## ELI5
In simple words: The perpendicular bisector of any chord of a circle always passes through the centre of that circle. Conversely, if a line passes through the centre of a circle and is perpendicular to a chord, it bisects the chord. Common mix-up: Students confuse the theorem with its converse: "Perpendicular from centre bisects chord" (c9_math_ch5_10).

## DEFINITION
The perpendicular bisector of any chord of a circle always passes through the centre of that circle. Conversely, if a line passes through the centre of a circle and is perpendicular to a chord, it bisects the chord. This bidirectional theorem establishes that the centre of a circle lies on the perpendicular bisector of every chord.
## COGNITIVE_LEVEL
understand
## MASTERY_CRITERIA
The student can prove the theorem using triangle congruence (SSS or RHS), apply it to find the centre of a given circle using two chords, and solve problems where the perpendicular distance from centre to chord is calculated using Pythagoras theorem combined with this property.
## SCOPE_BOUNDARY
Covers the theorem statement, proof using triangle congruence, applications in finding circle centre, and calculating chord lengths or distances from centre. Does NOT cover coordinate geometry proofs, equations of circles, or theorems about angles subtended by chords (covered in later nodes c9_math_ch5_6, c9_math_ch5_7).
## WALKTHROUGH
Imagine you are a surveyor in Rajasthan trying to locate the exact centre of a circular ancient well using only a measuring tape and a plumb line. You cannot reach the centre directly, but you can measure chords across the well's opening. If you draw two chords, construct their perpendicular bisectors using your plumb line, where they intersect must be the centre — this is exactly the theorem in action. Begin by drawing a circle with centre O, chord AB, and its perpendicular bisector PQ. Mark the midpoint M where PQ meets AB. To prove O lies on PQ, join OA and OB — these are radii. Now you have two triangles OMA and OMB with OM common, AM = BM (M is midpoint), and OA = OB (radii). By SSS congruence, the triangles are congruent, so ∠OMA = ∠OMB = 90°, proving OM is perpendicular to AB and thus O lies on the perpendicular bisector. The key insight: any point equidistant from A and B lies on the perpendicular bisector of AB, and the centre is equidistant from all points on the circle.
## DIAGNOSTIC_QUESTION_1
State the theorem: "The perpendicular bisector of a chord of a circle ______." Complete the sentence and draw a labelled diagram showing the chord, its perpendicular bisector, and the centre.
## DIAGNOSTIC_ANSWER_1
The perpendicular bisector of a chord of a circle **passes through the centre of the circle**. A correct diagram shows a circle with centre O, chord AB, midpoint M on AB, line PMQ perpendicular to AB at M, with O lying on PMQ. If a student writes "bisects the chord" instead, they are confusing this theorem with its converse (perpendicular from centre bisects chord). If they draw the centre not on the bisector, they haven't grasped the geometric locus concept — the centre is equidistant from endpoints, so it must lie on the perpendicular bisector.
## DIAGNOSTIC_QUESTION_2
In the diagram, O is the centre of the circle, AB is a chord, and OM ⟂ AB at M. A student claims: "Since OM is perpendicular to AB, M must be the midpoint of AB." Is this statement the same theorem or a different one? Explain why the logic "perpendicular from centre bisects chord" cannot be used to prove "perpendicular bisector passes through centre" without circular reasoning.
## DIAGNOSTIC_ANSWER_2
This is the **converse theorem** (c9_math_ch5_10), not the same theorem. The student's statement assumes we already know O is the centre and OM ⟂ AB, then concludes M is the midpoint. Our theorem (c9_math_ch5_4) starts with M as the midpoint and PM ⟂ AB, then proves O lies on PM. Using the converse to prove the original would be circular reasoning because both theorems are logically equivalent — each can be proved independently using triangle congruence (SSS for this theorem, RHS for the converse). A student who doesn't distinguish them will fail to construct a valid proof in board exams where "prove that the perpendicular bisector passes through the centre" requires starting from the midpoint, not the centre.
## DIAGNOSTIC_QUESTION_3
A chord of length 16 cm is drawn in a circle of radius 10 cm. Find the distance of the chord from the centre. Then, using the theorem, explain how you would locate the centre of this circle if only the chord and the circle's circumference were given (no centre marked).
## DIAGNOSTIC_ANSWER_3
**Distance calculation:** Let chord AB = 16 cm, radius OA = OB = 10 cm. Perpendicular from centre O to AB bisects it at M (converse theorem). So AM = MB = 8 cm. In right triangle OMA, OA² = OM² + AM² (Pythagoras). 10² = OM² + 8² → 100 = OM² + 64 → OM² = 36 → OM = 6 cm. **Locating centre:** Draw another chord CD (not parallel to AB). Construct perpendicular bisectors of AB and CD using compass and ruler. Their intersection point is the centre O. This works because the theorem guarantees the centre lies on the perpendicular bisector of ANY chord. If a student uses only one chord, they get a line of possible centres, not a unique point — they miss that two non-parallel chords are needed for a unique intersection.
## DIAGNOSTIC_QUESTION_4
Two chords AB and CD of a circle intersect at point P inside the circle. The perpendicular bisectors of AB and CD meet at O. Prove that O is the centre of the circle. Now consider: if AB and CD are parallel chords, their perpendicular bisectors are the same line. Can you still find the centre? What additional construction is needed?
## DIAGNOSTIC_ANSWER_4
**Proof:** By theorem, perpendicular bisector of AB passes through centre. Perpendicular bisector of CD also passes through centre. Two distinct non-parallel lines intersect at exactly one point, so their intersection O must be the centre. **Parallel chords case:** If AB ∥ CD, their perpendicular bisectors coincide (same line). You cannot locate a unique centre from just one line. **Additional construction:** Draw a third chord EF not parallel to AB (or CD). Its perpendicular bisector will intersect the common bisector at the centre. A student who says "impossible" misses that the theorem applies to ALL chords — you just need two non-parallel chords. This tests understanding that the theorem is universal for every chord, not just a special pair.
## DIAGNOSTIC_QUESTION_5
A student's proof: "Let AB be a chord, M its midpoint. Draw OM. Since OA = OB (radii) and AM = BM (M midpoint), triangles OAM and OBM are congruent by SSS. So ∠OMA = ∠OMB. Since they sum to 180°, each is 90°. Therefore OM ⟂ AB, so O lies on the perpendicular bisector." Identify the logical flaw in the order of reasoning. Rewrite the proof correctly starting from the perpendicular bisector.
## DIAGNOSTIC_ANSWER_5
**Flaw:** The student assumes O is joined to M *before* proving O lies on the perpendicular bisector. They effectively used the converse (perpendicular from centre bisects chord) in disguise by drawing OM and proving it's perpendicular. **Correct proof:** Let AB be a chord. Construct its perpendicular bisector PQ (using compass/ruler). Let PQ meet AB at M. So PM ⟂ AB and AM = MB. Join OA and OB. In ΔOAM and ΔOBM: OA = OB (radii), AM = MB (construction), OM = OM (common). By SSS, ΔOAM ≅ ΔOBM. So ∠OMA = ∠OMB = 90° (linear pair). Thus OM ⟂ AB, meaning O lies on PQ. The student who doesn't see this flaw will lose marks in board exams for "assuming what is to be proved" — the proof must start from the bisector construction, not from the centre.
## DIAGNOSTIC_QUESTION_6
Design a real-world problem for a Class 9 student where this theorem is used to find the centre of a circular object (e.g., a plate, a wheel, a roundabout) using only a ruler, a set square, and a pencil. The problem must require drawing at least two chords and explaining why the intersection gives the centre.
## DIAGNOSTIC_ANSWER_6
**Sample problem:** "You have a circular metal plate with no centre mark. You need to drill a hole exactly at its centre for a shaft. Using only a ruler, set square, and pencil, describe the steps to mark the centre accurately." **Good answer:** (1) Draw chord AB anywhere on the plate. (2) Use set square to draw perpendicular bisector of AB. (3) Draw another chord CD not parallel to AB. (4) Draw perpendicular bisector of CD. (5) Mark intersection O of the two bisectors — this is the centre. **Justification:** By theorem, centre lies on perpendicular bisector of any chord. Two non-parallel chords give two distinct bisectors intersecting at the unique centre. A poor answer uses only one chord, or draws diameters by guessing, or doesn't justify why intersection is the centre. This tests ability to transfer geometric reasoning to practical construction.
## COMMON_MISCONCEPTION
Students confuse the theorem with its converse: "Perpendicular from centre bisects chord" (c9_math_ch5_10). In proofs, they start by drawing radius to midpoint (assuming centre is known) instead of constructing the perpendicular bisector first. Example wrong working: "Let O be centre, AB chord, M midpoint. Join OM. Prove OM ⟂ AB." This proves the converse, not the required theorem. Board examiners deduct marks for "proving the wrong statement" — the question "Prove that the perpendicular bisector of a chord passes through the centre" requires starting with the bisector, not the centre.
## ON_FAILURE
If a student makes this error: (1) Ask them to read the theorem statement slowly: "perpendicular bisector ... passes through centre" — what is given? The bisector. What is to be proved? Centre lies on it. (2) Have them physically construct a perpendicular bisector of a segment on paper using compass — they see the bisector exists *without* knowing any centre. (3) Then draw a circle around that segment as a chord — the centre must be somewhere on their bisector line. (4) Repeat with a second chord — the intersection pins the centre. This concrete construction-first approach breaks the mental habit of starting from the centre.
## PREREQUISITE_NODE_IDS
c9_math_ch5_1, c9_math_ch5_3, c7_math_ch14_002, c7_math_ch09_005, c7_math_ch09_006, c6_math_ch07_076, c6_math_ch07_081, c9_math_ch5_2

## PREREQUISITE_REASONS
c9_math_ch5_1: Defines circle, centre, radius, chord — essential vocabulary for the theorem statement.
c9_math_ch5_3: Covers chord properties (midpoint, perpendicular from centre) — directly leads to this theorem.
c7_math_ch14_002: Teaches perpendicular bisector construction — needed to "draw the bisector" in proof and applications.
c7_math_ch09_005: SSS congruence criterion — used in the standard proof of this theorem.
c7_math_ch09_006: SAS congruence criterion — alternative proof method (using radii and right angles).
c6_math_ch07_076: Basic circle terminology (radius, diameter, chord, arc) — foundation for all circle theorems.
c6_math_ch07_081: Constructing perpendicular lines and bisectors — practical skill for locating centre.
c9_math_ch5_2: A circle possesses **reflection symmetry** about any line passing through its centre (every  - earlier chapter node that this node's author flags as feeding into this content.

## FORWARD_NODE_IDS
c9_math_ch5_5, c9_math_ch5_6, c9_math_ch5_10, c10_math_cbse_10_001, c10_math_cbse_10_003, c10_math_cbse_10_005, c10_math_cbse_10_009, c10_math_cbse_10_010

## FORWARD_REASONS
c9_math_ch5_5: Equal chords are equidistant from centre — uses perpendicular distances (this theorem) to prove equality.
c9_math_ch5_6: Angle subtended by chord at centre — uses radii to chord endpoints (this theorem guarantees centre on bisector).
c9_math_ch5_10: Converse theorem (perpendicular from centre bisects chord) — logically paired, often proved together in exams.
c10_math_cbse_10_001: Proves that the perpendicular from the centre to a chord bisects it — this logic extends to the tangent as the limiting case of a chord whose endpoints coincide, motivating the tangent-radius perpendicular property in the next node.
c10_math_cbse_10_003: Establishes that the perpendicular from centre to a chord bisects it — the proof of tangent-radius theorem uses the "shortest distance" principle from this concept.
c10_math_cbse_10_005: Perpendicular bisector of chord passes through centre — used in the symmetry argument for equal tangent lengths.
c10_math_cbse_10_009: Perpendicular bisector of chord passing through centre reinforces the symmetry used in tangent proofs.
c10_math_cbse_10_010: Perpendicular bisector of chord passes through centre, used in some tangent-chord problems.

## CROSS_SUBJECT_PREREQS
c7_math_ch14_002, c7_math_ch09_005, c6_math_ch07_081
## CROSS_SUBJECT_REASONS
c7_math_ch14_002: Geometric construction of perpendicular bisector — the practical skill used to physically locate centres in engineering/design.
c7_math_ch09_005: Triangle congruence (SSS) — the logical backbone of the proof, a core geometry reasoning skill.
c6_math_ch07_081: Construction of perpendiculars — connects to real-world surveying and architecture where centres of circular structures are located.
## CHAIN_DESCRIPTION
c9_math_ch5_3 -> c9_math_ch5_4 -> c9_math_ch5_5 (Chord properties → Perpendicular bisector theorem → Equal chords distance theorem)
## THIS_FORMULA
N/A - conceptual theorem (geometric property)
## FORMULA_VARIABLES
N/A
## FORMULA_UNITS
dimensionless
## COMPUTATION_TYPE
geometric
## CROSS_SUBJECT
c9_geo_ch2_1 | Map reading uses perpendicular bisectors to find epicentres: seismic waves from an earthquake reach three stations; the perpendicular bisectors of chords between stations intersect at the epicentre — same geometric principle.
## PREREQ_CONCEPT
Triangle congruence criteria (SSS/SAS) and perpendicular bisector construction — the proof and application both rely on these.
## PREREQ_BEFORE
Student must be able to construct a perpendicular bisector of a line segment using compass and ruler, and state SSS/SAS congruence conditions with correct vertex correspondence.
## PREREQ_STUCK
Revisit c7_math_ch14_002 (perpendicular bisector construction) and c7_math_ch09_005/006 (triangle congruence) — practice constructing bisectors and writing congruence statements with proper order of vertices.
## WORKED_EXAMPLE_1
PROBLEM: A circular garden has a straight path (chord) of length 24 metres across it. The perpendicular distance from the centre of the garden to this path is 5 metres. Find the radius of the garden. Then explain how a gardener could locate the exact centre of the garden using only a long rope and a right-angled tool (like a carpenter's square), without measuring the radius.

STEPS:
- Step 1: Identify given values — chord length AB = 24 m, perpendicular distance from centre OM = 5 m. Let O be centre, M midpoint of AB.
- Step 2: Apply the converse theorem (perpendicular from centre bisects chord) — since OM ⟂ AB, M is the midpoint. So AM = MB = 12 m.
- Step 3: In right triangle OMA, apply Pythagoras theorem: OA² = OM² + AM². OA is the radius we need.
- Step 4: Substitute values: OA² = 5² + 12² = 25 + 144 = 169. So OA = √169 = 13 m.
- Step 5: For locating centre practically: The gardener stretches the rope across the garden to mark chord AB. Uses the right-angled tool to construct perpendicular bisector of AB (by marking equal distances from A and B along the rope, then drawing perpendicular). Repeats with another chord CD not parallel to AB. The intersection of the two bisectors is the centre O. This works because the theorem guarantees the centre lies on the perpendicular bisector of ANY chord.

REASONING: The problem combines the converse theorem (to get half-chord length) with Pythagoras (to find radius). The practical method directly applies the forward theorem: the centre lies on the perpendicular bisector of every chord. Two non-parallel chords give two lines whose intersection is the unique centre.

ANSWER: Radius = 13 metres. Centre located at intersection of perpendicular bisectors of two non-parallel chords.
## WORKED_EXAMPLE_2
PROBLEM: In a circle with centre O, two chords AB and CD are parallel and on opposite sides of the centre. AB = 10 cm, CD = 24 cm, and the distance between the chords is 17 cm. Find the radius of the circle. (Hint: Use the fact that perpendicular from centre to parallel chords lies on the same line.)

STEPS:
- Step 1: Draw diagram. Let O be centre. Draw perpendicular OM to AB (M on AB) and ON to CD (N on CD). Since AB ∥ CD, M, O, N are collinear. Distance between chords = MN = 17 cm.
- Step 2: Let OM = x cm. Then ON = (17 - x) cm (since O lies between M and N as chords are on opposite sides).
- Step 3: Perpendicular from centre bisects chords (converse theorem). So AM = AB/2 = 5 cm, CN = CD/2 = 12 cm.
- Step 4: In right triangles OMA and ONC, radii OA = OC = r. Apply Pythagoras: r² = OM² + AM² = x² + 5² = x² + 25. Also r² = ON² + CN² = (17 - x)² + 12² = (289 - 34x + x²) + 144 = x² - 34x + 433.
- Step 5: Equate the two expressions for r²: x² + 25 = x² - 34x + 433. Cancel x²: 25 = -34x + 433 → 34x = 408 → x = 12 cm.
- Step 6: Substitute x = 12 into r² = x² + 25 = 144 + 25 = 169 → r = 13 cm.

REASONING: This problem uses the converse theorem (perpendicular from centre bisects chord) twice, and the fact that perpendiculars to parallel chords are collinear (which follows from the uniqueness of perpendicular from a point to a line). The key is setting up the distance variable correctly — O lies between the chords, so the distances from O to each chord sum to the total separation.

ANSWER: Radius = 13 cm.
## WORKED_EXAMPLE_3
PROBLEM: A circular railway track of unknown radius needs its centre marked for maintenance. Surveyors can only access the track at three points A, B, C on the circumference. They measure AB = 18 m, BC = 24 m, AC = 30 m. Show that triangle ABC is right-angled. Using the theorem, explain how to find the centre of the circle using only these three points and a theodolite (angle-measuring instrument). Calculate the radius.

STEPS:
- Step 1: Check if triangle ABC is right-angled. Sides: 18, 24, 30. Check Pythagoras: 18² + 24² = 324 + 576 = 900 = 30². Yes, it satisfies Pythagoras, so ∠B = 90° (angle opposite longest side AC).
- Step 2: In a circle, the angle in a semicircle is 90° (Thales' theorem, covered later). Since ∠ABC = 90°, AC must be a diameter. So the centre O is the midpoint of AC.
- Step 3: Alternatively, using our theorem (perpendicular bisector of chord passes through centre): Construct perpendicular bisectors of chords AB and BC. Their intersection is the centre O. Since ∠B = 90°, the perpendicular bisectors of AB and BC will intersect at the midpoint of AC.
- Step 4: Radius = half of diameter AC = 30/2 = 15 m.
- Step 5: Practical method with theodolite: At point B, measure angle ABC — it reads 90°. This confirms AC is diameter. The surveyor then finds midpoint of AC by measuring 15 m from A along AC. Or, they can measure perpendicular bisectors: at A, turn 90° to AB and sight line; at C, turn 90° to BC and sight line; intersection is centre.

REASONING: This combines chord properties with triangle geometry. The 18-24-30 triangle is a 3-4-5 scaled by 6, a classic Pythagorean triple. The theorem is used implicitly: the perpendicular bisector of chord AB (which is a leg of the right triangle) and chord BC intersect at the midpoint of the hypotenuse AC, which is the centre. This shows how the theorem connects to the "angle in semicircle" property.

ANSWER: Triangle ABC is right-angled at B. Centre is midpoint of AC. Radius = 15 m.
## COMPETENCY_QUESTION_1
QUESTION: A circular water tank has a leak at point L on its circumference. Maintenance workers need to find the centre O to install a central valve. They can only walk along the circumference and measure straight-line distances between points on the edge using a laser rangefinder. They mark three points A, B, C on the circumference and measure AB = 12 m, BC = 16 m, CA = 20 m. (a) Prove that triangle ABC is right-angled. (b) Which side is the diameter? (c) Explain how they can locate the exact centre O using only the laser rangefinder and the theorem about perpendicular bisectors, without entering the tank. (d) Calculate the radius of the tank.

COMPETENCY: Translating real-world situations to mathematical expressions and justifying geometric constructions.

STEPS:
- Step 1: Verify right triangle using Pythagoras: 12² + 16² = 144 + 256 = 400 = 20². So ∠B = 90°.
- Step 2: In a circle, angle in a semicircle is 90°. Since ∠B = 90° and B is on circumference, AC must be the diameter.
- Step 3: To locate centre using perpendicular bisector theorem: The centre lies on the perpendicular bisector of ANY chord. They can find midpoint of AC by measuring 10 m from A along AC (since AC = 20 m). Or, construct perpendicular bisectors of AB and BC using laser to find points equidistant from A,B and B,C respectively — intersection is centre.
- Step 4: Radius = half of diameter AC = 10 m.

ANSWER: (a) 12² + 16² = 20², so right-angled at B. (b) AC is the diameter. (c) Centre is midpoint of AC (10 m from A), or intersection of perpendicular bisectors of AB and BC. (d) Radius = 10 m.

DIFFICULTY: medium
## COMPETENCY_QUESTION_2
QUESTION: Two circles of radii 5 cm and 3 cm intersect at two points A and B. The distance between their centres O₁ and O₂ is 6 cm. (a) Prove that the line O₁O₂ is the perpendicular bisector of the common chord AB. (b) Find the length of the common chord AB. (c) A student says: "Since O₁O₂ is the perpendicular bisector of AB, the midpoint M of AB divides O₁O₂ in the ratio of the radii (5:3)." Is this correct? Justify your answer.

COMPETENCY: Comparing and justifying geometric relationships; error identification and correction.

STEPS:
- Step 1: For (a): In circles with centres O₁, O₂, chord AB is common. By theorem, perpendicular bisector of AB passes through O₁ (for first circle) and through O₂ (for second circle). Two points determine a unique line, so O₁O₂ is the perpendicular bisector of AB.
- Step 2: For (b): Let M be midpoint of AB. O₁M ⟂ AB, O₂M ⟂ AB. In right triangles O₁MA and O₂MA: O₁A = 5, O₂A = 3, O₁O₂ = 6. Let O₁M = x, then O₂M = 6 - x. By Pythagoras: 5² = x² + AM² and 3² = (6-x)² + AM². Subtract: 25 - 9 = x² - (36 - 12x + x²) → 16 = 12x - 36 → 12x = 52 → x = 13/3 cm. Then AM² = 25 - (169/9) = (225-169)/9 = 56/9 → AM = √(56/9) = (2√14)/3. So AB = 2AM = (4√14)/3 cm.
- Step 3: For (c): The student claims O₁M : MO₂ = 5 : 3. But O₁M = 13/3, MO₂ = 6 - 13/3 = 5/3. Ratio = (13/3) : (5/3) = 13:5, NOT 5:3. The student incorrectly assumed the midpoint divides the line of centres in the ratio of radii. Actually, the division ratio depends on the distances, not directly on radii.

ANSWER: (a) O₁O₂ is perpendicular bisector of AB because both centres lie on it (theorem). (b) AB = (4√14)/3 cm ≈ 4.99 cm. (c) Incorrect. Actual ratio O₁M:MO₂ = 13:5, not 5:3. The midpoint divides the line of centres in the ratio of the squares of the radii minus something — it's not a simple ratio.

DIFFICULTY: hard

## DIAGNOSTIC_QUESTION_7
Fill in the blank: The ______ bisector of any chord of a circle always passes through the centre of that circle.

## DIAGNOSTIC_ANSWER_7
perpendicular

## DIAGNOSTIC_QUESTION_8
Fill in the blank: Imagine you are a surveyor in Rajasthan trying to locate the exact centre of a circular ancient well using only a ______ tape and a plumb line.

## DIAGNOSTIC_ANSWER_8
measuring

## DIAGNOSTIC_QUESTION_9
Fill in the blank: By SSS congruence, the triangles are congruent, so ∠OMA = ∠OMB = ______°, proving OM is perpendicular to AB and thus O lies on the perpendicular bisector.

## DIAGNOSTIC_ANSWER_9
90

## DIAGNOSTIC_QUESTION_10
What must you be able to do to master this topic?

## DIAGNOSTIC_ANSWER_10
The student can prove the theorem using triangle congruence (SSS or RHS), apply it to find the centre of a given circle using two chords, and solve problems where the perpendicular distance from centre to chord is calculated using Pythagoras theorem combined with this property.

## DIAGNOSTIC_QUESTION_11
Fill in the blank: Imagine you are a surveyor in ______ trying to locate the exact centre of a circular ancient well using only a measuring tape and a plumb line.

## DIAGNOSTIC_ANSWER_11
Rajasthan
