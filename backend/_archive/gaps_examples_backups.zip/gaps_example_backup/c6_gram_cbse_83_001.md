## PREREQUISITE_NODE_IDS
c6_gram_cbse_82_001, c6_gram_cbse_82_002, c6_gram_cbse_82_003, c6_gram_cbse_81_001, c6_gram_cbse_81_002, c6_gram_cbse_81_003

## DIAGNOSTIC_QUESTION_4
'a' and 'an' introduce something new and ______; 'the' points at something specific that both people know.

## DIAGNOSTIC_ANSWER_4
non-specific

## ELI5
In simple words: 'a' and 'an' introduce something new and non-specific; 'the' points at something specific that both people know. And 'an' listens to SOUND not spelling: 'an apple', 'an hour' (silent h), but 'a university' (yoo-sound). Common mix-up: Students pick 'an' by looking at the first letter → 'an university', 'a hour' — and use 'the' for general categories ('The dogs are faithful animals').

## DEFINITION
'a' and 'an' introduce something new and non-specific; 'the' points at something specific that both people know. And 'an' listens to SOUND not spelling: 'an apple', 'an hour' (silent h), but 'a university' (yoo-sound).

## COGNITIVE_LEVEL
apply

## MASTERY_CRITERIA
The student chooses a/an/the by the shared-knowledge test, picks a vs an by pronunciation not spelling, and explains first-mention-a versus second-mention-the.

## SCOPE_BOUNDARY
Covers the basic article algorithm. Does NOT cover zero-article rules or quantifiers (class 9+).

## WALKTHROUGH
The story rule: 'I saw a bird. The bird sat on a branch. The branch broke.' First mention = a (new to the story), every mention after = the (we know which one). Then the sound test: say it aloud — 'hour' starts with a vowel sound → an; 'university' starts with 'yoo' → a.

## COMMON_MISCONCEPTION
Students pick 'an' by looking at the first letter → 'an university', 'a hour' — and use 'the' for general categories ('The dogs are faithful animals').

## ON_FAILURE
Step 1: First mention and non-specific → a/an. Known/specific → the. Step 2: a vs an — say the word; vowel SOUND → an. Step 3: General categories (all dogs, honesty) → usually no 'the'.

## DIAGNOSTIC_QUESTION_1
'___ umbrella' and '___ European country' — pick a or an for each.

## DIAGNOSTIC_ANSWER_1
'an umbrella' (vowel sound) and 'a European country' (yoo- consonant sound). A wrong answer 'a umbrella'/'an European' shows the student is matching letters, not sounds.

## DIAGNOSTIC_QUESTION_2
'I saw ___ elephant. ___ elephant was drinking water.'

## DIAGNOSTIC_ANSWER_2
a, then The — first mention introduces with 'a'; second points back with 'the'. A wrong answer 'a' twice shows the student doesn't track shared knowledge across sentences.

## DIAGNOSTIC_QUESTION_3
Fix: 'The honesty is the best policy.'

## DIAGNOSTIC_ANSWER_3
'Honesty is the best policy' — abstract/general nouns take no 'the' when meaning the whole idea. A wrong answer keeping 'the' shows over-specification.

## DIAGNOSTIC_QUESTION_5
Fill in the blank: 'a' and 'an' ______ something new and non-specific; 'the' points at something specific that both people know.

## DIAGNOSTIC_ANSWER_5
introduce

## DIAGNOSTIC_QUESTION_6
Fill in the blank: The ______ broke.' First mention = a (new to the story), every mention after = the (we know which one).

## DIAGNOSTIC_ANSWER_6
branch

## DIAGNOSTIC_QUESTION_7
What must you be able to do to master this topic?

## DIAGNOSTIC_ANSWER_7
The student chooses a/an/the by the shared-knowledge test, picks a vs an by pronunciation not spelling, and explains first-mention-a versus second-mention-the.
