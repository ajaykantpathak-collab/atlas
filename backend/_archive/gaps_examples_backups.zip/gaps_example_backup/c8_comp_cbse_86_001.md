## PREREQUISITE_NODE_IDS
c8_comp_cbse_86_002

## DIAGNOSTIC_QUESTION_4
A message is a compressed ______ record: when the writer wasn't there, you relay what matters — date and time of writing, the caller's name, the actual message in clipped sentences, and your name.

## DIAGNOSTIC_ANSWER_4
conversation

## ELI5
In simple words: A message is a compressed conversation record: when the writer wasn't there, you relay what matters — date and time of writing, the caller's name, the actual message in clipped sentences, and your name. About 50 words, indirect speech, no decoration. Common mix-up: Students copy the dialogue's direct speech into the message, exceed the word limit with filler, and forget to date-time-stamp the note.

## DEFINITION
A message is a compressed conversation record: when the writer wasn't there, you relay what matters — date and time of writing, the caller's name, the actual message in clipped sentences, and your name. About 50 words, indirect speech, no decoration.

## COGNITIVE_LEVEL
apply

## MASTERY_CRITERIA
The student compresses a telephone/verbal exchange into a ≤50-word message with all five elements, converting direct quotes to reported form.

## SCOPE_BOUNDARY
Covers the standard school message format (box optional by board). Does NOT cover notices or emails.

## WALKTHROUGH
The relay test: read a dialogue, extract what the RECEIVER must know — who called, about what, what action is needed, when. 'Anil called — your cricket kit is at his house; collect it before 6 pm.' Time-stamp at top, signature at bottom, box if required.

## COMMON_MISCONCEPTION
Students copy the dialogue's direct speech into the message, exceed the word limit with filler, and forget to date-time-stamp the note.

## ON_FAILURE
Step 1: Header — MESSAGE, date, time. Step 2: Salutation (name of receiver). Step 3: Body — caller + what they said in reported form + required action. Step 4: Writer's name. Step 5: Count — around 50 words.

## DIAGNOSTIC_QUESTION_1
Convert for a message: 'Tell Rahul that I said, "I will bring the book tomorrow".'

## DIAGNOSTIC_ANSWER_1
'Ravi called — he said he would bring the book tomorrow/the next day.' A wrong answer keeping 'I will bring' inside the message shows direct-speech leak — messages report, they don't quote.

## DIAGNOSTIC_QUESTION_2
What are the five elements of a message format?

## DIAGNOSTIC_ANSWER_2
Date, time, receiver's name/salutation, the reported message body, writer's name. A wrong answer missing date/time shows the student treats messages like mini-letters.

## DIAGNOSTIC_QUESTION_3
A message reads 85 words and includes 'Hello! How are you? It was such a nice chat.' — what's wrong?

## DIAGNOSTIC_ANSWER_3
Word-limit breach plus conversational filler — a message relays facts for action, not the chat. A wrong answer 'it's fine' shows the student doesn't know messages are clipped instruments.

## DIAGNOSTIC_QUESTION_5
Fill in the blank: A message is a compressed ______ record: when the writer wasn't there, you relay what matters — date and time of writing, the caller's name, the actual message in clipped sentences, and your name.

## DIAGNOSTIC_ANSWER_5
conversation

## DIAGNOSTIC_QUESTION_6
Fill in the blank: The relay test: read a ______, extract what the RECEIVER must know — who called, about what, what action is needed, when. 'Anil called — your cricket kit is at his house; collect it before 6 pm.' Time-stamp at top, signature at bottom, box if required.

## DIAGNOSTIC_ANSWER_6
dialogue

## DIAGNOSTIC_QUESTION_7
Fill in the blank: About ______ words, indirect speech, no decoration.

## DIAGNOSTIC_ANSWER_7
50

## DIAGNOSTIC_QUESTION_8
What must you be able to do to master this topic?

## DIAGNOSTIC_ANSWER_8
The student compresses a telephone/verbal exchange into a ≤50-word message with all five elements, converting direct quotes to reported form.

## DIAGNOSTIC_QUESTION_9
Fill in the blank: The relay test: read a dialogue, extract what the RECEIVER must know — who called, about what, what action is needed, when. 'Anil called — your cricket kit is at his house; collect it before 6 pm.' Time-stamp at top, ______ at bottom, box if required.

## DIAGNOSTIC_ANSWER_9
signature
