## PREREQUISITE_NODE_IDS
c9_gram_cbse_80_001, c9_gram_cbse_81_001, c9_gram_cbse_81_002, c9_gram_cbse_82_001, c9_gram_cbse_83_001, c9_gram_cbse_84_001

## DIAGNOSTIC_QUESTION_4
Editing tasks test the same tense sins in disguise: wrong form for the marker, double past ('didn't went'), missing auxiliaries ('she reading'), and tense drift ______ ('She was cooking and eats dinner').

## DIAGNOSTIC_ANSWER_4
mid-sentence

## ELI5
In simple words: Editing tasks test the same tense sins in disguise: wrong form for the marker, double past ('didn't went'), missing auxiliaries ('she reading'), and tense drift mid-sentence ('She was cooking and eats dinner'). Common mix-up: Students hunt for spelling errors in editing tasks and miss tense errors entirely — they don't know what pattern to look for.

## DEFINITION
Editing tasks test the same tense sins in disguise: wrong form for the marker, double past ('didn't went'), missing auxiliaries ('she reading'), and tense drift mid-sentence ('She was cooking and eats dinner').

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student locates and corrects tense errors in editing passages — one error per line format — and names the rule each correction applies.

## SCOPE_BOUNDARY
Covers the editing-question format applied to tense errors. Does NOT cover concord or determiner errors (those appear in the same format but are different nodes).

## WALKTHROUGH
The editing workflow: read for meaning first, then audit each verb against its markers. 'He didn't went' — the error is 'went'; 'did' already carries the past, so the main verb must return to base. 'She was cooking and eats' — drift: one time-zone, one tense family.

## COMMON_MISCONCEPTION
Students hunt for spelling errors in editing tasks and miss tense errors entirely — they don't know what pattern to look for.

## ON_FAILURE
Step 1: Read the line for its time-zone and markers. Step 2: Audit the verb — correct form for the marker? auxiliary present? Step 3: After did/didn't/does — verb back to base form. Step 4: Same time-zone = same tense family.

## DIAGNOSTIC_QUESTION_1
Edit: 'He didn't went to the doctor yesterday.'

## DIAGNOSTIC_ANSWER_1
'went' → 'go' — after 'didn't' the verb returns to base; 'did' already carries the past. A wrong answer 'didn't goed' creates a new error instead of fixing the old.

## DIAGNOSTIC_QUESTION_2
Edit: 'She was cooking dinner and eats it quickly.'

## DIAGNOSTIC_ANSWER_2
'eats' → 'ate' — tense drift; both actions share the past time-zone. A wrong answer changing 'was cooking' shows the student picks the wrong verb to fix.

## DIAGNOSTIC_QUESTION_3
Edit: 'Look! The baby crawl towards the door.'

## DIAGNOSTIC_ANSWER_3
'crawl' → 'is crawling' — 'Look!' demands present continuous, and it needs the be-auxiliary. A wrong answer 'crawls' misses the marker entirely.

## DIAGNOSTIC_QUESTION_5
Fill in the blank: Editing tasks test the same tense sins in disguise: wrong form for the marker, double past ('didn't went'), missing ______ ('she reading'), and tense drift mid-sentence ('She was cooking and eats dinner').

## DIAGNOSTIC_ANSWER_5
auxiliaries

## DIAGNOSTIC_QUESTION_6
Fill in the blank: The ______ workflow: read for meaning first, then audit each verb against its markers. 'He didn't went' — the error is 'went'; 'did' already carries the past, so the main verb must return to base. 'She was cooking and eats' — drift: one time-zone, one tense family.

## DIAGNOSTIC_ANSWER_6
editing

## DIAGNOSTIC_QUESTION_7
What must you be able to do to master this topic?

## DIAGNOSTIC_ANSWER_7
The student locates and corrects tense errors in editing passages — one error per line format — and names the rule each correction applies.

## DIAGNOSTIC_QUESTION_8
Fill in the blank: The editing ______: read for meaning first, then audit each verb against its markers. 'He didn't went' — the error is 'went'; 'did' already carries the past, so the main verb must return to base. 'She was cooking and eats' — drift: one time-zone, one tense family.

## DIAGNOSTIC_ANSWER_8
workflow
