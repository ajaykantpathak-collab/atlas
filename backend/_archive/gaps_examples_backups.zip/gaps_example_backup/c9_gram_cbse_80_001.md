## PREREQUISITE_NODE_IDS
c9_gram_cbse_80_002, c9_gram_cbse_81_001, c9_gram_cbse_81_002, c9_gram_cbse_82_001, c9_gram_cbse_83_001, c9_gram_cbse_84_001

## DIAGNOSTIC_QUESTION_4
CBSE class 9 tests tense through gap-fills and editing, not definitions: the examiners' tools are ______ (since, for, by the time, while, already, yet), stative verbs (know, believe, own — no -ing), and two-event ordering (earlier past = past perfect).

## DIAGNOSTIC_ANSWER_4
time-markers

## ELI5
In simple words: CBSE class 9 tests tense through gap-fills and editing, not definitions: the examiners' tools are time-markers (since, for, by the time, while, already, yet), stative verbs (know, believe, own — no -ing), and two-event ordering (earlier past = past perfect).

## DEFINITION
CBSE class 9 tests tense through gap-fills and editing, not definitions: the examiners' tools are time-markers (since, for, by the time, while, already, yet), stative verbs (know, believe, own — no -ing), and two-event ordering (earlier past = past perfect).

## COGNITIVE_LEVEL
apply

## MASTERY_CRITERIA
The student selects correct tense forms in gap-fill items by reading markers first, avoids stative-continuous errors, and orders two past events with past perfect.

## SCOPE_BOUNDARY
Covers the board-tested tense applications. Does NOT cover the full 12-cell theory (class 8 builds that) or modal perfects (ch 81).

## WALKTHROUGH
The exam pattern: every tense item hides a marker. 'I ___ here since 2019' — 'since' demands perfect. 'While she ___ , the phone rang' — 'while' demands continuous background. 'The train ___ before we reached' — 'before' demands past perfect on the earlier event. Read markers, not vibes.

## COMMON_MISCONCEPTION
Students choose tense by translating from Hindi — 'main 2019 se yahan hoon' produces 'I am here since 2019' — and miss that English encodes duration differently than Hindi.

## ON_FAILURE
Step 1: Underline every time expression before choosing. Step 2: Match marker → licensed form (since/for → perfect family; while → continuous; by the time/before → past perfect on earlier event). Step 3: Check the verb can take the form (statives refuse -ing).

## DIAGNOSTIC_QUESTION_1
'She ___ (teach) here for ten years.'

## DIAGNOSTIC_ANSWER_1
'has been teaching' / 'has taught' — 'for' demands the perfect family. A wrong answer 'is teaching' anchors to present and ignores the duration marker entirely.

## DIAGNOSTIC_QUESTION_2
'I ___ (not understand) this chapter — please explain again.'

## DIAGNOSTIC_ANSWER_2
'do not understand' — stative verb, no continuous. A wrong answer 'am not understanding' is the stative-ing error that markers cannot excuse.

## DIAGNOSTIC_QUESTION_3
'The train had left before we reached' — which event is earlier, and which tense marks it?

## DIAGNOSTIC_ANSWER_3
The leaving is earlier, marked by past perfect 'had left'. A wrong answer saying 'reached' is earlier shows the student reads clauses in order rather than using 'before' to order events.

## DIAGNOSTIC_QUESTION_5
Fill in the blank: CBSE class 9 tests tense through gap-fills and editing, not ______: the examiners' tools are time-markers (since, for, by the time, while, already, yet), stative verbs (know, believe, own — no -ing), and two-event ordering (earlier past = past perfect).

## DIAGNOSTIC_ANSWER_5
definitions

## DIAGNOSTIC_QUESTION_6
Fill in the blank: The exam pattern: every tense item hides a marker. 'I ___ here since 2019' — 'since' demands perfect. 'While she ___ , the phone rang' — 'while' demands ______ background. 'The train ___ before we reached' — 'before' demands past perfect on the earlier event.

## DIAGNOSTIC_ANSWER_6
continuous

## DIAGNOSTIC_QUESTION_7
Fill in the blank: The exam pattern: every tense item hides a marker. 'I ___ here since ______' — 'since' demands perfect. 'While she ___ , the phone rang' — 'while' demands continuous background. 'The train ___ before we reached' — 'before' demands past perfect on the earlier event.

## DIAGNOSTIC_ANSWER_7
2019

## DIAGNOSTIC_QUESTION_8
What must you be able to do to master this topic?

## DIAGNOSTIC_ANSWER_8
The student selects correct tense forms in gap-fill items by reading markers first, avoids stative-continuous errors, and orders two past events with past perfect.
