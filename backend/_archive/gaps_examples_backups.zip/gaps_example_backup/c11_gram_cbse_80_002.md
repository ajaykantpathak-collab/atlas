## PREREQUISITE_NODE_IDS
c11_gram_cbse_80_001, c11_gram_cbse_81_001, c11_gram_cbse_81_002, c11_gram_cbse_82_001, c11_gram_cbse_82_002, c11_gram_cbse_83_001

## DIAGNOSTIC_QUESTION_4
A ______ relative clause is non-defining (extra info); without commas it defines which one.

## DIAGNOSTIC_ANSWER_4
comma-wrapped

## ELI5
In simple words: Relative clauses join with who/whom/whose/which/that — and the choice carries meaning: who/whom for people, which for things, that for either in defining clauses, whose for possession. A comma-wrapped relative clause is non-defining (extra info); without commas it defines which one.

## DEFINITION
Relative clauses join with who/whom/whose/which/that — and the choice carries meaning: who/whom for people, which for things, that for either in defining clauses, whose for possession. A comma-wrapped relative clause is non-defining (extra info); without commas it defines which one.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student selects the correct relative pronoun, distinguishes defining from non-defining clauses by commas and meaning, and uses whom/whose correctly.

## SCOPE_BOUNDARY
Covers relative pronoun selection and the defining/non-defining comma contrast. Does NOT cover reduced relatives ('the man standing there').

## WALKTHROUGH
The comma test: 'My brother, who lives in Delhi, is a doctor' — commas say I have one brother; the clause is a side-note. 'My brother who lives in Delhi is a doctor' — no commas; the clause picks WHICH brother. 'That' is banned after commas — non-defining clauses need who/which.

## COMMON_MISCONCEPTION
Students use 'that' everywhere including after commas ('My father, that is a doctor,…'), drop 'whose' for 'of which' clumsily, and ignore that commas change the meaning, not just the style.

## ON_FAILURE
Step 1: People → who/whom; things → which/that; possession → whose. Step 2: Defining (which-one) → no commas, 'that' allowed. Step 3: Non-defining (extra info) → commas, only who/which — never 'that'.

## DIAGNOSTIC_QUESTION_1
'The girl ___ won the prize is my sister.' who/which/that?

## DIAGNOSTIC_ANSWER_1
'who' or 'that' — defining clause about a person. A wrong answer 'which' misassigns the person/thing boundary.

## DIAGNOSTIC_QUESTION_2
'My car, ___ is ten years old, still runs well.' that or which?

## DIAGNOSTIC_ANSWER_2
'which' — comma-wrapped non-defining clauses cannot take 'that'. A wrong answer 'that' shows the comma-rule gap.

## DIAGNOSTIC_QUESTION_3
Does the meaning change: 'Students who cheat fail' vs 'Students, who cheat, fail'?

## DIAGNOSTIC_ANSWER_3
Yes — first says only cheating students fail (defining); second says all students cheat and all fail (non-defining). A wrong answer 'same meaning' reveals the student reads commas as decoration.

## DIAGNOSTIC_QUESTION_5
Fill in the blank: Relative clauses join with who/whom/whose/which/that — and the choice carries meaning: who/whom for people, which for things, that for either in defining clauses, whose for ______.

## DIAGNOSTIC_ANSWER_5
possession

## DIAGNOSTIC_QUESTION_6
Fill in the blank: The comma test: 'My brother, who lives in Delhi, is a doctor' — commas say I have one brother; the clause is a side-note. 'My brother who lives in Delhi is a doctor' — no commas; the clause picks WHICH brother. 'That' is banned after commas — non-______ clauses need who/which.

## DIAGNOSTIC_ANSWER_6
defining

## DIAGNOSTIC_QUESTION_7
What is Relative clauses join with who/whom/whose/which/that? State the definition given in this lesson.

## DIAGNOSTIC_ANSWER_7
Relative clauses join with who/whom/whose/which/that — and the choice carries meaning: who/whom for people, which for things, that for either in defining clauses, whose for possession.

## DIAGNOSTIC_QUESTION_8
What common mix-up does this lesson flag about Relative clauses join with who/whom/whose/which/that?

## DIAGNOSTIC_ANSWER_8
Students use 'that' everywhere including after commas ('My father, that is a doctor,…'), drop 'whose' for 'of which' clumsily, and ignore that commas change the meaning, not just the style.

## DIAGNOSTIC_QUESTION_9
What must you be able to do to master this topic?

## DIAGNOSTIC_ANSWER_9
The student selects the correct relative pronoun, distinguishes defining from non-defining clauses by commas and meaning, and uses whom/whose correctly.
