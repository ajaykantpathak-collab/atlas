## DEFINITION
Writing Skills based on the chapter refers to the ability to compose structured, evidence-based analytical responses for the two poems by Varjik ("nhi vosQyk" and "eSaus ns[kk] ,d cw¡n") using the PEEL (Point, Evidence, Explanation, Link) framework, embedding textual references, analyzing poetic devices, and comparing thematic concerns — all aligned with CBSE board marking schemes and competitive exam expectations.

## COGNITIVE_LEVEL
apply

## MASTERY_CRITERIA
The student can independently write a 150-200 word analytical answer for a poem-based question: (1) states a clear thesis in the opening sentence, (2) cites 2-3 specific lines/phrases from the poem as evidence, (3) explains how each evidence supports the thesis using literary terminology (imagery, symbolism, tone, etc.), and (4) concludes by linking back to the poem's central idea or the question's demand.

## SCOPE_BOUNDARY
This node covers writing analytical answers, critical appreciations, and comparative responses specifically for the two poems in Chapter 3 (Antra). It does NOT cover creative writing formats (story, letter, article) or prose chapters from other sections. It focuses on exam-oriented answer writing for poetry analysis.

## WALKTHROUGH
Imagine you open your board exam paper and see: "How does the poet use the image of a small plant to convey resilience? Answer in 150 words." You remember the poem "eSaus ns[kk] ,d cw¡n" but your first draft is: "The poet sees a small plant growing in a wall crack. It shows resilience because it grows without care. The poet likes it." This is a weak answer — it states observations but lacks analysis, terminology, and structure. Let's transform it. First, identify the core thesis: "The poet celebrates the resilience of life through the metaphor of a fragile plant thriving in adversity." Next, hunt for evidence: the phrase "jax xbZ {k.kHkj <yrs lwjt dh vkx ls" (color faded from the heat of dry winds) and "u'ojrk osQ nkx ls" (from the spark of novelty). Then, explain each: the imagery of "dry winds" symbolizes harsh circumstances, while "spark of novelty" suggests innate vitality. Finally, link to the central idea: the plant becomes a symbol of human perseverance. This PEEL process — Point, Evidence, Explanation, Link — is the skeleton of every high-scoring answer. Master it here, and you'll crack any poetry question.

## DIAGNOSTIC_QUESTION_1
What does the acronym PEEL stand for in the context of writing analytical answers for poetry?

## DIAGNOSTIC_ANSWER_1
PEEL stands for Point, Evidence, Explanation, Link. A wrong answer (e.g., "Paragraph, Example, Explanation, Line") reveals the student has memorized a mnemonic without understanding its function: Point = thesis statement, Evidence = quoted textual detail, Explanation = analysis of how evidence supports point, Link = connection to central idea/question. Without this precision, answers remain descriptive rather than analytical.

## DIAGNOSTIC_QUESTION_2
A student writes: "In 'nhi vosQyk', the poet says small things are important because they make life complete." Identify why this answer would score low on a CBSE 5-mark question despite being factually correct.

## DIAGNOSTIC_ANSWER_2
The answer is a mere paraphrase — it states *what* the poem says but not *how* the poet conveys it. It lacks: (1) a clear analytical point (e.g., "The poet elevates the insignificant through repetition and imperative tone"), (2) textual evidence (e.g., quoting "ij bldks Hkh iafDr dks ns nks"), (3) explanation of literary device (repetition of "ns nks" creates urgency), and (4) link to the theme of acceptance. Low marks stem from missing the "E" and "E" of PEEL.

## DIAGNOSTIC_QUESTION_3
Apply the PEEL structure to answer: "Analyze the symbolism of 'lwjt' (dry wind) in the second poem." Write only the Point and Evidence steps.

## DIAGNOSTIC_ANSWER_3
Point: The 'lwjt' (dry wind) symbolizes the hostile, indifferent forces of the world that threaten to wither fragile life. Evidence: The line "jax xbZ {k.kHkj <yrs lwjt dh vkx ls" explicitly states the plant's color fades due to the heat of the dry wind. A wrong answer might quote the line but call it "imagery of weather" — missing the symbolic leap from literal wind to metaphorical adversity, which is the core of poetic analysis.

## DIAGNOSTIC_QUESTION_4
Compare how the two poems in this chapter treat the concept of "smallness" (nhi / cw¡n). What is the key difference in their thematic focus?

## DIAGNOSTIC_ANSWER_4
"nhi vosQyk" treats smallness as *inherent value* — the nhi (small) is complete in itself and demands acceptance ("iafDr esa 'kkfey dj yks"). "eSaus ns[kk] ,d cw¡n" treats smallness as *latent power* — the cw¡n (small plant) is fragile but possesses explosive vitality ("u'ojrk osQ nkx ls"). The difference: first poem argues for *dignity of the small*; second demonstrates *triumph of the small*. A wrong answer conflates them as "both talk about small things" — missing the shift from static worth to dynamic resilience.

## DIAGNOSTIC_QUESTION_5
Evaluate this claim: "The refrain 'ij bldks Hkh iafDr dks ns nks' in 'nhi vosQyk' is merely a repetition for rhythm." Defend or refute using poetic function.

## DIAGNOSTIC_ANSWER_5
Refute. The refrain is a structural and thematic anchor: (1) structurally, it divides the poem into three stanzas, each addressing a different "nhi" (small thing), creating a catalog effect; (2) thematically, the imperative "ns nks" (give it) transforms from request to demand to command across stanzas, mirroring the poet's escalating insistence on acceptance; (3) the repetition of "iafDr" (life) expands the scope from individual to universal. Calling it "just rhythm" ignores how form enacts meaning — a classic competitive-exam trap.

## DIAGNOSTIC_QUESTION_6
Write a 4-line original stanza in Hindi that uses the same symbolic strategy as "eSaus ns[kk] ,d cw¡n" — a small natural object representing human resilience — but set in an urban context (e.g., a crack in concrete, a weed in a gutter).

## DIAGNOSTIC_ANSWER_6
Example:
"simT gya ek patta, simenT ki darar mein,
dhoop ki talab, barish ke intezaar mein.
koi nahi dekhata, koi nahi poochta,
phir bhi khilta hai, apne hi pyaar mein."
A poor answer writes a generic motivational poem without a concrete central image (the "cw¡n" equivalent) or fails to ground resilience in a specific hostile setting (the "lwjt" equivalent). The skill tested: transferring the poem's symbolic architecture to a new context — proof of deep structural understanding.

## COMMON_MISCONCEPTION
Students believe "writing a good answer" means "writing everything I know about the poem." They dump plot summary, poet biography, and unrelated themes into a 5-mark answer. This stems from confusing *knowledge display* with *argument construction*. In "nhi vosQyk", a student might write a paragraph on Varjik's biography (from node 001) and another on the summary (node 002) but never address the question "How does the poet use repetition?" The board awards marks for *targeted analysis*, not breadth of recall. Competitive exams (CUET) penalize irrelevance even more harshly.

## ON_FAILURE
If a student produces a "knowledge dump" answer: (1) Have them highlight every sentence that directly answers the question — usually <20%. (2) Give them a 3-sentence template: "The poet uses [device] to show [theme]. For example, '[quote]'. This works because [analysis]." (3) Practice with one stanza of "nhi vosQyk": question = "How does stanza 2 differ from stanza 1 in tone?" Force them to use only lines from stanza 2 as evidence. (4) Re-diagnose with a new question: "Analyze the word 'fo'okl' in stanza 3." Check for PEEL compliance.

## BUILDS_ON
Critical Thinking: Analysis and Interpretation (c12_hin_a_cbse_03_013) — provides the analytical insights (themes, devices, tone) that become the "Point" and "Explanation" in PEEL writing.

## LEADS_TO
Speaking and Listening: Discussion Points (c12_hin_a_cbse_03_015) — oral articulation of the same analytical arguments, requiring tighter structure and real-time evidence recall.

## PREREQUISITE_NODE_IDS
c12_hin_a_cbse_03_001, c12_hin_a_cbse_03_002, c12_hin_a_cbse_03_006, c12_hin_a_cbse_03_007, c12_hin_a_cbse_03_008, c12_hin_a_cbse_03_009, c12_hin_a_cbse_03_010, c12_hin_a_cbse_03_011, c12_hin_a_cbse_03_012, c12_hin_a_cbse_03_013, c11_hin_ar_cbse_01_014, c11_hin_ar_cbse_02_014, c11_hin_ar_cbse_03_014, c11_hin_v_cbse_01_014, c11_hin_v_cbse_02_014, c11_hin_v_cbse_03_014, c12_hin_a_cbse_03_005

## PREREQUISITE_REASONS
c12_hin_a_cbse_03_001: Context/background needed to frame poet's intent in answers.
c12_hin_a_cbse_03_002: Narrative structure of poems (stanza division, refrain) informs structural analysis.
c12_hin_a_cbse_03_006: Primary theme is the "Link" destination in every PEEL paragraph.
c12_hin_a_cbse_03_007: Secondary themes provide alternative "Points" for multi-theme questions.
c12_hin_a_cbse_03_008: Imagery/metaphor identification supplies "Evidence" and "Explanation" content.
c12_hin_a_cbse_03_009: Irony/symbolism analysis elevates "Explanation" from literal to interpretive.
c12_hin_a_cbse_03_010: Key vocabulary (e.g., "lwjt", "u'ojrk") enables precise quoting.
c12_hin_a_cbse_03_011: Grammar usage (imperative mood in "ns nks") supports linguistic analysis.
c12_hin_a_cbse_03_012: Literal/inferential comprehension distinguishes paraphrase from analysis.
c12_hin_a_cbse_03_013: Critical interpretations are the raw material for "Point" and "Explanation".
c11_hin_ar_cbse_01_014: Class 11 Antra writing skills foundation — PEEL introduced there.
c11_hin_ar_cbse_02_014: Practice with different poets/devices builds transferable skill.
c11_hin_ar_cbse_03_014: Reinforces answer structure across chapters.
c11_hin_v_cbse_01_014: Vitan writing skills — different text types, same analytical framework.
c11_hin_v_cbse_02_014: More practice with evidence embedding.
c11_hin_v_cbse_03_014: Consolidates Class 11 writing competency before Class 12.
c12_hin_a_cbse_03_005: Writing Skills tasks (analytical paragraph, essay) will directly use the PEEL structure practiced here.  

## FORWARD_NODE_IDS
c12_hin_a_cbse_03_015
## FORWARD_REASONS
c12_hin_a_cbse_03_015: Speaking/Listening requires the same analytical content (Points, Evidence) but demands oral fluency, real-time structuring, and responsive linking — the performative extension of written PEEL.

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
c12_english_writing_skills: The PEEL framework is identical in English Core (CBSE) — thesis, textual evidence, analysis, link. Mastery in Hindi transfers directly to English answer writing.
c12_english_poetry_analysis: Poetic devices (symbolism, refrain, imagery) have universal definitions; analyzing Varjik's "lwjt" as symbol trains the same skill as analyzing Keats' "nightingale" — cross-linguistic literary competence.

## CHAIN_DESCRIPTION
c12_hin_a_cbse_03_013 -> c12_hin_a_cbse_03_014 -> c12_hin_a_cbse_03_015

## THIS_FORMULA
PEEL = Point (thesis) + Evidence (quoted line/phrase) + Explanation (device + effect) + Link (back to theme/question)

## FORMULA_VARIABLES
Point: One-sentence analytical claim answering the question. Evidence: Exact word/phrase/line from poem in quotation marks. Explanation: 2-3 sentences analyzing HOW the evidence proves the point (name device, explain effect). Link: Closing sentence connecting this point to poem's central idea or question's broader demand.

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
linguistic

## CROSS_SUBJECT
N/A | PEEL structure is the mandated answer framework for CBSE English Core poetry/prose questions — identical cognitive process, different language.
 N/A | Symbolism, refrain, imagery analysis in Varjik maps 1:1 to English poems (e.g., "The Road Not Taken", "A Thing of Beauty") — same literary terminology, same exam expectations.
## PREREQ_CONCEPT
PEEL paragraph structure introduced in Class 11 Hindi writing skills nodes (c11_hin_ar_cbse_XX_014) and reinforced in Class 12 comprehension/critical thinking nodes.

## PREREQ_BEFORE
Student must be able to: (1) identify the central theme of each poem, (2) locate 3+ poetic devices with line references, (3) distinguish paraphrase from analysis.

## PREREQ_STUCK
If stuck on "Explanation" step: revisit c12_hin_a_cbse_03_008 (Imagery/Metaphor) and c12_hin_a_cbse_03_009 (Irony/Symbolism) — these nodes teach the device-effect reasoning that fills the Explanation slot.

## WORKED_EXAMPLE_1
PROBLEM: CBSE 2023-style question: "How does the poet use the imperative mood in 'nhi vosQyk' to convey urgency? Answer in 120-150 words."
STEPS:
- Step 1: Identify the question's core demand — analyze grammatical mood (imperative) and its thematic effect (urgency). This is a "how" question requiring device + effect analysis.
- Step 2: Recall/locate imperative forms in the poem: "ns nks" (give/accept) repeated as refrain, "HkfDr dks ns nks" (give to the farmer), "iafDr dks ns nks" (give to life). Note the progression from general to specific addressees.
- Step 3: Draft Point: "The poet employs the imperative mood not as command but as desperate plea, escalating urgency through refrain repetition."
- Step 4: Select Evidence: Quote "ij bldks Hkh iafDr dks ns nks" (stanza 1), "ftKklq] izcq¼] lnk J¼ke;] bldks HkfDr dks ns nks" (stanza 3). Explain: Imperative "ns nks" addresses life itself (stanza 1) then specific marginalized figures (farmer, laborer, woodcutter) — widening circle of appeal.
- Step 5: Link: This grammatical choice transforms the poem from description to activism — the urgency is moral, not syntactic. The refrain's insistence mirrors the poem's theme: small things *must* be accepted for life to be whole.
REASONING: The steps move from question decoding → textual hunting → thesis formation → evidence selection → device-effect analysis → thematic synthesis. This mirrors the examiner's marking rubric: 1 mark for point, 2 for evidence+explanation, 1 for link, 1 for language.
ANSWER: The poet uses the imperative mood ("ns nks" — give/accept) as a structural refrain to escalate urgency. In stanza 1, "ij bldks Hkh iafDr dks ns nks" addresses life universally. By stanza 3, "ftKklq] izcq¼] lnk J¼ke;] bldks HkfDr dks ns nks" directs the imperative at specific marginalized figures — the farmer, laborer, woodcutter. This widening address turns grammar into moral demand: the imperative is not syntactic decoration but ethical insistence. The repetition mimics a heartbeat — persistent, unavoidable. Ultimately, the mood conveys that accepting the "nhi" (small) is not optional; it is a condition for wholeness of "iafDr" (life).

## WORKED_EXAMPLE_2
PROBLEM: Comparative question: "Both poems celebrate resilience. Compare the *source* of resilience in 'nhi vosQyk' vs 'eSaus ns[kk] ,d cw¡n'." (Competency: Comparative Analysis)
STEPS:
- Step 1: Deconstruct the question — it asks for *source* of resilience (internal vs external? inherent vs earned?) in two poems. Requires a thesis that contrasts, not just lists.
- Step 2: Retrieve themes: "nhi vosQyk" — resilience comes from *acceptance* of small things by society/life ("iafDr esa 'kkfey dj yks"). "eSaus ns[kk] ,d cw¡n" — resilience comes from *innate vitality* of the small plant ("u'ojrk osQ nkx ls").
- Step 3: Draft Point: "In 'nhi vosQyk', resilience is relational — granted through acceptance; in 'eSaus ns[kk] ,d cw¡n', resilience is intrinsic — erupting from within the organism."
- Step 4: Evidence for Poem 1: "nhi lc oqQN gS] lkjs xq.k ,oa 'kfDr;k¡ mlesa gSa" — the small has full personhood; resilience depends on *others* recognizing it ("iafDr dks ns nks"). Evidence for Poem 2: "jax xbZ {k.kHkj <yrs lwjt dh vkx ls" — external hostility (lwjt) fails to kill; "u'ojrk osQ nkx ls" — growth springs from internal spark.
- Step 5: Explanation: Poem 1 uses social metaphor (nhi as marginalized human) — resilience needs *social justice*. Poem 2 uses biological metaphor (cw¡n as plant) — resilience is *ontological fact*.
- Step 6: Link: Both poems argue the small is powerful, but Varjik shifts from *demanding justice* (Poem 1) to *witnessing miracle* (Poem 2) — a deepening of his philosophy across the chapter.
REASONING: Comparative questions require a clear contrast thesis (Step 3), parallel evidence gathering (Step 4), and thematic synthesis (Step 6). The "source" lens forces analysis beyond surface similarity.
ANSWER: While both poems affirm the power of the small, their resilience sources differ fundamentally. In "nhi vosQyk", resilience is *socially conferred* — the nhi (small) possesses "lkjs xq.k ,oa 'kfDr;k¡" (all qualities and rights) but requires acceptance: "iafDr dks ns nks" (give it to life). The imperative refrain makes resilience a collective responsibility. In "eSaus ns[kk] ,d cw¡n", resilience is *biologically innate* — the cw¡n (small plant) withstands "lwjt" (dry wind) because "u'ojrk osQ nkx ls" (from the spark of novelty) it draws its force. No one "gives" it resilience; it erupts from within. Thus, Poem 1 demands justice for the marginalized; Poem 2 marvels at life's indomitable will. Varjik moves from advocacy to awe.

## WORKED_EXAMPLE_3
PROBLEM: CUET-style critical appreciation: "Critically appreciate the use of contrast in 'eSaus ns[kk] ,d cw¡n'." (Combines: device identification, effect analysis, structural awareness, thematic linking — 6 steps)
STEPS:
- Step 1: Define "contrast" in poetry — juxtaposition of opposites (big/small, harsh/gentle, dead/alive) to heighten meaning.
- Step 2: Map contrasts in the poem: (a) "lwjt" (dry wind, harsh, big force) vs "cw¡n" (small plant, gentle, fragile); (b) "fojkV~" (huge, proud, established) vs "cw¡n" (tiny, hidden, emergent); (c) "mUekspu" (fading, dying) vs "u'ojrk" (novelty, birth, rising).
- Step 3: Select strongest contrast for thesis: The central contrast is *scale* — "fojkV~ osQ lEeq[k" (huge tree's equality) vs the cw¡n's insignificance — yet the cw¡n *survives* where the tree might not.
- Step 4: Evidence & Explanation for scale contrast: "lwus fojkV~ osQ lEeq[k gj vkyksd&Nqvk viukiu gS mUekspu" — the huge tree's equal (the cw¡n) fades the tree's pride. Explanation: "mUekspu" (humbling) shows the small *defeats* the big not by force but by mere existence — irony of power.
- Step 5: Evidence & Explanation for vitality contrast: "jax xbZ {k.kHkj <yrs lwjt dh vkx ls" (color faded by dry wind) BUT "u'ojrk osQ nkx ls" (from spark of novelty). Explanation: The same hostile force (lwjt) that drains color *cannot* drain the "spark" — contrast between superficial damage and essential vitality.
- Step 6: Link to theme: These contrasts collectively prove the poem's argument: resilience is not about size or circumstance but about an inner "u'ojrk" (newness/spark) that transcends external "lwjt". The poem's structure *enacts* this — starting with visual smallness, ending with metaphysical largeness.
REASONING: Critical appreciation demands device mapping (Step 2), thesis selection (Step 3), multi-evidence analysis (Steps 4-5), and structural-thematic synthesis (Step 6). CUET rewards this depth; board exams reward Steps 1, 3, 4, 6.
ANSWER: Contrast is the poem's engine. The primary contrast — scale: "fojkV~" (huge tree) vs "cw¡n" (tiny plant) — is inverted when the cw¡n becomes "lEeq[k" (equal) to the tree, causing the tree's pride to "mUekspu" (fade/humble). This irony — the small humbling the big — redefines power. The secondary contrast — hostility vs vitality: "lwjt" (dry wind) strips "jax" (color) but cannot touch "u'ojrk osQ nkx" (spark of novelty). The wind is vast; the spark is microscopic — yet the spark wins. Structurally, the poem moves from visual contrast (Stanza 1: wall crack vs plant) to existential contrast (Stanza 2: fading vs spark). Thematically, contrast proves that resilience is not the absence of adversity but the presence of an inner "u'ojrk" that no "lwjt" can extinguish.

## COMPETENCY_QUESTION_1
QUESTION: A student writes this answer for "Analyze the symbol of 'cw¡n' in the second poem": "The cw¡n is a small plant that grows in a wall crack. It faces dry wind and loses color but still grows. This shows resilience. The poet likes it." Using the PEEL rubric, identify exactly which two components are missing and rewrite the answer to include them (80-100 words).
COMPETENCY: Analytical Writing / Rubric-Based Self-Correction
STEPS:
- Step 1: Map the student's sentences to PEEL: "The cw¡n is..." = Point (weak, descriptive not analytical). "It faces..." = Evidence (paraphrased, not quoted). "This shows resilience" = Link (present but vague). Explanation (device+effect analysis) is ABSENT. Quoted Evidence is ABSENT.
- Step 2: Formulate analytical Point: "The cw¡n symbolizes fragile life asserting its right to exist through innate vitality."
- Step 3: Insert quoted Evidence: "jax xbZ {k.kHkj <yrs lwjt dh vkx ls" and "u'ojrk osQ nkx ls".
- Step 4: Add Explanation: The imagery of "lwjt" (dry wind) as adversary and "u'ojrk" (novelty/spark) as internal force transforms the plant from victim to victor.
- Step 5: Sharpen Link: The symbol proves resilience is not endurance but eruption.
ANSWER: The cw¡n symbolizes fragile life asserting its right to exist through innate vitality. The poet writes, "jax xbZ {k.kHkj <yrs lwjt dh vkx ls" — the plant's color fades under the dry wind's heat, imagery of external oppression. Yet "u'ojrk osQ nkx ls" — from the spark of novelty — it draws unconquerable force. The contrast between "lwjt" (hostile circumstance) and "u'ojrk" (internal spark) reveals resilience not as passive endurance but as active eruption. Thus, the cw¡n becomes a metaphor for any marginalized existence that refuses erasure.
DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: "Varjik's two poems in this chapter present a dialectic: 'nhi vosQyk' demands social inclusion for the small; 'eSaus ns[kk] ,d cw¡n' demonstrates cosmic inevitability of the small's triumph." Write a 200-word response defending or challenging this reading using textual evidence from both poems. (Competency: Dialectical Thinking / Inter-Textual Synthesis)
COMPETENCY: Critical Synthesis / Argument Construction
STEPS:
- Step 1: Unpack the prompt's dialectic thesis: Poem 1 = social demand (inclusion); Poem 2 = cosmic fact (inevitability). Decide: largely accurate but "inevitability" overstates Poem 2 — the plant *could* die; its triumph is miraculous, not guaranteed.
- Step 2: Evidence for Poem 1 (social inclusion): Refrain "iafDr dks ns nks" addresses society/life; "nhi lc oqQN gS... fiQj Hkh iafDr dh rqyuk esa og ,d gS" — the small is complete but needs acceptance to fulfill its role.
- Step 3: Evidence for Poem 2 (cosmic vitality): "u'ojrk osQ nkx ls" — spark of novelty as cosmic force; "fojkV~ osQ lEeq[k" — small equals big in cosmic ledger. But note: "mUekspu" (humbling) is the tree's reaction, not the plant's guarantee.
- Step 4: Synthesize: The dialectic holds if we read Poem 1 as *ethics* (what we must do) and Poem 2 as *ontology* (what is). Varjik moves from "give it space" to "watch it claim space."
- Step 5: Nuance: The "spark" (u'ojrk) is fragile — "jax xbZ" (color faded) shows vulnerability. Triumph is not inevitable; it's a *miracle* witnessed. The dialectic is aspiration (Poem 1) meeting mystery (Poem 2).
ANSWER: The reading captures a vital trajectory but oversimplifies Poem 2 as "inevitable." In "nhi vosQyk," the nhi (small) is structurally complete — "lkjs xq.k ,oa 'kfDr;k¡ mlesa gSa" — yet socially invisible. The refrain "ij bldks Hkh iafDr dks ns nks" is a *demand for inclusion*: society must "give" the nhi its place in "iafDr" (life). Resilience here is a social contract. In "eSaus ns[kk] ,d cw¡n," the cw¡n's resilience is ontological — "u'ojrk osQ nkx ls" (from the spark of novelty) it draws a force that humbles even the "fojkV~" (huge tree): "lwus fojkV~ osQ lEeq[k gj vkyksd&Nqvk viukiu gS mUekspu." But "jax xbZ {k.kHkj <yrs lwjt dh vkx ls" reminds us: the plant *suffers*. Its color fades. Triumph is not inevitable; it is a witnessed miracle — "u'ojrk osQ nkx ls" (from the spark of novelty) suggests a mysterious, non-guaranteed vitality. The dialectic is real: Poem 1 cries for justice (ethical), Poem 2 reveals a deeper, wilder justice (cosmic). Varjik does not promise the small will win; he shows it *can* win, and demands we make room for that possibility.
DIFFICULTY: hard