## DEFINITION
Plot and narrative structure refers to the organized sequence of events (plot) and the technique used to arrange and present those events (narrative structure) in a literary work. In "Hkh'e lkguh," the narrative employs a non-linear, episodic structure where the author interweaves personal memoir, historical events, and embedded stories to explore themes of nationalism, human relationships, and the writer's craft.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student must be able to: (1) Map the chronological vs. narrative order of events in the chapter with specific textual references, and (2) Explain how the embedded narratives (the sparrow story, the v[kckj episode, the Quit India context) function structurally to develop the central theme of the writer's responsibility toward truth and nation.

## SCOPE_BOUNDARY
This node covers the plot progression and narrative architecture of "Hkh'e lkguh" — including the frame narrative, flashbacks, embedded stories, and temporal shifts. It does NOT cover character analysis (nodes 004-005), theme analysis (nodes 006-007), or literary devices (nodes 008-009), though it references them where they serve structural purposes.

## WALKTHROUGH
Imagine you're watching a film that keeps jumping between the present, the 1930s, and a folk tale — that's exactly what this chapter does. Start by asking: "What is the 'present moment' of the narrator?" (Hint: it's the writing desk, looking back). Then trace three distinct narrative threads: (1) the 1938 workplace memoir with xkaèkh, (2) the domestic episodes with usg: and the bird stories, and (3) the 1942 Quit India political frame. Notice how the author doesn't tell these in order — he circles back, using objects (the v[kckj, the sparrow story) as structural anchors. The key insight: the narrative structure *is* the argument — a writer's duty is to stitch fragmented experiences into a coherent witness of history.

## DIAGNOSTIC_QUESTION_1
Identify the three distinct time periods/locations that form the narrative framework of "Hkh'e lkguh" and state which one serves as the primary 'frame' (the present moment of narration).

## DIAGNOSTIC_ANSWER_1
The three time-frames are: (1) 1938 — lsokxzke workplace where the narrator meets xkaèkh, (2) Early 1940s — the narrator's home interactions with usg: th and family (including the v[kckj and sparrow story episodes), (3) August 1942 — the Quit India Movement period with ;kLlsj vjkI+kQkr. The primary frame is the **writing present** (implied late 1940s/50s) where the narrator sits at his desk recalling these episodes — evidenced by phrases like "mu fnuksa" (those days) and "yxHkx o"kZ ckn" (many years later). A wrong answer (e.g., naming 1938 as the frame) reveals the student confuses the *earliest chronological event* with the *narrative present* — a fundamental structural misunderstanding.

## DIAGNOSTIC_QUESTION_2
The chapter opens with the narrator visiting xkaèkh at lsokxzke in 1938, but the *second* paragraph jumps to a scene with usg: th and a child singing "eSa ej jgk gw¡". Explain why the author places this domestic scene immediately after the workplace introduction, rather than following chronological order.

## DIAGNOSTIC_ANSWER_2
The juxtaposition creates a **structural contrast** between the public/political world (lsokxzke, xkaèkh the journalist) and the private/domestic world (usg: th's home, the innocent child's song). The child's song — "eSa ej tkm¡Qxk, ckiw dks cqykvks" — foreshadows the Quit India slogan "Angrezon Bharat Chhodo" and the theme of fearless truth-telling. Placing it early signals that the personal/domestic is not separate from the political; the narrative structure enacts the theme: *the writer's voice emerges from the intersection of home and history*. A wrong answer (e.g., "it's just a memory") misses the deliberate *structural* function of foreshadowing and thematic framing.

## DIAGNOSTIC_QUESTION_3
The sparrow story (ck”khxj aur ekrk efj;e) is told *by usg: th* to the narrator *within* the narrative. Map the narrative levels: who is telling the story to whom, at what narrative level, and what structural purpose does this embedding serve?

## DIAGNOSTIC_ANSWER_3
**Narrative levels:** Level 1 (Primary) — Author Hkh'e lkguh narrates to reader. Level 2 (Embedded) — usg: th narrates the sparrow story to the narrator (and the gathered listeners). Level 3 (Meta) — The sparrow story itself contains a folk-tale logic. **Structural purpose:** The embedding creates a *mise en abyme* (story within story) where the sparrow's sacrifice for its mother mirrors the writer's duty to the motherland. It also characterizes usg: th as a *carrier of oral tradition* — contrasting with xkaèkh's print journalism. The story is placed *before* the 1942 Quit India section, structurally preparing the reader for the theme of sacrifice. A wrong answer that treats it as "just a story usg: told" misses the multi-level narrative architecture and its thematic mirroring.

## DIAGNOSTIC_QUESTION_4
Analyze the function of the v[kckj (bird) episode (pages 95-96). How does this episode serve as a **structural pivot** between the domestic narrative (usg: th's home) and the political narrative (Quit India, ;kLlsj vjkI+kQkr)?

## DIAGNOSTIC_ANSWER_4
The v[kckj episode operates as a **hinge** in three ways: (1) **Object as trigger** — the physical bird (v[kckj) gifted to usg: th becomes the catalyst for the narrator's memories of usg: th's emotional depth ("usg: th mrj jgs gSa"), moving from external observation to internal feeling. (2) **Parallel sacrifice** — just as the sparrow dies protecting its mother, usg: th's tears reveal his sacrifice for the nation; the bird *embodies* the sparrow story's lesson. (3) **Temporal bridge** — the episode ends with the narrator leaving for V~;wful (Delhi) to join the Quit India delegates ("V~;wful esa gh mu fnuksa ys[kd la?k dh if=kdk ^yksVl* dk laikndh; dk;kZy; gqvk djrk Fkk"). The bird is the last domestic image before the political plunge. A wrong answer focusing only on "the narrator liked the bird" misses the structural engineering of transition.

## DIAGNOSTIC_QUESTION_5
Evaluate the author's decision to end the chapter with ;kLlsj vjkI+kQkr's statement: "os vkiosQ gh ugha, gekjs Hkh usrk gSa. mrus gh vknj.kh; ftrus vkiosQ fy,A" — rather than ending with the narrator's own reflection. What does this structural choice imply about the *narrative authority* in the text?

## DIAGNOSTIC_ANSWER_5
Ending with ;kLlsj vjkI+kQkr's voice — not the narrator's — performs a **radical structural surrender of authority**. The narrator, a writer, steps back and lets the *revolutionary* speak the final truth: "They are not just yours, they are ours too. As much as they belong to you, they belong to us." This mirrors the chapter's central argument: the writer does not *own* history; the writer *witnesses* it on behalf of the collective. The narrative structure thus enacts its own theme — the memoir begins with "I" (the narrator's visit to xkaèkh) and ends with "We" (the revolutionary's inclusive claim). A wrong answer (e.g., "it's a nice quote to end on") fails to see that the *position* of the quote *is* the argument — the structure performs the politics.

## DIAGNOSTIC_QUESTION_6
Create a **narrative timeline diagram** for the chapter showing: (a) Chronological order of events (1938 → 1942 → writing present), (b) Narrative order (as presented in the text), and (c) Mark where each embedded story (sparrow story, v[kckj episode, usg: th's folk tales) attaches. Use this to explain why the author chose this specific non-linear arrangement.

## DIAGNOSTIC_ANSWER_6
**Expected diagram (verbal description acceptable):**
- **Chronological:** 1938 (lsokxzke/xkaèkh) → Early 1940s (usg: th's home, sparrow story told, v[kckj episode) → Aug 1942 (Quit India, ;kLlsj vjkI+kQkr, departure for Delhi) → Writing present (narration).
- **Narrative order:** Opens with 1938 → jumps to usg: th's home (sparrow story embedded) → v[kckj episode → 1942 Quit India frame → ends with ;kLlsj vjkI+kQkr's voice.
- **Embedded stories attach at:** Sparrow story — during usg: th's home scenes (before v[kckj]). v[kckj — at the threshold of 1942 departure. Folk tales — woven throughout usg: th sections.
**Why this arrangement?** The author uses **associative logic** (memory triggered by objects/people) not chronological logic. The sparrow story *prepares* the reader emotionally for the v[kckj sacrifice. The v[kckj *triggers* the political departure. The 1942 frame *recontextualizes* the earlier domestic scenes as prelude to revolution. The structure mimics how memory actually works — and how a writer *transforms* memory into history. A poor diagram (e.g., straight timeline) reveals the student hasn't grasped that **narrative structure ≠ chronological order**.

## COMMON_MISCONCEPTION
Students treat "plot" as "what happens in order" and "narrative structure" as "beginning, middle, end." In this chapter, they list events chronologically (1938 → 1942) and call it the plot, missing that the *narrative* deliberately fractures chronology: the sparrow story (told in 1940s) contains a folk-tale logic outside time; the v[kckj episode (1942) recalls 1938 emotions; the ending voice belongs to ;kLlsj vjkI+kQkr, not the narrator. They write: "The plot is the author meets xkaèkh, then usg: th, then Quit India happens." **Why this is wrong:** It confuses *fabula* (chronological story) with *syuzhet* (narrative discourse). The chapter's *meaning* is produced precisely by the gap between the two — e.g., placing the innocent child's song (1940s) right after the 1938 workplace scene creates ironic foreshadowing of 1942. Board exams ask: "How does the narrative structure reinforce the theme?" — not "List the events."

## ON_FAILURE
If the student cannot distinguish fabula from syuzhet: (1) Have them draw two parallel timelines on paper — one labeled "When it happened (Chronology)", one labeled "When it's told (Narrative)". (2) Plot 5 key events on each using textual markers (e.g., "1938 lsokxzke", "usg: th tells sparrow story", "v[kckj gift", "Quit India 1942", ";kLlsj vjkI+kQkr's final words"). (3) Ask: "Why does the text show the sparrow story *before* the v[kckj episode, even though both happen in the 1940s?" Guide them to see: sparrow story = *lesson*; v[kckj = *enactment* of lesson. (4) Re-diagnose with DIAGNOSTIC_QUESTION_3 — if they now explain the embedding levels, the concept has landed.

## BUILDS_ON
Class 11 "Text: Plot and Narrative Structure" nodes (c11_hin_ar_cbse_13_002) where students learned basic plot elements (exposition, rising action, climax) and linear vs. non-linear narrative — now applied to a complex memoir with embedded narratives and historical layering.

## LEADS_TO
Node c12_hin_a_cbse_13_003 (Setting and Atmosphere) — the temporal/spatial shifts mapped here become the settings analyzed there; Node c12_hin_a_cbse_13_006 (Primary Theme) — the structural choices explained here (e.g., ending with revolutionary's voice) are the *evidence* for thematic claims there.

## PREREQUISITE_NODE_IDS
c11_hin_ar_cbse_13_002, c12_hin_a_cbse_13_001

## PREREQUISITE_REASONS
c11_hin_ar_cbse_13_002: Class 11 Antra Chapter 13 Plot and Narrative Structure — provides foundational concepts of fabula/syuzhet, linear vs. non-linear narrative, and embedded narratives which this Class 12 node extends with greater complexity.
c12_hin_a_cbse_13_001: Before You Read: Context and Background — supplies the historical context (Quit India, ;kLlsj vjkI+kQkr, xkaèkh's journalism) essential for understanding why the narrative is structured around these specific events.
## FORWARD_NODE_IDS
c12_hin_a_cbse_13_003, c12_hin_a_cbse_13_006, c12_hin_a_cbse_13_013, c12_hin_a_cbse_13_004, c12_hin_a_cbse_13_005, c12_hin_a_cbse_13_007, c12_hin_a_cbse_13_008, c12_hin_a_cbse_13_010, c12_hin_a_cbse_13_012, c12_hin_a_cbse_13_014, c12_hin_a_cbse_13_015

## FORWARD_REASONS
c12_hin_a_cbse_13_003: Setting and Atmosphere — the temporal/spatial framework mapped in this node (1938 workplace, 1940s home, 1942 Delhi) provides the settings to be analyzed for atmosphere in the next node.
c12_hin_a_cbse_13_006: Theme: Primary Theme and Message — the structural analysis here (why the narrative ends with the revolutionary's voice, how embedded stories mirror themes) supplies the textual evidence for thematic interpretation.
c12_hin_a_cbse_13_013: Critical Thinking: Analysis and Interpretation — the narratological tools (frame narrative, mise en abyme, structural pivot) developed here are the analytical lens for higher-order critical questions.
c12_hin_a_cbse_13_004: Establishes plot structure — the three phases (early struggle, xkaèkh friendship, Varanasi conference) map to the protagonist's character arc.  
c12_hin_a_cbse_13_005: Plot structure knowledge tells students *when* each supporting character enters/exits, which frames their narrative weight.  
c12_hin_a_cbse_13_007: Plot knowledge needed to locate thematic evidence in narrative sequence.  
c12_hin_a_cbse_13_008: Plot knowledge tells *where* key descriptive passages occur (moonlit walk, crane story, bird scene).  
c12_hin_a_cbse_13_010: Narrative structure helps locate where key words appear.  
c12_hin_a_cbse_13_012: Plot structure knowledge allows locating events for literal retrieval and sequencing for inference.  
c12_hin_a_cbse_13_014: Provides plot structure knowledge needed to select relevant textual evidence for answers  
c12_hin_a_cbse_13_015: Plot understanding needed for discussion context and textual referencing  

## CROSS_SUBJECT_PREREQS
c11_hin_ar_cbse_13_002

## CROSS_SUBJECT_REASONS
c11_hin_ar_cbse_13_002: Class 11 Hindi Antra narrative structure analysis — establishes the metalanguage (exposition, climax, flashback, frame narrative) used in this node; without it, students lack the vocabulary to name structural moves.
c11_hin_v_cbse_13_002: Class 11 Hindi Vitan narrative structure — provides a second exposure to narrative analysis, reinforcing the skill across texts so students recognize patterns (e.g., embedded stories) as transferable concepts, not text-specific tricks.

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_13_002 -> c12_hin_a_cbse_13_002 -> c12_hin_a_cbse_13_003 (Plot structure enables setting analysis) and c12_hin_a_cbse_13_006 (Plot structure provides evidence for theme).

## THIS_FORMULA
N/A - conceptual

## FORMULA_VARIABLES
N/A

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
conceptual

## CROSS_SUBJECT
N/A | The 1942 Quit India frame in the narrative structure mirrors the historical timeline; understanding the movement's phases (spontaneous uprising, repression, underground leadership) explains why the chapter places ;kLlsj vjkI+kQkr's voice at the end — it reflects the shift from open protest to underground resistance.
 N/A | The narrative's structural journey from individual memory (1938) to collective voice (1942 revolutionary's "gekjs Hkh usrk gSa") enacts the civics concept of citizenship as *shared ownership of history* — the text structures itself as a pedagogical model of democratic memory.
## PREREQ_CONCEPT
Understanding the difference between *fabula* (chronological story events) and *syuzhet* (narrative presentation order) — and recognizing embedded narratives (stories within stories) as structural devices, not just content.

## PREREQ_BEFORE
Student must be able to identify: (1) the narrator's "present moment" of writing, (2) at least two distinct past time-periods referenced, and (3) one story told by a character *within* the narrative (embedded narrative).

## PREREQ_STUCK
If stuck, review Class 11 "Plot and Narrative Structure" (c11_hin_ar_cbse_13_002) — specifically the section on "Non-linear narratives and flashbacks" and the worked example analyzing a frame story.

## WORKED_EXAMPLE_1
PROBLEM: The chapter contains three major embedded narratives: (A) the sparrow story told by usg: th, (B) the v[kckj episode experienced by the narrator, (C) the folk tales told by usg: th about dk'ehj and tokgjyky. Map each to its narrative level (primary/secondary/tertiary), its temporal placement, and its structural function.

STEPS:
- Step 1: Identify the primary narrative level — the author Hkh'e lkguh writing in the present (post-1942) recalling events. This is Level 1 (frame narrator → reader).
- Step 2: Locate each embedded narrative in the text. (A) Sparrow story: usg: th tells it to narrator + listeners at his home (Level 2: character → character). (B) v[kckj episode: narrator experiences it directly at usg: th's home (Level 1 but as *scene*, not summary). (C) Folk tales: usg: th narrates stories of dk'ehj/tokgjyky to narrator (Level 2).
- Step 3: Determine temporal placement. Sparrow story and folk tales occur during early 1940s home visits. v[kckj episode occurs just before narrator leaves for Delhi (Aug 1942).
- Step 4: Analyze structural function. Sparrow story = thematic mirror (sacrifice for mother → sacrifice for motherland). Folk tales = cultural memory carrier (oral tradition vs. xkaèkh's print journalism). v[kckj = structural pivot (domestic → political).
- Step 5: Synthesize — the three embeddings create a *triangulation*: folk tradition (folk tales), domestic love (sparrow), political duty (v[kckj as trigger) — all converging on the writer's responsibility.

REASONING: This mapping reveals the narrative architecture: the author doesn't just "include stories" — he positions each embedding at a specific structural coordinate to build a layered argument about what a writer owes to history. The folk tales root the writer in tradition; the sparrow story gives the emotional logic of sacrifice; the v[kckj enacts the transition from private to public duty.

ANSWER: 
- Sparrow story: Level 2 (usg: th → narrator), early 1940s home, function = thematic foreshadowing of sacrifice.
- v[kckj episode: Level 1 (narrator's direct experience), Aug 1942 threshold, function = structural pivot from domestic to political.
- Folk tales: Level 2 (usg: th → narrator), early 1940s home, function = cultural counterpoint to colonial modernity (xkaèkh's journalism).

## WORKED_EXAMPLE_2
PROBLEM: The chapter opens with "mu fnuksa esjs HkkbZ cyjkt] lsokxzke esa jgrs Fks" (those days my elder brother cyjkt worked at lsokxzke) — but the *actual* opening scene is the narrator visiting xkaèkh. Explain this discrepancy and analyze what the "HkkbZ cyjkt" reference achieves structurally.

STEPS:
- Step 1: Note the grammatical subject — "esjs HkkbZ cyjkt" (my elder brother cyjkt) — but the *acting* consciousness is "eSa" (I, the narrator) who goes to meet xkaèkh.
- Step 2: Recognize the displacement — the brother is the *reason* the narrator is at lsokxzke ("muosQ lkFk fcrk ikus osQ fy, eSa muosQ ikl pyk x;k Fkk"), but the narrative focuses on xkaèkh.
- Step 3: Identify the structural role of HkkbZ cyjkt — he is a *threshold figure* who connects the narrator to xkaèkh (journalist) and later to the Quit India network (cyjkt is part of the delegation to Delhi).
- Step 4: Analyze the opening sentence's deictic anchoring — "mu fnuksa" (those days) immediately signals *retrospective narration* from a later present. The brother grounds the personal in the historical.
- Step 5: Evaluate the effect — the narrative begins not with "I" but with a relational anchor ("my brother"), structurally enacting the theme: the individual writer emerges from family, community, and history. The brother disappears after paragraph 1 but reappears in 1942 ("esjh iRuh osQ lkFk" — with my brother) — a structural bookending.

REASONING: The "discrepancy" is a deliberate narrative strategy. The opening sentence establishes *relationality* before *individuality* — the narrator enters the scene through his brother, just as the writer enters history through community. The brother's reappearance in the 1942 section (as part of the Quit India delegation) creates a structural symmetry: the personal connection that brought the narrator to xkaèkh in 1938 becomes the political connection that takes him to Delhi in 1942.

ANSWER: The reference to HkkbZ cyjkt is not a discrepancy but a structural anchor. It establishes: (1) the narrator's social embeddedness (brother, family), (2) the historical network (cyjkt links to xkaèkh and later to Quit India), (3) the retrospective stance ("mu fnuksa"). The brother functions as a structural bookend — present at the 1938 threshold and the 1942 departure — framing the narrator's journey from observer to participant.

## WORKED_EXAMPLE_3
PROBLEM: Compare the narrative structure of "Hkh'e lkguh" with a conventional linear autobiography. Identify three specific non-linear techniques used and explain how each serves the chapter's central concern: *the writer as witness to history*.

STEPS:
- Step 1: Define conventional linear autobiography — chronological birth-to-present, single narrative voice, causal continuity, author as protagonist.
- Step 2: Identify Technique 1 — **Frame narrative with retrospective narration**. The "present" of writing is never directly described; it's inferred from "yxHkx o"kZ ckn" (many years later). Effect: positions the writer as *looking back*, making the act of writing itself a historical act of witnessing.
- Step 3: Identify Technique 2 — **Associative/episodic organization** (not causal). The narrative moves by memory-association: xkaèkh → usg: th (via brother) → sparrow story (via usg: th) → v[kckj (via usg: th's emotion) → Quit India (via v[kckj as trigger). Effect: mimics how *memory preserves history* — not as a straight line but as a web of triggered recollections. The writer's duty is to map this web.
- Step 4: Identify Technique 3 — **Polyphonic ending** (narrative authority transferred to ;kLlsj vjkI+kQkr). The final words are not the narrator's reflection but the revolutionary's claim: "gekjs HKh usrk gSa." Effect: the writer *relinquishes* sole authorship of history; the narrative structure enacts *collective ownership* of the past.
- Step 5: Contrast with linear autobiography — a linear version would end with the narrator's insight ("I learned that..."). This structure ends with *someone else's truth* — the witness steps aside for the participant.
- Step 6: Synthesize — each non-linear technique (frame, association, polyphony) converts the memoir from "my life" into "our history," which is exactly the chapter's argument about the writer's role.

REASONING: This comparison works because it uses a familiar form (linear autobiography) as a foil to make the specific structural choices visible. The three techniques are not decorative — each directly serves the thematic argument about witnessing. Board exams often ask: "How does the form of the text reflect its content?" — this analysis answers that precisely.

ANSWER: Three non-linear techniques: (1) Retrospective frame narration — positions writing as historical witnessing. (2) Associative episodic structure — mimics memory's preservation of history as triggered fragments, not causal chain. (3) Polyphonic closure — transfers narrative authority to the revolutionary voice, enacting the writer's surrender of individual authorship to collective history. A linear autobiography centers the author; this structure decenters the author to center the history.

## COMPETENCY_QUESTION_1
QUESTION: A student writes: "The plot of 'Hkh'e lkguh' is simple — the author meets xkaèkh in 1938, then spends time with usg: th, then joins Quit India in 1942." Using your understanding of narrative structure, explain why this summary fails to capture the *narrative* of the chapter. Rewrite the summary to reflect the actual narrative structure (not just chronology).

COMPETENCY: Narrative analysis / Critical thinking — distinguishing fabula from syuzhet and articulating structural logic.

STEPS:
- Step 1: Identify the error — the student summarizes *chronological events* (fabula) but ignores *narrative presentation* (syuzhet): the frame, the embeddings, the non-linear order, the polyphonic ending.
- Step 2: List what's missing: (a) the retrospective writing frame, (b) the sparrow story and folk tales as embedded narratives, (c) the v[kckj as structural pivot, (d) the ending with ;kLlsj vjkI+kQkr's voice, (e) the associative logic connecting domestic and political.
- Step 3: Rewrite using narrative-structure language: "The narrative opens in the writing present, looking back to a 1938 workplace encounter that introduces the journalist xkaèkh. Through associative memory triggered by the narrator's brother, it shifts to domestic scenes with usg: th, where embedded folk tales (the sparrow story) establish a logic of sacrifice. A pivotal v[kckj episode bridges the domestic and the political, leading to the 1942 Quit India frame where the narrator joins a delegation. The narrative closes not with the author's reflection but with the revolutionary ;kLlsj vjkI+kQkr's assertion of collective ownership of history — structurally enacting the writer's role as witness, not owner."
- Step 4: Verify — does the rewrite mention frame, embedding, pivot, polyphony? Yes.

ANSWER: The student's summary describes *what happened* (fabula) but not *how it's told* (syuzhet). The narrative structure is defined by: a retrospective frame, associative/episodic organization, three embedded narratives (sparrow story, folk tales, v[kckj as lived episode), a structural pivot from domestic to political, and a polyphonic ending that transfers authority to the revolutionary voice. The rewrite above captures these structural dimensions.

DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: The CBSE 2023 sample paper asked: "How does the narrative structure of 'Hkh'e lkguh' reinforce the idea that a writer's responsibility is to *witness* rather than *interpret* history?" Using specific structural evidence (frame, embeddings, pivot, ending), write a 150-word answer following the PEEL structure (Point, Evidence, Explanation, Link).

COMPETENCY: Board exam answer writing / Textual evidence integration / Argument construction

STEPS:
- Step 1: Formulate the Point — The narrative structure *performs* witnessing by decentering the narrator's interpretive voice.
- Step 2: Select Evidence — (a) Retrospective frame ("yxHkx o"kZ ckn") positions narrator as looker-back, not maker-of-meaning. (b) Embedded sparrow story — usg: th *tells*, narrator *listens*; the story's meaning (sacrifice) is transmitted, not invented. (c) v[kckj pivot — narrator *receives* the bird and the emotion, doesn't orchestrate it. (d) Polyphonic ending — ;kLlsj vjkI+kQkr speaks the final truth ("gekjs HKh usrk gSa"), narrator is silent.
- Step 3: Explain each — The frame makes writing an act of retrieval. The embeddings show the narrator as *recipient* of tradition/history. The pivot shows the narrator *moved by* events, not controlling them. The ending silences the narrator to amplify the collective.
- Step 4: Link back — Together, these structural choices make the text itself a *witnessing act*: it records, transmits, and yields authority — exactly what the chapter argues a writer must do.
- Step 5: Polish to 150 words with clear PEEL paragraphs.

ANSWER: The narrative structure of 'Hkh'e lkguh' enacts the writer's duty as witness by systematically decentering the narrator's interpretive authority. **Point:** The text's architecture — frame, embeddings, pivot, and closure — positions the narrator as a receiver and transmitter of history, not its author. **Evidence:** The retrospective frame ("yxHkx o"kZ ckn") opens with the narrator looking back, making the act of writing a retrieval. The sparrow story and folk tales are embedded at Level 2 (usg: th → narrator), rendering the narrator a listener to oral tradition. The v[kckj episode functions as a structural pivot where the narrator is *given* a bird and *shown* usg: th's tears — he witnesses, he does not direct. **Explanation:** Each structural move refuses the narrator the role of meaning-maker. The frame makes him a chronicler; the embeddings make him a student of tradition; the pivot makes him a recipient of sacrifice; the polyphonic ending — ;kLlsj vjkI+kQkr's "gekjs HKh usrk gSa" — silences the narrator entirely, yielding the final word to the collective revolutionary voice. **Link:** Thus the narrative structure *is* the argument: a writer witnesses by structuring the text as a vessel for others' truths, not a platform for his own.

DIFFICULTY: hard