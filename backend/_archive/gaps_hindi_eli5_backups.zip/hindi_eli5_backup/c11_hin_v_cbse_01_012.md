## DEFINITION
Literal comprehension questions require students to retrieve information explicitly stated in the text, while inferential comprehension questions demand logical deductions based on textual evidence, context, and prior knowledge. At the senior secondary level, this distinction involves identifying the author's stated facts versus implied meanings, attitudes, or thematic undercurrents.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student can independently classify a given question as literal or inferential, locate precise textual evidence for literal answers, and construct a justified inference with at least two pieces of supporting evidence from the text for inferential answers, using appropriate Hindi terminology (प्रत्यक्ष/अप्रत्यक्ष, स्पष्ट/निहित).

## SCOPE_BOUNDARY
This node covers the identification and answering of literal and inferential questions based on the chapter "Hkkjrh; xkf;dkvksa esa cstksM+µyrk eaxs'kdj". It does NOT cover critical evaluation (node 013), creative writing (node 014), or oral discussion (node 015), nor does it address poetic devices or grammar rules in isolation.

## WALKTHROUGH
Imagine you are reading a WhatsApp forward claiming "Yashodhar's art caused a revolution." Your first instinct is to check: does the text actually say that, or is it an interpretation? That is the core of literal vs. inferential comprehension. Begin by reading the question and underlining keywords (कौन, क्या, कब, क्यों, कैसे). Next, scan the text for those exact words or synonyms — if found, it's literal. If the question asks for reason, effect, or author's stance, you must connect multiple sentences, note tone words (जैसे 'मेरा मानना है', 'लगता है'), and synthesize an answer not directly written. Practice with the textbook's end-of-chapter exercises, labeling each question type before answering. The key insight: literal answers are *in* the text; inferential answers are *between* the lines, built from textual clues.

## DIAGNOSTIC_QUESTION_1
What is the primary difference between a literal comprehension question and an inferential comprehension question in the context of this chapter?

## DIAGNOSTIC_ANSWER_1
A literal question asks for information directly stated in the text (e.g., "What name was given to the painter's art?"), while an inferential question requires drawing a conclusion based on textual evidence (e.g., "Why does the author consider Yashodhar's art revolutionary?"). A wrong answer that merely quotes a sentence for an inferential question reveals the student cannot distinguish between explicit statement and implied meaning.

## DIAGNOSTIC_QUESTION_2
The text states: "चित्रकला के कारण जनमानस की दृष्टि और चिंतन में परिवर्तन आया।" If a question asks, "How did visual art affect common people's thinking?", is this literal or inferential? Explain your reasoning.

## DIAGNOSTIC_ANSWER_2
This is a literal question because the answer is explicitly stated in the quoted sentence: it changed people's vision and thought. A student who labels it inferential likely confuses "effect" language with inference, not realizing the text directly asserts the causal relationship.

## DIAGNOSTIC_QUESTION_3
Based on the passage, answer: "Why did the author feel that Yashodhar's sounds (words) had a 'music' that merged two words into one?" Provide a step-by-step inference using at least two textual clues.

## DIAGNOSTIC_ANSWER_3
Step 1: Locate the reference — the author describes Yashodhar's speech where the gap between two words is bridged by sound-symbolism (ध्वनि-प्रतीक). Step 2: Note the author's observation that this creates a sense of the words merging (फोयहु गकर्स गकर्स, एक नवल्ज् एसा फेय त्कर्स गसा). Step 3: Infer that this 'music' arises from Yashodhar's unique use of sound to collapse semantic distance, reflecting his artistic philosophy of unity. A wrong answer that only quotes the line without explaining the merging effect shows inability to synthesize clues.

## DIAGNOSTIC_QUESTION_4
Compare the author's view of traditional (श्रव्य) art and visual (चित्रकला) art in the chapter. Which type of question — literal or inferential — would best elicit this comparison, and why?

## DIAGNOSTIC_ANSWER_4
An inferential question (e.g., "How does the author contrast the impact of traditional and visual art?") is needed because the contrast is scattered across paragraphs and never summarized in a single statement. The student must analyze multiple passages: traditional art's reliance on sound/rule vs. visual art's immediate sensory appeal. A literal question would only retrieve isolated facts, missing the comparative relationship.

## DIAGNOSTIC_QUESTION_5
Evaluate this student's answer to an inferential question: "The author says visual art is superior because it reaches more people." Is this a valid inference? Justify using the text.

## DIAGNOSTIC_ANSWER_5
No, it is not fully valid. The author acknowledges visual art's wider reach but explicitly states that traditional art has its own irreplaceable depth ("श्रव्य कला भी जातीय न हो तो फीकी ही रह जायगी"). The student oversimplifies by ignoring the author's nuanced stance that both have distinct, equally valuable roles. This error reveals a tendency to infer a hierarchy where the text presents complementarity.

## DIAGNOSTIC_QUESTION_6
Create an inferential question based on the last paragraph of the chapter (page 7-8) that requires the examinee to connect the artist's emotional state to the broader theme of art's social role. Provide the expected answer outline.

## DIAGNOSTIC_ANSWER_6
Question: "The author ends with 'कितना बड़ा है हमारा हृदय!' — what does this exclamation reveal about the relationship between the artist's inner world and society?" Expected answer: The artist's expanded heart mirrors art's capacity to encompass collective joy/sorrow; the personal becomes universal. A poor answer would treat it as a literal comment on heart size, missing the metaphorical link to art's social function.

## COMMON_MISCONCEPTION
Students often believe that any question starting with "Why" or "How" is automatically inferential, and any "What/Who/When" question is literal. In this chapter, the author directly states reasons (e.g., "चित्रकला के कारण..."), making some "Why" questions literal. Conversely, a "What" question like "What is the significance of Yashodhar's three paintings?" requires inferring thematic significance from description. This misconception arises from relying on question words rather than checking whether the answer is explicitly written or must be constructed.

## ON_FAILURE
1. Give the student a mixed list of 10 questions from the chapter exercises. 2. Ask them to highlight the exact sentence(s) that answer each question. 3. For questions where no single sentence contains the full answer, guide them to list the 2-3 sentences they must combine. 4. Have them label each question "प्रत्यक्ष" (literal) or "निहित" (inferential) based on whether the answer was found in one sentence or built from multiple. 5. Repeat with a fresh text until they consistently distinguish by evidence location, not question word.

## BUILDS_ON
This node builds on the student's ability to locate explicit information in the text (covered in nodes 001-005) and understand vocabulary in context (node 010).

## LEADS_TO
This node enables critical thinking (node 013) where students evaluate interpretations, and writing skills (node 014) where they must embed textual evidence in structured answers.

## PREREQUISITE_NODE_IDS
c11_hin_v_cbse_01_001, c11_hin_v_cbse_01_002, c11_hin_v_cbse_01_003, c11_hin_v_cbse_01_004, c11_hin_v_cbse_01_005, c11_hin_v_cbse_01_006, c11_hin_v_cbse_01_007, c11_hin_v_cbse_01_008, c11_hin_v_cbse_01_009, c11_hin_v_cbse_01_010, c11_hin_v_cbse_01_011
## PREREQUISITE_REASONS
c11_hin_v_cbse_01_001: Provides background context needed to understand references in comprehension questions.
c11_hin_v_cbse_01_002: Plot knowledge allows locating events for literal questions.
c11_hin_v_cbse_01_003: Setting/atmosphere details are often the basis for inferential mood questions.
c11_hin_v_cbse_01_004: Protagonist analysis supplies character-based evidence for inference.
c11_hin_v_cbse_01_005: Supporting characters' roles are frequently tested in comparative inferential questions.
c11_hin_v_cbse_01_006: Primary theme is the anchor for higher-order inferential questions.
c11_hin_v_cbse_01_007: Secondary themes provide material for multi-theme inference.
c11_hin_v_cbse_01_008: Imagery/metaphor recognition is essential for inferring author's craft.
c11_hin_v_cbse_01_009: Irony/symbolism detection underpins subtle inferential questions.
c11_hin_v_cbse_01_010: Vocabulary in context prevents misreading key terms in questions.
c11_hin_v_cbse_01_011: Grammar awareness helps parse complex sentences for literal retrieval.

## FORWARD_NODE_IDS
c11_hin_v_cbse_01_013, c11_hin_v_cbse_01_014, c11_hin_v_cbse_01_015, c12_hin_a_cbse_04_012, c12_hin_a_cbse_06_012, c12_hin_al_cbse_02_012, c12_hin_ar_cbse_09_012, c12_hin_v_cbse_01_012, c12_hin_v_cbse_02_012

## FORWARD_REASONS
c11_hin_v_cbse_01_013: Critical thinking requires the ability to distinguish stated vs. implied ideas as a foundation for analysis.
c11_hin_v_cbse_01_014: Writing skills demand embedding both direct quotes (literal) and synthesized inferences in answers.
c11_hin_v_cbse_01_015: Speaking/listening discussions rely on participants citing textual evidence (literal) and offering interpretations (inferential).
c12_hin_a_cbse_04_012: Class 11 Vitan comprehension node provided practice with prose inference; this node transfers those skills to poetry.  
c12_hin_a_cbse_06_012: Class 11 Vitan comprehension foundation for non-fiction text strategies.  
c12_hin_al_cbse_02_012: Vitan Chapter 1 comprehension skills transfer to Antara texts.  
c12_hin_ar_cbse_09_012: Transfers skill to prose (Vitan), showing genre independence.  
c12_hin_v_cbse_01_012: Class 11 comprehension foundation — literal/inferential distinction was introduced there; this node deepens it with Class 12 text complexity.  
c12_hin_v_cbse_02_012: Prior practice with literal/inferential distinction in Vitan.  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
none

## CHAIN_DESCRIPTION
c11_hin_v_cbse_01_002 -> c11_hin_v_cbse_01_012 -> c11_hin_v_cbse_01_013

## THIS_FORMULA
N/A - conceptual

## FORMULA_VARIABLES
N/A

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
conceptual

## CROSS_SUBJECT
c11_history_art_movements | Understanding the historical shift from traditional to modern art in India provides context for the chapter's discussion of visual vs. auditory art, aiding inferential questions about societal impact.
c11_geography_cultural_landscapes | The chapter references regional art forms and their evolution; geographical awareness of cultural diffusion helps infer why visual art gained wider reach.

## PREREQ_CONCEPT
The student must be able to independently navigate the chapter text to locate specific paragraphs, sentences, and keywords.

## PREREQ_BEFORE
The student should have read the entire chapter at least once and completed the basic plot/character/theme nodes (001-007).

## PREREQ_STUCK
If stuck, review node c11_hin_v_cbse_01_002 (Plot and Narrative Structure) to refresh the sequence of events and key details.

## WORKED_EXAMPLE_1
PROBLEM: Answer the following question from the chapter: "लेखक ने चित्रकला को 'लोकहितकारी' क्यों कहा है?" (Why has the author called visual art 'beneficial to the people'?) Classify the question type and answer with evidence.

STEPS:
- Step 1: Identify the question word "क्यों" (why) — but do not assume inferential; check if the reason is explicitly stated.
- Step 2: Scan the text for the phrase "लोकहितकारी" or synonyms like "लोगों के हित में". Find the sentence: "चित्रकला ने लोगों की दृष्टि बदल दी..." and surrounding lines listing concrete effects (awakening social consciousness, reaching illiterate masses).
- Step 3: Since the author directly enumerates the benefits (changed vision, awakened consciousness, reached common people), the answer is explicitly spread across 2-3 sentences — this is a literal question requiring synthesis of explicit points.
- Step 4: Compile the answer: The author calls visual art लोकहितकारी because it (1) changed common people's perspective, (2) awakened social and political consciousness, and (3) reached even the illiterate, unlike traditional art which was limited to elites.
- Step 5: Verify each point has a direct textual reference; no interpretation beyond the text is needed.

REASONING: This example demonstrates that "why" questions can be literal if the author provides explicit reasons. The steps train the student to verify evidence location before classifying.

ANSWER: Question type: Literal (प्रत्यक्ष). Answer: लेखक ने चित्रकला को लोकहितकारी इसलिए कहा क्योंकि उसने जनमानस की दृष्टि और चिंतन बदला, सामाजिक-राजनीतिक चेतना जगाई, और निरक्षर जनता तक कला को पहुँचाया — ये सभी बातें पाठ में स्पष्ट लिखी हैं।

## WORKED_EXAMPLE_2
PROBLEM: "पाठ के आधार पर बताइए कि लेखक पारंपरिक (श्रव्य) कला और चित्रकला में से किसे श्रेष्ठ मानते हैं? अपने उत्तर के पक्ष में दो तर्क दीजिए।" (Based on the text, which art does the author consider superior? Give two arguments.)

STEPS:
- Step 1: Recognize the question asks for the author's stance (superiority) — this is not directly stated as a comparison; it requires inference.
- Step 2: Locate all passages where the author evaluates both arts. Note: Page 4-5 discusses traditional art's depth and discipline; page 6-7 praises visual art's reach and immediacy; page 7 concludes they are complementary ("दोनों का... समान मूल्य").
- Step 3: Synthesize: The author does NOT declare one superior; they argue for equal but distinct value. The inference is that the premise of the question (that one is superior) is flawed per the text.
- Step 4: Formulate answer: The author considers neither superior; they are complementary. Argument 1: Traditional art provides cultural depth and disciplined expression (page 4: "श्रव्य कला भी जातीय न हो तो फीकी ही रह जायगी"). Argument 2: Visual art democratizes art and awakens mass consciousness (page 6: "चित्रकला ने लोगों के दुःख दूर किए").
- Step 5: Check that both arguments are textually grounded and together refute the superiority claim.

REASONING: This example shows an inferential question where the correct answer contradicts the question's assumption, requiring the student to infer the author's nuanced position from multiple non-adjacent passages.

ANSWER: Question type: Inferential (निहित). Answer: लेखक किसी को श्रेष्ठ नहीं मानते; दोनों पूरक हैं। तर्क 1: पारंपरिक कला सांस्कृतिक गहराई और अनुशासित अभिव्यक्ति देती है (पृष्ठ 4)। तर्क 2: चित्रकला जनमानस तक पहुँचकर चेतना जगाती है (पृष्ठ 6)।

## WORKED_EXAMPLE_3
PROBLEM: A board-style question: "‘चित्रकला ने जनमानस के दुःख हर लिए’ — इस कथन का आशय स्पष्ट कीजिए। क्या यह कथन लेखक का प्रत्यक्ष कथन है या निहित निष्कर्ष? कारण सहित बताइए।" (Explain the meaning of this statement. Is it the author's direct statement or an implied conclusion? Give reasons.)

STEPS:
- Step 1: Locate the exact phrase or its close variant in the text. Found on page 6: "चित्रकला ने लोगों के दुःख दूर किए..." — the wording is slightly different but the sentiment is directly expressed.
- Step 2: Determine question type: The first part ("आशय स्पष्ट कीजिए") asks for explanation of a direct statement — literal. The second part asks to classify the statement's nature — meta-comprehension.
- Step 3: For the explanation, expand using context: Visual art depicted suffering (famine, exploitation) making it visible, which stirred empathy and reform — all explicitly described in the preceding lines.
- Step 4: For classification: It is a direct statement (प्रत्यक्ष कथन) because the author writes it as a factual claim in the narrative, not as a character's opinion or a subtle suggestion.
- Step 5: Provide reason: The sentence appears in the author's own voice ("चित्रकला ने...") without hedging words like "लगता है" or "शायद", and is supported by immediately following examples (photographs of famine, etc.).
- Step 6: Structure final answer: Meaning + Classification + Reason.

REASONING: This multi-part question tests both comprehension and meta-awareness of literal vs. inferential nature of a specific textual claim, mirroring board exam pattern.

ANSWER: आशय: चित्रकला ने सामाजिक पीड़ाओं (अकाल, शोषण) को दृश्य रूप देकर जनचेतना जगाई और सुधार की प्रक्रिया आरंभ की। वर्गीकरण: यह लेखक का प्रत्यक्ष कथन है। कारण: लेखक ने इसे अपनी ओर से तथ्यात्मक वाक्य के रूप में प्रस्तुत किया है ("चित्रकला ने लोगों के दुःख दूर किए"), कोई संकेत या संभावना नहीं व्यक्त की, और तुरंत बाद उदाहरण दिए हैं।

## COMPETENCY_QUESTION_1
QUESTION: Read the following excerpt from the chapter (not reproduced here): "वर्षों तक चित्रकला को केवल सजावट की वस्तु समझा जाता रहा। किंतु यशोधर ने सिद्ध किया कि वह समाज का दर्पण भी हो सकती है।" Based on the chapter, explain how Yashodhar's three paintings function as a 'mirror of society'. Your answer must reference at least two specific paintings and the social issue each reflects.

COMPETENCY: Textual evidence synthesis and thematic inference

STEPS:
- Step 1: Recall the three paintings described in the chapter (e.g., famine, exploitation, awakening).
- Step 2: For each painting, identify the specific social issue depicted (e.g., famine -> colonial neglect; exploitation -> feudal oppression).
- Step 3: Connect the visual details mentioned in the text (e.g., "सूखे हुए खेत", "जमींदार का कोड़ा") to the broader social reality.
- Step 4: Synthesize: Show how collectively they reflect a society in transition, fulfilling the 'mirror' metaphor.
- Step 5: Write a structured answer with topic sentence, evidence for two paintings, and concluding link to the metaphor.

ANSWER: Yashodhar's paintings mirror society by depicting concrete injustices. First, the famine painting shows parched fields and skeletal farmers, reflecting British colonial policies that caused starvation. Second, the exploitation painting portrays a landlord's whip over peasants, mirroring feudal oppression. Together, they make invisible suffering visible, forcing viewers to confront social realities — thus acting as a mirror.

DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: The author states: "श्रव्य कला और चित्रकला में प्रतिद्वंद्विता नहीं, पूरकता है।" (There is no rivalry but complementarity between auditory and visual art.) Using evidence from the chapter, evaluate this claim by analyzing one strength and one limitation of each art form as presented by the author. Conclude whether the author's claim is fully justified.

COMPETENCY: Critical evaluation of author's argument with balanced textual evidence

STEPS:
- Step 1: Identify the author's explicit claim of complementarity (page 7).
- Step 2: Extract strengths/limitations for auditory art: Strength — cultural depth, disciplined tradition (page 4); Limitation — limited reach, requires trained listener (page 3: "सामान्य जन... नहीं समझ पाते").
- Step 3: Extract strengths/limitations for visual art: Strength — immediate mass communication, awakens consciousness (page 6); Limitation — risk of superficiality, commercialization (page 7: "चित्रकला का क्षेत्र... व्यावसायिक हो गया").
- Step 4: Assess complementarity: Do the limitations of one align with strengths of the other? Yes — auditory art's depth compensates for visual art's potential superficiality; visual art's reach compensates for auditory art's elitism.
- Step 5: Conclude: The claim is justified but with a caveat — the author warns that visual art's commercialization may erode its social role, threatening the balance.

ANSWER: The claim is largely justified. Auditory art offers depth/discipline but lacks mass reach; visual art offers reach/immediacy but risks superficiality. Their limitations are mutually offsetting, supporting complementarity. However, the author cautions that visual art's commercial turn may undermine this balance, so the complementarity is conditional on visual art retaining its social purpose.

DIFFICULTY: hard