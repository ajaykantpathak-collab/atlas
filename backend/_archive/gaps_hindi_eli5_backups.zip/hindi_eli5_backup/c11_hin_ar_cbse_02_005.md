## DEFINITION
Character analysis of supporting characters examines how secondary figures function in a narrative — their distinct roles, relationships with the protagonist, contribution to thematic development, and how their contrasts or parallels illuminate the central character's traits and the story's core conflicts.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
Student can identify at least three supporting characters from 'Fe;k¡ ulh#íhu', explain each one's narrative function with specific textual evidence, and analyze how they collectively reveal the protagonist's philosophy and the story's critique of literacy-based hierarchy.

## SCOPE_BOUNDARY
Covers analysis of all characters except the protagonist (fe;k¡ ulh#íhu) in Chapter 2. Includes: 'kkgh ukuckbZ fe;k¡ dYyu, flj fgykuk, ehj lkfgc, ckn'kkg lyker, okfyn ejgwe, nknk, v[kckjuohl. Does not cover plot structure, setting, or primary themes in isolation — only as they emerge through supporting characters.

## WALKTHROUGH
Think about your favorite film — the hero never exists in isolation. The best friend, the antagonist, the mentor, the bureaucrat — each holds up a mirror that makes the hero's qualities visible. In 'Fe;k¡ ulh#íhu', the tailor's wisdom shines brighter because the clerk (ckn'kkg lyker) embodies rigid bureaucracy, the woman (flj fgykuk) represents practical modernity, and the father (okfyn ejgwe) anchors him in craft tradition. To begin, list every character who speaks or acts besides the tailor. Then ask: what does this character WANT? What do they FEAR? How does the tailor respond to them? The key insight: supporting characters are not background — they are thematic arguments in human form.

## DIAGNOSTIC_QUESTION_1
List three supporting characters from 'Fe;k¡ ulh#íhu' and state their primary narrative role in one sentence each.

## DIAGNOSTIC_ANSWER_1
Correct answer: (1) ckn'kkg lyker — the bureaucratic clerk who demands written identity, representing state power and literacy-based authority; (2) flj fgykuk — the pragmatic woman who initiates the identity inquiry and pushes for official documentation, embodying societal pressure for paper-based existence; (3) 'kkgh ukuckbZ fe;k¡ dYyu — the illiterate tailor double who shares the protagonist's profession but lacks his philosophical articulation, serving as a thematic mirror. A wrong answer that only lists names without functions reveals the student sees characters as plot devices rather than thematic instruments.

## DIAGNOSTIC_QUESTION_2
Explain how the clerk (ckn'kkg lyker) and the woman (flj fgykuk) differently represent the modern bureaucratic world's challenge to the tailor's oral identity.

## DIAGNOSTIC_ANSWER_2
Correct answer: The clerk represents institutional power — he wields the state's authority to demand "ckOkQj[kkuh&'khjeky&rkI+kQrku&csluh&[kehjh&:ekyh&xko&nhnk&xk"kscku&rqudh" (official records, verification, inquiry, investigation, etc.), threatening consequences for non-compliance. The woman represents social pressure — she initiates the questioning ("vkidks bu nksuksa esa ls fdlh dh Hkh dksbZ ulhgr ;kn gks!"), demands the father's name for records, and pushes the tailor toward the clerk. The clerk is the SYSTEM; the woman is the CITIZEN who internalizes the system's demands. A wrong answer that treats them as identical "villains" misses the crucial distinction between state coercion and social complicity.

## DIAGNOSTIC_QUESTION_3
The journalist (v[kckjuohl) asks the tailor for a "new angle" (ubZ ph"k) on his life. Based on the tailor's responses to the clerk and the woman, predict how he would respond to the journalist's request and explain your reasoning.

## DIAGNOSTIC_ANSWER_3
Correct answer: The tailor would reject being made into a "story" or "angle" — just as he refused to perform literacy for the clerk ("ge crZu èkksuk u lh[krs / ge Hkêòh cukuk u lh[krs") and redirected the woman's practical questions toward philosophy ("vfyI+kQ, cs, the" as life lessons). He would likely say: "dksbZ ,slh ph"k cukvks tks u vkx ls iosQ] u ikuh ls cus" (create something that comes from neither outside nor inside), refusing to be an object of literary consumption. Steps: (1) Recall tailor's resistance to external definitions; (2) Note his pattern of transforming others' questions into his own teachings; (3) Apply this pattern to the journalist's extractive request; (4) Conclude he would subvert the interview into a lesson on authentic creation. A wrong answer predicting compliance shows misunderstanding of the tailor's consistent agency.

## DIAGNOSTIC_QUESTION_4
Compare how the father (okfyn ejgwe) and the uncle (nknk) function as contrasting models of lineage. What does the tailor's selective claiming of the father but rejection of the uncle reveal about his philosophy of identity?

## DIAGNOSTIC_ANSWER_4
Correct answer: The father is claimed as "okfyn lkfgc e'kgwj Fks fe;k¡ cjOkQr 'kkgh ukuckbZ x<+S;kokys osQ uke ls" — he passed down the CRAFT (tailoring) and the identity of "illiterate tailor" as honorable work. The uncle is rejected when "cksyh osQ mB tkus ij vk cSBs mUgha osQ Bh;s ij" — the tailor physically moves away from the uncle's status-based legacy. This reveals the tailor's philosophy: identity is EARNED through skilled labor (father's legacy), not INHERITED through name or position (uncle's legacy). It enacts his statement "ge Hkêòh cukuk u lh[krs" (we don't create artificial identities). A wrong answer seeing both as "family members" misses the story's central argument: true lineage is craft mastery, not blood.

## DIAGNOSTIC_QUESTION_5
Evaluate whether the journalist (v[kckjuohl) functions primarily as a plot device to advance the narrative or as a thematic mirror reflecting the reader's own position. Justify with textual evidence.

## DIAGNOSTIC_ANSWER_5
Correct answer: The journalist is a thematic mirror for the reader, not merely a plot device. Evidence: He enters seeking "ubZ ph"k" (new angle) on the illiterate tailor — exactly what a reader does when approaching this story. The tailor's response "dksbZ ,slh ph"k cukvks tks u vkx ls iosQ] u ikuh ls cus" addresses the journalist AND the reader: true understanding comes from neither external observation nor internal projection, but from lived engagement. The journalist's brief wonder ("D;k muls cuh ,slh ph"k!") mirrors the reader's potential awakening. If he were only a plot device, his exit would resolve something; instead, his presence implicates the act of reading itself. A wrong answer calling him "minor character" ignores the meta-fictional layer central to Ñ".kk lkscrh's craft.

## DIAGNOSTIC_QUESTION_6
Write a 4-line dialogue between the tailor (fe;k¡ ulh#íhu) and a NEW supporting character — a young village schoolteacher — that reveals the tailor's philosophy on learning without using the words "literacy," "education," or "school."

## DIAGNOSTIC_ANSWER_6
Criteria for a strong answer: (1) Teacher speaks from institutional knowledge; (2) Tailor responds from experiential wisdom; (3) Contrast emerges naturally; (4) Tailor's philosophy shines through metaphor, not declaration. Example: Teacher: "Babuji, bachchon ko akshar sikhana zaroori hai." Tailor: "Betā, akshar to pathar par bhi likhe milte hain — lekin us pathar ne kabhi kisi ka haath nahin thama." Teacher: "Par likhna na aaye to duniya kaise samjhoge?" Tailor: "Jisne apne kaam ki baariqi samjhi, usne poori duniya ki siraahi samajh li." A poor answer has the tailor sound defensive or the teacher sound villainous — missing the story's nuance where both worlds exist but operate on different logics.

## COMMON_MISCONCEPTION
Students treat supporting characters as "background information" and list their actions (he asked for name, she made tea, he wrote report) without analyzing their NARRATIVE FUNCTION. They confuse "what the character does" with "what the character REPRESENTS." For example, noting that the clerk demands the tailor's father's name but missing that this exposes the bureaucratic reduction of identity to patrilineal paperwork — a direct assault on the tailor's philosophy that identity is crafted through work ("ge Hkêòh cukuk u lh[krs"). This error persists because Class 10 trained students to answer "who did what" questions; Class 11 demands "why does this character exist in the story's architecture?"

## ON_FAILURE
If a student lists actions without analysis: (1) Pick ONE supporting character — say, the clerk. (2) Find TWO specific dialogues he speaks. (3) Ask: "What does this REVEAL about the tailor OR about the society the tailor lives in?" (4) Write one sentence starting: "This character serves as a mirror for ______ because ______." (5) Repeat for two more characters. Do not proceed until each character has a "mirror statement" backed by a quote.

## BUILDS_ON
Character Analysis: Protagonist (c11_hin_ar_cbse_02_004)

## LEADS_TO
Theme: Primary Theme and Message (c11_hin_ar_cbse_02_006)

## PREREQUISITE_NODE_IDS
c11_hin_ar_cbse_02_001, c11_hin_ar_cbse_02_002, c11_hin_ar_cbse_02_004
## PREREQUISITE_REASONS
c11_hin_ar_cbse_02_001: Context/background knowledge needed to understand character motivations and historical setting (colonial bureaucracy, oral tradition)
c11_hin_ar_cbse_02_002: Plot structure knowledge required to place each supporting character's interventions in narrative sequence and causal chain
c11_hin_ar_cbse_02_004: Protagonist analysis must be completed first — supporting characters are defined by their contrast/parallel to the main character's established traits

## FORWARD_NODE_IDS
c11_hin_ar_cbse_02_006, c11_hin_ar_cbse_02_007, c11_hin_ar_cbse_02_013, c11_hin_ar_cbse_02_015, c12_hin_a_cbse_01_005, c12_hin_a_cbse_02_005, c12_hin_a_cbse_12_005, c12_hin_al_cbse_01_005, c12_hin_ar_cbse_02_005, c12_hin_ar_cbse_06_005

## FORWARD_REASONS
c11_hin_ar_cbse_02_006: Supporting characters embody thematic conflicts (tradition vs modernity, oral vs written, craft vs credential) that constitute the primary theme
c11_hin_ar_cbse_02_007: Secondary themes (dignity of labor, resistance through silence, identity as performance) emerge through supporting character arcs
c11_hin_ar_cbse_02_013: Critical interpretation requires a complete character map to analyze how the author constructs meaning through ensemble
c11_hin_ar_cbse_02_015: Supporting characters (professor, child, narrator) provide the polyvocal perspectives required for Diagnostic Q6's role-play.  
c12_hin_a_cbse_01_005: Class 11 Antra Chapter 2 provided practice with dual-voice structures (similar to nsolsuk/dkusZfy;k contrast) in a different historical setting.  
c12_hin_a_cbse_02_005: Class 11 foundation for analysing supporting characters in Hindi poetry.  
c12_hin_a_cbse_12_005: अगला तार्किक चरण: Supporting character analysis examines how secondary characters in a narrative — through their disti... इस नोड की अवधारणाओं को सीधे उपयोग/विस्तारित करता है।  
c12_hin_al_cbse_01_005: Reinforces the skill of using textual evidence for character analysis across different stories.  
c12_hin_ar_cbse_02_005: Class 11 practice with supporting characters in another poem, reinforcing the method.  
c12_hin_ar_cbse_06_005: Class 11 foundation on supporting character analysis in Aroh.  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
none

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_02_004 -> c11_hin_ar_cbse_02_005 -> c11_hin_ar_cbse_02_006

## THIS_FORMULA
Character Function = (Dialogue + Action + Contrast with Protagonist) → Thematic Revelation

## FORMULA_VARIABLES
- Dialogue: What the character says, how they say it, and what they avoid saying
- Action: What the character does in key scenes, especially toward the protagonist
- Contrast with Protagonist: Specific points of difference or unexpected similarity in values, language, worldview
- Thematic Revelation: The central idea or conflict this character illuminates (e.g., bureaucracy vs. wisdom, inherited vs. earned identity)

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
analytical

## CROSS_SUBJECT
c11_history_colonialism | The clerk (ckn'kkg lyker) represents the colonial bureaucratic mindset — rigid, text-obsessed, dismissive of oral knowledge — mirroring British administrative attitudes toward Indian traditional knowledge systems and the imposition of written record-keeping as governance
c11_sociology_social_stratification | The interactions reveal class/caste dynamics: the tailor's illiteracy marks him as lower status, yet his wisdom challenges the literacy=superiority assumption, illustrating how social hierarchies are maintained through controlled access to education and documentation

## PREREQ_CONCEPT
Understanding of protagonist's core traits: practical wisdom despite illiteracy, bearer of oral tradition, dignity in skilled labor, philosophical outlook on identity

## PREREQ_BEFORE
Student must have completed protagonist analysis identifying fe;k¡ ulh#íhu's three defining characteristics: (1) mastery of craft as identity foundation, (2) resistance to external definitions through philosophical redirection, (3) transformation of humiliation into teaching moments

## PREREQ_STUCK
Review the protagonist's three defining scenes: the name-giving episode (refusing clerk's categories), the alphabet teaching scene (transforming letters into life philosophy), and the final statement on artificial identities ("ge Hkêòh cukuk u lh[krs")

## WORKED_EXAMPLE_1
PROBLEM: Analyze how the character of 'kkgh ukuckbZ fe;k¡ dYyu (the illiterate tailor double) functions as a thematic mirror for the protagonist.

STEPS:
- Step 1: Identify all textual references to this character — he is mentioned when the woman asks "vkidks bu nksuksa esa ls fdlh dh Hkh dksbZ ulhgr ;kn gks!" and the tailor is mistaken for him
- Step 2: Note the explicit parallels — both are tailors (x<+S;kokys), both illiterate ('kkgh ukuckbZ), both known by profession not name
- Step 3: Identify the critical difference — the protagonist possesses philosophical self-awareness ("ge crZu èkksuk u lh[krs / ge Hkêòh cukuk u lh[krs"); the double represents the "common" illiterate artisan without articulation
- Step 4: Analyze the protagonist's reaction to the comparison — he doesn't reject it ("gk¡]µ,d nwljh i<+kbZ Hkh gksrh gSA") but transforms it through his wisdom, turning the label into a platform for his philosophy
- Step 5: Conclude the thematic function — the double allows the author to show the protagonist as both REPRESENTATIVE (everyman tailor) and EXCEPTIONAL (philosopher of labor), reinforcing that dignity transcends literacy

REASONING: The double character technique is a classic literary device where a secondary figure shares surface traits with the protagonist but lacks the defining quality. Here, it proves the tailor's wisdom is not INHERENT to his profession but EARNED through reflection — making his achievement more powerful.

ANSWER: 'kkgh ukuckbZ fe;k¡ dYyu serves as a thematic double — sharing the protagonist's profession and illiteracy but lacking his philosophical articulation. When the woman conflates them, the protagonist accepts the comparison ("gk¡]µ,d nwljh i<+kbZ Hkh gksrh gSA") but immediately elevates it: "ge crZu èkksuk u lh[krs / ge Hkêòh cukuk u lh[krs / Hkêòh dks vk¡p nsuk u lh[krs / rks D;k ge lhèks&lhèks ukuckbZ dk gquj lh[k tkrs!" This reveals the story's central theme: true knowledge isn't literacy but understanding life's essence through one's craft. The double makes this argument visible — without him, the tailor's exceptionality would be invisible.

## WORKED_EXAMPLE_2
PROBLEM: Examine how flj fgykuk (the woman) functions as the voice of practical reality against the protagonist's philosophical idealism, and analyze the power dynamic this creates.

STEPS:
- Step 1: Locate her key dialogues — she initiates the identity inquiry ("I+kQjekb,A*"), challenges evasiveness ("vkidks bu nksuksa esa ls fdlh dh Hkh dksbZ ulhgr ;kn gks!"), demands father's name for records ("vkius [kkunkuh ukuckbZ gksus dk f"kØ fd;k] D;k ;gk¡ vkSj Hkh ukuckbZ gSa\")
- Step 2: Contrast her concerns (identity papers, father's name, official recognition, "bYe" — knowledge/credentials) with the tailor's concerns (philosophical definitions, oral tradition, craft mastery)
- Step 3: Analyze the alphabet scene — she pushes for literal learning ("fudky ysaxs oDr FkksM+k") while he teaches "vfyI+kQ, cs, the" as life philosophy, not mere letters
- Step 4: Examine the power imbalance — she has institutional knowledge (knows about clerk, paperwork, "ckn'kkg lyker"); he has experiential wisdom. She represents the world that demands documentation; he represents the world that lives by memory and skill
- Step 5: Synthesize — she is not merely "pragmatic"; she embodies the historical transition from oral to written culture. Her persistence FORCES the tailor to articulate his philosophy, making her the catalyst for the story's central argument

REASONING: The woman is often dismissed as "pushy" or "practical," but her role is structural — she represents the specific historical pressure of colonial modernity that demanded paper identity. The tailor's brilliance is that he doesn't fight her on her terms; he teaches ON her terms (alphabet) but WITH his content (philosophy).

ANSWER: flj fgykuk represents the bureaucratic modernity that reduces identity to documentation. Her persistent questioning — "vkidks bu nksuksa esa ls fdlh dh Hkh dksbZ ulhgr ;kn gks!" and demand for father's name — exposes how the state requires written proof of existence. The tailor's response teaching "vfyI+kQ, cs, the" as life philosophy rather than mere letters shows his resistance: he accepts her FRAME (alphabet) but replaces her CONTENT (literacy) with his WISDOM. She is the catalyst that forces his philosophy into articulation. Without her, the tailor's wisdom remains implicit; with her, it becomes explicit debate. The power dynamic is asymmetric: she holds institutional power (access to clerk, knowledge of procedures); he holds moral authority (self-possession, philosophical depth). The story validates HIS authority by making her eventually listen ("flj fgykuk iM+k&^Bhd I+kQjekrs gSaA*").

## WORKED_EXAMPLE_3
PROBLEM: Analyze the clerk (ckn'kkg lyker) as an antagonist representing institutional rigidity. Evaluate whether he is a flat villain or a systemic symbol, using his language, actions, and the single moment of human curiosity.

STEPS:
- Step 1: List all clerk's actions — demands name/identity, rejects oral testimony, insists on written records, threatens consequences, summons the tailor officially
- Step 2: Analyze his language — the bureaucratic litany "ckOkQj[kkuh&'khjeky&rkI+kQrku&csluh&[kehjh&:ekyh&xko&nhnk&xk"kscku&rqudh" (verification, inquiry, investigation, examination, etc.) represents the state's totalizing vocabulary of control
- Step 3: Contrast with tailor's language — poetic, metaphorical, oral, philosophical ("vfyI+kQ, cs, the" as life lessons; "ge Hkêòh cukuk u lh[krs")
- Step 4: Examine the power structure — clerk wields state authority (can punish, document, erase); tailor wields moral authority (self-respect, wisdom, craft mastery). The conflict is epistemological: written/bureaucratic vs. oral/experiential knowledge
- Step 5: Identify the critical human moment — "D;k muls cuh ,slh ph"k!" (What a metaphor he created!) when the tailor explains his philosophy. This brief wonder reveals the clerk is not purely mechanical; the SYSTEM forces him to be
- Step 6: Conclude — he is a systemic symbol, not a personal villain. The tragedy is structural: a system that only recognizes written documentation cannot accommodate oral wisdom. The tailor wins morally but loses administratively — the story's central tragedy

REASONING: Reducing the clerk to "villain" simplifies Ñ".kk lkscrh's critique. The clerk's momentary appreciation ("D;k muls cuh ,slh ph"k!") proves the system's human agents CAN recognize wisdom — but the system's RULES prevent them from acting on it. This makes the critique deeper: it's not about bad people, but about bad structures.

ANSWER: ckn'kkg lyker is a systemic symbol, not a flat villain. His bureaucratic litany represents the state's demand for total documentation. His language ("ckOkQj[kkuh&'khjeky&rkI+kQrku...") is the vocabulary of control — each term a gate the tailor cannot pass without writing. Yet his brief wonder at the tailor's metaphor ("D;k muls cuh ,slh ph"k!") reveals the human beneath the uniform. The conflict is between two epistemologies: written/bureaucratic (clerk) vs. oral/experiential (tailor). The tailor wins morally — his philosophy resonates even with the clerk — but loses administratively, as the system demands papers he cannot produce. This structural tragedy is the story's sharpest critique of modernity.

## COMPETENCY_QUESTION_1
QUESTION: In 'Fe;k¡ ulh#íhu', the journalist (v[kckjuohl) appears briefly but significantly. Using textual evidence, analyze how this character serves as a bridge between the tailor's world and the reader's world. What narrative function does this serve in a story about oral vs. written culture?

COMPETENCY: Textual Analysis and Narrative Function Identification

STEPS:
- Step 1: Locate the journalist's entry — "ckn'kkg lyker us ;w¡ dgkµ fe;k¡ ukuckbZ] dksbZ ubZ ph"k f[kyk ldrs gks\" (the clerk suggested the tailor could create a "new angle")
- Step 2: Identify what the journalist wants — a story/article ("ubZ ph"k") on the illiterate tailor, representing the literary establishment's gaze
- Step 3: Analyze the tailor's response — "dksbZ ,slh ph"k cukvks tks u vkx ls iosQ] u ikuh ls cus" (create something that comes from neither outside nor inside), rejecting both external observation and internal projection
- Step 4: Explain how the journalist represents the "educated reader" — we too approach the tailor seeking a "story," an "angle," a consumable narrative
- Step 5: Connect to meta-commentary — the story critiques how literature itself consumes oral traditions; the journalist makes the reader complicit in this extraction

ANSWER: The journalist enters as the clerk's suggestion: "fe;k¡ ukuckbZ] dksbZ ubZ ph"k f[kyk ldrs gks\" — seeking a "new angle" on the illiterate tailor. He represents the literary establishment that exoticizes oral culture for written consumption. When the tailor responds "dksbZ ,slh ph"k cukvks tks u vkx ls iosQ] u ikuh ls cus," he refuses to be a specimen. The journalist's presence makes the reader complicit — we too are "reading" the tailor for a "ph"k" (angle/story). This meta-layer critiques how literature consumes oral traditions: the journalist wants to WRITE the tailor; the tailor insists on BEING his craft. The story thus implicates its own act of writing — Ñ".kk lkscrh writes ABOUT the tailor while the tailor refuses to be written. The journalist is the mirror in which the reader sees their own extractive gaze.

DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: Compare the father (okfyn ejgwe) and the uncle (nknk) as representations of familial legacy. How do their contrasting appearances in the tailor's memory reveal his philosophy on lineage, identity, and the relationship between craft and blood?

COMPETENCY: Comparative Character Analysis and Thematic Synthesis

STEPS:
- Step 1: Identify the father's reference — "okfyn lkfgc e'kgwj Fks fe;k¡ cjOkQr 'kkgh ukuckbZ x<+S;kokys osQ uke ls vkSj muosQ okfyn ;kuh fd gekjs nknk lkfgc Fks vkyk ukuckbZ fe;k¡ dYyu" — the father is claimed PROUDLY as source of craft identity
- Step 2: Identify the uncle's reference — "cksyh osQ mB tkus ij vk cSBs mUgha osQ Bh;s ij" — the tailor physically moves AWAY from the uncle's presence/status
- Step 3: Analyze WHY the distinction — father passed down SKILL (tailoring) and the honorable label "illiterate tailor"; uncle represents inherited STATUS without merit (position, name)
- Step 4: Connect to the name-giving philosophy — "ge Hkêòh cukuk u lh[krs" (we don't create artificial identities); identity is CHOSEN through work, not INHERITED through blood
- Step 5: Synthesize — father = spiritual ancestor (craft legacy); uncle = biological accident (status legacy). The tailor's selective claiming enacts his philosophy: true lineage is the craft you master

ANSWER: The father (okfyn ejgwe) is claimed because he transmitted the CRAFT — "okfyn lkfgc e'kgwj Fks fe;k¡ cjOkQr 'kkgh ukuckbZ x<+S;kokys osQ uke ls" — making the tailor's identity rooted in skilled labor. The uncle (nknk) represents inherited status without merit — when "cksyh osQ mB tkus ij vk cSBs mUgha osQ Bh;s ij," the tailor physically distances himself. This enacts the tailor's core philosophy: "ge Hkêòh cukuk u lh[krs" (we don't fabricate artificial identities). True lineage is EARNED through mastery (father's tailoring), not GIVEN through blood (uncle's position). The father is the spiritual ancestor; the uncle is the biological accident. This contrast reveals the story's radical argument: in a society obsessed with lineage and literacy, the tailor proposes CRAFT as the only authentic inheritance. The supporting characters of father and uncle are not merely family — they are the two possible answers to "where do you come from?" and the tailor's choice defines his rebellion.

DIFFICULTY: hard