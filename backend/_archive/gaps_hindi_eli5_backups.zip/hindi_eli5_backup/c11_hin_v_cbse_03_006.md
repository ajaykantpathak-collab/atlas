## DEFINITION
The primary theme is the central, unifying idea or message that the author conveys through the narrative, characters, and events. In "vHkh Hkh eqvutks&nM+ks," the primary theme is the struggle for dignity, self-expression, and identity of a domestic worker who transforms her lived experiences into literary creation, asserting her agency against social invisibility and systemic marginalization.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student must be able to identify the primary theme by tracing its development across at least three major narrative arcs in the text, support it with specific textual evidence (character actions, dialogue, narrative commentary), and explain how the theme resolves in the protagonist's journey from domestic worker to published writer.

## SCOPE_BOUNDARY
This node covers identification and analysis of the single most dominant theme in the chapter. It does NOT cover secondary themes (node 007), literary devices (nodes 008-009), or comprehension questions (node 012). Focus remains on the central message of empowerment through literacy and the dignity of invisible labor.

## WALKTHROUGH
Imagine you are the narrator—someone who spends decades cleaning strangers' homes, raising their children, eating leftovers, and being asked "Where is your husband? Why do you work?" every single day. Now ask: what is the ONE story this entire book is trying to tell? Start by listing the three biggest turning points: (1) when Rani (the narrator) first picks up a pen despite being illiterate, (2) when her writing is recognized by her employer Raghunath, and (3) when she publishes her autobiography. The theme lives in the gap between what society expects of her (silence, service) and what she claims for herself (voice, authorship). The key insight: the theme is not just "she becomes a writer"—it is that writing *is* her rebellion against erasure.

## DIAGNOSTIC_QUESTION_1
What is the definition of 'primary theme' in a literary text, and how does it differ from a 'subject' or 'topic'?

## DIAGNOSTIC_ANSWER_1
The primary theme is the central insight about life or human nature that the author conveys through the narrative—it is a complete statement (e.g., "Literacy empowers marginalized women to reclaim agency"), whereas a subject/topic is merely the general area (e.g., "domestic work" or "illiteracy"). A wrong answer that confuses theme with topic (e.g., saying "The theme is domestic work") reveals the student cannot distinguish between what the text is *about* and what the text *says* about it.

## DIAGNOSTIC_QUESTION_2
In "vHkh Hkh eqvutks&nM+ks," the narrator says: "eSa lksprh fd lpeqp brus fnuksa ckn eq>s ,d lgsyh feyhA" (I feel that after so many days, a relief has come). Explain what this 'relief' signifies in relation to the primary theme. Do not just summarize the plot.

## DIAGNOSTIC_ANSWER_2
The 'relief' signifies the moment the narrator's internal validation (self-worth through writing) finally outweighs external validation (employers' approval). It connects to the primary theme because it marks the completion of her journey from seeking permission to exist ("rqEgkjs iSlksa osQ ckjs esa eSa rqEgkjk dke ns[kdj crkÅ¡xk") to owning her narrative ("vk'kkiw.kkZ nsoh dh dksbZ u;h fdrkc i<+h D;k"). A wrong answer that treats this as mere plot resolution ("she felt happy her book was done") misses the thematic weight of self-authorization.

## DIAGNOSTIC_QUESTION_3
Apply the concept of 'primary theme' to this new scenario: A domestic worker in a metro city today starts a YouTube channel documenting her daily routine, gaining 100k followers. Her employers find out and feel uncomfortable. What would be the primary theme of *her* story if written as a memoir, and how does it echo or differ from the narrator's theme in the chapter?

## DIAGNOSTIC_ANSWER_3
The primary theme would be: "Digital self-representation allows invisible laborers to bypass gatekeepers and claim public dignity on their own terms." It echoes the chapter's theme (self-expression as resistance) but differs in medium (digital vs. print) and power dynamic (direct audience vs. mediated through employer). Steps: (1) Identify the core conflict—invisibility vs. visibility. (2) Identify the resolution—she controls her narrative. (3) Formulate as a universal statement. (4) Compare with chapter: both center agency through narration, but the YouTuber has immediate audience feedback, unlike the narrator's delayed recognition. A wrong answer would list "social media" or "domestic work" as the theme—confusing tool/topic with message.

## DIAGNOSTIC_QUESTION_4
Analyze how the narrative structure (non-linear, fragmented memories interspersed with present-time writing) reinforces the primary theme. Cite two specific structural choices and their thematic function.

## DIAGNOSTIC_ANSWER_4
Structural choice 1: The narrative opens *in medias res* with the narrator already writing ("vc rd ftruk eSa fy[k pqdh Fkh"), then flashes back to her early struggles. This mirrors the theme—writing *reorders* chaotic lived experience into coherent meaning. Structural choice 2: Recurring motif of "fdrkc&dkWih" (diary/notebook) appearing at three key junctures (gift from Raghunath, writing practice, final manuscript) creates a structural arc: object → practice → product. This embodies the theme of literacy as incremental empowerment. A wrong answer would only describe the structure ("it jumps in time") without linking each choice to the theme of self-construction through writing.

## DIAGNOSTIC_QUESTION_5
Evaluate this claim: "The primary theme of the chapter is the exploitation of domestic workers by upper-class employers." Defend or refute using textual evidence.

## DIAGNOSTIC_ANSWER_5
Refute. While exploitation *occurs* (unpaid wages, invasive questioning, physical discomfort), it is the *condition*, not the *message*. The primary theme is the protagonist's *response* to exploitation: transforming it into literature. Evidence: (1) She refuses to internalize shame ("eq>s ;g lc ns[k&lqudj vc esjh ckgj fudyus dh gh bPNk ugha gksrh"). (2) The climax is not escape from employment but publication ("rkrq'k us rqEgsa 'kCn&dks'k dh enn ysus dks Bhd gh dgk gSA"). (3) The closing lines center her voice ("esjh 'kqHkdkeuk vkiosQ lkFk gSA"). A wrong answer that agrees confuses *subject matter* (what happens to her) with *theme* (what the text argues about it). The text does not end in victimhood—it ends in authorship.

## DIAGNOSTIC_QUESTION_6
Create a one-paragraph thematic statement for a modern adaptation of this story set in a gig-economy context (e.g., a delivery partner, a home-nurse, a cleaning-app worker). Your statement must be a complete sentence expressing a universal insight, not a plot summary.

## DIAGNOSTIC_ANSWER_6
Example: "When algorithmic management reduces care-work to invisible data-points, the worker who documents her own reality reclaims not just visibility but the power to define what her labor means." Criteria for a good answer: (1) Single complete sentence. (2) Universal insight applicable beyond the specific character. (3) Contains tension (invisibility vs. definition, algorithm vs. human). (4) Echoes the chapter's core: self-narration as resistance. A poor answer: "A delivery guy writes a blog about his job and becomes famous" (plot, not theme); "Gig work is hard" (topic, not insight); "Technology exploits workers" (generalization, not specific to self-narration).

## COMMON_MISCONCEPTION
Students consistently confuse the *primary theme* with the *social issue* depicted in the text. They write "The theme is the hard life of domestic workers" or "The theme is illiteracy among poor women." This error arises because the text spends 50+ pages detailing exploitation, hunger, and humiliation—making the *conditions* feel like the *message*. The examiner, however, rewards the insight that the narrator *transcends* these conditions through writing. The specific wrong reasoning: "Since the text describes X extensively, X must be the theme." The correct reasoning: "The text describes X to show how the protagonist overcomes X via Y—therefore Y is the theme."

## ON_FAILURE
Step 1: Ask the student to write the *last paragraph* of the chapter in their own words. Step 2: Ask: "What does the narrator *have* at the end that she didn't have at the start?" (Answer: a published book, a recognized name, self-respect). Step 3: Guide them to complete this sentence: "The book argues that ______ is the way out of ______." Step 4: Have them replace the blanks with abstract nouns (literacy/dignity; invisibility/silence). Step 5: That completed sentence *is* the primary theme. Repeat with two other characters' arcs (Raghunath, the children) to show thematic consistency.

## BUILDS_ON
Character Analysis: Protagonist (c11_hin_v_cbse_03_004) — understanding the narrator's psychological arc is prerequisite to identifying what the narrative *argues* through her.

## LEADS_TO
Theme: Secondary Themes (c11_hin_v_cbse_03_007) — once the primary theme is established, subordinate threads (gender, class, education, motherhood) can be mapped as variations or counterpoints.

## PREREQUISITE_NODE_IDS
c11_hin_v_cbse_03_002, c11_hin_v_cbse_03_004, c11_hin_v_cbse_03_005, c11_hin_v_cbse_03_001, c11_hin_v_cbse_03_003

## PREREQUISITE_REASONS
c11_hin_v_cbse_03_002: Plot and Narrative Structure provides the sequence of events through which the theme unfolds; without knowing the turning points, theme identification is guesswork.
c11_hin_v_cbse_03_004: Character Analysis: Protagonist gives the internal journey (illiteracy → literacy, silence → voice) that embodies the theme.
c11_hin_v_cbse_03_005: Character Analysis: Supporting Characters provides the foils (employers, children, fellow workers) that define the thematic conflict by contrast.
c11_hin_v_cbse_03_001: "Before You Read: की समझ आवश्यक है, क्योंकि यह नोड (The primary theme is the central, unifying idea or message that the author conveys through...) इसी आधार पर आगे बढ़ता है।  
c11_hin_v_cbse_03_003: Primary themes (gendered labor, education as liberation/entrapment, autonomy vs. survival) emerge from the dialectic between character and setting established in this node.  

## FORWARD_NODE_IDS
c11_hin_v_cbse_03_007, c11_hin_v_cbse_03_013, c11_hin_v_cbse_03_014, c11_hin_v_cbse_03_008, c11_hin_v_cbse_03_010, c11_hin_v_cbse_03_015, c12_hin_v_cbse_03_006

## FORWARD_REASONS
c11_hin_v_cbse_03_007: Secondary Themes requires a clear primary theme as anchor; each secondary theme must be shown as complementing or complicating the central message.
c11_hin_v_cbse_03_013: Critical Thinking: Analysis and Interpretation demands thematic grounding; all higher-order analysis (irony, symbolism, narrative technique) serves the theme.
c11_hin_v_cbse_03_014: Writing Skills: Based on the Chapter tasks (essay, article, diary) require thematic clarity to produce coherent, evidence-based responses.
c11_hin_v_cbse_03_008: Primary theme (dignity in labor) is the *thematic anchor* — every image/metaphor must be evaluated for how it advances or complicates this theme.  
c11_hin_v_cbse_03_010: Primary theme (dignity through literacy) provides the thematic lens for evaluating vocabulary choices.  
c11_hin_v_cbse_03_015: मुख्य विषय (स्त्री अस्मिता, लेखन की मुक्तिकामी शक्ति) चर्चा के केंद्रीय बिंदु हैं।  
c12_hin_v_cbse_03_006: Provides the foundational skill of distinguishing topic from theme and evidence-based theme identification — this node applies that skill at higher complexity.  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
none

## CHAIN_DESCRIPTION
c11_hin_v_cbse_03_002 -> c11_hin_v_cbse_03_006 -> c11_hin_v_cbse_03_007

## THIS_FORMULA
N/A - conceptual

## FORMULA_VARIABLES
N/A

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
conceptual

## CROSS_SUBJECT
c11_sociology_social_stratification | The chapter dramatizes how caste-class-gender intersectionality shapes domestic labor; the primary theme (literacy as resistance) connects to sociological theories of agency within structural constraint.
c11_psychology_self_concept | The narrator's journey from internalized inferiority ("eq>s nq[k u igq¡ps") to authored identity illustrates Erikson's identity vs. role confusion and Bandura's self-efficacy through mastery experiences (writing).
c11_economics_informal_labour | The text is a case study of invisible reproductive labor; the theme of self-narration as economic empowerment links to feminist economics' emphasis on voice and visibility for informal workers.

## PREREQ_CONCEPT
Character arc analysis: the ability to trace a protagonist's internal change across the narrative (from c11_hin_v_cbse_03_004).

## PREREQ_BEFORE
The student must be able to list the narrator's three major psychological shifts: (1) accepting invisibility, (2) discovering writing as self-expression, (3) claiming public identity as a writer.

## PREREQ_STUCK
Review the protagonist's diary entries and letters in the text—these are the clearest markers of her internal transformation.

## WORKED_EXAMPLE_1
PROBLEM: Identify the primary theme of "vHkh Hkh eqvutks&nM+ks" using the 'Three Turning Points' method. Show your work.

STEPS:
- Step 1: Locate the three moments where the narrator's relationship to her own story changes fundamentally. From the text: (a) First time she writes in the notebook Raghunath gives her ("isu vkSj dkWih gkFk esa fy, eSa lkspus yxh"), (b) First time her writing is validated by an outsider ("rkrq'k us eq>ls cSB tkus dks dgk vkSj fiQj fp_h i<+dj lqukus yxs"), (c) The publication moment ("'kfeZyk nh us esjs ltus&èktus osQ ckjs esa iwNk D;ksafd...").
- Step 2: For each moment, write what she *gains* that she lacked before. (a) A private space for thought. (b) An audience that takes her seriously. (c) Public recognition and legacy.
- Step 3: Abstract the pattern: private voice → witnessed voice → published voice. The movement is from silence to authorship.
- Step 4: Formulate as a universal statement: "Literacy enables the marginalized domestic worker to transform lived invisibility into authored visibility, reclaiming dignity through self-narration."
- Step 5: Verify against the ending: The final pages show her teaching children to read, corresponding with readers, and planning her next book—the theme holds because the trajectory continues beyond the text.

REASONING: This method works because themes are not stated—they are *performed* through character change. By anchoring each abstract claim in a concrete narrative moment, we avoid the 'topic vs. theme' confusion.

ANSWER: Primary Theme: "Literacy enables the marginalized domestic worker to transform lived invisibility into authored visibility, reclaiming dignity through self-narration."

## WORKED_EXAMPLE_2
PROBLEM: A student writes: "The main theme is how badly employers treat servants." Diagnose the error and rewrite as a correct thematic statement.

STEPS:
- Step 1: Identify the error type: The student has named the *conflict* (exploitation) not the *resolution/insight* (what the text says about that conflict).
- Step 2: Check the text for the author's stance on this conflict. Does the text end with the employers changing? No. Does it end with the narrator escaping? No—she continues working but *on her terms*.
- Step 3: Locate the narrator's own articulation of meaning. She says: "fy[kus cSBus ls gh fy[kk tk ldrk gS] ;g vfHkKrk rqEgsa fuf'pr gh gks xbZ gSA" (Writing comes from sitting to write; this conviction has become firm in me).
- Step 4: Synthesize: The employer's behavior is the *obstacle*; writing is the *response*; the theme is the *power of that response*.
- Step 5: Rewrite: "The narrative demonstrates that self-narration through literacy is the most potent resistance available to domestic workers against the dehumanization of their labor."

REASONING: Themes are arguments, not situations. The rewrite passes the 'universal statement test' (applies beyond this specific story) and the 'ending test' (matches the final note of agency).

ANSWER: Corrected thematic statement: "The narrative demonstrates that self-narration through literacy is the most potent resistance available to domestic workers against the dehumanization of their labor."

## WORKED_EXAMPLE_3
PROBLEM: Compare the primary theme of "vHkh Hkh eqvutks&nM+ks" with the primary theme of Mahasweta Devi's "Stanadayini" (The Breast-Giver). Both feature marginalized women. Write a comparative thematic analysis in 150 words.

STEPS:
- Step 1: State "vHkh Hkh eqvutks&nM+ks" primary theme (from Worked Example 1): Literacy as self-authorization against erasure.
- Step 2: Recall "Stanadayini" primary theme: The commodification of a Dalit woman's body (wet-nursing) by upper-caste patriarchy, and her tragic inability to reclaim agency—her resistance (biting the infant) is crushed.
- Step 3: Identify the shared ground: Both center women whose reproductive/care labor is exploited by dominant structures (class/caste).
- Step 4: Identify the critical divergence: The narrator in our text *acquires a tool* (literacy) that converts private pain into public testimony; Jashoda in "Stanadayini" has *no such tool*—her body remains the only site of resistance, and it fails.
- Step 5: Formulate comparative insight: "While both texts expose the extraction of care-labor from marginalized women, 'vHkh Hkh eqvutks&nM+ks' posits literacy as a viable path to epistemic justice, whereas 'Stanadayini' reveals the fatal limits of embodied resistance without access to symbolic power."
- Step 6: Check word count and ensure both themes are named explicitly.

REASONING: Comparative thematic analysis requires (a) accurate individual theme identification, (b) a shared framework (care-labor exploitation), and (c) a differentiated claim about *agency*. This mirrors board exam 'compare and contrast' questions.

ANSWER: Comparative Thematic Analysis: "While both texts expose the extraction of care-labor from marginalized women, 'vHkh Hkh eqvutks&nM+ks' posits literacy as a viable path to epistemic justice—where the narrator transforms invisibility into authored visibility—whereas 'Stanadayini' reveals the fatal limits of embodied resistance without access to symbolic power. Jashoda's body is the only site of her rebellion (biting the infant), and it destroys her; the narrator's pen becomes a site of reconstruction, allowing her to 'reclaim dignity through self-narration.' The divergence lies not in the oppression depicted but in the narrative's judgment on whether the subaltern can speak—and be heard."

## COMPETENCY_QUESTION_1
QUESTION: The narrator says: "rqEgkjs rkrq'k us rqels Bhd gh dgk gS fd Hkwy gksrh gS rks gks] fiQj Hkh fy[kksA tsBw dh ftruh fpf_;k¡ vkrha mruh esjh bPNk gksrh fd fy[k¡w] vkSj Hkh fy[k¡wA" (Your Raghunath has rightly said: let whatever happens happen, but write. The more Tsab's pages arrive, the more I feel like writing, and writing more.) Explain how this dialogue encapsulates the primary theme. Your answer must reference the speaker, the addressee, and the thematic function of the imperative "fy[kks" (write).

COMPETENCY: Thematic interpretation with textual evidence

STEPS:
- Step 1: Identify the speaker (Tsab/Tsab's pages arriving) and addressee (the narrator). Note: Tsab is the narrator's literary mentor figure.
- Step 2: Analyze the imperative "fy[kks" — it is not a suggestion but a command rooted in the mentor's authority as a writer.
- Step 3: Connect to theme: The command externalizes what the narrator has internalized ("esjh 'kqHkdkeuk vkiosQ lkFk gSA"). The theme is not just that she writes, but that writing *must* continue regardless of circumstance ("Hkwy gksrh gS rks gks").
- Step 4: Synthesize: The dialogue crystallizes the theme—literacy as non-negotiable praxis, not optional therapy. The mentor validates writing as *work* equal to her domestic labor.

ANSWER: The dialogue between Tsab (via her arriving manuscripts) and the narrator encapsulates the primary theme by framing writing as an imperative ("fy[kks") that transcends circumstance ("Hkwy gksrh gS rks gks"). The speaker (Tsab, the established writer) legitimizes the narrator's practice as professional labor, not emotional outlet. The addressee (the narrator) receives this not as pressure but as permission to prioritize her authorship alongside her domestic work. Thematic function: it transforms writing from private solace into public vocation—the core argument of the text.

DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: A board exam question asks: "The title 'vHkh Hkh eqvutks&nM+ks' (Still, the stairs keep descending) is a metaphor for the primary theme. Analyze this statement." Write a structured response (PEEL format) that evaluates the metaphor's adequacy.

COMPETENCY: Metaphorical analysis of title in relation to theme

STEPS:
- Step 1: Point — The title metaphor *partially* captures the theme but requires qualification. "Descending stairs" suggests endless labor/decline; the theme is *ascent through narration*.
- Step 2: Evidence — The stairs appear literally when the narrator carries water up stairs ("yM+osQ&yM+fd;ksa] cM+s&cw<+s] lHkh gkFk esa ikuh dh cksry ys V^h osQ fy, ckgj tkrsA") and metaphorically in the unending cycle of employers' demands.
- Step 3: Explanation — However, the *narrative arc* reverses the descent: each chapter climbs toward authorship. The stairs are the *condition*; writing is the *elevator*. The title names the problem, the text performs the solution.
- Step 4: Link — Therefore, the metaphor is necessary but insufficient. A complete thematic reading must pair "eqvutks nM+ks" (the stairs keep descending) with the unstated counter-movement: "fy[kks" (write)—the upward trajectory the title omits but the text enacts.

ANSWER: The title metaphor "vHkh Hkh eqvutks&nM+ks" adequately represents the *structural condition* of the narrator's life—endless, repetitive domestic labor across multiple households (evidenced by the literal stairs she climbs carrying water, and the cyclical employer demands). However, it fails to capture the *thematic resolution*: the primary theme is not the descent but the ascent through literacy. The text counters the stairs' downward pull with the upward trajectory of "fy[kks" (write)—each manuscript completed, each letter answered, each child taught to read. The title names the gravity; the theme names the flight. A full analysis must hold both: the stairs are real, but they are not the whole truth.

DIFFICULTY: hard