## DEFINITION
Literal comprehension questions require students to retrieve explicitly stated information from the text (who, what, where, when), while inferential comprehension questions demand students to draw logical conclusions by combining textual evidence with reasoning, reading between the lines to understand implied meanings, character motivations, and thematic undercurrents.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student can independently distinguish between literal and inferential question types, locate precise textual evidence for literal answers, and construct inferential responses using a minimum of two pieces of textual evidence linked by logical reasoning to support a conclusion not directly stated.

## SCOPE_BOUNDARY
This node covers the classification and answering strategies for literal and inferential questions based on the short story "Xyrk Yksgk" from NCERT Class 11 Hindi Aroh Chapter 5. It does not cover critical appreciation, creative writing, or evaluative questions which are addressed in subsequent nodes.

## WALKTHROUGH
Imagine you're sitting in your board exam and the first comprehension question asks: "Why did Eksgu's mother send him to the city school?" You scan the text and find the exact sentence — that's literal. But the next question asks: "What does Eksgu's silence throughout the story reveal about his internal struggle?" The answer isn't written anywhere; you must connect his silence when the headmaster insults him, his silence when his mother begs, and his final act of touching the teacher's feet. Start by underlining every direct fact in the text — names, actions, dialogues, descriptions. Then for each inferential question, ask yourself: "What two or three facts, when combined, point to this hidden truth?" This two-step habit — extract facts first, then connect them — is what separates a 2-mark answer from a 5-mark answer.

## DIAGNOSTIC_QUESTION_1
Identify whether the following question is literal or inferential: "What was the name of the headmaster in Eksgu's school?" Explain your reasoning in one sentence.

## DIAGNOSTIC_ANSWER_1
This is a literal question because the answer "Phakeersingh" (f=kyksd flag) is explicitly stated in the text when the narrator introduces him as "ekLVj f=kyksd flag". A wrong classification (calling it inferential) reveals the student cannot distinguish between directly stated facts and conclusions requiring reasoning — they likely treat any question about a character as "deep" rather than checking if the name appears verbatim in the text.

## DIAGNOSTIC_QUESTION_2
The text states: "Eksgu did not answer. He sat with his head bowed." Based only on this sentence, what can you literally conclude, and what would be an inferential leap? Give one example of each.

## DIAGNOSTIC_ANSWER_2
Literal conclusion: Eksgu remained silent and kept his head lowered. Inferential leap: Eksgu felt humiliated or angry — this is not in the sentence; it requires interpreting body language. A student who writes "Eksgu was sad" as a literal fact reveals the misconception that emotional states are directly observable in the text, when they are always inferences drawn from actions.

## DIAGNOSTIC_QUESTION_3
Apply the two-step method (extract facts → connect) to answer this inferential question: "Why does the author describe the headmaster's voice as 'thunderous' (gur-gur) when he calls Eksgu?" Provide two textual facts you would combine.

## DIAGNOSTIC_ANSWER_3
Fact 1: The headmaster shouts "Eksgu! Bring water for the master!" in a commanding tone (explicit dialogue). Fact 2: The headmaster treats Eksgu as a servant, not a student, shown when he says "One day he will become a big officer of the city" mockingly. Connecting these: The "thunderous" description reflects the headmaster's feudal authority and caste arrogance, not just volume. A student who only quotes the dialogue without the mocking context gives a literal answer to an inferential question — missing the social critique.

## DIAGNOSTIC_QUESTION_4
Analyze the difference between these two questions from the NCERT exercises: (1) "Write a summary of the incident where Eksgu's mother sends him to the city school." (2) "Eksgu's life moves between two worlds — the village and the city. What is the significance of this movement?" Classify each and explain the cognitive demand difference.

## DIAGNOSTIC_ANSWER_4
Question 1 is literal — it asks for a chronological retelling of explicitly narrated events (mother's decision, father's opposition, Eksgu's departure). Question 2 is inferential — "significance" is never stated; the student must synthesize the contrast between village caste oppression and city anonymity, Eksgu's internal conflict, and the cyclical return to village. A student who writes a plot summary for Question 2 reveals they cannot shift from "what happened" to "what it means" — they treat analysis as extended narration.

## DIAGNOSTIC_QUESTION_5
Evaluate this student's answer to an inferential question: "Why does Eksgu touch the teacher's feet at the end?" Student writes: "Because he respects the teacher. The teacher helped him study." Is this answer sufficient for a 3-mark board question? Justify.

## DIAGNOSTIC_ANSWER_5
Insufficient. The answer states a surface-level inference (respect) but lacks textual evidence and misses the layered meaning: (1) Eksgu touches feet *after* the teacher's death — it's a ritual for the departed, not live gratitude; (2) The teacher (Shastriji) never directly taught him — Eksgu learned by overhearing; (3) The act contrasts with the headmaster's cruelty, symbolizing Eksgu's choice of dignity over caste submission. A student who gives this answer reveals they confuse "plausible guess" with "textually grounded inference" — they didn't anchor the inference in specific moments (Shastriji's "I don't teach, you learn" line, the final scene's funeral context).

## DIAGNOSTIC_QUESTION_6
Create an inferential question about the character of Gillo (the squirrel) that requires connecting at least three separate textual details. Write the question and list the three details a strong answer would combine.

## DIAGNOSTIC_ANSWER_6
Question: "How does Gillo's presence in the house reflect Eksgu's own position in the family and society?" Three required details: (1) Gillo is a "special kind of squirrel" brought from the forest — displaced like Eksgu from village to city; (2) Gillo is fed by everyone but belongs to no one — "not a pet of anyone" mirrors Eksgu's liminal caste status; (3) Gillo's death goes unmourned by the adults — only Eksgu notices, paralleling how Eksgu's suffering is invisible to the caste hierarchy. A weak answer would describe Gillo's cuteness or actions without linking to Eksgu — revealing the student cannot map symbolic parallels across the narrative.

## COMMON_MISCONCEPTION
Students believe inferential questions are "opinion questions" where any reasonable guess earns marks. They write answers like "Eksgu was brave because he went to the city" without citing the text — treating inference as imagination. In reality, board examiners award marks only for inferences *anchored* in textual evidence: the inference must be the *necessary conclusion* from specific quoted/paraphrased details, not a *possible* conclusion. For example, "Eksgu was brave" is weak; "Eksgu showed quiet resistance by continuing to study despite the headmaster's daily humiliation (text: 'Eksgu kept sitting on the cot... watching his helplessness') and his mother's pleas (text: 'Mother sent him to the city school')" is strong because the inference (quiet resistance) is *forced* by the evidence.

## ON_FAILURE
If a student cannot distinguish literal from inferential or writes evidence-free inferences: Step 1 — Give them a 3-sentence paragraph from the story. Ask them to highlight every fact that is *directly visible* in the sentences (literal layer). Step 2 — Ask: "What is *not* written but *must be true* given these facts?" Have them write the inference and draw arrows from each fact to the inference. Step 3 — Practice with one NCERT exercise question daily: first write "Literal facts I used:" then "My inference:" — this forces the two-step habit. Step 4 — Show them a 2-mark vs 5-mark answer side-by-side; the only difference is the evidence-inference chain.

## BUILDS_ON
c11_hin_ar_cbse_05_002 (Text: Plot and Narrative Structure) — students must know the sequence of events before they can extract facts or trace implications.

## LEADS_TO
c11_hin_ar_cbse_05_013 (Critical Thinking: Analysis and Interpretation) — inferential comprehension is the foundation for higher-order analysis of themes, symbols, and authorial intent.

## PREREQUISITE_NODE_IDS
c11_hin_ar_cbse_05_001, c11_hin_ar_cbse_05_002, c11_hin_ar_cbse_05_004, c11_hin_ar_cbse_05_010, c11_hin_ar_cbse_05_008, c11_hin_ar_cbse_05_009, c11_hin_ar_cbse_05_011

## PREREQUISITE_REASONS
c11_hin_ar_cbse_05_001: Context and background knowledge (caste system, rural-urban divide) is essential to make culturally grounded inferences.
c11_hin_ar_cbse_05_002: Plot knowledge provides the factual reservoir from which literal answers are drawn and inferential chains are built.
c11_hin_ar_cbse_05_004: Protagonist analysis supplies character-specific behavioral patterns that inform inferences about motivations.
c11_hin_ar_cbse_05_010: Vocabulary in context ensures students understand key terms (e.g., "izfr}a}h", "f=kyksd flag") literally before inferring their connotations.
c11_hin_ar_cbse_05_008: Comprehension questions often ask for effect of imagery/metaphor.  
c11_hin_ar_cbse_05_009: Inferential comprehension questions often ask 'What does X suggest?' — answered via symbolism/irony.  
c11_hin_ar_cbse_05_011: Comprehension questions require grammatical evidence (e.g., "How does the use of past habitual support the theme of unchanging tradition?").  

## FORWARD_NODE_IDS
c11_hin_ar_cbse_05_013, c11_hin_ar_cbse_05_014, c11_hin_ar_cbse_05_015, c12_hin_a_cbse_05_012, c12_hin_ar_cbse_04_012

## FORWARD_REASONS
c11_hin_ar_cbse_05_013: Critical thinking requires the ability to move from evidenced inferences to thematic generalizations and authorial critique.
c11_hin_ar_cbse_05_014: Writing skills tasks (e.g., character sketch, thematic essay) demand structured answers built on literal evidence and inferential reasoning.
c11_hin_ar_cbse_05_015: Inferential comprehension skills distinguish literal recall from discussion-worthy interpretation.  
c12_hin_a_cbse_05_012: Class 11 Chapter 5 specific comprehension practice with similar poetic style  
c12_hin_ar_cbse_04_012: अगला तार्किक चरण: Literal comprehension is the ability to extract explicitly stated facts, details, and sequences dire... इस नोड की अवधारणाओं को सीधे उपयोग/विस्तारित करता है।  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
none

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_05_002 -> c11_hin_ar_cbse_05_012 -> c11_hin_ar_cbse_05_013

## THIS_FORMULA
N/A - conceptual

## FORMULA_VARIABLES
N/A

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
linguistic

## CROSS_SUBJECT
c11_history_medieval_india | The story's depiction of caste-based occupational rigidity mirrors the historical jatis and varna hierarchy studied in medieval Indian social history — inferring Eksgu's trapped mobility requires understanding this historical structure.
c11_sociology_indian_society | The concept of "Sanskritization" and "dominant caste" (f=kyksd flag as village authority) from sociology explains the power dynamics the story only implies — inferential comprehension here directly applies sociological frameworks to literary analysis.

## PREREQ_CONCEPT
Ability to distinguish between explicitly stated information and implied meaning in a narrative text.

## PREREQ_BEFORE
Student must have read the full story "Xyrk Yksgk" at least once and completed the plot summary (c11_hin_ar_cbse_05_002).

## PREREQ_STUCK
If stuck, re-read the story marking every proper noun, dialogue, and physical action in one color, and every emotion-word or judgment in another — the first color is your literal bank, the second is where inferences begin.

## WORKED_EXAMPLE_1
PROBLEM: Answer the inferential question: "The author writes that Eksgu's mother 'did not want to send him to the city school, but circumstances forced her.' What were these 'circumstances'? Support with two textual evidences."

STEPS:
- Step 1: Identify the question type — "circumstances forced her" is not directly explained in one sentence; it requires synthesizing multiple plot points → inferential question.
- Step 2: Scan the text for mother's dialogues and actions related to Eksgu's education. Locate: (a) Father's death leaving family in debt; (b) Mother's conversation with Shastriji where she says "What will he do studying? He has to work"; (c) The turning point when Shastriji insists "Let him study, I will teach him."
- Step 3: Select two strongest evidences: Evidence 1 — "Father's death and the debt on the family" (explicit in the narrative exposition). Evidence 2 — "Shastriji's offer to teach for free and his argument that education is Eksgu's only way out of caste labor" (explicit in Shastriji's dialogue).
- Step 4: Connect evidences to the inference: The "circumstances" = economic desperation (father's death/debt) + unexpected opportunity (Shastriji's intervention). Neither alone forced her; the combination did.
- Step 5: Draft answer using the PEEL structure: Point — The circumstances were poverty after father's death and Shastriji's free tutoring offer. Evidence — Text states "Father's death left debt" and Shastriji said "I will teach him, no fees." Explanation — Poverty made schooling seem impossible; Shastriji's offer removed the cost barrier, forcing her hand. Link — This shows how structural poverty and individual agency intersect in Eksgu's life.

REASONING: This models the two-step method (extract → connect) and the PEEL answer structure required for 3-5 mark board questions. It forces the student to reject the vague "circumstances" and replace it with textually anchored specifics.

ANSWER: The 'circumstances' were the family's acute poverty after the father's death (leaving debts that made schooling unaffordable) combined with Shastriji's unexpected offer to teach Eksgu without fees. Evidence 1: The narrator states the father's death burdened the family with debt. Evidence 2: Shastriji tells the mother, "Let him study, I will teach him, no fees needed." The mother initially refuses ("What will he do studying? He must work"), but the zero-cost opportunity overrides her reluctance. This inference is necessary — not optional — because both facts are explicitly stated and jointly explain the change in her decision.

## WORKED_EXAMPLE_2
PROBLEM: Classify and answer: "Why does Eksgu not protest when the headmaster makes him fetch water and clean the office?"

STEPS:
- Step 1: Classify — "Why does he not protest?" asks for motivation, which is never directly stated → inferential.
- Step 2: Gather literal facts about Eksgu's behavior with the headmaster: (a) "Eksgu did not answer. He sat with head bowed." (b) "Eksgu kept sitting on the cot... watching his helplessness." (c) "Eksgu's silence was not weakness but the helplessness of one who knows his place." (d) Caste context from prerequisite node: Eksgu is from a lower caste; the headmaster is a dominant-caste authority.
- Step 3: Identify the inference chain: Fact (a) shows silence; Fact (b) shows awareness of powerlessness; Fact (c) narrator's comment explicitly names "helplessness of knowing his place"; Fact (d) provides the structural reason (caste hierarchy).
- Step 4: Synthesize: Eksgu doesn't protest because the caste system has internalized submission — protest is unimaginable, not just dangerous. The narrator's phrase "helplessness of knowing his place" is the key textual anchor.
- Step 5: Write board-style answer: Point — Eksgu's silence stems from internalized caste oppression, not consent. Evidence — Narrator describes his "helplessness of knowing his place" and his bowed head during the headmaster's thunderous commands. Explanation — In the village feudal order, a lower-caste boy challenging a dominant-caste headmaster is structurally impossible; the text shows Eksgu *aware* of this ("watching his helplessness"). Link — This silence contrasts with his later quiet resistance through education, making his final act of touching Shastriji's feet a reclamation of dignity.

REASONING: This example demonstrates how to use narrator commentary (often overlooked) as textual evidence for inference, and how to integrate cross-node knowledge (caste context from c11_hin_ar_cbse_05_001) without importing outside information.

ANSWER: Eksgu does not protest because the caste-feudal structure has made resistance unthinkable for him — his silence reflects the "helplessness of knowing his place" (narrator's explicit comment). Textual evidence: (1) "Eksgu did not answer, sat with head bowed" when ordered; (2) Narrator states his silence came from "helplessness of knowing his place"; (3) He watches his own helplessness, showing conscious awareness, not ignorance. The inference is forced: in a village where the headmaster embodies dominant-caste authority, a lower-caste child's protest would invite violent retribution, so silence is survival.

## WORKED_EXAMPLE_3
PROBLEM: A board exam question asks: "The story ends with Eksgu touching Shastriji's feet after his death. Explain the significance of this act in the context of the entire story. (5 marks)"

STEPS:
- Step 1: Recognize this as a high-stakes inferential question requiring synthesis across the whole narrative — "significance in context of entire story" demands multiple evidence strands.
- Step 2: Map the story arc for Eksgu-Shastriji relationship: (a) Beginning: Shastriji teaches by letting Eksgu overhear ("I don't teach, you learn"); (b) Middle: Shastriji defends Eksgu against headmaster ("He is my student"); (c) End: Shastriji dies; Eksgu touches feet — a ritual for guru, not just teacher.
- Step 3: Identify three thematic threads to weave: Thread 1 — Education as dignity (contrast with headmaster's school where Eksgu is servant). Thread 2 — Guru-shishya parampara transcending caste (Shastriji teaches a lower-caste boy freely). Thread 3 — Silent resistance (Eksgu never speaks much; his final act speaks).
- Step 4: Select precise textual anchors for each thread: Thread 1 — "Eksgu learned by listening, not by being taught" + headmaster's "fetch water" orders. Thread 2 — Shastriji's "I will teach him, no fees" + "He is my student" to headmaster. Thread 3 — Eksgu's repeated silence + final act described as "touched feet with reverence."
- Step 5: Structure the 5-mark answer using PEEL × 3 (one paragraph per thread) + concluding synthesis.
- Step 6: Verify each paragraph has Point, Evidence (quote/paraphrase), Explanation, Link to central theme (dignity through education).

REASONING: This models the multi-thread synthesis required for 5-mark questions. It shows how to break a big inferential question into manageable thematic strands, each grounded in specific textual moments, then weave them into a coherent argument — the hallmark of senior secondary analytical writing.

ANSWER: The act signifies three interconnected meanings: (1) **Education as dignity**: Unlike the headmaster's school where Eksgu fetches water, Shastriji's teaching — "I don't teach, you learn" — lets Eksgu claim knowledge on his own terms. Touching feet honors this dignity. (2) **Guru-shishya bond transcending caste**: Shastriji, a Brahmin, teaches a lower-caste boy free ("no fees") and claims him publicly ("He is my student"). Eksgu's act affirms this rare caste-transcending relationship. (3) **Silent resistance made visible**: Eksgu's silence before the headmaster was submission; his silence before Shastriji was absorption. The final touch transforms silence into ritual acknowledgment — "He touched feet with reverence" — making his resistance legible. Together, the act crowns the story's central argument: true education liberates not by certificates but by restoring human dignity.

## COMPETENCY_QUESTION_1
QUESTION: Read the following extract from the story and answer the question that follows:

"Eksgu sat on the cot. The headmaster's voice thundered. 'Eksgu! Bring water!' Eksgu did not move. He did not speak. He watched his own helplessness."

Question: The phrase "watched his own helplessness" is an example of which literary device? How does this device deepen the reader's understanding of Eksgu's internal state at this moment? Support with one additional textual detail from elsewhere in the story.

COMPETENCY: Literary device identification + inferential application to character analysis

STEPS:
- Step 1: Identify the device — "watched his own helplessness" personifies helplessness as an observable object; this is **personification** (or metaphorical objectification).
- Step 2: Explain the effect — It shows Eksgu is not merely feeling helpless; he is *conscious* of his helplessness as a separate, external reality. He observes himself from outside — a moment of split self-awareness.
- Step 3: Find supporting textual detail — Later, when Shastriji dies, "Eksgu touched his feet with reverence" — this deliberate, chosen action contrasts with the frozen helplessness here, proving the earlier moment was awareness, not paralysis.
- Step 4: Synthesize — The device marks the turning point where internalized oppression becomes visible to the character himself, setting up his later quiet resistance.

ANSWER: The phrase uses **personification** (treating the abstract 'helplessness' as a tangible thing one can watch). This deepens understanding by revealing Eksgu's **metacognitive awareness** — he doesn't just suffer; he *sees* himself suffering, creating a critical distance between his self and his circumstance. Supporting detail: In the final scene, Eksgu "touched Shastriji's feet with reverence" — a voluntary, dignified act that would be impossible if he were merely paralyzed by helplessness. The contrast proves the personification marks the birth of his conscious resistance.

DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: The NCERT textbook includes this exercise question: "Eksgu's life moves between two worlds — the village and the city. What is the significance of this movement? Discuss." A student writes: "Eksgu goes to the city to study. In the city he learns many things. Then he comes back to the village. This movement shows he got education." Evaluate this answer. Identify three specific weaknesses and rewrite the answer to meet Class 11 board standards (approximately 80-100 words).

COMPETENCY: Critical evaluation of peer response + structured answer writing (PEEL synthesis)

STEPS:
- Step 1: Identify Weakness 1 — The answer is purely literal narration ("goes to city, learns, comes back"); zero inference about "significance."
- Step 2: Identify Weakness 2 — No textual evidence cited (no quotes, no specific incidents).
- Step 3: Identify Weakness 3 — Misses the central tension: the city doesn't liberate him; he returns to the same caste reality, making the movement *cyclical and tragic*, not progressive.
- Step 4: Draft improved answer using three inferential threads: (a) City = temporary escape from caste labor but not from caste identity (evidence: headmaster's mockery follows him mentally). (b) Village = structural trap where education has no economic value (evidence: Shastriji's death leaves Eksgu with knowledge but no livelihood). (c) Movement = irony — physical mobility without social mobility (evidence: final scene, Eksgu still in village, touching feet of dead guru).
- Step 5: Condense to 80-100 words with PEEL flow.

ANSWER: The village-city movement signifies **the illusion of mobility under caste feudalism**. **Point 1**: The city offers temporary anonymity — Eksgu learns under Shastriji ("I don't teach, you learn") — but the headmaster's mocking prophecy ("One day he'll be a big officer") reveals the dominant caste's disbelief in his escape. **Evidence**: Shastriji's free teaching contrasts with headmaster's servitude orders. **Point 2**: Return to village exposes education's futility in a caste economy — Shastriji dies, leaving Eksgu with knowledge but no livelihood. **Evidence**: Final scene shows Eksgu still in village, touching his dead guru's feet. **Point 3**: The cycle is ironic — physical movement without structural mobility. **Synthesis**: The movement maps the tragedy of individual aspiration crushed by social structure.

DIFFICULTY: hard