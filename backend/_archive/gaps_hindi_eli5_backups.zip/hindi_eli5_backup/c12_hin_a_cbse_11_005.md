## DEFINITION
Supporting characters are figures in a narrative who are not the central protagonist but interact with them to advance the plot, reveal the protagonist's traits, embody thematic ideas, or provide social context. In Premchand's three stories in this chapter, each supporting character serves a distinct structural purpose: the father and inspector in "ckyd cp x;k" represent authority and tradition; the astronomers, historians, and geographers in "?kM+h osQ iq”ksZ" personify competing epistemologies of time; the three fruits, gardener, old woman, and child in "<sys pqu yks" function as allegorical voices debating life's purpose.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student can independently identify every supporting character across the three stories, cite specific textual evidence (dialogue, action, description) for each, explain how that character influences the protagonist's journey or the story's thematic argument, and compare the narrative function of supporting characters across the three stories.

## SCOPE_BOUNDARY
This node covers only the supporting characters in the three prescribed stories ("ckyd cp x;k", "?kM+h osQ iq”ksZ", "<sys pqu yks") from Chapter 11 of Class 12 Hindi Antra. It does not cover the protagonist (dealt with in c12_hin_a_cbse_11_004), nor does it address themes, literary devices, or writing skills which are separate nodes.

## WALKTHROUGH
Imagine you are reading "ckyd cp x;k" and you wonder why the father slaps the boy immediately after the inspector leaves — what does that moment tell us about the father's internal conflict? Begin by listing every named or described figure who is not the narrator/protagonist. For each, note: (1) their first appearance, (2) their key dialogue or action, (3) their relationship to the protagonist, and (4) the idea they embody (tradition, scientific rationality, temptation, innocence). Then ask: if this character were removed, what would the story lose? That question forces you to see their structural necessity, not just their presence.

## DIAGNOSTIC_QUESTION_1
In "ckyd cp x;k", who is the inspector (vè;kid) and what single question does he repeatedly ask the boy?

## DIAGNOSTIC_ANSWER_1
The inspector is a school official conducting an examination; he repeatedly asks the boy "rw D;k djsxk" (what will you do?). A wrong answer (e.g., "he is the boy's father") reveals the student cannot distinguish between institutional authority and familial authority, a confusion that blurs the story's critique of colonial education.

## DIAGNOSTIC_QUESTION_2
Explain in your own words why the narrator says "ckyd cp x;k" (the boy ran away) at the end of the first story, linking it to the boy's answer "eSa ;koTtUe yksdlsok d:¡ xk".

## DIAGNOSTIC_ANSWER_2
The boy's answer — "I want to become a servant of the country" — rejects the inspector's colonial framework (which expected a career like clerk or lawyer) and the father's material aspirations. The narrator uses "cp x;k" metaphorically: the boy escapes the predefined roles. A student who says "he physically ran out of the room" misses the symbolic escape and shows literal-level comprehension only.

## DIAGNOSTIC_QUESTION_3
In "?kM+h osQ iq”ksZ", the author lists astronomers, historians, and geographers as "osn'kkL=kK èkekZpk;ks±". Apply the concept of 'personification of epistemology' to explain what each group represents in the debate on time.

## DIAGNOSTIC_ANSWER_3
Astronomers represent cyclic, measurable time (planetary motion); historians represent linear, event-driven time (cause-effect); geographers represent spatialized time (distance/travel). A wrong assignment (e.g., "historians measure seconds") shows the student cannot map abstract disciplines to their temporal metaphors, a skill needed for Board's long-answer questions on this essay.

## DIAGNOSTIC_QUESTION_4
Compare the function of the father in "ckyd cp x;k" with the function of the gardener (mali) in "<sys pqu yks". How do both characters mediate between the protagonist and society's expectations?

## DIAGNOSTIC_ANSWER_4
The father enforces societal expectations (colonial career, obedience) through violence; the gardener presents nature's neutral bounty (three fruits) and lets the chooser decide. Both are gatekeepers, but the father closes options while the gardener opens them. A student who only describes their actions (slapping vs offering fruit) without analyzing their structural role as "mediators of expectation" fails the analytical demand.

## DIAGNOSTIC_QUESTION_5
Evaluate the author's choice to make the three fruits in "<sys pqu yks" speak in first person. Does this strengthen or weaken the allegory? Justify with two textual reasons.

## DIAGNOSTIC_ANSWER_5
It strengthens the allegory because (1) each fruit articulates its own philosophy directly (power, knowledge, pleasure) without narrator filtration, making the debate immediate; (2) the first-person voices create dramatic tension when the chooser must reject two. A student who says "it's just a story device" cannot defend the artistic choice, a common Board competency trap.

## DIAGNOSTIC_QUESTION_6
Create a one-paragraph ending for "ckyd cp x;k" where the boy meets the inspector again ten years later. The boy must speak in a way that echoes his original answer "eSa ;koTtUe yksdlsok d:¡ xk" but shows growth. Write the dialogue only.

## DIAGNOSTIC_ANSWER_6
A strong answer will have the boy reference his past words, show concrete service (teaching, healing, organizing), and retain the idealistic core while acknowledging complexity. A weak answer merely repeats the original line or makes the boy a high-ranking officer, missing the nuance that "yksdlsok" (servant of people) is not a job title but a stance.

## COMMON_MISCONCEPTION
Students treat supporting characters as "background decoration" and only describe their physical traits or plot actions. For example, they write "the old woman in <sys pqu yks gives advice" without analyzing that she embodies traditional wisdom that contradicts the fruit of power. This error stems from Class 10's focus on character sketches (appearance, nature) rather than Class 12's demand for functional analysis (what narrative work does this character do?). The Board marking scheme awards zero marks for mere description; full marks require linking the character to theme, structure, or protagonist's development.

## ON_FAILURE
If a student cannot move beyond description, assign this 3-step remediation: (1) Re-read c11_hin_ar_cbse_11_005 (Class 11 Supporting Characters) focusing on the "narrative function" column in the worked examples. (2) For each supporting character in the three stories, complete a 4-row table: Character | Key Action/Dialogue | Effect on Protagonist | Thematic Idea Represented. (3) Write a 100-word paragraph for one character using the PEEL structure (Point, Evidence, Explanation, Link to theme). Re-diagnose with Diagnostic Question 4.

## BUILDS_ON
Character Analysis: Protagonist (c12_hin_a_cbse_11_004) — understanding the central figure is prerequisite to seeing how others reflect, challenge, or complement them.

## LEADS_TO
Theme: Primary Theme and Message (c12_hin_a_cbse_11_006) — supporting characters are the primary vehicles through which Premchand articulates his thematic arguments about education, time, and life choices.

## PREREQUISITE_NODE_IDS
c12_hin_a_cbse_11_004, c12_hin_a_cbse_11_002, c11_hin_ar_cbse_11_005, c12_hin_a_cbse_11_003

## PREREQUISITE_REASONS
c12_hin_a_cbse_11_004: Protagonist analysis provides the reference point against which supporting characters are defined.
c12_hin_a_cbse_11_002: Plot structure knowledge helps locate where each supporting character enters and exits the narrative arc.
c11_hin_ar_cbse_11_005: Class 11 introduced the terminology (foil, confidant, allegorical figure) used here at higher depth.
c12_hin_a_cbse_11_003: Supporting characters (teacher, watchmaker, observer) are defined by their relationship to setting  
## FORWARD_NODE_IDS
c12_hin_a_cbse_11_006, c12_hin_a_cbse_11_013, c12_hin_a_cbse_11_014, c12_hin_a_cbse_11_007, c12_hin_a_cbse_11_012, c12_hin_a_cbse_11_015

## FORWARD_REASONS
c12_hin_a_cbse_11_006: Themes emerge from the clash of characters; supporting character analysis directly feeds thematic interpretation.
c12_hin_a_cbse_11_013: Critical thinking questions often ask "compare the role of X in story A with Y in story B" — this node builds that comparative skill.
c12_hin_a_cbse_11_014: Writing tasks (character sketch, thematic essay) require the evidence-gathering and analytical phrasing practiced here.
c12_hin_a_cbse_11_007: Supporting characters (teacher, father, narrator in other stories) voice or embody secondary themes.  
c12_hin_a_cbse_11_012: Supporting characters provide clues for inference.  
c12_hin_a_cbse_11_015: Supporting characters offer counter‑perspectives in dialogue.  

## CROSS_SUBJECT_PREREQS
c11_hin_ar_cbse_11_005

## CROSS_SUBJECT_REASONS
c11_hin_ar_cbse_11_005: Reinforces the same analytical framework (identify → evidence → function → theme) in a different textual context, ensuring transfer.
c11_hin_v_cbse_11_005: Vitan's non-fiction pieces use real people as "supporting characters" in arguments, bridging literary analysis to rhetorical analysis.

## CHAIN_DESCRIPTION
c12_hin_a_cbse_11_004 -> c12_hin_a_cbse_11_005 -> c12_hin_a_cbse_11_006

## THIS_FORMULA
N/A - conceptual

## FORMULA_VARIABLES
N/A

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
analytical

## CROSS_SUBJECT
N/A | The father in "ckyd cp x;k" embodies colonial-era parental anxiety about government jobs — a direct link to history's "impact of colonial education on Indian families".
 N/A | The three fruits in "<sys pqu yks" map onto Freud's id (pleasure), ego (power), superego (knowledge) — a concrete literary illustration of personality structure.
## PREREQ_CONCEPT
Narrative function of character: every named figure must perform structural work (advance plot, reveal protagonist, embody idea).

## PREREQ_BEFORE
Student has read all three stories at least once and can list at least three supporting characters per story without looking at the text.

## PREREQ_STUCK
If unable to list characters, re-read the stories with a highlighter marking every new name/role; then review c11_hin_ar_cbse_11_005's "character inventory" technique.

## WORKED_EXAMPLE_1
PROBLEM: Analyze the narrative function of the father (firk) in "ckyd cp x;k" using textual evidence.
STEPS:
- Step 1: Identify every appearance of the father — he appears in the examination hall, slaps the boy, drags him home, and is described through the narrator's observation of his "mYykl" (fist) and "ân;" (anger).
- Step 2: Categorize his actions: physical violence (slap, drag), verbal silence (he doesn't speak, only acts), and symbolic role (he brings the boy to the inspector, representing family's investment in colonial success).
- Step 3: Link each action to the protagonist (the boy) — the slap silences the boy's idealistic answer; the drag restores him to the father's world of material expectation.
- Step 4: Connect to theme — the father personifies "tradition enforced by force", contrasting with the boy's "idealism expressed in words". The story's central conflict (idealism vs pragmatism) is externalized in this relationship.
- Step 5: Verify against the text's closing image — the narrator notes the father's anger ("firk dk ân; mYykl ls Hkj jgk Fkk") while the boy is already gone ("ckyd cp x;k"), confirming the father's failure to contain the new idea.
REASONING: This 5-step method (inventory → categorize → link → thematicize → verify) mirrors the Board's expected answer structure: point, evidence, explanation, thematic link.
ANSWER: The father functions as the embodiment of colonial-era paternal authority that equates education with employment. His violence is not personal cruelty but structural enforcement — he has no dialogue because his role is to act, not reason. The boy's escape ("cp x;k") is simultaneously a physical departure and a symbolic rejection of this authority. The narrator's final focus on the father's clenched fist underscores that the old order holds power but not the future.

## WORKED_EXAMPLE_2
PROBLEM: Explain how the three fruits in "<sys pqu yks" serve as allegorical supporting characters rather than mere plot devices.
STEPS:
- Step 1: List the three fruits with their self-declared identities: lksus (power), pk¡nh (knowledge), yksgs (pleasure). Note each speaks in first person ("vdM+ck”k lksus dks pqurk gS", "yksHkh dks pk¡nh dh fiVkjh va[kwBk fn[kkrh gS").
- Step 2: Identify the choice architecture — the gardener offers all three equally ("blesa ls ,d mBk ys"), making the chooser's values the decisive factor.
- Step 3: Map each fruit to a philosophical stance: lksus = political/military power (vdM+us okyk), pk¡nh = intellectual/ascetic pursuit (vius iSQlys dks gh lgh ekuus okyk), yksgs = hedonistic/aesthetic enjoyment (mldh izfrewfrZ gSA).
- Step 4: Show how the chooser's rejection of two fruits reveals his character — he chooses the fruit of pleasure (yksgs) but the old woman warns "elku dh e^h dks gkFk yxkuk cM+k v'kqHk Fkk", introducing consequence.
- Step 5: Conclude that the fruits are not passive objects; they argue, persuade, and warn — they are dramatized ideas. Their supporting role is to externalize the internal debate every human faces.
REASONING: Allegorical characters require decoding (symbol → idea) and then evaluating their dramatic interaction. This step-by-step decoding is exactly what CUET/Hindi elective long answers demand.
ANSWER: The three fruits are personified ideologies. Power (lksus) demands dominance, Knowledge (pk¡nh) demands self-referential truth, Pleasure (yksgs) demands immediate fulfillment. The gardener's neutral offer and the old woman's warning about the "fruit of intoxication" (elku) frame the choice as moral, not arbitrary. By making the fruits speak, Premchand turns an abstract philosophical triad into a dramatic confrontation, forcing the protagonist (and reader) to adjudicate. This is the story's central structural innovation.

## WORKED_EXAMPLE_3
PROBLEM: Compare the inspector in "ckyd cp x;k" and the astronomers/historians/geographers in "?kM+h osQ iq”ksZ" as representatives of institutional knowledge. What does Premchand suggest about the relationship between institutional knowledge and individual truth?
STEPS:
- Step 1: Define the inspector's knowledge — he holds the official questionnaire, expects standardized answers, represents the colonial state's definition of a "useful" citizen.
- Step 2: Define the three disciplinary groups' knowledge — each claims exclusive authority over time (cyclic, linear, spatial), but the author shows all are partial ("èkeZ vxj oqQN fo'ks"k yksxksa ... dh eq_h esa gS rks vke vkneh ... mlosQ fodkl ,oa foLrkj dk |ksrd gSA").
- Step 3: Contrast their interaction with the individual — the inspector silences the boy (boy's answer is "thfor o`{k osQ gjs iÙkksa dk eèkqj eeZj"); the disciplines are challenged by the narrator's rhetorical questions ("rqEgsa blls D;k\") which assert individual lived experience over expert monopoly.
- Step 4: Synthesize — both stories depict institutions (school, academia) as attempting to colonize the individual's interiority. The boy's escape and the narrator's assertion that "èkeZ dk jgL; tkuuk flI+kZQ èkekZpk;ks± dk dke ugha" are parallel acts of epistemic resistance.
- Step 5: Formulate the thematic claim — Premchand positions institutional knowledge as necessary but insufficient; it becomes oppressive when it denies the individual's right to interpret their own existence. Supporting characters (inspector, experts) are the instruments of that denial.
- Step 6: Check against Board competency — this comparison integrates character analysis, thematic synthesis, and authorial intent, hitting all three assessment objectives.
REASONING: Cross-story comparison is a higher-order skill explicitly tested in Board's "Critical Thinking" and CUET's "Comparative Analysis" questions. The 6-step scaffold ensures no element is missed.
ANSWER: Both the inspector and the disciplinary experts function as gatekeepers of sanctioned knowledge. The inspector enforces a colonial vocational script; the experts parcel time into measurable, linear, or spatial units, each claiming totality. In both stories, the narrator/protagonist resists: the boy by refusing the script ("yksdlsok"), the essayist by declaring time-knowledge everyone's birthright ("dksbZ Hkh O;fDr vius Lrj ij ml jgL; dks tkuus dh dksf'k'k dj ldrk gS"). Premchand's message: institutions produce useful categories, but they become tyrannical when they mistake their map for the territory. Supporting characters are the human faces of that tyranny.

## COMPETENCY_QUESTION_1
QUESTION: In "?kM+h osQ iq”ksZ", the author writes "èkeZ dk jgL; tkuuk flI+kZQ èkekZpk;ks± dk dke ugha] dksbZ Hkh O;fDr vius Lrj ij ml jgL; dks tkuus dh dksf'k'k dj ldrk gS". Choose ONE supporting character from the other two stories who would agree with this statement and ONE who would disagree. Justify each choice with a specific action or line from the text.
COMPETENCY: Intertextual character analysis and thematic reasoning
STEPS:
- Step 1: Recall the statement's core claim — time-knowledge is democratized, not expert property.
- Step 2: Select a character who embodies democratized knowledge — the boy (ckyd) in "ckyd cp x;k" who asserts his own future ("eSa ;koTtUe yksdlsok d:¡ xk") without waiting for the inspector's approval.
- Step 3: Select a character who embodies expert monopoly — the father (firk) who uses physical force to impose his vision of the boy's future, mirroring the inspector's institutional force.
- Step 4: Cite evidence: boy's answer (direct quote); father's slap and drag (action).
- Step 5: Write a structured paragraph linking both to the statement.
ANSWER: The boy (ckyd) agrees — he claims the right to define his own time/future ("eSa ;koTtUe yksdlsok d:¡ xk") against the inspector's expert questionnaire. The father disagrees — he physically enforces his own temporal plan for the boy (slap, drag home), acting exactly like the "flI+kZQ èkekZpk;ks±" who think they own time-knowledge. Premchand uses both supporting characters to dramatize the essay's abstract argument.
DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: "Supporting characters in Premchand's trilogy are not individuals but arguments in disguise." Evaluate this claim by analyzing any TWO supporting characters from DIFFERENT stories. Your answer must: (a) name the argument each character embodies, (b) show how the character's dialogue/actions advance that argument, and (c) explain what the narrative loses if the character is removed.
COMPETENCY: Critical evaluation of characterization as ideological dramatization
STEPS:
- Step 1: Choose two characters from different stories (e.g., the old woman in "<sys pqu yks" and the inspector in "ckyd cp x;k").
- Step 2: For each, articulate the argument: old woman = "pleasure without responsibility leads to ruin"; inspector = "education must serve state manpower needs".
- Step 3: Map textual evidence: old woman's warning "elku dh e^h dks gkFk yxkuk cM+k v'kqHk Fkk" and prediction of consequences; inspector's repeated "rw D;k djsxk" and rejection of the boy's answer.
- Step 4: Hypothesize removal: without old woman, the choice of pleasure fruit becomes unproblematic, collapsing the moral tension; without inspector, the boy's answer has no antagonist, making his escape unearned.
- Step 5: Conclude whether the claim holds — yes, because each character's sole narrative function is to voice and enact a specific ideological position.
ANSWER: The claim is largely accurate. The old woman in "<sys pqu yks" embodies the argument that hedonism (yksgs) carries hidden costs (elku → C;kgh → ?kj elku). Her dialogue is entirely didactic — she exists to articulate consequence. Remove her, and the chooser's selection of the pleasure fruit becomes a happy ending, destroying the story's cautionary design. The inspector in "ckyd cp x;k" embodies the colonial argument that education = employability. His mechanical questioning ("rw D;k djsxk") and dismissal of the boy's idealism ("thfor o`{k osQ gjs iÙkksa dk eèkqj eeZj") stage the conflict. Remove him, and the boy's declaration has no institutional resistance, reducing a political act to a private fantasy. In both cases, the character is a dramatized premise, not a psychological portrait.
DIFFICULTY: hard