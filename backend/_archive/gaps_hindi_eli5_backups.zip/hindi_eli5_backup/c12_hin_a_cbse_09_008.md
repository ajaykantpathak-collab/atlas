## DEFINITION
Imagery (चित्रात्मकता) is the use of vivid, sensory language that appeals to the five senses (sight, sound, smell, touch, taste) to create mental pictures and evoke physical sensations in the reader. Metaphor (रूपक/उपमा बिना 'जैसे/वैसे' के) is a figure of speech that directly equates two unlike things by stating one *is* the other, transferring qualities from the vehicle (source) to the tenor (target) without using comparative words like 'like' or 'as'. In Class 12 Hindi poetry analysis, identifying these devices requires moving beyond mere spotting to explaining *how* the sensory detail or the implied comparison constructs the poem's emotional core and thematic argument.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student must be able to: (1) independently annotate a stanza from the prescribed poems, marking specific words/phrases that function as visual, auditory, tactile, olfactory, or gustatory imagery; (2) identify at least two metaphors per poem, naming the tenor and vehicle for each; (3) write a 60-80 word board-style explanation linking the *specific* device to the *specific* theme (e.g., separation, devotion, timelessness) using the PEEL structure (Point, Evidence, Explanation, Link).

## SCOPE_BOUNDARY
This node covers **only** the identification, classification, and thematic function of **Imagery (all five senses)** and **Metaphor (explicit and implicit)** in the two poems by Kukuan (कुकुआन) in Chapter 9 of Antra. It does **not** cover Simile (उपमा), Personification (मानवीकरण), Irony (व्यंग्य), Symbolism (प्रतीकवाद), or Sound Devices (alliteration, onomatopoeia) — these are handled in sibling nodes (c12_hin_a_cbse_09_009, c12_hin_a_cbse_09_011). It assumes the student has already grasped the literal meaning (c12_hin_a_cbse_09_012) and themes (c12_hin_a_cbse_09_006, c12_hin_a_cbse_09_007).

## WALKTHROUGH
Imagine you are sitting in the exam hall and the question reads: *"कुकुआन के पदों में विरह-वेदना को व्यक्त करने के लिए प्रयुक्त दो बिंबों/रूपकों की व्याख्या कीजिए।"* (Explain two images/metaphors used by Kukuan to express the pain of separation). Most students freeze because they try to memorize "answers" instead of learning a **process**. Here is your process: **Step 1:** Read the stanza aloud softly — Braj Bhasha's musicality reveals auditory imagery you miss when reading silently. **Step 2:** Circle every noun/adjective that triggers a sensory response (e.g., "नच्यौ" = visual movement, "बाजत" = sound). **Step 3:** For each circled word, ask: "What sense does this hit?" Label it V/A/T/O/G. **Step 4:** Hunt for "A is B" constructions where no 'जैसे' exists (e.g., "प्रेम पंथ" — love *is* a path). That's your metaphor. **Step 5:** Connect: "The tactile imagery of 'burning' (दहत) in the first poem transforms abstract grief into physical agony, reinforcing the theme of love as embodied suffering." Practice this 5-step loop on *every* stanza until it becomes automatic.

## DIAGNOSTIC_QUESTION_1
Define 'Imagery' (बिंब/चित्रात्मकता) and 'Metaphor' (रूपक) in your own words. Give one example of each from *any* Hindi poem you have studied (not necessarily Kukuan).

## DIAGNOSTIC_ANSWER_1
**Correct Answer:** Imagery is descriptive language appealing to the senses (e.g., "काली घटा छाई" — visual). Metaphor is an implicit comparison where one thing is called another (e.g., "जीवन एक संघर्ष है" — life *is* a struggle). **What a wrong answer reveals:** If a student gives a simile ("जीवन संघर्ष *जैसा* है") as a metaphor, they confuse explicit vs. implicit comparison. If they only give visual examples for imagery, they ignore the other four senses — a major gap because Kukuan heavily uses tactile (burning, touching) and auditory (flute, anklets) imagery.

## DIAGNOSTIC_QUESTION_2
In the first poem of Kukuan (starting "चगु फनुक दिस..."), the line "डग डग बाजत घुंघरू" appears. Identify the **type of imagery** here and explain **why** the poet chooses *this specific sense* to describe the beloved's movement, rather than just saying "she walked beautifully."

## DIAGNOSTIC_ANSWER_2
**Correct Answer:** This is **auditory imagery** (sound of anklets). The poet chooses sound over sight because in the *purdah*/*veil* context of Braj culture, the beloved's face/body may be hidden, but her *presence* is announced by sound. It also suggests the lover hears her before seeing her — heightening anticipation. **What a wrong answer reveals:** A student writing "visual imagery because it describes her walking" misses the word "बाजत" (jingling/sounding). This shows they hunt for keywords ("घुंघरू" = ornament) instead of analyzing the *verb* ("बाजत" = making sound). They also miss the cultural context (veil/separation) which is central to Kukuan's poetry.

## DIAGNOSTIC_QUESTION_3
**APPLY:** The second poem contains the line: "एक सूं लखन न लागै, दूजी सूं लखन जाय।" (One way: not seen; other way: seen/gone). Identify the **metaphor** hidden in this structure. Name the **Tenor** (target) and **Vehicle** (source). Explain what quality of the vehicle is transferred to the tenor.

## DIAGNOSTIC_ANSWER_3
**Correct Answer:** Metaphor: **The beloved's glance/attention is a "direction" or "path" (दिशा/मार्ग).** Tenor: Beloved's glance/attention. Vehicle: A physical path/direction (एक सूं/दूजी सूं). Transferred quality: **Irrevocability and binary finality** — just as a path either leads to the destination or away from it with no middle ground, the beloved's glance either grants union (दर्शन) or confirms separation (विरह). **What a wrong answer reveals:** Students often say "Metaphor: Life is a path" — importing a cliché from other poems. They fail to ground the tenor/vehicle in *this specific line's grammar* ("लागै/जाय" — takes effect/departs). They also miss the "binary" quality (एक/दूजी) which is the core of the metaphor's power.

## DIAGNOSTIC_QUESTION_4
**ANALYZE:** Compare the **dominant sensory imagery** in Poem 1 (first stanza) vs. Poem 2 (first stanza). Poem 1: "चगु फनुक दिस... डग डग बाजत घुंघरू". Poem 2: "वकुदकुह वजलह फुगफजक्स..." (dialogue starts). Which sense dominates each? Why does the poet shift the sensory mode between the two poems?

## DIAGNOSTIC_ANSWER_4
**Correct Answer:** Poem 1 dominates in **auditory + visual** (sound of anklets, sight of gait). Poem 2 dominates in **auditory + tactile** (spoken words "वकुदकुह", "वजलह" = harsh speech; "फुगफजक्स" = trembling/shivering body). **Shift Reason:** Poem 1 is the *lover's external observation* of the beloved (beauty perceived from outside → sight/sound). Poem 2 is the *beloved's internal experience* of speaking harsh words and feeling the physical tremors of anger/grief (internal reality → voice/touch). The shift mirrors the shift from **objectification** (poem 1) to **subjectivity** (poem 2). **What a wrong answer reveals:** Listing "visual for both" or "auditory for both" shows the student treats imagery as a checklist, not a perspective tool. They miss that Kukuan uses sensory mode to signal **narrative voice** — a key Class 12 analytical skill.

## DIAGNOSTIC_QUESTION_5
**EVALUATE:** A student writes: *"Kukuan's metaphor 'प्रेम पंथ' (path of love) in the intro note is the most effective metaphor in the chapter because it summarizes the whole theme."* Critique this statement. Is it accurate? Is it sufficient for a 3-mark board answer? What is missing?

## DIAGNOSTIC_ANSWER_5
**Correct Answer:** **Inaccurate & Insufficient.** (1) "प्रेम पंथ" appears in the *introductory note* (not in the poem text) — board exams require evidence *from the poem lines*. (2) It's a **dead metaphor** (lexicalized cliché), not a fresh poetic device crafted in the verse. (3) A 3-mark answer needs: **Specific line reference** + **Tenor/Vehicle naming** + **Effect on theme** (e.g., "In stanza 2, 'एक सूं... दूजी सूं' metaphorizes the glance as a binary path, making separation feel like a structural inevitability, not just an emotion"). **What a wrong answer reveals:** The student cannot distinguish between *paratext* (intro) and *text* (poem), a fatal error in source-based questions. They also confuse "theme summary" with "poetic device analysis" — they explain *what* the poem says, not *how* it says it.

## DIAGNOSTIC_QUESTION_6
**CREATE:** Write a 4-line stanza in Hindi (Khari Boli or Braj) on the theme **"Waiting for a message from a friend"**. You **must** use: (a) one **olfactory** (smell) imagery, (b) one **tactile** (touch) imagery, (c) one **metaphor** where the *waiting* is the tenor. Do not use 'जैसे/वैसे'.

## DIAGNOSTIC_ANSWER_6
**Expected Answer Criteria:** (1) Olfactory: e.g., "स्याही की गंध लिए हवा" / "बारिश की मिट्टी की खुशबू". (2) Tactile: e.g., "उंगलियाँ स्क्रीन पर ठंडी" / "कलम का भार भारी". (3) Metaphor: "इंतज़ार एक सूखा कुआँ है" / "प्रतीक्षा चुप्पी की दीवार है". **Good answer example:**
> डाकिए की साइकिल की घंटी, **मिट्टी की गंध** लाए (Olfactory)
> **उंगलियाँ काँपें** खाली जेब की **ठंडक** में (Tactile)
> **इंतज़ार एक बेनाम चिट्ठी है** जो कभी न आए (Metaphor: Waiting = Nameless letter)
> आँखें रास्ते पर, दिल दहलीज़ पर। **What a poor answer reveals:** Using simile ("इंतज़ार *जैसे* कुआँ है") fails the constraint. Only visual imagery ("रास्ता देखते आँखें थकी") shows sensory poverty. A metaphor where the vehicle is abstract ("इंतज़ार दुःख है") fails to transfer concrete qualities — the metaphor must be *concrete* to be evocative.

## COMMON_MISCONCEPTION
**Misconception:** "Imagery = Visual description only. Metaphor = Any comparison." **Why students make this error:** (1) Textbooks often illustrate imagery with pictures, reinforcing "image = visual". (2) In lower classes, "रूपक" is taught as a broad category including simile, so students don't internalize the *absence of comparative particles* as the defining feature. (3) In Braj Bhasha, archaic words (e.g., "फनुक", "वकुदकुह") obscure the verb/adjective that carries the sensory mode, so students guess based on nouns. **Concrete Example:** A student writes: *"कुकुआन ने 'घुंघरू' का दृश्य बिंब दिया है"* (Kukuan gave a visual image of anklets). **Why it's wrong:** "घुंघरू" is a noun (object), but the imagery is in "बाजत" (jingling — auditory verb). The student sees the *object* and assumes *visual*, ignoring the *action* that activates the sense. This loses 1 mark for "wrong classification" and 1 mark for "missing auditory emphasis on hidden beloved".

## ON_FAILURE
**Remediation Path (3 Steps):** 1. **Revisit Class 11 Node:** Go to `c11_hin_ar_cbse_09_008` (Literary Devices: Imagery and Metaphor). Re-do the "Sense-Mapping Exercise" there — take 5 poems, list 3 sensory words per poem, label V/A/T/O/G. Do this until you get 15/15 correct on a self-test. 2. **Vocabulary Bridge:** Use `c12_hin_a_cbse_09_010` (Vocabulary in Context) to master the Braj words in Kukuan's poems ("फनुक", "वकुदकुह", "फुगफजक्स", "एक्सिघग", "इकदक"). Make flashcards: **Word -> Meaning -> Sense it triggers**. 3. **Re-Diagnostic:** Take a fresh stanza from Kukuan (not the ones practiced). Apply the 5-step Walkthrough process aloud. Record yourself. Check: Did you name the sense from the *verb/adjective*? Did you name tenor/vehicle for a metaphor? If no → repeat Step 1.

## BUILDS_ON
Class 11 node `c11_hin_ar_cbse_09_008` (Literary Devices: Imagery and Metaphor) where students learned basic definitions and identification in simpler Khari Boli poems.

## LEADS_TO
`c12_hin_a_cbse_09_009` (Literary Devices: Irony and Symbolism) — because metaphors often *become* symbols when repeated (e.g., "path" → symbol of life journey), and irony arises when imagery contradicts expectation (e.g., beautiful sound of anklets heralding a painful meeting).

## PREREQUISITE_NODE_IDS
c11_hin_ar_cbse_09_008, c12_hin_a_cbse_09_001, c12_hin_a_cbse_09_003, c12_hin_a_cbse_09_006, c12_hin_a_cbse_09_010, c12_hin_a_cbse_09_012, c12_hin_a_cbse_09_002, c12_hin_a_cbse_09_005, c12_hin_a_cbse_09_007, c12_hin_a_cbse_09_011

## PREREQUISITE_REASONS
c11_hin_ar_cbse_09_008: Provides foundational definitions and identification practice in accessible Khari Boli; without this, Class 12 Braj analysis is impossible.
c12_hin_a_cbse_09_001: Context/Background gives the cultural setting (Braj, 17th century, Krishna bhakti, veil customs) essential for interpreting *why* certain senses are chosen (e.g., auditory over visual due to purdah).
c12_hin_a_cbse_09_003: Setting/Atmosphere establishes the physical/emotional landscape (forest, night, separation) that the imagery evokes and the metaphor navigates.
c12_hin_a_cbse_09_006: Primary Theme (Vipralambha Shringara / love in separation) is the *target* all devices serve; analyzing devices without the theme is empty formalism.
c12_hin_a_cbse_09_010: Vocabulary in Context is non-negotiable — Braj words like "फनुक" (गति/चाल), "वकुदकुह" (कठोर वचन), "फुगफजक्स" (काँपना) carry the sensory load; guessing meanings leads to wrong imagery classification.
c12_hin_a_cbse_09_012: Comprehension (Literal/Inferential) ensures the student knows *what* is happening in the poem before analyzing *how* it is said.
c12_hin_a_cbse_09_002: Imagery clusters (necklace, night, fire) serve as structural signposts.  
c12_hin_a_cbse_09_005: Imagery and metaphor are the *tools* used to build Latika's character; analyzing them here prepares for systematic device study.  
c12_hin_a_cbse_09_007: Literary devices (imagery, metaphor) are the tools used to express the secondary themes identified here.  
c12_hin_a_cbse_09_011: d Devices (alliteration, onomatopoeia) — these are handled in sibling nodes (c12_hin_a_cbse_09_009, c12_hin_a_cbse_09_011). It assumes the student has already grasped the literal meaning (c12_hin_a_cbse_09_012) and themes (c12_hin_a_cbse_09  

## FORWARD_NODE_IDS
c12_hin_a_cbse_09_009, c12_hin_a_cbse_09_013, c12_hin_a_cbse_09_014, c12_hin_a_cbse_09_015

## FORWARD_REASONS
c12_hin_a_cbse_09_009: Irony/Symbolism builds directly on Metaphor — a sustained metaphor becomes a symbol; ironic contrast often uses imagery to set up an expectation that is violated.
c12_hin_a_cbse_09_013: Critical Thinking requires the device-analysis skills from this node to construct interpretive arguments (e.g., "Kukuan's tactile metaphors materialize abstract grief").
c12_hin_a_cbse_09_014: Writing Skills (analytical paragraph, exam answer) applies the PEEL structure practiced here to full-length board responses.
c12_hin_a_cbse_09_015: Imagery (lamp, potter) and metaphor mechanics are the *textual evidence* students must cite orally.  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
No prior class nodes from other subjects are provided in the input list. Cross-subject links are established in the CROSS_SUBJECT section below using hypothetical Class 12 nodes from other disciplines.

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_09_008 -> c12_hin_a_cbse_09_008 -> c12_hin_a_cbse_09_009

## THIS_FORMULA
N/A - conceptual

## FORMULA_VARIABLES
N/A

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
linguistic

## CROSS_SUBJECT
N/A | Both require identical analytical protocol: (1) Quote evidence, (2) Name device precisely, (3) Explain effect on meaning/theme, (4) Use PEEL structure. Kukuan's "auditory veil" imagery parallels Keats' "Heard melodies are sweet" (auditory imagination) in *Ode on a Grecian Urn*.
 N/A | Kukuan's imagery/metaphors are rooted in *Braj Bhakti* conventions (vipralambha shringara, Radha-Krishna lore). Understanding the historical *Sampradaya* (Pushtimarg/Vallabhacharya) explains why "path" (पंथ) and "glance" (दृष्टि) are metaphorical staples — they map theological concepts (grace, surrender) onto sensory experience.
## PREREQ_CONCEPT
Precise sensory classification (V/A/T/O/G) and Tenor/Vehicle terminology for metaphor — not just "I see a comparison."

## PREREQ_BEFORE
Student must have completed vocabulary meanings for all Braj words in the two poems (node `c12_hin_a_cbse_09_010`) and understood the literal narrative (node `c12_hin_a_cbse_09_012`).

## PREREQ_STUCK
If stuck on identifying the sense: check the **verb/adjective**, not the noun. If stuck on metaphor: ask "Is there a 'जैसे/वैसे/सा'?" If yes → Simile. If no + "A is B" → Metaphor. If still unclear, revisit `c11_hin_ar_cbse_09_008` worked examples.

## WORKED_EXAMPLE_1
**PROBLEM:** Analyze the imagery in the first two lines of Kukuan's first poem: "चगु फनुक दिस वउक्लिक इजस / [कजस वजकजफु हकजस गस मफब तुक दकस" (Transliterated: "चगु फनुक दिस वौक्लिक इजस / डग डग बाजत घुंघरू..."). Identify each sensory image, its sense modality, and its thematic function in establishing the *Vipralambha* mood.

**STEPS:**
- Step 1: **Segment & Translate** — Break into semantic units: "चगु फनुक दिस" (चगु = चारों ओर/चहुँ; फनुक = फनक/गति/चाल; दिस = दिखती है) → "Her gait/movement is seen all around". "वौक्लिक इजस" likely "वक्लिक इजस" / "बाजत घुंघरू" → "Anklets jingle step by step".
- Step 2: **Tag Sensory Triggers** — "दिस" (दिखती है) = Visual verb. "बाजत" (बजते हुए) = Auditory participle. "डग डग" (step by step) = Rhythmic kinetic/tactile sense of vibration.
- Step 3: **Classify Modality** — Line 1: **Visual** (sight of movement). Line 2: **Auditory** (sound of anklets) + **Tactile/Kinesthetic** (rhythmic vibration felt through ground/body).
- Step 4: **Thematic Function** — Visual: Beloved's form is *perceived* but not fully grasped (veiled). Auditory: Sound travels *around* barriers (walls, veil) — her presence is inescapable. Tactile rhythm: Mirrors the lover's heartbeat/anticipation. Together they construct **separation (विरह) as a multi-sensory haunting** — she is absent visually (veiled/distant) but overwhelmingly present aurally/tactilely.
- Step 5: **Board Answer Draft (PEEL)** — **P:** Kukuan uses multi-modal imagery to make separation tangible. **E:** "दिस" (visual) shows the beloved's elusive form; "बाजत घुंघरू" (auditory) penetrates the veil; "डग डग" (tactile rhythm) syncs with the lover's pulse. **E:** This sensory layering transforms *virah* from an emotion into a physical environment the lover inhabits. **L:** Thus, imagery bridges the physical distance — the core tension of *Vipralambha Shringara*.

**REASONING:** This 5-step method forces the student to move from *word* -> *sense* -> *function* -> *theme*, which is exactly the CBSE marking scheme's progression (Identify -> Illustrate -> Interpret -> Integrate). Skipping Step 1 (translation) causes errors in Braj; skipping Step 4 (function) yields a list, not an analysis.

**ANSWER:** The stanza employs **Visual** ("दिस" — sight of gait), **Auditory** ("बाजत" — jingling sound), and **Tactile/Kinesthetic** ("डग डग" — rhythmic step vibration) imagery. The auditory dominance ("बाजत घुंघरू") is strategic: in a *purdah* context, sound bypasses the visual barrier, making the beloved's presence unavoidable. The tactile rhythm ("डग डग") internalizes her movement in the lover's body. Collectively, they render *virah* (separation) not as absence but as a **sensory saturation** — the beloved is everywhere through sound/touch though nowhere in sight.

## WORKED_EXAMPLE_2
**PROBLEM:** In the second poem, the line "एक सूं लखन न लागै, दूजी सूं लखन जाय" contains a metaphor. Deconstruct it using Tenor-Vehicle-Ground framework and explain how it structures the poem's central conflict.

**STEPS:**
- Step 1: **Literal Parsing** — "एक सूं" (from one direction/way), "लखन न लागै" (does not appear/meet), "दूजी सूं" (from the other direction), "लखन जाय" (appears/meets/departs). Context: The beloved speaks of her own glance/attention.
- Step 2: **Identify A = B Structure** — No "जैसे". The "glance/attention" (implied subject) **IS** a "direction/path" (सूं/मार्ग). **Tenor:** Beloved's glance / act of seeing. **Vehicle:** A physical path with two opposite directions (एक सूं / दूजी सूं).
- Step 3: **Extract Ground (Shared Qualities)** — (a) **Binary Exclusivity**: A path either leads *to* or *away*; no third option. (b) **Agency/Control**: The path exists independently; the walker chooses direction but not the path's geometry. (c) **Finality**: "लागै" (takes effect/arrives) vs "जाय" (goes/departs) — irreversible outcomes.
- Step 4: **Map to Conflict** — The beloved's glance *structures* the lover's reality: one glance grants union (दर्शन), the other enforces separation (विरह). The metaphor makes **separation an ontological structure**, not a fleeting mood. The lover is "on the path" — his fate depends entirely on which way the glance "faces".
- Step 5: **Board Answer (PEEL)** — **P:** The metaphor "Glance is a Binary Path" structuralizes the lover's helplessness. **E:** "एक सूं लखन न लागै / दूजी सूं लखन जाय" — Tenor=Glance, Vehicle=Two-way path. **E:** The vehicle's binary geometry (only two directions) transfers to the tenor: the glance *must* either grant union or enforce separation. The lover has zero agency — he is the traveler on a path he didn't build. **L:** This elevates personal grief to cosmic law, typical of Bhakti *virah* poetry where human longing mirrors divine will.

**REASONING:** The Tenor-Vehicle-Ground framework (from I.A. Richards, standard in literary theory) is the *only* way to get full marks for "metaphor explanation" in CBSE. Most students stop at "Glance is compared to a path" — that's identification (1 mark). Explaining *which qualities transfer* and *how that shapes the theme* gets the remaining 2 marks. Step 3 (Ground) is the differentiator.

**ANSWER:** **Metaphor:** Beloved's Glance (Tenor) = A Two-Way Path (Vehicle). **Ground (Transferred Qualities):** (1) Binary exclusivity — only two outcomes: union ("लागै") or separation ("जाय"). (2) Irrevocability — once the direction is set, the result follows inevitably. (3) External architecture — the path exists independently of the traveler (lover). **Thematic Function:** This metaphor converts the beloved's *volitional act* (looking) into an *objective structure* (path), making the lover's suffering a matter of **ontological positioning** rather than emotional fluctuation. The conflict is no longer "will she look?" but "on which path am I placed?" — aligning with the Bhakti view of grace (कृपा) as structural, not discretionary.

## WORKED_EXAMPLE_3
**PROBLEM:** **Synthesis Task:** Compare how **Imagery** and **Metaphor** *interact* in the two poems to construct two distinct models of *Vipralambha* (Separation). Poem 1: Lover's perspective (observation). Poem 2: Beloved's perspective (dialogue). Write a 100-word comparative analysis.

**STEPS:**
- Step 1: **Recall Device Maps** — Poem 1: Dominant **Auditory/Tactile** imagery (sound of anklets, rhythm of steps) + **Implicit Metaphor** (Beloved's movement = Music/Rhythm that binds). Poem 2: Dominant **Auditory/Tactile** imagery (harsh speech "वकुदकुह", trembling "फुगफजक्स") + **Explicit Structural Metaphor** (Glance = Binary Path).
- Step 2: **Identify Perspective Shift** — Poem 1: *External gaze* (Lover looks AT Beloved). Imagery is **receptive** (he receives sight/sound). Metaphor is **organic** (her movement *is* music). Poem 2: *Internal voice* (Beloved speaks OF her own power). Imagery is **expressive** (she emits sound/tremor). Metaphor is **architectural** (her glance *builds* the path).
- Step 3: **Analyze Interaction** — In Poem 1, imagery *feeds* the metaphor: the auditory/tactile saturation *creates* the sense that her movement is a rhythm/music (metaphor). In Poem 2, the metaphor *frames* the imagery: the binary path metaphor dictates that her speech must be harsh ("वकुदकुह") and her body must tremble ("फुगफजक्स") — the imagery *enacts* the metaphor's severity.
- Step 4: **Synthesize Models of Vipralambha** — Model A (Poem 1): **Vipralambha as Sensory Immersion** — Separation is a world filled with her traces (sound, rhythm). The lover *drowns* in her presence-in-absence. Model B (Poem 2): **Vipralambha as Judicial Verdict** — Separation is a binary judgment passed by her glance. The beloved *administers* the separation; her harsh words and tremors are the *execution* of the verdict.
- Step 5: **Draft Comparative Answer (100 words)** — "कुकुआन दोनों पदों में बिंब और रूपक की पारस्परिक क्रिया से विरह के दो प्रतिरूप रचते हैं। पद 1 (प्रेमी-दृष्टि) में श्रव्य-स्पर्शी बिंब ('बाजत घुंघरू', 'डग डग') प्रेयसी की गति को 'संगीत/लय' रूपक में ढालते हैं — विरह यहाँ **संवेदी विसर्जन** है, जहाँ अनुपस्थिति उपस्थिति-सी घेर लेती है। पद 2 (प्रेयसी-संवाद) में वही श्रव्य-स्पर्शी बिंब ('वकुदकुह', 'फुगफजक्स') 'दृष्टि = द्विमार्गी पथ' रूपक के अधीन कठोर हो जाते हैं — विरह यहाँ **न्यायिक निर्णय** है, जहाँ प्रेयसी की दृष्टि द्वैत (मिलन/विरह) रचती है और उसकी वाणी/काया उसका क्रियान्वयन करती हैं। इस प्रकार, बिंब जहाँ अनुभव की बनावट देते हैं, रूपक उसकी संरचना तय करता है।"

**REASONING:** This is a **Level 6 (Create/Synthesize)** task — exactly what CUET/IPMAT/Board "Critical Thinking" questions demand. It requires holding two device-maps simultaneously, seeing how they *interact* (not just coexist), and abstracting *models* (not just listing). The 5-step method (Map -> Perspective -> Interaction -> Model -> Draft) makes this manageable. Without Step 3 (Interaction), the answer remains two separate analyses — a common "compare" error.

**ANSWER:** (See Step 5 draft above). Key insight: **Imagery provides the texture; Metaphor provides the architecture.** In Poem 1, the architecture is *organic/musical* (immersion). In Poem 2, the architecture is *binary/judicial* (verdict). The same sensory modes (auditory/tactile) serve opposite thematic functions because the **metaphoric frame flips**.

## COMPETENCY_QUESTION_1
**QUESTION:** (Case-Based) A student analyzes the line "डग डग बाजत घुंघरू" and writes: *"This is a visual image of anklets. The metaphor is that the beloved's feet are music."* Evaluate this analysis. Identify **two specific errors** (one in imagery classification, one in metaphor identification) and rewrite the analysis correctly in 40 words using PEEL.

**COMPETENCY:** Critical Analysis & Error Correction (CBSE Competency: "Analyzing and Evaluating Literary Texts")

**STEPS:**
- Step 1: Spot the imagery error — "visual image of anklets" ignores the verb "बाजत" (jingling) which is auditory.
- Step 2: Spot the metaphor error — "feet are music" is not in the line; the line has *no metaphor*, only imagery. The metaphor "movement = music" is an inference from the *whole stanza*, not this line alone.
- Step 3: Construct correct PEEL: Point (Auditory imagery dominates), Evidence ("बाजत घुंघरू"), Explain (Sound penetrates veil; rhythm mirrors heartbeat), Link (Establishes vipralambha as sensory haunting).
- Step 4: Enforce word limit (40 words) — trim explanation to essence.

**ANSWER:** **Errors:** (1) "बाजत" (jingling) creates **auditory**, not visual, imagery. (2) The line contains **no metaphor**; "feet are music" is an interpretive leap, not a textual device. **Corrected PEEL (38 words):** Kukuan deploys **auditory imagery** ("बाजत घुंघरू") to make the veiled beloved's presence inescapable through sound. The rhythmic "डग डग" internalizes her steps as tactile vibration, syncing with the lover's pulse. This sensory saturation constructs *virah* as physical haunting, not mere absence.

**DIFFICULTY:** medium

## COMPETENCY_QUESTION_2
**QUESTION:** (Assertion-Reason + Application)
**Assertion (A):** In Kukuan's second poem, the metaphor "Glance = Binary Path" (एक सूं... दूजी सूं) functions as a **theological statement** about divine grace, not merely a description of human love.
**Reason (R):** The Bhakti tradition (Pushtimarg) views the Lord's glance (कृपा-दृष्टि) as the *sole* determinant of the soul's fate (मुक्ति/बन्धन), admitting no human effort (साधन).
**Task:** (i) State whether A and R are True/False. (ii) If both True, does R correctly explain A? (iii) **Apply:** Identify one phrase from the poem's vocabulary list (`c12_hin_a_cbse_09_010` words: वकुदकुह, वजलह, फुगफजक्स, एक्घग, इकदक) that *enacts* this theological metaphor in the human realm, and explain how.

**COMPETENCY:** Interdisciplinary Synthesis (Literary Analysis + Intellectual History) — CBSE Competency: "Connecting Text to Context"; CUET/IPMAT Style: Assertion-Reason with Textual Application.

**STEPS:**
- Step 1: Evaluate A — True. The binary path metaphor (glance -> union/separation) maps exactly onto Pushtimarg's *Kripa* doctrine: God's glance is unconditioned, binary (grace/withholding), and structuring.
- Step 2: Evaluate R — True. Standard Pushtimarg theology: *Kripa* is *nirhetuka* (causeless), *svatantra* (independent of human merit), binary (liberation/bondage).
- Step 3: R explains A — Yes. R provides the *theological source-domain* that the metaphor borrows its structure from. The metaphor *is* the poetic encoding of R.
- Step 4: Apply to Vocabulary — Choose "वकुदकुह" (कठोर वचन / harsh speech) or "फुगफजक्स" (काँपना / trembling). "वकुदकुह" is better: The beloved's harsh words *enact* the "दूजी सूं" (second path = separation/judgment). Just as divine withholding of grace is not "cruel" but *structural*, her harshness is not personal malice but the **verbal execution of the binary verdict**. The metaphor demands the imagery.
- Step 5: Write integrated response.

**ANSWER:** (i) **A: True. R: True.** (ii) **Yes, R correctly explains A.** The metaphor "Glance = Binary Path" imports the Pushtimarg structure of *Kripa* (causeless, binary, sovereign) into the human love-exchange. The glance, like divine grace, admits no negotiation — "एक सूं लखन न लागै" (withheld) / "दूजी सूं लखन जाय" (bestowed then withdrawn) mirrors *anugraha/nigraha*. (iii) **Phrase: "वकुदकुह" (कठोर वचन).** It *enacts* the "दूजी सूं" verdict. In the metaphor's logic, the beloved's speech *must* be harsh when the glance turns away — not from anger, but because the **binary architecture allows no soft middle ground**. Her "वकुदकुह" is the human analogue of divine *nigraha* (withholding): structurally necessary, personally devastating.

**DIFFICULTY:** hard