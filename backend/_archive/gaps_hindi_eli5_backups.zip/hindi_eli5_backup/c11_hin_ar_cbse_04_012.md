## DEFINITION
Literal comprehension questions require answers directly stated in the text (facts, details, sequence), while inferential comprehension questions demand logical deduction using textual evidence, context, and reasoning to uncover implied meaning, tone, or authorial intent.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
Student can independently classify any question as literal or inferential, locate exact textual evidence for literal answers, and construct inferential answers using a three-step chain: claim + textual evidence + logical reasoning linking evidence to claim.

## SCOPE_BOUNDARY
Covers only comprehension question types (literal vs inferential) based on the chapter "फोनबूथ" (Phone Booth). Does NOT cover critical analysis, creative writing, or speaking/listening skills (addressed in nodes 013-015).

## WALKTHROUGH
Imagine you're in the exam hall staring at a question: "लेखक ने मिस्टर यंग को 'एक वकील' क्यों कहा?" You panic because the text never explicitly says "he is a lawyer." This is where most students freeze. The key is to first ask: "Is the answer written word-for-word in the text?" If yes → literal. If no → inferential. For inferential, hunt for clues: tone (sarcasm), context (British legal exploitation), and repeated patterns (the narrator mocking official designations). The insight: inferential answers are not guesses; they are evidence-based arguments hiding in plain sight.

## DIAGNOSTIC_QUESTION_1
What is the defining difference between a literal comprehension question and an inferential comprehension question?

## DIAGNOSTIC_ANSWER_1
A literal question's answer is explicitly stated in the text (e.g., "What year did Mr. Young serve?"). An inferential question's answer is implied and must be deduced using textual clues (e.g., "Why does the narrator call Mr. Young a 'lawyer'?"). A wrong answer (e.g., "Inferential questions are just opinions") reveals the student confuses inference with unsupported guessing, missing the requirement for textual evidence.

## DIAGNOSTIC_QUESTION_2
In the chapter, the narrator says: "आपके देश के कानून तो बड़े न्यायप्रिय हैं।" Is the question "What is the narrator's attitude toward British law?" literal or inferential? Explain your reasoning.

## DIAGNOSTIC_ANSWER_2
It is inferential. The text never directly states "the narrator is sarcastic." The student must analyze the word "न्यायप्रिय" (justice-loving) in context: the narrator lists injustices (land revenue, forest laws) immediately after, creating irony. A wrong answer ("literal, because the word 'न्यायप्रिय' is in the text") shows the student matches keywords without analyzing tone or context — a surface-reading error.

## DIAGNOSTIC_QUESTION_3
Given the passage: "अंग्रेज़ी राज में... कानून का राज था।" A question asks: "List two specific laws mentioned by the narrator that exploited Indians." Demonstrate how to answer this literal question using the text.

## DIAGNOSTIC_ANSWER_3
Step 1: Scan for keywords "कानून", "नियम", "लगान". Step 2: Locate explicit mentions: "लगान", "वन कानून", "नमक कर". Step 3: Quote exact phrases: "लगान के नाम पर...", "वन कानून...", "नमक कर...". Step 4: Present as a list. A wrong answer (e.g., "The British made unfair laws") shows the student summarized instead of extracting explicit textual details — failing the literal requirement of verbatim or near-verbatim retrieval.

## DIAGNOSTIC_QUESTION_4
The narrator describes Mr. Young: "आपके शासन में... एक वकील का बेटा वकील बनता है।" Compare the literal meaning of this statement with its inferential implication about British colonial administration.

## DIAGNOSTIC_ANSWER_4
Literal: The narrator states a factual pattern — sons of lawyers become lawyers under British rule. Inferential: This implies nepotism, exclusion of Indians from power, and a self-perpetuating colonial bureaucracy. A wrong answer that only gives the literal meaning misses the satirical critique; one that only gives the inference without citing the specific textual pattern fails to ground the deduction. Both halves are required.

## DIAGNOSTIC_QUESTION_5
Evaluate this student answer to an inferential question: "The narrator hates Mr. Young because he is British." The question was: "Why does the narrator mock Mr. Young's departure?" Is this answer acceptable? Justify.

## DIAGNOSTIC_ANSWER_5
Unacceptable. The answer substitutes a vague emotion ("hate") and a simplistic identity reason ("because he is British") for textual evidence. The text shows mockery rooted in specific grievances: economic exploitation ("लगान"), legal hypocrisy ("न्यायप्रिय"), and personal insult ("वकील का बेटा"). A correct evaluation would note: the answer ignores the narrator's rhetorical strategy (irony), lacks textual citations, and reduces a political critique to personal prejudice — a common senior-secondary error of conflating tone with motive.

## DIAGNOSTIC_QUESTION_6
Create an inferential question based on the last paragraph of the chapter (the Indian prince's speech at Ujjain) that requires analyzing the shift from irony to direct appeal. Provide the question and a model answer structure.

## DIAGNOSTIC_ANSWER_6
Question: "How does the prince's final appeal to 'future generations' transform the narrator's earlier ironic tone into a moral challenge to Mr. Young?" Model structure: (1) Identify the shift: irony → direct address. (2) Cite evidence: "पीछे आने वालों को..." vs earlier "न्यायप्रिय". (3) Explain effect: universalizes the critique beyond one official. A poor question would be literal ("What did the prince say?"). A poor answer would miss the tonal shift or fail to link "future generations" to the narrator's opening historical framing.

## COMMON_MISCONCEPTION
Students believe inferential questions have "no right answer" or that "any interpretation is valid if you explain it." In Class 11 board exams, inferential answers are marked against a strict rubric: (1) claim must be text-grounded, (2) evidence must be specific (line/incident), (3) reasoning must follow literary logic (irony, satire, characterization). Students also confuse "inferential" with "personal opinion" — e.g., answering "I think the narrator is angry" instead of "The narrator uses sarcasm to expose hypocrisy, as seen when he..."

## ON_FAILURE
1. Give the student a 3-column table: Question | Type (L/I) | Evidence Location. 2. Practice with 5 questions from the chapter: two literal (e.g., "What post did Mr. Young hold?"), three inferential (e.g., "Why does the narrator mention the 1857 rebellion?"). 3. For each inferential, force the student to write: "The text says _____, which implies _____ because _____." 4. Grade only the evidence-reasoning link, not the final answer. Repeat until the scaffold becomes automatic.

## BUILDS_ON
Vocabulary in context (node 010) and character analysis (nodes 004-005) provide the textual knowledge base required to locate evidence and interpret tone.

## LEADS_TO
Critical thinking (node 013) where students evaluate interpretations, and writing skills (node 014) where they structure full-length answers using the literal/inferential distinction.

## PREREQUISITE_NODE_IDS
c11_hin_ar_cbse_04_010, c11_hin_ar_cbse_04_011, c11_hin_ar_cbse_04_004, c11_hin_ar_cbse_04_005, c11_hin_ar_cbse_04_006, c11_hin_ar_cbse_04_007

## PREREQUISITE_REASONS
c11_hin_ar_cbse_04_010: Key vocabulary (e.g., 'न्यायप्रिय', 'लगान', 'वन कानून') must be understood to locate literal answers and detect irony.
c11_hin_ar_cbse_04_011: Grammar usage (passive voice, rhetorical questions) signals authorial tone essential for inference.
c11_hin_ar_cbse_04_004: Protagonist analysis (narrator's voice, stance) provides the lens for inferring intent.
c11_hin_ar_cbse_04_005: Supporting character analysis (Mr. Young as colonial archetype) supplies context for inferential deductions.
c11_hin_ar_cbse_04_006: Primary theme (colonial exploitation) is the framework within which all inferences operate.
c11_hin_ar_cbse_04_007: Comprehension questions often test thematic inference.  

## FORWARD_NODE_IDS
c11_hin_ar_cbse_04_013, c11_hin_ar_cbse_04_014, c12_hin_ar_cbse_04_010, c12_hin_ar_cbse_04_012

## FORWARD_REASONS
c11_hin_ar_cbse_04_013: Critical thinking requires moving beyond comprehension to evaluation — students must first master extracting and inferring before they can critique.
c11_hin_ar_cbse_04_014: Writing skills (long answers, essays) demand structured use of literal evidence and inferential reasoning in PEEL paragraphs.
c12_hin_ar_cbse_04_010: Class 11 comprehension — trains inference from lexical gaps, directly prerequisite for 'inference' context clues.  
c12_hin_ar_cbse_04_012: अगला तार्किक चरण: Literal comprehension is the ability to extract explicitly stated facts, details, and sequences dire... इस नोड की अवधारणाओं को सीधे उपयोग/विस्तारित करता है।  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
none

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_04_010 -> c11_hin_ar_cbse_04_012 -> c11_hin_ar_cbse_04_013

## THIS_FORMULA
N/A - conceptual

## FORMULA_VARIABLES
N/A

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
linguistic

## CROSS_SUBJECT
c11_history_colonialism | The chapter satirizes British colonial policies (land revenue, forest laws, salt tax); comprehension of these references requires historical knowledge of economic exploitation mechanisms.
c11_politicalscience_power | The dialogue illustrates asymmetric power dynamics — legal rhetoric masking coercion — a core concept in political theory (hegemony, legitimacy).

## PREREQ_CONCEPT
Student must have completed a full reading of "फोनबूथ" with annotated understanding of plot, characters, vocabulary, and central satire.

## PREREQ_BEFORE
Student can summarize the chapter in 5 sentences and define 10 key terms (e.g., लगान, वन कानून, न्यायप्रिय, वकील, उज्जैन).

## PREREQ_STUCK
Re-read the chapter with a highlighter: mark every proper noun, number, and law named (literal anchors) and every sarcastic phrase (inferential anchors).

## WORKED_EXAMPLE_1
PROBLEM: Answer the literal question: "मिस्टर यंग ने भारत में किन दो पदों पर कार्य किया था?" using only the text.
STEPS:
- Step 1: Identify question type — asks for explicit designations → literal.
- Step 2: Scan text for "मिस्टर यंग", "पद", "कार्य", "नियुक्ति". Locate paragraph: "आप 1899 से 1904 तक... लेफ्टिनेंट गवर्नर रहे... फिर 1904 से 1905 तक... गवर्नर जनरल के एजेंट।"
- Step 3: Extract exact designations: "लेफ्टिनेंट गवर्नर" and "गवर्नर जनरल के एजेंट".
- Step 4: Verify no other posts mentioned for him in the text.
- Step 5: Format answer: "मिस्टर यंग 1899-1904 तक लेफ्टिनेंट गवर्नर और 1904-1905 तक गवर्नर जनरल के एजेंट रहे।"
REASONING: Literal questions test retrieval accuracy. The steps enforce text-dependency, prevent inference creep, and mirror board exam marking (1 mark per correct designation).
ANSWER: मिस्टर यंग 1899 से 1904 तक लेफ्टिनेंट गवर्नर और 1904 से 1905 तक गवर्नर जनरल के एजेंट के पद पर कार्यरत रहे।

## WORKED_EXAMPLE_2
PROBLEM: Answer the inferential question: "लेखक ने मिस्टर यंग के लिए 'वकील का बेटा वकील' वाक्यांश का प्रयोग क्यों किया है?"
STEPS:
- Step 1: Classify — asks for reason behind author's choice → inferential.
- Step 2: Locate the phrase in context: "आपके शासन में... एक वकील का बेटा वकील बनता है।" Preceded by list of excluded Indians; followed by "आपके देश के कानून तो बड़े न्यायप्रिय हैं।"
- Step 3: Identify literal facts: British legal posts were hereditary/nepotistic; Indians barred.
- Step 4: Infer authorial intent: The phrase condenses systemic exclusion into a bitter proverb — mocking "rule of law" rhetoric.
- Step 5: Construct answer with claim-evidence-reasoning: "लेखक ने यह वाक्यांश ब्रिटिश प्रशासन की भाई-भतीजावाद और भारतीयों के बहिष्कार को उजागर करने के लिए प्रयोग किया है। पाठ में 'वकील का बेटा वकील बनता है' के तुरंत बाद 'न्यायप्रिय' शब्द का व्यंग्यात्मक प्रयोग इस निष्कर्ष की पुष्टि करता है।"
REASONING: Inferential answers require the "text says → implies → because" chain. Step 3 separates literal anchor from inferential leap; step 5 models board-exam answer structure.
ANSWER: लेखक ने 'वकील का बेटा वकील' वाक्यांश द्वारा ब्रिटिश शासन में उच्च पदों पर वंशानुगत नियुक्तियों और भारतीयों के व्यवस्थित बहिष्कार पर कटाक्ष किया है। यह वाक्यांश 'न्यायप्रिय कानून' के दावे की विडंबना को तीक्ष्ण बनाता है।

## WORKED_EXAMPLE_3
PROBLEM: A 3-mark question: "पाठ के आधार पर स्पष्ट कीजिए कि मिस्टर यंग की विदाई के समय लेखक के मन में कौन-सी दो विरोधी भावनाएँ थीं और क्यों?" (Combines literal retrieval of emotions + inferential reasoning for causes)
STEPS:
- Step 1: Decompose — two emotions (literal) + two reasons (inferential).
- Step 2: Scan for departure scene: "विदा होते समय... मेरे मन में एक ओर तो... दूसरी ओर..." Locate: "एक ओर... संतोष... दूसरी ओर... करुणा".
- Step 3: Literal retrieval: Emotion 1 = संतोष (satisfaction), Emotion 2 = करुणा (pity).
- Step 4: Infer reasons from context: संतोष → because exploiter is leaving (text: "लुटेरा जा रहा है"); करुणा → because he is ultimately a victim of the same system (text: "वह स्वयं भी... एक यंत्र था").
- Step 5: Synthesize in board format: "लेखक को संतोष था कि एक शोषक जा रहा है (पाठ: 'लुटेरा जा रहा है'), किन्तु करुणा भी थी क्योंकि मिस्टर यंग स्वयं साम्राज्यवादी मशीनरी का एक पुर्जा मात्र था (पाठ: 'वह स्वयं भी... एक यंत्र था')।"
- Step 6: Check mark allocation: 1 mark per emotion+reason pair = 3 marks (1 for identification, 2 for reasoned explanation).
REASONING: Hybrid questions are common in board exams. The steps train students to separate retrieval from reasoning and allocate words per mark.
ANSWER: लेखक के मन में संतोष था क्योंकि एक शोषक अधिकारी विदा हो रहा था ('लुटेरा जा रहा है'), और करुणा थी क्योंकि मिस्टर यंग स्वयं ब्रिटिश साम्राज्यवाद की अमानवीय व्यवस्था का एक साधन मात्र था ('वह स्वयं भी... एक यंत्र था')।

## COMPETENCY_QUESTION_1
QUESTION: "The narrator calls British laws 'न्यायप्रिय' (justice-loving) three times in the chapter. Each time, the context contradicts the word. Explain how this repetition functions as an inferential key to the chapter's central satire. Provide two specific textual instances with line references."
COMPETENCY: Literary device analysis + inferential reasoning
STEPS:
- Step 1: Identify the device — ironic repetition (anaphora with semantic inversion).
- Step 2: Locate three occurrences: (a) after listing land revenue laws, (b) after forest laws, (c) after salt tax.
- Step 3: For each, state the literal context (exploitation) vs the word (न्यायप्रिय).
- Step 4: Infer cumulative effect: each repetition widens the gap between claim and reality, building the satire structurally.
- Step 5: Articulate why this is the "key" — it transforms isolated grievances into a systemic critique of legislative hypocrisy.
ANSWER: The thrice-repeated 'न्यायप्रिय' acts as a structural irony. Instance 1: After 'लगान के नाम पर किसानों का खून चूसा गया' — law protects revenue, not peasants. Instance 2: After 'वन कानून ने आदिवासियों को अपराधी बना दिया' — law criminalizes survival. Instance 3: After 'नमक कर ने गरीब का निवाला छीना' — law taxes survival. The repetition forces the reader to infer: 'न्यायप्रिय' is a euphemism for 'exploitative by design'. This is the chapter's central satire — legality as a weapon.
DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: "A student answers the inferential question 'Why does the narrator invoke the 1857 rebellion?' with: 'To show the British were cruel.' The teacher awards 1/3 marks. Using the board marking scheme logic, diagnose the answer's flaws and rewrite it to secure full marks."
COMPETENCY: Answer evaluation + reconstruction (metacognitive)
STEPS:
- Step 1: Analyze the weak answer — flaw 1: "cruel" is vague (literal generalization), flaw 2: no textual evidence, flaw 3: misses the narrator's rhetorical purpose (contrast: 1857 vs 1900s legal exploitation).
- Step 2: Recall textual anchors: "1857 में तलवारें चलीं... अब कानून चलते हैं", "पहले लूटते थे, अब कानूनी लूट".
- Step 3: Identify required inferential chain: 1857 reference → establishes historical continuity → shows shift from overt violence to structural violence → legitimizes narrator's claim that 'कानून' is the new sword.
- Step 4: Reconstruct with PEEL: Point (invocation serves to contrast methods), Evidence (quote 'तलवार' vs 'कानून'), Explanation (structural violence more insidious), Link (central theme: legitimacy of exploitation).
- Step 5: Write full-mark answer: "लेखक 1857 का उल्लेख इसलिए करता है ताकि ब्रिटिश शोषण के दो चरणों की तुलना कर सके: 1857 की प्रत्यक्ष सैन्य हिंसा ('तलवारें') और वर्तमान कानूनी हिंसा ('कानून')। पाठ में 'पहले तलवार से लूटते थे, अब कानून से लूटते हैं' यह कथन दर्शाता है कि कानून शोषण का नया हथियार है। यह संदर्भ 'न्यायप्रिय' की विडंबना को ऐतिहासिक गहराई देता है।"
ANSWER: Weak answer fails on: (1) specificity — 'cruel' not text-derived, (2) evidence — zero quotes, (3) depth — misses the 'violence vs law' contrast central to the satire. Full-mark answer above uses textual contrast, explains the inferential link, and ties to central irony.
DIFFICULTY: hard