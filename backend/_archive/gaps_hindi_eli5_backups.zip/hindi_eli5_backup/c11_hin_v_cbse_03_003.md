## DEFINITION
Setting refers to the time, place, and social environment in which a narrative unfolds, while atmosphere is the emotional tone or mood created by the setting's sensory details, cultural context, and character interactions. In senior secondary literary analysis, setting functions as an active force shaping character choices and thematic development, not merely a backdrop.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student must independently identify at least three distinct settings in "vkyks&vk¡èkkfj," explain how each setting's physical and social details create a specific atmosphere, and demonstrate how the shifting settings reflect the protagonist's evolving psychological state and the story's central themes of gender, class, and autonomy.

## SCOPE_BOUNDARY
This node covers analysis of physical settings (households, hostel, narrator's home), social environments (employer-employee dynamics, patriarchal structures), and atmospheric progression (oppression → negotiation → resilience) in Krishna Sobti's "vkyks&vk¡èkkfj." It does NOT cover character analysis in depth (covered in nodes 004-005), thematic synthesis (nodes 006-007), or literary devices like imagery/symbolism (nodes 008-009).

## WALKTHROUGH
Imagine you enter a house where every movement is watched, every question feels like an interrogation, and the air itself feels heavy with judgment — this is the opening setting of "vkyks&vk¡èkkfj." Begin by asking: "What physical details in the first household (lquhy's house) make the narrator feel trapped?" Guide students to notice the cramped rooms, the constant surveillance ("vkl&ikl osQ yksx iwNrs"), the lack of privacy for basic needs, and how these create an atmosphere of dehumanization. Then trace how the setting shifts to rkrq'k's house — initially warmer but still controlling — and finally to the narrator's own impoverished home where she reclaims agency. The key insight: setting in this story is not passive background; each space embodies power structures that the protagonist must navigate, resist, or transform.

## DIAGNOSTIC_QUESTION_1
Identify the three primary physical settings in "vkyks&vk¡èkkfj" and state one distinctive physical detail for each that establishes its atmosphere.

## DIAGNOSTIC_ANSWER_1
The three primary settings are: (1) lquhy's household — distinctive detail: "V^h&is'kkc osQ fy, ckgj tkuk gksrk Fkk" (had to go far for toilet), establishing degradation; (2) rkrq'k's household — distinctive detail: "dejs esa rhu vkyekfj;k¡ fdrkcksa ls Hkjh Fkha" (drawer full of manuscripts), establishing intellectual control; (3) Narrator's own home — distinctive detail: "HkkM+k rks ik¡p lkS #i;s gh Fkk" (only five feet of space), establishing extreme poverty. A wrong answer listing only two settings or giving vague details like "big house" reveals inability to distinguish how physical specifics create atmospheric meaning.

## DIAGNOSTIC_QUESTION_2
Explain how the social environment of lquhy's household differs from rkrq'k's household in terms of power dynamics, using one specific interaction from each setting.

## DIAGNOSTIC_ANSWER_2
In lquhy's house, power is exercised through overt surveillance and interrogation ("vkl&ikl osQ yksx iwNrs] rqe ;gk¡ vosQyh jgrh gks\"), treating the narrator as an object of suspicion. In rkrq'k's house, power operates through conditional benevolence and intellectual domination — rkrq'k offers work but controls her writing ("fy[kus dks rqe viuh thou&dgkuh Hkh fy[k ldrh gksA"), positioning himself as mentor-gatekeeper. A wrong answer that says "both are bad" misses the crucial distinction: the first setting uses crude patriarchal surveillance; the second uses educated patriarchal patronage — both trap the narrator but through different mechanisms requiring different resistance strategies.

## DIAGNOSTIC_QUESTION_3
The narrator describes her own home: "HkkM+k rks ik¡p lkS #i;s gh Fkk ysfdu V^h&is'kkc osQ fy, ckgj tkuk gksrk Fkk." Analyze how this physical description creates an atmosphere that contrasts with both employer households.

## DIAGNOSTIC_ANSWER_3
The five-feet space with no toilet creates an atmosphere of raw survival rather than surveillance or patronage. Unlike the employer homes where space exists but dignity is denied, here dignity is intact (she controls her labor: "viuk dke pykÅ¡xh vkSj oSQls ?kj dk fdjk;k nw¡xh") but basic humanity is compromised by poverty. The contrast: employer homes = space without autonomy; own home = autonomy without space. A wrong answer focusing only on "poverty" misses the atmospheric paradox — this setting generates resilience ("eSa lcsjs mBdj cPpksa dks f[kyk&fiykdj jsMh djrh") absent in the supposedly "better" employer homes.

## DIAGNOSTIC_QUESTION_4
Trace how the atmosphere shifts when the narrator moves from lquhy's house to rkrq'k's house to her own home. What does this progression reveal about the story's view on women's labor?

## DIAGNOSTIC_ANSWER_4
The progression: (1) lquhy's house — atmosphere of interrogation and dehumanization ("ckrsa vulquh dj vius cPpksa dh ckrsa djus yxrh"); (2) rkrq'k's house — atmosphere of conditional acceptance masking control ("rqEgkjs iSlksa osQ ckjs esa eSa rqEgkjk dke ns[kdj crkÅ¡xk"); (3) Own home — atmosphere of exhausted autonomy ("eSa viuk dke pykÅ¡xh vkSj oSQls ?kj dk fdjk;k nw¡xh"). This reveals women's labor is exploited in all settings — as servant, as protégée, as sole breadwinner — but only in her own space does she convert labor into agency. A wrong answer seeing only "improvement" misses the cyclical trap: each setting extracts her labor differently; true autonomy remains structurally denied.

## DIAGNOSTIC_QUESTION_5
Evaluate the statement: "The hostel setting where the narrator sends her children represents hope, not separation." Use textual evidence to defend or challenge this interpretation.

## DIAGNOSTIC_ANSWER_5
Challenge with evidence: The hostel is described through the narrator's anguish — "cPpksa dks ysdj vc eSa dgk¡ tkmQ¡!" and the landlady's cruel taunt: "bl yM+dh dk Lokeh ;gk¡ ugha jgrk gS] ;g vosQyh gh HkkM+s osQ ?kj esa cPpksa osQ lkFk jgrh gS." The atmosphere is shame ("ysxks NsM+[kkuh djuk pkgrs") not hope. However, the narrator frames it as strategic sacrifice: "brus iSlksa esa xq”kkjk oSQls gksxk" — she endures present atmospheric poison for future possibility. A one-sided "hope" answer ignores the text's unflinching portrayal of maternal grief; a one-sided "separation" answer ignores her conscious agency in choosing this pain.

## DIAGNOSTIC_QUESTION_6
Write a 150-word atmospheric description of a fourth setting implied but not fully described in the text: the narrator's childhood home, using sensory details consistent with the story's established tone and themes.

## DIAGNOSTIC_ANSWER_6
A strong answer will use the story's linguistic register (Hindi with regional inflections), incorporate motifs of confined spaces, absent fathers, working mothers, and intergenerational silence. Example opening: "Vh ?kj Hkh ik¡p lkS #i;s ka Fkk, jahan baap ki awaz nahi, maa ki thakan thi..." Must show: (1) physical parallel to current home, (2) atmospheric origin of her resilience, (3) absence of nurture as inherited condition. A poor answer writes generic "poor childhood" without linking to the text's specific atmospheric grammar — the interplay of surveillance, labor, and silenced female voice that defines all settings in the story.

## COMMON_MISCONCEPTION
Students treat setting as "where the story happens" and atmosphere as "mood words like sad or happy." In "vkyks&vk¡èkkfj," they miss how the same physical space (e.g., rkrq'k's study with manuscripts) creates different atmospheres for different characters — intellectual sanctuary for rkrq'k, surveillance chamber for the narrator. They also fail to see setting as dynamic: the narrator's own home shifts from "ikuh dh vlqfoèkk" (freedom of solitude) to "cPpksa dks ysdj vc eSa dgk¡ tkmQ¡" (suffocation of responsibility) as her children grow. The error stems from reading setting statically rather than as a site of power negotiation that changes with the protagonist's consciousness.

## ON_FAILURE
Step 1: Have the student reread the lquhy household section (pages 21-22) and list every verb describing what the narrator DOES in that space (cooks, hides children, endures questions, flees). Step 2: Repeat for rkrq'k's household (writes, reads, learns, resists, complies). Step 3: Compare the verb lists — first setting = survival verbs; second = negotiation verbs. Step 4: Ask: "If setting were just background, why do her verbs change?" This makes visible how setting shapes agency. Step 5: Apply the same verb-analysis to her own home across three timepoints (early, middle, late story) to prove setting's dynamic nature.

## BUILDS_ON
c11_hin_v_cbse_03_002 (Plot and Narrative Structure) — understanding the sequence of households is prerequisite to analyzing their atmospheric progression.

## LEADS_TO
c11_hin_v_cbse_03_004 (Character Analysis: Protagonist) — the protagonist's character is forged through her negotiation with these settings; atmosphere analysis provides the crucible for character analysis.

## PREREQUISITE_NODE_IDS
c11_hin_v_cbse_03_001, c11_hin_v_cbse_03_002
## PREREQUISITE_REASONS
c11_hin_v_cbse_03_001: Context and background knowledge of Krishna Sobti's feminist perspective and the socio-historical milieu of working-class women in mid-20th century North India is essential to decode the atmospheric codes of each setting.
c11_hin_v_cbse_03_002: Plot and narrative structure provides the chronological framework of the narrator's movement across households; without this sequence, setting analysis becomes fragmented rather than developmental.

## FORWARD_NODE_IDS
c11_hin_v_cbse_03_004, c11_hin_v_cbse_03_005, c11_hin_v_cbse_03_006, c11_hin_v_cbse_03_008, c11_hin_v_cbse_03_013, c12_hin_a_cbse_06_003, c12_hin_al_cbse_03_003, c12_hin_v_cbse_03_003

## FORWARD_REASONS
c11_hin_v_cbse_03_004: The protagonist's character traits (resilience, literary aspiration, maternal sacrifice) are direct responses to the atmospheric pressures of each setting analyzed here.
c11_hin_v_cbse_03_005: Supporting characters (lquhy, rkrq'k, ckck, tsBw) are defined by their relationship to the settings they inhabit or control; their atmospheric function precedes their character analysis.
c11_hin_v_cbse_03_006: Primary themes (gendered labor, education as liberation/entrapment, autonomy vs. survival) emerge from the dialectic between character and setting established in this node.
c11_hin_v_cbse_03_008: Imagery and metaphor (manuscripts as power, cramped space as structural violence, hostel as sacrificial altar) are atmospheric devices rooted in specific settings.
c11_hin_v_cbse_03_013: Critical interpretation requires synthesizing how setting-atmosphere-character interact across the full narrative arc — this node provides the setting-atmosphere foundation.
c12_hin_a_cbse_06_003: Essay/memoir atmosphere techniques  
c12_hin_al_cbse_03_003: Reinforces setting-atmosphere analysis in a different text (Vitan), ensuring transferable skill.  
c12_hin_v_cbse_03_003: Provides the foundational definitions and analytical framework for setting/atmosphere (layers, sensory mapping) that this Class 12 node deepens with historical stratification.  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
none

## CHAIN_DESCRIPTION
c11_hin_v_cbse_03_001 -> c11_hin_v_cbse_03_002 -> c11_hin_v_cbse_03_003 -> c11_hin_v_cbse_03_004

## THIS_FORMULA
Setting Analysis Framework: Physical Details + Social Power Dynamics + Sensory Atmosphere + Character Response = Thematic Function of Setting

## FORMULA_VARIABLES
Physical Details: Concrete spatial descriptors (size, facilities, objects, layout)
Social Power Dynamics: Hierarchies, surveillance, patronage, exploitation embedded in the space
Sensory Atmosphere: Emotional tone generated by the above (oppression, conditional warmth, exhausted autonomy)
Character Response: How the protagonist acts, resists, adapts, or transforms within the space
Thematic Function: What the setting reveals about the story's central concerns (gender, class, writing, motherhood)

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
analytical

## CROSS_SUBJECT
c11_sociology_social_structure | The three households represent distinct class-gender intersections: feudal patriarchy (lquhy), educated middle-class patriarchy (rkrq'k), and working-class matriarchy (narrator's home) — a sociological triad.
c11_geography_human_environment | The spatial progression (employer homes → own home → hostel → return) maps onto rural-urban migration patterns and the geography of domestic labor in postcolonial India.
c11_economics_labor_markets | The narrator's labor shifts from unpaid/reproductive (lquhy) to skilled/intellectual (rkrq'k) to self-directed but precarious (own home) — illustrating informal economy trajectories for women.

## PREREQ_CONCEPT
Narrative sequence of the protagonist's employment across three households (lquhy → rkrq'k → own home) and the hostel interlude.

## PREREQ_BEFORE
Student must recall the chronological order of the narrator's workplaces and the key conflict at each: interrogation at lquhy's, mentorship-control at rkrq'k's, autonomous struggle at own home.

## PREREQ_STUCK
Review c11_hin_v_cbse_03_002 (Plot and Narrative Structure) focusing on the "movement across households" flowchart; create a timeline with setting, duration, and primary conflict at each.

## WORKED_EXAMPLE_1
PROBLEM: Analyze how the physical layout of lquhy's house (pages 21-22) creates an atmosphere of institutional surveillance rather than domestic intimacy. Use the Setting Analysis Framework.

STEPS:
- Step 1: Identify physical details — "HkkM+k rks ik¡p lkS #i;s gh Fkk" (five feet space), "V^h&is'kkc osQ fy, ckgj tkuk gksrk Fkk" (toilet far away), "pkj ?kjksa osQ chp ckFk:e ,d gh Fkk" (one courtyard for four houses), "yM+osQ&yM+fd;ksa dks gkFk esa cksry fy, tkrs" (women queue for water).
- Step 2: Map social power dynamics — landlady (lquhy) controls access to basics; narrator is interrogated by "vkl&ikl osQ yksx" (neighbors); no privacy for bodily functions; labor extracted without dignity.
- Step 3: Determine sensory atmosphere — olfactory (shared toilet), auditory (constant questioning), tactile (cramped cooking), visual (surveillance from all sides) — composite = dehumanizing exposure.
- Step 4: Analyze character response — narrator hides children ("cPpksa dks lkFk ys eSa mlh le; dke [kkstus fudy iM+rh"), endures silently ("ckrsa vulquh dj"), plans escape ("eSa lksprh fd mlls vPNh txg dgk¡ fey ldrh gSA").
- Step 5: State thematic function — this setting embodies feudal patriarchy where working-class women's bodies are public property; the atmosphere is not "sad" but structurally violent.

REASONING: The framework forces separation of observable details from interpretive claims, preventing the "mood word" error. Each step builds evidence for the conclusion that setting here is an instrument of class-gender oppression.

ANSWER: lquhy's house functions as a carceral domestic space where physical confinement (5 feet, shared courtyard, distant toilet) enacts social confinement (surveillance, interrogation, bodily exposure). The atmosphere of "institutional surveillance" is produced by the alignment of architectural design with patriarchal entitlement — neighbors feel entitled to question ("rqEgkjk Lokeh dgk¡ jgrk gS\"), landlady controls movement ("dke osQ lkFk eSa ?kj Hkh <w¡<+ jgh Fkh"). The narrator's response — hiding children, silent endurance, escape planning — confirms the atmosphere's function: it produces resistance through flight, not voice.

## WORKED_EXAMPLE_2
PROBLEM: Contrast the atmosphere of rkrq'k's study (pages 27-28) with the narrator's own kitchen (pages 32-33) using the concept of "intellectual space vs. survival space."

STEPS:
- Step 1: Extract physical details of rkrq'k's study — "dejs esa rhu vkyekfj;k¡ fdrkcksa ls Hkjh Fkha" (drawer with manuscripts), "ckaXyk dh Hkh dkI+kQh fdrkcsa" (literary manuscripts), "fdrkcsa [kksydj Hkh ns[krh" (reading stolen pages), "MfLaVx dj jgh Fkh" (typing).
- Step 2: Extract physical details of narrator's kitchen — "HkkM+k rks ik¡p lkS #i;s gh Fkk" (five feet), "yM+osQ&yM+fd;ksa dks gkFk esa cksry fy, tkrs" (women queue for water), "ckFk:e dh vlqfoèkk Hkh Fkh" (courtyard freedom), "nok flI+kZQ ykrs gh ugha" (husband brings alcohol not food).
- Step 3: Analyze power dynamics in study — rkrq'k controls literary capital ("fy[kus dks rqe viuh thou&dgkuh Hkh fy[k ldrh gks"), gatekeeps publication ("fp_h dksydkrk ls muosQ ,d caèkq us Hksth gSA"), demands gratitude ("rqEgsa bu lc ckrksa dks ysdj vHkh ekFkk&iPph djus dh ”k:jr ugha gSA").
- Step 4: Analyze power dynamics in kitchen — narrator controls her labor ("viuk dke pykÅ¡xh vkSj oSQls ?kj dk fdjk;k nw¡xh"), but lacks resources ("ikuh dh vlqfoèkk FkhA ogk¡ ckFk:e dh vlqfoèkk Hkh Fkh"), faces spousal parasitism ("nok flI+kZQ ykrs gh ugha cfYd ftl le; tks nok [kkuh gS mls fudkydj ns Hkh nsrs").
- Step 5: Synthesize atmospheric contrast — study = intellectual patronage as subtle cage (air of "conditional benevolence"); kitchen = survival autonomy as exhausted freedom (air of "bare life with dignity"). Both trap her; the study traps her mind, the kitchen traps her body.

REASONING: This contrast reveals the story's central irony — the "liberating" space of writing is more atmospherically controlling than the "oppressive" space of domestic labor, because the former colonizes her imagination while the latter only colonizes her time.

ANSWER: rkrq'k's study creates an atmosphere of "gilded captivity" — manuscripts symbolize literary power he doles out conditionally ("rqe oqQN fdrkcsa i<+ks vkSj rkrq'k osQ ikl ls ckaXyk vfHkèkku ysdj jks”k mls iyVk djks"). The narrator's kitchen creates an atmosphere of "raw sovereignty" — she owns her labor ("eSa viuk dke pykÅ¡xh") but lacks the material conditions to convert it into intellectual freedom. The study's atmosphere smells of paper and permission; the kitchen's smells of smoke and autonomy. The story's tragedy: she cannot inhabit both simultaneously — to write she must enter his study; to survive she must rule her kitchen. The hostel decision (sending children away) is the atmospheric bridge: she sacrifices kitchen-intimacy for study-possibility.

## WORKED_EXAMPLE_3
PROBLEM: The final pages (52-56) return to the narrator's home after her husband's death. Trace how the atmosphere of this setting has transformed from pages 32-33 to pages 52-56, and explain what this transformation reveals about the story's theory of women's autonomy.

STEPS:
- Step 1: Reconstruct early home atmosphere (pages 32-33) — "HkkM+k rks ik¡p lkS #i;s gh Fkk," "yM+osQ&yM+fd;ksa dks gkFk esa cksry," "nok flI+kZQ ykrs gh ugha," "cPpksa dks iky&iksldj cM+k djus dh rjI+kQ," "eSa viuk dke pykÅ¡xh vkSj oSQls ?kj dk fdjk;k nw¡xh" — atmosphere: exhausted autonomy, maternal burden, spousal parasitism, communal solidarity among women.
- Step 2: Reconstruct late home atmosphere (pages 52-56) — "ckck pys x,A mUgsa dgha ls irk py x;k Fkk fd eSa oqQN fy[k&fo[k jgh gw¡A" (husband leaves, acknowledging her writing), "rkrq'k us muls dgk] vki csch dh rjI+kQ ls fuf'apr gksdj tk,¡A" (rkrq'k validates her professional identity), "esjs cPps... vc u rks igys dh rjg ”kjk&”kjk lh ckr ij jksus&fpYykus yxrs" (children matured), "eSa oqQN cksyrh] blosQ igys gh mlus fiQj dgk] ek] ,d dfork lqukvks u!" (she claims leisure/authority).
- Step 3: Identify atmospheric shifts — from survival to recognition; from hiding writing to claiming it publicly; from maternal anxiety to maternal authority; from spousal drain to spousal absence-as-relief; from communal queues to individual voice ("esjk mRlkg c<+kus okyksa esa tsBw osQ ,d caxkyh caèkq] vkuan Hkh FksA").
- Step 4: Analyze causal drivers — her writing practice (sustained across settings), children's education (hostel sacrifice bearing fruit), husband's death (removing parasitic load), rkrq'k's mentorship (delayed validation).
- Step 5: Evaluate autonomy theory — autonomy is not a setting (no "room of one's own") but a practice forged across settings. The home's atmosphere transforms because SHE transforms — she imports the study's intellectual authority into the kitchen's survival space. The final atmosphere: "ltuk vPNk yxrk gSA rqe esjs fy, ltuk vkSj eSa rqEgkjs fy, ltw¡xhA" — mutual recognition replacing hierarchical surveillance.
- Step 6: Connect to feminist literary theory — this mirrors Virginia Woolf's "room of one's own" but materialist: the room is not given, it is written into existence through labor across class positions.

REASONING: This multi-step analysis demonstrates how setting-atmosphere is not static but dialectical — the protagonist carries atmospheric residues from each setting (lquhy's surveillance → hyper-vigilance; rkrq'k's study → literary discipline; kitchen → survival skills) and synthesizes them into a new atmospheric mode at the end. The "transformation" is not in the physical space (still 5 feet) but in the power geometry within it.

ANSWER: The home's atmosphere shifts from "survival under siege" (pages 32-33: cramped, husband draining resources, children needing protection, writing hidden) to "sovereignty through synthesis" (pages 52-56: husband gone validating her writing, children educated, writing public, leisure claimed). The physical space is identical — "HkkM+k rks ik¡p lkS #i;s gh Fkk" — but the power geometry is inverted. She now occupies the center: "esjk mRlkg c<+kus okyksa esa tsBw osQ ,d caxkyh caèkq] vkuan Hkh FksA... rqEgkjs fy[kkoV igys eq>s dkI+kQh d"V nsrh FkhA vc d"V nsus dh ckr rks nwj." The story's theory: women's autonomy is not spatial (a room) but temporal-practical — the accumulation of negotiated agency across oppressive settings, carried forward as atmospheric capital. The final home atmosphere is the compound interest of all her setting-negotiations.

## COMPETENCY_QUESTION_1
QUESTION: In "vkyks&vk¡èkkfj," the narrator describes rkrq'k's house as having "ikuh dh vlqfoèkk" (freedom of solitude) yet she feels "cqjk" (suffocated) when he monitors her reading. Using the Setting Analysis Framework, explain how a space can simultaneously offer intellectual freedom and patriarchal surveillance. Provide two specific textual instances where the same physical object (e.g., a manuscript, a drawer, a typewriter) functions as both liberation and control.

COMPETENCY: Critical analysis of setting as contested space with dual atmospheric valences

STEPS:
- Step 1: Define the paradox — "ikuh dh vlqfoèkk" vs. "cqjk" — using the framework's Social Power Dynamics and Character Response variables.
- Step 2: Identify first object — the drawer with manuscripts ("dejs esa rhu vkyekfj;k¡ fdrkcksa ls Hkjh Fkha"). Liberation: access to literary world ("fy[kus dks rqe viuh thou&dgkuh Hkh fy[k ldrh gksA"). Control: rkrq'k curates what she reads ("rkrq'k us eq>ls igys gh iwNk Fkk] rqe tgk¡ jgrh gks ogk¡ dksbZ ckFk:e&okFk:e gS fd ugha").
- Step 3: Identify second object — the typewriter ("MfLaVx dj jgh Fkh"). Liberation: professional skill acquisition ("fy[kus&i<+uk rks vc gksus ls jgkA"). Control: rkrq'k claims ownership of her output ("rqEgkjs caèkq rqEgkjk fdruk mRlkg c<+k jgs gSaA"), demands gratitude ("rqEgkjs rkrq'k us lpeqp gh ,d ghjk [kkst fudkyk gS!").
- Step 4: Synthesize — the atmosphere is "patriarchal patronage": freedom granted as gift, revocable at donor's will. The narrator's response — "eSaus lkspk] lpeqp eq>ls vU;k; gqvkA" (realized she was being used) — shows her reading the atmosphere correctly.

ANSWER: rkrq'k's study embodies "patriarchal patronage" — a dual atmosphere where intellectual resources (manuscripts, typewriter, literary contacts) are physically accessible but socially conditional. The drawer of manuscripts offers liberation (she discovers writers: "johUnzukFk BkoqQj] dk”kh u”k#y bLyke...") but enacts control (rkrq'k decides when/what she reads: "rqEgsa fy[kus&i<+us dk 'kkSd gS\"). The typewriter offers professionalization ("fy[kus&i<+uk rks vc gksus ls jgkA") but enacts extraction ("rqEgkjs caèkq rqEgkjk fdruk mRlkg c<+k jgs gSaA"). The atmosphere is not "freedom with strings" but "freedom AS strings" — the very tools of liberation are the instruments of bondage. The narrator's eventual refusal ("rkrq'k dh ckr eSa vulquh u djrh rks D;k djrh!") marks her atmospheric literacy: she reads the gift as trap.

DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: The hostel where the narrator places her children is never directly described — we experience it only through her grief ("cPpksa dks ysdj vc eSa dgk¡ tkmQ¡!"), the landlady's taunts ("bl yM+dh dk Lokeh ;gk¡ ugha jgrk gS"), and her children's letters (implied). Using atmospheric inference, reconstruct the hostel's implied atmosphere and argue whether it functions as a "setting of hope" or "setting of structural violence" in the story's architecture. Support with three textual anchors from different narrative moments.

COMPETENCY: Inferential atmospheric reconstruction from absent/elliptical setting representation

STEPS:
- Step 1: Identify the three textual anchors — (a) narrator's decision moment: "bruh tYnh nwljk ?kj Hkh dgk¡ feysxk! cPpksa dks vius ikl fcBk, eSa jksus yxhA" (page 32); (b) landlady's taunt: "bl yM+dh dk Lokeh ;gk¡ ugha jgrk gS] ;g vosQyh gh HkkM+s osQ ?kj esa cPpksa osQ lkFk jgrh gSA" (page 33); (c) children's growth outcome: "os vc u rks igys dh rjg ”kjk&”kjk lh ckr ij jksus&fpYykus yxrs] u gh cseryc bèkj&mèkj HkVdrsA" (page 54).
- Step 2: Infer hostel atmosphere from each anchor — (a) maternal sacrifice atmosphere: "xq”kkjk oSQls gksxk" (she knows the cost); (b) social stigma atmosphere: "ysxks NsM+[kkuh djuk pkgrs" (hostel = marker of fatherlessness); (c) educational outcome atmosphere: children become "cseryc bèkj&mèkj" (modern, educated) — the hostel produced the class mobility she sought.
- Step 3: Evaluate "hope vs. structural violence" — Hope evidence: children educated, narrator's plan worked ("brus iSlksa esa xq”kkjk oSQls gksxk"). Structural violence evidence: mother-child separation enforced by poverty ("eSa dgk¡ tkmQ¡!"), patriarchal taunt defining her as failed mother ("Lokeh ;gk¡ ugha jgrk"), hostel as institution replacing maternal care with institutional discipline.
- Step 4: Synthesize — the hostel is a "setting of violent hope" — hope achieved through structural violence. The atmosphere is not in the hostel (never shown) but in the narrator's psyche: "eSa lksprh ge yksxksa dks f[kyk&iguk rks og jgs gh gSa] vkSj fdruk djsaxs gekjs fy,!" — she internalizes the violence as necessary cost.
- Step 5: Connect to story's architecture — the absent hostel setting haunts all present settings; its atmosphere is the ghost in every room she occupies thereafter.

ANSWER: The hostel functions as "violent hope" — a setting whose atmosphere is constructed entirely through absence and consequence. Three anchors prove this: (1) The decision moment (p.32) establishes atmosphere of "calculated rupture" — "bruh tYnh nwljk ?kj Hkh dgk¡ feysxk! cPpksa dks vius ikl fcBk, eSa jksus yxhA" — she chooses separation as strategy, not desperation. (2) The landlady's taunt (p.33) establishes atmosphere of "patriarchal shaming" — "bl yM+dh dk Lokeh ;gk¡ ugha jgrk gS" — the hostel marks her as failed wife/mother in communal eyes. (3) The outcome (p.54) establishes atmosphere of "class transformation" — children speak "cseryc bèkj&mèkj," not village dialect. The hostel's implied atmosphere: institutional discipline replacing maternal intimacy, producing the very modernity that will later validate her writing ("rqEgkjs fy[kkoV ns[kdj cgqr [kq'kh gksrh gSA"). It is structural violence (mother-child separation as tuition for class mobility) that generates hope (educated children, professional mother). The story's architecture makes the hostel the invisible engine: every subsequent atmospheric shift (her writing recognized, husband acknowledging her, rkrq'k validating her) runs on the fuel burned there. The hostel is not a setting in the story; it is the story's atmospheric unconscious.

DIFFICULTY: hard