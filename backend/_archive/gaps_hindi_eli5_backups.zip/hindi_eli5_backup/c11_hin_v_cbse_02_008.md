## DEFINITION
Imagery is the use of vivid, sensory language that appeals to the five senses (sight, sound, smell, touch, taste) to create mental pictures and evoke emotions. Metaphor is a figure of speech that directly compares two unrelated things by stating one is the other, revealing a hidden similarity without using "like" or "as".

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student can identify at least three distinct images in the text, explain which senses they appeal to, and analyze how two specific metaphors deepen the reader's understanding of the salt workers' lives or the landscape.

## SCOPE_BOUNDARY
This node covers identification and analysis of imagery (visual, auditory, tactile, olfactory, gustatory) and metaphor in the chapter "जक्तLFकku dh jtr cw¡nas". It does not cover other literary devices like irony, symbolism, or simile (which are in the next node).

## WALKTHROUGH
Imagine you are standing barefoot on the white salt flats of the Rann of Kutch at noon — the glare hurts your eyes, the heat burns your soles, and the air smells of brine and sweat. The chapter makes you feel exactly that through carefully chosen words. To begin, pick a paragraph that describes the salt-making process (e.g., the description of the Agariyas working in the pans). Read it slowly and underline every word that makes you see, hear, feel, smell, or taste something. Then ask: "What two things are being compared directly without 'like' or 'as'?" That is your metaphor. The key insight is that the author uses these devices not just for decoration but to make the harsh, beautiful reality of the salt pans visceral and unforgettable.

## DIAGNOSTIC_QUESTION_1
What is the definition of imagery in literature? List the five senses it can appeal to.

## DIAGNOSTIC_ANSWER_1
Imagery is the use of descriptive language that appeals to the five senses — sight, sound, smell, touch, and taste — to create vivid mental pictures. A wrong answer (e.g., "imagery means pictures in a book") reveals the student confuses the literary term with visual illustrations and misses the sensory dimension.

## DIAGNOSTIC_QUESTION_2
In the chapter, the author writes: "ओक़बज़ ओक्कज़ उस्के तय दक्स चमस फोफपकु <अक्स लेसवर्ह गस — रच हि तस ओक्कज़ घि उस्के!" Explain in your own words what this metaphor suggests about the salt pan and the natural process of evaporation.

## DIAGNOSTIC_ANSWER_2
The metaphor suggests that the salt pan acts like an efficient, almost intentional machine that separates salt from water even without the sun's direct heat, highlighting the ingenuity of the Agariyas' traditional method. A wrong answer (e.g., "it means the salt pan is hot") shows the student takes the metaphor literally and misses the comparison between the pan and a purposeful separator.

## DIAGNOSTIC_QUESTION_3
Find one example of tactile imagery (related to touch) from the text and explain how it helps the reader experience the physical conditions of the salt workers.

## DIAGNOSTIC_ANSWER_3
Example: "क्लकस्यह ंक्सवह ढककक ढककक ढकक" (the description of the salt crust being hard like a hoof). This tactile image lets the reader feel the hardness and unevenness of the salt surface underfoot, conveying the physical strain on workers' feet. A wrong answer that picks a visual image ("white salt flats") shows the student cannot distinguish sensory modalities.

## DIAGNOSTIC_QUESTION_4
Compare the metaphors "उसफर-उसफर तसलक ओक़कन इसपहन्क एकेक गस" (mirage-like illusion) and "ओक़बज़ ओक्कज़ उस्के तय दक्स..." (salt pan separates salt from water). How do these two metaphors create contrasting impressions of the salt pan landscape?

## DIAGNOSTIC_ANSWER_4
The first metaphor portrays the salt pan as an elusive, dreamlike mirage — beautiful but intangible — while the second portrays it as a practical, grounded tool that reliably extracts salt. Together they capture the dual nature of the Rann: a harsh, illusory landscape that is also a site of real, skilled labor. A wrong answer that treats both as mere descriptions misses the contrast between illusion and utility.

## DIAGNOSTIC_QUESTION_5
The author calls the salt pan "फुथ वस लककज़तफुद लइफकक दक फोहककतु दुस ओकह जस[क्क ओक़बज़ उस्के एकेक इसा चमस फोफपकु <अक्स फेव तकरह गस" (a raw narrator of history and geography). Evaluate whether this metaphor is effective in conveying the chapter's central theme. Justify your answer.

## DIAGNOSTIC_ANSWER_5
Yes, it is effective because the salt pan literally contains layers of history (generations of Agariyas) and geography (the Rann's unique ecology) in its crystals, and the metaphor elevates a simple evaporation bed to a storyteller. A weak evaluation (e.g., "it's a nice metaphor") without textual evidence shows the student cannot critique literary devices against thematic purpose.

## DIAGNOSTIC_QUESTION_6
Write a short paragraph (4-5 lines) describing a monsoon evening in your city using at least two types of imagery and one original metaphor (do not copy from the text).

## DIAGNOSTIC_ANSWER_6
A good answer will include, e.g., auditory imagery (rain drumming on tin roofs), olfactory imagery (wet earth smell), and a metaphor like "the streets turned into mirrors reflecting the city's lights". A poor answer uses only visual imagery and a clichéd metaphor ("rain like tears"), showing limited sensory range and derivative thinking.

## COMMON_MISCONCEPTION
Students often think imagery only means "visual description" and miss auditory, tactile, olfactory, and gustatory images. They also confuse metaphor with simile, believing any comparison is a metaphor, and fail to see that a metaphor asserts identity ("A is B") rather than similarity ("A is like B"). For example, they might call "salt pan is like a mirror" a metaphor, but it's a simile; the text's "salt pan is a narrator" is a true metaphor.

## ON_FAILURE
1. Have the student close their eyes and listen to a 30-second audio of a busy kitchen; ask them to list every non-visual sense they notice (sound of chopping, smell of spices, heat on face). 2. Give them two sentences: "The exam was a monster" and "The exam was like a monster"; ask which is a metaphor and why. 3. Return to the text and together annotate one paragraph, labeling each sensory image with a colored pencil (red=sight, blue=sound, etc.). 4. Ask them to rewrite one visual-only description from the text by adding two other senses.

## BUILDS_ON
This node builds on the student's ability to identify sensory details in descriptive writing (from earlier prose chapters) and to distinguish literal from figurative language.

## LEADS_TO
This node enables the analysis of irony and symbolism (next node), where metaphors often become sustained symbols, and imagery creates ironic contrasts.

## PREREQUISITE_NODE_IDS
c11_hin_v_cbse_02_001, c11_hin_v_cbse_02_002, c11_hin_v_cbse_02_003, c11_hin_v_cbse_02_006, c11_hin_v_cbse_02_007

## PREREQUISITE_REASONS
c11_hin_v_cbse_02_001: Context and background knowledge of the Rann of Kutch and Agariyas is essential to understand the setting that the imagery describes.
c11_hin_v_cbse_02_002: Understanding the plot and narrative structure helps locate where key images and metaphors appear in the text's progression.
c11_hin_v_cbse_02_003: The setting and atmosphere node establishes the physical environment that the imagery evokes and the metaphors interpret.
c11_hin_v_cbse_02_006: Imagery (fire, clay, smoke) and metaphor (kiln as furnace of lives) aesthetically render the primary theme.  
c11_hin_v_cbse_02_007: Imagery and metaphor (e.g., "pond as memory vessel") are the literary vehicles through which secondary themes are conveyed.  

## FORWARD_NODE_IDS
c11_hin_v_cbse_02_009, c11_hin_v_cbse_02_013, c11_hin_v_cbse_02_014, c12_hin_a_cbse_04_008, c12_hin_a_cbse_05_008

## FORWARD_REASONS
c11_hin_v_cbse_02_009: Irony and symbolism often extend the metaphors and imagery analyzed here; e.g., the salt pan as a "narrator" becomes a symbol of cultural memory.
c11_hin_v_cbse_02_013: Critical thinking and interpretation require the ability to deconstruct literary devices, which this node teaches.
c11_hin_v_cbse_02_014: Imagery and metaphor (e.g., land as text, moisture as language) supply analytical vocabulary for Explanation steps.  
c12_hin_a_cbse_04_008: Metaphor in free verse — "cukjl" is free verse.  
c12_hin_a_cbse_05_008: Reinforces metaphor analysis in non-fiction contexts.  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
none

## CHAIN_DESCRIPTION
c11_hin_v_cbse_02_003 -> c11_hin_v_cbse_02_008 -> c11_hin_v_cbse_02_009

## THIS_FORMULA
N/A - conceptual

## FORMULA_VARIABLES
N/A

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
linguistic

## CROSS_SUBJECT
c11_geography_physical_geography | The chapter's vivid imagery of the Rann's salt flats, seasonal flooding, and evaporation mirrors geographic concepts of landforms, climate, and human adaptation to extreme environments.
c11_economics_livelihoods | The metaphors of labor (salt pan as "narrator of history") connect to economic themes of traditional livelihoods, informal labor, and the valuation of indigenous knowledge systems.

## PREREQ_CONCEPT
Ability to distinguish literal language from figurative language and to identify the five senses in descriptive writing.

## PREREQ_BEFORE
Student must be able to pick out descriptive adjectives and verbs from a Hindi prose passage and say which sense they appeal to.

## PREREQ_STUCK
Review the "Setting and Atmosphere" node (c11_hin_v_cbse_02_003) and practice listing sensory words from any descriptive paragraph.

## WORKED_EXAMPLE_1
PROBLEM: Analyze the imagery in the paragraph describing the Agariyas working in the salt pans under the midday sun (text: "म्दमव़ चसबुक] इअत्स उस्के चय ?ककवुस एक्सम+ दज चसुबकअ..."). Identify three distinct sensory images and explain their combined effect.

STEPS:
- Step 1: Locate the paragraph in the text that describes the workers' midday labor (look for keywords like "दुपहिर", "धूप", "पसीना", "नमक").
- Step 2: Underline every word or phrase that triggers a sense: e.g., "तपती धूप" (touch/heat), "पसीने की गंध" (smell), "नमक की चमक" (sight), "चलते समय पैरों की रगड़" (touch/sound).
- Step 3: Classify each underlined phrase by sense modality (visual, tactile, olfactory, auditory, gustatory).
- Step 4: Select three images from different modalities (e.g., visual: "सफेद नमक की चादर", tactile: "जलती रेत पर नंगे पैर", olfactory: "खारे पानी की गंध").
- Step 5: Explain how together they create a holistic, immersive experience — the reader not only sees the whiteness but feels the burn, smells the brine, hearing the crunch — conveying the totality of the workers' reality.

REASONING: This step-by-step method moves from textual evidence to sensory classification to synthetic analysis, mirroring the board exam expectation of "quote, identify, explain effect".

ANSWER: The paragraph uses visual imagery ("सफेद नमक की चादर बिछी हुई"), tactile imagery ("जलती रेत पर नंगे पैर चलना"), and olfactory imagery ("खारे पानी और पसीने की मिली-जुली गंध"). Together they immerse the reader in the multisensory harshness of the Agariyas' work, making the labor palpable rather than merely described.

## WORKED_EXAMPLE_2
PROBLEM: The text states: "ओक़बज़ ओक्कज़ उस्के तय दक्स चमस फोफपकु <अक्स लेसवर्ह गस — रच हि तस ओक्कज़ घि उस्के!" Identify the metaphor, name the two things compared, and explain the point of similarity.

STEPS:
- Step 1: Identify the sentence as a metaphor (no "जैसा", "जैसे", "समान").
- Step 2: Extract the two terms: Tenor (subject) = "ओक़बज़" (salt pan), Vehicle (object of comparison) = an implied agent that "separates salt from water" (like a filter or a skilled craftsman).
- Step 3: State the implicit comparison: The salt pan is described as performing the separation actively, even without the sun (the usual agent of evaporation).
- Step 4: Determine the ground of comparison: Both the salt pan and a deliberate separator achieve the same result — extracting salt from brine — highlighting the efficacy of the traditional design.
- Step 5: Connect to theme: This metaphor honors the Agariyas' indigenous technology, showing it as intentional and sophisticated, not primitive.

REASONING: Metaphor analysis requires naming tenor and vehicle, stating the grounds, and linking to authorial purpose — a standard literary analysis framework.

ANSWER: Metaphor: "ओक़बज़ ओक्कज़ उस्के तय दक्स चमस फोफपकु <अक्स लेसवर्ह गस". Tenor: salt pan (ओक़बज़). Vehicle: an efficient separator (implied). Ground: both separate salt from water without needing the sun's direct heat. Significance: It elevates the traditional salt pan to a marvel of indigenous engineering, reinforcing the theme of unrecognized expertise.

## WORKED_EXAMPLE_3
PROBLEM: Compare the metaphor "उसफर-उसफर तसलक ओक़कन इसपहन्क एकेक गस" (mirage-like illusion) with the later description of the salt pan as "फुथ वस लककज़तफुद लइफकक दक फोहककतु दुस ओकह जस[क्क" (raw narrator of history and geography). How do these two metaphors frame the salt pan differently, and what does the shift reveal about the author's perspective?

STEPS:
- Step 1: Identify the first metaphor (mirage) — occurs early in the chapter when the narrator first sees the pans from a distance.
- Step 2: Identify the second metaphor (narrator) — occurs near the end after detailed description of the process, people, and history.
- Step 3: Analyze the first metaphor's connotations: illusion, distance, beauty, unreality, something that vanishes on approach.
- Step 4: Analyze the second metaphor's connotations: truth-telling, groundedness, accumulated wisdom, authenticity, voice of the land.
- Step 5: Trace the shift: The narrator moves from an outsider's distant, aestheticized view to an insider's informed, respectful understanding.
- Step 6: Conclude: The shift mirrors the reader's journey through the chapter — from seeing the Rann as a mysterious white expanse to recognizing it as a living cultural landscape.

REASONING: This example combines metaphor identification, connotation analysis, structural positioning, and thematic synthesis — a multi-step competency expected in board exams.

ANSWER: The "mirage" metaphor frames the salt pan as an elusive, almost magical spectacle viewed from afar, emphasizing its visual strangeness. The "narrator" metaphor frames it as a truth-bearing, historical entity that speaks of generations and geography. The shift reveals the author's movement from romantic outsider to empathetic chronicler, inviting the reader to undergo the same transformation.

## COMPETENCY_QUESTION_1
QUESTION: The chapter uses the metaphor "नमक की पवित्रता कठोर परिश्रम का प्रतीक बन जाती है" (the purity of salt becomes a symbol of hard labor). Explain how the imagery of the salt-making process (evaporation, crystallization, scraping) supports this metaphor. Use at least two specific sensory images from the text in your explanation.

COMPETENCY: Analytical interpretation of metaphor supported by textual imagery

STEPS:
- Step 1: Identify the metaphor: salt purity = symbol of hard labor.
- Step 2: Recall the process imagery: brine evaporation under sun (visual: shimmering pans; tactile: heat), crystal formation (visual: geometric shapes; auditory: crust cracking), scraping and collecting (tactile: rough crystals; kinesthetic: repetitive bending).
- Step 3: Select two sensory images: e.g., visual "धूप में चमकते नमक के कण" and tactile "कठोर नमक की परत को खुरचने का एहसास".
- Step 4: Explain how each image embodies labor: the shimmering crystals are the visible result of days of tending pans; the hard crust requires physical force to break, mirroring the workers' endurance.
- Step 5: Synthesize: The metaphor is earned because the text makes the labor sensorially present at every stage.

ANSWER: The metaphor is supported by the visual imagery of "धूप में चमकते नमक के कण" (salt grains glittering in the sun) which are the direct outcome of the Agariyas' daily tending of the pans, and the tactile imagery of "कठोर नमक की परत को खुरचने का एहसास" (the feel of scraping the hard salt crust) which mirrors the physical exertion and calloused hands of the workers. The purity of the final product is thus not a gift of nature alone but a crystallized record of human effort, making the metaphor both apt and poignant.

DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: A student writes: "The author uses a lot of imagery to describe the salt pans. For example, he says the salt pan is like a mirror and also like a narrator. These are good images." Critique this student's response. Identify two specific errors in literary terminology and analysis, and rewrite the response as a model answer for a board exam.

COMPETENCY: Critical evaluation of peer response; correct use of literary terminology; board-exam answer writing

STEPS:
- Step 1: Identify error 1: "like a mirror" and "like a narrator" — the text says "उसफर-उसफर तसलक" (mirage-like) which is a simile, and "फुथ वस लककज़तफुद... फोहककतु" (raw narrator) which is a metaphor; the student conflates both as "images" and misses the metaphor/simile distinction.
- Step 2: Identify error 2: The response is vague ("a lot of imagery", "good images") with no analysis of effect or connection to theme.
- Step 3: Recall board exam answer structure: Point (name device), Evidence (quote/paraphrase), Explanation (effect), Link (to theme).
- Step 4: Rewrite using the structure for both the mirage simile and the narrator metaphor, linking to the outsider-to-insider perspective shift.
- Step 5: Ensure the rewrite uses precise terminology (simile, metaphor, visual imagery, personification) and analytical depth.

ANSWER: The student's response contains two key errors: (1) It mislabels the metaphor "नमक का मैदान एक कथाकार है" as merely an "image" and fails to distinguish it from the simile "मृगतृष्णा जैसा भ्रम"; (2) It offers no analytical explanation of how these devices shape meaning. A board-exam standard answer would be: "The author employs a simile in 'मृगतृष्णा जैसा भ्रम' to convey the initial visual illusion of the salt flats — a shimmering, unreachable expanse that vanishes on approach — establishing the outsider's detached, aestheticized gaze. Later, the metaphor 'फुथ इतिहास और भूगोल का कथाकार' personifies the salt pan as a truth-teller, grounding the landscape in lived history and indigenous knowledge. The shift from simile to metaphor mirrors the narrator's deepening engagement, transforming the Rann from a mirage into a meaningful cultural space."

DIFFICULTY: hard