## DEFINITION
The primary theme is the central, unifying idea that the author develops through the narrative's events, characters, and language; in "फोनबूथ" it is a satirical indictment of British colonialism that exposes the systemic gap between the rhetoric of a "civilizing mission" and the reality of economic exploitation, cultural erasure, and political subjugation.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student can articulate the primary theme in a single precise sentence, cite at least three distinct textual evidences (dialogue, historical reference, or narrative detail) that collectively support the theme, and explain how each evidence connects to the central argument.

## SCOPE_BOUNDARY
This node covers identifying, articulating, and evidencing the primary theme of "फोनबूथ". It does not cover secondary themes (node 007), literary devices (nodes 008–009), vocabulary (node 010), grammar (node 011), or writing skills (node 014).

## WALKTHROUGH
Imagine you are handed a long, itemized bill for "services rendered" that you never asked for and that actually ruined your business – that is the narrator’s position in "फोनबूथ". To uncover the primary theme, first recall the plot sequence (node 002) and the narrator’s voice (node 004). Then, list every accusation the narrator levels against the departing official. Group these accusations into categories (economic, cultural, political). The theme is the umbrella statement that covers all categories. The key insight: the theme is not merely "British rule was bad" but a structured demonstration of how imperial power uses language ("सभ्यता", "कानून", "शिक्षा") to mask extraction.

## DIAGNOSTIC_QUESTION_1
What is the primary theme of the chapter "फोनबूथ" as revealed through the narrator’s monologue?

## DIAGNOSTIC_ANSWER_1
The primary theme is a comprehensive satirical critique of British colonial rule in India, exposing the hypocrisy of the "civilizing mission" by contrasting its stated ideals (progress, law, education) with its actual outcomes (economic drain, cultural destruction, political repression). A wrong answer such as "a conversation in a phone booth" reveals the student is fixated on the literal setting rather than the allegorical function of that setting.

## DIAGNOSTIC_QUESTION_2
Explain in your own words how the narrator uses the contrast between past promises and present reality to convey the theme.

## DIAGNOSTIC_ANSWER_2
The narrator systematically juxtaposes British claims – bringing "कानून", "शिक्षा", "सभ्यता" – with documented outcomes: destruction of indigenous industries (textiles, indigo), creation of a clerk class instead of thinkers, and laws that protect colonial interests rather than deliver justice. This contrast is the engine of the theme. A wrong answer that merely lists events without explaining the juxtaposition shows the student cannot see the thematic structure built on irony.

## DIAGNOSTIC_QUESTION_3
Identify three specific accusations the narrator makes against British rule and explain how each supports the primary theme.

## DIAGNOSTIC_ANSWER_3
1) Economic: "तुमने इस देश के उद्योग-धंधे चौपट कर दिए" – supports the theme of extraction masked as trade.  
2) Cultural: "अंग्रेजी पढ़ा-लिखा कर बाबू बनाया" – supports the theme of education as a tool for subservience, not liberation.  
3) Political: "कानून तुम्हारी रक्षा के लिए बने" – supports the theme of legal hypocrisy.  
A wrong answer giving vague accusations ("they were cruel") indicates inability to anchor theme in textual specifics.

## DIAGNOSTIC_QUESTION_4
Analyze how the narrator’s tone shifts throughout the monologue and what this reveals about the theme.

## DIAGNOSTIC_ANSWER_4
The tone moves from sardonic politeness ("एब यक्मज!") to biting accusation ("तुमने लूटा"), to prophetic warning ("तुम्हारा अंत निकट है"). This progression mirrors the thematic arc: surface civility → exposed brutality → inevitable historical judgment. A wrong answer that simply says "the tone is angry" misses the rhetorical strategy that structures the thematic argument.

## DIAGNOSTIC_QUESTION_5
Evaluate whether the primary theme of "फोनबूथ" remains relevant in a post-colonial context. Justify your answer.

## DIAGNOSTIC_ANSWER_5
Yes. The theme – the use of development rhetoric to legitimize extraction – applies to neocolonial economic policies, cultural hegemony through global media, and any power structure that claims benevolence while practicing exploitation. The text’s exposure of the "civilizing mission" as a linguistic mask for loot provides a analytical lens for contemporary critiques of globalization. A wrong answer that dismisses it as "only history" fails the evaluative task of recognizing thematic universality.

## DIAGNOSTIC_QUESTION_6
Write a one-paragraph thematic statement for "फोनबूथ" that could serve as a thesis for an analytical essay, incorporating the narrator’s perspective and historical context.

## DIAGNOSTIC_ANSWER_6
A strong thesis: "In 'फोनबूथ', Krishna Sobti employs a satirical monologue addressed to a departing Viceroy to deconstruct the colonial 'civilizing mission', using historical irony and direct accusation to reveal that British rule was not a benevolent modernization but a calculated system of economic extraction, cultural erasure, and political subjugation whose moral bankruptcy ensures its inevitable downfall." A weak thesis ("The chapter shows the British were bad") lacks specificity, evidence, and analytical depth.

## COMMON_MISCONCEPTION
Students often conflate the *setting* (a phone booth, a final conversation) with the *theme*. They answer "the theme is a phone call between an Indian and a British officer" because the title is "फोनबूथ". This error stems from treating the narrative frame as the message, ignoring that the phone booth is a metaphorical space for a historical reckoning where the colonized finally speaks back.

## ON_FAILURE
1) Have the student list five concrete accusations from the plot summary (node 002).  
2) Ask them to sort these into three buckets: Economic, Cultural, Political.  
3) Guide them to write a single sentence: "The narrator argues that British rule was a system of ______, ______, and ______."  
4) Show how the title "फोनबूथ" symbolizes a one-way line where the colonized voice delivers a final, unanswerable audit.

## BUILDS_ON
This node builds on plot comprehension (node 002) and protagonist analysis (node 004) to synthesize the central idea.

## LEADS_TO
This node enables the analysis of secondary themes (node 007) and literary devices like irony and symbolism (node 009) that deepen the primary theme.

## PREREQUISITE_NODE_IDS
c11_hin_ar_cbse_04_001, c11_hin_ar_cbse_04_002, c11_hin_ar_cbse_04_003, c11_hin_ar_cbse_04_004, c11_hin_ar_cbse_04_005
## PREREQUISITE_REASONS
c11_hin_ar_cbse_04_001: Provides historical context (Curzon’s viceroyalty, 1899–1905) essential to decode the accusations.  
c11_hin_ar_cbse_04_002: Plot knowledge supplies the sequence of accusations that form the thematic argument.  
c11_hin_ar_cbse_04_003: Setting analysis reveals the phone booth as a metaphorical space for truth-telling.  
c11_hin_ar_cbse_04_004: Protagonist analysis establishes the narrator as the voice of the colonized intellectual.  
c11_hin_ar_cbse_04_005: Supporting characters (British officials, Indian artisans) embody the theme’s victims and perpetrators.

## FORWARD_NODE_IDS
c11_hin_ar_cbse_04_007, c11_hin_ar_cbse_04_008, c11_hin_ar_cbse_04_009, c11_hin_ar_cbse_04_013, c11_hin_ar_cbse_04_012, c11_hin_ar_cbse_04_014, c11_hin_ar_cbse_04_015, c12_hin_ar_cbse_04_006, c12_hin_ar_cbse_12_006

## FORWARD_REASONS
c11_hin_ar_cbse_04_007: Primary theme is the trunk; secondary themes (resistance, cultural memory) are branches.  
c11_hin_ar_cbse_04_008: Imagery and metaphor (e.g., "phone booth", "loot") are vehicles for the primary theme.  
c11_hin_ar_cbse_04_009: Irony and symbolism (e.g., the "civilizing mission" irony) are techniques that sharpen the primary theme.  
c11_hin_ar_cbse_04_013: Critical thinking requires a firm grasp of the primary theme to interpret and evaluate the text.
c11_hin_ar_cbse_04_012: Primary theme (colonial exploitation) is the framework within which all inferences operate.  
c11_hin_ar_cbse_04_014: प्राथमिक विषय (उपनिवेशवाद विरोध) विषय-आधारित निबंध का केन्द्रीय तर्क देता है।  
c11_hin_ar_cbse_04_015: Supplies the primary theme (colonial critique) that anchors all discussion points.  
c12_hin_ar_cbse_04_006: Transfers the Class 11 protocol for evidence-based theme articulation to a more complex, dialogic poem.  
c12_hin_ar_cbse_12_006: Practice in distinguishing theme from subject.  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
none

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_04_002 -> c11_hin_ar_cbse_04_006 -> c11_hin_ar_cbse_04_007

## THIS_FORMULA
N/A - conceptual

## FORMULA_VARIABLES
N/A

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
analytical

## CROSS_SUBJECT
c11_history_colonialism | The chapter is a literary response to British colonial policies (Partition of Bengal, economic drain, cultural suppression) studied in History.  
c11_politicalscience_imperialism | The critique of imperialist rhetoric ("civilizing mission", "rule of law") connects to Political Science concepts of sovereignty, legitimacy, and anti-colonial resistance.

## PREREQ_CONCEPT
Ability to distinguish between plot (what happens) and theme (what it means) using textual evidence.

## PREREQ_BEFORE
Student must have completed plot analysis (node 002) and character analysis of the narrator (node 004).

## PREREQ_STUCK
If stuck, review the list of accusations in the plot summary (node 002) and the narrator’s tone in character analysis (node 004).

## WORKED_EXAMPLE_1
PROBLEM: Using the text, identify the primary theme of "फोनबूथ" and support it with three pieces of evidence from the narrator’s monologue.

STEPS:
- Step 1: Recall the central conflict – the narrator (an Indian) addresses a departing British official (Lord Curzon) in a phone booth, listing grievances.  
- Step 2: Identify recurring accusations: economic exploitation (destruction of textiles, forced indigo), cultural imposition (English education, disregard for Indian languages), political betrayal (laws favoring British, suppression of dissent).  
- Step 3: Group these into a unified claim: The narrator argues British rule was a system of exploitation disguised as civilization.  
- Step 4: Select three specific textual evidences: (a) "तुमने इस देश के उद्योग-धंधे चौपट कर दिए" (economic), (b) "अंग्रेजी पढ़ा-लिखा कर बाबू बनाया" (cultural), (c) "कानून तुम्हारी रक्षा के लिए बने" (political).  
- Step 5: Synthesize: The primary theme is the exposure of colonial hypocrisy – the gap between the rhetoric of "progress" and the reality of "loot".

REASONING: The theme emerges from the pattern of accusations, not a single event. Grouping evidence into categories reveals the systematic nature of the critique.

ANSWER: The primary theme of "फोनबूथ" is a comprehensive indictment of British colonialism as a hypocritical enterprise that exploited India economically, suppressed its culture, and subverted justice, all while claiming a civilizing mission. Evidence: 1) Narrator cites destruction of indigenous industries (textiles, indigo). 2) Narrator critiques English education as a tool to create clerks, not free thinkers. 3) Narrator exposes laws as instruments of control, not justice.

## WORKED_EXAMPLE_2
PROBLEM: Explain how the metaphor of the "phone booth" (फोनबूथ) functions to reinforce the primary theme.

STEPS:
- Step 1: Understand the literal situation – a phone booth is a small, enclosed space for private conversation.  
- Step 2: Analyze the power dynamic – the narrator uses this space to speak *to* the colonizer, reversing the usual colonial dynamic where the colonized is silenced.  
- Step 3: Connect to theme – the phone booth represents a moment of historical reckoning: a direct, unmediated communication where the colonized voice confronts the colonizer with truth.  
- Step 4: Note the one-way nature – the narrator speaks, the official cannot interrupt (he’s leaving). This mirrors the theme of inevitable accountability.  
- Step 5: Relate to title significance – the title "फोनबूथ" highlights this constructed space for truth-telling, making the theme of "speaking back to power" central.

REASONING: The setting is not incidental; it’s a metaphor for the narrative act itself – a colonized writer addressing the colonizer’s history.

ANSWER: The phone booth metaphor reinforces the primary theme by symbolizing a rare, enclosed space where the colonized can directly address the colonizer without censorship. It transforms a mundane object into a site of historical judgment, emphasizing the theme of accountability and the power of the subaltern voice.

## WORKED_EXAMPLE_3
PROBLEM: Compare the primary theme of "फोनबूथ" with the theme of another anti-colonial text you have studied (e.g., "हिंद स्वराज" or a poem by Subhadra Kumari Chauhan). Identify two similarities and one difference in how the theme is conveyed.

STEPS:
- Step 1: State the primary theme of "फोनबूथ" (from Worked Example 1): exposure of colonial hypocrisy through satirical monologue.  
- Step 2: Recall the theme of "हिंद स्वराज" (Gandhi): critique of modern civilization and advocacy for self-rule (स्वराज) through dialogue.  
- Step 3: Similarity 1: Both use a conversational format (monologue/dialogue) to deconstruct colonial arguments.  
- Step 4: Similarity 2: Both contrast colonial rhetoric ("civilization", "progress") with Indian reality (exploitation, moral decay).  
- Step 5: Difference: "फोनबूथ" uses sarcasm, irony, and historical accusation addressed *to* the colonizer; "हिंद स्वराज" uses philosophical argument addressed *to* Indians to awaken self-respect.  
- Step 6: Conclude: Both share the anti-colonial theme but differ in audience and rhetorical strategy.

REASONING: Comparing themes across texts deepens understanding of how the same core idea (anti-colonialism) can be shaped by genre, audience, and authorial intent.

ANSWER: Similarities: (1) Both employ a conversational structure to dismantle colonial justifications. (2) Both juxtapose British claims of benevolence with evidence of exploitation. Difference: "फोनबूथ" is a satirical accusation directed at the colonizer (external audience), using irony; "हिंद स्वराज" is a philosophical dialogue directed at Indians (internal audience), using moral reasoning.

## COMPETENCY_QUESTION_1
QUESTION: The narrator in "फोनबूथ" says: "तुमने इस देश को लूटा और उसे सभ्यता का नाम दिया।" Explain how this single sentence encapsulates the primary theme of the chapter. Provide two other examples from the text where the narrator exposes a similar gap between British claims and actions.

COMPETENCY: Analytical interpretation of thematic condensation and textual evidence retrieval.

STEPS:
- Step 1: Deconstruct the sentence: "लूटा" (exploitation) vs "सभ्यता का नाम दिया" (rhetorical cover) – this binary is the core theme.  
- Step 2: Identify the pattern: the narrator repeatedly pairs a British claim with an Indian reality.  
- Step 3: Retrieve Example 1: British claim of "कानून व्यवस्था" (law and order) vs reality of "कानून तुम्हारी रक्षा के लिए बने" (laws protecting British interests).  
- Step 4: Retrieve Example 2: British claim of "शिक्षा का प्रसार" (spread of education) vs reality of "अंग्रेजी पढ़ा-लिखा कर बाबू बनाया" (education for clerical servitude).  
- Step 5: Conclude: Each pair reinforces the theme of hypocrisy.

ANSWER: The sentence condenses the primary theme – the fundamental contradiction between colonial practice (loot) and colonial discourse (civilizing mission). Two other examples: 1) The narrator contrasts the British boast of "rule of law" with laws designed to protect British trade and suppress Indian dissent. 2) The narrator contrasts the introduction of English education as "enlightenment" with its actual purpose: creating a class of clerks loyal to the Raj. Each example follows the pattern: Claim vs. Reality, exposing the theme.

DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: "The primary theme of 'फोनबूथ' is not just anti-British; it is a critique of the *logic of imperialism itself*." Defend or challenge this statement using the narrator’s references to historical figures (e.g., Clive, Warren Hastings, Curzon) and the structural pattern of the monologue.

COMPETENCY: Evaluative reasoning – assessing the scope and universality of a literary theme.

STEPS:
- Step 1: Analyze the statement – it claims the theme transcends specific British individuals to target the systemic logic of empire.  
- Step 2: Examine historical references: The narrator names Clive (Plassey, corruption), Warren Hastings (impeachment, exploitation), Curzon (partition of Bengal, arrogance). These are not just individuals but representatives of successive phases of imperial logic: conquest, administration, consolidation.  
- Step 3: Analyze structural pattern: The monologue moves chronologically (1757 → 1857 → 1905), showing a continuous system, not isolated errors.  
- Step 4: Note the narrator’s address to "एब यक्मज" (Lord Curzon) as the current embodiment of a centuries-old system.  
- Step 5: Defend the statement: The theme critiques imperialism as a structure (economic extraction + cultural domination + political control) that persists across personalities.  
- Step 6: Nuance: The text is historically specific (Indian context), but the *logic* it exposes (rhetoric vs. reality) is universal to imperialism.

ANSWER: The statement is defensible. The narrator uses specific British officials (Clive, Hastings, Curzon) not as individuals but as metonyms for the evolving stages of imperial logic: military conquest, administrative exploitation, and bureaucratic arrogance. The monologue’s chronological sweep (1757–1905) and the recurring pattern of "promise vs. performance" demonstrate a systemic critique. The theme targets the *structure* of imperialism – the inherent contradiction between the rhetoric of trusteeship and the practice of extraction – making it a critique of the logic of imperialism itself, grounded in the Indian experience.

DIFFICULTY: hard