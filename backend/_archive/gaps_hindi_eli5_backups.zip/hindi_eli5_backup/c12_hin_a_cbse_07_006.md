## DEFINITION
The primary theme of a literary work is its central, unifying idea that the author explores throughout the text; the message is the specific insight or truth about human experience that the author conveys through that theme. In "ckjgeklk," the primary theme is **divine love (prem bhakti) expressed through the metaphor of Radha-Krishna's separation and union**, and the message is that **the soul's intense longing for the divine, sustained through suffering and remembrance, ultimately leads to spiritual fulfillment.**

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student can independently identify the primary theme of "ckjgeklk," trace its development across at least three stanzas using specific textual evidence (imagery, dialogue, emotional progression), and articulate the poem's message in their own words while distinguishing it from secondary themes like seasonal description or folk customs.

## SCOPE_BOUNDARY
This node covers **only** the identification, textual tracing, and articulation of the *primary* theme and message of "ckjgeklk." It does NOT cover secondary themes (node 007), literary devices like imagery/metaphor (node 008) or irony/symbolism (node 009), vocabulary (node 010), grammar (node 011), or comprehension questions (node 012). It assumes the student has already understood the plot/narrative (node 002), setting (node 003), and characters (nodes 004, 005).

## WALKTHROUGH
Imagine you are listening to a grandmother sing a lullaby that sounds like a simple love song but actually carries a deep secret about life. That is "ckjgeklk" — a folk poem in Braj Bhasha that uses Radha-Krishna's love story to map the soul's journey to God. Begin by reading the poem aloud (even if you don't understand every Braj word) to catch the rhythm of longing: the repeated calls, the pain of night, the desperation of the fourth stanza. Then, ask: *What does Radha want? What stops her? What changes by the end?* Map her emotional arc: Stanza 1 = restless waiting; Stanza 2 = physical suffering in separation; Stanza 3 = total surrender; Stanza 4 = union. The key insight: **the poem never names "God" or "soul" — it trusts the metaphor to carry the weight.** Your job is to unpack that metaphor step by step.

## DIAGNOSTIC_QUESTION_1
What is the primary theme of "ckjgeklk" in one sentence?

## DIAGNOSTIC_ANSWER_1
The primary theme is the soul's intense longing for union with the divine, expressed through the metaphor of Radha's separation from and ultimate union with Krishna. A wrong answer like "Radha and Krishna's love story" reveals the student is stuck at the literal narrative level and has not yet grasped the allegorical layer (prem bhakti as a path to moksha) that Class 12 demands.

## DIAGNOSTIC_QUESTION_2
Explain in your own words how the poem uses the *setting* (night, seasons, nature) to reflect the *internal state* of the protagonist. Do not just list images.

## DIAGNOSTIC_ANSWER_2
The oppressive heat of the day (stanza 2) mirrors the burning pain of separation; the dark, rainy night (stanza 1 & 4) mirrors the blindness and danger of the spiritual path without the beloved; the lightning flashes are moments of divine grace/glimpse. A wrong answer that merely lists "rain, lightning, heat" without connecting each to Radha's emotional state shows the student treats setting as decoration rather than as an objective correlative — a critical Class 12 analytical skill.

## DIAGNOSTIC_QUESTION_3
Apply the concept of *virah* (separation) as a spiritual discipline: Which *two* specific actions by Radha in Stanza 3 demonstrate that her suffering has transformed into active spiritual practice (sadhana)?

## DIAGNOSTIC_ANSWER_3
1. She abandons all social decorum ("laj laj lok laaj tanu chhuti" — shame and worldly honor fall away). 2. She runs towards the sound of the flute ("murli bajat suni chali aayi") despite the storm, showing single-pointed focus (ekagrata). A wrong answer citing "she cries" or "she waits" misses the shift from passive suffering to *active surrender* — the hallmark of bhakti as sadhana in the Nirguna/Saguna synthesis tradition.

## DIAGNOSTIC_QUESTION_4
Analyze the structural role of the *flute (murli/bansuri)* across all four stanzas. How does its meaning evolve?

## DIAGNOSTIC_ANSWER_4
Stanza 1: Distant call — divine grace initiating the longing. Stanza 2: Absent — its silence deepens the pain (virah). Stanza 3: Heard clearly — becomes the guru-mantra guiding the seeker. Stanza 4: Played *by* Krishna at union — becomes the celebration of realization. A wrong answer that says "it represents Krishna's love" in all stanzas fails to track the *dynamic* relationship between the symbol and the protagonist's spiritual stage — a common board exam error.

## DIAGNOSTIC_QUESTION_5
Evaluate this claim: "The fourth stanza resolves the poem's tension completely, leaving no ambiguity." Defend or critique using textual evidence.

## DIAGNOSTIC_ANSWER_5
Critique: The union is *suggested* ("mil gaye Shyam pyare"), but the poem ends on the *sound* of the flute continuing ("bajai murli"), implying the dance of union is eternal, not a static endpoint. The lack of a final "they lived happily" closure mirrors the bhakti understanding that union is a continuous process (nitya lila). A student who agrees fully misses the open-ended, cyclical nature of the folk bhakti tradition — a nuance that distinguishes a 4-mark answer from a 5-mark one.

## DIAGNOSTIC_QUESTION_6
Create a 4-line stanza in Hindi (Khari Boli or Braj) that captures the *message* of "ckjgeklk" for a modern teenager struggling with anxiety. Use the metaphor of "waiting for a message notification" instead of the flute.

## DIAGNOSTIC_ANSWER_6
*Raat bhar screen takta raha, dil mein baithi vyakulata,*
*Ek beep aayi, roshni jhalki, mit gayi sari ghabrahat.*
*Ab nahi chahiye koi signal, uska hi ehsaas kaafi hai,*
*Jab 'woh' saath hai har pal, toh kaunsa dard, kaun si baat?*
A poor answer would write a generic motivational quote without retaining the *structure of virah → surrender → union* or the *metaphorical mapping* (flute → notification, Radha → self, Krishna → inner peace/anchor). This tests if the student has internalized the poem's *architecture*, not just its content.

## COMMON_MISCONCEPTION
Students conflate the *folk narrative* (Radha-Krishna's romantic meeting) with the *primary theme* (soul-God union via prem bhakti). They write answers describing Radha's jewelry, the storm, or Krishna's peacock feather as if these are the theme. This happens because: (1) The poem's surface is vividly sensory, distracting from the allegory. (2) Class 10-11 theme questions often accepted "love" as a theme; Class 12 demands the *specific philosophical framework* (Nirguna bhakti using Saguna imagery). (3) The Braj Bhasha creates a language barrier, so students cling to the translated plot summary instead of analyzing the *original imagery* (e.g., "murli" as divine call, not just a flute).

## ON_FAILURE
1. **Re-read Stanza 3 aloud in Braj** (use the NCERT text) focusing *only* on the verbs: *chhuti, chali, bhayi, mil gaye*. Notice the shift from noun-heavy description (stanzas 1-2) to verb-driven action. 2. **Map the 4 stages of Bhakti** (from Class 11 node c11_hin_ar_cbse_07_006): Shraddha → Sadhana → Anubhuti → Samadhi onto the 4 stanzas. 3. **Write one sentence** defining the theme using this formula: "The poem uses [folk metaphor] to show that [spiritual process] leads to [ultimate goal]." 4. **Re-attempt Diagnostic Question 4** — if you can track the flute's evolving role, the misconception is broken.

## BUILDS_ON
Character Analysis: Protagonist (c12_hin_a_cbse_07_004) — understanding Radha's internal state is prerequisite to extracting theme from her actions.

## LEADS_TO
Theme: Secondary Themes (c12_hin_a_cbse_07_007) — once the primary theme is fixed, secondary threads (folk culture, nature as participant, gendered devotion) can be explored without diluting the core.

## PREREQUISITE_NODE_IDS
c12_hin_a_cbse_07_002, c12_hin_a_cbse_07_003, c12_hin_a_cbse_07_004, c12_hin_a_cbse_07_005, c11_hin_ar_cbse_07_006, c12_hin_a_cbse_07_001

## PREREQUISITE_REASONS
c12_hin_a_cbse_07_002: Plot/narrative structure provides the sequence of events (separation → search → union) that the theme rides on.
c12_hin_a_cbse_07_003: Setting/atmosphere (night, rain, heat) functions as objective correlative for the theme — must be understood first.
c12_hin_a_cbse_07_004: Protagonist analysis (Radha's psychology) is the lens through which the theme is experienced.
c12_hin_a_cbse_07_005: Supporting characters (Krishna, sakhis, nature) embody thematic forces (divine, society, environment).
c11_hin_ar_cbse_07_006: Class 11 Theme node established the method of theme identification (allegory, symbol, progression) — this node deepens it for a folk bhakti text.
c12_hin_a_cbse_07_001: Primary theme (devotion as lived experience) is rooted in Varkari philosophy from context.  

## FORWARD_NODE_IDS
c12_hin_a_cbse_07_007, c12_hin_a_cbse_07_008, c12_hin_a_cbse_07_009, c12_hin_a_cbse_07_013, c12_hin_a_cbse_07_012, c12_hin_a_cbse_07_015

## FORWARD_REASONS
c12_hin_a_cbse_07_007: Secondary themes (folk life, nature, gender) branch out *from* the primary theme's trunk.
c12_hin_a_cbse_07_008: Imagery/metaphor analysis requires a firm theme to anchor the symbols (e.g., why *this* metaphor for *that* stage?).
c12_hin_a_cbse_07_009: Irony/symbolism (e.g., the storm as both obstacle and witness) only makes sense when the primary theme defines the stakes.
c12_hin_a_cbse_07_013: Critical thinking/interpretation questions in boards/competitive exams demand a clear thematic thesis to argue from.
c12_hin_a_cbse_07_012: Primary theme (node 006) provides the *interpretive framework* — inferences must align with the chapter's core message (harmony with nature).  
c12_hin_a_cbse_07_015: Primary theme (viraha as spiritual metaphor) sets interpretive boundary  

## CROSS_SUBJECT_PREREQS
c11_hin_ar_cbse_07_006, c11_hin_ar_cbse_08_006
## CROSS_SUBJECT_REASONS
c11_hin_ar_cbse_07_006: Direct predecessor — same skill (theme identification) applied to a different text (likely "Kabir" or "Meera" in Class 11 Antra), establishing the *method* of reading bhakti poetry allegorically.
c11_hin_ar_cbse_08_006: Another Class 11 bhakti poem theme node — reinforces the pattern that *virah* (separation) is the central structuring device in North Indian bhakti poetry, preparing the student to recognize it instantly in "ckjgeklk."

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_07_006 -> c12_hin_a_cbse_07_006 -> c12_hin_a_cbse_07_007

## THIS_FORMULA
N/A - conceptual

## FORMULA_VARIABLES
N/A

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
conceptual

## CROSS_SUBJECT
N/A | The poem exemplifies the Nirguna-Saguna synthesis in medieval bhakti: using Saguna imagery (Radha-Krishna) to express Nirguna realization (formless union). History Chapter 3 traces this theological evolution.
 N/A | The poem maps a psychological journey: anxiety (separation) → obsessive focus (sadhana) → flow state (union) → self-actualization. Psychology's "stages of motivation" and "peak experience" (Maslow) parallel Radha's arc.
## PREREQ_CONCEPT
Allegorical reading: the ability to hold two levels of meaning simultaneously — the literal folk narrative AND the spiritual mapping — without collapsing one into the other.

## PREREQ_BEFORE
The student must be able to summarize the poem's *literal story* (Radha waits, suffers, runs, meets Krishna) in 3 sentences without using the words "God," "soul," or "bhakti."

## PREREQ_STUCK
If stuck, revisit the **Character Analysis: Protagonist (c12_hin_a_cbse_07_004)** node and re-do the exercise "Trace Radha's emotional state in each stanza using only verbs from the text."

## WORKED_EXAMPLE_1
PROBLEM: A student writes: "The theme of 'ckjgeklk' is Radha's love for Krishna." Using the 4-step Theme Extraction Method, guide them to the primary theme.

STEPS:
- Step 1: **Identify the literal subject** — The poem depicts Radha's night of separation, her physical/emotional suffering, her desperate run to Krishna, and their meeting. (From node 002 Plot).
- Step 2: **Spot the recurring pattern** — Every stanza centers on *sound* (flute, thunder, her own heartbeat, flute again) and *movement* (waiting → burning → running → meeting). The pattern is: Call → Pain → Response → Union.
- Step 3: **Map to the bhakti framework** (Class 11 prerequisite) — In Nirguna bhakti, the "Call" is divine grace (guru-shabda), "Pain" is virah-tapasya, "Response" is surrender (sharanagati), "Union" is yoga. Radha = jivatma; Krishna = paramatma.
- Step 4: **Formulate the theme statement** — "The poem allegorizes the soul's journey to God through the stages of divine call, separation-purification, total surrender, and unitive realization, using the Radha-Krishna folk motif."

REASONING: This method forces the student to move from *what happens* (plot) → *how it's structured* (pattern) → *what tradition it belongs to* (framework) → *what it means* (theme). Skipping any step leads to the "love story" misconception.

ANSWER: Primary Theme: The soul's (jivatma) intense longing and disciplined surrender leading to union with the Divine (paramatma), allegorized through Radha's virah and milan with Krishna. Message: True devotion transcends social norms and physical suffering; the divine call (flute) transforms separation into the very path of union.

## WORKED_EXAMPLE_2
PROBLEM: Board exam question: "Show how the poet uses the imagery of *night* and *lightning* to develop the primary theme." (4 marks)

STEPS:
- Step 1: **Define the thematic function of night** — Night = spiritual ignorance / absence of divine vision / the "dark night of the soul" (virah ka andhera). Cite Stanza 1: "andheri raat" where Radha is alone.
- Step 2: **Define the thematic function of lightning** — Lightning = momentary divine grace / glimpse of truth / guru's word cutting through darkness. Cite Stanza 1: "bijuri chamak" — it shows the path but also terrifies.
- Step 3: **Show the progression** — Stanza 1: Lightning is external, frightening. Stanza 4: The *flute's sound* becomes the inner light — "murli bajai" — no external lightning needed. The seeker becomes the light.
- Step 4: **Conclude with thematic link** — The imagery moves from *external, unpredictable grace* (lightning) to *internal, constant connection* (flute/music), mirroring the theme's arc from dependence to realization.

REASONING: Board marking scheme awards 1 mark for identifying each image's symbolic meaning, 1 mark for tracking progression, 1 mark for linking to theme, 1 mark for precise textual reference. This structure ensures all 4 marks.

ANSWER: Night symbolizes the soul's ignorance and the pain of separation (virah); lightning symbolizes fleeting divine grace that guides but also unsettles. In Stanza 1, lightning flashes in the external sky, terrifying Radha — grace experienced as disruption. By Stanza 4, the flute's melody *is* the inner light; no external lightning is needed. The imagery thus traces the thematic shift from seeking God outside to realizing God within through surrender.

## WORKED_EXAMPLE_3
PROBLEM: Competitive exam (CUET/Hindi Olympiad) style: "Compare the treatment of *virah* (separation) in 'ckjgeklk' and Kabir's 'Moko kahan dhunde re bande' (Class 11). Which poem presents virah as *more transformative* and why?"

STEPS:
- Step 1: **Define virah in 'ckjgeklk'** — Virah is a *process*: it burns (stanza 2), strips ego (stanza 3: "laj laj lok laaj tanu chhuti"), and propels action (running through storm). It is *sadhana*.
- Step 2: **Define virah in Kabir** — Virah is a *realization*: "Moko kahan dhunde re bande" — the separation is an illusion; God is within. Virah ends instantly upon knowledge (gyan), not through prolonged suffering.
- Step 3: **Identify the difference** — 'ckjgeklk' (Prem marg / Bhakti): Virah *purifies* over time (stages). Kabir (Gyan marg): Virah *dissolves* in insight (instant).
- Step 4: **Evaluate "more transformative"** — 'ckjgeklk' shows transformation *through* virah (Radha changes: from passive to active, from decorated to stripped, from fearful to fearless). Kabir shows transformation *beyond* vihr (the seeker realizes there was no separation).
- Step 5: **Formulate answer** — 'ckjgeklk' presents virah as more transformative *as a lived process* because it dramatizes the psychological and physical stripping required for ego-death. Kabir's virah is transformative only as a *cognitive shift*.
- Step 6: **Nuance for competitive edge** — Note that both are valid in their margs; the question tests if you know the *difference in method* (bhakti = time/effort/surrender vs gyan = immediate insight).

REASONING: This requires synthesizing Class 11 Kabir (node c11_hin_ar_cbse_07_006) with Class 12 "ckjgeklk" — a classic cross-chapter, cross-year competency question. The 6 steps ensure the student doesn't just say "both talk about separation" but analyzes the *mechanism* of transformation.

ANSWER: 'ckjgeklk' treats virah as a multi-stage sadhana (burning → stripping → running → union) that transforms the devotee's entire being. Kabir treats virah as an epistemological error corrected by knowledge. Therefore, 'ckjgeklk' portrays virah as *more transformative in the sense of a gradual, holistic purification of the self*, while Kabir portrays it as *instantly removable by insight*. The folk poem's emphasis on the body (heat, rain, running, ornaments falling) makes the transformation visceral and developmental.

## COMPETENCY_QUESTION_1
QUESTION: "The poem 'ckjgeklk' is often called a 'premakhyan' (love narrative) in the Sufi-Bhakti tradition. Explain how the *primary theme* of this poem fits the definition of premakhyan: 'a symbolic love story where the human lover represents the soul, the divine lover represents God, and the obstacles represent the ego/world.' Use exactly three pieces of evidence from the poem."

COMPETENCY: Textual Evidence & Conceptual Mapping (CBSE Competency: Literary Analysis & Interdisciplinary Connection)

STEPS:
- Step 1: State the three mappings: Human lover = Radha = Soul (jivatma); Divine lover = Krishna = God (paramatma); Obstacles = Storm/Night/Social shame = Ego/Maya.
- Step 2: Evidence 1 (Human lover as soul): Stanza 3 — "laj laj lok laaj tanu chhuti" (body/shame of world falls away) — the soul sheds social identity.
- Step 3: Evidence 2 (Divine lover as God): Stanza 1 & 4 — The flute (murli) calls *unconditionally*; in Stanza 4 Krishna plays it *at union* — God initiates and consummates the relationship.
- Step 4: Evidence 3 (Obstacles as ego/world): Stanza 2 — "tapti duphari," "agani barsat" (scorching noon, fire-like rain) — the world becomes hostile *because* the soul seeks God; Stanza 3 — "lok laaj" (world's shame) is explicitly named as what falls away.

ANSWER: The poem perfectly fits the premakhyan structure: (1) Radha's shedding of "lok laaj" (social honor/body consciousness) in Stanza 3 maps the soul's shedding of ego. (2) Krishna's flute, which calls in separation (Stanza 1) and celebrates in union (Stanza 4), maps the Divine's dual role as caller and goal. (3) The storm, heat, and darkness are not mere weather but the world's resistance to the soul's God-ward movement — the "obstacles" of the definition. Thus, the primary theme (soul's journey via love) is the *content* of the premakhyan form.

DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: "A Class 12 student argues: 'The primary message of "ckjgeklk" is that true love requires courage to defy society and nature.' Critique this interpretation using the poem's *ending* and the *bhakti framework*. Is the student partially right, wholly wrong, or missing the core? Justify in 4 steps."

COMPETENCY: Critical Evaluation & Conceptual Precision (CBSE Competency: Critical Thinking; CUET/NEET-style: Argument Analysis)

STEPS:
- Step 1: Acknowledge the partial truth — Radha *does* defy society ("lok laaj chhuti") and nature (runs in storm). Courage is *present*.
- Step 2: Identify the category error — The student reads the *vehicle* (folk love story) as the *tenor* (spiritual message). Courage is a *byproduct* of surrender, not the *cause* of union.
- Step 3: Use the ending — Stanza 4: "mil gaye Shyam pyare" (met the beloved Shyam) — the union is gifted ("mil gaye" passive/reciprocal), not seized by courage. The flute plays *Krishna's* agency.
- Step 4: Apply bhakti framework — In prem bhakti, the message is *grace (kripa) responding to surrender (sharanagati)*, not human heroism. The courage is real but *secondary*; the core message is "God meets the soul that has emptied itself."

ANSWER: The student is **partially right but misses the core**. (1) Courage/defiance occurs (Stanza 3) — valid textual observation. (2) However, the poem's *message* centers on *surrender* (sharanagati), not heroism. (3) The ending uses "mil gaye" (were met/found) — a passive construction implying divine initiative — and Krishna plays the flute, signaling *His* acceptance. (4) In bhakti theology, the soul's effort (including courage) is necessary but *insufficient*; the message is that *union is grace*. The student confuses the *means* (courage born of love) with the *message* (love as the path to grace).

DIFFICULTY: hard