## DEFINITION
Character analysis of supporting characters involves examining how secondary figures in a narrative reveal the protagonist's traits, advance themes, and embody social realities through their dialogue, actions, and relationship to the central figure.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
Student can identify 3+ supporting characters from the text, cite specific textual evidence for each, explain how each character's perspective illuminates the central theme of unity in diversity, and write a structured analytical paragraph using the PEEL method.

## SCOPE_BOUNDARY
This node covers analysis of supporting characters in Nehru's "Hkkjr ekrk" (Chapter 8 of Aroh) - specifically the villagers, the farmer (g^s&d^s tkV), and collective voices Nehru encounters. It does NOT cover the protagonist (Nehru himself, covered in node 004) or characters from other chapters.

## WALKTHROUGH
Imagine you're sitting in a village chaupal listening to Nehru ask farmers "What does Bharat Mata mean to you?" - their answers aren't just opinions, they're the living proof of his thesis. Start by listing every person or group Nehru directly quotes or describes in the chapter. For each, note: what they say, what they do, and what their words reveal about the idea of India. Then ask: why did Nehru choose THESE specific voices? The key insight: supporting characters in this essay aren't fictional inventions - they're real Indians whose collective voice becomes the definition of the nation.

## DIAGNOSTIC_QUESTION_1
Identify the supporting character in "Hkkjr ekrk" who responds to Nehru's question about Bharat Mata by saying the slogan comes from the land (dharti).

## DIAGNOSTIC_ANSWER_1
The supporting character is the farmer described as "g^s&d^s tkV" (an old weather-beaten peasant) who says "Hkkjr ekrk ls mudk eryc èkjrh ls gS" (Bharat Mata's meaning comes from the land). A wrong answer (e.g., naming Nehru himself or a generic "villager") reveals the student cannot distinguish the protagonist from supporting characters or cannot recall specific textual details about who speaks which line.

## DIAGNOSTIC_QUESTION_2
Explain in your own words why Nehru includes the voices of ordinary villagers and a farmer when exploring the meaning of "Bharat Mata" instead of only presenting his own intellectual analysis.

## DIAGNOSTIC_ANSWER_2
Nehru includes these voices to demonstrate that the idea of India lives in the lived experience of its people, not just in abstract theory - the farmer's answer "from the land" grounds the concept in material reality, while the villagers' initial confusion shows the gap between nationalist rhetoric and popular understanding. A wrong answer focusing only on "making the essay interesting" or "showing diversity" misses the structural purpose: these characters embody the thesis that India is its people.

## DIAGNOSTIC_QUESTION_3
In the passage where Nehru describes people from "nfD[ku] ifPNe" (Kashmir to Kanyakumari) and "iwjc ls ysdj ifPNe rd" (Gujarat to Bengal), identify TWO specific groups he mentions and explain what each group represents in his argument about unity.

## DIAGNOSTIC_ANSWER_3
Nehru mentions: (1) people from "fdlkuksa osQ fy, ;d&lk¡ Fks" (peasants and workers) representing the laboring masses whose unity transcends region, and (2) "LojkT; dk Hkh f"kØ djrk] tks FkksM+s yksxksa osQ fy, ugha] cfYd lHkh osQ I+kQk;ns osQ fy, gks ldrk Fkk" (the intelligentsia/service class) representing inclusive governance. A wrong answer listing only geographic regions (North/South) misses the socio-economic dimension Nehru emphasizes.

## DIAGNOSTIC_QUESTION_4
Compare how the farmer's definition of Bharat Mata ("from the land") differs from the urban intellectual's likely definition, and analyze what this contrast reveals about Nehru's view of nationalism.

## DIAGNOSTIC_ANSWER_4
The farmer defines Bharat Mata materially (land, soil, sustenance) while an intellectual would likely define it abstractly (culture, history, civilization). This contrast reveals Nehru's view that true nationalism must bridge both - the emotional-intellectual idea must be rooted in the material reality of the masses. A wrong answer treating both definitions as "equally valid perspectives" misses Nehru's synthesis: he values the farmer's definition as more authentic because it comes from lived struggle.

## DIAGNOSTIC_QUESTION_5
Evaluate whether the supporting characters in "Hkkjr ekrk" have distinct individual personalities or function primarily as collective voices. Defend your judgment with textual evidence.

## DIAGNOSTIC_ANSWER_5
They function primarily as collective voices - the farmer is unnamed ("g^s&d^s tkV"), villagers speak in chorus ("os ,d&nwljs dh rjI+kQ ;k esjh rjI+kQ ns[kus yx tkrs"), and Nehru generalizes ("bu yksxksa dh t;"). Only the farmer gets a specific line, but even he represents a type (peasant). This serves Nehru's purpose: the "character" of India is collective. A wrong answer claiming they are "well-developed characters" imposes fictional expectations on a non-fiction essay.

## DIAGNOSTIC_QUESTION_6
Write a 4-line dialogue between Nehru and a NEW supporting character (e.g., a young woman weaver from Banaras) that would fit seamlessly into the chapter, revealing a dimension of Bharat Mata not yet expressed.

## DIAGNOSTIC_ANSWER_6
A strong answer creates a voice that adds a new dimension (e.g., women's labor, artistic heritage, intergenerational memory) while matching Nehru's respectful tone and the chapter's theme of unity-in-diversity. Example: "Didi, Bharat Mata is the thread my grandmother spun, the sari I weave, the hunger in my fingers - and the hope that my daughter's loom will sing freer songs." A poor answer creates a character who merely repeats existing perspectives or speaks in anachronistic modern vocabulary.

## COMMON_MISCONCEPTION
Students treat supporting characters in this non-fiction essay as if they were fictional characters in a story - expecting names, backstories, and individual arcs. They fail to recognize that Nehru's "characters" are real people encountered during his travels who function as representative voices of social groups (peasants, workers, villagers). This error occurs because students apply fiction-analysis templates to a political-philosophical travelogue where individuals stand for collectives.

## ON_FAILURE
Step 1: Show the student the exact text where the farmer is introduced ("vkf[kj ,d g^s&d^s tkV us...") - note the descriptive label, not a name. Step 2: Have them highlight every instance where Nehru uses plural pronouns ("bu yksx", "mUgsa", "os") when referring to people he meets. Step 3: Ask: "If these were fictional characters, why would the author deny them names and individuality?" Step 4: Guide them to see that the TEXT'S PURPOSE (defining a nation) requires collective voices, not individual portraits.

## BUILDS_ON
This builds on the protagonist analysis (node 004) where students learned to analyze Nehru as the narrator-inquirer; now they analyze the respondents who shape his inquiry.

## LEADS_TO
This enables theme analysis (nodes 006-007) where the collective voices of supporting characters become the textual evidence for "unity in diversity" and "nation as people" themes.

## PREREQUISITE_NODE_IDS
c11_hin_ar_cbse_08_001, c11_hin_ar_cbse_08_002, c11_hin_ar_cbse_08_004
## PREREQUISITE_REASONS
c11_hin_ar_cbse_08_001: Context node provides historical background (Nehru's 1930s-40s travels) essential to understanding who these supporting characters are and why Nehru meets them.
c11_hin_ar_cbse_08_002: Plot/narrative structure node establishes the journey framework - the supporting characters appear at specific stops on Nehru's travel route.
c11_hin_ar_cbse_08_004: Protagonist analysis node covers Nehru's role as questioner; supporting characters are defined by their relationship to his inquiry.

## FORWARD_NODE_IDS
c11_hin_ar_cbse_08_006, c11_hin_ar_cbse_08_007, c11_hin_ar_cbse_08_013, c11_hin_ar_cbse_08_009, c11_hin_ar_cbse_08_014, c12_hin_a_cbse_08_005, c12_hin_ar_cbse_06_005, c12_hin_ar_cbse_08_005

## FORWARD_REASONS
c11_hin_ar_cbse_08_006: Primary theme (unity in diversity) is evidenced through supporting characters' collective voice.
c11_hin_ar_cbse_08_007: Secondary themes (nationalism, land-people relationship) emerge from what supporting characters say and represent.
c11_hin_ar_cbse_08_013: Critical thinking requires analyzing how Nehru constructs his argument through selected voices - a skill built here.
c11_hin_ar_cbse_08_009: Supporting characters (the farmer, the crowds) deliver the unexpected answers that create situational irony.  
c11_hin_ar_cbse_08_014: Supporting characters (peasant, crowds) provide concrete evidence for arguments.  
c12_hin_a_cbse_08_005: Direct Class 11 precedent for supporting character analysis in the same textbook series.  
c12_hin_ar_cbse_06_005: Class 11 foundation on supporting character analysis in Aroh.  
c12_hin_ar_cbse_08_005: Class 11 introduced typology (foil, catalyst, confidant, antagonist) — this node applies it at higher depth.  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
none

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_08_004 -> c11_hin_ar_cbse_08_005 -> c11_hin_ar_cbse_08_006

## THIS_FORMULA
N/A - conceptual

## FORMULA_VARIABLES
N/A

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
analytical

## CROSS_SUBJECT
c11_history_nationalism | Nehru's method of defining the nation through peasant voices parallels how nationalist historians recover subaltern perspectives in the Indian freedom struggle.
c11_civics_constitution | The farmer's "land-based" definition of Bharat Mata connects to Directive Principles (Article 39) on equitable distribution of material resources - the Constitution's material grounding of abstract justice.

## PREREQ_CONCEPT
Understanding Nehru as narrator-inquirer who structures his philosophical argument through encountered voices (from protagonist analysis node 004).

## PREREQ_BEFORE
Student must be able to distinguish Nehru's voice (the "I" who travels, asks, reflects) from the voices he records (the "they" who answer, embody, represent).

## PREREQ_STUCK
Review the protagonist analysis (node 004) focusing on Nehru's method: he doesn't lecture - he listens, then synthesizes.

## WORKED_EXAMPLE_1
PROBLEM: Analyze the farmer (g^s&d^s tkV) as a supporting character: what he says, what he represents, and how his single line advances Nehru's argument about Bharat Mata.

STEPS:
- Step 1: Locate the farmer's appearance in the text - he appears when Nehru describes being asked "Hkkjr ekrk dkSu gS" by people, and an old peasant responds.
- Step 2: Extract his exact words: "Hkkjr ekrk ls mudk eryc èkjrh ls gS" (Bharat Mata's meaning comes from the land/soil).
- Step 3: Analyze what he represents - the peasantry, the tillers of soil, those whose survival depends directly on land; his weather-beaten description ("g^s&d^s" = worn by sun/rain) marks him as authentic labor.
- Step 4: Connect to Nehru's argument - Nehru has been giving intellectual definitions (unity, culture, history); the farmer grounds it in material reality. Nehru then expands: "fganqLrku osQ unh vkSj igkM+... ftudh fxurh gS, os gSa fganqLrku osQ yksx" (unity's root is people like you and me).
- Step 5: Evaluate function - this character shifts the essay from abstract to concrete, making "Bharat Mata" a living relationship between people and land.

REASONING: The farmer is the pivot point where Nehru's intellectual journey meets lived reality. His one line carries the weight of millions of unnamed peasants.

ANSWER: The farmer (g^s&d^s tkV) functions as the embodied voice of the peasantry. His definition - "Bharat Mata's meaning comes from the land" - provides the materialist grounding that Nehru's intellectual argument requires. Nehru accepts this definition and builds on it: the nation IS its people, and the people are rooted in the land. The character has no name, no individuality beyond his labor - he represents a collective, which is precisely Nehru's point about what India is.

## WORKED_EXAMPLE_2
PROBLEM: Analyze how the collective voice of villagers (when Nehru asks them about Bharat Mata) functions as a supporting character group - their confusion, their chorus responses, and what this reveals about the gap between nationalist rhetoric and popular consciousness.

STEPS:
- Step 1: Identify the scene - Nehru travels village to village ("tylk ls nwljs tyls"), asks people about Bharat Mata.
- Step 2: Note their initial reaction - "os iqjk ugha fd vius NksVs vkdkj osQ ckoTkwn bl ys[k dk dF; vR;ar fojkV vkSj izLrqrhdj.k iSuk gS" (they don't understand that their simple words contain the essay's entire philosophy and explanation).
- Step 3: Analyze their verbal responses - they look at each other blankly ("oqQrwgy vkSj rkTtqc"), then exchange glances ("os ,d&nwljs dh rjI+kQ ;k esjh rjI+kQ ns[kus yx tkrs").
- Step 4: Interpret the silence/confusion - it reveals that "Bharat Mata" as a nationalist slogan hasn't reached the grassroots; the concept is elite intellectual property at this stage (1930s-40s).
- Step 5: Connect to Nehru's pedagogical purpose - he doesn't mock their ignorance; he learns FROM it. Their confusion becomes his motivation to find a definition that WORKS for them ("fganqLrku og lc oqQN gS] ftls mUgksaus le> j[kk gS").

REASONING: The villagers' collective confusion is not a failure of character - it's the central evidence Nehru uses to argue that nationalism must be redefined from below.

ANSWER: The villagers function as a collective supporting character whose primary trait is NOT knowledge but authentic ignorance. Their blank faces and mutual glances ("oqQrwgy vkSj rkTtqc") expose the disconnect between urban nationalist discourse and rural reality. Nehru uses this gap not to dismiss them but to derive his thesis: true unity (fganqLrku) must be intelligible to the masses. Their "character arc" is from confusion to becoming the very definition of the nation - "Hkkjr ekrk njvly ;gh djksM+ksa yksx gSa" (India's mother is precisely these millions of people).

## WORKED_EXAMPLE_3
PROBLEM: Synthesize how THREE supporting character groups (the farmer, the villagers, the "people like you and me" Nehru references) collectively construct the chapter's definition of Indian nationalism. Use PEEL structure for each group, then a synthesizing conclusion.

STEPS:
- Step 1: Group 1 - The Farmer (g^s&d^s tkV): Point - provides materialist definition. Evidence - "èkjrh ls eryc gS". Explanation - land as sustenance, not symbol. Link - grounds abstract nationalism in survival.
- Step 2: Group 2 - The Villagers (collective): Point - embody the reception gap. Evidence - "oqQrwgy vkSj rkTtqc", mutual glances. Explanation - slogan hasn't penetrated. Link - necessitates redefinition from grassroots.
- Step 3: Group 3 - "People like you and me" (Nehru's inclusive "we"): Point - bridge intellectual and lived experience. Evidence - "fganqLrku osQ yksx muosQ vkSj esjs tSls yksx". Explanation - nationalism as shared project across class. Link - synthesizes farmer's materiality with intellectual's vision.
- Step 4: Synthesize - All three groups form a dialectic: thesis (intellectual nationalism), antithesis (peasant materiality/villager ignorance), synthesis (people-centered nationalism).
- Step 5: Evaluate Nehru's method - he doesn't impose; he extracts the definition FROM the supporting characters. The essay's argument IS the characters' voices assembled.
- Step 6: Board exam application - this synthesis answers "How does Nehru define Bharat Mata?" with evidence from supporting characters, not just Nehru's narration.

REASONING: This multi-character synthesis demonstrates the analytical depth Class 11 requires - moving beyond individual character sketches to how characters function structurally in a non-fiction argument.

ANSWER: The three supporting character groups form a dialectical structure: the farmer gives the raw material definition (land), the villagers expose the rhetorical gap (ignorance of the slogan), and the inclusive "we" (Nehru + reader + farmer) creates the synthesized definition - Bharat Mata as the living people rooted in land. Nehru's genius: the supporting characters don't just illustrate his argument; they GENERATE it. For board exams, answer "How does Nehru arrive at his definition?" by tracing this three-stage evidence from the text.

## COMPETENCY_QUESTION_1
QUESTION: In "Hkkjr ekrk," Nehru writes: "Hkkjr ekrk njvly ;gh djksM+ksa yksx gSa] vkSj ¶Hkkjr ekrk dh t;!¸ ls eryc gqvk bu yksxksa dh t; dkA" (India's mother is precisely these millions of people, and the meaning of 'Bharat Mata's voice' has come from these people's voice). Using the farmer and the villagers as evidence, explain HOW the supporting characters' voices become the definition rather than merely illustrating it. Write a structured answer using PEEL method.

COMPETENCY: Analytical writing with textual evidence (PEEL structure)

STEPS:
- Step 1: State the thesis (Point) - supporting characters' voices CONSTITUTE the definition because Nehru's method is inductive: he derives the concept FROM them.
- Step 2: Evidence 1 - Farmer's line "èkjrh ls eryc gS" is not an example OF the definition; it IS the definition's core materialist claim.
- Step 3: Evidence 2 - Villagers' confusion forces Nehru to reject elite definitions and seek one that "mUgksaus le> j[kk gS" (they can understand).
- Step 4: Explanation - In both cases, the direction of meaning-flow is character → concept, not concept → character.
- Step 5: Link - This makes the essay a democratic epistemology: the nation is defined by its least articulate members.

ANSWER: The supporting characters' voices become the definition because Nehru structures his inquiry inductively. The farmer's statement "Bharat Mata's meaning comes from the land" (èkjrh ls eryc gS) is not an illustration of a pre-existing definition - it PROVIDES the definition's material core. Similarly, the villagers' blank confusion ("oqQrwgy vkSj rkTtqc") is not a failure to understand the concept; it REVEALS that the concept (as urban slogan) is hollow. Nehru explicitly shifts ground: "fganqLrku og lc oqQN gS] ftls mUgksaus le> j[kk gS" (unity is that simple thing which THEY have understood). The direction of meaning is bottom-up: characters → definition. This makes the essay enact its own thesis - the nation speaks through its most ordinary voices.

DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: A Class 11 student writes: "The supporting characters in 'Hkkjr ekrk' are poorly developed - the farmer has no name, the villagers just stare blankly, and we learn nothing about their personal lives. Nehru should have given them proper characterizations." Critique this student's response using your understanding of the text's genre, purpose, and Nehru's philosophical method. What category error is the student making?

COMPETENCY: Critical evaluation of genre expectations and authorial intent

STEPS:
- Step 1: Identify the category error - applying fictional character criteria (name, backstory, individual arc) to a non-fiction philosophical travelogue.
- Step 2: Explain the genre - this is a political-philosophical essay where "characters" are encountered real people functioning as representative voices of social collectives.
- Step 3: Analyze Nehru's philosophical method - he deliberately avoids individualizing because his thesis is COLLECTIVE: "Hkkjr ekrk njvly ;gh djksM+ksa yksx gSa" (India's mother is precisely these millions).
- Step 4: Show how "poor characterization" IS the point - the farmer's anonymity ("g^s&d^s tkV") makes him Everyman Peasant; the villagers' chorus voice makes them The Masses.
- Step 5: Conclude - the student's critique misunderstands the text's epistemology: it doesn't portray individuals to know them; it assembles voices to define a nation.

ANSWER: The student commits a category error by judging a non-fiction philosophical essay by fictional standards. In "Hkkjr ekrk," supporting characters are not "underdeveloped" - they are DELIBERATELY collective. The farmer's descriptor "g^s&d^s tkV" (weather-beaten peasant) is a class marker, not a name failure. The villagers' blank stares ("oqQrwgy vkSj rkTtqc") are not poor characterization - they are the EVIDENCE that nationalist rhetoric hasn't reached the grassroots. Nehru's method is inductive: he travels, listens, and lets the people's voices GENERATE the definition ("bu yksxksa dh t; ls eryc gqvk"). To give them names, backstories, or individual arcs would falsify the very collective reality he's documenting. The text's genre is democratic epistemology - the nation is defined by its most anonymous members. The student's critique reveals they haven't grasped the text's central argument: India IS its unnamed millions.

DIFFICULTY: hard