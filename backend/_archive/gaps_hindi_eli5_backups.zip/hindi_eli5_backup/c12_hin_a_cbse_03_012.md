## DEFINITION
Literal comprehension refers to understanding information explicitly stated in the text (facts, details, sequence), while inferential comprehension requires drawing logical conclusions by combining textual evidence with prior knowledge to grasp implied meanings, authorial intent, and thematic significance.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student can independently distinguish between literal and inferential questions, locate precise textual evidence for literal answers, and construct logically supported inferences with explicit textual warrants for inferential answers, demonstrating both in written responses structured as Point-Evidence-Explanation-Link.

## SCOPE_BOUNDARY
This node covers strategies for answering literal and inferential comprehension questions based on the two poems in Chapter 3 (नहीं वो सयक and मैंने देखा, एक कव्वन). It does NOT cover critical analysis, creative writing, or speaking/listening skills, which are addressed in subsequent nodes.

## WALKTHROUGH
Imagine you're sitting in the CBSE board exam and see a question: "कवि ने 'नहीं' शब्द को बार-बार क्यों दोहराया है?" Your first instinct might be to write a general answer about emphasis. But the examiner wants textual evidence. Start by reading the poem aloud — notice the rhythm. Then mark every occurrence of "नहीं" and what follows it. Ask: what is being denied in each stanza? The first denies smallness, the second denies ordinariness. That pattern reveals the poem's central argument. The key insight: literal comprehension finds *what* the text says; inferential comprehension explains *why* it says it that way, using the text as proof.

## DIAGNOSTIC_QUESTION_1
निम्नलिखित में से कौन-सा प्रश्न शाब्दिक (literal) बोध की श्रेणी में आता है?
(क) कवि ने 'नहीं' शब्द की पुनरावृत्ति से क्या प्रभाव उत्पन्न किया है?
(ख) कविता 'नहीं वो सयक' में 'नहीं' शब्द कितनी बार आया है?
(ग) 'लुसग हक' और 'खोज हक' का प्रतीकात्मक अर्थ क्या है?
(घ) कवि ने कव्वन के काले रंग को 'उदासी' से क्यों जोड़ा है?

## DIAGNOSTIC_ANSWER_1
Correct: (ख) — This asks for a directly countable fact from the text. Wrong answers reveal confusion between retrieval (literal) and interpretation (inferential). Students picking (क), (ग), or (घ) are treating analytical questions as factual recall, a pattern that leads to vague, evidence-free answers in board exams.

## DIAGNOSTIC_QUESTION_2
'मैंने देखा, एक कव्वन' कविता की पंक्ति "जै बख़ज़र सर ल्वजत ध वख़्स ल्स" में 'ल्वजत' शब्द का शाब्दिक अर्थ क्या है, और यह शब्द कव्वन के किस गुण को प्रत्यक्ष रूप से दर्शाता है?

## DIAGNOSTIC_ANSWER_2
Correct: शाब्दिक अर्थ = 'उड़ना/फड़फड़ाना'; प्रत्यक्ष गुण = कव्वन के पंखों की गति/उड़ान। Wrong answer: 'स्वतंत्रता' या 'उत्साह' लिखना। यह गलती दर्शाती है कि छात्र शब्द के शब्दकोशीय अर्थ (dictionary meaning) और उसके निहितार्थ (connotation) में भेद नहीं कर पा रहे — बोर्ड परीक्षा में इससे अंक कटते हैं क्योंकि शाब्दिक बोध में केवल पाठ में स्पष्ट अर्थ मान्य होता है।

## DIAGNOSTIC_QUESTION_3
'नहीं वो सयक' कविता के तीसरे पद में "ये वक़्क़ गस — लो;ा दक़ ध एक़ुक ध ;क़क्स्लप्]" "ये क्षजल — थौ&देक्क़ुक ध वेर्&इवर इ;] "ये वाओक्क — इक़्सभ् ेक़्ज़ दक़्स जफ़ो दक़्स रद्क फुउक़्ज़;" — इन तीनों पंक्तियों में आए संज्ञा शब्दों की सूची बनाइए और बताइए कि कवि ने इन्हें एक साथ क्यों रखा है? (यह अनुप्रयोग-स्तरीय प्रश्न है: आपको पाठ से शब्द निकालकर उनका वर्गीकरण करना है और फिर कवि की युक्ति समझानी है।)

## DIAGNOSTIC_ANSWER_3
Steps: (1) संज्ञा शब्द पहचानें: एक़ुक, क्षजल, वेर्, वाओक्क, इक़्सभ्, इक़्ज़, दक़्स, जफ़ो, दक़्स, फुउक़्ज़। (2) वर्गीकरण करें: एक़ुक/क्षजल/वेर् = प्राकृतिक/ग्रामीण परिवेश; वाओक्क/इक़्सभ्/इक़्ज़/दक़्स/जफ़ो/फुउक़्ज़ = मानवीय संवेदनाएँ/मूल्य। (3) कवि की युक्ति: ग्रामीण जीवन की सहजता और मानवीय मूल्यों की गहनता को साथ रखकर 'सयक' की परिभाषा विस्तृत कर रहे हैं। Wrong answer: केवल शब्दों की सूची देना बिना युक्ति बताए — यह दर्शाता है कि छात्र 'लागू करना' (apply) नहीं जानते, केवल 'याद करना' जानते हैं।

## DIAGNOSTIC_QUESTION_4
दोनों कविताओं में 'प्रकृति' का चित्रण कैसे भिन्न है? 'नहीं वो सयक' में प्रकृति प्रतीकात्मक है जबकि 'मैंने देखा, एक कव्वन' में प्रकृति यथार्थपरक है — इस कथन का विश्लेषण करते हुए पाठगत प्रमाण दीजिए।

## DIAGNOSTIC_ANSWER_4
Correct analysis: 'नहीं वो सयक' में "लुसग हक", "खोज हक", "एक़ुक", "क्षजल" प्रतीक हैं — लुसग = सहजता, खोज = सुंदरता, एक़ुक = ग्रामीण जीवन। 'मैंने देखा, एक कव्वन' में "ल्क्ज़", "कव्वन", "जै बख़ज़र", "ल्वजत" यथार्थ वर्णन हैं — कव्वन का काला रंग, पंख फड़फड़ाना, डाल पर बैठना। Wrong answer: दोनों को 'प्रकृति वर्णन' कहकर बराबर मानना। यह गलती दर्शाती है कि छात्र काव्य-भाषा के स्तरों (प्रतीकात्मक vs यथार्थपरक) को अलग नहीं कर पाते — प्रतियोगी परीक्षाओं में ऐसे प्रश्नों में पूरे अंक नहीं मिलते।

## DIAGNOSTIC_QUESTION_5
क्या आप इस मत से सहमत हैं कि 'नहीं वो सयक' कविता का शीर्षक विरोधाभासी (paradoxical) है? अपने उत्तर के लिए कविता के कम-से-कम तीन पदों के प्रमाण देते हुए तर्क दीजिए।

## DIAGNOSTIC_ANSWER_5
Correct: हाँ, शीर्षक विरोधाभासी है क्योंकि 'नहीं' नकार है पर कविता 'है' की स्थापना करती है। प्रमाण: (1) पहला पद: "नहीं वो सयक लुसग हक... पर ये सयक एनेर्क" — नकार के बाद सकार। (2) दूसरा पद: "ये वक़्क़ गस — लो;ा दक़ ध एक़ुक ध ;क़क्स्लप्" — साधारण चीज़ों को 'सयक' घोषित करना। (3) चौथा पद: "ये इज़्र] लो;ाह्क़्व] ज़्आ] व;क़्र्... 'क़्फ़्र दक़्स ऩ ऩ" — जीवन के कटु यथार्थ को भी 'सयक' का हिस्सा मानना। Wrong answer: केवल 'हाँ' या 'नहीं' लिखना बिना प्रमाण के — बोर्ड परीक्षा में ऐसे उत्तर शून्य अंक पाते हैं क्योंकि मूल्यांकन योजना (marking scheme) में 'पाठगत प्रमाण' अनिवार्य है।

## DIAGNOSTIC_QUESTION_6
'मैंने देखा, एक कव्वन' कविता के आधार पर एक नया पद (stanza) लिखिए जो कव्वन के किसी अन्य दैनिक क्रिया को वर्णित करे, और उसमें कम-से-कम दो अलंकारों (इमेजरी/मेटाफर/आयरनी) का प्रयोग कीजिए। फिर समझाइए कि आपके पद में प्रयुक्त अलंकार मूल कविता के भाव को कैसे आगे बढ़ाते हैं।

## DIAGNOSTIC_ANSWER_6
Expected criteria: (1) नया पद मूल कविता की छंद-शैली (मुक्त छंद, अनुप्रास) में हो। (2) कव्वन की क्रिया: दाना चुगना / पानी पीना / संध्या काल में लौटना। (3) दो अलंकार: जैसे — "काले मोती चुगता धरती से" (मेटाफर: दाना = मोती); "सूरज डूबा, कव्वन बोला — 'कल फिर आऊँगा'" (इमेजरी: दृश्य + श्रव्य)। (4) व्याख्या: मेटाफर साधारण दाने को मूल्यवान बनाता है जैसे मूल कविता साधारण कव्वन को 'जीवन-प्रतीक' बनाती है। Poor answer: अलंकारों के नाम लिखना बिना प्रभाव समझाए — यह दर्शाता है कि छात्र अलंकार को 'सजावट' समझते हैं, 'अर्थ-निर्माण का उपकरण' नहीं।

## COMMON_MISCONCEPTION
Students believe inferential questions have "no right answer" — they think any personal opinion counts. In reality, CBSE marking scheme requires inferences to be *textually warranted*: every claim must trace back to specific words, images, or structural choices in the poem. For example, writing "कवि दुखी है" without quoting "उदासी", "काला रंग", "एक़ुक ध ;क़क्स्लप्" gets zero marks. This misconception stems from confusing 'inference' (evidence-based conclusion) with 'impression' (subjective feeling).

## ON_FAILURE
Step 1: Give the student a 4-line unseen poem. Step 2: Ask them to write one literal question and one inferential question *with answers*. Step 3: For the inferential answer, demand: "Which exact word/line made you think this?" Step 4: If they cannot point to text, return to c11_hin_ar_cbse_01_012 (Class 11 Antra Comprehension) and practice the "Evidence → Inference" mapping exercise with 5 short passages. Step 5: Re-test with a new poem after 2 days.

## BUILDS_ON
Class 11 comprehension skills where students learned to distinguish explicit vs implicit information in prose and poetry.

## LEADS_TO
Critical Thinking: Analysis and Interpretation (c12_hin_a_cbse_03_013) where inferences become arguments for thematic interpretation.

## PREREQUISITE_NODE_IDS
c11_hin_ar_cbse_01_012, c11_hin_ar_cbse_02_012, c11_hin_ar_cbse_03_012, c12_hin_a_cbse_03_001, c12_hin_a_cbse_03_002, c12_hin_a_cbse_03_003, c12_hin_a_cbse_03_004, c12_hin_a_cbse_03_005, c12_hin_a_cbse_03_006, c12_hin_a_cbse_03_007, c12_hin_a_cbse_03_008, c12_hin_a_cbse_03_009, c12_hin_a_cbse_03_010, c12_hin_a_cbse_03_011
## PREREQUISITE_REASONS
c11_hin_ar_cbse_01_012: Class 11 literal/inferential foundation across multiple chapters
c11_hin_ar_cbse_02_012: Reinforced practice with different text types
c11_hin_ar_cbse_03_012: Poetry-specific comprehension strategies
c12_hin_a_cbse_03_001: Context/background needed to infer authorial intent
c12_hin_a_cbse_03_002: Narrative structure helps locate literal details in sequence
c12_hin_a_cbse_03_003: Setting/atmosphere provides inferential clues
c12_hin_a_cbse_03_004: Protagonist analysis requires inferring motives
c12_hin_a_cbse_03_005: Supporting characters expand inferential base
c12_hin_a_cbse_03_006: Primary theme guides thematic inferences
c12_hin_a_cbse_03_007: Secondary themes add inferential layers
c12_hin_a_cbse_03_008: Imagery/metaphor are primary inference triggers
c12_hin_a_cbse_03_009: Irony/symbolism require inferential reading
c12_hin_a_cbse_03_010: Vocabulary in context resolves literal ambiguities
c12_hin_a_cbse_03_011: Grammar usage clarifies literal meaning of complex lines

## FORWARD_NODE_IDS
c12_hin_a_cbse_03_013, c12_hin_a_cbse_03_014, c12_hin_a_cbse_03_015
## FORWARD_REASONS
c12_hin_a_cbse_03_013: Critical thinking builds on validated inferences to form interpretive arguments
c12_hin_a_cbse_03_014: Writing skills require embedding literal evidence and inferential reasoning in structured answers
c12_hin_a_cbse_03_015: Speaking/listening discussions use comprehension as basis for oral analysis

## CROSS_SUBJECT_PREREQS
c11_hin_ar_cbse_01_012, c11_hin_v_cbse_01_012
## CROSS_SUBJECT_REASONS
c11_hin_ar_cbse_01_012: Antra (prose/poetry blend) comprehension strategies transfer across Hindi Core/Elective
c11_hin_v_cbse_01_012: Vitan (supplementary reader) comprehension reinforces same skill set with different texts

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_01_012 -> c12_hin_a_cbse_03_012 -> c12_hin_a_cbse_03_013

## THIS_FORMULA
PEEL for Comprehension: Point (direct answer) → Evidence (quote/paraphrase line/word) → Explanation (how evidence proves point) → Link (connect to question's demand / central idea)

## FORMULA_VARIABLES
P = Point (1 sentence answering the question directly); E = Evidence (exact textual reference with line/stanza); E = Explanation (2-3 sentences analyzing the evidence); L = Link (1 sentence tying back to question keyword or poem's central theme)

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
linguistic

## CROSS_SUBJECT
N/A | Historical source analysis requires identical literal/inferential distinction: explicit facts (dates, names) vs inferred motives (why a ruler issued an edict)
 N/A | Economics case studies demand literal reading of data tables and inferential reasoning about market behavior — same evidence→claim structure
 N/A | Constitutional provisions (literal text) vs judicial interpretations (inferential) mirror the poem comprehension skill exactly
## PREREQ_CONCEPT
Ability to identify explicit textual details (who, what, where, when) and separate them from implicit suggestions (why, how, so what).

## PREREQ_BEFORE
Student must be able to locate a specific word/phrase in the poem when given a literal question, without re-reading the entire poem.

## PREREQ_STUCK
If stuck, review "Text: Plot and Narrative Structure" (c12_hin_a_cbse_03_002) to practice locating details in sequence, then "Vocabulary in Context" (c12_hin_a_cbse_03_010) to resolve word-level ambiguities.

## WORKED_EXAMPLE_1
PROBLEM: प्रश्न: 'नहीं वो सयक' कविता में कवि ने 'नहीं' शब्द की पुनरावृत्ति क्यों की है? पाठगत प्रमाण सहित उत्तर दीजिए।
STEPS:
- Step 1: प्रश्न का प्रकार पहचानें — यह अनुमानात्मक (inferential) प्रश्न है क्योंकि 'क्यों' पूछ रहा है, पाठ में सीधा उत्तर नहीं है।
- Step 2: कविता में 'नहीं' शब्द के सभी प्रसंग ढूंढें — पद 1: "नहीं वो सयक लुसग हक", पद 2: "नहीं वो सयक खोज हक", पद 3: "नहीं वो सयक... एनेर्क", पद 4: "नहीं वो सयक... एनेर्क"।
- Step 3: प्रत्येक प्रसंग के बाद क्या आता है, नोट करें — पद 1 के बाद: "गस खोज हक एनेर्क", पद 2 के बाद: "एनेर्क", पद 3-4 में: "एनेर्क" की स्थापना।
- Step 4: पैटर्न पहचानें — कवि पहले नकारता है (सयक लुसग/खोज नहीं है), फिर सकारात्मक परिभाषा देता है (ये सयक एनेर्क)।
- Step 5: निष्कर्ष बनाएं — पुनरावृत्ति 'नकार-से-सकार' युक्ति (negative definition technique) है जो सयक की परंपरागत धारणा को तोड़कर नई परिभाषा गढ़ती है।
REASONING: यह विधि शाब्दिक अवलोकन (शब्द गणना, स्थान) को अनुमानात्मक निष्कर्ष (कवि की युक्ति) में बदलती है, जो बोर्ड परीक्षा के 'विश्लेषण' टाइप प्रश्नों के लिए अनिवार्य है।
ANSWER: कवि ने 'नहीं' की पुनरावृत्ति 'नकार-से-सकार' युक्ति के तहत की है। पद 1 में "नहीं वो सयक लुसग हक... गस खोज हक एनेर्क", पद 2 में "नहीं वो सयक... एनेर्क", पद 3-4 में भी यही पैटर्न है। प्रत्येक 'नहीं' सयक की रूढ़ छवि (लघुता, साधारणता) को नकारता है और तुरंत 'एनेर्क' (विस्तार, गहराई, जीवन-सत्य) स्थापित करता है। यह पुनरावृत्ति केंद्रीय भाव — 'सयक छोटी नहीं, जीवन-समग्र है' — को बल देती है।

## WORKED_EXAMPLE_2
PROBLEM: प्रश्न: 'मैंने देखा, एक कव्वन' कविता में "जै बख़ज़र सर ल्वजत ध वख़्स ल्स" पंक्ति में 'ल्वजत' शब्द कव्वन के किस गुण को दर्शाता है? शाब्दिक और निहितार्थ दोनों लिखिए।
STEPS:
- Step 1: शब्द का शाब्दिक अर्थ शब्दकोश/पाठ-प्रसंग से निकालें — 'ल्वजत' = पंख फड़फड़ाना / उड़ान भरना (क्रिया विशेषण)।
- Step 2: पंक्ति में शब्द की भूमिका देखें — "जै बख़ज़र सर" (जैसे कवच सिर पर) + "ल्वजत ध वख़्स ल्स" (फड़फड़ाते हुए पंखों से) — यह कव्वन की शारीरिक क्रिया का वर्णन है।
- Step 3: निहितार्थ के लिए आसपास की पंक्तियाँ देखें — अगली पंक्ति: "ये वक़्क़ गस — लो;ा दक़ ध एक़ुक ध ;क़क्स्लप्" (यह वक़्क़ है — लो;ा दक़ ध एक़ुक ध ;क़क्स्लप्) — कव्वन की उड़ान साधारण नहीं, 'वीरता' का प्रतीक है।
- Step 4: कविता के केंद्रीय भाव से जोड़ें — कव्वन = साधारण प्राणी जिसकी साधारण क्रिया (उड़ना) भी गरिमामय है।
- Step 5: दोनों अर्थ अलग-अलग लिखें — शाब्दिक: पंख फड़फड़ाने की क्रिया; निहितार्थ: जीवन-संघर्ष में सक्रियता/वीरता/स्वतंत्रता।
REASONING: शाब्दिक अर्थ पाठ की सतह पर है; निहितार्थ पाठ के गहरे स्तर (थीम: साधारण में असाधारण) से जुड़ता है। दोनों लिखने से पूरा अंक मिलता है।
ANSWER: शाब्दिक अर्थ: कव्वन के पंख फड़फड़ाने / उड़ने की शारीरिक क्रिया। निहितार्थ: साधारण प्राणी की जीवन-यात्रा में सक्रिय संघर्षशीलता, वीरता और स्वतंत्रता का प्रतीक। प्रमाण: "जै बख़ज़र सर" (कवच जैसा सिर) + "ल्वजत" = योद्धा जैसी मुद्रा में उड़ान।

## WORKED_EXAMPLE_3
PROBLEM: प्रश्न: दोनों कविताओं ('नहीं वो सयक' और 'मैंने देखा, एक कव्वन') में 'साधारण' को 'असाधारण' बनाने की काव्य-प्रक्रिया की तुलना कीजिए। कम-से-कम दो समानताएँ और एक भिन्नता पाठगत प्रमाण सहित बताइए।
STEPS:
- Step 1: दोनों कविताओं का केंद्रीय भाव पहचानें — दोनों 'साधारण' (छोटी कविता / काला कव्वन) को 'असाधारण' (जीवन-सत्य / वीर प्रतीक) में बदलती हैं।
- Step 2: 'नहीं वो सयक' की प्रक्रिया निकालें — नकार-युक्ति: "नहीं लुसग... नहीं खोज... एनेर्क" (परिभाषा विस्तार द्वारा)।
- Step 3: 'मैंने देखा, एक कव्वन' की प्रक्रिया निकालें — रूपक-युक्ति: "जै बख़ज़र सर" (कवच), "ल्वजत" (वीर उड़ान), "वाओक्क... इक़्सभ्" (मानवीय मूल्यों का आरोपण)।
- Step 4: समानताएँ ढूंढें — (1) दोनों साधारण विषय लेती हैं और उसे गरिमा देती हैं। (2) दोनों पाठक की पूर्वधारणा (कविता छोटी होती है / कव्वन तुच्छ होता है) को तोड़ती हैं।
- Step 5: भिन्नता ढूंढें — 'नहीं वो सयक' में प्रक्रिया 'बौद्धिक/तार्किक' है (परिभाषा-विस्तार), जबकि 'मैंने देखा, एक कव्वन' में 'दृश्य/अनुभूतिमूलक' है (छवि-निर्माण)।
- Step 6: उत्तर को PEEL संरचना में लिखें — प्रत्येक बिंदु के लिए प्रमाण उद्धृत करें।
REASONING: तुलनात्मक प्रश्नों में 'समानता-भिन्नता' का स्पष्ट विभाजन और प्रत्येक के लिए स्वतंत्र प्रमाण अनिवार्य है — यही बोर्ड परीक्षा के 5-6 अंकों वाले प्रश्नों का पैटर्न है।
ANSWER: समानता 1: दोनों कविताएँ साधारण विषय (छोटी कविता / काला कव्वन) को असाधारण अर्थ (जीवन-सत्य / वीरता) देती हैं। प्रमाण: 'नहीं वो सयक' — "ये वक़्क़ गस... एनेर्क"; 'कव्वन' — "जै बख़ज़र सर ल्वजत"। समानता 2: दोनों पाठक की रूढ़ धारणा खंडित करती हैं। प्रमाण: 'नहीं वो सयक' — "नहीं वो सयक लुसग हक"; 'कव्वन' — शीर्षक में 'एक कव्वन' (तुच्छ) vs "बख़ज़र" (गरिमामय)। भिन्नता: 'नहीं वो सयक' तार्किक नकार-युक्ति (definition by negation) प्रयुक्त करती है — "नहीं... एनेर्क" पैटर्न; 'कव्वन' दृश्य रूपक-युक्ति (metaphorical imaging) प्रयुक्त करती है — "बख़ज़र", "ल्वजत", "वाओक्क"।

## COMPETENCY_QUESTION_1
QUESTION: CBSE बोर्ड परीक्षा में एक प्रश्न आया: "'नहीं वो सयक' कविता में कवि ने 'सयक' शब्द की परिभाषा कैसे बदली है? दो उदाहरण दीजिए।" एक छात्र ने उत्तर लिखा: "कवि ने सयक को छोटी नहीं, बड़ी बताया है। जैसे — लुसग नहीं, खोज।" इस उत्तर में क्या कमियाँ हैं? PEEL ढाँचे का प्रयोग करके सुधारित उत्तर लिखिए।
COMPETENCY: Critical evaluation of peer response + structured answer writing
STEPS:
- Step 1: छात्र के उत्तर की कमियाँ पहचानें — (1) 'बड़ी' अस्पष्ट है (कविता में 'एनेर्क' प्रयुक्त है)। (2) 'लुसग नहीं, खोज' गलत उद्धरण है — कविता में "नहीं वो सयक लुसग हक... गस खोज हक एनेर्क" है। (3) PEEL संरचना नहीं है — Point बिना Evidence के, Explanation नहीं, Link नहीं।
- Step 2: सही Point बनाएं — "कवि 'नकार-से-सकार' युक्ति से सयक की परिभाषा विस्तारित करते हैं।"
- Step 3: सही Evidence चुनें — उदा. 1: पद 1 "नहीं वो सयक लुसग हक... गस खोज हक एनेर्क"; उदा. 2: पद 3 "ये वक़्क़ गस — लो;ा दक़ ध एक़ुक ध ;क़क्स्लप्"।
- Step 4: Explanation लिखें — प्रत्येक प्रमाण का विश्लेषण: पद 1 में लघुता/साधारणता नकारकर विस्तार/गहराई स्थापित; पद 3 में ग्रामीण जीवन की सहजता को सयक का विषय बनाना।
- Step 5: Link जोड़ें — "इस प्रकार कवि सयक को 'लघु रचना' न मानकर 'जीवन-समग्र अभिव्यक्ति' सिद्ध करते हैं।"
ANSWER: कमियाँ: (1) 'बड़ी' शब्द कविता-प्रयुक्त 'एनेर्क' नहीं है। (2) "लुसग नहीं, खोज" गलत उद्धरण — मूल: "नहीं वो सयक लुसग हक... गस खोज हक एनेर्क"। (3) PEEL संरचना अनुपस्थित। सुधारित उत्तर: कवि 'नकार-से-सकार' युक्ति से सयक की परिभाषा विस्तारित करते हैं (Point)। पद 1 में "नहीं वो सयक लुसग हक... गस खोज हक एनेर्क" — लघुता/साधारणता नकारकर विस्तार/गहराई स्थापित करते हैं (Evidence 1 + Explanation)। पद 3 में "ये वक़्क़ गस — लो;ा दक़ ध एक़ुक ध ;क़क्स्लप्" — ग्रामीण जीवन की सहजता को सयक का विषय बनाते हैं (Evidence 2 + Explanation)। इस प्रकार सयक 'लघु रचना' नहीं, 'जीवन-समग्र अभिव्यक्ति' है (Link)।
DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: एक अपठित काव्यांश दिया गया है (कल्पनात्मक): "नहीं वो फूल जो महके केवल / नहीं वो गंध जो बिके बाजार में / वो तो वो जड़ जो धरती सींचे / वो तो वो तना जो आँधी सहे।" इसके आधार पर: (क) दो शाब्दिक तथ्य लिखिए। (ख) एक अनुमानात्मक निष्कर्ष निकालिए कि कवि 'फूल' को कैसे पुनर्परिभाषित कर रहा है। (ग) 'नहीं वो सयक' कविता की नकार-युक्ति से इस काव्यांश की युक्ति की तुलना कीजिए। यह प्रश्न CUET/Hindi Core के 'तुलनात्मक बोध' पैटर्न पर आधारित है।
COMPETENCY: Transfer of comprehension strategy to unseen text + comparative analysis across texts
STEPS:
- Step 1: (क) शाब्दिक तथ्य निकालें — तथ्य 1: कविता में 'फूल', 'गंध', 'जड़', 'तना' शब्द आए हैं। तथ्य 2: 'नहीं' शब्द दो बार आया है (पहली दो पंक्तियों में)।
- Step 2: (ख) अनुमानात्मक निष्कर्ष — कवि फूल को 'सौंदर्य/सुगंध मात्र' (बाजारू) न मानकर 'जीवन-शक्ति/संघर्ष' (जड़/तना) के रूप में पुनर्परिभाषित कर रहा है। प्रमाण: "नहीं वो फूल जो महके केवल / नहीं वो गंध जो बिके बाजार में" vs "वो तो वो जड़ जो धरती सींचे / वो तो वो तना जो आँधी सहे"।
- Step 3: (ग) तुलना करें — समानता: दोनों में 'नहीं... वो तो/एनेर्क' पैटर्न (नकार-युक्ति)। भिन्नता: 'नहीं वो सयक' में नकार के बाद 'एनेर्क' (परिभाषा-विस्तार) आता है; इस काव्यांश में नकार के बाद 'वो तो' (पहचान-स्थापना) आता है। 'नहीं वो सयक' बौद्धिक/तार्किक है; यह काव्यांश दृश्य/प्रतीकात्मक है।
- Step 4: उत्तर को संरचित रूप में लिखें — प्रत्येक भाग के लिए अलग पैराग्राफ, प्रमाण सहित।
ANSWER: (क) शाब्दिक तथ्य: 1. काव्यांश में 'फूल', 'गंध', 'जड़', 'तना', 'धरती', 'आँधी' संज्ञाएँ प्रयुक्त हैं। 2. 'नहीं' शब्द प्रथम दो पंक्तियों में क्रमशः 'फूल' और 'गंध' के साथ आया है। (ख) अनुमानात्मक निष्कर्ष: कवि फूल को बाह्य सौंदर्य/सुगंध (जो बाजार में बिकती है) तक सीमित न करके, उसकी आंतरिक जीवन-शक्ति — जड़ (धरती सींचना = पोषण देना) और तना (आँधी सहना = संघर्ष सहना) — के रूप में परिभाषित करता है। प्रमाण: "नहीं वो फूल जो महके केवल... वो तो वो जड़ जो धरती सींचे"। (ग) तुलना: समानता — दोनों में नकार-युक्ति ("नहीं... वो तो/एनेर्क") से रूढ़ अर्थ खंडित कर नया अर्थ गढ़ा गया है। भिन्नता — 'नहीं वो सयक' में नकार के बाद 'एनेर्क' (परिभाषा-विस्तार, तार्किक) है; इस काव्यांश में 'वो तो' (पहचान-उद्घोषणा, प्रतीकात्मक) है। पूर्व कविता 'सयक' की अवधारणा बदलती है; यह काव्यांश 'फूल' की पहचान बदलता है।
DIFFICULTY: hard