## DEFINITION
The primary theme of a literary text is its central, unifying idea that the author develops through content, structure, and language; in this chapter, the primary theme is the organic evolution and interconnectedness of Indian arts (painting, music, dance, folk traditions) as living expressions of India's cultural unity in diversity, rooted in daily life, rituals, and the Natyashastra tradition.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student can identify the primary theme of the chapter, trace its development across at least three distinct art forms discussed in the text, and write a structured board-style answer using textual evidence (PEEL format) that connects the theme to the concept of 'unity in diversity' and the 'living tradition' of Indian arts.

## SCOPE_BOUNDARY
This node covers identifying and analyzing the primary theme of Chapter 4 (Hkkjrh; dykvksa esa cstksM+yrk) with textual evidence from the NCERT Vitan textbook. It does NOT cover secondary themes (node 007), detailed literary devices (nodes 008-009), or writing skills (node 014) — those are separate nodes.

## WALKTHROUGH
Imagine you're standing in a museum where a Warli painting, a Bharatanatyam posture, and a Baul song are displayed together — what single thread connects them? That's exactly what this chapter asks: find the one big idea that binds India's diverse arts. Start by listing the three major art categories the text discusses (painting, music/dance, folk arts). Then ask: what does the author say about their origin? (Answer: folk/tribal roots). What does the author say about their current state? (Answer: living, evolving, interconnected). The key insight: the primary theme isn't just "Indian arts are diverse" — it's that their diversity emerges from a shared philosophical root (Natyashastra, life-ritual connection) and they remain alive because they never severed ties with the community.

## DIAGNOSTIC_QUESTION_1
What is the primary theme of Chapter 4 "Hkkjrh; dykvksa esa cstksM+yrk" as stated in the NCERT Vitan textbook?

## DIAGNOSTIC_ANSWER_1
The primary theme is the organic unity and continuous evolution of Indian arts (painting, music, dance, folk traditions) as living expressions of India's cultural philosophy, rooted in folk origins and the Natyashastra tradition, reflecting unity in diversity. A wrong answer like "Indian arts are very old" or "There are many types of Indian art" reveals the student is listing facts instead of synthesizing the central argument — they're confusing topic with theme.

## DIAGNOSTIC_QUESTION_2
Explain in your own words how the chapter establishes the connection between 'yksd dyk' (folk art) and ''kkL=kh; dyk' (classical art) as part of the primary theme.

## DIAGNOSTIC_ANSWER_2
The chapter argues that classical arts evolved from folk traditions — they share the same roots (ukV~;'kkL=k), the same life-ritual connections (seasons, agriculture, festivals), and the same community participation; the distinction is of formality and codification, not origin. A wrong answer that treats them as separate categories ("folk art is for villagers, classical is for kings") reveals the student missed the central argument of continuity and missed the textual evidence about Natyashastra incorporating folk elements.

## DIAGNOSTIC_QUESTION_3
The text states: "Hkkjrh; dykvksa dk laca/ Hkkjrh; laLÑfr esa fufgr olq/So oqQVqacde dh Hkkouk ls Hkh vo'; gksxk" (Indian arts' relation is also with the deep spiritual quests embedded in Indian culture). Apply this statement to analyze how ANY ONE art form discussed in the chapter (painting OR music/dance OR folk art) embodies this 'spiritual quest'.

## DIAGNOSTIC_ANSWER_3
For painting: Warli/Madhubani paintings use ritual motifs (marriage, harvest, deities) created during ceremonies — the act of painting IS the spiritual practice, not decoration. For music/dance: The shloka "lkfgR;laxhrdykfoghu% lk{kkRi'kq% iqPNfo"kk.kghu%" defines art as a path to liberation (moksha) — performance is sadhana. For folk art: Baul songs or Rajasthani folk dances express divine love through human metaphors — the body becomes the temple. A wrong answer that only describes the art form's appearance ("Warli uses triangles") without linking to ritual/spiritual purpose shows inability to apply the theme to evidence.

## DIAGNOSTIC_QUESTION_4
Compare how the chapter treats the 'living tradition' aspect across painting (fp=kdyk) and folk performing arts (u`R; dyk). What does this comparison reveal about the primary theme's emphasis on continuity?

## DIAGNOSTIC_ANSWER_4
Painting: Text shows ancient Bhimbetka → historical frescoes → contemporary tribal artists still painting on walls/floors — unbroken line. Folk performing arts: Text emphasizes they happen TODAY in villages during festivals, seasons, life-events — not museum pieces. Both demonstrate the theme: Indian arts are NOT static heritage but living practices that adapt (new materials, new audiences) while keeping ritual-core intact. A wrong answer listing "painting is visual, folk art is performance" misses the thematic comparison — it's descriptive, not analytical.

## DIAGNOSTIC_QUESTION_5
Evaluate this claim: "The chapter's primary theme is simply 'India has many art forms.'" Defend your evaluation using at least two specific textual arguments from the chapter.

## DIAGNOSTIC_ANSWER_5
The claim is reductive and incorrect. Argument 1: The chapter's structure moves from diversity TO unity — it opens with "fofo/rk gekjh igpku gS" (diversity is our identity) but immediately grounds it in shared philosophy: "ukV~;'kkL=k" as common grammatical root for all arts. Argument 2: The concluding paragraph explicitly states the theme: arts are expressions of "lewpk ekuo thou] lewph çÑfr" (ideal human life, ideal emotion) linked to "olq/So oqQVqacde" (deep spiritual quests) — this is a philosophical claim, not a census of art forms. A wrong answer agreeing with the claim reveals the student reads for information, not argument.

## DIAGNOSTIC_QUESTION_6
Create a one-paragraph thematic statement for this chapter that a Class 11 student could use as a thesis in a board exam answer. It must include: (a) the primary theme in one sentence, (b) two art forms as evidence, (c) the concept of 'living tradition', and (d) the phrase 'unity in diversity'.

## DIAGNOSTIC_ANSWER_6
"Chapter 4 argues that Indian arts — whether the wall paintings of Bhimbetka and Madhubani or the seasonal folk dances of Rajasthan and Bengal — form a living tradition where unity in diversity is not a slogan but a structural reality: classical and folk forms share the Natyashastra's grammatical root, remain tied to agricultural and life rituals, and continue evolving through community practice, making art a continuous spiritual expression of Indian civilization rather than a museum artifact." A poor answer that lists art names without synthesizing the argument ("The chapter talks about painting, music, dance, and folk art and how they are diverse but united") shows the student cannot craft a thematic thesis — they're still in recall mode.

## COMMON_MISCONCEPTION
Students confuse 'theme' with 'topic' or 'subject matter'. They write: "The theme is Indian arts" or "The theme is types of Indian painting, music, and dance." This happens because: (1) The chapter title "Hkkjrh; dykvksa esa cstksM+yrk" sounds like a survey topic, (2) The text IS encyclopedic in listing many art forms, (3) Board exam questions often ask "What are the main features of Indian arts?" which trains students to list, not synthesize. The actual theme is an ARGUMENT about those arts: they are a unified, living, philosophically-grounded system — not a collection.

## ON_FAILURE
Step 1: Ask the student to re-read the FIRST and LAST paragraphs of the chapter only — these frame the argument. Step 2: Have them highlight every sentence that makes a CLAIM (uses words like "is", "remains", "reflects", "evolves from") vs. sentences that give EXAMPLES (names of places, artists, styles). Step 3: Ask: "If you had to explain this chapter to someone who never saw Indian art, what ONE idea would you want them to remember?" Step 4: Guide them to phrase that one idea as a complete sentence with a verb — that's the theme. Do not let them list examples.

## BUILDS_ON
c11_hin_v_cbse_04_002 (Text: Plot and Narrative Structure) — understanding how the chapter structures its argument from diversity to unity is essential before extracting theme.

## LEADS_TO
c11_hin_v_cbse_04_007 (Theme: Secondary Themes) — once primary theme is mastered, students can identify subordinate themes like 'art and ecology', 'gender in folk arts', 'oral vs written transmission'.

## PREREQUISITE_NODE_IDS
c11_hin_v_cbse_04_001, c11_hin_v_cbse_04_002, c11_hin_v_cbse_04_003, c11_hin_v_cbse_04_004, c11_hin_v_cbse_04_005
## PREREQUISITE_REASONS
c11_hin_v_cbse_04_001: Context/background knowledge (Natyashastra, regional diversity) is needed to understand the thematic framework.
c11_hin_v_cbse_04_002: Narrative structure shows how the author builds the argument — theme emerges from structure.
c11_hin_v_cbse_04_003: Setting/atmosphere (ritual spaces, seasonal cycles) provides the thematic backdrop of 'life-connected art'.
c11_hin_v_cbse_04_004: Protagonist analysis (the 'artist' as community member) reveals the thematic agent.
c11_hin_v_cbse_04_005: Supporting characters (patrons, viewers, tradition-bearers) show the thematic ecosystem.

## FORWARD_NODE_IDS
c11_hin_v_cbse_04_007, c11_hin_v_cbse_04_008, c11_hin_v_cbse_04_009, c11_hin_v_cbse_04_013, c11_hin_v_cbse_04_010, c11_hin_v_cbse_04_014, c11_hin_v_cbse_04_015

## FORWARD_REASONS
c11_hin_v_cbse_04_007: Secondary themes (ecology, gender, transmission) branch from the primary theme of living unity.
c11_hin_v_cbse_04_008: Imagery/metaphor analysis requires knowing the theme to interpret WHY specific images (tree, river, circle) recur.
c11_hin_v_cbse_04_009: Irony/symbolism (e.g., classical art needing folk roots) only makes sense against the primary theme.
c11_hin_v_cbse_04_013: Critical thinking questions demand thematic grounding as analytical lens.
c11_hin_v_cbse_04_010: Theme analysis identifies the chapter's central themes, which are the *meaning* that semantic fields construct. Without thematic clarity, vocabulary analysis becomes listing rather than interpreting — the student needs to know what theme to connect the word patterns to.  
c11_hin_v_cbse_04_014: Primary theme (art-life continuum) is the central thesis around which all analytical answers must cohere.  
c11_hin_v_cbse_04_015: Primary Theme node establishes the core argument (folk-classical unity) that discussions must engage with.  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
none

## CHAIN_DESCRIPTION
c11_hin_v_cbse_04_002 -> c11_hin_v_cbse_04_006 -> c11_hin_v_cbse_04_007

## THIS_FORMULA
Theme Identification Formula: Primary Theme = (Recurring Claim Across Sections) + (Author's Framing in Opening/Closing) + (Philosophical Generalization from Concrete Examples)

## FORMULA_VARIABLES
- Recurring Claim: The assertion repeated across painting, music, dance, folk art sections (e.g., "arts rooted in life/rituals")
- Author's Framing: Thesis statements in first/last paragraphs that define the chapter's purpose
- Philosophical Generalization: The abstract concept the concrete examples serve (e.g., "unity in diversity as lived practice")

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
analytical

## CROSS_SUBJECT
c11_history_ancient_indian_culture | The chapter's discussion of Bhimbetka, Natyashastra, and temple arts directly parallels History NCERT themes on cultural development in ancient/medieval India — both analyze how art reflects social structure and philosophy.
c11_geography_human_geography | The link between art forms and ecological zones (Warli in forests, Madhubani in floodplains, Rajasthani in desert) mirrors Geography's cultural geography concepts — art as adaptation to environment.
c11_civics_cultural_diversity | The 'unity in diversity' framework is a core Civics concept — this chapter provides the cultural/artistic evidence for what Civics theorizes politically.

## PREREQ_CONCEPT
Understanding the difference between 'topic' (what the text is about) and 'theme' (what the text argues about the topic) — specifically, theme is a complete sentence expressing a universal insight, not a noun phrase.

## PREREQ_BEFORE
Student must be able to distinguish between a factual summary ("The chapter describes Warli, Madhubani, Bharatanatyam, Baul...") and a thematic statement ("The chapter argues that Indian arts are a living, unified system rooted in shared philosophy and community ritual").

## PREREQ_STUCK
Review the 'Topic vs Theme' distinction using a familiar text (e.g., a Class 10 story) — write both a topic sentence and a theme statement for it, then compare.

## WORKED_EXAMPLE_1
PROBLEM: A student writes this answer for a 3-mark question: "Identify the primary theme of Chapter 4 and support with one example." Their answer: "The theme is Indian arts. The chapter talks about painting like Warli and Madhubani, music like Hindustani and Carnatic, and folk dances. India has unity in diversity." Analyze why this answer would score 1/3 and rewrite it for full marks.

STEPS:
- Step 1: Diagnose the error — the student wrote a TOPIC ("Indian arts") not a THEME (an argument about Indian arts). The example is a list, not evidence for a claim.
- Step 2: Extract the actual theme from the text's opening/closing paragraphs — "Indian arts are a living, unified tradition rooted in folk origins and Natyashastra, expressing unity in diversity through continuous community practice."
- Step 3: Select ONE art form that BEST illustrates this theme — Warli painting (ancient roots, still practiced ritually, community-based, evolving materials).
- Step 4: Apply PEEL structure: Point (theme), Evidence (Warli details from text), Explanation (how Warli proves living tradition + unity in diversity), Link (back to theme).
- Step 5: Write the board-style answer in 3-4 sentences with Hindi terminology where appropriate (yksd, 'kkL=kh;, ukV~;'kkL=k).

REASONING: Board examiners reward answers that state a clear thematic claim first, then use specific textual evidence to prove it. Listing art forms without a governing argument shows comprehension but not analysis. The PEEL structure forces analytical writing.

ANSWER: "Primary theme: Indian arts constitute a living, unified tradition where classical and folk forms share philosophical roots (ukV~;'kkL=k) and remain tied to community rituals, embodying unity in diversity through continuous practice. Evidence: Warli painting — from Bhimbetka's prehistoric walls to today's marriage/festival rituals, it uses the same geometric vocabulary (triangle, circle) created collectively by women, adapting to paper/canvas but keeping ritual purpose intact. This demonstrates the theme: an art form that is ancient yet alive, individual yet communal, regional yet philosophically connected to all Indian arts through shared symbols of fertility, protection, and cosmic order."

## WORKED_EXAMPLE_2
PROBLEM: The chapter states: "Hkkjrh; dykvksa dk eqjhn vkt iwjk fo'o gSA" (The relevance of Indian arts is global today). Using the primary theme, explain WHY the author makes this claim in the concluding paragraph. Write a 4-mark answer.

STEPS:
- Step 1: Recall the primary theme — living unity of arts rooted in life/rituals/spiritual quest.
- Step 2: Identify the global relevance argument in the text — "lewpk ekuo thou] lewph çÑfr" (ideal human life, ideal emotion) and "olq/So oqQVqacde" (deep spiritual quests) are universal human concerns.
- Step 3: Connect theme to claim — because Indian arts never separated from life (unlike Western 'art for art's sake'), they offer a model where aesthetics and ethics, individual and community, tradition and innovation are integrated.
- Step 4: Select two art forms as proof — e.g., Natyashastra's rasa theory (universal emotional grammar) and folk arts' ecological wisdom (sustainability through ritual).
- Step 5: Structure as: Theme restatement → Global claim explanation → Evidence 1 → Evidence 2 → Concluding synthesis.

REASONING: This question tests whether the student can use the primary theme as an analytical tool to interpret the author's concluding claim — a higher-order skill than mere identification. The 4-mark answer requires multi-step reasoning connecting theme to global claim to textual evidence.

ANSWER: "The author claims global relevance because the primary theme — Indian arts as living expressions of unified philosophical vision — offers a model the modern world needs: art integrated with life, ecology, and spirituality. First, Natyashastra's rasa theory (ikdks"kq 'kkL=k) provides a universal grammar of human emotion (Hkko-Hkafxek) transcending culture — relevant for global performing arts and psychology. Second, folk arts like Rajasthani mandana or Bengal's alpona encode ecological knowledge (seasonal cycles, soil/water reverence) in ritual practice — a model for sustainable living the world seeks. Unlike Western art often severed from ritual, Indian arts demonstrate 'lewpk ekuo thou' (ideal human life) where beauty, duty, and transcendence are one — making their 'eqjhn' (relevance) not nostalgic but urgently contemporary."

## WORKED_EXAMPLE_3
PROBLEM: A board exam question asks: "Trace the development of the primary theme across the three major sections of the chapter (fp=kdyk, laxhr, u`R; dyk). Show how each section advances the argument." Write a 6-mark answer.

STEPS:
- Step 1: State the primary theme clearly in one sentence (thesis).
- Step 2: Map the chapter's three main sections — Painting (fp=kdyk, pp. 60-63), Music/Dance (laxhr, pp. 64-66), Folk Arts (u`R; dyk, pp. 66-69).
- Step 3: For EACH section, identify: (a) the opening claim, (b) the evidence/examples, (c) how it connects to the theme's key pillars (folk roots, Natyashastra unity, living tradition, life-ritual connection).
- Step 4: Show PROGRESSION — Painting establishes ancient continuity (Bhimbetka → now); Music/Dance provides the theoretical framework (Natyashastra, rasa, grammar); Folk Arts proves living practice today (seasons, life-events, community).
- Step 5: Synthesize — the three sections form a dialectic: Origin (painting) → Theory (music/dance) → Living Practice (folk arts) = complete argument for theme.
- Step 6: Write in structured paragraphs with textual references (page numbers or section names).

REASONING: This is a synthesis-level question requiring the student to hold the whole chapter's architecture in mind and demonstrate how the theme is BUILT, not just stated. It combines knowledge of structure (node 002), content (nodes 003-005), and thematic analysis (this node) — exactly what board competency questions demand.

ANSWER: "Primary theme: Indian arts are a living, unified tradition rooted in folk origins and Natyashastra philosophy, expressing unity in diversity through continuous community practice linked to life rituals. Section 1 (fp=kdyk, pp. 60-63): Opens with 'fp=kdkjh çkphu dky ls gh gekjs thou dk vfHkUu vax jgk gS' — establishes art as primal human expression. Traces Bhimbetka → historical frescoes → contemporary tribal wall/floor painting — proves unbroken continuity. Key evidence: Warli/Madhubani still ritually created by women, using same symbols (triangle=fertility, circle=cosmos). Advances theme: ART AS ANCIENT YET LIVING ROOT. Section 2 (laxhr, pp. 64-66): Provides the 'grammar' — 'ukV~;'kkL=k' as common source for all arts. Shloka 'lkfgR;laxhrdykfoghu%' defines art as moksha-path. Rasa theory (Hkko-Hkafxek) = universal emotional science. Classical forms (ekxhZ/nslh) codified but rooted in folk (nslh = yksd). Advances theme: ART AS PHILOSOPHICALLY UNIFIED SYSTEM. Section 3 (u`R; dyk, pp. 66-69): Demonstrates LIVING PRACTICE — 'Hkkjr yksd u`R;ksa ls le`¼ jgk gS'. Lists current forms across states tied to seasons (fxík, pkSdiwjuk), life-events (birth, marriage, harvest), and ecology (gkFk, iSj). 'ykvksa dh viuh Hkk"kk' — art as community's own language. Advances theme: ART AS COMMUNITY'S LIVING VOICE. Synthesis: The chapter moves from material continuity (painting) → theoretical unity (music/dance) → social aliveness (folk arts) — together proving the theme: Indian arts are not heritage but a living civilization's breathing expression."

## COMPETENCY_QUESTION_1
QUESTION: A Class 11 student writes this thematic statement for Chapter 4: "The chapter shows that Indian art forms like painting, music, and dance are very diverse but they all come from the same root." Identify TWO specific weaknesses in this statement from a board exam perspective, and rewrite it to meet the 'analyze' level expectation.

COMPETENCY: Thematic synthesis and board exam answer writing

STEPS:
- Step 1: Identify Weakness 1 — "very diverse but same root" is vague; doesn't name the root (Natyashastra/ukV~;'kkL=k) or the nature of unity (philosophical, ritual, grammatical).
- Step 2: Identify Weakness 2 — "painting, music, dance" lists categories but misses folk arts (u`R; dyk) which the chapter treats as EQUAL pillar, not subset.
- Step 3: Identify Weakness 3 (bonus) — misses 'living tradition' aspect (present continuous practice, not just historical origin).
- Step 4: Rewrite using: precise terminology (ukV~;'kkL=k, yksd/'kkL=kh;, je~ Hkkouk), complete sentence with claim verb, all three art pillars, living tradition concept.

ANSWER: "Weakness 1: Lacks textual precision — 'same root' should be 'ukV~;'kkL=k as grammatical and philosophical foundation for all arts including folk'. Weakness 2: Omits u`R; dyk (folk performing arts) as a co-equal category the chapter devotes 4 pages to. Weakness 3: Presents unity as historical fact ('come from') not living reality ('continue evolving through'). Rewritten thematic statement: 'Chapter 4 argues that Indian arts — painting (fp=kdyk), music-dance (laxhr), and folk performing traditions (u`R; dyk) — form a single living system unified by the Natyashastra's aesthetic grammar (ukV~;'kkL=k), where classical forms codify what folk traditions enact ritually, and both remain dynamically connected to agricultural cycles, life passages, and communal spiritual quests (olq/So oqQVqacde), making unity in diversity a practiced reality not a historical origin.'"

DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: The chapter contains this assertion: "fganqLrkuh dyk ftruh fganqLrku esa fn•kbZ iM+rh gS] blls dgha vf/d mlosQ ckgj Hkh gSA" (The more tribal an art appears, the more profound it actually is). Using the primary theme as your analytical lens, evaluate this paradox. Your answer must reference at least two specific art forms and explain HOW the paradox serves the chapter's central argument.

COMPETENCY: Critical evaluation using thematic framework

STEPS:
- Step 1: Unpack the paradox — 'tribal' (fganqLrkuh) usually implies 'primitive/simple' but author claims 'profound' (ckgj) meaning philosophically deep.
- Step 2: Connect to primary theme — the theme says folk/tribal arts are NOT inferior precursors but THE living carriers of India's core philosophy (unity with nature, ritual as life, community as canvas).
- Step 3: Select Art Form 1 — Warli painting: appears 'simple' (stick figures, triangles) but encodes cosmic geometry (circle=sun/moon, triangle=male/female/fertility) and is created RITUALLY during marriage/harvest — the 'simplicity' IS the sophistication of a visual language accessible to all.
- Step 4: Select Art Form 2 — Baul singing (Bengal folk): appears 'rustic' (ektara, wandering minstrels) but expresses advaita philosophy (body as temple, divine in human love) that parallels Upanishadic thought — the 'folk form' carries 'high philosophy'.
- Step 5: Explain HOW this serves the central argument — it collapses the hierarchy between 'classical' and 'folk', proving the theme's claim that unity in diversity means NO art form is peripheral; the 'tribal' IS the classical in its living essence.
- Step 6: Conclude with the author's purpose: to decolonize the classical/folk binary and reposition Indian aesthetics on its own terms.

ANSWER: "The paradox 'fganqLrkuh dyk... ckgj' is the thematic engine of the chapter. It serves the primary argument — Indian arts as unified living tradition — by dismantling the colonial hierarchy that labeled folk/tribal arts as 'craft' or 'primitive' and only classical as 'high art'. Warli painting: its 'simple' geometry (triangle, circle, line) is actually a sophisticated cosmic vocabulary — the triangle (yoni/linga) encodes creation philosophy, the circle (sun/moon) encodes cyclical time; created by women on marriage walls, it makes metaphysics domestic. Baul songs: 'rustic' ektara and wandering singers carry the Upanishadic 'deho tatta' (body as truth) — 'maner manush' (man of the heart) is advaita in vernacular. Both prove the theme: the 'tribal' IS the 'classical' in its purest, most accessible form because it never severed ties with je~ Hkkouk (life rituals). The paradox forces the reader to see that India's 'unity in diversity' is not tolerance of difference but recognition that the margin (folk) IS the center (philosophy). This is why the chapter ends with 'eqjhn vkt iwjk fo'o gSA' — the world needs this non-hierarchical, life-embedded art model."

DIFFICULTY: hard