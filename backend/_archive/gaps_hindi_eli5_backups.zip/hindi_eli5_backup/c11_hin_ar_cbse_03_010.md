## DEFINITION
Vocabulary in Context refers to the skill of determining the precise meaning, connotation, and grammatical function of key words as they are used within a specific literary text, rather than relying solely on dictionary definitions. It involves analyzing how an author's word choice shapes tone, reveals character, advances plot, and conveys thematic depth in the particular passage where the word appears.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student can independently identify 8-10 key words from the chapter, explain their contextual meanings with textual evidence, differentiate between literal and figurative usage, and demonstrate how each word contributes to the author's portrayal of the theatrical world and personal struggle.

## SCOPE_BOUNDARY
This node covers the 12 key vocabulary words listed in the NCERT 'kCn&Nfo' section (dky[kaM, LFkfxr, HkkM+s ij, oaQfVU;qbVh, 'kkWV~l, lkmaM fjdkWfMZLV, iqoqQj, uokxr gksuk, unkjn, Hkkr, ckW;yj, okLrqliZ) as they appear in I.F. Ikapkyh's autobiographical narrative. It does NOT cover general vocabulary building, synonyms/antonyms lists, or words from other chapters.

## WALKTHROUGH
Imagine you're watching a play where the actor says "The stage is set" - but you realize they mean "My life is at a turning point," not just the physical platform. That's vocabulary in context. Begin by opening the text to the first occurrence of each key word (e.g., 'dky[kaM' on page 32 where the author describes his struggle). Ask: "What is happening in the narrative at this exact moment? What emotion or situation does this word capture that a simple definition misses?" Trace each word through 2-3 occurrences to see if its meaning shifts. The key insight: in this chapter, theatrical terms like 'ckW;yj' (wings) and 'okLrqliZ' (proscenium) carry the weight of the author's artistic birth - they are not just stage parts but metaphors for his entry into a lifelong vocation.

## DIAGNOSTIC_QUESTION_1
What is the contextual meaning of 'oaQfVU;qbVh' as used in the sentence "mlesa ls ^oaQfVU;qbVh* unkjn gks tkrh" on page 33, and why does the author choose this specific word instead of a simpler term like 'xk;c' or 'deyk'?

## DIAGNOSTIC_ANSWER_1
Contextual meaning: 'oaQfVU;qbVh' means 'helplessness' or 'powerlessness' - specifically the helplessness of being unable to afford a proper cradle for the baby. The author chooses this Sanskritised compound (oaQ+fVU;qbVh = without support/helpless) over simpler words because it carries the weight of systemic poverty and the indignity of an artist unable to provide basics, elevating a personal struggle to a universal condition of the struggling artist. A wrong answer (e.g., just 'sadness' or 'poverty') reveals the student is translating literally without analyzing the word's morphological weight and the author's deliberate diction to convey artistic vulnerability.

## DIAGNOSTIC_QUESTION_2
The word 'ckW;yj' appears twice in the narrative (pages 34-35). Explain how its meaning shifts from a literal theatrical term to a metaphorical representation of the author's anxiety during the premiere.

## DIAGNOSTIC_ANSWER_2
First occurrence (p.34): Literal - "xkM+h osQ 'kwfVax dh txg osQ ikl vkrs gh ckW;yj esa dks;yk Mkyuk" - the physical wings/off-stage area where actors wait. Second occurrence (p.35): Metaphorical - "ckW;yj dk n`';" - the entire backstage crisis including the failed cradle, the missing infant, the storm, and the author's spiraling panic. The shift reveals how theatrical space mirrors psychological space. A wrong answer treating both as identical reveals failure to recognize metaphorical extension - a core Class 11 skill where concrete theatrical vocabulary becomes a vehicle for abstract emotional states.

## DIAGNOSTIC_QUESTION_3
In the phrase "lkmaM fjdkWfMZLV Hkwisu ckcw" (p.37), 'fjdkWfMZLV' is a compound adjective describing the sound. Deconstruct this compound (samās) and explain how its meaning creates a specific auditory image that 'loud' or 'noisy' cannot capture.

## DIAGNOSTIC_ANSWER_3
Samās vigraha: fjdkWfM±x djus okyk / fjdkWfM±x dk ykHk ysus okyk. 'fjdkWfM±x' = violent shaking/trembling (from fj + dkWfM±x). The compound means 'producing a violently shaking/trembling sound.' Unlike 'loud' (intensity) or 'noisy' (unpleasantness), 'fjdkWfMZLV' conveys a sound that physically vibrates through the body - the infant's cry shakes the air like a seizure. This mirrors the author's internal trembling. A wrong answer giving only 'loud cry' misses the somatic quality - the sound doesn't just enter ears, it shakes the listener's frame, paralleling how the theatrical crisis shakes the author's confidence.

## DIAGNOSTIC_QUESTION_4
Compare the usage of 'Hkkr' (p.35: "viw dh ek¡ loZt;k viw dks Hkkr f[kyk jgh gS") and 'Hkkr' (p.36: "viw [kkrs&[kkrs gh deku ls rhj NksM+rk gS"). How does the same noun acquire different thematic resonance in these two scenes involving the same character (the infant)?

## DIAGNOSTIC_ANSWER_4
First scene: 'Hkkr' = breast milk, the infant's rejected sustenance - symbol of maternal nurture spurned, the child's inexplicable refusal of life's basics. Second scene: 'Hkkr' = the same milk now accepted ravenously ("Hkwyks og Hkkr [kkrk gS") - symbol of restoration, the return of natural order after the supernatural crisis. The repetition creates a structural arc: rejection → crisis → acceptance. A wrong answer seeing only 'milk' in both cases misses how the author uses lexical repetition to chart the infant's journey from uncanny refusal to human need, mirroring the play's journey from disaster to triumph.

## DIAGNOSTIC_QUESTION_5
Evaluate the author's choice to use 'okLrqliZ' (proscenium/proscenium arch) on page 38 instead of simpler terms like 'stage' or 'curtain.' How does this technical term function as a metonym for the entire theatrical institution the author is entering?

## DIAGNOSTIC_ANSWER_5
'okLrqliZ' (from okLrq + liZ = house-divider) is the architectural frame separating audience from performance world. By using this precise term for the mysterious figure ("og ^okLrqliZ* Fkk") who turns out to be a wandering ascetic, the author makes the theatre's threshold a literal character. The proscenium is where reality becomes art; the ascetic embodies that liminal space. A simpler word would lose the double meaning: the physical arch AND the metaphysical boundary the author crosses by becoming a playwright. A wrong answer calling it 'just a technical term' fails to see how vocabulary choice enacts the theme - the word itself performs the crossing it describes.

## DIAGNOSTIC_QUESTION_6
Create a 50-word paragraph continuing the narrative after page 41, using at least 4 key vocabulary words (from the 'kCn&Nfo' list) in their established contextual meanings to show the author's changed relationship with theatre after this premiere.

## DIAGNOSTIC_ANSWER_6
Sample: "Years later, the okLrqliZ no longer intimidates; it welcomes. The ckW;yj holds not panic but prepared cues. Where oaQfVU;qbVh once gripped me seeing empty seats, now uokxr gksuk the rhythm of rehearsal steadies my hand. The fjdkWfMZLV silence before curtain-rise is no longer void - it is expectation." Criteria: Words must carry their chapter-specific weight (okLrqliZ = threshold of vocation, ckW;yj = managed backstage space, oaQfVU;qbVh = artist's vulnerability, uokxr = professional familiarity). A poor answer uses words as decorations without their earned contextual resonance.

## COMMON_MISCONCEPTION
Students treat the 'kCn&Nfo' list as a glossary to memorize (word → single Hindi meaning) rather than as textual anchors requiring contextual excavation. They write "LFkfxr = fixed/permanent" but miss that in "LFkfxr j[kuh iM+rh Fkh" (p.33), it describes the cradle's intended permanence IRONICALLY contrasted with its actual impermanence - the word carries dramatic irony. This error stems from Class 10 vocabulary exercises that test isolated definitions, not the Class 11 shift to "how does this word WORK here?"

## ON_FAILURE
Step 1: Have the student locate ONE word (e.g., 'unkjn') in the text using Ctrl+F or manual scan. Step 2: Read 3 sentences before and after. Step 3: Ask: "What is the SPECIFIC situation? What does the word DO here - name, describe, judge, metaphorize?" Step 4: Compare with dictionary meaning. Step 5: Write one sentence: "In this context, unkjn means ____ because ____." Repeat for 3 words. This builds the habit of contextual anchoring over definition retrieval.

## BUILDS_ON
c11_hin_ar_cbse_03_002 (Text: Plot and Narrative Structure) - because vocabulary meaning is inseparable from narrative moments; you must know WHERE in the plot each word appears.

## LEADS_TO
c11_hin_ar_cbse_03_011 (Grammar: Language Usage in the Text) - because contextual vocabulary analysis reveals grammatical patterns (samās, taddhita, Tatsama/Tadbhava) that the grammar node formalizes.

## PREREQUISITE_NODE_IDS
c11_hin_ar_cbse_03_002, c11_hin_ar_cbse_03_009

## PREREQUISITE_REASONS
c11_hin_ar_cbse_03_002: Understanding plot structure and narrative sequence is essential to locate each vocabulary word in its precise dramatic moment - the 'when' and 'why' of its usage.
c11_hin_ar_cbse_03_009: Vocabulary in Context requires recognizing how words like "oaQfVU;qbVh" (despair) or "okLrqliZ" (landmark) carry symbolic resonance.  

## FORWARD_NODE_IDS
c11_hin_ar_cbse_03_011, c11_hin_ar_cbse_03_012, c12_hin_a_cbse_01_010, c12_hin_a_cbse_07_010, c12_hin_a_cbse_10_010, c12_hin_a_cbse_12_010, c12_hin_al_cbse_02_010, c12_hin_al_cbse_03_010, c12_hin_ar_cbse_03_010, c12_hin_ar_cbse_12_010, c11_hin_ar_cbse_03_015

## FORWARD_REASONS
c11_hin_ar_cbse_03_011: The vocabulary analysis in this node surfaces the morphological and syntactic patterns (compounds, verb forms, case endings) that the grammar node will systematize and teach as language rules.
c11_hin_ar_cbse_03_012: Vocabulary in context (e.g., "oaQfVU;qbVh", "okLrqliZ") is essential for accurate literal/inferential reading.  
c12_hin_a_cbse_01_010: Covered intertextual echoes (mythological/historical allusions in vocabulary) — needed for 'एकेक्दे', 'फोग्क्ष' analysis.  
c12_hin_a_cbse_07_010: Learned to distinguish literal vs. contextual meaning in folk-style poetry.  
c12_hin_a_cbse_10_010: Provided practice with nuanced words in a third context.  
c12_hin_a_cbse_12_010: Applied strategy to character-specific vocabulary.  
c12_hin_al_cbse_02_010: Exposure to rural landscape vocabulary in Class 11 Aroh chapters.  
c12_hin_al_cbse_03_010: Class 11 Chapter 3 vocabulary node where students practiced the 'locate-context-glossary-infer' method on a simpler text.  
c12_hin_ar_cbse_03_010: Provides the foundational skill of distinguishing dictionary vs. contextual meaning — without this, students default to the Dictionary Trap.  
c12_hin_ar_cbse_12_010: Reinforced context-clue use with poetic language — relevant for metaphorical vocabulary in this chapter.  
c11_hin_ar_cbse_03_015: or learning new vocabulary items — those are addressed in sibling nodes c11_hin_ar_cbse_03_014 and c11_hin_ar_cbse_03_010 respectively.  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
none

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_03_002 -> c11_hin_ar_cbse_03_010 -> c11_hin_ar_cbse_03_011

## THIS_FORMULA
Contextual Meaning = (Dictionary Meaning) + (Narrative Situation) + (Author's Diction Choice) + (Thematic Resonance)

## FORMULA_VARIABLES
- Dictionary Meaning: Standard lexical definition
- Narrative Situation: Plot moment, speaker, emotion, physical setting
- Author's Diction Choice: Why THIS word over synonyms (register, connotation, sound, etymology)
- Thematic Resonance: How the word echoes larger themes (art vs life, struggle, vocation)

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
linguistic

## CROSS_SUBJECT
c11_history_colonialism | The chapter's setting (1930s theatre, colonial cities, wandering performers) connects to history of colonial urban culture and performing arts under British rule
c11_economics_livelihood | The author's precarious existence as a playwright mirrors economics of informal/artistic labour - 'oaQfVU;qbVh' embodies vulnerability of creative professions without social security

## PREREQ_CONCEPT
Students must understand that in literary texts, words are not containers of fixed meaning but instruments calibrated by the author for specific dramatic effects at specific narrative moments.

## PREREQ_BEFORE
Student should have read the full chapter at least once and be able to summarize the narrative arc: struggling playwright → first play premiere → backstage crises → supernatural intervention → triumph.

## PREREQ_STUCK
If stuck, re-read pages 32-34 (the prelude to premiere) and 35-38 (the premiere night) - these contain 9 of the 12 key words in their richest contexts.

## WORKED_EXAMPLE_1
PROBLEM: Analyze the word 'dky[kaM' (p.32: "viw osQ lkFk <kbZ lky osQ dky[kaM esa gj jks"k rks 'kwfVax gksrh ugha Fkh") using the contextual meaning formula.

STEPS:
- Step 1: Identify dictionary meaning - 'dky[kaM' = courtyard, open space in front of house, compound.
- Step 2: Locate narrative situation - Author describing his early struggles BEFORE the premiere flashback; he's a young teacher in a remote post, doing odd jobs (poster-pasting) to survive.
- Step 3: Analyze author's diction choice - Why 'dky[kaM' not 'angan' or 'parisar'? 'dky[kaM' (from dky + kaM) suggests a dusty, unpaved, utilitarian space - not decorative. The 'gj jks"k' (deep darkness) in the courtyard mirrors his professional darkness.
- Step 4: Determine thematic resonance - The courtyard is where he PASTES posters (menial labour) while dreaming of playwriting. It's the threshold space between his current reality and artistic aspiration.
- Step 5: Synthesize contextual meaning - 'dky[kaM' = the dusty, dark courtyard of a minor government quarters where a future playwright pastes posters by lantern light, embodying the gap between menial present and artistic future.

REASONING: The formula forces separation of lexical meaning from contextual work. 'dky[kaM' does not just mean 'courtyard' here - it means 'the specific courtyard where artistic vocation gestated in obscurity.'

ANSWER: In this context, 'dky[kaM' signifies the physical and metaphorical margins where the author's theatrical dream survived through menial labour. The word's roughness (dusty compound) and darkness (gj jks"k) enact the struggle, while its threshold position (between house and world) mirrors his transitional state.

## WORKED_EXAMPLE_2
PROBLEM: The word 'uokxr gksuk' appears in the glossary as "u, {ks=k ;k fo"k; dks tkuuk" (becoming familiar with a field/subject). Trace its actual usage in "ge lHkh bl {ks=k esa uokxr gksus osQ dkj.k FkksM+s ckSjk, gq, gh Fks" (p.35) and explain the gap between glossary meaning and contextual meaning.

STEPS:
- Step 1: Note glossary definition - 'becoming acquainted/familiar with a field.'
- Step 2: Locate exact sentence - Spoken by the author describing the premiere night team: director, stage manager, actor-director - "we were all new to this field."
- Step 3: Analyze the irony - These are PROFESSIONALS (director, stage manager) calling themselves 'uokxr' (novices). The word usually means 'learner' but here experts claim it.
- Step 4: Identify the reason - First play for ALL of them despite professional titles. The theatrical 'field' here is not their job but THIS production - a collective debut.
- Step 5: Define contextual meaning - 'uokxr gksuk' = the shared vulnerability of a first production where professional credentials dissolve into collective apprenticeship, regardless of individual experience.

REASONING: The glossary gives the word's general semantic range. The context reveals its specific ironic deployment - a word for 'learning' used by 'experts' to express the unique terror of a first night.

ANSWER: Contextually, 'uokxr gksuk' means 'finding oneself a novice again despite professional status' - the levelling effect of a first production where the director, stage manager, and author are equally untried. The glossary meaning 'becoming familiar' is the process; the contextual meaning is the STATE of shared inexperience that binds the team.

## WORKED_EXAMPLE_3
PROBLEM: Compare 'Hkkr' (milk) and 'iqoqQj' (end/border) as material vs. spatial nouns that both become metaphysical thresholds in the narrative. Use textual evidence from pages 35-36.

STEPS:
- Step 1: Identify 'Hkkr' occurrences - p.35: infant rejects milk (rejection of life); p.36: infant accepts milk (acceptance of life). Material substance becomes threshold of existence.
- Step 2: Identify 'iqoqQj' occurrences - p.35: "iqoqQj dk'kiwQyksa osQ ou esa igq¡prk gSA" (deep inside the forest trees); p.34: "iqoqQj" as the forest depth where the cradle-search happens. Spatial boundary becomes psychological frontier.
- Step 3: Analyze parallel structure - Both are concrete nouns (liquid, location) that the narrative invests with threshold function. Milk: threshold between life/death for infant. Forest end: threshold between known/unknown for searchers.
- Step 4: Examine author's pattern - Ikapkyh repeatedly uses concrete theatrical/domestic objects as portals: ckW;yj (wings), okLrqliZ (proscenium), Hkkr (milk), iqoqQj (forest edge).
- Step 5: Formulate comparative insight - The vocabulary of thresholds (Hkkr, iqoqQj, ckW;yj, okLrqliZ) creates a semantic field where every boundary in the narrative - physical, biological, theatrical - is permeable and charged with transformation.
- Step 6: Connect to theme - The playwright's vocation IS threshold work: making the unreal real, the private public, the personal universal.

REASONING: This multi-word analysis demonstrates how vocabulary in context reveals authorial patterning - a single word analysis misses the semantic architecture.

ANSWER: 'Hkkr' and 'iqoqQj' form a paired threshold vocabulary: one biological (milk as gateway to life), one spatial (forest edge as gateway to mystery). Both are ordinary nouns the narrative elevates into liminal zones. The infant's milk-refusal/acceptance at the breast parallels the searchers' penetration into the forest's iqoqQj - both are crossings where the everyday becomes portentous. This patterning reveals Ikapkyh's poetic logic: the playwright's materials are thresholds.

## COMPETENCY_QUESTION_1
QUESTION: The glossary defines 'LFkfxr' as "jksdk gqvk] oqQN le; osQ fy, eqYroh fd;k gqvk" (fixed, kept for some time). However, in the sentence "ml le; i;kZIr iSls Hkh ugha FksA iSls [kRe gksus osQ ckn] fiQj ls iSls tek gksus rd 'kwfVax LFkfxr j[kuh iM+rh Fkh" (p.33), the word carries a specific irony. Explain this irony and what it reveals about the author's condition at that time.

COMPETENCY: Contextual irony detection through vocabulary analysis

STEPS:
- Step 1: State the glossary meaning - fixed, permanent, stationary.
- Step 2: Quote the context - rehearsal schedule "fixed" from evening after school until morning.
- Step 3: Identify the contradiction - The schedule was 'fixed' (LFkfxr) only in intention; in reality it was chaotic, interrupted, dependent on a lantern that might not come.
- Step 4: Explain the irony - 'LFkfxr' describes the author's DESPERATE ATTEMPT to impose order on chaos, not the reality. The word is aspirational, not descriptive.
- Step 5: Connect to larger condition - The struggling artist tries to 'fix' his art-making in an unfixed life.

ANSWER: The irony: 'LFkfxr' (fixed/permanent) describes a rehearsal schedule that was anything but fixed - it was a fragile construct held together by a schoolteacher's will, a borrowed lantern, and stolen hours. The word reveals the author's condition: he imposes the vocabulary of professional theatre ('fixed rehearsal hours') on a reality that refuses professional conditions. 'LFkfxr' is a wish spoken as fact.

DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: In the climactic scene (p.38-39), the author writes: "vc ;gk¡ èkhjt j[kus osQ flok nwljk mik; ugha FkkA vxj oqQÙkk cPpksa osQ ihNs nkSM+k] rks gh og mudk ikyrw oqQÙkk yx ldrk Fkk." Analyze how the word 'èkhjt' (restraint/patience) and 'mik;' (means/measure) function together to characterize the author's transformation from panic to professional composure. Why are THESE specific words chosen over synonyms like 'dhairy' or 'upay'?

COMPETENCY: Precision in lexical choice analysis - distinguishing near-synonyms in context

STEPS:
- Step 1: Define 'èkhjt' - restraint, self-control, holding back (from khij - to be agitated; a-khij = unagitated). Not just 'patience' (dhairy) but active suppression of panic.
- Step 2: Define 'mik;' - measure, means, expedient, resource. Not just 'upay' (remedy) but a calculated, strategic action.
- Step 3: Analyze the collocation - 'èkhjt j[kus osQ flok nwljk mik; ugha' = there was no MEASURE/MEANS left for keeping restraint. Restraint has run out; strategy has failed.
- Step 4: Contrast with synonyms - 'dhairy' is a virtue; 'èkhjt' is a finite resource that depletes. 'upay' is a solution; 'mik;' is a tactical option.
- Step 5: Explain the transformation - The author moves from 'èkhjt' (trying to hold it together) to action: directing the mother to send the child, using the infant as 'mik;' (strategic means) to resolve the crisis. Professionalism = knowing which 'mik;' works when 'èkhjt' fails.
- Step 6: Conclude - The word choice enacts the shift from passive endurance to active professional judgement.

ANSWER: 'èkhjt' (finite restraint) and 'mik;' (tactical means) are chosen for their materiality - they are resources that can EXHAUST and DEPLOY. 'Dhairy' (courage/fortitude) is a character trait; 'èkhjt' is a diminishing supply. 'Upay' (remedy) implies a fix; 'mik;' implies a calculated move in a constrained situation. The author, having depleted his 'èkhjt', finally employs a 'mik;' (the infant as strategic intervention) - marking his transition from overwhelmed amateur to director who makes hard, effective choices. The vocabulary performs the professionalization.

DIFFICULTY: hard