## DEFINITION
Supporting characters are fictional figures who interact with the protagonist to advance the plot, reveal the protagonist's traits through contrast or parallel, embody thematic ideas, and represent social forces within the narrative world of "उद्देश्य नक्षत्र".

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student can independently select any supporting character from the story, cite two specific textual evidences (dialogue, action, or description), explain how that character's role illuminates the protagonist's journey or the story's central themes, and compare the functions of at least two supporting characters.

## SCOPE_BOUNDARY
This node covers only the supporting characters in Premchand's "उद्देश्य नक्षत्र" (ओखलाल, फिरोज़, मिर्ज़ा, लालाजी, पंडितजी, नक्षत्र as a symbolic figure). It does NOT cover the protagonist आइंस्टाइन (addressed in node c11_hin_ar_cbse_01_004), characters from other chapters, or general character theory unrelated to this text.

## WALKTHROUGH
Think about a cricket match: the captain (protagonist) gets attention, but the wicketkeeper, the bowler who creates pressure, and the fielder who takes a stunning catch shape the game's outcome. In "उद्देश्य नक्षत्र", आइंस्टाइन's scientific pursuit gains meaning only through his interactions with ओखलाल's practicality, फिरोज़'s loyalty, मिर्ज़ा's skepticism, and the societal pressure represented by लालाजी and पंडितजी. To begin, re-read the story marking every scene where a non-protagonist speaks or acts. Ask: "What does this character want? How does their want clash with or support आइंस्टाइन's goal? What would vanish from the story if this character were removed?" The key insight: supporting characters are not decoration; they are the lenses through which the protagonist's inner conflict and the story's social critique become visible.

## DIAGNOSTIC_QUESTION_1
Name three supporting characters from "उद्देश्य नक्षत्र" and state one distinct personality trait for each, using only the story text as evidence.

## DIAGNOSTIC_ANSWER_1
Correct answer: (1) ओखलाल – practical/grounded (evidence: advises आइंस्टाइन to accept government job for stability); (2) फिरोज़ – loyal/emotional (evidence: accompanies आइंस्टाइन in his wanderings despite hardship); (3) मिर्ज़ा – skeptical/rationalist (evidence: questions the feasibility of आइंस्टाइन's star-chasing). A wrong answer that lists traits without textual evidence reveals the student is relying on imagination rather than close reading. A wrong answer that confuses ओखलाल with फिरोज़ shows failure to distinguish character voices.

## DIAGNOSTIC_QUESTION_2
Explain in your own words how ओखलाल's worldview differs from आइंस्टाइन's, and why this difference is necessary for the story's conflict.

## DIAGNOSTIC_ANSWER_2
Correct answer: ओखलाल values material security, social acceptance, and familial duty (he urges आइंस्टाइन to take the government job, saying "नौकरी मिल गयी तो जीवन सुखी हो जायगा"), while आइंस्टाइन pursues an abstract scientific ideal regardless of poverty. This clash externalizes आइंस्टाइन's internal struggle between duty and passion. A wrong answer that merely summarizes their dialogue without identifying the ideological clash shows surface-level comprehension. A wrong answer claiming they share the same goal reveals inability to detect thematic opposition.

## DIAGNOSTIC_QUESTION_3
In the scene where फिरोज़ sells his belongings to fund आइंस्टाइन's experiment, identify the literary device used to characterize फिरोज़ and explain its effect on the reader's perception of आइंस्टाइन.

## DIAGNOSTIC_ANSWER_3
Correct answer: The device is foil characterization through self-sacrificial action. फिरोज़'s sacrifice (selling his watch/books) highlights आइंस्टाइन's single-minded obsession and moral blindness to the cost borne by others. Steps: (1) Locate the scene (फिरोज़ giving money saying "तुम्हारे काम के लिये मैं सब कुछ दे सकता हूँ"). (2) Identify the contrast: फिरोज़ acts out of friendship; आइंस्टाइन accepts without protest. (3) Explain effect: reader sees आइंस्टाइन's greatness as morally ambiguous. A wrong answer naming "irony" or "symbolism" misidentifies the device. A wrong answer praising फिरोज़ without critiquing आइंस्टाइन misses the evaluative dimension.

## DIAGNOSTIC_QUESTION_4
Compare the societal pressures represented by लालाजी (moneylender) and पंडितजी (priest) in the story. How do their different forms of authority constrain आइंस्टाइन's choices?

## DIAGNOSTIC_ANSWER_4
Correct answer: लालाजी embodies economic coercion (debt, interest, threat of auction – "सूदखोरी का जाल"), while पंडितजी embodies religious/traditional coercion (caste duties, rituals, fear of ostracism – "धर्म के नाम पर बंधन"). Together they trap आइंस्टाइन in a material-spiritual vise: लालाजी demands cash repayment forcing pragmatic compromise; पंडितजी demands ritual conformity forcing social conformity. A wrong answer treating them as identical "villains" misses the distinct institutional forces (economic vs. religious) Premchand critiques. A wrong answer ignoring their dialogue fails to ground analysis in text.

## DIAGNOSTIC_QUESTION_5
Critique the view that नक्षत्र (the star) functions merely as a plot device. Defend your position using the star's symbolic interactions with at least two supporting characters.

## DIAGNOSTIC_ANSWER_5
Correct answer: नक्षत्र is a dynamic symbol, not a static device. For ओखलाल, it represents "पागलपन" (madness) – he says "यह तारा नहीं, तुम्हारा भ्रम है". For फिरोज़, it represents "श्रद्धा" (faith) – he gazes at it with आइंस्टाइन. For मिर्ज़ा, it represents "विज्ञान की सीमा" (limits of science) – he calculates its distance to prove impossibility. The star's meaning shifts per character, revealing their inner worlds. A wrong answer calling it "just a goal" ignores its polysemic function. A wrong answer citing only आइंस्टाइन's view neglects the supporting cast's interpretive roles.

## DIAGNOSTIC_QUESTION_6
Write a 100-word diary entry from मिर्ज़ा's perspective on the night आइंस्टाइन declares he has "caught the star". Capture मिर्ज़ा's voice, skepticism, and hidden emotion.

## DIAGNOSTIC_ANSWER_6
Criteria for a good answer: (1) First-person voice using मिर्ज़ा's vocabulary (scientific terms mixed with Urdu inflections). (2) Expresses doubt ("क्या वाकई पकड़ लिया?") but also grudging respect ("उसकी जिद ने तो पत्थर भी पिघला दिए"). (3) References a specific earlier event (e.g., the telescope calculation scene). (4) Ends with ambiguity about whether science or madness won. A poor answer uses modern slang, ignores मिर्ज़ा's rationalist persona, or makes him fully supportive – showing failure to inhabit the character's established mindset.

## COMMON_MISCONCEPTION
Students often treat supporting characters as "background information" – listing them like a cast list – instead of analyzing them as structural necessities. They write: "ओखलाल is the friend who gives advice" (plot summary) instead of "ओखलाल embodies the gravitational pull of societal normality that the protagonist must escape to achieve transcendence" (functional analysis). This error stems from middle-school habit of "character sketches" (physical description + adjectives) rather than senior-secondary "character functions" (role in conflict, thematic representation, foil dynamics). The misconception is reinforced by exam questions that ask "describe the character" without specifying analytical depth.

## ON_FAILURE
1. Give the student a two-column table: Column A = "What the character says/does" (quote 3 actions/dialogues), Column B = "What this reveals about PROTAGONIST or THEME". 2. Model one row for ओखलाल together. 3. Student completes rows for फिरोज़ and मिर्ज़ा independently. 4. Student writes one paragraph synthesizing: "Through ओखलाल's practicality, फिरोज़'s devotion, and मिर्ज़ा's skepticism, Premchand shows that आइंस्टाइन's genius requires all three – the anchor, the fuel, and the brake." 5. Verify each claim traces to a specific textual moment.

## BUILDS_ON
c11_hin_ar_cbse_01_004 (Character Analysis: Protagonist) – understanding आइंस्टाइन's core conflict is prerequisite to seeing how supporting characters refract it.

## LEADS_TO
c11_hin_ar_cbse_01_006 (Theme: Primary Theme and Message) – supporting characters collectively embody the thematic tensions (individual vs society, science vs tradition) that the theme node will formalize.

## PREREQUISITE_NODE_IDS
c11_hin_ar_cbse_01_004, c11_hin_ar_cbse_01_002, c11_hin_ar_cbse_01_003, c11_hin_ar_cbse_01_001

## PREREQUISITE_REASONS
c11_hin_ar_cbse_01_004: Protagonist's traits and arc must be known to analyze foils and mirrors.
c11_hin_ar_cbse_01_002: Plot structure determines when/where supporting characters enter and exit.
c11_hin_ar_cbse_01_003: Setting (colonial small-town, observatory, marketplace) shapes supporting characters' social roles.
c11_hin_ar_cbse_01_001: "Context and Background" refers to the historical, social, biographical, and literary circ... की समझ आवश्यक है, क्योंकि यह नोड (Supporting characters are fictional figures who interact with the protagonist to advance t...) इसी आधार पर आगे बढ़ता है।  

## FORWARD_NODE_IDS
c11_hin_ar_cbse_01_006, c11_hin_ar_cbse_01_007, c11_hin_ar_cbse_01_013, c11_hin_ar_cbse_01_008, c12_hin_a_cbse_01_005, c12_hin_a_cbse_03_005, c12_hin_a_cbse_04_005, c12_hin_a_cbse_08_005, c12_hin_a_cbse_10_005, c12_hin_a_cbse_12_005, c12_hin_a_cbse_17_005, c12_hin_al_cbse_01_005, c12_hin_al_cbse_02_005, c12_hin_ar_cbse_01_005, c12_hin_ar_cbse_02_005, c12_hin_ar_cbse_06_005, c12_hin_ar_cbse_14_005

## FORWARD_REASONS
c11_hin_ar_cbse_01_006: Primary theme (pursuit of truth vs social obligation) is enacted through supporting characters' pressures.
c11_hin_ar_cbse_01_007: Secondary themes (friendship, rationality vs faith, colonial modernity) are carried by specific supporting figures.
c11_hin_ar_cbse_01_013: Critical thinking questions require multi-character comparative analysis.
c11_hin_ar_cbse_01_008: Supporting characters (contractor, wife, buyers) are the *vehicles* in many metaphors (e.g., contractor = government).  
c12_hin_a_cbse_01_005: Class 11 Antra Chapter 1 supporting character analysis introduced the method of reading lyrical monologues as character revelation — this node deepens that skill.  
c12_hin_a_cbse_03_005: Class 11 introduced the framework of analyzing supporting characters in prose/poetry; this node applies it at a higher symbolic density.  
c12_hin_a_cbse_04_005: Class 11 foundation for character analysis terminology and evidence-based reasoning.  
c12_hin_a_cbse_08_005: Foundational Class 11 introduction to character roles (flat/round, symbolic) in Hindi poetry.  
c12_hin_a_cbse_10_005: Class 11 foundation in supporting character analysis techniques (trait identification, textual evidence, functional role).  
c12_hin_a_cbse_12_005: अगला तार्किक चरण: Supporting character analysis examines how secondary characters in a narrative — through their disti... इस नोड की अवधारणाओं को सीधे उपयोग/विस्तारित करता है।  
c12_hin_a_cbse_17_005: Class 11 Antra Chapter 1 established the methodology for supporting character analysis (traits, evidence, function).  
c12_hin_al_cbse_01_005: Introduces the framework for analyzing supporting characters (traits, functions, relationships) at Class 11 level.  
c12_hin_al_cbse_02_005: Class 11 introduced the concept of "character function" (foil, chorus, symbol); this node applies it at a higher analytical depth.  
c12_hin_ar_cbse_01_005: Class 11 Supporting Characters node established the taxonomy (foil, witness, symbol) used here.  
c12_hin_ar_cbse_02_005: Class 11 foundation on supporting character analysis in poetry (e.g., in "A Photograph" or "The Laburnum Top") — transfers the skill of identifying personified elements.  
c12_hin_ar_cbse_06_005: Class 11 foundation on supporting character analysis in Aroh.  
c12_hin_ar_cbse_14_005: Foundational character analysis vocabulary (traits, motivation, textual evidence).  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
None available from prior class nodes.

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_01_004 -> c11_hin_ar_cbse_01_005 -> c11_hin_ar_cbse_01_006

## THIS_FORMULA
N/A - conceptual

## FORMULA_VARIABLES
N/A

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
analytical

## CROSS_SUBJECT
c11_history_colonialism | The story's depiction of government service (नौकरी) as the only respectable path for educated Indians reflects colonial-era employment structures; लालाजी's moneylending mirrors colonial rural indebtedness.
c11_sociology_social_change | The tension between आइंस्टाइन's modern scientific rationality and पंडितजी's traditional authority illustrates the "tradition vs modernity" dialectic central to sociological studies of Indian social change.

## PREREQ_CONCEPT
Protagonist's central conflict (scientific idealism vs material survival) and the story's three-act structure (departure, struggle, ambiguous return).

## PREREQ_BEFORE
Student must have completed a written character sketch of आइंस्टाइन identifying his two dominant traits (obsessive curiosity, emotional detachment) and the story's turning points.

## PREREQ_STUCK
Re-read the protagonist analysis node (c11_hin_ar_cbse_01_004) and the plot structure node (c11_hin_ar_cbse_01_002), focusing on the "conflict" and "climax" sections.

## WORKED_EXAMPLE_1
PROBLEM: Analyze how ओखलाल functions as a foil to आइंस्टाइन in the first half of the story (up to आइंस्टाइन's departure for the city). Use the PEEL structure (Point, Evidence, Explanation, Link).
STEPS:
- Step 1: Identify the core contrast – ओखलाल chooses secure government service; आइंस्टाइन rejects it for uncertain research.
- Step 2: Locate Evidence 1 – Dialogue where ओखलाल says "भाई, संसार में रहकर संसार की रीति पर चलना पड़ता है" (Chapter 2, after job offer).
- Step 3: Locate Evidence 2 – Narrative description: "ओखलाल ने नौकरी कर ली... आइंस्टाइन ने टेलिस्कोप खरीद लिया" (parallel actions showing divergent values).
- Step 4: Explanation – ओखलाल's pragmatism makes आइंस्टाइन's idealism visible; without ओखलाल's "normal" choice, आइंस्टाइन's "abnormal" choice lacks definition.
- Step 5: Link to theme – This foil establishes the story's central tension: individual genius vs collective security.
REASONING: The PEEL structure forces textual grounding (Evidence) before interpretation (Explanation) and thematic connection (Link), meeting board exam expectations for analytical writing.
ANSWER: ओखलाल serves as a pragmatic foil who crystallizes आइंस्टाइन's radical idealism. When ओखलाल accepts the government post arguing "संसार की रीति पर चलना पड़ता है", his conformity throws आइंस्टाइन's telescope purchase into sharp relief – one buys social insurance, the other buys a tool for cosmic inquiry. This binary structures the first act: every scene of ओखलाल's domestic comfort (wife, children, steady income) is intercut with आइंस्टाइन's leaky roof and borrowed books. Thematically, ओखलाल represents the "colonized subject who succeeds by accommodation"; his presence makes आइंस्टाइन's refusal a political act, not merely personal eccentricity.

## WORKED_EXAMPLE_2
PROBLEM: Compare the narrative functions of फिरोज़ and मिर्ज़ा in the middle section (आइंस्टाइन's city years). How does each represent a different form of "support"?
STEPS:
- Step 1: Define "support" in this context – material/emotional sustenance vs intellectual challenge.
- Step 2: Map फिरोज़'s actions – sells watch, writes letters, nurses during illness, never questions the goal.
- Step 3: Map मिर्ज़ा's actions – calculates orbital mechanics, points out mathematical errors, refuses to fund "impossible" phase.
- Step 4: Contrast – फिरोज़ = unconditional loyalty (heart); मिर्ज़ा = conditional rationality (mind).
- Step 5: Synthesize – आइंस्टाइन needs both: फिरोज़ keeps him alive; मिर्ज़ा keeps him honest. The story suggests genius requires both devotion and critique.
REASONING: This comparison moves beyond "character traits" to "narrative function", showing how Premchand uses supporting characters as dialectical components of the protagonist's journey.
ANSWER: फिरोज़ and मिर्ज़ा form a dialectical pair: फिरोज़ provides the emotional substrate (he sells his watch saying "तुम्हारे काम के लिये मैं सब कुछ दे सकता हूँ", nurses him through fever), enabling आइंस्टाइन's physical survival. मिर्ज़ा provides the intellectual scaffold (he corrects आइंस्टाइन's calculations, demands "सबूत" before investing), ensuring the pursuit remains scientific, not delusional. Crucially, मिर्ज़ा's skepticism ("यह असंभव है") is more valuable to the plot than फिरोज़'s blind faith, because it forces आइंस्टाइन to refine his method. Together they represent the dual necessity of "faith to begin" and "rigor to continue" – a nuanced view of scientific temperament.

## WORKED_EXAMPLE_3
PROBLEM: The story's ending shows आइंस्टाइन returning to his village, honored but isolated. Explain how the collective reaction of three supporting characters (लालाजी, पंडितजी, ओखलाल) in the final scene encapsulates the story's critique of Indian society's relationship with genius.
STEPS:
- Step 1: Recall final scene – आइंस्टाइन honored at a public function; villagers gather.
- Step 2: Analyze लालाजी's reaction – offers loan at zero interest now ("अब तो आप बड़े आदमी हैं"), showing opportunistic respect for status, not intellect.
- Step 3: Analyze पंडितजी's reaction – performs special puja for "ग्रह शांति", co-opting the scientist into ritual framework, neutralizing his disruptive rationality.
- Step 4: Analyze ओखलाल's reaction – touches feet tearfully but whispers "घर कब आओगे? अम्माँ राह देखती हैं", reducing the cosmic achiever to a dutiful son.
- Step 5: Synthesize – All three domesticate the genius: लालaji commodifies him, पंडितजी ritualizes him, ओखलाल familializes him. None engages his actual work.
- Step 6: Connect to theme – Society celebrates the *outcome* (fame) while ignoring the *process* (obsessive, lonely, rule-breaking), revealing a culture that consumes genius but cannot nurture it.
REASONING: This multi-character synthesis demonstrates the highest-order analysis: seeing supporting characters not as individuals but as a chorus voicing societal forces, a skill required for 6-mark board questions.
ANSWER: In the culminating public reception, Premchand stages a devastating chorus. लालाजी's instant offer of interest-free credit ("ब्याज नहीं लूँगा") exposes how capitalism neutralizes rebellion by commodifying the rebel. पंडितजी's "शांति पाठ" for planetary peace ritualistically domesticates the very science that threatened orthodoxy. ओखलाल's tearful "अम्माँ राह देखती हैं" pulls the star-chaser back into the gravitational field of filial duty. Not one asks about the telescope's findings or the theory's implications. The supporting characters collectively enact society's strategy: honor the symbol, ignore the substance. This is the story's sharpest satire – the village that once mocked the "madman" now claims him, but only after stripping his achievement of its threatening novelty.

## COMPETENCY_QUESTION_1
QUESTION: "In 'उद्देश्य नक्षत्र', supporting characters are not merely helpers or obstacles; they are the measuring rods of the protagonist's greatness." Evaluate this statement by analyzing the roles of ANY TWO supporting characters. Your answer must include: (a) a clear thesis, (b) two textual evidences per character, (c) explanation of how each character 'measures' a specific aspect of आइंस्टाइन, (d) a concluding synthesis.
COMPETENCY: Analytical writing with textual evidence and thematic synthesis
STEPS:
- Step 1: Formulate thesis – e.g., "Supporting characters quantify the cost and nature of आइंस्टाइन's genius by embodying the alternatives he rejects."
- Step 2: Select two characters (e.g., ओखलाल and मिर्ज़ा) and for each, choose two precise textual moments (dialogue/action).
- Step 3: For each evidence, explain what dimension of आइंस्टाइन it measures (e.g., ओखलाल measures his detachment from domestic life; मिर्ज़ा measures his intellectual rigor).
- Step 4: Synthesize – show how the two measuring rods together create a multidimensional portrait.
ANSWER: Thesis: Supporting characters act as calibrated instruments that reveal the magnitude and quality of आइंस्टाइन's pursuit by representing the norms he transcends. For ओखलाल: (1) When ओखलाल shows his appointment letter saying "अब मैं भी अफसर हूँ", it measures आइंस्टाइन's willingness to forfeit social legitimacy. (2) When ओखलाल visits the city and sees आइंस्टाइन's attic, his pity ("तुमने अपना जीवन बरबाद कर दिया") measures the protagonist's voluntary poverty. For मिर्ज़ा: (1) His demand "पहले गणना दिखाओ" measures आइंस्टाइन's discipline – he must meet scientific standards, not just dream. (2) His final admission "तुमने कर दिखाया" measures the achievement's objective validity. Together, ओखलाल measures the *human cost* (family, comfort, reputation) and मिर्ज़ा measures the *intellectual standard* (proof, logic, peer validation). The protagonist's greatness lies in satisfying the harder measure (मिर्ज़ा's) while enduring the softer measure's (ओखलाल's) judgment.
DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: The story uses the supporting character नक्षत्र (the star) as a "silent character" who speaks through others' reactions. Design a 4-column analytical table with these headers: Character | Reaction to नक्षत्र | What the reaction reveals about the character | What the reaction reveals about the story's view of science. Fill it for four characters (ओखलाल, फिरोज़, मिर्ज़ा, लालाजी). Then write a 150-word paragraph arguing whether the star ultimately unites or divides the community.
COMPETENCY: Multi-modal analysis (tabular + prose) and evaluative argument
STEPS:
- Step 1: Create table with four rows, each column filled with textual inferences (e.g., ओखलाल | calls it "भ्रम" | reveals his materialism | shows science as threat to practical life).
- Step 2: Ensure each cell uses story-specific language, not generic terms.
- Step 3: Write paragraph with clear stance (e.g., "The star divides because..."), using table data as evidence.
- Step 4: Conclude with thematic implication for Indian modernity.
ANSWER: Table: ओखलाल | "यह तारा नहीं, तुम्हारा भ्रम है" | pragmatic, fears instability | science = dangerous fantasy; फिरोज़ | gazes silently, says "तुम्हारा तारा मिल जाये" | loyal, accepts mystery | science = object of faith; मिर्ज़ा | calculates distance, says "प्रकाशवर्षों दूर है" | rationalist, demands proof | science = measurable, bounded; लालाजी | ignores star, asks "इससे कमाई होगी?" | mercenary, reduces all to profit | science = commodity. Paragraph: The star ultimately divides the community because each character projects their own need onto it, creating incompatible realities. ओखलाल sees delusion, फिरोज़ sees devotion, मिर्ज़ा sees data, लालाजी sees irrelevance. No shared discourse emerges; the star becomes a mirror reflecting fragmented selves, not a telescope revealing common truth. This fragmentation mirrors colonial India's inability to forge a collective scientific temperament – science remains a private quest (आइंस्टाइन's) or a borrowed prestige (villagers' final honor), never a public culture. The story warns that without a community that *understands* the star, the discoverer returns to a village that honors the medal but ignores the cosmos.
DIFFICULTY: hard