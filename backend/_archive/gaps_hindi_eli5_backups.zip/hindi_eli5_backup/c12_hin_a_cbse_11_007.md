## DEFINITION
Secondary themes are the supporting ideas, motifs, or messages that run parallel to the primary theme in a literary work. They are explored through sub-plots, minor characters, recurring images, or specific episodes, and they add depth, complexity, and multiple layers of meaning to the text without overshadowing the central message.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student can independently identify at least two distinct secondary themes in Chapter 11, cite specific textual evidence (events, dialogues, descriptions) for each, and explain in writing how each secondary theme interacts with the primary theme of "education for personality development" to enrich the chapter's overall significance.

## SCOPE_BOUNDARY
This node covers the identification and analysis of secondary themes in the three stories of Chapter 11: "क्यद भागा" (The Boy Who Ran Away), "आँखों की गज़ल" (The Ghazal of Eyes), and "सीस पूँछ एक" (Head and Tail One). It does NOT cover the primary theme (node 006), literary devices like imagery or irony (nodes 008, 009), or direct comprehension questions (node 012).

## WALKTHROUGH
Imagine you are watching a Hindi film where the hero fights for justice (main plot), but you also notice a side story about his sister's struggle for education and a comic track about a corrupt clerk. Those side tracks are secondary themes — they support the main message by showing its impact on different lives. In this chapter, the primary theme is "education should develop the personality, not just stuff information." To find secondary themes, first recall the primary theme (node 006). Then, list the key episodes in each story: the boy's fear and the teacher's reflection in "क्यद भागा"; the philosophical musings on time and observation in "आँखों की गज़ल"; the coin-toss metaphor and life choices in "सीस पूँछ एक". Next, ask: "What other big ideas appear repeatedly?" For example, fear of authority, the nature of time, the illusion of free will. Finally, pick one, find 2-3 pieces of evidence, and write a PEEL paragraph (Point, Evidence, Explanation, Link to primary theme). The key insight: secondary themes are not just topics (like "school") but statements about those topics (like "authoritarian schooling crushes curiosity").

## DIAGNOSTIC_QUESTION_1
Define "secondary theme" in your own words and give one example from any story you have read previously.

## DIAGNOSTIC_ANSWER_1
A secondary theme is a supporting idea that complements the main theme, often explored through sub-plots or minor characters. Example: In Premchand's "बड़े भाई साहब", the primary theme is the value of experience over bookish knowledge; a secondary theme is the sibling bond that softens the moral lesson.  
**What a wrong answer reveals:** If the student gives a topic like "school" or "family" instead of a thematic statement (e.g., "the pressure of expectations"), they confuse topic with theme. If they cannot give an example, they lack practice in distinguishing primary vs. secondary themes.

## DIAGNOSTIC_QUESTION_2
In "क्यद भागा", the teacher thinks: "शिक्षा बालकों पर लादी नहीं जानी चाहिए, बल्कि उनके अंतःकरण में शिक्षा की भूख जगानी चाहिए।" Explain how this reflection reveals a secondary theme distinct from the primary theme of "education for personality development."

## DIAGNOSTIC_ANSWER_2
The teacher's reflection highlights the secondary theme of **"the psychological damage of coercive pedagogy"**. While the primary theme advocates *what* education should be (personality development), this secondary theme exposes *what happens when it fails*: fear kills curiosity, and the system creates robots, not thinkers. The evidence is the boy's flight and the teacher's guilt.  
**What a wrong answer reveals:** If the student merely repeats "education should not be forced," they are restating the primary theme. They miss the nuance: the secondary theme focuses on the *consequences* of bad methods on the child's psyche, not just the ideal method.

## DIAGNOSTIC_QUESTION_3
Read this new paragraph: "The headmaster checked the attendance register every morning. Latecomers stood on the bench, ears pulled, while the class watched in silence. No one asked why they were late." Identify one secondary theme this paragraph illustrates and write a two-sentence analysis using the PEEL structure.

## DIAGNOSTIC_ANSWER_3
**Secondary theme:** "Institutional power enforces conformity through public humiliation."  
**PEEL analysis:** (Point) The paragraph shows how school authority uses ritualized punishment to instill obedience. (Evidence) The headmaster's public ear-pulling and the class's forced silence are the evidence. (Explanation) This creates a culture of fear where questioning is impossible, directly opposing the primary theme's call for awakening inner hunger. (Link) Thus, the system itself becomes a barrier to true education.  
**What a wrong answer reveals:** If the student writes "punishment is bad" without linking to the systemic nature or the primary theme, they remain at a surface level. If they omit Evidence or Explanation, they haven't mastered the PEEL structure.

## DIAGNOSTIC_QUESTION_4
Compare the secondary theme of "time" in "आँखों की गज़ल" with the secondary theme of "choice" in "सीस पूँछ एक". How do both themes use a metaphor to question human agency?

## DIAGNOSTIC_ANSWER_4
In "आँखों की गज़ल", time is metaphorized as an ever-watchful eye ("आँखों की गज़ल") that records every moment, suggesting humans are observed but cannot control time's flow. In "सीस पूँछ एक", the coin toss ("सीस पूँछ") metaphorizes life's choices as a 50-50 gamble, implying agency is an illusion because outcomes are arbitrary. Both metaphors reduce human agency: one to a passive witness, the other to a gambler. Yet, the first urges conscious observation ("देखना"), while the second mocks the search for meaning. Together, they deepen the primary theme by showing that *education must equip the mind to navigate a world where time is indifferent and choices are uncertain*.  
**What a wrong answer reveals:** If the student only lists metaphors without comparing their philosophical implications, they miss the analytical demand. If they treat the two stories as unrelated, they fail to see the chapter's structural unity.

## DIAGNOSTIC_QUESTION_5
Critique the view that the secondary theme of "fear" in "क्यद भागा" is more effectively conveyed than the secondary theme of "fatalism" in "सीस पूँछ एक". Support your judgment with two textual reasons.

## DIAGNOSTIC_ANSWER_5
**Judgment:** The theme of fear is more effectively conveyed because it is grounded in a concrete, relatable narrative arc (a child's panic, a teacher's remorse), whereas fatalism in "सीस पूँछ एक" is presented through an abstract allegory (coin toss, philosophical dialogue) that distances the reader emotionally.  
**Reason 1:** "क्यद भागा" uses sensory details — the boy's sweating palms, the teacher's "फटकार", the father's "आन" — to make fear visceral.  
**Reason 2:** "सीस पूँछ एक" relies on a folk-tale frame ("लुक्र्द फो|क") and generalized statements ("विक्ट डक्चज") that lack a specific character's lived experience.  
**What a wrong answer reveals:** If the student simply prefers one story subjectively ("I liked the first story more"), they are not evaluating *literary effectiveness*. If they cannot cite specific textual strategies (sensory detail vs. allegory), they lack analytical vocabulary.

## DIAGNOSTIC_QUESTION_6
Write a 100-word scene (original, not from the textbook) that dramatizes the secondary theme "the gap between institutional rhetoric and lived reality" using a school setting. Include one metaphor.

## DIAGNOSTIC_ANSWER_6
**Sample scene:** The principal's banner read "Holistic Development" in marigold letters. Inside, Class 12B memorized physics derivations for the third hour. Rahul raised his hand: "Sir, why does the electron not fall into the nucleus?" The teacher glanced at the clock: "That's not in the syllabus. Write the derivation five times." The banner fluttered, a paper kite tied to a brick.  
**Criteria for a good answer:** (1) Clear institutional rhetoric (banner/slogan), (2) Contrasting lived reality (rote learning, suppressed curiosity), (3) One metaphor (banner as kite tied to brick = rhetoric grounded by rigid system), (4) Within word limit.  
**What a poor answer reveals:** If the scene only describes a strict teacher without the rhetoric-reality gap, the theme is missing. If no metaphor is used, the student hasn't applied the concept of metaphorical representation of theme.

## COMMON_MISCONCEPTION
Students often treat **topics** as themes. For example, they write "The secondary theme is *school*" or "*time*" instead of "The secondary theme is *the dehumanizing effect of ritualized schooling*" or "*the indifference of time to human aspirations*." This happens because they stop at the noun (the subject) and do not articulate the *author's perspective* on that subject. Another error is listing a secondary theme without anchoring it in a specific story episode, leading to vague generalizations like "fear is bad." The NCERT marking scheme requires textual evidence tied to a clear thematic statement.

## ON_FAILURE
1. **Revisit Node 006 (Primary Theme):** Reread the primary theme analysis. Write one sentence distinguishing primary vs. secondary theme using the analogy: "Primary theme = the trunk of the tree; secondary themes = branches."  
2. **Re-read the Three Stories with a "Theme Hunt" Lens:** For each story, fill a 3-column table: *Episode/Detail* | *Topic* | *Thematic Statement (Author's View)*. Example: "Boy runs away" | Fear | "Fear paralyzes the learning instinct."  
3. **Practice Topic-to-Theme Conversion:** Take five nouns from the chapter (school, time, coin, eye, banner) and convert each into a thematic statement. Check with a peer/teacher.  
4. **Re-attempt Diagnostic Question 2** using the table from Step 2. If still stuck, review Class 11 node **c11_hin_ar_cbse_11_007** (Theme: Secondary Themes) for the same skill at a lower complexity.

## BUILDS_ON
This node builds on the ability to identify the primary theme (c12_hin_a_cbse_11_006) and analyze characters' inner conflicts (c12_hin_a_cbse_11_004, c12_hin_a_cbse_11_005).

## LEADS_TO
This node enables the analysis of how literary devices (imagery, irony, symbolism) embody secondary themes (c12_hin_a_cbse_11_008, c12_hin_a_cbse_11_009) and supports critical interpretation (c12_hin_a_cbse_11_013).

## PREREQUISITE_NODE_IDS
c12_hin_a_cbse_11_006, c12_hin_a_cbse_11_004, c12_hin_a_cbse_11_005, c11_hin_ar_cbse_11_007, c12_hin_a_cbse_11_002
## PREREQUISITE_REASONS
c12_hin_a_cbse_11_006: Primary theme must be known to distinguish secondary themes from it.  
c12_hin_a_cbse_11_004: Protagonist's actions/reactions (e.g., the boy's fear) are primary evidence for secondary themes.  
c12_hin_a_cbse_11_005: Supporting characters (teacher, father, narrator in other stories) voice or embody secondary themes.  
c11_hin_ar_cbse_11_007: Class 11 introduced secondary theme identification; this node deepens it with more complex texts.  
c12_hin_a_cbse_11_002: Plot structure knowledge helps locate where secondary themes emerge (e.g., climax, resolution).

## FORWARD_NODE_IDS
c12_hin_a_cbse_11_008, c12_hin_a_cbse_11_009, c12_hin_a_cbse_11_013, c12_hin_a_cbse_11_012, c12_hin_a_cbse_11_014, c12_hin_a_cbse_11_015

## FORWARD_REASONS
c12_hin_a_cbse_11_008: Imagery and metaphor are the main vehicles for secondary themes (e.g., "आँखों की गज़ल", "सीस पूँछ").  
c12_hin_a_cbse_11_009: Irony and symbolism often highlight the gap between primary and secondary themes (e.g., the "Holistic Development" banner).  
c12_hin_a_cbse_11_013: Critical thinking requires synthesizing primary and secondary themes into a coherent interpretation.
c12_hin_a_cbse_11_012: Secondary themes add layers for inferential depth.  
c12_hin_a_cbse_11_014: Gives secondary themes (time, tradition, social hypocrisy) for nuanced Points.  
c12_hin_a_cbse_11_015: Secondary themes allow nuanced, multi‑angle contributions.  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
N/A

## CHAIN_DESCRIPTION
c12_hin_a_cbse_11_006 -> c12_hin_a_cbse_11_007 -> c12_hin_a_cbse_11_008

## THIS_FORMULA
N/A - conceptual

## FORMULA_VARIABLES
N/A

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
analytical

## CROSS_SUBJECT
N/A | The story "क्यद भागा" reflects colonial-era schooling methods (rote learning, corporal punishment), linking to History themes of colonial education policy and its psychological impact.  
 N/A | The dynamics of the teacher's authority and the child's fear connect to Psychology concepts of obedience, authoritarian personality, and the effect of stress on learning (Yerkes-Dodson law).
## PREREQ_CONCEPT
Distinguishing a *topic* (noun) from a *theme* (complete sentence expressing the author's insight about that topic).

## PREREQ_BEFORE
The student must have read all three stories in Chapter 11 and completed the primary theme analysis (node 006).

## PREREQ_STUCK
If stuck on topic vs. theme, review the "Theme vs. Topic" exercise in Class 11 node **c11_hin_ar_cbse_11_007** (Theme: Secondary Themes).

## WORKED_EXAMPLE_1
**PROBLEM:** Identify and analyze the secondary theme of "fear as a barrier to authentic learning" in the story "क्यद भागा" using the PEEL structure.

**STEPS:**
- Step 1: Recall the primary theme (education for personality development) and list key episodes in "क्यद भागा": the boy's incorrect answer, the teacher's sarcasm, the boy's flight, the teacher's night-time reflection.
- Step 2: Select the episode where the teacher thinks, "मेरा फटकारना ही तो उसे भगा ले गया" (my scolding drove him away). This shows the teacher realizing his method created fear.
- Step 3: Formulate the thematic statement: "Authoritarian teaching methods generate fear that shuts down the learner's mind."
- Step 4: Gather evidence: (a) The boy's physical reaction — "पसीने से तर", "काँपता हुआ"; (b) The teacher's admission — "मैंने उसे डाँटा था"; (c) The father's pride in "आन" (honour) that prevents the boy from returning.
- Step 5: Write the PEEL paragraph linking to primary theme: The fear instilled by the system (Point) is evidenced by the boy's visceral panic and the teacher's guilt (Evidence). This fear makes the child flee the very space meant for growth (Explanation). Therefore, unless education removes fear, it cannot develop personality (Link).

**REASONING:** The steps move from textual details to abstract theme, ensuring evidence drives the claim. The link to primary theme shows the hierarchical relationship required in board answers.

**ANSWER:**  
**Secondary Theme:** Fear as a barrier to authentic learning.  
**PEEL Paragraph:** The story "क्यद भागा" exposes how authoritarian pedagogy uses fear as a tool, which ultimately paralyzes the learning instinct. When the teacher scolds the boy for a wrong answer, the boy's body reacts with "पसीने से तर" and trembling — fear manifests physically, shutting down cognition. The teacher later realizes, "मेरा फटकारना ही तो उसे भगा ले गया," admitting his method caused the flight. Even the father's misplaced "आन" (honour) prioritizes social image over the child's psychological safety. Thus, the system that should awaken "शिक्षा की भूख" instead plants terror, proving that personality development is impossible in a climate of fear.

## WORKED_EXAMPLE_2
**PROBLEM:** Analyze how the secondary theme "time as an indifferent witness" is developed through the metaphor of "आँखों की गज़ल" in the second story.

**STEPS:**
- Step 1: Identify the central metaphor: "आँखों की गज़ल" (the ghazal of eyes) — eyes that see, record, but do not intervene.
- Step 2: Trace the metaphor across the story: (a) The narrator describes eyes watching history ("बाबर की आँखें", "गाँधी की आँखें"); (b) The eyes see both joy and sorrow without bias; (c) The closing lines urge the reader to "देखो" (watch) consciously.
- Step 3: Formulate the thematic statement: "Time, like a silent gaze, records human deeds without judgment, making conscious observation our only agency."
- Step 4: Connect to primary theme: Education should cultivate this conscious observation ("देखने की तमीज़") so we don't drift passively.
- Step 5: Write an analytical paragraph using the structure: Metaphor → Expansion → Thematic Statement → Link to Primary Theme.

**REASONING:** The metaphor is the core literary device carrying the secondary theme. Analyzing its expansion across the text shows how the author builds the theme structurally, not just decoratively.

**ANSWER:**  
The metaphor "आँखों की गज़ल" personifies time as a perpetual, impartial witness. The narrator lists historical moments — "बाबर की आँखें", "गाँधी की आँखें" — showing that the same gaze records conquest and sacrifice alike. This indifference is stressed when the text says eyes "न मुस्कुराती हैं, न रोती हैं" (neither smile nor weep). The thematic statement emerges: **Time is an indifferent witness; human agency lies only in choosing what we observe and how we interpret it.** This directly serves the primary theme: true education must teach "देखने की तमीज़" (the art of seeing) so that students become conscious observers of their world, not passive victims of time's flow. The metaphor thus transforms a philosophical abstraction into a pedagogical imperative.

## WORKED_EXAMPLE_3
**PROBLEM:** Compare the secondary themes of "illusion of choice" in "सीस पूँछ एक" and "fear of authority" in "क्यद भागा". Show how both themes critique the *structure* of the education system, not just individual actors.

**STEPS:**
- Step 1: Identify the secondary theme in "सीस पूँछ एक": Life's choices are like a coin toss ("सीस पूँछ") — arbitrary, binary, and ultimately meaningless because the outcome is predetermined by forces beyond control.
- Step 2: Identify the secondary theme in "क्यद भागा": The school structure (teacher's power, father's honour, syllabus rigidity) creates a fear-based compliance that mimics choice (answer correctly or be punished) but offers no real agency.
- Step 3: Find structural parallels: (a) Both use a binary trap — right/wrong answer in class, head/tail in coin toss. (b) Both show authority figures (teacher, "नियति"/fate) who set the rules. (c) Both depict the individual (boy, narrator) as trapped within the structure.
- Step 4: Synthesize: The education system mirrors the fatalistic universe of "सीस पूँछ एक" — it presents pseudo-choices (memorize this or fail) while the real curriculum (critical thinking, courage) is excluded.
- Step 5: Write a comparative analysis paragraph using a point-by-point structure.

**REASONING:** This example combines two stories (synthesis) and moves from thematic identification to structural critique, a high-level skill needed for competency-based board questions and CUET-style analysis.

**ANSWER:**  
Both stories reveal that the *structure* of the system — whether school or fate — denies genuine agency. In "क्यद भागा", the boy faces a pseudo-choice: give the "correct" answer or face humiliation. The teacher's question has one right answer; the system allows no exploration. In "सीस पूँछ एक", the coin toss offers a 50-50 choice, but the narrator realizes "सीस पूँछ एक" — head and tail are two faces of the same coin, i.e., the outcome is fixed regardless of the call. The structural parallel: **the system defines the rules, the options, and the consequences, leaving the individual only the illusion of participation.** The teacher represents the curriculum's rigidity; the coin represents fate's indifference. True education (primary theme) would break this structure by teaching the child to question the coin itself — "Why only two sides? Who minted it?" — turning a victim of structure into its critic.

## COMPETENCY_QUESTION_1
**QUESTION:** The chapter uses three distinct narrative voices — a third-person realist narrator in "क्यद भागा", a philosophical first-person in "आँखों की गज़ल", and a folk-tale storyteller in "सीस पूँछ एक". Analyze how these narrative strategies serve the secondary themes of *fear*, *time*, and *fatalism* respectively. Write a structured response with one paragraph per story.

**COMPETENCY:** Critical Thinking & Textual Analysis

**STEPS:**
- Step 1: For each story, name the narrative voice and its key features (e.g., third-person limited, reflective first-person, oral folk style).
- Step 2: Link the voice to the secondary theme: How does the voice *enact* the theme? (e.g., third-person distance in "क्यद भागा" mirrors the institution's cold gaze; first-person intimacy in "आँखों की गज़ल" mimics the act of witnessing; folk-tale frame in "सीस पूँछ एक" universalizes fatalism).
- Step 3: Write three PEEL paragraphs, each connecting voice → theme → primary theme.
- Step 4: Conclude with a synthesis sentence on why the author varied the voices.

**ANSWER:**  
In "क्यद भागा", the third-person limited narrator stays close to the boy's panic and the teacher's guilt but maintains an observational distance, mirroring how the school system *watches* without *feeling*. This narrative coldness enacts the secondary theme of **institutional fear** — the system sees the child but does not understand him. The primary theme demands empathy; the narrative voice shows its absence.  

In "आँखों की गज़ल", the first-person reflective voice ("मैंने देखा", "मैं सोचता हूँ") performs the very act of conscious observation that the secondary theme **time as witness** advocates. The narrator *becomes* the watching eye, modeling the "देखने की तमीज़" that education should cultivate. The voice and theme fuse: to read is to witness.  

In "सीस पूँछ एक", the folk-tale frame ("लुक्र्द फो|क", "एक बार की बात है") and the generic "नैरेटर" universalize the secondary theme of **fatalism**. By using a timeless storytelling mode, the author suggests that the illusion of choice is not a modern problem but a human condition. The primary theme's call for critical education gains urgency: only conscious learning can break ancient fatalistic patterns.  

**Synthesis:** The three voices form a triad — the system's gaze, the individual's gaze, and the collective gaze — together arguing that education must transform passive seeing into critical vision.

**DIFFICULTY:** medium

## COMPETENCY_QUESTION_2
**QUESTION:** "The secondary themes in this chapter are not decorative; they are the *evidence* for the primary theme's argument." Evaluate this statement by selecting any two secondary themes and showing how each strengthens the case for "education for personality development." Your answer must include: (a) the thematic statement, (b) the structural role it plays (contrast, illustration, extension), and (c) a counter-perspective the text itself anticipates.

**COMPETENCY:** Argumentative Writing & Literary Evaluation

**STEPS:**
- Step 1: Choose two secondary themes (e.g., "fear as barrier" and "illusion of choice").
- Step 2: For each, write the thematic statement in one sentence.
- Step 3: Identify its structural role: Does it *contrast* with the ideal (fear vs. hunger), *illustrate* the ideal's absence (coin toss as current pedagogy), or *extend* the ideal to a broader domain (time as lifelong learning)?
- Step 4: Find a counter-perspective in the text: e.g., the father's "आन" justifies fear as discipline; the folk tale's acceptance of fate ("जो लिखा है सो होगा").
- Step 5: Write an evaluative essay of 200-250 words with clear thesis, two body paragraphs, and a conclusion.

**ANSWER:**  
**Thesis:** The secondary themes function as the *negative proof* of the primary theme — they demonstrate what happens when education fails its purpose, thereby making the primary theme's positive vision necessary and urgent.  

**Body 1 (Fear as Barrier):**  
*Thematic statement:* Authoritarian pedagogy instills fear that paralyzes the learning instinct.  
*Structural role:* **Contrast.** The boy's terror ("काँपता हुआ") stands in direct opposition to the primary theme's "शिक्षा की भूख" (hunger for education). The text juxtaposes the teacher's sarcasm with his later guilt to show that fear produces flight, not growth.  
*Counter-perspective:* The father's "आन" (honour) frames fear as necessary discipline — "डरोगे नहीं तो पढ़ोगे कैसे?" The text anticipates this by showing the father's pride ultimately fails: the boy does not return. The system's own logic collapses.  

**Body 2 (Illusion of Choice):**  
*Thematic statement:* The education system offers pseudo-choices (rote answers, exam streams) while real agency (critical thinking, dissent) is excluded.  
*Structural role:* **Illustration.** The coin-toss allegory ("सीस पूँछ एक") illustrates the classroom: the student "calls" head or tail (chooses science/commerce), but the coin is minted by the board/syllabus — the outcome is predetermined. The narrator's realization that "सीस पूँछ एक" mirrors the student's realization that stream choice doesn't change the rote method.  
*Counter-perspective:* The folk tale's fatalistic voice ("नियति के आगे किसकी चली") suggests resistance is futile. The text counters this by ending with a call to "देखो" (observe/question) — implying that *awareness* of the rigged game is the first move toward changing it.  

**Conclusion:** Both secondary themes expose the *mechanisms* (fear, false choice) that the primary theme seeks to dismantle. They are not ornamental; they are the diagnostic X-rays that justify the cure.

**DIFFICULTY:** hard