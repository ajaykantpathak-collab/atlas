## DEFINITION
Imagery is the use of vivid and descriptive language that appeals to the senses (sight, sound, smell, touch, taste) to create mental pictures and evoke sensory experiences. Metaphor is a figure of speech that directly compares two unrelated things by stating one is the other, without using "like" or "as", to suggest a resemblance and convey deeper meaning.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student can identify specific images and metaphors in the text, explain how they appeal to senses, and analyze how they reinforce themes of caste oppression, childhood innocence, and social hypocrisy in "xyrk yksgk".

## SCOPE_BOUNDARY
This node covers identification, interpretation, and analysis of imagery and metaphor in the story "xyrk yksgk" only. It does not cover other literary devices like irony, symbolism, or simile (which are in sibling nodes), nor does it teach general definitions without textual application.

## WALKTHROUGH
Imagine you are watching a movie scene where a child sits on a dusty floor, the smell of cow dung cakes burning, the sound of a distant temple bell, and the harsh voice of a teacher scolding. In "xyrk yksgk", Shivani uses words to paint such sensory scenes. To begin, pick a paragraph (e.g., the opening description of Eksgu's home) and underline every word that makes you see, hear, smell, or feel something. Then ask: why did the author choose these specific images? What do they reveal about Eksgu's world? Next, find a metaphor (e.g., "eksgu dh vk¡[kksa esa ,d ltZd dh ped Fkh" – a lamp's flame in her eyes) and unpack the comparison: what is being compared to what, and what does it suggest about her inner state? The key insight is that imagery builds the physical reality of caste poverty, while metaphor exposes the psychological reality of internalized oppression.

## DIAGNOSTIC_QUESTION_1
Define imagery and metaphor in your own words, giving one example of each from daily life (not from the textbook).

## DIAGNOSTIC_ANSWER_1
Imagery is language that creates sensory impressions (e.g., "the sizzle of frying pakoras" appeals to sound and smell). Metaphor is a direct comparison without 'like' or 'as' (e.g., "time is a thief"). A wrong answer that confuses metaphor with simile (using 'like'/'as') or thinks imagery is only visual reveals the student hasn't grasped the sensory breadth of imagery or the structural difference between metaphor and simile.

## DIAGNOSTIC_QUESTION_2
In the opening paragraph of "xyrk yksgk", the author describes Eksgu's home with "fugkbZ ij j[ks yky xeZ yksgs ij iM+rh gFkkSM+s dh èki~&èki~ vkok”k] BaMs yksgs ij yxrh pksV ls mBrk Budrk Loj". Identify the sensory images here and explain what atmosphere they create.

## DIAGNOSTIC_ANSWER_2
The images are auditory (crackling fire), visual (smoke on bamboo, dim lamp), and tactile (darkness). They create a suffocating, impoverished atmosphere. A wrong answer that only lists "visual imagery" misses the multi-sensory layering that conveys the family's marginalization.

## DIAGNOSTIC_QUESTION_3
Find a metaphor in the passage where Thakur Phoolchand's wife says, "eksgu ugha vk;k vkt". Explain what two things are being compared and what the metaphor suggests about her attitude toward Eksgu.

## DIAGNOSTIC_ANSWER_3
The metaphor is implicit: Eksgu is treated as an object/possession ("vkt" – came) rather than a person. The comparison is between a human being and a commodity that can be summoned. A wrong answer that takes the sentence literally misses the dehumanizing metaphor embedded in the casual phrasing.

## DIAGNOSTIC_QUESTION_4
Compare the imagery used to describe Eksgu's morning routine (lighting fire, cooking) with the imagery used for the Thakur family's morning (teacher scolding students, priest chanting). What does the contrast reveal about social hierarchy?

## DIAGNOSTIC_ANSWER_4
Eksgu's routine uses tactile, olfactory, auditory images of labor (cow dung, smoke, heavy grinding stone), while the Thakur routine uses images of authority (voice, chanting, scolding). The contrast shows labor vs. leisure, impurity vs. ritual purity. A wrong answer that only notes "different activities" fails to analyze how sensory details encode caste hierarchy.

## DIAGNOSTIC_QUESTION_5
Evaluate the effectiveness of the metaphor "eksgu dh vk¡[kksa esa ,d ltZd dh ped Fkh" (a lamp's flame in Eksgu's eyes) in conveying her resilience versus her vulnerability. Support your judgment with textual evidence.

## DIAGNOSTIC_ANSWER_5
The metaphor is effective because a lamp's flame is both fragile (easily extinguished) and persistent (gives light in darkness). It captures Eksgu's quiet endurance amid oppression. A wrong answer that calls it "just a description of shiny eyes" misses the symbolic duality and the author's intent to show inner strength.

## DIAGNOSTIC_QUESTION_6
Write a short paragraph (5-6 lines) describing a childhood memory using at least three types of imagery and one original metaphor that reveals an emotion (fear, joy, shame, etc.). Do not name the emotion directly.

## DIAGNOSTIC_ANSWER_6
A good answer will include visual, auditory, tactile, etc., images and a metaphor like "my heart was a trapped bird" for fear. A poor answer will list images without a metaphor or name the emotion outright, showing inability to use metaphor for indirect emotional expression.

## COMMON_MISCONCEPTION
Students often think imagery is only "visual description" and metaphor is only "poetic decoration". In "xyrk yksgk", they miss how olfactory imagery (cow dung, smoke) and tactile imagery (rough grinding stone) convey caste-based occupational stigma, and how metaphors like "ltZd dh ped" (lamp's flame) are not decorative but reveal the psychological internalization of inferiority. They also confuse metaphor with simile, missing that Shivani's metaphors are often implicit (e.g., treating a person as an object) rather than explicit "A is B" statements.

## ON_FAILURE
1. Have the student close their eyes and describe their kitchen at breakfast using all five senses; then map each sense to a line in the story's opening. 2. Give them two columns: "Literal statement" and "Metaphorical implication". Practice converting "Eksgu is poor" into metaphorical images from the text. 3. Use a think-aloud: read a paragraph aloud, pausing at each sensory word, and ask "What does this make me feel?" to build the habit of sensory analysis.

## BUILDS_ON
Understanding of basic literary terms (simile, personification) from Class 10 and the plot/character/context of "xyrk yksgk" from earlier nodes in this chapter.

## LEADS_TO
Analysis of irony and symbolism (next node) and critical interpretation of the story's social commentary (later nodes).

## PREREQUISITE_NODE_IDS
c11_hin_ar_cbse_05_001, c11_hin_ar_cbse_05_002, c11_hin_ar_cbse_05_003, c11_hin_ar_cbse_05_004, c11_hin_ar_cbse_05_005, c11_hin_ar_cbse_05_006, c11_hin_ar_cbse_05_007
## PREREQUISITE_REASONS
c11_hin_ar_cbse_05_001: Provides historical/caste context essential to decode imagery of poverty and ritual.
c11_hin_ar_cbse_05_002: Plot knowledge needed to locate where specific images appear in the narrative arc.
c11_hin_ar_cbse_05_003: Setting and atmosphere node establishes the physical world that imagery builds.
c11_hin_ar_cbse_05_004: Protagonist analysis helps link imagery/metaphor to Eksgu's characterization.
c11_hin_ar_cbse_05_005: Supporting characters' perspectives (Thakur family) are often conveyed through metaphorical language.
c11_hin_ar_cbse_05_006: Primary theme (caste oppression) is reinforced by imagery/metaphor patterns.
c11_hin_ar_cbse_05_007: Secondary themes (childhood, gender, education) are illuminated by specific sensory details.

## FORWARD_NODE_IDS
c11_hin_ar_cbse_05_009, c11_hin_ar_cbse_05_010, c11_hin_ar_cbse_05_011, c11_hin_ar_cbse_05_012, c11_hin_ar_cbse_05_013, c11_hin_ar_cbse_05_014, c11_hin_ar_cbse_05_015, c12_hin_a_cbse_04_008, c12_hin_a_cbse_05_003, c12_hin_a_cbse_05_008, c12_hin_a_cbse_16_008, c12_hin_ar_cbse_05_001, c12_hin_ar_cbse_05_008, c12_hin_ar_cbse_05_003

## FORWARD_REASONS
c11_hin_ar_cbse_05_009: Irony and symbolism build on metaphorical thinking; imagery often carries symbolic weight.
c11_hin_ar_cbse_05_010: Vocabulary in context requires understanding metaphorical usage of words (e.g., "ltZd", "ped").
c11_hin_ar_cbse_05_011: Grammar node examines how syntactic structures create imagery (e.g., participial phrases for simultaneous actions).
c11_hin_ar_cbse_05_012: Comprehension questions often ask for effect of imagery/metaphor.
c11_hin_ar_cbse_05_013: Critical thinking depends on ability to analyze literary devices as evidence.
c11_hin_ar_cbse_05_014: Writing skills (analytical paragraph) require quoting and explaining imagery/metaphor.
c11_hin_ar_cbse_05_015: Discussion points often center on how sensory language shapes reader empathy.
c12_hin_a_cbse_04_008: Work with kinesthetic imagery in folk-style poems — directly relevant to "cukjl"’s tactile focus.  
c12_hin_a_cbse_05_003: Imagery identification skill is prerequisite for spotting the sensory details that build atmosphere.  
c12_hin_a_cbse_05_008: Offers practice with metaphor types (implicit, explicit, extended).  
c12_hin_a_cbse_16_008: Connects imagery to theme in "नमक का दारोगा" — direct precursor to this story's poverty theme.  
c12_hin_ar_cbse_05_001: Covers 'Literary Devices: Imagery and Metaphor' in Class 11 Chapter 5, directly relevant to the symbolic technique described in this background.  
c12_hin_ar_cbse_05_008: Provides the foundational terminology (tenor/vehicle, sensory classification) this node applies at higher depth.  
c12_hin_ar_cbse_05_003: Ability to distinguish between denotative (literal) and connotative (emotional) functions of sensory imagery — taught in Class 11 Imagery node (c11_hin_ar_cbse_05_008).  

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_05_001 -> c11_hin_ar_cbse_05_008 -> c11_hin_ar_cbse_05_009

## THIS_FORMULA
Imagery Analysis: Identify sensory word -> Classify sense modality -> Determine connotation (positive/negative/neutral) -> Link to theme/character. Metaphor Analysis: Identify tenor (subject) and vehicle (image) -> State implicit comparison -> Explain thematic significance.

## FORMULA_VARIABLES
Sensory word: any adjective, verb, or noun evoking sight/sound/smell/touch/taste. Sense modality: visual, auditory, olfactory, tactile, gustatory. Connotation: emotional/cultural association. Tenor: the subject being described. Vehicle: the image used to describe it. Thematic significance: how the comparison reinforces a central idea.

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
analytical

## CROSS_SUBJECT
c11_history_caste_system | The imagery of cow dung, grinding stone, and segregated spaces in "xyrk yksgk" reflects historical realities of caste-based occupational segregation and untouchability practices studied in history.
c11_sociology_social_stratification | Metaphors of purity/pollution (lamp flame in dark eyes) illustrate sociological concepts of symbolic boundaries and internalized oppression in stratified societies.
c11_psychology_developmental | The child's sensory experience of poverty and the metaphor of resilience (lamp flame) connect to developmental psychology concepts of resilience and identity formation in adverse environments.

## PREREQ_CONCEPT
Ability to distinguish literal from figurative language and to identify sensory details in a narrative text.

## PREREQ_BEFORE
Student must have read the full story "xyrk yksgk" and completed nodes on plot, setting, character, and themes.

## PREREQ_STUCK
If stuck, review the "Setting and Atmosphere" node (c11_hin_ar_cbse_05_003) to re-familiarize with the physical world of the story, then practice sensory listing on a familiar scene.

## WORKED_EXAMPLE_1
PROBLEM: Analyze the imagery in the paragraph describing Eksgu lighting the stove and cooking (pages 56-57). How does the author use sensory details to convey the physical toll of her labor?
STEPS:
- Step 1: Locate the paragraph (begins "eksgu mudk vk'k; u le>rk gks..."). Read slowly, highlighting every word that triggers a sense.
- Step 2: Classify each highlighted word: "firk dh ckrsa lqudj" (auditory), "g¡lqos dh èkkj ij gkFk isQjrs" (tactile), "iwjh rjg oqaQn" (tactile/temperature), "Hkêòh esa xje gksrs yksgs" (visual), "mQij csar dk mi;ksx" (olfactory/tactile).
- Step 3: Note the predominance of tactile and olfactory images (heat, smoke, rough surfaces, cow dung) over visual/auditory.
- Step 4: Interpret the pattern: tactile/olfactory images emphasize bodily labor and the inescapable materiality of her low-caste work (handling fuel, fire, ash).
- Step 5: Connect to theme: the sensory overload mirrors the caste system's reduction of her body to a laboring instrument; the absence of pleasant images underscores deprivation.
- Step 6: Write the analytical point: "Shivani uses tactile and olfactory imagery to make the reader feel the weight and heat of Eksgu's daily grind, embodying caste oppression in the body."
REASONING: This step-by-step moves from textual evidence to classification to pattern recognition to thematic synthesis, modeling the analytical process required in board exams.
ANSWER: The passage uses predominantly tactile (burning heat, rough grinding stone) and olfactory (cow dung smoke) imagery to immerse the reader in Eksgu's physical labor. This sensory choice forces an embodied understanding of her caste-assigned drudgery, contrasting with the Thakur household's auditory/visual ritual imagery.

## WORKED_EXAMPLE_2
PROBLEM: Identify and analyze the metaphor in the line "eksgu dh vk¡[kksa esa ,d ltZd dh ped Fkh" (page 64). What does it reveal about her inner state at that moment?
STEPS:
- Step 1: Isolate the sentence. Note the context: Eksgu has just been beaten by the teacher, yet she sits silently watching the Thakur's wife.
- Step 2: Identify tenor (Eksgu's eyes/gaze) and vehicle (lamp's flame).
- Step 3: List qualities of vehicle: small, steady, fragile, illuminating darkness, passive, persistent.
- Step 4: Map qualities to tenor: her gaze is steady despite pain (steady), she sees clearly the injustice (illuminating), she is vulnerable (fragile), she endures (persistent).
- Step 5: Consider irony: a lamp gives light to others but consumes itself; Eksgu's awareness serves the reader/narrator but she remains powerless.
- Step 6: Formulate analysis: "The metaphor transforms her silent gaze into a symbol of quiet witness – fragile yet unextinguished, illuminating the moral darkness around her."
REASONING: Metaphor analysis requires unpacking the vehicle's connotations and mapping them to the tenor in context, then linking to broader themes.
ANSWER: The metaphor "a lamp's flame in her eyes" suggests Eksgu's resilient yet vulnerable consciousness. It conveys her clear-sighted endurance amid oppression, making her a silent witness to the hypocrisy she cannot yet articulate.

## WORKED_EXAMPLE_3
PROBLEM: Compare the metaphorical framing of Eksgu in two scenes: (a) when Thakur's wife calls her "eksgu ugha vk;k vkt" (page 57) and (b) when the narrator describes "eksgu dh vk¡[kksa esa ,d ltZd dh ped Fkh" (page 64). How do these metaphors represent opposing perspectives on her humanity?
STEPS:
- Step 1: Identify the two metaphors. First is implicit: Eksgu as a summonable object (commodity metaphor). Second is explicit: Eksgu's eyes as a lamp flame (resilience metaphor).
- Step 2: Analyze the first: "ugha vk;k vkt" treats her arrival as a transactional event; the grammar (subject "eksgu", verb "vkt" – came) denies agency. The metaphor frames her as property.
- Step 3: Analyze the second: "ltZd dh ped" attributes inner light and moral clarity to her; the metaphor restores subjectivity.
- Step 4: Contrast the perspectives: Thakur wife's view (external, oppressive) vs. narrator's view (internal, empathetic).
- Step 5: Link to structural irony: the same character is objectified by the powerful and humanized by the narrative voice.
- Step 6: Synthesize: "The story uses competing metaphors to expose how caste ideology reduces a child to a function, while the narrative perspective restores her dignity through a metaphor of enduring light."
REASONING: This multi-step comparison requires identifying different metaphor types (implicit vs explicit), analyzing their ideological implications, and synthesizing a structural observation about the text's critique.
ANSWER: The Thakur wife's implicit metaphor (Eksgu as summoned object) enacts caste dehumanization, while the narrator's explicit metaphor (lamp flame) reclaims her humanity. Together they form a dialectic of oppression and resistance central to the story's critique.

## COMPETENCY_QUESTION_1
QUESTION: In "xyrk yksgk", the author uses the recurring image of "csar" (cow dung cakes) in multiple scenes. Trace this image across three different moments in the story and explain how its sensory qualities (smell, texture, labor) evolve to reflect Eksgu's changing relationship with her environment.
COMPETENCY: Textual evidence integration and thematic tracing
STEPS:
- Step 1: Identify three scenes with cow dung imagery (e.g., morning fuel, throwing cakes at the inspector, the final scene where she handles them mechanically).
- Step 2: For each, note the sensory adjectives/verbs used (e.g., "fudky ysus", "dkV&Nk¡Vdj", "csar ls fudkydj").
- Step 3: Analyze the shift: from necessary fuel (survival) to weapon of resistance (agency) to routine habit (internalized role).
- Step 4: Conclude how the image's evolution maps her trajectory from passive victim to momentary rebel to resigned laborer.
ANSWER: The cow dung image begins as olfactory/tactile necessity (survival), becomes a tactile/kinetic act of defiance (throwing at inspector), and ends as mechanical routine (internalized caste labor). This sensory arc mirrors Eksgu's brief spark of agency being extinguished by structural forces.
DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: The metaphor "eksgu dk ;g gLr{ksi bruh iqQrhZ vkSj vkdfLed <ax ls gqvk Fkk" (page 63) describes her efficient movements. Deconstruct this metaphor: what is the tenor, what is the vehicle, and how does the adjective "vkdfLed" (mechanical) modify the metaphor to comment on the cost of her adaptation?
COMPETENCY: Metaphor deconstruction and critical interpretation
STEPS:
- Step 1: Identify tenor (Eksgu's movements/actions) and vehicle (machine/mechanical efficiency).
- Step 2: List connotations of "machine": precise, unthinking, tireless, replaceable, lacking autonomy.
- Step 3: Note the paradox: "gLr{ksi" (wonderful) praises the efficiency, but "vkdfLed" (mechanical) reveals the dehumanization.
- Step 4: Connect to the preceding context: she has just been beaten, yet works flawlessly.
- Step 5: Argue that the metaphor encapsulates the story's central tragedy: caste oppression forces a child to become a perfect instrument, erasing her childhood.
ANSWER: The metaphor compares Eksgu's body to a machine. "vkdfLed" strips the praise of "gLr{ksi" by implying her efficiency is not skill but programmed compliance. It shows how oppression converts a child's vitality into mechanical survival.
DIFFICULTY: hard