## DEFINITION
Literal comprehension questions require students to retrieve information directly stated in the text (who, what, where, when), while inferential comprehension questions require students to derive meaning not explicitly stated by combining textual evidence with reasoning (why, how, what might happen next).

## COGNITIVE_LEVEL
understand

## MASTERY_CRITERIA
The student can independently distinguish between literal and inferential questions, locate exact textual evidence for literal answers, and construct logical inferences supported by at least two pieces of textual evidence for inferential answers, writing responses in the CBSE 3-mark answer format (point + evidence + explanation).

## SCOPE_BOUNDARY
This node covers answering literal and inferential questions based **only** on the two poems in Chapter 7 ("ckjgeklk" and "iQkxqu iou >¡dksjS cgkA") and the introductory prose passage about efyd eqgEen tk;lh. It does NOT cover critical analysis, creative writing, or speaking/listening tasks (those are in sibling nodes 013-015).

## WALKTHROUGH
Imagine you're sitting in the CBSE exam hall and see Question 1: "vxgu ekl dh fo'ks"krk crkrs gq, fojfg.kh (ukxerh) dh O;Fkk&dFkk dk fp=k.k vius 'kCnksa esa dhft,A" (Describe the scene of the foggy morning depicting the fog-woman). Your heart races — where do you even start? First, breathe. **Step 1:** Identify the question type — "fp=k.k" (description) signals a **literal** question: the answer is *in* the text. **Step 2:** Scan the prose passage (before the poems) for keywords: "fojg", "ukxerh", "vxgu ekl". You find the second paragraph: "f}rh; va'k esa fojfg.kh ukf;dk osQ o.kZu osQ lkFk&lkFk 'khr ls mldk 'kjhj dk¡ius rFkk fo;ksx ls ân; dk¡ius dk lqanj fp=k.k gSA". **Step 3:** Convert that Hindi into your own words: "The poet describes the fog-woman shaking her hair and spreading moisture from her breath." **Step 4:** For an inferential question like "ek?k eghus esa fojfg.kh dks D;k vuqHkwfr gksrh gS?" (What does the fog-woman experience in the month of Ashadh?), you must combine clues: the third poem stanza shows "ek¡g ijS vc ikyk / igy igy ru #bZ tks >k¡iSA" (now the month has come, only those who endure remain). **Step 5:** Infer: "She feels relief/joy because the harsh summer (ek?k) is ending and monsoon arrives." The key insight: **literal = find; inferential = connect.**

## DIAGNOSTIC_QUESTION_1
What is the fundamental difference between a literal comprehension question and an inferential comprehension question in the CBSE Hindi exam context?

## DIAGNOSTIC_ANSWER_1
A literal question asks for information explicitly written in the text (e.g., "What does the fog-woman shake?" → "her hair" from the prose). An inferential question asks for meaning derived by reading between the lines (e.g., "Why does the poet call the fog 'ukxerh'?" → requires connecting "ukxerh" to the feminine imagery of hair and breath). **Wrong answer reveals:** Student thinks both question types are answered by copying lines; they don't grasp that inferential answers require *synthesis* of multiple textual clues.

## DIAGNOSTIC_QUESTION_2
In the poem "ckjgeklk" (first stanza), the line "vxgu nsol ?kVk fufl ck<+hA" appears. A student writes: "The poet says the morning sun makes the dew dry." Is this a literal or inferential response? Justify using the text.

## DIAGNOSTIC_ANSWER_2
This is a **literal** response because "vxgu nsol" = morning sun, "?kVk" = dew, "fufl ck<+h" = dries up — all directly translated from the words. **Wrong answer reveals:** Student labels it "inferential" because they think "dew drying" is an interpretation; they confuse *translation* with *inference*. Literal answers can still require vocabulary knowledge (from node 010) but don't require logical leaps.

## DIAGNOSTIC_QUESTION_3
Apply the 3-step CBSE answer structure (Point → Evidence → Explanation) to answer this inferential question: "Why does the poet use the image 'fi; lkSa dgsgq l¡nslM+k] ,s Hk¡ojk ,s dkx' in the first poem?" (The poet signals with fingers, saying 'look at the clouds and the sky').

## DIAGNOSTIC_ANSWER_3
**Point:** The poet personifies the fog-woman as a communicator directing attention to nature's drama. **Evidence:** "fi; lkSa dgsgq l¡nslM+k" (she signals with fingers) and "lks èkfu fcjgsa tfj eqbZ] rsfgd èkqvk¡ ge ykx" (if the clouds become yours, the nights become yours). **Explanation:** The gesture "l¡nslM+k" (inviting/pointing) transforms fog from passive weather into an active guide, suggesting humans must *choose* to engage with nature's cycles. **Wrong answer reveals:** Student gives only Evidence ("she points at clouds") without Explanation — they treat inference as quotation, missing the "why" that earns the third mark.

## DIAGNOSTIC_QUESTION_4
Analyze the relationship between the two poems in the chapter. How does the shift from "ckjgeklk" (monsoon arrival) to "iQkxqu iou >¡dksjS cgkA" (winter sun) change the *type* of inferential questions a student must prepare for?

## DIAGNOSTIC_ANSWER_4
"ckjgeklk" invites inferences about **anticipation and renewal** (e.g., "Why does the fog-woman shake her hair?" → to herald rain). "iQkxqu iou >¡dksjS cgkA" invites inferences about **endurance and transience** (e.g., "Why do birds sit with feathers fluffed?" → to conserve heat). The shift requires students to track **seasonal progression** (monsoon → winter) and **emotional arc** (joy → quiet resilience). **Wrong answer reveals:** Student treats poems in isolation, missing the chapter's structural design (covered in node 002) where tk;lh contrasts seasons to show life's cyclical nature — a classic CBSE "theme across texts" inferential trap.

## DIAGNOSTIC_QUESTION_5
Evaluate this student answer to Question 3 (iz'u&vH;kl): "ek?k eghus esa fojfg.kh dks vuqHkwfr gksrh gS fd o"kkZ dk gksuk rFkk iou dk cguk Hkh fojg rki dks c<+k jgk gSA" (In Ashadh, the fog-woman experiences the heat becoming intense and the sun's scorching rays troubling the fog). Is this answer sufficient for 3 marks? Why or why not?

## DIAGNOSTIC_ANSWER_5
**Insufficient — 1/3 marks.** The answer copies the prose line "o"kkZ dk gksuk rFkk iou dk cguk Hkh fojg rki dks c<+k jgk gSA" verbatim but fails to **interpret** the *experience* (vuqHkwfr). A 3-mark answer must add: "This shows the fog-woman's vulnerability — her cooling presence is threatened by summer's violence, foreshadowing her transformation into monsoon clouds." **Wrong answer reveals:** Student confuses *quoting* with *answering*. CBSE marking scheme (from node 014) awards marks for *insight*, not reproduction. This is the #1 mark-loser in board exams.

## DIAGNOSTIC_QUESTION_6
Create an original inferential question based on the last stanza of "iQkxqu iou >¡dksjS cgkA" ("eoqQ rsfg ekjx gksb ijkSa] oaQr èkjSa tg¡ ikmA") that tests a classmate's ability to connect imagery to the poem's central theme of resilience. Provide the ideal 3-mark answer.

## DIAGNOSTIC_ANSWER_6
**Question:** "The line 'eoqQ rsfg ekjx gksb ijkSa] oaQr èkjSa tg¡ ikmA' (when the sun rises, the fog disappears, but the cold stays where it was) seems contradictory. What does this paradox reveal about the poem's message?"  
**Ideal Answer:** **Point:** The paradox highlights that **external conditions change but inner resilience remains**. **Evidence:** "ekjx gksb ijkSa" (fog vanishes with sun) vs "oaQr èkjSa tg¡ ikmA" (cold stays in its place). **Explanation:** The fog (temporary) yields to the sun, but the cold (enduring essence) persists — mirroring how rural life (tk;lh's theme) endures seasonal hardships. The cold "ikmA" (stays put) like the farmer's steadfastness.  
**Poor answer reveals:** Student asks a literal question ("Where does the cold stay?") or gives a literal answer ("In the fields") — they haven't learned to *design* questions that probe theme, a skill needed for node 013 (Critical Thinking).

## COMMON_MISCONCEPTION
**Misconception:** "Inferential questions are just 'harder literal questions' — if I read the text five times, the answer will appear."  
**Why it's wrong:** Inferential answers are **constructed**, not found. In "ckjgeklk", the line "lqyfx lqyfx nxèkS HkS NkjkAA" (waves flow, water fills) literally describes rising water. But the inferential question "What does 'nxèkS HkS' symbolize?" requires connecting "nxèk" (flow) to the **theme of unstoppable natural cycles** (node 006) — a connection *nowhere written*. Students who re-read literally write "water flows" and get 0/3. The error stems from treating Hindi literature like a fact-recall subject (history dates) instead of an interpretive skill.

## ON_FAILURE
If a student cannot distinguish question types or writes literal answers for inferential questions:  
1. **Diagnose:** Give them 5 questions from the chapter's exercise (iz'u&vH;kl) and ask them to label each L (literal) or I (inferential) *before* answering.  
2. **Remediate:** For every "I" question, force them to complete this table: `Textual Clue 1 + Textual Clue 2 → My Inference`. Example: Clue 1: "ukf;dk fojg esa 'ka[k osQ leku gks xbZ gSA" (fog-woman's hair became equal to the sky) + Clue 2: "pdbZ vkSj dksfdyk ls ukf;dk osQ fojg dh rqyuk dh xbZ gSA" (fog-woman was awaited with longing and curiosity) → Inference: "The fog-woman's expansion mirrors the villagers' growing hope for rain."  
3. **Re-diagnose:** Have them answer a fresh inferential question from node 013's practice set using the table. If they still copy text, return to **node 010 (Vocabulary)** to ensure they understand words like "rqyuk" (awaited) and "leku" (equal) — vocabulary gaps block inference.

## BUILDS_ON
Builds on node 010 (Vocabulary in Context) and node 011 (Grammar: Language Usage) because you cannot infer meaning from words you don't understand or grammatical structures you can't parse (e.g., the passive "ck<+h" vs active "ck<+uk").

## LEADS_TO
Leads to node 013 (Critical Thinking: Analysis and Interpretation) where inferential skills are extended to evaluating author's craft, and node 014 (Writing Skills) where structured answers become full essays.

## PREREQUISITE_NODE_IDS
c12_hin_a_cbse_07_002, c12_hin_a_cbse_07_010, c12_hin_a_cbse_07_011, c12_hin_a_cbse_07_008, c12_hin_a_cbse_07_006, c12_hin_a_cbse_07_004, c12_hin_a_cbse_07_009

## PREREQUISITE_REASONS
c12_hin_a_cbse_07_002: Understanding narrative/poetic structure tells you *where* to look for clues (stanza vs prose paragraph).  
c12_hin_a_cbse_07_010: Vocabulary mastery (e.g., "l¡nslM+k", "nxèk") is the raw material for inference — you can't connect clues you can't define.  
c12_hin_a_cbse_07_011: Grammar knowledge (e.g., identifying "fufl ck<+h" as passive voice) reveals agency — who acts? nature or the fog-woman?  
c12_hin_a_cbse_07_008: Imagery/metaphor analysis (node 008) trains the exact skill: moving from literal image ("hair") to figurative meaning ("clouds").  
c12_hin_a_cbse_07_006: Primary theme (node 006) provides the *interpretive framework* — inferences must align with the chapter's core message (harmony with nature).
c12_hin_a_cbse_07_004: Comprehension questions (literal/inferential) directly test the nayika's portrayal — e.g., "How does the nayika describe her state in stanza 1?"  
c12_hin_a_cbse_07_009: Comprehension questions (literal/inferential) frequently ask "what does X symbolize?" or "where is the irony?" — this node supplies the analytical tools.  

## FORWARD_NODE_IDS
c12_hin_a_cbse_07_013, c12_hin_a_cbse_07_014, c12_hin_a_cbse_07_015
## FORWARD_REASONS
c12_hin_a_cbse_07_013: Critical thinking requires generating and defending inferences — this node provides the evidence-to-inference pipeline.  
c12_hin_a_cbse_07_014: Writing skills (PEEL paragraphs) use the same Point-Evidence-Explanation structure practiced here.  
c12_hin_a_cbse_07_015: Speaking/listening discussions need students to articulate inferences orally with textual support.

## CROSS_SUBJECT_PREREQS
c11_hin_ar_cbse_01_012, c11_hin_ar_cbse_02_012, c11_hin_ar_cbse_03_012
## CROSS_SUBJECT_REASONS
c11_hin_ar_cbse_01_012: Class 11 Antra Chapter 1 comprehension node established the L/I distinction — this node deepens it with Braj Bhasha complexity.  
c11_hin_ar_cbse_02_012: Chapter 2 introduced inferring from folk-style poetry — "ckjgeklk" uses similar nksgk-pkSikbZ meter.  
c11_hin_ar_cbse_03_012: Chapter 3 practiced multi-stanza inference — essential for connecting the two poems in this chapter.

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_03_012 -> c12_hin_a_cbse_07_012 -> c12_hin_a_cbse_07_013: Class 11 multi-stanza inference skill enables Chapter 7 literal/inferential mastery, which powers critical analysis in the next node.

## THIS_FORMULA
N/A - conceptual

## FORMULA_VARIABLES
N/A

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
linguistic

## CROSS_SUBJECT
N/A | Both subjects use identical L/I question taxonomy and PEEL answer structure; skills transfer directly.  
 N/A | History source-based questions (literal: "What does the inscription say?"; inferential: "What does it reveal about Gupta economy?") mirror the literary evidence-to-inference process.
## PREREQ_CONCEPT
The distinction between *stated meaning* (vachyaarth) and *implied meaning* (vyangyaarth) in Hindi poetics.

## PREREQ_BEFORE
Student must be able to translate Braj Bhasha vocabulary (using node 010 glossary) and identify the speaker/addressee in each stanza.

## PREREQ_STUCK
If stuck on vocabulary, revisit **node 010's glossary** for "l¡nslM+k", "nxèk", "ekjx", "ikmA" — these four words unlock 80% of the chapter's inferential questions.

## WORKED_EXAMPLE_1
PROBLEM: Answer the literal question from iz'u&vH;kl (Q1): "vxgu ekl dh fo'ks"krk crkrs gq, fojfg.kh (ukxerh) dh O;Fkk&dFkk dk fp=k.k vius 'kCnksa esa dhft,A" (Describe the fog-woman's scene depicting the characteristics of a foggy morning).

STEPS:
- Step 1: Identify question type — "fp=k.k" (description) + "vius 'kCnksa esa" (in your words) = LITERAL. No inference needed.
- Step 2: Locate source text — scan the prose introduction (before poems). Found in 2nd paragraph: "f}rh; va'k esa fojfg.kh ukf;dk osQ o.kZu osQ lkFk&lkFk 'khr ls mldk 'kjhj dk¡ius rFkk fo;ksx ls ân; dk¡ius dk lqanj fp=k.k gSA".
- Step 3: Extract key actions — (a) 'kjhj dk¡ius (shaking hair), (b) fo;ksx ls ân; dk¡ius (spreading moisture from breath).
- Step 4: Translate to standard Hindi — "fojg rki ne apne baal hilae aur saans se nami failai" (The fog-woman shook her hair and spread moisture from her breath).
- Step 5: Add atmospheric context from 1st paragraph — "ty jgh gS vkSj Hk¡ojs rFkk dkx osQ le{k viuh fLFkfr;ksa dk o.kZu djrs gq, uk;d dks lans'k Hkst jgh gSA" (Water standing, clouds and sky describing their conditions, signaling to the farmer).
- Step 6: Synthesize into CBSE 3-mark format — Point: The fog-woman is depicted as a living being heralding morning. Evidence: " 'khr ls mldk 'kjhj dk¡ius rFkk fo;ksx ls ân; dk¡ius". Explanation: Personification makes nature's action intimate and purposeful.

REASONING: Literal questions test *textual fidelity* — the answer must be traceable to specific lines. Steps 2-3 ensure evidence accuracy; Step 6 ensures exam-format compliance (Point-Evidence-Explanation).

ANSWER: The fog-woman (ukxerh) is personified as a graceful figure who shakes her hair ('kjhj dk¡ius) to release moisture and breathes out dampness (fo;ksx ls ân; dk¡ius), while clouds and sky signal the waiting farmer (uk;d dks lans'k Hkst jgh gSA). This imagery transforms a meteorological phenomenon into a nurturing feminine presence.

## WORKED_EXAMPLE_2
PROBLEM: Answer the inferential question from iz'u&vH;kl (Q3): "ek?k eghus esa fojfg.kh dks D;k vuqHkwfr gksrh gS?" (What does the fog-woman experience in the month of Ashadh?)

STEPS:
- Step 1: Identify question type — "vuqHkwfr" (experience/feeling) + "ek?k eghus" (context not in prose) = INFERENTIAL. Must use poem stanza 3.
- Step 2: Analyze poem stanza 3 (lines: "ek¡g ijS vc ikyk / igy igy ru #bZ tks >k¡iSA / vkbZ lwj gksb riq js ukgk¡A / ,fg ekl mitS jl ewywA / uSu pqo¯g tl ek¡gqV uh:A").
- Step 3: Decode Braj Bhasha using node 010 glossary — "ek¡g" = Ashadh (monsoon month), "ikyk" = arrived, ">k¡iSA" = endure/survive, "lwj" = tired, "riq" = path, "ewyw" = intense/strong, "ek¡gqV" = monsoon clouds.
- Step 4: Synthesize clues — Clue A: "ek¡g ijS vc ikyk" (Ashadh has arrived). Clue B: "igy igy ru #bZ tks >k¡iSA" (only those who endure remain). Clue C: "uSu pqo¯g tl ek¡gqV uh:" (no fear of monsoon clouds now). Clue D: "ggfy ggfy vfèkdkS fg; dk¡iSAA" (deep deep thunder sounds).
- Step 5: Formulate inference — The fog-woman experiences **relief and triumph**: summer's oppression ("ewyw" heat) ends, monsoon arrives ("ek¡gqV"), and she no longer fears ("uSu pqo¯g") because her purpose (bringing rain) is fulfilled. The "lwj" (tiredness) of summer path ("riq") is over.
- Step 6: Write in 3-mark format — Point: She feels relief and fulfillment. Evidence: "ek¡g ijS vc ikyk" + "uSu pqo¯g tl ek¡gqV uh:". Explanation: The arrival of monsoon (ek¡g) ends the harsh summer (ek?k) that troubled her (prose: "o"kkZ dk gksuk rFkk iou dk cguk... c<+k jgk gSA"), transforming her anxiety into peace.

REASONING: Inferential questions test *synthesis across text segments* (prose summer description + poem monsoon arrival). Steps 2-4 force cross-referencing; Step 6 ensures the inference is grounded, not imagined.

ANSWER: In Ashadh (monsoon), the fog-woman experiences **relief from summer's torment and fulfillment of her role**. The prose states summer's heat and scorching sun troubled her ("o"kkZ dk gksuk rFkk iou dk cguk... c<+k jgk gSA"). The poem confirms: "ek¡g ijS vc ikyk" (monsoon has arrived) and "uSu pqo¯g tl ek¡gqV uh:" (no fear of monsoon clouds now). Her exhaustion ("lwj") on summer's path ends; she welcomes the rain she heralded.

## WORKED_EXAMPLE_3
PROBLEM: A CBSE-style case-based question: "Read the extract from 'iQkxqu iou >¡dksjS cgkA' (stanza 4): 'rqEg fcuq oaQrk èkfu g#bZ] ru fruqoj Hkk MksyA / rsfg ij fcjg tjkbZ oSQ] pgS mM+kok >ksyAA'. Answer: (a) What literal action does 'fcjg tjkbZ oSQ' describe? (b) What does 'fruqoj Hkk Mksy' infer about the sun's intensity? (c) How do these two lines together reflect the poem's theme of resilience?"

STEPS:
- Step 1: Parse sub-questions — (a) LITERAL, (b) INFERENTIAL, (c) THEMATIC INFERENCE (connects to node 006).
- Step 2: (a) Literal — "fcjg tjkbZ oSQ" = "the sun rises on the fog" (from glossary: "tjr" = rise, "oSQ" = on). Direct translation.
- Step 3: (b) Inferential — "fruqoj Hkk Mksy" (glossary: "fruqoj" = extreme/excessive, "Hkk Mksy" = becomes hot). Inference: The sun's heat is **violently intense**, not gentle — it "becomes excessive heat" (fruqoj), suggesting a harsh winter sun that burns rather than warms.
- Step 4: (c) Thematic synthesis — Line 1: "rqEg fcuq oaQrk èkfu g#bZ" (when your cold touches the body). Line 2: "rsfg ij fcjg tjkbZ oSQ] pgS mM+kok >ksyAA" (on that the sun rises, the frost melts). Resilience theme: The cold ("oaQr") *initiates* contact ("èkfu g#bZ" — touches the body) but the sun *responds* by rising and melting frost ("pgS mM+kok >ksy" — "mM+kok" = frost, ">ksy" = melts). Yet the poem's last line "oaQr èkjSa tg¡ ikmA" (cold stays where it was) shows **cold's essence survives the sun's attack**.
- Step 5: Structure full answer — (a) The sun rises upon the fog. (b) The sun's heat is extreme ("fruqoj"), indicating a harsh, penetrating winter sun that actively melts frost. (c) Together they show nature's cycle: cold asserts presence (touches body), sun dominates temporarily (melts frost), but cold's core remains ("ikmA") — mirroring rural resilience against seasonal extremes.

REASONING: Case-based questions (new CBSE pattern) test *hierarchical comprehension* — literal → inferential → thematic — in one item. Step 4's cross-line analysis is the differentiator for 5-6 mark questions.

ANSWER: (a) The sun rises on the fog. (b) The sun's intensity is extreme ("fruqoj") — it doesn't just warm, it becomes scorching heat that melts frost ("pgS mM+kok >ksy"). (c) The lines depict a power struggle: cold reaches out ("oaQrk èkfu g#bZ"), sun counters by rising and melting surface frost, but the concluding paradox "oaQr èkjSa tg¡ ikmA" reveals cold's enduring core — symbolizing how rural life (tk;lh's theme) withstands seasonal violence without losing its essence.

## COMPETENCY_QUESTION_1
QUESTION: A student writes this answer to Q2 (iz'u&vH;kl): "th;r [kkb eq,¡ u¯g Nk¡M+k" iafDr osQ lanHkZ esa ukf;dk dh fojg&n'kk dk o.kZu vius 'kCnksa esa dhft,A — "The poet describes the fog-woman's scene where the cold doesn't let the frost die." Identify **two** specific errors in this answer and rewrite it to earn 3/3 marks.

COMPETENCY
Textual evidence integration and answer formatting

STEPS:
- Step 1: Identify Error 1 — The answer treats the **quote as the answer** ("th;r [kkb eq,¡ u¯g Nk¡M+k" is the *question's reference*, not the description). The question asks for description *with reference to* that line.
- Step 2: Identify Error 2 — "cold doesn't let the frost die" misreads "Nk¡M+k" (glossary: "Nk¡M+k" = increase/grow). "u¯g Nk¡M+k" = does **not increase** → frost *diminishes*, not persists.
- Step 3: Locate correct evidence — Prose 2nd para: "pdbZ vkSj dksfdyk ls ukf;dk osQ fojg dh rqyuk dh xbZ gSA ukf;dk fojg esa 'ka[k osQ leku gks xbZ gSA" (fog-woman awaited with longing/curiosity; her hair became equal to sky).
- Step 4: Rewrite using Point-Evidence-Explanation — Point: The fog-woman expands majestically as monsoon approaches. Evidence: "ukf;dk fojg esa 'ka[k osQ leku gks xbZ gSA" + "pdbZ vkSj dksfdyk ls... rqyuk dh xbZ gSA". Explanation: Her hair merging with sky ("'ka[k leku") visualizes fog becoming clouds; villagers' "rqyuk" (awaiting) mirrors her readiness to rain.

ANSWER: **Errors:** (1) Quoting the reference line instead of describing the scene. (2) Misinterpreting "u¯g Nk¡M+k" (does not increase → frost decreases) as "does not let die." **Corrected 3-mark answer:** The fog-woman's form expands grandly as monsoon nears — her hair grows until it equals the sky ("'ka[k osQ leku gks xbZ gSA"), symbolizing fog transforming into rain-clouds. Villagers await her with longing and curiosity ("pdbZ vkSj dksfdyk ls... rqyuk"), reflecting nature's anticipated benevolence. The line "th;r [kkb eq,¡ u¯g Nk¡M+k" (cold doesn't let frost increase) marks winter's end, making space for her monsoon arrival.

DIFFICULTY
medium

## COMPETENCY_QUESTION_2
QUESTION: Design a **new** inferential question for the poem "ckjgeklk" that requires connecting **imagery** (node 008), **grammar** (node 011), and **theme** (node 006). Provide the question, the ideal 4-mark answer structure, and explain why this question would discriminate between surface-level and deep comprehenders.

COMPETENCY
Question design and multi-concept synthesis

STEPS:
- Step 1: Select convergence point — Stanza 2, line: "iwl tkM+ FkjFkj ru dk¡ikA / fcjg ckf<+ Hkk nk#u lhmQA" (Evening comes spreading slowly / Sun dries up, heat becomes intense, 'lhmQA').
- Step 2: Identify three concepts — Imagery: "dk¡ik" (evening) as transition. Grammar: "nk#u" (intense/deep) as adjective modifying "Hkk" (heat) — shows heat's quality, not just quantity. Theme: Cyclical inevitability (node 006) — day yields to night, heat yields to cool.
- Step 3: Craft question — "In 'fcjg ckf<+ Hkk nk#u lhmQA', the adjective 'nk#u' (intense) modifies 'Hkk' (heat). How does this grammatical choice, combined with the imagery of 'iwl tkM+ FkjFkj ru dk¡ik' (evening spreading slowly), reinforce the poem's theme of nature's patient, unstoppable cycles?"
- Step 4: Ideal answer structure — Point: "nk#u" elevates heat from temporary to elemental. Evidence 1 (Grammar): "nk#u" as *gunvachak visheshan* (qualitative adjective) implies heat's *nature*, not degree. Evidence 2 (Imagery): "FkjFkj ru dk¡ik" (slowly spreading evening) contrasts heat's intensity with time's patience. Explanation: The grammar fixes heat as an inherent force; the imagery shows time outlasting it — evening *will* spread ("FkjFkj"), heat *will* dry ("ckf<+"), but the cycle continues. Theme confirmed: nature's rhythms are deeper than any single day's extremity.
- Step 5: Discrimination rationale — Surface comprehenders translate "nk#u" as "very hot" (literal) and miss the adjective's thematic weight. Deep comprehenders see "nk#u" + "FkjFkj" as a **dialectic** (intensity vs. patience) — the core of tk;lh's folk philosophy.

ANSWER: **Question:** "In 'fcjg ckf<+ Hkk nk#u lhmQA', the adjective 'nk#u' (intense) modifies 'Hkk' (heat). How does this grammatical choice, combined with the imagery of 'iwl tkM+ FkjFkj ru dk¡ik' (evening spreading slowly), reinforce the poem's theme of nature's patient, unstoppable cycles?"  
**Ideal 4-mark Answer:**  
**Point:** The qualitative adjective "nk#u" and the slow-motion imagery "FkjFkj" together establish heat as a *necessary phase* in an eternal cycle, not a crisis.  
**Evidence 1 (Grammar):** "nk#u" is a *gunvachak visheshan* — it defines heat's *essential quality* (intensity is its nature), not merely its current level.  
**Evidence 2 (Imagery):** "iwl tkM+ FkjFkj ru dk¡ik" portrays evening's arrival as deliberate, unhurried ("FkjFkj" = slowly, steadily).  
**Explanation:** Grammar makes heat fundamental; imagery makes time inexorable. The sun's intense heat ("nk#u Hkk") dries the land ("ckf<+"), but evening *inevitably* spreads ("dk¡ik FkjFkj"). This mirrors the folk worldview (tk;lh's theme): seasons extreme (ek?k heat, ek¡g rain) are not disruptions but required strokes in nature's cyclical painting. The farmer (uk;d) who understands this ("lans'k Hkst jgh gSA") embodies resilience.  
**Discrimination:** Low comprehenders write "evening comes slowly and heat is intense" (literal paraphrase). High comprehenders articulate the **tension between intensity and patience** as the poem's philosophical engine.

DIFFICULTY
hard