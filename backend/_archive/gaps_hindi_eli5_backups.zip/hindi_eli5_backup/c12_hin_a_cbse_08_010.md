## DEFINITION
Vocabulary in Context refers to the skill of determining the precise meaning of words and phrases as they are used in a specific literary text, by analyzing surrounding clues, grammatical forms, cultural nuances, and the author's stylistic choices, rather than relying solely on dictionary definitions.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student can independently identify at least 10 key words from the poem, explain their contextual meanings with textual evidence, and demonstrate how each word's connotation shapes the poem's imagery, tone, and thematic depth in written answers that follow the Point-Evidence-Explanation-Link structure.

## SCOPE_BOUNDARY
This node covers only the vocabulary items explicitly listed in the NCERT 'kCnkFkZ vkSj fVIi.kh' section for Chapter 8 (Phoolchand's poems), including Braj Bhasha forms, archaic usages, and context-dependent polysemy. It does NOT cover general Hindi vocabulary building, grammar rules (covered in node 011), or literary device identification (covered in nodes 008-009).

## WALKTHROUGH
Imagine you're reading a WhatsApp forward in shuddh Hindi and you stumble on 'eèkqiqj' — you might guess 'morning' but the poem uses it to mean 'the first light of spiritual awakening'. That gap between dictionary meaning and poetic meaning is exactly where board exams test you. Start by reading the poem aloud twice: first for rhythm, second to circle every word that feels unfamiliar or strangely used. Then, for each circled word, ask: (1) What is the literal/root meaning? (2) What does the surrounding line suggest? (3) Does the NCERT glossary give a different shade? (4) How does this specific shade deepen the image or emotion? The key insight: in Bhakti poetry, everyday words like 'nq[k' (nose/face) or 'ekl' (alone) become metaphors for spiritual longing — missing that shift loses you the 3-mark explanation questions.

## DIAGNOSTIC_QUESTION_1
What is the contextual meaning of 'ifrvk' in the first line of the poem 'osQ ifrvk y, tk,r js eksjk fivre ikl'?

## DIAGNOSTIC_ANSWER_1
Correct answer: 'ifrvk' here means 'message/letter' (i=k) sent by the beloved, not just 'news' or 'information'. The context 'y, tk,r' (come, having come) and 'js eksjk fivre ikl' (to my door) shows it is a tangible, awaited communication. A wrong answer like 'news' reveals the student is using dictionary meaning without considering the grammatical construction 'y, tk,r' (movement toward the speaker) which implies a sent object, and the emotional weight of 'fivre ikl' (my door) which suggests personal, intimate delivery.

## DIAGNOSTIC_QUESTION_2
Explain in your own words why the poet uses 'lkvksu ekl' instead of the standard Hindi 'lakdi ka ekla' or 'sunnapan' in the line 'fg, ufg lg, vlg nq[k js Hksy lkvksu ekl'.

## DIAGNOSTIC_ANSWER_2
Correct answer: 'lkvksu ekl' is a Braj Bhasha compound meaning 'the solitude of the forest/woods' (lkvksu = forest, ekl = alone). The poet chooses this over standard Hindi to maintain the rustic, folk authenticity of the virahini's voice and to evoke the specific imagery of a forest dwelling where the separation is physical and elemental. A wrong answer focusing only on 'archaic language' misses the functional purpose: the word 'lkvksu' carries sensory details (trees, wildness, night sounds) that 'sunnapan' (abstract loneliness) cannot, and the meter demands two syllables 'lk-vk-su' fitting the doha rhythm.

## DIAGNOSTIC_QUESTION_3
In the line 'lf[k vudj nq[k nk#u js tx osQ ifrvk,A', the word 'vudj' appears. Using the glossary and context, determine its meaning and explain how it changes the tone compared to using 'anyatra' or 'kahin aur'.

## DIAGNOSTIC_ANSWER_3
Correct answer: 'vudj' means 'elsewhere / in another direction' (vU;re). Combined with 'lf[k' (seeing) and 'nq[k nk#u' (nose/face turned), it creates a vivid physical gesture: the beloved's face is turned away, looking elsewhere. Using 'anyatra' would make it abstract and formal; 'vudj' is colloquial, immediate, and visually precise — we see the head turn. A student who answers 'somewhere else' without the physical gesture misses the 'show, don't tell' technique that earns full marks in 'explain the imagery' questions.

## DIAGNOSTIC_QUESTION_4
Compare the usage of 'nq[k' in these two lines: (1) 'fg, ufg lg, vlg nq[k js Hksy lkvksu ekl' and (2) 'lf[k vudj nq[k nk#u js tx osQ ifrvk,A'. How does the same word carry different layers of meaning?

## DIAGNOSTIC_ANSWER_4
Correct answer: In (1) 'nq[k' means 'face/visage' (the beloved's face is not seen in the forest solitude). In (2) 'nq[k' means 'nose' as a synecdoche for 'face/direction of gaze' (the nose/face is turned elsewhere). The shift from 'face as object of longing' to 'nose as indicator of rejection' deepens the virahini's despair: first she cannot see the face at all, then she sees it deliberately averted. A wrong answer that gives the same meaning for both ('face') fails to analyze how the poet reuses a word to advance the emotional narrative — a classic board exam 'analyze the word choice' trap.

## DIAGNOSTIC_QUESTION_5
The glossary defines 'frjfir' as 'r`Ir] larq"V' (firm, established). In the line 'tue vofèk ge :i fugkjy u;u u frjfir Hksy', evaluate whether 'frjfir' modifies 'u;u' (form) or 'Hksy' (is/happens) and justify how this grammatical ambiguity enriches the poem's philosophical depth.

## DIAGNOSTIC_ANSWER_5
Correct answer: 'frjfir' grammatically modifies 'u;u' (form/shape) — 'u;u u frjfir' = 'form not firm/established'. But because 'Hksy' (is) follows immediately, a reader can momentarily hear 'u frjfir Hksy' = 'is not firmly established'. This deliberate ambiguity mirrors the poem's theme: the physical form (body) is not firm, AND the existential state (being) is not firmly established. A student who picks only one reading misses the Bhakti poetic technique of 'shlesha' (double entendre) that conveys impermanence of both body and worldly existence — a 4-mark 'critical appreciation' requirement.

## DIAGNOSTIC_QUESTION_6
Create a two-line couplet in modern Hindi that captures the essence of 'fcnxèk' (fonXèk/nq[kh — bent/humiliated face) and 'deyeq[k' (dey osQ leku eq[k — heads equal to the dust) using contemporary imagery (e.g., smartphone, metro, office) but retaining the original emotional weight.

## DIAGNOSTIC_ANSWER_6
Expected answer: A couplet like: 'Screen ki roshni mein jhuka chehra, notification ka intezaar / Dust ke barabar ho gayi izzat, jab usne block kiya pyaar.' Criteria: must use modern setting, retain 'bent face' and 'dust-equal dignity' metaphors, and show the same helplessness. A poor answer that only translates literally ('jhuka hua chehra, mitti jaisi izzat') without contextual adaptation shows inability to transfer poetic essence across registers — a skill tested in CUET creative writing sections.

## COMMON_MISCONCEPTION
Students treat the NCERT glossary as a fixed dictionary: they memorize 'fcnxèk = fonXèk' and write it in exams without ever asking why the poet chose 'fcnxèk' (which implies 'breaking/ bending' from 'fcnxu') over the simpler 'nq[kh'. They miss that 'fcnxèk' is a causative participle — someone/something bent that face — implying external oppression (social norms, fate, the beloved's indifference) whereas 'nq[kh' is just a state. This error costs marks in 'explain the significance of the word' questions because the examiner expects the morphological insight (causative vs. stative) and its thematic link to the virahini's powerlessness.

## ON_FAILURE
Step 1: Pick 3 words from the glossary that have causative or passive morphology (e.g., fcnxèk, c[kkfuv, xekvksfy). Step 2: For each, write the root verb (fcnxu, c[kkuk, xekuk) and identify the suffix (èk, uv, fy). Step 3: Rewrite the poem line replacing the word with its root form and note the meaning shift. Step 4: Re-read the NCERT 'kCnkFkZ' column — notice how the glossary often gives the root meaning (e.g., 'fonXèk] nq[kh') but the text uses the derived form. Step 5: Practice writing one 'significance' answer per word using the template: 'The word X is a [form] of root Y, implying Z agency/condition, which reinforces the theme of W.'

## BUILDS_ON
Class 11 vocabulary-in-context skills (identifying context clues, using glossaries) and Chapter 8 literary devices nodes (imagery, symbolism) which show how word choice creates effects.

## LEADS_TO
Comprehension: Literal and Inferential Questions (node 012) where precise vocabulary understanding is needed for inference, and Writing Skills (node 014) where students must use similar contextual precision in their own analytical paragraphs.

## PREREQUISITE_NODE_IDS
c11_hin_ar_cbse_01_010, c11_hin_ar_cbse_02_010, c12_hin_a_cbse_08_008, c12_hin_a_cbse_08_009, c12_hin_a_cbse_08_001
## PREREQUISITE_REASONS
c11_hin_ar_cbse_01_010: Class 11 vocabulary foundation — context-clue strategies, glossary use, archaic word handling.
c11_hin_ar_cbse_02_010: Reinforces vocabulary skills across multiple Class 11 chapters, building transferable habit.
c12_hin_a_cbse_08_008: Imagery and Metaphor node shows how specific words create images; vocabulary feeds into that analysis.
c12_hin_a_cbse_08_009: Irony and Symbolism node demonstrates how word connotations create layered meanings.
c12_hin_a_cbse_08_001: Context and Background node provides historical/linguistic setting (Braj Bhasha, Bhakti era) essential for interpreting archaic vocabulary.

## FORWARD_NODE_IDS
c12_hin_a_cbse_08_011, c12_hin_a_cbse_08_012, c12_hin_a_cbse_08_013, c12_hin_a_cbse_08_014
## FORWARD_REASONS
c12_hin_a_cbse_08_011: Grammar node requires vocabulary base to analyze syntactic forms (e.g., causative verbs like fcnxèk).
c12_hin_a_cbse_08_012: Comprehension questions demand precise word meanings for literal and inferential answers.
c12_hin_a_cbse_08_013: Critical thinking needs nuanced vocabulary to support interpretations.
c12_hin_a_cbse_08_014: Writing skills require students to deploy context-appropriate vocabulary in analytical paragraphs.

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
No cross-subject prerequisite nodes provided in the prior class data for Hindi Antra.

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_01_010 -> c12_hin_a_cbse_08_010 -> c12_hin_a_cbse_08_011

## THIS_FORMULA
Contextual Meaning = Root Meaning + Grammatical Form + Surrounding Imagery + Cultural/Historical Connotation + Thematic Function

## FORMULA_VARIABLES
Root Meaning: literal/dictionary definition of the base word; Grammatical Form: morphological derivation (causative, passive, participle, compound); Surrounding Imagery: sensory details in adjacent words/lines; Cultural/Historical Connotation: associations in Bhakti/Braj tradition; Thematic Function: how the word advances the poem's central idea (virah, impermanence, divine love).

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
linguistic

## CROSS_SUBJECT
N/A | The vocabulary of Phoolchand's poem reflects the linguistic synthesis of the Bhakti period (Sanskrit + vernacular) which History Chapter 'Bhakti-Sufi Traditions' covers; understanding words like 'fo|kifr', 'eèkqiqj' requires knowing the Sant tradition's symbolic lexicon.
 N/A | The poem's vocabulary encodes gendered, rural, and devotional social roles (virahini, forest dweller, devotee) that Sociology's 'Social Structure and Change' chapter analyzes; words like 'lkvksu', 'fivre', 'eu Hkkou' are cultural artifacts.
## PREREQ_CONCEPT
Ability to use context clues (syntactic, semantic, cultural) to disambiguate polysemous words in pre-modern Hindi poetry.

## PREREQ_BEFORE
Student must have practiced identifying root words and derivational suffixes in Braj/Awadhi texts (Class 11 vocabulary nodes) and understand the virahini convention (Chapter 8 node 001).

## PREREQ_STUCK
If stuck, revisit Class 11 node c11_hin_ar_cbse_01_010 'Vocabulary in Context: Key Words' and re-do the exercise on 'deriving meaning from grammatical form' using the provided glossary.

## WORKED_EXAMPLE_1
PROBLEM: Analyze the word 'c[kkfuv' in the line 'lsg fifjfr vuqjkx c[kkfuv fry fry uwru gks,AA' using the contextual meaning formula.

STEPS:
- Step 1: Identify the root — 'c[kkuk' (to chew, to ruminate, to ponder). The suffix '-uv' makes it a passive participle: 'that which is chewed/pondered'.
- Step 2: Check glossary — 'c[kkfuv = c[kku djuk' (to chew/ponder). Note the glossary gives the active verb, but the text uses passive form.
- Step 3: Examine surrounding imagery — 'fifjfr' (separation), 'vuqjkx' (intense), 'fry fry' (continuously), 'uwru gks,' (becomes tasteless). The virahini's grief is being 'chewed over' continuously by her own mind.
- Step 4: Determine cultural connotation — In Bhakti poetry, 'c[kkuk' often means 'internalizing the guru's word' (positive). Here it is inverted: separation itself becomes the mantra that is mechanically chewed, losing taste (uwru).
- Step 5: Synthesize thematic function — The passive form 'c[kkfuv' shows the virahini has no agency; grief processes her. This reinforces the theme of helplessness in virah.

REASONING: Each step isolates a component of the formula. Step 1-2 handle linguistic form, Step 3 handles immediate context, Step 4 handles tradition, Step 5 handles theme — together they produce a board-exam-ready explanation.

ANSWER: 'c[kkfuv' is a passive participle meaning 'being incessantly chewed/pondered upon'. Unlike the active 'c[kkuk' (to reflect on divine name), here the grief of separation (fifjfr) mechanically occupies the mind, rendering life tasteless (uwru). The passive voice underscores the virahini's lack of control — a key aspect of virah bhakti.

## WORKED_EXAMPLE_2
PROBLEM: The word 'xekvksfy' appears in 'dr eèkq&tkfefu jel xekvksfy u cw>y dblu osQfyAA'. Derive its meaning and explain why the poet uses this causative form instead of the simple verb.

STEPS:
- Step 1: Break morphology — root 'xekuk' (to shake, to winnow). Suffix '-vksfy' = causative + passive? Actually 'xekvksfy' = 'xek' + 'v' (causative) + 'ksfy' (passive participle?); better: 'xekvksfy' = 'xek' (shake) + 'v' (causative) + 'ksfy' (from 'ksfy' = to cause to do?); consult glossary: 'xekvksfy = xok¡ nh] xq”kkj nh] fcrk nh' (gave a shake, gave a jerk, gave a blow).
- Step 2: Note the glossary gives three synonyms — all imply external force applied to something.
- Step 3: Context — 'dr eèkq&tkfefu jel' (how much the early morning dew/frost). The dew is the object receiving the action. 'u cw>y dblu osQfy' (did not leave the world/life).
- Step 4: Compare with simple verb 'xekuk' — 'xekuk' would mean 'the dew shook (intransitive)'. The causative 'xekvksfy' means 'something/someone shook the dew violently'. Who? The implied agent is the harsh reality of separation (or time, or God).
- Step 5: Thematic link — The causative mirrors the virahini's experience: she is not shaking by herself; the world's cruelty shakes her. The dew is a metaphor for her fragile existence.

REASONING: The causative form shifts agency from the subject to an external force, paralleling the poem's worldview where the devotee is acted upon by divine will / fate.

ANSWER: 'xekvksfy' is a causative passive construction meaning 'was violently shaken/jolted (by an external agent)'. The poet chooses it over 'xekuk' (shook) to show that the morning dew — symbol of the virahini's tender life — does not tremble on its own; it is shaken by the cruel 'eèkq tkfefu' (early morning frost/separation). This external agency echoes the Bhakti idea that the soul's suffering is ordained, not self-chosen.

## WORKED_EXAMPLE_3
PROBLEM: The poem uses 'tyèkkjk' (vJqèkkjk) in the last line: 'pkSnfl&pk¡n&lekuA Hkub fo|kifr flc¯lg uj&ifr yf[keknsb&jekuAA'. Explain how this single compound word encapsulates the poem's entire philosophical argument.

STEPS:
- Step 1: Segment the compound — 'ty' (that) + 'èkkjk' (bent, broken, humiliated). Glossary: 'tyèkkjk = vJqèkkjk'.
- Step 2: Locate in poem — Final line, after describing the beloved's face bent (fcnxèk), heads equal to dust (deyeq[k), the poet says 'tyèkkjk' as a concluding descriptor of the state.
- Step 3: Trace the arc — First poem: virahini waits for message. Second: describes physical/mental deterioration. Third: describes complete surrender — face bent, head in dust. 'tyèkkjk' is the final adjective for that state.
- Step 4: Connect to Phoolchand's philosophy — The poet-saint Phoolchand (fo|kifr) teaches that true devotion requires 'flc¯lg uj&ifr' (ego-less, formless state). 'tyèkkjk' = the broken ego, the surrendered self.
- Step 5: Link to node 006 (Primary Theme) — The primary theme is 'self-surrender in divine love'. 'tyèkkjk' is the vocabulary embodiment of that theme.
- Step 6: Board answer formulation — Use PEEL: Point (word encapsulates surrender), Evidence (final line, compounds fcnxèk/deyeq[k), Explanation (causative bending -> ego dissolution), Link (Phoolchand's Nirguna Bhakti).

REASONING: This example combines vocabulary analysis with thematic synthesis across multiple sibling nodes (theme, literary devices), modeling the multi-concept competency questions in CBSE 3-4 markers.

ANSWER: 'tyèkkjk' (vJqèkkjk — utterly broken/bent) is the climactic vocabulary choice that condenses the poem's journey from longing to total surrender. It grammatically echoes the causative 'fcnxèk' (made to bend) and the resultative 'deyeq[k' (heads equal to dust), showing that the virahini's ego has been systematically dismantled by love's discipline. In Phoolchand's Nirguna Bhakti, this 'broken' state is not defeat but the prerequisite for 'flc¯lg uj&ifr' (formless, attribute-less union). Thus one word carries the entire philosophical trajectory.

## COMPETENCY_QUESTION_1
QUESTION: A Class 12 student writes in a board exam answer: 'The word "fcnxèk" means "bent head" which shows the woman is sad.' Using the contextual meaning formula, critique this answer and rewrite it to earn full 3 marks.

COMPETENCY: Critical analysis of peer response / Exam answer improvement

STEPS:
- Step 1: Identify the gaps — only root meaning given, no grammatical form (causative), no imagery context (fcnxu = to break/bend), no cultural connotation (humiliation vs. devotion), no thematic link (ego surrender).
- Step 2: Apply formula components — Root: fcnxu (to break). Form: causative participle (made to bend). Imagery: paired with 'deyeq[k' (head in dust). Connotation: in Bhakti, bent head = surrender, not just sadness. Theme: virah as transformative discipline.
- Step 3: Structure improved answer using PEEL — Point: 'fcnxèk' is a causative form implying external agency bending the head. Evidence: Line 'oqQlqfer dkuu gsfj deyeq[k / ewfn jg, nq u;ku / dksfdy&dyjo] eèkqdj&èkqfu lqfu] dj nsb >k¡ib dku'. Explanation: The causative shows the world/God bends the devotee's head; 'deyeq[k' shows total prostration. Link: This is not mere sadness but the necessary ego-death for divine union.
- Step 4: Write final polished answer.

ANSWER: Improved answer: "'fcnxèk' is a causative participle from 'fcnxu' (to break/bend), meaning 'made to bend' — not simply 'bent'. The agency lies outside the virahini: the harsh reality of separation (symbolized by 'dksfdy&dyjo', 'eèkqdj&èkqfu') forces her head down. Paired with 'deyeq[k' (heads equal to dust), it depicts total prostration. In Nirguna Bhakti, this forced bending is the shattering of 'ahamkara' (ego), the prerequisite for 'flc¯lg uj&ifr' (formless union). Thus the word carries transformative spiritual weight, not mere sorrow." This earns 3 marks: identification of form, contextual evidence, thematic integration.

DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: The poem uses three words for 'seeing/looking': 'lf[k' (line 2), 'gsfj' (line 3), and 'is[k' (glossary for 'vuqeksn,'). Create a comparative table showing each word's root, grammatical form, contextual nuance, and thematic role. Then write a 150-word analysis of how this lexical triangulation structures the poem's visual narrative.

COMPETENCY: Comparative lexical analysis / Synthesis across text

STEPS:
- Step 1: Build table —
  Word | Root | Form | Contextual Nuance | Thematic Role
  lf[k | lf[kuk (to see) | Imperative/optative? Actually 'lf[k gs' = 'see!' or 'looking' | Active, urgent command to self to witness the beloved's absence | Initiates the visual search; desire-driven
  gsfj | gsfjuk (to see/watch) | Present participle 'gsfj&gsfj' = watching continuously | Helpless, ongoing witnessing of the beloved's deteriorated state | Sustains the virahini's torment; passive endurance
  is[k | is[kuk (to see) | Noun 'vuqeksn,' = seeing/appearance | The resulting appearance/visibility (or lack thereof) | Concludes the visual arc: the beloved's form is no longer 'is[k' (perceptible) in the old way
- Step 2: Analyze progression — From active seeking (lf[k) to forced witnessing (gsfj) to altered perception (is[k). This mirrors the virahini's journey from agency to surrender.
- Step 3: Draft analysis — Connect to 'visual narrative' concept: the poem moves from 'looking for' to 'watching decay' to 'seeing anew'. The vocabulary shift enacts the philosophical shift.
- Step 4: Ensure 150 words, use terminology (participial aspect, perceptual verb, narrative arc).

ANSWER: (Table as above) Analysis: The poem's visual narrative is engineered through three perceptual verbs that form a grammatical and semantic arc. 'lf[k' (imperative 'look!') opens with the virahini's volitional search — she commands herself to see the absent beloved. 'gsfj&gsfj' (reduplicated present participle 'watching continuously') traps her in involuntary witnessing of the beloved's emaciated form ('dksfdy&dyjo', 'eèkqdj&èkqfu'), the reduplication mimicking the relentless passage of time. Finally, 'vuqeksn,' (noun 'appearance/seeing') in 'dr fcnxèk tu jl vuqeksn,' shifts from act to result: the appearance itself has changed — the bent head (fcnxèk) is now the only visible truth. This triangulation — active search, passive endurance, transformed perception — linguistically enacts the Bhakti trajectory from ego-driven longing to grace-realized surrender. The vocabulary does not merely describe; it performs the devotee's inner transformation.

DIFFICULTY: hard