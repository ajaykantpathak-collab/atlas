## DEFINITION
Character analysis of the protagonist involves a systematic examination of the central character's traits, motivations, conflicts, and development throughout the narrative, using textual evidence such as dialogue, actions, internal thoughts, and relationships to construct a coherent interpretation of their role in advancing the story's themes.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student can write a structured 150-word character sketch of the protagonist (Feeki Uljhan) that identifies three distinct personality traits, supports each with specific textual evidence (paraphrased or quoted), explains how each trait drives the plot or reveals a theme, and uses precise literary terminology (e.g., internal conflict, agency, socioeconomic determinism).

## SCOPE_BOUNDARY
This node covers only the protagonist Feeki Uljhan from Nirmal Verma's "Feeki Uljhan" (Chapter 2). It does not cover supporting characters (node 005), thematic analysis (nodes 006-007), or literary devices (nodes 008-009), though it references them as needed for character interpretation.

## WALKTHROUGH
Imagine you meet a street vendor who makes beautiful handcrafted dolls but refuses to call herself an artist, insisting she's just a labourer. You'd wonder: what shapes her self-perception? Start by listing every scene where Feeki Uljhan appears — her workshop conversation with the narrator, the doll-making demonstration, the argument about the clerk's name, the poem she recites. Next, classify each observation into appearance, speech, action, thought, or others' reactions. Then ask: which traits are consistent? Which change? Finally, connect her resistance to labels ("ukuckbZ" vs "jksVh cukusokyk") to the story's critique of social hierarchies. The key insight: Feeki Uljhan's dignity lies not in her craft but in her refusal to let poverty define her identity.

## DIAGNOSTIC_QUESTION_1
What is the protagonist's primary occupation as explicitly stated in the text, and what secondary activity does she engage in to supplement her income?

## DIAGNOSTIC_ANSWER_1
Feeki Uljhan is primarily a school teacher (ukuckbZ) who supplements her income by making and selling dolls (jksVh). A wrong answer (e.g., "she is a full-time doll-maker") reveals the student cannot distinguish between a character's stated profession and their survival strategy, missing the central tension between institutional identity and marginalised labour.

## DIAGNOSTIC_QUESTION_2
Explain in your own words why Feeki Uljhan reacts sharply when the narrator calls her "ukuckbZ" (teacher) after she has identified herself as a doll-maker.

## DIAGNOSTIC_ANSWER_2
She rejects the label "teacher" because it represents a past institutional identity that failed to protect her from poverty, whereas "doll-maker" reflects her current agency and honest labour. A wrong answer (e.g., "she is humble" or "she doesn't like teaching") shows the student reads the reaction as mere modesty rather than a conscious political rejection of a system that devalues her real work.

## DIAGNOSTIC_QUESTION_3
Find two instances in the text where Feeki Uljhan's dialogue reveals her awareness of class-based power dynamics. Quote or paraphrase each and explain what it shows about her critical consciousness.

## DIAGNOSTIC_ANSWER_3
1) When she asks the clerk's name and rejects "uxhuklk"k", "ehuklk"k", "j¡xjst" as insufficient, she exposes how bureaucratic labels erase individual dignity. 2) Her poem "u dPph esa cSBk / u cSBk og iDdh esa / u nwljh esa / vkSj tk cSBk rhljh esa" critiques how education systems train children for passive compliance. A wrong answer that treats these as mere complaints misses her structural analysis of power.

## DIAGNOSTIC_QUESTION_4
Compare Feeki Uljhan's relationship with her son (revealed through the "the/cs/vfyI+kQ" teaching scene) to the narrator's relationship with his own childhood memories. What does this parallel reveal about intergenerational transmission of resilience?

## DIAGNOSTIC_ANSWER_4
Both scenes show adults teaching children to name the world on their own terms: Feeki Uljhan teaches her son "vfyI+kQ" (courage) through phonetic drilling, while the narrator recalls being taught to read by a teacher who "gave words a distinct identity." The parallel reveals resilience as a taught practice, not innate trait. A wrong answer focusing only on "mother loves son" misses the pedagogical dimension of resistance.

## DIAGNOSTIC_QUESTION_5
Evaluate the narrator's final description of Feeki Uljhan as "fuxyh vkSj g"ke" (radiant and fierce). Is this an objective observation or a subjective projection? Defend your answer using at least two textual details.

## DIAGNOSTIC_ANSWER_5
It is a subjective projection that reveals the narrator's middle-class romanticisation of poverty. Evidence: 1) He earlier describes her eyes as "yegk&Hkj" (strong/build) — a physical detail — but "fuxyh" (radiant) is an aesthetic judgement. 2) He admits "gels oqQN dgrs u cu vk;k" (no adequate words came) showing his linguistic failure to capture her reality. A wrong answer accepting the description as fact reveals uncritical acceptance of the narrator's gaze.

## DIAGNOSTIC_QUESTION_6
Write a 4-line poem from Feeki Uljhan's perspective responding to the narrator's question "D;k vki nwljh i<+kbZ dh ckcr oqQN dg jgs Fks u!" using her voice, rhythm, and concerns.

## DIAGNOSTIC_ANSWER_6
A strong answer uses her vernacular diction ("ukuckbZ", "jksVh", "vf[r;kj"), her defiant tone, and references her material reality (dolls, hunger, son's education). Example: "i<+kbZ ughw¡] dke gS vkSj vkSj / jksVh ds lkFk jInd gS / csVh ughw¡] ek¡xk ughw¡ / ekrk dh LoLFk gS vkSj vkSj". A poor answer uses standard Hindi, romantic metaphors, or ignores her economic anger, showing failure to internalise her voice.

## COMMON_MISCONCEPTION
Students often treat Feeki Uljhan as a "symbol of the poor" or "representative of marginalised women" rather than a specific individual with contradictions. They write: "She represents the struggle of all poor women" instead of "Her refusal to accept the clerk's title without a name reveals her specific critique of bureaucratic anonymity." This error occurs because textbooks often frame such characters as "types" in chapter summaries, and students confuse thematic function with character particularity.

## ON_FAILURE
1. Have the student list 5 things Feeki Uljhan says that NO other character says (e.g., the poem, the clerk-name interrogation, "dke djus ls vkrk gS] ulhgrksa ls ugha"). 2. For each, ask: "Could a different poor woman say this? Why or why not?" 3. Force them to rewrite one generic sentence ("She represents...") into a specific claim using one unique quote. 4. Verify they use "Feeki Uljhan" not "the protagonist" or "she" in the first three sentences of their next answer.

## BUILDS_ON
Close reading of dialogue and action from Text: Plot and Narrative Structure (c11_hin_ar_cbse_02_002) and physical environment from Setting and Atmosphere (c11_hin_ar_cbse_02_003).

## LEADS_TO
Character Analysis: Supporting Characters (c11_hin_ar_cbse_02_005) where the narrator and clerk become foils, and Theme: Primary Theme (c11_hin_ar_cbse_02_006) where Feeki Uljhan's resistance crystallises the story's message on dignity.

## PREREQUISITE_NODE_IDS
c11_hin_ar_cbse_02_001, c11_hin_ar_cbse_02_002, c11_hin_ar_cbse_02_003
## PREREQUISITE_REASONS
c11_hin_ar_cbse_02_001: Provides biographical context of Nirmal Verma and the socio-literary milieu of "Nayi Kahani" essential for understanding the author's gaze on marginality.
c11_hin_ar_cbse_02_002: Supplies the chronological sequence of Feeki Uljhan's appearances and her key interactions (with narrator, clerk, son) which are the raw data for analysis.
c11_hin_ar_cbse_02_003: Establishes the physical space (cramped room, doll display, street sounds) that shapes her bodily posture and economic constraints.

## FORWARD_NODE_IDS
c11_hin_ar_cbse_02_005, c11_hin_ar_cbse_02_006, c11_hin_ar_cbse_02_013, c11_hin_ar_cbse_02_007, c11_hin_ar_cbse_02_008, c11_hin_ar_cbse_02_009, c11_hin_ar_cbse_02_010, c11_hin_ar_cbse_02_012, c11_hin_ar_cbse_02_014, c11_hin_ar_cbse_02_015, c12_hin_a_cbse_02_005, c12_hin_a_cbse_12_004, c12_hin_al_cbse_01_004, c12_hin_al_cbse_02_004, c12_hin_ar_cbse_01_004, c12_hin_ar_cbse_02_004, c12_hin_ar_cbse_06_004, c12_hin_ar_cbse_08_004, c12_hin_ar_cbse_10_004

## FORWARD_REASONS
c11_hin_ar_cbse_02_005: Feeki Uljhan's traits are fully legible only in contrast to the narrator's detachment and the clerk's bureaucratic arrogance — supporting characters function as mirrors.
c11_hin_ar_cbse_02_006: Her character arc (from defensive pride to poetic declaration) embodies the primary theme of "dignity in labour vs institutional erasure."
c11_hin_ar_cbse_02_013: Critical thinking requires the character analysis as evidence base for interpretive claims about authorial intent and ideological stance.
c11_hin_ar_cbse_02_007: अगला तार्किक चरण: Secondary themes are subsidiary central ideas that run parallel to the primary theme in a literary w... इस नोड की अवधारणाओं को सीधे उपयोग/विस्तारित करता है।  
c11_hin_ar_cbse_02_008: Character analysis of fe;k¡ ulh#íhu provides the "tenor" for every metaphor—her dignity, labor, marginalization.  
c11_hin_ar_cbse_02_009: Protagonist analysis essential - Phenku's character IS the site where irony and symbolism operate  
c11_hin_ar_cbse_02_010: Protagonist analysis shows Fele's voice is subversive—she reclaims words like 'ukuckbZ' ironically.  
c11_hin_ar_cbse_02_012: Understanding the old woman's traits (skill, dignity, oral wisdom) provides the character foundation for inferring her motives and responses.  
c11_hin_ar_cbse_02_014: Protagonist analysis supplies the core character traits (paradoxical wisdom, satirical voice) that become 'Points' in PEEL answers.  
c11_hin_ar_cbse_02_015: Protagonist analysis gives fe;k¡'s motivation, voice, and irony — the engine of every discussion he dominates.  
c12_hin_a_cbse_02_005: Class 11 protagonist analysis skills transferred to supporting character context.  
c12_hin_a_cbse_12_004: Reinforces analysis of a protagonist in a different story, building transferable skill.  
c12_hin_al_cbse_01_004: Another Class 11 protagonist study reinforcing the method of evidence-based trait inference.  
c12_hin_al_cbse_02_004: Prior practice in protagonist analysis (Class 11 Antaral Chapter 2).  
c12_hin_ar_cbse_01_004: Practiced tracking persona across stanzas in Muktibodh's "अँधेरे में" — directly transferable to mapping "व्यक्तित्व"'s 5-stanza evolution.  
c12_hin_ar_cbse_02_004: Gives the foundational PEEL answer-writing skill and evidence-habit this node deepens for poetry.  
c12_hin_ar_cbse_06_004: अगला तार्किक चरण: Character analysis of the protagonist in poetry involves identifying the central personified figure,... इस नोड की अवधारणाओं को सीधे उपयोग/विस्तारित करता है।  
c12_hin_ar_cbse_08_004: Practices tracing a protagonist's emotional arc across stanzas.  
c12_hin_ar_cbse_10_004: Practices protagonist analysis in "Namak ka Daroga" — contrast between official role and inner morality parallels HkfDru's outer servitude/inner autonomy.  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
none

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_02_002 -> c11_hin_ar_cbse_02_004 -> c11_hin_ar_cbse_02_005

## THIS_FORMULA
Character Sketch = (Trait 1 + Evidence 1 + Function 1) + (Trait 2 + Evidence 2 + Function 2) + (Trait 3 + Evidence 3 + Function 3) + Thematic Link

## FORMULA_VARIABLES
Trait: A stable, observable quality (e.g., "defiant self-naming") | Evidence: Specific textual moment (dialogue/action/description) | Function: How the trait advances plot, reveals theme, or shapes relationships | Thematic Link: One-sentence connection to a central theme of the story

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
analytical

## CROSS_SUBJECT
c11_sociology_social_stratification | Feeki Uljhan's negotiation of identity between "teacher" (institutional status) and "doll-maker" (informal labour) illustrates the sociology of status inconsistency and occupational prestige in postcolonial India.
c11_economics_informal_sector | Her home-based doll production, pricing struggle ("rkyhe dh rkyhe gh cM+h ph"k gksrh gS"), and lack of social security exemplify the economics of the urban informal sector and the invisibility of women's piece-rate work.

## PREREQ_CONCEPT
Students must understand the difference between a character's "flat" (single-trait) and "round" (complex, contradictory) portrayal, and know how to anchor claims in textual evidence rather than general impression.

## PREREQ_BEFORE
The student should have completed a full reading of "Feeki Uljhan" and be able to locate at least three scenes where the protagonist speaks or acts significantly.

## PREREQ_STUCK
If stuck, review the "Text: Plot and Narrative Structure" node (c11_hin_ar_cbse_02_002) and create a two-column table: Column A = Scene/Page, Column B = What Feeki Uljhan Does/Says. This forces evidence-gathering before interpretation.

## WORKED_EXAMPLE_1
PROBLEM: Write a character sketch paragraph (approx. 80 words) on Feeki Uljhan's "defiant self-naming" using the formula: Trait + Evidence + Function + Thematic Link.

STEPS:
- Step 1: Identify the trait — Feeki Uljhan refuses externally imposed labels (teacher, clerk's title) and claims her own identity as a doll-maker.
- Step 2: Locate evidence — When the narrator calls her "ukuckbZ", she corrects: "fe;k¡ ukuckbZ ugha... lqfu,] fnekXk esa pDdj dkV xbZ gS". Later she interrogates the clerk's name: "D;k uxhuklk"k osQ ikl\ D;k vkbZuklk"k osQ ikl\ D;k ehuklk"k osQ ikl\".
- Step 3: Explain function — This defiance establishes her agency; she defines herself by her labour (doll-making) not by a state salary that abandoned her.
- Step 4: Connect to theme — Her self-naming enacts the story's central argument: dignity resides in autonomous work, not bureaucratic designation.
- Step 5: Draft paragraph using PEEL structure — Point: Feeki Uljhan's defining trait is defiant self-naming. Evidence: She rejects "teacher" and demands the clerk's real name. Explanation: This shows she derives identity from her craft, not a failed institution. Link: Thus she embodies the theme of labour as self-possession.

REASONING: The 4-step formula forces students to move from observation to interpretation. Step 2's requirement for exact textual moments prevents vague claims. Step 4 ensures the character analysis serves the larger literary task of thematic illumination.

ANSWER: Feeki Uljhan's defining trait is defiant self-naming. When the narrator addresses her as "teacher," she corrects him: "I am not a teacher... the clerk's post is vacant." Later she dismantles the clerk's authority by demanding his real name, rejecting "uxhuklk"k" (one who lifts burden) as insufficient. This refusal to accept institutional labels establishes her agency — she defines herself by her doll-making labour, not by a state salary that abandoned her. Her self-naming enacts the story's central argument: dignity resides in autonomous work, not bureaucratic designation.

## WORKED_EXAMPLE_2
PROBLEM: Analyse how Feeki Uljhan's physical description ("yegk&Hkj", "vk¡[kksa osQ oaQps") functions as characterisation, not just setting.

STEPS:
- Step 1: Isolate the descriptive phrases — "yegk&Hkj" (strong/sturdy build) and "vk¡[kksa osQ oaQps ge ij isQj fn,A" (eyes threw a challenge at us).
- Step 2: Resist the setting trap — Do not treat these as mere atmosphere. Ask: what do they reveal about her interiority and social position?
- Step 3: Connect body to labour — "yegk&Hkj" results from years of doll-making (repetitive handwork, carrying materials). Her body bears the inscription of her work.
- Step 4: Connect gaze to power — The eyes' "challenge" (isQj) precedes her verbal defiance. Her look confronts the middle-class narrator's pity before she speaks.
- Step 5: Synthesise — The description is focalised through the narrator but encodes Feeki Uljhan's resistance. Her body and gaze are sites where class conflict is embodied.

REASONING: Students often copy physical descriptions as "character traits" without analysing how the text constructs the body as a signifier of class and resistance. This example teaches them to read description as characterisation by asking: what social history is written on this body? What power dynamic does this gaze initiate?

ANSWER: Feeki Uljhan's "sturdy build" (yegk&Hkj) is not neutral description — it is the somatic archive of her doll-making labour: years of cutting, stitching, stuffing, carrying. Her eyes that "threw a challenge" (isQj) at the narrator operate before speech: they refuse the middle-class gaze of pity (vkSj csVs&csfV;k¡ gSa). The narrator admits "eu esa vk;k iwN ysa" (a question arose in mind) — her look forces his interrogation. Thus the physical description functions as characterisation by making her body a testament to autonomous labour and her gaze a weapon against class condescension.

## WORKED_EXAMPLE_3
PROBLEM: Trace Feeki Uljhan's character development across three key scenes: (1) first meeting in the workshop, (2) the clerk-name interrogation, (3) the poem recitation. Show how each scene deepens our understanding of her resistance.

STEPS:
- Step 1: Scene 1 (Workshop) — She appears as a skilled artisan ("cM+h #[kkbZ ls cksys") teaching the narrator doll-making. Her authority is pedagogical: she knows the craft, he doesn't. Resistance here is epistemic — she holds knowledge he lacks.
- Step 2: Scene 2 (Clerk Interrogation) — She shifts from craft-teacher to political interrogator. Her demand for the clerk's "real name" exposes how bureaucracy erases personhood. Resistance becomes structural critique.
- Step 3: Scene 3 (Poem Recitation) — She articulates a philosophy of labour: "u dPph esa cSBk / u cSBk og iDdh esa / u nwljh esa / vkSj tk cSBk rhljh esa". The poem transforms her personal practice into a generational manifesto. Resistance becomes pedagogical legacy.
- Step 4: Map the arc — Epistemic authority → Structural critique → Generational manifesto. Each scene expands the scope of her resistance from personal to systemic to intergenerational.
- Step 5: Identify the constant — Across all three, she speaks in her own voice, using her own metaphors (dolls, phonetic drill, bodily posture). The form of her resistance is inseparable from her identity as a maker.
- Step 6: Thematic synthesis — This arc proves the story's thesis: dignity is not a static possession but a practice of continuous self-definition against erasure.

REASONING: This multi-scene analysis prevents the "snapshot" error where students describe a character based on one moment. By requiring temporal tracing, it teaches that character in literary fiction is a dynamic process. The 6-step structure (three scenes + arc mapping + constant identification + synthesis) mirrors the board-exam expectation of "development across the text."

ANSWER: Feeki Uljhan's resistance deepens across three scenes. In the workshop, she holds epistemic authority as a craft-teacher ("cM+h #[kkbZ ls cksys") — the narrator learns from her. In the clerk interrogation, she becomes a structural critic, dismantling bureaucratic anonymity by demanding a "real name" beyond functional labels. In the poem, she elevates her practice to a generational manifesto: "don't sit in the lap / don't sit in the old / don't sit in the new / go sit in the traditional way" — redefining tradition as active resistance. The arc moves from personal skill to systemic critique to intergenerational pedagogy. The constant is her voice: vernacular, metaphorical, grounded in making. This trajectory proves the story's thesis: dignity is a practice of continuous self-definition against erasure.

## COMPETENCY_QUESTION_1
QUESTION: The narrator describes Feeki Uljhan's room as having "dkyh ranwj ls fuxyh vkSj g"ke" (radiant and fierce with smoky darkness). Using this description, explain how the physical space functions as an extension of her character. Your answer must reference at least two specific objects in the room and connect them to her traits.

COMPETENCY: Textual evidence integration and symbolic interpretation

STEPS:
- Step 1: Identify the two objects — the dolls ("jksfV;k¡") and the "nqdku" (cot/bed) where she sits.
- Step 2: Link dolls to her trait of "defiant creativity" — they are not decorative but functional, priced for survival, yet made with "lkI+kQ" (care).
- Step 3: Link the cot to her trait of "embodied authority" — she sits "pkjikbZ ij cSBs chM+h dk e"kk ys jgs gSa" (sitting on the cot with a child's cloth), commanding the space despite poverty.
- Step 4: Explain "fuxyh vkSj g"ke" — the smoky darkness (poverty) is illuminated by her labour's products (dolls) and intensified by her presence (fierce).
- Step 5: Conclude — The room is not a container for her character; it is materialised character.

ANSWER: The room extends Feeki Uljhan's character through two objects. The dolls (jksfV;k¡) embody her "defiant creativity" — each is a priced commodity ("rkyhe dh rkyhe gh cM+h ph"k") yet crafted with "lkI+kQ" (care), proving labour can be both economic necessity and aesthetic assertion. The cot (nqdku) where she sits "with a child's cloth" becomes a throne of embodied authority — she commands the narrative space from this marginal furniture. The "smoky darkness" (dkyh ranwj) represents her material deprivation, but "fuxyh vkSj g"ke" (radiant and fierce) shows how her presence transforms the space: the dolls radiate her skill; her gaze makes it fierce. The room is not a backdrop; it is her character made material.

DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: A Class 11 student writes: "Feeki Uljhan is a strong female protagonist who fights against poverty and patriarchy." Critique this statement using three specific textual details that either support, complicate, or contradict it. Your critique must use the terms "agency," "intersectionality," and "narratorial mediation."

COMPETENCY: Critical evaluation of interpretive claims with theoretical vocabulary

STEPS:
- Step 1: Deconstruct the claim — "strong female protagonist" (reductive), "fights against poverty" (vague), "patriarchy" (absent from text).
- Step 2: Apply "agency" — Support: Her agency is economic (doll-making) and epistemic (teaching narrator, interrogating clerk). Complicate: She says "ge crZu èkksuk u lh[krs / ge Hkêòh cukuk u lh[krs" — her agency is constrained by structural violence.
- Step 3: Apply "intersectionality" — She is not just "female" but a lower-caste/class widow (implied by "okfyn ejgwe"), a teacher-turned-informal-worker, a mother. The text never mentions gender oppression separate from class; her struggle is intersectional.
- Step 4: Apply "narratorial mediation" — We see her only through the middle-class male narrator who admits "gels oqQN dgrs u cu vk;k." His "fuxyh vkSj g"ke" romanticises her. The claim ignores this mediation.
- Step 5: Synthesise critique — The statement imposes a feminist hero narrative on a character whose resistance is class-based, materialist, and mediated by a compromised narrator.

ANSWER: The statement is reductive and theoretically imprecise. 1) Agency: Feeki Uljhan exercises economic agency (doll-making as survival) and epistemic authority (teaching the narrator craft, interrogating the clerk), but she explicitly states structural limits: "we don't let hunger win / we don't make compromise / we don't give hunger a chance / then do we wait for death like sheep?" — her agency exists within, not outside, structural violence. 2) Intersectionality: She is not a universal "woman" but a specific intersection: lower-class widow (okfyn ejgwe), former teacher, informal worker, mother. The text shows class, not patriarchy, as the primary axis — the clerk is male but equally bureaucratic; her son's education is her project, not a patriarchal burden. 3) Narratorial mediation: The narrator's "radiant and fierce" is a middle-class aestheticisation; he admits no adequate words came. The claim mistakes the narrator's romanticisation for the character's reality. Feeki Uljhan resists not as a "strong woman" but as a worker who refuses erasure.

DIFFICULTY: hard