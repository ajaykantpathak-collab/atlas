## DEFINITION
Irony (विडंबना/व्यंग्य) is a literary device where the intended meaning of words or situations is opposite to their literal or expected meaning, creating a contrast between appearance and reality. Symbolism (प्रतीकवाद) is the use of symbols—objects, characters, colors, or actions—to represent abstract ideas, qualities, or concepts beyond their literal sense, allowing deeper layers of meaning to emerge from concrete imagery.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student can independently identify at least two instances of irony and two symbols in the chapter "Hkkjrh; dyk,¡", explain how each operates (verbal/situational/dramatic irony; cultural/universal/personal symbol), and write a structured 150-word analysis connecting the device to the chapter's central theme of art-life inseparability.

## SCOPE_BOUNDARY
This node covers identification, classification, and analytical writing on irony and symbolism specifically within the NCERT Class 11 Vitan Chapter 4 "Hkkjrh; dyk,¡" (Indian Arts). It does NOT cover other literary devices (metaphor, imagery, simile), other chapters, or general theory without textual application. Focus remains on how these devices reveal the chapter's thesis: Indian arts are living expressions of collective life, not decorative artifacts.

## WALKTHROUGH
Imagine you're standing at a village fair in Rajasthan watching a Phad painter depict Pabuji's legend on cloth—every color, every gesture carries generations of belief, yet the painter sells it to a city tourist who frames it as "ethnic decor." That gap—between sacred narrative and commodity—is irony. Now notice the peacock feather in the painting: it's not just a feather; it symbolizes monsoon, love, Krishna, and the painter's own prayer for rain. In this chapter, the NCERT text itself uses such contrasts: classical art (शास्त्रीय) claims purity but originated from folk (लोक) traditions it now distances itself from—that's situational irony. And the recurring "उत्सव" (festival), "ऋतु" (season), "सामूहिकता" (collectivity) aren't just words; they symbolize the organic bond between art and life. Start by marking every sentence where the text contrasts "then vs now," "folk vs classical," "individual vs collective." Then ask: what concrete image (color, instrument, gesture, space) stands for an abstract value? That's your entry point.

## DIAGNOSTIC_QUESTION_1
What is the precise difference between situational irony and verbal irony? Give one example of each from everyday life (not from the textbook).

## DIAGNOSTIC_ANSWER_1
Situational irony occurs when the outcome of a situation is opposite to what was expected (e.g., a fire station burning down). Verbal irony occurs when a speaker says something but means the opposite, often with a tone signaling the contrast (e.g., saying "Great job!" when someone drops a tray). A wrong answer—confusing the two or giving only literary examples—reveals the student memorizes definitions without grasping the structural difference: situational irony resides in events/circumstances, verbal irony in language/utterance. This distinction is critical for analyzing the chapter, where the text's narrative structure (situational) and authorial voice (verbal) operate differently.

## DIAGNOSTIC_QUESTION_2
In the chapter, the author states: "शास्त्रीय कला और लोककला के बीच कभी भी वह सम्बन्ध नहीं टूटने पाया जो उनकी जड़ है" (Classical and folk arts never severed the root-relationship between them). Yet earlier the text describes how classical arts became courtly, rule-bound, and separated from common people. Identify the type of irony here and explain why it is not merely a contradiction.

## DIAGNOSTIC_ANSWER_2
This is situational irony: the historical trajectory (classical arts becoming elite, codified, court-dependent) creates an outcome opposite to the author's claim of unbroken organic connection. It is not a logical contradiction because the author asserts a *deep structural* continuity (root/जड़) despite *surface historical* divergence—a nuanced claim that the forms diverged institutionally but share the same cultural DNA. A student calling this "contradiction" misses the layered argument: the text uses irony to highlight that institutional separation (court vs village) couldn't erase the shared lifeworld (ऋतु, उत्सव, सामूहिकता) from which both spring. This misunderstanding reveals inability to distinguish textual assertion from historical description.

## DIAGNOSTIC_QUESTION_3
The chapter mentions "मोरपंखी" (peacock feather) in the context of Phad painting and "बांसुरी" (flute) in Krishna's iconography. Choose ONE and analyze it as a symbol: what concrete object is it, what abstract idea(s) does it represent in the chapter's framework, and how does the text support this reading?

## DIAGNOSTIC_ANSWER_3
Peacock feather (मोरपंखी): Concrete object = feather from peacock's tail, used in Phad paintings of Pabuji/Devnarayan. Abstract ideas = (1) Monsoon/fertility (peacock dances at first rain), (2) Divine grace (Krishna's crown feather), (3) Artist's prayer for livelihood (rain = crops = patron support), (4) Folk aesthetics (natural pigment, organic form). Text support: "ऋतु चक्र... लोकजीवन से जुड़ी" (seasonal cycle linked to folk life), "कला... उत्सव और ऋतु से जुड़ी" (art connected to festival and season). A weak answer lists only "beauty" or "Krishna" without anchoring in the chapter's specific arguments about art-season-community nexus. This reveals superficial symbol-hunting without textual evidence.

## DIAGNOSTIC_QUESTION_4
Compare the function of "उत्सव" (festival) as a symbol in the folk art section versus the classical art section. How does the same symbol operate differently across the two contexts, and what does this reveal about the chapter's argument?

## DIAGNOSTIC_ANSWER_4
In folk art: उत्सव = living, participatory, cyclic, community-generated (e.g., Madhubani on wedding walls, Phad during jagarans). Symbolizes art as *collective ritual*. In classical art: उत्सव = courtly occasion, patron-driven, performance-for-audience (e.g., Mughal/Rajput miniatures depicting royal festivals). Symbolizes art as *refined spectacle*. The shift from participatory to presentational mirrors the chapter's central tension: institutionalization extracts art from life. The symbol's dual operation proves the author's claim that "कला और जीवन का सम्बन्ध टूटा नहीं" (art-life relation didn't break)—it transformed. A student seeing only "festival = happiness" misses the structural symbolism: the *same word* carries opposite social relations. This reveals inability to track symbolic density across textual sections.

## DIAGNOSTIC_QUESTION_5
The chapter ends with: "क्या यह अनिवार्य रूप से कला में आएगा? मनुष्य का सृजनशील जीवन, सामाजिक चेतना... क्या अनिवार्य रूप से कला का विषय बनेंगे?" (Is it inevitable in art? Will creative human life, social consciousness... inevitably become art's subject?). Evaluate whether this rhetorical question functions as verbal irony, and justify your position using the chapter's overall tone and evidence.

## DIAGNOSTIC_ANSWER_5
Yes, it functions as verbal irony. The chapter spends 10 pages demonstrating that Indian arts *have always* sprung from creative life and social consciousness (folk songs at harvest, dance at birth, painting at marriage). The closing question feigns doubt about what the entire text has proven inevitable. The irony underscores urgency: modern alienation threatens this inevitability. The author says "Will it happen?" but means "It must happen, or art dies." A student answering "no, it's a genuine question" misses the rhetorical strategy: the text uses irony to convert descriptive history into prescriptive warning. This reveals failure to read tone against accumulated evidence—a key Class 11 analytical skill.

## DIAGNOSTIC_QUESTION_6
Create a 4-line free verse poem using ONE symbol from the chapter (e.g., बांसुरी, मोरपंखी, दीपक, रंग, ताल) that captures the irony of classical art's separation from its folk roots. The poem must show, not tell, the contrast.

## DIAGNOSTIC_ANSWER_6
Example (using बांसुरी):
बांसुरी गाती थी खेतों में, मजदूर के पसीने की ताल पर,
आज दरबार में सजती है, सोने की झंकार पर।
वही स्वर, वही साँस—पर सुनने वाला बदला,
लोक का राग, शास्त्र का बंधन—कौन सच्चा, कौन छला?
A strong answer uses concrete imagery (खेत/दरबार, पसीना/सोना), maintains the symbol (बांसुरी) throughout, and enacts the irony through juxtaposition without naming "irony." A weak answer explains the irony directly ("It's ironic that...") or uses abstract nouns only. This reveals whether the student can *embody* the device creatively, not just analyze it.

## COMMON_MISCONCEPTION
Students conflate "symbol" with "metaphor" and treat every noun in the text as a symbol. They write: "The peacock feather is a metaphor for beauty" or "The flute symbolizes music." This error stems from middle-school teaching that equates symbolism with "standing for something pretty." In Class 11, a symbol must be (a) recurrent or emphatically placed, (b) connected to the text's central argument, and (c) capable of multiple valid interpretations grounded in textual evidence. The chapter's symbols (उत्सव, ऋतु, सामूहिकता, वर्ण, लय) are *conceptual anchors* for the thesis "art = life," not decorative stand-ins. Students also miss irony because they read the text as information delivery, not as an argument with a rhetorical stance. They see "classical art became courtly" as fact, not as an ironic twist relative to the claim of unbroken roots.

## ON_FAILURE
Step 1: Give the student two parallel columns—"What the text says happened historically" vs "What the text claims is the essential truth." Have them fill 3 rows from the chapter (e.g., Court patronage vs folk origin; Rule-bound shastra vs spontaneous lok; Individual virtuoso vs collective creation). Step 2: Ask: "Where is the gap? What word describes a gap between expected and actual?" Guide them to "situational irony." Step 3: For symbolism, hand them a 3-column template: Concrete Image | Textual Context (quote line) | Abstract Idea(s) Supported. Do 2 together (मोरपंखी, दीपक), then they do 2 alone. Step 4: Require them to write one analytical paragraph using the PEEL structure (Point-Evidence-Explanation-Link) on either device. This moves them from labeling to arguing.

## BUILDS_ON
c11_hin_v_cbse_04_008: Literary Devices: Imagery and Metaphor (students already know how to identify concrete images and figurative comparisons; irony and symbolism deepen this by adding contrast and layered meaning).

## LEADS_TO
c11_hin_v_cbse_04_013: Critical Thinking: Analysis and Interpretation (where students synthesize all literary devices to construct original critical readings of the chapter).

## PREREQUISITE_NODE_IDS
c11_hin_v_cbse_04_008, c11_hin_v_cbse_04_006, c11_hin_v_cbse_04_002, c11_hin_v_cbse_04_005, c11_hin_v_cbse_04_007

## PREREQUISITE_REASONS
c11_hin_v_cbse_04_008: Imagery and Metaphor provides the foundation of identifying concrete images and figurative language—symbolism extends this by adding cultural/abstract resonance; irony extends this by adding contrast between image and context.
c11_hin_v_cbse_04_006: Primary Theme and Message (art-life inseparability) is the thematic anchor without which symbolism and irony appear as isolated devices rather than argumentative strategies.
c11_hin_v_cbse_04_002: Plot and Narrative Structure gives the chronological/historical framework (folk → classical → modern) within which situational irony operates across time.
c11_hin_v_cbse_04_005: Irony/symbolism may arise from contrasts between folk and classical supporting characters.  
c11_hin_v_cbse_04_007: Irony and symbolism interpretation depends on knowing which themes they reinforce or complicate  

## FORWARD_NODE_IDS
c11_hin_v_cbse_04_012, c11_hin_v_cbse_04_013, c11_hin_v_cbse_04_014, c12_hin_a_cbse_04_009, c12_hin_a_cbse_05_009, c12_hin_a_cbse_10_009, c12_hin_al_cbse_01_009, c12_hin_ar_cbse_09_009

## FORWARD_REASONS
c11_hin_v_cbse_04_012: Comprehension questions (literal/inferential) require device-awareness to answer "why did the author phrase it this way?" items.
c11_hin_v_cbse_04_013: Critical Thinking directly builds on device-analysis to produce original interpretations—the competency questions here are rehearsal for that node.
c11_hin_v_cbse_04_014: Writing Skills (analytical essay, critical appreciation) demand the structured argumentation (PEEL) practiced in this node's worked examples.
c12_hin_a_cbse_04_009: Class 11 Vitan Chapter 4 introduced symbolism in prose memoir — cross-genre reinforcement of the device.  
c12_hin_a_cbse_05_009: अगला तार्किक चरण: Irony is a literary device where the intended meaning of words or a situation is opposite to their l... इस नोड की अवधारणाओं को सीधे उपयोग/विस्तारित करता है।  
c12_hin_a_cbse_10_009: Vitan Chapter 4 explored verbal irony in letters — written voice analysis.  
c12_hin_al_cbse_01_009: Class 11 Vitan Chapter 4 Irony and Symbolism node adds essay/memoir analysis.  
c12_hin_ar_cbse_09_009: अगला तार्किक चरण: Irony is a literary device where the intended meaning of words or events contrasts sharply with thei... इस नोड की अवधारणाओं को सीधे उपयोग/विस्तारित करता है।  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
none

## CHAIN_DESCRIPTION
c11_hin_v_cbse_04_008 -> c11_hin_v_cbse_04_009 -> c11_hin_v_cbse_04_013

## THIS_FORMULA
N/A - conceptual

## FORMULA_VARIABLES
N/A

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
analytical

## CROSS_SUBJECT
c11_history_medieval_india | The chapter's discussion of Mughal/Rajput court patronage transforming folk arts into classical forms mirrors History's coverage of medieval cultural synthesis and elite appropriation of popular traditions (e.g., miniature painting, khayal gayaki).
c11_sociology_indian_society | The folk-classical continuum illustrates Sociology's concepts of "little tradition vs great tradition" (Reddy/Srinivas), sanskritization, and how cultural forms encode social hierarchy and collective identity.

## PREREQ_CONCEPT
Students must understand the chapter's central thesis: Indian arts are not aesthetic objects but living expressions of collective life (ritual, season, labor, community), and the folk-classical distinction is institutional, not ontological.

## PREREQ_BEFORE
Student can summarize the chapter's argument in 3 sentences and list 5 concrete images (objects, sounds, colors, spaces) the text uses to illustrate art-life connection.

## PREREQ_STUCK
Re-read the "लोककला और शास्त्रीय कला" (Folk and Classical Art) section (pages 63-65) and trace the words "उत्सव," "ऋतु," "सामूहिकता," "जड़" across the chapter—mark every occurrence.

## WORKED_EXAMPLE_1
PROBLEM: Analyze the situational irony in the chapter's description of how Phad painting—originally a mobile temple (चलता-फिरता मंदिर) carried by Bhopas for night-long community performances (जागरण)—now hangs as static wall decor in urban homes and galleries. Use textual evidence and explain how this irony serves the author's argument.
STEPS:
- Step 1: Locate the textual description of Phad's original function: "भोपा... रात भर जागरण करते हैं... फड़ उनके लिए चलता-फिरता मंदिर है" (Bhopas perform all-night jagarans; Phad is a mobile temple for them). Note keywords: communal, ritual, performative, sacred.
- Step 2: Locate the textual description of its current status: "आज ये चित्र... दीवारों पर सजते हैं... कला प्रेमियों के लिए" (Today these paintings decorate walls... for art lovers). Note keywords: static, decorative, individual consumption, secular.
- Step 3: Identify the irony type: Situational—the outcome (commodity on wall) is opposite to the intended/essential function (sacred ritual object in community). The object is identical; the context inverts its meaning.
- Step 4: Connect to author's argument: The irony proves the chapter's thesis that "कला और जीवन का सम्बन्ध टूटा नहीं" is aspirational, not automatic. Institutional separation (market, gallery) severs the ritual lifeline. The author uses this irony to warn: without living community, art becomes corpse.
- Step 5: Formulate analytical statement: "The Phad's journey from जागरण's mobile temple to drawing-room decor enacts situational irony that exposes the fragility of the 'unbroken root' claim—form survives, but function dies."
REASONING: This 5-step process moves from textual evidence to device identification to thematic synthesis—the exact chain board examiners reward. It forces the student to quote, classify, and interpret, not just label.
ANSWER: The Phad painting exemplifies situational irony: originally a sacred, communal, performative object (mobile temple for Bhopa's all-night जागरण), it now functions as static, individual, decorative commodity (wall art for urban collectors). The text contrasts "चलता-फिरता मंदिर" with "दीवारों पर सजते हैं" to show how market forces invert art's essence. This irony serves the author's argument that the folk-classical "root" survives only if living practice (ritual, community, season) survives—not merely the artifact. The irony is not decorative; it is the argument's evidence.

## WORKED_EXAMPLE_2
PROBLEM: The chapter uses "रंग" (color) as a symbol in three distinct contexts: (1) natural pigments in folk painting (हल्दी, गेरू, नील), (2) राग-रागिनी paintings where colors depict musical moods, (3) Holi/spring festivals where color = social dissolution. Trace how "रंग" operates as a multivalent symbol across these contexts and what it reveals about the chapter's view of art.
STEPS:
- Step 1: Extract Context 1 (folk painting): "हल्दी, गेरू, नील... प्रकृति से प्राप्त रंग" (turmeric, ochre, indigo... colors from nature). Symbolizes: art's material rootedness in local ecology, labor (grinding pigments), and ritual purity (colors for specific deities/occasions).
- Step 2: Extract Context 2 (Ragamala): "राग-रागिनियों के चित्रों में... रंगों से भाव व्यक्त होते हैं" (in Ragamala paintings, colors express emotions). Symbolizes: codified aesthetic theory (शास्त्र), where color becomes a semiotic system linking sound (राग) to visual mood (रस).
- Step 3: Extract Context 3 (festival/Holi): "होली... रंगों का उत्सव... सामाजिक बंधन ढीले पड़ते हैं" (Holi... festival of colors... social bonds loosen). Symbolizes: art as social leveler, temporary suspension of hierarchy, collective catharsis.
- Step 4: Synthesize: "रंग" moves from material (pigment) → semiotic (mood-code) → social (equality). The symbol's evolution mirrors the chapter's arc: art begins in nature/community, gets systematized by शास्त्र, but retains its democratic pulse in लोक. The multivalence proves art cannot be pinned to one register.
- Step 5: Write analytical claim: "रंग is a master symbol that condenses the chapter's thesis: art is simultaneously ecological (natural pigment), epistemological (Ragamala code), and political (Holi's equality)—and any account that isolates one register falsifies the whole."
REASONING: This example teaches symbol-tracking across textual sections—a high-order skill. The 5 steps enforce evidence-gathering before interpretation, preventing the "symbol = whatever I feel" error.
ANSWER: "रंग" operates as a multivalent symbol across three registers: (1) Ecological-material: natural pigments (हल्दी, गेरू, नील) ground folk art in local labor and ritual; (2) Epistemological-aesthetic: Ragamala paintings codify color as a visual language for musical moods (राग-रस), showing शास्त्र's systematizing power; (3) Social-political: Holi's color dissolves hierarchy, making art a temporary republic of equals. The symbol's journey from mud to code to carnival mirrors the folk→classical→living continuum. The chapter uses "रंग" to refuse any single definition of art—it is all three simultaneously.

## WORKED_EXAMPLE_3
PROBLEM: The chapter states: "शास्त्रीय कला... नियमों और अनुशासन से बँधी थी... लोककला... सहज और स्वाभाविक थी" (Classical art was bound by rules and discipline... folk art was spontaneous and natural). Yet it also shows classical artists (Tansen, Tyagaraja) drawing from folk melodies, and folk forms (Phad, Madhubani) adopting classical techniques (perspective, iconography). Write a 120-word analysis of how the text uses verbal irony in its authorial voice to destabilize the folk/classical binary, citing two specific textual moments.
STEPS:
- Step 1: Identify the binary the text sets up: शास्त्रीय = rule-bound, elite, courtly, written tradition; लोक = spontaneous, communal, rural, oral tradition. This is the "official" classification.
- Step 2: Find Moment 1 where the voice undermines it: "शास्त्रीय संगीत की जड़ें लोकधुनों में हैं... तानसेन ने लोकधुनों को रागों में ढाला" (Classical music's roots are in folk tunes... Tansen molded folk tunes into ragas). The verb "ढाला" (molded) implies classical form is a container filled by folk content—ironic for a "superior" tradition.
- Step 3: Find Moment 2: "मधुबनी चित्रकला... अब कैनवास पर भी बनती है... शास्त्रीय परिप्रेक्ष्य (perspective) अपनाया है" (Madhubani now on canvas... adopted classical perspective). The folk form "adopts" classical technique—reversing the hierarchy.
- Step 4: Name the device: Verbal irony in authorial narration. The text *states* the binary (sentence 1) but *narrates* its collapse (sentences 2-3), creating a gap between taxonomic claim and historical evidence. The tone is deliberately double-voiced.
- Step 5: Connect to theme: This irony enacts the chapter's argument that "दोनों की जड़ एक है" (both share one root). The binary is institutional, not essential. The author's voice performs the synthesis the thesis claims.
- Step 6: Draft 120-word answer using PEEL: Point (verbal irony destabilizes binary), Evidence (two quotes), Explanation (how each quote inverts the hierarchy), Link (irony = method of argument).
REASONING: This worked example combines device-identification (verbal irony), textual citation, structural analysis (binary vs evidence), and thematic synthesis—exactly the multi-concept competency board exams demand. The 6 steps scaffold the complexity.
ANSWER: The chapter deploys verbal irony to dismantle the folk/classical binary it appears to erect. The opening taxonomy—"शास्त्रीय... नियमों से बँधी... लोक... सहज"—sets up a hierarchy the subsequent narrative quietly subverts. Moment 1: "तानसेन ने लोकधुनों को रागों में ढाला" frames classical raga as a vessel for folk melody, inverting the presumed direction of refinement. Moment 2: "मधुबनी... शास्त्रीय परिप्रेक्ष्य अपनाया" shows the "spontaneous" folk form borrowing the "disciplined" classical technique. The authorial voice states separation but narrates osmosis. This irony is not rhetorical flourish; it performs the chapter's core thesis: "शास्त्रीय और लोककला की जड़ एक है." The binary exists in institutions (court vs village, shastra vs lok), not in the living art-practice where Tansen and the Madhubani painter meet. The text's double-voiced narration—classifying while demonstrating mixture—makes irony its method.

## COMPETENCY_QUESTION_1
QUESTION: The chapter describes how "उत्तर भारतीय शास्त्रीय संगीत" (Hindustani classical music) absorbed Persian/Arabic influences (खयाल, ग़ज़ल, तराना) yet presents itself as the pure descendant of Vedic chant (सामवेद). Identify the specific type of irony operating here, explain how the text's own evidence creates it, and state what this irony reveals about the politics of "शास्त्रीय" (classical) as a label.
COMPETENCY: Analyzing rhetorical strategy and ideological subtext in non-fiction prose
STEPS:
- Step 1: Identify the claim: Hindustani music traces lineage to Samaveda (Vedic purity).
- Step 2: Identify the counter-evidence in text: "फारसी/अरबी प्रभाव... खयाल, ग़ज़ल, तराना... अमीर खुसरो" (Persian/Arabic influences... khayal, ghazal, tarana... Amir Khusrau).
- Step 3: Classify irony: Situational irony—the historical outcome (syncretic, Islamicate-influenced tradition) contradicts the genealogical claim (unbroken Vedic purity). The label "शास्त्रीय" erases the very history the text documents.
- Step 4: Interpret political implication: "शास्त्रीय" functions as a legitimizing category that sanitizes hybridity. The irony exposes how cultural nationalism retroactively purifies a syncretic past.
ANSWER: The irony is situational: the text simultaneously asserts Hindustani music's Vedic lineage (सामवेद से निरंतरता) and documents its medieval transformation via Persian/Arabic forms (खयाल, ग़ज़ल, तराना, अमीर खुसरो). The outcome—a syncretic tradition—contradicts the claimed origin—pure Vedic descent. This reveals "शास्त्रीय" as a political label that confers legitimacy by erasing hybridity. The text's own evidence (Khusrau, khayal's emergence) creates the irony, making the reader complicit in seeing through the purification narrative. The chapter thus uses irony to critique the very category "classical" as a historical construction, not an essence.
DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: In the section on "लोक नृत्य" (folk dance), the text lists: "बिहू (असम), गरबा (गुजरात), भांगड़ा (पंजाब), घूमर (राजस्थान)"—each tied to a specific agrarian cycle (sowing, harvest, spring). Yet the chapter also notes these dances now perform on "राष्ट्रीय मंच" (national stages) and "अंतरराष्ट्रीय उत्सव" (international festivals). Using the concept of symbol, analyze how the *body of the dancer* transforms from a symbol of "community's seasonal rhythm" to a symbol of "national cultural heritage," and evaluate what is gained and lost in this symbolic shift. Support with two textual inferences.
COMPETENCY: Evaluating symbolic transformation across contexts and its cultural implications
STEPS:
- Step 1: Define the original symbol: Dancer's body in बिहू/गरबा/भांगड़ा = embodied seasonal knowledge (sowing/harvest movements), communal participation (no audience/performer split), ritual efficacy (dance *ensures* fertility).
- Step 2: Define the new symbol: Dancer's body on national/international stage = curated representation, aesthetic excellence, cultural diplomacy, fixed choreography for spectator consumption.
- Step 3: Identify textual inference 1: "लोक नृत्य... सामूहिकता के प्रतीक" (folk dance = symbol of collectivity) → on stage, collectivity becomes chorus-line synchronization (simulated, not lived).
- Step 4: Identify textual inference 2: "कला... उत्सव और ऋतु से जुड़ी" (art linked to festival/season) → on stage, the dance is decontextualized from its agrarian calendar (performed in December for tourists, not at Baisakhi).
- Step 5: Evaluate gain/loss: Gain = visibility, preservation funding, prestige. Loss = ritual function, communal ownership, ecological embeddedness. The symbol shifts from *index* (directly connected to what it signifies) to *icon* (resembles but detached).
- Step 6: Conclude: The chapter's anxiety ("क्या यह अनिवार्य रूप से कला में आएगा?") centers on this symbolic displacement.
ANSWER: The dancer's body undergoes a symbolic translocation. In the village, it is an index of seasonal rhythm: the Bihu dancer's hips mimic sowing, the Bhangra kick enacts harvest vigor—movement *is* prayer for crop. The text calls these "सामूहिकता के प्रतीक" (symbols of collectivity) where participation, not performance, matters. On the national/international stage, the same body becomes an icon of "heritage": choreographed, costumed, de-seasonalized (Bihu in Delhi's January), and addressed to an audience. Textual inference 1: "कला... उत्सव और ऋतु से जुड़ी" is violated when Garba performs at a corporate Diwali gala, not Navratri. Inference 2: "लोककला... जीवन का अंग" becomes "heritage item" when the dancer is a professional, not a farmer. Gain: institutional survival, global recognition. Loss: the body no longer *knows* the season—it *represents* it. The symbol hardens from living metaphor to museum exhibit. The chapter's closing question interrogates precisely this: can art remain art when its symbol-severed-from-source?
DIFFICULTY: hard