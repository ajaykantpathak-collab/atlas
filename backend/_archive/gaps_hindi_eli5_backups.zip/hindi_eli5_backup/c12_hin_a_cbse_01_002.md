## DEFINITION
Plot and Narrative Structure in poetry refers to the organized sequence of emotions, images, and thoughts that creates a coherent narrative arc within the poem — including the opening situation, development of feeling, turning point, and resolution — even when the poem does not tell a conventional story with characters and events.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student can independently trace the emotional and imagistic progression in both poems, identify the narrative voice and its shifts, and explain how the structure reinforces the central theme, using specific textual evidence in a structured PEEL paragraph.

## SCOPE_BOUNDARY
This node covers the two poems in the chapter — "nsolsuk dk xhr" (from *LoaQnxqIr*) and "dkusZfy;k dk xhr" (from *panzxqIr*) — focusing on their internal narrative movement, stanza organization, and how the poet arranges lyrical moments to build meaning. It does NOT cover character analysis, setting, themes, or literary devices in isolation (those are separate nodes).

## WALKTHROUGH
Imagine you are listening to a friend describe a vivid dream — they don’t tell it chronologically but in fragments of feeling and image. That’s how these poems work. Start by reading each poem aloud twice: first for the sound and rhythm, second to mark where the speaker’s emotion shifts. Ask: What triggers the first memory? Where does the tone turn from personal grief to collective longing? In "nsolsuk dk xhr", notice the movement from private mourning ("eSaus Hkzeo'k thou lafpr") to a plea for the nation ("fo'o! u l¡Hkysxh ;g eq>ls"). In "dkusZfy;k dk xhr", track the shift from geographic description to spiritual invocation ("vjQ.k ;g eèkqe; ns'k gekjk!"). The key insight: the narrative structure is not event-based but emotion-based — the plot is the journey of the speaker’s consciousness.

## DIAGNOSTIC_QUESTION_1
What is the primary difference between a narrative poem with a conventional plot (like a ballad) and the lyrical narrative structure found in "nsolsuk dk xhr"?

## DIAGNOSTIC_ANSWER_1
A conventional narrative poem follows a sequence of external events (exposition, rising action, climax, resolution) involving characters, while "nsolsuk dk xhr" structures itself around the speaker’s internal emotional states — grief, memory, anger, hope — without a linear storyline. A wrong answer that says “both have a beginning, middle, and end” misses the distinction between event-driven and consciousness-driven structure.

## DIAGNOSTIC_QUESTION_2
In "nsolsuk dk xhr", the speaker says “eSaus fut nqcZy in&cy ij / mlls gkjh&gksM+ yxkbZ”. Explain how this image functions as a structural turning point in the poem’s emotional arc.

## DIAGNOSTIC_ANSWER_2
The image of placing a heavy stone on a fragile heart marks the shift from passive suffering to active endurance — the speaker chooses to bear the weight of national sorrow. Before this line, the poem dwells on personal loss; after it, the voice expands to collective prayer. A student who only identifies the metaphor (“stone = burden”) without linking it to the poem’s structural pivot misunderstands how lyrical narrative works.

## DIAGNOSTIC_QUESTION_3
Apply the concept of ‘emotional plot points’ to the first stanza of "dkusZfy;k dk xhr". Identify three distinct emotional beats and the textual cues that mark them.

## DIAGNOSTIC_ANSWER_3
Beat 1: Pride and ownership (“vjQ.k ;g eèkqe; ns'k gekjk!”) — exclamatory tone, possessive pronoun. Beat 2: Reverent description of diversity (“ljl rkejl xHkZ foHkk ij…”) — cataloguing imagery, calm rhythm. Beat 3: Protective fervor (“mM+rs [kx ftl vksj eq¡g fd,…”) — shift to active verbs, intensity rises. A response that lists images without naming the emotional shift treats the stanza as static description, not narrative movement.

## DIAGNOSTIC_QUESTION_4
Compare the narrative closure of the two poems. How does each use its final lines to resolve (or leave open) the emotional journey?

## DIAGNOSTIC_ANSWER_4
"nsolsuk dk xhr" ends with a direct, vulnerable appeal to the universe (“blls eu dh ykt x¡okbZ”) — an open-ended surrender that invites the reader to share the prayer. "dkusZfy;k dk xhr" closes with a vision of eternal vigilance (“efnj m¡Q?krs jgrs tc / txdj jtuh Hkj rkjk”) — a resolved, almost mythic stance. A student who says “both end hopefully” misses the structural difference: one opens outward to the listener, the other seals the speaker’s identity as eternal guardian.

## DIAGNOSTIC_QUESTION_5
Evaluate this claim: “The narrative structure of these poems is weak because they lack clear events.” Defend or refute using evidence from both poems.

## DIAGNOSTIC_ANSWER_5
Refute. The poems employ a *lyrical narrative structure* where emotional states replace external events as plot points. In "nsolsuk dk xhr", the sequence — private grief → memory of shared past → confrontation with injustice → conscious acceptance of burden → universal prayer — is a rigorous internal plot. In "dkusZfy;k dk xhr", the movement from geographic praise → historical invocation → moral challenge → eternal commitment — creates a narrative of awakening. A student who agrees with the claim confuses *event* with *narrative momentum*.

## DIAGNOSTIC_QUESTION_6
Write a four-stanza poem (4 lines each) that uses the same emotional narrative structure as "nsolsuk dk xhr": personal loss → shared memory → conscious burden-bearing → collective prayer. Use your own imagery.

## DIAGNOSTIC_ANSWER_6
A strong response mirrors the four-phase arc with original imagery (e.g., a farmer losing crops → remembering grandfather’s hands → tying a stone to the plough → praying for rain). A weak response writes four unrelated stanzas or copies the original poem’s images, showing inability to internalize the structural pattern.

## COMMON_MISCONCEPTION
Students often think “plot” only means “what happens next” in a story. They therefore say these poems “have no plot” because no characters act in scenes. The error comes from applying a prose-fiction definition of plot to lyric poetry. In lyric, the *speaker’s consciousness* is the protagonist, and *shifts in feeling* are the events. This misconception leads to answers that describe images without showing how they *progress*.

## ON_FAILURE
1. Have the student reread "nsolsuk dk xhr" and highlight every line where the speaker uses “I” (eSaus, esjh, eq>ls). 2. Ask them to label the emotion in each highlighted line (grief, pride, anger, resolve, plea). 3. Draw arrows between the labels to visualize the emotional sequence. 4. Repeat for "dkusZfy;k dk xhr" using “we/our” (gekjk, esjs, losjs) to trace the collective voice. 5. Then rewrite a one-sentence summary of each poem’s *emotional plot*.

## BUILDS_ON
Class 11 skill of identifying stanza-wise progression in lyric poems (e.g., in *Aroh* Chapter 1 "Namak Ka Daroga" poetry sections).

## LEADS_TO
Character Analysis: Protagonist (c12_hin_a_cbse_01_004) — where the speaker’s persona becomes the ‘character’ to analyze.

## PREREQUISITE_NODE_IDS
c12_hin_a_cbse_01_001, c11_hin_ar_cbse_01_002, c11_hin_v_cbse_01_002
## PREREQUISITE_REASONS
c12_hin_a_cbse_01_001: Provides historical context of Tulsidas (1889–1937) and the novels *LoaQnxqIr* and *panzxqIr*, essential to situate the poems’ narrative voice.
c11_hin_ar_cbse_01_002: Introduces the concept of lyrical narrative structure in Class 11 Antra poems — this node deepens that skill.
c11_hin_v_cbse_01_002: Reinforces tracking emotional arcs in Vitan prose-poetry hybrids — complementary practice.

## FORWARD_NODE_IDS
c12_hin_a_cbse_01_004, c12_hin_a_cbse_01_006, c12_hin_a_cbse_01_013, c12_hin_a_cbse_01_003, c12_hin_a_cbse_01_008, c12_hin_a_cbse_01_010, c12_hin_a_cbse_01_012

## FORWARD_REASONS
c12_hin_a_cbse_01_004: The speaker’s narrative voice *is* the protagonist; understanding its structural journey enables character analysis.
c12_hin_a_cbse_01_006: The primary theme (national awakening through personal sacrifice) emerges directly from the narrative structure traced here.
c12_hin_a_cbse_01_013: Critical interpretation requires the structural map built in this node as evidence for analytical claims.
c12_hin_a_cbse_01_003: Establishes narrative structure so student understands where these excerpts sit in each novel's arc  
c12_hin_a_cbse_01_008: Narrative structure of each poem (where the metaphor appears) determines its function — climax vs. resolution.  
c12_hin_a_cbse_01_010: Establishes narrative structure of the poems — vocabulary sits inside this structure.  
c12_hin_a_cbse_01_012: Narrative structure helps locate where in the poem key evidence appears  

## CROSS_SUBJECT_PREREQS
c11_hin_ar_cbse_01_002, c11_hin_v_cbse_01_002
## CROSS_SUBJECT_REASONS
c11_hin_ar_cbse_01_002: Same skill (lyrical narrative analysis) applied to different texts — vertical alignment within Hindi.
c11_hin_v_cbse_01_002: Cross-textbook reinforcement (Antra + Vitan) ensures the concept is not textbook-specific.

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_01_002 -> c12_hin_a_cbse_01_002 -> c12_hin_a_cbse_01_004

## THIS_FORMULA
N/A - conceptual

## FORMULA_VARIABLES
N/A

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
conceptual

## CROSS_SUBJECT
N/A | Both poems emerge from the same historical moment (1920s–30s) and use personal emotion to articulate collective nationalist longing — the narrative structure mirrors the shift from individual to mass movement.
 N/A | The final prayer in "nsolsuk dk xhr" ("fo'o! u l¡Hkysxh ;g eq>ls") and the eternal vigilance in "dkusZfy;k dk xhr" ("txdj jtuh Hkj rkjk") reflect the civic ideals of fraternity and justice later enshrined in the Preamble.
## PREREQ_CONCEPT
Ability to distinguish between event-based plot (prose fiction) and emotion-based narrative arc (lyric poetry).

## PREREQ_BEFORE
Student must be able to identify the speaker, tone, and stanza breaks in a Hindi poem.

## PREREQ_STUCK
Review Class 11 Antra Chapter 1 poem analysis (c11_hin_ar_cbse_01_002) — specifically the worked example on tracing emotional shifts in "Namak Ka Daroga" verses.

## WORKED_EXAMPLE_1
PROBLEM: Analyze the narrative structure of the first two stanzas of "nsolsuk dk xhr". Show how the poet moves from personal grief to a shared historical memory.

STEPS:
- Step 1: Read the first stanza aloud. Mark the speaker’s direct statements: “eSaus Hkzeo'k thou lafpr” (I have ended my life) and “eèkqdfj;ksa dh Hkh[k yqVkbZ” (shattered the dreams of the awakened ones). Identify the dominant emotion: personal despair mixed with anger at broken promises.
- Step 2: Read the second stanza. Note the shift to past tense and collective imagery: “NyNy Fks laè;k osQ Jed.k” (there were chains of slavery’s feet) and “vk¡lw&ls fxjrs Fks izfr{k.k” (awakening used to erupt from the future). The speaker now speaks for a generation.
- Step 3: Identify the structural bridge: the line “esjh ;k=kk ij ysrh Fkh / uhjork vuar v¡xM+kbZ” (the unborn, rootless storm used to come on my lap). This fuses the personal (“my lap”) with the collective (“unborn storm” = future revolution).
- Step 4: Explain the narrative function: Stanza 1 = private wound; Stanza 2 = historical context that explains the wound. The poem’s plot begins *in media res* with the wound, then flashes back to its cause.
- Step 5: Connect to the whole poem: This two-stanza opening establishes the dual voice (I/we) that drives the entire narrative structure.

REASONING: The poem does not tell a story chronologically; it layers the present grief over the past struggle. The structural insight is that the “plot” is the speaker’s realization that their personal sorrow *is* the nation’s sorrow.

ANSWER: The first two stanzas form a micro-arc: private grief (stanza 1) → collective historical memory (stanza 2), linked by the image of the “unborn storm” on the speaker’s lap. This sets up the poem’s central narrative strategy — the personal is the portal to the political.

## WORKED_EXAMPLE_2
PROBLEM: In "dkusZfy;k dk xhr", the third stanza (“gse oqaQHk ys m”kk losjs / Hkjrh <qydkrh lq[k esjs / efnj m¡Q?krs jgrs tc / txdj jtuh Hkj rkjk”) acts as the poem’s climax. Justify this claim using structural evidence.

STEPS:
- Step 1: Outline the poem’s stanza-by-stanza emotional progression: Stanza 1 = proud possession (“gekjk!”); Stanza 2 = celebratory cataloguing of diversity; Stanza 3 = moral challenge (“mM+rs [kx ftl vksj eq¡g fd,”); Stanza 4 = eternal commitment (this stanza).
- Step 2: Identify the turning point: Stanza 3 shifts from description to imperative (“cjlkrh vk¡[kksa osQ ckny / curs tgk¡ Hkjs djQ.kk ty”). The speaker demands action.
- Step 3: Analyze Stanza 4 as the resolution to that demand: “gse oqaQHk” (holy Ganga-like purity) and “efnj m¡Q?krs” (one who sacrifices) transform the demand into a sacred vow. The rhythm slows, verbs become timeless (“jtuh Hkj rkjk” = forever bearing the burden).
- Step 4: Compare with "nsolsuk dk xhr"’s climax: both poems place the moment of conscious burden-bearing at the structural center (stanza 3 of 4 in each).
- Step 5: Conclude: Stanza 4 is the climax because it answers the poem’s central dramatic question — “Who will protect this land?” — with a mythic self-portrait.

REASONING: In a four-stanza lyric, the third stanza typically carries the highest tension (the ‘crisis’), and the fourth resolves it. Here, the crisis is the call to sacrifice; the resolution is the speaker’s acceptance of that role for eternity.

ANSWER: Stanza 4 is the structural climax — it fulfills the moral challenge of Stanza 3 by casting the speaker as the eternal guardian (“efnj”), using slow, solemn imagery (Ganga, sacrifice, bearing the world) to elevate the narrative from temporal duty to timeless dharma.

## WORKED_EXAMPLE_3
PROBLEM: A board exam question asks: “Compare the narrative structure of the two poems in the chapter. How does each use the ‘I’ vs ‘we’ dynamic to build its arc?” Write a 100-word answer using PEEL structure.

STEPS:
- Step 1: Point — Both poems use a shifting first-person voice to structure their emotional narrative, but the direction of shift differs.
- Step 2: Evidence (Poem 1) — "nsolsuk dk xhr" begins with singular “eSaus” (stanza 1), moves to collective past “NyNy Fks” (stanza 2), returns to singular burden “esjh ;k=kk ij” (stanza 3), and ends with universal plea “eq>ls” (stanza 4). The ‘I’ never fully becomes ‘we’; it carries the ‘we’.
- Step 3: Evidence (Poem 2) — "dkusZfy;k dk xhr" opens with collective ownership “gekjk” (stanza 1), sustains ‘we’ through description (stanza 2), issues a challenge to the collective “cjlkrh vk¡[kksa” (stanza 3), and resolves in a mythic singular “esjs” (stanza 4) that *represents* the collective.
- Step 4: Explanation — Poem 1’s structure is *inward-outward-inward*: the individual absorbs the nation. Poem 2’s is *outward-inward-outward*: the nation speaks, then the individual embodies it.
- Step 5: Link — Thus, narrative structure in both poems is the choreography of pronouns, mapping the relationship between self and nation.

REASONING: PEEL ensures each comparison point is grounded in textual evidence and tied to the structural concept. The pronoun-tracking method is a reproducible analytical tool for any lyric poem.

ANSWER:
Both poems structure their narrative through a dynamic ‘I/we’ choreography. In "nsolsuk dk xhr", the voice begins in isolated grief (“eSaus Hkzeo'k thou lafpr”), expands to shared history (“NyNy Fks laè;k osQ Jed.k”), contracts to personal burden (“esjh ;k=kk ij… gkjh&gksM+ yxkbZ”), and finally opens to universal prayer (“eq>ls”). The ‘I’ remains distinct, bearing the ‘we’. In "dkusZfy;k dk xhr", the voice starts as collective pride (“gekjk”), describes the land as ‘ours’ (“esjs”, “losjs”), challenges the collective (“cjlkrh vk¡[kksa”), and resolves in a singular mythic vow (“esjs… txdj jtuh Hkj rkjk”) that *stands for* the collective. Poem 1: individual absorbs nation. Poem 2: individual becomes nation’s symbol. The narrative arc in each is the movement of the pronoun.

## COMPETENCY_QUESTION_1
QUESTION: A student writes: “Both poems have the same structure — four stanzas, each describing a different aspect of India.” Identify the flaw in this statement and rewrite it to reflect an accurate structural comparison.

COMPETENCY: Critical analysis of textual structure / Identifying oversimplification
STEPS:
- Step 1: Recognize that the student confuses *form* (four stanzas) with *narrative structure* (emotional progression).
- Step 2: Note that the poems differ in stanza length, rhyme, and — crucially — the *direction* of their emotional arc.
- Step 3: Draft a corrected version that names the distinct structural logic of each poem (e.g., “Poem 1 moves from personal grief to collective prayer; Poem 2 moves from collective pride to individual eternal vow”).
- Step 4: Ensure the rewrite uses the terminology of this node (emotional plot points, narrative voice shift).

ANSWER: The statement reduces structure to visual form. Corrected: “While both poems have four stanzas, their narrative structures diverge: 'nsolsuk dk xhr' traces an individual’s journey from private sorrow to universal supplication, whereas 'dkusZfy;k dk xhr' charts a collective identity that crystallizes into a single eternal guardian. The first poem’s arc is centripetal (self → nation); the second’s is centrifugal (nation → self-as-nation).”
DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: The CBSE 2023 sample paper asked: “How does the narrative structure of 'nsolsuk dk xhr' reflect the influence of the Non-Cooperation Movement on the poet’s consciousness?” Using only the poem’s internal structure (no external history), construct a 150-word answer that links specific structural shifts to the *emotional* impact of mass mobilization.

COMPETENCY: Historical-literary synthesis / Evidence-based inference
STEPS:
- Step 1: Identify the structural shift that mirrors mobilization: Stanza 1 (isolated grief) → Stanza 2 (collective past) → Stanza 3 (conscious burden-bearing) → Stanza 4 (public prayer).
- Step 2: Map each shift to an emotional correlate of mass movement: personal loss → recovered heritage → voluntary sacrifice → shared hope.
- Step 3: Select textual anchors: “eSaus Hkzeo'k thou lafpr” (pre-movement despair), “vk¡lw&ls fxjrs Fks izfr{k.k” (awakening from future), “eSaus fut nqcZy in&cy ij / mlls gkjh&gksM+ yxkbZ” (taking up the stone = joining the struggle), “fo'o! u l¡Hkysxh ;g eq>ls” (prayer as collective witness).
- Step 4: Argue that the poem’s *structure itself* enacts the transformation from subject to citizen — the narrative arc *is* the poet’s political awakening.
- Step 5: Write concisely, embedding quotes as evidence, not decoration.

ANSWER: The poem’s four-stanza structure mirrors the poet’s internalization of mass mobilization. Stanza 1 traps the speaker in private ruin (“eSaus Hkzeo'k thou lafpr”) — the pre-movement isolation. Stanza 2 recalls a collective past of resistance (“vk¡lw&ls fxjrs Fks izfr{k.k”), recovering heritage as resource. Stanza 3 is the structural pivot: the speaker *chooses* the burden (“eSaus fut nqcZy in&cy ij / mlls gkjh&gksM+ yxkbZ”), enacting the shift from passive victim to active participant — the emotional equivalent of joining the Movement. Stanza 4 transforms personal prayer into public testimony (“fo'o! u l¡Hkysxh ;g eq>ls”), where the ‘I’ speaks for the ‘we’. The narrative arc *is* the consciousness moving from solitude to solidarity, not by describing events but by staging the speaker’s successive emotional decisions. The structure does not reflect history; it *performs* the making of a political self.
DIFFICULTY: hard