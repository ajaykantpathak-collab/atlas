## DEFINITION
Grammar: Language Usage in the Text refers to the systematic analysis of how grammatical structures (sentence patterns, verb forms, case markers, honorifics), lexical choices (dialect words, idioms, proverbs), and stylistic devices (figures of speech, register variation) function within a specific literary work to construct character, convey social hierarchy, and reinforce thematic concerns.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student can independently identify at least three distinct grammatical or stylistic features in "उद्देश्य नक्शा", provide textual evidence for each, and explain how each feature contributes to characterization, theme, or the representation of colonial power dynamics.

## SCOPE_BOUNDARY
This node covers the analysis of sentence structure (simple/compound/complex), verb morphology (tense, aspect, mood, voice), honorific systems (आप/तुम/तू), dialectal markers (Avadhi/Braj influences), idioms/proverbs, and word-formation processes as they appear in Premchand's "उद्देश्य नक्शा". It does not cover exhaustive grammar rules unrelated to the text, nor does it address poetic devices (covered in c11_hin_ar_cbse_01_008, c11_hin_ar_cbse_01_009).

## WALKTHROUGH
Imagine you receive two messages about the same event: one from a friend on WhatsApp full of slang, emojis, and sentence fragments, and another from your principal in a formal email with complete sentences, honorifics, and standard vocabulary. You instantly recognize who holds authority and what relationship exists between you. Now open "उद्देश्य नक्शा" and ask: "How does Premchand use language differences to show who has power?" Begin by highlighting every dialogue exchange. Circle the verb endings (है/हैं/हूँ), pronouns (आप/तुम/तू), and any non-standard words. Next, compare the narrator's descriptive passages with the clerk's speech and the peasant's speech. Notice how the clerk uses bureaucratic passive constructions ("कागज़ात जमा कराए गए") while the peasant uses active, concrete verbs ("हमने खेत जोता"). Finally, connect each linguistic choice to the story's critique of colonial bureaucracy — the language itself becomes evidence of oppression.

## DIAGNOSTIC_QUESTION_1
What is the grammatical term for the verb form "कराए गए" in the sentence "कागज़ात जमा कराए गए", and what does it indicate about agency in the context of the story?

## DIAGNOSTIC_ANSWER_1
The form "कराए गए" is a **causative passive** construction (कर्मवाच्य + causative). It indicates that the subject (कागज़ात) undergoes an action caused by an unnamed agent (the clerk/bureaucracy), obscuring human responsibility. A wrong answer (e.g., calling it simple past active) reveals the student cannot distinguish voice and causation, missing how grammar hides power.

## DIAGNOSTIC_QUESTION_2
In the peasant's dialogue "हमरे भाग्य मा यहीं लिखल बा", identify two dialectal features that mark this as Avadhi-influenced Hindi and explain how they distance the speaker from the clerk's register.

## DIAGNOSTIC_ANSWER_2
Features: (1) "हमरे" for "हमारे" (possessive pronoun with /r/ insertion), (2) "लिखल बा" for "लिखा है" (perfective participle + auxiliary "बा" from Avadhi). These mark the speaker as rural, uneducated in colonial administration, and linguistically marginalized. A wrong answer listing only vocabulary ("भाग्य") shows the student confuses lexical choice with grammatical dialect markers.

## DIAGNOSTIC_QUESTION_3
Rewrite the clerk's line "आपको नक्शा दिखाना पड़ेगा" into the peasant's register using appropriate pronoun, verb agreement, and dialect marker. Explain each change.

## DIAGNOSTIC_ANSWER_3
Peasant register: "तुझको नक्शा देखब पड़ै". Changes: (1) "आपको" → "तुझको" (intimate/inferior pronoun), (2) "दिखाना पड़ेगा" (standard infinitive + modal) → "देखब पड़ै" (Avadhi future passive "देखब" + "पड़ै" for "पड़ेगा"), (3) honorific plural verb "पड़ेगा" → singular "पड़ै". A wrong answer keeping "आपको" or "पड़ेगा" shows failure to map register to social role.

## DIAGNOSTIC_QUESTION_4
Compare the sentence structure of the narrator's opening description ("इज्सेपन/3" paragraph) with the clerk's first spoken line. How do syntactic complexity and clause embedding reflect their respective positions in the colonial hierarchy?

## DIAGNOSTIC_ANSWER_4
The narrator uses long, hypotactic sentences with multiple subordinate clauses ("जिसमें...वहाँ...जहाँ...") reflecting educated, analytical distance. The clerk's speech is paratactic, imperative-heavy ("दिखाइए...जाइए...लाइए"), reflecting bureaucratic authority that demands obedience. A wrong answer focusing only on vocabulary misses how syntax enacts power.

## DIAGNOSTIC_QUESTION_5
Evaluate the claim: "Premchand's use of the idiom 'अंधे के हाथ बटेर लगना' in the peasant's internal monologue is merely decorative." Defend your judgment with textual evidence.

## DIAGNOSTIC_ANSWER_5
The claim is false. The idiom occurs when the peasant unexpectedly gets the map, but its folk imagery (blind man, partridge) contrasts with the clerk's legalistic language, emphasizing that the peasant's 'luck' is fragile and unintelligible to the system. It also foreshadows the map's uselessness. A wrong answer accepting the claim shows inability to link idiom to theme and character perspective.

## DIAGNOSTIC_QUESTION_6
Create a new dialogue exchange (4-5 lines) between the clerk and a *different* peasant who is slightly literate, mixing standard Hindi verb forms with two Avadhi dialect markers. Annotate each dialect marker.

## DIAGNOSTIC_ANSWER_6
Example:
क्लर्क: "आपका नाम क्या है?"
किसान: "हमार नाम रामदीन बा, बाबू साहब। हम पढ़ल बानी।"
Annotations: (1) "हमार" for "हमारा" (possessive + /r/), (2) "बा" for "है" (Avadhi copula), (3) "पढ़ल बानी" for "पढ़ा हूँ" (perfective + 1st person auxiliary). A poor answer uses only vocabulary substitutions ("बाबू" → "मालिक") without grammatical dialect markers.

## COMMON_MISCONCEPTION
Students believe "language usage" only means identifying difficult words or listing idioms. They treat grammar as separate from literature, so they spot "कराए गए" but cannot explain *why* Premchand chose passive causative over active "क्लर्क ने कागज़ात जमा कराए". They also assume dialect markers are 'errors' rather than deliberate characterization tools, leading them to 'correct' the peasant's speech in analysis.

## ON_FAILURE
1. Give the student two parallel sentences: "अफसर ने फाइल मँगवाई" (active) vs "फाइल मँगवाई गई" (passive). Ask: "Who is responsible in each? Which protects the अफसर?" 2. Provide a three-column table: Standard Hindi | Avadhi form in text | Grammatical difference. Have them fill it for 5 examples from the story. 3. Ask them to rewrite one clerk's line in peasant register, then explain *what* changed (pronoun, verb, auxiliary) and *why* the peasant would never say "कृपया". 4. Finally, have them locate one idiom, translate it literally, and state what cultural knowledge it assumes the peasant has but the clerk lacks.

## BUILDS_ON
Basic Hindi grammar (verb conjugation, case system, sentence types) and familiarity with the plot and characters of "उद्देश्य नक्शा" (from c11_hin_ar_cbse_01_002).

## LEADS_TO
Comprehension of literal/inferential questions (c11_hin_ar_cbse_01_012) and critical interpretation of colonial critique through linguistic evidence (c11_hin_ar_cbse_01_013).

## PREREQUISITE_NODE_IDS
c11_hin_ar_cbse_01_002, c11_hin_ar_cbse_01_010, c11_hin_ar_cbse_01_008, c11_hin_ar_cbse_01_001

## PREREQUISITE_REASONS
c11_hin_ar_cbse_01_002: Plot knowledge is needed to contextualize who speaks when and why. c11_hin_ar_cbse_01_010: Vocabulary in Context provides the lexical base; this node extends to grammatical function. c11_hin_ar_cbse_01_008: Literary Devices covers metaphor/imagery; this node focuses on grammatical/stylistic devices.
c11_hin_ar_cbse_01_001: "Context and Background" refers to the historical, social, biographical, and literary circ... की समझ आवश्यक है, क्योंकि यह नोड (Grammar:) इसी आधार पर आगे बढ़ता है।  
c11_hin_ar_cbse_01_010: Grammar analysis requires identifying word-class and morphological markers first established here (e.g., *nkth* suffix in *cjoaQnkth*).  
c11_hin_ar_cbse_01_008: Grammar usage (e.g., nominal compounds like "mQijh+vk;") often creates dense imagery; syntax analysis supports device analysis.  

## FORWARD_NODE_IDS
c11_hin_ar_cbse_01_012, c11_hin_ar_cbse_01_013, c11_hin_ar_cbse_01_014, c12_hin_a_cbse_01_011, c12_hin_a_cbse_02_011, c12_hin_a_cbse_04_011, c12_hin_a_cbse_05_011, c12_hin_a_cbse_09_011, c12_hin_a_cbse_11_011, c12_hin_a_cbse_12_011, c12_hin_a_cbse_16_011, c12_hin_a_cbse_17_011, c12_hin_al_cbse_01_011, c12_hin_al_cbse_02_011, c12_hin_ar_cbse_01_011, c12_hin_ar_cbse_02_011, c12_hin_ar_cbse_06_011, c12_hin_ar_cbse_07_011, c12_hin_ar_cbse_09_011, c12_hin_ar_cbse_10_011, c12_hin_ar_cbse_11_011, c12_hin_ar_cbse_13_011

## FORWARD_REASONS
c11_hin_ar_cbse_01_012: Comprehension questions require citing linguistic evidence for inferences. c11_hin_ar_cbse_01_013: Critical thinking demands analysis of how language constructs ideology. c11_hin_ar_cbse_01_014: Writing skills need the ability to embed grammatical analysis in structured answers.
c12_hin_a_cbse_01_011: Class 11 grammar foundation for non-finite verbs, mood, and clause structure.  
c12_hin_a_cbse_02_011: Class 11 grammar node covers verb aspects, compounds, and case systems used here.  
c12_hin_a_cbse_04_011: Class 11 Antra grammar nodes establish baseline skills in identifying samasa, verb aspects, and poetic ellipsis — all reused here at higher depth.  
c12_hin_a_cbse_05_011: Class 11 foundation in identifying tense-aspect-mood in poetic texts  
c12_hin_a_cbse_09_011: Established baseline skill of identifying grammatical features in literary texts — transferred here to Braj dialect.  
c12_hin_a_cbse_11_011: Introduces ergative case in perfective past — essential for analyzing "ckyd us", "ys[kd us" in this chapter.  
c12_hin_a_cbse_12_011: Foundation in identifying sentence types (simple/compound/complex) in literary texts  
c12_hin_a_cbse_16_011: Introduces ergative case marking and verb agreement in Hindi — essential for Diagnostic 1.  
c12_hin_a_cbse_17_011: Established foundation in identifying root+suffix+gender in literary Hindi texts — required for analyzing आँगन/आँगनट/आँगनुह.  
c12_hin_al_cbse_01_011: Provides foundational skill of identifying dialectal vs. standard grammatical forms in literary texts.  
c12_hin_al_cbse_02_011: Introduced krdant/taddhit identification and dialect-marker spotting in Class 11 Antara prose — foundational skill.  
c12_hin_ar_cbse_01_011: Foundation in Hindi poetic grammar analysis — verb forms, aspect, case marking across Class 11 Aroh poems.  
c12_hin_ar_cbse_02_011: Foundation in Hindi verb forms, case markers, and samasa from first chapter of Class 11.  
c12_hin_ar_cbse_06_011: Establishes foundational concept of "language usage in text" as grammatical analysis, not just vocabulary.  
c12_hin_ar_cbse_07_011: Foundation in Braj Bhasha verb forms and chhand basics from Class 11 Chapter 1.  
c12_hin_ar_cbse_09_011: Class 11 foundation in alankar identification and vocabulary classification across multiple chapters.  
c12_hin_ar_cbse_10_011: Foundational exposure to dialect identification in Class 11 Aroh Chapter 1.  
c12_hin_ar_cbse_11_011: Foundation in identifying grammatical features in literary texts across Class 11 chapters  
c12_hin_ar_cbse_13_011: Class 11 grammar nodes established baseline skills in identifying dialect, register, and stylistic devices in literary texts.  
c11_hin_ar_cbse_01_013: अगला तार्किक चरण: Critical thinking in literary analysis involves examining a text beyond its literal meaning to evalu... इस नोड की अवधारणाओं को सीधे उपयोग/विस्तारित करता है।  
c11_hin_ar_cbse_01_014: अगला तार्किक चरण: Writing skills based on the chapter "इजसेपन" refers to the ability to compose structured, evidence-b... इस नोड की अवधारणाओं को सीधे उपयोग/विस्तारित करता है।  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
none

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_01_002 -> c11_hin_ar_cbse_01_011 -> c11_hin_ar_cbse_01_012

## THIS_FORMULA
Identify feature → Locate in text → Analyze grammatical function → Connect to character/theme/power dynamic

## FORMULA_VARIABLES
N/A

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
linguistic

## CROSS_SUBJECT
c11_history_colonialism | The story's bureaucratic language mirrors colonial record-keeping; analyzing passive voice reveals how grammar legitimizes extraction.  
c11_sociology_language | Honorific shift (आप/तुम/तू) and dialect markers instantiate social stratification and linguistic hegemony in rural North India.

## PREREQ_CONCEPT
Ability to distinguish verb voice (active/passive/causative), pronoun honorifics, and clause types in Hindi sentences.

## PREREQ_BEFORE
Student must have read "उद्देश्य नक्शा" completely and reviewed Class 10 Hindi grammar: कारक, वाच्य, काल, पुरुष, वाक्य-रचना.

## PREREQ_STUCK
If stuck, review "वाच्य परिवर्तन" (voice change) and "पुरुषवाचक सर्वनाम" (personal pronouns) from Class 10 grammar textbook, then re-read the clerk-peasant dialogues marking every verb ending.

## WORKED_EXAMPLE_1
PROBLEM: Analyze how the shift from "आप" to "तुम" to "तू" in the clerk's address to the peasant across three encounters reflects the changing power dynamic.

STEPS:
- Step 1: Locate the three encounters in the text (first meeting at office, second at peasant's hut, third at final confrontation) and extract the exact pronoun used by the clerk each time.
- Step 2: Identify the grammatical person and honorific level of each pronoun: "आप" (2nd person honorific plural), "तुम" (2nd person familiar/equal), "तू" (2nd person intimate/inferior).
- Step 3: Note the verb agreement shifts accompanying each pronoun: plural verbs ("हैं", "करें") with "आप", plural/familiar ("हो", "करो") with "तुम", singular ("है", "कर") with "तू".
- Step 4: Correlate each shift with the clerk's institutional confidence: initial procedural correctness ("आप"), growing irritation ("तुम"), open contempt ("तू") when the peasant resists.
- Step 5: Conclude that the pronoun trajectory mirrors the colonial state's journey from veneer of legality to naked coercion, and the peasant's silence in response underscores his voicelessness.

REASONING: This step-by-step moves from textual evidence to grammatical analysis to thematic interpretation, modeling the "Identify → Analyze → Connect" formula required for board answers.

ANSWER: The clerk uses "आप" in the office (bureaucratic mask), "तुम" at the hut (personal dominance), "तू" at the climax (dehumanizing power). Each shift drops honorific agreement, exposing how language enacts hierarchy.

## WORKED_EXAMPLE_2
PROBLEM: The peasant thinks "अंधे के हाथ बटेर लगना" when he unexpectedly receives the map. Explain why this idiom is structurally a *subjectless* construction and how that grammatical property reflects the peasant's worldview.

STEPS:
- Step 1: Parse the idiom: "अंधे के हाथ" (locative phrase, not subject), "बटेर" (object), "लगना" (intransitive verb 'to be found/obtained'). Note no nominative subject exists; the experiencer is in oblique case with "के".
- Step 2: Contrast with standard transitive "अंधे को बटेर मिली" (dative subject) or active "अंधे ने बटेर पकड़ी". The subjectless form presents the event as spontaneous, agentless luck.
- Step 3: Link to peasant's fatalism: he sees the map as random fortune, not something he earned or can control — just as a blind man doesn't *seek* a partridge.
- Step 4: Connect to the story's irony: the map (symbol of colonial order) arrives by 'blind luck', yet the system demands he treat it as legal proof. The grammar of the idiom foreshadows the map's ultimate uselessness.
- Step 5: State the analytical insight: Premchand chooses a subjectless idiom to encode the peasant's internalized powerlessness into the very syntax of his thought.

REASONING: Demonstrates how grammatical structure (absence of subject) carries ideological weight, a key Class 11 analytical skill.

ANSWER: The idiom's subjectless, experiencer-in-oblique structure ("अंधे के हाथ...लगना") frames the event as uncontrolled chance, mirroring the peasant's perception of his own agency within colonial bureaucracy.

## WORKED_EXAMPLE_3
PROBLEM: Compare the narrator's sentence "इज्सेपन साहित्य के विकास में कहानी और उपन्यास की धारा के विकास का निर्णायक मोड़ इज्सेपन को ही मानकर चला जाता रहा है" with the clerk's "नक्शा दिखाइए।" Analyze differences in clause embedding, verb modality, and information density, and explain what each reveals about the speaker's epistemic authority.

STEPS:
- Step 1: Segment the narrator's sentence: main clause "मानकर चला जाता रहा है" with three embedded nominal modifiers ("इज्सेपन साहित्य के विकास में", "कहानी और उपन्यास की धारा के विकास का", "निर्णायक मोड़"). Count clauses: 1 main + 3 embedded = high hypotaxis.
- Step 2: Segment the clerk's sentence: single imperative clause "नक्शा दिखाइए" with honorific plural verb. Zero embedding, zero modality beyond command.
- Step 3: Compare verb forms: narrator uses passive habitual "चला जाता रहा है" (impersonal, historical generalization); clerk uses imperative "दिखाइए" (directive, immediate compliance).
- Step 4: Evaluate information density: narrator packs genre history, authorial significance, and critical consensus into one sentence; clerk demands one object.
- Step 5: Interpret epistemic authority: narrator claims scholarly, distanced, cumulative knowledge; clerk claims institutional, immediate, non-negotiable power. The former constructs *intellectual* hierarchy, the latter *administrative* hierarchy.
- Step 6: Synthesize: Premchand juxtaposes these syntactic regimes to show how colonial knowledge (narrator's analysis) and colonial power (clerk's command) operate through different grammatical technologies.

REASONING: This multi-step comparison models the high-order analysis expected in board exams: grammatical parsing → functional interpretation → thematic synthesis.

ANSWER: Narrator's hypotactic, passive, dense sentence enacts scholarly authority; clerk's monoclausal imperative enacts bureaucratic command. Together they frame the peasant caught between knowing and obeying.

## COMPETENCY_QUESTION_1
QUESTION: In the final scene, the peasant says "हमरे भाग्य मा यहीं लिखल बा" and the clerk responds "बकवास मत करो। नक्शा दो।" Using grammatical evidence from both utterances, explain how the clash of *mood* (indicative vs imperative) and *person* (1st person vs 2nd person) enacts the story's central conflict.

COMPETENCY: Analytical reasoning with grammatical evidence

STEPS:
- Step 1: Identify mood of each verb: "लिखल बा" (indicative, stating perceived fact), "करो/दो" (imperative, commanding action).
- Step 2: Identify person/pronoun: "हमरे" (1st person possessive, subjective experience), implied "तुम" in "मत करो/दो" (2nd person familiar, objectifying the peasant).
- Step 3: Explain how indicative mood claims epistemic authority over one's own life ("मेरे भाग्य में लिखा है"), while imperative mood asserts deontic authority over another's body ("नक्शा दो").
- Step 4: Connect to conflict: peasant appeals to cosmic order (fate), clerk enforces legal order (document). Grammar makes the clash irreconcilable.
- Step 5: Conclude that the peasant's Avadhi indicative is dismissed as "बकवास" precisely because it lacks the imperative force the state recognizes.

ANSWER: The peasant's indicative 1st-person utterance ("लिखल बा") asserts lived truth; the clerk's imperative 2nd-person commands ("मत करो/दो") enforce state power. The grammatical mismatch — experience vs order — is the linguistic core of the conflict.

DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: Rewrite the clerk's bureaucratic notice (implied in the text) "समस्त कृषकों को सूचित किया जाता है कि भूमि अभिलेखों का सत्यापन अनिवार्य है" into a folk-song couplet (दोहा/चौपाई) that a peasant might compose to spread the same information orally. Your version must use: (a) Avadhi verb forms, (b) a metaphor from agrarian life, (c) rhythmic meter (24/24 or 16/16 matras). Then analyze how your grammatical choices transform the *speech act* from notification to resistance.

COMPETENCY: Creative application + metalinguistic analysis

STEPS:
- Step 1: Draft couplet in Avadhi: "खेत जोतें किसान सब, कागज माँगें नाय / लेखपाल के डर नहिं, भाग्य लिखावें जाय" (16+16 matras, Avadhi "नाय" for "नहीं", "जाय" for "जाता है").
- Step 2: Verify features: (a) Avadhi forms "नाय", "जाय", "लिखावें" (causative passive), (b) metaphor "खेत जोतें" vs "कागज", (c) meter check.
- Step 3: Compare speech acts: original = constative (informing) + directive (compliance demanded) in official register; rewrite = expressive (voicing fear) + commissive (resistance implied) in folk register.
- Step 4: Analyze grammatical transformation: passive "सूचित किया जाता है" → active "कागज माँगें"; abstract noun "सत्यापन" → concrete verb "लिखावें"; honorific distance removed, replaced by collective "किसान सब".
- Step 5: Argue that the folk version reclaims agency by making the peasant the grammatical subject of experience, not the object of notification.

ANSWER: Couplet: "खेत जोतें किसान सब, कागज माँगें नाय / लेखपाल के डर नहिं, भाग्य लिखावें जाय". The shift from bureaucratic passive to Avadhi active/causative, from abstract nouns to agrarian verbs, and from 3rd-person notification to 1st-person-plural declaration turns a state directive into a communal assertion of autonomy.

DIFFICULTY: hard