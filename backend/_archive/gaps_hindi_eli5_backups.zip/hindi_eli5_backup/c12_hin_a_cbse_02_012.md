## DEFINITION
Literal comprehension questions require answers directly stated in the text (explicit information), while inferential comprehension questions require drawing logical conclusions by combining textual evidence with prior knowledge (implicit meaning). Both demand evidence-based responses, but inferential answers must explicitly show the reasoning bridge from text to conclusion.

## COGNITIVE_LEVEL
apply

## MASTERY_CRITERIA
Student can independently classify any comprehension question as literal or inferential, locate exact textual evidence for literal answers, and construct a 3-step inferential response: (1) quote evidence, (2) state the logical inference, (3) explain the connection to the question — all while using the PEEL paragraph structure.

## SCOPE_BOUNDARY
This node covers strategies for answering literal and inferential questions specifically on the poem "लज्जत लेसर" (Lajjat Lesar) from NCERT Class 12 Hindi Antra Chapter 2. It does NOT cover critical analysis of themes, literary devices, or creative writing extensions — those are addressed in nodes c12_hin_a_cbse_02_013, 014, 015.

## WALKTHROUGH
Imagine you're sitting in the CBSE exam hall, staring at Question 3: "पिता को अपनी बेटी का बचपन क्यों याद आता है?" (Why does the father remember his daughter's childhood?). Your heart races — is this asking for a line from the poem or your own thought? **Start here**: Read the poem aloud once, marking stanzas with brackets. For *every* question, ask: "Can I point to a line that *says* this exactly?" If yes → literal. If no → inferential. For inferential, use the **T-chart method**: left column = textual evidence (quote line/stanza), right column = what it implies. The key insight: *inferential answers are not guesses — they are text-locked deductions*. Practice this on the poem's four stanzas until the classification becomes automatic.

## DIAGNOSTIC_QUESTION_1
**REMEMBER**: Define the difference between a literal and an inferential comprehension question in your own words. Give one example of each type based on any text you have studied.

## DIAGNOSTIC_ANSWER_1
**Correct answer**: A literal question asks for information explicitly written in the text (e.g., "कविता में पिता ने बेटी को क्या सिखाया?" — answer directly in lines). An inferential question asks for meaning not directly stated but derived from evidence (e.g., "पिता की मनोदशा क्या दर्शाती है?" — requires interpreting imagery).  
**What a wrong answer reveals**: If a student says "literal means easy, inferential means hard," they confuse difficulty with cognitive process. If they give an inferential example that is actually a personal opinion ("मुझे लगता है पिता दुखी है"), they miss the evidence requirement. Both errors show they cannot operationalize the distinction in an exam.

## DIAGNOSTIC_QUESTION_2
**UNDERSTAND**: Read the first stanza of "लज्जत लेसर" (starting "नज़र फूक वकेवु उय..."). The question asks: "कविता के पहले पद में 'वकेवु उय' का शाब्दिक अर्थ क्या है?" Classify this question as literal or inferential and justify your classification in two sentences.

## DIAGNOSTIC_ANSWER_2
**Correct answer**: Literal. The phrase "वकेवु उय" (वकेवु = पूरी तरह, उय = उजाला/रोशनी) has a direct dictionary meaning ("पूरा उजाला") provided in the NCERT word-meanings (शब्दार्थ) section. The question asks for *शाब्दिक अर्थ* (literal meaning), which is explicitly given in the textbook's glossary.  
**What a wrong answer reveals**: If a student classifies it as inferential because "they have to interpret the metaphor," they confuse *vocabulary lookup* with *inference*. This reveals a fundamental misunderstanding: literal questions can still require using a glossary — the answer remains *text-bound*, not *mind-bound*.

## DIAGNOSTIC_QUESTION_3
**APPLY**: The exam asks: "कविता के तीसरे पद में 'माँ ने पहली सीख दी' — यह सीख क्या थी? पाठ से उद्धृत करके लिखिए।" Write a model answer using the PEEL structure (Point, Evidence, Explanation, Link) in 4 sentences.

## DIAGNOSTIC_ANSWER_3
**Model answer**:  
**Point**: माँ ने बेटी को जीवन की पहली सीख "अनुशासन और कला" के रूप में दी।  
**Evidence**: पद 3 में लिखा है — "एक़ि ल्स्त रसझ लो;अ जप] लो;अ ड्यक" — अर्थात् माँ ने कहा: "यह सीख दूसरी कला है।"  
**Explanation**: यहाँ 'सीख' का शाब्दिक अर्थ माँ द्वारा सिखाया गया पहला पाठ है, जो कविता में सीधे संवाद के रूप में दर्ज है।  
**Link**: यह उद्धरण दर्शाता है कि माँ पारंपरिक ज्ञान-परंपरा की वाहक है।  
**What a wrong answer reveals**: If a student writes only "माँ ने अनुशासन सिखाया" without quoting the line, they lose 1 mark for missing *Evidence*. If they quote but don't explain *why* that line answers the question, they lose the *Explanation* mark. CBSE marking scheme awards 0.5 for Point, 1 for Evidence, 0.5 for Explanation, 0.5 for Link — skipping any step caps marks at 1.5/3.

## DIAGNOSTIC_QUESTION_4
**ANALYZE**: Compare the father's memory in Stanza 1 ("नज़र फूक वकेवु उय...") and Stanza 4 ("ग्स क्ग] वरेह; लोतु..."). What *shift* in emotional tone occurs? Identify two specific words/phrases from each stanza that evidence this shift.

## DIAGNOSTIC_ANSWER_4
**Correct analysis**:  
- Stanza 1: Tone = **tender nostalgia** → Evidence: "फिज़; ध व'क्न Üक`अक्ज&एक्ज" (child's playful words), "रु उ;ुका लस वक्यक्सद मर्ज" (innocent laughter filling the house).  
- Stanza 4: Tone = **aching void** → Evidence: "डक्सबज़ फ्का उघा] उ वकेअ=क.क" (no one remains, no celebration), "फिज़ एकुु, द लअक्ष ह्क्ज" (silence, only memory's weight).  
**Shift**: From sensory-rich presence (sound, light, touch) to abstract absence (silence, "लोतु" = one's own people gone).  
**What a wrong answer reveals**: If a student says "first happy, then sad" without quoting *specific phrases*, they treat analysis as summary. If they quote "वकेवु उय" (full light) for Stanza 1 but miss that it contrasts with "लोतु" (kinsfolk) in Stanza 4, they fail to analyze the *structural opposition* the poet builds. This error costs 2+ marks in board "analyze" questions.

## DIAGNOSTIC_QUESTION_5
**EVALUATE**: A student writes this answer to "पिता को बेटी का बचपन क्यों याद आता है?": "क्योंकि वह बूढ़ा हो गया है और अकेला महसूस करता है।" Critique this answer using CBSE marking criteria. What is missing? What would you add to make it full marks?

## DIAGNOSTIC_ANSWER_5
**Critique**: The answer states a *plausible inference* but provides **zero textual evidence** — it could be written without reading the poem. CBSE awards 0/3 for such responses.  
**To fix**: Add (1) Evidence from Stanza 2: "नक़क वक़हु, दद&मप्नोक्ल&लअक्ष" (father sees daughter's first steps as his first joy), (2) Evidence from Stanza 4: "फिज़ एकुु, द लअक्ष ह्क्ज" (silence now weighs on him), (3) Explicit link: "बेटी के बचपन की याद ही अब उसके पास शेष 'लोतु' (अपने लोग) है।"  
**What a wrong answer reveals**: If a teacher accepts the student's answer as "correct because it makes sense," they reinforce the dangerous misconception that *inferential = opinion*. This student will fail CUET/board questions that demand "पाठ के आधार पर" (based on the text).

## DIAGNOSTIC_QUESTION_6
**CREATE**: Write an *original* inferential question on Stanza 2 of "लज्जत लेसर" that requires the solver to connect the father's observation of his daughter's gait ("फ्चहु इक़लह लिअं") to a deeper theme of the poem. Provide the ideal 3-point answer key.

## DIAGNOSTIC_ANSWER_6
**Created question**: "पद 2 में 'फ्चहु इक़लह लिअं' (लड़खड़ाते कदमों से चलना) का प्रयोग करके कवि पिता-पुत्री के संबंध की कौन-सी विशेषता उजागर करता है? पाठ के दो साक्ष्य देकर स्पष्ट कीजिए।"  
**Ideal answer key**:  
1. **Evidence 1**: "फ्चहु इक़लह लिअं" — बेटी के बचपन की भौतिक असहायता दर्शाता है।  
2. **Evidence 2**: "रु [क़यह, दद&एमपीएन~ओक्ल&लअक्ष" — पिता इसे अपनी "पहली खुशी" (first joy) मानता है, न कि बोझ।  
3. **Inference**: यह दर्शाता है कि पिता पुत्री की *निर्भरता* को स्नेह का अवसर मानता है — संबंध की परस्परता (reciprocity) का सूक्ष्म चित्रण।  
**What a poor answer reveals**: If a student writes "पिता बेटी से प्यार करता है" without linking "लड़खड़ाते कदम" to "पहली खुशी," they miss the *irony* (लड़खड़ाहट = खुशी का स्रोत) that the poem hinges on. This shows they cannot create questions that test *structural awareness* — a CUET-level skill.

## COMMON_MISCONCEPTION
**The "Inference = Personal Opinion" Trap**: Students believe inferential questions invite their feelings ("मुझे लगता है पिता दुखी है क्योंकि बुढ़ापा दुखद होता है"). They write answers with *zero textual quotes*, treating the poem as a trigger for general knowledge. **Why this error persists**: In lower classes, "inferential" questions often accept reasonable guesses (e.g., "Why did the character cry?" → "Because he was sad"). At Class 12 board/CUET level, *every* inferential mark requires a **text-to-inference chain**: "Line X says Y → which implies Z → therefore answer." Without the chain, the answer is "unsubstantiated" — a term examiners use to deny marks.

## ON_FAILURE
1. **Immediate fix**: Take the poem's 4 stanzas. Make a 2-column sheet: Column A = "Line/phrase quoted exactly", Column B = "What this *forces* me to conclude". Do this for 5 literal + 5 inferential questions from the NCERT exercise (p. 12).  
2. **Re-diagnostic**: After 2 days, attempt Diagnostic Questions 3 & 4 again *without notes*. If you still miss Evidence or Explanation steps, revisit **c11_hin_ar_cbse_01_012** (Class 11 Comprehension node) for the PEEL structure refresher.  
3. **Peer check**: Swap answers with a partner; they must highlight your Evidence (yellow) and Explanation (green). If either color is missing, rewrite.

## BUILDS_ON
Class 11 literal/inferential distinction (c11_hin_ar_cbse_01_012) by adding the PEEL writing structure and exam-specific evidence requirements.

## LEADS_TO
Critical thinking node (c12_hin_a_cbse_02_013) where inferences become arguments for thematic analysis, and Writing Skills node (c12_hin_a_cbse_02_014) where PEEL paragraphs become full essays.

## PREREQUISITE_NODE_IDS
c12_hin_a_cbse_02_002, c12_hin_a_cbse_02_003, c12_hin_a_cbse_02_004, c12_hin_a_cbse_02_005, c12_hin_a_cbse_02_006, c12_hin_a_cbse_02_007, c12_hin_a_cbse_02_008, c12_hin_a_cbse_02_009, c12_hin_a_cbse_02_010, c12_hin_a_cbse_02_011, c11_hin_ar_cbse_01_012
## PREREQUISITE_REASONS
c12_hin_a_cbse_02_002: Plot/narrative structure provides the sequence of events to locate literal answers.  
c12_hin_a_cbse_02_003: Setting/atmosphere supplies contextual clues for inferential mood shifts.  
c12_hin_a_cbse_02_004: Protagonist analysis (father) gives character motivation evidence.  
c12_hin_a_cbse_02_005: Supporting characters (mother, daughter) provide relational evidence.  
c12_hin_a_cbse_02_006: Primary theme (memory/loss) frames the *purpose* of inferential questions.  
c12_hin_a_cbse_02_007: Secondary themes (tradition, silence) offer additional inference lenses.  
c12_hin_a_cbse_02_008: Imagery/metaphor identification — inferential questions often target these.  
c12_hin_a_cbse_02_009: Irony/symbolism — key to deeper inferences (e.g., "लड़खड़ाहट = खुशी").  
c12_hin_a_cbse_02_010: Vocabulary meanings — literal questions frequently test glossary words.  
c12_hin_a_cbse_02_011: Grammar usage — helps parse complex lines for exact meaning.  
c11_hin_ar_cbse_01_012: Class 11 foundation on literal vs inferential classification and basic evidence citation.

## FORWARD_NODE_IDS
c12_hin_a_cbse_02_013, c12_hin_a_cbse_02_014, c12_hin_a_cbse_02_015
## FORWARD_REASONS
c12_hin_a_cbse_02_013: Critical thinking requires validated inferences as building blocks for thematic arguments.  
c12_hin_a_cbse_02_014: Writing skills uses PEEL paragraphs (mastered here) as essay body paragraphs.  
c12_hin_a_cbse_02_015: Speaking/listening discussions need evidence-based claims practiced in this node.

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
c12_history_01_001: History source analysis uses identical literal/inferential framework — "What does the inscription say?" (literal) vs "What does it reveal about kingship?" (inferential).  
c12_english_01_001: English Core comprehension (CBSE Section A) tests the same two question types with identical marking expectations (evidence + explanation).

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_01_012 -> c12_hin_a_cbse_02_012 -> c12_hin_a_cbse_02_013

## THIS_FORMULA
PEEL Paragraph for Inferential Answers: **P**oint (direct answer) → **E**vidence (exact quote with stanza/line) → **E**xplanation (how evidence proves point) → **L**ink (connect to theme/question focus)

## FORMULA_VARIABLES
P = Point (1 sentence answering the question directly)  
E = Evidence (1-2 lines quoted verbatim from poem, with stanza reference)  
E = Explanation (2-3 sentences reasoning from evidence to inference)  
L = Link (1 sentence tying back to poem's central idea or question's keyword)

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
linguistic

## CROSS_SUBJECT
N/A | Primary source analysis in history requires distinguishing explicit statements (literal) from historian's deductions (inferential) — same cognitive process as poem comprehension.  
 N/A | CBSE English Core Section A (Reading Comprehension) uses identical question taxonomy: factual (literal) vs interpretive (inferential) with same evidence-demand.
## PREREQ_CONCEPT
Ability to locate explicit information in a Hindi poetic text and distinguish it from implied meaning.

## PREREQ_BEFORE
Student must have read "लज्जत लेसर" fully, understood the glossary (शब्दार्थ), and completed Class 11 comprehension basics (c11_hin_ar_cbse_01_012).

## PREREQ_STUCK
If stuck on classifying a question, return to the T-chart method (Walkthrough) and the Class 11 node c11_hin_ar_cbse_01_012 for the literal/inferential decision tree.

## WORKED_EXAMPLE_1
**PROBLEM**: Answer the NCERT exercise question (p. 12, Q1): "लज्जत के ऊँचे-ऊँचे रूप का अपने शब्दों में वर्णन कीजिए।" (Describe the various forms of Lajjat in your own words.) — This is a *literal* question asking for explicit descriptions from the poem.  
**STEPS**:  
- Step 1: Identify question type — "अपने शब्दों में वर्णन" + "पाठ से" implied = literal recall of listed forms.  
- Step 2: Scan poem for "लज्जत" references — found in Stanza 1 ("लज्जत लेसर" as title/subject), Stanza 2 ("लज्जत" as daughter's gait), Stanza 3 ("लज्जत" as mother's teaching), Stanza 4 ("लज्जत" as memory).  
- Step 3: Extract explicit descriptions: (a) "नज़र फूक वकेवु उय" — visual radiance, (b) "फ्चहु इक़लह लिअं" — physical movement, (c) "एक़ि ल्स्त रसझ लो;अ जप" — oral instruction, (d) "फिज़ एकुु, द लअक्ष ह्क्ज" — auditory absence.  
- Step 4: Synthesize in own words: "कविता में 'लज्जत' चार रूपों में आती है: बेटी के बचपन की चमक, उसके लड़खड़ाते कदम, माँ की सीख, और अंत में पिता की स्मृति में उसकी गूँज।"  
- Step 5: Verify — each form maps to a distinct stanza; no external interpretation added.  
**REASONING**: Literal questions are "treasure hunts" — the answer is hidden in plain sight across stanzas. The skill is systematic scanning, not creativity.  
**ANSWER**: लज्जत के चार रूप: 1. बेटी के बचपन का उज्ज्वल रूप (पद 1), 2. उसके चलने का मनमोहक रूप (पद 2), 3. माँ द्वारा दी गई शिक्षा का रूप (पद 3), 4. पिता की स्मृति में शेष ध्वनि-रूप (पद 4)।

## WORKED_EXAMPLE_2
**PROBLEM**: Answer NCERT Q3: "'वकद'क क्न दज कुक एघ' में 'वकद'क' और 'एघ' शब्द किस ओर संकेत करते हैं?" (What do 'वकद'क' and 'एघ' indicate?) — This is *inferential*: words are given, but their *significance* is not explicitly explained.  
**STEPS**:  
- Step 1: Classify — asks for "संकेत" (indication/symbolism) = inferential.  
- Step 2: Locate words in Stanza 2: "वकद'क क्न दज कुक एघ" (time changed, made [her] grow).  
- Step 3: Build T-chart:  
  - Evidence: "वकद'क" (time) + "कुक एघ" (made grow/age) → Implication: inevitable passage of time transforming child to adult.  
  - Evidence: Same line follows "रु [क़यह, दद&एमपीएन~ओक्ल&लअक्ष" (first joy) → Implication: time *converts* joy into separation.  
- Step 4: Draft PEEL:  
  P: 'वकद'क' और 'एघ' समय की अनिवार्य गति और उसके परिवर्तनकारी प्रभाव को दर्शाते हैं।  
  E: पद 2 में "वकद'क क्न दज कुक एघ" — समय ने ही बेटी को बड़ा किया।  
  E: यह पंक्ति ठीक उस प्रसंग के बाद आती है जहाँ पिता बेटी के पहले कदम को "पहली खुशी" कहता है — अर्थात् समय वही खुशी छीन लेता है।  
  L: इस प्रकार ये शब्द कविता के केंद्रीय विषय "स्मृति और वियोग" को स्थापित करते हैं।  
- Step 5: Check — both words addressed, two evidences used, theme linked.  
**REASONING**: Inferential answers fail when students define words ("वकद'क = समय") instead of *interpreting function*. The T-chart forces evidence→inference mapping.  
**ANSWER**: 'वकद'क' (समय) और 'एघ' (बढ़ना/बदलना) मिलकर दर्शाते हैं कि समय की अनिवार्य गति बालपन को वयस्कता में बदल देती है, जिससे पिता की प्रिय 'पहली खुशी' (बेटी का बचपन) छिन जाती है — यह कविता के वियोग-विषय का मूल सूत्र है।

## WORKED_EXAMPLE_3
**PROBLEM**: A CUET-style question: "The poem 'लज्जत लेसर' uses the daughter's childhood as a metaphor for ______. Choose the option that *best* completes the sentence, and justify with two textual evidences."  
Options: (A) Lost innocence (B) Cyclic nature of time (C) Father's unfulfilled dreams (D) Mother's silent sacrifice  
**STEPS**:  
- Step 1: Recognize competitive exam format — requires *best fit* inference + evidence, not just recall.  
- Step 2: Evaluate each option against poem:  
  (A) "Lost innocence" — supported by Stanza 1→4 shift (innocence → silence) but narrow.  
  (B) "Cyclic nature of time" — Stanza 2 "वकद'क क्न दज कुक एघ", Stanza 3 mother teaching, Stanza 4 father becoming memory-keeper — *strongest structural fit*.  
  (C) "Father's unfulfilled dreams" — no textual support.  
  (D) "Mother's silent sacrifice" — mother appears only in Stanza 3; not central metaphor.  
- Step 3: Select (B). Build evidence chain:  
  Evidence 1: Stanza 2 "वकद'क क्न दज कुक एघ" — time transforms child.  
  Evidence 2: Stanza 3 "एक़ि ल्स्त रसझ लो;अ जप" — mother passes knowledge (cycle of teaching).  
  Evidence 3: Stanza 4 "फिज़ एकुु, द लअक्ष ह्क्ज" — father now holds memory (role reversal).  
- Step 4: Write justification: "The poem traces a cycle: daughter receives (Stanza 3) → grows (Stanza 2) → becomes memory (Stanza 4) → father becomes keeper of that memory, mirroring the mother's role. 'लज्जत' (essence/joy) thus represents the *cyclic transmission of love across generations*."  
- Step 5: Format for CUET — concise, evidence-tagged, theme-centered.  
**REASONING**: Competitive exams test *synthesis* across the whole text. The cyclic reading connects all 4 stanzas; other options rely on 1-2 stanzas only.  
**ANSWER**: Correct option: **(B) Cyclic nature of time**. Justification: (1) "वकद'क क्न दज कुक एघ" (पद 2) — समय पीढ़ी-दर-पीढ़ी परिवर्तन करता है; (2) "एक़ि ल्स्त रसझ लो;अ जप" (पद 3) — माँ बेटी को सिखाती है, जो पिता को याद है — यह ज्ञान-परंपरा का चक्र है।

## COMPETENCY_QUESTION_1
**QUESTION**: A Class 12 student answers the inferential question "पिता को बेटी का बचपन 'लज्जत' (सार/सत्व) क्यों लगता है?" with: "क्योंकि बचपन मीठा होता है और पिता बूढ़ा है।" Using the PEEL rubric, identify exactly which two components are missing and rewrite the answer to score 3/3 marks.  
**COMPETENCY**: Textual evidence integration and structured response writing (CBSE Competency: "Creates coherent arguments using textual evidence")  
**STEPS**:  
- Step 1: Map student's answer to PEEL — Point: present ("बचपन मीठा होता है"), Evidence: absent, Explanation: absent, Link: weak ("पिता बूढ़ा है" not text-linked).  
- Step 2: Identify missing components — **Evidence** (no quote) and **Explanation** (no reasoning from text).  
- Step 3: Retrieve evidence from poem: Stanza 1 "नज़र फूक वकेवु उय" (childhood = full light), Stanza 4 "फिज़ एकुु, द लअक्ष ह्क्ज" (now only memory's weight).  
- Step 4: Rewrite with all four PEEL components.  
**ANSWER**:  
**Missing**: Evidence (E) and Explanation (E).  
**Rewritten 3/3 answer**:  
P: पिता को बेटी का बचपन 'लज्जत' इसलिए लगता है क्योंकि वही उसके जीवन का एकमात्र सार्थक प्रकाश था।  
E: पद 1 में "नज़र फूक वकेवु उय" (पूरी दृष्टि में पूर्ण उजाला) और पद 4 में "फिज़ एकुु, द लअक्ष ह्क्ज" (मौन, केवल स्मृति का भार)।  
E: बचपन 'वकेवु उय' (पूर्ण प्रकाश) था जो अब 'लअक्ष' (भार/स्मृति) में बदल गया है — 'लज्जत' इसी विलीन हुए प्रकाश का सत्व है।  
L: इस प्रकार 'लज्जत' पिता के लिए खोए हुए संपूर्णता का प्रतीक बन जाता है।  
**DIFFICULTY**: medium

## COMPETENCY_QUESTION_2
**QUESTION**: Design a *literal* and an *inferential* question on Stanza 3 of "लज्जत लेसर" such that: (a) the literal question tests a glossary word, (b) the inferential question tests the irony in the mother's teaching, (c) both require stanza-specific evidence. Provide the answer key with marking scheme (1+2 marks).  
**COMPETENCY**: Question design and assessment literacy (CBSE Competency: "Frames questions to assess specific comprehension levels"; CUET: "Creates valid test items")  
**STEPS**:  
- Step 1: Analyze Stanza 3 for glossary words — "ल्स्त" (सीख/पाठ), "जप" (मंत्र/दोहराव), "लो;अ" (लोग/जन).  
- Step 2: Craft literal question targeting "ल्स्त": "पद 3 में 'ल्स्त' शब्द का शाब्दिक अर्थ क्या है? पाठ के शब्दार्थ खंड से लिखिए।" (1 mark)  
- Step 3: Identify irony — mother teaches "दूसरी कला" (second art) as first lesson; "सीख" (teaching) is called "कला" (art), blurring instruction and creativity.  
- Step 4: Craft inferential question: "पद 3 में माँ द्वारा 'पहली सीख' को 'दूसरी कला' कहना किस विडंबना (irony) की ओर संकेत करता है? दो पाठगत साक्ष्य देकर स्पष्ट कीजिए।" (2 marks)  
- Step 5: Create marking scheme: Literal = 1 mark for correct glossary meaning ("सीख/पाठ/उपदेश"). Inferential = 0.5 for identifying irony (teaching labeled as art), 0.5 for Evidence 1 ("एक़ि ल्स्त रसझ लो;अ जप"), 0.5 for Evidence 2 ("लो;अ ड्यक" — people call it art), 0.5 for Explanation (instruction framed as creative act).  
**ANSWER**:  
**Literal Q**: पद 3 में 'ल्स्त' का शाब्दिक अर्थ 'सीख/पाठ/उपदेश' है (शब्दार्थ: ल्स्त = 'कÕ;क] फ्कLरज')।  
**Inferential Q Answer Key**:  
- Irony: माँ जीवन की पहली व्यावहारिक सीख (अनुशासन) को 'कला' (रचनात्मक अभिव्यक्ति) कहती है — कर्तव्य को सौंदर्य में बदल देती है।  
- Evidence 1: "एक़ि ल्स्त रसझ लो;अ जप" — एक सीख को मंत्र/कला की तरह दोहराया जाता है।  
- Evidence 2: "लो;अ ड्यक" — समाज भी इसे 'कला' मानता है।  
- Explanation: यह विडंबना दर्शाती है कि परंपरा में अनुशासन को बोझ नहीं, सौंदर्य माना जाता है।  
**Marking**: Literal 1/1; Inferential 0.5 (irony ID) + 0.5 (Ev1) + 0.5 (Ev2) + 0.5 (Explanation) = 2/2.  
**DIFFICULTY**: hard