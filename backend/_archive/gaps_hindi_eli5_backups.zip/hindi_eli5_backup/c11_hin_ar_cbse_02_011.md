## DEFINITION
Grammar: Language Usage in the Text refers to the study of specific grammatical structures—such as direct-indirect speech conversion, perception verb classifications, and word order variations—as they appear in the story "Fe;k¡ ulh#íhu" to understand how language choices shape meaning and tone.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student can independently convert direct speech to indirect speech for complex sentences from the text, classify perception verbs by their semantic roles, and explain how word order changes emphasize different elements in a Hindi sentence.

## SCOPE_BOUNDARY
This node covers only the grammar exercises given in the NCERT "Hkk"kk dh ckr" section for Chapter 2: direct-indirect speech conversion, identification of perception verb types, and analysis of word order (kCn&Øe). It does not cover general Hindi grammar rules outside the text or vocabulary meanings (covered in node 010).

## WALKTHROUGH
Imagine you are reading the conversation between Fe;k¡ ulh#íhu and the teacher in the story. You notice the dialogue is in direct speech, but when you retell the story to a friend, you naturally shift to indirect speech. Start by identifying the reporting verb and the reported speech in a dialogue. Then learn the rules for tense change, pronoun change, and time/place adverb adjustments. Next, look at verbs like "ns[kuk" (to see) – the story uses "ns[k", "iQk¡d ns[k", "?kwjdj ns[k" – these are perception verbs with nuanced meanings. Finally, examine the sentence order: Hindi normally follows SOV, but the author sometimes uses OSV or other orders for emphasis. Practice with the given exercises to see how these grammar points function in the actual text.

## DIAGNOSTIC_QUESTION_1
What is the basic rule for changing a direct speech sentence in present tense to indirect speech when the reporting verb is in past tense?

## DIAGNOSTIC_ANSWER_1
The tense of the reported speech shifts one step back (e.g., present simple becomes past simple). A wrong answer (e.g., "tense doesn't change") reveals the student hasn't grasped the backshifting rule, which is fundamental for indirect speech conversion.

## DIAGNOSTIC_QUESTION_2
In the sentence "fe;k¡ ulh#íhu us iapg”kkjh vank”k ls flj fgyk;k", identify the perception verb and explain how its meaning differs from simple "ns[kuk".

## DIAGNOSTIC_ANSWER_2
The perception verb is "flj fgyk;k" (looked angrily). Unlike "ns[kuk" (neutral seeing), "flj fgyk;k" conveys an emotional attitude (anger) through the adverbial phrase "flj" modifying the act of seeing. A wrong answer that just says "ns[kuk" misses the nuance of perception verbs combined with adverbs to show manner.

## DIAGNOSTIC_QUESTION_3
Convert the following direct speech from the text to indirect speech: "fe;k¡ ulh#íhu us iapg”kkjh vank”k ls flj fgyk;kµ ^fudky ysaxs oDr FkksM+k] ij ;g rks dfg,] vkidks iwNuk D;k gS\*"

## DIAGNOSTIC_ANSWER_3
Step 1: Identify reporting verb: "iapg”kkjh vank”k ls flj fgyk;k" (past tense). Step 2: Reported speech: "fudky ysaxs oDr FkksM+k] ij ;g rks dfg,] vkidks iwNuk D;k gS". Step 3: Change pronouns: "vkidks" -> "muhks" (or "mEuhks" depending on context). Step 4: Backshift tenses: "ysaxs" (future) -> "ysaxh" (future in past). Step 5: Adjust time/place: "ij" (here) -> "vk¡". Step 6: Convert interrogative to indirect question: "iwNuk D;k gS" -> "D;k iwNuk gS". Final: "fe;k¡ ulh#íhu us iapg”kkjh vank”k ls flj fgyk;k fd og fudky ysaxh oDr FkksM+k vk¡ ;g rks dfg gS] mls D;k iwNuk gS". A wrong answer that doesn't backshift the future tense or change pronouns shows incomplete application of conversion rules.

## DIAGNOSTIC_QUESTION_4
Compare the word order in these two sentences from the text: (a) "fe;k¡ e'kgwj gSa NIiu fdLe dh jksfV;k¡ cukus osQ fy,A" (b) "fudky ysaxs oDr FkksM+k". Explain why the author might choose the order in (a) over the standard SOV.

## DIAGNOSTIC_ANSWER_4
Sentence (a) uses OSV order (Object-Subject-Verb): "NIiu fdLe dh jksfV;k¡" (object) placed before subject "fe;k¡" to emphasize the purpose. Sentence (b) follows standard SOV: "fudky" (adverb) "ysaxs" (subject) "oDr FkksM+k" (verb). The author uses OSV in (a) to highlight the object (making dolls) as the focus of Fe;k¡'s eagerness. A wrong answer that says both are SOV fails to recognize how word order shifts emphasis in Hindi.

## DIAGNOSTIC_QUESTION_5
Evaluate the effectiveness of using indirect speech in the narrative when the author writes: "ckn'kkg lyker us I+kQjek;kµ ^dksbZ ,slh ph”k cukvks tks u vkx ls iosQ] u ikuh ls cusA*". Would direct speech be more powerful here? Justify.

## DIAGNOSTIC_ANSWER_5
Indirect speech here summarizes the teacher's suggestion, maintaining narrative flow without breaking into dialogue. Direct speech would be more powerful if the exact words were crucial for character voice, but the author chooses indirect to convey the gist quickly. A wrong answer that says "direct is always better" ignores narrative pacing and the author's stylistic choice.

## DIAGNOSTIC_QUESTION_6
Create a new dialogue between Fe;k¡ and the teacher using at least three different perception verbs (e.g., ns[kuk, i<+uk, lquk) in direct speech, then convert the entire dialogue to indirect speech.

## DIAGNOSTIC_ANSWER_6
Example dialogue:
Fe;k¡: "eSa vki dks ns[k jgw gw¡A"
Teacher: "vki D;k i<+ jgs gSa\"
Fe;k¡: "eSa vkidh ckr lqu jgw gw¡A"
Converted indirect:
Fe;k¡ told the teacher that she was looking at him. The teacher asked what she was reading. Fe;k¡ replied that she was listening to his words.
A poor answer uses only "ns[kuk" repeatedly or fails to backshift tenses correctly, showing lack of creativity and grammar control.

## COMMON_MISCONCEPTION
Students often think that in Hindi indirect speech, the tense of the reported speech never changes if the reporting verb is in past tense, because Hindi has "mixed" tense behavior. Actually, Hindi does backshift tenses (e.g., present -> past, future -> future in past) but the rules are more flexible than English. They also confuse perception verbs with simple verbs, missing the adverbial modification that changes the verb's semantic role.

## ON_FAILURE
If a student struggles, first isolate the reporting verb and reported speech in a simple sentence. Practice tense backshifting with a table: present->past, past->past perfect, future->future in past. For perception verbs, create a chart: verb + adverb = specific perception (e.g., flj ns[kuk = glare, lko ns[kuk = gaze). For word order, take a standard SOV sentence and rearrange to OSV, VSO, etc., discussing emphasis shift each time.

## BUILDS_ON
Understanding of basic Hindi sentence structure (SOV) and direct speech punctuation from Class 10.

## LEADS_TO
Advanced narrative analysis in Chapter 3 where students examine author's language choices for thematic effect.

## PREREQUISITE_NODE_IDS
c11_hin_ar_cbse_02_001, c11_hin_ar_cbse_02_002, c11_hin_ar_cbse_02_010
## PREREQUISITE_REASONS
c11_hin_ar_cbse_02_001: Provides background context of the author and story setting, essential for understanding the register of dialogues.
c11_hin_ar_cbse_02_002: Knowledge of plot and narrative structure helps locate the exact scenes from which grammar examples are drawn.
c11_hin_ar_cbse_02_010: Vocabulary in context ensures students understand the key words used in the grammar exercises.

## FORWARD_NODE_IDS
c11_hin_ar_cbse_02_012, c11_hin_ar_cbse_02_013, c11_hin_ar_cbse_02_014, c11_hin_ar_cbse_02_015, c12_hin_a_cbse_04_011, c12_hin_a_cbse_05_011, c12_hin_a_cbse_09_011, c12_hin_a_cbse_11_011, c12_hin_a_cbse_12_011, c12_hin_a_cbse_16_011, c12_hin_a_cbse_17_011, c12_hin_al_cbse_02_011, c12_hin_ar_cbse_01_011, c12_hin_ar_cbse_02_011, c12_hin_ar_cbse_07_011, c12_hin_ar_cbse_09_011, c12_hin_ar_cbse_10_011, c12_hin_ar_cbse_11_011

## FORWARD_REASONS
c11_hin_ar_cbse_02_012: Comprehension questions require understanding of indirect speech to interpret reported dialogues.
c11_hin_ar_cbse_02_013: Critical thinking about author's language choices relies on grammar analysis skills.
c11_hin_ar_cbse_02_014: Writing skills tasks (e.g., diary entry, letter) need correct indirect speech and verb usage.
c11_hin_ar_cbse_02_015: Grammar/usage (dialect, register shifts) helps students notice how fe;k¡'s language performs his resistance.  
c12_hin_a_cbse_04_011: अगला तार्किक चरण: This node analyzes the grammatical structures, syntactic patterns, and language usage specific to th... इस नोड की अवधारणाओं को सीधे उपयोग/विस्तारित करता है।  
c12_hin_a_cbse_05_011: Class 11 practice with dialectal variations in modern poetry  
c12_hin_a_cbse_09_011: Practiced *kriya* (verb) analysis in modern prose — needed to recognize Braj verb morphology as variant system.  
c12_hin_a_cbse_11_011: Covers honorific plural vs. singular — needed for "ân;" vs "vè;kid" distinction.  
c12_hin_a_cbse_12_011: Practice with verb aspect (perfective/imperfective/habitual) in narrative contexts  
c12_hin_a_cbse_16_011: Covers honorific system (referent and address) in narrative — essential for Diagnostics 2, 3, 6.  
c12_hin_a_cbse_17_011: Practiced morphological breakdown of tadbhava/tatsama words — needed for etymological analysis here.  
c12_hin_al_cbse_02_011: Practiced honorific system analysis (tu/tum/aap, verb agreement) in a different memoir — direct transfer.  
c12_hin_ar_cbse_01_011: Reinforces grammatical pattern recognition in different poetic voices.  
c12_hin_ar_cbse_02_011: Reinforcement of grammar analysis in second chapter.  
c12_hin_ar_cbse_07_011: Reinforcement of sandhi/samas in poetic language.  
c12_hin_ar_cbse_09_011: Reinforces grammatical analysis of poetic language in varied contexts.  
c12_hin_ar_cbse_10_011: Practice with honorific usage analysis in Class 11 Chapter 2.  
c12_hin_ar_cbse_11_011: Reinforces particle analysis in dialogue contexts  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
none

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_02_001 -> c11_hin_ar_cbse_02_011 -> c11_hin_ar_cbse_02_012

## THIS_FORMULA
Direct to Indirect Speech Conversion Rule: (1) Change reporting verb tense if needed, (2) Adjust pronouns, (3) Backshift reported speech tense (present->past, past->past perfect, future->future in past), (4) Change time/place adverbs, (5) Convert interrogatives/imperatives appropriately.

## FORMULA_VARIABLES
Reporting Verb (RV): The verb introducing the speech (e.g., dgk, fgyk;k). Reported Speech (RS): The actual words spoken. Tense Shift: The systematic backshifting of verb tenses. Pronoun Adjustment: Changing 1st/2nd person to 3rd person as per context. Adverb Shift: Changing words like "ij" (here) to "vk¡" (there), "vkt" (now) to "cgknqj" (then).

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
linguistic

## CROSS_SUBJECT
c11_eng_writing_01 | Direct-indirect speech conversion rules are parallel in English and Hindi; understanding one reinforces the other.
c11_eng_grammar_02 | Perception verbs (see, watch, look) in English have similar nuanced distinctions as Hindi (ns[kuk, i<+uk, lquk).

## PREREQ_CONCEPT
Basic knowledge of Hindi parts of speech (verb, pronoun, adverb) and sentence structure (SOV).

## PREREQ_BEFORE
Student must be able to identify the subject, object, and verb in a Hindi sentence and recognize direct speech punctuation (quotation marks, reporting clause).

## PREREQ_STUCK
Review Class 10 Hindi grammar chapters on "okD; foU;kl" (sentence structure) and "vuqowQy izlax" (direct-indirect speech).

## WORKED_EXAMPLE_1
PROBLEM: Convert the following direct speech from the text to indirect speech: "fe;k¡ ulh#íhu us vk¡[kksa osQ oaQps ge ij isQj fn,A fiQj rjsjdj cksysµ^D;k eryc\ iwfN, lkgcµukuckbZ bYe ysus dgha vkSj tk,xk\ D;k uxhuklk”k osQ ikl\ D;k vkbZuklk”k osQ ikl\ D;k ehuklk”k osQ ikl\ ;k jI+kwQxj] j¡xjs”k ;k rsyh&racksyh ls lh[kus tk,xk\ D;k I+kQjek fn;k lkgcµ;g rks gekjk [kkunkuh is'kk BgjkA"

STEPS:
- Step 1: Identify the reporting verb: "cksys" (said) – past tense.
- Step 2: Identify the reported speech: Everything inside the quotes after "cksys".
- Step 3: Change pronouns: "ge" (we) -> "mUgsa" (them), "vkidks" (you) -> "muhks" (him/her), "gekjk" (our) -> "mUgk" (their).
- Step 4: Backshift tenses: "ysus" (to take - infinitive) remains infinitive? Actually "ysus dgha" is negative infinitive, but the verb "tk,xk" (will go) is future -> becomes "tk,xh" (would go). "gks" (is) -> "Fkk" (was). "Bgjk" (broke) past -> "Bgjk Fkk" (had broken).
- Step 5: Adjust adverbs: "iwfN," (just now) -> "cgknqj" (just then). "vkt" (now) if any -> "cgknqj".
- Step 6: Convert questions: The reported speech has multiple questions. In indirect, they become embedded questions with "D;k" or "fd". For example: "D;k eryc" -> "fd D;k eryc gS". "D;k uxhuklk”k osQ ikl" -> "fd D;k uxhuklk”k osQ ikl gS".
- Step 7: Reassemble into a coherent indirect speech paragraph.

REASONING: This example demonstrates the multi-step process required for a long dialogue with multiple sentences, questions, and pronoun shifts. Each step must be applied systematically to avoid errors.

ANSWER: fe;k¡ ulh#íhu us vk¡[kksa osQ oaQps ge ij isQj fn, vkSj cksys fd D;k eryc gS] iwfN, lkgcµukuckbZ bYe ysus dgha vkSj og tk,xhA og iwNuk fd D;k uxhuklk”k osQ ikl gS] D;k vkbZuklk”k osQ ikl gS] D;k ehuklk”k osQ ikl gS] ;k jI+kwQxj] j¡xjs”k ;k rsyh&racksyh ls lh[kus tk,xhA og I+kQjek fn;k fd ;g rks mUgk [kkunkuh is'kk Bgjk Fkk.

## WORKED_EXAMPLE_2
PROBLEM: Identify the perception verb and its nuance in each of these sentences from the text: (a) "fe;k¡ us ?kwjdj ns[kk" (b) "fe;k¡ ulh#íhu osQ psgjs ij fdlh ncs gq, vaèkM+ osQ vklkj ns[k" (c) "ge f[kfl;kuh g¡lh g¡lsµ ^gS rks dkI+kQh] ij ”kjk uke ysrs rks mls oDr ls feyk ysrsA*"

STEPS:
- Step 1: Locate the verb related to seeing/perceiving in each sentence.
- Step 2: For (a), verb is "?kwjdj ns[kk" – "?kwjdj" (surprised/startled) + "ns[kk" (saw). This indicates a sudden, involuntary glance due to surprise.
- Step 3: For (b), verb is "ns[k" (saw/looked at) with "vaèkM+ osQ vklkj" (with half-closed eyes). This indicates a deliberate, lazy, or contemptuous look.
- Step 4: For (c), the phrase "f[kfl;kuh g¡lh g¡ls" is not a perception verb but a speech verb ("said laughing"). However, the content includes "oDr ls feyk ysrs" (recognize from afar) which involves visual perception. The perception verb here is implied in "feyk ysrs" (recognize). The nuance is cognitive recognition rather than physical seeing.
- Step 4: Classify each: (a) Involuntary perception, (b) Volitional perception with attitude, (c) Cognitive perception (recognition).
- Step 5: Explain how the adverbial phrases modify the base verb "ns[kuk" to create specific perception types.

REASONING: The author uses varied perception verbs to reveal character emotions and power dynamics. Fe;k¡'s "?kwjdj ns[kk" shows her shock, while her half-eyed look shows defiance. The teacher's "feyk ysrs" shows authority.

ANSWER: (a) "?kwjdj ns[kk" – startled/involuntary glance. (b) "ns[k" with "vaèkM+ osQ vklkj" – deliberate, half-closed eye look showing disdain. (c) "feyk ysrs" (recognize) – cognitive perception based on prior knowledge.

## WORKED_EXAMPLE_3
PROBLEM: Analyze the word order variations in these sentences and explain the emphasis created: (i) "vki gh crkb,] jksVh idkus esa >wB dk D;k dke!" (ii) "ckn'kkg lyker us I+kQjek;kµ ^dksbZ ,slh ph”k cukvks tks u vkx ls iosQ] u ikuh ls cusA*" (iii) "fe;k¡ ulh#íhu dks ukuckb;ksa dk elhgk D;ksa dgk x;k gS\"

STEPS:
- Step 1: Identify the standard SOV order for each sentence if it were neutral.
- Step 2: For (i), standard: "vki jksVh idkus esa >wB dk D;k dke crkb," (You tell what is the work of >wB in knowing jksVh). Actual: "vki gh crkb,] jksVh idkus esa >wB dk D;k dke!" – The verb "crkb," (tell) is moved to after "vki gh", and the object clause "jksVh idkus esa >wB dk D;k dke" is fronted. This emphasizes the question content (the "what") and the particle "gh" emphasizes "vki".
- Step 3: For (ii), standard: "ckn'kkg lyker us I+kQjek;k fd dksbZ ,slh ph”k cukvks tks u vkx ls iosQ] u ikuh ls cusA" Actual: The reported speech is direct, so word order inside quotes is imperative: "cukvks" (make) at end. The reporting clause "ckn'kkg lyker us I+kQjek;k" is SOV. The direct speech order is standard for imperative (Object-Verb). No unusual shift.
- Step 4: For (iii), standard: "fe;k¡ ulh#íhu dks ukuckb;ksa dk elhgk D;ksa dgk x;k gS\" (Passive). Actual: Same as standard because it's a passive construction. The emphasis is on "fe;k¡ ulh#íhu" as topic.
- Step 5: Compare: (i) uses fronting of object clause for emphasis on the question; (ii) uses direct speech to preserve the exact imperative force; (iii) uses passive to focus on the recipient.
- Step 6: Conclude that word order in the text serves rhetorical purposes: highlighting conflict, authority, and thematic questions.

REASONING: This example combines word order analysis with narrative function, showing how grammar choices serve literary goals.

ANSWER: (i) Fronted object clause emphasizes the interrogative content; "gh" adds focus on "vki". (ii) Direct speech retains imperative force; reporting clause is standard SOV. (iii) Passive construction (standard order) emphasizes Fe;k¡ as the topic of the question.

## COMPETENCY_QUESTION_1
QUESTION: In the story, Fe;k¡ often speaks in direct speech, but the narrator reports her words in indirect speech in the exercise. Take the dialogue where Fe;k¡ says: "^vki nwljh i<+kbZ dh ckcr oqQN dg jgs Fks u!*" and convert it to indirect speech as if reported by the narrator. Then explain why the author might have chosen direct speech in the story but the exercise asks for indirect speech.

COMPETENCY: Application of direct-indirect speech conversion and meta-awareness of narrative technique.
STEPS:
- Step 1: Identify reporting verb (implied: "dgk" or "cksys") in past tense.
- Step 2: Convert pronouns: "vki" -> "mEuhks" (or "mUhks"), "nwljh" -> "nwljh" (same), "oqQN" -> "dqN".
- Step 3: Backshift tense: "dg jgs Fks" (past continuous) -> "dg jgs Fks" (past continuous remains? Actually past continuous in direct becomes past perfect continuous in indirect: "dg jgs Fks" -> "dg jgs Fks" - Hindi often keeps same). But "Fks" is past, so "dg jgs Fks" -> "dg jgs Fks" (no change? Better: "dg jgs Fks" -> "dg jgs Fks" - but standard rule: past continuous -> past perfect continuous: "dg jgs Fks" -> "dg jgs Fks" - Hindi doesn't have perfect continuous distinct form; we use "dg jgs Fks" for both). We'll note the nuance.
- Step 4: Change adverbs: none.
- Step 5: Convert to statement: "fd vki nwljh i<+kbZ dh ckcr dqN u dg jgs Fks".
- Step 6: Explain: Direct speech in story gives immediacy and character voice; indirect in exercise tests grammar skill and summarizes.

ANSWER: Indirect: fe;k¡ us dgk fd mEuhks nwljh i<+kbZ dh ckcr dqN u dg jgs Fks. Explanation: Direct speech dramatizes the scene; indirect speech condenses for reporting.

DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: The text uses the word "rkyhe" twice in the phrase "rkyhe dh rkyhe gh cM+h ph”k gksrh gS". Analyze the grammatical function of the repetition. Is it a case of reduplication for emphasis, or does it serve a syntactic purpose? Create two similar sentences using reduplication of a noun/adjective for emphasis, and convert both to indirect speech.

COMPETENCY: Analysis of morphological reduplication and its grammatical role, combined with speech conversion.
STEPS:
- Step 1: Identify "rkyhe dh rkyhe" as reduplication of the adjective "rkyhe" (small/minor) with "dh" (of) creating a distributive sense: "the smallest of the small" or "even the smallest".
- Step 2: Explain that this is not mere emphasis but a grammatical construction meaning "even the very smallest".
- Step 3: Create sentence 1: "ckjh dh ckJh gh ckr vPNh gksrh gS" (Even the smallest thing matters).
- Step 4: Create sentence 2: "?kj dh ?kj gh lq>ko gksrk gS" (Every single house is beautiful).
- Step 5: Convert sentence 1 to indirect speech with a reporting verb: "lkfgc us dgk fd ckjh dh ckJh gh ckr vPNh gksrh gS" (no tense change as universal truth).
- Step 6: Convert sentence 2: "eSa us dgk fd ?kj dh ?kj gh lq>ko gksrk gS" (if reporting verb past, "gksrk" -> "gksrk" or "Fkk"? Universal truth may not backshift).
- Step 7: Discuss how reduplication survives conversion unchanged because it's a fixed phrase.

ANSWER: "rkyhe dh rkyhe" is a reduplicative construction meaning "even the minutest". Created sentences: (1) "ckjh dh ckJh gh ckr vPNh gksrh gS" -> Indirect: "lkfgc us dgk fd ckjh dh ckJh gh ckr vPNh gksrh gS". (2) "?kj dh ?kj gh lq>ko gksrk gS" -> Indirect: "eSa us dgk fd ?kj dh ?kj gh lq>ko gksrk gS". Reduplication remains intact in conversion.

DIFFICULTY: hard