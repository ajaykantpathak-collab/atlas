## DEFINITION
Imagery is the use of vivid, sensory language that appeals to the five senses (sight, sound, smell, touch, taste) to create mental pictures and evoke physical sensations. Metaphor is a figure of speech that directly equates two unlike things by stating one *is* the other, transferring qualities from the vehicle (image) to the tenor (subject) without using comparative words like 'like' or 'as'.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student can independently identify specific images and metaphors in the poem, explain the sensory appeal of each image, analyze the tenor-vehicle relationship in each metaphor, and evaluate how these devices collectively construct the poem's central argument about the nature of 'the most difficult'.

## SCOPE_BOUNDARY
This node covers identification, classification, and analytical explanation of imagery (visual, auditory, tactile, organic, kinesthetic) and metaphor (simple, extended, implied) specifically within the poem "Sabse Karkh" (The Most Difficult). It does not cover simile, personification, symbolism, or irony (addressed in node 009), nor does it cover devices in other chapters.

## WALKTHROUGH
Imagine you are trying to describe the feeling of 'exhaustion' to someone who has never felt it. You wouldn't just say "I am tired"; you might say "My legs are lead pipes" (metaphor) or "The weight of the day presses on my eyelids like wet clay" (imagery). Open the poem to the third stanza where the poet writes "Sabse karkh og kadak hoti hai / Jo aapki deh par chalti rahti hai". Ask yourself: what sense does 'chalti rahti hai' (walks) appeal to? Kinesthetic. What is being compared to what in 'kadak' (stiffness)? Helplessness is equated to a stiff, living presence on the body. The key insight: in this poem, metaphors are not decorative; they *are* the argument. Each metaphor ('kadak', 'ankh', 'patta', 'hadri', 'ped', 'raat') redefines 'difficulty' not as an event but as a physical state of being.

## DIAGNOSTIC_QUESTION_1
Define 'metaphor' precisely using the terms 'tenor' and 'vehicle'. Give one example from the poem's first three stanzas identifying both elements.

## DIAGNOSTIC_ANSWER_1
A metaphor asserts an identity between two distinct things: the **tenor** (the subject being described) and the **vehicle** (the image lending its qualities). In stanza 3, "Sabse karkh hoti hai / Apni bekasi se bhar jana" – the tenor is 'the state of being filled with one's own helplessness' and the vehicle is implied 'a container filling up' or 'a weight', though the explicit metaphor begins in the next line with "kadak" (stiffness) as vehicle for helplessness. A wrong answer (e.g., "comparison using like/as") reveals confusion with simile; missing tenor/vehicle shows lack of technical vocabulary needed for board answers.

## DIAGNOSTIC_QUESTION_2
The poem repeats "Sabse karkh..." seven times, each time followed by a metaphor (kadak, ankh, patta, hadri, ped, raat). Explain in your own words why the poet uses a *series* of distinct metaphors instead of one extended metaphor for 'difficulty'.

## DIAGNOSTIC_ANSWER_2
The poet uses a **series of discrete metaphors** because 'the most difficult' is not a single monolithic experience but a spectrum of lived realities: physical (stiffness on body), perceptual (the unblinking eye), biological (the dried leaf), mortal (the bone reading elegy), historical (the tree holding dreams), and existential (the night with fire). A single extended metaphor would unify and simplify; the series *fragments* and *accumulates*, forcing the reader to confront difficulty in its manifold, inescapable forms. A wrong answer focusing only on 'variety' or 'beauty' misses the structural argument: the form *enacts* the content.

## DIAGNOSTIC_QUESTION_3
Analyze the metaphor in stanza 5: "Sabse karkh wo patta hota hai / Jo zindagi ke garmi ke baad / Ojhu hawaon mein sookhta hai". Identify the tenor, vehicle, and **two specific qualities transferred**. Then explain the effect of the qualifier "jis par aapki aankhen pankhon ki tarah nahi tikti".

## DIAGNOSTIC_ANSWER_3
**Tenor:** A human life after its prime (post-summer). **Vehicle:** A leaf drying in hot winds. **Qualities transferred:** 1) Fragility/brittleness (easily crumbled), 2) Irreversibility (drying is one-way), 3) Exposure to indifferent external forces (winds). The qualifier "eyes do not rest like feathers" introduces a **counter-image**: feathers imply lightness, gentleness, staying. The eyes *cannot* stay gently means the witness (the poet/reader) cannot offer soft comfort or even sustained attention to this drying life. It intensifies the tragedy: the difficult thing is not just the dying, but the *abandonment* of the dying. A wrong answer listing only 'sadness' misses the precise mechanistic transfer of qualities.

## DIAGNOSTIC_QUESTION_4
Compare the **tactile imagery** in "kadak jo aapki deh par chalti rahti hai / aapki saans mein jamti rahti hai" (stanza 4) with the **thermal/organic imagery** in "raat jisme vedna ka lajawab maat jalta hai" (stanza 8). How does the shift from *external pressure* to *internal combustion* change the reader's experience of 'difficulty'?

## DIAGNOSTIC_ANSWER_4
Stanza 4 uses **tactile-kinesthetic imagery**: 'walks on body' (pressure, movement, weight), 'settles in breath' (blockage, viscosity, choking). The difficulty is **imposed from outside** (circumstances) and **colonizes** the body. Stanza 8 shifts to **thermal-organic imagery**: 'fire burns', 'no extinguisher for loneliness', 'shadow of other falls in lap'. The difficulty is now **generated from within** (vedna) and **self-sustaining** (no extinguisher). The shift moves the reader from feeling *crushed by the world* to feeling *consumed by one's own pain*, culminating in the paradox that the night (difficulty) offers shelter to the other's shadow (empathy arrives only in the darkest hour). A wrong answer treating both as just 'painful images' misses the agency shift: victim of circumstance → vessel of burning consciousness.

## DIAGNOSTIC_QUESTION_5
Evaluate the claim: "The metaphor of 'hadri' (bone) in stanza 6 is the most effective in the poem because it combines mortality, witness, and vulnerability." Defend or refute using textual evidence from at least two other metaphors.

## DIAGNOSTIC_ANSWER_5
**Refute/Qualify:** The 'hadri' metaphor is potent (mortality: bone remains; witness: reads elegy on sorrows; vulnerability: melts like wax), but **'ped' (tree) in stanza 7** is equally effective structurally. The tree *leans on storm branches* (resilience under pressure), *holds swinging dreams* (carries collective futurity), and *receives generational wounds on its leaves* (absorbs history). Unlike the passive bone, the tree is **active endurance**. The 'raat' (night) metaphor in stanza 8 surpasses both in **philosophical depth**: it contains fire (pain), lacks self-extinguishing (inescapability), yet *receives the other's shadow* (ethical dimension: difficulty creates capacity for compassion). The 'most effective' depends on whether the criterion is individual mortality (hadri), collective resilience (ped), or existential paradox (raat). A wrong answer picking one without comparative criteria shows inability to evaluate literary merit analytically.

## DIAGNOSTIC_QUESTION_6
Write a 4-line stanza in Hindi (or English) that uses **one extended metaphor** for 'the most difficult thing in a student's life', incorporating **at least two sensory images** (e.g., auditory + tactile). Do not use 'like' or 'as'.

## DIAGNOSTIC_ANSWER_6
**Example (Hindi):**
*Sabse karkh wo deewar hoti hai*
*Jo raat bhar khurchti rehti hai kalam ki aawaz se,*
*Jiski eent-e-eent mein chipka hua hai pichhle saal ka darr,*
*Aur haath lagate hi haath jala deti hai umeed ki raakh.*

**Criteria for good answer:** 1) Single sustained metaphor (wall), 2) Two sensory images (auditory: 'khurchti aawaz', tactile/thermal: 'haath jala deti'), 3) No simile markers, 4) Tenor (exam pressure/fear of failure) illuminated by vehicle (burning wall built of fear). A poor answer uses simile ("jaise deewar"), lists disconnected images, or lacks sensory specificity.

## COMMON_MISCONCEPTION
Students often treat metaphors in this poem as **isolated decorative comparisons** (e.g., "helplessness is like stiffness") and identify them by spotting "X is Y" sentences. They miss that the metaphors form a **cumulative argument**: each redefines 'karkh' (difficult) by shifting the locus from *external events* (stanzas 1-2: court, eyes, sleep) to *internal somatic states* (stanza 3-4: stiffness, eye), to *biological mortality* (stanza 5-6: leaf, bone), to *collective history* (stanza 7: tree), to *existential paradox* (stanza 8: night). They also confuse the **refrain's negation** ("eshgur ki chhaya... nahi") as merely listing 'non-difficult things', not realizing it **clears the semantic ground** so the metaphors can define 'karkh' positively by accretion.

## ON_FAILURE
1. **Re-read stanza by stanza with a highlighter:** Mark every noun that follows "Sabse karkh..." (kadak, ankh, patta, hadri, ped, raat). These are the **vehicles**. 
2. **Create a two-column table:** Column A = Vehicle (image), Column B = Tenor (aspect of 'difficulty' it explains). Fill using the lines *around* the metaphor (e.g., for 'ankh': tenor = the witnessing consciousness that sees suffering but cannot act). 
3. **Trace the sensory mode** for each: kadak (tactile/kinesthetic), ankh (visual), patta (visual/thermal), hadri (tactile/thermal), ped (visual/kinesthetic), raat (thermal/organic). 
4. **Write one sentence** explaining the *trajectory*: "The metaphors move from bodily sensation to cosmic night, proving difficulty is not an event but a condition of existence."

## BUILDS_ON
c11_hin_ar_cbse_15_006 (Theme: Primary Theme) - understanding the central theme of 'endurance of the common man' is necessary to interpret why these specific metaphors are chosen.

## LEADS_TO
c11_hin_ar_cbse_15_009 (Literary Devices: Irony and Symbolism) - the metaphors established here become the vehicles for irony (e.g., the night that burns yet shelters) and symbols (the tree, the bone) in the next node.

## PREREQUISITE_NODE_IDS
c11_hin_ar_cbse_15_001, c11_hin_ar_cbse_15_002, c11_hin_ar_cbse_15_003, c11_hin_ar_cbse_15_006, c11_hin_ar_cbse_15_004, c11_hin_ar_cbse_15_007

## PREREQUISITE_REASONS
c11_hin_ar_cbse_15_001: Provides biographical context (Viren Dangwal's progressive poetry, labor background) essential to read 'hadri' and 'patta' as class-conscious images, not universal abstractions.
c11_hin_ar_cbse_15_002: Narrative structure shows the poem's movement from negation (what it's not) to affirmation (what it is), which structures the metaphor sequence.
c11_hin_ar_cbse_15_003: Setting/atmosphere (the laborer's world, the night, the storm) provides the literal referents for the metaphorical vehicles (hot winds, storm branches, night fire).
c11_hin_ar_cbse_15_006: Primary theme ('common man's endurance') is the tenor that all metaphors serve; without it, metaphors become ornamental.
c11_hin_ar_cbse_15_004: Imagery (shadow, fragrance, bowed walk) functions as the speaker's *eyes* — analyze character to unlock imagery.  
c11_hin_ar_cbse_15_007: Imagery and metaphor analysis requires identified themes to explain what the devices are DOING thematically.  

## FORWARD_NODE_IDS
c11_hin_ar_cbse_15_009, c11_hin_ar_cbse_15_013, c11_hin_ar_cbse_15_014, c11_hin_ar_cbse_15_010, c11_hin_ar_cbse_15_012, c11_hin_ar_cbse_15_015, c12_hin_a_cbse_04_008, c12_hin_a_cbse_05_008, c12_hin_a_cbse_15_008, c12_hin_a_cbse_16_008, c12_hin_ar_cbse_15_008

## FORWARD_REASONS
c11_hin_ar_cbse_15_009: Irony and Symbolism build directly on these metaphors (e.g., the 'night' metaphor becomes symbolic; the 'bone reading elegy' is ironic witness).
c11_hin_ar_cbse_15_013: Critical thinking requires analyzing how devices construct meaning; this node provides the device-level evidence.
c11_hin_ar_cbse_15_014: Writing skills (analytical paragraph) require the PEEL structure practiced here: Point (metaphor), Evidence (lines), Explanation (tenor-vehicle), Link (theme).
c11_hin_ar_cbse_15_010: Imagery and metaphor analysis skills are prerequisite for tracing how "रम्य" becomes "deceptive beauty" and "एजफल" becomes "living testimony."  
c11_hin_ar_cbse_15_012: Imagery analysis (bird, dead body, poem) supplies the concrete textual evidence required for inferential answers.  
c11_hin_ar_cbse_15_015: Imagery and metaphor analysis provides concrete textual evidence.  
c12_hin_a_cbse_04_008: Writing PEEL paragraphs for device analysis — board-exam answer structure.  
c12_hin_a_cbse_05_008: Provides CUET-style MCQ practice on imagery.  
c12_hin_a_cbse_15_008: Provides foundational definitions and simple identification practice for imagery and metaphor.  
c12_hin_a_cbse_16_008: Practices writing analytical paragraphs with PEEL structure.  
c12_hin_ar_cbse_15_008: Provides foundational definitions and identification practice for imagery/metaphor without which Class 12 analytical depth is impossible.  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
none

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_15_006 -> c11_hin_ar_cbse_15_008 -> c11_hin_ar_cbse_15_009

## THIS_FORMULA
Metaphor Analysis Formula: **Tenor (Subject) + Vehicle (Image) + Ground (Shared Qualities) + Tension (Difference) = Meaning Effect**
Imagery Classification: **Sensory Mode (Visual/Auditory/Tactile/Olfactory/Gustatory/Kinesthetic/Organic) + Precision (Concrete/Abstract) + Function (Decorative/Structural/Thematic)**

## FORMULA_VARIABLES
- Tenor: The abstract concept being described (e.g., 'helplessness', 'mortality').
- Vehicle: The concrete image used (e.g., 'stiffness', 'leaf', 'bone').
- Ground: The specific qualities transferred (e.g., brittleness, irreversibility).
- Tension: The dissimilarity that creates poetic friction (e.g., a bone 'reading' an elegy).
- Sensory Mode: Which of the 7 senses the imagery activates.
- Function: Whether the device decorates, structures the poem, or carries the theme.

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
analytical

## CROSS_SUBJECT
c11_history_industrialisation | The poem's imagery of 'leaf drying after summer', 'bone melting like wax', 'tree leaning on storm' reflects the historical condition of the industrial/agrarian laborer in post-colonial India – bodies worn by seasonal migration, bones consumed by labor, generations wounded by policy storms.
c11_civics_rights | The metaphor 'ankh jo teh pyaasi rehti hai / jiski awaaz bechare ko karuna se pukarti hai' embodies the civic tension between the *right to dignity* (the eye that witnesses) and *state apathy* (the night with no extinguisher), framing 'difficulty' as a failure of constitutional compassion.

## PREREQ_CONCEPT
Understanding the **tenor-vehicle distinction** in metaphor and the **seven sensory modes** of imagery, plus the poem's central theme of 'endurance of the ordinary'.

## PREREQ_BEFORE
Student must be able to distinguish metaphor from simile, list the 5+2 sensory modes, and state the poem's primary theme in one sentence.

## PREREQ_STUCK
Review the definitions of tenor/vehicle and the sensory imagery chart from Class 10 Poetics; re-read the poem summary in node 002 focusing on the shift from 'external events' to 'internal states'.

## WORKED_EXAMPLE_1
PROBLEM: Analyze the metaphor "Sabse karkh wo haddi hoti hai / Jo doosron ke darwazon tak pahunchne ke liye / Ejfla padhti hai / Becharo logon ke dukhon par / Jo mom ki tarah pighalti hai" (Stanza 6). Explain how the **vehicle (bone)** transforms the **tenor (the witness-survivor)** through three transferred qualities, and why the simile "mom ki tarah" (like wax) inside the metaphor matters.

STEPS:
- Step 1: Isolate the metaphor core: "Sabse karkh wo haddi hoti hai" – Tenor = the most difficult thing (a specific mode of existence); Vehicle = a bone (specifically, a bone that travels, reads, melts).
- Step 2: Map the narrative actions of the bone to the tenor's experience: (a) "doosron ke darwazon tak pahunchne ke liye" → the survivor must enter others' spaces (court, office, hospital) to seek justice/relief; (b) "ejfla padhti hai" → the survivor performs the ritual of mourning (elegy) for collective suffering, not just personal; (c) "becharo logon ke dukhon par" → the site of this reading is the body of the oppressed.
- Step 3: Identify three qualities transferred from bone to survivor: 1) **Residue/Remains**: Bone is what remains after flesh burns – the survivor is the remnant of a crushed life. 2) **Structural rigidity**: Bone holds shape – the survivor maintains form despite loss. 3) **Calcium/whiteness**: The 'white' of bone suggests stark truth, stripped of illusion.
- Step 4: Analyze the embedded simile "mom ki tarah pighalti hai" (melts like wax). This creates a **metaphor-simile hybrid**: the bone (rigid, permanent) *melts* (soft, impermanent). The tension: the survivor's endurance (bone) *dissolves* into empathy (wax) when confronting others' pain. The 'most difficult' is this **paradoxical vulnerability of the strong remnant**.
- Step 5: Connect to poem's trajectory: This is the 5th metaphor (after kadak, ankh, patta). It shifts from *passive suffering* (leaf drying) to *active witness* (bone reading elegy) – the difficult thing becomes an ethical act.

REASONING: This step-by-step forces the student to move from identification (what is compared) to functional analysis (what work does the comparison do) to structural placement (how it advances the poem's argument). The hybrid metaphor-simile is a senior-secondary nuance.

ANSWER: The metaphor equates the 'most difficult' with a **survivor's bone** that journeys to institutional doors, performs the elegy of the oppressed, and melts into wax on their wounds. Transferred qualities: 1) Mortal residue (what remains after life burns), 2) Structural integrity (endurance), 3) Stark truth (whiteness). The internal simile "like wax" fractures the vehicle's rigidity, revealing that the survivor's difficult endurance *liquefies* into compassion – the hardest thing is not surviving, but surviving *open-hearted*. This shifts the poem from somatic to ethical difficulty.

## WORKED_EXAMPLE_2
PROBLEM: The poem uses **organic imagery** (internal bodily sensations) in two key moments: "kadak jo aapki deh par chalti rahti hai / aapki saans mein jamti rahti hai" (stanza 4) and "raat jisme vedna ka lajawab maat jalta hai / aur uski apni tanhai ka koi bujhane wala nahi" (stanza 8). Compare how these two organic image clusters redefine 'karkh' (difficulty) from a **physical sensation** to an **existential condition**.

STEPS:
- Step 1: Define organic imagery: sensations arising from within the body (hunger, thirst, heartbeat, breathing, pain, temperature). Both clusters are organic.
- Step 2: Analyze Cluster 1 (stanza 4): 'kadak' (stiffness) walks on 'deh' (body) → **kinesthetic-organic** (movement felt inside). 'Jamti rahti hai saans mein' (settles in breath) → **respiratory-organic** (blockage, viscosity). Effect: Difficulty = **colonization of the body by an external force** (helplessness). The body is a *site* occupied.
- Step 3: Analyze Cluster 2 (stanza 8): 'Vedna ka maat jalta hai' (fire of pain burns) → **thermal-organic** (internal combustion). 'Tanhai ka koi bujhane wala nahi' (no extinguisher for loneliness) → **absence of relief** as organic fact. 'Doosre ki chhaya god mein' (other's shadow in lap) → **tactile-organic** (weight of another's presence). Effect: Difficulty = **self-generated, self-sustaining internal state** that paradoxically *hosts* the other.
- Step 4: Compare the agency: Cluster 1 – helplessness 'walks' and 'settles' (agent is the difficulty). Cluster 2 – pain 'burns' (agent is the pain/vedna), but the night 'receives' shadow (agent is the night/difficulty as host). The shift: from **passive occupation** to **active endurance that enables compassion**.
- Step 5: Synthesize: The organic imagery progression proves the poem's thesis: 'karkh' is not an event (court, sleep, eyes) but a **metabolic condition** – first imposed (stiffness in breath), then intrinsic (fire with no extinguisher), finally relational (holding the other's shadow).

REASONING: Senior-secondary analysis requires tracking *image clusters* across stanzas, classifying by sensory mode, and linking the shift in sensory logic to the thematic argument. This example models that multi-layered tracking.

ANSWER: Stanza 4's organic imagery (stiffness walking on body, settling in breath) frames difficulty as **somatic colonization** – an external helplessness invading and blocking the body's rhythms. Stanza 8's organic imagery (fire burning without extinguisher, receiving shadow in lap) reframes difficulty as **autonomous combustion** – an internal fire that sustains itself and becomes a site of hospitality. The trajectory: difficulty moves from *what happens to you* (colonization) to *what you are* (burning night that shelters). This elevates 'karkh' from suffering to **sacred endurance**.

## WORKED_EXAMPLE_3
PROBLEM: A board exam question asks: "The poem 'Sabse Karkh' uses a sequence of metaphors to define 'difficulty'. Discuss with reference to **any three metaphors**, showing how each **extends the definition** rather than merely illustrating it." Write a structured analytical response (approx. 120 words) using the PEEL method.

STEPS:
- Step 1: **Deconstruct the prompt**: Key terms = 'sequence of metaphors', 'extends the definition' (not illustrates), 'any three'. Need thesis: metaphors *accrue* to build a composite definition.
- Step 2: **Select three metaphors** spanning the trajectory: 1) 'Kadak' (stiffness) – somatic, 2) 'Patta' (leaf) – biological/mortal, 3) 'Raat' (night) – existential/ethical. (Avoid adjacent ones to show range).
- Step 3: **Draft PEEL for Metaphor 1 (Kadak)**: Point: The first positive metaphor redefines difficulty as somatic colonization. Evidence: "kadak jo deh par chalti... saans mein jamti". Explanation: Tactile-kinesthetic imagery makes helplessness a physical weight on the body, not an abstract concept. Link: This grounds 'karkh' in the laborer's flesh.
- Step 4: **Draft PEEL for Metaphor 2 (Patta)**: Point: The leaf metaphor extends difficulty to irreversible biological decay. Evidence: "zindagi ke garmi ke baad / ojhu hawaon mein sookhta". Explanation: Visual-thermal imagery transfers brittleness and exposure to indifferent nature; the qualifier "eyes don't rest like feathers" adds witness-abandonment. Link: Moves from *felt weight* to *seen mortality*.
- Step 5: **Draft PEEL for Metaphor 3 (Raat)**: Point: The night metaphor culminates in existential paradox. Evidence: "vedna ka maat jalta... tanhai ka bujhane wala nahi / doosre ki chhaya god mein". Explanation: Thermal-organic imagery makes difficulty a self-sustaining fire; yet the lap receiving the other's shadow transforms suffering into ethical capacity. Link: Final extension – difficulty as **compassion's dark hearth**.
- Step 6: **Synthesize concluding sentence**: The sequence does not illustrate a pre-existing definition; it *constructs* 'karkh' as a layered reality: bodily, mortal, ethical.

REASONING: This models the exact board-exam skill: selecting evidence across the text, using technical vocabulary (somatic, existential, qualifier), and structuring with PEEL. The 'extends not illustrates' distinction is the high-order discriminator.

ANSWER: The poem constructs 'karkh' through accretive metaphors. First, **'kadak' (stiffness)** uses tactile-kinesthetic imagery ("deh par chalti", "saans mein jamti") to define difficulty as **somatic colonization** – helplessness as a physical weight occupying the laborer's body. Second, **'patta' (leaf)** extends this to **biological irreversibility**: the visual-thermal image of a leaf drying in post-summer winds transfers brittleness and exposure to indifferent forces; the haunting qualifier "eyes do not rest like feathers" adds the tragedy of **unwitnessed decay**. Third, **'raat' (night)** achieves **existential paradox**: organic-thermal imagery ("vedna ka maat jalta", "tanahai ka bujhane wala nahi") makes difficulty a self-sustaining internal fire, yet the night's lap receiving "doosre ki chhaya" transfigures suffering into **ethical hospitality**. The sequence thus builds 'karkh' not as an event but as a layered condition: imposed weight → mortal fragility → sacred endurance.

## COMPETENCY_QUESTION_1
QUESTION: In the poem, the metaphor 'ankh' (eye) in stanza 4 is described as: "jo lac oqQN dekhati rahti hai / teh pyaasi rehti hai". A student writes: "This is a personification because the eye is given human qualities like watching and being thirsty." Identify the error in the student's classification and explain the correct device with its specific function here.

COMPETENCY: Conceptual Clarity & Device Discrimination
STEPS:
- Step 1: Identify the student's claim: labeling 'ankh' as personification.
- Step 2: Define personification: attributing human qualities to non-human entities.
- Step 3: Analyze the tenor of 'ankh': The 'ankh' *is* the witnessing consciousness (human or divine), not a non-human object. The metaphor equates 'the most difficult' WITH an eye. The eye *is* the vehicle for the difficult thing.
- Step 4: Explain why it's metaphor, not personification: The 'ankh' is the vehicle; the tenor is the difficult condition of *witnessing without relief*. The qualities 'watching constantly' and 'remaining thirsty' are *literal* for an eye, but *metaphorical* for the condition.
- Step 5: State the function: The metaphor externalizes the internal state of 'karkh' into a visual organ that sees suffering (lac oqQN) but cannot quench its thirst (teh pyaasi) – making 'difficulty' an **insatiable witness**.

ANSWER: The student confuses **vehicle with tenor**. Personification gives human traits to non-humans (e.g., "the wind screamed"). Here, the **metaphor** states "Sabse karkh wo ankh hoti hai" – the *most difficult thing IS an eye*. The 'eye' is the vehicle; the tenor is the condition of **perpetual, thirsty witnessing**. The eye's literal functions (watching, needing moisture) become the metaphorical qualities of 'karkh': total surveillance of suffering ("lac oqQN dekhati") and unquenchable need for justice/relief ("teh pyaasi"). The device is **metaphor** (identity assertion), functioning to objectify the abstract condition into a vulnerable, seeing organ.

DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: "The progression of metaphors in 'Sabse Karkh' moves from the **individual body** to the **collective history** to the **cosmic night**." Verify this claim by mapping the six positive metaphors (kadak, ankh, patta, haddi, ped, raat) onto these three domains. Then argue which domain delivers the poem's most radical political statement, using the imagery of the **tree (ped)** and the **night (raat)**.

COMPETENCY: Structural Analysis & Political Reading
STEPS:
- Step 1: Map the six metaphors to three domains:
  - Individual Body: **Kadak** (stiffness on body, in breath), **Ankh** (eye on body, voice), **Patta** (leaf/life), **Haddi** (bone/remains). (4 metaphors)
  - Collective History: **Ped** (tree holding generational dreams/wounds), **Haddi** (reading elegy on 'becharo logon' – plural, collective). (2 metaphors, overlapping)
  - Cosmic Night: **Raat** (night with fire, no extinguisher, receiving shadow). (1 metaphor)
- Step 2: Note the trajectory: The poem *begins* and *dwells* in the individual body (4/6), *expands* to collective via haddi/ped, *culminates* in cosmic night.
- Step 3: Analyze **Ped (Tree)** imagery: "tufan ki shakhon par jhukti" (leaning on storm branches) – resilience against state/historical violence; "rang-birange sapne jhoolte" – collective futurity; "hamari peedi ke zakhm patton par girte" – history inscribed on the living body. Political statement: **The people (tree) endure the storm (oppression) while nurturing dreams and absorbing wounds.**
- Step 4: Analyze **Raat (Night)** imagery: "vedna ka maat jalta" (pain's fire burns) – inextinguishable injustice; "tanahai ka bujhane wala nahi" – structural abandonment; "doosre ki chhaya god mein" – the night (difficulty) becomes the *only shelter* for the other's shadow (solidarity). Political statement: **In the absence of state care (no extinguisher), the oppressed night becomes the site of mutual refuge.**
- Step 5: Argue: The **cosmic night (raat)** delivers the most radical statement because it **refuses resolution**. The tree *endures*; the night *transforms suffering into hospitality*. The final stanza's return to the opening negations ("eshgur ki chhaya... nahi") *after* the night metaphor proves the night has *redefined* the terms: difficulty is not memory/pain/longing – it is the **darkness that burns yet shelters**, making compassion possible only in the utter absence of justice.

ANSWER: Mapping: Individual Body (kadak, ankh, patta, haddi); Collective History (haddi, ped); Cosmic Night (raat). The trajectory is somatic → historical → existential. The **tree (ped)** makes a powerful collective claim: the people absorb historical wounds ("hamari peedi ke zakhm") on their living tissue while holding "rang-birange sapne" – a metaphor for **resilient futurity**. But the **night (raat)** is more radical: it presents difficulty as an **inextinguishable fire (vedna)** in a structureless void ("tanahai ka bujhane wala nahi") that *nevertheless* becomes the **only sanctuary** ("doosre ki chhaya god mein"). This inverts the political: the state (which should provide extinguishers/shelter) is absent; the *suffering itself* (the night) becomes the site of solidarity. The poem's closing return to the opening negations *after* the night metaphor confirms: the night has *replaced* memory, separation, longing as the true definition of 'karkh' – **difficulty is the dark, burning hearth where the abandoned shelter each other.**

DIFFICULTY: hard