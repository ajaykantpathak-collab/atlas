## DEFINITION
Character analysis of the protagonist involves examining the central character's personality traits, motivations, conflicts, development arc, and relationships through textual evidence—actions, dialogue, internal thoughts, and others' reactions—to understand their role in advancing the narrative's themes.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student must independently identify at least four distinct character traits of Eksgu with specific textual evidence from different story sections, explain how each trait drives his decisions, and trace his psychological transformation from passive acceptance to quiet resistance across the narrative.

## SCOPE_BOUNDARY
This node covers Eksgu's character arc, internal conflicts, and relationships with father, mother, teacher, and Èkujke as revealed in the prescribed text. It does not cover supporting characters' independent arcs (node 005), thematic analysis (nodes 006-007), or literary devices (nodes 008-009).

## WALKTHROUGH
Imagine you're watching a classmate who never speaks up when the teacher humiliates him, but one day you notice his hands trembling—not from fear, but from something else. That's Eksgu. Start by listing every scene where Eksgu appears: classroom, home, interactions with father, mother, teacher, Èkujke. For each scene, ask: What does he *do*? What does he *say*? What does he *think* (narrator reveals)? What do others *say about him*? Then group these observations into patterns—notice how his silence in early scenes becomes calculated observation, how his obedience masks growing awareness. The key insight: Eksgu's protagonist status comes not from dramatic action but from the quiet accumulation of dignity against systemic erasure.

## DIAGNOSTIC_QUESTION_1
What is the protagonist's name in "Xyrk Ysgk" and what is his primary social identity marker that shapes his conflicts in the story?

## DIAGNOSTIC_ANSWER_1
The protagonist is Eksgu, a student from a marginalized caste community (implied by the teacher's casteist behavior and the father's fear of traditional authority). A wrong answer—naming Èkujke or the teacher as protagonist, or missing the caste dimension—reveals the student cannot distinguish central vs. peripheral characters or recognize how social identity drives the narrative's central conflict.

## DIAGNOSTIC_QUESTION_2
Explain in your own words why Eksgu does not react openly when the teacher humiliates him in class, despite the text stating he feels the injustice deeply.

## DIAGNOSTIC_ANSWER_2
Eksgu's silence stems from internalized caste conditioning ("tkfrxr ghurk osQ dkj.k èkujke us dHkh eksgu dks viuk izfr}a}h ugha le>k") and his father's explicit warning that resistance invites worse consequences. His survival strategy is endurance, not confrontation. A wrong answer attributing his silence to mere fear or weakness misses the structural oppression and intergenerational trauma the text establishes.

## DIAGNOSTIC_QUESTION_3
Apply the "show, don't tell" principle: Find two instances where the narrator *shows* Eksgu's intelligence through actions rather than stating it directly, and explain what each reveals.

## DIAGNOSTIC_ANSWER_3
1) Eksgu memorizes the poem "rsjs fnekx esa rks yksgk Hkjk gS" perfectly after one hearing while Èkujke struggles—showing sharp memory and literary sensitivity. 2) He silently observes the teacher's hypocrisy (caste prejudice vs. professional duty) without confronting—showing analytical maturity. A wrong answer quoting the narrator's direct statements ("eksgu buddhiman tha") fails to distinguish textual evidence from authorial commentary.

## DIAGNOSTIC_QUESTION_4
Analyze how Eksgu's relationship with his father evolves across three key scenes: the haircut incident, the poem recitation aftermath, and the final departure. What does this progression reveal about both characters?

## DIAGNOSTIC_ANSWER_4
Scene 1: Father drags Eksgu for haircut—authority enforced through physical control. Scene 2: Father hears teacher's casteist prediction ("eksgu ,d fnu cM+k vkneh cudj LowQy dk vkSj mudk uke Å¡pk djsxk") and feels helpless pride—authority cracking under systemic reality. Scene 3: Father lets Eksgu leave for city without blessing but without stopping him—silent acceptance of son's autonomy. This reveals father's love expressed through protection, not permission, and Eksgu's growth from object of control to agent of his own life.

## DIAGNOSTIC_QUESTION_5
Evaluate the claim: "Eksgu's final act of leaving for the city is an act of rebellion against caste oppression." Defend or refute using textual evidence.

## DIAGNOSTIC_ANSWER_5
Refute with nuance: It is *strategic withdrawal*, not open rebellion. Eksgu doesn't confront the teacher or announce defiance. He leverages education (the very tool of his oppression) to exit the village system—"xaxkjke bldk pquko Lo;a djrs Fks" shows he uses the master's tools. The text calls his transformation "u;k vè;k;" (new turn), not "vidroh" (rebellion). A purely rebellious reading ignores the text's emphasis on quiet dignity over dramatic resistance.

## DIAGNOSTIC_QUESTION_6
Create a 4-line diary entry from Eksgu's perspective on the night before he leaves for the city, capturing his dominant emotion without naming it directly. Use one concrete sensory detail from the story.

## DIAGNOSTIC_ANSWER_6
Sample: "The lantern flickers like the teacher's promise—/ Father's razor still smells of lemongrass and fear./ I pack the poem he hated, the one about broken chains./ Tomorrow the train takes what the village couldn't hold." A poor entry names emotions ("I feel scared but hopeful") or uses generic details not grounded in the text (no sensory anchor like lemongrass/razor/lantern/poem).

## COMMON_MISCONCEPTION
Students conflate "protagonist" with "hero who fights back visibly." They read Eksgu's silence as passivity and miss that his *endurance is agency* in a context where open resistance means destruction. This error comes from equating protagonist with Western heroic archetypes (overt rebellion, speeches, victories) rather than recognizing Indian literary traditions where *sahana* (endurance with awareness) and *maryada* (dignified restraint) are protagonist virtues. The text explicitly contrasts Eksgu's "bruh iqQrhZ" (great patience) with Èkujke's performative outrage.

## ON_FAILURE
If a student insists Eksgu is "weak" or "passive," do not lecture. Instead: 1) Have them re-read the haircut scene (p.56) and list every verb associated with Eksgu—notice "pyk Fkk" (went), "gkFk isQjrs gq," "iwjh rjg oqaQn gks pqdh" (became completely alert)—he's hyper-aware, not passive. 2) Compare his inner monologue during the poem incident (p.59) with Èkujke's outer reaction—whose response changes the power dynamic? 3) Ask: "If Eksgu shouted at the teacher, what happens next?" Guide them to see the text's answer: expulsion, family ruin, no education. His silence *is* the strategy that preserves his future.

## BUILDS_ON
Plot and narrative structure (node 002) provides the event sequence; setting and atmosphere (node 003) establishes the caste-rigid village world that shapes Eksgu's constraints.

## LEADS_TO
Supporting character analysis (node 005) requires understanding Eksgu as the reference point; primary theme analysis (node 006) uses his arc as the primary vehicle for caste/education themes.

## PREREQUISITE_NODE_IDS
c11_hin_ar_cbse_05_001, c11_hin_ar_cbse_05_002, c11_hin_ar_cbse_05_003
## PREREQUISITE_REASONS
c11_hin_ar_cbse_05_001: Context node establishes the caste-oppression framework essential to reading Eksgu's conflicts.
c11_hin_ar_cbse_05_002: Plot node provides the event timeline—haircut, classroom humiliation, poem recitation, departure—that structures Eksgu's character arc.
c11_hin_ar_cbse_05_003: Setting node establishes the village school/household spaces where power dynamics play out on Eksgu's body and psyche.

## FORWARD_NODE_IDS
c11_hin_ar_cbse_05_005, c11_hin_ar_cbse_05_006, c11_hin_ar_cbse_05_013, c11_hin_ar_cbse_05_007, c11_hin_ar_cbse_05_008, c11_hin_ar_cbse_05_009, c11_hin_ar_cbse_05_012, c11_hin_ar_cbse_05_014, c11_hin_ar_cbse_05_015, c12_hin_a_cbse_05_004, c12_hin_ar_cbse_05_005, c12_hin_ar_cbse_06_004, c12_hin_ar_cbse_10_004, c11_hin_ar_cbse_05_010

## FORWARD_REASONS
c11_hin_ar_cbse_05_005: Supporting characters (father, teacher, Èkujke, mother) are defined by their impact on Eksgu; analyzing them requires his baseline.
c11_hin_ar_cbse_05_006: Primary theme (caste vs. education, dignity vs. survival) is enacted through Eksgu's choices; theme analysis needs character evidence.
c11_hin_ar_cbse_05_013: Critical thinking questions demand protagonist-centered interpretation as the anchor for broader analysis.
c11_hin_ar_cbse_05_007: Understanding the protagonist Eksgu's characterization is essential to see how his experiences embody secondary themes like resilience and denial of education.  
c11_hin_ar_cbse_05_008: Protagonist analysis helps link imagery/metaphor to Eksgu's characterization.  
c11_hin_ar_cbse_05_009: Protagonist analysis (Eksgu) provides the character lens through which symbols like the cot are experienced.  
c11_hin_ar_cbse_05_012: Protagonist analysis supplies character-specific behavioral patterns that inform inferences about motivations.  
c11_hin_ar_cbse_05_014: Provides protagonist traits and key incidents needed as evidence in answers.  
c11_hin_ar_cbse_05_015: Protagonist analysis (Eksgu's silence/resistance) feeds directly into all three discussion points.  
c12_hin_a_cbse_05_004: Prior practice in protagonist analysis (Class 11 Antra Ch5) builds the methodological foundation (traits, evidence, development).  
c12_hin_ar_cbse_05_005: Class 11 protagonist node reinforces the protagonist-supporting character dynamic.  
c12_hin_ar_cbse_06_004: अगला तार्किक चरण: Character analysis of the protagonist in poetry involves identifying the central personified figure,... इस नोड की अवधारणाओं को सीधे उपयोग/विस्तारित करता है।  
c12_hin_ar_cbse_10_004: Practices unreliable narrator effect in "Usne Kaha Tha" — essential for reading HkfDru through narrator's evolving gaze.  
c11_hin_ar_cbse_05_010: If stuck, review the character analysis of Thakur Phoolchand Singh (c11_hin_ar_cbse_05_004) and Ehsan (c11_hin_ar_cbse_05_005) - every key vocabulary word in this chapter is filtered through their opposing positions.  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
No prior class nodes available for cross-subject linkage in Hindi Aroh.

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_05_002 -> c11_hin_ar_cbse_05_004 -> c11_hin_ar_cbse_05_005: Plot provides events; protagonist analysis interprets them through Eksgu; supporting character analysis examines others in relation to him.

## THIS_FORMULA
Character Trait = (Repeated Action Pattern + Internal State Evidence + Relational Impact) × Narrative Progression

## FORMULA_VARIABLES
- Repeated Action Pattern: Observable behaviors across 3+ scenes (e.g., silent observation, memorization, compliance-with-awareness)
- Internal State Evidence: Narrator's access to thoughts/feelings (e.g., "eksgu dks f=kyksd flag ekLVj dh Hkfo";ok.kh ij iwjk ;dhu Fkk")
- Relational Impact: How trait affects other characters' responses (e.g., father's shift from control to silent letting-go)
- Narrative Progression: Trait's evolution from story beginning to end (passive silence → strategic silence → agency-through-exit)

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
analytical

## CROSS_SUBJECT
c11_history_caste_social_reform | Eksgu's experience mirrors 19th-20th century Dalit autobiographies (e.g., Ambedkar's school memories, Om Prakash Valmiki's "Joothan") where education is both liberation tool and site of caste humiliation.
c11_sociology_social_stratification | The teacher-student interaction illustrates "institutional discrimination"—formal equality (same classroom) masking substantive inequality (caste-based pedagogy)—a core concept in stratification theory.

## PREREQ_CONCEPT
Understanding that in realist fiction, character is revealed through *patterned behavior under constraint*, not isolated dramatic moments.

## PREREQ_BEFORE
Student must have completed plot summary (node 002) and identified all scenes featuring Eksgu.

## PREREQ_STUCK
If stuck, return to the plot timeline (node 002) and mark every page reference where Eksgu appears—this visual map prevents missing quiet but crucial scenes like the final lantern moment (p.64).

## WORKED_EXAMPLE_1
PROBLEM: Using the PEEL structure, write a 100-word analysis answering: "How does the haircut scene (p.56) establish Eksgu's core conflict between filial duty and selfhood?"

STEPS:
- Step 1: Identify the scene's key actions—Father commands haircut; Eksgu goes but notices barber's "èki~&èki~ vkok"k" (mechanical routine); he sees his reflection in "gFkkSM+s dh èki~&èki~ vkok"k" and "fugkbZ ij iM+rh gFkkSM+h dh [kud" (mirror on bicycle handle).
- Step 2: Select evidence for Point: The mirror image is the only moment Eksgu *sees himself* in the scene—he's object of father's will, not subject of his own.
- Step 3: Explain: The bicycle-mirror distortion symbolizes how village tradition (father's authority) reflects a warped self-image—Eksgu as "czkã.k Vksys" (lower caste) body, not individual.
- Step 4: Link: This establishes the central tension: Eksgu's body belongs to caste-order (father/teacher), but his consciousness (noticing the distorted reflection) already exceeds it.
- Step 5: Verify against text: Later scenes confirm—teacher sees caste-body; father sees duty-body; only Eksgu (and much later, Xaxkjke) sees thinking-self.

REASONING: The PEEL structure forces evidence-first reasoning. The mirror detail is easily missed but is the scene's only interiority marker—critical for protagonist analysis.

ANSWER:
The haircut scene establishes Eksgu's core conflict through a single visual detail: his distorted reflection in the bicycle's mirror. (Point) While his father enforces caste-conformity ("czkã.k Vksys osQ yksxksa dk f'kYidkj Vksys esa mBuk"), Eksgu notices the "fugkbZ ij iM+rh gFkkSM+h dh [kud"—the mirror on the handlebar showing his face. (Evidence) This fleeting self-glimpse, mechanical and warped, mirrors how tradition reduces him to a caste-body rather than a self. (Explanation) His compliance is physical; his awareness is already separate. (Link) The scene plants the split between external submission and internal observation that drives his entire arc.

## WORKED_EXAMPLE_2
PROBLEM: Trace Eksgu's "silence" across three scenes—classroom humiliation (p.57), poem recitation (p.59), final departure (p.63)—and explain how its *meaning* changes each time.

STEPS:
- Step 1: Classroom silence (p.57): Teacher mocks his name/caste; Eksgu "Hk_h ls nwj gVdj" (jumps up startled) but speaks not. Narrator notes: "èkujke us dHkh eksgu dks viuk izfr}a}h ugha le>k" (Èkujke never understood Eksgu's silence). Meaning: Silence as *survival reflex*—internalized oppression.
- Step 2: Poem recitation silence (p.59): Teacher forces Èkujke to recite; Eksgu knows it perfectly ("cksyk] ^ekLlkc Hkh D;k vkneh Fks yyk!"). He stays silent while Èkujke fails. Meaning: Silence as *superior knowledge withheld*—strategic invisibility.
- Step 3: Departure silence (p.63): Father asks nothing; Eksgu says nothing; "g¡lqos dks gkFk esa ysdj og fiQj ogha cSBk jgk tSls mls okfil tkus dh dksbZ tYnh u jgh gks" (sits with mother like he has nowhere to go). Meaning: Silence as *completed transition*—no need to explain, the act of leaving speaks.
- Step 4: Synthesize: Silence evolves from imposed → chosen → transcendent. It's not absence of voice but presence of a different language—action.
- Step 5: Connect to protagonist definition: The character who *acts through silence* centers the narrative's moral vision.

REASONING: Tracking a single motif (silence) across the arc reveals character development more precisely than listing traits. The three scenes form a structural triad: school, home, threshold.

ANSWER:
Eksgu's silence transforms across the narrative triad. In class (p.57), it's a survival reflex—"Hk_h ls nwj gVdj" but no words—marking internalized caste terror. At the poem recitation (p.59), silence becomes strategic: he knows "rsjs fnekx esa rks yksgk Hkjk gS" perfectly while privileged Èkujke fails, proving his competence exceeds the teacher's caste-blindness. At departure (p.63), silence transcends explanation—"g¡lqos dks gkFk esa ysdj og fiQj ogha cSBk jgk"—the leaving itself is his voice. The protagonist's journey: from silenced subject to silent knower to self-authored agent.

## WORKED_EXAMPLE_3
PROBLEM: Compare Eksgu and Èkujke as foil characters. Using four textual contrasts, explain how Èkujke's privileges expose the structural barriers Eksgu navigates, and why the text refuses to make Èkujke a villain.

STEPS:
- Step 1: Contrast 1—Teacher's expectation: "f=kyksd flag ekLVj dHkh&dHkkj gh ml ij fo'ks"k è;ku nsrs Fks" (teacher gave Èkujke special attention) vs. Eksgu's "vfèkdkj" (rightless) status. Structural barrier: Teacher invests in caste-privileged potential.
- Step 2: Contrast 2—Poem recitation: Èkujke fails despite coaching ("rh rhljh lh<+h rd igq¡prs&igq¡prs og fiQj yM+[kM+k x;k"); Eksgu knows it effortlessly. Irony: Merit exists where teacher doesn't look.
- Step 3: Contrast 3—Father's reaction: Èkujke's father (implied) supports education; Eksgu's father fears it ("cpiu ls gh eu esa cSBk nh xbZ tkfrxr ghurk"). Structural barrier: Intergenerational trauma vs. intergenerational capital.
- Step 4: Contrast 4—Final moment: Èkujke disappears from narrative; Eksgu leaves for city. Text refuses villainy: Èkujke is "izfr}a}h" (victim) of same system—he performs caste superiority but cracks under pressure ("vleatl vkSj èkeZ&ladV dh fLFkfr").
- Step 5: Synthesize: Èkujke is not antagonist but *mirror*—showing what Eksgu could be with privilege, and what privilege does to consciousness (makes it fragile).
- Step 6: Connect to theme: The foil structure proves caste harms *both* castes—Èkujke's "vleatl" (restlessness) is the flip side of Eksgu's "bruh iqQrhZ."

REASONING: Foil analysis requires moving beyond "good vs. bad" to "privileged vs. oppressed within same system." The text's humanization of Èkujke (his fear, his father's pressure) is deliberate—it makes caste a structure, not a personal failing.

ANSWER:
Èkujke is Eksgu's structural foil, not moral antagonist. Four contrasts: (1) Teacher's investment: Èkujke gets "fo'ks"k è;ku"; Eksgu gets "vfèkdkj" (denial of rights). (2) Competence: Èkujke crumbles memorizing "rsjs fnekx esa rks yksgk Hkjk gS" despite coaching; Eksgu knows it innately—merit ignored by caste gaze. (3) Paternal support: Èkujke's father enables; Eksgu's father fears "tkfrxr ghurk" consequences. (4) Outcome: Èkujke ends in "vleatl vkSj èkeZ&ladV" (restlessness, broken resolve); Eksgu exits with "u;k vè;k;" (new turn). The text refuses villainy because Èkujke's fragility proves caste deforms the privileged too—his "izfr}a}h" (victimhood) mirrors Eksgu's. The foil structure makes caste the antagonist, not individuals.

## COMPETENCY_QUESTION_1
QUESTION: A Class 11 student writes: "Eksgu is a weak character because he never stands up to his father or teacher. Real protagonists fight back." Using three specific textual moments, refute this claim by showing how the text redefines strength for a Dalit boy in a caste-rigid village.

COMPETENCY: Critical interpretation with textual evidence (CBSE Competency: Analytical Reasoning)

STEPS:
- Step 1: Identify the student's flawed premise: equating strength with overt confrontation.
- Step 2: Select Moment 1 (p.57): Eksgu endures teacher's humiliation but memorizes the poem perfectly—strength as *intellectual refusal to be erased*.
- Step 3: Select Moment 2 (p.59): Eksgu watches Èkujke fail the poem he knows—strength as *witnessing privilege's hollowness without gloating*.
- Step 4: Select Moment 3 (p.63-64): Eksgu leaves for city without fanfare—strength as *strategic exit preserving future agency*.
- Step 5: Synthesize: The text defines strength as "bruh iqQrhZ vkSj vkdfLed <ax" (great patience and firm resolve)—endurance with purpose.

ANSWER:
The claim imposes a privileged definition of strength. The text offers a situated one: (1) Classroom (p.57): Eksgu absorbs "tkfrxr foHkktu" (caste discrimination) but masters "rsjs fnekx esa rks yksgk Hkjk gS"—his mind remains uncaptured. (2) Poem scene (p.59): He watches Èkujke's coached failure silently—his silence holds *knowledge*, not emptiness. (3) Departure (p.64): "èkujke dh ladksp] vleatl vkSj èkeZ&ladV dh fLFkfr ls mnklhu eksgu larq"V Hkko ls vius yksgs osQ NYys dh =kqfVghu xksykbZ dks tk¡p jgk Fkk"—he leaves with "pure, flawless resolve." Strength here is not loud resistance but quiet preservation of selfhood against a system designed to deny it. The protagonist *is* the redefinition.

DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: The story ends with Eksgu sitting by the lantern, "ltZd dh ped" (lamp's glow) in his eyes—"ftlesa u LièkkZ Fkh vkSj u gh fdlh izdkj dh gkj&thr dk Hkko" (no flicker, no tremor). Explain how this final image resolves the central tension between *external erasure* (caste system) and *internal formation* (selfhood) developed across the narrative. Connect to the title "Xyrk Ysgk."

COMPETENCY: Thematic synthesis through character analysis (CBSE Competency: Interpretive Insight)

STEPS:
- Step 1: Decode the lantern image: Steady light in darkness = selfhood sustained without external validation.
- Step 2: Trace "external erasure" moments: Teacher erases name/identity ("eksgu ugha vk;k vkt"); father erases autonomy (haircut); village erases future ("eksgu ,d fnu cM+k vkneh cudj LowQy dk vkSj mudk uke Å¡pk djsxk").
- Step 3: Trace "internal formation": Memorizing poem (intellectual sovereignty); observing teacher's hypocrisy (critical consciousness); choosing city (agency).
- Step 4: Connect to title: "Xyrk Ysgk" (Crooked Lane/Alley)—the village lane is crooked (caste-twisted); Eksgu's straight gaze ("ltZd dh ped" without tremor) is the correction.
- Step 5: Conclude: The protagonist's arc completes when internal light no longer needs external fuel—he becomes his own "xyrk" (path) out of the crooked lane.

ANSWER:
The lantern's steady glow resolves the tension by making Eksgu's selfhood *self-sustaining*. Throughout the story, external forces attempt erasure: teacher predicts "eksgu ugha vk;k vkt" (he won't come tomorrow); father enforces caste-conformity; village scripts his future as "LowQy dk vkSj mudk uke Å¡pk" (school peon, nameless). Each time, Eksgu's internal formation counters: he memorizes the poem the teacher uses to humiliate (reclaiming language); he sees through Èkujke's coached performance (critical clarity); he chooses the city (refusing the script). The title "Xyrk Ysgk"—the crooked lane of caste—is the external darkness. The final image: "ltZd dh ped... u LièkkZ Fkh vkSj u gh fdlh izdkj dh gkj&thr dk Hkko"—a light that doesn't flicker because it's not fed by others' approval. Eksgu *becomes* the straight path out of the crooked lane. The protagonist's journey ends where his inner light matches the world's darkness—steady, tremourless, self-authored.

DIFFICULTY: hard