## DEFINITION
Vocabulary in Context refers to the skill of determining the precise meaning of key terms by analyzing their usage within the specific textual, cultural, and environmental framework of the chapter, rather than relying on dictionary definitions alone. In "jktLFkku dh jtr cw¡nas," this involves understanding technical terms related to desert hydrology (ikyjikuh, ikrkyikuh, jstk.khikuh), traditional engineering ([khai, vkM+kd, pj[kh), and socio-ecological systems (futh, lkoZtfud laifÙk) as they function within the oasis ecosystem.

## COGNITIVE_LEVEL
understand

## MASTERY_CRITERIA
The student must be able to: (1) Identify 8-10 key terms from the text and explain each using textual evidence showing how the author defines or illustrates it in context, and (2) Distinguish between closely related terms (e.g., ikyjikuh vs ikrkyikuh vs jstk.khikuh) by explaining the specific hydrological conditions each represents.

## SCOPE_BOUNDARY
This node covers vocabulary acquisition strategies specific to the chapter's technical, cultural, and ecological terminology. It does NOT cover general Hindi vocabulary building, grammar rules (covered in node 011), or literary device analysis (covered in nodes 008-009). It focuses exclusively on how key terms operate within the desert/oasis discourse of this text.

## WALKTHROUGH
Imagine you're reading a science article about groundwater but every third word is a technical term like "artesian aquifer" or "recharge zone" — you'd feel lost. This chapter is exactly that: a geo-hydrological treatise wrapped in narrative. Start by asking: "Which words does the author repeat when explaining HOW water reaches the surface?" Circle those. Then ask: "Which words describe the human response to that water?" Those are your two vocabulary clusters — hydrological and socio-cultural. The key insight: in this text, words are not labels; they are functional components of the oasis system. The author defines ikyjikuh by contrasting it with ikrkyikuh, and defines jstk.khikuh by describing what happens when you drill through impermeable rock. You learn the vocabulary by tracing these explanatory moves.

## DIAGNOSTIC_QUESTION_1
From the text, recall the three categories of groundwater (ikuh) classified by the 'kkL=k (scientific system) mentioned in the chapter. Write their Hindi terms and one distinguishing feature of each from the passage.

## DIAGNOSTIC_ANSWER_1
Correct answer: (1) ikyjikuh — surface water from rain, flows in rivers/streams, stored in ponds/tanks; (2) ikrkyikuh — groundwater below surface, extracted via wells; (3) jstk.khikuh — artesian water trapped between impermeable layers under pressure, rises automatically when tapped. A wrong answer listing only two categories or confusing ikrkyikuh with jstk.khikuh reveals the student hasn't tracked the author's explicit classification system in the third paragraph of the reference text.

## DIAGNOSTIC_QUESTION_2
The author writes: "jstk.khikuh [kfM+;k i^h osQ dkj.k ikrkyhikuh ls vyx cuk jgrk gSA" Explain in your own words WHY jstk.khikuh forms differently from ikrkyikuh, using the geological conditions described in the text.

## DIAGNOSTIC_ANSWER_2
Correct answer: jstk.khikuh forms when water is trapped between two impermeable rock layers (ckYVh) under pressure, so when a well pierces the upper layer, pressure forces water up. ikrkyikuh is simply groundwater in permeable rock without confining pressure. A wrong answer saying "both come from underground" misses the critical distinction: confining pressure vs. gravity-fed storage. This misconception shows the student hasn't visualized the geological cross-section the author describes.

## DIAGNOSTIC_QUESTION_3
In the sentence "oqaQbZ dh xgjkbZ esa py jgs esgurh dke ij ogk¡ dh xjeh dk vlj iM+sxkA," the word "esgurh" modifies "dke." Using context clues from the surrounding sentences (laborers working in chains, extreme heat, date palm construction), infer the precise meaning of "esgurh" and explain which textual evidence supports your inference.

## DIAGNOSTIC_ANSWER_3
Correct answer: "esgurh" means arduous/backbreaking/grueling. Evidence: (1) "rhl&iSarhl gkFk xgjh [kqnkbZ" — 2-3 km long trenches, (2) "bruh ladjh txg esa [kksnus dk dke oqQYgkM+h ;k iQkoM+s ls ugha gks ldrk" — cannot be done by machines, (3) "psyokath dh ihB vkSj Nkrh ls" — using hands and feet. A wrong answer like "difficult" without citing the physical specifics shows the student treats vocabulary as isolated word-meaning pairs rather than context-embedded concepts.

## DIAGNOSTIC_QUESTION_4
Compare how the author uses "futh" (tradition) in two contexts: (a) "futh vkSj lkoZtfud laifÙk dk foHkktu djus okyh eksVh js[kk" and (b) "futh gksrs gq, Hkh lkoZtfud {ks=k esa oaqQb;ksa ij xzke lekt dk vaoqQ'k yxk jgrk gSA" Analyze whether "futh" carries the same connotation in both or shifts meaning.

## DIAGNOSTIC_ANSWER_4
Correct answer: In (a), futh = living tradition of collective governance (eksVh js[kk = customary law). In (b), futh = historical legacy that persists as social inertia ("yxk jgrk gS" = casts a shadow). The shift is from active regulatory system to residual cultural weight. A wrong answer treating both as "custom" misses the author's critique: traditional law once managed water equitably, but now village power structures exploit that legacy. This tests whether the student tracks semantic shift across the text's argument arc.

## DIAGNOSTIC_QUESTION_5
The chapter ends with: "blh ueh ls lky&Hkj oqaQb;ksa esa ikuh HkjsxkA" Evaluate whether "lky&Hkj" (perennial/year-round) is an accurate description of oasis water supply based on the hydrological evidence the author presents earlier. Defend your judgment with two textual references.

## DIAGNOSTIC_ANSWER_5
Correct answer: No, "lky&Hkj" is an aspirational claim, not hydrological fact. Evidence against: (1) "fnu Hkj esa ,d oqaQbZ eqf'dy ls bruk gh ikuh tek dj ikrh gS fd mlls nks&rhu ?kM+s Hkj losaQ" — one oasis yields water for only 2-3 months, (2) "NksVs O;kl dh oqaQbZ esa èkhjs&èkhjs fjl dj vk jgk ikuh nks&pkj gkFk dh mQ¡pkbZ ys ysrk gS" — water recedes 2-4 ft yearly in large oases. The author shows oases are fragile, not perennial. A wrong answer accepting "lky&Hkj" at face value reveals the student doesn't cross-reference vocabulary claims with earlier data.

## DIAGNOSTIC_QUESTION_6
Create a 4-term glossary entry for a student from a non-desert region explaining: vkM+kd, pj[kh, [khai, and jLlk. Each entry must include: (a) the term, (b) its function in the oasis system, (c) one textual detail showing HOW it works, and (d) why it would fail if transplanted to a non-desert context.

## DIAGNOSTIC_ANSWER_6
Expected answer criteria: Each entry connects form to function to environmental logic. Example for vkM+kd: (a) vkM+kd, (b) irrigation channel distributing water from well to fields, (c) "vksM+kd vkSj pj[kh pM+lh dks ;gk¡&ogk¡ fcuk Vdjk, lh/s mQij rd ykrh gS" — channels run along field boundaries without erosion, (d) fails in non-desert because high rainfall would erode unlined channels and waterlogging would occur. A poor answer lists definitions without the "why it fails elsewhere" component, showing the student hasn't grasped that these terms name *desert-specific adaptations*, not universal farming tools.

## COMMON_MISCONCEPTION
Students treat key terms as static definitions to memorize (e.g., "ikyjikuh = rainwater") rather than as relational concepts defined by contrast within the text's explanatory structure. They miss that the author defines ikyjikuh BY distinguishing it from ikrkyikuh ("ikyjikuh vkSj ikrkyikuh osQ chp ikuh dk rhljk :i gS jstk.khikuh"), and defines [khai BY describing its construction sequence ("igys fnu oqaQbZ [kksnus osQ lkFk&lkFk [khai uke dh ?kkl dk <sj tek dj fy;k tkrk gS"). This error occurs because students are trained to extract definitions from glossaries, not to reconstruct them from the author's comparative logic. For example, a student will write "jstk.khikuh = artesian water" but cannot explain why the author says "jstk 'kCn dk mi;ksx gksrk gSA vkSj jstk dk eki èkjkry ij gqbZ o"kkZ dks ugha] èkjkry esa lekbZ o"kkZ dks ukirk gSA" — missing that the vocabulary carries the physics of the system.

## ON_FAILURE
Step 1: Have the student locate ONE key term in the text and highlight every sentence where it appears or is implicitly discussed. Step 2: Ask them to write: "The author explains [term] by showing how it differs from [other term] and by describing what happens when [condition]." Step 3: Give them a 3-column table: Term | Contrast Pair | Functional Description in Text. Step 4: Practice with ikyjikuh/ikrkyikuh/jstk.khikuh first (explicitly structured by author), then move to [khai/vkM+kd/pj[kh (described through process narratives). This shifts them from "word = meaning" to "term = node in explanatory network."

## BUILDS_ON
c11_hin_v_cbse_02_001 (Before You Read: Context and Background) — students need the geographical and cultural framing of desert/oasis systems before decoding the technical vocabulary.

## LEADS_TO
c11_hin_v_cbse_02_011 (Grammar: Language Usage in the Text) — vocabulary mastery enables analysis of how grammatical forms (passive voice in process descriptions, nominalization in technical definitions) encode the chapter's knowledge structures.

## PREREQUISITE_NODE_IDS
c11_hin_v_cbse_02_001
## PREREQUISITE_REASONS
c11_hin_v_cbse_02_001: Provides essential background on desert ecology, oasis formation, and traditional water management that makes the technical vocabulary intelligible; without this context, terms like jstk.khikuh and vkM+kd are opaque labels.

## FORWARD_NODE_IDS
c11_hin_v_cbse_02_011, c11_hin_v_cbse_02_012, c11_hin_v_cbse_02_013, c11_hin_v_cbse_02_014, c12_hin_a_cbse_07_010, c12_hin_al_cbse_02_010

## FORWARD_REASONS
c11_hin_v_cbse_02_011: Vocabulary mastery allows identification of grammatical patterns specific to technical discourse (e.g., passive constructions in oasis construction descriptions). c11_hin_v_cbse_02_012: Key terms are the anchors for literal and inferential comprehension questions. c11_hin_v_cbse_02_013: Critical interpretation requires precise understanding of terms like futh and lkoZtfud laifÙk as they carry the chapter's argument about tradition vs. modernity.
c11_hin_v_cbse_02_014: Key vocabulary (*ikyjikuh, ikrkyikuh, jstk.khikuh, pal, khai, paledar*) constitutes the mandatory Evidence pool.  
c12_hin_a_cbse_07_010: Reinforced context-clue strategy for vocabulary.  
c12_hin_al_cbse_02_010: Practice with dialect words in interview/oral history based chapters.  
c11_hin_v_cbse_02_012: Vocabulary in context (e.g., ikyjikuh, ikrkyikuh, jstk.khikuh, o"kZ Hkj) must be mastered to accurately interpret both literal and inferential questions.  
c11_hin_v_cbse_02_013: अगला तार्किक चरण: Critical Thinking: इस नोड की अवधारणाओं को सीधे उपयोग/विस्तारित करता है।  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
none

## CHAIN_DESCRIPTION
c11_hin_v_cbse_02_001 -> c11_hin_v_cbse_02_010 -> c11_hin_v_cbse_02_011

## THIS_FORMULA
N/A - conceptual

## FORMULA_VARIABLES
N/A

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
linguistic

## CROSS_SUBJECT
c11_geography_hydrology | The chapter's classification of groundwater (ikyjikuh, ikrkyikuh, jstk.khikuh) directly mirrors the geography concepts of surface water, groundwater, and artesian aquifers — students can map Hindi terms to hydrological processes studied in Class 11 Geography (Water Resources chapter).
c11_history_traditional_knowledge | The description of futh (customary law) governing oasis water allocation (eksVh js[kk) connects to History themes of indigenous resource management systems and colonial disruption of local ecological knowledge, relevant to Class 11 History themes on traditional societies.

## PREREQ_CONCEPT
Understanding that the chapter is a geo-hydrological exposition embedded in narrative, where technical terms are defined through comparative explanation and process description rather than glossary entries.

## PREREQ_BEFORE
Student must have read the chapter once for gist and identified the two main explanatory threads: (1) how water reaches the surface in deserts (hydrology), and (2) how humans organize to capture and distribute it (socio-technical systems).

## PREREQ_STUCK
If stuck, re-read the third and fourth paragraphs of the reference text where the author explicitly classifies groundwater types and describes [khai construction — these are the vocabulary "definition zones" of the chapter.

## WORKED_EXAMPLE_1
PROBLEM: The term "jstk.khikuh" appears in the text with a specific etymological explanation: "jstk 'kCn dk mi;ksx gksrk gSA vkSj jstk dk eki èkjkry ij gqbZ o"kkZ dks ugha] èkjkry esa lekbZ o"kkZ dks ukirk gSA." Using ONLY textual evidence, reconstruct the full meaning of jstk.khikuh including its geological condition, pressure mechanism, and why the term "jstk" (level/even) is scientifically appropriate.

STEPS:
- Step 1: Locate all sentences containing jstk.khikuh and its etymology in the reference text (paragraphs 3-4 of the provided text).
- Step 2: Extract the geological description: "ikuh dk rhljk :i gS] jstk.khikuhA èkjkry ls uhps mrjk ysfdu ikrky esa u fey ik;k ikuh jstk.kh gSA" — water below surface but not reaching the water table, trapped between impermeable layers.
- Step 3: Extract the pressure mechanism: "o"kkZ dh ek=kk ukius esa Hkh bap ;k lsaVhehVj ugha cfYd jstk 'kCn dk mi;ksx gksrk gSA" — no pump or machinery needed; "jstk" (level/even) refers to the potentiometric surface where pressure equals elevation head.
- Step 4: Extract the behavioral evidence: "ik¡p vaxqy Hkhrj lek tk, rks ml fnu dh o"kkZ dks ik¡p vaxqy jstks dgsaxsA" — 5 workers = 5 artesian units, showing pressure is measurable in human-labor equivalents.
- Step 5: Synthesize: jstk.khikuh = confined aquifer water under artesian pressure where the potentiometric surface (jstk) rises above the aquifer top, enabling free-flowing wells without lifting devices.
- Step 6: Verify against the [kfM+;k i^h (impermeable layer) description: "jstk.khikuh [kfM+;k i^h osQ dkj.k ikrkyhikuh ls vyx cuk jgrk gSA" — confirmed, it forms BECAUSE of the impermeable layer capping the aquifer.

REASONING: This example demonstrates the core vocabulary strategy for this chapter: terms are defined by the author through (a) positional classification (3rd type), (b) geological cause (impermeable layer), (c) functional behavior (rises without pump), and (d) etymological precision (jstk = pressure head level). Students must learn to assemble these distributed clues.

ANSWER: jstk.khikuh = artesian groundwater confined between impermeable strata (ckYVh) where hydraulic pressure forces water above the aquifer top (jstk = potentiometric surface level). The term is scientifically precise because "jstk" denotes the level to which water rises under pressure — matching the hydrogeological definition of artesian head. Textual proof: no pump needed (jstk 'kCn mi;ksx), forms due to [kfM+;k i^h (impermeable layer), and measurable in labor-units (ik¡p vaxqy jstks).

## WORKED_EXAMPLE_2
PROBLEM: The text describes [khai construction as a multi-day ritualized process: "igys fnu oqaQbZ [kksnus osQ lkFk&lkFk [khai uke dh ?kkl dk <sj tek dj fy;k tkrk gSA pstkjks [kqnkbZ 'kq: djrs gSa vkSj ckdh yksx [khai dh ?kkl ls dksbZ rhu vaxqy eksVk jLlk cVus yxrs gSA." Analyze how the vocabulary cluster {[khai, ?kkl, eksVk, jLlk, cVus} reveals the integration of engineering, ecology, and social ritual in oasis establishment.

STEPS:
- Step 1: Isolate each term in the cluster and find its textual definition context. [khai = the well structure; ?kkl = circular foundation ring; eksVk = date palm fiber rope; jLlk = date palm tree; cVus = to weave/bind.
- Step 2: Map the construction sequence: Day 1 — ?kkl (foundation ring) placed; workers dig; 3-4 date palm ropes (eksVk) lowered; woven (cVus) into a continuous ring; date palm trunks (jLlk) placed radially.
- Step 3: Identify the engineering logic: ?kkl distributes load; eksVk provides tensile strength in sandy soil where mortar fails; cVus technique creates flexible reinforcement; jLlk trunks act as shoring against collapse.
- Step 4: Identify the ecological logic: All materials (eksVk, jLlk) come FROM the oasis being created — the system bootstraps itself. "jLlk dh oqaQMyh dks fVdk, j[kus osQ fy, chp&chp esa dgha&dgha fpukbZ Hkh djrs tkrs gSa" — date palm offshoots planted simultaneously.
- Step 5: Identify the social ritual: "dksbZ rhu vaxqy eksVk jLlk cVus yxrs gSa" — specific number (3-4), communal labor (ckdh yksx), ceremonial initiation (igys fnu). The vocabulary encodes a socio-technical protocol.
- Step 6: Conclude: This cluster is not a list of words; it's a compressed blueprint for oasis genesis where each term names a component in a self-reproducing system.

REASONING: The author never defines these terms in isolation. They are defined relationally through the construction narrative. Students must learn to read "vertically" across the process description to extract meaning, not "horizontally" looking for dictionary definitions.

ANSWER: The cluster {[khai, ?kkl, eksVk, jLlk, cVus} forms a socio-technical vocabulary set where: [khai = the well-as-system; ?kkl = load-distributing foundation ring; eksVk = date-palm-fiber tensile reinforcement (replaces steel in sand); jLlk = date palm (source of fiber, fruit, shoring timber, and future canopy); cVus = the binding technique that makes flexible structures in non-cohesive soil. Together they describe a self-bootstrapping oasis genesis protocol: the well builds the palm grove that builds the well.

## WORKED_EXAMPLE_3
PROBLEM: A board exam question asks: "The author uses the term 'futh' in two seemingly contradictory ways — as a living regulatory system (eksVh js[kk) and as a lingering shadow (vaoqQ'k yxk jgrk gS). Explain this contradiction by tracing how the author's description of oqaQbZ ownership shifts from communal management to elite capture. Use at least 4 key terms from the text in your answer."

STEPS:
- Step 1: Identify the two futh contexts: (a) "futh vkSj lkoZtfud laifÙk dk foHkktu djus okyh eksVh js[kk" — futh as active customary law governing water rights; (b) "futh gksrs gq, Hkh lkoZtfud {ks=k esa oaqQb;ksa ij xzke lekt dk vaoqQ'k yxk jgrk gS" — futh as residual power structure.
- Step 2: Trace the ownership shift vocabulary: "oqaQbZ dks] mlosQ ikuh dks lkI+kQ j[kus osQ fy, mls <¡ddj j[kuk" — covering wells to control water; "NksVs e¡qg dks <¡duk ljy gksrk gS" — large wells easier to enclose; "gjsd oqaQbZ ij ydM+h osQ cus <Ddu <¡osQ feysaxs" — elites build walls on large oases.
- Step 3: Connect to labor terms: "pstkjks osQ cnys lkekU; x`gLFk Hkh bl fof'k"V dyk esa oqQ'ky cu tkrs FksA" — laborers' customary rights (x`gLFk) were part of the futh system; "izFkk1 ls mUgsa o"kZ&Hkj osQ rht&R;ksgkjksa esa] fookg tSls eaxy u, yksxksa dks" — annual contracts with advance payments to "important people."
- Step 4: Identify the ecological consequence vocabulary: "oqaQbZ osQ fuekZ.k esa y_s dk iz;ksx" — date palm used for construction; "bl 'kkL=k us lekt osQ fy, miyCèk ikuh dks rhu :iksa esa ck¡Vk gSA" — scientific system classifies water, but futh system classified rights.
- Step 5: Synthesize the contradiction: futh originally meant the customary law (eksVh js[kk) that distributed water via communal institutions (lkoZtfud laifÙk). But as oqaQbZ became enclosable property (<¡ddj j[kuk), the same term "futh" now describes how village elites (xzke lekt) use traditional authority (vaoqQ'k) to legitimize capture. The vocabulary shift FROM "foHkktu" (governance) TO "yxk jgrk gS" (casts shadow) marks this inversion.
- Step 6: Select 4+ key terms for the answer: futh, eksVh js[kk, lkoZtfud laifÙk, x`gLFk, o"kZ&Hkj, rht&R;ksgkj, vaoqQ'k, <¡ddj j[kuk.

REASONING: This models the board-exam competency of tracing a key term's semantic trajectory across the text's argument. The "contradiction" is actually the author's analytical move: showing how vocabulary itself gets repurposed when power relations change. Students must demonstrate this by using the text's own terms as evidence.

ANSWER: The term futh undergoes semantic inversion mirroring the oasis's political economy shift. Initially, futh = eksVh js[kk (customary law) operating through lkoZtfud laifÙk (social organization) to guarantee x`gLFk (laborers' customary shares) in water distribution. But when oqaQbZ become enclosable via <¡ddj j[kuk (walling) and NksVs e¡qg (large wells), futh transforms into vaoqQ'k (traditional authority) that xzke lekt (village society) deploys to legitimize elite capture — evidenced by o"kZ&Hkj (annual contracts) and rht&R;ksgkj (advance payments) to powerful patrons. The author uses the SAME word to diagnose the disease: futh once governed the commons; now it haunts the enclosure.

## COMPETENCY_QUESTION_1
QUESTION: A student writes: "ikyjikuh, ikrkyikuh, and jstk.khikuh are just three Hindi words for water found in different places." Using the author's explicit classification logic, explain why this statement is a category error. Your answer must reference the specific differentiating criteria the author uses (geological position, pressure condition, extraction method).

COMPETENCY: Conceptual discrimination using textual evidence

STEPS:
- Step 1: State the author's explicit classification framework: "bl 'kkL=k us lekt osQ fy, miyCèk ikuh dks rhu :iksa esa ck¡Vk gSA" — a scientific system divides water into three FORMS based on specific criteria.
- Step 2: Identify the three differentiating criteria from the text: (a) Geological position relative to surface and impermeable layers, (b) Pressure condition (hydrostatic vs. artesian), (c) Extraction method (gravity flow vs. lifting vs. free flow).
- Step 3: Show how each term maps to a unique combination: ikyjikuh = surface, atmospheric pressure, gravity collection; ikrkyikuh = subsurface unconfined, hydrostatic pressure, lifting required; jstk.khikuh = subsurface confined, artesian pressure, free flow.
- Step 4: Conclude: The student's statement reduces a 3-dimensional classification (position × pressure × extraction) to a 1-dimensional label (location). This erases the hydrological logic the chapter builds.

ANSWER: The statement commits a category error because the author's 'kkL=k (scientific system) classifies ikuh not by "where found" but by the interaction of THREE criteria: (1) Geological position — ikyjikuh on surface, ikrkyikuh in permeable zone below surface, jstk.khikuh trapped BELOW impermeable layer (ckYVh); (2) Pressure regime — ikyjikuh/ikrkyikuh under hydrostatic pressure, jstk.khikuh under artesian pressure (jstk = potentiometric head); (3) Extraction technology — ikyjikuh collected, ikrkyikuh lifted (pM+l, vkM+kd), jstk.khikuh flows freely (jstk 'kCn mi;ksx = no pump). The student's "different places" collapses this 3D matrix into a 1D label, missing the chapter's core hydrological argument.

DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: The chapter describes two distinct irrigation distribution systems: (A) vksM+kd/pj[kh channels on large oases, and (B) the implied system on small oases where "NksVs O;kl dh oqaQbZ esa èkhjs&èkhjs fjl dj vk jgk ikuh nks&pkj gkFk dh mQ¡pkbZ ys ysrk gSA." Compare these systems by analyzing how the vocabulary of CONTROL (terms like <¡ddj, <Ddu, rkys, vksM+kd) reveals the relationship between hydrological scale and social power. Your answer must use at least 5 key terms from the text.

COMPETENCY: Synthetic analysis of socio-hydrological vocabulary

STEPS:
- Step 1: Identify System A vocabulary (large oases): vksM+kd (engineered channels), pj[kh (field channels), <Ddu (embankments/walls), <¡ddj (enclosing), rkys (berms on channels), pM+lh (mechanical lift).
- Step 2: Identify System B vocabulary (small oases): NksVs O;kl (large establishment), èkhjs&èkhjs fjl (steady decline), mQ¡pkbZ (recession), ikuh [khapus (water retention), ckYVh (impermeable layer constraints).
- Step 3: Analyze CONTROL terms: <¡ddj j[kuk (enclosing to control) appears in BOTH but with different agents — "oqaQbZ dks <¡ddj j[kuk" (general principle) vs "gjsd oqaQbZ ij ydM+h osQ cus <Ddu <¡osQ feysaxs" (elites build walls on large oases).
- Step 4: Analyze SCALE terms: "fnu Hkj esa ,d oqaQbZ eqf'dy ls bruk gh ikuh tek dj ikrh gS" (small yield) vs "NksVs e¡qg dks <¡duk ljy gksrk gS" (large wells easier to enclose) — scale determines enclosability.
- Step 5: Analyze POWER terms: vksM+kd/pj[kh require collective maintenance ("vksM+kd vkSj pj[kh pM+lh dks ;gk¡&ogk¡ fcuk Vdjk, lh/s mQij rd ykrh gS") but <Ddu/<¡ddj enable PRIVATE control. The shift from communal channels to walled wells marks the power shift.
- Step 6: Synthesize: Hydrological vocabulary reveals that large oases (high yield, enclosable) develop engineered distribution (vksM+kd) AND elite capture (<Ddu), while small oases (low yield, declining) remain technically unenclosable but socially vulnerable. The terms are not neutral descriptors; they name the mechanisms of power.

ANSWER: The vocabulary maps a clear socio-hydrological gradient: On large oases, high yield (eqf'dy) enables engineering (vksM+kd, pj[kh, rkys) which REQUIRES collective labor but ENABLES elite enclosure (<Ddu, <¡ddj by ydM+h). On small oases, low yield (bruh gh ikuh) and steady decline (èkhjs&èkhjs fjl, mQ¡pkbZ) make engineering impractical, but the SAME enclosure vocabulary (<¡ddj) is used by village power (xzke lekt, vaoqQ'k) to assert control over the commons. Key terms proving this: vksM+kd (collective channel), <Ddu (elite wall), <¡ddj (enclosure act), xzke lekt (village power), vaoqQ'k (traditional authority), eqf'dy (yield capacity), mQ¡pkbZ (decline rate). The chapter's vocabulary doesn't just describe two systems — it exposes how hydrological parameters (yield, depth, recharge) determine which control vocabulary becomes operative.

DIFFICULTY: hard