## DEFINITION
Secondary themes are the underlying, complementary ideas in a literary work that support, contrast with, or enrich the primary theme. In Kabir's poetry, while the primary theme is devotion (bhakti) and the path to the divine through love, secondary themes include the critique of empty rituals, the necessity of a true guru, the body as a field of spiritual practice, the futility of scriptural learning without experience, and the equality of all human beings before the divine.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student can identify at least three distinct secondary themes in Kabir's three padas, cite specific lines as evidence for each theme, explain how each secondary theme connects to the primary theme of bhakti, and write a structured board-exam answer using the Point-Evidence-Explanation-Link (PEEL) method.

## SCOPE_BOUNDARY
This node covers only the identification, analysis, and written explanation of secondary themes in the three Kabir padas included in NCERT Class 12 Antra Chapter 8. It does not cover primary theme analysis (node 006), literary devices (nodes 008-009), vocabulary (node 010), or grammar (node 011).

## WALKTHROUGH
Imagine you're sitting in the exam hall and the question asks: "Kabir's poetry is not just about loving God — it also attacks hypocrisy. Discuss with reference to the prescribed poems." You freeze because you only memorized the "main theme." Here's how to begin: first, re-read the three padas looking for *patterns* that repeat but aren't the central love-story. Circle words like "pandit," "mullah," "tirath," "jap," "tap" — these signal the ritual-critique theme. Next, notice the guru references in every pada — that's the guru-shishya theme. Then, find body-metaphors (lotus, breath, nine gates) — that's the body-as-temple theme. Each pattern you find is a secondary theme. The key insight: secondary themes are the *arguments* Kabir uses to prove his primary point — they answer "why is love the only way?" by showing why everything else fails.

## DIAGNOSTIC_QUESTION_1
What is the difference between a primary theme and a secondary theme in a literary work? Give one example from Kabir's poetry in this chapter.

## DIAGNOSTIC_ANSWER_1
The primary theme is the central, unifying idea of the work (in Kabir: the path of love/devotion as the only way to the divine). A secondary theme is a supporting idea that enriches, contrasts with, or provides evidence for the primary theme (e.g., Kabir's critique of ritualistic practices like pilgrimages and idol worship serves as a secondary theme that *proves* why love is necessary). A wrong answer that lists two themes without explaining their hierarchical relationship reveals the student confuses "multiple themes" with "primary vs. secondary" — they treat all themes as equal rather than seeing how secondary themes serve the primary one.

## DIAGNOSTIC_QUESTION_2
In the first pada ("osQ ifrvk y, tk,r js eksjk fivre ikl"), Kabir writes: "lf[k vudj nq[k nk#u js tx osQ ifrvk,AA" Explain how this line reveals a secondary theme and how that theme supports the primary theme of devotion.

## DIAGNOSTIC_ANSWER_2
The line means: "Except for the beloved (divine), no other support helps in crossing over." The secondary theme here is *exclusivity of the divine path* — nothing else (rituals, knowledge, yoga) works as a boat to cross the ocean of existence. This supports the primary theme (bhakti/love) by negating all alternatives: if nothing else works, love *must* be the way. A wrong answer that only translates the line without naming the theme or connecting it to the primary theme shows the student can paraphrase but cannot *analyze thematic structure* — they miss the argumentative function of the line.

## DIAGNOSTIC_QUESTION_3
The second pada contains: "lsg fifjfr vuqjkx c[kkfuv fry fry uwru gks,AA" Identify the secondary theme this line illustrates, then write a 3-sentence PEEL paragraph explaining it using this line as evidence.

## DIAGNOSTIC_ANSWER_3
**Secondary theme:** The futility of external austerities (tapasya, fasting, yogic postures) without inner awakening.  
**PEEL paragraph:**  
**Point:** Kabir rejects harsh physical penances as a means to liberation.  
**Evidence:** In the second pada, he states "lsg fifjfr vuqjkx c[kkfuv fry fry uwru gks,AA" (Even after doing great penances and yogic practices, the inner impurity remains).  
**Explanation:** The words "fry fry" (repeated, intense) and "uwru gks," (remains impure) show that external effort alone cannot cleanse the mind; the root problem is internal, not physical.  
**Link:** This reinforces the primary theme — only love/devotion (internal transformation) can purify, not external rituals.  
A wrong answer that writes a summary instead of PEEL, or uses the line to prove a different theme (e.g., "yoga is bad"), reveals the student cannot structure analytical writing or misreads Kabir's nuanced critique (he critiques *ego-driven* yoga, not yoga itself).

## DIAGNOSTIC_QUESTION_4
Compare how the *guru* functions as a secondary theme across all three padas. What distinct role does the guru play in each, and how do these roles together build a complete picture?

## DIAGNOSTIC_ANSWER_4
In Pada 1, the guru is the *initiator* who gives the mantra/name ("fo|kifr dfo xkvksy js èkfu èk# eu vkl" — Kabir says the guru gave the name in the heart). In Pada 2, the guru is the *guide who reveals the inner path* ("dr eèkq&tkfefu jHkl xekvksfy" — the guru shows the difficult path of the breath/lotus). In Pada 3, the guru is the *liberator* who cuts the noose of death ("Hkub fo|kifr flc¯lg uj&ifr" — Kabir says the guru cut the noose of Yama). Together, they form a complete guru-tattva: the guru gives the method, teaches the practice, and grants the fruit (liberation). This progression supports the primary theme by showing bhakti is not self-invented — it requires grace transmitted through the guru. A wrong answer that treats all three references as identical ("guru is important") misses the developmental arc and fails to analyze *how* the theme evolves across the poem sequence.

## DIAGNOSTIC_QUESTION_5
A student writes in the board exam: "Kabir's secondary theme is that rituals are useless. He says don't go to temples, don't fast, don't read books." Evaluate this statement. Is it accurate? What nuance is missing? How would you improve it for full marks?

## DIAGNOSTIC_ANSWER_5
The statement is *partially correct but reductive* — it captures Kabir's critique but misses his nuance. Kabir does not reject all action; he rejects *ego-driven, mechanical, outward-only* action. In Pada 3, he describes the true seeker's state: "xqfu&xqfu izse rksgkjk" (constantly aware in every breath) — this *is* a practice, just an internal one. The improved answer: "Kabir's secondary theme is the *futility of external rituals devoid of inner love/awareness*. He critiques temple-visits, fasting, and scriptural reading *when performed without the guru's grace and the heart's devotion* (Pada 1: 'fiz;re xksoqQy NksM+dj eèkqiqj tk cls gSa'; Pada 2: 'fry fry uwru gks,'). The alternative he offers is not inaction but *sahaj* — natural, constant remembrance (Pada 3: 'rksgj fcjg fnu Nu&Nu ruq fNu')." A wrong answer that agrees fully with the student reveals the examinee cannot distinguish between "rejection of ritual" and "rejection of ritual *without spirit*" — a classic board-exam trap.

## DIAGNOSTIC_QUESTION_6
Write a 4-line poem (in Hindi or English) that expresses *one* secondary theme from Kabir's padas, using a fresh metaphor not found in the text. The poem must show you understand the theme's deeper meaning, not just its surface.

## DIAGNOSTIC_ANSWER_6
**Example (theme: body as temple / inner pilgrimage):**  
"मंदिर नहीं पत्थर का, न तीर्थ किसी धाम का,  
साँस-साँस में ज्योति जले, वही असली काम का।  
पंडित पढ़े वेद पुराण, योगी साधे आसन ध्यान,  
जिसने पाया अंतरामी, वही पार उतर गया जान।"  
**Criteria for a good answer:** (1) Identifies a clear secondary theme (here: inner pilgrimage > outer pilgrimage), (2) Uses a fresh metaphor (breath as lamp, not lotus), (3) Shows the *contrast* Kabir draws (outer vs inner), (4) Conveys the *experiential* nature ("jisne paya" — the one who *experienced*). A poor answer that merely rhymes "mandir/tirath" without the inner/outer contrast or experiential focus reveals the student has memorized keywords but not internalized the theme's logic.

## COMMON_MISCONCEPTION
Students believe "secondary theme" means "less important theme" and therefore write shorter, weaker answers for them. In reality, board examiners *expect* secondary themes to be analyzed with the *same depth* as the primary theme — they are the evidence that proves the primary theme. The specific error: when asked "Discuss the themes in Kabir's poetry," students write one paragraph on bhakti (primary) and one sentence each on rituals/guru/body (secondary), thinking they've covered everything. They lose marks because each secondary theme needs its own PEEL paragraph with textual evidence. This happens because Class 11 taught "identify themes" but Class 12 demands "analyze how themes function hierarchically."

## ON_FAILURE
Step 1: Have the student re-read all three padas with a highlighter, marking only words/phrases that *repeat across padas* (e.g., guru, naam, breath, death, pandit/mullah, body parts). Step 2: Group the highlights into 4-5 clusters — each cluster is a secondary theme. Step 3: For each cluster, write one PEEL paragraph using *only* the highlighted lines as evidence. Step 4: Check: does each paragraph explain *how* this theme supports the primary theme (bhakti)? If not, add the Link sentence. Step 5: Practice writing a 6-mark answer combining primary + three secondary themes in 15 minutes. Re-diagnose using Diagnostic Question 4.

## BUILDS_ON
This node builds on the primary theme analysis (node 006) by showing how secondary themes function as supporting arguments, and on character/setting analysis (nodes 003-005) by treating thematic patterns as "characters" that evolve across the three padas.

## LEADS_TO
This node enables literary devices analysis (nodes 008-009) because metaphors like the lotus, the nine gates, and the breath *are* the vehicles through which secondary themes are expressed — you cannot analyze the device without the theme it carries.

## PREREQUISITE_NODE_IDS
c12_hin_a_cbse_08_001, c12_hin_a_cbse_08_002, c12_hin_a_cbse_08_003, c12_hin_a_cbse_08_004, c12_hin_a_cbse_08_005, c12_hin_a_cbse_08_006, c11_hin_ar_cbse_01_007, c11_hin_ar_cbse_02_007, c11_hin_ar_cbse_03_007, c11_hin_ar_cbse_04_007, c11_hin_ar_cbse_05_007, c11_hin_ar_cbse_06_007, c11_hin_ar_cbse_07_007, c11_hin_ar_cbse_08_007, c11_hin_ar_cbse_09_007, c11_hin_ar_cbse_10_007, c11_hin_ar_cbse_11_007, c11_hin_ar_cbse_12_007, c11_hin_ar_cbse_13_007, c11_hin_ar_cbse_14_007, c11_hin_ar_cbse_15_007, c11_hin_ar_cbse_16_007, c11_hin_v_cbse_01_007, c11_hin_v_cbse_02_007, c11_hin_v_cbse_03_007, c11_hin_v_cbse_04_007, c11_hin_v_cbse_05_007
## PREREQUISITE_REASONS
c12_hin_a_cbse_08_001: Context/background knowledge of Kabir's era and Bhakti movement is essential to understand why he critiques rituals.
c12_hin_a_cbse_08_002: Narrative structure of the three padas as a sequence shows thematic progression.
c12_hin_a_cbse_08_003: Setting/atmosphere (the body as inner landscape) is a secondary theme itself.
c12_hin_a_cbse_08_004: Protagonist (Kabir as speaker) embodies the themes.
c12_hin_a_cbse_08_005: Supporting characters (guru, pandit, mullah, Yama) personify thematic conflicts.
c12_hin_a_cbse_08_006: Primary theme must be known first — secondary themes are defined *relative* to it.
c11_hin_ar_cbse_01_007 through c11_hin_v_cbse_05_007: Class 11 Antra and Vitan chapters built foundational theme-identification skills across multiple poets (Kabir, Meera, Surdas, etc.); this node deepens that skill to hierarchical thematic analysis.
c11_hin_ar_cbse_01_007: Secondary themes are the subordinate thematic threads that run parallel to the primary the... की समझ आवश्यक है, क्योंकि यह नोड (Secondary themes are the underlying, complementary ideas in a literary work that support,...) इसी आधार पर आगे बढ़ता है।  
c11_hin_ar_cbse_02_007: Secondary themes are subsidiary central ideas that run parallel to the primary theme in a... की समझ आवश्यक है, क्योंकि यह नोड (Secondary themes are the underlying, complementary ideas in a literary work that support,...) इसी आधार पर आगे बढ़ता है।  
c11_hin_ar_cbse_03_007: Secondary themes (गौण विषय) are the underlying ideas, motifs, or concerns that run paralle... की समझ आवश्यक है, क्योंकि यह नोड (Secondary themes are the underlying, complementary ideas in a literary work that support,...) इसी आधार पर आगे बढ़ता है।  
c11_hin_ar_cbse_04_007: Secondary themes are the underlying, supporting ideas in a literary work that complement a... की समझ आवश्यक है, क्योंकि यह नोड (Secondary themes are the underlying, complementary ideas in a literary work that support,...) इसी आधार पर आगे बढ़ता है।  
c11_hin_ar_cbse_05_007: Secondary themes are the underlying ideas or messages in a literary work that support, con... की समझ आवश्यक है, क्योंकि यह नोड (Secondary themes are the underlying, complementary ideas in a literary work that support,...) इसी आधार पर आगे बढ़ता है।  
c11_hin_ar_cbse_06_007: Secondary themes are the underlying ideas, concerns, or messages in a literary work that s... की समझ आवश्यक है, क्योंकि यह नोड (Secondary themes are the underlying, complementary ideas in a literary work that support,...) इसी आधार पर आगे बढ़ता है।  
c11_hin_ar_cbse_07_007: Secondary themes are the underlying thematic threads that run parallel to the primary them... की समझ आवश्यक है, क्योंकि यह नोड (Secondary themes are the underlying, complementary ideas in a literary work that support,...) इसी आधार पर आगे बढ़ता है।  
c11_hin_ar_cbse_08_007: Secondary themes are the underlying, supporting ideas in a text that complement and enrich... की समझ आवश्यक है, क्योंकि यह नोड (Secondary themes are the underlying, complementary ideas in a literary work that support,...) इसी आधार पर आगे बढ़ता है।  
c11_hin_ar_cbse_09_007: Secondary themes are the underlying ideas, motifs, or messages that run parallel to the pr... की समझ आवश्यक है, क्योंकि यह नोड (Secondary themes are the underlying, complementary ideas in a literary work that support,...) इसी आधार पर आगे बढ़ता है।  
c11_hin_ar_cbse_10_007: Secondary themes are the underlying ideas, social concerns, and philosophical dimensions t... की समझ आवश्यक है, क्योंकि यह नोड (Secondary themes are the underlying, complementary ideas in a literary work that support,...) इसी आधार पर आगे बढ़ता है।  
c11_hin_ar_cbse_11_007: Secondary themes are the underlying ideas, motifs, or messages that run parallel to the pr... की समझ आवश्यक है, क्योंकि यह नोड (Secondary themes are the underlying, complementary ideas in a literary work that support,...) इसी आधार पर आगे बढ़ता है।  
c11_hin_ar_cbse_12_007: Secondary themes are the underlying, supporting ideas in a literary work that complement a... की समझ आवश्यक है, क्योंकि यह नोड (Secondary themes are the underlying, complementary ideas in a literary work that support,...) इसी आधार पर आगे बढ़ता है।  
c11_hin_ar_cbse_13_007: Secondary themes are the underlying, supporting ideas in a literary work that complement t... की समझ आवश्यक है, क्योंकि यह नोड (Secondary themes are the underlying, complementary ideas in a literary work that support,...) इसी आधार पर आगे बढ़ता है।  
c11_hin_ar_cbse_14_007: Secondary themes are the subordinate yet significant ideas that run parallel to the primar... की समझ आवश्यक है, क्योंकि यह नोड (Secondary themes are the underlying, complementary ideas in a literary work that support,...) इसी आधार पर आगे बढ़ता है।  
c11_hin_ar_cbse_15_007: Secondary themes are the underlying, supporting ideas in a literary work that complement a... की समझ आवश्यक है, क्योंकि यह नोड (Secondary themes are the underlying, complementary ideas in a literary work that support,...) इसी आधार पर आगे बढ़ता है।  
c11_hin_ar_cbse_16_007: Secondary themes are the subsidiary ideas that run parallel to the primary theme, enrichin... की समझ आवश्यक है, क्योंकि यह नोड (Secondary themes are the underlying, complementary ideas in a literary work that support,...) इसी आधार पर आगे बढ़ता है।  
c11_hin_v_cbse_01_007: Secondary themes are the supporting ideas, motifs, and concerns that run alongside the pri... की समझ आवश्यक है, क्योंकि यह नोड (Secondary themes are the underlying, complementary ideas in a literary work that support,...) इसी आधार पर आगे बढ़ता है।  
c11_hin_v_cbse_02_007: Secondary themes are the underlying, often interconnected ideas in a literary text that su... की समझ आवश्यक है, क्योंकि यह नोड (Secondary themes are the underlying, complementary ideas in a literary work that support,...) इसी आधार पर आगे बढ़ता है।  
c11_hin_v_cbse_03_007: Secondary themes are the subordinate yet significant ideas that run parallel to the primar... की समझ आवश्यक है, क्योंकि यह नोड (Secondary themes are the underlying, complementary ideas in a literary work that support,...) इसी आधार पर आगे बढ़ता है।  
c11_hin_v_cbse_04_007: Secondary themes are the supporting ideas that run alongside the primary theme, enriching... की समझ आवश्यक है, क्योंकि यह नोड (Secondary themes are the underlying, complementary ideas in a literary work that support,...) इसी आधार पर आगे बढ़ता है।  
c11_hin_v_cbse_05_007: Secondary themes are the underlying ideas, concerns, or messages in a literary work that s... की समझ आवश्यक है, क्योंकि यह नोड (Secondary themes are the underlying, complementary ideas in a literary work that support,...) इसी आधार पर आगे बढ़ता है।  

## FORWARD_NODE_IDS
c12_hin_a_cbse_08_008, c12_hin_a_cbse_08_009, c12_hin_a_cbse_08_012, c12_hin_a_cbse_08_013, c12_hin_a_cbse_08_014
## FORWARD_REASONS
c12_hin_a_cbse_08_008: Imagery and metaphor (lotus, breath, nine gates) are the *vehicles* of secondary themes — analyzing devices requires knowing the themes they carry.
c12_hin_a_cbse_08_009: Irony and symbolism (e.g., the guru as "cutter of Yama's noose") deepen thematic meaning.
c12_hin_a_cbse_08_012: Comprehension questions often ask "How does the poet criticize rituals?" — requires thematic analysis.
c12_hin_a_cbse_08_013: Critical thinking asks for interpretation — e.g., "Is Kabir anti-ritual or anti-hypocrisy?" — needs secondary theme nuance.
c12_hin_a_cbse_08_014: Writing skills (analytical paragraphs, essays) directly apply the PEEL method taught here.

## CROSS_SUBJECT_PREREQS
c11_hin_ar_cbse_08_007, c11_hin_ar_cbse_12_007
## CROSS_SUBJECT_REASONS
c11_hin_ar_cbse_08_007: Class 11 Antra Chapter 8 (Kabir) introduced secondary themes in Kabir — this node advances from identification to hierarchical analysis.
c11_hin_ar_cbse_12_007: Class 11 Antra Chapter 12 (various Bhakti poets) built comparative theme-analysis skills across poets.

## CHAIN_DESCRIPTION
c12_hin_a_cbse_08_006 -> c12_hin_a_cbse_08_007 -> c12_hin_a_cbse_08_008

## THIS_FORMULA
PEEL Structure for Thematic Analysis: Point (Name the secondary theme) → Evidence (Quote/paraphrase specific line) → Explanation (Analyze words/images, show how they convey the theme) → Link (Connect to primary theme or next theme)

## FORMULA_VARIABLES
Point = Name of secondary theme (e.g., "Critique of Ritualism"); Evidence = Specific line reference (stanza/line description); Explanation = Close reading of keywords/metaphors; Link = Connection to primary theme (bhakti) or broader argument

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
analytical

## CROSS_SUBJECT
N/A | Kabir's critique of rituals reflects the historical Bhakti movement's challenge to Brahmanical orthodoxy and Sultanate-era religious structures — understanding the social context deepens thematic analysis.
 N/A | The secondary theme of equality (implicit in Kabir's rejection of caste-based ritual authority) connects to sociological concepts of social reform movements and religious dissent as drivers of change.
 N/A | Kabir's emphasis on inner conscience over external authority parallels constitutional values of freedom of conscience (Article 25) and equality — a cross-disciplinary lens for "why this theme matters today."
## PREREQ_CONCEPT
Hierarchical theme analysis: distinguishing primary from secondary themes and understanding their functional relationship (secondary themes argue for the primary theme).

## PREREQ_BEFORE
Student must have completed primary theme analysis (node 006) and be able to locate specific lines in all three padas by description (not memorized line numbers).

## PREREQ_STUCK
If stuck, review the "Theme: Primary Theme and Message" node (c12_hin_a_cbse_08_006) and re-read the three padas marking every reference to guru, rituals, body, death, and the Name.

## WORKED_EXAMPLE_1
PROBLEM: Analyze the secondary theme of "the body as a field of spiritual practice" (kṣetra/kṣetrajña) across the three padas. Write a structured answer suitable for a 4-mark board question.

STEPS:
- Step 1: Identify the theme — the body is not an obstacle but the *site* where the divine is encountered (kṣetra = field, kṣetrajña = knower of the field).
- Step 2: Scan Pada 1 for body references — "eu gfj gj y, xsy js viuks eu xsy" (heart as the place of meeting), "xksoqQy" (disciple/seeker embodied).
- Step 3: Scan Pada 2 — "eèkqj cksy" (breath control), "lsgks eèkqj cksy lzoufg" (in the midst of breath-practices), "yk[k yk[k tqx fgv fgv" (watching the breath repeatedly).
- Step 4: Scan Pada 3 — "xqfu&xqfu izse rksgkjk" (constant awareness in every breath), "tyèkkjk" (the body trembling/awakening), "pkSnfl&pk¡n&leku" (lotus blooming in the body).
- Step 5: Synthesize — the progression moves from heart (Pada 1) to breath (Pada 2) to subtle body/lotus (Pada 3), mapping the yogic inner geography Kabir adopts but reorients toward love.
- Step 6: Write the PEEL answer: Point → Evidence (cite one line per pada) → Explanation (show the progression) → Link (this inner geography *is* the path of bhakti, not separate from it).

REASONING: This worked example models the exact skill board exams test: tracing a theme across a multi-part poem, using textual evidence, and showing developmental logic. The 6 steps mirror the cognitive process: identify → locate → locate → locate → synthesize → write.

ANSWER:
**Secondary Theme: The Body as the Field of Spiritual Practice (Kṣetra)**  
**Point:** Kabir reimagines the human body not as a cage but as the sacred arena where the divine is realized.  
**Evidence:** In Pada 1, the meeting happens in the heart ("eu gfj gj y, xsy js viuks eu xsy"). In Pada 2, the practice centers on breath ("lsgks eèkqj cksy lzoufg... yk[k yk[k tqx fgv fgv"). In Pada 3, the lotus blooms within ("pkSnfl&pk¡n&leku") and awareness rides every breath ("xqfu&xqfu izse rksgkjk").  
**Explanation:** The progression from heart → breath → subtle lotus maps the yogic inner geography (cakra/niḍi), but Kabir strips it of technical ego — the "fivre" (beloved) is met in the heart, not through force. The body's trembling ("tyèkkjk") signals awakening, not dissolution.  
**Link:** This theme supports the primary theme of bhakti by showing that love is not an escape from the body but its fulfillment — the body *becomes* the temple when the Name resounds within.

## WORKED_EXAMPLE_2
PROBLEM: A board exam question asks: "Kabir's poetry presents a sharp contrast between 'outer religion' and 'inner realization.' Discuss with reference to the prescribed poems." Write a 6-mark answer.

STEPS:
- Step 1: Deconstruct the prompt — it asks for a *contrast* between two poles (outer/inner) across *all three padas*. This is a comparative thematic analysis.
- Step 2: Create a two-column table mentally: Outer Religion (rituals, pilgrimage, scripture, caste-marks, fasting, yoga-postures) vs. Inner Realization (love, guru's grace, Name, breath-awareness, heart-meeting, sahaj).
- Step 3: Populate from Pada 1: Outer — "fiz;re }kjk gj fy;k x;k" (written by scholars), "fiz;re xksoqQy NksM+dj eèkqiqj tk cls gSa" (scholars left for Kashi). Inner — "fo|kifr dfo xkvksy js èkfu èk# eu vkl" (Kabir says guru gave name in heart).
- Step 4: Populate from Pada 2: Outer — "fifjfr vuqjkx c[kkfuv fry fry" (great penances), "lsgks eèkqj cksy lzoufg" (breath-practices in forests). Inner — "tue vcfèk ge :i fugkjy u;u u frjfir Hksy" (true form not seen even after birth after birth), "dr fcnxèk tu jl vuqeksn" (the real secret is known only through guru).
- Step 5: Populate from Pada 3: Outer — implied in "dksfdy&dyjo] eèkqdj&èkqfu" (worldly attachments). Inner — "rksgj fcjg fnu Nu&Nu ruq fNu" (constant remembrance), "Hkub fo|kifr flc¯lg uj&ifr" (guru cut Yama's noose).
- Step 6: Structure the answer: Intro (thesis: Kabir contrasts to show outer is hollow without inner) → Three body paragraphs (one per pada, each with Point-Evidence-Explanation) → Conclusion (synthesis: the contrast is not rejection of action but reorientation of intention).
- Step 7: Write using PEEL in each paragraph, ensuring each uses at least one direct textual reference.

REASONING: This models the higher-order skill of *synthesizing across a poem sequence* — a frequent 6-mark board pattern. The table method prevents missing padas. The thesis-driven structure satisfies the "discuss" command word.

ANSWER:
**Outer Religion vs. Inner Realization in Kabir's Three Padas**  
Kabir structures his three padas as a progressive exposé: external religious performance cannot substitute for inner awakening.  

**Pada 1 — The False Destination:** The scholars (fiz;re) write scriptures and trek to Kashi (eèkqiqj), treating geography as salvation. Kabir contrasts this with the guru's gift: the Name placed *in the heart* ("èkfu èk# eu vkl"). The outer journey is horizontal (space); the inner is vertical (consciousness).  

**Pada 2 — The Failed Method:** Intense penance ("fry fry"), breath-control in forests ("lsgks eèkqj cksy lzoufg"), and yogic postures leave the seeker impure ("uwru gks,"). The "true form" (:i) remains unseen ("u;u u frjfir Hksy"). Outer discipline without the guru's inner key ("dr eèkq&tkfefu jHkl xekvksfy") is sterile.  

**Pada 3 — The True Outcome:** Worldly bonds ("dksfdy&dyjo") bind, but the seeker established in constant remembrance ("Nu&Nu ruq fNu") is freed from death itself ("flc¯lg uj&ifr"). The contrast resolves: outer religion manages life; inner realization transcends death.  

**Conclusion:** Kabir does not reject the body or action — he redefines them. The "outer" becomes a mirror: if it reflects the inner (grace, Name, sahaj), it serves; if it substitutes for the inner, it deceives.

## WORKED_EXAMPLE_3
PROBLEM: Combine secondary theme analysis with literary device analysis. Question: "How does Kabir use the metaphor of the 'lotus' (kamal/pankaj) across the padas to develop the secondary theme of *sahaj* (natural/spontaneous realization)?" Write a 4-mark answer.

STEPS:
- Step 1: Locate lotus references — Pada 2: implied in "eèkqj cksy" (breath/lotus connection in Nath yoga), "xekvksfy" (showing the path); Pada 3: explicit "pkSnfl&pk¡n&leku" (lotus blooming, fully bloomed, equal/balanced).
- Step 2: Identify the device — extended metaphor (lotus = subtle body center / sahasrara), symbolism (lotus = purity arising from mud), and sound patterning ("pkSnfl&pk¡n&leku" — reduplication for unfolding).
- Step 3: Analyze Pada 2 — the guru "shows" (xekvksfy) the lotus path; it is *revealed*, not self-found. The lotus here is the *goal* of breath-discipline.
- Step 4: Analyze Pada 3 — "pkSnfl&pk¡n&leku" (blooming, fully bloomed, balanced) — the lotus has *already bloomed* in sahaj state. No effort ("fry fry") needed; it is the natural outcome of "xqfu&xqfu izse" (constant awareness).
- Step 5: Trace the development — from *goal* (Pada 2, requiring guru's guidance) to *realized state* (Pada 3, spontaneous). This mirrors the bhakti path: effort → grace → sahaj.
- Step 6: Write the answer linking device → theme → primary theme.

REASONING: This is a *competitive-exam level* question (CUET/JEE-style) combining literary analysis with thematic depth. It tests whether the student sees devices as *theme-carriers*, not decorative ornaments. The 6 steps enforce: locate → identify device → analyze local meaning → analyze developed meaning → trace arc → synthesize.

ANSWER:
**Lotus Metaphor and the Theme of Sahaj**  
Kabir employs the lotus (kamal/pankaj) as an extended metaphor for the subtle body's highest center (sahasrāra), tracing its unfolding from *guided aspiration* to *spontaneous realization*.  

In Pada 2, the lotus is the *destination* of yogic breath-practice: the guru "shows the path" ("xekvksfy") to the lotus within the breath ("eèkqj cksy"). The seeker watches repeatedly ("yk[k yk[k"), implying effort and discipline. The lotus here is *potential* — closed, awaiting the guru's grace to open.  

In Pada 3, the same lotus appears *fully realized*: "pkSnfl&pk¡n&leku" — blooming (pkSnfl), fully blossomed (pk¡n), and perfectly balanced (leku). The reduplication mimics the natural, effortless unfolding of a flower. No "fry fry" (intense penance) appears here; instead, "xqfu&xqfu izse rksgkjk" (constant, breath-by-breath awareness) sustains it.  

**Thematic Function:** This progression — closed bud (guided) → open flower (sahaj) — embodies the secondary theme of *sahaj*: realization is not manufactured by force but *allowed* through grace and remembrance. The lotus metaphor thus bridges the secondary theme (sahaj) to the primary theme (bhakti): love is the water in which the lotus naturally opens.

## COMPETENCY_QUESTION_1
QUESTION: A Class 12 student writes this answer to "Identify two secondary themes in Kabir's poetry and give one evidence for each":  
"1. Kabir criticizes rituals. Evidence: 'fiz;re }kjk gj fy;k x;k'. 2. Kabir loves God. Evidence: 'eu gfj gj y, xsy'."  
Critique this answer. What are the three specific weaknesses? How would you rewrite it to score full marks (4/4)?

COMPETENCY: Critical evaluation of peer response / Answer structuring for board exams

STEPS:
- Step 1: Identify Weakness 1 — Theme 2 ("Kabir loves God") is the *primary* theme, not secondary. The student confuses hierarchy.
- Step 2: Identify Weakness 2 — Evidence for Theme 1 is from the *prose introduction* (fiz;re...), not the *poem itself*. Board exams require poetic textual evidence.
- Step 3: Identify Weakness 3 — No PEEL structure: no Explanation of *how* the evidence proves the theme, no Link to primary theme.
- Step 4: Rewrite Theme 1 correctly: "Critique of ritualistic scholarship" — Evidence from Pada 1: "fiz;re xksoqQy NksM+dj eèkqiqj tk cls gSa" — Explanation: Scholars abandon true knowledge for external pilgrimage — Link: Shows why inner love is necessary.
- Step 5: Rewrite Theme 2 correctly: "Guru as indispensable guide" — Evidence from Pada 2: "dr eèkq&tkfefu jHkl xekvksfy" — Explanation: Guru reveals the subtle breath-path — Link: Bhakti requires grace, not self-effort.

ANSWER:
**Three Weaknesses:**  
1. **Hierarchy Error:** "Kabir loves God" is the primary theme (bhakti), not secondary. Secondary themes *support* this (e.g., guru, body, ritual-critique).  
2. **Wrong Text Source:** The evidence for ritual-critique comes from the prose preface ("fiz;re }kjk gj fy;k x;k"), not the prescribed *poems*. Board marks require poem-text evidence.  
3. **Missing Analysis:** No Explanation or Link — just Point + Quote. The "so what?" is absent.  

**Rewritten for 4/4 Marks:**  
**Secondary Theme 1: Futility of External Rituals/Scholarship**  
**Evidence:** Pada 1 — "fiz;re xksoqQy NksM+dj eèkqiqj tk cls gSa" (Scholars leave for Kashi, the pilgrimage center).  
**Explanation:** "NksM+dj" (climbing with difficulty) and "tk cls gSa" (go away) show scholar-pilgrims treating salvation as a geographical destination, not an inner state.  
**Link:** This failure of outer knowledge proves the primary theme — only the heart's love (bhakti), guided by the guru, reaches the divine.  

**Secondary Theme 2: Guru as the Revealer of the Inner Path**  
**Evidence:** Pada 2 — "dr eèkq&tkfefu jHkl xekvksfy u cw>y dblu osQfy" (The guru shows the difficult breath-path; without him, the secret isn't known).  
**Explanation:** "eèkq&tkfefu" (breath-technique) and "jHkl" (difficult) mark the path as subtle and inaccessible to ego-effort; "xekvksfy" (shows/reveals) makes grace essential.  
**Link:** The guru's grace activates the primary theme — bhakti is not self-generated but received.

DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: "Kabir's secondary themes are not just criticisms — they are *positive* mappings of the inner path." Defend or challenge this statement using all three padas. Your answer must: (a) name three secondary themes, (b) for each, give one positive (constructive) element alongside the critical one, (c) show how the positive element maps the inner path, (d) conclude with a synthesized view.

COMPETENCY: Argumentative synthesis / Multi-theme integration / Evidence-based reasoning

STEPS:
- Step 1: Take a position — *Defend*. The statement is true: every critique implies a positive alternative.
- Step 2: Theme 1 — Critique of Rituals. Positive: The Heart as True Tirtha. Evidence: Pada 1 "eu gfj gj y, xsy js viuks eu xsy" (heart where beloved meets). Maps inner path: pilgrimage internalized.
- Step 3: Theme 2 — Critique of Forceful Yoga/Penance. Positive: Sahaj (Natural Awareness). Evidence: Pada 3 "xqfu&xqfu izse rksgkjk" (constant breath-awareness). Maps inner path: effort replaced by effortless remembrance.
- Step 4: Theme 3 — Critique of Death/Fear. Positive: Guru's Liberation. Evidence: Pada 3 "Hkub fo|kifr flc¯lg uj&ifr" (guru cut Yama's noose). Maps inner path: fear transcended through grace.
- Step 5: Synthesize — The "negative" themes clear the ground; the "positive" themes plant the path. Together they form a complete sadhana: negation (neti-neti) → affirmation (iti-iti).
- Step 6: Write a cohesive 150-word answer with clear paragraphing.

REASONING: This competency question tests the highest board skill: *dialectical thinking* — seeing critique and construction as two sides of one movement. It mirrors CUET/NEET "assertion-reason" and "case-based" patterns where students must integrate multiple textual threads into a coherent argument.

ANSWER:
**Defended.** Kabir's "critiques" are the shadow-side of his positive cartography of the inner path. Three secondary themes illustrate this dialectic:  

1. **Ritual-Critique → Heart as Tirtha:** The scholars' futile trek to Kashi ("fiz;re xksoqQy NksM+dj eèkqiqj tk cls gSa") is answered by the heart where the beloved meets the seeker ("eu gfj gj y, xsy js viuks eu xsy"). The outer pilgrimage is negated so the inner *tirtha* (heart) can be affirmed. The path maps: *from geography to consciousness*.  

2. **Forceful Yoga-Critique → Sahaj Awareness:** The penances leaving impurity ("fry fry uwru gks,") are answered by "xqfu&xqfu izse rksgkjk" — awareness riding every breath naturally. The violent effort ("fry fry") is negated so *sahaj* (spontaneous remembrance) can be affirmed. The path maps: *from will to grace*.  

3. **Death-Fear-Critique → Guru's Liberation:** The noose of Yama ("flc¯lg") is cut by the guru ("Hkub fo|kifr flc¯lg uj&ifr"). Mortality is negated so immortality-in-life (*jīvanmukti*) can be affirmed. The path maps: *from fear to fearlessness*.  

**Synthesis:** Kabir's method is *via negativa* clearing for *via positiva*. Each secondary theme operates as a paired negation/affirmation — the critique names the obstacle; the positive element names the doorway. The "inner path" is not hidden behind the critiques; it *emerges through* them.

DIFFICULTY: hard