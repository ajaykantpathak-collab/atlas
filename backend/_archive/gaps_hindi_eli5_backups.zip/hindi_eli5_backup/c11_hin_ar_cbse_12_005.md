## DEFINITION
Character analysis of supporting characters involves examining how secondary figures in a literary work reveal the protagonist's traits, advance the plot, embody thematic conflicts, and represent social realities through their distinct speech, actions, relationships, and symbolic functions.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student must independently identify three supporting characters in the poem, cite specific textual evidence (lines/stanzas) for each character's key traits, and explain how each character's interaction with the protagonist illuminates the central theme of literacy and social hierarchy.

## SCOPE_BOUNDARY
This node covers analysis of the maid (paik) and the narrator's wife (ckye) as supporting characters in Phalke Shivpujan's poem "पैक दकस दकस वपंज उघा फुगरह". It does NOT cover the protagonist (narrator/poet) which was addressed in the previous node, nor does it cover thematic analysis or literary devices which are separate nodes.

## WALKTHROUGH
Imagine you're watching a family WhatsApp group where your mother forwards a voice note from the household help asking how to read a medicine label — suddenly the poem's maid isn't just a character but a reality you recognize. Begin by re-reading the poem specifically tracking every time the maid speaks or acts, marking those stanzas with a highlighter. Next, do the same for the wife (ckye) who appears in the later stanzas. Ask: "What does each character's language reveal about their social position? How does the maid's refusal to learn challenge the narrator's assumptions?" The key insight: supporting characters in this poem are not background decoration; they are the living proof of the social divide the poem critiques.

## DIAGNOSTIC_QUESTION_1
Identify the two supporting characters in the poem "पैक दकस दकस वपंज उघा फुगरह" and state one defining action for each.

## DIAGNOSTIC_ANSWER_1
The two supporting characters are the maid (पैक) and the narrator's wife (चये). The maid's defining action is her persistent refusal to learn reading/writing despite the narrator's efforts (e.g., saying "मैं तो नहीं पढ़ी" and later "पैक कहती है: रे दकन घ कसन दजस फनु हकज"). The wife's defining action is her pragmatic intervention urging the narrator to teach the maid practically ("पैक चखह% रे फदरस >वबस गकस] नस[क्क"). A wrong answer that lists the narrator as a supporting character reveals confusion between protagonist and supporting roles; listing only the maid misses the wife's crucial thematic function.

## DIAGNOSTIC_QUESTION_2
Explain in your own words why the maid says "डयड्कस इज टज फजस" (keep the pen on the ear) and what this reveals about her worldview.

## DIAGNOSTIC_ANSWER_2
The maid says this to reject the narrator's academic approach to literacy — she sees the pen behind the ear as a performative symbol of educated status that doesn't translate to survival skills. Her worldview values tangible labor ("गजस कक<+स दके लज<सक") over symbolic literacy. A wrong answer interpreting this as mere stubbornness or ignorance misses the class critique: she's asserting that her illiteracy is a rational response to a system where literacy doesn't guarantee dignity or food security.

## DIAGNOSTIC_QUESTION_3
Apply the PEEL structure to write a 4-sentence analysis of how the wife's dialogue in the final stanza ("पैक चखह% रे फदरस >वबस गकस...") functions as a narrative pivot.

## DIAGNOSTIC_ANSWER_3
**Point:** The wife's dialogue shifts the poem from abstract idealism to material pragmatism. **Evidence:** She says "पैक चखह% रे फदरस >वबस गकस] नस[क्क" (Paik says: you keep doing big work, sister) and urges practical literacy ("पैक] रे पढ़ ले") tied to real needs like reading letters when the daughter-in-law is away. **Explanation:** Unlike the narrator's philosophical "डयड्कस इज टज फजस", the wife frames literacy as a tool for navigating patriarchal household crises — the maid must read letters to maintain family connections. **Link:** This pivot exposes the narrator's reformism as detached from the lived reality of women's domestic labor. A weak answer would only paraphrase the dialogue without contrasting the two women's approaches to literacy.

## DIAGNOSTIC_QUESTION_4
Analyze how the maid's physical description ("पैक लकुंज ध ्म+ध गस% ककसा-हकसालस ज[करक गस") and her labor ("पैक पपसक;कस दकस दकस पजरघ दजस तकरह गस") function as a symbolic counterpoint to the narrator's intellectual labor.

## DIAGNOSTIC_ANSWER_4
The maid's "clean" (लकुंज) appearance despite handling "dirt" (ककसा-हकसालस) symbolizes dignity in manual labor, while her managing "four corners" (पपसक;कस दकस दकस) of the household represents holistic, embodied knowledge. The narrator's intellectual labor (reading/writing) is fragmented and performative ("डयड्कस इज टज फजस"), whereas the maid's labor integrates body, space, and social reproduction. A wrong answer treating the description as mere realism misses the symbolic structure: the poem contrasts two epistemologies — bookish vs. embodied — with the maid embodying the latter's completeness.

## DIAGNOSTIC_QUESTION_5
Evaluate the criticism that the poem ultimately reinforces the narrator's savior complex by making the maid's illiteracy a project for his enlightenment. Defend or refute using textual evidence.

## DIAGNOSTIC_ANSWER_5
Refute: The poem subverts the savior complex through the maid's agency — she rejects the narrator's pedagogy ("मैं तो नहीं पढ़ी") and only engages when the wife reframes literacy as *her* need ("पैक] रे पढ़ ले... डयड्क्के इम लनसलक नकसख"). The final image — "डयड्क्के इम लनसलक नकसख" (don't ever go to the daughter-in-law's house) — centers the maid's survival strategy, not the narrator's teaching. A wrong answer accepting the criticism overlooks how the narrative structure gives the maid the last word (her laughter "पैक पकी गस" and practical wisdom), decentering the narrator's reformist ego.

## DIAGNOSTIC_QUESTION_6
Create a 4-line dialogue poem between the maid and a modern gig-worker (delivery person) where both articulate why formal literacy feels irrelevant to their survival. Use the maid's voice from the poem as inspiration.

## DIAGNOSTIC_ANSWER_6
**Maid:** "अककसर सजखके पेट भरे ना, रोटी ककसका भरे"  
**Gig-worker:** "ऐप पढ़के दकसका भला, रेट दकसका ना बढे"  
**Maid:** "चिट्ठी पढ़के बऊ लटौ, यहीं मेरो हकज"  
**Gig-worker:** "ओटोपी दकसका चलाउ, रास्तो मेरो पचहानो"  
A poor answer would write generic complaints about education without anchoring each line in the specific material logic of their labor (the maid's household management, the gig-worker's algorithmic navigation) as the poem does.

## COMMON_MISCONCEPTION
Students often treat supporting characters as "minor" and therefore less important for exams, writing one-line descriptions like "the maid is illiterate and stubborn." This error stems from equating *screen time* with *thematic weight*. In this poem, the maid speaks more lines than the narrator in key stanzas and her refusal drives the entire narrative arc. The misconception persists because textbook questions often ask "sketch the character of the protagonist," training students to ignore the dialectic between protagonist and supporting characters that creates meaning.

## ON_FAILURE
If a student reduces the maid to "illiterate servant," do this 3-step remediation: (1) Have them read aloud only the maid's lines (stanzas 2, 4, 6, 8) and circle every verb showing agency — "कहती", "करती", "देती", "हँसती". (2) Ask: "Which character changes the other's mind?" Trace how the narrator shifts from "डयड्कस इज टज फजस" to accepting "पैक चखह% रे फदरस >वबस गकस". (3) Assign a 3-sentence rewrite: "The maid teaches the narrator that literacy is ____, not ____." This forces recognition of her epistemic authority.

## BUILDS_ON
c11_hin_ar_cbse_12_004 (Character Analysis: Protagonist) — students must already understand the narrator's reformist stance to analyze how supporting characters challenge it.

## LEADS_TO
c11_hin_ar_cbse_12_006 (Theme: Primary Theme and Message) — supporting characters' conflicting views on literacy directly constitute the poem's central theme of education vs. survival.

## PREREQUISITE_NODE_IDS
c11_hin_ar_cbse_12_001, c11_hin_ar_cbse_12_002, c11_hin_ar_cbse_12_003, c11_hin_ar_cbse_12_004
## PREREQUISITE_REASONS
c11_hin_ar_cbse_12_001: Provides historical context of Phalke Shivpujan's reformist agenda and the social hierarchy the poem critiques.
c11_hin_ar_cbse_12_002: Establishes the narrative structure — the maid's appearances mark the poem's dramatic beats.
c11_hin_ar_cbse_12_003: The domestic setting (kitchen, household) is the maid's workspace; atmosphere shapes her characterization.
c11_hin_ar_cbse_12_004: The protagonist's character (narrator as reformer) is the foil against which supporting characters are defined.

## FORWARD_NODE_IDS
c11_hin_ar_cbse_12_006, c11_hin_ar_cbse_12_007, c11_hin_ar_cbse_12_008, c11_hin_ar_cbse_12_009, c11_hin_ar_cbse_12_013, c11_hin_ar_cbse_12_012, c12_hin_ar_cbse_06_005, c12_hin_ar_cbse_12_005

## FORWARD_REASONS
c11_hin_ar_cbse_12_006: The maid's practical literacy vs. narrator's symbolic literacy IS the primary theme.
c11_hin_ar_cbse_12_007: Secondary themes (gendered labor, class performance, epistemic justice) emerge from supporting characters' actions.
c11_hin_ar_cbse_12_008: Imagery of "डयड्कस इज टज फजस" and "ककसा-हकसालस" is carried by supporting characters.
c11_hin_ar_cbse_12_009: Irony — the "illiterate" maid outwits the "literate" narrator — requires character analysis.
c11_hin_ar_cbse_12_013: Critical interpretation of the poem's social critique depends on reading supporting characters as agents.
c11_hin_ar_cbse_12_012: Supporting characters (child, father) offer relational context for the mother's decisions.  
c12_hin_ar_cbse_06_005: Class 11 foundation on supporting character analysis in Aroh.  
c12_hin_ar_cbse_12_005: Class 11 practice in distinguishing character roles, extracting evidence, and writing PEEL paragraphs for supporting characters.  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
none

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_12_004 -> c11_hin_ar_cbse_12_005 -> c11_hin_ar_cbse_12_006

## THIS_FORMULA
N/A - conceptual

## FORMULA_VARIABLES
N/A

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
analytical

## CROSS_SUBJECT
c11_history_colonialism | The poem's literacy debate mirrors colonial-era "civilizing mission" vs. indigenous knowledge systems — the narrator as reformer echoes colonial educators; the maid's resistance mirrors subaltern rejection of imposed epistemologies.
c11_sociology_social_stratification | The maid's embodied labor (cleaning, managing household "four corners") exemplifies invisible reproductive labor that sustains upper-caste/class households — her illiteracy is structural, not individual.

## PREREQ_CONCEPT
Dialectical character analysis — understanding that characters gain meaning through conflict with each other, not in isolation.

## PREREQ_BEFORE
Student must be able to identify the narrator's explicit goal (teach the maid to read/write) and his method (symbolic/performative: "pen behind ear").

## PREREQ_STUCK
Review "Character Analysis: Protagonist" (c11_hin_ar_cbse_12_004) focusing on the narrator's reformist motivation and his blind spots regarding class/gender.

## WORKED_EXAMPLE_1
PROBLEM: Analyze how the maid's first spoken line ("बू दकस फुगकसा लस ओस लोज") establishes her character and the poem's central conflict in 5 steps.
STEPS:
- Step 1: Locate the line in Stanza 2 — the maid responds to the narrator's reading aloud by asking about the "dirt" (फुगकस) on the page, mistaking ink for grime.
- Step 2: Identify the literacy gap — her question reveals she reads material reality (dirt/cleanliness) not symbolic script; her world is tactile, not textual.
- Step 3: Note the verb "लस" (is/are) — present continuous, indicating immediate sensory perception vs. narrator's abstract past-tense narration.
- Step 4: Connect to conflict — this moment forces the narrator to confront that his "reform" assumes a shared symbolic universe that doesn't exist.
- Step 5: Link to theme — the maid's grounded question "what is this dirt?" becomes the poem's core query: what counts as knowledge in a stratified society?
REASONING: This 5-step close reading moves from textual detail to structural function to thematic resonance — the exact progression board exams reward in 4-6 mark questions.
ANSWER: The maid's opening line "बू दकस फुगकसा लस ओस लोज" (What is this dirt on these letters?) characterizes her as rooted in material reality where ink is physical substance, not meaning. It establishes the central conflict: the narrator's symbolic literacy vs. her tactile epistemology. Her question reframes the poem's project — not "how to teach her" but "whose knowledge counts."

## WORKED_EXAMPLE_2
PROBLEM: Using the wife's (ckye) intervention in the final stanza, write a PEEL paragraph explaining how she represents "pragmatic feminism" distinct from the narrator's "abstract reformism."
STEPS:
- Step 1: Point — The wife reframes literacy from male philanthropy to female survival strategy.
- Step 2: Evidence — She says "पैक चखह% रे फदरस >वबस गकस] नस[क्क" (acknowledging narrator's "big work") then pivots: "पैक] रे पढ़ ले... डयड्क्के इम लनसलक नकसख" (Paik, you read... so you never go to daughter-in-law's house).
- Step 3: Explanation — "Big work" (फदरस >वबस) subtly mocks narrator's intellectualism; her literacy goal is concrete: reading letters to maintain autonomy when patriarchal structures (daughter-in-law's house) threaten.
- Step 4: Link — Unlike narrator's "pen behind ear" performance, she ties literacy to the maid's bodily mobility and kinship survival — a feminist praxis grounded in domestic reality.
- Step 5: Synthesis — The wife bridges class (she's employer) and gender (she's woman navigating patriarchy) to offer a third way: literacy as tool, not trophy.
REASONING: This models the "compare/contrast character perspectives" question type common in 6-mark board questions, requiring textual evidence + conceptual framing.
ANSWER: The wife embodies pragmatic feminism by translating the narrator's abstract reform into the maid's material need. Her dialogue — "पैक चखह% रे फदरस >वबस गकस] नस[क्क / पैक] रे पढ़ ले... डयड्क्के इम लनसलक नकसख" — acknowledges his effort ("big work") but redirects literacy toward the maid's survival: reading letters to avoid dependence on patriarchal households. Where the narrator performs literacy (pen behind ear), the wife weaponizes it for female autonomy. This triangulation — narrator/maid/wife — makes the poem a debate, not a lesson.

## WORKED_EXAMPLE_3
PROBLEM: Compare the maid's two refusals — first "मैं तो नहीं पढ़ी" (Stanza 4) and later "पैक कहती है: रे दकन घ कसन दजस फनु हकज" (Stanza 7) — to trace her evolving agency in 6 steps.
STEPS:
- Step 1: First refusal (Stanza 4) — "मैं तो नहीं पढ़ी" is declarative, past-tense, stating identity: illiteracy as fixed fact.
- Step 2: Context — narrator has just offered "डयड्कस इज टज फजस" (performative literacy); she rejects the *form*, not the *possibility*.
- Step 3: Second refusal (Stanza 7) — "रे दकन घ कसन दजस फनु हकज" (Hey sister, what will I do with reading/writing?) is interrogative, future-oriented, demanding utility.
- Step 4: Shift — she now speaks as negotiator ("रे दकन" = respectful address) not subordinate; she defines literacy's value *on her terms*.
- Step 5: Catalyst — the wife's intervention (Stanza 6) provided the practical frame ("read letters when daughter-in-law is away") that makes refusal a calculated choice.
- Step 6: Thematic payoff — her final laughter "पैक पकी गस" (Paik laughed) signals victory: she forced the curriculum to serve her life, not the narrator's ego.
REASONING: This comparative close reading tracks character development across the narrative arc — a skill explicitly tested in "character sketch with textual evidence" board questions.
ANSWER: The maid's agency evolves from passive identity-claim ("I am illiterate") to active utility-claim ("what use is it to me?"). The first refusal accepts the narrator's frame (literacy as status); the second refusal, enabled by the wife's pragmatic reframing, demands literacy as tool for her specific vulnerability (navigating patriarchal kinship). Her laughter at the end confirms she has rewritten the lesson plan.

## COMPETENCY_QUESTION_1
QUESTION: The poem presents two women — the maid and the wife — who both "teach" the narrator. In a 150-word response, compare their pedagogies using the terms "epistemic authority" and "material condition." Cite at least two specific lines for each woman.
COMPETENCY: Critical comparison of character perspectives with theoretical vocabulary
STEPS:
- Step 1: Define each woman's pedagogy — maid teaches through refusal/questioning; wife teaches through pragmatic reframing.
- Step 2: Select evidence — maid: "बू दकस फुगकसा लस ओस लोज" and "रे दकन घ कसन दजस फनु हकज"; wife: "पैक चखह% रे फदरस >वबस गकस" and "डयड्क्के इम लनसलक नकसख".
- Step 3: Apply "epistemic authority" — maid asserts knowledge of her world (ink as dirt); wife asserts knowledge of patriarchal risks (daughter-in-law's house).
- Step 4: Apply "material condition" — maid's condition: laboring body managing household "four corners"; wife's condition: managing household under patriarchy.
- Step 5: Synthesize — both derive authority from lived reality, not books; narrator learns from both.
ANSWER: The maid's pedagogy emerges from her material condition as embodied laborer: "बू दकस फुगकसा लस ओस लोज" (what is this dirt on letters?) asserts epistemic authority over the physical world she navigates daily. Her later challenge "रे दकन घ कसन दजस फनु हकज" (what will I do with reading/writing?) demands utility grounded in survival. The wife's pedagogy operates from her material condition as a woman managing patriarchy: "पैक चखह% रे फदरस >वबस गकस" (Paik says: you do big work, sister) ironically recenters the maid's labor, while "डयड्क्के इम लनसलक नकसख" (don't ever go to daughter-in-law's house) frames literacy as defense against patriarchal displacement. Both women teach the narrator that knowledge is legitimate only when it serves the knower's material reality — a lesson no textbook provides.
DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: A board exam asks: "The maid in 'पैक दकस दकस वपंज उघा फुगरह' is not a passive recipient of reform but an active critic of the reformer's worldview." Evaluate this statement in 200 words by analyzing three specific moments where the maid's speech or action inverts the teacher-learner hierarchy.
COMPETENCY: Argumentative literary analysis with hierarchical evidence selection
STEPS:
- Step 1: Thesis — the statement is accurate; the maid structurally inverts hierarchy through three strategic inversions.
- Step 2: Moment 1 (Stanza 2) — "बू दकस फुगकसा लस ओस लोज": she reads the page as object, not text, exposing the arbitrariness of script.
- Step 3: Moment 2 (Stanza 7) — "रे दकन घ कसन दजस फनु हकज": she demands cost-benefit analysis, making the teacher justify his curriculum.
- Step 4: Moment 3 (Stanza 8) — "पैक पकी गस" (Paik laughed): laughter as final judgment — she evaluates the lesson, not vice versa.
- Step 5: Synthesis — each moment shifts power: from "what does this mean?" to "what is this worth?" to "I decide if it worked."
- Step 6: Conclusion — the poem's structure (ending with her laughter) confirms her as the ultimate assessor.
ANSWER: The statement is decisively proven by three hierarchical inversions. First, in Stanza 2, the maid's "बू दकस फुगकसा लस ओस लोज" (what is this dirt on these letters?) treats the sacred text as contaminated object — the "illiterate" reads materiality more honestly than the "literate" reads meaning. Second, in Stanza 7, "रे दकन घ कसन दजस फनु हकज" (sister, what will I do with reading/writing?) forces the reformer to justify his pedagogy in her currency — survival, not status. Third, the final image "पैक पकी गस" (Paik laughed) is the ultimate inversion: the learner evaluates the lesson. Laughter here is not ignorance but epistemic victory — she has seen through the performance ("डयड्कस इज टज फजस") and accepted only what serves her ("डयड्क्के इम लनसलक नकसख"). The poem's architecture — beginning with her question, ending with her laughter — makes her the silent architect of its meaning. The narrator reforms; the maid decides what reform means.
DIFFICULTY: hard