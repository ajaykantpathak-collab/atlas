## DEFINITION
Secondary themes are the underlying, supporting ideas in a literary work that complement the primary theme by exploring specific social, psychological, or moral dimensions through recurring motifs, character experiences, and symbolic imagery. In "lk;s esa /wi," secondary themes include child exploitation, systemic hypocrisy, the corruption of justice, and the theft of childhood innocence, each revealed through the poem's courtroom setting and the contrasting voices of the children and the judge.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student can identify at least three distinct secondary themes in the poem, cite specific lines or images as textual evidence for each, and explain how each secondary theme deepens the primary theme of social injustice against children.

## SCOPE_BOUNDARY
This node covers identification and analysis of secondary themes in Nagarjun's poem "lk;s esa /wi" using textual evidence from the four stanzas. It does not cover primary theme analysis (node 006), literary devices (nodes 008-009), or writing skills (node 014).

## WALKTHROUGH
Imagine you're watching a news report about children working in a factory instead of going to school — you feel angry, but can you explain *why* it's wrong beyond just "it's sad"? That's what secondary themes do: they give you the intellectual tools to articulate the specific injustices. Start by re-reading the poem silently, then aloud, noticing how the setting shifts from a physical courtroom to a moral tribunal. Mark every reference to hunger, law, power, and childhood in different colors. Ask: "What is each stanza *really* accusing?" The key insight is that secondary themes are not just 'sub-topics' — they are the specific mechanisms through which the primary injustice operates.

## DIAGNOSTIC_QUESTION_1
What is the definition of a secondary theme in literature, and how does it differ from the primary theme in terms of function and scope?

## DIAGNOSTIC_ANSWER_1
A secondary theme is a supporting idea that explores a specific dimension of the primary theme through particular motifs, characters, or settings, while the primary theme is the central, unifying message of the entire work. A wrong answer that equates secondary themes with 'minor topics' or 'subplots' reveals the student confuses thematic hierarchy with narrative structure — they haven't grasped that secondary themes *analytically deepen* the primary theme rather than merely coexist with it.

## DIAGNOSTIC_QUESTION_2
In the first stanza of "lk;s esa /wi," the speaker says: "डगकहीं तो र्ा फपजकक्सु ?क्ज िे िलए, डगकहीं फपजक् े;लल्ज उघा 'क्ज िे िलए" (Somewhere for a house, somewhere not for a palanquin but for a palanquin). Explain in your own words what this contrast reveals about the secondary theme of *inequality of opportunity* and how the repetition of "फपजक्" (for the sake of) structures this revelation.

## DIAGNOSTIC_ANSWER_2
The repetition of "फपजक्" creates a parallel structure that exposes how the *same human need* (shelter/transport) is met through vastly different means based on class — a hut for the poor, a palanquin for the rich — revealing that inequality is not accidental but *designed into the system*. A wrong answer focusing only on the literal meaning of "house vs palanquin" misses the grammatical patterning: the student hasn't learned to see how syntactic repetition (anaphora) functions as thematic evidence in poetry.

## DIAGNOSTIC_QUESTION_3
Apply the concept of "juxtaposition" to analyze how the second stanza contrasts the children's reality ("नजराँ िे िस म ें /िि े िि /िाँ") with the judge's world ("प्ा मेज़ िर ी िलए"). Write two sentences showing the juxtaposition and name the secondary theme it illuminates.

## DIAGNOSTIC_ANSWER_3
The poem juxtaposes the children's bare, hungry existence ("नजराँ िे िस म ें /िि े िि /िाँ" — in the lines of their eyes, hunger resides) with the judge's ceremonial authority ("प्ा मेज़ िर ी िलए" — for the judge's table), illuminating the secondary theme of *institutional complicity in child exploitation*. A wrong answer that merely lists the two images without using the word "juxtaposition" or explaining the *contrastive function* shows the student can identify images but cannot analyze their structural relationship — a critical gap for board-level poetry analysis.

## DIAGNOSTIC_QUESTION_4
Analyze how the third stanza's legal terminology ("इक़रेबू" — helpless/dependent, "चसडज्कज" — tiny/frail, "फउ़के" — ruler/authority) constructs the secondary theme of *the law as an instrument of oppression rather than protection*. Trace the progression across the stanza.

## DIAGNOSTIC_ANSWER_4
The stanza progresses from the children's legal vulnerability ("इक़रेबू िा िा िा फी?क् उघा िरिा" — they are helpless, the law cannot protect them) to the speaker's bitter identification with their powerlessness ("मे ीं चसडज्कज ुं... िलज िे िलए" — I am frail, for the sake of the hungry), culminating in the irony that the "फउ़के" (ruler) derives power from the very injustice ("िाँ िा फक़कु 'क्;ज िे" — the scepter's power comes from this famine). A wrong answer that treats these words as isolated vocabulary items reveals the student cannot trace *lexical chains* — a senior-secondary skill where thematic meaning accumulates through repeated, evolving key terms across a poem.

## DIAGNOSTIC_QUESTION_5
Evaluate the claim: "The final line 'यह अिगफर;कर "क्:झ िा ब्ल िे िलए' (This helplessness is for the sake of this world) transforms the poem from a critique of individual officials to an indictment of *civilizational failure*." Defend or refute using evidence from the poem's progression.

## DIAGNOSTIC_ANSWER_5
The claim is defensible: the shift from specific courtroom figures (judge, ruler) to the abstract "ब्ल" (world/civilization) in the final line, combined with the recurring "िे िलए" (for the sake of) structure that began with individual needs (house, palanquin) and ends with collective complicity, frames child suffering as the *foundation* of the social order — not its accident. A wrong answer that agrees but cites only the last line reveals *cherry-picking evidence*; the student hasn't learned that thematic claims require tracing a pattern across the *entire* text, a board exam requirement for "critical appreciation" questions.

## DIAGNOSTIC_QUESTION_6
Create a four-line stanza in Nagarjun's voice that introduces a *new* secondary theme not explicitly in the poem (e.g., environmental degradation, digital exclusion, gendered childhood) while maintaining the poem's anaphoric "िे िलए" structure and courtroom imagery.

## DIAGNOSTIC_ANSWER_6
A strong answer will: (1) use "िे िलए" at least twice in parallel positions, (2) place a child-figure in a courtroom-like setting, (3) name a specific modern injustice (e.g., "डगकहीं तो र्ा िोन िे िलए, डगकहीं िेटा िे िलए" — somewhere for a phone, somewhere for data), and (4) end with a bitter generalization like the original. A poor answer that writes a generic sad poem about children without the structural mimicry reveals the student views themes as *topics* rather than *formal patterns* — they cannot transfer the poem's *craft* to new content.

## COMMON_MISCONCEPTION
Students believe secondary themes are simply "other topics mentioned in the poem" and list them like tags (poverty, hunger, law, childhood) without showing how each theme is *constructed* through specific poetic choices — repetition, juxtaposition, lexical chains, structural progression. They treat theme identification as a treasure hunt for nouns rather than an analysis of *how meaning is built*. For example, a student writes "The secondary themes are poverty and injustice" but cannot explain how the anaphora "िे िलए" *creates* the theme of systemic inequality by grammatically equating the rich man's luxury and the poor child's survival as equally "purposeful."

## ON_FAILURE
If a student cannot move beyond listing topics, do this 3-step remediation: (1) Give them the first stanza with "िे िलए" highlighted in three places — ask: "What grammatical work is this phrase doing *each time*?" (2) Have them rewrite the stanza *without* the repetition — then compare: "What thematic force is lost?" (3) Assign a mini-analysis: "Trace 'इक़रेबू' → 'चसडज्कज' → 'फउ़के' across stanza 3. How does the *shift in agency* from victim to speaker to ruler build the theme of legal oppression?" This forces attention from *what* is said to *how* it is said.

## BUILDS_ON
c11_hin_ar_cbse_13_006 (Theme: Primary Theme and Message) — the primary theme of systemic injustice against children provides the unifying framework that the secondary themes specifically instantiate and evidence.

## LEADS_TO
c11_hin_ar_cbse_13_008 (Literary Devices: Imagery and Metaphor) — the imagery and metaphors (e.g., "नजराँ िे िस म ें /िि े िि /िाँ") are the *vehicles* through which secondary themes are concretized; analyzing devices requires prior thematic clarity.

## PREREQUISITE_NODE_IDS
c11_hin_ar_cbse_13_001, c11_hin_ar_cbse_13_002, c11_hin_ar_cbse_13_003, c11_hin_ar_cbse_13_004, c11_hin_ar_cbse_13_005, c11_hin_ar_cbse_13_006
## PREREQUISITE_REASONS
c11_hin_ar_cbse_13_001: Provides historical context of Nagarjun's Marxist leanings and the Emergency era, essential for reading "फउ़के" as political allegory.
c11_hin_ar_cbse_13_002: Establishes the poem's narrative structure (courtroom drama → moral tribunal) which frames how secondary themes unfold across stanzas.
c11_hin_ar_cbse_13_003: The oppressive courtroom atmosphere (setting) is the physical manifestation of the secondary theme "institutional complicity."
c11_hin_ar_cbse_13_004: The protagonist (the speaking "I" who identifies with the children) is the lens through which secondary themes are witnessed and voiced.
c11_hin_ar_cbse_13_005: The judge, ruler, and silent crowd function as thematic foils — their characterization *embodies* hypocrisy and power.
c11_hin_ar_cbse_13_006: The primary theme (systemic injustice) is the umbrella; secondary themes are its specific ribs — cannot analyze parts without the whole.

## FORWARD_NODE_IDS
c11_hin_ar_cbse_13_008, c11_hin_ar_cbse_13_009, c11_hin_ar_cbse_13_012, c11_hin_ar_cbse_13_013, c11_hin_ar_cbse_13_014, c12_hin_a_cbse_01_007, c12_hin_a_cbse_08_007, c12_hin_a_cbse_10_007, c12_hin_a_cbse_13_007, c12_hin_a_cbse_15_007, c12_hin_ar_cbse_13_007

## FORWARD_REASONS
c11_hin_ar_cbse_13_008: Imagery (e.g., hunger in eyes) and metaphor (courtroom as moral tribunal) are the *techniques* that materialize secondary themes — device analysis presupposes thematic identification.
c11_hin_ar_cbse_13_009: Irony (law protecting the powerful) and symbolism (scepter/famine) *encode* secondary themes — recognizing themes first enables decoding devices.
c11_hin_ar_cbse_13_012: Literal/inferential comprehension questions test whether students can *extract* thematic evidence from text — requires prior thematic framework.
c11_hin_ar_cbse_13_013: Critical interpretation (e.g., "Is the poem revolutionary or despairing?") demands synthesizing primary and secondary themes — this node provides the components.
c11_hin_ar_cbse_13_014: Writing skills (analytical paragraph, critical appreciation) require the PEEL structure: Point (secondary theme), Evidence (lines), Explanation (analysis), Link (to primary theme) — this node teaches the P and E.
c12_hin_a_cbse_01_007: Chapter 13 developed critical interpretation of themes.  
c12_hin_a_cbse_08_007: अगला तार्किक चरण: Secondary themes are the underlying, complementary ideas in a literary work that support, contrast w... इस नोड की अवधारणाओं को सीधे उपयोग/विस्तारित करता है।  
c12_hin_a_cbse_10_007: Develops comparative thematic analysis across texts.  
c12_hin_a_cbse_13_007: Class 11 foundation on secondary themes in memoir genre (same chapter in Antra Part 1).  
c12_hin_a_cbse_15_007: "रजनी" chapter's ecological-secondary-theme work is direct precedent for this story's environment-human nexus.  
c12_hin_ar_cbse_13_007: Class 11 secondary theme analysis provides the methodological foundation (identify-trace-connect)  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
none

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_13_006 -> c11_hin_ar_cbse_13_007 -> c11_hin_ar_cbse_13_008: Primary theme provides the unifying framework; secondary themes analyze its specific mechanisms; literary devices reveal the craft that constructs those mechanisms.

## THIS_FORMULA
N/A - conceptual

## FORMULA_VARIABLES
N/A

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
conceptual

## CROSS_SUBJECT
c11_pol_sci_democracy | The poem's depiction of law ("इक़रेबू") as a tool of the powerful ("फउ़के") mirrors the political science concept of "rule by law" vs "rule of law" — the judiciary serving state power rather than constitutional justice.
c11_sociology_social_change | The anaphoric structure "िे िलए" (for the sake of) grammatically enacts the sociological concept of "structural functionalism" gone wrong: inequality presented as systemic necessity ("डगकहीं तो र्ा फपजकक्सु ?क्ज िे िलए") rather than injustice.
c11_economics_poverty | The image "नजराँ िे िस म ें /िि े िि /िाँ" (hunger resides in the lines of eyes) visualizes the economic concept of "capability deprivation" (Amartya Sen) — poverty not as low income but as the denial of basic functionings (seeing, growing, learning).

## PREREQ_CONCEPT
The student must understand the distinction between primary theme (central unifying message) and secondary theme (specific dimensional exploration) as established in node 006, and be able to locate textual evidence across stanzas.

## PREREQ_BEFORE
The student must have completed a full reading of the poem with vocabulary support (node 010), understood the courtroom setting as allegory (node 003), and identified the speaker's dual role as witness and accomplice (node 004).

## PREREQ_STUCK
If stuck, review node 006 (Primary Theme) — specifically the worked example showing how the primary theme "systemic injustice against children" is evidenced across all four stanzas; then return here to *subdivide* that evidence into distinct thematic strands.

## WORKED_EXAMPLE_1
PROBLEM: Identify and analyze the secondary theme of "performative legality" in stanza 2 of "lk;s esa /wi" using the PEEL structure (Point, Evidence, Explanation, Link to primary theme).

STEPS:
- Step 1: Identify the core claim — the courtroom proceedings are a performance that legitimizes injustice rather than delivering justice.
- Step 2: Locate textual evidence — "प्ा मेज़ िर ी िलए" (for the judge's table), "उ ु ी िा उ ु ी िे िलए" (for the lawyer's fee), and the children's silence contrasted with legal ritual.
- Step 3: Analyze the evidence — the prepositional phrase "िे िलए" (for the sake of) attaches to symbols of legal authority (table, fee), showing the system serves its own rituals, not the children; the children "िि े िि /िाँ" (hunger resides) are physically present but legally absent.
- Step 4: Explain the thematic mechanism — the stanza uses syntactic parallelism ("िे िलए" x3) to equate the judge's table and lawyer's fee as *equal beneficiaries* of the performance, while the children's hunger is the unacknowledged substrate.
- Step 5: Link to primary theme — this performative legality *is* how systemic injustice operates: not through overt cruelty but through bureaucratic theater that makes exploitation procedurally correct.
REASONING: The PEEL structure forces the student to move from identification (Point) to textual grounding (Evidence) to analytical depth (Explanation) to thematic synthesis (Link) — the exact progression board examiners reward in "critical appreciation" answers.
ANSWER:
Point: The poem exposes "performative legality" — the courtroom as theater that enacts justice while institutionalizing child exploitation.
Evidence: Stanza 2 repeats "िे िलए" (for the sake of) three times: "प्ा मेज़ िर ी िलए" (for the judge's table), "उ ु ी िा उ ु ी िे िलए" (for the lawyer's fee), and implicitly for the "नजराँ िे िस म ें /िि े िि /िाँ" (hunger in the children's eyes) that fuels the spectacle.
Explanation: The anaphora grammatically equates the judge's authority and lawyer's livelihood as co-beneficiaries of the same performance. The children's hunger is not the *subject* of the trial but its *fuel* — their silence ("िि े िि /िाँ" — hunger resides, not speaks) contrasts with the noisy legal ritual. The law does not fail the children; it *requires* their suffering to maintain its legitimacy.
Link: This performativity is the *mechanism* of the primary theme (systemic injustice) — injustice persists not because laws are broken but because they are *followed* in a system designed to protect power.

## WORKED_EXAMPLE_2
PROBLEM: Trace the secondary theme of "complicity of the intellectual/observer" through the speaker's shifting position across stanzas 1, 3, and 4.

STEPS:
- Step 1: Map the speaker's position in each stanza — Stanza 1: detached observer describing inequality ("डगकहीं... डगकहीं..."); Stanza 3: implicated participant ("मे ीं चसडज्कज ुं... िलज िे िलए" — I am frail, for the hungry); Stanza 4: accusatory generalization ("यह अिगफर;कर ... ब्ल िे िलए" — this helplessness is for the world).
- Step 2: Identify the linguistic markers of shift — Stanza 1: third-person indefinite ("डगकहीं"); Stanza 3: first-person confession ("मे ीं"); Stanza 4: collective indictment ("ब्ल" — world/civilization).
- Step 3: Analyze the thematic progression — the speaker moves from *documenting* inequality to *inhabiting* complicity to *universalizing* guilt, revealing that intellectual witnessing without action is itself a form of participation.
- Step 4: Connect to the "courtroom" frame — the speaker is not a neutral judge but a fellow defendant; the poem's tribunal tries *all* adults, including the poet.
- Step 5: Name the secondary theme — "moral complicity of the conscious observer" or "the impossibility of innocent bystanding in structural injustice."
REASONING: This example models the senior-secondary skill of tracking a *theme across structural units* (stanzas) through *linguistic markers* (pronouns, scope) rather than treating each stanza as a separate idea — essential for "structure and meaning" questions.
ANSWER:
The secondary theme of "intellectual complicity" unfolds through the speaker's pronoun journey: Stanza 1's detached "डगकहीं" (somewhere) positions the poet as a journalist of inequality; Stanza 3's "मे ीं चसडज्कज ुं" (I am frail/tiny) collapses the distance — the speaker *is* the hungry, not just their chronicler; Stanza 4's "ब्ल" (world) expands the guilt from individual to civilizational — "यह अिगफर;कर 'क्:झ िा ब्ल िे िलए" (this helplessness is for the sake of this world) implicates every adult society that tolerates child hunger. The courtroom metaphor completes the turn: the speaker stands not on the bench but in the dock. This theme deepens the primary injustice by showing that *awareness without dissolution of privilege* is another layer of the crime.

## WORKED_EXAMPLE_3
PROBLEM: Compare how two secondary themes — "theft of childhood" and "hunger as structural violence" — are constructed through *different* poetic techniques in the poem, and explain why this technical distinction matters for the poem's political argument.

STEPS:
- Step 1: Define each theme precisely — "Theft of childhood": the denial of play, education, safety, future; "Hunger as structural violence": hunger not as natural scarcity but as politically engineered deprivation.
- Step 2: Identify techniques for Theme A (theft of childhood) — Stanza 1: spatial contrast (house vs palanquin) via anaphora; Stanza 2: sensory imagery ("नजराँ िे िस म ें /िि े िि /िाँ" — hunger *residing* in the eyes, metaphor of occupation); Stanza 4: "अिगफर;कर" (helplessness) as the defining condition of their childhood.
- Step 3: Identify techniques for Theme B (hunger as structural violence) — Stanza 3: legal vocabulary chain ("इक़रेबू" → "फउ़के") showing hunger *produced* by law; Stanza 1: "िे िलए" structure equating luxury and survival as systemic outputs; Stanza 4: "ब्ल" (world) as the agent — hunger serves the world order.
- Step 4: Contrast the techniques — Theme A uses *imagery and metaphor* (embodied, sensory, intimate) to make the theft *felt*; Theme B uses *lexical chains and syntactic parallelism* (abstract, structural, systemic) to make the violence *analyzed*.
- Step 5: Explain political significance — the dual technique mirrors Nagarjun's Marxist-humanist synthesis: the poem demands both *empathy* (for the stolen child) and *structural analysis* (of the system that steals). A poem using only imagery risks sentimentality; only analysis risks abstraction. The combination is the political argument.
- Step 6: Formulate board-ready comparative statement — "Nagarjun deploys embodied metaphor to humanize the victim and structural syntax to indict the system; the tension between these modes enacts the poem's demand for a revolution that is both tender and rigorous."
REASONING: This worked example models the highest-order skill: *comparative thematic analysis through technical distinction*. Board exams ask "How does the poet convey X and Y?" — the answer must show *different techniques for different thematic work*, not just list devices.
ANSWER:
"Theft of childhood" is built through intimate, sensory imagery: hunger "residing in the lines of eyes" (stanza 2, metaphor of occupation), the child's frailty "चसडज्कज" (stanza 3, diminutive adjective), the final "अिगफर;कर" (helplessness as identity). These make the theft *visceral* — the reader inhabits the child's body. "Hunger as structural violence" is built through systemic syntax: the anaphoric "िे िलए" (stanza 1) equating palanquin and hut as *equal products* of the same order; the legal lexicon "इक़रेबू/फउ़के" (stanza 3) showing law as hunger's architect; the final "ब्ल िे िलए" (stanza 4) naming civilization as beneficiary. These make the violence *intellectual* — the reader sees the machine. The distinction matters: if the poem only humanized, it would be charity; if only analyzed, it would be theory. Nagarjun's Marxist poetics *requires both* — the revolution must feel the child's hunger *and* name the system that manufactures it. Board answer: "The poem operates on dual tracks — metaphor for moral witness, syntax for political diagnosis — fusing the humanist and the materialist."

## COMPETENCY_QUESTION_1
QUESTION: A student writes in their board exam answer: "The secondary themes of the poem are poverty, hunger, and injustice." The examiner awards 1 out of 4 marks. Using your understanding of secondary theme analysis, explain why this answer is insufficient and rewrite it to earn full marks, incorporating at least two specific poetic techniques and textual references.

COMPETENCY: Analytical writing / Board exam answer construction

STEPS:
- Step 1: Diagnose the weakness — the answer lists *topics* (nouns) not *themes* (analytical propositions), offers zero textual evidence, and names no poetic techniques.
- Step 2: Recall the board marking scheme for "theme analysis" — requires: (a) thematic statement as arguable claim, (b) specific textual reference (line/device), (c) explanation of *how* the device constructs the theme, (d) connection to broader meaning.
- Step 3: Select two secondary themes with distinct techniques — e.g., "performative legality" (anaphora "िे िलए") and "hunger as structural violence" (legal lexicon chain).
- Step 4: Draft the improved answer using PEEL for each theme, then a synthesizing link.
ANSWER:
The original answer fails because it treats themes as *labels* rather than *constructed arguments*. A full-mark rewrite:
"Nagarjun constructs the secondary theme of **performative legality** through the anaphoric repetition of 'िे िलए' (for the sake of) in stanza 2 — 'प्ा मेज़ िर ी िलए, उ ु ी िा उ ु ी िे िलए' — which grammatically equates the judge's table and lawyer's fee as co-beneficiaries of a legal ritual that feeds on children's silence ('नजराँ िे िस म ें /िि े िि /िाँ'). Simultaneously, the theme of **hunger as structural violence** emerges through a lexical chain in stanza 3: 'इक़रेबू' (helpless/dependent) → 'चसडज्कज' (frail) → 'फउ़के' (ruler), revealing law not as protector but as architect of deprivation. The final line — 'यह अिगफर;कर "क्:झ िा ब्ल िे िलए' — fuses both themes: the courtroom's performance (theme 1) produces the civilization's hunger (theme 2). The poem thus argues that injustice is not legal failure but legal *function*."
DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: "The poem 'lk;s esa /wi' uses the courtroom as a metaphor for *moral judgment of society*. However, a critic argues: 'The metaphor fails because the children never speak — they are objects of pity, not agents of justice. The poem reinforces the very powerlessness it critiques.'" Evaluate this criticism by analyzing how the poem's *form* (structure, voice, address) either supports or subverts the critic's claim. Your answer must reference at least three specific formal choices.

COMPETENCY: Critical evaluation / Meta-analysis of form and ideology

STEPS:
- Step 1: Unpack the critic's claim — it's a *political aesthetics* argument: representation of silence = reinforcement of silencing; the poem's form contradicts its content.
- Step 2: Identify three formal choices to analyze — (a) the speaker's ventriloquism (speaking *for* the children), (b) the anaphoric structure "िे िलए" as systemic grammar, (c) the final address to "ब्ल" (world) as indictment rather than petition.
- Step 3: Analyze each — (a) The speaker *is* a child ("मे ीं चसडज्कज ुं") not an outsider; the ventriloquism is *self-representation*, not appropriation. (b) The "िे िलए" structure gives the children *grammatical agency* — they are the *purpose* of the system, not its victims alone. (c) The poem addresses not the judge (who would be petitioning) but the "world" — it's an accusation, not a plea.
- Step 4: Synthesize — the form *enacts* the transition from object to subject: stanza 1 (observed) → stanza 3 (speaking "I") → stanza 4 (accusing "we"). The silence in stanza 2 is the *evidence* the prosecution presents.
- Step 5: Conclude with nuanced evaluation — the critic mistakes *staged silence* (as evidence) for *authorial silencing*; the poem's formal arc is precisely the recovery of voice.
ANSWER:
The criticism misreads *staged silence* as *authorial silencing*. Three formal choices refute it:
1. **Speaker position**: The "I" in stanza 3 ("मे ीं चसडज्कज ुं") is not a liberal observer but a *fellow child* — the ventriloquism is auto-ethnographic. The poem does not speak *for* the voiceless; it *is* the voice that the system tries to silence.
2. **Anaphoric grammar**: The repeated "िे िलए" (stanzas 1, 2, 4) makes the children the *teleological center* of the system — "for the sake of the hungry" is the *reason* the judge, lawyer, ruler, and world exist. Grammatically, the children are the *subject* (purpose), not the object.
3. **Final address**: The poem ends not with a petition to the court ("फउ़के") but an indictment of "ब्ल" (world/civilization). The tribunal is not the courtroom — it is history. The children's silence in stanza 2 functions as *exhibit A* in that trial.
The poem's formal arc — observed object (stanza 1) → speaking subject (stanza 3) → accusing collective (stanza 4) — *is* the recovery of agency. The critic confuses the *dramatic situation* (children silenced in court) with the *poetic act* (children speaking through the poem).
DIFFICULTY: hard