## DEFINITION
Plot and narrative structure in poetry refers to the sequence of events, the progression of thought, and the arrangement of stanzas that convey a story or experience. In narrative poems like Nagarjun's "Olar Vah K", the structure moves from introduction of the character, through descriptive scenes, to a reflective climax, revealing the protagonist's life and societal context.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student can identify the narrative arc (exposition, rising action, climax, resolution) in a poem, explain how stanza arrangement and poetic devices build the story, and write a structured analysis using textual evidence.

## SCOPE_BOUNDARY
This node covers analysis of plot and narrative structure in the prescribed poems of Chapter 5 (Nagarjun's poems). It does not cover prose narrative techniques or poems from other chapters.

## WALKTHROUGH
Imagine you are asked to explain how a poem tells a story without using paragraphs like a short story. Start by reading the poem aloud, noticing how each stanza adds a new layer to the old woman's life. First, identify the speaker's tone and the opening image (the old woman walking). Then trace how the poem moves from external description to internal reflection. Notice the shift from third-person observation to direct address. The key insight is that narrative structure in poetry relies on imagery progression and emotional pacing rather than conventional plot points.

## DIAGNOSTIC_QUESTION_1
What is the primary difference between narrative structure in a short story and in a narrative poem like 'Olar Vah K'?

## DIAGNOSTIC_ANSWER_1
A short story uses prose paragraphs with explicit plot points (exposition, rising action, climax, resolution), while a narrative poem uses stanzas, imagery, and poetic devices to imply the story, often condensing time and focusing on emotional moments. A wrong answer that says 'poems don't have a plot' reveals the misconception that narrative poetry lacks structure.

## DIAGNOSTIC_QUESTION_2
In the poem 'Olar Vah K', the first stanza describes the old woman's physical appearance and movement. What narrative function does this serve?

## DIAGNOSTIC_ANSWER_2
It serves as exposition, introducing the protagonist and setting the scene, establishing her frailty and the rural atmosphere. A wrong answer that says 'it's just description' misses the structural role of exposition in narrative poetry.

## DIAGNOSTIC_QUESTION_3
Apply the concept of 'rising action' to the middle stanzas of 'Olar Vah K' where the poet describes the old woman's past hardships. How do these stanzas build tension?

## DIAGNOSTIC_ANSWER_3
The middle stanzas accumulate details of her labor (carrying loads, working in fields, enduring seasons), creating rising action by layering hardships that evoke empathy and lead to the climax of her current helplessness. A wrong answer that lists hardships without linking to structural progression shows inability to apply narrative concepts.

## DIAGNOSTIC_QUESTION_4
Compare the narrative structure of 'Olar Vah K' with the second poem 'Raksaks' in the same chapter. How does the repetition in 'Raksaks' alter the narrative flow?

## DIAGNOSTIC_ANSWER_4
'Olar Vah K' follows a linear biographical narrative, while 'Raksaks' uses cyclic repetition (repeated refrain) to convey a ritualistic, timeless narrative, replacing linear progression with emotional intensity. A wrong answer that only notes repetition without analyzing structural difference fails to analyze.

## DIAGNOSTIC_QUESTION_5
Evaluate whether the ending of 'Olar Vah K' (the poet's direct question to the reader) provides narrative resolution. Justify your view.

## DIAGNOSTIC_ANSWER_5
The ending does not give traditional resolution; instead, it shifts from narrative to philosophical inquiry, leaving the reader to reflect on societal neglect, which is a modernist open-ended resolution. A wrong answer that expects a clear 'happy/sad ending' shows misunderstanding of poetic narrative closure.

## DIAGNOSTIC_QUESTION_6
Write a two-stanza poem that uses narrative structure to depict a street vendor's day, employing a clear exposition, rising action, and a reflective ending.

## DIAGNOSTIC_ANSWER_6
A good answer will have two stanzas: first introducing the vendor and setting (exposition), second showing struggles and ending with a thought-provoking line (rising action/reflection). A poor answer will lack progression or simply describe without narrative arc.

## COMMON_MISCONCEPTION
Students often think narrative poems must have a clear beginning, middle, and end like a story, and they look for explicit plot events. In Nagarjun's poem, the narrative is fragmented, relying on snapshots; students miss the structural significance of imagery shifts and refrain, treating them as mere decoration.

## ON_FAILURE
If the student cannot identify narrative elements, guide them to: (1) Number the stanzas and label each with a one-phrase summary (e.g., 'introduction', 'past labor', 'present helplessness', 'poet's reflection'). (2) Draw a simple arc diagram labeling exposition, rising action, climax, resolution. (3) Re-read the poem aloud, noting where the tone shifts from descriptive to emotional. (4) Practice with a simpler narrative poem from Class 11 (e.g., c11_hin_ar_cbse_01_002) to reinforce the concept.

## BUILDS_ON
Class 11 understanding of narrative elements in poetry (exposition, climax, resolution) and stanza analysis.

## LEADS_TO
Character analysis of the protagonist (Olar) and theme analysis of rural marginalization in subsequent nodes.

## PREREQUISITE_NODE_IDS
c12_hin_a_cbse_05_001, c11_hin_ar_cbse_01_002
## PREREQUISITE_REASONS
c12_hin_a_cbse_05_001: Provides context about the poet and era, essential for interpreting narrative choices.
c11_hin_ar_cbse_01_002: Introduces basic narrative structure concepts in poetry, which this node deepens.

## FORWARD_NODE_IDS
c12_hin_a_cbse_05_003, c12_hin_a_cbse_05_004, c12_hin_a_cbse_05_006, c12_hin_a_cbse_05_008, c12_hin_a_cbse_05_012, c12_hin_a_cbse_05_014, c12_hin_a_cbse_05_015

## FORWARD_REASONS
c12_hin_a_cbse_05_003: Setting and atmosphere are established through the narrative structure analyzed here.
c12_hin_a_cbse_05_004: Character analysis requires understanding how the narrative reveals the protagonist.
c12_hin_a_cbse_05_006: Primary theme emerges from the narrative arc and its resolution.
c12_hin_a_cbse_05_008: Plot/narrative structure of the poems (sequence of images).  
c12_hin_a_cbse_05_012: Narrative structure understanding helps locate where in the poem evidence resides  
c12_hin_a_cbse_05_014: Narrative structure of poems (stanza progression) — needed to organize evidence chronologically.  
c12_hin_a_cbse_05_015: Establishes narrative structure of the poems, helping students locate discussion points.  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
No cross-subject prerequisite nodes from the provided list.

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_01_002 -> c12_hin_a_cbse_05_002 -> c12_hin_a_cbse_05_004

## THIS_FORMULA
N/A - conceptual

## FORMULA_VARIABLES
N/A

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
conceptual

## CROSS_SUBJECT
N/A | The poem reflects the socio-economic conditions of rural India in the 1930s, linking to historical context of peasant life.
 N/A | The depiction of the old woman's labor connects to economic concepts of unpaid/underpaid agricultural work and gendered division of labour.
## PREREQ_CONCEPT
Ability to identify stanzas, imagery, and tone shifts in a poem.

## PREREQ_BEFORE
Student must have read the poem 'Olar Vah K' at least twice and marked stanza breaks.

## PREREQ_STUCK
If stuck, review Class 11 node c11_hin_ar_cbse_01_002 on narrative structure in poetry and practice stanza-by-stanza summary.

## WORKED_EXAMPLE_1
PROBLEM: Analyze how the narrative structure of the first three stanzas of 'Olar Vah K' establishes the protagonist's character and setting.
STEPS:
- Step 1: Identify the stanzas: Stanza 1 describes the old woman walking; Stanza 2 elaborates on her physical features; Stanza 3 introduces her past through the poet's imagination.
- Step 2: Recognize the narrative function: Stanza 1 = exposition (introduces character and movement), Stanza 2 = characterization through imagery (wrinkles, bent back), Stanza 3 = backstory (rising action begins).
- Step 3: Note the poetic devices: use of similes ('like a withered leaf'), sensory details (sound of bangles, sight of torn clothes) to build a vivid portrait.
- Step 4: Explain how the progression from external to internal (observation to imagined past) deepens narrative engagement.
- Step 5: Conclude that the structure moves from static description to dynamic life history, setting up the central conflict of neglect.
REASONING: The poem uses a classic narrative arc compressed into stanzas; each stanza advances the narrative by adding layers to the character.
ANSWER: The first three stanzas function as exposition and early rising action, using vivid imagery and shifting perspective to establish the old woman as a symbol of enduring rural hardship.

## WORKED_EXAMPLE_2
PROBLEM: Explain the effect of the refrain 'Olar vah k' repeated at the start of multiple stanzas on the narrative pace.
STEPS:
- Step 1: Locate the refrain in the poem (appears at beginning of stanzas 1, 4, etc.).
- Step 2: Define refrain as a structural device that creates rhythm and emphasis.
- Step 3: Analyze how each recurrence marks a new narrative segment: first as introduction, later as a return to the present after flashbacks.
- Step 4: Discuss how the repetition slows the pace, mimicking the old woman's slow walk and the cyclical nature of her suffering.
- Step 5: Connect to theme: the refrain reinforces the inevitability of her condition, making the narrative circular rather than linear.
REASONING: Refrain in narrative poetry acts as a structural anchor, controlling pace and highlighting thematic resonance.
ANSWER: The refrain structures the poem into cycles, slowing narrative momentum to emphasize the protagonist's unchanging plight and creating a lyrical, elegiac tone.

## WORKED_EXAMPLE_3
PROBLEM: Compare the narrative structure of 'Olar Vah K' with a Class 11 narrative poem (e.g., 'Kabir's Sakhi' or any narrative poem studied). Identify two structural similarities and two differences.
STEPS:
- Step 1: Recall a Class 11 narrative poem (e.g., 'Meghdoot' or a folk narrative) and its structure: linear progression, clear characters, dialogue.
- Step 2: Map 'Olar Vah K' structure: non-linear, fragmented, no dialogue, uses imagery clusters.
- Step 3: Similarity 1: Both use stanzas as narrative units. Similarity 2: Both employ a speaker/narrator who observes and reflects.
- Step 4: Difference 1: Class 11 poem may follow chronological order; Nagarjun uses associative leaps (present to past to present).
- Step 5: Difference 2: Classical narrative poems often have a clear resolution; 'Olar Vah K' ends with an open question.
- Step 6: Synthesize: Modern narrative poetry subverts traditional structure to reflect fragmented modern experience.
REASONING: Comparing across periods highlights evolution of narrative techniques in Hindi poetry.
ANSWER: Both use stanzaic narrative units and a reflective narrator, but Nagarjun's poem is non-linear and open-ended, contrasting with the chronological, resolved structure of traditional narrative poems.

## COMPETENCY_QUESTION_1
QUESTION: The poem 'Olar Vah K' shifts from third-person description to first-person reflection in the final stanza. How does this shift alter the narrative perspective and what does it achieve? Write a structured answer using the PEEL method (Point, Evidence, Explanation, Link).
COMPETENCY: Analytical writing and perspective analysis
STEPS:
- Step 1: Point: The shift from third-person to first-person transforms the poem from an objective portrait to a subjective appeal.
- Step 2: Evidence: Identify lines where the poet uses 'I' (or implied) and addresses the reader directly.
- Step 3: Explanation: This draws the reader into moral responsibility, making the narrative a call to action rather than mere observation.
- Step 4: Link: Connects to the theme of societal indifference, reinforcing the poem's critical purpose.
ANSWER: The narrative perspective shift in the final stanza converts the poem from a descriptive narrative into a persuasive argument, implicating the reader in the old woman's plight and elevating the work from documentation to social commentary.
DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: Design a storyboard of 6 frames for a short film adaptation of 'Olar Vah K' that preserves the poem's narrative structure. For each frame, specify the visual, the corresponding stanza(s), and the narrative function (exposition, rising action, climax, falling action, resolution, or thematic epilogue).
COMPETENCY: Creative adaptation and structural mapping
STEPS:
- Step 1: Break the poem into 6 narrative beats matching its stanzas or groups.
- Step 2: Assign each beat a narrative function label.
- Step 3: Describe a visual that captures the imagery and emotion of that beat.
- Step 4: Ensure the sequence maintains the poem's non-linear shifts (e.g., frame 3 could be a flashback montage).
- Step 5: Write a brief justification for the framing choices, linking to poetic devices.
ANSWER: A successful storyboard will map the poem's structure faithfully, using visual metaphors for abstract reflections, and include a thematic epilogue frame for the open-ended question.
DIFFICULTY: hard