## DEFINITION
Irony is a literary device where the intended meaning of words or situations contrasts sharply with their literal or expected meaning, revealing a deeper truth; Symbolism is the use of concrete objects, characters, or actions to represent abstract ideas, values, or concepts beyond their literal significance.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student must independently identify at least two distinct types of irony (verbal, situational, dramatic) and two symbols in the chapter, explain how each operates in context, and write a board-style answer linking them to the theme of unity in diversity using textual evidence.

## SCOPE_BOUNDARY
This node covers irony and symbolism specifically in Nehru's "Bharat Mata" narrative from Chapter 8 of Aroh; it does not cover other rhetorical devices like satire, allegory, or extended metaphor, nor does it address irony/symbolism in other chapters or poems.

## WALKTHROUGH
Imagine you are sitting with your grandfather who says, "This heavy rain is just *perfect* for our picnic," while you both get soaked — his words mean the opposite of reality, and that is verbal irony. Now open the chapter and notice how Nehru asks crowds "Who is Bharat Mata?" expecting a goddess, but a farmer answers "the earth" — the gap between expected and actual answer creates situational irony. Next, track the recurring image of "mitti" (soil) and "khet-khalihan" (fields): they are not just dirt but symbols of the common people who constitute the nation. Your task is to map each ironic moment and each symbol to the central idea that India's unity emerges from its diverse, ordinary citizens.

## DIAGNOSTIC_QUESTION_1
Define verbal irony and situational irony in your own words, giving one original example for each (not from the textbook).

## DIAGNOSTIC_ANSWER_1
Verbal irony occurs when a speaker says the opposite of what they mean (e.g., saying "Great job!" when someone drops a tray). Situational irony occurs when the outcome of a situation is the opposite of what was expected (e.g., a fire station burning down). A wrong answer that confuses the two or gives only definitions without examples reveals the student cannot distinguish the mechanism (speaker's intent vs. circumstance) — a critical gap for board answers requiring precise terminology.

## DIAGNOSTIC_QUESTION_2
In the chapter, Nehru asks villagers "Who is Bharat Mata?" and a farmer replies "dharti se." Explain why this exchange is an example of situational irony, not verbal irony.

## DIAGNOSTIC_ANSWER_2
The irony is situational because the *outcome* of Nehru's question — a simple farmer giving the profound answer that the intellectual elite missed — contradicts the *expectation* that educated audiences would understand the nation better. It is not verbal irony because neither speaker is saying the opposite of what they mean; both are sincere. A student who labels it verbal irony misunderstands that situational irony arises from circumstance, not tone.

## DIAGNOSTIC_QUESTION_3
Identify one symbol in the passage "Hkkjr ekrk njvly ;gh djksM+ksa yksx gSa" and explain what abstract idea it represents, using the phrase "concrete object stands for abstract concept" in your answer.

## DIAGNOSTIC_ANSWER_3
"Bharat Mata" (Mother India) is a concrete personification that stands for the abstract concept of the collective Indian citizenry — specifically the millions of ordinary people ("djksM+ksa yksx") whose lives constitute the nation. A wrong answer that says "Bharat Mata symbolizes the country" is too vague; board examiners require naming the *specific* abstract idea (the people, not the territory) and the *specific* concrete vehicle (the mother figure).

## DIAGNOSTIC_QUESTION_4
Compare the symbolic function of "mitti" (soil/earth) in the farmer's answer with the symbolic function of "Bharat Mata" in Nehru's explanation. How do both symbols converge on the same theme?

## DIAGNOSTIC_ANSWER_4
"Mitti" symbolizes the grounded, laboring reality of the peasantry — the physical foundation of the nation — while "Bharat Mata" symbolizes the living, breathing collective of all citizens. Both converge on the theme that the nation is not an abstract territory or a goddess but the *people themselves*, especially the humble majority. A student who treats them as separate symbols misses the textual strategy: Nehru uses the farmer's concrete symbol to validate his own abstract one.

## DIAGNOSTIC_QUESTION_5
Evaluate whether the dramatic irony in the chapter — where the British rulers claim to govern for Indians while exploiting them — strengthens or weakens Nehru's argument for national unity. Justify with two textual references.

## DIAGNOSTIC_ANSWER_5
It strengthens the argument because the shared experience of exploitation (text: "fons'kh ljdkj us ge ij ykn j[kk Fkk") creates a common identity across religious, regional, and class lines (text: "lHkh txg fdlku eq>ls ,d&ls loky djrs"). The dramatic irony — the audience (readers) knows the British claim is false while the colonizers pretend otherwise — exposes the artificiality of colonial rule and makes organic unity more compelling. A student who says "it weakens unity because it shows division" confuses colonial division with the *response* to it.

## DIAGNOSTIC_QUESTION_6
Write a four-line stanza for a poem titled "Bharat Mata" that uses *one* symbol from the chapter and *one* type of irony to convey the idea that the nation lives in its people, not its monuments.

## DIAGNOSTIC_ANSWER_6
*Stone lions guard the gate in vain, (symbol: stone lions = hollow monuments)
The mother walks the dusty lane, (symbol: dusty lane = common life)
She wears no crown, she bears no sword, (irony: expected regal imagery absent)
Her strength is in the sweat outpoured.* (symbol: sweat = labor of the people)
A poor answer uses only symbols without irony, or uses clichés ("flag," "anthem") not grounded in the chapter's specific imagery (mitti, khet, mazdoor).

## COMMON_MISCONCEPTION
Students often treat every unexpected event as "irony" and every noun as a "symbol." For example, they label Nehru's travel from village to village as "situational irony" because he is a prime minister walking dusty roads — but this is merely contrast, not irony, because no expectation is violated (he *chose* to travel). Similarly, they call "the British flag" a symbol of oppression without explaining *how* the text uses it symbolically (the text barely mentions the flag). The error stems from memorizing definitions without learning the *textual test*: irony requires a violated expectation; symbolism requires a recurring concrete vehicle tied to an abstract tenor *within the work*.

## ON_FAILURE
Step 1: Give the student two side-by-side sentences — one ironic, one not — and ask "Which expectation is broken?" (e.g., "The fireman's house burned" vs. "The fireman quit his job"). Step 2: For symbolism, hand them a three-column table: Column A = object in text, Column B = abstract idea, Column C = textual evidence linking them. Have them fill it for "mitti," "khet," "Bharat Mata." Step 3: Ask them to rewrite a non-ironic sentence from the chapter into verbal irony, then explain why the new version works. This builds the *detector* skill before the *labeling* skill.

## BUILDS_ON
c11_hin_ar_cbse_08_008 (Literary Devices: Imagery and Metaphor) — because metaphor is the engine of symbolism (a symbol is an extended, culturally shared metaphor), and imagery provides the sensory raw material (mitti, khet) that becomes symbolic.

## LEADS_TO
c11_hin_ar_cbse_08_013 (Critical Thinking: Analysis and Interpretation) — because identifying irony and symbolism is the prerequisite for the deeper interpretive claims (e.g., "Nehru redefines nationalism through democratic symbolism") required in critical analysis.

## PREREQUISITE_NODE_IDS
c11_hin_ar_cbse_08_001, c11_hin_ar_cbse_08_002, c11_hin_ar_cbse_08_003, c11_hin_ar_cbse_08_004, c11_hin_ar_cbse_08_005, c11_hin_ar_cbse_08_006, c11_hin_ar_cbse_08_007, c11_hin_ar_cbse_08_008
## PREREQUISITE_REASONS
c11_hin_ar_cbse_08_001: Context and background (Nehru's role, historical moment) are essential to grasp why the British exploitation creates dramatic irony.
c11_hin_ar_cbse_08_002: Plot structure shows the journey pattern (village to village) that sets up repeated ironic encounters.
c11_hin_ar_cbse_08_003: Setting (dusty lanes, fields) provides the concrete images (mitti, khet) that become symbols.
c11_hin_ar_cbse_08_004: Protagonist analysis (Nehru as questioner) reveals his intentional use of irony as pedagogical tool.
c11_hin_ar_cbse_08_005: Supporting characters (the farmer, the crowds) deliver the unexpected answers that create situational irony.
c11_hin_ar_cbse_08_006: Primary theme (unity in diversity) is the abstract concept that the symbols (Bharat Mata, mitti) embody.
c11_hin_ar_cbse_08_007: Secondary themes (secularism, democracy) deepen the symbolic resonance of "Bharat Mata" beyond mere territory.
c11_hin_ar_cbse_08_008: Imagery and metaphor node teaches the mechanism (vehicle/tenor) that symbolism extends; without it, students cannot explain *how* mitti becomes a symbol.

## FORWARD_NODE_IDS
c11_hin_ar_cbse_08_010, c11_hin_ar_cbse_08_011, c11_hin_ar_cbse_08_012, c11_hin_ar_cbse_08_013, c11_hin_ar_cbse_08_014, c11_hin_ar_cbse_08_015, c12_hin_a_cbse_04_009, c12_hin_a_cbse_05_009, c12_hin_a_cbse_07_009, c12_hin_a_cbse_08_009, c12_hin_a_cbse_10_009, c12_hin_al_cbse_01_009, c12_hin_ar_cbse_08_009, c12_hin_ar_cbse_09_009, c12_hin_ar_cbse_12_009, c12_hin_ar_cbse_03_013

## FORWARD_REASONS
c11_hin_ar_cbse_08_010: Vocabulary in context (e.g., "njvly," "èkjrh") carries symbolic weight that this node decodes.
c11_hin_ar_cbse_08_011: Grammar usage (passive voice in "ykn j[kk Fkk") reinforces the irony of colonial agency.
c11_hin_ar_cbse_08_012: Comprehension questions often ask "explain the irony in the farmer's reply" — this node supplies the method.
c11_hin_ar_cbse_08_013: Critical interpretation builds directly on device identification done here.
c11_hin_ar_cbse_08_014: Writing skills (analytical paragraph) require embedding device analysis as evidence.
c11_hin_ar_cbse_08_015: Speaking/listening discussions on "What does Bharat Mata mean today?" rely on symbolic literacy.
c12_hin_a_cbse_04_009: Class 11 Antra Chapter 8 reinforced symbol-tracking across stanzas — skill directly reused here.  
c12_hin_a_cbse_05_009: अगला तार्किक चरण: Irony is a literary device where the intended meaning of words or a situation is opposite to their l... इस नोड की अवधारणाओं को सीधे उपयोग/विस्तारित करता है।  
c12_hin_a_cbse_07_009: Class 11 Antra Chapter 8 reinforces irony/symbolism in a *different* folk poem, giving comparative practice essential for Board "compare two poems" questions.  
c12_hin_a_cbse_08_009: Class 11 introduction to irony and symbolism in a different text provides the definitional baseline.  
c12_hin_a_cbse_10_009: Chapter 8 practiced multi-symbol tracking — needed for this chapter's cot/dictionary/pen cluster.  
c12_hin_al_cbse_01_009: Class 11 Antra Chapter 8 Irony and Symbolism node prepares for board-level questions.  
c12_hin_ar_cbse_08_009: Class 11 introduced definitions and basic examples of irony and symbolism; this node deepens to multi-device interaction in a complex sociopolitical poem.  
c12_hin_ar_cbse_09_009: Introduces dramatic irony in dialogue poems.  
c12_hin_ar_cbse_12_009: अगला तार्किक चरण: Irony in this story is the contrast between appearance and reality — where the wealthy waste water c... इस नोड की अवधारणाओं को सीधे उपयोग/विस्तारित करता है।  
c12_hin_ar_cbse_03_013: -function explanation: revisit Class 11 Chapter 8/9 Literary Devices nodes (c11_hin_ar_cbse_08_008, c11_hin_ar_cbse_08_009, c11_hin_ar_cbse_09_008, c11_hin_ar_cbse_09_009) and practice "device → effect → meaning" chains on isolated lines be  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
No prior class nodes are available for cross-subject linking in this specific Hindi Aroh chapter.

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_08_008 -> c11_hin_ar_cbse_08_009 -> c11_hin_ar_cbse_08_013

## THIS_FORMULA
Irony Detection Test: (1) Identify the expectation set up by text/context. (2) Identify the actual outcome/statement. (3) If expectation ≠ outcome AND the gap reveals meaning → irony. Symbolism Mapping: (1) Locate recurring concrete image/object. (2) Identify abstract idea it evokes in context. (3) Verify textual evidence links them consistently.

## FORMULA_VARIABLES
Expectation: What the text leads the reader/character to anticipate. Outcome: What actually happens or is said. Concrete Vehicle: The tangible object, action, or character in the text. Abstract Tenor: The concept, value, or idea the vehicle represents. Textual Evidence: Specific phrases/sentences showing the link.

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
analytical

## CROSS_SUBJECT
c11_history_nationalism | The chapter's redefinition of "Bharat Mata" from goddess to people mirrors the historical shift from religious/cultural nationalism to civic/territorial nationalism in Indian freedom struggle — irony exposes the colonial "civilizing mission" while symbolism constructs the new national subject.
c11_civics_constitution | Nehru's insistence that "Bharat Mata is the people" prefigures the Preamble's "We the People" — the symbol becomes the sovereign; the dramatic irony of colonial rule (rulers claiming to serve the ruled) becomes the constitutional justification for popular sovereignty.
c11_geography_human | The symbols "mitti" and "khet" reflect the geographical determinism of agrarian civilization — irony appears when urban elites forget that the nation's ecological base (soil, monsoon, peasant labor) is its true foundation, a theme relevant to contemporary development debates.

## PREREQ_CONCEPT
Understanding metaphor as a mapping between a concrete vehicle and abstract tenor (from c11_hin_ar_cbse_08_008) is the essential prerequisite because symbolism *is* a stabilized, culturally shared metaphor, and irony often works by subverting a metaphorical expectation.

## PREREQ_BEFORE
The student must be able to pick out a metaphor in a sentence, name its vehicle and tenor, and explain the similarity — e.g., in "Life is a journey," vehicle = journey, tenor = life, similarity = has stages, obstacles, movement.

## PREREQ_STUCK
If stuck, review the "vehicle/tenor" framework from c11_hin_ar_cbse_08_008 using the example "Hkkjr ekrk" itself: vehicle = mother, tenor = nation, similarity = nurtures, protects, demands loyalty — then ask how the chapter *changes* the tenor from "territory/goddess" to "people."

## WORKED_EXAMPLE_1
PROBLEM: Analyze the situational irony in the episode where Nehru asks "Who is Bharat Mata?" in a village and a farmer answers "dharti se" (from the earth), while educated audiences gave vague or mythological answers.

STEPS:
- Step 1: Identify the expectation set up by the context — Nehru is an Oxford-educated leader addressing Indian villagers; the reader expects the "educated" perspective to be deeper.
- Step 2: Identify the actual outcome — the simple farmer gives the most precise, grounded answer ("earth/soil"), while sophisticated audiences fumble.
- Step 3: Apply the irony test — expectation (education brings clarity) ≠ outcome (simplicity brings clarity), and the gap reveals a truth: the nation is rooted in the laboring masses, not intellectual abstractions.
- Step 4: Classify the irony type — it is situational because the irony lies in the *circumstance* (who answers best), not in anyone's tone or words.
- Step 5: Connect to theme — this irony validates Nehru's democratic redefinition: "Bharat Mata is the people," making the farmer the true knower.
REASONING: The steps move from surface event to structural expectation to thematic payoff, modeling the board-exam answer pattern: identify device → quote evidence → explain mechanism → link to central idea.
ANSWER: The episode is situational irony because the least expected person (an unlettered farmer) delivers the most accurate definition of the nation, overturning the assumption that education guarantees national understanding. This reinforces the theme that India's unity lives in its ordinary citizens ("djksM+ksa yksx"), not in elite discourse.

## WORKED_EXAMPLE_2
PROBLEM: Trace how "mitti" (soil/earth) functions as a symbol across three moments in the chapter: (a) the farmer's reply "dharti se," (b) Nehru's description of traveling "nfD[ku ls ysdj ifPNe rd" (from northwest to northeast), and (c) the closing line "Hkkjr ekrk njvly ;gh djksM+ksa yksx gSa."

STEPS:
- Step 1: List each occurrence with its immediate context — (a) direct answer to "Who is Bharat Mata?", (b) geographic sweep implying the soil connects all regions, (c) definitive statement equating Mother India with common people.
- Step 2: Identify the constant concrete vehicle — "mitti/dharti" (earth/soil) appears explicitly or implicitly in all three.
- Step 3: Determine the evolving abstract tenor — (a) the physical basis of life/labor, (b) the territorial continuity beneath diversity, (c) the collective body of citizens who *are* the earth.
- Step 4: Verify textual cohesion — the same Hindi root "dharti/mitti" recurs; Nehru explicitly links "mitti" to "log" (people) in the final paragraph.
- Step 5: State the symbolic function — "mitti" symbolizes the *material, laboring, shared foundation* of the nation that makes unity tangible rather than abstract.
REASONING: Symbolism in senior secondary requires showing *recurrence* and *development* — a one-off image is imagery; a traced pattern is symbol. The steps enforce this rigor.
ANSWER: "Mitti" is a developed symbol: it begins as the farmer's concrete answer (vehicle = soil, tenor = sustenance), expands to the geographic substrate linking diverse regions (vehicle = land, tenor = territorial unity), and culminates as the metaphorical body of the citizenry (vehicle = earth, tenor = the people themselves). The symbol thus carries the chapter's argument from biology to polity.

## WORKED_EXAMPLE_3
PROBLEM: The chapter contains dramatic irony: the British government claims to rule India for Indians' benefit, while the text reveals exploitation ("fons'kh ljdkj us ge ij ykn j[kk Fkk"). Write a board-style analytical paragraph (80-100 words) explaining how this dramatic irony serves Nehru's purpose of defining true nationalism.

STEPS:
- Step 1: Write a topic sentence naming the device and its purpose — "Nehru employs dramatic irony to expose the hollowness of colonial legitimacy and ground nationalism in popular sovereignty."
- Step 2: Provide textual evidence for the irony — Quote the contrast: British claim (implied in "ykn j[kk Fkk") vs. reality ("vejhdk us oSQlh rjDdh dh gSA").
- Step 3: Explain the mechanism — The reader knows the exploitation is real; the colonizer's rhetoric is false. This gap (dramatic irony) delegitimizes the colonial "nation."
- Step 4: Link to Nehru's counter-definition — Into the vacuum steps "Bharat Mata = the people," a definition rooted in shared suffering and labor, not royal decree.
- Step 5: Conclude with thematic significance — The irony thus performs political work: it clears space for a democratic nationalism where "njvly djksM+ksa yksx" are the sovereign.
REASONING: Board answers require the PEEL structure (Point, Evidence, Explanation, Link) with precise device terminology. This walkthrough models that discipline.
ANSWER: Nehru employs dramatic irony to expose the hollowness of colonial legitimacy and ground nationalism in popular sovereignty. The British claim to have "kept a yoke on us" ("ykn j[kk Fkk") for our good, yet the text reveals "the British exploited us" ("vejhdk us oSQlh rjDdh dh gSA"). The reader sees the exploitation the colonizers deny, creating dramatic irony that hollows out the imperial "nation." Into this space Nehru inserts his democratic symbol: "Bharat Mata are verily these common people" ("Hkkjr ekrk njvly ;gh djksM+ksa yksx gSa"). The irony thus performs political work — it clears the ground for a nationalism where the sovereign is not the Crown but the sweat of the peasantry.

## COMPETENCY_QUESTION_1
QUESTION: In the chapter, Nehru describes how audiences in different regions reacted to his question "Who is Bharat Mata?" — some looked blank, some grew angry, and one farmer said "dharti se." Using the concept of *situational irony*, explain why the farmer's answer is more "national" than the others' silence or anger. Your answer must use the terms "expectation," "outcome," and "revelation" explicitly.

COMPETENCY: Analytical reasoning with precise terminology
STEPS:
- Step 1: State the expectation Nehru (and the reader) holds — that politically aware or educated audiences will grasp the nation best.
- Step 2: State the actual outcome — the farmer, presumed "ignorant," gives the definitive answer.
- Step 3: Explain the revelation — the gap shows that national identity resides in lived connection to the land/labor, not in abstract patriotism.
- Step 4: Conclude why this makes the answer more "national" — it embodies the *people* Nehru defines as the nation.
ANSWER: The situational irony lies in the violated expectation: Nehru anticipates that sophisticated audiences will understand "Bharat Mata," but the outcome is their confusion versus the farmer's lucid "dharti se." This revelation — that the presumed outsider holds the insider truth — proves the farmer's answer more "national" because Nehru explicitly defines the nation as "djksM+ksa yksx" (common people) whose daily labor on the soil *is* the nation. The irony thus performs the chapter's central argument: nationalism is not a sentiment of the elite but the lived reality of the masses.
DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: The symbol "Bharat Mata" undergoes a semantic shift in the chapter: from a goddess-like figure (expected by audiences) to "the millions of people" (Nehru's definition). Identify *two* textual strategies Nehru uses to effect this shift — one relying on *irony*, one on *symbolism* — and explain how they work together to democratize the concept of the nation.

COMPETENCY: Synthesis of multiple literary devices for thematic analysis
STEPS:
- Step 1: Identify the irony-based strategy — the situational irony of the farmer's answer ("dharti se") displacing elite ignorance.
- Step 2: Identify the symbolism-based strategy — the extension of "mitti/dharti" from physical soil to the collective body of citizens ("Hkkjr ekrk njvly ;gh djksM+ksa yksx gSa").
- Step 3: Explain how irony clears the old meaning — the failure of expected answers (goddess, territory) creates a vacuum.
- Step 4: Explain how symbolism fills the new meaning — the recurring "mitti" motif builds a concrete, democratic referent for "Bharat Mata."
- Step 5: Synthesize — together they replace a hierarchical symbol (goddess above people) with a horizontal one (people *as* the mother).
ANSWER: Nehru uses situational irony when the farmer's "dharti se" outperforms elite answers, exposing the emptiness of the goddess-figure expectation. Simultaneously, he develops the symbol "mitti" — first as the farmer's reply, then as the geographic sweep "nfD[ku ls ifPNe rd," finally as the metaphorical body "njvly djksM+ksa yksx." The irony dismantles the top-down symbol (goddess worshipped by subjects); the symbolism constructs a bottom-up symbol (mother *constituted by* her children). Their interplay democratizes the nation: "Bharat Mata" ceases to be an icon to salute and becomes the living collective to serve.
DIFFICULTY: hard