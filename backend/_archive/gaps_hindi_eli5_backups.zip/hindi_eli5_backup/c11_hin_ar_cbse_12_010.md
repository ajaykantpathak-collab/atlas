## DEFINITION
Vocabulary in Context refers to the skill of determining the precise meaning of a word based on how it is used within a specific literary text, rather than relying solely on its isolated dictionary definition. In this poem, words like *phUgrh*, *pkSik;ksa*, and *ctj fxjs* carry layered cultural and emotional connotations that shift meaning depending on the speaker (the child *paik* or the mother) and the situation (learning vs. working).

## COGNITIVE_LEVEL
understand

## MASTERY_CRITERIA
The student can independently identify 5+ key words from the poem, explain their contextual meaning by citing specific lines/stanzas, and differentiate that meaning from the standard dictionary definition in written answers.

## SCOPE_BOUNDARY
This node covers only the 7 key vocabulary items explicitly listed in the textbook's '*kCn&Nfo*' section for this poem (*phUgrh, phUgksa, pkSik;ksa, dkxn, gkjs xk<+s dke ljsxk, ckye, ctj fxjs*). It does not cover grammatical analysis (node 011), broader comprehension questions (node 012), or literary device identification (nodes 008, 009).

## WALKTHROUGH
Imagine you are reading a WhatsApp message from a friend saying "This exam was a *piece of cake*." If you look up *piece* and *cake* in a dictionary separately, you will miss the actual meaning: "very easy." Similarly, when you read the poem *paik dkys dkys vPNj ugha phUgrh*, words like *phUgrh* or *pkSik;ksa* have special meanings tied to the child's world. First, read the poem aloud once to hear the rhythm. Second, underline the 7 words from the *kCn&Nfo* list wherever they appear. Third, for each word, ask: "Who is speaking? What is happening right then?" Fourth, compare the textbook's given meaning with your guess. The key insight: **Context decides meaning, not the dictionary alone.**

## DIAGNOSTIC_QUESTION_1
What is the textbook meaning provided for the word **phUgrh** in the *kCn&Nfo* section of this chapter?

## DIAGNOSTIC_ANSWER_1
The textbook defines **phUgrh** as **igpkurh** (reading/studying). A wrong answer (e.g., "writing" or "speaking") reveals the student has not consulted the textbook's vocabulary list or is confusing *phUgrh* (reading) with *fy[kuk* (writing) which appears later in the poem. This indicates a 'remember' level gap: the student cannot recall the explicitly provided gloss.

## DIAGNOSTIC_QUESTION_2
In the line *paik dkys dkys vPNj ugha phUgrh*, the word *dkys dkys* repeats. Why does the poet use *dkys dkys* (slowly slowly) instead of just *dkys* (slowly) for the act of *phUgrh* (reading)?

## DIAGNOSTIC_ANSWER_2
The repetition *dkys dkys* conveys the **struggle, hesitation, and gradual pace of a beginner** learning to decode letters. A wrong answer like "to make the poem rhyme" or "to show he is lazy" reveals the misconception that repetition is only decorative. The student misses the *analytical* link between form (reduplication) and content (the cognitive load of early literacy).

## DIAGNOSTIC_QUESTION_3
The word **pkSik;ksa** is defined in the textbook as *pkj iSjksa okys (tkuojksa osQ fy,) ;gk¡ xk;&HkSlksa osQ fy, iz;qDr gqvk gS*. Apply this definition to explain why the mother says *paik pkSik;ksa dks ysdj pjokgh djus tkrh gS* in the context of the poem's rural setting.

## DIAGNOSTIC_ANSWER_3
**Steps:** 1. Note the textbook meaning: four-sided/square shapes (letters for kids, fields for ploughing). 2. Identify the speaker: Mother. 3. Identify the action: *pjokgh* (ploughing). 4. Connect: Mother imagines the child's future as a farmer ploughing *square fields* (pkSik;ksa), contrasting with the *square letters* he struggles with now. 5. Conclude: The word bridges the child's present (school) and feared future (manual labour). A wrong answer ignoring the dual meaning (letters vs fields) shows failure to **apply** the given definition to the specific imagery.

## DIAGNOSTIC_QUESTION_4
Compare the meaning of **dkxn** (textbook: *dkXk”k* - loud noise/shout) in two contexts: (a) *mls cM+k vpjt gksrk gS% bu dkys phUgksa ls oSQls ;s lc Loj fudyk djrs gSa* and (b) *fiQj paik pqi gks tkrh gS / ml fnu paik vkbZ] eSaus dgk fd paik] rqe HKh i<+ yks*. How does the *source* of the *dkxn* change?

## DIAGNOSTIC_ANSWER_4
In (a), *dkxn* is the **child's internal frustration** (a loud noise/shout rising *from within* because the letters *fudyk* the *lc Loj* - the connection/thread of concentration). In (b), *dkxn* is the **mother's external call/command** (*paik vkbZ* - she calls out to him). The shift is from *involuntary expression of distress* to *intentional pedagogical intervention*. A wrong answer treating both as just "loud sound" misses the **analytical** distinction between internal psychological state and external social action.

## DIAGNOSTIC_QUESTION_5
The textbook glosses **ctj fxjs** as *otz fxjs] Hkkjh foifÙk vk,* (apply tilak, bring good fortune). Evaluate whether the mother's final command *dydÙkk eSa dHkh u tkus nw¡xh / dydÙks ij ctj fxjs* is purely a ritualistic blessing or a pragmatic survival strategy in the poem's socio-economic context. Justify.

## DIAGNOSTIC_ANSWER_5
It is a **pragmatic survival strategy disguised as ritual**. The mother *refuses* to go to the city (*dydÙkk eSa dHkh u tkus nw¡xh*) because the city represents alienation from their agrarian roots. By insisting on *ctj fxjs* (tilak on the forehead) *on the village threshold* (*dydÙks ij*), she anchors the child's identity to the land and traditional knowledge (*i<+uk&fy[kuk*), ensuring he remains employable locally (*gkjs xk<+s dke ljsxk*). A wrong answer calling it "just a religious ritual" fails to **evaluate** the economic subtext: the tilak marks him as a literate *local* candidate for office work, not a migrant labourer.

## DIAGNOSTIC_QUESTION_6
Write a 4-line dialogue (in Hindi) between the grown-up *paik* (now a clerk) and his own son who refuses to do homework, using **at least 3 words from the *kCn&Nfo* list** (*phUgrh, pkSik;ksa, dkxn, gkjs xk<+s dke ljsxk, ckye, ctj fxjs*) naturally to show their evolved meanings.

## DIAGNOSTIC_ANSWER_6
**Sample:**
**Putr:** *Pita ji, ye **phUgrh** bahut bor hai, main nahi karunga.*
**Paik:** *Beta, maine bhi **dkys dkys** **phUgrh** ki thi, **pkSik;ksa** se ladte hue. Aaj **gkjs xk<+s dke ljsxk** mila toh samjha ki woh **ctj fxjs** tha mere bhavishya ka.*
**Criteria:** Good answer uses words in new grammatical forms (e.g., *phUgrh* as noun) but retains contextual resonance (struggle -> reward). Poor answer uses words as decorative insertions without logical connection (e.g., "Maine **ctj fxjs** kiya homework").

## COMMON_MISCONCEPTION
Students treat the *kCn&Nfo* list as a **memorization list for translation exams** (Hindi -> English meaning). They fail to see that words like *pkSik;ksa* (square fields/letters) or *ctj fxjs* (tilak/blessing/employability marker) are **semantic pivots** — the poem's central argument (education vs. tradition) rotates on these double meanings. They memorize *igpkurh* for *phUgrh* but cannot explain why the poem doesn't use the common word *paRhna*. The error stems from treating vocabulary as static definitions rather than dynamic dramatic tools.

## ON_FAILURE
1. **Isolate the pivot:** Pick *one* word (e.g., *pkSik;ksa*). 2. **Draw two columns:** Column A = "Child's World (Stanza 1-2)", Column B = "Mother's World (Stanza 3-4)". 3. **Hunt evidence:** Find *pkSik;ksa* in text. Column A: *pkSik;ksa* = letters (child struggles). Column B: *pkSik;ksa* = fields (mother sees future). 4. **Synthesize:** Write one sentence: "The same square shape that frustrates the child today defines the mother's vision of his tomorrow." 5. **Repeat** for *ctj fxjs* and *dkxn*. Do not move to next word until this 5-step cycle is done for one.

## BUILDS_ON
c11_hin_ar_cbse_12_002 (Text: Plot and Narrative Structure) — the student must know the basic storyline (child learns, mother encourages) to situate vocabulary in the correct dramatic moment.

## LEADS_TO
c11_hin_ar_cbse_12_011 (Grammar: Language Usage in the Text) — understanding contextual meaning is prerequisite for analyzing *why* specific verb forms (*phUgrh* vs *i<+uk*), case markers (*pkSik;ksa dks*), or sentence types (imperative *i<+ yks*) are chosen.

## PREREQUISITE_NODE_IDS
c11_hin_ar_cbse_12_001, c11_hin_ar_cbse_12_002, c11_hin_ar_cbse_12_009

## PREREQUISITE_REASONS
c11_hin_ar_cbse_12_001: Provides the socio-historical background (Fakir Mohan Senapati, Odia context, colonial education) essential to grasp why *ctj fxjs* and *gkjs xk<+s dke ljsxk* carry weight.
c11_hin_ar_cbse_12_002: Establishes the narrative arc (resistance -> struggle -> negotiation -> resolution) which dictates the emotional valence of each key word at its specific occurrence.
c11_hin_ar_cbse_12_009: Key vocabulary (e.g., "फूगना", "पकीक", "डाकिया") carries symbolic weight that vocabulary study must unpack.  

## FORWARD_NODE_IDS
c11_hin_ar_cbse_12_011, c11_hin_ar_cbse_12_012, c11_hin_ar_cbse_12_014, c11_hin_ar_cbse_12_015, c12_hin_a_cbse_07_010, c12_hin_ar_cbse_12_010

## FORWARD_REASONS
c11_hin_ar_cbse_12_011: Grammar analysis (e.g., *phUgrh* as verbal noun vs *i<+uk* as infinitive) requires settled lexical meaning first.
c11_hin_ar_cbse_12_012: Literal comprehension questions (e.g., "What does *pkSik;ksa* refer to in line X?") directly test this vocabulary.
c11_hin_ar_cbse_12_014: Writing tasks (diary entry, letter) demand active use of these words in register-appropriate ways.
c11_hin_ar_cbse_12_015: Ensures students can decode Bundelkhandi terms ('पैक', 'डकस', 'पुखरह') during live discussion.  
c12_hin_a_cbse_07_010: Wrote original lines using mother-tongue vocabulary.  
c12_hin_ar_cbse_12_010: Synthesized all prior vocabulary skills in a full-chapter context — immediate skill base.  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
none

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_12_001 -> c11_hin_ar_cbse_12_010 -> c11_hin_ar_cbse_12_011

## THIS_FORMULA
N/A - conceptual

## FORMULA_VARIABLES
N/A

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
linguistic

## CROSS_SUBJECT
c11_history_colonialism | The poem reflects the introduction of colonial schooling (*i<+uk&fy[kuk*) disrupting traditional agrarian life (*pkSik;ksa* as fields); vocabulary like *gkjs xk<+s dke ljsxk* (clerical job) marks the new economy.
c11_economics_labour | The shift from *pkSik;ksa* (ploughing fields) to *gkjs xk<+s dke ljsxk* (office work) illustrates occupational mobility and the economic value of literacy in early 20th century India.
c11_sociology_socialization | *ctj fxjs* (tilak/blessing) functions as a rites-of-passage marker; the mother uses ritual to legitimize the new identity of "literate son" within the traditional community.

## PREREQ_CONCEPT
Ability to distinguish between *denotation* (dictionary meaning) and *connotation* (emotional/cultural association) in a literary text.

## PREREQ_BEFORE
Student must have read the poem at least once and located the 7 target words in the text physically (underlined/highlighted).

## PREREQ_STUCK
If stuck, re-read the **'Before You Read' (node 001)** section on Fakir Mohan Senapati's role in Odia literature and the history of *vaxzs"kh Nan* (script reform) — this unlocks the cultural weight of *pkSik;ksa* and *phUgrh*.

## WORKED_EXAMPLE_1
PROBLEM: The textbook defines **phUgksa** as *fpÞuksa] v{kjksa* (letters/alphabets). In the line *bu dkys phUgksa ls oSQls ;s lc Loj fudyk djrs gSa*, the child says these *phUgksa* break the *lc Loj* (connection/thread). Explain how the meaning of *phUgksa* shifts from "neutral letters" to "hostile obstacles" using textual evidence.

STEPS:
- Step 1: Locate the exact line: Stanza 1, Line 3 (*bu dkys phUgksa ls oSQls ;s lc Loj fudyk djrs gSa*).
- Step 2: Identify the standard meaning from *kCn&Nfo*: *fpÞuksa] v{kjksa* (letters/alphabets).
- Step 3: Analyze the verb *fudyk djrs gSa* (break/snap). What is being broken? *lc Loj* (the thread of concentration/understanding).
- Step 4: Analyze the adjective *dkys* (slow/hesitant) modifying *phUgksa*. The letters appear "slow" because the child decodes them laboriously.
- Step 5: Synthesize the shift: For a fluent reader, *phUgksa* are transparent tools. For this child, each *phUgksa* (letter) is a discrete barrier that *snaps* his fragile focus. The word now connotes "obstacle" not "symbol".
- Step 6: Verify with the poem's arc: This hostile view is the starting point (Stanza 1); by the end, *i<+uk&fy[kuk* becomes a tool for *gkjs xk<+s dke ljsxk*.

REASONING: This 6-step process forces the student to move from definition (Step 2) to grammatical analysis (Step 3-4) to thematic synthesis (Step 5-6), mirroring the "Point-Evidence-Explanation-Link" structure required in board answers.

ANSWER: In this context, **phUgksa** does not merely mean "alphabets"; it signifies **the material resistance of the written script against an unprepared mind**. The reduplicated *dkys dkys* (slowly slowly) and the violent verb *fudyk* (snaps) transform the neutral noun *v{kj* into an active agent of disruption — each letter is a knot that unties the child's concentration (*lc Loj*).

## WORKED_EXAMPLE_2
PROBLEM: The phrase **gkjs xk<+s dke ljsxk** is glossed as *dfBukbZ esa dke vk,xk* (will get work in the office). The mother uses this as the ultimate incentive. Analyze how this single phrase encapsulates the poem's critique of colonial modernity.

STEPS:
- Step 1: Translate literally: *gkjs* (big/grand) *xk<+s* (of writing/pen) *dke* (work) *ljsxk* (will get/obtain). Gloss: "Will get the grand work of the pen/office."
- Step 2: Identify the contrast set up in the poem: *pkSik;ksa* (ploughing square fields) vs *gkjs xk<+s dke* (office work).
- Step 3: Identify the historical referent: Colonial bureaucracy created a new class of *clerks* (copyists, record-keepers) — the "babus". This was the primary pathway for lower-caste/rural boys (like Fakir Mohan himself) to escape agrarian bondage.
- Step 4: Analyze the mother's agency: She is not a passive victim; she *strategically* deploys this colonial carrot (*gkjs xk<+s dke*) to overcome the child's resistance. She speaks the language of the new economy.
- Step 5: Evaluate the irony: The "grand work" (*gkjs dke*) is actually sedentary, repetitive copying (*xk<+s dke* — pen-work), physically softer but mentally alienating compared to *pkSik;ksa* (ploughing). The poem knows this; the mother sells the *dream*.
- Step 6: Connect to title *Q.kh'oj ukFk js.kq* (Search for the lost self? / The search continues): The vocabulary *gkjs xk<+s dke ljsxk* marks the moment the child enters the colonial time-regime, losing the cyclic time of *pkSik;ksa*.

REASONING: This example models the **competency-level** demand: moving beyond "meaning" to "ideological function of vocabulary". Steps 3-4 require cross-subject history knowledge (colonial bureaucracy); Step 5 requires literary irony detection; Step 6 requires thematic synthesis.

ANSWER: **gkjs xk<+s dke ljsxk** functions as a **colonial seduction script**. Lexically, it means "clerical employment." Structurally, it is the *counter-weight* the mother places against the child's hatred of *phUgksa*. Ideologically, it reveals the poem's central tension: literacy (*i<+uk&fy[kuk*) enters this rural home not as liberation (enlightenment) but as **labour market currency** (*dfBukbZ esa dke*). The mother internalizes the colonial value hierarchy (pen > plough) to ensure survival.

## WORKED_EXAMPLE_3
PROBLEM: Synthesize the vocabulary arc of **ctj fxjs** (tilak/blessing) across the poem. The textbook gives *otz fxjs] Hkkjh foifÙk vk,*. Show how the *same ritual act* means three different things in: (A) Mother's first mention (implied), (B) Child's sarcastic refusal (*paik us ;g dgk fd eSa rks ugha i<w¡xh*), (C) Mother's final command (*dydÙks ij ctj fxjs*).

STEPS:
- Step 1: Define the **denotative core**: *ctj* = forehead/tilak-mark; *fxjs* = apply/cause to apply. Literal: "Apply tilak on forehead."
- Step 2: Context A (Implied past): Before the poem starts, *ctj fxjs* = **Traditional Rite of Passage**. Initiation into literacy (*vidyarambh*). Positive, communal, sacred.
- Step 3: Context B (Stanza 4, Child's voice): *paik us ;g dgk fd eSa rks ugha i<w¡xh / rqe rks dgrs Fks xkaèkh ckck vPNs gSa / os i<+us fy[kus dh oSQls ckr dgsaxs*. Here *ctj fxjs* (implied by *xkaèkh ckck vPNs gSa*) = **Hypocritical Ritual**. The child accuses: "You performed the sacred *ctj fxjs* for the guru, but the guru is useless." The word becomes evidence of betrayal.
- Step 4: Context C (Stanza 5, Mother's voice): *dydÙkk eSa dHkh u tkus nw¡xh / dydÙks ij ctj fxjs*. Here *ctj fxjs* = **Strategic Boundary Marking**. She refuses the city (*dydÙkk*). She performs *ctj fxjs* on the *village threshold* (*dydÙks ij*). It means: "Your literacy belongs *here*, to *us*, for *our* survival (*gkjs xk<+s dke ljsxk*)."
- Step 5: Trace the semantic trajectory: **Sacred Initiation -> Broken Contract -> Reclaimed Sovereignty**. The mother *re-purposes* the ritual to reject migration.
- Step 6: Board Answer Formulation: "The polysemy of *ctj fxjs* structures the poem's argument: education is not a ticket *out* (city), but a tool *for* the village (threshold)."

REASONING: This is the hardest worked example because it requires **tracking a single lexical item across non-contiguous stanzas** (intertextual within the poem), detecting **voice shifts** (child vs mother), and linking to **socio-historical theme** (migration vs localization). It combines 4 concepts: denotation/connotation, dramatic voice, historical context, thematic structure.

ANSWER: **ctj fxjs** is the poem's **semantic hinge**.
1. **Denotation:** Applying auspicious tilak (textbook: *otz fxjs, Hkkjh foifÙk vk,*).
2. **Stanza 4 (Child):** Becomes a symbol of **failed tradition** — "Guruji was great (*vPNs*), you did *ctj fxjs*, yet I learn nothing." Ritual = empty performance.
3. **Stanza 5 (Mother):** Becomes an act of **political refusal** — *dydÙks ij ctj fxjs* (on the threshold, not in the city). She re-sacralizes the *village* as the site of the child's future (*gkjs xk<+s dke ljsxk*). The vocabulary resolves the conflict: Literacy (*i<+uk&fy[kuk*) is domesticated, not rejected.

## COMPETENCY_QUESTION_1
QUESTION: A student writes in an exam: *"In the poem, phUgrh means reading. The child does phUgrh slowly (dkys dkys). Later the mother says i<+ yks (you read). Both mean reading. So the poem repeats the same idea."* Identify **two distinct conceptual errors** in this answer and rewrite the correction using specific vocabulary distinctions from the *kCn&Nfo*.

COMPETENCY: Critical Analysis / Conceptual Precision

STEPS:
- Step 1: Identify Error 1: Conflating **phUgrh** (decoding/struggling to read) with **i<+uk** (competent reading/literacy as a skill). The *kCn&Nfo* gives *igpkurh* for *phUgrh* but the poem contrasts the *process* (phUgrh) with the *achieved ability* (i<+uk&fy[kuk).
- Step 2: Identify Error 2: Ignoring the **agency shift**. *dkys dkys phUgrh* is the child's involuntary suffering; *i<+ yks* is the mother's imperative command transferring agency.
- Step 3: Retrieve the specific *kCn&Nfo* distinctions: *phUgrh* = *igpkurh* (activity); *i<+uk&fy[kuk* = combined skill set (goal).
- Step 4: Draft corrected answer using PEEL: Point (different words = different stages), Evidence (quotes), Explanation (process vs outcome), Link (theme of acquisition).

ANSWER: **Errors:** (1) **Lexical flattening**: Treating *phUgrh* (laborious decoding, *igpkurh*) and *i<+uk* (mastered literacy) as synonyms. The *kCn&Nfo* and poem structure mark *phUgrh* as the *painful process* (Stanza 1) and *i<+uk&fy[kuk* as the *empowering outcome* (Stanza 5: *lc tu i<+uk&fy[kuk lh[ksa*). (2) **Erasure of voice**: *dkys dkys phUgrh* describes the child's *state*; *i<+ yks* is the mother's *command*. **Corrected Answer:** "The poem traces a vocabulary arc from **phUgrh** (*igpkurh* — the child's slow, painful decoding that *snaps* his concentration *lc Loj fudyk*) to **i<+uk&fy[kuk** (the mother's goal: 'practice reading-writing all life'). The shift from intransitive struggle (*phUgrh*) to imperative mastery (*i<+ yks*) marks the transition from passive victim of script to active user of literacy for *gkjs xk<+s dke ljsxk*."

DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: The word **pkSik;ksa** appears only once in the poem text (*paik pkSik;ksa dks ysdj pjokgh djus tkrh gS*) but the *kCn&Nfo* defines it with a **double referent**: (1) *tkuojksa osQ fy,* (for children — letters) and (2) *xk;&HkSlksa osQ fy,* (for ploughing — fields). Design a **board-level long answer (120-150 words)** explaining how this single word *pkSik;ksa* structurally unifies the poem's central conflict between **Education** and **Agrarian Life**. You must use the terms *denotation*, *connotation*, *metonymy*, and *irony*.

COMPETENCY: Integrated Literary Analysis / Board Exam Writing

STEPS:
- Step 1: Open with a thesis: *pkSik;ksa* is a **metonymic pivot** condensing the poem's dialectic.
- Step 2: Define denotation: "Four-cornered/square" (geometric shape).
- Step 3: Trace Referent 1 (Education): *pkSik;ksa* = *v{kj* (letters). Connotation: Confinement, abstraction, colonial imposition. The child sees squares on paper.
- Step 4: Trace Referent 2 (Agrarian Life): *pkSik;ksa* = *khet* (fields). Connotation: Tradition, bodily labour, food security. The mother sees squares of earth.
- Step 4: Analyze the Irony: The mother *uses* the school-referent (letters) to *threaten* the farm-referent (fields) — "If you don't do *these* squares (letters), you'll do *those* squares (fields) forever." But the poem's end (*dydÙks ij ctj fxjs*) suggests the squares (letters) ultimately serve the squares (fields) — the clerk supports the farm.
- Step 5: Conclude: The word *pkSik;ksa* proves literacy is not escape but **reinforcement of the agrarian base**.

ANSWER: **PkSik;ksa: The Square that Binds Two Worlds**
The word **pkSik;ksa** (denotation: four-cornered/square) operates as a **metonymic pivot** unifying the poem's central tension. Its *kCn&Nfo* double gloss — *tkuojksa osQ fy,* (letters for children) and *xk;&HkSlksa osQ fy,* (fields for ploughing) — maps the exact coordinates of the conflict.
In the child's mouth (implied), *pkSik;ksa* connotes **alien geometry**: the square letters (*v{kj*) that *fudyk* his *lc Loj*, representing colonial discipline. In the mother's warning (*paik pkSik;ksa dks ysdj pjokgh djus tkrh gS*), *pkSik;ksa* shifts metonymically to **square fields** — the agrarian destiny she fears. The **irony** is delicious: she wields the *threat* of the plough-squares to force the pen-squares. Yet the resolution (*dydÙks ij ctj fxjs / gkjs xk<+s dke ljsxk*) reveals a deeper synthesis: the *clerical squares* (office ledgers) ultimately secure the *agrarian squares* (family land). Thus, *pkSik;ksa* proves that in this rural imagination, **literacy is not flight from the soil, but its modern defence.** The square on the page guards the square in the field.

DIFFICULTY: hard