## DEFINITION
Secondary themes are the underlying ideas, concerns, or messages in a literary work that support, contrast, or enrich the primary theme. They emerge through subplots, character interactions, setting details, and recurring motifs, adding layers of meaning to the central narrative.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student can identify at least three distinct secondary themes in the chapter, trace each theme through specific textual evidence (events, dialogues, descriptions), and explain how each secondary theme connects to or complicates the primary theme of the story.

## SCOPE_BOUNDARY
This node covers identification, analysis, and interpretation of secondary themes in "jktLFkku dh jtr cw¡nas" only. It does not cover primary theme identification (covered in node 006), literary devices (nodes 008-009), or writing skills (node 014).

## WALKTHROUGH
Imagine you are visiting your ancestral village and notice an ancient stepwell (baoli) that once sustained the entire community but now lies dry and forgotten under plastic waste. You wonder: how did something so vital become invisible? This story works similarly — the old wells are not just background; they carry forgotten wisdom, neglected responsibility, and silent resistance. To find secondary themes, first list every recurring element: the dried wells, the clerk's transfers, the villagers' silence, the contractor's measurements, the old chowkidar's memories. Then ask: what larger idea does each element represent beyond the main plot? The clerk's transfers represent bureaucratic rootlessness; the dry wells represent ecological amnesia; the chowkidar represents custodial memory. The key insight: secondary themes are the story's "groundwater" — invisible but essential for the primary theme to have depth.

## DIAGNOSTIC_QUESTION_1
What is the precise difference between a primary theme and a secondary theme in a prose narrative?

## DIAGNOSTIC_ANSWER_1
A primary theme is the central, unifying idea that the entire narrative structure serves to explore (e.g., "the collapse of traditional water systems under modern administration"). A secondary theme is a distinct but related idea that runs parallel, often through subplots or specific characters, and adds complexity (e.g., "the erosion of intergenerational knowledge transfer"). A wrong answer that equates them or calls secondary themes "less important" reveals a misunderstanding of how thematic architecture works — secondary themes are not subordinate in significance, only in structural prominence.

## DIAGNOSTIC_QUESTION_2
In "jktLFkku dh jtr cw¡nas," the recurring image of the clerk measuring the well's depth with a tape that keeps slipping appears three times. A student claims this is just a plot detail showing the well is deep. Why is this interpretation incomplete?

## DIAGNOSTIC_ANSWER_2
The slipping tape measure is a motif that embodies the secondary theme of "the inadequacy of modern bureaucratic tools to grasp traditional ecological knowledge." Each slip represents the administration's failure to measure what matters: the well's social history, its recharge patterns, the community's relationship to it. A student who sees only plot detail misses how objects function as thematic carriers — a common error when readers treat descriptive details as decorative rather than symbolic.

## DIAGNOSTIC_QUESTION_3
Apply the concept of "thematic clustering" to this chapter: Group the following textual elements into two distinct secondary theme clusters and name each cluster: (a) the contractor's blueprint ignoring the well's catchment area, (b) the old chowkidar teaching his grandson to read the water lines on the well wall, (c) the clerk's file noting "well: non-functional" without visiting it, (d) the village women walking 3 km for water while the well has water at 40 ft.

## DIAGNOSTIC_ANSWER_3
Cluster 1: "Epistemic Violence of Bureaucracy" — elements (a) and (c) show how administrative categories (blueprints, files) erase lived hydrological reality. Cluster 2: "Embodied Ecological Memory" — elements (b) and (d) show how traditional knowledge (reading water lines, knowing the well still works) persists despite official negation. A wrong answer that mixes these clusters or creates vague labels like "water problems" reveals inability to distinguish between structural critique and cultural resilience as separate thematic strands.

## DIAGNOSTIC_QUESTION_4
Analyze how the secondary theme of "administrative nomadism" (the clerk's frequent transfers) structurally mirrors the primary theme of "hydrological discontinuity" (the breaking of traditional water chains). Provide two specific textual parallels.

## DIAGNOSTIC_ANSWER_4
Parallel 1: Just as the clerk leaves before completing a single monsoon cycle (transfer every 11 months), the traditional well maintenance cycle (desilting before monsoon, worship after) is broken by administrative schedules. Parallel 2: The clerk's file travels with him but contains no local knowledge — like the piped water scheme that brings water from 50 km away but knows nothing of the aquifer beneath the village. A wrong answer that treats these as mere coincidences misses the author's structural analogy: both themes depict "displacement as governance."

## DIAGNOSTIC_QUESTION_5
Evaluate this claim: "The contractor's character serves only as a villain; his greed is a simple secondary theme of corruption." Defend or refute using the concept of thematic complexity.

## DIAGNOSTIC_ANSWER_5
Refute. The contractor embodies the secondary theme of "development as extraction" — his measurements are not just greedy but epistemically violent: he measures the well's diameter for a cover slab but ignores its recharge zone, mirroring how the state measures "coverage" (taps installed) not "sustainability" (aquifer health). His villainy is structural, not personal. A student who reduces him to "corruption" commits the senior-secondary error of moralizing where the text offers systemic critique — confusing character flaw with thematic function.

## DIAGNOSTIC_QUESTION_6
Create a 4-line dialogue between the old chowkidar and the new clerk that dramatizes the clash between the secondary themes of "custodial memory" and "administrative amnesia" without naming either theme explicitly.

## DIAGNOSTIC_ANSWER_6
Chowkidar: "Sahib, the well breathes. In Jeth it sighs at noon; in Bhadon it laughs at midnight. Your tape measures bone, not breath."
Clerk: "Chowkidar ji, the file says 'dry well — sanction handpump.' Files don't breathe. They sanction."
Chowkidar: "And when the handpump fails in the third summer? The file will sanction another?"
Clerk: "By then, I'll be in another district. Another file. Another well."
A poor answer that has characters explain themes directly ("I represent memory, you represent amnesia") reveals inability to dramatize thematic conflict through subtext — a critical skill for board-level analysis.

## COMMON_MISCONCEPTION
Students often think "secondary theme" means "minor theme" or "sub-theme" that can be listed like topics (e.g., "water scarcity, corruption, tradition vs modernity"). This is a Class 10 carryover where themes were treated as labels. In Class 11, a secondary theme is a *dynamic argument* the text makes through pattern and variation — e.g., not "bureaucracy" but "how bureaucratic temporality (transfers, files, sanctions) actively dismantles ecological temporality (monsoon cycles, recharge rates, generational knowledge)." The error stems from reading for *content* rather than *structure*: they spot what the story is *about* instead of how the story *thinks*.

## ON_FAILURE
1. Ask the student to reread only the three scenes where the clerk interacts with the well (first visit, measurement, transfer order). 2. Have them make a two-column table: Column A — what the clerk *does/sees/says*; Column B — what the well *is/does/history* in that same moment. 3. Guide them to see each row as a micro-conflict between two worldviews. 4. Then ask: "What larger idea does each column represent?" This moves them from listing topics to extracting thematic arguments.

## BUILDS_ON
c11_hin_v_cbse_05_006 (Theme: Primary Theme and Message) — students must first anchor the primary theme before identifying how secondary themes orbit, challenge, or deepen it.

## LEADS_TO
c11_hin_v_cbse_05_008 (Literary Devices: Imagery and Metaphor) — secondary themes are often carried by recurring images/metaphors (the slipping tape, the breathing well); analyzing devices requires knowing the themes they serve.

## PREREQUISITE_NODE_IDS
c11_hin_v_cbse_05_001, c11_hin_v_cbse_05_002, c11_hin_v_cbse_05_003, c11_hin_v_cbse_05_004, c11_hin_v_cbse_05_005, c11_hin_v_cbse_05_006
## PREREQUISITE_REASONS
c11_hin_v_cbse_05_001: Context/background knowledge (water crisis in Rajasthan, administrative history) is essential to decode thematic references.
c11_hin_v_cbse_05_002: Plot structure knowledge needed to locate where secondary themes emerge (subplots, parallel scenes).
c11_hin_v_cbse_05_003: Setting/atmosphere (the well as physical and symbolic space) carries secondary themes materially.
c11_hin_v_cbse_05_004: Protagonist's (clerk's) arc embodies "administrative nomadism" — a key secondary theme.
c11_hin_v_cbse_05_006: Primary theme ("hydrological discontinuity") is the gravitational center; secondary themes must be mapped in relation to it.
c11_hin_v_cbse_05_005: Secondary themes (memory, displacement, ecological wisdom) emerge from distinct supporting character arcs.  
## FORWARD_NODE_IDS
c11_hin_v_cbse_05_008, c11_hin_v_cbse_05_009, c11_hin_v_cbse_05_013, c11_hin_v_cbse_05_014, c11_hin_v_cbse_05_012, c11_hin_v_cbse_05_015, c12_hin_a_cbse_01_007, c12_hin_a_cbse_05_007, c12_hin_a_cbse_08_007, c12_hin_a_cbse_10_007

## FORWARD_REASONS
c11_hin_v_cbse_05_008: Imagery/metaphor (e.g., well as "breathing body") are the vehicles of secondary themes.
c11_hin_v_cbse_05_009: Irony/symbolism (e.g., file sanctioning handpump over functioning well) enact thematic tensions.
c11_hin_v_cbse_05_013: Critical thinking requires synthesizing primary + secondary themes into an interpretive argument.
c11_hin_v_cbse_05_014: Writing skills (analytical paragraph, essay) demand thematic evidence and multi-theme integration.
c11_hin_v_cbse_05_012: Secondary themes offer additional lenses (gender, environment, education) for multi-layered inferences.  
c11_hin_v_cbse_05_015: Secondary themes (memory, identity, power) offer multiple discussion angles  
c12_hin_a_cbse_01_007: Vitan Chapter 5 consolidated thematic analysis across genres.  
c12_hin_a_cbse_05_007: Class 11 Vitan Chapter 5 similarly developed theme-layering analysis in non-fiction prose.  
c12_hin_a_cbse_08_007: अगला तार्किक चरण: Secondary themes are the underlying, complementary ideas in a literary work that support, contrast w... इस नोड की अवधारणाओं को सीधे उपयोग/विस्तारित करता है।  
c12_hin_a_cbse_10_007: Builds stamina for multi-theme analysis in longer texts.  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
No prior class nodes available for Hindi Vitan.

## CHAIN_DESCRIPTION
c11_hin_v_cbse_05_006 -> c11_hin_v_cbse_05_007 -> c11_hin_v_cbse_05_008

## THIS_FORMULA
N/A - conceptual

## FORMULA_VARIABLES
N/A

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
analytical

## CROSS_SUBJECT
c11_geography_water_resources | The chapter's secondary themes (traditional vs modern water management, bureaucratic failure of decentralized systems) directly mirror Class 11 Geography Chapter "Water Resources" — specifically the critique of mega-projects vs indigenous conservation (johads, baolis) and the concept of "hydrological cycle disruption by administrative boundaries."
c11_civics_local_governance | The clerk-contractor-villager triangle dramatizes Class 11 Political Science "Local Governance" tensions: 73rd Amendment's devolution vs actual bureaucratic capture, the gap between "sanction" (file) and "function" (well), and how frequent transfers undermine accountability to local ecological knowledge.

## PREREQ_CONCEPT
Primary theme identification and textual evidence citation (from node 006) — without a clear primary theme, secondary themes become an unstructured list.

## PREREQ_BEFORE
Student must be able to state the primary theme of "jktLFkku dh jtr cw¡nas" in one precise sentence and cite three textual moments that establish it.

## PREREQ_STUCK
If stuck, review node 006's worked examples on primary theme extraction — specifically the "thematic statement vs thematic topic" distinction and the evidence-mapping table.

## WORKED_EXAMPLE_1
PROBLEM: Identify and analyze the secondary theme of "gendered water labor" in the chapter, using the scene where village women wait at the handpump while the clerk inspects the well.

STEPS:
- Step 1: Locate the scene — Chapter middle, after the clerk's first well visit. Women are described waiting with matkas at the new handpump; the clerk is inside the well compound with the contractor.
- Step 2: Identify the thematic pattern — The text contrasts the women's embodied knowledge (they know which handpump yields sweet water, they time their visits to avoid queues) with the clerk's abstract knowledge (file says "water supply provided").
- Step 3: Trace the gendered division — Men (clerk, contractor, chowkidar) negotiate the well's *status* (functional/non-functional, heritage/obstacle); women negotiate the well's *water* (daily survival, quality, access). The well's drying affects women first and most.
- Step 4: Connect to primary theme — Primary theme: "hydrological discontinuity." This secondary theme shows *who bears the cost* of that discontinuity — not the clerk (transferred), not the contractor (paid), but the women whose labor intensifies as systems fail.
- Step 5: Formulate the thematic argument — "Gendered water labor" is not just "women fetch water"; it is the text's argument that administrative water governance is structurally blind to the reproductive labor that patches its failures.

REASONING: This 5-step process moves from textual location to pattern recognition to structural analysis to thematic synthesis — the exact chain required for board-level "analyze" questions. It avoids the trap of treating gender as a "topic" rather than a "thematic lens."

ANSWER: The secondary theme "gendered water labor" argues that the collapse of traditional water systems (primary theme) redistributes water labor onto women's bodies, while bureaucratic masculinity (clerk/contractor) remains insulated from this consequence. Evidence: women's matkas vs clerk's file; women's queue knowledge vs contractor's blueprint; women's wait vs clerk's transfer.

## WORKED_EXAMPLE_2
PROBLEM: The old chowkidar refuses to hand over the well keys to the contractor, saying "These keys open more than locks." Analyze how this moment crystallizes the secondary theme of "custodial memory vs legal possession."

STEPS:
- Step 1: Establish the conflict — Legal possession: contractor has sanction letter, measurement tape, government order. Custodial memory: chowkidar has keys, oral history of well's construction, knowledge of its fractures and veins.
- Step 2: Decode the metaphor — "Keys open more than locks" = keys unlock stories, recharge patterns, community agreements, ancestral vows. The contractor's keys (if he had them) would only open the physical cover.
- Step 3: Map to broader thematic structure — This mirrors the primary conflict: the state holds legal title to water (via sanctions, pipes, contracts) but lacks custodial memory of the aquifer. The chowkidar holds no legal title but holds the *epistemic* title.
- Step 4: Identify the narrative function — This moment refuses the binary of "tradition vs modernity." The chowkidar isn't opposing development; he's asserting that *any* intervention on the well requires custodial consent because the well is a living system, not dead infrastructure.
- Step 5: Articulate the thematic argument — "Custodial memory" is the secondary theme that claims: ecological continuity depends on *relational* knowledge (between people, well, rain, rock), not *transactional* rights (sanction, contract, transfer).

REASONING: The steps model how a single dialogue line can be "unpacked" into a full thematic argument by moving through literal, metaphorical, structural, narrative, and philosophical layers — a senior-secondary skill.

ANSWER: The chowkidar's keys symbolize custodial memory — the embodied, intergenerational knowledge that the well is a node in a living hydrological-social web. The contractor's sanction letter symbolizes legal possession — the state's claim to manage water as a resource separable from its ecology. The theme argues that without custodial memory, legal possession produces ecological amnesia (the well gets covered, the aquifer forgotten).

## WORKED_EXAMPLE_3
PROBLEM: Synthesize how three secondary themes — (1) administrative nomadism, (2) epistemic violence of blueprints, (3) gendered water labor — converge in the final scene where the clerk receives his transfer order while the women's handpump runs dry.

STEPS:
- Step 1: Reconstruct the final scene — Clerk reads transfer order (11th month, as always). Contractor's handpump (installed per blueprint) sputters air. Women wait, then leave empty-handed. Chowkidar locks the old well's cover slab. Monsoon clouds gather but don't break.
- Step 2: Map each theme to the scene — (1) Administrative nomadism: clerk's transfer order = the bureaucratic cycle completing itself, indifferent to the hydrological cycle. (2) Epistemic violence: blueprint promised "water security" via handpump; reality = dry pipe because blueprint ignored recharge zone (chowkidar's knowledge). (3) Gendered labor: women's empty matkas = the physical cost of that epistemic violence, borne by those excluded from both sanction and custodial memory.
- Step 3: Show convergence — The three themes are not parallel; they are *causally linked*: administrative nomadism (short tenures) incentivizes epistemic violence (quick blueprints over slow knowledge) which externalizes cost onto gendered labor (women's unpaid work fills the gap).
- Step 4: Link to primary theme — Primary theme: "hydrological discontinuity." This convergence *is* the mechanism of discontinuity: the social/administrative system is designed to break the hydrological cycle.
- Step 5: Evaluate the author's stance — The text does not offer a solution; it offers a diagnosis. The convergence in the final scene is a "systems portrait" — showing how three distinct logics (bureaucratic, technocratic, patriarchal) align to produce water scarcity.
- Step 6: Formulate board-level answer structure — Topic sentence: "The final scene synthesizes three secondary themes to reveal the structural production of water scarcity." Then three evidence-explanation pairs (one per theme). Concluding sentence: "Together, they demonstrate that the old wells' death is not natural but administrative."

REASONING: This 6-step synthesis models the highest-order competency: multi-theme integration with causal reasoning, directly mirroring the "Critical Thinking" (node 013) and "Writing Skills" (node 014) board requirements.

ANSWER: The final scene is a thematic convergence point where administrative nomadism (clerk's cyclic departure), epistemic violence (blueprint's dry handpump), and gendered labor (women's empty return) interlock to show that hydrological discontinuity is an administrative achievement. The clerk leaves, the blueprint fails, the women pay — and the old well, locked under its new slab, becomes a monument to a system that measures everything and understands nothing.

## COMPETENCY_QUESTION_1
QUESTION: A Class 11 student writes in their exam: "The secondary themes of this story are corruption, water scarcity, and tradition vs modernity." Using the distinction between "thematic topic" and "thematic argument," explain why this answer would score poorly and rewrite it as a high-scoring thematic statement for *one* of these.

COMPETENCY: Thematic precision — distinguishing topic from argument and writing board-level thematic statements.

STEPS:
- Step 1: Identify the error — "Corruption," "water scarcity," "tradition vs modernity" are *topics* (nouns), not *arguments* (claims the text makes about those topics).
- Step 2: Explain the board expectation — CBSE Class 11 marking schemes require thematic statements to be complete sentences expressing a *perspective* (e.g., "The story argues that...").
- Step 3: Demonstrate conversion — Take "corruption" → convert to argument: "The story exposes how bureaucratic corruption is not merely individual greed but a structural feature of a system that measures development in sanctions rather than sustainability."
- Step 4: Provide the rewrite template — "The secondary theme of [topic] is developed through [textual pattern] to argue that [thematic claim]."

ANSWER: The student's answer lists topics, not themes. A theme is a *proposition*, not a *label*. High-scoring rewrite for "corruption": "The secondary theme of bureaucratic corruption is dramatized through the contractor-clerk nexus to argue that corruption in water governance functions as an epistemic filter — it ensures only those interventions that generate paper trails (sanctions, measurements, transfers) are sanctioned, while those requiring ecological patience (desilting, recharge protection, community management) are rendered invisible and unfundable."

DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: The chapter ends with the line: "The well was covered. The file was closed. The rain came anyway." Analyze how this ending uses *structural irony* to bind the primary theme and all three secondary themes discussed in the worked examples into a single closing argument.

COMPETENCY: Synthetic thematic analysis — integrating primary and secondary themes through a textual device (irony) to produce a unified interpretation.

STEPS:
- Step 1: Deconstruct the three clauses — Clause 1: "The well was covered" = epistemic violence of blueprints (concrete over knowledge). Clause 2: "The file was closed" = administrative nomadism (bureaucracy completes its cycle). Clause 3: "The rain came anyway" = hydrological continuity (primary theme) persisting despite human discontinuity.
- Step 2: Identify the irony — The file closes *on* the well, but the rain opens *on* the aquifer. The administrative act of closure is structurally irrelevant to the hydrological act of recharge — yet the covered well *prevents* that recharge. Irony: the system that claims to manage water ensures its waste.
- Step 3: Map secondary themes onto the irony — Gendered labor: women will still walk for water next summer because the rain that "came anyway" was not caught. Custodial memory: the chowkidar's keys are now useless on a covered well — memory locked out. Administrative nomadism: the clerk who closed the file is gone; the next clerk will open a new file for a new handpump.
- Step 4: Synthesize the closing argument — The ending argues that the primary theme (hydrological discontinuity) is not a tragedy of nature but a *comedy of administration* — the system works perfectly (files open, close, transfer) while the ecology it governs works perfectly otherwise (rain falls, aquifer waits, well is covered). The disconnect *is* the system.
- Step 5: Write the board-level synthesis — "The final sentence's structural irony — administrative closure vs hydrological opening — fuses the primary theme of hydrological discontinuity with the secondary themes of epistemic violence (well covered), administrative nomadism (file closed), and gendered labor (rain came anyway, but not for the women). The text closes not with resolution but with indictment: the bureaucracy has perfected the art of closing files on open wounds."

ANSWER: The ending's irony binds all themes by showing that administrative completion (covered well, closed file) is ecologically suicidal (rain wasted). The primary theme — hydrological discontinuity — is revealed as the *product* of the three secondary themes working in concert: blueprints that erase recharge (epistemic violence), tenures that erase accountability (administrative nomadism), and a governance that erases the labor of those who actually manage water (gendered labor). The rain "coming anyway" is not hope; it is evidence of the state's irrelevance to the hydrological cycle it claims to govern.

DIFFICULTY: hard