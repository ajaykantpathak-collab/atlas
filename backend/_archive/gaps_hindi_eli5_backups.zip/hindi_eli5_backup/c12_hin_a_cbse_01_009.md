## DEFINITION
Irony (विरोधाभास/व्यंग्य) in poetry is a literary device where the intended meaning of words or situations is opposite to their literal or apparent meaning, creating a contrast between expectation and reality. Symbolism (प्रतीकवाद) is the use of concrete images, objects, or actions to represent abstract ideas, emotions, or concepts beyond their literal sense. In Class 12 Hindi Antra Chapter 1, both devices operate together in Tarashankar Bandyopadhyay's poems "नसोलसुक का छंद" and "डाकुसफ्याक का छंद" to critique social injustice and articulate a vision of inclusive nationalism.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student must be able to (1) identify specific instances of situational, verbal, and dramatic irony in both poems with textual evidence, (2) explain how symbols like "सूखी डालियाँ," "नक़ली फूल," "वृक्ष," and "जड़ें" function as multi-layered signifiers, and (3) write a structured analytical answer (PEEL format) connecting these devices to the poems' central themes of gendered oppression and composite nationalism.

## SCOPE_BOUNDARY
This node covers irony and symbolism exclusively in the two poems of Chapter 1 ("नसोलसुक का छंद" and "डाकुसफ्याक का छंद"). It does NOT cover imagery/metaphor (node 008), other chapters' literary devices, or general theory of irony/symbolism without textual anchoring. Analysis stays within CBSE Class 12 NCERT Antra scope.

## WALKTHROUGH
Imagine you are reading a poem where a woman says "मेरा पति आज़ादी का सिपाही है" while she starves — the words praise him but the reality condemns the system that abandons her. That gap is irony. Now picture a "वृक्ष" (tree) described with "जड़ें गहरी" and "शाखाएँ फैली" — it is not just a tree; it stands for a civilization with deep roots and diverse branches. Start by reading both poems aloud twice: first for literal meaning, second marking every line where what is said clashes with what is meant (irony) or where an object carries extra meaning (symbol). Ask: "What is the poet NOT saying directly?" That question unlocks both devices. The key insight: in these poems, irony exposes the betrayal of the marginalized, while symbols reconstruct a shattered wholeness.

## DIAGNOSTIC_QUESTION_1
Define situational irony and give one example from "नसोलसुक का छंद" where the character's expectation contradicts the actual outcome.

## DIAGNOSTIC_ANSWER_1
Situational irony occurs when the outcome of a situation is sharply contrary to what was expected or intended. In "नसोलसुक का छंद," Nasolsuk's husband joins the freedom struggle expecting to secure a better future for his family, but his absence leaves her destitute and vulnerable — the very freedom he fights for bypasses his own home. A wrong answer (e.g., "irony is when someone lies") reveals confusion between verbal irony (saying the opposite) and situational irony (outcome vs expectation), and inability to locate the device in the specific textual context.

## DIAGNOSTIC_QUESTION_2
In "डाकुसफ्याक का छंद," the line "वृक्ष की जड़ें गहरी हैं, शाखाएँ फैली हैं" uses the tree as a symbol. Explain in your own words what abstract idea this symbol represents and why the poet chooses a tree rather than a building or a river.

## DIAGNOSTIC_ANSWER_2
The tree symbolizes Indian civilization/composite culture: deep roots = ancient heritage and shared history; spreading branches = diverse communities, languages, religions growing from the same trunk. A tree is chosen because it is organic, living, interdependent (roots feed branches, leaves feed roots), and resilient — unlike a building (static, man-made, collapses) or a river (flows away, no visible unity). A wrong answer listing only "unity" or "strength" without the root/branch mapping shows superficial symbol-decoding; missing the organic metaphor reveals failure to analyze why this specific vehicle (tree) carries the tenor (nation).

## DIAGNOSTIC_QUESTION_3
Apply the concept of dramatic irony to the moment in "नसोलसुक का छंद" where Nasolsuk addresses her absent husband: "तुम्हारे लिए मैंने सब सहा." Who knows more than the speaker at this moment, and how does that knowledge gap create irony?

## DIAGNOSTIC_ANSWER_3
Dramatic irony arises when the audience/reader knows something a character does not. Here, the reader knows (from the poem's context) that the husband's "freedom" has not brought relief to Nasolsuk; the system exploits both. She believes her suffering serves a noble cause; we see it serves a patriarchal-colonial structure that ignores women. The knowledge gap: Nasolsuk thinks sacrifice = redemption; reader sees sacrifice = erasure. A wrong answer confusing this with situational irony ("she expected X, got Y") misses the structural reader-character knowledge asymmetry that defines dramatic irony.

## DIAGNOSTIC_QUESTION_4
Compare the function of "नक़ली फूल" (artificial flowers) in "नसोलसुक का छंद" with "पक्षी" (birds) in "डाकुसफ्याक का छंद." Both are symbols — but one signifies falseness, the other freedom. Analyze how each symbol's meaning is derived from its physical properties in the poem.

## DIAGNOSTIC_ANSWER_4
"नक़ली फूल" — made of paper/cloth, never wilt, no fragrance, mass-produced — symbolize hollow rituals, performative patriotism, and the fake honors bestowed on women's suffering. Their physical lifelessness maps to emotional/spiritual emptiness. "पक्षी" — fly freely across branches, nest in the tree, sing diverse songs — symbolize citizens/communities finding shelter and expression in the composite nation. Their mobility and song map to liberty and cultural pluralism. A wrong answer that merely labels them "symbols of bad/good" without linking physical trait → abstract meaning shows inability to do semiotic analysis (signifier → signified).

## DIAGNOSTIC_QUESTION_5
Evaluate this claim: "The irony in 'नसोलसुक का छंद' weakens the poem's feminist critique because it makes the woman appear passive." Defend or refute using textual evidence.

## DIAGNOSTIC_ANSWER_5
Refute. The irony *is* the critique: it exposes how patriarchal nationalism conscripts women's labor ("मैंने हक़ीक़त का बोझ उठाया") while denying them agency. Nasolsuk's final lines — "दुनिया! तुम इसे न छीन पाओगी / इससे प्यार की गंध आती है" — reclaim voice. The irony highlights systemic betrayal, not female passivity. A wrong answer agreeing with the claim misses that irony here targets the *structure*, not the victim; it also ignores the poem's closing resistance, revealing a reading that stops at victimhood without tracing the arc to assertion.

## DIAGNOSTIC_QUESTION_6
Create a four-line stanza using *both* irony and symbolism to depict a modern Indian student who studies "Digital India" by candlelight during a power cut. Use a concrete object as symbol and an outcome-expectation gap as irony.

## DIAGNOSTIC_ANSWER_6
Example stanza:
"डिजिटल इंडिया का पाठ पढ़ता हूँ दीये की रोशनी में,
लैपटॉप बंद, बैटरी मरी — भविष्य अंधेरे में चमकता है।
किताब का पन्ना (प्रतीक: ज्ञान जो बिजली नहीं माँगता)
हवा के झोंके से फड़फड़ाता है — असली नेटवर्क यही है।"
Symbol: किताब का पन्ना = resilient, non-digital knowledge. Irony: studying a digital future in analog darkness. A poor answer uses only metaphor ("candle = hope") without irony, or only irony ("power cut during Digital India class") without a developed symbol, showing inability to integrate both devices organically.

## COMMON_MISCONCEPTION
Students treat irony and symbolism as "spot-the-device" exercises: they underline "नक़ली फूल" and write "symbol of falseness" without explaining *how* the physical properties (mass-produced, scentless, unwilting) map to the abstract concept (hollow patriotism, performative grief). Similarly, they label "husband away, wife suffers" as "irony" but cannot distinguish situational (outcome vs expectation) from dramatic (reader knows more than character) or verbal (words vs intent). The root error: memorizing definitions instead of practicing the *interpretive move* — tracing the semiotic link (symbol) or the knowledge/outcome gap (irony) step by step. This costs marks in board exams where "explain with reference to context" requires the *mechanism*, not just the label.

## ON_FAILURE
If the student cannot distinguish irony types or explain symbol-mechanism: (1) Revisit c12_hin_a_cbse_01_008 (Imagery and Metaphor) — the signifier/signified logic is identical; practice with 3 simple symbols from daily life (e.g., "school bell = authority/control," "broken watch = lost time"). (2) Use the "Irony Triangle" worksheet: for each poem moment, fill three columns — *What is said/expected*, *What actually happens/is known*, *Type of irony*. (3) Re-diagnose with Diagnostic Questions 3 and 4 — require written semiotic mapping (physical trait → abstract meaning) for two symbols, and irony-type labeling with evidence for two moments.

## BUILDS_ON
c12_hin_a_cbse_01_008 (Literary Devices: Imagery and Metaphor) — the semiotic framework (vehicle/tenor, signifier/signified) established there is directly applied to symbols; irony adds the evaluative gap dimension.

## LEADS_TO
c12_hin_a_cbse_01_013 (Critical Thinking: Analysis and Interpretation) — mastery of device-analysis enables full critical essays on the chapter's themes.

## PREREQUISITE_NODE_IDS
c12_hin_a_cbse_01_008, c11_hin_ar_cbse_01_009, c11_hin_ar_cbse_02_009, c11_hin_v_cbse_01_009, c12_hin_a_cbse_01_001, c12_hin_a_cbse_01_006, c12_hin_a_cbse_01_007

## PREREQUISITE_REASONS
c12_hin_a_cbse_01_008: Imagery/Metaphor node establishes the signifier-signified analytical framework essential for symbol decoding. c11_hin_ar_cbse_01_009: Class 11 Antra Chapter 1 Irony/Symbolism node provides foundational definitions and simpler poem examples (e.g., "कबीर के पद") that this node deepens. c11_hin_ar_cbse_02_009: Class 11 Chapter 2 reinforces device identification in a different textual context (prose/poetry mix). c11_hin_v_cbse_01_009: Class 11 Vitan Chapter 1 offers complementary exposure to irony/symbolism in non-fiction narrative, broadening genre experience.
c12_hin_a_cbse_01_001: Irony and symbolism function within the cultural framework.  
c12_hin_a_cbse_01_006: Irony/symbolism (node 009) deepens the primary theme — e.g., the irony of "duty" that kills.  
c12_hin_a_cbse_01_007: Irony and symbolism often *encode* secondary themes (e.g., sindoor as ironic symbol).  
c11_hin_ar_cbse_01_009: Irony is a literary device where the intended meaning of words or events is opposite to th... की समझ आवश्यक है, क्योंकि यह नोड (Irony (विरोधाभास/व्यंग्य) in poetry is a literary device where the intended meaning of wor...) इसी आधार पर आगे बढ़ता है।  
c11_hin_ar_cbse_02_009: Irony in "फेंकू उल्हनिहु" is the contrast between appearance and reality where Phenku's ma... की समझ आवश्यक है, क्योंकि यह नोड (Irony (विरोधाभास/व्यंग्य) in poetry is a literary device where the intended meaning of wor...) इसी आधार पर आगे बढ़ता है।  
c11_hin_v_cbse_01_009: Irony (व्यंग्य) is a literary device where the intended meaning of words or situations is... की समझ आवश्यक है, क्योंकि यह नोड (Irony (विरोधाभास/व्यंग्य) in poetry is a literary device where the intended meaning of wor...) इसी आधार पर आगे बढ़ता है।  

## FORWARD_NODE_IDS
c12_hin_a_cbse_01_010, c12_hin_a_cbse_01_012, c12_hin_a_cbse_01_013, c12_hin_a_cbse_01_011, c12_hin_a_cbse_01_014

## FORWARD_REASONS
c12_hin_a_cbse_01_010: Vocabulary in Context requires recognizing how words acquire symbolic/ironic weight beyond dictionary meaning. c12_hin_a_cbse_01_012: Comprehension questions (literal/inferential) often test irony/symbolism inference directly. c12_hin_a_cbse_01_013: Critical Thinking essays demand device-based textual evidence — this node supplies the analytical toolkit.
c12_hin_a_cbse_01_011: Irony and symbolism are conveyed through syntactic patterns like inversion.  
c12_hin_a_cbse_01_014: Irony/symbolism analysis deepens Explanation step  
c12_hin_a_cbse_01_012: Irony/symbolism knowledge needed for deeper inferences (e.g., "ckoyh" as ironic address)  
c12_hin_a_cbse_01_013: Irony and symbolism knowledge needed for deeper interpretation  

## CROSS_SUBJECT_PREREQS
c11_hin_ar_cbse_01_009, c11_hin_ar_cbse_02_009, c11_hin_ar_cbse_03_009, c11_hin_ar_cbse_04_009, c11_hin_ar_cbse_05_009, c11_hin_ar_cbse_06_009, c11_hin_ar_cbse_07_009, c11_hin_ar_cbse_08_009, c11_hin_ar_cbse_09_009, c11_hin_ar_cbse_10_009, c11_hin_ar_cbse_11_009, c11_hin_ar_cbse_12_009, c11_hin_ar_cbse_13_009, c11_hin_ar_cbse_14_009, c11_hin_ar_cbse_15_009, c11_hin_ar_cbse_16_009, c11_hin_v_cbse_01_009, c11_hin_v_cbse_02_009, c11_hin_v_cbse_03_009, c11_hin_v_cbse_04_009, c11_hin_v_cbse_05_009
## CROSS_SUBJECT_REASONS
c11_hin_ar_cbse_01_009: Class 11 Antra Chapter 1 introduces irony/symbolism in Kabir/Meera poems — same devices, simpler texts, builds the conceptual ladder. c11_hin_v_cbse_01_009: Class 11 Vitan Chapter 1 uses irony/symbolism in memoir/history — shows cross-genre transfer, reinforcing that these are universal literary tools, not poem-only tricks.
c11_hin_ar_cbse_02_009: अन्य विषय की सहायता: Irony in "फेंकू उल्हनिहु" is the contrast between appearance and reality where Phenku's ma... के तत्व इस नोड में प्रयुक्त होते हैं।  
c11_hin_ar_cbse_03_009: अन्य विषय की सहायता: Irony is a literary device where there is a contrast between expectation and reality—what... के तत्व इस नोड में प्रयुक्त होते हैं।  
c11_hin_ar_cbse_04_009: अन्य विषय की सहायता: Irony (व्यंग्य) is a literary device in which the intended meaning of a statement, situati... के तत्व इस नोड में प्रयुक्त होते हैं।  
c11_hin_ar_cbse_05_009: अन्य विषय की सहायता: Irony is a literary device where the intended meaning of words or events is opposite to th... के तत्व इस नोड में प्रयुक्त होते हैं।  
c11_hin_ar_cbse_06_009: अन्य विषय की सहायता: Irony is a literary device where the intended meaning of words or events is opposite to th... के तत्व इस नोड में प्रयुक्त होते हैं।  
c11_hin_ar_cbse_07_009: अन्य विषय की सहायता: Irony is a literary device where the intended meaning of words or events is opposite to th... के तत्व इस नोड में प्रयुक्त होते हैं।  
c11_hin_ar_cbse_08_009: अन्य विषय की सहायता: Irony is a literary device where the intended meaning of words or situations contrasts sha... के तत्व इस नोड में प्रयुक्त होते हैं।  
c11_hin_ar_cbse_09_009: अन्य विषय की सहायता: Irony is a literary device where the intended meaning of words or situations is opposite t... के तत्व इस नोड में प्रयुक्त होते हैं।  
c11_hin_ar_cbse_10_009: अन्य विषय की सहायता: Irony in Kabir's poetry is the deliberate contrast between surface meaning and deeper spir... के तत्व इस नोड में प्रयुक्त होते हैं।  
c11_hin_ar_cbse_11_009: अन्य विषय की सहायता: Irony is a literary device where the intended meaning of words is opposite to their litera... के तत्व इस नोड में प्रयुक्त होते हैं।  
c11_hin_ar_cbse_12_009: अन्य विषय की सहायता: Irony in this poem is the contrast between the postman's role as a deliverer of written co... के तत्व इस नोड में प्रयुक्त होते हैं।  
c11_hin_ar_cbse_13_009: अन्य विषय की सहायता: Irony is a literary device where there is a contradiction between appearance and reality,... के तत्व इस नोड में प्रयुक्त होते हैं।  
c11_hin_ar_cbse_14_009: अन्य विषय की सहायता: Irony is a literary device where the intended meaning of words or events is opposite to th... के तत्व इस नोड में प्रयुक्त होते हैं।  
c11_hin_ar_cbse_15_009: अन्य विषय की सहायता: Irony in this poem is the sustained contrast between the speaker's repeated denial ("lcls... के तत्व इस नोड में प्रयुक्त होते हैं।  
c11_hin_ar_cbse_16_009: अन्य विषय की सहायता: Irony is a literary device where the intended meaning of words or situations is opposite t... के तत्व इस नोड में प्रयुक्त होते हैं।  
c11_hin_v_cbse_01_009: अन्य विषय की सहायता: Irony (व्यंग्य) is a literary device where the intended meaning of words or situations is... के तत्व इस नोड में प्रयुक्त होते हैं।  
c11_hin_v_cbse_02_009: अन्य विषय की सहायता: Irony (विडंबना) is a literary device where the intended meaning of words or events contrad... के तत्व इस नोड में प्रयुक्त होते हैं।  
c11_hin_v_cbse_03_009: अन्य विषय की सहायता: Irony is a literary device where the intended meaning of words or situations differs signi... के तत्व इस नोड में प्रयुक्त होते हैं।  
c11_hin_v_cbse_04_009: अन्य विषय की सहायता: Irony (विडंबना/व्यंग्य) is a literary device where the intended meaning of words or situat... के तत्व इस नोड में प्रयुक्त होते हैं।  
c11_hin_v_cbse_05_009: अन्य विषय की सहायता: Irony is a literary device where the intended meaning of words or events is opposite to th... के तत्व इस नोड में प्रयुक्त होते हैं।  

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_01_009 -> c12_hin_a_cbse_01_008 -> c12_hin_a_cbse_01_009 -> c12_hin_a_cbse_01_013

## THIS_FORMULA
Symbol Analysis Protocol: (1) Identify the concrete vehicle (object/image/action). (2) List its physical/observable properties in the text. (3) Map each property to an abstract tenor (idea/emotion/theme). (4) State the symbolic equation: Vehicle → Tenor via Property X. Irony Analysis Protocol: (1) State the expectation / literal meaning / character's knowledge. (2) State the reality / intended meaning / reader's knowledge. (3) Name the gap type: Situational / Verbal / Dramatic. (4) Explain the thematic work the gap performs.

## FORMULA_VARIABLES
Vehicle = concrete symbol (e.g., नक़ली फूल, वृक्ष); Tenor = abstract meaning (e.g., खोखला राष्ट्रवाद, संयुक्त संस्कृति); Property = physical trait enabling the mapping (e.g., गंधहीन, जड़ें गहरी); Expectation = what character/reader anticipates; Reality = what actually occurs; Gap-Type = Situational/Verbal/Dramatic.

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
analytical

## CROSS_SUBJECT
N/A | The poem "डाकुसफ्याक का छंद" articulates a composite nationalism (tree with diverse branches) that directly parallels the History chapter on "Nationalism in India" — both negotiate unity-in-diversity as a historical project. c12_sociology_02_social_change | "नसोलसुक का छंद" dramatizes gendered impact of nationalist mobilization — women's invisible labor sustaining public movements — a core case study in Sociology's "Social Change and Social Problems" unit on gender and nationalism.
## PREREQ_CONCEPT
Semiotic mapping (signifier → signified) from Imagery/Metaphor node; ability to distinguish literal vs intended meaning.

## PREREQ_BEFORE
Student must be able to (a) pick out a metaphor in a poem and explain the comparison, (b) define irony in one sentence with a daily-life example.

## PREREQ_STUCK
If stuck on symbol-decoding, return to c12_hin_a_cbse_01_008 Worked Example 2 (metaphor mapping) and replicate the 4-step table for "नक़ली फूल." If stuck on irony-type, make a 3-column chart (Expectation | Reality | Type) for three real-life situations (e.g., fire station burns down = situational).

## WORKED_EXAMPLE_1
PROBLEM: Analyze how the symbol "सूखी डालियाँ" (dry branches) in "नसोलसुक का छंद" represents Nasolsuk's emotional and social condition. Use the Symbol Analysis Protocol.

STEPS:
- Step 1: Identify the vehicle — "सूखी डालियाँ" appears in the stanza describing Nasolsuk's inner state: "मेरी डालियाँ सूख गईं / जड़ें फिर भी गहरी हैं."
- Step 2: List physical properties of dry branches in the poem's context — brittle, leafless, no sap flow, vulnerable to wind, yet still attached to living roots.
- Step 3: Map each property to Nasolsuk's condition — brittle = emotional fragility from prolonged grief; leafless = loss of nurturing capacity (children gone, husband absent); no sap = depleted vitality; vulnerable = exposed to patriarchal violence; attached to roots = still connected to cultural memory and love.
- Step 4: State the symbolic equation — सूखी डालियाँ → Nasolsuk's wounded but resilient self via properties (brittle yet rooted). The twist: roots are "गहरी" — the symbol simultaneously encodes damage AND endurance.
- Step 5: Connect to theme — this dual coding (wounded + rooted) refuses victim-only narrative; it mirrors the poem's feminist nationalism: women bear the cost but hold the cultural continuity.

REASONING: The protocol forces movement from concrete image to abstract meaning through explicit property-mapping, preventing the "label-only" error. Step 5 ensures the symbol serves thematic argument, not decorative spotting.

ANSWER: "सूखी डालियाँ" symbolizes Nasolsuk's depleted yet unbroken existence. Physical traits — brittleness, leaflessness, saplessness, vulnerability, root-attachment — map respectively to emotional fragility, lost nurturing role, vitality drain, exposure to oppression, and cultural rootedness. The symbol's power lies in its dual valence: it conveys suffering without erasing agency, directly supporting the poem's critique of nationalist discourse that consumes women's labor.

## WORKED_EXAMPLE_2
PROBLEM: Identify and classify the irony in these lines from "डाकुसफ्याक का छंद": "वृक्ष की जड़ें गहरी हैं / शाखाएँ फैली हैं / पक्षी गाते हैं / फिर भी कोई कहता है — यह वृक्ष मर चुका है." Explain the knowledge gap and its thematic function.

STEPS:
- Step 1: State the literal description (reality) — the tree has deep roots, spreading branches, birds singing → all signs of vigorous life.
- Step 2: State the contradictory claim (expectation/verbal assertion) — "कोई कहता है — यह वृक्ष मर चुका है" — an external voice declares it dead.
- Step 3: Identify the knowledge gap — the reader sees living evidence; the speaker ("कोई") either ignores evidence or uses a death-criterion invisible to the reader (e.g., political death, spiritual death). This is DRAMATIC IRONY: reader knows more than the claimant.
- Step 4: Check for other irony layers — the claimant may be a colonial ruler or communal partisan for whom "India is dead" is ideological wishful thinking → VERBAL IRONY (words contradict observable reality).
- Step 5: Thematic function — the irony exposes how power defines "life" and "death" of nations to justify control. The living tree (composite culture) is declared dead to legitimize partition or authoritarian rule. The birds' song (people's voices) becomes the rebuttal.

REASONING: Multi-layer irony classification (dramatic + verbal) shows analytical depth. Step 5 links device to the poem's political argument — essential for board "explain with reference to context" answers.

ANSWER: The passage deploys dramatic irony (reader sees living tree; claimant declares it dead) layered with verbal irony (the statement "tree is dead" contradicts the sensory evidence the poem just presented). The knowledge gap: the claimant operates on an ideological definition of nationhood (monocultural, majoritarian) that renders the actually existing plural tree "dead." Thematically, this irony unmasks the political motive behind declaring a civilization moribund — it prepares the ground for its dismemberment. The birds' persistent song = the people's lived reality resisting the imposed narrative.

## WORKED_EXAMPLE_3
PROBLEM: Compare the use of irony in the closing stanzas of both poems. "नसोलसुक का छंद" ends with Nasolsuk asserting "दुनिया! तुम इसे न छीन पाओगी / इससे प्यार की गंध आती है" addressing her suffering. "डाकुसफ्याक का छंद" ends with "यही एकता हमारी शक्ति है / यही हमारी पहचान." How does each poem use irony to convert a structure of oppression into a site of resistance?

STEPS:
- Step 1: Analyze Nasolsuk's closing irony — she addresses "दुनिया" (world/society) that has stripped her of everything. Expectation: the destitute woman has no power. Reality: she claims an inalienable possession — "प्यार की गंध" (fragrance of love) from her suffering. Type: Situational irony (powerless → powerful) + Verbal irony (addressing the oppressor as "दुनिया" while reclaiming agency).
- Step 2: Analyze Dakusfyak's closing irony — the poem has catalogued diversity (birds, branches, roots) while acknowledging the "dead tree" claim. Expectation: diversity = fragmentation/weakness. Reality: "यही एकता हमारी शक्ति है" — diversity IS unity. Type: Situational irony (fragmentation → strength) + Dramatic irony (the "dead tree" claimants cannot see the living unity the poem performs).
- Step 3: Compare the conversion mechanism — both poems take the very condition imposed by oppression (Nasolsuk's suffering, the nation's diversity) and, through ironic reversal, revalue it as the source of resistance. Suffering → love's fragrance (non-appropriable). Diversity → unity (non-destroyable).
- Step 4: Identify the shared structural move — irony pivots from *external definition* (what the system says you are: victim, fragmented) to *self-definition* (what you know you are: bearer of love, embodiment of unity).
- Step 5: Thematic synthesis — this is the chapter's core argument: irony is not just critique; it is the rhetorical engine of subaltern self-fashioning. The marginalized (woman, minority) use the gap between imposed identity and lived reality to generate a counter-narrative.

REASONING: This worked example models the comparative, multi-step analysis required for 5-6 mark board questions and CUET/Humanities critical thinking tasks. It integrates device identification, classification, thematic linking, and cross-poem synthesis — the full analytical stack.

ANSWER: Both poems deploy situational irony to invert the oppressor's script. Nasolsuk transforms imposed destitution into an inalienable spiritual wealth ("प्यार की गंध") that the world cannot seize — the irony converts material powerlessness into moral sovereignty. Dakusfyak transforms the "fragmentation" imposed by colonial/communal discourse ("tree is dead") into the very definition of strength ("यही एकता हमारी शक्ति है") — the irony converts prescribed weakness into constitutive power. In both, the ironic gap (expectation vs reality) is the hinge where the subaltern speaks: "You name me X; I am Y, and Y is my freedom."

## COMPETENCY_QUESTION_1
QUESTION: A student writes in the board exam: "The poem uses irony because Nasolsuk's husband went for freedom but she got nothing." The examiner awards 1/3 marks. Using the Irony Analysis Protocol, diagnose the specific deficiencies in this answer and rewrite it to earn full marks.

COMPETENCY: Critical evaluation of peer response / Exam answer improvement

STEPS:
- Step 1: Identify what the student's answer captures — it notes an outcome-expectation gap (husband's goal vs wife's result) → correctly senses situational irony.
- Step 2: Identify what is missing — (a) no irony type named, (b) no textual evidence quoted, (c) no explanation of the knowledge gap (who expects what), (d) no thematic connection (what the irony *does* in the poem).
- Step 3: Apply the Protocol to the same moment — Expectation: husband's sacrifice brings family honor/relief. Reality: wife bears double burden (poverty + loneliness). Type: Situational irony. Thematic work: exposes gendered cost of nationalist mobilization.
- Step 4: Rewrite with PEEL structure — Point: The poem employs situational irony in Nasolsuk's plight. Evidence: "तुम्हारे लिए मैंने सब सहा / फिर भी भूखी सोती हूँ." Explanation: The gap between the husband's nationalist sacrifice and the wife's material deprivation reveals how the freedom struggle externalizes its cost onto women's bodies. Link: This irony anchors the poem's feminist critique of patriarchal nationalism.

ANSWER: Deficiencies: (1) Labels "irony" without type specification (situational/verbal/dramatic). (2) Zero textual citation — board marking scheme requires "reference to context." (3) No analysis of *how* the gap functions thematically. (4) "She got nothing" is a plot summary, not device analysis. Full-mark rewrite: "The poem deploys situational irony: Nasolsuk's husband joins the freedom struggle expecting to secure their future ('आज़ादी का सिपाही'), but his absence leaves her destitute ('भूखी सोती हूँ'). The outcome contradicts the intention. This irony exposes the gendered architecture of nationalist sacrifice — women's invisible labor subsidizes the public heroism. The line 'तुम्हारे लिए मैंने सब सहा' makes the structural exploitation visible."

DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: "Symbols in these poems are not decorative; they are arguments." Defend this statement by constructing a comparative analysis of ONE symbol from each poem, showing how each symbol's physical properties are recruited to make a specific ideological claim. Use the Symbol Analysis Protocol for both.

COMPETENCY: Comparative literary analysis with ideological reading

STEPS:
- Step 1: Select symbols — "नक़ली फूल" (Nasolsuk) and "वृक्ष/जड़ें" (Dakusfyak).
- Step 2: Apply Protocol to "नक़ली फूल" — Vehicle: mass-produced paper/cloth flowers. Properties: scentless, unwilting, identical, cheap, offered as honors. Mapping: scentless = hollow ritual; unwilting = frozen performance; identical = erasure of individual grief; cheap = state's low valuation of women's sacrifice. Ideological claim: The state commodifies women's suffering into empty symbols — the "नक़ली फूल" is the material form of patriarchal nationalism's bad faith.
- Step 3: Apply Protocol to "वृक्ष/जड़ें" — Vehicle: ancient banyan/peepal tree. Properties: deep roots (shared history), massive trunk (common framework), spreading branches (diverse communities), birds nesting (citizens finding shelter), shade (protection), oxygen (life-giving). Mapping: roots = civilizational continuity; trunk = constitutional/secular framework; branches = pluralism; birds = minorities/marginalized; shade/oxygen = democratic welfare. Ideological claim: The nation is an organic, interdependent ecosystem — not a mechanical contract. Diversity is structural, not additive. Unity emerges from shared roots, not uniformity.
- Step 4: Compare the two symbols' ideological work — "नक़ली फूल" *deconstructs* a false official symbol (state honors); "वृक्ष" *constructs* a true organic symbol (composite culture). Both are arguments: one negative (this is fake), one positive (this is real). Together they enact the chapter's dialectic: critique → reconstruction.
- Step 5: Conclude — symbols here are "arguments in image-form" because their property-to-meaning mappings are contested ideological terrain. The poet fights the battle of meaning *through* the symbols.

ANSWER: "नक़ली फूल" argues that state-conferred honors on women's sacrifice are materially and morally counterfeit — their physical properties (scentless, mass-produced, permanent) map precisely to the ideological properties of patriarchal nationalism (emotionally empty, individually erasing, historically falsifying). "वृक्ष/जड़ें" argues that Indian nationhood is an organic pluralism — its properties (deep roots, diverse branches, sheltering birds) map to the ideological claims of composite culture (shared history, constitutional unity, minority protection). The first symbol *negates* a dominant discourse; the second *posits* an alternative. Both recruit physical traits as evidence for ideological claims — they are not ornaments but visual syllogisms.

DIFFICULTY: hard