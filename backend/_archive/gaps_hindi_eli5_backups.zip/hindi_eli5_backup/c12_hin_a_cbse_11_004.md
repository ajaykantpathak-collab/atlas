## DEFINITION
Character analysis of the protagonist involves a systematic examination of the central character's personality traits, motivations, internal conflicts, development arc, and relationship to the story's themes through textual evidence — their actions, dialogues, thoughts, and how other characters respond to them — to construct an interpretive argument about their role in conveying the author's message.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student can write a structured 150-200 word character sketch of बड़े भाई साहब using the PEEL method (Point, Evidence, Explanation, Link) with at least three distinct textual references covering his contradictions (sermonizing vs. human weakness), his protective love, and his symbolic representation of colonial-era educational trauma, and explain how his character advances the story's critique of rote learning.

## SCOPE_BOUNDARY
This node covers ONLY the character analysis of बड़े भाई साहब (the elder brother) as the protagonist of "बड़े भाई साहब" — his physical description, behavioral contradictions, psychological depth, narrative function, and thematic significance. It does NOT cover the younger brother (narrator) as protagonist, nor the characters from "मुँह देखी बात" or "सपनों के दिन" — those are addressed in c12_hin_a_cbse_11_005.

## WALKTHROUGH
Imagine you're telling a friend about a strict older sibling who lectures you endlessly about studying hard, stays up all night memorizing textbooks, fails exams repeatedly, yet the moment you get good marks effortlessly, they drop their guard and celebrate with you — that's बड़े भाई साहब. Start by asking: "What makes this character feel real instead of just a 'strict brother' stereotype?" Look first for moments where his actions contradict his words (he preaches discipline but gets distracted by kite-flying; he sermonizes on hard work but his own method is rote memorization). Then trace his emotional arc: from authoritarian figure (scolding the narrator for playing) to vulnerable human (admitting fear of failure, crying when the narrator passes). Finally, connect each trait to Premchand's larger critique — the colonial education system that turned sensitive humans into mechanical rote-learners. The key insight: बड़े भाई साहब is not just a character; he's a living indictment of an education system that measures worth by exam marks.

## DIAGNOSTIC_QUESTION_1
Identify the protagonist of "बड़े भाई साहब" and state his primary role in the narrative structure.

## DIAGNOSTIC_ANSWER_1
The protagonist is बड़े भाई साहब (the elder brother). His primary role is to embody the tragic conflict between sincere effort and systemic failure in colonial education — he is the vehicle through which Premchand critiques rote learning. A wrong answer (e.g., naming the narrator as protagonist) reveals the student confuses "narrator" with "protagonist" and misses that the story's emotional and thematic weight centers on the elder brother's internal struggle, not the younger brother's observations.

## DIAGNOSTIC_QUESTION_2
Explain in your own words why बड़े भाई साहब's method of studying (रटंत विद्या) is portrayed as both his greatest effort and his fundamental failure.

## DIAGNOSTIC_ANSWER_2
His rote memorization reflects genuine dedication — he sacrifices sleep, play, and health — but it fails because the colonial examination system rewards mechanical reproduction over understanding. The tragedy: his effort is real, but the method is mismatched to actual learning. A wrong answer that says "he was lazy" or "he didn't study enough" reveals the student missed the textual evidence of his extreme labor (staying up all night, copying notes, memorizing history dates) and confuses outcome (failure) with input (effort), a classic board-exam trap.

## DIAGNOSTIC_QUESTION_3
Apply the PEEL method to analyze this textual moment: When the narrator passes his exam, बड़े भाई साहब says "यों" (just like that) and his eyes fill with tears. Write a 4-sentence PEEL paragraph.

## DIAGNOSTIC_ANSWER_3
**Point:** This moment reveals बड़े भाई साहब's suppressed vulnerability beneath his authoritarian mask. **Evidence:** After the narrator passes effortlessly, the elder brother's monosyllabic "यों" and tear-filled eyes contrast sharply with his earlier hour-long sermons on hard work. **Explanation:** The tears expose his deep fear of failure and the emotional toll of a system that equates worth with marks; his brief response shows he cannot sustain the performative strictness when confronted with his brother's success. **Link:** This humanizes him and reinforces Premchand's critique — the system breaks even the most devoted students. A wrong answer that only describes the plot ("he cried because his brother passed") without analyzing the *contrast* between his earlier sermons and this silence reveals inability to move from literal comprehension to character analysis.

## DIAGNOSTIC_QUESTION_4
Compare बड़े भाई साहब's attitude toward education in his first sermon (after narrator fails Class 9) versus his final admission ("मैं तो खुद ही फेल हूँ"). What does this shift reveal about his character arc?

## DIAGNOSTIC_ANSWER_4
Initially, he weaponizes education as moral authority — "परिश्रम से सब कुछ हो सकता है" — positioning himself as the knowledgeable guide. By the end, he admits his own failure, collapsing the hierarchy: he is not the master of the system but its victim. The shift reveals his character arc from **performative authority** (masking insecurity with rhetoric) to **authentic vulnerability** (acknowledging shared helplessness). A wrong answer that calls this "hypocrisy" misses that his sermons were never dishonest — he genuinely believed in hard work; the tragedy is that the system betrayed his belief. This confusion between *hypocrisy* (intentional deceit) and *tragic irony* (sincere belief thwarted by structure) is a frequent board-exam error.

## DIAGNOSTIC_QUESTION_5
Evaluate the critic's claim: "बड़े भाई साहब is a flat character — just a symbol of the failed student." Defend or refute using three textual evidences.

## DIAGNOSTIC_ANSWER_5
**Refute.** He is a round character with psychological depth. Evidence 1: His kite-flying distraction (पतंग उड़ाना) shows human weakness contradicting his disciplined persona. Evidence 2: His protective love — buying sweets for the narrator, worrying about his health — reveals emotional warmth beyond the "strict brother" role. Evidence 3: His final tears and admission of fear ("मुझे डर लगता है") expose interiority that a flat symbol cannot possess. A wrong answer that agrees with the critic reveals inability to distinguish *symbolic function* (he represents a social type) from *character flatness* (lack of individual complexity) — a nuance JEE/NEET comprehension passages often test.

## DIAGNOSTIC_QUESTION_6
Create a 50-word diary entry from बड़े भाई साहब's perspective on the night before his final exam, capturing his internal conflict between his public sermons and private fears.

## DIAGNOSTIC_ANSWER_6
A strong entry will show: (a) physical exhaustion from rote memorization, (b) fear of disappointing family/himself, (c) awareness that his method (रटना) doesn't guarantee success, (d) resolve to maintain the "elder brother" mask for the narrator's sake. Example: "सारी रात इतिहास की तारीखें रटते बीती। आँखें जल रही हैं, पर डर यह नहीं कि पास न हुआ तो? डर यह है कि छोटे को क्या मुँह दिखाऊँगा — वही छोटा जिसे रोज़ समझाता हूँ 'मेहनत से सब होता है'। अगर मैं ही हार गया तो मेरा उपदेश झूठा पड़ जाएगा।" A weak entry that only lists study topics without emotional conflict reveals the student cannot inhabit the character's psychology — a skill needed for creative writing tasks in board exams.

## COMMON_MISCONCEPTION
Students consistently confuse **बड़े भाई साहब's sermons** (उपदेश) with **hypocrisy** (कपट). They write: "He preaches hard work but flies kites himself, so he's a hypocrite." This is wrong because: (1) His sermons reflect his *genuine belief* — he *does* work hard (memorizes all night), (2) The kite-flying is a momentary human lapse, not a rejection of his values, (3) Premchand uses this contradiction to show how the *system* dehumanizes even sincere students, not to expose personal moral failure. The error stems from reading the character morally (good/bad) instead of structurally (victim of systemic irony). Board marking schemes penalize "hypocrisy" labels because they reduce a tragic figure to a moral caricature.

## ON_FAILURE
If a student writes "hypocrite" or "flat character": Step 1 — Have them re-read the kite-flying scene (पतंग उड़ाना) and the final confession ("मैं तो खुद ही फेल हूँ") side-by-side; ask: "Does he *choose* to fail? Does he *stop believing* in hard work?" Step 2 — Map a 2-column table: Column A = His Sermons (quotes), Column B = His Actions (textual evidence). Step 3 — Ask: "Where is the *gap* between A and B? Is it dishonesty or systemic betrayal?" Step 4 — Re-attempt Diagnostic Question 4. If they still call it hypocrisy, assign c11_hin_ar_cbse_11_004 (Class 11 Character Analysis) for review of round vs. flat character distinction.

## BUILDS_ON
c12_hin_a_cbse_11_002 (Plot and Narrative Structure) — the student must already know the story's sequence of events to locate character moments in the narrative arc.

## LEADS_TO
c12_hin_a_cbse_11_005 (Character Analysis: Supporting Characters) — understanding the protagonist's depth enables contrast with the narrator (younger brother) as foil and with the father as absent authority figure.

## PREREQUISITE_NODE_IDS
c12_hin_a_cbse_11_001, c12_hin_a_cbse_11_002, c12_hin_a_cbse_11_003, c11_hin_ar_cbse_11_004
## PREREQUISITE_REASONS
c12_hin_a_cbse_11_001: Provides historical context of colonial education system essential to interpret बड़े भाई साहब's struggle as systemic, not personal.
c12_hin_a_cbse_11_002: Establishes plot sequence so student can anchor character analysis in specific narrative moments (first sermon, kite-flying, final confession).
c12_hin_a_cbse_11_003: Setting (hostel, colonial school) shapes the protagonist's isolation and pressure — without this, his behavior seems merely personal.
c11_hin_ar_cbse_11_004: Class 11 foundation on character analysis methods (round/flat, direct/indirect characterization, PEEL structure) — this node deepens, not repeats, that skill.

## FORWARD_NODE_IDS
c12_hin_a_cbse_11_005, c12_hin_a_cbse_11_006, c12_hin_a_cbse_11_013, c12_hin_a_cbse_11_007, c12_hin_a_cbse_11_012, c12_hin_a_cbse_11_015

## FORWARD_REASONS
c12_hin_a_cbse_11_005: Protagonist analysis establishes the benchmark for analyzing supporting characters (narrator, father) as foils and thematic mirrors.
c12_hin_a_cbse_11_006: The protagonist's arc *is* the primary theme (critique of rote education) — theme node builds directly on this character's trajectory.
c12_hin_a_cbse_11_013: Critical thinking requires synthesizing character, theme, and device — protagonist analysis is the core evidence base.
c12_hin_a_cbse_11_007: Protagonist's actions/reactions (e.g., the boy's fear) are primary evidence for secondary themes.  
c12_hin_a_cbse_11_012: Protagonist analysis aids inferring motives.  
c12_hin_a_cbse_11_015: Protagonist analysis supplies character‑based arguments.  

## CROSS_SUBJECT_PREREQS
c11_hin_ar_cbse_11_004, c11_hin_ar_cbse_11_013
## CROSS_SUBJECT_REASONS
c11_hin_ar_cbse_11_004: Class 11 Antra Chapter 11 (same story "बड़े भाई साहब") introduced basic character sketch — this node advances to board/competitive depth with PEEL, textual evidence hierarchy, and thematic linkage.
c11_hin_ar_cbse_11_013: Class 11 Critical Thinking node trained interpretation skills — this node applies them to a specific character with exam-level rigor.

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_11_004 -> c12_hin_a_cbse_11_004 -> c12_hin_a_cbse_11_005

## THIS_FORMULA
PEEL Character Analysis Formula: **P**oint (trait/claim) → **E**vidence (specific textual reference: action/dialogue/thought/other's reaction) → **E**xplanation (how evidence proves point, analyzing language/contradiction/subtext) → **L**ink (connect to theme/author's purpose/narrative function). Repeat for 3-4 distinct traits.

## FORMULA_VARIABLES
P = Character trait claim (e.g., "authoritarian yet vulnerable")  
E = Textual proof (e.g., "hour-long sermon after Class 9 failure" + "tears at narrator's success")  
E = Analytical reasoning (e.g., "contrast between performed authority and authentic fear")  
L = Thematic connection (e.g., "embodies colonial education's dehumanization of sincere students")

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
analytical

## CROSS_SUBJECT
N/A | The colonial Macaulay education system (History Ch. "Colonialism and the City") created the examination-centric rote-learning structure that crushes बड़े भाई साहब — his character is a literary case study of that historical policy's human cost.
 N/A | Erikson's "industry vs. inferiority" stage (Psychology Ch. "Human Development") maps onto the brothers: elder brother's worth tied to exam performance (industry), failure triggers inferiority; narrator's effortless success creates guilt — literary characterization mirrors developmental psychology.
## PREREQ_CONCEPT
Understanding the distinction between **direct characterization** (author tells: "वह बड़ा गंभीर था") and **indirect characterization** (author shows: actions, speech, thoughts, others' reactions) — Premchand uses almost exclusively indirect characterization for बड़े भाई साहब.

## PREREQ_BEFORE
Student must be able to locate at least 5 specific textual moments (with chapter/page reference) where बड़े भाई साहब's character is revealed indirectly — e.g., his sermon after Class 9 failure, his kite-flying, his copying notes all night, his "यों" at narrator's success, his final confession.

## PREREQ_STUCK
If unable to list 5 indirect characterization moments, revisit c12_hin_a_cbse_11_002 (Plot) and annotate the text marking every scene where बड़े भाई साहब speaks, acts, or is reacted to — then classify each as revealing which trait.

## WORKED_EXAMPLE_1
PROBLEM: Write a 120-word character sketch of बड़े भाई साहब for a 5-mark CBSE board question, using the PEEL method with three distinct traits.

STEPS:
- Step 1: Identify three core traits from the text that are thematically significant: (1) Performative authority masking insecurity, (2) Genuine protective love beneath sternness, (3) Tragic victimhood of colonial education system.
- Step 2: For each trait, select the strongest textual evidence: Trait 1 → First sermon ("परिश्रम से सब कुछ हो सकता है") contrasted with final admission ("मैं तो खुद ही फेल हूँ"); Trait 2 → Buying sweets (मिठाई लाना), worrying about narrator's health ("तू बीमार न पड़ जाए"); Trait 3 → Rote memorization all night (रटंत विद्या) ending in failure, kite-flying as human lapse.
- Step 3: Draft PEEL paragraph for Trait 1: Point = He performs authority to mask fear. Evidence = 2-hour sermon vs. final "मैं फेल हूँ". Explanation = Sermons are defense mechanism; admission collapses hierarchy. Link = Shows system breaks even its most devoted followers.
- Step 4: Draft PEEL paragraph for Trait 2: Point = Sternness covers deep affection. Evidence = Mिठाई, health warning. Explanation = Actions contradict words; love is shown through care, not praise. Link = Humanizes him beyond "strict brother" trope.
- Step 5: Draft PEEL paragraph for Trait 3: Point = He is system's victim, not its master. Evidence = All-night rote memorization (नक़ल करना, तारीखें रटना) + failure. Explanation = Effort is real, method is systemic. Link = Premchand's critique: education measures memory, not mind.
- Step 6: Write opening sentence (thesis) and closing sentence (thematic synthesis), ensure 120-word limit.

REASONING: Board examiners reward structured answers that move from evidence to interpretation to thematic link. Three traits × PEEL = 12 sentences ≈ 120 words. Each trait must be distinct (not repetitive) and each evidence must be specific (not vague "he studies hard").

ANSWER: **बड़े भाई साहब प्रेमचंद की व्यवस्था-व्यंग्य के जीवंत प्रतीक हैं।** **पहला,** वे अधिकारपूर्ण उपदेशों द्वारा अपनी असुरक्षा छिपाते हैं — नौवीं फेल होने पर छोटे भाई को दो घंटे "परिश्रम से सब होता है" समझाते हैं, पर अंत में स्वीकारते हैं "मैं तो खुद ही फेल हूँ"। यह विरोधाभास कपट नहीं, व्यवस्था की विडंबना है। **दूसरा,** कठोरता के नीचे गहरा स्नेह है — मिठाई लाना, स्वास्थ्य की चिंता ("तू बीमार न पड़ जाए") शब्दों से अधिक मुखर हैं। **तीसरा,** वे रटंत-शिक्षा के शिकार हैं — सारी रात नक़ल करना, तारीखें रटना, फिर भी फेल; पतंग उड़ाना मानवीय कमज़ोरी है, नैतिक पतन नहीं। प्रेमचंद उन्हें खलनायक नहीं, पीड़ित बनाते हैं: एक ऐसी शिक्षा-पद्धति का जो मेहनती इंसान को मशीन बना देती है। (118 शब्द)

## WORKED_EXAMPLE_2
PROBLEM: A student writes: "बड़े भाई साहब पाखंडी हैं क्योंकि वे खुद पतंग उड़ाते हैं और छोटे को पढ़ाई के लिए डाँटते हैं।" Identify the analytical error and rewrite the interpretation correctly using textual evidence.

STEPS:
- Step 1: Identify the error — the student equates *momentary human weakness* (kite-flying) with *moral hypocrisy* (preaching values one doesn't believe). This confuses character flaw with systemic tragedy.
- Step 2: Locate the kite-flying scene in context: It occurs *after* hours of rote memorization, as a brief mental break — not a rejection of his own advice.
- Step 3: Locate the sermons in context: They occur *after* narrator's failure, driven by genuine anxiety for brother's future, not desire to dominate.
- Step 4: Find the counter-evidence: The final confession ("मुझे डर लगता है") proves he *believes* in hard work but fears it's insufficient in this system.
- Step 5: Rewrite using "tragic irony" framework: His actions contradict his words not because he's dishonest, but because the system makes his method (rote) ineffective despite his sincerity.
- Step 6: Formulate corrected interpretation with PEEL structure.

REASONING: Competitive exams (CUET, JEE comprehension) test ability to distinguish *author's judgment* from *character's limitation*. Premchand never condemns बड़े भाई साहब; the narrative invites empathy. The student's error is a moralistic reading that ignores authorial stance.

ANSWER: **Error:** Labeling "पाखंड" (hypocrisy) imposes moral judgment where the text offers tragic irony. **Correction:** बड़े भाई साहब की कठोरता और पतंगबाज़ी का सहअस्तित्व उनके चरित्र की जटिलता है, न कि पाखंड। वे सचमुच मानते हैं "परिश्रम से सब होता है" — तभी सारी रात रटते हैं। पतंग उड़ाना थके हुए मन की क्षणिक मुक्ति है, मूल्यों का त्याग नहीं। अंतिम स्वीकारोक्ति ("मैं तो खुद ही फेल हूँ") प्रमाणित करती है कि उनकी असफलता प्रयास की कमी से नहीं, पद्धति की सीमा से है। प्रेमचंद उन्हें दोषी नहीं, पीड़ित दिखाते हैं: औपनिवेशिक परीक्षा-तंत्र ने एक संवेदनशील, मेहनती, स्नेही बड़े भाई को 'फेलियर' बना दिया। यही कथा का केंद्रीय व्यंग्य है।

## WORKED_EXAMPLE_3
PROBLEM: Compare बड़े भाई साहब's characterization with the narrator (younger brother) as a foil. Write a 150-word analytical paragraph showing how their contrast structures the story's critique of education.

STEPS:
- Step 1: Define "foil" — a character whose traits highlight the protagonist's traits by contrast.
- Step 2: Map 4-point contrast table: (a) Study method: rote (elder) vs. intuitive/playful (younger); (b) Exam outcome: failure despite effort (elder) vs. success despite play (younger); (c) Attitude to authority: internalizes colonial pedagogy (elder) vs. resists/subverts unconsciously (younger); (d) Emotional expression: repressed/sermonizing (elder) vs. spontaneous/guileless (younger).
- Step 3: Select strongest paired evidence: Elder's "सारी रात नक़ल करता रहा" vs. Younger's "खेल-कूद में दिन बीत जाता"; Elder's 2-hour sermon vs. Younger's silent listening; Elder's tears at Younger's success vs. Younger's guilt ("मेरा जी चाहता था कि मैं भी फेल हो जाऊँ").
- Step 4: Analyze structural function: The foil structure makes the critique *systemic* not *individual* — if only elder failed, it's personal; if younger succeeds *without* the prescribed method, the method itself is exposed as arbitrary.
- Step 5: Draft paragraph with thesis → paired evidence → analysis → thematic link.
- Step 6: Verify each claim has textual anchor; check word count.

REASONING: Board 6-mark questions often ask "how does the author use contrast..." — this requires moving beyond character sketches to *structural analysis*. The foil relationship is the engine of the story's argument.

ANSWER: **छोटा भाई (कथावाचक) बड़े भाई साहब का संरचनात्मक फ़ॉइल (foil) है — उनकी विडंबना को उजागर करने वाला दर्पण।** जहां बड़ा भाई "रटंत विद्या" का शहीद है (सारी रात नक़ल, तारीखें रटना, फिर भी फेल), वहीं छोटा भाई सहज बोध से पास होता है ("खेल-कूद में दिन बीत जाता")। यह विपरीत परिणाम **व्यक्तिगत योग्यता** नहीं, **पद्धति की निरर्थकता** सिद्ध करता है: परिश्रम करने वाला फेल, खेलने वाला पास। बड़ा भाई उपनिवेशवादी शिक्षाशास्त्र को अंतर्निहित करता है — "परिश्रम ही सफलता" का उपदेश देता है; छोटा भाई अनजाने उसका प्रतिरोध करता है — बिना रटे, बिना डरे, सहज जीता है। भावनात्मक तल पर भी विपरीतता: बड़ा भाई अधिकार जमाता है, आँसू छिपाता है; छोटा भाई अपराधबोध महसूस करता है ("मैं भी फेल हो जाऊँ")। प्रेमचंद इस द्वैत से व्यंग्य गढ़ते हैं: शिक्षा-तंत्र वह नहीं जो बड़े भाई सिखाते हैं, बल्कि वह जो छोटा भाई *अनजाने* जीता है — स्वाभाविक, आनंदमय, भयमुक्त। (152 शब्द)

## COMPETENCY_QUESTION_1
QUESTION: In the final scene, बड़े भाई साहब says "यों" (just like that) when the narrator passes, and his eyes fill with tears. A student argues: "This proves he always knew rote learning was useless — he was just pretending to believe in it to control his brother." Evaluate this interpretation. Is it supported by the text? What does the text actually suggest about his self-awareness?

COMPETENCY: Critical evaluation of character interpretation using textual evidence (CBSE Competency: "Analyze and evaluate interpretations")

STEPS:
- Step 1: Identify the claim — "he always knew rote learning was useless" (conscious deception).
- Step 2: Search text for evidence of *prior* self-awareness: Does he ever say "this method won't work"? No — he says "परिश्रम से सब होता है" sincerely.
- Step 3: Analyze the "यों" moment: It's a *reaction* to narrator's success, not a *revelation* of prior knowledge. The tears indicate *surprise* and *relief*, not "I told you so."
- Step 4: Contrast with his final confession: "मुझे डर लगता है" — fear implies uncertainty, not secret knowledge.
- Step 5: Conclude: The interpretation projects modern hindsight onto a character trapped in his historical moment. The text supports *tragic sincerity*, not *calculated deception*.

ANSWER: The interpretation is **not supported**. The text consistently portrays बड़े भाई साहब as *sincerely believing* in hard work — his all-night rote memorization is proof of belief, not pretense. The "यों" and tears are a *breakdown of his performed authority* when confronted with evidence that the system rewards something other than effort (the narrator's effortless success). His final words "मुझे डर लगता है" confirm he *feared* failure, not that he *knew* his method was futile. The student's reading commits the "intentional fallacy" — assuming a character's actions reveal conscious strategy rather than human limitation. Premchand's irony is structural: the system betrays the sincere. The brother is not a manipulator; he is a victim who momentarily sees the system's absurdity reflected in his brother's success.

DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: A CUET-style assertion-reason question:  
**Assertion (A):** बड़े भाई साहब's character arc moves from authoritarian certainty to vulnerable uncertainty.  
**Reason (R):** The colonial education system's examination structure rewards rote memorization over genuine understanding, making sincere effort unreliable.  

Choose the correct option:  
(a) Both A and R are true and R correctly explains A.  
(b) Both A and R are true but R does not explain A.  
(c) A is true but R is false.  
(d) A is false but R is true.  
Justify your choice with two specific textual references.

COMPETENCY: Assertion-Reason reasoning with textual grounding (CUET/Board competency: "Logical reasoning with evidence")

STEPS:
- Step 1: Verify Assertion (A) — Trace arc: Scene 1 (after Class 9 failure) = authoritarian certainty ("परिश्रम से सब होता है", 2-hour sermon); Scene 2 (kite-flying) = momentary lapse but still preaching; Scene 3 (narrator's success) = "यों" + tears = uncertainty; Scene 4 (final confession) = "मैं तो खुद ही फेल हूँ", "मुझे डर लगता है" = vulnerable uncertainty. A is TRUE.
- Step 2: Verify Reason (R) — Historical fact: Colonial exams (Matriculation, etc.) tested memorized reproduction. Textual support: Elder brother's method = "नक़ल करना", "तारीखें रटना", "इतिहास भूगोल रटना" — all rote. His failure despite extreme effort proves system rewards something else (or is arbitrary). R is TRUE.
- Step 3: Test causal link — Does R *explain* A? Yes: His authoritarian certainty *derives from* internalizing the system's promise ("hard work = success"). When the system betrays that promise (he fails, narrator passes without the prescribed method), his certainty collapses into uncertainty. The arc is the *psychological registration* of the systemic contradiction.
- Step 4: Select textual anchors: (1) First sermon ("परिश्रम से सब कुछ हो सकता है") = internalized systemic promise; (2) Final confession ("मैं तो खुद ही फेल हूँ") = systemic betrayal registered personally.
- Step 5: Choose (a) and write justification.

ANSWER: **Correct option: (a) Both A and R are true and R correctly explains A.**  
**Justification:**  
1. **Textual anchor for A:** The arc is documented in two poles — the first sermon ("परिश्रम से सब कुछ हो सकता है, यह संसार परिश्रम से चलता है") performs authoritarian certainty; the final confession ("मैं तो खुद ही फेल हूँ... मुझे डर लगता है") exposes vulnerable uncertainty.  
2. **Textual anchor for R→A:** The elder brother's method *is* the colonial prescription — "सारी रात नक़ल करता रहा", "इतिहास-भूगोल की तारीखें रटता रहा" — yet he fails. The narrator passes *without* this method ("खेल-कूद में दिन बीत जाता"). This structural irony (system rewards non-conformity) is what shatters the brother's certainty. His arc *is* the human record of the system's false promise. R doesn't just accompany A; it *generates* A.

DIFFICULTY: hard