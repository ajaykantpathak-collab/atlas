## DEFINITION
Character analysis of the protagonist involves a systematic examination of the central character's traits, motivations, conflicts, and development throughout the narrative, using textual evidence (actions, dialogue, internal monologue, and authorial description) to construct a nuanced interpretation of their role in advancing the theme. At the senior secondary level, this requires moving beyond listing traits to analyzing how the protagonist's choices reveal the author's critique of socio-political structures.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student can independently write a structured analytical paragraph (PEEL format) that identifies a specific character trait of the narrator in 'f'k{kk', provides two distinct pieces of textual evidence (paraphrased or brief quotes), explains how each evidence reveals the trait, and links the trait to the chapter's anti-colonial theme.

## SCOPE_BOUNDARY
This node covers analysis of the narrator-protagonist (the Indian interlocutor) in 'f'k{kk' only: his voice, ideological stance, rhetorical strategies, and symbolic function. It does NOT cover the antagonist (Ekb Yamraj), supporting characters, or thematic analysis of other chapters.

## WALKTHROUGH
Imagine you are a lawyer cross-examining a witness: you don't just ask 'Who are you?' but 'What did you do when X happened? What did you say? What does that choice reveal about your beliefs?' Similarly, to analyze the protagonist in 'f'k{kk', start by isolating every moment the narrator speaks or acts in the dialogue with Ekb Yamraj. Notice his tone shifts — from sarcastic reverence ('ekb ykWMZ!') to searing indictment ('vki fdrus m¡Qps gksdj vki fdrus uhps fxjs!'). Ask: What specific historical grievances does he voice? How does his language (Sanskritized Hindi vs. Persianized register) perform resistance? The key insight: the protagonist is not merely a complainant; he embodies the awakened Indian conscience that turns colonial 'education' into a weapon of moral reversal.

## DIAGNOSTIC_QUESTION_1
Identify the protagonist in 'f'k{kk' and state his primary role in the narrative structure.

## DIAGNOSTIC_ANSWER_1
The protagonist is the unnamed Indian narrator who engages Ekb Yamraj in a dramatic monologue-dialogue. His primary role is to serve as the voice of colonized India, systematically dismantling the British official's justifications for rule. A wrong answer (e.g., identifying Ekb Yamraj as protagonist) reveals confusion between the antagonist/foil and the central consciousness through which the critique is focalized.

## DIAGNOSTIC_QUESTION_2
Explain in your own words how the narrator's use of the address 'ekb ykWMZ!' (repeated throughout) functions as a rhetorical strategy rather than mere politeness.

## DIAGNOSTIC_ANSWER_2
The repeated honorific 'ekb ykWMZ!' operates as bitter irony: it mimics the deferential language Indians were forced to use for British officials while simultaneously framing the official as Yama (God of Death), thereby exposing the lethal reality behind bureaucratic civility. A wrong answer treating it as genuine respect misses the satirical mode central to the protagonist's character.

## DIAGNOSTIC_QUESTION_3
Apply the 'Action-Revelation' method: Select ONE specific action the narrator describes having taken in the past (e.g., building roads, railways, education system) and explain what this action reveals about his character and his relationship to colonial modernity.

## DIAGNOSTIC_ANSWER_3
The narrator lists having built 'lalkjh fujaoqQ'krk' (government railways), 'vaxzs"kkvksa dk opZLo LFkkfir djuk' (establishing industries), and 'lkfgR; dks LFkkfir djuk' (consolidating literature). This reveals him as a co-architect of colonial modernity who now recognizes his labor was exploited — a tragic complicity that deepens his moral authority to indict. A wrong answer merely listing achievements without the 'revelation' step fails the analytical requirement.

## DIAGNOSTIC_QUESTION_4
Analyze the protagonist's shift in register from the opening (formal, Sanskritized: 'fonkbZ&laHkk"k.k mudh lokZfèkd p£pr O;aX; Ñfr') to the climactic confrontation (colloquial, accusatory: 'vki nkfgus Fks, og ck,¡...'). What does this linguistic code-switching reveal about his evolving strategy?

## DIAGNOSTIC_ANSWER_4
The shift from high literary Hindi (establishing intellectual parity with the colonizer's discourse) to raw, direct address (stripping away colonial politeness protocols) mirrors the protagonist's journey from petitioner to prosecutor. It reveals his realization that the colonizer's 'language of law' cannot deliver justice — only the language of the oppressed can. A wrong answer focusing only on vocabulary difficulty misses the strategic performativity.

## DIAGNOSTIC_QUESTION_5
Evaluate the critic's claim: 'The protagonist in f'k{kk is merely a mouthpiece for the author's nationalist ideology, lacking psychological depth.' Defend or refute using textual evidence.

## DIAGNOSTIC_ANSWER_5
Refute. The protagonist exhibits psychological complexity: guilt ('vkidks fcNM+rs ns[kdj vkt ân; esa cM+k nq[k gSA'), wounded pride ('vki Lo;a bl ckj cspSuh mBkuh iM+h gS'), and existential fatigue ('bl ns'k osQ gkfde vkidh rky ij ukprs Fks'). These are not slogans but lived affect. A wrong answer accepting the claim overlooks the text's deliberate portrayal of an individual consciousness bearing historical trauma.

## DIAGNOSTIC_QUESTION_6
Create a 4-line interior monologue for the protagonist immediately after Ekb Yamraj departs, capturing his unresolved tension between historical exhaustion and moral vigilance.

## DIAGNOSTIC_ANSWER_6
Sample criteria: Must reference at least two specific grievances from the text (e.g., famine, cultural erasure), use first-person voice, and end on an ambiguous note (neither victory nor defeat). Example: 'The railways I laid still carry their coal / My Sanskrit they twisted into clerkly rule / I spoke the truth — did the walls hear? / Tomorrow I sharpen the same pen.' A poor answer writes generic patriotism without textual anchoring.

## COMMON_MISCONCEPTION
Students often conflate the protagonist's *satirical persona* with his *authentic self*, treating every hyperbolic accusation (e.g., 'vkius bl b'kkjs esa bl ns'k dh f'k{kk ik;eky gks xbZ') as literal factual claim rather than rhetorical exaggeration to expose systemic logic. They miss that the protagonist *knows* he is performing a role ('vki fopkfj, rks ,d vkneh dks vkiosQ dgus ij in u nsus ls...') — this meta-awareness is his defining modern subjectivity. The error stems from reading satire as realism.

## ON_FAILURE
1. Re-read the opening descriptive passage (page 44-45) to distinguish authorial voice from character voice. 2. Mark every instance of 'ekb ykWMZ' and the narrator's self-references ('vkxs', 'esjs', 'vkiosQ') in two colors. 3. For each colored pair, ask: 'Is the narrator stating a fact or performing an accusation?' 4. Write one sentence explaining the difference for three pairs. This trains the eye to see performance vs. reportage.

## BUILDS_ON
c11_hin_ar_cbse_04_002 (Plot and Narrative Structure) — understanding the dialogue form and dramatic irony is essential before analyzing character voice.

## LEADS_TO
c11_hin_ar_cbse_04_005 (Character Analysis: Supporting Characters) — the protagonist's traits are defined relationally against Ekb Yamraj; analyzing the foil next deepens the protagonist's portrait.

## PREREQUISITE_NODE_IDS
c11_hin_ar_cbse_04_001, c11_hin_ar_cbse_04_002, c11_hin_ar_cbse_04_003
## PREREQUISITE_REASONS
c11_hin_ar_cbse_04_001: Provides historical context (1899-1905 Curzon era) necessary to decode the protagonist's specific grievances.
c11_hin_ar_cbse_04_002: Establishes the dramatic monologue structure — the protagonist's character *is* the structure.
c11_hin_ar_cbse_04_003: The oppressive atmosphere (famine, surveillance) shapes the protagonist's urgency and rhetoric.

## FORWARD_NODE_IDS
c11_hin_ar_cbse_04_005, c11_hin_ar_cbse_04_006, c11_hin_ar_cbse_04_013, c11_hin_ar_cbse_04_007, c11_hin_ar_cbse_04_012, c11_hin_ar_cbse_04_014, c12_hin_ar_cbse_04_005, c12_hin_ar_cbse_06_004, c12_hin_ar_cbse_10_004

## FORWARD_REASONS
c11_hin_ar_cbse_04_005: The antagonist Ekb Yamraj's character is the mirror; analyzing him next completes the dialectic.
c11_hin_ar_cbse_04_006: The protagonist's traits (moral courage, historical consciousness) directly embody the primary theme (colonial education as double-edged sword).
c11_hin_ar_cbse_04_013: Critical thinking questions require a fully formed character analysis as foundation for interpretation.
c11_hin_ar_cbse_04_007: Protagonist analysis shows how the narrator's character embodies thematic resistance.  
c11_hin_ar_cbse_04_012: Protagonist analysis (narrator's voice, stance) provides the lens for inferring intent.  
c11_hin_ar_cbse_04_014: चरित्र विश्लेषण (मिस्टर यॉर्क, भारतीय राजा) चरित्र-चित्रण लेखन का कच्चा माल देता है।  
c12_hin_ar_cbse_04_005: Class 11 protagonist analysis establishes baseline character-study vocabulary.  
c12_hin_ar_cbse_06_004: अगला तार्किक चरण: Character analysis of the protagonist in poetry involves identifying the central personified figure,... इस नोड की अवधारणाओं को सीधे उपयोग/विस्तारित करता है।  
c12_hin_ar_cbse_10_004: Practices tracking character across time in "Gunge" — directly applicable to HkfDru's three-phase arc.  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
none

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_04_002 -> c11_hin_ar_cbse_04_004 -> c11_hin_ar_cbse_04_005

## THIS_FORMULA
Protagonist Analysis = (Trait Identification × Textual Evidence) + (Contextual Motivation × Thematic Function) → Structured Argument

## FORMULA_VARIABLES
Trait Identification: Specific, arguable character quality (e.g., 'ironic self-awareness', not 'brave'). Textual Evidence: Paraphrased action/dialogue with page/line reference. Contextual Motivation: Historical/psychological cause for the trait (e.g., famine witness → moral urgency). Thematic Function: How the trait serves the chapter's central idea (anti-colonial critique). Structured Argument: PEEL paragraph (Point, Evidence, Explanation, Link).

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
analytical

## CROSS_SUBJECT
c11_history_colonialism | The protagonist's grievances (railways, famine, education policy) are concrete historical events from Curzon's viceroyalty; analyzing his voice requires knowing which policies he references.
c11_civics_nationalism | The protagonist performs early nationalist discourse: claiming moral sovereignty ('bl ns'k dh iztk og iztk gS') while using the colonizer's language — a core tension in Indian nationalist thought.

## PREREQ_CONCEPT
Dramatic monologue structure: a single speaker addressing a silent listener, revealing character through what is said and how it is said.

## PREREQ_BEFORE
Student must be able to distinguish the narrator's voice from the author's voice and identify the silent listener (Ekb Yamraj) in the text.

## PREREQ_STUCK
Review c11_hin_ar_cbse_04_002 (Plot and Narrative Structure) focusing on 'dramatic monologue' and 'silent listener' — then return here.

## WORKED_EXAMPLE_1
PROBLEM: Analyze how the protagonist's reference to 'ukfnj'kkg' (Warren Hastings) and 'dRysvke' (impeachment) in the climax functions as character revelation.
STEPS:
- Step 1: Locate the passage (page 50) where the narrator invokes Hastings' impeachment by Burke as precedent for holding Ekb Yamraj accountable.
- Step 2: Identify the trait revealed: the protagonist possesses deep historical-legal consciousness; he doesn't just rage — he cites precedent.
- Step 3: Extract evidence: 'ukfnj'kkg us tc fnYyh esa dRysvke fd;k rks mlus mlh ne jksd fn;k' and 'vkB djksM+ iztk osQ fxM+fxM+kdj foPNsn u djus dh izkFkZuk ij vkius ”kjk Hkh è;ku ugha fn;k'.
- Step 4: Explain: By invoking Burke (British parliamentarian) prosecuting Hastings (British Governor-General), the protagonist weaponizes British constitutionalism against British imperialism — showing he masters the colonizer's moral vocabulary better than the colonizer.
- Step 5: Link to theme: This trait (intellectual appropriation) embodies the chapter's argument that colonial 'education' produces its own gravediggers.
REASONING: The steps move from textual location to trait naming to evidence selection to interpretive explanation to thematic synthesis — the full analytical arc required for board answers.
ANSWER: The protagonist reveals himself as a strategic thinker who uses the colonizer's own history of accountability (Hastings' impeachment) to trap the colonizer in a moral contradiction. His reference is not ornamental; it demonstrates that Indian nationalism was forged within, not outside, Enlightenment legal discourse.

## WORKED_EXAMPLE_2
PROBLEM: The protagonist claims 'vki cgqr èkhj&xaHkhj izfl¼ Fks' (you were very cunning and cruel). Using the 'Show, Don't Tell' principle, find three distinct textual moments where he *shows* this cruelty through specific policy descriptions rather than adjectives.
STEPS:
- Step 1: Scan the text for concrete policy descriptions attributed to the British (pages 47-49).
- Step 2: Select three: (a) 'fdrus gh jktksa dks e^h osQ f[kykSus dh Hkk¡fr vkius rksM+&iQksM+ Mkyk' (forcing princes to sign away rights), (b) 'fdrus gh e^h&dkB osQ f[kykSus vkidh Ñik osQ tknw ls cMs+&cMs+ inkfèkdkjh cu x,ka' (creating landlord monopolies), (c) 'bl ns'k osQ flj ij vkjg j[kk x;k' (starving the peasantry).
- Step 3: For each, explain how the *description itself* (without the adjective 'xaHkhj') conveys cruelty: (a) verbs 'rksM+&iQksM+ Mkyk' imply coercion, (b) 'inkfèkdkjh' reveals structural exploitation, (c) 'vkjg j[kk' evokes visceral suffering.
- Step 4: Synthesize: The protagonist's character as a witness-archivist emerges — he doesn't name cruelty; he catalogues its mechanics.
- Step 5: Connect to reliability: This evidentiary mode makes him a credible prosecutor, not just an accuser.
REASONING: This example trains students to distinguish characterization-through-adjectives (weak) from characterization-through-evidence-selection (strong), a key board-exam skill.
ANSWER: The protagonist establishes British cruelty through three documented mechanisms: forced abdication of princes, creation of exploitative zamindari systems, and engineered famines. His character is defined by forensic precision — he lets the policies speak the cruelty, positioning himself as historian-prosecutor.

## WORKED_EXAMPLE_3
PROBLEM: Compare the protagonist's self-portrayal in the opening ('fonkbZ&laHkk"k.k mudh lokZfèkd p£pr O;aX; Ñfr') with his self-portrayal in the climax ('vki Lo;a Hkh [kq'k u gks losQ vkSj ;gk¡ dh iztk dks lq[kh u gksus fn;k'). What character arc does this contrast trace?
STEPS:
- Step 1: Analyze opening self-portrayal: 'lokZfèkd p£pr O;aX; Ñfr' (representative of people's primitive nature) — he claims collective voice, humility, organic connection to soil.
- Step 2: Analyze climax self-portrayal: 'vki Lo;a Hkh [kq'k u gks' (you are not even ashamed) + 'iztk dks lq[kh u gksus fn;k' (prevented justice) — he shifts to individual moral witness, accusing the listener of ethical bankruptcy.
- Step 3: Identify the pivot: The transition occurs when he recounts personal suffering ('vkidks fcNM+rs ns[kdj vkt ân; esa cM+k nq[k gSA') — the collective representative becomes a wounded individual.
- Step 4: Trace the arc: From *spokesperson* (we, the people) to *survivor* (I, who endured) to *judge* (I, who condemn). Each stage adds authority: representativeness → experiential truth → moral standing.
- Step 5: Evaluate narrative function: This arc mirrors the nationalist movement's evolution from petitioning (1885) to non-cooperation (1920) — the protagonist *is* the movement in microcosm.
- Step 6: Formulate thesis: The protagonist's character development structures the chapter's argument: colonialism transforms loyal subjects into revolutionary judges.
REASONING: This multi-step comparison demonstrates how character analysis at Class 11 must integrate textual close reading with historical allegory — the hallmark of high-scoring answers.
ANSWER: The protagonist evolves from a collective emblem ('voice of the people's primitive nature') to an individual moral authority ('you are not even ashamed') through the crucible of witnessed suffering. This arc mirrors the historical trajectory from loyalist petition to nationalist indictment, making his character the chapter's structural spine.

## COMPETENCY_QUESTION_1
QUESTION: The protagonist in 'f'k{kk' says: 'vki fdl dke dks vk, Fks vkSj D;k dj pys' (You know what work you came for and what you did). Design a 3-question cross-examination that the protagonist would ask Ekb Yamraj to expose the gap between British *stated mission* (civilizing mission) and *actual practice* (exploitation). Each question must use a specific textual reference.
COMPETENCY: Textual Evidence Selection & Argumentative Design
STEPS:
- Step 1: Identify the stated mission from the text (e.g., 'vaxzs"kkvksa dk opZLo LFkkfir djuk', 'f'k{kk ik;eky gks xbZ').
- Step 2: Identify the actual practice contradicting it (e.g., 'bl ns'k osQ flj ij vkjg j[kk x;k', 'Lokèkhurk mM+ xbZ').
- Step 3: Frame each question as a direct confrontation using the protagonist's voice: 'You claimed X, but the record shows Y — how do you answer?'
- Step 4: Ensure each question targets a different domain (economic, cultural, political).
ANSWER: Sample questions: (1) 'ekb ykWMZ! vkius dgk Fkk vaxzs"kkvksa dk opZLo LFkkfir djsaxs, ij fcNM+u&le; cM+k d#.kksRiknd gksrk gS — og vaxzs"kka'k vkSj og Lokèkhurk dk var D;k gS?' (2) 'vkius f'k{kk dks ik;eky cuk;k, ij vkidh f'k{kk us f'ko'kaHkq osQ fp_s dks d#.kk cuk;k — ;g 'ik;eky' D;k gS?' (3) 'vkius jktksa dks e^h osQ f[kykSus dh Hkk¡fr rksM+ dh, ij bl ns'k dh i'kq&if{k;ksa dks fcNM+us osQ le; mnkl ns[kk — vkiosQ 'opZLo' dk vFkZ D;k gS?'
DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: A board exam question asks: 'The protagonist in f'k{kk is not a victim but a prosecutor.' Write a 150-word analytical response using the PEEL structure (Point, Evidence, Explanation, Link) that integrates at least three distinct textual references across the chapter. Your answer must explicitly use the terms 'moral reversal', 'forensic rhetoric', and 'historical witness'.
COMPETENCY: Structured Analytical Writing with Conceptual Vocabulary
STEPS:
- Step 1: Craft Point sentence: The protagonist occupies the position of prosecutor through moral reversal, transforming colonial education into forensic rhetoric.
- Step 2: Select Evidence 1 (opening): 'fonkbZ&laHkk"k.k mudh lokZfèkd p£pr O;aX; Ñfr' — establishes standing as historical witness.
- Step 3: Select Evidence 2 (middle): 'vki nkfgus Fks, og ck,¡... vki izFke Fks, og nwljs' — forensic listing of reversed hierarchies.
- Step 4: Select Evidence 3 (climax): 'ukfnj'kkg us tc fnYyh esa dRysvke fd;k' — invocation of legal precedent as prosecutorial tool.
- Step 5: Write Explanation for each: how each evidence shows prosecution, not victimhood.
- Step 6: Write Link: This prosecutorial stance makes the chapter a judicial act, not a lament.
ANSWER: The protagonist in 'f'k{kk' is not a victim but a prosecutor who achieves a moral reversal by weaponizing the colonizer's own discourse. As a historical witness, he opens with collective authority: 'fonkbZ&laHkk"k.k mudh lokZfèkd p£pr O;aX; Ñfr', claiming the right to judge. His forensic rhetoric then systematically dismantles the accused: 'vki nkfgus Fks, og ck,¡... vki izFke Fks, og nwljs' catalogues the inversion of power with archival precision. Most damningly, he invokes British legal precedent — 'ukfnj'kkg us tc fnYyh esa dRysvke fd;k' — turning Hastings' impeachment into a template for colonial accountability. Each move refuses victimhood; instead, the protagonist occupies the bench, cross-examines empire, and enters judgment. The chapter thus becomes a judicial act where the colonized tries the colonizer — education's ultimate irony.
DIFFICULTY: hard