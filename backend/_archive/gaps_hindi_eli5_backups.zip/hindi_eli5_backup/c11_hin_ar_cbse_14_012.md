## DEFINITION
Literal comprehension questions require answers directly stated in the text, while inferential comprehension questions require drawing conclusions by combining textual evidence with logical reasoning and prior knowledge.

## COGNITIVE_LEVEL
apply

## MASTERY_CRITERIA
The student can independently classify any question as literal or inferential, locate explicit textual evidence for literal questions, and construct a logical inference chain (evidence → reasoning → conclusion) for inferential questions using the poem "vDd" as the source text.

## SCOPE_BOUNDARY
This node covers only the skill of distinguishing and answering literal vs. inferential questions based on the two poems in Chapter 14 (vDdegknsoh's oppression and the daughter's plea). It does NOT cover critical appreciation, thematic essay writing, or grammatical analysis, which are addressed in sibling nodes.

## WALKTHROUGH
Imagine you are reading a WhatsApp forward claiming "vDdegknsoh was a queen" – you instantly know it's false because the text says she was a poet. That is literal comprehension: the answer sits on the page. Now imagine a friend asks, "Why did the king really fear vDdegknsoh?" The text never says 'fear' directly; you must infer it from his confiscating her property and her subsequent rebellion. This node teaches you to spot that difference: if the answer is printed, it's literal; if you must connect clues (her confiscated land + her poetic revolt = political threat), it's inferential. Start by underlining every factual detail in stanza 1 (dates, places, actions), then practice turning each underlined fact into a literal question. Next, list the gaps – what the poet implies but doesn't state – and practice framing inferential questions from those gaps.

## DIAGNOSTIC_QUESTION_1
What is the defining characteristic of a literal comprehension question?

## DIAGNOSTIC_ANSWER_1
A literal comprehension question has its answer explicitly stated in the text, requiring no interpretation or outside knowledge. A wrong answer (e.g., "it asks for the main idea") reveals the student confuses literal retrieval with higher-order skills like summarization or inference.

## DIAGNOSTIC_QUESTION_2
In the first poem, the line "vDdegknsoh viwoZ lqanjh FkhaA" appears. A student writes: "The question 'Was vDdegknsoh beautiful?' is inferential because beauty is subjective." Is the student correct? Explain why or why not.

## DIAGNOSTIC_ANSWER_2
The student is incorrect. The text explicitly states "viwoZ lqanjh FkhaA" (she was very beautiful), making "Was she beautiful?" a literal question. The subjectivity of beauty is irrelevant; the text asserts it as a fact. A wrong answer reveals the student confuses 'subjective topic' with 'inferential question type'.

## DIAGNOSTIC_QUESTION_3
The poem states the king confiscated vDdegknsoh's property ("buosQ ifjokj ij ncko Mkyk") and she responded by leaving his kingdom ("mlosQ {k.k oL=kkHkw"k.k rFkk jkt&ifjokj dks NksM+ fn;k"). Frame ONE literal question and ONE inferential question from these two facts only.

## DIAGNOSTIC_ANSWER_3
Literal: "What did the king do to vDdegknsoh's property?" (Answer: confiscated it). Inferential: "Why did vDdegknsoh leave the kingdom?" (Answer: to protest the injustice/confiscation). A wrong answer (e.g., making both literal) shows the student cannot distinguish between an explicit action and an implied motive.

## DIAGNOSTIC_QUESTION_4
Compare the two poems in the chapter. The first poem describes vDdegknsoh's historical rebellion; the second poem depicts a daughter (bZ'oj) asking her mother to burn their house. Analyze: Why does the poet place these two poems together? What inferential link connects the two female figures across the poems?

## DIAGNOSTIC_ANSWER_4
The inferential link is intergenerational resistance: vDdegknsoh's public political revolt mirrors the daughter's domestic revolt against patriarchal confinement (burning the house to escape marriage). The poet juxtaposes macro-history (anti-colonial/anti-feudal) with micro-domestic rebellion to show women's resistance transcends scale. A wrong answer (e.g., "both are about women") stays at literal description and misses the structural analogy.

## DIAGNOSTIC_QUESTION_5
A board exam question asks: "Evaluate whether the daughter's request to burn the house ('Hkwy tkÅ¡ viuk ?kj') is a literal desire for arson or a metaphorical plea for liberation. Justify using textual evidence." What level of comprehension does this demand, and what would a high-scoring answer include?

## DIAGNOSTIC_ANSWER_5
This demands EVALUATION-level comprehension. A high-scoring answer would: (1) Acknowledge the literal impossibility (arson is a crime, mother would not agree), (2) Cite metaphorical markers ("u feys Hkh[k" – don't let anyone see, "dksbZ oqQÙkk vk tk," – let some excuse arise), (3) Conclude it's a metaphor for breaking patriarchal control, using the mother's reluctant compliance as evidence of shared understanding. A weak answer treats it only as literal plot summary.

## DIAGNOSTIC_QUESTION_6
Create a new inferential question for the second poem that requires connecting the daughter's plea ("pjkpj! er pwd volj") with the imagery of "tyk er" (darkness) and "engks'k" (silence). Provide the expected inference chain.

## DIAGNOSTIC_ANSWER_6
Question: "What does the progression from 'pjkpj' (burning) to 'tyk' (darkness) to 'engks'k' (silence) suggest about the daughter's envisioned future?" Inference chain: Burning (destruction of current identity) → Darkness (unknown transition) → Silence (peaceful autonomy free from patriarchal noise). A poor answer lists the words without linking them to the theme of liberation.

## COMMON_MISCONCEPTION
Students believe inferential questions are "guessing" or "opinion-based" because the answer isn't in one sentence. They write vague answers like "It shows she is sad" without quoting the specific words (e.g., "eks g ! ik'k vIkus <hy" – her scream to cut the chains) that prove the sadness. They miss that inference = evidence + reasoning, not imagination.

## ON_FAILURE
1. Give the student a 3-column table: Column A = Direct Quote (e.g., "vks pjkpj! er pwd volj"), Column B = Literal Fact (She says burn the house), Column C = Inference (She wants to destroy her current life). 2. Practice filling Column C for 5 quotes from the poem. 3. Require them to write the reasoning sentence: "The word 'volj' (whole/complete) implies total destruction, not partial change, because..." 4. Only after mastering this scaffold, remove the table and ask for independent inferential answers.

## BUILDS_ON
c11_hin_ar_cbse_14_002 (Plot and Narrative Structure) – provides the sequence of events needed to locate literal facts.

## LEADS_TO
c11_hin_ar_cbse_14_013 (Critical Thinking: Analysis and Interpretation) – inferential comprehension is the foundation for deeper critical analysis.

## PREREQUISITE_NODE_IDS
c11_hin_ar_cbse_14_002, c11_hin_ar_cbse_14_004, c11_hin_ar_cbse_14_010, c11_hin_ar_cbse_14_007, c11_hin_ar_cbse_14_008, c11_hin_ar_cbse_14_009, c11_hin_ar_cbse_14_011

## PREREQUISITE_REASONS
c11_hin_ar_cbse_14_002: Understanding plot sequence allows students to locate explicit facts for literal questions.
c11_hin_ar_cbse_14_004: Character analysis of vDdegknsoh provides the background knowledge needed to make valid inferences about her motives.
c11_hin_ar_cbse_14_010: Vocabulary in context (e.g., meanings of 'ik'k', '<hy', 'pjkpj') is essential to interpret key words for both literal and inferential answers.
c11_hin_ar_cbse_14_007: Comprehension questions often ask: "Identify the theme of..." or "How does the poem show...?"  
c11_hin_ar_cbse_14_008: Inferential comprehension questions (e.g., "Why 'bZ'ओज'?") demand device-based evidence.  
c11_hin_ar_cbse_14_009: Comprehension questions often ask to explain the effect of irony and symbolism.  
c11_hin_ar_cbse_14_011: Grammatical parsing of case markers, verb forms, and compounds is prerequisite for answering literal comprehension questions accurately (e.g., who is addressing whom, what is the request). c11_hin_ar_cbse_14_013: Linguistic analysis of dialectal layering and archaic forms provides evidence for critical interpretation of the poem's folk authenticity and devotional stance.  

## FORWARD_NODE_IDS
c11_hin_ar_cbse_14_013, c11_hin_ar_cbse_14_014, c11_hin_ar_cbse_14_015, c12_hin_a_cbse_14_012, c12_hin_ar_cbse_04_012, c12_hin_ar_cbse_14_012

## FORWARD_REASONS
c11_hin_ar_cbse_14_013: Critical analysis requires the ability to make and defend inferences, which this node teaches.
c11_hin_ar_cbse_14_014: Writing skills (e.g., analytical paragraphs) depend on structuring answers with evidence (literal) and explanation (inferential).
c11_hin_ar_cbse_14_015: Literal/inferential comprehension ensures students distinguish fact from interpretation when speaking.  
c12_hin_a_cbse_14_012: Class 11 comprehension skill baseline for literal/inferential distinction.  
c12_hin_ar_cbse_04_012: अगला तार्किक चरण: Literal comprehension is the ability to extract explicitly stated facts, details, and sequences dire... इस नोड की अवधारणाओं को सीधे उपयोग/विस्तारित करता है।  
c12_hin_ar_cbse_14_012: Class 11 comprehension skills (literal/inferential distinction, evidence-based answering) are the direct foundation — this node advances them with Class 12 text complexity and board-exam rigor.  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
none

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_14_002 -> c11_hin_ar_cbse_14_012 -> c11_hin_ar_cbse_14_013

## THIS_FORMULA
Inference = Explicit Textual Evidence + Logical Reasoning + Contextual Knowledge

## FORMULA_VARIABLES
Explicit Textual Evidence: Direct quotes or paraphrased facts from the poem. Logical Reasoning: The connective logic (cause-effect, analogy, contrast) linking evidence to conclusion. Contextual Knowledge: Historical background (1857 revolt, Bhakti movement, patriarchal norms) from nodes 001 and 004.

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
analytical

## CROSS_SUBJECT
c11_history_1857_revolt | The poem references the 1857 uprising ("ohj 'kSo vkanksyu"); understanding the historical context of feudal loyalty vs. rebellion is necessary to infer why the king confiscated property and why vDdegknsoh's resistance was political, not personal.
c11_civics_gender_equality | The second poem's domestic rebellion (daughter vs. mother/house) mirrors civics concepts of patriarchal structures and women's agency; inferring the metaphorical meaning of "burning the house" requires recognizing gendered power dynamics.

## PREREQ_CONCEPT
Ability to distinguish between explicitly stated information and implied meaning in a literary text.

## PREREQ_BEFORE
Student must have read both poems in Chapter 14 and understood the basic narrative (vDdegknsoh's conflict with the king; daughter's plea to mother).

## PREREQ_STUCK
If stuck, review the 'Text: Plot and Narrative Structure' (c11_hin_ar_cbse_14_002) and 'Vocabulary in Context' (c11_hin_ar_cbse_14_010) nodes to rebuild factual and lexical foundation.

## WORKED_EXAMPLE_1
PROBLEM: Answer the textbook question: "y{; izkfIr esa bafnz;k¡ ckèkd gksrh gSa – blosQ lanHkZ esa vius rdZ nhft,A" (In the first poem, the poet talks about oppression. Give your opinion with reference to the context.) Classify this as literal or inferential and answer it.

STEPS:
- Step 1: Classify the question. It asks for "vius rdZ" (your opinion) based on "lanHkZ" (context), so it is INFERENTIAL – the answer is not directly written; you must interpret "oppression" from the narrative.
- Step 2: Locate explicit evidence (literal facts) for oppression: (a) King confiscated property ("ncko Mkyk"), (b) She was forced to leave ("NksM+ fn;k"), (c) Her poetry became rebellion ("dfork osQ :i esa vfHkO;fDr nhA").
- Step 3: Apply contextual knowledge: vDdegknsoh was a Bhakti poetess in 1857; the king was a British collaborator. Oppression here is both feudal (land seizure) and colonial (silencing dissent).
- Step 4: Construct inference chain: Evidence (land seizure + exile) → Reasoning (state power crushing female voice) → Conclusion (oppression is political retaliation against a woman's intellectual resistance).
- Step 5: Draft answer using PEEL: Point (Oppression is political), Evidence (quote "ncko Mkyk"), Explanation (king feared her influence), Link (thus her poetry becomes resistance).

REASONING: This models the full inferential process: the question demands an opinion, so we ground it in literal facts, then layer historical context and logical reasoning to build a defensible interpretation.

ANSWER: The question is inferential. Answer: In the first poem, oppression manifests as the feudal king's retaliation against vDdegknsoh's moral authority. The literal facts – confiscation of her livelihood ("ifjokj ij ncko Mkyk") and forced exile ("jkt&ifjokj dks NksM+ fn;k") – are not merely personal cruelty but political acts to silence a Bhakti poetess who commanded public respect ("lqanjh", "egkiq#"k"). Her transformation of suffering into poetic revolt ("dfork osQ :i esa vfHkO;fDr nhA") proves oppression here is the systemic crushing of female intellectual agency in 1857.

## WORKED_EXAMPLE_2
PROBLEM: A student writes this answer to "vks pjkpj! er pwd volj – bl iafDr dk vk'k; Li"V dhft,A": "The daughter wants to burn the house because she is angry." Identify the error and rewrite as a high-scoring inferential answer.

STEPS:
- Step 1: Diagnose the error. The answer treats a metaphorical plea as literal emotion ("angry") and misses the symbolic weight of "pwd volj" (whole/completely) and the follow-up instructions ("u feys Hkh[k", "dksbZ oqQÙkk vk tk,").
- Step 2: Re-classify the question. "vk'k; Li"V dhft,A" (explain the meaning) signals an INFERENTIAL task – the meaning is not the literal act of arson.
- Step 3: Gather textual evidence: (a) "pjkpj" (burn) + "pwd volj" (totally), (b) Secrecy markers ("u feys Hkh[k", "dksbZ oqQÙkk"), (c) Mother's role ("mls >iVdj Nhu ys eq>ls").
- Step 4: Apply context: In patriarchal society, the house = marital home/confinement. Burning = rejecting prescribed female role. Secrecy = fear of social punishment.
- Step 5: Synthesize inference: The plea is a metaphor for radical autonomy – she asks her mother (complicit in patriarchy) to help destroy the institution (house) that traps her, using a plausible excuse to avoid backlash.
- Step 6: Rewrite answer with structure: Point (metaphor for liberation), Evidence (three quotes), Explanation (patriarchal coding of house), Link (mother-daughter collusion in resistance).

REASONING: This example teaches the repair of a common error – literalizing metaphor – by forcing the student to re-read for symbolic markers and contextual codes.

ANSWER: Error: The answer reduces a complex metaphor to a literal emotion. High-scoring rewrite: The line "vks pjkpj! er pwd volj" is not a literal wish for arson but a metaphorical plea for total liberation from patriarchal confinement. The adverb "pwd volj" (completely) signals she seeks an absolute break, not reform. The demand for secrecy ("u feys Hkh[k") and a cover story ("dksbZ oqQÙkk vk tk,") reveals awareness that open rebellion invites social sanction. By asking her mother to "light the fire" ("pjkpj") and then "bring the ashes" ("mls >iVdj Nhu ys"), the daughter seeks maternal complicity in destroying the domestic space that enforces her subordination. Thus, the "house" symbolizes the marital/familial structure, and burning it symbolizes claiming agency over her own life.

## WORKED_EXAMPLE_3
PROBLEM: Combine literal and inferential skills: "Using ONLY the first poem, prove that vDdegknsoh's beauty ('viwoZ lqanjh') was a political liability, not just a personal trait." This requires chaining literal facts to an inferential conclusion.

STEPS:
- Step 1: List literal facts about beauty: "viwoZ lqanjh FkhaA" (Stanza 1 description).
- Step 2: List literal facts about king's reaction: "vn~Hkqr&vykSfdd lkSan;Z ns[kdj eqXèk gks x;k" (saw her yogic/spiritual aura and got jealous/suspicious), "fookg gsrq buosQ ifjokj ij ncko Mkyk" (confiscated property for rebellion).
- Step 3: Identify the gap: The text links her beauty/aura to the king's jealousy, then to property seizure, then to her rebellion. Beauty → King's insecurity → State action.
- Step 4: Apply historical context (Node 001): In feudal/colonial courts, a charismatic female ascetic threatened male authority; beauty amplified her public influence ("egkohj vkfn egkiq#"kksa osQ le{k [kM+s gksus dk iz;kl").
- Step 5: Construct logical chain: Literal Fact 1 (Beauty) + Literal Fact 2 (King's jealousy) + Context (Female spiritual authority = political threat) = Inference (Beauty made her a target).
- Step 6: Formulate answer: State thesis, cite Fact 1 & 2, explain the causal link using context, conclude.

REASONING: This multi-step problem forces integration of literal retrieval (beauty, jealousy, confiscation), cross-node context (Node 001, 004), and causal reasoning – exactly the synthesis board exams demand in 5-mark questions.

ANSWER: vDdegknsoh's beauty was a political liability because it amplified her public authority, provoking the feudal king's insecurity. Literal evidence: The text explicitly states "viwoZ lqanjh FkhaA" and immediately links the king's reaction to her "vn~Hkqr&vykSfdd lkSan;Z" (yogic bearing) which made him "eqXèk" (jealous/suspicious). His subsequent confiscation of her property ("ncko Mkyk") was a preemptive strike against a woman whose charisma ("lqanjh") drew "egkohj vkfn egkiq#"k" (great souls) to her. In the 1857 context (Node 001), a beautiful, spiritually powerful woman was a rallying point for dissent; thus her beauty was not ornamental but a catalyst for state oppression.

## COMPETENCY_QUESTION_1
QUESTION: The textbook asks: "D;k vDd egknsoh dks dUuM+ dh ehjk dgk tk ldrk gS\ ppkZ djsaA" (Can vDd be called the mother of the nation? Ponder.) This is an evaluative-inferential question. Write a structured answer that uses the formula: Inference = Evidence + Reasoning + Context.

COMPETENCY: Evaluative Inference Construction

STEPS:
- Step 1: Deconstruct the metaphor "dUuM+ dh ehjk" (mother of the nation) – it implies nurturing, sacrifice, foundational role.
- Step 2: Harvest literal evidence from Poem 1: (a) She suffers for the people ("ehjk dh iafDr ru dh vkl dcgw ugha dhuh"), (b) Her poetry inspires rebellion ("dfork osQ :i esa vfHkO;fDr nhA"), (c) She is linked to 1857 leaders ("egkohj vkfn egkiq#"kksa osQ le{k").
- Step 3: Apply reasoning: Motherhood here is metaphorical – she births resistance, not children. Her "opu" (poetry) is the medium of national awakening.
- Step 4: Add context: Bhakti tradition positions the poet as moral conscience; 1857 needed cultural icons. vDdegknsoh fits the "mother" archetype (like Bharat Mata) but as a historical agent, not myth.
- Step 5: Synthesize balanced verdict: Yes, metaphorically, because she embodies sacrificial resistance and cultural regeneration; but literally no, because she was a specific historical poet, not a symbolic construct.

ANSWER: vDdegknsoh can be called "dUuM+ dh ehjk" metaphorically, not literally. Evidence: The text states she bore the nation's sorrow ("ehjk dh iafDr ru dh vkl dcgw ugha dhuh") and transformed her oppression into poetic resistance that galvanized 1857 leaders ("egkohj vkfn egkiq#"kksa osQ le{k [kM+s gksus dk iz;kl"). Reasoning: In the Bhakti-virangana tradition, the female poet becomes the conscience of the polity – she 'mothers' the rebellion by giving it voice and moral courage. Context: The 1857 uprising lacked a unifying cultural symbol; vDdegknsoh's life (property seizure, exile, poetic revolt) mirrors the nation's trajectory. Verdict: She earns the title as a historical embodiment of the motherland's resistive spirit, distinct from the later mythologized Bharat Mata.

DIFFICULTY: hard

## COMPETENCY_QUESTION_2
QUESTION: Compare the inferential logic in these two questions from the same chapter:
QA: "bZ'oj osQ fy, fdl n`"Vkar dk iz;ksx fd;k x;k gSA bZ'oj vkSj mlosQ lkE; dk vkèkkj crkb,A" (What device is used for the daughter? Describe the daughter and her mother.)
QB: "nwljs opu esa bZ'oj ls D;k dkeuk dh xb± gS vkSj D;ksa\" (What does the daughter demand in the second poem and why?)
Explain why QA is primarily literal while QB is inferential, and demonstrate how a student might wrongly answer QB using only literal retrieval.

COMPETENCY: Metacognitive Classification of Question Types

STEPS:
- Step 1: Analyze QA verbs: "crkb,A" (describe) + "fdl n`"Vkar" (what device) – both ask for identification of explicit textual elements (simile/metaphor for daughter, character traits stated).
- Step 2: Analyze QB verbs: "D;k dkeuk dh xb±" (what demand) + "D;ksa" (why) – "what" could be literal ("burn the house"), but "why" demands motive inference (liberation, escape from marriage).
- Step 3: Simulate a literal-only error for QB: Student writes "She demands to burn the house because she says 'pjkpj! er pwd volj'." This quotes the demand but fails to answer "why" inferentially (patriarchal entrapment, desire for autonomy).
- Step 4: Explain the cognitive difference: QA = retrieval + labeling (Bloom: Remember/Understand). QB = retrieval + causal reasoning + contextual decoding (Bloom: Analyze/Evaluate).
- Step 5: State the teaching implication: Students must spot the "why/how/what does it imply" triggers that shift a question from literal to inferential.

ANSWER: QA is literal because "crkb,A" and "n`"Vkar" direct the student to identify stated facts: the literary device (metaphor: "esjs twgh osQ iwQy tSls bZ'oj") and explicit descriptions (daughter = rebellious, mother = cautious). QB is inferential because "D;ksa" (why) cannot be answered by quoting; it requires constructing the daughter's motive from implicit cues (secrecy "u feys Hkh[k", cover story "oqQÙkk", mother's reluctance). A literal-only answer to QB would merely repeat "pjkpj! er pwd volj" and miss the metaphorical demand for freedom from patriarchal confinement, scoring 1/3 marks.

DIFFICULTY: medium