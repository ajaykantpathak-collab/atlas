## DEFINITION
The primary theme of a literary work is its central, unifying idea that the author explores throughout the text, while the message is the specific insight or truth about life, society, or human nature that the author wants the reader to understand and carry forward. In "Bharat Mata," the primary theme is the concept of national identity rooted in the people rather than geography alone, and the message is that true patriotism means embracing unity in diversity across India's vast pluralism.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student must be able to: (1) Identify the primary theme by tracing its development across at least three distinct episodes in the text, and (2) Articulate the author's message in their own words with textual evidence, explaining how Nehru transforms a geographical concept into a humanistic one.

## SCOPE_BOUNDARY
This node covers identifying and analyzing the primary theme and core message of "Bharat Mata" using textual evidence from Nehru's narrative. It does NOT cover secondary themes (node 007), literary devices (nodes 008-009), or writing skills based on the chapter (node 014).

## WALKTHROUGH
Imagine you're at a family gathering where everyone argues about what "real India" means — some say it's the temples, others the Constitution, others the cricket team. Nehru faced this exact confusion in the 1930s when he asked villagers "What is Bharat Mata?" and got puzzled silence. To find the theme, start by listing every time Nehru describes India: the mountains, the rivers, the peasant's field, the factory worker's sweat, the ancient temples, the modern cities. Then ask: which description does he return to most? Which one makes him emotional? The answer — the people themselves — reveals the theme. The key insight: a theme isn't a topic (like "India") but a statement about that topic ("India is its people").

## DIAGNOSTIC_QUESTION_1
What is the difference between a "topic" and a "theme" in literary analysis? Give an example from "Bharat Mata" to illustrate.

## DIAGNOSTIC_ANSWER_1
A topic is a subject or noun phrase (e.g., "India," "freedom struggle," "geography"). A theme is a complete sentence expressing the author's insight about that topic (e.g., "True national identity resides in the collective lives of ordinary people, not in territorial boundaries"). In "Bharat Mata," the topic is "Bharat Mata"; the theme is "Bharat Mata is the millions of people who constitute the nation." A wrong answer that lists only nouns reveals the student confuses subject with thematic statement.

## DIAGNOSTIC_QUESTION_2
Nehru writes that when he asked people "Who is Bharat Mata?", a farmer replied "The earth, the fields." Why does Nehru reject this answer as incomplete, and what does his rejection reveal about the primary theme?

## DIAGNOSTIC_ANSWER_2
Nehru rejects the farmer's answer because it identifies Bharat Mata with inert geography (soil, fields) rather than living humanity. His rejection reveals the primary theme: the nation is not a piece of land but a community of people sharing history, struggle, and aspiration. A wrong answer that says "Nehru liked the farmer's answer" or "Nehru wanted a more poetic answer" shows the student misses the philosophical shift from territory to peoplehood that drives the entire essay.

## DIAGNOSTIC_QUESTION_3
Apply the "theme tracing" method: Find three distinct passages in the text where Nehru moves from describing physical India to describing human India. Quote a key phrase from each and explain how the progression builds the primary theme.

## DIAGNOSTIC_ANSWER_3
Passage 1: "From the snow-capped Himalayas to Cape Comorin" (physical geography). Passage 2: "The peasant in his field, the worker in the factory" (human labor on that geography). Passage 3: "Bharat Mata is essentially these millions of people" (explicit thematic statement). The progression builds the theme by first establishing the familiar geographic India, then populating it with living labor, then declaring the people *are* the nation. A wrong answer that picks three geographic descriptions shows the student cannot distinguish physical description from thematic development.

## DIAGNOSTIC_QUESTION_4
Analyze how Nehru uses the contrast between "unity" and "uniformity" to sharpen his message. Why is this distinction critical to the primary theme in a diverse country like India?

## DIAGNOSTIC_ANSWER_4
Nehru argues that India's unity is not uniformity (sameness) but a "unity in diversity" — different religions, languages, cultures held together by shared history and common destiny. This distinction is critical because if unity required uniformity, India would fracture; the theme *requires* diversity as the very substance of national identity. A wrong answer that treats unity and uniformity as synonyms reveals the student misses the political philosophy at the heart of Nehru's message: pluralism as patriotism.

## DIAGNOSTIC_QUESTION_5
Evaluate this claim: "Nehru's concept of Bharat Mata is purely emotional and lacks political substance." Defend or refute using evidence from the text.

## DIAGNOSTIC_ANSWER_5
Refute. The text shows Nehru linking Bharat Mata to concrete political ideals: democratic rights ("liberty for all"), economic justice ("removal of poverty"), social equality ("no discrimination"). He says the freedom struggle was *for* these people, not for abstract land. The emotion serves the politics — love for the people motivates the struggle for their rights. A wrong answer that agrees with the claim shows the student reads only the lyrical passages and ignores the explicit political program Nehru outlines (Five Year Plans, industrialization, social reform).

## DIAGNOSTIC_QUESTION_6
Create a 50-word "theme statement" for "Bharat Mata" that a Class 11 student could use in a board exam answer. It must include: the core idea, the shift Nehru makes, and the inclusive scope.

## DIAGNOSTIC_ANSWER_6
"Nehru redefines Bharat Mata from territorial geography to living humanity: the nation is not mountains or rivers but the diverse millions — peasants, workers, thinkers — whose shared struggles and aspirations forge unity in diversity, making inclusive peoplehood the only true patriotism." A poor answer that says "India is great because of its people" lacks the analytical precision (the shift, the inclusivity, the political implication) required for senior secondary marking.

## COMMON_MISCONCEPTION
Students often confuse the *refrain* "Bharat Mata ki Jai" (a slogan) with the *theme* (an argued concept). They write: "The theme is love for motherland" — treating the phrase as a devotional chant rather than an analytical construct Nehru builds. This happens because the slogan is culturally familiar, while Nehru's deconstruction of it (asking "who is she?", rejecting the soil answer, redefining her as people) requires active reading. The error is reading *with* the slogan instead of reading *against* it as Nehru does.

## ON_FAILURE
If a student gives the slogan-based answer: (1) Ask them to find the exact paragraph where Nehru says "I would tell them..." and read it aloud. (2) Have them underline every group of people Nehru lists (peasants, workers, city-dwellers, etc.). (3) Ask: "If Bharat Mata is just the land, why does Nehru spend 80% of the essay describing *people*?" (4) Guide them to rewrite the theme as a complete sentence starting with "Nehru argues that..." This forces the shift from slogan to argument.

## BUILDS_ON
This node builds on the student's ability to distinguish literal plot events from abstract ideas (from node 002: Plot and Narrative Structure).

## LEADS_TO
This node enables the analysis of secondary themes like secularism, economic justice, and historical continuity (node 007: Theme: Secondary Themes).

## PREREQUISITE_NODE_IDS
c11_hin_ar_cbse_08_001, c11_hin_ar_cbse_08_002, c11_hin_ar_cbse_08_003, c11_hin_ar_cbse_08_004, c11_hin_ar_cbse_08_005
## PREREQUISITE_REASONS
c11_hin_ar_cbse_08_001: Context and Background provides the historical setting (1930s freedom struggle) essential to understand why Nehru redefines nationalism.
c11_hin_ar_cbse_08_002: Plot and Narrative Structure gives the episode sequence (travels, dialogues, reflections) needed to trace thematic development.
c11_hin_ar_cbse_08_003: Setting and Atmosphere establishes the physical India (rivers, mountains, villages) that Nehru contrasts with human India.
c11_hin_ar_cbse_08_004: Character Analysis: Protagonist reveals Nehru's voice as both observer and philosopher — crucial for distinguishing authorial message from character speech.
c11_hin_ar_cbse_08_005: Character Analysis: Supporting Characters shows how the farmer, the factory worker, the intellectual each embody facets of "the people."

## FORWARD_NODE_IDS
c11_hin_ar_cbse_08_007, c11_hin_ar_cbse_08_012, c11_hin_ar_cbse_08_013, c11_hin_ar_cbse_08_014, c11_hin_ar_cbse_08_009, c11_hin_ar_cbse_08_015, c12_hin_a_cbse_08_006, c12_hin_ar_cbse_08_006, c12_hin_ar_cbse_12_006, c11_hin_ar_cbse_08_010

## FORWARD_REASONS
c11_hin_ar_cbse_08_007: Secondary Themes (secularism, socialism, historical continuity) branch directly from the primary theme of peoplehood.
c11_hin_ar_cbse_08_012: Comprehension questions require thematic understanding to answer inferential "why" and "how" questions.
c11_hin_ar_cbse_08_013: Critical Thinking demands evaluating Nehru's vision against contemporary India — impossible without clear primary theme.
c11_hin_ar_cbse_08_014: Writing Skills (article, speech, essay) on nationalism/unity use this theme as core argument.
c11_hin_ar_cbse_08_009: Primary theme (unity in diversity) is the abstract concept that the symbols (Bharat Mata, mitti) embody.  
c11_hin_ar_cbse_08_015: Primary theme analysis (unity in diversity, nationalism) supplies the core ideas to discuss.  
c12_hin_a_cbse_08_006: Class 11 Kabir theme node establishes the Nirguna framework; Class 12 deepens it with textual evidence.  
c12_hin_ar_cbse_08_006: Class 11 theme node established the theme-subject distinction and evidence-based method this node deepens.  
c12_hin_ar_cbse_12_006: Links imagery to theme — foundation for node 008.  
c11_hin_ar_cbse_08_010: a fragment but a lens for the whole — a concept essential for the 'विषय-वस्तु' (theme) questions in c11_hin_ar_cbse_08_006.  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
none

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_08_002 -> c11_hin_ar_cbse_08_006 -> c11_hin_ar_cbse_08_007

## THIS_FORMULA
N/A - conceptual

## FORMULA_VARIABLES
N/A

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
analytical

## CROSS_SUBJECT
c11_history_nationalism_in_india | Nehru's redefinition of Bharat Mata reflects the historical shift from territorial to civic nationalism during the freedom struggle, connecting literary theme to political history.
c11_civics_unity_in_diversity | The theme "unity in diversity" is the foundational principle of the Indian Constitution (Preamble, Fundamental Duties), making this literary analysis a gateway to constitutional philosophy.
c11_geography_india_physical_features | Nehru's opening geographic catalog (Himalayas, rivers, plains) uses physical geography as a foil for human geography — showing how literature transforms spatial description into social meaning.

## PREREQ_CONCEPT
The student must understand that a theme is an arguable statement about a topic, not the topic itself — and that themes are built through patterns across a text, not single quotes.

## PREREQ_BEFORE
Before starting, the student should be able to summarize the narrative arc of Nehru's travels and list the major groups of people he encounters.

## PREREQ_STUCK
If stuck, review "Plot and Narrative Structure" (node 002) to map the journey's episodes, then "Character Analysis: Supporting Characters" (node 005) to see how each encounter adds a facet to "the people."

## WORKED_EXAMPLE_1
PROBLEM: A student writes in a board exam: "The theme of 'Bharat Mata' is patriotism." Explain why this is insufficient and demonstrate how to upgrade it to a full thematic statement using textual evidence.

STEPS:
- Step 1: Identify the problem — "patriotism" is a topic (noun), not a theme (insight). It doesn't say *what* about patriotism, *whose* patriotism, or *how* it's defined.
- Step 2: Locate Nehru's explicit definition — find where he says "Bharat Mata is essentially..." (paragraph on the people) and "I would tell them..." (the redefinition moment).
- Step 3: Extract the contrast — Nehru contrasts "dharti" (land) with "log" (people); "slogan" with "understanding"; "past glory" with "present suffering."
- Step 4: Synthesize the pattern — Across the essay, Nehru moves from external symbols (flag, map, mountain) to internal realities (hunger, hope, labor, unity).
- Step 5: Formulate the upgraded statement — "Nehru argues that true patriotism is not emotional attachment to territory but active solidarity with the diverse, struggling millions who constitute the nation."
- Step 6: Verify against the text — Check: Does this cover the farmer episode? Yes. The factory worker? Yes. The unity-in-diversity argument? Yes. The political program? Yes.

REASONING: This 6-step process models the board-exam skill of moving from vague topic to precise thematic statement by anchoring each claim in textual movement. It teaches students to read for *argumentative trajectory*, not just content.

ANSWER: Upgraded theme statement: "Nehru redefines patriotism as people-centric solidarity: Bharat Mata is not the soil but the millions of diverse Indians whose shared aspirations and struggles create a living unity that transcends religious, linguistic, and regional differences." This earns full marks because it names the author, the shift, the scope, and the philosophical stakes.

## WORKED_EXAMPLE_2
PROBLEM: The exam asks: "How does Nehru use the question-answer dialogue with the farmer to establish the primary theme?" Write a structured 4-point answer using PEEL (Point, Evidence, Explanation, Link).

STEPS:
- Step 1: Point — The farmer dialogue is the thematic catalyst: it exposes the gap between slogan and understanding, forcing Nehru to articulate his redefinition.
- Step 2: Evidence — Quote the farmer's "dharti, khet" and Nehru's internal response: "I would tell them... Bharat Mata is these millions."
- Step 3: Explanation — The farmer's answer represents conventional, unexamined nationalism (land = mother). Nehru's rejection shows the theme requires *conscious* redefinition: the mother is not the womb (land) but the children (people).
- Step 4: Link — This dialogue structures the entire essay: every subsequent description (peasant, worker, temple, factory) answers "Who is she?" with a human face, building the theme cumulatively.
- Step 5: Board-exam polish — Add transitional phrase: "This pivotal exchange transforms the essay from travelogue to philosophical argument."

REASONING: PEEL forces analytical writing: Point states the literary function, Evidence grounds it, Explanation unpacks the meaning, Link connects to whole-text structure. This mirrors the CBSE marking scheme's demand for "analysis with textual support."

ANSWER: The farmer's reply ("dharti, khet") embodies unexamined territorial nationalism. Nehru uses this as a dialectical springboard: he rejects the land-centric definition to propose a people-centric one ("Bharat Mata is essentially these millions"). The dialogue thus establishes the essay's central argument — that the nation is a human community, not a geographic entity — and every subsequent vignette (peasant, worker, intellectual) serves as evidence for this redefinition. The exchange converts a slogan into a thesis.

## WORKED_EXAMPLE_3
PROBLEM: Combine theme analysis with historical context (node 001): "Nehru's concept of Bharat Mata reflects the specific challenges of 1930s India." Write a 6-step analytical paragraph proving this.

STEPS:
- Step 1: Identify the 1930s challenges — communal tensions, princely states, linguistic regions, colonial divide-and-rule, economic exploitation.
- Step 2: Map each challenge to a thematic response in the text — communal tension → "Hindu, Muslim, Sikh, Christian... all are Bharat Mata"; princely states → "from Kashmir to Kanyakumari"; linguistic regions → "different languages, same heart"; colonial exploitation → "poverty, hunger, unemployment"; divide-and-rule → "unity in diversity."
- Step 3: Show the textual mechanism — Nehru lists diversities *explicitly* (religions, languages, dresses, customs) then asserts unity *despite* them, not by erasing them.
- Step 4: Analyze the political philosophy — This is civic nationalism (shared destiny) vs ethnic nationalism (shared blood/soil), a deliberate choice for a plural society.
- Step 5: Connect to Nehru's later role — The theme prefigures his Prime Ministerial policies: linguistic states reorganization, secular constitution, planned economy for the poor.
- Step 6: Conclude with thematic significance — The primary theme is not abstract philosophy but a *strategic definition of nationhood* designed to hold a fragmenting colony together.

REASONING: This 6-step integration demonstrates the senior secondary skill of cross-referencing literary analysis with historical context — exactly what CBSE's "Critical Thinking" and "Long Answer" questions demand. It shows theme as both artistic choice and political intervention.

ANSWER: In the 1930s, India faced fragmentation along religious, regional, and class lines. Nehru's Bharat Mata directly counters each: he catalogues diversities (religions, languages, geographies) only to subsume them under "millions of people" — a civic nationalism where belonging comes from shared struggle and future, not uniform identity. The peasant's hunger and the worker's sweat become the common denominator. This theme wasn't literary ornament; it was the ideological glue for a nation-in-making, later encoded in the Constitution's "unity and integrity of the Nation" and Nehru's own policies. The text is a blueprint for inclusive nationhood.

## COMPETENCY_QUESTION_1
QUESTION: A Class 11 student writes: "The main theme of 'Bharat Mata' is that India is a great country with diverse cultures." Identify the three specific weaknesses in this statement and rewrite it as a board-exam worthy thematic statement.

COMPETENCY: Thematic precision and textual grounding

STEPS:
- Step 1: Identify weakness 1 — "great country" is evaluative praise, not analytical theme; the text doesn't argue greatness but defines identity.
- Step 2: Identify weakness 2 — "diverse cultures" lists a fact but doesn't state Nehru's *argument* about diversity (that it constitutes unity, not threatens it).
- Step 3: Identify weakness 3 — Missing the central shift: from land to people, from slogan to solidarity.
- Step 4: Rewrite using the formula: "Author argues that [core insight] by [textual strategy], revealing [implication]."
- Step 5: Final polish for exam conditions (under 40 words, includes author, shift, scope, stakes).

ANSWER: Weaknesses: (1) "Great country" is nationalist sentiment, not literary analysis. (2) "Diverse cultures" describes content, not the thematic claim (diversity *as* unity). (3) Omits Nehru's redefinition of Bharat Mata from territory to people. Board-exam rewrite: "Nehru transforms Bharat Mata from geographic territory into a human community: the nation is the diverse millions whose shared struggles forge unity in difference, making peoplehood the only authentic patriotism."

DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: "Nehru's 'Bharat Mata' and Tagore's 'Where the mind is without fear' both address Indian nationalism. Compare their *primary themes* in a structured response that: (a) states each theme as a complete sentence, (b) identifies one key difference in their conceptualization of the nation, and (c) explains how each author's historical moment shapes that difference."

COMPETENCY: Comparative thematic analysis with historical contextualization

STEPS:
- Step 1: State Nehru's theme as a complete sentence — "The nation is the living community of diverse people united by shared struggle and common destiny."
- Step 2: State Tagore's theme as a complete sentence — "True freedom is an inner condition of fearless, truthful, expansive consciousness that transcends narrow domestic walls."
- Step 3: Identify key difference — Nehru's nation is *collective and material* (people, labor, history); Tagore's nation is *individual and spiritual* (mind, truth, perfection).
- Step 4: Contextualize Nehru — 1930s: mass mobilization, colonial exploitation, communal tension → nation as political community to be built.
- Step 5: Contextualize Tagore — 1910 (pre-Gandhi): colonial education, social orthodoxy, spiritual crisis → freedom as internal liberation preceding political freedom.
- Step 6: Synthesize — Both reject colonial definitions, but Nehru builds outward (structures, unity), Tagore builds inward (consciousness, truth).

ANSWER: (a) Nehru: "The nation is the millions of diverse Indians whose collective life and struggle constitute Bharat Mata." Tagore: "True freedom is the fearless, truthful, ever-widening mind that breaks narrow domestic walls." (b) Key difference: Nehru locates nationhood in *social collectivity* (peasants, workers, shared history); Tagore locates it in *individual consciousness* (mind, truth, tireless striving). (c) Historical shaping: Nehru writes amid 1930s mass nationalism needing a unifying political identity for a fragmented colony — hence people-as-nation. Tagore writes in 1910 when political nationalism was nascent but colonial mental slavery was total — hence freedom-as-mind. Nehru's theme builds a *state*; Tagore's theme builds a *self*.

DIFFICULTY: hard