## DEFINITION
Imagery (चित्रात्मकता) refers to the use of vivid, sensory language that appeals to the five senses (sight, sound, smell, touch, taste) to create mental pictures and evoke emotions. Metaphor (रूपक) is a figure of speech that directly compares two unrelated things by stating one *is* the other, without using "like" or "as", to reveal a hidden similarity and deepen meaning.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student can independently identify specific images and metaphors in the poems "olar vk;k" and "rksM+ks", explain how each appeals to the senses, and articulate how they collectively reinforce the poems' central themes of impermanence and human resilience.

## SCOPE_BOUNDARY
This node covers only the identification, classification, and thematic analysis of imagery (visual, auditory, tactile, olfactory, gustatory) and metaphor in the two prescribed poems of Chapter 5. It does NOT cover irony, symbolism, or other literary devices (addressed in node c12_hin_a_cbse_05_009), nor does it address grammatical structures or vocabulary in isolation.

## WALKTHROUGH
Imagine you are sitting in a dimly lit room during a power cut, and someone describes a mango so vividly — its sweet fragrance, the sticky juice running down your fingers, the fibrous texture — that your mouth waters even though there is no mango. That is the power of imagery. Now, if they say "Life is a mango: messy, sweet, and you have to peel through the skin to get to the pulp," that is a metaphor. In this node, we will first read each poem aloud to catch the rhythm and sound. Then we will mark every phrase that triggers a sensory experience (Step 1). Next, we will label each as visual, auditory, etc. (Step 2). Then we will hunt for direct comparisons where one thing is called another (Step 3). Finally, we will ask: "What theme does this cluster of images and metaphors build?" (Step 4). The key insight is that in Jayshankar Prasad's poetry, imagery is not decorative; it is the very architecture of his philosophical argument.

## DIAGNOSTIC_QUESTION_1
What is the precise difference between a metaphor and a simile? Give one example of each from everyday Hindi usage.

## DIAGNOSTIC_ANSWER_1
A metaphor directly equates two things (e.g., "समय धन है" — Time is money), while a simile uses "जैसा" or "सा" to compare (e.g., "वह शेर जैसा बहादुर है" — He is brave like a lion). A wrong answer that says "both compare things" reveals the student has not grasped the structural distinction that metaphor asserts identity, which is crucial for analyzing Prasad's dense metaphorical statements like "जीवन एक प्रवाह है".

## DIAGNOSTIC_QUESTION_2
In the poem "olar vk;k", the line "बड़े-बड़े फूल, ऊँचे ऊँचे पेड़" creates a visual image. Explain how this image contributes to the poem's mood *before* the speaker realizes the fleeting nature of the scene.

## DIAGNOSTIC_ANSWER_2
The image establishes a mood of grandeur, permanence, and overwhelming beauty — tall trees and large flowers suggest a world that is majestic and enduring. This sets up the sharp contrast when the speaker later realizes "हम फँसते जाते हैं" (we keep getting trapped). A student who only says "it shows nature is beautiful" misses the structural role of the image in creating a false sense of stability that the poem later shatters.

## DIAGNOSTIC_QUESTION_3
Identify one metaphor in "rksM+ks" that compares an abstract concept to a concrete object. Write the line (by description, not full quote) and explain the comparison.

## DIAGNOSTIC_ANSWER_3
The metaphor "हृदय की आँच" (the heart's heat/flame) compares emotional passion or life-force to a physical fire. The concrete object (fire/heat) makes the abstract feeling tangible, suggesting it can be fanned, can burn, and can also die out. A wrong answer that picks "पत्थर" (stone) as a metaphor for "heart" without explaining the *comparative* logic shows the student is confusing a symbol with a metaphor.

## DIAGNOSTIC_QUESTION_4
Compare the use of auditory imagery in the two poems. How does the sound imagery in "olar vk;k" (e.g., the description of the bird's call) differ in function from the sound imagery in "rksM+ks" (e.g., the repeated "रक्से रक्से")?

## DIAGNOSTIC_ANSWER_4
In "olar vk;k", the bird's call ("फिर फिर फिर") mimics the repetitive, cyclical nature of time and memory, pulling the speaker back to the past. In "rksM+ks", the onomatopoeic "रक्से रक्से" (the sound of chiseling/hammering) creates a rhythmic, almost musical insistence that mirrors the persistent, laborious effort to carve a path through stone. A student who merely lists the sounds without linking them to the poems' respective themes (nostalgia vs. determined action) has not analyzed the functional difference.

## DIAGNOSTIC_QUESTION_5
Evaluate the claim: "The metaphor of 'पत्थर' (stone) in 'rksM+ks' is more effective than the metaphor of 'प्रवाह' (flow) in 'olar vk;k' because it is more concrete." Defend or refute with evidence from the poems.

## DIAGNOSTIC_ANSWER_5
Refute. Effectiveness depends on thematic fit, not concreteness alone. "पत्थर" brilliantly embodies the obstinate resistance of circumstance and the hardness of the path, while "प्रवाह" perfectly captures the relentless, uncontrollable, and transient nature of time and life. Both are equally effective *for their respective poems*. A student who agrees with the claim reveals a misconception that "concrete = better" and fails to see that metaphors serve specific thematic purposes.

## DIAGNOSTIC_QUESTION_6
Create a four-line Hindi poem stanza that uses at least two different types of sensory imagery (e.g., visual + olfactory) and one metaphor to express the feeling of waiting for exam results.

## DIAGNOSTIC_ANSWER_6
Example:
"कमरे में धुएँ-सी घुलती चिंता की गंध, (olfactory)
दीवार पर टिकी घड़ी की टिक-टिक, (auditory)
भविष्य एक बंद दरवाज़ा, चाबी खोई कहीं, (metaphor)
साँस रोककर बैठा हूँ, परिणाम की प्रतीक्षा में।" (tactile/kinesthetic)
A poor answer that uses only visual imagery ("मैं खिड़की से देखता हूँ") and no metaphor shows the student cannot yet synthesize the devices creatively.

## COMMON_MISCONCEPTION
Students often treat imagery and metaphor as decorative "ornaments" added to a poem, rather than as the **structuring logic** of Prasad's poetry. They identify an image (e.g., "गोकुल की गाय") and stop there, missing that the *cluster* of pastoral images builds a whole worldview (the idealized past) that the poem then interrogates. Similarly, they label "हृदय की आँच" as a metaphor but do not trace how the *fire* metaphor governs the entire stanza: it dictates the verbs (जलना, बुझना, तापना) and the nouns (ईंधन, राख, ज्वाला). This error costs marks in board exams (where "explain with reference to context" requires showing how the device shapes meaning) and in CUET/JEE-style questions that ask "How does the poet use the metaphor of X to develop the theme of Y?"

## ON_FAILURE
1. **Revisit Class 11 Imagery/Metaphor nodes** (e.g., c11_hin_ar_cbse_01_008): Reread the definitions and the worked examples there. 2. **Do a "Device Hunt"**: Take any 4 lines from "olar vk;k". Highlight every sensory word in one colour, every metaphor in another. 3. **Write the "So What?" sentence**: For each highlighted item, write one sentence: "This [image/metaphor] makes the reader feel/understand ______, which supports the theme of ______." 4. **Re-diagnostic**: Attempt Diagnostic Question 4 again. If you cannot link sound imagery to theme, repeat step 2 with a new stanza.

## BUILDS_ON
Class 11 node c11_hin_ar_cbse_01_008 (Literary Devices: Imagery and Metaphor) where students learned basic definitions and identification in simpler poems.

## LEADS_TO
Node c12_hin_a_cbse_05_009 (Literary Devices: Irony and Symbolism) where students will analyze how irony and symbolism interact with the imagery/metaphor foundation built here.

## PREREQUISITE_NODE_IDS
c11_hin_ar_cbse_01_008, c11_hin_ar_cbse_02_008, c11_hin_ar_cbse_03_008, c11_hin_ar_cbse_04_008, c11_hin_ar_cbse_05_008, c11_hin_ar_cbse_06_008, c11_hin_ar_cbse_07_008, c11_hin_ar_cbse_08_008, c11_hin_ar_cbse_09_008, c11_hin_ar_cbse_10_008, c11_hin_ar_cbse_11_008, c11_hin_ar_cbse_12_008, c11_hin_ar_cbse_13_008, c11_hin_ar_cbse_14_008, c11_hin_ar_cbse_15_008, c11_hin_ar_cbse_16_008, c11_hin_v_cbse_01_008, c11_hin_v_cbse_02_008, c11_hin_v_cbse_03_008, c11_hin_v_cbse_04_008, c11_hin_v_cbse_05_008, c12_hin_a_cbse_05_001, c12_hin_a_cbse_05_002, c12_hin_a_cbse_05_003, c12_hin_a_cbse_05_004, c12_hin_a_cbse_05_005, c12_hin_a_cbse_05_006, c12_hin_a_cbse_05_007
## PREREQUISITE_REASONS
c11_hin_ar_cbse_01_008: Provides foundational definitions of imagery and metaphor from Class 11 Aroh textbook.
c11_hin_ar_cbse_02_008: Reinforces identification skills across different poetic forms in Class 11.
c11_hin_ar_cbse_03_008: Builds analytical vocabulary for discussing sensory details.
c11_hin_ar_cbse_04_008: Introduces thematic linking of devices in Class 11 poems.
c11_hin_ar_cbse_05_008: Offers practice with metaphor types (implicit, explicit, extended).
c11_hin_ar_cbse_06_008: Develops ability to distinguish metaphor from simile and symbol.
c11_hin_ar_cbse_07_008: Trains students in writing device-analysis paragraphs.
c11_hin_ar_cbse_08_008: Expands repertoire of sensory categories (kinesthetic, organic).
c11_hin_ar_cbse_09_008: Shows how imagery creates tone in Class 11 poems.
c11_hin_ar_cbse_10_008: Practices comparative analysis of two poems' imagery.
c11_hin_ar_cbse_11_008: Introduces extended metaphor tracking across stanzas.
c11_hin_ar_cbse_12_008: Connects imagery to poet's biography and context.
c11_hin_ar_cbse_13_008: Teaches annotation techniques for close reading.
c11_hin_ar_cbse_14_008: Models board-exam style answers for device questions.
c11_hin_ar_cbse_15_008: Provides CUET-style MCQ practice on imagery.
c11_hin_ar_cbse_16_008: Synthesizes all Class 11 device skills.
c11_hin_v_cbse_01_008: Vitan textbook perspective on imagery in prose-poetry.
c11_hin_v_cbse_02_008: Reinforces metaphor analysis in non-fiction contexts.
c11_hin_v_cbse_03_008: Shows imagery in autobiographical writing.
c11_hin_v_cbse_04_008: Links metaphor to argumentative structure.
c11_hin_v_cbse_05_008: Practices device identification in unseen passages.
c12_hin_a_cbse_05_001: Context/background knowledge of Prasad's life and era.
c12_hin_a_cbse_05_002: Plot/narrative structure of the poems (sequence of images).
c12_hin_a_cbse_05_003: Setting/atmosphere created by imagery in the poems.
c12_hin_a_cbse_05_004: Protagonist's perspective shaped by metaphors.
c12_hin_a_cbse_05_005: Supporting characters (e.g., the bird, the stone) as metaphorical agents.
c12_hin_a_cbse_05_006: Primary theme (impermanence) that imagery serves.
c12_hin_a_cbse_05_007: Secondary themes (resilience, memory) that metaphors illuminate.

## FORWARD_NODE_IDS
c12_hin_a_cbse_05_009, c12_hin_a_cbse_05_010, c12_hin_a_cbse_05_011, c12_hin_a_cbse_05_012, c12_hin_a_cbse_05_013, c12_hin_a_cbse_05_014, c12_hin_a_cbse_05_015
## FORWARD_REASONS
c12_hin_a_cbse_05_009: Irony and symbolism analysis requires a solid grasp of imagery/metaphor as baseline.
c12_hin_a_cbse_05_010: Vocabulary in context often includes metaphorical usages (e.g., "आँच", "प्रवाह").
c12_hin_a_cbse_05_011: Grammar node examines how syntactic choices (compound verbs, case markers) shape imagery.
c12_hin_a_cbse_05_012: Comprehension questions frequently ask "What image does the poet create?" or "Explain the metaphor."
c12_hin_a_cbse_05_013: Critical thinking tasks demand synthesis of imagery, metaphor, theme, and context.
c12_hin_a_cbse_05_014: Writing skills (analytical paragraph, essay) require quoting and analyzing devices.
c12_hin_a_cbse_05_015: Speaking/listening discussions use device analysis as evidence for interpretations.

## CROSS_SUBJECT_PREREQS
c11_hin_ar_cbse_01_008, c11_hin_ar_cbse_02_008
## CROSS_SUBJECT_REASONS
c11_hin_ar_cbse_01_008: Establishes the literary device framework used across Hindi and English literature analysis.
c11_hin_ar_cbse_02_008: Provides comparative practice with other poets (e.g., Nirala, Mahadevi) whose imagery strategies differ from Prasad's.

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_01_008 -> c12_hin_a_cbse_05_008 -> c12_hin_a_cbse_05_009

## THIS_FORMULA
N/A - conceptual

## FORMULA_VARIABLES
N/A

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
conceptual

## CROSS_SUBJECT
N/A | The metaphor of "stone" (पत्थर) in "rksM+ks" parallels the historical metaphor of "bedrock of tradition" vs. "chisel of reform" used in nationalist discourse (e.g., Tilak's "Swaraj is my birthright" as hammer on colonial stone).
 N/A | The visual imagery of "बड़े-बड़े फूल, ऊँचे ऊँचे पेड़" mirrors geographical descriptions of biodiversity hotspots; both use scale and density to evoke awe and ecological value.
 N/A | The extended metaphor of "हृदय की आँच" (heart's heat) as fuel that can be exhausted or sustained connects to the economic concept of human capital depreciation and investment.
 N/A | The poem's central tension between "flow" (change) and "stone" (permanence) reflects the constitutional balance between flexibility (amendments) and basic structure doctrine.
## PREREQ_CONCEPT
Ability to distinguish literal from figurative language and to name the five sensory modalities (visual, auditory, tactile, olfactory, gustatory).

## PREREQ_BEFORE
Student must be able to read the Devanagari text of both poems fluently and understand the glossed vocabulary (e.g., ओलर, रक्से, पँखुसा, उगबस).

## PREREQ_STUCK
If stuck, review the "Imagery Classification Chart" from Class 11 (node c11_hin_ar_cbse_08_008) and practice labeling 10 random lines from any Hindi poem with sensory tags.

## WORKED_EXAMPLE_1
PROBLEM: Analyze the visual and tactile imagery in the opening stanza of "olar vk;k" (the lines describing the garden scene) and explain how they prepare the reader for the speaker's later sense of entrapment.

STEPS:
- Step 1: Read the stanza aloud twice. Note every word that triggers a sensory picture: "बड़े-बड़े फूल" (visual: size), "ऊँचे ऊँचे पेड़" (visual: height), "गोकुल की गाय" (visual: cultural icon), "फिर फिर फिर" (auditory: repetition).
- Step 2: Classify each: "बड़े-बड़े फूल" = visual (colour, size); "ऊँचे ऊँचे पेड़" = visual (verticality); "गोकुल की गाय" = visual + cultural memory; "फिर फिर फिर" = auditory (bird call).
- Step 3: Identify the dominant sensory mode: Visual dominates, creating a panoramic, static tableau. The tactile is absent — no texture, temperature, or touch — which makes the scene feel like a painting, not a lived space.
- Step 4: Connect to entrapment: A painting is a fixed, unchangeable frame. The speaker enters this "frame" ("हम फँसते जाते हैं") and realizes the beauty is a trap because it is frozen in time. The lack of tactile imagery foreshadows the speaker's inability to *grasp* or *hold* the moment.
- Step 5: Verify with the poem's progression: Later stanzas introduce tactile ("पत्थर", "आँच") and kinetic imagery as the speaker struggles to break the frame. The opening's purely visual/auditory imagery is the "before" state.

REASONING: This step-by-step moves from sensory inventory → classification → pattern detection → thematic linkage → structural verification. It mirrors the board-exam expectation: "Quote → Identify device → Explain effect → Link to theme."

ANSWER: The opening stanza uses expansive visual imagery (large flowers, tall trees, pastoral cow) and repetitive auditory imagery (bird call) to construct an idealized, static, almost mythic landscape. The absence of tactile or kinetic imagery makes this world feel like an untouchable picture. This sets up the central conflict: the speaker is "trapped" (फँसते) inside a beautiful but frozen image, unable to interact with it physically. The visual/auditory dominance creates the "frame"; the later tactile struggle is the attempt to escape it.

## WORKED_EXAMPLE_2
PROBLEM: Trace the extended metaphor of "fire/heat" (आँच, जलना, बुझना, तापना) across the first three stanzas of "rksM+ks". Show how the metaphor governs verb choice and noun selection.

STEPS:
- Step 1: Locate all fire-related words in stanzas 1-3: "आँच" (stanza 1), "जलना" (stanza 2), "बुझना" (stanza 2), "तापना" (stanza 3), "ईंधन" (implied in "पत्थर" as fuel?), "ज्वाला" (implied).
- Step 2: Map each to its grammatical role: "आँच" = noun (subject/object), "जलना/बुझना" = intransitive verbs (state), "तापना" = transitive verb (action).
- Step 3: Determine the metaphor's tenor (target) and vehicle (source): Tenor = human will/passion/life-force; Vehicle = fire/heat.
- Step 4: Analyze verb shifts: "जलना" (autonomous burning) → "बुझना" (cessation) → "तापना" (deliberate warming of others). This charts a trajectory from self-sustaining passion to vulnerability to purposeful service.
- Step 5: Check noun collocations: "हृदय की आँच" (possessive, internal), "पत्थर" (external obstacle that can become fuel). The metaphor turns the "stone" obstacle into potential "fuel" for the fire.
- Step 6: Synthesize: The fire metaphor is not ornamental; it provides the poem's causal logic: passion burns → may die out → must be actively shared (तापना) → requires fuel (even stone can be fuel). This is the poem's argument for resilience.

REASONING: Extended metaphor analysis requires tracking lexical chains across stanzas, noting grammatical shifts, and mapping the metaphor's narrative arc. This is exactly what CUET/Board "explain with reference to context" questions demand.

ANSWER: The fire metaphor structures the first three stanzas as a three-act drama of the life-force: (1) Existence ("हृदय की आँच" — the flame exists), (2) Crisis ("जलना/बुझना" — it burns autonomously but can extinguish), (3) Agency ("तापना" — the speaker chooses to warm others, turning obstacles into fuel). Verb transitivity shifts from intransitive to transitive mirror the speaker's shift from passive endurance to active compassion. The noun "पत्थर" is reconceptualized not as barrier but as potential "ईंधन".

## WORKED_EXAMPLE_3
PROBLEM: Compare the metaphor of "flow" (प्रवाह) in "olar vk;k" with the metaphor of "stone" (पत्थर) in "rksM+ks". How do these two central metaphors represent opposing philosophical positions on time and human agency? Write a structured comparative paragraph.

STEPS:
- Step 1: Extract the "flow" metaphor from "olar vk;k": Identify lines where time/life is described as flowing, unstoppable, directionless (e.g., "जीवन एक प्रवाह है", "समय की धारा").
- Step 2: Extract the "stone" metaphor from "rksM+ks": Identify lines where circumstance/path is hard, resistant, shapeable only by persistent labour (e.g., "पत्थर तोड़ते", "रक्से रक्से").
- Step 3: Create a comparison table:
   | Aspect | Flow (olar vk;k) | Stone (rksM+ks) |
   |--------|------------------|-----------------|
   | Ontology | Liquid, continuous, formless | Solid, discrete, resistant |
   | Time | Erodes, carries away, no pause | Endures, must be chiseled through |
   | Agency | Human is passive (drift) | Human is active (hammer) |
   | Outcome | Dissolution, loss | Shaped path, monument |
- Step 4: Identify the synthesis: Prasad presents both as true. "olar vk;k" accepts flow as cosmic reality; "rksM+ks" asserts stone-carving as human response. The poems are dialectical: thesis (flow) → antithesis (stone) → synthesis (the carved path *within* the flow).
- Step 5: Draft paragraph using PEEL: Point (Prasad uses opposing metaphors to stage a debate on agency), Evidence (quote/describe key lines), Explain (table analysis), Link (together they define his humanism: we flow, but we also carve).

REASONING: This example combines device identification, comparative analysis, philosophical interpretation, and answer-writing structure — the full chain required for 6-mark board questions and CUET long-answer types.

ANSWER: In "olar vk;k", the metaphor of "प्रवाह" (flow) portrays time and life as an indifferent, continuous current that sweeps away the speaker's cherished world ("गोकुल की गाय", "बड़े-बड़े फूल"). Human agency is minimal; one can only witness and remember. In "rksM+ks", the metaphor of "पत्थर" (stone) represents the obdurate material of existence that resists but can be shaped by relentless labour ("रक्से रक्से"). Here agency is paramount: the self becomes a chisel. The two metaphors are not contradictory but complementary: flow is the *given* condition of existence; stone-carving is the *chosen* response. Prasad's vision is that meaning is not found in escaping the flow, but in carving a path through the stone *while* flowing.

## COMPETENCY_QUESTION_1
QUESTION: A Class 12 student writes in a board exam answer: "The poet uses the metaphor of stone to show that life is hard." The examiner awards 1 out of 3 marks. Using the marking scheme logic, explain why this answer is incomplete and rewrite it to earn full marks.

COMPETENCY: Critical evaluation of answer quality / Application of marking scheme

STEPS:
- Step 1: Identify the weakness: "Life is hard" is a paraphrase, not an analysis. It names the tenor but ignores the vehicle's properties (stone is hard *and* shapeable, *and* can be a monument, *and* can become fuel).
- Step 2: Recall the marking scheme: 1 mark for identification, 1 for explanation of comparison, 1 for thematic link.
- Step 3: Add the missing layers: (a) Explain the comparison: "Stone resists the chisel but yields to persistent strikes" — this maps to "circumstance resists effort but yields to resilience." (b) Link to theme: "This metaphor supports the poem's theme of 'self-reliant labour' (स्वावलंबी श्रम) because..."
- Step 4: Rewrite: "The metaphor 'पत्थर' equates life's obstacles with a hard, resistant material. However, stone is not immutable; it can be carved ('रक्से रक्से') through sustained effort. This comparison transforms 'hardship' from a dead-end into a raw material for self-creation, directly advancing the poem's central message that dignity lies in shaping one's path through relentless work."

ANSWER: The original answer scores 1/3 because it only identifies the metaphor (tenor = life, vehicle = stone) but does not unpack the *grounds of comparison* (hardness + shapeability) nor link to the specific theme (self-reliant labour). The rewritten answer earns 3/3 by: (1) naming the metaphor, (2) detailing the bidirectional comparison (resistance AND potential for shaping), (3) connecting to the poem's thematic argument about agency.

DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: In a CUET-style assertion-reason question:
Assertion (A): The auditory imagery "फिर फिर फिर" in "olar vk;k" functions primarily as onomatopoeia.
Reason (R): Onomatopoeic words imitate natural sounds and thereby enhance the sensory realism of a poem.
Choose the correct option:
(a) Both A and R are true and R correctly explains A.
(b) Both A and R are true but R does not explain A.
(c) A is true but R is false.
(d) A is false but R is true.
Justify your choice with reference to the poem's structure.

COMPETENCY: Analytical reasoning / Literary device classification / Exam pattern familiarity

STEPS:
- Step 1: Evaluate Assertion: Is "फिर फिर फिर" primarily onomatopoeia? "फिर" means "again"; the repetition mimics the bird's repetitive call. Yes, it is onomatopoeic in effect.
- Step 2: Evaluate Reason: The definition of onomatopoeia is correct.
- Step 3: Test if R explains A: Does the *fact* that onomatopoeia enhances sensory realism explain *why* the poet used it *here*? Not fully. The primary function in this poem is structural: the triple repetition enacts the cyclical, haunting return of memory ("फिर" = again). The sensory realism is secondary to the thematic enactment of recurrence.
- Step 4: Select option: Both true, but R is not the *correct explanation* of A's *primary* function. Option (b).
- Step 5: Write justification: "While 'फिर फिर फिर' is onomatopoeic (true) and onomatopoeia generally enhances realism (true), the poet's strategic use here is to mimic the *temporal* cycle of memory, not merely to make the bird sound real. The word 'फिर' (again) carries semantic weight that pure sound-words (like 'कू कू') lack."

ANSWER: Option (b). Both statements are true, but Reason does not correctly explain Assertion because the primary function of "फिर फिर फिर" is thematic (enacting cyclical return) rather than sensory-realistic. The word "फिर" means "again", making it a semantic onomatopoeia that bridges sound and sense.

DIFFICULTY: hard