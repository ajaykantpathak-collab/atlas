## DEFINITION
Character analysis of supporting characters in a poem involves identifying the secondary figures — whether human, personified natural elements, or implied voices — that interact with the central image (protagonist) and examining their descriptive details, dialogue, actions, and symbolic function to reveal how they deepen the poem’s theme and emotional resonance.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student can independently identify all supporting figures in "जूही की कली", cite specific textual evidence (lines/stanzas) for each, explain their relationship to the जूही कली (protagonist), and articulate how each contributes to the poem’s central idea of fragile beauty and inevitable transience.

## SCOPE_BOUNDARY
This node covers the supporting characters in the poem "जूही की कली" (the child, the gardener implied by "माली", the personified night/dew, and the poet-observer). It does NOT cover the protagonist (जूही कली) which is addressed in node c12_hin_a_cbse_04_004, nor thematic synthesis (node c12_hin_a_cbse_04_006).

## WALKTHROUGH
Imagine you are reading "जूही की कली" and you pause at the lines where a child speaks: "फिरंगी फूल है क्या?" — why does the poet suddenly introduce a child’s voice? Start by listing every figure that is not the bud itself: the child who asks questions, the gardener suggested by "माली", the night that "wears a crown of dew", the dawn that "kisses" the bud. For each, note what the text explicitly says (appearance, speech, action) and what is implied (symbolic role). Then ask: how does this figure’s presence change our understanding of the bud’s fragility or the poem’s mood? The key insight is that supporting characters in a lyric poem are not plot devices but thematic mirrors — each reflects a facet of the central image’s vulnerability or beauty.

## DIAGNOSTIC_QUESTION_1
Identify the three distinct supporting figures explicitly mentioned or strongly implied in the poem "जूही की कली" (excluding the poet-speaker).

## DIAGNOSTIC_ANSWER_1
The three supporting figures are: (1) the child (बच्चा/सीपी) who asks "फिरंगी फूल है क्या?", (2) the gardener (माली) implied by the line "माली ने कहा", and (3) the personified night (रात) described as wearing a "मोती का मुकुट". A wrong answer that lists only human characters (e.g., only the child) reveals the misconception that supporting characters must be human; personified natural elements are equally vital in this poem.

## DIAGNOSTIC_QUESTION_2
Explain in your own words why the poet includes the child’s question "फिरंगी फूल है क्या?" — what does this dialogue reveal about the bud and the poem’s perspective on innocence?

## DIAGNOSTIC_ANSWER_2
The child’s question highlights the bud’s exotic, delicate otherness ("फिरंगी") and mirrors the poet’s own wonder; it frames the bud through innocent eyes that see mystery rather than botany. A wrong answer that treats the question as mere plot decoration misses how the child’s voice amplifies the theme of fragile beauty by contrasting adult knowledge with childlike awe.

## DIAGNOSTIC_QUESTION_3
Apply the "character function" framework to the gardener (माली): using two pieces of textual evidence, show how the gardener’s implied presence establishes the bud’s cultivated vulnerability.

## DIAGNOSTIC_ANSWER_3
Step 1: Locate the line "माली ने कहा" — this establishes a caretaker who monitors the bud. Step 2: Note the gardener’s protective stance implied by "साँझ को ढाँप दिया" (covered at dusk). Step 3: Infer that the bud is not wild but nurtured, making its eventual fall more poignant. A wrong answer that ignores the gardener’s protective act fails to see how human care intensifies the tragedy of natural transience.

## DIAGNOSTIC_QUESTION_4
Analyze how the personified night (रात) and dawn (प्रभात) function as contrasting supporting characters — one protective, one revelatory — and what this duality suggests about the bud’s existence.

## DIAGNOSTIC_ANSWER_4
Night "wears a crown of dew" (मोती का मुकुट) and "covers" the bud, acting as a gentle guardian; dawn "kisses" (चूमती) the bud, exposing it to light and inevitable wilting. Together they frame the bud’s brief life between shelter and exposure. A wrong answer that treats both as merely descriptive imagery misses their active, almost parental roles that structure the poem’s temporal arc.

## DIAGNOSTIC_QUESTION_5
Evaluate the claim: "The poet-speaker is the most important supporting character because he mediates all other figures." Defend or refute using evidence from the poem’s structure.

## DIAGNOSTIC_ANSWER_5
Refute: the poet-speaker is the observer, not a supporting character; the poem’s power comes from the bud’s direct interactions with the child, gardener, night, and dawn. The speaker’s voice appears only in the final reflective stanza ("मैंने देखा"), making him a framing device. A wrong answer that elevates the speaker confuses narrative perspective with character function, a common error in lyric analysis.

## DIAGNOSTIC_QUESTION_6
Create a two-stanza addition to the poem where a new supporting character — the wind (हवा) — interacts with the bud, maintaining the poem’s tone and symbolic pattern.

## DIAGNOSTIC_ANSWER_6
A strong answer will: (1) use the same meter and imagery density (e.g., "हवा आई दबे पाँव / कली को झुलाया धीरे"), (2) show the wind as both gentle and destructive, (3) end with a line that echoes the theme of transience. A poor answer that makes the wind merely "blow hard" ignores the poem’s nuanced personification where every natural force has dual tenderness and inevitability.

## COMMON_MISCONCEPTION
Students often believe "supporting characters" in a poem are only explicitly named humans (like the child). They miss that personified elements (night, dawn, dew) and implied figures (gardener) are equally critical because the poem’s world is built through these interactions. This error stems from applying prose-fiction character definitions to lyric poetry, where the "cast" includes non-human actors that carry thematic weight.

## ON_FAILURE
1. Re-read the poem aloud, circling every noun that acts or is addressed (बच्चा, माली, रात, प्रभात, ओस). 2. For each, write one line of evidence and one inference about its attitude toward the bud. 3. Compare your list with the worked examples below. 4. Re-attempt Diagnostic Questions 3 and 4, focusing on non-human figures.

## BUILDS_ON
Character Analysis: Protagonist (c12_hin_a_cbse_04_004) where the जूही कली was established as the central image; Class 11 character analysis skills (c11_hin_ar_cbse_01_005 etc.) for identifying textual evidence.

## LEADS_TO
Theme: Primary Theme and Message (c12_hin_a_cbse_04_006) where the collective function of all characters converges into the poem’s statement on transience and beauty.

## PREREQUISITE_NODE_IDS
c12_hin_a_cbse_04_004, c12_hin_a_cbse_04_002, c12_hin_a_cbse_04_003, c11_hin_ar_cbse_01_005, c11_hin_v_cbse_01_005, c12_hin_a_cbse_04_001, c11_hin_ar_cbse_01_008, c11_hin_v_cbse_01_008

## PREREQUISITE_REASONS
c12_hin_a_cbse_04_004: Protagonist analysis provides the central image against which supporting characters are defined.
c12_hin_a_cbse_04_002: Plot/narrative structure shows the sequence of interactions.
c12_hin_a_cbse_04_003: Setting/atmosphere establishes the natural world that becomes personified.
c11_hin_ar_cbse_01_005: Class 11 foundation for character analysis terminology and evidence-based reasoning.
c11_hin_v_cbse_01_005: Class 11 Vitan counterpart reinforces the skill across text types.
c12_hin_a_cbse_04_001: "Before You Read: की समझ आवश्यक है, क्योंकि यह नोड (Character analysis of supporting characters in a poem involves identifying the secondary f...) इसी आधार पर आगे बढ़ता है।  
c11_hin_ar_cbse_01_008: If stuck, review "Personification as Characterization" in Class 11 poetry nodes (c11_hin_ar_cbse_01_008, c11_hin_v_cbse_01_008) and practice on a simpler poem like "पहाड़" (Antra Ch. 2).  
c11_hin_v_cbse_01_008: If stuck, review "Personification as Characterization" in Class 11 poetry nodes (c11_hin_ar_cbse_01_008, c11_hin_v_cbse_01_008) and practice on a simpler poem like "पहाड़" (Antra Ch. 2).  

## FORWARD_NODE_IDS
c12_hin_a_cbse_04_006, c12_hin_a_cbse_04_007, c12_hin_a_cbse_04_013, c12_hin_a_cbse_04_008

## FORWARD_REASONS
c12_hin_a_cbse_04_006: Primary theme emerges from the protagonist-supporting character dynamics analyzed here.
c12_hin_a_cbse_04_007: Secondary themes (innocence, care, time) are carried by specific supporting figures.
c12_hin_a_cbse_04_013: Critical thinking requires synthesizing character roles into interpretive arguments.
c12_hin_a_cbse_04_008: Supporting characters (rain, mud, people) — vehicles for metaphors.  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
c12_history_02_004: Colonial-era "फिरंगी" reference in the child’s question links to historical perception of foreign flowers in Indian gardens.
c12_psychology_03_002: Child’s wonder vs. adult knowledge mirrors developmental psychology concepts of animism and perspective-taking.

## CHAIN_DESCRIPTION
c12_hin_a_cbse_04_004 -> c12_hin_a_cbse_04_005 -> c12_hin_a_cbse_04_006

## THIS_FORMULA
N/A - conceptual

## FORMULA_VARIABLES
N/A

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
conceptual

## CROSS_SUBJECT
N/A | The child's question "फिरंगी फूल है क्या?" reflects colonial-era botanical exchanges and Indian perceptions of foreign flora.
 N/A | The poem contrasts childlike animistic wonder (bud as mysterious being) with adult analytical gaze, illustrating Piaget's preoperational vs. formal operational stages.
 N/A | The gardener's protective labor (covering the bud at dusk) mirrors caretaker investment in perishable capital — a microeconomic analogy of resource allocation for fragile assets.
## PREREQ_CONCEPT
Ability to distinguish between explicit textual description and implied characterization in lyric poetry.

## PREREQ_BEFORE
Student must have completed protagonist analysis (node 004) and be comfortable citing stanza/line references from the poem.

## PREREQ_STUCK
If stuck, review "Personification as Characterization" in Class 11 poetry nodes (c11_hin_ar_cbse_01_008, c11_hin_v_cbse_01_008) and practice on a simpler poem like "पहाड़" (Antra Ch. 2).

## WORKED_EXAMPLE_1
PROBLEM: Analyze the child (बच्चा) as a supporting character in "जूही की कली" using the PEEL structure (Point, Evidence, Explanation, Link to theme).
STEPS:
- Step 1: Identify the child's only appearance — the question "फिरंगी फूल है क्या?" in the stanza describing the bud's exotic appeal.
- Step 2: Note the adjective "फिरंगी" (foreign) — the child recognizes the bud's non-native origin, framing it as an object of curiosity.
- Step 3: Explain that the child's innocent query serves as a foil to the poet's knowing observation; the child sees mystery, the poet sees transience.
- Step 4: Link to theme: the child's wonder amplifies the poem's celebration of fleeting beauty by presenting it through unjaded eyes.
- Step 5: Conclude that the child, though brief, expands the bud's significance from a botanical specimen to a wonder that bridges cultures and ages.
REASONING: The PEEL structure forces textual anchoring (Step 2) before interpretation (Step 3), preventing vague claims. The child's single line is maximalized for thematic resonance.
ANSWER: The child acts as an innocence-mirror: his question "फिरंगी फूल है क्या?" (Point) uses the loaded term "फिरंगी" (Evidence) to mark the bud as exotic and precious (Explanation), reinforcing the theme that beauty's value is heightened when seen through wonder rather than ownership (Link).

## WORKED_EXAMPLE_2
PROBLEM: Compare the gardener (माली) and the night (रात) as protective supporting characters — how do their methods of care differ, and what does this contrast reveal about the bud's vulnerability?
STEPS:
- Step 1: Locate gardener evidence: "माली ने कहा / साँझ को ढाँप दिया" — active, deliberate human intervention.
- Step 2: Locate night evidence: "रात ने पहना मोती का मुकुट / और कली को ढाँक लिया" — passive, natural envelopment via dew.
- Step 3: Analyze difference: gardener's care is intentional and scheduled (evening routine); night's care is automatic and ornamental (dew as crown).
- Step 4: Infer vulnerability: the bud needs both human discipline and nature's gentleness, yet neither prevents the dawn's kiss.
- Step 5: Synthesize: the dual protection underscores that the bud's fragility is existential — no amount of care can suspend transience.
- Step 6: Connect to poem's closing image: the fallen bud ("गिरी कली") proves both protections temporary.
REASONING: Contrasting human vs. natural protection deepens the tragedy; the gardener represents cultural cultivation, night represents cosmic nurture — both fail against time.
ANSWER: The gardener protects through ritual ("साँझ को ढाँप दिया"), the night through adornment ("मोती का मुकुट"). Together they frame the bud as a cherished yet doomed entity, making its fall inevitable and poignant.

## WORKED_EXAMPLE_3
PROBLEM: Write a board-exam style answer (80-100 words) to: "How do the supporting characters in 'जूही की कली' collectively construct the poem's central idea of fragile beauty?" Integrate at least three figures.
STEPS:
- Step 1: Thesis sentence: Supporting characters — child, gardener, night/dawn — form a chorus that encircles the bud with wonder, care, and temporal boundaries.
- Step 2: Evidence 1: Child's "फिरंगी फूल" question frames beauty as exotic wonder.
- Step 3: Evidence 2: Gardener's dusk covering shows human reverence for fragility.
- Step 4: Evidence 3: Night's dew-crown and dawn's kiss enact nature's tender but fatal cycle.
- Step 5: Synthesis: Each figure interacts with the bud without possessing it; their collective gaze elevates the bud's brief bloom into a shared moment of grace.
- Step 6: Concluding link: The poem thus argues that beauty resides in vulnerable transience witnessed by many, not owned by one.
REASONING: Board answers require multi-evidence synthesis, not isolated character sketches. The "chorus" metaphor unifies disparate figures into a thematic ensemble.
ANSWER: The supporting characters form a protective chorus around the जूही कली. The child's awed query "फिरंगी फूल है क्या?" frames its beauty as wondrous otherness. The gardener's ritual covering at dusk (माली ने कहा / साँझ को ढाँप दिया) manifests human reverence for fragility. Night's dew-crown (मोती का मुकुट) and dawn's fatal kiss (चूमती) enact nature's tender temporality. Together, they witness the bud's brief glory without possessing it, proving that the poem's central idea — beauty as fleeting grace — is co-created by every gaze that falls upon it.

## COMPETENCY_QUESTION_1
QUESTION: The poem includes a line where the gardener says, "साँझ को ढाँप दिया". If the gardener were replaced by a modern automated greenhouse system, how would the poem's emotional core shift? Explain using the concept of "humanized care" vs. "mechanical protection".
COMPETENCY: Critical Thinking - Evaluation of Authorial Choices
STEPS:
- Step 1: Identify the emotional weight of "माली ने कहा" — a voice, a relationship, a tradition.
- Step 2: Contrast with automated system: efficient but silent, devoid of tenderness.
- Step 3: Argue that the poem's pathos relies on the gardener's personal investment (he "says", he covers).
- Step 4: Conclude that mechanization would strip the poem of its human-nature intimacy, turning elegy into report.
ANSWER: The gardener's spoken care ("माली ने कहा") embodies a human-nature bond where protection is an act of love. An automated system would provide better climatic control but erase the tenderness that makes the bud's fall tragic. The poem mourns not just a flower's death but the fragility of the caring relationship itself.
DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: Construct a comparative analysis table showing how the child, the gardener, and the night each "see" the जूही कली differently. Then write a 50-word synthesis explaining how these three perspectives create a holistic portrait of the bud that the poet-speaker alone could not achieve.
COMPETENCY: Analytical Writing - Multi-Perspective Synthesis
STEPS:
- Step 1: Create table with columns: Figure / Perspective / Textual Evidence / Symbolic Lens.
- Step 2: Fill for child: wonder / "फिरंगी फूल है क्या?" / innocence lens.
- Step 3: Fill for gardener: responsibility / "साँझ को ढाँप दिया" / stewardship lens.
- Step 4: Fill for night: adornment / "मोती का मुकुट" / cosmic nurture lens.
- Step 5: Synthesize: The poet-speaker observes from outside; these three inhabit the bud's world — curious, protective, enveloping — together revealing the bud as culturally exotic, humanly cherished, and cosmically cradled.
ANSWER: Table: Child=Wonder ("फिरंगी फूल"), Gardener=Stewardship ("ढाँप दिया"), Night=Cosmic Nurture ("मोती का मुकुट"). Synthesis: The poet watches; the child marvels, the gardener tends, the night adorns. Their lived interactions — not the poet's description — make the bud's fragility palpable. The bud is not an image but a nexus of relationships; its beauty is relational, not intrinsic.
DIFFICULTY: hard