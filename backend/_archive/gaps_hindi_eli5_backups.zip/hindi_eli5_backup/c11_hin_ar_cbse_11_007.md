## DEFINITION
Secondary themes are the underlying ideas, motifs, or messages that run parallel to the primary theme in a literary work, enriching the text by adding layers of meaning, exploring related human experiences, or highlighting specific social, emotional, or philosophical dimensions that support but do not dominate the central idea.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student must be able to identify at least three distinct secondary themes in "Ghar ki Yaad," trace each theme across specific stanzas with textual evidence, and explain how each secondary theme deepens or complicates the primary theme of nostalgia and longing for home.

## SCOPE_BOUNDARY
This node covers the identification, analysis, and interpretation of secondary themes in the poem "Ghar ki Yaad" (Chapter 11, Aroh). It does not cover the primary theme in detail (covered in node 006), nor does it cover literary devices like imagery or irony (nodes 008, 009), though it may reference them as tools for theme development.

## WALKTHROUGH
Imagine you are packing for a hostel or university far from home. You feel a sharp pang when you see your mother's cooking, your father's chair, your sibling's toys – each object triggers a different memory: security, struggle, joy, silence. Similarly, in "Ghar ki Yaad," the poet's memory of home is not a single feeling but a cluster of interconnected experiences. To begin, re-read the poem marking every stanza that does not directly express "I miss home" but instead describes a person, a scene, or a feeling associated with home. Ask: What aspect of life does this stanza highlight? The mother's endless labor? The father's absence? The children's innocence? The house as a witness? Each distinct aspect is a secondary theme. The key insight is that secondary themes are the bricks that build the mansion of the primary theme.

## DIAGNOSTIC_QUESTION_1
What is the difference between a primary theme and a secondary theme in a poem?

## DIAGNOSTIC_ANSWER_1
The primary theme is the central, dominating idea that unifies the entire poem (e.g., the pain of separation from home in "Ghar ki Yaad"). A secondary theme is a subordinate idea that appears in specific sections, supports the primary theme, and explores a related facet of human experience (e.g., a mother's silent sacrifice, the father's absence, the innocence of children). A wrong answer that equates them or thinks secondary themes are less important reveals a misunderstanding of thematic hierarchy and the structural function of sub-themes in creating depth.

## DIAGNOSTIC_QUESTION_2
In "Ghar ki Yaad," the poet describes the mother lighting the stove, cooking, and managing the household alone. Which secondary theme does this imagery develop, and how does it connect to the primary theme of longing?

## DIAGNOSTIC_ANSWER_2
This imagery develops the secondary theme of **maternal sacrifice and the invisibility of women's labor**. The mother's ceaseless work ("cfgu vkbZ cki osQ ?kj") makes the home a living entity; the poet's longing is intensified because he realizes the home he misses is sustained by her unseen toil. A wrong answer that merely says "it shows the mother works hard" misses the thematic link: the secondary theme explains *why* the home is precious and *what* the poet feels guilty about leaving, deepening the primary theme from simple nostalgia to a complex emotional debt.

## DIAGNOSTIC_QUESTION_3
Apply the concept of secondary themes to a new context: In a poem about a soldier writing a letter from the border, he describes his father ploughing the field, his sister's wedding preparations, and the monsoon arriving early. Identify two secondary themes and explain how each would amplify the primary theme of duty vs. longing.

## DIAGNOSTIC_ANSWER_3
Two secondary themes: (1) **Continuity of rural life despite absence** – the father ploughing and sister's wedding show life goes on, making the soldier's absence a void in a functioning system, sharpening the pain of separation. (2) **Nature's indifference to human borders** – the early monsoon arrives regardless of war, contrasting the soldier's constrained existence with nature's freedom, heightening the tension between duty and the desire to return. A wrong answer that lists topics ("farming," "rain") without linking them to the primary theme fails to demonstrate thematic analysis.

## DIAGNOSTIC_QUESTION_4
Analyze how the secondary theme of "the house as a silent witness" (the house that remembers every hand, every footstep) interacts with the secondary theme of "the father's absence" in the poem. What does their intersection reveal about the family structure?

## DIAGNOSTIC_ANSWER_4
The house witnesses the father's empty chair ("firk th ftudks cq<+kik, d {k.k Hkh ugha O;kik") and the mother's burden simultaneously. Their intersection reveals a **fractured patriarchal structure where the physical absence of the father transfers the entire weight of "home" onto the mother and the house itself**. The house becomes the only constant "father figure" holding memories. A wrong answer that treats these as separate, unrelated observations misses the structural critique: the poem uses the house's memory to expose the father's failure, making the longing for home also a longing for a lost wholeness.

## DIAGNOSTIC_QUESTION_5
Evaluate the claim: "The secondary theme of childhood innocence (the children playing, unaware of poverty) weakens the poem's primary theme of painful longing because it introduces a happy note." Defend or refute with textual reasoning.

## DIAGNOSTIC_ANSWER_5
**Refute.** The innocence of children ("pkj HkkbZ pkj cfgusa... vkSj ek¡ fcu&i<+h esjh") does not weaken but **intensifies** the primary theme through dramatic irony. The poet's adult consciousness is haunted by the memory of his own past innocence; the contrast between the children's current joy and his present separation creates a temporal ache. Moreover, their innocence is fragile – the poem hints at future struggles ("dke esa >a>k yjtrk"). A wrong answer that agrees with the claim misunderstands how contrast and irony function: secondary themes often operate through juxtaposition, not harmony, to deepen the primary emotion.

## DIAGNOSTIC_QUESTION_6
Create a four-line stanza in Hindi (or English) that introduces a new secondary theme for "Ghar ki Yaad" – one not explicitly in the poem but consistent with its world – and explain how it would change the poem's emotional trajectory.

## DIAGNOSTIC_ANSWER_6
**Stanza (Hindi):**
"बूढ़े नीम की छाया में बैठा बूढ़ा बाप,
सुनाता था किस्से, अब सुनता है आप।
चिट्ठी पढ़कर रोता, फिर छुपा लेता आँसू,
घर की दीवारें ही जानें उसका हौसला।"

**New secondary theme: The silent grief of the aging father left behind.** This shifts the emotional trajectory from the poet's solitary longing to a **shared, intergenerational grief**, making "home" a space of mutual absence. The poem would then explore separation as a two-way wound. A poor answer would add a decorative image without a thematic function (e.g., just describing a tree) showing inability to distinguish thematic development from mere imagery.

## COMMON_MISCONCEPTION
Students often confuse **secondary themes with mere topics or motifs**. For example, they list "mother," "father," "children," "stove," "house" as secondary themes. These are *subjects* or *motifs*. A theme is a complete idea *about* that subject: not "mother" but "the invisibility and indispensability of maternal labor"; not "house" but "the house as a repository of collective memory that outlives its inhabitants." This error occurs because students stop at noun-identification instead of moving to propositional statements (subject + predicate). In board exams, writing "Mother is a secondary theme" fetches 0 marks; writing "The theme of maternal sacrifice..." fetches full marks.

## ON_FAILURE
1. **Step 1:** Give the student a list of 5 nouns from the poem (mother, father, house, children, stove). Ask them to convert each into a thematic statement by adding a verb and a consequence (e.g., Mother -> "Mother's labor sustains the home but goes unacknowledged").
2. **Step 2:** Provide two model thematic statements (one primary, one secondary) and ask the student to label them and justify using the definition of "central vs. supporting."
3. **Step 3:** Have the student re-read stanzas 4-6 (mother's description) and 7-9 (father's absence) and write one thematic statement per stanza cluster. Check if each statement can stand as a complete sentence expressing an insight about life.
4. **Step 4:** If still stuck, use the "So what?" ladder: "The poem mentions the stove." -> "So what?" -> "The mother works at the stove." -> "So what?" -> "Her work keeps the home alive." -> "So what?" -> "The home the poet misses is a product of her invisible labor." The final rung is the secondary theme.

## BUILDS_ON
This node builds on the ability to identify the primary theme (node 006) and the skill of extracting textual evidence from stanzas (nodes 002, 003).

## LEADS_TO
This node enables the analysis of how literary devices (imagery, irony, symbolism in nodes 008, 009) are deployed to construct these secondary themes, and supports critical interpretation (node 013) and writing skills (node 014).

## PREREQUISITE_NODE_IDS
c11_hin_ar_cbse_11_006, c11_hin_ar_cbse_11_002, c11_hin_ar_cbse_11_003, c11_hin_ar_cbse_11_005

## PREREQUISITE_REASONS
c11_hin_ar_cbse_11_006: Understanding the primary theme is essential because secondary themes are defined by their relationship to it (supporting, complicating, contrasting).
c11_hin_ar_cbse_11_002: Knowledge of plot/narrative structure helps locate where in the poem's progression each secondary theme appears and peaks.
c11_hin_ar_cbse_11_003: Understanding setting and atmosphere is crucial because secondary themes in this poem are deeply embedded in the physical and emotional landscape of the home.
c11_hin_ar_cbse_11_005: Secondary themes (gendered labor, generational gap, memory vs. reality) emerge from the specific characterisations of wife (domestic burden), children (resentful growth), and house (memory vessel).  

## FORWARD_NODE_IDS
c11_hin_ar_cbse_11_008, c11_hin_ar_cbse_11_009, c11_hin_ar_cbse_11_013, c11_hin_ar_cbse_11_014, c11_hin_ar_cbse_11_012, c12_hin_a_cbse_01_007, c12_hin_a_cbse_08_007, c12_hin_a_cbse_10_007, c12_hin_a_cbse_11_007

## FORWARD_REASONS
c11_hin_ar_cbse_11_008: Imagery and metaphor are the primary vehicles for conveying secondary themes (e.g., stove as metaphor for maternal labor); theme identification must precede device analysis.
c11_hin_ar_cbse_11_009: Irony and symbolism often operate at the level of secondary themes (e.g., the house symbolizing continuity vs. father's absence); recognizing themes allows detection of these devices.
c11_hin_ar_cbse_11_013: Critical interpretation requires synthesizing primary and secondary themes into a coherent reading; this node provides the thematic raw material.
c11_hin_ar_cbse_11_014: Writing skills (analytical paragraphs, essays) demand thematic arguments supported by evidence; this node teaches the argument formation.
c11_hin_ar_cbse_11_012: Secondary themes (displacement, time) provide additional lenses for inference.  
c12_hin_a_cbse_01_007: Chapter 11 integrated vocabulary with thematic nuance.  
c12_hin_a_cbse_08_007: अगला तार्किक चरण: Secondary themes are the underlying, complementary ideas in a literary work that support, contrast w... इस नोड की अवधारणाओं को सीधे उपयोग/विस्तारित करता है।  
c12_hin_a_cbse_10_007: Connects secondary themes to nationalist cultural projects.  
c12_hin_a_cbse_11_007: Class 11 introduced secondary theme identification; this node deepens it with more complex texts.  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
No prior class nodes are available for cross-subject linking in this dataset.

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_11_006 -> c11_hin_ar_cbse_11_007 -> c11_hin_ar_cbse_11_008 (Primary theme identification enables secondary theme analysis, which enables literary device analysis as thematic tools)

## THIS_FORMULA
Secondary Theme = (Recurring Subject/Motif) + (Author's Insight/Commentary on that Subject) + (Textual Evidence across 2+ Stanzas) + (Explicit Link to Primary Theme)

## FORMULA_VARIABLES
- Recurring Subject/Motif: A concrete element repeated in the poem (e.g., stove, empty chair, children playing).
- Author's Insight/Commentary: The abstract idea the poet attaches to that subject (e.g., "labor is invisible but essential").
- Textual Evidence across 2+ Stanzas: Specific lines/images from different parts of the poem that collectively support the insight.
- Explicit Link to Primary Theme: A statement explaining how this secondary theme deepens, contrasts, or contextualizes the central idea of longing for home.

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
conceptual

## CROSS_SUBJECT
c11_history_colonialism | The poem's depiction of rural household labor and absent father mirrors the economic migration patterns in colonial and post-colonial India where men left villages for work, leaving women to manage subsistence – a historical context that deepens the secondary theme of maternal burden.
c11_sociology_family_structure | The shift from joint to nuclear family and the changing roles of mothers/fathers in rural India (as seen in the poem's isolated mother figure) connects to sociological concepts of family disorganization and gendered division of labor, providing a structural lens for the secondary themes.

## PREREQ_CONCEPT
The student must understand that a theme is a complete sentence expressing a universal insight about life, not a single word or phrase (topic).

## PREREQ_BEFORE
The student must have completed the analysis of the primary theme (node 006) and be able to summarize the poem's narrative flow (node 002).

## PREREQ_STUCK
If stuck, review the distinction between "topic" (e.g., mother) and "theme" (e.g., maternal sacrifice) using the Primary Theme node (c11_hin_ar_cbse_11_006) where this was modeled for the central idea.

## WORKED_EXAMPLE_1
PROBLEM: Identify and analyze the secondary theme of "Time as an erosive force" in "Ghar ki Yaad," tracing it across three stanzas and linking it to the primary theme of longing.

STEPS:
- Step 1: Scan the poem for references to time, aging, change, or decay. Locate: Stanza 2 ("vkt ikuh fxj jgk gS" – now it has been a long time), Stanza 5 ("tc fd uhps vk, gksaxs... uSu ty ls Nk, gksaxs" – when you come down later, you will be tired), Stanza 10 ("vH;kl" section implies a future reunion).
- Step 2: Formulate the insight: Time transforms the remembered home into an idealized past; the present home is aging, and the future reunion will be with changed people in a changed space.
- Step 3: Gather evidence: "cgqr ikuh fxj jgk gS" (long time passed), "firk th ftudks cq<+kik" (father aged), "ik¡o tks ihNs gVkrk" (child who used to crawl now walks), "vkt muosQ Lo.kZ csVs yxs gksaxs mUgsa gsVs" (now they will be old, you will touch their feet).
- Step 4: Analyze the progression: Past (memory) -> Present (separation/aging) -> Future (reunion with irreversible change). The theme is not just "time passes" but "time makes return impossible in the way we imagine."
- Step 5: Link to primary theme: The longing is tragic because the object of longing (home as it was) is destroyed by time; the poet longs for a home that exists only in memory. This transforms nostalgia into existential grief.

REASONING: This worked example demonstrates the full thematic analysis loop: motif hunting -> proposition formation -> multi-stanza evidence clustering -> temporal/dialectical analysis -> thematic synthesis. It models the board-exam requirement of "tracing a theme across the text."

ANSWER: The secondary theme "Time as an erosive force that makes homecoming impossible" is developed through the contrast between the frozen memory of a vibrant home and the living reality of aging parents and growing children. It deepens the primary theme by showing that the poet's longing is directed at a phantom – the home he misses no longer exists, and the home that exists will not match his memory.

## WORKED_EXAMPLE_2
PROBLEM: The poem contrasts the "inside" of the home (warmth, mother, children) with the "outside" (the poet's current location, implied as distant, cold, perhaps urban). Analyze how this spatial dichotomy functions as a secondary theme of "Inside vs. Outside" and what it reveals about the migrant experience.

STEPS:
- Step 1: Identify spatial markers. Inside: "?kj u”kj esa frj jgk gS" (cradle swings in home), "cfgu vkbZ cki osQ ?kj" (mother's stove), "pkj HkkbZ pkj cfgusa" (four kids, four laps). Outside: Implied by "vkt ikuh fxj jgk gS" (now long time passed staying away), "tc fd uhps vk, gksaxs" (when you come down later – implying the poet is 'up' or 'away').
- Step 2: Formulate the thematic proposition: The home is constructed as a sanctuary of organic relationships, while the outside is a space of alienation and temporal displacement; the migrant belongs fully to neither.
- Step 3: Analyze the mother as the gatekeeper of the inside: She sustains the inside ("cfgu vkbZ cki osQ ?kj") but her body bears the cost ("dke esa >a>k yjtrk" – waist bent from work). The father's absence is an absence from the inside.
- Step 4: Analyze the poet's position: He is outside looking in ("eSa ets esa gw¡ lgh gS / ?kj ugha gw¡ cl ;gh gS" – I am right here, home is not here, it is that very feeling). He carries the inside inside him, but physically he is outside.
- Step 5: Connect to primary theme: The longing is not just for a place but for a mode of being (inside-ness) that migration has ruptured. The secondary theme spatializes the emotion.

REASONING: This example shows how to derive a secondary theme from a structural binary (inside/outside) rather than a single motif. It requires mapping spatial language across the poem and interpreting the migrant subject's split consciousness – a key Class 11 analytical skill.

ANSWER: The secondary theme "Home as an irreducible inside that cannot be transported" emerges from the poem's spatial architecture. The inside is defined by maternal labor, childhood innocence, and paternal authority (even in absence); the outside is defined by the poet's solitary voice. The tragedy is that the poet's identity is split: he is the "inside" person living "outside." This spatializes the primary theme: longing is the pain of the unbridgeable gap between where one's body is and where one's belonging resides.

## WORKED_EXAMPLE_3
PROBLEM: Synthesize the three secondary themes analyzed above (Maternal Sacrifice, Time as Erosive Force, Inside vs. Outside) to show how they form a thematic cluster that redefines the primary theme from "nostalgia" to "structural grief." Write a board-exam style analytical paragraph (100-120 words).

STEPS:
- Step 1: Define the thesis: The primary theme is not mere nostalgia but structural grief – the grief of a system (family, home, time) that migration has fractured.
- Step 2: Introduce Theme 1 (Maternal Sacrifice) as the economic/emotional base: The home is produced by the mother's invisible labor; the poet's absence is a withdrawal from this economy of care.
- Step 3: Introduce Theme 2 (Time) as the irreversible dimension: The mother ages, father weakens, children grow; the "home" is a moving target. The grief is for a past that cannot be reclaimed.
- Step 4: Introduce Theme 3 (Inside/Outside) as the spatial/existential condition: The poet carries the inside but lives outside; the grief is ontological – a split self.
- Step 5: Synthesize: These three themes (labor, time, space) are the three axes of the structural fracture. The primary theme "longing for home" is the symptom; the secondary themes are the diagnosis.
- Step 6: Draft the paragraph using PEEL structure (Point, Evidence, Explanation, Link) for each theme, then a concluding synthesis sentence. Ensure textual references (stanza indicators) are embedded.

REASONING: This is the highest-order task: thematic synthesis. Board exams (especially 5-6 mark questions) require students to show how multiple themes interact to produce a complex reading. This example trains the student to move from isolated theme identification to a unified critical argument.

ANSWER: In "Ghar ki Yaad," the primary theme of longing is deepened into structural grief by three interlocking secondary themes. First, the theme of maternal sacrifice ("cfgu vkbZ cki osQ ?kj") reveals the home as a product of gendered labor the poet has abandoned, making his longing tinged with guilt. Second, time's erosive force ("vkt ikuh fxj jgk gS", "firk th ftudks cq<+kik") makes the desired home a temporal phantom – the aging parents and grown children ensure the home he returns to will not be the home he left. Third, the inside/outside dichotomy ("?kj ugha gw¡ cl ;gh gS") spatializes the migrant's split consciousness: he is the inside-person stranded outside. Together, these themes – labor, time, space – diagnose the fracture: the poet does not merely miss a place; he mourns a wholeness that migration has structurally dismantled. The longing is the pain of an irreparable system.

## COMPETENCY_QUESTION_1
QUESTION: A Class 11 student writes in their exam answer: "The secondary themes of the poem are mother, father, children, and house." The examiner awards 0 marks. Using the definition and formula from this node, explain exactly why this answer fails and rewrite it to score full marks (2 marks for identification + 2 marks for explanation).

COMPETENCY: Conceptual Clarity & Exam Answer Writing
STEPS:
- Step 1: Identify the error: The student listed topics/nouns, not themes. A theme requires a predicate (insight about the topic).
- Step 2: Apply the formula: Secondary Theme = Subject + Insight + Evidence + Link to Primary Theme.
- Step 3: Convert each noun into a thematic statement with insight.
- Step 4: Write the corrected answer showing the thematic statement and one piece of evidence for each.

ANSWER: The answer fails because it confuses **motifs** (recurring concrete elements) with **themes** (abstract propositions about life). "Mother" is a character; "the invisibility and indispensability of maternal labor" is a theme. "House" is a setting; "the house as a silent witness that outlives its inhabitants" is a theme. **Corrected full-mark answer:** (1) **Maternal Sacrifice:** The poem portrays the mother as the unseen engine of the home ("cfgu vkbZ cki osQ ?kj"), revealing that the poet's longing is for a comfort built on her unacknowledged toil. (2) **Paternal Absence/Void:** The father's empty presence ("firk th ftudks cq<+kik, d {k.k Hkh ugha O;kik") creates a structural lack that the house and mother cannot fill, making the home incomplete. (3) **Fragility of Innocence:** The children's joy ("pkj HkkbZ pkj cfgusa") is framed by the poet's adult awareness of future hardship ("dke esa >a>k yjtrk"), contrasting past innocence with present grief. (4) **House as Memory-Keeper:** The house remembers every hand and foot ("?kj fd ?kj esa lc tqM+s gSa"), functioning as the only permanent "parent," making the poet's separation from it a separation from his own history.
DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: "Secondary themes in a poem are like branches of a tree; the primary theme is the trunk." Critique this metaphor using "Ghar ki Yaad." Does the poem support a hierarchical (trunk-branch) model or a rhizomatic (interconnected root) model of thematic structure? Justify with three specific textual intersections where secondary themes merge and cannot be separated.

COMPETENCY: Critical Thinking & Metaphorical Reasoning
STEPS:
- Step 1: Analyze the metaphor: Trunk-branch implies primary theme is structural support and secondary themes are dependent offshoots. Rhizomatic implies themes are horizontally connected, mutually constitutive, with no single center.
- Step 2: Test on the poem. Find three intersections:
  - Intersection 1: Mother's labor (Theme A) + Father's absence (Theme B) + Time (Theme C) – in stanza where mother works alone because father is away, and both are aging.
  - Intersection 2: Children's innocence (Theme D) + Inside/Outside (Theme E) + Maternal Sacrifice (Theme A) – children play inside because mother creates the inside; poet is outside remembering.
  - Intersection 3: House as witness (Theme F) + Time (Theme C) + Paternal Absence (Theme B) – house remembers father's youth, now sees his old age; poet asks house to convey messages.
- Step 3: Argue: These intersections show themes are co-produced, not hierarchically derived. The "primary theme" (longing) is the *effect* of these intersections, not their cause.
- Step 4: Conclude: The rhizomatic model is more accurate. The poem's structure is a web of mutual illumination.

ANSWER: The trunk-branch metaphor fails for "Ghar ki Yaad" because the secondary themes are not appendages of the primary theme; they are the **generative conditions** of it. The primary theme (longing) emerges *from* the rhizomatic entanglement of: (1) **Maternal labor + Paternal absence + Time** – Stanza 4-6: The mother runs the home alone ("cfgu vkbZ cki osQ ?kj") precisely because the father is absent ("firk th ftudks cq<+kik"), and both are aging ("vkt muosQ Lo.kZ csVs yxs gksaxs"). You cannot isolate "maternal sacrifice" as a branch; it is the trunk *and* the root simultaneously. (2) **Innocence + Inside/Outside + Maternal labor** – The children's safety ("pkj HkkbZ pkj cfgusa") exists only inside the home the mother sustains; the poet's outside-position makes him the sole witness to this fragility. (3) **House as witness + Time + Communication** – The house ("?kj fd ?kj esa lc tqM+s gSa") holds the father's past and the children's future; the poet asks it to deliver messages ("mUgsa dguk fy[k jgk gw¡"). The house is not a branch; it is the neural network connecting all themes. Thus, the poem operates as a **rhizome**: themes are horizontally linked nodes where pulling one vibrates the others. The "primary theme" is the name we give to the vibration of the whole network.
DIFFICULTY: hard