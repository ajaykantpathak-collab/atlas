## DEFINITION
Literal comprehension questions require answers that are directly and explicitly stated in the text. Inferential comprehension questions require the reader to deduce implied meaning by synthesizing textual clues, context, and prior knowledge, going beyond what is plainly written.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
Student can independently classify any question as literal or inferential, locate explicit textual evidence for literal answers, and construct a logical, text-supported inference for inferential answers using the PEEL (Point, Evidence, Explanation, Link) structure.

## SCOPE_BOUNDARY
This node covers strategies for answering literal and inferential questions based specifically on the three stories in Chapter 11 ("ckyd cp x;k", "?kM+h osQ iq”ksZ", "<sys pqu yks"). It does not cover critical analysis, creative writing, or speaking/listening skills (addressed in nodes 013–015).

## WALKTHROUGH
Imagine you are reading a WhatsApp forward about a new traffic rule. A literal question — "What is the fine amount?" — lets you point to a specific line. An inferential question — "Why will people follow this rule?" — forces you to connect the fine amount, the mention of cameras, and the quote from the commissioner to deduce the answer. Start by reading the question carefully and underlining keywords. Scan the text for those keywords: if the answer sits in one sentence, it is literal. If you must combine details from two different paragraphs, consider character motives, or interpret a metaphor, it is inferential. The key insight: every inferential answer must be anchored in textual evidence, never in personal opinion alone.

## DIAGNOSTIC_QUESTION_1
What is the fundamental difference between a literal comprehension question and an inferential comprehension question?

## DIAGNOSTIC_ANSWER_1
A literal question has its answer explicitly written in the text (e.g., "What did the teacher ask the boy?"). An inferential question requires the reader to deduce the answer by combining clues from the text (e.g., "Why did the teacher ask those specific questions?"). A wrong answer that treats an inferential question as literal — quoting a single line without explanation — reveals the student cannot distinguish between stated facts and implied meaning, leading to incomplete answers in board exams.

## DIAGNOSTIC_QUESTION_2
In "ckyd cp x;k", the narrator describes the teacher's questions in great detail (history dates, geography facts, names of kings). What is the author's purpose in listing these specific questions rather than simply saying "the teacher asked many questions"?

## DIAGNOSTIC_ANSWER_2
The detailed list illustrates the rote, mechanical nature of colonial education — facts disconnected from the child's life — and contrasts sharply with the boy's spontaneous, creative response ("yaw"). A wrong answer that merely summarizes the questions ("He asked about dates and kings") misses the author's critique of the education system and treats a literary device as mere plot detail.

## DIAGNOSTIC_QUESTION_3
Read this new paragraph: "The farmer stood at the edge of his field, eyes fixed on the western sky. The monsoon was two weeks late. His cotton seedlings, barely a finger high, curled in the dry heat." Write one literal question and one inferential question that could be asked about this paragraph.

## DIAGNOSTIC_ANSWER_3
Literal: "What crop is the farmer growing?" (Answer: cotton — explicitly stated). Inferential: "Why is the farmer anxious?" (Requires connecting late monsoon + dry heat + delicate seedlings → fear of crop failure). A wrong answer that makes both questions literal (e.g., "How high are the seedlings?") shows the student cannot frame questions that demand deduction.

## DIAGNOSTIC_QUESTION_4
Compare the father's reaction in "ckyd cp x;k" when the boy says "yaw" with the adults' reaction in "?kM+h osQ iq”ksZ" when children ask about history. What does this comparison reveal about the author's view of authority figures?

## DIAGNOSTIC_ANSWER_4
Both scenes show authority figures (father, teacher, specialists) dismissing or misunderstanding a child's natural curiosity — the father is embarrassed by the "wrong" answer; the specialists claim history is not for children. This reveals Premchand's consistent critique: institutional authority prioritizes conformity over genuine learning. A wrong answer that treats the two scenes as unrelated fails to synthesize across stories, a key Class 12 skill.

## DIAGNOSTIC_QUESTION_5
The narrator in "?kM+h osQ iq”ksZ" argues: "Knowing history is the job of specialists." Do you agree with this statement? Justify your position using evidence from the text and your own reasoning.

## DIAGNOSTIC_ANSWER_5
The text presents this view only to dismantle it — the narrator counters that when specialists monopolize history, ordinary people lose their connection to the past and become vulnerable to manipulation. A strong answer takes a clear stance (agree/disagree) and cites the watchmaker metaphor or the call to "observe with your own eyes." A wrong answer that simply repeats the specialist's view without critique shows inability to evaluate an argument, a core competency for board and CUET.

## DIAGNOSTIC_QUESTION_6
Write a 4-line dialogue between the boy from "ckyd cp x;k" and the narrator from "?kM+h osQ iq”ksZ" where they discuss what adults fail to understand about children.

## DIAGNOSTIC_ANSWER_6
Boy: "They ask what I'll become, but never who I am."
Narrator: "They lock history in books, so we never touch our roots."
Boy: "My 'yaw' was not an answer — it was a scream."
Narrator: "And our questions? They call them nuisance."
A poor answer would have both characters agree politely, missing the distinct voices (one frightened, one indignant) and the textual evidence each represents.

## COMMON_MISCONCEPTION
Students treat inferential questions as "opinion questions" with no right answer. In "?kM+h osQ iq”ksZ", when asked why the author criticizes the specialists, a student writes "Because adults are mean" instead of citing the text: "The author argues that monopolizing history cuts people off from their past, making them easy to manipulate." This error stems from confusing personal reaction with text-based deduction. Board examiners deduct marks for unsupported opinions; JEE/NEET comprehension passages penalize answers not grounded in the passage.

## ON_FAILURE
If a student cannot separate literal from inferential:
1. Give them a 5-sentence paragraph and ask them to highlight every sentence that directly answers a specific literal question.
2. Then ask: "What is suggested but not said?" — have them write one inference and underline the two sentences that support it.
3. Practice with 5 textbook questions: label each L or I, then for every I, write the PEEL structure (Point, Evidence, Explanation, Link).
4. Revisit node c12_hin_a_cbse_11_008 (Imagery and Metaphor) to see how figurative language creates inference.

## BUILDS_ON
This node builds on the student's thorough knowledge of plot, characters, themes, and literary devices of the three stories (covered in nodes 001–011).

## LEADS_TO
This node enables critical thinking and interpretation (node 013) where students analyze deeper meanings, and writing skills (node 014) where they compose structured analytical answers.

## PREREQUISITE_NODE_IDS
c12_hin_a_cbse_11_001, c12_hin_a_cbse_11_002, c12_hin_a_cbse_11_003, c12_hin_a_cbse_11_004, c12_hin_a_cbse_11_005, c12_hin_a_cbse_11_006, c12_hin_a_cbse_11_007, c12_hin_a_cbse_11_008, c12_hin_a_cbse_11_009, c12_hin_a_cbse_11_010, c12_hin_a_cbse_11_011, c11_hin_ar_cbse_11_012

## PREREQUISITE_REASONS
c12_hin_a_cbse_11_001: Context/background needed to understand historical setting of stories.
c12_hin_a_cbse_11_002: Plot knowledge allows locating events for literal answers.
c12_hin_a_cbse_11_003: Setting/atmosphere informs mood-based inferences.
c12_hin_a_cbse_11_004: Protagonist analysis aids inferring motives.
c12_hin_a_cbse_11_005: Supporting characters provide clues for inference.
c12_hin_a_cbse_11_006: Primary theme guides thematic inferences.
c12_hin_a_cbse_11_007: Secondary themes add layers for inferential depth.
c12_hin_a_cbse_11_008: Imagery/metaphor require inferential interpretation.
c12_hin_a_cbse_11_009: Irony/symbolism are key to inferential answers.
c12_hin_a_cbse_11_010: Vocabulary clarifies literal meaning of key terms.
c12_hin_a_cbse_11_011: Grammar usage helps parse complex sentences literally.
c11_hin_ar_cbse_11_012: Class 11 Antra comprehension skills are direct foundation.
## FORWARD_NODE_IDS
c12_hin_a_cbse_11_013, c12_hin_a_cbse_11_014, c12_hin_a_cbse_11_015
## FORWARD_REASONS
c12_hin_a_cbse_11_013: Critical thinking requires inferential skills to analyze/interpret.
c12_hin_a_cbse_11_014: Writing skills need comprehension to base answers on text.
c12_hin_a_cbse_11_015: Speaking/listening discussions rely on text comprehension.

## CROSS_SUBJECT_PREREQS
c11_hin_ar_cbse_11_012

## CROSS_SUBJECT_REASONS
c11_hin_ar_cbse_11_012: Class 11 Antra comprehension node builds same skill in different text.
c11_hin_v_cbse_11_012: Class 11 Vitan comprehension node provides additional practice.

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_11_012 -> c12_hin_a_cbse_11_012 -> c12_hin_a_cbse_11_013

## THIS_FORMULA
N/A - conceptual

## FORMULA_VARIABLES
N/A

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
linguistic

## CROSS_SUBJECT
N/A | Historical sources require literal reading of inscriptions and inferential understanding of social structures.
 N/A | Case studies need literal data extraction and inferential policy implications.
## PREREQ_CONCEPT
Ability to distinguish explicitly stated information from implied meaning in a text.

## PREREQ_BEFORE
Student must have read and understood all three stories in Chapter 11.

## PREREQ_STUCK
If stuck, review story summaries and character sketches from nodes 002, 004, 005.

## WORKED_EXAMPLE_1
PROBLEM: Answer the inferential question: "Why does the boy in 'ckyd cp x;k' say 'yaw' when asked what he wants to become?" using textual evidence.

STEPS:
- Step 1: Locate the scene — the teacher asks the boy his ambition; the father watches anxiously.
- Step 2: Identify literal details: the boy is frightened ("brus le; rd esjk 'okl ?kqV jgk Fkk"), the father's pride ("firk dk ân; mYykl ls Hkj jgk Fkk"), the teacher's expectation.
- Step 3: Note the boy's internal state — he is a child put on the spot, not thinking of career.
- Step 4: Infer that "yaw" is a spontaneous, meaningless utterance born of pressure, not a genuine ambition.
- Step 5: Connect to theme — the education system forces children into premature, performative decisions.

REASONING: The answer is not directly stated; we combine the boy's fear, the father's pride, and the author's critique of rote learning to infer the reason. This mirrors board exam "explain with reference to context" questions.

ANSWER: The boy says "yaw" because he is overwhelmed by adult expectations and utters a word without understanding, reflecting the story's critique of imposing adult ambitions on children.

## WORKED_EXAMPLE_2
PROBLEM: Classify each textbook question as Literal (L) or Inferential (I):
1. "ckyd ls mldh mez vkSj ;ksX;rk ls mQij osQ dkSu&dkSu ls iz'u iwNs x,\"
2. "ckyd us D;ksa dgk fd eSa ;koTtUe yksdlsok d:¡ xk\"
3. "èkeZ dk jgL; tkuuk osn'kkL=kK èkekZpk;ks± dk gh dke gSA vki bl dFku ls dgk¡ rd lger gSa\"

STEPS:
- Step 1: Q1 asks for a list of questions explicitly listed in the text → Literal.
- Step 2: Q2 asks "why" — the boy's motive (fear, desire to escape) must be deduced from his internal monologue → Inferential.
- Step 3: Q3 asks for evaluation of a view presented in the text — requires synthesizing author's counter-arguments → Inferential.
- Step 4: Verify by checking if a single sentence contains the answer (L) or if multiple paragraphs + reasoning needed (I).
- Step 5: Label accordingly.

REASONING: Board exams often mix L and I questions; classification speed saves time and ensures correct answer depth.

ANSWER: 1-L, 2-I, 3-I.

## WORKED_EXAMPLE_3
PROBLEM: Write a structured PEEL answer for: "In '<sys pqu yks', why does the author describe the various types of soils (e^h) in such detail?"

STEPS:
- Step 1 (Point): The detailed soil catalogue symbolizes the diversity of human lives and the universality of death.
- Step 2 (Evidence): Text lists soils from osfn, xkS'kkyk, [ksr, pkSjkgs, elku — each with distinct origin — then states all end in the same ground.
- Step 3 (Explanation): Each soil represents a different social path (farmer, warrior, king, merchant), but they merge, erasing hierarchy.
- Step 4 (Link): This supports the story's theme: social distinctions are temporary; death is the great equalizer.
- Step 5 (Conclude): Thus, the detail is thematic, not merely descriptive.

REASONING: PEEL ensures the answer is analytical (required for 3-4 mark board questions) rather than descriptive.

ANSWER: The author describes various soils to symbolize how diverse human lives — regardless of origin, status, or wealth — ultimately meet the same end. By listing soils from a farmer's field, a warrior's battlefield, a king's palace, and a merchant's shop, the text shows that social hierarchy vanishes in death. This reinforces the story's central message: pride in temporary distinctions is futile.

## COMPETENCY_QUESTION_1
QUESTION: Read this excerpt: "The old man stared at the broken watch. He had promised his grandson to fix it before the festival. Now, with trembling hands, he picked up the tiny screwdriver." Write one literal and one inferential question based on this excerpt. Explain why each is classified so.

COMPETENCY: Classification and justification of question types (CBSE competency: analysis).

STEPS:
- Step 1: List explicit facts: old man, broken watch, promise to grandson, festival, trembling hands, screwdriver.
- Step 2: Form a literal question using one explicit fact.
- Step 3: Identify implied information: old age, anxiety, urgency, possible failure, emotional weight of promise.
- Step 4: Form an inferential question using implied information.
- Step 5: Justify classification by referencing explicit vs. implied.

ANSWER: Literal: "What tool did the old man pick up?" (Directly stated: screwdriver). Inferential: "Why are the old man's hands trembling?" (Not stated — could be age, anxiety, cold, or all three; requires deduction). DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: The textbook asks: "èkeZ vxj oqQN fo'ks"k yksxksa osn'kkL=kK èkekZpk;ks±] eBkèkh'kksa] iaMs&iqtkfj;ksa dh eq_h esa gS rks vke vkneh vkSj lekt dk mlls D;k lacaèk gksxk\ viuh jk; fyf[k,A" Answer this inferential question in 80-100 words, using evidence from "?kM+h osQ iq”ksZ" and connecting to the author's broader message.

COMPETENCY: Text-based inferential reasoning with thematic connection (CBSE competency: critical thinking; CUET style).

STEPS:
- Step 1: Recall the text's argument — if history is left to specialists, common people lose connection with their past.
- Step 2: Identify consequences: loss of identity, vulnerability to manipulation, erosion of critical thinking.
- Step 3: Select evidence: the watchmaker metaphor ("specialist knows the watch, not the time"), the call to "observe with your own eyes," the rhetorical questions challenging the specialist's monopoly.
- Step 4: Synthesize into a PEEL paragraph.
- Step 5: Check word count and clarity.

ANSWER: If history remains confined to specialists, the common person loses their anchor in time. The text warns that a specialist knows the mechanism of the watch but not the time it shows — similarly, experts may know facts but not the lived meaning of history. This disconnect makes society susceptible to distorted narratives propagated by those in power (eBkèkh'k, iaMs&iqtkfj;k). The author urges every individual to "see with their own eyes" and "listen with their own ears," implying that historical consciousness is essential for a thinking, resistant citizenry. Without it, the relationship between the individual and society becomes passive obedience rather than informed participation. DIFFICULTY: hard