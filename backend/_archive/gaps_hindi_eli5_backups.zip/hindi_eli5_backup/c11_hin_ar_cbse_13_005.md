## DEFINITION
Supporting characters in a poem are secondary figures or groups who interact with the central situation, revealing thematic tensions through their actions, attitudes, or symbolic function rather than through individual development. In "lk;s esa /wi," they represent collective social roles (pallbearers, relatives, onlookers) that contrast with the speaker's internal consciousness.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
Student can identify at least two distinct supporting groups in the poem, cite specific textual evidence (verbs, metaphors, contrasts) for their attitudes, and explain how each group's portrayal advances the poem's critique of mechanical ritual versus authentic grief.

## SCOPE_BOUNDARY
Covers analysis of supporting characters/groups exclusively in Nagarjun's poem "lk;s esa /wi" (Chapter 13). Does not cover protagonist analysis (Node 004), theme articulation (Nodes 006-007), or literary devices in isolation (Nodes 008-009).

## WALKTHROUGH
Imagine you are standing at a busy Indian cremation ground watching a funeral procession pass. You notice three distinct groups: the hired pallbearers chatting about lunch, the immediate family performing loud grief, and the curious bystanders checking phones. The poem "lk;s esa /wi" freezes this exact scene. To analyze supporting characters here, don't look for names or dialogues—look for **collective verbs** (what the group does), **spatial positioning** (where they stand relative to the body), and **contrast markers** (words like "vkSj" or "ysfdu" that set groups against each other). Start by listing every plural subject or implied group in each stanza. Then ask: "What does this group's behavior reveal about society's relationship with death?" The key insight: supporting characters in this poem are not people but **social functions**—they embody the gap between ritual performance and human feeling.

## DIAGNOSTIC_QUESTION_1
List the three distinct supporting groups explicitly or implicitly presented across the three stanzas of the poem.

## DIAGNOSTIC_ANSWER_1
The three groups are: (1) The pallbearers/procession carriers (Stanza 1: implied by "fpjkxk¡ gjsoQ ?kj osQ fy,"), (2) The dead person's relatives/mourners (Stanza 2: "cxhps"), and (3) The generalized world/society or onlookers (Stanza 3: "cgj"). A wrong answer that lists only "people" or "crowd" reveals the student cannot distinguish functional groups in a collective scene—a senior-secondary error where students treat all background figures as an undifferentiated mass rather than analyzing distinct social roles.

## DIAGNOSTIC_QUESTION_2
Explain in your own words the difference between the grief of the "cxhps" (relatives) in Stanza 2 and the grief of the speaker ("eSa").

## DIAGNOSTIC_ANSWER_2
The relatives' grief is described as "xqyeksgj osQ rys" (a heap/pile of sorrow)—external, accumulated, performative, and spatially located in their laps. The speaker's grief is "xSj dh xfy;ksa esa" (in the corners of the heart)—internal, hidden, residual, and spatially metaphorical. A wrong answer equating both as "sadness" reveals the student misses the poem's central contrast: performed/public ritual vs. authentic/private feeling. This is a Class 11-specific error where students ignore spatial metaphors ("rys" vs "xfy;k") that encode the thematic tension.

## DIAGNOSTIC_QUESTION_3
The word "fpjkx" appears twice in Stanza 1 with different case endings ("fpjkxk¡" and "fpjkx"). Apply your knowledge of Hindi grammar and poetic ambiguity to explain how this double usage characterizes the pallbearers' attitude toward the dead body.

## DIAGNOSTIC_ANSWER_3
First "fpjkxk¡" (nominative plural?/direct case) treats the body as an active agent being taken somewhere ("fpjkxk¡ gjsoQ ?kj osQ fy,"). Second "fpjkx" (oblique?/object) treats it as passive cargo ("fpjkx e;Llj ugha 'kgj osQ fy,"). The shift from subject to object mirrors the pallbearers' view: initially a person with a destination, ultimately a burden without agency. A wrong answer focusing only on dictionary meaning ("dead body") reveals inability to track grammatical shifts as characterization—a skill required for board-level poetic analysis.

## DIAGNOSTIC_QUESTION_4
Analyze how the spatial arrangement of the three supporting groups across the stanzas (procession → relatives → world) creates a structural movement from physical proximity to metaphysical distance.

## DIAGNOSTIC_ANSWER_4
Stanza 1: Pallbearers are physically touching the body ("gjsoQ ?kj osQ fy,"). Stanza 2: Relatives are adjacent ("cxhps esa") but emotionally performative. Stanza 3: "cgj" (world) is abstract, ruled by "fu”kke" (death/time), with the body reduced to harvest ("fly"). The movement is: intimate labor → familial performance → cosmic indifference. A wrong answer listing groups without spatial verbs ("gjsoQ", "esa", "fy,") reveals the student reads stanzas as isolated pictures rather than a deliberate spatial argument—a key board exam analytical skill.

## DIAGNOSTIC_QUESTION_5
Evaluate whether the poet portrays the supporting characters with sympathy, irony, or condemnation. Defend your judgment using two specific textual markers.

## DIAGNOSTIC_ANSWER_5
The portrayal is **ironic detachment**, not sympathy or condemnation. Evidence: (1) "u gks deh”k rks ik¡oksa ls isV <¡d ysaxs" (if not a funeral pyre, they'd pull grass for a living)—pallbearers' labor is economically interchangeable, stripping ritual sanctity with flat factuality. (2) "os eqrebu gSa fd iRFkj fi?ky ugha ldrk" (they are helpless, cannot face the truth)—relatives are "eqrebu" (helpless), not hypocritical; the poet pities their entrapment in social forms. A wrong answer claiming "criticism of hypocrites" reveals the student imposes moral judgment where the poem offers sociological observation—a common Class 11 error when students confuse irony with satire.

## DIAGNOSTIC_QUESTION_6
Create a 4-line Hindi couplet (dohe style) from the perspective of a pallbearer who has carried hundreds of "fpjkx," revealing his inner thought that contrasts with his outward action.

## DIAGNOSTIC_ANSWER_6
Example: "bohq gya fpjkx, koi na puchhe naam / kaam hai yahi mera, mile do waqt ka kaam." (Carried hundreds of bodies, none ask the name / This is my work, just get two meals a day.) A poor answer writes a generic sad poem about death, revealing the student cannot adopt a supporting character's *specific* voice shaped by economic compulsion and routine—they default to universal grief, missing the poem's class-conscious characterization.

## COMMON_MISCONCEPTION
Students believe supporting characters in a poem must have names, dialogues, or individual traits. In "lk;s esa /wi," the supporting characters are **collective social types** (pallbearers, relatives, world) defined solely by their functional relationship to the dead body. Students write "the poem has no supporting characters" because they look for *persons* instead of *roles*. This error stems from applying prose fiction expectations (named characters) to lyric poetry where characterization occurs through **syntactic positioning** (subject/object), **metaphoric labels** ("xqyeksgj osQ rys"), and **structural contrast** (stanza-by-stanza shifting focus). The specific Class 11 error: treating "cxhps" as individuals with psychology rather than as a social unit performing grief.

## ON_FAILURE
1. **Re-read Stanza 1 only**: Underline every verb/action associated with the body ("gjsoQ", "yxrh", "pysa", "Hkj"). Ask: "Who does these actions? What single noun covers all doers?" → Pallbearers as laborers.
2. **Make a 3-column table**: Column A: Stanza number. Column B: Collective noun/pronoun (explicit or implied). Column C: Key metaphor describing them ("xqyeksgj osQ rys", "eqrebu", "fly"). Fill it without interpreting—just extract.
3. **Compare Column C entries**: "rys" (heap) vs "xfy;k" (corner) vs "fly" (harvest). Ask: "Which is heaviest? Which is most dehumanizing?" This forces the student to see supporting characters as **metaphoric constructs** not people.
4. **Write one sentence per group** using the formula: "The [group] represents [social function] through the metaphor of [textual phrase]."

## BUILDS_ON
Character Analysis: Protagonist (c11_hin_ar_cbse_13_004) where students learned to track the speaker's internal consciousness ("eSa").

## LEADS_TO
Theme: Primary Theme and Message (c11_hin_ar_cbse_13_006) where the supporting characters' mechanical rituals become evidence for the theme "ritual vs. authenticity."

## PREREQUISITE_NODE_IDS
c11_hin_ar_cbse_13_004, c11_hin_ar_cbse_13_002, c11_hin_ar_cbse_13_003, c11_hin_ar_cbse_13_001

## PREREQUISITE_REASONS
c11_hin_ar_cbse_13_004: Establishes the protagonist (speaker) as the consciousness against which supporting groups are contrasted.
c11_hin_ar_cbse_13_002: Provides the narrative sequence (procession → cremation → aftermath) that structures the three supporting groups' appearances.
c11_hin_ar_cbse_13_003: Establishes the cremation ground atmosphere that makes the supporting characters' behaviors socially determined.
c11_hin_ar_cbse_13_001: "Before You Read: की समझ आवश्यक है, क्योंकि यह नोड (Supporting characters in a poem are secondary figures or groups who interact with the cent...) इसी आधार पर आगे बढ़ता है।  

## FORWARD_NODE_IDS
c11_hin_ar_cbse_13_006, c11_hin_ar_cbse_13_013, c11_hin_ar_cbse_13_007, c12_hin_a_cbse_13_005, c12_hin_ar_cbse_06_005, c12_hin_ar_cbse_13_005

## FORWARD_REASONS
c11_hin_ar_cbse_13_006: The supporting characters' mechanical rituals (pallbearers' labor, relatives' performed grief) constitute the primary textual evidence for the theme "death as social ritual vs. personal loss."
c11_hin_ar_cbse_13_013: Critical thinking requires synthesizing character analysis with structural analysis—e.g., how the three-stanza structure mirrors the three groups' distancing from the body.
c11_hin_ar_cbse_13_007: The judge, ruler, and silent crowd function as thematic foils — their characterization *embodies* hypocrisy and power.  
c12_hin_a_cbse_13_005: Class 11 supporting‑character practice establishes the habit of distinguishing major vs. minor roles and using textual citations.  
c12_hin_ar_cbse_06_005: Class 11 foundation on supporting character analysis in Aroh.  
c12_hin_ar_cbse_13_005: Class 11 node establishes the framework for functional character analysis (traits, evidence, narrative role).  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
None from prior class nodes, but cross-subject links are created below.

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_13_004 -> c11_hin_ar_cbse_13_005 -> c11_hin_ar_cbse_13_006

## THIS_FORMULA
N/A - conceptual

## FORMULA_VARIABLES
N/A

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
analytical

## CROSS_SUBJECT
c11_sociology_social_structure | The poem's three supporting groups (laborers, family, state/world) map directly to sociological categories: informal labor, kinship performativity, and institutional power—each treating death as a functional event rather than human loss.
c11_psychology_group_behavior | The relatives' "xqyeksgj osQ rys" (heap of sorrow) illustrates collective emotional contagion and performative grief, contrasting with the speaker's private mourning—key concepts in social psychology of ritual.

## PREREQ_CONCEPT
Ability to distinguish between *individuated character* (prose fiction) and *typified social role* (lyric poetry/satire).

## PREREQ_BEFORE
Student must recognize that in Nagarjun's poetry, "character" = "social function expressed through metaphor," not psychological interiority.

## PREREQ_STUCK
Review Node 004 (Protagonist Analysis) to re-establish the speaker's voice, then re-read the poem asking "Who is *not* the speaker in each stanza?"

## WORKED_EXAMPLE_1
PROBLEM: Analyze how the pallbearers (implied in Stanza 1) function as a supporting character group representing the commodification of death rituals.
STEPS:
- Step 1: Identify the grammatical subject of actions in Stanza 1. The verbs "gjsoQ" (take), "yxrh" (rests), "pysa" (go), "Hkj" (fill) lack an explicit human subject. The implied agent is the collective "they" carrying "fpjkx."
- Step 2: Note the economic metaphor in Line 3: "u gks deh”k rks ik¡oksa ls isV <¡d ysaxs" (if not a pyre, they'd pull grass for fodder). The conditional "u gks... rks" equates funeral labor with agricultural labor—both are wage work.
- Step 3: Analyze "dksbZ glhu u”kkjk rks gS u”kj osQ fy," (some helpless compulsion exists for livelihood). "glhu" (greedy/desperate) and "u”kj" (livelihood) frame the pallbearers as economically coerced, not ritually devoted.
- Step 4: Contrast with the body's description: "fpjkx e;Llj ugha 'kgj osQ fy," (the body is not alone, for the world). The pallbearers deliver the body to the world; their role is logistical, not emotional.
- Step 5: Synthesize: The pallbearers embody the poem's thesis—death rituals have become a service economy. Their characterization relies entirely on **absence of feeling words** and **presence of economic compulsion words**.
REASONING: This 5-step method moves from grammatical reconstruction (Step 1) to lexical semantics (Step 2-3) to structural contrast (Step 4) to thematic synthesis (Step 5)—the exact analytical ladder board exams reward.
ANSWER: The pallbearers are characterized as wage laborers for whom the dead body is cargo. Key evidence: the conditional economic metaphor (pyre/grass equivalence), the word "u”kj" (livelihood), and the total absence of grief vocabulary. They represent society's outsourcing of death's physical reality.

## WORKED_EXAMPLE_2
PROBLEM: Explain how the relatives ("cxhps") in Stanza 2 function as a supporting group that performs grief rather than feels it, using the metaphor "xqyeksgj osQ rys."
STEPS:
- Step 1: Locate the explicit reference: "ft,¡ rks vius cxhps esa xqyeksgj osQ rys" (there, in their relatives, a heap of sorrow).
- Step 2: Deconstruct the metaphor: "rys" = heap/pile (noun), "xqyeksgj" = of sorrow (genitive). A heap is external, visible, measurable, and *constructed* by adding pieces—unlike a wound or ache.
- Step 3: Contrast spatial prepositions: relatives have sorrow "esa" (in/inside them) but as a "rys" (heap) suggesting it sits *on* them like a garment. The speaker has sorrow "xfy;ksa esa" (in corners)—fragmented, hidden, architectural.
- Step 4: Note the verb absence: relatives *are not described doing anything* with this heap. They don't weep, speak, or touch. The heap simply "is." This stasis = performance.
- Step 5: Connect to Stanza 1's movement: pallbearers *act* (verbs), relatives *contain* (static metaphor). The poem critiques both: action without feeling, feeling without action.
REASONING: Steps 2-3 demonstrate the senior-secondary skill of **metaphor archaeology**—excavating how a single noun's spatial logic ("rys" vs "xfy;k") encodes the character's thematic function. Step 4's verb-check is a transferable technique for any lyric poem.
ANSWER: The relatives are a static monument to performed grief. "xqyeksgj osQ rys" depicts sorrow as an external accumulation (social expectation) rather than internal experience. Their characterization is entirely metaphoric—no verbs, no agency—making them symbols of ritualized mourning.

## WORKED_EXAMPLE_3
PROBLEM: The final stanza introduces "cgj" (world) and "fu”kke" (ruler) as abstract supporting characters. Analyze how they complete the poem's tripartite social critique: labor → family → state/cosmos.
STEPS:
- Step 1: Identify the new collective entities: "fu”kke" (ruler/king/death personified) and "cgj" (world/society). Note "fu”kke" is singular but functions as a collective force.
- Step 2: Decode the metaphor: "rsjk fu”kke gS fly ns ”kqcku 'kk;j dh" (their ruler is the sharp sickle of the harvest). "fly" = harvest, "kqcku 'kk;j" = sharp sickle. Death = harvester; world = crop.
- Step 3: Analyze "cgj" as a supporting character: it is passive ("gfr;kr" = harvested/ripe crop), ruled, and silent. Unlike pallbearers (active) and relatives (static), "cgj" is *victim* of the same system.
- Step 4: Trace the pronoun chain: Stanza 1 "os" (they=pallbearers) → Stanza 2 "ft,¡" (there/relatives) → Stanza 3 "rsjk" (their=world's) and "bl cgj" (this world). The possessive "rsjk" links the world to the pallbearers/relatives—they *are* the world.
- Step 5: Evaluate the final judgment: ";s ,gfr;kr ”k:jh gS bl cgj osQ fy," (this is the harvest/festival of this world). "gfr;kr" = harvest festival (positive) but context = death (negative). Irony: the world celebrates its own consumption.
- Step 6: Synthesize the trilogy: Pallbearers (labor) enable the harvest; Relatives (family) ritualize it; World (cosmos) consumes it. All three are "supporting characters" to the central absurdity: death as social production.
REASONING: This 6-step analysis demonstrates the highest board-level competency: **tracking a conceptual argument across structural units** (stanzas as social sectors) while maintaining **metaphoric consistency** (harvest imagery). Step 4's pronoun-chain tracking is a specific linguistic technique for lyric poetry.
ANSWER: "cgj" and "fu”kke" are not background but the poem's ultimate supporting characters—the systemic frame that makes the pallbearers' labor and relatives' performance inevitable. The harvest metaphor ("fly", "kqcku 'kk;j", "gfr;kr") unifies all three groups as participants in a death-economy where even grief is a crop.

## COMPETENCY_QUESTION_1
QUESTION: The poem presents three supporting groups (pallbearers, relatives, world) but never uses a single proper noun or individual descriptor for any of them. Explain how this *absence of individuation* is itself a characterization technique that serves the poem's theme. Use evidence from at least two stanzas.
COMPETENCY: Analytical reasoning - connecting formal choices to thematic meaning
STEPS:
- Step 1: State the observation: zero proper nouns, zero individual markers (age, gender, name, unique trait) for any supporting figure.
- Step 2: Identify the collective grammatical forms used instead: plural verbs (Stanza 1), collective nouns "cxhps"/"cgj" (Stanzas 2-3), possessive pronouns "vius"/"rsjk".
- Step 3: Argue the effect: this erasure of individuality *is* the characterization—it shows a society where death reduces humans to functional categories (laborer, kin, subject).
- Step 4: Provide evidence: Stanza 1's "os" (they) for pallbearers; Stanza 3's "cgj" (world) as a monolith. Both deny interiority.
- Step 5: Conclude: the poem enacts its critique formally—by refusing to individuate the supporting characters, it mirrors a world that refuses to see them as persons.
ANSWER: The absence of individuation is the central characterization strategy. By denying names, unique voices, or private grief to pallbearers ("os"), relatives ("cxhps" as a category), and world ("cgj"), the poem makes them emblems of social roles. Stanza 1's faceless "os" who "Hkj mez" (fill the pyre) and Stanza 3's abstract "cgj" harvested by death's sickle represent a system where humans are replaceable parts. This formal choice performs the theme: ritual without humanity.
DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: A student claims: "The relatives in Stanza 2 are the most sympathetic supporting characters because they at least feel sorrow ('xqyeksgj'), unlike the indifferent pallbearers." Critique this interpretation using the poem's metaphoric logic and the speaker's positioning.
COMPETENCY: Evaluative judgment - critiquing an interpretation using textual evidence
STEPS:
- Step 1: Acknowledge the surface plausibility: "xqyeksgj" (sorrow) appears only with relatives.
- Step 2: Challenge via metaphor analysis: "rys" (heap) implies constructed, external, performative accumulation—not organic feeling.
- Step 3: Challenge via contrast: Speaker's sorrow is "xSj dh xfy;ksa esa" (in heart's corners)—internal, residual, authentic. The spatial opposition (heap vs corners) marks relatives' sorrow as *social performance*.
- Step 4: Challenge via agency: Relatives have *zero verbs*. They don't "feel"—they *contain* a heap. Pallbearers at least *act* (verbs: carry, fill). Passive containment < mechanical action in this poem's value system.
- Step 5: Synthesize: The poem offers no "sympathetic" supporting characters—only degrees of entrapment. Relatives are trapped in *performance*, pallbearers in *labor*, world in *consumption*. Sympathy is the speaker's (and reader's) task, not the poem's gift.
ANSWER: The interpretation fails because it reads "xqyeksgj" (sorrow) literally while ignoring its metaphoric container "rys" (heap). A heap is built, not felt. The relatives' sorrow is a social deposit, not a psychological state—evidenced by their total verbal passivity versus the speaker's internalized "xfy;ksa esa." The poem's logic: all supporting characters are *complicit* in the ritual machine; sympathy belongs only to the observing consciousness that sees through it.
DIFFICULTY: hard