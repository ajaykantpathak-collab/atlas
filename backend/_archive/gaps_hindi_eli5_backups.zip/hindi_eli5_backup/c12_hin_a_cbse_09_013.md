## DEFINITION
Critical Thinking: Analysis and Interpretation in Hindi literature is the systematic process of examining a text's deeper layers — themes, symbols, structure, language choices, and socio-cultural context — to construct an evidence-based interpretation that goes beyond literal comprehension, evaluating how the author's craft shapes meaning and connects to universal human experiences.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student can independently deconstruct a Kabir poem by identifying its central metaphor, tracing how linguistic choices (Braj/Awadhi vocabulary, rhythmic patterns) reinforce the theme, and articulating a coherent interpretation supported by textual evidence, while acknowledging alternative readings and the poem's historical context in the Bhakti movement.

## SCOPE_BOUNDARY
This node covers critical analysis of Kabir's two poems in Chapter 9 ("Kukuan") — focusing on metaphorical interpretation, Bhakti philosophy connections, linguistic analysis of Braj/Awadhi features, and structured answer writing for board exams. It does NOT cover detailed biography of Kabir, comparative analysis with other Bhakti poets, or comprehensive history of the Bhakti movement (those belong to history/civics cross-links).

## WALKTHROUGH
Imagine you're sitting in the CBSE board exam and see a 5-mark question: "Kabir's poetry uses simple metaphors to convey profound spiritual truths. Analyze with reference to the prescribed poems." Your mind goes blank — you remember the poems but don't know how to *structure* an analysis that earns full marks. Start by asking: "What is the ONE central tension in each poem?" In Poem 1, it's the guru-disciple relationship as a metaphor for divine grace; in Poem 2, it's the futility of ritual without inner transformation. Next, hunt for *craft evidence* — the repeated "lqtku" (disciple) in Poem 1, the contrast between "owQdHkjh" (ritual offering) and "cqyk;" (hollow) in Poem 2. Then ask: "How does the *sound* of the Braj/Awadhi language (rhythm, alliteration) mirror the meaning?" Finally, connect to Bhakti philosophy: nirguna bhakti, rejection of ritual, guru as mediator. The key insight: analysis isn't guessing — it's a repeatable method: **Identify Tension → Find Craft Evidence → Explain Effect → Connect to Context → Synthesize Interpretation.**

## DIAGNOSTIC_QUESTION_1
What is the primary difference between *literal comprehension* (understanding what happens in the poem) and *critical interpretation* (analyzing what the poem means)? Give one example from Kabir's first poem in Chapter 9.

## DIAGNOSTIC_ANSWER_1
Literal comprehension states: "The poet says he was a weaver, his guru's name was Ramanand, and he uses his guru's name in poems." Critical interpretation explains: "Kabir identifies as a weaver (low caste) to assert that spiritual authority comes from guru's grace, not birth; invoking 'Ramanand' in verses legitimizes his voice in a caste-rigid society." A wrong answer that only retells the poem's surface narrative reveals the student conflates summary with analysis — a Board exam error that caps marks at 1-2/5 for "knowledge" without "analysis."

## DIAGNOSTIC_QUESTION_2
In Kabir's first poem, the line "pkgr pyu ;s lanslks ys lqtku dks" uses the metaphor of a garment. Explain *why* Kabir chooses "garment" (lanslks) rather than "armor," "jewel," or "rope" — what specific quality of the guru-disciple relationship does "garment" capture that the others miss?

## DIAGNOSTIC_ANSWER_2
"Garment" (lanslks) captures *intimacy, constant contact, and identity-formation* — a garment touches the skin, is worn daily, and shapes how the world sees you. "Armor" implies conflict/defense; "jewel" implies ornamentation/status; "rope" implies binding/constraint. The guru's name as *garment* means the disciple's very identity is clothed in the guru's grace — inseparable, protective, defining. A wrong answer listing synonyms without explaining the *specific connotative gap* reveals the student treats metaphors as decorative rather than meaning-bearing — a fatal error in JEE-style literary analysis questions that test "author's craft."

## DIAGNOSTIC_QUESTION_3
Apply the "Tension → Craft → Effect → Context → Synthesis" method to analyze the second poem's opening: "vkukdkuh vkjlh fugkfjcks djkSxs dkSykSa \ dgk eks pfdr nlk R;ksa u nhfB MksfygS \". Identify the central tension, one craft choice (diction/syntax/sound), its effect, and the Bhakti context it invokes.

## DIAGNOSTIC_ANSWER_3
**Tension:** Ritual performance (vkukdkuh vkjlh — elaborate worship) vs. divine indifference (pfdr nlk R;ksa u nhfB — God doesn't accept). **Craft:** Rhetorical question ("djkSxs dkSykSa") + colloquial Braj ("vkukdkuh," "MksfygS") — creates conversational urgency, not liturgical formality. **Effect:** Undermines priestly authority; positions Kabir as direct questioner. **Context:** Nirguna Bhakti rejection of saguna ritual (idol worship, priestly mediation). **Synthesis:** The poem enacts its argument — its *form* (direct address, vernacular) performs the *content* (bypassing ritual). A wrong answer that only translates lines misses the *performative* dimension — Board examiners look for "how the poem does what it says."

## DIAGNOSTIC_QUESTION_4
Compare the role of "sound patterning" (anunāśik, alliteration, rhythm) in the two prescribed poems. How does Poem 1's rhythm serve devotion, while Poem 2's rhythm serves critique? Reference specific lines.

## DIAGNOSTIC_ANSWER_4
Poem 1: "cgqr fnuku dks vofèk vklikl ijs / [kjs vjcjfu Hkjs gSa mfB tku dks" — the repeating "k" and "s" sounds (vklikl, [kjs, vjcjfu, Hkjs, mfB) create a *chant-like*, meditative cadence mimicking japa (repetition of guru's name). Poem 2: "vkukdkuh vkjlh fugkfjcks djkSxs dkSykSa" — the staccato "k" clusters (vkukdkuh, vkjlh, fugkfjcks, dkSykSa) produce a *jarring*, percussive rhythm that mimics the hollow beating of ritual drums — sound enacts emptiness. A wrong answer that only lists "alliteration present" without linking *sound quality* to *thematic function* reveals superficial device-spotting — competitive exams (CUET, IPMAT) demand functional analysis.

## DIAGNOSTIC_QUESTION_5
Evaluate this student claim: "Kabir's poems are simple village songs — they don't need critical analysis because their meaning is obvious." Defend or refute using evidence from both poems' linguistic, philosophical, and structural layers.

## DIAGNOSTIC_ANSWER_5
Refute. **Linguistic:** "Simple" Braj/Awadhi masks sophisticated code-switching — "iSt" (cgl) for "heart" elevates body to temple; "owQdHkjh" (iqdkj Hkjh) fuses ritual + futility in one compound. **Philosophical:** Poem 1 encodes *guru-tattva* (guru as divine intermediary) — a contested theological position in 15th-century Vaishnavism. Poem 2 encodes *nirguna-saguna debate* — "iqdkj dku [kksfy gS" (don't offer hollow ritual) challenges temple Hinduism's economic basis. **Structural:** Poem 1's couplet (dohā) form condenses epistemology: "vc u f?kjr ?ku vkuan funku dks" — temporal shift (now/never) mirrors spiritual awakening. "Obviousness" is an illusion created by masterful compression. A wrong answer agreeing with the claim reveals the "simplicity fallacy" — confusing *accessible language* with *simple meaning* — a trap Board examiners set in "evaluate" questions.

## DIAGNOSTIC_QUESTION_6
Create a 4-line dohā (couplet) in Hindi (Devanagari) that uses Kabir's technique: a domestic metaphor (like garment, food, vessel) to express a spiritual truth about the guru-disciple or seeker-divine relationship. Explain your metaphor choice in 2 sentences.

## DIAGNOSTIC_ANSWER_6
**Student dohā example:**  
"गुरु ज्ञान घृत, शिष्य पात्र निर्मल, भक्ति अग्नि जली।  
ज्यों घी धार बिनु अग्नि बुझै, त्यों गुरु बिनु ज्ञान गली॥"  
**Metaphor explanation:** Ghee (clarified butter) represents guru's knowledge — pure, sustaining, transformative. The disciple is the vessel; bhakti is the fire. Without the steady stream of guru's grace (ghī dhār), the fire of devotion gutters — just as a lamp dies without oil. A poor answer using a clichéd metaphor ("guru is light") without *domestic specificity* or *causal logic* (why *this* metaphor?) reveals inability to transfer Kabir's method — the highest Bloom test.

## COMMON_MISCONCEPTION
Students believe "critical analysis" means *finding hidden symbols* — so they invent far-fetched readings (e.g., "lanslks = the five elements") instead of grounding interpretation in *textual evidence* and *historical context*. They also think "simple language = simple meaning," missing how Kabir's vernacular *is* the argument (democratizing spirituality). This error stems from Class 10-11 training that rewarded "identify the metaphor" over "explain why *this* metaphor *here*." In Board exams, this yields answers full of device labels (anupraś, rūpak) without *function* — losing 2-3 marks per 5-mark question. In CUET/IPMAT, it fails "author's craft" questions requiring *effect* explanation.

## ON_FAILURE
1. **Revisit c12_hin_a_cbse_09_008 (Imagery/Metaphor) and c12_hin_a_cbse_09_009 (Irony/Symbolism)** — re-do the "metaphor function" exercise: for each image, write "This image does X because Y (text evidence) and connects to theme Z."  
2. **Revisit c11_hin_ar_cbse_01_013 / 02_013 / 09_013 (Class 11 Critical Thinking)** — practice the 5-step method on a *new* Kabir dohā not in syllabus (e.g., "धीरे-धीरे रे मना...").  
3. **Diagnostic re-test:** Take Diagnostic Questions 2, 3, 4 again after 48 hours. If still scoring <80%, schedule 1:1 with teacher for "think-aloud" modeling of Poem 2 analysis.

## BUILDS_ON
c12_hin_a_cbse_09_012 (Comprehension: Literal and Inferential Questions) — literal/inferential comprehension provides the textual evidence base that critical analysis interprets.

## LEADS_TO
c12_hin_a_cbse_09_014 (Writing Skills: Based on the Chapter) — critical analysis outputs become the content and structure for high-scoring Board exam answers (long answers, value-based questions).

## PREREQUISITE_NODE_IDS
c12_hin_a_cbse_09_001, c12_hin_a_cbse_09_002, c12_hin_a_cbse_09_003, c12_hin_a_cbse_09_004, c12_hin_a_cbse_09_005, c12_hin_a_cbse_09_006, c12_hin_a_cbse_09_007, c12_hin_a_cbse_09_008, c12_hin_a_cbse_09_009, c12_hin_a_cbse_09_010, c12_hin_a_cbse_09_011, c12_hin_a_cbse_09_012, c11_hin_ar_cbse_01_013, c11_hin_ar_cbse_09_013

## PREREQUISITE_REASONS
c12_hin_a_cbse_09_001: Context/background establishes Kabir's historical position (15th century, Bhakti, nirguna) — essential for Context step in analysis method.
c12_hin_a_cbse_09_002: Plot/narrative structure (even in poems: sequence of thought) provides the "Tension" identification framework.
c12_hin_a_cbse_09_003: Setting/atmosphere (spiritual milieu, village vs. temple) informs the socio-cultural Context layer.
c12_hin_a_cbse_09_004: Protagonist analysis (Kabir as speaker-persona) enables voice/tone analysis in Craft step.
c12_hin_a_cbse_09_005: Supporting characters (guru Ramanand, implied priest/ritualist) map the relational dynamics poems dramatize.
c12_hin_a_cbse_09_006: Primary theme (guru grace, ritual futility) is the Synthesis target — analysis must reach it.
c12_hin_a_cbse_09_007: Secondary themes (caste, language politics, direct access) enrich Synthesis with nuance.
c12_hin_a_cbse_09_008: Imagery/metaphor identification supplies the Craft evidence (metaphors like lanslks, ghrit/pātr).
c12_hin_a_cbse_09_009: Irony/symbolism (ritual as hollow, guru-name as garment) provides interpretive lenses for Effect step.
c12_hin_a_cbse_09_010: Vocabulary (Braj/Awadhi terms: iSt, owQdHkjh, cqyk;) enables linguistic Craft analysis.
c12_hin_a_cbse_09_011: Grammar (verb forms, imperative mood in Poem 2) reveals tone/agency — key to Effect.
c12_hin_a_cbse_09_012: Literal/inferential comprehension is the evidence floor — analysis cannot begin without it.
c11_hin_ar_cbse_01_013: Class 11 Critical Thinking introduced the 5-step method; this node deepens it for Board-level rigor.
c11_hin_ar_cbse_09_013: Class 11 Chapter 9 Critical Thinking (if Kabir was covered) provides direct precedent for this poet.

## FORWARD_NODE_IDS
c12_hin_a_cbse_09_014, c12_hin_a_cbse_09_015
## FORWARD_REASONS
c12_hin_a_cbse_09_014: Writing Skills requires structured analytical paragraphs (PEEL: Point, Evidence, Explanation, Link) — this node teaches the analysis that feeds into PEEL.
c12_hin_a_cbse_09_015: Speaking/Listening discussions need interpretive positions to debate — this node equips students with evidence-based stances (e.g., "Is Kabir anti-ritual or anti-hollow-ritual?").

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
c11_his_cbse_07_001: Class 11 History "Bhakti-Sufi Traditions" (Chapter 7) provides the historical framework — Kabir as nirguna poet, Ramanandi lineage, caste critique — that constitutes the "Context" step in our analysis method.
c11_his_cbse_07_002: Same chapter's focus on "vernacular languages as vehicles of bhakti" directly explains Kabir's Braj/Awadhi choice — a Craft evidence point.
c11_civ_cbse_03_001: Class 11 Civics "Social Justice" (Chapter 3) covers caste discrimination and reform movements — Kabir's weaver identity and guru-access argument are literary enactments of this civic struggle.
c11_civ_cbse_03_002: Same chapter's "equality before law/divine" principle parallels Kabir's "grace not birth" theology — enables Context→Synthesis link in analysis.

## CHAIN_DESCRIPTION
c12_hin_a_cbse_09_012 -> c12_hin_a_cbse_09_013 -> c12_hin_a_cbse_09_014

## THIS_FORMULA
N/A - conceptual

## FORMULA_VARIABLES
N/A

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
analytical

## CROSS_SUBJECT
N/A | Kabir's 15th-century context (Delhi Sultanate decline, regional kingdoms, vernacular rise) is covered in Class 12 History "Themes in Indian History Part II" — provides macro-historical Context for poem analysis.
 N/A | Class 12 Civics "Social Movements" (Chapter 2) examines Bhakti as a social reform movement — Kabir's poems become primary sources for analyzing literature-as-activism, directly feeding the "Context → Synthesis" step.
c12_eco_cbse_04_001 | Class 12 Economics "Poverty and Inequality" (Chapter 4) — Kabir's weaver identity and critique of priestly economy (ritual as extraction) connect literary analysis to economic history of religious institutions.
c12_geo_cbse_03_001 | Class 12 Geography "Human Settlements" (Chapter 3) — Varanasi/Kashi as Kabir's locus, its temple economy and caste geography, grounds the poems' spatial imagination (village loom vs. temple courtyard).
## PREREQ_CONCEPT
The 5-step analytical method (Tension → Craft → Effect → Context → Synthesis) introduced in Class 11 Critical Thinking nodes, now applied to Kabir's specific Braj/Awadhi linguistic and nirguna philosophical texture.

## PREREQ_BEFORE
Student must be able to: (1) translate both poems line-by-line into modern Hindi, (2) identify all metaphors/symbols, (3) state the primary theme of each poem in one sentence, (4) define nirguna bhakti and guru-tattva in their own words.

## PREREQ_STUCK
If stuck on metaphor function (Diagnostic Q2), revisit c12_hin_a_cbse_09_008 "Imagery and Metaphor" — specifically the "vehicle/tenor/ground" framework for metaphor analysis.

## WORKED_EXAMPLE_1
PROBLEM: Analyze how Kabir uses the "weaver" (जुलाहा) identity in the first poem to construct spiritual authority. Write a Board-exam style 3-mark answer using PEEL structure.

STEPS:
- Step 1: Identify the Point — Kabir's self-identification as weaver (julāhā) is not autobiographical detail but a strategic theological claim: spiritual legitimacy derives from guru's grace, not caste birth.
- Step 2: Extract Evidence — "dfo ?kukuan fnYyh osQ ckn'kkg eqgEen 'kkg osQ ehj eqa'kh FksA dgrs gSa fd lqtku uke dh ,d L=kh ls mudk vVwV izse Fkk" (intro text) + poem's "pkgr pyu ;s lanslks ys lqtku dks" (guru's name as garment worn by disciple).
- Step 3: Explain Craft — Metaphor of "garment" (lanslks) transforms low-status occupation (weaving cloth) into high-status spiritual practice (wearing guru's name). The weaver *makes* garments; the disciple *wears* the guru's name — role reversal elevates disciple's agency.
- Step 4: Connect to Context — In 15th-century Kashi, Brahmin priests controlled ritual access; a weaver claiming direct divine access via guru was radical. Ramanand's acceptance of Kabir (despite caste) historicalizes the poem's claim.
- Step 5: Link to Theme — This synthesizes the primary theme: "गुरु कृपा ही मुक्ति का मार्ग है" (guru's grace alone is the path to liberation), making caste irrelevant.

REASONING: The PEEL structure forces evidence-based claims. Step 3's "craft explanation" (metaphor function) is what distinguishes analysis from summary. Step 4's historical grounding satisfies Board's "contextual understanding" rubric. Step 5's thematic synthesis earns the "evaluation" mark.

ANSWER: Kabir's weaver identity functions as a theological argument: just as a weaver transforms raw thread into garment, the guru transforms the low-born disciple into a vessel of grace. The metaphor "पकर पउ ;स लंसलकस यस लकतकु डस" equates the guru's name with a garment — intimate, identity-defining, worn daily. In caste-rigid 15th-century Kashi, this claiming of spiritual authority through guru (Ramanand) rather than birth subverts Brahminical monopoly on salvation. The poem thus enacts nirguna bhakti's core tenet: liberation is accessible to all through guru's grace, not ritual purity.

## WORKED_EXAMPLE_2
PROBLEM: The second poem critiques ritual worship ("vkukdkuh vkjlh"). Analyze how the poem's *structure* (dohā + chappay) and *address* (direct question to ritualist) perform this critique. Write a 4-mark answer.

STEPS:
- Step 1: Identify structural units — First stanza: dohā (24 matra, 13+11) establishing premise; Second stanza: chappay (6 lines, varied matra) escalating critique.
- Step 2: Analyze address shift — Dohā addresses general "you" (ritualist); chappay shifts to specific "tu" (तू) in "vc u f?kjr ?ku vkuan funku dks" — intensifying confrontation.
- Step 3: Trace argument arc — Dohā: ritual is performance ("fugkfjcks djkSxs dkSykSa"). Chappay: ritual is hollow ("owQdHkjh ewdrk cqyk;") and God rejects it ("pfdr nlk R;ksa u nhfB").
- Step 4: Connect form to content — Dohā's balanced rhythm mimics ritual's order; chappay's irregular lines mimic the *disorder* of hollow worship. The final line "dcgw¡ rkS esfj;S iqdkj dku [kksfy gS" breaks rhythm with urgent imperative — form enacts the call to stop.
- Step 5: Synthesize — Structure mirrors argument: from observation (dohā) to urgent intervention (chappay), embodying Kabir's role as spiritual whistleblower.

REASONING: Board exams reward "form-content relationship" analysis. Most students only analyze *words*; competitive exams (CUET) test *structural* awareness. The dohā→chappay shift is a deliberate generic choice — Kabir uses dohā for aphoristic truth, chappay for narrative/argumentative expansion.

ANSWER: The poem's two-stanza structure enacts its critique. The opening dohā ("कबीरदास कहि गये...") uses the form's traditional aphoristic authority to declare ritual as performative emptiness — "वकुकदुह वकजलह फुगकफजक्स दजकसक्स डकस्यकसा" (who are you deceiving with elaborate worship?). The shift to chappay in stanza 2 expands the critique with urgent direct address ("तू" implied in "वच उ फ?कजर ?कु वकुआन फुनकु डस" — now don't waste the moment). The chappay's longer, irregular lines accommodate the escalating evidence: ritual is "औकदहकज्ह एवदरक कयक;" (hollow offering), God "पफदर नलक र;कस उ नहफब" (doesn't accept). The final imperative "दकु [ककफय गस" (don't offer) breaks the rhythm — structural rupture performing spiritual rupture. Form *is* argument: ritual's order (dohā) masks chaos; truth (chappay) disrupts.

## WORKED_EXAMPLE_3
PROBLEM: Compare Kabir's use of "guru" in both poems. Poem 1: guru as grace-giver (Ramanand). Poem 2: guru implicit in "iqdkj dku [kksfy gS" (don't offer hollow ritual — implies true offering is guru-guided). Write a 5-mark comparative analysis for Board exam.

STEPS:
- Step 1: Establish comparison framework — Same concept (guru), different textual presence (explicit vs. implicit), different function (identity-source vs. ritual-antidote).
- Step 2: Analyze Poem 1 (explicit guru) — "lqtku" (disciple) defined by "lanslks" (guru's name as garment). Guru = external grace internalized. Evidence: "pkgr pyu ;s lanslks ys lqtku dks" + intro text on Ramanand.
- Step 3: Analyze Poem 2 (implicit guru) — No "guru" word. But "iqdkj" (hollow) ritual contrasted with implied "true" worship. In nirguna tradition, true worship = guru's instruction (guru-mukh). Evidence: "owQdHkjh ewdrk cqyk;" (ritual offering is hollow) → negation implies positive: guru-guided bhakti.
- Step 4: Trace philosophical consistency — Both poems position guru as *mediator* between seeker and nirguna brahman. Poem 1: mediator as grace-source. Poem 2: mediator as ritual-corrective. Neither permits direct unmediated access (unlike some yogic paths).
- Step 5: Evaluate significance — Kabir's consistency across poems reveals a coherent theology: guru is necessary but not sufficient (disciple must "wear" the name / "not offer hollow ritual"). Agency is shared.
- Step 6: Board-exam synthesis — Conclude: "Kabir presents guru as the non-negotiable gateway to nirguna realization — whether celebrated (Poem 1) or invoked by absence (Poem 2)."

REASONING: Comparative analysis is a high-order Board skill (5-markers often ask "compare/contrast"). The explicit/implicit distinction shows nuanced reading. Step 4's theological consistency check prevents over-reading. Step 6's "synthesis sentence" is the examiner's takeaway.

ANSWER: In Poem 1, the guru (Ramanand) is explicit and celebratory — the disciple's identity is *constituted* by the guru's name: "पकर पउ ;स लंसलकस यस लकतकु डस" (the disciple wears the guru's name as garment). The metaphor transforms the weaver's craft: the guru *provides* the garment; the disciple *wears* it — grace precedes effort. In Poem 2, the guru is absent but structurally necessary: the critique of "औकदहकज्ह" (hollow ritual) only makes sense if a *true* mode of worship exists — which nirguna tradition locates in guru-mukh bhakti (guru-instructed devotion). The imperative "दकु [ककफय गस" (don't offer hollow ritual) implicitly commands: "offer the guru's way." Both poems thus affirm the same theology: the nirguna brahman is inaccessible without guru — but the guru's grace demands the disciple's active participation (wearing the name / rejecting hollow ritual). Kabir's consistency across poems reveals a mature theology where guru is gateway, not substitute.

## COMPETENCY_QUESTION_1
QUESTION: A Class 12 student writes this answer to "Analyze the metaphor 'पकर पउ ;स लंसलकस यस लकतकु डस' (3 marks): 'This metaphor means the disciple wears the guru's name like clothes. It shows respect.' Identify THREE specific weaknesses in this answer using Board marking criteria. Then rewrite the answer to score full marks.

COMPETENCY: Critical evaluation of peer work / Answer improvement (metacognition)

STEPS:
- Step 1: Identify weakness 1 — "like clothes" is a paraphrase, not analysis. Missing: *why garment?* (intimacy, identity, daily wear vs. occasional ornament).
- Step 2: Identify weakness 2 — "shows respect" reduces theological claim to social etiquette. Missing: grace vs. birth, caste subversion, nirguna access.
- Step 3: Identify weakness 3 — No textual evidence beyond the quoted line. Missing: intro text (Ramanand, weaver), poem's "vc u f?kjr ?ku vkuan funku dks" (temporal urgency).
- Step 4: Rewrite using PEEL — Point (theological claim), Evidence (metaphor + context), Explanation (garment connotations + caste context), Link (theme: guru grace > birth).

ANSWER: **Weaknesses:** (1) Paraphrase, not analysis — explains *what* not *how/why*. (2) "Respect" trivializes the metaphor's theological weight (caste transcendence). (3) No supporting evidence (intro text, other lines). **Full-mark rewrite:** "The metaphor 'पकर पउ ;स लंसलकस यस लकतकु डस' equates the guru's name with a garment — intimate, identity-defining, worn constantly. Unlike armor (protection) or jewel (status), a garment touches skin and shapes public identity. For Kabir, a weaver (low caste), this asserts spiritual authority comes from *guru's grace* (Ramanand's acceptance), not birth. The intro confirms: 'लकतकु के नाम का प्रयोग अपनी रचनाओं में करते थे.' The poem's urgency 'अब न फ?कजर...' shows this 'wearing' is immediate, not deferred. Thus, the metaphor enacts nirguna bhakti's core: liberation via guru's grace, accessible to all castes."

DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: "Kabir's poetry is often called 'subversive.' Using BOTH prescribed poems, evaluate this claim by analyzing how *linguistic choices* (vocabulary, syntax, register) and *structural choices* (dohā, chappay, address) challenge orthodox religious authority. Write a 6-mark integrated response.

COMPETENCY: Integrated multi-text analysis with linguistic + structural evidence (highest Board competency)

STEPS:
- Step 1: Define "subversive" in this context — challenges priestly mediation, caste hierarchy, ritual economy using vernacular language and direct address.
- Step 2: Poem 1 linguistic subversion — "लकतकु" (disciple) as speaker (not priest); Braj/Awadhi vernacular vs. Sanskrit liturgy; "लंसलकस" (garment) domestic metaphor vs. Vedic upanayana (sacred thread).
- Step 3: Poem 1 structural subversion — Dohā form (traditionally wisdom verse) used for *personal testimony* ("I am weaver, guru's disciple") not abstract maxim.
- Step 4: Poem 2 linguistic subversion — Colloquial "वकुकदुह वकजलह" (elaborate worship), "एमकसफयगस" (accept) — temple Sanskrit replaced by people's speech. "औकदहकज्ह" (iqdkj Hkjh) compound fuses ritual + futility.
- Step 5: Poem 2 structural subversion — Direct rhetorical question ("दजकसक्स डकस्यकसा") breaks priest-devotee hierarchy; chappay's narrative expansion allows sustained critique impossible in dohā.
- Step 6: Synthesize — Language *and* structure jointly democratize spiritual authority: vernacular = access; direct address = agency; domestic metaphors = relevance.

ANSWER: Kabir's subversion operates at the intersection of language and form. **Poem 1** weaponizes the vernacular: the speaker is "लकतकु" (disciple), not acharya; the medium is Braj/Awadhi ("पकर पउ ;स लंसलकस"), not Sanskrit. The metaphor "गुरु नाम = लंसलकस" (garment) replaces the Brahminical "यज्ञोपवीत" (sacred thread) — a domestic, gender-neutral, caste-free symbol of belonging. The dohā form, traditionally for impersonal wisdom ("कबीरा खड़ा बाजार में"), becomes autobiographical testimony: "I, a weaver, wear my guru's name." **Poem 2** escalates: colloquial "वकुकदुह वकजलह" (elaborate worship) mocks priestly Sanskrit; "औकदहकज्ह" (हकदहकज्ह) condenses "ritual offering" + "hollow" in one compound — linguistic efficiency as critique. The rhetorical question "दजकसक्स डकस्यकसा" (who are you deceiving?) collapses the priest-devotee distance; the addressee must answer *to the poet*, not the deity. The shift from dohā (aphorism) to chappay (narrative argument) structures the subversion: observation → confrontation → imperative ("दकु [ककफय गस"). Together, both poems enact a dual revolution: **linguistic** (vernacular displaces liturgical) and **structural** (direct address displaces mediation) — making "subversive" not a label but a demonstrated practice.

DIFFICULTY: hard