## DEFINITION
Secondary themes are the underlying ideas, concerns, or messages in a literary work that support, contrast, or enrich the primary theme without being the central focus; they emerge through subplots, character interactions, setting details, and recurring motifs to reveal the text's broader social, psychological, or philosophical dimensions.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student can identify at least three distinct secondary themes in the play, trace each theme through specific dialogues and stage directions across multiple scenes, and explain how each secondary theme complicates or deepens the primary theme of the tuition-culture critique.

## SCOPE_BOUNDARY
This node covers the identification and analysis of secondary themes in the one-act play "जतüh" (jtuh) by Usha Priyamvada, focusing on themes such as gender roles, economic disparity, systemic corruption, generational conflict, and hypocrisy of the educated class. It does not cover primary theme analysis (node 006), literary devices (nodes 008-009), or writing skills (node 014).

## WALKTHROUGH
Imagine you are watching a family argument about private tuition fees — the mother insists it's necessary for the child's future, the father calls it exploitation, and the child sits silently terrified. That kitchen-table scene is exactly where secondary themes live: not in the main "tuition is bad" message, but in the mother's pragmatic fear, the father's helpless idealism, the child's voiceless anxiety. To begin, reread the play marking every moment where a character reveals a worry unrelated to tuition itself — money, gender expectations, job certificates, teacher integrity. Group these markings into clusters; each cluster is a candidate secondary theme. Then verify each cluster appears in at least two separate scenes with different characters. The key insight: secondary themes are not hidden messages; they are the text's way of showing that the central problem (tuition) is entangled with an entire ecosystem of social pressures.

## DIAGNOSTIC_QUESTION_1
Define "secondary theme" in your own words and give one example from any story you have read previously (not from this play).

## DIAGNOSTIC_ANSWER_1
A secondary theme is a recurring idea that supports or contrasts with the main theme but is not the central focus; for example, in "The Necklace" by Maupassant, the primary theme is the danger of vanity, while a secondary theme is the cruelty of social class distinctions. A wrong answer that merely repeats the primary theme definition or gives a plot event instead of a thematic idea reveals the student cannot distinguish between theme hierarchy levels.

## DIAGNOSTIC_QUESTION_2
In the play, the mother (yhyk) says: "मैं तो यही कहती हूँ कि वकील साहब को ट्यूशन करना ही पड़ेगा... बच्चों के भविष्य का सवाल है।" Explain what secondary theme this dialogue reveals and why it is not the primary theme.

## DIAGNOSTIC_ANSWER_2
This dialogue reveals the secondary theme of "parental pragmatism vs. systemic exploitation" — the mother accepts the corrupt tuition system as unavoidable for her child's survival. It is not the primary theme because the play's central critique targets the tuition culture itself, not the mother's compromise. A wrong answer that labels this as the primary theme shows the student conflates a character's coping strategy with the author's central argument.

## DIAGNOSTIC_QUESTION_3
Identify one stage direction from the text that conveys economic disparity without any character speaking about money directly. Quote the stage direction and explain its thematic function.

## DIAGNOSTIC_ANSWER_3
Stage direction: "निम्न मध्यम वर्ग के एक छोटे से मकान का एक दृश्य... एक टूटी हुई कुर्सी... दीवार पर टंगी हुई एक पुरानी तस्वीर।" This visual description establishes the family's poverty as a constant backdrop, making their desperate acceptance of tuition fees thematically inevitable rather than a mere choice. A wrong answer that quotes a spoken line about fees instead of a silent visual detail shows the student cannot distinguish thematic encoding in stagecraft from dialogue.

## DIAGNOSTIC_QUESTION_4
Compare the father (जतüh) and the teacher (गृहलक्ष्मी) in their responses to the tuition system. How do their contrasting stances create a secondary theme about "complicity of the educated"?

## DIAGNOSTIC_ANSWER_4
The father opposes tuition verbally but ultimately sends the child; the teacher refuses to give tuition personally but upholds school rules that make tuition necessary. Together they illustrate that even well-meaning educated individuals become complicit in systemic corruption through inaction or institutional obedience. A wrong answer that treats them as simply "good vs. bad" characters misses the thematic nuance that both are trapped in the same structure.

## DIAGNOSTIC_QUESTION_5
Critique the view that the play's secondary theme of "gendered division of labor" is merely a background detail. Use two specific scenes to defend your position.

## DIAGNOSTIC_ANSWER_5
The gendered division of labor is structurally essential: Scene 1 shows the mother managing household finances and tuition negotiations while the father debates principles; Scene 3 shows the mother physically feeding the child during the tuition discussion, symbolizing her role as the nurturer who bears the practical burden. Removing this theme would collapse the play's realism about how systemic pressures fall disproportionately on women. A wrong answer that calls it "just setting" reveals inability to see how character roles enact thematic arguments.

## DIAGNOSTIC_QUESTION_6
Write a 4-line poetic stanza that captures the secondary theme of "the child's silenced voice" using imagery from the play (e.g., broken chair, certificate, tuition fee receipt).

## DIAGNOSTIC_ANSWER_6
टूटी कुर्सी पर बैठा डर,<br>
सर्टिफिकेट की आस लिए,<br>
फीस की रसीद नहीं बोलती,<br>
बच्चे की चुप्पी ही गवाह बने।<br>
A poor answer that describes the plot instead of evoking the theme through imagery shows the student cannot transform thematic analysis into creative synthesis.

## COMMON_MISCONCEPTION
Students often believe secondary themes are simply "less important" themes that can be listed without textual evidence. In reality, a secondary theme in a senior-secondary text like "जतüh" must be traced through at least three distinct textual moments (dialogue, stage direction, character action) and shown to interact with the primary theme — e.g., the economic disparity theme is not just "they are poor" but "their poverty forces them to participate in the very system the play critiques." This misconception arises because Class 10 treatments often ask students to "list themes" without requiring evidence mapping.

## ON_FAILURE
If a student cannot distinguish secondary themes with evidence: 1) Have them create a three-column table: Column A = textual moment (quote/stage direction), Column B = what it literally shows, Column C = what thematic idea it suggests. 2) Ask them to group Column C entries into clusters of 3+ moments each. 3) For each cluster, write one sentence explaining how it complicates the primary theme. 4) Verify each cluster appears in at least two different scenes. This scaffold moves them from listing to evidence-based thematic mapping.

## BUILDS_ON
c11_hin_ar_cbse_06_006 (Theme: Primary Theme and Message) — students must first establish the central tuition-culture critique before identifying how secondary themes orbit it.

## LEADS_TO
c11_hin_ar_cbse_06_013 (Critical Thinking: Analysis and Interpretation) — secondary theme analysis provides the multi-layered textual evidence required for higher-order critical responses.

## PREREQUISITE_NODE_IDS
c11_hin_ar_cbse_06_001, c11_hin_ar_cbse_06_002, c11_hin_ar_cbse_06_003, c11_hin_ar_cbse_06_004, c11_hin_ar_cbse_06_005, c11_hin_ar_cbse_06_006
## PREREQUISITE_REASONS
c11_hin_ar_cbse_06_001: Context/background knowledge (author, period, tuition-culture reality) is needed to recognize thematic references.
c11_hin_ar_cbse_06_002: Plot structure understanding ensures students can locate thematic moments in the correct dramatic sequence.
c11_hin_ar_cbse_06_003: Setting/atmosphere analysis provides the physical and social backdrop where secondary themes materialize.
c11_hin_ar_cbse_06_004: Protagonist analysis (जतüh) reveals how the central character embodies thematic tensions.
c11_hin_ar_cbse_06_005: Supporting character analysis (यथ्य, वफ़र, गृहलक्ष्मी, प्रिंसिपल) shows how each character carries a thematic strand.
c11_hin_ar_cbse_06_006: Primary theme identification is the anchor against which secondary themes are defined and measured.

## FORWARD_NODE_IDS
c11_hin_ar_cbse_06_008, c11_hin_ar_cbse_06_009, c11_hin_ar_cbse_06_012, c11_hin_ar_cbse_06_013, c11_hin_ar_cbse_06_014, c12_hin_a_cbse_01_007, c12_hin_a_cbse_08_007, c12_hin_a_cbse_10_007, c12_hin_ar_cbse_04_007, c12_hin_ar_cbse_06_007, c12_hin_ar_cbse_07_007, c12_hin_ar_cbse_14_007

## FORWARD_REASONS
c11_hin_ar_cbse_06_008: Imagery and metaphor often encode secondary themes (e.g., broken chair = economic fragility).
c11_hin_ar_cbse_06_009: Irony and symbolism are primary vehicles for secondary themes (e.g., teacher's refusal = symbolic complicity).
c11_hin_ar_cbse_06_012: Comprehension questions frequently ask students to trace a secondary theme across the text.
c11_hin_ar_cbse_06_013: Critical interpretation requires synthesizing primary and secondary themes into a coherent reading.
c11_hin_ar_cbse_06_014: Writing tasks (article, speech, letter) on education reform demand thematic depth beyond the primary message.
c12_hin_a_cbse_01_007: Chapter 6 introduced comparative thematics across poems.  
c12_hin_a_cbse_08_007: अगला तार्किक चरण: Secondary themes are the underlying, complementary ideas in a literary work that support, contrast w... इस नोड की अवधारणाओं को सीधे उपयोग/विस्तारित करता है।  
c12_hin_a_cbse_10_007: Builds analytical writing stamina for thematic paragraphs.  
c12_hin_ar_cbse_04_007: Class 11 Chapter 6 secondary themes — introduces tracking themes across prose+poetry mixed chapters.  
c12_hin_ar_cbse_06_007: Class 11 node on secondary themes provides the foundational skill of distinguishing primary vs. subordinate thematic strands.  
c12_hin_ar_cbse_07_007: Chapter 6 application — cumulative practice before Class 12 complexity  
c12_hin_ar_cbse_14_007: Class 11 practice with prose memoir/diary form (e.g., "रजनी") builds genre-specific thematic awareness.  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
none

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_06_006 -> c11_hin_ar_cbse_06_007 -> c11_hin_ar_cbse_06_013

## THIS_FORMULA
N/A - conceptual

## FORMULA_VARIABLES
N/A

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
conceptual

## CROSS_SUBJECT
c11_sociology_social_stratification | The play's depiction of economic disparity and tuition culture mirrors sociological concepts of cultural capital and reproduction of inequality through education systems.
c11_economics_market_failure | The tuition market described exhibits information asymmetry (parents don't know school teaching is deliberately weakened) and coercive monopoly power (certificate gatekeeping), illustrating market failure in education services.
c11_political_science_policy_implementation | The principal's complicity and the teacher's helplessness demonstrate the gap between policy intent (equitable education) and street-level bureaucracy implementation.

## PREREQ_CONCEPT
Primary theme identification with textual evidence (node 006) — without a clearly evidenced central argument, secondary themes cannot be distinguished from random observations.

## PREREQ_BEFORE
Student must be able to state the primary theme of "जतüh" in one sentence with two supporting textual references.

## PREREQ_STUCK
Review node 006 (Primary Theme) and re-read the play marking every mention of tuition, fees, certificate, and school — these are the primary theme's textual anchors.

## WORKED_EXAMPLE_1
PROBLEM: Identify and trace the secondary theme of "generational conflict" through three distinct scenes in the play, explaining how it deepens the primary theme of tuition-culture critique.

STEPS:
- Step 1: Recall the primary theme — the play critiques a tuition culture where schools deliberately weaken classroom teaching to force paid private tuition.
- Step 2: Scan the text for moments where the child (वफ़र) expresses a view different from both parents — e.g., his fear of exams, his silence during arguments, his desperate wish to please.
- Step 3: Locate Scene 1: Father debates principle, mother demands pragmatism, child says nothing but stage direction notes "वफ़र का चेहरा उतर गया" — shows child as silent victim of adult ideological clash.
- Step 4: Locate Scene 2: Child attempts to study but cannot concentrate; father scolds "पढ़ाई नहीं करोगे तो क्या होगा?" while mother defends "थक गया है बेचारा" — reveals generational gap in understanding pressure.
- Step 5: Locate Scene 3: Child's result arrives; father says "देखा, ट्यूशन के बिना कुछ नहीं होता", mother says "अब तो ट्यूशन लगाना ही पड़ेगा" — child's achievement is immediately colonized by the tuition narrative.
- Step 6: Synthesize: The generational conflict theme shows tuition culture doesn't just exploit parents — it fractures family communication, making the child a trophy rather than a person, thus deepening the critique from "financial exploitation" to "psychological colonization."

REASONING: This six-step process moves from primary theme anchoring to evidence collection, scene-by-scene tracing, and finally thematic synthesis — the exact analytical ladder required for board-level answers.

ANSWER: The secondary theme of generational conflict appears in three scenes: (1) opening argument where child's silence marks his erasure, (2) study scene where parental pressure paralyzes rather than motivates, (3) result scene where child's success is claimed by the tuition system. Together they show tuition culture destroys intergenerational trust, deepening the primary critique from economic to existential.

## WORKED_EXAMPLE_2
PROBLEM: The stage direction "गृहलक्ष्मी के चेहरे पर एक अजीब सी विवशता उभरती है" (a strange helplessness appears on the teacher's face) occurs when she refuses tuition but admits the system forces it. Analyze how this single moment encapsulates the secondary theme of "hypocrisy of the educated."

STEPS:
- Step 1: Identify the speaker and context — गृहलक्ष्मी (teacher) has just refused to tutor वफ़र, citing principles, but then reveals she knows the school system makes tuition unavoidable.
- Step 2: Isolate the visual cue — "अजीब सी विवशता" (strange helplessness) is a staged facial expression, not dialogue, making it a deliberate directorial choice to convey internal conflict.
- Step 3: Connect to character role — As a teacher, she represents the educated class that should resist corruption; her helplessness shows even the profession tasked with education is captured by the system.
- Step 4: Link to primary theme — The primary theme attacks the tuition system; this moment shows the system's most natural opponents (teachers) are neutralized, making the critique systemic rather than individual.
- Step 5: Verify recurrence — Later, the principal (फनस'कद) explicitly defends the system, confirming the teacher's helplessness is structural, not personal.
- Step 6: Formulate thematic statement — The educated class's hypocrisy is not moral failure but structural entrapment: they know the system is wrong but lack institutional power to change it.

REASONING: This analysis demonstrates how a single stage direction can condense a secondary theme by combining character role, visual symbolism, and structural positioning — a skill essential for unpacking dense dramatic texts.

ANSWER: The teacher's "strange helplessness" visually encodes the secondary theme: the educated class recognizes systemic corruption (hypocrisy) but cannot act against it (helplessness), proving the tuition culture has captured its own gatekeepers.

## WORKED_EXAMPLE_3
PROBLEM: Synthesize how the secondary themes of "economic disparity," "gendered labor," and "systemic corruption" intersect in the mother's (यथ्य) character arc to create a feminist critique embedded within the play's education critique.

STEPS:
- Step 1: Map economic disparity onto mother — she manages the household budget, calculates tuition fees (72 rupees for 5 subjects), and decides which expenses to cut; her dialogue "कहाँ से लाएँगे इतने पैसे?" grounds the abstract corruption in material survival.
- Step 2: Map gendered labor onto mother — she alone negotiates with the teacher, feeds the child during discussions, and bears the emotional labor of worrying ("मैं तो रात-भर सो नहीं पाती"); the father debates principles, she manages consequences.
- Step 3: Map systemic corruption onto mother — she is the one who ultimately says "ट्यूशन लगाना ही पड़ेगा," showing how the system forces the most vulnerable (poor mother) to become its agent.
- Step 4: Identify intersection point — In Scene 2, when the teacher refuses tuition, the mother pleads "बच्चे का भविष्य खराब हो जाएगा" — here economic fear, maternal duty, and systemic coercion converge in one speech.
- Step 5: Trace arc across play — Beginning: mother as pragmatic negotiator. Middle: mother as desperate supplicant. End: mother as resigned participant ("अब तो ट्यूशन लगाना ही पड़ेगा") — her agency is progressively stripped by the system.
- Step 6: Articulate feminist critique — The play implicitly argues that education reform cannot succeed without addressing how patriarchal economies load the cost of systemic failure onto women's unpaid labor and anxiety.

REASONING: This synthesis requires holding three thematic strands simultaneously and showing their convergence in a single character — the highest-order thematic analysis skill for Class 11, directly mirroring board exam "analyze the character as a vehicle for multiple themes" questions.

ANSWER: The mother's arc embodies the intersection of all three secondary themes: her poverty makes tuition fees a survival crisis, her gender assigns her the labor of managing that crisis, and the corrupt system forces her to betray her own judgment. This convergence creates an implicit feminist critique: the tuition culture exploits not just students but the gendered economy of care that sustains families.

## COMPETENCY_QUESTION_1
QUESTION: A Class 11 student writes in a board exam answer: "The play 'जतüh' has many themes like poverty, gender, and corruption. The mother shows poverty because she worries about fees. The teacher shows corruption because she refuses tuition but knows it's needed. These are secondary themes." Evaluate this answer using the mastery criteria for this node. What is missing? Rewrite the answer to meet board-exam standards.

COMPETENCY: Critical evaluation of thematic analysis quality (evaluating textual evidence, thematic hierarchy, and synthesis)

STEPS:
- Step 1: Check if the answer identifies secondary themes with specific textual evidence — it names themes but gives only one generic example each, no quotes or scene references.
- Step 2: Check if it distinguishes secondary from primary theme — it never mentions the primary theme (tuition-culture critique), so hierarchy is absent.
- Step 3: Check if it shows thematic interaction — themes are listed in isolation, not shown intersecting in characters or scenes.
- Step 4: Rewrite using evidence clusters: For each theme, cite two specific moments (dialogue/stage direction), then explain how it complicates the primary theme.

ANSWER: The original answer fails mastery criteria: it lists themes without evidence mapping, ignores primary theme anchoring, and treats themes as isolated labels. Board-standard rewrite: "The play's primary theme is the critique of institutionalized tuition culture. Three secondary themes deepen this: (1) Economic disparity — established by the opening stage direction 'निम्न मध्यम वर्ग का छोटा मकान' and the mother's fee calculation '७२ रुपये पाँच विषयों के'; this shows the primary theme's victims are specifically the poor. (2) Gendered labor — the mother alone negotiates with the teacher (Scene 1) and manages the child's anxiety (Scene 2 'बच्चे को खाना खिलाते हुए'), revealing how systemic exploitation falls on women's unpaid care work. (3) Hypocrisy of the educated — the teacher's 'विवशता' (Scene 2) and the principal's defense of the system (Scene 3) prove the primary theme's corruption has captured its supposed guardians. Together, these secondary themes expand the critique from 'tuition is bad' to 'tuition is a structural violence that exploits class, gender, and professional ethics simultaneously.'"

DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: The play ends with the father (जतüh) organizing a public meeting against the tuition system while the mother (यथ्य) says "अब तो ट्यूशन लगाना ही पड़ेगा." Using this final contradiction, argue whether the play ultimately offers hope for systemic change or resigns to complicity. Support your argument with three secondary themes and their textual trajectories.

COMPETENCY: Synthesizing thematic trajectories to form an interpretive judgment (argumentative synthesis)

STEPS:
- Step 1: Identify the core tension — father's public resistance vs. mother's private surrender.
- Step 2: Trace secondary theme 1 (economic disparity) — mother's surrender is economically forced; father's resistance is ideologically privileged (he doesn't manage the budget).
- Step 3: Trace secondary theme 2 (gendered labor) — mother's surrender is the culmination of her bearing the practical burden; father's resistance is performative because he won't do the care work.
- Step 4: Trace secondary theme 3 (generational conflict) — the child's future is the stakes; neither parent's stance actually secures it without systemic change.
- Step 5: Synthesize judgment — the play ends in dialectical tension: hope (father's meeting) and resignation (mother's fee payment) coexist, refusing false closure. The secondary themes collectively argue that individual resistance without structural transformation is theater, but theater is the only space where truth can be spoken — making the play itself an act of resistance.

REASONING: This question demands the highest Bloom level (Create/Evaluate) by requiring students to use secondary themes as evidence for an original interpretive claim about the play's political philosophy — exactly the competency board exams test in "critical appreciation" questions.

ANSWER: The play refuses both naive hope and total resignation. The father's meeting represents the secondary theme of "performative resistance by the privileged" (he can protest because he doesn't pay the fees). The mother's surrender represents "material complicity of the burdened" (she pays because she manages survival). The child's silence represents "generational stakes beyond parental theater." Together, these three secondary themes' trajectories prove the play's final argument: systemic change requires collective action that redistributes the burdens the mother carries alone — the meeting is a necessary first step, but the fee payment shows how far the first step is from the finish line.

DIFFICULTY: hard