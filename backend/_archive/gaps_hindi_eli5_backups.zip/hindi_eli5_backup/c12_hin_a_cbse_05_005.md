## DEFINITION
In poetry, supporting characters are the secondary voices, symbols, or entities (such as birds, natural elements, or implied listeners) that interact with the central image or speaker to deepen the poem's thematic resonance. Unlike prose, they are not fully developed personalities but function as poetic devices to contrast, amplify, or embody the central idea.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student can identify at least two supporting characters/elements in each poem of Chapter 5, cite specific lines or images as evidence, and explain how each supporting element shapes the poem's central theme of nature's spontaneity versus human artifice (in "ओलार वक;क") or the celebration of instinctive joy (in "रक्सM+ks").

## SCOPE_BOUNDARY
This node covers the analysis of supporting poetic characters/elements in the two poems of Chapter 5 ("ओलार वक;क" and "रक्सM+ks") only. It does not cover the protagonist/speaker analysis (node 004), theme development (nodes 006, 007), or literary devices (nodes 008, 009).

## WALKTHROUGH
Imagine you are sitting in a garden and hear a bird's sudden, perfect song — you didn't ask for it, it just happens. Now think: in "ओलार वक;क", the child (nk) who listens and asks the bird to sing again is not the main focus, but without the child, the poem's contrast between spontaneous nature and human desire for repetition would vanish. In "रक्सM+ks", the peacock (fe^h) and parrot (cht) are not the dancer, yet their feathers become the very tools of dance. Start by asking: "Who else is present in the poem besides the speaker?" Mark every noun that acts or is addressed. Then ask: "What does this presence *do* to the poem's meaning?" The key insight: in poetry, supporting characters are often symbols — their 'character' is their function in the thematic architecture.

## DIAGNOSTIC_QUESTION_1
In the poem "ओलार वक;क", who is the 'nk' (child) and what is their single action in the poem?

## DIAGNOSTIC_ANSWER_1
The 'nk' is the child listener who, upon hearing the oriole's song, asks the bird to sing again ("dy eSaus tkuk fd olar vk;k"). A wrong answer (e.g., "the child is the poet" or "the child catches the bird") reveals the student confuses the implied listener with the speaker or imposes a narrative action not in the text. This shows a literal, prose-based reading of poetic personae.

## DIAGNOSTIC_QUESTION_2
Explain in your own words why the poet includes the child's request ("dy eSaus tkuk fd olar vk;k") at the end of "ओलार वक;क". What does it reveal about human nature versus the bird's song?

## DIAGNOSTIC_ANSWER_2
The child's request highlights the human tendency to want to possess and repeat a fleeting natural moment, contrasting with the bird's song which is spontaneous, unrepeatable, and free from intention. A wrong answer (e.g., "the child loves the bird" or "the poet wants us to protect birds") reveals a sentimental reading that misses the structural contrast the poem builds between *vuqHko* (spontaneous expression) and human *vkok”k* (desire to capture). This misconception stems from treating the poem as a story about a child and a bird rather than a philosophical contrast.

## DIAGNOSTIC_QUESTION_3
In "रक्सM+ks", the poet says ";s Ålj catj rksM+ks" (dance with peacock feathers and parrot feathers). Apply the concept of 'supporting character as symbol' to explain what the peacock and parrot represent *functionally* in the poem. Do not just describe the birds.

## DIAGNOSTIC_ANSWER_3
The peacock (fe^h) and parrot (cht) function as symbols of natural beauty and voice respectively; their feathers (Ålj, catj) are the *instruments* the poet urges the dancer to use, meaning the dance must be rooted in nature's own aesthetics, not artificial ornament. A wrong answer (e.g., "the peacock is the national bird so it shows patriotism" or "parrot represents mimicry") imports external knowledge and misses the poem's internal logic: the feathers are *vuqitkÅ ”kehu* (instinctive/natural) tools for *l`tu* (dance/joy). This error shows inability to read symbols within the poem's own symbolic economy.

## DIAGNOSTIC_QUESTION_4
Compare the role of the 'child' in "ओलार वक;क" with the role of the 'peacock/parrot' in "रक्सM+ks". How does each supporting element differently mediate the relationship between the human speaker and the natural world?

## DIAGNOSTIC_ANSWER_4
The child in "ओलार वक;क" represents human *interruption* — the desire to hold onto nature's spontaneity — thus creating tension. The peacock/parrot in "रक्सM+ks" represent *participation* — their feathers are the very medium through which the human dancer connects to nature, creating harmony. A wrong answer (e.g., "both are just part of the setting") flattens the poems' distinct thematic architectures: one poem explores the *gap* between human and nature, the other explores *union* through instinct. This reveals a failure to analyze how supporting elements structure the poem's argument.

## DIAGNOSTIC_QUESTION_5
Evaluate this statement: "The supporting characters in both poems are merely decorative images; the poems would mean the same without them." Defend your judgment with evidence from both poems.

## DIAGNOSTIC_ANSWER_5
The statement is false. In "ओलार वक;क", removing the child erases the poem's central irony: the bird sings *vuqHko* (spontaneously), but the human *asks* for it — the poem's meaning *is* that contrast. In "रक्सM+ks", removing the peacock/parrot feathers leaves the command "rksM+ks" (dance) without its prescribed *method* — the poem argues dance *must* be *vuqitkÅ* (instinctive/natural), and the feathers are the proof. A wrong evaluation (agreeing or giving vague reasons) shows the student sees imagery as ornament rather than structural necessity — a critical error for board and competitive exam analysis.

## DIAGNOSTIC_QUESTION_6
Write a 4-line stanza in Hindi (or English) where a natural element (bird, river, wind) acts as a supporting character that *changes* the speaker's mood or decision, using the same technique as Jitendra Kumar Lakha. Do not copy his lines.

## DIAGNOSTIC_ANSWER_6
A good answer creates a brief scene where a natural element's unbidden action (e.g., a sudden breeze scattering papers) forces the speaker to abandon a rigid plan and accept spontaneity — mirroring the 'olar vk;k' structure. A poor answer (e.g., a description of a pretty bird without a shift in the speaker) shows the student cannot transfer the *functional* role of a supporting character into creative practice. This reveals a gap between analytical recognition and generative understanding.

## COMMON_MISCONCEPTION
Students treat supporting characters in poetry as 'minor characters in a story' — they look for personality traits, backstories, or dialogue. In Jitendra Kumar Lakha's poems, the 'child' has no name, age, or personality; the 'peacock' has no voice. Their *only* reality is their *function* in the poem's argument. Students write: "The child is innocent and loves nature" (inventing traits) instead of "The child's request exposes the human urge to possess the unpossessable." This error costs marks in board exams (where 'character sketch' questions expect functional analysis) and in CUET/IPMAT (where unseen poem analysis demands structural reading).

## ON_FAILURE
1. Have the student re-read both poems *only* marking nouns that are not the speaker ('मैं', 'हम', 'dfo'). 2. For each marked noun, ask: "If I delete this noun, what specific meaning disappears?" 3. Make a two-column table: Column A = Supporting Element, Column B = Thematic Function (not description). 4. Practice writing one-sentence functional statements for each (e.g., "The child's request = human desire to repeat the unrepeatable"). 5. Re-attempt Diagnostic Questions 2 and 4 orally. If still stuck, revisit Class 11 node c11_hin_ar_cbse_05_005 for the 'functional character' framework.

## BUILDS_ON
Character Analysis: Protagonist (c12_hin_a_cbse_05_004) where the speaker's voice was established; now we analyze the voices/elements that surround and define that speaker.

## LEADS_TO
Theme: Primary Theme and Message (c12_hin_a_cbse_05_006) — the functions of supporting characters *are* the building blocks of the theme.

## PREREQUISITE_NODE_IDS
c12_hin_a_cbse_05_004, c11_hin_ar_cbse_05_005, c11_hin_v_cbse_05_005, c12_hin_a_cbse_05_001

## PREREQUISITE_REASONS
c12_hin_a_cbse_05_004: The protagonist (speaker) analysis establishes the central consciousness against which supporting characters are defined.
c11_hin_ar_cbse_05_005: Class 11 Antra Chapter 5 introduced the concept of 'functional characters' in poetry (e.g., in 'गंगा' or 'संध्या के बाद'), providing the analytical vocabulary.
c11_hin_v_cbse_05_005: Class 11 Vitan Chapter 5 reinforced character-role analysis in non-fiction narratives, transferable to poetic personae.
c12_hin_a_cbse_05_001: Supporting characters (wheel, clay, customers) are previewed as symbols of tradition.  

## FORWARD_NODE_IDS
c12_hin_a_cbse_05_006, c12_hin_a_cbse_05_007, c12_hin_a_cbse_05_008, c12_hin_a_cbse_05_014

## FORWARD_REASONS
c12_hin_a_cbse_05_006: The primary theme (spontaneity vs. artifice, instinctive joy) is *constructed* through the interplay of speaker and supporting characters — theme analysis requires this foundation.
c12_hin_a_cbse_05_007: Secondary themes (nature as teacher, the body as instrument) emerge directly from the symbolic roles of the bird, child, peacock, parrot.
c12_hin_a_cbse_05_008: Supporting characters (e.g., the bird, the stone) as metaphorical agents.  
c12_hin_a_cbse_05_014: Supporting characters (implied family/society) — evidence for "invisibility" theme.  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
No prior-class cross-subject nodes provided in the Hindi curriculum data.

## CHAIN_DESCRIPTION
c12_hin_a_cbse_05_004 -> c12_hin_a_cbse_05_005 -> c12_hin_a_cbse_05_006

## THIS_FORMULA
Functional Character Analysis Pattern: Identify Element -> Locate Textual Action/Image -> Determine Thematic Function (Contrast / Amplify / Embody) -> State Effect on Central Idea

## FORMULA_VARIABLES
Element = any noun/pronoun acting or addressed besides the speaker; Textual Action/Image = specific line/stanza reference; Thematic Function = one of: Contrast (opposes speaker), Amplify (intensifies speaker's trait), Embody (gives concrete form to abstract idea); Effect on Central Idea = how the poem's message changes if this element is removed.

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
analytical

## CROSS_SUBJECT
N/A | Folk traditions (like the 'olar' bird in regional songs) appear as living cultural symbols in poetry — analyzing them requires historical awareness of oral traditions.
 N/A | The specific imagery of oriole, peacock, parrot reflects subcontinental biodiversity; their symbolic use in literature is rooted in ecological familiarity.
 N/A | The poem's contrast between 'vuqHko' (spontaneous creation) and 'vkok”k' (demand/utility) mirrors the economic distinction between intrinsic value and exchange value.
 N/A | The child's request ('dy eSaus tkuk') can be read as a civic metaphor: the citizen's demand for repeatable, accountable beauty vs. the artist's uncontrolled expression.
## PREREQ_CONCEPT
Functional reading of poetic personae: every named entity in a poem is a structural component, not a narrative character.

## PREREQ_BEFORE
Student must be able to distinguish the *speaker* (the 'I' or implied poet) from every other voice/presence in the poem.

## PREREQ_STUCK
If stuck, review the 'Speaker vs. Listener' distinction in c12_hin_a_cbse_05_004 and the 'Symbol as Character' exercises in c11_hin_ar_cbse_05_005.

## WORKED_EXAMPLE_1
PROBLEM: Analyze the supporting character 'ngj&ngj ngosaQxs' (the dense, thick forests) in the line "fd ngj&ngj ngosaQxs dgha <kd osQ taxy vke ckSj vkosaxs" from "ओलार वक;क". Use the Functional Character Analysis Pattern.
STEPS:
- Step 1: Identify the element — 'ngj&ngj ngosaQxs' (dense forests) is a noun phrase acting as a subject in the child's imagination.
- Step 2: Locate textual action/image — the forests are described as places where even the peacock's call ('<kd osQ taxy') would make the heart tremble ('vke ckSj vkosaxs'), but 'gekjh fuxkg muij ugha tkrh' (our fear does not go there).
- Step 3: Determine thematic function — the forests *embody* the raw, untamed natural world that evokes instinctive awe (vke ckSj), contrasting with the speaker's/child's civilized detachment (fuxkg ugha tkrh). Function: Contrast.
- Step 4: State effect on central idea — without this image, the poem's claim that the bird's song is a primal, fear-transcending force ('izek.k') would lack spatial/emotional grounding. The forests are the *arena* of the spontaneous.
- Step 5: Verify — check if the forests appear elsewhere: they frame the bird's song as emerging from a depth humans don't access. Confirmed.
REASONING: The forests are not a setting; they are a psychological landscape. The pattern forces us to see 'setting' as 'supporting character' when it performs thematic work.
ANSWER: The dense forests function as a supporting character that *embodies* the primal natural world where instinct (peacock's call) still rules, contrasting with human emotional numbness. Their removal would sever the poem's link between the bird's song and the deep, fear-evoking wilderness.

## WORKED_EXAMPLE_2
PROBLEM: In "रक्सM+ks", the line "fe^h esa jl gksxk gh tc og ikslsxh cht dks" uses the peacock (fe^h) and parrot (cht) in a conditional structure. Analyze their combined supporting role.
STEPS:
- Step 1: Identify elements — peacock (fe^h) and parrot (cht) are the two non-human agents.
- Step 2: Locate textual action — the peacock will 'glisten/shine' (jl gksxk) *only when* (tc) it shows (ikslsxk) the parrot. The parrot is the object of the peacock's display.
- Step 3: Determine thematic function — together they *amplify* the poem's core metaphor: dance (l`tu) is a mutual, instinctive display of beauty. The peacock needs the parrot as witness; the parrot needs the peacock as performer. Function: Amplify (mutual reinforcement).
- Step 4: State effect on central idea — this mutuality mirrors the dancer's relationship with their own heart (eu): the heart is both performer and witness. Without the pair, the metaphor of 'dance as instinctive dialogue' collapses.
- Step 5: Verify — later lines: "ge bldks D;k dj Mkysa bl vius eu dh [kht dks" (what shall we do with this stiffness of our heart?) — the peacock-parrot pair is the *antidote* to stiffness. Confirmed.
REASONING: The conditional 'tc' (when) makes their relationship temporal and causal — a structural dependency that maps onto the human heart's need for instinctive release.
ANSWER: The peacock and parrot function as a paired supporting character representing the *reciprocal instinct* essential to dance. The peacock's beauty is actualized only in the parrot's witnessing, just as the heart's joy requires expression. They are not two characters but one symbolic circuit.

## WORKED_EXAMPLE_3
PROBLEM: Synthesize: How does the *absence* of a direct human listener in "रक्सM+ks" (unlike the child in "ओलार वक;क") change the role of the peacock/parrot? Compare the two poems' strategies for connecting human to nature.
STEPS:
- Step 1: Recall "ओलार वक;क" structure — Speaker -> Bird (song) -> Child (request) -> Speaker's reflection. Human listener *interrupts* the natural flow.
- Step 2: Recall "रक्सM+ks" structure — Speaker -> Command to dance -> Peacock/Parrot (instruments) -> Heart (eu) -> Speaker's question. No external human listener.
- Step 3: Analyze peacock/parrot role in absence of human listener — they become the *internal* audience. The dancer dances *for* the instinctive beauty they represent, not for a human child.
- Step 4: Compare strategies — Poem 1 uses an *external* supporting character (child) to create irony/distance. Poem 2 uses *internalized* supporting characters (feathers as extensions of the dancer's body) to create unity.
- Step 5: Determine thematic consequence — Poem 1: nature remains other, human desire fails. Poem 2: nature is internalized, human instinct succeeds. The supporting characters *are* the difference.
- Step 6: Articulate insight — Lakha uses supporting characters to stage two different human-nature relationships: longing vs. belonging.
REASONING: This synthesis requires holding both poems' architectures simultaneously — a skill tested in comparative questions (board 5-markers, CUET literary analysis).
ANSWER: In "ओलार वक;क", the child is an *external* supporting character whose request highlights the unbridgeable gap between human desire and nature's spontaneity. In "रक्सM+ks", the peacock and parrot are *internalized* supporting characters — their feathers are the dancer's own tools — enabling a union where dance *is* the bridge. The presence vs. absence of a human listener fundamentally reorients the supporting characters' function from 'contrast' to 'embodiment'.

## COMPETENCY_QUESTION_1
QUESTION: A Class 12 student writes in a board exam answer: "In 'ओलार वक;क', the child is a symbol of innocence. In 'रक्सM+ks', the peacock is a symbol of beauty." Identify two specific weaknesses in this answer from the perspective of Functional Character Analysis. Rewrite the answer to score full marks (2 marks per poem).
COMPETENCY
Critical Evaluation & Answer Construction
STEPS:
- Step 1: Identify weakness 1 — 'innocence' and 'beauty' are *traits*, not *functions*. They describe what the symbols *are*, not what they *do* in the poem.
- Step 2: Identify weakness 2 — no textual evidence (line/image) is cited to support the claim.
- Step 3: Apply Functional Pattern to 'child' — Function: Contrast (human desire to repeat vs. bird's spontaneity). Evidence: "dy eSaus tkuk fd olar vk;k".
- Step 4: Apply Functional Pattern to 'peacock' — Function: Embody (natural instrument for instinctive dance). Evidence: ";s Ålj catj rksM+ks" and conditional "fe^h esa jl gksxk gh tc og ikslsxh cht dks".
- Step 5: Construct revised answer using Point-Evidence-Function-Link structure.
ANSWER: Weaknesses: (1) Trait-based not function-based analysis; (2) No textual evidence. Revised answer: "In 'ओलार वक;क', the child functions as a *contrast* to the oriole's spontaneous song: the child's request 'dy eSaus tkuk fd olar vk;k' exposes the human urge to possess the unrepeatable. In 'रक्सM+ks', the peacock (with parrot) *embodies* the natural instruments of instinctive dance: the command ';s Ålj catj rksM+ks' and the condition 'fe^h esa jl gksxk gh tc og ikslsxh cht dks' show dance must root in mutual, instinctive display." 
DIFFICULTY
medium

## COMPETENCY_QUESTION_2
QUESTION: (Case-based) A CUET practice question gives an unseen 4-line poem: "The river sang at midnight / I asked it to stay / The mountain echoed my plea / The river flowed away." Using Lakha's technique of supporting characters, analyze the roles of the river and the mountain. Which poem of Chapter 5 does this unseen poem structurally resemble more, and why?
COMPETENCY
Comparative Structural Analysis & Knowledge Transfer
STEPS:
- Step 1: Identify supporting characters — River (singer), Mountain (echoer), Speaker (asker).
- Step 2: Analyze river's function — Sings spontaneously (vuqHko), refuses to stay (flows away) = embodies unpossessable nature.
- Step 3: Analyze mountain's function — Echoes the speaker's plea = amplifies human desire, makes it resonant but futile.
- Step 4: Compare to Chapter 5 poems — River = oriole (olar); Speaker's plea = child's request; Mountain = no direct equivalent, but amplifies the *human* side unlike peacock/parrot which amplify *nature*.
- Step 5: Conclude structural resemblance — Resembles "ओलार वक;क" because: (a) nature's spontaneity (river/oriole) vs. human desire to hold (plea/request), (b) nature ultimately withdraws (flows away/bird flies), (c) a supporting element (mountain/child) frames the human desire. "रक्सM+ks" has no withdrawal, no failed plea.
ANSWER: The river functions as the spontaneous natural voice (like the oriole); the mountain functions as an amplifier of human futility (like the child, but externalizing the plea rather than voicing it). The poem structurally resembles "ओलार वक;क" because both stage a confrontation where a human request meets nature's indifference, mediated by a supporting element that frames the request. The mountain's echo parallels the child's request — both make the human desire audible and thus more poignant in its failure.
DIFFICULTY
hard