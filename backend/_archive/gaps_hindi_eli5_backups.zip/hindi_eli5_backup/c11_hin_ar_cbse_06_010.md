## DEFINITION
Vocabulary in Context: Key Words refers to the skill of identifying, interpreting, and analyzing the meaning, connotation, and function of specific words and phrases as they are used within the chapter "जतूह" (Jatuh), considering the dramatic situation, speaker's intent, socio-cultural background, and thematic significance.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student can independently select any key word from the chapter, explain its contextual meaning with textual evidence, analyze how its usage reveals character or theme, and demonstrate its appropriate use in a new sentence that reflects the same register and nuance.

## SCOPE_BOUNDARY
This node covers the identification and contextual analysis of key vocabulary from the chapter "जतूह" (e.g., डकसए फेफडलएक्स, डकसए फ्लोफपैक्स, ट्यूशन, शिक्षा नीति, बैकसडेट, लकुरहप उबज़, नैक्यवांक"ख, इज़्वोम, एक्सावक्ट, सीकडनक, ब्डव, इकककसडल डजुक, फ्जदकउब"क, फ्जलपज़ इककसटसडीवी, ओएकएमडीवी, लकुरहप उबज़, नैक्यवांक"ख, इज़्वोम, एक्सावक्ट, सीकडनक, ब्डव, इकककसडल डजुक, फ्जदकउब"क, फ्जलपज़ इककसटसडीवी, ओएकएमडीवी, लकुरहप उबज़, नैक्यवांक"ख, इज़्वोम, एक्सावक्ट, सीकडनक, ब्डव, इकककसडल डजुक, फ्जदकउब"क, फ्जलपज़ इककसटसडीवी, ओएकएमडीवी). It does NOT cover general dictionary meanings, grammar rules, or vocabulary from other chapters.

## WALKTHROUGH
Imagine you are watching a heated argument between a parent and a school director about tuition fees. The parent says, "आपके स्कूल में तो कोड-मिक्सिंग और कोड-स्विचिंग चलती है!" You might know the dictionary definitions, but what do these words *really* mean in this moment? To begin, locate the word in the dialogue. Note who speaks it, to whom, and the emotional tone. Next, examine the surrounding sentences: what situation prompts this word? Then, ask: does the word carry irony, sarcasm, or a hidden critique? Finally, connect the word to the chapter's larger themes — commercialization of education, parental anxiety, systemic hypocrisy. The key insight: in "जतूह", words are not just labels; they are weapons, shields, and mirrors of a broken system.

## DIAGNOSTIC_QUESTION_1
Define the term "डकसए फेफडलएक्स" (code-mixing) as used in the chapter "जतूह" and give one example from the text where it occurs.

## DIAGNOSTIC_ANSWER_1
Correct answer: Code-mixing refers to the blending of two or more languages within a single utterance, as seen when characters mix Hindi and English in casual conversation (e.g., "ओके, बाई" or "थैंक्यू, सर"). A wrong answer that only gives the linguistic definition without a textual example shows the student cannot ground the term in the specific context of the play.

## DIAGNOSTIC_QUESTION_2
In the dialogue where जतूह says, "ट्यूशन के नाम पर चलने वाला यह फर्जीवाड़ा...", explain why the word "फर्जीवाड़ा" (fraud/racket) is more powerful than "धोखा" (deception) in this context.

## DIAGNOSTIC_ANSWER_2
Correct answer: "फर्जीवाड़ा" implies an organized, systemic, and recurring scam involving multiple stakeholders (schools, tutors, officials), whereas "धोखा" suggests a one-time act by an individual. The former captures the institutionalized corruption theme. A wrong answer treating them as synonyms reveals the student misses the socio-political nuance and the author's critique of the education system.

## DIAGNOSTIC_QUESTION_3
The word "शिक्षा नीति" (education policy) appears in the Director's dialogue: "शिक्षा नीति के अनुसार...". Rewrite this sentence replacing "शिक्षा नीति" with "सरकारी नियम" (government rule) and explain how the shift changes the tone and implication.

## DIAGNOSTIC_ANSWER_3
Correct answer: "सरकारी नियम के अनुसार..." sounds bureaucratic and rigid, removing the aspirational and reformist connotation of "नीति" (policy). The Director uses "नीति" to legitimize his actions; replacing it exposes his hypocrisy. A student who only changes the word without analyzing the tonal shift fails to apply contextual sensitivity.

## DIAGNOSTIC_QUESTION_4
Compare the usage of "ट्यूशन" (tuition) in three different speeches: (a) वफ़र's desperate plea, (b) यथ्यक's sarcastic remark, (c) जतूह's final monologue. How does the same word carry different emotional and thematic weights?

## DIAGNOSTIC_ANSWER_4
Correct answer: For वफ़र, "ट्यूशन" = survival/lifeline (hope); for यथ्यक, "ट्यूशन" = commercial exploitation (cynicism); for जतूह, "ट्यूशन" = systemic disease (indictment). A wrong answer that gives a uniform definition shows inability to analyze how context reshapes meaning across speakers and dramatic moments.

## DIAGNOSTIC_QUESTION_5
Evaluate the author's choice of the word "नैक्यवांक"ख" (accountability) in the climax when जतूह demands it from the Director. Is it the most effective word, or would "ज़िम्मेदारी" (responsibility) or "जवाबदेही" (answerability) work better? Justify.

## DIAGNOSTIC_ANSWER_5
Correct answer: "नैक्यवांक"ख" is the most effective because it carries legal-administrative weight, implying systemic answerability with consequences, unlike "ज़िम्मेदारी" (moral) or "जवाबदेही" (procedural). It matches जतूह's shift from emotional appeal to institutional demand. A student who picks any synonym without justifying the register mismatch fails to evaluate lexical precision in a dramatic climax.

## DIAGNOSTIC_QUESTION_6
Create a new dialogue line for the character ग्स्मेकल्वज (the Director) where he uses the phrase "बैकसडेट" (backdate) to justify an unethical action, mimicking the play's blend of bureaucratic jargon and moral corruption.

## DIAGNOSTIC_ANSWER_6
Criteria for a good answer: The line must (1) use "बैकसडेट" correctly as a verb/noun in a bureaucratic context, (2) reveal the Director's manipulative mindset, (3) maintain the play's tone of casual corruption. Example: "हमने तो बस बैकडेट में दस्तखत करवा लिए, नीति तो वही रहती है।" A poor answer uses the word mechanically without dramatic irony or character voice.

## COMMON_MISCONCEPTION
Students often think "vocabulary in context" means memorizing dictionary definitions of difficult words from the chapter. They fail to realize that in "जतूह", words like "ट्यूशन", "नीति", "फर्जीवाड़ा" are deliberately chosen by the playwright to expose character psychology and systemic critique. The misconception arises because school exams often test isolated word meanings, not contextual function. For example, a student may define "कोड-मिक्सिंग" linguistically but miss how its use by urban characters signals class privilege and alienation from the protagonist's reality.

## ON_FAILURE
If a student cannot move beyond dictionary meanings: (1) Give them three speeches from the play containing the same word (e.g., "ट्यूशन") spoken by different characters. (2) Ask them to annotate each occurrence with: speaker, emotion, implied meaning, thematic link. (3) Have them write a one-sentence "contextual definition" for each occurrence. (4) Finally, ask them to use the word in a new sentence that captures one of those contextual shades. This forces attention to speaker, situation, and subtext.

## BUILDS_ON
This node builds on the student's ability to identify speakers, dramatic situations, and thematic concerns established in the plot, character, and theme nodes of this chapter.

## LEADS_TO
This node enables the student to write analytically about language use in the Grammar (c11_hin_ar_cbse_06_011) and Comprehension (c11_hin_ar_cbse_06_012) nodes, where precise vocabulary interpretation is required for evidence-based answers.

## PREREQUISITE_NODE_IDS
c11_hin_ar_cbse_06_001, c11_hin_ar_cbse_06_002, c11_hin_ar_cbse_06_004, c11_hin_ar_cbse_06_006, c11_hin_ar_cbse_06_008, c11_hin_ar_cbse_06_009

## PREREQUISITE_REASONS
c11_hin_ar_cbse_06_001: Provides background on the education system and tuition culture essential for understanding words like "ट्यूशन" and "नीति".
c11_hin_ar_cbse_06_002: Knowledge of plot sequence helps locate where key words appear and their dramatic function.
c11_hin_ar_cbse_06_004: Understanding वफ़र's character reveals why he uses words like "ट्यूशन" with desperation.
c11_hin_ar_cbse_06_006: Primary theme (commercialization of education) frames the semantic field of words like "फर्जीवाड़ा", "नैक्यवांक"ख".
c11_hin_ar_cbse_06_008: Vocabulary study includes metaphorical usages of key words (e.g., "भट्टी", "घड़ा").  
c11_hin_ar_cbse_06_009: Key vocabulary (जूठन, बुहारना, नियम) gains depth when understood as ironic/symbolic terms.  

## FORWARD_NODE_IDS
c11_hin_ar_cbse_06_011, c11_hin_ar_cbse_06_012, c11_hin_ar_cbse_06_013, c11_hin_ar_cbse_06_014, c12_hin_a_cbse_07_010, c12_hin_ar_cbse_12_010

## FORWARD_REASONS
c11_hin_ar_cbse_06_011: Grammar analysis requires identifying parts of speech and syntactic patterns of key words in context.
c11_hin_ar_cbse_06_012: Comprehension answers need precise vocabulary interpretation for textual evidence.
c11_hin_ar_cbse_06_013: Critical thinking demands evaluating author's word choices for thematic impact.
c11_hin_ar_cbse_06_014: Writing tasks require using chapter vocabulary appropriately in analytical essays.
c12_hin_a_cbse_07_010: Compared standard vs. dialect synonyms in modern poetry.  
c12_hin_ar_cbse_12_010: Practiced tonal analysis of vocabulary — used in Diagnostic Q4.  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
none

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_06_001 -> c11_hin_ar_cbse_06_010 -> c11_hin_ar_cbse_06_011

## THIS_FORMULA
Contextual Meaning = (Dictionary Meaning) + (Speaker's Intent) + (Dramatic Situation) + (Thematic Resonance) + (Socio-cultural Register)

## FORMULA_VARIABLES
- Dictionary Meaning: Standard lexical definition.
- Speaker's Intent: What the character aims to achieve (persuade, mock, threaten, etc.).
- Dramatic Situation: The immediate conflict, relationship, and emotional climate.
- Thematic Resonance: How the word echoes the chapter's central ideas.
- Socio-cultural Register: The language variety (formal, colloquial, bureaucratic, code-mixed) signaling identity and power.

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
linguistic

## CROSS_SUBJECT
c11_sociology_education | The chapter's vocabulary reflects sociological concepts like "cultural capital" (code-mixing as elite marker), "institutional isomorphism" (नीति as ritual), and "shadow education" (ट्यूशन as parallel system).
c11_economics_market_failure | Words like "फर्जीवाड़ा", "बैकसडेट", "नैक्यवांक"ख" illustrate information asymmetry, regulatory capture, and credential inflation in the education market.

## PREREQ_CONCEPT
Ability to distinguish between denotation (literal meaning) and connotation (associated feelings/ideas) in a dramatic text.

## PREREQ_BEFORE
Student must have read the full chapter "जतूह" and identified the main characters, central conflict, and at least three recurring themes.

## PREREQ_STUCK
If stuck, review the character analysis of वफ़र and जतूह (c11_hin_ar_cbse_06_004) and the theme of commercialization (c11_hin_ar_cbse_06_006) to anchor vocabulary in character and theme.

## WORKED_EXAMPLE_1
PROBLEM: Analyze the word "कोड-मिक्सिंग" (code-mixing) as used by यथ्यक in the line: "क्ल-क्ल, ई ले> x;k vkidh lkjh rdyhI+kQ] vkidk lkjk xqLlkA" (Act 2). Explain how this meta-linguistic term functions dramatically.

STEPS:
- Step 1: Identify the speaker (यथ्यक), listener (जतूह), and situation (यथ्यक mocks जतूह's polished English-Hindi mixing after being confronted).
- Step 2: Note the dictionary meaning: mixing two languages in one utterance. But here, यथ्यक uses the *term* "कोड-मिक्सिंग" itself, not just doing it.
- Step 3: Analyze Speaker's Intent: यथ्यक weaponizes linguistic terminology to expose जतूह's elitism and hypocrisy — he claims to defend Hindi but speaks in mixed code.
- Step 4: Examine Dramatic Situation: This occurs right after जतूह's high-minded speech; the term punctures his authority by labeling his language performance.
- Step 5: Connect to Themes: "कोड-मिक्सिंग" becomes a symbol of urban privilege and the disconnect between policy rhetoric (Hindi promotion) and practice (English dominance).
- Step 6: Socio-cultural Register: The term itself is academic/sociolinguistic, marking यथ्यक as intellectually sharp despite her subordinate position.

REASONING: The word is not just vocabulary; it's a dramatic device that reveals character, advances conflict, and embodies theme. The analysis must layer all five formula variables.

ANSWER: In this context, "कोड-मिक्सिंग" functions as a satirical label that יथ्यक applies to जतूह's speech to expose the gap between his ideological stance (pro-Hindi) and linguistic practice (English-Hindi mixing). It carries connotations of elitism, performative bureaucracy, and the colonization of Indian education by English. The term shifts from a linguistic descriptor to a weapon of class critique.

## WORKED_EXAMPLE_2
PROBLEM: The word "ट्यूशन" appears 14 times in the play. Trace its semantic shift across three key moments: (a) वफ़र's first mention (Act 1), (b) जतूह's confrontation with the Director (Act 2), (c) Final monologue (Act 3). Show how the same word accumulates meaning.

STEPS:
- Step 1: Locate each occurrence in the text (Act 1: वफ़र says "ट्यूशन पढ़ाकर गुजारा करती हूँ"; Act 2: जतूह says "ट्यूशन के नाम पर चलने वाला यह फर्जीवाड़ा"; Act 3: जतूह says "ट्यूशन एक बीमारी है...").
- Step 2: For each, note Speaker, Listener, Emotional Tone, and Immediate Goal.
- Step 3: Extract Contextual Meaning using the formula: Act 1 = livelihood/survival (denotative + personal); Act 2 = systemic corruption (connotative + accusatory); Act 3 = social pathology (metaphorical + diagnostic).
- Step 4: Identify the trajectory: Personal necessity → Institutional racket → Civilizational disease.
- Step 5: Link to Thematic Arc: The word's evolution mirrors the play's movement from individual struggle to systemic indictment.
- Step 6: Verify with textual evidence: Each usage is supported by surrounding dialogue and stage directions.

REASONING: Vocabulary in context is dynamic; a key word's meaning deepens as the drama unfolds. Tracking this shift demonstrates how language constructs the play's argument.

ANSWER: "ट्यूशन" begins as a concrete noun for वफ़र's income source (Act 1), transforms into a synecdoche for institutional corruption in जतूह's accusation (Act 2), and finally becomes a metaphor for societal decay in the climax (Act 3). The word accumulates the play's entire critique: from symptom to system to sickness.

## WORKED_EXAMPLE_3
PROBLEM: In the Director's line "शिक्षा नीति के अनुसार...", the phrase "शिक्षा नीति" is used to legitimize an unethical order. Deconstruct how this bureaucratic collocation functions as "legitimation discourse" (Fairclough). Compare with how a sociologist would analyze the same phrase in a policy document.

STEPS:
- Step 1: Define "legitimation discourse": language used to justify power by appealing to authority, rules, or values.
- Step 2: Analyze the Director's utterance: Speaker = authority figure; Situation = pressured by जतूह; Goal = deflect accountability.
- Step 3: Apply formula: Dictionary meaning = government policy on education. Speaker's Intent = invoke higher authority to shut down debate. Dramatic Situation = confrontation in office. Thematic Resonance = policy as shield for corruption. Register = formal bureaucratic Hindi.
- Step 4: Contrast with sociological use: In a policy document, "शिक्षा नीति" refers to a framework with goals, stakeholders, implementation plans. It is prescriptive and aspirational.
- Step 5: Identify the irony: The Director empties the phrase of its aspirational content, retaining only its authoritarian force.
- Step 6: Synthesize: The play exposes the gap between policy-as-text and policy-as-weapon.

REASONING: This example combines linguistic analysis with critical discourse concepts, showing how vocabulary operates at the intersection of language, power, and ideology — a senior secondary competency.

ANSWER: In the Director's mouth, "शिक्षा नीति" is a performative legitimation device: it borrows the authority of the state to silence dissent. Unlike its use in policy documents (where it denotes a deliberative framework), here it denotes a ritualized incantation that masks arbitrariness. The collocation "के अनुसार" (according to) completes the bureaucratic theater. The play thus reveals how vocabulary can be hollowed out to serve power.

## COMPETENCY_QUESTION_1
QUESTION: In the board exam, you are asked: "जतूह में 'फर्जीवाड़ा' शब्द का प्रयोग किस प्रसंग में हुआ है? यह शब्द नाटक की केंद्रीय चिंता को कैसे अभिव्यक्त करता है?" Write a structured answer (100-120 words) using the PEEL method (Point, Evidence, Explanation, Link).

COMPETENCY: Textual evidence-based analytical writing with thematic integration.

STEPS:
- Step 1: Point — Identify the exact context: जतूह uses "फर्जीवाड़ा" in Act 2 when confronting the Director about tuition racket.
- Step 2: Evidence — Quote/paraphrase: "ट्यूशन के नाम पर चलने वाला यह फर्जीवाड़ा..."
- Step 3: Explanation — Analyze why "फर्जीवाड़ा" (not "धोखा" or "भ्रष्टाचार"): implies organized, recurring, multi-actor fraud; captures systemic nature.
- Step 4: Link — Connect to central concern: commercialization of education, erosion of trust, victimization of poor students like वफ़र.
- Step 5: Polish — Ensure formal Hindi, cohesive devices, and word limit.

ANSWER: "फर्जीवाड़ा" शब्द का प्रयोग जतूह द्वारा निदेशक के सामने किया जाता है जब वह ट्यूशन के नाम पर चल रहे संगठित भ्रष्टाचार को उजागर करती है। "ट्यूशन के नाम पर चलने वाला यह फर्जीवाड़ा..." — यहाँ "फर्जीवाड़ा" मात्र धोखा नहीं, बल्कि एक संस्थागत, आवर्ती और बहु-पक्षीय छल को दर्शाता है जिसमें स्कूल, ट्यूटर और अधिकारी सम्मिलित हैं। यह शब्द नाटक की केंद्रीय चिंता — शिक्षा के बाज़ारीकरण और गरीब विद्यार्थियों (जैसे वफ़र) के शोषण — को सटीकता से अभिव्यक्त करता है। "नीति" की आड़ में चल रहे इस "फर्जीवाड़े" के विरुद्ध जतूह का यह शब्द प्रतिरोध का भाषाई हथियार बन जाता है।

DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: A student writes in the exam: "नाटक में 'कोड-मिक्सिंग' शब्द का प्रयोग यह दिखाता है कि पात्र अंग्रेजी जानते हैं।" Critique this answer. Identify the misconception, explain why it is insufficient for Class 11, and rewrite the answer to meet board standards.

COMPETENCY: Critical evaluation of peer response; meta-cognitive awareness of analytical depth.

STEPS:
- Step 1: Identify the misconception: Reducing a socio-linguistic term to a mere display of English knowledge; ignoring power dynamics, irony, and thematic function.
- Step 2: Explain insufficiency: Class 11 requires analysis of *how* language constructs meaning in context, not just factual observation. The answer misses speaker intent, dramatic irony, and theme.
- Step 3: Rewrite using PEEL: Point — यथ्यक uses the term "कोड-मिक्सिंग" meta-linguistically to critique जतूह's linguistic performance. Evidence — "क्ल-क्ल, ई ले> x;k vkidh lkjh rdyhI+kQ..." Explanation — It exposes the gap between जतूह's pro-Hindi stance and his English-mixed speech, symbolizing elite capture of education policy. Link — Reinforces theme: language as marker of privilege and tool of exclusion.
- Step 4: Final polished answer in formal Hindi.

ANSWER: The student's answer reflects a surface-level misconception: treating "कोड-मिक्सिंग" as a decorative detail rather than a dramatic device. It fails to analyze *who* uses the term, *why*, and *what it reveals*. Board-standard rewrite: यथ्यक "कोड-मिक्सिंग" शब्द का प्रयोग जतूह के भाषाई आडंबर को उघाड़ने के लिए करती है। जब जतूह हिंदी की वकालत करते हुए अंग्रेजी-मिश्रित हिंदी बोलते हैं, तब यथ्यक व्यंग्यपूर्वक कहती है — "क्ल-क्ल, ई ले> x;k vkidh lkjh rdyhI+kQ..." यहाँ "कोड-मिक्सिंग" भाषिक विवरण न होकर वर्गीय विशेषाधिकार और नीति-व्यवहार के अंतर का प्रतीक बन जाता है। यह नाटक की केंद्रीय चिंता — शिक्षा तंत्र में अंग्रेजी का वर्चस्व और हिंदी की सजावटी पैरवी — को भाषाई विडंबना के माध्यम से व्यक्त करता है।

DIFFICULTY: hard