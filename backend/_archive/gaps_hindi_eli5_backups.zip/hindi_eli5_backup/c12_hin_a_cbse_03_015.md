## DEFINITION
Speaking and Listening: Discussion Points refers to the structured oral activity where students articulate reasoned interpretations of the poems "nhi vosQyk" and "eSaus ns[kk] ,d cw¡n" by vKs;, actively listen to peers' perspectives, and collaboratively explore themes of individuality vs. society, the symbolism of colour, and the poet's humanistic vision — using textual evidence to support every claim.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student can independently initiate and sustain a 3-minute discussion on either poem by: (1) stating a clear interpretive claim rooted in a specific stanza or line, (2) citing textual evidence (imagery, metaphor, refrain) without reading verbatim, (3) explaining how the evidence supports the claim, (4) responding to a peer's counter-point by either conceding with nuance or rebutting with additional evidence, and (5) summarizing the group's emergent understanding in one sentence.

## SCOPE_BOUNDARY
This node covers ONLY the speaking and listening discussion points derived from the two poems in Chapter 3 (Antra). It does NOT cover writing formal answers, grammar exercises, or literary device identification in isolation — those are addressed in sibling nodes c12_hin_a_cbse_03_008 to c12_hin_a_cbse_03_014. The focus is exclusively on oral formulation, evidence-based argumentation, and collaborative meaning-making.

## WALKTHROUGH
Imagine you're in a college seminar where the professor asks: "What does this poem *do* to you — and *how* does it do it?" You can't just say "it's nice" or "it's about a child." You need to point to the exact moment — the refrain "nhi vosQyk Lusg Hkjk gS xoZ Hkjk enekrk" — and explain how its repetition builds a demand for acceptance. Start by reading the poem aloud *twice*: first for rhythm, second to mark every image that surprises you (e.g., "xhr" and "eksrh" as metaphors for societal labels). Then, in a group of three, assign roles: Speaker (presents claim + evidence), Listener (paraphrases then asks a probing question), Synthesizer (connects both views to the central theme). The key insight: discussion isn't sharing opinions — it's *testing* interpretations against the text together.

## DIAGNOSTIC_QUESTION_1
What is the primary function of the refrain "ij bldks Hkh iafDr dks ns nks" in the poem "nhi vosQyk"?

## DIAGNOSTIC_ANSWER_1
The refrain acts as a structural anchor that transforms the poem from a description of a marginalized child into a direct address to society ("iafDr"), demanding not pity but *rightful inclusion* ("ns nks" — give her space). A wrong answer like "it repeats the main idea" reveals the student sees repetition as mere emphasis, not as a rhetorical device that shifts the poem's address from third-person observation to second-person command — a critical distinction for Board long-answer questions.

## DIAGNOSTIC_QUESTION_2
In "eSaus ns[kk] ,d cw¡n", the line "jax xbZ {k.kHkj <yrs lwjt dh vkx ls" uses colour imagery. Explain in your own words what the "colour flying off the brush" suggests about the child's creativity, and why the poet contrasts it with "lEeq[k cw¡n" (the tall building).

## DIAGNOSTIC_ANSWER_2
The flying colour signifies spontaneous, uncontainable creativity that escapes rigid structures ("lwjt" — brush/stroke), while the "tall building" represents standardized, institutional education that measures worth by height/conformity. A wrong answer like "the child is painting a building" reveals literal reading that misses the metaphor: the building is not the subject of the painting but the *system* the child's art defies. This confusion costs marks in both Board (inference) and CUET (critical reasoning) questions.

## DIAGNOSTIC_QUESTION_3
During a discussion, a peer says: "Both poems are just about sad children." Using evidence from *both* poems, formulate a 45-second spoken rebuttal that distinguishes the *agency* of the child in each poem.

## DIAGNOSTIC_ANSWER_3
Step 1: Acknowledge the surface similarity — both center a child. Step 2: Contrast agency: In "nhi vosQyk", the child *speaks* through the poet's voice (";g vf}rh; µ ;g esjk µ ;g eSa Lo;a folftZr") claiming self-definition. In "eSaus ns[kk]", the child *acts* — "jax xbZ {k.kHkj" — creativity as resistance. Step 3: Cite the refrain in Poem 1 ("iafDr dks ns nks") as a demand for rights, vs. Poem 2's "u'ojrk osQ nkx ls" (from the peak of wonder) as reclaiming joy. Step 4: Conclude: "One demands justice; the other celebrates freedom — neither is passive sadness." A weak rebuttal that only quotes lines without interpreting agency shows inability to synthesize across texts — a JEE/CUET-level comparative skill.

## DIAGNOSTIC_QUESTION_4
Analyze how the poet's use of colloquial/vernacular words ("xhr", "eksrh", "lfeèkk", "fcjyk") in "nhi vosQyk" functions *both* to characterize the child's world and to challenge literary Hindi norms. Provide two specific examples.

## DIAGNOSTIC_ANSWER_4
The words root the poem in the child's lived reality: "xhr" (scavenger) and "eksrh" (mother) are not abstract labels but identities imposed by society; "lfeèkk" (play) and "fcjyk" (unique) reclaim dignity through the child's own lexicon. Simultaneously, inserting these into a "shuddh" Hindi poem disrupts the hierarchy that privileges Sanskritized vocabulary — the poem *enacts* the inclusion it demands. A student who only lists the words without explaining this dual function (characterization + linguistic politics) misses the poet's deliberate craft — a point explicitly rewarded in Board marking schemes for "critical appreciation."

## DIAGNOSTIC_QUESTION_5
Evaluate this interpretation: "The poem 'eSaus ns[kk] ,d cw¡n' is ultimately pessimistic because the child's colour flies away ('jax xbZ'), suggesting creativity is lost." Defend or refute using the poem's closing lines.

## DIAGNOSTIC_ANSWER_5
Refute. The colour "flying off" ("xbZ") is not loss but *liberation* — it escapes the "brush" (tool/control) and the "tall building" (institution). The closing image "u'ojrk osQ nkx ls" (from the peak of wonder) and "mUekspu" (absorbing/transcending) frames the child's vision as *expansive*, not defeated. A student calling it pessimistic confuses "departure from convention" with "destruction" — a common error when reading metaphor as literal narrative. Board examiners penalize this as "superficial reading ignoring tonal shift."

## DIAGNOSTIC_QUESTION_6
Create a 2-minute discussion prompt for a peer group that *requires* them to connect the metaphor of "lkxj" (street) in "eSaus ns[kk]" with the concept of "iafDr" (society/court) in "nhi vosQyk". The prompt must be open-ended and text-dependent.

## DIAGNOSTIC_ANSWER_6
Strong prompt: "In 'eSaus ns[kk]', the child's creativity begins 'lkxj osQ >kx ls' (from the street's edge), while in 'nhi vosQyk', the poet appeals to 'iafDr' (society) to 'ns nks' (give space). Both poems position the marginalized at a boundary — one physical, one institutional. Discuss: *Does the street offer more freedom than the court? Use one image from each poem to support your view.*" A weak prompt like "Compare the two poems" fails because it allows vague generalizations. This prompt forces textual anchoring and comparative reasoning — exactly what CUET "case-based discussion" tasks assess.

## COMMON_MISCONCEPTION
Students treat "discussion" as *turn-taking monologues*: each person shares a pre-memorized summary or favourite line, with no listening, no building, no evidence-demand. They say "I think the poem is about..." instead of "In stanza 3, the image of X suggests Y because..." — confusing *opinion* with *interpretation*. This stems from school "speaking assessments" that reward fluency over reasoning. In Board ASL and CUET interviews, examiners explicitly mark down "lack of textual grounding" and "failure to engage with peer's point."

## ON_FAILURE
1. **Revisit c12_hin_a_cbse_03_008 (Imagery/Metaphor) and c12_hin_a_cbse_03_009 (Irony/Symbolism)** — re-learn how to *name* the device and *explain its effect* in one sentence. 2. **Practice the "Evidence Sandwich" drill**: Pick one line → State claim → Quote phrase → Explain link → Connect to theme. Do this for 5 lines from each poem. 3. **Record a 2-min solo discussion** on your phone; replay and check: Did I cite text? Did I explain *how* it supports me? Did I avoid "I feel"? 4. **Pair with a peer**: Use the "Listener" role — paraphrase their point, then ask "What line shows that?" — forces both to anchor in text.

## BUILDS_ON
The skill of evidence-based oral interpretation built in Class 11 Speaking/Listening nodes (c11_hin_ar_cbse_03_015) across all chapters, now applied to vKs;'s complex dual-poem structure requiring cross-text synthesis.

## LEADS_TO
University-level seminar participation, CUET/IPMAT personal interview articulation, and professional workplace collaborative problem-solving where claims must be grounded in shared data/text.

## PREREQUISITE_NODE_IDS
c12_hin_a_cbse_03_001, c12_hin_a_cbse_03_002, c12_hin_a_cbse_03_006, c12_hin_a_cbse_03_008, c12_hin_a_cbse_03_009, c12_hin_a_cbse_03_012, c12_hin_a_cbse_03_013, c11_hin_ar_cbse_03_015, c11_hin_v_cbse_03_015, c12_hin_a_cbse_03_014

## PREREQUISITE_REASONS
c12_hin_a_cbse_03_001: Provides biographical/historical context of vKs; essential for interpreting his humanistic stance in discussion. c12_hin_a_cbse_03_002: Narrative structure of each poem (stanza progression, refrain placement) needed to navigate discussion flow. c12_hin_a_cbse_03_006: Primary theme (individual dignity vs. social exclusion) is the core discussion anchor. c12_hin_a_cbse_03_008: Imagery/metaphor analysis supplies the textual evidence for claims. c12_hin_a_cbse_03_009: Irony/symbolism understanding enables deeper interpretation (e.g., "vf}rh;" as ironic self-assertion). c12_hin_a_cbse_03_012: Literal/inferential comprehension ensures baseline understanding before analysis. c12_hin_a_cbse_03_013: Critical thinking models the analytical moves (compare, evaluate, synthesize) required in discussion. c11_hin_ar_cbse_03_015: Class 11 Antra Chapter 3 speaking/listening practice provides the procedural foundation for structured discussion. c11_hin_v_cbse_03_015: Class 11 Vitan Chapter 3 speaking/listening extends exposure to discussion formats across textbooks.
c12_hin_a_cbse_03_014: Speaking/Listening requires the same analytical content (Points, Evidence) but demands oral fluency, real-time structuring, and responsive linking — the performative extension of written PEEL.  
c12_hin_a_cbse_03_002: Plot and narrative structure in poetry refers to the deliberate organization of images, id... की समझ आवश्यक है, क्योंकि यह नोड (Speaking and Listening:) इसी आधार पर आगे बढ़ता है।  
c12_hin_a_cbse_03_006: The primary theme of a literary work is its central, unifying idea or insight about life/h... की समझ आवश्यक है, क्योंकि यह नोड (Speaking and Listening:) इसी आधार पर आगे बढ़ता है।  
c12_hin_a_cbse_03_008: Imagery (बिंब) refers to the use of vivid, sensory language that appeals to the five sense... की समझ आवश्यक है, क्योंकि यह नोड (Speaking and Listening:) इसी आधार पर आगे बढ़ता है।  
c12_hin_a_cbse_03_009: Irony (व्यंग्य/विडंबना) is a literary device where the intended meaning of words or events... की समझ आवश्यक है, क्योंकि यह नोड (Speaking and Listening:) इसी आधार पर आगे बढ़ता है।  
c12_hin_a_cbse_03_012: Speaking/listening discussions use comprehension as basis for oral analysis  
c12_hin_a_cbse_03_013: Speaking/listening discussions need interpreted positions (not just summaries) to sustain meaningful debate.  
c11_hin_ar_cbse_03_015: Speaking and Listening: की समझ आवश्यक है, क्योंकि यह नोड (Speaking and Listening:) इसी आधार पर आगे बढ़ता है।  
c11_hin_v_cbse_03_015: Speaking and Listening discussion points for "वक़्स-वहाँ" are structured conversational fr... की समझ आवश्यक है, क्योंकि यह नोड (Speaking and Listening:) इसी आधार पर आगे बढ़ता है।  

## FORWARD_NODE_IDS


## FORWARD_REASONS
This is the terminal node of Chapter 3; no subsequent nodes in this chapter depend on it.

## CROSS_SUBJECT_PREREQS
c11_hin_ar_cbse_03_015, c11_hin_v_cbse_03_015
## CROSS_SUBJECT_REASONS
c11_hin_ar_cbse_03_015: Class 11 Antra Chapter 3 speaking/listening node established the discussion protocol (roles, evidence use) that this Class 12 node advances with more complex texts. c11_hin_v_cbse_03_015: Class 11 Vitan Chapter 3 speaking/listening provided practice in discussing non-fiction prose, building the transferable skill of evidence-based oral argument now applied to poetry.
c11_hin_v_cbse_03_015: अन्य विषय की सहायता: Speaking and Listening discussion points for "वक़्स-वहाँ" are structured conversational fr... के तत्व इस नोड में प्रयुक्त होते हैं।  

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_03_015 -> c12_hin_a_cbse_03_015 -> N/A (terminal node in chapter sequence)

## THIS_FORMULA
N/A - conceptual

## FORMULA_VARIABLES
N/A

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
linguistic

## CROSS_SUBJECT
N/A | The poem "nhi vosQyk" critiques social exclusion similarly to how historiography examines marginalized voices in nationalist narratives — both require interpreting silence and agency in texts. c12_political_science_rights_discourse | The refrain "iafDr dks ns nks" directly invokes rights-based language; discussing it builds the vocabulary for analyzing constitutional provisions on dignity and inclusion (Article 21, Directive Principles). c12_psychology_social_identity | The child's self-definition (";g eSa Lo;a folftZr") illustrates Tajfel's social identity theory — discussion of this link deepens interdisciplinary understanding of marginalization.
## PREREQ_CONCEPT
Evidence-based interpretive claim: the ability to move from "this line means X" to "this line *does* X by using device Y, which supports theme Z."

## PREREQ_BEFORE
Student must be able to identify at least three metaphors and the refrain structure in each poem, and state the central theme in one sentence.

## PREREQ_STUCK
If stuck, return to c12_hin_a_cbse_03_008 (Imagery/Metaphor) and re-do the "device → effect → theme" table for both poems.

## WORKED_EXAMPLE_1
PROBLEM: You are the Speaker in a 3-person discussion on "nhi vosQyk". Your task: Explain how the metaphor "xhr" (scavenger) and "eksrh" (mother) in stanza 2 function *together* to expose societal hypocrisy. You have 60 seconds.
STEPS:
- Step 1: Identify the two metaphors in the stanza — "xhr" (line 1) and "eksrh" (line 2) — and note they are socially assigned labels.
- Step 2: Recall from c12_hin_a_cbse_03_009 (Irony) that "xhr" is a caste-based occupation forced on the child, while "eksrh" is a universal nurturing role denied to her mother.
- Step 3: Formulate claim: "The poet juxtaposes these labels to show society reduces a child to her father's caste ('xhr') while ignoring her mother's humanity ('eksrh')."
- Step 4: Cite evidence: "iuMqCck µ ;s eksrh lPps fiQj dkSu Ñrh yk,xk" — the rhetorical question forces the listener to confront the injustice.
- Step 5: Link to theme: "This duality proves the poem's argument: individuality ('vf}rh;') is crushed by collective prejudice — hence the demand 'iafDr dks ns nks'."
REASONING: The steps move from device identification (Step 1) to contextual knowledge (Step 2) to claim formulation (Step 3) to textual anchoring (Step 4) to thematic synthesis (Step 5) — the exact cognitive chain Board examiners reward in ASL and long answers.
ANSWER: "In stanza 2, 'xhr' and 'eksrh' are not just descriptions — they are society's verdict. 'xhr' brands the child by birth; 'eksrh' erases the mother's identity. The poet asks: who made her a scavenger's daughter? Who denied her a mother? This irony — that the most human bond is negated by caste — is why the poem ends demanding space in 'iafDr', not charity."

## WORKED_EXAMPLE_2
PROBLEM: As Listener, your peer claims: "The 'tall building' in 'eSaus ns[kk]' represents the child's dream." You must paraphrase, then ask a text-dependent question that redirects to the correct interpretation.
STEPS:
- Step 1: Paraphrase neutrally: "So you're saying the 'lEeq[k cw¡n' symbolizes the child's aspiration — they want to reach that height."
- Step 2: Check text: The poem says "lwus fojkV~ osQ lEeq[k cw¡n dk leqnz ls vyx fn[kuk" — the *poet* sees the building *differently* from the child ("vyx" — different).
- Step 3: Identify the misreading: Peer conflates the building (institution) with the child's view (wonder/freedom).
- Step 4: Formulate probing question: "But the line says the poet sees it 'vyx' from the child — if the building is the child's dream, why would the poet's view differ? What does 'u'ojrk osQ nkx ls' suggest about where the child actually stands?"
- Step 5: Anticipate correction: Peer must now reconcile "peak of wonder" (child's position) with "tall building" (external standard).
REASONING: This models the Listener's critical role — not just nodding, but using textual precision to test interpretations. The question forces re-reading of the closing stanza, a skill tested in CUET "dialogue-based" questions.
ANSWER: "You see the building as the child's goal — but the text says the poet sees it *differently* ('vyx') from the child. And the child is at 'u'ojrk osQ nkx' (peak of wonder), not the building's top. So — is the building the child's dream, or the world's measure? Which line proves it?"

## WORKED_EXAMPLE_3
PROBLEM: Synthesizer role: After two peers discuss "individuality" in Poem 1 and "creative freedom" in Poem 2, you must produce a 30-second synthesis that connects both to vKs;'s humanism (from c12_hin_a_cbse_03_001 context) using the phrase "Lora=krk dk vkxzg" (glimpse of autonomy).
STEPS:
- Step 1: Recall context node: vKs; is called "izÑfr&izse vkSj ekuo&eu osQ var}±}ksa osQ dfo" — poet of individual consciousness and human love.
- Step 2: Map Peer 1's point (Poem 1): Child claims "vf}rh;" (specialness) and "folftZr" (completeness) — autonomy in *identity*.
- Step 3: Map Peer 2's point (Poem 2): Child's colour flies "lwjt dh vkx ls" (from brush's control) — autonomy in *expression*.
- Step 4: Identify common thread: Both poems show a child resisting external definition — one social (caste), one institutional (school).
- Step 5: Draft synthesis using key phrase: "Both poems give us 'Lora=krk dk vkxzg' — a glimpse of autonomy. In 'nhi vosQyk', it's the child naming herself (';g eSa Lo;a folftZr'); in 'eSaus ns[kk]', it's her art escaping the brush. vKs;'s humanism isn't abstract — it's this: every marginalized child carries a self that refuses to be built by others."
- Step 6: Check time and completeness: 30 seconds, names both poems, uses context, quotes text, uses required phrase.
REASONING: Synthesis is the highest discussion skill — it requires holding multiple analyses, accessing prior context, and producing a new, unified insight. This mirrors JEE Advanced "paragraph-based" questions and Board "critical appreciation" long answers.
ANSWER: "What connects both poems is 'Lora=krk dk vkxzg' — the glimpse of autonomy. The first child claims her self against caste (';g eSa Lo;a folftZr'); the second claims her vision against the institution ('jax xbZ {k.kHkj <yrs lwjt dh vkx ls'). vKs; shows us: human dignity isn't given by society or school — it's seized in the moment a child says 'this is me' or paints what no building can contain."

## COMPETENCY_QUESTION_1
QUESTION: In a recorded discussion for CUET Humanities, you are asked: "How does vKs; use the *sound* of the poems (rhythm, repetition, vernacular) to make the marginalized child's voice *heard* — not just described? Answer in 90 seconds with two specific sonic examples, one from each poem."
COMPETENCY: Oral articulation of literary analysis with textual evidence under time pressure (CUET/Board ASL pattern)
STEPS:
- Step 1: Open with direct thesis: "vKs; doesn't write *about* the child — he makes the poem *sound* like the child's world."
- Step 2: Example 1 (Poem 1): The refrain "nhi vosQyk Lusg Hkjk gS xoZ Hkjk enekrk / ij bldks Hkh iafDr dks ns nks" uses anapestic rhythm (da-da-DUM) mimicking a heartbeat/demand — and the colloquial "Lusg Hkjk / xoZ Hkjk" brings street speech into literary meter.
- Step 3: Example 2 (Poem 2): The line "jax xbZ {k.kHkj <yrs lwjt dh vkx ls" uses alliteration (x-b, x-b, l-w) to enact the colour's flight — sound enacts release.
- Step 4: Conclude: "Sound isn't decoration — it's the child's agency made audible."
ANSWER: "vKs; makes the child heard through sound. In 'nhi vosQyk', the refrain's driving rhythm — 'nhi vosQyk Lusg Hkjk gS xoZ Hkjk enekrk' — pounds like a demand, not a description. The vernacular 'Lusg Hkjk / xoZ Hkjk' forces literary Hindi to speak the child's language. In 'eSaus ns[kk]', 'jax xbZ {k.kHkj <yrs lwjt dh vkx ls' — the repeated 'x' and 'jh' sounds mimic colour scattering. The poem doesn't tell us the child is free; it *sounds* free. That's vKs;'s humanism: form becomes voice."
DIFFICULTY: hard

## COMPETENCY_QUESTION_2
QUESTION: A Board examiner asks: "Both poems end with an address to an audience — 'iafDr dks ns nks' and 'ftKklq] izcq¼] lnk J¼ke;] bldks HkfDr dks ns nks'. Compare the *nature of the demand* in each. Why does the first ask 'iafDr' (society) while the second asks 'ftKklq] izcq¼] lnk' (future generations/time)?" Answer in 2 minutes with textual evidence.
COMPETENCY: Comparative textual analysis with historical/literary context integration (Board long-answer / JEE Advanced paragraph type)
STEPS:
- Step 1: Identify the two addresses: Poem 1 → "iafDr" (society/court); Poem 2 → "ftKklq] izcq¼] lnk J¼ke;" (future/time/people).
- Step 2: Analyze Poem 1's demand: "iafDr dks ns nks" seeks *immediate inclusion* in existing social order — a rights claim *now*. Context: vKs; was a journalist/activist; this reflects contemporary Dalit/feminist demand for space.
- Step 3: Analyze Poem 2's demand: "ftKklq] izcq¼] lnk J¼ke;] bldks HkfDr dks ns nks" — asks future readers to *witness* ("HkfDr") the child's wonder. Not inclusion, but *preservation* of a vision that the present ("lEeq[k cw¡n") cannot contain.
- Step 4: Contrast: Poem 1 = political demand (justice now); Poem 2 = aesthetic/philosophical demand (truth for posterity).
- Step 5: Synthesize: vKs; spans both — the journalist demands rights; the poet archives wonder. Both are acts of resistance.
ANSWER: "The first poem addresses 'iafDr' — society as court — demanding *space now*: 'ns nks'. It's a citizen's claim: the child exists, so society must accommodate her. The second addresses 'ftKklq, izcq¼, lnk' — future time and people — asking them to *witness* ('HkfDr') the child's wonder that the present 'tall building' ignores. One says: 'Make room for me today.' The other says: 'Remember what I saw, because this world won't.' vKs; the activist speaks in Poem 1; vKs; the poet speaks in Poem 2. Both refuse erasure — one by law, one by memory."
DIFFICULTY: hard