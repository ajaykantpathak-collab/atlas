## DEFINITION
Critical Thinking: Analysis and Interpretation is the ability to examine a text deeply by breaking down its components (arguments, perspectives, evidence, literary techniques), evaluating their effectiveness, and synthesizing an independent, reasoned understanding of the author's intent, the text's broader implications, and its relevance to contemporary contexts.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student can independently deconstruct a passage from the chapter to identify the author's underlying assumptions, evaluate the strength of his arguments using textual evidence, and articulate a nuanced interpretation that connects the text's historical context to its enduring thematic significance.

## SCOPE_BOUNDARY
This node covers critical analysis of Nehru's "Bharat Mata" passage: evaluating his method of inquiry, interpreting the symbolism of "Bharat Mata," analyzing the unity-in-diversity argument, and assessing the text's relevance to modern Indian identity. It does NOT cover basic comprehension, vocabulary, grammar, or literary device identification (covered in prior nodes).

## WALKTHROUGH
Imagine you are a journalist today traveling through rural India, asking people "What does India mean to you?" just as Nehru did in the 1930s. You would hear vastly different answers shaped by caste, language, religion, and geography. Now, look at how Nehru handles this diversity in the text: he doesn't just record answers; he analyzes them to construct a unifying idea. To begin critical analysis, first identify the *central question* Nehru poses (What is this Bharat Mata?). Then trace how he uses *empirical observation* (peasants' responses) and *historical reasoning* (ancient unity) to build his answer. The key insight is that Nehru's "analysis" is itself an act of nation-building – he interprets diversity not as fragmentation but as the very substance of Indian unity.

## DIAGNOSTIC_QUESTION_1
What is the fundamental difference between *literal comprehension* (understanding what the text says) and *critical interpretation* (analyzing what the text means and implies) in the context of Nehru's "Bharat Mata" passage?

## DIAGNOSTIC_ANSWER_1
Literal comprehension identifies surface facts: Nehru travelled, asked peasants about Bharat Mata, received confused answers, and defined Bharat Mata as the people. Critical interpretation examines *why* Nehru chooses this anecdote, *how* the peasants' confusion serves his argument, and *what* his redefinition of "Bharat Mata" from a goddess to the people implies about his political philosophy. A wrong answer (e.g., "Comprehension is easy, interpretation is hard") reveals the student confuses difficulty level with cognitive process; they haven't grasped that interpretation requires questioning the author's choices and assumptions.

## DIAGNOSTIC_QUESTION_2
Nehru writes: "Bharat Mata ki jai" means victory to the people of India. Explain in your own words why Nehru deliberately shifts the referent of "Bharat Mata" from a mythological/deified entity to the *living population*, and what assumption about nationalism this shift relies upon.

## DIAGNOSTIC_ANSWER_2
Nehru shifts the referent to ground nationalism in tangible human reality rather than abstract mythology, making patriotism inclusive and democratic. This relies on the assumption that a nation is constituted *by* its people's shared struggles and aspirations, not by symbols imposed from above. A wrong answer (e.g., "He did it to be modern/secular") reveals a misconception that the shift is merely stylistic or ideological posturing, missing the structural argument: Nehru uses the peasants' own confusion ("Who is Bharat Mata?") as evidence that the *symbol* was alien to them, so the *reality* (the people) must become the new symbol.

## DIAGNOSTIC_QUESTION_3
Apply Nehru's method of "traveling and asking" to a contemporary issue: If you were to investigate "What does 'Development' mean to Indians today?" across three distinct regions (e.g., a tribal village in Jharkhand, a tech hub in Bengaluru, a flood-prone area in Assam), what *two* specific analytical criteria would you use to evaluate whether the responses reveal a unified national aspiration or fragmented local desires?

## DIAGNOSTIC_ANSWER_3
Criteria 1: **Structural Commonality** – Do responses share a core demand for *agency* (control over resources, decision-making) despite different material demands? Criteria 2: **Interconnectedness** – Do respondents recognize their fate as linked to others' (e.g., tribal villager understands urban policy affects forest rights)? A wrong answer (listing only topics like "jobs, roads, internet") reveals the student applies *data collection* but not *analytical framing*; they miss that Nehru's method analyzes *relationships* between responses, not just the responses themselves.

## DIAGNOSTIC_QUESTION_4
Analyze the relationship between the *anecdote of the peasant asking "Which Bharat Mata?"* and Nehru's *historical argument* about India's ancient cultural unity. How does the anecdote function as both *evidence* and *counter-evidence* for his thesis?

## DIAGNOSTIC_ANSWER_4
The anecdote is *evidence* for unity because the peasant *knows the slogan* ("Bharat Mata ki jai") across vast distances, proving a shared symbolic universe. It is *counter-evidence* because the peasant doesn't know *what* the symbol refers to, revealing a gap between elite nationalist discourse and popular consciousness. Nehru resolves this tension by redefining the symbol *through* the peasant's body – the peasant *is* Bharat Mata. A wrong answer (e.g., "The anecdote proves unity") shows the student cannot hold dialectical tension; they treat texts as linear arguments rather than sites of negotiation.

## DIAGNOSTIC_QUESTION_5
Evaluate the strength of Nehru's claim that "India's unity is not imposed from outside but grows from within." Consider the colonial context (British "divide and rule") and the text's own evidence of deep social divisions (caste, religion, language). Is his claim historically defensible or an aspirational projection? Justify.

## DIAGNOSTIC_ANSWER_5
It is an *aspirational projection* necessary for anti-colonial mobilization, not a fully defensible historical fact. The text itself admits divisions: "caste, religion, language... different customs." Nehru's "grows from within" refers to a *civilizational* continuity (shared myths, pilgrimages, epics) that *transcends* but does not *erase* divisions. The claim is strategically defensible as a *political philosophy* (unity-in-diversity) but historically contestable if read as empirical sociology. A wrong answer ("Yes, because he was Prime Minister" or "No, because Partition happened") reveals binary thinking; the student cannot evaluate a claim as *both* a rhetorical strategy and a historical argument.

## DIAGNOSTIC_QUESTION_6
Create a 4-line poetic stanza or a 3-sentence prose micro-narrative that reimagines the "Bharat Mata" encounter from the *peasant's perspective*, capturing their confusion, their lived reality, and their implicit critique of the nationalist intellectual's question.

## DIAGNOSTIC_ANSWER_6
*Example stanza:*
"Babu asks: 'Who is Mother India?'  
My fields are parched, my child coughs at night.  
I point to my calloused hands: 'She stands here,  
Hungry, waiting for the rain, not the slogan.'"
*A strong answer centers the peasant's material reality as the *true* referent, ironically fulfilling Nehru's redefinition while exposing the violence of the question. A weak answer (e.g., "The peasant says 'I don't know, ask the leader'") fails the creative task by not *inhabiting* the perspective; it stays in literal comprehension mode.*

## COMMON_MISCONCEPTION
Students often believe "Critical Thinking" means *criticizing* or *finding faults* with Nehru's views (e.g., "He ignored caste oppression" or "He was too idealistic"). This misconception arises because the word "critical" in everyday Hindi/English implies "negative judgment." In literary analysis, "critical" means *analytical* – examining *how* the text constructs meaning, *why* it makes certain choices, and *what* assumptions underlie it. For example, a student might write "Nehru is wrong because India is not united" instead of analyzing *how Nehru constructs the idea of unity as a political project*. This error prevents them from engaging with the text's intellectual architecture.

## ON_FAILURE
If a student falls into the "criticism = fault-finding" trap: (1) Give them a neutral text (e.g., a weather report) and ask them to "critically analyze" it – they'll realize analysis means examining *structure, evidence, omissions, audience*, not judging "good/bad." (2) Model the distinction: Show two responses to the peasant anecdote – Response A: "Nehru romanticizes peasants." Response B: "Nehru uses the peasant's ignorance of the symbol to argue that the symbol must be redefined *as* the peasant." (3) Have the student label each sentence in their own writing as "Judgment" or "Analysis." (4) Assign a micro-task: "Find one assumption Nehru makes about 'the people' and explain how it shapes his argument." This builds the habit of analytical detachment.

## BUILDS_ON
This node builds on the ability to identify themes, literary devices, and character perspectives (nodes 004-012) by requiring the student to *evaluate* how these elements work together to construct an argument.

## LEADS_TO
This node enables the student to write analytical essays (node 014) and participate in structured debates (node 015) where they must defend interpretations with textual evidence and logical reasoning.

## PREREQUISITE_NODE_IDS
c11_hin_ar_cbse_08_002, c11_hin_ar_cbse_08_004, c11_hin_ar_cbse_08_006, c11_hin_ar_cbse_08_008, c11_hin_ar_cbse_08_012, c11_hin_ar_cbse_08_005, c11_hin_ar_cbse_08_007, c11_hin_ar_cbse_08_009, c11_hin_ar_cbse_08_010

## PREREQUISITE_REASONS
c11_hin_ar_cbse_08_002: Plot/Narrative Structure provides the sequence of Nehru's journey and encounters, essential for analyzing his method of inquiry.
c11_hin_ar_cbse_08_004: Character Analysis (Protagonist/Nehru) gives insight into Nehru's persona as narrator-inquirer, whose perspective shapes the analysis.
c11_hin_ar_cbse_08_006: Primary Theme (Unity in Diversity) is the central claim that critical interpretation must evaluate.
c11_hin_ar_cbse_08_008: Literary Devices (Imagery/Metaphor) equips students to analyze *how* Nehru constructs the "Bharat Mata" metaphor.
c11_hin_ar_cbse_08_012: Comprehension (Literal/Inferential) ensures baseline understanding of events and explicit meanings before critical layer.
c11_hin_ar_cbse_08_005: Critical thinking requires analyzing how Nehru constructs his argument through selected voices - a skill built here.  
c11_hin_ar_cbse_08_007: Critical thinking requires synthesizing multiple secondary themes into a coherent interpretation of the text's complexity  
c11_hin_ar_cbse_08_009: Critical interpretation builds directly on device identification done here.  
c11_hin_ar_cbse_08_010: Critical thinking demands evaluating the author's lexical strategy (why 'दायरा' not 'सीमा'? why 'टुकड़ा' not 'भाग'?); this node supplies the analytical vocabulary for that evaluation.  

## FORWARD_NODE_IDS
c11_hin_ar_cbse_08_014, c11_hin_ar_cbse_08_015, c12_hin_a_cbse_08_013, c12_hin_al_cbse_02_013, c12_hin_ar_cbse_03_013, c12_hin_ar_cbse_08_013

## FORWARD_REASONS
c11_hin_ar_cbse_08_014: Writing Skills requires the analytical frameworks (claim-evidence-reasoning) developed here to structure high-scoring exam answers.
c11_hin_ar_cbse_08_015: Speaking/Listening Discussions demand the ability to articulate and defend interpretations generated in this node.
c12_hin_a_cbse_08_013: Class 11 critical thinking foundation — same skill applied to simpler texts.  
c12_hin_al_cbse_02_013: Analyzed how setting functions symbolically.  
c12_hin_ar_cbse_03_013: अगला तार्किक चरण: Critical Thinking: इस नोड की अवधारणाओं को सीधे उपयोग/विस्तारित करता है।  
c12_hin_ar_cbse_08_013: Class 11 critical thinking node established the PEEL framework and device-function linkage this node extends.  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
none

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_08_006 -> c11_hin_ar_cbse_08_013 -> c11_hin_ar_cbse_08_014

## THIS_FORMULA
N/A - conceptual

## FORMULA_VARIABLES
N/A

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
analytical

## CROSS_SUBJECT
c11_history_nationalism | Nehru's text is a primary source for analyzing the construction of Indian national identity; critical interpretation here mirrors historian's work of evaluating nationalist narratives.
c11_civics_constitution | The shift from "Bharat Mata as deity" to "Bharat Mata as people" prefigures the Constitutional shift from subjecthood to citizenship; analyzing this link develops civic literacy.
c11_sociology_unity_diversity | The text's central tension (unity vs. diversity) is a core sociological concept; critical analysis here builds skills for examining social cohesion in plural societies.

## PREREQ_CONCEPT
The student must understand the difference between *summary* (what happens) and *analysis* (why it matters/how it works).

## PREREQ_BEFORE
The student must have completed literal and inferential comprehension of the chapter (node 012) and identified the primary theme of unity in diversity (node 006).

## PREREQ_STUCK
If stuck, review "Theme: Primary Theme and Message" (node 006) to recall the central argument, then practice distinguishing *evidence* from *interpretation* using the peasant anecdote.

## WORKED_EXAMPLE_1
PROBLEM: Analyze how Nehru uses the *peasant's question* ("Which Bharat Mata?") to deconstruct the abstract nationalist symbol and reconstruct it as a democratic concept. Write a structured analytical paragraph (PEEL format).

STEPS:
- Step 1: Identify the *Point* – Nehru transforms a moment of ignorance into the foundation of his political philosophy.
- Step 2: Select *Evidence* – The peasant's confusion ("Is she the river? The mountain?") and Nehru's response ("You are Bharat Mata").
- Step 3: *Explain* the technique – The anecdote functions as a dialectical tool: thesis (slogan), antithesis (peasant's literalism), synthesis (redefinition).
- Step 4: *Link* to broader argument – This micro-encounter validates Nehru's macro-claim: unity emerges from recognizing the people *as* the nation, not from imposing symbols on them.
- Step 5: *Evaluate* significance – This move democratizes nationalism but risks erasing the very diversity (religious, cultural) the peasant's confusion represents.

REASONING: This 5-step process moves from textual detail to conceptual implication, modeling the "analysis -> interpretation -> evaluation" hierarchy required for board exams. It forces the student to treat the anecdote as *argumentative strategy*, not just narrative color.

ANSWER:
Nehru strategically deploys the peasant's bewilderment – "Which Bharat Mata? The river? The mountain?" – to dismantle the abstract, potentially exclusionary symbol of the goddess. By having the peasant voice the literalism that elite nationalism ignores, Nehru creates a dialectical opening: the slogan "Bharat Mata ki jai" circulates widely (thesis), but its referent is unknown to the very people it claims to represent (antithesis). Nehru resolves this by declaring, "You are Bharat Mata," grounding the nation in living humanity (synthesis). This micro-encounter encapsulates his macro-argument: Indian unity is not a top-down imposition but a bottom-up recognition of shared struggle. However, the analytical reader must note that this elegant synthesis risks smoothing over the peasant's actual material conditions (poverty, caste) which the text acknowledges but the metaphor subsumes.

## WORKED_EXAMPLE_2
PROBLEM: Compare Nehru's *method* of understanding India (travel, dialogue, empirical observation) with the *colonial method* (census, categorization, "divide and rule") implied in the text. What does this comparison reveal about Nehru's epistemology of the nation?

STEPS:
- Step 1: Extract Nehru's method from text – "I travelled... asked... listened... observed..." (inductive, empathetic, horizontal).
- Step 2: Identify colonial method from textual clues – "British told us we are not a nation... divide and rule... categories" (deductive, administrative, vertical).
- Step 3: Contrast the *epistemological stance* – Nehru seeks unity *through* diversity (dialogic); colonialism imposes unity *by* fixing diversity (taxonomic).
- Step 4: Analyze a specific textual moment – When Nehru asks peasants about Bharat Mata, he *learns*; when British categorize castes/tribes, they *fix* identities.
- Step 5: Interpret the political consequence – Nehru's method makes the nation a *becoming* (process); colonial method makes it a *being* (static category).
- Step 6: Connect to "Discovery of India" title – The title signals an ongoing epistemological project, not a finished essence.

REASONING: This comparative analysis requires synthesizing information across the text (method) and context (colonialism), a hallmark of senior-secondary critical thinking. It moves beyond "what Nehru thought" to "how Nehru knew."

ANSWER:
Nehru's epistemology is *participatory and inductive*: he discovers the nation by immersing himself in its heterogeneity – "from the Himalayas to Kanyakumari," listening to "peasants, workers, intellectuals." The colonial epistemology, implied by his reference to British claims that "India is not a nation," is *extractive and taxonomic*: it knows India through censuses, gazetteers, and rigid categories (caste, tribe, religion) designed for governance. The text juxtaposes these when Nehru describes British officials wondering at Indian unity despite diversity – their wonder reveals their categorical failure to grasp *organic* unity. Nehru's method treats diversity as *data for synthesis*; the colonial method treats diversity as *problems for management*. This contrast reveals Nehru's nation as a *dialogic process* ("I asked, they answered, we understood") versus the colonial nation as a *bureaucratic artifact*. The title "Discovery of India" thus names an epistemological stance: the nation is known only through the *act of relating* to its people.

## WORKED_EXAMPLE_3
PROBLEM: The text states: "Unity in diversity is not a slogan but a living reality." Critically evaluate this claim by analyzing *three* specific passages where the text *simultaneously asserts unity and records division*. What does this tension reveal about the nature of Nehru's "discovery"?

STEPS:
- Step 1: Locate Passage 1 – Peasants chant "Bharat Mata ki jai" (unity) but don't know who she is (division of consciousness).
- Step 2: Locate Passage 2 – "From the Himalayas to Cape Comorin... same pilgrimages, same epics" (cultural unity) vs. "different languages, customs, costumes" (social division).
- Step 3: Locate Passage 3 – "We are all children of the same mother" (metaphorical unity) vs. detailed description of caste hierarchy, untouchability, gender inequality (structural division).
- Step 4: Analyze the *rhetorical function* of each tension – Each unity claim is *immediately qualified* by empirical particularity; the text performs the unity it describes.
- Step 5: Evaluate the claim "not a slogan but living reality" – The claim is *aspirational*; the "living reality" is the *tension itself*, not a resolved harmony.
- Step 6: Synthesize – Nehru's "discovery" is the realization that Indian unity *is* the continuous negotiation of diversity, not its absence. The text *enacts* this by refusing to resolve its own contradictions.

REASONING: This multi-passage synthesis requires the student to hold contradictory textual evidence in productive tension, the essence of critical interpretation at Class 11 level. It connects literary form (the essay's dialectical structure) to political philosophy.

ANSWER:
Nehru's claim that unity-in-diversity is a "living reality, not a slogan" is critically validated *by* the text's own contradictions. Passage 1: The slogan "Bharat Mata ki jai" unites peasants across regions (unity), yet their ignorance of its referent reveals a fragmented consciousness (division). Passage 2: Shared pilgrimages and epics (Ramayana, Mahabharata) create a "cultural continuum" (unity), but the text simultaneously catalogs "hundreds of languages," "different customs," "varying costumes" (division). Passage 3: The metaphor "children of the same mother" asserts kinship (unity), yet the text unflinchingly describes "caste barriers," "untouchability," "women's subjugation" (division). The rhetorical pattern is consistent: every unity assertion is *immediately grounded* in lived particularity. This reveals that Nehru's "discovery" is not the *fact* of unity but the *mechanism* of unity: a civilization that *contains* its contradictions without collapsing. The "living reality" is precisely this dynamic equilibrium – the text performs it by refusing synthesis. Thus, the claim is not a description of a static state but a definition of a *political practice*: unity is the *continuous work* of acknowledging diversity.

## COMPETENCY_QUESTION_1
QUESTION: A Class 11 student writes in an exam: "Nehru proves India is united because everyone says 'Bharat Mata ki jai'." Using the concepts of *evidence*, *inference*, and *authorial strategy*, explain why this answer would receive low marks and rewrite it as a high-scoring analytical statement.

COMPETENCY: Analytical Writing / Textual Evidence Evaluation

STEPS:
- Step 1: Identify the flaw – The student treats the slogan as *proof* of unity, ignoring Nehru's own analysis of the slogan's *emptiness* without popular understanding.
- Step 2: Define the missing analytical move – Distinguish between *circulation of a symbol* (evidence of elite reach) and *internalization of meaning* (evidence of organic unity).
- Step 3: Apply authorial strategy – Nehru *uses* the slogan's emptiness to *argue for* redefinition; he doesn't cite it as proof of existing unity.
- Step 4: Rewrite using PEEL – Point: The slogan's circulation reveals a gap between nationalist discourse and popular consciousness. Evidence: Peasants chant it but ask "Which Bharat Mata?" Explanation: Nehru exploits this gap to ground the nation in the people. Link: This shows unity as an *achieved* political project, not a given fact.

ANSWER:
The original answer fails because it commits the *fallacy of equating repetition with comprehension*. It treats the text's *surface* (the slogan) as its *argument*, missing Nehru's entire analytical move: the slogan's *meaninglessness* to the peasants is the *evidence* he uses to *construct* a new meaning. High-scoring rewrite: "Nehru reveals that the widespread chant 'Bharat Mata ki jai' masks a profound disconnect: the peasants who shout it cannot identify its referent ('Is it the river? The mountain?'). This gap between symbol and understanding becomes the foundation of his democratic nationalism – he redefines Bharat Mata not as a goddess but as 'these millions of people.' Thus, unity emerges not from shared symbols but from the intellectual's *interpretive labor* to align symbols with lived reality."

DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: "Nehru's 'Discovery of India' is an act of *invention* as much as *discovery*." Defend or challenge this statement by analyzing *how* the text constructs the "peasant" as a rhetorical figure. Use at least two specific textual moments and the concept of *representative anecdote*.

COMPETENCY: Critical Evaluation / Rhetorical Analysis

STEPS:
- Step 1: Define "representative anecdote" (Kenneth Burke) – a specific story that stands for a whole system of beliefs.
- Step 2: Select Textual Moment 1 – The peasant asking "Which Bharat Mata?" functions as a representative anecdote for *popular ignorance/alienation from elite nationalism*.
- Step 3: Select Textual Moment 2 – The peasant who says "We are all one... children of the same mother" (later in text) functions as a representative anecdote for *innate civilizational wisdom*.
- Step 4: Analyze the *selection effect* – Nehru chooses peasants who *validate* his narrative arc (from confusion to clarity); he doesn't quote peasants who might say "Bharat Mata is a Brahmin goddess" or "We have no mother, only landlord."
- Step 5: Evaluate "invention vs. discovery" – The *discovery* is the empirical diversity; the *invention* is the framing of that diversity into a coherent national subject ("the people") through selective anecdotes.
- Step 6: Formulate judgment – The statement is *defensible*: Nehru discovers the raw material (diverse voices) but invents the national subject by curating which voices become "representative."

ANSWER:
The statement is defensible. Nehru *discovers* India's staggering heterogeneity through travel – "different languages, customs, castes" – but *invents* "the Indian people" as a unified political agent through *representative anecdotes*. Moment 1: The peasant asking "Which Bharat Mata?" is selected to represent the *problem* – the gap between elite symbols and popular consciousness. Moment 2: The peasant later affirming "We are all one... children of the same mother" is selected to represent the *solution* – an innate, civilizational unity that transcends elite discourse. Both anecdotes are *rhetorically curated*: the first peasant's confusion serves Nehru's argument for redefinition; the second peasant's wisdom serves his argument for organic unity. The text *silences* peasants whose voices might disrupt this arc (e.g., those for whom "Bharat Mata" evokes upper-caste domination). Thus, Nehru *discovers* the fragments but *invents* the mosaic. The "Discovery of India" is the *simultaneous* empirical encounter and imaginative construction of the nation.

DIFFICULTY: hard