## DEFINITION
The primary theme is the central, unifying idea or universal truth that the poem explores through its imagery, structure, and language; the message is the poet's specific insight or moral imperative conveyed through that theme. In Dadu Dayal's poetry, the primary theme is the *direct, inner realization of the Divine* (आत्म-साक्षात्कार) that transcends external rituals, caste boundaries, and scriptural literalism.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student can independently identify the primary theme of a Bhakti poem by tracing recurring motifs across stanzas, explain how the poet's use of vernacular metaphors (e.g., body as temple, breath as prayer) constructs that theme, and articulate the message in a structured answer using the PEEL format with textual evidence.

## SCOPE_BOUNDARY
This node covers identifying and articulating the *primary* theme and message of Dadu Dayal's prescribed poem (Aroh Chapter 9) using textual evidence from the poem's stanzas. It does NOT cover secondary themes (node 007), detailed literary device analysis (nodes 008, 009), or comparative analysis with other Bhakti poets.

## WALKTHROUGH
Imagine you are listening to a folk singer in a Rajasthan village singing a couplet that says "God is not in the temple nor the mosque, but in the breath you take right now." You instantly grasp the *message* — but in a board exam, you must prove *how* the poem builds that message across every stanza. Start by reading the poem aloud twice: first for the rhythm and sound of the Braj/khari boli mix, second to underline every word that points to "inside" (मन, साँस, घट, अंतर) versus "outside" (मंदिर, मस्जिद, काबा, काशी). Group these into two columns. The theme emerges from the tension between the columns. The key insight: Dadu Dayal doesn't just *state* the theme; he *enacts* it by making the poem's structure mirror the journey from outer search to inner discovery.

## DIAGNOSTIC_QUESTION_1
What is the difference between a 'theme' and a 'message' in a literary text? Answer in two sentences.

## DIAGNOSTIC_ANSWER_1
A theme is the broad, universal subject the text explores (e.g., "the search for truth"), while the message is the author's specific stance or lesson about that theme (e.g., "truth is found within, not in external rituals"). A wrong answer that treats them as synonyms reveals the student cannot distinguish between the *topic* of a work and the *author's argument* about that topic — a critical gap for board-level analytical answers.

## DIAGNOSTIC_QUESTION_2
In Dadu Dayal's poem, the line "घट घट में वासी राम" (Ram dwells in every heart/body) appears. A student writes: "The theme is God is everywhere." Why is this answer incomplete for a Class 11 board exam?

## DIAGNOSTIC_ANSWER_2
"God is everywhere" is a generic theological statement, not a literary theme derived *from this specific poem*. The correct theme must reflect Dadu's *particular* emphasis: the *accessibility* of the Divine through *inner awareness* (सुरति/सहज योग) *without* mediators (priests, scriptures, pilgrimages). A wrong answer shows the student confuses a universal religious idea with the poet's unique thematic construction using specific metaphors (body as vessel, breath as mantra).

## DIAGNOSTIC_QUESTION_3
Apply the "Inside vs. Outside" binary to Stanza 2 of the poem (which contrasts external pilgrimages with inner remembrance). List two concrete images from the stanza for each column.

## DIAGNOSTIC_ANSWER_3
**Outside column:** काबो (Kaba), काशी (Kashi), तीर्थ (pilgrimage sites), जोग (external yogic postures). **Inside column:** घट (body/heart), साँस (breath), सुरति (remembrance/awareness), सहज (natural/spontaneous state). A wrong answer that lists abstract nouns (faith, devotion) instead of the poem's *concrete metaphors* reveals the student cannot ground thematic analysis in textual evidence — a core board exam requirement.

## DIAGNOSTIC_QUESTION_4
Analyze how the poem's *repetition of the word 'सहज' (sahaj - natural/effortless)* across three stanzas shapes the primary theme. Explain in 3-4 sentences.

## DIAGNOSTIC_ANSWER_4
The repetition of 'सहज' transforms the theme from "God is inside" to "God is accessed *effortlessly* by dropping artificial effort." It structures the poem's argument: Stanza 1 rejects external effort (pilgrimage, ritual), Stanza 2 rejects forced yogic control (हठयोग), Stanza 3 affirms the natural state (सहज समाधि). A wrong answer that merely counts repetitions without linking each occurrence to a *stage in the thematic argument* shows the student treats repetition as decoration, not structural logic.

## DIAGNOSTIC_QUESTION_5
Evaluate this claim: "Dadu Dayal's primary message is anti-religious because he rejects temples, mosques, and scriptures." Defend or refute using two pieces of textual evidence.

## DIAGNOSTIC_ANSWER_5
Refute. The poem rejects *institutional mediation* and *mechanical ritual*, not spirituality itself. Evidence 1: "वेद कतेब कहत हैं झूठा, जो नहिं जाने अंतर की बात" — he critiques *literal reading* of scriptures, not the scriptures' core truth. Evidence 2: "हिंदू तुरक नहीं कोय, सब घट घट राम भरपूर" — he affirms a *universal* Divine presence transcending Hindu/Muslim labels. A wrong answer that agrees reveals a binary misunderstanding: the student equates "critique of externals" with "rejection of the sacred," missing the Bhakti movement's core reformist (not anti-religious) stance.

## DIAGNOSTIC_QUESTION_6
Write a 4-line stanza in Hindi (Khari Boli or Braj) that *extends* Dadu Dayal's primary message to a modern context (e.g., social media spirituality, app-based meditation). Use at least one metaphor from the original poem.

## DIAGNOSTIC_ANSWER_6
Example: "मोबाइल में मंत्र, फोटो में दर्शन, लाइक में पूजा पाई / घट घट का दाता भूल गया, सहज साँस नहिं भाई" — A strong answer adapts the "inside/outside" metaphor (साँस/घट) to contrast digital performance with embodied awareness. A poor answer that merely describes modern habits without the *thematic tension* (outer show vs. inner truth) shows the student cannot transfer the poem's structural logic to a new context.

## COMMON_MISCONCEPTION
Students conflate the *primary theme* with the *most repeated word* or the *first stanza's topic*. For example, seeing "Ram" frequently, they write "Theme: Ram bhakti." This error occurs because they read for *content* (what is mentioned) rather than *argument* (how the poet positions concepts against each other). Dadu Dayal mentions "Ram" precisely to *redefine* Ram as the inner witness (साक्षी), not the deity of Ayodhya — the theme is the *redefinition*, not the name.

## ON_FAILURE
1. Give the student a two-column template: "बाह्य साधन (External Means)" and "आंतरिक साधन (Internal Means)." 2. Ask them to fill it using *only* concrete nouns/verbs from the poem (e.g., मंदिर, माला, जप → outside; साँस, सुरति, सहज → inside). 3. Have them write one sentence starting: "The poem argues that ________ is superior to ________ because ________." 4. Verify the 'because' clause uses a *metaphor* from the poem (e.g., "because the body is the true temple"). This forces movement from word-spotting to argument-mapping.

## BUILDS_ON
c11_hin_ar_cbse_09_002 (Plot and Narrative Structure) — understanding the poem's stanza-by-stanza progression is prerequisite to tracing thematic development.

## LEADS_TO
c11_hin_ar_cbse_09_007 (Theme: Secondary Themes) — once the primary theme is fixed, secondary themes (communal harmony, guru-shishya dynamic, language as liberation) can be mapped as supporting strands.

## PREREQUISITE_NODE_IDS
c11_hin_ar_cbse_09_001, c11_hin_ar_cbse_09_002, c11_hin_ar_cbse_09_004, c11_hin_ar_cbse_09_005

## PREREQUISITE_REASONS
c11_hin_ar_cbse_09_001: Context (Dadu's Nirguni Bhakti background, 16th-century Rajasthan) is essential to decode why he rejects temples/mosques — it's a specific historical critique, not a generic one.
c11_hin_ar_cbse_09_002: The poem's narrative movement (outer search → inner realization → declaration) *is* the thematic argument; without mapping this structure, theme remains a static label.
c11_hin_ar_cbse_09_004: Dadu as protagonist-speaker (his voice, authority, direct address) establishes the *persona* through which the theme is delivered — the "I" who says "मैंने पाया" (I found).
c11_hin_ar_cbse_09_005: The primary theme of exploitation emerges directly from the relationship between protagonist and supporting characters.  

## FORWARD_NODE_IDS
c11_hin_ar_cbse_09_007, c11_hin_ar_cbse_09_008, c11_hin_ar_cbse_09_013, c11_hin_ar_cbse_09_010, c11_hin_ar_cbse_09_014, c11_hin_ar_cbse_09_015, c12_hin_a_cbse_09_006, c12_hin_ar_cbse_09_006, c12_hin_ar_cbse_12_006

## FORWARD_REASONS
c11_hin_ar_cbse_09_007: Secondary themes (e.g., social equality, anti-ritualism) branch *from* the primary theme of inner realization; they cannot be analyzed independently.
c11_hin_ar_cbse_09_008: Imagery (body as temple, breath as mantra) and metaphor (गुरु as inner guide) are the *vehicles* of the primary theme; device analysis presupposes thematic clarity.
c11_hin_ar_cbse_09_013: Critical interpretation (e.g., "Is Dadu's message relevant today?") requires a precisely articulated primary theme as the anchor for evaluation.
c11_hin_ar_cbse_09_010: Theme analysis identifies the chapter's central themes, which are the *meaning* that semantic fields construct. Without thematic clarity, vocabulary analysis becomes listing rather than interpreting — the student needs to know what theme to connect the word patterns to.  
c11_hin_ar_cbse_09_014: Primary theme (Nationalism/Poet's Duty) provides the core argument for any long answer.  
c11_hin_ar_cbse_09_015: Primary theme (equality) is the central topic around which most discussion points will revolve.  
c12_hin_a_cbse_09_006: Class 11 foundation on theme identification in Bhakti poetry (viraha, prem, samarpan) provides the conceptual toolkit.  
c12_hin_ar_cbse_09_006: Class 11 Theme node establishes the basic methodology for thematic analysis that Class 12 deepens.  
c12_hin_ar_cbse_12_006: Links irony/symbolism to theme — foundation for node 009.  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
none

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_09_001 -> c11_hin_ar_cbse_09_002 -> c11_hin_ar_cbse_09_004 -> c11_hin_ar_cbse_09_006 -> c11_hin_ar_cbse_09_007 -> c11_hin_ar_cbse_09_013

## THIS_FORMULA
N/A - conceptual

## FORMULA_VARIABLES
N/A

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
analytical

## CROSS_SUBJECT
c11_history_medieval_bhakti_movement | Dadu Dayal (1544-1603) was a key Nirguni Sant poet in the Bhakti movement; his rejection of caste, ritual, and institutional religion reflects the movement's radical egalitarian strand — historical context explains *why* the poem's theme is structured as an anti-establishment argument.
c11_civics_secularism_constitutional_values | The poem's line "हिंदू तुरक नहीं कोय, सब घट घट राम भरपूर" (No Hindu, no Turk — Ram fills every heart) prefigures the constitutional ideal of fraternity and equality before law; analyzing this connects literary theme to civic philosophy.
c11_geography_cultural_landscapes | The poem references Kaba, Kashi, and the Thar desert region — mapping these onto the cultural geography of Rajasthan/Gujarat shows how the theme of "universal access" emerges from a specific *syncretic landscape* where Hindu-Muslim shrines coexisted.

## PREREQ_CONCEPT
Stanza-by-stanza narrative progression (how the poem moves from problem to resolution) — without this, theme remains a list of topics.

## PREREQ_BEFORE
Student must be able to summarize each stanza in one sentence and identify the *turn* (volta) where the speaker shifts from describing external practices to advocating internal practice.

## PREREQ_STUCK
Review "narrative arc in poetry" (node 002) — specifically, practice identifying the *conflict* (outer search fails) and *resolution* (inner discovery succeeds) in 3 other Bhakti poems (Kabir, Meera, Ravidas).

## WORKED_EXAMPLE_1
PROBLEM: A board exam question asks: "दादू दयाल की कविता का केंद्रीय विषय क्या है? पाठ के आधार पर स्पष्ट कीजिए।" (What is the central theme of Dadu Dayal's poem? Explain with textual evidence.) Write a 4-point structured answer.

STEPS:
- Step 1: Identify the core tension — the poem contrasts *external religious performance* (pilgrimage, idol worship, scriptural recitation) with *internal realization* (breath-awareness, spontaneous meditation, guru's word within).
- Step 2: Select three stanzas that form the argument's spine: Stanza 1 (rejection of Kaba/Kashi), Stanza 2 (rejection of Hatha Yoga/mantra-japa), Stanza 3 (affirmation of Sahaj Samadhi/inner guru).
- Step 3: Extract one concrete metaphor per stanza as evidence: "काबो काशी छाँड़ि के" (external), "हठयोग न जप न तप" (rejected effort), "घट घट वासी राम" (internal presence).
- Step 4: Synthesize into a thematic statement: "The primary theme is *the primacy of direct, effortless inner experience (सहज अनभव) over mediated, effortful external practice* — the Divine is not 'out there' in sacred geography but 'in here' as the very breath of life."
- Step 5: Format as PEEL answer: Point (theme statement), Evidence (three metaphors), Explanation (how each metaphor advances the argument), Link (connect to Bhakti movement's core reform: accessibility of salvation).

REASONING: This 5-step process moves from *binary mapping* (inside/outside) to *structural selection* (which stanzas carry the argument) to *evidence-based synthesis* — exactly what board examiners reward. It avoids the trap of listing "devotion, God, guru" as themes.

ANSWER:
**केंद्रीय विषय:** दादू दयाल की कविता का केंद्रीय विषय है — **बाह्य आडंबरों एवं कर्मकांडों की निरर्थकता तथा अंतःकरण में सहज योग द्वारा परमात्मा की प्रत्यक्ष अनुभूति।**

**पाठगत प्रमाण सहित व्याख्या:**
1. **बाह्य तीर्थों का खंडन:** "काबो काशी छाँड़ि के, घट घट वासी राम" — कवि काबा-काशी जैसे पवित्र स्थलों को छोड़कर शरीर रूपी घट में ही राम की उपस्थिति घोषित करता है।
2. **हठयोग एवं मंत्र-जप की अस्वीकृति:** "हठयोग न जप न तप, सहज समाधि लखाई" — बलपूर्वक योग-साधना के स्थान पर सहज समाधि को श्रेष्ठ बताता है।
3. **गुरु का अंतर्निहित स्वरूप:** "गुरु घट घट में वासी, सुरति सँभाल सिखाई" — गुरु बाह्य व्यक्ति न होकर अंतर्यामी चेतना है जो सुरति (स्मृति/जागरूकता) जगाता है।

**निष्कर्ष:** कविता का संदेश है कि ईश्वर मंदिर-मस्जिद, वेद-कुरान या योग-क्रियाओं में नहीं, बल्कि प्रत्येक प्राणी के श्वास-श्वास में 'सहज' उपलब्ध है — यही निर्गुण भक्ति की क्रांतिकारी सुलभता है।

## WORKED_EXAMPLE_2
PROBLEM: The poem uses the metaphor "साँस साँस सुमिरन करो" (remember with every breath). Explain how this *single metaphor* encapsulates the primary theme. Write a 3-step analytical paragraph.

STEPS:
- Step 1: Deconstruct the metaphor — "साँस" (breath) is biological, involuntary, constant, and personal; "सुमिरन" (remembrance) is usually a voluntary, intermittent, ritual act (mala-japa). The metaphor *fuses* them.
- Step 2: Connect to theme — this fusion *is* the theme: spirituality becomes as natural and uninterrupted as breathing, removing the dichotomy between "religious time" (prayer hours) and "secular time" (daily life).
- Step 3: Contrast with rejected practices — unlike "माला फेरत जग भया" (the world rotates beads), which is mechanical and external, "साँस सुमिरन" is internal, automatic, and non-performative. The metaphor *enacts* the shift from effort (हठ) to effortlessness (सहज).

REASONING: Board exams often ask "explain the significance of a metaphor." The 3-step method (deconstruct → connect to theme → contrast with foil) ensures the answer analyzes *function*, not just meaning.

ANSWER:
"साँस साँस सुमिरन करो" रूपक कविता के केंद्रीय विषय — **सहज आंतरिक साधना की सर्वोच्चता** — को एक छवि में संघनित करता है। श्वास (साँस) अनैच्छिक, सतत और देहगत क्रिया है; सुमिरन (स्मरण) पारंपरिकतः ऐच्छिक, रुक-रुक कर होने वाला और बाह्य (माला, जप) कर्म है। दोनों को जोड़कर कवि साधना को **श्वास जितना सहज, जितना अनिवार्य और जितना अंतर्निहित** बना देता है। यह "माला फेरत जग भया, मन का मनका न फेरा" (बाह्य यांत्रिकता) के ठीक विपरीत है: यहाँ न माला चाहिए, न नियत समय, न आसन — श्वास ही मंत्र बन जाता है, देह ही मंदिर। इस प्रकार यह रूपक विषय का केवल वर्णन नहीं करता, बल्कि विषय को **अनुभव की संरचना** में बदल देता है।

## WORKED_EXAMPLE_3
PROBLEM: Compare Dadu Dayal's primary theme with Kabir's poem "मोको कहाँ ढूंढे रे बंदे" (included in Class 11 syllabus). Identify one shared thematic core and one critical difference in *how* each poet constructs that theme. Write a 6-step comparative analysis.

STEPS:
- Step 1: State shared core — both assert **Divine immanence in the human body/heart** and reject external search (temples, scriptures, rituals).
- Step 2: Map Dadu's construction — uses **positive prescription** ("साँस सुमिरन करो", "सहज समाधि लखाई") + **metaphors of naturalness** (breath, spontaneous absorption). Tone: invitational, instructional, calm.
- Step 3: Map Kabir's construction — uses **rhetorical negation** ("ना मैं मंदिर ना मस्जिद", "ना मैं काबे ना कैलास") + **urgent direct address** ("मोको कहाँ ढूंढे रे बंदे"). Tone: provocative, challenging, iconoclastic.
- Step 4: Analyze difference in *thematic emphasis* — Dadu emphasizes **method (साधन)**: *how* to realize (breath-awareness, guru's word). Kabir emphasizes **location (अवस्थान)**: *where* NOT to look, clearing false sites.
- Step 5: Link to historical persona — Dadu as *guru-founder* (Dadupanth) teaches a *path*; Kabir as *weaver-poet* disrupts *assumptions*. The theme is identical; the *thematic strategy* differs.
- Step 6: Synthesize for board answer — "Both poems share the Nirguni theme of 'God within,' but Dadu constructs it as a **positive pedagogy of Sahaj Yoga** while Kabir constructs it as a **negative dialectic of iconoclasm**."

REASONING: Comparative theme analysis is a high-order board skill. The 6-step method ensures: shared core → individual strategies → structural difference (prescription vs. negation) → tonal difference → historical reason → synthesized thesis. This avoids the "similarities and differences" list format that scores poorly.

ANSWER:
**साझा विषय:** कबीर और दादू दोनों **निर्गुण ब्रह्म की अंतर्निहित सत्ता** को केंद्रीय विषय बनाते हैं — "मोको कहाँ ढूंढे रे बंदे, मैं तो तेरे पास में" / "घट घट में वासी राम"।

**निर्माणगत अंतर (Thematic Strategy):**
1. **दादू: विधेय साधनोपदेश (Positive Pedagogy)** — "साँस साँस सुमिरन करो", "सहज समाधि लखाई", "गुरु घट घट में वासी" — कवि *क्या करें* बताता है; रूपक **प्रकृति/सहजता** के हैं (श्वास, लय, स्वाभाविकता)।
2. **कबीर: निषेधात्मक विवेचन (Negative Dialectic)** — "ना मंदिर ना मस्जिद", "ना काबे ना कैलास", "ना जप ना तप" — कवि *कहाँ न ढूंढें* बताता है; शैली **प्रश्नोत्तरात्मक/उत्तेजक** है ("रे बंदे")।

**महत्व:** दादू का विषय **मार्गदर्शन** है (साधक को सहज योग सिखाना); कबीर का विषय **भ्रम-भंजन** है (साधक की बाह्य खोज रोकना)। दोनों निर्गुण भक्ति के दो पूरक आयाम हैं — एक *विधि* देता है, दूसरा *बाधा* हटाता है।

## COMPETENCY_QUESTION_1
QUESTION: A student writes in the exam: "दादू दयाल की कविता का मुख्य विषय भक्ति है।" The examiner awards 1/5 marks. Using the concept of 'primary theme vs. generic topic,' explain *why* this answer fails and rewrite it to earn full marks (3 sentences max).

COMPETENCY
Thematic Precision — distinguishing a generic topic label from a text-specific thematic statement with argumentative force.

STEPS:
- Step 1: Identify the error — "भक्ति" (devotion) is a *genre/topic*, not a *theme*. It describes what the poem is *about* broadly, not what the poem *argues* specifically.
- Step 2: Explain the examiner's expectation — Board marking schemes require: (a) the central *tension/argument*, (b) the poet's *unique stance*, (c) *textual anchors* (metaphors/keywords).
- Step 3: Rewrite using the "Inside/Outside" binary — "दादू दयाल का केंद्रीय विषय है: **बाह्य कर्मकांडों (तीर्थ, माला, हठयोग) की अपेक्षा अंतःकरण की सहज सुरति (श्वास-स्मरण) द्वारा परमात्मा की प्रत्यक्ष अनुभूति** — जिसे वे 'घट घट वासी राम' और 'सहज समाधि' रूपकों से स्थापित करते हैं।"
- Step 4: Verify — Contains argument (internal > external), unique stance (sahaj/surati), textual anchors (घट, सहज, साँस) — all in one sentence.

ANSWER:
The answer fails because "भक्ति" is a **generic topic label** (like "love" or "war"), not a **specific thematic claim** — it doesn't capture Dadu's *argument* that true devotion is *internal, effortless, and mediator-free*. A full-mark rewrite: **"दादू दयाल की कविता का केंद्रीय विषय है — बाह्य आडंबरों (तीर्थ, माला, हठयोग) की निरर्थकता सिद्ध करके, श्वास-आधारित सहज सुरति (सहज समाधि) द्वारा घट-निवासी राम की प्रत्यक्ष अनुभूति को ही सच्ची भक्ति घोषित करना।"** This states the *thesis*, the *antithesis*, and the *synthesis* with textual keywords.

DIFFICULTY
medium

## COMPETENCY_QUESTION_2
QUESTION: "दादू दयाल की कविता में 'सहज' शब्द की आवृत्ति (repetition) केवल अलंकार नहीं, विषय-निर्माण की संरचनात्मक युक्ति है।" इस कथन का विश्लेषण करते हुए समझाइए कि 'सहज' की तीनों आवृत्तियाँ क्रमशः किस प्रकार विषय को विकसित करती हैं। (Analyze how the three occurrences of 'sahaj' structurally build the theme, not merely decorate it.)

COMPETENCY
Structural Thematic Analysis — tracking how a keyword's *positioned repetitions* advance the poem's argument across stanzas.

STEPS:
- Step 1: Locate the three occurrences — (1) "सहज समाधि लखाई" (Stanza 2, resolution of rejection), (2) "सहज योग सिखाई" (Stanza 3, guru's teaching), (3) "सहज ही मिलै भगवंत" (Stanza 4, final fruit).
- Step 2: Map each to a stage in the thematic argument — Occurrence 1: **Definition** (what the goal is — effortless absorption). Occurrence 2: **Method** (how to reach it — guru's instruction in natural yoga). Occurrence 3: **Guarantee** (the outcome — God meets you effortlessly).
- Step 3: Show progression — The word moves from *noun* (समाधि) → *adjective modifying method* (योग) → *adverb modifying divine encounter* (मिलै) — grammatically enacting the deepening of the theme from *state* to *path* to *result*.
- Step 4: Contrast with "हठ" (force/effort) in Stanza 2 — "हठयोग न जप न तप" immediately precedes "सहज समाधि लखाई"; the repetition *only makes sense* as the antithesis to the rejected "हठ".
- Step 5: Conclude — The threefold repetition is a **thematic arc**: Definition → Method → Fruit, each negating "हठ" and affirming "सहज" as the poem's structural logic.

ANSWER:
'सहज' की तीन आवृत्तियाँ कविता के विषय को **तीन चरणों में संरचित** करती हैं:
1. **परिभाषा चरण (स्टेंजा 2):** "सहज समाधि लखाई" — 'हठयोग न जप न तप' के नकार के तुरंत बाद, 'सहज' लक्ष्य को परिभाषित करता है: **प्रयासरहित समाधि**।
2. **साधन चरण (स्टेंजा 3):** "सहज योग सिखाई" — गुरु *क्या* सिखाता है? **सहज योग**। यहाँ 'सहज' विधि को विशेषणित करता है: साधना सहज हो, हठ न हो।
3. **फल चरण (स्टेंजा 4):** "सहज ही मिलै भगवंत" — परिणाम: भगवान **सहज ही** मिलते हैं, श्रम से नहीं।

व्याकरणिक विकास (संज्ञा → विशेषण → क्रियाविशेषण) विषय के **आंतरिक तर्क** को दर्शाता है: स्थिति → मार्ग → प्राप्ति। 'हठ' का नकार 'सहज' के विधेय में ही सार्थक होता है — इसीलिए आवृत्ति अलंकार नहीं, **विषय-युक्ति** है।

DIFFICULTY
hard