## DEFINITION
Secondary themes are the underlying, supporting ideas in a text that complement and enrich the primary theme by exploring specific dimensions of human experience, society, or philosophy through concrete textual evidence.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student must be able to identify at least three distinct secondary themes in "Hkkjr ekrk," trace each theme across multiple passages with specific textual evidence, and explain how each secondary theme deepens the primary theme of national unity.

## SCOPE_BOUNDARY
This node covers identification and analysis of secondary themes in Nehru's "Hkkjr ekrk" (Chapter 8, Aroh). It does NOT cover primary theme identification (covered in node 006), literary devices (nodes 008-009), or writing skills (node 014).

## WALKTHROUGH
Imagine you're listening to your grandmother tell stories about your family's history – she doesn't just say "we're a family," she tells you about the recipes passed down, the festivals celebrated differently in each branch, the struggles that brought everyone together. Similarly, when Nehru says "Bharat Mata," he's not just giving a slogan; he's weaving in themes of shared geography, common struggles, cultural continuity, and the voice of ordinary people. To find these secondary themes, start by asking: "What specific experiences does Nehru describe when he travels across India?" Then track how each experience – the peasant's question, the mountain dweller's isolation, the city worker's labor – builds a layer of meaning beneath the main idea of unity.

## DIAGNOSTIC_QUESTION_1
What is the difference between a primary theme and a secondary theme in a prose text like "Hkkjr ekrk"?

## DIAGNOSTIC_ANSWER_1
A primary theme is the central, overarching message (here: national unity through the concept of Bharat Mata), while secondary themes are supporting ideas that explore specific facets of that message (such as geographical diversity, historical continuity, or the perspective of common people). A wrong answer that lists "patriotism" as a secondary theme reveals the student cannot distinguish between the main message and its thematic components – they are confusing the primary theme with a related concept.

## DIAGNOSTIC_QUESTION_2
In the passage where Nehru describes peasants asking "How can India be one when regions are so different?", what secondary theme emerges through this dialogue?

## DIAGNOSTIC_ANSWER_2
The secondary theme of "unity amidst diversity" or "the intellectual challenge of national integration" emerges – Nehru uses the peasants' genuine skepticism to show that unity is not obvious but must be discovered through understanding shared geography, history, and struggle. A wrong answer like "peasants are uneducated" reveals the student misses the thematic function of the dialogue and focuses only on character judgment.

## DIAGNOSTIC_QUESTION_3
Apply the concept of secondary themes: Identify a passage in "Hkkjr ekrk" where Nehru connects the physical geography of India (rivers, mountains, plains) to the lives of ordinary people, and name the secondary theme this connection develops.

## DIAGNOSTIC_ANSWER_3
When Nehru describes traveling "from the snow-capped Himalayas to Cape Comorin" and meeting people in "remote villages" who share the same emotional response to "Bharat Mata," the secondary theme of "geography as a unifying lived experience" emerges. Steps: (1) Locate the travel narrative passages, (2) Note specific geographical markers mentioned, (3) Observe how people in different regions respond similarly, (4) Name the theme linking land and emotional belonging. A wrong answer quoting only the Himalayas without connecting to human response shows inability to synthesize setting and theme.

## DIAGNOSTIC_QUESTION_4
Analyze how the secondary theme of "historical continuity" functions in the text. How does Nehru use references to the past to strengthen the primary theme of national unity?

## DIAGNOSTIC_ANSWER_4
Nehru weaves historical continuity by referencing ancient cultural unity ("ek tq"k gSa"), shared epics and traditions, and the freedom struggle as a collective endeavor – showing that the nation is not a modern political construct but a civilizational continuum. This deepens the primary theme by giving unity historical depth and emotional legitimacy. A wrong answer listing historical facts without explaining their thematic function reveals the student cannot analyze how evidence serves a theme.

## DIAGNOSTIC_QUESTION_5
Evaluate this interpretation: "The secondary theme of social equality in 'Hkkjr ekrk' is weak because Nehru focuses only on emotional unity, not structural inequality." Defend or critique using textual evidence.

## DIAGNOSTIC_ANSWER_5
Critique: The interpretation is incomplete. Nehru explicitly mentions "LojkT; dk Hkh f"kØ djrk] tks FkksM+s yksxksa osQ fy, ugha] cfYd lHkh osQ I+kQk;ns osQ fy, gks ldrk Fkk" (he speaks of social justice not just for the few but for all) and describes meeting "dkjsM+ yksx" (common people) across class lines. The theme of social equality operates through inclusion of marginalized voices (peasants, mountain dwellers, workers) rather than explicit policy discourse. A wrong answer accepting the prompt uncritically reveals inability to distinguish between thematic treatment in a literary essay vs. a political manifesto.

## DIAGNOSTIC_QUESTION_6
Create a thematic map showing how three secondary themes in "Hkkjr ekrk" connect to the primary theme of national unity. Use one textual reference per secondary theme.

## DIAGNOSTIC_ANSWER_6
A strong answer maps: (1) Geography → Unity: "mÙkj&ifPNe esa [kScj osQ njsZ ls ysdj èkqj nfD[ku" – shared land creates shared identity; (2) Historical continuity → Unity: "ek tq"k gSa" – common past validates present unity; (3) Common people's voice → Unity: "Hkkjr ekrk njvly ;gh djksM+ksa yksx gSa" – unity belongs to ordinary citizens, not elites. Each link must show the connective logic. A poor answer lists themes without the "→ Unity" causal arrow, revealing the student sees themes as isolated topics rather than structural supports.

## COMMON_MISCONCEPTION
Students often treat secondary themes as just "other topics mentioned in the text" (like listing "travel," "peasants," "mountains" as themes). The error: confusing subject matter with thematic idea. A theme is a *statement about* a subject – not "mountains" but "geography shapes collective identity." Students make this error because textbook questions often ask "what topics are discussed?" and they transfer that listing habit to theme analysis.

## ON_FAILURE
Step 1: Give the student two columns – "Subject/Topic" and "Thematic Statement." Step 2: Have them list five concrete things Nehru describes (e.g., Himalayas, peasant's question, freedom struggle, common people, social justice). Step 3: For each, ask "What is Nehru *saying about* this?" and write a complete sentence (e.g., "The Himalayas represent the shared northern boundary that makes diverse people feel part of one land"). Step 4: Show how each thematic statement answers "How does this support the idea of Bharat Mata?" This converts listing into thematic thinking.

## BUILDS_ON
This node builds on the ability to identify the primary theme (node 006) and understand character perspectives (nodes 004-005), as secondary themes emerge through how different characters/voices experience the primary theme.

## LEADS_TO
This node enables literary devices analysis (nodes 008-009) because devices like imagery and symbolism are the tools Nehru uses to enact secondary themes, and critical thinking (node 013) which requires synthesizing multiple thematic threads.

## PREREQUISITE_NODE_IDS
c11_hin_ar_cbse_08_001, c11_hin_ar_cbse_08_002, c11_hin_ar_cbse_08_004, c11_hin_ar_cbse_08_005, c11_hin_ar_cbse_08_006
## PREREQUISITE_REASONS
c11_hin_ar_cbse_08_001: Context/background knowledge of Nehru's purpose and historical moment is essential to grasp why certain secondary themes (like unity in diversity) are emphasized
c11_hin_ar_cbse_08_002: Understanding narrative structure helps locate where secondary themes are introduced, developed, and resolved across the essay's journey
c11_hin_ar_cbse_08_004: Protagonist analysis (Nehru as narrator) reveals how his perspective shapes which secondary themes emerge and how they're framed
c11_hin_ar_cbse_08_005: Supporting characters (peasants, mountain dwellers, workers) embody different secondary themes through their voices and experiences
c11_hin_ar_cbse_08_006: Primary theme identification is the anchor – secondary themes only make sense as extensions of the central "Bharat Mata" concept

## FORWARD_NODE_IDS
c11_hin_ar_cbse_08_008, c11_hin_ar_cbse_08_009, c11_hin_ar_cbse_08_013, c11_hin_ar_cbse_08_014, c11_hin_ar_cbse_08_015, c12_hin_a_cbse_01_007, c12_hin_a_cbse_08_007, c12_hin_a_cbse_10_007, c12_hin_ar_cbse_10_007

## FORWARD_REASONS
c11_hin_ar_cbse_08_008: Imagery and metaphor are the primary literary vehicles for secondary themes (e.g., geographical imagery for unity-in-diversity)
c11_hin_ar_cbse_08_009: Irony and symbolism deepen secondary themes (e.g., the irony of peasants questioning unity while embodying it)
c11_hin_ar_cbse_08_013: Critical thinking requires synthesizing multiple secondary themes into a coherent interpretation of the text's complexity
c11_hin_ar_cbse_08_014: Secondary themes (nationalism, identity) offer alternative "Points" for varied questions.  
c11_hin_ar_cbse_08_015: Secondary themes (freedom struggle, cultural synthesis, historical continuity) offer additional discussion dimensions.  
c12_hin_a_cbse_01_007: Chapter 8 connected themes to author's biography.  
c12_hin_a_cbse_08_007: अगला तार्किक चरण: Secondary themes are the underlying, complementary ideas in a literary work that support, contrast w... इस नोड की अवधारणाओं को सीधे उपयोग/विस्तारित करता है।  
c12_hin_a_cbse_10_007: Practice with linguistic identity themes in modern Hindi poetry.  
c12_hin_ar_cbse_10_007: अगला तार्किक चरण: Secondary themes are the underlying ideas, motifs, and concerns that run parallel to the primary the... इस नोड की अवधारणाओं को सीधे उपयोग/विस्तारित करता है।  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
none

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_08_006 -> c11_hin_ar_cbse_08_007 -> c11_hin_ar_cbse_08_008: Primary theme identification enables secondary theme analysis, which enables literary device analysis as the mechanism of thematic expression.

## THIS_FORMULA
N/A - conceptual

## FORMULA_VARIABLES
N/A

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
conceptual

## CROSS_SUBJECT
c11_history_nationalism_in_india | Nehru's "Bharat Mata" concept reflects the historical construction of Indian nationalism in the 1930s-40s, where cultural unity was mobilized against colonial rule – the secondary themes mirror historical debates about nationhood
c11_civics_constitutional_values | The secondary themes of unity in diversity, social justice, and common citizenship directly anticipate the Preamble's "fraternity," "justice," and "equality" – the text is a literary precursor to constitutional philosophy

## PREREQ_CONCEPT
Primary theme identification: the student must confidently state the central message of "Hkkjr ekrk" (national unity through the Bharat Mata concept) before analyzing supporting thematic threads.

## PREREQ_BEFORE
The student must have read the full text of "Hkkjr ekrk" and completed nodes on context, narrative structure, character analysis, and primary theme.

## PREREQ_STUCK
If stuck, review the primary theme analysis (node 006) and re-read the text marking every passage where Nehru describes a specific group of people or geographical region – these are the entry points for secondary themes.

## WORKED_EXAMPLE_1
PROBLEM: Identify and analyze the secondary theme of "the ordinary citizen as the true nation" in "Hkkjr ekrk" using textual evidence.
STEPS:
- Step 1: Locate all passages where Nehru describes interacting with ordinary people (peasants in villages, mountain dwellers, workers, the "g^s&d^s" villager)
- Step 2: Note the pattern – each encounter reveals that these people, not leaders or elites, embody "Bharat Mata" through their lived connection to the land
- Step 3: Identify the key quotation: "Hkkjr ekrk njvly ;gh djksM+ksa yksx gSa] vkSj 'Hkkjr ekrk dh t;' ls eryc gqvk bu yksxksa dh t; dkA"
- Step 4: Formulate the thematic statement: "The nation is not an abstract idea or elite project but lives in the collective existence of common people who share the land's joys and sorrows"
- Step 5: Connect to primary theme: This secondary theme democratizes "Bharat Mata" – unity is not top-down but emerges from the grassroots, making the primary theme inclusive and lived
REASONING: This works because it moves from concrete textual moments (step 1) to pattern recognition (step 2) to authoritative evidence (step 3) to thematic articulation (step 4) to structural function (step 5) – the complete analytical arc.
ANSWER: The secondary theme "the ordinary citizen as the true nation" is developed through Nehru's repeated encounters with common people across India. The peasant who asks about unity, the mountain dweller isolated yet connected, the villager who defines Bharat Mata as "dharti se" (from the earth) – all demonstrate that national identity resides in those who work the land. The climactic declaration that "Bharat Mata is precisely these common people" reframes the primary theme: unity is not a slogan but the shared condition of millions of ordinary lives.

## WORKED_EXAMPLE_2
PROBLEM: Trace how the secondary theme of "historical continuity validating present unity" operates across the beginning, middle, and end of the essay.
STEPS:
- Step 1: Beginning – Locate Nehru's opening reference to "ek tq"k gSa" (we are one fragment/part) and the ancient cultural unity implied by "laLÑfr" (culture/civilization)
- Step 2: Middle – Find the freedom struggle references: "vk”kknh ls igys Hkkjr&fuekZ.k" and how "dbZ ;kstuk" (many plans) for development drew from "lkfgR;] dyk] laLÑfr" (literature, art, culture)
- Step 3: End – Identify the closing vision where past, present, and future merge: "bl ckr dh dksf'k'k dh fd yksx lkjs fganqLrku osQ ckjs esa lkspsa" – the appeal to shared heritage as basis for future unity
- Step 4: Analyze the progression: Ancient unity → Colonial disruption → Freedom struggle as recovery → Post-independence building on civilizational foundation
- Step 5: Thematic statement: "Historical continuity provides the legitimacy and emotional depth that transforms political unity into civilizational unity"
REASONING: This traces a theme temporally across the text structure (beginning-middle-end), showing how the author builds the theme progressively rather than stating it once – essential for senior secondary analysis.
ANSWER: The theme of historical continuity operates as a three-part argument: (1) Opening: India's oneness is civilizational ("ek tq"k"), not merely political; (2) Middle: The freedom struggle and Nehru's planning consciously drew from this cultural reservoir ("lkfgR;] dyk] laLÑfr"); (3) Closing: The appeal to people to understand "fganqLrku" (unity) through shared heritage makes history the bridge between past unity and future nationhood. This theme elevates the primary theme from a political necessity to a civilizational imperative.

## WORKED_EXAMPLE_3
PROBLEM: Compare how two secondary themes – "geography as lived unity" and "shared struggle as emotional unity" – intersect in the passage where Nehru describes his travels and the peasants' responses.
STEPS:
- Step 1: Identify the geography theme evidence: "mÙkj&ifPNe esa [kScj osQ njsZ ls ysdj èkqj nfD[ku" (Kashmir to Kanyakumari) and "fdlkuksa ls] ftudk u”kfj;k egnwn Fkk" (villages with vast horizons)
- Step 2: Identify the shared struggle theme evidence: "ftlosQ ge yksx dksf'k'k dj jgs Fks vkSj crkrk fd fdl rjg ns'k dk ,d fgLlk nwljs ls Tkqnk gksrs gq, Hkh fganqLrku ,d Fkk" (struggling for freedom, explaining unity despite differences)
- Step 3: Find the intersection point: The peasants' question "Hkkjr ,d ns'k gS] ftlosQ lHkh fgLlksa dh fu;fr ,d gh rjhosQ ls curh&fcxM+rh gS" emerges *during* the geographical journey
- Step 4: Analyze the synthesis: Physical travel (geography) creates the encounters where intellectual/emotional unity (struggle) is articulated – the land enables the dialogue
- Step 5: Thematic synthesis statement: "Geography provides the stage; shared struggle provides the script – together they produce the performance of national unity"
- Step 6: Connect to primary theme: This intersection makes "Bharat Mata" both a physical territory (motherland) and a community of sacrifice (mother of heroes)
REASONING: This combines two secondary themes (geography, struggle) showing their interdependence – a higher-order analytical skill requiring synthesis across thematic threads and textual locations.
ANSWER: In Nehru's travel narrative, geography and struggle are inseparable. The physical journey "from the snow-capped Himalayas to Cape Comorin" is not mere description – it creates the spatial conditions for meeting people whose shared struggle (freedom movement) has already forged emotional unity. The peasant's skeptical question about unity arises *because* they experience geographical diversity daily, yet their participation in the freedom struggle ("dksf'k'k dj jgs Fks") gives them the answer: unity persists despite difference. The land (geography) holds the people; the struggle (history) binds them. "Bharat Mata" thus embodies both the territory and the collective sacrifice – the secondary themes converge to give the primary theme material and moral weight.

## COMPETENCY_QUESTION_1
QUESTION: "Nehru's 'Hkkjr ekrk' uses the secondary theme of 'unity in diversity' not as a static fact but as a discovery process." Analyze this statement by tracing how the narrator's understanding of unity evolves through three specific encounters in the text.
COMPETENCY: Analytical interpretation with textual evidence
STEPS:
- Step 1: Identify the initial understanding – Nehru begins with an intellectual concept of unity ("fganqLrku ,d gS")
- Step 2: First encounter – The peasants' skeptical question forces him to confront diversity as lived reality, not abstraction
- Step 3: Second encounter – The mountain dweller's isolation shows unity must bridge physical and cultural distance
- Step 4: Third encounter – The "g^s&d^s" villager's definition ("èkjrh ls") reveals unity as earthy, tangible belonging
- Step 5: Synthesize – The narrator moves from asserting unity to discovering its grounds in land, people, and history
ANSWER: The statement is accurate. Nehru's journey mirrors the reader's: he starts with "fganqLrku ,d gS" as a given, but the peasant's question ("D;ksa Hkkjr ,d ns'k gS") exposes the gap between slogan and lived experience. The mountain dweller encounter extends this – unity must reach "èkkoksa osQ flyflys" (remote corners). The villager's answer ("èkjrh ls" – from the earth) resolves it: unity is not imposed but grown from shared soil. The narrator's understanding evolves from abstract claim → challenged by diversity → grounded in geography → validated by common people's voice. This arc makes the secondary theme dynamic – unity is discovered, not declared.
DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: The secondary theme of "social justice as integral to national unity" in "Hkkjr ekrk" operates through inclusion rather than explicit argument. Evaluate this claim by analyzing how Nehru's portrayal of three marginalized groups (peasants, mountain dwellers, industrial workers) constructs this theme without direct polemic.
COMPETENCY: Critical evaluation of thematic technique
STEPS:
- Step 1: Define the claim – "inclusion not polemic" means the theme emerges through who is given voice/presence, not through explicit statements about inequality
- Step 2: Analyze peasants – Their skepticism is treated as legitimate inquiry; Nehru answers patiently, positioning them as co-thinkers of the nation
- Step 3: Analyze mountain dwellers – Their isolation ("èkkoksa osQ flyflys") is acknowledged without romanticization; their inclusion in "Bharat Mata" validates their marginality
- Step 4: Analyze workers – Referenced through "LojkT; dk Hkh f"kØ" (social justice) and "dM+s yxku" (heavy burdens), linking labor to nationhood
- Step 5: Evaluate – The theme works by making the marginalized the *definers* of the nation ("Hkkjr ekrk njvly ;gh djksM+ksa yksx gSa"), not objects of policy
- Step 6: Judge effectiveness – This literary method (showing, not telling) makes social justice feel like the nation's natural constitution, not an add-on
ANSWER: The claim is strongly supported. Nehru never delivers a speech on caste or class inequality. Instead: (1) Peasants are the first interlocutors – their doubt about unity is the text's central dramatic tension, giving them epistemic authority; (2) Mountain dwellers ("vkSj èkkoksa osQ flyflys") are explicitly included in the national imagination despite geographic marginality; (3) Workers appear through "dM+s yxku" (heavy burdens) and the explicit link to social justice ("LojkT; dk Hkh f"kØ... lHkh osQ I+kQk;ns osQ fy,"). The climax – "Bharat Mata is precisely these common people" – makes inclusion the definition of the nation. This technique (dramatization over declaration) is more persuasive for a literary essay because the reader *experiences* the inclusion rather than being told it's important.
DIFFICULTY: hard