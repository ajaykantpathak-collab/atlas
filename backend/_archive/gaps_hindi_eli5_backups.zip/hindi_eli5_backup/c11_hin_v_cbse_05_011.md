## DEFINITION
Grammar: Language Usage in the Text refers to the systematic analysis of syntactic structures, morphological patterns, and stylistic choices (such as voice, sentence types, connectives, nominalization, and compound formations) that the author employs to convey argumentative force, descriptive precision, and formal register in the environmental prose piece "jktLFkku dh jtr cw¡nas".

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student must be able to identify at least three distinct grammatical features in a given excerpt (e.g., passive constructions, samas types, connective patterns), explain their rhetorical function in context, and demonstrate how they collectively establish the text's formal, persuasive tone.

## SCOPE_BOUNDARY
This node covers grammatical and stylistic analysis of the specific prose text "jktLFkku dh jtr cw¡nas" — including voice, sentence structure, samas, sandhi, connectives, and register. It does NOT cover general Hindi grammar rules unrelated to the text, poetic devices (covered in nodes 008-009), or comprehension questions (node 012).

## WALKTHROUGH
Imagine you are reading a government report on Delhi's vanishing green cover — the language feels dense, authoritative, and impersonal. Now open "jktLFkku dh jtr cw¡nas" and notice how the author uses similar grammatical choices to make ecological destruction sound urgent and factual. Begin by scanning a paragraph for verbs: are they active (कर्ता करता है) or passive (कर्म होता है)? Next, underline long compound words (समास) — do they pack technical meaning? Then trace connecting words (योजक) like 'अतः', 'इसलिए', 'किंतु' that build logical chains. Finally, ask: how would the impact change if the author used simple sentences and active voice? The key insight is that grammar here is not decoration — it is the engine of persuasion.

## DIAGNOSTIC_QUESTION_1
Identify the grammatical term for the process where two or more words combine to form a single compound word with a new meaning, as seen in words like 'वनसंपदा' or 'पर्यावरणीय' in the text.

## DIAGNOSTIC_ANSWER_1
The term is **समास (compound formation)**. A wrong answer (e.g., 'संधि' or 'उपसर्ग') reveals the student confuses word-level combination (समास) with sound-level junction (संधि) or prefixation (उपसर्ग), indicating they cannot distinguish morphological layers — a critical gap for analyzing dense administrative Hindi in this text.

## DIAGNOSTIC_QUESTION_2
In the sentence "वनों की कटाई के कारण जलस्तर गिर रहा है", the verb 'गिर रहा है' is in active voice. Rewrite it in passive voice and explain why the author might prefer passive constructions when presenting environmental data.

## DIAGNOSTIC_ANSWER_2
Passive: "जलस्तर वनों की कटाई के कारण गिराया जा रहा है" (or more naturally "वनों की कटाई के कारण जलस्तर गिराया जा रहा है"). A wrong explanation (e.g., "to make it shorter") shows the student misses the rhetorical purpose: passive voice shifts focus from the *doer* (often unnamed corporations/policies) to the *victim* (groundwater), creating objectivity and avoiding direct blame — a hallmark of formal investigative prose.

## DIAGNOSTIC_QUESTION_3
Given the excerpt: "पहले वनों का क्षेत्रफल अधिक था, किंतु अब वह तेजी से घट रहा है; इसलिए तापमान बढ़ रहा है।" Identify the three connectives (योजक) and explain the logical relationship each establishes between clauses.

## DIAGNOSTIC_ANSWER_3
Connectives: **'पहले...किंतु'** (contrast/समुच्चयबोधक विरोधार्थक), **'अब'** (time sequence/कालवाचक क्रियाविशेषण functioning as discourse marker), **'इसलिए'** (cause-effect/कार्य-कारण बोधक). A student listing only 'किंतु' and 'इसलिए' misses the temporal framing 'पहले...अब' that structures the argument's "before-after" evidence — revealing inability to track multi-layered logical architecture in argumentative prose.

## DIAGNOSTIC_QUESTION_4
Compare the nominalized phrase "वनों का विनाश" (destruction of forests) with the verbal clause "वन नष्ट हो रहे हैं" (forests are being destroyed). Analyze how nominalization changes the agency, measurability, and tone of the statement in an environmental report.

## DIAGNOSTIC_ANSWER_4
Nominalization ("वनों का विनाश") **removes the agent** (no 'by whom'), **turns process into measurable noun** (can be quantified: 'वनों का विनाश 20% बढ़ा'), and **elevates register** to bureaucratic/scientific tone. A student saying "both mean the same" fails to see how grammar shapes epistemology: verbal clause implies ongoing action with potential actors; nominalized noun presents destruction as established fact/statistic — crucial for the text's evidence-based argumentation.

## DIAGNOSTIC_QUESTION_5
Evaluate this claim: "The author's use of long samas compounds (e.g., 'पर्यावरणीय असंतुलन') makes the text inaccessible to common readers and therefore weakens its persuasive power." Defend or refute with two grammatical arguments.

## DIAGNOSTIC_ANSWER_5**
**Refute.** Argument 1: Samas creates **lexical density** — packing 'पर्यावरण + असंतुलन' into one word allows the author to treat complex ecological concepts as single manipulable units in logical chains (e.g., "पर्यावरणीय असंतुलन के कारण..."), which simple phrasing ("पर्यावरण का संतुलन बिगड़ना") would make clunky. Argument 2: The target register is **policy/administrative discourse**, not popular science; precision trumps accessibility. A student agreeing with the claim confuses *pedagogical simplicity* with *rhetorical effectiveness* in formal advocacy writing.

## DIAGNOSTIC_QUESTION_6
Write a 3-sentence paragraph in the style of "jktLFkku dh jtr cw¡nas" arguing for wetland conservation, using: (a) at least one द्वन्द्व समास, (b) one passive construction, (c) two causal connectives.

## DIAGNOSTIC_ANSWER_6
**Sample answer:** "जल-थल (द्वन्द्व समास) का संरक्षण अनिवार्य है, क्योंकि (कारण 1) ये भूजल पुनर्भरण के प्रमुख स्रोत हैं; अतः (कारण 2) इनका ह्रास नगरों में जलसंकट उत्पन्न करता है। अतिक्रमण के कारण आर्द्रभूमि तेजी से सुखाई जा रही है (passive: सुखाई जा रही है)।" A poor answer uses active voice ("लोग सुखा रहे हैं"), misses द्वन्द्व समास, or strings clauses with only 'और' — showing inability to deploy the text's grammatical toolkit for authoritative argumentation.

## COMMON_MISCONCEPTION
Students treat "grammar in text" as **spotting isolated rules** (e.g., "here is a passive verb") rather than **tracing a grammatical system** that builds the text's argumentative architecture. They ask "What samas is this?" but not "Why *this* samas *here* in the logical flow?" For example, seeing 'वन-विनाश' as just तत्पुरुष समास misses how its nominalized form allows it to become the *subject* of the next sentence ("वन-विनाश ने जलचक्र बिगाड़ा"), turning an event into an actor — a grammatical sleight-of-hand that drives the text's causal chain.

## ON_FAILURE
1. **Isolate one paragraph** (3-4 sentences) from the text. 2. **Color-code**: verbs (blue), connectives (red), compounds (green), nominalizations (orange). 3. **Ask for each color**: "What work does this do *in this sentence* and *for the paragraph's argument*?" 4. **Rewrite the paragraph** in simple active voice with no compounds — read both aloud. 5. **Articulate the difference**: "The original sounds like a report; mine sounds like a story." This contrast makes the grammatical *choices* visible as *rhetorical decisions*.

## BUILDS_ON
Vocabulary in Context (node 05_010) — students must already recognize key terms (e.g., 'आर्द्रभूमि', 'पारिस्थितिकी') to analyze how grammar structures them.

## LEADS_TO
Comprehension: Literal and Inferential Questions (node 05_012) — grammatical awareness enables students to unpack dense sentences for meaning and inference.

## PREREQUISITE_NODE_IDS
c11_hin_v_cbse_05_010
## PREREQUISITE_REASONS
c11_hin_v_cbse_05_010: Vocabulary knowledge is essential to identify lexical items within grammatical structures (e.g., recognizing 'पर्यावरणीय' as an adjective derived from 'पर्यावरण' before analyzing its role in a nominalized phrase).

## FORWARD_NODE_IDS
c11_hin_v_cbse_05_012, c11_hin_v_cbse_05_013, c11_hin_v_cbse_05_015, c12_hin_a_cbse_04_011, c12_hin_a_cbse_07_011, c12_hin_a_cbse_09_011, c12_hin_a_cbse_12_011, c12_hin_ar_cbse_10_011

## FORWARD_REASONS
c11_hin_v_cbse_05_012: Grammatical parsing skills directly support literal comprehension of complex sentences and inferential reading of implicit logical links. c11_hin_v_cbse_05_013: Critical analysis of author's stance requires understanding how grammatical choices (voice, nominalization, connectives) encode perspective and authority.
c11_hin_v_cbse_05_015: Grammar/usage knowledge ensures articulate spoken expression  
c12_hin_a_cbse_04_011: अगला तार्किक चरण: This node analyzes the grammatical structures, syntactic patterns, and language usage specific to th... इस नोड की अवधारणाओं को सीधे उपयोग/विस्तारित करता है।  
c12_hin_a_cbse_07_011: Class 11 Vitan Chapter 5 grammar node reinforces case-system and verb-morphology terminology used here.  
c12_hin_a_cbse_09_011: Additional *kriya visheshan* practice — consolidates compound verb skill.  
c12_hin_a_cbse_12_011: Worked examples of rhetorical devices in prose  
c12_hin_ar_cbse_10_011: Vitan Chapter 5 — syntactic simplicity as style.  
c11_hin_v_cbse_05_013: अगला तार्किक चरण: Critical thinking in literary analysis refers to the ability to examine a text beyond its literal me... इस नोड की अवधारणाओं को सीधे उपयोग/विस्तारित करता है।  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
none

## CHAIN_DESCRIPTION
c11_hin_v_cbse_05_010 -> c11_hin_v_cbse_05_011 -> c11_hin_v_cbse_05_012

## THIS_FORMULA
N/A - conceptual

## FORMULA_VARIABLES
N/A

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
linguistic

## CROSS_SUBJECT
c11_geography_environmental_degradation | The text's grammatical packaging of ecological processes (nominalization of 'deforestation', passive 'groundwater is lowered') mirrors geography's technical discourse where processes are objectified as measurable variables for policy analysis.  
c11_civics_environmental_policy | The formal register, causal connectives, and agentless passives in the text reflect administrative language of environmental impact assessments and policy briefs, where grammar constructs institutional accountability (or its avoidance).

## PREREQ_CONCEPT
Morphological awareness: ability to segment words into root + affix + suffix and recognize compound boundaries (samas vigrah).

## PREREQ_BEFORE
Student must be able to perform समास विग्रह (compound analysis) for common types (तत्पुरुष, कर्मधारय, द्वन्द्व, बहुव्रीहि) and identify कारक relationships in sentences.

## PREREQ_STUCK
Review Class 10 Hindi Vyakaran: समास के भेद व विग्रह, वाच्य परिवर्तन (कर्तृ/कर्मणी), और अव्यय/योजक शब्दों के प्रकार — use NCERT व्याकरण पूरक पुस्तिका Chapter 3-5.

## WORKED_EXAMPLE_1
PROBLEM: Analyze the grammatical architecture of this constructed sentence in the style of the text: "औद्योगिकरण की तीव्र गति के कारण वनों का व्यापक विनाश हुआ है, जिसके फलस्वरूप जलवायु परिवर्तन स्पष्ट दिखाई दे रहा है।" Identify: (a) the nominalized event, (b) the causal connective chain, (c) the voice of the main verb, (d) the anaphoric reference 'जिसके फलस्वरूप', and (e) the overall information flow pattern.

STEPS:
- Step 1: Segment the sentence into clauses — Clause 1: "औद्योगिकरण की तीव्र गति के कारण वनों का व्यापक विनाश हुआ है", Clause 2: "जिसके फलस्वरूप जलवायु परिवर्तन स्पष्ट दिखाई दे रहा है".
- Step 2: Identify nominalization — 'वनों का व्यापक विनाश' (destruction of forests) is a nominalized phrase (तत्पुरुष समास 'वन-विनाश' expanded with genitive 'वनों का' and adjective 'व्यापक'); it turns the verbal process 'वन नष्ट हुए' into a noun phrase that can be acted upon by 'हुआ है'.
- Step 3: Map causal connectives — 'के कारण' (postpositional causal marker linking 'तीव्र गति' to 'विनाश') and 'जिसके फलस्वरूप' (relative-correlative connective linking the entire prior event to the next consequence).
- Step 4: Determine voice — 'हुआ है' (perfective passive of 'होना') — agentless passive; 'दिखाई दे रहा है' (intransitive passive-like construction) — no grammatical agent for climate change visibility.
- Step 5: Describe information flow — Theme-Rheme progression: Given (industrialization) → New (forest destruction) → Given (that destruction) → New (climate change visible). This chaining is typical of formal explanatory prose.

REASONING: Each step isolates a grammatical stratum (morphology, syntax, discourse) and shows how they collaborate to present a causal chain as objective fact-sequence rather than human-action narrative.

ANSWER: (a) Nominalized event: 'वनों का व्यापक विनाश'. (b) Causal chain: 'के कारण' (immediate cause) → 'जिसके फलस्वरूप' (consequential link). (c) Voice: Both main verbs agentless passive/intransitive. (d) 'जिसके फलस्वरूप' = relative pronoun 'जिसके' (referring to entire Clause 1 event) + noun 'फलस्वरूप' (consequence) = compound connective. (e) Pattern: Linear causal chaining with thematic progression — each new clause picks up the previous clause's outcome as its starting point.

## WORKED_EXAMPLE_2
PROBLEM: The text contains the phrase "नगर-नियोजन की उपेक्षा" (neglect of urban planning). Perform full समास विग्रह (compound analysis), identify the कारक relationship, then rewrite the phrase as a full clause in active voice with an explicit agent. Compare the two forms for agency attribution and register.

STEPS:
- Step 1: Identify samas type — 'नगर-नियोजन' = तत्पुरुष समास (निर्माणतत्पुरुष: नगर का नियोजन); 'उपेक्षा' = separate noun. Full phrase = तत्पुरुष समास (संबंधतत्पुरुष: नगर-नियोजन की उपेक्षा).
- Step 2: Vigrah — नगर-नियोजन = नगर का नियोजन (कर्मणी कारक, षष्ठी विभक्ति); उपेक्षा = उपेक्षा करना (क्रिया). Combined vigrah: नगर-नियोजन की उपेक्षा = नगर-नियोजन की उपेक्षा की गई / किसी ने नगर-नियोजन की उपेक्षा की.
- Step 3: कारक — 'नगर-नियोजन' is कर्म (object of neglect) in षष्ठी (genitive) due to samas internal structure; 'उपेक्षा' is क्रिया-नाम (action-noun).
- Step 4: Active clause with agent — "नगर निगम ने नगर-नियोजन की उपेक्षा की" (Municipal corporation neglected urban planning) or "सरकार ने नगर-नियोजन की उपेक्षा की".
- Step 5: Compare — Samas form: no agent, process nominalized, register = formal/report. Active clause: agent explicit ('नगर निगम'), process verbal, register = accusatory/narrative. The samas allows the text to present neglect as systemic fact without naming culprits — strategic for diplomatic yet damning critique.

REASONING: This demonstrates how समास + nominalization + genitive case work as a system to background agency — a deliberate grammatical choice in environmental advocacy targeting policy audiences.

ANSWER: Samas: तत्पुरुष (संबंधतत्पुरुष). Vigrah: नगर का नियोजन + उसकी उपेक्षा. कारक: नगर-नियोजन = कर्म (षष्ठी). Active rewrite: "नगर निगम ने नगर-नियोजन की उपेक्षा की." Contrast: Samas form = agentless, nominalized, bureaucratic objectivity; Active form = agentive, verbal, direct accountability.

## WORKED_EXAMPLE_3
PROBLEM: A student writes this answer to a board question: "लेखक ने पर्यावरण समस्या बताने के लिए कठिन शब्दों का प्रयोग किया है जैसे 'पारिस्थितिकीय असंतुलन'।" Upgrade this answer to a senior-secondary level grammatical analysis using the PEEL structure (Point, Evidence, Explanation, Link) and incorporating: nominalization, lexical density, register, and causal chaining.

STEPS:
- Step 1 (Point): The author deploys grammatical nominalization and high lexical density to construct an authoritative scientific register that frames ecological decline as measurable systemic failure.
- Step 2 (Evidence): In "पारिस्थितिकीय असंतुलन", 'असंतुलन' (imbalance) nominalizes the verbal process 'असंतुलित होना'; the compound adjective 'पारिस्थितिकीय' (derived from 'पारिस्थितिकी' + ईय suffix) packs the entire discipline of ecology into a pre-modifier. This yields a single noun phrase where a clause ("पारिस्थितिकी असंतुलित हो गई") would require three words.
- Step 3 (Explanation): Nominalization allows the phrase to function as Theme in "पारिस्थितिकीय असंतुलन के कारण..." — the imbalance becomes a causal agent in its own right, entering further causal chains without re-specifying actors. Lexical density (content words per clause) increases, matching the information-packing demands of policy discourse.
- Step 4 (Link): This grammatical strategy serves the text's persuasive aim: it presents environmental collapse not as accidental but as structurally produced, legible to administrators, and amenable to technocratic intervention — the grammar *is* the argument.
- Step 5 (PEEL assembly): Combine into a coherent paragraph with clear topic sentence, quoted/paraphrased evidence, linguistic explanation, and thematic link.

REASONING: The upgrade moves from vague "difficult words" to precise grammatical metalanguage (nominalization, lexical density, Theme-Rheme, register) showing *how* language constructs the text's epistemic authority — exactly what board examiners reward.

ANSWER: **Upgraded answer:** "लेखक 'पारिस्थितिकीय असंतुलन' जैसे नामिकृत पदों (nominalized phrases) का प्रयोग करता है जहाँ 'असंतुलन' क्रिया 'असंतुलित होना' का संज्ञा-रूप है और 'पारिस्थितिकीय' विशेषण पूरे पारिस्थितिकी-विज्ञान को एक पद में संपीड़ित करता है (high lexical density)। यह नामिकरण असंतुलन को वाक्य का विषय (Theme) बनाता है — 'पारिस्थितिकीय असंतुलन के कारण भूजल गिरा' — जिससे वह स्वयं एक कारणिक एजेंट बन जाता है, बिना किसी मानवीय कर्ता के नाम लिए। यह व्याकरणिक चयन (grammatical choice) पाठ को प्रशासनिक-वैज्ञानिक रजिस्टर (bureaucratic-scientific register) देता है, जहाँ समस्या तथ्य-सी वस्तुनिष्ठ (objective) लगती है, न कि आरोप-सी व्यक्तिपरक (subjective)। इस प्रकार व्याकरण ही तर्क-रचना (argumentation) का साधन बनता है।"

## COMPETENCY_QUESTION_1
QUESTION: Read the two sentences: (A) "लोग वनों को काट रहे हैं जिससे जलस्तर गिर रहा है।" (B) "वनों की कटाई के कारण जलस्तर गिराया जा रहा है।" Using grammatical terminology (voice, nominalization, agency, register), explain how Sentence B transforms the ecological process into a formal administrative fact. Why is this transformation rhetorically effective for the text's purpose?

COMPETENCY: Grammatical analysis for rhetorical purpose identification

STEPS:
- Step 1: Identify voice in each — (A) active ('काट रहे हैं', 'गिर रहा है'); (B) passive agentless ('गिराया जा रहा है') with nominalized cause ('वनों की कटाई').
- Step 2: Compare agency — (A) explicit human agent 'लोग'; (B) no agent, cause expressed as event-noun.
- Step 3: Analyze nominalization — 'कटाई' (action-noun from 'काटना') + genitive 'वनों की' = तत्पुरुष समास packing event into noun phrase.
- Step 4: Determine register shift — (A) narrative/conversational; (B) bureaucratic/scientific.
- Step 5: Connect to text purpose — The transformation presents groundwater decline as inevitable consequence of a systemic event (deforestation), not contingent on specific actors' choices, making it suitable for policy documentation where structural causes are highlighted over individual blame.

ANSWER: Sentence B uses **agentless passive** ('गिराया जा रहा है') and **nominalized cause** ('वनों की कटाई' — तत्पुरुष समास) to eliminate human agency and reify the process as an objective causal fact. This shifts register from narrative to administrative-scientific, allowing the text to position ecological collapse as a measurable systemic outcome — rhetorically effective because it demands *structural* policy response, not moral appeals to 'people'.

DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: The text uses a chain of causal connectives: "चूँकि औद्योगिकरण तीव्र है, इसलिए वन कट रहे हैं; परिणामस्वरूप जलवायु बदली; अतः नागरिक स्वास्थ्य संकट में है।" Map the logical topology of this chain (identify each connective's semantic type). Then, rewrite the chain replacing each connective with a synonym from a different grammatical class (e.g., postposition → conjunction → adverb). Analyze how each substitution alters the logical weight and textual cohesion.

COMPETENCY: Discourse-level grammatical manipulation and semantic analysis

STEPS:
- Step 1: Map original connectives — 'चूँकि' (subordinating conjunction, cause), 'इसलिए' (correlative adverb, effect), 'परिणामस्वरूप' (discourse adverbial, consequence), 'अतः' (conjunction/adverb, inference).
- Step 2: Classify semantic types — Reason (चूँकि), Result (इसलिए), Consequence (परिणामस्वरूप), Deduction (अतः) — showing layered causality: immediate cause → intermediate effect → systemic consequence → policy implication.
- Step 3: Substitute with different classes — e.g., 'चूँकि' (conj) → 'के कारण' (postposition); 'इसलिए' (adv) → 'तो' (conj); 'परिणामस्वरूप' (adv) → 'जिससे' (relative conj); 'अतः' (conj/adv) → 'इस प्रकार' (demonstrative adverbial).
- Step 4: Analyze cohesion impact — Postposition 'के कारण' embeds cause inside NP, reducing clause prominence; 'तो' makes result clause feel conversational; 'जिससे' creates syntactic dependency weakening the consequence's independence; 'इस प्रकार' adds demonstrative summarizing force.
- Step 5: Synthesize — Original chain uses escalating grammatical weight (conj → adv → adv → conj/adv) to build argumentative momentum; substitutions flatten or fragment this progression, showing how connective *grammatical class* controls rhetorical pacing.

ANSWER: Original topology: कारण (चूँकि - संयोजक) → परिणाम (इसलिए - क्रियाविशेषण/सह-संयोजक) → दूरगामी परिणाम (परिणामस्वरूप - वाच्य-स्तरीय क्रियाविशेषण) → निष्कर्ष (अतः - संयोजक/क्रियाविशेषण). Substitutions: 'औद्योगिकरण की तीव्रता के कारण वन कट रहे हैं; तो जलवायु बदली; जिससे नागरिक स्वास्थ्य संकट में है; इस प्रकार नीति परिवर्तन आवश्यक है।' Analysis: 'के कारण' demotes cause to modifier; 'तो' colloquializes; 'जिससे' subordinates consequence; 'इस प्रकार' adds meta-discursive summary. The original's mix of subordination, correlation, and discourse-adverbials creates a **multi-tiered causal architecture** that substitutions cannot replicate — proving connective grammar is argument structure.

DIFFICULTY: hard