## DEFINITION
Writing skills based on Chapter 2 ("जक्तLFkku dh jtr cw¡nas") refer to the ability to compose structured, evidence-based responses—descriptive, analytical, and evaluative—about the traditional *khadin* water-harvesting system of Rajasthan, its ecological principles (surface, sub-surface, and capillary moisture), community construction practices, and the socio-ecological consequences of its decline, using the PEEL (Point, Evidence, Explanation, Link) framework aligned with CBSE Class 11 board answer-writing expectations.

## COGNITIVE_LEVEL
apply

## MASTERY_CRITERIA
The student can independently write a 150-200 word board-style answer that states a clear thematic point, cites two specific textual details (e.g., the three moisture types or the *pal* construction steps), explains their significance, and links back to the chapter's central message about indigenous ecological wisdom versus modern disruption—without reiterating the narrative.

## SCOPE_BOUNDARY
This node covers writing descriptive reports on *khadin* construction, analytical paragraphs on the three moisture categories (*ikyjikuh*, *ikrkyikuh*, *jstk.khikuh*), comparative answers contrasting traditional and modern water management, and critical evaluations of the text's stance on development. It does NOT cover creative writing (stories, poems), formal letter formats, or grammar drills unrelated to textual evidence.

## WALKTHROUGH
Imagine you sit in the exam hall and the question reads: "Explain how the *khadin* system reflects the Thar community's deep understanding of soil moisture." Your mind goes blank—you remember the words *ikyjikuh* and *pal* but don't know how to turn them into a 5-mark answer. Start by asking: "What is the ONE big idea the question wants?" (Community wisdom encoded in practice). Next, flip to the text mentally: locate the two concrete details that prove this (the three moisture types and the *pal* design that exploits capillary rise). Now draft a topic sentence that names the big idea. Follow with Evidence: "The text identifies *ikyjikuh*, *ikrkyikuh*, and *jstk.khikuh* as distinct moisture zones..." Explain: "This classification shows farmers read the land like a text..." Link: "Thus the *khadin* is not mere engineering but embodied ecological knowledge." The key insight: board answers are not summaries—they are arguments built from textual evidence.

## DIAGNOSTIC_QUESTION_1
Define the PEEL structure for writing a literature-based answer in CBSE Class 11 Hindi Core.

## DIAGNOSTIC_ANSWER_1
PEEL stands for Point (main claim in one sentence), Evidence (specific textual detail or quote), Explanation (how the evidence proves the point), and Link (connect back to the question/theme). A wrong answer—such as "PEEL means writing a summary"—reveals the student confuses structure with content and will produce narrative retellings instead of analytical paragraphs.

## DIAGNOSTIC_QUESTION_2
A student writes: "The chapter tells us about khadins in Rajasthan. They are built by piling earth. People work together. It is very important for water." Identify why this answer would score poorly on a 5-mark "analyze" question.

## DIAGNOSTIC_ANSWER_2
The answer is a plot summary lacking a thematic Point, specific Evidence (no terms like *jstk.khikuh* or *pal*), analytical Explanation, or thematic Link. It shows the student mistakes "writing about the chapter" for "analyzing the chapter"—a fundamental category error that yields 1-2 marks instead of 5.

## DIAGNOSTIC_QUESTION_3
Using the PEEL framework, write a 4-sentence paragraph answering: "How does the construction of the *pal* (embankment) demonstrate the builders' knowledge of capillary action?" Use the terms *jstk.khikuh* and *ikrkyikuh*.

## DIAGNOSTIC_ANSWER_3
Point: The *pal* design exploits capillary rise to irrigate crops without surface water. Evidence: The text describes *jstk.khikuh* (capillary moisture) rising from *ikrkyikuh* (sub-surface moisture) through the embankment's fine soil. Explanation: By raising the *pal* with layered *vija* (silt) and *mitti*, builders create a wick that pulls moisture upward into the root zone. Link: This engineering of *jstk.khikuh* proves the *khadin* is a precision hydro-technology, not a crude dam. A wrong answer omitting *jstk.khikuh* reveals the student cannot map textual terminology to physical processes.

## DIAGNOSTIC_QUESTION_4
Compare the traditional *khadin* community-labor model (*paledar*, *khai*, *johad*) with the modern contractor-driven approach described in the text's later paragraphs. What core value shifts?

## DIAGNOSTIC_ANSWER_4
Traditional model: labor as reciprocal duty (*paledar* system), knowledge embedded in community, *khai* ceremony binds social-ecological contract. Modern model: wage labor, external contractors, *khai* reduced to ritual, knowledge displaced by machinery. Core shift: from *collective stewardship* to *extractive transaction*. A wrong answer listing only "machines replaced people" misses the cultural-epistemic rupture the text foregrounds.

## DIAGNOSTIC_QUESTION_5
Critique this claim using textual evidence: "The author romanticizes the *khadin* system; modern canals are objectively more efficient for Rajasthan's water security."

## DIAGNOSTIC_ANSWER_5
The text never claims *khadins* yield more water per hectare; it argues they match *local ecology* (low evaporation, salinity control, zero energy). Evidence: "NksVs O;kl dh oqaQbZ esa èkhjs&èkhjs fjl dj vk jgk ikuh nks&pkj gkFk dh mQ¡pkbZ ys ysrk gSA" (In large *khadins*, capillary moisture rises 2-3 ft). Canals bring *ek=kk* (flood irrigation) causing waterlogging and salinity—exactly what *khadins* avoid. The author values *sustainability in situ*, not volumetric efficiency. A wrong answer agreeing with the claim shows inability to distinguish the text's evaluative framework (ecological fit) from an external metric (yield volume).

## DIAGNOSTIC_QUESTION_6
Draft a 100-word "report for the school magazine" describing the *khai* ceremony as a socio-ecological contract, using at least three chapter-specific terms (*khai*, *pal*, *johad*, *paledar*, *jstk.khikuh*).

## DIAGNOSTIC_ANSWER_6
Expected criteria: (1) Opens with *khai* as ceremonial inauguration of *pal* repair. (2) Names *paledar* households contributing labor per *bigha*. (3) Links ceremony to *johad* desilting and *jstk.khikuh* recharge. (4) Closes with *khai* as renewal of community-water covenant. A poor answer treats *khai* as a festival alone, omitting the labor-ecology contract—revealing the student reads ritual as culture, not as resource governance.

## COMMON_MISCONCEPTION
Students believe "writing skills" means learning *formats* (report, article, speech) by heart. For this chapter, they memorize a "report format" template and pour chapter summary into it. The error: CBSE assesses *integration of textual evidence into argument*, not format compliance. A perfectly formatted report with zero *ikyjikuh/ikrkyikuh/jstk.khikuh* terminology scores near zero on content. Students make this error because Class 10 taught format-driven writing; Class 11 shifts to evidence-driven analysis but the habit persists.

## ON_FAILURE
Step 1: Give the student a 5-mark question and a 2/5 sample answer (summary-only). Ask: "What textual proof is missing?" Step 2: Co-construct a PEEL paragraph on the board using *only* three chapter terms. Step 3: Assign a "terminology hunt"—list 10 chapter-specific words, define each in one sentence, then use each in a PEEL Evidence slot. Step 4: Practice timed 5-mark answers where the rubric awards 1 mark each for Point, Evidence, Explanation, Link, Terminology—no format marks.

## BUILDS_ON
c11_hin_v_cbse_02_013 (Critical Thinking: Analysis and Interpretation) — students must first interpret themes before writing about them.

## LEADS_TO
c11_hin_v_cbse_02_015 (Speaking and Listening: Discussion Points) — written arguments become oral defense material.

## PREREQUISITE_NODE_IDS
c11_hin_v_cbse_02_002, c11_hin_v_cbse_02_006, c11_hin_v_cbse_02_008, c11_hin_v_cbse_02_010, c11_hin_v_cbse_02_012, c11_hin_v_cbse_02_013, c11_hin_v_cbse_02_007, c11_hin_v_cbse_02_009, c11_hin_v_cbse_02_011

## PREREQUISITE_REASONS
c11_hin_v_cbse_02_002: Plot and narrative structure provides the event sequence (khadin construction, khai ceremony) that answers must reference accurately.
c11_hin_v_cbse_02_006: Primary theme (indigenous ecological wisdom vs. modern disruption) is the thematic anchor for all analytical writing.
c11_hin_v_cbse_02_008: Imagery and metaphor (e.g., land as text, moisture as language) supply analytical vocabulary for Explanation steps.
c11_hin_v_cbse_02_010: Key vocabulary (*ikyjikuh, ikrkyikuh, jstk.khikuh, pal, khai, paledar*) constitutes the mandatory Evidence pool.
c11_hin_v_cbse_02_012: Literal and inferential comprehension ensures students distinguish stated facts from interpreted themes.
c11_hin_v_cbse_02_013: Critical thinking skills (evaluating author stance, comparing systems) are the raw material for the Explanation and Link steps.
c11_hin_v_cbse_02_007: Writing skills (analytical paragraphs, essays) apply secondary theme analysis in structured academic responses.  
c11_hin_v_cbse_02_009: Writing tasks (analytical paragraph, essay) demand structured use of textual evidence on these devices.  
c11_hin_v_cbse_02_011: Writing tasks require students to replicate or adapt the text's register, voice, and technical vocabulary.  

## FORWARD_NODE_IDS
c12_hin_a_cbse_03_014, c12_hin_a_cbse_05_014, c12_hin_v_cbse_02_014

## FORWARD_REASONS
c12_hin_a_cbse_03_014: More practice with evidence embedding.  
c12_hin_a_cbse_05_014: अगला तार्किक चरण: Writing Skills based on the chapter refers to the ability to compose structured, evidence-based resp... इस नोड की अवधारणाओं को सीधे उपयोग/विस्तारित करता है।  
c12_hin_v_cbse_02_014: Class 11 Vitan writing skills foundation — paragraph structure, textual embedding, formal register.  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
none

## CHAIN_DESCRIPTION
c11_hin_v_cbse_02_013 -> c11_hin_v_cbse_02_014 -> c11_hin_v_cbse_02_015

## THIS_FORMULA
PEEL = Point (1 thematic sentence) + Evidence (1-2 specific textual details with chapter terminology) + Explanation (2-3 sentences connecting evidence to point via cause/effect or significance) + Link (1 sentence returning to question/theme)

## FORMULA_VARIABLES
Point: Thematic claim answering the question directly; Evidence: Chapter-specific term, fact, or paraphrased detail (e.g., *jstk.khikuh*, *pal* height, *paledar* duty); Explanation: Analytical reasoning showing how evidence proves the point; Link: Concluding sentence tying the paragraph back to the central theme or question stem.

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
linguistic

## CROSS_SUBJECT
c11_geography_water_resources | The *khadin* system is a classic case study in traditional water harvesting (Class 11 Geography Ch. "Water Resources")—writing about it requires the same terminology (*johad*, *khadin*, recharge) and ecological logic (capillary rise, evaporation reduction).
c11_civics_local_governance | The *paledar* labor-sharing institution mirrors gram-sabha-based resource governance (Class 11 Political Science "Local Governments")—analytical writing on community management draws on identical concepts of collective action and common-pool resources.

## PREREQ_CONCEPT
Ability to distinguish plot summary from thematic analysis using textual evidence.

## PREREQ_BEFORE
Student must know the three moisture types (*ikyjikuh, ikrkyikuh, jstk.khikuh*), the *pal* construction steps, and the *khai* ceremony's social function—without notes.

## PREREQ_STUCK
Review c11_hin_v_cbse_02_010 (Vocabulary) and c11_hin_v_cbse_02_006 (Primary Theme) simultaneously—make flashcards pairing each term with its thematic role.

## WORKED_EXAMPLE_1
PROBLEM: "Write a 150-word analytical paragraph: 'The *khadin* is not merely a water-harvesting structure but a socio-ecological contract.' Use PEEL and at least three chapter-specific terms."

STEPS:
- Step 1: Identify the question's demand—analytical paragraph, not description; key claim to prove: *khadin* = socio-ecological contract.
- Step 2: Select Evidence from chapter: (a) *paledar* system (labor per *bigha*), (b) *khai* ceremony (renewal oath), (c) *jstk.khikuh* recharge (ecological outcome of collective maintenance).
- Step 3: Draft Point sentence: "The *khadin* functions as a socio-ecological contract because its engineering is inseparable from the community's reciprocal obligations."
- Step 4: Insert Evidence: "The *paledar* arrangement binds each cultivator to contribute labor proportional to landholding; the annual *khai* ceremony ritualizes this pledge before *pal* repair begins."
- Step 5: Write Explanation: "This labor covenant ensures the *pal* maintains the fine *vija-mitti* layers that enable *jstk.khikuh* (capillary moisture) to rise 2-3 feet, irrigating roots without surface water—an outcome no individual could sustain alone."
- Step 6: Craft Link: "Thus the *khadin* materializes a contract where social reciprocity produces ecological resilience, a unity modern contractors fracture."

REASONING: The steps move from question decoding to evidence selection to structured drafting, ensuring every PEEL component is populated with chapter-specific content rather than generic statements.

ANSWER: The *khadin* functions as a socio-ecological contract because its engineering is inseparable from the community's reciprocal obligations. The *paledar* arrangement binds each cultivator to contribute labor proportional to landholding; the annual *khai* ceremony ritualizes this pledge before *pal* repair begins. This labor covenant ensures the *pal* maintains the fine *vija-mitti* layers that enable *jstk.khikuh* (capillary moisture) to rise 2-3 feet, irrigating roots without surface water—an outcome no individual could sustain alone. Thus the *khadin* materializes a contract where social reciprocity produces ecological resilience, a unity modern contractors fracture.

## WORKED_EXAMPLE_2
PROBLEM: "Convert this weak 3-mark answer into a 5-mark PEEL response: 'Khadins are old water systems in Rajasthan. They stop rainwater. Farmers grow crops. Now government makes canals so khadins are dying.' Target: 150 words, four chapter terms."

STEPS:
- Step 1: Diagnose weaknesses—no Point, generic Evidence ("old water systems"), zero terminology, no Explanation of *why* canals replace *khadins*, no thematic Link.
- Step 2: Formulate Point: "State-driven canal irrigation displaces the *khadin* not by outperforming it ecologically but by substituting collective stewardship with centralized extraction."
- Step 3: Upgrade Evidence: Replace "stop rainwater" with "*pal* embankments harvest *ikrkyikuh* (sub-surface moisture) and sustain *jstk.khikuh* (capillary rise)"; replace "farmers grow crops" with "*paledar*-organized cultivation of *bajra, moth, til* on residual moisture"; replace "government makes canals" with "canal command areas introduce *ek=kk* (flood irrigation) causing waterlogging and salinity."
- Step 4: Write Explanation: "Canals deliver water *to* the field; *khadins* cultivate moisture *in* the field. The former raises the water table, triggering salinity—the very hazard *khadins* avoid by design. The latter requires zero energy, zero salinity risk, and community labor the *paledar* system guarantees."
- Step 5: Craft Link: "Development policy mistakes volumetric supply for ecological suitability, erasing a system where *khai* ceremony bound people to land and moisture alike."

REASONING: The transformation demonstrates how the same factual skeleton gains marks by swapping generic nouns for chapter terminology and adding causal Explanation.

ANSWER: State-driven canal irrigation displaces the *khadin* not by outperforming it ecologically but by substituting collective stewardship with centralized extraction. *Pal* embankments harvest *ikrkyikuh* (sub-surface moisture) and sustain *jstk.khikuh* (capillary rise) for *bajra, moth, til* cultivation organized through the *paledar* labor covenant. Canals introduce *ek=kk* (flood irrigation) that raises the water table, triggering salinity—the very hazard *khadins* avoid by design. *Khadins* require zero energy, zero salinity risk, and community labor the *paledar* system guarantees; canals replace this with external water and individual pumps. Development policy mistakes volumetric supply for ecological suitability, erasing a system where *khai* ceremony bound people to land and moisture alike.

## WORKED_EXAMPLE_3
PROBLEM: "A 6-mark question: 'Compare the author's portrayal of the *khadin* ecosystem with the modern canal-irrigated ecosystem on three parameters: (i) water source and movement, (ii) social organization of labor, (iii) long-term soil health. Structure as three mini-PEEL paragraphs.'"

STEPS:
- Step 1: Deconstruct the question—three parameters, each needs a mini-PEEL; total ~180 words; must use comparative connectives (*whereas, unlike, in contrast*).
- Step 2: Parameter (i) Water: Point—*khadin* uses *in-situ* moisture (*ikyjikuh → ikrkyikuh → jstk.khikuh* vertical continuum); canal uses *ex-situ* *ek=kk* (surface flood). Evidence—text: "*jstk.khikuh* rises 2-3 ft in *pal*" vs. "canal water reaches *hyksa* (field channels)." Explanation—*khadin* works *with* gravity and capillarity; canal works *against* evaporation and percolation loss. Link—source determines sustainability.
- Step 3: Parameter (ii) Labor: Point—*khadin* = *paledar* (proportional community labor); canal = wage/contractor labor. Evidence—"*paledar* per *bigha*" vs. "contractors bring *majdur*." Explanation—*paledar* embeds knowledge in practice; contractor labor severs knowledge from work. Link—labor model determines knowledge survival.
- Step 4: Parameter (iii) Soil health: Point—*khadin* prevents salinity; canal induces it. Evidence—"*khadin* fields *lvan* (salinity) *ugha* hota" vs. "canal areas *lvan* badhta hai." Explanation—*jstk.khikuh* irrigation leaves no salt crust; *ek=kk* evaporates leaving salts. Link—soil health is the ultimate ledger of ecological fit.
- Step 5: Synthesize concluding Link across all three: "The *khadin* integrates water, labor, and soil into a single regenerative loop; the canal severs them into three managed inputs—water delivered, labor hired, soil amended—the loop broken."

REASONING: This multi-paragraph task tests the student's ability to maintain PEEL discipline across comparative parameters while deploying the chapter's full technical vocabulary—a direct rehearsal for 6-mark board questions.

ANSWER: (i) Water: The *khadin* exploits an *in-situ* moisture continuum—*ikyjikuh* (surface) percolates to *ikrkyikuh* (sub-surface) which feeds *jstk.khikuh* (capillary rise of 2-3 ft in the *pal*)—whereas canals impose *ex-situ ek=kk* (flood irrigation) that evaporates and percolates wastefully. The *khadin* works *with* gravity and capillarity; the canal works *against* loss—source determines sustainability. (ii) Labor: The *khadin* runs on *paledar* (proportional community labor tied to *bigha* holding, renewed annually at *khai*); canals run on wage/contractor labor that severs ecological knowledge from practice. The *paledar* embeds stewardship in daily work; the contractor extracts labor—labor model determines knowledge survival. (iii) Soil: *Khadin* fields avoid *lvan* (salinity) because *jstk.khikuh* irrigation leaves no surface residue; canal commands develop *lvan* as *ek=kk* evaporates, depositing salts. *Khadin* integrates water, labor, soil into one regenerative loop; the canal severs them into three managed inputs—the loop broken.

## COMPETENCY_QUESTION_1
QUESTION: "A Class 11 student writes this answer to a 4-mark question 'Explain the role of *jstk.khikuh* in the *khadin* system': '*Jstk.khikuh* is capillary moisture. It rises in the soil. Plants use it. It is important.' The teacher returns it with '1/4 – PEEL missing.' Rewrite the answer to earn full marks using the same facts but adding structure and two more chapter-specific terms."

COMPETENCY: Structuring factual knowledge into analytical argument (PEEL application)

STEPS:
- Step 1: Identify the bare facts present (*jstk.khikuh* = capillary moisture, rises, used by plants).
- Step 2: Add missing chapter terms that explain *how* it rises (*ikrkyikuh* as source, *pal* design as mechanism).
- Step 3: Construct Point: "*Jstk.khikuh* (capillary moisture) is the *khadin*'s invisible irrigation engine, drawn upward from *ikrkyikuh* by the *pal*'s engineered soil profile."
- Step 4: Insert Evidence: "The text notes *jstk.khikuh* rises 'nks&pkj gkFk' (2-3 feet) through the *pal*'s layered *vija-mitti*, reaching crop roots without surface water."
- Step 5: Write Explanation: "This capillary lift transforms stored sub-surface moisture into plant-available water at zero energy cost, enabling *bajra-moth* cultivation on residual moisture alone."
- Step 6: Craft Link: "Without *jstk.khikuh*, the *khadin* would be a mere pond; with it, the *khadin* becomes a self-regulating moisture battery."

ANSWER: *Jstk.khikuh* (capillary moisture) is the *khadin*'s invisible irrigation engine, drawn upward from *ikrkyikuh* by the *pal*'s engineered soil profile. The text notes *jstk.khikuh* rises 'nks&pkj gkFk' (2-3 feet) through the *pal*'s layered *vija-mitti*, reaching crop roots without surface water. This capillary lift transforms stored sub-surface moisture into plant-available water at zero energy cost, enabling *bajra-moth* cultivation on residual moisture alone. Without *jstk.khikuh*, the *khadin* would be a mere pond; with it, the *khadin* becomes a self-regulating moisture battery.

DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: "You are asked in the board exam: 'The chapter ends with the line: *blh [kM+h osQ cy ij [kkjs ikuh osQ chp ehBk ikuh nsrh [kM+h jgrh gS oqaQbZA* (On the ashes of this *khadin* burns the *khadin* that gives capillary moisture between the lines of sub-surface moisture). Write a 200-word critical appreciation of this metaphor, analyzing how it condenses the chapter's ecological and historical argument.'"

COMPETENCY: Metaphor analysis and thematic synthesis (high-order literary response)

STEPS:
- Step 1: Decode the metaphor—*[kM+h* (khadin/ashes) = destroyed traditional system; *[kkjs ikuh* (sub-surface moisture) = the ecological base; *ehBk ikuh* (capillary moisture) = the regenerative capacity; *oqaQbZ* (khadin) = the phoenix system rising *on* the ruins.
- Step 2: Identify three condensed arguments: (a) Destruction: modern canals burn the *khadin* (ash). (b) Persistence: *ikrkyikuh* survives the fire (sub-surface moisture remains). (c) Regeneration: *jstk.khikuh* can still rise *if* the *pal* is rebuilt (capillary moisture between the lines).
- Step 3: Draft Point: "The closing metaphor condenses the chapter's dialectic: destruction, latency, and conditional rebirth of an eco-social technology."
- Step 4: Evidence & Explanation for (a): "Canals as 'fire'—*ek=kk* waterlogging burns the *pal*, ends *paledar*, erases *khai*."
- Step 5: Evidence & Explanation for (b): "*Ikrkyikuh* (sub-surface moisture) is the 'ash-bed'—it survives because geology outlives policy."
- Step 6: Evidence & Explanation for (c): "*Jstk.khikuh* 'between the lines'—capillary rise *can* restart *if* community rebuilds *pal* (the 'lines' = *pal* ridges)."
- Step 7: Synthesizing Link: "The metaphor refuses nostalgia: the *khadin* is not a relic but a latent potential encoded in the land's moisture memory, awaiting the social contract (*khai*) to reactivate it."

ANSWER: The closing metaphor condenses the chapter's dialectic: destruction, latency, and conditional rebirth of an eco-social technology. Canals act as 'fire'—*ek=kk* flood irrigation waterlogs the *pal*, dissolves the *paledar* labor covenant, and hollows the *khai* ceremony into ritual, burning the living *khadin* to ash. Yet *ikrkyikuh* (sub-surface moisture) persists as the ash-bed; geology outlasts policy because the Thar's sandy strata hold moisture regardless of surface regime. Upon this latent moisture, *jstk.khikuh* (capillary rise) can still climb 'between the lines'—the *pal* ridges—*if* the community re-assembles the *vija-mitti* layers and re-swears the *khai* oath. The metaphor refuses nostalgia: the *khadin* is not a museum piece but a latent potential encoded in the land's moisture memory, awaiting the social contract to reactivate it. History burns the structure; ecology keeps the blueprint; community decides whether to rebuild.

DIFFICULTY: hard