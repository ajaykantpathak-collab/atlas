## DEFINITION
Critical Thinking: Analysis and Interpretation is the systematic process of examining a literary text beyond its surface meaning by breaking down its components (plot, character, theme, language, structure), evaluating the author's choices, and synthesizing evidence to form reasoned, defensible interpretations that account for historical context, literary devices, and multiple perspectives.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student can independently select a passage from the chapter, identify at least three literary elements at work, trace how they interact to produce meaning, and write a structured analytical response using the PEEL framework (Point, Evidence, Explanation, Link) that connects textual evidence to the chapter's central concerns about colonial power and resistance.

## SCOPE_BOUNDARY
This node covers deep analytical reading of "फोनब्ज़-लाHkk"k.k" (Chapter 4), focusing on interpreting the dramatic confrontation between Lord Lytton and the Indian ruler, analyzing irony/symbolism in the dialogue, and evaluating the text's critique of colonialism. It does NOT cover creative writing based on the chapter (node 014) or oral discussion skills (node 015), nor does it repeat literal comprehension (node 012).

## WALKTHROUGH
Imagine you're watching a heated argument between a landlord and a tenant where the landlord claims he's "helping" the tenant by raising the rent. You'd instantly sense the irony — but can you prove it using the exact words, tone, and power dynamic? That's what we do here: start by re-reading the confrontation scene (pages 46-50) and marking every moment where Lytton's words contradict his actions. Next, cluster those markings into patterns — false generosity, historical erasure, threats disguised as advice. Then ask: what is the author *really* saying about colonial rule through this one scene? Finally, build your answer using PEEL: make a claim, quote the Hindi text, explain the irony, link to the theme of "सत्ता का छद्म" (the façade of power). The key insight: analysis isn't finding hidden meanings — it's exposing how the text *constructs* meaning through deliberate contradictions.

## DIAGNOSTIC_QUESTION_1
What is the primary analytical move required when interpreting the dialogue between Lord Lytton and the Indian ruler in "फोनब्ज़-लाHkk"k.k"? (Answer in 1-2 sentences)

## DIAGNOSTIC_ANSWER_1
The primary move is identifying **dramatic irony** — the gap between what Lytton claims (benevolence, progress, protection) and what his actions reveal (exploitation, erasure, coercion). A wrong answer like "understanding the plot" or "translating the Hindi" reveals the student is stuck at literal comprehension (node 012) and hasn't grasped that analysis requires exposing the *contradiction* between speaker's intent and textual evidence.

## DIAGNOSTIC_QUESTION_2
Explain in your own words why the author chooses a *dramatic confrontation* (dialogue-heavy scene) rather than third-person narration to critique colonial rule. What effect does this create for the reader?

## DIAGNOSTIC_ANSWER_2
The dramatic form forces the reader to *witness* the power imbalance in real time — we hear Lytton's polished rhetoric ("तुम्हारे पूर्वजों को मैंने...") clash with the ruler's silenced fury, making the colonial logic *perform* its own exposure. A wrong answer like "it makes the story interesting" or "dialogue is easier to read" shows the student confuses *form* with *entertainment* and misses that the *structure itself* is the argument: colonialism survives by controlling the narrative, and the dialogue format lets the text reclaim narrative agency.

## DIAGNOSTIC_QUESTION_3
Apply the concept of "unreliable narrator" to Lord Lytton's speech on page 48 ("फिरकी, रक्] D;k 'कु वकदह ब्ल नस'क इमस..."). Identify two specific claims he makes that the text *simultaneously undermines* through contextual clues, and explain how the undermining works.

## DIAGNOSTIC_ANSWER_3
**Claim 1:** "मैंने तुम्हें हर तरह का यकहक दिया" (I gave you every right) — undermined by the ruler's internal monologue listing confiscated lands, taxes, and stripped titles. **Claim 2:** "तुम्हारी प्रजा खुश थी" (Your subjects were happy) — undermined by the earlier description of "नक़्क़ारख़ाने में तूती की आवाज़" (voice lost in drum-beat) showing suppressed dissent. The undermining works through **juxtaposition**: the text places Lytton's assertions immediately beside evidence that contradicts them, forcing the reader to do the critical work. A wrong answer that only summarizes Lytton's speech without identifying the *counter-evidence* shows the student cannot yet perform *intertextual* analysis within a single passage.

## DIAGNOSTIC_QUESTION_4
Analyze how the symbol of "उजोज़्क्स<+" (Ujojx<+ — the city/place name) functions across the chapter. Trace its transformation from a geographical marker to a metaphor for colonial dispossession, citing at least two textual moments.

## DIAGNOSTIC_ANSWER_4
Initially, "उजोज़्क्स<+" is a concrete location where the ruler's ancestor held authority ("उजोज़्क्स<+ नाम के एक स्थान पर..."). By the final confrontation, it becomes a **metonym for lost sovereignty** — Lytton says "तुम्हारे पूर्वजों ने इसे विकसित किया" (your ancestors developed it) while simultaneously claiming ownership, turning the ruler's heritage into British property. The transformation works through **semantic slippage**: the same proper noun shifts from denoting *indigenous achievement* to denoting *colonial asset*. A wrong answer that treats Ujojx<+ as mere setting shows the student misses how proper nouns in postcolonial texts often carry **contested histories** — the battle over *naming* is the battle over *owning the past*.

## DIAGNOSTIC_QUESTION_5
Evaluate this interpretation: "The chapter ultimately portrays the Indian ruler as powerless and defeated, reinforcing the colonial narrative of inevitable British supremacy." Defend or refute using *only* textual evidence from the ruler's final speech (page 51).

## DIAGNOSTIC_ANSWER_5
**Refute.** The ruler's final speech ("हट्क्क्स्स हक्क्जर! इस आज़तक़्क़्क़ रक़्क़... मेरे पीछे आने वालों...") performs **discursive resistance**: he refuses Lytton's framing ("तुम्हारा शासन नहीं"), reclaims historical agency ("मेरे पुरखों ने..."), and addresses *future generations* ("मेरे पीछे आने वालों"), positioning himself as a link in an unbroken chain of resistance. The text ends not with his submission but with his *voice persisting* — the last words are his, not Lytton's. A wrong answer that agrees with the interpretation reveals the student equates *political defeat* with *narrative defeat* and cannot distinguish between the ruler's material loss and his **symbolic victory in controlling the story's closure**.

## DIAGNOSTIC_QUESTION_6
Create a 4-line poetic response (in Hindi or English) from the perspective of the *city of Ujojx<+* witnessing the confrontation. Your poem must incorporate at least two symbols from the chapter (e.g., "नक़्क़ारख़ाना", "तूती", "फिरकी", "सिंहासन") and show the city's judgment on *both* men.

## DIAGNOSTIC_ANSWER_6
**Sample criteria for a strong answer:**
- Uses 2+ chapter symbols organically (not just listed)
- Gives the city a distinct voice (neither fully Lytton's nor the ruler's)
- Implies judgment through imagery, not statement
- Example:  
  *"नक़्क़ारख़ाने की धुन में दबी तूती अब सिंहासन गिनती है,*  
  *फिरकी सा घूमता वक़्त — एक ने लूटा, दूजे ने सहा,*  
  *मेरी माटी याद रखेगी: सत्ता की बोली नहीं, चुप्पी की गवाही।"*
A poor answer that merely describes the scene ("The city saw two men fight") shows the student cannot yet **transfer analytical insight into creative synthesis** — the highest Bloom level where analysis becomes generative.

## COMMON_MISCONCEPTION
Students believe "critical analysis" means **finding faults** in the text or **disagreeing with the author**. In this chapter, they often write: "The author is biased against the British" or "The ruler is too emotional." This error stems from confusing *critical* (as in "criticize") with *critical* (as in "critically examine"). The Hindi term "विश्लेषण" (analysis) literally means "विशेष + लय" — breaking into *distinct components* to see how they *function together*. Students miss that the text *invites* us to see through Lytton's rhetoric precisely *because* the author constructed it that way — the "bias" is a deliberate literary device, not an authorial flaw.

## ON_FAILURE
1. **Name the confusion:** "You're judging the *character*, not analyzing the *craft*. Ask: 'How did the author *make* me see Lytton as hypocritical?'"  
2. **Model the shift:** Take one Lytton quote → show the *textual mechanism* (juxtaposition, irony, lexical choice) that creates the critique → label it "author's strategy."  
3. **Practice micro-analysis:** Give 3 short quotes; student identifies *only the device* (not the meaning) — e.g., "इसमें व्यंग्य है क्योंकि..." (irony because...).  
4. **Rebuild the answer:** Student rewrites their "fault-finding" response as "The author uses irony in X to reveal Y, which supports the theme of Z."

## BUILDS_ON
Literal and inferential comprehension (node 012) — you cannot analyze what you haven't first understood at surface and implied levels.

## LEADS_TO
Writing analytical essays based on the chapter (node 014) — analysis provides the evidence and reasoning that structured writing requires.

## PREREQUISITE_NODE_IDS
c11_hin_ar_cbse_04_001, c11_hin_ar_cbse_04_002, c11_hin_ar_cbse_04_003, c11_hin_ar_cbse_04_004, c11_hin_ar_cbse_04_005, c11_hin_ar_cbse_04_006, c11_hin_ar_cbse_04_007, c11_hin_ar_cbse_04_008, c11_hin_ar_cbse_04_009, c11_hin_ar_cbse_04_010, c11_hin_ar_cbse_04_011, c11_hin_ar_cbse_04_012
## PREREQUISITE_REASONS
c11_hin_ar_cbse_04_001: Historical context (Curzon/Lytton era) is essential to decode the political subtext of the dialogue.
c11_hin_ar_cbse_04_002: Plot structure reveals why the confrontation is the climax — analysis needs structural awareness.
c11_hin_ar_cbse_04_003: Setting (princely state, colonial office) creates the spatial power dynamic analyzed here.
c11_hin_ar_cbse_04_004: Protagonist's (ruler's) characterization provides the psychological depth for interpreting his silence/speech.
c11_hin_ar_cbse_04_005: Lytton as antagonist — his characterization as "colonial administrator" is the foil for analysis.
c11_hin_ar_cbse_04_006: Primary theme (colonial façade) is the *thesis* that analysis must evidence.
c11_hin_ar_cbse_04_007: Secondary themes (memory, resistance, language) are the *threads* analysis traces.
c11_hin_ar_cbse_04_008: Imagery/metaphor (e.g., "नक़्क़ारख़ाना") are the *tools* analysis dissects.
c11_hin_ar_cbse_04_009: Irony/symbolism are the *primary devices* this node operationalizes.
c11_hin_ar_cbse_04_010: Key vocabulary (e.g., "ड#.क्क्सरिकन्द", "फ्पन्स्न") carries ideological weight analysis must unpack.
c11_hin_ar_cbse_04_011: Language usage (Hindustani vs. Sanskritized Hindi) marks power — analysis reads this code.
c11_hin_ar_cbse_04_012: Literal/inferential comprehension is the *floor* — analysis is the *ceiling* built on it.

## FORWARD_NODE_IDS
c11_hin_ar_cbse_04_014, c11_hin_ar_cbse_04_015, c12_hin_a_cbse_02_013, c12_hin_a_cbse_17_013, c12_hin_al_cbse_02_013, c12_hin_ar_cbse_03_013, c12_hin_ar_cbse_04_013, c12_hin_ar_cbse_04_003

## FORWARD_REASONS
c11_hin_ar_cbse_04_014: Writing skills require analytical content — this node supplies the claims, evidence, and reasoning for essays.
c11_hin_ar_cbse_04_015: Speaking/listening discussions need interpreted positions — this node teaches how to form and defend them.
c12_hin_a_cbse_02_013: Class 11 analysis of Nirala's "Juhi Ki Kali" transfers device-recognition skills.  
c12_hin_a_cbse_17_013: Develops ability to handle etymological arguments.  
c12_hin_al_cbse_02_013: Built experience in evaluating an author's stance vs. narrator's stance.  
c12_hin_ar_cbse_03_013: अगला तार्किक चरण: Critical Thinking: इस नोड की अवधारणाओं को सीधे उपयोग/विस्तारित करता है।  
c12_hin_ar_cbse_04_013: Class 11 critical thinking practice establishes the analytical framework.  
c12_hin_ar_cbse_04_003: Builds on Class 11 skill of identifying sensory imagery (c11_hin_ar_cbse_04_008) and distinguishing literal from figurative meaning (c11_hin_ar_cbse_04_013).  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
No prior class nodes available for Hindi Aroh, but conceptual bridges exist (see CROSS_SUBJECT below).

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_04_012 -> c11_hin_ar_cbse_04_013 -> c11_hin_ar_cbse_04_014

## THIS_FORMULA
PEEL Analytical Framework: **P**oint (interpretive claim) → **E**vidence (textual quote/paraphrase) → **E**xplanation (how evidence proves claim via literary device) → **L**ink (connect to theme/historical context/author's purpose)

## FORMULA_VARIABLES
P = Interpretive claim (e.g., "Lytton's rhetoric masks coercion as care")  
E = Specific Hindi phrase/sentence from text (e.g., "तुम्हारे हित में...")  
E = Device + Effect analysis (e.g., "उपमा + व्यंग्य: 'पिता समान' कहकर सत्ता का व्यक्तिगतकरण")  
L = Connection to chapter's central concern (e.g., "यह औपनिवेशिक 'संरक्षण' के छद्म को उजागर करता है")

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
analytical

## CROSS_SUBJECT
c11_history_colonialism | The chapter dramatizes the "subsidiary alliance" system and "doctrine of lapse" — analysis here mirrors historical source criticism: reading colonial archives "against the grain."
c11_politicalscience_power | Lytton's dialogue exemplifies "hegemony" (Gramsci) — power maintained through consent manufactured by rhetoric, not just force. Analysis here is applied political theory.
c11_economics_land_revenue | References to "लगान", "जागीर", "सिंचाई" reflect land revenue systems (Permanent Settlement, Ryotwari) — analysis connects literary representation to economic exploitation.

## PREREQ_CONCEPT
Dramatic irony as a structural device: the gap between a speaker's stated intent and the textual reality the author constructs around them.

## PREREQ_BEFORE
Student must be able to locate the confrontation scene (pp. 46-51), identify the two speakers, and summarize the literal exchange without interpretation.

## PREREQ_STUCK
If stuck, return to **node 009 (Irony and Symbolism)** and re-practice identifying *verbal irony* in 3 short dialogues from the chapter — this is the micro-skill analysis scales up from.

## WORKED_EXAMPLE_1
PROBLEM: Analyze how the author uses the motif of "voice/sound" (आवाज़, ध्वनि, नक़्क़ारख़ाना, तूती) to represent the ruler's agency across the chapter. Write a PEEL paragraph.

STEPS:
- Step 1: **Scan for the motif** — Search the text for all sound/voice words: "नक़्क़ारख़ाने में तूती की आवाज़" (p.47), "आवाज़ नहीं निकली" (p.48), "तुम्हारी आवाज़ कौन सुनेगा" (p.49), "मेरी आवाज़..." (p.51 ruler's speech).
- Step 2: **Map the trajectory** — Early: voice = suppressed ("दबी"). Middle: voice = threatened ("नहीं निकलेगी"). End: voice = reclaimed ("मेरी आवाज़... आने वालों तक").
- Step 3: **Identify the device** — **Extended metaphor**: the "नक़्क़ारख़ाना" (drum-house) symbolizes colonial noise/propaganda; the "तूती" (small drum/voice) is indigenous truth. The shift from "दबी" to "गूंजेगी" marks resistance.
- Step 4: **Draft PEEL** — P: The sound motif traces the ruler's journey from silencing to testimony. E: "नक़्क़ारख़ाने में तूती की आवाज़" → "मेरी आवाज़ मेरे पीछे आने वालों तक पहुँचे". E: The metaphor inverts — initially the *colonial* noise drowns the *indigenous* voice; by the end, the ruler's voice *becomes* the drum that future generations will hear. L: This mirrors the chapter's argument: colonialism controls the present narrative, but resistance owns the future archive.
- Step 5: **Verify against theme** — Does this support "colonial façade vs. resistant truth"? Yes — the motif makes the abstract tangible.

REASONING: This example models *motif tracking* — a core analytical skill where a recurring image/word is traced to reveal thematic architecture. The 5 steps move from data collection (scan) to pattern recognition (map) to device naming (identify) to structured argument (draft) to thematic validation (verify).

ANSWER: **The sound motif traces the ruler's journey from silencing to testimony. In the opening, "नक़्क़ारख़ाने में तूती की आवाज़" establishes the colonial soundscape — overwhelming state noise (नक़्क़ारख़ाना) drowning the fragile indigenous voice (तूती). By the climax, Lytton threatens "तुम्हारी आवाज़ कौन सुनेगा," confirming the regime's strategy of epistemic erasure. But the ruler's final speech reclaims the metaphor: "मेरी आवाज़ मेरे पीछे आने वालों तक पहुँचे" transforms the तूती from a drowned sound into a transmitting drum. The author thus uses the same acoustic imagery to show that while colonialism monopolizes the *present* soundscape, resistance secures the *future* archive. This sonic trajectory embodies the chapter's central argument: the façade of power (noise) is temporary; the truth of resistance (voice) is intergenerational.**

## WORKED_EXAMPLE_2
PROBLEM: The chapter uses **lexical register shift** (Hindustani vs. Sanskritized Hindi) to mark power. Analyze two moments where Lytton's language switches registers, and explain what each switch reveals about his strategy.

STEPS:
- Step 1: **Define the registers** — Hindustani (Perso-Arabic vocabulary: "हुकूमत", "इन्साफ", "रिआया", "फैसला") = administrative/colonial register. Sanskritized Hindi (Tatsama: "संरक्षण", "प्रजा", "धर्म", "न्याय") = indigenous/legitimacy register.
- Step 2: **Locate Switch 1** — p.47: Lytton opens with "सरकार की हुकूमत में..." (Hindustani) → shifts to "तुम्हारे पूर्वजों का धर्म था..." (Sanskritized). Why? He uses *colonial* register for authority ("हुकूमत"), *indigenous* register for moral coercion ("धर्म").
- Step 3: **Locate Switch 2** — p.50: "मैंने तुम्हारी रिआया का ख्याल रखा" (Hindustani) → "तुम्हारा सिंहासन तुम्हारी विरासत है" (Sanskritized). Why? "रिआया" reduces subjects to revenue units; "विरासत/सिंहासन" flatters the ruler's ego to secure compliance.
- Step 4: **Analyze the pattern** — Lytton **code-switches strategically**: Hindustani for *extraction* (tax, order, control), Sanskritized for *seduction* (tradition, honor, legacy). This is **linguistic mimicry** — adopting the colonized's sacred vocabulary to legitimize profane power.
- Step 5: **Connect to postcolonial theory** — This mirrors Bhabha's "almost the same, but not quite" — the mimicry *exposes* the colonizer's dependence on the colonized's cultural capital.

REASONING: This example demonstrates *linguistic analysis* as critical thinking — moving beyond "what is said" to "how language *performs* power." The 5 steps progress from register definition to textual location to strategic analysis to pattern synthesis to theoretical framing.

ANSWER: **Lytton's register switching reveals colonial power as performative mimicry. First switch (p.47): "हुकूमत" (Hindustani — bureaucratic authority) → "धर्म" (Sanskritized — moral obligation). He invokes the *colonial state's* legitimacy to demand the *ruler's* traditional duty — framing exploitation as dharmic compliance. Second switch (p.50): "रिआया" (Hindustani — revenue subject) → "विरासत/सिंहासन" (Sanskritized — sacred lineage). He reduces people to taxable units while inflating the ruler's symbolic capital to buy collaboration. The pattern: Hindustani = *extraction* (material control), Sanskritized = *seduction* (ideological capture). This linguistic duality embodies the chapter's thesis: colonialism speaks in two tongues — the language of force and the language of fraud — and the ruler's tragedy is that he hears both as one.**

## WORKED_EXAMPLE_3
PROBLEM: Synthesize nodes 006, 008, and 009 to answer: "How do the *primary theme* (colonial façade), *imagery* (light/dark, sound/silence), and *irony* (verbal, dramatic, situational) **converge in the final confrontation** (pp. 50-51) to produce the chapter's closing argument? Write a 150-word analytical response."

STEPS:
- Step 1: **Retrieve the three nodes' core insights** — Node 006: Theme = "सत्ता का छद्म" (façade of power). Node 008: Key imagery = "नक़्क़ारख़ाना/तूती" (sound), "अंधेरा/रोशनी" (epistemic violence). Node 009: Irony types — Lytton's verbal irony ("तुम्हारे हित में"), dramatic irony (reader knows ruler's inner truth), situational irony (ruler's "defeat" becomes moral victory).
- Step 2: **Close-read the final confrontation** (pp. 50-51) — Mark every convergence: Lytton's "रोशनी" (light = progress) vs. ruler's "अंधेरे में धकेला" (darkness = erasure); Lytton's verbal irony "तुम्हारी भलाई" vs. ruler's dramatic irony (silent knowledge of betrayal); situational irony — Lytton thinks he's won, text shows he's lost the narrative.
- Step 3: **Map the convergence** — Create a 3-column table: Theme | Imagery | Irony | Convergence Effect. Row 1: Façade | Light/Dark | Verbal | Lytton's "light" is the *glare* of exposure. Row 2: Resistance | Sound/Silence | Dramatic | Ruler's silence *speaks* louder. Row 3: History | Archive/Voice | Situational | "Defeat" becomes *testimony*.
- Step 4: **Draft synthesis** — Use PEEL x3 (one per convergence), then a unifying L. P1: The light/dark imagery materializes the façade theme through verbal irony. E1: "रोशनी लाया हूँ" / "अंधेरे में धकेला". E1: Verbal irony — "light" = epistemic violence. L1: Colonial modernity *is* the darkness it claims to dispel. P2: Sound motif enacts resistance through dramatic irony. E2: "नक़्क़ारख़ाना" vs. "मेरी आवाज़". E2: Reader hears what Lytton cannot — the ruler's interior testimony. L2: Narrative agency survives political defeat. P3: Situational irony seals the argument: the "victor" loses the story.
- Step 5: **Condense to 150 words** — Trim to essential claims + sharpest evidence. Final polish for board-exam precision.
- Step 6: **Verify multi-node integration** — Check: Theme (006) ✓ Imagery (008) ✓ Irony (009) ✓ Convergence in final scene ✓ PEEL structure ✓ Word limit ✓.

REASONING: This is the *capstone* worked example — it demands **inter-nodal synthesis**, the hallmark of senior-secondary critical thinking. The 6 steps model how to: retrieve prior learning, close-read for convergence, structure multi-evidence analysis, compose under constraints, and self-verify against criteria. This mirrors Board "Long Answer Type" questions requiring integration of theme, device, and structure.

ANSWER: **The final confrontation converges the chapter's three analytical pillars to expose colonialism's fatal contradiction. First, the light/dark imagery materializes the "façade of power" theme through verbal irony: Lytton's "मैं रोशनी लाया हूँ" (I brought light) is instantly undermined by the ruler's "तुमने हमें अंधेरे में धकेला" (you pushed us into darkness) — colonial modernity *is* the epistemic violence it claims to cure. Second, the sound motif (नक़्क़ारख़ाना/तूती) enacts resistance through dramatic irony: the reader accesses the ruler's interior testimony ("मेरी आवाज़ मेरे पीछे आने वालों तक पहुँचे") which Lytton's colonial noise cannot silence — narrative agency survives political defeat. Third, situational irony delivers the closing argument: Lytton believes he has secured the "सिंहासन" (throne), but the text's last words belong to the ruler, turning the conqueror's victory into the conquered's archive. Together, these convergences prove the chapter's thesis: the façade cracks not from outside force, but from the *internal testimony* it tries to erase.**

## COMPETENCY_QUESTION_1
QUESTION: A Class 11 student writes this analysis: "The author shows Lytton as evil and the ruler as good. The irony is that Lytton lies." Identify **three specific analytical failures** in this response and rewrite it as a Board-level PEEL paragraph using evidence from the final confrontation (p.51).

COMPETENCY: Analytical precision — distinguishing moral judgment from literary analysis, identifying device-specific irony, and structuring evidence-based argument.

STEPS:
- Step 1: Diagnose Failure 1 — "Evil/good" is moralizing, not analyzing. Analysis examines *how* the text constructs complexity (Lytton's rhetoric *mimics* benevolence; ruler's resistance *contains* compromise).
- Step 2: Diagnose Failure 2 — "Lytton lies" reduces *verbal irony* to mere falsehood. Irony requires *structural gap* between utterance and context — here, Lytton's words *perform* the colonial logic they conceal.
- Step 3: Diagnose Failure 3 — No textual evidence, no device naming, no thematic link. Board answers require: Quote → Device → Effect → Theme.
- Step 4: Rewrite using PEEL on p.51 ruler's speech: P: The ruler's final speech exposes colonial façade through *reclaimed narrative agency*. E: "हट्क्क्स्स हक्क्जर! इस आज़तक़्क़्क़ रक़्क़... मेरे पीछे आने वालों..." E: **Apostrophe** (addressing absent future) + **Anaphora** ("मेरे... मेरे...") constructs intergenerational witness; **lexical reclamation** ("आज़तक़्क़्क़" — freedom/history) counters Lytton's "हुकूमत". L: The text closes not on defeat but on *testimony* — the façade cracks because the ruled *speak the archive*.

ANSWER: **The ruler's final speech exposes the colonial façade through reclaimed narrative agency. When he declares "हट्क्क्स्स हक्क्जर! इस आज़तक़्क़्क़ रक़्क़... मेरे पीछे आने वालों..." the apostrophe to future generations ("मेरे पीछे आने वालों") and anaphoric insistence ("मेरे... मेरे...") construct an intergenerational witness that Lytton's colonial rhetoric ("हुकूमत", "इन्साफ") cannot contain. The lexical reclamation of "आज़तक़्क़्क़" (history/freedom) directly counters the administrative vocabulary of extraction. This is not moral triumph but *discursive* triumph: the chapter ends with the ruled voice controlling the story's closure, proving that the façade of power fractures when the colonized seize the archive. The irony is not that Lytton lies — it is that his language *unwittingly creates the terms of its own exposure*.**

DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: "The chapter's critique of colonialism fails because it focuses only on a princely ruler — an elite — ignoring the peasantry who suffered most." Evaluate this claim by analyzing **how the text *represents* (or *excludes*) the subaltern**. Use at least two textual moments and one concept from postcolonial theory (e.g., Spivak's "subaltern cannot speak," Guha's "subaltern studies").

COMPETENCY: Theoretical application — using postcolonial concepts to evaluate a text's political limitations, not just its themes.

STEPS:
- Step 1: **Unpack the claim** — It argues the text commits "elite capture" of anti-colonial narrative. Valid critique? Partially — but the *text itself* stages this tension.
- Step 2: **Locate Moment 1 (exclusion)** — p.47: "तुम्हारी रिआया खुश थी" (Lytton) / ruler's silence. The peasant ("रिआया") is *spoken for* by both men — neither lets her speak. This *enacts* Spivak: the subaltern is the *object* of elite debate.
- Step 3: **Locate Moment 2 (trace presence)** — p.48: "नक़्क़ारख़ाने में तूती की आवाज़" — the "तूती" *could* be the peasant voice drowned by both colonial *and* princely "नक़्क़ारख़ाना". The metaphor *haunts* the text with the excluded.
- Step 4: **Apply Guha** — Subaltern Studies reads elite archives "against the grain" to recover peasant insurgency. Here, the *ruler's* archive (the chapter) *contains* the trace of what it excludes — the "तूती" is the subaltern's ghost in the elite's machine.
- Step 5: **Synthesize evaluation** — The claim is *textually grounded but interpretively incomplete*. The text doesn't "ignore" the peasantry — it *stages their silencing* as the condition of both colonial and princely power. The critique belongs *inside* the analysis, not outside it.

ANSWER: **The claim identifies a real exclusion but misreads its function. The text does not merely "ignore" the peasantry — it *dramatizes their silencing* as the shared foundation of colonial and princely authority. Moment 1: Lytton's "तुम्हारी रिआया खुश थी" and the ruler's silence jointly constitute the peasant as *spoken-for object* — a textual enactment of Spivak's "subaltern cannot speak." Moment 2: The central metaphor "नक़्क़ारख़ाने में तूती की आवाज़" haunts the narrative: the "तूती" (subaltern voice) is drowned not just by colonial "नक़्क़ारख़ाना" but by the *entire elite soundscape*, including the ruler's. Guha would read this as the elite archive *bearing the trace* of what it suppresses. Thus, the chapter's limitation *is* its method: by centering the ruler, it makes the peasant's absence *audible*. The critique doesn't refute the text — it *deepens* the analysis: colonialism and its native collaborators *both* rely on subaltern erasure. A Board-level answer would argue: the text's elite focus is not a flaw but a *diagnosis* of how power, colonial and indigenous, operates through the same silencing.**

DIFFICULTY: hard