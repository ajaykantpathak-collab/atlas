## DEFINITION
Irony is a literary device where there is a contradiction between appearance and reality, expectation and outcome, or what is said and what is meant; Symbolism is the use of concrete objects, characters, or actions to represent abstract ideas, qualities, or concepts beyond their literal meaning.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student can independently identify specific instances of irony (situational, verbal, dramatic) and symbolism in Nagarjun's poem "lk;s esa /wi", explain the gap between literal and intended meaning, and articulate how these devices deepen the poem's critique of socio-political indifference.

## SCOPE_BOUNDARY
This node covers the identification, classification, and analytical explanation of irony and symbolism specifically within the prescribed poem "lk;s esa /wi" from Chapter 13. It does not cover other poems, extended allegory, or the history of these devices in world literature.

## WALKTHROUGH
Imagine you see a signboard outside a government office saying "Public Service Centre" but the gates are locked and the peon demands a bribe to let you in. That jarring gap between the board's promise and the reality is irony. Now, think of the "fpjkx" (footwear) left outside a temple — it literally protects feet, but symbolically represents the devotee's humility and the social hierarchy that demands its removal. In this poem, Nagarjun uses the "lk;s esa /wi" (house of the dead) not just as a setting, but as a brutal symbol of a society where the living poor are treated worse than corpses. We will first map the literal scene, then hunt for the contradictions (irony), and finally decode the objects that carry heavier meanings (symbolism).

## DIAGNOSTIC_QUESTION_1
Define 'situational irony' and 'symbol' in your own words, giving one generic example for each (not from the poem).

## DIAGNOSTIC_ANSWER_1
**Correct Answer:** Situational irony occurs when the actual outcome of a situation is starkly opposite to what was expected or considered appropriate (e.g., a fire station burning down). A symbol is a concrete object, person, or action that stands for an abstract idea while retaining its literal identity (e.g., a dove representing peace).  
**Misconception Alert:** If a student defines irony merely as "something funny" or "sarcasm", they confuse tone with structural contradiction. If they define a symbol as "a metaphor", they miss the crucial distinction that a symbol operates persistently across a work and retains its literal existence, whereas a metaphor is a direct, often transient, comparison.

## DIAGNOSTIC_QUESTION_2
In the first stanza of the poem, the speaker lists reasons people come to the "lk;s esa /wi" (house of the dead): "fpjkxk¡ gjsoQ ?kj osQ fy," (footwear for the sake of a house) and "mez Hkj osQ fy," (to fill the stomach). Explain why this constitutes situational irony. What is the expected function of a mortuary versus the reality depicted?

## DIAGNOSTIC_ANSWER_2
**Correct Answer:** A mortuary is socially and functionally designated for the *dead* — a place of final rest, silence, and mourning. The irony lies in the *living* poor invading this space not for mourning, but for basic survival: shelter ("?kj") and food ("mez"). The contradiction is structural: a space meant for the absolute end of life (death) becomes the only refuge for sustaining life (survival).  
**Misconception Alert:** A student who merely says "it is sad" or "poor people live there" has identified the *theme* (poverty) but missed the *device* (irony). They must articulate the **clash of functions**: Death-house vs. Life-shelter.

## DIAGNOSTIC_QUESTION_3
The word "fpjkx" (footwear/sandals) appears twice in the first stanza ("fpjkxk¡ gjsoQ ?kj osQ fy," and "fpjkx e;Llj ugha 'kgj osQ fy,"). Apply the concept of symbolism: What abstract idea does "fpjkx" represent in this context? Justify using the lines "u gks deh”k rks ik¡oksa ls isV <¡d ysaxs" (if not delayed, they will snatch the skin off the soles).

## DIAGNOSTIC_ANSWER_3
**Correct Answer:** The "fpjkx" symbolizes **the fragile dignity and minimal material possession of the destitute**. Literally, it is footwear. Symbolically, it represents the last barrier between the poor and total dehumanization ("ik¡oksa ls isV <¡d" — skin peeled off soles). The threat of losing even this meagre protection to the cruelty of the system ("yksx fdrus equkflc gSa") elevates the object to a symbol of precarious existence.  
**Misconception Alert:** If a student says "fpjkx symbolizes poverty", that is a *theme*, not a *symbolic reading*. The symbol is the *vehicle* (footwear); the tenor is *dignity/protection*. They must separate the concrete object from the abstract concept it carries.

## DIAGNOSTIC_QUESTION_4
Analyze the relationship between the irony in Stanza 1 (living occupying a dead-house) and the symbolism in Stanza 2 ("vius cxhps esa xqyeksgj osQ rys" vs "xSj dh xfy;ksa esa xqyeksgj"). How does the poet use the *contrast in curiosity* to sharpen the socio-political critique?

## DIAGNOSTIC_ANSWER_4
**Correct Answer:** Stanza 1 establishes the **situational irony** of spatial inversion (mortuary → home). Stanza 2 deepens this through **symbolic contrast of "xqyeksgj" (curiosity)**. The powerful/privileged ("cxhps" — those with influence) possess curiosity as a *luxury* ("rys" — hobby/pastime), observing suffering from a distance. The poet/speaker ("ejsa") experiences curiosity as a *wound* ("xSj dh xfy;ksa" — thorns of pain), born of lived trauma. This contrast symbolizes the unbridgeable class divide: for the elite, poverty is an intellectual spectacle; for the poor, it is a lacerating reality. The irony of the mortuary-home is thus explained by this symbolic gap in perception.  
**Misconception Alert:** A student treating the two stanzas as separate points (one irony, one symbolism) misses the **structural integration**. The devices work *together*: the irony creates the scene; the symbolism diagnoses the cause (apathy of the powerful).

## DIAGNOSTIC_QUESTION_5
Evaluate the effectiveness of the final two lines as a culminating symbol: "rsjk fu”kke gS fly ns ”kqcku 'kk;j dh] ;s ,gfr;kr ”k:jh gS bl cgj osQ fy," (The ruler's command is to fly the flag of hollow peace; this arrangement is for the sake of this world/order). Does the symbol of the "fly ns ”kqcku 'kk;j" (flag of hollow peace) successfully synthesize the poem's irony? Justify your judgment.

## DIAGNOSTIC_ANSWER_5
**Correct Answer:** Yes, it is highly effective. The "flag of hollow peace" (**symbol**) represents the State's performative rhetoric — grand, visible, empty. It flies *above* the "lk;s esa /wi" where the irony (living dying in a dead-house) plays out *below*. The symbol **encapsulates the central irony**: the State claims to guarantee order/peace ("cgj" — world/order), but its actual "arrangement" (" ,gfr;kr") produces the mortuary-home for the poor. The flag *is* the irony made visible: a symbol of protection that only marks the territory of neglect.  
**Misconception Alert:** A student calling it "just a metaphor for the government" reduces a complex symbol to a simple substitution. Evaluation requires weighing the **symbol's capacity to hold multiple tensions**: sovereignty vs. neglect, visibility vs. invisibility, rhetoric vs. reality.

## DIAGNOSTIC_QUESTION_6
Create a 4-line stanza (in Hindi or English) depicting a contemporary urban irony using a central symbol (e.g., a shiny mall, a smart phone, a flyover). The stanza must show a contradiction between appearance/reality (irony) and use an object to represent a deeper systemic issue (symbolism).

## DIAGNOSTIC_ANSWER_6
**Criteria for a Good Answer:**  
1. **Clear Irony:** A stated purpose vs. actual outcome (e.g., "Free Wi-Fi zone / Where no one speaks").  
2. **Central Symbol:** One concrete object carrying the weight (e.g., the "Flyover" shading the slum).  
3. **Systemic Link:** The symbol points to policy/planning failure, not just individual bad luck.  
**Example:**  
*Chamakti sheeshe ki deewarein, "Vikas" ka naya naam,*  
*Neeche sulagti jhuggi, dhoop mein bechaara kaam.*  
*Flyover ka saaya bada, par chhaanv nahin kisi ko,*  
*Yeh "Smart City" ka nishan, hai garib ki qabristan.*  
**Poor Answer Reveals:** Using only adjectives ("sad mall") without structural contradiction, or using a symbol decoratively (e.g., "phone = connection") without irony.

## COMMON_MISCONCEPTION
Students frequently conflate **irony** with **coincidence** or **misfortune**. They read the poor living in a mortuary and say "It is ironic that they are poor." No — poverty is the context; the irony is the *specific functional perversion* of a death-house becoming a life-shelter. Similarly, they treat **symbolism** as a "hidden code" where *everything* stands for something else (e.g., "the wall symbolizes barriers"). They fail to distinguish a **literary symbol** (rooted in the text's logic, recurring, multivalent) from a **private association**. In this poem, "fpjkx" is a symbol because the text *builds* its meaning through threat ("ik¡oksa ls isV <¡d ysaxs"); a random "wall" mentioned once is just imagery.

## ON_FAILURE
1. **Isolate the Literal Level:** Ask the student to draw the physical scene of Stanza 1: a building, a sign "Mortuary", people sleeping, eating, storing shoes. Confirm they see the *literal* reality.  
2. **Name the Expected Function:** Ask: "What is this building *supposed* to be for?" (Dead bodies). Write it down.  
3. **Name the Actual Function:** Ask: "What is it *actually* used for in the poem?" (Living humans' shelter/food). Write it down.  
4. **Define the Gap:** "Irony = The Gap between Step 2 and Step 3." Drill this definition.  
5. **Symbol Hunt:** Pick *one* object (fpjkx). Ask: "If this object could speak, what would it say about the owner's life?" Guide from "protects feet" → "protects dignity" → "last possession".  
6. **Connect:** "The irony (wrong building) creates the conditions where the symbol (shoes) becomes a lifeline."

## BUILDS_ON
c11_hin_ar_cbse_13_008 (Literary Devices: Imagery and Metaphor) — students must already distinguish literal imagery from figurative comparison to grasp how a symbol differs from a metaphor.

## LEADS_TO
c11_hin_ar_cbse_13_010 (Vocabulary in Context: Key Words) — understanding irony/symbolism is prerequisite for explaining nuanced vocabulary like "equkflc" (cruel/heartless) or " ,gfr;kr" (arrangement/system) in their contextual depth.

## PREREQUISITE_NODE_IDS
c11_hin_ar_cbse_13_008, c11_hin_ar_cbse_13_006, c11_hin_ar_cbse_13_007, c11_hin_ar_cbse_13_001, c11_hin_ar_cbse_13_002

## PREREQUISITE_REASONS
c11_hin_ar_cbse_13_008: Provides the foundational skill of distinguishing literal vs. figurative language (imagery/metaphor) essential for identifying symbolism.
c11_hin_ar_cbse_13_006: Establishes the Primary Theme (socio-political indifference/poverty) which is the *content* that irony and symbolism *express*.
c11_hin_ar_cbse_13_007: Secondary themes (human dignity, systemic cruelty) provide the specific abstract concepts that the symbols (fpjkx, flag) concretize.
c11_hin_ar_cbse_13_001: "Before You Read: की समझ आवश्यक है, क्योंकि यह नोड (Irony is a literary device where there is a contradiction between appearance and reality,...) इसी आधार पर आगे बढ़ता है।  
c11_hin_ar_cbse_13_002: If stuck, re-read the "Text: Plot and Narrative Structure" (c11_hin_ar_cbse_13_002) and "Theme: Primary Theme" (c11_hin_ar_cbse_13_006) nodes to lock down the what and why before tackling the how (devices).  

## FORWARD_NODE_IDS
c11_hin_ar_cbse_13_010, c11_hin_ar_cbse_13_012, c11_hin_ar_cbse_13_013, c11_hin_ar_cbse_13_014, c12_hin_a_cbse_05_009, c12_hin_a_cbse_10_009, c12_hin_a_cbse_13_009, c12_hin_al_cbse_01_009, c12_hin_ar_cbse_09_009, c12_hin_ar_cbse_12_009, c12_hin_ar_cbse_13_009

## FORWARD_REASONS
c11_hin_ar_cbse_13_010: Key vocabulary (e.g., "fu”kke", " ,gfr;kr", "equkflc") acquires its full force only when understood as parts of the ironic/symbolic structure.
c11_hin_ar_cbse_13_012: Inferential comprehension questions (e.g., "Why does the poet call the peace 'hollow'?") require the analytical framework built here.
c11_hin_ar_cbse_13_013: Critical interpretation (e.g., "Analyze the poem as a satire") is impossible without mastering the devices of irony and symbolism.
c11_hin_ar_cbse_13_014: Writing analytical paragraphs (PEEL structure) on literary devices uses the worked examples from this node as templates.
c12_hin_a_cbse_05_009: अगला तार्किक चरण: Irony is a literary device where the intended meaning of words or a situation is opposite to their l... इस नोड की अवधारणाओं को सीधे उपयोग/विस्तारित करता है।  
c12_hin_a_cbse_10_009: Chapter 13 analyzed irony in epistolic form — expands structural understanding.  
c12_hin_a_cbse_13_009: Class 11 node covers the foundational definitions and types of irony (verbal, situational, dramatic) and symbol categories (conventional, contextual); Class 12 deepens this with textual application and device interplay.  
c12_hin_al_cbse_01_009: Class 11 Antra Chapter 13 Irony and Symbolism node adds nuance.  
c12_hin_ar_cbse_09_009: Prepares for competency-based evaluation questions.  
c12_hin_ar_cbse_12_009: अगला तार्किक चरण: Irony in this story is the contrast between appearance and reality — where the wealthy waste water c... इस नोड की अवधारणाओं को सीधे उपयोग/विस्तारित करता है।  
c12_hin_ar_cbse_13_009: अगला तार्किक चरण: Irony (व्यंग्य/विडंबना) is a literary device where the intended meaning of words or events is opposi... इस नोड की अवधारणाओं को सीधे उपयोग/विस्तारित करता है।  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
none

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_13_008 -> c11_hin_ar_cbse_13_009 -> c11_hin_ar_cbse_13_010

## THIS_FORMULA
N/A - conceptual

## FORMULA_VARIABLES
N/A

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
analytical

## CROSS_SUBJECT
c11_polsc_democratic_rights | The poem's critique of the State ("fu”kke", " ,gfr;kr") failing its poorest citizens mirrors the Political Science concept of 'Substantive vs. Procedural Democracy' — the flag (procedure) flies while rights (substance) are denied in the mortuary-home.
c11_sociology_social_inequality | The symbol of "fpjkx" (footwear) as the last marker of dignity connects to the Sociological concept of 'Material Deprivation' and 'Symbolic Boundaries' — how minimal possessions define the boundary between human and 'waste life' in stratification systems.

## PREREQ_CONCEPT
Ability to distinguish between the literal denotation of a word/image and its connotative, figurative, or structural function in a text.

## PREREQ_BEFORE
Student must have read the poem "lk;s esa /wi" at least twice: once for literal narrative flow (who, where, what), and once marking every object/phrase that feels "heavier" than its dictionary meaning.

## PREREQ_STUCK
If stuck, re-read the "Text: Plot and Narrative Structure" (c11_hin_ar_cbse_13_002) and "Theme: Primary Theme" (c11_hin_ar_cbse_13_006) nodes to lock down the *what* and *why* before tackling the *how* (devices).

## WORKED_EXAMPLE_1
PROBLEM: Analyze the situational irony in the first stanza of "lk;s esa /wi" using the 4-step method: (1) Identify the Expected Norm, (2) Identify the Actual Reality, (3) Articulate the Contradiction, (4) Link to Theme.
STEPS:
- Step 1: Identify the Expected Norm. The poem's title and setting ("lk;s esa /wi") establish the normative function: a mortuary is a designated space for the *dead* — for post-mortem, storage of corpses, and final rites. It is a space of stillness, hygiene, and legal/medical procedure.
- Step 2: Identify the Actual Reality. The stanza describes living humans ("yksx") entering this space for "fpjkxk¡ gjsoQ ?kj osQ fy," (footwear/house) and "mez Hkj osQ fy," (filling stomach). They are not mourners or staff; they are the homeless poor seeking shelter and food.
- Step 3: Articulate the Contradiction. The core irony is **Functional Inversion**: A space architected for the *end of biological life* (death) becomes the only available infrastructure for the *continuation of biological life* (survival) for the marginalized. The "dead-house" hosts the living; the "living-world" (outside) kills them (exposure, hunger).
- Step 4: Link to Theme. This irony is not accidental; it is the poem's central evidence for the Primary Theme (c11_hin_ar_cbse_13_006): **Systemic Indifference**. The State provides a building for the dead (respectable, visible) but zero infrastructure for the living poor (invisible, expendable). The irony *is* the indictment.
REASONING: This 4-step method forces the student to move beyond "it's sad" to structural analysis. Steps 1-2 establish the binary; Step 3 names the specific type of irony (situational/functional); Step 4 anchors the device to the theme, which is the exam requirement.
ANSWER: The situational irony in Stanza 1 is the functional inversion of the mortuary: designed for the dead, it serves as the sole shelter for the living poor. This contradiction exposes the State's prioritization of procedural dignity for corpses over substantive survival for citizens, directly embodying the theme of socio-political cruelty.

## WORKED_EXAMPLE_2
PROBLEM: Trace the symbolism of "xqyeksgj" (curiosity) across Stanza 2 ("vius cxhps esa xqyeksgj osQ rys" vs "ejsa rks xSj dh xfy;ksa esa xqyeksgj osQ fy,") using the 5-step Symbol Analysis Protocol: (1) Locate the Literal Object/Action, (2) Identify the Abstract Concept, (3) Show the Textual Bridge (how the text builds the link), (4) Determine the Symbol's Valence (positive/negative/ambivalent), (5) State the Thematic Contribution.
STEPS:
- Step 1: Locate the Literal Object/Action. The word "xqyeksgj" (curiosity/inquisitiveness) appears twice in Stanza 2, possessed by two different subjects: "vius cxhps" (the powerful/elite) and "ejsa" (the poet/speaker).
- Step 2: Identify the Abstract Concept. The abstract concept is **Mode of Engagement with Suffering** — how consciousness relates to the pain of others.
- Step 3: Show the Textual Bridge. For the elite ("cxhps"), curiosity is a "rys" (hobby, pastime, luxury) — detached, voluntary, safe ("cxhps" implies height/distance). For the poet ("ejsa"), curiosity is "xSj dh xfy;ksa" (thorns of pain) — involuntary, wounding, embodied ("xSj" = thorn, "xfy;k" = prick/wound). The text builds the link through the *contrast in prepositions*: "esa" (inside/within) for both, but the *container* differs: "rys" (leisure) vs "xfy;k" (injury).
- Step 4: Determine the Symbol's Valence. The symbol is **bifurcated/ambivalent**: Curiosity itself is neutral, but its *class-inflected forms* are polarized. Elite curiosity = negative (voyeurism, complicity). Poet's curiosity = positive/necessary (witnessing, truth-telling), though painful.
- Step 5: State the Thematic Contribution. This symbolism diagnoses *why* the irony of Stanza 1 persists. The mortuary-home exists because the powerful view poverty as a spectacle ("rys"), not a crisis ("xfy;k"). The symbol reveals the **epistemological root of political failure**: the ruling class's "curiosity" is structurally incapable of generating justice.
REASONING: Symbolism in senior secondary analysis requires tracking a term's *semantic shift* across contexts. The protocol prevents the student from saying "curiosity symbolizes interest" — a tautology. It forces the mapping of *contextual modifiers* (rys vs xfy;k) onto *social positions* (cxhps vs ejsa).
ANSWER: "xqyeksgj" functions as a bifurcated symbol of class-determined consciousness. For the elite, it is a detached hobby ("rys"), symbolizing voyeuristic complicity. For the poet, it is a wound ("xSj dh xfy;ksa"), symbolizing ethical witness. The contrast explains the persistence of the Stanza 1 irony: the system survives because its observers treat suffering as entertainment.

## WORKED_EXAMPLE_3
PROBLEM: Synthesize Irony and Symbolism: Explain how the final symbol "fly ns ”kqcku 'kk;j" (flag of hollow peace) *resolves* the poem's central irony (mortuary as home) by converting a spatial contradiction into a political statement. Use 6 steps.
STEPS:
- Step 1: Restate the Central Irony (from Worked Example 1). The mortuary (death-space) functions as home (life-space) for the poor. This is a *spatial/functional* irony located in the physical setting.
- Step 2: Identify the Culminating Symbol. The final couplet introduces "fly ns ”kqcku 'kk;j" (flag of hollow peace) as the emblem of the State's authority ("fu”kke") and the justification of the social order (" ,gfr;kr ... bl cgj osQ fy,").
- Step 3: Analyze the Symbol's Components. "Fly" = sovereignty, visibility, verticality (flies high). "”kqcku" = empty, false, performative. "'kk;j" = peace, order, legitimacy. Together: A highly visible claim of legitimate order that is internally empty.
- Step 4: Map Symbol onto Irony. The flag flies *above* the mortuary-home. The "peace" it claims is the *condition* that produces the irony: the "arrangement" ( ,gfr;kr) that builds mortuaries for the dead but not homes for the living *is* the "hollow peace". The irony (wrong building for wrong people) is the *material proof* of the symbol's hollowness.
- Step 5: Show the Conversion. The poem moves from **Spatial Irony** (Stanza 1: building misuse) → **Psychological Symbolism** (Stanza 2: curiosity gap) → **Political Symbol** (Stanza 3: flag). The flag *names* the system that produces the mortuary-home. The irony is no longer just a tragic scene; it is a *policy outcome* ("fu”kke").
- Step 6: Final Thematic Synthesis. The symbol "hollow peace flag" transforms the poem from a description of poverty into an **allegation of state violence**. The mortuary-home is not a failure of the system; it *is* the system (" ,gfr;kr ... bl cgj osQ fy,").
REASONING: Board exams (CBSE Class 11) frequently ask "How does the poet use irony and symbolism to criticize the system?" This worked example models the **synthesis answer**: showing how devices operate sequentially across stanzas to escalate from scene → analysis → accusation. The 6 steps mirror the 3 stanzas + synthesis.
ANSWER: The "flag of hollow peace" is the master symbol that politically anchors the mortuary-home irony. The irony (dead-house sheltering the living) is the material reality; the flag is the ideological cover. The symbol reveals that the "arrangement" (system) *requires* this irony to maintain its "peace". Thus, irony + symbolism = indictment of the State.

## COMPETENCY_QUESTION_1
QUESTION: "Nagarjun's poem uses the mortuary not just as a setting, but as an ironic symbol of the Indian Republic's failed contract with its poorest citizens." Do you agree? Support your answer by analyzing **one** specific irony and **one** specific symbol from the poem, showing how they work together.
COMPETENCY: Literary Analysis & Argumentation (CBSE Competency: Critical Thinking & Interpretation)
STEPS:
- Step 1: Take a clear stance (Agree/Disagree/Qualified) in the opening sentence.
- Step 2: Select and define the specific irony (e.g., Functional Inversion of Mortuary in Stanza 1).
- Step 3: Select and define the specific symbol (e.g., "fpjkx" or "fly ns ”kqcku 'kk;j").
- Step 4: Demonstrate the *interaction*: How the symbol deepens/explains the irony, or how the irony gives material weight to the symbol.
- Step 5: Conclude by linking the device-interaction to the "failed contract" thesis.
ANSWER: I agree. The central **situational irony** — a mortuary (death-space) serving as the only home (life-space) for the living poor — materializes the "failed contract": the State provides dignity in death (mortuary building) but denies the right to life (housing/food). This irony is politically decoded by the culminating **symbol of the "fly ns ”kqcku 'kk;j" (flag of hollow peace)**. The flag symbolizes the State's performative sovereignty: it flies high, claiming "peace" and "order" (cgj), while the "arrangement" ( ,gfr;kr) it legitimizes actively produces the mortuary-home. The irony *is* the ground reality; the symbol *is* the state's alibi. Together, they prove the contract is broken: the Republic builds monuments for the dead (flags, mortuaries) but offers only "hollow peace" to the living poor.
DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: Compare the use of **symbolism** in Nagarjun's "lk;s esa /wi" with the use of **metaphor** in a poem from your Class 10 syllabus (e.g., "The Road Not Taken" — roads as life choices; or "Dust of Snow" — crow/hemlock as redemption). Write a structured comparative paragraph answering: How does a *symbol* differ from a *metaphor* in its capacity to carry socio-political critique? Use the terms 'tenor', 'vehicle', 'fixity', and 'polysemy'.
COMPETENCY: Comparative Literary Analysis & Metaliterary Terminology (CBSE Competency: Intertextual Connection & Conceptual Precision)
STEPS:
- Step 1: Define Metaphor (Class 10 level): A direct, often localized comparison (Vehicle → Tenor) where the vehicle *is* the tenor for the duration of the image (e.g., "Road = Life Choice"). High fixity, low polysemy in context.
- Step 2: Define Symbol (Class 11 level): A concrete object retaining its literal identity while *accumulating* abstract meanings (Tenor) through textual recurrence and contextual pressure (e.g., "fpjkx" = footwear + dignity + vulnerability + systemic cruelty). Lower fixity, high polysemy.
- Step 3: Apply to Nagarjun: "fpjkx" remains footwear (literal) while signifying the precarious threshold of survival. Its meaning *expands* as the stanza progresses (from "house" to "skin off soles"). This **polysemy** allows it to carry the *systemic* critique (poverty, cruelty, dignity) simultaneously.
- Step 4: Apply to Class 10 Example (e.g., Frost's Roads): The roads *are* the choices (metaphor). Once the comparison is made, the vehicle (road) is largely exhausted. It carries *individual* existential critique, not *structural* socio-political critique.
- Step 5: Synthesize: Symbols are superior for socio-political critique because their **polysemy** mirrors the **complexity of structural oppression** (economic + psychological + political), whereas metaphors' **fixity** suits individual, psychological epiphanies.
ANSWER: In Class 10 metaphors (e.g., Frost's "Roads" as life choices), the vehicle (road) maps directly onto a single tenor (choice) with high fixity — the comparison is the point. In Nagarjun's "fpjkx" (footwear), the symbol retains its literal reality (poor man's chappal) while accumulating a *cluster* of tenors (dignity, vulnerability, systemic cruelty, the threshold of humanity) through textual pressure ("ik¡oksa ls isV <¡d ysaxs"). This **polysemy** — the capacity to hold multiple, simultaneous, unresolved meanings — is essential for socio-political critique because oppression is not a single comparison but a dense web of material, psychological, and institutional forces. A metaphor says "A is B"; a symbol says "A is A, and also B, C, D, and the system that produces them." The "flag of hollow peace" similarly condenses sovereignty, lie, violence, and legitimacy into one fluttering object — a density no metaphor can sustain.
DIFFICULTY: hard