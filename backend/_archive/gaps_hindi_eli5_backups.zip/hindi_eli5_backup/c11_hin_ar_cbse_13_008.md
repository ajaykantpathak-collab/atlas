## DEFINITION
Imagery is the use of vivid, sensory language that appeals to the five senses (sight, sound, touch, taste, smell) to create concrete mental pictures and evoke physical sensations in the reader. Metaphor is a figure of speech that directly equates two unlike things by stating one *is* the other, transferring qualities from the source domain to the target domain without using comparative words like 'like' or 'as'.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student can independently identify specific images and metaphors in the poem, explain their sensory effect and comparative logic, and articulate how each device deepens the poem's central theme of poverty and false promise.

## SCOPE_BOUNDARY
This node covers only imagery (visual, auditory, tactile, olfactory, gustatory) and metaphor as they appear in Nagarjun's poem "लक्ष्मी का स्वागत". It does not cover simile, personification, irony, symbolism, or other poetic devices addressed in sibling nodes.

## WALKTHROUGH
Imagine you are trying to describe the feeling of a bitter winter night to someone who has never felt cold. You could say "It is very cold" (a flat statement) or you could say "The wind is a knife that cuts through my woolens, and the air smells of frozen metal" (metaphor + olfactory/tactile imagery). The second version makes the listener *feel* the cold. Now open the poem and read the first stanza aloud. Notice which words make you *see* the cracked walls, *hear* the silence, *feel* the emptiness. Circle those words. Then ask: "Is the poet comparing Lakshmi to something without using 'like'?" That comparison is a metaphor. The key insight: every image and metaphor in this poem is a deliberate brushstroke painting the harsh reality that makes the irony of 'welcoming Lakshmi' sting.

## DIAGNOSTIC_QUESTION_1
Define 'imagery' and 'metaphor' in your own words, giving one original example of each (not from the textbook).

## DIAGNOSTIC_ANSWER_1
Imagery: descriptive language appealing to senses (e.g., "The smell of wet earth rose after the first rain"). Metaphor: direct comparison without 'like/as' (e.g., "Time is a thief"). A wrong answer that defines imagery only as 'visual description' reveals the misconception that imagery is solely about sight. A wrong answer that calls a simile ('brave as a lion') a metaphor reveals confusion between direct and indirect comparison.

## DIAGNOSTIC_QUESTION_2
In the poem's opening lines, the poet writes about "फटे हुए घर" (broken house) and "नज़रों के लश में लक्ष्मी". Explain how these phrases function as imagery and metaphor respectively. Why is the metaphor *not* a simile?

## DIAGNOSTIC_ANSWER_2
"फटे हुए घर" creates visual/tactile imagery of dilapidation, letting the reader see cracks and feel drafts. "नज़रों के लश में लक्ष्मी" (Lakshmi in the glare of eyes) metaphorically equates the goddess of wealth with a blinding, perhaps illusory, presence in the poor's gaze. It is not a simile because it does not use 'like' or 'as'; it states Lakshmi *is* that glare. A wrong answer that labels the first phrase a metaphor shows inability to distinguish sensory description from figurative equivalence.

## DIAGNOSTIC_QUESTION_3
Read the line: "ये लोग कितने एकाकी हैं इस लीके के लिए" (How lonely these people are for this ridge/path). Identify the dominant imagery type here and rewrite the line as a simile that retains the same comparison.

## DIAGNOSTIC_ANSWER_3
Dominant imagery: emotional/psychological (solitude) reinforced by visual imagery of a desolate ridge. Simile rewrite: "ये लोग इस लीके के लिए वैसे ही एकाकी हैं जैसे निर्जन वन में एक वृक्ष" (These people are as lonely for this ridge as a single tree in a deserted forest). A wrong answer that picks only 'visual' imagery misses the internal sensation; a rewrite that keeps 'like/as' but changes the compared object (e.g., "lonely like a cloud") fails to retain the original comparison.

## DIAGNOSTIC_QUESTION_4
Compare the metaphor "रजत का राजा" (king of silver) used for a coin/money in the poem with the imagery of "खाली थाली" (empty plate) in the same stanza. How do the two devices work together to sharpen the poem's critique of wealth?

## DIAGNOSTIC_ANSWER_4
"रजत का राजा" metaphorically elevates a mere silver coin to royalty, exposing the disproportionate power money holds over the poor. "खाली थाली" provides stark visual/tactile imagery of hunger. Together, the metaphor *aggrandizes* the oppressor (money) while the imagery *diminishes* the victim (empty plate), creating a brutal contrast that underscores exploitation. A wrong answer that treats them as separate decorative phrases misses their dialectical interplay.

## DIAGNOSTIC_QUESTION_5
Critique the view that the poem's metaphors are merely ornamental. Use evidence from at least two metaphors to argue whether they are essential to the poem's political message.

## DIAGNOSTIC_ANSWER_5
The metaphors are structural, not ornamental. "लक्ष्मी" as an uninvited guest who "आती नहीं, लाई जाती है" (does not come, is brought) metaphorically frames wealth as a manipulated commodity, not divine grace. "फटा हुआ एहसास" (torn feeling) turns abstract humiliation into a physical tear. Removing them reduces the poem to a plain complaint; keeping them makes the political critique visceral. A wrong answer calling them 'beautiful decorations' reveals a formalist misconception that separates form from content.

## DIAGNOSTIC_QUESTION_6
Compose two original lines for a poem about 'examination stress' that use (a) a metaphor equating stress to a physical weight, and (b) auditory imagery that mimics a heartbeat. Label each device.

## DIAGNOSTIC_ANSWER_6
(a) Metaphor: "परीक्षा का बोझ एक पहाड़ है जो सीने पर रखा गया है" (The burden of exams is a mountain placed on the chest). (b) Auditory imagery: "धक-धक, धक-धक, घड़ी की टिक-टिक दिल की दीवारों से टकराती है" (Thump-thump, thump-thump, the clock's tick-tick strikes the heart's walls). A poor answer that writes "Stress is heavy like a mountain" (simile) or "I hear my heart beating fast" (statement, not imagery) shows failure to apply the devices creatively.

## COMMON_MISCONCEPTION
Students often think imagery *only* means visual description (pictures in the mind) and overlook auditory, tactile, olfactory, and gustatory imagery. They also confuse metaphor with simile, believing any comparison is a metaphor. In this specific poem, a third error is treating the metaphor "लक्ष्मी" as a mere personification of wealth, missing that the metaphor *subverts* the traditional deity image to expose systemic deception.

## ON_FAILURE
1. Give the student a sensory inventory chart: list 5 senses across the top; have them find one phrase from the poem for each sense. 2. Provide three pairs of sentences (one simile, one metaphor) and ask them to underline the comparative word ('like/as') in the simile and note its absence in the metaphor. 3. Ask: "If Lakshmi is a guest who *refuses* to enter, what does that metaphor say about wealth distribution?" Guide them to articulate the subversion.

## BUILDS_ON
Basic identification of figures of speech (simile, personification) and sensory language from Classes 9-10.

## LEADS_TO
Analysis of irony and symbolism (node c11_hin_ar_cbse_13_009) where the metaphor of Lakshmi becomes an ironic symbol.

## PREREQUISITE_NODE_IDS
c11_hin_ar_cbse_13_003, c11_hin_ar_cbse_13_006, c11_hin_ar_cbse_13_007, c11_hin_ar_cbse_13_001, c11_hin_ar_cbse_13_002

## PREREQUISITE_REASONS
c11_hin_ar_cbse_13_003: Setting and Atmosphere establishes the physical world that imagery constructs.
c11_hin_ar_cbse_13_006: Primary Theme provides the central idea that imagery and metaphor serve.
c11_hin_ar_cbse_13_007: Secondary Themes show additional layers that specific metaphors may illuminate.
c11_hin_ar_cbse_13_001: "Before You Read: की समझ आवश्यक है, क्योंकि यह नोड (Imagery is the use of vivid, sensory language that appeals to the five senses (sight, soun...) इसी आधार पर आगे बढ़ता है।  
c11_hin_ar_cbse_13_002: In poetry, narrative structure refers to the organization of a poem's events, images, and... की समझ आवश्यक है, क्योंकि यह नोड (Imagery is the use of vivid, sensory language that appeals to the five senses (sight, soun...) इसी आधार पर आगे बढ़ता है।  

## FORWARD_NODE_IDS
c11_hin_ar_cbse_13_009, c11_hin_ar_cbse_13_013, c11_hin_ar_cbse_13_014, c11_hin_ar_cbse_13_010, c11_hin_ar_cbse_13_015, c12_hin_a_cbse_04_008, c12_hin_a_cbse_05_008, c12_hin_a_cbse_13_008, c12_hin_a_cbse_16_008, c12_hin_ar_cbse_13_008, c11_hin_ar_cbse_13_011

## FORWARD_REASONS
c11_hin_ar_cbse_13_009: Irony and Symbolism build directly on the metaphorical foundation laid here.
c11_hin_ar_cbse_13_013: Critical Thinking requires the ability to dissect devices for interpretive arguments.
c11_hin_ar_cbse_13_014: Writing Skills need textual evidence from imagery/metaphor analysis to support answers.
c11_hin_ar_cbse_13_010: Trains the student to spot metaphorical extensions (e.g., 'nj[r' as moral blindness), which is the core mechanism of this poem's vocabulary.  
c11_hin_ar_cbse_13_015: बिम्ब/रूपक विश्लेषण (फाटक, मेज, चिराग) मौखिक तर्क के साक्ष्य बनते हैं।  
c12_hin_a_cbse_04_008: Mixed metaphor detection — avoids confusion in complex stanzas.  
c12_hin_a_cbse_05_008: Teaches annotation techniques for close reading.  
c12_hin_a_cbse_13_008: Provides the foundational definitions and identification practice; Class 12 deepens to analysis and thematic function.  
c12_hin_a_cbse_16_008: Connects devices to author's style (Usha Priyamvada's minimalism).  
c12_hin_ar_cbse_13_008: Provides foundational definitions of imagery types and metaphor structure (tenor/vehicle/ground) in Hindi literary context.  
c11_hin_ar_cbse_13_011: m standard grammar). It does NOT cover literary device identification (metaphor, irony - covered in c11_hin_ar_cbse_13_008, 009) or vocabulary meanings (covered in c11_hin_ar_cbse_13_010).  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
No prior class nodes available for cross-subject links.

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_13_006 -> c11_hin_ar_cbse_13_008 -> c11_hin_ar_cbse_13_009

## THIS_FORMULA
N/A - conceptual

## FORMULA_VARIABLES
N/A

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
analytical

## CROSS_SUBJECT
c11_economics_poverty_alleviation | The poem's imagery of empty plates and metaphor of wealth as a manipulable commodity directly illustrate economic concepts of poverty traps and unequal resource distribution.
c11_civics_social_justice | The metaphorical subversion of Lakshmi (a cultural symbol of prosperity) critiques systemic injustice, linking to civics themes of equity and rights of marginalized communities.

## PREREQ_CONCEPT
Ability to distinguish literal from figurative language and to name the five senses.

## PREREQ_BEFORE
Student must be able to pick out describing words in a sentence and say which sense they appeal to.

## PREREQ_STUCK
Review Class 9-10 'Figures of Speech' chapter: practice converting 5 similes into metaphors and listing 3 sensory words for a given scene (e.g., railway station).

## WORKED_EXAMPLE_1
PROBLEM: Analyze the visual and tactile imagery in the first stanza of the poem (lines describing the house and surroundings). Explain how they establish the poem's atmosphere.

STEPS:
- Step 1: Read the first stanza aloud twice. Mark every word/phrase that triggers a sensory response (sight, touch, sound, smell, taste).
- Step 2: Classify each marked phrase by sense modality. Example: "फटे हुए घर" → visual (cracks) + tactile (drafts); "सूनी दीवारें" → visual (emptiness) + tactile (cold).
- Step 3: Group the classified images. Notice a cluster of visual-tactile images conveying dilapidation and exposure to elements.
- Step 4: Connect the cluster to atmosphere. The accumulation of broken, cold, empty images creates an atmosphere of neglect and vulnerability.
- Step 5: Verify against the poem's theme. This atmosphere of physical decay sets the stage for the ironic 'welcome' to Lakshmi, making the contrast sharper.

REASONING: The step-by-step sensory marking forces close reading; classification prevents vague 'it creates a picture' claims; grouping reveals patterns; linking to atmosphere and theme shows analytical depth required for board answers.

ANSWER: The first stanza uses dense visual-tactile imagery ("फटे हुए घर", "उघड़े पाँव", "सर्द हवा") to build an atmosphere of stark poverty. The cracked walls and bare feet are not just description—they make the reader *feel* the cold and roughness, preparing the ground for the metaphor of Lakshmi as an intruder in this fragile space.

## WORKED_EXAMPLE_2
PROBLEM: Examine the metaphor "लक्ष्मी एक अनचाही मेहमान है" (Lakshmi is an uninvited guest) in the context of the poem. Explain the source domain, target domain, and the implied critique.

STEPS:
- Step 1: Identify the two terms in the metaphor. Target: Lakshmi (wealth/prosperity). Source: अनचाही मेहमान (uninvited guest).
- Step 2: List attributes of the source domain: arrives without notice, disrupts routine, creates obligation, may bring burden, often unwanted by host.
- Step 3: Map attributes to target domain. Wealth arrives unpredictably (lottery, corruption), disrupts simple lives, creates debt/obligation, burdens the poor with expectations, is 'unwanted' because it comes with strings attached.
- Step 4: Note the subversion. Traditionally Lakshmi is a *desired* guest (welcomed with rangoli, lamps). The metaphor flips the cultural script.
- Step 5: Articulate the critique. The metaphor exposes how 'development' or 'aid' imposed on the poor often feels like an invasion, not a blessing.

REASONING: Explicit domain mapping makes the metaphor's mechanics visible; cultural context reveals the irony; the final step connects device to theme, which is the exam expectation.

ANSWER: The metaphor equates Lakshmi (target) with an uninvited guest (source). Mapping the guest's disruptive, obligatory nature onto wealth reveals the poet's critique: prosperity forced upon the marginalized through exploitative policies is experienced as violation, not grace. The cultural inversion (welcome → unwelcome) sharpens the political edge.

## WORKED_EXAMPLE_3
PROBLEM: Show how the poem uses a sustained metaphor of "भूख" (hunger) as a living entity across stanzas 2 and 3, supported by auditory and olfactory imagery. Explain the combined effect on the reader's empathy.

STEPS:
- Step 1: Locate all references to hunger in stanzas 2-3. Example phrases: "भूख रोती है", "भूख की गंध", "भूख के दाँत".
- Step 2: Identify the sustained metaphor. Hunger is personified as a creature that cries, has a smell, and possesses teeth.
- Step 3: Find accompanying auditory imagery ("रोती है" – sound of weeping) and olfactory imagery ("गंध" – sour/acrid smell of empty stomach).
- Step 4: Analyze the interaction. The metaphor gives hunger agency; the sensory images make its presence visceral. The reader *hears* the cry and *smells* the starvation.
- Step 5: Evaluate the empathetic effect. The combination transforms hunger from an abstract noun into a predatory presence, forcing the reader to confront the physical reality of poverty rather than pity it from a distance.
- Step 6: Link to the poem's larger argument. This visceral embodiment of hunger makes the later irony of 'welcoming Lakshmi' morally unacceptable—how can you invite a goddess when a monster is eating your child?

REASONING: Sustained metaphor analysis requires tracking a device across stanzas; pairing with sensory imagery shows how devices layer; the empathy argument demonstrates higher-order evaluation expected in competency questions.

ANSWER: Across stanzas 2-3, hunger operates as an extended metaphorical predator (crying, smelling, biting). Auditory imagery ("सिसकियाँ") and olfactory imagery ("सड़ी रोटी की गंध") ground the metaphor in bodily reality. The combined effect is to make hunger an inescapable, sensory antagonist, so that the poem's titular 'welcome' reads as a cruel joke—deepening the reader's moral outrage at systemic neglect.

## COMPETENCY_QUESTION_1
QUESTION: "A student claims that the metaphor 'लक्ष्मी के पैर नहीं, पहिये हैं' (Lakshmi has not feet but wheels) is just a fancy way of saying 'money moves fast'. Using your knowledge of metaphor analysis, evaluate this claim and explain what the metaphor actually reveals about the nature of wealth in the poem."

COMPETENCY: Critical evaluation of metaphorical meaning in context.

STEPS:
- Step 1: Break the metaphor into target (Lakshmi/wealth) and source (wheels).
- Step 2: List connotations of 'wheels': mechanical, impersonal, directional, controllable by external force, no agency of its own, rolls over whatever is in its path.
- Step 3: Contrast with 'feet' (human, agency, choice, can stop, can turn back).
- Step 4: Apply to poem's portrayal of wealth. Wealth here is not a benevolent visitor choosing where to go; it is a mechanistic force driven by power structures, crushing the poor in its path.
- Step 5: Conclude why the student's claim is reductive. 'Money moves fast' captures only speed, missing the violence, lack of agency, and structural inevitability encoded in 'wheels'.

ANSWER: The claim is inadequate. The metaphor replaces organic feet with mechanical wheels, signaling that wealth in the poem is not a conscious benefactor but an impersonal, system-driven force that rolls over the vulnerable without moral choice. It conveys violence (crushing), externality (driven by others), and irreversibility—far richer than mere speed.

DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: "The poem uses the olfactory image 'धुएँ की गंध' (smell of smoke) in the kitchen and the visual metaphor 'अँधेरे का जाला' (cobweb of darkness) in the same stanza. Write a structured analytical paragraph (PEEL format) showing how these two devices work together to depict the *texture* of poverty, not just its appearance."

COMPETENCY: Integrated analysis of multiple devices using evidence-based paragraph writing.

STEPS:
- Step 1: Point – State the combined function: the olfactory image and visual metaphor jointly construct a multi-sensory texture of poverty that is tactile, suffocating, and inescapable.
- Step 2: Evidence – Cite the two phrases. Explain 'धुएँ की गंध' as olfactory imagery of chronic indoor pollution from damp fuel; explain 'अँधेरे का जाला' as a visual metaphor where darkness is not absence of light but a sticky, woven trap.
- Step 3: Explanation – Smoke smell penetrates clothes, hair, lungs → poverty seeps into body. Cobweb implies entanglement, stickiness, difficulty of escape → poverty as structural trap.
- Step 4: Link – Together they move the reader from *seeing* a poor house to *inhabiting* its atmosphere, making the subsequent irony of 'welcome' physically felt.
- Step 5: Polish – Ensure topic sentence, embedded quotes, analytical verbs (conveys, embodies, intensifies), and concluding link to theme.

ANSWER: The stanza constructs the texture of poverty through a duet of olfactory imagery and visual metaphor. The "धुएँ की गंध" is not merely a smell; it is the olfactory signature of damp wood and cow-dung cakes burning in an unventilated room, a scent that clings to skin and hair, embodying how poverty permeates the body. Simultaneously, "अँधेरे का जाला" reimagines darkness as a woven, adhesive web—darkness that *traps* rather than simply *hides*. A cobweb is spun silently, catches the unwary, and resists tearing; likewise, the poem suggests, structural poverty is a silent, sticky enclosure. Where the smell makes poverty *inhalable*, the metaphor makes it *tangible*. Their convergence forces the reader to occupy the space, so that the poem's title "लक्ष्मी का स्वागत" lands not as a verbal irony alone but as a sensory violation—how does one welcome a goddess of light into a room that smells of smoke and is woven with darkness?

DIFFICULTY: hard