## DEFINITION
Irony is a literary device where the intended meaning of words or situations is opposite to their literal or expected meaning, creating a contrast between appearance and reality. Symbolism is the use of concrete objects, images, or actions to represent abstract ideas, emotions, or states of being, where the symbol carries meaning beyond its literal function.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student must be able to identify specific instances of irony (verbal, situational, dramatic) and symbolism in the poem, explain how each device operates with textual evidence, and evaluate how they collectively reinforce the central theme of existential weariness and the longing for release.

## SCOPE_BOUNDARY
This node covers the identification, analysis, and interpretation of irony and symbolism specifically within the poem "vkvks] feydj cpk,¡" from NCERT Class 11 Hindi Aroh Chapter 16. It does not cover other literary devices like imagery or metaphor (covered in node 008) nor does it require analysis of poems outside the prescribed textbook.

## WALKTHROUGH
Imagine you are lying awake at 2 AM, exhausted but unable to sleep because your mind replays the day's disappointments — you might whisper to the darkness, "Come, sweet sleep," even though you know sleep only brings temporary escape, not solutions. This paradox — inviting something that resembles death to escape the pain of living — is the heartbeat of this poem. Begin by reading the poem aloud twice: first for the rhythm of the words, second to mark every concrete noun (ink, night, dreams, weariness) and ask, "What abstract burden does this object carry?" Then trace the speaker's tone: is the invitation to sleep genuine relief or a desperate irony? The key insight is that the poem uses sleep not as rest but as a metaphor for the only peace available in an unjust social order.

## DIAGNOSTIC_QUESTION_1
Define verbal irony and situational irony with one example each from everyday life (not from the poem).

## DIAGNOSTIC_ANSWER_1
Verbal irony occurs when a speaker says the opposite of what they mean (e.g., saying "Great job!" when someone drops a tray). Situational irony occurs when the outcome of a situation is the opposite of what was expected (e.g., a fire station burning down). A wrong answer that confuses the two or gives only sarcasm as irony reveals the student cannot distinguish between linguistic irony and structural irony, which is essential for analyzing the poem's layered tone.

## DIAGNOSTIC_QUESTION_2
In the poem, the speaker says "vkvks] feydj cpk,¡" (Come, let's sleep). Explain why this invitation functions as verbal irony given the poem's depiction of sleep as "fe^h dk lksaèkkiu" (the extinction of sleep) and "vD[kM+iu" (restlessness).

## DIAGNOSTIC_ANSWER_2
The invitation is verbally ironic because the speaker calls for sleep using the language of companionship ("cpk,¡" — let's sleep together) while describing sleep as an extinction ("lksaèkkiu") and the night as filled with restlessness ("vD[kM+iu") and weariness ("tq>k:iu"). The literal meaning (let us rest) contradicts the contextual reality (sleep is a fragile, almost violent extinction). A wrong answer that treats the line as a sincere lullaby misses the poem's central tension between the desire for oblivion and the impossibility of true peace.

## DIAGNOSTIC_QUESTION_3
Identify two symbols in the poem (other than sleep) and explain what abstract idea each represents. Provide the specific Hindi word/phrase from the poem for each symbol.

## DIAGNOSTIC_ANSWER_3
1. "ekVh" (ink/blackness) — symbolizes the all-encompassing darkness of night, ignorance, and the oppressive social structure that blots out hope. 2. "Hkksykiu" (dreams) — symbolizes the fragile, illusory aspirations of the marginalized that are crushed by reality ("FkksM+h&lh mEehn" — heavy, oppressive dreams). A wrong answer that lists concrete nouns without linking them to abstract socio-existential meanings (e.g., "ink means black color") shows the student cannot move from literal to symbolic reading.

## DIAGNOSTIC_QUESTION_4
Analyze how the symbol of "nkSj" (time/night) operates differently in the first half of the poem (where it is a setting) versus the final stanza (where the speaker says "bl nkSj esa Hkh cpkus dks cgqr oqQN cpk gS"). What does this shift reveal about the speaker's relationship with time?

## DIAGNOSTIC_ANSWER_4
Initially, "nkSj" is a passive backdrop — the night when the world sleeps and the speaker observes suffering ("cPpksa osQ fy, eSnku", "i'kqvksa osQ fy, gjh&gjh ?kkl"). In the final stanza, "nkSj" becomes an active, almost hostile presence ("vfo'okl&Hkjs nkSj" — terrifying, burning time) yet paradoxically the speaker claims "bl nkSj esa Hkh cpkus dks cgqr oqQN cpk gS" (even in this time, there is much to sleep for). This shift reveals the speaker's movement from victim of time to someone who reclaims agency by choosing sleep as resistance. A wrong answer that treats "nkSj" as merely 'night' in both places misses the dynamic symbolism that mirrors the poem's thematic arc.

## DIAGNOSTIC_QUESTION_5
Evaluate the effectiveness of the poem's central irony: the speaker invites sleep ("fe^h") as a friend ("cpk,¡") while simultaneously describing it as "lksaèkkiu" (extinction) and linking it to "Hkksykiu fny dk vD[kM+iu" (the restlessness of dreams). Does this irony deepen the poem's critique of social injustice or undermine the speaker's sincerity?

## DIAGNOSTIC_ANSWER_5
The irony deepens the critique. By framing sleep — a biological necessity — as a desperate, almost political act of surrender ("cpk,¡" becomes a radical choice), the poem exposes how structural oppression ("vkfnoklh lekt") has turned even rest into a luxury. The speaker's sincerity is not undermined; rather, the irony highlights the absurdity of a world where the only peace available is the "extinction" of consciousness. A wrong answer that calls the irony "confusing" or "contradictory" fails to see irony as a tool for social commentary, not mere wordplay.

## DIAGNOSTIC_QUESTION_6
Write a four-line stanza in Hindi (or English) that uses a concrete symbol (e.g., a locked door, a withered flower, a broken clock) to represent the same existential weariness ("tq>k:iu") and longing for release ("fe^h") as the poem, and embed one line of verbal irony.

## DIAGNOSTIC_ANSWER_6
Example (Hindi):
टूटी घड़ी की सुईयाँ थमी हैं रात भर,
"वक़्त अब आराम करे" — यह झूठी बात कहकर।
सपनों की धूल झाड़ता हूँ चुपके से,
नींद आये तो मौत सी, न आये तो ज़हर।
A poor answer would use abstract words like "sadness" or "pain" directly instead of a concrete symbol, or would lack the ironic gap between what is said and what is meant, showing the student cannot yet craft symbolic language with ironic tension.

## COMMON_MISCONCEPTION
Students often confuse symbolism with metaphor, treating every symbol as a direct "A = B" comparison (e.g., "ink = sadness"). In this poem, "ekVh" (ink) is not just a metaphor for sadness; it is a symbol that accumulates meanings: the darkness of caste oppression, the erasure of identity, the permanence of structural violence, and the medium in which the poet's words are written. Similarly, students read the irony as mere sarcasm ("the poet is mocking sleep") rather than structural irony where the entire social situation makes the invitation to sleep a tragic necessity. This error stems from Class 10-level device-spotting without analyzing how devices interact with theme and context.

## ON_FAILURE
If the student conflates symbol and metaphor: 1) Have them list all concrete nouns in the poem (ink, night, dreams, weariness, time, children, elderly). 2) For each, ask: "What does this object *do* in the poem? What feelings or ideas *surround* it?" 3) Show how "ekVh" appears in the poet's bio ("uxkM+s dh rjg ctrs 'kCn") and in the poem's atmosphere — it is a material that *writes* the poem and *colors* the night. 4) Contrast with a clear metaphor from node 008 (e.g., "thou dh xekZgV" — life's zigzag) to show metaphor is a stated comparison, while symbol is an object that resonates with multiple meanings. If the student reads irony as sarcasm: 1) Define sarcasm as "verbal irony intended to wound." 2) Ask: "Who is the speaker wounding? The night? Sleep? The reader?" 3) Guide them to see the speaker includes themselves ("viuh cfLr;ksa") — the irony is existential, not interpersonal.

## BUILDS_ON
c11_hin_ar_cbse_16_008 (Literary Devices: Imagery and Metaphor) — students must already distinguish metaphor from symbol and identify sensory imagery that carries symbolic weight.

## LEADS_TO
c11_hin_ar_cbse_16_013 (Critical Thinking: Analysis and Interpretation) — where irony and symbolism become evidence for interpretive arguments about the poem's ideological stance.

## PREREQUISITE_NODE_IDS
c11_hin_ar_cbse_16_008, c11_hin_ar_cbse_16_006, c11_hin_ar_cbse_16_002, c11_hin_ar_cbse_16_007, c11_hin_ar_cbse_16_010

## PREREQUISITE_REASONS
c11_hin_ar_cbse_16_008: Provides the foundation in metaphor and imagery analysis; students must know how concrete images work before analyzing how they become symbols.
c11_hin_ar_cbse_16_006: The primary theme (existential weariness under structural oppression) is the thematic anchor that gives irony and symbolism their purpose.
c11_hin_ar_cbse_16_002: Understanding the poem's narrative structure (invocation → catalog of sufferers → final paradox) is necessary to track how irony and symbolism evolve across stanzas.
c11_hin_ar_cbse_16_007: Irony and symbolism deepen the thematic contrasts (rural/urban, tradition/modernity).  
c11_hin_ar_cbse_16_010: Irony and symbolism operate through lexical gaps - e.g., "मेहन" (affection) becoming burdensome - which this node identifies.  

## FORWARD_NODE_IDS
c11_hin_ar_cbse_16_013, c11_hin_ar_cbse_16_014, c11_hin_ar_cbse_16_012, c12_hin_a_cbse_05_009, c12_hin_a_cbse_10_009, c12_hin_a_cbse_16_009, c12_hin_al_cbse_01_009, c12_hin_ar_cbse_09_009, c12_hin_ar_cbse_12_009

## FORWARD_REASONS
c11_hin_ar_cbse_16_013: Critical interpretation requires using irony and symbolism as analytical evidence for thematic claims.
c11_hin_ar_cbse_16_014: Writing tasks (e.g., "Analyze the use of symbolism in the poem") demand structured answers built on this node's analytical framework.
c11_hin_ar_cbse_16_012: Inferential comprehension questions often ask "What does X symbolize?" or "Why is the tone ironic?" — this node provides the toolkit.
c12_hin_a_cbse_05_009: अगला तार्किक चरण: Irony is a literary device where the intended meaning of words or a situation is opposite to their l... इस नोड की अवधारणाओं को सीधे उपयोग/विस्तारित करता है।  
c12_hin_a_cbse_10_009: Chapter 16 was a Board-style practice set — builds exam temperament.  
c12_hin_a_cbse_16_009: Class 11 introduced irony/symbolism definitions and basic identification — this node deepens to structural analysis.  
c12_hin_al_cbse_01_009: Class 11 Antra Chapter 16 Irony and Symbolism node completes the Class 11 cycle.  
c12_hin_ar_cbse_09_009: Full chapter revision at Class 11 level.  
c12_hin_ar_cbse_12_009: अगला तार्किक चरण: Irony in this story is the contrast between appearance and reality — where the wealthy waste water c... इस नोड की अवधारणाओं को सीधे उपयोग/विस्तारित करता है।  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
none

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_16_008 -> c11_hin_ar_cbse_16_009 -> c11_hin_ar_cbse_16_013

## THIS_FORMULA
N/A - conceptual

## FORMULA_VARIABLES
N/A

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
conceptual

## CROSS_SUBJECT
c11_history_social_structure | The poem's depiction of "vkfnoklh lekt" (feudal society) and its impact on the marginalized connects to History themes of caste, feudalism, and resistance in medieval/early modern India.
c11_sociology_social_stratification | The symbols of "cPpksa" (children), "i'kqvksa" (elderly), "cw<+ksa" (women) suffering under "FkksM+k&lk fo'okl" (heavy, oppressive systems) illustrate sociological concepts of structural violence and intersectional vulnerability.

## PREREQ_CONCEPT
Students must understand the difference between a metaphor (explicit comparison) and a symbol (object accruing associative meanings), and recognize that irony operates at the level of situation and structure, not just tone.

## PREREQ_BEFORE
The student should be able to annotate a poem for concrete imagery and identify the central theme of the poem (existential weariness in a feudal social order) before attempting irony/symbolism analysis.

## PREREQ_STUCK
If stuck, review the metaphor analysis in node 008 (especially "thou dh xekZgV") and the theme analysis in node 006 (primary theme: the search for peace in an unjust society).

## WORKED_EXAMPLE_1
PROBLEM: Analyze how the symbol of "ekVh" (ink/blackness) functions across the poet's biographical note and the poem to represent both oppression and creative resistance.

STEPS:
- Step 1: Locate the reference to "ekVh" in the biographical note: "uxkM+s dh rjg ctrs gSa 'kCn" (words scatter like ink) — here ink represents the raw, uncontrollable material of expression.
- Step 2: Locate "ekVh" in the poem's opening imagery: "ekVh dk jax iz;ksx djrs gq, fdl ckr dh vksj laosQr fd;k x;k gS" — the poet uses the color of ink to signal something; what is being "written" in darkness?
- Step 3: Connect to the poem's night setting: "BaMh gksrh fnup;kZ esa / thou dh xekZgV" — the night is ink-colored, and life's zigzag is inscribed in it. Ink becomes the medium of both suffering (the darkness) and testimony (the poem itself).
- Step 4: Analyze the dual valence: Ink stains (oppression, permanence of caste) but also writes (the poet's voice, the act of naming injustice). The symbol thus holds both the wound and the witness.
- Step 5: Conclude: "ekVh" is a polysemous symbol — it represents the inescapable darkness of feudal nights AND the poet's deliberate act of writing in/against that darkness, making the poem itself an artifact of resistance.

REASONING: This works because it moves from textual evidence (bio note + poem lines) to structural analysis (dual valence) to thematic synthesis (resistance). It models the senior-secondary skill of reading paratext (bio) as part of the symbolic field.

ANSWER: The symbol "ekVh" operates as a dual signifier: (1) the imposed darkness of a caste-feudal order that blots out light/hope, and (2) the poet's chosen medium — the black ink in which the poem is written — that transforms suffering into articulate testimony. The irony is that the same ink that marks the "vkfnoklh lekt's" oppression becomes the tool to expose it.

## WORKED_EXAMPLE_2
PROBLEM: Identify the situational irony in the catalog of sleepers in the middle stanzas (children, elderly, women, youth) and explain how it intensifies the speaker's isolation.

STEPS:
- Step 1: List the groups described as sleeping: "cPpksa osQ fy, eSnku" (lullaby for children), "i'kqvksa osQ fy, gjh&gjh ?kkl" (soft beds for elderly), "cw<+ksa osQ fy, igkM+ksa dh 'kkfUr" (shelter of walls for women), "vkSj bl vfo'okl&Hkjs nkSj esa / FkksM+k&lk fo'okl / FkksM+h&lh mEehn / FkksM+s&ls lius" (heavy systems, heavy dreams, heavy fatigue).
- Step 2: Note the expected norm: Sleep is a universal biological relief; the poem initially presents it as available to vulnerable groups (children, elderly, women).
- Step 3: Detect the irony: The very groups who should be protected (children, elderly, women) are described with verbs of burden ("Hkj ,dkUr", "igkM+ksa dh 'kkfUr", "FkksM+h&lh mEehn") — their sleep is not rest but a weighted, enforced shutdown under "FkksM+k&lk fo'okl" (heavy systems).
- Step 4: Contrast with the speaker: The speaker *cannot* access even this compromised sleep ("vkvks] feydj cpk,¡" is a plea, not a description). The situational irony: those with the least power sleep (fitfully), while the conscious witness (the poet) stays awake.
- Step 5: Interpret: This irony structuralizes the poem's central claim — consciousness is a burden of the witness; sleep is a privilege of the numb. The speaker's insomnia is ethical, not biological.

REASONING: The steps guide from textual cataloging to pattern recognition (sleep as burdened, not restful) to structural irony (distribution of sleep vs. wakefulness) to thematic payoff (insomnia as moral witness). This mirrors board-exam "analyze the irony" questions.

ANSWER: The situational irony lies in the inversion of expectation: sleep, typically a restorative escape, is depicted as a heavy, system-imposed shutdown for the vulnerable ("FkksM+h&lh mEehn"), while the speaker — who most craves release — remains awake. This intensifies isolation by making the speaker the sole conscious witness to a world where even rest is politicized.

## WORKED_EXAMPLE_3
PROBLEM: The final stanza claims "bl nkSj esa Hkh cpkus dks cgqr oqQN cpk gS" (even in this time, there is much to sleep for). Using the symbols of "Hkksykiu" (dreams) and "nkSj" (time/night), evaluate whether this statement resolves or deepens the poem's central irony.

STEPS:
- Step 1: Recall the earlier symbolism: "Hkksykiu" = fragile aspirations crushed by reality ("Hkksykiu fny dk vD[kM+iu" — restlessness of dreams). "nkSj" = the terrifying, burning duration of feudal nights ("vfo'okl&Hkjs nkSj").
- Step 2: Analyze the syntax: "cpkus dks cgqr oqQN cpk gS" — infinitive "cpkus" (to sleep) as noun, modified by "oqQN" (much/many). Grammatically, it suggests abundance of reasons to sleep.
- Step 3: Test against context: The reasons to sleep are the very sufferings cataloged earlier (children's hunger, elderly's cold, women's fear, youth's fatigue). Each reason is a wound.
- Step 4: Evaluate irony: The statement *looks* like resolution (many reasons → sleep is justified) but *functions* as deepening irony: the abundance of reasons is the abundance of injustices. Sleep remains "lksaèkkiu" (extinction), not cure.
- Step 5: Synthesize: The poem ends not in peace but in a paradoxical affirmation — the speaker chooses sleep *because* the world is unbearable, making sleep a form of protest ("cpk,¡" as refusal to witness further). The irony is unresolved; it becomes the poem's final stance.

REASONING: This example demands inter-stanza synthesis (symbols from middle stanzas reinterpreted in final stanza), grammatical attention (infinitive as noun), and evaluation of irony's trajectory — exactly the multi-concept, justification-heavy work board exams require.

ANSWER: The statement deepens the irony. "oqQN cpk gS" appears to offer closure, but the "reasons" to sleep are the cataloged atrocities of feudal nights. The symbols "Hkksykiu" (crushed dreams) and "nkSj" (burning time) confirm that sleep remains extinction ("lksaèkkiu"), not healing. The speaker's choice to sleep is a radical, ironic act of withdrawal from a world that offers no justice — the poem ends in resistant irony, not resolution.

## COMPETENCY_QUESTION_1
QUESTION: "The poem uses the symbol of 'night' (nkSj) not merely as a temporal setting but as a structural metaphor for the feudal social order." Defend or challenge this statement using two specific symbolic associations of "nkSj" from the poem and one instance of irony that supports your position.

COMPETENCY: Literary argumentation with textual evidence

STEPS:
- Step 1: Identify two symbolic associations of "nkSj": (a) "vfo'okl&Hkjs nkSj" — terrifying, burning night = the violent, oppressive nature of feudalism; (b) "bl nkSj esa Hkh" — the night that contains "oqQN cpk" (much to sleep for) = the night as the archive of accumulated injustices.
- Step 2: Identify one irony: The situational irony that the vulnerable (children, elderly, women) "sleep" under this night, but their sleep is "FkksM+h&lh mEehn" (heavy dreams) — the night/feudalism grants them only exhausted shutdown, not rest.
- Step 3: Argue: These symbols transform "nkSj" from backdrop to agent — the feudal order *is* the night that burns, weighs, and silences. The irony confirms it: the night doesn't just happen; it *enforces* a distribution of sleep that mirrors social hierarchy.
- Step 4: Conclude: The statement is defended. "nkSj" is a structural metaphor because its symbolic properties (burning, heavy, inescapable) map directly onto the feudal order's properties (violent, oppressive, totalizing).

ANSWER: The statement is defensible. "nkSj" symbolizes the feudal order through (1) "vfo'okl&Hkjs nkSj" — the night as active, burning violence, mirroring feudalism's terror; and (2) "bl nkSj esa Hkh cpkus dks cgqr oqQN cpk gS" — the night as the container of endless suffering that makes sleep the only refuge. The situational irony that the most vulnerable 'sleep' only into "FkksM+h&lh mEehn" (heavy dreams) proves the night/feudalism structures even biological rest. Thus, night is not setting but system.

DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: Compare the function of verbal irony in the opening invocation ("vkvks] feydj cpk,¡") with the function of symbolic irony in the final declaration ("bl nkSj esa Hkh cpkus dks cgqr oqQN cpk gS"). How does the shift from verbal to symbolic irony reflect the poem's movement from personal plea to collective testimony?

COMPETENCY: Comparative analysis of irony types and their structural role

STEPS:
- Step 1: Define the verbal irony in Stanza 1: The speaker addresses sleep as a companion ("cpk,¡" — let's sleep together) while the context reveals sleep as "lksaèkkiu" (extinction) and the night as "xekZgV" (zigzag/agonizing). The irony is linguistic: words say 'come friend' but context says 'come oblivion'.
- Step 2: Define the symbolic irony in the final stanza: "nkSj" (night/time) has become a symbol of feudal oppression; "cpkus" (to sleep) has become a symbol of resistance/withdrawal. The irony is structural: the abundance of reasons to sleep ("oqQN cpk") are the abundance of systemic crimes. The symbol *enacts* the irony.
- Step 3: Trace the shift: Opening = individual voice, direct address, linguistic gap. Closing = collective condition, declarative statement, symbolic enactment. The speaker moves from *performing* irony (saying one thing, meaning another) to *embodying* irony (living in a world where symbols invert their meanings).
- Step 4: Link to collective testimony: The opening "viuh cfLr;ksa" (your eyes) is personal; the final "bl nkSj" (this night) encompasses "cPpksa", "i'kqvksa", "cw<+ksa" — the collective. Symbolic irony operates at the systemic level; verbal irony at the utterance level. The poem's architecture moves from utterance to system.
- Step 5: Conclude: The shift mirrors the poem's thematic arc — from a poet's private despair to a public indictment. Verbal irony opens the wound; symbolic irony names the weapon.

ANSWER: The opening verbal irony ("vkvks] feydj cpk,¡") is a performative gap — the speaker's words invite sleep as solace while the imagery frames it as extinction. The final symbolic irony ("bl nkSj esa Hkh cpkus dks cgqr oqQN cpk gS") is a structural enactment — the symbols "nkSj" (feudal night) and "cpkus" (sleep-as-withdrawal) generate irony by their very collision in a world where the reasons to sleep are the crimes of the system. The shift from verbal to symbolic irony tracks the poem's movement from personal plea (individual voice, linguistic irony) to collective testimony (systemic condition, symbolic irony). The poet begins by speaking ironically; the poem ends by revealing a world that *is* ironic.

DIFFICULTY: hard