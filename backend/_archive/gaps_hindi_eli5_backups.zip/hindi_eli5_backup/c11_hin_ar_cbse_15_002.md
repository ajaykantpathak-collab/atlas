## DEFINITION
Plot and narrative structure in a poem refers to the deliberate organization of images, arguments, and recurring refrains that guides the reader through a logical or emotional progression toward a central revelation, much like a story's sequence of events but built through poetic stanzas instead of scenes.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student can independently map the poem's stanza‑by‑stanza progression, identify the turning point where the definition shifts from negative to positive, and explain how the repetition of "lcls [krjukd" structures the poem's argument about cruelty.

## SCOPE_BOUNDARY
This node covers only the poem "lcls [krjukd" from Chapter 15. It focuses on the internal architecture of the poem — its stanza arrangement, the pattern of negation and affirmation, and the cumulative effect of the refrain. It does not cover character, setting, or thematic analysis (those are separate nodes).

## WALKTHROUGH
Imagine you are asked to explain this poem to a friend who has never read it. You might start by listing the images — a mother's love, a father's lap, childhood laughter — but soon realize the poem isn't just a list; it's a debate. First, ask yourself: "What is the poet doing in the first three stanzas?" Notice he keeps saying what cruelty is NOT. Then ask: "Where does the answer finally appear?" The fourth stanza onward gives positive definitions. The key insight is that the poem's structure mimics a process of elimination — stripping away easy answers to land on the hardest truth: cruelty is the slow death of dignity in everyday struggle.

## DIAGNOSTIC_QUESTION_1
What is the basic structural pattern of the poem "lcls [krjukd" in terms of how the stanzas are organized?

## DIAGNOSTIC_ANSWER_1
The poem opens with three stanzas that repeatedly deny common assumptions about cruelty (mother's love, father's lap, childhood joy are NOT the cruelest), followed by stanzas that positively define cruelty through concrete, harsh realities of adult life. A wrong answer (e.g., "it's just a list of sad things") reveals the student sees only isolated images and misses the argumentative movement from negation to affirmation that drives the poem's meaning.

## DIAGNOSTIC_QUESTION_2
Explain in your own words why the poet uses the refrain "lcls [krjukd ugha gksrh" at the end of the first three stanzas.

## DIAGNOSTIC_ANSWER_2
The refrain acts as a structural anchor that signals the poem is in its "negative definition" phase; each repetition tells the reader "keep looking, the real answer hasn't arrived yet." A wrong answer (e.g., "it's just a poetic decoration") shows the student treats repetition as ornamental rather than as a signpost that organizes the poem's logic.

## DIAGNOSTIC_QUESTION_3
Apply the concept of "turning point" to this poem: identify the exact stanza where the structure shifts from saying what cruelty is NOT to what cruelty IS, and describe what formal change accompanies that shift.

## DIAGNOSTIC_ANSWER_3
The shift occurs at the fourth stanza ("eqnkZ 'kkafr ls Hkj tkuk / u gksuk rM+i dk lc lgu dj tkuk / ?kj ls fudyuk dke ij"), where the refrain changes from "ugha gksrh" to "lcls [krjukd gksrk gS" and the imagery moves from domestic warmth to economic survival. A wrong answer (pointing to a later stanza or missing the refrain change) indicates the student cannot track structural markers that signal a change in rhetorical mode.

## DIAGNOSTIC_QUESTION_4
Analyze how the poem's two‑part structure (negative definitions followed by positive definitions) reinforces its central idea about the nature of cruelty.

## DIAGNOSTIC_ANSWER_4
By first dismissing sentimental clichés, the poet clears space for a definition rooted in systemic deprivation — hunger, job loss, eroded dignity — making the final statement feel earned and unavoidable. A wrong answer that only summarizes the images without linking structure to theme shows the student treats form and content as separate rather than interdependent.

## DIAGNOSTIC_QUESTION_5
Evaluate whether the poem would lose its impact if the first three stanzas were removed and it began directly with the positive definitions. Justify your judgment.

## DIAGNOSTIC_ANSWER_5
Yes, the impact would be severely reduced because the negative stanzas perform the crucial work of dismantling the reader's comfortable assumptions; without that demolition, the positive definitions would read as mere complaints rather than a hard‑won revelation. A wrong answer ("it would be shorter but same meaning") reveals an inability to see structure as an active meaning‑making device.

## DIAGNOSTIC_QUESTION_6
Create a two‑stanza poem that uses the same negative‑then‑positive structural pattern to define a different abstract concept (e.g., "freedom" or "loneliness").

## DIAGNOSTIC_ANSWER_6
A successful response will have a clear refrain, first stanza negating common misconceptions, second stanza offering a grounded, concrete definition. A poor response (just a list of feelings without structural contrast) shows the student has not internalized the pattern as a reusable template for organizing thought.

## COMMON_MISCONCEPTION
Students often believe "plot" and "narrative structure" apply only to stories with characters and events, so they look for a storyline in this poem and conclude it has no structure. In reality, the poem's structure is its argumentative architecture: the deliberate sequencing of negatives, the refrain as a structural hinge, and the climax in the final image of the weary worker's feet. This misconception arises because school curricula rarely teach poetic structure as a form of narrative logic.

## ON_FAILURE
1. Have the student read the poem aloud twice, marking every occurrence of "lcls [krjukd" with a highlighter. 2. Ask them to draw a simple two‑column table: left column = "What cruelty is NOT (stanzas 1‑3)", right column = "What cruelty IS (stanzas 4‑end)". 3. Guide them to notice the refrain changes from "ugha gksrh" to "gksrk gS" exactly at the column break. 4. Finally, have them write one sentence explaining why the poet needed the left column before writing the right column.

## BUILDS_ON
Basic ability to identify stanzas, refrain, and imagery from Class 10 poetry study.

## LEADS_TO
Theme analysis (node c11_hin_ar_cbse_15_006) where the structural insights are used to articulate the poem's central message about systemic cruelty.

## PREREQUISITE_NODE_IDS
c11_hin_ar_cbse_15_001
## PREREQUISITE_REASONS
c11_hin_ar_cbse_15_001: Provides the historical context (1988 riots, poet's background) that explains why the poem's structure moves from domestic to socio‑economic imagery.

## FORWARD_NODE_IDS
c11_hin_ar_cbse_15_003, c11_hin_ar_cbse_15_006, c11_hin_ar_cbse_15_007, c11_hin_ar_cbse_15_004, c11_hin_ar_cbse_15_005, c11_hin_ar_cbse_15_008, c11_hin_ar_cbse_15_010, c11_hin_ar_cbse_15_011, c11_hin_ar_cbse_15_015, c12_hin_a_cbse_09_002, c12_hin_a_cbse_15_002, c12_hin_ar_cbse_15_002

## FORWARD_REASONS
c11_hin_ar_cbse_15_003: Understanding the poem's structural progression helps locate where atmosphere shifts from domestic warmth to public harshness. c11_hin_ar_cbse_15_006: The structural turning point directly supports the primary theme of dignity vs. deprivation. c11_hin_ar_cbse_15_007: Secondary themes (labor, silence, resistance) emerge from the positive‑definition stanzas whose placement is structurally determined.
c11_hin_ar_cbse_15_004: Establishes the poem's narrative structure (the negative-to-positive argument arc) which the speaker *enacts*.  
c11_hin_ar_cbse_15_005: Establishes the poem's two-stanza structure (negation then affirmation) which organizes how supporting figures are deployed.  
c11_hin_ar_cbse_15_008: Narrative structure shows the poem's movement from negation (what it's not) to affirmation (what it is), which structures the metaphor sequence.  
c11_hin_ar_cbse_15_010: Narrative structure (negation-accumulation → revelation) controls the semantic trajectory of "कठिन" across the poem.  
c11_hin_ar_cbse_15_011: Narrative structure (negation → affirmation) mirrors the grammatical movement from *pratishedh* to *vidhi* mood.  
c11_hin_ar_cbse_15_015: Understanding plot/narrative structure helps reference specific parts of the poem.  
c12_hin_a_cbse_09_002: Discussed narrative structure orally.  
c12_hin_a_cbse_15_002: Introduces the terminology of plot structure (linear vs. non-linear, flashback, reflective narration) that students must now apply to a more complex text.  
c12_hin_ar_cbse_15_002: Established baseline skill of tracking argument progression in Hindi non-fiction; this node deepens it to structural analysis.  
c11_hin_ar_cbse_15_006: Understanding the narrative structure (negation then revelation) is key to following the theme's development.  
c11_hin_ar_cbse_15_007: Narrative structure shows the poem's movement from public negation to private affirmation, which structures thematic development.  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS


## CHAIN_DESCRIPTION
c11_hin_ar_cbse_15_001 -> c11_hin_ar_cbse_15_002 -> c11_hin_ar_cbse_15_003

## THIS_FORMULA
N/A - conceptual

## FORMULA_VARIABLES
N/A

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
analytical

## CROSS_SUBJECT
c11_history_indian_national_movement | The poem's backdrop of the 1988 riots and labor unrest links to history topics on post‑independence industrial conflicts.
c11_civics_social_justice | The structural revelation of cruelty as systemic deprivation connects to civics concepts of structural violence and economic rights.

## PREREQ_CONCEPT
Recognizing stanzas and refrains as structural units in poetry.

## PREREQ_BEFORE
Student must be able to divide the poem into stanzas and spot the repeating phrase "lcls [krjukd".

## PREREQ_STUCK
Review "stanza and refrain identification" from Class 10 poetry chapter.

## WORKED_EXAMPLE_1
PROBLEM: A student writes: "The poem is just a list of sad things; there's no plot." Show how to disprove this using structural evidence.
STEPS:
- Step 1: Identify the repeating element — the phrase "lcls [krjukd" appears in every stanza.
- Step 2: Group stanzas by the verb that follows the phrase: first three use "ugha gksrh" (is not), later stanzas use "gksrk gS" (is).
- Step 3: Observe the imagery shift: early stanzas depict family warmth (mother's love, father's lap, childhood play); later stanzas depict economic survival (hunger, job loss, weary feet).
- Step 4: Conclude that the poem has a two‑act structure: Act I dismantles myths, Act II builds a counter‑definition — this IS the narrative arc.
- Step 5: Verify by reading the poem aloud; the tone shifts from gentle denial to grim affirmation exactly at the structural hinge.
REASONING: The refrain acts as a structural signpost; the verb change marks the turning point; the imagery clusters confirm the two‑phase design. This transforms a "list" into a deliberate argument.
ANSWER: The poem possesses a clear narrative structure: a negative phase (stanzas 1‑3) that refuses easy answers, followed by a positive phase (stanzas 4‑end) that defines cruelty through lived reality. The refrain's verb change is the structural hinge.

## WORKED_EXAMPLE_2
PROBLEM: Explain how the poem's structure controls the reader's emotional journey.
STEPS:
- Step 1: Map the emotional tone of each stanza cluster: stanzas 1‑3 evoke tenderness and nostalgia (mother, father, childhood).
- Step 2: Note that the refrain "ugha gksrh" gently pushes the reader away from comfort — "don't settle here."
- Step 3: At stanza 4, the refrain flips to "gksrk gS" and imagery becomes visceral (hunger, job loss, feet that won't lift).
- Step 4: The final stanza widens to collective suffering (crowd's crushed hopes, flickering lamps), creating a cumulative weight.
- Step 5: Argue that the structure forces the reader to enact the poet's own realization: comfort is stripped before truth is shown.
REASONING: Structure is not static; it choreographs the reader's affect. The negative phase lulls, the hinge jars, the positive phase accumulates moral force.
ANSWER: The poem's structure engineers an emotional trajectory from false comfort through disruptive awakening to sustained moral urgency, making the definition of cruelty felt, not just understood.

## WORKED_EXAMPLE_3
PROBLEM: Compare the structural strategy of this poem with a typical short story's plot diagram (exposition, rising action, climax, resolution).
STEPS:
- Step 1: Label the poem's phases: Exposition = stanzas 1‑3 (establish common beliefs); Rising Action = refrain repetition building tension; Climax = stanza 4 (refrain verb flips, imagery hardens); Falling Action = stanzas 5‑7 (elaboration of the true cruelty); Resolution = final stanza (universalizing the condition).
- Step 2: Identify parallels: both use a turning point to invert expectations; both delay the core truth.
- Step 3: Identify differences: story uses events/characters; poem uses images/refrain; story's climax is an event, poem's climax is a linguistic shift.
- Step 4: Evaluate effectiveness: the poem's compression makes the turn sharper — one verb change replaces chapters of plot.
- Step 5: Synthesize: poetic narrative structure achieves similar cognitive work (setup, confrontation, revelation) through linguistic patterning rather than temporal sequence.
- Step 6: Conclude that recognizing this parallel helps students transfer plot‑analysis skills to poetry.
REASONING: Mapping poetic structure onto a familiar plot diagram makes the abstract concept concrete and shows that "narrative structure" is a transferable analytical framework.
ANSWER: The poem mirrors a classic plot arc but condenses it into stanza‑level linguistic moves: the exposition establishes myths, the refrain builds tension, the verb change is the climax, the subsequent stanzas unpack the revelation, and the final image resolves into a universal statement.

## COMPETENCY_QUESTION_1
QUESTION: The poem uses a refrain that changes its verb halfway through. Explain how this single grammatical shift functions as the poem's structural climax. Support your answer with two specific textual details.
COMPETENCY: Literary analysis – identifying structural devices and their functional role.
STEPS:
- Step 1: Locate the exact line where the verb changes from "ugha gksrh" to "gksrk gS".
- Step 2: Explain that this line marks the transition from negative to positive definition.
- Step 3: Cite the imagery before the shift (domestic warmth) and after (economic desperation).
- Step 4: Argue that the verb change is the poem's "event" — the moment the argument turns.
ANSWER: The verb change in the fourth stanza ("lcls [krjukd gksrk gS") is the structural climax because it reverses the poem's entire rhetorical direction. Before it, the refrain denies; after it, the refrain asserts. The accompanying shift from "esgur dh ywV" (mother's love) to "eqnkZ 'kkafr ls Hkj tkuk" (hunger despite a full heart) proves the climax is both grammatical and imagistic.
DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: A critic claims the poem's last three stanzas are "just more examples" and do not advance the structure. Refute or defend this claim using the concept of cumulative progression.
COMPETENCY: Critical evaluation – judging structural coherence and progression.
STEPS:
- Step 1: Define cumulative progression: each new stanza adds a layer that deepens, not merely repeats, the definition.
- Step 2: Analyze stanza 5: moves from individual hunger to family responsibility ("gekjs liuksa dk ej tkuk").
- Step 3: Analyze stanza 6: moves from economic loss to psychological erosion ("vk¡[kksa dks fepks± dh rjg ugha xM+rk").
- Step 4: Analyze stanza 7: expands to collective historical trauma ("f"kank :g osQ vklekuksa ij").
- Step 5: Conclude that the stanzas widen the scope from body → family → psyche → history, proving structural advancement.
ANSWER: The claim is false. The final three stanzas enact a widening spiral: stanza 5 adds familial duty, stanza 6 adds bodily betrayal, stanza 7 adds historical memory. Each step deepens the definition from personal to collective, which is the essence of structural progression.
DIFFICULTY: hard