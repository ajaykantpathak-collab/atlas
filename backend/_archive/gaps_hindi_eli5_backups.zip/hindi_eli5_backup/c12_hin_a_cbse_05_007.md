## DEFINITION
Secondary themes are the subordinate but significant ideas, motifs, or concerns that run parallel to the primary theme in a literary work, enriching the text by adding layers of meaning, revealing character psychology, or reflecting socio-cultural contexts without being the central message.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student can independently identify at least two secondary themes in the prescribed poems, trace their development across specific stanzas using textual evidence, and explain how they interact with the primary theme to deepen the poem's overall significance.

## SCOPE_BOUNDARY
This node covers identification and analysis of secondary themes in the two poems "olar vk;k" and "rksM+ks" from Chapter 5 (j?kqohj lgk;). It does NOT cover primary theme analysis (handled in node 006), detailed literary device analysis (nodes 008, 009), or vocabulary/grammar (nodes 010, 011).

## WALKTHROUGH
Imagine you are listening to a friend describe a vivid dream: the main story is about flying, but you notice recurring images of locked doors and ticking clocks. Those aren't the main plot, but they reveal anxiety about time and missed opportunities. Similarly, in Nagarjun's poems, the primary theme might be nature's renewal or self-purification, but secondary themes like the poet's nostalgia for his creative past ("olar vk;k") or the dignity of manual labor as meditation ("rksM+ks") operate underneath. Begin by re-reading each poem with a highlighter, marking every image, action, or reflection that does NOT directly serve the main theme. Group these markings into clusters — each cluster is a candidate secondary theme. Verify by checking if the cluster appears in at least two distinct stanzas and connects to the poet's known concerns (social realism, individual vs. nature, creative process).

## DIAGNOSTIC_QUESTION_1
What is the definition of a secondary theme in literature, and how does it differ from the primary theme in terms of textual prominence and function?

## DIAGNOSTIC_ANSWER_1
A secondary theme is a recurring idea that supports, contrasts, or complicates the primary theme but receives less direct authorial emphasis and does not unify the entire work. The primary theme is the central controlling idea; secondary themes are subsidiary threads. A wrong answer that equates them or says secondary themes are "less important" reveals a misunderstanding of how thematic layers create depth — secondary themes are not minor; they are structurally necessary for complexity.

## DIAGNOSTIC_QUESTION_2
In "olar vk;k", the poet describes spring's arrival with sensory details (buds, fragrance, birdsong) but also inserts personal memories of writing poetry and reading others' works. Explain how this personal reflection functions as a secondary theme distinct from the primary theme of nature's cyclical renewal.

## DIAGNOSTIC_ANSWER_2
The personal reflection introduces the secondary theme of the creative process and literary legacy. While the primary theme celebrates nature's eternal cycle, the poet's memory of composing poems and reading peers' works highlights the transient human attempt to capture that eternity through art. A wrong answer that treats the memory as mere autobiographical detail misses the meta-poetic layer: the poem becomes about poetry itself, contrasting nature's effortless renewal with the poet's laborious craft.

## DIAGNOSTIC_QUESTION_3
Apply the concept of secondary theme to "rksM+ks": identify a specific action described in the poem (e.g., cutting grass, piling it, clearing the field) and explain how it operates as a metaphor for a psychological or spiritual process, thereby establishing a secondary theme.

## DIAGNOSTIC_ANSWER_3
The act of cutting grass (rksM+ks) and clearing the field serves as a sustained metaphor for mental purification — removing weeds of negativity, doubt, and clutter to prepare the mind for clarity. This establishes the secondary theme of "labor as inner discipline." A wrong answer that only describes the physical activity without the metaphorical leap fails to recognize the poem's allegorical structure, where every physical step (cutting, piling, burning) maps onto a psychological step (identifying, confronting, releasing).

## DIAGNOSTIC_QUESTION_4
Compare the secondary theme of "nostalgia for creative community" in "olar vk;k" with the secondary theme of "self-reliance through manual work" in "rksM+ks". How do both themes reflect the poet's broader philosophical stance on the individual's relationship to society and nature?

## DIAGNOSTIC_ANSWER_4
In "olar vk;k", nostalgia for fellow poets (reading their works, remembering shared creative moments) positions the individual within a literary lineage — society as cultural continuity. In "rksM+ks", the poet refuses help ("ge bldks D;k dj Mkysa") and insists on doing the work himself, asserting self-reliance as a path to authenticity. Together, they reflect Nagarjun's belief that the individual must simultaneously honor collective heritage and cultivate personal integrity through direct engagement with nature. A wrong answer that treats them as unrelated misses the dialectic: community validates, but solitude purifies.

## DIAGNOSTIC_QUESTION_5
Evaluate the effectiveness of using domestic, rural imagery (grass, sickle, field, spring buds) to convey complex secondary themes like creative anxiety and existential purification. Does the simplicity of vocabulary enhance or dilute the philosophical weight?

## DIAGNOSTIC_ANSWER_5
The simplicity enhances the weight: by grounding abstract themes in tangible, universal rural acts, Nagarjun makes the philosophical accessible without reduction. The sickle cutting grass is not a symbol imposed from outside; it is the actual tool of the poet-farmer's life, fusing his dual identity. A wrong answer claiming "simple words mean simple ideas" reveals a bias against vernacular modernism — Nagarjun's genius lies precisely in making the profound speak in the language of the plough.

## DIAGNOSTIC_QUESTION_6
Write a four-line stanza in Hindi (or English) that introduces a secondary theme of "intergenerational transmission of craft" into a poem whose primary theme is "seasonal change", using only concrete, sensory images (no abstract nouns).

## DIAGNOSTIC_ANSWER_6
Example (Hindi):
पुरखों की हँसिया अब भी धार रखती है,
नए फसल की जड़ें पुरानी लीक पकड़ती हैं।
धूप वही, मिट्टी वही, बदले बस हाथ,
बीज बोता हूँ मैं, काटता हूँ साथ।
A poor answer would use abstract words like "parampara" (tradition) or "virsaat" (legacy) instead of showing the sickle, the furrow, the shared sun/soil, and the speaker's hands continuing the cycle.

## COMMON_MISCONCEPTION
Students often confuse "secondary theme" with "minor detail" or "subplot". They list random images (e.g., "birds singing", "sickle shining") as separate secondary themes instead of clustering them into coherent conceptual threads. They also assume a poem can have only one theme total, so they force every line to serve the primary theme, missing the text's polyphony. This error stems from board-exam training that rewards "one main idea" answers, whereas competitive exams (CUET, JEE-type comprehension) test multi-layered interpretation.

## ON_FAILURE
If the student cannot distinguish secondary themes, take them back to the poem "olar vk;k" and do a three-column annotation: Column 1 = lines directly about spring's arrival (primary theme), Column 2 = lines about the poet's memory of writing/reading (secondary theme A), Column 3 = lines about the act of composing this very poem (secondary theme B). Have them write one sentence per column summarizing the thread. Then repeat for "rksM+ks" with columns: physical labor, mental purification, social refusal. This visual separation builds the clustering habit.

## BUILDS_ON
c12_hin_a_cbse_05_006 (Theme: Primary Theme and Message) — students must first anchor the primary theme before identifying what runs parallel to it.

## LEADS_TO
c12_hin_a_cbse_05_013 (Critical Thinking: Analysis and Interpretation) — thematic layers become the raw material for higher-order critical essays and comparative answers.

## PREREQUISITE_NODE_IDS
c12_hin_a_cbse_05_006, c11_hin_ar_cbse_05_007, c11_hin_v_cbse_05_007, c12_hin_a_cbse_05_001, c12_hin_a_cbse_05_004, c12_hin_a_cbse_05_005

## PREREQUISITE_REASONS
c12_hin_a_cbse_05_006: Primary theme must be established first to define what is "secondary".
c11_hin_ar_cbse_05_007: Class 11 Antra Chapter 5 covered secondary themes in a different text, building the conceptual skill.
c11_hin_v_cbse_05_007: Class 11 Vitan Chapter 5 similarly developed theme-layering analysis in non-fiction prose.
c12_hin_a_cbse_05_001: Secondary themes (decay, resilience) emerge from the biographical details.  
c12_hin_a_cbse_05_004: Secondary themes (rural neglect, memory as resistance) emerge from specific details of the protagonist's life.  
c12_hin_a_cbse_05_005: Secondary themes (nature as teacher, the body as instrument) emerge directly from the symbolic roles of the bird, child, peacock, parrot.  

## FORWARD_NODE_IDS
c12_hin_a_cbse_05_008, c12_hin_a_cbse_05_009, c12_hin_a_cbse_05_013, c12_hin_a_cbse_05_014

## FORWARD_REASONS
c12_hin_a_cbse_05_008: Imagery and metaphor are the vehicles through which secondary themes are conveyed; identifying themes guides device analysis.
c12_hin_a_cbse_05_009: Irony and symbolism often operate at the secondary theme level (e.g., the sickle as symbol of both destruction and care).
c12_hin_a_cbse_05_013: Critical thinking questions require synthesizing primary and secondary themes into a coherent interpretation.
c12_hin_a_cbse_05_014: Secondary themes (ritual, liberation, human connection) — for nuanced "Link" sentences.  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
c12_history_ncert_03_007: The theme of "oral tradition and literary lineage" in Nagarjun connects to history's study of Bhakti/Sufi poet-communities and vernacular manuscript cultures.
c12_sociology_ncert_02_004: "Labor as self-fashioning" in "rksM+ks" links to sociology's concepts of dignity of work, caste-division of labor, and Gandhian self-reliance (bread labor).

## CHAIN_DESCRIPTION
c12_hin_a_cbse_05_006 -> c12_hin_a_cbse_05_007 -> c12_hin_a_cbse_05_013

## THIS_FORMULA
N/A - conceptual

## FORMULA_VARIABLES
N/A

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
conceptual

## CROSS_SUBJECT
N/A | Nagarjun's invocation of fellow poets mirrors the historical formation of literary sampradayas (traditions) in medieval Hindi literature, where guru-shishya parampara and poetic gatherings (kavi-sammelan) sustained language.
 N/A | The poem "rksM+ks" enacting self-performed labor reflects the economic concept of "own-account worker" and the non-monetary value of subsistence production, relevant to informal sector studies.
 N/A | Spring imagery in "olar vk;k" (buds, fragrance, bird migration) correlates with phenological indicators of seasonal change studied in climate geography.
## PREREQ_CONCEPT
Ability to distinguish central vs. peripheral ideas in a text and to track recurring motifs across stanzas.

## PREREQ_BEFORE
Student must have completed the primary theme analysis of both poems (node 006) and be familiar with Nagarjun's biography (peasant-poet, Marxist leanings, vernacular modernism).

## PREREQ_STUCK
If stuck, revisit the "Theme: Primary Theme and Message" node (c12_hin_a_cbse_05_006) and re-read the two poems with a single question: "What is the ONE main message?" — then everything else left over is candidate secondary material.

## WORKED_EXAMPLE_1
PROBLEM: Analyze how the secondary theme of "the poet as chronicler of ordinary lives" emerges in "olar vk;k" through specific images of rural women and children.
STEPS:
- Step 1: Identify the primary theme of the poem (nature's renewal in spring) by locating the dominant imagery in stanzas 1-2 (buds, fragrance, birds).
- Step 2: Scan the remaining stanzas for shifts in focus — notice the sudden appearance of "veqd fnu veqd ckj enueghus dh gksosxh iapeh" (women grinding grain daily) and "ngj&ngj ngosaQxs dgha <kd osQ taxy vke ckSj vkosaxs" (children carrying firewood).
- Step 3: Recognize that these images are not about spring per se; they depict the unchanging labor of rural poor, contrasting with nature's cyclical beauty.
- Step 4: Connect this to Nagarjun's known role as a poet of the marginalized — the poem becomes a witness document, making "chronicling the ordinary" a secondary theme.
- Step 5: Verify by checking if this theme recurs in his other works (e.g., "badh ke baad", "akal aur uske baad") — yes, it is a signature concern.
REASONING: This method moves from global (primary theme) to local (specific stanzas) to biographical/literary context, ensuring the secondary theme is textually grounded, not imposed.
ANSWER: The secondary theme of chronicling ordinary rural lives is established through the juxtaposition of spring's splendor with the relentless, invisible labor of women (grinding) and children (gathering wood), positioning the poet as an ethical witness who refuses to romanticize nature at the cost of human reality.

## WORKED_EXAMPLE_2
PROBLEM: Trace the development of the secondary theme "language as a tool of resistance" in "olar vk;k" through the poet's deliberate use of dialect words (e.g., "fiQjdh", "ngj&ngj", "uanu&ou").
STEPS:
- Step 1: List all non-standard, dialect, or folk words in the poem (fiQjdh = grinding stone motion, ngj&ngj = walking heavily, uanu&ou = forest produce).
- Step 2: Note that these words are not decorative; they name specific rural realities that standard Hindi (Khari Boli) would genericize (e.g., "pisna" for grinding, "chalna" for walking).
- Step 3: Link this to the poet's stated philosophy: "vuko';d 'kCnksa osQ iz;ksx ls iz;kliwoZd cprs gSa" (they stay close to necessary words) — the dialect is a political choice to center the speaker's community.
- Step 4: Argue that by making the poem's texture out of the marginalized's vocabulary, the text enacts linguistic resistance against Sanskritized official Hindi.
- Step 5: Conclude that "language as resistance" is a secondary theme because it operates through form (vocabulary) rather than content, and supports the primary theme by authenticating the spring scene as lived experience, not pastoral fantasy.
REASONING: Secondary themes often live in form (diction, syntax, rhythm) not just content. This example trains students to look at word-level choices as thematic carriers.
ANSWER: The poem's dense use of Magahi/Bhojpuri dialect words (fiQjdh, ngj&ngj, uanu&ou) constructs a secondary theme of linguistic resistance: each folk term asserts the validity of the peasant's worldview against the homogenizing pressure of standard Hindi, turning the poem itself into a site of cultural preservation.

## WORKED_EXAMPLE_3
PROBLEM: Compare how both poems use the secondary theme of "time" differently — "olar vk;k" as cyclical/eternal, "rksM+ks" as linear/urgent — and explain what this contrast reveals about the poet's view of human agency.
STEPS:
- Step 1: In "olar vk;k", locate time markers: "veqd fnu veqd ckj" (day after day), "nÝ+rj esa" (in the night), the recurring spring — time is a circle, nature repeats, humans repeat labor.
- Step 2: In "rksM+ks", locate time markers: "ux.; fnu" (the final day), "tkuw¡xk" (will end), the imperative "rksM+ks" (cut now) — time is a deadline, action must happen before the end.
- Step 3: Identify the philosophical contrast: cyclical time = acceptance, continuity, humility; linear time = agency, choice, mortality awareness.
- Step 4: Synthesize: Nagarjun holds both — the peasant lives in nature's cycles (olar) but must act decisively within his finite life (rksM+ks). The secondary theme of time thus bridges the two poems into a unified worldview.
- Step 5: Connect to board exam pattern: this comparative thematic analysis is exactly the "critical thinking" question type (node 013) and appears in CUET comprehension passages.
REASONING: This worked example models the multi-text, multi-concept synthesis required for competency questions. It combines theme tracking, philosophical inference, and exam-pattern awareness.
ANSWER: "olar vk;k" portrays time as cyclical (seasons return, labor repeats), suggesting humans are part of an eternal natural order. "rksM+ks" portrays time as linear and terminal ("ux.; fnu tkuw¡xk"), demanding urgent self-purification before death. Together, they reveal Nagarjun's dialectical view: we are embedded in nature's cycles (no escape) but possess radical agency within our allotted span (must cut the grass now). Human dignity lies in acting purposefully within the cycle.

## COMPETENCY_QUESTION_1
QUESTION: A Class 12 student writes in their board exam answer: "The secondary theme of 'rksM+ks' is cleanliness because the poet cuts grass and cleans the field." Using the poem's textual evidence, explain why this answer would receive partial credit (1/3 marks) and rewrite it to earn full marks by correctly identifying the secondary theme and its metaphorical function.
COMPETENCY: Critical interpretation and exam-answer writing (CBSE marking scheme alignment)
STEPS:
- Step 1: Identify the error — the student confuses literal action (cleaning) with thematic meaning (purification).
- Step 2: Recall the marking scheme: 1 mark for identifying a relevant detail, 1 mark for naming the correct theme, 1 mark for explaining the metaphor with evidence.
- Step 3: Select evidence: "lc [ksr cukdj NksM+ks" (make a field and cut), "ge bldks D;k dj Mkysa bl vius eu dh [kht dks" (what do we do with our heart's hardness), "xksM+ks xksM+ks xksM+ks" (break/tear open).
- Step 4: Construct the full-mark answer using PEEL: Point (secondary theme is inner purification through self-labor), Evidence (quotes above), Explanation (grass = negative tendencies, field = mind, sickle = will), Link (connects to primary theme of self-reliance).
REASONING: This competency question directly targets the board exam skill of converting textual observation into thematic argument with the required structure.
ANSWER: The student's answer is literal, not thematic. Full-mark rewrite: "The secondary theme of 'rksM+ks' is self-purification through voluntary labor. The physical act of cutting grass ('rksM+ks rksM+ks') and clearing the field ('lc [ksr cukdj NksM+ks') operates as an extended metaphor: the overgrown grass represents accumulated negativity, hardness of heart ('eu dh [kht'), and mental clutter; the sickle represents the will to confront them; the refusal of help ('ge bldks D;k dj Mkysa') asserts that inner cleansing cannot be outsourced. Thus, the poem transforms a mundane agricultural chore into a spiritual discipline."
DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: In a CUET-style comparative question, you are given an unseen 4-line poem about a potter shaping clay on a wheel ("The wheel spins / wet clay rises / hands know the rhythm / ancestors' breath in each curve"). Using the analytical framework developed for Nagarjun's poems, identify two plausible secondary themes and justify each with one line from the unseen poem.
COMPETENCY: Transfer of thematic analysis skill to unseen text (CUET/NEET comprehension pattern)
STEPS:
- Step 1: Identify the primary theme (creation/artistry/craft) from the central action (potter shaping clay).
- Step 2: Scan for secondary threads: (a) "ancestors' breath in each curve" → secondary theme: intergenerational transmission of craft/tradition. (b) "hands know the rhythm" → secondary theme: embodied knowledge / muscle memory as intelligence.
- Step 3: Justify each with the specific line: For (a), the line explicitly names ancestors' presence in the product. For (b), "know the rhythm" implies non-cognitive, somatic mastery.
- Step 4: Check against Nagarjun framework: both mirror "olar vk;k" (literary lineage) and "rksM+ks" (body's wisdom in labor).
- Step 5: Present as two clear theme-evidence pairs, using the terminology "secondary theme" and "textual evidence".
REASONING: Competitive exams test whether students can export a learned analytical method to new material. This question simulates that transfer.
ANSWER: Secondary Theme 1: Intergenerational continuity of craft. Evidence: "ancestors' breath in each curve" — the potter's work is not individual invention but a conduit for ancestral skill, mirroring Nagarjun's poetic lineage in "olar vk;k". Secondary Theme 2: Embodied/non-verbal knowledge. Evidence: "hands know the rhythm" — the craft resides in somatic memory, not conscious thought, paralleling the intuitive, self-reliant labor in "rksM+ks" where the body enacts purification.
DIFFICULTY: hard