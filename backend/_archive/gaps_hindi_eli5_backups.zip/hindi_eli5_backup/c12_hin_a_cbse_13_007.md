## DEFINITION
Secondary themes are the underlying ideas, motifs, or messages that run parallel to the primary theme of a literary work, enriching the narrative by adding layers of meaning, revealing character depth, and reflecting the socio-cultural context without being the central focus.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student can identify at least three distinct secondary themes in "Hkh'e lkguh", trace each across specific textual evidence (dialogues, incidents, descriptions), and explain how they interconnect with the primary theme of nationalism and literary mentorship to create a cohesive memoir.

## SCOPE_BOUNDARY
This node covers identification, textual evidence mapping, and analytical writing for secondary themes in Chapter 13 ("Hkh'e lkguh") only. It does NOT cover primary theme analysis (node 006), literary devices (nodes 008-009), or comprehensive character sketches (nodes 004-005) — though it references them.

## WALKTHROUGH
Imagine you're listening to your grandfather recount his youth — he mentions the freedom struggle, but also casually describes the taste of mangoes from his village tree, the strictness of his teacher, and the smell of rain on dry earth. Those sensory details aren't the "main story" but they make the memory real. Similarly, in "Hkh'e lkguh", the author's encounters with शाखा, उसगा, and कालेकर are framed by nationalism (primary theme), but the texture comes from secondary themes: the guru-shishya parampara in literary mentorship, the quiet dignity of unsung freedom fighters, the collision of tradition and modernity in language, and the author's own evolution from awestruck youth to chronicler. To begin, re-read the chapter marking every passage that feels like a "side note" — a description of food, a linguistic observation, a moment of humor, a comment on clothing or customs. Cluster these markings. Each cluster is a candidate secondary theme. Validate by checking: does this cluster appear in at least three distinct scenes? Does it reveal something about the author or the era beyond the nationalist narrative? If yes, you have a secondary theme.

## DIAGNOSTIC_QUESTION_1
What is the definition of a secondary theme in literature, and how does it differ from the primary theme in terms of narrative function?

## DIAGNOSTIC_ANSWER_1
A secondary theme is a recurring idea that supports, contrasts, or deepens the primary theme without being the central message. The primary theme is the core argument or dominant insight (e.g., nationalism in this chapter); secondary themes are subsidiary threads (e.g., literary mentorship, simplicity of great men) that add texture and complexity. A wrong answer that equates secondary themes with "subplots" or "minor characters" reveals confusion between structural narrative elements and thematic layers — themes are ideas, not plotlines.

## DIAGNOSTIC_QUESTION_2
In the chapter, the author describes शाखा ठाकुर eating mangoes with relish, कालेकर जी's simple dhoti-kurta, and उसगा जी's colloquial speech. Which secondary theme do these details collectively illustrate, and why is it significant that the author chooses *these specific sensory details* rather than their political speeches?

## DIAGNOSTIC_ANSWER_2
These details illustrate the secondary theme of "simplicity and authenticity of great personalities" (सरलता और सहजता). The author deliberately avoids grand political rhetoric to humanize icons — showing that their greatness lay in ordinary, grounded living. A student who answers "the theme of food" or "description of clothes" misses the thematic abstraction: they are stuck at literal description (remember level) and cannot infer the author's purpose (understand level). The error reveals inability to move from concrete imagery to abstract thematic labeling.

## DIAGNOSTIC_QUESTION_3
Trace the secondary theme of "literary mentorship and guru-shishya parampara" across three distinct episodes in the chapter. For each episode, quote or paraphrase the textual evidence and explain what it reveals about the author's literary formation.

## DIAGNOSTIC_ANSWER_3
Episode 1: Author's early education at home with Sanskrit and Persian (para 1 of intro) — reveals traditional multilingual foundation. Episode 2: शाखा ठाकुर correcting the author's language and sharing manuscripts (middle sections) — shows direct textual mentorship. Episode 3: Author translating शाखा's works and editing 'यशोधरा' (later sections) — demonstrates the disciple carrying forward the guru's legacy. A weak answer lists only one episode or gives vague references like "he learned from them" without textual anchoring. This exposes inability to synthesize scattered evidence into a coherent thematic thread — a key analytical skill for board exams.

## DIAGNOSTIC_QUESTION_4
Compare how the secondary theme of "colonial modernity vs. indigenous tradition" manifests in the author's description of (a) the railway journey to लखनऊ and (b) the evening gatherings at शाखा ठाकुर's house. What tension does this create in the memoir's tone?

## DIAGNOSTIC_ANSWER_4
(a) Railway journey: steam engine, tickets, timetables, colonial infrastructure — symbolizes imposed modernity. (b) Evening gatherings: oil lamps, Sanskrit recitation, handwritten manuscripts, colloquial Hindi — embodies living tradition. The tension creates a bittersweet tone: the author inhabits both worlds but mourns the erosion of the latter. A student who only describes the scenes without naming the binary (modernity/tradition) or the tonal effect (nostalgia, irony) fails to analyze thematic dialectics — a common board exam requirement in "critical appreciation" questions.

## DIAGNOSTIC_QUESTION_5
Evaluate the claim: "The secondary theme of 'unsung women in the freedom struggle' is more powerfully conveyed through the story of the caged bird (thenkari) told by उसगा जी than through any direct description of women freedom fighters in the chapter." Defend or refute with textual reasoning.

## DIAGNOSTIC_ANSWER_5
Defend: The thenkari story (bird that sings only when covered) is an allegory for silenced women — उसगा जी uses it to critique patriarchal nationalism without didacticism. The chapter has *no* direct description of women fighters; the allegory fills that silence. Refute: The story is told by a male character about a bird — it centers male narration, not women's voices. Both positions are valid *if* grounded in the text's narrative strategy. A wrong answer ignores the allegorical layer and treats the story as mere entertainment, revealing inability to read symbolism as thematic commentary — a critical gap for competitive exams like CUET.

## DIAGNOSTIC_QUESTION_6
Write a 150-word diary entry from the author's perspective on the night he first heard कालेकर जी say: "वे तुम्हारे ही नहीं, हमारे भी उस्ताद हैं।" Incorporate at least two secondary themes and show how they intersect in that moment.

## DIAGNOSTIC_ANSWER_6
A strong entry will weave (1) literary mentorship (कालेकर acknowledging शाखा as guru) and (2) nationalist humility (greatness recognizes greatness without hierarchy). The intersection: literary lineage mirrors national unity. A poor entry writes a generic emotional reaction ("I felt happy/proud") without thematic labeling or intersection — showing the student cannot *apply* thematic concepts creatively. This tests the highest Bloom level: creating new text that demonstrates internalized thematic architecture.

## COMMON_MISCONCEPTION
Students often confuse "secondary themes" with "subplots" or "minor characters". In this chapter, they might list "the train journey" or "the mango episode" as themes. These are *incidents*, not themes. A theme is an abstract idea (e.g., "the simplicity of greatness") that the incident *illustrates*. The error stems from reading for plot rather than pattern. Another misconception: assuming secondary themes are less important. In board exams, questions often ask "Discuss the significance of the secondary themes in highlighting the primary theme" — ignoring them loses 3-4 marks. Competitive exams (CUET) frame this as "Which of the following is NOT a secondary theme?" with distractors that are plot points.

## ON_FAILURE
If a student cannot distinguish incident from theme: Step 1 — Give them three incidents from the chapter (mango eating, train journey, thenkari story). Step 2 — Ask: "What idea does each represent?" Step 3 — Have them write the abstract noun phrase (simplicity, colonial modernity, silenced voices). Step 4 — Re-read the chapter together, highlighting every recurrence of each abstract idea. Step 5 — Assign a mini-essay: "How does the theme of simplicity deepen the portrait of शाखा ठाकुर as a nationalist?" Use node c12_hin_a_cbse_13_004 (Character Analysis: Protagonist) for character reference.

## BUILDS_ON
Primary Theme and Message (node 006) — secondary themes only make sense in relation to the established primary theme of nationalism and literary legacy.

## LEADS_TO
Literary Devices: Imagery and Metaphor (node 008) — secondary themes are often conveyed through imagery; next node teaches how to analyze that craft.

## PREREQUISITE_NODE_IDS
c12_hin_a_cbse_13_006, c11_hin_ar_cbse_13_007, c12_hin_a_cbse_13_002, c12_hin_a_cbse_13_004, c12_hin_a_cbse_13_005
## PREREQUISITE_REASONS
c12_hin_a_cbse_13_006: Primary theme must be known to position secondary themes in relation to it.
c11_hin_ar_cbse_13_007: Class 11 foundation on secondary themes in memoir genre (same chapter in Antra Part 1).
c12_hin_a_cbse_13_002: Plot knowledge needed to locate thematic evidence in narrative sequence.
c12_hin_a_cbse_13_004: Protagonist's character arc is the lens through which secondary themes are experienced.
c12_hin_a_cbse_13_005: Supporting characters (शाखा, उसगा, कालेकर) embody different secondary themes.

## FORWARD_NODE_IDS
c12_hin_a_cbse_13_008, c12_hin_a_cbse_13_013, c12_hin_a_cbse_13_014, c12_hin_a_cbse_13_010

## FORWARD_REASONS
c12_hin_a_cbse_13_008: Imagery and metaphor are the primary vehicles for secondary themes — next node analyzes this craft.
c12_hin_a_cbse_13_013: Critical thinking requires synthesizing primary + secondary themes for interpretation.
c12_hin_a_cbse_13_014: Writing skills tasks (article, speech) often ask to develop a secondary theme as main argument.
c12_hin_a_cbse_13_010: Secondary themes (sacrifice) inform "vH;FkZuk".  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
c12_history_theme_nationalism: The chapter's secondary themes (unsung heroes, colonial modernity) are historical phenomena — History node provides factual context for literary analysis.
c12_sociology_theme_social_change: The tension between tradition/modernity in the memoir mirrors sociological concepts of sanskritization and westernization — Sociology node offers theoretical vocabulary.

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_13_007 -> c12_hin_a_cbse_13_006 -> c12_hin_a_cbse_13_007 -> c12_hin_a_cbse_13_008 -> c12_hin_a_cbse_13_013

## THIS_FORMULA
N/A - conceptual

## FORMULA_VARIABLES
N/A

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
analytical

## CROSS_SUBJECT
N/A | The secondary theme of "unsung freedom fighters" in the memoir directly reflects historical reality of marginalized contributors to independence — History provides archival evidence to validate literary portrayal.
 N/A | The theme "collision of tradition and modernity" in the author's linguistic and lifestyle observations is a classic sociological case study of cultural transition — Sociology supplies concepts like 'cultural lag' and 'reference group' for deeper analysis.
## PREREQ_CONCEPT
The student must understand that a memoir uses personal memory as a lens to refract larger historical truths — secondary themes are the refractive angles.

## PREREQ_BEFORE
Student must have completed Primary Theme analysis (node 006) and be able to state it in one sentence: "The primary theme is the making of a nationalist literary consciousness through mentorship."

## PREREQ_STUCK
If stuck, revisit the definition of 'theme' vs 'topic' in Class 11 node c11_hin_ar_cbse_13_007 and practice converting plot points to thematic statements using the "So what?" ladder technique.

## WORKED_EXAMPLE_1
PROBLEM: Identify and justify the secondary theme of "language as cultural identity" in the chapter using three textual evidences.
STEPS:
- Step 1: Recall the primary theme (nationalist literary consciousness) and ask: what role does language play in it? The author mentions learning Sanskrit, Persian, Hindi; शाखा ठाकुर's purity of Hindi; कालेकर जी's Marathi-Hindi bridge.
- Step 2: Scan the text for explicit language references: para 1 (Sanskrit/Persian at home), middle (शाखा correcting author's Hindi, praising 'खड़ी बोली'), later (author translating, editing 'यशोधरा' in Hindi).
- Step 3: Abstract the pattern: language choices = identity choices. Sanskrit/Persian = traditional scholarship; खड़ी बोली = modern nationalist Hindi; Marathi-Hindi = linguistic unity.
- Step 4: Select three evidences: (a) Author's home education in Sanskrit/Persian — roots. (b) शाखा ठाकुर's insistence on 'शुद्ध हिन्दी' — ideological stance. (c) कालेकर जी writing in Hindi despite being Marathi — political act.
- Step 5: Synthesize: The theme "language as cultural identity" shows that the freedom struggle was fought not just politically but linguistically — each character's language use maps their nationalist positioning.
REASONING: This works because it moves from primary theme dependency (step 1) to textual scanning (step 2) to abstraction (step 3) to evidence selection (step 4) to thematic synthesis (step 5) — mirroring the analytical writing process required in board exams.
ANSWER: The secondary theme "language as cultural identity" is justified by: (1) Author's Sanskrit/Persian upbringing representing composite pre-colonial identity, (2) शाखा ठाकुर's linguistic purism as cultural nationalism, (3) कालेकर जी's adoption of Hindi as linguistic unity in diversity. Together they show language as both battlefield and bridge in nationalist self-fashioning.

## WORKED_EXAMPLE_2
PROBLEM: Explain how the secondary theme of "humor as humanizing device" operates in the portrayal of शाखा ठाकुर, with two examples.
STEPS:
- Step 1: Define the thematic function: humor prevents hagiography — makes the icon relatable.
- Step 2: Locate humorous moments: (a) शाखा ठाकुर eating mangoes messily, juice dripping, author's embarrassment. (b) शाखा ठाकुर's witty reply to author's awe: "अरे, मैं भी तो मनुष्य हूँ।"
- Step 3: Analyze each: (a) Sensory comedy (mango juice) contrasts with his scholarly image — shows embodied simplicity. (b) Verbal wit deflates author's reverence — establishes equality.
- Step 4: Connect to primary theme: Humanized greatness strengthens nationalist narrative — heroes are not demigods but ordinary people doing extraordinary work.
- Step 5: Evaluate effectiveness: The humor is gentle, never mocking — consistent with author's reverence. It serves the theme of 'simplicity' (secondary theme 1) while advancing 'literary mentorship' (secondary theme 2) by showing गुरु as approachable.
REASONING: This example demonstrates how a secondary theme (humor) serves multiple other themes (simplicity, mentorship) and the primary theme — a multi-layered analysis that scores full marks in "critical appreciation" questions.
ANSWER: Humor humanizes शाखा ठाकुर through (1) the mango episode — sensory, messy simplicity contrasting scholarly aura, and (2) his self-deprecating wit — "I am also human" — dissolving hierarchy. This reinforces the primary theme by showing nationalist greatness as accessible, lived practice.

## WORKED_EXAMPLE_3
PROBLEM: Write a board-style 5-mark answer: "Discuss how the secondary theme of 'intergenerational literary legacy' structures the narrative of 'Hkh'e lkguh'."
STEPS:
- Step 1: Deconstruct the question: "Discuss" = analyze + illustrate; "how... structures" = narrative function, not just presence; 5 marks = 3-4 distinct points with evidence.
- Step 2: Identify the theme's narrative arc: Beginning (author as receiver) → Middle (author as participant) → End (author as transmitter).
- Step 3: Map to textual stages: (a) Childhood: learning from father/grandfather (Sanskrit/Persian) — legacy received. (b) Youth: शाखा ठाकुर's mentorship — legacy deepened. (c) Adulthood: editing शाखा's works, translating, teaching — legacy transmitted.
- Step 4: Draft point-evidence-explanation for each stage using PEEL structure.
- Step 5: Write concluding synthesis: The narrative *is* the legacy — the memoir itself is the final act of transmission.
- Step 6: Polish for board language: Use terms like 'गुरु-शिष्य परम्परा', 'साहित्यिक विरासत', 'स्मृति-लेखन'.
REASONING: This models the exact cognitive process for a 5-mark board question: question analysis → thematic mapping → evidence selection → structured writing → meta-synthesis. It combines primary theme (nationalist literary consciousness) with secondary theme (intergenerational legacy) showing their structural interdependence.
ANSWर: The memoir is structured as a three-generation literary lineage: (1) Inherited legacy — author's home education in Sanskrit/Persian (para 1) establishes the foundation. (2) Deepened legacy — शाखा ठाकुर's mentorship in Khari Boli, manuscript sharing, and linguistic rigor (middle sections) transforms the author from learner to disciple. (3) Transmitted legacy — author's editing of 'यशोधरा', translations, and this very memoir (final sections) complete the cycle. The narrative arc mirrors the guru-shishya parampara: the text *enacts* the theme it describes. This structural mirroring elevates the memoir from biography to cultural document.

## COMPETENCY_QUESTION_1
QUESTION: A Class 12 student writes: "The chapter has many themes like mangoes, trains, birds, and old clothes." Using your understanding of secondary themes, explain why this statement is analytically inadequate and rewrite it as a thematic analysis opening paragraph.
COMPETENCY: Critical thinking - distinguishing concrete details from abstract themes; analytical writing.
STEPS:
- Step 1: Identify the error: The student lists motifs/incidents (mangoes, trains, birds, clothes) not themes. These are *vehicles* for themes.
- Step 2: Convert each to a theme: mangoes → simplicity/embodied authenticity; trains → colonial modernity vs tradition; birds (thenkari) → silenced voices/women in nationalism; clothes → cultural identity/simplicity.
- Step 3: Establish hierarchy: These are secondary to the primary theme of nationalist literary consciousness.
- Step 4: Draft opening paragraph: "Beyond its primary theme of nationalist literary formation, 'Hkh'e lkguh' weaves secondary themes of simplicity in greatness, the tension between colonial modernity and indigenous tradition, the silencing of women in nationalist discourse, and language as cultural identity — each illuminated through deceptively ordinary motifs like mangoes, train journeys, a caged bird, and a dhoti-clad scholar."
ANSWER: The original statement confuses literary devices (motifs) with themes. Themes are abstract ideas; motifs are recurring concrete elements that suggest themes. The rewritten paragraph demonstrates thematic abstraction, hierarchy, and textual grounding — exactly what board examiners look for in "theme analysis" answers.
DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: In a CUET-style assertion-reason question: Assertion (A): The secondary theme of 'unsung women in the freedom struggle' is conveyed only through the thenkari allegory. Reason (R): The author deliberately excludes direct female voices to reflect historical erasure. Choose the correct option and justify.
COMPETENCY: Evaluating interpretive claims; understanding authorial strategy and historical context.
STEPS:
- Step 1: Analyze Assertion (A): True — the thenkari story (told by उसगा जी) is the *only* textual representation of women's struggle in the chapter. No woman speaks directly.
- Step 2: Analyze Reason (R): Plausible but not explicitly stated — it's an inferential claim about authorial intent. The text shows erasure (no women at gatherings, no female fighters named) but doesn't confirm *deliberate* exclusion as strategy.
- Step 3: Determine relationship: (A) is factually correct based on text. (R) is a valid critical interpretation but not the *only* explanation (could be author's limited access, genre conventions of memoir). Thus (R) explains (A) partially but not definitively.
- Step 4: Select option: Both (A) and (R) are true, but (R) is not the correct explanation of (A) — because the allegory might serve literary economy, not just historical critique.
- Step 5: Justify: The allegory's power lies in its indirectness — it *enacts* silencing by using a male voice to tell a female-coded story. This complexity exceeds a simple "authorial intent" claim.
ANSWER: Option: Both (A) and (R) are true but (R) is not the correct explanation of (A). Justification: The thenkari allegory is indeed the sole representation (A true). The erasure is real (R partially true), but the allegory's function is primarily literary — it conveys the *experience* of silencing through form, not just reflects it. The author may not have consciously "excluded" women; the memoir form centers *his* memory, which was male-dominated.
DIFFICULTY: hard