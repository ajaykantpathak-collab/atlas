## DEFINITION
Character analysis of the protagonist involves systematically examining the main character's traits, motivations, conflicts, and development through their actions, speech, thoughts, relationships, and authorial descriptions to understand their role in advancing the narrative's central themes.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student must independently write a structured 150-200 word character analysis of आयुर्विज्ञान using textual evidence from at least three distinct episodes, explaining how his traits reveal the story's critique of colonial modernity versus traditional knowledge systems.

## SCOPE_BOUNDARY
This node covers deep analysis of आयुर्विज्ञान (the Ayurvedic physician) as protagonist in "उद्देश का नक्षत्र" - his professional ethics, philosophical stance, relationships with ओंकारनाथ and family, and symbolic significance. It does NOT cover supporting characters (node 005), plot structure (node 002), or thematic analysis (nodes 006-007).

## WALKTHROUGH
Imagine you're a doctor today pressured to prescribe expensive branded medicines when cheaper generics work just as well - that's exactly आयुर्विज्ञान's dilemma in 1914 colonial India. Begin by listing every scene where he appears: his clinic confrontation with the inspector, his conversation with ओंकारनाथ about resignation, his refusal to compromise with the British official, and his final moments with his father. Notice how his speech shifts from professional Sanskritized Hindi with patients to raw emotional Hindi with family. Track what he *chooses* over what he *loses* - that's your analytical entry point.

## DIAGNOSTIC_QUESTION_1
Identify the protagonist's full name and profession as explicitly stated in the opening paragraphs of "उद्देश का नक्षत्र".

## DIAGNOSTIC_ANSWER_1
The protagonist is आयुर्विज्ञान, an Ayurvedic physician (वैद्य) running a government dispensary (उद्देश का नक्षत्र). A wrong answer like "ओंकारनाथ" or "डॉक्टर" reveals confusion between the two male leads or failure to distinguish Ayurvedic from allopathic practice - a critical distinction for the story's central conflict.

## DIAGNOSTIC_QUESTION_2
Explain in your own words why आयुर्विज्ञान refuses the inspector's order to use the new allopathic medicines, connecting his refusal to his professional identity.

## DIAGNOSTIC_ANSWER_2
आयुर्विज्ञान refuses because his professional identity as a वैद्य is inseparable from his ethical commitment to his patients' trust and his ancestral knowledge system; compliance would violate both his conscience and the therapeutic relationship he has built. A wrong answer focusing only on "stubbornness" or "pride" misses the philosophical depth - this isn't ego but epistemological resistance to colonial medical hegemony.

## DIAGNOSTIC_QUESTION_3
Apply the "action-revelation" method: Select ONE specific action by आयुर्विज्ञान in the clinic confrontation scene and analyze what it reveals about his character that his words alone don't show.

## DIAGNOSTIC_ANSWER_3
When आयुर्विज्ञान "अपनी कुर्सी पर बैठा रहा" (remained seated in his chair) while the inspector shouted, this physical stillness reveals deeper resolve than his verbal arguments - it shows embodied resistance, professional dignity, and refusal to be intimidated by colonial authority. A wrong answer quoting only his dialogue misses how Premchand uses body language to characterize quiet strength versus performative outrage.

## DIAGNOSTIC_QUESTION_4
Compare आयुर्विज्ञान's relationship with his father (फिरकथ) versus his relationship with ओंकारनाथ. What does this contrast reveal about his core values?

## DIAGNOSTIC_ANSWER_4
With his father, आयुर्विज्ञान shows reverent obedience and emotional vulnerability ("पिता के चरणों में गिर पड़ा"); with ओंकारनाथ, he shows intellectual equality and moral firmness ("तुम्हारी नौकरी तुम्हारी जान से प्यारी है"). This contrast reveals he values tradition and filial duty emotionally, but professional integrity and intellectual honesty rationally - he negotiates with authority figures differently based on the nature of their claim on him.

## DIAGNOSTIC_QUESTION_5
Evaluate whether आयुर्विज्ञान's resignation is a "victory" or "defeat" within the story's moral framework. Defend your judgment using textual evidence.

## DIAGNOSTIC_ANSWER_5
It is a moral victory but material defeat - he loses livelihood (defeat) but retains self-respect and exposes colonial injustice (victory). The text frames it as victory: "उसने अपनी आत्मा बेचने से इनकार कर दिया" and his father's final blessing "तूने कुल का नाम रखा". A wrong answer calling it pure tragedy misses Premchand's Gandhian ethos where spiritual integrity transcends material loss.

## DIAGNOSTIC_QUESTION_6
Create a 50-word diary entry from आयुर्विज्ञान's perspective on the night before his resignation, capturing his internal conflict using his characteristic vocabulary (Sanskritized Hindi for professional thoughts, colloquial for emotional ones).

## DIAGNOSTIC_ANSWER_6
A strong entry mixes registers: "कल निरीक्षक ने अंग्रेजी दवाओं का आदेश दिया। वैद्यकर्म मेरा धर्म है, नौकरी नहीं। पिता को क्या कहूं? माँ की चिंता... पर आत्मा तो अपनी है। कल त्यागपत्र दूंगा।" Weak entries use uniform language, missing how his code-switching reveals his fractured identity under colonialism.

## COMMON_MISCONCEPTION
Students treat आयुर्विज्ञान as merely "an honest man who loses his job" - a middle-school moral reading. The senior-secondary error is missing how Premchand constructs him as a *site of epistemic resistance*: his Ayurvedic practice represents an entire knowledge system (गुरु-शिष्य परंपरा, अनुभव-आधारित चिकित्सा) being displaced by colonial institutional medicine. Students quote his "honesty" but miss his *epistemological authority* - e.g., when he diagnoses through नाड़ी-परीक्षा versus the inspector's bureaucratic forms.

## ON_FAILURE
1. Have the student re-read ONLY the clinic confrontation scene (pages 6-8) and highlight every word related to knowledge/authority: ज्ञान, अनुभव, परंपरा, आदेश, नियम, सरकार. 2. Ask: "Who has *real* medical knowledge here - the inspector with his rules or आयुर्विज्ञान with his pulse diagnosis?" 3. Map the binary: अनुभव vs नियम, गुरु-परंपरा vs सरकारी आदेश, आत्मा vs नौकरी. 4. Rewrite one paragraph explaining how आयुर्विज्ञान's body (seated, calm, pulse-reading) embodies traditional epistemic authority against colonial bureaucratic power.

## BUILDS_ON
Character analysis builds on plot comprehension (node 002) - you must know *what happens* before analyzing *why the character acts*.

## LEADS_TO
This enables supporting character analysis (node 005) where ओंकारनाथ serves as foil to आयुर्विज्ञान, and thematic analysis (nodes 006-007) where the protagonist's choices embody the tradition-modernity conflict.

## PREREQUISITE_NODE_IDS
c11_hin_ar_cbse_01_001, c11_hin_ar_cbse_01_002, c11_hin_ar_cbse_01_003

## PREREQUISITE_REASONS
c11_hin_ar_cbse_01_001: Context node provides colonial medical history background essential for understanding आयुर्विज्ञान's professional crisis
c11_hin_ar_cbse_01_002: Plot node establishes the sequence of events (clinic confrontation, resignation, father's death) that structure the character's arc
c11_hin_ar_cbse_01_003: Vyksihnhu's character is shaped by the office atmosphere — his corruption is a survival response to the setting.  

## FORWARD_NODE_IDS
c11_hin_ar_cbse_01_005, c11_hin_ar_cbse_01_006, c11_hin_ar_cbse_01_013, c11_hin_ar_cbse_01_007, c11_hin_ar_cbse_01_008, c11_hin_ar_cbse_01_009, c11_hin_ar_cbse_01_010, c11_hin_ar_cbse_01_012, c11_hin_ar_cbse_01_014, c11_hin_ar_cbse_01_015, c12_hin_a_cbse_01_004, c12_hin_a_cbse_02_004, c12_hin_a_cbse_03_004, c12_hin_a_cbse_04_004, c12_hin_a_cbse_06_004, c12_hin_a_cbse_10_004, c12_hin_a_cbse_12_004, c12_hin_a_cbse_13_004, c12_hin_a_cbse_15_004, c12_hin_a_cbse_16_004, c12_hin_a_cbse_17_004, c12_hin_al_cbse_01_004, c12_hin_al_cbse_02_004, c12_hin_ar_cbse_01_004, c12_hin_ar_cbse_01_005, c12_hin_ar_cbse_03_004, c12_hin_ar_cbse_04_004, c12_hin_ar_cbse_05_004, c12_hin_ar_cbse_06_004, c12_hin_ar_cbse_08_004, c12_hin_ar_cbse_10_004, c12_hin_v_cbse_01_004

## FORWARD_REASONS
c11_hin_ar_cbse_01_005: ओंकारनाथ's character only makes sense as foil to आयुर्विज्ञान's established traits
c11_hin_ar_cbse_01_006: Primary theme (colonial modernity vs traditional knowledge) is enacted through protagonist's choices
c11_hin_ar_cbse_01_013: Critical thinking requires protagonist analysis as foundation for interpretive arguments
c11_hin_ar_cbse_01_007: Character analysis of Vyaksihnhu provides the psychological anchor for secondary themes like idealism vs survival and paternal sacrifice.  
c11_hin_ar_cbse_01_008: Protagonist analysis (IafMr) reveals whose consciousness filters the imagery — his sensory world *is* the imagery.  
c11_hin_ar_cbse_01_009: Understanding Vyasingh and Eka Okha as characters is essential to see how their actions generate dramatic/verbal irony.  
c11_hin_ar_cbse_01_010: Character analysis reveals idiolect—Iftar's rustic speech vs. Ojha's bureaucratic Hindi—which determines register-specific meanings.  
c11_hin_ar_cbse_01_012: Character analysis of Vyakti Singh provides the psychological foundation for inferring motivations  
c11_hin_ar_cbse_01_014: Gives protagonist analysis (Vyaksihnhu's traits) needed for character-sketch Points.  
c11_hin_ar_cbse_01_015: Supplies protagonist analysis essential for discussing Vyaksihnhu's motives and actions.  
c12_hin_a_cbse_01_004: Class 11 foundation in character analysis terminology and evidence-based writing.  
c12_hin_a_cbse_02_004: Provides the PEEL answer-writing framework essential for board answers.  
c12_hin_a_cbse_03_004: Introduced character analysis terminology (traits, motivation, arc) which must be *unlearned/adapted* for poetic persona.  
c12_hin_a_cbse_04_004: Prior practice analyzing protagonist in Class 11 poems (e.g., "Kabir's sakhi") builds the skill of reading non-human agency.  
c12_hin_a_cbse_06_004: Transfers the PEEL (Point-Evidence-Explanation-Link) character analysis framework from fictional to historical-poetic texts.  
c12_hin_a_cbse_10_004: Introduces the foundational character analysis framework (traits, evidence, development) this node extends with narrator-perspective complexity.  
c12_hin_a_cbse_12_004: Introduces basic character analysis framework (traits, evidence, sketch writing) used here.  
c12_hin_a_cbse_13_004: Class 11 foundation in character analysis methodology (traits, evidence, arc) — this node deepens it with first-person narrative complexity.  
c12_hin_a_cbse_15_004: Class 11 foundation on protagonist analysis (traits, evidence, development) which this node deepens.  
c12_hin_a_cbse_16_004: Class 11 character analysis skills (identifying traits, using evidence) are directly applied here at a higher level.  
c12_hin_a_cbse_17_004: Provides foundational framework for character analysis (appearance, speech, thought, action) adapted here for essay persona.  
c12_hin_al_cbse_01_004: Class 11 foundation in protagonist analysis (e.g., in "Namak Ka Daroga") transfers the skill of tracking character arc.  
c12_hin_al_cbse_02_004: Prior practice in protagonist analysis (Class 11 Antaral Chapter 1).  
c12_hin_ar_cbse_01_004: Introduced the core distinction between poet and persona using Nirala's lyrics — foundational for not conflating Mathur with his speaker.  
c12_hin_ar_cbse_01_005: Class 11 Protagonist node built the habit of evidence-based trait inference.  
c12_hin_ar_cbse_03_004: Builds on Class 11 foundation of character analysis methodology (traits, evidence, inference).  
c12_hin_ar_cbse_04_004: Teaches the PEEL method for character analysis used in all worked examples here.  
c12_hin_ar_cbse_05_004: Class 11 foundation — identifying protagonist in poetry (e.g., 'कबीर की साखी' where कबीर is protagonist vs. 'राम की शक्तिपूजा' where राम is protagonist).  
c12_hin_ar_cbse_06_004: अगला तार्किक चरण: Character analysis of the protagonist in poetry involves identifying the central personified figure,... इस नोड की अवधारणाओं को सीधे उपयोग/विस्तारित करता है।  
c12_hin_ar_cbse_08_004: Introduces basic character analysis framework (appearance, speech, actions) for poetry.  
c12_hin_ar_cbse_10_004: Introduces character analysis methodology (traits, evidence, development) — foundational skill.  
c12_hin_v_cbse_01_004: Class 11 Aroh protagonist analysis reinforces the PEEL method for literary character writing.  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
none

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_01_001 -> c11_hin_ar_cbse_01_002 -> c11_hin_ar_cbse_01_004 -> c11_hin_ar_cbse_01_005 -> c11_hin_ar_cbse_01_006

## THIS_FORMULA
N/A - conceptual

## FORMULA_VARIABLES
N/A

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
analytical

## CROSS_SUBJECT
c11_history_colonialism | The story critiques colonial medical policy (Western medicine institutionalized, Ayurveda marginalized) - connects to History chapter on "Colonialism and the City" or "Social Change in Colonial India"
c11_civics_rights | आयुर्विज्ञान's resignation asserts professional autonomy and conscience rights against state coercion - connects to Civics "Fundamental Rights" (Article 19: freedom of profession) and "Directive Principles" (promotion of traditional medicine)

## PREREQ_CONCEPT
Students must understand the historical context of colonial medical pluralism in 1910s India - the coexistence and competition between Ayurvedic, Unani, and Allopathic systems under British patronage.

## PREREQ_BEFORE
Students should have completed the "Before You Read" context node (001) covering Premchand's biography, the 1914 publication context, and the colonial medical service structure.

## PREREQ_STUCK
If stuck, review node 001's section on "औपनिवेशिक चिकित्सा नीति" (colonial medical policy) - specifically the 1914 Indian Medical Service regulations that mandated allopathic drugs in government dispensaries.

## WORKED_EXAMPLE_1
PROBLEM: Write a structured character analysis paragraph (100 words) on आयुर्विज्ञान's professional ethics using the PEEL method, focusing on the clinic confrontation scene.

STEPS:
- Step 1: Identify the POINT - आयुर्विज्ञान's professional ethics are rooted in patient trust and ancestral knowledge, not bureaucratic compliance.
- Step 2: Find EVIDENCE - Locate three textual details: (a) his refusal to use "नई दवाएं" despite inspector's order, (b) his statement "मेरा काम रोगियों की सेवा करना है, सरकार के आदेश मानना नहीं", (c) his continued pulse-diagnosis (नाड़ी-परीक्षा) while being reprimanded.
- Step 3: EXPLAIN each evidence - (a) shows prioritization of therapeutic relationship over institutional obedience, (b) articulates his professional philosophy explicitly, (c) demonstrates embodied resistance through continued practice.
- Step 4: LINK to broader significance - This ethics represents pre-colonial medical morality where वैद्य's authority came from गुरु-परंपरा and रोगी-विश्वास, not state license.
- Step 5: Verify word count and PEEL structure completeness.

REASONING: The PEEL structure forces analytical depth - each evidence must be explained, not just listed. The clinic scene is optimal because it concentrates his ethical stance in one dramatic confrontation.

ANSWER: आयुर्विज्ञान की व्यावसायिक नैतिकता रोगी-विश्वास और गुरु-परंपरा में निहित है, नौकरशाही आज्ञापालन में नहीं। जब निरीक्षक नई अंग्रेजी दवाओं का आदेश देता है, वह स्पष्ट कहता है: "मेरा काम रोगियों की सेवा करना है, सरकार के आदेश मानना नहीं" - यह कथन उसकी नैतिक प्राथमिकता घोषित करता है। साथ ही, डाँट खाते हुए भी वह नाड़ी-परीक्षा जारी रखता है, जो उसकी शारीरिक मुद्रा द्वारा प्रतिरोध दर्शाता है। यह वैद्यक की पूर्व-औपनिवेशिक नैतिकता है जहां अधिकार राज्य-लाइसेंस से नहीं, अनुभव और रोगी-श्रद्धा से आता है। (102 words)

## WORKED_EXAMPLE_2
PROBLEM: Analyze how आयुर्विज्ञान's speech register shifts between professional and familial contexts, and what this reveals about his fractured identity under colonialism.

STEPS:
- Step 1: Identify the two speech contexts - professional (clinic, with inspector, with patients) and familial (with father, mother, ओंकारनाथ).
- Step 2: Collect vocabulary evidence - Professional: "नाड़ी-ज्ञान", "त्रिदोष", "पथ्य-अपथ्य", "रोगी-सेवा" (Sanskritized medical terminology). Familial: "बाबूजी", "अम्मा", "नौकरी छूट जाएगी", "घर कैसे चलेगा" (colloquial, emotional).
- Step 3: Analyze the code-switching moment - When ओंकारनाथ visits the clinic, आयुर्विज्ञान uses *both* registers: professional Sanskritized Hindi with patients, then switches to colloquial with ओंकारनाथ ("तुम्हें क्या लगता है, मैं डर जाऊँगा?").
- Step 4: Interpret the fracture - The register split mirrors his structural position: gatekeeper of traditional knowledge (professional register) vs. colonial subject dependent on government salary (familial vulnerability).
- Step 5: Connect to character arc - His final resignation resolves the fracture by rejecting the colonial salary, allowing professional register to fully colonize his identity ("अब मैं मुक्त हूँ").

REASONING: Linguistic analysis of register shift is a senior-secondary skill - it moves beyond "what he says" to "how he says it differently in different power dynamics", revealing internalized colonialism.

ANSWER: आयुर्विज्ञान दो भाषाई संसारों में जीता है: क्लिनिक में संस्कृतनिष्ठ वैद्य-भाषा ("त्रिदोष असंतुलन", "पथ्यपालन") और घर में खड़ीबोली ("नौकरी जाएगी तो खाएंगे क्या?")। यह द्विभाषिकता उसकी खंडित पहचान दर्शाती है - वह एक साथ परंपरा का वाहक (व्यावसायिक) और औपनिवेशिक राज्य का आश्रित (पारिवारिक) है। ओंकारनाथ के सामने वह दोनों रजिस्टर मिलाता है, पर अंत में त्यागपत्र देकर व्यावसायिक रजिस्टर को पूर्णतः अपना लेता है: "अब मैं वैद्य हूँ, नौकर नहीं"।

## WORKED_EXAMPLE_3
PROBLEM: Compare आयुर्विज्ञान and ओंकारनाथ as contrasting responses to colonial modernity. Write a 150-word analytical comparison using the foil technique.

STEPS:
- Step 1: Define the foil relationship - ओंकारनाथ represents accommodationist modernity (accepts colonial job, English education, bureaucratic logic); आयुर्विज्ञान represents resistant tradition (Ayurvedic knowledge, moral autonomy).
- Step 2: Map three contrast points with textual evidence:
  (a) Attitude to authority: ओंकारनाथ - "नौकरी बचानी है तो आदेश मानो"; आयुर्विज्ञान - "आत्मा बेचकर नौकरी नहीं करूँगा"
  (b) Knowledge epistemology: ओंकारनाथ trusts "सरकारी नियम", "डिग्री", "सर्टिफिकेट"; आयुर्विज्ञान trusts "गुरु-मुख", "अनुभव", "नाड़ी"
  (c) Time orientation: ओंकारनाथ calculates future ("पेंशन", "प्रमोशन"); आयुर्विज्ञान honors past ("पिता की सीख", "कुल की मर्यादा")
- Step 3: Analyze the pivotal dialogue (pages 9-10) where ओंकारनाथ calls him "पागल" and आयुर्विज्ञान replies "पागल वह जो आत्मा बेचे" - this inverts the sanity label.
- Step 4: Evaluate narrative judgment - The text validates आयुर्विज्ञान through father's blessing and inspector's ultimate discomfort, not ओंकारनाथ's pragmatism.
- Step 5: Synthesize - The foil structure makes आयुर्विज्ञान's resistance legible as *conscious choice*, not mere backwardness.

REASONING: Foil analysis is a core Class 11 competency - it requires holding two characters in comparative tension and reading the narrative's moral architecture through their opposition.

ANSWER: ओंकारनाथ और आयुर्विज्ञान औपनिवेशिक आधुनिकता के दो प्रतिक्रियावादी स्वरूप हैं। ओंकारनाथ समझौतावादी है: वह सरकारी नौकरी, अंग्रेजी शिक्षा, और नौकरशाही तर्क को स्वीकार करता है ("नियम मानने पड़ते हैं")। आयुर्विज्ञान प्रतिरोधी परंपरा है: उसका ज्ञान गुरु-परंपरा और नाड़ी-अनुभव से आता है, डिग्री से नहीं। तीन विपरीतताएं स्पष्ट हैं: (1) सत्ता के प्रति - ओंकारनाथ आज्ञापालन को व्यावहारिकता कहता है, आयुर्विज्ञान इसे "आत्मा बेचना" कहता है; (2) ज्ञान की सत्ता - ओंकारनाथ "सर्टिफिकेट" मानता है, आयुर्विज्ञान "गुरु-मुख"; (3) समय-दृष्टि - ओंकारनाथ भविष्य (पेंशन) देखता है, आयुर्विज्ञान अतीत (कुल-मर्यादा)। निर्णायक संवाद में ओंकारनाथ उसे "पागल" कहता है; आयुर्विज्ञान उत्तर देता है: "पागल वह जो आत्मा बेचे" - कथा इस व्युत्क्रम को मान्य करती है जब पिता आशीर्वाद देते हैं: "तूने कुल का नाम रखा"। ओंकारनाथ की व्यावहारिकता अंततः खोखली सिद्ध होती है; आयुर्विज्ञान की "अव्यावहारिकता" नैतिक विजय बनती है। (158 words)

## COMPETENCY_QUESTION_1
QUESTION: The CBSE 2023 sample paper asks: "How does Premchand use the character of आयुर्विज्ञान to critique the colonial transformation of Indian medical practice? Support your answer with three specific textual references." Write a board-exam style answer (120-150 words).

COMPETENCY: Textual analysis with historical contextualization - integrating character study with colonial history

STEPS:
- Step 1: Frame thesis - आयुर्विज्ञान embodies the displacement of indigenous medical epistemology by colonial institutional medicine.
- Step 2: Reference 1 - Clinic scene: Inspector's "नई दवाओं का बक्सा" vs आयुर्विज्ञान's "नाड़ी-परीक्षा" - contrasts bureaucratic standardization with personalized diagnosis.
- Step 3: Reference 2 - Resignation dialogue: "सरकार वैद्यों को डॉक्टर बनाना चाहती है" - exposes colonial policy of absorbing/subsuming Ayurveda into allopathic framework.
- Step 4: Reference 3 - Father's deathbed blessing: "तूने वैद्यक का धर्म निभाया" - frames professional integrity as dharmic duty, not mere job performance.
- Step 5: Conclude - Character becomes synecdoche for colonized knowledge systems.

ANSWER: प्रेमचंद आयुर्विज्ञान के माध्यम से औपनिवेशिक चिकित्सा-नीति की आलोचना करते हैं जो देशी ज्ञान-प्रणालियों को संस्थागत एलोपैथी से विस्थापित करती है। पहला, क्लिनिक दृश्य में निरीक्षक का "नई दवाओं का बक्सा" नौकरशाही मानकीकरण दर्शाता है, जबकि आयुर्विज्ञान की "नाड़ी-परीक्षा" व्यक्तिगत, अनुभव-आधारित निदान - दोनों ज्ञान की विरोधी पद्धतियाँ हैं। दूसरा, त्यागपत्र संवाद में आयुर्विज्ञान कहता है: "सरकार वैद्यों को डॉक्टर बनाना चाहती है" - यह नीति उजागर करता है जहां आयुर्वेद को एलोपैथी में विलीन किया जा रहा था। तीसरा, पिता का मृत्युशय्या आशीर्वाद "तूने वैद्यक का धर्म निभाया" व्यावसायिक निष्ठा को धार्मिक कर्तव्य बनाता है, मात्र रोजगार नहीं। इस प्रकार आयुर्विज्ञान उपनिवेशित ज्ञान-प्रणालियों का पर्यायवाची बनता है - उसकी व्यक्तिगत हार सामूहिक सांस्कृतिक प्रतिरोध की विजय है। (132 words)

DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: A competitive exam (CUET) style question: "In 'उद्देश का नक्षत्र', the protagonist's body language often contradicts his spoken words. Analyze TWO instances where this contradiction reveals his psychological state more accurately than his dialogue. Explain how Premchand uses this technique to characterize resistance."

COMPETENCY: Literary device analysis (body language vs dialogue) and psychological characterization

STEPS:
- Step 1: Identify Instance 1 - Clinic confrontation: आयुर्विज्ञान speaks politely ("हुजूर, यह नियम के विरुद्ध है") but body "कुर्सी पर जमा रहा", "नाड़ी देखता रहा" - reveals suppressed rage and professional confidence masked as deference.
- Step 2: Identify Instance 2 - Home scene after resignation: He tells mother "चिंता मत करो, कुछ न कुछ हो जाएगा" (reassuring words) but "हाथ काँप रहे थे", "आँखें लाल थीं" - reveals terror beneath stoicism.
- Step 3: Analyze the technique - Premchand uses "कथन-क्रिया अंतराल" (speech-action gap) to show colonial subject's double consciousness: public performance of submission vs private resistance.
- Step 4: Explain characterization function - The gaps make resistance *embodied* and *psychologically real*, not just ideological. The body cannot lie like language can.
- Step 5: Connect to resistance theme - Bodily resistance (seated posture, trembling hands) precedes and exceeds verbal resistance, suggesting resistance is ontological, not just political.

ANSWER: दो प्रमुख उदाहरण: (1) क्लिनिक में आयुर्विज्ञान शब्दों में विनम्र है ("हुजूर, नियम विरुद्ध") पर शरीर "कुर्सी पर जमा रहता है", नाड़ी देखता रहता है - यह दबी हुई क्रोध और व्यावसायिक आत्मविश्वास दर्शाता है जो विनम्रता के मुखौटे में छिपा है। (2) त्यागपत्र के बाद माँ को दिलासा देता है "कुछ हो जाएगा" पर "हाथ काँपते हैं", "आँखें लाल" - भय और अनिश्चितता जो शब्द छिपाते हैं। प्रेमचंद इस "कथन-क्रिया अंतराल" द्वारा औपनिवेशिक विषय की द्वि-चेतना दिखाते हैं: सार्वजनिक समर्पण का प्रदर्शन बनाम निजी प्रतिरोध। शरीर भाषा से अधिक सच्चा है - प्रतिरोध पहले शारीरिक है (बैठे रहना, काँपना), फिर वाचिक। इससे प्रतिरोध राजनीतिक न रहकर अस्तित्वगत बनता है। (128 words)

DIFFICULTY: hard