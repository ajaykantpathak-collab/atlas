## DEFINITION
Irony is a literary device where there is a contrast between expectation and reality—what appears to be true differs from what is actually true. Symbolism is the use of an object, person, situation, or action to represent a deeper, abstract meaning beyond its literal sense.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student can independently identify at least two instances of irony (verbal, situational, or dramatic) and two symbols in the chapter, explain their function in advancing the theme, and write a structured analytical paragraph using the PEEL method (Point, Evidence, Explanation, Link).

## SCOPE_BOUNDARY
This node covers the identification, classification, and thematic analysis of irony and symbolism specifically within the short story "viw osQ lkFk <kbZ lky" (Chapter 3, Aroh). It does not cover other literary devices like metaphor, imagery, or alliteration (addressed in node c11_hin_ar_cbse_03_008), nor does it require analysis of irony/symbolism in other texts.

## WALKTHROUGH
Imagine you are writing a crucial exam and your pen stops working—right when you need it most. That frustrating gap between what you expect (smooth writing) and what happens (ink fails) is situational irony. In "viw osQ lkFk <kbZ lky," the writer struggles to begin his story because his pen won't write, yet the pen itself becomes a symbol of his creative voice. To analyze this, first re-read the sections where the pen fails (the opening) and where the doll (oqQÙkk) appears (the middle). Ask: "What does the writer expect? What actually happens?" for irony. For symbolism, ask: "What concrete object keeps recurring? What abstract idea (creativity, childhood, authenticity) does it carry?" The key insight: irony creates tension; symbolism builds thematic depth—they often work together.

## DIAGNOSTIC_QUESTION_1
Define situational irony and give a one-sentence example from daily life (not from the textbook).

## DIAGNOSTIC_ANSWER_1
Situational irony occurs when the outcome of a situation is the opposite of what was expected or intended. Example: A fire station burns down. A wrong answer (e.g., "irony is when something funny happens") reveals the student confuses irony with humor or coincidence, missing the core "expectation vs. reality" structure.

## DIAGNOSTIC_QUESTION_2
In the story, the writer says, "viw osQ lkFk <kbZ lky" (the small line with the pen). Explain in your own words why this statement is ironic, considering the writer's profession.

## DIAGNOSTIC_ANSWER_2
The writer is a professional author (fI+kQYedkj) whose livelihood depends on writing, yet he cannot produce even a single line because his pen fails. The irony lies in the gap between his identity (a writer) and his immediate reality (unable to write). A wrong answer focusing only on the pen's mechanical fault shows the student misses the professional-personal contrast that creates the irony.

## DIAGNOSTIC_QUESTION_3
Identify one object in the story (other than the pen) that functions as a symbol. State what it literally is and what abstract idea it represents.

## DIAGNOSTIC_ANSWER_3
The doll (oqQÙkk) given to the child (Hkwyks) is literally a toy, but it symbolizes the writer's own creative work—fragile, crafted, and vulnerable to external judgment. A wrong answer naming the pen again shows the student cannot transfer the symbol-identification skill to a new object; an answer giving only the literal meaning misses the abstract layer.

## DIAGNOSTIC_QUESTION_4
Compare the irony in the pen-failure episode (opening) with the irony in the doll episode (middle). How does the *type* of irony shift, and what does this shift reveal about the writer's evolving conflict?

## DIAGNOSTIC_ANSWER_4
The opening uses situational irony (tool fails the professional). The doll episode introduces dramatic irony: the writer and reader know the doll is a cheap replacement, but the child (Hkwyks) treats it as precious. The shift moves the conflict from external (mechanical failure) to internal (artistic insecurity—fear his work is a "fake"). A wrong answer listing both as "situational" shows inability to distinguish irony types; missing the "internal conflict" link shows lack of thematic synthesis.

## DIAGNOSTIC_QUESTION_5
Critique this student statement: "The pen is a symbol of writing, so the whole story is just about writing." Is this a sufficient symbolic reading? Justify.

## DIAGNOSTIC_ANSWER_5
No, it is reductive. The pen symbolizes not just "writing" but the *struggle for authentic expression*—its failure mirrors the writer's block; its eventual working mirrors breakthrough. The doll, the storm (ckfj'k), and the historical portraits (tosYV, pfpZy, etc.) expand the symbolism to legacy, fear, and political context. A "sufficient" judgment reveals the student treats symbols as simple one-to-one codes rather than multi-layered thematic nodes.

## DIAGNOSTIC_QUESTION_6
Write a 4-line micro-story that uses *both* situational irony and a symbol (choose any object) to convey the theme "unexpected help."

## DIAGNOSTIC_ANSWER_6
Example: "The lighthouse keeper forgot to light the lamp. A ship crashed. The wreckage washed up—dry firewood for his cold hearth. The lamp (symbol of guidance) failed; the disaster (symbol of chaos) saved him." A poor answer uses only irony or only symbolism, or makes the symbol explicit ("the lamp symbolized hope") instead of letting the object carry the meaning implicitly.

## COMMON_MISCONCEPTION
Students often treat *any* unexpected event as irony, ignoring the necessity of a clear expectation-reality clash. They also confuse symbolism with metaphor: they think a symbol must be explicitly compared ("the pen *is like* a sword") rather than understanding that a symbol *is* the object itself carrying layered meaning through repetition and context. For example, they label the storm (ckfj'k) as "just bad weather" (missing its symbolic function as creative turmoil) or call the writer's pen failure "ironic" without stating what he expected (smooth writing) versus what happened (ink refusal).

## ON_FAILURE
1. **Isolate the expectation**: Have the student complete the sentence "The writer expected ______, but ______ happened" for three story events. 2. **Symbol hunt**: Give a list of 5 recurring objects (pen, doll, storm, portraits, lighthouse). For each, ask: "If this object were a message, what would it say?" 3. **Type-sorting**: Provide 4 short scenarios (2 ironic, 2 coincidental). Student sorts them and justifies using "expectation vs. reality." 4. **Re-read target paragraphs**: Focus on the doll-exchange scene (pages 36-38) and the storm-night scene (pages 38-39) with the two lenses separately, then together.

## BUILDS_ON
c11_hin_ar_cbse_03_008 (Literary Devices: Imagery and Metaphor) — because metaphorical thinking is prerequisite to grasping symbolic layers.

## LEADS_TO
c11_hin_ar_cbse_03_013 (Critical Thinking: Analysis and Interpretation) — where irony and symbolism become tools for deeper thematic argument.

## PREREQUISITE_NODE_IDS
c11_hin_ar_cbse_03_008, c11_hin_ar_cbse_03_002, c11_hin_ar_cbse_03_006

## PREREQUISITE_REASONS
c11_hin_ar_cbse_03_008: Imagery and Metaphor train the mind to see concrete objects carrying abstract weight—direct preparation for symbolism.
c11_hin_ar_cbse_03_002: Plot and Narrative Structure provides the event-sequence knowledge needed to spot where expectation-reality gaps (irony) occur in the story timeline.
c11_hin_ar_cbse_03_006: Irony and symbolism deepen the theme; their function is thematic.  

## FORWARD_NODE_IDS
c11_hin_ar_cbse_03_010, c11_hin_ar_cbse_03_012, c11_hin_ar_cbse_03_013, c11_hin_ar_cbse_03_015, c12_hin_a_cbse_05_009, c12_hin_a_cbse_10_009, c12_hin_al_cbse_01_009, c12_hin_ar_cbse_01_009, c12_hin_ar_cbse_03_009, c12_hin_ar_cbse_05_009, c12_hin_ar_cbse_09_009, c12_hin_ar_cbse_12_009

## FORWARD_REASONS
c11_hin_ar_cbse_03_010: Vocabulary in Context requires recognizing how words like "oaQfVU;qbVh" (despair) or "okLrqliZ" (landmark) carry symbolic resonance.
c11_hin_ar_cbse_03_012: Comprehension questions often ask "Why is the doll episode ironic?" or "What does the storm symbolize?"—direct application.
c11_hin_ar_cbse_03_013: Critical Thinking essays demand thematic arguments built on device-analysis (e.g., "Irony exposes the writer's vulnerability").
c11_hin_ar_cbse_03_015: Irony/symbolism (two dogs, rain) are high-yield discussion triggers.  
c12_hin_a_cbse_05_009: अगला तार्किक चरण: Irony is a literary device where the intended meaning of words or a situation is opposite to their l... इस नोड की अवधारणाओं को सीधे उपयोग/विस्तारित करता है।  
c12_hin_a_cbse_10_009: Chapter 3 used symbolism in a historical narrative — builds context for biographical symbolism here.  
c12_hin_al_cbse_01_009: Class 11 Antra Chapter 3 Irony and Symbolism node gives more practice with varied contexts.  
c12_hin_ar_cbse_01_009: Practice with contextual symbols in prose prepares for Muktibodh's dense symbolic layering.  
c12_hin_ar_cbse_03_009: Class 11 Irony and Symbolism introduces the core definitions and simple examples; Class 12 deepens to multi-layered, meta-textual usage.  
c12_hin_ar_cbse_05_009: अगला तार्किक चरण: Irony (व्यंग्य/विडंबना) is a literary device where the intended meaning of words or situations is op... इस नोड की अवधारणाओं को सीधे उपयोग/विस्तारित करता है।  
c12_hin_ar_cbse_09_009: Expands symbolism from conventional to contextual symbols.  
c12_hin_ar_cbse_12_009: अगला तार्किक चरण: Irony in this story is the contrast between appearance and reality — where the wealthy waste water c... इस नोड की अवधारणाओं को सीधे उपयोग/विस्तारित करता है।  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
none

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_03_008 -> c11_hin_ar_cbse_03_009 -> c11_hin_ar_cbse_03_013

## THIS_FORMULA
N/A - conceptual

## FORMULA_VARIABLES
N/A

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
analytical

## CROSS_SUBJECT
c11_history_nationalism | Irony in colonial narratives: British "civilizing mission" vs. exploitation reality mirrors writer's "creative mission" vs. block.
c11_psychology_dreams | Symbolism in dream analysis (Freud/Jung): objects (pen, doll) as displaced representations of unconscious conflicts, like the writer's creative anxiety.

## PREREQ_CONCEPT
Ability to distinguish literal vs. figurative meaning and to trace a recurring object across a narrative arc.

## PREREQ_BEFORE
Student must know the story's plot sequence (especially the pen failure, doll gift, storm night, and final breakthrough) and understand basic metaphor structure (tenor/vehicle).

## PREREQ_STUCK
Revisit the plot-summary node (c11_hin_ar_cbse_03_002) for event order, and the imagery/metaphor node (c11_hin_ar_cbse_03_008) for tenor-vehicle practice.

## WORKED_EXAMPLE_1
PROBLEM: Analyze the situational irony in the opening scene where the writer (iFksj ikapkyh) cannot start his story because his pen won't write. Use the PEEL structure.
STEPS:
- Step 1: Identify the expectation: A professional writer expects his primary tool (pen) to function reliably when he sits to work.
- Step 2: Identify the reality: The pen refuses to write ("viw osQ lkFk <kbZ lky" — the small line with the pen doesn't form), despite multiple attempts.
- Step 3: Name the irony type: Situational irony — outcome opposes reasonable expectation.
- Step 4: Explain thematic function: It externalizes the internal "writer's block," making the abstract struggle concrete and immediate for the reader.
- Step 5: Link to broader theme: This opening irony sets up the story's central concern — the fragile, almost magical dependence of creativity on mundane tools and circumstances.
REASONING: The PEEL steps force the student to move from surface event to thematic significance, which is the board-exam expectation for "analyze" questions.
ANSWER: The opening scene deploys situational irony: a seasoned writer (iFksj ikapkyh) finds his pen failing precisely when he needs it most. The expectation — professional competence — clashes with the reality — mechanical failure. This irony is not merely comic; it materializes the invisible anxiety of the creative act, framing the entire narrative as a negotiation between the writer's will and the capriciousness of his medium.

## WORKED_EXAMPLE_2
PROBLEM: The doll (oqQÙkk) given to Hkwyks functions as a symbol. Trace its symbolic evolution across three scenes: (a) purchase, (b) child's acceptance, (c) writer's reflection.
STEPS:
- Step 1: Scene (a) — Purchase: Writer buys a cheap, replacement doll because the original is lost. Literal: a toy. Symbolic: a "counterfeit" creation — the writer fears his own work is similarly inauthentic.
- Step 2: Scene (b) — Child's acceptance: Hkwyks embraces the substitute doll with genuine love. Literal: child's innocence. Symbolic: the reader/audience accepts the work *despite* the creator's doubts; authenticity resides in reception, not origin.
- Step 3: Scene (c) — Writer's reflection: The writer watches the child sleep with the doll. Literal: bedtime ritual. Symbolic: the creator makes peace with imperfection; the "small line" (lkbZ lky) has become a living bond.
- Step 4: Synthesize: The doll moves from symbol of *anxiety* (fake) to symbol of *connection* (love) to symbol of *resolution* (accepted creation).
- Step 5: Connect to theme: This arc mirrors the writer's journey from block to breakthrough — the very "small line" he struggled to draw.
REASONING: Symbols in senior-secondary texts are dynamic, not static. Tracking an object across scenes demonstrates the "analyze" skill of seeing development.
ANSWER: The doll begins as a symbol of the writer's impostor syndrome (cheap substitute), transforms into a symbol of unconditional readerly love (child's embrace), and finally settles as a symbol of artistic reconciliation (writer's quiet acceptance). Its evolving meaning structures the story's emotional arc.

## WORKED_EXAMPLE_3
PROBLEM: The storm night (ckfj'k) episode (pages 38-39) combines irony and symbolism. Explain how they interact to deepen the theme of "creative vulnerability."
STEPS:
- Step 1: Identify the symbolic layer: The storm (ckfj'k) symbolizes chaotic, uncontrollable forces — both natural and psychological — that threaten the fragile creative space (the house, the manuscript).
- Step 2: Identify the ironic layer: The writer has just succeeded in fixing the pen (tool works), but now nature (storm) threatens to destroy the written pages — a new expectation-reality gap: "tool fixed → work safe" vs. "storm → work endangered."
- Step 3: Show interaction: The storm *tests* the symbol (the written pages). The irony *heightens* the stakes: the very moment the writer gains agency (working pen), external chaos strips it away.
- Step 4: Analyze the resolution: The writer protects the pages physically (hugging them) — an act that symbolizes the artist's ultimate responsibility: safeguarding the work against chaos.
- Step 5: Thematic link: Creative vulnerability is not just internal (block) but existential (chaos). Irony exposes it; symbolism (storm, pages) embodies it.
- Step 6: Board-exam phrasing: "The storm functions as a pathetic fallacy symbolizing creative turmoil, while the situational irony of the pen working *just before* the storm strikes amplifies the precariousness of artistic production."
REASONING: Senior-secondary analysis requires showing how devices *collaborate*, not just listing them. This 6-step model mirrors the "explain with evidence" demand of 5-mark questions.
ANSWER: The storm night fuses symbol and irony: the storm symbolizes the uncontrollable forces that besiege creativity, while the bitter irony of the pen functioning perfectly *only* to face destruction by wind and rain underscores that the writer's agency is always provisional. The writer's physical embrace of the manuscript becomes the defining image — creativity survives not because tools work, but because the creator shields it.

## COMPETENCY_QUESTION_1
QUESTION: Read this unseen micro-passage: "The pianist practiced the concerto for a year. On concert night, the hall's heater failed; his fingers stiffened. He played flawlessly anyway. The reviewer wrote: 'A cold hall warmed by hot hands.'" Identify the irony and the symbol. Explain how they work together to characterize the artist.
COMPETENCY: Literary analysis of unseen text (transfer of irony/symbolism skills)
STEPS:
- Step 1: Spot the expectation-reality gap: Year of practice → expectation of control; heater failure → loss of bodily control (stiff fingers). Outcome: flawless playing. That is situational irony.
- Step 2: Identify the symbol: "Cold hall" (external hostility) vs. "hot hands" (internal mastery). The hands symbolize the artist's disciplined will.
- Step 3: Explain interaction: The irony (cold hall should ruin performance) is *resolved* by the symbol (hot hands = mastery transcends conditions).
- Step 4: Character insight: The artist is defined not by favorable conditions but by the ability to generate warmth (art) in coldness (adversity).
ANSWER: The passage uses situational irony: the year's preparation is nearly nullified by a broken heater, yet the pianist succeeds. The "hot hands" symbolize the artist's internalized skill — a portable furnace. Together they characterize the artist as someone whose art is an act of defiance against circumstance; the irony provides the threat, the symbol provides the triumph.
DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: "In 'viw osQ lkFk <kbZ lky,' the pen and the doll are parallel symbols: both are fragile instruments that mediate the creator's relationship with the world." Defend or challenge this statement with textual evidence, addressing both irony and symbolism.
COMPETENCY: Thematic argumentation using multiple devices (synthesis)
STEPS:
- Step 1: Establish the parallel: Pen mediates writer→story; doll mediates writer→child (and by extension, writer→reader). Both are "instruments."
- Step 2: Show fragility: Pen fails (irony of tool failure); doll is a cheap replacement (irony of inauthenticity). Both are vulnerable.
- Step 3: Trace divergence: Pen's failure is *internal* to the creative act (writer's block); doll's "failure" (being a substitute) is *external* (lost original). The pen symbolizes the *struggle*; the doll symbolizes the *leap of faith*.
- Step 4: Evaluate the statement: Partially true — both are fragile mediators. But the pen's irony is situational (expectation vs. reality of function); the doll's irony is dramatic (writer knows it's fake, child doesn't). The symbols serve different thematic stages: pen = anxiety; doll = resolution.
- Step 5: Conclude: The statement oversimplifies by ignoring the *type* of irony and the *temporal evolution* of the doll's symbolism.
ANSWER: I challenge the "parallel" claim. While both are fragile mediators, the pen's irony is situational (professional tool fails) and it symbolizes the *obstacle* to creation. The doll's irony is dramatic (creator knows it's a substitute; recipient doesn't) and it evolves to symbolize *acceptance* of imperfection. The pen represents the agony of beginning; the doll represents the grace of completion. They are sequential, not parallel.
DIFFICULTY: hard