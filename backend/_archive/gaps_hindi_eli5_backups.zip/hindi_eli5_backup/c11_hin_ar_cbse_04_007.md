## DEFINITION
Secondary themes are the underlying, supporting ideas in a literary work that complement and enrich the primary theme, often exploring specific social, psychological, historical, or moral dimensions through recurring motifs, character interactions, and narrative details.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student can identify at least three distinct secondary themes in "फोनब्जलाHkk"k.k", trace each across two or more textual evidence points, and explain how they deepen the primary anti-colonial critique using the PEEL structure (Point, Evidence, Explanation, Link).

## SCOPE_BOUNDARY
This node covers identification and analysis of secondary themes (colonial psychology, linguistic resistance, historical accountability, ironic justice) in Krishan Chander's "फोनब्जलाHkk"k.k". It does NOT cover primary theme identification (node 006), literary devices (nodes 008-009), or writing skills (node 014).

## WALKTHROUGH
Imagine you're watching a movie where the hero defeats the villain, but you notice subtle subplots: the villain's insecurity, the hero's use of the villain's own weapons, and a background character remembering a forgotten promise. These subplots are secondary themes. In "फोनब्जलाHkk"k.k", start by rereading the narrator's monologue (pages 46-50) and highlight every passage where the British officer's hypocrisy, the narrator's rhetorical traps, or historical references appear. Ask: "What idea does this pattern reveal beyond 'British rule is bad'?" The key insight: secondary themes are the threads that make the primary theme's tapestry complex and credible.

## DIAGNOSTIC_QUESTION_1
Define 'secondary theme' in your own words and give one example from any story you have read.

## DIAGNOSTIC_ANSWER_1
A secondary theme is a supporting idea that runs parallel to the main theme, adding depth (e.g., in "The Necklace", a secondary theme is the danger of vanity, while the primary theme is the irony of fate). A wrong answer that confuses secondary theme with 'subplot' or 'character trait' shows the student cannot distinguish thematic layers from narrative elements.

## DIAGNOSTIC_QUESTION_2
In "फोनब्जलाHkk"k.k", the narrator repeatedly uses the British officer's own historical figures (Clive, Warren Hastings) against him. Explain what secondary theme this pattern develops and why it is not the primary theme.

## DIAGNOSTIC_ANSWER_2
This pattern develops the secondary theme of 'historical accountability' — using the colonizer's own recorded crimes to expose moral bankruptcy. It is not the primary theme because the central message is the illegitimacy of colonial rule itself, while historical accountability is one method of proving it. A wrong answer that calls this the primary theme reveals an inability to distinguish the central argument from its supporting strategies.

## DIAGNOSTIC_QUESTION_3
Find two passages in the text (provide page/line references) where the narrator turns the officer's language (English/Hindustani) into a weapon. Apply the concept of 'linguistic resistance' to explain how each passage works.

## DIAGNOSTIC_ANSWER_3
Passage 1 (p.47): The narrator mimics the officer's "फोनब्जलाHkk"k.k" tone to mock his authority. Passage 2 (p.49): The narrator uses Sanskritized Hindi ("इज्जत", "न्याय") to claim moral high ground. Both show linguistic resistance — reclaiming power by subverting the oppressor's language. A wrong answer that only translates the lines misses the analytical step of connecting language choice to thematic resistance.

## DIAGNOSTIC_QUESTION_4
Compare the psychological portrayal of the British officer in the first half (arrogant, dismissive) with the second half (rattled, defensive). Analyze how this shift supports the secondary theme of 'colonial fragility'.

## DIAGNOSTIC_ANSWER_4
The officer's shift from commanding "एक्का बुलाओ" to pleading "मेरी इज्जत रख लो" reveals that colonial authority rests on performance, not inherent superiority. The narrator's rhetorical traps expose this fragility systematically. A wrong answer that merely lists the officer's emotions without linking to the structural weakness of colonialism fails to analyze the theme.

## DIAGNOSTIC_QUESTION_5
Evaluate whether the secondary theme of 'ironic justice' (the officer trapped by his own laws) strengthens or weakens the story's anti-colonial message. Justify with textual evidence.

## DIAGNOSTIC_ANSWER_5
It strengthens the message by demonstrating that colonial 'justice' is a hollow construct — when applied fairly, it condemns the colonizer. The officer's inability to escape his own legal logic (p.50) proves the system's moral bankruptcy. A wrong answer that calls it 'just a plot twist' misses the thematic function of irony as critique.

## DIAGNOSTIC_QUESTION_6
Write a 100-word alternative ending where a different secondary theme (e.g., 'collective memory' or 'intergenerational trauma') becomes prominent, using the narrator's voice.

## DIAGNOSTIC_ANSWER_6
A strong answer will maintain the narrator's satirical tone, introduce a new thematic thread (e.g., the officer hearing voices of 1857 rebels), and link it to the existing narrative logic. A poor answer that simply changes the plot without thematic depth shows the student cannot generate thematic coherence.

## COMMON_MISCONCEPTION
Students often treat every recurring topic (e.g., "British officers", "Indian poverty") as a secondary theme. A theme is an *idea* or *argument* about that topic (e.g., "colonial power is performative", not just "colonial power exists"). This error occurs because they confuse motif (recurring image) with theme (abstract concept).

## ON_FAILURE
1. Give the student a two-column table: Column A lists recurring motifs (e.g., "officer's uniform", "historical names", "language switching"). 2. Ask them to write in Column B: "What idea about colonialism does this motif *prove*?" 3. Model one: Motif = "officer quotes British law" → Idea = "colonialism uses law as a shield". 4. Have them complete three more, then convert each Column B entry into a thematic statement.

## BUILDS_ON
Primary theme identification (node 006) — the central anti-colonial argument must be established before supporting themes can be mapped to it.

## LEADS_TO
Literary devices analysis (nodes 008-009) — secondary themes are often conveyed through imagery, irony, and symbolism, which require device-level analysis.

## PREREQUISITE_NODE_IDS
c11_hin_ar_cbse_04_001, c11_hin_ar_cbse_04_002, c11_hin_ar_cbse_04_003, c11_hin_ar_cbse_04_004, c11_hin_ar_cbse_04_005, c11_hin_ar_cbse_04_006
## PREREQUISITE_REASONS
c11_hin_ar_cbse_04_001: Context/background knowledge of colonial India is essential to decode historical references.
c11_hin_ar_cbse_04_002: Plot structure knowledge helps locate where secondary themes emerge in the narrative arc.
c11_hin_ar_cbse_04_003: Setting/atmosphere analysis reveals how physical space reinforces themes (e.g., the dak bungalow as colonial microcosm).
c11_hin_ar_cbse_04_004: Protagonist analysis shows how the narrator's character embodies thematic resistance.
c11_hin_ar_cbse_04_005: Supporting character (officer) analysis reveals how his portrayal serves thematic contrast.
c11_hin_ar_cbse_04_006: Primary theme must be fixed as the anchor for all secondary themes.

## FORWARD_NODE_IDS
c11_hin_ar_cbse_04_008, c11_hin_ar_cbse_04_009, c11_hin_ar_cbse_04_010, c11_hin_ar_cbse_04_011, c11_hin_ar_cbse_04_012, c11_hin_ar_cbse_04_013, c11_hin_ar_cbse_04_014, c11_hin_ar_cbse_04_015, c12_hin_a_cbse_01_007, c12_hin_a_cbse_04_007, c12_hin_a_cbse_08_007, c12_hin_a_cbse_10_007, c12_hin_ar_cbse_04_007, c12_hin_ar_cbse_07_007

## FORWARD_REASONS
c11_hin_ar_cbse_04_008: Imagery/metaphor analysis requires thematic awareness to interpret symbolic patterns.
c11_hin_ar_cbse_04_009: Irony/symbolism are primary vehicles for secondary themes like 'ironic justice'.
c11_hin_ar_cbse_04_010: Vocabulary in context is tied to the 'linguistic resistance' theme.
c11_hin_ar_cbse_04_011: Grammar/usage analysis reveals how language choices encode thematic positions.
c11_hin_ar_cbse_04_012: Comprehension questions often test thematic inference.
c11_hin_ar_cbse_04_013: Critical thinking builds directly on multi-theme analysis.
c11_hin_ar_cbse_04_014: Writing tasks require thematic structuring.
c11_hin_ar_cbse_04_015: Discussion points emerge from thematic debates.
c12_hin_a_cbse_01_007: Chapter 4 linked themes to character arcs.  
c12_hin_a_cbse_04_007: Class 11 Antra Chapter 4 secondary themes node provides the foundational skill of identifying and tracing subordinate themes in poetry.  
c12_hin_a_cbse_08_007: अगला तार्किक चरण: Secondary themes are the underlying, complementary ideas in a literary work that support, contrast w... इस नोड की अवधारणाओं को सीधे उपयोग/विस्तारित करता है।  
c12_hin_a_cbse_10_007: Exposure to thematic interplay in classical Hindi literature (Bharatendu, Dwivedi era).  
c12_hin_ar_cbse_04_007: Class 11 secondary themes practice (Chapter 4) builds the skill of distinguishing primary vs. secondary.  
c12_hin_ar_cbse_07_007: Chapter 4 application  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
none

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_04_006 -> c11_hin_ar_cbse_04_007 -> c11_hin_ar_cbse_04_008

## THIS_FORMULA
Secondary Theme = (Recurring Motif/Pattern) + (Abstract Idea it Proves) + (Link to Primary Theme)

## FORMULA_VARIABLES
Recurring Motif/Pattern: A repeated element (image, phrase, situation, character behavior) observed at 3+ points in the text. Abstract Idea: The universal concept (justice, fragility, resistance, memory) the pattern illustrates. Link to Primary Theme: Explicit explanation of how this idea supports the central argument.

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
analytical

## CROSS_SUBJECT
c11_history_colonialism | The secondary theme of 'historical accountability' directly connects to the history curriculum's coverage of colonial economic exploitation and the use of historical records as evidence.
c11_civics_rule_of_law | The theme of 'ironic justice' (colonizer trapped by own laws) illustrates the civics concept of rule of law versus rule by law, a core distinction in democratic theory.

## PREREQ_CONCEPT
The student must understand that a literary theme is an arguable claim about a universal human experience, not a topic or plot summary.

## PREREQ_BEFORE
The student must have completed node 006 (Primary Theme) and be able to state the primary theme of "फोनब्जलाHkk"k.k" in one precise sentence.

## PREREQ_STUCK
If stuck, review the distinction between 'topic' (colonialism) and 'theme' (colonialism is morally unsustainable because it relies on performative authority) using the worked example in node 006.

## WORKED_EXAMPLE_1
PROBLEM: Identify and analyze the secondary theme of 'performative authority' in the British officer's character, using three textual evidences from pages 46-48.
STEPS:
- Step 1: Locate the officer's first appearance (p.46) — he demands a carriage, uses imperatives ("एक्का बुलाओ"), assumes compliance.
- Step 2: Find the narrator's description of the officer's uniform and medals (p.46) — external symbols substituting for real power.
- Step 3: Identify the officer's reliance on historical precedent ("हमने तुम्हे सभ्य बनाया") — invoking a narrative to legitimize presence.
- Step 4: Synthesize: All three evidences show authority performed through props, tone, and story, not inherent legitimacy.
- Step 5: Link to primary theme: This performativity proves colonial rule is a fragile construct, not a natural order.
REASONING: The formula (Motif + Idea + Link) forces the student to move from observation to abstraction to thematic integration, which is the core analytical skill for board exams.
ANSWER: Secondary theme: 'Colonial authority is performative, not substantive.' Evidences: (1) Imperative commands mask dependence on Indian labor; (2) Uniform/medals are theatrical props; (3) 'Civilizing mission' rhetoric is a rehearsed script. Each performance cracks when challenged, revealing the primary theme: colonialism lacks moral foundation.

## WORKED_EXAMPLE_2
PROBLEM: Trace the secondary theme of 'linguistic resistance' through the narrator's code-switching between English, Hindustani, and Sanskritized Hindi. Provide two examples with analysis.
STEPS:
- Step 1: Scan the text for language shifts — mark every instance where the narrator chooses a specific register (e.g., p.47 "फोनब्जलाHkk"k.k" in English vs. p.49 "इज्जत", "न्याय" in Sanskritized Hindi).
- Step 2: Categorize each shift: Mockery (mimicking officer's English), Moral claim (Sanskritized Hindi), Intimacy (colloquial Hindustani with reader).
- Step 3: Analyze function: Mockery exposes officer's linguistic arrogance; Moral claim appropriates the 'high culture' vocabulary the British claimed to protect; Intimacy builds nationalist solidarity.
- Step 4: Generalize: Language is a battlefield where the narrator denies the officer monopoly over 'civilized' discourse.
- Step 5: Connect to primary theme: Linguistic resistance mirrors political resistance — both reclaim agency from colonial control.
REASONING: This example teaches close reading of register shifts as thematic evidence, a skill frequently tested in 'explain with reference to context' questions.
ANSWER: Theme: 'Language as site of resistance.' Example 1: Narrator mimics "फोनब्जलाHkk"k.k" (p.47) to reduce the officer's authority to a hollow sound. Example 2: Narrator uses "न्याय", "इज्जत" (p.49) to claim the moral vocabulary the British appropriated. Both demonstrate that the colonized can weaponize the colonizer's language and their own classical tradition simultaneously.

## WORKED_EXAMPLE_3
PROBLEM: The narrator references Clive, Warren Hastings, and Cornwallis (p.48-49). Analyze how this 'historical accountability' theme interacts with the 'ironic justice' theme when the officer is trapped by his own legal logic (p.50).
STEPS:
- Step 1: List the three historical figures and the specific crime each is accused of in the text (Clive: plunder; Hastings: judicial murder; Cornwallis: permanent settlement exploitation).
- Step 2: Note the narrator's method: he uses British historians' own records ("तुम्हारे ही इतिहासकार") — turning the colonizer's archive against him.
- Step 3: Identify the ironic justice moment: The officer demands "कानून" (law) but the narrator shows British law itself condemns these acts (p.50: "तुम्हारे कानून के मुताबिक...").
- Step 4: Analyze interaction: Historical accountability provides the *evidence*; ironic justice provides the *mechanism* — the officer's own system becomes the instrument of his condemnation.
- Step 5: Evaluate thematic depth: This dual theme argues colonialism is not just externally imposed but internally contradictory — it carries the seeds of its own legal/moral collapse.
- Step 6: Link to primary theme: The primary theme (colonialism is illegitimate) is proven not by assertion but by the system's self-contradiction.
REASONING: This multi-step synthesis of two secondary themes demonstrates the high-order thinking (analysis + evaluation) required for 6-mark board questions.
ANSWER: The 'historical accountability' theme (using British records to document crimes) and 'ironic justice' theme (the officer ensnared by his own legal framework) are mutually reinforcing. The narrator first establishes the crimes via British sources (Clive, Hastings, Cornwallis), then demonstrates that the officer's appeal to "कानून" backfires because that same law, if applied impartially, would convict the British Empire. This proves the primary theme: colonialism is structurally unjust, not merely occasionally cruel.

## COMPETENCY_QUESTION_1
QUESTION: "In 'फोनब्जलाHkk"k.k', the secondary theme of 'colonial fragility' is conveyed not through what the officer *does*, but through what he *fears*." Using two specific textual details, evaluate the validity of this statement.
COMPETENCY: Critical analysis of characterization as thematic vehicle
STEPS:
- Step 1: Identify two moments where the officer's fear is explicit or implicit (e.g., p.47 "मेरी इज्जत रख लो", p.50 "कहीं यह बात फैला न दे").
- Step 2: Explain what each fear reveals about colonial psychology (fear of exposure, fear of loss of control).
- Step 3: Contrast with his actions (bluster, threats) to show the gap between performance and reality.
- Step 4: Conclude whether the statement is valid, and how this fear-based portrayal serves the primary theme.
ANSWER: The statement is largely valid. The officer's plea "मेरी इज्जत रख लो" (p.47) reveals fear of public shame — the colonial 'prestige' is a social construct, not inherent. His panic at the narrator's threat to expose the encounter (p.50) shows fear of losing narrative control. These fears are more telling than his bluster because they expose the psychological dependence of the colonizer on the colonized's complicity. This directly supports the primary theme: colonial power collapses when the colonized refuse to perform their assigned role.
DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: Design a 4-row thematic evidence table for "फोनब्जलाHkk"k.k" with columns: (1) Secondary Theme, (2) Recurring Motif, (3) Key Passage (page/ref), (4) Link to Primary Theme. Fill it for any three secondary themes discussed in this node, ensuring each motif appears at least twice in the text.
COMPETENCY: Synthesis and structured presentation of thematic analysis
STEPS:
- Step 1: Select three secondary themes from the node (e.g., performative authority, linguistic resistance, historical accountability/ironic justice).
- Step 2: For each, identify a recurring motif (e.g., uniform/medals; code-switching; citation of British historians).
- Step 3: Locate two distinct textual occurrences for each motif with page references.
- Step 4: Articulate the link to primary theme in one precise sentence per row.
- Step 5: Verify that the table demonstrates the formula: Motif + Idea + Link.
ANSWER: 
Row 1: Performative Authority | Uniform/medals, imperative commands | p.46 (uniform description), p.47 ("एक्का बुलाओ") | Shows colonial power is theatrical, not substantive.
Row 2: Linguistic Resistance | Code-switching (English mimicry, Sanskritized Hindi) | p.47 ("फोनब्जलाHkk"k.k"), p.49 ("न्याय", "इज्जत") | Reclaims discursive agency from colonial monopoly.
Row 3: Historical Accountability/Ironic Justice | Citation of British historians/laws | p.48 (Clive, Hastings, Cornwallis), p.50 ("तुम्हारे कानून के मुताबिक") | Proves colonialism is self-condemning by its own standards.
DIFFICULTY: hard