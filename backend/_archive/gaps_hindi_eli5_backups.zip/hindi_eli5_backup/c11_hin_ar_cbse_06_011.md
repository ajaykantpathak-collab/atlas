## DEFINITION
Grammar: Language Usage in the Text refers to the systematic analysis of how linguistic choices—such as code-mixing (डक्सम फेफ्डलाक्स/डक्सम फ्लोफपाक्स), register variation (formal vs. colloquial), dialectal markers, and syntactic patterns—function within the play "jtuh" to reveal character identity, social hierarchy, thematic tension, and dramatic realism.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student must be able to identify at least three distinct language-usage features in the play, explain their dramatic function with textual evidence, and demonstrate the difference between डक्सम फेफ्डलाक्स and डक्सम फ्लोफपाक्स by citing original examples from the dialogue.

## SCOPE_BOUNDARY
This node covers linguistic analysis of the play's dialogue and stage directions only; it does not cover literary devices like imagery or symbolism (covered in nodes 06_008, 06_009) nor plot comprehension (node 06_012). It focuses on Hindi-English code-mixing, register shifts, and dialect representation as grammatical/stylistic choices.

## WALKTHROUGH
Imagine you are watching a modern Indian web-series where characters effortlessly switch between Hindi and English mid-sentence—now ask: why does the playwright make जटुह (the teacher) speak in polished Hindi while वफर (the student) uses "V~;w'ku" and "bZ;jyh"? Begin by reading aloud a two-page dialogue segment, highlighting every English-derived word in Devanagari script. Next, categorise each highlighted term as either a single-word insertion (डक्सम फेफ्डलाक्स) or a syntactic blend (डक्सम फ्लोफपाक्स). Then, link each category to the speaker's social role: the school director uses administrative register ("cksMZ", "funs'kd"), the mother uses domestic endearments ("yhyk"), and the student uses peer slang. The key insight: language usage is not decorative—it is the playwright's primary tool for characterisation and social critique.

## DIAGNOSTIC_QUESTION_1
Define डक्सम फेफ्डलाक्स and डक्सम फ्लोफपाक्स in your own words, giving one original example from the play for each.

## DIAGNOSTIC_ANSWER_1
डक्सम फेफ्डलाक्स = inserting a single English word into a Hindi sentence (e.g., "V~;w'ku" in "V~;w'ku osQ uke ij"). डक्सम फ्लोफपाक्स = mixing grammatical structures of both languages within one clause (e.g., "eks aVkt esa oqQN n`'; fn[kk, tk,¡" where English syntax "montage" is embedded). A wrong answer that merely lists English words without distinguishing insertion vs. structural blending reveals the student cannot see grammar as a system of choices.

## DIAGNOSTIC_QUESTION_2
Explain why the playwright makes the school director (funs'kd) say "cksMZ dk dke gh ;g gS fd f'k{kk osQ izpkj&izlkj esa ftruk Hkh gks losQ lg;ksx djsA" while जटुह (jtuh) replies "tc bruh cM+h ,M nsrs gSa rks vkidk dksbZ oaQVªksy Hkh jgrk gksxk LowQyksa ijA" Focus on register and power dynamics.

## DIAGNOSTIC_ANSWER_2
The director uses bureaucratic register ("izpkj&izlkj", "lg;ksx") to legitimise institutional authority; जटुह counters with sarcastic commercial register ("oaQVªksy", "LowQyksa ij") to expose the school's market-driven hypocrisy. A student who only translates the sentences misses how register encodes ideological conflict.

## DIAGNOSTIC_QUESTION_3
In the exchange where वफर says "esjs gks x,A" after जटुह asks "isij vPNk djks rc Hkh uacj de gks tkrs gSa\", identify the grammatical mood of वफर's utterance and explain its pragmatic effect in the context of a parent-teacher conference.

## DIAGNOSTIC_ANSWER_3
"esjs gks x.A" is a declarative mood statement functioning as a performative admission—it simultaneously acknowledges the fee reduction and asserts वफर's helplessness. A student who labels it merely "past tense" fails to connect grammar to the powerlessness of a marginalised parent.

## DIAGNOSTIC_QUESTION_4
Compare the stage direction language ("n`'; lekIr u;k n`';") with the dialogue language. How does the playwright use imperative vs. descriptive verb forms to differentiate narrative voice from character voice?

## DIAGNOSTIC_ANSWER_4
Stage directions use infinitives/imperfective participles ("ctkus", "ns[krs gq,", "iM+rs gq,") to create a timeless, observational narrator, while dialogue uses finite conjugated verbs ("gS", "gqbZ", "yxh") anchoring characters in immediate interaction. Confusing the two voices indicates the student cannot distinguish meta-textual grammar from dramatic grammar.

## DIAGNOSTIC_QUESTION_5
Critique the effectiveness of the playwright's use of डक्सम फ्लोफपाक्स in the climax where जटुह declares "vc vki yksx viuh jk; nhft,A" after a montage of voices. Does the syntactic blending enhance or dilute the political message? Justify.

## DIAGNOSTIC_ANSWER_5
The blending enhances the message: by embedding English administrative terms ("f'kdk;r", "fu;e", "izLrko") inside Hindi syntactic frames, the playwright mirrors how neoliberal policy language colonises everyday speech, making the protest linguistically enact the very resistance it voices. A purely aesthetic judgment ("it sounds modern") shows insufficient critical engagement.

## DIAGNOSTIC_QUESTION_6
Write a five-line dialogue between a gig-worker and a platform-algorithm (personified) that uses डक्सम फेफ्डलाक्स for technical terms and डक्सम फ्लोफपाक्स for the worker's internal monologue, mimicking the play's style.

## DIAGNOSTIC_ANSWER_6
Example:
Worker: "Algorithm bhai, rating kam kyun gayi?"
Algorithm: "Policy update—new metrics applied."
Worker (aside): "Metrics matlab? Mere kaam ka data harvest kar liya."
Algorithm: "Compliance mandatory. Appeal window closed."
Worker: "Appeal bhi ek 'feature' hai jo humein diya hi nahi."
A poor answer would use only Hindi or only English, missing the strategic code-switching that indexes power asymmetry.

## COMMON_MISCONCEPTION
Students often think "code-mixing" just means "using English words in Hindi" and treat every English-origin word as identical. They miss that डक्सम फेफ्डलाक्स (word-level insertion) and डक्सम फ्लोफपाक्स (structural blending) have different grammatical mechanisms and dramatic purposes. For instance, they might label "V~;w'ku" and "eks aVkt" both as "code-mixing" without noticing the former is a lexical loan while the latter forces Hindi syntax to accommodate an English noun phrase ("montage"), thereby performatively enacting cultural imposition.

## ON_FAILURE
1. Give the student a two-column table: Column A = 5 sentences from the play with English words; Column B = labels "फेफ्डलाक्स" or "फ्लोफपाक्स". 2. Ask them to circle the English element and draw an arrow to the Hindi grammatical slot it occupies (noun slot, verb slot, clause slot). 3. Have them explain aloud: "This word sits in a Hindi noun phrase → फेफ्डलाक्स" vs. "This phrase forces Hindi word order to change → फ्लोफपाक्स". 4. Finally, assign a mini-rewrite: convert one फ्लोफपाक्स sentence into pure Hindi and discuss what is lost (e.g., the bureaucratic flavour of "f'kdk;r").

## BUILDS_ON
Vocabulary in Context (node 06_010) where students learned key terms like "V~;w'ku", "cksMZ", "funs'kd" and their contextual meanings.

## LEADS_TO
Comprehension: Literal and Inferential Questions (node 06_012) where language-usage analysis becomes evidence for inferential answers about character motive and theme.

## PREREQUISITE_NODE_IDS
c11_hin_ar_cbse_06_010, c11_hin_ar_cbse_06_008, c11_hin_ar_cbse_06_009, c11_hin_ar_cbse_06_004, c11_hin_ar_cbse_06_005, c11_hin_ar_cbse_06_001, c11_hin_ar_cbse_06_006

## PREREQUISITE_REASONS
c11_hin_ar_cbse_06_010: Provides the lexical inventory (key words) that are the raw data for code-mixing analysis.
c11_hin_ar_cbse_06_008: Establishes imagery/metaphor awareness so students don't confuse linguistic devices with literary tropes.
c11_hin_ar_cbse_06_009: Irony/symbolism knowledge helps interpret why code-mixing can be ironic (e.g., director's "V~;w'ku" vs. जटुह's "V~;w'ku").
c11_hin_ar_cbse_06_004: Protagonist analysis gives character background needed to link register to personality.
c11_hin_ar_cbse_06_005: Supporting character analysis supplies social roles (director, mother, student) that determine language choices.
c11_hin_ar_cbse_06_001: Grammar usage reflects the play's deliberate mixing of formal Hindi and colloquial speech for authenticity.  
c11_hin_ar_cbse_06_006: Language usage (formal vs. colloquial) reflects power dynamics central to theme.  

## FORWARD_NODE_IDS
c11_hin_ar_cbse_06_012, c11_hin_ar_cbse_06_013, c11_hin_ar_cbse_06_014, c11_hin_ar_cbse_06_015, c12_hin_a_cbse_04_011, c12_hin_a_cbse_06_011, c12_hin_a_cbse_09_011, c12_hin_a_cbse_11_011, c12_hin_a_cbse_12_011, c12_hin_a_cbse_17_011, c12_hin_ar_cbse_01_011, c12_hin_ar_cbse_02_011, c12_hin_ar_cbse_06_011, c12_hin_ar_cbse_07_011, c12_hin_ar_cbse_09_011, c12_hin_ar_cbse_10_011, c12_hin_ar_cbse_11_011

## FORWARD_REASONS
c11_hin_ar_cbse_06_012: Language-usage evidence directly supports inferential comprehension answers.
c11_hin_ar_cbse_06_013: Critical interpretation of power dynamics relies on register and code-mixing analysis.
c11_hin_ar_cbse_06_014: Writing tasks (e.g., converting scene to story) require replicating the play's linguistic texture.
c11_hin_ar_cbse_06_015: Speaking tasks (discussion) need vocabulary to articulate linguistic observations.
c12_hin_a_cbse_04_011: अगला तार्किक चरण: This node analyzes the grammatical structures, syntactic patterns, and language usage specific to th... इस नोड की अवधारणाओं को सीधे उपयोग/विस्तारित करता है।  
c12_hin_a_cbse_06_011: Provides foundational Braj Bhasha grammar rules (pronouns, verbs, sandhi) directly applicable to Raskhan's text.  
c12_hin_a_cbse_09_011: Practiced *sandhi* in modern text — Braj shows distinct sandhi (e.g., *vkou* from *bahu+ku*) for comparison.  
c12_hin_a_cbse_11_011: Covers comparative constructions (se, dy, thaan) — needed for "dy osQ eksj ls" analysis.  
c12_hin_a_cbse_12_011: Training in distinguishing narrator's language from character's speech  
c12_hin_a_cbse_17_011: Analyzed author's linguistic choices in earlier essays — builds analytical habit.  
c12_hin_ar_cbse_01_011: Exposure to ergative/non-ergative variation in poetic contexts.  
c12_hin_ar_cbse_02_011: Deeper understanding of syntactic deviations.  
c12_hin_ar_cbse_06_011: Introduces Braj Bhasha grammar basics — verb endings, postpositions, समास — directly applicable here.  
c12_hin_ar_cbse_07_011: Introduction to dfoÙk and loS;k meters.  
c12_hin_ar_cbse_09_011: Consolidates understanding of imagery types through grammatical lens.  
c12_hin_ar_cbse_10_011: Study of folk sayings (lokoktiyan) in text (Chapter 6).  
c12_hin_ar_cbse_11_011: Strengthens syntax-characterization linking  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
none

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_06_010 -> c11_hin_ar_cbse_06_011 -> c11_hin_ar_cbse_06_012

## THIS_FORMULA
डक्सम फेफ्डलाक्स = [Hindi Syntactic Frame] + [Single English Lexical Item] | डक्सम फ्लोफपाक्स = [Hybrid Syntactic Structure] where English grammar influences Hindi word-order/morphology

## FORMULA_VARIABLES
Hindi Syntactic Frame: the base sentence structure in Hindi (SOV, postpositions, agreement). Single English Lexical Item: one English-origin word inserted without changing Hindi grammar. Hybrid Syntactic Structure: a clause where English syntactic rules (e.g., prepositional phrases, SVO order) visibly reshape the Hindi utterance.

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
linguistic

## CROSS_SUBJECT
c11_sociology_social_change | The play's language reflects shifting class codes in urban India; sociology examines how language indexes social mobility and exclusion.
c11_psychology_cognitive_development | Code-switching research in psycholinguistics shows how bilingual speakers manage cognitive load; the play dramatizes this in parent-teacher interactions.

## PREREQ_CONCEPT
Ability to distinguish lexical borrowing from syntactic interference in bilingual speech.

## PREREQ_BEFORE
Student must recognise basic Hindi parts of speech (noun, verb, postposition) and English parts of speech to map insertions.

## PREREQ_STUCK
Review Class 10 Hindi grammar: पद परिचय (parts of speech) and वाक्य विचार (sentence structure) to identify slots where English words enter.

## WORKED_EXAMPLE_1
PROBLEM: Analyse the utterance "vki Hkh eglwl djrs gSa u ,slk\--- rks fiQj lkFk nhft, gekjkA" (spoken by जटुह to लैकन्द). Identify all डक्सम फेफ्डलाक्स and डक्सम फ्लोफपाक्स instances, and explain how they characterise जटुह as an activist-teacher.
STEPS:
- Step 1: Transliterate the utterance and mark every English-origin word: "vki Hkh eglwl djrs gSa u ,slk\--- rks fiQj lkFk nhft, gekjkA" → no English words visible; but earlier in the same speech she says "v[kckj ;fn fdlh b';w dks mBk ys vkSj yxkrkj ml ij pksV djrk jgs rks fiQj og FkksM+s ls yksxksa dh ckr ugha jg tkrhA lcdh cu tkrh gS---vk¡[k ew¡ndj ugha jg ldrk fiQj dksbZ mllsA" – here "b';w" (issue), "mBk" (bring), "pksV" (pressurise) are Hindi; however "v[kckj" (editor), "lcdh" (logic), "ew¡ndj" (stand) are Hindi. Wait—look for English: "v[kckj" is Hindi, but "editor" is English loan. Actually the text uses "v[kckj" (Hindi). The play uses Devanagari for English words like "V~;w'ku", "bZ;jyh", "cksMZ". In this excerpt, there are no Devanagari-English words. So we need to pick a different utterance. Let's choose the director's line: "cksMZ dk dke gh ;g gS fd f'k{kk osQ izpkj&izlkj esa ftruk Hkh gks losQ lg;ksx djsA". Here "cksMZ" (school), "f'k{kk" (education), "izpkj&izlkj" (administration), "lg;ksx" (implementation) are all Sanskritised Hindi. The English loans appear elsewhere. Let's use वफर's line: "esjs fj”kYV dkA eSaus fdruk dgk Fkk fd eSFl esa Hkh esjh V~;w'ku yxok nhft,] ojuk esjk fj”kYV fcxM+ tk,xkA". Here "V~;w'ku" (tuition) is a single English loan in Devanagari → डक्सम फेफ्डलाक्स. Also "fcxM+" (high) is Hindi. No structural blending. For डक्सम फ्लोफपाक्स, look at the stage direction: "eks aVkt esa oqQN n`'; fn[kk, tk,¡" where "eks aVkt" (montage) is an English noun phrase inserted as adverbial, and the rest is Hindi passive construction. That's structural blending because "montage" brings its English syntactic expectation (countable noun with article) but gets Hindi case marking "esa". 
- Step 2: Classify each: "V~;w'ku" = फेफ्डलाक्स (noun slot). "eks aVkt" = फ्लोफपाक्स (adverbial phrase with English head noun).
- Step 3: Link to character: वफर uses "V~;w'ku" naturally, showing middle-class aspiration; the stage direction uses "eks aVkt" to signal modern theatrical technique, meta-commenting on form.
- Step 4: Explain dramatic function: The lexical loan indexes वफर's socioeconomic world; the structural blend in stage direction indexes the playwright's modernist aesthetics.
- Step 5: Conclude: Two different code-mixing types serve two different dramatic levels—character realism vs. authorial innovation.
REASONING: This step-by-step moves from identification to classification to functional interpretation, modelling the analytical hierarchy required in board answers.
ANSWER: डक्सम फेफ्डलाक्स: "V~;w'ku" (noun insertion). डक्सम फ्लोफपाक्स: "eks aVkt esa" (English noun phrase governing Hindi postposition). Characterisation: वफर's loanword reflects parental anxiety about education costs; stage direction's blend signals experimental form.

## WORKED_EXAMPLE_2
PROBLEM: The director says "vkWI+kQdkslZA cksMZ osQ cgqr ls ,sls fu;e gSa tks LowQyksa dks ekuus gksrs gSa] LowQy ekurs gSaA flyscl cksMZ cukrk gS---I+kQkbuy bZ;j osQ ,D”kkEl cksMZ oaQMDV djrk gSA". Identify the register features (lexical, syntactic, rhetorical) that construct institutional authority, and contrast with जटुह's immediate reply.
STEPS:
- Step 1: Segment the director's utterance into clauses: (a) "vkWI+kQdkslZA" (acknowledgement), (b) "cksMZ osQ cgqr ls ,sls fu;e gSa tks LowQyksa dks ekuus gksrs gSa] LowQy ekurs gSa" (generalisation with relative clause), (c) "flyscl cksMZ cukrk gS" (brand-name claim), (d) "I+kQkbuy bZ;j osQ ,D”kkEl cksMZ oaQMDV djrk gSA" (proper-noun heavy institutional naming).
- Step 2: Tag register markers: Sanskritised lexicon ("fu;e", "ekuus", "ekurs", "oaQMDV", "I+kQkbuy"), complex sentence embedding (relative clause "tks..."), passive/impersonal construction ("cukrk gS", "djrk gS"), zero colloquial contractions.
- Step 3: Now examine जटुह's reply: "LowQyksa esa vktdy izkbosV V~;w'kal dk tks flyflyk pyk gqvk gS] V~;w'kal D;k cPpksa dks ywVus dk tks èkaèkk pyk gqvk gS] mlosQ ckjs esa vkidk cksMZ D;k djrk gS\"". Mark: rhetorical question, colloquial "flyflyk" (rampant), "èkaèkk" (trend), "V~;w'ku" (loan), direct address "vkidk cksMZ".
- Step 4: Contrast: Director = bureaucratic register (depersonalised, nominalised, hierarchical). जटुह = critical register (interrogative, metaphorical "flyflyk", "èkaèkk", direct challenge).
- Step 5: Interpret: The clash of registers enacts the conflict between institutional self-legitimation and teacher's subversive questioning.
REASONING: Register analysis requires moving from word-level to clause-level to discourse-level, mirroring the board's expectation of multi-layered linguistic commentary.
ANSWER: Director uses Sanskritised lexis, embedded clauses, impersonal verbs to project authority; जटुह uses rhetorical questions, colloquial metaphors, English loans ("V~;w'ku") to dismantle that authority.

## WORKED_EXAMPLE_3
PROBLEM: The play ends with a montage ("eks aVkt") of voices demanding "dksbZ Hkh Vhpj vius gh LowQy osQ Nk=kksa dk V~;w'ku ugha djsxkA". Using the concepts of डक्सम फेफ्डलाक्स and डक्सम फ्लोफपाक्स, explain how the final legislative performative ("fu;e dks rksM+us okys VhplZ osQ f[kykI+kQ l[r&ls&l[r dk;Zokgh dh tk,xh---") synthesises both code-mixing types to imagine a decolonised policy language.
STEPS:
- Step 1: Isolate the final legislative sentence: "fu;e dks rksM+us okys VhplZ osQ f[kykI+kQ l[r&ls&l[r dk;Zokgh dh tk,xh---". Identify English-origin elements: "VhplZ" (schools), "f[kykI+kQ" (amendment), "l[r&ls&l[r" (strict), "dk;Zokgh" (action/work). All are Sanskritised Hindi loans from English, but written in Devanagari—these are lexical loans (फेफ्डलाक्स).
- Step 2: Check for structural blending: The syntax is purely Hindi SOV with postpositions ("okys", "osQ", "dh"). No English word order. So only फेफ्डलाक्स at word level.
- Step 3: Now examine the preceding montage line: "dksbZ Hkh Vhpj vius gh LowQy osQ Nk=kksa dk V~;w'ku ugha djsxkA". Here "Vhpj" (politician), "LowQy" (school), "Nk=kksa" (own), "V~;w'ku" (tuition) are all फेफ्डलाक्स. But the phrase "vius gh LowQy osQ" mirrors English "their own school's" with Hindi genitive "osQ"—this is a calque, a subtle फ्लोफपाक्स where English possessive structure is replicated in Hindi.
- Step 4: Synthesise: The montage accumulates फेफ्डलाक्स (lexical decolonisation: using Hindi script for English concepts) while the legislative sentence achieves a Hindi syntactic frame for policy discourse. Together they model a future where English terminology is nativised (फेफ्डलाक्स) but grammar remains Hindi (resisting फ्लोफपाक्स).
- Step 5: Connect to theme: This linguistic strategy mirrors the play's political arc—from individual resistance (जटुह's sarcasm) to collective legislation (लैकन्द's law).
- Step 6: Board-exam phrasing: "The playwright uses lexical nativisation (डक्सम फेफ्डलाक्स) to reclaim educational vocabulary, while avoiding structural hybridity (डक्सम फ्लोफपाक्स) in the legislative register, thereby asserting linguistic sovereignty."
REASONING: This example demands integration of both code-mixing types across discourse segments, plus thematic synthesis—exactly the multi-step reasoning Class 11 board questions require.
ANSWER: The montage layers फेफ्डलाक्स ("Vhpj", "LowQy", "V~;w'ku") with a calque-type फ्लोफपाक्स ("vius gh LowQy osQ"); the legislative sentence uses only फेफ्डलाक्स in pure Hindi syntax, symbolising a policy language that has absorbed English concepts but rejected English grammar.

## COMPETENCY_QUESTION_1
QUESTION: In the parent-teacher conference scene, वफर says "eSFl esa rks rw oSls gh cgqr vPNk gS] D;k djsxk V~;w'ku ysdj\" and जटुह replies "V~;w'ku rks de”kksj cPps ysrs gSaA". Using register analysis, explain how the same word "V~;w'ku" indexes opposite ideological positions for the two speakers.
COMPETENCY: Linguistic register analysis and ideological inference
STEPS:
- Step 1: Identify the speech event: formal parent-teacher meeting, power asymmetry.
- Step 2: Analyse वफर's utterance: "V~;w'ku" appears in a hypothetical conditional ("D;k djsxk V~;w'ku ysdj") framed as desperate solution; register = supplicatory, domestic, finance-anxious.
- Step 3: Analyse जटुह's utterance: "V~;w'ku" appears in a generalising present habitual ("de”kksj cPps ysrs gSa") framed as sociological fact; register = critical, pedagogical, structural.
- Step 4: Contrast: For वफर, "V~;w'ku" = unavoidable expense (commodity). For जटुह, "V~;w'ku" = systemic symptom (critique).
- Step 5: Conclude: Identical lexical item, divergent pragmatic force due to register framing.
ANSWER: वफर uses "V~;w'ku" in a domestic-finance register (commodity to buy); जटुह recontextualises it in a critical-pedagogical register (systemic disease). The word becomes a site of ideological struggle.
DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: The play's stage directions repeatedly use imperfective participles ("ctkus", "ns[krs gq,", "iM+rs gq,") while dialogue uses finite verbs. A director wants to film this play. Advise the director on how to translate this grammatical distinction into visual grammar (camera movement, editing rhythm). Justify with two specific textual examples.
COMPETENCY: Inter-semiotic translation (linguistic to visual grammar)
STEPS:
- Step 1: Define the linguistic distinction: stage directions = atemporal, observational (participles); dialogue = temporal, interactional (finite verbs).
- Step 2: Choose example 1: Stage direction "(nunukrh fudy tkrh gSA nksuksa osQ psgjs ij ,d vlgk;&lk HkkoA)" → participles "fudy", "tkrh" describe continuous state.
- Step 3: Visual correlate: slow tracking shot, deep focus, no cuts—camera as detached observer.
- Step 4: Choose example 2: Dialogue "jtuh % vjs okg! rc rks eSa feBkbZ [kkdj gh tkÅ¡xhA" → finite verbs "okg", "tkÅ¡xh" mark immediate speech act.
- Step 5: Visual correlate: shot-reverse-shot, close-ups, rapid editing—camera as participant in exchange.
- Step 6: Synthesise: The grammatical aspect (imperfective vs. perfective/finite) maps to camera aspect (continuous vs. segmented).
ANSWER: Use continuous long takes for stage directions (mirroring participles' unbounded aspect) and fragmented shot-reverse-shot for dialogue (mirroring finite verbs' bounded speech acts). Example: the opening stage direction's "nunukrh fudy tkrh gSA" → 30-second unbroken take; the first exchange "jtuh % yhyk csu dgk¡ gks---ck”kkj ugha pyuk D;k\" → rapid alternation between जटुह and यहयक close-ups.
DIFFICULTY: hard