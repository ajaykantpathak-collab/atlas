## DEFINITION
Secondary themes are the underlying thematic threads that run parallel to the primary theme, enriching the narrative by exploring complementary human experiences, social critiques, or philosophical questions without dominating the central message.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student must be able to identify at least three distinct secondary themes in "tkequ dk isM+", trace each across specific textual evidence from beginning to end, and explain how each secondary theme deepens or complicates the primary theme of bureaucratic absurdity versus human dignity.

## SCOPE_BOUNDARY
This node covers identification, textual tracing, and analytical explanation of secondary themes in "tkequ dk isM+" only. It does NOT cover primary theme analysis (node 006), literary devices (nodes 008-009), or character analysis (nodes 004-005) except as evidence for thematic arguments.

## WALKTHROUGH
Imagine you're watching a news report about a poet who sat under a tree for days because government offices argued over whether a tree seed on his head was a "forest matter" or "municipal matter" — absurd, right? Now ask yourself: besides mocking red tape, what else is this story really about? Start by listing every human relationship that breaks down in the story — mother-son, officer-subordinate, poet-society, nature-machine. Then track how each breakdown appears in the opening, middle, and climax. The key insight: secondary themes aren't "extra topics" — they're the lenses through which the primary theme becomes visible in its full cruelty.

## DIAGNOSTIC_QUESTION_1
What is the most fundamental difference between a primary theme and a secondary theme in a short story?

## DIAGNOSTIC_ANSWER_1
The primary theme is the central controlling idea that organizes the entire narrative — every major plot event, character arc, and conflict serves it directly. A secondary theme runs parallel, enriching the primary theme by exploring a related but distinct dimension of human experience; it does not drive the main conflict but illuminates it from another angle. A wrong answer (e.g., "secondary themes are less important") reveals the student confuses thematic hierarchy with thematic significance — in "tkequ dk isM+", the secondary theme of environmental neglect is not "less important" but operates through a different causal chain than the bureaucratic absurdity.

## DIAGNOSTIC_QUESTION_2
In "tkequ dk isM+", the mother (ekyh) repeatedly tries to get officials to help remove the seed from her son's head. A student claims this shows "a mother's love" as a secondary theme. Why is this an incomplete thematic statement?

## DIAGNOSTIC_ANSWER_2
"A mother's love" is a topic, not a theme — a theme must make an assertion about that topic (e.g., "maternal love is rendered powerless against institutional indifference"). The student's error is confusing a recurring subject with a thematic statement. In the text, the mother's love is precisely what gets weaponized by the system — her desperation makes her navigate offices, sign petitions, and ultimately accept the absurd compromise. A complete secondary theme would articulate what the narrative *says* about maternal love in this context: it becomes a currency the bureaucracy spends but never honors.

## DIAGNOSTIC_QUESTION_3
Identify one secondary theme in "tkequ dk isM+" and provide two distinct textual moments (not from the same scene) where it surfaces through action or dialogue, not narration.

## DIAGNOSTIC_ANSWER_3
Secondary theme: The poet/artist as society's conscience, yet rendered voiceless by the very system that claims to protect culture. Moment 1: The poet (nck gqvk vkneh) refuses to let the tree be cut, saying "exj ,d vkneh dh tku dk loky gS" — asserting bodily autonomy as artistic integrity. Moment 2: When the Dy. Director offers a "compromise" (pquko-i=k), the poet rejects it with "eSa vHkh thfor gw¡" — his silence becomes louder than bureaucratic language. A wrong answer citing only the ending or only the beginning shows the student cannot trace thematic continuity across the narrative arc.

## DIAGNOSTIC_QUESTION_4
Compare how the secondary theme of "nature versus bureaucracy" operates differently in the first half (offices arguing over jurisdiction) versus the second half (the tree growing, the poet dying). What structural shift does this reveal?

## DIAGNOSTIC_ANSWER_4
In the first half, nature (the seed/tree) is a passive object over which bureaucrats fight jurisdictional wars — the Forest Department and Municipal Corporation treat it as paperwork. In the second half, the tree becomes an active agent: it grows, demands water, resists cutting, and ultimately outlives the poet. The structural shift is from *bureaucracy controlling nature* to *nature absorbing bureaucracy* — the final image of the tree standing while the poet dies and officials flee reverses the power dynamic. A student who only lists "nature vs bureaucracy" in both halves misses this inversion, which is the story's deepest irony.

## DIAGNOSTIC_QUESTION_5
Evaluate this claim: "The secondary theme of environmental degradation in 'tkequ dk isM+' is weakened because the tree is supernatural (a seed growing on a human head), making it a fantasy rather than a realistic ecological critique."

## DIAGNOSTIC_ANSWER_5
The claim fails because it misreads the literary mode — the supernatural premise is precisely what *enables* the ecological critique. By making the tree grow *on* a human body, Renu forces the bureaucracy to confront nature as intimate violation, not distant policy. The fantasy element heightens realism: a seed on a head is no more absurd than a file noting "tree in municipal area, jurisdiction unclear" while a man dies. The student who agrees with the claim confuses literalism with realism; the story uses the fantastic to expose the *actual* absurdity of environmental governance.

## DIAGNOSTIC_QUESTION_6
Write a 4-sentence thematic paragraph that weaves together two secondary themes from "tkequ dk isM+" and shows how they jointly intensify the primary theme of bureaucratic absurdity. Use no direct quotes — only paraphrased textual evidence.

## DIAGNOSTIC_ANSWER_6
The story traces how institutional language replaces human speech: the poet's verses become "pquko-i=k" (official orders), the mother's pleas become "iQkSju" (applications), and the tree's growth becomes "LokLF; ns[kuk" (medical examination). Simultaneously, the narrative shows care transforming into procedure — the mother's nurturing becomes "fu'p; djrs gSa" (making efforts), the doctor's healing becomes "I+kSQlyk djuk" (processing). Together, these twin secondary themes — *language as erasure* and *care as procedure* — prove that bureaucracy doesn't just fail humans; it metabolizes their humanity into its own survival. A weak answer lists the themes separately without showing their *interaction* in intensifying the primary theme.

## COMMON_MISCONCEPTION
Students treat secondary themes as a checklist of "topics mentioned in the story" (e.g., "environment," "mother-son relationship," "poetry") rather than as *arguments the narrative makes* about those topics. They write "environmental degradation" as a theme instead of "environmental degradation is accelerated when nature is reduced to jurisdictional categories." This error stems from Class 10 training where "theme = topic" was often accepted; at Class 11, theme requires a complete proposition with a subject and a predicate that the text *argues for* through its structure.

## ON_FAILURE
Step 1: Have the student pick one "topic" they listed (e.g., "poetry"). Step 2: Ask "What happens to poetry in this story? Does it save anyone? Does it fail? Does it change form?" Step 3: Force a complete sentence: "In this story, poetry ______ because ______." Step 4: Verify the sentence can be supported by *at least three* non-consecutive textual moments. Step 5: Repeat for two more topics. This converts topic-listing into thematic argumentation.

## BUILDS_ON
Primary theme identification (node 006) — the student must already articulate the central argument about bureaucratic absurdity before analyzing how secondary themes orbit it.

## LEADS_TO
Literary devices analysis (nodes 008-009) — understanding secondary themes enables recognizing how imagery, irony, and symbolism *encode* those themes rather than merely decorating the text.

## PREREQUISITE_NODE_IDS
c11_hin_ar_cbse_07_001, c11_hin_ar_cbse_07_002, c11_hin_ar_cbse_07_006, c11_hin_ar_cbse_07_003, c11_hin_ar_cbse_07_005

## PREREQUISITE_REASONS
c11_hin_ar_cbse_07_001: Context/background knowledge of Renu's satirical style and the socio-political milieu is essential to recognize thematic targets.
c11_hin_ar_cbse_07_002: Plot and narrative structure mastery allows the student to map thematic beats onto specific structural turns (exposition, jurisdictional conflict, climax, resolution).
c11_hin_ar_cbse_07_006: Primary theme must be established first — secondary themes are defined *relationally* to the primary theme.
c11_hin_ar_cbse_07_003: Secondary themes (art as witness, environmental ethics) emerge from atmospheric symbolism.  
c11_hin_ar_cbse_07_005: Secondary themes (artistic integrity, maternal instinct, bureaucratic dehumanization) are carried by specific supporting characters.  

## FORWARD_NODE_IDS
c11_hin_ar_cbse_07_008, c11_hin_ar_cbse_07_009, c11_hin_ar_cbse_07_013, c12_hin_a_cbse_01_007, c12_hin_a_cbse_07_007, c12_hin_a_cbse_08_007, c12_hin_a_cbse_10_007, c12_hin_ar_cbse_07_007, c12_hin_ar_cbse_12_007

## FORWARD_REASONS
c11_hin_ar_cbse_07_008: Imagery and metaphor analysis requires knowing *what* themes the images serve (e.g., the tree-as-file imagery serves the "language as erasure" theme).
c11_hin_ar_cbse_07_009: Irony and symbolism operate *through* secondary themes — the central irony (poet becomes tree) only resonates if the "poet as conscience" theme is established.
c11_hin_ar_cbse_07_013: Critical thinking/interpretation questions in board exams demand thematic synthesis across devices, characters, and structure.
c12_hin_a_cbse_01_007: Chapter 7 practiced writing theme-based answers.  
c12_hin_a_cbse_07_007: Class 11 node on secondary themes in a different chapter — establishes the foundational skill of identifying and explaining secondary themes.  
c12_hin_a_cbse_08_007: अगला तार्किक चरण: Secondary themes are the underlying, complementary ideas in a literary work that support, contrast w... इस नोड की अवधारणाओं को सीधे उपयोग/विस्तारित करता है।  
c12_hin_a_cbse_10_007: Introduces guru-shishya parampara as a recurring secondary theme in Hindi literature.  
c12_hin_ar_cbse_07_007: Class 11 foundation on secondary theme identification in simpler texts  
c12_hin_ar_cbse_12_007: Class 11 practice in identifying secondary themes in shorter texts builds the analytical habit.  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
none

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_07_006 -> c11_hin_ar_cbse_07_007 -> c11_hin_ar_cbse_07_008

## THIS_FORMULA
N/A - conceptual

## FORMULA_VARIABLES
N/A

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
analytical

## CROSS_SUBJECT
c11_political_science_bureaucracy | The story dramatizes Max Weber's "iron cage" of rational-legal authority — secondary themes show how bureaucratic procedures (jurisdictional disputes, file notings, compromise formulas) colonize human relationships, a core Class 11 Political Science concept.
c11_sociology_social_institutions | The breakdown of family, medical, and artistic institutions under bureaucratic pressure illustrates the sociological concept of "institutional isomorphism" — where distinct social spheres (family, medicine, art) are forced into administrative templates.

## PREREQ_CONCEPT
The student must understand that a theme is a *proposition* (subject + predicate) argued by the text, not a *topic* mentioned in the text.

## PREREQ_BEFORE
Ability to distinguish between "what the story is about" (plot summary) and "what the story argues" (thematic statement) — practiced in node 006.

## PREREQ_STUCK
Review the "theme vs topic" distinction exercise from node 006 where students converted "loneliness" → "loneliness in modern cities is produced by communication technology that promises connection."

## WORKED_EXAMPLE_1
PROBLEM: Identify and trace the secondary theme of "the corruption of care into procedure" across three distinct narrative moments in "tkequ dk isM+".

STEPS:
- Step 1: Define the thematic proposition precisely — "Institutional systems transform acts of human care (nurturing, healing, protecting) into bureaucratic procedures (applications, examinations, approvals) that serve the system's survival, not the human's need."
- Step 2: Locate Moment 1 (opening): The mother (ekyh) runs from Forest Dept to Municipal Corp to Police — her maternal care becomes "iQkSju" (application writing) and "fu'p; djrs gSa" (making efforts), terms that belong to office work, not mothering.
- Step 3: Locate Moment 2 (middle): The doctor (gkWVhZdYpj fMikVZesaV) examines the tree as a medical case — "LokLF; ns[kuk" (check condition), "tk¡p djosQ fjiksVZ Hkst nh" (gave fitness certificate) — healing becomes certification.
- Step 4: Locate Moment 3 (climax): The Dy. Director (dYpjy fMikVZesaV) offers "pquko-i=k" (compromise order) to save the poet — protection becomes a signed document; the poet rejects it saying "eSa vHkh thfor gw¡" (I am still satisfied), refusing procedural life.
- Step 5: Synthesize — Each moment shows care morphing into procedure; the progression moves from family → medicine → administration, proving the theme operates at every level of society.

REASONING: This works because it follows the "trace across structure" method — thematic analysis requires showing the theme's *trajectory*, not just its presence. The three moments are structurally spaced (beginning, middle, end) and institutionally distinct (family, medical, administrative), proving pervasiveness.

ANSWER: The secondary theme "care corrupted into procedure" is traced through: (1) Mother's love reduced to inter-office applications; (2) Doctor's healing reduced to fitness certificates for a tree; (3) Director's protection reduced to a compromise order the poet rejects. Together they show bureaucracy doesn't just ignore care — it *consumes* care and excretes procedure.

## WORKED_EXAMPLE_2
PROBLEM: Explain how the secondary theme "the poet as society's unheard conscience" complicates the primary theme of bureaucratic absurdity. Use two textual strategies Renu employs.

STEPS:
- Step 1: State the primary theme clearly — "Bureaucratic rationality destroys human life through jurisdictional absurdity."
- Step 2: State the secondary theme as a proposition — "The poet embodies moral truth that bureaucracy cannot process, yet his voice is systematically silenced by the very system that claims to protect culture."
- Step 3: Identify Strategy 1 — *Contrast of languages*: The poet speaks in metaphors ("vksl osQ iwQy" — the essence of poetry), officials speak in circulars ("I+kQkWjsLV fMikVZesaV", "pquko-i=k"). The narrative shows poetic language as *more* precise about reality (the tree *is* a life) than bureaucratic language (the tree *is* a jurisdictional dispute).
- Step 4: Identify Strategy 2 — *Structural marginalization*: The poet enters late (after 2 days of jurisdictional war), speaks little, and dies before the "solution" — his conscience is acknowledged only when it's too late (the final "pquko-i=k" arrives post-mortem).
- Step 5: Show complication — The secondary theme proves the primary theme is not just "absurdity" but *moral crime*: the system doesn't merely malfunction; it *actively suppresses* the consciousness that could expose it.

REASONING: This works because it uses "complicate" correctly — not "add to" but "deepen the moral weight of." The two strategies (language contrast, structural positioning) are distinct textual mechanisms, not just plot points.

ANSWER: The poet-as-conscience theme complicates bureaucratic absurdity by revealing it as *willful moral blindness*. Renu uses (1) language contrast — poetic truth vs administrative euphemism — and (2) structural marginalization — the poet arrives late, speaks less, dies before the file closes — to show the system survives by silencing its own conscience.

## WORKED_EXAMPLE_3
PROBLEM: A board exam question asks: "How do the secondary themes of 'environmental vulnerability' and 'institutional language games' intersect in the climax of 'tkequ dk isM+'? Analyze with reference to the final three pages." Construct a 6-step analytical answer.

STEPS:
- Step 1: Define both secondary themes as propositions — (A) "Nature's vulnerability is exposed when it is forced into human administrative categories" and (B) "Institutional language (files, orders, certificates) replaces material reality as the site where decisions are made."
- Step 2: Identify the climax zone — The final sequence: I+kQkWjsLV fMikVZesaV arrives with "vk'p;Z" (inspection), orders cutting; poet refuses; Dy. Director proposes cutting the *man* instead; poet accepts death; tree stands; officials leave.
- Step 3: Show Intersection Point 1 — The tree's vulnerability is *created* by language: it becomes "cuttable" only when the Director's "I+kQkWjsLV" (special order) reclassifies it from "protected" to "removable." The physical tree hasn't changed; the *file* has.
- Step 4: Show Intersection Point 2 — The poet's body becomes the *alternative site* of nature: when the Dy. Director says "cut the man" (vkneh dks dkVdj fudky fy;k tk,A), the human body replaces the tree as the "nature" to be sacrificed — proving the system sees both as mere obstacles to procedure.
- Step 5: Show Intersection Point 3 — The final image: "isM+ ogha dk ogha jgsxk" (tree remains as it was) while the poet dies and officials flee — the *material* nature outlasts the *linguistic* institution. The tree's survival is silent; the bureaucracy's departure is noisy (files, jeeps, orders).
- Step 6: Conclude the intersection — The climax proves that institutional language games *produce* environmental vulnerability: the tree was safe until the file said "cut it"; the poet was alive until the file said "compromise him." Language doesn't describe reality here — it *authorizes* destruction.

REASONING: This meets board-level competency by (a) defining themes propositionally, (b) locating precise textual zone, (c) showing *intersection* not just coexistence, (d) using three distinct intersection mechanisms, (e) ending with a synthesized insight about language/reality inversion.

ANSWER: In the climax, environmental vulnerability and institutional language games intersect fatally: (1) The tree becomes "cuttable" only when a special order reclassifies it — language authorizes violence against nature. (2) The poet's body is offered as substitute nature — "cut the man" — showing the system treats human and non-human life as equally expendable procedural obstacles. (3) The tree survives silently while the bureaucracy departs noisily — material reality outlasts linguistic authority. The intersection reveals the story's core argument: administrative language doesn't manage nature; it *legitimizes* its destruction.

## COMPETENCY_QUESTION_1
QUESTION: In "tkequ dk isM+", the mother (ekyh) says to the sitting vkneh: "rqEgkjk ;gk¡ dksbZ okfjl gS rks eq>s mldk vrk&irk crkvks] eSa mUgsa [kcj nsus dh dksf'k'k d:¡xk" — then immediately leaves when he says "eSa ykokfjl gw¡." A student argues this shows the mother *abandons* her son. Using the secondary theme of "care corrupted into procedure," explain why this reading misses the story's thematic architecture. What does the mother's exit actually represent?

COMPETENCY: Thematic interpretation with textual evidence and conceptual precision

STEPS:
- Step 1: Identify the student's error — reading the mother's action as individual moral choice rather than structural position.
- Step 2: Recall the secondary theme proposition — care becomes procedure when the system forces it into administrative channels.
- Step 3: Analyze the dialogue — The mother offers a *bureaucratic solution* ("vrk&irk crkvks" = show proof, "[kcj nsus dh dksf'k'k" = I'll pay the bribe/fee) because the system has taught her that care *only works* through procedure.
- Step 4: Analyze the exit — She leaves not from indifference but because the vkneh's "yokfjl" (helplessness) reveals the procedure has *failed* — the system she trusted to mediate her care has no solution. Her exit is the system ejecting her, not her abandoning her son.
- Step 5: Connect to theme — This moment *is* the theme "care corrupted into procedure" in action: maternal love has been so thoroughly proceduralized that when procedure fails, the mother has no non-procedural language left to stay.

ANSWER: The mother does not abandon her son — the bureaucracy abandons her *as a mother*. Her offer to pay ("[kcj nsus dh dksf'k'k") shows she has internalized the system's logic: care = transaction. When the vkneh admits helplessness ("yokfjl"), the procedural channel closes, and she is ejected — not by choice but by structural design. Her exit *enacts* the secondary theme: care, once fully converted to procedure, vanishes when procedure fails.

DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: The story ends with the tree standing ("isM+ ogha dk ogha jgsxk"), the poet dead, and the bureaucrats driving away in jeeps. A critic claims: "The ending is hopeful — nature triumphs over bureaucracy." Using at least two secondary themes, evaluate this claim and explain what the ending *actually* achieves thematically.

COMPETENCY: Critical evaluation of thematic resolution with multi-theme synthesis

STEPS:
- Step 1: Identify the two secondary themes most relevant to the ending — (1) "Nature's indifference to human systems" and (2) "The poet's conscience silenced but not erased."
- Step 2: Test the critic's claim against Theme 1 — The tree stands, yes, but *how*? It stands because the poet *died* protecting it, and the bureaucrats left only when their "compromise" (killing the poet) was rejected. Nature's survival is parasitic on human sacrifice — not triumph but tragic dependency.
- Step 3: Test against Theme 2 — The poet's final words "eq>s ¯"knk j[kks" (keep my honor) and his refusal of the compromise order show his conscience *outlives* his body in the narrative memory — but the story gives no evidence this conscience *changes* the system. The jeeps drive away; the files remain.
- Step 4: Synthesize the actual thematic achievement — The ending refuses both tragedy (total defeat) and hope (victory). It presents a *standoff*: the tree lives, the poet dies, the bureaucracy survives to file another day. This standoff *is* the primary theme — bureaucratic absurdity is not solved, only witnessed.
- Step 5: Articulate the board-level insight — The ending's power lies in its *refusal of closure*. The tree standing is not "nature wins" but "nature endures *despite*." The poet's death is not "conscience fails" but "conscience *cannot be filed*." The bureaucrats leaving is not "system retreats" but "system *moves to the next file*."

ANSWER: The critic's "hopeful" reading collapses the story's thematic complexity into a binary. The ending achieves a *standoff without resolution*: the tree survives at the cost of the poet's life; the bureaucracy survives by moving on. Secondary theme 1 (nature's indifference) shows the tree's survival is amoral, not victorious. Secondary theme 2 (poet as silenced conscience) shows the poet's refusal preserves moral truth *outside* the system — not as institutional change but as narrative witness. The ending thematizes *endurance without redemption* — the most accurate portrait of bureaucratic absurdity.

DIFFICULTY: hard