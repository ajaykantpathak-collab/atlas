## DEFINITION
Imagery is the use of vivid, sensory language that appeals to the five senses (sight, sound, smell, touch, taste) to create mental pictures and evoke physical sensations in the reader. Metaphor is a figure of speech that directly compares two unrelated things by stating one *is* the other, transferring qualities from the source domain to the target domain without using "like" or "as" (unlike simile). In Class 12 Hindi Antra Chapter 11, these devices operate not merely as decoration but as structural elements that encode the author's critique of education, perspective, and life choices.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student can independently identify specific images and metaphors in all three stories of the chapter, explain how each device appeals to a specific sense or transfers specific qualities, and articulate in a structured PEEL paragraph how the device advances the story's central theme or character portrayal, using textual evidence without quoting entire passages.

## SCOPE_BOUNDARY
This node covers imagery (visual, auditory, tactile, olfactory, gustatory) and metaphor (explicit, implied, extended) as they appear in the three prescribed stories: "ckyd cp x;k", "?kM+h osQ iq”ksZ", and "<sys pqu yks". It does NOT cover irony, symbolism, personification, or other figures of speech (those are in node c12_hin_a_cbse_11_009). It does NOT cover plot summary or character sketches (covered in nodes 002, 004, 005).

## WALKTHROUGH
Imagine you are reading "ckyd cp x;k" and suddenly feel the roughness of the boy's torn clothes against your skin, or hear the teacher's harsh voice echoing in a silent classroom — that is imagery at work. Now notice how the author calls the education system a "thfor o`{k" (harsh tree) whose "gjs iÙkksa dk eèkqj eeZj" (sharp thorns) pierce the child — that is a metaphor compressing an entire critique into one image. To begin analysis, first read a short passage aloud and mark every word that triggers a sensory response (underline for visual, circle for auditory, etc.). Then ask: "What two things are being equated here?" and "What qualities from the first are forced onto the second?" The key insight: in this chapter, metaphors are not ornamental; they *are* the argument. The ant's lens, the boy's shadow, the seeds — each is a metaphorical vehicle carrying the author's philosophical payload.

## DIAGNOSTIC_QUESTION_1
Define "imagery" and "metaphor" in your own words, and give one example of each from any story in Chapter 11 without looking at the text.

## DIAGNOSTIC_ANSWER_1
**Correct answer:** Imagery = sensory language creating mental pictures (e.g., visual: "foy{k.k jaxksa dk ifjorZu" — shifting colors on the boy's face in "ckyd cp x;k"; auditory: "LokHkkfod Hkkoksa dh yM+kbZ" — heavy breathing of people). Metaphor = direct comparison without "like/as" (e.g., "thfor o`{k osQ gjs iÙkksa dk eèkqj eeZj" — education system as a harsh tree with sharp thorns).  
**What a wrong answer reveals:** If the student gives a simile ("jaisa") as a metaphor, they confuse the two devices. If they only give visual imagery, they ignore the other four senses. If they cannot cite a chapter-specific example, they have not internalized the text's device usage.

## DIAGNOSTIC_QUESTION_2
In "?kM+h osQ iq”ksZ", the author writes: "èkeZ dk jgL; tkuuk osn'kkL=kK èkekZpk;ks± dk gh dke gSA" (Knowing the world's ways is only the work of cunning politicians). Explain why this statement is *not* a metaphor, and then identify the actual metaphor in the very next sentence: "?kM+h le; crykrh gSA" (The ant kills time).

## DIAGNOSTIC_ANSWER_2
**Correct answer:** The first statement is a literal assertion/opinion, not a comparison between two unlike things. The metaphor is "?kM+h le; crykrh gSA" — time (abstract) is equated with a living being that can be killed (concrete), transferring agency and mortality to time. The ant's limited lifespan becomes a metaphor for human futility in grasping eternity.  
**What a wrong answer reveals:** If the student calls the first sentence a metaphor, they mistake any strong statement for a metaphor. If they miss the personification in "crykrh", they fail to see metaphor operating through verb choice. This tests the boundary between literal language and metaphorical mapping.

## DIAGNOSTIC_QUESTION_3
Apply the "sensory mapping" technique to the opening of "<sys pqu yks": "oSfnd dky esa ¯gnqvksa esa oSQlh ykVjh pyrh Fkh" (A strange life used to flow in ancient times in the villages). List three distinct sensory images evoked by this single sentence and name the sense each appeals to.

## DIAGNOSTIC_ANSWER_3
**Correct answer:**  
1. Visual: "oSfnd dky" (ancient village) — mud houses, narrow lanes, open fields.  
2. Auditory: "ykVjh pyrh Fkh" (life flowed) — implies sounds of daily rhythm: cattle bells, women singing at wells, temple bells.  
3. Tactile/Olfactory combined: "oSQlh ykVjh" (strange life) — the texture of dust, smell of cow dung cakes, cool mud floors.  
**What a wrong answer reveals:** Listing three visual details shows sensory tunnel vision. Confusing "ykVjh pyrh" as only visual misses the kinetic/auditory metaphor of "flowing". This tests multi-sensory reading.

## DIAGNOSTIC_QUESTION_4
Compare the central metaphor in "ckyd cp x;k" (education system as "thfor o`{k") with the central metaphor in "<sys pqu yks" (life choices as "fe^h osQ <sys" — seeds of the field). Analyze how each metaphor's *source domain* (tree vs. seeds) shapes the story's message about agency.

## DIAGNOSTIC_ANSWER_4
**Correct answer:** In "ckyd cp x;k", the tree metaphor positions the system as an imposing, pre-existing structure (the tree) that the child (victim) cannot change; thorns are inevitable — agency is near zero. In "<sys pqu yks", the seed metaphor positions the individual as an active chooser (the farmer) who *selects* a seed; different seeds yield different crops — agency is central. The first metaphor naturalizes oppression; the second metaphor empowers choice.  
**What a wrong answer reveals:** Treating both as "just metaphors about nature" misses the ideological work each does. Failing to link source domain (tree = fixed, hierarchical; seed = potential, selectable) to theme shows superficial analysis.

## DIAGNOSTIC_QUESTION_5
Evaluate this student claim: "The metaphor 'vdM+ck”k lksus' (selfish person) in '<sys pqu yks' is ineffective because selfishness is a human trait, not a physical object like a seed." Defend or refute using the concept of *tenor* and *vehicle*.

## DIAGNOSTIC_ANSWER_5
**Correct answer:** Refute. The claim misunderstands metaphor mechanics. Tenor = selfish person (abstract quality). Vehicle = "lksus" (a concrete noun, but here used as a type/category). The metaphor works by *categorization*: it places the selfish person in a class ("vdM+ck”k lksus") defined by "vius iSQlys dks gh lgh ekuus okyk" (considering only one's own side right). The vehicle is not a physical seed but a *conceptual category* that makes the abstract trait visible and judgeable. Effectiveness lies in this reification.  
**What a wrong answer reveals:** Agreeing with the claim shows a literalist reading — expecting metaphors to only compare physical objects. Missing "tenor/vehicle" terminology indicates lack of technical vocabulary for evaluation.

## DIAGNOSTIC_QUESTION_6
Create a new, original metaphor for the *teacher* in "ckyd cp x;k" that captures his dual role as both oppressor (enforcing the system) and victim (trapped in the same system). Write the metaphor in Hindi and explain the tenor, vehicle, and two transferred qualities.

## DIAGNOSTIC_ANSWER_6
**Sample strong answer:** "vè;kid gS dksbZ Hkh ugha] tks cM+s ykM+ ls uqekb'k esa feLVj gknh osQ dksYgw dh rjg fn[kk tk jgk gS" (The teacher is nothing but a puppet hanging by a thick rope from the ceiling of the system).  
- Tenor: Teacher.  
- Vehicle: Puppet hanging by a rope.  
- Transferred qualities: (1) Lack of autonomy (strings pulled by system), (2) Visible suffering (hanging, twisted) but unable to cut the rope.  
**What a poor answer reveals:** A simile ("teacher *jaise* puppet") fails the "create a metaphor" instruction. A metaphor without explanation of tenor/vehicle/qualities shows mechanical application without understanding. This tests generative mastery.

## COMMON_MISCONCEPTION
Students consistently treat imagery as "only visual description" and metaphor as "any comparison". In this chapter, they miss *tactile imagery* (e.g., "n`f"V Hkwfe ls mBrh ugha Fkh" — not trembling with cold — in "ckyd cp x;k") because they don't associate "cold" with touch. They miss *implied metaphors* like "?kM+h osQ n`"Vkar cgqr rkfy;k¡ fiVokdj fn;k tkrk gSA" (the ant's perspective is greatly enlarged) — where "fiVokdj fn;k" (enlarged/given) implies the perspective is a physical object that can be scaled, but no explicit "is" appears. They also confuse the *author's voice* with *character's voice*: in "?kM+h osQ iq”ksZ", the long philosophical monologue is the author using the ant as a mouthpiece — the ant's "iq”ksZ" *is* the metaphor for limited human epistemology, not just a character's opinion.

## ON_FAILURE
1. **Sensory re-calibration:** Take the first paragraph of "ckyd cp x;k". Read it *only* for non-visual senses. List every tactile, auditory, olfactory word. Verify with a peer.  
2. **Metaphor surgery:** Pick one explicit metaphor (e.g., "thfor o`{k"). Write: Tenor = ____, Vehicle = ____, Ground (shared qualities) = ____. Do this for three metaphors across the three stories.  
3. **Implied metaphor hunt:** In "?kM+h osQ iq”ksZ", find three sentences where a verb or adjective forces a comparison without "is". (Hint: "le; crykrh", "n`"Vkar fiVokdj", "iq”ksZ [kksydj").  
4. **Re-diagnostic:** Retake Diagnostic Questions 2 and 4. If still incorrect, revisit Class 11 node c11_hin_ar_cbse_01_008 for basic definitions, then redo step 2 with teacher feedback.

## BUILDS_ON
Class 11 understanding of basic imagery types and metaphor identification (tenor/vehicle/ground) from node c11_hin_ar_cbse_01_008 and its equivalents across chapters.

## LEADS_TO
Node c12_hin_a_cbse_11_009 (Irony and Symbolism) where metaphors often become symbolic systems, and node c12_hin_a_cbse_11_013 (Critical Thinking) where device analysis feeds interpretation.

## PREREQUISITE_NODE_IDS
c11_hin_ar_cbse_01_008, c12_hin_a_cbse_11_002, c12_hin_a_cbse_11_006, c12_hin_a_cbse_11_003, c12_hin_a_cbse_11_007

## PREREQUISITE_REASONS
c11_hin_ar_cbse_01_008: Provides foundational definitions of imagery and metaphor (tenor, vehicle, ground) and basic identification practice.  
c12_hin_a_cbse_11_002: Plot and narrative structure knowledge is needed to locate *where* devices appear in the story sequence.  
c12_hin_a_cbse_11_006: Primary theme understanding is required because devices serve the theme; analyzing them in isolation loses the "why".
c12_hin_a_cbse_11_003: Imagery/metaphor devices are the tools that build atmosphere — analyzed here, named there  
c12_hin_a_cbse_11_007: Imagery and metaphor are the main vehicles for secondary themes (e.g., "आँखों की गज़ल", "सीस पूँछ").  

## FORWARD_NODE_IDS
c12_hin_a_cbse_11_009, c12_hin_a_cbse_11_013, c12_hin_a_cbse_11_014, c12_hin_a_cbse_11_012, c12_hin_a_cbse_11_015

## FORWARD_REASONS
c12_hin_a_cbse_11_009: Irony and symbolism often extend metaphors (e.g., the "seed" metaphor becomes a symbol of destiny); this node prepares that leap.  
c12_hin_a_cbse_11_013: Critical thinking questions require device analysis as evidence; this node supplies the analytical toolkit.  
c12_hin_a_cbse_11_014: Writing skills tasks (e.g., "write a character sketch using metaphors from the text") directly apply this node's output.
c12_hin_a_cbse_11_012: Imagery/metaphor require inferential interpretation.  
c12_hin_a_cbse_11_015: Imagery/metaphor recognition lets students cite literary evidence.  

## CROSS_SUBJECT_PREREQS
c11_hin_ar_cbse_01_008, c11_hin_ar_cbse_02_008, c11_hin_ar_cbse_03_008
## CROSS_SUBJECT_REASONS
c11_hin_ar_cbse_01_008: Class 11 Antra Chapter 1 "Literary Devices: Imagery and Metaphor" — identical conceptual foundation in a different text, reinforcing transfer.  
c11_hin_ar_cbse_02_008: Chapter 2's device analysis provides comparative examples of how metaphors function in different narrative voices.  
c11_hin_ar_cbse_03_008: Chapter 3's focus on extended metaphor in poetry builds the stamina for sustained metaphor tracking in prose.

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_01_008 -> c12_hin_a_cbse_11_008 -> c12_hin_a_cbse_11_009 (progression from device identification to thematic function to symbolic extension)

## THIS_FORMULA
Metaphor Analysis Protocol: (1) Locate the comparison (explicit "is" or implied verb/adjective). (2) Label Tenor (target) and Vehicle (source). (3) List 2-3 qualities transferred from Vehicle to Tenor. (4) Ask: "What thematic work does this transfer do?" (5) Write PEEL paragraph.

## FORMULA_VARIABLES
Tenor = the subject being described (e.g., education system). Vehicle = the image used to describe it (e.g., harsh tree). Ground = shared qualities (e.g., pre-existing, painful, inescapable). Thematic Work = the idea advanced (e.g., system as naturalized violence).

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
analytical

## CROSS_SUBJECT
c12_history_03_nationalism: The "thfor o`{k" metaphor mirrors colonial education as a imposed structure — analyze how both use organic metaphors to naturalize power.  
c12_psychology_02_cognitive_processes: The ant's limited perspective ("?kM+h osQ iq”ksZ") illustrates bounded rationality / perspective-taking limits — connect metaphor to cognitive bias.  
c12_economics_01_choice_scarcity: The seed-choice metaphor in "<sys pqu yks" maps directly to opportunity cost and production possibility frontier — each seed = allocation decision.
## PREREQ_CONCEPT
Tenor-Vehicle-Ground framework for metaphor analysis and five-sense imagery classification.

## PREREQ_BEFORE
Student must be able to label tenor/vehicle in a simple metaphor (e.g., "Time is a thief") and list five sensory modalities.

## PREREQ_STUCK
If stuck, review Class 11 node c11_hin_ar_cbse_01_008 "Literary Devices: Imagery and Metaphor" — specifically the worked examples on tenor/vehicle identification and sensory word sorts.

## WORKED_EXAMPLE_1
PROBLEM: Analyze the tactile and visual imagery in the description of the boy in "ckyd cp x;k": "mldk eq¡g ihyk Fkk] vk¡[ksa lisQn Fkha] n`f"V Hkwfe ls mBrh ugha Fkh" (His body was thin, hands were like sticks, not trembling with cold). Explain how this imagery establishes his vulnerability *before* he speaks.

STEPS:
- Step 1: Identify the sensory words: "ihyk" (thin — visual + tactile), "lisQn" (sticks — visual simile supporting tactile fragility), "n`f"V Hkwfe ls mBrh ugha" (not trembling with cold — tactile negation implying something else).
- Step 2: Classify each: "ihyk" = visual (gaunt) + tactile (bony); "lisQn" = visual (stick-thin) + tactile (brittle); "mBrh ugha" = tactile (absence of expected shivering).
- Step 3: Determine the combined effect: The boy is physically wasted (visual) and fragile (tactile), yet his stillness is *not* from cold — implying fear or resignation, a psychological state made physical.
- Step 4: Connect to vulnerability: A body this frail, presented before any dialogue, makes the reader anticipate victimhood. The teacher's later violence is foreshadowed by this pre-established physical inequality.
- Step 5: Verify against theme: The education system ("thfor o`{k") destroys the body first — this imagery is the evidence.

REASONING: This example models multi-sensory reading and shows how imagery does character work *before* plot action. The negation ("not trembling with cold") is a sophisticated tactile cue that redirects interpretation from environment to emotion.

ANSWER: The passage uses visual-tactile imagery ("ihyk", "lisQn") to render the boy's emaciation palpable, and a tactile negation ("mBrh ugha") to signal internal terror rather than external cold. Together, they construct a body already broken by the system, making his subsequent silence and flight inevitable — the imagery *is* the critique.

## WORKED_EXAMPLE_2
PROBLEM: In "<sys pqu yks", the farmer offers three seeds: "vdM+ck”k lksus", "yksHkh", "izseh yksgs". Treat each seed as a metaphor for a life philosophy. For each, state the Tenor (philosophy), Vehicle (seed characteristics), and two transferred qualities.

STEPS:
- Step 1: Extract seed descriptions from text: "vdM+ck”k lksus" = selfish, considers only own side right; "yksHkh" = wants pond's beauty, seeks surface pleasure; "izseh yksgs" = wants to become farmer's companion, seeks enduring relationship.
- Step 2: For each, map Tenor and Vehicle:
  - Seed 1: Tenor = Egoistic individualism. Vehicle = Weed/selfish plant (implied by "vdM+ck”k"). Transferred: (a) Chokes others, (b) Short-rooted, unstable.
  - Seed 2: Tenor = Hedonism/aestheticism. Vehicle = Flowering plant by pond ("pk¡nh dh fiVkjh va[kwBk"). Transferred: (a) Beauty-dependent on external conditions (water), (b) Seasonal, not perennial.
  - Seed 3: Tenor = Stewardship/commitment. Vehicle = Crop seed ("izseh yksgs" — chosen by farmer). Transferred: (a) Requires mutual nurturance (farmer + seed), (b) Yields sustenance, not just display.
- Step 3: Note the extended metaphor: The *farmer* is the chooser (agency), the *field* is life context, the *harvest* is outcome.
- Step 4: Analyze thematic ranking: The story privileges Seed 3 — the metaphor structures the moral hierarchy.
- Step 5: Formulate PEEL point: "The three seeds function as an extended metaphor mapping botanical traits onto ethical orientations, with the narrative endorsing the relational, productive choice over the selfish or ornamental."

REASONING: This works because it treats the fable's central conceit as a systematic metaphor set, not isolated comparisons. The agricultural vehicle domain (weed, flower, crop) perfectly maps onto ethical domains (exploitation, display, sustenance).

ANSWER:
1. vdM+ck”k lksus → Tenor: Egoism. Vehicle: Invasive weed. Qualities: Parasitic, destructive.
2. yksHkh → Tenor: Hedonism. Vehicle: Ornamental pond-flower. Qualities: Conditionally beautiful, non-nutritive.
3. izseh yksgs → Tenor: Stewardship. Vehicle: Food crop. Qualities: Reciprocal, life-sustaining.
The metaphor sequence argues that meaningful life requires choosing the "crop" — relational labor over self-display.

## WORKED_EXAMPLE_3
PROBLEM: Compare how "shadow" ("yaw") functions as imagery and metaphor in two moments in "ckyd cp x;k": (a) "lHkk ^okg&okg* djrh lqu jgh Fkh" (The shadow was making 'okg-okg' sound) and (b) "ckyd dh izo`fÙk;ksa dk xyk ?kksVuk" (The boy's shadow reflecting his gestures). Trace the shift from sensory detail to psychological metaphor.

STEPS:
- Step 1: Moment (a) — Auditory imagery: "okg&okg" is onomatopoeic, mimicking the sound of feet dragging or heavy breathing. It is *literal* shadow-sound (perhaps the boy's feet scuffing). Sense: Auditory. Effect: Eerie, childlike, vulnerable.
- Step 2: Moment (b) — Visual imagery + Metaphor: "izo`fÙk;ksa dk xyk ?kksVuk" — the shadow *reflects* (xyk) the gestures. Here "xyk" (reflection/image) triggers the metaphor: Shadow = True Self / Unfiltered Expression. The boy's *body* runs away, but his *shadow* stays, mimicking his aborted resistance.
- Step 3: Identify the metaphor's Tenor/Vehicle: Tenor = Boy's suppressed agency. Vehicle = Shadow (detached, mimetic, ground-bound). Transferred qualities: (a) Inescapability (shadow follows object), (b) Fidelity (shadow copies exactly), (c) Powerlessness (shadow has no independent motion).
- Step 4: Analyze the shift: First, shadow is sensory atmosphere (sound). Second, shadow becomes metaphorical witness — the part of the boy that *could not* run away, that "spoke" the resistance his voice couldn't.
- Step 5: Connect to theme: The education system captures the body (boy runs) but the metaphor says the *self* (shadow) remains trapped, gesturing in protest. This deepens "thfor o`{k" — the thorns catch the shadow too.
- Step 6: Write integrated insight: The auditory imagery of the shadow's sound humanizes the boy; the visual-metaphoric shadow that mirrors his gestures *politicizes* him — even his shadow testifies against the system.

REASONING: This example demonstrates how a single noun ("yaw") carries multiple device layers across a story, and how the shift from imagery to metaphor elevates a detail into thematic evidence. It requires tracking a motif across the narrative arc.

ANSWER: In moment (a), "yaw" operates as auditory imagery ("okg&okg") creating a sensory snapshot of a child's heavy, fearful movement. In moment (b), "yaw" becomes a metaphor for the boy's trapped agency: Tenor = suppressed resistance; Vehicle = shadow mirroring gestures. The shift from sound to reflection transforms the shadow from atmosphere to witness — the system controls the body, but the shadow (true self) stays behind, gesturing defiance. This dual operation makes "yaw" a microcosm of the story's central tension.

## COMPETENCY_QUESTION_1
QUESTION: A Class 12 student writes in a board exam answer: "The author uses the metaphor of a tree to describe the education system. This shows the system is big and strong." Using the Metaphor Analysis Protocol, critique this answer and rewrite it to score full marks (3 marks: identification, analysis, thematic link).

COMPETENCY: Critical analysis of metaphor — moving from vague description to specific quality-transfer and thematic function.

STEPS:
- Step 1: Identify the flaw: "Big and strong" are generic tree qualities, not the *specific* qualities the author transfers (harshness, thorns, piercing). The answer misses "thfor" (harsh) and "eèkqj eeZj" (sharp thorns).
- Step 2: Apply Protocol: Tenor = Education system. Vehicle = Harsh tree (thfor o`{k). Ground = Pre-existing, imposing, inflicting pain on contact (thorns), naturalized as part of landscape.
- Step 3: Thematic link: The metaphor argues the system is not accidentally harmful but *structurally* violent — thorns are inherent to the tree, just as cruelty is inherent to this pedagogy.
- Step 4: Rewrite using PEEL: Point — The "thfor o`{k" metaphor encodes structural violence. Evidence — "gjs iÙkksa dk eèkqj eeZj" (sharp thorns of harsh tree). Explanation — Thorns are not added; they are the tree's nature. Link — Thus the boy's injury is systemic, not personal.

ANSWER: **Critique:** The student answer is vague ("big and strong") and misses the *qualitative* transfer (harshness, piercing) and the *thematic* implication (systemic, inherent violence). It would score 1/3.  
**Rewritten full-mark answer:** "The metaphor 'thfor o`{k' (harsh tree) with its 'eèkqj eeZj' (sharp thorns) transfers the qualities of *inherent, structural violence* onto the education system. Unlike a 'strong tree' which suggests protection, a *harsh* tree's thorns are organic to it — the system's cruelty is not incidental but constitutional. This explains why the boy's flight is the only rational response: one does not negotiate with thorns." (3 marks: precise quality-transfer + thematic consequence).

DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: In "?kM+h osQ iq”ksZ", the author claims "èkeZ dk jgL; tkuuk osn'kkL=kK èkekZpk;ks± dk gh dke gSA" and then spends the story demonstrating the *ant's* perspective. Construct an argument that the entire story is an *extended metaphor* where the ant's lens = human epistemic limitation. Use at least three textual moments (paraphrased) as evidence and explain how each extends the metaphor.

COMPETENCY: Extended metaphor tracking and epistemological interpretation — synthesizing across the whole text.

STEPS:
- Step 1: Thesis: The ant's physical sensory limits (size, lifespan, ground-level view) are a sustained metaphor for human cognitive limits in grasping history, time, and power.
- Step 2: Moment 1 — "èkeZ osQ nl y{k.k og lquk x;k] ukS jlksa osQ mnkgj.k ns x;k" (He heard 9 lectures, gave mosquito examples). Extends metaphor: Just as the ant reduces world history to insect-scale data, humans reduce cosmic time to petty anecdotes.
- Step 3: Moment 2 — "baXySaM osQ jktk vkBosa gsujh dh fL=k;ksa osQ uke vkSj is'kokvksa dk oqQlhZukek lquk x;k" (Heard glorification of emperors). Extends metaphor: The ant's awe at grand names mirrors human susceptibility to nationalist myth-making — scale distortion.
- Step 4: Moment 3 — "?kM+h le; crykrh gSA" / "fiQj nwljs ls iwNus dk VaVk D;ksa\" (Ant kills time / why ask tomorrow?). Extends metaphor: The ant's fatalistic presentism = human refusal to interrogate power structures because "time is short".
- Step 5: Synthesis: The metaphor is *extended* because every ant-statement maps onto a human epistemic vice: reductionism, myth-consumption, presentism. The author *is* the ant — and so are we.
- Step 6: Write compact argument (board-style): "The ant's perspective functions as an extended metaphor for human bounded rationality. Three mappings: (1) Historical reductionism (mosquitoes for empires), (2) Scale illusion (awe at BaXySaM/Gsujh), (3) Temporal fatalism ('?kM+h le; crykrh'). Each ant-utterance exposes a human cognitive trap. The story thus diagnoses our collective 'ant-condition'."

ANSWER: The story is an extended metaphor where the ant's epistemic situation (tiny, short-lived, ground-bound) maps onto the human condition vis-à-vis history and power. Evidence 1: The ant cites mosquitoes as historical proof → humans reduce macro-history to micro-anecdotes. Evidence 2: The ant glorifies emperors by name → humans fetishize rulers without structural critique. Evidence 3: "?kM+h le; crykrh" → humans surrender agency to time-scarcity. The metaphor extends consistently: the ant *is* us when we mistake proximity for truth.

DIFFICULTY: hard