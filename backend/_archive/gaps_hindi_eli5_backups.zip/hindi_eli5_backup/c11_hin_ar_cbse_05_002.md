## DEFINITION
Plot is the logical sequence of causally connected events that constitute the story, while narrative structure is the architectural framework organizing these events—including chronology, perspective, pacing, and temporal manipulation—to shape the reader's experience and convey thematic meaning.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student can independently map the five stages of Freytag's pyramid onto "Xyrk yksgk" with specific textual evidence, explain how narrative ellipsis and third-person omniscient perspective serve the theme of incremental social change, and write a board-style analytical paragraph using the PEEL structure (Point, Evidence, Explanation, Link).

## SCOPE_BOUNDARY
This node covers plot analysis (exposition, rising action, climax, falling action, resolution) and narrative structure (linear chronology with strategic ellipsis, third-person omniscient narration, temporal compression) exclusively for "Xyrk yksgk." It does not cover character analysis, thematic interpretation, or literary devices—those are addressed in subsequent nodes.

## WALKTHROUGH
Imagine you're watching a 20-year movie compressed into 10 minutes—how does the director decide which scenes to show and which to skip? That's exactly what Shivprasad Singh does in "Xyrk yksgk." Begin by listing every major event you remember in chronological order: Eksgu's childhood, the flood, his clerkship, the teacher's death. Now ask: why are years of schooling, job hunting, and city life completely invisible? The answer lies in narrative structure—the author uses *ellipsis* (time gaps) to show that social change for a lower-caste person isn't a smooth curve but a series of rare, visible breakthroughs separated by invisible struggle. The key insight: the story's structure *enacts* its theme—slow, non-linear, measured in crises.

## DIAGNOSTIC_QUESTION_1
What are the five stages of Freytag's pyramid used for plot analysis in senior secondary English?

## DIAGNOSTIC_ANSWER_1
The five stages are: 1) Exposition (establishes setting, characters, status quo), 2) Rising Action (series of conflicts complicating the situation), 3) Climax (turning point of maximum tension where the central conflict is confronted), 4) Falling Action (consequences of the climax unfolding), 5) Resolution (new equilibrium, possibly incomplete). A wrong answer listing only "beginning, middle, end" reveals the student lacks the precise terminology required for board-level structural analysis.

## DIAGNOSTIC_QUESTION_2
In "Xyrk yksgk," the narrative spans ~20 years but shows only 4-5 detailed scenes. Why does the author use such large temporal ellipses (gaps) instead of continuous narration?

## DIAGNOSTIC_ANSWER_2
The ellipses mimic how social mobility actually occurs for marginalized individuals: long periods of invisible endurance punctuated by rare, crisis-driven visibility (flood rescue, job appointment, ritual duty). The gaps force the reader to infer the daily caste humiliations and systemic barriers that the protagonist endures off-stage. A wrong answer like "to keep the story short" shows the student misses the thematic function of structural omission.

## DIAGNOSTIC_QUESTION_3
Map the flood incident (Eksgu saving the teacher's son) onto Freytag's pyramid. Is it rising action, climax, or falling action? Justify with two textual reasons.

## DIAGNOSTIC_ANSWER_3
The flood incident is the **climax**. Step 1: It is the peak physical danger and moral test—Eksgu risks his life across caste lines. Step 2: It forces a public re-evaluation: the teacher's "csar pkcqd" (whip of irony) and the villagers' stunned silence show the caste script breaking. Step 3: All subsequent events (clerkship, teacher's aging, pyre lighting) are consequences of this rupture. A wrong answer placing it in rising action confuses a dramatic event with the structural turning point.

## DIAGNOSTIC_QUESTION_4
The story uses third-person omniscient narration that occasionally enters upper-caste minds (Thakur Saheb, the teacher). How would the critique of caste change if told from Eksgu's first-person perspective?

## DIAGNOSTIC_ANSWER_4
First-person would restrict the critique to Eksgu's subjective experience, losing the irony of seeing upper-caste characters' self-justifying thoughts (e.g., Thakur Saheb's feudal entitlement, the teacher's paternalistic "reform"). Omniscient narration exposes caste as a *systemic mindset* internalized even by allies, not just individual prejudice. A wrong answer focusing only on "emotional connection" reveals inability to analyze narrative perspective as an ideological tool.

## DIAGNOSTIC_QUESTION_5
The resolution shows Eksgu lighting his teacher's funeral pyre. Is this a structurally satisfying resolution? Evaluate considering both the guru-shishya bond and the caste conflict.

## DIAGNOSTIC_ANSWER_5
It is a *bittersweet, structurally deliberate* resolution. It satisfies the personal arc (guru-shishya debt repaid) but deliberately leaves the structural caste conflict unresolved—Eksgu remains a clerk, the village hierarchy persists. This mirrors the author's view (from Before You Read) that change is "slow and incomplete." A wrong answer calling it a "happy ending" shows a superficial reading that ignores the story's critical realism.

## DIAGNOSTIC_QUESTION_6
Write a 80-word alternate opening using a *non-linear frame narrative*: an older Eksgu in a city office recounting his past to a junior colleague. Include one flashback trigger.

## DIAGNOSTIC_ANSWER_6
A competent answer: "The ceiling fan sliced the humid air of the district office. 'Sir, your signature?' the new clerk asked. Eksgu paused, pen hovering over the file—thirty years vanished. The monologue of rain on thatched roofs, the weight of a drowning boy in his arms, Thakur Saheb's voice thick with feudal pride. He signed. 'Eksgu,' he said. 'Not *Eksgu ji*. Just Eksgu.'" A poor answer merely summarizes the plot linearly, showing inability to manipulate narrative structure creatively.

## COMMON_MISCONCEPTION
Students conflate *plot* (what happens) with *narrative structure* (how it's told). They write event summaries ("Eksgu grows up, studies, saves a boy, gets a job, lights a pyre") and call it structural analysis. At Class 11, you must explain *why* the author orders events this way: e.g., starting with childhood (not the clerkship) forces the reader to experience caste oppression as a lived, developmental reality, not a flashback. The structure *is* the argument.

## ON_FAILURE
1. Give the student 10 scrambled events from the story (e.g., "Eksgu gets clerk job," "Flood rescue," "Teacher dies," "Childhood in village," "Eksgu lights pyre," "Thakur Saheb's patronage"). 2. Ask them to reorder chronologically (plot). 3. Then: "Which events are *shown in detail*? Which are *skipped*? Label each detailed scene with Freytag's stage." 4. Finally: "Why does the author show the flood in real-time but skip 10 years of schooling? What does this omission *say* about caste and education?"

## BUILDS_ON
c11_hin_ar_cbse_05_001

## LEADS_TO
c11_hin_ar_cbse_05_003

## PREREQUISITE_NODE_IDS
c11_hin_ar_cbse_05_001
## PREREQUISITE_REASONS
c11_hin_ar_cbse_05_001: Provides essential historical context (caste hierarchy, zamindari, colonial education) without which plot events lack social significance and structural choices appear arbitrary.

## FORWARD_NODE_IDS
c11_hin_ar_cbse_05_003, c11_hin_ar_cbse_05_004, c11_hin_ar_cbse_05_006, c11_hin_ar_cbse_05_005, c11_hin_ar_cbse_05_008, c11_hin_ar_cbse_05_009, c11_hin_ar_cbse_05_010, c11_hin_ar_cbse_05_011, c11_hin_ar_cbse_05_012, c11_hin_ar_cbse_05_013, c11_hin_ar_cbse_05_015, c12_hin_a_cbse_09_002

## FORWARD_REASONS
c11_hin_ar_cbse_05_003: Plot events are anchored in specific settings (village, floodwaters, city office) whose atmosphere the next node analyzes.
c11_hin_ar_cbse_05_004: Protagonist's character arc is revealed *through* plot stages; structural understanding is prerequisite for character analysis.
c11_hin_ar_cbse_05_006: Primary theme (caste, dignity, incremental change) is enacted through plot progression; plot analysis feeds directly into thematic interpretation.
c11_hin_ar_cbse_05_005: Plot knowledge needed to locate each supporting character's key scenes and narrative function.  
c11_hin_ar_cbse_05_008: Plot knowledge needed to locate where specific images appear in the narrative arc.  
c11_hin_ar_cbse_05_009: Plot knowledge needed to locate where ironies occur (e.g., Thakur's promise, Eksgu's death).  
c11_hin_ar_cbse_05_010: The plot and narrative structure node establishes the sequence of events, character relationships, and the two timelines (childhood vs. adulthood) that determine which contextual meaning activates at which point in the story.  
c11_hin_ar_cbse_05_011: Understanding plot/narrative structure is needed to locate where specific grammatical features appear (e.g., cwrs in exposition vs. dialogue).  
c11_hin_ar_cbse_05_012: Plot knowledge provides the factual reservoir from which literal answers are drawn and inferential chains are built.  
c11_hin_ar_cbse_05_013: Understanding plot structure allows identification of key turning points for analysis.  
c11_hin_ar_cbse_05_015: Narrative structure (flashback) is Discussion Question 3 – requires understanding of analepsis.  
c12_hin_a_cbse_09_002: Showed how supporting characters create subplots.  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
none

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_05_001 -> c11_hin_ar_cbse_05_002 -> c11_hin_ar_cbse_05_003

## THIS_FORMULA
N/A - conceptual

## FORMULA_VARIABLES
N/A

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
analytical

## CROSS_SUBJECT
c11_history_colonialism | The story's depiction of shifting rural power (zamindari decline, colonial administration creating clerk jobs) mirrors historical transitions studied in Class 11 History (Colonialism and the Countryside).
c11_sociology_caste | Narrative structure's focus on caste oppression and rare mobility connects to sociological concepts of social stratification, structural mobility, and "Sanskritization" in Class 11 Sociology.

## PREREQ_CONCEPT
Familiarity with basic story elements (beginning, middle, end) and completion of the "Before You Read" context node for "Xyrk yksgk."

## PREREQ_BEFORE
Student must have read the full story "Xyrk yksgk" (textbook pages 55-64) and completed node c11_hin_ar_cbse_05_001.

## PREREQ_STUCK
If stuck, re-read the "Before You Read" section (c11_hin_ar_cbse_05_001) and the end-of-chapter summary questions (textbook page 65) to refresh the event sequence.

## WORKED_EXAMPLE_1
PROBLEM: Identify the five stages of Freytag's pyramid in "Xyrk yksgk" with specific textual events for each stage.

STEPS:
- Step 1: List 8-10 major events in chronological order: (1) Eksgu's childhood in village, caste hierarchy introduced; (2) Thakur Saheb's patronage begins; (3) Teacher (f=kyksd flag) supports Eksgu's education; (4) Flood incident—Eksgu saves teacher's son xaxkjke; (5) Eksgu gets clerkship in city; (6) Years pass, teacher ages; (7) Teacher's death; (8) Eksgu lights funeral pyre.
- Step 2: Define each Freytag stage with analytical criteria: Exposition = status quo establishment; Rising Action = conflict introduction/escalation; Climax = irreversible turning point; Falling Action = consequences; Resolution = new equilibrium.
- Step 3: Map events: Exposition = Event 1 (village caste order, Eksgu's position). Rising Action = Events 2-3 (education as quiet rebellion, tension building). Climax = Event 4 (flood rescue—public rupture of caste script). Falling Action = Events 5-6 (clerkship, teacher's decline—consequences of climax). Resolution = Events 7-8 (pyre lighting—personal closure, structural continuity).
- Step 4: Verify cause-effect chain: Childhood caste position → education opportunity → flood as test of humanity vs. caste → clerkship as delayed fruit → final ritual as personal triumph within unchanged structure.
- Step 5: Write PEEL paragraph for Climax: "The flood rescue (pp. 60-61) functions as the structural climax because it forces a public confrontation between caste prescription and human action. When Eksgu carries the teacher's son through 'vuqHkoh ?kfl;kjksa' (desperate circumstances), the narrator notes 'fdukjs igq¡prs&u&igq¡prs eVeSys ikuh dk jsyk mu rd vk gh igq¡pk'—the floodwaters ignore caste. This irreversible act compels the teacher's ironic 'csar pkcqd' and redefines their relationship."

REASONING: This mapping moves beyond summary by requiring the student to justify each placement with structural criteria and textual evidence, a core board exam skill.

ANSWER:
Exposition: Opening pages—village setting, caste hierarchy, Eksgu's low-caste family, Thakur Saheb's feudal authority.
Rising Action: Teacher's educational patronage; Eksgu's schooling amid caste barriers; growing tension between tradition and change.
Climax: Flood incident (pp. 60-61)—Eksgu saves teacher's son, transcending caste boundaries in a life-death moment.
Falling Action: Eksgu's clerkship in city; teacher's aging; years of physical distance but persistent bond.
Resolution: Teacher's death; Eksgu lights pyre—fulfills guru-shishya duty but caste structure remains (he is still addressed without honorific).

## WORKED_EXAMPLE_2
PROBLEM: Analyze how the narrative structure (linear chronology with three major ellipses) serves the theme of "slow, incomplete social change" in "Xyrk yksgk."

STEPS:
- Step 1: Identify three major temporal ellipses (gaps): Gap A: Childhood (p.56) → Flood years later (p.60) — ~10 years omitted. Gap B: Flood → Clerkship (p.62) — ~5 years omitted. Gap C: Clerkship → Teacher's death (p.63) — ~5 years omitted.
- Step 2: For each gap, list what is *omitted* (daily caste humiliations, exam grind, job search, city adaptation, marriage/family?) and what is *retained* (key turning points).
- Step 3: Analyze the rhetorical effect: The gaps mimic the lived experience of marginalized mobility—progress is invisible day-to-day, visible only in retrospect through crises.
- Step 4: Connect to author's stated intent (from c11_hin_ar_cbse_05_001): "Social change is slow... meaning's depth and structural significance are equally profound."
- Step 5: Write analytical paragraph: "The decade-long ellipsis between Eksgu's childhood and the flood compresses his education into a silent endurance. We never see him studying, facing classroom exclusion, or the teacher's daily quiet advocacy. This structural silence *enacts* the invisibility of lower-caste struggle—the system doesn't record their effort, only their rare breakthroughs. The subsequent gaps reinforce that each victory (job, return, ritual) is isolated, not cumulative."

REASONING: This teaches students to link specific structural devices (ellipsis, scene selection) to thematic argument, moving from "what happens" to "how the telling shapes meaning."

ANSWER: The three ellipses structure the reader's understanding of social mobility as non-linear and crisis-dependent. Gap A (childhood→flood) hides the daily grind of education, making the flood rescue appear as a sudden eruption of suppressed agency. Gap B (flood→clerkship) omits the job search, suggesting employment came from structural shifts (colonial administration) not just merit. Gap C (clerkship→death) skips city life, emphasizing that physical mobility doesn't erase caste identity—the village bond persists. The narrative time (reading time) thus contradicts story time: 20 years in 10 pages teaches that change is measured in rare, visible ruptures, not steady progress.

## WORKED_EXAMPLE_3
PROBLEM: Compare the actual linear-with-gaps structure of "Xyrk yksgk" with a hypothetical non-linear frame narrative (older Eksgu narrating past to city colleague). How would the thematic emphasis shift?

STEPS:
- Step 1: Describe actual structure: Chronological, third-person omniscient, begins with Eksgu as child, ends with pyre lighting.
- Step 2: Describe hypothetical structure: Frame story in city office (present), flashbacks to flood/childhood, returns to frame.
- Step 3: Analyze actual structure's effect: Immerses reader in slow, grinding caste reality; makes flood climax a rupture in routine; centers systemic oppression as ongoing environment.
- Step 4: Analyze hypothetical structure's effect: Creates mystery/suspense; frames story as *memory/legacy*; centers guru-shishya bond and personal gratitude; individualizes caste struggle.
- Step 5: Evaluate against author's purpose (from Before You Read): "Reflects society's stubborn caste hierarchy... meaning's depth and structural significance."
- Step 6: Conclude: Linear structure is superior for *social critique* because it forces reader to endure the timeline with the protagonist. Non-linear would aestheticize suffering into nostalgia.

REASONING: Comparative structural analysis develops the "critical thinking" competency required for 6-mark board questions asking "What would be the effect if...?"

ANSWER: The actual linear structure immerses the reader in the *duration* of caste oppression—we wait through the gaps just as Eksgu waits through the years. The flood climax arrives as a shock because we've experienced the preceding stasis. A non-linear frame starting with the pyre would transform the story into a retrospective tribute, shifting focus from systemic critique (caste as daily environment) to personal redemption (guru-shishya as emotional core). The author's choice of chronology with strategic ellipses makes a sociological argument: caste is a *temporal* structure—it persists across time, and resistance is measured in the rare moments it cracks.

## COMPETENCY_QUESTION_1
QUESTION: The third-person omniscient narrator in "Xyrk yksgk" occasionally enters the minds of upper-caste characters (Thakur Saheb, the teacher). Choose ONE such moment and explain how this narrative choice deepens the story's critique of caste beyond a simple victim-oppressor binary.

COMPETENCY: Narrative perspective analysis and thematic function
STEPS:
- Step 1: Identify a specific moment of upper-caste interiority (e.g., teacher thinking Eksgu will "raise the village's name" p.58, or Thakur Saheb's irritation at Eksgu's education p.57).
- Step 2: Paraphrase the textual evidence precisely.
- Step 3: Explain what this interiority reveals about the character's complicity (e.g., teacher's reformism is paternalistic—Eksgu's success reflects on *village honor*, not Eksgu's dignity).
- Step 4: Connect to broader critique: Caste is maintained not just by overt cruelty but by ingrained mindset even among allies.

ANSWER: When the teacher (f=kyksd flag) thinks "eksgu ,d fnu cM+k vkneh cudj LowQy dk vkSj mudk uke Å¡pk djsxk" (p.58), the narrator reveals that even the sympathetic teacher views Eksgu's potential success as a reflection on *the village's reputation* (upper-caste collective honor), not Eksgu's autonomous dignity. This exposes the subtle paternalism of reformist upper castes: they support mobility only when it validates their benevolence. The narrative choice to enter the teacher's mind shows caste prejudice as an *internalized system* rather than individual malice, deepening the critique structurally.
DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: Using the concept of "narrative ellipsis," explain how the author uses THREE specific time gaps to structure the reader's understanding of social mobility for a lower-caste person in rural India. Your answer must name each gap, state what is omitted, and analyze the cumulative thematic effect.

COMPETENCY: Structural analysis of temporal manipulation and social commentary
STEPS:
- Step 1: Define narrative ellipsis in this context (omission of story-time from discourse-time).
- Step 2: Identify Gap 1 (Childhood→Flood, ~10 years), Gap 2 (Flood→Clerkship, ~5 years), Gap 3 (Clerkship→Teacher's death, ~5 years).
- Step 3: For each gap, state omitted content: Gap 1 omits schooling, daily caste slights, teacher's quiet advocacy. Gap 2 omits exam struggle, job search, migration. Gap 3 omits city life, family, return visits.
- Step 4: Analyze cumulative effect: Mobility appears as isolated breakthroughs (flood, job, ritual) separated by invisible endurance. The structure *enacts* the author's view that change is "slow and incomplete."
- Step 5: Conclude with how this shapes reader empathy: we feel the *weight* of the omitted time.

ANSWER: 
Gap 1 (Childhood to Flood): Omits the decade of schooling—the daily walk past upper-caste wells, the teacher's covert support, the invisible labor of learning. Effect: Education is rendered as silent endurance, not visible achievement.
Gap 2 (Flood to Clerkship): Omits competitive exams, applications, the humiliation of seeking employment as a lower-caste man. Effect: The clerkship appears as a structural gift (colonial administration) not pure merit.
Gap 3 (Clerkship to Death): Omits years of city life—possible promotions, marriage, cultural dislocation. Effect: Physical mobility doesn't dissolve caste identity; the village bond (pyre lighting) remains the defining anchor.
Cumulatively, the ellipses teach that for a lower-caste person, "success" is a series of rare, crisis-driven visibilities (rescue, appointment, ritual) against a backdrop of persistent, unnarrated oppression. The narrative structure *is* the sociological argument.
DIFFICULTY: hard