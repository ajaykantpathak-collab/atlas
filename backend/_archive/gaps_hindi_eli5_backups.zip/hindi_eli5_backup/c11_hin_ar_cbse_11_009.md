## DEFINITION
Irony is a literary device where the intended meaning of words is opposite to their literal meaning, or a situation where the outcome is contrary to what was expected. Symbolism is the use of symbols (objects, characters, figures, colors) to represent abstract ideas or qualities, giving them deeper significance beyond their literal sense.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student can identify at least two instances of irony and two symbols in the poem, explain their function in deepening the theme of longing and alienation, and write a structured analysis using textual evidence.

## SCOPE_BOUNDARY
This node covers irony (verbal, situational, dramatic) and symbolism as used in the poem "Ghar Ki Yaad" from the NCERT Class 11 Hindi Aroh textbook. It does not cover other literary devices like imagery or metaphor (covered in node c11_hin_ar_cbse_11_008) or devices in other chapters.

## WALKTHROUGH
Imagine you are sitting in a new city, far from your childhood home, and you see a house that looks exactly like yours but feels completely unfamiliar. That feeling—being physically present but emotionally absent—is the core irony of this poem. To begin, read the poem aloud and notice the repeated phrase "ghar" (home). Ask: What does the poet mean by "ghar" in each stanza? Is it the brick-and-mortar structure or something else? Then, mark every object that carries emotional weight (the threshold, the mother's lap, the father's voice). The key insight is that the poem uses irony to show that the physical house remains but the "home" has vanished, and symbolism to turn everyday objects into vessels of memory.

## DIAGNOSTIC_QUESTION_1
Define irony and symbolism in your own words, giving one example of each from everyday life (not from the poem).

## DIAGNOSTIC_ANSWER_1
Irony: A situation where the opposite of what is expected happens (e.g., a fire station burning down). Symbolism: An object representing an abstract idea (e.g., a dove representing peace). A wrong answer reveals the student confuses irony with coincidence or thinks symbolism is just decoration, not representation.

## DIAGNOSTIC_QUESTION_2
In the poem, the poet says "मैं यहाँ हूँ, पर यह घर नहीं है" (I am here, but this is not home). Explain why this statement is ironic. What does the poet mean by "घर" in this context?

## DIAGNOSTIC_ANSWER_2
The irony lies in the contrast between physical presence and emotional absence: the poet stands in the same building, yet denies it is his home because the emotional anchors (mother, father, childhood memories) are gone. "घर" here symbolizes emotional belonging, not the physical structure. A wrong answer shows the student takes "घर" literally and misses the emotional disconnect.

## DIAGNOSTIC_QUESTION_3
Identify one symbol in the poem (e.g., the threshold, the mother's lap, the father's voice) and explain how it functions as a symbol of the poet's longing. Write a 3-sentence analysis using the PEEL structure (Point, Evidence, Explanation, Link).

## DIAGNOSTIC_ANSWER_3
Example: The threshold (देहरी) symbolizes the boundary between the secure past and the alien present. Evidence: The poet describes sitting on the threshold, unable to enter. Explanation: It represents the poet's liminal state—physically at the door but emotionally locked out. Link: This deepens the theme of irreversible loss. A wrong answer treats the threshold as just a physical step, missing its symbolic weight.

## DIAGNOSTIC_QUESTION_4
Compare the use of irony in the first stanza (where the poet says the house is far away) with the irony in the last stanza (where he says he is right but this is not home). How does the irony evolve?

## DIAGNOSTIC_ANSWER_4
In the first stanza, irony is spatial: the house is physically distant. In the last stanza, irony becomes existential: the poet is physically present but spiritually absent. The evolution mirrors the poet's journey from physical separation to emotional alienation. A wrong answer treats both as the same type of irony or misses the shift from external to internal.

## DIAGNOSTIC_QUESTION_5
Evaluate the effectiveness of symbolism in conveying the poem's central theme of loss. Could the theme be conveyed equally well without symbols? Justify your answer.

## DIAGNOSTIC_ANSWER_5
Symbols like the threshold, the mother's lap, and the father's voice condense complex emotions into tangible images, making the abstract grief palpable. Without them, the poem would become a direct statement of feeling, losing its evocative power and universality. A wrong answer claims symbols are merely decorative or says the theme would be unchanged, showing a lack of understanding of literary function.

## DIAGNOSTIC_QUESTION_6
Write a four-line stanza (in Hindi) that uses irony and at least one symbol to express the feeling of missing a place that no longer exists. Explain your choices.

## DIAGNOSTIC_ANSWER_6
Example stanza:
"दरवाज़ा खुला है, पर कोई बुलाता नहीं,
दीवारें वही हैं, पर साया नहीं।
मैं खड़ा हूँ जहाँ बचपन बीता था,
वह घर अब बस एक खंडहर है।"
Symbol: The open door (invitation denied) symbolizes inaccessible past. Irony: The house stands but the home is a ruin. A poor answer writes a literal description without irony or symbol, revealing inability to apply the devices creatively.

## COMMON_MISCONCEPTION
Students often think irony in this poem is only about the physical distance from home, missing the deeper existential irony: the poet is physically inside the house but declares it "not home." They also treat symbols (like the mother's lap) as mere descriptive details rather than representations of emotional security. This happens because they focus on literal plot (the poet visiting his old house) and overlook the poem's emotional architecture.

## ON_FAILURE
1. Reread the poem focusing only on the word "घर" in each stanza; note how its meaning shifts from a physical place to an emotional state.
2. List every concrete object mentioned (threshold, lap, voice, letters) and write what abstract feeling each evokes.
3. Practice writing one PEEL paragraph for one symbol, using the template: "The [object] symbolizes [abstract idea] because the poet writes '[quote]'; this shows [explanation]; thus it reinforces the theme of [theme]."
4. Discuss with a peer: "If the poet had said 'I miss my house' directly, what would be lost?" to grasp the function of irony and symbolism.

## BUILDS_ON
This node builds on the understanding of imagery and metaphor (node c11_hin_ar_cbse_11_008) because irony and symbolism often operate through metaphorical language and vivid images.

## LEADS_TO
This node leads to critical thinking and interpretation (node c11_hin_ar_cbse_11_013) where students synthesize all devices to form a holistic analysis of the poem.

## PREREQUISITE_NODE_IDS
c11_hin_ar_cbse_11_001, c11_hin_ar_cbse_11_002, c11_hin_ar_cbse_11_008, c11_hin_ar_cbse_11_006, c11_hin_ar_cbse_11_007

## PREREQUISITE_REASONS
c11_hin_ar_cbse_11_001: Provides context about the poet and the poem's background, essential for understanding the autobiographical irony.
c11_hin_ar_cbse_11_002: Establishes the narrative structure and key events, needed to situate ironic moments in the poem's progression.
c11_hin_ar_cbse_11_008: Covers imagery and metaphor, which are foundational for recognizing how symbols are built through metaphorical language.
c11_hin_ar_cbse_11_006: The irony (home persists only in the one who left) and symbolism (refrain as heartbeat) are the devices that *construct* the primary theme.  
c11_hin_ar_cbse_11_007: Irony and symbolism often operate at the level of secondary themes (e.g., the house symbolizing continuity vs. father's absence); recognizing themes allows detection of these devices.  

## FORWARD_NODE_IDS
c11_hin_ar_cbse_11_010, c11_hin_ar_cbse_11_012, c11_hin_ar_cbse_11_013, c11_hin_ar_cbse_11_014, c11_hin_ar_cbse_11_015, c12_hin_a_cbse_05_009, c12_hin_a_cbse_10_009, c12_hin_a_cbse_11_009, c12_hin_al_cbse_01_009, c12_hin_ar_cbse_09_009, c12_hin_ar_cbse_11_009, c12_hin_ar_cbse_12_009

## FORWARD_REASONS
c11_hin_ar_cbse_11_010: Vocabulary in context relies on understanding symbolic meanings of key words like "देहरी", "अंक", "पाती".
c11_hin_ar_cbse_11_012: Comprehension questions require identifying irony and symbolism to answer inferential questions.
c11_hin_ar_cbse_11_013: Critical thinking and interpretation demand a synthesized analysis of all literary devices, including irony and symbolism.
c11_hin_ar_cbse_11_014: Irony/symbolism knowledge enables higher-order analysis answers.  
c11_hin_ar_cbse_11_015: Irony and symbolism — the father's predicted role-reversal is ironic; the house as living entity is symbolic; discussion demands these labels.  
c12_hin_a_cbse_05_009: अगला तार्किक चरण: Irony is a literary device where the intended meaning of words or a situation is opposite to their l... इस नोड की अवधारणाओं को सीधे उपयोग/विस्तारित करता है।  
c12_hin_a_cbse_10_009: Chapter 11 used irony in satirical writing — shows irony's range beyond biography.  
c12_hin_a_cbse_11_009: Class 11 coverage of irony/symbolism in other texts provides the definitional baseline.  
c12_hin_al_cbse_01_009: Class 11 Antra Chapter 11 Irony and Symbolism node practices exam-style answers.  
c12_hin_ar_cbse_09_009: Links irony to tone shifts.  
c12_hin_ar_cbse_11_009: Class 11 coverage of irony and symbolism gives the terminological and analytical base; Class 12 deepens application to a complex text.  
c12_hin_ar_cbse_12_009: अगला तार्किक चरण: Irony in this story is the contrast between appearance and reality — where the wealthy waste water c... इस नोड की अवधारणाओं को सीधे उपयोग/विस्तारित करता है।  

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_11_001 -> c11_hin_ar_cbse_11_009 -> c11_hin_ar_cbse_11_013

## THIS_FORMULA
N/A - conceptual

## FORMULA_VARIABLES
N/A

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
conceptual

## CROSS_SUBJECT
c11_history_colonialism | The poem's theme of displacement and longing for a lost home mirrors the historical experience of communities uprooted during Partition or migration, where physical structures remain but cultural "home" is lost.
c11_psychology_memory | The symbolic objects (threshold, mother's lap) function as retrieval cues in autobiographical memory, illustrating how sensory triggers evoke emotional past—a concept studied in cognitive psychology.

## PREREQ_CONCEPT
Understanding the difference between literal and figurative meaning, and the ability to identify metaphorical language.

## PREREQ_BEFORE
The student must be able to distinguish between a word's dictionary definition and its contextual connotation in a poem.

## PREREQ_STUCK
Review the concept of metaphor and connotation from node c11_hin_ar_cbse_11_008 (Literary Devices: Imagery and Metaphor).

## WORKED_EXAMPLE_1
PROBLEM: Analyze the irony in the lines where the poet describes the house as "very far" (बहुत दूर) in the first stanza, but later says "I am here" (मैं यहाँ हूँ). Explain how this shift creates situational irony and what it reveals about the poet's state of mind.

STEPS:
- Step 1: Identify the two contrasting statements: Stanza 1 says the house is "बहुत दूर" (very far), while a later stanza says "मैं यहाँ हूँ" (I am here).
- Step 2: Recognize that the first statement reflects emotional/psychological distance (longing makes the home feel distant), while the second reflects physical proximity (the poet has returned).
- Step 3: Define situational irony: an outcome contrary to expectation. The expectation is that returning home eliminates distance; the reality is that physical return does not bridge the emotional gap.
- Step 4: Connect to the poet's state of mind: The irony reveals that the poet's alienation is internal—the loss of loved ones and childhood makes the physical house feel like a stranger's place.
- Step 5: Conclude that the irony underscores the theme: home is not a building but a web of relationships, now broken.

REASONING: This step-by-step moves from textual evidence to device identification to thematic interpretation, modeling the analytical process required for board exams.

ANSWER: The poem opens with the home feeling "very far" due to emotional longing, but later the poet stands physically inside it—yet declares it "not home." This situational irony highlights that physical return cannot restore the emotional home, revealing the poet's irreversible loss and alienation.

## WORKED_EXAMPLE_2
PROBLEM: The threshold (देहरी) appears repeatedly in the poem. Analyze how it functions as a symbol of the poet's liminal state between past and present, belonging and alienation.

STEPS:
- Step 1: Locate references to the threshold: the poet sits on it, cannot cross it, feels it as a boundary.
- Step 2: Define symbolism: an object representing an abstract idea. The threshold is a physical boundary between outside and inside.
- Step 3: Map the physical boundary to an abstract one: the threshold represents the line between the poet's past (inside, childhood, security) and present (outside, adulthood, loss).
- Step 4: Note the poet's action: he sits on the threshold but does not enter, symbolizing his inability to fully reclaim the past or fully accept the present.
- Step 5: Link to theme: The threshold symbolizes the irreversible transition—once crossed, childhood cannot be re-entered; the poet is stuck in between.

REASONING: The steps guide from concrete image to abstract representation to thematic significance, demonstrating how to unpack a symbol systematically.

ANSWER: The threshold symbolizes the poet's liminal existence—physically at the door of his childhood home but emotionally barred from re-entering that world. It marks the boundary between the secure past (mother's lap, father's voice) and the alien present, reinforcing the poem's central theme of irrevocable loss.

## WORKED_EXAMPLE_3
PROBLEM: Combine irony and symbolism: The poet says "यह घर नहीं, यह तो एक खंडहर है" (This is not a home, it is a ruin). Explain how this statement uses verbal irony and the symbol of "ruin" to convey the collapse of emotional security.

STEPS:
- Step 1: Identify verbal irony: the poet calls the standing house a "ruin" (खंडहर), though it is physically intact. The literal meaning (dilapidated building) contradicts the visual reality.
- Step 2: Identify the symbol: "खंडहर" (ruin) symbolizes the poet's inner world—his sense of security, identity, and belonging has crumbled.
- Step 3: Explain the connection: The irony (calling a solid house a ruin) forces the reader to see the house through the poet's eyes—where emotional devastation makes the physical structure feel like a ruin.
- Step 4: Analyze the effect: This fusion of irony and symbolism compresses the poem's message: the home is destroyed not by time or weather but by the absence of love and memory.
- Step 5: Relate to broader theme: The poem suggests that a home is made of relationships; when they vanish, the house becomes a ruin regardless of its bricks.
- Step 6: Write a structured answer using PEEL: Point (verbal irony + symbol), Evidence (quote), Explanation (how they work together), Link (theme of emotional vs physical home).

REASONING: This example requires synthesizing two devices, showing how they amplify each other—a higher-order skill for board-level analysis.

ANSWER: The poet's declaration "यह घर नहीं, यह तो एक खंडहर है" is verbally ironic because the house stands physically intact, yet he labels it a ruin. The word "खंडहर" functions as a symbol of his shattered emotional world. Together, they reveal that the true destruction is not architectural but relational—the home has collapsed because the people who made it a home are gone.

## COMPETENCY_QUESTION_1
QUESTION: In the poem, the father's voice is described as "अभी भी वही रौब" (still the same authority). Yet the poet feels the father's authority is hollow now. Identify the type of irony here and explain how the father's voice serves as a symbol of the changed power dynamics in the family.

COMPETENCY: Literary analysis – identifying and explaining irony and symbolism in conjunction.

STEPS:
- Step 1: Recognize the contrast: the voice sounds the same (authoritative), but the context has changed (father is old, dependent).
- Step 2: Classify the irony: This is dramatic irony—the reader knows the father's authority is diminished, but the voice still projects the old power.
- Step 3: Identify the symbol: The father's voice symbolizes the past patriarchal order and the poet's childhood submission.
- Step 4: Explain the shift: The voice now highlights the father's vulnerability and the poet's new role as caregiver, reversing the power dynamic.
- Step 5: Conclude: The irony and symbol together underscore the theme of time's irreversible transformation of relationships.

ANSWER: The irony is dramatic: the father's voice retains its authoritative tone, but the reality is his dependence and frailty. The voice symbolizes the erstwhile patriarchal authority that once governed the home; its persistence in a weakened body highlights the reversal of roles and the poet's painful awareness of time's passage.

DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: The poem ends with the lines: "मैं यहाँ हूँ, पर यह घर नहीं है / यह तो एक खंडहर है / जहाँ मेरी यादें दफन हैं।" (I am here, but this is not home / It is a ruin / Where my memories are buried.) Evaluate how the poet uses irony and symbolism in these concluding lines to achieve closure. Could the poem have ended effectively without the symbol of "ruin"? Justify your answer.

COMPETENCY: Critical evaluation of literary devices' contribution to thematic closure.

STEPS:
- Step 1: Identify the irony in "मैं यहाँ हूँ, पर यह घर नहीं है" – physical presence vs emotional absence (situational irony).
- Step 2: Identify the symbol "खंडहर" (ruin) representing the poet's internal devastation.
- Step 3: Analyze how they work together: The irony states the problem; the symbol visualizes the emotional reality, making the abstract grief concrete.
- Step 4: Evaluate necessity of the symbol: Without "खंडहर", the ending would be a mere statement of feeling ("I don't feel at home"), lacking the vivid image of a collapsed inner world that "ruin" provides.
- Step 5: Argue that the symbol elevates the personal to the universal—anyone who has lost their emotional anchors can relate to the image of a ruin.

ANSWER: The concluding lines fuse situational irony (presence without belonging) with the symbol of "ruin" (internal collapse). The irony declares the disconnect; the symbol embodies it. Removing "ruin" would strip the ending of its visceral power, reducing a profound existential realization to a flat complaint. The symbol is essential for thematic resonance and universal appeal.

DIFFICULTY: hard