## DEFINITION
Writing Skills based on the chapter refers to the ability to compose structured, evidence-based analytical responses — such as character sketches, theme analyses, critical appreciations of poems, and comparative answers — that demonstrate deep engagement with the text's literary devices, thematic concerns, and socio-cultural context, following the CBSE marking scheme's PEEL (Point-Evidence-Explanation-Link) framework.

## COGNITIVE_LEVEL
apply

## MASTERY_CRITERIA
The student can independently write a 150-200 word analytical answer for any question from this chapter (poem appreciation, character analysis, theme discussion) using the PEEL structure: a clear topic sentence, 2-3 textual evidences with line/stanza references, explanation of literary devices and their effect, and a concluding link to the central idea — all within 8-10 minutes under exam conditions.

## SCOPE_BOUNDARY
This node covers writing analytical answers for the two poems in Chapter 1 (नसोल्सुक का छर्रा and डकुस्ज़फ़िक का छर्रा) — including critical appreciation, theme analysis, imagery/symbolism explanation, and comparative questions. It does NOT cover creative writing (story/diary/letter), speaking/listening tasks, or grammar exercises from the chapter.

## WALKTHROUGH
Imagine you're in the exam hall facing a 6-mark question: "नसोल्सुक के छर्रे में कवि ने स्वतंत्रता की लालसा को कैसे व्यक्त किया है?" Most students freeze — they know the poem but don't know where to start. The secret: don't start writing. Start by annotating. Read the question, underline keywords (स्वतंत्रता, लालसा, व्यक्त किया), then flip to the poem and mark 3-4 lines that directly answer it. Now you have your evidence. Next, group those lines by idea (e.g., physical confinement vs mental freedom). That's your paragraph structure. Write one PEEL paragraph per group. The insight: good answers are not written — they are assembled from annotated evidence.

## DIAGNOSTIC_QUESTION_1
What does the acronym PEEL stand for in the context of writing literature answers for CBSE Class 12 Hindi?

## DIAGNOSTIC_ANSWER_1
PEEL stands for Point, Evidence, Explanation, Link. A wrong answer (e.g., "Paragraph, Example, Explain, Language") reveals the student has heard the term but never internalized the structural logic — they treat it as a mnemonic rather than a writing protocol. This leads to answers that have paragraphs but no analytical progression.

## DIAGNOSTIC_QUESTION_2
A student writes: "नसोल्सुक का छर्रा स्वतंत्रता के बारे में है। नसोल्सुक जेल में है और वह आजाद होना चाहता है। कवि ने बहुत सुंदर शब्दों का प्रयोग किया है।" Identify the three specific structural weaknesses in this answer as per CBSE marking scheme.

## DIAGNOSTIC_ANSWER_2
Weaknesses: (1) No clear Point — the opening is a vague topic statement, not an analytical claim. (2) No Evidence — no line/stanza reference, no quoted phrase, no specific imagery cited. (3) No Explanation — "सुंदर शब्दों का प्रयोग" is empty praise without naming a device (metaphor, symbol, rhythm) or explaining its effect. A wrong diagnosis (e.g., "answer is too short") misses that length is irrelevant; a 50-word PEEL answer scores higher than a 200-word narrative summary.

## DIAGNOSTIC_QUESTION_3
Given the line "eSaus Hkzeo'k thou lafpr] eèkqdfj;ksa dh Hkh[k yqVkbZ" from नसोल्सुक का छर्रा, write a complete PEEL paragraph (4-5 sentences) analyzing how this line establishes the poem's central conflict. Use the structure: Point → Evidence (quote) → Explanation (device + effect) → Link to theme.

## DIAGNOSTIC_ANSWER_3
Point: The opening line establishes the central conflict between spiritual liberation and physical confinement. Evidence: "eSaus Hkzeo'k thou lafpr] eèkqdfj;ksa dh Hkh[k yqVkbZ" (Stanza 1). Explanation: The metaphor "Hkzeo'k thou lafpr" (life offered/sacrificed) frames imprisonment as a deliberate spiritual act, not passive suffering; "eèkqdfj;ksa dh Hkh[k yqVkbZ" uses tactile imagery (breaking chains of sorrow) to transform physical shackles into emotional burdens, suggesting the prisoner's agency. Link: This redefines captivity as a crucible for inner freedom, the poem's core theme. A wrong answer would paraphrase the meaning without naming "metaphor" or "tactile imagery" or connecting to "agency."

## DIAGNOSTIC_QUESTION_4
Compare how the two poems in Chapter 1 (नसोल्सुक का छर्रा and डकुस्ज़फ़िक का छर्रा) use the image of "chain/bondage" (शृंखला/बेड़ी). Write two distinct analytical points with evidence from each poem.

## DIAGNOSTIC_ANSWER_4
Point 1 (नसोल्सुक): Chains are internalized sorrow — "eèkqdfj;ksa dh Hkh[k" (chains of sorrow) and later "vk¡lw&ls fxjrs Fks izfr{k.k" (memories flying from the window) show bondage as psychological; the prisoner breaks them through memory and will. Point 2 (डकुस्ज़फ़िक): Chains are colonial oppression — "mM+rs [kx ftl vksj eq¡g fd,µle> uhM+ fut I;kjk" (where the rising sun kisses the peaks of those high mountains) and "cjlkrh vk¡[kksa osQ cknyµcurs tgk¡ Hkjs djQ.kk ty" (where silver rivers flow between mountain ranges) contrast India's natural freedom with imposed servitude. A wrong answer would list images without distinguishing the metaphorical function: personal vs national, internal vs external.

## DIAGNOSTIC_QUESTION_5
Evaluate this student claim: "दोनों छर्रों में कवि ने एक ही भाव व्यक्त किया है — देशभक्ति।" Is this a valid interpretation? Justify with textual evidence from both poems.

## DIAGNOSTIC_ANSWER_5
Invalid. नसोल्सुक का छर्रा centers on *individual spiritual freedom* within confinement — "nsolsuk dk xhr dfork esa nsolsuk vius thou ij n`f"Vikr djrs gq, vius vuqHkoksa esa vftZr osnuke; {k.kksa dks ;kn dj jgh gSA" (introductory note). The tone is introspective, metaphysical. डकुस्ज़फ़िक का छर्रा is *collective national awakening* — "vjQ.k ;g eèkqe; ns'k gekjk!" addresses the nation directly, invoking geography ("rkejl xHkZ", "fNVdk thou"), history ("uhM+"), and cultural unity. Conflating them erases the distinction between *atma-mukti* (self-liberation) and *rashtra-mukti* (national liberation) that Tulsidas deliberately structures across the two novels. A wrong evaluation would agree superficially because both mention "freedom."

## DIAGNOSTIC_QUESTION_6
Write a 4-line original stanza in Hindi (using Tulsidas's style: simple vocabulary, rhythmic meter, nature imagery) that could serve as a third poem in this series — expressing the *post-independence* realization that political freedom alone is insufficient without inner freedom. Title it.

## DIAGNOSTIC_ANSWER_6
Title: "स्वतंत्रता के बाद"
vjQ.k ;g eèkqe; ns'k gekjk,¡
ytu vkSj Hkh bUdhe gSa pkj dksA
vk¡lw osQ Hkh[k ugha tkrk Ab
eèkqe; gS tc rd vk¡[k vkSj gksA
Criteria: (1) Rhythmic meter matching the poems' गेयता, (2) Nature imagery (पक्षी, नदी), (3) Explicit contrast between political freedom (ns'k) and inner bondage (Hkh[k), (4) Tulsidas's signature simple Sanskritized vocabulary (eèkqe;, vk¡lw, bUdhe). A poor answer would use complex words, lack rhythm, or state the theme bluntly without imagery.

## COMMON_MISCONCEPTION
Students believe "writing skills" means memorizing model answers for each question. They rote-learn a 150-word paragraph for "नसोल्सुक का चरित्र-चित्रण" and reproduce it verbatim. This fails when the question shifts angle (e.g., "नसोल्सुक की मानसिक स्थिति का विश्लेषण कीजिए" vs "नसोल्सुक का चरित्र-चित्रण") because the memorized answer addresses the wrong Point. The misconception stems from treating literature as information-retrieval rather than argument-construction. CBSE's competency-based questions (2024 pattern) explicitly test *application* of understanding to new framings — memorized answers score 1-2/6.

## ON_FAILURE
Step 1: Take the last 3 years' CBSE Hindi Core sample papers. Extract every 5-6 mark question from Chapter 1. Step 2: For each question, write ONLY the Point (topic sentence) and list 2 evidence quotes with stanza numbers — do NOT write full answers. Step 3: Check if your Points directly answer the specific question verb (विश्लेषण कीजिए / तुलना कीजिए / व्याख्या कीजिए). Step 4: Rewrite Points that don't match. Step 5: Now write full PEEL paragraphs for 2 questions. Get feedback from teacher on whether Explanation names devices and Link connects to theme. Repeat until consistent.

## BUILDS_ON
The skill of identifying literary devices and thematic patterns in the two poems (covered in nodes c12_hin_a_cbse_01_008, c12_hin_a_cbse_01_009, c12_hin_a_cbse_01_006, c12_hin_a_cbse_01_007).

## LEADS_TO
The ability to write comparative essays across chapters (e.g., comparing Tulsidas's nationalism with other poets in Antra) and tackle unseen poem appreciation in Board exams.

## PREREQUISITE_NODE_IDS
c12_hin_a_cbse_01_006, c12_hin_a_cbse_01_007, c12_hin_a_cbse_01_008, c12_hin_a_cbse_01_009, c12_hin_a_cbse_01_010, c12_hin_a_cbse_01_012, c12_hin_a_cbse_01_013, c11_hin_ar_cbse_01_014, c11_hin_v_cbse_01_014, c12_hin_a_cbse_01_001, c12_hin_a_cbse_01_011

## PREREQUISITE_REASONS
c12_hin_a_cbse_01_006: Primary theme (freedom) must be understood before writing about it
c12_hin_a_cbse_01_007: Secondary themes (memory, nature, patriotism) provide sub-points for essays
c12_hin_a_cbse_01_008: Imagery/metaphor identification supplies Evidence for PEEL paragraphs
c12_hin_a_cbse_01_009: Irony/symbolism analysis deepens Explanation step
c12_hin_a_cbse_01_010: Key vocabulary (eèkqdfj;ksa, uhM+, lr`".k) enables precise Evidence quoting
c12_hin_a_cbse_01_012: Literal/inferential comprehension ensures accurate textual reference
c12_hin_a_cbse_01_013: Critical thinking provides the analytical depth for Explanation and Link
c11_hin_ar_cbse_01_014: Class 11 Antra writing skills foundation (PEEL structure introduction)
c11_hin_v_cbse_01_014: Class 11 Vitan writing skills foundation (analytical answer practice)
c12_hin_a_cbse_01_001: Writing tasks demand contextual references for authenticity.  
c12_hin_a_cbse_01_011: Writing skills tasks (e.g., analytical paragraphs) demand grammatical precision.  

## FORWARD_NODE_IDS


## FORWARD_REASONS


## CROSS_SUBJECT_PREREQS
c11_hin_ar_cbse_01_014, c11_hin_v_cbse_01_014
## CROSS_SUBJECT_REASONS
c11_hin_ar_cbse_01_014: Class 11 Antra writing skills established the PEEL framework this node advances
c11_hin_v_cbse_01_014: Class 11 Vitan writing skills provided practice in evidence-based analysis for prose/poetry

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_01_014 -> c12_hin_a_cbse_01_014 -> c12_hin_a_cbse_01_015

## THIS_FORMULA
PEEL Structure: Point (analytical claim answering the question verb) → Evidence (quoted phrase + stanza/line ref) → Explanation (device name + effect on meaning/tone) → Link (connects back to theme/question)

## FORMULA_VARIABLES
Point: One-sentence analytical claim directly addressing the question keyword (e.g., "विश्लेषण", "तुलना", "व्याख्या"); Evidence: Exact textual phrase in quotes + location (stanza/line); Explanation: Literary device name (metaphor, symbol, alliteration, etc.) + its specific effect in this context; Link: One sentence connecting this paragraph's idea to the poem's central theme or the question's demand

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
linguistic

## CROSS_SUBJECT
N/A | Both Chapter 1 poems emerge from the 1920s-30s nationalist movement; नसोल्सुक का छर्रा reflects prison literature (like Nehru's letters), डकुस्ज़फ़िक का छर्रा reflects cultural nationalism (like Bankim's Anandamath) — writing answers requires situating texts in this historical context
 N/A | The poems' core tension (individual liberty vs state power) mirrors Article 19-22 debates; analytical answers on "freedom" must distinguish political, personal, and spiritual dimensions as the Constitution does
 N/A | डकुस्ज़फ़िक का छर्रा's geographic imagery ("fNVdk thou", "cjlkrh vk¡[k") invokes India's natural wealth exploited under colonialism — economic history enriches the "national pride" theme analysis
 N/A | The poem's mountain ranges ("uhM+", "rkejl"), rivers ("cjlkrh vk¡[k"), and biodiversity ("gse oqaQHk") map to India's physiographic divisions — geographic literacy strengthens imagery analysis
## PREREQ_CONCEPT
PEEL paragraph structure and literary device identification (metaphor, symbol, imagery, personification) from Class 11 Hindi writing skills nodes.

## PREREQ_BEFORE
Student must be able to: (1) identify the central theme of each poem, (2) locate 3-4 key images per poem with stanza references, (3) name the literary device in any given line, (4) write a basic PEEL paragraph on a familiar topic.

## PREREQ_STUCK
If unable to generate Points for a question, revisit c12_hin_a_cbse_01_006 (Theme: Primary) and c12_hin_a_cbse_01_008 (Imagery and Metaphor) — list 5 theme statements and 5 images, then practice turning each into a Point.

## WORKED_EXAMPLE_1
PROBLEM: Write a 150-word answer for: "नसोल्सुक के छर्रे में 'खिड़की' (window) प्रतीक के रूप में कैसे प्रयुक्त हुई है? समझाइए।" (6 marks)

STEPS:
- Step 1: Identify question verb — "समझाइए" demands Explanation of a symbol's function, not just identification. The Point must state *what* the window symbolizes and *how* it operates.
- Step 2: Scan poem for "खिड़की" / "vk¡lw" references. Found in Stanza 2: "vk¡lw&ls fxjrs Fks izfr{k.k" (memories flying from the window) and Stanza 3 context: "vius vklikl mls lcdh I;klh fuxkgsa gh fn[kkbZ iM+rh gSa" (eyelids try to shut it). Also introductory note: "xhr osQ f'kYi esa jph xbZ ;g dfork osnuk osQ {k.kksa esa euq"; vkSj izÑfr osQ lacaèkksa dks Hkh O;Dr djrh pyrh gSA"
- Step 3: Group evidence by symbolic function: (a) Window as portal between confinement and freedom (memories fly OUT), (b) Window as threshold of consciousness (eyelids try to shut it — resistance to painful memory), (c) Window as frame for the poem's central irony (physical barrier enabling mental escape).
- Step 4: Draft PEEL paragraphs. Para 1: Point — Window symbolizes the porous boundary between physical imprisonment and mental liberty. Evidence — "vk¡lw&ls fxjrs Fks izfr{k.k". Explanation — "fxjrs" (flying) + "izfr{k.k" (memories) personifies memory as birds escaping; the window is not a barrier but a launchpad. Link — Establishes the poem's thesis: freedom is internal.
- Step 5: Para 2: Point — The window also represents the prisoner's vulnerable consciousness. Evidence — "vius vklikl mls lcdh I;klh fuxkgsa gh fn[kkbZ iM+rh gSa". Explanation — "vklikl" (eyelids) as shutters; "I;klh fuxkgsa" (forced shut) shows voluntary suppression of traumatic memory; the window cannot be fully closed — consciousness leaks. Link — Deepens the tragedy: freedom of memory is both salvation and torture.
- Step 6: Concluding Link — The window thus structures the poem's dialectic: confinement ↔ freedom, suppression ↔ expression, body ↔ spirit.

REASONING: The PEEL structure forces each paragraph to make one analytical move. Grouping evidence by symbolic function (portal vs threshold) prevents list-like answers. Naming devices (personification, metaphor) in Explanation meets CBSE's "literary appreciation" criterion. The final Link synthesizes the symbol's multi-layered role.

ANSWER:
नसोल्सुक के छर्रे में 'खिड़की' एक बहु-स्तरीय प्रतीक है जो शारीरिक क़ैद और मानसिक स्वतंत्रता के बीच की पारगम्य सीमा को व्यक्त करता है। पहली दृष्टि में खिड़की स्मृति का प्रस्थान-बिंदु है: "vk¡lw&ls fxjrs Fks izfr{k.k" — यहाँ 'fxjrs' (उड़ना) और 'izfr{k.k' (स्मृतियाँ) का मानवीकरण खिड़की को एक ऐसे द्वार में बदल देता है जहाँ से क़ैदी की चेतना मुक्त होकर अतीत में विचरण करती है। यह भौतिक बाधा को मानसिक सेतु बना देती है। दूसरी ओर, "vius vklikl mls lcdh I;klh fuxkgsa gh fn[kkbZ iM+rh gSa" में पलकें (vklikl) खिड़की के पटों की भाँति कार्य करती हैं जिन्हें क़ैदी जबरन बंद करना चाहता है — यह चेतना की भेद्यता दर्शाता है जहाँ दुःखद स्मृतियाँ अनचाही घुसपैठ करती हैं। विडंबना यह कि वही खिड़की जो क़ैद का प्रतीक है, स्वतंत्रता का एकमात्र साधन भी है। इस प्रकार खिड़की छर्रे के केंद्रीय द्वंद्व — देह की बेड़ी बनाम आत्मा की उड़ान — को संरचित करती है।

## WORKED_EXAMPLE_2
PROBLEM: Write a comparative answer (120 words) for: "दोनों छर्रों में प्रकृति-चित्रण का उद्देश्य भिन्न है। स्पष्ट कीजिए।" (5 marks)

STEPS:
- Step 1: Question verb "स्पष्ट कीजिए" + comparative "भिन्न है" → Need two distinct Points, one per poem, with comparative Link.
- Step 2: नसोल्सुक — Nature as mirror of inner state. Evidence: "NyNy Fks laè;k osQ Jed.k] vk¡lw&ls fxjrs Fks izfr{k.k" (Stanza 2) — "laè;k osQ Jed.k" (wave of memories) uses water imagery for memory's flow; "vk¡lw&ls fxjrs" — window frames nature as memory-trigger. Also "p<+dj esjs thou&jFk ij] izy; py jgk vius iFk ij" (shadow moving on life-path) — nature (shadow) measures inner time.
- Step 3: डकुस्ज़फ़िक — Nature as evidence of national greatness. Evidence: "rkejl xHkZ foHkk ijµukp jgh rjQf'k[kk euksgj" (saffron-like mountain peaks) — geography as cultural symbol; "fNVdk thou gfj;kyh ijµeaxy oqaQoqQe lkjk" (life like blooming garden) — fertility as civilization's proof; "cjlkrh vk¡[kksa osQ cknyµcurs tgk¡ Hkjs djQ.kk ty" (silver rivers) — resources as heritage.
- Step 4: Draft Para 1 (नसोल्सुक): Point — Nature reflects the prisoner's psyche. Evidence — "laè;k osQ Jed.k" / "p<+dj esjs thou&jFk ij". Explanation — Water/shadow imagery externalizes memory's rhythm and time's passage; nature is subjective, internal. Link — Serves introspection.
- Step 5: Draft Para 2 (डकुस्ज़फ़िक): Point — Nature validates the nation's civilizational glory. Evidence — "rkejl xHkZ", "fNVdk thou", "cjlkrh vk¡[k". Explanation — Saffron peaks, blooming gardens, silver rivers are objective geographic marvels claimed as collective inheritance; nature is evidentiary, external. Link — Serves nationalist assertion.
- Step 6: Comparative Link — नसोल्सुक में प्रकृति 'आत्म-दर्शन' का माध्यम है, डकुस्ज़फ़िक में 'राष्ट्र-गौरव' का प्रमाण।

REASONING: Comparative answers fail when students write two separate analyses without a synthesizing Link. The "भिन्न है" demand requires explicit contrast in the final sentence. Using "आत्म-दर्शन" vs "राष्ट्र-गौरव" as conceptual labels makes the distinction sharp and scorable.

ANSWER:
नसोल्सुक के छर्रे में प्रकृति-चित्रण क़ैदी की आंतरिक मनोदशा का प्रतिबिंब है — "NyNy Fks laè;k osQ Jed.k" में लहरों की गति स्मृति के आवेग को, "p<+dj esjs thou&jFk ij izy; py jgk vius iFk ij" में छाया की गति जीवन-पथ पर समय की अनुभूति को व्यक्त करती है। यहाँ प्रकृति व्यक्तिपरक (subjective) है, आत्म-दर्शन का दर्पण। इसके विपरीत डकुस्ज़फ़िक के छर्रे में प्रकृति राष्ट्र की सभ्यतागत महानता का वस्तुनिष्ठ प्रमाण है — "rkejl xHkZ foHkk ij" (केसरिया शिखर), "fNVdk thou gfj;kyh ij" (खिलता बाग़), "cjlkrh vk¡[kksa osQ ckny" (चाँदी-सी नदियाँ) भौगोलिक वैभव को सांस्कृतिक विरासत के रूप में प्रस्तुत करते हैं। नसोल्सुक में प्रकृति 'आत्म-दर्शन' का माध्यम है, डकुस्ज़फ़िक में 'राष्ट्र-गौरव' का प्रमाण — एक अंतर्मुखी, दूसरी बहिर्मुखी।

## WORKED_EXAMPLE_3
PROBLEM: A 6-mark Board question: "तुलसीदास ने दोनों छर्रों में 'स्वतंत्रता' की अवधारणा को कैसे भिन्न-भिन्न स्तरों पर प्रस्तुत किया है? उदाहरण देकर समझाइए।" Write a full structured answer.

STEPS:
- Step 1: Deconstruct "भिन्न-भिन्न स्तरों पर" (at different levels) — requires identifying 3 distinct conceptual levels across the two poems.
- Step 2: Level 1 — Physical/Political (डकुस्ज़फ़िक dominant): Evidence — "vjQ.k ;g eèkqe; ns'k gekjk!", "mM+rs [kx ftl vksj eq¡g fd,", "ygjsa Vdjkrh vuar dhµikdj tgk¡ fdukjk". Explanation — Geographic sovereignty, territorial integrity, resource ownership. Device: Apostrophe (addressing nation), cataloging (geographic features).
- Step 3: Level 2 — Psychological/Spiritual (नसोल्सुक dominant): Evidence — "eSaus Hkzeo'k thou lafpr", "nsolsuk dgrh gSµ¶ân; dh dksey dYiuk lks tk!", "thou esa ftldh laHkkouk ugha] ftls }kj ij vk, gq, ykSVk fn;k Fkk mlosQ fy, iqdkj epkuk D;k". Explanation — Freedom as choice of attitude, dignity in surrender, transcendence of bodily limits. Device: Paradox (freedom in captivity), rhetorical question.
- Step 4: Level 3 — Cultural/Civilizational (both, differently): नसोल्सुक — "vk¡lw&ls fxjrs Fks izfr{k.k" (cultural memory as freedom); डकुस्ज़फ़िक — "gse oqaQHk ys m"kk losjsµHkjrh <qydkrh lq[k esjs" (cultural continuity in nature). Explanation — Memory preserves identity; landscape embodies civilization.
- Step 5: Structure answer: Intro thesis (3 levels). Para 1: Political freedom (डकुस्ज़फ़िक) with 2 evidences. Para 2: Spiritual freedom (नसोल्सुक) with 2 evidences. Para 3: Cultural freedom (both) with 1 evidence each. Conclusion: Tulsidas presents freedom as layered — political prerequisite, spiritual essence, cultural continuum.
- Step 6: Verify each paragraph has PEEL. Check time: 8 minutes.

REASONING: Board 6-mark questions require 3 analytical paragraphs + intro/conclusion. "स्तर" (level) is the organizing principle — not poem-by-poem but concept-by-concept. This cross-poem thematic structure scores higher than sequential summary. The thesis-driven approach shows "critical thinking" competency.

ANSWER:
तुलसीदास ने दोनों छर्रों में स्वतंत्रता को तीन स्तरों पर व्यंजित किया है: राजनीतिक-भौगोलिक, आध्यात्मिक-मनोवैज्ञानिक, और सांस्कृतिक-सभ्यतागत।

राजनीतिक स्तर पर डकुस्ज़फ़िक का छर्रा राष्ट्र की भौगोलिक संप्रभुता को स्वतंत्रता का आधार बनाता है — "vjQ.k ;g eèkqe; ns'k gekjk!" का संबोधन (apostrophe) और "mM+rs [kx ftl vksj eq¡g fd,µle> uhM+ fut I;kjk" / "cjlkrh vk¡[kksa osQ cknyµcurs tgk¡ Hkjs djQ.kk ty" का सूचीबद्ध भू-वर्णन (cataloging) भूमि, पर्वत, नदियों को राष्ट्र-संपत्ति के रूप में स्थापित करता है। यहाँ स्वतंत्रता = क्षेत्रीय अखंडता।

आध्यात्मिक स्तर पर नसोल्सुक का छर्रा देह की बेड़ी के बावजूद आत्मा की मुक्ति दिखाता है — "eSaus Hkzeo'k thou lafpr" का विरोधाभास (paradox) क़ैद को स्वेच्छा से ग्रहण बलिदान बनाता है, और "thou esa ftldh laHkkouk ugha] ftls }kj ij vk, gq, ykSVk fn;k Fkk mlosQ fy, iqdkj epkuk D;k" का प्रश्नवाचक तर्क (rhetorical question) शारीरिक असहायता को नैतिक श्रेष्ठता में बदल देता है। यहाँ स्वतंत्रता = चित्त की अनश्वरता।

सांस्कृतिक स्तर पर दोनों छर्रे मिलते हैं: नसोल्सुक में "vk¡lw&ls fxjrs Fks izfr{k.k" — स्मृति के पंखों पर उड़ती सांस्कृतिक विरासत; डकुस्ज़फ़िक में "gse oqaQHk ys m"kk losjsµHkjrh <qydkrh lq[k esjs" — प्रकृति में निहित सभ्यतागत निरंतरता। तुलसीदास इस प्रकार स्वतंत्रता को सीढ़ीदार बनाते हैं: राजनीतिक पूर्वापेक्षा, आध्यात्मिक सार, सांस्कृतिक निरंतरता।

## COMPETENCY_QUESTION_1
QUESTION: A student writes this answer for "नसोल्सुक के छर्रे का केंद्रीय भाव स्पष्ट कीजिए" (3 marks):
"नसोल्सुक का छर्रा स्वतंत्रता की इच्छा के बारे में है। नसोल्सुक जेल में बंद है और वह बाहर जाना चाहता है। वह खिड़की से चाँद देखता है और पुरानी यादें आती हैं। अंत में वह कहता है कि दुनिया इसे न छीने। यह बहुत मार्मिक छर्रा है।"
Using CBSE marking criteria, identify exactly which competency descriptors this answer FAILS to meet. Then rewrite the answer to meet all descriptors for 3/3 marks.

COMPETENCY: Critical analysis and structured response writing (CBSE Competency: "Analyzes literary texts using evidence and literary terminology")

STEPS:
- Step 1: Identify the 3 competency descriptors for a 3-mark "केंद्रीय भाव" question: (a) Accurate identification of central theme with nuance, (b) Minimum 2 textual evidences with location, (c) Use of at least 1 literary term (device/tone/structure) in explanation.
- Step 2: Map student's answer: "स्वतंत्रता की इच्छा" — vague (misses spiritual dimension); "जेल में बंद... बाहर जाना चाहता है" — plot summary, no evidence quotes; "खिड़की से चाँद देखता है" — factual error (moon not mentioned); "मार्मिक" — empty adjective, no device named. Fails all 3 descriptors.
- Step 3: Rewrite: Point must name the specific freedom (spiritual/attitudinal). Evidence: 2 quotes with stanzas. Explanation: name device (paradox, rhetorical question).
- Step 4: Final Polish for 80-100 words.

ANSWER:
Failed descriptors: (1) Theme identification lacks nuance — reduces spiritual freedom to physical escape. (2) Zero textual evidence — no quoted phrases, no stanza references. (3) Zero literary terminology — "मार्मिक" is affective, not analytical.

Rewritten answer (3/3 marks):
नसोल्सुक के छर्रे का केंद्रीय भाव **शारीरिक क़ैद में भी आत्मिक स्वतंत्रता की अजेयता** है। छर्रा इस विरोधाभास (paradox) पर टिका है: "eSaus Hkzeo'k thou lafpr] eèkqdfj;ksa dh Hkh[k yqVkbZ" (पद 1) — जीवन समर्पित करके भी दुःख की बेड़ियाँ तोड़ी जाती हैं; और "thou esa ftldh laHkkouk ugha] ftls }kj ij vk, gq, ykSVk fn;k Fkk mlosQ fy, iqdkj epkuk D;k" (पद 3) — प्रश्नवाचक शैली (rhetorical question) द्वारा कवि सिद्ध करता है कि जिसे जीवन का आधार (ykSVk) मिला हो, उसके लिए शारीरिक बाधा अर्थहीन है। इस प्रकार स्वतंत्रता बाहरी परिस्थिति नहीं, आंतरिक संकल्प है।

DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: "डकुस्ज़फ़िक का छर्रा" में कवि ने भारत की भौगोलिक विविधता को सांस्कृतिक एकता के रूपक में कैसे बदला है? तीन विशिष्ट भौगोलिक छवियों का चयन करके, उनके प्रतीकात्मक अर्थ की व्याख्या कीजिए। (6 marks)

COMPETENCY: Intertextual synthesis — connecting geographic knowledge to literary symbolism (CBSE Competency: "Integrates cross-disciplinary knowledge in literary analysis")

STEPS:
- Step 1: Select 3 geographic images from the poem with exact phrases: (a) "rkejl xHkZ foHkk ijµukp jgh rjQf'k[kk euksgj" (Himalayas/saffron peaks), (b) "fNVdk thou gfj;kyh ijµeaxy oqaQoqQe lkjk" (Gangetic plains/blooming garden), (c) "cjlkrh vk¡[kksa osQ cknyµcurs tgk¡ Hkjs djQ.kk ty" (rivers/silver streams).
- Step 2: For each, identify: geographic referent → cultural symbol → unifying function.
- Step 3: (a) Himalayas → "rkejl xHkZ" (saffron color) = renunciation/spirituality + "rjQf'k[kk euksgj" (crown jewel) = civilizational pinnacle. Unifies North as spiritual crown.
- Step 4: (b) Plains → "fNVdk thou" (new life) + "gfj;kyh" (garden) = agricultural fertility, cultural flourishing. Unifies heartland as life-giver.
- Step 5: (c) Rivers → "cjlkrh" (silver) = purity/wealth + "Hkjs djQ.kk ty" (flowing rhythm) = civilizational continuity. Unifies geography as circulatory system.
- Step 6: Synthesize: The poem moves North→Heartland→Flow — a geographic synecdoche for the nation's organic unity. Draft 3 PEEL paragraphs + synthesis conclusion.

ANSWER:
डकुस्ज़फ़िक का छर्रा भारत की भौगोलिक विविधता को तीन प्रतीकात्मक छवियों के माध्यम से सांस्कृतिक एकता के जीवंत रूपक में रूपांतरित करता है:

1. **हिमालय — आध्यात्मिक मुकुट**: "rkejl xHkZ foHkk ijµukp jgh rjQf'k[kk euksgj" — केसरिया (rkejl) रंग त्याग और अध्यात्म का प्रतीक है; "rjQf'k[kk euksgj" (मुकुट-मणि) हिमालय को राष्ट्र के मस्तक का रत्न घोषित करता है। भौगोलिक उत्तरी सीमा = सांस्कृतिक शिखर।

2. **गंगा के मैदान — जीवनदायिनी वाटिका**: "fNVdk thou gfj;kyh ijµeaxy oqaQoqQe lkjk" — "fNVdk thou" (नवजीवन) और "gfj;kyh" (खिलता बाग़) कृषि-उर्वरता को सभ्यतागत समृद्धि में बदल देते हैं। मैदान केवल भूभाग नहीं, संस्कृति की पोषक माता हैं।

3. **नदियाँ — सभ्यता की संचार-धमनियाँ**: "cjlkrh vk¡[kksa osQ cknyµcurs tgk¡ Hkjs djQ.kk ty" — चाँदी-सी (cjlkrh) नदियाँ शुद्धता और संपदा दोनों दर्शाती हैं; "Hkjs djQ.kk ty" (लयबद्ध प्रवाह) निरंतरता का बोध कराता है। नदियाँ विविध प्रदेशों को एक सांस्कृतिक परिसंचरण में बाँधती हैं।

उत्तर → हृदय → प्रवाह की यह यात्रा भौगोलिक विभाजन को सांस्कृतिक संश्लेषण में विलीन कर देती है — विविधता में एकता का काव्यात्मक साक्ष्य।

DIFFICULTY: hard