## DEFINITION
Plot and narrative structure refers to the organized sequence of events and the framework used to present a story or biographical account. In this chapter, it involves analyzing how the biographical sketch of Raskhan (रसखान) structures his life chronologically — from birth, spiritual transformation, to literary achievements — and how the poem "हजारी-जइके" (Hajari-Jaike) uses stanzaic progression to build devotional intensity through descriptive imagery rather than linear plot.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student can independently map the biographical sketch into exposition, turning points, and resolution; identify the poem's structural movement from physical description to emotional surrender; and explain how both structures serve the theme of divine love transcending religious boundaries.

## SCOPE_BOUNDARY
Covers only the biographical prose passage on Raskhan's life and the poem "हजारी-जइके" from NCERT Class 12 Antra Chapter 6. Does not cover the second poem "जकेसि! एक कछु फीझ वहोकस" (addressed in later nodes), nor thematic analysis (nodes 006–007), or literary devices (nodes 008–009).

## WALKTHROUGH
Imagine you're asked to explain Raskhan's life journey to a friend who knows nothing about him. You wouldn't just list random facts — you'd start with his birth in a Muslim family, then the pivotal moment hearing Jayadeva's Gita Govinda, then his renunciation, then his literary output. That's narrative structure: the *order* that gives meaning. Now look at the poem — it doesn't tell a story with events. Instead, each stanza builds a layer: first Krishna's beauty (stanza 1), then the poet's helplessness (stanza 2), then total surrender (stanza 3). The structure *is* the argument. Today we'll learn to see that architecture in both texts.

## DIAGNOSTIC_QUESTION_1
What is the chronological sequence of major life events presented in the biographical sketch of Raskhan before he composed "हजारी-जइके"?

## DIAGNOSTIC_ANSWER_1
Correct sequence: Birth in Kannauj (c. 1532) → Early loss of parents → Education in Persian/Arabic → Turning point: hearing Jayadeva's Gita Govinda → Renunciation of worldly life → Settlement in Vrindavan → Composition of devotional works including "हजारी-जइके". A wrong answer (e.g., placing Vrindavan before Gita Govinda) reveals the student cannot distinguish causal turning points from background details — a critical error for board questions on "life journey" (जीवन-यात्रा).

## DIAGNOSTIC_QUESTION_2
The biographical sketch mentions Raskhan learned Persian and Arabic but composed in Braj Bhasha. Why is this structural detail placed *before* his spiritual transformation in the narrative?

## DIAGNOSTIC_ANSWER_2
It establishes his Islamic scholarly background (exposition) to heighten the contrast with his later Krishna-bhakti (turning point). The narrative structure uses this juxtaposition to prove the theme: divine love transcends formal education and religious identity. A student who says "it's just background info" misses the structural purpose — this is a classic board trap where "irrelevant details" are actually thematic scaffolding.

## DIAGNOSTIC_QUESTION_3
In the poem "हजारी-जइके", the first stanza describes Krishna's physical beauty (flute, peacock feather, yellow garment). The second stanza shifts to the poet's internal state ("मैं तुमहीं फत उहक लहकमक"). Identify the structural device enabling this shift and explain its effect.

## DIAGNOSTIC_ANSWER_3
The device is *stanzaic progression* (पद-क्रम विकास) moving from *objective description* (बाह्य सौंदर्य) to *subjective experience* (आंतरिक व्याकुलता). Step 1: Stanza 1 = visual imagery (form). Step 2: Stanza 2 = emotional response (feeling). Step 3: This mirrors the bhakti trajectory: darshan → longs → surrender. A student who only lists images without linking stanza 1 to stanza 2's emotional trigger fails to see structure as meaning-making — a JEE/NEET-style analytical error.

## DIAGNOSTIC_QUESTION_4
Compare the narrative structure of the biographical prose (linear, chronological) with the poem's structure (imagistic, emotional escalation). How does each structure serve its distinct purpose?

## DIAGNOSTIC_ANSWER_4
Prose uses *chronological causality* (event A → event B) to establish historical authenticity and show transformation over time. Poem uses *associative layering* (image → emotion → surrender) to enact the instantaneous, non-linear nature of divine attraction. The prose *proves* the change; the poem *performs* it. A student calling both "linear" or both "descriptive" confuses genre conventions — a fatal error in CBSE competency questions comparing prose vs poetry structure.

## DIAGNOSTIC_QUESTION_5
The biographical sketch ends with Raskhan's major works listed. The poem ends with "लकख हक्क¡ जख इहक फुदव दगम¡ लफकी लफर हककम" (the poet's final surrender). Evaluate which ending provides stronger *narrative closure* for its respective text type.

## DIAGNOSTIC_ANSWER_5
The prose ending (listing works) provides *external closure* — validating the life's output historically. The poem ending ("लकख...") provides *internal closure* — completing the emotional arc from longing to union. Neither is "better"; each fits its genre: biography demands factual completion; lyric demands emotional resolution. A student preferring one as "more complete" imposes novelistic expectations on poetry — a common board misconception when answering "समाप्ति कैसी है?" (How is the ending?).

## DIAGNOSTIC_QUESTION_6
Rewrite the biographical sketch's turning point (hearing Gita Govinda) as a 4-line poem stanza that uses the *same structural shift* as "हजारी-जइके" (external trigger → internal transformation). Use Braj Bhasha vocabulary from the text.

## DIAGNOSTIC_ANSWER_6
Example:  
"जयदेव गीत गुनि कान परे, भयो मन मगन अचानक।  
छाड़ि कुरान नमाज सब, भजत श्याम सुख दायक।  
हजारी जइके रूप निहारि, बौरानो भयो तन-मन।  
रसखान कहत सुनि री झट, प्रेम पथ गयो बन बन॥"  
A poor answer merely summarizes in verse without the *image → emotion* shift. This tests if the student can *transfer* structural logic across genres — the highest Bloom level.

## COMMON_MISCONCEPTION
Students treat the biographical sketch as "just facts" and the poem as "just images," missing that *both are carefully structured narratives*. Specifically, they think the poem has no "plot" because no events occur — but the *emotional arc* (description → longing → surrender) *is* its plot. In board exams, they write "कविता में कथानक नहीं है" (poem has no plot) and lose 2–3 marks. In competitive exams, they fail analogy questions like "stanza 1 : stanza 2 :: exposition : ?" because they don't recognize structural parallelism.

## ON_FAILURE
1. Re-read the biographical sketch *only for sequence markers*: "पहले", "फिर", "बाद में", "तब" — mark each temporal connector. 2. Re-read the poem *stanza by stanza* asking: "What changes from previous stanza?" (Not "what is described?" but "what shifts?"). 3. Complete node c11_hin_ar_cbse_01_002 (Class 11 Plot & Narrative Structure) Exercise 3 on "emotional arc as plot." 4. Re-attempt Diagnostic Question 4 — if still stuck, map both texts on a two-column chart: Left = Prose Event, Right = Poem Emotional Beat.

## BUILDS_ON
Class 11 understanding of linear vs. non-linear narrative (c11_hin_ar_cbse_01_002) and the concept of "emotional trajectory" in lyric poetry (c11_hin_ar_cbse_03_002).

## LEADS_TO
Character Analysis: Protagonist (c12_hin_a_cbse_06_004) — Raskhan's structural choices reveal his character; Setting and Atmosphere (c12_hin_a_cbse_06_003) — Vrindavan's depiction structures the poem's mood.

## PREREQUISITE_NODE_IDS
c12_hin_a_cbse_06_001, c11_hin_ar_cbse_01_002, c11_hin_ar_cbse_03_002, c11_hin_v_cbse_01_002
## PREREQUISITE_REASONS
c12_hin_a_cbse_06_001: Provides historical context (Bhakti movement, syncretism) essential to interpret why the biography structures Raskhan's conversion as a climax.  
c11_hin_ar_cbse_01_002: Introduces Freytag's pyramid (exposition, rising action, climax) used to map the biographical sketch.  
c11_hin_ar_cbse_03_002: Teaches "stanzaic progression" in narrative poems — directly applicable to "हजारी-जइके".  
c11_hin_v_cbse_01_002: Covers Braj Bhasha poetic conventions (doha, chaupai) that structure Raskhan's verse.

## FORWARD_NODE_IDS
c12_hin_a_cbse_06_003, c12_hin_a_cbse_06_004, c12_hin_a_cbse_06_006, c12_hin_a_cbse_06_005, c12_hin_a_cbse_06_012, c12_hin_a_cbse_06_013, c12_hin_a_cbse_06_015

## FORWARD_REASONS
c12_hin_a_cbse_06_003: Narrative structure determines *when* and *how* setting details (Vrindavan, Braj) are revealed — e.g., prose delays Vrindavan until post-conversion; poem embeds it in opening imagery.  
c12_hin_a_cbse_06_004: Raskhan's character is *constructed* by the narrative structure — the biography's turning point defines him; the poem's surrender completes him.  
c12_hin_a_cbse_06_006: Primary theme (divine love transcends boundaries) is *enacted* through structure: biography = social transcendence; poem = emotional transcendence.
c12_hin_a_cbse_06_005: अगला तार्किक चरण: Character analysis of supporting characters involves examining secondary figures in a literary text... इस नोड की अवधारणाओं को सीधे उपयोग/विस्तारित करता है।  
c12_hin_a_cbse_06_012: Plot/narrative structure helps locate where evidence appears in the text.  
c12_hin_a_cbse_06_013: Establishes narrative structure of the excerpts, needed to analyze how form shapes meaning.  
c12_hin_a_cbse_06_015: कथानक संरचना (हजारी प्रसंग, बाल-लीला क्रम) जानने पर ही संवाद/तर्क क्रमबद्ध होंगे।  

## CROSS_SUBJECT_PREREQS
c11_hin_ar_cbse_01_002, c11_hin_ar_cbse_03_002
## CROSS_SUBJECT_REASONS
c11_hin_ar_cbse_01_002: Provides the universal narrative toolkit (exposition, climax, resolution) applied here to a specific historical-biographical text.  
c11_hin_ar_cbse_03_002: Supplies the lyric-specific structural model (image → emotion → insight) that "हजारी-जइके" exemplifies.

## CHAIN_DESCRIPTION
c12_hin_a_cbse_06_001 -> c12_hin_a_cbse_06_002 -> c12_hin_a_cbse_06_003

## THIS_FORMULA
N/A - conceptual

## FORMULA_VARIABLES
N/A

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
analytical

## CROSS_SUBJECT
N/A | The biographical sketch's narrative structure mirrors the historical trajectory of the Bhakti movement: institutional religion (Persian/Arabic learning) → personal revelation (Gita Govinda) → syncretic expression (Braj Bhasha poetry).  
 N/A | Raskhan's life story, as structured in the text, becomes a narrative argument for pluralism — the structure itself (Muslim birth → Hindu devotion → universal poet) enacts the constitutional ideal of unity in diversity.
## PREREQ_CONCEPT
Ability to distinguish *chronological sequence* (prose biography) from *associative/emotional sequence* (lyric poem) as two distinct narrative logics.

## PREREQ_BEFORE
Student must know: (1) Freytag's pyramid for prose narratives, (2) Stanzaic progression patterns in Bhakti poetry (description → feeling → surrender), (3) Basic Braj Bhasha vocabulary to follow structural cues in the poem.

## PREREQ_STUCK
If unable to map structure, revisit c11_hin_ar_cbse_01_002 (prose narrative arcs) and c11_hin_ar_cbse_03_002 (lyric emotional arcs) — specifically the worked example on "Meera's padas."

## WORKED_EXAMPLE_1
PROBLEM: Map the biographical sketch of Raskhan onto Freytag's Pyramid (Exposition, Rising Action, Climax, Falling Action, Resolution). Justify each placement with textual evidence.

STEPS:
- Step 1: Identify Exposition — Birth in Kannauj (c. 1532), Muslim family, early orphanhood, Persian/Arabic education. Text evidence: "रसखान का जन्म कन्नौज के निकट... फारसी-अरबी की शिक्षा."
- Step 2: Identify Rising Action — Worldly pursuits: hunting, painting, music; growing dissatisfaction. Text evidence: "शिकार, चित्रकला, संगीत... मन नहीं लगता था."
- Step 3: Identify Climax — Hearing Jayadeva's Gita Govinda; instantaneous transformation. Text evidence: "जयदेव के गीत गोविंद सुनकर... जीवन बदल गया."
- Step 4: Identify Falling Action — Renunciation, journey to Vrindavan, adoption of Braj Bhasha, discipleship. Text evidence: "गृह त्याग... वृंदावन में बस गए... ब्रजभाषा में रचना."
- Step 5: Identify Resolution — Literary output listed (Rasikapriya, Prem Vatika, etc.); death in Vrindavan. Text evidence: "रसिकप्रिया, प्रेम वाटिका... वृंदावन में ही देहावसान."
- Step 6: Verify — Does the structure show *causal* links? Yes: education → worldly life → Gita Govinda (cause) → renunciation (effect) → works (result).

REASONING: The biography uses classic linear causality to legitimize a radical religious shift — the structure *proves* the transformation was inevitable, not arbitrary. This is exactly what CBSE "जीवन-यात्रा" questions test.

ANSWER: 
Exposition: Birth & early education (Muslim scholarly milieu)  
Rising Action: Worldly engagements + inner void  
Climax: Gita Govinda moment (structural pivot)  
Falling Action: Renunciation, Vrindavan, language shift  
Resolution: Canonical works + death in sacred space  
Each stage has textual anchor — essential for 3-mark board answers.

## WORKED_EXAMPLE_2
PROBLEM: Analyze the three-stanza structure of "हजारी-जइके" as an emotional arc. Identify the governing principle of each stanza and the transition logic between them.

STEPS:
- Step 1: Stanza 1 (हजारी जइके...) — Principle: *Objective enumeration of Krishna's iconography*. Lists 7 physical attributes (flute, peacock feather, yellow garment, etc.). Function: Establishes the *object* of devotion visually.
- Step 2: Stanza 2 (तू ही फत उहक लहकमक...) — Principle: *Subjective collapse of the devotee*. Shift from 3rd-person description to 1st-person address ("तू", "मैं"). Key transition word: "तू" (You) — direct address signals internalization.
- Step 3: Stanza 3 (लकख हक्क¡ जख इहक फुदव...) — Principle: *Total surrender / identity dissolution*. Grammatical shift: finite verbs → infinitives/participles ("लकख", "फुदव") suggesting ongoing state, not action. Final word "लफकी" (lips) → speech silenced in union.
- Step 4: Trace transition logic: Visual → Vocal → Virtual. Stanza 1 = sight (दर्शन), Stanza 2 = speech (संवाद), Stanza 3 = silence (मौन/एकत्व). This mirrors the Bhakti trajectory: दर्शन → संवाद → सायुज्य.
- Step 5: Verify against text — No external events; only internal states escalating. Structure *is* the spiritual argument.

REASONING: Unlike Western lyric which often uses argument (thesis-antithesis-synthesis), Bhakti poetry uses *bhava-vriddhi* (emotional intensification) as structure. Recognizing this prevents misreading the poem as "repetitive" or "plotless."

ANSWER: 
Stanza 1: Iconic inventory (Visual darshan)  
Stanza 2: Personal address & helplessness (Vocal longing)  
Stanza 3: Dissolution into divine (Virtual union)  
Transition logic: Third-person → Second-person → Non-personal (grammaticular mirror of ego-loss)

## WORKED_EXAMPLE_3
PROBLEM: The biographical sketch states Raskhan "कृष्णभक्ति में मुसलमान होकर भी हिंदुओं से बढ़कर मान्य हुए" (though Muslim, accepted more than Hindus in Krishna-bhakti). Show how *both* the prose structure and poem structure jointly argue this claim.

STEPS:
- Step 1: Prose structure argument — Chronology places *Muslim identity first* (exposition), *conversion as climax*, *Hindu recognition as resolution* (works accepted, settled in Vrindavan). The sequence itself argues: identity is not birth but *bhakti*.
- Step 2: Poem structure argument — Stanza 1 uses *Sanskritized Braj* (हजारी, जइके, मोरमुकुट) — Hindu iconography. Stanza 2 uses *Persianate syntax* ("तू ही फत उहक लहकमक" — "fat" = Persian "pat" = then/so). Stanza 3 merges both in *ecstatic Braj*. The linguistic structure enacts syncretism.
- Step 3: Cross-text structural parallel — Prose: Muslim → Hindu (social). Poem: Sanskrit → Persian → Unified (linguistic). Both use *progression from difference to unity* as master structure.
- Step 4: Identify the shared device — *Analepsis* (flashforward in prose: "later accepted"; prolepsis in poem: final surrender anticipated in first glimpse). Structure creates inevitability.
- Step 5: Synthesize — The chapter's *macro-structure* (prose then poem) replicates the micro-structure: biography = social journey; poem = aesthetic journey. Together they prove the claim without stating it directly.

REASONING: Competency questions (CBSE & CUET) often ask "How does the text structure its argument?" This worked example models the *inter-textual structural analysis* required for 5–6 mark answers.

ANSWER: 
The chapter uses a *dual-structure strategy*:  
1. Biographical prose: Social trajectory (Muslim birth → Hindu acceptance) via chronological causality.  
2. Poem: Aesthetic trajectory (Sanskrit iconography → Persian syntax → Unified ecstasy) via linguistic layering.  
Both follow the master pattern: *Difference → Encounter → Transcendence*.  
This structural doubling is the text's central argument — form *performs* content.

## COMPETENCY_QUESTION_1
QUESTION: A student writes: "The biography of Raskhan is just a list of dates and events. The poem has no story — it's only description of Krishna's ornaments." Using your knowledge of narrative structure, write a 150-word rebuttal explaining why this view is analytically incorrect for both texts.

COMPETENCY: Critical interpretation of narrative structure across genres (CBSE Competency: "Analyze and evaluate text structure")

STEPS:
- Step 1: Define narrative structure broadly — not just event-sequence but *meaning-sequence*.
- Step 2: For biography: Identify the *causal chain* (education → emptiness → Gita Govinda → renunciation) — not a list, but a transformation arc.
- Step 3: For poem: Identify *emotional arc* (visual → vocal → virtual) — not static description, but dynamic bhava-vriddhi.
- Step 4: Connect both to the chapter's thesis: structure *enacts* the transcendence of categories.
- Step 5: Conclude: Calling them "list" and "description" confuses *surface features* with *deep structure*.

ANSWER: 
The biography is not a list but a *causal narrative*: each event (orphanhood, Persian learning, hunting) builds the *necessity* of the Gita Govinda moment — the structural climax that reorients the entire life. The poem is not description but *enactment*: stanza 1 presents the divine form (आलम्बन), stanza 2 the devotee's collapse (उद्दीपन), stanza 3 the dissolution of separation (अनुभाव) — the three pillars of rasa theory. Both texts use structure to *prove* that Krishna-bhakti transcends religious birth: the biography socially, the poem aesthetically. Dismissing them as "list" and "description" mistakes the *vehicle* for the *journey*.

DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: The biographical sketch uses a *linear chronological structure* while "हजारी-जइके" uses a *circular emotional structure* (beginning and ending with Krishna's name/form). Design a 4-panel graphic organizer that a Class 12 student could use to compare these structures for board exam revision. Specify what goes in each panel with examples from the text.

COMPETENCY: Visual representation of structural analysis (CBSE Competency: "Organize information using graphic organizers"; CUET: "Compare textual structures")

STEPS:
- Step 1: Panel 1 = "Prose: Linear Causality" — Axis: Time. Nodes: Birth (1532) → Education → Worldly Life → Gita Govinda (Climax) → Vrindavan → Works → Death. Arrow direction: Left to Right.
- Step 2: Panel 2 = "Poem: Circular Intensification" — Axis: Emotional Depth. Center: Krishna (हजारी जइके). Spokes outward: Stanza 1 (Form) → Stanza 2 (Longing) → Stanza 3 (Union) → back to Center. Arrow direction: Outward spiral returning.
- Step 3: Panel 3 = "Shared Master Pattern" — Three-stage template: Stage 1: Encounter (Prose: Gita Govinda / Poem: Visual Darshan). Stage 2: Transformation (Prose: Renunciation / Poem: Helplessness). Stage 3: Integration (Prose: Accepted in Vrindavan / Poem: Surrender).
- Step 4: Panel 4 = "Exam Keywords" — For prose: "क्रमिक विकास" (gradual development), "मोड़" (turning point). For poem: "भाव-वृद्धि" (emotional intensification), "आत्मसमर्पण" (self-surrender). Include one quote each.

ANSWER: 
[Graphic Organizer Description]  
Panel 1 (Linear): Timeline with 6 nodes, climax highlighted at Node 4 (Gita Govinda).  
Panel 2 (Circular): Concentric circles — Center: "हजारी जइके"; Ring 1: "मोरमुकुट... पीतांबर" (Stanza 1); Ring 2: "मैं तुमहीं फत..." (Stanza 2); Ring 3: "लकख हक्क¡..." (Stanza 3); Arrow loops back to center.  
Panel 3 (Convergence): Three-column table mapping Encounter/Transformation/Integration across both texts.  
Panel 4 (Vocabulary): Boxed terms with one-line definitions and textual anchors.  
This organizer enables 3-minute revision of structural comparison — a frequent 4-marker in CBSE sample papers.

DIFFICULTY: hard