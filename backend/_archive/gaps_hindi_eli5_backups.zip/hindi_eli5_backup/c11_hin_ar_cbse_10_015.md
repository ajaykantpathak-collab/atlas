## DEFINITION
Speaking and Listening: Discussion Points refers to the structured oral activity where students collaboratively explore the poem "ehjk" by formulating, articulating, and responding to interpretive questions about its themes (devotion, social reform, caste critique), literary devices (metaphor, symbolism), and the poet's rebellious stance, using textual evidence to build a shared understanding.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student can independently generate at least three distinct discussion points rooted in specific stanzas of the poem, actively listen to peers' interpretations by paraphrasing them before responding, and synthesize a collective insight that connects Kabir's 15th-century social critique to a contemporary issue of inequality or religious hypocrisy.

## SCOPE_BOUNDARY
This node covers only the facilitation and participation in structured academic discussions based on the poem "ehjk" (Kabir) from the Aroh textbook. It does not cover formal debate rules, presentation skills for other chapters, or the writing of analytical essays (covered in node c11_hin_ar_cbse_10_014).

## WALKTHROUGH
Imagine you are in a literature circle where the teacher asks, "Kabir says 'nwèk dh eFkfu;k¡ cM+s izse ls foyks;h' – what does this burning away of rituals mean for us today?" You hesitate because the metaphor feels abstract. Begin by re-reading the specific stanza aloud, noticing the rhythm and the contrast between 'cM+s izse' (big fire) and 'foyks;h' (extinguished). Next, identify the core tension: external rituals versus internal realization. Then, connect this to a modern parallel – perhaps how social media performs religiosity without spiritual depth. Finally, frame this as an open-ended question for the group: "Does Kabir reject all rituals, or only those devoid of love?" This moves you from passive reading to active, evidence-based dialogue.

## DIAGNOSTIC_QUESTION_1
What is the primary purpose of a 'discussion point' in a Class 11 Hindi literature class when analyzing a poem like "ehjk"?

## DIAGNOSTIC_ANSWER_1
A discussion point is an interpretive question or observation grounded in a specific textual detail (e.g., a metaphor, a historical reference in the poem) that invites multiple perspectives and requires evidence-based reasoning, not a factual recall question like "When was Kabir born?" A wrong answer (e.g., "To summarize the poem") reveals the student confuses discussion with retelling, missing the analytical demand of senior secondary oral assessment.

## DIAGNOSTIC_QUESTION_2
In the poem "ehjk", the line 'valqou ty lhafp&lhafp] izse&csfy cks;h' uses juxtaposition. Explain in your own words how this juxtaposition functions as a discussion point about the poet's state of mind.

## DIAGNOSTIC_ANSWER_2
The juxtaposition of 'valqou ty' (calm, cool bank/shore) with 'lhafp&lhafp' (trembling/shaking) and 'izse' (fire) with 'csfy' (shade/coolness) creates a paradox: the poet sits at the tranquil shore of knowledge, yet his body trembles with the fever of separation, feeling fire in the cool shade. This functions as a discussion point because it forces us to debate whether this trembling is fear, ecstatic love, or the physical toll of spiritual longing. A wrong answer (e.g., "It shows the weather is hot and cold") reveals a literal reading that misses the symbolic fusion of opposites central to Nirguna bhakti poetry.

## DIAGNOSTIC_QUESTION_3
Apply the 'Point-Evidence-Explanation-Link' (PEEL) structure to orally respond to this peer's claim: "Kabir only criticizes Hindu rituals in this poem." Use a specific line from the poem as evidence.

## DIAGNOSTIC_ANSWER_3
**Point:** Kabir critiques hollow ritualism across religious boundaries, not just Hindu practices. **Evidence:** The line 'yksdykt vkSj oqQy dh e;kZnk osQ uke ij yxk, x, lkekftd vkSj oSpkfjd caèkuksa dk ges'kk fojksèk fd;kA' (from the prose intro) and the poem's rejection of 'dkfu' (scripture/ritual) and 'f<x' (company/association based on caste) imply a universal critique. **Explanation:** By attacking 'yksdykt' (Hindu) and 'oqQy' (Muslim) orthodoxies equally through the shared metaphor of 'inkoyh' (weaving) as honest labor versus priestly hypocrisy, Kabir targets the *structure* of institutional religion. **Link:** This connects to the poem's central claim 'esjs nnZ dks igpkurk ugha] u 'k=kq u fe=k' – a direct address to the formless Divine bypassing all intermediaries. A wrong answer using only the word 'pandit' or 'mandir' as evidence reveals confirmation bias, ignoring the text's explicit inclusion of 'qazi' and 'mullah' equivalents in the broader chapter context.

## DIAGNOSTIC_QUESTION_4
Analyze how the poet's self-identification as a 'julaha' (weaver) in the introductory prose shapes the *ethos* (credibility/authority) of the speaker in the poem during a discussion on social equality.

## DIAGNOSTIC_ANSWER_4
The prose introduction establishes Kabir's 'julaha' identity as a lived reality: 'mUgksaus yksdykt vkSj oqQy dh e;kZnk osQ uke ij yxk, x, lkekftd vkSj oSpkfjd caèkuksa dk ges'kk fojksèk fd;kA' and 'inkZ izFkk dk Hkh ikyu ugha fd;k'. This biographical grounding transforms the poem's first-person voice ('esjs', 'nkfl ehjka') from a generic devotional persona into a specific subaltern subject speaking *from* the margins. In discussion, this allows us to argue that the line 'laru f<x cSfB&cSfB] yksd&ykt [kks;h' (people recognize me by my low caste/occupation) is not self-pity but a strategic assertion: spiritual authority derives from honest labor ('inkoyh'), not birth. A wrong answer treating the 'julaha' reference as mere background trivia misses how it legitimizes the poem's radical claim that 'eqDrd xs; inksa dh jpuk dhA' (he composed poems of the suffering).

## DIAGNOSTIC_QUESTION_5
Evaluate the effectiveness of using the poem's final line 'rkjks vc eksgh' (now only then [do I call out]) as a closing argument in a discussion about whether Kabir's path is one of *virakta* (renunciation) or *sahaj* (natural/spontaneous integration).

## DIAGNOSTIC_ANSWER_5
The line 'rkjks vc eksgh' (now only then I call out/cry) is highly effective as a closing argument for *sahaj* because the adverb 'vc' (now/then) marks a culmination: the trembling ('lhafp&lhafp'), the fever ('dkf<+'), the burning ('izse') have all been endured *while* living as a householder weaver ('inkoyh'). The cry 'eksgh' is not a retreat from the world but a spontaneous eruption *from* within the world ('laru f<x cSfB&cSfB'). A discussion citing this can conclude that Kabir's 'vuU;rk' (detachment) is internal ('O;FkZ osQ dk;ks± esa O;Lr yksxksa osQ izfr nq[k izdV'), not external renunciation. A wrong answer claiming 'eksgh' proves he finally became a sanyasi ignores the prose clarification 'thou osQ vafre fnuksa esa os }kjdk pyh xb±A' (he lived a householder's life in his later days), revealing a failure to synthesize prose context with poetic closure.

## DIAGNOSTIC_QUESTION_6
Create a discussion prompt for a literature circle that connects the poem's metaphor of weaving ('inkoyh') to a modern gig-economy worker's struggle for dignity, requiring participants to use the word 'sahaj' in their response.

## DIAGNOSTIC_ANSWER_6
**Prompt:** "Kabir calls his poetry 'inkoyh' (weaving) and says 'eqDrd xs; inksa dh jpuk dh' – he wove verses for the suffering. Today, a delivery rider or freelance coder 'weaves' labor into an app's algorithm. How might Kabir's concept of 'sahaj' – the spontaneous, unforced integration of work and worship – challenge the modern fragmentation of 'labor' and 'life'? Respond using 'sahaj' to describe the ideal relationship." A strong response might argue: "For Kabir, weaving was *sahaj* – the rhythm of the loom matched the rhythm of 'Ram' japa; there was no 'shift'. For the gig worker, the algorithm imposes an alien rhythm; reclaiming *sahaj* would mean owning the means of their 'weaving' so labor becomes offering, not extraction." A poor response treats 'sahaj' as a synonym for 'easy' or 'simple', missing its technical meaning in Nirguna bhakti as 'natural state of being where duality dissolves'.

## COMMON_MISCONCEPTION
Students believe a "good discussion" in Hindi literature means agreeing with the teacher's interpretation or the textbook's 'vH;kl' answers. They prepare by memorizing the NCERT exercise solutions (e.g., the answer to 'ehjk Ñ".k dh mikluk fdl :i esa djrh gaS') and repeat them verbatim. This fails because the CBSE ASL (Assessment of Speaking and Listening) rubric explicitly rewards *original thinking*, *disagreement with evidence*, and *building on peers' ideas*. For example, a student saying "Kabir rejects *all* rituals because the textbook says 'bahya aadambar ka virodh'" shuts down discussion; a student saying "But in stanza 2, 'laru f<x cSfB&cSfB' suggests he *uses* his low-caste identity as a ritual of honesty – isn't that a ritual too?" opens it up.

## ON_FAILURE
1. **Interrupt the memorization loop:** Ask the student to put the textbook/guide away. Give them a single printed stanza (e.g., stanza 2: 'valqou ty...') and a blank paper. 2. **Force textual anchoring:** Set a 5-minute timer: "Write three *genuine* questions this stanza raises for *you* – things you actually wonder about, not exam questions. No 'what does X mean?', only 'why does the poet...?' or 'what if...?'." 3. **Model the pivot:** Take one of their questions (e.g., "Why 'lhafp&lhafp' twice?") and think aloud: "The repetition mimics the physical tremor. But 'valqou ty' means cool bank. So the coolness *causes* the trembling? That's paradoxical. Let's ask the group: Is the shore of knowledge actually terrifying?" 4. **Practice the 'Build' move:** In the next literature circle, assign the role "The Builder" – their only job is to start every turn with "Adding to [Peer's name]'s point about [X], I notice in line [Y]..." for 10 minutes.

## BUILDS_ON
This node builds on the student's ability to identify literary devices (c11_hin_ar_cbse_10_008, c11_hin_ar_cbse_10_009), interpret themes (c11_hin_ar_cbse_10_006, c11_hin_ar_cbse_10_007), and comprehend inferential meaning (c11_hin_ar_cbse_10_012) to transform silent reading into collaborative oral analysis.

## LEADS_TO
This node leads to the board examination's Internal Assessment (ASL - Assessment of Speaking and Listening) where students are graded on interactive competence, and to higher-order critical writing in university humanities seminars (c11_hin_ar_cbse_10_014 Writing Skills provides the written counterpart).

## PREREQUISITE_NODE_IDS
c11_hin_ar_cbse_10_001, c11_hin_ar_cbse_10_002, c11_hin_ar_cbse_10_003, c11_hin_ar_cbse_10_004, c11_hin_ar_cbse_10_005, c11_hin_ar_cbse_10_006, c11_hin_ar_cbse_10_007, c11_hin_ar_cbse_10_008, c11_hin_ar_cbse_10_009, c11_hin_ar_cbse_10_010, c11_hin_ar_cbse_10_011, c11_hin_ar_cbse_10_012, c11_hin_ar_cbse_10_013, c11_hin_ar_cbse_10_014
## PREREQUISITE_REASONS
c11_hin_ar_cbse_10_001: Context/background provides the historical setting (Bhakti movement, Kabir's biography) essential for informed discussion.
c11_hin_ar_cbse_10_002: Plot/narrative structure helps students track the poem's progression as an argument, not just verses.
c11_hin_ar_cbse_10_003: Setting/atmosphere analysis enables discussion of the poem's symbolic landscape (e.g., 'valqou ty').
c11_hin_ar_cbse_10_004: Protagonist analysis (Kabir as speaker) is the foundation for discussing voice and persona.
c11_hin_ar_cbse_10_005: Supporting characters (implied Pandit/Qazi/Society) are the foils against which the speaker defines himself.
c11_hin_ar_cbse_10_006: Primary theme (Nirguna Bhakti/social equality) is the central axis of any discussion.
c11_hin_ar_cbse_10_007: Secondary themes (labor, knowledge vs. ritual, body/spirit) provide subsidiary discussion threads.
c11_hin_ar_cbse_10_008: Imagery/metaphor identification (weaving, fire, shade, tremor) supplies the textual evidence for claims.
c11_hin_ar_cbse_10_009: Irony/symbolism analysis (e.g., the weaver as supreme guru) deepens interpretive possibilities.
c11_hin_ar_cbse_10_010: Vocabulary in context (e.g., 'inkoyh', 'sahaj', 'laru', 'csfy') ensures precise semantic grounding.
c11_hin_ar_cbse_10_011: Grammar/language usage (Brajbhasha/Khadi Boli mix, verb forms) aids close reading of tone.
c11_hin_ar_cbse_10_012: Literal/inferential comprehension is the baseline for moving to evaluative discussion.
c11_hin_ar_cbse_10_013: Critical thinking/interpretation skills are the direct precursor to generating discussion points.
c11_hin_ar_cbse_10_014: Writing skills (PEEL structure) transfer directly to oral argument structure.

## FORWARD_NODE_IDS
c12_hin_a_cbse_12_015, c12_hin_al_cbse_02_015, c12_hin_al_cbse_03_015, c12_hin_ar_cbse_10_015, c12_hin_ar_cbse_12_015

## FORWARD_REASONS
This is the terminal node of Chapter 10 (Aroh). It synthesizes all prior analytical nodes into the performative skill of academic discussion, which is assessed summatively in the ASL component of the board exam.
c12_hin_a_cbse_12_015: अगला तार्किक चरण: Speaking and Listening: इस नोड की अवधारणाओं को सीधे उपयोग/विस्तारित करता है।  
c12_hin_al_cbse_02_015: Develops skill in synthesizing multiple viewpoints.  
c12_hin_al_cbse_03_015: Peer feedback and self-assessment habits  
c12_hin_ar_cbse_10_015: Class 11 ASL foundation — basic turn-taking, prompt response — which Class 12 deepens into evidence-based argumentation.  
c12_hin_ar_cbse_12_015: अगला तार्किक चरण: Speaking and Listening: इस नोड की अवधारणाओं को सीधे उपयोग/विस्तारित करता है।  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
No prior class nodes are available for Hindi Aroh in the provided data.

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_10_001 -> c11_hin_ar_cbse_10_002 -> c11_hin_ar_cbse_10_003 -> c11_hin_ar_cbse_10_004 -> c11_hin_ar_cbse_10_005 -> c11_hin_ar_cbse_10_006 -> c11_hin_ar_cbse_10_007 -> c11_hin_ar_cbse_10_008 -> c11_hin_ar_cbse_10_009 -> c11_hin_ar_cbse_10_010 -> c11_hin_ar_cbse_10_011 -> c11_hin_ar_cbse_10_012 -> c11_hin_ar_cbse_10_013 -> c11_hin_ar_cbse_10_014 -> c11_hin_ar_cbse_10_015: The chapter progresses linearly from contextual knowledge through textual analysis to written and finally oral synthesis.

## THIS_FORMULA
Discussion Point = (Textual Anchor + Interpretive Tension + Open-Ended Framing) → Peer Response (Paraphrase + Evidence + Extension/Challenge) → Collective Synthesis

## FORMULA_VARIABLES
- Textual Anchor: A specific line, word, or device from the poem (e.g., "lhafp&lhafp in stanza 2").
- Interpretive Tension: A genuine ambiguity or conflict in meaning (e.g., "Is the trembling fear or love?").
- Open-Ended Framing: A question structure inviting multiple valid answers (e.g., "How might we read...?").
- Peer Response: The mandatory three-move uptake: 1. Paraphrase peer's claim, 2. Cite new/different evidence, 3. Extend or challenge.
- Collective Synthesis: The group's emergent insight that no single student held initially.

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
linguistic

## CROSS_SUBJECT
c11_history_bhakti_movement | The poem "ehjk" is a primary source for the Nirguna Bhakti strand; discussion points on caste critique ('laru f<x cSfB&cSfB') directly illustrate historian's debates on whether Bhakti challenged or reinforced social hierarchy.
c11_civics_constitutional_values | Kabir's rejection of 'yksdykt vkSj oqQy dh e;kZnk' (Hindu and Muslim orthodoxies) and assertion of 'ekurh Fkha fd egkiq#"kksa osQ lkFk laokn' (equality with the great) prefigures Articles 14, 15, 25 of the Indian Constitution; discussion can trace this lineage.
c11_sociology_social_exclusion | The poet's self-location as 'julaha' and the line 'nkfl ehjka yky fxjèkj' (O Kabir, the low-caste weaver) provide a lived-experience case study for sociological concepts of stigma, untouchability, and resistance through cultural production.

## PREREQ_CONCEPT
The student must understand that Kabir's "inkoyh" (weaving) is an extended metaphor for poetic composition as honest labor, contrasting with the "parasitic" labor of the priestly class.

## PREREQ_BEFORE
Before starting this node, the student must have completed a close reading of the poem "ehjk" (all stanzas) and the introductory prose biography, and be able to identify at least three metaphors and the central theme of Nirguna Bhakti.

## PREREQ_STUCK
If stuck, review the metaphor of 'inkoyh' (weaving) in node c11_hin_ar_cbse_10_008 (Literary Devices: Imagery and Metaphor) and the theme of social equality in node c11_hin_ar_cbse_10_006 (Theme: Primary Theme).

## WORKED_EXAMPLE_1
PROBLEM: A student wants to initiate a discussion on the paradox in Stanza 2: "valqou ty lhafp&lhafp] izse&csfy cks;h" (On the cool bank, trembling; fire and shade together). They don't know how to frame it as an open question that invites debate rather than a single answer.
STEPS:
- Step 1: Identify the core textual anchor – the juxtaposition of 'valqou ty' (cool bank/shore of knowledge) and 'lhafp&lhafp' (trembling/shivering) in the same breath.
- Step 2: Identify the interpretive tension – usually knowledge brings peace ('shanti'), but here the shore of knowledge ('valqou ty') induces a feverish tremor ('lhafp&lhafp'). Why?
- Step 3: Formulate two competing hypotheses from the text: Hypothesis A (Virag): The tremor is the pain of detachment from the world. Hypothesis B (Prema/Viraha): The tremor is the intensity of love/separation from the Divine ('izse' = fire of love in 'csfy' = shade of peace).
- Step 4: Frame an open-ended prompt using the PEEL-oral structure: "Point: This stanza presents a paradox. Evidence: 'valqou ty' vs 'lhafp&lhafp'. Explanation: Does the 'cool bank' represent the calm of Brahma-jnana which makes the body's attachment tremble, OR the fire of viraha burning in the shade of union? Link: Let's look at the next line 'vc r csfy iSQfy xbZ' – the shade *became* fire. Which reading does that support?"
- Step 5: Anticipate peer responses and plan the 'Build' move: If a peer says "It's fear of death," respond: "Adding to that, the prose says 'Khu ls gh muosQ eu esa Ñ".k HkfDr dh Hkkouk tUe ys pqdh' – the longing was born in childhood. So is this tremor ancient, not new?"
REASONING: This models the senior-secondary skill of holding multiple valid interpretations (polyvalence) characteristic of Bhakti poetry, rather than hunting for the "correct" textbook answer. The step-by-step moves from textual micro-detail to macro-theme to dialogic framing.
ANSWER: The final discussion prompt: "Dosto, doosre band mein 'valqou ty lhafp&lhafp' ka virodh hai – gyaan ka thanda kinara hoke bhi shareer kaanp kyun raha hai? Kya ye virakti ka dard hai ya prem ka bukhaar? Agli line 'vc r csfy iSQfy xbZ' kuchh aur hi sanket deti hai. Aap kya sochte hain?" (Friends, in stanza 2 there is a contradiction – on the cool shore of knowledge, why does the body tremble? Is it pain of detachment or fever of love? The next line 'then the shade became fire' signals something else. What do you think?)

## WORKED_EXAMPLE_2
PROBLEM: During a literature circle, a peer asserts: "Kabir is arrogant when he says 'esjs nnZ dks igpkurk ugha] u 'k=kq u fe=k' (No one recognizes my worth, neither male nor female)." The student wants to challenge this respectfully using textual evidence.
STEPS:
- Step 1: Paraphrase the peer's claim to show listening: "So you're reading 'igpkurk ugha' as Kabir boasting about his unrecognized greatness?"
- Step 2: Locate the precise textual context – this is the poem's closing declaration of radical singularity ('vuU;rk').
- Step 3: Retrieve counter-evidence from the prose introduction: "The text says 'ehjk Reprint 2026-27... ehjk us Ñ".k ls viuh vuU;rk O;Dr dh gS rFkk O;FkZ osQ dk;ks± esa O;Lr yksxksa osQ izfr nq[k izdV fd;k gSA' (Kabir expressed his distinctness from the Divine and showed indifference towards worldly people)."
- Step 4: Retrieve counter-evidence from the poem itself: "Stanza 1 says 'laru f<x cSfB&cSfB] yksd&ykt [kks;h' – people know me only by my low caste/work. The 'nnZ' (worth/value) unrecognized is precisely his *spiritual* identity as a bhakta, which the world ignores because it sees only 'julaha'."
- Step 5: Synthesize the challenge: "Actually, the line follows 'laru f<x...' – the world recognizes him *only* as low-caste ('f<x'), never as the knower of Ram ('nnZ'). So 'igpkurk ugha' isn't arrogance; it's a diagnostic of social blindness. The 'u 'k=kq u fe=k' (neither male nor female) further rejects *all* social categories. It's the ultimate equality claim."
- Step 6: Frame as a question to the group: "If Kabir refuses *both* 'kaka' (male/status) and 'kaki' (female/status), what space opens up for the 'julaha'? Is that arrogance or liberation?"
REASONING: This demonstrates the "Challenge with Evidence" move essential for ASL's 'Interactive Competence' band. It uses the prose intro (often ignored) to gloss the poem, and flips a deficit reading (arrogance) into a structural reading (critique of categorization).
ANSWER: Oral response script: "Adding to your point – I hear you saying it sounds like ego. But look at the line just before: 'laru f<x cSfB&cSfB' – the world *does* recognize him, but only as 'f<x' (low caste). The 'nnZ' (true worth) he says is unrecognized is his identity as a bhakta. And 'u 'k=kq u fe=k' rejects gender/caste labels entirely. So isn't he saying: 'You don't see *me*, you only see my label'? That's not arrogance, that's a demand to be seen beyond caste. What does the group think?"

## WORKED_EXAMPLE_3
PROBLEM: The teacher assigns a group discussion: "Connect Kabir's critique of ritual ('dkfu', 'f<x', 'e;kZnk') to ONE contemporary issue of performative morality. The group must reach a consensus statement in 10 minutes." The student is the facilitator.
STEPS:
- Step 1 (Setting the frame): "Let's use the 'Text-to-World' bridge. Our textual anchors: Prose says 'yksdykt vkSj oqQy dh e;kZnk osQ uke ij... caèkuksa dk fojksèk fd;k' (exposed hypocrisies in name of Hindu/Muslim dharma). Poem rejects 'dkfu' (scriptural ritual) and 'f<x' (caste association)."
- Step 2 (Brainstorming modern parallels): "Round-robin: Each person names one modern 'e;kZnk' (observance/ritual) that looks like 'dkfu' (hollow ritual). Examples: Corporate 'value statements' vs labor practices; Social media 'activism' (posting) vs groundwork; Religious processions vs daily ethics."
- Step 3 (Filtering through Kabir's lens): "Now test each against Kabir's criteria: Does it separate 'O;FkZ' (action/work) from 'O;Lr' (real/essential)? Kabir says 'inkoyh' (weaving/labor) *is* his sadhana. So the test: Is the modern ritual *integrated* with honest labor ('sahaj') or *separated* from it?"
- Step 4 (Deepening one case): "Take 'Corporate Diversity Training' (modern e;kZnk). Evidence: Often a 2-hour module (dkfu) while hiring/pay gaps persist (virodh). Kabir's 'eqDrd xs; inksa dh jpuk' (weaving for the suffering) asks: Does this ritual serve the sufferer or the institution?"
- Step 5 (Synthesizing consensus): "Consensus statement draft: 'Like Kabir's 'pandit' who reads Vedas but misses Ram, modern performative morality (e.g., mandatory diversity workshops without structural equity) substitutes ritual utterance ('dkfu') for the 'inkoyh' of daily justice. Kabir's 'sahaj' demands the integration of word and work.'"
- Step 6 (Meta-reflection for ASL): "As facilitator, I note we used: 1. Textual anchor (prose + poem), 2. Analytical lens (sahaj = integration), 3. Specific modern instance, 4. Consensus language ('We agree...'). This mirrors the ASL 'Problem Solving' task format."
REASONING: This worked example models the highest-order speaking skill: facilitating a structured, evidence-based, time-bound group discussion that bridges 15th-century text and 21st-century life – exactly the "Critical Thinking & Problem Solving" competency CBSE assesses in ASL.
ANSWER: Facilitator's closing summary: "Mitron, humne tay kiya ki Kabir ka 'dkfu' aaj ke 'performative rituals' jaise – corporate diversity training bina policy change, ya social media par 'thoughts and prayers' bina donation – hain. Kyunki Kabir ke liye 'inkoyh' (kaam) hi 'ibadat' thi, toh 'sahaj' ka matlab hai: ritual aur reality ka judna. Hamara consensus: 'Jahan ritual kaam se alag hota hai, wahan Kabir ka virodh laagu hota hai.'"

## COMPETENCY_QUESTION_1
QUESTION: You are in a literature circle discussing the line "nfèk efFk ?k`r dkf<+ fy;ks] Mkfj n;h Nks;h" (The fire of separation burns the body; the mind remains absorbed in the Beloved). A peer argues this proves Kabir advocates *ascetic self-mortification* (body hatred). Using the poem's stanza 1 ("laru f<x cSfB&cSfB] yksd&ykt [kks;h") and the prose introduction ("thou osQ vafre fnuksa esa os }kjdk pyh xb±A"), construct a spoken rebuttal that reframes the body as the *site* of devotion, not its obstacle. Use the term 'sahaj' in your response.
COMPETENCY: Critical Interpretation & Oral Argumentation
STEPS:
- Step 1: Acknowledge the peer's reading (valid surface reading: body burns, mind stays).
- Step 2: Introduce counter-evidence from Stanza 1: The speaker identifies as 'laru f<x' (low caste/body) and 'yksd&ykt [kks;h' (known by common people) – the body *in the world* is the starting point.
- Step 3: Introduce prose evidence: Kabir lived as a householder weaver ('}kjdk pyh') till late life – he did not abandon the body.
- Step 4: Define 'sahaj' using the poem: 'izse&csfy cks;h' (fire and shade together) – the body feels the fire (virah) *while* the mind rests in shade (union); they coexist naturally.
- Step 5: Conclude: The burning ('dkf<+') is not self-inflicted mortification but the *inevitable friction* of love in a body that lives honestly ('inkoyh'). The body is the loom.
ANSWER: "I hear you – 'nfèk efFk ?k`r dkf<+ fy;ks' does sound like body-hate. But look at the first line: 'laru f<x cSfB&cSfB' – he *starts* from his embodied identity as a low-caste weaver. And the prose says he lived as a householder ('}kjdk pyh') till the end. So the body isn't the enemy; it's the loom. 'Sahaj' means the fire of separation ('izse') and the shade of union ('csfy') happen *together* in this very body ('cks;h'). The burning isn't something he *does* to the body; it's what love *does* in the body while he weaves. The body is the site, not the obstacle."
DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: Design a 5-minute "Fishbowl Discussion" activity for 6 students on the prompt: "Kabir's 'inkoyh' (weaving) metaphor redefines *work* as *worship* – does this sanctify labor or exploit it?" Specify: (a) The 3 textual anchors each inner-circle speaker must use, (b) The specific 'talk move' (e.g., Paraphrase, Press for Evidence, Build On, Counter) assigned to each outer-circle observer, (c) The synthesis question the teacher asks to close.
COMPETENCY: Pedagogical Design & Metacognitive Discussion Facilitation
STEPS:
- Step 1: Select 3 textual anchors spanning prose and poem: Anchor A (Prose): 'mUgksaus eqDrd xs; inksa dh jpuk dh' (composed poems for the suffering). Anchor B (Poem Stanza 1): 'inkoyh' implied in 'yksd&ykt [kks;h' (known by common folk through work). Anchor C (Poem Stanza 2): 'izse&csfy cks;h' (fire and shade together in the body-at-work).
- Step 2: Assign inner-circle roles (3 speakers, 10 mins): Speaker 1 argues "Sanctifies" using Anchor A (labor as service to suffering). Speaker 2 argues "Exploits" using Anchor B (world only sees 'f<x' low caste, ignores 'nnZ'). Speaker 3 mediates using Anchor C ('sahaj' integration – neither sanctification nor exploitation, but non-dual practice).
- Step 3: Assign outer-circle observers (3 observers) specific talk-move trackers: Observer 1 tracks "Press for Evidence" (tally each time a speaker cites a specific word/line). Observer 2 tracks "Build On" (tally each "Adding to X..."). Observer 3 tracks "Counter with Text" (tally each disagreement grounded in a quote).
- Step 4: Define the synthesis closing question (teacher asks at 4:30 mark): "If Kabir's weaving is 'sahaj' – where the loom's rhythm *is* the mantra – then for a modern gig worker whose algorithm *breaks* the rhythm, is reclaiming 'sahaj' a spiritual act or a labor rights demand? Answer in one sentence using 'inkoyh'."
- Step 5: Debrief structure (30 secs): Observers report tallies; inner circle reflects: "Which talk move was hardest? Where did we stall?"
REASONING: This tests the student's ability to *design* the discussion architecture – a meta-skill for future teachers/leaders. It requires mapping textual evidence to argument roles, operationalizing 'talk moves' as observable behaviors, and crafting a synthesis question that fuses the poem's core concept ('sahaj', 'inkoyh') with contemporary critical theory (labor/algorithm).
ANSWER: (a) Anchors: 1. Prose: 'eqDrd xs; inksa dh jpuk' (labor as compassion). 2. Poem: 'laru f<x cSfB&cSfB' (labor as stigmatized identity). 3. Poem: 'izse&csfy cks;h' (labor as non-dual field of fire/shade). (b) Observer Talk Moves: Obs-1: Press for Evidence ("Which line?"). Obs-2: Build On ("Adding to..."). Obs-3: Counter with Text ("But the prose says..."). (c) Synthesis Question: "Algorithm todta hai rhythm; 'inkoyh' wapas lena adhyatmik karyavahi hai ya shramik adhikar ki maang? Ek vakya mein 'inkoyh' prayog karke batao."
DIFFICULTY: hard