## DEFINITION
Writing Skills based on the chapter refers to the ability to construct coherent, evidence-based responses in Hindi that analyze the prose text "jktLFkku dh jtr cw¡nas" using a structured framework (Point, Evidence, Explanation, Link) to address comprehension, character analysis, thematic exploration, and critical interpretation questions typical of Class 11 board examinations.

## COGNITIVE_LEVEL
apply

## MASTERY_CRITERIA
The student must independently write a 150-200 word structured answer in Hindi for a thematic or character-based question, embedding at least two precise textual references (paraphrased or quoted), explaining their significance, and linking them to the central idea of human dignity versus systemic oppression, without digressing into plot summary.

## SCOPE_BOUNDARY
This node covers writing analytical answers (long answer type, 5-6 marks) for the specific prose piece "jktLFkku dh jtr cw¡nas" — focusing on character sketches of the protagonist and supporting characters, theme of exploitation and resilience, and use of irony/symbolism. It does NOT cover creative writing formats (letters, articles, stories) or unseen passage comprehension.

## WALKTHROUGH
Imagine you sit in the exam hall and see a question: "How does the author use the protagonist's silence to critique the feudal system? Answer in 150 words." Your mind goes blank — you know the story but don't know how to *structure* the answer. Start by recalling the PEEL method: **P**oint (make a claim), **E**vidence (give a specific incident from the text), **E**xplanation (analyze *how* that incident proves your claim), **L**ink (connect back to the question's focus). First, identify *two* key moments where the protagonist's silence speaks louder than words — for instance, when he accepts the unjust wage without protest, and when he refuses to sign the false document. For each moment, write one PEEL paragraph. Finally, add a concluding sentence that synthesizes both points into the larger theme of silent resistance. The key insight: board examiners reward *analysis of evidence*, not narration of events.

## DIAGNOSTIC_QUESTION_1
What is the full form of the PEEL structure used for writing analytical answers in Hindi literature, and what does each letter stand for in the context of a long-answer question?

## DIAGNOSTIC_ANSWER_1
PEEL stands for **P**oint (मुख्य बात/दावा), **E**vidence (पाठ्य साक्ष्य/घटना), **E**xplanation (व्याख्या/विश्लेषण), **L**ink (संबंध/निष्कर्ष). A wrong answer (e.g., confusing Explanation with Example, or omitting Link) reveals the student treats answer writing as storytelling rather than argument-building — they will narrate *what happened* instead of proving *why it matters* for the question asked.

## DIAGNOSTIC_QUESTION_2
A student writes: "The protagonist is very poor and suffers a lot. The landlord exploits him. In the end, he dies sadly. This shows the theme of exploitation." Identify the specific structural flaw in this answer and explain why it would score poorly in a Class 11 board exam despite mentioning the correct theme.

## DIAGNOSTIC_ANSWER_2
The answer lacks **textual evidence** (specific incidents, dialogues, or descriptions) and **explanation** (analysis of *how* the evidence proves exploitation). It is a plot summary with a thematic label slapped at the end. Board marking schemes allocate marks for: (1) relevant point, (2) precise textual reference, (3) analytical explanation, (4) thematic link. This answer might get 1/5 marks — only for identifying the theme. The student mistakes *knowing the story* for *answering the question analytically*.

## DIAGNOSTIC_QUESTION_3
Apply the PEEL structure to answer this question in 3-4 sentences (Hindi or English): "How does the incident of the protagonist refusing to put his thumb impression on the false paper reveal his inner strength?" Provide one complete PEEL paragraph.

## DIAGNOSTIC_ANSWER_3
**Point:** The protagonist's refusal to thumb-print the false document demonstrates his moral courage and self-respect despite systemic powerlessness.  
**Evidence:** When the landlord's men force him to sign a paper falsely stating he received full wages, he pulls his hand back and says, "Main jhooth nahi bolunga" (I will not speak a lie).  
**Explanation:** This act is not mere defiance; it reclaims his agency in a space where his body and labor are owned by others. By risking immediate violence for truth, he asserts that his dignity is non-negotiable.  
**Link:** Thus, a single silent gesture becomes a powerful indictment of a feudal system that equates illiteracy with consent.  
A wrong answer would quote the incident but skip Explanation (e.g., "This shows he is brave") — failing to connect the *specific action* to the *larger psychological/spiritual resistance*.

## DIAGNOSTIC_QUESTION_4
Compare two ways of embedding textual evidence in a Hindi answer: (A) Direct quote: "उसने कहा, 'मैं झूठ नहीं बोलूंगा'।" (B) Paraphrase: "जब उससे झूठे कागज़ पर अंगूठा लगवाया गया, तो उसने इनकार कर दिया।" Analyze which is more effective for a *character analysis* question and which for a *theme* question, and why.

## DIAGNOSTIC_ANSWER_4
For **character analysis**, direct quotes (A) are superior because they capture the character's *voice, diction, and tone* — "मैं झूठ नहीं बोलूंगा" reveals simplicity, firmness, and moral clarity in his own words. For **theme questions**, paraphrase (B) is often better because it condenses the *situational context* (force, false paper, refusal) which illustrates the systemic oppression theme more efficiently. A common error: using long quotes in theme answers (wasting word limit) or paraphrasing in character answers (losing the character's unique speech pattern). The choice must serve the *question's demand*, not habit.

## DIAGNOSTIC_QUESTION_5
Evaluate this student's claim: "Since the chapter is a translation from another language, we should not focus on specific Hindi words or phrases used by the author; the themes are universal, so general answers are acceptable." Defend or refute with reference to board exam expectations.

## DIAGNOSTIC_ANSWER_5
**Refute.** Board exams (CBSE Hindi Core/Elective) assess *close reading of the prescribed Hindi text*. The translator's word choices (e.g., "जत्था", "ठेकेदार", "अंगूठा छाप", "बेगारी") carry specific socio-cultural weight — "अंगूठा छाप" implies systemic illiteracy exploited by feudal contracts, which "illiterate" alone does not convey. General answers ("he was forced to sign") lose the *cultural specificity* that the marking scheme rewards. Students must analyze the *Hindi text as given*, noting how vocabulary constructs the world of the story. Ignoring the Hindi phrasing treats translation as transparent, which is a Category Error in literary analysis.

## DIAGNOSTIC_QUESTION_6
Create a new 6-mark question on the theme of "silent resistance" in the chapter, and write a 2-sentence *thesis statement* (in Hindi or English) that a top-scoring answer would build upon. The thesis must be arguable, specific to the text, and go beyond "silent resistance exists."

## DIAGNOSTIC_ANSWER_6
**Question:** "The protagonist never delivers a speech or leads a revolt, yet the text portrays him as a figure of resistance. Analyze how 'silence' functions as a form of rebellion in 'jktLFkku dh jtr cw¡nas', citing three distinct incidents."  
**Thesis Statement:** "In the narrative, silence is not passive submission but a strategic withdrawal of consent — the protagonist's refusal to speak falsehoods, his withheld labor during illness, and his final unspoken gaze at the landlord collectively dismantle the feudal contract that equates his body with property."  
A weak thesis ("He resists silently in many ways") is a *topic*, not an *argument* — it offers no analytical lens (strategic withdrawal, dismantling contract) and no roadmap for the three incidents. The strong thesis makes a *claim about how silence works* that the essay must then prove.

## COMMON_MISCONCEPTION
Students believe that writing a good Hindi answer means using "difficult" or "Sanskritized" vocabulary (e.g., "शोषण" instead of "जुल्म", "प्रतिरोध" instead of "विरोध") and quoting long passages. They think *language ornamentation* substitutes for *analytical depth*. In reality, examiners penalize flowery language that obscures the argument. The marking scheme rewards: (1) precise, simple Hindi that clearly states the point, (2) short, relevant textual references (even in the student's own words), (3) logical explanation linking evidence to point. A student writing "The landlord exploits him" (जमींदार उसका शोषण करता है) with a specific incident and clear analysis scores higher than one writing "सामंती व्यवस्था द्वारा श्रमिक का घोर शोषण किया जाता है" with no evidence. The error stems from confusing *literary criticism register* with *exam answer writing register*.

## ON_FAILURE
If a student submits a flowery, evidence-free answer:  
1. **Highlight** every sentence in their answer with three colors: Yellow = Point/Claim, Green = Textual Evidence, Blue = Explanation/Analysis. If a color is missing, that PEEL component is absent.  
2. **Rewrite one paragraph together** using only Class 9-level Hindi vocabulary but strict PEEL structure — prove that *clarity + structure > vocabulary*.  
3. **Give a "vocabulary budget"**: allow only 2 "high-level" words per 150-word answer; force the rest into simple, precise Hindi.  
4. **Practice "Evidence First" drill**: give a question, ask them to *only* list 3 specific textual references (page/incident) before writing a single sentence of analysis. This breaks the habit of starting with vague generalizations.

## BUILDS_ON
This node builds on the student's ability to identify themes, characters, and literary devices from nodes c11_hin_v_cbse_05_004 to c11_hin_v_cbse_05_013 — converting *analytical insights* into *structured written arguments*.

## LEADS_TO
This node leads to c11_hin_v_cbse_05_015 (Speaking and Listening) where the same analytical points must be articulated orally in discussion, requiring even tighter organization and real-time evidence recall.

## PREREQUISITE_NODE_IDS
c11_hin_v_cbse_05_004, c11_hin_v_cbse_05_005, c11_hin_v_cbse_05_006, c11_hin_v_cbse_05_007, c11_hin_v_cbse_05_008, c11_hin_v_cbse_05_009, c11_hin_v_cbse_05_012, c11_hin_v_cbse_05_013, c11_hin_v_cbse_05_010

## PREREQUISITE_REASONS
c11_hin_v_cbse_05_004: Character analysis of protagonist provides the core material for character-sketch answers.  
c11_hin_v_cbse_05_005: Supporting characters (landlord, contractor) are needed for answers on conflict and systemic oppression.  
c11_hin_v_cbse_05_006: Primary theme (exploitation vs dignity) is the central thesis for most long-answer questions.  
c11_hin_v_cbse_05_007: Secondary themes (migration, identity, silence) enable nuanced answers on specific aspects.  
c11_hin_v_cbse_05_008: Imagery/metaphor analysis supplies evidence for "how the author conveys theme" questions.  
c11_hin_v_cbse_05_009: Irony/symbolism (e.g., thumb impression as false consent) are high-value evidence for critical interpretation.  
c11_hin_v_cbse_05_012: Literal/inferential comprehension ensures accurate textual referencing — no misquoting.  
c11_hin_v_cbse_05_013: Critical thinking skills provide the *analytical depth* (why this matters) for the Explanation step of PEEL.
c11_hin_v_cbse_05_010: Writing Skills: Based on the Chapter demands using the chapter's own thematic vocabulary (e.g., *संवेदनहीनता*, *अस्तित्व*) to write analytical answers.  

## FORWARD_NODE_IDS
c11_hin_v_cbse_05_015, c12_hin_a_cbse_05_014

## FORWARD_REASONS
c11_hin_v_cbse_05_015: Speaking and Listening requires students to orally present the same structured arguments (PEEL) in real-time discussion, using the textual evidence and analytical points mastered in this writing node.
c12_hin_a_cbse_05_014: अगला तार्किक चरण: Writing Skills based on the chapter refers to the ability to compose structured, evidence-based resp... इस नोड की अवधारणाओं को सीधे उपयोग/विस्तारित करता है।  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
none

## CHAIN_DESCRIPTION
c11_hin_v_cbse_05_004 -> c11_hin_v_cbse_05_014 -> c11_hin_v_cbse_05_015

## THIS_FORMULA
PEEL Structure for Long Answers:  
**P** = Point (प्रश्न के सीधे उत्तर में एक स्पष्ट दावा)  
**E** = Evidence (पाठ से एक विशिष्ट घटना/संवाद/विवरण — उद्धृत या संक्षिप्त)  
**E** = Explanation (साक्ष्य दावे को कैसे सिद्ध करता है — विश्लेषण, कारण, प्रभाव)  
**L** = Link (दावे को प्रश्न के कीवर्ड/केंद्रीय विषय से वापस जोड़ना)

## FORMULA_VARIABLES
P = Point (मुख्य तर्क/दावा) — 1 sentence, directly answers the question.  
E = Evidence (पाठ्य साक्ष्य) — 1-2 specific textual details (incident, quote, description).  
E = Explanation (व्याख्या) — 2-3 sentences analyzing *how* evidence proves the point.  
L = Link (संबंध/निष्कर्ष) — 1 sentence connecting back to question's focus/theme.

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
linguistic

## CROSS_SUBJECT
c11_history_feudalism_colonial_india | The chapter's depiction of bonded labor (begari), thumb-impression contracts, and landlord-contractor nexus mirrors the historical reality of feudal exploitation in colonial and post-colonial rural India — students can use historical context to deepen Explanation step.  
c11_civics_rights_dignity | The protagonist's refusal to sign a false document embodies Article 21 (Right to Life with Dignity) and Article 23 (Prohibition of Forced Labour) — linking literary analysis to constitutional values strengthens the Link step in board answers.

## PREREQ_CONCEPT
Ability to distinguish between *plot summary* (what happens) and *analytical argument* (why it matters for the question) — developed through nodes 004-013.

## PREREQ_BEFORE
Student must have completed thematic and character analysis of the chapter (nodes 004-007, 013) and be able to recall at least 5 specific textual incidents with page/chapter references.

## PREREQ_STUCK
If stuck, review **c11_hin_v_cbse_05_013 (Critical Thinking)** — specifically the distinction between "text-to-self" connections (personal feelings) and "text-to-text" analysis (evidence-based interpretation), which is the foundation of the Explanation step.

## WORKED_EXAMPLE_1
PROBLEM: A student writes this answer for a 6-mark question: "How does the author portray the contractor as a symbol of systemic exploitation? (150 words)"  
**Weak Answer:** "The contractor is very bad. He takes the workers to the city and makes them work hard. He does not give them full money. He beats them. He is a symbol of exploitation because he exploits the poor workers. The author shows him as cruel and greedy."  
Improve this answer using PEEL structure with two distinct textual evidences.

STEPS:
- Step 1: Identify the question's core demand — "contractor as *symbol of systemic exploitation*" (not just "he is bad"). The answer must show how his *individual actions represent a larger system*.
- Step 2: Select two precise textual evidences: (a) The contractor advances money (dadni) creating debt-bondage, then deducts "expenses" so wages never clear the debt. (b) He tells the protagonist: "Yahan tumhari koi sunne wala nahi" (No one will hear you here) — revealing state complicity.
- Step 3: Draft Point for Paragraph 1: The contractor embodies the *mechanism* of exploitation — debt-bondage disguised as employment. Evidence: The dadni advance and manipulated accounts. Explanation: This is not personal cruelty but a structural trap — the advance binds the worker legally/morally, and the accounting ensures perpetual debt. Link: Thus, the contractor personifies the feudal economy's engine.
- Step 4: Draft Point for Paragraph 2: The contractor enforces *impunity* — the system protects him. Evidence: His statement "Yahan tumhari koi sunne wala nahi" when the protagonist complains. Explanation: This reveals the absence of legal recourse; exploitation is not a bug but a feature of the system. The contractor speaks for the state's silence. Link: Therefore, his power derives from systemic design, not individual strength.
- Step 5: Write a concluding Link sentence synthesizing both: "The contractor is not a villain but a functionary — the human face of a system that converts poverty into bondage and silence into law."

REASONING: The weak answer lists *traits* (cruel, greedy) — character sketch, not symbol analysis. The improved answer uses each PEEL paragraph to prove *how the contractor represents a system*: Paragraph 1 = economic mechanism (debt), Paragraph 2 = political mechanism (impunity). Each Evidence is specific (dadni, specific dialogue). Each Explanation analyzes *structure*, not personality. The final Link synthesizes into the "symbol" demand.

ANSWER:  
**Paragraph 1 (Economic Symbol):**  
ठेकेदार शोषण की आर्थिक यांत्रिकी — दादनी प्रथा — का मूर्त रूप है। वह मज़दूरों को अग्रिम राशि (दादनी) देकर कर्ज़ के जाल में फँसाता है और फिर खर्चों के नाम पर कटौती कर मज़दूरी कभी चुकने नहीं देता (पाठ संदर्भ: दादनी और हिसाब-किताब का वर्णन)। यह व्यक्तिगत क्रूरता नहीं, बल्कि सामंती अर्थव्यवस्था का संरचनात्मक जाल है: अग्रिम राशि मज़दूर को नैतिक-कानूनी रूप से बाँधती है और हिसाब-किताब सतत ऋण सुनिश्चित करता है। इस प्रकार, ठेकेदार उस व्यवस्था का इंजन है जो गरीबी को बंधुआ मज़दूरी में बदल देती है।  

**Paragraph 2 (Political Symbol):**  
ठेकेदार शोषण को दंड-मुक्ति (impunity) भी प्रदान करता है। जब नायक शिकायत करता है, तो ठेकेदार कहता है, "यहाँ तुम्हारी कोई सुनने वाला नहीं" (पाठ संदर्भ: संवाद)। यह कथन राज्य की चुप्पी को उजागर करता है — क़ानून और प्रशासन शोषक के साथ हैं। शोषण व्यवस्था की 'बग' नहीं, 'फीचर' है। ठेकेदार की शक्ति उसकी व्यक्तिगत बल में नहीं, व्यवस्थागत डिज़ाइन में निहित है।  

**संश्लेषण:** अतः ठेकेदार खलनायक नहीं, एक पदाधिकारी (functionary) है — उस व्यवस्था का मानवीय चेहरा जो गरीबी को बंधन में और मौन को क़ानून में बदल देती है।

## WORKED_EXAMPLE_2
PROBLEM: Write a 150-word answer for: "Analyze the significance of the title 'jktLFkku dh jtr cw¡nas' (The Silent Screams of the State/Capital) with reference to the protagonist's journey." (Note: Title translation is interpretive — "jtr cw¡nas" = silent screams/cries; "jktLFkku" = state/capital/power center.)

STEPS:
- Step 1: Deconstruct the title metaphor: "jtr cw¡nas" (silent screams) = oxymoron. Screams imply voice, protest; silence implies suppression. The title promises a study of *voiceless protest*. "jktLFkku" = the power center (state/capital/feudal headquarters) where power resides.
- Step 2: Identify three protagonist moments that enact "silent screams": (a) Refusing thumb-impression on false paper (silent refusal). (b) Working through illness without complaint (silent endurance as resistance). (c) Final gaze at the landlord/contractor before death (silent accusation).
- Step 3: Structure two PEEL paragraphs (word limit 150 words ≈ 2 paragraphs + concluding line). Paragraph 1: Title's "silent screams" = protagonist's *refusal to legitimize lies* (thumb impression incident). Paragraph 2: Title's "jktLFkku" (power center) = the destination where silence becomes loudest (final gaze).
- Step 4: Draft Paragraph 1: Point = Title's oxymoron captures protagonist's resistance mode. Evidence = Refusal to thumb-print false wage receipt. Explanation = By withholding consent, his silence *screams* truth in a system built on fabricated consent. Link = This is the first "silent scream" at the periphery.
- Step 5: Draft Paragraph 2: Point = The "jktLFkku" (power center) is where silent screams converge. Evidence = Dying protagonist's fixed gaze at the contractor/landlord. Explanation = In the heart of power, his voiceless body becomes the loudest indictment — no speech needed. Link = The title's geography (from village to capital) maps the journey of silence becoming testimony.
- Step 6: Concluding synthesis: The title is not metaphorical decoration; it is the narrative's structural principle — the protagonist carries the village's silent screams into the capital's heart.

REASONING: Title analysis questions require decoding the *metaphor* and mapping it onto *narcissus structure*. The worked example shows how to treat each title word as an analytical lens (oxymoron, geography) and attach specific textual moments. The student learns to avoid "title reflects theme" generalities.

ANSWER:  
शीर्षक 'जत्था की जत्र च्वनास' (सत्ता की चीख़ें/मौन चीख़ें) एक ऑक्ज़िमोरॉन (विरोधाभास) है जो नायक के प्रतिरोध के तरीके को परिभाषित करता है: 'मौन' जो 'चीख़' बन जाता है। पहला 'मौन चीख़' तब उठता है जब नायक झूठे मज़दूरी रसीद पर अंगूठा लगाने से इनकार करता है — उसकी चुप्पी उस व्यवस्था की सहमति को नकार देती है जो झूठ पर टिकी है (पाठ: अंगूठा छाप प्रकरण)। यह परिधि (गाँव) पर उठी चीख़ है।  

दूसरी 'चीख़' 'जत्था' (सत्ता-केंद्र/शहर) में गूँजती है: मृत्युशय्या पर नायक की ठेकेदार/जमींदार पर टिकी निर्निमेष दृष्टि। यहाँ मौन देह ही सबसे तीव्र अभियोग बन जाती है — किसी भाषण की आवश्यकता नहीं। शीर्षक की भौगोलिक यात्रा (गाँव से सत्ता-केंद्र) नायक की मौन यात्रा को प्रतिबिंबित करती है।  

अतः शीर्षक केवल रूपक नहीं, कथा की संरचनात्मक सिद्धांत है: नायक गाँव की 'मौन चीख़ों' को सत्ता के हृदय तक पहुँचाता है।

## WORKED_EXAMPLE_3
PROBLEM: A 6-mark comparative question: "Compare the protagonist's resistance with that of the supporting character (the young migrant who runs away). How do their contrasting strategies reveal the novel's view on agency under oppression? (200 words)"

STEPS:
- Step 1: Identify the two characters and their resistance strategies: Protagonist = *endurance + moral refusal* (stays, works, refuses to lie). Young migrant = *flight* (runs away to city, breaks contract).
- Step 2: Determine the "novel's view on agency" — thesis: The text presents *both* as limited but meaningful; neither achieves systemic change, but both reclaim humanity in different registers — protagonist through *ethical integrity*, migrant through *physical escape*.
- Step 3: Select evidence for Protagonist: (a) Refusal to sign false paper. (b) Working while ill to not give excuse for wage deduction. Evidence for Migrant: (a) Night escape despite risk of capture. (b) Letter sent back saying "Main azad hoon" (I am free).
- Step 4: Structure three PEEL paragraphs: Para 1 = Protagonist's strategy (ethical refusal). Para 2 = Migrant's strategy (physical flight). Para 3 = Synthesis — what the contrast reveals about agency.
- Step 5: Draft Para 1 (Protagonist): Point = Protagonist resists by *refusing complicity* within the system. Evidence = Thumb-impression refusal + working while ill. Explanation = His agency is *negative* (refusal to participate in lie) and *embodied* (body as site of truth). He stays, making his resistance a daily act of witnessing. Link = This is agency as *moral anchorship*.
- Step 6: Draft Para 2 (Migrant): Point = Migrant resists by *exiting* the system. Evidence = Night escape + "Main azad hoon" letter. Explanation = His agency is *spatial* — he claims freedom by removing body from the site of oppression. But freedom is precarious (urban anonymity, no guarantee). Link = This is agency as *rupture*.
- Step 7: Draft Para 3 (Synthesis): Point = The contrast reveals agency under oppression is *fragmented, not heroic*. Evidence = Protagonist dies in bondage; migrant's freedom is uncertain. Explanation = Text refuses a single "correct" resistance — both pay costs (life vs. rootlessness). Together they map the *impossible choices* of the oppressed. Link = Thus, the novel honors both without romanticizing either — agency is survival with dignity, however partial.

REASONING: Comparative questions require a *thesis about the comparison itself* (not just two character sketches). The worked example shows how to build a synthesis paragraph (Para 3) that answers "what does the contrast reveal?" — the highest-order thinking in the question. Each character gets a full PEEL paragraph with distinct evidence and distinct analytical lens (moral anchorship vs. rupture).

ANSWER:  
**नायक: नैतिक लंगर (Moral Anchorage) के रूप में अभिकर्ता**  
नायक व्यवस्था के *भीतर* रहकर उसकी झूठी सहमति को नकारता है। वह झूठे कागज़ पर अंगूठा नहीं लगाता और बीमारी में भी काम करता है ताकि मज़दूरी न कटे (पाठ: अंगूठा छाप और बीमारी प्रसंग)। उसकी अभिकर्ता 'नकारात्मक' (इनकार) और 'दैहिक' (शरीर को सत्य का स्थल बनाना) है। वह भागता नहीं, गवाही देता रहता है। यह प्रतिरोध का 'नैतिक लंगर' है — व्यवस्था को उसकी ही शर्तों पर चुनौती।  

**युवा प्रवासी: विद्रूप (Rupture) के रूप में अभिकर्ता**  
युवा मज़दूर व्यवस्था से *बाहर* निकलकर आज़ादी छीनता है। वह रातोंरात भाग जाता है और पत्र लिखता है: "मैं आज़ाद हूँ" (पाठ: भागने और पत्र का प्रसंग)। उसकी अभिकर्ता 'स्थानिक' (स्पेशियल) है — देह को शोषण-स्थल से हटाना। किंतु यह आज़ादी अनिश्चित है: शहरी गुमनामी, कोई सुरक्षा नहीं। यह प्रतिरोध का 'विद्रूप' है — व्यवस्था को तोड़कर निकलना।  

**संश्लेषण: खंडित, वीर नहीं अभिकर्ता**  
दोनों रणनीतियों का विरोधाभास बताता है कि उत्पीड़न में अभिकर्ता 'खंडित' (fragmented) होती है, वीरतापूर्ण नहीं। नायक बंधुआ मरता है; प्रवासी की आज़ादी अधूरी। पाठ किसी एक को 'सही' नहीं ठहराता — दोनों की क़ीमत दर्शाता है। साथ में वे उत्पीड़ित के 'असंभव विकल्पों' का नक्शा खींचते हैं। उपन्यास दोनों का सम्मान करता है बिना रोमैंटिसाइज़ किए — अभिकर्ता है गरिमा के साथ जीवित रहना, चाहे जितना आंशिक।

## COMPETENCY_QUESTION_1
QUESTION: A Class 11 student writes this opening for a 6-mark question on "Irony in the chapter": "There are many ironies in this chapter. For example, the contractor says he helps workers but actually exploits them. This is ironic. Also, the protagonist is illiterate but knows the truth better than the educated contractor. This is also ironic."  
Rewrite this opening into a *single* high-scoring introductory paragraph (40-50 words) that: (a) defines irony precisely in this context, (b) states a thesis about irony's *function* (not just existence), and (c) signals the two specific ironies to be analyzed. Do not write the full answer — only the improved introduction.

COMPETENCY: Analytical writing — crafting a thesis-driven introduction for a literary analysis answer.

STEPS:
- Step 1: Identify the flaws in the student's opening: lists examples without definition, no thesis (just "there are ironies"), uses "also" as weak transition, no analytical vocabulary.
- Step 2: Define irony for this text: "Irony here operates as the gap between the system's *legitimizing rhetoric* (contract, law, literacy) and its *lived reality* (exploitation, violence, moral clarity of the illiterate)."
- Step 3: Formulate thesis: "The author deploys structural irony to expose how feudal power masks coercion in the language of consent."
- Step 4: Signal the two ironies: (1) Contractual irony — thumb-impression as simulated consent. (2) Epistemic irony — illiterate protagonist as moral knower vs. literate contractor as moral blind.
- Step 5: Compress into 40-50 words Hindi/English paragraph.

ANSWER:  
इस कथा में विडंबना (irony) सहमति की भाषा में छिपे जबरन शोषण का पर्दाफ़ाश करती है: सामंती सत्ता अनुबंध, क़ानून और साक्षरता की आड़ में बंधुआ मज़दूरी को वैध बनाती है। दो संरचनात्मक विडंबनाएँ केंद्रीय हैं — (१) संविदात्मक विडंबना: अंगूठा छाप 'सहमति' का नाटक जो वास्तव में लूट का दस्तावेज़ है; (२) ज्ञानमीमांसीय विडंबना: निरक्षर नायक नैतिक सत्य जानता है, जबकि साक्षर ठेकेदार अंधा है। लेखक विडंबना का प्रयोग शोषण के 'वैध' मुखौटे को उतारने के लिए करता है।

DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: "The chapter ends with the protagonist's death. Some students argue this makes the ending 'hopeless' and the resistance 'futile'. Write a 100-word counter-argument paragraph (using PEEL) defending the view that the ending *affirms* the protagonist's dignity and the possibility of resistance, citing two textual details from the final scenes."

COMPETENCY: Evaluative argumentation — constructing a defensible literary interpretation against a plausible misreading, using textual evidence.

STEPS:
- Step 1: Identify the opposing claim: Death = futility/hopelessness. This confuses *outcome* (he dies) with *meaning* (what his death signifies).
- Step 2: Formulate counter-thesis (Point): The ending transforms death from defeat into *testimony* — his dying body becomes the final, irrefutable evidence against the system.
- Step 3: Select Evidence 1: The protagonist's final gaze fixed on the contractor/landlord — "unblinking accusation" (पाठ: अंतिम दृश्य में दृष्टि).
- Step 4: Select Evidence 2: The silence surrounding his death — no ritual, no mourning allowed, yet the *narrator* records it, making the reader the witness (पाठ: मृत्यु के बाद का मौन/वर्णन).
- Step 5: Draft Explanation: The gaze refuses the system's demand for invisible disappearance; the narrative preservation refuses erasure. Death is the *price*, not the *negation*, of his resistance.
- Step 6: Draft Link: Thus, the ending does not close with hopelessness but opens the reader's moral responsibility — the "silent scream" reaches us.
- Step 7: Write 100-word PEEL paragraph in Hindi.

ANSWER:  
नायक की मृत्यु निराशा नहीं, गवाही है — प्रतिरोध की अंतिम विजय। उसकी निश्चल, अपलक दृष्टि ठेकेदार/जमींदार पर टिकी रहती है (पाठ: अंतिम दृश्य), जो व्यवस्था की माँग — 'गायब हो जाओ, कोई निशान न छोड़ो' — को ठुकरा देती है। यह दृष्टि 'मौन चीख़' का चरम बिंदु है: मरते हुए भी वह अभियुक्त को देखता रहता है, न्यायाधीश बनकर।  

दूसरे, उसकी मृत्यु के बाद का थोपा गया मौन (कोई क्रिया-कर्म नहीं, कोई शोक नहीं) स्वयं कथाकार द्वारा दर्ज किया जाता है — पाठक को गवाह बनाकर (पाठ: मृत्योपरांत वर्णन)। कथा मृत्यु को मिटने नहीं देती; उसे साक्ष्य में बदल देती है।  

अतः अंत 'निरर्थकता' नहीं, नैतिक दायित्व का आरंभ है: नायक की 'मौन चीख़' अब पाठक की अंतरात्मा में गूँजती है। व्यवस्था शरीर मार सकती है, सत्य नहीं।

DIFFICULTY: hard