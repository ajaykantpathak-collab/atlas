## DEFINITION
Setting and atmosphere in poetry refer to the time, place, physical environment, and the emotional mood or tone that the poet creates through descriptive language, imagery, and sound devices. In Kakuan's dohas, the setting is often a natural, rural landscape at night or dawn, while the atmosphere is one of intense viraha (separation-longing) blended with devotional surrender.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student can independently identify the physical and temporal setting of a given stanza, explain how specific words and images build the atmosphere, and articulate how that atmosphere reinforces the poem's central theme of viraha-bhakti.

## SCOPE_BOUNDARY
This node covers analysis of setting and atmosphere in the two prescribed dohas of Kakuan (Chapter 9, Antra). It does not cover character analysis, thematic development beyond atmosphere, or grammatical explanations — those are addressed in sibling nodes.

## WALKTHROUGH
Imagine you are sitting in your grandmother's courtyard at dusk, hearing a folk song about a woman waiting for her husband who has gone to the city. The song mentions the chirping of crickets, the cool breeze, the dim lamp — you instantly feel her loneliness. That is exactly what Kakuan does in his dohas: he paints a scene (setting) and fills it with a feeling (atmosphere). To begin, read the first doha aloud, noticing the Braj rhythm. Then, underline every word that indicates time (e.g., 'furan' – night/late), place (e.g., 'khaj' – sky/space), or sensory detail (e.g., 'vkou' – call, 'nchys' – restless). Next, ask: what emotion do these details collectively evoke? Finally, connect that emotion to the poet's stated longing for the guru/beloved. The key insight is that setting is not just backdrop; it is an active participant in conveying the spiritual yearning.

## DIAGNOSTIC_QUESTION_1
What is the primary temporal setting indicated in the first doha of Kakuan, and which word signals it?

## DIAGNOSTIC_ANSWER_1
The primary temporal setting is late night or the small hours before dawn, signaled by the word 'फुरक' (furak) meaning 'late at night' or 'after a long wait'. A wrong answer such as 'morning' or 'evening' reveals the student has not recognized the Braj vocabulary for time markers, which is essential for establishing the viraha mood.

## DIAGNOSTIC_QUESTION_2
Explain in your own words how the phrase 'दफग दफग वकउ नछस एुहको दक' contributes to the atmosphere of the first doha.

## DIAGNOSTIC_ANSWER_2
The repetition 'दफग दफग' (dagar dagar – at every step/everywhere) and 'वकउ नछस' (vahu niras – deserted/empty) creates a pervasive sense of emptiness and isolation, reinforcing the atmosphere of desolate longing. A wrong answer that merely translates the phrase without linking repetition to emotional effect shows the student treats imagery as decoration rather than as an atmosphere-building tool.

## DIAGNOSTIC_QUESTION_3
In the second doha, the poet addresses the beloved as 'एकस गव लकसा नसफ[ककस' (ekas gava lasa nasf[kakas). Apply the concept of setting to argue whether this address shifts the setting from physical to metaphysical.

## DIAGNOSTIC_ANSWER_3
Yes, the address shifts the setting. The first doha uses concrete nature imagery (night, sky, path), while the second doha's direct address to the beloved as the sole support ('ekas gava') moves the setting into the devotee's inner spiritual space. A student who says the setting remains the same physical landscape misses the transition from external viraha to internal surrender, a key structural move in Kakuan's poetry.

## DIAGNOSTIC_QUESTION_4
Compare the atmosphere created by the sound devices in the first doha (e.g., alliteration in 'खफग खफग') with that in the second doha (e.g., the rhythmic 'वउकदकुह वकजलह'). How does each serve the poem's emotional arc?

## DIAGNOSTIC_ANSWER_4
The first doha's 'खफग खफग' (khphag khphag) mimics the slow, heavy footsteps of a lonely walker, building a weary, dragging atmosphere. The second doha's 'वउकदकुह वकजलह' (vaukkaduh vakjalaha) has a more urgent, staccato rhythm reflecting the speaker's desperate pleading. A student who only identifies alliteration without connecting sound to emotional progression fails to analyze how auditory texture shapes atmosphere.

## DIAGNOSTIC_QUESTION_5
Evaluate the claim: 'Kakuan's setting descriptions are merely conventional Braj nature tropes and do not advance the poem's spiritual message.' Defend your position with evidence from the text.

## DIAGNOSTIC_ANSWER_5
The claim is false. The 'नछस' (deserted) paths and 'लुएकु' (restless) heart in the first doha mirror the devotee's inner void, making the external landscape a metaphor for spiritual emptiness. In the second doha, the 'इकदकज' (sharp/piercing) call cuts through the night, symbolizing grace penetrating ignorance. A student who agrees with the claim overlooks the functional integration of setting and theme, a hallmark of bhakti poetry.

## DIAGNOSTIC_QUESTION_6
Write a four-line stanza in Hindi (or Braj-style) that creates a setting of a monsoon night and an atmosphere of hopeful waiting, using at least two sound devices and three sensory images.

## DIAGNOSTIC_ANSWER_6
Example: 'घन गरजत बरसत नीर, बिरहिनी बैठी द्वार। / टर-टर बोलत काग सब, आस जगावत बार-बार।' (Clouds thunder, rain falls, the separated woman sits at the door. / Koo-koo speak the crows all, awakening hope again and again.) A poor answer would list images without weaving them into a coherent mood or would omit sound devices, showing inability to synthesize setting and atmosphere creatively.

## COMMON_MISCONCEPTION
Students often think 'setting' means only the physical location (e.g., 'a village') and 'atmosphere' means a single adjective like 'sad'. They miss that setting includes time, season, and sensory details, and that atmosphere is built through a cluster of words, sounds, and rhythms. For instance, they may write 'the setting is night' but not explain how 'फुरक' (late night) differs from 'रात' (night) in conveying prolonged waiting. This error costs marks in board exams where the marking scheme expects specific textual evidence linked to emotional effect.

## ON_FAILURE
1. Revisit c11_hin_ar_cbse_01_003 (Setting and Atmosphere in Class 11) and re-do the worked example on identifying time/place markers in a doha. 2. Take the first doha of Kakuan and make a three-column table: Column A – word/phrase, Column B – sensory modality (visual/auditory/tactile), Column C – emotion evoked. 3. Write a 50-word paragraph explaining how the table proves the atmosphere is 'desolate longing'. 4. Self-check using the diagnostic question 2 rubric.

## BUILDS_ON
Class 11 skill of identifying sensory imagery and linking it to mood in bhakti poetry (c11_hin_ar_cbse_01_003).

## LEADS_TO
Analysis of how imagery and metaphor (c12_hin_a_cbse_09_008) deepen the atmosphere established here, and how irony/symbolism (c12_hin_a_cbse_09_009) subvert it.

## PREREQUISITE_NODE_IDS
c12_hin_a_cbse_09_001, c12_hin_a_cbse_09_002, c11_hin_ar_cbse_01_003, c11_hin_ar_cbse_02_003, c11_hin_ar_cbse_03_003
## PREREQUISITE_REASONS
c12_hin_a_cbse_09_001: Provides historical context of Kakuan and the bhakti tradition, essential to understand why the setting is rural and devotional.
c12_hin_a_cbse_09_002: Gives the narrative structure (two dohas as a dialogue), without which the shift in setting between stanzas is unclear.
c11_hin_ar_cbse_01_003: Teaches the basic framework of setting-atmosphere analysis in a simpler doha; this node applies it to a more complex text.
c11_hin_ar_cbse_02_003: Reinforces identification of Braj vocabulary for time/place, a recurring skill.
c11_hin_ar_cbse_03_003: Offers practice in linking sound devices to mood, directly used in Diagnostic 4.

## FORWARD_NODE_IDS
c12_hin_a_cbse_09_004, c12_hin_a_cbse_09_008, c12_hin_a_cbse_09_009, c12_hin_a_cbse_09_013, c12_hin_a_cbse_09_005, c12_hin_a_cbse_09_006, c12_hin_a_cbse_09_015

## FORWARD_REASONS
c12_hin_a_cbse_09_004: The protagonist's inner state is revealed through the atmosphere analyzed here.
c12_hin_a_cbse_09_008: Imagery and metaphor are the building blocks of the atmosphere; this node identifies them, the next analyzes their function.
c12_hin_a_cbse_09_009: Irony and symbolism often operate by contrasting with the established atmosphere.
c12_hin_a_cbse_09_013: Critical interpretation requires a firm grasp of setting and atmosphere as evidence.
c12_hin_a_cbse_09_005: Setting/atmosphere (the devotional space of Braj bhakti) provides the cultural codes for interpreting the metaphors.  
c12_hin_a_cbse_09_006: The setting (night, door, path) supplies the spatial imagery that *becomes* the theme's metaphorical vocabulary.  
c12_hin_a_cbse_09_015: Atmosphere of devotional intensity vs. disciplinary rigor shapes the tonal range students must navigate in oral delivery.  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
c12_history_medieval_bhakti_movement: Understanding the historical milieu of nirguna/saguna bhakti explains why Kakuan uses a rural, night-time setting as a metaphor for the soul's journey.
c12_geography_cultural_landscapes_of_india: The Braj region's geography (forests, rivers, village paths) directly shapes the physical setting in the poems.

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_01_003 -> c12_hin_a_cbse_09_003 -> c12_hin_a_cbse_09_008

## THIS_FORMULA
N/A - conceptual

## FORMULA_VARIABLES
N/A

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
linguistic

## CROSS_SUBJECT
N/A | The bhakti movement's emphasis on personal devotion in vernacular languages directly informs the intimate, night-time setting of Kakuan's dohas.
 N/A | The Braj cultural landscape (yamuna banks, groves, village lanes) provides the concrete topoi that Kakuan transforms into spiritual space.
## PREREQ_CONCEPT
Ability to distinguish literal setting details from their symbolic function in a poem.

## PREREQ_BEFORE
Student must be able to list at least five sensory words from a given doha and name the sense each appeals to.

## PREREQ_STUCK
If stuck, review the 'Imagery Identification' exercise in c11_hin_ar_cbse_01_003 and practice with a new doha from the Class 11 textbook.

## WORKED_EXAMPLE_1
PROBLEM: Analyze how the first doha of Kakuan establishes a setting of 'profound nocturnal isolation' and an atmosphere of 'aching viraha'. Use the PEEL structure (Point, Evidence, Explanation, Link).
STEPS:
- Step 1: Identify the question's demand — we must prove two claims (setting = nocturnal isolation, atmosphere = aching viraha) using textual evidence.
- Step 2: Scan the doha for time markers: 'फुरक' (late night), 'वइकिल' (passed/elapsed) indicate deep night. Place markers: 'खज' (sky/space), 'खज वजउफु' (sky and directions) suggest vast emptiness.
- Step 3: Collect sensory evidence: auditory – 'वकउ' (call), tactile – 'नछस' (deserted/cool), kinetic – 'खफग खफग' (step by step). Note the alliteration in 'खफग खफग' and 'नस नस'.
- Step 4: Explain: The vast sky and deserted paths (setting) mirror the devotee's inner emptiness. The repetitive rhythm mimics the slow, painful pacing of a separated lover (atmosphere). The word 'लुएकु' (restless) directly names the viraha.
- Step 5: Link to central idea: This external isolation is not accidental; it is the necessary crucible for the surrender expressed in the second doha.
REASONING: The PEEL structure forces the student to move from observation to interpretation, ensuring each claim is anchored in the text. The step-by-step scanning prevents missing subtle Braj words.
ANSWER: The doha opens with 'फुरक' (late night) and 'वइकिल इज' (long time has passed), establishing a temporal setting of deep, protracted night. Spatially, 'खज वजउफु' (sky and directions) and 'दफग दफग' (every path) depict a boundless, deserted landscape. Auditory imagery ('वकउ' – call) and tactile suggestion ('नछस' – cool/deserted) combine with the alliterative 'खफग खफग' to create a soundscape of heavy, lonely footsteps. Together, these details build an atmosphere of aching viraha: the external desolation reflects the internal restlessness ('लुएकु') of the devotee awaiting the guru. This setting-atmosphere complex prepares the shift to direct address in the next doha.

## WORKED_EXAMPLE_2
PROBLEM: The second doha begins with 'वउकदकुह वकजलह फुगकफजकस दजकस दकसकस'. Explain how this opening line alters the setting and atmosphere established in the first doha.
STEPS:
- Step 1: Recall the first doha's setting (external, night, nature) and atmosphere (desolate longing).
- Step 2: Translate/paraphrase the opening line: 'O you who are the support of the fallen, the remover of fear...' — it is a direct invocation.
- Step 3: Identify the shift: The speaker turns from describing the world to addressing the Divine/Beloved. The setting moves from 'outside' to 'inside the speaker's heart'.
- Step 4: Analyze atmosphere change: The desperate, staccato rhythm ('वउकदकुह वकजलह') conveys urgency and intimacy, replacing the slow drag of the first doha. The atmosphere becomes one of hopeful supplication.
- Step 5: Synthesize: The two dohas together enact a movement from viraha (separation) to samarpan (surrender), with setting and atmosphere as the vehicle.
REASONING: This example teaches the comparative skill required for board questions that ask 'How does the mood change?' or 'Trace the development of feeling.' It also models how to handle difficult Braj vocabulary by focusing on function.
ANSWER: The first doha's setting is the external night — sky, paths, directions — observed by a lonely wanderer. The second doha's opening collapses that distance: the speaker directly addresses the beloved as 'वउकदकुह' (uplifter of the fallen) and 'वकजलह' (remover of fear). The setting becomes the speaker's own heart, where the beloved resides as the sole refuge. Correspondingly, the atmosphere shifts from the heavy, alliterative drag of 'खफग खफग' to the urgent, clustered consonants of 'वउकदकुह वकजलह', signalling a turn from passive suffering to active, desperate prayer. The night remains, but it is now pierced by the 'इकदकज' (sharp) call of devotion.

## WORKED_EXAMPLE_3
PROBLEM: A board exam question asks: 'Kakuan's dohas use the natural setting not as background but as a metaphor for the devotee's inner state.' Evaluate this statement with reference to both dohas, citing at least four specific phrases.
STEPS:
- Step 1: Deconstruct the prompt — it demands evaluation (agree/disagree with nuance), metaphor identification, and four textual citations across both dohas.
- Step 2: List candidate phrases from Dohâ 1: 'फुरक' (time as prolonged wait), 'नछस' (emptiness as spiritual void), 'लुएकु' (restlessness as viraha), 'खफग खफग' (repetitive steps as repetitive remembrance).
- Step 3: List candidate phrases from Dohâ 2: 'वउकदकुह' (fallen state as spiritual fall), 'इकदकज' (sharp call as grace), 'दकु [ककसफगस' (make me hear — the act of listening as reception of truth), 'एसफज;स' (this very moment — time as kairos).
- Step 4: Select the strongest four that clearly function as metaphors: (1) 'नछस' (deserted paths = empty heart), (2) 'लुएकु' (restless body = restless soul), (3) 'इकदकज' (piercing call = divine grace cutting ignorance), (4) 'एसफज;स' (this moment = moment of liberation).
- Step 5: Structure the answer: Thesis statement, then four PEEL paragraphs (one per phrase), concluding synthesis.
- Step 6: Check against marking scheme: 1 mark for thesis, 4 marks for evidence+explanation, 1 mark for conclusion = 6 marks typical for such a question.
REASONING: This multi-step example combines setting-atmosphere analysis with metaphor identification (forward link to c12_hin_a_cbse_09_008) and exam-writing strategy. It shows how to select and deploy evidence efficiently under time pressure.
ANSWER: The statement is wholly accurate. In the first doha, 'नछस' (deserted) describes paths but metaphorically maps the devotee's heart emptied of divine presence. 'लुएकु' (restless) ostensibly qualifies the body but signifies the soul's agitation in separation. In the second doha, 'इकदकज' (sharp/piercing) modifies the call, yet it operates as a metaphor for grace that penetrates the darkness of ignorance. Finally, 'एसफज;स' (this very moment) appears as a temporal marker but symbolizes the timeless instant of realization. Thus, every natural detail is pressed into service as an inner correlate, making the setting a sustained metaphor for the spiritual journey.

## COMPETENCY_QUESTION_1
QUESTION: A student writes: 'The setting of Kakuan's first doha is a village at night. The atmosphere is sad because the heroine misses her lover.' Identify two major inaccuracies in this statement and rewrite it correctly using textual evidence.
COMPETENCY: Critical textual analysis and precise literary terminology
STEPS:
- Step 1: Spot the first inaccuracy: 'village' is never mentioned; the setting is cosmic (sky, directions) and generic, not a specific village.
- Step 2: Spot the second inaccuracy: 'heroine/lover' imposes a secular romance reading; the text addresses a guru/beloved in a bhakti context (viraha for the Divine).
- Step 3: Retrieve correct evidence: 'खज वजउफु' (sky and directions), 'फुरक' (late night), 'लुएकु' (restless longing for the guru).
- Step 4: Rewrite: 'The setting is a vast, deserted nightscape (sky, directions, paths) at deep night (फुरक). The atmosphere is one of intense spiritual viraha (लुएकु), where the devotee's restless pacing (खफग खफग) mirrors the soul's yearning for the guru.'
ANSWER: The original statement reduces the cosmic, symbolic setting to a mundane village and misidentifies the devotional viraha as romantic sadness. Corrected version: 'The setting is a boundless, deserted nocturnal expanse (खज वजउफु, दफग दफग) at the lateness of night (फुरक). The atmosphere is one of profound spiritual longing (लुएकु), conveyed through the repetitive rhythm of solitary pacing (खफग खफग) and the unanswered call (वकउ), reflecting the devotee's yearning for the guru.'
DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: Compare the function of 'night' in Kakuan's first doha with its function in any one poem by Kabir (from Class 11 or 12 syllabus). How does each poet use the night setting to advance a distinct theological argument?
COMPETENCY: Intertextual synthesis and theological-literary reasoning
STEPS:
- Step 1: Recall Kabir's use of night (e.g., in 'रात गवाई सोय के' or 'अंधियारी रात'): night as wasted time, ignorance, or the dark night of the soul before awakening.
- Step 2: Recall Kakuan's night: night as the appointed time for viraha, the fertile darkness where longing intensifies and grace descends.
- Step 3: Identify the theological difference: Kabir (nirguna) uses night to warn against spiritual sloth; Kakuan (saguna/nirguna blend) uses night as the sacred space of separation that precedes union.
- Step 4: Select evidence: Kabir – 'रात गवाई सोय के' (night lost in sleep); Kakuan – 'फुरक' (late night as culmination of waiting), 'इकदकज' (call that pierces the night).
- Step 5: Synthesize: Both use night symbolically, but Kabir's night is a negative backdrop for awakening, while Kakuan's night is a positive, necessary phase of bhakti.
ANSWER: In Kabir's 'रात गवाई सोय के', night represents ignorance and wasted human birth; the rooster's crow (dawn) signals urgent awakening. In Kakuan, 'फुरक' (deep night) is not wasted but saturated with viraha — the devotee's wakefulness in night is itself devotion. The 'इकदकज' call comes *in* the night, suggesting grace meets the devotee in the darkness of separation. Thus, Kabir's night is a problem to be ended; Kakuan's night is a threshold to be crossed. Both advance theology through setting, but Kabir emphasizes self-effort (jagriti), Kakuan emphasizes grace (kripa) in the milieu of longing.
DIFFICULTY: hard