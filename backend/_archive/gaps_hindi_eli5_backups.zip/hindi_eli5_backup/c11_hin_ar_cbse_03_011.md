## DEFINITION
Language Usage in the Text refers to the systematic analysis of grammatical structures, lexical choices, syntactic patterns, and stylistic devices employed by the author (लालित्य ललित) in "वीं के साथ बिते लम्हे" to convey narrative voice, characterize speakers, establish setting, and evoke emotional resonance, moving beyond mere identification to functional explanation of *why* a specific form is chosen over alternatives.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student must independently select any paragraph from the chapter, identify at least three distinct grammatical or lexical features (e.g., aspectual verb forms, honorific shift, dialect marker), and write a 150-word analytical comment explaining how each feature shapes the reader's perception of the narrator's relationship with "वीं" or the socio-cultural milieu.

## SCOPE_BOUNDARY
This node covers: (1) tense-aspect-modality patterns in narrative vs. dialogue, (2) honorific and pronoun alternations reflecting power/intimacy, (3) region-specific lexical items (अवधी/ब्रज touches) and their standardization, (4) compound verbs and their aspectual nuance. It does NOT cover: exhaustive parsing of every sentence, historical linguistics of Hindi, or comparison with other chapters' language.

## WALKTHROUGH
Imagine you are a detective handed a handwritten letter — you notice the writer switches from "आप" to "तुम" mid-sentence, uses "हो गया" instead of "किया", and sprinkles words like "ड्योढ़ी" and "ओझल". Your first move is to **read aloud** the opening paragraph (page 32) and **mark every verb**; ask: "Is this simple past, perfective, or habitual?" Next, **highlight every address term** (वीं, बाबूजी, अम्मा) and **track pronoun shifts** across the same speaker. Then, **list five words** that feel "local" (e.g., "बाँस", "खटिया", "किवाड़") and check the glossary. Finally, **choose one compound verb** (e.g., "चल दिया", "बैठ गया") and test what happens if you replace it with a simple verb — does the focus shift from completion to mere action? The key insight: grammar here is not rule-following but *choice-making* that builds the world of the story.

## DIAGNOSTIC_QUESTION_1
Identify the grammatical term for the verb form "बैठ गया" in the sentence "वीं खटिया पर बैठ गया" and state its aspectual value.

## DIAGNOSTIC_ANSWER_1
**Answer:** Compound verb (संयुक्त क्रिया) — "बैठ" (main verb) + "गया" (vector verb); aspectual value: **perfective completive** (कार्य समाप्ति बोधक), indicating the action is viewed as a bounded, completed event with a resultant state.  
**Wrong-answer diagnosis:** If a student labels it simply "past tense" or "simple verb", they miss the vector verb's role in adding *telicity* (endpoint focus). This reveals a middle-school habit of treating all past forms as monolithic, ignoring the aspectual layering critical for Class 11 textual analysis.

## DIAGNOSTIC_QUESTION_2
In the passage, the narrator uses "वीं" for the grandmother but "आप" for the village elders. Explain in your own words what this honorific shift reveals about the narrator's perceived social distance and emotional intimacy.

## DIAGNOSTIC_ANSWER_2
**Answer:** "वीं" (a dialectal, affectionate contraction of "वीं/दादी") signals **zero social distance + high intimacy** — it is a family-specific lexeme. "आप" marks **formal respect + social distance** toward non-kin elders. The shift shows the narrator code-switches between *intimate kinship register* and *public deference register*, mirroring the dual world of the text (home vs. village).  
**Wrong-answer diagnosis:** If a student says "both mean respect" or "वीं is just a nickname", they conflate *politeness* with *intimacy* and miss the sociolinguistic indexing of relationships — a common error when students map Hindi honorifics onto a binary "formal/informal" instead of a multidimensional grid (power, solidarity, affect).

## DIAGNOSTIC_QUESTION_3
Rewrite the sentence "वीं ने खाना खा लिया" replacing the compound verb with a simple verb. Then explain how the meaning changes regarding the narrator's focus on the *process* vs. *completion* of eating.

## DIAGNOSTIC_ANSWER_3
**Rewritten:** "वीं ने खाना खाया।"  
**Explanation:** "खा लिया" (perfective completive) foregrounds **completion and resultant satisfaction** — the meal is *finished*, implying Vee's appetite is met. "खाया" (simple perfective) merely states the **occurrence** of eating without emphasizing closure. In the text, the compound form underscores the narrator's attentive caregiving gaze: he *notices* the empty plate, the ritual concluded.  
**Wrong-answer diagnosis:** If a student claims "no difference" or only notes "emphasis", they lack the aspectual distinction between *event quantification* (completive) and *event reporting* (perfective). This is a senior-secondary error where aspect is reduced to "intensity" rather than *viewpoint on time*.

## DIAGNOSTIC_QUESTION_4
Compare the narrative prose ("मैंने देखा...") with the reported dialogue ("वीं बोली, 'बेटा, पानी लाओ'"). Analyze **two** syntactic differences (e.g., sentence type, pronoun, verb mood) and argue how they construct distinct *voices* for narrator vs. character.

## DIAGNOSTIC_ANSWER_4
**Answer:**  
1. **Sentence type & mood:** Narrative uses declarative perfective ("देखा", "गया"); dialogue uses imperative ("लाओ") and vocative ("बेटा").  
2. **Pronoun system:** Narrator = first-person "मैं"; Vee = second-person "तुम/आप" embedded in her speech, but third-person "वीं" in narration.  
**Effect:** The narrator's voice is **retrospective, observational, controlled**; Vee's voice is **immediate, directive, affective**. The syntax enacts the gap between *remembering* and *living*.  
**Wrong-answer diagnosis:** Listing differences without linking to *voice construction* (e.g., "one is past, one is command") shows surface-level comparison. Senior analysis requires connecting form to *narrative function*: how grammar allocates authority, temporality, and empathy.

## DIAGNOSTIC_QUESTION_5
The text uses "ड्योढ़ी" (threshold) and "किवाड़" (door) instead of standard "देहली" and "दरवाज़ा". Evaluate the author's decision: does this lexical choice *enhance* or *alienate* a non-rural reader? Justify with two textual arguments.

## DIAGNOSTIC_ANSWER_5
**Answer:** **Enhances** — (1) **Sensory precision**: "ड्योढ़ी" evokes the raised, sacred threshold of a traditional courtyard house (where rituals occur), while "देहली" is generic. (2) **Cultural indexing**: These words anchor the narrative in a specific **Avadhi-rural lifeworld**; replacing them with standard Hindi would erase the *material culture* the story preserves. The glossary footnotes mitigate alienation, turning opacity into invited learning.  
**Wrong-answer diagnosis:** "Alienates because difficult" reflects a reader-response fallacy — judging by *immediate comprehension* rather than *aesthetic function*. Senior students must evaluate lexical choice against *authorial intent* (here: ethnographic fidelity), not personal convenience.

## DIAGNOSTIC_QUESTION_6
Write a 4-line micro-scene (prose or dialogue) set in the same household, using **at least two** dialect words from the glossary (e.g., "बाँस", "खटिया", "ओझल") and **one** compound verb, such that the grammar *shows* (not tells) a grandparent-grandchild bond.

## DIAGNOSTIC_ANSWER_6
**Sample answer:**  
"अम्मा खटिया पर लेट गयीं, बाँस की टेक से सिर टिकाए।  
'पानी ला, बेटा,' बोलीं, आँखें मूँदे।  
मैं दौड़ गया, लोटा भर लाया —  
उन्होंने पी लिया, तृप्त हो गयीं।"  
**Criteria for good answer:** (a) Dialect words used naturally, not forced; (b) Compound verb ("लेट गयीं", "पी लिया", "तृप्त हो गयीं") marks completive care; (c) Imperative + vocative ("बेटा") + zero honorific in grandchild's action ("दौड़ गया") mirrors text's intimacy grammar.  
**Poor answer reveals:** Using dialect as decoration ("The खटिया was brown"), missing compound verbs, or flattening honorifics — shows inability to *transfer* analytical insights into creative syntax.

## COMMON_MISCONCEPTION
**Misconception:** "Grammar analysis means labeling every verb tense and part of speech."  
**Why it persists:** Class 10 board exams reward identification (e.g., "underline the verb and name its tense"). Students carry this *taxonomic* mindset into Class 11, where the syllabus demands *functional* analysis: *why this tense here?* *what does the honorific shift achieve?* The text's richness lies in **deviations** (e.g., historical present in "वीं आती है", dialect forms) not in standard paradigms. Treating grammar as a labeling exercise misses the *rhetorical* dimension — how लालित्य ललित uses non-standard forms to resist linguistic homogenization, a theme central to the chapter.

## ON_FAILURE
1. **Isolate the gap:** Give the student two sentences from the text — one narrative ("मैंने देखा"), one dialogue ("बेटा, पानी लाओ") — and ask: "If you swapped the verbs, what would break?" Guide them to notice mood/pronoun mismatch.  
2. **Micro-drill:** Provide a 3-sentence strip with *only* compound verbs removed (e.g., "खा लिया → खाया", "बैठ गया → बैठा"). Have them read both versions aloud and articulate the *felt difference* in completion vs. process.  
3. **Re-anchor to theme:** Connect the grammatical choice to the chapter's core tension — **tradition vs. modernity** — by showing how "ड्योढ़ी/किवाड़" lexically resists the "दरवाज़ा" of urban standardization. This moves analysis from *form* to *meaning-making*.

## BUILDS_ON
Vocabulary in Context (c11_hin_ar_cbse_03_010) — students must already recognize key lexical items (ड्योढ़ी, ओझल, कृतज्ञता) before analyzing their grammatical embedding.

## LEADS_TO
Comprehension: Literal and Inferential Questions (c11_hin_ar_cbse_03_012) — grammatical sensitivity (e.g., aspect, honorifics) is prerequisite for inferring unstated relationships and narrative reliability.

## PREREQUISITE_NODE_IDS
c11_hin_ar_cbse_03_010, c11_hin_ar_cbse_03_002, c11_hin_ar_cbse_03_004
## PREREQUISITE_REASONS
c11_hin_ar_cbse_03_010: Vocabulary in Context provides the lexical inventory (dialect words, glossary terms) whose grammatical behavior we analyze here.  
c11_hin_ar_cbse_03_002: Plot and Narrative Structure supplies the narrative segments (childhood, rehearsal, performance) where language usage shifts — e.g., rehearsal scenes use more imperatives.  
c11_hin_ar_cbse_03_004: Character Analysis: Protagonist establishes the narrator's dual role (grandson / director), which drives the code-switching between intimate and formal registers.

## FORWARD_NODE_IDS
c11_hin_ar_cbse_03_012, c11_hin_ar_cbse_03_013, c11_hin_ar_cbse_03_014, c12_hin_a_cbse_03_011, c12_hin_a_cbse_04_011, c12_hin_a_cbse_05_011, c12_hin_a_cbse_09_011, c12_hin_a_cbse_11_011, c12_hin_a_cbse_12_011, c12_hin_a_cbse_16_011, c12_hin_a_cbse_17_011, c12_hin_ar_cbse_01_011, c12_hin_ar_cbse_02_011, c12_hin_ar_cbse_03_011, c12_hin_ar_cbse_07_011, c12_hin_ar_cbse_09_011, c12_hin_ar_cbse_10_011, c12_hin_ar_cbse_11_011

## FORWARD_REASONS
c11_hin_ar_cbse_03_012: Comprehension questions often hinge on aspectual nuance (e.g., "had finished" vs. "finished") and honorific inference — skills built here.  
c11_hin_ar_cbse_03_013: Critical interpretation of the author's linguistic politics (standard vs. dialect) requires the grammatical toolkit developed in this node.  
c11_hin_ar_cbse_03_014: Writing skills (e.g., diary entry, script) demand conscious register control — directly informed by analyzing the text's register shifts.
c12_hin_a_cbse_03_011: Provides foundational grammar toolkit (samAs classification, karak identification, mood recognition) used here for literary analysis.  
c12_hin_a_cbse_04_011: अगला तार्किक चरण: This node analyzes the grammatical structures, syntactic patterns, and language usage specific to th... इस नोड की अवधारणाओं को सीधे उपयोग/विस्तारित करता है।  
c12_hin_a_cbse_05_011: Class 11 exposure to samasa analysis in verse  
c12_hin_a_cbse_09_011: Covered *sarvanam* (pronoun) forms — prerequisite for analyzing Braj pronominal suffixes like **-g**.  
c12_hin_a_cbse_11_011: Teaches compound verb vectors (cp, jana, dena) — required for "cp x;k", "fl[kk;k", "ns jgk".  
c12_hin_a_cbse_12_011: Exposure to honorific systems (tum/aap/tu) and their social indexing  
c12_hin_a_cbse_16_011: Teaches compound verb structure (main + vector verbs) and aspectual nuances — essential for Diagnostic 4.  
c12_hin_a_cbse_17_011: Introduced Sanskrit declension basics (विभक्ति) — essential for parsing the लक्ष्मी paradigm.  
c12_hin_ar_cbse_01_011: Builds comparative grammar skills across poets.  
c12_hin_ar_cbse_02_011: Further practice with poetic grammar in third chapter.  
c12_hin_ar_cbse_03_011: Provides foundational practice in grammatical analysis of Hindi literary texts.  
c12_hin_ar_cbse_07_011: Exposure to nksgk and pkSikbZ in earlier poems.  
c12_hin_ar_cbse_09_011: Builds cumulative exposure to syntactic patterns in Hindi poetry.  
c12_hin_ar_cbse_10_011: Introduction to samasa-vigrah in literary context (Chapter 3).  
c12_hin_ar_cbse_11_011: Builds code-mixing identification skills  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
none

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_03_010 -> c11_hin_ar_cbse_03_011 -> c11_hin_ar_cbse_03_012

## THIS_FORMULA
N/A - conceptual

## FORMULA_VARIABLES
N/A

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
linguistic

## CROSS_SUBJECT
c11_history_colonialism | The chapter's tension between dialect (Avadhi) and standard Hindi mirrors colonial-era language politics where "Hindustani" was standardized, marginalizing regional varieties — grammatical analysis here develops skills to read language as a site of power.  
c11_sociology_rural_urban | Honorific/pronoun shifts in the text reflect changing kinship structures and rural-to-urban migration; sociological concepts of "primary/secondary groups" map onto the "वीं/आप" distinction analyzed linguistically.

## PREREQ_CONCEPT
Students must understand the difference between **tense** (time reference) and **aspect** (viewpoint on action completion) — e.g., perfective vs. completive — as taught in Class 10 Hindi grammar (क्रिया काल व पक्ष).

## PREREQ_BEFORE
Ability to identify main verb + vector verb in compound verbs (e.g., "चल दिया" = चल + दिया) and to recognize three honorific levels in Hindi pronouns (तू / तुम / आप).

## PREREQ_STUCK
If stuck, review Class 10 "क्रिया के भेद" (especially संयुक्त क्रिया) and "सर्वनाम के भेद" (पुरुषवाचक सर्वनाम में सम्मान सूचकता) using NCERT grammar workbook exercises 12-15.

## WORKED_EXAMPLE_1
PROBLEM: In the opening paragraph (page 32), the narrator writes: "वीं खटिया पर बैठ गयीं।" Later, in rehearsal scene: "वीं बोलीं, 'बैठ जाओ।'" Analyze the grammatical shift in the verb forms for "sit" and explain its narrative function.  
STEPS:  
- Step 1: Identify the two verb forms — "बैठ गयीं" (compound verb, perfective completive, 3rd person plural honorific) vs. "बैठ जाओ" (compound verb, imperative mood, 2nd person plural honorific).  
- Step 2: Note the person/number shift — narrative uses 3rd person (reporting Vee's action); dialogue uses 2nd person (Vee addressing children).  
- Step 3: Compare aspect — both are completive ("गयीं", "जाओ" as vector), but narrative views the event *retrospectively* (completed past), while dialogue projects *immediate future compliance*.  
- Step 4: Connect to narrative function — the shift enacts the transition from **narrator's memory** (observing Vee's frailty: "बैठ गयीं" implies effort) to **Vee's authority** (directing others despite frailty).  
- Step 5: Verify with context — the paragraph describes Vee's physical difficulty; "गयीं" captures that completed effort. The imperative "जाओ" shows her undiminished directorial voice.  
REASONING: This analysis moves beyond labeling to showing how grammar *distributes agency* — the same root "बैठ" carries different modal force depending on syntactic packaging, revealing character through form.  
ANSWER: The shift from 3rd-person perfective completive ("बैठ गयीं") to 2nd-person imperative completive ("बैठ जाओ") moves the reader from *witnessing Vee's bodily limitation* to *hearing her undiminished social authority*, using aspectual consistency (completive) to bind the two moments while mood/person reconfigures the power dynamic.

## WORKED_EXAMPLE_2
PROBLEM: The text uses "ओझल" (disappeared/vanished) as a predicate adjective in "वीं ओझल हो गयीं" but as an adverbial in "ओझल होती गयी". Distinguish the grammatical roles and argue how each shapes the depiction of Vee's fading presence.  
STEPS:  
- Step 1: Parse "ओझल हो गयीं" — "ओझल" = predicative adjective (subject complement) linked by copular vector "हो गयीं" (change-of-state completive). Subject: "वीं".  
- Step 2: Parse "ओझल होती गयी" — "ओझल" = adverbial modifier of the verb "होती गयी" (progressive aspect + vector "गयी" = gradual progression). No separate subject; implied "she".  
- Step 3: Contrast aspectual focus — first: **punctual change-of-state** (she *became* vanished, a boundary crossing). Second: **gradual process** (she *was vanishing*, a continuum).  
- Step 4: Link to narrative tone — the first marks the *moment of loss* (finality); the second stretches the *act of losing* (prolonged grief).  
- Step 5: Evaluate authorial choice — the text uses both to layer time: the sudden absence (punctual) embedded in the slow erosion (gradual), mirroring how memory works.  
REASONING: Grammatical category (adjective vs. adverb) + aspect (completive vs. progressive) creates a *temporal texture* that a single lexical item cannot — the grammar *performs* the phenomenology of disappearance.  
ANSWER: "ओझल हो गयीं" (predicative adjective + completive) frames disappearance as a **completed event** — the instant Vee exits the visible world. "ओझल होती गयी" (adverbial + progressive) frames it as a **protracted process** — the slow fading of her presence from the narrator's life. Together, they enact the dual temporality of grief: the sharp moment of death and the long aftermath of absence.

## WORKED_EXAMPLE_3
PROBLEM: The narrator describes the village elders: "वे सब 'आप' कहकर बुलाते थे।" But with Vee: "मैं उन्हें 'वीं' कहता था।" Using sociolinguistic concepts of **solidarity** and **power**, explain how this pronoun/honorific contrast structures the social map of the story.  
STEPS:  
- Step 1: Define the two address systems — System A: "आप" (plural honorific) = **high power distance, low solidarity** (formal, public, inter-generational respect). System B: "वीं" (kin-term, singular intimate) = **zero power distance, maximal solidarity** (family, private, affective).  
- Step 2: Map onto characters — Elders = public sphere representatives (teachers, priests, officials); Vee = private sphere anchor (grandmother, oral tradition bearer).  
- Step 3: Analyze narrator's positioning — He *code-switches*: uses System A with elders (showing deference to institutional authority), System B with Vee (claiming kinship intimacy). This dual competence marks him as **boundary-crosser** — the one who can navigate both worlds.  
- Step 4: Connect to plot — The rehearsal scenes require him to translate between registers: elders' "आप" language of bureaucracy vs. Vee's "वीं" language of tradition. His directorial role *is* this linguistic mediation.  
- Step 5: Extend to theme — The contrast encapsulates the chapter's central conflict: **standardized modernity (आप) vs. localized tradition (वीं)**. Grammar here is not decorative; it *is* the ideology.  
- Step 6: Synthesize for board answer — "The honorific contrast 'आप/वीं' constructs a sociolinguistic binary: public/formal vs. private/intimate. The narrator's fluent code-switching positions him as the mediator who sustains tradition within modernity, making grammar the site where the story's central tension is enacted."  
REASONING: This integrates grammatical form (pronoun/honorific), pragmatic function (solidarity/power), and thematic meaning (tradition/modernity) — the three-layer analysis expected in Class 12 board competency questions.  
ANSWER: The "आप/वीं" opposition indexes a **diglossic social structure**: "आप" encodes institutional power and distance (elders as public figures), while "वीं" encodes kinship solidarity and zero distance (Vee as private world). The narrator's bidirectional code-switching demonstrates his unique agency — he belongs to both orders, and his directorial work *is* the grammatical labor of translating between them. This makes honorific choice the structural metaphor for the chapter's theme of cultural preservation amid standardization.

## COMPETENCY_QUESTION_1
QUESTION: A student writes: "The author uses past tense throughout, so there is no grammatical variation to analyze." Using **two specific examples** from the text, refute this claim by showing how *aspect* and *mood* create variation within past-time reference.  
COMPETENCY: Grammatical analysis / Argumentation  
STEPS:  
- Step 1: Identify the student's error — conflating *tense* (past) with *aspect/mood* (completive, progressive, imperative, habitual).  
- Step 2: Select Example 1 — "वीं खाना खा **ली थीं**" (past perfective completive) vs. "वीं खाना **खाती थीं**" (past habitual). Explain: same past tense, different aspectual viewpoint (single completed event vs. repeated routine).  
- Step 3: Select Example 2 — Narrative "मैंने **देखा**" (past perfective) vs. Dialogue "'देखो', **बोलीं**" (past perfective verb but imperative mood in quoted speech). Explain: mood shift creates *voice* difference despite shared tense.  
- Step 4: Conclude — Grammatical variation in the text operates at **aspect** (completive/habitual/progressive) and **mood** (declarative/imperative/interrogative) layers, not tense alone.  
ANSWER: The claim is false. In "वीं खाना खा ली थीं" (completive aspect: focus on meal finished) vs. "वीं खाना खाती थीं" (habitual aspect: focus on daily ritual), both are past tense but convey opposite temporal perspectives — *bounded event* vs. *unbounded repetition*. Similarly, narrative "मैंने देखा" (declarative mood: reporting) coexists with Vee's quoted "देखो" (imperative mood: commanding) — same past-time frame, different illocutionary force. The text's richness lies precisely in this **aspect-mood density** within a consistent past-tense narrative.  
DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: The glossary defines "लखनवी तहज़ीब" as a cultural code. The text never uses this phrase, but its grammar *enacts* it. Identify **three grammatical features** from the chapter that perform "तहज़ीब" (refined courtesy) and explain how each operates as a **linguistic politeness strategy**.  
COMPETENCY: Sociolinguistic interpretation / Textual evidence integration  
STEPS:  
- Step 1: Feature 1 — **Honorific plural verb agreement with singular referent**: "वीं **बैठ गयीं**" (not "बैठ गयी"). Strategy: *Grammatical honorification* — elevating the subject via plural morphology, indexing respect without lexical change.  
- Step 2: Feature 2 — **Indirective speech acts**: "वीं बोलीं, 'बेटा, पानी **ला देना**'" (compound verb "ला देना" = benefactive vector). Strategy: *Mitigated directive* — "ला देना" (bring for me) softens the imperative "लाओ" by framing it as a favor, enacting *negative politeness* (minimizing imposition).  
- Step 3: Feature 3 — **Kinship-term address as pronoun substitute**: "वीं", "बाबूजी", "अम्मा" used *instead of* pronouns. Strategy: *Relational indexing* — kinship terms encode the relationship (grandmother, father, mother) every turn, constantly reaffirming the *social bond* that "आप/तुम" would abstract away.  
- Step 4: Synthesize — These three features (morphological honorification, benefactive mitigation, kinship-term recurrence) collectively construct a **grammar of तहज़ीब** where courtesy is built into the syntax, not added as polite words.  
- Step 5: Board-style conclusion — "The text performs लखनवी तहज़ीब through (1) plural verb agreement for singular elders, (2) benefactive compound verbs softening commands, (3) kinship terms replacing pronouns — each a grammaticalized politeness strategy that makes respect *structural* rather than *lexical*."  
ANSWER: Three grammatical enactments of तहज़ीब:  
1. **Plural verb for singular honorific subject** — "वीं बैठ गयीं" (not "बैठ गयी") — morphological respect marking.  
2. **Benefactive compound verb in directives** — "पानी ला देना" (not "पानी लाओ") — mitigates imposition via "for me" semantics.  
3. **Kinship terms as pronominal system** — "वीं/बाबूजी/अम्मा" replace "आप/तुम" — embeds relationship in every reference.  
Together, they make politeness *infrastructural* to the grammar, embodying लखनवी तहज़ीब as a syntactic habitus.  
DIFFICULTY: hard