## DEFINITION
Critical thinking in literary analysis is the disciplined process of examining a text's structural choices, linguistic patterns, and thematic layers to form an evidence-based interpretation that goes beyond surface comprehension, requiring the reader to question assumptions, identify contradictions, and evaluate the author's craft in shaping meaning.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student can independently deconstruct a stanza from "?kj dh ;kn" by identifying at least two literary devices, explaining their combined effect on tone, and connecting that effect to the poem's central theme of separation and memory, using textual evidence in a structured PEEL paragraph.

## SCOPE_BOUNDARY
This node covers deep analytical interpretation of "?kj dh ;kn" (Harivansh Rai Bachchan) focusing on structural repetition, symbolic imagery, and emotional progression across its 12 stanzas. It does NOT cover biography of the poet, historical context of Chhayavaad, or comparison with other poems — those belong to prerequisite nodes.

## WALKTHROUGH
Imagine you are listening to an old song that suddenly makes you miss your childhood home — the smell of the kitchen, the sound of your father's footsteps. That visceral pull is exactly what this poem engineers through language. Begin by reading the poem aloud twice: first for rhythm, second to mark every recurrence of "?kj" (home) and "ikuh" (long time). Notice how the repetition isn't decorative — it builds a tightening spiral of longing. Then isolate one stanza (e.g., stanza 4 with "pkj HkkbZ pkj cfgusa") and ask: why four walls, four doors? What does the number four evoke in Indian cultural memory? This moves you from *what* the poem says to *how* it makes you feel the poet's ache.

## DIAGNOSTIC_QUESTION_1
What is the primary structural device used in "?kj dh ;kn" to convey the passage of time and persistent memory?

## DIAGNOSTIC_ANSWER_1
The primary structural device is **anaphora** — the deliberate repetition of "ikuh fxj jgk gS" (long time has passed) and "?kj u”kj esa frj jgk gS" (a flame burns in the heart of the house) at the start of multiple stanzas. A wrong answer (e.g., "rhyme scheme" or "metaphor") reveals the student is confusing structural repetition with ornamental devices, missing how Bachchan uses syntactic parallelism to mimic the cyclical, obsessive nature of memory.

## DIAGNOSTIC_QUESTION_2
Explain in your own words why the poet describes the house as having "pkj HkkbZ pkj cfgusa" (four walls, four doors) rather than simply saying "a house."

## DIAGNOSTIC_ANSWER_2
The phrase "four walls, four doors" transforms the house from a generic dwelling into a **symbolic enclosure** — the four walls represent the fixed boundaries of childhood safety, while the four doors suggest both accessibility (to family) and escape (to the outside world). A student who answers "it describes the architecture" misses the symbolic compression: the number four invokes the *char-dham* (four pilgrimages) and *char-ashram* (four life stages) in Indian tradition, framing the home as a sacred, complete universe now lost.

## DIAGNOSTIC_QUESTION_3
Apply the concept of **juxtaposition** to compare the father's portrayal in stanza 5 ("firk th ftudks cq<+kik, dk.k Hkh ugha O;kik") with the poet's self-portrayal in stanza 9 ("ik¡pok¡ eSa gw¡ vHkkxk... c¡èkk cSBk gw¡ vHkkxk"). What does this contrast reveal about the poem's emotional core?

## DIAGNOSTIC_ANSWER_3
The father is depicted as **utterly depleted** ("cq<+kik" — broken, "dk.k Hkh ugha O;kik" — not a shred of strength), while the poet presents himself as **artificially fortified** ("vHkkxk" — strong, "c¡èkk cSBk" — sitting on a throne). This juxtaposition exposes the poet's guilt: his worldly success ("throne") is built on his father's silent sacrifice. A wrong answer that merely lists adjectives without linking them to the theme of *intergenerational debt* shows inability to synthesize character portrayal across stanzas.

## DIAGNOSTIC_QUESTION_4
Analyze how the shift from past tense ("jgk gS", "frj jgk gS") in early stanzas to future tense ("gsVsaxs", "iM+saxs") in later stanzas structures the poem's emotional trajectory.

## DIAGNOSTIC_ANSWER_4
The tense shift enacts a **movement from static longing to anticipated reunion**. Early stanzas use present continuous ("is passing", "is burning") to freeze the poet in perpetual separation. From stanza 7 onward, future tense ("will meet", "will call") projects a hypothetical return, revealing the poem's true engine: not memory alone, but the *fantasy of closure*. A student who only identifies tenses without explaining their narrative function treats grammar as labeling, not as a meaning-making tool.

## DIAGNOSTIC_QUESTION_5
Evaluate the claim: "The poem's ending ('er djks oqQN 'kksd dguk' — let someone say something true) resolves the poet's conflict by achieving authentic communication." Defend or refute with textual evidence.

## DIAGNOSTIC_ANSWER_5
**Refute.** The final stanza *intensifies* the conflict: "er djks oqQN 'kksd dguk" is a desperate plea for *any* truthful utterance because the poet realizes **language itself has failed** — "dke djrk gw¡ fd dguk / uke djrk gw¡ fd dguk" (I work to speak / I name to speak) shows speech reduced to mechanical function. The poem ends not with resolution but with the haunting awareness that even "true words" cannot bridge the physical absence. A student agreeing with the claim confuses *thematic yearning* for *narrative closure*.

## DIAGNOSTIC_QUESTION_6
Create a four-line stanza in the style of "?kj dh ;kn" that extends the poem's central metaphor of "home as a flame in the heart" into a modern context (e.g., migration, digital disconnect). Use anaphora and one concrete sensory image.

## DIAGNOSTIC_ANSWER_6
**Sample strong response:**
> "ikuh fxj jgk gS, skrin ij tks ?kj jgk gS
> ?kj u”kj esa frj jgk gS, piksls ds ?kj esa
> pkj HkkbZ pkj cfgusa, ab nOtiphikeshDV dh txg
> gk; js] ikuh fxj jgk gS — Wi-Fi dk ekSgYys gS"
**Why it works:** Retains anaphora ("ikuh fxj jgk gS / ?kj u”kj esa frj jgk gS"), substitutes "four walls/doors" with "notification screens" (concrete sensory modern equivalent), and ends with ironic metaphor (Wi-Fi as fragile lifeline). A weak answer would merely describe missing home without mirroring the poem's structural DNA.

## COMMON_MISCONCEPTION
Students treat "critical analysis" as **listing devices** (e.g., "there is a metaphor in line 3, anaphora in line 5") rather than **explaining how devices interact to produce meaning**. In this poem, they often note the repetition of "?kj" but miss that its frequency *increases* in later stanzas (stanzas 1, 3, 5, 7, 9, 11) — a quantitative pattern that mirrors the *escalating* psychological pressure of memory. They also confuse the *father's voice* (stanzas 5, 7, 11) with the *poet's voice*, attributing the father's lines to the narrator.

## ON_FAILURE
1. **Re-read only stanzas 1, 5, 9, 11 aloud** — these are the structural pillars (poet's present, father's past, poet's fantasy, father's final blessing). 2. **Color-code**: highlight every "?kj" in yellow, every "ikuh" in blue, every tense marker in green. 3. **Write one sentence per color**: "Yellow shows the object of longing; blue shows its duration; green shows the shift from endurance to hope." 4. **Speak it**: explain the poem to a peer as if they've never read it, using only your color-coded notes. This forces synthesis over listing.

## BUILDS_ON
c11_hin_ar_cbse_11_012 (Comprehension: Literal and Inferential Questions) — students must first grasp literal events and infer basic emotions before analyzing how structure shapes those emotions.

## LEADS_TO
c11_hin_ar_cbse_11_014 (Writing Skills: Based on the Chapter) — analytical insights become raw material for structured long-answer writing (e.g., "Discuss how repetition constructs the theme of separation").

## PREREQUISITE_NODE_IDS
c11_hin_ar_cbse_11_008, c11_hin_ar_cbse_11_009, c11_hin_ar_cbse_11_010, c11_hin_ar_cbse_11_011, c11_hin_ar_cbse_11_012, c11_hin_ar_cbse_11_004, c11_hin_ar_cbse_11_005, c11_hin_ar_cbse_11_006, c11_hin_ar_cbse_11_007

## PREREQUISITE_REASONS
c11_hin_ar_cbse_11_008: Imagery and metaphor identification is needed to decode symbols like "frj" (flame) and "pkj HkkbZ" (four walls).
c11_hin_ar_cbse_11_009: Irony and symbolism understanding enables reading the "throne" (c¡èkk) as bitter irony, not literal power.
c11_hin_ar_cbse_11_010: Vocabulary in context (e.g., "cq<+kik", "vHkkxk", "yhd") is essential for precise character portrayal.
c11_hin_ar_cbse_11_011: Grammar knowledge (tense, aspect, imperative mood in final stanza) supports structural analysis.
c11_hin_ar_cbse_11_012: Literal/inferential comprehension provides the factual baseline (who speaks when, what happens) for higher analysis.
c11_hin_ar_cbse_11_004: Critical thinking questions demand synthesis of character, theme, and device — this node provides the character foundation.  
c11_hin_ar_cbse_11_005: Critical interpretation requires synthesising character-function evidence — e.g., "Is the house a character or a symbol?" — which this node's analytical framework enables.  
c11_hin_ar_cbse_11_006: Critical interpretation (e.g., "Is the poem nostalgic or anti-nostalgic?") requires a settled understanding of the primary theme as a baseline.  
c11_hin_ar_cbse_11_007: Critical interpretation requires synthesizing primary and secondary themes into a coherent reading; this node provides the thematic raw material.  

## FORWARD_NODE_IDS
c11_hin_ar_cbse_11_014, c11_hin_ar_cbse_11_015, c12_hin_a_cbse_11_013, c12_hin_al_cbse_02_013, c12_hin_ar_cbse_03_013, c12_hin_ar_cbse_11_013

## FORWARD_REASONS
c11_hin_ar_cbse_11_014: Writing skills require analytical depth — e.g., a 6-mark question "Analyze the use of repetition" demands the device-effect-theme chain practiced here.
c11_hin_ar_cbse_11_015: Speaking/listening discussions (e.g., "Is the ending hopeful?") need evidence-based interpretations, not opinions.
c12_hin_a_cbse_11_013: Class 11 critical thinking foundation (analysis of "Namak ka Daroga" etc.) provides the methodological template.  
c12_hin_al_cbse_02_013: Evaluated open endings in memoir.  
c12_hin_ar_cbse_03_013: अगला तार्किक चरण: Critical Thinking: इस नोड की अवधारणाओं को सीधे उपयोग/विस्तारित करता है।  
c12_hin_ar_cbse_11_013: Class 11 critical thinking node builds the analytical habit (claim-evidence-reasoning) this node advances.  

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_11_012 -> c11_hin_ar_cbse_11_013 -> c11_hin_ar_cbse_11_014: Comprehension provides facts; critical thinking transforms them into arguments; writing skills package arguments for board exams.

## THIS_FORMULA
N/A - conceptual

## FORMULA_VARIABLES
N/A

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
conceptual

## CROSS_SUBJECT
c11_history_nationalism | The poem's "home as sacred enclosure" mirrors early nationalist discourse (Bankim's *Anandamath*, Tagore's *Ghare Baire*) where the domestic sphere becomes a metaphor for the colonized nation — both use "four walls" to symbolize a threatened cultural integrity.
c11_psychology_memory | The anaphoric repetition ("ikuh fxj jgk gS") mimics **involuntary autobiographical memory** (Berntsen, 2009) — cue-driven, recurrent, emotionally charged — offering a literary case study for memory's non-linear persistence.

## PREREQ_CONCEPT
Student must understand that **literary devices are not decorative but functional** — each repetition, tense shift, or symbol serves a specific thematic purpose in Bachchan's architecture.

## PREREQ_BEFORE
Student can identify anaphora, metaphor, juxtaposition, and tense in isolation (from nodes 008, 009, 011) and answer inferential questions about character emotions (node 012).

## PREREQ_STUCK
If stuck, review **c11_hin_ar_cbse_11_009 (Irony and Symbolism)** — specifically the difference between *symbol* (object representing idea) and *irony* (gap between appearance and reality) — using the "throne vs. broken father" contrast as practice.

## WORKED_EXAMPLE_1
PROBLEM: Analyze how the metaphor "?kj u”kj esa frj jgk gS" (a flame burns in the heart of the house) evolves across stanzas 1, 3, and 5 to reflect the poet's changing relationship with memory.

STEPS:
- Step 1: Locate the metaphor in each target stanza. Stanza 1: "?kj u”kj esa frj jgk gS" appears as a declarative fact. Stanza 3: Repeated identically but now preceded by "?kj fd ?kj esa pkj HkkbZ" — the flame is housed within a defined structure. Stanza 5: The flame imagery disappears; replaced by "firk th ftudks cq<+kik" — the father *is* the extinguished flame.
- Step 2: Identify the shift in agency. Stanza 1: The flame burns autonomously ("frj jgk gS" — exists independently). Stanza 3: The flame is contained by architecture ("pkj HkkbZ pkj cfgusa" — walls/doors control it). Stanza 5: The flame is *gone* — the father's brokenness ("cq<+kik") means the house's heart has no fire.
- Step 3: Connect to emotional trajectory. The metaphor moves from **memory as living presence** (stanza 1) → **memory as preserved relic** (stanza 3) → **memory as lost source** (stanza 5). The poet doesn't just miss the house; he misses the *vitality* the father embodied.
- Step 4: Verify with textual neighbors. Stanza 2's "cfgu vkbZ cki osQ ?kj" (mother's lap is the house) confirms the flame = parental love. Stanza 4's "nq%[k esa og x<+h esjh" (that laughter of mine in the courtyard) shows the flame once warmed the poet directly.
- Step 5: Formulate the analytical claim. The metaphor's **progressive domestication and eventual extinction** mirrors the poet's realization that he cannot return to the *living* home — only to its ashes.

REASONING: This works because it tracks a single image across structural intervals, showing how Bachchan uses metaphor not as static decoration but as a dynamic indicator of psychological change — exactly what board exams reward in "analyze the development of a symbol" questions.

ANSWER: The flame metaphor evolves from autonomous presence (stanza 1) to architecturally contained memory (stanza 3) to extinguished source (stanza 5), charting the poet's shift from feeling the home's warmth to recognizing its irreversible loss. The father's broken body ("cq<+kik") replaces the flame as the poem's central image, transferring the "heart of the house" from an abstract symbol to a human casualty.

## WORKED_EXAMPLE_2
PROBLEM: The poem uses the imperative mood only in the final two lines: "er djks oqQN 'kksd dguk". Explain why this sudden grammatical shift is the poem's structural climax.

STEPS:
- Step 1: Scan the poem for mood. Stanzas 1-11: entirely indicative ("jgk gS", "frj jgk gS", "cq<+kik", "vHkkxk", "gsVsaxs") — descriptive, narrative, speculative. No commands, no direct address.
- Step 2: Identify the addressee of the imperative. "er djks oqQN 'kksd dguk" — "let someone say something true." The vagueness ("er" = someone, anyone) is deliberate: the poet addresses the universe, God, or the reader — not a specific person.
- Step 3: Analyze the semantic weight of "'kksd" (true/authentic). Earlier, language is performative: "dke djrk gw¡ fd dguk / uke djrk gw¡ fd dguk" (I work to speak / I name to speak) — speech as social ritual. "'kksd" demands speech that *corresponds to reality* — the reality of separation, guilt, love.
- Step 4: Connect to the poem's central silence. The father never speaks directly; his voice is ventriloquized by the poet (stanzas 5, 7, 11). The mother is silent. The poet's own speech is "yhd" (false/artificial). The imperative erupts because **all prior speech has failed to bridge the gap**.
- Step 5: Evaluate structural position. Placing the *only* imperative at the very end denies resolution — it's a cry *into* silence, not a dialogue. The poem ends on a demand for truth that the poem itself cannot supply.

REASONING: This analysis moves beyond "identify the imperative" to "explain why its isolation and placement enact the theme of communicative failure" — the kind of grammatical-thematic synthesis expected in 6-mark board questions.

ANSWER: The imperative "er djks oqQN 'kksd dguk" is the structural climax because it is the poem's sole direct speech act, demanding authentic utterance after 11 stanzas of descriptive/performative language. Its vagueness ("er") and placement (final line) enact the poet's isolation: he commands truth into a void, confirming that language — even poetic language — cannot restore the lost home.

## WORKED_EXAMPLE_3
PROBLEM: Synthesize nodes 008 (Imagery), 009 (Symbolism), and 012 (Inference) to answer: "How does Bachchan use the *courtyard* (nq%[k) as a polysemous symbol that binds the poem's temporal layers?" (6-mark board-style question)

STEPS:
- Step 1 (Imagery - node 008): Catalog all courtyard references. Stanza 4: "nq%[k esa og x<+h esjh" (my laughter in the courtyard) — sensory: sound of child's joy. Stanza 6: "tc fd uhps vk, gksaxs / uSu ty ls Nk, gksaxs" (when they come down / they will meet from the sky) — courtyard as future meeting ground. Stanza 10: implied in "ik¡posa dks os u rjlsa" (don't let the thresholds burn) — thresholds *are* the courtyard's edges.
- Step 2 (Symbolism - node 009): Decode polysemy. Literal: physical space of childhood play. Metaphorical: **liminal zone** between inside (family) and outside (world). Cultural: *aangan* as site of rituals (birth, marriage, death) — the "four doors" open *onto* it. Temporal: past (laughter), present (empty), future (reunion).
- Step 3 (Inference - node 012): Infer emotional stakes. The courtyard is where the poet *was* whole ("x<+h esjh" — my laughter). Its emptiness now ("gk; js] ikuh fxj jgk gS") measures the loss. The future reunion ("uSu ty ls Nk, gksaxs") *must* happen there — otherwise it's not *home*.
- Step 4: Synthesize across layers. The courtyard **anchors the poem's time travel**: it is the fixed coordinate that makes "past," "present," and "future" meaningful. Without it, "home" is abstract; with it, home is a place you can stand in.
- Step 5: Draft the PEEL paragraph. **Point**: The courtyard functions as the poem's spatio-temporal anchor. **Evidence**: "nq%[k esa og x<+h esjh" (stanza 4) vs. "uSu ty ls Nk, gksaxs" (stanza 6). **Explanation**: The same physical space holds the poet's past joy and his imagined future redemption, making the present absence palpable. **Link**: This spatial fixity contrasts with the fluidity of memory ("ikuh fxj jgk gS"), proving the home is not a feeling but a *place* — and the poet is exiled from it.
- Step 6: Refine for board answer. Add terminology: "polysemous symbol," "liminal space," "temporal collapse." Ensure each claim has a line reference.

REASONING: This models the **multi-node synthesis** required for high-mark questions — not just "what does the courtyard mean?" but "how do imagery, symbolism, and inference *together* construct its meaning?" The 6-step structure mirrors the 6-mark allocation.

ANSWER: The courtyard (nq%[k) is a polysemous symbol binding the poem's temporal layers: as **sensory imagery** it stores the poet's childhood laughter (stanza 4); as **cultural symbol** it is the liminal *aangan* where family rituals occur (invoked by "pkj cfgusa" in stanza 3); as **inferred emotional center** it becomes the mandatory site of future reunion (stanza 6). Its fixity ("four doors" opening onto it) contrasts with memory's fluidity ("ikuh fxj jgk gS"), making the poet's exile spatial, not just temporal. The courtyard *is* the home — and the poet stands outside it.

## COMPETENCY_QUESTION_1
QUESTION: A student writes: "The repetition of 'ikuh fxj jgk gS' shows the poet is sad for a long time." Using the concept of **anaphora as structural pacing**, explain why this answer is insufficient for a 4-mark question and rewrite it to meet board standards.

COMPETENCY: Critical evaluation of peer response / metacognitive awareness of answer quality

STEPS:
- Step 1: Identify the gap. The student states *effect* (sadness) but not *mechanism* — how does the repetition *create* that sadness structurally?
- Step 2: Define the missing concept. Anaphora here controls **temporal pacing** — each recurrence forces the reader to re-experience the "long time," making the duration *felt*, not just reported.
- Step 3: Add quantitative precision. The phrase opens 6 of 12 stanzas (1, 3, 5, 7, 9, 11) — a 50% recurrence rate that imposes a rhythmic inevitability.
- Step 4: Connect to theme. The pacing mirrors memory's **intrusive recurrence** — not a steady sadness, but waves that return despite the poet's will.
- Step 5: Rewrite with PEEL. **Point**: Anaphora enacts the involuntary return of memory. **Evidence**: "ikuh fxj jgk gS" opens alternate stanzas, creating a 6-beat pulse across the poem. **Explanation**: This structural rhythm mimics how traumatic memory bypasses voluntary control — the poet *cannot stop* returning to the duration. **Link**: Thus repetition is not decorative; it is the poem's formal embodiment of psychological compulsion.

ANSWER: The original answer fails because it describes *theme* (sadness) without analyzing *form* (how anaphora structures time). Board-standard rewrite: "Bachchan deploys anaphora ('ikuh fxj jgk gS' opening 6 of 12 stanzas) as structural pacing — the 6-beat recurrence forces the reader into the poet's involuntary memory loops, making the 'long time' viscerally experiential rather than merely reported. The device *enacts* the compulsion it describes."

DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: The poem's final stanza has been read as both a **prayer** ("er djks oqQN 'kksd dguk") and a **poetic manifesto** ("dke djrk gw¡ fd dguk / uke djrk gw¡ fd dguk"). Construct a 150-word argument defending *one* reading while acknowledging the other, using at least three textual anchors from stanzas 9-12.

COMPETENCY: Argumentative writing with textual evidence / nuanced interpretation

STEPS:
- Step 1: Choose a stance. Defend **poetic manifesto** — the stanza defines the poet's vocation in the face of failure.
- Step 2: Select three anchors. (1) "dke djrk gw¡ fd dguk / uke djrk gw¡ fd dguk" — speech as labor/naming. (2) "gs lthys gjs lkou / gs fd esjs iq.; ikou" — aligning speech with breath and life-force. (3) "er djks oqQN 'kksd dguk" — the *demand* for truth as professional ethic.
- Step 3: Acknowledge the counter-reading. The address to an unspecified "er" (someone) and the invocation of "Hkokuh" (the poet's pen name, stanza 11) *resembles* prayer — but "Hkokuh" here means "the poet," not God.
- Step 4: Structure the argument. Opening thesis → Anchor 1 (speech as work) → Anchor 2 (speech as vitality) → Anchor 3 (truth as standard) → Concession (prayer-like tone) → Rebuttal (secular, artistic commitment) → Closing synthesis.
- Step 5: Monitor word count and tone. Formal, analytical, no first-person opinion ("I think") — only "The text demonstrates," "The structure reveals."

ANSWER: The final stanza functions primarily as a **poetic manifesto**, defining literature as the discipline of truth-telling when ordinary language fails. "Dke djrk gw¡ fd dguk / uke djrk gw¡ fd dguk" frames speech as *karma* — the poet's work is to speak, to name, even when naming cannot restore the lost home. "Gs lthys gjs lkou / gs fd esjs iq.; ikou" elevates this labor to ontology: speech *is* the poet's breath and pulse. The closing imperative "er djks oqQN 'kksd dguk" then sets the ethical benchmark — not comfort, but *truth* — as the only valid output of that labor. While the address to an unnamed "er" and the pen name "Hkokuh" (stanza 11) echo prayer's supplicatory tone, the content is resolutely secular: the poet demands truth from *himself* and his craft, not grace from a deity. The stanza thus closes the poem not with consolation but with a professional vow — the writer's duty to articulate the unsayable.

DIFFICULTY: hard