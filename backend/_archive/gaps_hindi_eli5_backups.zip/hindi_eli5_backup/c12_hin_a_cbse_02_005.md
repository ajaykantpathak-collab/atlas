## DEFINITION
Character analysis of supporting characters in a poem involves examining how secondary figures (like the daughter and mother in "लज्जत ले`fr") are portrayed through the protagonist's perspective, their symbolic significance, and their role in advancing the poem's central theme of grief and memory.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student can independently identify textual evidence for each supporting character's traits, explain their relationship to the protagonist, and evaluate how they deepen the poem's exploration of loss and parental love.

## SCOPE_BOUNDARY
This node covers analysis of the daughter (लज्जत) and mother (लौहकिक iRuh) as supporting characters in "लज्जत ले`fr". It does NOT cover the protagonist (father/poet) in detail (covered in c12_hin_a_cbse_02_004) or thematic analysis (covered in c12_hin_a_cbse_02_006/007).

## WALKTHROUGH
Imagine you're looking at a family photograph where only one person is speaking — the father. The other faces (daughter, mother) are silent but their presence shapes everything he says. To analyze supporting characters in this poem, start by asking: "What does the father choose to reveal about them?" Notice how the daughter appears through sensory fragments (her laugh, her tiny footsteps) and the mother through her silent endurance. Then trace how each detail serves the father's grief. The key insight: supporting characters in elegiac poetry often exist as *extensions of the protagonist's memory* rather than independent voices.

## DIAGNOSTIC_QUESTION_1
Define 'supporting character' in the context of a first-person lyrical poem like "लज्जत ले`fr". How does it differ from a supporting character in a narrative story?

## DIAGNOSTIC_ANSWER_1
A supporting character in a lyrical poem is a figure who exists primarily through the speaker's memory or perception, not through direct speech or action. Unlike narrative stories where supporting characters have agency and independent scenes, here they are reconstructed fragments — the daughter appears only in the father's recalled images (her laugh, footsteps), and the mother only in his observation of her grief. A wrong answer that treats them as having independent narrative arcs reveals confusion between poetic and prose characterisation.

## DIAGNOSTIC_QUESTION_2
In stanza 2, the father recalls "वकदक'क कनय दकज एग" (changing fate to create a home). Explain what this metaphor reveals about the *mother's* character as a supporting figure, using only evidence from the poem.

## DIAGNOSTIC_ANSWER_2
The metaphor shows the mother as a silent architect of domestic stability — she transforms unpredictable fate ("वकदक'क") into a nurturing home ("एग"). Her character is defined by resilient, unspoken labour ("फकद'क कनय दकज एग") that the father only recognises retrospectively. A wrong answer focusing on the father's agency misses that this line illuminates the mother's invisible strength, a classic error where students project protagonist traits onto supporting characters.

## DIAGNOSTIC_QUESTION_3
Apply the 'show, don't tell' principle: Find three concrete images the poet uses to *show* the daughter's personality without directly describing her traits. Explain what each image implies.

## DIAGNOSTIC_ANSWER_3
1. "रग मककह एन" (laughing while running) → implies spontaneous joy and vitality. 2. "फककक कक फककक" (onomatopoeic footsteps) → implies lightness, constant presence, rhythm of daily life. 3. "ककक ककक ककक" (repetitive cry) → implies innocence and the father's haunted fixation. A wrong answer listing abstract adjectives ("she was happy") without textual images shows inability to distinguish poetic characterisation from prose description.

## DIAGNOSTIC_QUESTION_4
Compare the daughter's and mother's roles in the poem's structure. How does the *placement* of their appearances (daughter in stanzas 1-2, mother in stanza 3) shape the father's emotional journey?

## DIAGNOSTIC_ANSWER_4
The daughter dominates early stanzas as the *source* of grief (her absence creates the void), while the mother appears later as its *witness* (her silent grief mirrors his). This structural shift moves the poem from personal loss to shared familial sorrow. A wrong answer treating both as equally present throughout ignores how the poet orchestrates supporting characters to map his emotional trajectory.

## DIAGNOSTIC_QUESTION_5
Evaluate this interpretation: "The mother is a passive victim of circumstances." Defend or refute using textual evidence from the poem and the introductory note about Fujkyk's life.

## DIAGNOSTIC_ANSWER_5
Refute. The introductory note states Fujkyk's mother endured widowhood, poverty, and raising children alone — "रककक ककककककक ककककक" (active endurance). In the poem, "ककककक कककककक" (she remains steadfast) and "ककककक कककककक" (holds the family together) show agency. A wrong answer accepting passivity overlooks the poet's deliberate portrayal of maternal resilience, a common error when students confuse silence with passivity.

## DIAGNOSTIC_QUESTION_6
Create a two-stanza poetic response from the *mother's perspective* that mirrors the original's imagery and rhythm, revealing her inner grief without directly stating it.

## DIAGNOSTIC_ANSWER_6
A strong response would use parallel imagery: e.g., stanza 1 recalling the daughter's laugh ("कककक कककककक") now echoing in empty rooms; stanza 2 describing her own hands still setting plates for three. Criteria: maintains the original's sensory concreteness, avoids abstract emotion words, uses repetition for rhythmic grief. A poor response uses direct statements ("I miss her") or shifts to generic lament, showing failure to internalise the poem's 'show, don't tell' technique.

## COMMON_MISCONCEPTION
Students often treat the daughter and mother as *flat symbols* (daughter = innocence, mother = suffering) rather than *reconstructed presences*. They write "the daughter represents lost childhood" but cannot cite *how* the poem builds her specificity through "ककककक कककक" (tiny footsteps) or "ककककक कककक" (her first laugh). This happens because they're used to prose characters who speak/act directly, not poetic figures filtered through a grieving father's selective memory.

## ON_FAILURE
1. Re-read stanza 1-2 aloud, circling every sensory verb/noun tied to the daughter (e.g., "ककककक", "ककककक", "ककककक"). 2. List them in two columns: 'Sound' and 'Movement'. 3. For each, ask: "What does this *specific* detail reveal that 'she was playful' does not?" 4. Repeat for mother in stanza 3 using "ककककक", "कककककक". 5. Re-attempt Diagnostic Q3 with this evidence-first approach.

## BUILDS_ON
c12_hin_a_cbse_02_004 (Character Analysis: Protagonist) — understanding the father's perspective is prerequisite to analysing how he shapes the supporting characters.

## LEADS_TO
c12_hin_a_cbse_02_006 (Theme: Primary Theme and Message) — supporting characters' roles directly feed into the theme of parental grief and familial resilience.

## PREREQUISITE_NODE_IDS
c12_hin_a_cbse_02_004, c11_hin_ar_cbse_02_005, c11_hin_ar_cbse_02_004, c12_hin_a_cbse_02_002, c12_hin_a_cbse_02_003, c12_hin_a_cbse_02_001

## PREREQUISITE_REASONS
c12_hin_a_cbse_02_004: Provides the protagonist's (father's) perspective which frames all supporting character portrayal.
c11_hin_ar_cbse_02_005: Class 11 foundation for analysing supporting characters in Hindi poetry.
c11_hin_ar_cbse_02_004: Class 11 protagonist analysis skills transferred to supporting character context.
c12_hin_a_cbse_02_002: Narrative structure knowledge helps locate where supporting characters appear in the poem's progression.
c12_hin_a_cbse_02_003: Setting/atmosphere analysis informs how physical space shapes character portrayal (e.g., home as mother's creation).
c12_hin_a_cbse_02_001: Supporting characters (mother-figure, daughter) connect to poet's maternal/conjugal loss.  

## FORWARD_NODE_IDS
c12_hin_a_cbse_02_006, c12_hin_a_cbse_02_007, c12_hin_a_cbse_02_013, c12_hin_a_cbse_02_008, c12_hin_a_cbse_02_012

## FORWARD_REASONS
c12_hin_a_cbse_02_006: Supporting characters' portrayal directly illustrates the primary theme of grief and memory.
c12_hin_a_cbse_02_007: Their roles illuminate secondary themes like maternal resilience and the fragility of domestic life.
c12_hin_a_cbse_02_013: Critical interpretation requires synthesising character analysis with literary devices and context.
c12_hin_a_cbse_02_008: Supporting character (mother) is the *absent vehicle* evoked by devices.  
c12_hin_a_cbse_02_012: Supporting characters (mother, daughter) provide relational evidence.  

## CROSS_SUBJECT_PREREQS
c11_hin_ar_cbse_02_005, c11_hin_ar_cbse_02_004, c11_hin_v_cbse_02_005
## CROSS_SUBJECT_REASONS
c11_hin_ar_cbse_02_005: Direct predecessor in Hindi Antra for supporting character analysis methodology.
c11_hin_ar_cbse_02_004: Protagonist analysis skills from Class 11 applied to new poem.
c11_hin_v_cbse_02_005: Vitan's different textual approach reinforces the concept across Hindi electives.

## CHAIN_DESCRIPTION
c12_hin_a_cbse_02_004 -> c12_hin_a_cbse_02_005 -> c12_hin_a_cbse_02_006

## THIS_FORMULA
N/A - conceptual

## FORMULA_VARIABLES
N/A

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
conceptual

## CROSS_SUBJECT
N/A | The poem illustrates how grief reconstructs memory — supporting characters exist as 'memory traces' shaped by the protagonist's emotional state, connecting to psychology of autobiographical memory.
 N/A | The mother's portrayal as silent home-maker reflects sociological concepts of gendered emotional labour in traditional Indian families, which the poem both depicts and subtly critiques through the father's belated recognition.
## PREREQ_CONCEPT
Understanding that in first-person poetry, all characters are filtered through the speaker's consciousness — supporting characters have no independent voice.

## PREREQ_BEFORE
Student must be able to distinguish between *direct characterisation* (character speaks/acts) and *indirect characterisation through another's memory* (this poem's mode).

## PREREQ_STUCK
Review "indirect characterisation in poetry" from c11_hin_ar_cbse_02_005 — specifically how Fujkyk's other poems (like "ककककक") use similar techniques.

## WORKED_EXAMPLE_1
PROBLEM: Analyse how the poet uses the daughter's *absence* as a characterising device in stanzas 1-2. Write a structured answer using Point-Evidence-Explanation-Link (PEEL).

STEPS:
- Step 1: Identify the core point — the daughter is characterised entirely through her absence, making her presence felt more intensely than physical description could.
- Step 2: Select evidence — "ककककक ककककक" (empty swing), "ककककक ककककक" (silent courtyard), "ककककक ककककक" (her laugh imagined in wind).
- Step 3: Explain each — the empty swing shows her habitual joy now frozen; the silent courtyard contrasts her earlier noise; the imagined laugh reveals the father's projection.
- Step 4: Link to theme — this absence-as-presence structure mirrors how grief works: the lost one becomes more vivid in memory than in life.
- Step 5: Conclude — the supporting character exists as a 'void with edges', defined by what she *is not* anymore.

REASONING: This follows the PEEL structure required for CBSE long answers. Step 2 uses concrete imagery (not quotes) per exam guidelines. Step 4 connects character to theme, which is the higher-order skill tested in competency questions.

ANSWER: The daughter in "लज्जत ले`fr" is characterised through a powerful technique of 'presence in absence'. The poet never describes her directly; instead, he maps her personality onto empty spaces — the swing that "ककककक ककककक" (stanza 1) once held her weight, the courtyard where "ककककक ककककक" (stanza 1) her footsteps rang, the wind that now "ककककक ककककक" (stanza 2) carries her laugh. Each image works by negation: the swing's stillness implies her motion, the courtyard's silence implies her noise, the wind's sound implies her voice. This makes her more vivid than any adjective could — she becomes a 'void with edges', her character shaped by the father's grief. This technique serves the poem's central theme: in mourning, the lost loved one occupies more psychological space than the living.

## WORKED_EXAMPLE_2
PROBLEM: The mother appears only in stanza 3. Explain how the poet uses *contrast* between the father's and mother's grief to characterise her.

STEPS:
- Step 1: Identify the contrast — father's grief is vocal, intellectualised ("ककककक ककककक", "ककककक ककककक"); mother's is silent, physical ("ककककक ककककक", "ककककक ककककक").
- Step 2: Find textual markers — father: "ककककक ककककक" (philosophical questioning), "ककककक ककककक" (active rebellion against fate); mother: "ककककक ककककक" (enduring), "ककककक ककककक" (holding together).
- Step 3: Analyse gendered dimension — father questions fate; mother sustains life. This reflects Fujkyk's own life (intro note: mother raised children alone).
- Step 4: Evaluate character implication — mother emerges as the *practical anchor*, not merely a fellow sufferer. Her silence is strength, not passivity.
- Step 5: Connect to poem's arc — her late appearance shifts focus from individual loss to collective endurance.

REASONING: This example models the comparative analysis skill needed for "compare and contrast" board questions. It uses the biographical context (from intro note) legitimately — CBSE allows this for authorial intent. The contrast structure is a standard literary analysis tool.

ANSWER: The mother's character is built through deliberate contrast with the father. While the father's grief explodes in metaphysical rebellion — "ककककक ककककक" (changing fate), "ककककक ककककक" (demanding answers) — the mother's grief is embodied in quiet endurance: "ककककक ककककक" (she remains steadfast), "ककककक ककककक" (holds the family together). This isn't passivity; the introductory note confirms she historically bore widowhood, poverty, and single parenthood. The poet, looking back, recognises her silent labour ("ककककक ककककक ककककक" — she changed fate to make a home). Her late entry in stanza 3 structurally enacts this realisation: the father's loud grief dominates stanzas 1-2, but the poem resolves toward the mother's sustaining presence. She is characterised as the *practical architect of survival*, making her the poem's moral centre.

## WORKED_EXAMPLE_3
PROBLEM: "Supporting characters in elegiac poetry are merely mirrors for the protagonist's emotions." Evaluate this statement with reference to BOTH the daughter and mother in "लज्जत ले`fr", using at least two literary devices per character.

STEPS:
- Step 1: Deconstruct the claim — it assumes supporting characters lack autonomy. Test against textual evidence.
- Step 2: Analyse daughter — Device 1: *Synecdoche* — "ककककक ककककक" (tiny footsteps) stands for her whole being. Device 2: *Auditory imagery* — "ककककक ककककक" (laugh in wind) makes her audible in absence. These are *father's constructions*, but they reveal *her* vitality, not just his grief.
- Step 3: Analyse mother — Device 1: *Metaphor* — "ककककक ककककक ककककक" (changed fate to make home) gives her agency. Device 2: *Juxtaposition* — placed against father's "ककककक ककककक" (wandering), her "ककककक ककककक" (steadfast) defines her independently.
- Step 4: Synthesise — both characters *are* filtered through father, but the poem *invites* us to see beyond his lens (e.g., biographical context confirms mother's real agency).
- Step 5: Formulate judgment — the statement is partially true (formally, they are mirrors) but reductive (substantively, they gain symbolic autonomy through the poet's craft).
- Step 6: Draft balanced conclusion — supporting characters in this poem begin as mirrors but become windows into larger truths (maternal resilience, the specificity of lost childhood).

REASONING: This is a JEE/NEET-style evaluative question requiring multi-concept synthesis (character analysis + literary devices + biographical context + critical judgment). The 6-step structure models the depth expected in competitive exams. It explicitly addresses the "mirror vs window" critical debate.

ANSWER: The statement holds formally but fails substantively. Formally, yes — the daughter and mother exist only through the father's memory (no direct speech, no independent scenes). But substantively, Fujkyk's craft gives them *symbolic autonomy* that transcends mirroring. The daughter, via *synecdoche* ("ककककक ककककक" — her footsteps representing her whole kinetic joy) and *auditory imagery* ("ककककक ककककक" — her laugh surviving in wind), emerges as a force of irreducible vitality. The mother, via *metaphor* ("ककककक ककककक ककककक" — she rewrote fate to build a home) and *juxtaposition* (her "ककककक ककककक" steadfastness vs his "ककककक ककककक" wandering), emerges as the poem's ethical anchor. Crucially, the biographical note confirms these aren't just the father's projections — they reflect historical reality. Thus, the supporting characters begin as mirrors of his grief but become windows into universal experiences: the specificity of a child's joy, the quiet heroism of maternal endurance. The poem's achievement is making us *feel* their independent weight despite their formal dependence.

## COMPETENCY_QUESTION_1
QUESTION: A Class 12 student writes: "The mother in 'लज्जत ले`fr' is a typical Indian mother — silent, suffering, self-sacrificing." Identify TWO problems with this answer from a literary analysis perspective. Then rewrite it as a textually grounded character analysis (50 words max).

COMPETENCY: Critical thinking — identifying stereotyping vs textual evidence; concise analytical writing.

STEPS:
- Step 1: Identify Problem 1 — "typical Indian mother" imposes external stereotype, ignoring poem's specific characterisation.
- Step 2: Identify Problem 2 — "silent, suffering, self-sacrificing" lists abstract traits without *any* textual evidence (no images, lines, devices).
- Step 3: Recall textual evidence for mother — "ककककक ककककक" (changed fate), "ककककक ककककक" (held family), "ककककक ककककक" (steadfast).
- Step 4: Draft rewrite using evidence — "The mother emerges as a resilient architect of survival: 'ककककक ककककक ककककक' (she transformed fate into home), her grief 'ककककक ककककक' (steadfast, not performative), making her the poem's moral anchor."
- Step 5: Check word count and PEEL structure.

ANSWER: Problems: 1) Uses cultural stereotype instead of textual analysis. 2) Zero textual evidence — no images, lines, or devices cited. Rewrite: The mother is characterised as a resilient architect of survival, not a passive sufferer. The metaphor "ककककक ककककक ककककक" (she changed fate to create home) and juxtaposition with the father's vocal grief ("ककककक ककककक" vs her "ककककक ककककक" steadfastness) reveal active agency. Her silence is structural strength, not submission. (49 words)

DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: The poem's structure moves from daughter (stanzas 1-2) to mother (stanza 3). Design a 3-mark board exam question that tests whether a student understands *why* this structural choice matters for character analysis. Provide the marking scheme.

COMPETENCY: Assessment design — understanding exam patterns and structural analysis.

STEPS:
- Step 1: Identify the core structural insight — the shift mirrors the father's emotional journey from individual loss to collective resilience.
- Step 2: Frame question to require *analysis*, not just identification — "Explain how the placement of the mother's appearance in the final stanza shapes our understanding of both supporting characters."
- Step 3: Define 3-mark scheme: 1 mark for identifying the structural shift; 1 mark for linking daughter's early dominance to 'source of grief'; 1 mark for linking mother's late entry to 'witness/anchor of grief'.
- Step 4: Add distractor warning — students often describe *what* happens, not *why* the structure matters.
- Step 5: Finalise question and scheme.

ANSWER: Question: "The daughter dominates the first two stanzas; the mother appears only in the third. Explain how this structural sequencing deepens the characterisation of BOTH supporting characters." (3 marks) Marking Scheme: 1 mark — Daughter's early presence establishes her as the *catalyst* of grief (her absence creates the void). 1 mark — Mother's late entry positions her as the *stabiliser* of grief (her endurance contains the void). 1 mark — Together, the sequence maps the father's journey from raw loss (daughter) to communal resilience (mother). Distractor: Merely listing their stanzas without interpreting structural function scores 0.

DIFFICULTY: hard