## DEFINITION
Secondary themes are the subordinate ideas, motifs, or concerns that run parallel to the primary theme in a literary work, enriching its texture by exploring specific human experiences, social realities, or philosophical nuances that support or contrast with the central message. In "चुकजल" and "फँक", secondary themes include the tension between perception and reality, the quiet dignity of rural labor, the intergenerational transmission of comfort, and the fleeting nature of fear against enduring natural cycles.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student can independently identify at least three distinct secondary themes in the chapter, trace each across specific stanzas or passages with textual evidence, and explain how each secondary theme deepens or complicates the primary theme of rootedness in nature and simple human existence.

## SCOPE_BOUNDARY
This node covers identification, textual tracing, and analytical explanation of secondary themes in the two poems "चुकजल" and "फँक" from Chapter 4 of Antra. It does NOT cover primary theme analysis (done in node 006), literary devices (nodes 008-009), or comprehensive character sketches (nodes 004-005). Focus remains on thematic layering and inter-theme relationships.

## WALKTHROUGH
Imagine you're sitting on a charpoy in your ancestral village at dusk — the air smells of wet earth and woodsmoke, and you notice how the same scene holds different meanings for your grandfather (memories), your younger sister (play), and you (fleeting peace). That layered perception is exactly what secondary themes capture in "चुकजल". Start by rereading the poem silently, then aloud — mark every stanza where the speaker shifts from describing the external village (water, fields, birds) to an internal realization ("यदि ध्यान से देखें तो यह एक है और एक नहीं है"). Ask: what *else* is the poet saying beneath the surface description? List 4-5 recurring concerns (time, perception, labor, fear/comfort, continuity). For each, find 2-3 textual anchors. Finally, map how each secondary theme either reinforces or quietly questions the primary theme of harmonious coexistence with nature.

## DIAGNOSTIC_QUESTION_1
What is the definition of a secondary theme in literature, and how does it differ from the primary theme in terms of scope and function within a text?

## DIAGNOSTIC_ANSWER_1
A secondary theme is a subordinate idea that runs parallel to the primary theme, exploring specific facets of human experience with narrower scope; while the primary theme is the central, unifying message (e.g., "harmony with nature"), secondary themes are supporting threads (e.g., "the act of perception shapes reality," "rural labor's quiet dignity") that add depth without dominating. A wrong answer that equates secondary themes with "minor topics" or "subplots" reveals confusion between thematic layers and narrative elements — themes are abstract ideas, not plot points.

## DIAGNOSTIC_QUESTION_2
In "चुकजल", the speaker says "यदि ध्यान से देखें तो यह एक है और एक नहीं है". Explain in your own words what this line suggests about the secondary theme of perception versus reality, and why it is not the primary theme of the poem.

## DIAGNOSTIC_ANSWER_2
The line reveals that reality is not fixed but shifts with the observer's attention — the village scene is simultaneously unified ("एक") and fragmented ("एक नहीं") depending on how deeply one looks. This is a secondary theme because it operates as a philosophical lens *through which* the primary theme (rooted, cyclical rural existence) is experienced, not the central message itself. A wrong answer that calls this the "main point" misses that the poem's core is the lived harmony of that village, not the epistemological claim about perception.

## DIAGNOSTIC_QUESTION_3
Apply the concept of secondary themes to the poem "फँक": identify one secondary theme present in the father-child interaction during the thunderstorm, quote the specific line(s) that evidence it, and explain how it supports the primary theme of intergenerational continuity.

## DIAGNOSTIC_ANSWER_3
Secondary theme: "Fear as a bridge for tenderness." Evidence: "eSa Lohdkj d:¡ eSaus igyh ckj tkuk fgeky; fdèkj gS!" — the child's repeated "मैँ-मैँ" (me-me) shows self-centered fear, while the father's silent presence ("eSa Lohdkj dj¡Q") transforms terror into trust. This supports the primary theme (continuity of care across generations) by showing *how* continuity is enacted — not through grand gestures but through quiet, repeated acts of protection. A wrong answer that picks "thunderstorm" as a theme confuses setting/event with thematic idea.

## DIAGNOSTIC_QUESTION_4
Compare the secondary theme of "time's passage" in "चुकजल" (stanzas describing the village's cyclical rhythms) and "फँक" (the child's fear as a momentary rupture in the night). How do both poems use temporal contrast — enduring vs. fleeting — to deepen their respective primary themes?

## DIAGNOSTIC_ANSWER_4
In "चुकजल", time is cyclical and expansive: "यही रग [कयक है", "यही रग भरता / और [कयता है" — the village endures through repetitive natural cycles, reinforcing primary theme of rooted permanence. In "फँक", time is linear and fragile: the child's "पन्द्रह-सोलह मिनट" of terror is a brief rupture against the father's steady presence, highlighting how continuity is *felt* in moments of vulnerability. Together, they show time as both the container of tradition (चुकजल) and the test of bonding (फँक). A wrong answer that treats time identically in both poems misses the structural difference: cyclical vs. episodic temporality.

## DIAGNOSTIC_QUESTION_5
Evaluate this student claim: "The secondary theme of 'rural labor' in 'चुकजल' is merely decorative background — removing it would not change the poem's core message about nature." Defend or refute using textual evidence.

## DIAGNOSTIC_ANSWER_5
Refute. Labor is not decorative; it is the *mediator* between humans and nature. Lines like "यहाँ गृह कार्य अपनी 'जगत' में होता है", "खेत खलिहान... बैलों की घंटियों की टुनटुन" show labor as the daily enactment of harmony — humans don't just *observe* nature, they *participate* in its rhythms through work. Remove labor, and the poem becomes pastoral escapism, not lived coexistence. The primary theme *requires* labor as its tangible expression. A wrong answer that agrees reveals a misunderstanding of theme as "message + decoration" rather than an integrated system where secondary themes operationalize the primary.

## DIAGNOSTIC_QUESTION_6
Create a four-line free-verse stanza in Hindi that introduces a new secondary theme for "चुकजल" — one not explicitly discussed in the textbook — rooted in the poem's imagery (water, birds, fields, observation). The theme must be abstract, universal, and distinct from perception/reality, labor, or time.

## DIAGNOSTIC_ANSWER_6
Example stanza (theme: **silence as a form of knowledge**):
"बोलते नहीं खेत, न बोलती नहर,
फिर भी जानते हैं — कब बीज फूटा, कब धान भरा।
चुप्पी यहाँ अनपढ़ नहीं, गुरु है गहरी,
जो सुने ध्यान से, वही पाए खजाना।"
A poor answer would be descriptive ("पानी बहता, चिड़िया गाती") without abstracting a theme, or would repeat perception/time. The test: can the theme be stated in a noun phrase ("silence as knowledge") and traced beyond this stanza?

## COMMON_MISCONCEPTION
Students often treat secondary themes as "less important themes" that can be listed like inventory items (e.g., "nature, time, fear, labor") without showing *how* each theme functions structurally — i.e., how it modifies, qualifies, or deepens the primary theme through specific textual mechanisms. They write "Another theme is X" and quote a line, but don't explain the *relationship*: Does X reinforce the primary theme? Complicate it? Provide a counter-perspective? This error costs marks in board exams (where "analyze" requires relational thinking) and in CUET/JEE-style questions that ask "How does the theme of perception *mediate* the theme of rootedness?"

## ON_FAILURE
If a student lists themes without relational analysis: (1) Have them reread the primary theme statement from node 006. (2) Give a two-column template: Column A = "Primary theme claim", Column B = "How secondary theme X *shapes* that claim". (3) Model one row together: Primary = "Village life is harmonious"; Secondary = "Perception shapes reality" → "Harmony is not objective but *achieved* through attentive seeing." (4) Assign: complete 3 rows for the remaining secondary themes. (5) Re-diagnose using Diagnostic Question 4 — require explicit "mediates/complicates/extends" language in the answer.

## BUILDS_ON
This node builds on the primary theme identification in c12_hin_a_cbse_04_006, requiring students to move from "what is the main message" to "what are the supporting thematic layers and how do they interact."

## LEADS_TO
This node enables c12_hin_a_cbse_04_008 (Literary Devices: Imagery and Metaphor) by establishing thematic threads that devices like water imagery or bird motifs concretize, and c12_hin_a_cbse_04_013 (Critical Thinking) where multi-theme synthesis is required.

## PREREQUISITE_NODE_IDS
c12_hin_a_cbse_04_006, c11_hin_ar_cbse_04_007, c11_hin_v_cbse_04_007, c12_hin_a_cbse_04_005

## PREREQUISITE_REASONS
c12_hin_a_cbse_04_006: Primary theme must be established first — secondary themes are defined *in relation* to it.
c11_hin_ar_cbse_04_007: Class 11 Antra Chapter 4 secondary themes node provides the foundational skill of identifying and tracing subordinate themes in poetry.
c11_hin_v_cbse_04_007: Class 11 Vitan Chapter 4 secondary themes node reinforces the same analytical skill across a different text type (prose/non-fiction), ensuring transferability.
c12_hin_a_cbse_04_005: Secondary themes (innocence, care, time) are carried by specific supporting figures.  

## FORWARD_NODE_IDS
c12_hin_a_cbse_04_008, c12_hin_a_cbse_04_013, c12_hin_a_cbse_04_009

## FORWARD_REASONS
c12_hin_a_cbse_04_008: Imagery and metaphor are the primary vehicles through which secondary themes (e.g., water for perception, thunder for fear) are rendered concrete — students need thematic clarity to analyze devices meaningfully.
c12_hin_a_cbse_04_013: Critical thinking questions demand synthesis of multiple themes with textual evidence — this node provides the thematic inventory and relational framework.
c12_hin_a_cbse_04_009: Secondary themes (urbanization, memory, language failure) give context for why specific symbols (pond, lane) are chosen.  

## CROSS_SUBJECT_PREREQS
c11_hin_ar_cbse_04_007, c11_hin_v_cbse_04_007
## CROSS_SUBJECT_REASONS
c11_hin_ar_cbse_04_007: Same chapter-position in Class 11 Antra — builds thematic analysis skill progression from simpler to more complex texts.
c11_hin_v_cbse_04_007: Class 11 Vitan (non-fiction) Chapter 4 — demonstrates secondary theme analysis in expository/argumentative writing, showing the concept's genre-transferability.

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_04_007 -> c12_hin_a_cbse_04_007 -> c12_hin_a_cbse_04_008

## THIS_FORMULA
N/A - conceptual

## FORMULA_VARIABLES
N/A

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
conceptual

## CROSS_SUBJECT
N/A | The poem "चुकजल" depicts a pre-industrial village rhythm; History Chapter 4 (Colonialism and the Countryside) examines how British land revenue systems disrupted exactly such self-sustaining rural ecologies — secondary theme of "labor as harmony with nature" contrasts sharply with colonial extraction.
 N/A | Geography Chapter 4 (Human Settlements) analyzes rural settlement patterns, occupational structure, and human-environment interaction — the poem's secondary theme of "cyclical time aligned with nature" maps directly to geographical concepts of sustainable rural livelihoods and seasonal calendars.
 N/A | Economics Chapter 4 (Informal Sector) studies unorganized labor — the poem's depiction of "गृह कार्य अपनी 'जगत' में" (household work in its own world) reflects non-market, subsistence labor that economics categorizes as invisible informal work, raising questions about valuation.
## PREREQ_CONCEPT
Primary theme identification and the concept of thematic hierarchy (primary vs. secondary) from Class 11 poetry analysis.

## PREREQ_BEFORE
Student must be able to state the primary theme of "चुकजल" and "फँक" in one sentence each, and distinguish theme (abstract idea) from topic (subject matter) and plot (sequence of events).

## PREREQ_STUCK
If stuck, revisit c12_hin_a_cbse_04_006 (Primary Theme) and practice writing one-sentence theme statements for 3 familiar poems/stories until the distinction between topic ("village") and theme ("harmony with nature through attentive participation") becomes automatic.

## WORKED_EXAMPLE_1
PROBLEM: Identify and trace the secondary theme of "the body as a site of memory" in "चुकजल", using at least three textual anchors from different stanzas, and explain how it complicates the primary theme of timeless rural continuity.

STEPS:
- Step 1: Recall the primary theme from node 006 — "रचनात्मक सहअस्तित्व: प्रकृति और मनुष्य का ध्यानपूर्वक, श्रमशील सामंजस्य" (creative coexistence: attentive, laborious harmony of nature and human).
- Step 2: Scan the poem for bodily references — not just labor but sensory bodies: "आँख" (eye/perception), "कान" (ear/sound), "हाथ" (touch/work), "पैर" (movement through fields).
- Step 3: Select three anchors: (a) Stanza 2: "यदि ध्यान से देखें" — the *eye* as active interpreter, not passive receiver; (b) Stanza 4: "कानों में पड़ती... बैलों की घंटियों की टुनटुन" — the *ear* catching rhythm that binds body to cycle; (c) Stanza 6: "पैर तले की मिट्टी... गीली, भूरी, गंधाती" — *feet* grounding memory in tactile present.
- Step 4: Analyze each: The body is not a neutral vessel but a *filter* — what the village *is* depends on which sense dominates. The eye sees unity ("एक"), the ear hears fragmentation ("टुनटुन"), the feet feel transience ("गीली... भूरी").
- Step 5: Connect to primary theme: Continuity is not automatic; it is *re-embodied* daily through sensory labor. The theme of "body as memory-site" complicates "timeless continuity" by showing continuity as a *fragile, re-enacted achievement* of living bodies, not a given.

REASONING: This works because it moves from thematic hierarchy (primary first) to textual evidence (specific senses/body parts) to structural analysis (how the secondary theme *qualifies* the primary), modeling the exact relational thinking board exams reward.

ANSWER: Secondary theme: "The sensing body as the fragile mediator of rural continuity." Anchors: (1) "ध्यान से देखें" — visual attention constructs unity; (2) "कानों में पड़ती... टुनटुन" — auditory rhythm binds body to cycle; (3) "पैर तले की मिट्टी" — tactile grounding makes continuity tangible. Relationship: This theme *complicates* the primary theme by revealing that the poem's celebrated harmony is not a static fact but a daily, bodily re-creation — if bodies forget (lose attention), the harmony dissolves.

## WORKED_EXAMPLE_2
PROBLEM: In "फँक", the secondary theme "language as both barrier and bridge" appears in the child's fragmented speech ("मैँ-मैँ", "पिताजी... पिताजी") versus the father's silence. Trace this theme through the poem and evaluate whether it ultimately reinforces or undermines the primary theme of intergenerational trust.

STEPS:
- Step 1: State primary theme of "फँक" (from node 006): "भय के क्षण में मौन अभिभावकीय उपस्थिति ही पीढ़ीगत विश्वास की नींव है" (Silent parental presence in moments of fear is the foundation of intergenerational trust).
- Step 2: Map the child's language: "मैँ-मैँ" (repetitive, self-enclosed, fear-driven), "पिताजी... पिताजी" (invocation, not conversation), "फँक... फँक" (onomatopoeic, pre-linguistic terror).
- Step 3: Map the father's language: Silence ("पिता कुछ नहीं बोलते"), action ("लोहड़ी जला देते हैं", "सीने से लगा लेते हैं"), minimal utterance ("सो जा") — language reduced to its barest functional core.
- Step 4: Analyze tension: Child's language *expresses* fragmentation; father's silence *contains* it. The gap between them is where trust grows — not through dialogue but through the father's refusal to match the child's linguistic panic.
- Step 5: Evaluate: Reinforces primary theme. The "barrier" (child's incoherent speech vs father's silence) becomes the "bridge" because the father's silence is not absence but *holding space*. Trust is built not by explaining the thunder but by *withstanding* the child's fear without words.

REASONING: This example demonstrates how to trace a secondary theme through *contrast* (child vs father, speech vs silence) and evaluate its structural role (reinforce/complicate) — a key skill for "analyze" level board questions and CUET case-based items.

ANSWER: Secondary theme: "Language as both barrier (child's panic-speech) and bridge (father's containing silence)." Evidence: Child — "मैँ-मैँ", "फँक... फँक", repetitive "पिताजी"; Father — silence, "सो जा", physical actions. Verdict: Reinforces primary theme. The linguistic asymmetry *is* the trust mechanism — the father does not colonize the child's fear with adult explanations; he outlasts it with presence. The barrier becomes the bridge.

## WORKED_EXAMPLE_3
PROBLEM: Synthesize a comparative analysis: How do the secondary themes of "perception/reality" (चुकजल) and "language/silence" (फँक) *jointly* illuminate a meta-theme about "knowing" in Osanikjuk Phalg's poetry? Write a 150-word analytical paragraph with integrated textual evidence.

STEPS:
- Step 1: Define the meta-theme: "Knowing as participatory, not propositional" — knowledge in both poems is not information acquired but a *way of being* (attentive seeing in चुकजल, silent holding in फँक).
- Step 2: Extract the epistemic claim from चुकजल: "यदि ध्यान से देखें तो यह एक है और एक नहीं है" — reality *responds* to the quality of attention; knowing = attending.
- Step 3: Extract the epistemic claim from फँक: Father knows the thunder is harmless, but *does not tell* the child. His knowing is enacted through body (embrace, fire), not transmitted through words. The child *learns* safety by *feeling* it.
- Step 4: Synthesize: Both poems reject knowledge-as-statement. In चुकजल, the village's truth is not in a description but in the *act of describing* ("ध्यान से देखें"). In फँक, the father's truth is not in "थंडर खतरनाक नहीं" but in "सीने से लगा लेना".
- Step 5: Meta-theme formulation: Phalg posits that in rooted, intergenerational worlds, *knowing is a practice of presence* — perceptual in one poem, relational in the other. The secondary themes (perception, language) are the *modes* of this practice.
- Step 6: Draft paragraph integrating quotes: "ध्यान से देखें", "पिता कुछ नहीं बोलते", "सीने से लगा लेते हैं".

REASONING: This models the highest-level board/CUET skill: cross-text thematic synthesis with a meta-analytical claim, using secondary themes as the analytical ladder. It requires holding two poems' thematic architectures simultaneously — exactly what "critical thinking" node 013 will demand.

ANSWER: In both poems, Phalg reframes knowing as participatory practice rather than propositional content. In "चुकजल", the line "यदि ध्यान से देखें तो यह एक है और एक नहीं है" makes reality contingent on the *quality of perception* — the village's unity is not a fact to be stated but a truth to be *enacted* through attentive seeing. In "फँक", the father's silence ("पिता कुछ नहीं बोलते") and embrace ("सीने से लगा लेते हैं") convey safety not through linguistic assurance but through *bodily presence* — the child knows security by *inhabiting* it. Together, the secondary themes of perception (चुकजल) and language/silence (फँक) converge on a meta-theme: **in a world rooted in continuity, knowledge is not what you say or see, but how you attend and hold**. The poems' quiet radicalism lies in making epistemology ethical — to know is to be present.

## COMPETENCY_QUESTION_1
QUESTION: A Class 12 student writes in their board exam answer: "The secondary themes in 'चुकजल' are nature, time, and labor. The poet describes the village beautifully." Using the marking scheme for CBSE Class 12 Hindi Core (Section C: Literature, 6-mark question), identify the three specific deficiencies in this answer and rewrite it as a 4-point structured response that would earn full marks.

COMPETENCY: Exam answer structuring / Assessment literacy

STEPS:
- Step 1: Identify deficiency 1 — "nature, time, labor" are *topics*, not *themes* (themes require abstract noun phrases with a claim: "nature as cyclic renewer," "time as embodied rhythm").
- Step 2: Identify deficiency 2 — No textual evidence (quotes/references) to anchor each theme.
- Step 3: Identify deficiency 3 — No analysis of *relationship* to primary theme (how each secondary theme modifies/deepens the central message).
- Step 4: Rewrite using PEEL structure for each theme: Point (theme statement), Evidence (textual anchor), Explanation (how it works), Link (to primary theme).

ANSWER: Deficiencies: (1) Lists topics, not thematic statements; (2) Zero textual evidence; (3) No thematic relationship analysis. Full-mark rewrite:
1. **Perception constructs reality** — "यदि ध्यान से देखें तो यह एक है और एक नहीं है" — the village's unity is not given but *achieved* through attentive seeing, complicating the primary theme of inherent harmony by making it *earned*.
2. **Labor as daily re-enactment of coexistence** — "गृह कार्य अपनी 'जगत' में होता है" — work is not economic necessity but the *ritual* through which humans participate in nature's cycles, operationalizing the primary theme.
3. **The sensing body as memory's site** — "पैर तले की मिट्टी... गीली, भूरी, गंधाती" — continuity is grounded in tactile, fragile embodiment, not abstract timelessness.
4. **Cyclical time vs. linear observation** — "यही रग भरता / और [कयता है" — natural cycles endure, but human perception is momentary; the poem holds both, suggesting harmony requires *repeated return* to attention.

DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: CUET 2024 Hindi question (adapted): "In 'फँक', the child's fear of lightning is momentary, but the poem suggests its *residue* shapes the child's future relationship with the world. Using the secondary theme of 'fear as apprenticeship,' analyze how the poem's closing image ('विह्वल नभ में / चमकती बिजली / अब नहीं डराती') transforms the primary theme of paternal protection into one of *internalized resilience*."

COMPETENCY: Cross-text thematic evolution / Competitive exam analytical writing

STEPS:
- Step 1: Define "fear as apprenticeship" — fear is not just an emotion to be soothed but a *developmental passage* where the child learns to distinguish real danger from perceived threat.
- Step 2: Trace the arc: Opening — "चमकती बिजली / डराती है" (external threat triggers cry); Middle — Father's silent containment ("सीने से लगा लेते हैं") *without* explaining; Closing — "अब नहीं डराती" (internal shift).
- Step 3: Key insight: The father *does not teach* "lightning is safe." He *models* calm presence. The child *internalizes* that model. Resilience is caught, not taught.
- Step 4: Transformation of primary theme: Primary theme (node 006) = "पितृसत्तात्मक नहीं, पालन-पोषणात्मक संरक्षण" (nurturant, not patriarchal protection). Closing image shows protection's *teleology*: its goal is its own obsolescence — the child no longer *needs* the father's chest because the father's calm has become the child's own.
- Step 5: Synthesize in 120 words with integrated evidence.

ANSWER: The poem redefines paternal protection not as perpetual shelter but as *scaffolding for self-trust*. The child's initial "मैँ-मैँ" (self-enclosed panic) meets the father's wordless embrace — a containment that *does not explain* but *endures*. The closing transformation ("विह्वल नभ में / चमकती बिजली / अब नहीं डराती") reveals the apprenticeship's completion: the external lightning hasn't changed, but the *internal witness* has. The father's silence ("पिता कुछ नहीं बोलते") was not absence but *modeling* — the child absorbs the father's unshaken presence as their own baseline. Thus, the primary theme of "nurturant protection" evolves into "protection that *cultivates the protected's autonomy*." The residue of fear, metabolized through silent love, becomes the child's inner lightning rod. Fear, once apprenticeship, becomes graduated resilience.

DIFFICULTY: hard