## DEFINITION
Setting and Atmosphere in literature refers to the time, place, season, and social environment (setting) where a narrative or poem unfolds, and the emotional mood or feeling (atmosphere) constructed through sensory details, imagery, and linguistic choices that shape the reader's affective experience.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
Student can identify specific textual evidence of setting (temporal, spatial, seasonal markers) and atmosphere (mood, tone, sensory texture) in Phoolchand's three Braj Bhasha poems, explain how linguistic and cultural conventions transform setting into atmospheric agent, and trace the viraha narrative arc through the progressive deepening of atmosphere across the poem sequence.

## SCOPE_BOUNDARY
This node covers analysis of setting markers (time, place, season, sensory details) and atmosphere construction (mood, tone, emotional resonance) in the three Phoolchand poems of Chapter 8. It does NOT cover character analysis (nodes 004-005), thematic analysis (nodes 006-007), or detailed literary device classification (nodes 008-009), though it references them.

## WALKTHROUGH
Imagine you're reading a late-night message from someone far away — the words on screen carry weight, but the rain tapping your window, the darkness outside, the very hour of night, all amplify what the message says. That's setting becoming atmosphere. Start by reading Phoolchand's three poems ALOUD in Braj — let the sounds (nasals, aspirates, onomatopoeia like 'Nu Nu') hit your ear before you translate. First, hunt for concrete setting markers: which ritu (season)? Which prahar (time)? What physical space? Mark every sensory word — sound (rain, thunder, frogs), sight (lightning, clouds, darkness), touch (wind, dampness). Then ask: how does each detail do double duty? The rain isn't just weather — in Indian poetics, varsha ritu is the coded season for lovers' UNION; Phoolchand's beloved leaving DURING this season makes the setting an active betrayal. The clouds aren't backdrop — they're addressed as failed messengers. The night isn't just time — it progresses from lonely witness (Poem 1) to restless endurance (Poem 2) to sensory assault (Poem 3). Key insight: In viraha poetry, external landscape IS internal mindscape — the storm outside IS the storm within.

## DIAGNOSTIC_QUESTION_1
What are the two main components of 'setting' in a literary text, and how does 'atmosphere' differ from setting?

## DIAGNOSTIC_ANSWER_1
Setting comprises time (historical period, time of day, season) and place (geographical location, physical environment). Atmosphere is the emotional mood or feeling evoked in the reader through descriptive language — it's the subjective experience created by the setting details. A wrong answer that conflates setting with atmosphere (e.g., "setting is the mood") reveals the student hasn't distinguished objective backdrop from subjective emotional effect.

## DIAGNOSTIC_QUESTION_2
In Phoolchand's first poem, the line "xksoqQy rsft eèkqiqj cl js du vitl ysy" (सखी सखी एकएक चल जा दू विटल यस्य) — explain in your own words how this line establishes both setting and atmosphere simultaneously.

## DIAGNOSTIC_ANSWER_2
The line depicts the sakhi (friend) watching the beloved (priya) walk away into the distance during the rainy season (varsha ritu), establishing spatial setting (separation distance), temporal setting (rainy season journey), and atmosphere of helpless longing (the sakhi can only watch, "du vitl" — from afar). A wrong answer focusing only on "rainy season" misses the emotional atmosphere; one focusing only on "watching him leave" misses the seasonal setting that amplifies the viraha.

## DIAGNOSTIC_QUESTION_3
Given this new couplet in Braj: "बरखा बरसत देखि सखी, विरह बिथा बढ़ी अति जाय / बिजुरी चमके घटा घनघोर, प्रियतम न आवत नाहिं" — identify the setting markers and explain how they construct the atmosphere of viraha.

## DIAGNOSTIC_ANSWER_3
Setting markers: "बरखा बरसत" (rain falling — seasonal/temporal), "घटा घनघोर" (dense clouds — spatial/weather), "बिजुरी चमके" (lightning — temporal moment). These construct atmosphere by: (1) Rain = traditional viraha season (varsha) when separation pain intensifies, (2) Dense clouds = visual metaphor for obscured union, (3) Lightning = fleeting hope that illuminates but doesn't last, (4) "प्रियतम न आवत" = the setting's promise (rain brings lovers together) is ironically unfulfilled. Wrong answer listing only "rain and clouds" without connecting to viraha convention shows mechanical identification without literary understanding.

## DIAGNOSTIC_QUESTION_4
Compare how the first and third poems use 'night' (रात्रि/निशा) differently to construct atmosphere. The first poem has "eèkqiqj" (एकएक — alone/lonely) while the third has "Nu&Nu ruq fNu" (नु नु रुक फनु — onomatopoeic night sounds). What does this shift reveal about the progression of viraha?

## DIAGNOSTIC_ANSWER_4
First poem: "eèkqiqj" (एकएक) — night as solitary isolation, the sakhi watches the beloved depart into loneliness. Atmosphere: static, witnessing separation's beginning. Third poem: "Nu&Nu ruq fNu" — night as alive with sounds (crickets, frogs, rain), each sound amplifies the beloved's absence. Atmosphere: dynamic, sensory assault where every sound becomes a reminder. The shift reveals viraha's progression from acute departure-moment to chronic, immersive suffering where the environment itself becomes hostile. Wrong answer saying "both show night is sad" misses the developmental arc from witnessing to embodying separation.

## DIAGNOSTIC_QUESTION_5
A student claims: "Phoolchand's poems use setting merely as background decoration — the rainy season is just when the story happens." Evaluate this claim using textual evidence from at least two poems.

## DIAGNOSTIC_ANSWER_5
The claim is incorrect. Evidence: (1) Poem 1: "xksoqQy rsft eèkqiqj cl js du vitl ysy" — the rainy season journey (varsha ritu) is the traditional time for lovers' meetings in Indian poetics; the beloved's departure DURING this season violates convention, making setting an active agent of betrayal. (2) Poem 2: "lsgks eèkqj cksy lzoufg lwuy lzqfr iFk ijl u xsy" — the rain clouds (मेघ) are addressed directly as messengers (दूत), personified setting that fails its duty. (3) Poem 3: "tyèkkjk" (वज्राकाक — thunderbolt) — the storm's violence mirrors internal agony. Setting is not background; it's a participating character in the viraha drama. Wrong answer agreeing with the claim reveals inability to see setting as functional in pre-modern Indian poetry where nature mirrors human emotion (रस सिद्धान्त).

## DIAGNOSTIC_QUESTION_6
Write a 4-line Braj-style couplet (in Devanagari or transliteration) that uses a seasonal setting (NOT varsha) to create an atmosphere of viraha. Include at least two sensory images.

## DIAGNOSTIC_ANSWER_6
Example: "शिशिर बयार तन झकोरै, प्रिय बिन काटै न रैन / कुहु कुहु कोकिल बोलत सखी, जियरा लागै न चैन" (Winter wind shakes the body, night doesn't pass without beloved / Cuckoo calls 'kuhu kuhu' friend, heart finds no peace). Good answer: uses non-varsha season (shishir/winter), two sensory images (wind on skin, cuckoo sound), maintains viraha atmosphere. Poor answer: "Winter comes, I am sad, no beloved here" — lacks sensory imagery, Braj flavor, and poetic compression; reveals student treats it as prose statement not poetic construction.

## COMMON_MISCONCEPTION
Students treat 'setting' as only physical backdrop (time/place) and 'atmosphere' as a separate add-on, missing that in Bhakti/viraha poetry, setting IS atmosphere — the external landscape (varsha ritu, night, storms) is the objective correlative for internal emotion. They also miss that Braj Bhasha's phonetic texture (repeated nasals, aspirates, onomatopoeia like 'Nu Nu') creates atmosphere BEFORE meaning is parsed. Example error: "The setting is rainy season. The atmosphere is sad." Correct: "The rainy season's specific sounds (rain, thunder, frogs), timing (night), and cultural associations (megha-duta tradition) CONSTRUCT the sadness."

## ON_FAILURE
1. Re-read the three poems ALOUD in Braj, marking every sensory word (sound, sight, touch) with a highlighter.
2. Create a two-column table: Column A = Setting Detail (quote), Column B = Atmosphere Effect (what feeling it creates).
3. Revisit c11_hin_ar_cbse_08_003 (Class 11 Setting and Atmosphere) for the foundational framework of setting-atmosphere relationship.
4. Re-do Diagnostic Question 4 as a written exercise with the table as scaffold.

## BUILDS_ON
Class 11's introduction to setting-atmosphere analysis (c11_hin_ar_cbse_08_003) where students learned to identify basic setting markers and mood words.

## LEADS_TO
c12_hin_a_cbse_08_008 (Literary Devices: Imagery and Metaphor) where sensory setting details are analyzed as poetic imagery, and c12_hin_a_cbse_08_006 (Theme: Primary Theme) where viraha as central theme is explored through its atmospheric construction.

## PREREQUISITE_NODE_IDS
c11_hin_ar_cbse_08_003, c12_hin_a_cbse_08_001, c12_hin_a_cbse_08_002
## PREREQUISITE_REASONS
c11_hin_ar_cbse_08_003: Provides foundational framework for setting-atmosphere analysis from Class 11 Antaral
c12_hin_a_cbse_08_001: Context/background on Phoolchand, Bhakti period, Braj Bhasha conventions essential for interpreting setting markers
c12_hin_a_cbse_08_002: Plot/narrative structure gives the separation narrative arc that setting details enact

## FORWARD_NODE_IDS
c12_hin_a_cbse_08_008, c12_hin_a_cbse_08_009, c12_hin_a_cbse_08_006, c12_hin_a_cbse_08_004, c12_hin_a_cbse_08_007

## FORWARD_REASONS
c12_hin_a_cbse_08_008: Setting details (rain, lightning, night sounds) function as imagery/metaphors analyzed in depth there
c12_hin_a_cbse_08_009: Atmosphere of viraha enables recognition of irony (rain brings union but here brings separation) and symbolism (clouds as failed messengers)
c12_hin_a_cbse_08_006: Primary theme of viraha is constructed through the setting-atmosphere interplay analyzed here
c12_hin_a_cbse_08_004: Supplies the atmosphere (night, threshold, locked door) that the protagonist inhabits and interacts with.  
c12_hin_a_cbse_08_007: Setting/atmosphere (the body as inner landscape) is a secondary theme itself.  

## CROSS_SUBJECT_PREREQS
c11_hin_ar_cbse_08_003, c11_hin_ar_cbse_09_003
## CROSS_SUBJECT_REASONS
c11_hin_ar_cbse_08_003: Class 11 Antaral Chapter 8 setting-atmosphere analysis provides the methodological foundation
c11_hin_ar_cbse_09_003: Class 11 Antaral Chapter 9 extends setting-atmosphere analysis to another text, reinforcing the skill

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_08_003 -> c12_hin_a_cbse_08_003 -> c12_hin_a_cbse_08_008

## THIS_FORMULA
Setting Markers (Time + Place + Season + Sensory Details) → Atmosphere Construction (Mood + Tone + Emotional Resonance) → Thematic Function (Viraha Rasa Evocation)

## FORMULA_VARIABLES
N/A - conceptual

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
conceptual

## CROSS_SUBJECT
N/A | The Bhakti movement's historical context (14th-15th century Sultanate period) explains Phoolchand's courtly yet devotional poetry where setting reflects both courtly separation and divine longing
 N/A | The Indian monsoon's cultural significance (varsha ritu as lovers' season in Sanskrit poetics) makes the rainy season setting a culturally coded symbol, not just weather
## PREREQ_CONCEPT
Ability to distinguish objective setting details from subjective atmospheric effects, and familiarity with Indian poetic conventions of ritu-varnana (seasonal description) as emotional correlate.

## PREREQ_BEFORE
Student must know: (1) Basic setting components (time, place, season), (2) What 'viraha' means in Bhakti poetry, (3) That Braj Bhasha phonetics carry atmospheric weight.

## PREREQ_STUCK
If stuck, review 'Ritu-varnana in Bhakti poetry' from Class 11 Hindi (c11_hin_ar_cbse_08_003) and the concept of 'objective correlative' in literary analysis.

## WORKED_EXAMPLE_1
PROBLEM: Analyze how the opening stanza of Poem 1 ("osQ ifrvk y, tk,r js eksjk fivre iklA / fg, ufg lg, vlg nq[k js Hksy lkvksu eklAA") establishes setting and atmosphere through linguistic choices.

STEPS:
- Step 1: Identify the literal scenario — a message (ifrvk) is being sent via a messenger (fivre) to the beloved (priya), during the rainy season (lkvksu ekl = लाखु का मेघ/मास)
- Step 2: Mark setting markers — "lkvksu ekl" (month of Lakhu/Sawan-Bhadon), "nq[k" (rain), "fg, ufg lg, vlg" (onomatopoeic rain sounds: tip-tip, tap-tap, drip-drop)
- Step 3: Analyze phonetic atmosphere — the repeated nasals (ं, न, म) and aspirates (फ, भ) in "fg, ufg lg, vlg" mimic rain's sound texture, creating auditory immersion before semantic meaning
- Step 4: Connect to viraha convention — Sawan is traditional meeting season; sending a message INSTEAD of meeting violates expectation, making the setting (rainy season) an active participant in separation
- Step 5: Synthesize — The stanza constructs atmosphere of 'anticipatory viraha' where nature's abundance (rain) contrasts with human absence (message instead of presence)

REASONING: This step-by-step moves from literal comprehension to phonetic analysis to cultural-literary convention to thematic synthesis — the full analytical arc needed for Class 12 board answers.

ANSWER: The opening stanza establishes a rainy-season (varsha ritu) setting through explicit seasonal marker "lkvksu ekl" and onomatopoeic rain sounds "fg, ufg lg, vlg". The phonetic texture (nasals/aspirates) creates auditory atmosphere of incessant rain. Culturally, varsha is the season of union (मिलन); the message-sending instead of meeting makes the setting ironically amplify separation. Atmosphere = poignant anticipation where nature's fullness highlights human emptiness.

## WORKED_EXAMPLE_2
PROBLEM: In Poem 2, the line "lsg fifjfr vuqjkx c[kkfuv fry fry uwru gks,AA" — explain how the cloud (मेघ) functions as both setting element and atmospheric agent.

STEPS:
- Step 1: Decode vocabulary — "lsg" = वह (that), "fifjfr" = पत्र/संदेश (letter/message), "vuqjkx" = पहुंचाना (deliver), "c[kkfuv" = चखना/स्वाद लेना (taste/experience), "fry fry" = बार-बार (repeatedly), "uwru" = ऊबना (get weary/bored)
- Step 2: Identify the conceit — the cloud is addressed as a messenger (दूत) to deliver the message of viraha to the beloved
- Step 3: Analyze setting function — clouds are physical setting (varsha ritu sky), but here personified as active agent
- Step 4: Analyze atmosphere function — "fry fry uwru gks," (becomes weary repeatedly) transfers the virahini's exhaustion to the cloud; the cloud 'tasting' the message (c[kkfuv) suggests the message is bitter/painful
- Step 5: Evaluate effectiveness — this merges setting and atmosphere: the external cloud internalizes the lover's fatigue, making the sky itself a participant in viraha
- Step 6: Connect to tradition — echoes Kalidasa's Meghaduta but subverts it: there cloud brings union hope; here cloud carries separation pain

REASONING: Demonstrates how to unpack a single dense line through vocabulary, conceit identification, dual function analysis, and intertextual awareness — exactly what board exam long-answer questions require.

ANSWER: The cloud (मेघ) operates dually: as setting, it's the varsha sky's physical presence; as atmospheric agent, it's personified messenger who "repeatedly wearies" (fry fry uwru) delivering the viraha message. The verb "c[kkfuv" (taste/experience) implies the message has bitter flavor — the cloud internalizes the sender's exhaustion. This fuses external landscape with internal state: the sky doesn't just witness viraha, it enacts it. Subverts Meghaduta tradition where cloud brings hopeful union.

## WORKED_EXAMPLE_3
PROBLEM: Compare the atmosphere of 'night' across all three poems. Poem 1: "eèkqiqj" (एकएक — alone/lonely night). Poem 2: "tue vcfèk ge :i fugkjy u;u u frjfir Hksy" (तू चैन के गई: रूप फुगक्जय नहीं नहीं फ्रजफिर गय). Poem 3: "Nu&Nu ruq fNu" (नु नु रुक फनु — onomatopoeic night sounds). Write a structured analysis showing progression.

STEPS:
- Step 1: Create comparison framework — three dimensions: (a) Night's descriptive label, (b) Sensory modality engaged, (c) Viraha stage represented
- Step 2: Analyze Poem 1 night — "eèkqiqj" (एकएक): label = solitary/lonely; modality = visual (watching departure); stage = departure moment (acute separation)
- Step 3: Analyze Poem 2 night — "tue vcfèk ge :i fugkjy u;u u frjfir Hksy": label = restless/sleepless ("u;u u frjfir" = not settled/not composed); modality = cognitive/emotional (mental unrest); stage = waiting/endurance (chronic separation)
- Step 4: Analyze Poem 3 night — "Nu&Nu ruq fNu": label = sonically dense (onomatopoeia for crickets/frogs/rain); modality = auditory (immersive soundscape); stage = immersive suffering (environment as antagonist)
- Step 5: Trace progression — visual witnessing → mental unrest → sensory assault; static → dynamic → enveloping; external observation → internal projection → environmental embodiment
- Step 6: Thematic conclusion — Night evolves from backdrop to mirror to monster, mapping viraha's deepening from event to condition to existence

REASONING: This models the comparative analysis skill needed for board exam 'analyze across the text' questions, using a structured framework that ensures comprehensive coverage.

ANSWER: Poem 1 night ("eèkqiqj"): solitary visual witnessing of departure — acute viraha onset. Poem 2 night ("u;u u frjfir"): restless mental unrest in waiting — chronic viraha endurance. Poem 3 night ("Nu Nu ruq fNu"): auditory immersion in hostile soundscape — embodied viraha where environment attacks. Progression: Night shifts from setting (time marker) to mirror (reflecting inner state) to antagonist (actively causing pain). This three-stage mapping structures the viraha narrative arc across the poem sequence.

## COMPETENCY_QUESTION_1
QUESTION: A Class 12 student writes in their board exam answer: "Phoolchand uses the rainy season as setting because it rains a lot in India during that time." Identify the TWO major analytical gaps in this statement and rewrite it as a competent analytical statement using the setting-atmosphere framework.

COMPETENCY: Critical analysis of peer response / Application of literary framework

STEPS:
- Step 1: Identify Gap 1 — reduces culturally coded literary convention (varsha ritu as milan season) to mere meteorological fact
- Step 2: Identify Gap 2 — ignores how setting CONSTRUCTS atmosphere (irony of separation during union-season)
- Step 3: Apply framework: Setting marker (varsha) + Cultural convention (miln season) + Ironic violation (virah instead of miln) = Atmosphere (intensified viraha)
- Step 4: Rewrite using evidence: "Phoolchand deploys varsha ritu not as meteorological backdrop but as a literary convention where rain traditionally signifies lovers' union; the beloved's departure/journey during this very season creates ironic tension that amplifies the viraha atmosphere."

ANSWER: Gaps: (1) Confuses meteorological fact with literary convention (varsha = मिलन ऋतु in Indian poetics), (2) Treats setting as passive background rather than active atmospheric constructor. Competent rewrite: "Phoolchand invokes the Indian poetic convention of varsha ritu as the season of union (मिलन ऋतु) to create ironic atmosphere: the beloved's departure during the very season coded for meeting intensifies separation pain, making the rain's abundance a cruel contrast to the lover's emptiness."

DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: The third poem ends with "Hkub fo|kifr flc¯lg uj&ifr yf[keknsb&jeku" (हकुब फूलचंद फलक लग उज इफर यफकेकन्सब जेकु). Explain how the poem's atmospheric progression (from Poem 1 to Poem 3) prepares the reader for this concluding signature line where the poet names himself. What does the atmosphere achieve for the poet's self-presentation?

COMPETENCY: Synthesis across texts / Authorial intention analysis

STEPS:
- Step 1: Recall atmospheric arc — Poem 1: anticipatory viraha (message sent), Poem 2: endurance viraha (cloud messenger fails), Poem 3: immersive viraha (night sounds assault)
- Step 2: Analyze the signature line — "Hkub" (हकुब = हक से/अधिकार से), "flc¯lg" (फलक लग = फलक पर लगा/स्थापित), "uj&ifr" (उज इफर = उज्ज्वल इधर/इस ओर), "yf[keknsb&jeku" (यश के कंसब जेकु = यश के कारण जीतू/विजयी)
- Step 3: Connect atmosphere to authority — the poet earns the right (हकुब) to speak on viraha because the poems have ENACTED viraha atmospherically, not just described it
- Step 4: Explain "flc¯lg" — the atmosphere built across three poems establishes (लगाता) the poet's reputation on the "फलक" (firmament/slate of literary tradition)
- Step 5: Conclude — the atmospheric progression IS the poet's credential; by making reader FEEL viraha through setting-atmosphere craft, Phoolchand establishes his authenticity as a viraha poet

REASONING: This requires synthesizing across all three poems, understanding the convention of poet's signature (bhanita) in medieval poetry, and seeing atmosphere as rhetorical proof of poetic authority — a high-level competency for board and competitive exams.

ANSWER: The three poems' atmospheric arc (anticipatory → enduring → immersive viraha) functions as performed evidence of Phoolchand's poetic authority. The concluding line "Hkub fo|kifr flc¯lg..." means "By right, Phoolchand establishes [his name] on the firmament." The atmosphere doesn't just describe viraha — it MAKES the reader experience it. This experiential proof earns the poet the "right" (हकुब) to inscribe his name in the tradition. The setting-atmosphere craft across the sequence IS the credential.

DIFFICULTY: hard