## DEFINITION
Primary theme is the central, unifying idea or message that the author conveys through the narrative, characters, and conflict. In "उद्देश्य का नक्षत्र", the primary theme is the clash between colonial oppression and individual conscience, illustrating that true education empowers one to resist injustice even at great personal cost.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student can identify the primary theme of the story, trace its development across at least three key episodes, and explain how the protagonist's choices embody the theme, using textual evidence in a structured answer.

## SCOPE_BOUNDARY
This node covers identifying and analyzing the primary theme and central message of "उद्देश्य का नक्षत्र" using plot, character, and setting. It does not cover secondary themes (node 007), literary devices (nodes 008-009), or writing skills (node 014).

## WALKTHROUGH
Imagine you are asked: "What is this story really about?" You might recall the plot—a teacher refuses a government job and goes to jail. But the theme is not the plot; it's the idea the plot serves. Start by listing the major conflicts: Vyaksihnhu vs. Oakh/J, freedom vs. security, conscience vs. law. Then ask: Which side does the story favor? Look at the ending—Vyaksihnhu's dignity remains intact. The key insight: The story argues that moral courage is the highest form of education.

## DIAGNOSTIC_QUESTION_1
What is the primary theme of "उद्देश्य का नक्षत्र" as expressed through the conflict between Vyaksihnhu and the government official?

## DIAGNOSTIC_ANSWER_1
The primary theme is the conflict between individual conscience and state authority, showing that true education leads to moral resistance against oppression. A wrong answer (e.g., "It's about a teacher getting a job") reveals the student confuses plot with theme.

## DIAGNOSTIC_QUESTION_2
Explain in your own words why Vyaksihnhu refuses the government job offered by Oakh/J, and what this refusal reveals about the story's message.

## DIAGNOSTIC_ANSWER_2
Vyaksihnhu refuses because accepting would mean betraying his principles and the cause of freedom; the message is that dignity and freedom are inseparable. A wrong answer focusing only on his pride or stubbornness misses the ideological dimension.

## DIAGNOSTIC_QUESTION_3
Apply the concept of 'primary theme' to a new situation: If the story ended with Vyaksihnhu accepting the job but secretly helping revolutionaries, how would the primary theme change? Justify with reference to the original theme.

## DIAGNOSTIC_ANSWER_3
The theme would shift from 'open moral resistance' to 'pragmatic compromise', suggesting survival over principled stand. The original theme of uncompromising conscience would be diluted. A wrong answer that says the theme remains the same ignores the significance of public vs. private resistance.

## DIAGNOSTIC_QUESTION_4
Analyze how the setting (colonial prison, government office) and the supporting character (Oakh/J) function together to sharpen the primary theme.

## DIAGNOSTIC_ANSWER_4
The colonial setting embodies systemic oppression; Oakh/J represents the seductive power of the state. Their interaction with Vyaksihnhu in these spaces highlights the theme by making the abstract conflict concrete. A wrong answer that treats setting as mere backdrop misses its thematic role.

## DIAGNOSTIC_QUESTION_5
Evaluate the statement: "The story's primary theme is not patriotism but the definition of true education." Defend or critique using textual evidence.

## DIAGNOSTIC_ANSWER_5
The statement is defensible: the opening quotes define education as awakening consciousness, and Vyaksihnhu's refusal is an educational act. However, patriotism is the content of that education. A wrong answer that rejects the statement outright fails to see the meta-theme of education.

## DIAGNOSTIC_QUESTION_6
Create a one-paragraph alternative ending for the story that reinforces the same primary theme but changes the plot outcome. Explain how your ending preserves the theme.

## DIAGNOSTIC_ANSWER_6
Example: Vyaksihnhu is executed but his last letter inspires a student to continue the struggle. The theme of conscience inspiring future resistance is preserved. A poor ending (e.g., he escapes and lives happily) would betray the theme of sacrifice.

## COMMON_MISCONCEPTION
Students often think the primary theme is simply "patriotism" or "freedom struggle." They miss that the story is equally about what constitutes true education (as per the epigraphs) and the internal moral architecture of resistance. They also confuse the protagonist's personal traits (stubbornness) with the thematic statement.

## ON_FAILURE
1. Re-read the epigraphs at the start of the chapter—they define education and literature's role. 2. Map each major scene to a question: "What does this scene teach about the cost of conscience?" 3. Compare Vyaksihnhu and Oakh/J as foil characters representing two philosophies. 4. Write a one-sentence theme statement using the formula: "The story argues that [abstract idea] because [evidence]."

## BUILDS_ON
Character analysis of the protagonist (node 004) and supporting characters (node 005) provides the behavioral evidence for thematic claims.

## LEADS_TO
Secondary themes (node 007) such as the role of women, the psychology of the oppressor, and the symbolism of the night sky.

## PREREQUISITE_NODE_IDS
c11_hin_ar_cbse_01_001, c11_hin_ar_cbse_01_002, c11_hin_ar_cbse_01_003, c11_hin_ar_cbse_01_004, c11_hin_ar_cbse_01_005
## PREREQUISITE_REASONS
c11_hin_ar_cbse_01_001: Provides historical context of colonial India necessary to understand the stakes.
c11_hin_ar_cbse_01_002: Plot structure reveals the thematic arc through conflict, climax, resolution.
c11_hin_ar_cbse_01_003: Setting establishes the oppressive atmosphere that makes the theme urgent.
c11_hin_ar_cbse_01_004: Protagonist's characterization shows the embodiment of the theme.
c11_hin_ar_cbse_01_005: Supporting characters (especially Oakh/J) serve as thematic foils.

## FORWARD_NODE_IDS
c11_hin_ar_cbse_01_007, c11_hin_ar_cbse_01_008, c11_hin_ar_cbse_01_009, c11_hin_ar_cbse_01_013, c11_hin_ar_cbse_01_014, c11_hin_ar_cbse_01_015, c11_hin_ar_cbse_01_010, c11_hin_ar_cbse_01_012, c12_hin_a_cbse_01_006, c12_hin_a_cbse_02_006, c12_hin_a_cbse_03_006, c12_hin_a_cbse_04_006, c12_hin_a_cbse_06_006, c12_hin_a_cbse_12_006, c12_hin_a_cbse_13_006, c12_hin_a_cbse_17_001, c12_hin_a_cbse_17_006, c12_hin_al_cbse_01_006, c12_hin_al_cbse_02_006, c12_hin_ar_cbse_01_001, c12_hin_ar_cbse_01_006, c12_hin_ar_cbse_03_006, c12_hin_ar_cbse_12_006

## FORWARD_REASONS
c11_hin_ar_cbse_01_007: Primary theme establishes the framework for identifying secondary themes.
c11_hin_ar_cbse_01_008: Imagery and metaphor are tools used to reinforce the primary theme.
c11_hin_ar_cbse_01_009: Irony and symbolism deepen the thematic expression.
c11_hin_ar_cbse_01_013: Critical thinking requires a firm grasp of the primary theme to analyze further.
c11_hin_ar_cbse_01_014: Writing tasks often ask for thematic essays.
c11_hin_ar_cbse_01_015: Discussions center on thematic interpretations.
c11_hin_ar_cbse_01_010: Primary theme (dignity vs. exploitation) is the thematic lens through which ambiguous words (*vdkjFk, rtoh"k*) must be read.  
c11_hin_ar_cbse_01_012: Primary theme (social justice) gives the thematic framework that guides valid inferences  
c12_hin_a_cbse_01_006: Class 11 theme-analysis practice (Aroh) builds the skill of moving from topic to thematic statement.  
c12_hin_a_cbse_02_006: Introduces theme identification in Class 11 poetry — foundational skill.  
c12_hin_a_cbse_03_006: Class 11 foundation for distinguishing subject vs. theme and writing thematic statements.  
c12_hin_a_cbse_04_006: Class 11 Antra theme analysis builds the skill of thematic statement formulation.  
c12_hin_a_cbse_06_006: Class 11 foundation on theme identification methodology (topic vs theme, evidence-based claim).  
c12_hin_a_cbse_12_006: Prior practice in theme identification from Class 11 Antra stories provides the analytical vocabulary (theme vs. plot vs. moral).  
c12_hin_a_cbse_13_006: Class 11 foundation on theme identification/analysis; assumes prior practice.  
c12_hin_a_cbse_17_001: Class 11 Theme analysis for Namak ka Daroga — introduces "identity vs duty" theme that reappears as "uke vs :i" in this chapter.  
c12_hin_a_cbse_17_006: Prior practice in identifying primary theme in Class 11 Aaroh chapters builds the analytical skill required here.  
c12_hin_al_cbse_01_006: Class 11 theme node establishes the basic definition and identification method (topic vs. theme) which Class 12 deepens.  
c12_hin_al_cbse_02_006: Foundational definition of theme vs message vs moral from Class 11.  
c12_hin_ar_cbse_01_001: Class 11 Theme node for Chapter 1 covered प्रगतिवाद's core ideas (social realism, anti-romanticism) — essential to recognize Muktibodh's lineage.  
c12_hin_ar_cbse_01_006: Class 11 theme node provides the foundational subject vs. theme distinction this node deepens.  
c12_hin_ar_cbse_03_006: Class 11 theme-analysis skill (identifying central idea, tracing across stanzas, using textual evidence) is the direct methodological prerequisite.  
c12_hin_ar_cbse_12_006: Class 11 theme-analysis practice establishes the method (identify → trace → articulate).  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
none

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_01_001 -> c11_hin_ar_cbse_01_006 -> c11_hin_ar_cbse_01_007

## THIS_FORMULA
Theme Statement = Central Conflict + Author's Resolution + Universal Insight

## FORMULA_VARIABLES
Central Conflict: The opposing forces in the story (conscience vs. state). Author's Resolution: How the conflict ends (Vyaksihnhu chooses imprisonment). Universal Insight: The general truth about human experience (moral courage defines true education).

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
analytical

## CROSS_SUBJECT
c11_history_nationalism | The story reflects the historical reality of colonial education and nationalist resistance in early 20th century India.
c11_civics_fundamental_rights | The conflict illustrates the tension between state authority and individual rights to conscience and expression.

## PREREQ_CONCEPT
Understanding the difference between plot (what happens) and theme (what it means) is essential before analyzing primary theme.

## PREREQ_BEFORE
Student must be able to summarize the plot and describe the main characters' motivations.

## PREREQ_STUCK
If stuck, review the character analysis of Vyaksihnhu (node 004) and the plot structure (node 002).

## WORKED_EXAMPLE_1
PROBLEM: Identify the primary theme of "उद्देश्य का नक्षत्र" and trace its development through three key episodes in the story.
STEPS:
- Step 1: Recall the central conflict—Vyaksihnhu (teacher, nationalist) vs. Oakh/J (colonial official) over a government job offer.
- Step 2: List three pivotal episodes: (a) the job offer in prison, (b) the dialogue on education and duty, (c) Vyaksihnhu's final refusal and return to cell.
- Step 3: For each episode, note the thematic beat: (a) temptation of security vs. principle, (b) debate on what true education means, (c) action confirming the theme.
- Step 4: Synthesize: The story moves from external pressure to internal clarification to decisive action, illustrating that true education culminates in moral courage.
- Step 5: Formulate theme statement: "The story demonstrates that genuine education awakens an unyielding conscience that resists oppression even at the cost of personal freedom."
- Step 6: Verify against epigraphs: The opening quotes define education as awakening world-view and art as portraying truth in darkness—both align.
REASONING: This step-by-step method moves from concrete plot points to abstract theme, ensuring textual grounding.
ANSWER: Primary theme: The story argues that true education is not mere literacy but the awakening of conscience that compels resistance against injustice, as embodied in Vyaksihnhu's refusal to collaborate with colonial authority.

## WORKED_EXAMPLE_2
PROBLEM: Explain how the character of Oakh/J serves as a thematic foil to highlight the primary theme.
STEPS:
- Step 1: Define thematic foil—a character who contrasts with the protagonist to emphasize thematic qualities.
- Step 2: Identify Oakh/J's traits: pragmatic, loyal to state, views education as career, uses persuasion and threat.
- Step 3: Contrast with Vyaksihnhu: idealistic, loyal to conscience, views education as liberation, uses silence and sacrifice.
- Step 4: Map each contrast to theme: Oakh/J represents colonial co-option; Vyaksihnhu represents resistance. Their debate dramatizes the theme.
- Step 5: Note the narrative effect: Oakh/J's failure to convert Vyaksihnhu proves the theme's strength—conscience cannot be bought.
- Step 6: Conclude: The foil structure makes the theme visible through conflict rather than narration.
REASONING: Foil analysis is a standard literary technique for theme extraction; it shows theme through character dynamics.
ANSWER: Oakh/J embodies the colonial worldview that equates success with collaboration; his inability to sway Vyaksihnhu underscores the theme that true education creates an inner freedom no external power can conquer.

## WORKED_EXAMPLE_3
PROBLEM: A board exam question asks: "The story 'उद्देश्य का नक्षत्र' is as much about the definition of education as about patriotism." Analyze this statement with reference to the text.
STEPS:
- Step 1: Deconstruct the statement—two claims: (1) story defines education, (2) patriotism is not the sole focus.
- Step 2: Locate textual evidence for education definition: epigraphs (Tagore, Hazari Prasad Dwivedi), Vyaksihnhu's dialogue on "शिक्षा का अर्थ".
- Step 3: Locate evidence for patriotism: Vyaksihnhu's past activism, the nationalist context, the prison setting.
- Step 4: Analyze relationship: Patriotism is the content of the awakened conscience; education is the process. The story shows education leading to patriotic resistance.
- Step 5: Evaluate the balance: The climax is educational (Vyaksihnhu teaches Oakh/J a lesson) as much as political.
- Step 6: Synthesize answer: The statement is accurate because the narrative frames the political act as an educational outcome—Vyaksihnhu's refusal is a pedagogical act for the oppressor and the reader.
REASONING: Board questions often require evaluating a critical statement; this requires separating and linking two concepts.
ANSWER: The story uses the nationalist struggle as a vehicle to explore its deeper concern: what constitutes true education. The epigraphs and Vyaksihnhu's final act both define education as the courage to stand for truth, making patriotism a manifestation of that education.

## COMPETENCY_QUESTION_1
QUESTION: "In the story, the night sky and the stars are mentioned repeatedly. How does this imagery connect to the primary theme of the story?" 
COMPETENCY: Literary analysis - connecting imagery to theme
STEPS:
- Step 1: Recall the primary theme (conscience vs. state, true education as resistance).
- Step 2: Identify references to night sky/stars in the text (e.g., "नक्षत्र", "आकाश", "तारे").
- Step 3: Analyze symbolic meaning: stars as distant, constant, guiding lights—like ideals.
- Step 4: Link to theme: Vyaksihnhu's conscience is his "नक्षत्र" (guiding star) that remains visible even in the darkness of prison.
- Step 5: Formulate answer: The imagery reinforces the theme by symbolizing the enduring, guiding nature of moral truth amid oppression.
ANSWER: The recurring night-sky imagery symbolizes the protagonist's inner moral compass—the "नक्षत्र" of the title—which remains steadfast in the darkness of colonial imprisonment, just as true education provides an unerring guide for conscience.
DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: "Compare the primary theme of 'उद्देश्य का नक्षत्र' with that of another Hindi story you have studied (e.g., 'उपन्यास' or 'बड़े भाई साहब'). How do both stories use the teacher-student or authority-subordinate dynamic to explore the meaning of education?" 
COMPETENCY: Comparative thematic analysis across texts
STEPS:
- Step 1: State the primary theme of 'उद्देश्य का नक्षत्र' (education as moral courage).
- Step 2: Recall the primary theme of the other story (e.g., 'बड़े भाई साहब': education as experiential wisdom vs. bookish knowledge).
- Step 3: Identify the authority-subordinate dynamic in each: Vyaksihnhu-Oakh/J (teacher-official), younger brother-older brother (student-teacher reversed).
- Step 4: Analyze how each dynamic tests the definition of education: in Izsepan, the test is political/moral; in Bade Bhai Sahab, it's practical vs. academic.
- Step 5: Synthesize comparison: Both stories reject institutional definitions of education in favor of lived, ethical understanding.
- Step 6: Write a structured comparative answer.
ANSWER: Both stories critique formal education: 'उद्देश्य का नक्षत्र' shows education as conscience that resists state power, while 'बड़े भाई साहब' shows it as wisdom from life experience. The authority figure in each (Oakh/J, older brother) represents conventional success, but the subordinate (Vyaksihnhu, younger brother) embodies a deeper, truer education.
DIFFICULTY: hard