## DEFINITION
Speaking and Listening: Discussion Points for "जतुः" refers to the structured oral competency where students articulate analytical perspectives on the play's exploration of institutional failure in education, parental complicity in student distress, and the systemic normalization of coaching culture, using textual evidence to substantiate arguments while practicing active listening and respectful rebuttal in a collaborative inquiry format.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student must independently initiate a discussion thread by posing an interpretive question grounded in a specific scene, sustain the exchange by integrating at least two peers' contributions with textual citations, and conclude by synthesizing a nuanced position that acknowledges counter-perspectives from the play's multi-voiced structure.

## SCOPE_BOUNDARY
This node covers facilitation of discussion on the play's central conflict (coaching culture vs. student well-being), character motivations (Jtuh's moral courage vs. institutional inertia), and thematic resonance (systemic complicity); it does NOT cover formal debate rules, public speaking techniques, or assessment rubrics for speaking skills which belong to the broader curriculum framework.

## WALKTHROUGH
Imagine you're in a parent-teacher meeting where the principal dismisses a student's suicide attempt as "weakness" — how would you respond using only what the play shows? Begin by identifying the scene where Jtuh confronts the principal (pages 80-81) and mark every instance where institutional language ("नियम", "फाइल", "फीस") clashes with human language ("बच्चा", "माँ", "दर्द"). Next, trace how three characters — Yathyak's mother, Vafar, and the Grihsevak — each represent a different form of complicity. Then practice the "Yes, and..." protocol: accept a peer's point about parental pressure, then add how the play shows parents themselves as victims of the same system. Finally, formulate a discussion question that cannot be answered with a simple "yes/no" but requires weighing evidence from at least two scenes.

## DIAGNOSTIC_QUESTION_1
What is the primary dramatic conflict that structures the discussion points in "जतुः", and which two characters embody the opposing poles of this conflict most sharply?

## DIAGNOSTIC_ANSWER_1
The primary conflict is the tension between institutional self-preservation (embodied by the Principal who prioritizes rules, fees, and reputation) and moral accountability (embodied by Jtuh who risks her career to expose systemic cruelty). A wrong answer identifying "student vs. teacher" or "rich vs. poor" reveals the student has reduced the play's systemic critique to interpersonal drama, missing how the Principal's "नियम" and Jtuh's "नियम तोड़ना" represent competing logics of education itself.

## DIAGNOSTIC_QUESTION_2
Explain why Yathyak's mother's shift from defending the coaching system (page 70: "अच्छा ही तो था... कोचिंग में पढ़ते थे") to condemning it (page 83: "फीस के नाम पर... बच्चों की जान ले रहे हैं") is dramatically necessary for the play's argument about complicity.

## DIAGNOSTIC_ANSWER_2
Her transformation demonstrates that complicity is not static villainy but active participation sustained by hope and fear; the play argues that parents become enforcers of the very system that destroys their children because they internalize its metrics (marks, ranks, fees paid) as love. A wrong answer treating her as "hypocritical" or "inconsistent" reveals the student reads character psychologically rather than structurally, missing how the play uses her arc to indict the system's ability to colonize parental love.

## DIAGNOSTIC_QUESTION_3
Using the Grihsevak's testimony (pages 82-83: "दोनों घंटों... बच्चों की जान ले रहे हैं"), construct a discussion prompt that forces participants to confront the play's implication that non-teaching staff often witness institutional violence more clearly than educators.

## DIAGNOSTIC_ANSWER_3
Effective prompt: "The Grihsevak sees 'दोनों तरफ से बच्चों की जान ली जा रही है' while the Principal sees 'नियम'. What does this gap in perception reveal about who is permitted to know what in educational institutions? Cite one moment where a teacher's professional role blinds them to what a servant sees." A weak prompt asking "Is the Grihsevak reliable?" reveals the student treats testimony as factual evidence rather than dramatic perspective, missing the play's epistemic hierarchy critique.

## DIAGNOSTIC_QUESTION_4
Analyze how the play's final stage direction — "सारा मैदान... एक नया आंदोलन का उद्गम" — transforms Jtuh's individual act of whistleblowing into a collective possibility, and why this matters for discussion design.

## DIAGNOSTIC_ANSWER_4**
The direction refuses tragic closure (Jtuh's suspension) by staging the aftermath as collective awakening: parents, students, and the Grihsevak converge, suggesting resistance requires crossing the very boundaries (teacher/parent, insider/outsider) the system enforces. Discussion design must therefore move beyond "Was Jtuh right?" to "What alliances does the play imagine as necessary for change?" A response focusing on Jtuh's heroism reveals the student defaults to individual moralism, missing the play's structural insistence that accountability is collective.

## DIAGNOSTIC_QUESTION_5
Evaluate the pedagogical risk of framing the play's coaching critique as "coaching is bad" versus "the coaching industry exploits parental anxiety and institutional vacancy". Which framing better serves the play's complexity and why?

## DIAGNOSTIC_ANSWER_5
The second framing is superior because it preserves the play's systemic analysis: coaching fills a vacuum created by school failure (Principal admits "स्कूल का काम ही है कि शिक्षा के प्रचार-प्रसार में जितना भी हो सके योगदान दे"), and parents choose it desperate for mobility ("गरीब माँ-बाप... फीस देते हैं"). The first framing lets institutions off the hook by making coaching an external villain. A student defending the first framing reveals they read the play as social commentary rather than institutional critique, missing how the Principal's "फीस के नाम पर" indictment implicates the entire educational economy.

## DIAGNOSTIC_QUESTION_6
Create a discussion opening that uses Vafar's silence (pages 72-73: "हूँ... हूँ... देखते क्या हो") as a metaphor for student voicelessness, and requires participants to trace how the play both represents and resists that silence through its dramatic form.

## DIAGNOSTIC_ANSWER_6
Strong opening: "Vafar speaks mostly in grunts and fragmented sentences until Jtuh forces his file open — his silence is the play's central sound. How does the script's structure — overlapping dialogues, stage directions describing bodily collapse, the Grihsevak's testimony — make audible what Vafar cannot say? Identify one moment where the form itself 'speaks' for him." A weak opening asking "Why is Vafar quiet?" reveals the student treats silence as character trait rather than dramatic strategy, missing how the play's polyphonic form (multiple voices, interrupted speeches, offstage sounds) enacts the struggle for voice.

## COMMON_MISCONCEPTION
Students conflate "discussion points" with "opinions about the story" — they treat the play as a source of debatable topics (e.g., "Should coaching be banned?") rather than as a structured argument about institutional logic that demands evidence-based analysis. This error stems from school-level "group discussion" practice where personal opinion is valued over textual grounding. For example, a student might say "I think parents are to blame" without citing the mother's initial defense of coaching (page 70) or the Principal's admission that schools have abdicated responsibility (page 80), thereby missing how the play distributes complicity across the entire ecosystem.

## ON_FAILURE
If a student offers opinion untethered from text: (1) Pause and ask "Which line or stage direction makes you say that?" — wait for a specific citation. (2) If they cannot cite, direct them to the relevant page cluster (e.g., "Look at pages 79-81 where the Principal and Jtuh debate 'नियम'") and have them read aloud the exchange. (3) Then ask: "What does the Principal mean by 'नियम'? What does Jtuh mean?" — forcing semantic analysis. (4) Finally, have them reformulate their point using the format: "The play suggests X because [character] says [quote] in [scene], which contrasts with [other character]'s [quote] in [scene]."

## BUILDS_ON
c11_hin_ar_cbse_06_013: Critical Thinking: Analysis and Interpretation (provides the analytical framework for dissecting the play's systemic critique)

## LEADS_TO
c11_hin_ar_cbse_06_014: Writing Skills: Based on the Chapter (discussion insights become raw material for structured analytical writing)

## PREREQUISITE_NODE_IDS
c11_hin_ar_cbse_06_001, c11_hin_ar_cbse_06_002, c11_hin_ar_cbse_06_004, c11_hin_ar_cbse_06_006, c11_hin_ar_cbse_06_013, c11_hin_ar_cbse_06_008, c11_hin_ar_cbse_06_009, c11_hin_ar_cbse_06_011, c11_hin_ar_cbse_06_012, c11_hin_ar_cbse_06_014

## PREREQUISITE_REASONS
c11_hin_ar_cbse_06_001: Context and Background establishes the New Story Movement and Usha Priyamvada's social realism — essential for understanding the play's documentary intent
c11_hin_ar_cbse_06_002: Plot and Narrative Structure provides the scene-sequence map needed to locate discussion evidence chronologically
c11_hin_ar_cbse_06_004: Character Analysis: Protagonist (Jtuh) gives the moral center around which discussion tensions organize
c11_hin_ar_cbse_06_006: Theme: Primary Theme and Message identifies the systemic critique that discussion must engage
c11_hin_ar_cbse_06_013: Critical Thinking: Analysis and Interpretation supplies the methodological tools (evidence, inference, synthesis) for rigorous discussion
c11_hin_ar_cbse_06_008: Speaking/listening discussions reference textual imagery for oral analysis.  
c11_hin_ar_cbse_06_009: Discussion points on caste and education are enriched by referencing specific ironic scenes and symbols.  
c11_hin_ar_cbse_06_011: Speaking tasks (discussion) need vocabulary to articulate linguistic observations.  
c11_hin_ar_cbse_06_012: Speaking/listening discussions need students to distinguish fact from interpretation  
c11_hin_ar_cbse_06_014: Written analyses form the basis for structured group discussions and oral presentations in the speaking/listening node.  

## FORWARD_NODE_IDS
c12_hin_a_cbse_12_015, c12_hin_al_cbse_02_015, c12_hin_al_cbse_03_015, c12_hin_ar_cbse_06_015, c12_hin_ar_cbse_12_015

## FORWARD_REASONS
This is the terminal node in the chapter sequence; discussion mastery demonstrates readiness for the chapter's writing assessment (node 014) and board-level speaking evaluation.
c12_hin_a_cbse_12_015: अगला तार्किक चरण: Speaking and Listening: इस नोड की अवधारणाओं को सीधे उपयोग/विस्तारित करता है।  
c12_hin_al_cbse_02_015: Exposure to peer feedback mechanisms in speaking tasks.  
c12_hin_al_cbse_03_015: Familiarity with evidence-based oral argument  
c12_hin_ar_cbse_06_015: Prior exposure to Nirala's style in Class 11 Aroh (Chapter 6) enables comparative depth.  
c12_hin_ar_cbse_12_015: अगला तार्किक चरण: Speaking and Listening: इस नोड की अवधारणाओं को सीधे उपयोग/विस्तारित करता है।  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
No prior class nodes available for cross-subject mapping in this dataset.

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_06_013 -> c11_hin_ar_cbse_06_015 -> c11_hin_ar_cbse_06_014: Critical analysis enables evidence-based discussion which feeds into structured analytical writing on the play's institutional critique.

## THIS_FORMULA
Discussion Point = Interpretive Question + Textual Anchor (specific scene/line) + Multi-perspective Mapping (at least 2 character positions) + Systemic Implication (what this reveals about the institution)

## FORMULA_VARIABLES
Interpretive Question: An open-ended query about meaning, not fact (e.g., "Why does the Principal invoke 'नियम' when confronted with a dying child?")
Textual Anchor: Precise location in script (page, speaker, stage direction) that grounds the question
Multi-perspective Mapping: Identification of how 2+ characters embody competing logics on the issue
Systemic Implication: The structural insight the play offers beyond individual morality

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
linguistic

## CROSS_SUBJECT
c11_psychology_adolescent_mental_health | The play dramatizes academic pressure as a mental health crisis; discussion points must engage how institutional structures (coaching, school, family) produce pathological outcomes — connects to psychology's study of systemic stressors on adolescent development
c11_sociology_education_and_social_stratification | The coaching industry's role in reproducing class inequality (fees as barrier, "गरीब माँ-बाप" vs. "अमीर") mirrors sociology's analysis of education as both mobility channel and stratification mechanism
c11_political_science_right_to_education_policy | The Principal's "नियम" vs. Jtuh's "बच्चों की जान" enacts the policy tension between bureaucratic compliance and substantive right to education — discussion must trace how the play critiques implementation gaps in RTE

## PREREQ_CONCEPT
The play's central argument: educational institutions have replaced pedagogical duty with bureaucratic self-preservation, and this shift is enforced through a language of "rules" that obscures human cost.

## PREREQ_BEFORE
Student must be able to identify the three institutional languages in the play: bureaucratic (Principal: "फाइल", "नियम", "फीस"), commercial (Coaching: "रैंक", "फीस", "वीआईपी"), and human (Jtuh/Grihsevak: "बच्चा", "माँ", "दर्द").

## PREREQ_STUCK
If stuck, review c11_hin_ar_cbse_06_006 (Primary Theme) to re-anchor in the play's systemic thesis, then c11_hin_ar_cbse_06_004 (Jtuh's character) to recall how her moral vocabulary opposes institutional vocabulary.

## WORKED_EXAMPLE_1
PROBLEM: A student offers the discussion point: "The play shows that teachers don't care about students." Design a facilitation move that redirects this toward the play's structural analysis using the Discussion Point Formula.

STEPS:
- Step 1: Identify the student's claim as an opinion about individual morality ("teachers don't care") rather than a structural claim about institutional logic.
- Step 2: Apply the Formula's Textual Anchor requirement: ask "Which scene makes you say that? Give me the page and speaker."
- Step 3: When student cites Jtuh-Principal confrontation (pages 80-81), apply Multi-perspective Mapping: "The Principal says 'नियम का काम ही है कि शिक्षा के प्रचार-प्रसार में जितना भी हो सके योगदान दे' — he claims to care. Jtuh says 'ये नियम... बच्चों की जान ले रहे हैं'. What's the gap between their definitions of 'care'?"
- Step 4: Apply Systemic Implication: "So the play isn't saying teachers lack care — it's saying the institution defines 'care' as rule-following. How does the Grihsevak's testimony (page 82) confirm this?"
- Step 5: Synthesize a reformulated discussion point: "The play suggests institutional 'care' is structurally incompatible with student survival because 'नियम' prioritizes institutional continuity over individual life — evidenced by the Principal's defense of rules while a student dies, contrasted with the Grihsevak's witness."

REASONING: The Formula forces movement from moral judgment (teachers = bad) to structural analysis (institutional logic redefines care as compliance), which is the play's actual argument. The Textual Anchor prevents vague generalization; Multi-perspective Mapping reveals the play's dialectical structure; Systemic Implication extracts the transferable insight.

ANSWER: Reformulated discussion point: "How does the play demonstrate that the category of 'care' is colonized by institutional bureaucracy? Compare the Principal's 'नियम... योगदान दे' (p.80) with Jtuh's 'नियम... जान ले रहे हैं' (p.81) and the Grihsevak's 'दोनों तरफ से बच्चों की जान ली जा रही है' (p.82) to show three competing definitions of what it means to care for a student in this system."

## WORKED_EXAMPLE_2
PROBLEM: During discussion, a student argues: "Vafar's father is the real villain — he pushed his son into coaching and ignored his distress." Facilitate a response that uses the play's evidence to complicate this reading without dismissing it.

STEPS:
- Step 1: Acknowledge the textual basis: "Yes, page 69 shows him saying 'पढ़ाई में बहुत पैसा लगता है... कोचिंग जरूरी है' and page 73 he dismisses Vafar's collapse as 'थकान'."
- Step 2: Apply Multi-perspective Mapping by introducing the counter-evidence: "But page 83 shows him at the protest — 'पिता... हाथ में तख्ती लिए' — and page 77 his wife says 'आपने ही तो कहा था... अच्छा इंजीनियर बनेगा'."
- Step 3: Trace the father's arc across the play's timeline: initial investor in the dream (p.69) → dismissive of distress (p.73) → grieving participant in resistance (p.83).
- Step 4: Apply Systemic Implication: "The play doesn't let him stay a villain — it shows him as a parent trapped in the same metrics (engineer son, fees paid, rank achieved) that the system sells as 'good parenting'. His villainy and victimhood are simultaneous."
- Step 5: Formulate a discussion question that holds this complexity: "The father both enforces and resists the system. What does this duality reveal about how the coaching industry captures parental aspiration? Use his three appearances (pp.69, 73, 83) to argue whether he changes or the system changes him."

REASONING: The play refuses stable moral categories — characters are positions in a structure. The father's trajectory from enforcer to protester illustrates how the system consumes its own enforcers. Discussion must preserve this dialectic rather than settle on "villain" or "victim."

ANSWER: Discussion question: "Vafar's father occupies the contradictory position of both fueling the coaching machine (p.69: 'कोचिंग जरूरी है') and joining its resistance (p.83: protest). Does his final act redeem his earlier complicity, or does the play suggest redemption is impossible within the system? Argue using his dismissal of Vafar's distress (p.73) as either evidence of unchanged mindset or proof of the system's power to silence even a father's instinct."

## WORKED_EXAMPLE_3
PROBLEM: A discussion group reaches consensus that "the Principal is the antagonist." Design a sequence of moves that uses the play's polyphonic structure to disrupt this consensus and deepen systemic analysis.

STEPS:
- Step 1: Surface the consensus: "Everyone agrees the Principal is the antagonist. Let's test that against the play's structure."
- Step 2: Introduce the Principal's own framing (p.80): "'फीस के नाम पर... बच्चों की जान ले रहे हैं' — he admits the coaching industry kills. He's not denying harm; he's claiming helplessness: 'स्कूल का काम ही है कि शिक्षा के प्रचार-प्रसार में जितना भी हो सके योगदान दे'."
- Step 3: Map the Principal's constraints: he answers to "प्रबंधन" (management), "फाइल" (bureaucracy), "बजट" (budget) — cited in his "मेरे हाथ में कुछ नहीं" (p.81).
- Step 4: Contrast with Jtuh's position: she has "नौकरी" (job) to lose but chooses "नियम तोड़ना" (breaking rules). The play asks: why can she break rules but he cannot?
- Step 5: Introduce the Grihsevak as third pole (p.82): he has no institutional power but sees most clearly — "मैं तो चौकीदार हूँ... पर आँखें हैं".
- Step 6: Synthesize a systemic reframing: "The antagonist isn't a person — it's the structure that makes the Principal's helplessness rational and Jtuh's courage irrational. The play's tragedy is that the only character with institutional power to stop the harm (Principal) is structurally prevented from using it, while the character with moral clarity (Jtuh) has no power."

REASONING: Consensus on "villain" collapses the play's institutional critique into character critique. The polyphonic structure (Principal's admission, Jtuh's risk, Grihsevak's witness) distributes agency and complicity across the system. Discussion must model this distribution.

ANSWER: Reframed discussion prompt: "The Principal admits the coaching industry kills children (p.80) but claims 'मेरे हाथ में कुछ नहीं'. Jtuh has no institutional power but breaks rules to save Vafar. The Grihsevak has no power and no rule-breaking capacity but his testimony triggers the climax. Map the relationship between institutional position, moral vision, and effective action across these three characters. What does this triangle reveal about where change can originate in the play's world?"

## COMPETENCY_QUESTION_1
QUESTION: A Class 11 student prepares a 2-minute spoken intervention for a panel discussion on "Coaching Culture and Student Well-being" using "जतुः" as the primary text. They must: (a) state a clear thesis grounded in the play's systemic critique, (b) cite two specific dramatic moments as evidence, (c) anticipate and rebut the counter-argument that "coaching provides necessary academic support," and (d) conclude with a policy-relevant insight drawn from the play's final scene. Outline the structure of this intervention with specific textual references.

COMPETENCY: Evidence-based oral argumentation with counter-argument integration

STEPS:
- Step 1: Formulate thesis using Systemic Implication from Formula: "The play argues coaching is not an educational supplement but a parasitic industry that fills the vacuum left by school failure, converting parental anxiety into profit while schools abdicate responsibility."
- Step 2: Select Evidence 1: Principal's admission (p.80) that schools have ceded ground to coaching — "फीस के नाम पर... बच्चों की जान ले रहे हैं" spoken by the Principal himself.
- Step 3: Select Evidence 2: Grihsevak's witness (p.82) that coaching centers operate "दोनों तरफ से" — extracting fees while delivering harm — with institutional indifference.
- Step 4: Construct Counter-argument Rebuttal: Acknowledge coaching's academic function (Yathyak's mother p.70: "अच्छा ही तो था... कोचिंग में पढ़ते थे") but reframe using Jtuh's distinction (p.81): "तूशन पढ़ने वाला बच्चा... कोचिंग वाला बच्चा नहीं" — coaching replaces schooling, it doesn't supplement it.
- Step 5: Derive Policy Insight from Final Scene (p.83-84): The protest's demand — "कोई भी व्यावसायिक संस्था... अपने फायदे के लिए बच्चों की जान नहीं ले सकती" — translates to: regulation must separate educational service from commercial exploitation, and schools must be legally compelled to reclaim their pedagogical duty.

ANSWER: Structured intervention outline:
1. Thesis (15s): "जतुः exposes coaching as a symptom of school failure, not a solution to it."
2. Evidence 1 (30s): Principal's own indictment (p.80) — the institution meant to protect children admits the industry kills them.
3. Evidence 2 (30s): Grihsevak's ground-level testimony (p.82) — the system extracts fees from both ends while children collapse.
4. Rebuttal (30s): Coaching appears as "support" (mother, p.70) but structurally replaces school (Jtuh, p.81) — the play shows this substitution, not supplementation.
5. Policy Insight (15s): Final protest demands (p.83) — legal separation of education from commerce, and enforced school accountability.

DIFFICULTY: hard

## COMPETENCY_QUESTION_2
QUESTION: Design a 15-minute student-led discussion session on "जतुः" for a mixed-ability Class 11 section. The session must: (a) open with an interpretive question that admits no single answer, (b) include a structured protocol ensuring every student contributes at least once, (c) incorporate a mid-session "evidence hunt" where students locate textual support for emerging claims, and (d) close with a synthesis move that maps the discussion's trajectory onto the play's systemic argument. Provide the complete session plan with timing, prompts, and facilitation notes.

COMPETENCY: Discussion design and facilitation for literary analysis

STEPS:
- Step 1: Opening Question (2 min): "The play shows three fathers — Vafar's (investor), Yathyak's (absent), and the Principal (institutional father). Which father fails most catastrophically, and what does this failure reveal about the system?" — No single answer; each choice implicates a different structural node.
- Step 2: Round-Robin First Pass (5 min): Each student states position in one sentence with one textual anchor. Facilitator maps positions on board: Father A (complicity), Father B (absence), Father C (bureaucratic capture).
- Step 3: Evidence Hunt (5 min): In pairs, students find one quote/stage direction per father that complicates the initial reading (e.g., Vafar's father at protest p.83; Principal's admission p.80; Yathyak's mother as proxy for absent father p.70).
- Step 4: Synthesis Discussion (3 min): Pairs report complications. Facilitator highlights pattern: all three fathers are positioned by the system — none acts freely.
- Step 5: Closing Synthesis (2 min): "We started asking 'which father fails' and discovered the play asks 'what system makes fatherhood complicit?' — this is the shift from moral to structural analysis that जतुः demands."

ANSWER: Complete session plan:
**0:00-0:02** Opening Question projected: "Three fathers. One system. Who fails?"
**0:02-0:07** Round-Robin: "Name + Position + One Line from Text" — facilitator records on three-column board.
**0:07-0:12** Evidence Hunt: Pair work with text. Prompt: "Find the moment your father contradicts your first reading."
**0:12-0:15** Synthesis: "The play doesn't judge fathers — it shows fatherhood as a role the system scripts." Connect to Jtuh's final speech (p.84): "नियम बदलने होंगे... पिता बदलने से नहीं होगा."

Facilitation Notes: If discussion stalls on "Vafar's father is worst," redirect with Principal's p.80 line. If "Principal is worst," redirect with Grihsevak's p.82 "चौकीदार हूँ... आँखें हैं" — the Principal sees but cannot act; the Grihsevak sees and speaks. The synthesis must land on: individual moral failure is the system's alibi.

DIFFICULTY: medium