## DEFINITION
Grammar: Language Usage in the Text refers to the systematic analysis of how a poet manipulates standard Hindi grammar — including tense-aspect-mood choices, sentence structures, dialectal variations, compound formations, and syntactic deviations — to create poetic effects such as rhythm, emphasis, irony, or authentic rural voice, and how these choices serve the poem's thematic concerns.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student can independently identify three distinct grammatical features in the prescribed poems (e.g., dialectal verb forms, repetitive imperative structures, compound word formations), explain their function with textual evidence, and write a structured board-style answer linking each feature to the poem's theme or tone.

## SCOPE_BOUNDARY
This node covers grammatical analysis of the two poems "olar vk;k" and "rksM+ks" by j?kqohj lgk; in NCERT Class 12 Antra Chapter 5 — specifically tense/aspect patterns, dialectal verb morphology, imperative repetition, compound formations, and syntactic inversion. It does NOT cover general Hindi grammar rules unrelated to these poems, nor does it cover literary devices like metaphor or symbolism (covered in nodes 008, 009).

## WALKTHROUGH
Imagine you are asked in the board exam: "How does the poet's use of rural verb forms like 'pyrh' and 'xksy' contribute to the poem's authenticity?" Most students would just list the words. Instead, start by reading the poem aloud — notice how "pyrh pyrh pyrs" sounds different from standard "chalta rahta hai". First, mark every verb ending that deviates from standard Khari Boli. Second, group them: are they past habitual? Present continuous? Imperative? Third, ask: what picture of the farmer's life does this grammar paint? The key insight: grammatical deviation here is not error — it is a deliberate tool to make the urban reader hear the village voice.

## DIAGNOSTIC_QUESTION_1
Identify the tense-aspect of the verb form "pyrs" in the line "iqQVikFk ij pyrs pyrs pyrs" from the poem "olar vk;k" and state whether it is standard Khari Boli or dialectal.

## DIAGNOSTIC_ANSWER_1
Correct: "pyrs" is present habitual aspect, dialectal (Braj/Awadhi region) form corresponding to standard Khari Boli "chalta hai / chalte hain". The triplication "pyrs pyrs pyrs" marks iterative aspect — continuous repeated action. A wrong answer (e.g., calling it past tense or standard Hindi) reveals the student cannot distinguish dialectal verb morphology from standard forms, a critical gap for analyzing how the poem constructs rural voice.

## DIAGNOSTIC_QUESTION_2
Explain in your own words why the poet uses the imperative repetition "rksM+ks rksM+ks rksM+ks" at the start of the second poem instead of a single "rksM+ks" or a polite request like "rksM+ksiye".

## DIAGNOSTIC_ANSWER_2
Correct: The triple imperative mimics the rhythmic, physical act of threshing grain — each "rksM+ks" enacts a blow of the flail. It also reflects the collective, urgent voice of the community addressing the farmer, not an individual polite request. A wrong answer focusing only on "emphasis" without linking to the agricultural action or collective voice shows the student treats repetition as mere decoration, not as grammatical enactment of labor.

## DIAGNOSTIC_QUESTION_3
In the line "fe^h esa jl gksxk gh tc og ikslsxh cht dks", identify the grammatical mood of "gksxk" and "ikslsxh", and explain how the conditional structure "gh tc... tb" (implied) shapes the poem's argument about labor and reward.

## DIAGNOSTIC_ANSWER_3
Correct: "gksxk" is future indicative (standard Khari Boli), "ikslsxh" is future subjunctive/conditional (dialectal "ikslsxh" for standard "iksel"). The structure "gh tc... [result]" creates a cause-effect logic: ONLY when the plough shares the burden will the harvest be golden. A wrong answer misidentifying moods or missing the conditional logic reveals inability to see how grammar builds the poem's central thesis: justice in labor relations.

## DIAGNOSTIC_QUESTION_4
Compare the compound formations "pqjeqjk," (pjejkus dh vkok"k) and "enueghuk" (dkenso dk eghuk) from the vocabulary gloss. Analyze how their samasa type (tatpurusha vs. bahuvrihi) reflects different semantic relationships in the rural world the poem depicts.

## DIAGNOSTIC_ANSWER_4
Correct: "pqjeqjk," is tatpurusha (pjejkus dh vkok"k — desire FOR water), showing a direct object relationship — the crow's need is transitive, goal-directed. "enueghuk" is bahuvrihi (dkenso dk eghuk — one WHOSE master is the season), describing the farmer's identity as defined by an external force. A wrong answer confusing the samasa types or missing the semantic contrast shows the student cannot link morphological structure to the poem's portrayal of agency vs. subjugation.

## DIAGNOSTIC_QUESTION_5
Evaluate the claim: "The poet's use of dialectal forms like 'fiQjdh' (for fiQjgjh) and 'ngj&ngj' (for èkèkd&èkèkd) is merely decorative local color." Defend your position with two specific grammatical arguments from the text.

## DIAGNOSTIC_ANSWER_5
Correct: The claim is false. Argument 1: "fiQjdh" (feminine singular perfective participle) and standard "fiQjgjh" differ in aspectual nuance — the dialect form carries completive force tied to the agricultural cycle's finality. Argument 2: "ngj&ngj" (reduplicated adverbial) encodes iterative manner ("slowly, steadily") that standard "hekd&hekd" lacks — the reduplication itself is a grammatical device for durative aspect. A wrong answer accepting the claim reveals the student sees dialect as ornamental, not as a grammatical system with its own aspectual distinctions.

## DIAGNOSTIC_QUESTION_6
Write four lines of a poem in Hindi (Khari Boli or dialect) about a modern urban laborer (delivery driver, construction worker, etc.) that uses: (a) a repeated imperative verb, (b) a dialectal present habitual form, (c) a bahuvrihi compound describing the worker, and (d) a conditional future structure like "gh tc... tb".

## DIAGNOSTIC_ANSWER_6
Expected criteria: (a) Repeated imperative e.g., "chal chal chal" or "kaam kar kar kar"; (b) Dialectal habitual e.g., "bhagat rahat" (Braj) for "bhagta rehta hai"; (c) Bahuvrihi e.g., "petkebhar" (one whose stomach is full — but ironically empty) or "raatbhar" (one of the whole night); (d) Conditional e.g., "gh tc tankhah mile tb ghar jaun". A poor answer using only standard Hindi, missing any element, or treating dialect as slang shows the student cannot productively apply the grammatical tools analyzed in the poems.

## COMMON_MISCONCEPTION
Students treat dialectal forms in the poem as "incorrect Hindi" or "mistakes" rather than as a coherent grammatical system with its own rules (e.g., Braj/Awadhi present habitual "-at/-at hain" vs. Khari Boli "-ta/-te hain"). They write: "The poet uses wrong grammar to show villagers are uneducated." This is factually wrong — the poet is a highly educated journalist who deliberately code-switches. The error stems from equating standard language with correctness and dialect with deficiency, a colonial-era bias still embedded in school grammar teaching.

## ON_FAILURE
Step 1: Have the student list 5 verb forms from the poem that "look wrong" (e.g., pyrs, fiQjdh, ngj&ngj). Step 2: For each, find the standard Khari Boli equivalent using a grammar reference. Step 3: Identify the specific grammatical difference (tense, aspect, gender, number, reduplication). Step 4: Re-read the poem asking: "What does THIS form DO that the standard form cannot?" — e.g., "pyrs pyrs pyrs" enacts walking rhythm; "fiQjdh" carries finality of sunset. Step 5: Rewrite the board answer framing dialect as "deliberate grammatical choice for poetic function".

## BUILDS_ON
Class 11 Hindi Antra grammar nodes where students learned to identify basic parts of speech, tense, and samasa in poetic texts.

## LEADS_TO
Node c12_hin_a_cbse_05_012 (Comprehension: Literal and Inferential Questions) where grammatical analysis becomes evidence for inferential answers about theme and tone.

## PREREQUISITE_NODE_IDS
c11_hin_ar_cbse_01_011, c11_hin_ar_cbse_02_011, c11_hin_ar_cbse_03_011, c11_hin_ar_cbse_04_011, c11_hin_ar_cbse_05_011, c12_hin_a_cbse_05_010, c12_hin_a_cbse_05_001, c12_hin_a_cbse_05_008

## PREREQUISITE_REASONS
c11_hin_ar_cbse_01_011: Class 11 foundation in identifying tense-aspect-mood in poetic texts
c11_hin_ar_cbse_02_011: Class 11 practice with dialectal variations in modern poetry
c11_hin_ar_cbse_03_011: Class 11 exposure to samasa analysis in verse
c11_hin_ar_cbse_04_011: Class 11 work on syntactic deviation for poetic effect
c11_hin_ar_cbse_05_011: Class 11 integration of grammar with theme interpretation
c12_hin_a_cbse_05_010: Vocabulary node provides gloss for dialectal terms used in grammatical analysis
c12_hin_a_cbse_05_001: Grammar usage (colloquial verb forms) is anticipated from the journalist‑poet profile.  
c12_hin_a_cbse_05_008: Grammar node examines how syntactic choices (compound verbs, case markers) shape imagery.  

## FORWARD_NODE_IDS
c12_hin_a_cbse_05_012, c12_hin_a_cbse_05_013, c12_hin_a_cbse_05_014
## FORWARD_REASONS
c12_hin_a_cbse_05_012: Grammatical features become textual evidence for literal/inferential comprehension answers
c12_hin_a_cbse_05_013: Grammar analysis feeds critical interpretation of irony, satire, social critique
c12_hin_a_cbse_05_014: Writing skills require using grammatical terminology precisely in analytical essays

## CROSS_SUBJECT_PREREQS
c11_hin_ar_cbse_01_011, c11_hin_ar_cbse_02_011
## CROSS_SUBJECT_REASONS
c11_hin_ar_cbse_01_011: Establishes baseline grammatical metalanguage (tense, aspect, mood, samasa) used across all Hindi literature analysis
c11_hin_ar_cbse_02_011: Introduces concept of "grammar as style" — how syntactic choices create literary effects, transferable to English literature analysis

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_05_011 -> c12_hin_a_cbse_05_011 -> c12_hin_a_cbse_05_012

## THIS_FORMULA
Poetic Grammar Analysis = (Identify Deviation) + (Name Grammatical Category) + (Explain Systemic Rule in Dialect/Standard) + (Link to Poetic Function: Rhythm/Voice/Theme)

## FORMULA_VARIABLES
- Identify Deviation: Spot forms differing from standard Khari Boli
- Name Grammatical Category: Tense/Aspect/Mood/Voice/Samasa/Syntax
- Explain Systemic Rule: State the dialect's grammatical rule (e.g., Braj present habitual = verb stem + -at)
- Link to Poetic Function: Connect to rhythm, speaker identity, thematic argument

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
linguistic

## CROSS_SUBJECT
N/A | In English poetry analysis (e.g., Dalit poetry in translation, or A.K. Ramanujan), students similarly analyze how non-standard dialect grammar (African American Vernacular English, Scottish dialect, Indian English) constructs speaker identity and political stance — same analytical framework: identify deviation, name category, explain system, link to function
 N/A | Sociology of language: how language variation (dialect vs. standard) reflects power structures — the poem's use of rural grammar enacts resistance to linguistic hegemony, connecting to concepts of cultural capital and linguistic marginalization in NCERT Sociology Chapter 3
## PREREQ_CONCEPT
Student must understand that Hindi has multiple grammatical systems (Khari Boli standard, Braj, Awadhi, etc.) each with internally consistent rules, and that poets consciously choose between them.

## PREREQ_BEFORE
Student should be able to conjugate a verb in present habitual in both Khari Boli (karta hai) and Braj (karat hai) and identify samasa types (tatpurusha, bahuvrihi, dvandva, karmadharaya) in unseen compounds.

## PREREQ_STUCK
If stuck, review Class 11 Hindi Vyakaran Chapter on "Kriya ke Kaal aur Karak" and "Samasa" — specifically the tables comparing Khari Boli and Braj verb paradigms.

## WORKED_EXAMPLE_1
PROBLEM: Analyze the grammatical construction "vkèks vkèks xkus" in the poem "rksM+ks". Identify the verb form, its standard equivalent, the grammatical term for the repetition, and its poetic function in context.

STEPS:
- Step 1: Locate the line in the poem — it appears in the refrain "vkèks vkèks xkus / rksM+ks rksM+ks rksM+ks". The verb is "xkus" (from "xkuk" - to thresh/beat).
- Step 2: Identify the form — "xkus" is the infinitive/verbal noun used here as imperative plural (standard Khari Boli would use "xkosa" or "xkkiye"). The repetition "vkèks vkèks" is reduplication of the adverb "vkèks" (again/once more).
- Step 3: Name the grammatical phenomenon — (a) Infinitive used as imperative (common in older Hindi/Braj), (b) Adverbial reduplication for iterative aspect ("again and again"), (c) Verb phrase repetition for rhythmic enactment.
- Step 4: Explain the dialectal rule — In Braj/Awadhi, the infinitive in "-na/-n" often functions as imperative plural; reduplication of adverbs marks frequentative aspect systematically.
- Step 5: Connect to poetic function — The triple "rksM+ks" + "vkèks vkèks xkus" creates a 5-beat rhythmic unit mimicking the flail's fall: THRESH THRESH THRESH / again again BEAT. The grammar IS the sound of labor.

REASONING: This analysis moves from form to function by treating the grammatical deviation as a system (Braj imperative + reduplication) rather than an error, and links the syntax directly to the poem's central image of threshing.

ANSWER: The construction uses Braj infinitive-as-imperative "xkus" and adverbial reduplication "vkèks vkèks" to create a rhythmic enactment of threshing. The repetition is not mere emphasis — it is grammatical mimesis of agricultural labor.

## WORKED_EXAMPLE_2
PROBLEM: The poem "olar vk;k" uses the compound "uanu&ou" (glossed as "vkuannk;h ou (banz dk m|ku)"). Identify the samasa type, break it into components with their grammatical cases, and explain why this compound is more effective than a paraphrase like "ou tks banz dk m|ku gS".

STEPS:
- Step 1: Identify the compound — "uanu&ou" from the vocabulary gloss.
- Step 2: Break into components — "uanu" (from "uan" = wool/cotton/fiber, here metonymically "cotton") + "ou" (from "ou" = banz/heat). Both are noun stems.
- Step 3: Determine samasa type — The gloss says "vkuannk;h ou (banz dk m|ku)" = "heat that is the MEASURE of cotton". This is KARMADHARAYA (appositional) where the first member qualifies the second: "cotton-measuring heat" or "heat-as-cotton-measure". NOT tatpurusha (which would be "cotton's heat") and NOT bahuvrihi (which would describe a person).
- Step 4: Analyze case relationship — "uanu" is in instrumental sense (by means of cotton) or locative (in cotton), "ou" is the head noun. The compound fuses the instrument of measurement with the quality measured.
- Step 5: Compare with paraphrase — "ou tks banz dk m|ku gS" uses a relative clause (3 words + verb). The compound "uanu&ou" compresses this into a single prosodic unit (4 matras) that fits the poem's tight meter and carries the conceptual fusion: in the farmer's world, heat IS the measure of cotton — they are inseparable.

REASONING: Samasa analysis reveals how compounds in poetry are not just shortened phrases but conceptual fusions. The karmadharaya here embodies the poem's theme: nature's parameters (heat) become the farmer's economic reality (cotton measure).

ANSWER: Karmadharaya samasa — "uanu" (cotton, instrumental/locative) + "ou" (heat, head). The compound fuses the measuring instrument with the measured quality, embodying the poem's theme that natural forces directly determine agricultural value. More effective than paraphrase due to metrical compression and conceptual fusion.

## WORKED_EXAMPLE_3
PROBLEM: Compare the grammatical representation of TIME in the two poems. "olar vk;k" uses "veqd fnu veqd ckj" (many days, many times) and "ux.;" (sudden/unscheduled), while "rksM+ks" uses the conditional future "gksxk gh tc... ikslsxh". Analyze how these temporal grammars construct different relationships between labor and reward.

STEPS:
- Step 1: Extract temporal markers from "olar vk;k" — "veqd fnu" (quantified duration, accusative of extent), "veqd ckj" (quantified frequency), "ux.;" (adverbial, "sudden/unexpected", from "uxar" = remainder/unscheduled). All are PAST/HABITUAL time — looking back at a cycle already completed.
- Step 2: Extract temporal markers from "rksM+ks" — "gksxk" (future indicative), "ikslsxh" (future conditional/subjunctive), "gh tc" (conditional particle + time). This is FUTURE-ORIENTED CONDITIONAL time — reward DEPENDS on a future action.
- Step 3: Identify grammatical contrast — Poem 1: Perfective/Habitual aspect (completed cycles). Poem 2: Future + Conditional modality (contingent outcome).
- Step 4: Link to labor-reward relationship — Poem 1: The farmer's past labor ("veqd fnu... iapeh i<+rs jgus") earned only "izek.k" (sign/omen) of poems, not material reward. Time is a record of exploitation. Poem 2: The poem DEMANDS a new temporal contract — "gh tc og ikslsxh cht dks / ge bldks D;k dj Mkysa" — reward becomes conditional on just sharing of labor.
- Step 5: Synthesize — The shift from past habitual to future conditional grammar enacts the poem's political move: from documenting injustice to demanding justice. Grammar performs the argument.

REASONING: This comparison shows how tense-aspect-modality systems are not neutral — they encode ideological positions on time, labor, and justice. The analysis requires integrating grammatical categories across two texts.

ANSWER: "olar vk;k" uses past habitual/perfective time grammar (veqd fnu, ux.;) to frame labor as completed exploitation. "rksM+ks" uses future conditional grammar (gksxk gh tc... ikslsxh) to frame reward as contingent on just action. The grammatical shift from indicative past to conditional future enacts the poem's move from testimony to demand.

## COMPETENCY_QUESTION_1
QUESTION: A Class 12 student writes in the board exam: "The poet uses wrong grammar like 'pyrs' and 'fiQjdh' to show the farmer is illiterate." Using your knowledge of dialect grammar and poetic function, write a 100-word correction of this answer that would score full marks. Your correction must: (a) name the dialect, (b) state the grammatical rule for the form, (c) explain the poetic function, (d) use the term "code-switching" or "stylistic variation".

COMPETENCY: Critical evaluation of peer response using grammatical metalanguage

STEPS:
- Step 1: Identify the error — the student confuses dialect with error, and confuses speaker identity (farmer) with poet's craft.
- Step 2: Name the dialect — Braj/Bhasha region (Western Uttar Pradesh/Haryana border where Yamuna Nagar lies).
- Step 3: State rule for "pyrs" — Braj present habitual 3rd person singular = verb stem + -s (cf. Khari Boli -ta hai).
- Step 4: State rule for "fiQjdh" — Braj perfective participle feminine singular = verb stem + -i + -dh (cf. Khari Boli -i + -i).
- Step 5: Explain function — Code-switching to rural voice creates authenticity, enacts rhythm of labor, resists linguistic hegemony.
- Step 6: Draft correction within word limit.

ANSWER: The student's claim reflects a misunderstanding of poetic code-switching. The forms "pyrs" (Braj present habitual: stem+-s) and "fiQjdh" (Braj perfective feminine: stem+-i+dh) follow systematic dialect rules, not errors. The poet — a journalist with an MA in English — deliberately employs stylistic variation to construct an authentic rural speaker. This grammatical choice enacts the rhythm of walking ("pyrs pyrs pyrs") and the finality of sunset ("fiQjdh"), making the farmer's lived experience audible. Treating dialect as deficiency confuses linguistic prejudice with literary analysis.

DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: The poem "rksM+ks" ends with the lines: "xksM+ks xksM+ks xksM+ks / iz'u&vH;kl". The verb "xksM+ks" (from "xksMk" - to break/crush) is repeated thrice as an imperative. Design a 3-question "iz'u&vH;kl" (exercise) that a teacher could give to test whether students understand: (1) the grammatical form, (2) the rhythmic function, (3) the thematic significance. For each question, provide the expected answer in 1-2 sentences.

COMPETENCY: Pedagogical content knowledge — designing assessment for grammatical analysis

STEPS:
- Step 1: Design Question 1 (grammatical form) — focus on identifying the verb form and its dialectal imperative use.
- Step 2: Design Question 2 (rhythmic function) — focus on how repetition maps to physical action.
- Step 3: Design Question 3 (thematic significance) — focus on the shift from "rksM+ks" (thresh grain) to "xksM+ks" (break/crush) — what is being crushed?
- Step 4: Write expected answers showing depth appropriate for Class 12 board.
- Step 5: Ensure questions progress from identification to analysis to synthesis.

ANSWER: 
Q1: "xksM+ks" is the imperative plural of which verb root? In which dialect region is the bare stem used as imperative? 
A1: Root "xksMk" (to break/crush). In Braj/Bhasha, the bare stem functions as imperative plural (vs. Khari Boli "xksM+osa").

Q2: The poem opens with "rksM+ks rksM+ks rksM+ks" (thresh) and closes with "xksM+ks xksM+ks xksM+ks" (crush). How does the verb repetition in both refrains create rhythmic mimesis? 
A2: Each triplet enacts one cycle of the flail — the grammar's repetition IS the labor's rhythm, making the reader's mouth mimic the worker's arm.

Q3: What shifts from "threshing grain" to "crushing" in the final refrain? What does the farmer now demand to crush? 
A3: The object shifts from grain to injustice — "xksM+ks" now means "crush the exploitative structure." The imperative becomes revolutionary command.

DIFFICULTY: hard