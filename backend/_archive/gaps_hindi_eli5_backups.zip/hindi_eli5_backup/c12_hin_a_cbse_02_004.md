## DEFINITION
Character analysis of the protagonist involves examining the central character's personality traits, motivations, internal conflicts, development arc, and relationship to the poem's central theme through their actions, speech, thoughts, and the poet's descriptive language.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student can write a structured 150-word character sketch of लज्जा (the protagonist) using the PEEL method (Point, Evidence, Explanation, Link) with at least three distinct textual references from the poem, showing her transformation from shyness to assertiveness and connecting it to the theme of women's empowerment.

## SCOPE_BOUNDARY
This node covers ONLY the protagonist (लज्जा) of the poem "लज्जा" by फजल in Class 12 Antra Chapter 2. It does NOT cover supporting characters (node 005), themes (nodes 006-007), or literary devices (nodes 008-009) — though it references them as needed for character analysis.

## WALKTHROUGH
Imagine you're describing your best friend to someone who's never met them — you'd mention their habits, how they react in crises, and how they've changed over time. That's exactly what we do for लज्जा. Start by reading the poem aloud twice: first for the story, second marking every line that reveals her personality (adjectives, verbs, metaphors). Notice the shift from "लज्जा" (shyness) as her name/identity to "निर्भय" (fearless) in the final stanza. That contrast is your thesis. Now organize evidence chronologically: early stanzas (shyness), middle (catalyst for change), climax (transformation). Each claim needs a line reference — "In stanza 2, 'सकुचाई-सी' shows..." — not vague generalizations. The key insight: लज्जा isn't just a girl; she symbolizes every woman shedding imposed timidity.

## DIAGNOSTIC_QUESTION_1
What is the literal meaning of the protagonist's name "लज्जा" and how does the poet use it ironically in the opening stanza?

## DIAGNOSTIC_ANSWER_1
"लज्जा" literally means "shame" or "modesty/shyness". The poet uses it ironically because the name defines her initial state (stanza 1: "लज्जा-सी सकुचाई") but the entire poem traces her journey of shedding that very quality. A wrong answer (e.g., "her name means beauty") reveals the student hasn't connected the name to the central character arc — they're treating it as a label, not a thematic device.

## DIAGNOSTIC_QUESTION_2
Explain in your own words why the mother's advice "वक़्त बदल डालो" (change the times) acts as the turning point for लज्जा's character development.

## DIAGNOSTIC_ANSWER_2
The mother reframes लज्जा's shyness not as an innate virtue but as a condition imposed by outdated times ("पुराने ज़माने की लाज"), giving her agency to reject it. This shifts लज्जा from passive acceptance to active rebellion. A wrong answer focusing only on "mother loves daughter" misses the sociopolitical dimension — the mother represents intergenerational feminist consciousness, not just affection.

## DIAGNOSTIC_QUESTION_3
Apply the "show, don't tell" principle: Find two lines where the poet *shows* लज्जा's new fearlessness through concrete actions rather than abstract adjectives, and explain the effect.

## DIAGNOSTIC_ANSWER_3
1. "सिर उठाकर चलने लगी" (literal action: walking with head high) replaces abstract "निर्भय हुई". 2. "आँख मिलाकर बात करती" (direct eye contact) demonstrates confidence behaviorally. Effect: Readers witness transformation viscerally. A wrong answer quoting "वीरांगना बन गई" (abstract label) shows the student confuses telling with showing — a critical error in board answer writing.

## DIAGNOSTIC_QUESTION_4
Analyze how the metaphor "पुराने ज़माने की लाज / उतार फेंकी जैसे पुराना वस्त्र" (discarded old shame like old clothing) reveals both the ease and the deliberateness of लज्जा's transformation.

## DIAGNOSTIC_ANSWER_4
The clothing metaphor implies: (a) shame was external/imposed, not intrinsic skin; (b) removal is a conscious choice ("उतार फेंकी" — active verb); (c) it's a public act (clothing is visible). The simile "जैसे पुराना वस्त्र" suggests familiarity and lack of regret. A wrong answer calling it "just a comparison" misses how metaphor encodes agency — crucial for JEE/NEET-style inference questions.

## DIAGNOSTIC_QUESTION_5
Evaluate the claim: "लज्जा's transformation is complete and unambiguous by the poem's end." Defend or critique using textual evidence.

## DIAGNOSTIC_ANSWER_5
Critique: The final stanza's "नई लज्जा" (new shame/modesty) complicates a binary reading. She hasn't discarded *all* modesty — she's redefined it on her terms ("अपनी शर्तों पर"). The word "नई" implies continuity with transformation, not total rupture. A wrong answer saying "yes, she's fully bold" ignores nuance — board exams reward "balanced evaluation" (CBSE marking scheme: 2 marks for nuance).

## DIAGNOSTIC_QUESTION_6
Create a 4-line stanza in Hindi (any meter) from लज्जा's perspective *ten years later*, showing how she now teaches her own daughter about "लज्जा".

## DIAGNOSTIC_ANSWER_6
Example: "बेटी, लज्जा अब बोझ नहीं, ढाल है मेरी / आँख मिलाकर सच बोलना, यही नई चाल है मेरी / पुरानी लाज उतार दी, नई लज्जा पहन ली / अपनी शर्तों पर जीना, यही मिसाल है मेरी।" Criteria: Must show evolved definition of लज्जा, intergenerational link, and agency. A poor answer repeating the original poem's imagery shows inability to extrapolate character growth — a creative thinking gap.

## COMMON_MISCONCEPTION
Students treat लज्जा as a static symbol of "Indian womanhood" rather than a dynamic character with specific textual turning points. They write: "लज्जा भारतीय नारी का प्रतीक है" (generic) instead of: "Stanza 3 shows लज्जा's internal conflict when she hears 'वक़्त बदल डालो' — her pause ('क्षण भर रुकी') proves the change isn't automatic." The error stems from memorizing thematic summaries instead of analyzing character mechanics. Board exams deduct marks for "vague symbolism without textual anchoring".

## ON_FAILURE
1. Re-read the poem *only* for लज्जा's verbs (highlight every action verb: सकुचाई, सुनी, उठी, चली, मिलाती). 2. Create a 3-column table: Stanza | Verb/Action | What it reveals. 3. Rewrite one PEEL paragraph using *only* verb evidence. 4. Re-attempt Diagnostic Question 3. If still stuck, revisit c11_hin_ar_cbse_01_004 (Class 11 Character Analysis: Protagonist) for the PEEL framework.

## BUILDS_ON
Class 11 skill of writing PEEL-structured character sketches (c11_hin_ar_cbse_01_004) — now applied to a poetic protagonist with symbolic name and transformative arc.

## LEADS_TO
Character Analysis: Supporting Characters (c12_hin_a_cbse_02_005) — the mother's role as catalyst requires the protagonist analysis first.

## PREREQUISITE_NODE_IDS
c12_hin_a_cbse_02_001, c12_hin_a_cbse_02_002, c12_hin_a_cbse_02_003, c11_hin_ar_cbse_01_004

## PREREQUISITE_REASONS
c12_hin_a_cbse_02_001: Context (poet's feminist lens) frames why लज्जा's name is ironic.
c12_hin_a_cbse_02_002: Narrative structure (stanza progression) maps लज्जा's character arc.
c12_hin_a_cbse_02_003: Setting (traditional household) establishes constraints लज्जा breaks.
c11_hin_ar_cbse_01_004: Provides the PEEL answer-writing framework essential for board answers.

## FORWARD_NODE_IDS
c12_hin_a_cbse_02_005, c12_hin_a_cbse_02_006, c12_hin_a_cbse_02_013, c12_hin_a_cbse_02_007, c12_hin_a_cbse_02_008, c12_hin_a_cbse_02_012

## FORWARD_REASONS
c12_hin_a_cbse_02_005: Mother's character (supporting) is defined by her impact on लज्जा.
c12_hin_a_cbse_02_006: Primary theme (women's empowerment) is embodied in लज्जा's journey.
c12_hin_a_cbse_02_013: Critical interpretation of the poem's feminist reading requires protagonist analysis as foundation.
c12_hin_a_cbse_02_007: Protagonist (father) analysis reveals how secondary themes reflect/refract through his consciousness.  
c12_hin_a_cbse_02_008: Protagonist (child) is the *tenor* of most metaphors.  
c12_hin_a_cbse_02_012: Protagonist analysis (father) gives character motivation evidence.  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
No cross-subject prerequisites from Class 11 nodes provided.

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_01_004 -> c12_hin_a_cbse_02_004 -> c12_hin_a_cbse_02_005

## THIS_FORMULA
PEEL Character Analysis Framework: Point (trait/change) → Evidence (line/stanza ref) → Explanation (how evidence proves point) → Link (connect to theme/arc)

## FORMULA_VARIABLES
Point = Specific character claim (e.g., "लज्जा shifts from passive to active"); Evidence = Exact textual reference (stanza/line); Explanation = Literary reasoning; Link = Connection to central theme (empowerment)

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
analytical

## CROSS_SUBJECT
c12_hist_cbse_03_004 | लज्जा's rejection of "पुराने ज़माने की लाज" mirrors historical analysis of 19th-century social reform movements (e.g., widow remarriage debates) where women negotiated tradition vs. modernity.
 c12_soc_cbse_02_007 | The mother-daughter dialogue illustrates "intergenerational transmission of gender ideology" — a core concept in sociology of family and social change.
## PREREQ_CONCEPT
PEEL paragraph structure for literary analysis (learned in Class 11).

## PREREQ_BEFORE
Student must be able to locate specific stanzas/lines in the poem and distinguish between "telling" (adjectives) and "showing" (verbs/actions).

## PREREQ_STUCK
If unable to write evidence-based claims, review "Show vs. Tell in Character Analysis" from c11_hin_ar_cbse_01_004 Worked Example 2.

## WORKED_EXAMPLE_1
PROBLEM: Write a PEEL paragraph analyzing how लज्जा's relationship with her name changes from stanza 1 to the final stanza.
STEPS:
- Step 1: Identify the Point — लज्जा's name transforms from a definition of her identity to a label she redefines.
- Step 2: Gather Evidence — Stanza 1: "लज्जा-सी सकुचाई" (simile equating her with shyness); Final stanza: "नई लज्जा" (possessive adjective showing ownership).
- Step 3: Explain — In stanza 1, the hyphenated "लज्जा-सी" makes shyness her essence; in the end, "नई लज्जा" makes it a chosen attribute ("मेरी लज्जा" implied).
- Step 4: Link — This linguistic shift mirrors the poem's core argument: women must reclaim language used to confine them.
- Step 5: Verify — Does every claim have a line reference? Yes. Does it connect to theme? Yes.
REASONING: The PEEL structure forces textual anchoring (board requirement) while the "Link" step ensures thematic depth (competitive exam requirement). Tracking a single word ("लज्जा") across the poem demonstrates close reading.
ANSWER: लज्जा's name undergoes semantic reclamation: initially "लज्जा-सी सकुचाई" (stanza 1) uses a simile to fuse her identity with imposed modesty, but the final stanza's "नई लज्जा" employs a possessive construction that marks agency — she now defines what लज्जा means. This mirrors the poem's feminist thesis that liberation isn't discarding tradition but rewriting it on one's terms.

## WORKED_EXAMPLE_2
PROBLEM: Using only verbs/actions (no adjectives), trace लज्जा's agency progression across three key stanzas.
STEPS:
- Step 1: Define "agency verbs" — actions where the subject initiates change (not passive reception).
- Step 2: Scan poem for लज्जा as grammatical subject of active verbs.
- Step 3: Select three stanzas: Stanza 2 (सुनी — passive hearing), Stanza 4 (उठी, चली — active movement), Stanza 5 (मिलाती, बोलती — active communication).
- Step 4: Analyze progression: सुनना (receiving) → उठना/चलना (physical assertion) → मिलाना/बोलना (social assertion).
- Step 5: Synthesize — Agency expands from internal (listening) to bodily (walking) to relational (speaking).
REASONING: Verbs are the most objective evidence of character change. Boards reward "textual evidence"; JEE/NEET rewards "pattern recognition". This method satisfies both.
ANSWER: Stanza 2: "सुनी" (passive reception of mother's words). Stanza 4: "उठी", "चली" (bodily assertion — she initiates movement). Stanza 5: "मिलाती", "बोलती" (relational agency — she controls eye contact and speech). The verb trajectory maps लज्जा's expanding locus of control.

## WORKED_EXAMPLE_3
PROBLEM: Compare लज्जा's transformation with the protagonist of the Class 11 poem "पथिक" (from Antra) — both shed old identities. Write a comparative PEEL paragraph.
STEPS:
- Step 1: Recall "पथिक" protagonist — sheds "पुराना बोझ" (old burden) to walk freely.
- Step 2: Identify similarity — both use clothing/burden metaphors for shedding the past.
- Step 3: Identify difference — "पथिक" is solitary/individualistic; लज्जा's change is catalyzed by mother (intergenerational).
- Step 4: Draft Point — Both protagonists reject imposed pasts, but लज्जा's agency is collectively nurtured.
- Step 5: Evidence — लज्जा: "वक़्त बदल डालो" (mother's voice); पथिक: "अकेले ही चलना पड़ा" (solitude).
- Step 6: Explanation — लज्जा inherits feminist consciousness; पथिक discovers self-reliance alone.
- Step 7: Link — Shows two models of empowerment in Hindi poetry: collective vs. individual.
REASONING: Cross-text comparison is a Class 12 board competency (case-based questions) and builds intertextual awareness for CUET/IPMAT.
ANSWER: While both लज्जा ("पुराने ज़माने की लाज / उतार फेंकी जैसे पुराना वस्त्र") and पथिक's protagonist ("पुराना बोझ उतार फेंका") use shedding metaphors, लज्जा's transformation is dialogic — triggered by "माँ ने कहा, वक़्त बदल डालो" — whereas पथिक's is solitary ("अकेले ही चलना पड़ा"). This contrast reveals a generational shift in Hindi poetry: from individualistic liberation (Class 11) to intergenerational feminist solidarity (Class 12).

## COMPETENCY_QUESTION_1
QUESTION: A Class 12 student writes: "लज्जा पहले शर्मीली थी, फिर बहादुर बन गई।" Why is this answer insufficient for a 3-mark board question? Rewrite it to meet CBSE marking criteria.
COMPETENCY: Critical evaluation of answer quality (metacognition)
STEPS:
- Step 1: Identify missing elements — no textual evidence, no analysis of *how* change occurs, no thematic link.
- Step 2: Apply CBSE marking scheme — 1 mark for trait identification, 1 for evidence, 1 for explanation.
- Step 3: Rewrite using PEEL with stanza references.
- Step 4: Verify all three marks are addressed.
ANSWER: The original answer scores 1/3 (only trait identification). Improved version: "लज्जा's journey from passive modesty to active confidence is traced through verb progression: stanza 1's 'सकुचाई' (intransitive, reflexive) becomes stanza 5's 'मिलाती/बोलती' (transitive, agentive). The catalyst is maternal intervention ('वक़्त बदल डालो', stanza 3), framing empowerment as intergenerational. Thus, लज्जा embodies the poem's thesis that tradition must be rewritten, not discarded." This earns full marks: trait + evidence + thematic link.
DIFFICULTY: easy

## COMPETENCY_QUESTION_2
QUESTION: The poem ends with "नई लज्जा". Some critics argue this retains patriarchal framing (modesty as female virtue). Defend or refute using the poem's internal logic and the mother's role.
COMPETENCY: Argumentative writing with textual evidence (higher-order thinking)
STEPS:
- Step 1: Acknowledge the critique's validity — "लज्जा" remains the central term.
- Step 2: Refute using redefinition evidence — "नई" modifier + possessive implication + mother's redefinition ("पुराने ज़माने की लाज" vs. new).
- Step 3: Analyze mother's role — she doesn't reject लज्जा; she historicizes it ("पुराने ज़माने की"), making it contingent, not essential.
- Step 4: Connect to feminist theory (optional but impressive) — strategic essentialism / reclaiming terminology.
- Step 5: Conclude — The poem enacts linguistic reclamation, not retention.
ANSWER: Refutation: The critique ignores the poem's central operation — semantic reclamation. "नई लज्जा" is not the old virtue recycled; it's a conscious redefinition evidenced by: (1) The adjective "नई" marks rupture; (2) The mother explicitly historicizes the old meaning ("पुराने ज़माने की लाज"), proving it's socially constructed, not biological; (3) लज्जा's final actions ("आँख मिलाकर बात करती") contradict traditional modesty (downcast eyes). The poem doesn't retain patriarchal framing — it hijacks the term to mean "self-respect on one's own terms". This distinction is the poem's political core.
DIFFICULTY: hard