## DEFINITION
Secondary themes are the underlying ideas, social concerns, and philosophical dimensions that run parallel to the primary theme of devotion in a literary work, enriching the text by revealing the protagonist's struggle against societal norms, gender constraints, and institutional religion while pursuing spiritual truth.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student must be able to identify at least three distinct secondary themes in Meera Bai's poetry, trace each theme across specific stanzas with textual evidence, and explain how these themes intersect with the primary theme of Krishna-bhakti to create a layered critique of 16th-century Rajput society.

## SCOPE_BOUNDARY
This node covers the identification and analysis of secondary themes in Meera Bai's prescribed poem (stanza 1) and the biographical context from the textbook introduction. It does NOT cover detailed poetic devices (imagery, metaphor, irony, symbolism) which are addressed in nodes 008-009, nor does it cover primary theme analysis (node 006) or comprehension questions (node 012).

## WALKTHROUGH
Imagine you're listening to a bhajan at a temple and suddenly realize the singer isn't just praising God — she's also quietly questioning why women can't choose their own spiritual path, why caste determines who can worship, and why society fears a woman who thinks for herself. That's exactly what Meera Bai does. To begin analyzing secondary themes, first re-read the biographical note on pages 113-114 and note every instance where Meera defies a social rule — leaving the palace, ignoring purdah, mixing with lower castes, refusing sati. Then read the poem stanza and underline words that carry double meaning: "fxjèkj" (worldly husband vs Krishna), "ifr" (worldly co-wife vs Maya), "cqèk" (social norms vs spiritual truth). The key insight is that every act of devotion in Meera's poetry is simultaneously an act of rebellion against patriarchal, casteist, and ritualistic structures.

## DIAGNOSTIC_QUESTION_1
What is the definition of a secondary theme in literature, and how does it differ from the primary theme?

## DIAGNOSTIC_ANSWER_1
A secondary theme is a subsidiary idea that runs parallel to the primary theme, adding depth and complexity without being the central message. The primary theme is the main controlling idea (here, Krishna-bhakti), while secondary themes are the social, psychological, or philosophical undercurrents (gender defiance, caste critique, spiritual autonomy). A wrong answer that equates secondary themes with "minor topics" or "subplots" reveals the student confuses thematic hierarchy with narrative structure — themes are ideas, not plot events.

## DIAGNOSTIC_QUESTION_2
In the biographical note (page 113), the text states Meera "ges'kk fojksèk fd;k" (broke social customs) regarding intercaste dining and purdah. Explain in your own words how this biographical fact functions as a secondary theme in her poetry.

## DIAGNOSTIC_ANSWER_2
Meera's real-life defiance of caste and gender norms becomes a secondary theme because her poems encode this rebellion metaphorically — when she rejects "fxjèkj" (the mortal husband/king) for Krishna, she simultaneously rejects the patriarchal authority that arranged her marriage and the Rajput code that demanded purdah and sati. The biographical fact isn't just context; it's the lived reality that the poetry transforms into spiritual critique. A wrong answer that treats the biography as mere "background information" misses how the text uses personal history as thematic evidence — the life and the verse are inseparable in bhakti poetry.

## DIAGNOSTIC_QUESTION_3
Apply the concept of secondary themes to the first stanza of the poem. Identify two words/phrases that carry a secondary theme of gendered power dynamics, and explain the dual meaning of each.

## DIAGNOSTIC_ANSWER_3
Step 1: Identify "fxjèkj" (line 1) — literal: the king/husband Bhojraj; metaphorical: patriarchal authority that claims ownership over a woman's life. Step 2: Identify "ifr" (line 2) — literal: co-wives in the palace; metaphorical: worldly attachments (Maya) and rival claimants to a woman's loyalty imposed by polygynous custom. Step 3: Explain how addressing Krishna as "yky fxjèkj" (my king/husband) in the last line subverts the marital hierarchy by replacing the human husband with the Divine, asserting the woman's right to choose her lord. A wrong answer that only gives literal meanings misses the subversive double-coding essential to bhakti poetry's social critique.

## DIAGNOSTIC_QUESTION_4
Analyze how the secondary theme of caste transcendence operates in both the biographical note and the poem's imagery. Compare the explicit biographical statement with the implicit poetic strategy.

## DIAGNOSTIC_ANSWER_4
The biography explicitly states Meera practiced "lkoZtfud :i ls ukpus&xkus" (intercaste dining) and faced opposition from "lRlax" (orthodox) elements. The poem implicitly encodes this through "yksd&ykt [kks;h" (folk/simple language) and "valqou ty lhafp&lhafp" (tears flowing like a river) — the vernacular language itself rejects Sanskritized priestly register, and the uncontrolled weeping defies the Brahminical ideal of stoic, ritualized devotion. The secondary theme operates explicitly in prose (biography) and implicitly in verse (poem), creating a unified critique across genres. A wrong answer that treats the biography and poem as separate texts fails to see how the secondary theme bridges the paratext and the main text.

## DIAGNOSTIC_QUESTION_5
Evaluate the claim: "Meera Bai's secondary themes of social reform are merely incidental to her primary theme of devotion; the poetry would remain unchanged without them." Defend or refute with evidence.

## DIAGNOSTIC_ANSWER_5
Refute. The secondary themes are structurally constitutive — remove the gender defiance, and "fxjèkj xksiky" loses its subversive reclaiming of agency; remove the caste critique, and "yksd&ykt [kks;h" becomes mere stylistic simplicity rather than political choice; remove the ritual-rejection, and "cqèk efFk ?k`r dkf<+ fy;ks" (breaking the hard shell of convention) loses its specific referent. The primary theme of nirguna/saguna bhakti in Meera's case is inextricably social because her Krishna is accessible precisely *because* he transcends caste/gender. A wrong answer that agrees reveals a fundamental misunderstanding of nirguna bhakti as inherently anti-hierarchical — the social and spiritual are one continuum in the bhakti tradition.

## DIAGNOSTIC_QUESTION_6
Create a four-line stanza in Hindi (or English) that expresses a secondary theme of spiritual autonomy in the voice of a young person today resisting family pressure about career/marriage choices, using the same double-coding strategy Meera employs.

## DIAGNOSTIC_ANSWER_6
Example: "mausam kehta hai doctor ban ja / lekin dil ke mandir mein artist basta hai / samaj ki deewarein utha loon main / apne Khuda ka rasta khud chunta hoon" — This mirrors Meera's strategy: "mausam/samaj" = "fxjèkj/ifr" (external authority), "dil ke mandir/khuda" = "fxjèkj xksiky" (internal divine authority), "rasta khud chunta hoon" = "cqèk efFk ?k`r dkf<+ fy;ks" (breaking convention). A poor answer that writes a direct complaint without metaphorical double-coding misses the essential bhakti technique of encoding resistance in devotional language.

## COMMON_MISCONCEPTION
Students often believe secondary themes are "less important" than the primary theme and can be listed as separate bullet points (e.g., "Theme 1: Bhakti. Theme 2: Women's rights. Theme 3: Caste."). This is wrong because in bhakti poetry, the secondary themes ARE the primary theme's flesh and blood — Meera's devotion *is* her rebellion. The social critique isn't added on; it's the very form her bhakti takes. Students make this error because school textbooks often teach themes as a checklist rather than as an integrated meaning-system, and because the biographical note (prose) and poem (verse) are presented as separate sections, obscuring their thematic unity.

## ON_FAILURE
If the student cannot integrate secondary themes with the primary theme: Step 1 — Have them re-read the biographical note and poem side-by-side, drawing arrows connecting each biographical fact (e.g., "refused sati") to a specific poetic phrase (e.g., "cqèk efFk ?k`r dkf<+ fy;ks"). Step 2 — Ask: "If Meera had obeyed every social rule, would her Krishna-bhakti be the same?" Guide them to see that her bhakti *requires* the transgression. Step 3 — Give a mini-writing task: "Rewrite the first stanza as if Meera were a compliant Rajput princess. What disappears?" The comparison will reveal that the secondary themes are the poem's engine, not its decoration.

## BUILDS_ON
Builds on the primary theme analysis (node 006) by extending the devotional framework into its social, gendered, and institutional dimensions.

## LEADS_TO
Enables literary devices analysis (nodes 008-009) by providing the thematic content that imagery, irony, and symbolism encode, and enables critical thinking (node 013) by establishing the interpretive lens for deeper analysis.

## PREREQUISITE_NODE_IDS
c11_hin_ar_cbse_10_001, c11_hin_ar_cbse_10_002, c11_hin_ar_cbse_10_003, c11_hin_ar_cbse_10_004, c11_hin_ar_cbse_10_005, c11_hin_ar_cbse_10_006
## PREREQUISITE_REASONS
c11_hin_ar_cbse_10_001: Provides historical context (bhakti movement, Rajput society) essential for recognizing social critique.
c11_hin_ar_cbse_10_002: Narrative structure shows how Meera's life events map onto poetic persona.
c11_hin_ar_cbse_10_003: Setting (palace vs temple vs wilderness) encodes the secondary theme of spatial/social transgression.
c11_hin_ar_cbse_10_004: Protagonist analysis establishes Meera's agency as the driver of thematic complexity.
c11_hin_ar_cbse_10_005: Supporting characters (husband, in-laws, priests) embody the social forces she resists.
c11_hin_ar_cbse_10_006: Primary theme (Krishna-bhakti) is the anchor; secondary themes only make sense in relation to it.

## FORWARD_NODE_IDS
c11_hin_ar_cbse_10_008, c11_hin_ar_cbse_10_009, c11_hin_ar_cbse_10_013, c11_hin_ar_cbse_10_014, c11_hin_ar_cbse_10_015, c12_hin_a_cbse_01_007, c12_hin_a_cbse_08_007, c12_hin_a_cbse_10_007, c12_hin_ar_cbse_04_007, c12_hin_ar_cbse_10_007

## FORWARD_REASONS
c11_hin_ar_cbse_10_008: Imagery and metaphor are the vehicles for secondary themes (e.g., "valqou ty" = tears as river of rebellion).
c11_hin_ar_cbse_10_009: Irony and symbolism operate at the intersection of primary and secondary themes (e.g., "fxjèkj" as ironic honorific).
c11_hin_ar_cbse_10_013: Critical thinking requires thematic depth to support interpretive claims.
c11_hin_ar_cbse_10_014: Writing skills need thematic substance for analytical essays and creative responses.
c11_hin_ar_cbse_10_015: Secondary themes (labor, knowledge vs. ritual, body/spirit) provide subsidiary discussion threads.  
c12_hin_a_cbse_01_007: Chapter 10 used symbolism to reveal secondary themes.  
c12_hin_a_cbse_08_007: अगला तार्किक चरण: Secondary themes are the underlying, complementary ideas in a literary work that support, contrast w... इस नोड की अवधारणाओं को सीधे उपयोग/विस्तारित करता है।  
c12_hin_a_cbse_10_007: Reinforces peer-collective as literary formation site.  
c12_hin_ar_cbse_04_007: Class 11 Chapter 10 secondary themes — advanced practice with satirical texts similar to this chapter's tone.  
c12_hin_ar_cbse_10_007: अगला तार्किक चरण: Secondary themes are the underlying ideas, motifs, and concerns that run parallel to the primary the... इस नोड की अवधारणाओं को सीधे उपयोग/विस्तारित करता है।  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
No prior class nodes available for cross-subject connections.

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_10_006 -> c11_hin_ar_cbse_10_007 -> c11_hin_ar_cbse_10_008

## THIS_FORMULA
N/A - conceptual

## FORMULA_VARIABLES
N/A

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
conceptual

## CROSS_SUBJECT
c11_history_bhakti_movement | The bhakti movement's challenge to Brahminical authority and caste hierarchy is the historical backdrop for Meera's secondary themes of social reform.
c11_sociology_gender_caste | Sociological concepts of patriarchal control (purdah, sati, co-wife rivalry) and caste endogamy explain the specific social structures Meera's poetry resists.
c11_political_science_rights_dissent | The concept of spiritual autonomy as political dissent connects Meera's 16th-century resistance to modern frameworks of individual rights vs state/religious authority.

## PREREQ_CONCEPT
The student must understand the primary theme of nirguna/saguna Krishna-bhakti as developed in node 006, particularly the concept of personal divine relationship bypassing priestly mediation.

## PREREQ_BEFORE
The student must have completed the character analysis of Meera (node 004) and the primary theme analysis (node 006) to recognize how her persona and central devotion create the foundation for secondary themes.

## PREREQ_STUCK
If stuck, review the primary theme of "prem-bhakti as total surrender to Krishna" (node 006) and Meera's character trait of "fearless defiance" (node 004) — these two together generate all secondary themes.

## WORKED_EXAMPLE_1
PROBLEM: Analyze how the secondary theme of "renunciation of royal privilege" operates in the first stanza of Meera's poem. Provide textual evidence and explain its connection to the primary theme.

STEPS:
- Step 1: Identify the biographical basis — the intro states Meera left the palace ("okil esM+rk vk xb±") and lived as an ascetic ("}kjdk pyh xb±").
- Step 2: Locate the poetic markers — "fxjèkj xksiky" (king of the fortress/palace) is addressed but then displaced by "yky fxjèkj" (MY king, Krishna) in the final line, signaling transfer of allegiance from royal to divine.
- Step 3: Analyze "nwljks u dksbZ" (no one else / nothing else) — the negation of worldly attachments includes royal status, wealth, and palace life.
- Step 4: Examine "yksd&ykt [kks;h" (folk/simple singing) — the deliberate choice of vernacular over courtly Sanskritized register enacts renunciation of elite cultural capital.
- Step 5: Connect to primary theme — this renunciation isn't ascetic withdrawal but *engaged* devotion; she sings publicly ("yksd"), dances ("lhafp&lhafp"), making her bhakti visible and communal, not private ritual.

REASONING: The secondary theme of renunciation is not rejection of the world but reorientation of loyalty — every royal signifier (king, fortress, court language) is hollowed out and refilled with devotional meaning. This mirrors the bhakti doctrine that the world is real but its hierarchies are false.

ANSWER: The stanza encodes renunciation through lexical substitution (human king → divine king), register shift (courtly → folk), and performative mode (private ritual → public song-dance). This secondary theme deepens the primary theme by showing that Meera's bhakti requires dismantling the very identity (princess) that society imposed on her.

## WORKED_EXAMPLE_2
PROBLEM: Trace the secondary theme of "female spiritual authority vs male institutional control" across the biographical note and the poem. Show how the text constructs this tension.

STEPS:
- Step 1: From biography — "n`<+fu'p;h Fkha" (independent woman), "fo'okl fd;k] ml ij vey fd;k" (worshipped and endured persecution), "lRlax" (orthodox) opposition — establishes the gendered power struggle.
- Step 2: From biography — "jkt?kjkus esa vusd d'V mBkus" (many attacks in royal courts) — shows institutional (patriarchal + priestly) power arrayed against her.
- Step 3: In poem — "fxjèkj" (king/husband) and "ifr" (co-wives) represent the domestic patriarchal structure she addresses but subverts.
- Step 4: In poem — "cqèk efFk ?k`r dkf<+ fy;ks" (broke the hard shell of convention) — the "hard shell" is explicitly the male-controlled social order (purdah, sati, caste dining rules).
- Step 5: In poem — "Mkfj n;h Nks;h" (freed herself, escaped) — active verb agency; she is the subject of her own liberation, not a passive recipient of grace.
- Step 6: Synthesis — the poem doesn't just describe this conflict; its very existence (a woman composing, singing, teaching) *is* the enactment of female spiritual authority.

REASONING: The biographical prose narrates the conflict externally (third-person history), while the poem enacts it internally (first-person voice). Together they show that female spiritual authority in bhakti is both a theological claim (Krishna accepts her) and a political act (she speaks without male mediation).

ANSWER: The secondary theme operates on two registers: the biography documents the institutional resistance to her authority (court cases, persecution), while the poem performs that authority through direct address to Krishna, vernacular composition, and public performance. The tension is resolved not by compromise but by Krishna's implicit validation — the poem exists because her bhakti was authentic.

## WORKED_EXAMPLE_3
PROBLEM: Compare how two secondary themes — caste transcendence and ritual rejection — intersect in a single phrase from the poem: "yksd&ykt [kks;h valqou ty lhafp&lhafp." Explain the layered coding.

STEPS:
- Step 1: Deconstruct "yksd&ykt" — "yksd" = of the people/folk (non-Sanskrit, non-Brahminical); "ykt" = simple, unadorned, accessible. Together: language/register that bypasses priestly Sanskrit monopoly.
- Step 2: Deconstruct "[kks;h" — singing as spiritual practice (kirtan/bhajan) replacing Vedic recitation (which required Brahmin males).
- Step 3: Deconstruct "valqou ty lhafp&lhafp" — tears flowing like a river; uncontrolled, copious, bodily. Contrast with Brahminical ideal of "sthitaprajna" (steady wisdom) and ritualized, restrained worship.
- Step 4: Identify caste coding — "yksd" historically denotes lower-caste/vernacular traditions; Meera, a Rajput princess, adopts the voice of the marginalized, erasing her caste privilege in devotion.
- Step 5: Identify ritual rejection coding — "lhafp&lhafp" (weeping) and "csfy iSQfy" (dancing wildly) replace puja, mantra, yajna. The body becomes the site of worship, not the temple altar.
- Step 6: Show intersection — the same act (singing in folk tongue, weeping publicly) simultaneously transcends caste (by adopting low-prestige register) and rejects ritual (by replacing formal worship with emotional excess). The themes are inseparable because caste *is* ritual hierarchy in the varna system.

REASONING: In the bhakti worldview, caste and ritual are co-constitutive — Brahminical authority rests on ritual monopoly. Meera's single performative act attacks both. The poem compresses this intersection into one dense line, demonstrating how secondary themes in bhakti poetry are not additive but multiplicative.

ANSWER: "yksd&ykt [kks;h valqou ty lhafp&lhafp" is a compressed site where caste transcendence (vernacular language, folk form) and ritual rejection (tears/dance vs mantra/puja) converge. The phrase encodes Meera's strategic self-lowering (princess → folk singer) as spiritual elevation, demonstrating that in nirguna bhakti, social transgression *is* the path to the divine.

## COMPETENCY_QUESTION_1
QUESTION: A Class 11 student writes in an exam: "Meera Bai's poem has two themes: devotion to Krishna and women's empowerment." Using the concept of primary vs secondary themes, explain why this answer would receive partial marks at best, and rewrite it as a full-mark response.

COMPETENCY: Critical analysis of thematic hierarchy and integration in bhakti poetry

STEPS:
- Step 1: Identify the error — treating "women's empowerment" as a separate, modern thematic category imposed on the text rather than an immanent dimension of Meera's bhakti.
- Step 2: Explain the theoretical flaw — "empowerment" is a 20th-century liberal feminist framework; Meera's resistance is framed as *prem-bhakti* (love-devotion), not rights-claiming.
- Step 3: Show the correct relationship — gender defiance is a secondary theme *constitutive* of the primary theme; her devotion *takes the form of* resisting patriarchal control.
- Step 4: Provide the full-mark rewrite — "Meera's primary theme is Krishna-prem-bhakti, but this devotion is structurally inseparable from secondary themes of gender transgression (rejecting purdah/sati/co-wife rivalry encoded in 'fxjèkj/ifr'), caste transcendence (adopting 'yksd&ykt' vernacular over Sanskrit), and ritual rejection ('cqèk efFk ?k`r dkf<+ fy;ks'). Her bhakti *is* her rebellion; the social and spiritual are one continuum."

ANSWER: The original answer fails because it imposes an anachronistic framework and treats themes as a list. The rewritten answer shows thematic integration, uses textual evidence, and respects the text's own conceptual vocabulary (prem-bhakti, not empowerment).

DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: The textbook's biographical note calls Meera "n`<+fu'p;h Fkha" (independent/autonomous woman). Using evidence from both the biography and the poem, argue whether this label captures the full complexity of her agency, or whether it imposes a modern individualist framework on a pre-modern bhakti subject.

COMPETENCY: Historiographic critique of thematic interpretation / evaluating anachronism in literary analysis

STEPS:
- Step 1: Analyze "n`<+fu'p;h" — literally "self-willed" or "autonomous"; in 16th-century context, this meant acting without male permission (father/husband/king), a radical transgression.
- Step 2: Contrast with modern "individualism" — Meera's autonomy is *theocentric* (oriented to Krishna), not *egocentric* (oriented to self). She says "esjs rks fxjèkj xksiky" — MY king is Krishna, not "I am my own master."
- Step 3: Evidence from biography — she doesn't claim rights; she claims *bhakti* as her only duty ("Ñ".k dks gh viuk vkjkè; vkSj ifr ekurh jgha").
- Step 4: Evidence from poem — "Mkfj n;h Nks;h" (I freed myself, I escaped) — agency is real but *for* Krishna, not for self-realization in the modern sense.
- Step 5: Synthesize — the label "n`<+fu'p;h" is textually accurate (the textbook uses it) but analytically incomplete if read through modern individualism. Her agency is *relational* (defined by her relationship to Krishna) and *communal* (she gathers followers, creates a sect), not solitary self-fashioning.

ANSWER: The label is historically grounded but hermeneutically risky. Meera's agency is real and radical for her time, but it is *bhakti-agency* — freedom *for* divine service, not freedom *from* all constraint. A full analysis must hold both: she transgresses every patriarchal norm (modern resonance) but frames it as slavery to Krishna (pre-modern framework). The secondary theme of gender defiance cannot be reduced to "women's empowerment" without distorting the primary theme.

DIFFICULTY: hard