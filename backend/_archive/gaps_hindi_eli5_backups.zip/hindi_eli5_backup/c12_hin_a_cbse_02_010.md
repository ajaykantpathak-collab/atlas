## DEFINITION
Vocabulary in Context is the skill of determining the precise meaning of a word or phrase by analyzing its surrounding text — including syntactic clues, thematic consistency, emotional tone, and cultural or historical references — rather than relying solely on dictionary definitions.

## COGNITIVE_LEVEL
apply

## MASTERY_CRITERIA
The student can independently identify 5+ key words from the poem "ljkst Le`fr", explain how the context (imagery, tone, syntax) shapes each word's meaning, and use those words correctly in new sentences that reflect the poem's emotional register.

## SCOPE_BOUNDARY
This node covers vocabulary analysis specifically for the poem "ljkst Le`fr" (Chapter 2, Antra). It does NOT cover vocabulary from other chapters, general dictionary skills, or grammar rules (covered in node c12_hin_a_cbse_02_011).

## WALKTHROUGH
Imagine you're reading a WhatsApp forward in Hindi where a friend writes: "आज तो पूरा दिन *लताड़* पड़ी" — you instantly know *लताड़* doesn't mean "licking" but "scolding" because of the context "पूरा दिन" and the frustrated tone. That's exactly what we do with poetic vocabulary: the poem "ljkst Le`fr" uses words like *लयान*, *मँड़ोकल*, *लचक* in emotionally charged, image-dense lines. Start by reading the poem aloud — notice which words feel heavy, sharp, or tender. Then isolate 5–6 unfamiliar words. For each, ask: (1) What is the immediate sentence saying? (2) What image or emotion surrounds it? (3) Does the word's sound (hard/soft consonants) match the feeling? (4) How does the NCERT glossary definition shift when placed back in the line? The key insight: in poetry, a word's *contextual meaning* often carries more weight than its *dictionary meaning*.

## DIAGNOSTIC_QUESTION_1
From the poem "ljkst Le`fr", the word *वकेवय* appears in the line "नस[kk fookg vkewy uoy". What is the *contextual meaning* of *वकेवय* in this line, and which two contextual clues support it?

## DIAGNOSTIC_ANSWER_1
Correct answer: *वकेवय* means "completely" or "entirely" (not just "alone" or "lonely"). Clue 1: It modifies *फूकग* (darkness) — "वकेवय फूकग" suggests darkness that is total, unbroken. Clue 2: The next word *उओय* (empty/vacant) reinforces absolute absence. A wrong answer like "lonely" reveals the student is using the dictionary meaning of *एकाकी* without checking syntactic role (adverb modifying a noun phrase) or the cumulative imagery of total darkness and emptiness.

## DIAGNOSTIC_QUESTION_2
In the line "मज एसा ङ्यानि", the word *मज* is glossed as *आनन; एउ* (face/heart). Why does the poet choose *मज* over common synonyms like *मुख* or *हृदय* in this specific context?

## DIAGNOSTIC_ANSWER_2
Correct answer: *मज* (from Sanskrit *मानस्*) carries a sense of "inner self, mind-heart unity" — it fuses feeling and perception. In context, the speaker sees the mother's form (*रूप*) not just with eyes (*मुख*) or emotion (*हृदय*) but with his whole being. A wrong answer like "it means face" shows the student ignores the poem's theme of holistic memory (visual + emotional + spiritual) and the word's etymological depth, which the NCERT glossary hints at by giving *both* *आनन* and *हृदय*.

## DIAGNOSTIC_QUESTION_3
Apply the context-clue method to the word *लचक* in the line "फिज; ध व'कन  Üक`ाक्सज&ए[kज". The glossary says *लचक* = *झुकना, झुकाव*. But in this line, what *additional* meaning emerges from the metaphor of *काँगक्ष-काज* (a bending, flexible twig)?

## DIAGNOSTIC_ANSWER_3
Correct answer: *लचक* here means "resilient flexibility" — the ability to bend under pressure (grief) without breaking. The metaphor *काँगक्ष-काज* (a young, green branch) implies life, suppleness, and endurance. A student who only writes "bending" misses the *survival* connotation: the speaker's grief is not rigid (*अटल* like *लरकणक*) but alive and adaptive. This error reveals a failure to connect the word to the poem's central tension between *अटल* (fixed) memory and *लचक* (living) grief.

## DIAGNOSTIC_QUESTION_4
Compare the contextual meanings of *एक्का* (in "एक्का जिि फुजककज") and *एघ* (in "वकक'क कनय दज कुग एघ"). Both relate to "support" or "foundation". How does the poem use them to contrast the father's and mother's roles in the speaker's memory?

## DIAGNOSTIC_ANSWER_4
Correct answer: *एक्का* (from *एक* + *का*, "the one who makes whole") implies *active, structural support* — the father as builder of identity ("जिि फुजककज" = one who gave poetic voice). *एघ* (from *अग्नि* root, "hearth/foundation") implies *passive, enduring warmth* — the mother as the constant hearth ("वकक'क कनय" = the unchanging base). A wrong answer treating them as synonyms ("both mean support") misses the gendered, role-based contrast the poem constructs: father = dynamic enabler, mother = static anchor. This error reveals inability to trace thematic patterns across stanzas.

## DIAGNOSTIC_QUESTION_5
Evaluate this student interpretation: "The word *कुटजिक्र* (in *कुटजिक्र एिा फन*) means 'obstinate' because the glossary says *हकख फोइफक* (stubborn insistence). The speaker is being stubborn about his grief." Is this interpretation valid? Justify using the poem's tone and the word's morphological structure.

## DIAGNOSTIC_ANSWER_5
Correct answer: Invalid. *कुटजिक्र* = *कुट* (intense) + *जिक्र* (remembrance/meditation) → "deep, persistent remembrance", not "obstinate". The prefix *कुट-* intensifies the noun *जिक्र* (from *स्मृति*), and the context "एिा फन" (on this very pyre/ground) shows sacred devotion, not stubbornness. The tone is reverential ("हकख फोइफक" in glossary means "firm resolve", not negativity). A student calling it "obstinate" imposes a negative connotation from everyday Hindi *जिद* onto a Sanskritized poetic term — a classic register error.

## DIAGNOSTIC_QUESTION_6
Create two new sentences using *लोटु* and *रकणय* that capture their *poem-specific* meanings (not just dictionary meanings). The sentences must reflect the emotional weight these words carry in "ljkst Le`fr".

## DIAGNOSTIC_ANSWER_6
Good answer example:  
1. *लोटु*: "जब बाबूजी की पुरानी घड़ी हाथ में आई, तो लगा जैसे कोई *लोटु* लौट आया हो — वही टिक-टिक, वही अपनापन।" (Captures *लोटु* = "beloved familiar presence returning", not just "relative".)  
2. *रकणय*: "उसने अपने *रकणय* में दादी की कहानियाँ, माँ के गीत, और गाँव की मिट्टी सब सहेज रखी थी।" (Captures *रकणय* = "sacred trust/legacy passed down", not just "property".)  
A poor answer using *लोटु* as "relative" and *रकणय* as "inheritance money" reveals the student cannot transfer contextual meaning to new situations — the ultimate test of vocabulary mastery.

## COMMON_MISCONCEPTION
Students treat the NCERT glossary (*'कन्कफकज व फवीक.ह*) as the *final* meaning. They write "*लचक* means *झुकना*" and stop. But in poetry, the glossary gives the *denotation*; the *connotation* lives in the line's imagery, sound, and thematic role. For example, *लचक* in "फिज; ध व'कन Üक`ाक्सज" is not just "bending" — it's *resilient bending of a living twig*, contrasting with *लरकणक* (rigid/fixed) in the next line. Students miss this because they don't ask: "What does this word *do* in this line that its dictionary definition doesn't show?"

## ON_FAILURE
Step 1: Have the student pick 3 words from the glossary they think they "know". Step 2: For each, find the exact line in the poem. Step 3: Ask: "If you replace this word with its glossary synonym, does the line lose something? What?" Step 4: Guide them to name the *added layer* (sound, image, contrast, cultural echo). Step 5: Re-attempt Diagnostic Q3 and Q4. If still stuck, revisit node c12_hin_a_cbse_02_008 (Imagery and Metaphor) to see how words *create* images.

## BUILDS_ON
Class 11 skill of using context clues for vocabulary (node c11_hin_ar_cbse_01_010) — now applied to dense poetic language with cultural-historical layers.

## LEADS_TO
Node c12_hin_a_cbse_02_012 (Comprehension: Literal and Inferential Questions) where contextual vocabulary enables accurate inference, and c12_hin_a_cbse_02_014 (Writing Skills) where precise word choice shapes analytical answers.

## PREREQUISITE_NODE_IDS
c11_hin_ar_cbse_01_010, c12_hin_a_cbse_02_008, c12_hin_a_cbse_02_009
## PREREQUISITE_REASONS
c11_hin_ar_cbse_01_010: Class 11 Vocabulary in Context node — established the basic context-clue method (syntax, tone, surrounding words) which this node deepens for poetic register.
c12_hin_a_cbse_02_008: Imagery and Metaphor — essential because key vocabulary in this poem (*काँगक्ष-काज*, *लचक*, *लोटु*) functions *as* metaphor; you cannot decode the word without the image.
c12_hin_a_cbse_02_009: Irony and Symbolism — the poem uses words like *एक्का* and *एघ* symbolically (father/mother roles); understanding symbolic vocabulary requires this node's framework.

## FORWARD_NODE_IDS
c12_hin_a_cbse_02_012, c12_hin_a_cbse_02_013, c12_hin_a_cbse_02_014, c12_hin_a_cbse_02_011, c12_hin_a_cbse_02_015

## FORWARD_REASONS
c12_hin_a_cbse_02_012: Comprehension questions (literal/inferential) require precise word meanings — e.g., Q2 "Why does the poet remember mother?" needs *एघ* = "hearth/foundation", not just "support".
c12_hin_a_cbse_02_013: Critical Thinking asks for interpretation of lines like "वकक'क कनय दज कुग एघ" — vocabulary depth enables thematic analysis.
c12_hin_a_cbse_02_014: Writing Skills (analytical paragraphs) demand using the poem's own vocabulary (*लचक*, *कुटजिक्र*, *रकणय*) as evidence — misusing them loses marks.
c12_hin_a_cbse_02_011: Provides glossed vocabulary essential for identifying dialect words.  
c12_hin_a_cbse_02_015: Key vocabulary ensures precise articulation of concepts during discussion.  

## CROSS_SUBJECT_PREREQS
c11_hin_ar_cbse_01_010, c11_hin_ar_cbse_02_010, c11_hin_ar_cbse_03_010
## CROSS_SUBJECT_REASONS
c11_hin_ar_cbse_01_010: Vocabulary in Context (Chapter 1, Antra) — introduced the "context > dictionary" principle with simpler prose; this poem applies it to complex verse.
c11_hin_ar_cbse_02_010: Vocabulary in Context (Chapter 2, Antra) — practiced on a different poem (*मीरा के पद*), building the habit of checking devotional vs. literal meanings.
c11_hin_ar_cbse_03_010: Vocabulary in Context (Chapter 3, Antra) — worked with *कबीर* where words like *माया*, *राम* have layered meanings — direct preparation for *फुजककज*'s Sanskritized lexicon.

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_01_010 -> c12_hin_a_cbse_02_010 -> c12_hin_a_cbse_02_012

## THIS_FORMULA
Contextual Meaning = Denotation (glossary) + Connotation (imagery, sound, contrast, cultural echo) + Syntactic Role (how it functions in the sentence) + Thematic Resonance (how it echoes the poem's central concerns)

## FORMULA_VARIABLES
- Denotation: Literal meaning from NCERT glossary (e.g., *लचक* = झुकना)
- Connotation: Emotional/associative charge from poetic context (e.g., *लचक* = resilient, living flexibility)
- Syntactic Role: Grammatical function shaping meaning (e.g., *वकेवय* as adverbial intensifier)
- Thematic Resonance: Connection to poem's core themes (memory, grief, identity, gendered parental roles)

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
linguistic

## CROSS_SUBJECT
N/A | The poem references *कुटजिक्र* (intense remembrance) and *रकणय* (sacred trust) — terms rooted in Sanskrit textual tradition (Upanishadic *स्मृति*, Dharmashastric *न्यास*). Understanding their historical semantic range helps decode the poet's deliberate archaism.
 N/A | The imagery *काँगक्ष-काज* (flexible twig) and *लचक* reflects ecological knowledge of riparian vegetation (willow-like trees near rivers) — the poet uses a geographically grounded metaphor for psychological resilience.
 N/A | The father's role as *एक्का* ("enabler of voice") mirrors the informal mentor-apprentice economy in traditional *गुरुकुल* / *उस्ताद-शागिर्द* systems — vocabulary encodes a socio-economic relationship.
## PREREQ_CONCEPT
The principle that in literary texts, especially poetry, a word's meaning is co-created by its immediate linguistic environment and the work's larger thematic architecture — not fixed by dictionary entry.

## PREREQ_BEFORE
Student must be able to: (1) locate a word in the poem's line, (2) read the line aloud for sound/tone, (3) identify the glossary meaning, (4) notice at least one image or contrast near the word.

## PREREQ_STUCK
If stuck, review the "Context Clue Types" table from Class 11 (node c11_hin_ar_cbse_01_010): Definition, Synonym, Antonym, Example, Inference — then practice on 2-3 lines from this poem.

## WORKED_EXAMPLE_1
PROBLEM: Analyze the word *लयान* in the line "गकसा एसा फकटयह इ¡क्लह लयान". The glossary says *लयान* = *आकिउ* (wave). But *लयान* is not the common word for wave (*लहर*, *तरंग*). What does *लयान* add?
STEPS:
- Step 1: Locate the line — it describes the mother's form appearing in the "form of color" (*रूप जकस एसा ईरुह ध*) amidst darkness.
- Step 2: Check glossary: *लयान* = *आकिउ* (wave). Note: *आकिउ* is also uncommon; it suggests a *rising swell*, not a breaking wave.
- Step 3: Analyze syntactic role — *लयान* is the subject of *इ¡क्लह* (was rising). The mother's form *rises like a swell*.
- Step 4: Connect to imagery — "गकसा एसा फकटयह" (in the form of color) + *लयान* = a color-swell, not a water-wave. It's synesthetic: grief made visible as rising color.
- Step 5: Thematic resonance — *लयान* (from *लय* = rhythm/dissolution) implies a *cyclic return*, matching the poem's theme of memory recurring. *लहर* would be too transient; *लयान* feels inevitable, tidal.
REASONING: The poet chooses a rare, Sanskritized word (*लयान*) over common *लहर* to evoke *ritual return* (like *लय* in music/dance) and *synesthetic grief* (color rising like water). The glossary gives the denotation; the context builds the connotation.
ANSWER: *लयान* means "a rhythmic, inevitable swell of color/form" — carrying connotations of cyclic memory, synesthetic grief, and ritual return that *लहर* cannot.

## WORKED_EXAMPLE_2
PROBLEM: The glossary defines *मँड़ोकल* = *वकग हकजुक* (to fold hands). In the line "मँड़ोकल एवकक फकटयह एम~ोक्ल्हल्क्ष", the word appears in a compound with *लक्* (lax). Why is *मँड़ोकल* used instead of *जोड़ना* or *बाँधना*?
STEPS:
- Step 1: Find the line — it describes the speaker's childhood: "मज एसा ङ्यानि ... मँड़ोकल एवकक फकटयह एम~ोक्ल्हल्क्ष" (hands folded in color-form).
- Step 2: Glossary meaning: *मँड़ोकल* = *वकग हकजुक* (folding hands, usually in prayer/greeting).
- Step 3: Syntactic context — *मँड़ोकल* is a verbal noun (gerund) describing a habitual action (*फकटयह* = form/shape). The phrase *मँड़ोकल एवकक* = "the form of folded hands".
- Step 4: Cultural connotation — *मँड़ोकल* (from *मण्डल* + *कृ*) implies *ritualized, sacred folding* — not casual. It evokes *नमस्कार*, *प्रणाम*, the child's posture before mother/deity.
- Step 5: Contrast with *लक्* (lax) in *एम~ोक्ल्हल्क्ष* — *मँड़ोकल* (tight, ritual) vs. *लक्* (loose, natural). The child's body holds both: reverence (*मँड़ोकल*) and ease (*लक्*).
REASONING: *मँड़ोकल* is not just "folding" — it's *sacralized gesture*. *जोड़ना* is mechanical; *बाँधना* implies binding. The poet chooses a word steeped in *भक्ति* culture to show the child's instinctive reverence for the mother as divine.
ANSWER: *मँड़ोकल* means "ritualized, reverent folding of hands" — encoding the child's unconscious deification of the mother, contrasting with the natural looseness (*लक्*) of the same body.

## WORKED_EXAMPLE_3
PROBLEM: Synthesize: How do the words *एक्का*, *एघ*, *लचक*, and *रकणय* together map the poem's emotional architecture? Use the Contextual Meaning Formula.
STEPS:
- Step 1: List each word with its Denotation (glossary): *एक्का* = enabler, *एघ* = hearth/foundation, *लचक* = bending, *रकणय* = legacy/trust.
- Step 2: For each, add Connotation from imagery: *एक्का* → poetic voice gifted (active), *एघ* → unchanging base (passive), *लचक* → living flexibility (adaptive), *रकणय* → sacred inheritance (transgenerational).
- Step 3: Note Syntactic Roles: *एक्का* (subject), *एघ* (object of *दे*), *लचक* (subject of *इकक*), *रकणय* (object of *दे* in imperative).
- Step 4: Map Thematic Resonance: Father = *एक्का* (origin of speech), Mother = *एघ* (ground of being), Grief = *लचक* (living process), Duty = *रकणय* (what must be passed on).
- Step 5: See the pattern — the four words form a *structural quartet*: Origin (father), Ground (mother), Process (grief), Transmission (legacy). No single word carries this; the *set* does.
- Step 6: Verify with poem's closing: "नस दस± ध वीज.क दज] दजरक एसा रीज.क!" — *वीज.क* (viZ.k = giving legacy) and *रीज.क* (riZ.k = performing last rites) enact *रकणय*.
REASONING: Vocabulary in context is not word-by-word; it's *networked*. The poem's emotional architecture is built by a cluster of key terms that define each other through contrast and complement. The formula works at the *system* level.
ANSWER: The quartet *एक्का–एघ–लचक–रकणय* maps the poem's emotional architecture as: Father (dynamic origin of voice) ↔ Mother (static ground of being) → Grief (living, flexible process) → Legacy (sacred duty to transmit). Each word's contextual meaning is defined by its place in this system.

## COMPETENCY_QUESTION_1
QUESTION: A student writes in a board exam answer: "In 'ljkst Le`fr', the poet uses the word *लचक* to show that grief makes a person weak and submissive." Using the Contextual Meaning Formula, evaluate this interpretation. Is it correct, partially correct, or incorrect? Justify with two specific contextual evidences from the poem.
COMPETENCY: Critical evaluation of peer interpretation using textual evidence
STEPS:
- Step 1: Recall the line: "फिज; ध व'कन Üक`ाक्सज ए[kज" and the next line "लरकणक ध :ि इककर दज दज एघ".
- Step 2: Apply Denotation: *लचक* = bending/flexibility; *लरकणक* = rigid/fixed.
- Step 3: Apply Connotation: *काँगक्ष-काज* (green twig) = life, resilience; *लरकणक* = dead, unyielding.
- Step 4: Apply Thematic Resonance: The poem values *लचक* (living grief) over *लरकणक* (frozen stagnation). The speaker *chooses* "वकक'क कनय दज कुग एघ" — to *remain* in the mother's foundation, not break.
- Step 5: Judge the student's claim: "weak and submissive" imposes a negative social meaning onto a poetic image of *survival through flexibility*. Incorrect.
ANSWER: Incorrect. Evidence 1: *लचक* is paired with *काँगक्ष-काज* (living twig) — symbol of resilience, not weakness. Evidence 2: The poem contrasts *लचक* (adaptive, alive) with *लरकणक* (rigid, dead) — the former is presented as the *viable* way to carry grief. The student confuses "bending" with "breaking".
DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: The NCERT glossary gives *कुटजिक्र* = *हकख फोइफक* (firm resolve/insistence). A competitive exam (CUET) asks: "In 'ljkst Le`fr', the word *कुटजिक्र* primarily conveys: (a) stubborn refusal to accept reality, (b) ritualized remembrance as sacred duty, (c) psychological denial, (d) artistic obsession." Choose the correct option and defend it using morphological analysis and thematic context.
COMPETENCY: Competitive exam application — morphological + thematic decoding
STEPS:
- Step 1: Morphological breakdown: *कुट्* (intensive prefix, 'deeply/fully') + *जिक्र* (from *स्मृ* 'to remember', via *जिक्र* = remembrance/meditation). Literal: "deep remembrance".
- Step 2: Locate in poem: "कुटजिक्र एिा फन" — on *this very pyre/ground* (where father was cremated / mother's memory burns).
- Step 3: Thematic context: The speaker says "नक[ घ थौ ध दकक जघ] दक दग¡ वकत टक्स उघा दघा*" — memory is the only truth. *कुटजिक्र* is the *act of keeping that truth alive*.
- Step 4: Evaluate options: (a) "stubborn refusal" — negative, imposes *जिद*; (b) "ritualized remembrance as sacred duty" — matches *कुट्+जिक्र* + pyre imagery + "रीज.क" (last rites) later; (c) "denial" — contradicts "नक[ घ थौ..."; (d) "artistic obsession" — reduces *रकणय* to personal fixation.
- Step 5: Select (b) — only option aligning with morphology, imagery, and theme.
ANSWER: (b) Ritualized remembrance as sacred duty. Defense: Morphology (*कुट्* + *जिक्र* = intensive remembrance), context (on the pyre, *एिा फन*), and theme (memory as only truth, *रकणय* as duty) all converge on sacred, deliberate commemoration — not pathology or art.
DIFFICULTY: hard