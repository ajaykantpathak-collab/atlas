## DEFINITION
Literal comprehension questions ask for information explicitly stated in the text, while inferential comprehension questions require the reader to deduce meaning using context, prior knowledge, and textual clues.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student can independently classify a given comprehension question as literal or inferential, locate explicit textual evidence for literal questions, and construct a logical inference with textual support for inferential questions.

## SCOPE_BOUNDARY
This node covers the distinction between literal and inferential questions using Kabir's poem from Chapter 10, strategies to answer each type, and practice with board-exam style questions. It does not cover critical appreciation, literary devices in depth, or creative writing based on the poem.

## WALKTHROUGH
Imagine you are sitting in the exam hall and see a question: "Why does Kabir say 'no one knows my address'?" You panic because the poem doesn't directly say why. This is where knowing the difference between literal and inferential questions saves you. First, read the question and ask: "Is the answer directly written in the poem?" If yes, it's literal – underline the exact lines. If not, it's inferential – you must combine clues from the poem (like Kabir's rejection of rituals, his focus on inner devotion) with your understanding of the Bhakti movement to form an answer. Start by identifying the question type, then follow the appropriate strategy.

## DIAGNOSTIC_QUESTION_1
What is the primary difference between a literal comprehension question and an inferential comprehension question?

## DIAGNOSTIC_ANSWER_1
A literal comprehension question has its answer directly stated in the text, while an inferential comprehension question requires the reader to draw a conclusion based on textual evidence and context. A wrong answer (e.g., "literal questions are easy, inferential are hard") reveals the student confuses difficulty with the source of the answer, missing the core distinction of explicit vs. implicit information.

## DIAGNOSTIC_QUESTION_2
In the poem, Kabir says: "esjs rks fxjèkj xksiky] nwljks u dksbZ tk osQ flj eksj&eqoqQV] esjks ifr lksbZ". If a question asks, "Who does Kabir consider his family?", is this literal or inferential? Explain your reasoning.

## DIAGNOSTIC_ANSWER_2
This is a literal question because the poem explicitly lists Kabir's family as "eksj&eqoqQV" (the poor and the downtrodden) and "ifr lksbZ" (everyone is my friend). A wrong classification (e.g., inferential) suggests the student thinks any question about relationships requires interpretation, not realizing the text directly states the answer.

## DIAGNOSTIC_QUESTION_3
Given the line "vc r csfy iSQfy x;h] vk.kan&iQy gks;h", a question asks: "What does the poet imply about the change in his social status?" Demonstrate how to answer this inferential question using textual clues.

## DIAGNOSTIC_ANSWER_3
Step 1: Identify the literal meaning – "now the touch has become impure, it has become contaminated." Step 2: Note the contrast with earlier lines where Kabir associated with the lowly. Step 3: Infer that the poet is criticizing the caste-based pollution concept – his touch is now considered impure by orthodox society because he embraces the marginalized. Step 4: Support with the poem's theme of rejecting caste hierarchy. A wrong answer that only paraphrases the line without connecting to the social critique shows the student cannot move beyond literal translation to inference.

## DIAGNOSTIC_QUESTION_4
Compare the two questions: (a) "What does Kabir say about his birth?" (b) "Why does Kabir reject the label of a weaver (julaha)?" Analyze the cognitive demand of each.

## DIAGNOSTIC_ANSWER_4
Question (a) is literal – the poem states "tUe % lu~ 1498] oqQM+dh xk¡o". Question (b) is inferential – the poem never explicitly says "I reject the label"; instead, we infer rejection from his assertion of divine identity over caste identity ("Ñ".k dh mikfldk gksus osQ dkj.k mudh dfork esa lxq.k HkfDr eq[; :i ls ekStwn gS"). A student who treats both as literal fails to see that (b) requires synthesizing multiple textual hints about Kabir's philosophy.

## DIAGNOSTIC_QUESTION_5
Evaluate this student answer to an inferential question: "Kabir rejects rituals because he was illiterate." The question was: "Why does Kabir emphasize inner devotion over rituals?" Justify your evaluation.

## DIAGNOSTIC_ANSWER_5
The answer is poor because it introduces an external assumption (illiteracy) not supported by the text. The poem shows Kabir's rejection stems from his realization that rituals are hollow without true knowledge ("Kku ls eqfDr feyrh gS") and his direct experience of the Divine. A good evaluation would note that the student's answer ignores textual evidence (e.g., "fojg dh osnuk gS vkSj feyu dk mYykl Hkh") and substitutes a biographical stereotype. This reveals the student doesn't know inferences must be text-grounded.

## DIAGNOSTIC_QUESTION_6
Create an inferential question based on the poem's last stanza ("nfèk efFk ?k`r dkf<+ fy;ks] Mkfj n;h Nks;h...") and provide a model answer with textual support.

## DIAGNOSTIC_ANSWER_6
Question: "What does the image of 'the deer caught in the trap' symbolize about the human condition in Kabir's view?" Model answer: The deer represents the soul entangled in worldly illusions (Maya) and the trap is the cycle of birth-death; Kabir suggests only the Guru's grace (implied by "Hkxr nsf[k jkth gq;h") can free it. A poor answer would describe the literal deer without connecting to the poem's spiritual theme, showing the student cannot create inferential questions that target deeper meaning.

## COMMON_MISCONCEPTION
Students often think inferential questions are "opinion questions" where any answer is acceptable. They write personal feelings ("I think Kabir is angry") instead of text-based inferences ("The poem's tone suggests Kabir is critical of orthodoxy because he contrasts 'valqou ty' with 'izse&csfy'"). This error arises because they confuse 'inference' with 'guessing' and don't realize every inference must be anchored in specific textual evidence.

## ON_FAILURE
1. Give the student a short excerpt from the poem (2-3 lines) and ask them to write one literal and one inferential question about it. 2. Have them swap with a partner and classify each other's questions. 3. For each inferential question, require the partner to underline the exact words in the excerpt that support the inference. 4. Debrief: highlight that if no words can be underlined, the inference is unsupported. Repeat with new excerpts until the student consistently produces text-anchored inferences.

## BUILDS_ON
This builds on the student's ability to identify explicit information in a text (literal comprehension) learned in earlier classes.

## LEADS_TO
This enables the student to tackle critical thinking and analysis questions (node c11_hin_ar_cbse_10_013) where they must evaluate themes and author's intent using inferential reasoning.

## PREREQUISITE_NODE_IDS
c11_hin_ar_cbse_10_001, c11_hin_ar_cbse_10_002, c11_hin_ar_cbse_10_010, c11_hin_ar_cbse_10_008, c11_hin_ar_cbse_10_011

## PREREQUISITE_REASONS
c11_hin_ar_cbse_10_001: Provides context about Kabir and the Bhakti movement, essential for making historical/cultural inferences.
c11_hin_ar_cbse_10_002: Understanding plot/narrative structure helps locate where explicit information appears in the poem.
c11_hin_ar_cbse_10_010: Vocabulary in context is needed to comprehend the literal meaning of words like 'csfy', 'foyks;h', 'Nks;h' before inferring.
c11_hin_ar_cbse_10_008: Comprehension questions often ask for interpretation of images and metaphors.  
c11_hin_ar_cbse_10_011: Literal comprehension questions (e.g., "Why does she call Giridhar 'fxjèkj'?") require case and vocabulary analysis taught here.  

## FORWARD_NODE_IDS
c11_hin_ar_cbse_10_013, c11_hin_ar_cbse_10_014, c11_hin_ar_cbse_10_015, c12_hin_a_cbse_10_012, c12_hin_ar_cbse_04_012, c12_hin_ar_cbse_09_012, c12_hin_ar_cbse_10_012

## FORWARD_REASONS
c11_hin_ar_cbse_10_013: Critical thinking requires inferential skills to analyze themes, irony, and symbolism.
c11_hin_ar_cbse_10_014: Writing skills tasks (e.g., analytical paragraph) demand the ability to cite textual evidence for both literal and inferential points.
c11_hin_ar_cbse_10_015: Literal/inferential comprehension is the baseline for moving to evaluative discussion.  
c12_hin_a_cbse_10_012: Direct predecessor — same skill at lower text complexity; student must have mastered L/I labeling there.  
c12_hin_ar_cbse_04_012: अगला तार्किक चरण: Literal comprehension is the ability to extract explicitly stated facts, details, and sequences dire... इस नोड की अवधारणाओं को सीधे उपयोग/विस्तारित करता है।  
c12_hin_ar_cbse_09_012: Reinforces skill across a different poetic voice.  
c12_hin_ar_cbse_10_012: Prior practice with literal/inferential distinction in Class 11.  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
none

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_10_001 -> c11_hin_ar_cbse_10_012 -> c11_hin_ar_cbse_10_013

## THIS_FORMULA
N/A - conceptual

## FORMULA_VARIABLES
N/A

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
linguistic

## CROSS_SUBJECT
c11_history_bhakti_movement | Understanding the Bhakti movement's challenge to ritual orthodoxy provides the historical context needed to infer Kabir's motives in the poem.
c11_civics_social_reform | Kabir's rejection of caste hierarchy mirrors modern constitutional values of equality; inferring his social message connects literature to civic ideals.

## PREREQ_CONCEPT
Ability to distinguish between explicitly stated information and implied meaning in a text.

## PREREQ_BEFORE
Student must be able to read and understand the Hindi poem's vocabulary and basic storyline.

## PREREQ_STUCK
Review the vocabulary list (c11_hin_ar_cbse_10_010) and the plot summary (c11_hin_ar_cbse_10_002) to ensure literal comprehension before attempting inference.

## WORKED_EXAMPLE_1
PROBLEM: Analyze the following question from the poem: "ehjk txr dks ns[kdj jksrh D;ksa gSa\" (Why does Kabir laugh seeing the thread?). Provide a step-by-step inferential answer.

STEPS:
- Step 1: Identify the question type – it asks "why", indicating an inferential question because the poem does not directly state the reason for laughing.
- Step 2: Locate the relevant lines – the poem mentions "txr" (thread) in the context of the sacred thread ceremony (janeu) and Kabir's refusal: "ehjk okil esM+rk vk xb±A ;gk¡ ls mUgksaus Ñ".k dh yhyk Hkwfe o`Unkou dh ;k=kk dhA"
- Step 3: Gather textual clues – Kabir rejects the thread made of cotton, calling it fragile ("Hkwfe"), and points out it burns, rots, and breaks. He values the thread of God's name ("Ñ".k") instead.
- Step 4: Synthesize inference – Kabir laughs at the irony of people placing faith in a perishable cotton thread while ignoring the eternal divine thread. His laughter is a critique of ritual superficiality.
- Step 5: Formulate answer with evidence – "Kabir laughs because he finds it absurd that the sacred thread (janeu) is treated as a spiritual guarantee when it is physically fragile (cotton burns, rots, breaks). He contrasts it with the 'thread of Ram's name' which is unbreakable. This is supported by the lines where he rejects the cotton thread and the priest's anger."

REASONING: The steps move from question classification to textual evidence gathering, then to synthesis of implicit meaning, ensuring the inference is grounded in the poem's own contrasts.

ANSWER: Kabir laughs at the hypocrisy of valuing a fragile cotton thread (janeu) over the eternal thread of devotion. The poem explicitly states he rejected the cotton thread because it burns, rots, and breaks, implying his laughter stems from seeing the futility of ritual without inner faith.

## WORKED_EXAMPLE_2
PROBLEM: A literal question: "ehjk us Ñ".k dh mikluk fdl :i esa djrh gS\ og :i oSQlk gS\" (In what form does Kabir worship Ram? Is that form saguna or nirguna?). Answer using direct textual evidence.

STEPS:
- Step 1: Recognize this as a literal question – it asks for information explicitly given in the introductory prose passage.
- Step 2: Scan the prose passage before the poem for keywords: "Ñ".k dh mikfldk", "ekStwn", "fuxZq.k".
- Step 3: Extract exact statements – "Ñ".k dh mikfldk gksus osQ dkj.k mudh dfork esa lxq.k HkfDr eq[; :i ls ekStwn gS ysfdu fuxZq.k HkfDr dk izHkko Hkh feyrk gS".
- Step 4: Interpret the terms – "ekStwn" = nirguna (formless), "fuxZq.k" = saguna (with form). The text says primarily nirguna but also saguna influence.
- Step 5: Construct answer – "Kabir worships Ram primarily in the nirguna (formless) form, as stated in the introduction: 'lxq.k HkfDr eq[; :i ls ekStwn gS'. However, the text also notes saguna influence: 'fuxZq.k HkfDr dk izHkko Hkh feyrk gS'."

REASONING: Literal questions require direct quotation or close paraphrase of the text. The steps ensure the student doesn't infer but reports exactly what the text says, using the author's own terminology.

ANSWER: According to the introductory passage, Kabir worships Ram mainly in the nirguna (formless) aspect ("eq[; :i ls ekStwn"), though the saguna (with form) influence is also present ("fuxZq.k HkfDr dk izHkko Hkh feyrk gS").

## WORKED_EXAMPLE_3
PROBLEM: A board-style question combining literal and inferential skills: "How does Kabir use the metaphor of 'weaving' to convey his spiritual philosophy? Cite specific lines."

STEPS:
- Step 1: Identify the core metaphor – Kabir was a weaver (julaha) and uses weaving imagery throughout.
- Step 2: Locate literal references – The poem mentions "nkl th" (weaver) in the intro: "j.kNksM+ nkl th dh eafnj dh ewfrZ esa os lekfgr gks xb±A". The poem itself has weaving-related words? Actually the poem lines given: "esjs rks fxjèkj xksiky..." don't explicitly have weaving words, but the intro does. Also, the poem's structure of "threads" (txr) connects.
- Step 3: Infer the metaphorical meaning – Weaving = creating the fabric of life/devotion. The "thread" (txr) is the divine name; the "weaver" is the devotee. The cotton thread (janeu) is fake; the true thread is Ram's name.
- Step 4: Connect to philosophy – Just as a weaver interlaces threads to make cloth, the devotee interlaces moments of remembrance to create a life of devotion. The metaphor emphasizes labor, patience, and the value of the raw material (God's name).
- Step 5: Cite evidence – Use intro: "j.kNksM+ nkl th dh eafnj dh ewfrZ esa os lekfgr gks xb±A" and poem: "txr" as divine thread, contrast with cotton thread.
- Step 6: Write structured answer – Point: Kabir transforms his profession into a spiritual metaphor. Evidence: He was a weaver (intro); he speaks of "txr" (thread) in the poem. Explanation: The cotton thread of ritual is weak; the thread of Ram's name is strong. Link: This reflects his philosophy that true spirituality is woven through constant practice, not external symbols.

REASONING: This example combines literal retrieval (weaver identity from intro) with inferential interpretation (metaphorical meaning of weaving/thread), modeling the multi-step reasoning needed for high-mark board questions.

ANSWER: Kabir uses his identity as a weaver (julaha) to metaphorically frame devotion as weaving: the raw material is God's name (Ram), the thread is continuous remembrance, and the fabric is a life of inner purity. The poem contrasts the fragile cotton thread (janeu) with the unbreakable thread of Ram's name, showing that true spirituality is woven through sustained bhakti, not ritual. Textual support: intro mentions his weaver background; poem centers on "txr" as the divine thread.

## COMPETENCY_QUESTION_1
QUESTION: Read the following lines from the poem: "laru f<x cSfB&cSfB] yksd&ykt [kks;h / valqou ty lhafp&lhafp] izse&csfy cks;h". A student answers: "Kabir is describing a morning walk." Is this answer correct? Explain why or why not, and provide the correct interpretation.

COMPETENCY: Textual interpretation and inference

STEPS:
- Step 1: Analyze the student's answer – it takes the imagery literally (morning walk) without considering the poetic context.
- Step 2: Identify the actual imagery – "cSfB&cSfB" (slowly, gently), "yksd&ykt" (simple, natural), "valqou ty" (pure water/tears?), "lhafp&lhafp" (trembling), "izse&csfy" (love's shade?).
- Step 3: Infer the symbolic meaning – These lines depict the subtle, tender experience of divine love (prem/bhakti) entering the heart, not a physical walk.
- Step 4: Formulate correction – The answer is incorrect because it ignores the metaphorical language. The correct interpretation: Kabir describes the gentle, transformative arrival of divine love (izse) that makes the heart tremble (lhafp) and brings purity (valqou ty).

ANSWER: The student's answer is incorrect. The lines use metaphorical language to describe the internal experience of divine love (izse) – "cSfB&cSfB" (gradually), "yksd&ykt" (naturally), "valqou ty" (pure essence), "lhafp&lhafp" (trembling with emotion), "izse&csfy" (in the shade of love). Kabir is not describing a literal walk but the subtle awakening of bhakti in the heart.

DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: The NCERT textbook includes this question: "dYiuk djsa] izse izkfIr osQ fy, ehjk dks fdu&fdu dfBukb;ksa dk lkeuk djuk iM+k gksxkA" (Discuss what difficulties Kabir must have faced to realize divine love). This requires synthesizing information from the entire chapter (prose intro + poem). Write a structured answer using the PEEL method (Point, Evidence, Explanation, Link) with at least three distinct points.

COMPETENCY: Synthesis and structured analytical writing

STEPS:
- Step 1: Break the question – it asks for difficulties (dfBukbZ) faced in achieving divine love (izse izkfIr), requiring inference from both prose and poem.
- Step 2: Point 1 – Social ostracization due to caste. Evidence: Intro says "fpÙkkSM+ jkt?kjkus esa vusd d\"V mBkus osQ ckn ehjk okil esM+rk vk xbZ" (after many failed attempts to enter the palace, Kabir left). Explanation: As a low-caste weaver, he was denied access to traditional spiritual spaces. Link: This exclusion forced him to find an alternative path.
- Step 3: Point 2 – Rejection of ritual orthodoxy. Evidence: Poem shows he rejects the sacred thread (janeu) and the priest's anger. Explanation: Challenging established rituals invited persecution. Link: His refusal to compromise brought conflict.
- Step 4: Point 3 – Internal struggle to maintain purity. Evidence: Poem lines "nwèk dh eFkfu;k¡ cM+s izse ls foyks;h" (the new bride's ornaments are lost in great love). Explanation: Surrendering ego and worldly attachments is a difficult inner battle. Link: The metaphor of the bride losing ornaments signifies letting go of identity.
- Step 5: Conclude – Kabir's realization came through overcoming social, religious, and internal barriers, making his path of love a radical act of resistance.

ANSWER: Kabir faced three major difficulties in realizing divine love: (1) Social exclusion – as a low-caste weaver, he was barred from temples and guru's doors (intro: "fpÙkkSM+ jkt?kjkus esa vusd d\"V mBkus osQ ckn ehjk okil esM+rk vk xbZ"), forcing him to seek God directly. (2) Religious persecution – his rejection of rituals like the janeu (poem: contrast of cotton thread vs. Ram's name) angered orthodox authorities. (3) Inner surrender – the poem's image of the bride losing her ornaments in love ("nwèk dh eFkfu;k¡ cM+s izse ls foyks;h") symbolizes the painful shedding of ego and worldly identity. These difficulties show that Kabir's path of love (prem marg) required courage against both external structures and internal attachments.

DIFFICULTY: hard