## DEFINITION
Irony is a literary device where the intended meaning of words or events is opposite to their literal or expected meaning, creating a contrast between appearance and reality. Symbolism is the use of concrete objects, characters, or actions to represent abstract ideas, qualities, or themes beyond their literal sense.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student can independently identify specific instances of verbal, situational, and dramatic irony in the chapter's poem and prose, explain how symbols like the flute, peacock feather, or the forest function as multi-layered representations of devotion and separation, and write a structured board-style answer using the Point-Evidence-Explanation-Link (PEEL) method.

## SCOPE_BOUNDARY
This node covers irony (verbal, situational, dramatic) and symbolism (objects, characters, settings) as they appear in the Chapter 6 texts: the poem "Hajir-Jaik ka Izhaar" and the prose piece "Hajir aur Jaik". It does NOT cover imagery, metaphor, simile, or other figures of speech addressed in node c12_hin_a_cbse_06_008, nor does it cover vocabulary or grammar exercises.

## WALKTHROUGH
Imagine you are reading the poem where Hajir says "I will not go to the forest" but her every action shows she is already mentally there — that gap between words and truth is irony. Now think of the peacock feather: it is just a feather, but in the text it stands for Krishna's grace, the beauty of devotion, and the pain of separation all at once — that is symbolism. Begin by reading the poem aloud twice: first for the surface story, second to mark every line where the speaker says one thing but means another (irony) and every object that feels heavier than its physical weight (symbolism). In the prose, watch for moments where the narrator knows more than the characters (dramatic irony) and for recurring motifs like the forest or the flute that carry emotional weight. The key insight: irony creates tension by revealing a gap; symbolism creates depth by loading an object with meaning — both serve the central theme of *prem-bhakti* (devotional love) where human limitation meets divine play.

## DIAGNOSTIC_QUESTION_1
Define verbal irony and give one example from the poem "Hajir-Jaik ka Izhaar" where Hajir's spoken words contradict her inner state.

## DIAGNOSTIC_ANSWER_1
Verbal irony occurs when a speaker says the opposite of what they mean. In the poem, when Hajir declares "Main tumhin phut ukFk lqHkkmQ" (I will not go, I am firm), her trembling voice and subsequent actions reveal she is already surrendering — her words deny what her heart affirms. A wrong answer would simply quote a line without explaining the contradiction, showing the student confuses irony with mere strong emotion or hyperbole.

## DIAGNOSTIC_QUESTION_2
Explain in your own words how the flute (baansuri) functions as a symbol in both the poem and the prose piece. What abstract ideas does it carry beyond being a musical instrument?

## DIAGNOSTIC_ANSWER_2
The flute symbolizes Krishna's divine call that pulls the devotee beyond worldly duties, the sweetness of spiritual attraction that disrupts ordinary life, and the paradox of a simple hollow reed producing music that governs hearts — representing how emptiness (ego-surrender) becomes a vessel for the divine. A wrong answer would list physical attributes (made of bamboo, has holes) or treat it only as a plot device, missing the layered abstraction that distinguishes symbolism from literal description.

## DIAGNOSTIC_QUESTION_3
Apply the concept of situational irony to the moment in the prose when Hajir's mother (Daksha) tries to protect her from Krishna's influence but inadvertently pushes her closer to him. Trace the cause-effect chain in 3-4 steps.

## DIAGNOSTIC_ANSWER_3
Step 1: Daksha fears Krishna's pull and imposes strict restrictions. Step 2: Restrictions create resentment and curiosity in Hajir. Step 3: Hajir seeks the forbidden — the forest, the flute, the stories — precisely because they are forbidden. Step 4: The protection becomes the catalyst for deeper attachment. A wrong answer would describe the plot without naming the irony type or would confuse it with dramatic irony (where the audience knows more), revealing confusion between irony categories.

## DIAGNOSTIC_QUESTION_4
Analyze how the forest (van) operates as a polyvalent symbol across the two texts. Compare its symbolic weight in the poem versus the prose.

## DIAGNOSTIC_ANSWER_4
In the poem, the forest is primarily a symbolic space of *viraha* (separation) and *milana* (union) — a psychological landscape where the devotee meets the divine in absence. In the prose, the forest is also a social boundary: crossing it means defying maternal authority and village norms, so it symbolizes the threshold between conventional duty (dharma as social order) and devotional duty (dharma as love). A weak answer would treat the forest as mere setting in both, missing the shift from internal to external conflict and the different thematic loads the same symbol carries in different genres.

## DIAGNOSTIC_QUESTION_5
Evaluate the effectiveness of dramatic irony in the prose scene where the villagers gossip about Hajir's "madness" while the reader knows she is experiencing *bhakti-avesh* (divine possession). Does this device deepen the theme or create mockery? Justify.

## DIAGNOSTIC_ANSWER_5
It deepens the theme: the gap between the villagers' clinical label ("madness") and the reader's spiritual insight ("bhakti") mirrors the central tension of the chapter — worldly eyes see deviation, devotional eyes see union. The irony invites the reader into the privileged position of the devotee, aligning us with Hajir's inner truth. A wrong answer would say "it creates sympathy" without linking to the theme of *laukik vs. alaukik drishti* (worldly vs. divine vision), or worse, claim it mocks her, showing failure to distinguish authorial intent from character perspective.

## DIAGNOSTIC_QUESTION_6
Create a four-line stanza in Hindi (or Hindi-English mix) that uses verbal irony to express a devotee's denial of love for the divine while the imagery reveals surrender. Include at least one symbol from the chapter (flute, peacock feather, forest, river Yamuna).

## DIAGNOSTIC_ANSWER_6
Example: "Main baansuri ki dhun sun ke bhi anjaan bani / Mor pankh haath mein le ke bhi 'nahin' keh di / Yamuna kinare paon pade to man mandir bana / Ban mein jaake bhi main 'ghar' wapas aa gayi." A poor answer would write a straightforward devotional verse without irony (no contradiction between words and imagery) or would use the symbol decoratively without symbolic weight, showing the student cannot operationalize the devices creatively.

## COMMON_MISCONCEPTION
Students consistently confuse *situational irony* with *bad luck* or *coincidence* (e.g., "It's ironic that it rained on her wedding day" — no, that's just unfortunate). In this chapter, they label Hajir's mother's protective backfire as "sad" or "unexpected" rather than recognizing the structural reversal where the preventive action causes the feared outcome. They also reduce symbolism to "metaphor with an object" — e.g., writing "the flute is a metaphor for Krishna's love" — missing that a symbol *is* the object itself charged with meaning, not a comparison. This error stems from Class 10-11 teaching that often treats symbolism as a sub-type of metaphor rather than an independent mode of signification where the literal object remains fully present while simultaneously pointing beyond itself.

## ON_FAILURE
If a student cannot distinguish irony types or reduces symbols to metaphors: 1) Have them create a three-column table: Column A = literal event/word, Column B = expected meaning, Column C = actual/ironic meaning — fill for 5 moments from the texts. 2) For symbolism, use the "onion peel" exercise: take the peacock feather — Layer 1 (physical): feather with eye-pattern; Layer 2 (contextual): Krishna wears it; Layer 3 (thematic): beauty, grace, all-seeing witness; Layer 4 (philosophical): the eye that sees the devotee's heart. 3) Re-attempt Diagnostic Questions 3 and 4 after this. If still stuck, revisit c11_hin_ar_cbse_01_009 (Class 11 Irony and Symbolism) for foundational definitions.

## BUILDS_ON
c12_hin_a_cbse_06_008 (Literary Devices: Imagery and Metaphor) — because understanding how concrete images carry abstract weight (metaphor) is the gateway to grasping how symbols *are* the image itself charged with meaning, and how irony often works through imagery that says one thing while the context shows another.

## LEADS_TO
c12_hin_a_cbse_06_012 (Comprehension: Literal and Inferential Questions) and c12_hin_a_cbse_06_013 (Critical Thinking: Analysis and Interpretation) — because mastery of irony and symbolism is essential for answering inferential questions (which often hinge on gaps between stated and implied) and for critical essays that require unpacking layered textual strategies.

## PREREQUISITE_NODE_IDS
c12_hin_a_cbse_06_008, c11_hin_ar_cbse_01_009, c11_hin_v_cbse_01_009, c12_hin_a_cbse_06_001, c12_hin_a_cbse_06_003, c12_hin_a_cbse_06_007

## PREREQUISITE_REASONS
c12_hin_a_cbse_06_008: Imagery and Metaphor provides the foundation of concrete-to-abstract transfer that symbolism extends and irony subverts.
c11_hin_ar_cbse_01_009: Class 11 Antra Chapter 1 introduced irony and symbolism definitions and basic identification; this node deepens to multi-text analysis and board-style answer writing.
c11_hin_v_cbse_01_009: Class 11 Vitan Chapter 1 reinforced the same devices in a different textual context (memoir/essay), giving cross-genre exposure before Class 12 synthesis.
c12_hin_a_cbse_06_001: Irony/symbolism (Muslim poet singing Hindu bhakti) is contextual.  
c12_hin_a_cbse_06_003: Irony/symbolism (e.g., Muslim poet in Hindu sacred space) rooted in setting tension  
c12_hin_a_cbse_06_007: Irony and symbolism deepen secondary themes (e.g., Krishna bound by love = irony of Infinite bound by finite).  

## FORWARD_NODE_IDS
c12_hin_a_cbse_06_010, c12_hin_a_cbse_06_012, c12_hin_a_cbse_06_013, c12_hin_a_cbse_06_015

## FORWARD_REASONS
c12_hin_a_cbse_06_010: Vocabulary in Context requires recognizing when words are used ironically or symbolically (e.g., "pagal" meaning both "mad" and "divinely intoxicated").
c12_hin_a_cbse_06_012: Inferential comprehension questions frequently test the gap between literal and ironic meaning or the symbolic implication of a detail.
c12_hin_a_cbse_06_013: Critical analysis essays demand explicit discussion of how irony and symbolism construct the chapter's philosophical argument about bhakti.
c12_hin_a_cbse_06_015: विडंबना/प्रतीक (हजारी=समावेशिता) समझने पर ही गहरी चर्चा हो सकती है।  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
c12_english_literary_devices: The definitions and analytical frameworks for irony (verbal/situational/dramatic) and symbolism (conventional vs. contextual) are identical across Hindi and English literature; skills transfer directly.
c12_sociology_cultural_symbolism: The peacock feather, flute, and forest are not just literary symbols but culturally encoded symbols in Indian tradition (Krishna iconography, vanaprastha symbolism); sociology provides the cultural semiotic background that enriches literary reading.

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_01_009 -> c12_hin_a_cbse_06_008 -> c12_hin_a_cbse_06_009 -> c12_hin_a_cbse_06_012

## THIS_FORMULA
N/A - conceptual

## FORMULA_VARIABLES
N/A

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
conceptual

## CROSS_SUBJECT
N/A | Shared analytical terminology and PEEL answer structure for literary device analysis across Hindi and English board exams.
 N/A | The symbols in this chapter (flute, peacock feather, forest, Yamuna) are culturally saturated signs in Indian society; sociological understanding of their conventional meanings deepens literary interpretation beyond textual internal evidence.
## PREREQ_CONCEPT
The student must understand that a literary symbol retains its literal existence while simultaneously signifying abstract concepts, unlike a metaphor which is a comparison between two distinct things.

## PREREQ_BEFORE
Before starting this node, the student should be able to identify at least three metaphors in the Chapter 6 poem and explain the tenor-vehicle relationship in each (from node c12_hin_a_cbse_06_008).

## PREREQ_STUCK
If stuck, review the "tenor-vehicle" distinction in metaphors (c12_hin_a_cbse_06_008) and practice converting a metaphor into a symbol by keeping the vehicle as a physical presence in the text while expanding its referential range.

## WORKED_EXAMPLE_1
PROBLEM: Analyze the irony in the poem's opening stanza where Hajir claims indifference to Krishna's call but describes the call's effect on her body in vivid sensory detail.
STEPS:
- Step 1: Identify the literal claim — Hajir says "I do not listen / I do not go" (verbal denial).
- Step 2: Identify the contradictory evidence in the same stanza — "ears burn", "heart dances", "breath stops" (physiological surrender).
- Step 3: Classify the irony type — this is verbal irony (words say no, body says yes) layered with dramatic irony (Krishna knows, we know, but Hajir performs denial for herself/her mother).
- Step 4: Explain the thematic function — the irony enacts the core conflict of *prem-bhakti*: the ego's resistance versus the soul's recognition; the gap *is* the devotional tension.
- Step 5: Connect to board answer format — Point: The poem opens with verbal irony. Evidence: Quote "ears burn/heart dances". Explanation: Body betrays speech. Link: This pattern structures the entire poem — each denial deepens the proof of love.
REASONING: This 5-step method moves from textual evidence to device classification to thematic integration — exactly what CBSE 3-4 mark questions require. It prevents the common error of just naming "irony" without showing *how* it works in the specific lines.
ANSWER: The stanza uses verbal irony where Hajir's spoken refusal ("Main tumhin phut ukFk lqHkkmQ") is contradicted by her involuntary physiological responses ("ekj vHkkx mnf/ voxkgw", "tkfjm¡ tk;¡ tufu dfg dkowQ"). The irony is not decorative — it establishes the poem's central dialectic: the finite ego's attempt to deny the infinite call, and the body's truth-telling that the mouth cannot suppress. A full-mark answer would name the irony type, quote the contrasting lines, and link to the theme of *bhakti* as surrender beyond will.

## WORKED_EXAMPLE_2
PROBLEM: Trace the peacock feather (mor pankh) as a symbol across three moments in the chapter: (a) Krishna wearing it in the poem's description, (b) Hajir holding it in the prose, (c) the villagers seeing it in her hand.
STEPS:
- Step 1: List the three moments with their immediate contexts — (a) divine adornment, (b) devotional relic, (c) social evidence of madness.
- Step 2: For each, state the literal object (feather with eye-pattern) and the abstract idea it carries — (a) divine beauty & all-seeing grace, (b) tangible connection to the absent beloved, (c) proof of transgression.
- Step 3: Analyze how the *same physical object* acquires different symbolic valences in different perspectives — divine vs. devotee vs. society.
- Step 4: Synthesize — the feather becomes a symbol of the *gap* between divine intention (grace), devotee reception (love), and social perception (deviance). This gap *is* the chapter's thematic field.
- Step 5: Draft a PEEL paragraph for a 5-mark question — Point: The mor pankh is a polyvalent symbol. Evidence: In poem it crowns Krishna; in prose Hajir clutches it; villagers point to it. Explanation: Each holder reads it differently — grace, anchor, madness. Link: The symbol exposes the chapter's central tension: bhakti rewrites social reality.
REASONING: Symbolism questions in boards often ask "Discuss the significance of X" — requiring the student to show how one object generates multiple meanings across contexts. This worked example models the multi-perspective tracking that a single-text analysis would miss.
ANSWER: The peacock feather functions as a contextual symbol whose meaning shifts with the perceiver: on Krishna it signifies *saundarya* (beauty) and *sarvajnatva* (omniscience — the eye that sees all); in Hajir's hand it becomes *smriti* (memory) and *sambandh* (connection) — a physical anchor for the absent divine; to villagers it reads as *pagalpan* (madness) — a material proof of her social breakdown. The symbol thus condenses the chapter's triad: God, devotee, society. A high-scoring answer maps this triad explicitly and notes that the feather never loses its physical identity — it remains a feather throughout — which is why it is symbolism, not metaphor.

## WORKED_EXAMPLE_3
PROBLEM: Compare the use of situational irony in the prose (Daksha's protection backfires) with the dramatic irony in the poem (Krishna/Hajir know the truth of her love while she performs denial). How do the two irony types serve different narrative functions?
STEPS:
- Step 1: Define each irony type precisely for this context — situational: outcome opposes intention; dramatic: audience knows more than character(s).
- Step 2: Map the prose instance — Daksha intends protection → outcome: deeper attachment. Identify the agent (Daksha) and the victim of irony (Daksha's plan).
- Step 3: Map the poem instance — Hajir performs denial → Krishna knows, reader knows, but Hajir *also* knows at a deeper level (self-deception). The audience is aligned with the divine perspective.
- Step 4: Contrast narrative functions — Prose irony drives plot (causes Hajir's forest journeys); Poem irony deepens lyric interiority (enacts the devotee's inner conflict).
- Step 5: Evaluate which is more central to the chapter's theme — Both essential: prose irony shows bhakti's social disruption; poem irony shows bhakti's psychological structure.
- Step 6: Write a comparative thesis statement for a 6-mark question — "While situational irony in the prose externalizes bhakti as social transgression, dramatic irony in the poem internalizes it as the soul's dialogue with the divine; together they present bhakti as both world-shattering and world-creating."
REASONING: Competitive exams (CUET, IPMAT) and board competency questions increasingly ask for cross-textual comparison of literary techniques. This example models the analytical move from device identification to functional comparison to thematic synthesis — the full arc of a high-order response.
ANSWER: Situational irony in the prose (Daksha's restrictions → Hajir's rebellion) operates at the level of *plot causality* and *social consequence* — it shows how bhakti disrupts familial and village order. Dramatic irony in the poem (Hajir's denial vs. reader's/Krishna's knowledge) operates at the level of *psychological truth* and *aesthetic tension* — it lets us inhabit the devotee's split consciousness. The former is irony of *event*; the latter is irony of *awareness*. A sophisticated answer notes that the poem's dramatic irony is unusual because Hajir is not fully deceived — she is performing denial *for* her mother/society while her inner self knows — making it a triple-layered irony: verbal (words vs. heart), dramatic (performance vs. audience knowledge), and situational (denial deepens love). This complexity is exactly what distinguishes Class 12 analysis from Class 11.

## COMPETENCY_QUESTION_1
QUESTION: In the prose piece, Hajir's mother says, "I tied the amulet so Krishna's spell would break." Later, Hajir touches the amulet and feels Krishna's presence more intensely. Identify the irony type, explain its mechanism in 3 steps, and state what thematic truth about *bhakti* this irony reveals. Write your answer in the PEEL format.
COMPETENCY: Literary Analysis — Irony Identification and Thematic Linkage
STEPS:
- Step 1: Name the irony type (situational) and define it in this context.
- Step 2: Trace the 3-step mechanism: intention → action → opposite outcome.
- Step 3: Extract the thematic truth: bhakti cannot be blocked by material means; protection becomes provocation.
- Step 4: Assemble into PEEL: Point, Evidence (quote/paraphrase), Explanation (mechanism), Link (theme).
ANSWER: Point: The amulet episode employs situational irony to reveal bhakti's invulnerability to ritual manipulation. Evidence: Daksha ties the amulet "taaki Krishna ka jadoo toot jaye" (so Krishna's spell breaks), but Hajir finds "amulet chhune par Krishna ka ehsaas aur gehra hua" (touching the amulet deepened Krishna's presence). Explanation: The protective object becomes a conduit for the very presence it was meant to repel — the mother's love, expressed through fear, inadvertently fuels the daughter's devotion. Link: This irony enacts the chapter's core philosophical claim: *prem* (love) operates by a logic that inverts worldly causality — resistance becomes participation, barriers become bridges. The amulet, meant to bind Hajir to social dharma, binds her instead to divine lila.
DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: The river Yamuna appears in the poem as a physical setting and in the prose as a remembered boundary. Construct an argument that the Yamuna functions as a *threshold symbol* (liminal space) between three pairs of opposites: (1) village/forest, (2) mother/daughter, (3) worldly duty/divine love. Support each pairing with one textual detail (do not quote full lines; describe the moment). Conclude with one sentence on how this symbolic density elevates the chapter beyond a simple love story.
COMPETENCY: Symbolic Analysis — Multi-layered Symbol Tracking and Thematic Synthesis
STEPS:
- Step 1: Define threshold/liminal symbol in your own words.
- Step 2: For each of the three pairs, identify a specific moment where the Yamuna marks the transition.
- Step 3: Explain how the *same* river serves all three symbolic boundaries simultaneously.
- Step 4: Draft the concluding synthesis sentence.
- Step 5: Check that each textual detail is from a different scene (poem vs. prose) to show cross-textual range.
ANSWER: A threshold symbol is a physical locus that marks passage between states of being. (1) Village/forest: In the prose, Hajir crosses the Yamuna at midnight to reach the forest — the river is the legal and moral boundary between Daksha's jurisdiction and Krishna's domain. (2) Mother/daughter: In the poem, Hajir recalls "Yamuna kinare paon pade to man mandir bana" (feet touched Yamuna's bank, heart became temple) — the riverbank is where maternal voice fades and divine voice rises. (3) Worldly duty/divine love: In the prose climax, Daksha stands on one bank calling Hajir back to *grihastha dharma*; Hajir stands mid-stream answering *prem dharma* — the water itself becomes the contested space. The Yamuna's symbolic density elevates the chapter because it refuses to reduce bhakti to either social rebellion or private ecstasy; the river holds both, showing that true devotion *is* the dangerous crossing where all identities dissolve and reform.
DIFFICULTY: hard