## DEFINITION
Critical Thinking: Analysis and Interpretation is the disciplined process of examining a literary text beyond its surface meaning to uncover underlying themes, evaluate the author's stylistic choices, and construct an independent, evidence-based judgment about the text's significance and artistry.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student can independently select a stanza from Raidas's poetry, identify at least two literary devices, explain their combined effect on the poem's central theme of social equality and devotion, and articulate a coherent critical response structured with a clear claim, textual evidence, and analytical reasoning.

## SCOPE_BOUNDARY
This node covers critical analysis and interpretation of Raidas's poetry in Chapter 10 (Aroh), focusing on thematic depth, metaphorical complexity, symbolism, and socio-historical context. It does NOT cover basic comprehension, vocabulary, grammar, or identification of literary devices in isolation, which are addressed in prerequisite nodes.

## WALKTHROUGH
Imagine you are reading Raidas's poem and feel the words are beautiful but you cannot explain *why* they move you or what they truly say about society. Begin by reading the poem aloud to hear its rhythm. Next, mark every image that surprises you — like a "lake of love" or a "boat drifting from shore." Then, connect each image to the poet's life as a leather-worker saint challenging caste hierarchy. Ask: "What social reality is this metaphor hiding or revealing?" Finally, write a response that states your insight, quotes the specific lines, explains the metaphor's double meaning, and links it to the Bhakti movement's radical equality. The key insight is that Raidas uses devotional language to dismantle social barriers — the poem is both a prayer and a protest.

## DIAGNOSTIC_QUESTION_1
What is the primary difference between *literal comprehension* and *critical interpretation* of a literary text?

## DIAGNOSTIC_ANSWER_1
Literal comprehension retrieves facts explicitly stated in the text (who, what, where), while critical interpretation examines implicit meanings, authorial intent, stylistic choices, and socio-cultural context to form an evaluative judgment. A wrong answer that equates interpretation with "personal opinion" reveals the misconception that analysis is subjective rather than evidence-based.

## DIAGNOSTIC_QUESTION_2
In Raidas's poem, the line "valqou ty lhafp&lhafp] izse&csfy cks;h" (lake of love, shade of devotion) appears. Explain in your own words what this metaphor suggests about the nature of divine love, and why the poet might choose a *lake* and *shade* specifically.

## DIAGNOSTIC_ANSWER_2
The metaphor portrays divine love as a sustaining, cooling, and immersive refuge — a lake quenches thirst and shade protects from heat, implying God's love fulfills spiritual longing and shields from worldly suffering. Raidas, a leather-worker exposed to scorching sun and social heat, chooses these images from his lived labor experience. A wrong answer that only defines "metaphor" without connecting the imagery to the poet's caste identity misses the socio-contextual layer essential for Class 11 analysis.

## DIAGNOSTIC_QUESTION_3
Apply the concept of *irony* to the following situation from the poem: The poet describes himself as "nkfl ehjka yky fxjèkj" (O Raidas, servant of your city) while addressing God as the ruler of the city. Identify the irony and explain how it subverts the feudal hierarchy of 15th-century India.

## DIAGNOSTIC_ANSWER_3
The irony lies in a low-caste poet claiming the status of a "servant" to the Divine King, thereby rejecting the authority of human kings and upper-caste elites who considered him untouchable. By making God the only true ruler, Raidas renders earthly hierarchy illegitimate. A wrong answer that merely defines irony as "contrast" without linking it to the specific power dynamics of medieval India fails to apply the concept analytically.

## DIAGNOSTIC_QUESTION_4
Compare the use of *water imagery* in the first stanza ("izse dh xr izse tk.kS") and the second stanza ("valqou ty"). Analyze how the meaning of water shifts from a *force of dissolution* to a *source of sustenance*, and what this shift reveals about the poet's spiritual journey.

## DIAGNOSTIC_ANSWER_4
In stanza one, water (rain/river) dissolves the ego ("izse dh xr izse tk.kS" — the flow of love is the flow of love), suggesting surrender. In stanza two, water becomes a "lake of love" offering shade and rest, indicating attained peace. The shift mirrors the Bhakti path: from turbulent longing to stable union. A wrong answer that treats both images as identical "water symbols" misses the developmental arc crucial for interpretation.

## DIAGNOSTIC_QUESTION_5
Evaluate the claim: "Raidas's poetry is primarily devotional; its social critique is merely a by-product." Defend or refute using at least two specific textual strategies from the poem.

## DIAGNOSTIC_ANSWER_5
Refute. The poem fuses devotion and critique inseparably: (1) The metaphor "nwèk dh eFkfu;k¡ cM+s izse ls foyks;h" (boat of life drifting from shore of love) equates spiritual deviation with social alienation — the "shore" is both God and just society. (2) Addressing God as "fxjèkj" (city-ruler) directly challenges the Mughal/Rajput sovereigns who upheld caste law. A wrong answer that agrees with the claim overlooks how Bhakti poets used devotional vocabulary as a coded language of resistance.

## DIAGNOSTIC_QUESTION_6
Create a four-line stanza in the style of Raidas that uses a *labor metaphor* (e.g., leather-work, weaving, farming) to express the idea that "true devotion erases caste distinctions." Write in Hindi (Devanagari or transliteration) and explain your metaphor in one sentence.

## DIAGNOSTIC_ANSWER_6
Example: "कामड़ चामड़ सिलत रह्यो, राम नाम क धागा / जात-पात क काट दियो, भक्ति ने लागा" (Stitching leather with thread of Ram's name / Bhakti cut through caste divisions). The metaphor maps the poet's actual craft (stitching leather) onto spiritual practice, showing how devotional labor transforms the stigma of his caste into sacred art. A poor answer uses a generic metaphor (like "light/darkness") unrelated to Raidas's specific labor identity, showing inability to synthesize form and content.

## COMMON_MISCONCEPTION
Students often believe "critical interpretation" means expressing any personal feeling about the poem, or they think identifying a metaphor (e.g., "lake = love") is the end of analysis. They miss that Class 11 requires explaining *why that specific metaphor matters in this specific poet's mouth* — e.g., Raidas chooses a *lake* not a *river* because a lake is still, accessible to all, and reflects the sky (God) without flowing away, mirroring his vision of a casteless society where everyone drinks equally. This error stems from treating literary devices as decorations rather than arguments.

## ON_FAILURE
1. Give the student a scaffolded template: "Raidas uses [device] in line [X] to compare [A] to [B]. This is significant because Raidas was a [caste/occupation], so [A] represents [lived experience]. By linking it to [B], he argues that [theme]." 2. Practice with one stanza: have them fill the template for the "boat" metaphor. 3. Ask them to swap the metaphor (e.g., "mountain of love") and explain how the meaning changes. 4. Finally, have them write a 100-word analysis using the template as paragraph structure.

## BUILDS_ON
Literal and inferential comprehension (node c11_hin_ar_cbse_10_012) and identification of literary devices (nodes c11_hin_ar_cbse_10_008, c11_hin_ar_cbse_10_009).

## LEADS_TO
Structured analytical writing (node c11_hin_ar_cbse_10_014) and evidence-based discussion (node c11_hin_ar_cbse_10_015).

## PREREQUISITE_NODE_IDS
c11_hin_ar_cbse_10_001, c11_hin_ar_cbse_10_002, c11_hin_ar_cbse_10_003, c11_hin_ar_cbse_10_004, c11_hin_ar_cbse_10_005, c11_hin_ar_cbse_10_006, c11_hin_ar_cbse_10_007, c11_hin_ar_cbse_10_008, c11_hin_ar_cbse_10_009, c11_hin_ar_cbse_10_010, c11_hin_ar_cbse_10_011, c11_hin_ar_cbse_10_012
## PREREQUISITE_REASONS
c11_hin_ar_cbse_10_001: Provides historical context of Bhakti movement and Raidas's caste identity essential for interpretation.
c11_hin_ar_cbse_10_002: Narrative structure understanding helps locate where key metaphors appear in the poem's progression.
c11_hin_ar_cbse_10_003: Setting/atmosphere analysis reveals the socio-physical world shaping the poet's imagery.
c11_hin_ar_cbse_10_004: Protagonist analysis gives insight into Raidas's voice as a speaker.
c11_hin_ar_cbse_10_005: Supporting characters (God, society) define the conflict.
c11_hin_ar_cbse_10_006: Primary theme (equality in devotion) is the anchor for all interpretation.
c11_hin_ar_cbse_10_007: Secondary themes (labor, knowledge, love) enrich critical reading.
c11_hin_ar_cbse_10_008: Imagery and metaphor identification is the raw material for analysis.
c11_hin_ar_cbse_10_009: Irony and symbolism detection enables deeper critique.
c11_hin_ar_cbse_10_010: Vocabulary in context clarifies nuanced word choices (e.g., "fxjèkj").
c11_hin_ar_cbse_10_011: Grammar/usage shows how linguistic forms carry meaning.
c11_hin_ar_cbse_10_012: Literal/inferential comprehension is the foundation — you cannot analyze what you do not understand.

## FORWARD_NODE_IDS
c11_hin_ar_cbse_10_014, c11_hin_ar_cbse_10_015, c12_hin_al_cbse_02_013, c12_hin_ar_cbse_03_013

## FORWARD_REASONS
c11_hin_ar_cbse_10_014: Writing skills require the analytical claims and evidence structures developed here.
c11_hin_ar_cbse_10_015: Speaking/listening discussions need interpreted insights to debate, not just summarize.
c12_hin_al_cbse_02_013: Compared two narrative perspectives in a single text.  
c12_hin_ar_cbse_03_013: अगला तार्किक चरण: Critical Thinking: इस नोड की अवधारणाओं को सीधे उपयोग/विस्तारित करता है।  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
No prior class nodes available for cross-subject linking in this chapter.

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_10_012 -> c11_hin_ar_cbse_10_013 -> c11_hin_ar_cbse_10_014

## THIS_FORMULA
N/A - conceptual

## FORMULA_VARIABLES
N/A

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
analytical

## CROSS_SUBJECT
c11_history_medieval_bhakti_movement | Raidas's poetry is a primary source for understanding how Bhakti saints used devotional language to challenge caste hierarchy and royal authority in 15th-century North India.
c11_sociology_social_stratification | The poem's metaphors (lake, shore, boat) encode a sociological critique of purity-pollution norms; analyzing them applies sociological concepts of hierarchy, resistance, and symbolic capital.

## PREREQ_CONCEPT
Ability to move from "what the text says" to "what the text does" by linking literary form to historical context.

## PREREQ_BEFORE
Student must have completed nodes on comprehension, themes, and literary devices for this chapter.

## PREREQ_STUCK
Review the metaphor and symbolism nodes (c11_hin_ar_cbse_10_008, c11_hin_ar_cbse_10_009) with focus on Raidas's labor-specific imagery.

## WORKED_EXAMPLE_1
PROBLEM: Analyze the metaphor "valqou ty lhafp&lhafp] izse&csfy cks;h" (lake of love, shade of devotion) in the second stanza. Explain how this metaphor functions at three levels: literal, devotional, and socio-political.

STEPS:
- Step 1: Identify the given metaphor and its literal components — "lake" (body of water), "shade" (shelter from sun), "love" and "devotion" as abstract qualities made concrete.
- Step 2: Recall the poet's identity — Raidas, a chamar (leather-worker) who worked outdoors in heat, handling dead animals, considered polluted.
- Step 3: Analyze the devotional level — the lake represents God's grace as immersive (you bathe in it) and the shade as protection (you sit under it), both freely available to anyone who approaches.
- Step 4: Analyze the socio-political level — upper castes controlled wells and temples (sources of water and shade). By making God a "lake of love" accessible to all, Raidas declares divine resources are not caste-monopolized.
- Step 5: Synthesize — the metaphor simultaneously expresses spiritual longing, asserts the devotee's right to divine grace, and indicts a society that denies physical water/shade to lower castes.
- Step 6: Verify with textual consistency — the next line "vc r csfy iSQfy xbZ] vk.kan&iQy gks;h" (then the shade became cool, the heat became bearable) confirms the transformative power of this grace.

REASONING: This step-by-step movement from textual detail to biographical context to multi-layered meaning models the analytical depth expected in board exams. Each level builds on the previous, preventing superficial "metaphor spotting."

ANSWER: The metaphor "lake of love, shade of devotion" operates as a triple-coded argument: literally, it describes physical relief from heat; devotionally, it portrays God's grace as universally accessible sustenance; politically, it subverts caste control over natural resources by declaring the Divine as the true, egalitarian provider. Raidas transforms his occupational suffering into theological authority.

## WORKED_EXAMPLE_2
PROBLEM: Interpret the line "nwèk dh eFkfu;k¡ cM+s izse ls foyks;h" (the boat of life drifts away from the shore of love). Explain how the "boat" and "shore" metaphors encode a warning about both spiritual and social alienation.

STEPS:
- Step 1: Parse the imagery — "boat of life" (nwèk dh eFkfu;k¡) = human existence; "shore of love" (cM+s izse) = grounding in divine connection; "drifts away" (foyks;h) = passive loss of mooring.
- Step 2: Identify the literary device — extended metaphor (life as journey, love as anchor). Note the passive verb "foyks;h" implying drifting is unintentional, a gradual neglect.
- Step 3: Connect to Bhakti theology — the shore is *nam-simran* (remembrance of God); drifting is *maya* (worldly distraction). The boat has no oar — only grace can return it.
- Step 4: Connect to Raidas's social reality — the "shore" also represents the community of saints (sangat) that transcends caste. Drifting away means falling back into caste identity, ritualism, or ego.
- Step 5: Analyze the warning's urgency — the next lines "nfèk efFk ?k`r dkf<+ fy;ks] Mkfj n;h Nks;h" (write the account of the soul's deeds, the final moment is near) introduce mortality. The metaphor is not decorative; it is a call to immediate re-anchoring.
- Step 6: Evaluate the metaphor's effectiveness — a boat without a shore is helpless, just as a human without divine love is subject to social oppression. The image works because both boat and shore are familiar to riverine North Indian life.

REASONING: This example demonstrates how a single metaphor can carry theological, ethical, and sociological weight simultaneously. The steps enforce close reading (verb choice), contextual knowledge (Bhakti concepts), and synthesis.

ANSWER: The boat/shore metaphor warns that spiritual neglect (drifting from God's remembrance) and social conformity (returning to caste-bound identity) are the same motion. The passive "drifts" emphasizes how easily a leather-worker saint could be pulled back into the polluted identity society assigns him. Only active devotion — tying the boat to the shore of love — secures liberation.

## WORKED_EXAMPLE_3
PROBLEM: Critically examine how Raidas blends the language of *feudal loyalty* (servant-king, city-ruler) with *Bhakti surrender* to construct a counter-hegemonic identity in the closing address "nkfl ehjka yky fxjèkj! rkjks vc eksgh" (O Raidas, servant of your city! Now, what to do?).

STEPS:
- Step 1: Identify the key terms — "fxjèkj" (city-ruler/king), "yky" (your servant/subject), "ehjka" (of Raidas), "rkjks vc eksgh" (now what remains?).
- Step 2: Recognize the feudal register — in 15th-century Rajasthan, "fxjèkj" is the Maharana; "yky" is the loyal subject. Raidas adopts this political vocabulary.
- Step 3: Analyze the subversion — by addressing God as *the only* fxjèkj, Raidas rejects the Maharana's sovereignty over his identity. He becomes "yky" (servant) not to a human king but to the Divine, making caste-based servitude illegitimate.
- Step 4: Link to the poem's earlier imagery — the "lake of love" (God's resource) replaces the king's patronage; the "shade of devotion" replaces the palace shelter.
- Step 5: Interpret the final cry "rkjks vc eksgh" — not despair, but radical responsibility. Having declared God as King, the poet asks what action follows. The answer is implicit: live as a free citizen of God's city, not a subject of caste hierarchy.
- Step 6: Connect to historical outcome — this rhetorical strategy allowed Bhakti poets to speak truth to power using the power's own language, creating a "hidden transcript" of resistance.

REASONING: This worked example combines literary analysis (register, address), historical knowledge (feudal terminology), and critical theory (counter-hegemony, hidden transcript) — exactly the multi-concept synthesis Class 11 board exams demand.

ANSWER: Raidas's closing address performs a political theology: he hijacks the feudal oath of loyalty ("I am your servant, O King") and redirects it to God, thereby declaring independence from human hierarchy. The phrase "fxjèkj" (city-ruler) transforms the poem into a charter of spiritual citizenship where caste has no jurisdiction. The final question "now what to do?" challenges the listener to enact this freedom.

## COMPETENCY_QUESTION_1
QUESTION: The poem uses the repeated structure "X dh xr X tk.kS" (X's flow is X's flow) in the opening lines for "ehjk" (Raidas), "?kkby" (Krishna), and "tkSgj" (the saint). Analyze how this syntactic parallelism establishes a theological equality that undermines social hierarchy. Support your answer with reference to the poet's biography and the Bhakti concept of *nirguna* devotion.

COMPETENCY: Analytical reasoning with textual evidence and contextual synthesis

STEPS:
- Step 1: Quote the parallel structure and identify the three figures equated.
- Step 2: Explain the syntactic effect — identical grammar creates identical ontological status.
- Step 3: Connect to Raidas's biography — a leather-worker placed grammatically on par with Krishna and the generic saint.
- Step 4: Link to nirguna Bhakti — formless God erases distinctions between devotees.
- Step 5: Conclude how form enacts content — the sentence structure *is* the argument.

ANSWER: The parallelism "ehjk osQ in ehjk tk.kS / ?kkby dh xr ?kkbyh tk.kS / tkSgj dh xr tkSgjh tk.kS" uses identical syntax to assert that Raidas, Krishna, and any saint share the same essential nature — each is defined solely by their own "flow" (essence/voice), not by birth. For a chamar poet, this grammatical equality is a radical theological claim: in nirguna devotion, the devotee's voice *is* the divine voice. The structure itself performs the social leveling that the content preaches.

DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: "Raidas's poetry transforms the stigma of his caste labor into the very medium of his spiritual authority." Critically evaluate this statement by analyzing at least three specific metaphors from the poem that derive from leather-work, water-carrying, or outdoor labor, and explain how each metaphor revalues the associated labor.

COMPETENCY: Critical evaluation with multi-evidence synthesis and conceptual originality

STEPS:
- Step 1: Identify three labor-derived metaphors (e.g., "stitching" implicit in "inkoyh", "water-carrying" in "izse dh xr", "shade-seeking" in "lhafp&lhafp").
- Step 2: For each, state the literal labor activity and its stigmatized status (handling dead skin, fetching water for others, working in sun).
- Step 3: Explain the metaphorical transvaluation — how the poem turns the stigma into sacred skill (stitching = joining soul to God; water-carrying = channeling grace; shade-seeking = granting refuge).
- Step 4: Argue why this matters — the poet does not transcend his labor; he transfigures it, making the stigmatized body the site of revelation.
- Step 5: Conclude with the broader implication for Bhakti as a movement of labor dignity.

ANSWER: The statement is profoundly accurate. (1) "inkoyh" (composition/poetry) puns on leather-stitching — Raidas "stitches" verses as he stitched shoes, but now the product is immortal and worn by all castes. (2) "izse dh xr izse tk.kS" evokes the water-carrier's rhythmic gait — the despised labor of fetching water becomes the rhythm of divine love flowing equally to all. (3) "valqou ty lhafp&lhafp" reclaims the leather-worker's sun-exposure: the poet who once burned now offers shade. In each case, the metaphor does not escape labor; it reveals labor's hidden holiness, making the chamar's body a theological text.

DIFFICULTY: hard