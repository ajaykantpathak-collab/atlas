## DEFINITION
Literal comprehension questions require students to locate and recall information explicitly stated in the text (e.g., "What does the poet say about the bird?"). Inferential comprehension questions require students to draw logical conclusions by combining textual evidence with background knowledge, reading between the lines to grasp implied meaning (e.g., "Why does the poet call the bird a symbol of freedom?"). Both types demand evidence-based answers, but inferential questions test higher-order thinking by asking *why* or *how* based on textual clues.

## COGNITIVE_LEVEL
apply

## MASTERY_CRITERIA
The student can independently classify any question from the chapter as literal or inferential, locate precise textual evidence (stanza/line reference) for literal answers, and construct a logical inference chain (evidence → reasoning → conclusion) for inferential answers, writing a structured 3-4 sentence response that quotes or paraphrases the text.

## SCOPE_BOUNDARY
This node covers *only* the comprehension question types (literal vs. inferential) for the two poems by Kukuan in Chapter 9 (Antra). It does NOT cover critical appreciation, thematic essays, creative writing, or grammar rules — those are handled in sibling nodes 013, 014, 011 respectively.

## WALKTHROUGH
Imagine you are sitting in the exam hall and see Question 3: "Why does the poet say 'pkgr pyu ;s lanslks ys lqtku dks'?" Your heart races — is this a "find the line" question or a "think deeply" question? Start by reading the question stem carefully: words like *what, who, when, where* signal literal; words like *why, how, what does this suggest, explain* signal inferential. For literal, scan the poem for keywords (here: *pkgr, lanslks, lqtku*) and copy the exact context. For inferential, note the keywords, then ask: "What emotion, irony, or contrast does this line create *in the situation described in the stanza*?" Connect the image (bird flying away) to the poet's stated feeling (longing for the disciple). The key insight: **every inferential answer must begin with a literal anchor** — a concrete line you can point to.

## DIAGNOSTIC_QUESTION_1
Identify whether the following question is literal or inferential: "According to the first poem, what time of day is described in the opening stanza?" 

## DIAGNOSTIC_ANSWER_1
**Correct:** Literal. The question asks for a detail explicitly stated in the text (time of day).  
**Wrong answer reveals:** If a student says "inferential," they confuse *setting description* with *interpretation*. They likely think any "what" question about poetry is inferential because poems are "hard." Remind them: if the answer is directly written (e.g., "cgqr fnuku dks" = many days / long time), it is literal.

## DIAGNOSTIC_QUESTION_2
A student answers the textbook question "dfo us ^pkgr pyu ;s lanslks ys lqtku dks* D;ksa dgk gS?" with: "Because the bird flew away." Explain why this answer is incomplete for an inferential question.

## DIAGNOSTIC_ANSWER_2
**Correct explanation:** The question asks *why the poet says this* (the poet's intention/feeling), not *what happened*. The student gave a literal plot summary. A complete inferential answer must link the bird's departure to the poet's emotional state (longing, helplessness) using the stanza's contrast: the bird flies freely ("pkgr pyu") while the poet is bound ("lanslks").  
**Wrong answer reveals:** The student treats "why" as "what caused the event" rather than "what does the poet convey." They miss the shift from *event* to *authorial purpose*.

## DIAGNOSTIC_QUESTION_3
APPLY: The second poem contains the line "owQdHkjh ewdrk cqyk; vki cksfygSA" (You have filled the cup of sorrow with the poison of irony). Write a 3-step inference chain to answer: "What does this line suggest about the relationship between the speaker and the addressee?"

## DIAGNOSTIC_ANSWER_3
**Steps & Answer:**  
1. **Literal anchor:** The line uses metaphor — "owQdHkjh" (poison of irony) mixed in "ewdrk" (cup of sorrow).  
2. **Reasoning:** Poison in a cup implies deliberate harm; irony implies the addressee's words/actions contradict the speaker's expectations.  
3. **Conclusion:** The relationship is marked by betrayal or deep disappointment — the addressee has turned the speaker's grief into something toxic.  
**Wrong answer reveals:** If the student writes "they are sad," they stop at the literal word "sorrow" and ignore the metaphor's agency ("vki cksfyg" = *you* filled). They miss the *interpersonal* dimension.

## DIAGNOSTIC_QUESTION_4
ANALYZE: Compare the two textbook questions: (1) "dfo ekSu gksdj izsfedk osQ dkSu ls iz.k ikyu dks ns[kuk pkgrk gS?" and (2) "?kukuan dh jpukvksa dh Hkkf"kd fo'ks"krkvksa dks vius 'kCnksa esa fyf[k,A". Classify each and justify why the second cannot be answered by quoting a single line.

## DIAGNOSTIC_ANSWER_4
**Correct:** (1) Inferential — asks for the *specific quality* the poet wants to see, requiring synthesis across stanzas (the bird's fearlessness, freedom). (2) Analytical/Evaluative — asks for *characteristic features of all works*, needing generalization across poems.  
**Why second isn't single-line:** It demands a thematic synthesis (language style, recurring motifs like disciple, irony, musicality) that no single line contains.  
**Wrong answer reveals:** If a student says both are "long answer," they miss the cognitive leap: Q1 is *text-bound inference*; Q2 is *author-study synthesis*. They treat all "explain" questions as same difficulty.

## DIAGNOSTIC_QUESTION_5
EVALUATE: A student claims: "In the first poem, the line 'vc u f?kjr ?ku vkuan funku dks' is literal because it describes the poet's current action." Defend or refute this claim using the definition of literal comprehension.

## DIAGNOSTIC_ANSWER_5
**Refute.** The line means "Now I do not find the path to reach you" — it expresses an *internal state of helplessness*, not an observable action. Literal comprehension only covers what is *explicitly denoted* (e.g., "the bird flew"). The poet's inability to find a path is a metaphorical expression of emotional distance.  
**Wrong answer reveals:** The student equates "first-person statement" with "literal fact." They don't grasp that poetry often uses *figurative literal statements* — the words are literal, the meaning is inferential.

## DIAGNOSTIC_QUESTION_6
CREATE: Frame one literal and one inferential question *on the same stanza* (Stanza 1 of Poem 2) that a Class 12 examiner could ask. Ensure the inferential question cannot be answered by copying a phrase.

## DIAGNOSTIC_ANSWER_6
**Sample literal:** "What does the speaker ask the addressee in the first line of the second poem?" (Answer: "vkukdkuh vkjlh fugkfjcks djkSxs dkSykSa\" — Why do you create separation?)  
**Sample inferential:** "How does the rhetorical question in the opening line establish the tone of the entire poem?" (Answer: It sets a tone of accusation and bewilderment, implying the separation is unjustified and painful.)  
**Poor answer reveals:** If the inferential question is "Why is the speaker angry?", it's still too close to literal (anger is named in "vkukdkuh"). A good inferential question forces analysis of *technique* (rhetorical question, tone) not just *emotion*.

## COMMON_MISCONCEPTION
Students believe **inferential questions have "no right answer" — "it's just my opinion."** They write vague feelings ("I think the poet is sad") without textual anchors. In Class 12 board exams, inferential answers are marked on a **fixed rubric**: 1 mark for correct literal evidence, 1 mark for logical link, 1 mark for precise conclusion. Saying "the poet feels bad" gets 0/3 because "bad" is not in the text; "the poet feels helpless because the bird (his disciple) has flown away and he cannot follow" gets 3/3. The error stems from treating literature as subjective chat rather than evidence-based argument.

## ON_FAILURE
1. **Revisit the two poems** with a highlighter: mark every concrete noun/verb (bird, fly, cup, poison) in yellow — these are literal anchors.  
2. **Take one textbook inferential question** (e.g., Q2: "dfo ekSu gksdj..."). Write the answer in three columns: **Evidence (line)** → **Reasoning (what it implies)** → **Conclusion (answer)**.  
3. **Re-diagnostic:** Ask the student to convert a literal question ("What did the bird do?") into an inferential one ("What does the bird's action reveal about the poet's state?") and answer their own question using the 3-column method. If they skip the Evidence column, repeat step 2.

## BUILDS_ON
c12_hin_a_cbse_09_010 (Vocabulary in Context) and c12_hin_a_cbse_09_011 (Grammar: Language Usage) — because precise word meanings and grammatical structures (e.g., metaphor, rhetorical question) are the raw material for both literal and inferential comprehension.

## LEADS_TO
c12_hin_a_cbse_09_013 (Critical Thinking: Analysis and Interpretation) — where students move from *answering given questions* to *generating original interpretations* using the same evidence→reasoning→conclusion chain.

## PREREQUISITE_NODE_IDS
c12_hin_a_cbse_09_010, c12_hin_a_cbse_09_011, c11_hin_ar_cbse_01_012, c11_hin_ar_cbse_09_012, c12_hin_a_cbse_09_002, c12_hin_a_cbse_09_007

## PREREQUISITE_REASONS
c12_hin_a_cbse_09_010: Key vocabulary (owQdHkjh, iSt, cgjk;cs) must be understood to locate literal meaning.  
c12_hin_a_cbse_09_011: Grammatical forms (imperative, rhetorical question, metaphor) signal question type.  
c11_hin_ar_cbse_01_012: Class 11 foundation on literal/inferential distinction in a different text.  
c11_hin_ar_cbse_09_012: Same chapter in Class 11 (if covered) provides spiral reinforcement.
c12_hin_a_cbse_09_002: Comprehension questions require structural awareness to infer unstated events.  
c12_hin_a_cbse_09_007: Comprehension questions often ask to explain themes with textual evidence.  

## FORWARD_NODE_IDS
c12_hin_a_cbse_09_013, c12_hin_a_cbse_09_014, c12_hin_a_cbse_09_008, c12_hin_a_cbse_09_015

## FORWARD_REASONS
c12_hin_a_cbse_09_013: Critical thinking requires the evidence→reasoning chain mastered here.  
c12_hin_a_cbse_09_014: Writing skills (e.g., character sketch, theme essay) use the same structured answer format.
c12_hin_a_cbse_09_008: Comprehension (Literal/Inferential) ensures the student knows *what* is happening in the poem before analyzing *how* it is said.  
c12_hin_a_cbse_09_015: Literal/inferential comprehension skills transfer directly to listening to peers' claims and extracting their evidence.  

## CROSS_SUBJECT_PREREQS
c11_hin_ar_cbse_01_012, c11_hin_v_cbse_01_012
## CROSS_SUBJECT_REASONS
c11_hin_ar_cbse_01_012: Antra (prose/poetry) comprehension skills transfer across all Hindi Core chapters.  
c11_hin_v_cbse_01_012: Vitan (supplementary reader) uses identical question typology — practice there reinforces this node.

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_01_012 -> c12_hin_a_cbse_09_012 -> c12_hin_a_cbse_09_013

## THIS_FORMULA
N/A - conceptual

## FORMULA_VARIABLES
N/A

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
linguistic

## CROSS_SUBJECT
N/A | Both require distinguishing explicitly stated facts in a source (literal) from implied author bias/purpose (inferential).  
 N/A | Reading a data table: literal = "GDP grew 6%"; inferential = "Policy X likely caused growth because..." — same evidence→reasoning chain.
## PREREQ_CONCEPT
Ability to identify explicit textual details (who, what, where, when) and distinguish them from implied meanings (why, how, so what).

## PREREQ_BEFORE
Student must have read both poems at least twice and underlined unfamiliar words (resolved via node 010).

## PREREQ_STUCK
If stuck on "what counts as evidence," review **c12_hin_a_cbse_09_010** for word meanings and **c12_hin_a_cbse_09_011** for figures of speech — these are the building blocks of evidence.

## WORKED_EXAMPLE_1
PROBLEM: Answer the textbook inferential question: "dfo us fdl izdkj dh iqdkj ls ^dku [kksfy gS* dh ckr dgh gS?" (With what kind of anger does the poet say "teach a lesson"?)

STEPS:
- Step 1: Locate the phrase "dku [kksfy gS" in Poem 2, Stanza 2. It appears in the line: "dcgw¡ rkS esfj;S iqdkj dku [kksfy gSA"
- Step 2: Identify the literal context: The speaker challenges the addressee — "Sometime, sitting in the court of God, [you] will teach a lesson." The setting is divine judgment ("esfj;S" = in God's court).
- Step 3: Analyze the adjective/modifier for "iqdkj" (anger). The line does not use an explicit adjective; the *context* provides the quality: it is **eschatological anger** (anger awaiting divine justice), not immediate human rage. The phrase "dcgw¡ rkS" (sometime/then) implies deferred, inevitable justice.
- Step 4: Synthesize: The poet does not speak from petty anger but from a conviction that moral accountability exists beyond this world. The anger is **righteous, patient, and rooted in faith in ultimate justice**.
- Step 5: Verify against the poem's tone: The first stanza shows bewilderment ("vkukdkuh vkjlh..."), the second shifts to prophetic warning. The answer fits the trajectory.

REASONING: The question asks "fdl izdkj dh" (what kind of) — a classic inferential probe. The answer is not in any single word; it is built by combining the *setting* (God's court), the *timing* (dcgw¡), and the *act* (teaching a lesson). The 3-column method (Evidence → Reasoning → Conclusion) prevents the common error of quoting the line without interpreting it.

ANSWER: The poet speaks with **eschatological, righteous anger** — not immediate retaliation, but a calm certainty that divine justice will eventually hold the addressee accountable ("dcgw¡ rkS esfj;S iqdkj dku [kksfy gS"). This reflects the poet's spiritual worldview where moral order transcends human power.

## WORKED_EXAMPLE_2
PROBLEM: A board exam question: "How does the contrast between the bird's freedom and the poet's bondage in Poem 1, Stanza 2, develop the central theme of the poem?"

STEPS:
- Step 1: Identify the two contrasting elements in Stanza 2: Bird — "pkgr pyu ;s lanslks ys lqtku dks" (flies away, taking the disciple); Poet — implied stationary, left behind ("lanslks" = bound/tied).
- Step 2: Note the keyword "lanslks" (bondage/attachment) vs "pkgr pyu" (flying away/freedom). The poet *chooses* the word "lanslks" for himself, acknowledging his own attachment.
- Step 3: Connect to central theme (from node 006): The poem explores the **guru-shishya bond tested by separation and the guru's selfless love that lets go**. The contrast *is* the theme — love that binds (lanslks) yet releases (pkgr pyu).
- Step 4: Structure answer: (a) State contrast with line references. (b) Explain how the contrast *enacts* the theme (the bird's flight = disciple's independence; poet's stillness = guru's acceptance). (c) Conclude: The poet's willingness to stay bound ("lanslks") so the disciple can fly ("pkgr pyu") defines the nobility of the relationship.
- Step 5: Check marking scheme alignment: 1 mark for identifying contrast, 1 for linking to theme, 1 for thematic vocabulary (selfless love, separation).

REASONING: Board questions often ask "how does X develop theme?" — this requires *analyzing a literary device (contrast) in service of theme*. The steps force the student to move from device → effect → theme, not just list the device.

ANSWER: The contrast between the bird's flight ("pkgr pyu") and the poet's bondage ("lanslks") *enacts* the central theme of **selfless guru-shishya love**. The disciple (bird) gains freedom through the guru's sacrifice; the guru remains tethered by affection ("lanslks") yet blesses the departure. The contrast transforms separation from tragedy into spiritual fulfillment.

## WORKED_EXAMPLE_3
PROBLEM: Multi-concept question combining comprehension + literary device (from node 008/009): "Identify the metaphor in 'owQdHkjh ewdrk cqyk; vki cksfygSA' and explain how it deepens the inferential answer to 'What is the nature of the speaker's grief?'"

STEPS:
- Step 1: Identify metaphor: "owQdHkjh" (poison of irony) → tenor = the addressee's words/actions; vehicle = poison. "ewdrk" (cup) → tenor = the speaker's sorrow; vehicle = cup. Combined: The addressee has *poisoned the speaker's sorrow* with irony.
- Step 2: Literal anchor for grief: The speaker feels sorrow ("ewdrk") — explicit in the metaphor.
- Step 3: Inferential leap via metaphor: Poison *transforms* a substance. Irony (saying one thing, meaning another) turns pure grief into something toxic — **betrayal, bitterness, loss of trust**. The grief is no longer just sadness; it is *corrupted* by the addressee's duplicity.
- Step 4: Connect to "nature of grief": It is **active, relational, and aggravated by betrayal** — not passive mourning but a wound inflicted by a trusted person.
- Step 5: Verify with poem context: Stanza 1 asks "Why create separation?" (vkukdkuh vkjlh...). The irony: the addressee *chose* to separate, yet perhaps pretended otherwise. The metaphor captures this duality.
- Step 6: Final answer structure: Name metaphor → Explain tenor/vehicle → Show how metaphor *modifies* the literal emotion (sorrow → poisoned sorrow) → State inferred nature.

REASONING: This combines node 012 (inferential) with node 008/009 (metaphor/irony). The steps model how *literary devices are the machinery of inference* — they are not decoration; they create the meaning we infer.

ANSWER: The metaphor "owQdHkjh ewdrk" (cup of sorrow poisoned by irony) reveals the grief is **betrayal-laced**. Literal grief = sorrow (ewdrk). Metaphorical transformation = irony (owQdHkjh) acts as poison, converting sorrow into bitterness. The inferential answer: The speaker's grief is not mere sadness; it is the acute pain of realizing the addressee's words were hollow, turning trust into toxin.

## COMPETENCY_QUESTION_1
QUESTION: Read the following student answer to the textbook question "dfo ekSu gksdj izsfedk osQ dkSu ls iz.k ikyu dks ns[kuk pkgrk gS?" and improve it using the evidence→reasoning→conclusion structure.  
**Student answer:** "The poet wants to see the courage of his disciple because the bird flew away without fear."

COMPETENCY: **Structured Answer Writing (PEEL: Point, Evidence, Explanation, Link)**

STEPS:
- Step 1: Identify the Point missing — the answer states *what* (courage) but not *which specific courage* (fearlessness in face of unknown).
- Step 2: Add Evidence — quote the line showing the bird's fearlessness: "vèkj yxs gSa vkfu dfj oSQ i;ku izku" (They fly fearlessly, leaving the nest).
- Step 3: Add Explanation — connect "nest" (i;ku) to security, "flying" to embracing uncertainty. The disciple (bird) leaves the guru's shelter (nest).
- Step 4: Add Link — conclude: The poet seeks the quality of **fearless independence** (nirbhay swatantrata) in the disciple, mirroring the bird's flight.

ANSWER: **Improved answer:** The poet wishes to see **fearless independence** in his disciple. Evidence: The bird "vèkj yxs gSa vkfu dfj oSQ i;ku izku" (flies fearlessly, leaving the nest). Explanation: The nest represents the guru's protective shelter; flying away signifies embracing the unknown world without fear. Link: Thus, the poet values the disciple's courage to venture beyond the guru's shadow — a courage that is spiritual, not just physical.

DIFFICULTY: easy

## COMPETENCY_QUESTION_2
QUESTION: The CBSE 2023 Sample Paper includes a case-based comprehension passage from an unseen poem. You are given Stanza 1 of Poem 2 as the "case."  
**Case:** "vkukdkuh vkjlh fugkfjcks djkSxs dkSykSa\ dgk eks pfdr nlk R;ksa u nhfB MksfygS\"  
**Questions:**  
(a) Literal: What does "vkukdkuh" mean in context?  
(b) Inferential: Why does the speaker use a rhetorical question here instead of a direct accusation?  
(c) Analytical: How does the metaphor "fugkfjcks" (creating separation) characterize the *agency* of the addressee?  
Answer all three parts in 2-3 sentences each.

COMPETENCY: **Multi-level Question Handling (Literal + Inferential + Analytical in one set)**

STEPS:
- Step 1 (a): Literal — "vkukdkuh" = separation, parting (from vocabulary node 010). Answer directly.
- Step 2 (b): Inferential — Rhetorical question implies the answer is obvious/self-evident; it expresses *bewilderment* and *appeals to conscience* rather than attacking. It invites reflection, not defense.
- Step 3 (c): Analytical — "fugkfjcks" (causative verb: make/create separation) assigns *active agency* to the addressee. Separation is not mutual fate; it is *deliberately crafted* by the addressee. This characterizes the addressee as **responsible, perhaps cruel**.
- Step 4: Synthesize — ensure each answer uses a distinct cognitive verb (define, explain, analyze) and textual anchor.

ANSWER:  
(a) "vkukdkuh" means **separation/parting** — the act of creating distance between two connected beings.  
(b) The rhetorical question **"Why do you create separation?"** conveys **helpless bewilderment** and **moral appeal**. A direct accusation ("You separated us") would close dialogue; the question keeps the door open for the addressee to reflect, mirroring the poet's lingering hope.  
(c) The causative metaphor **"fugkfjcks" (make/create separation)** assigns **full agency to the addressee**. Separation is portrayed as a *crafted act*, not an accident. This characterizes the addressee as **deliberate and accountable** — the architect of the rupture.

DIFFICULTY: hard