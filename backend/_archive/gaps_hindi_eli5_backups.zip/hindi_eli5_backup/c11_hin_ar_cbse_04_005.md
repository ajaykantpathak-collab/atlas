## DEFINITION
Character analysis of supporting characters involves examining the traits, motivations, relationships, and narrative functions of characters who are not the central protagonist but who advance the plot, reveal thematic concerns, and illuminate the protagonist's personality through contrast or parallel. In senior secondary Hindi literature, this requires identifying how each supporting character's *kriya* (action), *vichar* (thought), *samvad* (dialogue), and *paristhiti* (circumstance) contribute to the author's critique of social, political, or psychological realities.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student can independently select a supporting character from 'f'k{kk', cite three distinct textual evidences (actions, dialogues, or narrative descriptions), and write a structured PEEL paragraph explaining how that character deepens the story's critique of colonialism or reveals a specific flaw/virtue in the British magistrate protagonist.

## SCOPE_BOUNDARY
This node covers systematic analysis of the two sisters (the snake-charmer's daughters), the snake-charmer father, the Collector, the Doctor, and the Indian servants in 'f'k{kk'. It does NOT cover the protagonist's analysis (done in node 004), thematic essay writing (nodes 006-007), or identification of literary devices like irony/symbolism attached to these characters (nodes 008-009).

## WALKTHROUGH
Imagine you are watching a play where the main actor delivers powerful monologues, but the story makes no sense without the reactions of the people around him — the silent servant pouring tea, the angry villager shouting from the crowd, the child crying in the corner. In 'f'k{kk', the British magistrate is that main actor, but the two sisters, their father, and the colonial officials are the "reaction shots" that expose his cruelty and the system's injustice. To begin, don't try to analyze everyone at once. Pick **one** supporting character — say, the younger sister who dies. Ask: "What does she *do*? What does she *say*? How does the magistrate treat her? What happens *because* of her?" Write down three specific moments from the text. That is your evidence. Then ask: "So what? What does this prove about the British Raj or the magistrate's soul?" That connection is your analysis.

## DIAGNOSTIC_QUESTION_1
Identify the two supporting characters in 'f'k{kk' who are sisters and describe the key difference in their fate as presented in the narrative.

## DIAGNOSTIC_ANSWER_1
The two sisters are the daughters of the snake-charmer (sapera). The elder sister survives and later confronts the magistrate as the widow of the *juktoqekj* (the man who cursed the magistrate), while the younger sister dies after being denied water by the magistrate's order during the plague inspection. A wrong answer (e.g., confusing them with the magistrate's sisters or missing the death of the younger sister) reveals the student has not tracked the minor characters' plot arcs and cannot distinguish their narrative functions.

## DIAGNOSTIC_QUESTION_2
Explain in your own words why the snake-charmer father refuses to let the magistrate's men kill his performing snake, and what this refusal reveals about his character versus the magistrate's.

## DIAGNOSTIC_ANSWER_2
The snake-charmer refuses because the snake is his livelihood and his child's companion — "esjk vUunkrk gS" (it is my life). This reveals his dignity, protective love, and connection to tradition, contrasting sharply with the magistrate's arbitrary power and disregard for Indian lives. A wrong answer focusing only on "he liked the snake" misses the economic and emotional dependency, showing the student cannot infer character depth from dialogue subtext.

## DIAGNOSTIC_QUESTION_3
Apply the "foil" concept: Choose ONE supporting character (Collector, Doctor, or elderly servant) and demonstrate with two textual details how they act as a foil to the magistrate's evolving attitude toward Indians.

## DIAGNOSTIC_ANSWER_3
**Collector**: (1) He initially supports the magistrate's harsh plague measures ("vkius dgk Fkk fd ;gk¡ ls tkrs le; Hkkjro"kZ dks ,slk dj tkm¡Qxk"), showing complicity. (2) Later, he is silenced by the magistrate's tirade, revealing his moral cowardice versus the magistrate's eventual guilty conscience. The student must select evidence showing *contrast* at two time-points. A wrong answer listing only one trait or ignoring the temporal change shows inability to apply the foil concept dynamically.

## DIAGNOSTIC_QUESTION_4
Analyze the narrative function of the younger sister's death scene (denial of water). How does this single event operate on three levels: plot advancement, thematic development, and protagonist characterization?

## DIAGNOSTIC_ANSWER_4
**Plot**: Triggers the father's curse ("esjk iz.kke ys") which haunts the magistrate. **Theme**: Embodies the story's central indictment — colonial bureaucracy values procedure ("foPNsn") over human life ("nq[k"). **Protagonist**: Exposes the magistrate's peak cruelty ("vkidh ftí dk iQy ;gha ns[k fy;k") and plants the guilt that later destroys him. A wrong answer treating it only as "a sad event" fails to see the structural multiplicity senior secondary analysis demands.

## DIAGNOSTIC_QUESTION_5
Evaluate the author's choice to make the *juktoqekj* (the cursed official) the husband of the elder sister rather than a random victim. Defend or critique this decision using the story's irony and symbolism.

## DIAGNOSTIC_ANSWER_5
**Defense**: It creates dramatic irony — the magistrate's curse returns through the very family he wronged, tightening the karmic circle. The elder sister's transformation from voiceless victim to powerful accuser ("rw esjk oqQN ugha fcxkM+k") symbolizes colonialism's inevitable backlash. **Critique**: It risks melodrama, making justice feel personal rather than systemic. A strong answer weighs both. A weak answer merely says "it makes the story interesting" without engaging irony/symbolism concepts from nodes 008-009.

## DIAGNOSTIC_QUESTION_6
Create a 50-word monologue for the *snake* (as a silent witness) summarizing its observation of the magistrate's transformation from arrogant ruler to broken man. Use at least two Hindi phrases from the text's vocabulary list (e.g., *d#.kksRiknd*, *nqf[kr*).

## DIAGNOSTIC_ANSWER_6
**Sample**: "Mainne dekha: sahib ka *d#.kksRiknd* andaaz, jab usne pani roka. Fir *nqf[kr* aankhon se usne baap ki kurbaan dekhi. Aaj uski *ftí* jal rahi hai, meri tarah — beawaz, lekin sachchi." A poor answer uses modern slang, ignores the vocabulary list, or makes the snake speak like a human philosopher, showing failure to adopt textual voice and constraints.

## COMMON_MISCONCEPTION
Students treat supporting characters as "background decoration" and write generic descriptions like "the sister was sad" or "the father was poor." They miss that in Guleri's story, **every supporting character is a deliberate argument against colonialism**: the younger sister's death *is* the indictment of bureaucratic cruelty; the father's curse *is* the voice of colonized resistance; the Collector's silence *is* the moral bankruptcy of collaboration. Students also confuse "character trait" (adjective) with "character function" (narrative role), leading to descriptive rather than analytical answers.

## ON_FAILURE
1. **Re-read with a lens**: Assign the student to re-read ONLY the scenes with the snake-charmer family (pages 46-48 in NCERT), highlighting every verb attached to them. 2. **Function-first table**: Create a 3-column table: Character | Key Action/Dialogue | What This Proves About Colonialism/Magistrate. 3. **Oral defense**: Ask the student to explain *why* Guleri gave the dying girl no name but gave the father a curse — force them to articulate authorial intent. 4. **Connect to protagonist node**: Review node 004's analysis of the magistrate's guilt; map each supporting character to a specific stage of that guilt.

## BUILDS_ON
c11_hin_ar_cbse_04_004 (Character Analysis: Protagonist) — supporting characters are defined relationally; you cannot analyze the foil without knowing the protagonist's arc.

## LEADS_TO
c11_hin_ar_cbse_04_006 (Theme: Primary Theme and Message) — the collective weight of supporting characters' suffering constitutes the textual evidence for the primary theme of colonial injustice.

## PREREQUISITE_NODE_IDS
c11_hin_ar_cbse_04_001, c11_hin_ar_cbse_04_002, c11_hin_ar_cbse_04_003, c11_hin_ar_cbse_04_004
## PREREQUISITE_REASONS
c11_hin_ar_cbse_04_001: Provides historical context (1899-1905 plague, British plague policies) essential to understand why supporting characters act as they do.
c11_hin_ar_cbse_04_002: Plot knowledge is required to locate each supporting character's entry, exit, and turning points in the narrative sequence.
c11_hin_ar_cbse_04_003: The oppressive atmosphere (plague, inspection, fear) shapes supporting characters' behaviour and limits their agency.
c11_hin_ar_cbse_04_004: The magistrate's character arc (arrogance → guilt → breakdown) is the benchmark against which all supporting characters are measured.

## FORWARD_NODE_IDS
c11_hin_ar_cbse_04_006, c11_hin_ar_cbse_04_007, c11_hin_ar_cbse_04_013, c11_hin_ar_cbse_04_014, c11_hin_ar_cbse_04_012, c12_hin_al_cbse_03_005, c12_hin_ar_cbse_04_005, c12_hin_ar_cbse_06_005

## FORWARD_REASONS
c11_hin_ar_cbse_04_006: Supporting characters' collective experience provides the textual evidence for the primary theme (colonial dehumanization).
c11_hin_ar_cbse_04_007: Individual supporting characters embody secondary themes (e.g., father = tradition/resistance; Collector = collaboration).
c11_hin_ar_cbse_04_013: Critical interpretation requires synthesizing multiple character perspectives to evaluate the author's stance.
c11_hin_ar_cbse_04_014: Writing tasks (character sketch, thematic essay) demand structured character analysis as raw material.
c11_hin_ar_cbse_04_012: Supporting character analysis (Mr. Young as colonial archetype) supplies context for inferential deductions.  
c12_hin_al_cbse_03_005: That chapter (उषा) used supporting characters to contrast tradition/modernity — direct thematic parallel.  
c12_hin_ar_cbse_04_005: Class 11 foundation in supporting character typology (foil, confidant, catalyst).  
c12_hin_ar_cbse_06_005: Class 11 foundation on supporting character analysis in Aroh.  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
none

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_04_004 -> c11_hin_ar_cbse_04_005 -> c11_hin_ar_cbse_04_006

## THIS_FORMULA
PEEL Structure for Character Analysis: **P**oint (Character's narrative function) + **E**vidence (Specific action/dialogue/description with page/ref) + **E**xplanation (How evidence proves the point, using literary terminology) + **L**ink (Connect to theme/protagonist/author's purpose)

## FORMULA_VARIABLES
P = Function claim (e.g., "The younger sister functions as the embodiment of bureaucratic cruelty's innocent victim")
E = Textual proof (e.g., "On page 47, the magistrate orders 'pani mat dena' during plague inspection")
E = Analysis (e.g., "The imperative mood and denial of basic need *pani* strips her of humanity, mirroring colonial policy")
L = Thematic link (e.g., "This moment triggers the curse that destroys the magistrate, proving Guleri's karmic justice theme")

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
analytical

## CROSS_SUBJECT
c11_history_colonialism | The plague inspection scenes in 'f'k{kk' mirror historical British plague policies (1896-1897 Epidemic Diseases Act) — supporting characters represent Indian responses: resistance (father), compliance (servants), victimhood (sisters).
c11_civics_power_authority | The magistrate's arbitrary denial of water ("pani mat dena") illustrates Weber's "monopoly on legitimate violence" — supporting characters experience state power without rights, enabling discussion of colonial vs. democratic accountability.

## PREREQ_CONCEPT
Understanding of "foil" and "narrative function" from Class 10 prose analysis, applied here to a colonial-era Hindi text with historical specificity.

## PREREQ_BEFORE
Student must have completed node 004 (Protagonist Analysis) and know the magistrate's three-stage transformation: arrogance (plague duty), guilt (curse haunting), breakdown (confession to Collector).

## PREREQ_STUCK
If stuck, review the magistrate's "confession scene" (page 50-51) and list every supporting character he mentions — each name is a key to a supporting character analysis.

## WORKED_EXAMPLE_1
PROBLEM: Write a PEEL paragraph analyzing how the **snake-charmer father** functions as a symbol of dignified resistance in 'f'k{kk'.

STEPS:
- Step 1: Identify the character's narrative function claim (Point). The father is not just a victim; his refusal to kill the snake and his curse represent active, cultural resistance to colonial dehumanization.
- Step 2: Select two precise textual evidences (Evidence). (a) Page 47: When ordered to hand over the snake, he says "esjk vUunkrk gS" (it is my life) and risks death. (b) Page 48: His dying curse "esjk iz.kke ys" (accept my curse) delivered with "foin osQ fnu" (last day's authority).
- Step 3: Explain the significance of each evidence (Explanation). (a) "vUunkrk" equates the snake with survival and identity — colonial power demands he destroy his own livelihood, he refuses. (b) The curse uses the magistrate's own bureaucratic language ("iz.kke" = official acceptance) against him, weaponizing ritual authority.
- Step 4: Link to broader theme and protagonist (Link). This resistance contrasts with the Collector's collaboration and the servants' fear, proving Guleri's thesis: colonialism breaks bodies but cannot silence the moral voice of the colonized, which ultimately destroys the oppressor.
- Step 5: Verify PEEL completeness and Hindi terminology. Check: Point = function claim? Yes. Evidence = page-specific? Yes. Explanation = literary analysis? Yes. Link = thematic? Yes.

REASONING: This example models the senior secondary requirement to move beyond "he was brave" to "he embodies cultural resistance through linguistic subversion." The steps enforce evidence-first, interpretation-second discipline.

ANSWER: The snake-charmer father functions as the story's voice of dignified resistance against colonial dehumanization. When the magistrate's men demand he surrender his performing snake during the plague inspection, he declares, "esjk vUunkrk gS" (page 47), equating the creature with his very survival and cultural identity — a refusal to let bureaucracy erase his livelihood. Later, dying from the magistrate's brutality, he delivers his curse in the magistrate's own administrative register: "esjk iz.kke ys" (page 48), weaponizing the term for "official acceptance" to bind the ruler to karmic accountability. This linguistic subversion contrasts sharply with the Collector's silent complicity and the servants' terrified obedience, establishing that while colonial power can kill the body, it cannot suppress the moral authority of the colonized. The father's curse becomes the structural engine of the magistrate's downfall, proving Guleri's central argument: injustice carries its own destruction.

## WORKED_EXAMPLE_2
PROBLEM: Compare the **Collector** and the **Doctor** as representatives of the colonial bureaucracy. How do their differing responses to the magistrate's cruelty reveal the spectrum of complicity?

STEPS:
- Step 1: Define the analytical frame — "spectrum of complicity" from active enforcement to passive witnessing.
- Step 2: Map Collector's actions: (a) Initial endorsement ("vkius dgk Fkk fd ;gk¡ ls tkrs le; Hkkjro"kZ dks ,slk dj tkm¡Qxk" — page 48). (b) Silent presence during magistrate's final confession (page 51).
- Step 3: Map Doctor's actions: (a) Professional detachment during plague inspection ("foPNsn u djus dh izkFkZuk" — page 49). (b) Failure to challenge the water denial despite medical knowledge.
- Step 4: Analyze contrast. Collector = political complicity (policy-maker who later feigns ignorance). Doctor = professional complicity (expert who prioritizes protocol over ethics).
- Step 5: Synthesize thematic implication. Together they show colonialism corrupts *both* governance and science — no "good" bureaucrat exists in Guleri's vision.
- Step 6: Draft comparative PEEL with dual evidence.

REASONING: Senior secondary analysis requires comparing supporting characters to expose systemic critique. The steps enforce multi-character tracking and thematic synthesis.

ANSWER: The Collector and Doctor represent twin pillars of colonial complicity — political and professional. The Collector initially champions the magistrate's harsh plague measures, boasting they would "make Indians so afraid they'd never return" (page 48), revealing policy-level cruelty. Yet during the magistrate's final confession, he sits silent, embodying the bureaucrat who executes orders then feigns innocence. The Doctor, meanwhile, epitomizes technocratic complicity: he raises "no objection to the magistrate's refusal to allow water" (page 49) despite knowing dehydration kills plague patients, hiding behind "professional protocol." Their contrast is damning: the Collector *orders* inhumanity, the Doctor *sanitizes* it with expertise. Neither protests. Guleri thus indicts the entire colonial apparatus — not just the "villain" magistrate but the "decent" officials who enable him. This dual portrait deepens the story's critique beyond individual morality to institutional rot.

## WORKED_EXAMPLE_3
PROBLEM: The **elder sister** appears only in the final scene as the *juktoqekj*'s widow. Analyze how her brief appearance achieves maximum thematic impact through *contrast* with her younger sister and *parallel* with the magistrate.

STEPS:
- Step 1: Establish the younger sister's baseline — voiceless, passive victim (dies without dialogue, denied water).
- Step 2: Analyze elder sister's entry — she speaks *with* authority ("rw esjk oqQN ugha fcxkM+k"), commands the magistrate ("esjk iz.kke ys"), and reclaims agency.
- Step 3: Identify the contrast mechanism — same family, same oppression, but different historical moment (post-curse vs. pre-curse) transforms victim into avenger.
- Step 4: Identify the parallel with magistrate — both use bureaucratic language ("iz.kke", "foPNsn") but she uses it for justice, he for oppression.
- Step 5: Explain the irony — the magistrate's own curse ("fcNM+u&le; cM+k d#.kksRiknd gksrk gS") creates the time-gap allowing her transformation.
- Step 6: Conclude: Her brevity *is* the point — one empowered voice dismantles the magistrate's lifelong power, proving Guleri's faith in inevitable historical justice.

REASONING: This advanced example combines character contrast, temporal analysis, linguistic parallelism, and structural irony — exactly the multi-concept synthesis Board exams demand.

ANSWER: The elder sister's single-scene appearance is a masterclass in economical characterization. Her younger sister dies voiceless, denied even water ("pani mat dena"), embodying the colonized as silent victim. The elder sister, however, enters *after* the curse's maturation ("fcNM+u&le; cM+k d#.kksRiknd gksrk gS") — she is the historical consequence of that victimhood. She speaks the magistrate's language: "esjk iz.kke ys" (accept my curse) mirrors his "iz.kke" (official acceptance); "rw esjk oqQN ugha fcxkM+k" (my rights not diminished) echoes his "foPNsn" (inspection/authority). But she inverts them: where he used bureaucracy to deny life, she uses it to demand accountability. The irony is exquisite — the magistrate's own prophecy ("time makes big things small") describes his own shrinkage before her moral stature. Her brevity amplifies power: she needs no backstory because she *is* the backstory made flesh. Guleri thus argues that colonialism's victims, given time, become its judges — a theme the protagonist's breakdown confirms.

## COMPETENCY_QUESTION_1
QUESTION: "In 'f'k{kk', the supporting characters are not individuals but symbols." Evaluate this statement with reference to ANY TWO supporting characters. Your answer must include: (a) one symbolic reading for each character, (b) one textual detail that *complicates* the symbolic reading (shows individual humanity), and (c) a conclusion on why Guleri balances both.

COMPETENCY: Critical evaluation of characterization technique with textual nuance
STEPS:
- Step 1: Select two characters (e.g., younger sister = symbol of innocent victimhood; father = symbol of traditional resistance).
- Step 2: For each, state the symbolic reading with evidence.
- Step 3: For each, find a humanizing detail that resists pure symbolism (e.g., younger sister's fear of darkness; father's worry for elder daughter).
- Step 4: Synthesize: Guleri uses symbolism to indict a system, but humanizing details prevent allegory, forcing reader empathy.
ANSWER: The statement is partially true but reductive. The younger sister *functions* as a symbol of bureaucratic cruelty's faceless victim — she has no name, no dialogue, dies for "protocol." Yet the text notes "og Hkw[kh [kM+h jgh] pkjk Nqvk rd ugha" (she sat trembling, didn't reach the door) — a specific, human fear of the dark that transcends symbolism. The father *functions* as the symbol of karmic resistance — his curse destroys the magistrate. Yet he begs "esjk vUunkrk gS" for the snake, revealing a father's desperate love, not just ideological defiance. Guleri balances both because pure symbols invite intellectual agreement; human details demand moral outrage. The system kills *people*, not symbols. This duality is the story's ethical core.
DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: Design a 3-question interview for the **Collector** set ten years after the story ends. Each question must: (a) probe a specific moral choice he made in the story, (b) use a direct quote from the text as the basis, and (c) require him to confront the gap between his self-image and his complicity. Write the questions only — no answers.

COMPETENCY: Creative application of character analysis to expose moral complexity
STEPS:
- Step 1: Identify Collector's three key moments: (1) Endorsing the magistrate's plan (page 48), (2) Silent during water denial (page 49), (3) Silent during confession (page 51).
- Step 2: Select quotes for each: (1) "vkius dgk Fkk fd ;gk¡ ls tkrs le; Hkkjro"kZ dks ,slk dj tkm¡Qxk", (2) "vkidh 'kklu&vofèk iwjh gks xbZ gS", (3) "vki Lo;a Hkh [kq'k u gks losQ vkSj ;gk¡ dh iztk dks lq[kh u gksus fn;k".
- Step 3: Frame questions that trap him in his own words: e.g., "You said you'd make Indians afraid — did you include the girl who died of thirst?"
- Step 4: Ensure each question demands self-judgment, not factual recall.
- Step 5: Verify all three criteria (a, b, c) are met for each question.
ANSWER:
1. "Collector sahib, you promised the magistrate his measures would make 'Hkkjro"kZ ... d"V' — but when the snake-charmer's daughter died begging for water, did her fear count as your success, or your failure?"
2. "You watched the magistrate declare 'vkidh 'kklu&vofèk iwjh gks xbZ' while denying a dying girl water. As the senior medical officer present, which 'foPNsn' did you conduct that day — the plague inspection, or your conscience?"
3. "Years later, the magistrate confessed you 'Lo;a [kq'k u gks' and let 'iztk dks lq[kh u gksus fn;k'. When you read his confession now, do you see a broken tyrant — or your own reflection in the mirror?"
DIFFICULTY: hard