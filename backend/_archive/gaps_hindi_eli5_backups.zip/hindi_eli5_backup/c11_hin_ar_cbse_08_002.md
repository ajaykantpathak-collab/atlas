## DEFINITION
Plot and Narrative Structure refers to the deliberate arrangement of events, reflections, and episodes in a non-fiction prose text to convey the author's central idea; in this chapter, it is an episodic, first-person travelogue that interweaves physical journeys across India with philosophical reflections on unity, diversity, and national identity.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student must be able to map the chapter's non-linear narrative structure (framing journey, episodic encounters, reflective digressions, concluding synthesis) and explain how this structure reinforces the theme of "unity in diversity" using specific textual evidence.

## SCOPE_BOUNDARY
This node covers the narrative architecture of "Hkkjr ekrk" — its framing device, episodic organization, shifts between observation and reflection, and the author's direct address to the reader. It does NOT cover character analysis, thematic depth, literary devices, or vocabulary, which are addressed in subsequent nodes.

## WALKTHROUGH
Imagine you are asked to summarize this chapter in one paragraph but find yourself jumping from the Himalayas to the plains, from a dialogue with a peasant to a meditation on history — that confusion is your entry point. Begin by identifying the **framing device**: Nehru's physical travel across India (the "tyl" or journey) which acts as the spine. Next, mark the **episodes**: each distinct encounter (the peasant, the factory worker, the intellectual) as a self-contained unit. Then trace the **reflective digressions**: where the author pauses the journey to philosophize about "Bharat Mata" or "fganqLrku". Finally, observe the **synthesis** in the closing pages where the journey ends but the idea of India expands. The key insight: the structure *is* the argument — the fragmented yet connected episodes mirror the diverse yet united nation.

## DIAGNOSTIC_QUESTION_1
What is the primary narrative frame that structures the entire chapter "Hkkjr ekrk"?

## DIAGNOSTIC_ANSWER_1
The primary narrative frame is Jawaharlal Nehru's first-person travelogue across India (tyl) during the 1930s-40s, which serves as the spine connecting all episodes and reflections. A wrong answer (e.g., "the freedom struggle" or "Nehru's autobiography") reveals the student confuses the *historical context* with the *narrative structure* — they are identifying the backdrop, not the organizing device.

## DIAGNOSTIC_QUESTION_2
Explain in your own words why the author shifts abruptly from describing a peasant's dialogue to a philosophical reflection on "fganqLrku" (unity) within the same paragraph.

## DIAGNOSTIC_ANSWER_2
The abrupt shifts mimic the actual experience of travel: physical encounters trigger immediate intellectual connections, showing that unity is not an abstract idea but emerges from concrete, diverse interactions. A wrong answer (e.g., "the author is disorganized" or "it's a stream of consciousness") reveals the misconception that narrative structure must be linear or that digressions are flaws — missing that the *juxtaposition* is a deliberate structural choice to embody the theme.

## DIAGNOSTIC_QUESTION_3
Given a new excerpt from the chapter where Nehru describes a factory in Kanpur and then immediately recalls a Vedic hymn, apply the concept of "episodic-reflective structure" to explain the author's purpose.

## DIAGNOSTIC_ANSWER_3
Step 1: Identify the episode (factory visit) and the reflection (Vedic hymn). Step 2: Note the contrast — modern industrial setting vs. ancient spiritual text. Step 3: Explain the structural purpose: the episode grounds the reflection in contemporary reality, while the reflection elevates the episode to a timeless civilizational continuity. Step 4: Conclude that this pairing structurally enacts "unity in diversity" across time. A wrong answer that only summarizes the content without analyzing the *structural pairing* shows inability to apply the concept of episodic-reflective alternation.

## DIAGNOSTIC_QUESTION_4
Compare the narrative structure of this chapter with a conventional short story (exposition-rising action-climax-fall-resolution). What fundamental difference in purpose does this reveal?

## DIAGNOSTIC_ANSWER_4
A conventional story uses linear causality to resolve a conflict; this chapter uses *accumulation of episodes* to build a composite portrait of a nation. The difference reveals the author's purpose is not dramatic resolution but *demonstrative synthesis* — each episode adds a facet to the idea of India, and the structure never "concludes" because the nation is ongoing. A wrong answer that forces the chapter into a story arc (e.g., "the climax is the Quit India Movement") reveals the misconception that all narratives follow fictional plot conventions.

## DIAGNOSTIC_QUESTION_5
Critique the view that the chapter's lack of chronological order (jumping between 1930s travels, ancient history, and 1947 independence) is a weakness. Defend your judgment using the concept of "thematic architecture."

## DIAGNOSTIC_ANSWER_5
The non-chronological order is a strength because the chapter's architecture is *thematic*, not temporal: it groups episodes by *idea* (e.g., all references to "soil" or "labor" appear together regardless of when they occurred). This structures the reader's understanding around enduring civilizational patterns rather than historical accidents. A wrong answer that calls it "confusing" or "poor editing" reveals the student evaluates structure by chronological coherence alone, missing that thematic architecture serves a different rhetorical goal.

## DIAGNOSTIC_QUESTION_6
Create a one-page visual map (describe it in words) of the chapter's narrative structure that a Class 11 student could use for revision. Your map must show the framing journey, at least three episodes, two reflective digressions, and the synthesis.

## DIAGNOSTIC_ANSWER_6
A strong map would show: (1) A horizontal timeline labeled "Tyak" (Journey) with nodes for major locations (Himalayas, Punjab, Bengal, South). (2) From each location, vertical branches for Episodes (e.g., peasant dialogue, factory visit, temple conversation). (3) Cloud-shaped bubbles for Reflective Digressions (e.g., "Bharat Mata concept", "Vedic continuity", "Unity in diversity") linked to the episodes that trigger them. (4) A converging funnel at the end labeled "Synthesis: India as a living unity." A poor map that lists events chronologically or omits the reflective layer reveals the student still sees structure as a sequence of events, not an architecture of ideas.

## COMMON_MISCONCEPTION
Students believe "plot" only applies to fiction and means a chronological sequence of cause-and-effect events leading to a climax. They therefore either (a) claim this non-fiction chapter "has no plot" or (b) forcibly impose a story arc (e.g., "the climax is Independence"). This error stems from middle-school teaching that equates plot with Freytag's pyramid, ignoring that non-fiction narratives use *thematic* or *episodic* structures where the "plot" is the intellectual journey.

## ON_FAILURE
Step 1: Ask the student to list five distinct "stops" in Nehru's journey (places/people) without interpreting them. Step 2: For each stop, ask: "What idea does Nehru connect to this encounter?" — this separates episode from reflection. Step 3: Have them draw a two-column table: Column A = Physical Encounter (Episode), Column B = Idea Triggered (Reflection). Step 4: Show how the chapter alternates A→B→A→B, and how the final pages merge all Column B ideas. This concrete mapping replaces the abstract misconception with visible structure.

## BUILDS_ON
c11_hin_ar_cbse_08_001 (Before You Read: Context and Background) — provides the historical and biographical context needed to recognize why Nehru chose a travelogue structure.

## LEADS_TO
c11_hin_ar_cbse_08_003 (Text: Setting and Atmosphere) — the narrative structure determines how settings are introduced and layered; understanding the episodic frame is prerequisite to analyzing setting.

## PREREQUISITE_NODE_IDS
c11_hin_ar_cbse_08_001, c12_hin_ar_cbse_08_001

## PREREQUISITE_REASONS
c11_hin_ar_cbse_08_001: Provides the historical context (1930s-40s India, Nehru's role, the concept of "Bharat Mata") without which the narrative frame and its purpose cannot be understood.
c12_hin_ar_cbse_08_001: tional skill of identifying narrative structure in Hindi poetry (stanza, refrain, narrative voice). c12_hin_ar_cbse_08_001: Gives the historical/biographical context of Phanishwar Nath Renu essential for understanding why the poem moves fro  

## FORWARD_NODE_IDS
c11_hin_ar_cbse_08_003, c11_hin_ar_cbse_08_004, c11_hin_ar_cbse_08_006, c11_hin_ar_cbse_08_005, c11_hin_ar_cbse_08_007, c11_hin_ar_cbse_08_008, c11_hin_ar_cbse_08_009, c11_hin_ar_cbse_08_012, c11_hin_ar_cbse_08_013, c11_hin_ar_cbse_08_014, c11_hin_ar_cbse_08_015, c12_hin_a_cbse_09_002, c12_hin_ar_cbse_08_002, c12_hin_ar_cbse_08_005

## FORWARD_REASONS
c11_hin_ar_cbse_08_003: Setting analysis requires knowing the episodic structure because each episode introduces a distinct setting-atmosphere pair. c11_hin_ar_cbse_08_004: Character analysis (Nehru as narrator-protagonist) depends on recognizing how the narrative structure positions him as both observer and participant. c11_hin_ar_cbse_08_006: Primary theme ("unity in diversity") is enacted *through* the narrative structure; structure is the theme's vehicle.
c11_hin_ar_cbse_08_005: Plot/narrative structure node establishes the journey framework - the supporting characters appear at specific stops on Nehru's travel route.  
c11_hin_ar_cbse_08_007: Understanding narrative structure helps locate where secondary themes are introduced, developed, and resolved across the essay's journey  
c11_hin_ar_cbse_08_008: Plot/narrative structure reveals the *journey framework* that organizes the extended metaphor of travel-as-discovery.  
c11_hin_ar_cbse_08_009: Plot structure shows the journey pattern (village to village) that sets up repeated ironic encounters.  
c11_hin_ar_cbse_08_012: Plot structure gives the chronological framework to locate literal events (journeys, meetings) and trace how they build inferential understanding.  
c11_hin_ar_cbse_08_013: Plot/Narrative Structure provides the sequence of Nehru's journey and encounters, essential for analyzing his method of inquiry.  
c11_hin_ar_cbse_08_014: Plot/narrative structure provides the sequence of events to reference as evidence.  
c11_hin_ar_cbse_08_015: Understanding plot/narrative structure provides the chronological framework for discussing Nehru's journey and encounters.  
c12_hin_a_cbse_09_002: Introduced imagery as structural markers.  
c12_hin_ar_cbse_08_002: Provides foundational skill of identifying narrative structure in Hindi poetry (stanza, refrain, narrative voice). c12_hin_ar_cbse_08_001: Gives the historical/biographical context of Phanishwar Nath Renu essential for understanding why the poem moves from personal memory to linguistic manifesto.  
c12_hin_ar_cbse_08_005: Class 11 plot analysis trained identification of causal chains — now applied to character-driven causality.  
c11_hin_ar_cbse_08_004: The plot's journey structure (travel → encounters → realization) maps directly onto the protagonist's character development phases.  
c11_hin_ar_cbse_08_006: Plot and Narrative Structure gives the episode sequence (travels, dialogues, reflections) needed to trace thematic development.  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
none

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_08_001 -> c11_hin_ar_cbse_08_002 -> c11_hin_ar_cbse_08_003

## THIS_FORMULA
N/A - conceptual

## FORMULA_VARIABLES
N/A

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
analytical

## CROSS_SUBJECT
c11_history_nationalism | The chapter's episodic structure mirrors the historical process of constructing Indian nationalism — diverse regional experiences (episodes) synthesized into a unified national idea (reflection).  
c11_civics_unity_in_diversity | The narrative architecture (alternating concrete encounters with abstract reflections) enacts the civic principle of "unity in diversity" at the formal level, making the structure a pedagogical model for the concept.

## PREREQ_CONCEPT
Understanding of travelogue as a genre that blends personal observation with cultural commentary.

## PREREQ_BEFORE
Student must know that Nehru undertook these journeys as a political leader *before* independence, not as a tourist, and that the text was written during imprisonment.

## PREREQ_STUCK
Review the "Before You Read" node (c11_hin_ar_cbse_08_001) for Nehru's biography and the historical circumstances of writing.

## WORKED_EXAMPLE_1
PROBLEM: Identify the narrative frame and first two episodes in the opening section of the chapter (up to the first reflective digression on "Bharat Mata").

STEPS:
- Step 1: Locate the opening sentences — Nehru describes moving from one "tyl" (place) to another, addressing listeners. This establishes the frame: a speaker traveling and narrating.
- Step 2: Identify the first concrete episode — the encounter with a group of peasants in a village who ask about "Bharat Mata." Note the sensory details (dust, heat, curious faces).
- Step 3: Identify the second episode — the dialogue with an educated young man who defines "Bharat Mata" geographically. Contrast the two episodes: one rooted in lived experience, the other in intellectual abstraction.
- Step 4: Mark the transition to reflection — Nehru steps back from both dialogues to articulate his own synthesis: "Bharat Mata is the people."
- Step 5: Verify the pattern — Frame (journey) → Episode 1 (peasant) → Episode 2 (intellectual) → Reflection (author's definition). This A-B-B-C pattern repeats throughout.

REASONING: The worked example models the core analytical skill: distinguishing the framing device from the episodes and the reflections, and seeing their recurring sequence. This pattern-recognition is the foundation for all further structural analysis.

ANSWER: The narrative frame is Nehru's itinerant speaking tour. Episode 1: Peasant group asking "Who is Bharat Mata?" Episode 2: Educated youth giving a geographic definition. The first reflective digression is Nehru's own answer: "Bharat Mata is the millions of people."

## WORKED_EXAMPLE_2
PROBLEM: Analyze how the chapter's structure handles the transition from the 1930s travels to the 1942 Quit India Movement and post-1947 nation-building.

STEPS:
- Step 1: Identify the temporal markers — the text moves from "tyl" (travels) to "lu~ rhl osQ ckn" (after 1942) to "lu~ 1947" (independence) without linear narration.
- Step 2: Observe the structural device — Nehru uses *associative links*: the memory of a peasant's face triggers the memory of the 1942 uprising; the factory visit triggers the planning commission vision.
- Step 3: Explain the effect — this creates a "simultaneity" structure where past, present, and future coexist, mirroring the idea that India's civilization is timeless.
- Step 4: Contrast with chronological history — a history textbook would separate these periods; Nehru's structure fuses them to show continuity.
- Step 5: Connect to theme — the structure itself argues that the "idea of India" transcends political periodization.

REASONING: This example demonstrates how to analyze non-linear temporal structure — a key senior-secondary skill — by focusing on associative logic rather than chronological order.

ANSWER: The structure uses associative memory links (peasant's face → 1942; factory → planning) to fuse pre-independence travels, the freedom struggle, and post-independence governance into a single continuous civilizational narrative, rejecting periodization in favor of thematic unity.

## WORKED_EXAMPLE_3
PROBLEM: Compare the narrative structure of "Hkkjr ekrk" with that of a conventional autobiography (e.g., Gandhi's "My Experiments with Truth"). Identify three structural differences and explain their rhetorical purposes.

STEPS:
- Step 1: Define conventional autobiography structure — chronological life story, first-person introspection, causal self-explanation.
- Step 2: Map "Hkkjr ekrk" structure — episodic travelogue, outward-looking (focus on others), thematic synthesis over personal growth.
- Step 3: Difference 1: Chronology vs. Thematic clustering. Purpose: Autobiography builds identity; this chapter builds a collective idea.
- Step 4: Difference 2: Self as center vs. Self as lens. Purpose: Nehru uses his "I" to refract the "We" — the narrator disappears into the nation.
- Step 5: Difference 3: Closure vs. Openness. Autobiography ends with a settled self; this chapter ends with an unfolding future ("vkf[kjdkj ftudh fxurh gS..."). Purpose: The nation is a process, not a finished product.
- Step 6: Synthesize — the structural choices are not accidental but serve the rhetorical goal of defining a nation-in-the-making.

REASONING: This multi-step comparison requires the student to hold two structural models simultaneously and evaluate them against their respective rhetorical purposes — a hallmark of senior-secondary analytical depth.

ANSWER: Three differences: (1) Thematic clustering replaces chronology to emphasize civilizational continuity over personal timeline. (2) The narrator acts as a lens for collective voices rather than a subject of self-examination. (3) The open-ended synthesis replaces autobiographical closure to mirror the ongoing project of nation-building.

## COMPETENCY_QUESTION_1
QUESTION: A student claims: "This chapter has no plot because nothing happens — it's just Nehru talking to random people." Using the concept of episodic-reflective narrative structure, write a 150-word rebuttal that identifies the structural logic and its thematic function.

COMPETENCY: Argumentative writing with textual evidence and conceptual precision.

STEPS:
- Step 1: Define "plot" in non-fiction as the architecture of ideas, not just event sequence.
- Step 2: Identify the recurring structural unit: Episode (encounter) → Reflection (synthesis).
- Step 3: Cite two specific episode-reflection pairs from the text (e.g., peasant dialogue → "Bharat Mata is people"; factory visit → planning vision).
- Step 4: Explain how the accumulation of these pairs *is* the plot — the gradual construction of the idea of India.
- Step 5: Conclude that dismissing it as "random" confuses linearity with coherence.

ANSWER: The chapter's plot is the intellectual journey from fragmented encounters to a unified vision. Each episode — the peasant asking "Who is Bharat Mata?", the worker in Kanpur, the scholar in Benares — is a data point. The reflections are the analytical framework that connects them. The "plot" advances not by what happens next, but by what idea deepens next. By the end, the random-seeming conversations form a composite portrait of a civilization. The structure *enacts* the theme: unity emerges from diversity, just as the chapter's coherence emerges from its episodes.

DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: The chapter ends with Nehru addressing the reader directly: "You are the Bharat Mata." Analyze how the narrative structure prepares the reader for this final address. Your answer must reference (a) the framing journey, (b) the episodic encounters, (c) the reflective digressions, and (d) the shifting narrative distance (third-person observation → first-person reflection → second-person address).

COMPETENCY: Structural analysis integrating multiple narrative elements.

STEPS:
- Step 1: Trace the framing journey — the physical travel creates a shared spatial experience between author and reader.
- Step 2: Show how episodic encounters populate that space with diverse Indian voices, making "Bharat Mata" concrete.
- Step 3: Explain how reflective digressions generalize each encounter into a principle, training the reader to think synthetically.
- Step 4: Analyze the narrative distance shift: early third-person descriptions ("people said") → mid-text first-person reasoning ("I think") → final second-person invocation ("You are").
- Step 5: Conclude that the structure is a rhetorical funnel: it draws the reader from observer to participant, making the final address an earned inclusion, not a sudden imposition.

ANSWER: The structure is a carefully engineered movement from distance to intimacy. The framing journey establishes a shared ground. The episodes fill that ground with specific, diverse faces — the peasant, the worker, the intellectual — so "Bharat Mata" becomes a mosaic of real people. The reflections teach the reader to see the pattern behind the mosaic. Finally, the narrative voice shifts from "they said" to "I see" to "you are," collapsing the distance between author, subject, and reader. The final address works because the structure has spent 100 pages proving that the reader *is* one of those episodes — a living thread in the unity.

DIFFICULTY: hard