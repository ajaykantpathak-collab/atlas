## DEFINITION
Setting in poetry refers to the time, place, and physical environment constructed through sensory details; atmosphere (or mood) is the emotional quality evoked in the reader by the setting, imagery, and language choices. They are distinct: setting is the "where and when," atmosphere is the "how it feels."

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student can identify the physical setting of "वृद्ध के उपवन" through textual evidence, trace how specific sensory images create the atmosphere, and explain how the setting-atmosphere relationship reinforces the poem's central concern with aging, nature, and devotion.

## SCOPE_BOUNDARY
This node covers analysis of setting (time, place, sensory details) and atmosphere (mood, emotional tone) in the poem "वृद्ध के उपवन" by वृद्धा गंगासोह. It does NOT cover character analysis (nodes 004, 005), theme analysis (nodes 006, 007), or isolated literary device identification (nodes 008, 009) — though it builds toward them.

## WALKTHROUGH
Imagine walking into your दादी's garden at 5:30 AM — you hear koels, smell wet earth, see dew on marigolds. That sensory snapshot is the *setting*. The quiet peace mixed with a pang of "she won't be here forever" is the *atmosphere*. In this poem, the poet builds the garden through sound first: bird calls ("gs Hkw[k!"), wind ("bZ";kZ"), water ("tyk"). Read the poem aloud and underline every sound, sight, and smell word. Group them: which create the physical garden? Which make you *feel* something? Notice the shift in Stanza 2 — the garden becomes "मेरे बगीचे के पक्षी" (birds of my garden). That possessive pronoun contracts the setting from cosmic nature to personal sanctuary and changes the atmosphere from impersonal harmony to intimate tenderness. The key insight: setting is not backdrop; it is the emotional engine of the poem.

## DIAGNOSTIC_QUESTION_1
Define "setting" and "atmosphere" in poetry. How are they different from each other?

## DIAGNOSTIC_ANSWER_1
Setting is the time, place, and physical environment created through sensory details (e.g., "a garden at dawn with bird calls and dew"). Atmosphere is the emotional feeling evoked in the reader (e.g., "peaceful, vibrant, melancholic"). They differ in function: setting is the *constructed world*; atmosphere is the *reader's emotional response* to that world. A wrong answer that says "setting is the mood" reveals the student conflates the objective details with the subjective effect — a fundamental category error that prevents analytical writing.

## DIAGNOSTIC_QUESTION_2
In the first stanza, the poet uses lines like "gs Hkw[k! er epy / I;kl] rM+i er". What physical setting do these sounds establish? Explain in your own words.

## DIAGNOSTIC_ANSWER_2
These onomatopoeic bird calls establish a garden/upvan (उपवन) at dawn, dense with avian life. The repetition ("gs... gs... gs...") mimics the layered soundscape of multiple species — koels, parrots, bulbuls — suggesting a thriving ecosystem. A wrong answer that says "it shows the old woman is lonely" reveals the student projects character emotion onto the setting before the speaker even appears. The stanza has no human observer yet; the setting exists independently, vibrant and self-sufficient.

## DIAGNOSTIC_QUESTION_3
Find three visual images from Stanza 1 and explain what time of day they collectively suggest.

## DIAGNOSTIC_ANSWER_3
Images: "ozQksèक" (trees with spreading branches), "epक" (flowers), "yख" (sky), "bZ";कZ" (wind moving things visibly), "त्यक" (water reflecting light). Together they suggest early morning (मफ़की इक़फकी = morning-evening cycle, but the bird chorus and dew-implied freshness point to dawn). A wrong answer listing "sunset" because of "इक़फकी" misses that the *bird chorus* is a dawn marker in Indian poetic convention — the student relies on one ambiguous word instead of synthesizing multiple images.

## DIAGNOSTIC_QUESTION_4
Compare the atmosphere in Stanza 1 versus Stanza 2. How does the shift from observation ("gs Hkw[k!") to direct address ("gs esjs twघ osQ iwQy tसलस बज़ोज") change the mood?

## DIAGNOSTIC_ANSWER_4
Stanza 1: expansive, impersonal, harmonious — nature's chorus without human interference. Stanza 2: intimate, protective, tenderly anxious — the garden becomes "mine," the birds become "like my birds." The shift from third-person imperative ("Look!") to first-person plea ("Listen... don't go into the cage") contracts the atmosphere from cosmic peace to personal vulnerability. A wrong answer saying "both are peaceful" misses the introduction of fear ("फकज तक़ा उहपस" — don't go down into the cage) and agency ("मलस >इवड़ज नहु यस एम>लस" — catch and bring to me) in Stanza 2.

## DIAGNOSTIC_QUESTION_5
A classmate argues: "The poem's atmosphere is primarily melancholic because it's about an old woman." Defend or challenge this using evidence from both stanzas.

## DIAGNOSTIC_ANSWER_5
Challenge. Stanza 1 has *zero* human presence — only bird calls, wind, water, sky. Its atmosphere is vitality, not melancholy. Stanza 2 introduces the speaker but her tone is devotional attentiveness ("एखोकवकस एम>लस हख[क" — look at me with affection) and protective care, not self-pity. The cage image ("फकज") acknowledges fragility, but the response is action ("catch and bring to me"), not resignation. A wrong answer agreeing with the classmate reveals the "biographical fallacy" — assuming the poet's age dictates the poem's mood, ignoring how the *setting's vitality* counterbalances human frailty.

## DIAGNOSTIC_QUESTION_6
Write four lines describing a setting (real or imagined) that creates an atmosphere of *hopeful resilience*. Use at least two sensory details (sound, sight, smell, touch).

## DIAGNOSTIC_ANSWER_6
Example: "The neem tree shakes its coins of light / On the cracked courtyard stone / A sparrow builds again where the monsoon broke her nest / The smell of wet dust rises — *we are still here*." Good answers use concrete sensory details (light on stone, sparrow, wet dust smell) to *show* resilience without naming it. Poor answers write "The garden is strong and hopeful" — telling, not showing; no sensory evidence; atmosphere claimed not created.

## COMMON_MISCONCEPTION
Students treat setting and atmosphere as synonyms, writing "the setting is sad" instead of "the setting is a dawn garden; the atmosphere is peaceful vitality." They also commit the *biographical fallacy*: because the poet is वृद्धा (elderly), they assume the poem *must* be melancholic, ignoring how the text's sensory abundance (bird chorus, wind, water, flowers) creates a counter-atmosphere of continuity. In this poem specifically, students miss that Stanza 1 has *no human observer* — the garden exists in its own right — so the atmosphere there cannot be "the old woman's sadness." The atmosphere shifts *because* the speaker enters in Stanza 2.

## ON_FAILURE
1. **Two-column drill**: Draw a T-chart. Left: "Setting Details from Text" (quote phrases: "बज़ोज", "फकज", "त्यक", "मफ़की इक़फकी"). Right: "Atmosphere Created" (name the feeling: vitality, intimacy, anxiety, tenderness). 2. **Setting swap**: Take the same garden images but rewrite Stanza 1 at midnight — how does the atmosphere change? This proves setting *details* (not just "garden") create atmosphere. 3. **Biographical trap check**: Ask: "Which lines explicitly mention the speaker's age or pain?" None in Stanza 1. The melancholy is *inferred*, not *evoked by the setting*. Practice separating textual evidence from reader projection.

## BUILDS_ON
c11_hin_ar_cbse_14_002 (Plot and Narrative Structure) — understanding the two-stanza structure and the shift from observation to address locates where setting details cluster.

## LEADS_TO
c11_hin_ar_cbse_14_008 (Literary Devices: Imagery and Metaphor) — setting analysis naturally requires identifying the imagery (auditory, visual, tactile) that constructs it; c11_hin_ar_cbse_14_013 (Critical Thinking) — evaluating how setting-atmosphere serves theme.

## PREREQUISITE_NODE_IDS
c11_hin_ar_cbse_14_001, c11_hin_ar_cbse_14_002
## PREREQUISITE_REASONS
c11_hin_ar_cbse_14_001: Context about वृद्धा गंगासोह, the Bhakti tradition, and the upvan (उपवन) as a cultural space is essential to read the setting as more than a generic garden.
c11_hin_ar_cbse_14_002: The poem's narrative structure — two stanzas, shift from third-person soundscape to first-person address — determines where and how setting details appear.

## FORWARD_NODE_IDS
c11_hin_ar_cbse_14_008, c11_hin_ar_cbse_14_009, c11_hin_ar_cbse_14_013, c11_hin_ar_cbse_14_004, c11_hin_ar_cbse_14_006, c11_hin_ar_cbse_14_007, c11_hin_ar_cbse_14_014, c12_hin_a_cbse_06_003, c12_hin_a_cbse_14_003, c12_hin_ar_cbse_14_003

## FORWARD_REASONS
c11_hin_ar_cbse_14_008: Identifying sensory images in the setting (bird calls, wind, water, cage) is the raw material for imagery analysis.
c11_hin_ar_cbse_14_009: The garden as symbol of life-cycle and the cage as symbol of bodily limitation require setting-atmosphere foundation.
c11_hin_ar_cbse_14_013: Critical interpretation of how the upvan setting embodies Bhakti ideals (seva, detachment, continuity) builds directly on this node.
c11_hin_ar_cbse_14_004: Explains the setting/atmosphere (Adivasi life, oppression) that shapes the speaker's character.  
c11_hin_ar_cbse_14_006: Setting (feudal court vs. domestic space) establishes the structural loci of oppression  
c11_hin_ar_cbse_14_007: Setting (field, hut, courtyard) provides the spatial mapping for themes like displacement and private/public divide.  
c11_hin_ar_cbse_14_014: Setting/atmosphere (the cage, the palace) provides concrete Evidence for confinement imagery.  
c12_hin_a_cbse_06_003: Setting-atmosphere in autobiographical prose  
c12_hin_a_cbse_14_003: Provides foundational skill of identifying setting elements and mood vocabulary from Class 11 Antra Chapter 14.  
c12_hin_ar_cbse_14_003: Class 11 foundation on setting/atmosphere analysis (e.g., in "उषा" or "बड़े भाई साहब") — this node deepens that skill for board-level complexity.  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
none

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_14_001 -> c11_hin_ar_cbse_14_002 -> c11_hin_ar_cbse_14_003 -> c11_hin_ar_cbse_14_008 -> c11_hin_ar_cbse_14_013

## THIS_FORMULA
N/A - conceptual

## FORMULA_VARIABLES
N/A

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
analytical

## CROSS_SUBJECT
c11_history_bhakti_movement | The poem's poet वृद्धा गंगासोह belongs to the Bhakti tradition where nature (upvan) mirrors the devotee's inner landscape; understanding the historical role of women poet-sants illuminates why the garden setting carries spiritual weight.
c11_geography_human_environment_interaction | The old woman's daily tending of the garden, feeding birds, and fearing the cage illustrates a cultural landscape where human aging and ecological cycles are intertwined — a classic human-environment interaction case.

## PREREQ_CONCEPT
Ability to distinguish sensory details (sight, sound, smell, touch) in a text and separate literal description from emotional effect on the reader.

## PREREQ_BEFORE
Student should have read the poem twice: once for flow, once with a pencil marking every sensory word (sound, sight, smell, touch, taste).

## PREREQ_STUCK
Review "sensory imagery identification" from Class 10 poetry (e.g., "Megh Aaye" or "Sandhya Ke Baad") — practice listing 5 sensory words per poem and naming the sense each appeals to.

## WORKED_EXAMPLE_1
PROBLEM: Analyze how the opening lines of the poem establish the physical setting and what atmosphere they create.

STEPS:
- Step 1: Read Stanza 1 aloud, marking every sound word: "gs Hkw[k! er epy / I;kl] rM+i er / gs uhan ! er lrk / ozQksèक] epक er mफकी इक़फकी / gs एमसग ! इक'क वइकुस <हय / यख] एर ययपक / gs एन! एर डज एंगस'क / बज़;कZ] त्यक एर". These are onomatopoeic bird calls (koel, parrot, bulbul) followed by visual elements (trees, flowers, sky, wind, water).
- Step 2: Identify the physical elements: multiple bird species → biodiverse garden; "ozQksèक" (branching trees) and "epक" (flowers) → cultivated upvan; "yख" (sky) and "त्यक" (water body) → open, watered space; "मफ़की इक़फकी" → time cycle marker.
- Step 3: Determine time and place: The dawn chorus (bird calls peak at sunrise in Indian settings), fresh flowers, moving water indicate early morning in a tended garden-orchard (उपवन) attached to a dwelling.
- Step 4: Analyze atmosphere creation: The *density* of sound ("gs... gs... gs...") creates auditory immersion — the reader *hears* the garden before seeing it. The absence of human sound makes the atmosphere impersonal, vibrant, self-sustaining — nature's own rhythm.
- Step 5: Connect to poem's arc: This vitality establishes a baseline. When the speaker enters in Stanza 2, her fragility contrasts with the garden's robustness, making her care *devotional* (seva) rather than desperate.

REASONING: The poet uses auditory imagery *first* and *most densely* — 6 sound phrases before a single visual. This sonic immersion establishes the setting as alive and autonomous. The atmosphere emerges from accumulation, not declaration.

ANSWER: The setting is an upvan (garden-orchard) at dawn, rich with birdlife, flowering trees, open sky, and flowing water. The atmosphere is vibrant, harmonious, and impersonally alive — created through layered onomatopoeia that makes the garden's vitality audible before it becomes visible.

## WORKED_EXAMPLE_2
PROBLEM: In Stanza 2, the speaker addresses the garden directly ("gs एमसजस तवघ उस क इवकय तसलस बज़ोज"). How does this shift change the setting and atmosphere?

STEPS:
- Step 1: Identify the grammatical shift: Stanza 1 = third-person imperatives ("gs Hkw[k!" — "Look, birds!" addressing an unseen listener). Stanza 2 = first-person direct address to the garden's inhabitants ("gs एमसजस तवघ..." — "Listen, like birds of my garden").
- Step 2: Extract new setting details introduced: "तवघ उस क इवकय" (your garden's this way), "?कज" (home), "फकज" (cage), "उहपस" (down/below), "डज" (give), "मलस >इवड़ज नहु यस एम>लस" (catch and bring to me). The setting now includes a human dwelling (?कज), a threat (फकज), and verticality (उहपस — descent).
- Step 3: Compare atmospheres: Stanza 1 = expansive, horizontal (sky, trees, water), communal (many birds). Stanza 2 = contracted, vertical (cage below, home above), dyadic (speaker ↔ birds), protective.
- Step 4: Interpret "बज़ोज" (बज़ोज = birds/garden creatures): Addressed as "एमसजस तवघ उस क इवकय तसलस" — they are *kin*, not strangers. The speaker identifies with their vulnerability ("फकज तक़ा उहपस" — don't go down into the cage).
- Step 5: Synthesize: The setting contracts from cosmic nature to personal sanctuary. The atmosphere shifts from impersonal harmony to intimate tenderness laced with anxiety (cage) and agency (catch and bring).

REASONING: The possessive pronoun "मेरे" (मेरे बगीचे के) collapses the distance between speaker and setting. The garden is no longer a place she observes; it is a place she *belongs to* and *acts within*. This transforms atmosphere from aesthetic to ethical — the setting becomes a site of dharma (care).

ANSWER: The setting narrows from a general upvan to the speaker's specific garden-home, adding a cage (confinement) and a dwelling (attachment). The atmosphere becomes intimate, protective, and morally charged — the speaker's devotional care for vulnerable life replaces the earlier impersonal natural harmony.

## WORKED_EXAMPLE_3
PROBLEM: Trace how the poem uses the garden setting as an extended metaphor for the human life-cycle, citing specific images from both stanzas.

STEPS:
- Step 1: List life-cycle images in Stanza 1: "मफ़की इक़फकी" (morning-evening = youth to old age cycle), "यख" (sky = aspiration/limitlessness), "बज़;कZ" (wind = change/breath), "त्यक" (water = time's flow/purity), "एपक" (flowers = beauty/transience).
- Step 2: List life-cycle images in Stanza 2: "बज़ोज" (birds = soul/jivatma), "?कज" (home = body/earthly abode), "फकज" (cage = physical decline/mortality), "उहपस" (down = death/return), "डज" (giving = grace), ">इवड़ज नहु यस" (catching/bringing = guru/kripa).
- Step 3: Map the metaphor structure: Garden = Samsara (world); Birds = Individual souls; Dawn/Dusk = Birth/Death; Cage = Body's cage; Speaker = Devotee/Guru facilitating liberation.
- Step 4: Analyze the speaker's dual role: She is *part of* the garden (aging, like the trees) and *tender of* the garden (feeding birds, protecting from cage). This duality mirrors the Bhakti ideal: engaged in world yet oriented toward release.
- Step 5: Evaluate atmosphere generated: Not tragic acceptance but *active devotion*. The setting's cycles (morning-evening, flight-cage-flight) create an atmosphere of *rhythmic continuity* — individual frailty held within cosmic order.
- Step 6: Connect to Bhakti context: The upvan is a classic Bhakti metaphor (Kabir's "बगिया", Mira's "चरण कमल बन"). The poem continues this tradition: the setting *is* the theology.

REASONING: The poem operates on two simultaneous planes — literal garden description and metaphysical allegory. The setting *is* the metaphor. This dual functioning is characteristic of Bhakti poetry where nature imagery carries soteriological meaning. The atmosphere of "peaceful vitality" in Stanza 1 becomes "compassionate action" in Stanza 2 — mirroring the shift from jnana (knowledge of cycles) to bhakti (devotional action).

ANSWER: The garden functions as an extended metaphor for human existence: morning-evening = life stages; birds = souls; sky/water = cosmic continuity; cage = bodily limitation; home = temporary abode. The atmosphere evolves from cosmic harmony (Stanza 1) to devotional engagement (Stanza 2), embodying the Bhakti synthesis of worldly duty and spiritual detachment.

## COMPETENCY_QUESTION_1
QUESTION: The poem creates atmosphere primarily through sound in Stanza 1 and through direct speech in Stanza 2. Choose ONE stanza and explain how its dominant technique (sound imagery OR direct address) builds a specific atmosphere. Support with two specific textual references.

COMPETENCY: Literary Analysis — Technique and Effect

STEPS:
- Step 1: Choose a stanza and name its dominant technique (sound imagery for Stanza 1; direct address for Stanza 2).
- Step 2: Select two specific textual references that exemplify this technique.
- Step 3: Explain how *each* reference contributes to the atmosphere (not just meaning — the *feeling* it creates).
- Step 4: Synthesize: State the overall atmosphere and why this technique serves the poem's theme.

ANSWER: For Stanza 1: Dominant technique = dense auditory imagery. Reference 1: "gs Hkw[k! एर एपय / इ;कल] रम+इ एर" — the repeated, varied bird calls create a cacophony of life, establishing an atmosphere of *vibrant abundance*. Reference 2: "बज़;कZ] त्यक एर" — wind and water sounds add textural layers, suggesting nature's perpetual, self-sustaining motion. Together they build an atmosphere of *harmonious, impersonal natural order* — the garden as autonomous ecosystem. This technique is effective because it establishes the setting's vitality *before* the human enters, making the later personal connection an act of grace, not need.

DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: A student claims: "The atmosphere of the poem is sad because it's about an old woman." Using evidence from BOTH stanzas, evaluate this claim. Is the atmosphere exclusively melancholic? What other emotional tones are present, and how does the *setting* create them?

COMPETENCY: Critical Evaluation — Evidence-Based Interpretation

STEPS:
- Step 1: Identify the claim's assumption (biographical fallacy: poet's age → poem's mood).
- Step 2: Find Stanza 1 evidence contradicting "exclusively sad" (bird chorus, wind, water, sky — no human sorrow).
- Step 3: Find Stanza 2 evidence showing complex emotions: tenderness ("एखोकवकस एम>लस हख[क"), protective anxiety ("फकज तक़ा उहपस"), empowered care ("मलस >इवड़ज नहु यस एम>लस").
- Step 4: Analyze how the *setting* generates these tones: nature's cycles (मफ़की इक़फकी) → peace; cage (फकज) → tension; feeding birds (डज) → purpose; sky/water (यख, त्यक) → perspective.
- Step 5: Formulate a nuanced judgment: Melancholy is present but *subordinate* to acceptance, tenderness, and quiet resilience. The setting's vitality balances human frailty.

ANSWER: The claim is reductive. Stanza 1 establishes an atmosphere of *vital peace* through bird calls, wind, water — no sadness inherent in the setting. Stanza 2 introduces human emotion: tenderness ("एखोकवकस एम>लस हख[क" — look at me with affection), anxiety about confinement ("फकज तक़ा उहपस" — don't go into the cage), but also *agency* ("मलस >इवड़ज नहु यस एम>लस" — catch it and bring it to me). The garden setting, with its cycles of flight and return, creates an atmosphere of *acceptance* — the old woman tends life knowing its transience. The dominant tone is not sadness but *devotional attentiveness* (सेवा भाव), characteristic of Bhakti poetry where the setting (upvan) is a site of spiritual practice, not suffering.

DIFFICULTY: hard