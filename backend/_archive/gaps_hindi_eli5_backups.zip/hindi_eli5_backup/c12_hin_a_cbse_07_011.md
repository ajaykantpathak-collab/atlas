## DEFINITION
Grammar: Language Usage in the Text refers to the systematic analysis of the dialectal, morphological, and syntactic features employed in a literary work — here, the Braj Bhasha poem *कचजगेळक* — to understand how non-standard verb forms, archaic case endings, phonological shifts, and vocabulary choices create poetic effect and convey cultural context.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student can (1) identify at least five distinct Braj Bhasha grammatical features in the poem (e.g., verb endings, case markers, phonological changes), (2) convert each to standard Modern Hindi with correct grammatical terminology, and (3) explain how each feature contributes to the poem's tone, rhythm, or thematic expression in a structured written response.

## SCOPE_BOUNDARY
This node covers grammatical analysis of the poem *कचजगेळक* only: dialect identification, verb morphology, case system, phonology, and vocabulary archaisms. It does NOT cover literary devices (imagery, irony, symbolism) — those are in nodes c12_hin_a_cbse_07_008 and c12_hin_a_cbse_07_009 — nor comprehension questions (node c12_hin_a_cbse_07_012).

## WALKTHROUGH
Imagine you open the textbook and see the poem *कचजगेळक* — the words look like Hindi but the endings are unfamiliar: *nsol, fufl, nwHkj, fg;k*. You wonder: "Is this wrong Hindi? Why does the poet write this way?" Start by reading the first stanza aloud, listening to the rhythm. Notice that *nsol* sounds like *fnol* (day), *fufl* like *jkf=k* (burning). These are not errors — they are Braj Bhasha, the medieval literary dialect of the Krishna-bhakti region. Your task: systematically map each unusual form to its standard Hindi equivalent, label the grammatical change (e.g., *अन्त्य अ का लोप*, *क्रिया रूप में परिवर्तन*), and then ask: "What does this dialect choice DO for the poem?" — it evokes the folk voice of the gopis, roots the monsoon imagery in the Braj landscape, and preserves the oral-song tradition. That connection between form and meaning is what the board exam rewards.

## DIAGNOSTIC_QUESTION_1
Identify the standard Modern Hindi equivalents of the following Braj Bhasha words from the poem: *nsol, fufl, nwHkj, fg;k, tukok*. Write each pair as "Braj → Hindi".

## DIAGNOSTIC_ANSWER_1
Correct: *nsol → fnol* (day), *fufl → jkf=k* (burning), *nwHkj → dfBu* (deep/intense), *fg;k → ân;* (grace/beauty), *tukok → izrhr gqvk* (broken/shattered). A wrong answer (e.g., *nsol → nsol* or *fufl → fufl*) reveals the student treats the dialect as mere spelling variation rather than a systematic grammatical system with predictable phonological and morphological rules.

## DIAGNOSTIC_QUESTION_2
Explain in your own words why the poet uses the Braj Bhasha form *lhÅ* instead of standard Hindi *'khr* in the line *lhÅ rkS iS tkb gksb l¡x ihmQA*. What grammatical category does this illustrate?

## DIAGNOSTIC_ANSWER_2
*lhÅ* is the Braj Bhasha nominative singular pronoun for 'he/she/it' (standard Hindi *'khr*). It illustrates the **pronoun paradigm shift** between Braj and Modern Hindi. A wrong answer like "it's just an old word" misses the systematic nature: Braj retains the Apabhramsha *so/seh* lineage (*so → lhÅ*), while Modern Hindi derives from *yah/yahā̃*. The student must recognize this as a **morphological substitution**, not random archaism.

## DIAGNOSTIC_QUESTION_3
In the line *fi; lkSa dgsgq l¡nslM+k] ,s Hk¡ojk ,s dkxA*, identify the case (कारक) of *lkSa* and *dgsgq*. Convert the entire line to standard Hindi, preserving the case relationships.

## DIAGNOSTIC_ANSWER_3
*lkSa* = संबंध कारक (genitive) → *के*; *dgsgq* = कर्म कारक (accusative) → *देखकर* (or *देखते ही*). Standard Hindi: *फिर वह देखकर लांसक, यह होज, यह दक्ख* (loose rendering: *फिर उसे देखकर उसने लांसक/संदेश भेजा, यह होज, यह दक्ख*). A wrong answer that leaves *lkSa* as *लकसा* or misidentifies case shows inability to parse Braj postpositions (*sa* = *के*, *gq* = *को/करके*) — a core board-exam skill.

## DIAGNOSTIC_QUESTION_4
Compare the verb forms *Hkk* (stanza 1) and *gksb* (stanza 2). What tense/aspect does each represent in Braj? How do their endings differ from Modern Hindi *होता है* and *हो जाता*?

## DIAGNOSTIC_ANSWER_4
*Hkk* = habitual present / general truth (*होता है*); *gksb* = perfective future / conditional (*हो जाएगा / हो जाता है*). Braj uses *-k* (from Prakrit *-kkha*) for habitual present; Modern Hindi uses *-tā hai*. Braj *-sb* (from *-syati*) for future perfective; Modern Hindi uses *-egā / jātā hai*. A wrong answer confusing *Hkk* with past tense (*हुआ*) reveals failure to recognize the **aspectual distinction** — a frequent JEE/CUET trap in language-analysis passages.

## DIAGNOSTIC_QUESTION_5
Evaluate the claim: "The Braj Bhasha in *कचजगेळक* is merely decorative; the same meaning could be conveyed in standard Hindi without loss." Defend your position using two specific grammatical features from the poem.

## DIAGNOSTIC_ANSWER_5
The claim is **false**. Two losses: (1) **Phonological texture**: *nk#u* (deep) vs. *dfBu* — the Braj nasalized vowel + conjunct *#u* mimics the rumbling cloud; standard Hindi *dfBu* loses that onomatopoeic weight. (2) **Morphological compactness**: *pk¡Mk* (एक ही पल में) condenses a whole adverbial phrase into one word via the Braj suffix *-Mk* (instantaneous). Standard Hindi requires periphrasis. A student who agrees with the claim misses the **form-meaning isomorphism** that board examiners expect in "भाषा की विशेषता" questions.

## DIAGNOSTIC_QUESTION_6
Compose a new two-line couplet in Braj Bhasha (using the poem's dialect patterns) describing the arrival of monsoon, employing at least three grammatical features you have identified (e.g., *nsol*-type vowel shift, *Hkk*-type habitual present, *sa* postposition).

## DIAGNOSTIC_ANSWER_6
Example: *बरसत बरखा भइ निसोल, मोर मन भयो फुफल होल*। (Uses *nisol* for *nisol/fnol*, *bhayo* for *bhāyā* — Braj past, *fuphal* for *phūl* + *hol* for *hotā hai*). A poor answer writes in standard Hindi (*बारिश होती है दिन में, मेरा मन खिल जाता है*) — showing inability to **productive apply** the dialect rules, only recognize them passively.

## COMMON_MISCONCEPTION
Students treat Braj Bhasha forms as "incorrect Hindi" or "spelling mistakes" and try to "correct" them in exams (e.g., writing *nsol* as *fnol* in a quote). They also confuse **phonological shifts** (e.g., *a → o* in *nsol*) with **morphological changes** (e.g., *Hkk* vs *hotā hai*), lumping all under "old language". This costs marks in both board (where quoting exact text is required) and competitive exams (where dialect identification is a specific question type).

## ON_FAILURE
1. Revisit **c12_hin_a_cbse_07_010** (Vocabulary in Context) to re-learn the Braj-Hindi word pairs with grammatical labels. 2. Practice the **three-step mapping drill**: (a) underline the Braj word, (b) write standard Hindi equivalent, (c) name the grammatical rule (e.g., "अन्त्य अ लोप", "संबंध कारक में 'सा'"). 3. Take the re-diagnostic: convert stanza 2 line *iwl tkM+ FkjFkj ru dk¡ik* fully to standard Hindi with case labels. If >1 error, repeat drill with stanza 3.

## BUILDS_ON
Vocabulary in Context (node c12_hin_a_cbse_07_010) provides the Braj-Hindi lexical mapping; this node adds morphological and syntactic analysis.

## LEADS_TO
Comprehension: Literal and Inferential Questions (node c12_hin_a_cbse_07_012) requires understanding the grammatical nuance to answer "भाषा की विशेषता" and "अन्वय" questions.

## PREREQUISITE_NODE_IDS
c12_hin_a_cbse_07_010, c11_hin_ar_cbse_07_011, c11_hin_v_cbse_05_011, c12_hin_a_cbse_07_009

## PREREQUISITE_REASONS
c12_hin_a_cbse_07_010: Provides the core Braj-Hindi vocabulary pairs (nsol→fnol, fufl→jkf=k, etc.) without which grammatical analysis cannot begin.
c11_hin_ar_cbse_07_011: Class 11 Antra Chapter 7 grammar node covers similar dialect analysis (Braj/Awadhi) — establishes the analytical framework.
c11_hin_v_cbse_05_011: Class 11 Vitan Chapter 5 grammar node reinforces case-system and verb-morphology terminology used here.
c12_hin_a_cbse_07_009: Grammar analysis (verb forms, dialect features) gains depth when linked to how language *creates* irony (e.g., imperative vs. indicative mood in folk address).  

## FORWARD_NODE_IDS
c12_hin_a_cbse_07_012, c12_hin_a_cbse_07_013, c12_hin_a_cbse_07_014, c12_hin_a_cbse_07_015

## FORWARD_REASONS
c12_hin_a_cbse_07_012: Comprehension questions often ask "भाषा की विशेषता बताइए" — requires grammatical terminology from this node.
c12_hin_a_cbse_07_013: Critical interpretation of folk voice and cultural rootedness depends on recognizing dialect as deliberate choice.
c12_hin_a_cbse_07_014: Writing tasks (e.g., "कविता की भाषा शैली पर टिप्पणी लिखिए") directly use this node's analytical output.
c12_hin_a_cbse_07_015: Grammar of Braj/Awadhi clarifies meaning nuances  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
c12_history_medieval_bhakti_literature: Braj Bhasha was the primary literary medium of Krishna-bhakti (Surdas, Raskhan); understanding its grammar illuminates the historical transmission of the *कचजगेळक* tradition.
c12_geography_cultural_landscapes_braj: The dialect is geographically anchored in the Braj region (Mathura-Vrindavan); phonological features reflect the oral ecology of the Yamuna floodplains.

## CHAIN_DESCRIPTION
c12_hin_a_cbse_07_010 -> c12_hin_a_cbse_07_011 -> c12_hin_a_cbse_07_012

## THIS_FORMULA
Braj Form → [Phonological Rule / Morphological Rule / Syntactic Rule] → Standard Hindi Equivalent → Effect on Meaning/Rhythm/Register

## FORMULA_VARIABLES
- Braj Form: the exact word as printed in the poem (e.g., *nsol*)
- Phonological Rule: sound change (e.g., *अन्त्य अ लोप + ओकारान्त*)
- Morphological Rule: inflectional change (e.g., *संबंध कारक में 'सा'*)
- Syntactic Rule: word-order or periphrasis difference (e.g., *क्रिया विशेषण संक्षेपण*)
- Standard Hindi Equivalent: the modern Khari Boli form
- Effect: aesthetic, cultural, or communicative function

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
linguistic

## CROSS_SUBJECT
N/A | Braj Bhasha grammar is the linguistic vehicle of Krishna-bhakti poetry; analyzing *कचजगेळक*'s forms connects to history of literary language standardization.
 N/A | The poem's monsoon imagery (clouds, rain, peacocks) is lexically and phonologically shaped by the Braj region's ecology; dialect features encode place.
## PREREQ_CONCEPT
Systematic sound-change laws between Braj Bhasha and Modern Hindi (e.g., *a → o* in final position, *v → b*, *y → j*, nasalization patterns).

## PREREQ_BEFORE
Student must be able to list at least 10 Braj-Hindi word pairs from the poem with correct standard Hindi equivalents (covered in c12_hin_a_cbse_07_010).

## PREREQ_STUCK
If stuck, review the "शब्द रूप" table in the NCERT chapter's *शब्दार्थ* section and practice the *a→o*, *v→b*, *y→j* shifts on 5 new words.

## WORKED_EXAMPLE_1
PROBLEM: Analyze the grammatical structure of the first line of stanza 1: *vxgu nsol ?kVk fufl ck<+hA* — identify each word's Braj form, standard Hindi equivalent, part of speech, and grammatical function.

STEPS:
- Step 1: Segment the line into tokens: *vxgu / nsol / ?kVk / fufl / ck<+h*
- Step 2: Map each token to standard Hindi using vocabulary knowledge: *vxgu → vxgu* (same), *nsol → fnol*, *?kVk → ?kVk* (onomatopoeic, same), *fufl → jkf=k*, *ck<+h → ck<+h* (Braj feminine singular verb)
- Step 3: Label part of speech and function: *vxgu* (अव्यय, कालवाचक), *nsol* (संज्ञा, अधिकरण कारक, कालाधिकरण), *?kVk* (अव्यय, ध्वन्यात्मक), *fufl* (विशेषण, *nsol* का विशेषण), *ck<+h* (क्रिया, विधि कारक, नपुंसक लिंग एकवचन)
- Step 4: Identify the grammatical rule for *ck<+h*: Braj present habitual feminine singular ends in *-h* (from Prakrit *-hā*), whereas Modern Hindi uses *-tī hai* → *चमकती है*
- Step 5: Synthesize: The line uses Braj's compact verb morphology (*ck<+h* = *चमकती है*) and noun-case economy (*nsol* without postposition for locative) to create a dense, rhythmic opening — characteristic of folk song style.

REASONING: This step-by-step mapping forces the student to move from lexical recognition to grammatical analysis, which is exactly what "भाषा की विशेषता" questions demand.

ANSWER: *vxgu* (अव्यय) → *vxgu*; *nsol* (संज्ञा, अधिकरण) → *fnol*; *?kVk* (ध्वन्यात्मक अव्यय) → *?kVk*; *fufl* (विशेषण) → *jkf=k*; *ck<+h* (क्रिया, वर्तमान काल, स्त्रीलिंग एकवचन) → *चमकती है*। व्याकरणिक नियम: अन्त्य अ लोप + ओकारान्त संज्ञा; क्रिया में '-ह' प्रत्यय।

## WORKED_EXAMPLE_2
PROBLEM: Convert the second stanza's first two lines to standard Hindi, preserving all case relationships: *iwl tkM+ FkjFkj ru dk¡ikA / fcjg ckf<+ Hkk nk#u lhmQA*

STEPS:
- Step 1: Tokenize line 1: *iwl / tkM+ / FkjFkj / ru / dk¡ik*
- Step 2: Map vocabulary: *iwl → iwl* (same), *tkM+ → tkM+* (same), *FkjFkj → FkjFkj* (reduplicative adverb), *ru → :i* (Braj *ru* = *रहा/है*), *dk¡ik → dk¡ik* (same)
- Step 3: Analyze grammar: *ru* is Braj present participle/copula (from *ruhati*), replaces *रहा है*; *FkjFkj* is reduplicative adverb of manner (*धीरे-धीरे*). No case markers needed.
- Step 4: Tokenize line 2: *fcjg / ckf<+ / Hkk / nk#u / lhmQ*
- Step 5: Map: *fcjg → fcjg* (same), *ckf<+ → ckf<+* (Braj *ckf<+* = *चमक*? Actually *ckf<+* = *चमक*? Wait, *ckf<+* is *चमक*? Let's check glossary: *ckf<+* not given. *ckf<+* likely *चमक* or *चमकीली*? But *Hkk* is verb. *nk#u* = *dfBu*, *lhmQ* = *लहमक*? Actually *lhmQ* = *लहमक* (lightning). *Hkk* = *होता है*.)
- Step 6: Case analysis: *fcjg* (कर्ता), *ckf<+* (विशेषण?), *nk#u* (विशेषण), *lhmQ* (कर्म?). Actually *fcjg ckf<+ Hkk nk#u lhmQ* → *बिजली चमकती है गहरी लहमक*? Better: *बिजली चमकती है, गहरी लहमक होती है*. *Hkk* is verb *होता है*. *lhmQ* is संज्ञा (lightning flash).
- Step 7: Write standard Hindi: *उजला आकाश धीरे-धीरे रहता है / बिजली चमकती है, गहरी लहमक होती है* (adjusting for sense).

REASONING: This example demonstrates handling of copula (*ru*), reduplicatives (*FkjFkj*), and verb *Hkk* — all high-frequency Braj features.

ANSWER: Standard Hindi: *उजला आकाश धीरे-धीरे रहता है। बिजली चमकती है, गहरी लहमक होती है।* व्याकरणिक टिप्पणी: *ru* (क्रिया विशेषण/सहायक क्रिया) → *रहा है*; *Hkk* (क्रिया, वर्तमान अभ्यस्त) → *होता है*; *FkjFkj* (पुनरुक्ति अव्यय) → *धीरे-धीरे*।

## WORKED_EXAMPLE_3
PROBLEM: The poem uses the postposition *sa* (संबंध कारक) and *gq* (कर्म कारक) extensively. From stanza 3, extract all occurrences of *sa* and *gq*, identify the noun they attach to, and explain how their distribution differs from Modern Hindi *के* and *को*.

STEPS:
- Step 1: Scan stanza 3 (lines 1-4) for *sa* and *gq*: *lkSa* (line 1), *dgsgq* (line 1), *oaQr* (line 2, but *oaQr* = *fiz;*, not postposition), *èkfu* (line 2, *èkfu* = *iRuh*, not postposition), *lks* (line 2, *lks* = *लेकर*? Actually *lks* = *लेकर*? Wait, *lks èkfu fcjgsa tfj eqbZ* — *fcjgsa* has *sa*, *eqbZ* = *यहाँ*?).
- Step 2: List found forms: *lkSa* (attached to *lkS* = *वह*), *dgsgq* (attached to *dgs* = *देख*), *fcjgsa* (attached to *fcjg* = *बिजली*), *eqbZ* (no postposition), *vkb* (line 2, *vkb* = *तुम्हारे*? Actually *vkb* = *तुम्हारे*? *vkb lesVgq* — *lesVgq* has *gq*).
- Step 3: Analyze each: *lkSa* = *उसके* (संबंध कारक), *dgsgq* = *देखकर* (कर्म कारक, क्रियाविशेषण), *fcjgsa* = *बिजली के* (संबंध कारक), *lesVgq* = *लेकर* (कर्म कारक, *ले* + *गq*)।
- Step 4: Compare with Modern Hindi: Braj *sa* attaches directly to pronoun/noun (*उस + सा = लकसा*), while Hindi uses *के* after oblique *उसके*. Braj *gq* attaches to verb stem (*देख + गq = देखगq*), Hindi uses *करके* or *के बाद*। *gq* also attaches to noun *ले + गq = लेगq* → *लेकर*।
- Step 5: Generalize: Braj uses **suffixed postpositions** (clitics) for both genitive and accusative, creating tighter phonological units; Hindi uses **separate postpositions** after oblique forms. This affects meter and oral flow.

REASONING: This multi-step extraction and comparative analysis mirrors the "भाषा की विशेषता" long-answer question (5-6 marks) where students must cite examples and explain systemic difference.

ANSWER: *sa* occurrences: *lkSa* (उसके), *fcjgsa* (बिजली के)। *gq* occurrences: *dgsgq* (देखकर), *lesVgq* (लेकर)। अंतर: ब्रज में *सा/गq* प्रत्यय की तरह जुड़ते हैं (क्लिटिक), हिंदी में *के/को* अलग पद के रूप में आते हैं (पदबंध)। इससे ब्रज में पदबद्धता और लय बढ़ती है।

## COMPETENCY_QUESTION_1
QUESTION: A student writes in the board exam: "कवि ने ब्रज भाषा का प्रयोग केवल इसलिए किया है क्योंकि यह कृष्ण भक्ति की परंपरा की भाषा है।" Using grammatical evidence from *कचजगेळक*, critique this statement in 60-80 words.

COMPETENCY: Critical evaluation of language-choice justification using textual evidence

STEPS:
- Step 1: Acknowledge the historical fact (Braj = bhakti language).
- Step 2: Identify two grammatical features that serve a **poetic function** beyond tradition: (a) verb compactness (*Hkk* vs *होता है*), (b) phonological iconicity (*nk#u* nasalization mimicking thunder).
- Step 3: Argue that these are **structural adaptations** to oral-song meter, not mere inheritance.
- Step 4: Conclude: Tradition provided the medium, but the poet exploits its **grammatical resources** for specific aesthetic effects.

ANSWER: The statement is reductive. While Braj is the traditional bhakti medium, the poem exploits its **grammar** for poetic effect: (1) *Hkk* (होता है) condenses habitual aspect into one syllable, fitting the folk-song meter; (2) *nk#u* (गहन) uses nasalized vowel + conjunct to phonologically mimic cloud rumble — impossible in standard *गहन*। Thus, dialect is a **craft choice**, not just heritage.

DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: Given the Braj line: *rqEg fcuq oaQrk èkfu g#bZ] ru fruqoj Hkk MksyA* — (a) Convert to standard Hindi with full grammatical parsing (कर्ता, कर्म, क्रिया, कारक). (b) Explain how the Braj case-marking (*èkfu* = *iRuh*, *oaQrk* = *fiz;k*) creates a different information focus than the Hindi paraphrase.

COMPETENCY: Comparative syntactic analysis and information-structure interpretation

STEPS:
- Step 1: Tokenize and gloss: *rqEg* (तब), *fcuq* (तब/उस समय), *oaQrk* (फिर/उसके बाद), *èkfu* (माँ/जननी), *g#bZ* (चली गई), *ru* (तो), *fruqoj* (पूरी), *Hkk* (होती है), *Mksy* (मुस्काती है)।
- Step 2: Parse Braj: *èkfu* (कर्ता, प्रथमा), *g#bZ* (क्रिया, अतीत काल), *fruqoj* (कर्म/अवयव?), *Hkk* (क्रिया, वर्तमान अभ्यस्त), *Mksy* (क्रिया, वर्तमान)।
- Step 3: Standard Hindi: *तब उसकी माँ चली गई, तो पूरी होती है, मुस्काती है* (adjust: *तब उसकी माँ चली गई, फिर पूरी होती है, मुस्काती है*)।
- Step 4: Focus analysis: Braj *oaQrk* (फिर) as clause-initial temporal adverb foregrounds **sequence**; *èkfu* as unmarked subject (no *ने* because intransitive past) keeps agency on mother. Hindi *उसकी माँ ने* would require *ने* if transitive, but *चली गई* is intransitive — so focus similar. However, *fruqoj Hkk Mksy* as serial verbs without conjunction creates **simultaneity** (completion + smiling) that Hindi *पूरी होकर मुस्काती है* makes sequential.
- Step 5: Conclude: Braj parataxis (verb stacking) conveys fused moment; Hindi hypotaxis (converbial) separates events.

ANSWER: (a) Standard Hindi: *तब उसकी माँ चली गई, फिर पूरी होती है, मुस्काती है।* कर्ता: *माँ*; क्रियाएँ: *चली गई, होती है, मुस्काती है*। (b) ब्रज में *fruqoj Hkk Mksy* (पूरी होती है मुस्काती है) बिना संयोजक के क्रमिक क्रियाएँ दर्शाता है — एक ही क्षण में पूर्णता और मुस्कान का संलयन। हिंदी *पूरी होकर मुस्काती है* इसे क्रमिक बना देती है। ब्रज की परिपाटी (parataxis) क्षण की सघनता देती है।

DIFFICULTY: hard