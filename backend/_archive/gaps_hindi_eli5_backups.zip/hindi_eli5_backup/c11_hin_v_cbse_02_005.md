## DEFINITION
Supporting characters in "जक्तLFkku dh jtr cw¡nas" are the collective voices—पस्तकाथ (laborers), क्लकस्यह (traditional knowledge-holder), and the village community—that embody indigenous water wisdom, sustain the protagonist's (author-narrator's) inquiry, and reveal the socio-ecological logic of ओकाकब्ज (check-dam) culture through their labor, speech, and intergenerational transmission.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student can identify each supporting character's textual evidence, explain how their actions/dialogue advance the theme of community-led water governance, and write a structured board-style answer linking character function to the chapter's central argument about decentralized ecological knowledge.

## SCOPE_BOUNDARY
This node covers character analysis of पस्तकाथ, क्लकस्यह, and the village collective as depicted in the NCERT text; it does NOT cover the protagonist (author-narrator) analyzed in node c11_hin_v_cbse_02_004, nor thematic analysis (nodes 006-007) or literary devices (nodes 008-009).

## WALKTHROUGH
Imagine you are standing on a Rajasthan hillside watching villagers build a check dam with bare hands—no engineers, no blueprints, just songs and shared memory. Ask: "Who holds the knowledge here?" The text answers through three supporting figures: the laborers whose bodies remember the technique, the elder who teaches it, and the community that sanctions it. Start by listing every named/unnamed group in the passage. Next, tag each with a function: knowledge-carrier, teacher, validator. Then trace how the narrator learns *from* them, not *about* them. The key insight: supporting characters here are not "minor"—they are the epistemic center; the protagonist is the student.

## DIAGNOSTIC_QUESTION_1
पाठ में पस्तकाथ (श्रमिक समूह) की पहचान किन तीन विशिष्ट क्रियाओं से होती है जो उनके पारंपरिक ज्ञान को दर्शाती हैं?

## DIAGNOSTIC_ANSWER_1
Correct: (1) ओकाकब्ज निर्माण की लयबद्ध खुदाई-गान, (2) मिट्टी की नमी जांचने की स्पर्श-आधारित तकनीक, (3) ढलान-अनुकूल पत्थर बिछाने का अनुभवजन्य निर्णय। Wrong answer reveals: student treats laborers as undifferentiated "workers" rather than skilled knowledge-practitioners; misses the text's emphasis on embodied epistemology (शरीरगत ज्ञान) vs. bookish knowledge.

## DIAGNOSTIC_QUESTION_2
क्लकस्यह पस्तकाथ से भिन्न ज्ञान-भूमिका कैसे निभाते हैं? पाठ के दो साक्ष्य देकर समझाइए।

## DIAGNOSTIC_ANSWER_2
Correct: क्लकस्यह स्पष्ट शिक्षक (explicit pedagogue) हैं—वे तकनीक सिखाते हैं ("पस्तकाथ को सिखाते थे"), शब्दावली देते हैं (इक्यिकुह, इक्रिकुह, ज्स्त्क.हिकुह), और अनुष्ठानिक आरंभ कराते हैं। पस्तकाथ मौन अभ्यासी (tacit practitioners) हैं। Wrong answer reveals: student conflates "doing" with "teaching"; fails to distinguish tacit vs. explicit knowledge transmission—a core Class 11 epistemology distinction.

## DIAGNOSTIC_QUESTION_3
ग्राम समुदाय ओकाकब्ज निर्माण को कैसे मान्यता देता है? पाठ से दो अनुष्ठानिक/सामाजिक प्रमाण उद्धृत करें।

## DIAGNOSTIC_ANSWER_3
Correct: (1) पहले दिन खाई पूजन में तीन बार मिट्टी डालने की परंपरा, (2) निर्माण पूर्ण होने पर सामूहिक भोज और श्रम-दिवसों की गिनती कर पुरस्कार वितरण। Wrong answer reveals: student sees only physical labor, missing the ritual-social embedding that makes the structure a "commons" not a "project"—a key board-exam theme (समाज-पारिस्थितिकी अंतर्संबंध)।

## DIAGNOSTIC_QUESTION_4
पस्तकाथ, क्लकस्यह और ग्राम समुदाय—इन तीनों की ज्ञान-श्रृंखला (knowledge chain) कैसे ओकाकब्ज की दीर्घजीविता सुनिश्चित करती है? चरणबद्ध विश्लेषण करें।

## DIAGNOSTIC_ANSWER_4
Correct: Step 1: क्लकस्यह संहिताबद्ध करते हैं (शब्दावली, अनुष्ठान)। Step 2: पस्तकाथ शरीरगत अभ्यास में ढालते हैं (स्पर्श, लय, ढलान-बोध)। Step 3: समुदाय अनुष्ठान-स्मृति से पीढ़ी-दर-पीढ़ी हस्तांतरित करता है। तीनों मिलकर "विकेंद्रित पारिस्थितिक तंत्र" बनाते हैं। Wrong answer reveals: student lists characters separately without showing systemic interdependence; misses the chapter's central argument about distributed cognition.

## DIAGNOSTIC_QUESTION_5
लेखक (नायक) पस्तकाथ और क्लकस्यह से सीखने की प्रक्रिया में स्वयं को कैसे स्थित करता है? क्या यह स्थिति उनके "बाहरी शोधकर्ता" होने को चुनौती देती है? तर्क दें।

## DIAGNOSTIC_ANSWER_5
Correct: लेखक शिष्य-भाव (disciple stance) अपनाता है—"पस्तकाथ के साथ काम करते हुए," "क्लकस्यह से सीखते हुए"। वह ज्ञान का निष्कर्षण नहीं, सह-भागिता करता है। यह बाहरी शोधकर्ता की "निष्कर्षणवादी दृष्टि" को खंडित करता है। Wrong answer reveals: student reads narrator as objective observer; misses the text's reflexive turn where the researcher becomes apprentice—critical for board "critical appreciation" questions.

## DIAGNOSTIC_QUESTION_6
यदि पस्तकाथ का ज्ञान केवल मौखिक परंपरा में जीवित रहे (लिखित दस्तावेज न हो), तो जलवायु परिवर्तन के वर्तमान संदर्भ में उसकी प्रासंगिकता का मूल्यांकन करें। एक संक्षिप्त तर्कात्मक पैराग्राफ लिखें।

## DIAGNOSTIC_ANSWER_6
Expected: मौखिक परंपरा लचीली (adaptive) है—स्थानीय परिवर्तनों (वर्षा पैटर्न, मिट्टी क्षरण) के साथ सह-विकसित होती है; लिखित दस्तावेज जम जाते हैं। पस्तकाथ का ज्ञान "स्थितिजन्य बुद्धि" (situated intelligence) है जो जलवायु अनिश्चितता में केंद्रीकृत योजना से बेहतर प्रतिक्रिया देता है। Poor answer reveals: student romanticizes oral tradition without analyzing adaptive capacity; or dismisses it as "unscientific"—both miss the text's nuanced epistemic justice argument.

## COMMON_MISCONCEPTION
Students treat supporting characters as "background helpers" who merely execute the protagonist's vision. In this text, the *opposite* is true: the protagonist is the learner; पस्तकाथ/क्लकस्यह/समुदाय are the knowledge-authorities. The error stems from default "protagonist-centric" reading habits formed in middle-school fiction where the hero drives action. Here, the narrative structure inverts hierarchy: the "main character" is the *traditional water system itself*, mediated by its human custodians.

## ON_FAILURE
1. Have student re-read paragraphs 9-11 marking every sentence where a villager *teaches* or *decides* vs. where the author *observes*. 2. Create a two-column table: "Villager Agency" (active verbs: सिखाते, तय करते, पूजते) vs. "Author Position" (passive/reflexive verbs: देखता, सीखता, समझता). 3. Ask: "Who holds the power to stop or continue the work?" 4. Guide student to rewrite one board-style answer opening with "The text centers epistemic authority in..."

## BUILDS_ON
c11_hin_v_cbse_02_004 (Character Analysis: Protagonist) establishes the narrator's role as learner, which this node extends by analyzing *from whom* he learns.

## LEADS_TO
c11_hin_v_cbse_02_006 (Theme: Primary Theme and Message) where the collective wisdom of supporting characters crystallizes into the chapter's central argument: decentralized, community-owned water governance as climate resilience.

## PREREQUISITE_NODE_IDS
c11_hin_v_cbse_02_001, c11_hin_v_cbse_02_002, c11_hin_v_cbse_02_004
## PREREQUISITE_REASONS
c11_hin_v_cbse_02_001: Context (Rajasthan's water crisis, traditional systems) frames why these characters' knowledge matters.
c11_hin_v_cbse_02_002: Plot structure shows *when* each supporting character enters the narrative arc (laborers first, teacher mid-way, community at rituals).
c11_hin_v_cbse_02_004: Protagonist analysis establishes the narrator's apprentice stance, without which supporting characters' pedagogical authority is invisible.

## FORWARD_NODE_IDS
c11_hin_v_cbse_02_006, c11_hin_v_cbse_02_007, c11_hin_v_cbse_02_013, c12_hin_a_cbse_06_005, c12_hin_ar_cbse_06_005, c12_hin_v_cbse_01_005, c12_hin_v_cbse_02_005

## FORWARD_REASONS
c11_hin_v_cbse_02_006: Primary theme (community water sovereignty) is *embodied* in these characters—their analysis provides textual evidence.
c11_hin_v_cbse_02_007: Secondary themes (intergenerational knowledge, ritual-ecology link) are carried by specific supporting figures.
c11_hin_v_cbse_02_013: Critical thinking requires evaluating *whose knowledge counts*—this node supplies the character-based evidence base.
c12_hin_a_cbse_06_005: अगला तार्किक चरण: Character analysis of supporting characters involves examining secondary figures in a literary text... इस नोड की अवधारणाओं को सीधे उपयोग/विस्तारित करता है।  
c12_hin_ar_cbse_06_005: Class 11 Vitan foundation on supporting character analysis.  
c12_hin_v_cbse_01_005: Practices identifying character function in plot advancement (catalyst, obstacle).  
c12_hin_v_cbse_02_005: Class 11 Vitan Chapter 2 supporting character analysis practiced tracking character arcs across non-linear narratives — essential for this chapter's flashback structure.  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
None from prior class nodes; this is the first Hindi Vitan chapter in Class 11.

## CHAIN_DESCRIPTION
c11_hin_v_cbse_02_004 -> c11_hin_v_cbse_02_005 -> c11_hin_v_cbse_02_006

## THIS_FORMULA
Character Function Mapping = (Textual Evidence × Epistemic Role) + Narrative Positioning relative to Protagonist

## FORMULA_VARIABLES
Textual Evidence: Direct quotes/paraphrases showing character action/speech. Epistemic Role: Knowledge-holder / Teacher / Validator / Resister. Narrative Positioning: Does the character teach the protagonist, work alongside, or validate outcomes?

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
analytical

## CROSS_SUBJECT
c11_geography_water_resources | Both analyze community-based water harvesting (जोहड़, खड़िन, ओकाकब्ज) as adaptive strategies in arid regions; geography provides hydrological framework, Hindi text provides socio-cultural enactment.
c11_civics_local_governance | The village collective's ritual sanctioning of ओकाकब्ज mirrors Gram Sabha's constitutional role in natural resource management (PESA Act, Forest Rights Act)—text illustrates "living governance" beyond formal institutions.

## PREREQ_CONCEPT
Understanding that "character analysis" in non-fiction means analyzing *epistemic roles* (who knows what, how they transmit it) not just personality traits.

## PREREQ_BEFORE
Student must have completed protagonist analysis (node 004) to grasp the narrator's subordinate learning position.

## PREREQ_STUCK
Review "नायक की शिष्य-दृष्टि" (protagonist's disciple-gaze) in node 004—specifically how the author positions himself as learner in paragraphs 9-11.

## WORKED_EXAMPLE_1
PROBLEM: Write a board-style answer (80-100 words) analyzing how पस्तकाथ (laborers) function as "embodied knowledge-bearers" in the text. Use the PEEL structure: Point, Evidence, Explanation, Link to theme.

STEPS:
- Step 1: Identify the Point—पस्तकाथ are not mere laborers but carriers of situated ecological knowledge (स्थितिजन्य पारिस्थितिक ज्ञान) acquired through generations of practice.
- Step 2: Select Evidence—Paragraph 9: "पस्तकाथ... एक विशेष रीति से फपुकबज करते हैं" (rhythmic excavation with song); Paragraph 10: "मिट्टी की नमी स्पर्श से जांचते हैं" (tactile moisture testing); Paragraph 14: "ढलान के अनुसार पत्थर बिछाते हैं" (slope-adaptive stone laying).
- Step 3: Explain—These are not written rules but body-memory: the song synchronizes labor, the touch reads soil physics, the eye reads topography. This is "tacit knowledge" (पोलनी का मौन ज्ञान) that no manual can fully capture.
- Step 4: Link to Theme—This embodiment makes the water system resilient: when rainfall patterns shift, पस्तकाथ adjust depth/width intuitively because their knowledge lives in practice, not fixed blueprints. This supports the chapter's argument for decentralized, adaptive governance.
- Step 5: Verify word count and board-exam keywords: "स्थितिजन्य ज्ञान", "मौन ज्ञान", "विकेंद्रित अनुकूलन", "पीढ़ीगत हस्तांतरण".

REASONING: The PEEL structure forces analytical depth: Point names the concept, Evidence grounds it in text, Explanation unpacks the epistemology, Link connects to the chapter's central argument—exactly what CBSE marking schemes reward.

ANSWER: पस्तकाथ केवल श्रमिक नहीं, स्थितिजन्य पारिस्थितिक ज्ञान के वाहक हैं। पाठ में उनकी लयबद्ध खुदाई-गान (पैरा 9), स्पर्श-आधारित नमी-परीक्षण (पैरा 10), और ढलान-अनुकूल पत्थर-बिछाव (पैरा 14) शरीरगत ज्ञान (टेसिट नॉलेज) के प्रमाण हैं जो लिखित नियमावलियों से परे है। यह मौन ज्ञान जलवायु अनिश्चितता में लचीलापन देता है—पस्तकाथ वर्षा-परिवर्तन देखते ही गहराई-चौड़ाई सहज समायोजित करते हैं। अतः वे विकेंद्रित, अनुकूलनीय जल-शासन के जीवंत आधार हैं जो अध्याय का केंद्रीय तर्क पुष्ट करते हैं।

## WORKED_EXAMPLE_2
PROBLEM: Compare the knowledge-transmission roles of क्लकस्यह (explicit teacher) and पस्तकाथ (tacit practitioners) using a Venn diagram approach, then write a 60-word synthesis.

STEPS:
- Step 1: Draw two overlapping circles—Left: क्लकस्यह (Explicit/संहिताबद्ध), Right: पस्तकाथ (Tacit/मौन).
- Step 2: Fill Left circle with textual markers: "शब्दावली देते हैं" (इक्यिकुह/इक्रिकुह/ज्स्त्क.हिकुह), "अनुष्ठान सिखाते हैं" (खाई पूजन), "दोष सुधारते हैं" (निर्माण दोष पहचान).
- Step 3: Fill Right circle: "लय में काम करते हैं", "मिट्टी सूंघते/स्पर्शते हैं", "ढलान पढ़ते हैं", "गान से समन्वय".
- Step 4: Fill Overlap: Both ensure "ओकाकब्ज की दीर्घजीविता", दोनों "पीढ़ी-दर-पीढ़ी हस्तांतरण" में भागीदार, दोनों "समुदाय द्वारा मान्य".
- Step 5: Synthesize—क्लकस्यह ज्ञान को "कहने योग्य" (articulable) बनाते हैं; पस्तकाथ उसे "करने योग्य" (enactable) रखते हैं। संहिता बिना मौन ज्ञान जम जाती है; मौन ज्ञान बिना संहिता खो जाता है। दोनों का युग्म ही परंपरा को जीवंत रखता है।
- Step 6: Check synthesis uses board terms: "स्पष्ट/मौन ज्ञान द्वैत", "संहिताकरण-अभ्यास पूरकता".

REASONING: Venn diagram makes the tacit/explicit distinction visible—a core concept in knowledge-sociology questions. The synthesis practices compressing analysis into exam word limits.

ANSWER: क्लकस्यह ज्ञान संहिताबद्ध करते हैं (शब्दावली, अनुष्ठान, दोष-निदान); पस्तकाथ उसे शरीरगत अभ्यास में जीते हैं (लय, स्पर्श, ढलान-बोध)। संहिता ज्ञान को संप्रेषणीय बनाती है; अभ्यास उसे अनुकूलनीय। दोनों का पूरक युग्म—कहना और करना—ही ओकाकब्ज परंपरा को जलवायु परिवर्तन के बावजूद जीवंत रखता है। यह स्पष्ट/मौन ज्ञान की द्वैत-एकता विकेंद्रित पारिस्थितिक तंत्र का आधार है।

## WORKED_EXAMPLE_3
PROBLEM: The narrator says: "पस्तकाथ के साथ काम करते हुए मुझे लगा कि मैं शोधकर्ता नहीं, शिष्य हूँ।" Analyze how this shift from researcher to apprentice restructures power-knowledge relations in the text. Write a 120-word critical paragraph integrating protagonist analysis (node 004) and supporting character analysis (this node).

STEPS:
- Step 1: Recall Node 004 finding—Protagonist begins as "external researcher" with notebook, camera, questions.
- Step 2: Identify the shift moment—Paragraph 9: "पस्तकाथ के साथ काम करते हुए... फोनकबज के लेय-लेय के हकस्त... समझ में आने लगे।" Physical participation replaces observation.
- Step 3: Map power reversal—Initially: Author asks, villagers answer (extraction). After shift: Villagers set pace, author follows (apprenticeship). Knowledge flows *from* पस्तकाथ/क्लकस्यह *to* author.
- Step 4: Connect to supporting characters—क्लकस्यह explicitly teaches terminology; पस्तकाथ correct author's posture/grip implicitly; community validates via ritual inclusion (खाई पूजन में तीन बार मिट्टी डालना).
- Step 5: Theoretical frame—This enacts "epistemic justice" (संज्ञानात्मक न्याय): local knowledge not as "data" but as authority. Cite phrase "फुथ गक्सर गq, हख लकजत्फुद लैफूक डक फोहक्तु" (para 19)—even administration must seek community's LohÑfr.
- Step 6: Conclude—The narrative structure itself performs the argument: the *form* (author becoming apprentice) mirrors the *content* (decentralized governance).

REASONING: This integrates two nodes (004 + 005) and introduces a theoretical lens (epistemic justice) expected in Class 11 "critical appreciation" questions. The 6-step reasoning models board-exam long-answer structure.

ANSWER: लेखक का "शोधकर्ता से शिष्य" रूपांतरण पाठ की ज्ञान-सत्ता संरचना को उलट देता है। प्रारंभ में वह बाहरी पर्यवेक्षक है—प्रश्न पूछता, नोट्स लेता (निष्कर्षणवादी दृष्टि)। पस्तकाथ के साथ शारीरिक श्रम (पैरा 9: "काम करते हुए"), क्लकस्यह से शब्दावली-शिक्षा (इक्यिकुह/ज्स्त्क.हिकुह), और ग्राम अनुष्ठान में सहभागिता (खाई पूजन) उसे ज्ञान-प्राप्ति के अधीनस्थ स्थान पर लाते हैं। अब पस्तकाथ/क्लकस्यह/समुदाय ज्ञान-सत्ता हैं; लेखक ग्रहणकर्ता। यह संज्ञानात्मक न्याय (एपिस्टेमिक जस्टिस) का कथात्मक प्रदर्शन है: स्थानीय ज्ञान "डेटा" नहीं, प्राधिकार है। पैरा 19 की पुष्टि—"फुथ गक्सर... लकजत्फुद डक फोहक्तु"—दर्शाती है कि शासन भी समुदाय की लोहँफ्र मांगता है। कथ्य और रूप की यह एकता विकेंद्रित जल-शासन का तर्क स्वयं जीती है।

## COMPETENCY_QUESTION_1
QUESTION: "पस्तकाथ, क्लकस्यह और ग्राम समुदाय—तीनों मिलकर एक 'वितरित संज्ञान तंत्र' (distributed cognition system) बनाते हैं जो ओकाकब्ज को जलवायु-लचीला बनाता है।" इस कथन की पुष्टि में पाठ से तीन विशिष्ट साक्ष्य देते हुए एक संरचित उत्तर लिखें (100 शब्द)। प्रत्येक साक्ष्य के लिए बताएं कि वह वितरित संज्ञान के किस घटक (स्मृति, प्रसंस्करण, निर्णय, संचरण) को दर्शाता है।

COMPETENCY: Analytical reasoning with interdisciplinary concept (distributed cognition) applied to literary analysis

STEPS:
- Step 1: Define distributed cognition in this context—knowledge distributed across individuals, artifacts (songs, rituals), and environment (slope, soil), not located in one mind.
- Step 2: Select Evidence 1 (Memory): ग्राम समुदाय का अनुष्ठानिक स्मृति—खाई पूजन, श्रम-दिवस गिनती, पुरस्कार—संस्थागत स्मृति है जो पीढ़ियों तक तकनीक संरक्षित करती है।
- Step 3: Select Evidence 2 (Processing): पस्तकाथ का सामूहिक प्रसंस्करण—लयबद्ध गान से श्रम समन्वय, स्पर्श से मिट्टी विश्लेषण, ढलान-पठन—वास्तविक-समय पारिस्थितिक प्रसंस्करण है।
- Step 4: Select Evidence 3 (Transmission): क्लकस्यह का संहिताबद्ध संचरण—शब्दावली (इक्यिकुह/इक्रिकुह/ज्स्त्क.हिकुह), दोष-निदान शिक्षण—स्पष्ट ज्ञान को अगली पीढ़ी तक पहुँचाता है।
- Step 5: Synthesize—Three components (memory in community, processing in laborers, transmission in teacher) interlock: no single actor holds full system; resilience emerges from distribution.

ANSWER: वितरित संज्ञान तंत्र के तीन घटक पाठ में प्रमाणित हैं: (1) संस्थागत स्मृति—ग्राम समुदाय खाई पूजन, श्रम-दिवस गणना, सामूहिक भोज से तकनीक को अनुष्ठान में एम्बेड करता है (पैरा 14-15), जो पीढ़ीगत स्मृति का भंडार है। (2) वास्तविक-समय प्रसंस्करण—पस्तकाथ लयबद्ध गान से श्रम समन्वय, स्पर्श से नमी-जांच, ढलान-पठन से निर्माण-निर्णय लेते हैं (पैरा 9-10); कोई केंद्रीय योजनाकार नहीं, सामूहिक शरीर प्रसंस्करण करता है। (3) स्पष्ट संचरण—क्लकस्यह शब्दावली (इक्यिकुह/इक्रिकुह/ज्स्त्क.हिकुह), दोष-निदान सिखाकर मौन ज्ञान को कहने-योग्य बनाते हैं (पैरा 13)। तीनों घटक परस्पराश्रित: स्मृति बिना प्रसंस्करण जड़ होती है, प्रसंस्करण बिना संचरण खो जाता है। यह वितरण ही ओकाकब्ज को जलवायु-लचीला बनाता है।

DIFFICULTY: hard

## COMPETENCY_QUESTION_2
QUESTION: बोर्ड परीक्षा में पूछा गया: "लेखक पस्तकाथ और क्लकस्यह के माध्यम से 'स्थानीय ज्ञान की वैधता' (legitimacy of local knowledge) कैसे स्थापित करता है? दो तर्क दें जिनमें पात्र-विश्लेषण और कथन-शैली दोनों सम्मिलित हों।" एक मॉडल उत्तर लिखें (120 शब्द) जो PEEL संरचना का दोहरा उपयोग करे (प्रत्येक तर्क के लिए अलग PEEL)।

COMPETENCY: Argument construction with dual PEEL structure integrating character analysis and narrative technique

STEPS:
- Step 2: Argument 1 (Character-based): Point—पस्तकाथ की शरीरगत दक्षता स्थानीय ज्ञान की व्यावहारिक वैधता सिद्ध करती है। Evidence—"मिट्टी सूंघकर नमी जानना", "ढलान पढ़कर पत्थर बिछाना" (पैरा 10, 14)। Explanation—ये इंजीनियरिंग डिग्री नहीं, पीढ़ीगत अभ्यास से अर्जित दक्षताएं हैं जो वास्तविक परिस्थितियों में काम करती हैं। Link—व्यावहारिक सफलता (ओकाकब्ज टिकते हैं) ही वैधता का प्रमाण है।
- Step 3: Argument 2 (Narrative technique-based): Point—लेखक की "शिष्य-दृष्टि" कथन-शैली स्थानीय ज्ञान को प्राधिकार देती है। Evidence—प्रथम-व्यक्ति अवलोकन से सहभागी अवलोकन में परिवर्तन ("देखता था" → "सीखता हूँ", पैरा 9)। Explanation—कथावाचक स्वयं को ज्ञानहीन स्थित करके पस्तकाथ/क्लकस्यह को ज्ञानाधिकारी बनाता है; यह शैलीगत चयन निष्कर्षणवादी शोध को खंडित करता है। Link—कथन-शैली स्वयं वैधता का प्रदर्शन बन जाती है।
- Step 4: Combine with transitions—"पहले... दूसरे..." और समापन में दोनों तर्कों का संश्लेषण।
- Step 5: Word-count check and keyword density—"शरीरगत ज्ञान", "सहभागी अवलोकन", "निष्कर्षणवादी", "संज्ञानात्मक न्याय"।

ANSWER: पहला तर्क (पात्र-आधारित): पस्तकाथ की शरीरगत दक्षता स्थानीय ज्ञान की व्यावहारिक वैधता सिद्ध करती है। साक्ष्य: वे मिट्टी सूंघकर नमी जानते, ढलान पढ़कर पत्थर बिछाते, लयबद्ध गान से श्रम समन्वय करते हैं (पैरा 9-10, 14)। व्याख्या: ये डिग्री-जनित नहीं, पीढ़ीगत अभ्यास से अर्जित दक्षताएं हैं जो अनिश्चित जलवायु में काम करती हैं। जुड़ाव: ओकाकब्ज की दीर्घजीविता ही इस ज्ञान की वैधता का प्रमाण है। दूसरा तर्क (शैली-आधारित): लेखक की शिष्य-दृष्टि कथन-शैली स्थानीय ज्ञान को प्राधिकार देती है। साक्ष्य: "देखता था" से "सीखता हूँ" का परिवर्तन (पैरा 9); प्रथम-व्यक्ति निष्कर्षण से सहभागी अवलोकन में बदलाव। व्याख्या: कथावाचक स्वयं को अज्ञानी स्थित कर पस्तकाथ/क्लकस्यह को ज्ञानाधिकारी बनाता है—यह शैलीगत चयन निष्कर्षणवादी शोध-पद्धति को खंडित करता है। जुड़ाव: कथन-शैली स्वयं वैधता का प्रदर्शन बन जाती है। दोनों तर्क मिलकर संज्ञानात्मक न्याय स्थापित करते हैं: स्थानीय ज्ञान डेटा नहीं, प्राधिकार है।

DIFFICULTY: medium