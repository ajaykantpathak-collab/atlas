## DEFINITION
Imagery is the use of vivid, sensory language that appeals to the five senses (sight, sound, touch, taste, smell) to create mental pictures and evoke emotions. Metaphor is a figure of speech that directly compares two unrelated things by stating one *is* the other, transferring qualities from the *vehicle* (the image used) to the *tenor* (the subject) without using "like" or "as". In these poems, imagery makes abstract pain or patriotism tangible, while metaphors condense complex ideas into powerful, compact symbols.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student can independently identify specific images and metaphors in both poems, classify the sensory mode of each image, deconstruct the tenor-vehicle-ground of each metaphor, and write a structured PEEL paragraph explaining how each device reinforces the poem's central theme.

## SCOPE_BOUNDARY
This node covers **only** imagery (visual, auditory, tactile, thermal, kinesthetic) and metaphor (explicit and implicit) as they appear in the two poems of Chapter 1: "nsolsuk dk xhr" and "dkusZfy;k dk xhr". It does **not** cover simile, personification, irony, symbolism, or other rhetorical devices (those are in node c12_hin_a_cbse_01_009). It also does not cover grammatical analysis or vocabulary meanings (covered in nodes 010, 011).

## WALKTHROUGH
Imagine you are reading "nsolsuk dk xhr" and suddenly *feel* the heat of "Hkzeo'k thou lafpr" on your skin, or hear the silent scream in "vkg! osnuk feyh fonkbZ!" — that is imagery working. To begin, read the poem aloud twice: first for flow, second with a pencil marking every word that triggers a sensation (burning, thorn, stone, lamp, stream). Next, circle every direct comparison where the poet says X *is* Y (e.g., "vk'kk ckoyh"). For each, ask: what is the subject (tenor)? what is the image (vehicle)? what shared quality (ground) links them? Finally, connect each device to the poem's core message: nsolsuk's inexpressible agony or the nation's awakening. The key insight: imagery makes the reader *experience* the emotion; metaphor makes the reader *understand* the abstract through the concrete.

## DIAGNOSTIC_QUESTION_1
Define "imagery" and "metaphor" in your own words, giving one example of each from "nsolsuk dk xhr" without quoting the poem verbatim.

## DIAGNOSTIC_ANSWER_1
Imagery: sensory language creating mental pictures (e.g., the description of extinguished lamps evoking darkness and lost hope). Metaphor: direct comparison without 'like/as' (e.g., tears described as a stream/river). A wrong answer that gives a simile ("tears *like* a stream") reveals confusion between metaphor and simile. An answer listing only visual images reveals the misconception that imagery is only visual.

## DIAGNOSTIC_QUESTION_2
In "nsolsuk dk xhr", the line "eSaus fut nqcZy in&cy ij mlls gkjh&gksM+ yxkbZ" uses two metaphors. Identify the tenor, vehicle, and ground for *each* metaphor and explain why the poet chooses *both* a thorn and a stone.

## DIAGNOSTIC_ANSWER_2
First metaphor: tenor = life's path/suffering, vehicle = "nqcZy in cy" (sharp thorn on a tender shoot), ground = piercing, unexpected pain that wounds something delicate. Second metaphor: tenor = burden of existence, vehicle = "gkjh gksM+" (heavy stone), ground = crushing weight, immobility. The poet uses both to show pain's dual nature: sharp/stabbing (thorn) and constant/oppressive (stone). A wrong answer that merges them into one metaphor or misses the "tender shoot" nuance shows failure to unpack layered imagery.

## DIAGNOSTIC_QUESTION_3
Apply the concept of thermal imagery to "dkusZfy;k dk xhr". Find two thermal images (heat/cold) in the poem, quote the key words, and explain how they contrast to build the poem's emotional arc.

## DIAGNOSTIC_ANSWER_3
1. "rkejl" (blood-red, intense heat) — suggests passionate sacrifice, revolutionary fervour. 2. "ey; lehj" (cool, soothing wave of love) — suggests healing, inclusivity. The arc moves from fiery struggle to cool harmony. A student who only finds "rkejl" and misses "ey; lehj" or misreads "lehj" as heat shows inability to track thermal contrasts across stanzas.

## DIAGNOSTIC_QUESTION_4
Compare the function of the "lamp" metaphor in "nsolsuk dk xhr" ("eèkqdfj;ksa dh Hkh[k yqVkbZ") with the "boatman" metaphor in "dkusZfy;k dk xhr" ("efnj m¡Q?krs jgrs tc"). How does each metaphor's vehicle shape the reader's understanding of the tenor?

## DIAGNOSTIC_ANSWER_4
Lamp metaphor: tenor = hopes/dreams, vehicle = extinguished lamp, ground = sudden, irreversible loss of light/guidance → conveys finality and darkness. Boatman metaphor: tenor = destiny/guide, vehicle = "efnj" (ferryman steering across world-ocean), ground = trustworthy navigation through turbulence → conveys active guidance and hope. A wrong answer that treats both as mere decoration misses how vehicle choice dictates emotional tone (despair vs. trust).

## DIAGNOSTIC_QUESTION_5
Evaluate this claim: "The metaphor 'vk'kk ckoyh' (tears are a stream) in 'nsolsuk dk xhr' is more effective than 'vk'kk [kks nh ldy dekbZ' (tears gave two lazy glances) because the former is a noun-metaphor while the latter is a verb-metaphor." Defend or refute with textual reasoning.

## DIAGNOSTIC_ANSWER_5
Refute. Effectiveness depends on *context*, not grammatical form. "ckoyh" (noun) freezes grief into a vast, flowing landscape — endless, natural. "[kks nh ldy dekbZ" (verb phrase) personifies tears as reluctant witnesses — lazy, indifferent, highlighting the world's apathy. Both are powerful *because* they serve different moments: one expands grief to cosmic scale, the other isolates the sufferer. A student who agrees based on "noun > verb" shows rigid rule-based thinking instead of contextual analysis.

## DIAGNOSTIC_QUESTION_6
Create two original metaphors for "patriotism" — one using a *natural element* (fire, water, seed, mountain) and one using a *human role* (mother, guard, weaver, lamp). For each, state the tenor, vehicle, and ground explicitly.

## DIAGNOSTIC_ANSWER_6
Example 1: Patriotism is a **banyan seed** (tenor=patriotism, vehicle=banyan seed, ground=small beginning grows into vast shelter for generations). Example 2: Patriotism is a **night-watchman** (tenor=patriotism, vehicle=night-watchman, ground=silent, sleepless vigilance protecting others while they sleep). A poor answer uses similes ("like a seed") or fails to articulate the ground, showing the student cannot *construct* the device they only *identify*.

## COMMON_MISCONCEPTION
Students believe **imagery = only visual description** and **metaphor = any comparison**. They write "the poet uses imagery to describe the fire" (naming the object, not the sensory effect) and call "thou lafpr" a metaphor because "life is compared to a finished task" — but "thou lafpr" is a literal statement (life *has* ended), not a figurative transfer. They also confuse metaphor with personification (e.g., calling "ckoyh" personification because a stream "flows"). The root error: they hunt for *labels* instead of analyzing *how the vehicle reshapes the tenor*.

## ON_FAILURE
1. **Revisit sensory listing**: Take any stanza, list *only* words triggering non-visual senses (sound of "vkg!", touch of "gkjh gksM+", heat of "rkejl"). 2. **Metaphor surgery**: For each metaphor, write "Tenor = ___ ; Vehicle = ___ ; Ground = ___". If ground is vague ("they are similar"), the metaphor is not understood. 3. **Re-diagnostic**: Attempt Diagnostic Questions 2 & 4 again, this time writing the tenor-vehicle-ground table before answering. 4. **Peer check**: Swap tables with a partner; if they cannot guess the metaphor from your ground alone, refine the ground.

## BUILDS_ON
Class 11 understanding of basic poetic devices (imagery, metaphor, simile) from multiple chapters (e.g., c11_hin_ar_cbse_01_008, c11_hin_ar_cbse_02_008).

## LEADS_TO
Analysis of irony and symbolism in the same poems (c12_hin_a_cbse_01_009), where metaphors often *become* symbols.

## PREREQUISITE_NODE_IDS
c11_hin_ar_cbse_01_008, c11_hin_v_cbse_01_008, c12_hin_a_cbse_01_001, c12_hin_a_cbse_01_002, c12_hin_a_cbse_01_003, c12_hin_a_cbse_01_006, c12_hin_a_cbse_01_007, c11_hin_ar_cbse_02_008

## PREREQUISITE_REASONS
c11_hin_ar_cbse_01_008: Introduced imagery/metaphor identification in Class 11 Antra Chapter 1; this node deepens to analysis.  
c11_hin_v_cbse_01_008: Reinforced device recognition in Vitan prose/poetry; provides cross-genre practice.  
c12_hin_a_cbse_01_001: Context/background of t;'kadj izlkn and the poems' historical setting is essential to interpret metaphors like "eèkqe; ns'k".  
c12_hin_a_cbse_01_002: Narrative structure of each poem (where the metaphor appears) determines its function — climax vs. resolution.
c12_hin_a_cbse_01_003: Imagery and metaphor are the primary tools constructing setting-atmosphere (studied here, named there)  
c12_hin_a_cbse_01_006: Imagery/metaphor analysis (node 008) requires the thematic anchor to avoid device-spotting.  
c12_hin_a_cbse_01_007: Imagery and metaphor are the primary vehicles of secondary themes — this node provides the *what*, next node teaches the *how*.  
c11_hin_ar_cbse_02_008: Class 11 understanding of basic poetic devices (imagery, metaphor, simile) from multiple chapters (e.g., c11_hin_ar_cbse_01_008, c11_hin_ar_cbse_02_008).  

## FORWARD_NODE_IDS
c12_hin_a_cbse_01_009, c12_hin_a_cbse_01_012, c12_hin_a_cbse_01_013, c12_hin_a_cbse_01_011, c12_hin_a_cbse_01_014, c12_hin_a_cbse_01_015

## FORWARD_REASONS
c12_hin_a_cbse_01_009: Irony and symbolism often extend the metaphors studied here (e.g., the "lamp" becomes a symbol of extinguished hope).  
c12_hin_a_cbse_01_012: Comprehension questions require citing imagery/metaphor as evidence for inferential answers.  
c12_hin_a_cbse_01_013: Critical thinking tasks demand evaluation of device effectiveness — built on the analysis practiced here.
c12_hin_a_cbse_01_011: Imagery and metaphor often rely on grammatical choices (e.g., participial adjectives).  
c12_hin_a_cbse_01_014: Imagery/metaphor identification supplies Evidence for PEEL paragraphs  
c12_hin_a_cbse_01_015: Imagery analysis (हज्जाम, ईंज, रकेल, रोटी) supplies the concrete textual evidence required in ASL.  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
No prior-class nodes from other subjects are listed in the provided data.

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_01_008 -> c12_hin_a_cbse_01_008 -> c12_hin_a_cbse_01_009

## THIS_FORMULA
Metaphor Analysis Template: **Tenor (Subject) + Vehicle (Image) = Ground (Shared Quality) → Effect (Emotional/Intellectual)**. Imagery Classification: **Sensory Mode (Visual/Auditory/Tactile/Thermal/Kinesthetic/Olfactory/Gustatory) + Intensity Word + Contextual Function**.

## FORMULA_VARIABLES
- Tenor: The abstract concept or literal subject being described (e.g., "grief", "nation").  
- Vehicle: The concrete image used to describe the tenor (e.g., "stream", "seed").  
- Ground: The specific shared attribute(s) that make the comparison work (e.g., "continuous flow", "potential to grow").  
- Effect: The resulting emotional or intellectual impact on the reader (e.g., "universalizes grief", "suggests organic growth").  
- Sensory Mode: Which sense the imagery primarily activates.  
- Intensity Word: The modifier that scales the image (e.g., "nqcZy" sharp, "gkjh" heavy).  
- Contextual Function: What the image *does* at that point in the poem (e.g., "opens the poem with shock", "closes with resolve").

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
analytical

## CROSS_SUBJECT
N/A | The metaphor "eèkqe; ns'k" (awakened nation) in "dkusZfy;k dk xhr" directly parallels the historical concept of nationalist awakening in Class 12 History (Ch. "Nationalism in India") — both use organic awakening imagery to describe political consciousness.  
 N/A | The tactile/thermal imagery ("rkejl", "ey; lehj") maps onto geography's "cultural landscape" concept where physical terrain (blood-red soil, cooling waves) becomes a metaphor for collective identity and emotional geography.
## PREREQ_CONCEPT
Ability to distinguish literal vs. figurative language and name the five sensory modes.

## PREREQ_BEFORE
Student must know that a metaphor asserts identity (A *is* B) while a simile asserts similarity (A *is like* B), and that imagery is not limited to sight.

## PREREQ_STUCK
If stuck, review Class 11 node c11_hin_ar_cbse_01_008 (Literary Devices: Imagery and Metaphor) and re-do its worked examples on "identifying sensory words" and "tenor-vehicle-ground".

## WORKED_EXAMPLE_1
PROBLEM: Analyze the thermal and tactile imagery in the opening stanza of "nsolsuk dk xhr" ("eSaus Hkzeo'k thou lafpr] eèkqdfj;ksa dh Hkh[k yqVkbZ..."). Show how the imagery establishes the poem's emotional baseline.

STEPS:
- Step 1: Read the stanza aloud; mark every word that evokes a physical sensation — "Hkzeo'k" (burnt/consumed), "lafpr" (ended/finished), "Hkh[k" (extinguished), "yqVkbZ" (put out). Note: no visual words like "saw"; all are thermal/tactile verbs.
- Step 2: Classify each: "Hkzeo'k" = thermal (heat/fire), "lafpr" = kinesthetic (cessation of movement), "Hkh[k/yqVkbZ" = thermal + tactile (touch of putting out a flame).
- Step 3: Identify the tenor: the speaker's life ("thou") and hopes ("eèkqdfj;ksa"). The vehicle is fire/lamp. Ground: life and hope are fragile flames; suffering consumes them.
- Step 4: Explain the effect: The accumulation of *extinguishing* verbs (lafpr, yqVkbZ) creates a sense of finality and coldness after heat. The absence of visual imagery forces the reader to *feel* the loss internally, not observe it externally.
- Step 5: Connect to theme: This sensory baseline makes the later metaphor "vk'kk ckoyh" (tears = stream) inevitable — the fire is out, only the water remains.

REASONING: Starting with sensory classification prevents vague "imagery of fire" answers. The step-by-step tenor-vehicle-ground mapping shows *how* the metaphor works, not just *that* it exists. Linking the opening imagery to the poem's trajectory demonstrates structural awareness.

ANSWER: The stanza uses exclusively thermal/kinesthetic imagery (burnt, ended, extinguished) to embody the speaker's inner state. The metaphor "life = flame, hopes = lamps" transfers fragility and irreversibility. The effect is visceral: the reader experiences the *aftermath* of burning — cold, still, dark — setting up the poem's central paradox: a scream ("vkg!") from a silenced life.

## WORKED_EXAMPLE_2
PROBLEM: Deconstruct the extended metaphor in "dkusZfy;k dk xhr": "tgk¡ igq¡p vutku f{kfrt dks feyrk ,d lgkjk" (where past and future meet in an embrace). Identify tenor, vehicle, ground, and explain why "embrace" (lgkjk) is chosen over "meeting" or "junction".

STEPS:
- Step 1: Locate the lines: Stanza 1, "tgk¡ igq¡p vutku f{kfrt dks feyrk ,d lgkjk". Tenor = the nation (ns'k) / time in the nation. Vehicle = "lgkjk" (embrace/hug). Ground = intimacy, warmth, mutual acceptance, physical closeness.
- Step 2: Contrast with alternatives: "meeting" (miln) = formal, neutral; "junction" (sMgaam) = mechanical, spatial. "Embrace" implies *emotional* reconciliation — the past is not discarded, the future not feared; they hold each other.
- Step 3: Analyze the modifier "igq¡p" (here/now) and "feyrk" (giving/presenting). The embrace is *active* and *gift-like* — the nation *offers* this synthesis.
- Step 4: Link to surrounding imagery: "rkejl" (blood-red) and "ey; lehj" (love-wave) frame the embrace with sacrifice and compassion. The embrace is the *method* by which blood becomes love.
- Step 5: State the effect: The metaphor transforms an abstract historical process (synthesis of tradition and modernity) into a human, tender act — making patriotism feel like care, not duty.

REASONING: This example models the "vehicle choice matters" principle. By comparing "embrace" to rejected alternatives, the student sees metaphor as a *deliberate selection* with semantic consequences. The step linking to neighboring images shows how metaphors cluster to build a thematic network.

ANSWER: Tenor = the nation's temporal synthesis (past+future). Vehicle = embrace (lgkjk). Ground = intimate, voluntary, warm acceptance. "Embrace" is chosen because it conveys *love* and *wholeness* — the past is not a burden but a partner. This metaphor is the poem's emotional core: nationalism as an act of affection, not force.

## WORKED_EXAMPLE_3
PROBLEM: Compare the use of **nature-as-metaphor** in both poems. In "nsolsuk dk xhr": "nqcZy in cy" (thorn on tender shoot), "gkjh gksM+" (heavy stone). In "dkusZfy;k dk xhr": "rkejl" (blood-red like rkejl flower), "ey; lehj" (wave of love). Write a comparative paragraph (4-5 sentences) using the PEEL structure.

STEPS:
- Step 1 (Point): Both poems use nature metaphors, but "nsolsuk" uses *flora/mineral* to express *individual suffering*, while "dkusZfy;k" uses *flora/hydro* to express *collective aspiration*.
- Step 2 (Evidence): "nsolsuk": "nqcZy in cy" (plant thorn) + "gkjh gksM+" (stone) — both inert, damaging, imposed. "dkusZfy;k": "rkejl" (flower/red) + "ey; lehj" (water wave) — both dynamic, life-giving, chosen.
- Step 3 (Explanation): The thorn/stone are *passive* obstacles that pierce/crush the sufferer; the flower/wave are *active* forces that color/cleanse the land. The ground differs: pain's sharpness/weight vs. patriotism's vitality/flow.
- Step 4 (Link): This contrast mirrors the poems' themes: nsolsuk's isolated, inescapable agony vs. the nation's shared, forward-moving awakening. Nature in the first poem is a prison; in the second, a promise.
- Step 5 (Synthesis): The poet's range — from mineral hardness to floral color to aquatic grace — shows his mastery of matching vehicle to tenor's emotional texture.

REASONING: This worked example forces cross-poem synthesis (a Board/Competency favorite). The PEEL structure ensures each claim is evidenced and explained. The final synthesis moves beyond comparison to *evaluation of craft* — a higher-order skill.

ANSWER: Both poems deploy nature metaphors, but with opposite valence. "nsolsuk" traps the self in thorn and stone — inert, heavy, wounding — making suffering feel geological and inescapable. "dkusZfy;k" releases the nation into rkejl-flower and love-wave — vibrant, fluid, nurturing — making patriotism feel organic and expansive. The contrast reveals the poet's central vision: individual grief is a weight; collective hope is a current.

## COMPETENCY_QUESTION_1
QUESTION: "In 'nsolsuk dk xhr', the metaphor 'vk'kk ckoyh' (tears are a stream) appears *after* the thermal imagery of extinguished lamps. Explain how the *sequence* of these two devices structures the reader's emotional journey from despair to a darker realization. Use the terms 'tenor', 'vehicle', and 'ground' in your answer."

COMPETENCY: Literary Analysis — Device Sequencing and Emotional Structuring

STEPS:
- Step 1: Identify the first device (thermal imagery of extinguished lamps) and its tenor/vehicle/ground/effect.
- Step 2: Identify the second device (metaphor "vk'kk ckoyh") and its tenor/vehicle/ground/effect.
- Step 3: Analyze the transition: fire → water, heat → flow, finality → continuity.
- Step 4: Articulate the "darker realization": the stream implies tears *keep coming*; the fire was a one-time end, the stream is an ongoing flood.
- Step 5: Write the answer integrating terminology and emotional arc.

ANSWER: The poem opens with thermal imagery: tenor=life/hopes, vehicle=flame/lamp, ground=fragility/finality. The verbs "lafpr" and "yqVkbZ" deliver a *completed* catastrophe — the fire is out, leaving cold ash. Then comes the metaphor "vk'kk ckoyh": tenor=grief/tears, vehicle=stream, ground=ceaseless, natural, uncontrollable flow. The sequence is crucial: first we feel the *end* (fire out), then we realize the *aftermath* is not silence but a stream that won't stop. The ground shifts from "irreversible termination" to "irrepressible continuation". The reader moves from witnessing a death to drowning in a flood — a structural descent from closure to endless mourning.

DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: "A critic argues that the metaphor 'efnj' (boatman/ferryman) in 'dkusZfy;k dk xhr' is a *religious* symbol (referencing the Bhagavad Gita's charioteer or the Upanishadic ferryman), while another says it is a *secular* symbol of democratic leadership. Evaluate both readings using textual evidence from the poem's other metaphors ('rkejl', 'ey; lehj', 'f{kfrt'). Which reading is better supported, and why?"

COMPETENCY: Critical Evaluation — Intertextuality and Symbolic Ambiguity

STEPS:
- Step 1: Unpack the religious reading: "efnj" = traditional guru/ferryman across samsara; supported by "f{kfrt" (cremation ground = spiritual transition) and "jtuh" (world = samsara).
- Step 2: Unpack the secular reading: "efnj" = constitutional guide/leader; supported by "rkejl" (blood = sacrifice for nation, not ritual) and "ey; lehj" (love = fraternity, not bhakti).
- Step 3: Test each against the *cluster* of metaphors. Religious cluster would expect moksha, detachment, silence. Secular cluster expects action, blood, love, inclusive embrace ("lgkjk").
- Step 4: Note the poem's closing: "txdj jtuh Hkj rkjk" (steering the world-boat across) — active, worldly, continuous.
- Step 5: Conclude: Secular reading is better supported because the *entire metaphorical field* (blood, wave, embrace, past-future synthesis) is socio-political, not soteriological. The religious resonance is a *cultural echo*, not the *structuring logic*.

ANSWER: The secular reading is stronger. The metaphorical constellation — "rkejl" (revolutionary blood), "ey; lehj" (fraternal love wave), "lgkjk" (past-future embrace), "f{kfrt" (historical crossroads, not cremation) — consistently maps onto nationalist discourse: sacrifice, unity, progress, steering the ship of state. "efnj" as democratic helmsman fits this field; "efnj" as spiritual ferryman requires ignoring the political valence of "rkejl" and "ey; lehj". The poem uses religious *language* (efnj, f{kfrt) to *sanctify* the secular nation — a common strategy in nationalist poetry — but the *ground* of every metaphor is worldly.

DIFFICULTY: hard