## DEFINITION
Primary theme is the central, unifying idea that the author explores throughout a literary work. In "vDd osQ opu," the primary theme is the systemic oppression of women under feudal patriarchy and their struggle for autonomy, dignity, and liberation — presented not as individual misfortune but as a structural condition requiring collective resistance.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
Student can identify the primary theme across both poems, cite specific textual evidence from each poem (imagery, narrative voice, structural choices), and explain how the theme develops through the dialectical relationship between the two poems — one depicting the historical consequence of rebellion, the other the lived reality demanding it.

## SCOPE_BOUNDARY
Covers identification and analysis of the primary theme (patriarchal oppression and women's resistance) in both poems of "vDd osQ opu." Does not cover secondary themes (node 007), literary devices (nodes 008-009), comprehension questions (node 012), or writing skills (node 014).

## WALKTHROUGH
Imagine you're reading a newspaper report about a young woman in a village who refuses an arranged marriage and faces backlash — what's the core issue? It's not just her story; it's the system that punishes her choice. Now open the chapter. Read both poems aloud. Notice the words that repeat: *zanjir* (chains), *qaid* (prison), *azadi* (freedom), *deewar* (walls). Ask: Who holds the keys? In Poem 1, a king orders execution; in Poem 2, a locked door and missing keys trap the *bZ'oj*. Different settings — public gallows vs. private courtyard — but the same architecture of control. The theme isn't "women suffer." The theme is: *patriarchy is a system maintained by both spectacular violence and everyday confinement, and freedom requires dismantling that system.* That's the argument the poems make together.

## DIAGNOSTIC_QUESTION_1
What is the primary theme that unifies both poems in "vDd osQ opu"?

## DIAGNOSTIC_ANSWER_1
The primary theme is the systemic oppression of women under feudal patriarchy and their struggle for freedom and self-determination. A wrong answer (e.g., "love," "death," or "nature") reveals the student hasn't grasped the socio-political core of the Progressive Writers' Movement context provided in the chapter introduction. The poems are not about personal emotion; they are political critiques of gendered power structures.

## DIAGNOSTIC_QUESTION_2
Explain in your own words how the image of "chains" (*zanjir*) functions differently in the two poems while serving the same theme.

## DIAGNOSTIC_ANSWER_2
In Poem 1, chains represent institutionalized feudal oppression — the king's literal punishment for rebellion. In Poem 2, chains represent internalized patriarchal conditioning — the home as prison, the latch (*kundi*) and missing key (*chabi*) as normalized control. Both symbolize constraint but at different levels: external state enforcement vs. internalized domestic norm. A wrong answer treating them identically misses the nuance of how oppression operates structurally (public spectacle) versus psychologically (private endurance).

## DIAGNOSTIC_QUESTION_3
Given a new stanza: "The courtyard gate stays locked / The keys hang on the master's belt / She counts the cracks in the wall / Waiting for monsoon to weaken the mortar" — identify which poem's thematic approach this continues and justify with two pieces of evidence.

## DIAGNOSTIC_ANSWER_3
This continues Poem 2's approach (the *bZ'oj*'s perspective). Evidence: (1) First-person experiential focus ("She counts") matches Poem 2's subjective voice; (2) Domestic space as prison ("courtyard gate," "wall") matches Poem 2's household setting versus Poem 1's public execution ground. Wrong assignment to Poem 1 shows confusion between public spectacle of punishment versus private endurance of confinement — a critical distinction for thematic analysis.

## DIAGNOSTIC_QUESTION_4
Compare how the two poems portray the source of women's oppression. Does the author locate it in individual villains or systemic structures? Support with textual reasoning.

## DIAGNOSTIC_ANSWER_4
The author locates oppression in systemic structures. Poem 1: The king represents feudal authority, but the poet notes "this behavior wasn't just the king's alone" (*yeh R;kx L=kh osQoy 'kjhj ugha gS*) — implicating the entire aristocracy. Poem 2: No individual villain appears; the "home" itself, social expectations, and internalized fear ("no one gives a key") form the prison. A student blaming only the king or husband misses the structural critique central to Progressive literature — the theme is *system*, not *sinner*.

## DIAGNOSTIC_QUESTION_5
Critique this interpretation: "The primary message is that women should run away from home to be free." Is this faithful to the poems? Why or why not?

## DIAGNOSTIC_ANSWER_5
Unfaithful interpretation. Poem 1's protagonist destroys the feudal system itself (*"vDdegknsoh us mlh {k.k oL=kkHkw"k.k rFkk jkt&ifjokj dks NksM+ fn;k"*), not just escapes. Poem 2's *bZ'oj* wants to leave but the poem ends with her still strategizing (*"vks pjkpj! er pwd volj"* — "fly, bird, fly! break the net") — suggesting freedom requires structural change (keys given, walls broken), not individual flight. The message is collective liberation, not individual escape. A student agreeing reveals reductive reading that ignores the poems' political dimension.

## DIAGNOSTIC_QUESTION_6
Write a 4-line stanza in Hindi that extends the primary theme to a modern context (e.g., workplace, education, digital space) while maintaining the poetic voice of the chapter.

## DIAGNOSTIC_ANSWER_6
Good answer example:  
*कुर्सी पर बैठी हूँ, पर आवाज़ नहीं / फाइलें पास हैं, अधिकार नहीं / स्क्रीन की रोशनी में भी अंधेरा / कब तक सहूँगी यह पहरा?*  

Criteria: Uses modern workplace imagery, shows structural constraint (not individual failure), maintains the tone of suppressed rage turning to questioning. Poor answer focuses only on personal sadness without systemic critique — e.g., "I am sad at work, I want to leave" — which reduces the theme to emotion rather than analysis.

## COMMON_MISCONCEPTION
Students often confuse "theme" with "plot summary" or "moral lesson." They write: "The theme is that a woman was killed by a king" (plot) or "Women should be brave" (moral). The specific error: They treat the poems as narrative anecdotes rather than political commentary. This happens because Class 10 Hindi often taught theme as *"kya seekh milti hai"* (what lesson is learned), but Class 11 requires understanding theme as the work's central argument about society/human condition, grounded in textual patterns. The Progressive Writers' Movement explicitly rejected "art for art's sake" — the theme *is* the politics.

## ON_FAILURE
Step 1: Ask student to list 5 repeated words/images across both poems (e.g., *zanjir, qaid, azadi, mahal, deewar*). Step 2: For each, ask: "What does this represent in the real world the poet critiques?" Step 3: Have them complete the sentence: "The poet argues that women's unfreedom is caused by _______ and the solution requires _______." Step 4: Compare their answer to the Progressive Writers' Manifesto summary in the chapter introduction (node 001) — does it name the *system*?

## BUILDS_ON
Builds on Character Analysis (nodes 004, 005) where students identified the protagonist's rebellion and the *bZ'oj*'s desire for freedom as enacted theme.

## LEADS_TO
Enables Secondary Themes (node 007) where students will explore complementary themes like class solidarity, role of art in resistance, and psychological impact of oppression.

## PREREQUISITE_NODE_IDS
c11_hin_ar_cbse_14_001, c11_hin_ar_cbse_14_002, c11_hin_ar_cbse_14_003, c11_hin_ar_cbse_14_004, c11_hin_ar_cbse_14_005
## PREREQUISITE_REASONS
c11_hin_ar_cbse_14_001: Provides historical context of Progressive Writers' Movement essential for theme identification  
c11_hin_ar_cbse_14_002: Narrative structure reveals how theme unfolds across the two poems  
c11_hin_ar_cbse_14_003: Setting (feudal court vs. domestic space) establishes the structural loci of oppression  
c11_hin_ar_cbse_14_004: Protagonist's characterization shows resistance as theme-in-action  
c11_hin_ar_cbse_14_005: Supporting characters (king, implied family) represent patriarchal structures

## FORWARD_NODE_IDS
c11_hin_ar_cbse_14_007, c11_hin_ar_cbse_14_008, c11_hin_ar_cbse_14_009, c11_hin_ar_cbse_14_013, c11_hin_ar_cbse_14_014, c11_hin_ar_cbse_14_015, c12_hin_a_cbse_14_006, c12_hin_ar_cbse_12_006, c12_hin_ar_cbse_14_006

## FORWARD_REASONS
c11_hin_ar_cbse_14_007: Primary theme established here allows identification of secondary themes as variations/extensions  
c11_hin_ar_cbse_14_008: Imagery and metaphor analysis requires knowing the theme they serve  
c11_hin_ar_cbse_14_009: Irony and symbolism deepen the primary theme's expression  
c11_hin_ar_cbse_14_013: Critical thinking builds on thematic foundation for interpretation
c11_hin_ar_cbse_14_014: Primary theme (oppression/resistance) is the ultimate "Link" destination for every paragraph.  
c11_hin_ar_cbse_14_015: Primary theme analysis gives the central argument anchor for discussion points.  
c12_hin_a_cbse_14_006: Class 11 theme analysis of the same chapter builds foundational skill; Class 12 deepens it with cross-story synthesis and board-exam answer writing.  
c12_hin_ar_cbse_12_006: Writing analytical paragraphs on theme.  
c12_hin_ar_cbse_14_006: Class 11 foundation in theme identification — this node deepens it with metaphor-layering and PEEL writing  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
none

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_14_004 -> c11_hin_ar_cbse_14_006 -> c11_hin_ar_cbse_14_007

## THIS_FORMULA
N/A - conceptual

## FORMULA_VARIABLES
N/A

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
analytical

## CROSS_SUBJECT
c11_history_colonial_india | The Progressive Writers' Movement emerged alongside anti-colonial nationalism; both poems critique feudal patriarchy as part of broader social reform movements in 1930s-40s India  
c11_sociology_indian_society | The poems illustrate patriarchal control of women's mobility and sexuality through family/household structures — key concepts in sociology of gender and family  
c11_political_science_rights | The demand for *azadi* (freedom) in the poems connects to fundamental rights discourse; the shift from subject to citizen mirrors the poems' trajectory from oppression to resistance

## PREREQ_CONCEPT
Understanding of "Progressive Writers' Movement" (*pragatisheel lekhak andolan*) as a literary movement that viewed literature as a tool for social change, not just aesthetic expression.

## PREREQ_BEFORE
Student must be able to distinguish between plot (what happens) and theme (what the work argues about society/human condition).

## PREREQ_STUCK
Review the chapter introduction (node 001) for the Progressive Writers' Movement context and the distinction between narrative summary and thematic argument.

## WORKED_EXAMPLE_1
PROBLEM: Analyze how the primary theme of "patriarchal oppression and resistance" is established in the opening lines of both poems. Use the 4-step evidence-based analysis method.

STEPS:
- Step 1: Identify the opening situation in Poem 1 — a woman being publicly executed by a king for rebellion; in Poem 2 — a woman (*bZ'oj*) confined in her home, planning escape
- Step 2: Mark the key phrases that signal oppression: Poem 1 — *zanjir* (chains), *phansi* (execution), *raja* (king as authority); Poem 2 — *ghar* (house as prison), *kundi* (latch/lock), *chabi* (key held by others)
- Step 3: Analyze how each opening establishes a different facet of the same system — Poem 1 shows state/feudal violence against dissent; Poem 2 shows domestic confinement as normalized control
- Step 4: Synthesize — both openings position the female body as site of patriarchal control (public spectacle vs. private imprisonment), establishing the theme's structural scope
- Step 5: Connect to central idea — the dual opening proves the theme operates at both macro (state) and micro (family) levels, which is the hallmark of Progressive literature's systemic critique

REASONING: This method moves from textual evidence to structural analysis, preventing the common error of treating the poems as separate stories. The 5 steps ensure students link specific words to the abstract theme.

ANSWER: The primary theme is introduced through parallel openings: Poem 1 dramatizes the lethal consequence of female resistance to feudal authority (public execution), while Poem 2 depicts the everyday containment of women within domestic walls (locked house). Together they map the totality of patriarchal control — from spectacular violence to invisible normalization — establishing that the "oppression" in the theme is structural, not incidental.

## WORKED_EXAMPLE_2
PROBLEM: A student writes: "The theme of both poems is women's suffering." Using the theme-analysis rubric, explain why this is incomplete and rewrite it as a Class 11-level thematic statement.

STEPS:
- Step 1: Apply the rubric criterion — "Theme must name the social structure or human condition examined, not just the emotion experienced"
- Step 2: Identify what's missing — "suffering" describes effect, not cause; it erases the agent of oppression (patriarchy/feudalism) and the response (resistance)
- Step 3: Retrieve textual evidence of agency — Poem 1: *vDdegknsoh ne... raj-satta ko NksM+ fn;k* (she broke the royal power); Poem 2: *bZ'oj* actively plans escape (*ud jaaun*, *chabi mil jaaye*)
- Step 4: Formulate the complete theme using the template: "[System/Structure] + [Impact on Subject] + [Subject's Response]"
- Step 5: Write the refined statement and verify it covers both poems

REASONING: This worked example teaches the precise vocabulary of thematic analysis (structure, agency, resistance) that board exams expect. The 5-step rubric application transforms vague observation into analytical claim.

ANSWER: Incomplete statement: "Women's suffering" (describes symptom, ignores system and agency). Class 11 thematic statement: "The poems collectively argue that feudal patriarchy systematically denies women autonomy through both spectacular state violence and everyday domestic confinement, yet women's resistance — whether through revolutionary overthrow or persistent escape-planning — exposes the system's fragility and asserts the inevitability of liberation."

## WORKED_EXAMPLE_3
PROBLEM: The chapter introduction states vDdegknsoh's poetry is "the first conscious expression of this progressive trend" (*igyak ltZukRed nLrkostk*). Using this claim, analyze how the primary theme in these poems differs from earlier Hindi literary treatments of women (e.g., Bhakti poetry's *virahini* or Chhayavad's romantic idealization). This combines theme analysis with literary history.

STEPS:
- Step 1: Recall the three comparative models: Bhakti (*virahini* — separation from divine/lover as spiritual metaphor), Chhayavad (woman as muse/nature symbol, aestheticized), Progressive (woman as historical subject under material oppression)
- Step 2: Map Poem 1's protagonist to the Progressive model — she is a historical actor (named, situated in 12th century Lanjha village), her rebellion is political (against king), her death catalyzes collective uprising
- Step 3: Map Poem 2's *bZ'oj* to the Progressive model — she speaks in first person (*mere ghar*), her confinement is material (locked door, physical keys), her desire is for tangible freedom (*ud jaaun*), not spiritual union
- Step 4: Contrast with Bhakti — *virahini*'s pain is devotional, not political; no critique of patriarchy; Chhayavad — woman is object of poet's gaze, not speaking subject
- Step 5: Identify the thematic shift — from "woman as symbol" to "woman as agent of history"; from metaphysical longing to material demand for rights
- Step 6: Conclude how this validates the "first conscious expression" claim — the theme itself (patriarchy as analyzable, changeable structure) is the innovation

REASONING: This 6-step example demonstrates the senior-secondary skill of situating a text's theme within literary history. It requires synthesizing character analysis (nodes 004-005), context (node 001), and theme analysis — exactly the multi-concept integration board exams test.

ANSWER: Earlier Hindi literature treated women as symbols (*virahini* = soul's longing; Chhayavad heroine = beauty/nature). vDdegknsoh's primary theme breaks this by presenting women as historical subjects: Poem 1's protagonist is a named peasant woman whose political rebellion topples a king; Poem 2's *bZ'oj* is a speaking subject demanding physical freedom from a locked house. The theme shifts from "woman's essence" to "woman's condition under patriarchy" — making oppression the object of analysis, not the background of romance. This structural critique of gendered power is what makes it the "first conscious progressive expression."

## COMPETENCY_QUESTION_1
QUESTION: The chapter contains two poems with different speakers, settings, and outcomes. Yet the NCERT introduction calls them a single "opu" (opus/work) with one primary theme. Construct an argument defending this editorial decision using evidence from both poems. Your answer must reference: (a) the structural parallel between the two openings, (b) the shared imagery of confinement, and (c) the common political vision.

COMPETENCY: Thematic synthesis and textual evidence integration

STEPS:
- Step 1: State the thesis — the two poems form a dialectical pair: Poem 1 shows the historical consequence of resistance (martyrdom), Poem 2 shows the lived reality demanding resistance (confinement)
- Step 2: Evidence for (a) — Both open with the female body in extremis: Poem 1 at the gallows, Poem 2 at the locked door; both establish the stakes immediately
- Step 3: Evidence for (b) — Shared imagery: *zanjir/kaid* (chains/prison), *deewar/kundi* (walls/latches), *azadi/udna* (freedom/flying) — creating a semantic field of entrapment across both poems
- Step 4: Evidence for (c) — Both envision freedom as structural transformation: Poem 1 achieves it through revolutionary overthrow (*raj-satta todi*); Poem 2 seeks it through breaking barriers (*deewar tode*, *chabi mil jaaye*) — neither accepts reform within the system
- Step 5: Conclude — the editorial unity reflects the Progressive aesthetic: literature as "weapon" (*hathiyaar*) where form serves political clarity

ANSWER: The two poems constitute a single thematic work because they present the two faces of patriarchal oppression: the spectacular punishment of dissent (Poem 1) and the invisible normalization of confinement (Poem 2). Structural parallel: both open at the moment of crisis — execution vs. escape-planning. Shared imagery: chains, walls, locks, keys, flying/freedom create a unified symbolic vocabulary. Common political vision: both reject individual escape or reform; Poem 1's protagonist destroys the throne, Poem 2's *bZ'oj* seeks to shatter walls. Together they map the total system — proving the theme is structural, not situational. This unity is why the editor presents them as one "opu."

DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: A board exam question asks: "*vDd osQ opu mein stree-mukti ki awaz sirf ek vyaktigat pukar nahi, balki ek samajik-andolan ki hava hai.*" (The voice of women's liberation in vDd osQ opu is not just an individual cry but the wind of a social movement.) Evaluate this statement by analyzing how the poems convert personal experience into collective political claim. Your answer must integrate: (1) the historical context from the chapter introduction, (2) the shift from third-person narrative (Poem 1) to first-person voice (Poem 2), and (3) the ending of each poem.

COMPETENCY: Historical-contextual analysis and narrative perspective evaluation

STEPS:
- Step 1: Unpack the claim — "not individual cry but social movement" means the poems frame personal suffering as symptom of structural injustice requiring collective remedy
- Step 2: Use historical context (introduction) — vDdegknsoh linked to Progressive Writers' Movement, peasant uprisings, *ohj 'kSo vkanksyu* — the poems are movement literature, not confessional lyrics
- Step 3: Analyze perspective shift — Poem 1's third-person (*vDdegknsoh*, *usne*) creates historical distance, making the protagonist a representative figure; Poem 2's first-person (*mere*, *mujhe*) creates immediacy, making the *bZ'oj* every woman's voice
- Step 4: Analyze endings — Poem 1: *ehjk dh iafDr ru dh vkl dcgw ugha dhuh* (her sacrifice didn't go in vain) + reference to *egkohj* (revolutionaries) joining — individual death seeds collective uprising; Poem 2: open-ended strategizing (*ud jaaun*, *chabi mil jaaye*) implies ongoing struggle, not resolution — the movement continues
- Step 5: Synthesize — the movement from third-person martyr to first-person survivor mirrors the historical shift from sporadic rebellion to organized movement; both endings project forward to collective future

ANSWER: The statement is accurate. The chapter introduction situates vDdegknsoh within the Progressive Writers' Movement and peasant revolts — literature as political intervention. Poem 1's third-person narrative historicizes the protagonist (vDdegknsoh of Lanjha, 12th century), making her martyrdom a founding moment for later revolutionaries (*egkohj vkfn egkiq#"kksa*). Poem 2's first-person voice (*mere ghar*, *mujhe*) universalizes the *bZ'oj*'s confinement — she could be any woman in any feudal household. The endings seal the collective dimension: Poem 1 explicitly links her death to future uprising; Poem 2's unresolved escape-plan (*agar main ud jaaun... chabi mil jaaye*) refuses closure, signaling the struggle continues. Personal experience becomes political claim through this dual strategy: historical exemplarity + universalized voice. The "wind of social movement" is the structural analysis itself — naming patriarchy as a system, not a fate.

DIFFICULTY: hard