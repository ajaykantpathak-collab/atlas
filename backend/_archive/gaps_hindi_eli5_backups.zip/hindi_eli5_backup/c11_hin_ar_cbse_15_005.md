## DEFINITION
Character analysis of supporting characters in poetry involves identifying and interpreting the representative figures, voices, or personas invoked by the poet to embody collective experiences, social realities, or ideological positions that contrast with or amplify the central poetic voice.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student must be able to identify at least four distinct representative figures in the poem, explain how each figure's concrete imagery reveals a specific socio-political condition, and articulate how the collective portrayal of these figures constructs the poem's central argument about what constitutes the "smallest" (लघु) human experience.

## SCOPE_BOUNDARY
This node covers analysis of the representative figures invoked in Ik's poem "लघुशंका" (the hungry returnee, the dreamless sleeper, the silent watcher, the ruin-reader, the crushed voices) as supporting characters. It does NOT cover the protagonist analysis (the poetic speaker), thematic analysis, or literary devices, which are addressed in separate nodes.

## WALKTHROUGH
Imagine you are listening to a street play where one main narrator speaks, but keeps pointing to different people in the crowd — a woman carrying water, a mother kissing her child, a soldier at the border, a laborer dragging home at night — and says: "Their pain is not small; THIS person's pain is the smallest." To begin analyzing supporting characters in this poem, first list every distinct human figure the poet names or describes across both stanzas. Next, for each figure, note the specific physical detail the poet attaches to them (shadow, love, border, hungry stomach, dead dreams, unblinking eyes, reading on ruins, crushed voices). Then ask: what social group or condition does this figure represent? Finally, compare how the first three figures are explicitly rejected as "not the smallest" while the last five are affirmed as "the smallest" — this contrast is the analytical key.

## DIAGNOSTIC_QUESTION_1
Identify the three figures the poet explicitly states are NOT "लघु" (the smallest/minor) in the first stanza of the poem.

## DIAGNOSTIC_ANSWER_1
The three figures are: (1) a woman's shadow (esgur dh ywV), (2) a mother's love (iqfyl dh ekj), and (3) the border dispute between two nations (xíkjh&yksHk dh eq_h). A wrong answer that includes figures from the second stanza (like the hungry returnee or the dreamless sleeper) reveals the student cannot distinguish the poem's two-part structure of negation followed by affirmation, which is essential for understanding the poet's rhetorical strategy.

## DIAGNOSTIC_QUESTION_2
Explain in your own words why the poet rejects "a woman's shadow" and "a mother's love" as examples of the "smallest" thing, even though both are traditionally considered powerless or insignificant in patriarchal society.

## DIAGNOSTIC_ANSWER_2
The poet rejects them because they carry immense symbolic weight — a woman's shadow represents the entire structure of patriarchal control, and a mother's love represents the foundational emotional labor that sustains society; neither is "small" in impact or significance. A wrong answer that says "because women and mothers are important" misses the poetic logic: the poem is not about importance but about the *scale of suffering* — the poet argues that systemic oppression (shadow) and sacred love (mother) are vast, while the daily crushing of a hungry worker's dignity is what is truly, terrifyingly "small" in its invisibility.

## DIAGNOSTIC_QUESTION_3
The poem describes a figure: "वकील तुम्हारी आँखों पर पड़ी गकबZ हकqbZ Hkh तेह cq/Z gksrh gS" (the eye that doesn't blink like a frog even while watching). Apply the concept of "representative figure" to explain which social group this figure embodies and what the "frog" comparison reveals about their condition.

## DIAGNOSTIC_ANSWER_3
This figure embodies the silent witness — the common citizen who sees injustice daily but cannot speak or act. The frog comparison reveals forced hyper-vigilance: a frog's unblinking stare is a survival mechanism, not choice; similarly, the oppressed must keep watching the powerful (ejfl;) read their destruction on ruins, paralyzed by fear. A wrong answer that focuses only on "fear" without connecting the frog's biological trait to the political condition of enforced silence misses the poem's critique of how power reduces humans to bare survival instincts.

## DIAGNOSTIC_QUESTION_4
Compare the figure of "the hungry person returning home" (eqnkZ 'kkafr ls Hkj tkuk) with "the one whose dreams die" (gekjs liuksa dk ej tkuk). How do these two supporting characters represent different dimensions of the same systemic violence?

## DIAGNOSTIC_ANSWER_4
The hungry returnee represents material deprivation — the body's immediate need denied by economic structures that separate labor from sustenance (dke ls ykSVdj ?kj vkuk). The dreamless sleeper represents psychological/spiritual deprivation — the future imagination killed by hopelessness (liuksa dk ej tkuk). Together they show systemic violence operates on both biological survival and human aspiration. A wrong answer that treats them as separate "types of poor people" fails to see the poem's dialectic: hunger makes dreaming impossible, and dreamlessness makes hunger unbearable — they are sequential stages of the same crushing.

## DIAGNOSTIC_QUESTION_5
Evaluate the poet's choice to end the affirmation sequence with "the crushed voices of the oppressed on the thorns of history" (vkrafdr yksxksa dh njok"kksa ij tks xaqMs dh rjg vdM+rk gS). Is this figure the most effective culmination of the "लघु" argument? Justify your judgment.

## DIAGNOSTIC_ANSWER_5
Yes, it is the most effective culmination because it transforms the previous individual figures into a collective historical subject. The grape metaphor (xaqMs) captures both the viscosity of blood/suffering and the wine of resistance — crushed voices ferment into something that intoxicates power. The "thorns of history" (pkSxkBksa) echoes the crown of thorns, suggesting sacrificial redemption. A wrong answer that calls it "just another sad image" misses the teleological structure: the poem moves from individual bodies (stomach, eyes, dreams) to collective voice, making the final figure the political synthesis of all preceding ones.

## DIAGNOSTIC_QUESTION_6
Create a new representative figure that could fit into the poem's second stanza as an example of "लघु" (the smallest), using the same concrete, image-based style. Write two lines in Hindi that follow the poem's syntactic pattern.

## DIAGNOSTIC_ANSWER_6
Example: "लघु वह साँस है जो धुएँ भरे कारखाने में / मशीन की गड़गड़ाहट के नीचे दबकर रह जाती है" (The smallest is that breath in a smoke-filled factory / crushed under the machine's roar). A good answer uses: (a) a concrete physical detail (breath, smoke, machine), (b) a specific laboring body, (c) passive verb construction (दबकर रह जाती है) mirroring the poem's syntax of things happening TO the figure. A poor answer uses abstract nouns (injustice, poverty) or breaks the poem's pattern of "लघु वह X है जो Y करता/होता है".

## COMMON_MISCONCEPTION
Students often treat the poem's figures as literal characters in a story (e.g., "the woman," "the mother," "the hungry man") and analyze their "personalities" or "feelings." This error occurs because the term "character analysis" triggers prose-fiction habits. In this political lyric, these are not individuals with interiority but **representative figures** — each is a metonym for a structural position (gendered oppression, reproductive labor, national conflict, wage labor, alienation, surveillance, historical trauma). The poem denies them individuality precisely to show how systems reduce humans to functions.

## ON_FAILURE
If a student writes a "character sketch" of the hungry man describing his personality, take these steps: (1) Show them the poem's syntax: "लघु वह [noun] है जो [relative clause describing condition]" — no name, no past, no agency. (2) Ask: "Does the poem tell us this man's name, caste, village, or thoughts? No. It only tells us what the system does TO him." (3) Have them rewrite the analysis replacing "the hungry man" with "the figure of the wage-laborer separated from the product of his labor" — this shift from individual to structural language is the conceptual breakthrough. (4) Practice with the "frog-eyed watcher": identify the structural position (surveillance subject) and the bodily detail that encodes it (unblinking eye).

## BUILDS_ON
c11_hin_ar_cbse_15_004 (Character Analysis: Protagonist) — understanding the poetic speaker's voice and position is necessary before analyzing how other figures are positioned relative to it.

## LEADS_TO
c11_hin_ar_cbse_15_006 (Theme: Primary Theme and Message) — the collective portrait of supporting figures directly constructs the poem's central theme of redefining "लघु" as systemic invisibility rather than individual insignificance.

## PREREQUISITE_NODE_IDS
c11_hin_ar_cbse_15_001, c11_hin_ar_cbse_15_002, c11_hin_ar_cbse_15_004
## PREREQUISITE_REASONS
c11_hin_ar_cbse_15_001: Provides historical context (1988, post-Emergency, Sikh riots) essential for reading the figures as responses to specific state violence.
c11_hin_ar_cbse_15_002: Establishes the poem's two-stanza structure (negation then affirmation) which organizes how supporting figures are deployed.
c11_hin_ar_cbse_15_004: Analyzes the poetic speaker (protagonist) whose perspective frames all supporting figures as foils or extensions.

## FORWARD_NODE_IDS
c11_hin_ar_cbse_15_006, c11_hin_ar_cbse_15_007, c11_hin_ar_cbse_15_013, c11_hin_ar_cbse_15_015, c12_hin_a_cbse_15_005, c12_hin_ar_cbse_06_005, c12_hin_ar_cbse_15_005

## FORWARD_REASONS
c11_hin_ar_cbse_15_006: The primary theme (redefinition of "लघु") emerges directly from the contrast between rejected and affirmed supporting figures.
c11_hin_ar_cbse_15_007: Secondary themes (hunger, silence, historical memory) are each carried by specific supporting figures analyzed here.
c11_hin_ar_cbse_15_013: Critical interpretation requires synthesizing how the ensemble of figures constructs the poem's political argument.
c11_hin_ar_cbse_15_015: Supporting characters (implied figures) expand discussion scope.  
c12_hin_a_cbse_15_005: Class 11 Antra Chapter 15 supporting character analysis provides the foundational skill of distinguishing protagonist from supporting roles.  
c12_hin_ar_cbse_06_005: Class 11 foundation on supporting character analysis in Aroh.  
c12_hin_ar_cbse_15_005: Class 11 node teaches fiction supporting character roles (foil, confidant, antagonist); this node requires unlearning/adapting those for non-fiction.  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
No prior class nodes available for cross-subject connections in this dataset.

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_15_001 -> c11_hin_ar_cbse_15_002 -> c11_hin_ar_cbse_15_004 -> c11_hin_ar_cbse_15_005 -> c11_hin_ar_cbse_15_006 -> c11_hin_ar_cbse_15_013

## THIS_FORMULA
N/A - conceptual

## FORMULA_VARIABLES
N/A

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
analytical

## CROSS_SUBJECT
c11_history_postcolonial_india | The poem's figures (border dispute, crushed voices on history's thorns) directly reference 1980s Punjab crisis and Emergency-era state violence — analyzing them requires the same source-criticism skills used in history for reading literary testimony as historical evidence.
c11_sociology_structural_inequality | The representative figures embody Marx's "immiseration of the worker" (hungry returnee), Foucault's "docile bodies" (frog-eyed watcher), and Gramsci's "subaltern silence" (crushed voices) — sociology provides the theoretical vocabulary to name what the poem shows imagistically.

## PREREQ_CONCEPT
Understanding the poetic speaker's position (from Protagonist Analysis) as a politically conscious observer who refuses dominant definitions of "minor" and "major" suffering.

## PREREQ_BEFORE
Student must be able to distinguish the poem's two-stanza rhetorical structure: Stanza 1 = negative definition (what लघु is NOT), Stanza 2 = positive definition (what लघु IS).

## PREREQ_STUCK
If stuck, review c11_hin_ar_cbse_15_002 (Plot and Narrative Structure) to map the poem's movement from negation to affirmation, then review c11_hin_ar_cbse_15_004 to see how the speaker's voice frames the figures.

## WORKED_EXAMPLE_1
PROBLEM: Analyze how the figure of "the woman carrying a pitcher on her head, walking on the edge of a well" (vkidh dykbZ ij pyrh gqbZ Hkh tks vkidh fuxkg esa #dh gksrh gS) functions as a supporting character that redefines "लघु" through gendered labor.

STEPS:
- Step 1: Locate the figure in the text — second stanza, fourth affirmative example after "लघु वह ?kM+h gksrh gS" — note the syntactic parallelism with preceding figures.
- Step 2: Deconstruct the imagery: pitcher on head (dykbZ) = water-fetching labor; walking on well's edge (fuxkg) = constant danger; "even while walking, falls into your stomach" (pyrh gqbZ Hkh teh cqZ gksrh gS) = the labor consumes the laborer's own body.
- Step 3: Identify the structural position: rural/poor woman whose reproductive labor (water for household) is so hazardous and internalized that the boundary between her body and the well collapses.
- Step 4: Contrast with Stanza 1's rejected "woman's shadow" (esgur dh ywV) — there, woman as symbol of patriarchal control; here, woman as material body destroyed by the very labor that sustains life.
- Step 5: Connect to the poem's argument: this figure proves "लघु" is not symbolic oppression (shadow) but the literal, daily dissolution of the body into the work that keeps others alive — the smallest thing is the woman disappearing into her own labor.

REASONING: The poem uses gendered labor not as a "women's issue" but as the paradigmatic form of invisible, body-destroying work that the system treats as negligible (लघु) while depending on it entirely. The well-edge imagery makes the danger spatial and immediate.

ANSWER: The pitcher-woman figure redefines "लघु" by shifting from the symbolic (shadow) to the somatic (body falling into its own stomach). She represents the reproductive laborer whose work is so "small" it erases her — the well's edge is both her workplace and her grave. This supports the poem's thesis that the truly "smallest" suffering is the one that leaves no trace because it is built into survival itself.

## WORKED_EXAMPLE_2
PROBLEM: The poem presents two reader-like figures: "ejfl;" (the elegist/poet reading on ruins) and the implied reader of the poem itself. Analyze how the "ejfl;" figure functions as a supporting character that implicates the act of witnessing.

STEPS:
- Step 1: Identate the figure's location — second stanza, sixth affirmative example: "लघु वह xhr gksrk gS vkiosQ dkuksa rd igq¡pus osQ fy, tks ejfl; i<+rk gS" (the smallest is the ruin reaching to the poet's doors, on which the ejfl; reads).
- Step 2: Define "ejfl;" using the glossary: "d#.k jl dh dfork tks fdlh O;fDr dh e`R;q ij fy[kh tkrh gS" — an elegy written on someone's death. The ejfl; is the professional mourner/poet who aestheticizes death.
- Step 3: Analyze the spatial relation: ruins (xhr) reach TO the poet's doors (dkuksa) — the destruction comes to the writer, who then reads/performs it. The poet doesn't go to the ruin; the ruin comes to the poet.
- Step 4: Determine the critical function: this figure exposes the complicity of literary witness. The ejfl; transforms living suffering (ruins with bodies) into textual objects (elegies) — the "reading" (i<+rk) is an act of consumption.
- Step 5: Link to the poem's self-reflexivity: Ik (the poet) includes the ejfl; AS a "लघु" figure, implicating himself. The smallest thing includes the poet's own practice of making poetry from corpses.

REASONING: This is the poem's most meta-critical move — it turns the analytical lens onto the very act of poetic representation. The ejfl; is not an outsider but a supporting character INSIDE the system of "लघु," showing that even resistance-literature can become a mechanism of neutralization.

ANSWER: The ejfl; figure represents the intellectual/artist who processes collective trauma into aesthetic form. By making the ejfl; a "लघु" figure — one whose doors are reached by ruins, who reads elegies on them — the poem argues that the act of witnessing is itself part of the "smallest" violence when it aestheticizes suffering without interrupting its production. The supporting character thus indicts the poet's own craft.

## WORKED_EXAMPLE_3
PROBLEM: Synthesize the five affirmative figures of Stanza 2 (hungry returnee, dreamless sleeper, pitcher-woman, frog-eyed watcher, ejfl; on ruins, crushed voices) into a single analytical framework showing how they form a "anatomy of the लघु" — a structural map of invisible violence.

STEPS:
- Step 1: List all six affirmative figures with their core imagery: (1) hungry stomach returning from work, (2) dead dreams in sleep, (3) pitcher-woman falling into her own stomach, (4) unblinking eyes watching elegies on ruins, (5) ejfl; reading on ruins, (6) crushed voices on history's thorns like grapes.
- Step 2: Group by dimension of violence: Material (1, 3), Psychological (2), Sensory/Perceptual (4), Cultural/Intellectual (5), Historical/Collective (6).
- Step 3: Trace the progression: individual body (stomach) → individual psyche (dreams) → gendered body (woman/well) → sensory organ under surveillance (eyes) → cultural processor (ejfl;) → collective voice (grapes). This is a zoom-out from cellular to historical scale.
- Step 4: Identify the connective logic: each figure's "smallness" is produced by a specific mechanism — exploitation (1), alienation (2), reproductive labor (3), panopticism (4), aestheticization (5), archival erasure (6).
- Step 5: Note the formal mirroring: the poem's anaphora ("लघु वह... लघु वह... लघु वह...") enacts the accumulation of these mechanisms — the repetition IS the structural argument that "लघु" is not an exception but a system.
- Step 6: Conclude: the supporting characters collectively demonstrate that "लघु" names the total social factory that produces invisibility at every register — biological, psychic, gendered, perceptual, cultural, historical.

REASONING: This synthesis moves beyond listing figures to showing how the poem constructs a systemic theory of "the smallest" through its ensemble. The anaphoric structure is not decorative but analytical — each repetition adds a layer to the anatomy.

ANSWER: The six supporting characters form a complete anatomy of structural invisibility: (1) metabolic (hunger), (2) imaginative (dead dreams), (3) reproductive (woman/well), (4) perceptual (frog-eye), (5) cultural (ejfl;), (6) historical (crushed grapes). Together they prove the poem's thesis: "लघु" is not a size but a mode of production — the system that makes suffering invisible by distributing it across every human faculty. The anaphora ("लघु वह...") performs this totality formally.

## COMPETENCY_QUESTION_1
QUESTION: The poem's first stanza rejects three figures as "not लघु" (woman's shadow, mother's love, border dispute). The second stanza affirms six figures as "लघु." Select ANY ONE rejected figure and ANY ONE affirmed figure, and explain how their contrast reveals the poem's political criteria for what counts as "the smallest." Your answer must use specific imagery from both figures.

COMPETENCY: Comparative analysis of poetic figures to extract conceptual criteria

STEPS:
- Step 1: Choose one rejected figure (e.g., "mother's love" — iqfyl dh ekj) and one affirmed figure (e.g., "hungry returnee" — eqnkZ 'kkafr ls Hkj tkuk).
- Step 2: Identify the core imagery of each: mother's love = expansive, generative, socially sanctified; hungry returnee = contracted, degenerative, socially invisible.
- Step 3: Articulate the contrast: the rejected figure represents power DISGUISED as vulnerability (mother's love controls through sacrifice); the affirmed figure represents vulnerability STRIPPED of power (hunger that cannot be spiritualized).
- Step 4: State the political criterion: "लघु" names suffering that serves no ideological function, carries no symbolic capital, and cannot be redeemed into narrative — it is the residue that the system produces and discards.

ANSWER: The mother's love (rejected) is vast because it is the emotional infrastructure of the nation/family — it builds subjects. The hungry returnee (affirmed) is "लघु" because his hunger builds nothing, serves no one, and disappears without trace — it is the system's waste product. The criterion: suffering that reproduces power (mother's love) is "not small"; suffering that only testifies to power's violence (hunger) is "the smallest."

DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: A Class 11 student writes: "The poem's supporting characters are all victims — the hungry man, the dreamless sleeper, the woman at the well, the watcher, the poet, the crushed voices. The poem is a catalog of victimhood." Critique this interpretation using evidence from the poem's structure and the specific agency (or refusal of agency) encoded in each figure's imagery.

COMPETENCY: Critical evaluation of reductive readings through structural and imagistic evidence

STEPS:
- Step 1: Acknowledge the surface validity — all figures suffer — but identify the reduction: "victimhood" implies passivity, while the poem's imagery encodes specific forms of resistance, complicity, and structural positioning.
- Step 2: Analyze the hungry returnee: "dke ls ykSVdj ?kj vkuk" (leaving work for home) — the movement FROM work TO home asserts a claim on life despite exhaustion; not pure passivity.
- Step 3: Analyze the pitcher-woman: "pyrh gqbZ Hkh teh cqZ gksrh gS" (walking yet falling into stomach) — the body's dissolution INTO its labor is a critique of the labor relation, not just suffering.
- Step 4: Analyze the frog-eyed watcher: "tepks± dh rjg ugha xM+rk" (doesn't blink like a frog) — the forced vigilance is a survival strategy; the eye that won't close is a refusal of blindness.
- Step 5: Analyze the ejfl;: the poet READING on ruins — this is an ACTIVE choice of form (elegy) that the poem critiques as complicit. Agency exists but is misdirected.
- Step 6: Analyze the crushed grapes: "xaqMs dh rjg vdM+rk" (crushed like grapes) — grapes ferment; the metaphor carries latent transformation (wine/intoxication), not just destruction.
- Step 7: Synthesize: the poem catalogs not victimhood but the MORPHOLOGY of power — how it shapes bodies, dreams, gazes, art, history. The figures are positions in a structure, not identities.

ANSWER: The "catalog of victimhood" reading fails because it ignores the poem's structural intelligence. Each figure encodes a specific relation to power: the hungry returnee's movement home is a claim; the pitcher-woman's body dissolving into labor exposes the labor relation; the frog-eye's unblinking stare is enforced vigilance as survival; the ejfl;'s reading is aesthetic complicity; the grapes' crushing holds fermentation. The poem doesn't pity — it dissects. The supporting characters are not "victims" but evidence in an indictment.

DIFFICULTY: hard