## DEFINITION
Plot and narrative structure in a narrative poem refers to the organized sequence of events, the dramatic situation (speaker, addressee, setting), and the structural devices (dialogue, repetition, progression) that shape the poem's story arc from exposition through climax to resolution.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student can independently map the poem's events onto a five-stage narrative arc (exposition, inciting incident, rising action, climax, resolution), identify the two distinct voices and their structural functions, and explain how the dialogue-driven structure reinforces the literacy theme.

## SCOPE_BOUNDARY
This node covers narrative structure analysis of the poem "पैक डाकिया डाकिया..." including dramatic situation, speaker/addressee roles, event sequence, dialogue as structural device, and thematic progression. It does NOT cover setting/atmosphere details (node 003), deep character analysis (nodes 004-005), theme exploration (nodes 006-007), or literary devices (nodes 008-009) — those are separate nodes.

## WALKTHROUGH
Imagine you're waiting for an important WhatsApp message from a friend — that anticipation, the notification sound, the relief or anxiety when you read it. Now replace the phone with a postman in a 1930s village carrying letters most people cannot read. Begin by reading the poem aloud twice: first for the sound and rhythm, second to mark every speaker change (who says what). Notice the poem opens with the postman's arrival (exposition), moves through his call "डाकिया डाकिया" (inciting incident), builds through the illiterate person's shame and the postman's persuasion (rising action), peaks at the command "पढ़ ले!" (climax), and resolves with the vision of an empowered future (resolution). The key insight: the entire narrative is carried through dialogue — there is no third-person narration — making the structure itself a performance of oral culture transitioning to literacy.

## DIAGNOSTIC_QUESTION_1
Who is the primary speaker in the opening stanza of the poem, and what specific action announces their arrival?

## DIAGNOSTIC_ANSWER_1
The primary speaker is the postman (पैक/डाकिया), announced by the repeated call "डाकिया डाकिया" and the sound of his footsteps "पकी पकी लुक दजर गस" (पग-पग ध्वनि). A wrong answer (e.g., "the poet" or "a villager") reveals the student cannot distinguish the dramatic speaker from the poet, a fundamental error in narrative poetry analysis where the *persona* ≠ *author*.

## DIAGNOSTIC_QUESTION_2
Explain in your own words the dramatic situation (कथात्मक स्थिति) that the poem sets up in its first two stanzas.

## DIAGNOSTIC_ANSWER_2
A postman arrives in a village with letters, but the intended recipients are illiterate — they cannot read the letters themselves, creating a crisis of communication where the messenger holds knowledge the people cannot access. A wrong answer focusing only on "the postman brings letters" misses the *conflict* (illiteracy as barrier) that drives the entire narrative; this shows the student sees events but not the structural tension.

## DIAGNOSTIC_QUESTION_3
Map the poem's progression onto a narrative arc diagram: label which lines/stanzas correspond to exposition, inciting incident, rising action, climax, and resolution. Use stanza references (e.g., "Stanza 1–2: Exposition").

## DIAGNOSTIC_ANSWER_3
**Exposition**: Stanzas 1–2 (postman arrives, announces letters). **Inciting Incident**: Stanza 3 (villager admits "मैं नहीं पढ़ी" / postman insists "पढ़ लेना अच्छा है"). **Rising Action**: Stanzas 4–5 (postman describes future benefits — reading letters, independence, not relying on others). **Climax**: Stanza 6 (postman's direct command "डाकिया कहती है: पढ़ ले!"). **Resolution**: Final lines (vision of the villager reading independently, "डाकिया कहती है: तू पढ़ ले!"). A wrong mapping (e.g., placing climax at the arrival) shows the student confuses *event sequence* with *emotional/structural peak*.

## DIAGNOSTIC_QUESTION_4
The poem uses two distinct voices. Compare their linguistic registers (शैली) and explain how this contrast structures the poem's central conflict.

## DIAGNOSTIC_ANSWER_4
Voice 1 (Postman): Authoritative, persuasive, future-oriented, uses standard Hindi ("पढ़ लेना अच्छा है", "चिट्ठी पढ़ सकेगी") — represents literacy, modernity, agency. Voice 2 (Villager): Hesitant, self-deprecating, present-bound, uses colloquial/dialect markers ("मैं नहीं पढ़ी", "कभी नहीं गई") — represents oral tradition, dependence, shame. The structural alternation creates a dialogue-of-unequals that mirrors the social hierarchy the poem critiques. A wrong answer listing only "one speaks nicely, one roughly" misses how *register encodes power dynamics* — a senior-secondary analytical requirement.

## DIAGNOSTIC_QUESTION_5
Evaluate: Is the poem's resolution (the villager learning to read) presented as achieved fact or as aspirational projection? Defend your judgment with structural evidence.

## DIAGNOSTIC_ANSWER_5
Aspirational projection. The resolution occurs in the *postman's imagined future* ("जब तू पढ़ लेगी... तब तू खुद चिट्ठी पढ़ेगी"), not in a depicted scene of the villager actually reading. The poem ends on an imperative ("पढ़ ले!") not a declarative ("उसने पढ़ लिया"). This open-ended structure forces the reader to carry the literacy mission forward. A wrong answer claiming "the villager learns to read" confuses *narrative prediction* with *narrated event* — a critical distinction for board-level literary analysis.

## DIAGNOSTIC_QUESTION_6
Write a 4-line continuation stanza that follows the poem's narrative logic: the villager, now literate, receives a letter. Maintain the dialogue structure and thematic tone.

## DIAGNOSTIC_ANSWER_6
*Expected criteria*: (1) Villager as new speaker, (2) Letter in hand as prop, (3) Independence declared ("अब मुझे डाकिया नहीं चाहिए"), (4) Echo of postman's earlier words ("चिट्ठी आई, मैंने पढ़ ली"). A poor answer that has the postman still reading *for* the villager reveals the student missed the structural arc from dependence → independence — the poem's entire narrative purpose.

## COMMON_MISCONCEPTION
Students treat this poem as a *lyric* (expressing feeling) rather than a *narrative* (telling a story with characters, conflict, sequence). They write "the poet feels sad about illiteracy" instead of "the postman character confronts the villager character's illiteracy through dialogue." This error stems from Class 10 focus on *bhav* (emotion) over *kathanak* (plot) in poems like "पुष्प की अभिलाषा." In senior secondary, narrative poems demand *structural* reading: who speaks, to whom, in what order, toward what end.

## ON_FAILURE
1. **Re-read aloud with speaker labels**: Print the poem, write "डाकिया" and "ग्रामीण" in margins at every voice change. 2. **Storyboard it**: Draw 6 boxes — one per narrative stage — sketch the action (stick figures fine), write one Hindi line from the poem per box. 3. **Identify the "turn"**: Find the exact line where power shifts (postman's "पढ़ ले!" in Stanza 6). 4. **Explain to a peer**: Teach the narrative arc to someone who hasn't read it — teaching forces structural clarity. Do NOT re-read the chapter summary; it gives interpretation, not structure.

## BUILDS_ON
c11_hin_ar_cbse_12_001 (Context and Background) — provides the historical reality of rural postal systems and literacy gaps that the narrative structure dramatizes.

## LEADS_TO
c11_hin_ar_cbse_12_003 (Setting and Atmosphere) — the narrative structure establishes *when/where* the dialogue occurs; the next node deepens the spatial-temporal texture.

## PREREQUISITE_NODE_IDS
c11_hin_ar_cbse_12_001
## PREREQUISITE_REASONS
c11_hin_ar_cbse_12_001: Provides historical context about the poet Falkyapu, the colonial-era rural setting, and the social problem of illiteracy — without which the narrative conflict (postman vs. illiterate villager) lacks its real-world anchor.

## FORWARD_NODE_IDS
c11_hin_ar_cbse_12_003, c11_hin_ar_cbse_12_004, c11_hin_ar_cbse_12_012, c11_hin_ar_cbse_12_005, c11_hin_ar_cbse_12_006, c11_hin_ar_cbse_12_008, c11_hin_ar_cbse_12_010, c11_hin_ar_cbse_12_013, c12_hin_a_cbse_09_002, c11_hin_ar_cbse_12_007

## FORWARD_REASONS
c11_hin_ar_cbse_12_003: Narrative structure fixes the temporal sequence (postman's arrival → dialogue → departure); setting/atmosphere elaborates the sensory world within that sequence.
c11_hin_ar_cbse_12_004: The protagonist (postman) is introduced through narrative *action* (arriving, speaking, persuading) before character analysis examines his traits.
c11_hin_ar_cbse_12_012: Literal/inferential comprehension questions (e.g., "Why does the postman insist?") require prior grasp of the narrative conflict and its structural development.
c11_hin_ar_cbse_12_005: Establishes the narrative structure — the maid's appearances mark the poem's dramatic beats.  
c11_hin_ar_cbse_12_006: Establishes the narrative arc (dialogue → conflict → resolution) that structures the theme's development.  
c11_hin_ar_cbse_12_008: Narrative structure tells us the poem moves from description → dialogue → resolution; metaphors cluster at turning points (Paik's speeches).  
c11_hin_ar_cbse_12_010: Establishes the narrative arc (resistance -> struggle -> negotiation -> resolution) which dictates the emotional valence of each key word at its specific occurrence.  
c11_hin_ar_cbse_12_013: Understanding the narrative structure (three movements) is essential to trace how irony develops across the poem's architecture.  
c12_hin_a_cbse_09_002: Practiced literal/inferential questions on structure.  
c11_hin_ar_cbse_12_007: यदि अटका हुआ महसूस हो, तो c11_hin_ar_cbse_12_002 (Plot and Narrative Structure) पर लौटकर कविता की घटना-शृंखला (sequence of events) पुनः लिखें — द्वितीयक विषय घटनाओं के बीच की दरारों (gaps) में रहते हैं।  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
none

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_12_001 -> c11_hin_ar_cbse_12_002 -> c11_hin_ar_cbse_12_003

## THIS_FORMULA
N/A - conceptual

## FORMULA_VARIABLES
N/A

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
analytical

## CROSS_SUBJECT
c11_history_colonial_communication | The poem's postman figure reflects the historical expansion of the British Indian postal network into villages, which became a conduit for both colonial administration and nationalist communication — the narrative structure mirrors this dual role (carrier of official letters, enabler of literacy).
c11_sociology_adult_literacy | The dialogue-driven narrative enacts the "each one teach one" pedagogy of 1930s–50s Indian adult literacy movements (e.g., Gandhi's Nai Talim), where the literate outsider empowers the illiterate insider through structured conversation — the poem's climax ("पढ़ ले!") is a performative speech act of social change.

## PREREQ_CONCEPT
Narrative arc (exposition, rising action, climax, falling action, resolution) as applied to poetry — not just prose — from Class 10 Hindi (e.g., narrative poems like "राम-लक्ष्मण-परशुराम संवाद" or "उत्साह").

## PREREQ_BEFORE
The student must recognize that poems can have plots with characters, conflict, and sequence — not just images and emotions — and must know the five standard narrative stages by name.

## PREREQ_STUCK
Review "कथानक के सोपान" (narrative stages) from Class 10 Hindi textbook Chapter "पद" or "दोहे" where narrative poems were analyzed for plot structure.

## WORKED_EXAMPLE_1
PROBLEM: Identify the five narrative stages in the poem "पैक डाकिया डाकिया..." and cite one key line (by description, not full quote) as evidence for each stage.

STEPS:
- Step 1: Read the poem twice — first for flow, second to mark every speaker change with "डा." (डाकिया) and "ग्रा." (ग्रामीण) in the margin. This reveals the dialogue structure.
- Step 2: Locate the exposition — the opening situation before conflict. Find the stanzas where the postman arrives and announces letters without yet confronting illiteracy. Evidence: Opening call "डाकिया डाकिया" + description of letters arriving.
- Step 3: Locate the inciting incident — the moment the central problem surfaces. Find where the villager admits inability to read and the postman identifies the solution. Evidence: Villager's line "मैं नहीं पढ़ी" met with postman's "पढ़ लेना अच्छा है".
- Step 4: Trace rising action — the persuasion phase. Identify stanzas where the postman lists concrete benefits of literacy (reading letters, independence, future security). Evidence: Postman's extended speech about "चिट्ठी पढ़ सकेगी", "किसी के सामने हाथ नहीं फैलाना पड़ेगा".
- Step 5: Pinpoint the climax — the structural peak of tension/decision. Find the shortest, most imperative line where the postman commands action. Evidence: Single-line command "डाकिया कहती है: पढ़ ले!" — the only direct imperative in the poem.
- Step 6: Confirm the resolution — the projected new equilibrium. Identify the closing vision of the villager as literate agent. Evidence: Final image of villager reading own letters, "अब तू खुद पढ़ेगी".

REASONING: Narrative poems compress the arc into fewer stanzas than prose, so each stage may occupy just 1–2 stanzas. The dialogue format means stages are marked by *speaker shifts* and *speech act changes* (statement → admission → persuasion → command → vision). Mapping by speaker+function avoids the error of counting stanzas mechanically.

ANSWER:
Exposition: Stanzas 1–2 (Postman arrives, announces letters) — Key line: Postman's call "डाकिया डाकिया" + footsteps.
Inciting Incident: Stanza 3 (Illiteracy revealed as barrier) — Key line: Villager's admission "मैं नहीं पढ़ी".
Rising Action: Stanzas 4–5 (Postman persuades with benefits) — Key line: Postman's promise "चिट्ठी पढ़ सकेगी / किसी के सामने हाथ नहीं फैलाना पड़ेगा".
Climax: Stanza 6 (Direct command to act) — Key line: "डाकिया कहती है: पढ़ ले!"
Resolution: Final lines (Empowered future projected) — Key line: Vision "तू खुद पढ़ेगी / चिट्ठी आई, तू पढ़ लेगी"।

## WORKED_EXAMPLE_2
PROBLEM: Explain how the poem's dialogue-only structure (no narrator, no description) shapes the reader's experience of the literacy conflict.

STEPS:
- Step 1: Verify the claim — scan the poem for any third-person narration ("वह बोली", "डाकिया ने कहा", descriptive adjectives outside speech). Confirm: zero narrator intrusion; 100% direct speech.
- Step 2: Identify the effect of this choice — the reader *becomes* the listener, positioned exactly as the villager: hearing the postman's voice directly, forced to respond. No interpretive filter.
- Step 3: Analyze the power dynamic — in a narrated version, the author could describe the villager's shame internally. Here, the villager *must speak* her shame ("मैं नहीं पढ़ी"), making vulnerability performative and public.
- Step 4: Connect to theme — literacy is about *voice* (ability to speak for oneself through writing). A dialogue-only structure enacts the pre-literate state (oral only) while the postman's speech models the literate voice (structured, persuasive, future-oriented).
- Step 5: Evaluate the structural payoff — the final command "पढ़ ले!" is not advice; it is a speech act that *creates* the possibility of the villager's future voice. The structure performs the theme.

REASONING: Senior-secondary analysis requires moving beyond "what happens" to "how the form enacts the meaning." The absence of a narrator is not a lack — it is a deliberate structural choice that makes the reader experience the oral-to-literate transition the poem advocates.

ANSWER: The dialogue-only structure eliminates narrative distance, forcing the reader to occupy the villager's position — hearing the postman's authoritative voice without authorial mediation. This mirrors the illiterate person's dependence on oral communication. As the postman's speech shifts from informational ("चिट्ठी आई") to persuasive ("पढ़ लेना अच्छा है") to imperative ("पढ़ ले!"), the reader feels the escalating demand for literacy. The form *is* the argument: the poem demonstrates oral culture's limits (only spoken words, no record) while using the postman's structured rhetoric to model what literacy enables — future-oriented, independent, authoritative speech.

## WORKED_EXAMPLE_3
PROBLEM: Compare the narrative structure of this poem with the narrative poem "राम-लक्ष्मण-परशुराम संवाद" (Class 10). Both are dialogue-driven, but how does each use dialogue to structure its central conflict differently?

STEPS:
- Step 1: Recall "राम-लक्ष्मण-परशुराम संवाद" structure — three speakers (Ram, Lakshman, Parshuram), escalating confrontation, mythological stakes, resolution through divine recognition. Dialogue = conflict *between* equals/near-equals.
- Step 2: Map "पैक डाकिया..." structure — two speakers (Postman, Villager), asymmetrical power (literate vs. illiterate), social-realist stakes, resolution through *projected* empowerment. Dialogue = conflict *across* a structural divide.
- Step 3: Analyze dialogue function in Ram-Lakshman-Parshuram — each speech reveals character *and* advances theological debate; the structure is dialectical (thesis-antithesis-synthesis via Ram's calm).
- Step 4: Analyze dialogue function in Paik Dakiyas — each speech reveals *social position*; the structure is pedagogical (teacher-student, persuader-resister). The postman's speeches lengthen; the villager's shorten then vanish (silenced by shame, then by transformation).
- Step 5: Identify the structural climax difference — Ram-Lakshman-Parshuram: Parshuram's bow breaks (external divine sign). Paik Dakiyas: Postman's command "पढ़ ले!" (internal human agency). One resolves via cosmic order; the other via social intervention.
- Step 6: Synthesize — Both use dialogue-as-structure, but Ram-Lakshman-Parshuram uses *multi-voice dialectic* for mythic conflict, while Paik Dakiyas uses *asymmetrical duet* for social transformation. The latter's structure mirrors its message: literacy redistributes voice.

REASONING: Cross-textual structural comparison is a board-exam competency (CBSE Hindi Core, Section C: Critical Thinking). It requires abstracting structural patterns (dialogue types, power symmetry, resolution modes) from specific content — exactly the analytical skill this node builds.

ANSWER: "राम-लक्ष्मण-परशुराम संवाद" employs a **tripartite dialectical structure**: three voices of near-equal mythic weight clash through escalating speeches (Lakshman's anger → Parshuram's challenge → Ram's resolution), resolving via divine recognition (bow breaks). "पैक डाकिया डाकिया..." employs a **bipartite pedagogical structure**: two voices of unequal social power (literate postman vs. illiterate villager) engage in asymmetrical exchange where the dominant voice lengthens (persuasion) and the subordinate voice shrinks (shame/silence), resolving via *projected human agency* ("पढ़ ले!"). The former uses dialogue to *reveal pre-existing hierarchy* (Ram > Parshuram); the latter uses dialogue to *create new hierarchy* (literate > illiterate → then dismantle it). Both are dialogue-driven narratives, but the first is *agonistic* (conflict between equals), the second *transformative* (conflict across a divide that the structure itself bridges).

## COMPETENCY_QUESTION_1
QUESTION: The poem "पैक डाकिया डाकिया..." uses the postman's arrival as its structural anchor. Analyze how the poet transforms a routine event (mail delivery) into a narrative climax through dialogue pacing. Support with three specific structural observations.

COMPETENCY: Analyzing structural craft in narrative poetry

STEPS:
- Step 1: Identify the routine event — postman delivering letters (common, mundane).
- Step 2: Trace how dialogue pacing escalates it — count speeches per stanza: Stanza 1 (1 speech: postman), Stanza 2 (1 speech: postman), Stanza 3 (2 speeches: villager + postman), Stanza 4 (1 long speech: postman), Stanza 5 (1 long speech: postman), Stanza 6 (1 ultra-short speech: postman command).
- Step 3: Observe the villager's shrinking voice — from full admission (Stanza 3) to silence (Stanzas 4–6), structurally enacting disempowerment.
- Step 4: Note the postman's expanding authority — from announcer to persuader to commander, each speech longer and more future-oriented.
- Step 5: Conclude — the climax is not the arrival (Stanza 1) but the *verbal intervention* (Stanza 6) that reframes the routine event as a literacy intervention.

ANSWER: The poet transforms routine mail delivery into narrative climax through three structural devices: (1) **Speech redistribution** — the postman's speeches grow from 1 line (Stanza 1) to 4+ lines (Stanzas 4–5) while the villager's voice vanishes after Stanza 3, pacing the shift from equality (two speakers) to authority (one speaker). (2) **Temporal expansion in dialogue** — early speeches are present-tense ("चिट्ठी आई"); middle speeches project future ("पढ़ सकेगी", "नहीं फैलाना पड़ेगा"); climax is immediate imperative ("पढ़ ले!"). The dialogue *creates* the future it describes. (3) **Absence of narration** — no narrator explains "this is important"; the dialogue's own pacing forces the reader to feel the escalation. The routine event becomes climactic because the structure makes the postman's final command the *only* way forward — structurally, the poem has no other exit.

DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: A board exam question asks: "कविता की संरचना में डाकिया का आगमन केवल घटना नहीं, एक 'संरचनात्मक उपकरण' है।" (The postman's arrival in the poem's structure is not just an event but a structural device.) Defend or challenge this statement using narrative theory terms (exposition, inciting incident, catalyst, etc.) and poem-specific evidence.

COMPETENCY: Applying narratological concepts to literary analysis

STEPS:
- Step 1: Define "structural device" in narratology — an element that *organizes* the narrative (e.g., a catalyst that triggers the plot, a frame that bounds it) rather than merely occurring within it.
- Step 2: Classify the postman's arrival — it is the **inciting incident** (disturbs equilibrium: letters arrive but cannot be read) AND the **catalyst** (brings the agent of change: the literate outsider).
- Step 3: Show dual function — as *event*, it is "mail comes"; as *device*, it introduces the only character who can speak the literate language that structures the poem's middle and end.
- Step 4: Evidence — without the arrival, no dialogue occurs (the poem is 100% dialogue); without the postman's literate voice, the rising action (persuasion) and climax (command) cannot exist. The arrival *generates* the structure.
- Step 5: Refine — challenge the "only" in "केवल घटना नहीं" — it *is* an event, but its *structural necessity* makes it a device. The statement is defensible: the arrival is the **structural hinge** on which the narrative arc turns.

ANSWER: **Defend.** In narratology, a structural device is an element whose *removal collapses the narrative architecture*. The postman's arrival functions as: (1) **Inciting incident** — shatters the status quo (letters exist but are unreadable). (2) **Catalyst character introduction** — brings the sole literate voice that structures the poem's middle (persuasion) and end (command). (3) **Dialogue enabler** — the poem has zero narration; every stanza is speech. No postman arrival = no postman speech = no poem. (4) **Thematic embodiment** — the arrival *is* the literacy intervention in physical form. Evidence: Stanza 1–2 (arrival) → Stanza 3 (conflict voiced) → Stanzas 4–6 (literate voice dominates). Remove the arrival, and the structural chain (exposition → rising action → climax) has no first link. The statement is accurate: the arrival is an event *elevated to device* by its structural indispensability.

DIFFICULTY: hard