## DEFINITION
Irony in this poem is the sustained contrast between the speaker's repeated denial ("lcls [krjukd ugha gksrk" - is not the most cruel) applied to conventionally tragic events (death, poverty, betrayal) and the final revelation that the true cruelty is the systematic erosion of hope and agency. Symbolism operates through concrete images — the unhealing wound ("pk¡n"), the poison that cannot be spat out ("xhr"), the burning that consumes from within ("jkr"), the darkness where reason vanishes ("fn'kk") — each representing the internalization of oppression that makes resistance impossible.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student can identify at least three distinct instances of irony and three symbols in the poem, explain how each operates using textual evidence, and demonstrate how together they construct the poem's central argument about structural violence.

## SCOPE_BOUNDARY
This node covers irony and symbolism exclusively in Ik's poem "lcls [krjukd" (Chapter 15, Aroh). It does not cover other poems, general definitions without textual anchoring, or other literary devices like metaphor (covered in node 008) or imagery (also node 008).

## WALKTHROUGH
Imagine a friend fails an exam and you say, "Wow, you really nailed it!" — that's verbal irony, but the poem uses a deeper, structural irony: it builds a list of horrors (war, famine, betrayal) only to dismiss each as "not the most cruel," forcing us to ask: then what is? Start by reading the poem aloud, noticing the refrain "lcls [krjukd ugha gksrk" — mark every line where it appears. Then circle the concrete nouns in the second half (wound, poison, fire, darkness). Ask: why does the poet reject the obvious tragedies? Because they are visible, nameable, and therefore resistible. The true cruelty is invisible, internal, and self-perpetuating — that is the symbolic core. The key insight: irony here is not a momentary twist but the poem's entire architecture; symbolism is not decorative but the only language adequate for the unspeakable.

## DIAGNOSTIC_QUESTION_1
In the poem "lcls [krjukd", the phrase "lcls [krjukd ugha gksrk" (is not the most cruel) is repeated multiple times. What is the primary function of this repetition in creating irony?

## DIAGNOSTIC_ANSWER_1
The repetition creates structural irony by establishing a pattern of negation: each time the poet denies that a conventionally recognized horror (war, hunger, betrayal) is the "most cruel," the reader's expectation of a hierarchy of suffering is subverted, preparing the ground for the revelation that true cruelty lies elsewhere. A wrong answer that merely says "it emphasizes the point" misses the ironic displacement — the repetition does not reinforce the listed horrors but systematically dismantles their claim to being the ultimate cruelty.

## DIAGNOSTIC_QUESTION_2
The poem lists "esgur dh ywV" (beauty of youth), "iqfyl dh ekj" (mother's love), and "xíkjh&yksHk dh eq_h" (soldier's sacrifice) as things that are NOT the most cruel. Explain why the poet's choice of these specific positive/valued concepts (rather than only negative ones) deepens the irony.

## DIAGNOSTIC_ANSWER_2
By including cherished values — youth, maternal love, patriotic sacrifice — alongside horrors, the poet implies that even the highest human ideals are powerless against the true cruelty, which is the destruction of the capacity to hope and act. A student who says "the poet is saying these good things are also cruel" has missed the irony: the poet is not calling them cruel; the irony lies in the fact that their *absence* or *destruction* is still not the worst fate — the worst is the loss of the self that could value them.

## DIAGNOSTIC_QUESTION_3
Identify the symbol in the lines "lcls [krjukd og ?kM+h gksrh gS / vkidh dykbZ ij pyrh gqbZ Hkh tks / vkidh fuxkg esa #dh gksrh gS" and explain how it functions as a symbol (not just a metaphor) for the poem's central cruelty.

## DIAGNOSTIC_ANSWER_3
The "?kM+h" (thorn) that pierces even while one walks on one's own path and grows in one's own breath symbolizes self-inflicted suffering born of internalized oppression — the cruelty that makes the victim complicit in their own wounding. A metaphor would say "cruelty is a thorn"; the symbol *is* the thorn, recurring and expanding across the poem (later becoming "pk¡n", "xhr", "jkr"), accumulating meaning as the poem progresses. A wrong answer that treats it as a simple comparison ("cruelty is like a thorn") fails to see how the symbol evolves and embodies the condition it represents.

## DIAGNOSTIC_QUESTION_4
Compare the symbolic progression from "?kM+h" (thorn) → "pk¡n" (wound) → "xhr" (poison) → "jkr" (burning) → "fn'kk" (darkness). What does this sequence reveal about the nature of the "most cruel" condition?

## DIAGNOSTIC_ANSWER_4
The sequence maps the internalization of oppression: a thorn pricks from outside; the wound remains unhealed; the wound becomes poison that cannot be expelled; the poison turns into self-consuming fire; the fire ends in darkness where even reason ("vkRek dk lwjt Mwc") and conscience ("eqnkZ èkwi dk dksbZ VqdM+k") are lost. This is not a random list but a developmental psychology of subjugation. A student who lists them as separate symbols misses the causal chain: each stage is the inevitable consequence of the previous one, showing cruelty as a process, not an event.

## DIAGNOSTIC_QUESTION_5
The poem ends with the refrain "esgur dh ywV lcls [krjukd ugha gksrh / iqfyl dh ekj lcls [krjukd ugha gksrh / xíkjh&yksHk dh eq_h lcls [krjukd ugha gksrhA" Evaluate whether this repetition at the end functions as ironic closure or tragic resignation. Justify with textual evidence.

## DIAGNOSTIC_ANSWER_5
It is ironic closure, not resignation. The first occurrence (stanza 1) is a proposition; the final occurrence is a hard-won truth after the middle stanzas have *defined* the true cruelty. The repetition now carries the full weight of the symbolic definition — it says: even after knowing what the worst is, we must still deny that the old horrors are the worst, because the worst is the system that makes us forget them. Resignation would accept the darkness; irony here reasserts the hierarchy of suffering as an act of resistance. A wrong answer calling it "sad acceptance" ignores the poem's political imperative (the poet's biography: trade unionist, journalist, activist).

## DIAGNOSTIC_QUESTION_6
Write a four-line stanza in Hindi that uses the same structural irony (listing three things that are "not the most X" to reveal a fourth, hidden truth) and at least one symbol from the poem (wound, poison, fire, darkness) to address a contemporary injustice (e.g., climate displacement, digital surveillance, caste humiliation).

## DIAGNOSTIC_ANSWER_6
A strong answer will: (1) establish a refrain "lcls [krjukd ugha gksrk" or equivalent; (2) list three visible injustices (e.g., flood, hunger, loss of home); (3) reveal the hidden cruelty (e.g., the erasure of memory, the algorithm that predicts your death, the silence of allies); (4) use a symbol like "xhr" or "fn'kk" to embody that hidden cruelty. Example: "baVh ugha lcls [krjukd / vkSj ugha lcls [krjukd / ?kj ujkus dk duk ugha lcls [krjukd / lcls [krjukd gS / vkids / fnu&fnu dk xhr / tks vki / ugha ulxj ldrsA" A poor answer will lack the ironic structure (just list bad things) or use the symbol decoratively without symbolic necessity.

## COMMON_MISCONCEPTION
Students often confuse the poem's irony with simple contrast ("the poet says war is not cruel") or treat the symbols as static metaphors ("thorn = pain"). The specific error is failing to see that the irony is *cumulative and structural* — each denial builds the case for the final definition — and that the symbols form a *developmental sequence* (thorn → wound → poison → fire → darkness) representing the stages of internalized oppression. This happens because students are trained to spot devices in isolation, not to trace their architectural function across a whole text.

## ON_FAILURE
1. Have the student physically number the stanzas 1–5 and mark every occurrence of "lcls [krjukd ugha gksrk" with a highlighter. 2. Ask: "What changes between the first time you see this phrase and the last time?" Guide them to see that the *meaning* of the phrase changes because the middle stanzas have filled it with new content. 3. Draw the symbolic chain on paper: thorn → wound → poison → fire → darkness. Ask: "If you remove 'poison', does 'fire' still make sense?" This forces recognition of causal linkage. 4. Assign a micro-writing: "In two sentences, explain why the poet *had to* use irony instead of directly saying 'the worst cruelty is losing hope.'"

## BUILDS_ON
c11_hin_ar_cbse_15_008 (Literary Devices: Imagery and Metaphor) — students must already distinguish metaphor (explicit comparison) from symbol (embodied, evolving meaning) and understand how imagery prepares symbolic resonance.

## LEADS_TO
c11_hin_ar_cbse_15_013 (Critical Thinking: Analysis and Interpretation) — the ability to trace irony and symbolism across the whole poem is the foundation for the critical essay and interpretation tasks in that node.

## PREREQUISITE_NODE_IDS
c11_hin_ar_cbse_15_008, c11_hin_ar_cbse_15_006, c11_hin_ar_cbse_15_007

## PREREQUISITE_REASONS
c11_hin_ar_cbse_15_008: Students need the distinction between metaphor and symbol established in the Imagery and Metaphor node to avoid reducing the poem's symbols to simple comparisons.
c11_hin_ar_cbse_15_006: The Primary Theme node (structural violence, erasure of agency) provides the thematic anchor without which irony and symbolism become empty formal exercises.
c11_hin_ar_cbse_15_007: Irony and symbolism analysis depends on understanding the gap between negated ideals and affirmed realities that secondary themes expose.  

## FORWARD_NODE_IDS
c11_hin_ar_cbse_15_010, c11_hin_ar_cbse_15_012, c11_hin_ar_cbse_15_013, c11_hin_ar_cbse_15_014, c11_hin_ar_cbse_15_015, c12_hin_a_cbse_03_009, c12_hin_a_cbse_05_009, c12_hin_a_cbse_10_009, c12_hin_a_cbse_15_009, c12_hin_al_cbse_01_009, c12_hin_ar_cbse_09_009, c12_hin_ar_cbse_12_009, c12_hin_ar_cbse_15_009

## FORWARD_REASONS
c11_hin_ar_cbse_15_010: Vocabulary in Context requires understanding how words like "pk¡n", "xhr", "jkr", "fn'kk" acquire symbolic weight beyond dictionary meaning.
c11_hin_ar_cbse_15_012: Comprehension questions (literal and inferential) directly test the ability to track ironic structure and symbolic progression.
c11_hin_ar_cbse_15_013: Critical Thinking tasks demand the analytical framework built here — tracing how form (irony, symbol) enacts content (internalized oppression).
c11_hin_ar_cbse_15_014: Irony and symbolism understanding allows deeper Explanation of how devices create meaning.  
c11_hin_ar_cbse_15_015: Irony and symbolism deepen interpretive possibilities.  
c12_hin_a_cbse_03_009: Class 11 Antra Chapter 15 covers irony and symbolism in poetry, giving prior exposure to definitions and simpler examples.  
c12_hin_a_cbse_05_009: अगला तार्किक चरण: Irony is a literary device where the intended meaning of words or a situation is opposite to their l... इस नोड की अवधारणाओं को सीधे उपयोग/विस्तारित करता है।  
c12_hin_a_cbse_10_009: Chapter 15 combined irony+symbolism in a single essay — direct rehearsal for this node's competency.  
c12_hin_a_cbse_15_009: Class 11 Antra Chapter 15 covered irony/symbolism in a different text; this node assumes familiarity with device definitions and basic identification.  
c12_hin_al_cbse_01_009: Class 11 Antra Chapter 15 Irony and Symbolism node prepares for creative application.  
c12_hin_ar_cbse_09_009: Integrates irony and symbolism with other devices.  
c12_hin_ar_cbse_12_009: अगला तार्किक चरण: Irony in this story is the contrast between appearance and reality — where the wealthy waste water c... इस नोड की अवधारणाओं को सीधे उपयोग/विस्तारित करता है।  
c12_hin_ar_cbse_15_009: Provides foundational definitions and identification practice for irony and symbolism from Class 11.  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
none

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_15_008 -> c11_hin_ar_cbse_15_009 -> c11_hin_ar_cbse_15_013

## THIS_FORMULA
N/A - conceptual

## FORMULA_VARIABLES
N/A

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
conceptual

## CROSS_SUBJECT
c11_history_colonialism | The poem's depiction of internalized oppression (thorn → wound → poison → fire → darkness) mirrors the colonial psychology analyzed in Frantz Fanon's "Wretched of the Earth" — a concrete historical parallel for the symbolic sequence.
c11_political_science_power | The structural irony (denying obvious horrors to name the hidden one) illustrates Steven Lukes' "third dimension of power" — shaping desires so that the oppressed accept their oppression — a core Class 11 Political Science concept.

## PREREQ_CONCEPT
Distinction between metaphor (explicit comparison) and symbol (concrete entity that embodies and evolves meaning across a text).

## PREREQ_BEFORE
Student must be able to identify the refrain "lcls [krjukd ugha gksrk" and list the five key symbols (thorn, wound, poison, fire, darkness) in order of appearance.

## PREREQ_STUCK
Review the "Symbol vs. Metaphor" table in node 008 and re-read the poem marking only the refrain and the five symbols.

## WORKED_EXAMPLE_1
PROBLEM: Analyze how the first stanza of "lcls [krjukd" establishes the poem's ironic structure. Use the 4-step evidence-based method: (1) State the point, (2) Quote evidence, (3) Explain, (4) Link to central idea.
STEPS:
- Step 1: Identify the ironic move — the stanza lists three universally acknowledged tragedies (war, hunger, betrayal) and denies each is "the most cruel."
- Step 2: Quote the key lines: "esgur dh ywV lcls [krjukd ugha gksrh / iqfyl dh ekj lcls [krjukd ugha gksrh / xíkjh&yksHk dh eq_h lcls [krjukd ugha gksrh" — note the progression from natural beauty to human love to civic sacrifice.
- Step 3: Explain the irony: by including positive values (youth, mother's love, soldier's sacrifice) alongside horrors, the poet implies that even the *loss* of these is not the ultimate cruelty — the ultimate cruelty must be something that destroys the very capacity to value them.
- Step 4: Link to central idea: this opening irony sets up the poem's argument that structural violence (caste, class, state power) is worse than episodic violence because it attacks the subject's agency and hope.
REASONING: The 4-step method forces textual grounding (step 2) and prevents vague claims. Step 3's explanation of *why these three* is the analytical core — without it, the student only sees a list.
ANSWER: The first stanza uses structural irony by denying the "most cruel" status to three escalating categories of loss — natural, emotional, civic — thereby creating a vacuum that the rest of the poem fills with the true cruelty: the internalized erasure of hope and reason.

## WORKED_EXAMPLE_2
PROBLEM: Trace the symbolic development of "pk¡n" (wound) across stanzas 2 and 3. Show how it transforms from a physical injury to a psychological condition.
STEPS:
- Step 1: Locate the first appearance: "lcls [krjukd og ?kM+h gksrh gS / vkidh dykbZ ij pyrh gqbZ Hkh tks / vkidh fuxkg esa #dh gksrh gS" — the thorn that becomes a wound by persisting in the victim's own breath.
- Step 2: Locate the explicit naming: "lcls [krjukd og pk¡n gksrk gS / tks gj gR;kdkaM osQ ckn / ohjku gq, vk¡xuksa esa p<+rk gS / ij vkidh vk¡[kksa dks fepks± dh rjg ugha xM+rk gS" — the wound that survives "gj gR;kdkaM" (great revolutions) and sits in "ohjku gq, vk¡xuksa" (broken bones).
- Step 3: Analyze the shift: initially the wound is inflicted from outside (thorn on path); later it is revealed as *unhealable* despite historical upheaval ("gj gR;kdkaM") and *invisible* to the victim's own touch ("vkidh vk¡[kksa dks fepks± dh rjg ugha xM+rk").
- Step 4: Connect to the next symbol: the unhealed wound becomes "xhr" (poison) in stanza 4 — the wound that cannot be touched becomes the poison that cannot be spat out.
REASONING: This step-by-step tracing shows symbolism as process, not static image. The wound's properties (persistence, invisibility to self, survival of revolution) are the poem's diagnosis of structural trauma.
ANSWER: The wound symbol evolves from an external puncture (thorn) to an internal, unhealing, self-invisible condition that outlives political revolution, preparing the ground for the poison symbol — the wound that the victim cannot even reach to heal.

## WORKED_EXAMPLE_3
PROBLEM: The poem's final stanza reasserts the opening refrain after defining the true cruelty. Write a board-exam style answer (80-100 words) explaining why this repetition is ironic closure, not mere repetition. Use the PEEL structure.
STEPS:
- Step 1 (Point): The final refrain functions as ironic closure because its semantic weight has been transformed by the intervening symbolic definition of true cruelty.
- Step 2 (Evidence): Opening stanza denies "most cruel" to war/hunger/betrayal. Middle stanzas (2-4) define true cruelty as the thorn-wound-poison-fire-darkness sequence — the internalized destruction of agency. Final stanza repeats the denial *after* this definition.
- Step 3 (Explanation): The first denial is a question; the final denial is an answer. The irony: the poet must *still* say "war is not the most cruel" even after showing what is, because the system that produces the true cruelty *depends* on keeping attention on the visible horrors. The repetition is a political act of refusal.
- Step 4 (Link): This mirrors the poet Ik's life as a trade unionist and journalist — the poem's form enacts the resistance it describes: naming the hidden cruelty without letting the visible ones off the hook.
REASONING: PEEL ensures each sentence does analytical work. Step 3's "question vs. answer" distinction is the key to showing *why* it's irony, not repetition. Step 4's biographical link is expected in senior secondary answers.
ANSWER: The final refrain is ironic closure, not repetition. Initially the denial ("war/hunger/betrayal are not the most cruel") poses a question. After stanzas 2-4 define the true cruelty as the internalized erasure of hope (thorn→wound→poison→fire→darkness), the same words become a settled judgment. The irony: the poet must still deny the obvious horrors the "most cruel" title because the system of oppression *requires* us to mistake the visible for the ultimate. The repetition thus becomes resistance — a refusal to let the visible horrors obscure the invisible machinery that produces them.

## COMPETENCY_QUESTION_1
QUESTION: A Class 11 student writes: "The poet uses irony to say that war is not cruel, but a thorn is." Identify the two fundamental misunderstandings in this statement and correct them using evidence from the poem.
COMPETENCY: Critical analysis of peer response / misconception correction
STEPS:
- Step 1: Identify misunderstanding 1 — the student thinks the poet *denies* the cruelty of war, rather than denying it the *superlative* "most cruel."
- Step 2: Identify misunderstanding 2 — the student treats "thorn" as a literal object replacing war, not as the first symbol in a developmental sequence.
- Step 3: Correct using text: Quote "esgur dh ywV lcls [krjukd ugha gksrh" — the poet does not say youth/war is not cruel; the refrain is comparative. Quote the full symbolic chain to show thorn is stage 1 of 5.
- Step 4: Explain why this matters: reducing structural irony to a simple swap ("war → thorn") erases the poem's political argument about the hierarchy of violence.
ANSWER: The student makes two errors: (1) Confusing comparative denial ("not the *most* cruel") with absolute denial ("not cruel"). The poem acknowledges war's cruelty but refuses it the top rank. (2) Treating the thorn as a static metaphor ("cruelty = thorn") instead of the opening symbol in a five-stage sequence (thorn→wound→poison→fire→darkness) that maps the *process* of internalized oppression. Both errors flatten the poem's structural irony and symbolic architecture.
DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: The poem "lcls [krjukd" was written in 1988, after the poet's decades of trade union and journalistic work. How does the symbol "xhr" (poison that cannot be spat out) specifically encode the experience of organized labor's defeat in the late 1980s Indian context? Support with two textual details and one historical inference.
COMPETENCY: Historical-contextual literary analysis
STEPS:
- Step 1: Identify the symbol's textual properties: "lcls [krjukd og xhr gksrk gS / vkiosQ dkuksa rd igq¡pus osQ fy, / tks ejfl;k i<+rk gS / vkrafdr yksxksa osQ njok”kksa ij / tks xaqMs dh rjg vdM+rk gS" — poison that reaches the veins, reads the ejfl (elegy), sits on the wounds of the helpless like a hawk.
- Step 2: Connect "ejfl;k" (elegy for the dead) to the poet's practice of writing for martyred workers — the poison is the *unspoken grief* of the activist who must keep speaking.
- Step 3: Connect "vkrafdr yksxksa osQ njok”kksa ij / tks xaqMs dh rjg vdM+rk gS" to the Emergency/post-Emergency crackdown on unions — the poison is the state's violence internalized as silence.
- Step 4: Historical inference: The 1988 Great Bombay Textile Strike's collapse (after 1982-83) left a generation of organizers with exactly this "poison" — the inability to articulate defeat, the grief that becomes toxic.
- Step 5: Synthesize: The symbol is not generic "suffering" but the specific *political melancholia* of the Left intellectual after the failure of mass mobilization.
ANSWER: The "xhr" symbol encodes the 1980s labor defeat through three textual markers: (1) "ejfl;k i<+rk gS" — the poet-organizer forced to write elegies for fallen comrades, (2) "vkrafdr yksxksa osQ njok”kksa ij" — the state's violence inscribed on the bodies of the poor, (3) "xaqMs dh rjg vdM+rk gS" — the predatory persistence of that violence. Historically, this mirrors the post-1982 Bombay textile strike collapse where union leaders, unable to prevent mass job losses, internalized the defeat as a poison they could neither spit out nor speak — the "ejfl" (elegy) becoming the only remaining speech.
DIFFICULTY: hard