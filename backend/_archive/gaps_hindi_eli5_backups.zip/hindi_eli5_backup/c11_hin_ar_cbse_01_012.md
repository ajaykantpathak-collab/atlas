## DEFINITION
Literal comprehension involves extracting explicitly stated information from the text (facts, events, dialogue, descriptions), while inferential comprehension requires drawing logical conclusions by combining textual evidence with contextual knowledge, character motivations, and thematic patterns that are implied but not directly stated.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student can independently distinguish between literal and inferential questions, locate precise textual evidence for literal answers, and construct multi-step inferential responses that cite specific passages, explain the logical bridge from evidence to conclusion, and connect the inference to broader themes in "Udd Ka Naukri" or similar senior secondary texts.

## SCOPE_BOUNDARY
This node covers literal vs. inferential question classification, evidence-based answer writing using the PEEL structure (Point, Evidence, Explanation, Link), and application to Premchand's "Udd Ka Naukri" (pages 6-19). It does NOT cover critical evaluation of authorial intent (node 013), creative writing based on the text (node 014), or oral discussion skills (node 015).

## WALKTHROUGH
Imagine you're sitting in your Class 11 Hindi exam and see a question: "Why does Vyakti Singh ultimately help the strikers?" Your first instinct might be to write "Because he is kind" — but that's a guess, not an answer. Start by asking: "What does the text explicitly SAY he does?" (Literal: He gives his savings, resigns, joins them). Then ask: "What MOTIVATIONS can I prove from his dialogue and actions?" (Inferential: His father's values, his guilt over privilege, the breaking point at the station). The key insight: every inferential answer must stand on a foundation of literal evidence — you build the invisible bridge using visible bricks from the text.

## DIAGNOSTIC_QUESTION_1
Identify whether the following question about "Udd Ka Naukri" is literal or inferential: "What specific action does Vyakti Singh take when the police arrive at the station to arrest the strikers?"

## DIAGNOSTIC_ANSWER_1
**Correct Answer: Literal.** The text explicitly states: "Vyakti Singh gave his savings to the strikers, resigned from his job, and joined them at the station" (pages 14-15). A student who labels this "inferential" confuses *character motivation* (why he did it) with *explicit action* (what he did). This reveals the misconception that any question about a character's behavior is automatically inferential — but literal questions can ask for explicitly described actions, not just facts about setting or plot sequence.

## DIAGNOSTIC_QUESTION_2
A student writes this answer to an inferential question: "Vyakti Singh helps the strikers because he feels bad for them." Explain why this answer would receive partial marks at best in a Class 11 board exam, and what specific element is missing.

## DIAGNOSTIC_ANSWER_2
**Correct Explanation:** The answer states a plausible inference but provides **zero textual evidence** and **no logical reasoning chain**. In Class 11, inferential answers require: (1) a clear claim, (2) at least two specific textual references (dialogue, action, or description), (3) explanation of how each piece of evidence supports the claim, and (4) a link to a broader theme (e.g., class consciousness, moral awakening). The student's answer is an unsupported opinion — it could apply to any sympathetic character in any story. This reveals the misconception that "inferential" means "give your opinion" rather than "draw a conclusion *grounded in the text*."

## DIAGNOSTIC_QUESTION_3
Using the PEEL structure, write a 4-sentence answer to this inferential question: "How does the station master's attitude toward the strike change from the beginning to the end of the story? Provide two pieces of evidence."

## DIAGNOSTIC_ANSWER_3
**Model Answer:**
**Point:** The station master shifts from dismissive authority to reluctant complicity.  
**Evidence 1:** Early, he calls the strike "a nuisance" and threatens "stern action" (page 7).  
**Evidence 2:** Later, he silently accepts Vyakti Singh's resignation and lets the strikers remain on the platform without calling police (page 15).  
**Explanation:** His silence and inaction at the end contrast with his earlier threats, showing the strike's moral force has undermined his institutional power.  
**Link:** This mirrors the story's theme — institutional authority crumbles when confronted with collective moral courage.

**Why this works:** Each PEEL component is distinct and text-grounded. A wrong answer would merge Evidence and Explanation, use vague references ("he acts differently later"), or omit the thematic Link — revealing the student treats PEEL as a checklist rather than a reasoning scaffold.

## DIAGNOSTIC_QUESTION_4
Compare these two student answers to the same inferential question: "Why does Vyakti Singh's father remain silent when his son resigns?"
- **Answer A:** "Because he is proud of his son."
- **Answer B:** "The text says 'his father sat silent for a long time, then said: You have done well' (page 16). His silence first shows shock at losing the secure job he sacrificed for, then acceptance because his son honored their shared values of integrity over survival."
Which answer demonstrates deeper analytical reasoning, and what specific analytical skill does the weaker answer lack?

## DIAGNOSTIC_ANSWER_4
**Correct Analysis:** Answer B demonstrates deeper analytical reasoning. It **tracks a character's internal shift across time** (shock → acceptance), **uses a direct quote as anchor**, and **connects the micro-moment to a macro-value conflict** (security vs. integrity). Answer A lacks **textual anchoring** and **temporal analysis** — it treats the father's silence as a single static emotion rather than a process. This reveals the misconception that inferential answers only need a "reasonable guess" rather than a **reconstruction of character psychology through textual moments**.

## DIAGNOSTIC_QUESTION_5
A Class 11 student argues: "Since Premchand was a social reformer, Vyakti Singh's decision to join the strike is really Premchand's voice — so the 'inference' about his motivation is just the author's message." Evaluate this claim. Is it a valid interpretive lens or a category error? Justify.

## DIAGNOSTIC_ANSWER_5
**Correct Evaluation:** It is a **category error** that conflates *authorial intent* with *character motivation*. In literary analysis, inferential questions about characters must be answered **internally** (using the character's own context, dialogue, and development) not **externally** (using the author's biography). While Premchand's reformism shapes the *theme*, Vyakti Singh's motivation must be traced through *his* experiences: his father's values (page 6), his guilt at the station (page 10), the breaking point with the police (page 14). A student who uses author biography as evidence for character motivation commits the **intentional fallacy** — a senior secondary error that replaces textual analysis with biographical speculation. Valid approach: "The text constructs Vyakti Singh's motivation through X, Y, Z; this *aligns with* Premchand's thematic concern for..."

## DIAGNOSTIC_QUESTION_6
Create a new inferential question about "Udd Ka Naukri" that requires synthesizing evidence from **at least three different scenes** and connects to the theme of **"education as both liberation and complicity."** Provide the question and a bullet-point outline of the evidence a top-mark answer would use.

## DIAGNOSTIC_ANSWER_6
**Created Question:** "Trace how Vyakti Singh's education (B.A., job preparation) simultaneously empowers him to resist injustice and traps him in the colonial system — using evidence from his childhood, his job, and his final decision."

**Top-Mark Evidence Outline:**
- **Childhood scene (pages 6-7):** Father equates education with "government job = security" — education framed as *compliance tool*.
- **Job scene (pages 8-9):** His B.A. makes him a clerk who *enforces* railway rules against strikers — education as *instrument of oppression*.
- **Station confrontation (pages 14-15):** His literacy lets him read the strikers' pamphlets and *choose* resistance — education as *critical consciousness*.
- **Final resignation (page 16):** He rejects the degree's institutional value ("this piece of paper") for moral integrity — education *transcended*.

**Why this works:** The question demands **cross-scene synthesis** and **thematic dialectic** (liberation vs. complicity). A poor answer would list scenes without showing the *tension* between them, revealing the student cannot hold contradictory textual evidence in simultaneous view — a core Class 11 analytical skill.

## COMMON_MISCONCEPTION
Students believe "inferential" means "subjective interpretation where any answer is valid if you can argue for it." In reality, senior secondary inferential questions have **constrained validity**: your inference must be (1) logically necessitated by the textual evidence, (2) inconsistent with alternative readings, and (3) recognized by the marking scheme as a standard interpretation. For example, claiming "Vyakti Singh joins the strike because he secretly loves the striker's daughter" is *textually impossible* — no evidence supports it, and it contradicts his stated motives. Students make this error because school often rewards "creative guesses" in lower classes, but board exams reward **evidentiary discipline**.

## ON_FAILURE
If a student cannot distinguish literal from inferential or writes unsupported inferences:
1. **Color-code the text:** Give them a photocopy of a key passage (e.g., pages 14-16). Have them highlight **explicit facts** in yellow (literal) and **implied meanings** in green (inferential) — physically separating the two layers.
2. **Play "Evidence or Opinion?":** Read 5 student sentences aloud. Student holds up "E" card if it cites text, "O" if it's opinion. Example: "Vyakti Singh is brave" (O) vs. "Vyakti Singh faces armed police without a weapon" (E — page 14).
3. **Build the bridge backwards:** Give them the inference ("Vyakti Singh values justice over security"). Ask: "What are the *minimum three bricks* (quotes/actions) needed to build this bridge?" They must list exact page references before writing the answer.
4. **Model a "failed inference":** Show an answer with a plausible claim but wrong evidence (e.g., citing his father's death instead of his father's values). Ask: "Why does this evidence not reach the conclusion?" This trains evidentiary precision.

## BUILDS_ON
This node builds on the character analysis of Vyakti Singh (node 01004) and the theme of social justice (node 01006) by requiring students to convert static character/trait knowledge into dynamic evidence-based reasoning.

## LEADS_TO
This node enables critical thinking (node 01013) where students evaluate competing interpretations, and writing skills (node 01014) where they structure full-length analytical essays using the PEEL framework mastered here.

## PREREQUISITE_NODE_IDS
c11_hin_ar_cbse_01_002, c11_hin_ar_cbse_01_004, c11_hin_ar_cbse_01_006, c11_hin_ar_cbse_01_010, c11_hin_ar_cbse_01_001, c11_hin_ar_cbse_01_008, c11_hin_ar_cbse_01_009, c11_hin_ar_cbse_01_011

## PREREQUISITE_REASONS
c11_hin_ar_cbse_01_002: Plot and narrative structure knowledge is essential to locate evidence in the correct scene sequence
c11_hin_ar_cbse_01_004: Character analysis of Vyakti Singh provides the psychological foundation for inferring motivations
c11_hin_ar_cbse_01_006: Primary theme (social justice) gives the thematic framework that guides valid inferences
c11_hin_ar_cbse_01_010: Vocabulary in context ensures students understand key terms (e.g., "satyagraha", "zamindari") when they appear in evidence
c11_hin_ar_cbse_01_001: "Context and Background" refers to the historical, social, biographical, and literary circ... की समझ आवश्यक है, क्योंकि यह नोड (Literal comprehension involves extracting explicitly stated information from the text (fac...) इसी आधार पर आगे बढ़ता है।  
c11_hin_ar_cbse_01_008: Comprehension questions frequently ask "What image suggests...?" or "Explain the metaphor..." — direct application.  
c11_hin_ar_cbse_01_009: Inferential comprehension questions often ask "What does the map represent?" or "Why is the ending ironic?" — direct application.  
c11_hin_ar_cbse_01_011: Comprehension questions require citing linguistic evidence for inferences. c11_hin_ar_cbse_01_013: Critical thinking demands analysis of how language constructs ideology. c11_hin_ar_cbse_01_014: Writing skills need the ability to embed grammatical analysis in structured answers.  

## FORWARD_NODE_IDS
c11_hin_ar_cbse_01_013, c11_hin_ar_cbse_01_014, c11_hin_ar_cbse_01_015, c12_hin_a_cbse_01_012, c12_hin_a_cbse_02_012, c12_hin_a_cbse_03_012, c12_hin_a_cbse_04_012, c12_hin_a_cbse_05_012, c12_hin_a_cbse_06_012, c12_hin_a_cbse_08_012, c12_hin_a_cbse_09_012, c12_hin_a_cbse_12_012, c12_hin_a_cbse_16_012, c12_hin_a_cbse_17_004, c12_hin_a_cbse_17_012, c12_hin_al_cbse_01_012, c12_hin_al_cbse_02_012, c12_hin_al_cbse_03_012, c12_hin_ar_cbse_01_012, c12_hin_ar_cbse_02_012, c12_hin_ar_cbse_03_012, c12_hin_ar_cbse_04_012, c12_hin_ar_cbse_05_012, c12_hin_ar_cbse_12_012, c12_hin_ar_cbse_13_012, c12_hin_v_cbse_02_012, c12_hin_a_cbse_16_001, c12_hin_ar_cbse_09_012

## FORWARD_REASONS
c11_hin_ar_cbse_01_013: Critical thinking requires the evidence-based inference skills mastered here to evaluate competing interpretations
c11_hin_ar_cbse_01_014: Writing skills (analytical essays) directly apply the PEEL structure and textual evidence discipline from this node
c11_hin_ar_cbse_01_015: Develops literal and inferential comprehension skills to accurately cite textual evidence.  
c12_hin_a_cbse_01_012: Class 11 literal/inferential foundation — this node advances it with PEE rigor  
c12_hin_a_cbse_02_012: Class 11 foundation on literal vs inferential classification and basic evidence citation.  
c12_hin_a_cbse_03_012: Class 11 literal/inferential foundation across multiple chapters  
c12_hin_a_cbse_04_012: Class 11 Antra comprehension node established baseline literal/inferential distinction; this node deepens it with board-exam answer structures.  
c12_hin_a_cbse_05_012: Class 11 foundation in literal/inferential distinction  
c12_hin_a_cbse_06_012: Class 11 Antra comprehension foundation for literal/inferential classification.  
c12_hin_a_cbse_08_012: Provides foundational comprehension question types from Class 11.  
c12_hin_a_cbse_09_012: Class 11 foundation on literal/inferential distinction in a different text.  
c12_hin_a_cbse_12_012: Class 11 foundation on literal/inferential distinction and evidence-based answering.  
c12_hin_a_cbse_16_012: अगला तार्किक चरण: Literal comprehension questions require answers directly stated in the text (facts, events, dialogue... इस नोड की अवधारणाओं को सीधे उपयोग/विस्तारित करता है।  
c12_hin_a_cbse_17_004: Teaches literal vs inferential comprehension — essential to move beyond "what the author says" to "what the author reveals about himself."  
c12_hin_a_cbse_17_012: Class 11 literal/inferential foundation — this node assumes familiarity with the *distinction*; Class 12 deepens *application rigor*.  
c12_hin_al_cbse_01_012: Class 11 foundation in literal vs inferential distinction — without this, student lacks the basic vocabulary of comprehension types.  
c12_hin_al_cbse_02_012: Class 11 literal/inferential practice — foundation for Class 12 depth.  
c12_hin_al_cbse_03_012: Class 11 literal/inferential practice builds the foundational skill this node advances.  
c12_hin_ar_cbse_01_012: Class 11 comprehension baseline — this node assumes familiarity with L/I distinction.  
c12_hin_ar_cbse_02_012: Class 11 comprehension foundation — literal/inferential distinction was introduced there; this node deepens it with a more complex poem.  
c12_hin_ar_cbse_03_012: Prior practice with literal/inferential distinction in Class 11.  
c12_hin_ar_cbse_04_012: अगला तार्किक चरण: Literal comprehension is the ability to extract explicitly stated facts, details, and sequences dire... इस नोड की अवधारणाओं को सीधे उपयोग/विस्तारित करता है।  
c12_hin_ar_cbse_05_012: Class 11 Chapter 1 comprehension introduced the literal/inferential distinction.  
c12_hin_ar_cbse_12_012: Provides the baseline literal/inferential classification skill from Class 11.  
c12_hin_ar_cbse_13_012: Class 11 में शाब्दिक/निहितार्थ प्रश्नों का आधारभूत वर्गीकरण और उत्तर-लेखन सिखाया गया था; यह Class 12 का उन्नत अनुप्रयोग है।  
c12_hin_v_cbse_02_012: Aaroh comprehension builds transferable skill.  
c12_hin_a_cbse_16_001: _16_010: Vocabulary in context ensures accurate understanding of key terms (e.g., "वककक", "थकककक"). c11_hin_ar_cbse_01_012: Class 11 literal/inferential foundation. c11_hin_ar_cbse_16_012: Previous chapter's comprehension practice.  
c12_hin_ar_cbse_09_012: The skill of distinguishing explicit vs. implicit meaning developed across Class 11 comprehension nodes (c11_hin_ar_cbse_01_012 to 16_012).  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
none

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_01_004 -> c11_hin_ar_cbse_01_012 -> c11_hin_ar_cbse_01_013

## THIS_FORMULA
PEEL Structure for Inferential Answers: **P**oint (claim) → **E**vidence (2+ textual citations with page/line) → **E**xplanation (logical bridge from evidence to claim) → **L**ink (connection to theme/author's purpose)

## FORMULA_VARIABLES
P = Assertion answering the question; E1, E2 = Specific textual references (quote, action, description); X = Reasoning showing how E supports P; L = Thematic or contextual significance

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
linguistic

## CROSS_SUBJECT
c11_history_nationalism | Premchand's story reflects the 1920s non-cooperation movement; understanding colonial labor strikes requires historical context of railway nationalization and worker mobilization
c11_civics_rights | The story dramatizes the tension between legal duty (clerk's contract) and moral duty (supporting strikers) — a concrete case study for fundamental rights vs. directive principles

## PREREQ_CONCEPT
Character motivation analysis using textual evidence (from node 01004)

## PREREQ_BEFORE
Student must be able to list Vyakti Singh's key actions in sequence and identify his stated values from dialogue

## PREREQ_STUCK
Review the "Character Analysis: Protagonist" node (01004) and re-read pages 6-16 with a focus on Vyakti Singh's dialogue — mark every instance where he explains *why* he acts

## WORKED_EXAMPLE_1
PROBLEM: Answer this inferential question using PEEL: "How does the description of the railway station in the opening scene (pages 6-7) foreshadow the conflict between institutional power and human dignity?" (4 marks)

STEPS:
- Step 1: Identify the question type — inferential (asks "how does description foreshadow," not "what is described"). Requires connecting setting details to thematic conflict.
- Step 2: Locate the opening station description (pages 6-7). Literal evidence: "The station was a small island of order... clerks in crisp uniforms... the station master's bell rang like a temple bell... the platform gleamed with discipline."
- Step 3: Analyze each image for symbolic weight. "Island of order" = fragile colonial control. "Crisp uniforms" = dehumanized compliance. "Bell like temple bell" = false sanctity of authority. "Gleamed with discipline" = surface perfection hiding exploitation.
- Step 4: Construct the logical bridge (Explanation). The station's rigid order *depends* on suppressing the workers' humanity (the "nuisance" of their demands). The foreshadowing works because the text shows order *as* oppression — the strike will shatter this "gleam."
- Step 5: Link to theme. This mirrors the central conflict: colonial modernity (railways) builds efficiency on human suffering. The station is a microcosm of the raj.
- Step 6: Write the PEEL answer. Point: The station's description establishes order as oppression. Evidence: "island of order," "bell like temple bell," "gleamed with discipline." Explanation: These images reveal authority's fragility and moral hollowness. Link: The strike later exposes this by replacing the bell's rhythm with human voices.

REASONING: This models the senior secondary move from "finding symbols" to "explaining how textual details *function* as foreshadowing through thematic resonance." Each step builds the evidentiary chain required for 4-mark answers.

ANSWER:
**Point:** The opening station description foreshadows the conflict by portraying institutional order as a fragile, dehumanizing facade.  
**Evidence 1:** The station is called "an island of order" (page 6) — isolated, artificial, surrounded by the chaos of exploited lives.  
**Evidence 2:** The station master's bell rings "like a temple bell" (page 6) — investing bureaucratic authority with false sacredness.  
**Evidence 3:** The platform "gleamed with discipline" (page 7) — a polished surface maintained by invisible labor.  
**Explanation:** These images collectively show that colonial order *requires* the suppression of human dignity (the workers' "nuisance"). The station's perfection is parasitic on their suffering.  
**Link:** The strike later shatters this gleam not with violence but with moral presence — the workers' dignity exposes the station's order as injustice. This embodies Premchand's theme: true order emerges from justice, not discipline.

## WORKED_EXAMPLE_2
PROBLEM: A student wrote this answer to: "Why does the striker leader say 'We don't want your charity, we want your conscience'?" (page 13). Improve it using PEEL.
**Student's answer:** "He says this because he wants Vyakti Singh to feel guilty and join them. It shows the strikers have self-respect."

STEPS:
- Step 1: Diagnose the weaknesses. The answer has a plausible Point but: (a) no textual Evidence beyond the quote itself, (b) Explanation is psychological speculation ("feel guilty") not text-based, (c) Link is a vague trait ("self-respect") not a thematic connection.
- Step 2: Retrieve deeper evidence. Re-read pages 12-14. Find: (a) The leader refuses Vyakti Singh's money earlier ("keep your charity"), (b) He references Vyakti Singh's father's values ("your father would be ashamed"), (c) He connects the strike to "every worker's right to dignity."
- Step 3: Rebuild the Point with precision. The leader rejects *transactional* sympathy (money) to demand *moral* solidarity (conscience) — framing the strike as a test of character, not economics.
- Step 4: Structure Evidence-Explanation pairs. E1: "Keep your charity" + context of refused money → shows strike is not about material need. E2: "Your father would be ashamed" + reference to father's integrity → invokes inherited moral framework. E3: "Every worker's right to dignity" → universalizes the demand beyond this strike.
- Step 5: Craft the Link. This moment crystallizes the story's argument: justice requires not alms but *ethical recognition* of the other's humanity — the core of Premchand's humanism.
- Step 6: Write the improved answer.

REASONING: This demonstrates the revision process — taking a "common sense" answer and upgrading it to board-standard by replacing speculation with textual chains and thematic depth.

ANSWER:
**Improved Answer:**
**Point:** The striker leader rejects material charity to demand moral solidarity, framing Vyakti Singh's choice as a test of conscience rooted in his father's legacy.  
**Evidence 1:** When Vyakti Singh offers money, the leader says "Keep your charity" (page 12) — refusing the transactional frame that would make the strike a beggar's plea.  
**Evidence 2:** He invokes Vyakti Singh's father: "Your father would be ashamed" (page 13) — anchoring the demand in the values Vyakti Singh was raised with (integrity over survival).  
**Evidence 3:** He universalizes: "This is every worker's right to dignity" (page 13) — elevating the strike from economic dispute to moral claim.  
**Explanation:** By refusing money and invoking heritage/universal rights, the leader forces Vyakti Singh to choose between his class privilege (charity) and his moral inheritance (conscience). The "conscience" demanded is not abstract — it is the specific courage to act on his father's values.  
**Link:** This embodies Premchand's vision: social change comes not from elite benevolence but from the privileged recognizing their complicity and crossing the line — the "conscience" that transforms charity into justice.

## WORKED_EXAMPLE_3
PROBLEM: This 6-mark board question combines literal retrieval, inference, and thematic synthesis: "Trace the evolution of Vyakti Singh's relationship with his father's values from childhood memory to the final scene. Use at least four textual references spanning the beginning, middle, and end of the story."

STEPS:
- Step 1: Map the narrative arc. Identify 4+ key moments: (a) Childhood: father's advice "education = government job = security" (page 6), (b) Job acceptance: Vyakti Singh takes the clerk post to fulfill father's dream (page 7), (c) Crisis: station confrontation where father's values *conflict* with duty (page 14), (d) Resolution: father's silent acceptance then "You have done well" (page 16).
- Step 2: Classify each moment's valence. (a) Values as *external pressure* (compliance), (b) Values as *internalized duty* (willing conformity), (c) Values as *critical conscience* (judgment on his actions), (d) Values as *validated inheritance* (conscious reclamation).
- Step 3: Select precise textual anchors for each. Must include exact phrases: "iw.kZeklh dk pk¡n" (page 6), "firkth us vk'khokZn fn;k" (page 7), "firkth dks Hkh nq%[k gqvk" (page 15), "rkSj dgkµrkSj dke djrs" (page 16).
- Step 4: Build the explanatory chain. Show how each moment *transforms* the relationship: from obedience → to identification → to crisis → to chosen alignment. The evolution is not linear — it's a dialectic.
- Step 5: Synthesize the thematic significance. The father's values are not static "tradition" but a living ethical compass that *guides* Vyakti Singh through the very system (colonial service) they were meant to serve.
- Step 6: Write the structured answer with clear temporal markers (Beginning/Middle/End) and PEEL for each phase.

REASONING: This models the highest-order comprehension skill: **diachronic character analysis** — tracking a value system across the narrative arc using distributed evidence. It combines literal retrieval (4+ references), inference (interpreting psychological shifts), and synthesis (thematic meaning of the evolution).

ANSWER:
**Beginning (Childhood & Job Acceptance — Pages 6-7):**
**Point:** Initially, his father's values operate as external authority equating education with colonial security.  
**Evidence 1:** Father calls a government job "iw.kZeklh dk pk¡n" — "the pinnacle of education" (page 6).  
**Evidence 2:** Vyakti Singh accepts the clerkship thinking "firkth us vk'khokZn fn;k" — "father gave permission/blessing" (page 7), framing compliance as filial duty.  
**Explanation:** The father's values are *received*, not examined. "Education" means *certification for the system*.

**Middle (Station Crisis — Pages 10-14):**
**Point:** The strike forces a confrontation where his father's values become a critical mirror.  
**Evidence 3:** Seeing the strikers' suffering, he recalls his father's integrity: "firkth dks Hkh nq%[k gqvk" — "father too was shocked" (page 15, reflecting on page 10 moment).  
**Evidence 4:** The striker leader's taunt "Your father would be ashamed" (page 13) weaponizes the father's values *against* Vyakti Singh's current role.  
**Explanation:** The inherited values *judge* his present compliance. He cannot be both a "good son" (obeying father's wish for a job) and a "good man" (upholding father's integrity).

**End (Resignation & Validation — Page 16):**
**Point:** He consciously reclaims his father's values on his own terms, transforming obedience into ethical choice.  
**Evidence 5:** Father's silence breaks: "rkSj dgkµrkSj dke djrs" — "You have done well" (page 16), validating the *rebellion* as the true fulfillment.  
**Evidence 6:** Vyakti Singh rejects the degree: "this piece of paper" (page 16) — the institutional symbol of his father's dream is discarded for the *living value* behind it.  
**Explanation:** The father's blessing on the *resignation* (not the job) reveals the values were never about the job — they were about *integrity*. Vyakti Singh finally *owns* them.

**Synthesis:** The evolution traces: **Inheritance → Internalization → Crisis → Conscious Reclamation**. Premchand shows that true tradition is not preserved by obedience but *renewed* by moral courage — the son honors the father by breaking the father's *plan* to keep the father's *principle*.

## COMPETENCY_QUESTION_1
QUESTION: A Class 11 student answers this inferential question: "Why does the narrator describe the striker's wife as 'silent but her eyes spoke'" (page 11)?
**Student's answer:** "It shows she is a strong woman who supports her husband silently. Women in those days didn't speak much but had inner strength."
Evaluate this answer. Identify exactly two specific weaknesses relative to Class 11 board standards, and rewrite the answer to meet the standard.

COMPETENCY: Textual evidence discipline and avoidance of historical generalization

STEPS:
- Step 1: Identify Weakness 1 — The answer uses **historical generalization** ("Women in those days...") instead of **textual evidence**. The text gives no information about "women in those days" — this is external knowledge inappropriately imported.
- Step 2: Identify Weakness 2 — The answer **paraphrases the quote** ("silent but her eyes spoke" → "supports her husband silently") without **analyzing the literary device** (metaphor of eyes speaking) or its **narrative function** (focalization through Vyakti Singh's perception).
- Step 3: Retrieve textual evidence. Page 11: "His wife sat silent... but her eyes spoke... they said: we are with you." Page 12: She brings food to the strikers without a word. Page 15: She tends to the injured.
- Step 4: Construct the improved answer using PEEL with textual anchors and literary analysis.

ANSWER:
**Weaknesses:** (1) Substitutes historical stereotype for textual analysis. (2) Treats the metaphor "eyes spoke" as literal description rather than analyzing its narrative effect (focalization, emotional weight).
**Improved Answer:**
**Point:** The description "silent but her eyes spoke" uses focalized metaphor to convey the striker's wife's moral authority without granting her narrative voice — reflecting both her marginalization and her power.  
**Evidence 1:** The narrator (Vyakti Singh's perspective) notes: "His wife sat silent... but her eyes spoke... they said: we are with you" (page 11) — the metaphor "eyes spoke" translates her silence into articulate solidarity *through his perception*.  
**Evidence 2:** Her subsequent actions — bringing food "without a word" (page 12), tending the injured (page 15) — enact what her eyes "said," making the metaphor a predictive motif.  
**Explanation:** The silence is not passivity; it is a *chosen language* of care and resistance. The narrator's focalization (he "reads" her eyes) makes *her* silence *his* moral awakening — her eyes speak *to him*.  
**Link:** This mirrors the story's gendered politics: women's labor (feeding, nursing) sustains the strike, but their voice is mediated through male perception. Premchand shows dignity in silence — but also the cost of that silence.

DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: This 6-mark question appears in a board paper: "Premchand's 'Udd Ka Naukri' uses the railway station as a microcosm of colonial society. Analyze how three specific setting details from different parts of the story build this microcosm, and explain what the station's transformation in the final scene reveals about the possibility of change."

COMPETENCY: Cross-scene synthesis of setting details for thematic argument

STEPS:
- Step 1: Select three setting details from distinct narrative phases. (a) Opening: "island of order," "bell like temple bell," "gleamed with discipline" (pages 6-7). (b) Middle: Strike chaos — "platform filled with sitting bodies," "slogans on walls," "police boots on stone" (pages 11-13). (c) End: "The bell didn't ring... the platform held a different order... voices instead of whistles" (pages 16-17).
- Step 2: Analyze each as a microcosm element. (a) Opening = colonial order: rigid, hierarchical, sacralized. (b) Middle = rupture: bodies reclaim space, slogans rewrite walls, police = state violence exposed. (c) End = new order: horizontal (voices), not vertical (whistles/bells).
- Step 3: Explain the *mechanism* of microcosm-building. Each detail maps a social relation: bell/whistle = command obedience; sitting bodies = collective refusal; voices = democratic deliberation.
- Step 4: Synthesize the transformation's meaning. The station doesn't return to "normal" — the final order is *qualitatively different* (consensual, human). Change is possible but not through reform — through *moral occupation* of space.
- Step 5: Structure the answer with clear three-part analysis + synthesis paragraph.

ANSWER:
**Opening Station (Pages 6-7) — Colonial Order as Sacred Hierarchy:**  
**Detail:** "The station was an island of order... the station master's bell rang like a temple bell... the platform gleamed with discipline."  
**Analysis:** The "island" isolates the station from the surrounding poverty; the "temple bell" sacralizes bureaucratic authority; the "gleam" is maintained by invisible labor. The station microcosmically enacts colonialism: order imposed from above, sanctified by ritual, sustained by exploitation.

**Strike Station (Pages 11-13) — Rupture and Reclamation:**  
**Detail:** "The platform filled with sitting bodies... slogans chalked on walls... police boots echoing on stone."  
**Analysis:** "Sitting bodies" (Gandhian satyagraha) reclaim space horizontally — no hierarchy. "Slogans on walls" rewrite the station's semiotic landscape: the institution's voice is overwritten. "Police boots" expose the violence undergirding the "gleam." The microcosm fractures: the station becomes a battlefield of meanings.

**Transformed Station (Pages 16-17) — Emergent Moral Order:**  
**Detail:** "The bell didn't ring that day... the platform held a different order... voices instead of whistles."  
**Analysis:** The absent bell = delegitimized authority. "Different order" = not chaos but a new coordination: workers self-organize, share food, debate. "Voices instead of whistles" = communication replaces command. The station now microcosmically enacts the *society the strikers want*: consensual, vocal, human.

**Synthesis — What the Transformation Reveals:**  
The station's arc proves change is possible but **not through institutional reform**. The colonial station *cannot* be reformed — its "gleam" *is* the oppression. Change comes when the oppressed **physically and morally occupy** the space, creating a new order from below. Premchand's realism: the final scene is not utopian (police remain, jobs are lost) but *prefigurative* — the station becomes a glimpse of the possible. The microcosm teaches: structures don't change; people change structures by becoming the structure.

DIFFICULTY: hard