## DEFINITION
"Before You Read: Context and Background" is a preparatory step where students gather essential information about the poet (Sant Eknath), the literary tradition (Abhang/Varkari Sampradaya), the historical period (15th-16th century Maharashtra), and the specific work (Chakigelek from Abhang) to build a mental framework that enables deeper comprehension and analysis of the poem.

## COGNITIVE_LEVEL
understand

## MASTERY_CRITERIA
The student can independently explain who Sant Eknath was, describe the Varkari tradition and Abhang form, identify the historical-social context of 15th-16th century Maharashtra, and articulate how this background shapes the themes and language of the poem — all without referring to notes.

## SCOPE_BOUNDARY
This node covers ONLY the pre-reading context: poet's biography, literary tradition, historical setting, and genre conventions. It does NOT cover plot summary, line-by-line analysis, literary devices, vocabulary, or comprehension questions — those belong to subsequent nodes (c12_hin_a_cbse_07_002 through c12_hin_a_cbse_07_015).

## WALKTHROUGH
Imagine you're about to watch a period film set in 1500s Maharashtra — you'd want to know who the characters are, what society looks like, and what cultural forces shape their lives. The same applies here: before reading "Chakigelek," you must "meet" Sant Eknath, understand the Varkari pilgrimage tradition, and grasp how Abhang poetry works. Start by asking: "Who is speaking? To whom? In what tradition? Why does it matter?" Then systematically collect: (1) poet's life and philosophy, (2) the Abhang form's structure and purpose, (3) the Bhakti movement's social context, (4) the specific occasion of this poem. The key insight: this background isn't extra information — it's the lens through which the poem's simplicity reveals profound depth.

## DIAGNOSTIC_QUESTION_1
Who was Sant Eknath, and what is his significance in the Varkari tradition of Maharashtra?

## DIAGNOSTIC_ANSWER_1
Sant Eknath (c. 1492–1542) was a prominent Marathi saint-poet of the Varkari tradition, known for composing Abhangas that blended devotion to Vitthal (Vishnu) with social reform. He wrote in accessible Marathi, used folk meters, and emphasized egalitarian devotion over ritual. A wrong answer (e.g., confusing him with Tukaram or Namdev, or calling him a Sanskrit scholar) reveals the student hasn't distinguished between Bhakti poets or understood the Varkari lineage's chronological development.

## DIAGNOSTIC_QUESTION_2
Explain in your own words what an "Abhang" is and how it differs from a classical Sanskrit poetic form like a "Shloka."

## DIAGNOSTIC_ANSWER_2
An Abhang is a devotional poetic form in Marathi, characterized by simple language, folk rhythm (often in ovi or similar meters), direct address to God, and themes from daily life — designed for communal singing during Varkari pilgrimages. Unlike a Shloka (Sanskrit, strict meter, scholarly, often philosophical), Abhang uses colloquial Marathi, flexible rhythm, emotional immediacy, and social commentary. A wrong answer that only says "it's a Marathi poem" misses the functional, performative, and structural distinctions critical for analyzing Eknath's craft.

## DIAGNOSTIC_QUESTION_3
The poem "Chakigelek" is described as being from the collection "Abhang." If you were to predict the poem's language, tone, and subject matter based solely on this genre label, what would you expect and why?

## DIAGNOSTIC_ANSWER_3
Expect: simple Marathi (not Sanskritized), conversational tone addressing Vitthal directly, themes of devotion mixed with everyday struggles (hunger, fatigue, social barriers), use of folk imagery (pilgrimage, river, food), and a rhythm suitable for singing. Reason: Abhangas were composed for Varkari pilgrims to sing en route to Pandharpur — they needed to be memorable, emotionally resonant, and accessible to non-literate devotees. A wrong prediction (e.g., "complex metaphors," "philosophical abstraction," "Sanskrit vocabulary") shows the student doesn't connect genre to audience and purpose.

## DIAGNOSTIC_QUESTION_4
Compare the social context of 15th-16th century Maharashtra (as described in the background) with the likely concerns of the Varkari pilgrims. How might this context shape the poem's depiction of "fojg" (hunger) and "ty" (thirst)?

## DIAGNOSTIC_ANSWER_4
The period saw rigid caste hierarchies, ritual orthodoxy, and economic hardship for lower castes. Varkari pilgrims — often from marginalized communities — undertook long journeys on foot, facing physical deprivation and social exclusion. "Hunger" and "thirst" in the poem thus operate on two levels: literal physical need during pilgrimage, and metaphorical spiritual longing denied by orthodox structures. Eknath uses these universal bodily experiences to bridge the human-divine gap and subtly critique social injustice. A superficial answer treating hunger/thirst only as literal needs misses the poem's layered social commentary.

## DIAGNOSTIC_QUESTION_5
Evaluate this claim: "Knowing the poet's biography is unnecessary for understanding a poem — the text should stand on its own." Argue for or against using Sant Eknath's "Chakigelek" as a test case.

## DIAGNOSTIC_ANSWER_5
Against. While close reading is vital, Eknath's life — as a Brahmin who challenged caste norms, edited the Dnyaneshwari, and composed for marginalized pilgrims — directly informs why "Chakigelek" uses a woman's voice (Ukha's wife), folk dialect, and domestic imagery to express devotion. Without this context, the poem's subversion of gender/caste expectations, its deliberate linguistic choices, and its placement in the Varkari reform project remain invisible. A student who agrees with the claim reveals a New Critical bias that ignores how Bhakti poetry functions as lived, communal practice — not just aesthetic object.

## DIAGNOSTIC_QUESTION_6
Create a 3-sentence "background brief" for a classmate who hasn't read the introduction, covering only the three most essential context points they need before reading "Chakigelek."

## DIAGNOSTIC_ANSWER_6
A strong brief: (1) Sant Eknath (1492–1542) was a Varkari saint-poet who wrote Abhangas in simple Marathi for pilgrims walking to Pandharpur. (2) The Varkari tradition centered on devotion to Vitthal, egalitarian community, and singing as spiritual practice — open to all castes and genders. (3) "Chakigelek" is an Abhang dramatizing a pilgrim woman's hunger/thirst on the journey, blending physical need with divine longing. A poor brief lists random facts (birthplace, parents' names) or omits the genre/audience/purpose triangle that unlocks the poem.

## COMMON_MISCONCEPTION
Students treat "context" as a list of memorizable facts (dates, birthplace, other works) rather than an interpretive framework. They write: "Sant Eknath was born in 1492 in Paithan" but cannot explain *why* his Brahmin identity matters for a poem voiced by a lower-caste woman, or *how* the Abhang's oral performance shape its repetition and rhythm. This happens because Class 11 "Before You Read" nodes often encouraged fact-collection over function-analysis. The error costs marks in board exams (where 2-mark questions ask "How does the poet's background reflect in this line?") and in CUET (where inference questions require context-to-text mapping).

## ON_FAILURE
If a student cannot articulate the function of context (not just facts), do: (1) Have them re-read the Class 11 node c11_hin_ar_cbse_01_001 (Before You Read) and identify *one* way the background changed their reading of that chapter's poem. (2) Give them two 2-line excerpts — one from a Sanskrit Shloka, one from an Abhang — and ask: "Which is for singing? Which for recitation? How do you know?" (3) Then return to Eknath: "What in his life made him choose the singing form for this message?" This 15-minute remediation shifts focus from *what* to *why*.

## BUILDS_ON
Class 11 "Before You Read: Context and Background" (c11_hin_ar_cbse_01_001) where students learned to identify poet, period, and genre — but at a factual level; Class 12 deepens this to functional analysis.

## LEADS_TO
c12_hin_a_cbse_07_002 (Text: Plot and Narrative Structure) — the background framework built here directly enables identifying the poem's narrative voice, dramatic situation, and structural choices.

## PREREQUISITE_NODE_IDS
c11_hin_ar_cbse_01_001, c11_hin_ar_cbse_07_001
## PREREQUISITE_REASONS
c11_hin_ar_cbse_01_001: Introduced the "Before You Read" skill at Class 11 level — identifying poet, period, genre — which this node advances to functional analysis.
c11_hin_ar_cbse_07_001: Covered Bhakti movement context in Class 11 Chapter 7; this node assumes familiarity with Varkari tradition basics and builds deeper.

## FORWARD_NODE_IDS
c12_hin_a_cbse_07_002, c12_hin_a_cbse_07_003, c12_hin_a_cbse_07_004, c12_hin_a_cbse_07_006, c12_hin_a_cbse_07_008, c12_hin_a_cbse_07_010, c12_hin_a_cbse_07_013, c12_hin_a_cbse_07_015, c12_hin_a_cbse_06_015, c12_hin_a_cbse_07_005

## FORWARD_REASONS
c12_hin_a_cbse_07_002: Narrative structure analysis requires knowing the dramatic situation (pilgrimage) and speaker (pilgrim woman) established in context.
c12_hin_a_cbse_07_003: Setting/atmosphere (Pandharpur road, night, hunger) is unintelligible without Varkari pilgrimage background.
c12_hin_a_cbse_07_004: Protagonist analysis (Ukha's wife) depends on understanding gender/caste norms Eknath subverts.
c12_hin_a_cbse_07_006: Primary theme (devotion as lived experience) is rooted in Varkari philosophy from context.
c12_hin_a_cbse_07_008: Imagery/metaphor analysis (food, water, night) requires knowing folk vs. classical conventions from genre context.
c12_hin_a_cbse_07_010: Provides historical/cultural context of efyd eqgEen tk;lh and Braj Bhasha.  
c12_hin_a_cbse_07_013: Provides historical context of poet and folk tradition essential for interpreting dialect choice  
c12_hin_a_cbse_07_015: Context on Tulsidas and folk tradition frames discussion scope  
c12_hin_a_cbse_06_015: c12_hin_a_cbse_06_013 -> c12_hin_a_cbse_06_015 -> c12_hin_a_cbse_07_001 (अगले अध्याय का आरंभ)  
c12_hin_a_cbse_07_005: If stuck, review the definition of "viraha" in c12_hin_a_cbse_07_001 (Context) and the protagonist's profile in c12_hin_a_cbse_07_004.  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
No non-Hindi prior class nodes provided in the dataset that directly link to this literary context.

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_01_001 -> c12_hin_a_cbse_07_001 -> c12_hin_a_cbse_07_002

## THIS_FORMULA
Context Framework = (Poet's Identity × Literary Tradition) + (Historical Setting × Genre Function) → Interpretive Lens for Text

## FORMULA_VARIABLES
N/A - conceptual

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
conceptual

## CROSS_SUBJECT
N/A | The Varkari tradition is a major strand of the Bhakti movement in Maharashtra; understanding its social reform agenda (caste, gender, language) requires historical context of 15th-16th century Deccan society.
 N/A | The physical geography of the pilgrimage route (Paithan to Pandharpur, rivers, terrain) shapes the poem's imagery of hunger, thirst, night travel, and communal resting places.
## PREREQ_CONCEPT
Functional genre analysis: understanding that a literary form (Abhang) is shaped by its performance context (pilgrimage singing), audience (mixed-caste pilgrims), and purpose (devotional sustenance).

## PREREQ_BEFORE
Student must know the basic definition of "Bhakti movement," "Varkari," and "Abhang" from Class 11 — not just definitions, but why each matters for how a poem works.

## PREREQ_STUCK
If stuck, review Class 11 Chapter 7 (c11_hin_ar_cbse_07_001) "Before You Read" where Varkari tradition and Abhang form were introduced — focus on the *function* column in the genre table, not the *definition* column.

## WORKED_EXAMPLE_1
PROBLEM: A student reads the background note on Sant Eknath and writes: "Eknath was a Brahmin saint who wrote Abhangas. He lived in Paithan. This poem is from his Abhang collection." The teacher asks: "So what? How does any of this help you read 'Chakigelek'?" Guide the student to transform this fact-list into an interpretive lens.

STEPS:
- Step 1: Identify the facts given — poet's caste (Brahmin), genre (Abhang), collection (Abhang), place (Paithan).
- Step 2: Ask "So what?" for each fact: Brahmin + writing in voice of lower-caste woman = deliberate crossing of caste/gender boundaries. Abhang = oral, performative, for pilgrims. Paithan = starting point of pilgrimage to Pandharpur.
- Step 3: Connect to poem's opening: the speaker is a woman (Ukha's wife), hungry/thirsty on the road, speaking in folk Marathi — each element reflects Eknath's choices informed by his identity and tradition.
- Step 4: Formulate the lens: "This poem uses a marginalized woman's bodily experience to express universal devotion, enabled by a Brahmin poet choosing a folk form for egalitarian worship."
- Step 5: Verify — does this lens predict features in the text? Yes: simple language, direct address to Vitthal, domestic imagery, repetition for singing.

REASONING: This moves from static facts to dynamic interpretive tool. The "So what?" question forces functional thinking — essential for board 2-mark questions and CUET inference items.

ANSWER: The interpretive lens: "Eknath's Brahmin identity + Varkari egalitarianism + Abhang's oral function = a poem that centers a lower-caste woman's physical/spiritual hunger as legitimate devotion." This lens lets the student explain *why* the poem uses folk dialect, why hunger is central, why the tone is conversational — all before reading a single line.

## WORKED_EXAMPLE_2
PROBLEM: Predict the poem's structure and language features based solely on: "Abhang, Varkari pilgrimage, 16th century Maharashtra, composed for singing en route to Pandharpur."

STEPS:
- Step 1: Deconstruct each context element for textual implications.
- Step 2: "Abhang" → stanzaic, refrain, simple meter (ovi-like), repetition for memorability.
- Step 3: "Varkari pilgrimage" → first-person pilgrim voice, road imagery, night/day progression, communal references.
- Step 4: "16th century Maharashtra" → Marathi (not Sanskrit), folk vocabulary, references to local geography (Godavari, Bhima), social realities (caste, gender).
- Step 5: "Composed for singing en route" → rhythmic regularity, call-and-response potential, emotional directness, practical concerns (food, rest, fatigue) mixed with spiritual longing.
- Step 6: Synthesize prediction: The poem will have short stanzas, a recurring refrain, a woman speaker describing physical hardship on the road, direct address to Vitthal, and a resolution linking bodily need to divine grace.

REASONING: This trains the student to generate text-informed hypotheses — a skill tested in CBSE "based on the context, what do you expect?" questions and CUET critical reading items.

ANSWER: Predicted features: (1) 4-6 line stanzas with refrain, (2) folk Marathi vocabulary (e.g., 'fojg', 'ty', 'ekg'), (3) female pilgrim persona, (4) imagery of road, night, hunger, river, (5) direct address 'Vitthal'/'Pandurang', (6) emotional arc from complaint to surrender. Post-reading, the student checks predictions against actual text — building metacognitive habit.

## WORKED_EXAMPLE_3
PROBLEM: A board exam question: "How does the background of the Varkari tradition help you understand the significance of the line 'fojg rki dks c<+k jgk gSA' (hunger and thirst trouble the body) in 'Chakigelek'?" Write a 40-word answer using the context-to-text method.

STEPS:
- Step 1: Recall context point: Varkari pilgrims walked 200+ km, often barefoot, fasting, across castes — bodily deprivation was shared reality.
- Step 2: Recall genre function: Abhang voices the pilgrim's *lived* experience, not abstract theology — the body is the site of devotion.
- Step 3: Connect: The line universalizes the pilgrim's physical suffering as spiritual offering — hunger/thirst become the language of prayer.
- Step 4: Add Eknath's role: As a Brahmin composing for all castes, he validates the low-caste pilgrim's body as worthy of divine attention.
- Step 5: Draft answer: "The Varkari pilgrimage made hunger/thirst universal shared experiences across castes. Eknath's Abhang form — sung by pilgrims — centers this bodily reality as devotion itself. The line transforms physical suffering into spiritual language, affirming that Vitthal meets the devotee in their need, not in ritual purity." (39 words)
- Step 6: Check: Uses context (pilgrimage, caste, genre), quotes line, explains significance, within word limit.

REASONING: Models the exact CBSE 2-mark answer structure: Context point + Genre function + Textual evidence + Significance. Trains students to avoid vague "it shows devotion" answers.

ANSWER: "The Varkari pilgrimage made hunger/thirst universal shared experiences across castes. Eknath's Abhang form — sung by pilgrims — centers this bodily reality as devotion itself. The line transforms physical suffering into spiritual language, affirming that Vitthal meets the devotee in their need, not in ritual purity."

## COMPETENCY_QUESTION_1
QUESTION: A Class 12 student says: "I'll skip the 'Before You Read' section and go straight to the poem — the introduction is just history, not literature." Using your understanding of Sant Eknath and the Abhang tradition, explain why this approach will lead to missing at least three specific layers of meaning in "Chakigelek."

COMPETENCY: Critical thinking — evaluating the necessity of context for literary interpretation

STEPS:
- Step 1: Identify the student's misconception: context = irrelevant history.
- Step 2: Retrieve three context-to-text mappings for this poem: (a) Varkari pilgrimage → bodily imagery as devotion, (b) Abhang oral form → repetition/refrain as musical not decorative, (c) Eknath's Brahmin identity + female low-caste voice → subversion of caste/gender norms.
- Step 3: Explain what is missed without each: (a) hunger/thirst read as mere complaint not sacred offering, (b) structure read as simple not functionally musical, (c) speaker's identity read as neutral not radical.
- Step 4: Conclude: Context isn't background — it's the decoding key for the poem's deliberate choices.

ANSWER: Skipping context loses: (1) The poem's central metaphor — physical hunger as spiritual longing — rooted in Varkari pilgrimage practice where the body's need *is* the prayer. (2) The Abhang's refrain and rhythm as functional for communal singing, not just poetic style — without this, the repetition seems redundant. (3) The radical act of a Brahmin saint voicing a lower-caste woman's experience — without Eknath's reformist context, the gender/caste subversion is invisible. Context here is not "history" but the poem's operating system.

DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: You are given two unknown short poems: one in classical Sanskrit meter (Anushtup), one in Marathi Abhang style. Both describe a devotee offering food to God. Design a 4-question diagnostic checklist to determine which is which — without being told the language. Your questions must test structural, linguistic, performative, and thematic markers.

COMPETENCY: Analytical reasoning — applying genre knowledge to discriminate textual features

STEPS:
- Step 1: Identify the four discriminators: structure (meter/stanza), language (register/vocabulary), performance (recitation vs. singing), theme (abstract vs. embodied).
- Step 2: Frame Q1 (structural): "Does the poem use a fixed classical meter with strict syllable count, or a flexible folk stanza with refrain?"
- Step 3: Frame Q2 (linguistic): "Is the vocabulary Sanskritized (tatsama) or colloquial Marathi (deshi/tadbhava) with folk idioms?"
- Step 4: Frame Q3 (performative): "Is it designed for solo recitation with pauses, or group singing with rhythmic regularity?"
- Step 5: Frame Q4 (thematic): "Does the devotee offer food through ritual symbolism (mantra, mudra) or through personal bodily hunger shared with God?"
- Step 6: Verify: Each question maps to a context element (tradition, genre, function, philosophy) — no language ID needed.

ANSWER: Diagnostic Checklist:
1. Structure: Fixed classical meter (Anushtup: 32 syllables, 4×8) vs. flexible folk stanza with recurring refrain (Abhang: ovi-based, variable, musical).
2. Language: Sanskrit tatsama vocabulary, grammatical complexity vs. colloquial Marathi, tadbhava words, folk expressions (e.g., 'fojg', 'ty', 'ekg').
3. Performance: Solo recitative, meditative pace vs. communal singing, steady rhythm, call-and-response potential.
4. Theme: Ritual offering (external, symbolic, priest-mediated) vs. embodied offering (internal, physical hunger/thirst as direct communion).
These four questions operationalize the context-to-text framework — exactly what CUET critical reading and CBSE competency questions test.

DIFFICULTY: hard