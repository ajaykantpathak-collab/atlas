## DEFINITION
Grammar: Language Usage in the Text refers to the systematic analysis of grammatical structures, lexical choices, and stylistic patterns employed in the prose chapter "जतLFककु ध जतत रचनास" (Chapter 2 of Vitan) to understand how language constructs meaning, reflects the subject matter, and serves the author's communicative purpose.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student must be able to identify at least three distinct grammatical or lexical features (e.g., technical terminology, passive voice prevalence, sentence complexity, dialectal borrowings) in the text, explain their function with textual evidence, and evaluate how these features align with the informative and descriptive aims of the chapter.

## SCOPE_BOUNDARY
This node covers the analysis of grammar and language usage specifically within the NCERT Class 11 Hindi Vitan Chapter 2 text. It does not cover general Hindi grammar rules unrelated to the text, nor does it duplicate the study of literary devices like imagery, metaphor, irony, or symbolism (covered in nodes 008 and 009).

## WALKTHROUGH
Imagine you are reading the chapter and notice words like "इक्यजिकुह", "इकरिकुह", "जस्त.किकुह" and sentences like "ओक्यूबज बनाई जाती है" appearing repeatedly. You wonder why the author chooses these specific terms and structures instead of simpler everyday language. Begin by scanning the text for recurring verb forms (especially passive constructions), technical nouns, and sentence lengths. Categorise them: which are scientific terms? Which reflect local dialect? Which sentence patterns dominate descriptive passages versus narrative ones? The key insight is that the language usage is not arbitrary; it mirrors the cold desert environment, the construction technology, and the community's social organisation, making the text both a linguistic and a cultural document.

## DIAGNOSTIC_QUESTION_1
Define the term "इक्यजिकुह" as used in the chapter and state its English equivalent.

## DIAGNOSTIC_ANSWER_1
"इक्यजिकुह" refers to the topsoil layer that is fertile and suitable for cultivation, equivalent to "topsoil" or "arable soil". A wrong answer (e.g., confusing it with "इकरिकुह" or "जस्त.किकुह") reveals that the student has not distinguished the three soil-type terms defined in the text, indicating a gap in technical vocabulary acquisition which is essential for understanding the region's agricultural constraints.

## DIAGNOSTIC_QUESTION_2
Explain in your own words why the author predominantly uses passive voice constructions (e.g., "ओक्यूबज बनाई जाती है", "मिट्टी डाली जाती है") when describing the construction of houses.

## DIAGNOSTIC_ANSWER_2
The passive voice shifts focus from the human agents (masons, labourers) to the process and materials, creating an objective, impersonal tone appropriate for an explanatory/descriptive text about traditional architecture. A wrong answer that merely identifies the passive voice without linking it to the text's informative purpose shows the student can recognize the form but not analyse its functional significance in this register.

## DIAGNOSTIC_QUESTION_3
Given the sentence from the text: "जब ओक्यूबज की दीवारें खड़ी हो जाती हैं, तब छत डालने का काम शुरू होता है।" Identify the clause types (main/subordinate) and the conjunction used, then rewrite the sentence in active voice without changing the meaning.

## DIAGNOSTIC_ANSWER_3
The sentence contains a subordinate adverbial clause of time ("जब ओक्यूबज की दीवारें खड़ी हो जाती हैं") introduced by "जब", and a main clause ("तब छत डालने का काम शुरू होता है"). Active rewrite: "जब ओक्यूबज की दीवारें खड़ी हो जाती हैं, तब मजदूर छत डालने का काम शुरू करते हैं।" A wrong answer that fails to separate the clauses or misidentifies the conjunction indicates weak syntactic analysis skills; an incorrect active rewrite (e.g., keeping "होता है") shows inability to manipulate voice while preserving tense and aspect.

## DIAGNOSTIC_QUESTION_4
Compare the sentence structure and vocabulary density in the paragraph describing soil types (इक्यजिकुह, इकरिकुह, जस्त.किकुह) with the paragraph describing the social life during festivals. What does the difference reveal about the author's stance toward each subject?

## DIAGNOSTIC_ANSWER_4
The soil-type paragraph uses dense nominal compounds, precise technical terms, and declarative sentences with minimal modification, reflecting a scientific, classificatory stance. The festival paragraph employs longer, more complex sentences with descriptive adjectives, cultural vocabulary, and emotive modifiers, reflecting an ethnographic, participatory stance. A wrong answer that only notes "one is technical, the other is simple" misses the nuanced interplay of syntax and lexicon that encodes the author's dual role as documentarian and insider.

## DIAGNOSTIC_QUESTION_5
Critique the author's decision to retain dialect words like "बाखा", "जस्ता", "लद्दाखी" without glosses in the main text. Is this effective for a national-level textbook audience? Justify your position.

## DIAGNOSTIC_ANSWER_5
Retaining dialect words without glosses preserves authenticity and respects the linguistic identity of the region, but it risks alienating readers unfamiliar with Ladakhi terms. Effectiveness depends on the pedagogical goal: if the aim is immersive cultural exposure, it succeeds; if the aim is immediate comprehension, footnotes would be better. A one-sided answer (e.g., "it is good because it's authentic" without acknowledging accessibility issues) reveals an inability to evaluate trade-offs in register and audience design.

## DIAGNOSTIC_QUESTION_6
Write a 4-5 sentence paragraph describing the construction of a traditional house in your own region, deliberately incorporating: (a) at least two passive voice verbs, (b) one technical term (real or coined) for a local material, and (c) a complex sentence with a subordinate clause of reason.

## DIAGNOSTIC_ANSWER_6
A strong response will demonstrate controlled use of passive voice (e.g., "दीवारें खड़ी की जाती हैं", "छत डाली जाती है"), introduce a plausible technical term (e.g., "लाल-मिट्टी-ईंट" or "चूना-पलस्तर"), and embed a reason clause (e.g., "क्योंकि बरसात अधिक होती है, इसलिए ढलवाँ छत बनाई जाती है।"). A poor response that uses only active voice, lacks a technical term, or produces only simple sentences shows the student cannot yet apply the analysed features productively.

## COMMON_MISCONCEPTION
Students often equate "language usage" with "difficult vocabulary" only, ignoring syntactic patterns (passive voice, clause embedding), morphological structure of technical terms (prefixes like इक्य-, इकर-, जस्त-), and discourse-level choices (paragraph organisation, register shifts). They also confuse grammatical analysis with literary device identification (e.g., calling a passive construction a "metaphor"). This error arises because school grammar exercises typically isolate sentences, whereas this chapter demands analysis of grammar-in-context across paragraphs.

## ON_FAILURE
1. Have the student highlight every verb in two contrasting paragraphs (one technical, one narrative) and label each as active/passive, transitive/intransitive. 2. Ask them to list all nouns ending in "-इकुह" or "-आ" and break them into root + suffix. 3. Provide a short active-voice version of a technical description and ask them to convert it to passive, then discuss what is lost/gained. 4. Finally, have them write a one-paragraph explanation of why the author's grammatical choices suit the text's purpose, using the evidence gathered.

## BUILDS_ON
Vocabulary in Context (node 010) and Text: Plot and Narrative Structure (node 002) provide the content knowledge and lexical base necessary for grammatical analysis.

## LEADS_TO
Comprehension: Literal and Inferential Questions (node 012) and Writing Skills: Based on the Chapter (node 014) directly apply the language-awareness developed here to answer formulation and composition tasks.

## PREREQUISITE_NODE_IDS
c11_hin_v_cbse_02_001, c11_hin_v_cbse_02_002, c11_hin_v_cbse_02_010
## PREREQUISITE_REASONS
c11_hin_v_cbse_02_001: Context and background knowledge frames the register and domain-specific terminology of the text.
c11_hin_v_cbse_02_002: Understanding plot and narrative structure helps locate where descriptive vs. narrative language dominates.
c11_hin_v_cbse_02_010: Vocabulary in Context supplies the meanings of key technical terms (इक्यजिकुह, ओक्यूबज, etc.) that are the building blocks of grammatical analysis.

## FORWARD_NODE_IDS
c11_hin_v_cbse_02_012, c11_hin_v_cbse_02_013, c11_hin_v_cbse_02_014, c11_hin_v_cbse_02_015, c12_hin_a_cbse_04_011, c12_hin_a_cbse_09_011, c12_hin_a_cbse_12_011, c12_hin_ar_cbse_10_011, c12_hin_v_cbse_03_011

## FORWARD_REASONS
c11_hin_v_cbse_02_012: Grammatical awareness enables precise literal comprehension (e.g., identifying who does what in passive constructions) and inference (e.g., why a term is used).
c11_hin_v_cbse_02_013: Critical interpretation of authorial stance relies on analysing syntactic and lexical patterns established here.
c11_hin_v_cbse_02_014: Writing tasks require students to replicate or adapt the text's register, voice, and technical vocabulary.
c11_hin_v_cbse_02_015: Discussion points often centre on language choices; this node equips students to articulate those choices.
c12_hin_a_cbse_04_011: अगला तार्किक चरण: This node analyzes the grammatical structures, syntactic patterns, and language usage specific to th... इस नोड की अवधारणाओं को सीधे उपयोग/विस्तारित करता है।  
c12_hin_a_cbse_09_011: Additional *kriya* practice — consolidates verb morphology analysis.  
c12_hin_a_cbse_12_011: Practice with sandhi/samas identification in literary texts  
c12_hin_ar_cbse_10_011: Vitan Chapter 2 — dialect in memoir.  
c12_hin_v_cbse_03_011: Reinforced practice with syntactic analysis across different chapters.  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS


## CHAIN_DESCRIPTION
c11_hin_v_cbse_02_002 -> c11_hin_v_cbse_02_011 -> c11_hin_v_cbse_02_012

## THIS_FORMULA
N/A - conceptual

## FORMULA_VARIABLES
N/A

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
linguistic

## CROSS_SUBJECT
c11_geography_cold_desert | The chapter's classification of soil (इक्यजिकुह, इकरिकुह, जस्त.किकुह) and house construction techniques (ओक्यूबज) are direct applications of geographical knowledge about cold desert pedology and vernacular architecture.
c11_history_ladakh_culture | The retention of Ladakhi dialect terms (बाखा, जस्ता) and description of community labour systems (फोस्पा, खलाई) reflect historical social organisation and cultural continuity in the trans-Himalayan region.

## PREREQ_CONCEPT
Basic Hindi grammar (voice, tense, clause types, word formation) and prior reading of the chapter to familiarity with its content.

## PREREQ_BEFORE
Student must have read Chapter 2 completely and be able to summarise its main sections (geography, soil, houses, social life) in their own words.

## PREREQ_STUCK
If stuck, review the definitions of इक्यजिकुह, इकरिकुह, जस्त.किकुह, ओक्यूबज, बाखा, फोस्पा from the Vocabulary in Context node (c11_hin_v_cbse_02_010) and practice identifying passive verbs in any Hindi textbook passage.

## WORKED_EXAMPLE_1
PROBLEM: Analyse the use of passive voice in the paragraph describing the construction of an ओक्यूबज (traditional house). Explain how this grammatical choice supports the author's explanatory purpose.

STEPS:
- Step 1: Locate the paragraph in the text that details the construction process (from laying foundation to roof completion).
- Step 2: Extract all finite verbs in that paragraph and classify each as active or passive.
- Step 3: Calculate the proportion of passive verbs; note the agents (if any) expressed by "द्वारा" or implied.
- Step 4: Compare with a parallel active-voice version (e.g., "पस्तकजी दीवारें खड़ी करते हैं" vs "दीवारें खड़ी की जाती हैं") to see the shift in thematic focus.
- Step 5: Conclude that the high frequency of agentless passives centres the process/materials, creating an objective, timeless description suitable for documenting traditional knowledge.

REASONING: Passive voice in technical/explanatory writing backgrounds the human doer to foreground the procedure, making the description reproducible and impersonal. This aligns with the chapter's aim to inform readers about a building system rather than narrate a specific building event.

ANSWER: The construction paragraph uses 8 out of 10 finite verbs in passive voice (e.g., "बनाई जाती है", "डाली जाती है", "लगाई जाती है"). Agents are never mentioned. This produces a generic, instructional tone: the focus is on the sequence of operations (foundation → walls → roof) and the materials (mud, stones, poplar beams), not on the masons. An active version would personalise the account and introduce unnecessary specificity about who builds, which is irrelevant to the architectural description.

## WORKED_EXAMPLE_2
PROBLEM: The text introduces three soil-type terms: इक्यजिकुह, इकरिकुह, जस्त.किकुह. Analyse their morphological structure and explain how the prefixes इक्य-, इकर-, जस्त- function semantically.

STEPS:
- Step 1: Isolate the three terms and note the common suffix "-इकुह" (meaning 'soil/earth' in the local dialect).
- Step 2: Identify the prefixes: इक्य-, इकर-, जस्त-.
- Step 3: Consult the text's definitions: इक्यजिकुह = fertile topsoil, इकरिकुह = subsoil with pebbles, जस्त.किकुह = sandy/barren soil.
- Step 4: Hypothesise the semantic contribution of each prefix based on the definitions (e.g., इक्य- ≈ 'upper/good', इकर- ≈ 'lower/mixed', जस्त- ≈ 'barren/sandy').
- Step 5: Verify by checking if these prefixes appear in other Ladakhi-derived words in the chapter (e.g., जस्ता = barren land).
- Step 6: Explain that the author uses these morphological patterns to convey a precise, hierarchical soil classification system economical for local farmers.

REASONING: Morphological analysis reveals that the author adopts the region's own classificatory lexicon rather than imposing Hindi equivalents (उपजाऊ मिट्टी, कंकरीली मिट्टी, बलुई मिट्टी). This respects indigenous knowledge and gives readers access to the local conceptual framework.

ANSWER: All three terms share the root "-इकुह" (soil). The prefixes encode the local taxonomy: इक्य- denotes the upper, fertile layer; इकर- denotes the lower, pebble-mixed layer; जस्त- (cognate with जस्ता 'barren') denotes the sandy, infertile layer. The author's choice to retain these compound terms instead of translating them preserves the emic (insider) categorisation and signals the text's ethnographic authenticity.

## WORKED_EXAMPLE_3
PROBLEM: Compare the syntactic complexity (average sentence length, clause embedding, coordination vs. subordination) in the opening geographical description (first two paragraphs) with the concluding paragraph about social life during festivals. Relate the differences to the communicative goals of each section.

STEPS:
- Step 1: Select the first two paragraphs (geography/climate) and the final paragraph (festivals/social life).
- Step 2: Count sentences and clauses in each; calculate average clauses per sentence.
- Step 3: Classify clause relations: coordination (और, लेकिन) vs. subordination (क्योंकि, जब, यदि, जिससे).
- Step 4: Note lexical density (ratio of content words to total words) in each.
- Step 5: Interpret: geographical section shows higher subordination (causal/temporal clauses explaining climatic processes), higher lexical density; festival section shows more coordination, lower lexical density, more vocatives and exclamatory tags.
- Step 6: Argue that the former enacts scientific explanation (cause-effect chains), the latter enacts narrative involvement (event sequencing, emotional resonance).

REASONING: Syntactic complexity is not random; it maps onto genre expectations. Explanation demands logical linkage (hence subordination), while narration of communal experience favours paratactic flow and interpersonal markers.

ANSWER: The geographical opening has 7 sentences, 22 clauses (3.1 clauses/sentence), 65% subordination (e.g., "क्योंकि... इसलिए", "जब... तब"), and high lexical density (technical nouns: हिमालय, काराकोरम, पर्वत-श्रेणियाँ). The festival closing has 5 sentences, 11 clauses (2.2 clauses/sentence), 80% coordination (और, फिर, तो), lower lexical density, and includes discourse particles (अरे, वाह). The grammar thus switches from explanatory to celebratory register, mirroring the shift from landscape to lifescape.

## COMPETENCY_QUESTION_1
QUESTION: The author uses the compound term "जस्त.किकुह" to designate a soil type. Using your knowledge of Hindi word-formation (समास/उपसर्ग), deconstruct this term, explain the semantic contribution of each component, and argue why such a technical compound is more effective than a descriptive phrase like "बलुई और बंजर मिट्टी" in this specific text.

COMPETENCY
Morphological analysis and register awareness

STEPS:
- Step 1: Segment "जस्त.किकुह" into "जस्त-" + "-किकुह" (variant of -इकुह).
- Step 2: Identify "जस्त-" as a local root meaning 'barren/sandy' (cf. "जस्ता" in text).
- Step 3: Identify "-किकुह" as the dialect word for 'soil/earth'.
- Step 4: Explain that the compound functions as a single lexical item in the local classification system, carrying a precise, culturally recognised definition.
- Step 5: Contrast with the descriptive phrase: the phrase is longer, uses generic Hindi terms, and loses the emic category boundary that local farmers actually use.

ANSWER: "जस्त.किकुह" = जस्त (बंजर/बलुई) + किकुह (मिट्टी). The compound is a technical term in the Ladakhi agronomic lexicon, denoting a specific soil category with known properties (low moisture retention, high drainage, unsuitable for crops without amendment). The descriptive phrase "बलुई और बंजर मिट्टी" is a loose translation that blurs the categorical precision and erases the indigenous knowledge system the chapter seeks to document. In an expository text about traditional adaptation, the native term signals epistemic respect and informational exactness.

DIFFICULTY
medium

## COMPETENCY_QUESTION_2
QUESTION: Transform the following active-voice sentence, which could appear in a narrative version of the text, into the passive voice used in the actual chapter, and then justify the transformation in terms of information structure and thematic focus: "पस्तकजी ओक्यूबज की दीवारें मिट्टी और पत्थर से बनाते हैं।"

COMPETENCY
Grammatical transformation and stylistic justification

STEPS:
- Step 1: Identify subject (पस्तकजी), verb (बनाते हैं), object (दीवारें), instrumental adjunct (मिट्टी और पत्थर से).
- Step 2: Apply passive formation: object becomes subject (दीवारें), verb becomes passive (बनाई जाती हैं), original subject becomes optional agent (पस्तकजियों द्वारा) or is omitted.
- Step 3: Produce the passive sentence: "ओक्यूबज की दीवारें मिट्टी और पत्थर से बनाई जाती हैं।"
- Step 4: Analyse information structure: active version thematises the masons (topic = people); passive version thematises the walls (topic = construction element).
- Step 5: Justify: the chapter's purpose is to explain the building system, not to tell a story about specific masons. Thematic focus on materials and process aligns with the explanatory genre; agent omission generalises the procedure across all builders.

ANSWER: Passive: "ओक्यूबज की दीवारें मिट्टी और पत्थर से बनाई जाती हैं।" The transformation shifts thematic prominence from human agents to the architectural components and materials. Since the text aims to convey a repeatable, communal building technique rather than a particular construction event, the agentless passive is rhetorically appropriate: it presents the method as collective, timeless knowledge.

DIFFICULTY
hard