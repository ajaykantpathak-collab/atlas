## DEFINITION
Writing skills based on the chapter refer to the ability to compose structured, evidence-based responses (short answers, long answers, essays, diary entries, articles) that demonstrate understanding of the poem's themes, literary devices, and socio-cultural context, using appropriate Hindi language conventions and textual evidence from "सबसे छोटे" (The Smallest).

## COGNITIVE_LEVEL
apply

## MASTERY_CRITERIA
Student can independently write a well-structured answer using the PEEL method (Point, Evidence, Explanation, Link) for a question on the poem, incorporating at least two textual evidences, explaining their significance, linking to the central theme, and using correct Hindi grammar and vocabulary.

## SCOPE_BOUNDARY
This node covers writing analytical and creative responses based on the poem "सबसे छोटे" (e.g., short answers, long answers, diary entry, article, interview script). It does not cover speaking/listening skills (node 015) or detailed identification of literary devices (nodes 008, 009) which are prerequisites.

## WALKTHROUGH
Imagine you are sitting in the exam hall and the question asks: "कविता में विस्थापन की पीड़ा को कवि ने कैसे व्यक्त किया है?" You know the poem but your mind goes blank on how to start. First, read the question twice and underline keywords: 'विस्थापन की पीड़ा' and 'कैसे व्यक्त किया'. Next, recall 2-3 specific images from the poem that show this pain (e.g., the train metaphor, the unheard cries, the loss of loved ones). Then, structure your answer using PEEL: make a clear Point, quote Evidence (lines or paraphrase), Explain how the evidence shows the pain, and Link back to the theme of invisible suffering. Practice this with a sample question now.

## DIAGNOSTIC_QUESTION_1
What does the acronym PEEL stand for in structured answer writing?

## DIAGNOSTIC_ANSWER_1
PEEL stands for Point, Evidence, Explanation, Link. A wrong answer (e.g., "Paragraph, Example, Explanation, Line") reveals the student does not know the standard analytical writing framework used in board exams, leading to disorganized answers that lack logical flow.

## DIAGNOSTIC_QUESTION_2
Why is it necessary to quote exact lines or closely paraphrase specific stanzas when answering a question on poetic imagery?

## DIAGNOSTIC_ANSWER_2
Quoting evidence anchors the analysis in the text, proves the claim is not invented, and allows the examiner to verify the interpretation. A wrong answer like "It makes the answer look longer" shows the student treats evidence as decoration rather than proof, leading to vague, unsubstantiated responses.

## DIAGNOSTIC_QUESTION_3
Write a PEEL paragraph (4-5 sentences) answering: "कवि ने 'सबसे छोटे' शब्द को कैसे पुनर्परिभाषित किया है?" Use two images from the poem.

## DIAGNOSTIC_ANSWER_3
**Point:** कवि 'सबसे छोटे' को पारंपरिक अर्थ (आंसू, आह) से हटाकर विस्थापितों के अदृश्य दुख तक विस्तारित करता है।  
**Evidence:** पहली पंक्ति में "आँसू सबसे छोटे नहीं होते" और तीसरे खंड में "घर से निकलना काम पर / सबसे छोटा होता है"।  
**Explanation:** कवि शारीरिक रूप से छोटी चीजों की तुलना में विस्थापन के उस दर्द को 'सबसे छोटा' बताता है जो समाज की नज़र में नहीं आता।  
**Link:** यह पुनर्परिभाषा प्रवासी मजदूरों की मूक पीड़ा को केंद्र में लाती है।  
A wrong answer that only summarizes the poem without the PEEL structure reveals inability to apply the framework to a new question.

## DIAGNOSTIC_QUESTION_4
Compare these two answers to "कविता का केंद्रीय विषय क्या है?"  
Answer A: "कविता विस्थापन के बारे में है। कवि बताते हैं कि लोग घर छोड़कर जाते हैं और दुखी होते हैं।"  
Answer B: "कविता का केंद्रीय विषय विस्थापन की अदृश्य पीड़ा है। कवि 'सबसे छोटे' शब्द का विरोधाभासी प्रयोग करके दिखाते हैं कि समाज जिसे तुच्छ समझता है (घर छोड़ना), वही वास्तव में सबसे बड़ा दुख है।"  
Identify three differences in quality.

## DIAGNOSTIC_ANSWER_4
1. Answer B states a precise theme ("अदृश्य पीड़ा") while A gives a vague topic ("विस्थापन के बारे में")।  
2. Answer B uses a specific poetic device (विरोधाभास/पुनर्परिभाषा) as analytical lens; A only narrates.  
3. Answer B interprets the poet's intent ("समाज जिसे तुच्छ समझता है..."); A stays at surface level.  
A student who cannot articulate these differences lacks analytical reading skill and will produce descriptive rather than analytical answers.

## DIAGNOSTIC_QUESTION_5
A student writes for a 5-mark question: "कविता में ट्रेन एक रूपक है जो विस्थापन दिखाती है।" Is this sufficient? Justify your evaluation.

## DIAGNOSTIC_ANSWER_5
No, it is insufficient for 5 marks. The answer identifies the metaphor but does not: (a) quote or describe the specific lines where the train appears, (b) explain how the train's movement/motion symbolizes forced migration, (c) connect to the poem's broader theme of unheard suffering. A 5-mark answer requires at least two developed PEEL cycles. A student who thinks this is enough misunderstands the marking scheme's demand for depth and evidence.

## DIAGNOSTIC_QUESTION_6
Write a diary entry (80-100 words) from the perspective of a migrant worker who has just read this poem, expressing how it reflects their life. Use at least three poetic images.

## DIAGNOSTIC_ANSWER_6
**Criteria for a good answer:**  
- First-person voice, dated entry, emotional tone.  
- Integrates ≥3 images (e.g., "ट्रेन की गड़गड़ाहट", "अनसुनी चीखें", "छूटे हुए रिश्ते") naturally.  
- Shows personal connection: "यह कविता मेरी कहानी कहती है।"  
- Correct Hindi grammar and vocabulary.  
A poor answer writes in third person, lists images mechanically without emotional synthesis, or exceeds word limit without focus, revealing inability to transfer analytical understanding into creative expression.

## COMMON_MISCONCEPTION
Students believe that writing a detailed summary of the poem with a few quoted lines constitutes a good analytical answer. They do not realize that board exam questions demand *interpretation* (e.g., "कैसे व्यक्त किया है", "क्या प्रभाव पड़ता है") which requires explaining *how* the evidence creates meaning, not just *what* happens. For example, when asked "कवि ने विरोधाभास का प्रयोग कैसे किया है?", a student writes the whole stanza containing the paradox but fails to explain the contrast between conventional and redefined 'smallest'.

## ON_FAILURE
1. Show the student a model 5-mark answer with each PEEL component highlighted in different colors.  
2. Give a new question and ask them to write *only* the Point sentence. Provide feedback.  
3. Ask them to add two Evidence lines from the poem. Check accuracy.  
4. Guide them to write Explanation for each evidence: "यह पंक्ति दर्शाती है कि..."  
5. Finally, have them write the Link sentence connecting to the theme. Repeat with 3-4 questions until they internalize the structure.

## BUILDS_ON
Comprehension of literal/inferential meaning (node 012) and critical analysis of themes/devices (node 013).

## LEADS_TO
Speaking and listening discussion (node 015) where structured oral responses mirror written PEEL structure.

## PREREQUISITE_NODE_IDS
c11_hin_ar_cbse_15_012, c11_hin_ar_cbse_15_013, c11_hin_ar_cbse_15_008, c11_hin_ar_cbse_15_009, c11_hin_ar_cbse_15_010, c11_hin_ar_cbse_15_011, c11_hin_ar_cbse_15_006, c11_hin_ar_cbse_15_007

## PREREQUISITE_REASONS
c11_hin_ar_cbse_15_012: Literal and inferential comprehension provides the factual base for evidence selection.  
c11_hin_ar_cbse_15_013: Critical thinking supplies the analytical lens (theme, device, context) for the Point and Explanation.  
c11_hin_ar_cbse_15_008: Imagery and metaphor knowledge enables identification of specific poetic images to quote as Evidence.  
c11_hin_ar_cbse_15_009: Irony and symbolism understanding allows deeper Explanation of how devices create meaning.  
c11_hin_ar_cbse_15_010: Vocabulary in context ensures precise Hindi word choice in writing.  
c11_hin_ar_cbse_15_011: Grammar usage ensures syntactically correct, formal Hindi in answers.
c11_hin_ar_cbse_15_006: Writing skills tasks (e.g., thematic essay) need the primary theme as the thesis statement.  
c11_hin_ar_cbse_15_007: Writing skills tasks (analytical paragraphs, theme essays) require thematic evidence banks built in this node.  

## FORWARD_NODE_IDS
c11_hin_ar_cbse_15_015, c12_hin_a_cbse_05_014, c12_hin_a_cbse_15_014

## FORWARD_REASONS
c11_hin_ar_cbse_15_015: Writing skills (structured arguments, evidence use) directly transfer to organizing spoken points in discussions and presentations.
c12_hin_a_cbse_05_014: अगला तार्किक चरण: Writing Skills based on the chapter refers to the ability to compose structured, evidence-based resp... इस नोड की अवधारणाओं को सीधे उपयोग/विस्तारित करता है।  
c12_hin_a_cbse_15_014: Class 11 foundation in chapter-based writing skills  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS


## CHAIN_DESCRIPTION
c11_hin_ar_cbse_15_012 -> c11_hin_ar_cbse_15_014 -> c11_hin_ar_cbse_15_015

## THIS_FORMULA
PEEL: Point (थीसिस कथन), Evidence (पाठ्य साक्ष्य), Explanation (व्याख्या), Link (विषय से संबंध)

## FORMULA_VARIABLES
P = Point (मुख्य तर्क), E = Evidence (उद्धरण/संदर्भ), E = Explanation (विश्लेषण), L = Link (केंद्रीय विषय से जुड़ाव)

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
linguistic

## CROSS_SUBJECT
c11_history_partition_migration | The poem's depiction of displacement resonates with historical migrations during Partition and later internal migrations; students can use historical facts as contextual evidence in answers.  
c11_economics_labour_migration | Economic concepts of distress migration, informal sector, and wage labor explain the "काम पर निकलना" compulsion; answers can reference these for deeper socio-economic analysis.  
c11_civics_human_rights | The poem's voice for the voiceless aligns with human rights discourse on dignity, shelter, and livelihood; students can frame answers within a rights-based perspective.

## PREREQ_CONCEPT
Understanding of the poem's central theme (invisible suffering of migrants), key images (train, unheard cries, redefined 'smallest'), and the poet's socio-political intent.

## PREREQ_BEFORE
Student must have read the poem multiple times, identified at least 5 key images, and understood the irony in the title "सबसे छोटे".

## PREREQ_STUCK
Review the Theme nodes (006, 007) and Literary Devices nodes (008, 009) to refresh thematic and device-level understanding.

## WORKED_EXAMPLE_1
PROBLEM: Write a 5-mark answer to the question: "कवि ने 'सबसे छोटे' शब्द को कैसे पुनर्परिभाषित किया है? पाठ्य साक्ष्य सहित समझाइए।"  
STEPS:  
- Step 1: Analyze the question – it asks for *redefinition* of a specific term with *textual evidence*.  
- Step 2: Recall the poem's structure – first stanza lists conventional 'small' things (tears, sighs), later stanzas present the migrant's reality as 'smallest'.  
- Step 3: Select two precise evidences: (i) "आँसू सबसे छोटे नहीं होते / आहें सबसे छोटी नहीं होतीं" (stanza 1), (ii) "घर से निकलना काम पर / सबसे छोटा होता है" (stanza 3).  
- Step 4: Draft Point: कवि 'सबसे छोटे' को शारीरिक/भावनात्मक लघुता से सामाजिक-आर्थिक अदृश्यता की ओर मोड़ता है।  
- Step 5: Write Explanation for each evidence: पहली पंक्तियाँ पारंपरिक धारणा खंडित करती हैं; तीसरी पंक्ति दिखाती है कि मजबूरी में घर छोड़ना समाज की नज़र में मामूली है पर वास्तव में सबसे बड़ा दुख है।  
- Step 6: Link: यह पुनर्परिभाषा प्रवासी श्रमिकों के मूक अस्तित्व को रेखांकित करती है।  
REASONING: The PEEL structure ensures each claim is grounded in text, analyzed, and tied to the central theme, meeting board exam criteria for analytical depth.  
ANSWER:  
कवि 'सबसे छोटे' को पारंपरिक अर्थ (आंसू, आह) से हटाकर विस्थापितों के अदृश्य दुख तक विस्तारित करता है। (Point)  
पहले खंड में वह कहता है, "आँसू सबसे छोटे नहीं होते / आहें सबसे छोटी नहीं होतीं" और तीसरे खंड में, "घर से निकलना काम पर / सबसे छोटा होता है"। (Evidence)  
यह विरोधाभास दर्शाता है कि समाज जिसे तुच्छ मानता है (मजदूर का रोज घर छोड़ना), वही वास्तव में सबसे गहरी पीड़ा है क्योंकि यह पहचान, जड़ें और रिश्ते छीन लेता है। (Explanation)  
अतः 'सबसे छोटे' का पुनर्परिभाषित करना प्रवासी श्रमिकों की मूक व्यथा को केंद्रीयता देता है। (Link)

## WORKED_EXAMPLE_2
PROBLEM: Write a diary entry (80-100 words) from the perspective of a migrant worker who has just read this poem, expressing how it reflects their life. Use at least three poetic images.  
STEPS:  
- Step 1: Adopt persona – a migrant worker, first person, dated, informal but expressive Hindi.  
- Step 2: Choose three images from poem: (i) ट्रेन की गड़गड़ाहट (stanza 2), (ii) अनसुनी चीखें/आवाज़ें (stanza 4), (iii) छूटे हुए रिश्ते/घर (stanza 3).  
- Step 3: Structure diary: Date → Salutation ("प्रिय डायरी") → Body (emotional reflection connecting poem to life) → Sign-off.  
- Step 4: Draft body integrating images: "आज यह कविता पढ़कर लगा जैसे मेरी ही कहानी है। ट्रेन की वही गड़गड़ाहट कानों में गूंजती है जो गांव से शहर खींच लाई। 'अनसुनी चीखें' मेरी ही हैं जो मशीनों के शोर में दब जाती हैं। 'घर से निकलना' रोज का कर्म है पर दिल वहीं छूटा रहता है।"  
- Step 5: Check word count, Hindi grammar, emotional authenticity.  
REASONING: Creative tasks require empathy and textual synthesis; using specific images proves engagement with the poem while the diary format tests voice and perspective.  
ANSWER:  
दिनांक: 15 अक्टूबर 2023  
प्रिय डायरी,  
आज 'सबसे छोटे' कविता पढ़ी। लगा कवि ने मेरी ही आत्मा लिख दी। ट्रेन की गड़गड़ाहट अब भी सपनों में पीछा करती है – वही गड़गड़ाहट जो गांव से खींच लाई। कारखाने की मशीनों में मेरी 'अनसुनी चीखें' दब जाती हैं, कोई नहीं सुनता। रोज 'घर से निकलना काम पर' सबसे छोटा काम लगता है दुनिया को, पर मेरे लिए वही सबसे बड़ा दुख है – छूटे रिश्ते, मिट्टी की गंध, मां की राह देखती आंखें। यह कविता मेरी आवाज़ है।  
– एक प्रवासी

## WORKED_EXAMPLE_3
PROBLEM: A student wrote this answer for "कविता का केंद्रीय विषय समझाइए" (3 marks): "कविता विस्थापन के बारे में है। कवि बताते हैं कि मजदूर घर छोड़कर शहर जाते हैं और दुखी रहते हैं। ट्रेन आती है और उन्हें ले जाती है। अंत में कवि कहते हैं कि सबसे छोटा दुख यही है।" Improve this answer using PEEL to make it worthy of full marks.  
STEPS:  
- Step 1: Identify weaknesses – only summary, no analytical term, no specific evidence, no explanation of *how* theme is conveyed.  
- Step 2: Formulate a precise Point: "कविता का केंद्रीय विषय विस्थापन की अदृश्य पीड़ा और समाज की उदासीनता है।"  
- Step 3: Insert Evidence: "कवि 'सबसे छोटे' शब्द का विरोधाभासी प्रयोग करता है – 'आँसू सबसे छोटे नहीं' बनाम 'घर से निकलना काम पर सबसे छोटा होता है'।"  
- Step 4: Add Explanation: "यह विरोधाभास उजागर करता है कि श्रमिक का दैनिक विस्थापन समाज की नज़र में मामूली है, परंतु वही उसकी पहचान का क्षरण करता है।"  
- Step 5: Add second Evidence-Explanation cycle: "ट्रेन का रूपक (दूसरा खंड) अनिवार्य गति का प्रतीक है जो इच्छा नहीं, मजबूरी से चलती है।"  
- Step 6: Link: "इस प्रकार कवि प्रवासी श्रमिक के 'सबसे छोटे' अस्तित्व को सबसे बड़ा मानवीय प्रश्न बना देता है।"  
REASONING: Transforming summary into analysis requires replacing narration with interpretation, each step backed by textual proof – exactly what board examiners reward.  
ANSWER:  
कविता का केंद्रीय विषय विस्थापन की अदृश्य पीड़ा और समाज की उदासीनता है। (Point)  
कवि 'सबसे छोटे' शब्द का विरोधाभासी प्रयोग करता है: "आँसू सबसे छोटे नहीं होते" के बरक्स "घर से निकलना काम पर सबसे छोटा होता है"। (Evidence 1) यह विरोधाभास उजागर करता है कि श्रमिक का दैनिक विस्थापन समाज की नज़र में मामूली है, परंतु वही उसकी पहचान का क्षरण करता है। (Explanation 1)  
ट्रेन का रूपक (दूसरा खंड) अनिवार्य गति का प्रतीक है जो इच्छा नहीं, मजबूरी से चलती है। (Evidence 2) यह दिखाता है कि प्रवास चयन नहीं, जीवित रहने की शर्त है। (Explanation 2)  
इस प्रकार कवि प्रवासी श्रमिक के 'सबसे छोटे' अस्तित्व को सबसे बड़ा मानवीय प्रश्न बना देता है। (Link)

## COMPETENCY_QUESTION_1
QUESTION: "कविता में ट्रेन एक रूपक है जो विस्थापन को दर्शाती है। इस कथन का विश्लेषण पाठ्य साक्ष्य सहित कीजिए।" (5 अंक)  
COMPETENCY: Analytical writing with textual evidence  
STEPS:  
- Step 1: Identify the metaphor (train) and its function (displacement).  
- Step 2: Locate two stanzas where train appears/implied (stanza 2: "ट्रेन की गड़गड़ाहट", stanza 4: "गाड़ी छूटती है")।  
- Step 3: Write Point: ट्रेन रूपक अनैच्छिक, यांत्रिक और निरंतर विस्थापन का प्रतीक है।  
- Step 4: Evidence + Explanation for each: (i) गड़गड़ाहट = पूंजीवादी ताकत जो खींच ले जाती है; (ii) छूटती गाड़ी = लौटने की असंभावना।  
- Step 5: Link to theme of powerlessness.  
ANSWER:  
ट्रेन रूपक अनैच्छिक, यांत्रिक और निरंतर विस्थापन का प्रतीक है। (Point)  
दूसरे खंड में "ट्रेन की गड़गड़ाहट / कानों में गूंजती रहती है" – यह ध्वनि पूंजीवादी उत्पादन तंत्र की अनवरत पुकार है जो ग्रामीण को शहर खींच लाती है, उसकी इच्छा नहीं, पेट की मजबूरी। (Evidence + Explanation)  
चौथे खंड में "गाड़ी छूटती है / और वह नहीं चढ़ पाता" – छूटी हुई गाड़ी वापसी की असंभावना दर्शाती है; जड़ें कट चुकी हैं। (Evidence + Explanation)  
अतः ट्रेन रूपक प्रवासी की विवश गति और समाज की उपेक्षा को मूर्त करता है। (Link)  
DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: "कल्पना कीजिए आप एक पत्रकार हैं जो कवि से इस कविता की आज के संदर्भ में प्रासंगिकता पर साक्षात्कार ले रहे हैं। 10 प्रश्न और उनके संभावित उत्तर लिखिए (संवाद शैली में)।" (Creative synthesis)  
COMPETENCY: Creative synthesis and perspective-taking  
STEPS:  
- Step 1: List 5 core themes: invisible suffering, redefinition of 'small', train as forced migration, unheard voices, home vs livelihood.  
- Step 2: Frame 10 journalist questions covering each theme + current context (lockdown migration, gig economy, policy).  
- Step 3: Craft poet's answers using poem's logic – e.g., "आज भी 'सबसे छोटे' वही हैं जिन्हें गिना नहीं जाता।"  
- Step 4: Ensure dialogue format with names, colons, natural Hindi.  
- Step 5: Connect at least 3 answers to contemporary issues (e.g., 2020 lockdown walk, labor codes).  
ANSWER:  
पत्रकार: आपकी कविता 'सबसे छोटे' आज के प्रवासी संकट में कैसे प्रासंगिक है?  
कवि: आज भी 'सबसे छोटे' वे हैं जिनकी गिनती नहीं होती – लॉकडाउन में पैदल चलते मजदूर, गिग इकॉनमी के डिलीवरी बॉय। उनकी पीड़ा अब भी 'अनसुनी चीख' है।  
पत्रकार: 'ट्रेन की गड़गड़ाहट' रूपक आज क्या दर्शाता है?  
कवि: अब ट्रेन नहीं, हाईवे और ऐप्स की एल्गोरिदम खींचते हैं; गति वही, माध्यम नया।  
... (8 more exchanges linking poem to current realities)  
DIFFICULTY: hard