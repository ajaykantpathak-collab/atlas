## DEFINITION
Secondary themes are the subsidiary ideas that run parallel to the primary theme, enriching the text by exploring specific social, cultural, ecological, or psychological dimensions. In this poem, they include the intimate bond between language and land, the dignity of agricultural labor, ecological consciousness, and the rural-urban divide.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student can identify at least three distinct secondary themes in the poem, cite specific textual evidence (by describing the relevant lines/stanzas) for each, and explain how each secondary theme deepens or complicates the primary theme of returning to one's roots.

## SCOPE_BOUNDARY
This node covers the identification and analysis of secondary themes in the poem "vkvks] feydj cpk,¡" such as language-land connection, dignity of labor, ecological awareness, and rural-urban contrast. It does not cover the primary theme (node 006), literary devices (nodes 008, 009), or vocabulary/grammar (nodes 010, 011).

## WALKTHROUGH
Imagine you are reading the poem aloud and notice the poet repeatedly mentions "mati" (soil), "beej" (seed), "ritu" (season), and "bhasha" (language) in the same breath. Ask yourself: what ideas keep surfacing besides the main call to return? First, mark every stanza that talks about the soil's color, the seed's struggle, or the farmer's sweat. Next, group these markings into clusters: one cluster might be about how language grows from the land, another about the respect for hard work, another about nature's cycles. Then, for each cluster, write a one-sentence theme statement. Finally, check how each statement supports the central message of reconnecting with roots. The key insight is that secondary themes are not just topics; they are the poet's specific perspectives on those topics.

## DIAGNOSTIC_QUESTION_1
What is the definition of a secondary theme in literature?

## DIAGNOSTIC_ANSWER_1
A secondary theme is a subordinate idea that supports or complements the primary theme, exploring specific facets of the central message. A wrong answer (e.g., "it's just another topic") reveals the student confuses theme with subject matter and cannot distinguish between a topic (farming) and a theme (the dignity of labor in farming).

## DIAGNOSTIC_QUESTION_2
In the poem, the line "Hkk"kk esa >kj[kaMhiu" (ruralness in language) suggests a secondary theme. Explain in your own words what this theme is about.

## DIAGNOSTIC_ANSWER_2
This theme highlights that language is not abstract but rooted in the land, shaped by agricultural rhythms and rural life. A wrong answer (e.g., "it means villagers speak differently") shows the student misses the metaphorical link between linguistic vitality and ecological grounding.

## DIAGNOSTIC_QUESTION_3
Identify a stanza where the poet describes the physical labor of farming and explain how it illustrates the secondary theme of dignity of labor.

## DIAGNOSTIC_ANSWER_3
The stanza listing "Hkhrj dh vkx, èkuq"k dh Mksjh, rhj dk uqdhykiu" (plough's line, bullock's sweat, plow's rhythm) portrays labor as sacred and rhythmic. A wrong answer that merely lists the implements without connecting to dignity shows the student cannot move from literal description to thematic interpretation.

## DIAGNOSTIC_QUESTION_4
Compare the portrayal of rural life in the first half of the poem with the implied urban life in the latter half. What secondary theme emerges from this contrast?

## DIAGNOSTIC_ANSWER_4
The contrast reveals the theme of rural-urban alienation: the poem's vivid, sensory rural imagery stands against the implied sterility of urban existence, emphasizing what is lost in modernization. A wrong answer that only describes rural beauty without the contrast indicates failure to analyze structural juxtaposition.

## DIAGNOSTIC_QUESTION_5
Critique the view that the poem's ecological references (seasons, soil, seeds) are merely decorative. Defend your position with evidence.

## DIAGNOSTIC_ANSWER_5
The ecological references are structural, not decorative: the cycle of seasons mirrors the cycle of language and culture; the soil's color ("ekVh dk jax") symbolizes identity. A wrong answer that treats nature imagery as background shows the student cannot evaluate the functional role of imagery in theme-building.

## DIAGNOSTIC_QUESTION_6
Write a four-line stanza in Hindi that introduces a new secondary theme consistent with the poem's tone, such as the role of women in preserving agricultural knowledge.

## DIAGNOSTIC_ANSWER_6
A good stanza would use agricultural metaphors and feminine imagery (e.g., "maati ki godi mein beej bohti maa") and maintain the poem's rhythmic, imperative tone. A poor stanza would be generic ("women work hard") without metaphorical integration, revealing inability to synthesize theme and form.

## COMMON_MISCONCEPTION
Students often list topics like "farming," "seasons," or "village life" as secondary themes without articulating the poet's perspective on them. For example, writing "the theme is farming" instead of "the theme is the sacredness of farming as a cultural anchor." This happens because they confuse the subject (what the poem is about) with the theme (what the poem says about that subject).

## ON_FAILURE
1. Ask the student to pick one recurring image (e.g., "beej" - seed) and complete the sentence: "The poet uses the seed to show that ______." 2. Have them find two other images that complete the same sentence. 3. Guide them to generalize the completed sentence into a thematic statement. 4. Verify by checking if the statement can be supported by at least three distinct stanzas.

## BUILDS_ON
Primary theme analysis (node 006) where the central message of returning to roots is established.

## LEADS_TO
Literary devices analysis (node 008) where imagery and metaphor are examined as tools that build these secondary themes.

## PREREQUISITE_NODE_IDS
c11_hin_ar_cbse_16_001, c11_hin_ar_cbse_16_002, c11_hin_ar_cbse_16_003, c11_hin_ar_cbse_16_006, c11_hin_ar_cbse_16_005

## PREREQUISITE_REASONS
c11_hin_ar_cbse_16_001: Provides biographical and historical context of the poet and the rural milieu.
c11_hin_ar_cbse_16_002: Ensures familiarity with the poem's narrative flow and stanza sequence.
c11_hin_ar_cbse_16_003: Establishes the setting and atmosphere that ground the secondary themes.
c11_hin_ar_cbse_16_006: Gives the primary theme against which secondary themes are defined and compared.
c11_hin_ar_cbse_16_005: Secondary themes (ecological balance, collective memory, language as preservation) emerge from specific supporting character groups.  

## FORWARD_NODE_IDS
c11_hin_ar_cbse_16_008, c11_hin_ar_cbse_16_009, c11_hin_ar_cbse_16_010, c11_hin_ar_cbse_16_011, c11_hin_ar_cbse_16_012, c11_hin_ar_cbse_16_013, c11_hin_ar_cbse_16_014, c11_hin_ar_cbse_16_015, c12_hin_a_cbse_01_007, c12_hin_a_cbse_08_007, c12_hin_a_cbse_10_007, c12_hin_a_cbse_16_007

## FORWARD_REASONS
c11_hin_ar_cbse_16_008: Imagery and metaphor are the primary vehicles for secondary themes.
c11_hin_ar_cbse_16_009: Irony and symbolism deepen the thematic contrasts (rural/urban, tradition/modernity).
c11_hin_ar_cbse_16_010: Key vocabulary (e.g., >kj[kaMhiu, vD[kM+iu) carries thematic weight.
c11_hin_ar_cbse_16_011: Language usage reflects the theme of linguistic rootedness.
c11_hin_ar_cbse_16_012: Comprehension questions test thematic understanding directly.
c11_hin_ar_cbse_16_013: Critical thinking requires synthesizing primary and secondary themes.
c11_hin_ar_cbse_16_014: Writing tasks often ask for thematic analysis essays.
c11_hin_ar_cbse_16_015: Discussion points explore thematic relevance to contemporary issues.
c12_hin_a_cbse_01_007: Chapter 16 synthesized all thematic skills.  
c12_hin_a_cbse_08_007: अगला तार्किक चरण: Secondary themes are the underlying, complementary ideas in a literary work that support, contrast w... इस नोड की अवधारणाओं को सीधे उपयोग/विस्तारित करता है।  
c12_hin_a_cbse_10_007: Synthesizes Class 11 thematic skills for Class 12 application.  
c12_hin_a_cbse_16_007: Class 11 secondary themes node provides foundational skill of theme identification.  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
none

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_16_006 -> c11_hin_ar_cbse_16_007 -> c11_hin_ar_cbse_16_008

## THIS_FORMULA
N/A - conceptual

## FORMULA_VARIABLES
N/A

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
analytical

## CROSS_SUBJECT
c11_history_agrarian_societies | The poem's depiction of rural labor and traditional knowledge connects to historical studies of agrarian societies and peasant movements.
c11_geography_agricultural_patterns | The references to soil types, seasons, and crops align with geographical concepts of agricultural patterns and land use.
c11_economics_rural_development | The rural-urban contrast and dignity of labor theme relate to economic issues of rural development and migration.
c11_civics_local_governance | The call to return to roots and community-based living echoes principles of grassroots democracy and local governance.

## PREREQ_CONCEPT
Ability to distinguish between a topic (subject) and a theme (author's insight about the subject) and to trace recurring motifs across a text.

## PREREQ_BEFORE
Student must have read the poem completely, understood the primary theme (node 006), and be able to locate specific stanzas by their content.

## PREREQ_STUCK
Review the primary theme (node 006) and the setting/atmosphere (node 003) to re-ground yourself in the poem's world.

## WORKED_EXAMPLE_1
PROBLEM: Analyze the secondary theme of "language rooted in land" (Hkk"kk esa >kj[kaMhiu) in the poem.
STEPS:
- Step 1: Locate the phrase "Hkk"kk esa >kj[kaMhiu" and note its placement in the poem (early stanza, setting the tone).
- Step 2: Identify three other stanzas where language or speech is linked to natural elements (e.g., "BaMh gksrh fnup;kZ esa thou dh xekZgV" - language blooms in the soil of life).
- Step 3: List the natural metaphors used for language: soil (ekVh), seed (beej), bloom (xekZgV), color (jax).
- Step 4: Interpret the metaphor: language grows organically from the land, not imposed from outside; it carries the "color" of the soil.
- Step 5: Formulate the theme statement: "Language derives its vitality and authenticity from its connection to the land and rural life."
- Step 6: Connect to primary theme: This secondary theme explains why returning to roots (primary theme) is necessary for linguistic and cultural survival.
REASONING: The poet uses an extended metaphor of agriculture to describe language, making the abstract concept of linguistic vitality concrete and grounded. This metaphorical mapping is the core of the secondary theme.
ANSWER: The secondary theme is that language is not a static system but a living crop nurtured by the land. Evidence: the direct phrase "Hkk"kk esa >kj[kaMhiu", the image of language blooming in life's soil, and the color of soil (ekVh dk jax) symbolizing linguistic identity. This supports the primary theme by showing that uprooting from the land withers language.

## WORKED_EXAMPLE_2
PROBLEM: Examine how the poem establishes the dignity of agricultural labor as a secondary theme.
STEPS:
- Step 1: Scan the poem for verbs and nouns describing farm work (e.g., "Hkhrj" - plough, "èkuq"k" - bullock, "rhj" - plow, "oqQYgkM+h" - harvest, "taxy" - threshing).
- Step 2: Note the sensory details: "vkx" (line/furrow), "Mksjh" (sweat), "uqdhykiu" (rhythm), "èkkj" (fragrance), "rk”kk" (sound), "fueZyrk" (creation).
- Step 3: Observe the absence of drudgery language; instead, work is portrayed as rhythmic, creative, and fragrant.
- Step 4: Compare with the implied urban work: "vfo'okl&Hkjs nkSj" (artificial-busy time) where "FkksM+k&lk fo'okl" (heavy hollow talk) contrasts with productive labor.
- Step 5: Synthesize the theme: Agricultural labor is depicted as dignified, life-giving, and culturally central, unlike alienated urban labor.
- Step 6: Link to primary theme: Returning to roots means reclaiming this dignified labor as identity.
REASONING: The poet elevates labor through aesthetic and sensory language, transforming work into worship. The contrast with urban emptiness sharpens the theme.
ANSWER: The secondary theme is the sanctity and dignity of agricultural labor. Evidence: the catalog of farming actions with positive sensory attributes (sweat as rhythm, harvest as fragrance) and the explicit contrast with "hollow talk" of urban life. This reinforces the primary theme by making the return to roots a return to meaningful work.

## WORKED_EXAMPLE_3
PROBLEM: Identify and analyze the secondary theme of ecological consciousness in the poem, and explain its relationship to the primary theme.
STEPS:
- Step 1: List all ecological elements: seasons (fnup;kZ), soil (ekVh), seed (beej), rain (implied by "gfM+;k"), crops (fny, Hkksykiu), cycles (tq>k:iu, vD[kM+iu).
- Step 2: Note the verbs showing human participation in ecology: "cpk,¡" (plant), "gfM+;k" (sow), "lUFkky ijxuk" (nurture on lap), "vD[kM+iu" (protect), "tq>k:iu" (wait/watch).
- Step 3: Recognize the reciprocal relationship: humans care for land, land sustains humans ("eu dk gjkiu" - heart's coolness, "Hkksykiu fny dk vD[kM+iu" - protecting green gold).
- Step 4: Identify the threat: "vfo'okl&Hkjs nkSj" (artificial busy time) disrupts this reciprocity.
- Step 5: Formulate theme: Ecological consciousness is presented as a mutual care between humans and nature, essential for cultural survival.
- Step 6: Connect to primary theme: The call to "feydj cpk,¡" (plant and nurture) is literally ecological and metaphorically cultural; uprooting causes both ecological and cultural desertification.
REASONING: The poem does not treat nature as backdrop but as partner. The agricultural cycle is a model for cultural continuity. This theme combines environmental and cultural critique.
ANSWER: The secondary theme is ecological reciprocity as cultural imperative. Evidence: the imperative "cpk,¡" addressed to both seeds and relationships, the metaphor of "green gold" (Hkksykiu fny) needing protection, and the contrast with artificial urban time. This deepens the primary theme by showing that returning to roots is an ecological act, not just nostalgic.

## COMPETENCY_QUESTION_1
QUESTION: The poem uses the metaphor of "ekVh dk jax" (color of soil) in two contexts: the color of the earth and the color of language. Explain how this dual reference structures the secondary theme of linguistic rootedness. Provide evidence from at least two different stanzas.
COMPETENCY: Analytical interpretation of metaphor across textual locations.
STEPS:
- Step 1: Identify the first occurrence of "ekVh dk jax" and its literal referent (soil).
- Step 2: Identify the second occurrence where language is described as having this color.
- Step 3: Explain the metaphorical transfer: language acquires the properties of soil (fertility, depth, identity).
- Step 4: Cite a third stanza where language's vitality is linked to rural life (e.g., "BaMh gksrh fnup;kZ esa").
- Step 5: Conclude how this metaphor binds the secondary theme to the primary call to return.
ANSWER: The metaphor "ekVh dk jax" appears first as the physical color of the ploughed field, then as the inherent quality of authentic language ("Hkk"kk esa >kj[kaMhiu"). This transfer means language, like soil, is the medium of growth. The stanza "BaMh gksrh fnup;kZ esa thou dh xekZgV" shows language blooming in life's soil. Thus, losing connection to land (primary theme) drains language of its color. The dual reference structures the theme by making linguistic rootedness tangible.
DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: The poem contrasts "vD[kM+iu" (protecting/nurturing) and "tq>k:iu" (waiting/watchful care) with "FkksM+k&lk fo'okl" (heavy hollow talk). Using these three terms, construct an argument that the poem critiques modernity not just as urban but as epistemologically sterile. Support with textual reasoning.
COMPETENCY: Critical synthesis of lexical contrasts to build a thematic argument.
STEPS:
- Step 1: Define "vD[kM+iu" and "tq>k:iu" in the poem's context: active, patient, embodied engagement with growth.
- Step 2: Define "FkksM+k&lk fo'okl" as speech disconnected from action and earth.
- Step 3: Show how the poem pairs the former with natural cycles (seasons, seeds) and the latter with artificial time ("vfo'okl&Hkjs nkSj").
- Step 4: Argue that the contrast is epistemological: knowledge from participation (vD[kM+iu) vs. knowledge from abstraction (fo'okl).
- Step 5: Conclude that this makes the secondary theme a critique of modern epistemology, not just lifestyle.
ANSWER: "vD[kM+iu" and "tq>k:iu" represent embodied, cyclic knowledge where understanding comes from nurturing and waiting (e.g., protecting green gold, waiting for harvest). "FkksM+k&lk fo'okl" represents disembodied discourse heavy with words but light on substance. The poem aligns the former with "fnup;kZ" (days/seasons) and the latter with "nkSj" (time) that is "vfo'okl&Hkjs" (artificially busy). This contrast critiques modernity's way of knowing: it replaces participatory wisdom with hollow talk. The secondary theme thus becomes an epistemological critique, deepening the primary theme's call to return to a grounded way of knowing.
DIFFICULTY: hard