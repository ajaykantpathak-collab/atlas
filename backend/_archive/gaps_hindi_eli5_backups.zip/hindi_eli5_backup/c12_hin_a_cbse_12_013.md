## DEFINITION
Critical Thinking: Analysis and Interpretation is the ability to move beyond literal comprehension of a literary text to examine its underlying assumptions, evaluate the effectiveness of narrative choices, synthesize multiple textual elements (character, setting, theme, device), and construct an evidence-based argument about the text's meaning, cultural significance, and artistic merit.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student can independently deconstruct a passage from "laofn;k" to explain how the author uses specific narrative techniques (e.g., contrast, symbolism, dialogue) to reveal the conflict between tradition and modernity, and can defend their interpretation with precise textual evidence while acknowledging alternative readings.

## SCOPE_BOUNDARY
This node covers critical analysis of the short story "laofn;k" (Iqbal Bahadur Singh "Jasrak") focusing on: (1) interpreting the symbolic function of the storyteller (laofn;k) and the city visitor (gjxksfcu), (2) analyzing narrative structure (frame story, circular ending), (3) evaluating the author's use of dialect and oral storytelling conventions, and (4) connecting the text to socio-historical context of post-Independence rural India. It does NOT cover basic plot summary, character sketches, or identification of literary devices (covered in nodes 001-012).

## WALKTHROUGH
Imagine you are a journalist visiting a village where the last traditional storyteller has just died. You have the audio recording of her final session with a city-educated guest. How do you write an article that explains *why* this moment matters — not just what happened? Start by re-reading the climactic scene (pages 84-86) where gjxksfcu finally leaves. Ask: "What changes in the power dynamic between the two characters across the three meetings?" Mark every shift in address terms (cM+h gosyh → cM+h cgqfj;k → ek¡), every silence, every physical gesture. Then trace how the author uses the *sound* of the story (the recurring song "gekjks laokn ys tkgq js laofn;k&;k&;k") as a structural thread. The key insight: the story is not *about* storytelling; it *enacts* the death of oral tradition through its own form — the narrative voice slowly abandons the village dialect for standard Hindi as gjxksfcu's perspective dominates.

## DIAGNOSTIC_QUESTION_1
What is the literal meaning of the term "laofn;k" as established in the opening paragraph of the story, and what social function does the narrator say it served in the village?

## DIAGNOSTIC_ANSWER_1
"laofn;k" literally means "one who tells/recites stories" (lans'kokgd). The narrator states that in every village, only the poor, the servants, and the beggars (fuBYyk] dkepksj vkSj isVw vkneh) performed this role — it was not a respected profession but a survival activity for the marginalized. A wrong answer (e.g., "respected elder" or "priest") reveals the student has not grasped the story's central irony: the keeper of cultural memory is socially invisible.

## DIAGNOSTIC_QUESTION_2
In your own words, explain why cM+h cgqfj;k refuses to tell gjxksfcu a story during his first visit, even though she is a professional storyteller.

## DIAGNOSTIC_ANSWER_2
She refuses because gjxksfcu approaches her as a collector/exploiter ("laokn igq¡pkus dk dke lHkh ugha dj ldrs") demanding a performance without relationship or reciprocity. She insists on the ritual: "laokn osQ izR;sd 'kCn dks ;kn j[kuk] ftl lqj vkSj Loj esa laokn lquk;k x;k gS] Bhd mlh <ax ls tkdj lqukuk lgt dke ugha." A wrong answer focusing only on her tiredness or age misses the ethical stance: she protects the story's integrity against extraction.

## DIAGNOSTIC_QUESTION_3
Apply the concept of "frame narrative" to "laofn;k": Identify the outer frame and the inner story, and explain how the inner story (the tale of the king and the beggar woman) mirrors the outer situation between gjxksfcu and cM+h cgqfj;k.

## DIAGNOSTIC_ANSWER_3
Outer frame: gjxksfcu visiting the village and meeting cM+h cgqfj;k (present tense). Inner story: the tale she tells of a king who demands a story from a beggar woman, who refuses unless he listens properly (past tense, oral style). Mirror: The king = gjxksfcu (powerful, entitled, wants the story as object); the beggar woman = cM+h cgqfj;k (marginalized, possesses the story as living practice). The inner story's resolution — the king learns to listen — foreshadows gjxksfcu's partial transformation. A wrong answer that merely summarizes both plots without mapping the structural parallel shows inability to analyze narrative architecture.

## DIAGNOSTIC_QUESTION_4
Analyze the significance of the repeated song "gekjks laokn ys tkgq js laofn;k&;k&;k" at three key moments: (a) when gjxksfcu first arrives, (b) when he leaves the first time, (c) at the story's end. How does its function change?

## DIAGNOSTIC_ANSWER_4
(a) Opening: sung by cM+h cgqfj;k as assertion of identity and territory — "this is my space, my art." (b) First departure: sung by gjxksfcu mockingly ("laofn;k!---laokn igq¡pkus dk dke lHkh ugha dj ldrs") — he appropriates her song to dismiss her. (c) End: the song returns as a haunting fragment ("gejks laokn ys tkgq js laofn;k&;k&;k!!") after gjxksfcu flees, now stripped of irony, becoming an elegy for the tradition he could not sustain. The shift from active voice to fragmented echo maps the transfer (and loss) of cultural authority. A wrong answer treating the song as mere "background music" misses its role as the story's structural and thematic spine.

## DIAGNOSTIC_QUESTION_5
Evaluate the claim: "gjxksfcu is the villain of the story." Defend your position using at least three specific textual moments.

## DIAGNOSTIC_ANSWER_5
The claim is reductive. gjxksfcu is an *ambivalent* figure: (1) Villainous: he exploits her hospitality, mocks her ritual, treats her as specimen ("xk¡o osQ yksxksa dh xyr /kj.kk"), and ultimately abandons her. (2) Human: he returns, brings gifts, listens to her life story, and is genuinely shaken ("gjxksfcu dk th Hkkjh gks x;k"). (3) Symbolic: he represents modernity's inevitable, often unconscious destruction of tradition — not malice but structural indifference. The text invites critique of the *system* (education, urbanization) more than the individual. A wrong answer that simply condemns or excuses him fails to engage the story's moral complexity.

## DIAGNOSTIC_QUESTION_6
Create a 4-line dialogue between cM+h cgqfj;k and her granddaughter (imagined, not in text) set ten years after the story ends, where the granddaughter asks why she stopped telling stories. Use the village dialect markers from the text (e.g., "dkcqyh&dk;nk", "pqi", "tyku").

## DIAGNOSTIC_ANSWER_6
Sample criteria for a strong answer:
- Granddaughter: "dadi, rqe D;ksa ugha sunxh laokn? xk¡o ds cPps lqus yxrs FksA"
- cM+h cgqfj;k: "ckbZ] laokn u gksrk tyku ls] gksrk gS lksp lsA og xkM+h ugha vkrh] ftlus eu ls lqukA"
- Granddaughter: "ysfdu rqe rks dgrh Fkh — 'laofn;k MVdj [kkrk gS'..."
- cM+h cgqfj;k: "Hkh] ysfdu vc xk¡o ds eu [kwc ugha] cPpksa ds ikl fdlh ds fy, ugha gS /;kuA"
A poor answer uses standard Hindi, ignores the dialect, or makes the grandmother bitter rather than resigned — missing the text's tone of quiet extinction.

## COMMON_MISCONCEPTION
Students often treat "critical analysis" as "finding hidden symbols" — e.g., claiming the "xkM+h" (cot) *represents* the caste system because it's elevated. The text never supports this. The cot is a literal cot; its significance is *functional* (gjxksfcu sits above, cM+h cgqfj;k below) not allegorical. This error comes from confusing *literary analysis* (how the text works) with *free association* (what objects remind me of). The remedy: every claim must answer "How does the text *show* this?" with a specific sentence or pattern.

## ON_FAILURE
If the student cannot distinguish analysis from speculation: (1) Have them list 5 physical details about the cot from the text (height, material, who sits where, when it changes). (2) Ask: "Which of these details does the author *choose* to include, and what does that choice *do* to the reader's understanding of power?" (3) Practice with a simpler text: a photograph of a classroom — list 5 visible details, then infer the power dynamic. (4) Re-attempt Diagnostic Question 4 with the song, using only words the author wrote.

## BUILDS_ON
This node builds on the ability to identify literary devices (nodes 008, 009) and trace themes (nodes 006, 007) by requiring synthesis: how do devices *create* theme?

## LEADS_TO
This node enables Writing Skills (node 014) where students must produce structured critical essays, and Speaking/Listening (node 015) where they defend interpretations in discussion.

## PREREQUISITE_NODE_IDS
c12_hin_a_cbse_12_012, c12_hin_a_cbse_12_006, c12_hin_a_cbse_12_008, c12_hin_a_cbse_12_009, c11_hin_ar_cbse_01_013, c12_hin_a_cbse_12_001, c12_hin_a_cbse_12_002, c12_hin_a_cbse_12_003, c12_hin_a_cbse_12_004, c12_hin_a_cbse_12_005, c12_hin_a_cbse_12_007, c12_hin_a_cbse_12_010, c12_hin_a_cbse_12_011

## PREREQUISITE_REASONS
c12_hin_a_cbse_12_012: Comprehension provides the factual base (plot, character actions) without which analysis has no evidence.
c12_hin_a_cbse_12_006: Theme identification gives the "what" — critical thinking asks "how" and "why" the theme is constructed.
c12_hin_a_cbse_12_008: Imagery and metaphor are the primary tools the author uses to encode meaning; analysis requires decoding them.
c12_hin_a_cbse_12_009: Irony and symbolism are central to this story's critique of modernity; recognizing them is prerequisite to interpreting them.
c11_hin_ar_cbse_01_013: Class 11 Critical Thinking established the basic framework (claim-evidence-reasoning) which this node deepens for a more complex text.
c12_hin_a_cbse_12_001: Critical thinking requires the contextual foundation laid here.  
c12_hin_a_cbse_12_002: Critical thinking requires analyzing how narrative structure shapes meaning.  
c12_hin_a_cbse_12_003: Critical thinking node requires synthesized setting-atmosphere-character-theme analysis  
c12_hin_a_cbse_12_004: Critical thinking requires synthesizing character, theme, and device; protagonist analysis is a core input.  
c12_hin_a_cbse_12_005: Supporting character analysis examines how secondary characters in a narrative — through t... की समझ आवश्यक है, क्योंकि यह नोड (Critical Thinking:) इसी आधार पर आगे बढ़ता है।  
c12_hin_a_cbse_12_007: Critical Thinking node requires synthesizing primary and secondary themes into an interpretive argument.  
c12_hin_a_cbse_12_010: Critical interpretation of 'laofn;k' as ironic symbol depends on vocabulary depth.  
c12_hin_a_cbse_12_011: Language usage patterns become primary data for thematic interpretation  

## FORWARD_NODE_IDS
c12_hin_a_cbse_12_014, c12_hin_a_cbse_12_015
## FORWARD_REASONS
c12_hin_a_cbse_12_014: Writing Skills requires the student to articulate the analytical moves practiced here (claim, evidence, explanation, link) in formal essay form.
c12_hin_a_cbse_12_015: Speaking and Listening requires the student to orally defend and refine interpretations in real-time dialogue, using the same evidence base.

## CROSS_SUBJECT_PREREQS
c11_hin_ar_cbse_01_013, c11_hin_ar_cbse_02_013
## CROSS_SUBJECT_REASONS
c11_hin_ar_cbse_01_013: The Class 11 critical thinking node (Chapter 1) introduced the concept of "reading against the grain" — questioning the narrator's authority — which is essential for analyzing gjxksfcu's unreliable perspective.
c11_hin_ar_cbse_02_013: The Class 11 critical thinking node (Chapter 2) practiced comparing two texts on the same theme; here the student compares the inner story (king/beggar) with the outer frame.

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_01_013 -> c12_hin_a_cbse_12_013 -> c12_hin_a_cbse_12_014

## THIS_FORMULA
Critical Interpretation = (Textual Evidence × Narrative Technique) → Thematic Claim + Alternative Reading Acknowledgement

## FORMULA_VARIABLES
N/A - conceptual

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
analytical

## CROSS_SUBJECT
N/A | The story documents the decline of oral tradition in post-colonial India — a key topic in modern Indian social history (NCERT History Class 12, Themes in Indian History Part III, Chapter on "Colonialism and the Countryside" / "Rebels and the Raj").
 N/A | The conflict between gjxksfcu (urban, educated, bureaucratic) and cM+h cgqfj;k (rural, oral, marginalized) exemplifies the "Sanskritization vs. Westernization" and "Dominant Caste vs. Subaltern" dynamics in NCERT Sociology Class 12 (Social Change and Development in India, Chapter 2 & 3).
 N/A | cM+h cgqfj;k's failing memory ("cFkqvk lkx [kkdj dc rd thm¡Q") and the granddaughter's forgotten stories illustrate the psychology of autobiographical memory loss and intergenerational transmission failure (NCERT Psychology Class 12, Chapter 7: Memory).
## PREREQ_CONCEPT
The student must understand the difference between *literal comprehension* (what happens) and *interpretive analysis* (why the author chose to present it this way).

## PREREQ_BEFORE
The student must have completed a full reading of "laofn;k" and be able to recount the three meetings between gjxksfcu and cM+h cgqfj;k in sequence.

## PREREQ_STUCK
If stuck, re-read the "iz'u&vH;kl" (exercise questions) at the end of the NCERT chapter — Questions 6, 7, 8, and 10 are explicitly analytical — and write one-paragraph answers for each using the PEEL structure (Point, Evidence, Explanation, Link).

## WORKED_EXAMPLE_1
PROBLEM: Analyze how the author uses the motif of "hands" (hkkbZ) to track the shifting power dynamic between gjxksfcu and cM+h cgqfj;k across the story. Provide three distinct textual instances with interpretation.

STEPS:
- Step 1: Scan the text for all references to hands (hkkbZ, hkkb;ksa, hkkbZlkgsc, etc.) and note the context, character, and action.
- Step 2: Select three instances that show a clear progression: (a) First meeting: gjxksfcu's hands hold the pen/notebook (recording, extracting). (b) Middle: cM+h cgqfj;k's hands tremble while holding the chillum/food (embodied labor, aging). (c) Final meeting: gjxksfcu folds his hands in a gesture of respect/leave-taking (ritual closure, but empty).
- Step 3: For each instance, identify the narrative technique: synecdoche (part for whole), tactile imagery, gestural symbolism.
- Step 4: Interpret the progression: Hands move from tools of power (pen) to markers of vulnerability (tremor) to performative gestures (folded hands) — mirroring how modernity extracts, exhausts, then ritualistically honors tradition without sustaining it.
- Step 5: Connect to the central theme: The body of the storyteller is the site where cultural memory lives and dies; the city visitor's hands never learn to *hold* the story, only to *take* or *fold*.

REASONING: This worked example models the core analytical move: tracking a concrete motif across the narrative arc to reveal abstract thematic development. It forces the student to ground interpretation in specific textual coordinates (page/line) and name the device (synecdoche, imagery).

ANSWER:
Instance 1 (pp. 78-79): "gjxksfcu us fiQj yach lk¡l yhA" — his hands hold the pen/notebook, positioning him as recorder/owner of the story. The hand is an instrument of appropriation.
Instance 2 (p. 82): "cM+h cgqfj;k osQ cM+s HkkbZ us gjxksfcu dks ugha igpkuk" — her large, labor-worn hands reject his offered money; the hand becomes a site of dignity and refusal.
Instance 3 (p. 86): "gjxksfcu us HkkbZ tksM+dj cksfj;ksa esa can djosQ pys tk,¡xsA" — his folded hands perform a traditional farewell, but the narrative voice notes "mlus cM+h cgqfj;k dk laokn lqukus osQ fy, cw<+h ekrk osQ ikl tk cSBkA" — he still doesn't listen. The gesture is hollow.
Synthesis: The hand motif traces the arc from extraction to exhaustion to empty ritual — the tragedy of a tradition that is archived but not inherited.

## WORKED_EXAMPLE_2
PROBLEM: The story ends with gjxksfcu fleeing the village as the song "gekjks laokn ys tkgq js laofn;k&;k&;k" echoes. Evaluate whether this ending offers *closure* or *rupture*. Support with two structural and two linguistic arguments.

STEPS:
- Step 1: Define "closure" (resolution, circularity, answered questions) vs. "rupture" (open ending, fragmentation, silence) in narrative theory.
- Step 2: Structural argument for closure: The story returns to the opening song (circular structure); gjxksfcu departs (physical exit); the frame narrative closes.
- Step 3: Structural argument for rupture: The inner story (king/beggar) remains unresolved — we never learn if the king truly learned; cM+h cgqfj;k is left alone, her future uncertain; the song fragments ("&;k&;k") rather than resolves.
- Step 4: Linguistic argument for closure: The final paragraph uses past perfect ("pyk x;k", "igq¡pkA") — completed action; standard Hindi dominates, signaling return to "normal" narrative order.
- Step 5: Linguistic argument for rupture: The song's dialect ("gekjks", "tkgq") intrudes into the standard Hindi narration; the onomatopoeic "!!" and repetition "&;k&;k" break syntactic grammar — the oral tradition *disrupts* the written text even at the end.
- Step 6: Synthesize: The ending is a *rupture disguised as closure* — the form mimics departure, but the sound refuses to leave. This enacts the story's thesis: oral tradition cannot be neatly archived; it haunts.

REASONING: This example teaches students to use structural and linguistic evidence simultaneously, and to resist binary conclusions (closure/rupture) in favor of a nuanced "both/and" reading — a hallmark of advanced literary analysis.

ANSWER:
The ending is a **rupture disguised as closure**.
Structural closure: Circular return of the song; gjxksfcu's physical departure completes the frame.
Structural rupture: The inner story's moral (the king learns to listen) is *not* fulfilled — gjxksfcu listens partially but flees; cM+h cgqfj;k's lineage ends with her.
Linguistic closure: Standard Hindi narration resumes ("gjxksfcu pyk x;k"), past tense seals the event.
Linguistic rupture: The song's Braj-inflected dialect ("gekjks", "tkgq") and non-grammatical repetition ("&;k&;k!!") invade the standard prose — the oral refuses to be silenced by the written.
Conclusion: The text performs its own argument — tradition does not "end" neatly; it persists as disruptive sound in the modern narrative.

## WORKED_EXAMPLE_3
PROBLEM: Compare the representation of "laofn;k" (storytelling) in this story with Premchand's "Budhi Kaki" (Class 10/11) where an old woman's voice is silenced by family. Write a comparative thesis statement and support with two points of contrast and one point of convergence.

STEPS:
- Step 1: Recall "Budhi Kaki": The old woman (Budhi Kaki) is denied food, voice, dignity by her own family; her "story" is her hunger, expressed only through groans. The narrative sympathizes but keeps her passive.
- Step 2: Recall "laofn;k": cM+h cgqfj;k *controls* the storytelling ritual; she sets conditions, refuses the powerful visitor, tells a story *within* the story. She has narrative agency.
- Step 3: Formulate thesis: "While both texts center an elderly marginalized woman, Premchand portrays the silencing of the subaltern by patriarchal family structures, whereas Jasrak portrays the *resistance* of the subaltern storyteller against modern extractive epistemology — yet both end with the woman's voice unheard by the dominant order."
- Step 4: Contrast 1 (Agency): Budhi Kaki's body is the site of neglect (she cannot speak); cM+h cgqfj;k's voice is the site of power (she dictates terms of telling).
- Step 5: Contrast 2 (Audience): Budhi Kaki's audience is indifferent family; cM+h cgqfj;k's audience is an outsider-intellectual — the threat is not neglect but *appropriation*.
- Step 6: Convergence: Both texts use the *grandchild/child* figure as the only potential inheritor (Budhi Kaki's great-grandson; cM+h cgqfj;k's imagined granddaughter in Diagnostic Q6) — and both show the transmission failing.
- Step 7: Refine thesis to include the formal difference: Premchand uses third-person realism; Jasrak uses a self-reflexive frame narrative that *thematizes* the act of storytelling itself.

REASONING: This example integrates prior curricular knowledge (Premchand) with the current text, demanding intertextual analysis — a key competitive exam skill (CUET, JEE Advanced Humanities). It also models thesis-driven comparative writing.

ANSWER:
Thesis: "Premchand's 'Budhi Kaki' and Jasrak's 'laofn;k' both stage the crisis of the elderly subaltern woman's voice in modern India, but where Premchand depicts *familial silencing* through realist empathy, Jasrak depicts *epistemic extraction* through metafictional irony — yet both conclude with the terrifying fragility of intergenerational transmission."
Contrast 1: Agency — Budhi Kaki is acted upon (starved, ignored); cM+h cgqfj;k acts (sets conditions, tells inner story, refuses money).
Contrast 2: Threat — Familial patriarchy vs. Urban intellectual modernity.
Convergence: The broken chain — in both, the child who *should* inherit the memory (great-grandson / imagined granddaughter) is absent or unprepared. The stories end not with death but with *discontinuity*.

## COMPETENCY_QUESTION_1
QUESTION: The story "laofn;k" is often taught as a critique of modernity. However, the narrator (who is also the author's persona) is himself a modern, educated writer using print technology to preserve this story. Analyze this irony: How does the text *simultaneously* critique and participate in the displacement of oral tradition? Use the concepts of "frame narrative" and "narrative voice" in your answer.

COMPETENCY: Critical analysis of textual self-reflexivity and authorial positionality

STEPS:
- Step 1: Identify the two narrative voices: (a) The frame narrator (standard Hindi, print-oriented, analytic) — this is the author/Jasrak. (b) The inner story voice (dialect, oral, performative) — this is cM+h cgqfj;k.
- Step 2: Show how the frame narrator *documents* the oral tradition's death using the very tools (writing, standard language, fixed text) that kill it. Quote: "laofn;k MVdj [kkrk gS vkSj viQj dj lksrk gS" — the frame narrator defines oral tradition in print terms (eating, digesting).
- Step 3: Show how the frame narrator *depends* on the oral tradition for his material — without cM+h cgqfj;k, there is no story for him to write.
- Step 4: Conclude: The text is a "monument" — it preserves by petrifying. The irony is unresolved; the author knows it (hence the fragmented song at the end). This self-awareness *is* the critical depth.

ANSWER:
The story enacts a **performative contradiction**: it mourns the loss of oral tradition using the instruments of its displacement (print, standard Hindi, fixed narrative). The frame narrator (Jasrak) occupies the same structural position as gjxksfcu — both are educated outsiders recording the storyteller. But the text *exposes* this through form: the inner story (cM+h cgqfj;k's tale) is rendered in her dialect, her rhythm, her logic — it resists full translation. The final fragmentation of the song ("&;k&;k!!") into the standard Hindi narration is the text admitting: "I cannot fully capture this; I can only let its ghost haunt my sentences." The critique of modernity is therefore not external but *immanent* — the text wounds itself to show the wound.

DIFFICULTY: hard

## COMPETENCY_QUESTION_2
QUESTION: Design a 5-minute classroom activity for Class 10 students to experience the difference between "hearing a story" and "reading a story" using a 2-minute folk tale. The activity must include: (a) an oral telling by the teacher, (b) a silent reading of the same tale, (c) a structured comparison worksheet with three specific analytical prompts derived from "laofn;k".

COMPETENCY: Pedagogical translation of literary analysis into teaching practice (application + creation)

STEPS:
- Step 1: Select a 2-minute folk tale with repetition, dialect, and a ritual opening/closing (e.g., a Panchatantra tale in local dialect).
- Step 2: Oral telling: Teacher tells it *without text*, using voice modulation, gesture, address to students ("suno beta"), and the ritual formula ("ek tha raja..."). Students listen with eyes closed.
- Step 3: Silent reading: Distribute printed version in standard Hindi. Students read silently for 2 minutes.
- Step 4: Comparison worksheet (derived from "laofn;k"):
   Prompt 1 (Ritual): "In the oral version, what words/actions marked the *beginning* and *end* of the story? Were they in the written version? Why does cM+h cgqfj;k insist on 'laokn osQ izR;sd 'kCn dks ;kn j[kuk'?"
   Prompt 2 (Body): "Where did you *feel* the story in your body during oral telling (heartbeat, breath, posture)? Where during reading? Connect to 'cM+h cgqfj;k osQ hkkbZ' as the site of the story."
   Prompt 3 (Audience): "In oral telling, how did your neighbor's reaction (laugh, gasp) change your experience? In reading, were you alone? What does gjxksfcu's solitary reading miss?"
- Step 5: Whole-class discussion: "Can a printed story ever be a 'laofn;k'? What does the text say?"

ANSWER:
Activity Plan:
1. Tale: "The Lion and the Mouse" in Braj/Awadhi (2 mins).
2. Oral: Teacher performs with "suno re bhaiya", rhythmic repetition, eye contact.
3. Print: Standard Hindi text, no performance cues.
4. Worksheet:
   - Ritual: Oral had "Ram Ram" opening/closing; print had N/A. cM+h cgqfj;k knows the story *lives* in the ritual frame.
   - Body: Oral — leaned forward, held breath at climax; Reading — eyes scanned, body still. The story "eats" the teller's body (cM+h cgqfj;k's hands, voice).
   - Audience: Oral — collective gasp created shared emotion; Reading — isolated. gjxksfcu reads alone; he never becomes part of the story.
5. Discussion: Print *archives*; oral *communes*. The text "laofn;k" is a print archive *haunted* by the oral it cannot keep.

DIFFICULTY: medium