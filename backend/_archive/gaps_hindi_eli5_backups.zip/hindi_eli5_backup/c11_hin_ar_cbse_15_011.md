## DEFINITION
Grammar: Language Usage in the Text refers to the systematic analysis of syntactic structures, morphological patterns, and rhetorical devices employed in the poem "lcls [krjukd" to convey meaning, emotion, and thematic depth. It involves identifying how the poet manipulates standard Hindi grammar—through negation repetition, case marking, compound formation, and elliptical constructions—to create a distinct poetic voice that bridges colloquial speech and literary expression.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student must be able to: (1) Identify and explain at least three distinct grammatical deviations from standard prose Hindi used in the poem and their thematic function; (2) Analyze how the repetition of the negative construction "lcls [krjukd ugha gksrh" structures the poem's argument; (3) Write a board-exam style answer explaining the grammatical significance of a given line using terminology like *karak*, *samasa*, *upasarga-pratyaya*, and *vakya-samrachana*.

## SCOPE_BOUNDARY
This node covers grammatical analysis of the prescribed poem "lcls [krjukd" only: negation patterns, case usage (karak), compound words (samasa), verb forms, and poetic ellipsis. It does NOT cover general Hindi grammar rules unrelated to the text, sandhi rules, or grammar of other chapters. It focuses on how grammar serves poetic meaning in this specific text.

## WALKTHROUGH
Imagine you're reading a WhatsApp forward that says "Sabse chhota woh nahi, yeh nahi, wo bhi nahi... sabse chhota wo hai jo..." — you instinctively feel the rhythm of negation building tension. That's exactly what Ik does grammatically in this poem. Start by reading the poem aloud, noticing how your voice drops on "ugha gksrh" (is not) and rises on "gksrk gS" (is). First, underline every occurrence of "lcls [krjukd ugha gksrh" — count them. Then, circle the case markers (ko, se, par, ki, ka) in the lines that follow each negation. Ask: why does the poet use "esgur dh ywV" (love's shadow) with *dh* (genitive) but "xíkjh&yksHk dh eq_h" (sword-edge's sharpness) with the same marker? The key insight: grammar here isn't just rules — it's the architecture of the poet's argument that the "smallest" thing is actually the most expansive human experience.

## DIAGNOSTIC_QUESTION_1
Identify the grammatical term for the repeated structure "lcls [krjukd ugha gksrh" in the poem and state its syntactic function in a standard Hindi sentence.

## DIAGNOSTIC_ANSWER_1
The structure is a *pratishedh vakya* (negative sentence) with *lcls* (superlative adjective) + *[krjukd* (noun, predicate nominative) + *ugha* (negative particle) + *gksrh* (habitual present verb, feminine singular agreeing with implied subject). In standard Hindi, this asserts that the subject does not possess the quality of being the smallest. A wrong answer (e.g., calling it a command or question) reveals the student cannot distinguish sentence types by verb morphology and negation placement — a Class 9-level gap that blocks poetic analysis.

## DIAGNOSTIC_QUESTION_2
Explain why the poet uses the genitive case marker *dh* (ka/ki/ke) in phrases like "esgur dh ywV", "iqfyl dh ekj", and "xíkjh&yksHk dh eq_h" instead of the instrumental *se* or locative *me*. What thematic relationship does this case choice establish?

## DIAGNOSTIC_ANSWER_2
The genitive *dh* marks possession/association, making "love's shadow," "affection's mother," and "sword-edge's sharpness" intrinsic attributes — not instruments or locations. This grammatical choice reinforces the poem's central paradox: these vast emotions/phenomena are *owned* by the "smallest" thing, not the other way around. A student answering "it's just poetic license" misses that case markers encode semantic relationships; confusing genitive with instrumental reveals inability to map *karak* to meaning — critical for board questions on "bhavarth" (implicit meaning).

## DIAGNOSTIC_QUESTION_3
In the line "cSBs&fcBk, idM+s tkukµcqjk rks gS", identify the *samasa* (compound) type in "cSBs&fcBk," and "idM+s", then rewrite the line in standard prose word order (anvaya) showing all implied case markers.

## DIAGNOSTIC_ANSWER_3
"cSBs&fcBk," = *dvandva samasa* (copulative compound: cSBs + fcBk, = vuk;kl + vdkj.k). "idM+s" = *karmadharaya samasa* (appositional: idM+ = cspSuh, feminine singular). Anvaya: "cSBs vuk;kl vdkj.k cspSuh idM+s tkuk cqjk rks gS" (To walk in disorder and crookedness is indeed difficult). Implied markers: *me* (locative) after cSBs&fcBk,, *ko* (dative) after idM+s. A wrong answer splitting the compound incorrectly (e.g., treating "idM+s" as bahuvrihi) shows weak *samasa* analysis — a recurring board exam stumbling block.

## DIAGNOSTIC_QUESTION_4
Compare the verb forms in the negative section ("ugha gksrh" — habitual present) and affirmative section ("gksrk gS" — habitual present + auxiliary). How does this grammatical parallelism with a single polarity shift structure the poem's dialectical movement?

## DIAGNOSTIC_ANSWER_4
Both sections use habitual present (*gksrh/gksrk*) indicating timeless truth, but the negative section uses *ugha* (negation) while the affirmative uses *gksrk gS* (assertion with emphatic auxiliary *gS*). This creates a *virodhabhas* (apparent contradiction) resolved grammatically: the same verb form first denies conventional "smallness" then affirms the poet's redefinition. The auxiliary *gS* in the affirmative adds *niścayatā* (certainty) absent in the open-ended negation. Missing the auxiliary's emphatic force leads to treating both sections as merely opposite statements, not a structured argument — a key distinction for "shailli" (style) questions.

## DIAGNOSTIC_QUESTION_5
Evaluate the effectiveness of the elliptical construction in "lcls [krjukd og ?kM+h gksrh gS / vkidh dykbZ ij pyrh gqbZ Hkh tks / vkidh fuxkg esa #dh gksrh gS" where the relative clause "tks..." lacks an explicit main verb until the final "gksrh gS". Does this delay strengthen or weaken the poetic impact? Justify.

## DIAGNOSTIC_ANSWER_5
The delay strengthens impact by enacting the "burden" (*?kM+h*) grammatically: the reader carries the suspended relative clause ("tks vkidh dykbZ ij pyrh gqbZ Hkh tks vkidh fuxkg esa #dh gksrh gS") across three lines before the verb "gksrh gS" releases it — mimicking the psychological weight of unspoken grief. A student calling it "confusing syntax" misses that poetic ellipsis (*lopa*) is a deliberate *alamkara* (figure of speech) where grammatical incompleteness mirrors thematic incompleteness. This confusion between error and device is fatal for "kavya-saundarya" (poetic beauty) questions.

## DIAGNOSTIC_QUESTION_6
Create a four-line Hindi poem stanza using the same grammatical template: three lines of "sabse [adjective] [noun] nahin hai" with genitive phrases, followed by a fourth line "sabse [adjective] hai woh jo..." with a suspended relative clause. Use a different abstract concept (not "smallest").

## DIAGNOSTIC_ANSWER_6
Example: "sabse bada dhokha nahin hai / dhan ki chah nahin hai / shakti ki bhookh nahin hai / sabse bada hai woh jo / apne hi saaye se darta hai." Criteria: (1) Correct *pratishedh* structure with *nahin hai*; (2) Genitive *ki* in all three negations; (3) Affirmative with *hai woh jo* + relative clause spanning lines; (4) Thematic coherence. A weak answer using "sabse bada... nahin" but failing to suspend the relative clause (e.g., ending line 4 with "hai") shows inability to replicate the poem's syntactic rhythm — the core skill for "rachanaatmak lekhan" (creative writing) tasks.

## COMMON_MISCONCEPTION
Students treat the poem's grammar as "incorrect" or "broken" Hindi because it omits explicit subjects (e.g., "lcls [krjukd ugha gksrh" has no stated subject), uses inverted word order ("idM+s tkuk cqjk rks gS" instead of "idM+s tkuk cqjk rks gS" — same here but often misread), and stacks relative clauses. They think "poetic license" means *ignoring* grammar, not *exploiting* it. For example, they mark "vkidh dykbZ ij pyrh gqbZ Hkh tks" as a sentence fragment and lose marks for not recognizing it as a *visheshya-visheshana* (head-modifier) structure where "tks" anticipates "og ?kM+h". This misconception stems from Class 10 prose-focused grammar where ellipsis is rare; they haven't learned that poetry *systematically* violates prose norms for effect.

## ON_FAILURE
1. Give the student two versions of a simple sentence: prose "Ye chhota hai" vs. poetic "Chhota ye hai, bada nahin." Ask: "Which sounds like a poem? Why?" 2. Have them physically cut up the poem's lines into clauses (negation, genitive phrase, relative clause) and reassemble in standard prose order (anvaya). 3. Use color-coding: red for *pratishedh* (negation), blue for *karak* markers, green for *kriya* (verb). 4. Finally, ask them to write one "grammatically wrong but poetically right" sentence about their own life — this bridges intuition to analysis.

## BUILDS_ON
Vocabulary in Context (c11_hin_ar_cbse_15_010) — understanding key terms like *esgur*, *xíkjh*, *ejfl;k* is prerequisite for analyzing their grammatical behavior.

## LEADS_TO
Comprehension: Literal and Inferential Questions (c11_hin_ar_cbse_15_012) — grammatical analysis provides the evidence for inferential answers about tone and theme.

## PREREQUISITE_NODE_IDS
c11_hin_ar_cbse_15_001, c11_hin_ar_cbse_15_002, c11_hin_ar_cbse_15_010
## PREREQUISITE_REASONS
c11_hin_ar_cbse_15_001: Context (poet's Marxist leanings, 1988 Sikh riots backdrop) explains why grammar becomes political — e.g., passive constructions hiding agency.
c11_hin_ar_cbse_15_002: Narrative structure (negation → affirmation) mirrors the grammatical movement from *pratishedh* to *vidhi* mood.
c11_hin_ar_cbse_15_010: Vocabulary node gives meanings of *esgur*, *xíkjh*, *ejfl;k* etc. — without these, case analysis of "esgur dh ywV" is impossible.

## FORWARD_NODE_IDS
c11_hin_ar_cbse_15_012, c11_hin_ar_cbse_15_013, c11_hin_ar_cbse_15_014, c11_hin_ar_cbse_15_015, c12_hin_a_cbse_04_011, c12_hin_a_cbse_09_011, c12_hin_a_cbse_11_011, c12_hin_a_cbse_12_011, c12_hin_a_cbse_15_011, c12_hin_a_cbse_17_011, c12_hin_ar_cbse_01_011, c12_hin_ar_cbse_02_011, c12_hin_ar_cbse_07_011, c12_hin_ar_cbse_09_011, c12_hin_ar_cbse_10_011, c12_hin_ar_cbse_11_011, c12_hin_ar_cbse_15_011

## FORWARD_REASONS
c11_hin_ar_cbse_15_012: Comprehension questions require citing grammatical evidence (e.g., "How does the poet use negation to build tension?").
c11_hin_ar_cbse_15_013: Critical thinking needs grammatical precision to argue interpretations (e.g., "Does the genitive case imply ownership or inevitability?").
c11_hin_ar_cbse_15_014: Writing skills (analytical paragraph) demand the PEEL structure where Evidence = grammatical quotation + analysis.
c11_hin_ar_cbse_15_015: Grammar and language usage support fluent expression.  
c12_hin_a_cbse_04_011: अगला तार्किक चरण: This node analyzes the grammatical structures, syntactic patterns, and language usage specific to th... इस नोड की अवधारणाओं को सीधे उपयोग/विस्तारित करता है।  
c12_hin_a_cbse_09_011: *Visheshan* identification — Braj adjectives like *vkou* are invariant, unlike Khari Boli.  
c12_hin_a_cbse_11_011: Introduces CUET-style language analysis questions — prepares for competitive exam patterns.  
c12_hin_a_cbse_12_011: Tense/aspect/mood system of modern standard Hindi vs dialects  
c12_hin_a_cbse_15_011: Provides foundational grammar concepts (vector verbs, ergativity, honorifics) in standard Hindi that are prerequisites for analyzing their dialectal variants in this chapter.  
c12_hin_a_cbse_17_011: Reviewed all Class 11 grammar-in-literature skills — consolidation.  
c12_hin_ar_cbse_01_011: Reinforces habitual vs. perfective aspect distinction in poetry.  
c12_hin_ar_cbse_02_011: Comparative analysis across poets.  
c12_hin_ar_cbse_07_011: Poetic license vs. grammatical system.  
c12_hin_ar_cbse_09_011: Consolidates all Class 11 grammar-for-poetry skills.  
c12_hin_ar_cbse_10_011: Intertextual language references (Chapter 15).  
c12_hin_ar_cbse_11_011: Reinforces oral performance of grammatical features  
c12_hin_ar_cbse_15_011: Class 11 grammar node for same chapter builds foundational skills in identifying voice, nominalization, rhetorical structures.  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
none

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_15_010 -> c11_hin_ar_cbse_15_011 -> c11_hin_ar_cbse_15_012

## THIS_FORMULA
Poetic Grammar Analysis Protocol: (1) Identify deviation from standard prose syntax; (2) Name the grammatical form (karak, samasa, vakya-prakar, kriya-rupa); (3) Explain semantic function in context; (4) Link to thematic development.

## FORMULA_VARIABLES
N/A

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
linguistic

## CROSS_SUBJECT
c11_history_indian_national_movement | The poem's 1988 context (post-Operation Blue Star, anti-Sikh riots) connects to history syllabus on "Challenges to Democracy" — grammatical suppression of agency mirrors state suppression of minority voices.
c11_political_science_democracy | The shift from negative definitions (what the smallest is NOT) to affirmative redefinition mirrors democratic discourse: defining citizenship by exclusion vs. inclusion — a grammatical enactment of political philosophy.

## PREREQ_CONCEPT
Ability to identify *karak* (case) markers and *samasa* (compound) types in unseen Hindi sentences — typically mastered in Class 9-10 but applied here to poetic distortion.

## PREREQ_BEFORE
Student must comfortably parse a standard Hindi sentence into subject-object-verb with case markers (e.g., "Ram ne kitab padhi" -> Ram=karta, ne=kartari, kitab=karma, padhi=kriya).

## PREREQ_STUCK
Review Class 9 Hindi Grammar Chapter "Vakya Vichar" and "Samasa" — specifically *karmadharaya*, *dvandva*, and *bahuvrihi* compounds with practice exercises from NCERT workbook.

## WORKED_EXAMPLE_1
PROBLEM: Analyze the grammatical structure and thematic function of the line: "lcls [krjukd og pk¡n gksrk gS / tks gj gR;kdkaM osQ ckn / ohjku gq, vk¡xuksa esa p<+rk gS / ij vkidh vk¡[kksa dks fepks± dh rjg ugha xM+rk gS"
STEPS:
- Step 1: Segment the line into clauses: Main clause "lcls [krjukd og pk¡n gksrk gS" (The smallest is that wound) + Relative clause "tks gj gR;kdkaM osQ ckn / ohjku gq, vk¡xuksa esa p<+rk gS / ij vkidh vk¡[kksa dks fepks± dh rjg ugha xM+rk gS" (which...).
- Step 2: Identify grammatical forms: "pk¡n" = noun, masculine singular (predicate nominative after "og"); "gksrk gS" = habitual present + emphatic auxiliary (assertive mood); "tks" = relative pronoun (correlative to "og"); "gj" = adverb (past/behind); "gR;kdkaM" = noun, oblique singular (after postposition "osQ"); "ckn" = postposition (locative/temporal); "ohjku" = adjective (wounded, agreeing with vk¡xuksa); "vk¡xuksa" = noun, oblique plural (after "esa"); "p<+rk" = present participle (progressive aspect); "ij" = postposition (locative); "vkidh" = genitive pronoun; "vk¡[kksa" = noun, direct plural (object of "xM+rk"); "fepks± dh rjg" = simile marker (like thorns); "ugha xM+rk" = negative habitual present.
- Step 3: Analyze deviations: (a) Ellipsis of subject in main clause ("og" is demonstrative pronoun standing for "lcls [krjukd"); (b) Stacked postpositional phrases ("gj gR;kdkaM osQ ckn / ohjku gq, vk¡xuksa esa") creating spatial layering; (c) Simile "fepks± dh rjg" modifying the verb "xM+rk" (prick) not the noun "vk¡[kksa" (eyes) — a *kriya-visheshana* usage.
- Step 4: Thematic function: The wound (*pk¡n*) is defined by its location (behind war, in wounded breaths) and its action (pricking eyes unlike thorns). Grammatically, the present participle "p<+rk" (festering) makes the wound *ongoing* — not a past event. The negative "ugha xM+rk" denies the naturalness of thorns, asserting the wound's *unnatural* persistence.
- Step 5: Connect to central idea: This grammatical portrait of a wound that "festers in wounded breaths" and "pricks eyes unlike thorns" redefines "smallest" as the *most enduring, invasive trauma* — the grammatical continuity (participle + habitual present) mirrors historical continuity of injustice.
REASONING: The protocol moves from form to function to theme — exactly what board examiners expect in "bhavarth avam shailli" questions. Each grammatical term (participle, postposition, aspect) is a tool to unpack *how* the poet makes the abstract concrete.
ANSWER: The line uses a demonstrative-relativizer correlative ("og... tks") with stacked locative postpositions and a present participle to spatialize trauma, while the habitual present + negative ("ugha xM+rk") asserts the wound's unnatural, persistent violence — grammatically enacting the poem's thesis that the "smallest" trauma is the most expansive.

## WORKED_EXAMPLE_2
PROBLEM: The poem repeats "lcls [krjukd ugha gksrh" six times with different subjects. Explain how the grammatical agreement (gender/number) of "gksrh" changes across repetitions and what this reveals about the poet's conception of "smallness".
STEPS:
- Step 1: List all six occurrences with their subjects: (1) esgur dh ywV (feminine singular) -> gksrh; (2) iqfyl dh ekj (feminine singular) -> gksrh; (3) xíkjh&yksHk dh eq_h (feminine singular) -> gksrh; (4) cSBs&fcBk, (masculine plural? but treated as singular concept) -> gksrh; (5) idM+s (feminine singular) -> gksrh; (6) eqf_;k¡ Hkhapdj cl oDr fudky ysuk (masculine singular infinitive phrase) -> gksrh.
- Step 2: Note "gksrh" is feminine singular in ALL cases — even where subject is masculine (cSBs&fcBk,) or an infinitive phrase (default masculine). This violates standard agreement rules where verb matches subject gender.
- Step 3: Identify the grammatical principle: In *pratishedh vakya* with *lcls [krjukd* as predicate adjective, the verb agrees with the *predicate* ([krjukd, feminine) not the subject. This is standard for "A is not B" where B is adjective.
- Step 4: Thematic inference: By forcing all diverse subjects (love's shadow, affection's mother, sword's sharpness, disorder, difficulty, cowardly act) to conform to a single feminine grammatical form, the poet grammatically *unifies* them under one category: "things falsely called smallest." The invariant "gksrh" becomes a refrain — a grammatical *dhruva* (fixed point) against which the final affirmative "gksrk gS" (masculine, matching "pk¡n/?kM+h/pk¡n/xhr") breaks the pattern.
- Step 5: Board exam application: A 3-mark question "Explain the significance of the repeated verb form" requires: (a) Identification of invariant feminine agreement; (b) Explanation of predicate agreement rule; (c) Interpretation as structural unification device.
REASONING: This example demonstrates how a "mistake" (if seen as subject-verb disagreement) is actually a sophisticated grammatical constant that the final shift exploits. Students who only check subject-verb agreement miss the predicate-agreement rule and the poetic strategy.
ANSWER: The verb "gksrh" remains feminine singular throughout the negative section because it agrees with the predicate adjective "lcls [krjukd" (feminine), not the varying subjects. This grammatical invariance unifies six disparate concepts into a single rejected category. The shift to masculine "gksrk gS" in the affirmative section (agreeing with pk¡n/?kM+h/xhr) marks the poetic breakthrough — grammar itself enacts the redefinition.

## WORKED_EXAMPLE_3
PROBLEM: Combine grammatical analysis with literary device identification: In "lcls [krjukd og xhr gksrk gS / vkiosQ dkuksa rd igq¡pus osQ fy, / tks ejfl, i<+rk gS / vkrafdr yksxksa osQ njok”kksa ij / tks xaqMs dh rjg vdM+rk gS", identify the *upama* (simile) and explain how its grammatical embedding (case structure) differs from a standard prose simile.
STEPS:
- Step 1: Locate the simile: "xaqMs dh rjg vdM+rk gS" (falls like lightning). "xaqMs" = lightning (noun, masculine singular); "dh rjg" = genitive + noun "rjg" (manner/way) = postpositional phrase functioning as adverbial of manner.
- Step 2: Standard prose simile: "Wo xaqMs ki tarah gira" (He fell like lightning) — "ki tarah" is a fixed postpositional phrase. Here, "dh rjg" is the poetic variant (rjg = tarah).
- Step 3: Analyze embedding: The simile is NOT at clause end but embedded inside a relative clause ("tks ejfl, i<+rk gS / vkrafdr yksxksa osQ njok”kksa ij / tks xaqMs dh rjg vdM+rk gS") which itself modifies "xhr" (sharpness). Three layers: Main clause -> Relative clause 1 (purpose: igq¡pus) -> Relative clause 2 (agent: ejfl, i<+rk) -> Relative clause 3 (manner: xaqMs dh rjg vdM+rk).
- Step 4: Grammatical deviation: The verb "vdM+rk" (falls) is habitual present, but its subject is the relative pronoun "tks" referring to "xhr" (sharpness) — abstract noun acting as agent of falling. In prose, we'd say "xaqMs ki tarah tej chalti hai" (runs like lightning). Here, "sharpness falls like lightning on helpless people's sorrows" — the grammatical subject ("xhr") is the *quality* not the *agent*.
- Step 5: Thematic payoff: This grammatical transference (quality becomes actor) mirrors the poem's central metaphor: abstract injustices (sharpness, lightning) act directly on bodies. The genitive "vkrafdr yksxksa osQ njok”kksa ij" (on helpless people's sorrows) uses double genitive (vkrafdr yksxksa = of helpless people; njok”kksa = sorrows) to concentrate victimhood.
- Step 6: Synthesis for board answer: "The poet embeds the simile 'xaqMs dh rjg' within a triple-relative-clause structure where the abstract noun 'xhr' (sharpness) becomes the grammatical subject of 'vdM+rk' (falls). This syntactic promotion of quality to agent enacts the poem's political vision: systemic violence is not done *by* people but *is* the sharpness that falls like lightning."
REASONING: This 6-step example shows the integration required for 5-6 mark "samagra vishleshan" (comprehensive analysis) questions — connecting grammar (relative clause embedding, subject selection), rhetoric (simile structure), and theme (political metaphor).
ANSWER: The simile "xaqMs dh rjg" uses the genitive-postposition "dh rjg" (poetic for "ki tarah") but is embedded three clauses deep with "xhr" (sharpness) as subject of "vdM+rk". This grammatical architecture makes an abstract quality the actor of violence, syntactically realizing the theme that oppression is structural, not personal.

## COMPETENCY_QUESTION_1
QUESTION: A student writes in their board exam answer: "The poet uses wrong grammar in 'lcls [krjukd ugha gksrh' because there is no subject. This makes the poem confusing." Using your knowledge of poetic grammar, write a 4-point rebuttal that a teacher would give, referencing specific grammatical concepts from this node.
COMPETENCY: Critical evaluation of peer response using grammatical terminology
STEPS:
- Step 1: Identify the student's error: confusing elliptical subject (standard in Hindi) with "wrong grammar".
- Step 2: Name the concept: *lopa* (ellipsis) of *karta* (subject) when recoverable from context/predicate.
- Step 3: Explain the poetic function: The missing subject forces reader focus onto the predicate "lcls [krjukd" — enacting the theme of erasure.
- Step 4: Cite the grammatical rule: Hindi is a *pro-drop* language; null subjects are grammatical, not errors.
- Step 5: Connect to exam rubric: Such a statement would lose marks for "lack of grammatical awareness" in the "shailli" section.
ANSWER: Teacher's rebuttal: (1) Hindi is a pro-drop language — null subjects (*lopa*) are grammatically licensed, not errors; the subject "yah/wo" is recoverable from discourse. (2) The construction follows *pratishedh vakya* syntax: [Subject] [Predicate Adjective] [Negative] [Verb] — the predicate "lcls [krjukd" carries the semantic weight. (3) Poetically, the ellipsis enacts the poem's theme: the "smallest" things are those rendered invisible (subject-less) by power structures. (4) Calling this "wrong grammar" confuses poetic *shailli* (style) with prose *niyam* (rule) — a category error that loses 2-3 marks in "bhavarth avam shailli" questions.
DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: The poem's final stanza uses three nouns — "pk¡n" (wound), "?kM+h" (burden), "xhr" (sharpness) — all masculine singular, each followed by a relative clause with "tks". Design a grammatical transformation exercise where you convert this poetic structure into standard prose (anvaya) while preserving all case relations, then explain what is lost in translation.
COMPETENCY: Grammatical transformation and meta-linguistic analysis
STEPS:
- Step 1: Write the anvaya for one noun (e.g., "pk¡n"): "Wo pk¡n hai jo yuddh ke peeche, ghaayal saanson mein palti hai, aur jismein aapki aankhen kantein ki tarah nahin chubhti." Mark all karak: pk¡n (karta), yuddh ke peeche (adhikarana), ghaayal saanson mein (adhikarana), aapki aankhen (karta of chubhti), kantein ki tarah (upamana).
- Step 2: Note losses: (a) Rhythmic parallelism of three "og... tks" structures; (b) Enjambment forcing "p<+rk" (festering) to hang before "ij"; (c) The emphatic "gksrk gS" at line-start vs. prose "hai" at clause-end; (d) The visual spacing on page that makes "xaqMs dh rjg vdM+rk gS" a final hammer-blow.
- Step 3: Generalize: Prose anvaya linearizes the poem's *spatial* grammar — where postpositional phrases stack vertically — into temporal sequence.
- Step 4: Formulate exam answer: "Anvaya flattens the poem's vertical syntax (stacked locatives, suspended relatives) into horizontal narration, losing the *chhavi* (image) of weight and delay that the grammar enacts."
- Step 5: Add board-exam tip: "Always quote the poetic line first, then give anvaya, then analyze what the poetic word order *does* that anvaya cannot."
ANSWER: Transformation: "Sabse chhota wo zakhm hai jo yuddh ke peeche, ghaayal saanson mein paltta hai, aur jis par aapki aankhen kantein ki tarah nahin chubhti." / "Sabse chhota wo bojh hai jo aapki peeth par pada hai, aur jo aapki ragon mein dhadakta hai." / "Sabse chhoti wo teekha hai jo bebas logon ke ghamon par bijli ki tarah girti hai." Losses: (1) The triple anaphora "og... tks... og... tks... og... tks" creating ritualistic accumulation; (2) The participle "p<+rk" stranded before its postposition "ij" — a syntactic suspension mirroring psychological suspension; (3) The final line's isolation of "xaqMs dh rjg vdM+rk gS" as a standalone declaration. Prose makes it information; poetry makes it experience.
DIFFICULTY: hard