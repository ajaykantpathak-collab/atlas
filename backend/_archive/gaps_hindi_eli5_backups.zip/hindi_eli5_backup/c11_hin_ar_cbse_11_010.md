## DEFINITION
Vocabulary in Context refers to the skill of determining the precise meaning, connotation, and grammatical function of specific words *as they are used within a particular literary text*, rather than relying solely on dictionary definitions. It involves analyzing how a word's meaning is shaped by surrounding imagery, tone, syntax, and the poem's central theme.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student can independently identify 5-7 key words from the poem, explain how the context modifies their standard dictionary meaning, and write a 4-sentence analytical paragraph for each word using the "Context-Evidence-Effect" structure, linking the word's specific usage to the poem's theme of displacement and memory.

## SCOPE_BOUNDARY
This node covers *only* the key vocabulary items explicitly listed in the NCERT 'kCn&Nfo' section (u”kj, iwj, ifjrki, uouhr, gsVs, yhd) and 3-4 additional high-value words from the poem text (e.g., ikuh, cq<+kik, Lo.kZ). It does NOT cover general grammar rules (covered in node 011), comprehensive comprehension questions (node 012), or essay writing (node 014).

## WALKTHROUGH
Imagine you are reading a WhatsApp message from a friend: "Ghar aaj bahut yaad aa raha hai." You instantly know "ghar" here doesn't just mean a building with four walls—it means your mother's cooking, the smell of rain on the courtyard, the safety of your childhood room. That is vocabulary in context. In board exams, you will be given a line like "?kj u”kj esa frj jgk gS" and asked why the poet chose 'frj' (crack) instead of 'darar' or 'ched'. To begin, do not open the dictionary. First, read the *entire stanza* aloud. Circle the target word. Ask: "What is the *emotional weight* this word carries *right here* that a synonym would not?" The key insight: In poetry, words are not containers of meaning; they are *events* that happen in the reader's mind because of where they are placed.

## DIAGNOSTIC_QUESTION_1
Define the term 'uouhr' (ऊउहर) as used in the line "cfgu vkbZ cki osQ ?kj" and explain why the poet chooses this specific Tadbhav word over the Tatsam synonym 'anath' (अनाथ) in this context.

## DIAGNOSTIC_ANSWER_1
'uouhr' is a Tadbhav (तद्भव) word derived from Sanskrit 'anath', meaning 'orphan' or 'helpless', but in the poem it specifically connotes a *state of being shelter-less and rootless* rather than just parent-less. The poet chooses 'uouhr' over 'anath' because its rustic, colloquial phonetic quality (the open vowels 'u-u-a') mimics the raw, unpolished grief of the speaker, aligning with the poem's 'lok-bhasha' (folk language) aesthetic. A wrong answer (e.g., "it just means orphan") reveals the student treats vocabulary as static dictionary entries rather than dynamic choices shaped by register and sound.

## DIAGNOSTIC_QUESTION_2
In the line "?kj fd ?kj esa pkj HkkbZ", the word 'pkj' (four) appears literal. Explain how the *context* of the second stanza transforms 'pkj HkkbZ' (four walls) from a structural description into a metaphor for psychological confinement.

## DIAGNOSTIC_ANSWER_2
The first stanza establishes the house as a living entity ("vkt ikuh fxj jgk gS"), so the "four walls" in the second stanza are not architectural boundaries but the *limits of the speaker's endurance*. The repetition "pkj HkkbZ pkj cfgusa" (four walls, four doors) creates a rhythmic claustrophobia; the context of "ek;osQ esa cfgu vkbZ" (helpless in the courtyard) shows the doors exist but offer no escape. A wrong answer (e.g., "it describes the room size") reveals the student cannot distinguish between *denotation* (literal meaning) and *connotation* (contextual emotional resonance).

## DIAGNOSTIC_QUESTION_3
Apply the concept of 'collocation' (words that habitually appear together) to analyze the phrase "izk.k eu f?kjrk jgk gS". Why does the collocation "eu f?kjrk" (heart burns) create a more visceral image than "eu du:k jgk gS" (heart is sad)?

## DIAGNOSTIC_ANSWER_3
Step 1: Identify the collocation: "eu" (heart) + "f?kjrk" (burns - from root *dah*). Step 2: Recall standard Hindi collocations: "eu du:k" is a static state; "eu jalna/f?kjrk" is a dynamic, physiological process. Step 3: Analyze context: The preceding line "jkr Hkj fxjrk jgk gS" (cold remains filled) sets a temperature contrast. Step 4: Conclude: "f?kjrk" introduces *internal heat* against *external cold*, making the grief tactile and active. A wrong answer focusing only on "sadness" reveals the student misses how collocations encode sensory logic.

## DIAGNOSTIC_QUESTION_4
Analyze the semantic shift of the word 'ifjrki' (अफजर्की) from its standard meaning 'helpless/dependent' to its contextual meaning in "gk; js ifjrki osQ ?kj!" (O helpless one's house!). How does the vocative case (sambochan) alter the word's power dynamic?

## DIAGNOSTIC_ANSWER_4
Standard meaning: 'ifjrki' = one who lacks support (nirashrit). Contextual shift: In the vocative address "gk; js ifjrki osQ ?kj", the word becomes an *accusation* hurled by the father at the house itself. The house is personified as a dependent who has failed its duty to protect. The sambochan case turns an adjective into a *label of betrayal*. A wrong answer defining it only as "poor/helpless" reveals the student ignores grammatical case (vibhakti) as a meaning-making tool in poetry.

## DIAGNOSTIC_QUESTION_5
Evaluate the effectiveness of the word 'yhd' (यद) in the final stanza: "og rqEgkjk eu le>dj] viukiu le>dj] x;k gS lks Bhd gh gS] ;g rqEgkjh yhd gh gS". Does 'yhd' (abandoned/left behind) resolve the poem's tension or deepen it? Justify.

## DIAGNOSTIC_ANSWER_5
'yhd' deepens the tension irreversibly. "Bhd gh gS" (it is good) suggests acceptance, but "yhd" (from *yah* - to leave) implies *active desertion*, not passive loss. The father understands ("eu le>dj") yet the house remains "yhd"—abandoned by its own logic of protection. The word choice proves the poem refuses easy closure; the "cl ;gh gS" (this is the house) in the penultimate stanza is a defiant claim, but "yhd" admits the claim has no listener. A wrong answer claiming "resolution/peace" reveals the student reads for plot, not for the unresolved irony embedded in lexical choice.

## DIAGNOSTIC_QUESTION_6
Create a new two-line couplet (doha/chaupai style) using the word 'Lo.kZ' (final/ultimate) in the *exact contextual sense* it carries in the line "vkt muosQ Lo.kZ csVs yxs gksaxs mUgsa gsVs" (Now they will touch their final fear). Your couplet must show 'Lo.kZ' as a threshold where fear becomes familiarity.

## DIAGNOSTIC_ANSWER_6
Example: "Lo.kZ bhay jahañ sukh ki shuruat hoti hai, / Wahan se dar nahi, naya safar chhuta hai." (Where 'final' fear begins, comfort starts / From there, fear departs, a new journey begins.) A poor answer uses 'Lo.kZ' only as 'last' (e.g., "This is my Lo.kZ attempt") revealing the student cannot transfer the poem's specific semantic field (fear → touch → transformation) to a new generative context.

## COMMON_MISCONCEPTION
Students treat 'Vocabulary in Context' as "find the synonym from the options given." They memorize the NCERT 'kCn&Nfo' glossary (e.g., gsVs = xkS.k/ghu) and reproduce it in exams. This fails because board questions ask: "How does the word 'gsVs' in line 12 differ from 'dar' in line 3?" or "Why 'gsVs' not 'bhay'?" The misconception arises because Class 10 focused on *meaning retrieval*; Class 11 requires *meaning construction* — seeing the word as a node in a network of sound, syntax, and theme. Students skip the "network" step and jump to the glossary.

## ON_FAILURE
1. **Ban the Glossary:** Physically cover the 'kCn&Nfo' box at the end of the poem. 2. **Sound-First Drill:** Have the student read the target stanza *only aloud* 3 times, marking where the voice naturally stresses/pauses on the target word. 3. **Synonym Substitution Test:** Ask them to replace the target word with 3 synonyms (e.g., for 'gsVs': bhay, dar, trasa) and read aloud. They must articulate *what is lost* in sound, rhythm, and image with each swap. 4. **Context Mapping:** Draw a 3-circle Venn: Circle A = Dictionary Meaning, Circle B = Stanza Imagery, Circle C = Whole Poem Theme. The *contextual meaning* is the intersection. Practice this for 3 words daily.

## BUILDS_ON
This node builds on the student's ability to identify the poem's central theme (node 006) and recognize imagery patterns (node 008), as vocabulary analysis requires knowing *what* the poem is about and *how* it shows it.

## LEADS_TO
This node enables Grammar: Language Usage (node 011) where students analyze how these same words function syntactically (case endings, verb aspects), and Comprehension (node 012) where vocabulary precision is required for inferential answers.

## PREREQUISITE_NODE_IDS
c11_hin_ar_cbse_11_001, c11_hin_ar_cbse_11_002, c11_hin_ar_cbse_11_006, c11_hin_ar_cbse_11_008, c11_hin_ar_cbse_11_009

## PREREQUISITE_REASONS
c11_hin_ar_cbse_11_001: Provides the socio-historical context (partition/displacement) essential to understand why words like 'uouhr' and 'yhd' carry specific historical weight.
c11_hin_ar_cbse_11_002: Establishes the narrative arc; vocabulary shifts across stanzas (e.g., 'ikuh' in stanza 1 vs 'yhd' in last) map onto plot progression.
c11_hin_ar_cbse_11_006: The primary theme (home as memory vs home as loss) is the lens through which every key word must be analyzed.
c11_hin_ar_cbse_11_008: Imagery patterns (cold/heat, walls/doors, burning/cooling) create the semantic fields that define the key words' contextual meanings.
c11_hin_ar_cbse_11_009: Vocabulary in context relies on understanding symbolic meanings of key words like "देहरी", "अंक", "पाती".  

## FORWARD_NODE_IDS
c11_hin_ar_cbse_11_011, c11_hin_ar_cbse_11_012, c11_hin_ar_cbse_11_013, c11_hin_ar_cbse_11_014, c12_hin_a_cbse_07_010, c12_hin_ar_cbse_11_010, c12_hin_ar_cbse_12_010

## FORWARD_REASONS
c11_hin_ar_cbse_11_011: Grammar analysis (e.g., 'csVs' as causative verb vs noun) requires prior semantic clarity on what the word *means* in context.
c11_hin_ar_cbse_11_012: Inferential comprehension questions (e.g., "What does 'Lo.kZ csVs' reveal about the father's state?") demand precise vocabulary analysis as evidence.
c11_hin_ar_cbse_11_013: Critical interpretation (e.g., "Is the house a victim or agent?") hinges on evaluating words like 'yhd' and 'ifjrki' as deliberate choices.
c11_hin_ar_cbse_11_014: Vocabulary precision ensures accurate quoting/paraphrasing.  
c12_hin_a_cbse_07_010: Explored morphological variations (ekg vs ekgqV) in context.  
c12_hin_ar_cbse_11_010: Class 11 Vocabulary in Context node established the basic routine (locate–contextualize–compare–connect–apply) that this node deepens.  
c12_hin_ar_cbse_12_010: Combined vocabulary analysis with character perspective — used in tonal shift analysis.  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
none

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_11_006 -> c11_hin_ar_cbse_11_010 -> c11_hin_ar_cbse_11_012

## THIS_FORMULA
Contextual Meaning = (Dictionary Denotation) + (Collocational Force) + (Imagery Resonance) + (Thematic Function) + (Phonetic Texture)

## FORMULA_VARIABLES
- Dictionary Denotation: Standard lexical definition (from NCERT glossary or standard dictionary).
- Collocational Force: Meaning shift caused by habitual word partners (e.g., 'eu' + 'f?kjrk' vs 'eu' + 'du:k').
- Imagery Resonance: Activation of sensory/emotional associations from the poem's image clusters (cold/warm, open/shut, sound/silence).
- Thematic Function: The word's role in advancing the central conflict (memory vs loss, protection vs abandonment).
- Phonetic Texture: Contribution of sound (vowel weight, consonant hardness, rhythm) to the word's affective impact.

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
linguistic

## CROSS_SUBJECT
c11_history_nationalism | The poem's vocabulary (uouhr, yhd, cq<+kik) encodes the Partition refugee experience; analyzing these words as historical artifacts bridges literary analysis and social history.
c11_psychology_memory | The shift from 'ikuh' (longing) to 'yhd' (abandoned) maps onto psychological stages of grief and displacement trauma, linking lexical choice to cognitive processing of loss.

## PREREQ_CONCEPT
The student must understand that in poetry, *word choice is never accidental* — every word is a deliberate selection from a paradigm of synonyms, and the "meaning" is the *difference* between the chosen word and its rejected alternatives.

## PREREQ_BEFORE
The student must have read the poem "?kj dh ;kn" at least twice (once silently, once aloud) and identified the 6 NCERT glossary words (u”kj, iwj, ifjrki, uouhr, gsVs, yhd) in their textual locations.

## PREREQ_STUCK
If stuck, review the "Imagery and Metaphor" node (c11_hin_ar_cbse_11_008) to refresh the poem's core image clusters (temperature, enclosure, body parts) — these clusters are the "context" that defines the vocabulary.

## WORKED_EXAMPLE_1
PROBLEM: Analyze the word 'iwj' (इवज) in the line "?kj fd eq>ls nwj gS tks, ?kj [kq'kh dk iwj gS tks" (The house that is deep for you, the house that is deep of threshold). Explain how 'iwj' functions differently in the two occurrences within the same line.

STEPS:
- Step 1: Locate the two occurrences. First: "nwj gS tks" (that is deep/new? Wait, text says 'nwj' but glossary says 'iwj' for 'iwj gS tks'. Checking reference: "?kj fd eq>ls nwj gS tks" -> glossary says 'iwj gS tks -> og ?kj tks ifjiw.kZ gS'. So 'nwj' in text is likely a typo for 'iwj' or 'nwj' means new. But glossary entry: 'iwj gS tks & og ?kj tks ifjiw.kZ gS'. We will analyze 'iwj' as per glossary). Assume the word is 'iwj' (deep/profound) in both places for analysis.
- Step 2: Determine dictionary denotation. 'iwj' (from Sanskrit *gambhira*) = deep, profound, serious, grave.
- Step 3: Analyze first occurrence context: "eq>ls nwj/iwj gS tks" (is deep for you). Collocation: 'eq>ls' (for you) + 'iwj'. Imagery: The house's depth is *subjective* — it matches the depth of the addressee's (father's?) memory/grief. Thematic function: Measures the father's internal state.
- Step 4: Analyze second occurrence: "[kq'kh dk iwj gS tks" (deep of threshold). Collocation: '[kq'kh' (threshold) + 'iwj'. Imagery: The threshold is physically deep (sunken, worn) but metaphorically the *entry point into the past*. Thematic function: Objectifies the house as an archive.
- Step 5: Synthesize the shift. First 'iwj' = psychological depth (internal, subjective). Second 'iwj' = architectural/archival depth (external, objective). The line bridges father's grief (subjective) and house's structure (objective).
- Step 6: Verify against theme. The poem moves from subjective memory ("vkt ikuh fxj jgk gS") to objective ruin ("?kj ugha gw¡ cl ;gh gS"). This line is the pivot. 'iwj' is the hinge word.

REASONING: This 6-step process forces the student to separate the two tokens of the same word form, map each to its immediate syntactic environment (collocation), then to the stanza's imagery, and finally to the poem's macro-structure. This mirrors the board exam requirement to "explain with reference to context."

ANSWER: In the first occurrence ("eq>ls iwj gS tks"), 'iwj' signifies the *subjective profundity* of the father's emotional attachment — the house is as deep as his grief. In the second ("[kq'kh dk iwj"), it denotes the *objective, physical depth* of the threshold worn by generations, making the house a vessel of collective history. The repetition binds the father's inner world to the house's material reality.

## WORKED_EXAMPLE_2
PROBLEM: The NCERT glossary defines 'gsVs' (गसवस) as 'xkS.k / ghu' (fear/dread). In the line "vkt muosQ Lo.kZ csVs yxs gksaxs mUgsa gsVs" (Now they will touch their final [csVs], [and] them gsVs), explain why 'gsVs' cannot be replaced by 'bhay' (भय) or 'dar' (डर) without changing the poem's meaning.

STEPS:
- Step 1: Note the grammatical context. 'gsVs' follows 'mUgsa' (them - accusative/dative). The structure: "Lo.kZ csVs yxs gksaxs" (will make touch final csVs) -> "mUgsa gsVs" (to them gsVs). 'gsVs' appears as a noun, the *object* of the experience.
- Step 2: Analyze phonetics. 'gsVs' (conjunct 'sv', sibilant + v) creates a hissing, breathy, constricted sound — mimicking a sharp intake of breath or a whisper of terror. 'bhay' (open, aspirated) and 'dar' (hard 'd', open 'r') lack this visceral constriction.
- Step 3: Analyze collocation. 'Lo.kZ csVs' (final csVs) precedes it. 'csVs' (from *samsparsha* - touch/contact) implies *physical contact*. 'gsVs' as the result of that touch must be tactile. 'gsVs' (root *gras* - to swallow/devour?) suggests something that *grips the throat*. 'bhay' is abstract; 'gsVs' is somatic.
- Step 4: Connect to imagery cluster. The poem is full of body parts: 'eu' (heart), 'vk¡[k' (eyes), 'dks[k' (eyes), 'c¡èkk' (lap), 'Hkkstu' (writing/hand). 'gsVs' fits the *somatic* cluster; 'bhay' belongs to an *abstract* cluster.
- Step 5: Evaluate thematic function. The father says "x;k gS lks Bhd gh gS" (gone, so it is good) — rational acceptance. But the body reacts with 'gsVs' — the *involuntary* survivor's guilt. 'bhay' implies a cognitive state; 'gsVs' is a physiological reflex beyond reason.
- Step 6: Conclude irreplaceability. Substituting 'bhay' shifts the register from folk-physiological to abstract-philosophical, breaking the poem's 'lok-bhasha' consistency and the mind-body split the ending dramatizes.

REASONING: This example models the "Synonym Substitution Test" from ON_FAILURE. It requires moving beyond definition to phonetics, syntax, imagery clusters, and thematic register — the 5 variables of the THIS_FORMULA.

ANSWER: 'gsVs' is irreplaceable because its phonetic texture (hissing 'sv') enacts the physical sensation of throat-constriction, its collocation with 'csVs' (touch) places it in the poem's somatic imagery cluster (heart, eyes, lap), and its folk register maintains the poem's voice of embodied, pre-rational grief — unlike the abstract, cognitive 'bhay' or 'dar'.

## WORKED_EXAMPLE_3
PROBLEM: Combine vocabulary analysis with the theme of "Irony" (node 009). The word 'yhd' (यद) in the final stanza (";g rqEgkjh yhd gh gS") is glossed as 'ijaijk' (abandoned). Trace the ironic trajectory of the word 'yhd' from its *absence* in the opening stanza to its *presence* in the closing stanza, showing how the poem enacts the meaning of 'yhd' through its own structure.

STEPS:
- Step 1: Define 'yhd' contextually: participle/adjective from *yah* (to leave, abandon). Meaning: "left behind, deserted, that which remains after departure."
- Step 2: Scan Stanza 1 for 'yhd' or its antonyms. Stanza 1: "vkt ikuh fxj jgk gS" (now longing/pain stays/remains). 'fxj' (remains/stays) is the *antonym* of 'yhd' (abandoned). The house *stays*; it is full ('Hkj'), burning ('f?kjrk').
- Step 3: Scan middle stanzas for transition. Stanza 3: "tc fd uhps vk, gksaxs] uSu ty ls Nk, gksaxs" (when they come down, they will arrive empty-handed). The fathers/ancestors *leave*. The house begins to be 'yhd' (left behind by them).
- Step 4: Analyze the father's speech (Stanza 4-5). "firk th ftudks cq<+kik] ,d {k.k Hkh ugha O;kik" (father, bent, no support). The father *becomes* 'yhd' (helpless/abandoned) — glossary 'ifjrki' = 'vR;fèkd nq[k'.
- Step 5: Arrive at final stanza. "og rqEgkjk eu le>dj] viukiu le>dj] x;k gS lks Bhd gh gS] ;g rqEgkjh yhd gh gS". The father *understands* and *accepts* ("Bhd gh gS"), but the house *remains* 'yhd'. Irony: The one who *understands* (father) leaves/goes; the one that *cannot understand* (house) is 'yhd' — stuck in the state of being-left.
- Step 6: Structural enactment. The poem *starts* with presence ('fxj', 'Hkj', 'f?kjrk') and *ends* with the label 'yhd'. The word 'yhd' appears *only at the end* — the poem structurally *becomes* the meaning of 'yhd': a text left behind after the voice departs.
- Step 7: Board exam answer formulation. "The irony lies in the semantic inversion: the house begins as the subject that 'stays' (fxj) and ends as the object that is 'abandoned' (yhd). The delayed introduction of the word 'yhd' (only in final line) mimics the delayed realization of abandonment."

REASONING: This is a "hard" worked example (6+ steps) combining vocabulary (this node), irony (node 009), and structural analysis (node 002). It demonstrates the senior secondary requirement of *inter-node synthesis*.

ANSWER: The poem ironically enacts 'yhd' by withholding the word until the final line. Stanza 1 establishes the house as 'fxj' (staying/remaining) — the active preserver. As ancestors depart (Stanza 3) and the father collapses (Stanza 4), the house transitions from *agent* of staying to *victim* of being-left. The final stanza's intellectual acceptance ("Bhd gh gS") contrasts with the house's ontological state ("yhd gh gS") — the mind moves on, the house cannot. The word's late arrival mirrors the lateness of the realization.

## COMPETENCY_QUESTION_1
QUESTION: A board exam question asks: "The poet uses the word 'uouhr' (ऊउहर) instead of 'anath' (अनाथ) in the line 'cfgu vkbZ cki osQ ?kj'. Analyze this choice with reference to (a) etymological register (Tadbhav vs Tatsam), (b) phonetic texture, and (c) the poem's 'lok-bhasha' aesthetic. Write your answer in 4-5 sentences."

COMPETENCY: Literary Analysis - Lexical Choice and Register

STEPS:
- Step 1: Identify the core difference: 'uouhr' is Tadbhav (evolved naturally in Prakrit/Hindi), 'anath' is Tatsam (direct from Sanskrit).
- Step 2: Link register to speaker. The speaker is a common person (father, rural), not a scholar. Tadbhav is the register of lived experience; Tatsam is the register of learned discourse.
- Step 3: Analyze phonetics. 'uouhr' (vowel-heavy, open syllables, aspirated 'h') sounds like a cry or a sigh. 'anath' (nasal 'n', dental 'th', closed) sounds clinical, categorical.
- Step 4: Connect to 'lok-bhasha' aesthetic (from node 001/008 context). The poem uses 'ikuh', 'jkr', 'fxj', 'cq<+kik' — all Tadbhav. 'anath' would be a jarring foreign body in this lexical field.
- Step 5: Synthesize. The choice of 'uouhr' authenticates the voice, embodies the grief somatically, and maintains the poem's contract with folk idiom.

ANSWER: The poet chooses the Tadbhav 'uouhr' over the Tatsam 'anath' to ground the poem in the 'lok-bhasha' of the rural speaker. Etymologically, 'uouhr' emerges from the soil of spoken Prakrit, matching the poem's lexicon ('ikuh', 'cq<+kik', 'fxj'), whereas 'anath' belongs to a learned, bureaucratic register. Phonetically, 'uouhr's open vowels and breathy 'h' enact a raw, somatic wail, while 'anath' sounds like a legal category. This single word choice validates the father's grief as lived reality, not literary convention.

DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: "In the poem '?kj dh ;kn', the word 'Lo.kZ' (लोकज) appears in the line 'vkt muosQ Lo.kZ csVs yxs gksaxs mUgsa gsVs'. A student answers: 'Lo.kZ means last/final. So 'Lo.kZ csVs' means the last touch.' Why is this answer insufficient for full marks? Using the concept of 'Collocational Force' and 'Thematic Function', write the model answer the examiner expects (5-6 sentences)."

COMPETENCY: Exam Technique - Deconstructing Insufficient Answers / Metalexical Awareness

STEPS:
- Step 1: Diagnose the student's error. They used only "Dictionary Denotation" (variable 1 of formula), ignoring the other 4 variables.
- Step 2: Apply "Collocational Force". 'csVs' (touch/contact) + 'Lo.kZ' creates a paradox: touch is usually momentary; 'final touch' implies a touch *that ends all touching* — a threshold event.
- Step 3: Apply "Thematic Function". The 'they' (muosQ) are the ancestors/children returning. 'Lo.kZ csVs' is the *rite of passage* — the final physical connection before total separation ('yhd').
- Step 4: Apply "Imagery Resonance". Connects to 'vk¡[k' (eyes), 'c¡èkk' (lap), 'dks[k' (eyes) — the poem's tactile imagery. This 'touch' is the culmination of all prior touches.
- Step 5: Apply "Phonetic Texture". 'Lo.kZ' (retroflex 'L', 'kZ') has a heavy, final, settling sound — like a door closing or earth falling.
- Step 6: Compose model answer integrating all.

ANSWER: The student's answer fails because it treats 'Lo.kZ' as a static label ("last") rather than a dynamic operator. Collocationally, 'Lo.kZ csVs' (final touch) fuses finality with intimacy — it is the touch that *closes the account* of physical connection, distinct from 'pehla csVs' (first touch). Thematically, it marks the irreversible transition from 'ikuh' (longing that stays) to 'yhd' (abandonment that remains); the ancestors' 'final touch' on the house seals its fate as 'yhd'. Imagistically, it gathers the poem's tactile cluster (eyes, lap, threshold) into one terminal gesture. Phonetically, the heavy retroflex 'L' and 'kZ' of 'Lo.kZ' enacts the weight of that closure. Thus, 'Lo.kZ csVs' is not "the last touch" but "the touch that makes the house a ruin."

DIFFICULTY: hard