## DEFINITION
Critical thinking in literary analysis involves examining a text beyond its literal meaning to uncover deeper themes, evaluate the author's stylistic choices, and interpret the text's significance within its socio-cultural context. It requires synthesizing evidence from the text to form an independent, reasoned judgment about the work's meaning and effect.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student can independently analyze a stanza from the poem, identify at least two literary devices, explain their combined effect on the reader, and connect them to the central theme of rural displacement versus urban alienation with specific textual evidence.

## SCOPE_BOUNDARY
This node covers deep analysis and interpretation of the poem "vkvks] feydj cpk,¡" focusing on imagery, symbolism, structural contrasts (rural/urban, past/present), and the poet's philosophical stance. It does not cover the poet's detailed biography, other poems from the textbook, or grammar rules unrelated to poetic language.

## WALKTHROUGH
Imagine you visit your ancestral village after ten years in a metro city. The lanes are narrower, the trees gone, replaced by concrete. You feel a sharp pain – the place exists, but *your* place in it is gone. This poem captures that exact moment. To analyze it, start by reading the poem aloud to hear the rhythm of the rural words (BaMh, ckgq, Hkksykiu). Then, mark every sensory image: the "color of the soil," the "flute's melody," the "spinning wheel's sound." Ask: *Why these specific images?* They are not random; they are the building blocks of a lost world. Finally, trace the movement from the imperative "Come, let's go" to the resigned "lost" – this structural journey *is* the argument.

## DIAGNOSTIC_QUESTION_1
What is the central theme of the poem "vkvks] feydj cpk,¡" as established in the opening stanza?

## DIAGNOSTIC_ANSWER_1
The central theme is the poet's poignant longing to return to the simplicity and sensory richness of his rural childhood, contrasted with the impossibility of that return due to the irreversible changes brought by time and modernity. A wrong answer focusing only on "description of village life" reveals the student has grasped the *setting* but missed the *conflict* (desire vs. impossibility) which is the engine of the poem.

## DIAGNOSTIC_QUESTION_2
Explain in your own words the significance of the metaphor "uxkM+s dh rjg ctrs gSa 'kCn" (words flutter like butterflies) in the context of the poet's memory.

## DIAGNOSTIC_ANSWER_2
The metaphor signifies the fragile, elusive, and beautiful nature of the poet's memories and his mother tongue (Braj Bhasha). Like butterflies, these memories are colorful and alive but impossible to hold or pin down permanently; they flutter away when chased. A wrong answer interpreting it as "words are beautiful" misses the critical dimensions of *transience* and *helplessness* inherent in the butterfly image, failing to connect form (fluttering) to theme (loss of language/memory).

## DIAGNOSTIC_QUESTION_3
Identify two auditory images from the first half of the poem and explain how they function collectively to build the atmosphere of the "lost world."

## DIAGNOSTIC_ANSWER_3
The "BaMh" (flute melody) and the sound of the "ckgq" (spinning wheel) create a soundscape of rhythmic, organic, communal labor and leisure. Collectively, they establish an auditory signature of a self-sufficient rural life where work and art are integrated. A wrong answer listing visual images (like "color of soil") confuses sensory modes, while an answer listing them without explaining their *collective function* (integration of life) treats them as decorative details rather than structural evidence.

## DIAGNOSTIC_QUESTION_4
Analyze the structural contrast between the portrayal of the rural past (Stanzas 1-3) and the urban present (implied in Stanzas 4-5). What specific shift in agency does the poet depict?

## DIAGNOSTIC_ANSWER_4
The rural past is depicted as a space of *active participation* ("cpk,¡" - let's go, "nwfj;k¡" - we used to play, "fueZyk" - earned) where the subject is part of a collective rhythm. The urban present implies *passive alienation* ("vf'k{kk" - ignorance, "oqQjhfr;ksa" - complexities, "ckr dh vksj" - reason for helplessness). The shift is from *communal agency* to *individual powerlessness* within a complex modernity. A wrong answer merely listing "village good, city bad" misses the nuanced depiction of the village having "anomalies" (folaxfr;k¡) and the city having "arguments" (lekukRed), reducing a dialectical analysis to a binary.

## DIAGNOSTIC_QUESTION_5
Evaluate the effectiveness of the refrain "vkvks] feydj cpk,¡" at the poem's end compared to its beginning. Does the meaning change?

## DIAGNOSTIC_ANSWER_5
At the start, the refrain is an *invitation* (imperative mood) filled with hope and agency – the poet believes he can guide the reader (and himself) back. At the end, after the litany of loss ("FkksM+s&ls lius"), it becomes a *haunting echo* – a ritualistic chant to a god who isn't listening. The words are identical, but the semantic weight shifts from *possibility* to *impossibility*. A wrong answer stating "it repeats to emphasize the theme" is technically true but analytically shallow; it fails to perform the close reading of *contextual shift* required at this level.

## DIAGNOSTIC_QUESTION_6
Write a four-line stanza in Hindi using a central metaphor (like the poem's "mirage" or "butterflies") to describe a personal memory that you can never physically return to. Explain your metaphor choice.

## DIAGNOSTIC_ANSWER_6
*Example Stanza:*
"पुरानी नीम की छाँव, धूप सी फिसल गई,
पकड़ने चला था जिसे, वो रेत सी निकल गई।"
*Metaphor Explanation:* I used "dhup" (sunlight) and "ret" (sand) as metaphors for the memory of my grandmother's courtyard. Sunlight cannot be held; sand slips through fingers the tighter you grip. This mirrors the poem's "vkcks&gok" (mirage) – the memory is visible and warm but lacks substance in the present. A poor answer would use a simile ("memory is *like* sand") instead of a metaphor, or choose a metaphor implying permanence (e.g., "rock"), contradicting the prompt's requirement of "never return."

## COMMON_MISCONCEPTION
Students often believe "Critical Analysis" means hunting for a checklist of literary devices (metaphor, simile, alliteration) and defining them. They treat the poem as a static museum exhibit. The specific error is **Device Spotting without Functional Analysis**. For example, a student writes: "The poet uses metaphor in 'uxkM+s dh rjg ctrs gSa 'kCn'." They stop there. They do not ask: *Why a butterfly? Why not a bird? What does the 'fluttering' imply about the stability of the poet's identity?* This happens because school-level teaching often rewards identification over interpretation.

## ON_FAILURE
If a student only identifies devices, do not say "analyze deeper." Instead, use the **"So What?" Ladder** technique:
1.  **Quote the device:** "Words flutter like butterflies."
2.  **Ask:** "So what? What does a butterfly *do*?" (Flutters, fragile, short-lived, colorful, hard to catch).
3.  **Map to text:** "Which words? The Braj Bhasha words of childhood."
4.  **Synthesize:** "Therefore, the metaphor tells us the mother tongue is beautiful but dying/uncatchable in the modern world."
5.  **Force a PEEL paragraph:** Point (Metaphor of fragility), Evidence (Quote), Explanation (Ladder steps 2-4), Link (Connects to theme of cultural erosion). Practice this on *one* image per session until automatic.

## BUILDS_ON
This node builds directly on the literal/inferential comprehension (c11_hin_ar_cbse_16_012) and the identification of specific literary devices – Imagery/Metaphor (c11_hin_ar_cbse_16_008) and Irony/Symbolism (c11_hin_ar_cbse_16_009) – requiring the student to now *synthesize* these elements into a coherent critical argument.

## LEADS_TO
This node enables the Writing Skills node (c11_hin_ar_cbse_16_014) where students must structure these analytical insights into formal board-exam answers (long answer type), and the Speaking/Listening node (c11_hin_ar_cbse_16_015) where they defend their interpretation in discussion.

## PREREQUISITE_NODE_IDS
c11_hin_ar_cbse_16_012, c11_hin_ar_cbse_16_008, c11_hin_ar_cbse_16_009, c11_hin_ar_cbse_16_006, c11_hin_ar_cbse_16_007, c11_hin_ar_cbse_16_004, c11_hin_ar_cbse_16_005, c11_hin_ar_cbse_16_011

## PREREQUISITE_REASONS
c11_hin_ar_cbse_16_012: Literal and inferential comprehension provides the factual textual base (plot, setting, basic meaning) required before analysis can begin.
c11_hin_ar_cbse_16_008: Mastery of imagery and metaphor identification is the raw material for interpretation; you cannot analyze the "butterfly" if you don't recognize it as a metaphor.
c11_hin_ar_cbse_16_009: Understanding irony (the village has flaws, the city has logic) and symbolism (spinning wheel = self-reliance) is essential for the dialectical reading this node demands.
c11_hin_ar_cbse_16_006: The primary theme (nostalgia/loss) is the thesis statement that the analysis must prove.
c11_hin_ar_cbse_16_007: Secondary themes (education, feudalism, language politics) provide the sub-arguments for a multi-layered critical essay.
c11_hin_ar_cbse_16_004: Critical thinking node asks students to evaluate interpretations of the speaker's revolutionary ethics—requires this node's foundation.  
c11_hin_ar_cbse_16_005: Critical interpretation of the poem's socio-political argument requires the character-map built in this node.  
c11_hin_ar_cbse_16_011: Language usage in poetry refers to the deliberate grammatical, lexical, and syntactic choi... की समझ आवश्यक है, क्योंकि यह नोड (Critical thinking in literary analysis involves examining a text beyond its literal meanin...) इसी आधार पर आगे बढ़ता है।  

## FORWARD_NODE_IDS
c11_hin_ar_cbse_16_014, c11_hin_ar_cbse_16_015, c12_hin_a_cbse_03_013, c12_hin_a_cbse_10_013, c12_hin_al_cbse_02_013, c12_hin_ar_cbse_03_013

## FORWARD_REASONS
c11_hin_ar_cbse_16_014: Board exam long-answer questions (5-6 marks) require the PEEL structure and evidence-based argumentation modeled in this node's worked examples.
c11_hin_ar_cbse_16_015: Discussion points require students to articulate and defend interpretations (e.g., "Is the poet romanticizing the past?") using the analytical framework built here.
c12_hin_a_cbse_03_013: Class 11 critical thinking node establishes the analytical vocabulary and habits this node deepens.  
c12_hin_a_cbse_10_013: Advanced Class 11 practice — interpreting authorial positioning in 'Bharatvarsh Ki Unnati'.  
c12_hin_al_cbse_02_013: Prepared for board-style 'critical appreciation' questions.  
c12_hin_ar_cbse_03_013: अगला तार्किक चरण: Critical Thinking: इस नोड की अवधारणाओं को सीधे उपयोग/विस्तारित करता है।  

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_16_012 -> c11_hin_ar_cbse_16_013 -> c11_hin_ar_cbse_16_014

## THIS_FORMULA
N/A - conceptual

## FORMULA_VARIABLES
N/A

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
analytical

## CROSS_SUBJECT
c11_history_colonialism | The poem's depiction of the disruption of rural industry (spinning wheel) and traditional education by "vkfnoklh lekt" (feudal order) and modern "vf'k{kk" (Western education) mirrors the History syllabus on the impact of colonial economic policies and the destruction of indigenous industries in 18th-19th century India.
c11_sociology_social_change | The contrast between "vkfnoklh lekt" (gemeinschaft-like community) and the implied modern "laFkkyh lekt" (gesellschaft-like association) with its "oqQjhfr;k¡" (complexities) and "vf'k{kk" (anonymity) directly illustrates the Sociological concepts of Social Change, Urbanization, and the loss of Traditional Occupations.

## PREREQ_CONCEPT
The student must be able to distinguish between a literary device (the tool) and its rhetorical function (the effect), and must know the poem's central argument: *Modernity severs the organic link between language, labor, and landscape.*

## PREREQ_BEFORE
The student must have completed the 'Comprehension' and 'Literary Devices' nodes for this chapter and be able to list 5 key images and 3 key themes from the poem without looking at the text.

## PREREQ_STUCK
If stuck, immediately re-read the 'Literary Devices: Imagery and Metaphor' (c11_hin_ar_cbse_16_008) and 'Theme: Primary Theme' (c11_hin_ar_cbse_16_006) nodes. Focus specifically on the *list* of images and the *theme statement* provided there.

## WORKED_EXAMPLE_1
PROBLEM: Analyze the opening stanza ("vkvks] feydj cpk,¡ / viuh cfLr;ksa dks / uaxh gksus ls / 'kgj dh vkcks&gok ls cpk,¡") for the combined effect of the imperative mood and the central metaphor "vkcks&gok" (mirage). How does this establish the poem's core tension?

STEPS:
- Step 1: Identify the grammatical mood: "vkvks" (Come), "feydj" (walking), "cpk,¡" (touch) are imperative verbs addressing a second person (the reader/memory), establishing an urgent, active desire to bridge distance.
- Step 2: Identify the central metaphor: "vkcks&gok" (mirage) describes the "street of the courtyard" ('kgj). A mirage is an optical illusion caused by heat – visible, shimmering, but intangible and vanishing upon approach.
- Step 3: Analyze the collision: The imperative verbs demand *physical action* ("walk and touch"), but the metaphor declares the destination is an *optical illusion* (untouchable). The grammar commands movement; the imagery denies arrival.
- Step 4: Interpret the psychological state: This enacts the migrant's dilemma – the will to return (agency) vs. the ontological impossibility of return (structure). The "heat" causing the mirage is the "heat" of time/modernity.
- Step 5: Connect to Core Tension: The stanza compresses the entire poem's argument into four lines: The past is not a place you can visit; it is a mirage you can only hallucinate.

REASONING: This analysis moves beyond "identifying a metaphor" to "reading the friction between syntax and semantics." The imperative mood creates the *thesis* (return is possible); the mirage metaphor delivers the *antithesis* (return is impossible). The synthesis is the poem itself.

ANSWER: The opening stanza establishes the core tension through a clash between syntax and image. The imperative verbs ("vkvks, feydj, cpk,¡") assert the poet's agency and desire to physically reclaim the past. Simultaneously, the metaphor "vkcks&gok" (mirage) defines the object of that desire – the childhood street – as an illusion that recedes upon approach. This structural irony (commanding an action that the imagery declares impossible) encapsulates the migrant's tragedy: the past is geographically locatable ('kgj) but experientially inaccessible (vkcks&gok).

## WORKED_EXAMPLE_2
PROBLEM: In the lines "BaMh gksrh fnup;kZ esa / thou dh xekZgV / eu dk gjkiu / Hkksykiu fny dk / vD[kM+iu] tq>k:iu Hkh", the poet contrasts two sets of abstract nouns. Analyze how the morphological structure of these nouns (Tatsam vs. Tadbhav/Sanskritized) encodes the rural/urban divide.

STEPS:
- Step 1: List the positive nouns: "gjkiu" (melody/singing - Tadbhav/Desi root), "fny" (flute - Tadbhav), "vD[kM+iu" (restlessness - Tatsam/Sanskritized), "tq>k:iu" (weariness/fatigue - Tatsam/Sanskritized).
- Step 2: Note the morphological pattern: The rural joys use *Tadbhav/Desi* words (gjkiu, fny, BaMh, ckgq) – words born from the soil, phonetically soft, oral. The urban pains use *Tatsam/Sanskritized* abstract suffixes (-iu, -pan) – words of the academy, bureaucracy, philosophy, phonetically heavy, written.
- Step 3: Analyze the semantic shift: "eu dk gjkiu" (heart's song) is concrete, embodied, communal. "vD[kM+iu" (restlessness) is abstract, psychological, individualistic.
- Step 4: Connect to Language Politics (Theme): The poem argues that the *language itself* (Hkk"kk esa >kj[kaMhiu) carries the culture. Losing the Desi words means losing the Desi experiences they name.
- Step 5: Synthesize: The poet performs the loss linguistically. The vocabulary of the "lost world" is Desi; the vocabulary of the "present analysis" is Sanskritized. The medium *is* the message.

REASONING: This worked example demonstrates "Critical Thinking" by moving from *what* the words mean to *what the words are*. It connects the micro-level linguistic choice (morphology/etymology) to the macro-level theme (cultural displacement), a hallmark of senior secondary analysis.

ANSWER: The poet encodes the rural/urban divide in the etymology of his vocabulary. Rural vitality ("gjkiu", "fny", "BaMh", "ckgq") is named through Tadbhav/Desi words – oral, sensory, rooted in the body. Urban alienation ("vD[kM+iu", "tq>k:iu", "oqQjhfr", "vf'k{kk") is named through Tatsam/Sanskritized abstract nouns – cerebral, systemic, detached. This linguistic stratification proves the poem's argument: the shift to a Sanskritized/Urban Hindi ("Hkk"kk esa >kj[kaMhiu" lost) is not just a change of register, but an erasure of the experiential world those Desi words carried.

## WORKED_EXAMPLE_3
PROBLEM: The poem concludes: "FkksM+k&lk fo'okl / FkksM+h&lh mEehn / FkksM+s&ls lius / vkvks] feydj cpk,¡". Analyze how the anaphora of "FkksM+" (a little) and the semantic progression of the nouns ("fo'okl" -> "mEehn" -> "lius") structurally enact the poem's final philosophy of "diminishing returns."

STEPS:
- Step 1: Identify the device: Anaphora (repetition of "FkksM+" at line start).
- Step 2: Analyze the quantifier "FkksM+" (a little/just a bit). It signals reduction, minimization, lowering of expectations. The poet no longer asks for the *whole* past, just a *fragment*.
- Step 3: Trace the semantic trajectory of the objects:
    *   Line 1: "fo'okl" (World/Universe) – External, vast, spatial.
    *   Line 2: "mEehn" (Love/Affection) – Internal, relational, emotional.
    *   Line 3: "lius" (Lost) – Not a noun object, but a verb/adjective of status. The object has vanished; only the state of loss remains.
- Step 4: Analyze the syntactic collapse: Line 1 & 2 are noun phrases (Things wanted). Line 3 breaks the pattern: "FkksM+s&ls lius" (Lost *from* a little). The grammar fails to hold the object.
- Step 5: Interpret the Refrain's return: "vkvks] feydj cpk,¡" returns. But the imperative "cpk,¡" (touch) now has *no object* left to touch (fo'okl? lius. mEehn? lius). The command becomes a performative contradiction.
- Step 6: Final Philosophy: The structure mimics entropy. Hope shrinks from World -> Love -> Zero. The poem ends not with a period, but with a loop (refrain) that has lost its referent.

REASONING: This is a "Senior Secondary" level analysis because it integrates prosody (anaphora), semantics (lexical chain), syntax (phrase structure collapse), and pragmatics (speech act theory - the failed imperative) to prove the interpretation. It treats the poem as a machine made of words, not just a container of meaning.

ANSWER: The final stanza enacts "diminishing returns" through its form. The anaphora "FkksM+" creates a rhythmic shrinking. The semantic objects shrink ontologically: the cosmic "fo'okl" (world) reduces to the intimate "mEehn" (love), which collapses into the null-state "lius" (lost). Crucially, the syntax breaks in line 3 – "FkksM+s&ls lius" (Lost *from* a little) – signaling that even the *capacity to desire* is exhausted. The returning refrain "vkvks] feydj cpk,¡" thus becomes a cruel irony: the imperative "Touch!" hangs in a void where "fo'okl" and "mEehn" have already been declared "lius." The structure *performs* the impossibility it describes.

## COMPETENCY_QUESTION_1
QUESTION: The poem uses the image of the "ckgq" (spinning wheel) in the context: "ckgq dh nqfu;k ls Hkh ifjp; gqvk" (awakened even by the sound of the spinning wheel). Critically analyze how this single image functions as a *synectic symbol* connecting three distinct themes of the poem: the economic, the gendered, and the temporal.

COMPETENCY: Multi-thematic synthesis and symbolic interpretation

STEPS:
- Step 1: Define the spinning wheel's primary economic significance in the Indian nationalist discourse (Khadi, self-reliance, village republic).
- Step 2: Analyze the gendered dimension: "ckgq" is traditionally women's labor (spinning). Its sound ("nqfu;k") marking the rhythm of the day positions women's invisible labor as the *chronometer* of rural life.
- Step 3: Analyze the temporal dimension: The spinning wheel is cyclical (circular motion), representing cyclical/agrarian time. "ifjp; gqvk" (awakened) implies a rupture – linear/historical time (modernity/colonialism) shattering the cycle.
- Step 4: Synthesize: The image condenses the poem's argument: The destruction of the village economy (economic), the disruption of women's social rhythm (gendered), and the imposition of linear history (temporal) are not three separate events but *one* event – the sound stopping.

ANSWER: The spinning wheel is a synectic symbol compressing the poem's total critique. Economically, it evokes the Gandhian village republic destroyed by colonial modernity ("vf'k{kk", "oqQjhfr"). Gendered, its sound ("nqfu;k") represents the invisible female labor that structured the domestic day; its silencing marks the erasure of that world. Temporally, its circular motion symbolizes the cyclical time of nature/tradition; the phrase "ifjp; gqvk" (was awakened/aroused) suggests a violent interruption of this cycle by linear historical time. The single auditory image thus binds the material, social, and philosophical ruptures of the poem into one resonant symbol.

DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: "The poet's use of Braj Bhasha forms ('cfLr;k¡', 'vkcks&gok', 'BaMh', 'ckgq') within a Modern Standard Hindi poem is not merely stylistic flavor; it is the *site of the political argument*." Defend or refute this statement using evidence from the poem's treatment of language ("Hkk"kk esa >kj[kaMhiu") and education ("firk vkSj pkpk f'k{kd").

COMPETENCY: Evaluation of language politics and meta-linguistic awareness

STEPS:
- Step 1: Establish the linguistic hierarchy: Modern Standard Hindi (Khari Boli) = Language of State, Education, Modernity, Power. Braj Bhasha = Language of Home, Intimacy, Tradition, Marginality.
- Step 2: Analyze "Hkk"kk esa >kj[kaMhiu" (Rusticity in language). The poet *values* this "rusticity" – it is not a defect but the "osaQnz" (essence) of his poetry.
- Step 3: Analyze the education narrative: "firk vkSj pkpk f'k{kd" (Father and uncle were teachers) but "fu;fer vè;;u" (forced employment) due to economic distress. The *traditional* guru-shishya parampara (Braj/oral) is replaced by *colonial* service (English/Hindi/written).
- Step 4: Analyze the poetic form: The poem is *written* in Khari Boli (the language of the colonizer/modernity) but *populated* by Braj words (the language of the colonized/past).
- Step 5: Judge the statement: The statement is **defended**. The friction *between* the matrix language (Khari Boli) and the embedded lexicon (Braj) *enacts* the political tension. The poem does not just *talk about* language loss; its very syntax *performs* the colonization of the vernacular by the standard.

ANSWER: The statement is thoroughly defensible. The poem is written in the language of the "victor" (Khari Boli/Hindi) but its soul resides in the "vanquished" (Braj). The line "Hkk"kk esa >kj[kaMhiu" reclaims the "rustic" as aesthetic ideal. The reference to "firk vkSj pkpk f'k{kd" losing their traditional role to "fu;fer vè;;u" maps the linguistic shift onto economic survival. Every Braj word in the text ('vkcks&gok', 'BaMh', 'ckgq') acts as a resistant kernel inside the Khari Boli shell. The poem's structure *is* the argument: a modern Hindi poem that can only speak its deepest truth in a "dialect" the modern education system tried to erase. The "site of political argument" is the code-switching itself.

DIFFICULTY: hard