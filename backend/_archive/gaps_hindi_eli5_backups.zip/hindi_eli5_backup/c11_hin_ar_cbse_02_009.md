## DEFINITION
Irony in "फेंकू उल्हनिहु" is the contrast between appearance and reality where Phenku's mastery of basket-weaving stands in sharp opposition to his own empty, broken life. Symbolism operates through the दउरा (basket) and टोकरी which represent not just his craft but the fragile containers of human dignity, tradition, and economic survival that can neither hold nor protect what matters most.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
Student can identify at least two distinct types of irony (situational, dramatic, verbal) in the story with textual evidence, explain how the basket functions as a multi-layered symbol across three different scenes, and write a structured analytical paragraph connecting both devices to the story's central theme of artisan marginalization.

## SCOPE_BOUNDARY
This node covers irony and symbolism exclusively within Nirmal Verma's "फेंकू उल्हनिहु" from Aroh Chapter 2. It does NOT cover other literary devices (metaphor, imagery - covered in node 008), general definitions without textual application, or comparative analysis with other chapters.

## WALKTHROUGH
Imagine you're watching a master carpenter build exquisite furniture for wealthy clients while sitting on a broken stool himself - that's the living irony of Phenku Ulhnihu. Begin by re-reading the three key dialogue exchanges: Phenku with the woodcutter (लकड़हारा), with the narrator about basket prices, and the final scene where he refuses the narrator's charity. In each, ask: what does Phenku say vs what is actually true? Then trace the basket (दउरा/टोकरी) through the story - first as craft object, then as metaphor for his body, finally as symbol of a dying tradition. The key insight: Verma uses irony not to mock Phenku but to expose how society consumes artisan skill while discarding the artisan.

## DIAGNOSTIC_QUESTION_1
Define situational irony and give one example from "फेंकू उल्हनिहु" where Phenku's words or situation create this effect.

## DIAGNOSTIC_ANSWER_1
Situational irony occurs when the outcome is opposite to what is expected or appropriate. In the story, Phenku is a master basket-weaver whose whole identity is making containers, yet his own life holds nothing - no savings, no security, no future. A wrong answer (e.g., "irony is when someone lies") reveals confusion between verbal irony and situational irony, and inability to distinguish literary device from character trait.

## DIAGNOSTIC_QUESTION_2
The narrator says: "फेंकू उल्हनिहु को टोकरी बनाने का बेढ़ा नहीं, कोई नई बारीक कला आ गई हो जैसे।" Explain why this observation contains dramatic irony.

## DIAGNOSTIC_ANSWER_2
Dramatic irony exists because the narrator admires Phenku's skill as "delicate art" while the reader knows this "art" is born of desperate poverty and physical degradation - Phenku's fingers are ruined, his body bent. The narrator's aesthetic distance creates the irony. A wrong answer focusing only on "narrator doesn't know Phenku is poor" misses that the narrator DOES see his condition but frames it as artistry, creating the gap between perception and reality.

## DIAGNOSTIC_QUESTION_3
In the final scene, Phenku refuses the narrator's offer of money saying: "रखे की रखी ही बड़ी फाँक होती है।" Identify the type of irony here and explain how it functions differently from the earlier examples.

## DIAGNOSTIC_ANSWER_3
This is verbal irony - Phenku says "savings are the biggest savings" (literal meaning: hoarding is best) but means the opposite: that hoarding money destroys human connection. Unlike situational irony (which depends on circumstances), this is a conscious rhetorical choice where Phenku weaponizes language to reject charity. A wrong answer calling it "sarcasm" misses that sarcasm intends to wound; Phenku's irony protects his dignity.

## DIAGNOSTIC_QUESTION_4
Trace the symbol of the दउरा (large basket) through three scenes: (a) when Phenku makes it for the woodcutter, (b) when the narrator observes Phenku's own broken दउरा, (c) the final image of empty baskets. How does its symbolic meaning shift?

## DIAGNOSTIC_ANSWER_4
(a) For the woodcutter, the दउरा is a functional tool of labor - symbol of honest work. (b) Phenku's own broken दउरा symbolizes his body: once strong container, now failing vessel that cannot hold his own life. (c) Empty baskets at the end symbolize a tradition emptied of social value - containers with nothing to contain. A wrong answer listing only physical descriptions misses the progressive semantic shift from utility → body → cultural erasure.

## DIAGNOSTIC_QUESTION_5
Evaluate this interpretation: "The story uses irony to make us pity Phenku, and symbolism to make us admire his craft." Defend or refute with textual evidence.

## DIAGNOSTIC_ANSWER_5
Refute. Verma's irony refuses pity - Phenku's verbal irony ("रखे की रखी...") and situational irony (master craftsman with nothing) demand respect for his agency, not pity. The basket symbolism doesn't romanticize craft; the broken दउरा and empty final baskets show craft's collapse under economic violence. A wrong answer agreeing reveals confusion between emotional response (pity/admiration) and literary function (critique/exposure).

## DIAGNOSTIC_QUESTION_6
Write a 4-line poetic response from Phenku's perspective using the basket as central symbol, incorporating one ironic twist that reflects his voice in the story.

## DIAGNOSTIC_ANSWER_6
Sample criteria: Must use basket imagery (weave, rim, handle, empty space), reflect Phenku's vernacular dignity (not literary Hindi), and end with ironic reversal (e.g., "मैं टोकरी बुनता हूँ / ताकि दुनिया भरे / मेरी टोकरी ही खाली रह जाए / यही मेरी कारीगरी का फल"). A poor answer uses generic poverty tropes, lacks ironic structure, or writes in polished Hindi rather than Phenku's voice.

## COMMON_MISCONCEPTION
Students confuse Phenku's verbal irony with simplicity or ignorance, reading "रखे की रखी ही बड़ी फाँक होती है" as naive folk wisdom rather than a sophisticated rhetorical rejection of capitalist value systems. They also treat the basket as a static symbol of "tradition" rather than tracking its dynamic semantic shift: from functional object → extension of Phenku's body → emblem of a tradition society has hollowed out. This happens because students search for "symbols = universal meanings" instead of "symbols = context-dependent meaning-making."

## ON_FAILURE
Step 1: Have student re-read only the three dialogue scenes aloud, marking every instance where Phenku's words contradict his visible reality. Step 2: Create a two-column table: "What Phenku says/does" vs "What is actually true" - this makes situational/verbal irony visible. Step 3: Draw the basket three times - once whole (for woodcutter), once broken (Phenku's), once empty (ending) - labeling each with its specific symbolic function in that scene only. Step 4: Practice writing one analytical sentence using the template: "Verma uses [device] in [scene] to show that [theme], evidenced by [quote]."

## BUILDS_ON
c11_hin_ar_cbse_02_008 (Literary Devices: Imagery and Metaphor) - students must already identify concrete images before analyzing their ironic/symbolic function.

## LEADS_TO
c11_hin_ar_cbse_02_013 (Critical Thinking: Analysis and Interpretation) - irony/symbolism analysis provides the evidentiary base for higher-order critical arguments.

## PREREQUISITE_NODE_IDS
c11_hin_ar_cbse_02_002, c11_hin_ar_cbse_02_004, c11_hin_ar_cbse_02_008, c11_hin_ar_cbse_02_007

## PREREQUISITE_REASONS
c11_hin_ar_cbse_02_002: Plot and narrative structure knowledge needed to locate irony/symbolism in correct narrative moments
c11_hin_ar_cbse_02_004: Protagonist analysis essential - Phenku's character IS the site where irony and symbolism operate
c11_hin_ar_cbse_02_008: Imagery and metaphor skills transfer directly - symbolism extends metaphor; irony often works through imagery
c11_hin_ar_cbse_02_007: Secondary themes are subsidiary central ideas that run parallel to the primary theme in a... की समझ आवश्यक है, क्योंकि यह नोड (Irony in "फेंकू उल्हनिहु" is the contrast between appearance and reality where Phenku's ma...) इसी आधार पर आगे बढ़ता है।  

## FORWARD_NODE_IDS
c11_hin_ar_cbse_02_012, c11_hin_ar_cbse_02_013, c11_hin_ar_cbse_02_014, c11_hin_ar_cbse_02_015, c12_hin_a_cbse_01_009, c12_hin_a_cbse_05_009, c12_hin_a_cbse_10_009, c12_hin_al_cbse_01_009, c12_hin_ar_cbse_01_009, c12_hin_ar_cbse_02_009, c12_hin_ar_cbse_03_009, c12_hin_ar_cbse_05_009, c12_hin_ar_cbse_09_009, c12_hin_ar_cbse_12_009, c11_hin_ar_cbse_02_010

## FORWARD_REASONS
c11_hin_ar_cbse_02_012: Comprehension questions require identifying and explaining irony/symbolism as textual evidence
c11_hin_ar_cbse_02_013: Critical thinking builds arguments on the foundation of device analysis done here
c11_hin_ar_cbse_02_014: Writing skills tasks (analytical paragraphs, character sketches) demand structured use of these devices
c11_hin_ar_cbse_02_015: Irony/symbolism (fe;k¡'s "illiterate" wisdom vs. professor's "learned" folly) is the primary engine of textual tension.  
c12_hin_a_cbse_01_009: अगला तार्किक चरण: Irony (विरोधाभास/व्यंग्य) in poetry is a literary device where the intended meaning of words or situ... इस नोड की अवधारणाओं को सीधे उपयोग/विस्तारित करता है।  
c12_hin_a_cbse_05_009: अगला तार्किक चरण: Irony is a literary device where the intended meaning of words or a situation is opposite to their l... इस नोड की अवधारणाओं को सीधे उपयोग/विस्तारित करता है।  
c12_hin_a_cbse_10_009: Chapter 2 applied irony/symbolism to a different genre (poetry) — shows device versatility across forms.  
c12_hin_al_cbse_01_009: Class 11 Antra Chapter 2 Irony and Symbolism node reinforces the concepts with another story.  
c12_hin_ar_cbse_01_009: Exposure to irony/symbolism in a different poetic voice (Nirala/Muktibodh contrast) builds comparative lens.  
c12_hin_ar_cbse_02_009: Reinforces the same devices in a different Class 11 chapter, ensuring exposure to varied contexts.  
c12_hin_ar_cbse_03_009: Reinforces the device definitions across multiple chapters; ensures the student has seen varied examples before tackling these complex poems.  
c12_hin_ar_cbse_05_009: अगला तार्किक चरण: Irony (व्यंग्य/विडंबना) is a literary device where the intended meaning of words or situations is op... इस नोड की अवधारणाओं को सीधे उपयोग/विस्तारित करता है।  
c12_hin_ar_cbse_09_009: Reinforces identification of irony types in different textual contexts.  
c12_hin_ar_cbse_12_009: अगला तार्किक चरण: Irony in this story is the contrast between appearance and reality — where the wealthy waste water c... इस नोड की अवधारणाओं को सीधे उपयोग/विस्तारित करता है।  
c11_hin_ar_cbse_02_010: PROBLEM: Combine vocabulary analysis with irony (c11_hin_ar_cbse_02_009). The word 'ctk I+kQjekuk' (glossary: 'Bhd ccr dguk' — to speak well/pleasantly) appears on page 27 when Fele says: "  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
none

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_02_002 -> c11_hin_ar_cbse_02_009 -> c11_hin_ar_cbse_02_013

## THIS_FORMULA
Irony Analysis Formula: Identify Expectation (from text/context) → Identify Reality (from text) → Name Gap Type (situational/verbal/dramatic) → Explain Thematic Function. Symbolism Tracking Formula: Object → Scene 1 Meaning → Scene 2 Meaning → Scene 3 Meaning → Synthesize Semantic Shift → Link to Theme.

## FORMULA_VARIABLES
Expectation: What character/reader anticipates based on surface information; Reality: What text reveals as actual condition; Gap Type: Classification of irony (situational/verbal/dramatic); Thematic Function: What the gap exposes about society/character; Object: Concrete element (basket, body, money); Scene Meaning: Context-specific symbolic value; Semantic Shift: How meaning evolves across narrative; Theme: Central concern (artisan marginalization, dignity vs economics)

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
analytical

## CROSS_SUBJECT
c11_history_industrialization | The story's depiction of artisan displacement mirrors historical impact of colonial industrial policy on traditional crafts - irony of skilled labor becoming obsolete
c11_economics_informal_sector | Phenku embodies informal sector vulnerability: no social security, skill not recognized as "productive" - verbal irony exposes gap between economic theory and lived reality

## PREREQ_CONCEPT
Students must understand that literary devices in senior secondary are not decorative but structural - they organize the story's meaning. Irony and symbolism in Verma function as critique mechanisms, not embellishments.

## PREREQ_BEFORE
Student can locate three key scenes in the story (woodcutter dialogue, narrator's observation, final refusal) and describe Phenku's physical/economic condition in each.

## PREREQ_STUCK
If stuck, review c11_hin_ar_cbse_02_004 (Character Analysis: Protagonist) for Phenku's material conditions, and c11_hin_ar_cbse_02_002 (Plot) for scene sequencing.

## WORKED_EXAMPLE_1
PROBLEM: Analyze the situational irony in the woodcutter scene where Phenku makes a दउरा for the woodcutter but his own दउरा is broken. Write a structured analytical paragraph (PEEL format).

STEPS:
- Step 1: Identify the two parallel situations - Phenku crafting a new, strong दउरा for the woodcutter vs his own broken दउरा leaning against the wall
- Step 2: State the expectation: a master craftsman's own tools should be the best, showcasing his skill
- Step 3: State the reality: Phenku's personal दउरा is "टूटी हुई" (broken), "पुरानी" (old), held together by wire - the opposite of expectation
- Step 4: Classify as situational irony - outcome (broken own tool) contradicts expectation (master's own tool should be finest)
- Step 5: Explain thematic function: This irony exposes how artisan labor serves others' needs while the artisan's own life deteriorates - the दउरा he makes holds the woodcutter's livelihood; his own holds nothing
- Step 6: Draft PEEL paragraph: Point (situational irony reveals exploitation), Evidence (quotes about both baskets), Explanation (contrast structure), Link (connects to theme of invisible labor)

REASONING: This example models the full analytical chain from textual detail to thematic claim, using the PEEL structure required for board answers. The six steps ensure students don't jump to theme without grounding in specific irony mechanics.

ANSWER: Verma deploys situational irony in the woodcutter scene to expose the structural exploitation of artisan labor. Phenku weaves a "मजबूत दउरा" (sturdy basket) for the woodcutter - "साँस-साँस में बुनी गई" (woven breath by breath) - while his own दउरा is "टूटी हुई," "पुरानी," "तार से बँधी हुई" (broken, old, bound with wire). The expectation that a master's own tools reflect his mastery is violently inverted: the basket that holds another man's livelihood is whole; the basket that should hold Phenku's dignity is fractured. This irony does not merely characterize Phenku - it indicts an economy that consumes artisan skill while discarding the artisan. The broken दउरा becomes symbol of a body and life that society has used but not sustained.

## WORKED_EXAMPLE_2
PROBLEM: Explain how the symbol of the basket shifts from "container of labor" to "container of body" to "container of tradition" across three scenes. Provide textual evidence for each shift.

STEPS:
- Step 1: Scene 1 (woodcutter commission) - basket as container of labor: "दउरा बनाना कोई बेढ़ा काम नहीं" - it holds wood, grass, produce; its value is use-value for another's work
- Step 2: Scene 2 (narrator's observation) - basket as container of body: "उसकी उँगलियाँ... टोकरी की तरह मुड़ गई थीं" (fingers bent like basket) - Phenku's body has become the basket, shaped by the same repetitive labor
- Step 3: Scene 3 (ending) - basket as container of tradition: empty baskets "खाली पड़े रह जाते हैं" - no wood, no grass, no next generation to use them; tradition emptied of social function
- Step 4: Synthesize the shift: utility → embodiment → obsolescence. Each stage narrows the basket's capacity to hold meaning
- Step 5: Connect to Verma's critique: the symbol's evolution mirrors the artisan's trajectory from productive member to embodied skill to discarded relic
- Step 6: Write analytical response using "symbolic trajectory" terminology expected in board exams

REASONING: This example teaches symbol tracking as dynamic process, not static identification. The three-stage structure mirrors board exam questions asking "trace the development of symbol X." Step 5's synthesis is the differentiator for high marks.

ANSWER: The दउरा/टोकरी undergoes a three-stage symbolic trajectory in Verma's story. Stage 1 (woodcutter scene): Functional container - "दउरा बनाना... बारीक कला" - it holds the woodcutter's produce, representing labor's tangible output. Stage 2 (narrator's close observation): Embodied container - "उसकी उँगलियाँ टोकरी की तरह मुड़ गई थीं" / "पीठ टोकरी की शक्ल में झुक गई" - Phenku's body has internalized the basket's form; he IS the container, his spine the rim, fingers the weave. Stage 3 (final scene): Empty container - "खाली दउरे... खाली पड़े रह जाते हैं" - no produce, no apprentice hands, no social need. The semantic shift: use-value → body-memory → cultural vacancy. Verma uses this trajectory to show how tradition dies not from lack of skill but from lack of social container - the basket holds nothing because society has nothing left to put in it.

## WORKED_EXAMPLE_3
PROBLEM: The narrator offers Phenku money; Phenku refuses with "रखे की रखी ही बड़ी फाँक होती है." Analyze how verbal irony, situational irony, and symbolism operate simultaneously in this single moment.

STEPS:
- Step 1: Verbal irony layer - Phenku says "savings are the biggest savings" (literal: hoarding preserves) but performs the opposite: refusing money that would be savings. His words enact anti-hoarding.
- Step 2: Situational irony layer - A destitute artisan refuses money. Expectation: poverty accepts charity. Reality: dignity refuses it. The irony exposes that poverty ≠ lack of agency.
- Step 3: Symbolism layer - Money offered = paper currency (abstract, state-backed). Basket = bodily skill (concrete, self-made). Phenku chooses the basket's logic: "रखे की रखी" refers to what his hands make, not what state prints.
- Step 4: Synthesis - The three devices converge: verbal irony performs dignity, situational irony exposes structural violence, symbolism contrasts two value systems (market vs craft)
- Step 5: Board-exam answer structure: Opening thesis sentence → Device 1 with quote → Device 2 with quote → Device 3 with quote → Convergence analysis → Thematic conclusion
- Step 6: Check against marking scheme: identifies all three devices, uses textual evidence, explains interaction, links to theme

REASONING: This is the highest-order task - analyzing device interaction in a single dense moment. Board exams frequently ask "how does the writer use language to convey..." requiring multi-device analysis. The six steps model the complexity management needed.

ANSWER: In the climactic refusal, Verma compresses three devices into one utterance. Verbal irony: "रखे की रखी ही बड़ी फाँक होती है" - literally "what is kept is the biggest saving" but pragmatically "I keep my dignity by not keeping your money." The proverb form masks a radical rejection: true saving is not hoarding currency but preserving self-respect. Situational irony: A starving artisan refuses cash - the expected economic actor behaves anti-economically. This irony reveals that Phenku operates on a non-market logic where agency > survival. Symbolism: The narrator's note (कागज़ का नोट) vs Phenku's basket (हाथ की बुनी टोकरी). Paper money is abstract, alien, state-guaranteed; the basket is concrete, bodily, self-guaranteed. Phenku's refusal chooses the basket's epistemology - value resides in what hands make, not what paper states. The three devices converge: verbal irony speaks the basket's logic, situational irony enacts it, symbolism grounds it. Together they articulate Verma's central argument: artisan dignity survives not through economic inclusion but through epistemic refusal.

## COMPETENCY_QUESTION_1
QUESTION: A Class 11 student writes: "The irony in the story is that Phenku is poor but happy." Using your knowledge of irony types and the story's actual textual evidence, explain why this statement is a misreading and rewrite it as a correct analytical claim.

COMPETENCY: Critical evaluation of peer interpretation / analytical writing correction

STEPS:
- Step 1: Identify the error - "poor but happy" imposes a binary (poverty vs happiness) that the story never supports; Phenku is neither simply poor nor happy - he is dignified, angry, skilled, abandoned
- Step 2: Identify missing irony analysis - the statement names "irony" but describes neither expectation/reality gap nor any specific type
- Step 3: Locate correct textual evidence - Phenku's verbal irony ("रखे की रखी"), situational irony (master craftsman with broken tools), dramatic irony (narrator's aestheticizing gaze)
- Step 4: Rewrite as analytical claim: "Verma uses situational irony (master craftsman owning broken tools) and verbal irony (Phenku's refusal of charity framed as wisdom) to expose how economic marginalization coexists with epistemic sovereignty - Phenku's poverty is real but his agency remains intact."

ANSWER: The student's claim fails on three counts: (1) It reduces a complex character to a binary trait ("happy") unsupported by text - Phenku shows pride, bitterness, weariness, not happiness. (2) It labels "irony" without identifying any expectation/reality gap - poverty/happiness is contrast, not irony. (3) It misses Verma's political purpose: the irony structures a critique of how society consumes artisans. Corrected claim: "Verma deploys situational irony (Phenku's broken दउरा vs the sturdy one he makes for others) and verbal irony ('रखे की रखी' as dignity-performance) to reveal that artisan marginalization produces not passive victims but subjects who weaponize language and craft to retain sovereignty over their labor's meaning."

DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: Compare the symbolic function of the basket in "फेंकू उल्हनिहु" with the symbol of the loom in any other Indian literary text you have studied (e.g., Premchand's "बूढ़ी काकी" - no loom; suggest "कफ़न" - no loom; better: Tagore's "The Postmaster" - no; actually: any text with weaver/artisan symbol). Construct a comparative analytical paragraph showing how both symbols operate as sites where labor, body, and tradition intersect.

COMPETENCY: Comparative literary analysis / intertextual synthesis

STEPS:
- Step 1: Select appropriate comparison text - e.g., "दुःख का अधिकार" (Muktibodh) or folk tradition of Kabir's weaving metaphors, or a prescribed text like "नमक का दरोगा" (no). Better: reference the Class 10 text "बड़े भाई साहब" (no). Use a known weaver text: "कबीर के दोहे" (weaving as spiritual practice) or "गोदान" (Hori's plough - different). Accept any valid artisan symbol from curriculum.
- Step 2: Establish Phenku's basket symbolic triad: labor-container, body-extension, tradition-remnant
- Step 3: Establish comparison symbol's triad in the other text
- Step 4: Identify convergence: both symbols materialize the artisan's body-labor unity
- Step 5: Identify divergence: Verma's basket shows tradition's collapse; comparison symbol may show continuity/resistance/spiritual transcendence
- Step 6: Write comparative paragraph with clear topic sentence, evidence from both texts, analytical connection, thematic conclusion

ANSWER: [Sample using Kabir's weaving metaphor from Class 10/11 Hindi curriculum] In "फेंकू उल्हनिहु," the दउरा traces a trajectory from functional tool to embodied skill to empty relic - the basket's emptiness at the end signals a tradition severed from social reproduction. In Kabir's "झीनी झीनी बीनी चदरिया," the woven चदरिया (sheet) moves oppositely: from raw cotton (unformed self) through weaving (spiritual practice) to finished garment (liberated consciousness). Both symbols materialize the artisan's labor-body unity - Phenku's bent spine mirrors the basket's rim; Kabir's "सुरति" (awareness) is the weaver's shuttle. But they diverge historically: Verma's basket bears the fracture of colonial modernity - "खाली दउरे" with no next generation; Kabir's चदरिया bears the continuity of bhakti tradition - "सुरति से ताना बाना" woven across generations. Where Verma's symbol exposes structural violence, Kabir's symbol enacts spiritual resistance. Together they frame the artisan's craft as both vulnerable to and capable of transcending historical rupture.

DIFFICULTY: hard