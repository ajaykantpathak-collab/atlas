## DEFINITION
Writing skills based on the chapter "Hkkjrh; xkf;dkvksa esa cstksM+yrk" refers to the ability to construct structured, evidence-based responses that analyze the evolution, characteristics, and cultural significance of Indian folk and classical arts (painting, music, dance) using textual evidence, comparative reasoning, and thematic synthesis appropriate for CBSE Class 11 board examination standards.

## COGNITIVE_LEVEL
apply

## MASTERY_CRITERIA
The student must independently write a 150-200 word analytical answer comparing folk and classical art forms using the PEEL structure (Point, Evidence, Explanation, Link), incorporating at least three specific textual references from the chapter, and demonstrating the interrelationship between art, geography, rituals, and community life.

## SCOPE_BOUNDARY
This node covers writing analytical and comparative answers on Indian art forms (painting, music, dance) as presented in the NCERT Vitan Chapter 4. It does NOT cover creative writing, letter writing, or unrelated grammar exercises. It focuses exclusively on exam-oriented answer construction using chapter content.

## WALKTHROUGH
Imagine you're sitting in the exam hall and the question asks: "Compare the origins and development of folk painting and classical painting in India using examples from the text." Most students freeze because they know the facts but don't know how to *structure* the comparison. Start by identifying the two categories being compared (folk vs classical). Next, hunt for three specific textual anchors: cave paintings for folk origins, royal patronage for classical development, and the unbroken continuity mentioned in the text. Then apply the PEEL framework: make a clear comparative point, quote or paraphrase the evidence, explain what it reveals about social context, and link back to the theme of art reflecting life. The key insight is that board examiners reward *structured argumentation* over fact-listing — every fact must serve a comparative claim.

## DIAGNOSTIC_QUESTION_1
Define the PEEL structure for answer writing and state its four components in the correct order.

## DIAGNOSTIC_ANSWER_1
PEEL stands for Point, Evidence, Explanation, Link. Point = the main claim or topic sentence. Evidence = textual reference (quote or paraphrase). Explanation = analysis of how evidence supports the point. Link = concluding sentence connecting back to the question/theme. A wrong answer (e.g., listing components out of order or confusing Evidence with Explanation) reveals the student lacks a procedural framework for constructing analytical paragraphs, leading to disorganized, narrative-style answers that lose marks for coherence.

## DIAGNOSTIC_QUESTION_2
A student writes: "Folk paintings are old and classical paintings are also old. Both use natural colors. Folk paintings are on walls, classical on paper." Identify two specific weaknesses in this answer relative to board exam expectations.

## DIAGNOSTIC_ANSWER_2
Weakness 1: The answer lists isolated facts without a comparative *argument* — no Point framing the comparison (e.g., "While both traditions are ancient, their patronage systems differed fundamentally"). Weakness 2: Evidence is vague ("old", "natural colors") rather than text-specific (e.g., "Bhimbetka cave paintings vs. Mughal miniatures under royal ateliers"). A student making this error treats the question as a recall task rather than an analytical synthesis task, missing the "analyze/evaluate" command words in board questions.

## DIAGNOSTIC_QUESTION_3
Using the chapter content, construct a PEEL paragraph answering: "How does the text establish the connection between geography and the evolution of folk painting styles?" Provide the complete paragraph with labeled PEEL components.

## DIAGNOSTIC_ANSWER_3
**Point:** Folk painting styles in India evolved directly from regional geographical materials and occupational rhythms. **Evidence:** The text states that rock paintings at Bhimbetka used natural pigments, while Mithila paintings originated on mud walls during rituals, and Rajasthani phad paintings used cloth scrolls suited to mobile communities. **Explanation:** These examples show that pigment availability (mineral colors in caves, vegetable dyes in plains), surface constraints (rock, wall, cloth), and lifestyle (settled agriculture vs. pastoral mobility) shaped distinct visual languages — not aesthetic choice alone. **Link:** Thus, geography acts as both canvas and co-author of folk art, a pattern the chapter reinforces across painting, music, and dance forms. A weak answer would list examples without the causal "shaped by" logic in the Explanation step.

## DIAGNOSTIC_QUESTION_4
Compare how the chapter treats the *transmission* of classical music versus folk dance. Identify one structural similarity and one structural difference in their developmental trajectories as presented in the text.

## DIAGNOSTIC_ANSWER_4
Similarity: Both follow an oral guru-shishya parampara (teacher-disciple tradition) for transmission — classical music through formal gharanas, folk dance through community participation. Difference: Classical music underwent early codification into written treatises (Natya Shastra, Sangeet Ratnakar) creating fixed frameworks, while folk dance remained fluid, adapting to seasonal/ritual cycles without textual standardization. A wrong answer conflating "both are oral" as the *only* point misses the critical divergence: codification vs. flexibility — a comparative nuance the chapter explicitly develops.

## DIAGNOSTIC_QUESTION_5
Evaluate this claim using chapter evidence: "The distinction between folk and classical arts in India is rigid and absolute." Defend or refute in 3-4 sentences with textual support.

## DIAGNOSTIC_ANSWER_5
Refute. The text explicitly states: "'kkL=kh; vkSj yksddykvksa osQ chp dHkh u •Re gksus okyk laokn gh budh rkdr gS" (the unbroken dialogue between classical and folk is their beauty). Evidence: Classical dance (Bharatanatyam) draws from folk forms like Sadir; classical ragas incorporate folk tunes; miniature paintings depict folk festivals. The chapter frames the relationship as a continuum where classical forms *emerge from* and *return to* folk roots. A student agreeing with the claim misreads the central thesis of mutual nourishment ("laokn") that the author builds across all three art forms.

## DIAGNOSTIC_QUESTION_6
Write a 100-word museum placard for an exhibit titled "From Cave to Court: The Journey of Indian Painting" using exactly three chapter references and the PEEL structure implicitly (without labels).

## DIAGNOSTIC_ANSWER_6
A strong placard opens with a clear thesis (Point): "Indian painting traces a continuum from Bhimbetka's prehistoric rock shelters to Mughal ateliers and Mithila's ritual walls." It embeds Evidence: "Natural mineral pigments on sandstone (Bhimbetka), vegetable dyes on mud (Madhubani), and Persian-influenced miniatures on paper (Mughal courts)." The Explanation weaves these: "Each shift reflects changing patrons — community rituals, royal courts, temple traditions — yet all retain the narrative impulse to record life." The Link closes: "This exhibit reveals not replacement, but layering: folk roots sustaining classical branches." Weak answers list styles chronologically without the "continuum" argument.

## COMMON_MISCONCEPTION
Students believe "writing skills" for literature chapters means *summarizing* the text in their own words. They write: "The chapter talks about painting, then music, then dance. Painting has folk and classical types..." This narrative retelling earns near-zero marks in board exams because the question demands *analysis* (compare, evaluate, trace, examine), not *narration*. The error stems from Class 10 habits where "explain the chapter" sufficed; Class 11 requires *argument-driven* writing where every sentence advances a claim supported by evidence.

## ON_FAILURE
Step 1: Show the student a side-by-side comparison — a 2/5 summary answer vs a 5/5 analytical answer on the *same* question — and ask them to identify three differences in structure (not content). Step 2: Give them a "PEEL template" with sentence starters: "The text suggests that... [Point] For instance... [Evidence] This reveals... [Explanation] Therefore... [Link]". Step 3: Practice with one sub-topic (e.g., "materials in folk painting") — have them write four sentences using the template, then expand to a full paragraph. Step 4: Provide a checklist: "Does every paragraph have a comparative verb (differs, parallels, evolves from)?" until internalized.

## BUILDS_ON
c11_hin_v_cbse_04_012 (Comprehension: Literal and Inferential Questions) — students must first extract accurate textual evidence before they can structure it into arguments.

## LEADS_TO
c11_hin_v_cbse_04_015 (Speaking and Listening: Discussion Points) — the analytical frameworks built here (comparison, evidence-use, thematic linking) become the scaffolding for oral presentations and debates.

## PREREQUISITE_NODE_IDS
c11_hin_v_cbse_04_001, c11_hin_v_cbse_04_002, c11_hin_v_cbse_04_006, c11_hin_v_cbse_04_007, c11_hin_v_cbse_04_012, c11_hin_v_cbse_04_013, c11_hin_v_cbse_04_005, c11_hin_v_cbse_04_008, c11_hin_v_cbse_04_009, c11_hin_v_cbse_04_011

## PREREQUISITE_REASONS
c11_hin_v_cbse_04_001: Provides historical/geographical context needed to ground comparative claims in writing.
c11_hin_v_cbse_04_002: Narrative structure awareness helps students organize answers chronologically or thematically.
c11_hin_v_cbse_04_006: Primary theme (art-life continuum) is the central thesis around which all analytical answers must cohere.
c11_hin_v_cbse_04_007: Secondary themes (patronage, ritual, geography) provide the sub-arguments for multi-point answers.
c11_hin_v_cbse_04_012: Literal/inferential comprehension skills are the evidence-mining prerequisite for PEEL's Evidence step.
c11_hin_v_cbse_04_013: Critical thinking (analysis/interpretation) directly feeds the Explanation and Link steps of PEEL.
c11_hin_v_cbse_04_005: Writing tasks may ask to profile a supporting character or compare two.  
c11_hin_v_cbse_04_008: Writing skills (analytical paragraph, essay) require embedding device analysis using PEEL structure taught here.  
c11_hin_v_cbse_04_009: Writing Skills (analytical essay, critical appreciation) demand the structured argumentation (PEEL) practiced in this node's worked examples.  
c11_hin_v_cbse_04_011: Writing tasks (e.g., "explain the guru-shishya parampara in your own words") demand replication of the chapter's expository register — samasa density, formal vocabulary, non-finite subordination.  

## FORWARD_NODE_IDS
c11_hin_v_cbse_04_015, c12_hin_a_cbse_05_014

## FORWARD_REASONS
c11_hin_v_cbse_04_015: Speaking/listening tasks require the same evidence-based argumentation structures (claim → support → reasoning) developed in writing, now transferred to oral mode.
c12_hin_a_cbse_05_014: अगला तार्किक चरण: Writing Skills based on the chapter refers to the ability to compose structured, evidence-based resp... इस नोड की अवधारणाओं को सीधे उपयोग/विस्तारित करता है।  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
none

## CHAIN_DESCRIPTION
c11_hin_v_cbse_04_012 -> c11_hin_v_cbse_04_014 -> c11_hin_v_cbse_04_015

## THIS_FORMULA
PEEL Structure: Point (Comparative Claim) → Evidence (Textual Reference) → Explanation (Analytical Reasoning) → Link (Thematic Synthesis)

## FORMULA_VARIABLES
Point: A clear, arguable topic sentence answering the specific command word (compare, trace, evaluate). Evidence: Specific chapter reference — quote, paraphrase, or data point (e.g., "Bhimbetka cave paintings," "Natya Shastra codification"). Explanation: 2-3 sentences analyzing *how* the evidence proves the point — causal, contrastive, or functional reasoning. Link: One sentence connecting the paragraph's argument to the chapter's central theme (art-life continuum, folk-classical dialogue, geography-art nexus).

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
linguistic

## CROSS_SUBJECT
c11_history_ancient_india | The chapter's treatment of Bhimbetka rock art, Mughal miniatures, and temple sculpture parallels History's coverage of material culture as historical evidence — both require students to interpret visual/artistic sources as records of social structure, patronage, and belief systems.
c11_geography_human_geography | The explicit geography-art linkage (materials, climate, occupation shaping folk forms) mirrors Geography's core concept of environmental determinism vs. possibilism in cultural landscapes — students apply spatial reasoning to artistic evolution.

## PREREQ_CONCEPT
Evidence-based analytical writing using the PEEL paragraph structure, grounded in chapter-specific content knowledge of Indian folk and classical art forms.

## PREREQ_BEFORE
Student can accurately recall three folk and three classical art forms from the chapter with their regional associations, and can distinguish literal comprehension (what the text says) from inferential reading (what the text implies about cultural processes).

## PREREQ_STUCK
Review c11_hin_v_cbse_04_012 (Comprehension) for evidence-extraction practice and c11_hin_v_cbse_04_013 (Critical Thinking) for analysis modeling — specifically the "folk-classical dialogue" interpretive framework.

## WORKED_EXAMPLE_1
PROBLEM: Board-style question: "Trace the evolution of Indian painting from prehistoric rock art to classical miniatures, highlighting the changing role of patronage. Write your answer in 150 words using the PEEL structure."

STEPS:
- Step 1: Deconstruct the prompt — command word "trace" requires chronological + causal structure; key variables: painting forms, patronage shift, 150-word limit.
- Step 2: Select three textual anchors from chapter — (a) Bhimbetka cave paintings (community/ritual patronage), (b) Ajanta murals (Buddhist monastic/royal patronage), (c) Mughal/Rajput miniatures (court atelier patronage).
- Step 3: Draft Point sentence: "Indian painting evolved from community-owned ritual expression to court-controlled aesthetic production, driven by shifting patronage structures."
- Step 4: Build Evidence-Explanation pairs for each era — Bhimbetka: natural pigments on rock, anonymous artists serving collective memory; Ajanta: monastic sponsorship enabling narrative sophistication; Mughal ateliers: imperial workshops standardizing style under named masters.
- Step 5: Craft Link: "This trajectory reveals art's negotiation between communal identity and elite taste — a tension the chapter shows persisting in modern folk-classical dialogue."
- Step 6: Word-count check and PEEL verification — each era gets one PEEL unit; total ~150 words; comparative verbs (shifted, enabled, standardized) drive analysis.

REASONING: The chronological "trace" command demands a developmental argument, not a list. PEEL forces each era to contribute to the patronage thesis. Textual anchors prevent vague generalizations. The Link returns to the chapter's central "continuum" idea, satisfying the "highlighting" requirement.

ANSWER: Indian painting evolved from community-owned ritual expression to court-controlled aesthetic production, driven by shifting patronage structures. At Bhimbetka, prehistoric communities used mineral pigments on sandstone to record collective hunts and dances — anonymous artists serving shared memory, not individual fame. Buddhist monastic and royal patronage at Ajanta (2nd century BCE–6th century CE) transformed walls into sophisticated narrative cycles (Jataka tales), enabling technical advances in perspective and emotion. Mughal and Rajput ateliers (16th–18th century) institutionalized painting within imperial workshops: named masters (Basawan, Daswanth), standardized pigments on paper, and Persian-influenced portraiture serving royal propaganda. This trajectory reveals art's negotiation between communal identity and elite taste — a tension the chapter shows persisting in modern folk-classical dialogue where Mithila's ritual walls coexist with gallery-recognized Madhubani.

## WORKED_EXAMPLE_2
PROBLEM: Improve this weak answer to: "Compare the relationship between music and language in classical vs. folk traditions." Weak answer: "Classical music uses Sanskrit and folk music uses local languages. Classical has strict rules, folk is free. Both use voice."

STEPS:
- Step 1: Diagnose weaknesses — no comparative thesis (Point), vague evidence ("Sanskrit", "local languages"), no analysis of *why* language matters (Explanation), no thematic Link.
- Step 2: Formulate a strong Point: "While both traditions unite sound and meaning, classical music subordinates language to raga grammar, whereas folk music lets linguistic rhythm drive melodic form."
- Step 3: Upgrade Evidence with chapter specifics — Classical: "Sangeet Ratnakar codifies svara and tala independent of lyrics; bandish texts are often secondary vehicles for raga exploration." Folk: "Pandavani narration in Chhattisgarhi dictates melodic contours; Baul songs in Bengali fuse dialect metaphors with ektara drone."
- Step 4: Deepen Explanation — Classical: "Sanskrit's phonetic precision serves raga's microtonal architecture; the text becomes a scaffold for improvisation." Folk: "Local language's speech-rhythms (matra, laya) generate the tune — melody *is* spoken poetry."
- Step 5: Craft Link to chapter theme: "This contrast mirrors the broader folk-classical dialectic: codification vs. spontaneity, text-as-tool vs. text-as-source."
- Step 6: Assemble into 120-word PEEL paragraph with clear signposting.

REASONING: The weak answer treats language as a label; the strong answer analyzes language as a *structuring principle* — exactly the inferential leap the chapter invites. PEEL ensures the comparison is mechanistic (how language *functions*), not taxonomic (what language *is*).

ANSWER: While both traditions unite sound and meaning, classical music subordinates language to raga grammar, whereas folk music lets linguistic rhythm drive melodic form. Classical treatises like Sangeet Ratnakar codify svara and tala as autonomous systems; bandish lyrics — often in Braj or Sanskrit — serve as vehicles for raga exposition, their phonetics chosen for tonal resonance over semantic weight. In contrast, folk forms like Chhattisgarh's Pandavani or Bengal's Baul songs derive melodic contour directly from Chhattisgarhi and Bengali speech-rhythms: the tune *is* the spoken verse, its matra and laya inseparable from dialect cadence. This contrast mirrors the broader folk-classical dialectic the chapter traces: codification versus spontaneity, text as scaffold versus text as source — a dialogue where each tradition continuously renews the other.

## WORKED_EXAMPLE_3
PROBLEM: Board competency question: "The chapter argues that Indian arts are 'living traditions' sustained by community participation. Evaluate this claim with reference to ANY TWO art forms (painting, music, dance), using at least four textual details. Structure as a mini-essay: Introduction (thesis), Two body paragraphs (PEEL each), Conclusion (synthesis)."

STEPS:
- Step 1: Unpack "living tradition" and "community participation" — thesis must take a position (support/qualify/refute) with nuance.
- Step 2: Select two art forms with richest community-evidence — Dance (folk: Garba, Bihu; classical: Bharatanatyam's devadasi-to-stage journey) and Painting (folk: Madhubani women's collectives; classical: miniature ateliers → modern revival).
- Step 3: Write Introduction (40 words): Thesis — "The chapter validates 'living tradition' but reveals community participation as dynamic negotiation, not static preservation — especially where classical institutionalization risks fossilization."
- Step 4: Body 1 (Dance) — Point: "Dance epitomizes the community-art lifeline." Evidence: "Garba's circular formation enacts village unity; Bharatanatyam's shift from temple devadasis to Kalakshetra's urban classrooms shows community redefinition." Explanation: "Ritual origin ensures survival, but new communities (diaspora, academies) reshape form — living means adapting." Link: "Thus dance communities are permeable, not fixed."
- Step 5: Body 2 (Painting) — Point: "Painting reveals community as both canvas and market." Evidence: "Mithila women painting kohbar on nuptial walls; today's Madhubani cooperatives selling to global collectors." Explanation: "Ritual function (community) expands into livelihood (market) — participation evolves from obligation to agency." Link: "Commercialization threatens authenticity but enables visibility."
- Step 6: Conclusion (30 words) — Synthesis: "Across forms, 'living' means the community-art contract is renegotiated each generation — the chapter's 'laokn' (dialogue) is the mechanism of survival."

REASONING: Mini-essay structure tests sustained argumentation. Two body paragraphs force cross-form synthesis. Four textual details ensure evidence density. The thesis must be evaluative ("dynamic negotiation") not descriptive. The conclusion's "renegotiation" concept elevates beyond summary to insight.

ANSWER: The chapter validates "living tradition" but reveals community participation as dynamic negotiation, not static preservation — especially where classical institutionalization risks fossilization. Dance epitomizes the community-art lifeline. Garba's circular formation enacts village unity through shared rhythm; Bharatanatyam's shift from temple devadasis to Kalakshetra's urban classrooms shows community redefinition across centuries. Ritual origin ensures survival, but new communities — diaspora networks, state academies — reshape form: living means adapting. Thus dance communities are permeable, not fixed. Painting reveals community as both canvas and market. Mithila women painting kohbar on nuptial walls embodied ritual duty; today's Madhubani cooperatives selling to global collectors transform participation into economic agency. Commercialization threatens authenticity but enables visibility — the community-art contract is renegotiated each generation. Across forms, "living" means this dialogue (laokn) between heritage and horizon is the mechanism of survival.

## COMPETENCY_QUESTION_1
QUESTION: A Class 11 student writes this answer to "Explain how geography shapes folk music instruments": "Folk instruments are made from local materials. For example, the ektara uses bamboo and gourd. The sarangi uses wood and goat skin. In mountains they use drums, in plains flutes. Geography decides the instrument." Identify THREE specific improvements needed to meet Class 11 board standards, and rewrite the answer as a single PEEL paragraph (80-100 words).

COMPETENCY: Analytical writing revision — diagnosing structural flaws and reconstructing using PEEL with textual precision.

STEPS:
- Step 1: Identify the three flaws — (a) No comparative/analytical Point (just a list), (b) Evidence not tied to chapter specifics (ektara/sarangi not named in text), (c) Explanation missing causal mechanism ("geography decides" is assertion, not analysis).
- Step 2: Formulate a chapter-grounded Point: "The chapter demonstrates that folk instruments emerge from the dialogue between regional ecology and occupational lifestyle, not mere material availability."
- Step 3: Select textual Evidence — "Ravanahatha (Rajasthan) from coconut shell and bamboo suited to pastoral mobility; Pena (Manipur) from bamboo and horsehair reflecting forest resources; Algoza (Punjab) double flute shaped by agrarian breath-rhythms."
- Step 4: Construct Explanation — "Material choice is mediated by function: drone instruments (ektara) sustain during long herding; percussion (dhol) projects across open fields; melody instruments (algoza) mimic birdsong in riverine plains."
- Step 5: Write Link — "Thus geography provides the palette, but community need selects the brush — a principle the chapter extends to dance costumes and painting surfaces."

ANSWER: The chapter demonstrates that folk instruments emerge from the dialogue between regional ecology and occupational lifestyle, not mere material availability. The ravanahatha of Rajasthan uses coconut shell and bamboo — lightweight, durable for pastoral mobility; Manipur's pena employs bamboo and horsehair sourced from forest fringes; Punjab's algoza double flute mirrors the breath-rhythms of agrarian labor in riverine plains. Material choice is mediated by function: drone instruments (ektara) sustain during long herding watches; percussion (dhol) projects across open fields; melody instruments (algoza) mimic birdsong in wetland ecosystems. Thus geography provides the palette, but community need selects the brush — a principle the chapter extends to dance costumes and painting surfaces.
DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: "The distinction between 'folk' and 'classical' in Indian arts is a colonial construct; the chapter's evidence shows a continuous spectrum." Write a 200-word evaluative response defending or challenging this statement using chapter evidence. Your answer must: (a) Define your interpretive stance in the opening thesis, (b) Use two PEEL body paragraphs (one painting, one music/dance), (c) Incorporate the Sanskrit terms 'marga' and 'desi' implicitly or explicitly, (d) Conclude with a synthesized judgment on the "colonial construct" claim.

COMPETENCY: High-order evaluative writing — synthesizing chapter evidence with historiographical awareness (marga/desi framework) to critique a meta-claim.

STEPS:
- Step 1: Take a nuanced stance — "The chapter supports a spectrum view but reveals *internal* classification (marga/desi) predating colonialism; colonialism rigidified, not invented, the binary."
- Step 2: Body 1 (Painting) — Point: "Painting shows marga-desi permeability." Evidence: "Ajanta's monastic murals (marga) depict folk Jataka tales; Mughal miniatures (courtly marga) absorb Rajasthani folk palette; Madhubani moves from wall (desi) to paper (gallery marga)." Explanation: "Styles migrate across the porous boundary — court artists borrow folk motifs; folk painters adopt classical perspective." Link: "The spectrum is indigenous, not imposed."
- Step 3: Body 2 (Music/Dance) — Point: "Music-dance continuity is codified in Natya Shastra's own marga-deshi distinction." Evidence: "Bharata classifies deshi (regional) and marga (classical) as coexisting streams; gharanas formalize deshi variants into marga; Baul folk tunes enter classical ragas (Bhairavi)." Explanation: "The text treats them as interacting registers — 'laokn' (dialogue) is the native theory." Link: "Colonial ethnography froze this dialogue into hierarchy."
- Step 4: Conclusion — "The chapter affirms a pre-colonial spectrum (marga-deshi) but documents colonialism's role in hardening it into 'folk vs classical' — a distortion the living tradition still resists."

ANSWER: The chapter supports a spectrum view but reveals internal classification (marga/desi) predating colonialism; colonialism rigidified, not invented, the binary. Painting shows marga-deshi permeability. Ajanta's monastic murals (marga) depict folk Jataka tales; Mughal miniatures absorb Rajasthani folk palette; Madhubani moves from ritual wall (desi) to gallery paper (marga). Styles migrate across the porous boundary — court artists borrow folk motifs; folk painters adopt classical perspective. The spectrum is indigenous, not imposed. Music-dance continuity is codified in Natya Shastra's own marga-deshi distinction. Bharata classifies deshi (regional) and marga (classical) as coexisting streams; gharanas formalize deshi variants into marga; Baul folk tunes enter classical ragas (Bhairavi). The text treats them as interacting registers — 'laokn' (dialogue) is the native theory. Colonial ethnography froze this dialogue into hierarchy. The chapter affirms a pre-colonial spectrum (marga-deshi) but documents colonialism's role in hardening it into "folk vs classical" — a distortion the living tradition still resists.
DIFFICULTY: hard