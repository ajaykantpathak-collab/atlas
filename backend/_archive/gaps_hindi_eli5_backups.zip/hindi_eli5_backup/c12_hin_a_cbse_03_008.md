## DEFINITION
Imagery (बिंब) refers to the use of vivid, sensory language that appeals to the five senses (sight, sound, smell, touch, taste) to create mental pictures and evoke emotions. Metaphor (रूपक/उपमा) is a figure of speech that directly equates two unlike things without using comparative words like "like" or "as" (जैसे/वैसे), asserting that one thing *is* another to transfer qualities and deepen meaning. In Class 12 Hindi poetry (Varjak's "वह नहीं" and "मैंने देखा, एक चाँद"), imagery constructs the physical and emotional landscape, while metaphor fuses abstract concepts (freedom, identity, time) with concrete natural elements (spring, moon, wind, hill).

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student can independently identify specific images and metaphors in an unseen Hindi poem, explain the sensory appeal of each image, articulate the tenor (subject) and vehicle (image) of each metaphor, and evaluate how the interplay of imagery and metaphor constructs the poem's central theme (e.g., individuality vs. society, transience vs. permanence) in a structured PEEL paragraph.

## SCOPE_BOUNDARY
This node covers **only** the analysis of imagery (visual, auditory, tactile, organic) and metaphor (simple, extended, mixed) as employed in the two prescribed poems of Chapter 3 ("वह नहीं" and "मैंने देखा, एक चाँद"). It does **not** cover simile (उपमा), personification (मानवीकरण), irony (व्यंग्य), or symbolism (प्रतीकवाद) — those are addressed in node c12_hin_a_cbse_03_009. It also does not cover rhyme scheme, meter, or grammatical analysis.

## WALKTHROUGH
Imagine you are standing on a terrace at dusk: the sky bruises purple, a cool wind carries the scent of rain, and a lone streetlamp flickers. You feel a sudden, sharp loneliness — not because you're alone, but because the *scene* makes the feeling tangible. That is exactly what Varjak does: he doesn't tell you "freedom is fragile"; he shows you a moon losing its colour in the evening wind ("जाक्स कब्बा रंग देक्स जफो दक्स रुद्रक फुहक्ज़;"). Step 1: Read the poem aloud twice — first for rhythm, second to mark every word that triggers a sense (colour, sound, temperature, movement). Step 2: Circle every direct equation (X *is* Y) — these are metaphors. Step 3: For each metaphor, ask: "What quality of Y is forced onto X?" Step 4: Cluster the images — do they form a pattern (e.g., all fading light)? Step 5: Write one sentence linking that pattern to the poem's argument about the individual. The key insight: in Varjak, imagery is not decoration; it is the *evidence* for the metaphor's claim.

## DIAGNOSTIC_QUESTION_1
Define "बिंब" (imagery) and "रूपक" (metaphor) in your own words, giving one example from daily Hindi usage for each (not from the textbook).

## DIAGNOSTIC_ANSWER_1
**Correct answer:** बिंब = इंद्रियों को संबोधित करने वाला शब्द/वाक्यांश जो मानसिक चित्र बनाता है (उदाहरण: "तवे पर रोटी की सोंधी गंध" — घ्राण बिंब)। रूपक = दो असमान चीजों की सीधी तुलना जहाँ एक को दूसरा *बताया* जाता है (उदाहरण: "समय धन है" — समय रूपी धन)।  
**Wrong answer reveals:** Student confuses imagery with "description" (mere adjectives) or metaphor with simile (using "जैसे/वैसे"). They may give ornamental examples ("सुंदर फूल") that lack sensory specificity or metaphorical tension.

## DIAGNOSTIC_QUESTION_2
In "वह नहीं", the poet writes "वह वसंत है... वह मोक्ष है... वह अनंतरूप है". Explain why these are metaphors and not similes. What abstract concept is the tenor (उपमेय) and what concrete images are the vehicles (उपमान)?

## DIAGNOSTIC_ANSWER_2
**Correct answer:** They are metaphors because the poet asserts identity ("है") without comparative particles. Tenor = the elusive "वह" (the ideal state/being the poet seeks). Vehicles = वसंत (renewal, sensory richness), मोक्ष (ultimate release), अनंतरूप (boundless multiplicity).  
**Wrong answer reveals:** Student identifies "वह" as the *vehicle* and spring/liberation as the *tenor* (reversal). Or they call it a simile because "spring resembles freedom". They miss that the metaphor *creates* the concept of "वह" by layering vehicles.

## DIAGNOSTIC_QUESTION_3
Apply the "sensory mapping" technique to the first stanza of "मैंने देखा, एक चाँद". List every image, tag its sense modality (visual/auditory/tactile/olfactory/gustatory/organic), and state the dominant sensory cluster.

## DIAGNOSTIC_ANSWER_3
**Correct answer:**  
1. "लक्ष्मी के ऊपर से" — visual (height, perspective)  
2. "जाक्स कब्बा" — visual (moon-like shape)  
3. "रंग देक्स" — visual (colour)  
4. "जफो दक्स" — tactile/organic (wind touching, internal sensation of fading)  
5. "रुद्रक फुहक्ज़" — auditory/organic (sound of wind, internal tremor)  
Dominant cluster: **visual-tactile** (seeing the moon *and* feeling the wind erase it).  
**Wrong answer reveals:** Student lists nouns only ("चाँद, पहाड़, हवा") without sensory tags, or tags all as "visual". They miss the tactile/organic dimension of "वायु के झोंके से रंग उतरना" — the *feeling* of colour leaving.

## DIAGNOSTIC_QUESTION_4
Analyze the extended metaphor in "वह नहीं" where "वह" is sequentially equated to वसंत, मोक्ष, अनंतरूप, and finally "आत्मा में क्षेप". How does each vehicle *shift* the meaning of the tenor, and why does the poem end by asking the reader to place "यह" (this) in the soul?

## DIAGNOSTIC_ANSWER_4
**Correct answer:** The metaphor evolves: वसंत → sensory, cyclical renewal; मोक्ष → spiritual, final release; अनंतरूप → infinite multiplicity (rejecting fixed form). Each vehicle expands "वह" from seasonal → soteriological → ontological. The final request "आत्मा में क्षेप दो" transforms the metaphor from *description* to *prescription*: the reader must internalize the metaphor, making the abstract "वह" a lived reality. The shift from third-person ("वह") to demonstrative ("यह") signals ownership.  
**Wrong answer reveals:** Student treats the four vehicles as a mere list of synonyms. They don't see the *progressive deepening* (body → spirit → structure → praxis). They miss the grammatical shift from "वह" to "यह" and the imperative mood as part of the metaphor's function.

## DIAGNOSTIC_QUESTION_5
Evaluate this claim: "In 'मैंने देखा, एक चाँद', the fading moon is a weak metaphor for transience because the moon *actually* wanes — it's just literal observation." Defend or refute using evidence from the poem's imagery.

## DIAGNOSTIC_ANSWER_5
**Correct answer:** Refute. The poem does not describe a *natural* lunar cycle. Key phrases make it metaphorical: "लक्ष्मी के ऊपर से" (subjective, elevated perspective), "जाक्स कब्बा" (invented compound: "moon-like *something*"), "रंग देक्स जफो दक्स" (colour fading *due to wind*, not phase), "रुद्रक फुहक्ज़" (a violent, shuddering loss). The moon stands for the *individual's* unique light ("यह वहीं है... यह मेरा है") being stripped by external forces ("वायु" = society/time). Literal moons don't shudder; metaphorical selves do.  
**Wrong answer reveals:** Student accepts the surface literalism ("it's just a moon setting"). They ignore the neologisms ("जाक्स कब्बा", "रुद्रक फुहक्ज़") and the possessive claim ("यह मेरा है") that signals metaphor. They confuse *observation* with *poetic construction*.

## DIAGNOSTIC_QUESTION_6
Create a four-line Hindi poem (or two couplets) that uses **at least two distinct sensory images** and **one metaphor** to express "the pressure of board exams". Do not use the words "परीक्षा", "तनाव", or "दबाव".

## DIAGNOSTIC_ANSWER_6
**Expected criteria:**  
- Two sensory images (e.g., "सुबह की चाय ठंडी होती जाती है" — tactile/gustatory; "पंखे की घरघराहट में नींद टूटती है" — auditory).  
- One clear metaphor (e.g., "किताबें दीमक हैं जो समय चाट रही हैं" — books = termites eating time).  
- No banned words.  
- Emotional resonance without naming the emotion.  
**Poor answer reveals:** Uses clichés ("सिर भारी है" — organic image but no metaphor), or uses simile ("परीक्षा जैसे पहाड़" — banned word + simile), or writes a prose sentence broken into lines. Shows inability to *condense* experience into image+metaphor.

## COMMON_MISCONCEPTION
**"Metaphor is just a fancy word for 'comparison'."** Students write: "कवि ने चाँद की तुलना आशा से की है" (The poet compared the moon to hope). This is wrong because: (1) Metaphor is *identification*, not comparison — the moon *becomes* hope, not "is like" hope. (2) In Varjak, the metaphor *creates* the tenor; there is no pre-existing "hope" that the moon resembles. The moon's shuddering loss *is* the definition of hope's fragility. (3) Board marking scheme awards marks for "रूपक की व्याख्या: उपमेय और उपमान का संबंध स्पष्ट करना" — explaining the *transfer of qualities*, not stating a similarity. Students lose 1-2 marks per question by writing "तुलना" instead of "आरोप/पहचान".

## ON_FAILURE
1. **Revisit Class 11 node c11_hin_ar_cbse_03_008** (Literary Devices: Imagery and Metaphor) — specifically the "तुलना vs आरोप" table. Re-do the exercise converting 5 similes into metaphors (e.g., "वह शेर जैसा बहादुर है" → "वह शेर है").  
2. **Sensory Drill:** Take a mundane object (e.g., a cold cup of tea). Write 5 lines, each invoking a *different* sense, *without* naming the object. Swap with a peer — can they guess it?  
3. **Metaphor Surgery:** Pick one metaphor from "वह नहीं" (e.g., "वह मोक्ष है"). Write: Tenor = ___; Vehicle = ___; Qualities transferred = ___; What *fails* to transfer = ___ (e.g., moksha is permanent, "वह" is invoked as fleeting). This exposes the tension that makes the metaphor poetic.  
4. **Re-diagnostic:** Answer Diagnostic Question 2 again, now explicitly labeling tenor/vehicle/transferred qualities.

## BUILDS_ON
Class 11 understanding of basic figures of speech (अलंकार) — specifically the distinction between रूपक (metaphor) and उपमा (simile) and the concept of बिंब (imagery) as sensory evocation.

## LEADS_TO
Node c12_hin_a_cbse_03_009 (Literary Devices: Irony and Symbolism) where metaphorical images become stable symbols (e.g., the moon *as* a recurring symbol of the self) and irony arises from the gap between metaphorical assertion and reality.

## PREREQUISITE_NODE_IDS
c12_hin_a_cbse_03_001, c12_hin_a_cbse_03_002, c12_hin_a_cbse_03_003, c12_hin_a_cbse_03_004, c12_hin_a_cbse_03_005, c12_hin_a_cbse_03_006, c12_hin_a_cbse_03_007, c11_hin_ar_cbse_03_008
## PREREQUISITE_REASONS
c12_hin_a_cbse_03_001: Context/background of Varjak and his poetic philosophy is essential to know *why* he uses dense metaphor.
c12_hin_a_cbse_03_002: Narrative structure of the poems (stanza breaks, progression) determines where metaphors cluster.
c12_hin_a_cbse_03_003: Setting/atmosphere (hilltop at dusk, abstract "soul-space") provides the physical ground for imagery.
c12_hin_a_cbse_03_004: Protagonist (the speaker/poet-persona) is the *tenor* of many metaphors — his voice shapes the vehicle.
c12_hin_a_cbse_03_005: Supporting characters (society, "लोग", "वायु") appear as metaphorical forces (wind that strips colour).
c12_hin_a_cbse_03_006: Primary theme (individuality vs. conformity) is the *argument* that metaphors prove.
c12_hin_a_cbse_03_007: Secondary themes (transience, creativity, freedom) are the *sub-arguments* carried by specific image clusters.
c11_hin_ar_cbse_03_008: Direct prior exposure to imagery/metaphor definitions and simple identification; this node deepens to analysis/evaluation.

## FORWARD_NODE_IDS
c12_hin_a_cbse_03_009, c12_hin_a_cbse_03_010, c12_hin_a_cbse_03_012, c12_hin_a_cbse_03_013, c12_hin_a_cbse_03_014, c12_hin_a_cbse_03_015

## FORWARD_REASONS
c12_hin_a_cbse_03_009: Irony and symbolism build directly on metaphor — a symbol is a metaphor fixed by cultural repetition; irony often undermines a metaphor's claim.
c12_hin_a_cbse_03_010: Vocabulary in context (e.g., "क्षेप", "रुद्रक", "जाक्स कब्बा") requires understanding metaphorical usage to gloss correctly.
c12_hin_a_cbse_03_012: Comprehension questions (literal/inferential) test if student can decode metaphorical meaning (e.g., "कवि 'वह' को 'मोक्ष' क्यों कहता है?").
c12_hin_a_cbse_03_013: Critical thinking asks for evaluation of metaphor's effectiveness — directly uses this node's analytical framework.
c12_hin_a_cbse_03_014: Writing tasks (analytical paragraph, creative response) require the PEEL structure modeled here.
c12_hin_a_cbse_03_015: अगला तार्किक चरण: Speaking and Listening: इस नोड की अवधारणाओं को सीधे उपयोग/विस्तारित करता है।  

## CROSS_SUBJECT_PREREQS
c11_hin_ar_cbse_03_008, c11_hin_ar_cbse_03_013
## CROSS_SUBJECT_REASONS
c11_hin_ar_cbse_03_008: Class 11 Hindi (Antra) Chapter 3 covered the same devices — this node assumes that foundation and pushes to board/competitive depth.
c11_hin_ar_cbse_03_013: Critical thinking/interpretation skills from Class 11 (analyzing themes through devices) are the cognitive prerequisite for the "evaluate/create" diagnostics here.

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_03_008 -> c12_hin_a_cbse_03_008 -> c12_hin_a_cbse_03_009

## THIS_FORMULA
**Metaphor Analysis Protocol (MAP):**  
1. **Locate** the copular verb (है/हैं/था/थी) linking two nouns without "जैसे/वैसे".  
2. **Label** Tenor (उपमेय = subject being described) and Vehicle (उपमान = image imposed).  
3. **List** 3-4 qualities of the Vehicle (sensory, cultural, emotional).  
4. **Select** which qualities transfer to the Tenor (and which are deliberately blocked).  
5. **State** the *new meaning* created for the Tenor that did not exist before the metaphor.  
6. **Connect** to poem's theme: Does this metaphor advance, complicate, or resolve the central conflict?

## FORMULA_VARIABLES
- Tenor (उपमेय): The abstract concept/entity being redefined (e.g., "वह", "चाँद", "आत्मा")  
- Vehicle (उपमान): The concrete image imposed (e.g., "वसंत", "मोक्ष", "जाक्स कब्बा")  
- Ground (आधार): Shared qualities enabling the metaphor (e.g., renewal, multiplicity, fragility)  
- Tension (तनाव): Qualities of Vehicle that *contradict* Tenor, creating poetic energy (e.g., moksha is final; "वह" is ongoing)  
- Theme-link (थीम-संबंध): How the metaphor serves the poem's argument

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
linguistic

## CROSS_SUBJECT
N/A | Varjak's metaphors reflect the Chhayavad/Modernist shift from ornamental imagery to existential metaphor — parallels Tagore's "Gitanjali" where "cloud" becomes metaphor for divine longing.  
 N/A | The metaphor "वह वसंत है... इसे भी आत्मा में क्षेप दो" enacts the political theory of positive liberty (freedom *to* self-define) vs. negative liberty (freedom *from* interference) — the individual internalizes the metaphor to resist state/society ("वायु") stripping identity.
## PREREQ_CONCEPT
Ability to distinguish between *literal description* (चाँद निकला) and *figurative identification* (चाँद आशा है) — tested in Class 11 via conversion exercises (simile ↔ metaphor).

## PREREQ_BEFORE
Student must be able to: (a) underline every sensory word in a stanza, (b) convert a simile to a metaphor and vice versa, (c) state the theme of "वह नहीं" in one sentence.

## PREREQ_STUCK
If stuck on tenor/vehicle identification: Revisit Class 11 node c11_hin_ar_cbse_03_008, section "रूपक के अंग" — practice with 10 non-textbook sentences (e.g., "क्रोध अग्नि है", "स्मृति धुंध है") until labeling is automatic.

## WORKED_EXAMPLE_1
**PROBLEM:** Analyze the metaphor "यह एक्कुक है — थौ-डके सुक दक वीर एव" (from "वह नहीं", line 4) using the MAP protocol. Explain how the neologism "एक्कुक" functions as a vehicle.

**STEPS:**
- Step 1: Locate the copula — "है" (implied in "एक्कुक है"). The structure is "यह [demonstrative] + [noun phrase]".
- Step 2: Label Tenor = "यह" (referring back to "वह" — the elusive ideal). Vehicle = "एक्कुक" (compound: एक + कुक? or एक + कूक? — "solitary cry/call").
- Step 3: List Vehicle qualities: "एक्कुक" suggests singularity (एक), sound (कूक = bird call), loneliness, urgency, organic emission from a living throat.
- Step 4: Select transferred qualities: The ideal "वह" is not a static object but a *living utterance* — singular, unrepeatable, demanding response. Blocked qualities: "कूक" is animalistic; "वह" is spiritual — tension between raw biology and transcendence.
- Step 5: New meaning: "वह" is redefined as *performative* — it exists only when voiced/claimed ("आत्मा में क्षेप दो"). It is not a noun but a verb-event.
- Step 6: Theme-link: This metaphor shifts the poem from *seeking* an external savior ("वह") to *uttering* one's own truth ("एक्कुक") — the individual's voice *is* the freedom.

**REASONING:** The MAP forces attention to Varjak's invented vocabulary ("एक्कुक", "जाक्स कब्बा", "रुद्रक फुहक्ज़") as vehicles that *create* new tenors. Standard dictionary metaphors (time = money) recycle cultural associations; poetic neologisms *forge* them.

**ANSWER:** The metaphor "यह एक्कुक है" identifies the abstract ideal "वह" with a solitary, urgent cry. Tenor = the sought-after freedom/identity; Vehicle = a unique, biological vocalization. Transferred: singularity, urgency, embodiment, need for witness. Blocked: animal vs. spiritual. New meaning: Freedom is not found but *voiced*. This advances the theme of self-creation against conformity.

## WORKED_EXAMPLE_2
**PROBLEM:** In "मैंने देखा, एक चाँद", trace the visual-tactile image cluster across the poem and explain how it prepares the final metaphor "यह वहीं है... यह मेरा है".

**STEPS:**
- Step 1: Map sensory images stanza-wise:  
  Stanza 1: "लक्ष्मी के ऊपर से" (visual: height), "जाक्स कब्बा" (visual: moon-shape), "रंग देक्स जफो दक्स" (visual-tactile: colour stripped by wind), "रुद्रक फुहक्ज़" (auditory-organic: shuddering loss).  
  Stanza 2: "यह वहीं है" (visual: recognition), "यह मेरा है" (organic/tactile: possession/internalization).
- Step 2: Identify the cluster — **visual-tactile-organic**: seeing a coloured form → feeling the wind erase it → feeling the shudder of loss → recognizing the remnant → claiming it bodily ("मेरा").
- Step 3: Analyze the progression: The images move from *external observation* (hilltop, moon) to *internal sensation* (wind on skin, shudder in chest) to *proprioceptive claim* ("मेरा" = mine, located in body).
- Step 4: Link to final metaphor: "यह वहीं है... यह मेरा है" is a metaphor of *identity* — the faded, wind-shaken moon *is* the self. The visual-tactile cluster *proves* the metaphor: the self is what survives the stripping.
- Step 5: Evaluate effectiveness: The cluster makes the metaphor inevitable, not asserted. We *feel* the loss before we name the identity.

**REASONING:** Imagery clusters are not random; they build the sensory evidence that the concluding metaphor *cashes in*. Board answers must show this causal chain: image cluster → metaphorical payoff → thematic statement.

**ANSWER:** The poem constructs a visual-tactile-organic cluster: elevated sight → colour stripped by wind → bodily shudder → recognition → possessive claim. This cluster enacts the metaphor "यह वहीं है... यह मेरा है" — the self is the residue that survives external erosion. The metaphor is *earned* by the imagery, not merely declared.

## WORKED_EXAMPLE_3
**PROBLEM:** Compare the function of metaphor in "वह नहीं" (poem 1) and "मैंने देखा, एक चाँद" (poem 2). Both use nature vehicles (spring, moon) for abstract tenors (freedom, self). How does the *direction* of the metaphor differ? (Hint: one is aspirational, one is recuperative.)

**STEPS:**
- Step 1: Identify tenor/vehicle pairs in Poem 1: "वह" (tenor) ← "वसंत/मोक्ष/अनंतरूप/एक्कुक" (vehicles). Direction: **Upward/Outward** — the poet *projects* ideal qualities onto an absent "वह", then demands the reader *internalize* them ("आत्मा में क्षेप दो"). The metaphor *creates* a future self.
- Step 2: Identify tenor/vehicle pairs in Poem 2: "चाँद/जाक्स कब्बा" (vehicle) → "यह/मेरा" (tenor). Direction: **Downward/Inward** — the poet *observes* a natural phenomenon, *witnesses* its erosion, then *recognizes* the remnant as self ("यह वहीं है... यह मेरा है"). The metaphor *recovers* a present self.
- Step 3: Analyze vehicle choice: Poem 1 uses *cultural* vehicles (वसंत, मोक्ष — loaded with tradition). Poem 2 uses *phenomenological* vehicles (moon, wind, colour, shudder — raw perception).
- Step 4: Analyze tense/mood: Poem 1 = present tense assertions + imperative ("क्षेप दो"). Poem 2 = past tense narrative ("मैंने देखा") + present recognition ("यह वहीं है").
- Step 5: Synthesize: Poem 1's metaphor is **prescriptive** (build the self through metaphorical aspiration). Poem 2's metaphor is **descriptive/constitutive** (the self *is* the metaphorical residue of experience).
- Step 6: Thematic consequence: Poem 1 = freedom as *project* (Nehruvian/Modernist). Poem 2 = freedom as *survival* (existentialist). Both are Varjak — the two poles of his poetic philosophy.

**REASONING:** Competitive exams (CUET, JEE Hindi) ask for *comparative device analysis* across texts. This worked example models the "directionality" heuristic: does the metaphor *project* an ideal or *reveal* a reality? This distinguishes Modernist (poem 1) from Existentialist (poem 2) strains in Hindi poetry.

**ANSWER:** Poem 1 uses metaphor **aspirationally**: cultural vehicles (spring, moksha) are imposed on an absent tenor ("वह") to *construct* a future ideal, culminating in an imperative to internalize. Poem 2 uses metaphor **recuperatively**: phenomenological vehicles (moon, wind, shudder) are observed eroding, leaving a remnant that *is* identified as the self ("यह मेरा है"). Direction: Poem 1 = outward/forward (creation); Poem 2 = inward/backward (recognition). Vehicle type: Poem 1 = cultural/symbolic; Poem 2 = sensory/immediate.

## COMPETENCY_QUESTION_1
**QUESTION:** A student writes in the board exam: "कवि ने चाँद को अपनी आशा का प्रतीक बनाया है क्योंकि चाँद सुंदर होता है और आशा भी सुंदर होती है।" Identify **three** specific errors in this statement using the concepts of metaphor vs. symbol, vehicle/tenor, and imagery. Rewrite the answer to score full marks (2 marks).

**COMPETENCY:** Critical analysis of peer response / Exam answer correction

**STEPS:**
- Step 1: Identify Error 1 — "प्रतीक" (symbol) vs "रूपक" (metaphor). The poem uses metaphor (direct equation), not a pre-existing cultural symbol. Symbols are stable; this metaphor is invented ("जाक्स कब्बा").
- Step 2: Identify Error 2 — "चाँद को आशा का प्रतीक बनाया" reverses tenor/vehicle. The moon (vehicle) is imposed on the self (tenor), not "hope". The tenor is *identity*, not hope.
- Step 3: Identify Error 3 — "सुंदर होता है" reduces imagery to vague adjective. The poem uses *specific* visual-tactile-organic imagery (fading colour, wind, shudder) — not "beauty".
- Step 4: Rewrite using MAP: "कवि 'जाक्स कब्बा' (चाँदनुमा आकृति) रूपक द्वारा 'मैं' (आत्मा) को उपमेय बनाता है। वायु द्वारा रंग उतरना (दृश्य-स्पर्शी बिंब) और रुद्रक फुहक्ज़ (श्रवण-आंतरिक बिंब) बाह्य दबाव दर्शाते हैं। अंत में 'यह मेरा है' रूपक से आत्मा की अवशेष पहचान स्थापित होती है।"

**ANSWER:** Errors: (1) Confuses metaphor (dynamic, invented) with symbol (fixed, cultural). (2) Reverses tenor/vehicle — moon is vehicle, self is tenor. (3) Replaces precise sensory imagery with vague "beauty". Corrected answer (2 marks): "कवि 'जाक्स कब्बा' रूपक द्वारा 'मैं' को उपमेय बनाता है। दृश्य-स्पर्शी बिंब (रंग उतरना) और श्रवण-आंतरिक बिंब (रुद्रक फुहक्ज़) बाह्य क्षरण दिखाते हैं। 'यह मेरा है' रूपक से आत्मा की अवशेष पहचान सिद्ध होती है।"

**DIFFICULTY:** medium

## COMPETENCY_QUESTION_2
**QUESTION:** (Case-based) Read the excerpt from a Class 12 student's analytical paragraph on "वह नहीं":  
> "कवि 'वह' को 'वसंत', 'मोक्ष', 'अनंतरूप' बताता है। ये रूपक हैं क्योंकि 'जैसे' शब्द नहीं है। वसंत से ताजगी, मोक्ष से मुक्ति, अनंतरूप से अनेक रूप आते हैं। अंत में कवि कहता है 'आत्मा में क्षेप दो'। इससे पता चलता है कि कवि स्वतंत्रता चाहता है।"  
Using the **Metaphor Analysis Protocol (MAP)**, critique this paragraph. Identify **two** missing analytical moves and **one** interpretive leap. Then write a **replacement paragraph** (80-100 words) that demonstrates "analyze" level competence for CBSE 3-mark question.

**COMPETENCY:** Metacognitive evaluation of literary analysis / Board answer writing (PEEL + MAP)

**STEPS:**
- Step 1: Missing Move 1 — No **tension analysis**: The paragraph lists transferred qualities (freshness, release, multiplicity) but ignores what *fails* to transfer (e.g., spring is cyclical; "वह" is invoked as singular/urgent "एक्कुक"). Tension creates poetic meaning.
- Step 2: Missing Move 2 — No **progression tracking**: The four vehicles are treated as a flat list. MAP Step 5 requires showing how each vehicle *shifts* the tenor (sensory → spiritual → ontological → performative).
- Step 3: Interpretive Leap — "इससे पता चलता है कि कवि स्वतंत्रता चाहता है" reduces the poem to a biography. The metaphor *enacts* freedom as self-creation ("क्षेप" = throwing/placing), not mere desire.
- Step 4: Replacement paragraph (PEEL + MAP):  
  **Point:** "वह नहीं" में रूपक-श्रृंखला उपमेय "वह" को स्थिर संज्ञा से क्रियात्मक घटना में बदलती है।  
  **Evidence:** "वसंत" (चक्रीय नवीकरण) → "मोक्ष" (अंतिम मुक्ति) → "अनंतरूप" (सीमाहीन बहुलता) → "एक्कुक" (एकाकी उच्चारण) — प्रत्येक उपमान उपमेय को गहन करता है।  
  **Explanation:** "क्षेप" (आरोपण) की आज्ञा रूपक को वर्णन से विधान में बदल देती है: स्वतंत्रता पाई नहीं जाती, गढ़ी जाती है।  
  **Link:** यह रूपक-प्रगति वर्जक के "व्यक्ति निर्माण" थीम को मूर्त करती है।

**ANSWER:** Critique: (1) Missing tension analysis (spring's cyclicity vs. "वह"s urgency). (2) Missing progression tracking (sensory→spiritual→ontological→performative). (3) Leap: reduces metaphor to authorial intent ("wants freedom") instead of textual enactment ("throws into soul"). Replacement paragraph above demonstrates MAP-integrated PEEL.

**DIFFICULTY:** hard