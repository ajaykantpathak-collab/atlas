## DEFINITION
Literal comprehension questions require answers directly stated in the text, while inferential comprehension questions require drawing conclusions by combining textual evidence with logical reasoning. Both types test the ability to extract and interpret meaning from the given passage or poem.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student can independently distinguish between literal and inferential questions, locate exact textual evidence for literal answers, and construct logical inferences supported by at least two textual clues for inferential answers, writing responses in the PEEL structure (Point, Evidence, Explanation, Link) within the CBSE word limit.

## SCOPE_BOUNDARY
This node covers strategies for answering literal and inferential comprehension questions based on the prose and poetry texts of Chapter 6 (Raghuveer Sahay's works) only. It does NOT cover critical analysis, creative writing, or speaking/listening skills, which are addressed in subsequent nodes.

## WALKTHROUGH
Imagine you are sitting in the CBSE Class 12 Hindi exam and see a question: "Hajir ne apni maa ko kaise yaad kiya?" — your heart races because the answer isn't directly written. Start by reading the question twice, circling keywords like "Hajir", "maa", "yaad". Then scan the poem for those words or synonyms. If you find an exact line, it's literal — quote it. If not, gather clues: Hajir's tone, imagery of mother, his emotional words. Combine clues to form an inference. Always write your answer in four steps: (1) Direct answer in one sentence, (2) Quote/paraphrase evidence, (3) Explain how evidence proves your point, (4) Connect to the poem's central theme of maternal love and memory. This method works for both prose and poetry.

## DIAGNOSTIC_QUESTION_1
What is the fundamental difference between a literal comprehension question and an inferential comprehension question?

## DIAGNOSTIC_ANSWER_1
A literal question's answer is explicitly stated in the text (e.g., "What is the poet's name?"), while an inferential question requires the reader to deduce the answer by combining textual clues (e.g., "Why does the poet compare the mother to a shadow?"). A wrong answer that defines both as "questions based on the text" reveals the student cannot distinguish explicit vs. implicit information, leading to vague answers in exams.

## DIAGNOSTIC_QUESTION_2
In the poem "Hajir-Ja ke Ijse", the line "Meri maa thi ek chhaya" does not appear. How would you answer the inferential question: "Kavi ne maa ko chhaya kyon kaha hai?" using textual evidence?

## DIAGNOSTIC_ANSWER_2
The student must identify metaphors like "thandi hawa", "saya", "aanchal" in the poem that suggest protection and coolness, then infer that "chhaya" symbolizes the mother's sheltering love. A wrong answer quoting a non-existent line shows the student confuses inference with direct quotation, a common error where students fabricate textual evidence instead of deriving it.

## DIAGNOSTIC_QUESTION_3
Apply the PEEL structure to answer this literal question from the prose extract: "Raghuveer Sahay ke pita ka naam kya tha?" (Refer to the biographical note in the chapter).

## DIAGNOSTIC_ANSWER_3
Step 1: Locate the biographical note (first paragraph of the chapter). Step 2: Find the sentence stating his father's name. Step 3: Write: Point — "Raghuveer Sahay ke pita ka naam Pandit Ramavatar Sharma tha." Evidence — "Pathya-pustak ke anusar, 'Unke pita Pandit Ramavatar Sharma the.'" Explanation — "Yeh jaankari lekhak ke jeevan parichay mein spashth roop se di gayi hai." Link — "Isse unke parivarik patachitra ka pata chalta hai." A wrong answer without the exact name or citing the wrong paragraph shows inability to locate explicit facts.

## DIAGNOSTIC_QUESTION_4
Analyze the following student answer to an inferential question: "Hajir apni maa ko bhul nahi paata kyunki usne use bahut pyaar kiya." Is this a complete inference? What is missing?

## DIAGNOSTIC_ANSWER_4
The answer states a conclusion but lacks textual evidence and explanation. A complete inference must cite specific lines (e.g., "raat bhar jaagta tha", "uski god mein soya") and explain how they prove the bond. The missing PEEL components (Evidence, Explanation) will cost marks in CBSE marking scheme which awards points for each step. A student giving such an answer treats inference as opinion, not text-based reasoning.

## DIAGNOSTIC_QUESTION_5
Evaluate this claim: "For inferential questions in poetry, personal feeling is more important than textual evidence." Defend your evaluation with reference to CBSE marking criteria.

## DIAGNOSTIC_ANSWER_5
The claim is false. CBSE marking scheme for inferential questions allocates marks: 1 for correct inference, 1 for relevant textual evidence, 1 for logical explanation linking evidence to inference. Personal feeling without textual support earns zero. A student believing this will write subjective responses like "Mujhe lagta hai maa pyaari hoti hai" and lose all inference marks. The evaluation must reference the rubric: evidence is mandatory.

## DIAGNOSTIC_QUESTION_6
Create an inferential question based on the poem "Hajir-Ja ke Ijse" that requires connecting two separate stanzas, and provide a model answer outline.

## DIAGNOSTIC_ANSWER_6
Question: "Kavi ne maa ki yaad ko 'raat' aur 'sapne' dono se kyun joda hai? Do bandon ke aadhar par bataiye." Model outline: Point — "Maa ki yaad hajir ko raat bhar jagati hai aur sapnon mein bhi aati hai." Evidence 1 — Stanza 2: "raat bhar jaagta tha". Evidence 2 — Stanza 4: "sapne mein maa aati thi". Explanation — "Raat jagran dikhata hai viyog ki teevrata, sapne dikhate hain avchatan mein bhi maa ki upasthiti." Link — "Yeh milkar maa ke pyaar ki amar taqat dikhate hain." A poor question would be answerable from one stanza, not testing cross-stanza synthesis.

## COMMON_MISCONCEPTION
Students believe inferential questions allow "any answer as long as it makes sense." They write personal opinions ("Maa to sabko pyaari hoti hai") without anchoring in the specific text. This error stems from confusing "inference" (text-based deduction) with "imagination" (free association). In CBSE exams, such answers score zero because the marking scheme explicitly requires "textual evidence" (pathya-samarthit uttar). The poem "Hajir-Ja ke Ijse" uses specific Avadhi/Braj words like "lori", "god", "aanchal" — ignoring these cultural markers leads to generic, low-scoring responses.

## ON_FAILURE
If a student cannot differentiate literal vs. inferential, do this 3-step remediation: (1) Give them a 5-line excerpt from the chapter's prose biography. Ask: "Highlight every fact directly written" (literal practice). (2) Ask: "What is NOT written but can be guessed about the poet's childhood?" List guesses, then demand one textual clue per guess (inference practice). (3) Have them rewrite one guess as a PEEL paragraph. Re-diagnose using Diagnostic Question 2 format with a new poem stanza. If they still invent evidence, revisit node c11_hin_ar_cbse_01_012 (Class 11 comprehension basics) for literal/inferential classification drills.

## BUILDS_ON
Builds on Class 11 comprehension skills (literal/inferential distinction) and Chapter 6's prior nodes on vocabulary, grammar, and literary devices which provide the textual toolkit for evidence gathering.

## LEADS_TO
Enables Critical Thinking: Analysis and Interpretation (c12_hin_a_cbse_06_013) where students evaluate themes across texts, and Writing Skills (c12_hin_a_cbse_06_014) where comprehension answers become structured essays.

## PREREQUISITE_NODE_IDS
c12_hin_a_cbse_06_001, c12_hin_a_cbse_06_002, c12_hin_a_cbse_06_003, c12_hin_a_cbse_06_004, c12_hin_a_cbse_06_005, c12_hin_a_cbse_06_006, c12_hin_a_cbse_06_007, c12_hin_a_cbse_06_008, c12_hin_a_cbse_06_009, c12_hin_a_cbse_06_010, c12_hin_a_cbse_06_011, c11_hin_ar_cbse_01_012, c11_hin_v_cbse_01_012
## PREREQUISITE_REASONS
c12_hin_a_cbse_06_001: Context/background knowledge needed to understand cultural references in inference.
c12_hin_a_cbse_06_002: Plot/narrative structure helps locate where evidence appears in the text.
c12_hin_a_cbse_06_003: Setting/atmosphere clues support inferential reasoning about mood.
c12_hin_a_cbse_06_004: Protagonist analysis provides character-specific evidence for inference.
c12_hin_a_cbse_06_005: Supporting characters offer additional textual clues.
c12_hin_a_cbse_06_006: Primary theme guides the "Link" step in PEEL for inferential answers.
c12_hin_a_cbse_06_007: Secondary themes enrich multi-layered inferences.
c12_hin_a_cbse_06_008: Imagery/metaphor identification is core evidence for poetry inference.
c12_hin_a_cbse_06_009: Irony/symbolism detection enables deeper inferences.
c12_hin_a_cbse_06_010: Vocabulary in context ensures accurate understanding of key words in questions.
c12_hin_a_cbse_06_011: Grammar usage knowledge helps parse complex sentences for literal answers.
c11_hin_ar_cbse_01_012: Class 11 Antra comprehension foundation for literal/inferential classification.
c11_hin_v_cbse_01_012: Class 11 Vitan comprehension foundation for non-fiction text strategies.

## FORWARD_NODE_IDS
c12_hin_a_cbse_06_013, c12_hin_a_cbse_06_014, c12_hin_a_cbse_06_015
## FORWARD_REASONS
c12_hin_a_cbse_06_013: Critical thinking requires the evidence-gathering and inference skills mastered here.
c12_hin_a_cbse_06_014: Writing skills tasks (essays, letters based on chapter) use comprehension answers as raw material.
c12_hin_a_cbse_06_015: Speaking/listening discussions need students to articulate literal facts and defend inferences orally.

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
No cross-subject prerequisites from Class 11 nodes listed; comprehension skills are language-specific at this level.

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_01_012 -> c12_hin_a_cbse_06_012 -> c12_hin_a_cbse_06_013

## THIS_FORMULA
PEEL Structure for Comprehension Answers: Point (Direct Answer) + Evidence (Text Quote/Paraphrase) + Explanation (How Evidence Proves Point) + Link (Connect to Theme/Context)

## FORMULA_VARIABLES
Point = One-sentence answer to the question; Evidence = Exact line reference or paraphrase from text with location (stanza/paragraph); Explanation = Logical reasoning connecting evidence to point; Link = Connection to central idea, author's intent, or broader context.

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
linguistic

## CROSS_SUBJECT
N/A | Historical source analysis uses identical literal/inferential distinction: literal = what the document explicitly states; inferential = what the historian deduces about bias, audience, context using textual clues.
 N/A | Case-study questions in economics require literal data extraction (e.g., "What is the GDP figure in Table 1?") and inferential reasoning (e.g., "Why might this GDP figure be misleading?") using the same PEEL evidence-based structure.
## PREREQ_CONCEPT
Ability to distinguish explicit textual statements from implicit suggestions, developed in Class 11 Hindi comprehension nodes.

## PREREQ_BEFORE
Student must be able to locate specific information in a Hindi text (skimming/scanning) and understand key vocabulary from the chapter (node c12_hin_a_cbse_06_010).

## PREREQ_STUCK
If stuck on finding evidence, review "Text: Plot and Narrative Structure" (c12_hin_a_cbse_06_002) to learn text navigation, and "Vocabulary in Context" (c12_hin_a_cbse_06_010) for word meanings blocking comprehension.

## WORKED_EXAMPLE_1
PROBLEM: Answer the inferential question: "Hajir ki maa uske jeevan mein kya sthan rakhti thi? Kavita ke aadhar par spashth kijiye." (Based on the poem "Hajir-Ja ke Ijse" in Chapter 6).
STEPS:
- Step 1: Identify question type — "sthan rakhti thi" asks for role/importance, not directly stated → inferential.
- Step 2: Scan poem for mother-related imagery. Find Stanza 1: "thandi hawa jaisi", Stanza 2: "raat bhar jaagti", Stanza 3: "god mein sulati", Stanza 4: "sapne mein aati".
- Step 3: Group evidence: Protection (thandi hawa, god), Sacrifice (raat bhar jaagti), Permanent presence (sapne mein).
- Step 4: Formulate Point: "Hajir ki maa uske jeevan mein suraksha, tyag aur nirantar upasthiti ka prateek thi."
- Step 5: Write PEEL answer: Point (as above). Evidence: "Stanza 1 mein 'thandi hava', Stanza 2 mein 'raat bhar jaagti', Stanza 3 mein 'god mein sulati', Stanza 4 mein 'sapne mein aati'." Explanation: "Ye chारों images milkar dikhate hain ki maa keval janm dene wali nahi, balki har pal — jaagte, sote, sapne mein — saath dene wali shakti thi." Link: "Yeh kavi ke 'matri-bhakti' ke kendriya bhav ko pratibimbit karta hai."
REASONING: The steps move from question analysis to evidence clustering to structured writing, ensuring each CBSE marking point is hit. Clustering evidence from multiple stanzas demonstrates the synthesis required for full marks.
ANSWER: Hajir ki maa uske jeevan mein suraksha (thandi hava), tyag (raat bhar jaagna), aur nirantar upasthiti (sapne mein aana) ka prateek thi. Kavita ke char bandon mein ye chhavi ubhar kar aati hai jo matri-prem ki amar taqat dikhati hai.

## WORKED_EXAMPLE_2
PROBLEM: Answer the literal question: "Raghuveer Sahay ne 'Jkepfjrekul' ki rachna kis bhasha mein ki thi? Pathya-pustak ke anusar bataiye." (Based on the biographical note).
STEPS:
- Step 1: Identify question type — asks for a specific fact explicitly mentioned → literal.
- Step 2: Locate the relevant section: first paragraph of the chapter introduction (biographical note).
- Step 3: Extract exact information: The text states "Jkepfjrekul ... eq[;r% nksgk vkSj pkSikbZ Nan esa gqbZ gSA" (written mainly in Braj and Khari Boli).
- Step 4: Formulate direct answer using textual language: "Raghuveer Sahay ne 'Jkepfjrekul' ki rachna mukhya roop se Braj Bhasha aur Khari Boli mein ki thi."
- Step 5: Verify no inference needed — answer is complete with just the fact. Add citation: "Pathya-pustak ke parichay anuchhed ke anusar."
REASONING: Literal questions test retrieval accuracy. The steps enforce text-dependence: locate, extract, quote. No analysis or synthesis is required or rewarded. Adding "in my opinion" would be penalized.
ANSWER: Raghuveer Sahay ne 'Jkepfjrekul' ki rachna mukhya roop se Braj Bhasha aur Khari Boli mein ki thi. (Pathya-pustak ke parichay anuchhed ke anusar)

## WORKED_EXAMPLE_3
PROBLEM: A student writes this answer to an inferential question: "Kavi ne 'Hajir' ka chitra kaisa khicha hai? Uttar: Hajir bahut dukhi aur akela ladka tha." Improve this answer using PEEL and textual evidence from the poem and prose extract.
STEPS:
- Step 1: Diagnose weakness — answer is an unsupported opinion (inference without evidence), misses complexity (Hajir is not just sad/lonely; he has memories, love, resilience).
- Step 2: Gather evidence from poem: Stanza 1 "fut ukFk lqHkkmQ" (doesn't want to sleep alone), Stanza 2 "raat bhar jaagta" (vigilant), Stanza 3 "fp=kfy[kh lh" (mother's picture equal to mother), prose extract "jke ouxeu osQ i'pkr~ Hkjr dh euksn'kk" (mother's memory is Hajir's support).
- Step 3: Synthesize Point: "Hajir ek aisa balak hai jise maa ki yaad sambhalti hai, use ekela nahi hone deti, aur uske andar prem aur suraksha ki bhavna jagrit karti hai."
- Step 4: Draft PEEL: Point (as above). Evidence: "Kavita ke Stanza 1 mein 'fut ukFk lqHkkmQ', Stanza 2 mein 'raat bhar jaagta', Stanza 3 mein 'fp=kfy[kh lh', aur gadya ansh mein 'i'pkr~ Hkjr dh euksn'kk'." Explanation: "Ye sab milkar dikhate hain ki Hajir ka dukh maa ki yaad se kam hota hai, wo akela nahi hai kyunki maa ki yaad uske saath hai." Link: "Yeh kavi ke 'smriti ke bal' ke vichar ko pratibimbit karta hai."
- Step 5: Check against CBSE rubric — Point (1), Evidence (1), Explanation (1), Link (1) = 4/4 marks.
REASONING: This example teaches the most common upgrade: transforming a vague opinion into a textually grounded, multi-evidence inference. It combines poetry and prose evidence, a higher-order skill for Chapter 6's mixed-genre text.
ANSWER: Improved Answer: Hajir ek aisa balak hai jise maa ki yaad sambhalti hai, use ekela nahi hone deti, aur uske andar prem aur suraksha ki bhavna jagrit karti hai. Kavita ke Stanza 1 mein 'fut ukFk lqHkkmQ', Stanza 2 mein 'raat bhar jaagta', Stanza 3 mein 'fp=kfy[kh lh', aur gadya ansh mein 'i'pkr~ Hkjr dh euksn'kk' jaise praman milte hain. Ye sab milkar dikhate hain ki Hajir ka dukh maa ki yaad se kam hota hai, wo akela nahi hai kyunki maa ki yaad uske saath hai. Yeh kavi ke 'smriti ke bal' ke vichar ko pratibimbit karta hai.

## COMPETENCY_QUESTION_1
QUESTION: Read the following lines from the poem (not reproduced here, but imagine Stanza 2: "raat bhar jaagta tha / uski god mein soya"). A student answers the inferential question "Hajir raat bhar kyun jaagta tha?" with: "Hajir raat bhar isliye jaagta tha kyunki use neend nahi aati thi." Is this a valid inference? Justify your evaluation using the PEEL criteria and textual evidence.
COMPETENCY: Critical evaluation of peer responses using textual evidence (CBSE Competency: Analytical Thinking)
STEPS:
- Step 1: Identify the student's inference: "neend nahi aati thi" (insomnia).
- Step 2: Check textual evidence: The lines say "raat bhar jaagta tha / uski god mein soya" — he stayed awake *in mother's lap*, implying he chose to stay awake to be with her, not inability to sleep.
- Step 3: Apply PEEL: The student's answer has a Point but Evidence contradicts it (god mein soya shows comfort, not insomnia). Explanation fails logic. Link missing.
- Step 4: Formulate evaluation: "Invalid inference. Evidence shows voluntary wakefulness in mother's protective lap, not sleeplessness. Correct inference: He stayed awake to prolong the moment of maternal closeness."
ANSWER: The student's inference is invalid. The textual evidence "uski god mein soya" indicates he was comforted and secure in his mother's lap, suggesting he stayed awake voluntarily to cherish her presence, not due to insomnia. A valid inference must align with all cited evidence; here the evidence contradicts the claim. PEEL evaluation: Point (1) but Evidence (0), Explanation (0), Link (0) = 1/4 marks.
DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: The prose extract states: "Hajr Hkkoqd ân; ls crkrs gSa fd jke dk muosQ izfr vR;fèkd izseHkko gSA" (Hajir says with emotion that Ram had a special affection for him). Based on this literal fact AND the poem's portrayal of Hajir's mother, construct an inferential answer to: "Hajir ke jeevan mein do mahilaon — uski maa aur Hajir (jise wo 'Hajir' ke roop mein yaad karta hai) — ki bhumika ka tulnatmak vishleshan kijiye." (Comparative analysis of two women in Hajir's life: his mother and Hajir herself). Note: This requires synthesizing prose fact (Hajir's statement about Ram) with poem's maternal imagery.
COMPETENCY: Inter-textual synthesis and comparative inference (CBSE Competency: Critical Thinking & Analysis; CUET/Higher Ed readiness)
STEPS:
- Step 1: Extract literal fact from prose: Hajir (the narrator) says Ram (Hajir's father?) had special affection for Hajir (the son). Clarify identities: The narrator is the poet Raghuveer Sahay recalling his childhood name "Hajir". His father is Ramavatar Sharma. The "Hajir" in poem is the poet as a child.
- Step 2: Extract poem's maternal imagery: Mother as "thandi hawa", "raat bhar jaagti", "god mein sulati", "sapne mein aati" — nurturing, protective, ever-present.
- Step 3: Identify gap: The prose mentions father's affection (Ram -> Hajir). The poem focuses on mother -> Hajir. The question asks about "two women": mother and "Hajir" (but Hajir is male child). Realize the question likely means: Compare mother's role and father's role (both caregivers). Or compare mother and the narrator's present self? Assume it's a comparative inference between mother's nurturance (poem) and father's affection (prose).
- Step 4: Synthesize Point: "Hajir ke jeevan mein maa ki bhumika nirantar raksha aur mamta ki thi (kavita), jabki pita ki bhumika vishesh sneh aur samman ki thi (gadya)."
- Step 5: Write PEEL with dual evidence: Point (as above). Evidence 1 (Poem): "Stanza 1-4: thandi hawa, raat bhar jaagti, god, sapne." Evidence 2 (Prose): "Hajr Hkkoqd ân; ls crkrs gSa fd jke dk muosQ izfr vR;fèkd izseHkko gSA." Explanation: "Maa ki mamta din-raat, sapne-jaagran sab mein vyapt thi; pita ka sneh 'vishesha' tha — shayad adhik spashth nahi lekin gahra." Link: "Dono ka yog hi Hajir ko 'i'pkr~' (support) deta hai jo uske dfo banne ka adhar bana."
ANSWER: Hajir ke jeevan mein maa ki bhumika nirantar, sarvavyapi mamta aur raksha ki thi (kavita ke char bandon mein 'thandi hava' se 'sapne mein aane' tak), jabki pita (Ramavatar Sharma) ki bhumika 'vishesh sneh' ki thi jo gadya ansh mein 'vR;fèkd izseHkko' ke roop mein ullekhit hai. Maa ki upasthiti har pal mehsoos hoti thi; pita ka sneh ek gahra, shayad alag kism ka adhar tha. Dono ka milajula pyaar hi Hajir ko jeevan ki chunautiyon ka samna karne ka bal deta hai — yahi 'smriti ka bal' hai jo kavi ko dfo banata hai.
DIFFICULTY: hard