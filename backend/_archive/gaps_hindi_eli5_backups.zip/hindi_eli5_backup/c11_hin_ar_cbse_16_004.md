## DEFINITION
Character analysis of the protagonist in poetry involves examining the poetic speaker's persona—their voice, perspective, values, and emotional stance—as revealed through imagery, tone, diction, and thematic concerns, rather than through narrative actions or dialogue.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student can identify the poetic speaker's persona in "vkvks] feydj cpk,¡" by citing specific images and tonal shifts, explain how the speaker's voice embodies a call for social awakening, and write a structured 150-word analysis using the Point-Evidence-Explanation-Link method.

## SCOPE_BOUNDARY
This node covers analysis of the poetic speaker (protagonist) in Fuezyk iqrqy's poem "vkvks] feydj cpk,¡" from Chapter 16, focusing on voice, imagery, tone, and ideological stance. It does NOT cover supporting characters (node 005), plot summary (node 002), or thematic analysis (nodes 006-007) except as they illuminate the speaker's character.

## WALKTHROUGH
Imagine you hear a voice at dawn urging you to wake up—not just from sleep, but from apathy toward injustice around you. That voice is the poetic speaker in this poem. Begin by reading the poem aloud twice: first for the rhythm and sound of words like "vkcks&gok" and "ekVh," then for the progression from darkness to light across the three stanzas. Notice how the speaker doesn't describe themselves directly; instead, their character emerges through what they *call attention to*—the "cfLr;ksa" (students/youth), the "lUFkky ijxuk dh ekVh" (dawn's red hue), the catalog of suffering in stanza 2. Ask: What does the speaker *value*? What angers them? What vision drives them? The key insight: the protagonist here is not a person with a name, but a collective conscience urging transformation.

## DIAGNOSTIC_QUESTION_1
Who is the protagonist in the poem "vkvks] feydj cpk,¡" and how is their presence established in the text?

## DIAGNOSTIC_ANSWER_1
The protagonist is the poetic speaker (kavya-vaktā) who addresses the youth ("cfLr;ksa") in an imperative tone ("cpk,¡"). Their presence is established not through self-description but through the urgent command to awaken, the vivid imagery of dawn ("lUFkky ijxuk dh ekVh"), and the catalog of social suffering they witness. A wrong answer—naming a character from a story or describing a physical person—reveals the student confuses poetic persona with narrative protagonist and hasn't grasped that in lyric poetry, the "I" is a constructed voice, not a biographical individual.

## DIAGNOSTIC_QUESTION_2
Explain in your own words what the phrase "Hkk'kk esa >kj[kaMhiu BaMh gksrh fnup;kZ esa thou dh xekZgV" reveals about the speaker's perspective on language and social change.

## DIAGNOSTIC_ANSWER_2
The phrase means "in language, the revolution of the marginalized occurs in the dawn of life's struggle." It reveals the speaker believes language (Hindi, specifically the Bundeli dialect) is not merely communication but a tool of liberation for the oppressed (" >kj[kaMhiu" = marginalized/subaltern). The speaker sees linguistic expression as inseparable from social revolution. A wrong answer focusing only on "beauty of language" or "morning poetry" misses the political dimension—the speaker's identity as a poet-activist who wields words as weapons against feudal oppression ("f'kf{kr lekt").

## DIAGNOSTIC_QUESTION_3
Apply the PEEL method to analyze how the imagery in the second stanza ("Hkhrj dh vkx / èkuq'k dh Mksjh / rhj dk uqdhykiu...") constructs the speaker's character as a witness to systemic injustice.

## DIAGNOSTIC_ANSWER_3
**Point:** The speaker's character is defined by unflinching witness to feudal cruelty. **Evidence:** Stanza 2 lists visceral images—"Hkhrj dh vkx" (peasant's sweat), "èkuq'k dh Mksjh" (artisan's toil), "rhj dk uqdhykiu" (the poor's hunger), "oqQYgkM+h dh èkkj" (widow's sigh). **Explanation:** By cataloguing specific sufferings without metaphorical distancing, the speaker positions themselves as one who *sees* and *records* truth, refusing aesthetic escape. The accumulation ("taxy dh rk'kk gok / ufn;ksa dh fueZyrk") creates moral weight. **Link:** This witness-role connects to the opening command "cpk,¡"—awakening begins with seeing. A wrong answer listing images without explaining *how* they shape the speaker's ethos shows the student can identify devices but not analyze character construction.

## DIAGNOSTIC_QUESTION_4
Compare the speaker's tone in the opening lines ("vkvks] feydj cpk,¡ / viuh cfLr;ksa dks / uaxh gksus ls") with the tone in the closing lines ("FkksM+k&lk fo'okl / FkksM+h&lh mEehn / FkksM+s&ls lius"). What does this shift reveal about the speaker's evolving role?

## DIAGNOSTIC_ANSWER_4
The opening tone is urgent, imperative, intimate ("vkvks" = come, "feydj cpk,¡" = wake them up)—the speaker as rouser. The closing tone is expansive, visionary, inclusive ("FkksM+k&lk fo'okl" = vast sky, "FkksM+h&lh mEehn" = vast love, "FkksM+s&ls lius" = vast freedom)—the speaker as prophet of a new order. The shift from *command* to *vision* reveals the speaker's character arc: they don't just want awakening; they *embody* the liberated future they summon. A wrong answer calling both tones "hopeful" or "angry" flattens the poem's rhetorical architecture and misses how the speaker's authority grows from moral urgency to transformative possibility.

## DIAGNOSTIC_QUESTION_5
Evaluate the claim: "The poetic speaker in 'vkvks] feydj cpk,¡' represents the poet Fuezyk iqrqy's own voice without mediation." Defend your judgment with textual evidence.

## DIAGNOSTIC_ANSWER_5
The claim is **false**. The speaker is a *constructed persona*—a collective voice of the marginalized (" >kj[kaMhiu") speaking through the specific dialect ("Hkk'kk esa >kj[kaMhiu") and historical consciousness ("laFkkyh lekt... ladV esa gS"). Evidence: the poet's biography (born 1972, teacher, PhD) differs from the speaker's implied location in feudal fields ("Hkhrj," "èkuq'k"). The poem explicitly frames the speaker as emerging *from* feudal society's contradictions ("nksuksa lektksa dh fozQ;k&izfrfozQ;k / ls og cks'k fodflr gqvk"). A wrong answer accepting the claim confuses author with persona—a senior-secondary error that ignores the deliberate artifice of poetic voice.

## DIAGNOSTIC_QUESTION_6
Write a 4-line stanza in the voice of the poetic speaker from "vkvks] feydj cpk,¡" addressing a modern classroom, using at least two images from the original poem.

## DIAGNOSTIC_ANSWER_6
**Sample answer:**
"vkvks, feydj cpk,¡ viuh / ekVh dks uaxh gksus ls /
Hkhrj dh vkx ab Hkh / pkpk gS iklh ls //"
**Criteria:** Uses imperative address ("vkvks, feydj cpk,¡"), echoes "ekVh / uaxh gksus ls" (dawn/awakening), and "Hkhrj dh vkx" (peasant's sweat) to link past injustice to present responsibility. A poor answer would write generic motivational lines ("study hard, succeed") without the poem's specific political vocabulary or the speaker's characteristic fusion of personal and collective awakening.

## COMMON_MISCONCEPTION
Students treat the poetic speaker as either (a) the poet themselves, or (b) a fictional character like in a story. They write: "The protagonist is Fuezyk iqrqy who wakes up students" or "The protagonist is a teacher telling students to wake up." Both miss that the *speaker* is a rhetorical construct—a voice forged from Bundeli dialect, feudal witness, and revolutionary hope—that *performs* the act of awakening through the poem itself. The error stems from applying prose character-analysis tools (name, background, actions) to lyric poetry where character = voice + stance + imagery.

## ON_FAILURE
1. Have the student read the poem aloud *only in Hindi*, marking every verb addressing "cfLr;ksa" (cpk,¡, cpk,¡, laosQr, cpkus). 2. Ask: "Who is speaking these verbs? Does the text ever say 'main Fuezyk iqrqy bol raha hoon'?" 3. Show the NCERT note: "laFkkyh Hkk'kk ls fganh :ikarj v'kksd flag us fd;k gS"—the translator's presence proves mediation. 4. Co-write a PEEL paragraph: **Point** = Speaker is constructed voice. **Evidence** = "Hkk'kk esa >kj[kaMhiu" (dialect of marginalized). **Explanation** = Poet is educated, urban; speaker claims subaltern tongue. **Link** = Therefore, protagonist = poetic persona, not poet.

## BUILDS_ON
c11_hin_ar_cbse_16_002 (Plot and Narrative Structure) – understanding the poem's three-stanza progression from command to catalog to vision is essential before analyzing how the speaker's character unfolds across that structure.

## LEADS_TO
c11_hin_ar_cbse_16_005 (Character Analysis: Supporting Characters) – the "cfLr;ksa" (youth) addressed by the speaker function as the poem's implied audience/secondary figures; analyzing them next deepens understanding of the speaker's relational stance.

## PREREQUISITE_NODE_IDS
c11_hin_ar_cbse_16_001, c11_hin_ar_cbse_16_002, c11_hin_ar_cbse_16_003
## PREREQUISITE_REASONS
c11_hin_ar_cbse_16_001: Context node provides feudal society background and poet's biography needed to distinguish persona from author.
c11_hin_ar_cbse_16_002: Plot/structure node establishes the three-stanza arc (awakening → witness → vision) that shapes the speaker's evolving role.
c11_hin_ar_cbse_16_003: Setting/atmosphere node covers the dawn imagery ("lUFkky ijxuk dh ekVh") that constitutes the speaker's symbolic landscape.

## FORWARD_NODE_IDS
c11_hin_ar_cbse_16_005, c11_hin_ar_cbse_16_006, c11_hin_ar_cbse_16_008, c11_hin_ar_cbse_16_013, c12_hin_ar_cbse_06_004

## FORWARD_REASONS
c11_hin_ar_cbse_16_005: The addressed "cfLr;ksa" become supporting characters whose implied response completes the speaker's dramatic situation.
c11_hin_ar_cbse_16_006: The speaker's ideological stance (anti-feudal, pro-marginalized) *is* the primary theme; theme analysis requires protagonist analysis first.
c11_hin_ar_cbse_16_008: Imagery/metaphor node examines how "ekVh," "vkcks&gok," "Hkhrj dh vkx" construct the speaker's vision—direct extension of character analysis.
c11_hin_ar_cbse_16_013: Critical thinking node asks students to evaluate interpretations of the speaker's revolutionary ethics—requires this node's foundation.
c12_hin_ar_cbse_06_004: Class 11 Character Analysis: Protagonist (c11_hin_ar_cbse_01_004 through c11_hin_ar_cbse_16_004) where students learned to extract traits from actions/dialogue in prose narratives — now transferred to poetic personification.  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
none

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_16_001 -> c11_hin_ar_cbse_16_002 -> c11_hin_ar_cbse_16_003 -> c11_hin_ar_cbse_16_004 -> c11_hin_ar_cbse_16_005 -> c11_hin_ar_cbse_16_006

## THIS_FORMULA
N/A - conceptual

## FORMULA_VARIABLES
N/A

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
conceptual

## CROSS_SUBJECT
c11_history_social_change | The poem's speaker embodies the transition from feudal to modern consciousness, mirroring History's analysis of 19th-20th century Indian social reform movements where language and education were tools of awakening.
c11_sociology_stratification | The catalog of sufferings ("Hkhrj dh vkx," "rhj dk uqdhykiu," "oqQYgkM+h dh èkkj") maps directly onto Sociology's study of caste-class-gender intersectionality in rural power structures.

## PREREQ_CONCEPT
Distinction between *author* (biographical person) and *persona* (constructed poetic voice) – the foundational concept for all lyric poetry analysis at senior secondary level.

## PREREQ_BEFORE
Student must know that in poetry, "I" ≠ poet necessarily; the speaker is a literary device shaped by diction, imagery, tone, and ideological stance.

## PREREQ_STUCK
Review the concept of "kavya-vaktā" (poetic speaker) from Class 10 Hindi (Kshitij/Kritika) – specifically how the speaker in "Megh Aaye" or "Sabse Khatarnak" is a crafted voice, not the poet.

## WORKED_EXAMPLE_1
PROBLEM: Analyze how the opening address "vkvks] feydj cpk,¡ / viuh cfLr;ksa dks / uaxh gksus ls" establishes the speaker's character in the first three lines. Use PEEL structure.

STEPS:
- Step 1: Identify the grammatical mood and addressee – imperative "cpk,¡" (wake up) directed at "cfLr;ksa" (students/youth), with "vkvks" (come) creating spatial intimacy.
- Step 2: Note the causal phrase "uaxh gksus ls" (from becoming awake/conscious) – the speaker doesn't just want physical waking but consciousness-raising.
- Step 3: Connect to the poem's epigraph context: "vkvks] feydj cpk,¡" is a command to *mediate* awakening for others, positioning the speaker as catalyst, not sleeper.
- Step 4: Interpret character traits: urgency (no polite "kripya"), authority (imperative mood), collective orientation ("viuh cfLr;ksa" = your students, implying speaker stands outside/above), moral purpose (awakening as end-in-itself).
- Step 5: Link to central idea – this opening encapsulates the speaker's entire role: the one who *sees* the need for awakening and *acts* to trigger it.

REASONING: The PEEL method forces movement from textual detail (mood, vocabulary) to character inference (traits) to thematic significance (role in poem's argument). Each step builds on the previous: grammar → pragmatics → positioning → characterization → thematic function.

ANSWER: The speaker emerges as an urgent, authoritative moral catalyst who positions themselves outside the slumbering collective ("cfLr;ksa") to ignite consciousness ("uaxh gksus ls"). The imperative "vkvks, feydj cpk,¡" establishes spatial and ethical proximity—speaker comes *to* the addressee to wake *their* charges. This is not a teacher giving routine instruction; it is a revolutionary summons where "awakening" = political consciousness. The speaker's character is thus defined by *initiative* (they come), *mediation* (they wake others through the addressee), and *purpose* (consciousness, not mere activity).

## WORKED_EXAMPLE_2
PROBLEM: The second stanza lists 12 concrete images of suffering ("Hkhrj dh vkx" through "cw<+ksa osQ fy, igkM+ksa dh 'kkfUr"). Explain how this catalog constructs the speaker as a *witness* rather than a *reformer*. Use specific lines.

STEPS:
- Step 1: Define the distinction – a *reformer* proposes solutions; a *witness* testifies to truth without immediate remedy.
- Step 2: Analyze the syntactic structure – 12 noun phrases in apposition, no verbs of action, no "should/must." Example: "Hkhrj dh vkx / èkuq'k dh Mksjh" (peasant's sweat / artisan's toil) – pure nomination.
- Step 3: Note the absence of the speaker's "I" – the stanza is entirely third-person objective, creating documentary effect.
- Step 4: Connect to the feudal context from node 001 – these are not abstract symbols but specific feudal exploitations: "taxy dh rk'kk gok" (tax collector's whip), "jksus osQ fy, eq_h Hkj" (for daughters, dowry burden).
- Step 5: Conclude – the speaker's character gains moral authority *through* this refusal to rush to solutions; they force the reader (and the "cfLr;ksa") to *see* first.

REASONING: This analysis moves from syntactic observation (noun phrases, no verbs) to generic distinction (witness vs. reformer) to historical grounding (feudal specifics) to character function (moral authority through restraint). The 12-item list is not decoration—it is the speaker's evidentiary method.

ANSWER: The speaker constructs themselves as a witness by presenting suffering as *inventory*, not argument. The stanza's 12 noun phrases—"Hkhrj dh vkx," "èkuq'k dh Mksjh," "rhj dk uqdhykiu," "oqQYgkM+h dh èkkj," "taxy dh rk'kk gok," "ufn;ksa dh fueZyrk," "igkM+ksa dk ekSu," "xhrksa dh èkqu," "fe^h dk lksaèkkiu," "iQlyksa dh ygygkgV," "ukpus osQ fy, [kqyk vk¡xu," "xkus osQ fy, xhr"—accumulate without commentary, verbs, or prescriptions. This syntactic stillness mirrors the feudal world's inertia. The speaker *withholds* the "cpk,¡" (wake up) of stanza 1, forcing the images to speak. Character insight: the speaker knows awakening *requires* this unmediated seeing; reform without witness is hollow. The final triplet ("FkksM+k&lk fo'okl / FkksM+h&lh mEehn / FkksM+s&ls lius") only becomes possible *after* this witnessing.

## WORKED_EXAMPLE_3
PROBLEM: Synthesize nodes 001, 002, and 004 to write a 150-word board-style answer: "How does the poetic speaker in 'vkvks] feydj cpk,¡' embody the transition from feudal to modern consciousness? Support with three textual evidences."

STEPS:
- Step 1: Retrieve context from node 001 – poet born 1972 in feudal Bundelkhand, witnessed "nksuksa lektksa dh fozQ;k&izfrfozQ;k" (clash of two societies), educated in both traditions.
- Step 2: Retrieve structure from node 002 – three stanzas = three stages: summons (stanza 1), testimony (stanza 2), vision (stanza 3).
- Step 3: Map speaker's evolution across stanzas using node 004 analysis – Stage 1: imperative voice ("cpk,¡") = modern rational agent interrupting feudal torpor. Stage 2: documentary gaze ("Hkhrj dh vkx...") = modern empirical witness naming feudal crimes. Stage 3: expansive vision ("FkksM+k&lk fo'okl") = modern citizen imagining liberty/equality/fraternity.
- Step 4: Select three precise evidences: (i) "Hkk'kk esa >kj[kaMhiu BaMh" – language as revolutionary tool (modern) vs. feudal silence. (ii) "laFkkyh lekt... ladV esa gS" – speaker located *in* the contradiction (transitional). (iii) "FkksM+s&ls lius" – freedom as boundless sky (modern universal) vs. feudal enclosure.
- Step 5: Draft PEEL paragraphs integrating all three nodes – each evidence gets Point-Evidence-Explanation-Link.
- Step 6: Edit for board-exam conciseness: topic sentence, integrated quotes, analytical verbs (embodies, mediates, testifies, envisions), concluding thematic sentence.

REASONING: This worked example models the *synthesis* expected in board exams—combining context, structure, and character analysis into one coherent argument. The 6 steps mirror the cognitive progression: recall → structural mapping → character-tracing → evidence selection → structured writing → exam-style polishing.

ANSWER: The poetic speaker embodies the feudal-to-modern transition through a three-stage consciousness mirrored in the poem's tripartite structure. First, as imperative catalyst ("vkvks, feydj cpk,¡ / viuh cfLr;ksa dks / uaxh gksus ls"), the speaker enacts the modern rational subject interrupting feudal passivity—awakening is not religious salvation but cognitive-political act. Second, as documentary witness ("Hkhrj dh vkx / èkuq'k dh Mksjh / rhj dk uqdhykiu..."), the speaker deploys empirical gaze to name feudal exploitation (tax, dowry, caste labor) that tradition naturalized; the 12 noun-phrases without verbs constitute testimony, not lament. Third, as visionary architect ("FkksM+k&lk fo'okl / FkksM+h&lh mEehn / FkksM+s&ls lius"), the speaker articulates modernity's trinity—space, solidarity, liberty—transcending feudal enclosure. Crucially, the speaker *mediates* this transition: "laFkkyh lekt... ladV esa gS" locates them *within* the contradiction, while "Hkk'kk esa >kj[kaMhiu BaMh" claims subaltern language as revolutionary instrument. The speaker is thus neither feudal subject nor modern citizen alone, but the *threshold figure* through which the poem thinks the transition.

## COMPETENCY_QUESTION_1
QUESTION: A student writes: "The protagonist of the poem is the poet himself, Fuezyk iqrqy, who wants students to wake up early and study hard." Identify two specific errors in this statement and correct them using the distinction between poet and persona.

COMPETENCY: Critical interpretation – distinguishing author from constructed poetic voice.

STEPS:
- Step 1: Identify Error 1 – conflation of poet (biographical) with persona (literary construct).
- Step 2: Identify Error 2 – reduction of "uaxh gksus" (consciousness-raising) to literal "wake up early and study."
- Step 3: Correct Error 1 using node 001 context: poet is 1972-born PhD teacher; speaker claims "Hkk'kk esa >kj[kaMhiu" (subaltern dialect).
- Step 4: Correct Error 2 using node 004 analysis: "cpk,¡" is metaphor for socio-political awakening, evidenced by stanza 2's feudal suffering catalog.

ANSWER: Error 1: The statement confuses the *poet* (Fuezyk iqrqy, a 20th-century educated academic) with the *poetic persona* (a voice emerging from "laFkkyh lekt... ladV" speaking in ">kj[kaMhiu" dialect). The NCERT note confirms translation from Bundeli – the speaker's linguistic identity differs from the poet's. Error 2: "uaxh gksus ls" and "cpk,¡" are metaphorical for *critical consciousness* ("chetnā"), not literal sleep. The speaker addresses "cfLr;ksa" to awaken them to feudal injustice ("Hkhrj dh vkx," "oqQYgkM+h dh èkkj"), not to morning tuition. Correction: The protagonist is a constructed revolutionary voice that *mediates* awakening for the youth through poetic testimony.

DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: "The speaker's authority in 'vkvks] feydj cpk,¡' derives not from individual charisma but from collective testimony." Defend or challenge this statement by analyzing how the poem's imagery shifts from singular command (stanza 1) to plural suffering (stanza 2) to universal vision (stanza 3).

COMPETENCY: Synthetic analysis – integrating character, structure, and imagery across the whole poem.

STEPS:
- Step 1: Analyze stanza 1 – singular imperative ("vkvks, feydj cpk,¡") addresses one addressee ("viuh cfLr;ksa") – appears individual/charismatic.
- Step 2: Analyze stanza 2 – 12 third-person images create *collective* portrait of suffering; speaker disappears as "I," becomes recording consciousness.
- Step 3: Analyze stanza 3 – plural expansive nouns ("fo'okl," "mEehn," "lius") with no possessive – vision belongs to all, not speaker.
- Step 4: Synthesize – the speaker's authority *shifts* from individual command (stanza 1) to evidentiary weight of collective suffering (stanza 2) to shared futurity (stanza 3).
- Step 5: Conclude – the statement is *partially true but incomplete*: authority begins in individual summons but *derives its legitimacy* from collective testimony and *culminates* in universal vision. The speaker is the *vehicle*, not the *source*.

ANSWER: The statement is defensible with qualification. Stanza 1's "vkvks, feydj cpk,¡" presents a singular, urgent voice – seemingly charismatic authority. But stanza 2 immediately dissolves this individuality: 12 noun-phrases ("Hkhrj dh vkx" through "cw<+ksa osQ fy, igkM+ksa dh 'kkfUr") accumulate without an "I," making the speaker a *medium* for collective suffering. The authority to command awakening *comes from* this testimony – the speaker speaks *because* they have witnessed. Stanza 3 confirms: "FkksM+k&lk fo'okl / FkksM+h&lh mEehn / FkksM+s&ls lius" uses no possessive pronoun; the vision is impersonal, universal. Thus: authority originates in individual summons but is *grounded* in collective witness and *dissolved* into shared futurity. The speaker is the threshold where individual voice becomes collective conscience.

DIFFICULTY: hard