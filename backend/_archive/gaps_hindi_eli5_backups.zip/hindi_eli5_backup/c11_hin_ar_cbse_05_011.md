## DEFINITION
Language Usage in the Text refers to the systematic analysis of grammatical structures, syntactical patterns, lexical choices, and discourse features employed by the author in the chapter "xyrk yksgk" to convey meaning, characterize speakers, reflect socio-cultural context, and achieve stylistic effects. It includes the study of tense/aspect distribution, direct-indirect speech transformation, compound word formation (samasa), dialectal variations, and the functional use of suffixes/prefixes (kridanta/taddhita) within the narrative.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student can independently identify at least three distinct grammatical features in any given excerpt from the chapter, explain their contextual function with textual evidence, and accurately transform direct speech passages into indirect speech while preserving the original tone and speaker identity.

## SCOPE_BOUNDARY
This node covers grammar analysis strictly within the NCERT Chapter 5 "xyrk yksgk" text and its end-of-chapter exercises (Hkk"kk dh ckr). It does not cover general Hindi grammar rules unrelated to the text, nor does it address poetry-specific prosody. Focus is on: tense usage (cwrs), speech conversion (loZuke), compound verbs/words (dkV&Nk¡Vdj types), suffix-derived vocabulary (ykSgdeZ), and dialectal markers.

## WALKTHROUGH
Imagine you are a detective examining a crime scene – the "crime" is the author's craft, and the "clues" are the grammatical choices. Start by asking: "Why does the author use past tense (cwrs) in the opening paragraph but switch to present tense in dialogue?" First, scan the text for all verbs and mark their tense. Next, hunt for compound verbs like "dkV&Nk¡Vdj" – break them into component verbs and ask what nuance the combination adds. Then, locate the four direct speech sentences on page 66 (eksgu! FkksM+k ngh...) and practice converting them to indirect speech step-by-step. Finally, connect these findings to character: how does the rustic imperative mood of the mother reveal her authority? The key insight: grammar is not abstract rules; it is the DNA of the author's voice.

## DIAGNOSTIC_QUESTION_1
Identify the grammatical term for the word formation process seen in "dkV&Nk¡Vdj" (page 56) and "fdukjs mx" (page 56) where two verbs combine to express a single complex action.

## DIAGNOSTIC_ANSWER_1
The term is **compound verb (saMyukta kriya / dvikriyaka)** – specifically a **conjunctive participle + main verb** structure (absolutive + finite verb) where the first verb (dkV, mx) indicates the manner/means and the second (Nk¡Vdj, vkbZ) completes the action. A wrong answer like "samasa" (compound noun) reveals confusion between nominal and verbal compounding; a wrong answer like "kriya visheshan" (adverb) shows inability to recognize the verbal nature of the construction.

## DIAGNOSTIC_QUESTION_2
Explain in your own words why the author uses the past habitual tense (cwrs) in the sentence "lkekU; rkSj ls czkã.k Vksys osQ yksxksa dk f'kYidkj Vksys esa mBuk&cSBuk ugha gksrk Fkk" (page 63) instead of simple past.

## DIAGNOSTIC_ANSWER_2
The past habitual (cwrs) indicates a **repeated/customary social practice** over time – "used to not be allowed" – establishing the systemic, long-standing nature of caste segregation. Simple past would denote a single completed event. A wrong answer focusing only on "past time" misses the aspectual nuance of *repetition/custom* crucial for depicting social structure. This misunderstanding shows the student treats tense as only time-deictic, not aspectual.

## DIAGNOSTIC_QUESTION_3
Convert the following direct speech from page 66 into correct indirect speech (loZuke), making all necessary changes to pronouns, tense, and reporting verb:
"eksgu! FkksM+k ngh rks yk ns ck”kkj lsA"

## DIAGNOSTIC_ANSWER_3
**Steps:**
1. Identify reporting verb (implied "dgk" / said) and reported speech (imperative request).
2. Change imperative to infinitive construction with "yksdj" (requested to) or "vuqjks/k" (ordered to) – here mother's tone is affectionate command → "yksdj".
3. Adjust pronouns: "eksgu" (vocative) → "eksgu dks" (object); "ck”kkj ls" (adverb) remains.
4. Tense: No tense change for imperative→infinitive.
**Result:** "firk us eksgu dks FkksM+k ngh yk ns ck”kkj ls yksdjA" (Mother requested Eksgu to give a little water affectionately.)
A wrong answer retaining "yk ns" (imperative) or failing to add "dks" after "eksgu" shows incomplete mastery of speech conversion rules for imperative sentences.

## DIAGNOSTIC_QUESTION_4
Analyze the function of the dialectal word "/kSaduh" (page 66, defined as "yqgkj ;k lqukjksa dh vkx ngdkus okyh yksgs ;k ck¡l dh uyh") in the narrative. Why does the author choose this specific regional term instead of standard Hindi "bailgadi" or "thela"?

## DIAGNOSTIC_ANSWER_4
The word "/kSaduh" serves three functions: (1) **Authenticates setting** – grounds the story in the specific rural Uttar Pradesh locale (Avadhi/Bhojpuri belt). (2) **Characterizes speakers** – used by/for villagers (f=kyksd flag, eksgu), marking their identity vs. urban narrator. (3) **Thematic reinforcement** – the slow, animal-drawn vehicle symbolizes the stagnant, tradition-bound social mobility of the lower caste. A wrong answer like "it's just a synonym" ignores the sociolinguistic signaling; the student fails to see language as a carrier of caste/geography identity.

## DIAGNOSTIC_QUESTION_5
Evaluate the effectiveness of the author's use of the suffix "-u" (as in "vuqxw¡t", "izfr}a}h", "lsozsQVsfj;V") in the vocabulary list (page 67) for building abstract nouns from roots. Does this morphological pattern enhance or obscure meaning for a Class 11 student? Justify.

## DIAGNOSTIC_ANSWER_5
**Evaluation: Enhances meaning** – the suffix "-u" (taddhita pratyaya forming abstract nouns denoting state/quality/action) creates precise terminology: "vuqxw¡t" (state of being unexpected), "izfr}a}h" (quality of being responsible), "lsozsQVsfj;V" (state of being retired). These are *transparent derivations* – root + suffix = predictable meaning. This aids vocabulary expansion (decoding new words). However, obscure roots like "lsozsQV" (from English "superannuation") reduce transparency. A student calling it "obscure" likely lacks morphological awareness (root+suffix analysis) and treats words as unanalyzable wholes.

## DIAGNOSTIC_QUESTION_6
Create two new sentences using the compound verb pattern "Verb1 (absolutive) + Verb2 (finite)" found in the text (like "dkV&Nk¡Vdj", "mx vkbZ"), where Verb1 is a body-action verb (hands/feet/eyes) and Verb2 is a motion/completion verb. Translate both to Hindi.

## DIAGNOSTIC_ANSWER_6
**Criteria for good answer:**
- Verb1 must be absolutive form (ending in -kar/-ke or dialectal -dj).
- Verb2 must be finite (conjugated).
- Semantic link: V1 = manner/means, V2 = core action.
**Example 1:** "She wiped her tears and left." → "oh viuh vfHk;ksa dks iMr dj xbZA" (iMr = wipe, xbZ = went).
**Example 2:** "He grabbed the rope and climbed." → "uls us rjQ ekj dj /kkjsA" (ekj = grab, /kkjs = climbed).
A poor answer uses two finite verbs ("iMrk xbZ") or wrong aspect ("iMrus xbZ"), showing failure to internalize the absolutive+finite template.

## COMMON_MISCONCEPTION
Students believe "grammar in text" means merely **labeling parts of speech** (noun, verb, tense) in isolated sentences. They miss that in senior secondary, the exam asks: *"How does the use of past habitual in paragraph 3 reflect the social rigidity of the village?"* or *"Why is the mother's speech in direct imperative while the narrator uses indirect past?"* The error stems from Class 10's focus on identification exercises; they haven't shifted to **functional analysis** – grammar as a tool for characterization, theme, and dialect representation. For example, they will underline "ck”kkj" as "adverb" but not explain how its repetition in four consecutive imperatives (page 66) builds the mother's nurturing urgency.

## ON_FAILURE
1. **Isolate the pattern**: Give the student only the four imperative sentences (page 66). Have them convert each to indirect speech using a 3-column table: Direct | Reporting Verb Change | Indirect Result. Drill the pronoun/tense shifts until automatic.
2. **Morphology bootcamp**: Provide 10 words from the text with suffixes (-u, -pan, -hat, -ai). Student writes: Root + Suffix = Derived Word + Literal Meaning. Example: "izfr}a}h" = izfr} + u = responsibility = "state of answering for". Builds analytical habit.
3. **Dialect hunt**: Assign: "Find 5 words in the story not in standard Hindi dictionary. Write their standard equivalent + effect of using dialect version." Forces attention to sociolinguistic choice.
4. **Connect to theme**: Ask: "Pick one compound verb (dkV&Nk¡Vdj). If author used simple verb 'Nk¡Vdj' alone, what nuance is lost?" Trains functional thinking.

## BUILDS_ON
c11_hin_ar_cbse_05_010 (Vocabulary in Context: Key Words) – students must know the meanings of key terms like "/kSaduh", "vuqxw¡t", "izfr}a}h" before analyzing their grammatical formation.

## LEADS_TO
c11_hin_ar_cbse_05_012 (Comprehension: Literal and Inferential Questions) – grammatical analysis provides evidence for inferential answers (e.g., tense choice reveals narrator's distance from events).

## PREREQUISITE_NODE_IDS
c11_hin_ar_cbse_05_002, c11_hin_ar_cbse_05_010, c11_hin_ar_cbse_05_008
## PREREQUISITE_REASONS
c11_hin_ar_cbse_05_002: Understanding plot/narrative structure is needed to locate where specific grammatical features appear (e.g., cwrs in exposition vs. dialogue).
c11_hin_ar_cbse_05_010: Vocabulary node provides meanings of key grammatical terms (ykSgdeZ, samasa, loZuke) and dialect words used in exercises.
c11_hin_ar_cbse_05_008: Literary devices node covers irony/symbolism; grammar analysis often reveals how syntactic choices create irony (e.g., polite indirect speech masking caste insult).

## FORWARD_NODE_IDS
c11_hin_ar_cbse_05_012, c11_hin_ar_cbse_05_013, c11_hin_ar_cbse_05_014, c11_hin_ar_cbse_05_015, c12_hin_a_cbse_04_011, c12_hin_a_cbse_05_011, c12_hin_a_cbse_09_011, c12_hin_a_cbse_11_011, c12_hin_a_cbse_12_011, c12_hin_a_cbse_17_011, c12_hin_ar_cbse_01_011, c12_hin_ar_cbse_02_011, c12_hin_ar_cbse_05_011, c12_hin_ar_cbse_07_011, c12_hin_ar_cbse_09_011, c12_hin_ar_cbse_10_011, c12_hin_ar_cbse_11_011

## FORWARD_REASONS
c11_hin_ar_cbse_05_012: Comprehension questions require grammatical evidence (e.g., "How does the use of past habitual support the theme of unchanging tradition?").
c11_hin_ar_cbse_05_013: Critical thinking demands analysis of author's linguistic choices as craft – e.g., why direct speech for mother, indirect for narrator?
c11_hin_ar_cbse_05_014: Writing skills (article/speech) require demonstrating command of reported speech, compound verbs, and appropriate register – all practiced here.
c11_hin_ar_cbse_05_015: Grammar usage (direct/indirect speech, tense shifts in flashback) aids fluent articulation.  
c12_hin_a_cbse_04_011: अगला तार्किक चरण: This node analyzes the grammatical structures, syntactic patterns, and language usage specific to th... इस नोड की अवधारणाओं को सीधे उपयोग/विस्तारित करता है।  
c12_hin_a_cbse_05_011: Class 11 integration of grammar with theme interpretation  
c12_hin_a_cbse_09_011: Covered *kriya visheshan* — helps distinguish compound verbs (Diagnostic 2) from adverbials.  
c12_hin_a_cbse_11_011: Introduces register analysis (Sanskritized/Persianized/Dialectal) — basis for vocabulary comparison across three stories.  
c12_hin_a_cbse_12_011: Worked examples of compound verb constructions (aspectual verbs)  
c12_hin_a_cbse_17_011: Practiced linking grammatical form to semantic nuance — core skill for this node.  
c12_hin_ar_cbse_01_011: Practice with causative and compound verb constructions in poetry.  
c12_hin_ar_cbse_02_011: Building analytical skills across texts.  
c12_hin_ar_cbse_05_011: Class 11 Grammar node establishes baseline terminology (kriya visheshan, samas, vakya bhed) required to name forms in Class 12 analysis.  
c12_hin_ar_cbse_07_011: Vocabulary overlap (tatsam/tadbhav) with current chapter.  
c12_hin_ar_cbse_09_011: Expands repertoire of analysed poems for comparative reference.  
c12_hin_ar_cbse_10_011: Analysis of verb morphology variations (Chapter 5).  
c12_hin_ar_cbse_11_011: Practices proverb/idiom grammatical structure analysis  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
none

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_05_002 -> c11_hin_ar_cbse_05_011 -> c11_hin_ar_cbse_05_012

## THIS_FORMULA
**Direct to Indirect Speech Conversion (Imperative Sentences):**
Reported Speech (Imperative) → Reporting Verb (requested/ordered/advised) + Object + Infinitive (verb root + -na/-ne) + Adverbials (retained).
**Compound Verb Identification:**
Verb1 (Absolutive: root + -kar/-ke/-dj) + Verb2 (Finite: conjugated) = Single Predicate [V1 = Manner/Means, V2 = Core Action].

## FORMULA_VARIABLES
- Reporting Verb: The verb introducing the speech (e.g., dgk, yksdj, vuqjks/k).
- Object: The listener addressed in direct speech (vocative becomes dative with -ko/-dks).
- Infinitive: The base verb + -na (e.g., yk -> ykna).
- Absolutive: Non-finite verb form ending in -kar/-ke (standard) or -dj (dialectal) indicating prior/completed action.
- Finite Verb: Main conjugated verb agreeing with subject.

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
linguistic

## CROSS_SUBJECT
c11_history_medieval_india | The dialect words (/kSaduh, g¡lqos, fugkbZ) reflect the linguistic landscape of medieval/early modern North Indian villages, similar to how historical sources use period-specific terminology to reconstruct social life.
c11_sociology_indian_society | The grammatical contrast between the narrator's standard Hindi (indirect, past habitual) and characters' dialect (direct, imperative) mirrors the sociological concept of "restricted vs. elaborated code" (Bernstein) and caste-based linguistic stratification.

## PREREQ_CONCEPT
Student must understand the difference between **finite** and **non-finite** verb forms (kriya rup) and the concept of **karaka** (case roles: karta, karma, karana) to analyze speech conversion and compound verbs.

## PREREQ_BEFORE
Student should be able to identify the subject, object, and verb in a simple Hindi sentence and recognize the three tenses (vartaman, bhoot, bhavishya) in their habitual/progressive/simple aspects.

## PREREQ_STUCK
If stuck, review **Class 10 Hindi B Vyakaran: Kriya (Verb) – finite vs. non-finite forms, and Vachya (Voice) – direct/indirect speech rules**. Specifically practice converting 10 imperative sentences to indirect speech daily for a week.

## WORKED_EXAMPLE_1
PROBLEM: In the opening paragraph (page 54), the author writes: "varj dh ?kqeM+rh osnuk dks vk¡[kksa dh jkg ckgj fudky ysus ij euq"; tks Hkh fu'p; djrk gS os Hkkoqd {k.kksa dh vis{kk vfèkd foosdiw.kZ gksrs gSa". Identify the tense/aspect of the main verbs ("fudky ysus", "fu'p; djrk", "gksrs") and explain how this grammatical choice frames the narrative perspective.

STEPS:
- Step 1: Isolate the three verb phrases: "fudky ysus" (having seen), "fu'p; djrk" (does/does habitually), "gksrs" (become/habitually become).
- Step 2: Analyze each: "fudky ysus" = perfective participle (absolutive) of "fudkyuk" (to see) – antecedent action. "fu'p; djrk" = present habitual (vartaman abhyas) – generic truth. "gksrs" = present habitual plural – generic consequence.
- Step 3: Determine subject for each: "euq"; tks Hkh" (whoever) is subject of "fu'p; djrk"; "os" (they) is subject of "gksrs". The absolutive "fudky ysus" shares the implied subject "euq";".
- Step 4: Synthesize function: The mix of perfective (specific past perception) + habitual (general truth) creates a **gnomic present** – the narrator states a universal psychological principle observed in the past but true always. This elevates a personal memory to thematic statement.
- Step 5: Connect to narrative frame: This opening establishes the narrator as a reflective adult analyzing childhood through a sociological lens, not just recounting events.

REASONING: The shift from perfective (specific past) to habitual (timeless generalization) is a classic narrative strategy to move from anecdote to thesis. The student must track aspect (perfective vs. habitual) not just tense (past vs. present).

ANSWER: Verbs: "fudky ysus" (perfective participle/absolutive), "fu'p; djrk" (present habitual), "gksrs" (present habitual). The grammatical framing presents the narrator's childhood observation as a validated universal truth – the specific past seeing ("fudky ysus") leads to a timeless generalization ("fu'p; djrk gksrs"), positioning the narrator as an analyst of social psychology.

## WORKED_EXAMPLE_2
PROBLEM: On page 66, the text gives four direct speech commands by the mother to Eksgu. Convert all four into a single paragraph of indirect speech, maintaining the sequence and the affectionate yet authoritative tone.

STEPS:
- Step 1: List the four sentences with implied reporting verbs:
  1. "eksgu! FkksM+k ngh rks yk ns ck”kkj lsA" (Request/affectionate command)
  2. "eksgu! ;s diM+s èkksch dks ns rks vkA" (Command to give)
  3. "eksgu! ,d fdyks vkyw rks yk nsA" (Request for water)
  4. (Implied context) Mother repeatedly calls him with needs.
- Step 2: Choose reporting verbs: "yksdj" (requested) for #1, #3 (polite/affectionate); "vuqjks/k" (ordered/told) for #2 (direct command).
- Step 3: Convert each:
  1. firk us eksgu dks FkksM+k ngh yk ns ck”kkj ls yksdjA
  2. firk us eksgu dks ;s diM+s èkksch nsus dks vuqjks/kA
  3. firk us eksgu dks ,d fdyks vkyw yk ns yksdjA
- Step 4: Combine into coherent paragraph using connectives (phir, uske baad, antim mein): "Phir firk us eksgu dks FkksM+k ngh yk ns ck”kkj ls yksdj. Uske baad usne eksgu dks ;s diM+s èkksch nsus dks vuqjks/k. Antim mein firk us eksgu dks ,d fdyks vkyw yk ns yksdj."
- Step 5: Verify pronoun/tense consistency: All third person past, infinitives correct, honorifics maintained (firk us, eksgu dks).

REASONING: Board exams often ask to convert a *set* of direct speeches into a narrative paragraph (not isolated sentences). This tests ability to manage discourse cohesion (connectives) alongside grammatical conversion.

ANSWER: "Phir firk us eksgu dks FkksM+k ngh yk ns ck”kkj ls yksdj. Uske baad usne eksgu dks ;s diM+s èkksch nsus dks vuqjks/k. Antim mein firk us eksgu dks ,d fdyks vkyw yk ns yksdj." (Then mother requested Eksgu to give a little water affectionately. After that she ordered Eksgu to give those two biscuits. Finally mother requested Eksgu to give a glass of water.)

## WORKED_EXAMPLE_3
PROBLEM: The word "lsozsQVsfj;V" appears in the vocabulary list (page 67) defined as "lfpoky;". Analyze its morphological structure, identify the root language, explain the suffixation process, and discuss why the author might include this Anglicism in a rural dialect-heavy story.

STEPS:
- Step 1: Segment the word: "lksozsQV" + "sfj;V". Recognize "lksozsQV" as transliteration of English "superannuation".
- Step 2: Identify suffix "-sfj;V" (from English "-tion" via Hindi phonological adaptation) forming abstract noun from verb/noun stem.
- Step 3: Trace root: English "superannuate" (verb) → "superannuation" (noun) → Hindi phonetic borrowing "lksozsQVsfj;V".
- Step 4: Analyze semantic shift: Original meaning "retirement due to age/invalidity" → in text context (page 62) "fu;qfDr gks xbZ gS vkSj 'kh?kz gh foHkkxh; ijh{kk,¡ nsdj og cM+s in ij igq¡p tk,xk" – used for a school peon's retirement with pension benefits.
- Step 5: Evaluate authorial purpose: The word enters the village via the school system (modern institution). Its use by the narrator (educated, urbanized) vs. absence in villagers' speech highlights the **intrusion of bureaucratic modernity into traditional rural life**. It contrasts with dialect words like "/kSaduh", "g¡lqos".
- Step 6: Connect to theme: The peon's retirement (lsozsQVsfj;V) triggers the crisis – Eksgu's father loses his meager income, pushing Eksgu toward the city. A single borrowed noun encapsulates the disruptive force of state modernity on caste-bound village economy.

REASONING: Senior secondary exams test *morphological analysis of loanwords* and *sociolinguistic interpretation*. Students must move beyond "meaning" to "morphology + register + thematic function".

ANSWER: Morphology: English loan "superannuation" → Hindi "lksozsQVsfj;V" (root "lksozsQV" + suffix "-sfj;V"). It is a **tatsama-like borrowing** (English → Hindi) denoting institutional retirement. Author includes it to mark the narrator's educated register and to symbolize the modern bureaucratic event that disrupts the traditional village economy, contrasting with indigenous vocabulary like "/kSaduh".

## COMPETENCY_QUESTION_1
QUESTION: The narrator describes his father's reaction to the peon's retirement news: "èkujke dks f=kyksd flag ekLVj dh Hkfo";ok.kh ij iwjk ;dhu Fkkµ ,slk gksuk gh Fkk mlus lkspkA" (page 62). The verb "lkspk" (past habitual) is used instead of "lkspk" (simple past – same form but different aspect). How does the **past habitual aspect** here characterize the father's mindset differently from simple past would? Support with two textual evidences from earlier/later in the story.

COMPETENCY: Analyzing aspectual nuance for character portrayal (Literary Analysis + Grammar)

STEPS:
- Step 1: Identify the aspect: "lkspk" here is past habitual (abhyas) because of context "iwjk ;dhu Fkkµ ,slk gksuk gh Fkk" (it was exactly as he had expected) – indicating a *repeated pattern of confirmed suspicions*, not a single thought.
- Step 2: Explain difference: Simple past "lkspk" (he thought at that moment) → momentary cognition. Past habitual "lkspk" (he used to think / it was his habit to think) → ingrained mindset, cynicism born of repeated betrayal.
- Step 3: Find Evidence 1: Page 58 – "èkujke us dHkh eksgu dks viuk izfr}a}h ugha le>k cfYd og bls eksgu dk vfèkdkj gh le>rk jgk Fkk" (Father never understood Eksgu as responsible, kept considering him a servant). "le>rk jgk Fkk" (past progressive/habitual) shows persistent attitude.
- Step 4: Find Evidence 2: Page 62 – "f=kyksd flag ekLVj dh ckrksa osQ lkFk&lkFk cpiu ls ysdj vc rd osQ thou osQ dbZ izlaxksa ij eksgu vkSj èkujke ckrsa djrs jgsA" (Father and son discussed Thakur's affairs habitually). "ckrsa djrs jgsA" (past habitual) confirms father's routine engagement in cynical discourse.
- Step 5: Conclude: The habitual aspect in "lkspk" aligns with a pattern of *habitual distrust* – father's worldview is structurally cynical, not situationally reactive.

ANSWER: Past habitual "lkspk" reveals the father's **chronic, ingrained cynicism** toward the Thakur, not a one-time thought. Evidence 1: "le>rk jgk Fkk" (p. 58) – he habitually viewed Eksgu as a servant, not a son. Evidence 2: "ckrsa djrs jgsA" (p. 62) – he habitually discussed Thakur's exploitation. The aspect transforms a cognitive verb into a character trait.

DIFFICULTY: hard

## COMPETENCY_QUESTION_2
QUESTION: A board exam question asks: *"The story uses the compound verb 'mx vkbZ' (page 56) and 'dkV&Nk¡Vdj' (page 56). A student writes: 'Both mean the same as simple verbs 'vkbZ' and 'Nk¡Vdj' – the first part is redundant.' Refute this student's claim using grammatical, semantic, and stylistic arguments with textual evidence."*

COMPETENCY: Evaluating grammatical complexity and authorial craft (Argumentative Writing + Linguistic Analysis)

STEPS:
- Step 1: Grammatical argument: "mx vkbZ" = absolutive "mx" (having uprooted) + finite "vkbZ" (came). The absolutive adds **manner/means** (kriya visheshan function) – he came *by uprooting*. Simple "vkbZ" lacks this adverbial specification.
- Step 2: Semantic argument: "dkV&Nk¡Vdj" = "dkV" (cut) + "Nk¡Vdj" (threw). The compound denotes a **single complex event** (cutting-and-throwing-away) with violent finality. Simple "Nk¡Vdj" (threw) omits the preparatory violence of cutting. Text: "dkV&Nk¡Vdj" describes destroying the peon's record – the cutting implies severing his identity/service.
- Step 3: Stylistic argument: Compound verbs are **expressive, colloquial, high-agency** – typical of rural speech (f=kyksd flag's order). They convey physical intensity. Simple verbs are neutral. The story's texture relies on this visceral physicality.
- Step 4: Textual evidence: Page 56 – "cw<+s oa'khèkj th osQ cwrs dk vc ;g lc dke ugha jgkA ;gh D;k] tUe Hkj ftl iqjksfgrkbZ osQ cwrs ij mUgksaus ?kj&lalkj pyk;k Fkk] og Hkh vc oSls dgk¡ dj ikrs gSa!" The compound verb "dkV&Nk¡Vdj" mirrors the brutal erasure of history described here.
- Step 5: Synthesize refutation: The first verb is not redundant; it is the **semantic core of the violence** that the simple verb cannot carry.

ANSWER: The claim is false. Grammatically, the absolutive (mx, dkV) functions as an adverbial of manner, specifying *how* the main action occurred. Semantically, "dkV&Nk¡Vdj" encodes a unified violent act (cut+throw) distinct from mere throwing. Stylistically, compound verbs convey the raw physicality of rural power dynamics – the Thakur's order to "dkV&Nk¡Vdj" the peon's records (p. 56) enacts the same brutality as his social erasure of the lower caste. Removing the first verb sanitizes the violence.

DIFFICULTY: medium