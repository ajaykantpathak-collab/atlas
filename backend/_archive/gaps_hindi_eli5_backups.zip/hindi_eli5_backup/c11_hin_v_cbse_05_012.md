## DEFINITION
Literal comprehension questions require students to retrieve information explicitly stated in the text, while inferential comprehension questions demand students to derive meaning by combining textual evidence with logical reasoning and background knowledge. At the Class 11 level, inferential questions require multi-step reasoning connecting implicit details across paragraphs to uncover authorial intent, character motivation, or thematic development.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student can independently distinguish between literal and inferential question types in unseen passages, locate explicit textual evidence for literal answers, and construct multi-sentence inferential responses that cite specific textual clues, explain the logical bridge, and connect to broader themes of the chapter.

## SCOPE_BOUNDARY
This node covers the classification, strategy, and answer-writing techniques for literal and inferential questions based on the chapter "jktLFkku dh jtr cw¡nas". It does NOT cover critical analysis, creative writing, or speaking/listening skills which are addressed in subsequent nodes (c11_hin_v_cbse_05_013, c11_hin_v_cbse_05_014, c11_hin_v_cbse_05_015).

## WALKTHROUGH
Imagine you're sitting in your Class 11 Hindi exam and the first comprehension question asks: "लेखक का बचपन कहाँ बीता?" (Where did the author spend his childhood?) — you quickly scan the text, find "टोंक (राजस्थान) में", and write the answer. The next question asks: "लेखक के परिवार की आर्थिक स्थिति कैसी थी? पाठ के आधार पर बताइए।" (What was the author's family's economic condition? Explain based on the text.) — now you pause. The text never directly says "we were poor." You must piece together clues: father's transfer, mother's illness, moving to a smaller house, the author leaving school early. This node teaches you exactly how to make that leap from "finding" to "figuring out" using a systematic 4-step method: Identify question type → Locate evidence → Build logical bridge → Write structured answer.

## DIAGNOSTIC_QUESTION_1
पाठ्य बोध (Comprehension) में 'शाब्दिक प्रश्न' (Literal Question) और 'अनुमानात्मक प्रश्न' (Inferential Question) का मूल अंतर क्या है? एक-एक उदाहरण देकर स्पष्ट कीजिए।

## DIAGNOSTIC_ANSWER_1
**Correct Answer:** शाब्दिक प्रश्न का उत्तर पाठ में स्पष्ट रूप से लिखा होता है (उदाहरण: "लेखक का जन्म कहाँ हुआ?" — उत्तर: "टोंक, राजस्थान में")। अनुमानात्मक प्रश्न का उत्तर पाठ में सीधे नहीं लिखा होता; पाठ के संकेतों, प्रसंगों और तर्क का उपयोग करके निकालना पड़ता है (उदाहरण: "लेखक के पिता के तबादले से परिवार पर क्या प्रभाव पड़ा?" — उत्तर: आर्थिक तंगी, माँ की बीमारी, छोटे घर में स्थानांतरण, लेखक की पढ़ाई छूटना)।  
**Wrong Answer Reveals:** यदि छात्र दोनों को एक ही मानता है या उदाहरण नहीं दे पाता, तो उसकी समझ सतही है — वह प्रश्न के 'कमांड वर्ब' (कहाँ, क्या, कैसे, क्यों) को पहचान नहीं पा रहा। इसका अर्थ है कि उसे प्रश्न वर्गीकरण की बुनियादी रणनीति नहीं आती।

## DIAGNOSTIC_QUESTION_2
"जयपुर पहुँचने पर लेखक के परिवार की स्थिति में क्या परिवर्तन आया?" — यह प्रश्न शाब्दिक है या अनुमानात्मक? अपने उत्तर का औचित्य सिद्ध कीजिए।

## DIAGNOSTIC_ANSWER_2
**Correct Answer:** यह **अनुमानात्मक प्रश्न** है। पाठ में एक पंक्ति में नहीं लिखा कि "स्थिति खराब हो गई"। छात्र को कई जगहों से साक्ष्य जोड़ने पड़ेंगे: (1) पिता का तबादला → (2) माँ की बीमारी बढ़ना → (3) बड़ा घर छोड़कर छोटे घर में जाना → (4) लेखक का स्कूल छूटना → (5) पारिवारिक तनाव। इन बिखरे संकेतों को जोड़कर निष्कर्ष निकालना पड़ता है।  
**Wrong Answer Reveals:** यदि छात्र इसे शाब्दिक मानता है, तो वह 'स्पष्ट कथन' और 'निहितार्थ' का अंतर नहीं समझा। वह पाठ को टुकड़ों में पढ़ता है, पूर्ण प्रसंग के रूप में नहीं। यह Class 11 में एक आम भ्रांति है जहाँ छात्र 'पाठ में लिखा है' का अर्थ केवल वाक्य-दर-वाक्य मिलान समझते हैं।

## DIAGNOSTIC_QUESTION_3
दिए गए अंश के आधार पर निम्नलिखित शाब्दिक प्रश्न का उत्तर दीजिए और फिर उसी अंश से एक अनुमानात्मक प्रश्न बनाइए:  
"पिताजी का तबादला जयपुर हो गया। माँ की तबीयत वहीं बिगड़ने लगी। बड़ा घर छोड़कर हमें एक छोटे मकान में रहना पड़ा।"

## DIAGNOSTIC_ANSWER_3
**Correct Answer:**  
**शाब्दिक प्रश्न:** "पिताजी का तबादला कहाँ हुआ था?" → उत्तर: "जयपुर।" (सीधे पाठ से)  
**अनुमानात्मक प्रश्न (छात्र द्वारा निर्मित):** "तबादले के बाद माँ की तबीयत क्यों बिगड़ने लगी होगी?" → संभावित उत्तर: "नए स्थान का वातावरण अनुकूल न होना, बड़े घर से छोटे घर में जाने का मानसिक तनाव, आर्थिक चिंता।"  
**Wrong Answer Reveals:** यदि छात्र अनुमानात्मक प्रश्न नहीं बना पाता या ऐसा प्रश्न बनाता है जिसका उत्तर पाठ में स्पष्ट है (जैसे "बड़ा घर क्यों छोड़ा?"), तो वह 'निहितार्थ निकालने' की प्रक्रिया से अनभिज्ञ है। यह दर्शाता है कि वह पाठ को केवल सूचना के स्रोत के रूप में देखता है, अर्थ-निर्माण के क्षेत्र के रूप में नहीं।

## DIAGNOSTIC_QUESTION_4
पाठ "जक्तLFकku dh jtr cw¡nas" में लेखक लिखते हैं: "पढ़ाई छूट गई, पर पढ़ने की ललक नहीं छूटी।" इस वाक्य के आधार पर लेखक के चरित्र की कौन-सी विशेषता उभरती है? पाठ के दो अन्य प्रसंगों से साक्ष्य देकर पुष्टि कीजिए।

## DIAGNOSTIC_ANSWER_4
**Correct Answer:** विशेषता: **जिजीविषा और स्व-अधिगम की लगन (Resilience & Self-driven learning)**।  
**साक्ष्य 1:** लेखक ने नौकरी करते हुए भी पुस्तकें पढ़ीं और ज्ञान अर्जित किया (पाठ में उल्लिखित: "नौकरी के साथ-साथ पढ़ाई जारी रखी")।  
**साक्ष्य 2:** बाद में लेखक ने पर्यावरण पत्रकारिता और लेखन के क्षेत्र में पहचान बनाई, जो औपचारिक शिक्षा के अभाव में स्व-अर्जित ज्ञान का प्रमाण है।  
**तार्किक पुल:** औपचारिक शिक्षा बाधित हुई, पर अनौपचारिक सीखने की प्रक्रिया निरंतर रही — यह वाक्य इसी द्वंद्व को अभिव्यक्त करता है।  
**Wrong Answer Reveals:** यदि छात्र केवल "वह मेहनती था" लिखता है बिना विशिष्ट प्रसंगों के, तो वह 'सामान्यीकरण' की भ्रांति में है। Class 11 बोर्ड परीक्षा में "पाठ के आधार पर" का अर्थ है **विशिष्ट पंक्ति/प्रसंग संदर्भ**, सामान्य कथन नहीं।

## DIAGNOSTIC_QUESTION_5
"अनुमानात्मक प्रश्नों के उत्तर में व्यक्तिगत राय (Personal Opinion) शामिल करनी चाहिए या नहीं?" — इस कथन का मूल्यांकन कीजिए। बोर्ड परीक्षा की अपेक्षा के संदर्भ में तर्क दीजिए।

## DIAGNOSTIC_ANSWER_5
**Correct Answer:** **नहीं, व्यक्तिगत राय शामिल नहीं करनी चाहिए।** बोर्ड परीक्षा में अनुमानात्मक उत्तर **पाठ-आधारित साक्ष्य (Textual Evidence)** और **तार्किक निष्कर्ष (Logical Inference)** पर आधारित होने चाहिए, न कि छात्र के निजी अनुभव या मूल्यांकन पर। उदाहरण: "लेखक का संघर्ष प्रेरणादायक है" — यह व्यक्तिगत राय है, परीक्षा उत्तर नहीं। सही उत्तर: "लेखक ने औपचारिक शिक्षा छूटने के बावजूद स्वाध्याय से ज्ञान अर्जित किया और पर्यावरण पत्रकार बने — यह उनके दृढ़ संकल्प को दर्शाता है।"  
**Wrong Answer Reveals:** यदि छात्र कहता है "राय दे सकते हैं", तो वह 'अनुमान' (Inference) और 'राय' (Opinion) का भेद नहीं समझा। यह भ्रांति अंक कटौती का प्रमुख कारण है — परीक्षक 'पाठ-आधारित तर्क' ढूंढते हैं, भावनात्मक प्रतिक्रिया नहीं।

## DIAGNOSTIC_QUESTION_6
"जक्तLFकku dh jtr cw¡nas" शीर्षक के आधार पर एक अनुमानात्मक प्रश्न बनाइए जिसका उत्तर देने के लिए पूरे पाठ के विषय (Theme), प्रतीकवाद (Symbolism) और लेखक के दृष्टिकोण (Perspective) को जोड़ना पड़े। प्रश्न ऐसा हो जो 4-5 अंक का हो।

## DIAGNOSTIC_ANSWER_6
**Expected Question:** "शीर्षक 'जक्तLFकku dh jtr cw¡nas' (सत्ता/सामंती व्यवस्था के बुझते दीये) पाठ के केंद्रीय विषय को कैसे अभिव्यक्त करता है? लेखक के व्यक्तिगत संघर्ष और सामाजिक-ऐतिहासिक संदर्भ को जोड़ते हुए स्पष्ट कीजिए।"  
**Criteria for Good Answer:**  
1. शीर्षक के प्रतीकवाद की व्याख्या: 'जक्तLFकku' = सामंती सत्ता/परंपरा, 'jtr cw¡nas' = उसका क्षय/परिवर्तन।  
2. लेखक के परिवार का पतन (पिता की नौकरी, आर्थिक संकट) को उस सामाजिक परिवर्तन का सूक्ष्म रूप (Microcosm) दिखाना।  
3. लेखक का दृष्टिकोण: नॉस्टेल्जिया नहीं, यथार्थपरक विश्लेषण — "दीये बुझ रहे हैं, नए प्रकाश की जरूरत है"।  
4. पर्यावरण/जनपक्षीय पत्रकारिता से जुड़ाव को नए 'दीये' के रूप में प्रस्तुत करना।  
**Poor Answer Reveals:** यदि छात्र केवल शीर्षक का शाब्दिक अर्थ बताता है या केवल लेखक की जीवनी लिखता है, तो वह **अंतर्विषयक संश्लेषण (Interdisciplinary Synthesis)** नहीं कर पाया — जो Class 12 बोर्ड और CUET में अपेक्षित है।

## COMMON_MISCONCEPTION
**विशिष्ट भ्रांति:** छात्र मानते हैं कि "अनुमानात्मक प्रश्न का उत्तर पाठ में 'छिपा' होता है जिसे ढूंढना पड़ता है" — जैसे कोई खजाना खोज रहे हों। वास्तव में, अनुमानात्मक उत्तर **निर्मित (Constructed)** होता है: छात्र पाठ के बिखरे संकेतों (Clues) को **तार्किक श्रृंखला (Logical Chain)** में जोड़कर **नया अर्थ (New Meaning)** उत्पन्न करता है।  
**उदाहरण:** पाठ में लिखा है — "पिताजी चुपचाप अखबार पढ़ते रहते", "माँ खिड़की से बाहर देखती रहती", "हम भाई-बहन आपस में कम बोलते"। छात्र खोजता है: "परिवार में तनाव था" — यह वाक्य पाठ में कहीं नहीं लिखा। छात्र ने तीनों व्यवहारों को जोड़कर **निष्कर्ष निकाला**। जो छात्र "पाठ में नहीं लिखा" कहकर उत्तर नहीं लिखते, वे **अनुमान को 'खोज' समझते हैं, 'निर्माण' नहीं**। यह भ्रांति Class 10 से आती है जहाँ प्रश्न प्रायः सीधे होते हैं।

## ON_FAILURE
**चरणबद्ध उपचार:**  
1. **मॉडलिंग (2 मिनट):** एक छोटा अंश (3-4 वाक्य) लें। दिखाएँ: "यहाँ क्या लिखा है → यहाँ क्या नहीं लिखा → मैं कैसे जोड़ता हूँ → मेरा उत्तर।"  
2. **संकेत-मानचित्रण (Clue Mapping):** छात्र से कहें: "पाठ में उन 3-4 वाक्यों को रेखांकित करो जो तुम्हारे उत्तर का आधार बनेंगे।" फिर पूछें: "इनमें क्या समानता है? ये मिलकर क्या बताते हैं?"  
3. **वाक्य-ढांचा (Sentence Scaffold):** दें — "पाठ में ______ लिखा है, और ______ भी लिखा है। इससे पता चलता है कि ______।" छात्र को इसी ढांचे में 3 उत्तर लिखवाएँ।  
4. **फीडबैक लूप:** प्रत्येक उत्तर पर केवल एक टिप्पणी: "साक्ष्य स्पष्ट है / तार्किक पुल कमजोर है / निष्कर्ष पाठ से आगे निकल गया।"  
5. **अगले सप्ताह:** अनदेखे अंश (Unseen Passage) पर यही प्रक्रिया दोहराएँ।

## BUILDS_ON
c11_hin_v_cbse_05_011 (Grammar: Language Usage in the Text) — because understanding syntax, vocabulary, and cohesive devices is essential for locating explicit evidence and tracing implicit connections across sentences.

## LEADS_TO
c11_hin_v_cbse_05_013 (Critical Thinking: Analysis and Interpretation) — because inferential comprehension is the foundation for higher-order critical analysis, evaluation, and interpretation of themes, perspectives, and authorial craft.

## PREREQUISITE_NODE_IDS
c11_hin_v_cbse_05_001, c11_hin_v_cbse_05_002, c11_hin_v_cbse_05_003, c11_hin_v_cbse_05_004, c11_hin_v_cbse_05_005, c11_hin_v_cbse_05_006, c11_hin_v_cbse_05_007, c11_hin_v_cbse_05_008, c11_hin_v_cbse_05_009, c11_hin_v_cbse_05_010, c11_hin_v_cbse_05_011
## PREREQUISITE_REASONS
c11_hin_v_cbse_05_001: Context/background knowledge activates schema for making inferences about historical/social setting.
c11_hin_v_cbse_05_002: Plot structure knowledge helps locate where in the narrative explicit answers reside and where gaps require inference.
c11_hin_v_cbse_05_003: Setting/atmosphere details often serve as implicit clues for inferential questions about mood, conflict, or character state.
c11_hin_v_cbse_05_004: Protagonist analysis provides character motivation framework needed for "why" inferential questions.
c11_hin_v_cbse_05_005: Supporting characters' roles create relational evidence for inferential questions about family/social dynamics.
c11_hin_v_cbse_05_006: Primary theme awareness guides thematic inferences — the 'big picture' that connects scattered details.
c11_hin_v_cbse_05_007: Secondary themes offer additional lenses (gender, environment, education) for multi-layered inferences.
c11_hin_v_cbse_05_008: Imagery/metaphor recognition enables inference of symbolic meaning beyond literal description.
c11_hin_v_cbse_05_009: Irony/symbolism detection is crucial for inferential questions on authorial tone and critique.
c11_hin_v_cbse_05_010: Vocabulary in context prevents misreading key terms that serve as inference triggers.
c11_hin_v_cbse_05_011: Grammar/cohesion knowledge helps trace reference chains, connectors, and elliptical constructions that carry implicit meaning.

## FORWARD_NODE_IDS
c11_hin_v_cbse_05_013, c11_hin_v_cbse_05_014, c11_hin_v_cbse_05_015
## FORWARD_REASONS
c11_hin_v_cbse_05_013: Critical thinking requires moving beyond "what the text says" to "how the text means" — inferential comprehension is the bridge.
c11_hin_v_cbse_05_014: Writing skills (analytical paragraphs, essays) demand the same evidence-reasoning-link structure taught here.
c11_hin_v_cbse_05_015: Speaking/listening discussions use inferential questions as springboards for interpretation and debate.

## CHAIN_DESCRIPTION
c11_hin_v_cbse_05_011 -> c11_hin_v_cbse_05_012 -> c11_hin_v_cbse_05_013 (Grammar enables evidence location → Comprehension classifies & structures retrieval/inference → Critical thinking extends to evaluation/interpretation)

## THIS_FORMULA
**4-Step Inference Construction Protocol (ICP-4):**  
1. **QUESTION TYPE TAG** → शाब्दिक (Literal) / अनुमानात्मक (Inferential) पहचानें।  
2. **EVIDENCE HUNT** → पाठ में स्पष्ट कथन (Explicit) + निहित संकेत (Implicit Clues) रेखांकित करें।  
3. **LOGIC BRIDGE** → संकेतों को जोड़ने वाला तार्किक वाक्य लिखें: "चूँकि X और Y, इसलिए Z"।  
4. **STRUCTURED ANSWER** → PEEL फॉर्मेट: Point (निष्कर्ष) + Evidence (उद्धरण/संदर्भ) + Explanation (तर्क) + Link (विषय/प्रसंग से संबंध)।

## FORMULA_VARIABLES
N/A

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
linguistic

## CROSS_SUBJECT
c11_history_ancient_india | Historical source analysis requires distinguishing direct statements in inscriptions (literal) from inferences about socio-economic conditions (inferential) — same evidence→reasoning→claim structure.
c11_geography_human_geography | Interpreting maps/data tables: literal reading of symbols vs. inferring migration patterns, resource distribution causes — mirrors textual clue-mapping.
c11_economics_microeconomics | Case study questions: explicit data (price, quantity given) vs. inferring elasticity, consumer surplus — requires logical bridge from data to concept.
c11_civics_constitution | Article interpretation: literal wording vs. inferring legislative intent, judicial precedent — same "textual evidence + constitutional principle" reasoning.

## PREREQ_CONCEPT
Ability to identify explicit information in a text and distinguish it from implicit suggestions — developed through prior nodes on plot, character, theme, and language analysis.

## PREREQ_BEFORE
Student must be able to summarize the chapter's narrative arc, list main characters with 2-3 traits each, and define 5-7 key vocabulary words from the text.

## PREREQ_STUCK
If stuck, review c11_hin_v_cbse_05_002 (Plot) and c11_hin_v_cbse_05_010 (Vocabulary) — these provide the factual backbone and lexical access for all comprehension work.

## WORKED_EXAMPLE_1
PROBLEM: पाठ "जक्तLFकku dh jtr cw¡nas" से: "लेखक ने अपनी माँ की बीमारी का वर्णन करते हुए लिखा है — 'माँ खिड़की से बाहर देखती रहती, मानो किसी की प्रतीक्षा कर रही हो।' इस कथन के आधार पर माँ की मानसिक स्थिति क्या थी? पाठ के दो अन्य प्रसंगों से पुष्टि कीजिए।" (3 अंक)
STEPS:
- Step 1: प्रश्न प्रकार पहचानें — "मानसिक स्थिति" सीधे नहीं लिखी, अतः **अनुमानात्मक**।
- Step 2: साक्ष्य खोजें — (क) दिया गया वाक्य: खिड़की से देखना + प्रतीक्षा का रूपक → निष्क्रियता, आशा/निराशा। (ख) प्रसंग 1: "पिताजी के तबादले के बाद माँ चुप हो गई" → आघात/सदमा। (ग) प्रसंग 2: "दवा के पैसे नहीं थे, माँ कहती — 'ठीक हो जाऊँगी'" → आर्थिक चिंता छिपाना, बच्चों को ढाढ़स।
- Step 3: तार्किक पुल बनाएँ — शारीरिक बीमारी + आर्थिक तंगी + पति का मौन + बच्चों की चिंता = **आंतरिक संघर्ष, असहायता, परन्तु जिजीविषा**।
- Step 4: PEEL उत्तर लिखें — Point: माँ अवसादग्रस्त किन्तु संघर्षशील थी। Evidence: "खिड़की से देखती रहती", "चुप हो गई", "ठीक हो जाऊँगी"। Explanation: खिड़की प्रतीक है बाहरी दुनिया से कटे होने का; मौन और झूठी दिलासा आंतरिक पीड़ा के प्रतिरक्षा तंत्र (Defense mechanisms) हैं। Link: यह पारिवारिक विघटन के बीच मातृत्व की दृढ़ता दर्शाता है — पाठ के केंद्रीय विषय 'संघर्ष में गरिमा' से जुड़ता है।
REASONING: ICP-4 प्रोटोकॉल सुनिश्चित करता है कि छात्र 'खोज' नहीं 'निर्माण' करे। Step 2 में एकाधिक प्रसंग जोड़ने से उत्तर 'पाठ-आधारित' बनता है, सामान्यीकरण नहीं। Step 4 का Link चरण बोर्ड परीक्षा के "विषय से संबंध" मानदंड को पूरा करता है।
ANSWER: माँ की मानसिक स्थिति **आंतरिक पीड़ा, असहायता और मौन संघर्ष की मिश्रित अवस्था** थी। पाठ में लिखा है — "माँ खिड़की से बाहर देखती रहती, मानो किसी की प्रतीक्षा कर रही हो" — यह रूपक उनके अवसाद और बाहरी दुनिया से कटे होने को दर्शाता है। दूसरे, "पिताजी के तबादले के बाद माँ चुप हो गई" — यह आघात-जनित मौन है। तीसरे, "दवा के पैसे नहीं थे, माँ कहती — 'ठीक हो जाऊँगी'" — यह बच्चों को ढाढ़स बँधाने के लिए बोला गया झूठ है, जो उनकी ममता और दृढ़ता का प्रमाण है। ये तीनों प्रसंग मिलकर बताते हैं कि माँ शारीरिक-आर्थिक संकट में भी परिवार का भावनात्मक आधार बनी रहीं — पाठ के 'संघर्ष में गरिमा' विषय की प्रतीक हैं।

## WORKED_EXAMPLE_2
PROBLEM: निम्नलिखित अंश पढ़कर प्रश्नों के उत्तर दीजिए:  
"जयपुर में हमारा बड़ा घर छूट गया। छोटे मकान में जगह कम थी, सो हम भाई-बहन एक ही कमरे में सोते। रात को पिताजी की खाँसी और माँ की कराहट सुनाई देती। फिर भी सुबह स्कूल जाते समय हमारा बस्ता भारी नहीं लगता था।"  
(i) शाब्दिक: "भाई-बहन कहाँ सोते थे?"  
(ii) अनुमानात्मक: "फिर भी सुबह स्कूल जाते समय हमारा बस्ता भारी नहीं लगता था" — इस वाक्य का निहितार्थ क्या है? पाठ के संदर्भ में स्पष्ट कीजिए।
STEPS:
- Step 1 (i): प्रश्न टैग — "कहाँ" → **शाब्दिक**।
- Step 2 (i): सीधा साक्ष्य — "एक ही कमरे में"।
- Step 1 (ii): प्रश्न टैग — "निहितार्थ", "क्या है" → **अनुमानात्मक**।
- Step 2 (ii): संकेत रेखांकित करें — (क) बड़ा घर छूटा → आर्थिक पतन। (ख) छोटा मकान, भीड़ → शारीरिक असुविधा। (ग) पिताजी की खाँसी + माँ की कराहट → रोग/तनाव का ध्वनि-चित्र। (घ) "फिर भी" (Contrast marker) + "बस्ता भारी नहीं लगता" → मानसिक भार की अनुपस्थिति।
- Step 3 (ii): तार्किक पुल — शारीरिक/आर्थिक कष्ट (External) के बावजूद शिक्षा/भविष्य के प्रति लगन (Internal Motivation) भार को 'हल्का' बनाती है। बस्ता = शिक्षा का प्रतीक; भारी न लगना = आशा/उद्देश्य की शक्ति।
- Step 4 (ii): PEEL उत्तर — Point: वाक्य बालकों की **शिक्षा के प्रति निष्ठा और आशावादिता** दर्शाता है। Evidence: "बड़ा घर छूट गया", "खाँसी/कराहट", "फिर भी बस्ता भारी नहीं लगता"। Explanation: विषम परिस्थितियाँ (घर, स्वास्थ्य, आर्थिक) बाहरी भार हैं; बस्ते का हल्का लगना आंतरिक प्रेरणा का रूपक है। Link: यह लेखक के आत्मकथ्य का केंद्रीय द्वंद्व है — बाह्य अभाव बनाम आंतरिक समृद्धि।
REASONING: Step 2 में 'फिर भी' (Adversative conjunction) को संकेत के रूप में पहचानना व्याकरणिक ज्ञान (c11_hin_v_cbse_05_011) का अनुप्रयोग है। Step 3 में प्रतीकवाद (बस्ता = शिक्षा/भविष्य) साहित्यिक उपकरण ज्ञान (c11_hin_v_cbse_05_008/009) का उपयोग है। यह क्रॉस-नोड एकीकरण Class 11 गहराई दर्शाता है।
ANSWER: (i) भाई-बहन **एक ही कमरे में** सोते थे। (ii) निहितार्थ: **घोर पारिवारिक संकट (आर्थिक, स्वास्थ्य, आवासीय) के बावजूद बच्चों की शिक्षा के प्रति लगन और भविष्य के प्रति आशा बनी हुई थी।** "बड़ा घर छूटना", "पिताजी की खाँसी", "माँ की कराहट" — ये बाह्य कष्ट हैं। "फिर भी" संयोजक इन कष्टों का प्रतिवाद करता है। "बस्ता भारी नहीं लगता" — बस्ता शिक्षा का प्रतीक है; उसका हल्का लगना दर्शाता है कि ज्ञान-प्राप्ति का उद्देश्य कष्टों से बड़ा है। यह प्रसंग पाठ के 'अभाव में भी शिक्षा की ज्योति' विषय को मूर्त करता है।

## WORKED_EXAMPLE_3
PROBLEM: बोर्ड परीक्षा प्रश्न: "लेखक ने लिखा है — 'जक्तLFकku के दीये बुझ रहे थे, पर हमने अपनी झोपड़ी में नया दीया जलाना सीख लिया।' इस कथन में निहित प्रतीकवाद और लेखक के दृष्टिकोण की व्याख्या करते हुए बताइए कि यह पाठ के केंद्रीय विषय को कैसे अभिव्यक्त करता है?" (5 अंक)
STEPS:
- Step 1: प्रश्न प्रकार — **उच्च-स्तरीय अनुमानात्मक (Synthesizing Inference)** — शीर्षक, प्रतीक, विषय, दृष्टिकोण सब जोड़ने हैं।
- Step 2: प्रतीक विखंडन — 'जक्तLFकku के दीये' = सामंती सत्ता/परंपरा/पुरानी व्यवस्था (c11_hin_v_cbse_05_009 Symbolism)। 'बुझ रहे थे' = ऐतिहासिक अपरिहार्यता/क्षय। 'अपनी झोपड़ी' = लेखक का वर्तमान/सामान्य जन का जीवन। 'नया दीया' = स्व-अर्जित ज्ञान/शिक्षा/पर्यावरण चेतना/नई दृष्टि।
- Step 3: पाठगत साक्ष्य संकलन — (क) बचपन: सामंती परिवेश का वर्णन (c11_hin_v_cbse_05_003 Setting)। (ख) परिवार का पतन: पिता की नौकरी, आर्थिक संकट (c11_hin_v_cbse_05_002 Plot)। (ग) लेखक का स्वाध्याय, नौकरी, पत्रकारिता (c11_hin_v_cbse_05_004 Protagonist)। (घ) पर्यावरण/जनपक्षीय लेखन (c11_hin_v_cbse_05_006 Theme)।
- Step 4: दृष्टिकोण विश्लेषण — लेखक **नॉस्टेल्जिक नहीं, यथार्थवादी-प्रगतिशील** हैं। 'बुझ रहे दीयों' पर शोक नहीं, 'नया दीया जलाने' पर बल। यह 'परिवर्तन को स्वीकारना, नया रचना' दृष्टिकोण है।
- Step 5: विषय से संश्लेषण — केंद्रीय विषय: **'परंपरा के अवसान में नई चेतना का उदय'** (Transition from feudal decay to self-made enlightenment)। यह वाक्य इसी का सघन प्रतीकात्मक कथन है।
- Step 6: संरचित 5-अंकीय उत्तर — PEEL विस्तारित: Point (प्रतीकवाद+दृष्टिकोण) → Evidence 1 (बचपन/सामंती परिवेश) → Evidence 2 (पतन/संकट) → Evidence 3 (स्वाध्याय/नया दीया) → Explanation (तार्किक श्रृंखला) → Link (केंद्रीय विषय) → Concluding Insight (समकालीन प्रासंगिकता)।
REASONING: यह उदाहरण दर्शाता है कि Class 11 में अनुमानात्मक प्रश्न **बहु-स्तरीय संश्लेषण (Multi-layered Synthesis)** माँगते हैं। Step 2-4 में पूर्व नोड्स (Setting, Plot, Character, Theme, Symbolism) का सक्रिय उपयोग अनिवार्य है। Step 6 का विस्तारित PEEL बोर्ड पैटर्न (5 अंक: 1+1+1+1+1 या 2+2+1) से मेल खाता है।
ANSWER: यह कथन **द्वैत प्रतीकवाद (Dual Symbolism)** के माध्यम से पाठ का केंद्रीय विषय व्यक्त करता है:  
**'जक्तLFकku के दीये'** — सामंती व्यवस्था, पारंपरिक सत्ता संरचना, और लेखक के बचपन के उस परिवेश के प्रतीक हैं जो ऐतिहासिक रूप से क्षयमान थे (Setting: "सामंती ठाठ-बाट", "जागीरदारी प्रथा")।  
**'बुझ रहे थे'** — नॉस्टेल्जिया नहीं, **ऐतिहासिक अनिवार्यता** दर्शाता है; लेखक का यथार्थवादी दृष्टिकोण कि पुराना मिट रहा है।  
**'अपनी झोपड़ी'** — लेखक का वर्तमान: सामान्य जन का जीवन, अभाव, संघर्ष (Plot: पिता का तबादला, माँ की बीमारी, छोटा मकान)।  
**'नया दीया जलाना सीख लिया'** — **स्व-अर्जित ज्ञान, शिक्षा, पर्यावरण चेतना, जनपक्षीय पत्रकारिता** का प्रतीक (Character: "पढ़ाई छूटी पर ललक नहीं"; Theme: "नई चेतना")।  
**लेखक का दृष्टिकोण:** वे अतीत के विलाप में नहीं, वर्तमान के निर्माण में विश्वास करते हैं — "सीख लिया" क्रिया **अर्जन (Agency)** दर्शाती है।  
**केंद्रीय विषय से संबंध:** यह वाक्य पाठ के मूल संदेश — **"परंपरा के अवसान में नई स्व-निर्मित चेतना का उदय"** — को एक सघन बिंब में समेटता है। आज जब सामंती मानसिकता के अवशेष नए रूपों में मौजूद हैं, 'अपनी झोपड़ी में नया दीया जलाना' हर वंचित युवा के लिए प्रासंगिक रूपक है।

## COMPETENCY_QUESTION_1
QUESTION: आपने एक अनदेखा गद्यांश (Unseen Passage) पढ़ा जिसमें एक ग्रामीण बालिका का वर्णन है: "स्कूल जाने के लिए वह रोज 5 किमी पैदल चलती। बरसात में नदी पार करने के लिए नाव का इंतजार करती। किताबें भीग न जाएँ, इसलिए पॉलीथीन में लपेटकर रखती। पिता कहते — 'पढ़-लिखकर क्या करेगी, ब्याह ही तो होना है।' फिर भी वह रोज जाती।"  
इस अंश के आधार पर एक शाब्दिक और एक अनुमानात्मक प्रश्न **बनाइए** (पूछिए नहीं, बनाइए) और दोनों के **आदर्श उत्तर** लिखिए। ध्यान रखें: अनुमानात्मक प्रश्न का उत्तर PEEL संरचना में हो।
COMPETENCY: Question Design & Answer Modeling — demonstrating mastery of both question types by creating them and answering to board standard.
STEPS:
- Step 1: अंश से स्पष्ट तथ्य (Explicit Fact) चुनकर शाब्दिक प्रश्न बनाएँ — कमांड वर्ब 'क्या/कहाँ/कितना'।
- Step 2: अंश के निहित संकेतों (Implicit Clues) को जोड़कर अनुमानात्मक प्रश्न बनाएँ — कमांड वर्ब 'कैसे/क्यों/क्या निहितार्थ'।
- Step 3: शाब्दिक प्रश्न का 1-वाक्यीय सीधा उत्तर लिखें।
- Step 4: अनुमानात्मक प्रश्न का PEEL उत्तर लिखें: Point (निष्कर्ष) + Evidence (2-3 विशिष्ट संकेत) + Explanation (तार्किक पुल) + Link (बालिका शिक्षा/लैंगिक संघर्ष विषय से)।
ANSWER:  
**शाब्दिक प्रश्न:** "बालिका स्कूल जाने के लिए रोज कितनी दूरी पैदल तय करती थी?"  
**उत्तर:** "5 किलोमीटर।"  

**अनुमानात्मक प्रश्न:** "पिता के विरोध और शारीरिक बाधाओं के बावजूद बालिका का रोज स्कूल जाना उसके चरित्र की कौन-सी विशेषता दर्शाता है? अंश के साक्ष्यों सहित स्पष्ट कीजिए।"  
**PEEL उत्तर:**  
**Point:** बालिका में **दृढ़ संकल्प, शिक्षा के प्रति अटूट निष्ठा और पितृसत्तात्मक मानसिकता के प्रतिरोध का साहस** है।  
**Evidence:** (1) "रोज 5 किमी पैदल चलती" — शारीरिक श्रम की निरंतरता। (2) "बरसात में नाव का इंतजार, किताबें पॉलीथीन में लपेटना" — संसाधनहीनता में भी सुरक्षा की युक्ति (Resourcefulness)। (3) "पिता कहते — 'पढ़-लिखकर क्या करेगी'... फिर भी वह रोज जाती" — प्रत्यक्ष विरोध के बावजूद अनुपालन न करना।  
**Explanation:** ये तीनों संकेत मिलकर बताते हैं कि उसकी प्रेरणा बाह्य पुरस्कार नहीं, आंतरिक विश्वास (Self-efficacy) से आती है। पॉलीथीन का उपयोग व्यावहारिक बुद्धि (Practical intelligence) दिखाता है; पिता की बात न मानना **मौन प्रतिरोध (Silent Resistance)** है।  
**Link:** यह प्रसंग ग्रामीण भारत में बालिका शिक्षा के संघर्ष का सूक्ष्म रूपक है — जहाँ भौतिक बाधाएँ और सामाजिक निषेध दोनों पार करने पड़ते हैं।
DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: "जक्तLFकku dh jtr cw¡nas" पाठ में लेखक अपने बचपन के एक प्रसंग का वर्णन करते हैं: "मेले में खिलौने बेचने वाला एक बूढ़ा रो रहा था। उसका पोता बीमार था, दवा के पैसे नहीं थे। पिताजी ने जेब से रुपये निकाले, दे दिए। बूढ़े ने आशीर्वाद दिया — 'तुम्हारा घर आबाद रहे।' उस दिन मैंने जाना कि दया भी एक तरह का धन है।"  
इस प्रसंग के आधार पर एक **बहु-चरणीय अनुमानात्मक प्रश्न (Multi-step Inferential Question)** बनाइए जो छात्र से निम्नलिखित तीनों अपेक्षा करे:  
(a) पिताजी के चरित्र का एक आयाम उद्घाटित करे (Character Dimension)  
(b) लेखक के बाल-मन पर पड़े प्रभाव का विश्लेषण करे (Psychological Impact)  
(c) इस प्रसंग को पाठ के व्यापक विषय (Broader Theme) से जोड़े।  
फिर इस प्रश्न का **बोर्ड-स्तरीय आदर्श उत्तर** लिखिए (शब्द सीमा: 80-100 शब्द)।
COMPETENCY: Multi-dimensional Inferential Reasoning — synthesizing character analysis, psychological insight, and thematic integration in a single coherent response.
STEPS:
- Step 1: प्रश्न निर्माण — तीनों आयाम (चरित्र, मनोविज्ञान, विषय) को एक प्रश्न में बुनें; कमांड वर्ब: "विश्लेषण कीजिए", "स्पष्ट कीजिए"।
- Step 2: आयाम (a) के लिए साक्ष्य — पिताजी का तत्काल सहयोग, बिना पूछे/हिचके देना → **करुणा और सहज उदारता (Spontaneous Compassion)**।
- Step 3: आयाम (b) के लिए साक्ष्य — "उस दिन मैंने जाना" (Epiphany marker), "दया भी एक तरह का धन" (Metaphorical insight) → **नैतिक बोध का क्षण (Moral Epiphany), मूल्य-निर्माण (Value Formation)**।
- Step 4: आयाम (c) के लिए साक्ष्य — पाठ का विषय: "अभाव में भी मानवीय गरिमा", "सामंती ठाठ के विपरीत जनपक्षीय मूल्य" → **'नया दीया' रूपक से जुड़ाव**।
- Step 5: संक्षिप्त PEEL-एकीकृत उत्तर लिखें — प्रत्येक आयाम को अलग पैराग्राफ न देकर, प्रवाहमय तर्क में पिरोएँ।
ANSWER:  
**प्रश्न:** "मेले के प्रसंग में पिताजी द्वारा बूढ़े खिलौने वाले को दी गई सहायता उनके चरित्र के किस पक्ष को उजागर करती है? इस घटना ने लेखक के बाल-मन पर क्या प्रभाव डाला? यह प्रसंग पाठ के केंद्रीय विषय 'अभाव में गरिमा' को कैसे प्रतिबिंबित करता है? संक्षेप में विश्लेषण कीजिए।"  

**आदर्श उत्तर (92 शब्द):**  
पिताजी का बिना हिचक रुपये देना उनकी **सहज करुणा और मानवीय गरिमा** दर्शाता है — सामंती अहंकार से मुक्त, वे 'देने' को अधिकार नहीं कर्तव्य मानते हैं। लेखक के बाल-मन पर यह **नैतिक प्रबोधन (Moral Epiphany)** था: "दया भी एक तरह का धन है" रूपक से उसने जाना कि भौतिक अभाव (पिता की नौकरी, माँ की बीमारी) के बावजूद नैतिक सम्पदा अर्जित की जा सकती है। यह प्रसंग पाठ के केंद्रीय विषय — **"जक्तLFकku के बुझते दीयों (सामंती मूल्यों) के बीच सामान्य जन की झोपड़ी में जलता नया दीया (मानवीय करुणा, स्व-निर्मित मूल्य)"** — का सजीव उदाहरण है। पिताजी का आचरण ही वह 'नया दीया' है जो पुत्र में संचरित होता है।
DIFFICULTY: hard