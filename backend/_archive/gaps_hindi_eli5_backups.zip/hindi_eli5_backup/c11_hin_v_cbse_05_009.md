## DEFINITION
Irony is a literary device where the intended meaning of words or events is opposite to their literal or expected meaning, creating a contrast between appearance and reality. Symbolism is the use of objects, characters, settings, or actions to represent abstract ideas, qualities, or concepts beyond their literal sense.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student can independently identify at least two instances of irony and two symbols in the chapter, explain how each operates using textual evidence, and analyze their combined contribution to the theme of displacement and resilience in a structured PEEL paragraph.

## SCOPE_BOUNDARY
This node covers identification, classification, and analysis of irony (situational, verbal, dramatic) and symbolism (objects, settings, actions) specifically within "जक्तल्फक्कु ध झटर च्वीनस". It does not cover other literary devices like imagery or metaphor (covered in node 008) nor general comprehension questions (node 012).

## WALKTHROUGH
Imagine you are packing a small suitcase for a sudden move, knowing you can never return home — what one object would you take that carries your entire past? That object becomes a symbol. Now, think of a moment when you said "I'm fine" while your world was falling apart — that is verbal irony. In this chapter, the author uses such contrasts and objects to convey the trauma of Partition migration. We begin by locating moments where the narrator's words clash with reality (irony) and where ordinary things like a "टूटी हुई चारपाई" or "पुराना संदूक" carry heavy emotional weight (symbolism). We then trace how these devices deepen the theme of lost homeland and rebuilt identity. The key insight: irony exposes the gap between expectation and experience, while symbols condense history into tangible forms.

## DIAGNOSTIC_QUESTION_1
Define situational irony and give one example from daily life (not from the textbook).

## DIAGNOSTIC_ANSWER_1
Situational irony occurs when the outcome of a situation is sharply contrary to what was expected or intended. Example: A fire station burning down while firefighters are away at a fire safety seminar. A wrong answer (e.g., confusing it with verbal irony or giving a coincidence) reveals the student cannot distinguish between types of irony or confuses irony with mere bad luck.

## DIAGNOSTIC_QUESTION_2
In the chapter, the narrator's father says, "हम जल्दी लौट आएंगे" (We will return soon) while locking the house forever. Explain why this is verbal irony and what it reveals about the father's internal state.

## DIAGNOSTIC_ANSWER_2
This is verbal irony because the father's words express hope of return while his action (locking the house permanently) and the historical context (Partition migration) confirm he knows they will never return. It reveals his protective denial — shielding children from trauma while privately accepting irreversible loss. A wrong answer that calls it "a lie" or "situational irony" shows the student misses the deliberate contrast between spoken words and known reality, and fails to link it to character psychology.

## DIAGNOSTIC_QUESTION_3
Identify one object in the chapter that functions as a symbol. Explain what it represents and cite one textual detail that supports your interpretation.

## DIAGNOSTIC_ANSWER_3
The "पुराना संदूक" (old trunk) symbolizes the family's uprooted heritage and fragmented memories. It carries physical remnants (clothes, documents) of their past life, yet its limited capacity forces selection — mirroring how migrants must choose what identity to preserve. Textual detail: the narrator describes the trunk as "भारी मगर अधूरा" (heavy but incomplete). A weak answer that only says "it represents memories" without linking to migration trauma or citing evidence shows superficial symbol-spotting without analytical depth.

## DIAGNOSTIC_QUESTION_4
Compare the irony in the father's promise to return with the symbolism of the "टूटी हुई चारपाई" (broken cot) left behind. How do both devices together convey the theme of irreversible displacement?

## DIAGNOSTIC_ANSWER_4
The father's verbal irony (promise vs. reality) captures the *moment* of denial, while the broken cot — left behind because it cannot fit in the trunk — symbolizes the *permanence* of loss: a life too large to carry, too broken to reconstruct. Together, they show displacement as both a spoken falsehood and a physical abandonment. A wrong answer that treats them as separate devices without synthesizing their joint thematic work reveals inability to analyze inter-device relationships.

## DIAGNOSTIC_QUESTION_5
Evaluate the author's choice to use a child narrator to convey irony and symbolism. Does this perspective strengthen or weaken the portrayal of Partition trauma? Justify.

## DIAGNOSTIC_ANSWER_5
The child narrator *strengthens* the portrayal because their limited understanding creates dramatic irony: readers grasp the horror (permanent exile, parental grief) that the child only senses through symbols (the trunk, the cot) and ironic adult statements. This gap between child's perception and reader's knowledge amplifies tragedy without melodrama. An answer claiming it weakens the portrayal because "children don't understand" misses the sophisticated use of dramatic irony and the symbolic weight of a child's innocent observations.

## DIAGNOSTIC_QUESTION_6
Write a 4-line paragraph (in Hindi or English) describing a personal object you would take if forced to migrate suddenly, using it as a symbol of your identity. Include one ironic statement you might tell yourself while packing it.

## DIAGNOSTIC_ANSWER_6
Expected: A paragraph where the object (e.g., grandmother's recipe diary) symbolizes cultural continuity, and the ironic statement (e.g., "I'll cook from this in our new kitchen tomorrow") contrasts with the reality of an uncertain future. Criteria: clear symbol-object link, irony that reveals emotional conflict, concise language. A poor answer that merely describes the object without symbolic meaning or uses sarcasm instead of irony shows confusion between symbolism/literal description and irony/sarcasm.

## COMMON_MISCONCEPTION
Students often confuse *symbolism* with *imagery* — thinking any vivid description (e.g., "the burning pyre") is a symbol. They also mistake *coincidence* or *sarcasm* for *irony*. In this chapter, they may label the "burning pyre" in the title as just a dramatic image, missing that it *symbolizes* the cremation of a homeland and the irony that "जक्तल्फक्कु" (kingdom/state) has a "झटर च्वीनस" (burning pyre) — the state meant to protect becomes the agent of destruction. This error stems from treating literary devices as decorative labels rather than meaning-making mechanisms.

## ON_FAILURE
1. Re-teach the distinction: Imagery appeals to senses; symbolism assigns *representational* meaning. Use a non-text example: a wedding ring (image: gold circle) vs. symbol (eternal commitment). 
2. For irony, create a 3-column table: Type | Definition | Text Example. Fill together using the father's promise (verbal), the family leaving the cot (situational: they need it most but abandon it), and the child's belief in return (dramatic: reader knows otherwise). 
3. Practice with a 2-sentence micro-analysis: "Object X is a symbol of Y because [text detail]. This creates irony because [contrast]." Repeat for three objects from the chapter.

## BUILDS_ON
Builds on the ability to identify imagery and metaphor (node 008) by advancing from sensory comparison to structural contrast (irony) and representational meaning (symbolism).

## LEADS_TO
Enables critical thinking (node 013) where students evaluate how irony and symbolism shape the chapter's commentary on Partition, and writing skills (node 014) requiring device-based analytical paragraphs.

## PREREQUISITE_NODE_IDS
c11_hin_v_cbse_05_001, c11_hin_v_cbse_05_002, c11_hin_v_cbse_05_008, c11_hin_v_cbse_05_006, c11_hin_v_cbse_05_007

## PREREQUISITE_REASONS
c11_hin_v_cbse_05_001: Provides historical context of Partition migration essential for understanding the gap between expectation (return) and reality (permanent displacement) that creates irony.
c11_hin_v_cbse_05_002: Establishes plot sequence so students can locate ironic moments (e.g., locking the house) and symbolic objects (trunk, cot) at specific narrative points.
c11_hin_v_cbse_05_008: Develops foundational skill of identifying figurative language; irony and symbolism are higher-order devices requiring prior comfort with non-literal meaning.
c11_hin_v_cbse_05_006: Irony (watchman guarding power) and symbolism (bushes) *enact* the theme; identifying them depends on knowing *what* they symbolize.  
c11_hin_v_cbse_05_007: Irony/symbolism (e.g., file sanctioning handpump over functioning well) enact thematic tensions.  

## FORWARD_NODE_IDS
c11_hin_v_cbse_05_013, c11_hin_v_cbse_05_014, c11_hin_v_cbse_05_012, c11_hin_v_cbse_05_015, c12_hin_a_cbse_03_009, c12_hin_a_cbse_05_009, c12_hin_a_cbse_10_009, c12_hin_al_cbse_01_009, c12_hin_ar_cbse_09_009, c11_hin_v_cbse_05_010

## FORWARD_REASONS
c11_hin_v_cbse_05_013: Critical thinking requires analyzing how irony and symbolism construct the chapter's perspective on trauma, memory, and identity — directly applying this node's skills.
c11_hin_v_cbse_05_014: Writing analytical paragraphs (PEEL structure) about literary devices demands the identification, evidence citation, and explanatory reasoning practiced here.
c11_hin_v_cbse_05_012: Irony/symbolism detection is crucial for inferential questions on authorial tone and critique.  
c11_hin_v_cbse_05_015: Irony/symbolism analysis allows sophisticated textual readings  
c12_hin_a_cbse_03_009: Class 11 Vitan Chapter 5 includes analysis of symbolic language in prose, reinforcing cross-genre recognition.  
c12_hin_a_cbse_05_009: अगला तार्किक चरण: Irony is a literary device where the intended meaning of words or a situation is opposite to their l... इस नोड की अवधारणाओं को सीधे उपयोग/विस्तारित करता है।  
c12_hin_a_cbse_10_009: Vitan Chapter 5 synthesized devices in a full memoir — capstone for Class 11.  
c12_hin_al_cbse_01_009: Class 11 Vitan Chapter 5 Irony and Symbolism node completes prior coverage.  
c12_hin_ar_cbse_09_009: अगला तार्किक चरण: Irony is a literary device where the intended meaning of words or events contrasts sharply with thei... इस नोड की अवधारणाओं को सीधे उपयोग/विस्तारित करता है।  
c11_hin_v_cbse_05_010: - Step 5: Connect to literary device. This is lexical irony / semantic reversal (c11_hin_v_cbse_05_009), reinforcing the theme of power asymmetry.  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
None directly from prior class nodes, but conceptual bridges exist with Class 11 History (Partition), Geography (migration patterns), and Civics (citizenship/refugee rights) — these are not prior nodes but concurrent curriculum links.

## CHAIN_DESCRIPTION
c11_hin_v_cbse_05_001 -> c11_hin_v_cbse_05_009 -> c11_hin_v_cbse_05_013

## THIS_FORMULA
N/A - conceptual

## FORMULA_VARIABLES
N/A

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
conceptual

## CROSS_SUBJECT
c11_history_partition | The chapter's irony (promises of return vs. permanent exile) and symbols (trunk, cot) mirror historical realities of 1947 migration: oral histories show refugees locking homes expecting return, carrying limited objects that became identity anchors.
c11_geography_migration | Symbolic objects represent "place attachment" in migration geography; irony reflects the dissonance between push factors (violence) and pull factors (none — displacement was forced, not chosen).
c11_civics_citizenship | The father's verbal irony ("we'll return") encodes the legal limbo of refugees: citizens of a new state but emotionally stateless; symbols like documents in the trunk represent contested citizenship proofs.

## PREREQ_CONCEPT
Ability to distinguish literal from figurative meaning and to locate specific textual details in a prose narrative.

## PREREQ_BEFORE
Student must have read the full chapter and completed nodes on plot (002) and imagery/metaphor (008) to recognize non-literal language and narrative context.

## PREREQ_STUCK
If stuck, review node 008 (Imagery and Metaphor) focusing on the difference between *comparison* (metaphor) and *representation* (symbolism), and re-read the chapter's migration scenes (locking house, packing trunk, leaving cot).

## WORKED_EXAMPLE_1
PROBLEM: Analyze how the "जली हुई रोटी" (burnt roti) mentioned in the narrator's memory functions as both a symbol and an instance of situational irony in the context of the family's last meal before fleeing.
STEPS:
- Step 1: Locate the reference — the narrator recalls the mother serving a slightly burnt roti on the morning they left, saying "आज जल्दी में जल गई" (burnt in today's hurry).
- Step 2: Identify the literal level — a cooking accident due to rushed packing; the mother's casual explanation masks panic.
- Step 3: Analyze symbolism — the burnt roti symbolizes a life "half-cooked, half-burnt" by sudden displacement: nourishment (home) ruined by haste (Partition violence), yet still eaten (survival).
- Step 4: Analyze situational irony — the family flees to save their lives, but the very act of fleeing destroys the life they tried to preserve; the burnt roti, meant to sustain them for the journey, becomes the last taste of home they never expected to lose.
- Step 5: Connect to theme — this dual device encapsulates the chapter's central tension: survival requires abandoning what makes life meaningful.
REASONING: This example demonstrates how a single concrete detail can operate simultaneously as symbol (representing abstract trauma) and irony (contrasting intention/outcome), requiring multi-layered reading.
ANSWER: The burnt roti symbolizes the incomplete, damaged transition from rooted life to refugee existence. Its situational irony lies in the mother's mundane explanation ("hurry") for a ruin caused by historical catastrophe. Together, they show how ordinary domestic moments become archives of trauma — a key analytical move for board answers.

## WORKED_EXAMPLE_2
PROBLEM: The chapter's title "जक्तल्फक्कु ध झटर च्वीनस" (The Burning Pyre of the Kingdom) is itself a symbolic irony. Explain how the title works at three levels: literal, symbolic, and ironic.
STEPS:
- Step 1: Literal level — "जक्तल्फक्कु" (kingdom/state) and "झटर च्वीनस" (burning pyre) describe a state's funeral pyre; could refer to cremation grounds seen during migration.
- Step 2: Symbolic level — the "kingdom" represents the lost homeland (Pakistan/Punjab), the "pyre" represents the violence that consumed it, and the "burning" is the Partition itself — a civilization set ablaze.
- Step 3: Ironic level — a kingdom (राज्य) is meant to protect its people (प्रजा); here, the state's collapse (burning pyre) is caused by its own political decisions (Partition), making the protector the destroyer. The title ironically inverts the state's duty.
- Step 4: Narrative corroboration — the father, a loyal citizen, becomes a refugee; the "kingdom" he served burns his home. The child narrator witnesses this inversion without naming it.
- Step 5: Thematic synthesis — the title condenses the chapter's argument: political irony (state fails people) and symbolic loss (homeland as pyre) are inseparable.
REASONING: Titles are compressed symbolic-ironic statements; unpacking them trains students to read paratext as interpretation, a skill tested in board exams' "significance of title" questions.
ANSWER: The title operates as a symbolic irony: literally a cremation ground, symbolically the incineration of a homeland, ironically the self-destruction of a state meant to shelter. This three-layer reading models the depth expected in "explain the significance of the title" questions (3-4 marks).

## WORKED_EXAMPLE_3
PROBLEM: Compare the symbolism of the "पुराना संदूक" (old trunk) and the "टूटी हुई चारपाई" (broken cot) in representing two different responses to displacement. Use evidence from at least two different scenes.
STEPS:
- Step 1: Identify Scene 1 — packing the trunk: the father carefully selects documents, clothes, a deity photo; the trunk becomes a "portable homeland" symbolizing *preservation* of identity.
- Step 2: Identify Scene 2 — leaving the cot: the cot is too large, broken, left behind; the mother says "नई बनवा लेंगे" (we'll get a new one made), but her voice trembles. The cot symbolizes *surrender* — what cannot be carried, must be released.
- Step 3: Analyze trunk as active symbol — it travels, survives, reappears in the new home; represents continuity, agency, memory work.
- Step 4: Analyze cot as passive symbol — it remains, decays, vanishes; represents rupture, loss, the irretrievable.
- Step 5: Link to irony — the father's verbal irony ("we'll return") is contradicted by the cot's abandonment (situational irony: leaving behind what return would require).
- Step 6: Conclude — the two symbols map the dialectic of migration: carrying the past (trunk) while the past breaks you (cot). The chapter structures memory between these poles.
REASONING: This comparative analysis requires tracking symbols across narrative time, connecting them to character actions, and synthesizing their thematic opposition — a higher-order skill for long-answer questions.
ANSWER: The trunk symbolizes curated survival (what we choose to save); the cot symbolizes forced sacrifice (what breaks us to leave). Their contrast structures the chapter's exploration of migration as both an act of agency (packing) and an experience of victimization (abandoning). A board-level answer would cite the packing scene and the departure scene, then link to the father's ironic promise.

## COMPETENCY_QUESTION_1
QUESTION: In the chapter, the narrator observes: "पिताजी ने ताला लगाते समय चाबी अपनी जेब में नहीं, संदूक में रख दी" (While locking, father put the key not in his pocket but inside the trunk). Analyze this action as an instance of dramatic irony and a symbolic gesture. What does it reveal about the father's psychological state?
COMPETENCY: Literary analysis — interpreting character action as device
STEPS:
- Step 1: Recognize dramatic irony — the father locks the house and puts the key *inside* the locked trunk, making return impossible; the child narrator does not grasp this finality, but the reader does.
- Step 2: Identify symbolism — the key inside the trunk symbolizes sealing the past: the means of return (key) is trapped with the past (trunk), rendering both inaccessible.
- Step 3: Connect to psychology — the father performs the ritual of locking (normalcy) while subconsciously ensuring no return (key inside); this is protective denial made physical.
- Step 4: Link to theme — the action condenses the migrant's paradox: locking up to protect what you must abandon.
ANSWER: The key-in-trunk moment is dramatic irony (reader knows return is impossible; child doesn't) and a symbol of irreversible closure. It reveals the father's split consciousness: consciously performing departure rituals, unconsciously enacting permanent exile. This dual reading demonstrates how small actions carry structural meaning.
DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: The chapter ends with the narrator as an adult revisiting the abandoned house and finding the "टूटी हुई चारपाई" still there, now "मिट्टी में धँसी" (sunk in mud). Evaluate how this closing image transforms the cot's symbolism from Chapter 5's beginning and resolves (or deepens) the irony of the father's promise "हम जल्दी लौट आएंगे". Support with a structured PEEL paragraph.
COMPETENCY: Synthesis — tracing device evolution across narrative arc
STEPS:
- Step 1: Point — The cot's symbolism shifts from "abandoned loss" to "enduring witness," and the father's irony shifts from "protective lie" to "tragic truth."
- Step 2: Evidence — Initially, the cot is left behind as useless baggage; finally, it remains rooted in the soil of the homeland, outlasting the migrants.
- Step 3: Explanation — The cot's persistence mocks the father's promise: they never returned, but the cot *never left*. The irony deepens: the object they sacrificed for mobility becomes the only thing that truly "returned" by staying.
- Step 4: Link — This transformation elevates the cot from personal symbol to historical artifact: it embodies the land's memory of its people, making the chapter a testimony, not just a memoir.
- Step 5: Evaluation — The resolution is not closure but haunting; the irony is not resolved but perpetuated across generations.
ANSWER: [PEEL Paragraph] The broken cot, initially a symbol of forced abandonment, transforms into a permanent witness of displacement. In the opening, it is left behind because "नई बनवा लेंगे" (we'll make a new one) — a practical sacrifice. In the closing, it sits "मिट्टी में धँसी," rooted in the homeland the family could not return to. This deepens the father's verbal irony ("हम जल्दी लौट आएंगे"): the cot never needed to return because it never left. The irony thus shifts from a father's protective lie to history's cruel joke — the inanimate object achieves the permanence denied to humans. The chapter ends not with return but with the land remembering what the state forgot.
DIFFICULTY: hard