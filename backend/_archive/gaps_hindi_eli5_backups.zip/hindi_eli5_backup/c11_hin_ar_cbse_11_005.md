## DEFINITION
Supporting characters are secondary figures in a literary work who interact with the protagonist to advance the plot, reveal the protagonist's traits, or embody thematic ideas. In poetry, they may appear through direct address, memory, or symbolic presence rather than sustained action.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student can identify all supporting characters in "?kj dh ;kn", extract textual evidence for each character's traits and function, and write a structured analysis explaining how each supporting character deepens the portrayal of the protagonist's emotional conflict and the poem's central theme of separation and memory.

## SCOPE_BOUNDARY
This node covers character analysis of the wife (ek¡), children (ik¡posa), and the house (?kj) as a personified presence in Harivansh Rai Bachchan's poem "?kj dh ;kn". It does not cover the protagonist (the father/narrator) in depth, as that was addressed in the previous node (c11_hin_ar_cbse_11_004), nor does it cover thematic analysis beyond character-function connections.

## WALKTHROUGH
Imagine you are looking at an old family photograph where only one person is in sharp focus — the father — but the blurred figures around him (his wife, his children, the house behind them) are the reason his expression holds so much pain. In "?kj dh ;kn", the father's voice dominates, but the poem's emotional weight comes from those he left behind. Begin by asking: "Who else lives in this poem besides the speaker?" Mark every reference to 'ek¡', 'ik¡posa', 'firk', and 'ghar' across all stanzas. Notice how the wife never speaks but her silence screams; the children grow up in absentia; the house becomes a repository of memory. The key insight: supporting characters in lyric poetry often exist as fragmented images — a phrase here, a refrain there — and your task is to assemble these fragments into coherent character portraits that explain the protagonist's inner world.

## DIAGNOSTIC_QUESTION_1
In "?kj dh ;kn", which three supporting characters (or personified entities) appear most frequently across the stanzas, and what single word or phrase identifies each one in the text?

## DIAGNOSTIC_ANSWER_1
The three most frequent supporting presences are: (1) the wife/mother, identified by 'ek¡' (mother) and 'ek;osQ' (wife); (2) the children, identified by 'ik¡posa' (children) and 'cPps' (kids); (3) the house, identified by '?kj' (home) and personified as 'ifjrki dk ?kj' (house of waiting). A wrong answer — such as listing the father, the poet, or abstract concepts like 'memory' — reveals the student cannot distinguish the speaking 'I' (protagonist) from the figures he references, or confuses thematic nouns with characters.

## DIAGNOSTIC_QUESTION_2
The wife (ek¡) never speaks a single line in the poem, yet the poet calls the house "ifjrki dk ?kj" (house of waiting) in her honour. Explain in your own words how a silent character can become the emotional centre of a poem without uttering a word.

## DIAGNOSTIC_ANSWER_2
The wife's silence is her characterisation: she waits, manages the household ("cfgu vkbZ cki osQ ?kj"), and holds the family together ("pkj HkkbZ pkj cfgusa / Hkqtk HkkbZ I;kj cfgusa") while the father is absent. The house is named after her waiting ("ifjrki dk ?kj") because her patient endurance defines the domestic space. A wrong answer that claims "she is not important because she doesn't speak" or "the father is the only real character" reveals the misconception that character importance requires dialogue or direct action, ignoring how lyric poetry builds character through absence, implication, and the protagonist's obsessive focus.

## DIAGNOSTIC_QUESTION_3
In Stanza 4 (beginning "ik¡pok¡ eSa gw¡ vHkkxk..."), the father imagines his children's future reaction to his return. Apply the "show, don't tell" principle: quote two specific lines that *show* the children's resentment and two that *show* the father's guilt, then explain how these images function as characterisation for both parties.

## DIAGNOSTIC_ANSWER_3
Children's resentment shown: "firk th us dgk gksxk] gk;] fdruk lgk gksxk" (father will say, oh, how long it took) — the formal address 'firk th' and sarcastic 'fdruk lgk' reveal distance and bitterness. "jks iM+saxs vkSj cPps" (they will just laugh) — mocking laughter, not joy. Father's guilt shown: "c¡èkk cSBk gw¡ vHkkxk" (I sit with head bowed) — physical posture of shame. "eSa e'ks esa gw¡ lgh gS / ?kj ugha gw¡ cl ;gh gS" (I am right here / this is not home, this is a shadow) — self-erasure. A wrong answer that paraphrases ("the kids are angry, the dad feels bad") without quoting reveals inability to anchor analysis in textual evidence, a core board-exam requirement.

## DIAGNOSTIC_QUESTION_4
Compare the portrayal of the house in the opening refrain ("?kj u”kj esa frj jgk gS") with its portrayal in the closing stanzas ("foaQrq ;g cl cM+k cl gS / blh cl ls lc fojl gS"). Analyse how the house transforms from a physical space into a psychological state, and what this transformation reveals about the protagonist's relationship with his family.

## DIAGNOSTIC_ANSWER_4
Opening: the house is a concrete, sensory place — "?kj fd eq>ls nwj gS tks / ?kj [kq'kh dk iwj gS tks" (the house that has my scent / the house that is the orphan's shelter) — rooted in smell, touch, and familial roles. Closing: the house becomes "cl" (shadow) and "fojl" (mistake/illusion) — "eSa e'ks esa gw¡ lgh gS / ?kj ugha gw¡ cl ;gh gS" (I am right here / this is not home, this is a shadow). The transformation mirrors the father's realisation: the physical house persists, but the *emotional* home — built on his presence, his wife's waiting, his children's growth — has dissolved because he was absent. A wrong answer that treats the house as merely a setting in both cases misses the poem's central movement: the supporting character (house) absorbs the family's collective memory and ultimately exposes the protagonist's self-deception.

## DIAGNOSTIC_QUESTION_5
Critique this student statement: "The children in '?kj dh ;kn' are flat characters because they don't have names, individual personalities, or dialogue — they're just 'ik¡posa'." Defend or refute using evidence from at least three different stanzas.

## DIAGNOSTIC_ANSWER_5
Refute. The children are *collectively* characterised through developmental progression across stanzas, which is a deliberate poetic choice reflecting the father's guilt: Stanza 1 — "cfgu vkbZ cki osQ ?kj" (infants crawling); Stanza 4 — "ik¡pok¡ eSa gw¡ vHkkxk / ftls lksus ij lqgkxk" (children I cling to / who cling to laps) — toddlers needing physical contact; Stanza 5 — "jks iM+saxs cjkcj / ik¡posa dk uke ysdj" (they'll just laugh mockingly / naming the children) — older, articulate, resentful. Their lack of individual names *is* their characterisation: the father's absence has reduced them to a generic plural, just as his absence reduced his role to a generic 'father'. A wrong answer that accepts the "flat character" label reveals a novel-centric understanding of character (requiring name, backstory, arc) applied inappropriately to lyric poetry, where collective figures often carry thematic weight.

## DIAGNOSTIC_QUESTION_6
Write a 4-stanza poem (4 lines each) from the *wife's perspective* in "?kj dh ;kn", using the same refrain structure ("?kj u”kj esa frj jgk gS / pkj HkkbZ pkj cfgusa..."). Your poem must reveal her inner conflict: pride in holding the fort, resentment at solitary parenting, and the quiet fear that the returning husband is a stranger.

## DIAGNOSTIC_ANSWER_6
A strong response will: (1) maintain the refrain's rhythm and anaphora; (2) shift pronouns from 'I' (father) to 'I' (mother) with corresponding changes in agency — she *acts* ("dk;Z djrh gw¡", "ek¡ dks iM+rhi gw¡") where he *remembers*; (3) embed specific textual echoes — "cfgu vkbZ" becomes "cfgu c<+kh", "ifjrki" becomes "ifjrk ugha thk"; (4) end not with self-justification ("eSa e'ks esa gw¡ lgh gS") but with a question to the absent husband. A poor answer that merely translates the father's stanzas into feminine grammar ("ek¡ u”kj esa frj jgk gS") without new emotional material reveals inability to inhabit a supporting character's distinct consciousness — the core skill of character analysis.

## COMMON_MISCONCEPTION
Students believe "supporting character analysis" means writing a mini-biography for each character (age, personality, likes/dislikes) as if they were real people. In "?kj dh ;kn", the wife, children, and house are *poetic constructs* — they exist only through the father's memory and the poem's imagery. The misconception leads to answers like "The wife is a strong, patient woman who loves her husband" (unsupported generalisation) instead of "The wife is constructed through the metaphor 'ifjrki dk ?kj' and the image 'cfgu vkbZ cki osQ ?kj', which portray her as the silent architect of domestic continuity." The error stems from importing prose-fiction character expectations (rounded/flat, static/dynamic) into lyric poetry where characters are often *functions* of the speaker's psyche.

## ON_FAILURE
Step 1: Ask the student to list every noun/pronoun referring to someone other than "eSa" (I) in the poem. Step 2: For each, ask: "Does this figure speak? Act? Or only appear in the speaker's memory/imagination?" Step 3: Show how the text *constructs* the wife through three specific images (Stanza 2: "cfgu vkbZ cki osQ ?kj"; Stanza 3: "ek;osQ vkbZ cgu osQ fy, ifjrki dk ?kj"; Stanza 5: "firk th dgrs jgs gSa / I;kj esa cgrs jgs gSa" — reported speech). Step 4: Practice writing one analytical sentence per figure using the template: "The poem constructs [figure] as [trait/function] through [specific image/refrain] in Stanza [X], which reveals [effect on protagonist/theme]." Repeat until the student separates *textual construction* from *assumed biography*.

## BUILDS_ON
c11_hin_ar_cbse_11_004 (Character Analysis: Protagonist) — students must already understand the father's voice, guilt, and narrative stance before analysing how supporting figures reflect and refract him.

## LEADS_TO
c11_hin_ar_cbse_11_006 (Theme: Primary Theme and Message) — supporting characters' collective portrayal of waiting, growth, and decay directly embodies the poem's central theme of time, separation, and the impossibility of return.

## PREREQUISITE_NODE_IDS
c11_hin_ar_cbse_11_001, c11_hin_ar_cbse_11_002, c11_hin_ar_cbse_11_004, c11_hin_ar_cbse_11_003

## PREREQUISITE_REASONS
c11_hin_ar_cbse_11_001: Provides biographical and historical context (Bachchan's life, Chhayavad movement) essential for understanding why the father is absent and the poem's autobiographical weight.
c11_hin_ar_cbse_11_002: Establishes the poem's narrative structure (refrain-driven, non-linear memory) so students can track where supporting characters appear across stanzas.
c11_hin_ar_cbse_11_004: The protagonist analysis gives the father's psychological baseline — his guilt, alienation, and self-justification — which the supporting characters mirror, contradict, or intensify.
c11_hin_ar_cbse_11_003: Supporting characters (father, mother, children) exist only through their interactions with the house's spaces.  

## FORWARD_NODE_IDS
c11_hin_ar_cbse_11_006, c11_hin_ar_cbse_11_007, c11_hin_ar_cbse_11_013, c11_hin_ar_cbse_11_008, c11_hin_ar_cbse_11_012, c11_hin_ar_cbse_11_014, c12_hin_a_cbse_11_005, c12_hin_ar_cbse_06_005, c12_hin_ar_cbse_11_005

## FORWARD_REASONS
c11_hin_ar_cbse_11_006: The primary theme (time/separation/irreversibility) is enacted through the supporting characters — the wife's waiting, children's aging, house's decay — so character analysis feeds directly into thematic articulation.
c11_hin_ar_cbse_11_007: Secondary themes (gendered labor, generational gap, memory vs. reality) emerge from the specific characterisations of wife (domestic burden), children (resentful growth), and house (memory vessel).
c11_hin_ar_cbse_11_013: Critical interpretation requires synthesising character-function evidence — e.g., "Is the house a character or a symbol?" — which this node's analytical framework enables.
c11_hin_ar_cbse_11_008: Explains the father's role, crucial for understanding the auditory imagery of his voice.  
c11_hin_ar_cbse_11_012: Supporting characters (father) are central to key inferential questions about loss.  
c11_hin_ar_cbse_11_014: Supporting character analysis (father, mother) provides evidence for relationship questions.  
c12_hin_a_cbse_11_005: Class 11 introduced the terminology (foil, confidant, allegorical figure) used here at higher depth.  
c12_hin_ar_cbse_06_005: Class 11 foundation on supporting character analysis in Aroh.  
c12_hin_ar_cbse_11_005: Class 11 foundation in supporting character analysis (foil, mirror, catalyst roles) — this node deepens it with meta-fictional complexity.  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
none

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_11_004 -> c11_hin_ar_cbse_11_005 -> c11_hin_ar_cbse_11_006

## THIS_FORMULA
N/A - conceptual

## FORMULA_VARIABLES
N/A

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
analytical

## CROSS_SUBJECT
c11_history_indian_national_movement | The poem's context (Bachchan's involvement in the freedom struggle, his absences from home for political work) mirrors the father's absence — supporting characters embody the domestic cost of public duty, a theme relevant to studying families of freedom fighters.
c11_psychology_human_development | The children's portrayal across stanzas maps onto developmental psychology: infant dependency (Stanza 1-2), early childhood attachment (Stanza 4 "lksus ij lqgkxk"), adolescent individuation and resentment (Stanza 5 "jks iM+saxs cjkcj") — the poem compresses years of development into poetic fragments.

## PREREQ_CONCEPT
Understanding that in lyric poetry, supporting characters are often *focalised* through the speaker's consciousness — we see them only as the speaker remembers, imagines, or addresses them.

## PREREQ_BEFORE
Student must be able to identify the speaker ("eSa"), trace the refrain structure, and articulate the father's core conflict (guilt vs. self-justification) from the protagonist analysis node.

## PREREQ_STUCK
Review c11_hin_ar_cbse_11_004's worked example on the father's "dual voice" (the remembering 'I' vs. the justifying 'I') — supporting characters exist primarily to trigger and test that duality.

## WORKED_EXAMPLE_1
PROBLEM: Analyse how the refrain "pkj HkkbZ pkj cfgusa / Hkqtk HkkbZ I;kj cfgusa" (four arms, four legs / six arms, six legs) constructs the wife as a supporting character across Stanzas 1, 2, and 3.
STEPS:
- Step 1: Locate the refrain in each of the first three stanzas and note what immediately precedes/follows it — Stanza 1 follows "ek;osQ vkbZ cgu osQ fy, / cfgu vkbZ cki osQ ?kj"; Stanza 2 follows "firk th ftudks cq<+kik / ,d {k.k Hkh ugha O;kik"; Stanza 3 follows "vkt xhrk ikB djosQ / naM nks lkS lkB djosQ".
- Step 2: Identify the grammatical subject of each preceding clause — Stanza 1: "ek;osQ" (wife) and "cfgu" (children); Stanza 2: "firk th" (father) — but the father is *absent* ("cq<+kik"), leaving the wife alone; Stanza 3: implied future where children ("xhrk", "lkS") take on adult roles.
- Step 3: Analyse the refrain's arithmetic — "pkj HkkbZ pkj cfgusa" = 2 people × 2 arms/legs = wife + father (complete family unit); "Hkqtk HkkbZ I;kj cfgusa" = 3 people × 2 arms/legs = wife + 2 children (father replaced by second child). The arithmetic *changes* across stanzas.
- Step 4: Connect to characterisation — The wife's body count shifts from "4 arms/legs" (with husband) to "6 arms/legs" (with children, without husband). She physically *absorbs* the missing father's labour. The refrain doesn't just repeat; it *counts* her increasing burden.
- Step 5: State the analytical conclusion — The wife is constructed not through adjectives but through *mathematical imagery* that quantifies her compensatory labour. The refrain is her character arc in numbers.
REASONING: This example models the core skill: supporting characters in this poem are built through structural patterns (refrain variation, arithmetic progression) rather than descriptive passages. Students learn to track a single device across stanzas to extract characterisation.
ANSWER: The wife emerges as the poem's silent protagonist — the refrain's shifting arithmetic (4→6 limbs) maps her transition from partner to sole caregiver. Each stanza adds a layer: Stanza 1 establishes the ideal unit; Stanza 2 reveals the fracture (father absent, "cq<+kik"); Stanza 3 projects the future where children grow but the count remains 6 — the father never returns to restore the 4. Her character *is* the arithmetic of absence.

## WORKED_EXAMPLE_2
PROBLEM: The house (?kj) is addressed as "ifjrki dk ?kj" (house of waiting) in Stanza 2. Using only Stanzas 1, 2, and 5, write a 3-point character profile of the house as a supporting character, with one quoted evidence per point.
STEPS:
- Step 1: Define the analytical lens — treat the house as a *character* with agency, memory, and relationship to others, not as setting. Ask: What does the house *do*? What does it *know*? How does it *change*?
- Step 2: Extract evidence for Point 1 (House as Witness) — Stanza 1: "?kj fd ?kj esa pkj HkkbZ / pkj fd brus dc tqM+s gSa" (the house where four arms, four legs / where however many meet). The house *knows* the family's bodily presence; "tqM+s" (meet/unite) gives it agency as the site of reunion.
- Step 3: Extract evidence for Point 2 (House as Keeper of Absence) — Stanza 2: "ek;osQ vkbZ cgu osQ fy, / ?kj dks ifjrki dk ?kj dgk gS" (for the lonely wife / the house is called house of waiting). The house *receives a name* based on the wife's state — it *becomes* her waiting. Personification: the house accepts this identity.
- Step 4: Extract evidence for Point 3 (House as Failed Promise) — Stanza 5: "foaQrq ;g cl cM+k cl gS / blh cl ls lc fojl gS" (alas, this shadow is very big / from this shadow everything is mistake). The house *transforms* into "cl" (shadow) and "fojl" (error/illusion) — it fails to be the home the father promised to return to.
- Step 5: Synthesise into a profile — The house is a loyal witness turned involuntary monument to waiting, ultimately exposed as a shadow. Its character arc: presence → personification → disillusionment.
REASONING: This models the "character profile from fragments" method required for board exams: each point = one textual anchor + one interpretive leap + connection to protagonist/theme. The house never speaks, but the poem *speaks through* the house.
ANSWER: Character Profile of the House: (1) Witness to Intimacy — "?kj fd ?kj esa pkj HkkbZ / pkj fd brus dc tqM+s gSa" (Stanza 1): the house holds the family's physical togetherness, its very walls defined by their meeting. (2) Embodiment of Waiting — "?kj dks ifjrki dk ?kj dgk gS" (Stanza 2): the house *becomes* the wife's waiting; its identity is conferred by her endurance. (3) Shadow of Betrayal — "foaQrq ;g cl cM+k cl gS / blh cl ls lc fojl gS" (Stanza 5): the house dissolves into illusion, revealing that without the father's return, it was never a home — only a shadow of one.

## WORKED_EXAMPLE_3
PROBLEM: Compare the father's imagined future dialogue with his children (Stanza 4: "firk th dgrs jgs gSa / I;kj esa cgrs jgs gSa") with the wife's reported speech about the father (Stanza 3: "firk th ftudks cq<+kik / ,d {k.k Hkh ugha O;kik"). Analyse how these two *reported speech* passages construct the father differently — and what this reveals about the wife's character as the keeper of truth.
STEPS:
- Step 1: Isolate the two reported speech blocks — Block A (father's imagination, Stanza 4): "firk th dgrs jgs gSa / I;kj esa cgrs jgs gSa / vkt muosQ Lo.kZ csVs / yxs gksaxs mUgsa gsVs / D;ksafd eSa muij lqgkxk / c¡èkk cSBk gw¡ vHkkxk". Block B (wife's description to children, Stanza 3): "firk th ftudks cq<+kik / ,d {k.k Hkh ugha O;kik / tks vHkh Hkh nkSM+ tk,¡ / tks vHkh Hkh f[kyf[kyk,¡".
- Step 2: Analyse Block A's construction of the father — He imagines himself *humble* ("c¡èkk cSBk"), *causally linked* to children's growth ("D;ksafd eSa muij lqgkxk"), *awaiting judgment* ("firk th dgrs jgs gSa / I;kj esa cgrs jgs gSa"). He controls the narrative: he is the penitent centre.
- Step 3: Analyse Block B's construction of the father — The wife tells the children he is "cq<+kik" (gone/fled) and ",d {k.k Hkh ugha O;kik" (not even one virtue). She adds: "tks vHkh Hkh nkSM+ tk,¡ / tks vHkh Hkh f[kyf[kyk,¡" (who still have to go / who still tremble) — referring to *herself and the children* as the ones still suffering. The father is *absent from virtue*, not just absent in body.
- Step 4: Contrast the two fathers — Father's version: tragic, self-aware, central. Wife's version: deficient, peripheral, the cause of ongoing tremor ("f[kyf[kyk"). The wife's speech *refuses* the father's self-mythologising.
- Step 5: Deduce the wife's character — She is the *truth-teller* who strips the father's romanticised absence to its bare reality: desertion without virtue. Her reported speech is the poem's only external perspective on the father — and it devastates his self-justification.
- Step 6: Connect to theme — The wife's truth-telling makes "?kj dh ;kn" not just a poem of nostalgia but of *accountability*. The supporting character (wife) becomes the moral compass the protagonist lacks.
REASONING: This advanced example combines three concepts: reported speech analysis, character construction through contrast, and thematic function of supporting characters. It demonstrates how a single supporting character's words (even reported) can restructure the reader's understanding of the protagonist — a high-order board exam skill.
ANSWER: The father imagines a future where he returns as a penitent ("c¡èkk cSBk") and the children judge him ("I;kj esa cgrs jgs gSa") — he remains the protagonist of his own drama. The wife's reported speech destroys this: "firk th ftudks cq<+kik / ,d {k.k Hkh ugha O;kik" — he fled, he has no virtue. She reframes the suffering: "tks vHkh Hkh nkSM+ tk,¡ / tks vHkh Hkh f[kyf[kyk,¡" — *we* (wife and children) are the ones still trembling, still going forward. The wife emerges as the poem's moral centre: she names the absence honestly, bears the continuing cost, and denies the father the redemption he scripts for himself. Her character = truth-telling endurance.

## COMPETENCY_QUESTION_1
QUESTION: In "?kj dh ;kn", the children are never directly described by the poet — they appear only through the father's memory (Stanzas 1-2), the father's imagination (Stanza 4), and the wife's reported speech (Stanza 3). Using evidence from all three modes, explain how the poem constructs the children's *growth* as a measure of the father's *failure*. Your answer must reference at least one specific line from each of the three modes.
COMPETENCY: Textual Synthesis and Character-Function Analysis
STEPS:
- Step 1: Identify the three modes of presentation — Memory (Stanzas 1-2): "cfgu vkbZ cki osQ ?kj" (crawling children); Imagination (Stanza 4): "ik¡pok¡ eSa gw¡ vHkkxk / ftls lksus ij lqgkxk" (children I cling to / who cling to laps); Reported Speech (Stanza 3): "tks vHkh Hkh nkSM+ tk,¡ / tks vHkh Hkh f[kyf[kyk,¡" (who still have to go / who still tremble).
- Step 2: Trace the developmental arc — Infants crawling → toddlers clinging → adolescents/adults "still trembling" and "still having to go" (life continuing without him).
- Step 3: Map each stage to the father's absence — His absence *is* the timeline: he missed the crawling, he misses the clinging, he will miss the trembling adulthood.
- Step 4: Formulate the analytical claim — The children's growth is not celebrated; it is *calibrated* against the father's void. Each stage deepens his failure: he wasn't there for the first steps, isn't there for the need for lap-clinging, won't be there for the adult struggles.
- Step 5: Write the structured answer using PEEL — Point, Evidence (three quotes), Explanation (growth = failure metric), Link (theme of irreversible time).
ANSWER: The poem uses the children's growth as a chronological indictment of the father's absence. In memory (Stanza 1), they are "cfgu vkbZ cki osQ ?kj" — crawling infants whose first movements he missed. In imagination (Stanza 4), they are "ik¡pok¡ eSa gw¡ vHkkxk / ftls lksus ij lqgkxk" — toddlers still needing laps, a need he can only *imagine* fulfilling. In the wife's truth-telling (Stanza 3), they become "tks vHkh Hkh nkSM+ tk,¡ / tks vHkh Hkh f[kyf[kyk,¡" — beings who "still have to go" and "still tremble" through life's journey without him. The progression from crawling → clinging → trembling maps the father's failure onto their bodies: each developmental milestone is a milestone of his absence. The children do not grow *despite* him; they grow *marked* by him. Their growth is the poem's most damning evidence against the father's self-justification.
DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: A critic argues: "In '?kj dh ;kn', the house is not a character but a symbol — it represents tradition, stability, and the past. Treating it as a character with agency and arc is a category error." Evaluate this claim by analysing *three* moments where the house *acts* or *is acted upon* as an agent, and explain whether the critic's distinction between 'character' and 'symbol' holds in this poem.
COMPETENCY: Critical Evaluation of Literary Concepts
STEPS:
- Step 1: Define the critic's terms — Symbol: static, representational, meaning imposed by reader. Character: dynamic, agentive, participates in narrative/emotional action.
- Step 2: Find Moment 1 (House as Agent) — Stanza 1: "?kj fd ?kj esa pkj HkkbZ / pkj fd brus dc tqM+s gSa" — the house *hosts* ("tqM+s" = meet/unite, active verb), its interior space *enables* family unity. The house *does* something: it gathers.
- Step 3: Find Moment 2 (House as Recipient of Identity) — Stanza 2: "?kj dks ifjrki dk ?kj dgk gS" — the house *receives a name* based on the wife's state. It *becomes* "house of waiting" — a transformation conferred by another character's experience. This is character-like: identity shaped by relationship.
- Step 4: Find Moment 3 (House as Failed Promise) — Stanza 5: "foaRq ;g cl cM+k cl gS / blh cl ls lc fojl gS" — the house *turns into* "cl" (shadow) and "fojl" (mistake). It *changes nature* in the speaker's perception — a reversal of its earlier role as shelter. This is an arc: shelter → waiting-house → shadow.
- Step 5: Evaluate the critic — The house *functions* as both symbol and character simultaneously. In lyric poetry, the distinction collapses: a symbol *becomes* a character when the speaker *relates to it* as a presence with history, agency, and betrayal. The father addresses it ("?kj u”kj esa frj jgk gS"), names it, and finally rejects it — a relational arc. The critic's binary is a prose-novel framework misapplied to poetry.
- Step 6: Conclude with nuance — The house is a *personified symbol* or *symbolic character* — a hybrid category essential for analysing lyric poetry's compressed characterisation.
ANSWER: The critic's distinction fails for this poem because the house occupies a lyric-specific hybrid category: it is a *personified symbol* that undergoes a relational arc. Three moments prove its agency: (1) Stanza 1 — "?kj fd ?kj esa pkj HkkbZ / pkj fd brus dc tqM+s gSa" — the house actively *gathers* the family ("tqM+s" = unite/meet), its space enabling intimacy. (2) Stanza 2 — "?kj dks ifjrki dk ?kj dgk gS" — the house *accepts an identity* conferred by the wife's waiting; it becomes what she endures. (3) Stanza 5 — "foaRq ;g cl cM+k cl gS / blh cl ls lc fojl gS" — the house *transforms* into shadow and error, its meaning collapsing under the weight of broken return. A static symbol does not gather, accept identity, or collapse. The house *relates* to the wife (becomes her waiting), to the father (becomes his guilt), and to time (becomes shadow). In lyric poetry, where characters are often constructed through address and perception, the house *is* a character — one made of bricks and memory, whose arc mirrors the family's disintegration. The critic imposes a novelistic binary on a form that dissolves it.
DIFFICULTY: hard