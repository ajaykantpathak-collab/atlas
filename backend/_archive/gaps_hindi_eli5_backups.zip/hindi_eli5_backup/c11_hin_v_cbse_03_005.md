## DEFINITION
Character analysis of supporting characters involves examining how secondary figures in a narrative reveal the protagonist's traits, advance thematic concerns, and embody social realities through their actions, speech, relationships, and narrative function—without being the central focus of the story.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student can identify three supporting characters, cite textual evidence for each character's distinguishing traits, explain how each character's interaction with the protagonist illuminates the protagonist's journey, and articulate how these characters collectively represent broader social structures (class, gender, literacy) in the text.

## SCOPE_BOUNDARY
This node covers analysis of Rakhi, Rakhi's husband, the three children (VatS, Je.k, Lq[knhi), Tsbw, KfeZyk nh, Lquhy, and Vkdk'k as supporting characters in "vkyks&vk¡èkkfj." It does NOT cover the protagonist's internal monologue (covered in node 004), plot structure (node 002), or thematic synthesis (nodes 006-007).

## WALKTHROUGH
Imagine you're watching a family dinner where the protagonist serves food but never sits at the table. The people eating—the employer's wife who complains about the salt, the husband who asks about your studies, the child who shows you their drawing—each reveals something about the protagonist's world without saying a word about her directly. Start by listing every named character who speaks or acts in the protagonist's presence. For each, ask: What does this character want? How do they treat the protagonist? What social role do they embody? The key insight: supporting characters are not "minor"—they are the mirrors and makers of the protagonist's reality.

## DIAGNOSTIC_QUESTION_1
Name three supporting characters from "vkyks&vk¡èkkfj" and state one defining action or speech for each that reveals their attitude toward the protagonist.

## DIAGNOSTIC_ANSWER_1
Correct answer: (1) Rakhi — asks "रक्रीक, तू यहाँ क्या करती है?" showing suspicion; (2) Rakhi's husband — says "मैं तुम्हारी कहानी छपवाऊँगा" showing encouragement; (3) Vkdk'k — brings food to the protagonist saying "माँ ने भेजा है" showing care across class lines. A wrong answer that lists only names without textual evidence reveals the student confuses character identification with character analysis.

## DIAGNOSTIC_QUESTION_2
Explain in your own words how Rakhi's attitude toward the protagonist changes from the beginning to the middle of the narrative, and identify the specific incident that marks this shift.

## DIAGNOSTIC_ANSWER_2
Correct answer: Initially Rakhi interrogates the protagonist ("तू यहाँ कैसे आई?"), monitoring her movements. The shift occurs when the protagonist begins writing—Rakhi then asks her to read aloud, offers paper, and says "तू बहुत अच्छा लिखती है." A wrong answer describing only the final relationship misses the power dynamic reversal: literacy becomes the lever that forces Rakhi to recognize the protagonist's humanity.

## DIAGNOSTIC_QUESTION_3
The text describes Vkdk'k (the watchman's son) bringing food to the protagonist. Using this incident, explain how a minor character can embody a thematic contradiction in the narrative.

## DIAGNOSTIC_ANSWER_3
Correct answer: Vkdk'k belongs to the same working class as the protagonist, yet his mother sends food to her—an act of solidarity that contradicts the class-based exploitation the protagonist faces from employers. This mirrors the text's central tension: the poor sustain each other while the wealthy extract labor. A wrong answer that only summarizes the plot event fails to connect the character's action to the theme of class solidarity versus class oppression.

## DIAGNOSTIC_QUESTION_4
Compare how Rakhi's husband and Tsbw each respond to the protagonist's writing. What does this comparison reveal about gender and class positions in the text?

## DIAGNOSTIC_ANSWER_4
Correct answer: Rakhi's husband (educated, male, employer-class) offers public validation—"मैं तुम्हारी कहानी छपवाऊँगा"—exerting institutional power. Tsbw (female, fellow worker) responds with private recognition—"तू तो हमारी आवाज़ बन गई"—exerting communal solidarity. The contrast shows that empowerment operates differently across class and gender: the patriarchal gatekeeper grants access to public sphere; the peer affirms identity within the private sphere. A wrong answer treating both responses as "support" flattens the structural analysis.

## DIAGNOSTIC_QUESTION_5
Evaluate the claim: "Lquhy (the previous domestic worker) functions only as a foil to highlight the protagonist's resilience." Defend or refute using textual evidence.

## DIAGNOSTIC_ANSWER_5
Correct answer: Refute. Lquhy is not merely a foil—she is a warning. When Lquhy says "मैं यहाँ नहीं रहूँगी" and leaves, she demonstrates that exit is possible but costly. The protagonist stays not because she is "stronger" but because she has children to feed and no alternative shelter. Lquhy's departure sharpens the protagonist's dilemma: resistance risks destitution. A wrong answer accepting the foil claim reduces a structural constraint to a character contrast.

## DIAGNOSTIC_QUESTION_6
Write a 100-word diary entry from the perspective of Je.k (the younger son) describing the day he discovers the protagonist can read and write. Use textual details to make it authentic.

## DIAGNOSTIC_ANSWER_6
Criteria for a strong answer: (1) Uses child's voice—simple sentences, concrete sensory details (smell of ink, sound of pages turning); (2) References a specific textual moment (e.g., protagonist reading a letter aloud); (3) Shows Je.k's confusion turning to respect, not adult analysis; (4) Ends with a child's question ("क्या तू मुझे भी सिखाएगी?"). A weak answer writes in adult voice, invents events not in text, or makes Je.k articulate class theory.

## COMMON_MISCONCEPTION
Students treat supporting characters as "background information" to be listed, not as structural elements that construct the protagonist's social world. They write: "Rakhi is the employer's wife. She is strict but later becomes kind." This misses that Rakhi's "kindness" is conditional on the protagonist's literacy serving Rakhi's status ("मेरी नौकरानी लिखती है"). The misconception arises because Class 10 character sketches asked for trait lists; Class 11 demands functional analysis—what does this character DO to the narrative's meaning?

## ON_FAILURE
Step 1: Have the student pick ONE supporting character and find three moments where that character speaks directly to the protagonist. Step 2: For each moment, ask: "What does the protagonist learn about her own position from this exchange?" Step 3: Ask: "If this character were removed, what would the protagonist NOT understand about her world?" Step 4: Guide the student to write one paragraph answering: "This character exists in the narrative to show that ______." This shifts focus from trait-listing to narrative function.

## BUILDS_ON
Character Analysis: Protagonist (node 004) — students must first understand the protagonist's central conflict (literacy vs. labor, voice vs. silence) before analyzing how supporting characters reflect, resist, or enable that conflict.

## LEADS_TO
Theme: Primary Theme and Message (node 006) — supporting characters embody the social structures (patriarchy, class hierarchy, literacy as power) that the primary theme critiques.

## PREREQUISITE_NODE_IDS
c11_hin_v_cbse_03_001, c11_hin_v_cbse_03_002, c11_hin_v_cbse_03_004, c11_hin_v_cbse_03_003

## PREREQUISITE_REASONS
c11_hin_v_cbse_03_001: Context and Background provides the socio-historical setting (domestic labor in urban India) necessary to understand supporting characters' class positions.
c11_hin_v_cbse_03_002: Plot and Narrative Structure establishes the sequence of events where supporting characters enter/exit, enabling analysis of their narrative timing.
c11_hin_v_cbse_03_004: Character Analysis: Protagonist defines the protagonist's arc (silence to writing) which supporting characters mirror, challenge, or facilitate.
c11_hin_v_cbse_03_003: Supporting characters (lquhy, rkrq'k, ckck, tsBw) are defined by their relationship to the settings they inhabit or control; their atmospheric function precedes their character analysis.  

## FORWARD_NODE_IDS
c11_hin_v_cbse_03_006, c11_hin_v_cbse_03_007, c11_hin_v_cbse_03_013, c11_hin_v_cbse_03_008, c11_hin_v_cbse_03_012, c12_hin_a_cbse_06_005, c12_hin_al_cbse_03_005, c12_hin_ar_cbse_06_005, c12_hin_v_cbse_01_005, c12_hin_v_cbse_03_005

## FORWARD_REASONS
c11_hin_v_cbse_03_006: Primary Theme and Message requires evidence from supporting characters (e.g., Rakhi's class anxiety, Tsbw's solidarity) to substantiate thematic claims.
c11_hin_v_cbse_03_007: Secondary Themes (gender, education, dignity of labor) are carried by specific supporting characters—analysis here feeds thematic tracing.
c11_hin_v_cbse_03_013: Critical Thinking: Analysis and Interpretation demands comparative character analysis across the text, building directly on this node's skills.
c11_hin_v_cbse_03_008: Supporting characters (employers, children, husband) are the *objects* of metaphors (son, cage, master) — understanding their roles clarifies vehicle choice.  
c11_hin_v_cbse_03_012: Supporting character dynamics offer the relational context for inferring motives of employers/family.  
c12_hin_a_cbse_06_005: अगला तार्किक चरण: Character analysis of supporting characters involves examining secondary figures in a literary text... इस नोड की अवधारणाओं को सीधे उपयोग/विस्तारित करता है।  
c12_hin_al_cbse_03_005: Vitan Chapter 3 (अतीत में दबे पाँव) uses minor characters as historical witnesses — same testimonial function.  
c12_hin_ar_cbse_06_005: Class 11 Vitan foundation on supporting character analysis.  
c12_hin_v_cbse_01_005: Develops skill of linking character to theme via authorial intent.  
c12_hin_v_cbse_03_005: Class 11 node introduced the classification of supporting characters (foil, guide, chorus, symbol) — this node applies that framework to a non-fiction travelogue.  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
none

## CHAIN_DESCRIPTION
c11_hin_v_cbse_03_004 -> c11_hin_v_cbse_03_005 -> c11_hin_v_cbse_03_006

## THIS_FORMULA
N/A - conceptual

## FORMULA_VARIABLES
N/A

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
conceptual

## CROSS_SUBJECT
c11_sociology_social_stratification | Supporting characters in "vkyks&vk¡èkkfj" embody caste-class-gender intersections in domestic labor—Rakhi as employer-class woman, protagonist as Dalit/working-class woman, Vkdk'k as generational mobility—mirroring sociological concepts of intersectionality and structural inequality.
c11_history_women_labour_movements | The protagonist's journey from oral to written expression parallels historical trajectories of women workers gaining literacy and voice in late 20th-century India; Tsbw and KfeZyk nh represent collective organizing precursors.

## PREREQ_CONCEPT
Protagonist's central conflict: the tension between enforced silence (illiteracy, domestic servitude) and claimed voice (writing, self-narration).

## PREREQ_BEFORE
Student can summarize the protagonist's journey in 3-4 sentences using specific textual milestones (first letter written, first story read aloud, first publication).

## PREREQ_STUCK
Review node 004 (Character Analysis: Protagonist) worked examples on tracking the protagonist's literacy milestones.

## WORKED_EXAMPLE_1
PROBLEM: Analyze how Rakhi's husband functions as a "benevolent patriarch" in the narrative. Use three textual moments to show how his support both empowers and constrains the protagonist.

STEPS:
- Step 1: Identify the character's structural position—educated male, employer-class, husband of the direct employer. This positions him as a gatekeeper of public sphere access (publication, recognition).
- Step 2: Locate Moment 1 — Early encouragement: "मैं तुम्हारी कहानी छपवाऊँगा" (I'll get your story published). Note: he decides the venue, the timing, the form. The protagonist's agency is filtered through his institutional power.
- Step 3: Locate Moment 2 — Domestic intervention: He arranges for the protagonist's children's schooling ("बच्चों को स्कूल भेजो"). This extends his patriarchal care to the next generation, but frames education as his gift, not the protagonist's right.
- Step 4: Locate Moment 3 — Public validation: He introduces her to literary circles ("ये मेरी नौकरानी है, लिखती है"). The phrase "मेरी नौकरानी" (my maid) reinscribes ownership even while celebrating her talent.
- Step 5: Synthesize — His benevolence is real but bounded: it operates within patriarchal ownership ("मेरी") and class hierarchy ("नौकरानी"). The protagonist gains voice but remains "his" discovery. This duality is the character's narrative function.

REASONING: This analysis moves beyond "he is kind" to "he embodies the conditional nature of patriarchal patronage." Each step uses a specific textual moment to show how the character's action simultaneously opens and closes doors for the protagonist.

ANSWER: Rakhi's husband is a benevolent patriarch whose support for the protagonist's literacy is genuine but structurally limited—he grants access to the public sphere while retaining proprietary language ("मेरी नौकरानी"), extends care to her children while framing it as his benevolence, and validates her writing while controlling its circulation. His character reveals that empowerment within hierarchy always carries the terms of the hierarchy itself.

## WORKED_EXAMPLE_2
PROBLEM: The three children (VatS, Je.k, Lq[knhi) represent three distinct responses to the protagonist's literacy. Map each child's response to a specific stage of the protagonist's journey and explain what each reveals about intergenerational transmission of class privilege.

STEPS:
- Step 1: Establish the protagonist's literacy stages — (a) Secret learning (hiding writing), (b) Public reading (reading aloud to family), (c) Published writing (recognition beyond household).
- Step 2: Map VatS (eldest son) — Responds to Stage (b) with discomfort: "तू पढ़ती है?" (You read?). His question marks the boundary crossing. As heir to class privilege, he senses literacy threatens the servant-master distinction that secures his status.
- Step 3: Map Je.k (younger son) — Responds to Stage (c) with curiosity: "क्या तू मुझे भी सिखाएगी?" (Will you teach me too?). His request inverts the hierarchy momentarily—the master's son asks the servant for knowledge. This reveals privilege's fragility when knowledge crosses class lines.
- Step 4: Map Lq[knhi (daughter) — Responds across all stages with absorption: she learns letters alongside the protagonist, mimics her writing. She embodies the possibility of a different gendered future—literacy as play, not power struggle.
- Step 5: Synthesize — The three children form a triad: resistance (VatS), negotiation (Je.k), assimilation (Lq[knhi). Together they show how class privilege is negotiated, not simply inherited, in the intimate space of the household.

REASONING: This example demonstrates how supporting characters can be analyzed as a system—each child represents a distinct structural response to the same disruption (a servant becoming literate). The analysis connects individual character beats to the sociological concept of intergenerational class reproduction.

ANSWER: VatS resists the protagonist's literacy as a threat to class order; Je.k negotiates it by seeking access to her knowledge; Lq[knhi assimilates it as natural play. The triad reveals that class privilege is not passively inherited but actively negotiated by each generation—and that a literate domestic worker destabilizes the cultural capital that sustains that privilege.

## WORKED_EXAMPLE_3
PROBLEM: Tsbw and KfeZyk nh are both working-class women who write. Compare their literary practices to argue whether the text presents writing as individual salvation or collective resistance.

STEPS:
- Step 1: Characterize Tsbw's writing — Private, therapeutic, hidden ("डायरी में लिखती है"), focused on personal survival ("अपना दर्द भूलने के लिए"). She writes to endure.
- Step 2: Characterize KfeZyk nh's writing — Public, political, published ("कविताएँ छपती हैं"), focused on collective voice ("हमारी आवाज़"). She writes to challenge.
- Step 3: Locate their interaction — When protagonist meets KfeZyk nh through Tsbw, the text shows a lineage: Tsbw introduces protagonist to KfeZyk nh's work, protagonist finds her own voice validated. The chain is: private survival writing → public resistance writing → new writer empowered.
- Step 4: Analyze the protagonist's position — She begins like Tsbw (secret diary), moves toward KfeZyk nh (published stories), but retains Tsbw's groundedness (writes about domestic labor, not abstract ideals).
- Step 5: Evaluate the text's stance — The narrative structure (Tsbw → KfeZyk nh → Protagonist) suggests writing travels as a relay: individual survival enables collective resistance, which enables new individual voices. It is not either/or—it is a continuum.
- Step 6: Connect to supporting character function — Tsbw and KfeZyk nh are not just "friends who write"; they represent historical stages of working-class women's literary emergence in Hindi literature. Their presence in the narrative archives a literary genealogy.

REASONING: This worked example combines character analysis with literary history. It requires the student to (a) distinguish two similar characters by their writing practice, (b) trace a narrative pattern across their appearances, (c) evaluate a thematic claim using that pattern, and (d) connect to extra-textual literary context—all skills required for board-level competency questions.

ANSWER: The text presents writing as a relay between individual survival and collective resistance. Tsbw's private diary sustains the self; KfeZyk nh's published poetry sustains the movement; the protagonist's published stories bridge both—rooted in domestic labor (Tsbw's domain) but addressed to public readership (KfeZyk nh's domain). The supporting characters function as a literary genealogy: each woman's writing makes the next woman's writing possible.

## COMPETENCY_QUESTION_1
QUESTION: In "vkyks&vk¡èkkfj," the protagonist's employer Rakhi says: "तू बहुत अच्छा लिखती है, पर तेरा लिखना हमारे किस काम का?" (You write well, but of what use is your writing to us?) Analyze this statement to explain how a supporting character's dialogue can simultaneously acknowledge and contain the protagonist's agency. Your answer must reference the speaker's class position, the protagonist's labor, and the narrative's central tension.

COMPETENCY: Textual analysis with socio-structural contextualization

STEPS:
- Step 1: Identify the speaker (Rakhi), her structural position (employer-class woman, mistress of the household), and the recipient (protagonist, domestic worker, newly literate).
- Step 2: Parse the sentence's two clauses — "तू बहुत अच्छा लिखती है" (acknowledgment of skill) vs. "पर तेरा लिखना हमारे किस काम का?" (instrumental dismissal). The "पर" (but) is the pivot.
- Step 3: Connect "हमारे" (us/our) to class interest — Rakhi evaluates the protagonist's writing by its utility to the employing household, not its value to the writer.
- Step 4: Link to central tension — The protagonist's literacy threatens the labor relation: a writing servant may demand rights, leave, or expose exploitation. Rakhi's question attempts to re-contain the disruption within the existing hierarchy.
- Step 5: Conclude — The dialogue performs "contained acknowledgment": it grants the protagonist humanity ("अच्छा लिखती है") only to reclaim her labor ("हमारे किस काम का"). This is how supporting characters voice the structure's self-defense.

ANSWER: Rakhi's statement epitomizes how the employing class manages disruption: it acknowledges the protagonist's achieved skill (literacy) while immediately subordinating it to the employer's interest ("हमारे किस काम का"). The pronoun "हमारे" reveals that Rakhi views the protagonist's writing not as the protagonist's liberation but as a potential resource for the household—or a threat to be neutralized. This dialogue crystallizes the narrative's central tension: literacy as the protagonist's claim to selfhood versus literacy as the employer's anxiety about losing control over labor. The supporting character speaks the structure's logic.

DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: The text ends with the protagonist reflecting: "रक्रीक के बच्चे अब मुझे 'दीदी' कहते हैं, पर रक्रीक अब भी 'तू' कहती है." (Rakhi's children now call me 'Didi', but Rakhi still calls me 'Tu'.) Using this final observation, evaluate how the narrative uses supporting characters to measure the protagonist's social mobility—and its limits. Your answer must address: (a) the children's shift as generational change, (b) Rakhi's persistence as structural continuity, and (c) the protagonist's own assessment of this gap.

COMPETENCY: Thematic synthesis through character dynamics

STEPS:
- Step 1: Decode the honorific shift — "तू" (intimate/inferior) to "दीदी" (respectful elder sister) marks the children's recognition of the protagonist's achieved status (literacy, authority, care). This is generational: the young learn new hierarchies.
- Step 2: Analyze Rakhi's refusal — She maintains "तू" despite knowing the protagonist's publications, awards, public recognition. This is structural: the employer-servant relation is the material base of her household; changing address would destabilize the labor contract.
- Step 3: Read the protagonist's tone — The observation is stated without bitterness ("पर" not "मगर"), suggesting she understands the difference between interpersonal respect (children) and structural position (employer). She measures mobility in real terms, not symbolic gestures.
- Step 4: Synthesize the narrative's measurement — Social mobility is partial: cultural capital (literacy, respect from young) shifts; economic relation (wages, address, dependency) holds. The supporting characters embody this split—children = cultural shift; employer = economic stasis.
- Step 5: Conclude — The narrative refuses both triumphalism (mobility achieved) and defeatism (nothing changed). The supporting characters are the measuring instruments: each registers a different dimension of the protagonist's position.

ANSWER: The final observation structures the narrative's verdict on mobility as a split: the children's "दीदी" registers cultural recognition earned through literacy and care—a generational shift in how labor is valued. Rakhi's persistent "तू" registers the unchanged economic relation—wages for labor, address as ownership. The protagonist reads both without illusion: she has gained a voice and the children's respect, but she remains a worker in Rakhi's house. The supporting characters function as the narrative's diagnostic tools: the children measure how far she has come culturally; the employer measures how far she has not come structurally. The gap between them is the text's final image of justice—partial, real, and ongoing.

DIFFICULTY: hard