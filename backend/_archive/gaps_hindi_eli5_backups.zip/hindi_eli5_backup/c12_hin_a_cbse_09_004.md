## DEFINITION
Character analysis of the protagonist in poetry involves examining the poetic persona (the speaker) — their emotions, motivations, conflicts, and growth — through close reading of their words, imagery, tone, and structural choices in the poem. In Kukuan's dohas, the protagonist is the poet-lover who speaks in first person, revealing his inner world through direct address to his beloved Lakshmi.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student can identify at least three distinct character traits of the protagonist (e.g., intense longing, spiritual devotion, vulnerability) and support each with specific textual evidence (lines, images, vocabulary) from both dohas, explaining how the evidence reveals the trait.

## SCOPE_BOUNDARY
This node covers ONLY the protagonist (the poetic speaker) in the two prescribed dohas of Kukuan (Chapter 9, Antra). It does NOT cover supporting characters (Lakshmi, the sakhi), thematic analysis, or literary devices in isolation — those are separate nodes (c12_hin_a_cbse_09_005, 006, 008, 009).

## WALKTHROUGH
Imagine you receive a voice note from a friend who sounds completely different from their usual texts — their voice cracks, they pause, they repeat a name. You instantly know *how* they feel without them saying "I am sad." That is exactly what Kukuan does in these dohas: he doesn't announce his feelings; he *performs* them through rhythm, repetition, and raw vocabulary. Start by reading both dohas aloud — hear the beat (लय), notice which words repeat (लकतू, पिउ, दुख), and mark every first-person verb (चाहूं, देखूं, सुनूं). The protagonist isn't a character *in* the poem; he *is* the poem. Your job is to reconstruct his personality from the traces he leaves in language.

## DIAGNOSTIC_QUESTION_1
Who is the protagonist in Kukuan's dohas, and what is his primary relationship that drives the poem?

## DIAGNOSTIC_ANSWER_1
The protagonist is the poetic speaker (Kukuan himself as the lover-poet), and his primary relationship is his intense, separation-driven love for his beloved Lakshmi (लकतू). A wrong answer (e.g., "Lakshmi is the protagonist" or "the sakhi") reveals the student confuses the addressee with the speaker — a fundamental error in identifying the poetic persona. The speaker uses first-person verbs (चाहूं, देखूं) and addresses Lakshmi as "you," making him the subject.

## DIAGNOSTIC_QUESTION_2
Explain in your own words why the protagonist says "पकड़ परो यो लँसलकस यो लकतू कस" (Hold me, this chain is for Lakshmi) — what does this reveal about his mental state?

## DIAGNOSTIC_ANSWER_2
The line reveals the protagonist's desperate surrender: he offers himself as a captive (लँसलकस = chain/bond) to Lakshmi, showing he views love as voluntary imprisonment. A wrong answer (e.g., "he wants to give her a gift") misses the metaphor of bondage and the speaker's agency in choosing enslavement — a key trait of his devotional love. The student who misreads this fails to see the protagonist's active, willing submission.

## DIAGNOSTIC_QUESTION_3
Apply the "show, don't tell" principle: Find two instances where the protagonist *shows* his suffering through physical/concrete imagery rather than naming the emotion directly. Quote the Hindi phrases.

## DIAGNOSTIC_ANSWER_3
1. "डग डग वको नछयस एउहकोउ कस" (Step by step, the body wastes away) — shows physical deterioration. 2. "अब न फ?कजर ?कु वकुान फुंक कस" (Now even the breath doesn't stay) — shows life ebbing. A wrong answer quoting "दुख" or "विरह" directly shows the student cannot distinguish between *naming* an emotion and *evoking* it through imagery — a critical skill for board answers.

## DIAGNOSTIC_QUESTION_4
Compare the protagonist's tone in the first doha (stanzas 1-2) with the second doha. How does his relationship to suffering change?

## DIAGNOSTIC_ANSWER_4
In the first doha, suffering is *endured* and *described* (body wasting, breath failing) with a tone of helpless longing. In the second doha, suffering becomes a *challenge* — "Who can endure this pain?" (कस फदर नलक र;का उ नहफब मसफयगस) — shifting to defiant pride in his capacity to love. A wrong answer saying "both are sad" misses the evolution from passive victim to active martyr — the protagonist's character arc across the two poems.

## DIAGNOSTIC_QUESTION_5
Evaluate: Is the protagonist's love selfish or selfless? Defend your judgment using one line from each doha.

## DIAGNOSTIC_ANSWER_5
Selfless — he seeks no reciprocation, only union. Doha 1: "पकड़ परो यो लँसलकस यो लकतू कस" (he offers himself, not asking her to change). Doha 2: "तकु ?कुवकुआन ;का एकसग रकएगस इस्ट इझ" (he claims the pain as *his* exclusive right, not hers). A wrong answer calling it selfish because "he wants her" ignores that he demands nothing from her — not even her presence, only the *right* to suffer for her. This confusion between desire and demand is a classic board-exam trap.

## DIAGNOSTIC_QUESTION_6
Create a third stanza (4 lines) in Kukuan's style where the protagonist responds to Lakshmi finally appearing before him — maintaining his established voice, vocabulary, and metaphor of bondage.

## DIAGNOSTIC_ANSWER_6
Example: "आयो पिउ द्वार, टूटी न लँसलकस / नयनन मिले, मिटी न विरह-कसकस / कहत कुकुआन, अब भई पूर्ण आस / दास भयो सदा, राखियो पास"  
A poor answer would use modern Hindi, rhyme scheme, or make the protagonist demand love — revealing the student hasn't internalized the protagonist's register (Braj-inflected Khari Boli), his metaphorical consistency (chain remains unbroken), or his devotional stance (he remains दास).

## COMMON_MISCONCEPTION
Students treat the protagonist as a fictional character *separate* from the poet Kukuan, writing "the poet creates a character who feels..." — but in Bhakti/Riti poetry, the poet *is* the speaker; the "I" is autobiographical. They also confuse the *sakhi* (female friend) in the second doha ("सखा न स्फ[ककस") as a separate character speaking, when she is merely referenced by the protagonist. This leads to answers analyzing the "sakhi's perspective" — a zero-mark error in board exams.

## ON_FAILURE
1. Re-read both dohas aloud, circling every first-person pronoun/verb (मैं, मेरा, चाहूं, देखूं, सुनूं, भयो). 2. List only what the *speaker* says/does — ignore Lakshmi's actions or the sakhi's mention. 3. Revisit Class 11 node **c11_hin_ar_cbse_09_004** (Character Analysis: Protagonist) for the "speaker vs. character" distinction in Kabir/Dadu. 4. Write a 50-word summary: "The speaker is Kukuan himself, a lover who..." — if you write "the poet shows a lover who...", restart step 1.

## BUILDS_ON
Class 11 skill of distinguishing poetic speaker from poet (c11_hin_ar_cbse_09_004) — now applied to a poet who *uses his own name* in the poem (कुकुआन), blurring the line intentionally.

## LEADS_TO
c12_hin_a_cbse_09_005 (Supporting Characters) — where Lakshmi and the sakhi are analyzed as *reflections* of the protagonist's psyche, not independent agents.

## PREREQUISITE_NODE_IDS
c12_hin_a_cbse_09_001, c12_hin_a_cbse_09_002, c11_hin_ar_cbse_09_004, c12_hin_a_cbse_09_003

## PREREQUISITE_REASONS
c12_hin_a_cbse_09_001: Provides historical context (Kukuan's life, Lakshmi's identity) essential to read the protagonist as autobiographical.  
c12_hin_a_cbse_09_002: Establishes narrative structure (two dohas = two stages of viraha) needed to trace the protagonist's emotional arc.  
c11_hin_ar_cbse_09_004: Teaches the core skill of identifying the poetic persona in first-person Bhakti poetry — directly transferable.
c12_hin_a_cbse_09_003: The protagonist's inner state is revealed through the atmosphere analyzed here.  

## FORWARD_NODE_IDS
c12_hin_a_cbse_09_005, c12_hin_a_cbse_09_006, c12_hin_a_cbse_09_013, c12_hin_a_cbse_09_007, c12_hin_a_cbse_09_015

## FORWARD_REASONS
c12_hin_a_cbse_09_005: Supporting characters (Lakshmi, sakhi) are defined *by* the protagonist's gaze — his words create them.  
c12_hin_a_cbse_09_006: Primary theme (prem as surrender) emerges from the protagonist's self-characterization.  
c12_hin_a_cbse_09_013: Critical interpretation (e.g., "Is this feudal patriarchy or spiritual democracy?") requires a fixed protagonist profile first.
c12_hin_a_cbse_09_007: Protagonist (poet-disciple) perspective shapes the thematic voice.  
c12_hin_a_cbse_09_015: Protagonist (guru) characterization across two dohas supplies the central figure for all discussion claims.  

## CROSS_SUBJECT_PREREQS
c11_hin_ar_cbse_09_004, c11_hin_ar_cbse_10_004
## CROSS_SUBJECT_REASONS
c11_hin_ar_cbse_09_004: Kabir's protagonist (the weaver-saint) uses similar "I am yours" rhetoric — comparing both reveals the *Riti* convention of the lover-poet persona.  
c11_hin_ar_cbse_10_004: Bihari's nayak in Satsai is a *courtly* lover; Kukuan's protagonist is a *devotional* lover — contrast sharpens analysis of genre expectations.

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_09_004 -> c12_hin_a_cbse_09_004 -> c12_hin_a_cbse_09_005

## THIS_FORMULA
Protagonist Profile = (Autobiographical Anchor) + (First-Person Verb Cluster) + (Recurring Metaphor Set) + (Tonal Shift Across Stanzas)

## FORMULA_VARIABLES
Autobiographical Anchor: Poet's named self-reference (कुकुआन) in text.  
First-Person Verb Cluster: All verbs where speaker acts/feels (चाहूं, देखूं, सुनूं, भयो, कहत).  
Recurring Metaphor Set: Repeated images defining self (लँसलकस/chain, दुख/pain, दास/servant).  
Tonal Shift Across Stanzas: Change from helplessness (doha 1) to defiant ownership (doha 2).

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
analytical

## CROSS_SUBJECT
N/A | The protagonist's self-fashioning as दास (servant) mirrors the historical shift in North Indian Bhakti from temple-centered to personal surrender — Kukuan's "chain" metaphor reflects 17th-century feudal-devotional vocabulary.  
 N/A | The protagonist constructs identity through relational definition ("I am Lakshmi's") — a textbook case of *interdependent self-construal* in cultural psychology, useful for CUET psychology passages.
## PREREQ_CONCEPT
Identifying the poetic "I" in first-person Braj/Khari Boli poetry — knowing that the speaker *is* the text's consciousness.

## PREREQ_BEFORE
Student must locate every first-person marker in both dohas and sort them into: physical actions, mental states, metaphors for self.

## PREREQ_STUCK
If stuck on "who is speaking?", return to the biography in c12_hin_a_cbse_09_001 — Kukuan *names himself* in the last line of the second doha (कुकुआन). That is the anchor.

## WORKED_EXAMPLE_1
PROBLEM: Using only the first doha (both stanzas), list three character traits of the protagonist with one evidence line each.  
STEPS:
- Step 1: Isolate all first-person expressions in Doha 1 — "चाहूं", "देखूं", "सुनूं", "पकड़ परो", "भयो".  
- Step 2: Group by semantic field — "चाहूं/देखूं/सुनूं" = sensory longing; "पकड़ परो" = voluntary bondage; "भयो" = resultant state.  
- Step 3: Name traits from groups — (a) Intense sensory longing, (b) Willing self-surrender, (c) Transformed identity (becomes दास).  
- Step 4: Select sharpest evidence per trait — (a) "नयनन देखूं, कनन सुनूं, रसना चाहूं" (triple sensory focus), (b) "पकड़ परो यो लँसलकस यो लकतू कस" (active offering of chain), (c) "दास भयो सदा" (permanent identity shift).  
- Step 5: Verify each trait appears *only* in speaker's voice — no attribution to Lakshmi or narrator.  
REASONING: This method prevents "theme-hunting" (e.g., listing "love" as a trait) and forces evidence-based character adjectives — exactly what 3-mark board questions require.  
ANSWER: 1. Intensely sensory lover — "नयनन देखूं, कनन सुनूं, रसना चाहूं" 2. Voluntarily enslaved — "पकड़ परो यो लँसलकस यो लकतू कस" 3. Permanently transformed — "दास भयो सदा"

## WORKED_EXAMPLE_2
PROBLEM: The second doha begins with a rhetorical question: "वकुकदकुह वकजलह फुगकफजकस जककसक्स दकसयकसा" (Who can describe the pain of separation?). Explain how this question *characterizes* the protagonist rather than just expressing emotion.  
STEPS:
- Step 1: Note the grammatical form — indefinite pronoun "कस" (who) + modal "सक्स" (can) = challenge to universe.  
- Step 2: Identify the implied answer — "No one" — making the protagonist's pain *unique* and *indescribable*.  
- Step 3: Connect to character — this is not a sufferer seeking sympathy; it's a sufferer *claiming exclusive authority* over his suffering.  
- Step 4: Contrast with Doha 1 — there he *describes* pain (body wasting); here he *guards* it as intellectual property.  
- Step 5: Formulate trait — "Proprietary guardianship of personal suffering" — supported by "एकसग रकएगस इस्ट इझ" (I keep this pain as my right).  
REASONING: Rhetorical questions in poetry are character actions — they reveal agency. Board answers that treat them as mere ornament lose marks for "lack of analytical depth."  
ANSWER: The question establishes the protagonist as a *connoisseur of his own grief* — he doesn't just feel pain; he curates it, claiming no one else can understand or articulate it, turning suffering into a badge of authentic love.

## WORKED_EXAMPLE_3
PROBLEM: Synthesize a 4-point character sketch of the protagonist across *both* dohas for a 6-mark "lanHkZ lfgr O;k[;k" (explain with context) board question.  
STEPS:
- Step 1: Create a two-column table: Doha 1 traits | Doha 2 traits.  
- Step 2: Fill using worked examples 1 & 2 — Doha 1: sensory longing, voluntary bondage, identity as दास. Doha 2: proprietary grief, defiant endurance, exclusive claim ("मेरा"), spiritual pride.  
- Step 3: Find the *through-line* — all traits serve one core: **love as chosen servitude that elevates the lover**.  
- Step 4: Draft four points with integrated evidence:  
  (i) *Sensory absolutist* — "नयनन देखूं, कनन सुनूं, रसना चाहूं" (D1) → love consumes all faculties.  
  (ii) *Autonomous surrender* — "पकड़ परो यो लँसलकस" (D1) → chains are self-offered, not imposed.  
  (iii) *Grief as privilege* — "एकसग रकएगस इस्ट इझ" (D2) → suffering = proof of love's depth.  
  (iv) *Eternal servant* — "दास भयो सदा" (D1) + "कुकुआन" signature (D2) → identity fixed in relation to beloved.  
- Step 5: Add context sentence: "Kukuan, a 17th-century Riti poet, uses the nayak voice autobiographically, merging poet and persona."  
- Step 6: Check marking scheme fit — 4 points × 1 mark each + context 1 mark + integration 1 mark = 6 marks.  
REASONING: Board "lanHkZ lfgr O;k[;k" demands *integration* (लनहकज) — not isolated points. The through-line (love as chosen servitude) is the integration key.  
ANSWER: [See Step 4 points + context sentence] — structured as: "कुकुआन का नायक..." with each point beginning with a trait label in bold, evidence in quotes, and one-sentence explanation.

## COMPETENCY_QUESTION_1
QUESTION: A student writes: "The protagonist in Kukuan's dohas is a typical nayak who follows the Riti convention of describing viraha." Why is this answer insufficient for a Class 12 board exam? What must be added to make it competent?  
COMPETENCY: Critical evaluation of literary generalization vs. textual specificity  
STEPS:
- Step 1: Identify the flaw — "typical nayak" erases Kukuan's *autobiographical* use of his own name (कुकुआन) and the *devotional* (not courtly) frame.  
- Step 2: Recall Riti convention — nayak is usually a generic courtly lover; Kukuan breaks this by naming himself and addressing a real woman (Lakshmi).  
- Step 3: Specify what to add — (a) "Unlike conventional nayaks, this protagonist is the poet himself..." (b) "His viraha is not performative but existential — he claims it as 'मेरा'..." (c) "The chain metaphor (लँसलकस) replaces the standard 'arrow of love' with feudal bondage imagery..."  
- Step 4: Write the competent version incorporating these.  
ANSWER: The original answer is a *category error* — it applies a genre label without textual proof. Competent answer: "While the viraha theme follows Riti tradition, Kukuan's protagonist subverts the generic nayak by (1) autobiographical self-naming (कुकुआन), (2) addressing a historical beloved (Lakshmi), (3) replacing Kama's arrows with the feudal metaphor of chain (लँसलकस), and (4) transforming suffering into a claimed right ('एकसग रकएगस इस्ट इझ') — making him a *specific* devotee-lover, not a *type*."  
DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: In the second doha, the protagonist says: "तकु ?कुवकुआन ;का एकसग रकएगस इस्ट इझ" (Only Kukuan keeps this pain as his right). Design a 3-question interview you would ask *this protagonist* to test whether his claim is genuine or performative. Each question must target a different psychological layer (behavioral, cognitive, motivational) and reference a specific Hindi phrase from the text.  
COMPETENCY: Psychological characterization through textual interrogation (CUET/Board HOTS)  
STEPS:
- Step 1: Behavioral layer — target observable action: "You say 'दास भयो सदा' (D1) but also 'एकसग रकएगस' (D2) — does a servant *own* his pain, or does the master? Show me a moment you *chose* the chain over freedom." (References: दास भयो, एकसग रकएगस)  
- Step 2: Cognitive layer — target belief: "When you ask 'कस फदर नलक र;का उ नहफब मसफयगस' (who can endure this?), do you *want* someone to endure it, or do you *need* to be the only one? What happens if Lakshmi returns and the pain vanishes?" (References: कस फदर, नहफब मसफयगस)  
- Step 3: Motivational layer — target desire: "Is 'पकड़ परो यो लँसलकस' an invitation to Lakshmi, or a ritual you perform for yourself? If she never comes, does the chain still have meaning?" (References: पकड़ परो, लँसलकस)  
- Step 4: Ensure each question cannot be answered by "yes/no" — forces the protagonist (and student) into interpretive depth.  
ANSWER: [Three questions as above] — evaluated on: (a) textual anchoring, (b) layer distinction, (c) openness. A competent response uses the protagonist's own vocabulary to destabilize his self-presentation.  
DIFFICULTY: hard