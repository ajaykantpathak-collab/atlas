## DEFINITION
Plot and narrative structure refer to the sequence of events in a story and the technique used to present them, including exposition, rising action, climax, falling action, and resolution, as well as devices like flashback, dialogue, and point of view.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student can identify the five stages of the plot in "js.kq", explain how the narrative structure (including flashbacks and dialogue) shapes the reader's understanding of the characters and theme, and write a structured analysis using textual evidence.

## SCOPE_BOUNDARY
This node covers the plot outline and narrative structure of the story "js.kq" from the Class 12 Hindi Antra textbook. It does not cover character analysis, themes, or literary devices in depth (those are separate nodes).

## WALKTHROUGH
Imagine you are telling a friend about a movie you watched: you wouldn't just list events randomly; you'd start with the setting, introduce characters, build tension, reach a turning point, and then show how things settle. That's plot structure. In "js.kq", the author uses a similar arc but with a twist: the narrator returns to his village after years, and the story unfolds through his conversations with his old nanny, revealing the past through flashbacks. To analyze this, first read the story and mark the key events in order. Then identify where the author breaks chronological order (flashbacks) and why. Notice how dialogue drives the plot forward. The key insight is that the narrative structure mirrors the theme of memory and change.

## DIAGNOSTIC_QUESTION_1
What are the five traditional stages of a plot, and which stage in "js.kq" corresponds to the narrator's arrival at the village?

## DIAGNOSTIC_ANSWER_1
The five stages are exposition, rising action, climax, falling action, and resolution. In "js.kq", the narrator's arrival at the village is part of the exposition, where the setting and characters are introduced. A wrong answer (e.g., saying it's the climax) reveals the student cannot distinguish the beginning of the story from its turning point.

## DIAGNOSTIC_QUESTION_2
Explain how the author uses flashback in "js.kq" to reveal the relationship between the narrator and the nanny. Why is this technique effective?

## DIAGNOSTIC_ANSWER_2
The author uses flashback when the nanny recounts past events (like the narrator's childhood, the incident with the snake, etc.) through her dialogue. This technique is effective because it builds emotional depth and shows the passage of time without the narrator directly narrating the past. A wrong answer that only lists flashback events without explaining the effect shows the student understands the device but not its narrative purpose.

## DIAGNOSTIC_QUESTION_3
Identify the climax of the story "js.kq" and justify your choice with two pieces of textual evidence.

## DIAGNOSTIC_ANSWER_3
The climax occurs when the narrator (gjxksfcu) decides to take the nanny (cM+h cgqfj;k) with him to the city, and she refuses, leading to an emotional confrontation. Evidence: (1) The nanny says she will not leave the village, and (2) the narrator's desperate plea ("cM+h cgqfj;k] rqe esjh ek¡] lkjs xk¡o dh ek¡ gks!"). A wrong answer that picks an earlier event (like the narrator's arrival) shows the student confuses rising action with climax.

## DIAGNOSTIC_QUESTION_4
Compare the narrative structure of "js.kq" with a linear story (without flashbacks). How does the non-linear structure affect the reader's empathy for the nanny?

## DIAGNOSTIC_ANSWER_4
In a linear story, we would see the nanny's past first, then the present. In "js.kq", the present is shown first, and the past is revealed through her dialogue, making her current loneliness more poignant because we see the contrast. The non-linear structure builds empathy by delaying the full revelation of her sacrifices. A wrong answer that says "it makes the story confusing" reveals the student hasn't grasped the emotional function of the structure.

## DIAGNOSTIC_QUESTION_5
Evaluate whether the resolution of "js.kq" provides closure for the narrator's internal conflict. Support your evaluation with reasoning.

## DIAGNOSTIC_ANSWER_5
The resolution provides partial closure: the narrator accepts the nanny's decision and leaves, but his internal conflict (guilt, love, duty) is not fully resolved, as seen in his final emotional outburst. This open-ended resolution reflects the theme of irreversible change. A wrong answer that claims complete closure ignores the lingering emotional tension the author deliberately leaves.

## DIAGNOSTIC_QUESTION_6
Write a brief alternate ending for "js.kq" where the nanny agrees to go to the city. How would this change the story's theme and narrative structure?

## DIAGNOSTIC_ANSWER_6
An alternate ending: The nanny agrees, and they leave together. This would change the theme from "acceptance of change and the pain of separation" to "reunion and hope", and the narrative structure would shift from a tragic realism to a more conventional happy ending, losing the poignant irony of the nanny's rootedness. A poor answer that only changes the event without analyzing thematic impact shows the student cannot connect structure to theme.

## COMMON_MISCONCEPTION
Students often think "plot" is just a summary of events. They write a chronological summary and call it plot analysis. The error is confusing plot (the causal sequence of events structured by the author) with story (the raw chronological events). In "js.kq", the story includes the narrator's childhood, but the plot starts with his return and reveals the childhood through flashback. Students miss the author's deliberate structuring.

## ON_FAILURE
If a student cannot distinguish plot from story, have them: (1) List all events in the story in chronological order (story). (2) List events in the order they appear in the text (plot). (3) Compare the two lists and note differences (flashbacks, starting in media res). (4) Write one sentence explaining why the author chose this plot order. Use the Class 11 node c11_hin_ar_cbse_01_002 (Plot and Narrative Structure) for a simpler story to practice.

## BUILDS_ON
Class 11 concept of plot stages (exposition, rising action, climax, falling action, resolution) and narrative devices like flashback.

## LEADS_TO
Character analysis (node c12_hin_a_cbse_12_004) because understanding plot structure helps analyze how characters drive and are driven by the plot.

## PREREQUISITE_NODE_IDS
c11_hin_ar_cbse_01_002, c12_hin_a_cbse_12_001
## PREREQUISITE_REASONS
c11_hin_ar_cbse_01_002: Provides foundational understanding of plot stages and narrative devices from Class 11.
c12_hin_a_cbse_12_001: Gives context and background of the author and story, necessary to understand the setting and cultural nuances.

## FORWARD_NODE_IDS
c12_hin_a_cbse_12_003, c12_hin_a_cbse_12_004, c12_hin_a_cbse_12_005, c12_hin_a_cbse_12_006, c12_hin_a_cbse_12_012, c12_hin_a_cbse_12_013, c12_hin_a_cbse_12_008, c12_hin_a_cbse_12_010, c12_hin_a_cbse_12_014, c12_hin_a_cbse_12_015

## FORWARD_REASONS
c12_hin_a_cbse_12_003: Setting and atmosphere are intertwined with plot events.
c12_hin_a_cbse_12_004: Protagonist's actions and development are plotted across the narrative arc.
c12_hin_a_cbse_12_005: Supporting characters' roles are defined by their function in the plot.
c12_hin_a_cbse_12_006: Primary theme emerges through the plot's progression and climax.
c12_hin_a_cbse_12_012: Comprehension questions often ask about plot sequence and structure.
c12_hin_a_cbse_12_013: Critical thinking requires analyzing how narrative structure shapes meaning.
c12_hin_a_cbse_12_008: अगला तार्किक चरण: Imagery is the use of vivid, sensory language that appeals to the five senses (sight, sound, smell,... इस नोड की अवधारणाओं को सीधे उपयोग/विस्तारित करता है।  
c12_hin_a_cbse_12_010: Plot structure locates where each key word appears (e.g., 'dkcqyh&dk;nk' in the confrontation scene).  
c12_hin_a_cbse_12_014: कथानक संरचना (plot structure) जाने बिना घटनाओं को क्रमबद्ध कर साक्ष्य नहीं चुने जा सकते।  
c12_hin_a_cbse_12_015: Supplies plot structure knowledge to reference specific narrative turning points during discussion  

## CROSS_SUBJECT_PREREQS
c11_hin_ar_cbse_01_002, c11_hin_ar_cbse_02_002
## CROSS_SUBJECT_REASONS
c11_hin_ar_cbse_01_002: Plot structure concepts from Class 11 Hindi (Antra) are directly applied here.
c11_hin_ar_cbse_02_002: Another Class 11 chapter on plot structure reinforces the concept across texts.

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_01_002 -> c12_hin_a_cbse_12_002 -> c12_hin_a_cbse_12_004

## THIS_FORMULA
N/A - conceptual

## FORMULA_VARIABLES
N/A

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
analytical

## CROSS_SUBJECT
N/A | The story reflects social changes in post-independence rural India, similar to history topics on rural transformation.
 N/A | The narrative structure mirrors the sociological theme of tradition vs. modernity in village life.
## PREREQ_CONCEPT
Understanding of the five-stage plot structure (Freytag's pyramid) and the difference between story (chronological events) and plot (author's arrangement).

## PREREQ_BEFORE
Student must be able to identify exposition, rising action, climax, falling action, resolution in a simple story.

## PREREQ_STUCK
Review the plot diagram (Freytag's pyramid) and practice labeling stages in a short story from Class 11 (e.g., "The Lament" or any Class 11 story).

## WORKED_EXAMPLE_1
PROBLEM: Analyze the exposition of "js.kq" by identifying the setting, main characters introduced, and the initial situation.
STEPS:
- Step 1: Read the opening paragraphs (up to the narrator's arrival at the village) and note the time, place, and atmosphere.
- Step 2: Identify the narrator (gjxksfcu) and his purpose for returning.
- Step 3: List the characters introduced: the narrator, the nanny (cM+h cgqfj;k), the old servant (laofn;k), and the village setting.
- Step 4: Determine the initial situation: the narrator has returned after many years, the village has changed, and the nanny is old and frail.
- Step 5: Explain how this exposition sets up the central conflict (the narrator's desire to take the nanny vs. her attachment to the village).
REASONING: The exposition establishes the physical and emotional landscape. By starting with the narrator's return, the author immediately creates a contrast between past and present, which is the story's core tension.
ANSWER: The exposition introduces the narrator returning to his changed village, meeting his aged nanny and the old servant. The initial situation is the narrator's wish to take the nanny to the city, which she resists, setting up the central conflict.

## WORKED_EXAMPLE_2
PROBLEM: Trace the rising action in "js.kq" by listing three key events that escalate the conflict between the narrator and the nanny.
STEPS:
- Step 1: Identify the conflict: narrator wants to take nanny to city; nanny refuses.
- Step 2: Find the first escalation: the narrator tries to persuade her with comforts of city life (dialogue about city amenities).
- Step 3: Find the second escalation: the nanny reveals her deep roots through stories of the past (flashbacks about the narrator's childhood, the snake incident, etc.).
- Step 4: Find the third escalation: the emotional confrontation where the narrator pleads and the nanny firmly refuses, citing her duty to the village and her late husband's memory.
- Step 5: Explain how each event raises the emotional stakes and deepens the characterization.
REASONING: Rising action builds tension through dialogue and revelation of the past. Each event makes the nanny's refusal more understandable and the narrator's desire more desperate.
ANSWER: The rising action includes: (1) Narrator's persuasion using city comforts, (2) Nanny's flashbacks revealing her emotional ties, (3) The direct confrontation where nanny refuses, stating her life is in the village.

## WORKED_EXAMPLE_3
PROBLEM: Explain how the narrative structure (use of flashback and dialogue) in "js.kq" serves the theme of "memory and change". Write a structured paragraph using the PEEL method (Point, Evidence, Explanation, Link).
STEPS:
- Step 1: State the Point: The non-linear narrative structure reinforces the theme of memory and change.
- Step 2: Provide Evidence: The story begins in the present (narrator's return) and the past is revealed through the nanny's dialogue (e.g., the snake incident, the narrator's childhood games).
- Step 3: Explain: The flashbacks are not just background; they are voiced by the nanny, showing how the past lives in her present. The dialogue format makes the past immediate and personal.
- Step 4: Link: This structure mirrors the theme: the village (and the nanny) is a repository of memory that resists change, while the narrator represents change. The narrative structure enacts this tension.
- Step 5: Conclude: Thus, the author's choice of structure is integral to the theme.
REASONING: This example combines plot analysis with thematic interpretation, requiring the student to connect structural choices to meaning, a key Class 12 skill.
ANSWER: The non-linear narrative structure of "js.kq" reinforces the theme of memory and change. The story opens in the present with the narrator's return, but the past emerges through the nanny's dialogue, such as her recounting the snake incident and the narrator's childhood. These flashbacks are not detached narration; they are the nanny's living memories, showing how the past persists in her present. This structural choice mirrors the thematic tension: the nanny embodies rooted memory, while the narrator represents disruptive change. The narrative structure thus enacts the theme, making the form itself meaningful.

## COMPETENCY_QUESTION_1
QUESTION: In "js.kq", the author uses a first-person narrator who is also a character in the story. How does this narrative perspective affect the plot structure? Choose one specific plot event and explain how it would differ if told from a third-person omniscient perspective.
COMPETENCY: Analyzing narrative perspective and its impact on plot structure
STEPS:
- Step 1: Identify the narrative perspective (first-person, participant narrator).
- Step 2: Select a plot event (e.g., the climax where the nanny refuses to leave).
- Step 3: Describe how the event is presented through the narrator's limited knowledge and emotions.
- Step 4: Contrast with third-person omniscient: would show both characters' inner thoughts directly, possibly reducing the mystery of the nanny's motives.
- Step 5: Conclude the effect on plot structure: first-person creates dramatic irony and emotional tension because the reader discovers the past along with the narrator.
ANSWER: The first-person perspective means the climax (nanny's refusal) is filtered through the narrator's shock and desperation. We feel his surprise because he expected her to agree. In third-person omniscient, we would know the nanny's resolve beforehand, reducing the tension. The first-person structure delays the revelation of the nanny's depth, making the climax more impactful.
DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: The story "js.kq" ends with the narrator leaving alone. Some critics argue this is an "open ending". Evaluate this claim by analyzing the falling action and resolution. Does the ending resolve the primary conflict? What thematic purpose does the lack of complete closure serve?
COMPETENCY: Evaluating narrative resolution and its thematic function
STEPS:
- Step 1: Define open ending vs. closed ending.
- Step 2: Summarize the falling action: narrator's failed persuasion, nanny's final words, narrator's emotional breakdown.
- Step 3: Analyze the resolution: narrator leaves; nanny stays. The external conflict (will she go?) is resolved (no), but the internal conflict (narrator's guilt, acceptance) is not fully resolved.
- Step 4: Evaluate: The ending is open regarding the narrator's emotional state and future relationship. It serves the theme of irreversible change and the pain of letting go.
- Step 5: Argue that the lack of closure is deliberate and thematically consistent.
ANSWER: The ending is open in terms of the narrator's internal resolution. The external conflict (nanny's refusal) is resolved, but the narrator's guilt and love remain unresolved as he leaves. This lack of closure mirrors the theme: some separations are permanent, and memory cannot be fully reconciled with change. The author denies easy closure to emphasize the pain of transition.
DIFFICULTY: hard