## DEFINITION
In poetry, narrative structure refers to the organization of a poem's events, images, and arguments across stanzas to create a coherent progression of thought or story. For "lk;s esa /wi," it is the three-stanza movement from an external, chaotic street scene (Stanza 1) to a personal, defiant internal monologue (Stanza 2) and finally to a universal philosophical assertion (Stanza 3), bound by the recurring motif of the "stake" (लकड़ी) as a symbol of resistance.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student can independently trace the poem's three-stanza narrative arc, explain how the shift from third-person observation to first-person declaration structures the political argument, and justify why the poet chooses this specific non-linear, montage-like structure over a linear story to depict Emergency-era oppression.

## SCOPE_BOUNDARY
This node covers the structural architecture of Nagarjun's poem: stanza division, narrative voice shifts, temporal progression (immediate scene → personal memory → timeless truth), and the function of the refrain-like repetition of "लकड़ी" (stake/wood). It does NOT cover detailed imagery analysis (node 13_008), irony/symbolism (13_009), or character sketches (13_004/005), though it references them as structural building blocks.

## WALKTHROUGH
Imagine you are editing a documentary about the 1975 Emergency: you have footage of a violent street arrest (Stanza 1), a voice-over of the filmmaker's terrified but defiant inner monologue (Stanza 2), and a closing title card with a universal truth about power (Stanza 3). To analyze this poem's structure, first read it aloud *three times*—once per stanza—marking the pronouns (वह/वे vs. मैं/मेरा). Next, draw a vertical timeline: label Stanza 1 as "Public Chaos," Stanza 2 as "Private Terror," Stanza 3 as "Eternal Law." Notice how the poet *refuses* a linear cause-effect plot; instead, he stacks three simultaneous realities to show that state violence, individual fear, and moral law coexist in a single moment. The key insight: the "plot" is not *what happens* but *how the poet forces us to hold three contradictory perspectives at once*.

## DIAGNOSTIC_QUESTION_1
Identify the three distinct narrative "layers" or perspectives presented in the three stanzas of "lk;s esa /wi" and name the dominant pronoun/voice in each.

## DIAGNOSTIC_ANSWER_1
Correct: Stanza 1 = External/Observational layer (third-person: "वह", "वे", "यहाँ"); Stanza 2 = Internal/Subjective layer (first-person: "मैं", "मेरा"); Stanza 3 = Universal/Philosophical layer (gnomic present tense, no personal pronoun). A wrong answer (e.g., saying all stanzas are the poet's direct speech) reveals the student cannot distinguish between the poet's *persona* as observer, victim, and prophet—a critical skill for board exam "explain with reference to context" questions.

## DIAGNOSTIC_QUESTION_2
The poem opens with "दग़दग़ा रहीं..." (burning/smoldering) and closes with "राजा हूँ मैं..." (I am the king). Explain in your own words why Nagarjun structures the poem to move from sensory chaos to a declarative metaphor of kingship, rather than telling a chronological story of an arrest.

## DIAGNOSTIC_ANSWER_2
Correct: The structure mimics the *experience* of totalitarianism—where past, present, and future collapse into a single moment of terror. By denying chronology, the poet forces the reader to feel the simultaneity of state violence ("वे लोग"), existential dread ("मैं चुपचाप"), and moral certainty ("राजा हूँ मैं"). A wrong answer focusing only on "variety" or "beauty" shows the student misses the political *function* of form: structure *is* resistance here.

## DIAGNOSTIC_QUESTION_3
Apply the concept of "montage structure" (juxtaposing discrete images without explicit connectors) to Stanza 1. List three concrete images placed side-by-side and explain what narrative gap the reader must fill between them.

## DIAGNOSTIC_ANSWER_3
Correct: Images: (1) "दग़दग़ा रहीं लकड़ियाँ" (smoldering stakes), (2) "नंगे पाँव भागते बच्चे" (barefoot fleeing children), (3) "पुलिस की जीप" (police jeep). Gap: The poem never says the stakes *cause* the flight or the jeep *chases* the children; the reader must infer the causal chain of state violence. A student who writes "the police burned the stakes" imposes a linear plot the poem deliberately withholds—revealing a habit of forcing narrative coherence where the poet creates fragmentation.

## DIAGNOSTIC_QUESTION_4
Analyze the structural role of the word "लकड़ी" (stake/wood) which appears in Stanza 1 ("दग़दग़ा रहीं लकड़ियाँ") and echoes in Stanza 3 ("लकड़ी की तरह"). How does this lexical anchor transform the poem from a scene into an argument?

## DIAGNOSTIC_ANSWER_4
Correct: "लकड़ी" acts as a structural refrain: in Stanza 1 it is passive fuel (victim), in Stanza 3 it becomes the standard of unyielding truth ("लकड़ी की तरह सीधा खड़ा हूँ"). The argument *is* the transformation of the object from tool-of-oppression to symbol-of-integrity. A wrong answer treating the two occurrences as unrelated imagery misses the poem's dialectical structure—thesis (wood burns) → antithesis (wood stands) → synthesis (I am king *because* I stand like wood).

## DIAGNOSTIC_QUESTION_5
Evaluate the claim: "The second stanza ('मैं चुपचाप...') is a structural weakness because it breaks the objective realism of the first stanza." Defend or refute using evidence from the poem's political context.

## DIAGNOSTIC_ANSWER_5
Correct: Refute. The shift *is* the political point: under Emergency, the private self *cannot* remain separate from public terror. The "weakness" (subjective intrusion) mirrors the state's violation of the citizen's interiority. A student agreeing with the claim reveals a middle-school expectation of "consistent point of view" and fails to see that *formal rupture = thematic enactment*—a senior-secondary analytical move.

## DIAGNOSTIC_QUESTION_6
Create a one-stanza "fourth stanza" that would *break* the poem's current tripartite structure. Explain in two sentences what thematic damage your addition would cause.

## DIAGNOSTIC_ANSWER_6
Good answer example: A stanza describing the poet's release from jail or the end of Emergency. Damage: It would impose historical closure on a poem structured to show that *moral resistance is timeless*, not tied to a specific regime's fall. A poor answer (e.g., adding a hopeful sunrise) reveals the student reads for "message" not "structure"—they don't grasp that the poem's power lies in its *refusal* of resolution.

## COMMON_MISCONCEPTION
Students treat the poem as a short story with a hidden plot: "Police burn stakes → children run → poet hides → poet realizes he is a king." They hunt for *causal links* between stanzas (e.g., "Did the police see the poet?"). This error stems from Class 10 prose training where "plot = sequence of events." In modernist political poetry, *structure = argument*; the stanzas are simultaneous facets of a totalitarian moment, not consecutive scenes. The "plot" is the reader's mental assembly of the three perspectives.

## ON_FAILURE
1. Give the student three index cards labeled "Camera Eye" (Stanza 1), "Diary Entry" (Stanza 2), "Manifesto" (Stanza 3). 2. Ask them to read only Stanza 1 and write one sentence in *present continuous* tense describing what the camera sees. 3. Repeat for Stanza 2 in *first-person past* ("I felt..."), Stanza 3 in *gnomic present* ("Truth is..."). 4. Physically lay the cards side-by-side (not in a line) and ask: "Do these happen one after another, or all at once?" 5. Guide them to the word "लकड़ी" on each card to show the single thread holding the simultaneous panels together.

## BUILDS_ON
c11_hin_ar_cbse_13_001 (Context: Emergency background, Nagarjun's biography, and the poem's genre as "राजनीतिक कविता" / political poetry).

## LEADS_TO
c11_hin_ar_cbse_13_003 (Setting and Atmosphere: the physical/spatial details that populate the structural frames analyzed here).

## PREREQUISITE_NODE_IDS
c11_hin_ar_cbse_13_001
## PREREQUISITE_REASONS
c11_hin_ar_cbse_13_001: Provides the historical context (Emergency, 1975-77) and authorial intent (Nagarjun as "जनकवि") without which the structural choices (fragmentation, voice shifts) appear arbitrary rather than strategic resistance.

## FORWARD_NODE_IDS
c11_hin_ar_cbse_13_003, c11_hin_ar_cbse_13_008, c11_hin_ar_cbse_13_013, c11_hin_ar_cbse_13_004, c11_hin_ar_cbse_13_005, c11_hin_ar_cbse_13_006, c11_hin_ar_cbse_13_007, c11_hin_ar_cbse_13_010, c11_hin_ar_cbse_13_011, c11_hin_ar_cbse_13_012, c11_hin_ar_cbse_13_015, c12_hin_a_cbse_09_002, c12_hin_a_cbse_13_002, c12_hin_ar_cbse_13_002, c12_hin_ar_cbse_13_007, c11_hin_ar_cbse_13_009

## FORWARD_REASONS
c11_hin_ar_cbse_13_003: Setting/Atmosphere analysis requires the structural frames (public street vs. private psyche) established here to locate imagery. c11_hin_ar_cbse_13_008: Imagery/Metaphor devices operate *within* the structural slots (e.g., "लकड़ी" as metaphor functions differently in Stanza 1 vs 3). c11_hin_ar_cbse_13_013: Critical Thinking/Interpretation needs the structural map to argue *how* form creates meaning.
c11_hin_ar_cbse_13_004: Establishes the poem's narrative structure (three stanzas = three stages) which frames the protagonist's development.  
c11_hin_ar_cbse_13_005: Provides the narrative sequence (procession → cremation → aftermath) that structures the three supporting groups' appearances.  
c11_hin_ar_cbse_13_006: Establishes the three-stanza narrative arc (observation → solidarity → prophecy) that structures the thematic argument.  
c11_hin_ar_cbse_13_007: Establishes the poem's narrative structure (courtroom drama → moral tribunal) which frames how secondary themes unfold across stanzas.  
c11_hin_ar_cbse_13_010: Establishes the narrative movement from temple to city, which structures the semantic journey of words like 'e;Llj' → 'cgj'.  
c11_hin_ar_cbse_13_011: Establishes narrative voice and stanza structure; language usage analysis requires knowing *who* speaks and *where* in the poem.  
c11_hin_ar_cbse_13_012: Understanding narrative structure (three stanzas = three movements) helps locate literal details in the correct stanza.  
c11_hin_ar_cbse_13_015: कथानक/संरचना समझ (तीन पदों की प्रगति) चर्चा के क्रम को तय करती है।  
c12_hin_a_cbse_09_002: Developed critical interpretation of structural choices.  
c12_hin_a_cbse_13_002: Class 11 Antra Chapter 13 Plot and Narrative Structure — provides foundational concepts of fabula/syuzhet, linear vs. non-linear narrative, and embedded narratives which this Class 12 node extends with greater complexity.  
c12_hin_ar_cbse_13_002: Class 11 node on plot and narrative structure provides the foundational terminology (exposition, rising action, etc.) and practice with simpler texts.  
c12_hin_ar_cbse_13_007: Plot structure knowledge needed to locate thematic evidence at turning points  
c11_hin_ar_cbse_13_008: अगला तार्किक चरण: Imagery is the use of vivid, sensory language that appeals to the five senses (sight, sound, touch,... इस नोड की अवधारणाओं को सीधे उपयोग/विस्तारित करता है।  
c11_hin_ar_cbse_13_013: अगला तार्किक चरण: Critical thinking in literary analysis is the disciplined process of examining a text's components—s... इस नोड की अवधारणाओं को सीधे उपयोग/विस्तारित करता है।  
c11_hin_ar_cbse_13_009: If stuck, re-read the "Text: Plot and Narrative Structure" (c11_hin_ar_cbse_13_002) and "Theme: Primary Theme" (c11_hin_ar_cbse_13_006) nodes to lock down the what and why before tackling the how (devices).  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
none

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_13_001 -> c11_hin_ar_cbse_13_002 -> c11_hin_ar_cbse_13_003

## THIS_FORMULA
N/A - conceptual (Structural Analysis Framework for Political Lyric: Identify Stanza Units → Map Narrative Voice per Unit → Trace Lexical Anchors Across Units → Diagnose Temporal Logic → Evaluate Form-Function Fit)

## FORMULA_VARIABLES
N/A

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
analytical

## CROSS_SUBJECT
c11_history_ncert_theme3 | The poem's fragmented structure mirrors the historical rupture of the Emergency (1975-77) where normal legal/time sequences were suspended—just as the poem suspends linear narrative.
c11_civics_ncert_ch4 | The three-stanza structure enacts the civics concept of "State vs. Citizen": Stanza 1 = State apparatus (police, jeep), Stanza 2 = Vulnerable Citizen, Stanza 3 = Citizen claiming Sovereign Rights (Article 21 / "राजा हूँ मैं").

## PREREQ_CONCEPT
Historical context of the Emergency (1975-77): censorship, arbitrary arrests, suspension of fundamental rights, and Nagarjun's role as a poet of resistance.

## PREREQ_BEFORE
Student must be able to define "Emergency" in one sentence and explain why a poet would choose *fragmented form* to write about it.

## PREREQ_STUCK
Revisit c11_hin_ar_cbse_13_001, specifically the paragraph on "आपातकाल की पृष्ठभूमि" and the note on Nagarjun's "जनवादी प्रतिबद्धता."

## WORKED_EXAMPLE_1
PROBLEM: Using the Structural Analysis Framework, demonstrate how the poem's narrative structure enacts the argument "Tyranny burns the body but cannot burn the soul."

STEPS:
- Step 1: Segment the poem into its three structural units (stanzas) and label the narrative mode of each: Stanza 1 = Cinematic Montage (External/Objective), Stanza 2 = Interior Monologue (Subjective/Fragmented), Stanza 3 = Philosophical Aphorism (Universal/Timeless).
- Step 2: Map the "Body" imagery to Stanza 1: "दग़दग़ा रहीं लकड़ियाँ" (burning wood = burning bodies), "नंगे पाँव भागते बच्चे" (vulnerable flesh), "पुलिस की जीप" (mechanized state force). The structure *shows* the body under assault without commentary.
- Step 3: Map the "Soul/Consciousness" to Stanza 2: The shift to "मैं चुपचाप..." marks the retreat into interiority. The fragmented syntax ("नहीं, नहीं / ठीक नहीं") mimics a mind under pressure but *refusing* to articulate surrender.
- Step 4: Map the "Unburnable Truth" to Stanza 3: The gnomic declaration "राजा हूँ मैं / लकड़ी की तरह सीधा खड़ा हूँ" transposes the passive wood of Stanza 1 into an active moral standard. The structure *performs* the transmutation: wood (object) → I (subject) → King (sovereign).
- Step 5: Synthesize: The non-linear, simultaneous structure proves the argument. If the poem were linear (arrest → jail → realization), the soul's independence would be a *result* of the body's suffering. By placing the "King" declaration *alongside* the burning (not after), the structure insists the soul's sovereignty is *co-present* with the torture—it is not earned, it is inherent.

REASONING: This framework moves beyond "what happens" to "how the arrangement of parts creates the meaning." Board examiners reward answers that treat structure as *evidence* for interpretation, not just a container for content.

ANSWER: The poem's tripartite structure (Montage → Monologue → Manifesto) spatially enacts the coexistence of state violence, individual terror, and moral sovereignty. The lexical anchor "लकड़ी" transforms from passive fuel (Stanza 1) to active standard (Stanza 3), proving structurally that the soul's integrity is not a consequence of the body's burning but its simultaneous, unshakeable counterpart.

## WORKED_EXAMPLE_2
PROBLEM: A student writes: "The poem has no plot because nothing changes from beginning to end." Using structural analysis, correct this misconception and explain what *kind* of plot a political lyric possesses.

STEPS:
- Step 1: Validate the observation: Yes, no *external* event changes (the stakes still burn, the jeep still there, the poet still standing). This is not a novelistic plot (exposition → climax → resolution).
- Step 2: Define "Lyrical Plot" for Class 11: In modernist political poetry, plot = *the movement of consciousness* or *the unfolding of an argument through juxtaposition*. The "events" are cognitive/emotional shifts.
- Step 3: Trace the internal plot points: Plot Point 1 (Stanza 1): Perception of overwhelming force (State as fire/machine). Plot Point 2 (Stanza 2): Moment of existential crisis ("डर लगता है") immediately countered by refusal ("नहीं, नहीं"). Plot Point 3 (Stanza 3): Epiphanic reclamation of agency ("राजा हूँ मैं").
- Step 4: Identify the structural engine: The *repetition with variation* of the central image (लकड़ी). Stanza 1: लकड़ी = victim. Stanza 3: लकड़ी = standard. The "plot" is the *semantic rotation* of this image.
- Step 5: Conclude: The plot is the reader's journey from witnessing victimhood to recognizing sovereignty. The structure *is* the plot.

REASONING: Senior-secondary exams often ask "कथानक की दृष्टि से..." (from plot perspective). Students must redefine "plot" for poetry: it is the architecture of meaning-making, not sequence of actions.

ANSWER: The poem possesses a *dialectical plot*: Thesis (State violence burns the individual) → Antithesis (Individual asserts inner freedom) → Synthesis (Individual *is* the unburnable law). The structure drives this plot through voice-shift (3rd → 1st → Universal) and image-rotation (लकड़ी as ash → लकड़ी as axis). "Nothing changes" externally; everything changes ontologically.

## WORKED_EXAMPLE_3
PROBLEM: Compare the narrative structure of "lk;s esa /wi" with a conventional short story (e.g., Premchand's "Kafan"). Explain why Nagarjun's structure is *more* effective for depicting totalitarianism than a linear story would be.

STEPS:
- Step 1: Outline "Kafan" structure: Linear chronological plot (Father/son sit → wife dies → they beg → buy shroud → drink/eat → moral decay). Cause-effect chain; time moves forward; closure (however bleak).
- Step 2: Outline "lk;s esa /wi" structure: Simultaneous panels (Stanza 1: Street NOW; Stanza 2: Mind NOW; Stanza 3: Truth ALWAYS). No cause-effect between stanzas; time is vertical (depth) not horizontal (sequence); no closure.
- Step 3: Link to Totalitarianism's nature (from History/Civics cross-subject): Totalitarianism *destroys linear time* (arbitrary arrest, no trial, suspended rights). The victim experiences past-trauma, present-terror, and future-dread *simultaneously*.
- Step 4: Argue effectiveness: A linear story (Arrest → Torture → Death/Release) implies a *process* with rules. Nagarjun's structure denies process—it presents the *state of exception* as a static, eternal now. The reader cannot "wait for the outcome"; they are trapped in the triptych.
- Step 5: Connect to board exam keyword: "अकथनीय को कहने की संरचना" (Structure that speaks the unspeakable). The fragmentation *is* the testimony.
- Step 6: Final synthesis: For a historical event that defies narrative logic (Emergency), only a fractured form can be truthful. Linear form would *normalize* the abnormality.

REASONING: This comparative structural analysis hits the "Critical Thinking" competency (node 13_013) and "Cross-subject link" requirement. It demonstrates the Class 11 shift from "identifying structure" to "evaluating structural fitness for theme."

ANSWER: "Kafan" uses linear plot to show *social decay over time*; "lk;s esa /wi" uses simultaneous triptych to show *political suspension of time*. Nagarjun's structure is more effective because totalitarianism does not play by narrative rules (cause/effect, justice/outcome)—it creates a perpetual present of terror. The poem's refusal of chronology forces the reader to inhabit that perpetual present, making the structure an ethical act, not just an aesthetic choice.

## COMPETENCY_QUESTION_1
QUESTION: "The three stanzas of 'lk;s esa /wi' are not sequential; they are simultaneous." Using specific structural evidence (voice, tense, imagery), defend this statement and explain why simultaneity is the *only* honest structure for a poem about the Emergency.

COMPETENCY: Literary Analysis & Argumentation (Evaluating form-theme adequacy)

STEPS:
- Step 1: Cite voice evidence: Stanza 1 uses third-person present continuous ("दग़दग़ा रहीं", "भागते") = ongoing external now. Stanza 2 uses first-person present ("लगता है", "सोचता हूँ") = ongoing internal now. Stanza 3 uses gnomic present ("हूँ", "खड़ा हूँ") = eternal now. Zero past/future tense markers linking them sequentially.
- Step 2: Cite imagery evidence: The "लकड़ी" in Stanza 1 burns *while* the "लकड़ी" in Stanza 3 stands. They are the same object in two states at once—simultaneity made visible.
- Step 3: Connect to Emergency context: Under Article 352, *habeas corpus* suspended → no legal "before/after" (arrest → trial). The citizen exists in a perpetual "during." Sequential narrative implies due process; simultaneous structure enacts lawlessness.
- Step 4: Conclude: Honesty to the *phenomenology* of totalitarianism demands a form that refuses beginning/middle/end. The triptych *is* the testimony.

ANSWER: The poem presents three co-existing realities—State Violence (Stanza 1), Subjective Terror (Stanza 2), Moral Law (Stanza 3)—through locked-present tenses and the rotating image of "लकड़ी." A sequential structure would falsely impose causality and resolution on a historical moment defined by the *suspension* of both. Simultaneity is the structural equivalent of "न्याय नहीं, सिर्फ अन्याय" (no justice, only injustice).

DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: Design a board-exam style "Reference to Context" answer for the lines "राजा हूँ मैं / लकड़ी की तरह सीधा खड़ा हूँ" that *must* include: (a) identification of the structural position (which stanza, what function), (b) the transformation of the central image from Stanza 1, and (c) the political claim being made through this structural climax. Write the answer in the PEEL format (Point, Evidence, Explanation, Link).

COMPETENCY: Exam Answer Writing & Structural Synthesis (Applying structural analysis to a specific extract)

STEPS:
- Step 1 (Point): These lines form the structural climax (Stanza 3, Philosophical Manifesto) where the poem's dialectical argument resolves: the victim of Stanza 1 becomes the sovereign of Stanza 3.
- Step 2 (Evidence): Quote "लकड़ी की तरह" linking to Stanza 1's "दग़दग़ा रहीं लकड़ियाँ." Note the shift from plural passive ("लकड़ियाँ... दग़दग़ा रहीं") to singular active ("सीधा खड़ा हूँ").
- Step 3 (Explanation): The structure rotates the central symbol 180 degrees: wood-as-fuel (consumed by state fire) → wood-as-axis (unbending moral law). The "I" claims kingship *not despite* the burning but *through* the same material integrity.
- Step 4 (Link): This structural climax enacts the poem's core political thesis: under totalitarianism, the only sovereignty left to the citizen is the refusal to be bent—making the body that burns the very standard that judges the tyrant.
- Step 5: Polish for board exam: Use terminology "संरचनात्मक चरम" (structural climax), "प्रतीक-परिवर्तन" (symbol transformation), "राजनैतिक संप्रभुता" (political sovereignty).

ANSWER: (Point) ये पंक्तियाँ कविता के त्रि-स्तरीय ढाँचे (Montage → Monologue → Manifesto) का संरचनात्मक चरम हैं जहाँ कवि निजी भय को सार्वभौम नैतिक अधिकार में रूपांतरित करता है। (Evidence) प्रथम स्त्रोत की निष्क्रिय बहुवचन "दग़दग़ा रहीं लकड़ियाँ" यहाँ एकवचन सक्रिय "लकड़ी की तरह सीधा खड़ा हूँ" में बदल जाती है। (Explanation) यह प्रतीक-परिवर्तन संरचना द्वारा संपन्न होता है: वही लकड़ी जो राज्य की आग में ईंधन थी, अब नागरिक की रीढ़ बन जाती है। (Link) इस प्रकार संरचना सिद्ध करती है कि अत्याचार की भट्टी में जलना और सत्य की धुरी बनना एक ही सिक्के के दो पहलू हैं—यही आपातकालीन भारत का नागरिक-सत्य है।

DIFFICULTY: hard