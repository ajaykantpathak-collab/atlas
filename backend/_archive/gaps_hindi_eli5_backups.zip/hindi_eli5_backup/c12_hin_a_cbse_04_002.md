## DEFINITION
Narrative structure in poetry refers to the organized sequence of events, images, and perspectives through which a poem tells a story — including its opening situation, complications, turning points, and resolution — arranged in a deliberate order to shape the reader's emotional and intellectual response.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student can independently map the narrative arc of both poems in this chapter (चुकजल and फ्नेक), identify structural devices (time shifts, perspective changes, repetition patterns), and explain how the poet's structural choices reinforce the central theme — using textual evidence in a structured PEEL paragraph.

## SCOPE_BOUNDARY
This node covers narrative structure analysis of the two poems in Chapter 4 (चुकजल and फ्नेक) only: narrative arc stages, sequencing techniques, perspective/voice, and structural devices like repetition and time manipulation. It does NOT cover setting description, character analysis, thematic interpretation, or literary devices — those are separate sibling nodes.

## WALKTHROUGH
Imagine you're watching a short film with no dialogue — only visuals and background music. How do you know what's happening? The director arranges shots in a specific order: first the peaceful village well, then a bucket descending, then water splashing, then a child's face lighting up. That *arrangement* is narrative structure. In चुकजल, Osankukfark Lag does exactly this with words: he sequences images (well → rope → bucket → water → reflection) to build a story without a single named character. Start by reading the poem aloud twice — first for sound, second to mark where the "camera angle" shifts. Ask: what changes between stanza 1 and stanza 4? The key insight: narrative structure in poetry is not *what* happens but *how the poet orders what happens* to control revelation.

## DIAGNOSTIC_QUESTION_1
Define "narrative arc" in the context of a narrative poem. List its five standard stages in order.

## DIAGNOSTIC_ANSWER_1
A narrative arc is the structural framework of a story comprising five stages: (1) Exposition — introduces setting, time, and initial situation; (2) Rising Action — introduces conflict or complication; (3) Climax — moment of highest tension or turning point; (4) Falling Action — consequences of the climax unfold; (5) Resolution — new equilibrium or closure. A wrong answer (e.g., listing "beginning, middle, end" or confusing with thematic progression) reveals the student treats poems as static images rather than temporal sequences — a Class 11 carry-over where lyrical poems dominated.

## DIAGNOSTIC_QUESTION_2
In चुकजल, the poem moves from "ओलार" (buzzing activity) at the well to "एक ठहरी हुई साँस" (a paused breath) in the final stanza. Explain in your own words how this shift represents a structural movement from rising action to resolution. Why does the poet *delay* the moment of stillness until the end?

## DIAGNOSTIC_ANSWER_2
The opening stanzas pile sensory details (bucket descending, water splashing, ropes creaking) creating kinetic energy — this is rising action. The final stanza's stillness ("वह ठहरी हुई साँस") resolves that energy by freezing the motion into a reflective moment. The delay forces the reader to experience the village's rhythm *before* granting the epiphany. A wrong answer focusing only on "calm vs noise" misses the *temporal* function: structure controls *when* the reader receives insight, not just *what* the insight is.

## DIAGNOSTIC_QUESTION_3
Given this 4-line excerpt from an unseen narrative poem:  
"पहले आया सन्नाटा, फिर पदचाप / फिर दरवाज़ा खुला, फिर कोई न आया / फिर धूप झुकी दीवार पर, फिर छाया / फिर रात ने गिने तारे, फिर सवेरा आया"  
Identify the narrative stage of each line using the five-stage arc. Justify your mapping for line 2 and line 4.

## DIAGNOSTIC_ANSWER_3
Line 1: Exposition (establishes silence/emptiness). Line 2: Rising Action (door opens but absence creates tension — "कोई न आया" is the complication). Line 3: Climax (sunlight shifting marks peak visual transformation). Line 4: Falling Action → Resolution (night counting stars = reflection; dawn = new equilibrium). Justification: Line 2 introduces *unfulfilled expectation* (classic complication). Line 4 shows *time passing without resolution of the visitor*, accepting cyclical nature — resolution without closure. Wrong answers that label line 2 as "climax" confuse surprise with structural peak; line 4 as "climax" confuses imagery intensity with narrative function.

## DIAGNOSTIC_QUESTION_4
Compare the narrative structure of चुकजल and फ्नेक. Both use repetition ("एक ठहरी हुई साँस" / "पिता-पिता — उसने कहा"), but to opposite structural effects. Analyze how repetition functions as a *structural hinge* in each poem.

## DIAGNOSTIC_ANSWER_4
In चुकजल, repetition ("एक ठहरी हुई साँस" echoes earlier "ओलार") creates a *circular structure* — the well's activity returns to stillness, mirroring the village's eternal rhythm. The hinge connects end to beginning. In फ्नेक, "पिता-पिता" repeats at increasing intervals (stanza 1 → stanza 3 → final cry) creating a *spiral structure* — each repetition escalates the child's urgency and the father's absence, driving toward irreversible loss. The hinge *propels* time forward. Wrong answers that say "both show emphasis" miss how repetition's *placement* in the sequence determines whether it closes or opens the narrative.

## DIAGNOSTIC_QUESTION_5
A student claims: "फ्नेक has no real climax — the father never appears, so nothing *happens*." Evaluate this claim using narrative structure theory. Is the poem's climax internal or external? Defend your judgment with two structural evidence points.

## DIAGNOSTIC_ANSWER_5
The claim confuses *external event* with *narrative climax*. The climax is internal: the child's realization ("मैंने पहली बार जाना / फनेग पिता नहीं है") — an epistemological turning point. Evidence 1: The poem's longest stanza (stanza 4) coincides with this realization — structural weight = thematic weight. Evidence 2: The final repetition "पिता-पिता" shifts from address to invocation — syntax change marks the psychological climax. Wrong evaluations that demand a physical confrontation impose novelistic expectations on poetic narrative, where climax = moment of maximum *perceptual change*.

## DIAGNOSTIC_QUESTION_6
Design a 5-stanza narrative poem outline (2 lines per stanza) on "A farmer waiting for rain" that uses *only* structural sequencing (no adjectives, no metaphors) to move from hope to acceptance. Label each stanza's narrative stage.

## DIAGNOSTIC_ANSWER_6
Stanza 1 (Exposition): "Sky turns white at noon / Oxen rest under neem"  
Stanza 2 (Rising Action): "Cloud gathers on horizon / Wind lifts dust in spirals"  
Stanza 3 (Climax): "First drop hits dry earth / Second drop misses the bucket"  
Stanza 4 (Falling Action): "Cloud passes without breaking / Shadow returns to field"  
Stanza 5 (Resolution): "Farmer unties oxen / Walks home with empty pot"  
A poor answer uses emotional language ("sad farmer", "cruel sky") revealing the misconception that structure = theme. Structure *is* the sequence of concrete actions; theme emerges *from* the sequence.

## COMMON_MISCONCEPTION
Students believe narrative poems *must* have named characters, dialogue, and linear chronology to have a "plot." They read चुकजल as a description of a well, not a story *of* the well's daily cycle. They read फ्नेक as a dialogue snippet, not a child's psychological journey structured through *absence*. This error stems from Class 10-11 exposure to plot only in prose fiction (short stories/novels), where plot = character-driven events. In poetry, plot = *image-driven temporal sequencing*. The misconception causes them to write "no plot" in board answers and miss 3-4 marks on structure questions.

## ON_FAILURE
Step 1: Have the student watch a 2-minute silent short film (e.g., "The Red Balloon" clip) and draw a 5-box storyboard labeling narrative stages. Step 2: Map the same 5 boxes onto चुकजל's stanzas — well activity = rising action, reflection = climax, stillness = resolution. Step 3: Repeat for फ्नेक using the child's *changing understanding* as the "character." Step 4: Re-attempt Diagnostic Questions 2 and 4. If confusion persists, revisit c11_hin_ar_cbse_01_002 (Class 11 Plot and Narrative Structure) for the foundational arc model.

## BUILDS_ON
c12_hin_a_cbse_04_001 (Context and Background) — provides the poet's narrative intent and rural milieu essential for decoding structural choices.

## LEADS_TO
c12_hin_a_cbse_04_003 (Setting and Atmosphere) — narrative structure determines *when* and *how* setting details are revealed; c12_hin_a_cbse_04_004 (Character Analysis) — narrative perspective shapes character access.

## PREREQUISITE_NODE_IDS
c12_hin_a_cbse_04_001, c11_hin_ar_cbse_01_002, c11_hin_v_cbse_01_002
## PREREQUISITE_REASONS
c12_hin_a_cbse_04_001: Context node supplies the poet's narrative philosophy (Osankukfark Lag's focus on "thou ke bina izo'qfr") which directly shapes his non-linear, image-based narrative structure.  
c11_hin_ar_cbse_01_002: Class 11 Antra Chapter 1 introduced the five-stage narrative arc applied to narrative poems — this node extends it to dual-poem comparison and structural device analysis.  
c11_hin_v_cbse_01_002: Class 11 Vitan Chapter 1 covered narrative perspective in autobiographical narratives — essential for analyzing फ्नेक's child-narrator reliability.

## FORWARD_NODE_IDS
c12_hin_a_cbse_04_003, c12_hin_a_cbse_04_004, c12_hin_a_cbse_04_012, c12_hin_a_cbse_04_005, c12_hin_a_cbse_04_006, c12_hin_a_cbse_04_008, c12_hin_a_cbse_04_009, c12_hin_a_cbse_04_014

## FORWARD_REASONS
c12_hin_a_cbse_04_003: Setting details in both poems are *released* according to narrative pace (e.g., चुकजल's well described only during bucket's descent) — structure gates setting.  
c12_hin_a_cbse_04_004: The "character" in चुकजल is the well itself, revealed through structural personification across stanzas; फ्नेक's father exists *only* through structural absence.  
c12_hin_a_cbse_04_012: Comprehension questions (literal/inferential) require identifying *where* in the narrative arc information appears — e.g., "When does the reader learn the father is dead?" = structural inference.
c12_hin_a_cbse_04_005: Plot/narrative structure shows the sequence of interactions.  
c12_hin_a_cbse_04_006: Plot/narrative structure reveals the poem's movement from scene to abstraction.  
c12_hin_a_cbse_04_008: Narrative structure — where imagery peaks in the poem's arc.  
c12_hin_a_cbse_04_009: Narrative structure reveals *where* irony peaks (opening vs. closing) — essential for structural analysis.  
c12_hin_a_cbse_04_014: Provides plot/narrative structure of the poems for reference.  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
c12_history_narrative_sources: Historians analyze narrative structure in primary sources (e.g., Mughal chronicles' selective event sequencing) — same skill: identifying what the narrator *orders* and *omits*.  
c12_economics_narrative_economics: Behavioral economics studies how narrative framing (sequence of gain/loss presentation) alters decisions — structural sequencing shapes perception in both poetry and economic choice architecture.

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_01_002 -> c12_hin_a_cbse_04_002 -> c12_hin_a_cbse_04_003

## THIS_FORMULA
Narrative Arc Mapping Formula:  
Stanza N → Narrative Stage = f(Imagery Density, Syntax Complexity, Perspective Shift, Repetition Position, Temporal Marker)  
Where:  
- Imagery Density ↑ = Rising Action  
- Syntax Complexity ↑ + Perspective Shift = Climax  
- Repetition Position (opening vs closing) = Circular vs Spiral Structure  
- Temporal Marker (अब, फिर, तब) = Linear vs Cyclical Time

## FORMULA_VARIABLES
- Stanza N: Ordinal position of stanza in poem (1, 2, 3...)  
- Imagery Density: Count of concrete sensory images per line  
- Syntax Complexity: Clause depth / sentence length variation  
- Perspective Shift: Change in grammatical person (मैं → वह) or focalization  
- Repetition Position: Stanza index of first vs last occurrence of key phrase  
- Temporal Marker: Lexical items marking time sequence (पहले, फिर, अंत में)

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
analytical

## CROSS_SUBJECT
N/A | Both require identifying how narrative sequencing constructs meaning — historian reads chronicle's event selection as argument; student reads poem's image sequence as theme.  
 N/A | Both analyze how temporal framing (order of presentation) alters interpretation — economist studies loss-aversion framing; student studies grief-framing in फ्नेक's delayed revelation.
## PREREQ_CONCEPT
Five-stage narrative arc (Exposition → Rising Action → Climax → Falling Action → Resolution) applied to poetic stanzas.

## PREREQ_BEFORE
Student must be able to label each stanza of a simple narrative poem (e.g., Class 11's "नौकर") with its narrative stage and justify using imagery/shift evidence.

## PREREQ_STUCK
If stuck on mapping stanzas to stages, review "narrative arc in poetry" from c11_hin_ar_cbse_01_002 — specifically the worked example mapping "नौकर" stanzas to arc stages.

## WORKED_EXAMPLE_1
PROBLEM: Map the narrative arc of चुकजल across its 4 stanzas. Identify the structural device that signals each transition.  
STEPS:  
- Step 1: Read stanza 1 aloud. Mark every concrete sensory image (ओलार, रस्सी, बाल्टी, पानी, छपाक). Count: 5 images in 4 lines → high density. Label: Exposition (establishes well's kinetic world).  
- Step 2: Read stanza 2. Note shift: images become meta-sensory ("आवाज़ की परछाई", "प्रतिबिंब"). Syntax lengthens (compound sentences). Label: Rising Action (complication — the well becomes a mirror, introducing perception).  
- Step 3: Read stanza 3. Identify peak complexity: "एक ठहरी हुई साँस" — oxymoron, nominalized verb, caesura after "एक". Perspective shifts from external observation to internal stillness. Label: Climax (perceptual turning point).  
- Step 4: Read stanza 4. Images reduce to 2 ("चाँद", "कुंआ"). Repetition of "ठहरी हुई साँस" from stanza 3. Time marker "अब" signals new equilibrium. Label: Resolution (circular return to stillness).  
- Step 5: Verify circular structure: Stanza 1 opens with motion (ओलार), Stanza 4 closes with its absorption (ठहरी हुई साँस). The well's cycle = village's cycle.  
REASONING: This stepwise mapping forces attention to *structural signals* (image count, syntax, repetition position) rather than thematic guessing. The formula variables operationalize abstract arc stages into countable textual features.  
ANSWER: चुकजल follows a circular narrative arc: Exposition (stanza 1: kinetic well) → Rising Action (stanza 2: reflective well) → Climax (stanza 3: frozen perception) → Resolution (stanza 4: absorbed stillness). Key structural devices: imagery density gradient (5→3→1→2), syntactic expansion→contraction, repetition as structural hinge (stanza 3→4).

## WORKED_EXAMPLE_2
PROBLEM: Analyze how फ्नेक uses *absence* as a structural engine. Trace the father's presence/absence across stanzas.  
STEPS:  
- Step 1: List father-references per stanza: Stanza 1: "पिता-पिता" (direct address, present in child's mind). Stanza 2: "पिता नहीं है" (explicit negation). Stanza 3: "पिता-पिता" (repeated address, now desperate). Stanza 4: "पिता नहीं है" (realization). Stanza 5: Zero references (father linguistically erased).  
- Step 2: Plot presence-index: 1 (address) → -1 (negation) → 1 (address) → -1 (negation) → 0 (erasure). This oscillation *is* the rising action — each swing escalates emotional stakes.  
- Step 3: Identify climax: Stanza 4's "मैंने पहली बार जाना" — first-person epistemic verb marks internal turning point. Structural confirmation: longest stanza (6 lines), most complex syntax (subordinate clauses).  
- Step 4: Analyze repetition "पिता-पिता": First occurrence = hope (vocative). Second occurrence = protest (repeated despite negation). Third occurrence (implied in final silence) = ritual. Repetition *spirals* rather than circles.  
- Step 5: Connect to narrative theory: Absence functions as "negative space" driving narrative — like a mystery where the detective never appears. The structure *enacts* the child's cognitive process: denial → bargaining → acceptance.  
REASONING: Tracking a *non-entity* (absent father) through structural markers (address, negation, repetition, erasure) demonstrates how narrative structure operates without traditional plot events. The oscillation pattern is the plot.  
ANSWER: फ्नेक's narrative engine is the father's structured absence: Stanza 1 (vocative presence) → Stanza 2 (explicit absence) → Stanza 3 (desperate re-invocation) → Stanza 4 (epiphanic acceptance) → Stanza 5 (linguistic erasure). The spiral repetition "पिता-पिता" marks each oscillation cycle, culminating in the climax of realization (stanza 4). Structure mimetically enacts grief's non-linear progression.

## WORKED_EXAMPLE_3
PROBLEM: Compare the temporal structures of चुकजल and फ्नेक. One uses cyclical time, the other linear-irreversible time. Prove this using only structural evidence (temporal markers, repetition patterns, stanza-sequence logic).  
STEPS:  
- Step 1: Extract temporal markers from चुकजल: "जब" (stanza 1), "फिर" (stanza 2), "अब" (stanza 4). Sequence: recurring condition → repetition → new state. "फिर" implies recurrence; "अब" implies cycle completion.  
- Step 2: Extract temporal markers from फ्नेक: "पहली बार" (stanza 4), "फिर कभी नहीं" (implied in stanza 5 silence). Sequence: delayed realization → permanent closure. No "फिर" for the father.  
- Step 3: Analyze repetition-time relationship: चुकजल's repetition ("ठहरी हुई साँस") occurs *across* stanzas 3-4 — bridging climax to resolution, sealing the cycle. फ्नेक's repetition ("पिता-पिता") occurs *within* the rising action (stanzas 1, 3) — each repetition *advances* time toward irreversibility.  
- Step 4: Analyze stanza-sequence logic: चुकजल's final stanza returns to opening imagery (well, water, reflection) — visual rhyme = temporal rhyme. फ्नेक's final stanza introduces *new* imagery (empty cot, morning light) — no return, only forward motion.  
- Step 5: Synthesize: चुकजल = cyclical time (village eternal return). फ्नेक = linear time with terminal endpoint (individual mortality). Structural evidence: temporal marker semantics, repetition directionality, opening/closing imagery symmetry.  
- Step 6: Board exam application: This comparison is a 5-mark "analyze" question. Answer must cite *specific structural features* (not themes) — e.g., "चुकजल में 'फिर' की पुनरावृत्ति चक्रीय समय दर्शाती है, जबकि फ्नेक में 'पहली बार' अपरिवर्तनीय परिवर्तन का सूचक है।"  
REASONING: Competitive exams (CUET, JEE language papers) test ability to abstract temporal structure from linguistic markers. This worked example models the evidence-to-inference chain required.  
ANSWER: चुकजल employs cyclical temporal structure: recurrent markers ("जब", "फिर"), symmetric repetition bridging climax-resolution, opening/closing imagery mirroring. फ्नेक employs linear-irreversible structure: terminal markers ("पहली बार", implied "फिर कभी नहीं"), spiral repetition accelerating toward endpoint, opening/closing imagery asymmetry. Evidence is strictly structural — no thematic interpretation required.

## COMPETENCY_QUESTION_1
QUESTION: A Class 12 student writes this answer for "Analyze the narrative structure of चुकजल":  
"चुकजल एक गाँव के कुएँ का वर्णन है। पहले स्टैंजा में कुएँ पर भीड़ है, दूसरे में पानी की आवाज़, तीसरे में चाँद का प्रतिबिंब, चौथे में शांति। कवि ने गाँव के जीवन को दिखाया है।"  
Identify three specific structural-analysis failures in this answer. Rewrite the answer using the PEEL structure (Point, Evidence, Explanation, Link) to score full marks.  
COMPETENCY: Critical analysis of peer response / structured answer writing  
STEPS:  
- Step 1: Identify Failure 1 — answer describes *content* (what happens) not *structure* (how it's ordered). No narrative stage labels.  
- Step 2: Identify Failure 2 — no structural devices named (repetition, image density, syntax, temporal markers).  
- Step 3: Identify Failure 3 — no connection between structure and effect (e.g., how circular structure enacts eternal return).  
- Step 4: Rewrite using PEEL: Point = "चुकजल चक्रीय कथात्मक संरचना का प्रयोग करता है।" Evidence = "स्टैंजा 1 में 'ओलार' (गतिशीलता) और स्टैंजा 4 में 'ठहरी हुई साँस' (स्थिरता) की पुनरावृत्ति प्रारंभ और अंत को जोड़ती है।" Explanation = "यह संरचनात्मक दर्पण गाँव के शाश्वत चक्र को रूपायित करता है — घटनाएँ नहीं, लय प्रमुख है।" Link = "इस प्रकार, संरचना ही विषयवस्तु बन जाती है।"  
ANSWER: Three failures: (1) Content-summary masquerading as structure analysis, (2) Zero structural terminology, (3) No structure-theme linkage. PEEL rewrite provided above demonstrates board-marking-scheme alignment: 1 mark for Point (naming structure type), 2 marks for Evidence (specific textual markers), 2 marks for Explanation+Link (analytical depth).  
DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: Assertion (A): In narrative poetry, the climax always occurs in the penultimate stanza.  
Reason (R): The final stanza must resolve the tension, so the peak tension must immediately precede it.  
Evaluate A and R for the two poems in this chapter. Is R the correct explanation for A? Provide a counter-example from चुकजल or फ्नेक if applicable.  
COMPETENCY: Assertion-Reason evaluation / structural generalization testing  
STEPS:  
- Step 1: Test A on चुकजल: Climax = stanza 3 (of 4) → penultimate. Holds.  
- Step 2: Test A on फ्नेक: Climax = stanza 4 (of 5) → penultimate. Holds.  
- Step 3: Test R: "Final stanza must resolve" — true for both. "Peak tension must immediately precede" — true for both.  
- Step 4: But is R the *correct explanation*? No. R describes a *convention*, not a necessity. Counter-evidence: In चुकजल, the climax (stanza 3) is marked by *stillness* ("ठहरी हुई साँस"), not peak tension. Tension peaks in stanza 2 (sensory overload). The climax is *epiphanic*, not tensional. R incorrectly equates climax with "peak tension."  
- Step 5: Conclusion: A is true (coincidentally), R is partially true but misdefines climax. R is NOT the correct explanation.  
ANSWER: A = True (both poems place climax in penultimate stanza). R = Partially true (final stanza resolves) but False as explanation because it misidentifies climax as "peak tension" rather than "turning point of perception." In चुकजल, climax = stillness (low tension), not peak tension. Therefore R does not correctly explain A.  
DIFFICULTY: hard