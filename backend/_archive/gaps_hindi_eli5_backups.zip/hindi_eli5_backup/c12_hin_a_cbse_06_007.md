## DEFINITION
Secondary themes are the subordinate but significant ideas that run parallel to the primary theme in a literary work, enriching the central message by exploring complementary human experiences, social contexts, or philosophical dimensions. In Raskhan's poetry, while the primary theme is Krishna-bhakti (devotion to Krishna), secondary themes include maternal love (vatsalya), surrender of ego (aham-visarjan), harmony across religious boundaries (dharmik sadbhav), and the transformative power of divine love (prem-ki shakti).

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student can identify at least three distinct secondary themes in Raskhan's "Hajar-jke dk izse" (हजार-जके का इजसे), trace each theme across specific stanzas using textual evidence, and explain how these themes interconnect to deepen the primary theme of Krishna-bhakti.

## SCOPE_BOUNDARY
This node covers identification and analysis of secondary themes in Raskhan's savaiya and kavitt poems from Chapter 6 (Antra). It does NOT cover primary theme analysis (covered in node 006), literary devices (nodes 008-009), or vocabulary/grammar (nodes 010-011).

## WALKTHROUGH
Imagine you are listening to a bhajan where the singer repeats "Radhe-Radhe" but between the lines you hear echoes of a mother's lullaby, a lover's longing, and a seeker's surrender — all woven into one melody. That is how secondary themes work in Raskhan's poetry. Begin by re-reading the poem "Hajar-jke dk izse" (stanzas 1 and 2) not for the story but for the emotional undercurrents: notice where Yashoda's anxiety appears (stanza 1, lines about "tuuh fuj[kfr cku"), where Krishna's playful defiance surfaces (stanza 1, "dcgq¡ dgfr ;ksa"), and where the poet's own voice merges with the characters (stanza 2, "jk?kkS! ,d ckj fiQfj vkokS"). Mark these shifts with different colored pencils — one color for maternal love, another for divine playfulness, another for poet's surrender. The key insight: secondary themes are not decorations; they are the bridges that let a 16th-century Muslim poet's voice carry a Hindu devotee's heart to a 21st-century student.

## DIAGNOSTIC_QUESTION_1
Define "secondary theme" in your own words and give one example from any Class 11 or 12 Hindi text you have studied.

## DIAGNOSTIC_ANSWER_1
A secondary theme is a significant but subordinate idea that supports and enriches the primary theme by exploring a related aspect of human experience. For example, in Premchand's "Bade Bhai Sahab" (Class 11), the primary theme is sibling relationship and education, while a secondary theme is the conflict between traditional and modern values. A wrong answer that merely lists "love" or "sadness" without connecting it to a primary theme reveals the student confuses theme with topic or emotion.

## DIAGNOSTIC_QUESTION_2
In Raskhan's "Hajar-jke dk izse" (stanza 1), the lines "dcgq¡ izFke T;ksa tkb txkofr dfg fiz; cpu lokjs" and "dcgq¡ dgfr ;ksa ¶cM+h ckj Hkb tkgq Hkwi ig¡] HkS;k" reveal which secondary theme? Explain how these lines develop that theme.

## DIAGNOSTIC_ANSWER_2
These lines reveal the secondary theme of **bal-leela (divine childhood playfulness)** intertwined with **maternal anxiety (vatsalya-chinta)**. The first line shows Yashoda's frantic search ("cpu lokjs" — running here and there) when Krishna is missing, capturing a mother's panic. The second line shows Krishna's nonchalant response to being caught stealing butter ("cM+h ckj Hkb tkgq Hkwi ig¡"), revealing his divine playfulness that transcends ordinary mischief. A wrong answer that only says "Krishna's childhood" misses the dual perspective: the theme emerges from the tension between mother's worry and child's divine indifference.

## DIAGNOSTIC_QUESTION_3
Apply the concept of secondary themes to analyze the shift in speaker between stanza 1 (third-person narrative) and stanza 2 (first-person direct address: "jk?kkS! ,d ckj fiQfj vkokS"). What new secondary theme emerges from this shift?

## DIAGNOSTIC_ANSWER_3
The shift introduces the secondary theme of **poet's personal surrender (atma-nivedan / sharanagati)**. In stanza 1, Raskhan narrates Yashoda-Krishna leela as an observer. In stanza 2, he directly addresses Yashoda ("jk?kkS!") and identifies himself with the devotee seeking Krishna ("esjs jke ykfMys!"), merging his voice with the gopis' longing. This transforms the poem from a retelling into a personal prayer. A wrong answer that calls this "change of perspective" without naming the thematic shift (from observation to participation) fails to recognize how form serves theme.

## DIAGNOSTIC_QUESTION_4
Compare the secondary theme of **religious harmony (dharmik sadbhav)** in Raskhan's poetry with its treatment in Kabir's dohas (Class 11, Chapter 1). How does Raskhan's approach differ in method though not in spirit?

## DIAGNOSTIC_ANSWER_4
Kabir attacks religious hypocrisy directly through negation ("Hindu-Musalman sab ek") and irony, using a confrontational method. Raskhan embodies harmony through **affirmative participation** — he adopts Krishna-bhakti vocabulary (Braj Bhasha, Vaishnava imagery), lives the devotee's life, and writes as an insider. His method is *anubhav* (lived experience) rather than *vichar* (intellectual argument). A wrong answer that says "both talk about unity" misses the crucial difference in *literary method*: Kabir deconstructs; Raskhan reconstructs from within.

## DIAGNOSTIC_QUESTION_5
Evaluate this student claim: "The secondary theme of 'maternal love' in Raskhan's poem is just a decorative retelling of the Bhagavata Purana story; it adds nothing new to the primary theme of bhakti." Defend or refute with textual evidence.

## DIAGNOSTIC_ANSWER_5
Refute. Raskhan's treatment of maternal love is **not decorative but transformative**. In the Bhagavata, Yashoda's love is part of Krishna's lila; in Raskhan, it becomes a *model for the devotee's love*. Stanza 1, line "caèkq cksfy tsab; tks HkkoS xbZ fuNkofj eS;k" — Yashoda tying Krishna with a grinding stone (damodar-lila) — is reimagined not as divine play but as **love that binds the Infinite**. The poet writes in stanza 2: "rnfi fnu¯g fnu gksr >k¡ojs eugq¡ dey fgeekjs" (day by day, love grows, melting the heart). This progression — from physical binding to heart-melting — shows maternal love *evolving into* bhakti. A wrong answer that agrees with the claim fails to see how Raskhan uses a Puranic episode to map the *stages of devotion*.

## DIAGNOSTIC_QUESTION_6
Create a 4-line savaiya (or free verse) in Hindi that expresses *your* secondary theme of "student's surrender to learning" using Raskhan's technique of adopting a mythological persona (e.g., Arjuna to Krishna, Nachiketa to Yama). Do not copy Raskhan's words.

## DIAGNOSTIC_ANSWER_6
A strong answer will: (1) choose a clear persona (e.g., "Arjun" or "Eklavya"), (2) address the guru/knowledge-figure directly, (3) show vulnerability/ignorance, (4) express surrender as the path to wisdom. Example: "गुरुवर! अर्जुन-सा भ्रमित खड़ा, गांडीव ढीला, लक्ष्य अदृश्य / ज्ञान-रथ हाँको, कृष्ण बनकर, मेरा सारथी बनो निष्पक्ष / अहंकार का कवच उतार, शरणागत हुआ द्वार तुम्हारे / 'कर्मण्येवाधिकारस्ते' — यह सूत्र लिख दो हृदय हमारे।" A poor answer uses abstract statements ("I want to learn") without persona, address, or emotional arc — missing Raskhan's technique of *dramatized surrender*.

## COMMON_MISCONCEPTION
Students often think "secondary theme" means "minor theme" or "less important theme" and therefore give it cursory treatment. The error: they list themes (e.g., "maternal love, surrender, religious harmony") without showing **how each theme is developed through specific poetic choices** — imagery, speaker shift, sound patterns, vocabulary. For instance, they write "Raskhan shows maternal love" but don't analyze *how* the word "tsab;" (melting) in stanza 2 transforms physical binding into spiritual melting. This costs marks in board exams (where "explain with reference to context" requires textual anchoring) and in CUET (where comparative theme questions demand methodological rigor).

## ON_FAILURE
If the student cannot distinguish primary from secondary themes or cannot anchor themes in textual evidence: (1) Revisit node **c12_hin_a_cbse_06_006** (Primary Theme) and create a two-column table: Column A = Primary Theme statements (directly about Krishna-bhakti), Column B = Everything else that supports it. (2) Re-read stanza 1 of "Hajar-jke dk izse" and highlight every word showing *emotion* (Hkko, fopkj, ân;) — these are your secondary theme markers. (3) Practice the "Theme-Tracing Template": Theme Name | Stanza/Line | Key Word/Phrase | How it develops the theme | Link to primary theme. Do this for 3 themes. (4) Re-attempt Diagnostic Question 3 and 5.

## BUILDS_ON
Primary theme identification (node 006) — you must know the central message before mapping what supports it.

## LEADS_TO
Literary devices analysis (nodes 008-009) — devices like imagery, irony, symbolism are the *tools* that build secondary themes.

## PREREQUISITE_NODE_IDS
c12_hin_a_cbse_06_006, c11_hin_ar_cbse_01_007, c11_hin_v_cbse_01_007, c12_hin_a_cbse_06_001, c12_hin_a_cbse_06_003

## PREREQUISITE_REASONS
c12_hin_a_cbse_06_006: Primary theme must be established first to distinguish secondary themes from it.
c11_hin_ar_cbse_01_007: Class 11 Antra Chapter 1 (Kabir) covers secondary themes in bhakti poetry — foundational practice.
c11_hin_v_cbse_01_007: Class 11 Vitan Chapter 1 covers theme analysis in prose — transfers analytical skill.
c12_hin_a_cbse_06_001: Secondary themes (virah, vatsalya) are introduced in the background.  
c12_hin_a_cbse_06_003: Secondary themes (syncretism, renunciation) emerge from setting contrasts  

## FORWARD_NODE_IDS
c12_hin_a_cbse_06_008, c12_hin_a_cbse_06_009, c12_hin_a_cbse_06_013, c12_hin_a_cbse_06_012

## FORWARD_REASONS
c12_hin_a_cbse_06_008: Imagery and metaphor are the primary vehicles for expressing secondary themes (e.g., "tsab;" = melting heart).
c12_hin_a_cbse_06_009: Irony and symbolism deepen secondary themes (e.g., Krishna bound by love = irony of Infinite bound by finite).
c12_hin_a_cbse_06_013: Critical thinking requires synthesizing primary + secondary themes into interpretive arguments.
c12_hin_a_cbse_06_012: Secondary themes enrich multi-layered inferences.  

## CROSS_SUBJECT_PREREQS
c11_hin_ar_cbse_01_007, c11_hin_v_cbse_01_007
## CROSS_SUBJECT_REASONS
c11_hin_ar_cbse_01_007: Kabir's secondary themes (social critique, religious harmony) provide comparative framework for Raskhan's affirmative harmony.
c11_hin_v_cbse_01_007: Prose theme analysis (Vitan) trains the "trace theme across text" skill needed for poetry.

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_01_007 -> c12_hin_a_cbse_06_006 -> c12_hin_a_cbse_06_007 -> c12_hin_a_cbse_06_008

## THIS_FORMULA
Secondary Theme Identification Formula: **STC-Link** = (S)elect key emotional shifts in text → (T)race each shift across stanzas via recurring words/images → (C)ategorize as distinct theme → (Link) to primary theme by showing how it deepens/expands the central message.

## FORMULA_VARIABLES
S = Speaker/voice shifts (e.g., narrator → devotee); T = Textual anchors (repeated words: Hkko, fopkj, tsab;, vanslks); C = Category labels (Vatsalya, Sharanagati, Sadbhav); Link = Explanatory sentence connecting to Krishna-bhakti.

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
analytical

## CROSS_SUBJECT
N/A | Raskhan's poetry reflects 16th-17th century Bhakti movement's syncretic culture — Muslim poets adopting Vaishnava themes mirrors historical Hindu-Muslim cultural synthesis in Mughal era.
 N/A | Secondary theme of "religious harmony through lived practice" (Raskhan's method) illustrates sociological concept of "syncretism" vs "assimilation" — relevant for NCERT Sociology Chapter 3 (Social Institutions: Continuity and Change).
## PREREQ_CONCEPT
Ability to distinguish "topic" (what the text is about) from "theme" (what the text says about the topic) — learned in Class 11 theme nodes.

## PREREQ_BEFORE
Student must have completed Primary Theme analysis (node 006) and know the story of Yashoda-Krishna (Damodar-lila) from cultural knowledge or Class 11 Bhakti poetry.

## PREREQ_STUCK
If stuck on "how to find secondary themes," review Class 11 Antra Chapter 1 (Kabir) node c11_hin_ar_cbse_01_007 — practice identifying themes other than "God is one" in Kabir's dohas.

## WORKED_EXAMPLE_1
PROBLEM: Identify and analyze the secondary theme of "divine playfulness vs. maternal authority" in stanza 1 of "Hajar-jke dk izse" using the STC-Link method.

STEPS:
- Step 1: Select emotional shifts — scan stanza 1 for contrasting emotions. Find: Yashoda's panic ("cpu lokjs" — running frantically), her anger ("Hkwi ig¡" — scolding), Krishna's calm defiance ("cM+h ckj Hkb tkgq" — eating butter repeatedly), his innocent gaze ("leqf> ouxeu jke dks jfg pfd fp=kfy[kh lh" — looking at Yashoda with butter-smeared face).
- Step 2: Trace across lines — "dcgq¡ izFke T;ksa..." (first panic), "dcgq¡ dgfr ;ksa..." (then scolding), "dcgq¡ leqf> ouxeu..." (then tender moment). The repetition of "dcgq¡" (sometimes/at times) structures the shift.
- Step 3: Categorize — This oscillation between mother's authority (search, scold, bind) and child's divine freedom (play, steal, charm) = secondary theme: **Leela-tattva (divine play as theology)**.
- Step 4: Link to primary theme — Raskhan shows that Krishna's playfulness *is* the form bhakti takes for Yashoda. Her authority becomes service (seva); her binding (damodar) becomes liberation. The secondary theme reveals: bhakti is not solemn duty but joyous participation in God's play.
- Step 5: Verify — Check stanza 2: "lqugq ifFkd! tks jke fey¯g cu dfg;ks ekrq lanslks" (listen, O wise one! The one Krishna loves, the mother melts for him). Confirmed: maternal authority transforms into melting love.

REASONING: The STC-Link method forces textual grounding at each step. "dcgq¡" repetition is the structural key; "tsab;" (melting) in stanza 2 is the thematic resolution. This mirrors how board exam "explain with reference to context" answers are structured: quote → explain → connect.

ANSWER: The secondary theme is **Leela-tattva (divine play as the medium of devotion)**. It develops through the "dcgq¡" (sometimes) structure showing alternating maternal panic/authority and Krishna's charming defiance, resolving in stanza 2 where Yashoda's binding becomes love's melting ("tsab;"). This deepens the primary theme by showing bhakti as joyous surrender to God's play, not rigid ritual.

## WORKED_EXAMPLE_2
PROBLEM: Analyze how the secondary theme of "poet's identity transformation" (Muslim poet → Krishna devotee) operates in stanza 2 through direct address and self-identification.

STEPS:
- Step 1: Identify the shift — Stanza 1: third-person narration ("rqylhnkl og le; dgs rsa..."). Stanza 2: first-person direct address ("jk?kkS! ,d ckj fiQfj vkokS" — O Yashoda! Once I pleaded).
- Step 2: Trace self-references — "esjs jke" (my Krishna), "esjs jke ykfMys" (my Krishna, O beloved), "rqylh eks¯g vkSj lcfgu rsa" (Raskhan says: Krishna and I both). The poet inserts himself into the narrative.
- Step 3: Categorize — Theme: **Atma-nivedan (self-surrender as identity transformation)**. The poet doesn't just describe devotion; he *performs* it by becoming a character in the leela.
- Step 4: Analyze technique — Uses "jk?kkS" (Yashoda) as stand-in for guru/divine mediator. Pleads: "fuiV fclkjs" (remove my confusion). Claims kinship: "rqylh eks¯g vkSj lcfgu rsa bUgdks cM+ks vanslks" (Raskhan says: Krishna and I both make them great). "vanslks" = acceptance/approval.
- Step 5: Link to primary theme — This personal entry validates the primary theme (Krishna-bhakti) as *universally accessible* — not limited by birth (Muslim poet), language (Braj not Persian), or tradition. The secondary theme *proves* the primary theme's inclusivity.
- Step 6: Connect to historical context — Raskhan's lived life (born Muslim, died Krishna-bhakt) mirrors this textual transformation. The poem *is* the evidence.

REASONING: This example shows how secondary theme analysis requires biographical + textual + theological synthesis — exactly what CUET/Board "critical interpretation" questions demand. The key move: seeing the poet's voice shift as thematic argument, not just stylistic choice.

ANSWER: The secondary theme is **identity transformation through surrender (atma-nivedan)**. It operates via: (1) speaker shift from narrator to participant, (2) direct address to Yashoda as guru-figure, (3) self-identification as "esjs jke" (my Krishna), (4) claim of mutual acceptance ("vanslks") with Krishna. This enacts the primary theme's claim: bhakti transcends religious birth-identity.

## WORKED_EXAMPLE_3
PROBLEM: Compare the secondary theme of "love as binding force" in Raskhan's "Hajar-jke dk izse" (stanza 1: "caèkq cksfy tsab; tks HkkoS xbZ fuNkofj eS;k") and Surdas's "Maiya mori main nahin makhan khayo" (Class 11). How does each poet use the *damodar-lila* (Krishna tied to mortar) differently?

STEPS:
- Step 1: Recall Surdas's treatment — In "Maiya mori," the binding is comic denial: Krishna *denies* stealing butter, frames it as mother's illusion. The rope keeps shortening (divine play). Theme: **God's playful evasion of human categories**.
- Step 2: Analyze Raskhan's treatment — "caèkq cksfy tsab; tks HkkoS xbZ fuNkofj eS;k" — the grinding stone (cakki) becomes binding rope. "tsab; tks HkkoS" — *love* binds. "fuNkofj eS;k" — melts the heart. The physical binding *is* spiritual melting.
- Step 3: Categorize difference — Surdas: binding = divine play (leela) that *reveals* Krishna's freedom. Raskhan: binding = love's power that *transforms* the binder (Yashoda) and the bound (Krishna) both.
- Step 4: Trace theological implication — Surdas (Vallabha sampradaya): Krishna is *always* free; binding is lila. Raskhan (universal bhakti): Love *binds* the Infinite — the devotee's love has coercive power over God.
- Step 5: Link to secondary themes — Surdas's secondary theme: **divine freedom (svatantrya)**. Raskhan's secondary theme: **love's sovereignty (prem-ki prabhuta)**.
- Step 6: Synthesize for exam answer — "While both use damodar-lila, Surdas emphasizes Krishna's uncontainable divinity (rope shortens), Raskhan emphasizes love's ability to contain the Infinite (heart melts). Raskhan's 'tsab;' (melting) transforms physical bond into spiritual fusion."

REASONING: This multi-text comparison is a hallmark of CUET and Board "comparative literature" questions. It requires: (a) accurate recall of prior text, (b) close reading of current text, (c) theological/philosophical categorization, (d) explicit linking to theme labels. The worked example models the 6-step comparative analysis.

ANSWER: Surdas uses damodar-lila to show **divine freedom** (Krishna cannot be bound; rope shortens miraculously). Raskhan uses it to show **love's sovereignty** ("tsab; tks HkkoS xbZ fuNkofj eS;k" — love binds and melts). Surdas's secondary theme = God's play transcends human control. Raskhan's = Human love *controls* God. Raskhan's innovation: the grinding stone (cakki) — symbol of daily domestic labor — becomes the instrument of divine capture, sanctifying ordinary maternal work as bhakti.

## COMPETENCY_QUESTION_1
QUESTION: A Class 12 student writes in the board exam: "Raskhan's poem has many secondary themes like maternal love, surrender, and religious harmony. He uses simple language to express them." The examiner awards 2/5 marks. Using the STC-Link method, rewrite the answer to earn full marks. Your rewrite must include: (a) three named secondary themes, (b) one textual anchor per theme, (c) one link-sentence per theme connecting to primary theme.

COMPETENCY
Structured answer writing with textual evidence and thematic linking (CBSE Board competency: "Analyze and interpret literary texts with evidence")

STEPS:
- Step 1: Identify the three secondary themes from the poem — (1) Vatsalya-leela (maternal love as divine play), (2) Atma-nivedan (poet's self-surrender), (3) Prem-ki prabhuta (love's sovereignty over the Infinite).
- Step 2: For each theme, select one precise textual anchor — (1) "dcgq¡ leqf> ouxeu jke dks jfg pfd fp=kfy[kh lh" (stanza 1), (2) "esjs jke ykfMys! rs vc fuiV fclkjs" (stanza 2), (3) "caèkq cksfy tsab; tks HkkoS xbZ fuNkofj eS;k" (stanza 1).
- Step 3: Write link-sentence for each — (1) This image of Krishna charming Yashoda with butter-smeared face shows bhakti as joyous participation in God's play, not rigid ritual. (2) The poet's direct plea to Yashoda and claim "esjs jke" enacts the primary theme's universality — bhakti transcends birth-identity. (3) The grinding stone binding that melts the heart proves love binds the Infinite, making domestic love a path to liberation.
- Step 4: Assemble into coherent paragraph with topic sentence and concluding synthesis.

ANSWER: Raskhan's "Hajar-jke dk izse" deepens the primary theme of Krishna-bhakti through three interwoven secondary themes. First, **vatsalya-leela** (maternal love as divine play) emerges in the image of Krishna charming Yashoda with butter-smeared face ("leqf> ouxeu jke dks jfg pfd fp=kfy[kh lh"), revealing bhakti as joyous participation in God's play rather than solemn duty. Second, **atma-nivedan** (self-surrender) is enacted when the poet directly addresses Yashoda as "esjs jke ykfMys" and pleads "fuiV fclkjs," claiming Krishna as his own — this personal entry validates the primary theme's universality across religious boundaries. Third, **prem-ki prabhuta** (love's sovereignty) appears in the damodar-lila reimagined: the grinding stone binding becomes heart-melting ("caèkq cksfy tsab; tks HkkoS xbZ fuNkofj eS;k"), proving love can bind the Infinite. Together, these themes transform a Puranic episode into a theology of inclusive, joyous, transformative devotion.

DIFFICULTY
medium

## COMPETENCY_QUESTION_2
QUESTION: In the CUET 2024 Hindi paper, a question asked: "Compare how two Bhakti poets (one Nirguna, one Saguna) use a secondary theme to argue for religious inclusivity. Use textual evidence." Write a 150-word comparative answer comparing Raskhan (Saguna) and Kabir (Nirguna) on the secondary theme of **religious harmony**, using one doha from Kabir (Class 11) and one stanza from Raskhan (Chapter 6).

COMPETENCY
Comparative literary analysis across texts and traditions (CUET competency: "Critical thinking and intertextual connections")

STEPS:
- Step 1: Select Kabir doha — "Hindu-Musalman sab ek, kahu Kabir vichar / Ek hi raam rahim, ek hi thakur" (or similar from Class 11 Chapter 1). Identify method: *negation of labels* + *intellectual assertion*.
- Step 2: Select Raskhan stanza — Stanza 2: "rqylh eks¯g vkSj lcfgu rsa bUgdks cM+ks vanslks" (Raskhan says: Krishna and I both make them great/accepted). Identify method: *affirmative embodiment* + *lived identity*.
- Step 3: Categorize difference — Kabir: harmony through *deconstruction* (rejecting external labels). Raskhan: harmony through *reconstruction* (adopting the other's tradition fully).
- Step 4: Draft comparative argument — Kabir's secondary theme of harmony operates via *vichar* (reason): he exposes the absurdity of division. Raskhan's operates via *anubhav* (experience): he becomes the harmony he preaches. Kabir says "we are one"; Raskhan *lives* "I am Krishna's."
- Step 5: Polish to 150 words with precise terminology (Nirguna/Saguna, vichar/anubhav, deconstruction/embodiment).

ANSWER: Kabir (Nirguna) and Raskhan (Saguna) both advocate religious harmony but through opposing literary methods. Kabir's doha "हिंदू-मुसलमान सब एक, कहु कबीर विचार / एक ही राम रहीम, एक ही ठाकुर" uses **vichar (intellectual deconstruction)**: he negates external labels ("Hindu-Musalman") to assert an abstract unity ("Ek hi Ram Rahim"). Harmony is a *conclusion* of reason. Raskhan's stanza "रसखन एग वक लचगु रसा बूगडक्स ंसलक्स" (रसखन एक और लगु रसा बूगडक्स ंसलक्स — Raskhan says: Krishna and I both make them great) uses **anubhav (lived embodiment)**: a Muslim poet adopts Braj Bhasha, Vaishnava imagery, and Krishna-bhakti *from within*. He doesn't argue for unity; he *performs* it by becoming a devotee. Kabir's secondary theme of harmony is **propositional** (stated); Raskhan's is **performative** (enacted). This mirrors their theological divergence: Nirguna rejects form to find unity; Saguna embraces a specific form (Krishna) to transcend all forms.

DIFFICULTY
hard