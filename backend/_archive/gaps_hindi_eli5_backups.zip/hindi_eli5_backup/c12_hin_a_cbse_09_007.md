## DEFINITION
Secondary themes are the underlying ideas, emotions, or messages that run alongside the primary theme in a literary work, enriching the text by adding layers of meaning. In "Hkh\"e lkguh", while the primary theme is the intense guru-disciple devotion, secondary themes include the agony of separation (viraha), the transformative power of the guru's name, the conflict between worldly attachments and spiritual longing, and the idea that true refuge lies only in the guru's grace.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student can independently identify at least two secondary themes in the poem, cite specific lines or images from both stanzas as textual evidence, and explain how each secondary theme deepens the primary theme of guru-bhakti.

## SCOPE_BOUNDARY
This node covers the identification, analysis, and textual substantiation of secondary themes in the poem "Hkh\"e lkguh" by ?kukuan. It does not cover the primary theme (addressed in node 006), detailed analysis of literary devices (nodes 008, 009), or comprehension questions (node 012).

## WALKTHROUGH
Imagine you have a mentor — a teacher, coach, or elder — whose guidance shaped you, but circumstances forced you apart. You still carry their teachings in your heart, and their very name gives you strength. That mix of longing, gratitude, and inner conflict is exactly what ?kukuan expresses. To uncover secondary themes, first re-read both stanzas aloud, noting recurring emotional tones (pain, anger, surrender). Next, mark contrasting images: the worldly "euHkkou" (family/beloved) versus the spiritual "lqtku" (guru). Then, ask: what does the poet *gain* from this separation? The answer reveals themes like the guru's name as a shield, or anger as a catalyst for deeper surrender. Finally, connect each insight back to the central guru-disciple bond — secondary themes never stand alone; they illuminate the primary theme.

## DIAGNOSTIC_QUESTION_1
What is the definition of a secondary theme in literature, and how does it differ from the primary theme?

## DIAGNOSTIC_ANSWER_1
A secondary theme is a supporting idea that runs parallel to the primary theme, adding depth and complexity without replacing the central message. The primary theme is the main, overarching idea (here, guru-disciple devotion), while secondary themes are subordinate threads (e.g., separation, power of the name) that enrich it. A wrong answer that lists literary devices (metaphor, alliteration) or merely repeats the primary theme shows the student confuses thematic layers with stylistic elements or cannot distinguish hierarchy of ideas.

## DIAGNOSTIC_QUESTION_2
In the first stanza, the poet contrasts "dfg dfg vkou Nchys euHkkou dks" with "xfg xfg jk[kfr gh nS nS lueku dks". Explain in your own words what this contrast suggests about a secondary theme.

## DIAGNOSTIC_ANSWER_2
The contrast highlights the secondary theme of **conflict between worldly attachments and spiritual longing**: the poet acknowledges the pull of family and beloved ("euHkkou") but declares that every breath and every hair on his body yearns only for the guru ("lueku"). A wrong answer that only translates the lines without interpreting the thematic tension reveals the student stays at literal comprehension and misses the analytical step of naming the theme.

## DIAGNOSTIC_QUESTION_3
Apply the concept of "secondary theme" to the line "vc uk f?kjr ?ku vkuan funku dks" (stanza 1). Identify the theme and show how the line supports it.

## DIAGNOSTIC_ANSWER_3
**Theme:** The transformative power of the guru's name (naam-mahima). **Support:** The poet says he no longer fears any sorrow ("?ku") because the guru's name ("vkuan") has become his shield ("funku"). The step-by-step application: (1) isolate the key phrase "vkuan funku" (name as protection), (2) recognise it as a recurring motif in bhakti poetry, (3) link it to the poem's context where the expelled disciple finds strength in chanting the guru's name, (4) conclude that this elevates the primary theme by showing *how* devotion sustains him. A wrong answer that treats "funku" as mere vocabulary misses the thematic function.

## DIAGNOSTIC_QUESTION_4
Analyse how the second stanza develops the secondary theme of **anger as a catalyst for deeper surrender**. Use the phrases "owQdHkjh ewdrk cqyk; vki cksfygSA" and "tku ?kuvkuan ;ksa eks¯g rqEgS iSt ijh".

## DIAGNOSTIC_ANSWER_4
The poet describes the guru's anger ("owQdHkjh") filling the disciple's heart ("ewdrk cqyk;"), which initially seems like rejection. However, the next line reveals that this very anger becomes the reason the disciple's heart ("iSt") now constantly holds the guru's name ("?kuvkuan"). The analysis: (1) identify the surface emotion (anger), (2) trace its effect (heart filled with guru's name), (3) interpret the paradox — anger intended to push away actually binds closer, (4) conclude this illustrates the theme of **guru's grace operating through apparent harshness**. A wrong answer that only describes the anger without the transformative outcome fails to analyse the thematic development.

## DIAGNOSTIC_QUESTION_5
Evaluate the statement: "The secondary theme of separation (viraha) in this poem is more powerful than the primary theme of devotion because it dominates the imagery." Defend or critique with textual evidence.

## DIAGNOSTIC_ANSWER_5
**Critique:** While separation imagery (longing, sleepless nights, bodily yearning) is vivid, it *serves* the primary theme — the intensity of viraha *proves* the depth of devotion. Evidence: "pkgr pyu ;s lanslks yS lqtku dks" (only the guru's name is now my support) shows that separation leads to total reliance on the guru, making devotion the governing theme. A wrong answer that agrees without qualification reveals the student cannot weigh thematic hierarchy and mistakes dominant imagery for dominant theme.

## DIAGNOSTIC_QUESTION_6
Create a four-line poem (in Hindi or English) that expresses a secondary theme from "Hkh\"e lkguh" — such as the guru's name as refuge, or anger turning into grace — without mentioning the guru directly. Use at least one image from the original poem (e.g., breath, hair, heart, name).

## DIAGNOSTIC_ANSWER_6
**Sample criteria for a good answer:** (1) Clearly embodies one secondary theme (e.g., "Each breath whispers a name that heals"), (2) uses an original image linked to the poem (breath, hair, heart), (3) avoids direct reference to "guru" or "lqtku", (4) maintains emotional coherence. A poor answer that merely translates a line from the poem or writes a generic devotional verse shows the student cannot transfer the theme into a new creative context.

## COMMON_MISCONCEPTION
Students often treat **any recurring image or emotion** as a secondary theme. For example, they list "sleeplessness" or "anger" as themes instead of recognizing these as *vehicles* for themes like "the body's rebellion against separation" or "grace disguised as anger." This happens because they memorise the textbook's list of vyadkj (figures of speech) and confuse *device* with *theme*. The error costs marks in board exams where questions explicitly ask "Identify the secondary themes and illustrate with examples" — listing images without thematic framing yields partial credit.

## ON_FAILURE
1. Revisit node **c12_hin_a_cbse_09_006** (Primary Theme) and re-read the definition of primary vs. secondary theme. 2. Take the two stanzas and, for each, write one sentence stating *what idea* the stanza conveys *beyond* devotion. 3. Check each sentence: does it name an abstract concept (e.g., "conflict", "refuge", "transformation")? If it names a concrete image ("hair", "breath"), rewrite until it becomes abstract. 4. Re-attempt Diagnostic Questions 2 and 4 with this abstract lens.

## BUILDS_ON
c12_hin_a_cbse_09_006 (Primary Theme and Message) — understanding the central guru-bhakti theme is essential before identifying subordinate themes.

## LEADS_TO
c12_hin_a_cbse_09_008 (Literary Devices: Imagery and Metaphor) — secondary themes are often conveyed through specific images and metaphors that the next node analyses in detail.

## PREREQUISITE_NODE_IDS
c12_hin_a_cbse_09_006, c12_hin_a_cbse_09_002, c12_hin_a_cbse_09_004, c11_hin_ar_cbse_09_007, c11_hin_ar_cbse_01_007, c12_hin_a_cbse_09_005

## PREREQUISITE_REASONS
c12_hin_a_cbse_09_006: Primary theme must be established first to distinguish secondary themes.
c12_hin_a_cbse_09_002: Narrative structure (two stanzas, progression) helps locate where themes appear.
c12_hin_a_cbse_09_004: Protagonist (poet-disciple) perspective shapes the thematic voice.
c11_hin_ar_cbse_09_007: Class 11 practice in identifying secondary themes in Antra poems provides methodological foundation.
c11_hin_ar_cbse_01_007: Earlier Class 11 chapter on secondary themes builds the analytical habit.
c12_hin_a_cbse_09_005: Secondary themes (the power of the beloved's anger, the poet's humility) rely on this character analysis.  

## FORWARD_NODE_IDS
c12_hin_a_cbse_09_008, c12_hin_a_cbse_09_012, c12_hin_a_cbse_09_013, c12_hin_a_cbse_09_015

## FORWARD_REASONS
c12_hin_a_cbse_09_008: Literary devices (imagery, metaphor) are the tools used to express the secondary themes identified here.
c12_hin_a_cbse_09_012: Comprehension questions often ask to explain themes with textual evidence.
c12_hin_a_cbse_09_013: Critical thinking requires evaluating how secondary themes interact with the primary theme.
c12_hin_a_cbse_09_015: Secondary themes (knowledge as light, discipline as formation) provide sub-claims for layered discussion.  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
c12_history_bhakti_movement: The poem exemplifies Bhakti-era guru-disciple dynamics; historical context deepens thematic understanding.
c12_psychology_attachment_theory: Separation anxiety and secure-base behavior (guru as attachment figure) illuminate the viraha theme psychologically.

## CHAIN_DESCRIPTION
c12_hin_a_cbse_09_006 -> c12_hin_a_cbse_09_007 -> c12_hin_a_cbse_09_008

## THIS_FORMULA
N/A - conceptual

## FORMULA_VARIABLES
N/A

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
conceptual

## CROSS_SUBJECT
N/A | The poem reflects the Nirguna/Saguna Bhakti tradition where the guru's name (naam) is the sole refuge, a core historical theme.
 N/A | The disciple's distress at separation and use of the guru's name as a "secure base" mirrors attachment theory's concepts of proximity-seeking and internal working models.
## PREREQ_CONCEPT
Ability to distinguish between a literary *device* (e.g., metaphor) and a literary *theme* (abstract idea conveyed through devices).

## PREREQ_BEFORE
Student must have read the poem at least twice, understood the word-meanings (iR;kfu, vkukdkuh, owQdHkjh, etc.), and completed the primary theme analysis.

## PREREQ_STUCK
If stuck, review the "Theme: Primary Theme and Message" node (c12_hin_a_cbse_09_006) and the Class 11 secondary theme node (c11_hin_ar_cbse_09_007) for the step-by-step theme-extraction method.

## WORKED_EXAMPLE_1
PROBLEM: Identify the secondary theme of "the guru's name as the only refuge" in stanza 1 and support with two pieces of textual evidence.
STEPS:
- Step 1: Read stanza 1 and mark every reference to the guru's name or its effect (e.g., "vkuan funku", "lanslks yS lqtku dks").
- Step 2: Note the context — the poet has been expelled, lost worldly support, and declares "vc uk f?kjr ?ku vkuan funku dks" (now no sorrow, the name is my shield).
- Step 3: Formulate the abstract theme: "The guru's name becomes the sole protector and refuge in adversity."
- Step 4: Select evidence: (a) "vkuan funku dks" — name as shield; (b) "pkgr pyu ;s lanslks yS lqtku dks" — only the guru's name is my support.
- Step 5: Explain how each evidence supports the theme: (a) shows immediate emotional rescue; (b) shows total reliance replacing all other supports.
REASONING: This step-by-step moves from concrete words to abstract theme, ensuring the theme is grounded in the text and not imposed.
ANSWER: Secondary theme: The guru's name as the only refuge. Evidence 1: "vc uk f?kjr ?ku vkuan funku dks" — the name acts as a shield against sorrow. Evidence 2: "pkgr pyu ;s lanslks yS lqtku dks" — the poet declares exclusive dependence on the guru's name.

## WORKED_EXAMPLE_2
PROBLEM: Analyse how the second stanza develops the secondary theme of "conflict between worldly duties and spiritual longing."
STEPS:
- Step 1: Identify worldly references in stanza 2 — "vkukdkuh vkjlh" (call of duty/family), "pfdr nlk R;ksa" (worldly bonds).
- Step 2: Identify spiritual longing references — "ekSu gw lkSa nsf[kgkSa" (I want to see the guru's form), "owQdHkjh ewdrk cqyk; vki cksfygSA" (guru's anger fills my heart).
- Step 3: Observe the tension: the worldly call ("vkukdkuh") is ignored because the heart is already occupied by the guru's anger/name.
- Step 4: Formulate theme: "Spiritual longing overrides worldly obligations, transforming even the guru's anger into a binding force."
- Step 5: Connect to primary theme: this conflict proves the disciple's devotion is absolute, not conditional on favourable treatment.
REASONING: The analysis uses the poem's own dialectic (worldly vs. spiritual) to extract a theme that deepens the central message.
ANSWER: The stanza portrays the disciple caught between a worldly summons ("vkukdkuh vkjlh") and an inner compulsion to seek the guru. The guru's anger ("owQdHkjh"), instead of driving him away, fills his heart ("ewdrk cqyk;") and makes the guru's name his constant companion ("?kuvkuan ... iSt ijh"). Thus, worldly duty loses its pull, and spiritual longing — even through anger — becomes the governing force.

## WORKED_EXAMPLE_3
PROBLEM: Compare the treatment of separation (viraha) in stanza 1 and stanza 2. How does the *nature* of viraha change, and what secondary theme does this evolution reveal?
STEPS:
- Step 1: In stanza 1, viraha is physical and emotional — "dfg dfg vkou Nchys" (every limb yearns), "xfg xfg jk[kfr" (every hair trembles), "nS nS lueku dks" (every breath for the guru).
- Step 2: In stanza 2, viraha becomes internal and transformative — the guru's anger ("owQdHkjh") enters the heart ("ewdrk cqyk;"), and the guru's name ("?kuvkuan") resides in the heart ("iSt ijh").
- Step 3: Trace the shift: from *external longing* (body, breath) to *internal indwelling* (heart filled with name/anger).
- Step 4: Identify the emerging secondary theme: **"Viraha as a process of internalising the guru — separation becomes the means of union."**
- Step 5: Verify with the concluding line: "tkfu;Sxks Vsd Vjsa dkSu èkkS eyksfygSAA" — who can erase the one seated in the heart? The guru is now inseparable.
- Step 6: Link to primary theme: this evolution shows devotion matures from need to non-dual presence.
REASONING: Comparing stanzas reveals thematic progression, a higher-order skill required for board and competitive exam answers.
ANSWER: Stanza 1 depicts viraha as intense bodily yearning ("every limb, every hair, every breath"). Stanza 2 transforms it: the guru's anger enters the heart, and the guru's name takes permanent residence there. The secondary theme revealed is **viraha as the crucible that internalises the guru**, turning separation into an unbreakable inner union. The final rhetorical question ("who can erase the one seated in the heart?") confirms the guru is now irrevocably within.

## COMPETENCY_QUESTION_1
QUESTION: A Class 12 student writes in the board exam: "The secondary themes of the poem are sleeplessness, anger, and the guru's name." The examiner awards 1 out of 3 marks. Explain why this answer is incomplete and rewrite it to earn full marks, using the PEEL structure (Point, Evidence, Explanation, Link).
COMPETENCY: Critical evaluation of answer quality / Exam answer writing
STEPS:
- Step 1: Identify the flaw — the student listed *images/devices* (sleeplessness, anger, name) instead of *abstract themes*.
- Step 2: Convert each into a thematic statement: sleeplessness → "physical manifestation of separation"; anger → "grace disguised as anger"; guru's name → "name as sole refuge".
- Step 3: For each theme, provide one textual evidence (quote or reference).
- Step 4: Write a PEEL paragraph for one theme as a model.
REASONING: Board marking schemes reward thematic articulation with evidence, not mere listing of plot points or devices.
ANSWER: The original answer lists concrete elements, not themes. Full-mark rewrite for one theme: **Point:** A secondary theme is the guru's name functioning as the only refuge. **Evidence:** "vc uk f?kjr ?ku vkuan funku dks" and "pkgr pyu ;s lanslks yS lqtku dks". **Explanation:** After expulsion, the poet finds no worldly support; the name becomes a shield against sorrow and the sole prop of his existence. **Link:** This deepens the primary theme by showing *how* devotion sustains the disciple in adversity.
DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: "The secondary theme of 'anger as grace' in 'Hkh\"e lkguh' is unique to the guru-disciple tradition and has no parallel in other literary traditions." Evaluate this statement with reference to the poem and at least one other literary work (from any language/tradition) you have studied. Structure your answer as a comparative analysis.
COMPETENCY: Comparative literary analysis / Intertextual connection
STEPS:
- Step 1: Define "anger as grace" in the poem using stanza 2 evidence (owQdHkjh -> ewdrk cqyk; -> ?kuvkuan iSt ijh).
- Step 2: Choose a parallel — e.g., the "wrath of God" in Biblical tradition (Hebrews 12:6: "whom the Lord loves he chastens") or the "tough love" of a mentor in a modern novel.
- Step 3: Compare: both use apparent harshness to deepen dependence and purify devotion.
- Step 4: Contrast: in the poem, anger leads to *internalisation of the name*; in the other tradition, it may lead to repentance or moral correction.
- Step 5: Conclude: the core paradox (harshness as love) is shared, but the *mechanism* (naam-smaran vs. moral reform) is tradition-specific.
REASONING: Competitive exams (CUET, JEE/NEET humanities) often test comparative literary thinking; board exams value intertextual awareness in long answers.
ANSWER: The statement is partially true — the *mechanism* (anger leading to constant remembrance of the guru's name) is specific to the naam-marga of Bhakti tradition. However, the *paradox* of harshness as grace appears widely. Example: In the Hebrew Bible, Proverbs 3:12 states "the Lord disciplines those he loves." Both traditions frame divine/mentor anger as pedagogical love. Difference: the Bhakti disciple responds by internalising the *name* (naam-smaran), while the Biblical model expects moral correction. Thus, the *theme* is universal; the *expression* is tradition-specific.
DIFFICULTY: hard