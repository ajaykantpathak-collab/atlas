## DEFINITION
Writing skills based on the chapter refer to the ability to compose structured, creative, and analytical responses — such as diary entries, character sketches, descriptive paragraphs, and dialogues — that draw directly on the themes, imagery, characters, and emotional landscape of the poem "कंजकली" by Syed Ehtesham Hussain.

## COGNITIVE_LEVEL
apply

## MASTERY_CRITERIA
The student can independently produce a 100–150 word piece in a specified format (diary entry, character sketch, descriptive paragraph, or dialogue) that integrates at least two textual evidences from the poem, maintains the required tone and structure, and reflects the poem’s folk flavour and monsoon mood.

## SCOPE_BOUNDARY
This node covers four writing formats tied to "कंजकली": diary entry (first‑person emotional record), character sketch (third‑person analytical portrait), descriptive paragraph (sensory scene‑painting), and dialogue (dramatic interaction). It does NOT cover unrelated formats like formal letters, notices, articles on general topics, or essay writing.

## WALKTHROUGH
Imagine you are Kanjakali, standing barefoot in the courtyard as the first monsoon drops hit the dust — what would you write in your diary that night? Begin by recalling the poem’s key images: the rain‑darkened sky, the peacock’s cry, the longing in the air. Next, pick the format (diary entry = date, first person, intimate tone). Then, select two vivid lines from the poem (e.g., the description of rain in stanza 1, the peacock’s dance in stanza 3) and turn them into personal observations. Draft using the PEEL structure: Point (your feeling), Evidence (poem’s image), Explanation (what it means to you), Link (broader theme of longing). Finally, read aloud to check if the folk rhythm and emotional authenticity come through.

## DIAGNOSTIC_QUESTION_1
What are the four mandatory components of a diary entry format in CBSE Class 12 Hindi?

## DIAGNOSTIC_ANSWER_1
The four mandatory components are: (1) Date and day, (2) Time (optional but recommended), (3) Salutation (e.g., "प्रिय डायरी"), (4) Body written in first person, and (5) Closing signature. A wrong answer (e.g., listing "subject line" or "address") reveals the student is confusing diary entry with formal letter format.

## DIAGNOSTIC_QUESTION_2
Why must a diary entry based on Kanjakali be written in first person rather than third person?

## DIAGNOSTIC_ANSWER_2
First person captures the protagonist’s subjective emotions — her joy, longing, and unity with nature — which are central to the poem’s folk lyricism. A third‑person account would distance the reader from the intimate, immediate experience the poem creates. A wrong answer (e.g., "third person is more formal") shows the student misunderstands the purpose of diary writing as personal expression.

## DIAGNOSTIC_QUESTION_3
Write a four‑line dialogue between Kanjakali and the peacock (मोर) using imagery from the poem’s first and third stanzas.

## DIAGNOSTIC_ANSWER_3
**Steps:**  
1. Identify two images: rain‑soaked earth (stanza 1) and peacock’s dance (stanza 3).  
2. Assign each speaker a line reflecting their perspective.  
3. Keep the folk rhythm (short, rhyming lines).  
4. Ensure the dialogue reveals mutual longing.  

**Sample answer:**  
कंजकली: "बरसात की बूँदें मेरे आँगन में गाती हैं, मोर नाचो ना!"  
मोर: "तेरी पायल की झंकार सुनी, तब ही तो नाचूँ मैं रे!"  
कंजकली: "बादल गरजे, दिल डोले, सखी बनी घटा आज।"  
मोर: "तेरे संग झूमूँगा, कंजकली, जब तक बरसे सावन आज।"  

A wrong answer that merely describes the scene without dialogue form shows the student cannot transform poetic imagery into dramatic speech.

## DIAGNOSTIC_QUESTION_4
Compare the descriptive language of the poem’s first stanza (rain’s arrival) with the third stanza (peacock’s dance). How does the mood shift?

## DIAGNOSTIC_ANSWER_4
The first stanza uses words like "फुहार", "भीगा आँगन", "शीतल हवा" to create a quiet, anticipatory mood. The third stanza shifts to dynamic verbs — "नाचता", "झूमता", "पंख फैलाता" — and auditory images ("कूक", "टेर") conveying ecstatic release. The mood moves from receptive stillness to expressive celebration. A wrong answer that only lists images without tracing the emotional arc misses the analytical demand.

## DIAGNOSTIC_QUESTION_5
Which writing format — diary entry, character sketch, or descriptive paragraph — best captures the poem’s central theme of longing (विरह)? Justify with two reasons.

## DIAGNOSTIC_ANSWER_5
Diary entry is most effective because: (1) Its first‑person intimacy mirrors the poem’s subjective lyricism, letting Kanjakali voice her inner void directly. (2) The dated, daily‑record structure parallels the cyclical monsoon waiting that frames the poem’s longing. A character sketch analyses from outside; a descriptive paragraph paints the setting but not the inner ache. A wrong choice without textual justification reveals evaluative weakness.

## DIAGNOSTIC_QUESTION_6
Compose a four‑line Hindi poem in the rhythm of "कंजकली" that describes winter (शीत ऋतु) instead of monsoon, using at least two folk‑style words.

## DIAGNOSTIC_ANSWER_6
**Criteria for a good answer:**  
- Four lines with a simple AABB or ABCB rhythm.  
- Two folk‑style words (e.g., "कुँआर", "अलाव", "चादर", "धुंध").  
- Sensory winter imagery (fog, bonfire, cold wind).  
- Emotional tone matching the original’s longing.  

**Sample:**  
"धुंध घिरी आँगन में, कुँआर की रात सुहानी।  
अलाव जले, बातें हों, याद आए नानी।  
शीतल पवन छूए गाल, कंजकली सी ठिठुरन।  
रजाई में सिमटे मन, बीते यूँ यह क्षण।"  

A poor answer that copies monsoon images or lacks folk vocabulary shows inability to adapt the poem’s form to a new context.

## COMMON_MISCONCEPTION
Students often write a **summary of the poem** when asked for a creative response (diary entry, dialogue, etc.). They treat "based on the chapter" as "about the chapter", producing a third‑person overview instead of a first‑person, format‑specific piece. This happens because they confuse *content knowledge* (what happens in the poem) with *writing craft* (how to shape that content into a required form). For example, a diary entry becomes "Kanjakali felt happy when it rained" instead of "आज बादल बरसे और मेरा मन मोर सा नाच उठा!"

## ON_FAILURE
1. **Revisit format templates**: Use node c12_hin_a_cbse_07_013 (Critical Thinking) to review the exact structure of each writing type.  
2. **Evidence hunting**: Go back to nodes c12_hin_a_cbse_07_003 (Setting) and 07_008 (Imagery) and list 5 concrete images/emotions from the poem.  
3. **Guided draft**: Fill a PEEL template for one format (e.g., diary entry) with teacher scaffolding, then write independently.  
4. **Re‑diagnose**: Attempt Diagnostic Question 3 again; if still struggling, practice dialogue writing with a simpler poem first.

## BUILDS_ON
Deep understanding of the poem’s setting (monsoon village), protagonist (Kanjakali’s emotions), and imagery (rain, peacock, longing) from nodes 07_003, 07_004, 07_008.

## LEADS_TO
Speaking and listening discussion (node 07_015) where students present their written pieces orally and defend creative choices.

## PREREQUISITE_NODE_IDS
c12_hin_a_cbse_07_003, c12_hin_a_cbse_07_004, c12_hin_a_cbse_07_008, c12_hin_a_cbse_07_013, c11_hin_ar_cbse_07_014, c12_hin_a_cbse_07_005, c12_hin_a_cbse_07_010, c12_hin_a_cbse_07_011, c12_hin_a_cbse_07_012

## PREREQUISITE_REASONS
c12_hin_a_cbse_07_003: Provides the monsoon setting and sensory details needed for descriptive writing.  
c12_hin_a_cbse_07_004: Supplies character traits and emotional arc for character sketch and diary entry.  
c12_hin_a_cbse_07_008: Equips student with specific metaphors and symbols (peacock, rain) to embed as textual evidence.  
c12_hin_a_cbse_07_013: Develops analytical skill to select and interpret evidence — prerequisite for PEEL structure.  
c11_hin_ar_cbse_07_014: Class 11 writing‑skills node establishes baseline formats (diary, sketch, paragraph) before Class 12 deepening.
c12_hin_a_cbse_07_005: Writing tasks (e.g., "analyze the role of the sakhi") demand the analytical paragraphs practiced here.  
c12_hin_a_cbse_07_010: Writing tasks (character sketch, thematic essay) demand quoting and glossing key words.  
c12_hin_a_cbse_07_011: Writing tasks (e.g., "कविता की भाषा शैली पर टिप्पणी लिखिए") directly use this node's analytical output.  
c12_hin_a_cbse_07_012: Writing skills (PEEL paragraphs) use the same Point-Evidence-Explanation structure practiced here.  

## FORWARD_NODE_IDS
c12_hin_a_cbse_07_015
## FORWARD_REASONS
c12_hin_a_cbse_07_015: Written pieces become scripts for oral presentation and debate in the speaking/listening activity.

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
c12_history_folk_culture: The poem’s folk idiom connects to medieval Bhakti/Sufi traditions studied in history — understanding oral culture enriches authentic voice.  
c12_geography_monsoon_climate: Geographic mechanism of monsoon (onset, spread, impact on rural life) grounds the poem’s setting in physical reality, aiding descriptive accuracy.

## CHAIN_DESCRIPTION
c12_hin_a_cbse_07_003 -> c12_hin_a_cbse_07_014 -> c12_hin_a_cbse_07_015

## THIS_FORMULA
PEEL structure for analytical paragraphs (Point, Evidence, Explanation, Link); Format‑Content‑Language checklist for creative formats (Diary: Date+FirstPerson+Emotion; Character Sketch: Traits+Evidence+ThirdPerson; Descriptive Paragraph: TopicSentence+SensoryDetails+FigurativeLanguage+Clincher).

## FORMULA_VARIABLES
P = Point (main idea), E = Evidence (quote or image from poem), E = Explanation (how evidence supports point), L = Link (connect to theme/central idea). For creative formats: F = Format requirements, C = Content drawn from poem, L = Language (folk flavour, appropriate register).

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
linguistic

## CROSS_SUBJECT
N/A | The poem’s folk style mirrors oral traditions of medieval India; historical context helps students adopt authentic diction.  
 N/A | Monsoon’s arrival, intensity, and cultural significance in rural India are geographic facts that make descriptive writing vivid and accurate.
## PREREQ_CONCEPT
Ability to extract and cite textual evidence (images, dialogues, emotions) from a poem and map them to a writing format’s structural requirements.

## PREREQ_BEFORE
Student must have completed close analysis of the poem’s setting (node 07_003), protagonist (07_004), and imagery/symbolism (07_008).

## PREREQ_STUCK
If stuck, re‑read the poem aloud focusing on sensory words; then list 5 images with stanza numbers. Use nodes 07_003 and 07_008 as reference.

## WORKED_EXAMPLE_1
**PROBLEM:** Write a diary entry (100‑120 words) from Kanjakali’s perspective on the night the monsoon arrives, using at least two images from the poem.

**STEPS:**  
1. **Identify format requirements**: Date, day, time, salutation "प्रिय डायरी", first‑person body, signature.  
2. **Recall poem’s key images**: Stanza 1 — "फुहार", "भीगा आँगन", "शीतल हवा"; Stanza 3 — "मोर नाचता", "पंख फैलाता", "कूक".  
3. **Select emotions**: Joy of rain’s arrival + deep longing for absent beloved (विरह).  
4. **Draft using PEEL**:  
   - Point: "आज सावन की पहली फुहार ने मेरा आँगन भिगो दिया।"  
   - Evidence: "मोर ने पंख फैलाकर ऐसे नाचा जैसे मेरे मन का राग समझ गया हो।"  
   - Explanation: "उसकी कूक में मुझे अपने प्रिय की पुकार सुनाई दी।"  
   - Link: "बरसात आ गई, पर तुम कब आओगे?"  
5. **Review**: Check word count, folk vocabulary (सावन, आँगन, कूक), emotional authenticity.

**REASONING:** The PEEL structure ensures each poetic image serves the diary’s emotional arc. Folk words maintain the poem’s flavour. First‑person voice makes the longing immediate.

**ANSWER:**  
दिनांक: 15 जुलाई, शुक्रवार  
समय: रात 10 बजे  

प्रिय डायरी,  

आज सावन की पहली फुहार ने मेरा आँगन भिगो दिया। शीतल हवा जब गाल छूकर गुज़री, लगा जैसे कोई बरसों पुराना वादा पूरा हुआ हो। मोर ने नीम के नीचे पंख फैलाकर ऐसा नाचा कि उसकी कूक में मुझे अपने प्रिय की पुकार सुनाई दी। बरसात आ गई, धरती तृप्त हो गई, पर मेरा मन अब भी प्यासा है। तुम कब आओगे, साजन?  

तुम्हारी  
कंजकली

## WORKED_EXAMPLE_2
**PROBLEM:** Write a character sketch of Kanjakali (120‑150 words) using third‑person narration and at least three traits supported by poem evidence.

**STEPS:**  
1. **List traits from poem**: (a) Nature‑lover (dances with rain), (b) Emotionally expressive (longing voiced through nature), (c) Rooted in folk tradition (uses imagery of peacock, swing, monsoon).  
2. **Find evidence**: Stanza 1 — she stands in rain; Stanza 2 — she sings on swing; Stanza 3 — she addresses peacock as confidante.  
3. **Structure sketch**: Introduction (name, role), Trait 1 + evidence, Trait 2 + evidence, Trait 3 + evidence, Conclusion (significance).  
4. **Draft in third person, present tense**: "कंजकली ग्रामीण सौंदर्य की प्रतीक है। वह..."  
5. **Polish**: Replace generic adjectives with poem‑specific nouns (झूला, मोर, फुहार).

**REASONING:** Character sketch demands analytical distance (third person) but must stay anchored in textual proof. Each trait‑evidence pair mirrors the poem’s method of revealing character through interaction with nature.

**ANSWER:**  
कंजकली ग्रामीण स्त्री का वह सजीव चित्र है जो प्रकृति के साथ एकाकार होकर अपनी भावनाएँ व्यक्त करती है। वह प्रकृति‑प्रेमी है: पहली फुहार में आँगन में खड़ी होकर वह "शीतल हवा" का स्वागत करती है। उसकी अभिव्यक्ति सहज और गहरी है: झूले पर बैठकर गाते हुए वह विरह की पीड़ा को "कजरी" में ढाल देती है। वह लोक‑परम्परा की वाहक है: मोर को सखा मानकर उससे संवाद करती है — "मोर नाचो, मेरा मन नाचे"। इस प्रकार कंजकली व्यक्तिगत विरह को सामूहिक लोक‑संवेदना में बदल देती है।

## WORKED_EXAMPLE_3
**PROBLEM:** Write a descriptive paragraph (100 words) on the monsoon scene in the poem, organizing details spatially (sky → courtyard → vegetation → living beings) and using two figures of speech from the poem.

**STEPS:**  
1. **Identify sensory details**: Visual — dark clouds, wet courtyard, green leaves; Auditory — thunder, peacock’s call, rain drops; Tactile — cool wind, damp earth.  
2. **Choose spatial order**: Sky (clouds, thunder) → Courtyard (rain, puddles) → Vegetation (leaves, swing) → Living beings (peacock, Kanjakali).  
3. **Select figures of speech**: Simile — "मोर सा नाचता मन"; Personification — "बादल गरजे जैसे शिकायत कर रहे हों".  
4. **Draft with topic sentence**: "सावन का आगमन गाँव के आँगन को एक जीवंत कैनवास में बदल देता है।"  
5. **Weave details in order**, embed figures of speech, end with clincher linking to longing.

**REASONING:** Spatial organization mirrors the poem’s panoramic view. Figures of speech borrowed from the poem (simile, personification) create intertextual cohesion. The clincher ties description to theme.

**ANSWER:**  
सावन का आगमन गाँव के आँगन को एक जीवंत कैनवास में बदल देता है। काले मेघ आकाश में ऐसे घुमड़ते हैं जैसे कोई रूठा प्रेमी शिकायत कर रहा हो; गरज के साथ फुहारें आँगन की धूल को दुलारती हुई गिरती हैं। नीम के पत्ते धुलकर निखर उठते हैं, झूला बारिश की बूँदों से झिलमिलाता है। इसी बीच मोर पंख फैलाकर नाचता है — उसका नृत्य कंजकली के मन की तरंगों का प्रतिबिम्ब लगता है। प्रकृति का यह उत्सव सुंदर है, पर कंजकली की आँखों में एक मौन प्रतीक्षा भी झलकती है: बरसात आई, पर साजन नहीं।

## COMPETENCY_QUESTION_1
**QUESTION:** The poem uses the peacock as a symbol of Kanjakali’s inner state. Write a paragraph (80‑100 words) explaining how the peacock’s dance mirrors her longing, citing two specific images from the poem.

**COMPETENCY:** Analytical writing with textual evidence (CBSE competency: "Analysis and Interpretation")

**STEPS:**  
1. State the symbolic link in a topic sentence.  
2. Cite first image (peacock’s dance triggered by rain) and explain its parallel to Kanjakali’s awakened hope.  
3. Cite second image (peacock’s call/कूक) and explain its parallel to her voiced longing.  
4. Conclude with the unified theme of expression through nature.

**ANSWER:**  
मोर कंजकली के अंतर्मन का दर्पण है। जब वर्षा की फुहार पड़ती है, मोर "पंख फैलाकर नाचता है" — ठीक वैसे ही जैसे कंजकली का मन बरसात देख खिल उठता है। मोर की "कूक" केवल पक्षी‑ध्वनि नहीं, कंजकली की अनकही पुकार है; वह मोर से कहती है "नाचो, मेरा मन नाचे", जिससे स्पष्ट है कि मोर का नृत्य उसकी दबी हुई अभिलाषा की अभिव्यक्ति है। इस प्रकार प्रकृति (मोर) और मानवीय भावना (विरह) एकाकार हो जाते हैं।

**DIFFICULTY:** medium

## COMPETENCY_QUESTION_2
**QUESTION:** Imagine you are a journalist visiting the village during monsoon. Write a short article (120‑150 words) on the folk tradition of singing "कजरी" during the rains, drawing on the poem’s depiction of Kanjakali’s singing, the community’s response, and the role of nature. Use a headline, byline, and three paragraphs.

**COMPETENCY:** Creative adaptation and journalistic writing (CBSE competency: "Creative Writing — Article"; CUET/Higher‑order application)

**STEPS:**  
1. Craft a catchy headline and byline.  
2. Paragraph 1: Set scene — monsoon arrival, village atmosphere, introduce कजरी tradition.  
3. Paragraph 2: Focus on Kanjakali as exemplar — her singing on swing, interaction with peacock, folk authenticity.  
4. Paragraph 3: Broaden to community — collective participation, nature as co‑singer, tradition’s resilience.  
5. Ensure journalistic tone (third person, factual yet evocative), word limit, and at least two poem‑derived details.

**ANSWER:**  
**सावन में गूँजती कजरी: ग्रामीण आत्मा का संगीत**  
— ग्रामीण संवाददाता  

सावन की पहली फुहार पड़ते ही गाँव का आँगन कजरी की तानों से गूँज उठता है। बादलों की गरज और मोर की कूक के बीच स्त्रियाँ झूले पर बैठकर गाती हैं — विरह, प्रतीक्षा और प्रकृति के संगम के गीत। यह परम्परा केवल मनोरंजन नहीं, सामूहिक भावनाओं का निर्वाह है।  

कंजकली इस परम्परा की सजीव प्रतिमा है। नीम के झूले पर बैठी वह जब "कजरी" गाती है, तो मोर भी पंख फैलाकर नाचने लगता है। उसकी आवाज़ में गाँव की मिट्टी की गंध और बरसात की शीतलता घुली होती है। वह मोर को संबोधित करती है — "नाचो, मेरा मन नाचे" — जिससे लोक‑कंठ और वन‑कंठ की सीमा मिट जाती है।  

आज जब शहरीकरण लोक‑गीतों को हाशिये पर धकेल रहा है, यह गाँव कजरी को जीवित रखे हुए है। बारिश केवल फसल नहीं लाती, वह संस्कृति की जड़ें भी सींचती है। कंजकली जैसी असंख्य कंठ इस बात के प्रमाण हैं कि लोक‑संगीत अभी भी ग्रामीण भारत की धड़कन है।

**DIFFICULTY:** hard