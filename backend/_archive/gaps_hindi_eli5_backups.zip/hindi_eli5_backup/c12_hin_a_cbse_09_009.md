## DEFINITION
Irony (व्यंग्य) is a literary device where the intended meaning of words or situations is opposite to their literal meaning, creating a contrast between expectation and reality. Symbolism (प्रतीकवाद) uses concrete objects, characters, or actions to represent abstract ideas, emotions, or themes beyond their literal significance.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student must be able to identify specific instances of irony and symbolism in the poem "Varjak," explain how each device functions to deepen the theme of separation and unrequited love, and write a structured analysis using textual evidence with the PEEL method (Point, Evidence, Explanation, Link).

## SCOPE_BOUNDARY
This node covers irony (situational, verbal, dramatic) and symbolism (objects, natural elements, colors) specifically in Keshavdas's "Varjak" from Chapter 9 of Hindi Antra. It does NOT cover other poems in the textbook, nor does it teach general definitions without textual application.

## WALKTHROUGH
Imagine you're reading a WhatsApp status where someone posts "What a beautiful day!" during a torrential downpour — you instantly recognize the irony because the words clash with reality. Now open your textbook to "Varjak" and read the first stanza aloud. Notice how the poet describes the beloved's absence using images of blooming gardens and sweet breezes — scenes that should bring joy but instead intensify the pain of separation. That clash is irony. Then look at the "dark night" (काली रात) and "thunderclouds" (घनघोर घटा) — they aren't just weather; they symbolize the lover's inner turmoil. Your task: mark every line where what is said contradicts what is felt, and every image that carries a hidden emotional weight.

## DIAGNOSTIC_QUESTION_1
Define irony (व्यंग्य) in your own words and give one example from daily life (not from the textbook).

## DIAGNOSTIC_ANSWER_1
Irony is when words or situations convey a meaning opposite to their literal sense — e.g., saying "Great job!" when someone drops and breaks a plate. A wrong answer (e.g., "irony means sarcasm" or "irony is a lie") reveals the student confuses irony with mere mockery or falsehood, missing the structural contrast between expectation and reality that defines the device.

## DIAGNOSTIC_QUESTION_2
In the first stanza of "Varjak," the poet describes gardens in full bloom and cool breezes blowing. Explain why this description creates irony in the context of the poem's theme.

## DIAGNOSTIC_ANSWER_2
The natural beauty (blooming gardens, pleasant breezes) typically evokes joy and union, but here it intensifies the lover's pain because the beloved is absent — the external world's happiness contrasts sharply with internal sorrow. A wrong answer (e.g., "the poet likes nature" or "it sets a happy mood") shows the student reads literally and misses the situational irony: the setting mocks the speaker's emotional state.

## DIAGNOSTIC_QUESTION_3
Identify two symbols in the second stanza of "Varjak" and explain what abstract idea each represents.

## DIAGNOSTIC_ANSWER_3
(1) "काली रात" (dark night) symbolizes the lover's despair, ignorance, and emotional blindness. (2) "घनघोर घटा" (dense thunderclouds) symbolizes overwhelming grief and the heaviness of unfulfilled longing. A wrong answer (e.g., "night means it's late" or "clouds mean rain") treats symbols as literal descriptions, ignoring their conventional and contextual associative meanings.

## DIAGNOSTIC_QUESTION_4
Compare the function of irony in the first stanza with the function of symbolism in the second stanza. How do they work together to convey the central theme?

## DIAGNOSTIC_ANSWER_4
Irony in stanza 1 creates a painful gap between the joyful external world and the lover's inner void, while symbolism in stanza 2 externalizes that inner void into tangible images (dark night, thunderclouds). Together, they move the reader from cognitive contrast (irony) to visceral emotional immersion (symbolism), deepening the theme of separation. A wrong answer that treats them as separate decorative devices misses their structural partnership in building the poem's emotional arc.

## DIAGNOSTIC_QUESTION_5
A student claims: "The thunderclouds in stanza 2 are just a weather description — they don't symbolize anything because the poet doesn't say 'this represents my sadness.'" Evaluate this claim.

## DIAGNOSTIC_ANSWER_5
The claim is incorrect. Symbolism operates through association and context, not explicit labels. The thunderclouds appear precisely when the speaker describes sleeplessness and longing ("vc u f?kjr ?ku vkuan funku dks"), and their darkness, heaviness, and turbulence mirror the speaker's mental state — this contextual juxtaposition establishes the symbolic link. A wrong evaluation (agreeing with the student) reveals a misunderstanding that symbols must be explicitly declared, a common error that leads to missing implied meaning in board exam unseen passages.

## DIAGNOSTIC_QUESTION_6
Write a 4-line poem fragment (in Hindi or English) that uses BOTH irony and symbolism to express the feeling of waiting for someone who never arrives. Underline the ironic phrase and circle the symbol.

## DIAGNOSTIC_ANSWER_6
Example: "The clock ticks *cheerfully* (irony) — / its hands dance like **golden butterflies** (symbol of fleeting time/false hope) / while the chair stays empty / and the tea grows cold." A poor answer (e.g., only irony or only symbolism, or neither device used correctly) shows the student cannot synthesize the two devices creatively, indicating surface-level understanding rather than operational mastery.

## COMMON_MISCONCEPTION
Students often think irony and symbolism are the same as "metaphor" or "imagery" — they label any non-literal language as "metaphor" without distinguishing the specific mechanism. For example, they call "काली रात" a metaphor for sadness, but it's a symbol because it's a concrete object standing for an abstract idea through cultural association, not a direct comparison. They also confuse verbal irony (saying the opposite) with situational irony (outcome contrary to expectation) — in "Varjak," the blooming garden is situational irony, not verbal irony, because the poet isn't speaking sarcastically; the situation itself is ironic.

## ON_FAILURE
Step 1: Re-read the two stanzas of "Varjak" aloud, marking every word that describes nature (garden, breeze, night, clouds). Step 2: For each marked word, ask: "Does this word mean what it says, or does it carry a second meaning?" — if second meaning, it's a symbol. Step 3: Ask: "Does the scene described match the speaker's feeling?" — if opposite, it's situational irony. Step 4: Write one PEEL paragraph for each device using the template: "In stanza X, the poet uses [device] when describing [quote]. This creates [effect] because [explanation]. This supports the theme of [theme]." Re-attempt Diagnostic Questions 2 and 3 after this.

## BUILDS_ON
Class 11 node c11_hin_ar_cbse_01_009 (Literary Devices: Irony and Symbolism) where students learned basic definitions and identification in simpler poems.

## LEADS_TO
c12_hin_a_cbse_09_013 (Critical Thinking: Analysis and Interpretation) where students synthesize all literary devices to write full critical appreciations.

## PREREQUISITE_NODE_IDS
c11_hin_ar_cbse_01_009, c12_hin_a_cbse_09_008, c12_hin_a_cbse_09_006, c12_hin_a_cbse_09_002, c12_hin_a_cbse_09_003, c12_hin_a_cbse_09_005

## PREREQUISITE_REASONS
c11_hin_ar_cbse_01_009: Provides foundational definitions of irony and symbolism from Class 11 that this node deepens with complex textual application.
c12_hin_a_cbse_09_008: Imagery and Metaphor node teaches close reading of sensory language, which is essential for spotting symbolic images in "Varjak."
c12_hin_a_cbse_09_006: Primary Theme node establishes the central theme of separation/unrequited love, without which irony and symbolism cannot be interpreted in context.
c12_hin_a_cbse_09_002: Irony (unanswered plea) and symbolism (necklace) operate at structural turning points.  
c12_hin_a_cbse_09_003: Irony and symbolism often operate by contrasting with the established atmosphere.  
c12_hin_a_cbse_09_005: Irony (the beloved's anger is nectar) and symbolism (cup, fire, gaze) are rooted in her portrayal.  

## FORWARD_NODE_IDS
c12_hin_a_cbse_09_013, c12_hin_a_cbse_09_014, c12_hin_a_cbse_09_015

## FORWARD_REASONS
c12_hin_a_cbse_09_013: Critical Thinking requires analyzing how irony and symbolism interact with other devices to shape meaning — this node provides the device-specific evidence.
c12_hin_a_cbse_09_014: Writing Skills tasks (e.g., critical appreciation) demand structured analysis of literary devices using textual evidence — this node teaches the PEEL method for that.
c12_hin_a_cbse_09_015: Irony (guru burns self to light other) and symbolism (clay = unformed mind) offer interpretive depth for counter-arguments.  

## CROSS_SUBJECT_PREREQS
c11_hin_ar_cbse_01_009, c11_hin_ar_cbse_02_009, c11_hin_ar_cbse_03_009
## CROSS_SUBJECT_REASONS
c11_hin_ar_cbse_01_009: Reinforces irony/symbolism concepts across multiple Class 11 chapters (Aroh), showing device consistency across texts.
c11_hin_ar_cbse_02_009: Demonstrates how symbolism functions differently in narrative vs. poetic texts (Chapter 2 is prose).
c11_hin_ar_cbse_03_009: Shows irony in dramatic monologue form (Chapter 3), contrasting with lyrical irony in "Varjak."

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_01_009 -> c12_hin_a_cbse_09_009 -> c12_hin_a_cbse_09_013

## THIS_FORMULA
PEEL Analysis Structure for Literary Devices: Point (name device + location) → Evidence (quote/paraphrase line) → Explanation (how device works here) → Link (connect to theme)

## FORMULA_VARIABLES
Point = Specific device name (irony/symbolism) + stanza/line reference; Evidence = Key phrase from poem in original language; Explanation = Mechanism of contrast (irony) or association (symbolism); Link = Connection to theme of separation/longing

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
linguistic

## CROSS_SUBJECT
N/A | Both Hindi and English poetry use irony and symbolism as core devices; analyzing Keshavdas's "Varjak" builds the same close-reading skills needed for English poems like Keats's "Ode to a Nightingale" where the nightingale's song (symbol of eternal beauty) contrasts with the poet's mortality (irony).
 N/A | The cognitive dissonance created by situational irony (external joy vs internal pain) mirrors the psychological concept of emotional incongruence; symbolism operates through associative networks in memory — "dark night" activates schemas of fear/unknown, which the poem exploits for emotional resonance.
## PREREQ_CONCEPT
Ability to distinguish literal from figurative meaning and to identify the speaker's emotional state from textual clues.

## PREREQ_BEFORE
Student must know the poem's basic plot (speaker separated from beloved, sees beautiful nature, feels intensified pain, experiences sleepless night) and the definitions of irony and symbolism from Class 11.

## PREREQ_STUCK
If stuck, review Class 11 node c11_hin_ar_cbse_01_009 for device definitions and practice identifying them in the simpler poem "Megh Aaye" from that chapter.

## WORKED_EXAMPLE_1
PROBLEM: Analyze how situational irony functions in the first two lines of "Varjak" (cgqr fnuku dks vofèk vklikl ijs / [kjs vjcjfu Hkjs gSa mfB tku dks) to establish the poem's central conflict.

STEPS:
- Step 1: Identify the literal scene — "many days have passed, gardens are blooming, cool breezes blow" — a description of spring beauty and pleasant weather.
- Step 2: Identify the speaker's context from the poem's background — the speaker is separated from the beloved (लकुटक), living in exile/sorrow.
- Step 3: Compare the two — the external world is in full celebratory bloom (expectation: joy, union), but the speaker's internal state is grief and longing (reality: pain, separation). This mismatch is situational irony.
- Step 4: Explain the effect — the irony doesn't just decorate; it makes the separation palpable. The universe's indifference (nature blooms regardless) amplifies the speaker's isolation.
- Step 5: Link to theme — this irony establishes the core theme: love's suffering is intensified by a world that refuses to acknowledge it. The beauty becomes a torment.

REASONING: Situational irony works by structural contrast, not wordplay. The steps move from literal reading to contextual knowledge to comparative analysis to thematic synthesis — the exact chain board examiners reward.

ANSWER: In the opening lines, Keshavdas presents a vibrant spring scene (gardens blooming, cool breezes) that conventionally signifies joy and romantic union. However, the speaker — a separated lover — experiences this beauty as torture because the beloved is absent. This situational irony (expectation of happiness vs reality of sorrow) establishes the poem's central conflict: the cruel indifference of nature to human grief. The blooming garden doesn't comfort; it accuses. This irony sets the emotional tone for the entire poem.

## WORKED_EXAMPLE_2
PROBLEM: Identify and analyze the symbolism of "घनघोर घटा" (dense thunderclouds) in the second stanza, explaining how it functions as a symbol rather than mere imagery.

STEPS:
- Step 1: Locate the phrase in context — second stanza, line describing the night: "tku ?kuvkuan ;ksa eks¯g rqEgS iSt ijh ------ dcgw¡ rkS esfj;S iqdkj dku [kksfy gS" — the thunderclouds appear during the sleepless night of longing.
- Step 2: List literal attributes — dark, heavy, turbulent, obscuring vision, preceding storm, associated with monsoon intensity.
- Step 3: Map attributes to speaker's state — darkness = despair/ignorance; heaviness = emotional burden; turbulence = inner chaos; obscuring = inability to see hope/clarity; storm = impending emotional breakdown.
- Step 4: Verify symbolic function — the clouds are not just weather because they appear precisely when the speaker says "vc u f?kjr ?ku vkuan funku dks" (now sleep doesn't come, the mind is restless). The juxtaposition anchors the symbol.
- Step 5: Distinguish from imagery — imagery would be "the clouds looked dark and heavy" (sensory). Symbolism is "the clouds ARE my grief made visible" (representational). The poem uses them representationally.

REASONING: Symbolism requires a stable cultural/psychological association (darkness ↔ despair) activated by contextual placement. The steps enforce this distinction, preventing the common error of labeling all description as symbolism.

ANSWER: "घनघोर घटा" (dense thunderclouds) symbolizes the speaker's overwhelming grief and mental turbulence. Its darkness mirrors the "काली रात" of despair; its heaviness reflects the weight of unfulfilled longing; its turbulence enacts the speaker's restless mind ("vc u f?kjr ?ku vkuan funku dks"). Unlike mere imagery (which would only paint a picture), this symbol externalizes the internal — the clouds become an objective correlative for subjective anguish. The symbol deepens the theme by making abstract emotion tangible and universal.

## WORKED_EXAMPLE_3
PROBLEM: Write a complete PEEL paragraph analyzing how verbal irony in the line "pkgr pyu ;s lanslks ys lqtku dks" (teach this parrot to say 'beloved') interacts with the symbol of the parrot to reveal the speaker's psychological state.

STEPS:
- Step 1: Point — The line uses verbal irony (speaker says one thing, means another) combined with the parrot as a symbol of mechanical, hollow repetition of love.
- Step 2: Evidence — "pkgr pyu ;s lanslks ys lqtku dks" — the speaker sarcastically suggests teaching a parrot to say "लकुटक" (beloved), implying the word has lost meaning through empty repetition.
- Step 3: Explanation (verbal irony) — Literally, the speaker proposes a trivial task; actually, they mock the futility of naming the beloved when the beloved is absent. The irony exposes the gap between language and experience.
- Step 4: Explanation (symbolism) — The parrot symbolizes mindless mimicry — it can say "beloved" without feeling love. This mirrors how the speaker feels: surrounded by empty words/rituals of love while real love is gone.
- Step 5: Synthesis — The verbal irony and symbolism fuse: the parrot's mechanical "लकुटक" is the ironic proof that the word has become a hollow sound. The speaker's sarcasm is a defense against this hollowness.
- Step 6: Link to theme — This reveals the psychological core: love reduced to a syllable, the speaker's grief alienated from language itself. The theme of separation extends beyond physical absence to semantic emptiness.

REASONING: This example combines two devices (verbal irony + symbolism) in one line, requiring multi-layered analysis — a high-order skill for board 5-mark questions and CUET critical appreciation.

ANSWER: In "pkgr pyu ;s lanslks ys lqtku dks," Keshavdas employs verbal irony: the speaker mockingly suggests teaching a parrot to utter "लकुटक," but the real meaning is the bitter futility of naming the absent beloved. This irony fuses with the parrot's symbolism — the bird represents mechanical, emotionless repetition, mimicking love's language without its substance. The parrot's hollow "लकुटक" becomes an ironic mirror of the speaker's own condition: surrounded by the word "beloved" but devoid of the beloved. The device pairing exposes a deeper tragedy — separation has drained language of meaning. The theme of separation thus expands from physical distance to existential silence.

## COMPETENCY_QUESTION_1
QUESTION: In "Varjak," the poet uses the blooming garden (stanza 1) and the thunderclouds (stanza 2) as contrasting symbols. Explain how this contrast structures the poem's emotional movement from external torment to internal immersion. Support your answer with two specific textual references.

COMPETENCY: Literary Analysis – Synthesis of Symbolic Contrast

STEPS:
- Step 1: Identify the two symbolic clusters — garden/breeze (stanza 1) vs night/clouds (stanza 2).
- Step 2: Analyze the first cluster's symbolic valence — beauty, life, openness, day — but experienced as irony (torment).
- Step 3: Analyze the second cluster's symbolic valence — darkness, weight, enclosure, night — experienced as direct embodiment of grief.
- Step 4: Trace the movement — the poem shifts from "world hurts me" (external irony) to "I am the storm" (internal symbolism).
- Step 5: Cite evidence — "dfg dfg vkou Nchys euHkkou dks" (gentle breezes caress the body) vs "tku ?kuvkuan ;ksa eks¯g rqEgS iSt ijh" (sleep doesn't come, the mind is restless).

ANSWER: The poem moves through a symbolic arc: Stanza 1's garden and breeze (symbols of vitality and union) become instruments of torture through situational irony — their beauty "caresses the body" (dfg dfg vkou Nchys euHkkou dks) but cannot reach the grieving heart. Stanza 2 replaces external symbols with internal ones: the "काली रात" and "घनघोर घटा" are not ironic contrasts; they *are* the speaker's grief made visible. The emotional movement is from alienation (world's beauty mocks me) to immersion (I become the darkness). The shift is marked by the transition from sensory description (stanza 1) to psychological confession (stanza 2: "vc u f?kjr ?ku vkuan funku dks"). This structural contrast — ironic symbol → embodied symbol — maps the lover's journey from resistance to surrender to sorrow.

DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: A critic argues: "Keshavdas's 'Varjak' uses irony only as ornamentation; the poem's power comes entirely from its musicality in Braj Bhasha." Refute or defend this claim using evidence of how irony and symbolism functionally construct the poem's meaning, not just decorate it.

COMPETENCY: Critical Evaluation – Argumentation with Textual Evidence

STEPS:
- Step 2: Identify the claim's two parts — (a) irony is decorative, (b) musicality is the sole source of power.
- Step 3: Refute (a) by showing irony's structural role — the opening irony (garden vs grief) establishes the central conflict; the verbal irony (parrot line) reveals semantic collapse. Without irony, the poem becomes a mere lament, not a dramatic tension.
- Step 4: Refute (b) by showing symbolism's semantic role — the thunderclouds don't just sound musical; they *mean* grief. The symbol carries the poem's psychological weight.
- Step 5: Acknowledge musicality's role — Braj Bhasha's phonetics (e.g., alliteration in "vkou Nchys") enhance the devices but don't replace them.
- Step 6: Conclude — irony and symbolism are meaning-making architecture; musicality is the vehicle. The claim confuses vehicle with architecture.

ANSWER: The claim is untenable. Irony in "Varjak" is not ornamental — it is the poem's structural spine. The opening situational irony (spring beauty vs separation pain) creates the central tension that drives the entire lyric. The verbal irony in "pkgr pyu ;s lanslks ys lqtku dks" performs the crucial work of exposing language's failure to capture love-in-absence. Symbolism, likewise, does semantic heavy lifting: "घनघोर घटा" is not a decorative image; it is the objective correlative of the speaker's overwhelming grief, without which the final stanza's emotional climax ("iqdkj dku [kksfy gS" — the pain of separation is unbearable) would lack foundation. Braj Bhasha's musicality (e.g., the rhythmic "dfg dfg vkou") *amplifies* these devices — the soft consonants mimic the breeze's caress, the heavy consonants in "घनघोर घटा" enact the cloud's weight — but musicality without the devices would be empty sound. The devices construct the meaning; the music delivers it.

DIFFICULTY: hard