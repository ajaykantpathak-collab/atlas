## DEFINITION
Vocabulary in Context refers to the skill of determining the precise meaning, connotation, and emotional weight of specific words as they are used within a particular literary text, rather than relying solely on dictionary definitions. It involves analyzing how a word's meaning is shaped by surrounding imagery, tone, syntax, and the poem's overarching themes.

## COGNITIVE_LEVEL
understand

## MASTERY_CRITERIA
The student can independently identify key vocabulary from the poem, explain the contextual meaning of each word with textual evidence, and articulate how the poet's word choices reinforce the central themes of social inequality and false consciousness.

## SCOPE_BOUNDARY
This node covers the eight key words listed in the NCERT 'kCn&Nfo' section for the poem "lk;s esa /wi" (e;Llj, nj[r, eqrebu, csdjkj, fu”kke, ,gfr;kr, cgj, vlj). It does not cover general vocabulary building strategies, etymology, or words outside this specific poem.

## WALKTHROUGH
Imagine you are reading Nagarjun's poem and stumble on the word "eqrebu" in the line "os eqrebu gSa fd iRFkj fi?ky ugha ldrk". You might know its dictionary meaning 'blind faith', but why does the poet choose this specific word over 'andhvishwasi'? Start by reading the stanza aloud, noticing the rhythm. Then, underline the target word and the two lines before and after it. Ask: What image is being painted here? The preceding lines describe people rushing to fill their stomachs, ignoring the temple's darkness. The word "eqrebu" thus carries a tone of tragic irony — their faith is not just blind, but actively blinding them to their own exploitation. Finally, connect this to the poem's critique of how religion pacifies the hungry masses. This process — locate, contextualize, interpret, connect — is the core of vocabulary in context.

## DIAGNOSTIC_QUESTION_1
What is the primary difference between a dictionary definition of a word and its contextual meaning in a poem?

## DIAGNOSTIC_ANSWER_1
A dictionary definition provides a fixed, decontextualized meaning, while contextual meaning in a poem is fluid, shaped by imagery, tone, syntax, and thematic purpose. A wrong answer (e.g., "they are the same") reveals the student treats vocabulary as static memorization rather than dynamic interpretation, missing how poets deliberately stretch words to create layered effects.

## DIAGNOSTIC_QUESTION_2
In the poem, the word "nj[r" (darkness) appears in the line "pyks ;gk¡ ls pysa vkSj mez Hkj osQ fy,". Explain why the poet uses "nj[r" instead of a more common word like "andhera" in this specific context.

## DIAGNOSTIC_ANSWER_2
"nj[r" (from Sanskrit 'andhakara') carries a heavier, more classical and oppressive connotation than the colloquial "andhera". It evokes a primordial, suffocating darkness that mirrors the systemic oppression of the poor, not just physical absence of light. A wrong answer focusing only on synonyms shows the student ignores register, etymology, and the poem's elevated, almost mythic tone in portraying social injustice.

## DIAGNOSTIC_QUESTION_3
Apply the context-clue strategy to determine the meaning of "csdjkj" in the line "u gks deh”k rks ik¡oksa ls isV <¡d ysaxs] ;s yksx fdrus equkflc gSa bl lI+kQj osQ fy, [kqnk ugha] u lgh] vkneh dk [okc lgh dksbZ glhu u”kkjk rks gS u”kj osQ fy, rsjk fu”kke gS fly ns ”kqcku 'kk;j dh". Write the steps you would take.

## DIAGNOSTIC_ANSWER_3
Steps: 1) Locate "csdjkj" — it appears in the vocabulary list as meaning 'छोटा/तुच्छ' (small/trivial). 2) Examine the stanza: the poet contrasts the massive systemic injustice ("vkneh dk [okc") with the people's trivial pursuit ("csdjkj") of filling stomachs. 3) Note the syntactic parallel: "[kqnk ugha] u lgh] vkneh dk [okc lgh" sets up a scale of moral weight; "csdjkj" is the antonym of this gravity. 4) Conclude: here, "csdjkj" means 'morally insignificant' or 'petty survivalism', not just 'small'. A wrong answer giving only 'small' reveals failure to trace the semantic shift caused by the stanza's argumentative structure.

## DIAGNOSTIC_QUESTION_4
Compare the words "fu”kke" (power/rule) and ",gfr;kr" (welfare) in the last two lines. How does their juxtaposition expose the poem's central irony?

## DIAGNOSTIC_ANSWER_4
"fu”kke" implies coercive, top-down authority ("jkt], 'kklu"), while ",gfr;kr" suggests organic, bottom-up well-being ("lko/kuh"). The poet places them in consecutive lines — "rsjk fu”kke gS fly ns ”kqcku 'kk;j dh] ;s ,gfr;kr ”k:jh gS bl cgj osQ fy," — to show that the state's power serves the elite's comfort ("fly ns ”kqcku"), while true welfare for the city ("cgj") remains a hollow slogan. A wrong answer treating them as unrelated concepts misses the structural critique: power masquerading as welfare.

## DIAGNOSTIC_QUESTION_5
Evaluate the claim: "The vocabulary list in the textbook (e;Llj, nj[r, eqrebu, csdjkj, fu”kke, ,gfr;kr, cgj, vlj) is sufficient for a complete understanding of the poem's language." Defend your position.

## DIAGNOSTIC_ANSWER_5
The claim is false. The list covers only isolated lexical items, ignoring collocations (e.g., "fpjkx 'kCn"), syntactic inversions ("dgk¡ rks r; Fkk"), and the semantic fields created by repetition ("xqyeksgj" appears in the exercise but not the list). A student who memorizes only these eight words will miss how "vlj" (effect) in the last line resonates with "Hkko" (impact) in the preface, creating a frame of cause-and-effect. A wrong answer agreeing reveals over-reliance on textbook aids rather than independent textual engagement.

## DIAGNOSTIC_QUESTION_6
Create a two-line couplet (dohe) using at least three words from the vocabulary list (e;Llj, nj[r, eqrebu, csdjkj, fu”kke, ,gfr;kr, cgj, vlj) that captures the poem's theme of false consciousness. Provide the Hindi lines and a one-sentence explanation of your word choices.

## DIAGNOSTIC_ANSWER_6
Example: "e;Llj dh chhaya mein nj[r phelai, eqrebu janata csdjkj sukhai / fu”kke kare ,gfr;kr ki baat, cgj mein vlj dikhai." Explanation: I placed "e;Llj" and "nj[r" together to show the temple as the source of darkness, "eqrebu" and "csdjkj" to link blind faith with trivialized existence, and "fu”kke", ",gfr;kr", "cgj", "vlj" to condense the poem's political irony into the city space. A poor answer using words randomly without thematic cohesion shows the student cannot synthesize vocabulary into a coherent interpretive stance.

## COMMON_MISCONCEPTION
Students often believe that 'vocabulary in context' means simply replacing the poetic word with a Hindi synonym from the textbook's 'kCn&Nfo' box (e.g., writing "e;Llj = miyC/" and moving on). They miss that Nagarjun uses "e;Llj" not just as 'temple' but as a metonym for institutional religion that legitimizes exploitation — the word acquires a sarcastic charge when juxtaposed with "fpjkx" (hut) in the first line. This error stems from treating the vocabulary list as an answer key rather than a starting probe, and from not reading the poem as an argument where each word does rhetorical work.

## ON_FAILURE
1. Return to the poem and read only the lines containing the target word, ignoring the vocabulary box entirely. 2. Write a paraphrase of that stanza in your own simple Hindi without using the target word. 3. Compare your paraphrase with the textbook gloss — note where your version captures the emotion and where it falls flat. 4. Re-read the preface (page 131) where Nagarjun explains his intent: "jktuhfr vkSj lekt esa tks oqQN py jgk gS, mls [kkfjt djus vkSj fodYi dh ryk'k dks ekU;rk nsus dk Hkko". 5. Ask: How does this specific word serve that purpose? This forces the student to derive meaning from function, not from a list.

## BUILDS_ON
This node builds on the student's ability to identify imagery and metaphor (c11_hin_ar_cbse_13_008), as key vocabulary in this poem functions primarily through metaphorical extension.

## LEADS_TO
This node enables Grammar: Language Usage in the Text (c11_hin_ar_cbse_13_011), where students analyze how these same words operate syntactically and morphologically.

## PREREQUISITE_NODE_IDS
c11_hin_ar_cbse_13_001, c11_hin_ar_cbse_13_002, c11_hin_ar_cbse_13_008, c11_hin_ar_cbse_13_009

## PREREQUISITE_REASONS
c11_hin_ar_cbse_13_001: Provides the socio-historical context (Nagarjun's Marxist leanings, Emergency background) essential to decode words like 'fu”kke' and ',gfr;kr' as political terms.
c11_hin_ar_cbse_13_002: Establishes the narrative movement from temple to city, which structures the semantic journey of words like 'e;Llj' → 'cgj'.
c11_hin_ar_cbse_13_008: Trains the student to spot metaphorical extensions (e.g., 'nj[r' as moral blindness), which is the core mechanism of this poem's vocabulary.
c11_hin_ar_cbse_13_009: Key vocabulary (e.g., "fu”kke", " ,gfr;kr", "equkflc") acquires its full force only when understood as parts of the ironic/symbolic structure.  

## FORWARD_NODE_IDS
c11_hin_ar_cbse_13_011, c11_hin_ar_cbse_13_012, c11_hin_ar_cbse_13_013, c11_hin_ar_cbse_13_014, c12_hin_a_cbse_07_010, c12_hin_a_cbse_13_010, c12_hin_ar_cbse_12_010, c12_hin_ar_cbse_13_010

## FORWARD_REASONS
c11_hin_ar_cbse_13_011: Grammatical analysis (e.g., 'eqrebu' as adjective vs noun) requires prior semantic clarity from this node.
c11_hin_ar_cbse_13_012: Literal and inferential comprehension questions directly test contextual vocabulary (e.g., "What does 'csdjkj' reveal about the poet's attitude?").
c11_hin_ar_cbse_13_013: Critical interpretation of themes like 'false consciousness' is built on precise understanding of words like 'eqrebu' and 'vlj'.
c11_hin_ar_cbse_13_014: Writing tasks (e.g., analytical paragraph) demand the ability to embed and explain key vocabulary as textual evidence.
c12_hin_a_cbse_07_010: Evaluated peer translations for loss of cultural nuance.  
c12_hin_a_cbse_13_010: Class 11 vocabulary-in-context practice builds foundational skill.  
c12_hin_ar_cbse_12_010: Extended to comparative vocabulary across texts — forward link.  
c12_hin_ar_cbse_13_010: Direct prior practice of the same strategy on Class 11 texts.  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
none

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_13_001 -> c11_hin_ar_cbse_13_010 -> c11_hin_ar_cbse_13_011

## THIS_FORMULA
N/A - conceptual

## FORMULA_VARIABLES
N/A

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
linguistic

## CROSS_SUBJECT
c11_history_social_inequality | The poem's vocabulary (fu”kke, ,gfr;kr, cgj) directly maps to historical concepts of state power vs. popular welfare during the Emergency era, enabling interdisciplinary analysis of literature as historical testimony.
c11_economics_poverty | Words like 'csdjkj' (trivial survival) and 'vlj' (impact) operationalize economic concepts of subsistence living and policy failure, allowing students to see poetic language as economic critique.
c11_civics_social_justice | The pairing 'eqrebu' (blind faith) and 'nj[r' (darkness) illustrates the civics concept of 'false consciousness' — how ideology obscures structural injustice — making abstract political theory concrete through textual evidence.

## PREREQ_CONCEPT
Ability to distinguish between denotation (literal meaning) and connotation (associated feeling/implication) in poetic language.

## PREREQ_BEFORE
Student must have read the poem "lk;s esa /wi" at least twice — once for gist, once marking every unfamiliar word — and completed the 'Before You Read' context activity.

## PREREQ_STUCK
If stuck, review the concept of 'metaphorical extension' from c11_hin_ar_cbse_13_008 using the example of 'xqyeksgj' (exploitation) in the exercise questions.

## WORKED_EXAMPLE_1
PROBLEM: Analyze how the word "e;Llj" (temple) functions differently in the first line ("dgk¡ rks r; Fkk fpjkxk¡ gjsoQ ?kj osQ fy,") versus its implied presence in the vocabulary list, and what this shift reveals about the poem's attitude toward religion.

STEPS:
- Step 1: Locate the word "e;Llj" — it appears explicitly only in the vocabulary list, not in the poem's text. The poem opens with "fpjkxk¡ gjsoQ ?kj osQ fy," (huts for the poor) and later "dgk¡ fpjkx e;Llj ugha 'kgj osQ fy," (where the temple is not for the poor but for the city). Note the absence/presence pattern.
- Step 2: Identify the concept — this is 'strategic omission'. The poet denies the poor their temple in the narrative space, forcing the reader to feel the exclusion before the word "e;Llj" is even introduced in the glossary.
- Step 3: Apply to context — the vocabulary list defines "e;Llj = miyC/" (temple), but the poem's syntax "fpjkx e;Llj ugha" (temple not for huts) turns the word into a symbol of institutional betrayal. The dictionary meaning is neutral; the contextual meaning is accusatory.
- Step 4: Analyze the shift — the glossary entry comes after the poem, mimicking how the poor encounter religion: first as lived exclusion ("fpjkx e;Llj ugha"), then as a defined concept ("e;Llj = miyC/"). The gap between experience and label is the poem's critique.
- Step 5: Verify with theme — connect to Nagarjun's stated aim (preface): "jktuhfr vkSj lekt esa tks oqQN py jgk gS, mls [kkfjt djus". The word "e;Llj" performs this pacification by naming the very institution that excludes.

REASONING: This example demonstrates that vocabulary in context is not about matching word-to-definition, but about tracing how a word's meaning is constructed by its textual environment, structural position, and thematic burden.

ANSWER: "e;Llj" shifts from a neutral dictionary entry (miyC/) to a charged symbol of systemic exclusion because the poem first shows its denial to the poor ("fpjkx e;Llj ugha") and only later labels it. This structural irony enacts the poem's theme: religion as a tool that names comfort while delivering deprivation.

## WORKED_EXAMPLE_2
PROBLEM: The vocabulary list gives "vlj = izHkko" (effect/impact). In the final line "rsjk fu”kke gS fly ns ”kqcku 'kk;j dh] ;s ,gfr;kr ”k:jh gS bl cgj osQ fy,", explain how "vlj" (though not explicitly in this line) operates as the unseen grammatical and thematic link between "fu”kke" and ",gfr;kr".

STEPS:
- Step 1: Recall the vocabulary list: "vlj & izHkko". Note that "vlj" does not appear in the poem's text but is provided as a key word for the poem's overall effect.
- Step 2: Identify the syntactic gap — the last two lines present a cause ("fu”kke") and a claimed effect (",gfr;kr") without a connecting verb. The missing link is precisely "vlj" (impact/consequence).
- Step 3: Apply grammatical knowledge — "fu”kke" is the subject, ",gfr;kr" is the predicate nominative, but the copula "gS" (is) creates a false equivalence. The real "vlj" of "fu”kke" is "fly ns ”kqcku 'kk;j" (comfort of the elite), not ",gfr;kr".
- Step 4: Analyze the irony — the vocabulary list includes "vlj" to prompt the student to ask: "What is the actual *vlj* of this *fu”kke*?" The answer lies in the contrast between the claimed welfare and the described reality.
- Step 5: Connect to central idea — this mirrors the poem's structure: the poor are told the temple (e;Llj) is for welfare (,gfr;kr), but its actual impact (vlj) is darkness (nj[r). The absent word "vlj" haunts the poem as the suppressed truth.

REASONING: This example shows how a vocabulary word can be 'absent but governing' — the textbook includes it to train students to detect the causal logic the poem deliberately obscures.

ANSWER: "vlj" functions as the poem's hidden analytical key: it exposes the false equation "fu”kke = ,gfr;kr" by demanding evidence of actual impact, which the poem provides in the preceding stanzas (hunger, darkness, blind faith). The vocabulary list's inclusion of "vlj" is a pedagogical nudge toward this detection.

## WORKED_EXAMPLE_3
PROBLEM: Synthesize the words "eqrebu" (blind faith), "csdjkj" (trivial/petty), and "nj[r" (darkness) to construct a coherent explanation of how the poem portrays the internalization of oppression by the poor. Use the 'Point-Evidence-Explanation-Link' (PEEL) structure.

STEPS:
- Step 1 (Point): The poem argues that the poor are complicit in their own oppression through internalized false consciousness, encoded in the triad "eqrebu", "csdjkj", "nj[r".
- Step 2 (Evidence): Locate each word's context: "eqrebu" in "os eqrebu gSa fd iRFkj fi?ky ugha ldrk" (they are such blind believers that they cannot see the immediate); "csdjkj" in ";s yksx fdrus equkflc gSa bl lI+kQj osQ fy, [kqnk ugha] u lgh] vkneh dk [okc lgh dksbZ glhu u”kkjk rks gS u”kj osQ fy," (how petty these people are... no right, no wrong... some trivial stomach-filling); "nj[r" in "pyks ;gk¡ ls pysa vkSj mez Hkj osQ fy," (darkness resides here, leave and go fill stomachs).
- Step 3 (Explanation): "eqrebu" shows the cognitive block — faith replaces critical sight. "csdjkj" shows the moral reduction — justice shrinks to biological survival. "nj[r" shows the environmental totality — the temple, the city, the system all radiate darkness. Together, they form a closed loop: faith (eqrebu) blinds them to injustice (nj[r), reducing their horizon to petty survival (csdjkj).
- Step 4 (Link): This loop is exactly what Nagarjun calls "jktuhfr vkSj lekt esa tks oqQN py jgk gS, mls [kkfjt djus" — the vocabulary trio maps the mechanism of pacification.
- Step 5 (Synthesize): The progression eqrebu → nj[r → csdjkj mirrors the poem's movement from temple (stanza 1) to city (stanza 3), showing false consciousness as a spatial and temporal process, not a static condition.
- Step 6 (Verify): Check against the exercise question 1: "vkf[kjh 'ksj esa xqyeksgj dh ppkZ gqbZ gSA D;k mldk vk'k; ,d [kkl rjg osQ iQwynkj o`{k ls gS ;k mlesa dksbZ lkaosQfrd vFkZ fufgr gS\" — our analysis answers this by showing the 'grief' (ppkZ) is structural (lkaosQfrd), enacted through these words.

REASONING: This multi-word synthesis is the highest level of vocabulary-in-context work: it requires tracking semantic fields across stanzas, mapping them to thematic architecture, and using them as evidence for interpretation.

ANSWER: The triad "eqrebu–nj[r–csdjkj" forms the poem's anatomy of internalized oppression: blind faith (eqrebu) creates the epistemological darkness (nj[r) that morally miniaturizes the poor (csdjkj), turning revolutionary potential into mere stomach-filling. This is not individual failing but systemic design, as the vocabulary's distribution across stanzas proves.

## COMPETENCY_QUESTION_1
QUESTION: A student writes in an exam: "In the poem, 'nj[r' means darkness and 'eqrebu' means blind faith. The poet uses them to show the poor are ignorant." Using the concept of vocabulary in context, explain why this answer would receive partial marks at best, and rewrite it to meet Class 11 board standards.

COMPETENCY: Critical analysis of peer response / Answer improvement using textual evidence and conceptual precision.

STEPS:
- Step 1: Identify the flaw — the answer treats words as static labels ('means') and reduces a systemic critique to individual ignorance ('poor are ignorant').
- Step 2: Retrieve contextual nuances — "nj[r" is not just darkness but the poem's atmosphere (stanza 1: "pyks ;gk¡ ls pysa"); "eqrebu" is not just belief but a crippling condition ("iRFkj fi?ky ugha ldrk").
- Step 3: Apply PEEL structure — Point: The poet uses "nj[r" and "eqrebu" to expose structural false consciousness, not individual ignorance. Evidence: "nj[r" frames the temple space; "eqrebu" explains the poor's inability to perceive "vkneh dk [okc". Explanation: The syntax "os eqrebu gSa fd..." presents it as a systemic descriptor, not a personal flaw. Link: This serves Nagarjun's aim to "fodYi dh ryk'k dks ekU;rk nsus".
- Step 4: Write the improved answer incorporating the above.

ANSWER: The original answer fails because it (a) substitutes dictionary glosses for contextual analysis, and (b) misreads the poem's political stance by blaming the victims. Improved answer: "Nagarjun deploys 'nj[r' (primordial, oppressive darkness) as the poem's prevailing atmosphere — 'pyks ;gk¡ ls pysa' — and 'eqrebu' (blind faith that paralyzes perception — 'iRFkj fi?ky ugha ldrk') as the mechanism by which the poor are rendered incapable of recognizing 'vkneh dk [okc' (the voice of injustice). Together, they diagnose false consciousness as a socially produced condition, not an innate ignorance, fulfilling the poet's stated aim to expose how power 'fodYi dh ryk'k dks ekU;rk nsus'."

DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: The vocabulary list includes "cgj" (city/nagar) and "fu”kke" (power/rule). The poem's final line reads: "rsjk fu”kke gS fly ns ”kqcku 'kk;j dh] ;s ,gfr;kr ”k:jh gS bl cgj osQ fy,". Design a board-exam style 3-mark question that tests a student's ability to analyze the relationship between these two words in this specific context, and provide the marking scheme.

COMPETENCY: Question design / Assessment literacy / Synthesis of vocabulary and theme.

STEPS:
- Step 1: Determine the target skill — analyzing how lexical choice encodes power dynamics in the poem's closing irony.
- Step 2: Draft the question — "How does the juxtaposition of 'fu”kke' and 'cgj' in the final line reveal the poem's critique of the state? Support your answer with two specific textual references from the poem." (3 marks)
- Step 3: Define marking scheme — 1 mark for identifying the semantic contrast (coercive power vs. civic space); 1 mark for citing evidence (e.g., "fly ns ”kqcku 'kk;j" vs. ",gfr;kr ”k:jh"); 1 mark for linking to the central theme (welfare as slogan, power as reality).
- Step 4: Anticipate common errors — students may define words separately without connecting them; or quote the preface instead of the poem.
- Step 5: Refine the question to ensure it cannot be answered by rote memorization of the vocabulary box.

ANSWER: Question: "How does the juxtaposition of 'fu”kke' and 'cgj' in the final line reveal the poem's critique of the state? Support your answer with two specific textual references from the poem." (3 marks) Marking Scheme: (1) Identifies that 'fu”kke' (coercive authority) serves the elite's comfort ('fly ns ”kqcku 'kk;j') while 'cgj' (the polity) is falsely promised welfare (',gfr;kr ”k:jh'). (2) Cites two textual anchors: e.g., the contrast between 'fu”kke gS fly ns ”kqcku 'kk;j dh' and ',gfr;kr ”k:jh gS bl cgj osQ fy', AND the earlier imagery of 'fpjkx e;Llj ugha 'kgj osQ fy' showing the city's exclusionary design. (3) Concludes that the vocabulary pair exposes the state's dual face: power for the few, slogans for the many.

DIFFICULTY: hard