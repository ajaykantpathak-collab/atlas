## DEFINITION
Character analysis of the protagonist involves examining the central character's traits, motivations, conflicts, and development through their actions, speech, thoughts, relationships, and the author's direct commentary to understand their role in advancing the story's themes.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student can write a structured 150-200 word character sketch of the protagonist (the old man/poet) using the PEEL method: Point-Evidence-Explanation-Link, citing at least three textual instances that reveal his personality, values, and thematic significance.

## SCOPE_BOUNDARY
This node covers deep character analysis of the protagonist (the old man revealed as a poet) in "तेंदुए का इस्माइल" including his dual identity, moral courage, and symbolic function. It does NOT cover supporting characters (node 005) or plot summary (node 002).

## WALKTHROUGH
Imagine you meet someone who looks like a helpless old beggar under a tree, but later discover he's actually a celebrated poet whose words challenge government authority. That's the protagonist of this story. Begin by asking: "What does the author show us about this man before the big reveal?" Look for his silence when officials debate cutting the tree, his calm dignity when facing death, and his final act of protecting the cub at personal risk. Notice how his identity as a poet (dfo) explains his behavior - he observes, endures, and ultimately acts on conscience rather than fear. The key insight: the protagonist isn't just a character; he's the story's moral compass contrasting bureaucratic cruelty with human compassion.

## DIAGNOSTIC_QUESTION_1
Who is the protagonist of "तेंदुए का इस्माइल" and what is his true identity revealed at the end of the story?

## DIAGNOSTIC_ANSWER_1
The protagonist is the old man (नंगा बूढ़ा नेह) living under the tree, who is revealed to be a poet (कवि) when the Range Officer recognizes him as the author of "वस्ल का इमला" - a famous poem. A wrong answer (e.g., identifying the mother leopard or the Range Officer as protagonist) reveals the student cannot distinguish between catalyst characters and the central consciousness through whom the story's moral conflict unfolds.

## DIAGNOSTIC_QUESTION_2
Why does the old man remain silent throughout most of the officials' debate about cutting down the tree, and what does this silence reveal about his character?

## DIAGNOSTIC_ANSWER_2
His silence reflects helplessness against bureaucratic machinery and a poet's observational nature - he witnesses injustice but lacks institutional power to stop it. This silence breaks only when he acts to save the cub, showing moral courage transcends his apparent powerlessness. A wrong answer (e.g., "he was scared" or "he didn't understand") reveals the student mistakes passive silence for passive character, missing the distinction between structural powerlessness and moral agency.

## DIAGNOSTIC_QUESTION_3
Identify three specific textual moments where the protagonist's actions reveal his core values, and explain what each moment shows about his character.

## DIAGNOSTIC_ANSWER_3
1) Refusing to leave the tree despite death threat - values principle over survival. 2) Accepting death calmly ("मैं अभी ठहरा हूँ") - shows dignity and fearlessness. 3) Protecting the cub even when ordered to step aside - demonstrates compassion transcending self-preservation. A wrong answer listing generic traits without textual evidence reveals the student cannot ground analysis in the text, a critical board exam skill.

## DIAGNOSTIC_QUESTION_4
Compare the protagonist's response to the bureaucratic system with the responses of the Range Officer (रेंज ऑफिसर) and the DFO (डीएफओ). What does this contrast reveal about the story's central conflict?

## DIAGNOSTIC_ANSWER_4
The protagonist embodies human conscience and artistic integrity - he resists non-violently but firmly. The Range Officer represents mindless rule-following ("आदेश है काटने का"). The DFO represents pragmatic compromise ("हम यहाँ तक कर सकते हैं"). This three-way contrast structures the story's conflict: bureaucracy vs. humanity, with the poet as the moral anchor. A wrong answer treating all three as similar "authority figures" reveals inability to analyze character as thematic device.

## DIAGNOSTIC_QUESTION_5
Evaluate the statement: "The protagonist's identity as a poet is merely a plot twist; it doesn't fundamentally change our understanding of his actions throughout the story." Defend your position with textual evidence.

## DIAGNOSTIC_ANSWER_5
The statement is false. His poet identity retroactively illuminates his silence (observation), his fearlessness (truth-teller's courage), and his final act (protecting the vulnerable like poetry protects truth). The Range Officer's reaction - "बहुत बड़ा कवि" - and the order to spare the tree because "यह इस्माइल के नीचे का पेड़ है" confirm his identity transforms the situation. A wrong answer agreeing reveals the student treats character revelation as plot device rather than thematic key.

## DIAGNOSTIC_QUESTION_6
Write a 100-word diary entry from the protagonist's perspective on the night before the tree-cutting, capturing his inner conflict between fear for his life and resolve to protect the cub.

## DIAGNOSTIC_ANSWER_6
A strong entry will show: awareness of mortality ("कल ये पेड़ कटेगा, मैं भी"), poetic observation ("चाँदनी में इस्माइल की आँखें"), moral clarity ("कविता सच बचाती है, मैं भी बचाऊँगा"), and acceptance ("डर नहीं, बस दुख है कि व्यवस्था इतनी अंधी है"). A weak entry focusing only on fear or only on heroism reveals the student cannot synthesize the character's complexity - his simultaneous vulnerability and strength.

## COMMON_MISCONCEPTION
Students often treat the protagonist as a passive victim who "gets saved" by his poet identity revelation. They miss that his moral stance (refusing to move, protecting the cub) PRECEDES and CAUSES the revelation - the Range Officer recognizes him BECAUSE he stood his ground. This reverses cause-effect: his character drives the plot, not the plot twist defining his character. The error stems from reading plot linearly rather than analyzing character as thematic engine.

## ON_FAILURE
If a student makes this error: 1) Have them re-read the scene where the Range Officer arrives - note he says "यह वही 'वस्ल का इमला' वाला कवि है" AFTER the old man refuses to leave. 2) Create a two-column chart: "Actions BEFORE identity reveal" vs "Consequences AFTER reveal." 3) Ask: "Would the officer have recognized him if he'd quietly moved away?" 4) Guide them to write: "His poet identity doesn't save him; his conscience makes him recognizable as a poet."

## BUILDS_ON
This builds on c11_hin_ar_cbse_07_002 (Plot and Narrative Structure) where students learned the sequence of events, enabling them to locate character moments in the narrative arc.

## LEADS_TO
This enables c11_hin_ar_cbse_07_005 (Character Analysis: Supporting Characters) where students apply the same analytical framework to the Range Officer, DFO, and mother leopard as foils to the protagonist.

## PREREQUISITE_NODE_IDS
c11_hin_ar_cbse_07_001, c11_hin_ar_cbse_07_002, c11_hin_ar_cbse_07_003
## PREREQUISITE_REASONS
c11_hin_ar_cbse_07_001: Context about author Ñ'upanj and his experiential writing grounds the protagonist's authenticity as a poet-character.
c11_hin_ar_cbse_07_002: Plot structure knowledge lets students pinpoint the protagonist's entry, conflict moments, and climax.
c11_hin_ar_cbse_07_003: Setting analysis (the tree, the well, the bureaucratic office) establishes the physical and institutional spaces the protagonist navigates.

## FORWARD_NODE_IDS
c11_hin_ar_cbse_07_005, c11_hin_ar_cbse_07_006, c11_hin_ar_cbse_07_013, c11_hin_ar_cbse_07_010, c11_hin_ar_cbse_07_012, c11_hin_ar_cbse_07_014, c12_hin_a_cbse_07_004, c12_hin_a_cbse_07_005, c12_hin_ar_cbse_07_004

## FORWARD_REASONS
c11_hin_ar_cbse_07_005: Protagonist analysis provides the benchmark for analyzing supporting characters as foils/contrasts.
c11_hin_ar_cbse_07_006: The protagonist's values (compassion, integrity, artistic truth) embody the primary theme of humanity vs. bureaucracy.
c11_hin_ar_cbse_07_013: Critical thinking requires a fully analyzed central character to interpret the story's deeper meanings.
c11_hin_ar_cbse_07_010: The old man's character (poverty, dignity, connection to nature) determines the emotional weight of "isM+" and "foyac".  
c11_hin_ar_cbse_07_012: Protagonist analysis (the old poet) supplies character motives needed for inferential questions about his refusal to leave.  
c11_hin_ar_cbse_07_014: Protagonist (माली) analysis provides character-based evidence for answers  
c12_hin_a_cbse_07_004: Supplies the *nayika-bheda* terminology (*virahotkanthita*, *abhisarika*, etc.) needed for precise analysis.  
c12_hin_a_cbse_07_005: Class 11 protagonist analysis practice — needed to avoid conflating the two.  
c12_hin_ar_cbse_07_004: Foundation skill of trait identification + single evidence; Class 12 requires multi-evidence synthesis.  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
none

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_07_002 -> c11_hin_ar_cbse_07_004 -> c11_hin_ar_cbse_07_005

## THIS_FORMULA
N/A - conceptual

## FORMULA_VARIABLES
N/A

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
analytical

## CROSS_SUBJECT
c11_history_colonial_administration | The bureaucratic hierarchy in the story (Range Officer, DFO, Chief Conservator) mirrors colonial forest administration structures that prioritized revenue over ecology and local rights.
c11_civics_citizen_rights | The protagonist's stand represents individual moral resistance against state authority - a civics case study of conscience vs. legal order.

## PREREQ_CONCEPT
Understanding narrative point of view: the story is focalized through the protagonist's consciousness, making his perception the reader's primary lens.

## PREREQ_BEFORE
Student must know the basic plot sequence and be able to identify the old man as the character present from beginning to end.

## PREREQ_STUCK
Review c11_hin_ar_cbse_07_002 for the protagonist's key scenes: introduction under tree, officials' debate, identity revelation, final confrontation.

## WORKED_EXAMPLE_1
PROBLEM: Write a structured character sketch of the protagonist (the old man/poet) using the PEEL method, focusing on his moral courage. Use three textual evidences.

STEPS:
- Step 1: Identify the core trait to analyze - moral courage defined as acting on conscience despite personal risk.
- Step 2: Locate three textual moments: (a) Refusing to leave the tree when ordered, (b) Calm acceptance of death ("मैं अभी ठहरा हूँ"), (c) Shielding the cub with his body at the climax.
- Step 3: For each moment, apply PEEL: Point (trait shown), Evidence (text reference), Explanation (why this shows courage), Link (connect to theme of humanity vs bureaucracy).
- Step 4: Synthesize into a coherent paragraph showing character arc from passive observer to active resister.
- Step 5: Verify the sketch addresses his dual identity (beggar/poet) and explains how the poet identity deepens the courage (truth-teller's role).

REASONING: PEEL ensures each claim is textually grounded. Three evidences meet board exam expectations for "sufficient textual support." The arc structure shows character development, not static trait-listing.

ANSWER: The protagonist embodies moral courage that transcends his apparent powerlessness. Initially, he appears as a helpless old man under the tree, silent while officials debate its felling. His first act of courage is refusal: when ordered to vacate, he stays, risking arrest. The text shows his calm dignity: "मैं अभी ठहरा हूँ" - accepting death without pleading. This silence isn't passivity but witness. His poet identity, revealed when the Range Officer recognizes "वस्ल का इमला," explains this stance: a poet's duty is to truth, not safety. The climax confirms this: he physically shields the cub, telling the officer "यह पेड़ नहीं कटेगा." His courage isn't heroic posturing but quiet insistence on conscience. The bureaucracy (Range Officer, DFO) operates on orders; he operates on morality. His final victory - the tree saved, the cub spared - comes not from power but from moral authority that even the system must acknowledge.

## WORKED_EXAMPLE_2
PROBLEM: Analyze how the author uses the protagonist's physical description to foreshadow his inner strength and poetic identity. Cite four descriptive details.

STEPS:
- Step 1: List all physical descriptions of the old man in the opening scenes: "नंगा बूढ़ा नेह," "पेड़ के नीचे," "मैले-कुचैले कपड़े," "सफेद दाढ़ी," "आँखों में अजीब चमक."
- Step 2: For each detail, infer symbolic meaning: nakedness = vulnerability AND freedom from social masks; tree-shelter = rootedness in nature; ragged clothes = poverty but also rejection of materialism; white beard = age/wisdom; strange glint in eyes = hidden depth/poetic vision.
- Step 3: Connect each to later revelations: the "glint" foreshadows the poet's sharp perception; the tree-shelter foreshadows his defense of it.
- Step 4: Explain the technique: author uses "deceptive frailty" trope - outward weakness masking inner strength, common in Ñ'upanj's experiential realism.
- Step 5: Conclude how this physical portrayal prepares the reader for the identity reveal without making it feel like a cheat.

REASONING: Senior secondary analysis requires moving beyond "what he looks like" to "how description functions narratively." Four details ensure comprehensive coverage. Connecting early description to late revelation demonstrates structural awareness.

ANSWER: The protagonist's physical introduction is a masterclass in deceptive frailty. "नंगा बूढ़ा नेह" (naked old man Neh) establishes vulnerability - he owns nothing, not even clothes - yet "नेह" (affection/warmth) in his name hints at emotional richness. "पेड़ के नीचे" positions him as part of nature, not society, foreshadowing his defense of the tree as extension of self. "मैले-कुचैले कपड़े" and "सफेद दाढ़ी" mark him as discarded by society, yet the beard suggests wisdom earned through time. Most crucially, "आँखों में अजीब चमक" (strange glint in eyes) - this single detail carries the entire foreshadowing: it signals intelligence, observation, and the poet's penetrating gaze that sees through bureaucratic lies. When the Range Officer later recognizes him as the poet of "वस्ल का इमला," the "glint" retroactively becomes the poet's vision. The contrast between ragged exterior and luminous interior mirrors the story's central contrast: bureaucratic ugliness vs. poetic truth. Ñ'upanj's experiential realism (he lived among tribals) makes this description authentic, not symbolic contrivance.

## WORKED_EXAMPLE_3
PROBLEM: The protagonist speaks very little in the story. Analyze how his silence functions as characterization, and how his few spoken lines carry disproportionate thematic weight. Compare with the verbose bureaucrats.

STEPS:
- Step 1: Quantify: count protagonist's spoken lines vs. officials' dialogue. Note he speaks only 3-4 times; officials dominate pages 92-98.
- Step 2: Categorize his silence: (a) Strategic silence during debate (pages 92-93), (b) Silence as witness to injustice, (c) Silence as refusal to legitimize bureaucracy.
- Step 3: Analyze each spoken line: "मैं अभी ठहरा हूँ" (dignity), "यह पेड़ नहीं कटेगा" (moral law), "तुम्हें इस्माइल का वास्ता" (emotional appeal to shared humanity).
- Step 4: Contrast with bureaucratic speech: euphemisms ("आदेश है"), procedural language ("इक़रारनामा"), threats ("काट दिया जाएगा").
- Step 5: Explain the literary effect: silence creates tension; speech releases it with moral authority. The poet's economy of language vs. bureaucracy's verbosity mirrors poetry vs. administration.
- Step 6: Connect to Ñ'upanj's style: he was a poet first - the protagonist's voice IS the author's poetic voice breaking through prose.

REASONING: This combines character analysis with stylistic analysis - a higher-order skill for Class 11. Quantifying dialogue turns subjective impression into analytical evidence. The contrast structure (silence vs. verbosity, poetry vs. bureaucracy) reveals theme through characterization.

ANSWER: The protagonist's silence is his loudest characterization. For 90% of the story, he watches, listens, endures - the poet as witness. His silence during the officials' debate (pages 92-93) isn't absence; it's judgment. He doesn't argue with the Range Officer's "आदेश है" because argument legitimizes the framework. His three spoken lines are surgical: "मैं अभी ठहरा हूँ" asserts existence against erasure. "यह पेड़ नहीं कटेगा" states moral law above administrative order. "तुम्हें इस्माइल का वास्ता" invokes the cub's name (thismail = smile/innocence) as moral witness. Contrast the officials: the Range Officer speaks in threats ("काट दिया जाएगा"), the DFO in procedures ("इक़रारनामा"), the Chief Conservator in politics ("पूर्व सरकार"). Their verbosity masks emptiness; his silence holds truth. This mirrors Ñ'upanj's own journey: poet first, prose writer later. The protagonist's voice IS poetic distillation - maximum meaning, minimum words. When he finally speaks, the narrative pauses. The bureaucrats talk past each other; he talks past them to the reader's conscience.

## COMPETENCY_QUESTION_1
QUESTION: "The protagonist in 'तेंदुए का इस्माइल' is not an individual but a symbol." Evaluate this statement. In your answer, analyze how the protagonist functions both as a credible human character AND as a symbolic figure, using specific textual evidence for both dimensions.

COMPETENCY: Critical analysis of character as both mimetic (realistic) and symbolic

STEPS:
- Step 1: Define the two dimensions: mimetic (believable human with specific traits) vs symbolic (representing abstract ideas).
- Step 2: Identify mimetic evidence: physical frailty, fear of death ("प्राण जाए पर वचन न जाए" internal conflict), personal history as poet, relationship with the cub (emotional, not abstract).
- Step 3: Identify symbolic evidence: name "नेह" (affection/humanity), tree-shelter = nature guardianship, poet identity = truth-teller, final stand = conscience vs state.
- Step 4: Synthesize: the symbolism EMERGES from the mimetic specificity - he's not an allegorical figure (like "Everyman") but a particular man whose particularity MAKES him universal.

ANSWER: The statement is a false dichotomy. The protagonist is a credible individual whose specificity generates symbolic resonance. As a mimetic character: he shivers in cold ("काँपता हुआ"), fears death ("प्राण सूख गए"), remembers his poem's publication history, feels tenderness for the cub ("इस्माइल की आँखें"). These particularities ground him in reality. Simultaneously, he functions symbolically: "नेह" names the human capacity for affection that bureaucracy lacks; his tree-dwelling represents organic belonging vs. institutional displacement; his poet identity embodies art's duty to witness; his final stand with the cub ("तुम्हें इस्माइल का वास्ता") makes him the voice of the voiceless. Crucially, the symbolism doesn't flatten him - it deepens him. The Range Officer recognizes the SYMBOL ("बहुत बड़ा कवि") because the MAN stood his ground. If he were merely symbolic, his fear would be performative; because he's real, his courage is costly. Ñ'upanj's experiential realism ensures the symbol is earned, not imposed.

DIFFICULTY: hard

## COMPETENCY_QUESTION_2
QUESTION: Compare the protagonist's moral journey in this story with the journey of a protagonist from another Class 11 Hindi text (e.g., 'नमक का दारोगा' or 'अपना-अपना भाग्य'). How does each author use the protagonist's relationship with institutional power to explore the theme of individual conscience? Write a comparative analysis of 200 words.

COMPETENCY: Comparative literary analysis across texts

STEPS:
- Step 1: Select a comparison text (e.g., 'नमक का दारोगा' - Vanshidhar vs. corrupt system).
- Step 2: Map parallel structural points: both protagonists are low-status individuals facing powerful institutions; both face a choice between compliance and conscience; both act at personal cost; both achieve moral victory despite material loss.
- Step 3: Identify key differences: Vanshidhar works WITHIN the system (as inspector) then breaks from it; the poet exists OUTSIDE the system entirely. Vanshidhar's conflict is professional duty vs. honesty; the poet's is survival vs. humanity.
- Step 4: Analyze authorial technique: Premchand uses irony (Vanshidhar's honesty gets him fired then rehired); Ñ'upanj uses revelation (poet identity reframes the conflict).
- Step 5: Synthesize: both authors show conscience as disruptive to institutional order, but Ñ'upanj adds the artist's specific role - poetry as conscience's archive.

ANSWER: Both Vanshidhar ('नमक का दारोगा') and the poet-protagonist ('तेंदुए का इस्माइल') embody individual conscience confronting institutional corruption, but their structural positions differ crucially. Vanshidhar is an insider - a salt inspector sworn to uphold the system he ultimately defies. His crisis is professional: "ड्यूटी" vs. "ईमानदारी." The poet is an outsider - a beggar-poet with no institutional role, making his stand purely existential. Vanshidhar's journey: compliance → temptation → resistance → punishment → vindication. The poet's: silence → witness → refusal → revelation → moral authority. Premchand uses dramatic irony: Vanshidhar's honesty costs him his job but earns Munshi Alopideen's respect, leading to a better position. Ñ'upanj uses identity revelation: the poet's stature forces the bureaucracy to retreat. Both endings are idealized - but Ñ'upanj's is more fragile. The tree is saved "इस बार" (this time); the system remains intact. Premchand suggests institutional reform is possible; Ñ'upanj suggests only individual conscience can momentarily halt the machine. The poet's art ("वस्ल का इमला") is the difference: Vanshidhar has only his word; the poet has his WORK that outlives him. Both authors affirm: conscience is not private feeling but public action.

DIFFICULTY: hard