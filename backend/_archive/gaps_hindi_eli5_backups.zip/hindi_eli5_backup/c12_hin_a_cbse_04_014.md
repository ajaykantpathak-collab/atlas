## DEFINITION
Writing skills based on the chapter refer to the ability to compose structured, evidence-based answers that analyze the poems "cukjl" and "fn'kk" by Osankjukph Lg, using textual evidence, literary terminology, and thematic insight to meet CBSE board exam expectations.

## COGNITIVE_LEVEL
apply

## MASTERY_CRITERIA
The student can independently write a 150-200 word answer for any textbook question on this chapter using the PEEL structure (Point, Evidence, Explanation, Link), incorporating at least two textual references and one literary device, and connecting the analysis to the poem's central theme.

## SCOPE_BOUNDARY
This node covers writing analytical answers for the two poems in Chapter 4 (cukjl and fn'kk), including summary, theme, imagery, symbolism, and critical appreciation. It does not cover creative writing, letter writing, or unrelated grammar exercises.

## WALKTHROUGH
Imagine you sit down to answer "cukjl esa olar dk vkxeu oSQls gksrk gS vkSj mldk D;k izHkko bl 'kgj ij iM+rk gS\" but your mind goes blank — you remember the poem describes a village scene but cannot turn that into a structured answer. Start by reading the question carefully and identifying the keywords: \"olar\" (crops/fields), \"vkxeu\" (description), \"izHkko\" (impact). Next, flip to the poem and mark 2-3 lines that directly address these keywords (e.g., the opening stanza describing the fields). Then, draft a point sentence: \"The poet portrays the village fields as a living entity.\" Follow with evidence: quote or paraphrase the lines about \"xaxk\" and \"eafnj\". Explain how the imagery creates a sense of vitality. Finally, link back to the theme of harmony between humans and nature. This step-by-step process transforms recall into analysis.

## DIAGNOSTIC_QUESTION_1
What is the full form of PEEL in the context of writing structured answers for literature questions?

## DIAGNOSTIC_ANSWER_1
PEEL stands for Point, Evidence, Explanation, Link. A wrong answer (e.g., \"Paragraph, Example, Explanation, Line\") reveals the student does not know the standard answer-writing framework taught in Class 12, leading to disorganized responses that lose marks for structure.

## DIAGNOSTIC_QUESTION_2
A student writes: \"In cukjl, the poet describes the village beautifully. The fields are green and the crops are growing. It shows nature is nice.\" Identify two specific weaknesses in this answer with respect to board exam expectations.

## DIAGNOSTIC_ANSWER_2
Weaknesses: (1) No textual evidence — vague statements like \"beautifully\" and \"green\" without quoting or referencing specific lines from the poem. (2) No analysis of literary devices or deeper meaning — stays at surface description. A wrong diagnosis (e.g., \"grammar errors\") shows the student confuses language mechanics with analytical writing requirements.

## DIAGNOSTIC_QUESTION_3
Apply the PEEL structure to answer: \"Explain the significance of the repeated phrase 'èkhjs&èkhjs' in the poem cukjl.\" Write only the Point and Evidence steps.

## DIAGNOSTIC_ANSWER_3
Point: The repetition of 'èkhjs&èkhjs' emphasizes the slow, inevitable passage of time in the village. Evidence: In the third stanza, the lines \"èkhjs&èkhjs mM+rh gS... èkhjs&èkhjs pyrs gSa yksx\" show how each repeated phrase marks a mundane yet continuous activity. A wrong application (e.g., giving evidence from the wrong stanza) reveals inability to locate precise textual support.

## DIAGNOSTIC_QUESTION_4
Compare the use of imagery in the opening stanzas of cukjl and fn'kk. How does each poet establish the setting differently?

## DIAGNOSTIC_ANSWER_4
In cukjl, visual and auditory imagery (\"xaxk\", \"eafnj\", \"fHk[kkfj;ksa dk mrjuk\") creates a vibrant, living landscape. In fn'kk, the imagery is minimal and dialogic (\"cPps dk mèkj&mèkj\", \"fgeky; fdèkj\") focusing on human emotion rather than scenery. A wrong comparison (e.g., saying both use similar nature imagery) shows failure to distinguish the poems' distinct poetic strategies.

## DIAGNOSTIC_QUESTION_5
Evaluate this claim: \"The poem fn'kk is only a simple conversation between a child and the poet; it has no deeper thematic significance.\" Defend or refute using textual evidence.

## DIAGNOSTIC_ANSWER_5
Refute. The poem uses the child's innocent question (\"fgeky; fdèkj gS\") to reveal the adult's loss of wonder and the erosion of ecological memory. The line \"eSa Lohdkj d:¡\" carries irony — the poet claims knowledge but has forgotten the bird's call. A wrong evaluation (agreeing with the claim) indicates a literal reading that misses symbolism and thematic depth.

## DIAGNOSTIC_QUESTION_6
Create a new 4-line stanza in the style of cukjl that extends the poem's theme of nature's endurance, using at least two literary devices from the original poem.

## DIAGNOSTIC_ANSWER_6
Example: \"xaxk phir bhi muskurayegi / èkq,¡ phir bhi geet sunayegi / olar ki god mein soyi duniya / naya savera phir aayegi.\" Uses personification (xaxk muskurayegi) and metaphor (olar ki god). A poor creation (e.g., a generic rhyming couplet without devices) shows inability to internalize and replicate the poet's craft.

## COMMON_MISCONCEPTION
Students believe that writing a detailed summary of the poem constitutes a good answer. They write: \"First the poet describes the fields, then the crops, then the farmers...\" This is wrong because board exams award marks for *analysis*, not narration. Summaries lack Point-Evidence-Explanation-Link structure, omit literary terminology, and fail to connect to themes. The misconception arises from confusing \"knowing the poem\" with \"answering the question analytically.\"

## ON_FAILURE
1. Have the student take a textbook question and highlight the command word (e.g., \"explain\", \"compare\", \"evaluate\"). 2. Together, list 3 exact lines from the poem that address the command. 3. Model one PEEL paragraph on the board, thinking aloud: \"My point is... My evidence is line 4... This shows... Therefore...\" 4. Assign a parallel question for independent practice with a PEEL template scaffold. 5. Re-diagnose using Diagnostic Question 2 format.

## BUILDS_ON
Critical thinking and textual analysis skills developed in nodes c12_hin_a_cbse_04_012 (Comprehension) and c12_hin_a_cbse_04_013 (Critical Thinking).

## LEADS_TO
Speaking and listening discussion (c12_hin_a_cbse_04_015) where students articulate written analyses orally.

## PREREQUISITE_NODE_IDS
c12_hin_a_cbse_04_002, c12_hin_a_cbse_04_003, c12_hin_a_cbse_04_006, c12_hin_a_cbse_04_008, c12_hin_a_cbse_04_009, c12_hin_a_cbse_04_012, c12_hin_a_cbse_04_013, c11_hin_ar_cbse_01_014, c11_hin_ar_cbse_02_014, c12_hin_a_cbse_04_011

## PREREQUISITE_REASONS
c12_hin_a_cbse_04_002: Provides plot/narrative structure of the poems for reference.
c12_hin_a_cbse_04_003: Supplies setting/atmosphere details used as evidence.
c12_hin_a_cbse_04_006: Gives primary theme to link back to in the Link step.
c12_hin_a_cbse_04_008: Provides imagery analysis for Evidence step.
c12_hin_a_cbse_04_009: Provides irony/symbolism analysis for Explanation step.
c12_hin_a_cbse_04_012: Ensures literal comprehension before inferential writing.
c12_hin_a_cbse_04_013: Develops interpretive skills needed for Explanation.
c11_hin_ar_cbse_01_014: Prior class writing skills foundation (PEEL introduction).
c11_hin_ar_cbse_02_014: Prior practice with evidence-based writing.
c12_hin_a_cbse_04_011: Writing skills tasks (e.g., "analyze the poet's language") directly apply the analytical framework taught here.  

## FORWARD_NODE_IDS
c12_hin_a_cbse_04_015
## FORWARD_REASONS
c12_hin_a_cbse_04_015: Written analyses become the basis for structured oral discussions and presentations.

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
N/A

## CHAIN_DESCRIPTION
c12_hin_a_cbse_04_013 -> c12_hin_a_cbse_04_014 -> c12_hin_a_cbse_04_015

## THIS_FORMULA
PEEL = Point (topic sentence) + Evidence (textual quote/paraphrase) + Explanation (analysis of device/meaning) + Link (connection to theme/question)

## FORMULA_VARIABLES
Point: One clear analytical claim answering the question. Evidence: Specific line(s) or detail from the poem. Explanation: How the evidence proves the point using literary terms. Link: Tie back to central theme or broader significance.

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
linguistic

## CROSS_SUBJECT
N/A | Analyzing primary sources (poems as cultural artifacts) uses same evidence-based argumentation as historical source analysis.
 N/A | Interpreting qualitative data (villager voices in fn'kk) parallels analyzing development narratives in economics case studies.
## PREREQ_CONCEPT
Ability to locate and cite specific textual evidence from a poem.

## PREREQ_BEFORE
Student must have read both poems at least twice and completed the comprehension and critical thinking nodes for this chapter.

## PREREQ_STUCK
If stuck, revisit c12_hin_a_cbse_04_012 (Comprehension) to practice extracting exact lines for given questions.

## WORKED_EXAMPLE_1
PROBLEM: Write a structured answer (150 words) for: \"cukjl dh iw.kZrk vkSj fjDrrk dks dfo us fdl izdkj fn[kk;k gS?\" (How has the poet depicted the beauty and vitality of the village?)

STEPS:
- Step 1: Identify keywords — \"iw.kZrk\" (beauty), \"fjDrrk\" (vitality), \"dfo us fdl izdkj fn[kk;k\" (how has the poet depicted). This demands analysis of poetic techniques, not just listing images.
- Step 2: Recall/locate evidence — Stanza 1: \"xaxk\", \"eafnj\", \"fHk[kkfj;ksa dk mrjuk\"; Stanza 2: \"èkhjs&èkhjs\" repetition showing ongoing life; Stanza 3: \"vkèkk ty esa\", \"vkèkk ea=k esa\" metaphor of nature as all-encompassing.
- Step 3: Draft Point — The poet uses dynamic imagery and metaphor to portray the village as a living, breathing entity.
- Step 4: Write Evidence + Explanation — Quote \"xaxk esa caèkh uko\" and explain personification of crops; quote \"vkèkk ty esa gS\" and explain metaphor of nature as water/air/food.
- Step 5: Craft Link — Conclude: Thus, beauty is not static scenery but the ceaseless pulse of life (fjDrrk) sustained by nature (vkèkk).

REASONING: The PEEL structure forces each paragraph to make an analytical claim, ground it in the text, unpack the literary effect, and relate it to the question's core demand. This mirrors the CBSE marking scheme's emphasis on \"analysis with textual support.\"

ANSWER:
The poet depicts the village's beauty and vitality through dynamic imagery and all-encompassing metaphors. In the opening stanza, crops are personified: \"xaxk esa caèkh uko\" — the fields possess a dignified vitality, not mere greenery. The auditory image \"fHk[kkfj;ksa dk mrjuk\" (the humming of insects) animates the scene with sound. Vitality is reinforced by the repetitive refrain \"èkhjs&èkhjs\" which mimics the relentless, cyclical rhythm of rural life — people walking, birds flying, time passing. Finally, the metaphor \"vkèkk ty esa gS / vkèkk ea=k esa gS\" (it is in the water, in the air) elevates nature to the very substance of existence. Thus, beauty (iw.kZrk) is inseparable from the living pulse (fjDrrk) that nature sustains in every breath of the village.

## WORKED_EXAMPLE_2
PROBLEM: Improve this weak answer for \"fn'kk dfo ne cPps ls D;k iwNk?\" (What did the poet ask the child in fn'kk?) Weak answer: \"The poet asked the child if he knew the bird's name. The child said he forgot. The poet felt sad.\"

STEPS:
- Step 1: Identify the question's demand — it asks \"what did the poet ask\", but board exams expect the *significance* of the question, not just the literal words.
- Step 2: Retrieve exact dialogue — Poet asks: \"fgeky; fdèkj gS\" (Is this a phoenix bird?). Child replies: \"mèkj&mèkj — ftèkj mldh iarx Hkkxh tk jgh Fkh\" (I don't know — the one whose call is fading).
- Step 3: Apply PEEL — Point: The poet's question reveals adult ignorance masked as knowledge. Evidence: \"eSa Lohdkj d:¡ eSaus igyh ckj tkuk fgeky; fdèkj gS\" (I swear, I am learning for the first time that this is a phoenix). Explanation: The irony — the educated adult discovers the bird's identity only when the child mourns its disappearing call. Link: This moment crystallizes the poem's theme: ecological memory resides in the young, not the learned.
- Step 4: Check word count and terminology — Include \"irony\", \"ecological memory\", \"dialogue\".
- Step 5: Final polish for flow and board-style language.

REASONING: Transforming a plot-level response into an analytical one requires shifting from \"what happened\" to \"what it means and how it is crafted.\" The PEEL framework guides this shift systematically.

ANSWER:
The poet asks the child, \"fgeky; fdèkj gS\" (Is this a phoenix bird?), but the question's irony unveils the poem's central concern. The child's reply — \"mèkj&mèkj — ftèkj mldh iarx Hkkxh tk jgh Fkh\" — carries the weight of vanishing biodiversity. The poet's admission \"eSa Lohdkj d:¡ eSaus igyh ckj tkuk fgeky; fdèkj gS\" exposes the modern adult's ecological amnesia: formal education (Lohdkj) failed to teach what the child knows instinctively. This dialogue employs dramatic irony to argue that true environmental knowledge lies in lived experience and intergenerational memory, not textbooks. The poet thus uses a simple query to indict a society that forgets its own natural heritage.

## WORKED_EXAMPLE_3
PROBLEM: A board exam question: \"Compare the representation of time in cukjl and fn'kk.\" Write a 200-word comparative analysis.

STEPS:
- Step 1: Deconstruct the question — \"Compare\" requires similarities and differences; \"representation of time\" is the thematic lens.
- Step 2: Map time in cukjl — Cyclical, eternal: \"èkhjs&èkhjs\" repetition, seasons implied by crops, nature as timeless (\"vkèkk\" metaphor).
- Step 3: Map time in fn'kk — Linear, irreversible loss: \"iarx Hkkxh tk jgh\" (call fading), \"igyh ckj tkuk\" (first time learning), childhood memory vs. present ignorance.
- Step 4: Identify literary devices for each — cukjl: repetition, metaphor; fn'kk: irony, dialogue, symbolism (phoenix = lost species).
- Step 5: Structure comparison — Use a point-by-point method: (a) Cyclical vs. Linear, (b) Nature as constant vs. Nature as vanishing, (c) Collective memory vs. Individual forgetting.
- Step 6: Draft with PEEL per paragraph, ensuring each comparative point has evidence from both poems.

REASONING: Comparative analysis is a high-order skill tested in 5-6 mark questions. It demands holding two texts in mind simultaneously and synthesizing a third insight (the contrast). The step-by-step mapping prevents missing one poem or listing features without comparing.

ANSWER:
Both poems engage with time but through opposing temporal visions. In cukjl, time is cyclical and eternal, embodied in the hypnotic repetition \"èkhjs&èkhjs\" — each iteration marks a mundane act (walking, flying, crying) that has occurred and will recur. The metaphor \"vkèkk ty esa gS / vkèkk ea=k esa gS\" casts nature as the timeless medium sustaining all life. Conversely, fn'kk presents time as linear and tragic: the phoenix's call \"Hkkxh tk jgh\" signals irreversible extinction. The poet's ironic epiphany — \"igyh ckj tkuk fgeky; fdèkj gS\" — marks a moment of delayed awareness, a personal timeline where knowledge arrives too late. Where cukjl's collective \"yksx\" (people) move in perennial rhythm, fn'kk isolates the individual (\"eSa\") confronting loss. Yet both converge on memory: cukjl's \"lbZ lk¡>\" (heart's call) summons ancestral connection to land; fn'kk's child holds the fading auditory memory (\"iarx\") that the adult has lost. Thus, cukjl celebrates time as nature's continuity; fn'kk mourns time as humanity's erasure of nature.

## COMPETENCY_QUESTION_1
QUESTION: A student writes an answer on \"Imagery in cukjl\" but only lists images (fields, crops, insects) without explaining their effect. Using the PEEL framework, rewrite the student's second paragraph to include Explanation and Link. Original paragraph: \"The poet uses visual imagery like 'xaxk' and 'eafnj' and auditory imagery like 'fHk[kkfj;ksa dk mrjuk'. These show the village is beautiful.\"

COMPETENCY: Analytical writing / Textual evidence integration

STEPS:
- Step 1: Identify the missing PEEL components — the paragraph has Point (implied) and Evidence but no Explanation or Link.
- Step 2: Add Explanation — Explain how visual imagery creates vitality (personification of crops) and how auditory imagery adds life (insects as background score of labor).
- Step 3: Add Link — Connect to the poem's theme of harmony between humans and nature.
- Step 4: Ensure board-appropriate vocabulary (personification, soundscape, vitality).

ANSWER:
The poet employs visual and auditory imagery to transform the village from a static landscape into a living organism. The visual personification \"xaxk esa caèkh uko\" (crops stand with dignified posture) invests the fields with agency and resilience, while \"eafnjksa vkSj ?kkVksa osQ fdukjs\" (thickets of bushes and branches) suggests wild, untamed fertility. The auditory image \"fHk[kkfj;ksa dk mrjuk\" (the dying hum of insects) is not mere sound — it is the soundscape of productive labor, linking nature's rhythms to human sustenance. Together, these images establish the poem's central theme: the village's beauty (iw.kZrk) is inseparable from its vitality (fjDrrk), a vitality sustained by the symbiotic pulse of land, life, and labor.

DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: \"The poem fn'kk is a critique of modern education.\" Evaluate this statement by writing a structured argument that uses at least three textual references and addresses both the literal and symbolic levels of the poem.

COMPETENCY: Critical evaluation / Multi-evidence argumentation

STEPS:
- Step 1: Deconstruct the claim — \"critique of modern education\" implies the poem blames formal schooling for ecological disconnect.
- Step 2: Select three textual anchors — (1) \"eSa Lohdkj d:¡\" (I swear), (2) \"igyh ckj tkuk fgeky; fdèkj gS\" (first time learning), (3) Child's knowledge \"mèkj&mèkj\" vs. adult's ignorance.
- Step 3: Build argument — Literal level: The educated poet doesn't know a local bird; the uneducated child does. Symbolic level: \"Lohdkj\" (education) represents institutional knowledge that excludes indigenous ecological wisdom; \"fgeky;\" (phoenix) symbolizes vanishing biodiversity.
- Step 4: Address counter-perspective — The poem doesn't reject education per se but highlights its gap; the poet's admission shows capacity for relearning.
- Step 5: Synthesize with Link to broader theme of intergenerational memory loss.

ANSWER:
The statement is partially valid but requires nuance. At the literal level, the poem starkly contrasts the poet's formal education (\"Lohdkj\") with the child's experiential knowledge (\"mèkj&mèkj — ftèkj mldh iarx Hkkxh tk jgh\"). The poet's oath \"eSa Lohdkj d:¡ eSaus igyh ckj tkuk fgeky; fdèkj gS\" uses irony to expose how schooling produces certified ignorance about local ecology. Symbolically, the phoenix (\"fgeky;\") — a bird of renewal — becomes an emblem of irreversible loss (\"iarx Hkkxh tk jgh\"), implicating a development model that erases indigenous memory. However, the poem does not dismiss education entirely; the poet's moment of recognition (\"igyh ckj tkuk\") suggests education can be redirected toward ecological literacy. Thus, fn'kk critiques not education itself but its alienation from place-based knowledge, urging a curriculum that listens to the child's \"mèkj\" as much as the textbook's \"Lohdkj\".

DIFFICULTY: hard