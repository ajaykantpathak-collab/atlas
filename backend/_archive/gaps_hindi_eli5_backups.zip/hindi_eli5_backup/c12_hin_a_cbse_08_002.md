## DEFINITION
Plot and Narrative Structure in poetry refers to the organization of events, emotions, and images into a coherent sequence that conveys a story or emotional journey — even in lyrical verses. In Class 12 Hindi (Antra) Chapter 8, the three stanzas of *Phool Kee* (by poet *Phul ke*) form a mini-narrative: a separated woman’s longing (stanza 1), her night-time anguish (stanza 2), and her prayer to the lamp for her husband’s return (stanza 3). The structure moves from **exposition → rising emotional tension → climax of despair → resolution through prayer**.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student can (1) break each stanza into its narrative function (exposition, complication, climax, resolution), (2) quote specific words/phrases that signal structural shifts, and (3) explain how the poet uses repetition, imagery, and address to the lamp to advance the emotional arc — all in a structured PEEL paragraph.

## SCOPE_BOUNDARY
This node covers **only** the narrative structure of the three stanzas in NCERT Chapter 8 (*Phool Kee*). It does **not** cover setting/atmosphere (node 003), character analysis (nodes 004-005), themes (nodes 006-007), or literary devices in isolation (nodes 008-009). It focuses on *how the story is ordered* across stanzas.

## WALKTHROUGH
Imagine you’re watching a short film with three scenes: a woman staring at an empty road (scene 1), the same woman at midnight hearing wind howl (scene 2), and finally her whispering to a flickering lamp “don’t go out, bring him back” (scene 3). You instinctively sense a story progressing. That’s exactly what *Phool Kee* does in three stanzas. Start by reading the three stanzas aloud — notice how the **first stanza sets up the separation**, the **second intensifies the pain with night imagery**, and the **third shifts to direct address (apostrophe) to the lamp**. Mark the transition words: *lf[k* (then), *rhljs* (third), *dj nsb* (do this). The key insight: **even without a linear plot, the poet orders emotions like a narrative — each stanza is a “scene” that pushes the emotional story forward.**

## DIAGNOSTIC_QUESTION_1
What is the primary narrative function of the first stanza in *Phool Kee*?

## DIAGNOSTIC_ANSWER_1
The first stanza serves as **exposition**: it introduces the protagonist (the separated woman), her situation (husband gone to a distant land), and her core emotion (longing). A wrong answer like “it describes the night” reveals the student is confusing stanza 1 with stanza 2 — they haven’t distinguished the *setup* from the *intensification*.

## DIAGNOSTIC_QUESTION_2
Explain in your own words how the narrative shifts from stanza 1 to stanza 2. What changes in the woman’s emotional state?

## DIAGNOSTIC_ANSWER_2
Stanza 1 is **static waiting** (“I have been watching the path since birth”); stanza 2 becomes **active suffering** — night deepens, wind howls, the moon loses beauty, and she admits “I have not found peace.” A wrong answer that says “both stanzas show sadness” misses the structural shift from *passive waiting* to *active, sensory anguish* — the narrative complication.

## DIAGNOSTIC_QUESTION_3
Identify the exact phrase in stanza 3 that marks the **climax** of the narrative arc and justify why it is the turning point.

## DIAGNOSTIC_ANSWER_3
The phrase **“dj nsb >k¡ib dku” (extinguish the lamp, O lamp)** — actually a plea *not* to let the lamp go out — is the climax. The woman moves from describing pain to **direct action**: she commands the lamp to survive so her husband can find his way. A wrong answer picking “ewfn jg, nq u;ku” (stay awake, don’t sleep) shows they see only desperation, not the *agency* that marks the narrative peak.

## DIAGNOSTIC_QUESTION_4
Compare the narrative role of the **lamp (dkuu)** in stanza 3 with the **path (Hkou)** in stanza 1. How does the shift from path to lamp restructure the story?

## DIAGNOSTIC_ANSWER_4
The **path** in stanza 1 is a *passive symbol* of hope (she watches it). The **lamp** in stanza 3 becomes an *active agent* she addresses and commands. This shifts the narrative from **external waiting** to **internal agency** — she now participates in the resolution. A wrong answer treating both as mere “symbols of hope” misses the structural promotion of the lamp to a character she bargains with.

## DIAGNOSTIC_QUESTION_5
Evaluate whether the three-stanza structure effectively resolves the narrative tension. Support your judgment with evidence from the text.

## DIAGNOSTIC_ANSWER_5
**Yes, partially.** The prayer to the lamp (“stay lit so he returns”) provides emotional closure — she transforms despair into ritual. But the husband’s return is **not shown**; the narrative ends on *anticipation*, not fulfillment. A wrong answer claiming “complete resolution” ignores the open ending; one saying “no resolution” misses the psychological closure of the prayer act.

## DIAGNOSTIC_QUESTION_6
Write a fourth stanza (4-6 lines in Hindi) that continues the narrative *after* the lamp prayer, maintaining the same voice, imagery, and structural logic.

## DIAGNOSTIC_ANSWER_6
A strong stanza will: (a) use Braj-inflected vocabulary (*eèkqiqj, xksoqQy, fiz;rek*), (b) show the lamp’s response (flaring steady / flickering), (c) introduce a sensory sign of return (footsteps, dust on road), and (d) end on a note of *quiet hope* not full reunion. A weak answer jumps to “he came back” — breaking the poem’s restraint — or switches to modern Hindi, losing the linguistic texture.

## COMMON_MISCONCEPTION
Students treat each stanza as an **independent poem** on “separation” and write three separate summaries. They miss that **the stanzas are sequenced like acts in a play**: stanza 1 = *setup*, stanza 2 = *complication*, stanza 3 = *climax + partial resolution*. This happens because board exams often ask “explain stanza 2” in isolation, training students to fragment the narrative. The competitive-exam trap: CUET/JEE-style questions ask “trace the emotional arc across stanzas” — fragmentation loses 2-3 marks.

## ON_FAILURE
1. **Re-read the three stanzas in one sitting** without stopping for meanings. Feel the emotional flow.  
2. **Draw a 3-box storyboard**: Box 1 = “Woman on road at dusk”, Box 2 = “Same woman at midnight with wind”, Box 3 = “Woman at lamp, whispering”. Label each box with the stanza number.  
3. **Revisit node c11_hin_ar_cbse_01_002** (Class 11 Plot & Narrative Structure) — redo its worked example on “identifying narrative beats in a lyric poem”.  
4. **Re-diagnostic**: Answer Diagnostic Question 4 again — if you now see the *path → lamp* shift as structural promotion, you’re ready.

## BUILDS_ON
Class 11 skill of identifying narrative beats (exposition, rising action, climax) in lyric poetry (node c11_hin_ar_cbse_01_002).

## LEADS_TO
Setting & Atmosphere (node c12_hin_a_cbse_08_003) — where the night/wind/lamp imagery analysed here becomes the *atmospheric backdrop* for the narrative.

## PREREQUISITE_NODE_IDS
c12_hin_a_cbse_08_001, c11_hin_ar_cbse_01_002, c11_hin_ar_cbse_02_002, c11_hin_ar_cbse_03_002
## PREREQUISITE_REASONS
c12_hin_a_cbse_08_001: Provides historical context of *Phool Kee* and poet Phul Kee — needed to understand why a medieval poet uses this narrative structure.  
c11_hin_ar_cbse_01_002: Introduces the concept of “narrative beats in poetry” — the analytical framework used here.  
c11_hin_ar_cbse_02_002: Reinforces stanza-level progression tracking across multiple poems.  
c11_hin_ar_cbse_03_002: Shows how emotional arcs replace event-based plots in Bhakti/Riti poetry.

## FORWARD_NODE_IDS
c12_hin_a_cbse_08_003, c12_hin_a_cbse_08_004, c12_hin_a_cbse_08_006, c12_hin_a_cbse_08_007, c12_hin_a_cbse_08_008, c12_hin_a_cbse_08_009, c12_hin_a_cbse_08_012

## FORWARD_REASONS
c12_hin_a_cbse_08_003: The night/wind/lamp imagery mapped here becomes the *setting* analysed in the next node.  
c12_hin_a_cbse_08_004: The protagonist’s agency (commanding the lamp) is the core of her character analysis.  
c12_hin_a_cbse_08_006: The primary theme “love transcends separation” is carried by the narrative structure traced here.
c12_hin_a_cbse_08_007: Narrative structure of the three padas as a sequence shows thematic progression.  
c12_hin_a_cbse_08_008: Establishes narrative structure (three poems = three stages of viraha) so imagery can be mapped to emotional arc.  
c12_hin_a_cbse_08_009: Narrative structure of each poem (stanza progression) helps locate where symbols are introduced and developed.  
c12_hin_a_cbse_08_012: Understanding narrative/poetic structure helps locate evidence in specific stanzas.  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
(No cross-subject nodes provided in prior class data; this is a standalone Hindi literature node.)

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_01_002 -> c12_hin_a_cbse_08_002 -> c12_hin_a_cbse_08_003

## THIS_FORMULA
N/A - conceptual

## FORMULA_VARIABLES
N/A

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
analytical

## CROSS_SUBJECT
N/A | The poem reflects 14th-15th century North Indian social reality: men leaving for trade/war (xksoqQy to eèkqiqj), women managing household rituals (lamp prayer) — a micro-history of gendered separation.  
 N/A | The lamp (dkuu) as a cultural symbol of continuity and hope connects to civics’ “intangible cultural heritage” — how rituals structure collective memory.
## PREREQ_CONCEPT
Ability to segment a lyric poem into narrative beats (exposition, complication, climax, resolution) — taught in Class 11 node c11_hin_ar_cbse_01_002.

## PREREQ_BEFORE
Student must know the literal meaning of key Braj words: *fiz;rek* (separated woman), *xksoqQy* (beloved/husband), *eèkqiqj* (distant land), *dkuu* (lamp), *>k¡ib* (extinguish/put out).

## PREREQ_STUCK
If stuck, revisit the **vocabulary glossary** at the end of NCERT Chapter 8 (words like *fivk, fcuq, lkvksu, vitl*) and map each to its narrative function.

## WORKED_EXAMPLE_1
PROBLEM: Using the three stanzas of *Phool Kee*, write a PEEL paragraph explaining how the poet structures the woman’s emotional journey from passive waiting to active prayer.

STEPS:
- Step 1: Identify the three narrative beats — Stanza 1 = Exposition (waiting on path), Stanza 2 = Complication (night deepens, pain intensifies), Stanza 3 = Climax + Partial Resolution (addressing the lamp).
- Step 2: Select evidence: Stanza 1 — “eksjk fivre iklA lg, ufg lg, vlg nq[k js Hksy lkvksu ekl” (watching path since birth, through seasons); Stanza 2 — “tue vcfèk ge :i fugkjy u;u u frjfir Hksy” (night passed, no peace found); Stanza 3 — “dj nsb >k¡ib dku” (command to lamp).
- Step 3: Explain each quote’s structural role: the seasonal markers (lg, ufg, vlg) stretch time → exposition; the sensory details (wind, moon, sleeplessness) raise stakes → complication; the imperative verb “dj nsb” shifts agency to the woman → climax.
- Step 4: Link to central idea: The structure mirrors the Bhakti/Riti trope of *viraha* (separation) where the devotee’s longing becomes spiritual practice — the lamp prayer is both ritual and narrative resolution.
- Step 5: Concluding sentence: Thus, the three-stanza architecture transforms a static lyric into a dynamic emotional narrative.

REASONING: The PEEL structure forces the student to tie each textual evidence to a structural label (exposition, complication, climax) — exactly what board marking schemes reward. The seasonal markers in stanza 1 are not decorative; they *create* the time-span of waiting.

ANSWER:
The poet structures the woman’s journey in three narrative beats. **Stanza 1 (Exposition)** establishes her passive vigil: “eksjk fivre iklA lg, ufg lg, vlg nq[k js Hksy lkvksu ekl” — the cycle of seasons (spring, summer, rainy) on the path shows years of waiting. **Stanza 2 (Complication)** intensifies the crisis: “tue vcfèk ge :i fugkjy u;u u frjfir Hksy” — night deepens, the moon offers no solace, and she admits total sleeplessness. **Stanza 3 (Climax + Resolution)** shifts agency: “dj nsb >k¡ib dku” — she commands the lamp not to die, turning despair into ritual action. This arc — from watching → suffering → praying — mirrors the *viraha* tradition where separation becomes a path to union. The structure is the poem’s argument.

## WORKED_EXAMPLE_2
PROBLEM: A board question asks: “How does the repetition of ‘nq[k’ (path/way) in stanza 1 and ‘nk#u’ (eyes/vision) in the same stanza prepare the narrative ground for the lamp in stanza 3?” Answer in 60 words.

STEPS:
- Step 1: Locate the words: “nq[k” appears twice in stanza 1 (“nq[k js Hksy lkvksu ekl” and “nq[k nk#u js tx osQ ifrvk”); “nk#u” appears once (“nk#u js tx osQ ifrvk”).
- Step 2: Analyse their narrative function: “nq[k” = external path she watches; “nk#u” = internal gaze (eyes) fixed on that path. Together they establish **visual fixation** as her only action.
- Step 3: Connect to stanza 3’s lamp: The lamp *becomes* the new “path” — its light *is* the way for the husband. The fixation transfers from road to flame.
- Step 4: Draft concise answer: In stanza 1, repeated “nq[k” (path) and “nk#u” (eyes) build a narrative of **visual obsession** — she *is* her gaze. Stanza 3 transfers that obsession to the lamp (“dkuu”): the flame replaces the road as the guiding path. The structural logic: external path → internal gaze → ritual light. The lamp inherits the path’s narrative burden.
- Step 5: Check word count (≈55 words) and ensure terms “exposition”, “transfer”, “narrative burden” are used.

REASONING: Board exams test *inter-stanza coherence*. This question forces the student to see a word (“nq[k”) not as vocabulary but as a **structural thread** that the poet pulls from stanza 1 to stanza 3.

ANSWER:
In stanza 1, “nq[k” (path) and “nk#u” (eyes) construct an exposition of **visual fixation** — the woman’s identity merges with watching the road. Stanza 3 structurally transfers this burden to the lamp (“dkuu”): the flame becomes the new “path” guiding the husband. The narrative logic: external road → internal gaze → ritual light. The lamp inherits the path’s function, turning passive waiting into active tending.

## WORKED_EXAMPLE_3
PROBLEM: (CUET-style) The three stanzas of *Phool Kee* are often called a “miniature narrative.” Identify **two** structural devices the poet uses to compress a full separation story into three stanzas, and explain how each device works with a textual example.

STEPS:
- Step 1: Recall structural compression devices in lyric narratives: (a) **Ellipsis** (skipping time/events), (b) **Symbolic condensation** (one image carries multiple narrative beats), (c) **Apostrophe as climax** (address to absent object resolves tension).
- Step 2: Select two: **Ellipsis** and **Apostrophe as climax**.
- Step 3: Evidence for Ellipsis: Stanza 1 covers *years* (“lg, ufg lg, vlg” — three seasons) in two lines; the husband’s departure, journey, and absence are **never narrated** — only the woman’s watching remains. This compresses the backstory into exposition.
- Step 4: Evidence for Apostrophe as climax: Stanza 3’s “dj nsb >k¡ib dku” — she speaks *to* the lamp, not *about* it. This direct address **enacts** the resolution (prayer) instead of describing it. The narrative peak is a speech act.
- Step 5: Explain effect: Ellipsis forces reader to *infer* the missing years; apostrophe makes the climax *performative* — we hear her voice, not the poet’s summary.
- Step 6: Write final answer with device names, examples, and compression effect.

REASONING: Competitive exams (CUET, JEE language papers) test **meta-awareness of narrative craft**. Naming devices (ellipsis, apostrophe) and linking each to a specific textual compression shows analytical depth beyond “the poem tells a story.”

ANSWER:
Two compression devices:  
1. **Ellipsis** — Stanza 1 condenses *years* of separation (“lg, ufg lg, vlg nq[k js Hksy lkvksu ekl”) into a single seasonal sweep. The husband’s departure, travel, and stay abroad are **omitted**; only the woman’s vigil remains. The reader reconstructs the missing narrative.  
2. **Apostrophe as performative climax** — Stanza 3’s “dj nsb >k¡ib dku” addresses the lamp directly. The narrative resolution (prayer for return) is **enacted as speech**, not reported. The climax becomes a ritual act the reader witnesses, compressing “she prayed and felt hope” into four imperative words.

## COMPETENCY_QUESTION_1
QUESTION: A student writes: “All three stanzas of *Phool Kee* describe the same thing — a woman missing her husband. There is no story, just repetition.” Using your knowledge of narrative structure, write a 75-word rebuttal that identifies the **specific structural progression** the student misses.

COMPETENCY
Critical Thinking — Analysis and Interpretation (CBSE Competency: “Analyse and evaluate literary texts”)

STEPS:
- Step 1: Acknowledge the surface similarity (all stanzas express longing).
- Step 2: Name the three distinct narrative beats with stanza numbers.
- Step 3: Give one textual marker per beat that proves progression (seasonal markers → night sensory details → imperative verb).
- Step 4: Conclude: repetition is *structural*, not redundant — it builds emotional intensity.

ANSWER:
The student confuses *theme* with *structure*. Yes, longing is the constant theme, but the **narrative beats** shift: **Stanza 1 (Exposition)** — “lg, ufg lg, vlg” (seasons) establishes *duration* of waiting. **Stanza 2 (Complication)** — “tue vcfèk ge :i fugkjy u;u u frjfir Hksy” introduces *night’s sensory assault* (wind, moon, sleeplessness) — the pain sharpens. **Stanza 3 (Climax)** — “dj nsb >k¡ib dku” moves from description to **imperative prayer** — agency emerges. The repetition of longing *is* the narrative engine: each stanza ratchets the emotional stakes.

DIFFICULTY
medium

## COMPETENCY_QUESTION_2
QUESTION: (Case-based) A director wants to stage *Phool Kee* as a 3-minute dance-drama with **no dialogue**, only movement, lighting, and sound. Based on the narrative structure you analysed, design the **lighting cue sheet** for the three stanzas. For each stanza, specify: (a) dominant colour, (b) intensity change, (c) one symbolic prop illuminated. Justify each choice with a structural reason from the poem.

COMPETENCY
Creative Application — Interdisciplinary Thinking (CUET/Board Competency: “Apply literary analysis to other media”)

STEPS:
- Step 1: Map stanza 1 (exposition) → lighting: **warm amber**, **slow fade-in**, **spot on empty path (floor pattern)** — reason: seasonal waiting, hope still alive.
- Step 2: Map stanza 2 (complication) → lighting: **cold blue**, **strobe/flicker**, **spot on wind chime / moving fabric** — reason: night, sensory chaos, moon’s lost beauty.
- Step 3: Map stanza 3 (climax) → lighting: **single golden pool**, **steady intensity**, **spot on lamp (dkuu) centre stage** — reason: lamp becomes sole focus, prayer ritual, agency.
- Step 4: Ensure each cue ties to a *structural function* (exposition/complication/climax), not just mood.
- Step 5: Present as a table or bullet list with justifications.

ANSWER:
| Stanza | Narrative Beat | Dominant Colour | Intensity Change | Symbolic Prop Lit | Structural Justification |
|--------|----------------|-----------------|------------------|-------------------|--------------------------|
| 1 | Exposition | Warm amber | Slow fade-in (0→60%) | Floor-projected **path** (nq[k) | Seasons pass on the road; hope is external, diffuse. |
| 2 | Complication | Cold steel blue | Erratic flicker / strobe | **Wind chime** / flowing fabric | Night fractures peace; sensory overload mirrors “tue vcfèk ge :i fugkjy u;u u frjfir Hksy”. |
| 3 | Climax + Resolution | Pure gold | Steady, unwavering (100%) | **Lamp (dkuu)** centre stage | “dj nsb >k¡ib dku” — the lamp *is* the narrative resolution; all light converges on her agency. |

DIFFICULTY
hard