## DEFINITION
Vocabulary in Context refers to the skill of determining the precise meaning, connotation, and grammatical function of key words by analyzing their usage within specific sentences, paragraphs, and the broader narrative structure of the text, rather than relying on isolated dictionary definitions.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student can independently identify 8-10 key words from the chapter, explain their contextual meaning with textual evidence, analyze how the author's word choice shapes tone and theme, and use these words correctly in original sentences reflecting the chapter's socio-emotional context.

## SCOPE_BOUNDARY
This node covers vocabulary acquisition strategies specific to the autobiographical narrative "vkyks&vk¡èkkfj" — focusing on words related to domestic labor, social hierarchy, literacy journey, and emotional resilience. It does NOT cover general Hindi vocabulary building, grammar rules (covered in node 011), or literary device identification (covered in nodes 008-009).

## WALKTHROUGH
Imagine you're reading the scene where the narrator describes carrying heavy water pots up stairs while pregnant — you encounter "lqvj ihNs ls vkdj rax djuk 'kq: dj nsrsA" — you might guess "rax" means tiredness, but the context reveals it's a specific physical exhaustion that forces surrender. Start by identifying 15-20 unfamiliar or significantly used words from the text. For each, locate its exact sentence, note the surrounding action/emotion, determine if it carries positive/negative/neutral connotation in this context, and compare with its standard dictionary meaning. The key insight: in this chapter, words like "yM+dh" (mistress/employer), "lquhy" (the previous employer), "rkrq'k" (the supportive employer), and "fp_h" (diary/writing) carry layered meanings shaped by power dynamics and the narrator's evolving self-perception.

## DIAGNOSTIC_QUESTION_1
In the phrase "esjs cPpksa dks f[kyk&fiykdj jsMh djrh vkSj ?kj esa rkyk yxkdj muosQ lkFk fudy iM+rh" (paragraph 3), what does the compound verb "f[kyk&fiykdj" reveal about the narrator's action that "f[kykdj" alone would not?

## DIAGNOSTIC_ANSWER_1
"f[kyk&fiykdj" (waking up AND sending off) is a compound verb showing sequential, completed actions — the narrator doesn't just wake her children but ensures they leave for school. A wrong answer treating it as simple "waking up" misses the narrator's agency and routine responsibility, revealing the student cannot analyze how compound verbs convey layered domestic labor.

## DIAGNOSTIC_QUESTION_2
The word "yM+dh" appears 40+ times in the chapter. In "rkrq'k us dgk] ns[kks] rqe ;g dHkh er lkspuk fd rqe ;gk¡ cl dke ij yxh ,d yM+dh gks] ;k ;g ?kj fdlh vkSj dk gSA bls rqe viuk gh le>ukA esjh dksbZ yM+dh ugha] gS] eSa rqEgsa viuh yM+dh tSlk ekurk gw¡" (page 36), how does the meaning shift from its standard dictionary definition of "mistress/lady of the house"?

## DIAGNOSTIC_ANSWER_2
Here "yM+dh" transforms from a title of authority to a relational identity — rkrq'k claims the narrator AS his "yM+dh" (partner/wife-figure) rather than employer, rejecting transactional power for emotional belonging. A student defining it only as "employer" misses the chapter's central theme of redefining relationships beyond class hierarchy.

## DIAGNOSTIC_QUESTION_3
Apply the context-clue strategy to determine the meaning of "v[kckj" in this sentence from page 54: "rkrq'k mlesa ls tks oqQN eq>s crkrs og lc esjs fy, fcyoqQy u;k gksrk vkSj oSlh ckrsa ckj&ckj lquus&le>us osQ fy, eSa jks”k lcsjs xsV ij [kM+h gks v[kckj vkus dk jkLrk ns[krhA"

## DIAGNOSTIC_ANSWER_3
Step 1: Identify sentence structure — "v[kckj vkus dk jkLrk ns[krh" (watching the arrival of v[kckj). Step 2: Note preceding context — rkrq'k reads aloud, narrator listens repeatedly. Step 3: Connect to "xsV ij [kM+h gks" (sitting on bed) — a relaxed, receptive posture. Step 4: Infer "v[kckj" = written composition/manuscript (what is being read). Wrong answers like "letter" or "book" ignore the personal, evolving nature of the narrator's own writing being read back to her.

## DIAGNOSTIC_QUESTION_4
Analyze the semantic progression of "fp_h" (diary/writing) across these three contexts: (a) page 42 "rkrq'k us viuh fy[kus dh Vsfcy osQ Mªkj ls ,d isu vkSj dkWih fudkyh" (b) page 46 "tsBw us mUgsa viuh dgkuh dks fdlh ,d eksM+ rd igq¡pkuk gksxk" (c) page 50 "vc rd ftruk eSa fy[k pqdh Fkh mls rkrq'k us I+kQksVks&dkWih djk osQ vius ,d caèkq osQ ikl dksydkrk Hkst fn;k Fkk". How does the narrator's relationship to writing change?

## DIAGNOSTIC_ANSWER_4
(a) "fp_h" = gifted notebook — external tool given by another. (b) "dgkuh" (story) = her life narrative — writing becomes self-expression. (c) "fy[kus" = published manuscript — writing becomes professional identity. The progression: object → voice → vocation. Students treating "fp_h" as static "diary" miss the chapter's arc of empowerment through literacy.

## DIAGNOSTIC_QUESTION_5
Evaluate this claim: "The word 'lquhy' (the first employer) functions only as a proper noun identifying a character." Use textual evidence from pages 21-27 to defend or refute.

## DIAGNOSTIC_ANSWER_5
Refute. "lquhy" appears 15+ times with shifting connotations: initially neutral employer (p.21 "lquhy vk;k"), then investigator (p.22 "lquhy us xsV osQ ckgj yxh"), then betrayer (p.26 "lquhy us mUgsa crk;k Fkk fd rkrq'k us fiQj dgk"), finally symbol of systemic exploitation (p.27 "lquhy dks dgk¡ ls irk pyk gksxk"). The name becomes a metonym for institutional indifference. Accepting the claim shows inability to track semantic evolution across narrative time.

## DIAGNOSTIC_QUESTION_6
Create two original sentences using "cqyk" (from page 34 "eq>s cqykdj mUgsa dgk] pyks] pydj ns[krh gw~¡A") that demonstrate its distinct meanings in: (1) a domestic labor context, (2) an emotional separation context. Explain how context determines the grammatical structure in each.

## DIAGNOSTIC_ANSWER_6
(1) "yM+dh ne cPpksa dks f[kyk cqykdj LowQy ykSV xbZ" (causative: made someone do something — transitive, labor context). (2) "og vius eu dks cqykdj chl xbZ" (reflexive: steeled oneself — intransitive, emotional context). Good answers show "cqyk" + infinitive = causative action vs. "cqyk" + reflexive pronoun = internal resolve. Poor answers use identical structures, missing how valency changes with context.

## COMMON_MISCONCEPTION
Students believe "vocabulary in context" means finding dictionary definitions for bolded words in the textbook. In this chapter, they specifically look up "yM+dh" as "mistress" and "lquhy" as a name, then stop. They miss that "yM+dh" shifts from oppressive employer (pages 21-25) to chosen partner (page 36) to professional colleague (page 50), and "lquhy" transforms from individual to systemic symbol. This happens because they treat words as static labels rather than dynamic meaning-makers shaped by the narrator's evolving consciousness.

## ON_FAILURE
1. Have the student trace ONE word ("yM+dh" or "fp_h" or "v[kckj") across 5 specific page references, noting speaker, listener, action, and emotion each time. 2. Create a 3-column chart: Dictionary Meaning | Contextual Meaning | Narrative Function. 3. Ask: "If this word were deleted, what would the reader lose?" 4. Practice with a fresh paragraph from page 44-45 (the "je.k nk" episode) identifying 3 words whose meaning shifts from their dictionary entry.

## BUILDS_ON
c11_hin_v_cbse_03_002 (Text: Plot and Narrative Structure) — understanding the narrator's journey from domestic worker to writer provides the narrative arc that shapes vocabulary evolution.

## LEADS_TO
c11_hin_v_cbse_03_011 (Grammar: Language Usage in the Text) — vocabulary analysis reveals grammatical patterns (compound verbs, causative constructions, honorific shifts) that become the focus of grammar study.

## PREREQUISITE_NODE_IDS
c11_hin_v_cbse_03_002, c11_hin_v_cbse_03_004, c11_hin_v_cbse_03_006
## PREREQUISITE_REASONS
c11_hin_v_cbse_03_002: Plot knowledge needed to situate vocabulary in narrative sequence (e.g., "fp_h" meaning changes pre/post literacy).
c11_hin_v_cbse_03_004: Protagonist analysis reveals how the narrator's voice shapes word connotations (her internal vs. external vocabulary).
c11_hin_v_cbse_03_006: Primary theme (dignity through literacy) provides the thematic lens for evaluating vocabulary choices.

## FORWARD_NODE_IDS
c11_hin_v_cbse_03_011, c11_hin_v_cbse_03_012, c11_hin_v_cbse_03_014, c12_hin_a_cbse_07_010, c12_hin_v_cbse_03_010

## FORWARD_REASONS
c11_hin_v_cbse_03_011: Vocabulary analysis directly feeds into grammar study of causative verbs, honorifics, and compound verbs used in the text.
c11_hin_v_cbse_03_012: Contextual vocabulary mastery enables literal and inferential comprehension answers requiring precise word interpretation.
c11_hin_v_cbse_03_014: Writing skills tasks (diary entry, character sketch) require deploying chapter-specific vocabulary authentically.
c12_hin_a_cbse_07_010: Applied vocabulary skills to prose passages.  
c12_hin_v_cbse_03_010: Provides the foundational context-clue taxonomy (definition, synonym, antonym, example, inference) that this node advances to semantic-field clustering and authorial stance analysis.  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
none

## CHAIN_DESCRIPTION
c11_hin_v_cbse_03_002 -> c11_hin_v_cbse_03_010 -> c11_hin_v_cbse_03_011

## THIS_FORMULA
Contextual Meaning = (Dictionary Definition) + (Speaker/Listener Relationship) + (Narrative Moment) + (Recurring Pattern Across Text)

## FORMULA_VARIABLES
- Dictionary Definition: Standard lexical meaning
- Speaker/Listener Relationship: Power dynamic, intimacy, or formality between interlocutors
- Narrative Moment: Chronological position in the narrator's journey (pre-literacy, learning, post-publication)
- Recurring Pattern Across Text: Frequency, collocations, and semantic shifts tracked through the chapter

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
linguistic

## CROSS_SUBJECT
c11_history_social_change | The chapter's vocabulary of domestic labor ("yM+dh", "lquhy", "dke", "fdjk;s") mirrors historical shifts in women's work and caste-class dynamics in 20th century India — analyzing word meanings parallels analyzing primary sources for social history.
c11_geography_human_geography | Spatial vocabulary ("?kj", "dejs", "vkl&ikl", "nwljks ?kj") reflects migration, urban housing geography, and the gendered use of domestic space — word meanings are anchored in material geography.

## PREREQ_CONCEPT
The narrator's identity transformation from invisible domestic worker to published writer — this journey is the engine driving semantic change in the chapter's key vocabulary.

## PREREQ_BEFORE
Student must recall the 5 major phases of the narrator's life in the chapter: (1) Multiple exploitative employers, (2) rkrq'k's household — learning to read/write, (3) Writing "fp_h" and gaining recognition, (4) Family reunions and losses, (5) Established writer with agency.

## PREREQ_STUCK
If stuck, review the timeline in c11_hin_v_cbse_03_002 (Plot and Narrative Structure) focusing on the narrator's literacy milestones — each milestone correlates with a vocabulary shift.

## WORKED_EXAMPLE_1
PROBLEM: Analyze the word "dke" (work) in three distinct contexts from the chapter to show how its meaning expands from "labor" to "identity" to "vocation."

STEPS:
- Step 1: Locate first occurrence — page 21 "vc vius fdjk;s osQ ?kj esa FKhA lc le; lksprh jgrh fd dke u feyk rks..." — here "dke" = domestic chores for survival, imposed by necessity, no agency.
- Step 2: Locate middle occurrence — page 34 "bl ?kj dh yM+dh us dgk fd ;fn mUgsa irk pys fd fdlh dks dke djus okys dh ”k:jr gS rks eq>s crk,¡" — here "dke" = recognized profession with rights, negotiated between employer and worker.
- Step 3: Locate late occurrence — page 50 "rkrq'k us rqEgsa 'kCn&dks'k dh enn ysus dks Bhd gh dgk gSA... rqEgkjs dgkuh D;k bèkj lks;h iM+h gS" — here "dke" (implied in 'kCn&dks'k, fy[kus) = creative vocation, self-defined, socially validated.
- Step 4: Map the trajectory — survival labor → rights-bearing employment → creative vocation. Note grammatical shifts: "dke u feyk" (negative compulsion) → "dke djus okys" (agentive participle) → "fy[kus" (infinitive as noun, "writing" as THE work).
- Step 5: Synthesize — The single lexeme "dke" carries the chapter's entire thesis: dignity comes when work becomes self-chosen expression.

REASONING: This example models the core analytical move: tracking one word across narrative time to reveal thematic development. The three contexts represent the chapter's three acts, and the grammatical analysis (negative verb, participle, infinitive-noun) provides linguistic evidence for the semantic shift.

ANSWER: "dke" evolves from coerced domestic labor (p.21, "dke u feyk" — work not found/available, implying desperate search) to recognized professional service with rights (p.34, "dke djus okys" — one who does work, implying professional identity) to creative authorship (p.50, "fy[kus" subsuming "dke" — writing AS work). The grammatical progression (negative existential → agentive participle → verbal noun) mirrors the narrator's journey from object to subject to author.

## WORKED_EXAMPLE_2
PROBLEM: The phrase "ikuh ihus osQ cgkus" appears on page 31 ("ikuh ihus osQ cgkus esjs ?kj vk tkrsA"). Deconstruct this nominalized phrase to explain how it encapsulates the narrator's social vulnerability.

STEPS:
- Step 1: Break morphology — "ikuh" (root: stay/live) + "ihus" (root: be/become) + "osQ" (genitive) + "cgkus" (plural oblique of cgka = effort/attempt). Literal: "of efforts to make stay/become."
- Step 2: Identify grammatical structure — Double verbal noun compound in genitive governing a postpositional phrase. This nominalization turns processes into a noun phrase.
- Step 3: Contextualize — Preceding sentence: "os eq>ls ckrsa djus dh ps"Vk djrs vkSj ikuh ihus osQ cgkus esjs ?kj vk tkrsA" (They try to talk and come to my house on the pretext of finding a place to stay).
- Step 4: Analyze function — The phrase masks intrusion as legitimate need. "cgkus" (effort/attempt) implies persistence; "ikuh ihus" reduces human dwelling to biological survival. The visitors (neighbors/relatives of employers) exploit the narrator's lack of privacy.
- Step 5: Connect to theme — This linguistic packaging reveals how language sanitizes power: "cgkus" frames exploitation as helpful effort; the narrator's home becomes a resource for others' "ikuh ihus."

REASONING: This example demonstrates morphological analysis as a vocabulary tool. The compound verbal noun "ikuh ihus" is not in dictionaries — its meaning emerges only through morphological decomposition + syntactic context + narrative situation. This is exactly the skill the node teaches.

ANSWER: "ikuh ihus osQ cgkus" = "on the pretext of efforts to secure lodging." Morphologically: two verbal nouns compounded (stay + become) + genitive + plural oblique noun (efforts). In context, it's a euphemism for powerful people invading the narrator's hard-won private space. The nominalization hides agency ("they come" → "efforts come"), making intrusion seem abstract and inevitable rather than a deliberate violation by specific people.

## WORKED_EXAMPLE_3
PROBLEM: Compare the honorific vocabulary used for three male figures: "lquhy" (first employer), "rkrq'k" (second employer/partner), "Hkksyk nk" (the old man who helps at the end). How do address terms and reference terms map power, intimacy, and respect across the narrative?

STEPS:
- Step 1: Catalog reference terms for lquhy — always "lquhy" (name/title), never honorific. Direct address: "csch" (respectful but distant, p.22, 26). No kinship term.
- Step 2: Catalog reference terms for rkrq'k — shifts from "rkrq'k" (name) to "rkrq'k" + "csch" (p.26) to "rkrq'k" alone as intimacy grows. Crucially, narrator calls him "rkrq'k" without honorific but HE calls her "csch" (p.36 "csch] rqEgsa...") then "rqe" (intimate) — asymmetric honorifics revealing gendered power.
- Step 3: Catalog reference terms for Hkksyk nk — "Hkksyk nk" (honorific "nk" = respected elder) consistently. Direct address: "Hkksyk nk" (p.32). Narrator uses "vki" (formal you) with him (p.32 "vki tc dgsaxs").
- Step 4: Analyze pattern — lquhy: professional distance maintained by both. rkrq'k: narrator maintains respect ("csch"), he shifts to intimacy ("rqe") — her vulnerability vs. his choice. Hkksyk nk: mutual formal respect ("vki", "nk") — egalitarian dignity.
- Step 5: Synthesize — Honorific vocabulary maps the chapter's core tension: the narrator extends respect universally (her dignity), but receives it selectively (social hierarchy). Only with Hkksyk nk is respect reciprocal.

REASONING: This example combines pragmatic analysis (address/reference terms) with narrative tracking. It shows vocabulary isn't just "words" but a system of social indexing. The 6-step analysis moves from data collection to pattern recognition to thematic synthesis — the full analytical arc expected at Class 11.

ANSWER: Three distinct honorific regimes: (1) lquhy — "lquhy" / "csch" — institutional distance, no kinship, respect one-way (narrator to employer). (2) rkrq'k — narrator: "rkrq'k" / "csch"; rkrq'k to narrator: shifts "csch" → "rqe" — asymmetric intimacy, he controls the register shift. (3) Hkksyk nk — mutual "Hkksyk nk" / "vki" — reciprocal formal respect, the only egalitarian male relationship. The vocabulary proves: narrator's dignity is in her consistent respect; society's failure is in not returning it.

## COMPETENCY_QUESTION_1
QUESTION: In the board exam, you may be asked: "How does the author use the word 'fp_h' (diary/writing) to structure the narrative's emotional arc? Give three specific textual instances with analysis." Write a model answer following the PEEL structure (Point, Evidence, Explanation, Link) for each instance.

COMPETENCY: Textual analysis with structured academic writing

STEPS:
- Step 1: Select three chronologically spaced instances of "fp_h" / "fy[kus" / "dgkuh" representing beginning, middle, end of writing journey.
- Step 2: For each, write a PEEL paragraph: Point (what the word signifies at this stage), Evidence (exact phrase with page), Explanation (how context shapes meaning), Link (connect to emotional arc).
- Step 3: Ensure vocabulary analysis drives the argument — not plot summary.
- Step 4: Use precise terminology: "semantic shift," "nominalization," "agency," "vocation."

ANSWER: Instance 1 (p.42): Point — "fp_h" as gifted object marking literacy's beginning. Evidence — "rkrq'k us viuh fy[kus dh Vsfcy osQ Mªkj ls ,d isu vkSj dkWih fudkyh." Explanation — "fp_h" enters as external tool (pencil/notebook from his pocket), passive reception ("fudkyh"). Link — Writing starts as dependence. Instance 2 (p.46): Point — "dgkuh" (story) as self-reclamation. Evidence — "tsBw us mUgsa viuh dgkuh dks fdlh ,d eksM+ rd igq¡pkuk gksxk." Explanation — "dgkuh" replaces "fp_h"; her life becomes narratable. "igq¡pkuk" (reach a stage) shows agency. Link — Writing becomes voice. Instance 3 (p.50): Point — "fy[kus" as professional identity. Evidence — "vc rd ftruk eSa fy[k pqdh Fkh mls rkrq'k us I+kQksVks&dkWih djk osQ vius ,d caèkq osQ ikl dksydkrk Hkst fn;k Fkk." Explanation — "fy[kus" (infinitive as noun) = THE work. "I+kQksVks&dkWih" (dedication) marks public recognition. Link — Writing becomes vocation. The arc: object → voice → vocation.

DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: The chapter uses "yM+dh" to refer to four different women: (1) the narrator's first employer (p.21), (2) rkrq'k's mother (p.36), (3) the narrator herself as rkrq'k's partner (p.36), (4) lquhfr (p.41). Create a 4-row analytical table with columns: Referent | Contextual Meaning | Power Dynamic | Narrator's Attitude. Then write a 150-word synthesis explaining how this single word exposes the chapter's critique of gendered labor.

COMPETENCY: Comparative semantic analysis and thematic synthesis

STEPS:
- Step 1: Extract each referent's context — who calls whom "yM+dh," in what situation, with what tone.
- Step 2: Fill table with precise analysis — avoid vague labels like "positive/negative."
- Step 3: Write synthesis using table data — focus on how "yM+dh" reveals the fiction of "mistress" as a stable category.
- Step 4: Connect to the chapter's final message about women's solidarity across class.

ANSWER: Table: (1) First employer | Transactional authority | Employer owns labor, narrator owns nothing | Fear, submission. (2) rkrq'k's mother | Maternal domestic authority | Traditional hierarchy, narrator as outsider | Awe, distance ("tokc nsus esa 'kje vk jgh Fkh"). (3) Narrator (as rkrq'k's claim) | Chosen partnership | He redefines term: "eSa rqEgsa viuh yM+dh tSlk ekurk gw¡" | Shock, then acceptance ("cgqr [kq'k gqbZ"). (4) lquhfr | Professional peer/mentor | Published writer guiding another | Respect, aspiration ("mUgsa pkgrs Fks] rqe nwljh vk'kkiw.kkZ nsoh cu ldrh gks"). Synthesis: "yM+dh" begins as a cage (employer's power), becomes a bridge (rkrq'k's radical redefinition), and ends as a horizon (lquhfr's achieved identity). The word exposes how "mistress" is not a fixed role but a site of struggle — the narrator refuses to be anyone's "yM+dh" in the old sense, yet the word persists, transformed. The chapter's feminism lies in this lexical hijacking: the same word that once marked her subordination finally marks her arrival.

DIFFICULTY: hard