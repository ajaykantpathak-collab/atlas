## DEFINITION
Narrative structure in poetry refers to the organized sequence of stanzas, images, and emotional beats that guides the reader through a coherent journey from opening situation to resolution, using devices like refrain, repetition, and thematic progression rather than conventional plot events.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student can trace the poem's narrative arc across all stanzas, identify how structural devices (refrain, parallelism, tonal shifts) organize the emotional journey, and explain how the structure reinforces the central theme of memory and belonging.

## SCOPE_BOUNDARY
This node covers stanza-level organization, narrative progression, and structural devices (refrain, repetition, circular patterning) in "Ghar ki Yaad." It does NOT cover setting/atmosphere analysis (node 003), character analysis (nodes 004-005), or thematic deep-dives (nodes 006-007).

## WALKTHROUGH
Imagine listening to a grandmother's story where she repeats a chorus after every few lines — that chorus isn't decoration; it's the heartbeat holding the story together. Begin by reading the poem aloud twice: first for flow, second to mark every recurring line ("ikuh fxj jgk gS," "?kj u"kj esa frj jgk gS"). Notice how the poem moves from physical description (walls, rooms) to emotional memory (father's voice, mother's cooking) to philosophical reflection (identity, time). The key insight: the refrain acts as an anchor, pulling the wandering memory back to the core truth — home is not a building but a living presence in the speaker.

## DIAGNOSTIC_QUESTION_1
What is the primary structural device that organizes the narrative progression in "Ghar ki Yaad," and how frequently does it appear in the poem?

## DIAGNOSTIC_ANSWER_1
The primary structural device is the refrain — the repeated couplet "ikuh fxj jgk gS / ?kj u"kj esa frj jgk gS" — which appears at the end of every alternate stanza (stanzas 1, 3, 5, 7, 9, 11), creating a six-beat pulse that structures the entire 12-stanza poem. A wrong answer (e.g., "rhyme scheme" or "metaphor") reveals the student is confusing poetic devices with narrative structure; they need to distinguish between decorative elements and architectural ones that shape the poem's journey.

## DIAGNOSTIC_QUESTION_2
Explain in your own words how the refrain functions differently in the first stanza versus the final stanza, even though the words are identical.

## DIAGNOSTIC_ANSWER_2
In stanza 1, the refrain states a present observation ("the house stands silent") — a factual opening. In stanza 12, the same words carry accumulated emotional weight: after 11 stanzas of memories, the silence is no longer empty but *full* of voices, making the refrain a resonant echo rather than a simple statement. A wrong answer treating both occurrences as identical shows the student misses how context transforms meaning — a critical skill for analyzing poetic narrative where repetition deepens rather than merely repeats.

## DIAGNOSTIC_QUESTION_3
Map the poem's narrative progression by identifying the dominant focus of stanzas 1-4, 5-8, and 9-12. What shifts occur between these three phases?

## DIAGNOSTIC_ANSWER_3
Phase 1 (stanzas 1-4): Physical house — walls, rooms, courtyard, sensory details (smell of food, sound of rain). Phase 2 (stanzas 5-8): Human presence — father's voice, mother's cooking, siblings' games, specific rituals. Phase 3 (stanzas 9-12): Internal landscape — speaker's identity ("ik¡pok¡ eSa gw¡ vHkkxk"), philosophical realization ("?kj ugha gw¡ cl ;gh gS"), address to future generations. The shift is from *external/ concrete* → *relational/ emotional* → *abstract/ existential*. A wrong answer listing random images shows the student cannot perceive macro-structure; they need practice grouping stanzas by thematic cluster.

## DIAGNOSTIC_QUESTION_4
Compare the narrative function of the father's voice (stanzas 5-6) and the speaker's own voice (stanzas 9-10). How does the poem use these two voices to structure its argument about memory?

## DIAGNOSTIC_ANSWER_4
The father's voice represents *transmitted memory* — authoritative, directive ("firk th dgrs jgs gSa / I;kj esa cgrs jgs gSa"), preserving tradition. The speaker's voice represents *internalized memory* — questioning, asserting ownership ("eSa e"ks esa gw¡ lgh gS / ?kj ugha gw¡ cl ;gh gS"). The structure moves from receiving memory (father speaking *to* speaker) to claiming memory (speaking *for* self), proving memory becomes identity only when actively possessed. A wrong answer describing both as "characters" misses the structural role: voices are narrative mechanisms, not just people.

## DIAGNOSTIC_QUESTION_5
Evaluate whether the poem's circular structure (ending with the refrain that opened it) strengthens or weakens its narrative impact. Justify with two specific textual reasons.

## DIAGNOSTIC_ANSWER_5
It strengthens impact. Reason 1: Circular return transforms the opening's *observation* into *realization* — the house "standing silent" becomes the house "living in me." Reason 2: The refrain's sixth recurrence in stanza 12 arrives after the speaker declares "eSa dke djrk gw¡ fd dguk" (I work to speak), making the final silence an *active choice* to carry the house forward, not passive abandonment. A wrong answer calling it "repetitive" or "boring" reveals a prose-bias: expecting linear resolution instead of poetic resonance where return = deepening.

## DIAGNOSTIC_QUESTION_6
Write a four-line stanza that could follow stanza 12, maintaining the poem's narrative structure and refrain pattern, advancing the speaker's relationship with memory.

## DIAGNOSTIC_ANSWER_6
Strong answer example: "ab mere bachche puchhenge / ye deewarein kya kehtee hain / main kehunga: ye boltee hain / ikuh fxj jgk gS, ?kj u"kj esa frj jgk gS." This works because it: (a) extends the narrative to the next generation (forward movement), (b) shows memory becoming legacy (thematic consistency), (c) places the refrain as the *answer* to a question (structural logic), (d) keeps the meter and tone. A poor answer adds random imagery or breaks the refrain pattern, showing the student hasn't internalized the poem's structural grammar.

## COMMON_MISCONCEPTION
Students believe "plot" only exists in stories with events (he did this, then that happened) and therefore poems *lack* narrative structure. They search for physical actions in "Ghar ki Yaad" and find none, concluding the poem is "just descriptions." The error: confusing *event-driven plot* (prose) with *consciousness-driven narrative arc* (poetry). In this poem, the "events" are mental acts — remembering, comparing, realizing, deciding — and the structure traces the speaker's inner journey from "house outside me" to "house inside me."

## ON_FAILURE
Step 1: Have the student read only the first and last stanza aloud side-by-side. Ask: "Same words — different feeling? Why?" Step 2: Give them 12 index cards, one per stanza. Ask them to sort into 3 piles of 4 by "what this stanza is *doing*." Step 3: Label piles together: "Outside → Inside → Beyond." Step 4: Trace the refrain cards — notice they sit at the *end* of piles 1 and 2, but *inside* pile 3's final card. Step 5: Write one sentence: "The structure moves the house from ______ to ______ to ______." This makes the invisible architecture visible.

## BUILDS_ON
c11_hin_ar_cbse_11_001 (Context and Background) — knowledge of Bachchan's life, the Chhayavaad movement, and the poem's autobiographical roots provides the biographical lens through which the narrative structure gains personal resonance.

## LEADS_TO
c11_hin_ar_cbse_11_003 (Setting and Atmosphere) — the narrative structure's three phases (physical → relational → existential) directly map to how setting evolves from backdrop to emotional landscape to symbolic space.

## PREREQUISITE_NODE_IDS
c11_hin_ar_cbse_11_001
## PREREQUISITE_REASONS
c11_hin_ar_cbse_11_001: Understanding Bachchan's displacement from Allahabad, his father's influence, and the Chhayavaad emphasis on personal emotion provides the necessary context to recognize the poem's narrative as autobiographical memory-work rather than fictional invention.

## FORWARD_NODE_IDS
c11_hin_ar_cbse_11_003, c11_hin_ar_cbse_11_004, c11_hin_ar_cbse_11_005, c11_hin_ar_cbse_11_006, c11_hin_ar_cbse_11_007, c11_hin_ar_cbse_11_008, c11_hin_ar_cbse_11_009, c11_hin_ar_cbse_11_010, c11_hin_ar_cbse_11_011, c11_hin_ar_cbse_11_012, c11_hin_ar_cbse_11_014, c11_hin_ar_cbse_11_015, c12_hin_a_cbse_09_002, c12_hin_a_cbse_11_002, c12_hin_ar_cbse_11_002, c12_hin_ar_cbse_11_001

## FORWARD_REASONS
c11_hin_ar_cbse_11_003: The narrative structure's three-phase progression (physical house → lived-in home → internalized memory) sets up the analysis of how setting shifts from static backdrop to dynamic emotional atmosphere across the same stanzas.
c11_hin_ar_cbse_11_004: The structural distinction between "father's voice" (transmitted memory) and "speaker's voice" (claimed identity) establishes the protagonist's character arc from passive recipient to active narrator.
c11_hin_ar_cbse_11_005: Establishes the poem's narrative structure (refrain-driven, non-linear memory) so students can track where supporting characters appear across stanzas.  
c11_hin_ar_cbse_11_006: Establishes the poem's non-linear narrative structure — the movement from present longing to past scenes to future vow — which the theme analysis must follow.  
c11_hin_ar_cbse_11_007: Knowledge of plot/narrative structure helps locate where in the poem's progression each secondary theme appears and peaks.  
c11_hin_ar_cbse_11_008: Establishes the poem's narrative structure (memory unfolding in stages) so devices can be mapped to structural shifts.  
c11_hin_ar_cbse_11_009: Establishes the narrative structure and key events, needed to situate ironic moments in the poem's progression.  
c11_hin_ar_cbse_11_010: Establishes the narrative arc; vocabulary shifts across stanzas (e.g., 'ikuh' in stanza 1 vs 'yhd' in last) map onto plot progression.  
c11_hin_ar_cbse_11_011: Plot and narrative structure analysis (or in the case of a poem, the structural arc — opening, development, climax, resolution) establishes where grammatical features appear in the poem's movement, which is essential because tense shifts and repetition patterns are *structurally positioned* — they occur at specific points in the poem's arc for specific reasons.  
c11_hin_ar_cbse_11_012: Plot/narrative structure provides the sequence of events for literal retrieval.  
c11_hin_ar_cbse_11_014: Plot/narrative structure understanding helps sequence evidence logically.  
c11_hin_ar_cbse_11_015: Plot and narrative structure — the poem's 12-stanza architecture mirrors the cyclic refrain; students must grasp this macro-structure to discuss micro-shifts.  
c12_hin_a_cbse_09_002: Covered grammar of narrative tense/aspect.  
c12_hin_a_cbse_11_002: Establishes baseline plot analysis vocabulary (exposition, climax, etc.) and practice with linear narratives.  
c12_hin_ar_cbse_11_002: Introduces Freytag's pyramid and narrative terminology; this node applies those tools to a complex satirical text.  
c12_hin_ar_cbse_11_001: If stuck on "psychoanalytic story" definition: Re-read c11_hin_ar_cbse_11_002 (Plot of R;kxi=k) and c11_hin_ar_cbse_11_004 (Character Analysis of R;kxi=k protagonist) — they demonstrate the method in action.  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
none

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_11_001 -> c11_hin_ar_cbse_11_002 -> c11_hin_ar_cbse_11_003

## THIS_FORMULA
Narrative Arc = Σ (Stanza Cluster_i × Structural Device_i) where Structural Device ∈ {Refrain, Parallelism, Tonal Shift, Voice Shift} and Cluster_i ∈ {Physical, Relational, Existential}

## FORMULA_VARIABLES
Stanza Cluster_i: Group of stanzas sharing dominant focus (Physical=1-4, Relational=5-8, Existential=9-12); Structural Device_i: Organizing mechanism operating in that cluster (Refrain anchors all, Parallelism dominates cluster 1, Voice Shift dominates cluster 2, First-person assertion dominates cluster 3)

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
analytical

## CROSS_SUBJECT
c11_history_oral_tradition | The refrain structure mirrors oral storytelling traditions where repeated choruses anchor collective memory across generations — Bachchan uses this to make personal memory feel communal.
c11_psychology_narrative_identity | The poem's arc from external house to internalized "ghar" illustrates McAdams' narrative identity theory: we become who we are by integrating memories into a coherent life story, exactly as the speaker does in stanzas 9-12.

## PREREQ_CONCEPT
Understanding that poetry can have a narrative arc driven by consciousness rather than external events.

## PREREQ_BEFORE
Student must know the poem's basic storyline (speaker remembers childhood home) and recognize the refrain when hearing it.

## PREREQ_STUCK
Review the concept of "lyric narrative" — poems that tell a story through emotional progression rather than plot events — using a simpler example like a film song with verses and chorus.

## WORKED_EXAMPLE_1
PROBLEM: Analyze how the refrain "ikuh fxj jgk gS / ?kj u"kj esa frj jgk gS" structures the narrative timeline of the poem across its six appearances.

STEPS:
- Step 1: Locate all six refrain occurrences by stanza number (1, 3, 5, 7, 9, 11) and note what immediately precedes each.
- Step 2: Categorize the preceding content: Stanza 1 = physical description; Stanza 3 = sensory details (rain, smell); Stanza 5 = father's voice enters; Stanza 7 = mother's rituals; Stanza 9 = speaker's identity claim; Stanza 11 = address to future generations.
- Step 3: Observe the pattern — each refrain is preceded by a *new layer* of memory added to the house, making the refrain a cumulative checkpoint: "After adding this memory, the house still stands."
- Step 4: Note the timing — refrains appear at regular 2-stanza intervals, creating a rhythmic heartbeat that measures the poem's emotional time, not clock time.
- Step 5: Synthesize: The refrain transforms from a static description (stanza 1) into a living testament (stanza 11) because each recurrence carries the weight of all preceding stanzas.

REASONING: This step-by-step tracing reveals that the refrain is not decorative repetition but a structural scaffold — each recurrence marks a completed "memory deposit," and the final refrain holds the full accumulation. The regular spacing mimics how memory works in waves, not linear flow.

ANSWER: The refrain acts as a structural metronome marking six stages of memory accumulation: physical → sensory → paternal → maternal → personal → generational. Its fixed position (end of odd stanzas) creates a predictable return that contrasts with the expanding emotional content, embodying the poem's central tension: the house remains constant ("ikuh fxj jgk gS") while the speaker's relationship to it deepens infinitely.

## WORKED_EXAMPLE_2
PROBLEM: Trace the shift from third-person observation to first-person assertion across the poem's three phases, citing one key line from each phase that marks the transition.

STEPS:
- Step 1: Define the three phases by stanza groups (1-4, 5-8, 9-12) based on dominant perspective.
- Step 2: Phase 1 (stanzas 1-4) — identify the observational language: "vkt ikuh fxj jgk gS" (present tense, impersonal), "jkr Hkj fxjrk jgk gS" (descriptive). No "I" appears.
- Step 3: Phase 2 (stanzas 5-8) — locate the entry of relational voices: "firk th ftudks cq<+kik" (father described in third person), "ek¡ us dgk gksxk" (mother's anticipated speech). The "I" is still absent; memory is witnessed, not owned.
- Step 4: Phase 3 (stanzas 9-12) — find the first-person explosion: "ik¡pok¡ eSa gw¡ vHkkxk" (stanza 9, line 1), "eSa e"ks esa gw¡ lgh gS" (stanza 10), "dke djrk gw¡ fd dguk" (stanza 11). The speaker claims agency.
- Step 5: Connect to structure: The narrative doesn't just *contain* a perspective shift — its architecture *enacts* it. The refrain's silence in stanzas 2,4,6,8,10,12 creates space for the "I" to emerge gradually.

REASONING: This analysis shows how narrative structure in lyric poetry manages point-of-view as a structural element. The delayed first-person emergence (stanza 9 of 12) is a deliberate structural choice — the speaker must first inherit memory (phases 1-2) before authoring it (phase 3).

ANSWER: Phase 1 key line: "vkt ikuh fxj jgk gS" (impersonal observation). Phase 2 key line: "firk th dgrs jgs gSa / I;kj esa cgrs jgs gSa" (memory mediated through father's voice). Phase 3 key line: "ik¡pok¡ eSa gw¡ vHkkxk / ftls lksus ij lqgkxk" (direct assertion of self-as-memory-keeper). The structure moves from *house observed* → *house remembered by others* → *house lived in me*.

## WORKED_EXAMPLE_3
PROBLEM: The poem uses parallelism in stanzas 5-8 (father/mother, past/future, speech/silence). Explain how this parallelism structures the poem's argument about what constitutes "home."

STEPS:
- Step 1: Identify the parallel pairs in stanzas 5-8: Father/Mother (stanzas 5-6 vs 7-8), Past voice/Future voice ("dgrs jgs gSa" vs "dgk gksxk"), Spoken/Unspoken ("dguk" vs "ugha dguk"), Visible/Invisible ("ilkjk" vs "ugha ilkjk").
- Step 2: Map each pair to a dimension of home: Father = authority/tradition; Mother = nurture/continuity. Past = what was said; Future = what will be understood. Spoken = explicit teaching; Unspoken = absorbed values.
- Step 3: Observe the structural effect — parallelism creates *balance*, suggesting home is not one thing (not just father's discipline, not just mother's love) but the *tension and harmony* between opposites.
- Step 4: Connect to the refrain — the parallel stanzas (5-6 and 7-8) are each capped by the refrain, meaning *both* father's and mother's memories are equally "house-standing" truths.
- Step 5: Extend to phase 3 — the speaker's synthesis in stanza 9 ("eSa muij lqgkxk / c¡èkk cSBk gw¡ vHkkxk") resolves the parallels by claiming *both* lineages: "I am attentive to them" (father's discipline) AND "my mother said" (mother's intuition).
- Step 6: Conclude: The parallelism structures the poem's definition of home as *dialectical* — built from complementary forces — and the narrative arc is the speaker learning to hold both.

REASONING: This worked example demonstrates how to analyze structural parallelism as argumentation. In senior secondary exams, students must move beyond "identifying" devices to explaining how they *build* the poem's meaning. The 6-step process models the depth expected: identify → map → interpret structural function → connect to refrain → trace forward resolution → synthesize.

ANSWER: The parallelism in stanzas 5-8 constructs home as a dialectical space: father's explicit instruction ("dgrs jgs gSa") balances mother's implicit wisdom ("dgk gksxk"), spoken lessons ("dguk") balance unspoken absorption ("ugha dguk"). The refrain's return after *each* parallel pair validates both as structural pillars. The narrative arc completes when the speaker in phase 3 integrates both — becoming the "c¡èkk cSBk" (attentive listener) to father and the voice that "dke djrk gw¡ fd dguk" (works to speak) like mother. Home = the synthesis of inherited opposites.

## COMPETENCY_QUESTION_1
QUESTION: The poem's narrative structure relies on a tension between stasis (the refrain's unchanging house) and flux (the accumulating memories). Choose THREE stanzas where this tension is most sharply felt, and explain how the structure uses that tension to redefine "home" by the end.

COMPETENCY: Analytical reasoning with textual evidence — ability to identify structural tension, select relevant evidence across the text, and synthesize a thematic claim.

STEPS:
- Step 1: Identify the two poles — stasis = refrain's "ikuh fxj jgk gS" (unchanging); flux = new memories in each stanza pair.
- Step 2: Select three stanzas where new memory directly precedes the refrain, creating maximum tension: Stanza 3 (sensory flux: rain, smell vs. silent house), Stanza 7 (mother's living rituals vs. silent house), Stanza 11 (speaker's active vow "dke djrk gw¡ fd dguk" vs. silent house).
- Step 3: For each, explain the friction: Stanza 3 — house is silent but senses scream life; Stanza 7 — house is empty but mother's routines fill it; Stanza 11 — house is past but speaker makes it future.
- Step 4: Synthesize: The structure *requires* this tension — if the house truly stood silent and unchanged, memory would be mere nostalgia. The friction proves the house *lives* in memory, redefining home as "that which grows inside you when you carry it."

ANSWER: Stanza 3: Sensory flux (rain on courtyard, smell of earth) crashes against refrain's silence — home persists *through* sensation. Stanza 7: Mother's active rituals (cooking, feeding, naming) contradict the empty courtyard — home persists *through* care. Stanza 11: Speaker's declaration "I work to speak / not to speak for speaking's sake" transforms the house from relic to responsibility — home persists *through* conscious transmission. The structure uses accumulating friction to prove: home is not the building that stands silent, but the life that refuses to let it be silent.

DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: "Ghar ki Yaad" has 12 stanzas — an even number — yet the refrain appears 6 times (odd-numbered stanzas only). The final stanza (12) does *not* end with the refrain but with a direct address to the reader ("er djks oqQN 'kksd dguk"). Evaluate how this structural asymmetry shapes the poem's narrative closure. Does the poem end *in* the house or *outside* it?

COMPETENCY: Structural evaluation — ability to analyze formal choices (stanza count, refrain placement, final deviation) as narrative decisions with thematic consequences.

STEPS:
- Step 1: Note the pattern — 12 stanzas, refrain at 1,3,5,7,9,11. Stanza 12 breaks the pattern: no refrain, new voice (imperative address).
- Step 2: Interpret the break — the refrain has been the "house's voice." Its absence in stanza 12 means the house *stops speaking*; the speaker speaks *for* it.
- Step 3: Analyze the final lines: "er djks oqQN 'kksd dguk" (don't let anyone say empty words) — this is the speaker protecting the house's truth from trivialization.
- Step 4: Determine location — the poem ends *outside* the physical house (addressing readers/listeners) but *inside* the carried house (speaker as guardian).
- Step 5: Evaluate closure — asymmetrical ending refuses false symmetry. A 13th stanza with refrain would suggest "memory complete." The break says "memory continues in action."

ANSWER: The poem ends *outside* the physical house but *inside* the internalized one. The structural asymmetry (12 stanzas, 6 refrains, final stanza breaking pattern) enacts the speaker's graduation from *inhabitant* to *carrier*. The refrain's silence in stanza 12 is not absence — it's transference. The house no longer "stands" (ikuh fxj); it *walks* in the speaker's command to "not let empty words be spoken." Closure is not return but departure-with-possession — the narrative structure's final move.

DIFFICULTY: hard