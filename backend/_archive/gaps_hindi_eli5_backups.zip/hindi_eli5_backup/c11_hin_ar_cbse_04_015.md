## DEFINITION
Speaking and Listening: Discussion Points refers to the structured oral communication skills where students engage in analytical dialogue about literary texts, using textual evidence to support arguments, practicing active listening, and developing coherent spoken responses that demonstrate critical thinking about themes, characters, and authorial intent.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student can independently initiate and sustain a 3-minute structured discussion on the chapter's colonial critique, citing at least three specific textual references, responding to counter-arguments with evidence, and maintaining formal Hindi register appropriate for academic discourse.

## SCOPE_BOUNDARY
This node covers formal discussion techniques, evidence-based argumentation, active listening strategies, and academic Hindi register for literary analysis of "फोनबूथ लहक". It does NOT cover creative writing, grammar drills, or basic comprehension questions already addressed in nodes 012-013.

## WALKTHROUGH
Imagine you're in a college seminar where the professor asks: "How does Vaid use satire to expose colonial hypocrisy in this text?" You freeze because you've only written answers, never spoken them. Start by identifying ONE powerful irony from the text — like the Viceroy claiming to bring "civilization" while the narrator exposes exploitation. Practice saying aloud: "व्यंग्य में वायसराय की 'सभ्यता' का दावा तब खोखला लगता है जब..." — this is your opening claim. Next, pull a specific line as evidence. Then anticipate a classmate's counter-view ("लेकिन वायसराय ने विकास भी किया") and prepare your rebuttal with another textual detail. The key insight: spoken analysis requires the SAME evidence-thinking as writing, but compressed into real-time verbal structure — claim, evidence, reasoning, link — delivered with eye contact and measured pace.

## DIAGNOSTIC_QUESTION_1
Define "academic register" (शैक्षिक शैली) in the context of a Hindi literary discussion. How does it differ from casual conversation?

## DIAGNOSTIC_ANSWER_1
Academic register uses formal vocabulary (तत्सम शब्द like 'शोषण', 'विडंबना', 'उपनिवेशवाद'), complete sentences with proper syntax, impersonal tone (avoiding 'मुझे लगता है', using 'पाठ से स्पष्ट होता है'), and structured argumentation (claim-evidence-reasoning). A wrong answer — "just speaking properly" — reveals the student confuses register with mere politeness, missing the disciplinary vocabulary and logical architecture required for literary discourse.

## DIAGNOSTIC_QUESTION_2
A student says: "This chapter is just about a British officer being rude." Explain why this interpretation fails to meet the analytical standard for Class 11 discussion.

## DIAGNOSTIC_ANSWER_2
The interpretation reduces a complex satirical text to a single behavioral observation, ignoring: (1) the historical allegory (Curzon as colonialism personified), (2) the structural irony (the narrator's subversive mimicry), (3) the thematic depth (cultural erasure, economic exploitation, epistemic violence). A wrong answer reveals the student reads literally, missing allegory and authorial strategy — a Class 10 habit that must be unlearned for senior secondary analysis.

## DIAGNOSTIC_QUESTION_3
During a discussion, a peer argues: "Vaid's narrator is unrealistic — no Indian could speak so boldly to a Viceroy." Using textual evidence, formulate a spoken rebuttal that defends the text's artistic choice.

## DIAGNOSTIC_ANSWER_3
Rebuttal structure: (1) Acknowledge the surface implausibility — "सतही तौर पर यह अविश्वसनीय लगता है" (2) Identify the device — "लेकिन यह यथार्थवादी चित्रण नहीं, व्यंग्यात्मक कल्पना (satirical fantasy) है" (3) Cite evidence — "पाठ में वायसराय स्वयं स्वीकार करता है: 'तुम्हारी हिम्मत कैसे हुई...' जो दर्शाता है कि लेखक सत्ता के सामने प्रतिरोध की संभावना रच रहा है" (4) Connect to theme — "यह 'असंभव' संवाद ही उपनिवेशवाद की नैतिक खोखलेपन को उजागर करता है।" A weak answer merely disagrees without naming the literary device or citing text.

## DIAGNOSTIC_QUESTION_4
Compare two discussion approaches: (A) Listing all themes you remember from the chapter. (B) Tracing ONE theme (e.g., 'epistemic violence') through three specific textual moments with analysis. Which demonstrates higher-order thinking? Justify.

## DIAGNOSTIC_ANSWER_4
Approach B demonstrates analysis (Bloom's Level 4) because it: (1) selects and narrows focus, (2) synthesizes evidence across the text, (3) explains HOW the theme operates (not just THAT it exists), (4) reveals authorial craft. Approach A is mere recall (Level 1). A student choosing A reveals they equate "discussion" with "information dump" — a fundamental misconception about academic dialogue.

## DIAGNOSTIC_QUESTION_5
Evaluate this discussion contribution: "I think the ending is hopeful because the narrator wins the argument." Provide a critique using textual evidence and suggest how to reframe it analytically.

## DIAGNOSTIC_ANSWER_5
Critique: The claim misreads the ending's ambiguity — the Viceroy's departure is tactical, not defeat ("अभी तो यह शुरुआत है" implies ongoing struggle). The word "wins" imposes a binary victory narrative on a text that resists closure. Analytical reframe: "The ending refuses resolution: the narrator's rhetorical victory (व्यंग्यात्मक विजय) coexists with historical reality (इतिहास की वास्तविकता) where Curzon's policies continued. This tension — between discursive triumph and material continuity — is precisely Vaid's critique of anti-colonial discourse." A poor evaluation accepts the surface reading without interrogating the text's complexity.

## DIAGNOSTIC_QUESTION_6
Create a 90-second opening statement for a formal discussion on: "How does Vaid use the Viceroy's own language to expose colonial contradictions?" Include: thesis, two textual anchors, and a bridging question for the group.

## DIAGNOSTIC_ANSWER_6
Model opening: "थीसिस: वैद वायसराय की भाषा को ही उसके विरुद्ध हथियार बनाते हैं — उसकी 'सभ्यता' की शब्दावली (vocabulary of civilization) उसके शोषण को ढकने का आवरण बन जाती है। पहला प्रमाण: वायसराय 'विकास' (development) शब्द का प्रयोग करता है, पर पाठ दिखाता है कि यह 'विकास' केवल ब्रिटिश हितों की पूर्ति करता है — 'रेलवे भारतीयों के लिए नहीं, कच्चे माल की ढुलाई के लिए'। दूसरा प्रमाण: 'कानून और व्यवस्था' (law and order) का नारा तब खोखला लगता है जब वायसराय स्वयं स्वीकार करता है कि 'न्याय केवल शासकों के लिए'। ब्रिजिंग प्रश्न: क्या आपको लगता है कि भाषा का यह आत्म-विरोधाभास (self-contradiction) केवल औपनिवेशिक संदर्भ में है, या समकालीन सत्ता-भाषा में भी दिखता है?" A weak answer lacks thesis clarity, uses vague references, or omits the bridging question that invites dialogue.

## COMMON_MISCONCEPTION
Students believe "discussion" means taking turns sharing opinions ("मुझे लगता है...", "मेरी राय में...") without textual anchoring. They treat literary discussion as personal reaction-sharing rather than evidence-based collective inquiry. This stems from Class 10 "speaking skills" activities that prioritized fluency over analytical rigor. In senior secondary, the examiner expects: (1) every claim tied to a specific textual moment, (2) engagement with peers' arguments (agree/disagree/extend), (3) disciplinary vocabulary (व्यंग्य, विडंबना, रूपक, उपनिवेशवादी विमर्श). The error is not "speaking poorly" but "thinking aloud without analytical scaffolding."

## ON_FAILURE
If a student defaults to opinion-sharing: (1) Interrupt gently: "रुकिए — यह आपकी राय है, लेकिन पाठ में इसका आधार कहाँ है?" (2) Model the pivot: "चलिए, पृष्ठ 47 पर वायसराय का संवाद देखते हैं — वहाँ वह क्या कहता है जो आपके बिंदु का समर्थन या खंडन करता है?" (3) Co-construct one analytical turn together: claim + quote + analysis. (4) Assign a "textual evidence quota" for next practice: minimum 3 specific references in 2 minutes. (5) Record and replay — students hear their own "मुझे लगता है" patterns and self-correct.

## BUILDS_ON
Critical Thinking: Analysis and Interpretation (node 013) — students must first develop written analytical habits before transferring them to real-time oral discourse.

## LEADS_TO
Writing Skills: Based on the Chapter (node 014) — oral discussion rehearses the argument structures that written answers formalize; the claim-evidence-reasoning loop is identical across modalities.

## PREREQUISITE_NODE_IDS
c11_hin_ar_cbse_04_013, c11_hin_ar_cbse_04_006, c11_hin_ar_cbse_04_008, c11_hin_ar_cbse_04_009, c11_hin_ar_cbse_04_007, c11_hin_ar_cbse_04_010

## PREREQUISITE_REASONS
c11_hin_ar_cbse_04_013: Provides the analytical framework (identifying irony, allegory, authorial intent) that discussion verbalizes.
c11_hin_ar_cbse_04_006: Supplies the primary theme (colonial critique) that anchors all discussion points.
c11_hin_ar_cbse_04_008: Equips students to name and discuss imagery/metaphor as textual evidence during dialogue.
c11_hin_ar_cbse_04_009: Enables identification of irony and symbolism — the core devices Vaid uses — for citation in spoken arguments.
c11_hin_ar_cbse_04_007: Discussion points emerge from thematic debates.  
c11_hin_ar_cbse_04_010: Discussion points require articulating nuanced word meanings (e.g., "What does 'फकीरचंद' represent?").  

## FORWARD_NODE_IDS
c12_hin_a_cbse_12_015, c12_hin_al_cbse_02_015, c12_hin_al_cbse_03_015, c12_hin_ar_cbse_04_015, c12_hin_ar_cbse_12_015

## FORWARD_REASONS
c12_hin_a_cbse_12_015: अगला तार्किक चरण: Speaking and Listening: इस नोड की अवधारणाओं को सीधे उपयोग/विस्तारित करता है।  
c12_hin_al_cbse_02_015: Practice in evidence-based speaking from Class 11 texts.  
c12_hin_al_cbse_03_015: Practice with literary texts in oral mode  
c12_hin_ar_cbse_04_015: Class 11 speaking/listening baseline — assumes familiarity with discussion protocols (turn-taking, summarizing).  
c12_hin_ar_cbse_12_015: अगला तार्किक चरण: Speaking and Listening: इस नोड की अवधारणाओं को सीधे उपयोग/विस्तारित करता है।  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
none

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_04_013 -> c11_hin_ar_cbse_04_015 -> c11_hin_ar_cbse_04_014

## THIS_FORMULA
N/A - conceptual

## FORMULA_VARIABLES
N/A

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
linguistic

## CROSS_SUBJECT
c11_history_colonialism | The chapter's critique of Curzon's viceroyalty (1899-1905) directly parallels History curriculum on colonial policies — Partition of Bengal, land revenue systems, educational reforms — allowing students to use historical facts as contextual evidence in literary discussions.
c11_political_science_colonial_discourse | The text's exposure of "civilizing mission" rhetoric mirrors Political Science's study of colonial discourse (Macaulay's Minute, Orientalist-Anglicist debate) — students can connect Vaid's literary satire to the actual ideological apparatus of empire.

## PREREQ_CONCEPT
Evidence-based literary analysis: the habit of grounding every interpretive claim in a specific textual moment with explanatory reasoning.

## PREREQ_BEFORE
Student can write a structured analytical paragraph (PEEL: Point, Evidence, Explanation, Link) on the chapter's themes using textual quotes.

## PREREQ_STUCK
Review "Critical Thinking: Analysis and Interpretation" (node 013) — specifically the worked examples showing how to move from observation to analysis using textual evidence.

## WORKED_EXAMPLE_1
PROBLEM: A student must deliver a 2-minute spoken analysis on: "How does the narrator's mimicry of the Viceroy's language function as resistance?" The student has written notes but freezes when speaking.
STEPS:
- Step 1: Identify the core concept — mimicry as subversion (Bhabha's concept, simplified: "शत्रु की भाषा को अपना कर उसे उलट देना").
- Step 2: Select TWO precise textual anchors — (a) Viceroy's "विकास" / narrator's redefinition as "लूट", (b) Viceroy's "न्याय" / narrator's exposure of "न्याय केवल शासकों के लिए".
- Step 3: Structure the spoken turn using oral PEEL: Claim (15 sec) → Evidence 1 with line reference (30 sec) → Analysis of HOW mimicry works here (30 sec) → Evidence 2 + analysis (30 sec) → Link to broader theme (15 sec).
- Step 4: Rehearse aloud with timer, replacing written connectors ("फिर", "इसके अलावा") with spoken signposts ("पहला उदाहरण देखें...", "यहाँ गौर करने लायक बात है...", "इससे स्पष्ट होता है कि...").
- Step 5: Anticipate one follow-up question ("क्या यह नकल केवल व्यंग्य है या वास्तविक प्रतिरोध?") and prepare a 30-second response citing the narrator's final challenge: "तुम्हारे जाने के बाद भी हमारी लड़ाई जारी रहेगी।
REASONING: Written analysis allows revision; spoken analysis demands pre-structured chunks and signpost language. The 5-step process converts silent knowledge into performable speech units.
ANSWER: Delivered speech: "केंद्रीय दावा: वैद का कथावाचक वायसराय की भाषा की नकल नहीं करता, उसे विकृत (subvert) करता है। पहला प्रमाण: पृष्ठ 46 पर वायसराय 'विकास' कहता है — रेल, नहर, कानून। कथावाचक तुरंत उसी शब्द को पकड़ कर पूछता है: 'किसका विकास? रेलवे भारतीयों के लिए नहीं, कपास ढोने के लिए।' यहाँ 'विकास' शब्द का अर्थ ही पलट जाता है — उपनिवेशवादी शब्दावली का आंतरिक विरोधाभास उजागर होता है। दूसरा प्रमाण: 'न्याय और व्यवस्था' के नारे पर कथावाचक का प्रत्युत्तर — 'न्याय केवल तुम्हारे लिए, हमारे लिए तो केवल व्यवस्था।' यह नकल (mimicry) व्यंग्य नहीं, epistemological resistance है: शासक की भाषा से ही उसकी नैतिक वैधता छीन लेना। अंतिम संवाद — 'तुम जाओगे, पर हमारी आवाज़ नहीं रुकेगी' — पुष्ट करता है कि यह भाषाई प्रतिरोध भौतिक संघर्ष का पूर्वाभास है।"

## WORKED_EXAMPLE_2
PROBLEM: In a group discussion, Student A claims: "The chapter is too angry — it doesn't show any nuance, just anti-British propaganda." Student B must respond analytically, not emotionally.
STEPS:
- Step 1: Diagnose Student A's claim — it's an evaluative judgment ("propaganda") masquerading as literary criticism, ignoring craft.
- Step 2: Acknowledge the surface validity — "सतही पाठन में क्रोध प्रमुख लगता है" — to validate the peer before dismantling.
- Step 3: Introduce the craft counter-evidence — "लेकिन वैद का शिल्प देखें: व्यंग्य (irony) क्रोध नहीं, बौद्धिक विच्छेदन (intellectual dissection) है।"
- Step 4: Cite TWO nuanced moments — (a) Viceroy's human moment: "मेरे बच्चे भी यहाँ बड़े हुए" (p.48) — the text grants the colonizer humanity, complicating the binary; (b) Narrator's self-implication: "हम भी तो चुप रहे इतने वर्ष" — resistance includes self-critique.
- Step 5: Synthesize — "यह 'प्रोपेगेंडा' नहीं, dialectical critique है: शोषक की मानवीयता और शोषित की सहभागिता दोनों दिखाकर वैद नैतिक सरलीकरण से बचते हैं।"
- Step 6: Invite further probe — "क्या आपको लगता है कि वायसराय की 'मानवीयता' उसके अपराधों को कम करती है, या उन्हें और भयावह बनाती है?"
REASONING: Effective academic disagreement requires: (1) steel-manning the opposing view, (2) pivoting to textual craft, (3) introducing complexity the opponent missed, (4) closing with a generative question. This models scholarly discourse.
ANSWER: Spoken response: "आपकी बात समझ में आती है — पहला पाठन में आक्रोश मुखर लगता है। लेकिन वैद का शिल्प देखें: वे वायसराय को राक्षस नहीं, मानवीय बनाते हैं — 'मेरे बच्चे भी यहीं बड़े हुए' (पृष्ठ 48) कहकर। यह मानवीयता ही उसके अपराधों को और विकट बनाती है: एक सामान्य मनुष्य कैसे व्यवस्था का अंग बन जाता है। साथ ही, कथावाचक स्वयं को भी दोषी ठहराता है: 'हम भी तो चुप रहे'। यह द्वंद्वात्मक आलोचना (dialectical critique) है, एकपक्षीय प्रचार नहीं। आप क्या कहते हैं — क्या वायसराय की 'पारिवारिक मानवीयता' उसके साम्राज्यवादी कृत्यों को अधिक भयावह बनाती है?"

## WORKED_EXAMPLE_3
PROBLEM: A formal assessed discussion (ASL-style) on: "Evaluate the effectiveness of Vaid's use of the 'phone booth' (फोनबूथ) as a central metaphor for colonial communication." Student must sustain 3 minutes with 4+ textual references.
STEPS:
- Step 1: Deconstruct the metaphor — "फोनबूथ" = (a) technological modernity imposed by empire, (b) controlled communication (who speaks, who listens), (c) physical enclosure mirroring colonial containment, (d) voice transmission without presence — disembodied authority.
- Step 2: Map 4 textual moments to these dimensions — (i) Opening: Viceroy enters booth, narrator follows — spatial invasion; (ii) p.46: "आवाज़ आती है, आदमी नहीं" — disembodied power; (iii) p.48: Booth as "शीशे का पिंजरा" (glass cage) — transparency as trap; (iv) Ending: Narrator remains, Viceroy leaves — booth outlives the colonizer.
- Step 3: Structure 3-minute arc — Thesis (30s): "फोनबूथ उपनिवेशवाद का सूक्ष्मजगत (microcosm) है: तकनीक, नियंत्रण, और प्रतिरोध का स्थल।" → Dimension 1 + Evidence (45s) → Dimension 2 + Evidence (45s) → Dimension 3 + Evidence (45s) → Synthesis/Link to present (15s).
- Step 4: Embed disciplinary vocabulary — "metonymy (लक्षणा)", "spatial politics (स्थानिक राजनीति)", "disembodiment (अशरीरीकरण)", "subaltern voice (उपनिवेशित आवाज़)".
- Step 5: Prepare for examiner interruption — practice "पुनः कहना चाहूँगा..." (rephrasing), "पाठ से एक और प्रमाण..." (additional evidence), "यह बिंदु प्रश्न से कैसे जुड़ता है..." (relevance signaling).
- Step 6: Final polish — record, check: Are all 4 references precise? Is Hindi register formal (तत्सम-heavy)? Are transitions smooth? Is pace measured (120-130 words/minute)?
REASONING: ASL assessment criteria: (1) Content relevance & depth, (2) Organization & coherence, (3) Language accuracy & register, (4) Fluency & pronunciation. The 6-step process maps each criterion to a preparation action, converting the abstract rubric into concrete rehearsal tasks.
ANSWER: Delivered 3-minute response: (Thesis) "फोनबूथ मात्र सेटिंग नहीं, उपनिवेशवाद का रूपक है — जहाँ तकनीक सत्ता का विस्तार बनती है। (Dim 1) आरंभ में वायसराय बूथ में प्रवेश करता है, कथावाचक पीछे-पीछे — 'शीशे की दीवारें पारदर्शी हैं, पर अभेद्य' (पृ.45)। यह पारदर्शिता छल है: संचार का भ्रम, वास्तविकता में एकालाप। (Dim 2) 'आवाज़ आती है, आदमी नहीं' (पृ.46) — वायसराय की आवाज़ व्यवस्था बन जाती है, बिना उत्तरदायित्व के। यह अशरीरीकरण (disembodiment) औपनिवेशिक नौकरशाही की पहचान है। (Dim 3) कथावाचक बूथ को 'पिंजरा' कहता है (पृ.48) — पर पिंजरे में कौन है? वायसराय सुरक्षित, कथावाचक बाहर किन्तु मुक्त। (Dim 4) अंत में वायसराय चला जाता है, बूथ रह जाता है, कथावाचक की आवाज़ गूँजती रहती है — 'तुम जाओगे, हम रहेंगे'। रूपक पूर्ण होता है: तकनीक साम्राज्य की नहीं, प्रतिरोध की वाहक बनती है। आज भी — डिजिटल फोनबूथों में — पूछना शेष है: कौन बोलता है? कौन सुना जाता है?"

## COMPETENCY_QUESTION_1
QUESTION: You are moderating a peer discussion on "Vaid's narrator as an unreliable witness." One participant says: "The narrator lies — he claims Curzon admitted crimes he never would." Another says: "That's the point — it's satire, not testimony." As moderator, synthesize these positions into a higher-order analytical framework for the group, using the text.
COMPETENCY: Discussion facilitation & synthesis — ability to mediate peer contributions, elevate discourse from binary disagreement to conceptual complexity, and anchor synthesis in textual evidence.
STEPS:
- Step 1: Validate both positions — "पहला वक्ता 'तथ्यात्मक सत्यता' (factual veracity) पर प्रश्न उठाता है; दूसरा 'कलात्मक रणनीति' (artistic strategy) पर। दोनों सही हैं, पर अलग स्तरों पर।"
- Step 2: Introduce the bridging concept — "यह 'अविश्वसनीय कथावाचक' (unreliable narrator) नहीं, 'व्यंग्यात्मक व्यक्तित्व' (satiric persona) है — लेखक द्वारा रचा गया एक मुखौटा जो ऐतिहासिक सत्य को कल्पनात्मक अतिशयोक्ति से उजागर करता है।"
- Step 3: Cite textual evidence for synthesis — "पृ.47 पर वायसराय कहता है: 'मैंने जो किया, गर्व से किया' — यह ऐतिहासिक कर्ज़न का वक्तव्य नहीं, उपनिवेशवादी मानसिकता का संक्षेपण (condensation) है।"
- Step 4: Frame a generative question — "तो प्रश्न यह नहीं कि 'क्या यह सच हुआ?', बल्कि 'यह कल्पना कौन-सा सत्य उद्घाटित करती है जो यथार्थवादी वर्णन नहीं कर सकता?'"
ANSWER: Moderator synthesis: "हमारे दो साथियों ने महत्वपूर्ण भेद उजागर किया: ऐतिहासिक तथ्य बनाम कलात्मक सत्य। वैद का कथावाचक 'झूठा' नहीं, 'प्रतीकात्मक' है — वह कर्ज़न को नहीं, उपनिवेशवाद के तर्क (logic of colonialism) को बोलता हुआ दिखाता है। जब वायसराय स्वीकार करता है 'न्याय केवल शासकों के लिए', यह कोई ऐतिहासिक स्वीकारोक्ति नहीं, बल्कि उपनिवेशवादी विधि-व्यवस्था का नग्न सत्य है जिसे कोई वास्तविक वायसराय कभी नहीं बोलेगा, पर जो हर नीति में निहित है। यह 'रणनीतिक अतिशयोक्ति' (strategic hyperbole) है — असंभव संवाद के माध्यम से असहनीय सत्य बोलना। आइए अब देखें: पाठ में और कहाँ ऐसी 'असंभव स्वीकारोक्तियाँ' हैं, और वे कौन-से ढके हुए सत्य खोलती हैं?"
DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: In an assessed discussion, you must argue: "Vaid's satire fails because it targets a dead empire — Curzon left in 1905, the text was written decades later. It's nostalgia, not critique." Defend or refute this position using the text's internal evidence and its contemporary relevance, in a 2-minute structured turn.
COMPETENCY: Argumentative agility — ability to engage a provocative counter-claim, dismantle it textually, and extend the text's relevance beyond its historical moment, all within strict time constraints.
STEPS:
- Step 1: Identify the counter-claim's flaw — it confuses historical setting with thematic target; the text critiques colonial LOGIC, not just Curzon.
- Step 2: Cite textual evidence of self-conscious anachronism — "पृ.49: 'आज भी... नए नामों से वही आवाज़ें' — वैद स्वयं समयातीतता (timelessness) का दावा करता है।"
- Step 3: Identify the continuing structure — "फोनबूथ रूपक: तब टेलीफोन, आज डिजिटल प्लेटफॉर्म — नियंत्रित संचार की संरचना समान।"
- Step 4: Cite narrator's final address to future — "पृ.50: 'मेरे पीछे आने वालों के लिए' — पाठ भविष्य को संबोधित है, अतीत को नहीं।"
- Step 5: Conclude with contemporary bridge — "यह 'नॉस्टेल्जिया' नहीं, 'वंशावली' (genealogy) है — दिखाता है कि वर्तमान सत्ता-भाषा की जड़ें कहाँ हैं।"
ANSWER: Structured rebuttal: "यह आपत्ति पाठ के ऐतिहासिक संदर्भ को उसके विषय (subject) से भ्रमित करती है। वैद कर्ज़न पर व्यंग्य नहीं करते — उपनिवेशवाद की तर्क-प्रणाली (episteme) पर करते हैं। प्रमाण एक: पृ.49 पर कथावाचक कहता है — 'आज भी, नए नामों से, वही आवाज़ें गूँजती हैं'। लेखक स्वयं समयातीतता का दावा करता है। प्रमाण दो: फोनबूथ रूपक — तब ब्रिटिश टेलीफोन नेटवर्क भारतीय संसाधन निष्कर्षण के लिए, आज वैश्विक डिजिटल अवसंरचना डेटा निष्कर्षण के लिए। संरचना समान: तकनीक सत्ता की वाहक। प्रमाण तीन: अंतिम संबोधन — 'मेरे पीछे आने वालों के लिए' (पृ.50) — पाठ भविष्य को पुकारता है, अतीत को नहीं। यह 'नॉस्टेल्जिया' (nostalgia) नहीं, फूको के अर्थ में 'वंशावली' (genealogy) है: वर्तमान की सत्ता-भाषा की जड़ें ऐतिहासिक रूपक में खोजना। इसलिए व्यंग्य 'मृत साम्राज्य' पर नहीं, 'जीवित तर्क' पर है — और वह तर्क आज भी सक्रिय है।"
DIFFICULTY: hard