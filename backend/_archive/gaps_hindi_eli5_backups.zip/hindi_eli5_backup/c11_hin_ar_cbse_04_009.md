## DEFINITION
Irony (व्यंग्य) is a literary device in which the intended meaning of a statement, situation, or structural design is opposite to or significantly different from its literal or surface meaning, creating a deliberate gap between what is said and what is meant. Symbolism (प्रतीक/प्रतीकवाद) is the use of concrete objects, characters, actions, or settings to represent abstract ideas, values, or thematic concepts that extend beyond their literal significance, where the symbol carries meaning that is culturally and textually constructed rather than inherent. In the context of Hindi Aroh Chapter 4, irony operates as the satirical engine that inverts colonial power dynamics, while symbolism elevates concrete colonial artifacts into representations of systemic oppression and resistance.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student must independently identify at least two instances each of verbal irony, situational irony, and dramatic irony in the chapter, explain the specific gap between surface meaning and intended meaning in each, and articulate how each ironic instance serves the satirical argument against Lord Curzon. Additionally, the student must identify at least three symbols in the text, distinguish their literal from figurative meanings, and analyze how at least one symbol evolves or accumulates meaning across multiple passages to deepen the chapter's thematic critique of colonialism.

## SCOPE_BOUNDARY
This node covers the identification, classification, and functional analysis of irony (verbal, situational, dramatic) and symbolism (conventional, contextual, evolving) specifically within the satirical monologue addressing Lord Curzon in Chapter 4. It does NOT cover metaphor and imagery analysis (addressed in node 008), nor does it address rhyme, meter, or narrative structure (addressed in node 002). It does not extend to allegory as a full narrative mode, though individual symbols within the chapter may be examined for their allegorical potential.

## WALKTHROUGH
Imagine a friend who says "Oh, wonderful weather!" while standing in a thunderstorm soaking wet — you instantly know they mean the opposite of the literal words. That gap between surface and meaning is irony. Now open the chapter to the passage where the narrator addresses Lord Curzon with apparent respect and courtesy — ask yourself: does the narrator genuinely revere Curzon, or does the polite address mask a devastating critique? The answer lies in the ironic gap: the more courteous the language, the sharper the condemnation beneath it. Next, locate the concrete objects that recur across the chapter — the bulldozer, the phantom's eyes, the laundry, the whip. Ask of each: what does this object literally do in the scene, and what larger concept does it stand for? The bulldozer is not just a machine; it is a symbol of industrialized, mechanized violence that colonialism deploys against organic, human resistance. The key insight: irony inverts the power relationship between speaker and addressee (the colonized narrator gains rhetorical authority over the colonial lord), while symbolism condenses abstract systemic critique into a single, memorable concrete image that the reader carries away from the text.

## DIAGNOSTIC_QUESTION_1
Define verbal irony, situational irony, and dramatic irony in your own words, giving one everyday example of each (not from the textbook).

## DIAGNOSTIC_ANSWER_1
Verbal irony: a speaker says the opposite of what they mean (e.g., "What a brilliant idea!" when someone suggests leaving textbooks at home before an exam). Situational irony: the outcome of a situation is the opposite of what was expected (e.g., a traffic jam outside a sign that reads "Smooth Drive Ahead"). Dramatic irony: the audience or reader knows something the character does not, creating a gap between character knowledge and reader knowledge (e.g., the reader knows the hero's best friend is the villain, but the hero trusts him completely). A wrong answer that conflates verbal irony with sarcasm alone (sarcasm is a subset of verbal irony that is intended to wound) or that defines situational irony as "something unexpected happens" (without the requirement of reversal of expectation) reveals the student has not grasped the *gap structure* that unifies all three types: irony always involves a discrepancy between two levels of meaning or knowledge.

## DIAGNOSTIC_QUESTION_2
In the chapter, the narrator addresses Lord Curzon with elaborate courtesy and formal respect, calling him a great administrator and reformer. Identify the type of irony operating here and explain how the courteous surface and the critical subtext create the satirical effect.

## DIAGNOSTIC_ANSWER_2
This is verbal irony operating at the level of sustained address. The narrator's courteous language ("great administrator," "reformer") carries a surface meaning of praise, but the intended meaning — revealed through the surrounding context of exploitation, violence, and suffering described alongside the praise — is devastating condemnation. The satirical effect emerges from the *gap*: the more extravagant the praise, the more the reader perceives the indictment beneath it. The courtesy is not sincerity but a rhetorical weapon — by adopting the colonizer's own language of "reform" and "civilization," the narrator exposes its hollowness from within. A wrong answer that calls this "sarcasm" or "dramatic irony" shows the student misses that the irony is structural and sustained throughout the monologue, not a momentary jab — it is the *organizing principle* of the entire address, not an isolated quip.

## DIAGNOSTIC_QUESTION_3
The narrator describes the British legal system as having "long arms" that "only pick the pockets of the poor." Identify the symbol embedded here and explain how its literal and figurative meanings interact to produce a critique that a direct statement ("the law exploits the poor") could not achieve.

## DIAGNOSTIC_ANSWER_3
The symbol is the "long arms of the law" — literally, the reach and jurisdiction of the legal system; figuratively, the invasive, inescapable grip of colonial justice that extends into every corner of Indian life but functions selectively, extracting from the poor while protecting the rich. The symbol works because the concrete image (arms reaching, fingers picking pockets) makes the abstract critique (systemic legal exploitation) visceral and memorable. A direct statement would be argumentative; the symbol is *demonstrative* — it shows the law as a physical body committing a physical crime, collapsing the distance between institution and act. A wrong answer that identifies "picking pockets" as merely a metaphor without recognizing the *symbolic* dimension (the law as a body, the arms as reach, the fingers as selectivity) shows the student can spot figurative language but cannot distinguish metaphor (a momentary equation) from symbol (a recurring, accumulating image that carries thematic weight across the text).

## DIAGNOSTIC_QUESTION_4
Compare the irony in the narrator's praise of Curzon's "reforms" with the situational irony of the narrator's return to India finding "the same" conditions despite regime changes. How do these two types of irony target different aspects of colonialism — its *rhetoric* versus its *reality*?

## DIAGNOSTIC_ANSWER_4
The verbal irony of praising Curzon's "reforms" targets colonial *rhetoric* — the language of civilization, progress, and improvement that the colonizer uses to justify rule. By inflating this rhetoric through praise, the narrator exposes its emptiness: the reforms are praised precisely because they failed. The situational irony of "the same" conditions despite regime change targets colonial *reality* — the expectation that a change in viceroy or policy would improve Indian life is reversed by the experience of identical oppression. Together, the two ironies create a double critique: verbal irony dismantles the *language* of colonialism (its self-justifying narrative), while situational irony dismantles the *practice* of colonialism (its actual outcomes). A wrong answer that treats both as "just irony" without distinguishing the rhetorical target (language vs. outcome) reveals the student sees irony as a single undifferentiated device rather than a toolkit with distinct analytical functions.

## DIAGNOSTIC_QUESTION_5
Trace the symbol of the "phantom" (फाँक) across at least two passages in the chapter. How does its symbolic meaning evolve from its first appearance to its later occurrences, and what does this evolution reveal about the chapter's argument regarding the nature of colonial power?

## DIAGNOSTIC_ANSWER_5
First appearance: the phantom with "two eyes" that watch everything symbolizes colonial surveillance — omnipresent, disembodied, inescapable gaze. The phantom is a *presence without a body*, representing power that is felt everywhere but located nowhere, making resistance feel futile because there is no body to fight. Later occurrence: the narrator "watches back" at the phantom's eyes, and the symbol evolves from instrument of oppression to site of confrontation. The phantom's gaze, once unidirectional (colonizer watches colonized), becomes reciprocal (colonized watches back), symbolizing the reclamation of subjectivity and agency. The evolution reveals the chapter's argument: colonial power appears as an omnipresent phantom precisely to *prevent* resistance by making power seem supernatural and unchallengeable, but the act of returning the gaze — of seeing the phantom as seeable — demystifies it and opens the space for defiance. A wrong answer that treats the phantom as a static symbol of "fear" misses the *evolutionary* dimension — symbols in sophisticated literary texts are not fixed signs but dynamic images that accumulate and transform meaning across the narrative arc.

## DIAGNOSTIC_QUESTION_6
Write a 4-5 sentence paragraph addressed to a fictional "Principal Saab" that uses verbal irony to criticize an unfair school rule (e.g., a rule banning water bottles in summer), and includes one symbol (a concrete object that represents the larger issue). Do not state the criticism directly — let the irony and symbol carry it.

## DIAGNOSTIC_ANSWER_6
Example: "Principal Saab, your enlightened decree banning water bottles in the classroom is a triumph of dry policy over wet reality — our throats have never been so educated in the virtue of thirst. The empty bottle I carry in my bag (symbol: the hollowness of rules that ignore human need) rattles like a medal of your administrative wisdom. Truly, no principal in history has so successfully united an entire student body — in dehydration. We are grateful that your concern for our carpets exceeds your concern for our kidneys." Criteria for a good answer: (1) the praise is clearly ironic (the gap between surface praise and intended criticism is evident), (2) the empty bottle functions as a symbol (literal object carrying figurative weight), (3) the criticism is indirect — the reader infers it from the ironic gap, not from explicit statement. A poor answer that states "This rule is unfair because students need water" directly, or that uses a symbol without ironic framing, shows the student cannot *generate* ironic discourse — only recognize it.

## COMMON_MISCONCEPTION
Students treat irony and symbolism as *labeling exercises* — they identify "here is irony" and "here is a symbol" and stop, as if the goal is to spot and name rather than to analyze function. The specific error in this chapter is reading the narrator's courteous address to Curzon as *genuine respect* (missing the irony entirely) or reading the bulldozer as *a literal bulldozer* mentioned for descriptive color (missing the symbolism). A deeper error is recognizing that irony exists but classifying all irony as "sarcasm" — reducing a sustained structural irony (the entire monologue's address mode) to a momentary tone, which prevents the student from seeing how irony *organizes* the text rather than decorating it. Students also confuse symbols with motifs: a motif is a recurring element that reinforces theme through repetition, while a symbol carries a *representational* function — it stands *for* something beyond itself. The bulldozer recurring is a motif; the bulldozer standing for mechanized colonial violence is a symbol. The distinction matters because board exam questions ask "what does X symbolize?" not "what is the motif of X?"

## ON_FAILURE
Step 1: Return to the narrator's address to Curzon. Ask the student to read the first three paragraphs aloud, marking every sentence where the narrator praises Curzon. Then ask: "If the narrator genuinely admired Curzon, why does he spend the rest of the chapter listing atrocities? What is the relationship between the praise and the atrocities?" Step 2: Have the student draw a two-column table: Column A = "What the narrator says (surface)," Column B = "What the narrator means (subtext)." Fill it for five praise statements. Step 3: For symbolism, ask the student to pick one concrete object from the chapter (e.g., the bulldozer, the phantom, the whip) and answer three questions: (a) What is this object literally? (b) What does it stand for beyond itself? (c) Where else in the chapter does this object or its image recur, and does its meaning change? Step 4: Ask the student to rewrite one paragraph of the chapter *without* irony — stating the criticism directly. Compare the two versions and ask: "What does the ironic version achieve that the direct version cannot?" This forces the student to experience irony's rhetorical power rather than merely define it.

## PREREQUISITE_NODE_IDS
c11_hin_ar_cbse_04_002, c11_hin_ar_cbse_04_003, c11_hin_ar_cbse_04_006, c11_hin_ar_cbse_04_008, c11_hin_ar_cbse_04_007

## PREREQUISITE_REASONS
c11_hin_ar_cbse_04_002: Understanding the plot structure (satirical monologue addressing Curzon) is essential because irony in this chapter is *structural* — it is organized by the monologue's address format, not by isolated witty remarks. Without knowing the narrative architecture, the student cannot see how irony operates across the whole text.
c11_hin_ar_cbse_04_003: The atmosphere of oppression and resistance established in the setting analysis provides the *reality* against which the narrator's *ironic praise* is measured. The gap between the courteous language and the oppressive atmosphere is what creates the irony — without the setting context, the praise reads as sincere.
c11_hin_ar_cbse_04_006: The primary theme (colonial exploitation and Indian resilience) is the *meaning* that the chapter's symbols carry. A symbol's figurative significance is always thematically determined — without clarity on the theme, symbol analysis becomes free association rather than grounded interpretation.
c11_hin_ar_cbse_04_008: Imagery and metaphor analysis (node 008) provides the foundational skill of distinguishing literal from figurative language. Irony and symbolism build on this: irony is a gap between two levels of *meaning* (requiring literal/figurative distinction), and symbolism is figurative representation through concrete objects (requiring the metaphorical mapping skill developed in node 008).
c11_hin_ar_cbse_04_007: Irony/symbolism are primary vehicles for secondary themes like 'ironic justice'.  

## FORWARD_NODE_IDS
c11_hin_ar_cbse_04_013, c11_hin_ar_cbse_04_014, c11_hin_ar_cbse_04_010, c11_hin_ar_cbse_04_011, c11_hin_ar_cbse_04_015, c12_hin_a_cbse_04_009, c12_hin_a_cbse_05_009, c12_hin_a_cbse_10_009, c12_hin_al_cbse_01_009, c12_hin_ar_cbse_04_009, c12_hin_ar_cbse_09_009, c12_hin_ar_cbse_12_009

## FORWARD_REASONS
c11_hin_ar_cbse_04_013: Critical thinking and interpretation questions in board exams demand evidence-based analysis of how irony and symbolism construct meaning — this node provides the analytical framework (gap analysis for irony, literal/figurative mapping for symbolism) that the critical thinking node will require students to apply independently.
c11_hin_ar_cbse_04_014: Writing skills (analytical paragraphs, essays) require the ability to cite ironic gaps and symbolic meanings as evidence in structured arguments — this node teaches the PEEL structure (Point, Evidence, Explanation, Link) specifically applied to irony and symbolism, which the writing node will extend to full essay composition.
c11_hin_ar_cbse_04_010: Irony/Symbolism understanding is prerequisite — this chapter's vocabulary *is* its irony.  
c11_hin_ar_cbse_04_011: Irony and symbolism recognition is essential for detecting satirical grammar.  
c11_hin_ar_cbse_04_015: Enables identification of irony and symbolism — the core devices Vaid uses — for citation in spoken arguments.  
c12_hin_a_cbse_04_009: Class 11 Antra Chapter 4 covered irony/symbolism in a different poem — transfers the *analytical framework*, not content.  
c12_hin_a_cbse_05_009: अगला तार्किक चरण: Irony is a literary device where the intended meaning of words or a situation is opposite to their l... इस नोड की अवधारणाओं को सीधे उपयोग/विस्तारित करता है।  
c12_hin_a_cbse_10_009: Chapter 4 focused on verbal irony in dialogue — directly relevant to narrator's self-deprecating labels.  
c12_hin_al_cbse_01_009: Class 11 Antra Chapter 4 Irony and Symbolism node deepens understanding through different characters.  
c12_hin_ar_cbse_04_009: Class 11 Irony and Symbolism node establishes the basic definitions and simple examples; Class 12 deepens to sustained textual analysis in a dialogic poem.  
c12_hin_ar_cbse_09_009: Practices analyzing irony in narrative poems.  
c12_hin_ar_cbse_12_009: अगला तार्किक चरण: Irony in this story is the contrast between appearance and reality — where the wealthy waste water c... इस नोड की अवधारणाओं को सीधे उपयोग/विस्तारित करता है।  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
none

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_04_008 -> c11_hin_ar_cbse_04_009 -> c11_hin_ar_cbse_04_013

## THIS_FORMULA
N/A - conceptual

## FORMULA_VARIABLES
N/A

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
analytical

## CROSS_SUBJECT
N/A

## PREREQ_CONCEPT
Distinguishing literal from figurative meaning: the foundational skill that both irony (gap between surface and intended meaning) and symbolism (concrete object representing abstract concept) require. The student must already understand that literary language operates on multiple semantic levels simultaneously before they can analyze how irony and symbolism exploit those levels.

## PREREQ_BEFORE
The student must be able to: (1) identify the narrator's voice as distinct from the author's voice; (2) recognize that the address to "Lord Curzon" is a rhetorical device, not a historical letter; (3) distinguish metaphor (momentary equation of two things) from symbol (recurring object carrying thematic weight); (4) explain how imagery creates sensory experience — all skills developed in nodes 002, 003, 006, and 008.

## PREREQ_STUCK
If the student cannot identify the irony in the narrator's praise of Curzon, return to node 003 (Setting/Atmosphere) and re-establish the oppressive atmosphere. Then ask: "If the atmosphere is oppressive, but the narrator is praising the administrator, what is the gap between the praise and the atmosphere? What does that gap tell you about the narrator's true intention?" This re-anchors irony in the contrast between language and context.

## WORKED_EXAMPLE_1
PROBLEM: Analyze the verbal irony in the narrator's statement: "Your justice is so perfect that the poor man's cry for help and the rich man's demand for profit reach your ears at exactly the same speed — only the rich man's arrives first." Identify the surface meaning, the intended meaning, and explain how the ironic structure produces a sharper critique than a direct statement would.

STEPS:
- Step 1: Identify the surface meaning — The narrator appears to praise the British justice system as "perfect" and "equal" (both poor and rich can access it).
- Step 2: Identify the intended meaning — The justice system is not equal: it systematically favors the rich. The "same speed" is ironic because the outcome ("rich man's arrives first") contradicts the claim of equality.
- Step 3: Analyze the ironic structure — The sentence sets up an expectation of equality ("same speed") and then immediately reverses it ("arrives first"). The reversal is the irony: the praise of equality *is* the criticism of inequality. The structure mimics the experience of colonial justice — it *appears* fair, then *reveals* its bias.
- Step 4: Compare with a direct statement — A direct version: "The British justice system favors the rich over the poor." This is a claim; the ironic version is a *demonstration* — it makes the reader experience the bait-and-switch of colonial justice rather than merely being told about it.
- Step 5: Connect to the chapter's satirical strategy — This micro-irony (within a single sentence) mirrors the macro-irony (the entire monologue's praise of Curzon). Both operate by *apparent endorsement* that *reveals condemnation* through structural reversal.

REASONING: This worked example models the three-step irony analysis: (1) surface meaning, (2) intended meaning, (3) the gap between them and what it achieves. The comparison with a direct statement (Step 4) is the critical move that distinguishes senior-secondary analysis from middle-school device-spotting — the student must articulate *why irony is more effective* than direct statement, not just *that irony is present*.

ANSWER: The surface meaning praises British justice as perfect and equal; the intended meaning condemns it as systematically biased toward the rich. The ironic structure (setting up equality, then reversing it) makes the reader *experience* the deception of colonial justice rather than merely hearing about it, producing a sharper critique than a direct statement because it enacts the very bait-and-switch it describes.

## WORKED_EXAMPLE_2
PROBLEM: The chapter uses the symbol of the "whip" (कोड़ा) in multiple passages. Trace this symbol across three occurrences: (a) the whip in the hands of the colonial police, (b) the whip described as "the teacher of discipline," (c) the narrator's memory of the whip's sound. For each occurrence, identify the literal meaning, the symbolic meaning, and explain how the symbol evolves.

STEPS:
- Step 1: Occurrence (a) — Literal: a physical whip used by colonial police to control crowds. Symbolic: the direct, physical violence of colonial authority — power exercised through pain on the body.
- Step 2: Occurrence (b) — Literal: the whip described metaphorically as a "teacher of discipline." Symbolic: colonial violence disguised as pedagogy — the whip is not just punishment but *education*, teaching the colonized to submit. The symbol shifts from *instrument of control* to *instrument of ideological formation*.
- Step 3: Occurrence (c) — Literal: the narrator remembers the *sound* of the whip, not its image. Symbolic: the whip has moved from physical object to psychological imprint — it lives in memory as sound, meaning colonial violence has been *internalized*. The symbol evolves from external force to internal scar.
- Step 4: Synthesize the evolution — Physical violence (a) → disguised pedagogy (b) → internalized trauma (c). The symbol traces the *deepening* of colonial power: from body to ideology to psyche. This evolution mirrors the chapter's broader argument that colonialism is not just physical occupation but total psychological colonization.
- Step 5: Connect to board-exam answer format — A high-scoring response would trace this evolution in 4-5 sentences, quoting key phrases from each occurrence, and conclude: "The whip metamorphoses from instrument of physical control to emblem of internalized subjugation, embodying the chapter's central argument about the psychological depth of colonial domination."

REASONING: This worked example models *symbol tracking* — the skill of following a single symbol across multiple passages and analyzing how its meaning accumulates and transforms. This is explicitly tested in CBSE competency questions ("How does the symbol of X develop across the text?"). The 5-step method (identify each occurrence → analyze literal/symbolic at each → synthesize evolution → connect to argument → format for exam) is transferable to any symbol in any literary text.

ANSWER: The whip evolves from physical violence (colonial police) to disguised pedagogy ("teacher of discipline") to internalized trauma (remembered sound). This progression traces the deepening of colonial power from body to ideology to psyche, embodying the chapter's argument that colonialism is not merely physical occupation but total psychological colonization. The symbol's evolution from visible object to invisible sound enacts the very process of internalization it critiques.

## WORKED_EXAMPLE_3
PROBLEM: Identify the dramatic irony in the chapter's structure: the narrator addresses Lord Curzon as if Curzon can hear and respond, but the reader knows Curzon is dead and cannot hear. Explain how this structural dramatic irony shapes the reader's experience and serves the chapter's satirical purpose.

STEPS:
- Step 1: Identify the dramatic irony — The narrator speaks as if Curzon is present and listening, but the reader knows Curzon is dead. The gap is between the narrator's frame (Curzon as living addressee) and the reader's knowledge (Curzon as dead historical figure).
- Step 2: Analyze the effect on the reader — The reader occupies a privileged position: they know something the narrator's *addressee* does not (that he is dead and cannot hear). This creates a triangular structure: narrator → (absent) Curzon → knowing reader. The reader becomes the *actual audience*, drawn into complicity with the narrator's critique.
- Step 3: Explain the satirical purpose — By addressing a dead man as if he were alive, the narrator implies that Curzon's *policies* are alive even though Curzon is dead. The dead addressee symbolizes the *persistence* of colonial structures beyond individual administrators. The irony is not that the narrator is foolish (addressing a dead man) but that the *system Curzon built outlives him* — the address is to the *living legacy*, not the dead man.
- Step 4: Connect to the chapter's argument — The dramatic irony reinforces the situational irony of "the same" conditions despite regime change: Curzon is gone, but Curzonism remains. The dead addressee is the structural embodiment of the chapter's thesis that colonialism is a *system*, not a person — killing the person does not kill the system.
- Step 5: Evaluate the rhetorical brilliance — The dramatic irony does triple duty: (a) it mocks Curzon (he is so irrelevant he cannot even hear the critique), (b) it empowers the narrator (he speaks with the authority of one addressing the living from a position of superior knowledge), (c) it recruits the reader (the reader's knowledge makes them an ally, not a bystander).

REASONING: This worked example models *structural irony analysis* — irony that operates at the level of narrative architecture rather than individual sentences. Senior-secondary students often miss structural irony because they look for irony in *what is said* rather than in *how the text is framed*. The 5-step method (identify the irony → analyze reader effect → explain satirical purpose → connect to argument → evaluate rhetorical function) trains students to see irony as a *design principle*, not just a verbal trick.

ANSWER: The dramatic irony of addressing a dead Curzon as if he were alive serves triple satirical purpose: it mocks Curzon's irrelevance (he cannot even hear the critique), it implies his *policies* outlive him (the real addressee is the living colonial system), and it recruits the reader as the actual audience who shares the narrator's knowledge. This structural irony embodies the chapter's thesis that colonialism is a system that persists beyond individual administrators — Curzon is dead, but Curzonism lives.

## COMPETENCY_QUESTION_1
QUESTION: The narrator states: "You gave us railways, and we are grateful — the trains carry our cotton to your ports faster than bullock carts ever could." (a) Identify the type of irony. (b) Explain the gap between surface meaning and intended meaning. (c) How does this ironic statement serve a *different* rhetorical function from the irony in the narrator's praise of Curzon's "reforms"? Specify the distinct target of each irony.

COMPETENCY: Distinguishing types of irony and their distinct rhetorical functions within a single text — a key board exam competency requiring students to classify irony and explain its specific argumentative purpose.

STEPS:
- Step 1: Classify the irony — The statement praises the railways ("we are grateful") but the explanation ("carry our cotton to your ports") reveals the railways' true function: extraction of Indian resources for British benefit. This is verbal irony — the surface praise conceals condemnation.
- Step 2: Identify the gap — Surface: railways are a gift, a sign of progress, a benefit to India. Intended: railways are an instrument of colonial extraction, built to serve British economic interests, not Indian welfare. The "gratitude" is ironic because the gift is actually a tool of exploitation.
- Step 3: Compare with the "reforms" irony — The "reforms" irony targets colonial *ideology* (the language of civilization and improvement that justifies rule). The "railways" irony targets colonial *infrastructure* (the physical systems built to extract resources). The reforms irony dismantles the *moral* claim of colonialism; the railways irony dismantles the *material* claim that colonialism brought development.
- Step 4: Synthesize — Both ironies operate by the same mechanism (praise that reveals condemnation) but target different dimensions of the colonial argument: ideology vs. infrastructure, moral justification vs. economic practice. Together they form a comprehensive critique that covers both the *language* and the *logistics* of empire.

ANSWER: (a) Verbal irony. (b) Surface: railways are a beneficial gift; intended: railways are extraction infrastructure serving British ports, not Indian welfare. (c) The "reforms" irony targets colonial *ideology* (the moral language of civilization); the "railways" irony targets colonial *infrastructure* (the material systems of extraction). Both use praise-to-condem structure but dismantle different pillars of the colonial argument — moral justification versus economic practice.

DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: Construct an analytical paragraph (PEEL structure) arguing that the chapter's use of the "phantom" as a symbol is more effective than its use of the "whip" as a symbol for conveying the chapter's central argument about the *psychological* nature of colonial power. Use textual evidence from both symbols and explain why the phantom's *invisibility* is symbolically superior to the whip's *visibility* for this specific thematic purpose.

COMPETENCY: Comparative symbol analysis — evaluating the relative effectiveness of two symbols for a specific thematic purpose, requiring students to justify symbol choice as rhetorical strategy rather than treating all symbols as equally functional.

STEPS:
- Step 1: Point — The phantom is a more effective symbol than the whip for conveying the *psychological* nature of colonial power because invisibility (phantom) represents internalized surveillance, while visibility (whip) represents only external force.
- Step 2: Evidence — Phantom: "two eyes that never blink" (omnipresent, disembodied gaze); Whip: "the teacher of discipline" (physical, embodied violence). Quote both.
- Step 3: Explanation — The whip operates in the *visible* domain: it is a physical object, its violence is external, and its power ends when the whipping stops. The phantom operates in the *invisible* domain: it is a presence without a body, its surveillance is internalized (the colonized *feels* watched even when alone), and its power persists precisely because it cannot be located and fought. For the chapter's argument that colonialism is *psychological* colonization (not just physical occupation), the phantom's invisibility is symbolically superior because it represents power that has moved *inside* the mind — the ultimate form of domination.
- Step 4: Link — This connects to the chapter's climactic moment where the narrator "watches back" at the phantom: the act of returning the gaze is the act of *making the invisible visible* — the first step of psychological decolonization. The whip, being already visible, cannot represent this journey from internalized oppression to conscious resistance.
- Step 5: Concluding synthesis — The phantom's symbolic superiority lies in its capacity to *evolve* (from surveillance to confrontation), while the whip's meaning, though powerful, remains in the domain of physical force. The chapter's deepest argument is not about the whip (colonialism hurts) but about the phantom (colonialism *inhabits* you) — and only an invisible symbol can carry that weight.

ANSWER: The phantom is symbolically superior to the whip for representing colonialism's psychological dimension because invisibility embodies internalized surveillance (power felt everywhere, located nowhere) while visibility embodies only external force. The phantom evolves from instrument of oppression to site of resistance (the narrator watches back), enacting the journey from internalized subjugation to conscious decolonization — a journey the visible whip, limited to physical violence, cannot symbolize. The chapter's deepest argument is not that colonialism hurts (whip) but that colonialism inhabits you (phantom), and only an invisible symbol can carry that thematic weight.

DIFFICULTY: hard
