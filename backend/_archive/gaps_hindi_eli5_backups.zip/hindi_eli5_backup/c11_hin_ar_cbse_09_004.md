## DEFINITION
Character analysis of the protagonist in poetry involves examining the speaker's persona—their voice, emotions, philosophical stance, and relationship with the divine or world—by closely reading the poem's imagery, tone, and structure, and contextualizing it with the poet's background and literary tradition.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student can independently identify the protagonist's key traits in Dadu's poem, cite specific textual evidence (lines/images) to support each trait, explain how the poet's Nirguna Bhakti philosophy shapes the persona, and write a structured analytical answer using the Point-Evidence-Explanation-Link (PEEL) method.

## SCOPE_BOUNDARY
This node covers the analysis of the speaker/protagonist in Dadu's poem (in 1) from Chapter 9, including his spiritual attitude, rejection of ritualism, and embodiment of the Nirguna ideal. It does NOT cover supporting characters (node 005), thematic development (nodes 006-007), or literary devices in isolation (nodes 008-009).

## WALKTHROUGH
Imagine you are listening to a friend pour their heart out in a diary entry—you instinctively know their fears, hopes, and personality without them listing them. Similarly, when you read Dadu's poem, the protagonist isn't described; he reveals himself through what he *rejects* (rituals, external symbols) and what he *embraces* (inner realization, the guru's word). Start by reading the poem aloud to catch the conversational, urgent tone. Then, mark every line where the speaker uses "I" or addresses the listener directly—these are windows into his mind. Next, connect his rejection of "bathing at pilgrimages" to Dadu's biography (a cotton-carder saint who defied caste norms). The key insight: the protagonist is not just a character but a mouthpiece for a radical spiritual democracy where truth is accessed through the guru's *shabda*, not birth or ritual.

## DIAGNOSTIC_QUESTION_1
Who is the protagonist (speaker) in Dadu's poem presented in Chapter 9, and what is his primary spiritual stance as evident in the opening lines?

## DIAGNOSTIC_ANSWER_1
The protagonist is the poet-devotee Dadu himself (or his poetic persona), a Nirguna Bhakta who rejects external rituals like pilgrimages and idol worship in favor of inner realization through the Guru's word (*shabda*). A wrong answer—such as identifying the protagonist as a generic "Hindu devotee" or confusing him with a Saguna bhakta like Surdas—reveals the student hasn't distinguished between Nirguna (formless divine) and Saguna (form-based) traditions, nor grasped that the "I" in the poem is a specific historical voice, not a universal everyman.

## DIAGNOSTIC_QUESTION_2
Explain in your own words why the protagonist says, "If the body is a temple, why go to a stone one?" What does this metaphor reveal about his concept of the divine?

## DIAGNOSTIC_ANSWER_2
The protagonist uses the body-as-temple metaphor to argue that the divine resides within the human heart (*hridaya*), making external stone temples redundant. This reveals his Nirguna belief that God is formless (*nirakar*) and accessible only through internal purification and the Guru's guidance, not physical geography. A wrong answer focusing only on "the body is holy" misses the polemical edge: the metaphor is a weapon against priestly authority and caste-based temple entry restrictions, not just a pious observation.

## DIAGNOSTIC_QUESTION_3
Apply the concept of *virakti* (detachment) to analyze the protagonist's attitude toward "caste" (*jati*) and "scriptural learning" (*shastra*) in the poem. Cite one implicit reference from the text.

## DIAGNOSTIC_ANSWER_3
The protagonist demonstrates *virakti* by dismissing caste pride and bookish knowledge as barriers to true knowledge. The line "The pandit reads the Vedas but doesn't know the Self" (implied in the text's description of Dadu's debates) shows he values experiential realization (*anubhav*) over textual authority. Steps: 1) Identify *virakti* as indifference to worldly status. 2) Locate the protagonist's rejection of external markers (caste, books). 3) Connect to Dadu's life: a low-caste carder teaching Brahmins. A wrong answer listing "he hates Brahmins" confuses social critique with spiritual detachment—the protagonist rejects *false authority*, not people.

## DIAGNOSTIC_QUESTION_4
Analyze how the protagonist's use of simple, colloquial Braj Bhasha (e.g., *kahat*, *sunat*, *man mast hua*) functions as a characterization tool. What does his language choice say about his intended audience and authority?

## DIAGNOSTIC_ANSWER_4
The protagonist's vernacular language characterizes him as an accessible, anti-elitist teacher who bypasses Sanskrit's gatekeeping. By speaking in the listener's mother tongue, he positions the Guru's *shabda* as universally available, not the monopoly of priests. This linguistic choice *is* his theology: the formless divine is caught in the net of common speech. A wrong answer calling it "simple language for simple people" patronizes the text and misses the deliberate political-spiritual strategy—Dadu's "rough words" (*kharak boli*) are a methodological rejection of *panditya* (scholasticism).

## DIAGNOSTIC_QUESTION_5
Evaluate the claim: "The protagonist in Dadu's poem is a rebellious social reformer first, a mystic second." Defend your judgment using evidence from the poem and the biographical note.

## DIAGNOSTIC_ANSWER_5
The claim is false; the protagonist is a mystic *through* whom social reform happens organically, not a reformer using mysticism as a tool. Evidence: his primary address is to the *individual soul* ("O mind, listen"), not society. He attacks caste/ritual only because they obstruct *atma-jnana*. The biographical note says he "gave knowledge on the strength of experience," not agitation. A wrong answer agreeing with the claim imposes a modern secular framework on a pre-modern saint, misreading *bhakti* as activism rather than surrender (*prapatti*).

## DIAGNOSTIC_QUESTION_6
Create a 4-line response in the protagonist's voice, addressing a modern student stressed about exams and career, using his core philosophy (Guru's word, inner truth, detachment from fruit).

## DIAGNOSTIC_ANSWER_6
*Why tremble at results, O mind? The Guru's word is your only degree.*
*Do your duty, leave the fruit—truth resides not in marks, but in the heart's decree.*
*The examiner within sees all; no cheating passes His silent test.*
*Rest in *shabda*, become fearless—this is the only real success.*
A poor answer would offer generic motivational quotes ("believe in yourself") without the specific Nirguna vocabulary (*shabda*, *guru*, *phal tyag*, *antarjami*), showing the student hasn't internalized the protagonist's unique theological grammar.

## COMMON_MISCONCEPTION
Students conflate the *historical Dadu* (15th-century cotton-carder) with the *poetic protagonist* (the timeless "I" of the poem), treating every line as autobiographical fact. They also mistake the protagonist's harsh tone toward rituals as "anger" rather than *karuna* (compassion) born of seeing people waste lives on externals. For example, when the poem mocks "bathing in the Ganga," students write "Dadu hated the Ganga," missing that the protagonist is attacking the *superstition* that water washes sin, not the river itself. This error stems from reading the poem as a biography instead of a *sadhana* (spiritual practice) text where the "I" is a pedagogical device.

## ON_FAILURE
1. **Separate Poet from Persona**: Have the student draw a two-column table: "Historical Dadu (from bio note)" vs. "Poetic Speaker (from poem lines)." Fill with 3 points each. 2. **Tone Mapping**: Ask them to read the "mocking" lines aloud in three tones: angry, sarcastic, compassionate. Discuss which fits the Guru-disciple context (compassionate urgency). 3. **Re-read with "You"**: Replace "The pandit..." with "You, the student, memorize formulas but don't understand concepts." This bridges the 15th-century context to their life, making the protagonist's intent visceral. 4. **Write a PEEL paragraph** answering: "Is the protagonist angry or compassionate? Prove with two lines."

## BUILDS_ON
Understanding of Nirguna Bhakti terminology (*nirguna*, *shabda*, *guru*, *virakti*) and poetic persona from the Context node (c11_hin_ar_cbse_09_001).

## LEADS_TO
Analysis of how the protagonist's traits illuminate the Primary Theme (node 006) and enable Critical Thinking questions (node 013) requiring synthesis of character and philosophy.

## PREREQUISITE_NODE_IDS
c11_hin_ar_cbse_09_001, c11_hin_ar_cbse_09_002, c11_hin_ar_cbse_09_003
## PREREQUISITE_REASONS
c11_hin_ar_cbse_09_001: Provides essential biographical and philosophical context (Nirguna tradition, Dadu's caste, guru lineage) without which the protagonist's social radicalism is unintelligible.
c11_hin_ar_cbse_09_002: Establishes the poem's narrative structure (dialogue, argument, realization) which shapes how the protagonist's voice unfolds across stanzas.
c11_hin_ar_cbse_09_003: Sets the atmosphere of *virakti* and inner stillness that the protagonist embodies; the setting (marketplace, heart) mirrors his dual engagement.

## FORWARD_NODE_IDS
c11_hin_ar_cbse_09_005, c11_hin_ar_cbse_09_006, c11_hin_ar_cbse_09_013, c12_hin_a_cbse_09_004, c12_hin_ar_cbse_09_004

## FORWARD_REASONS
c11_hin_ar_cbse_09_005: The protagonist's solitary voice gains depth when contrasted with implicit "supporting characters" (the pandit, the yogi, the worldly man) he debates.
c11_hin_ar_cbse_09_006: The protagonist's traits (detachment, guru-centrism, anti-ritualism) *are* the primary theme in dramatized form; theme analysis requires character analysis as evidence.
c11_hin_ar_cbse_09_013: Critical interpretation (e.g., "Is Dadu modern?") demands a firmly established protagonist profile to avoid anachronistic projections.
c12_hin_a_cbse_09_004: Teaches the core skill of identifying the poetic persona in first-person Bhakti poetry — directly transferable.  
c12_hin_ar_cbse_09_004: Class 11 foundation of persona vs. author distinction — this node deepens it with more complex, metaphorically dense poems.  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
none

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_09_001 -> c11_hin_ar_cbse_09_004 -> c11_hin_ar_cbse_09_005

## THIS_FORMULA
N/A - conceptual

## FORMULA_VARIABLES
N/A

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
analytical

## CROSS_SUBJECT
c11_history_bhakti_movement | The protagonist embodies the Nirguna Bhakti movement's core challenge to Brahminical ritual hegemony and caste hierarchy; analyzing him requires the historical context of 15th-century North Indian sant parampara.
c11_psychology_self_realization | The protagonist's journey from external seeking to internal realization mirrors Maslow's self-actualization and Carl Rogers' "fully functioning person," offering a cross-cultural lens on intrinsic motivation vs. extrinsic validation.

## PREREQ_CONCEPT
Nirguna Bhakti framework: the distinction between *saguna* (form/worship) and *nirguna* (formless/knowledge) paths, and the centrality of *guru-shabda* as the sole authority.

## PREREQ_BEFORE
The student must have read the biographical note on Dadu (caste, guru, era) and the poem translation at least once, noting every "I/we/you" pronoun.

## PREREQ_STUCK
If stuck, re-read the "Before You Read" (node 001) section on "Dadu's philosophy" and the poem's first two stanzas, circling all verbs showing *rejection* (don't go, don't bathe, don't read) vs. *affirmation* (listen, realize, awaken).

## WORKED_EXAMPLE_1
PROBLEM: Analyze how the protagonist characterizes himself as a "true knower" (*jnani*) in the first stanza of the poem, using the PEEL structure.

STEPS:
- Step 1: Identify the Point: The protagonist establishes his authority not through lineage or scripture but through direct experience (*anubhav*).
- Step 2: Locate Evidence: In the opening lines, he declares "I say what I have seen/known" (*main kahan dekhi*), contrasting with "pandits who read Vedas."
- Step 3: Explain the Evidence: The verb *dekhi* (seen/experienced) is epistemological—it claims ocular proof of the formless, a paradox that defines Nirguna epistemology. He positions himself as a witness, not a believer.
- Step 4: Link to Concept: This self-characterization as *anubhavi* (experiential knower) is the hallmark of the *sant* tradition (Kabir, Raidas, Dadu), distinguishing them from *pandits* (scholars) and *yogis* (technicians).
- Step 5: Connect to Central Idea: The stanza thus frames the whole poem as a testimony, not a sermon—the protagonist invites verification, not faith.

REASONING: This 5-step PEEL process moves from textual detail to tradition-level significance, modeling the board-exam expectation of "evidence-based interpretation." It avoids paraphrase by anchoring each claim in a specific word (*dekhi*) and its philosophical weight.

ANSWER: The protagonist constructs his persona as an *anubhavi jnani* (experiential knower) by opening with "Main kahan dekhi" (I speak from seeing), using the first-person perceptual verb to claim direct, unmediated access to truth. This contrasts sharply with the "pandit" who relies on *shruti* (heard/scriptural knowledge). In the *sant* tradition, *anubhav* supersedes *agama* (scripture); thus, the protagonist's authority is anti-institutional and democratic—anyone can "see" if guided by the Guru. The stanza functions as a epistemological manifesto: truth is verified in the laboratory of the heart, not the library of the Vedas.

## WORKED_EXAMPLE_2
PROBLEM: The protagonist uses the metaphor of the "body as a temple" (*deh deval*). Analyze how this metaphor reveals his attitude toward the *external* world (rituals, pilgrimages) and the *internal* world (mind, breath, guru).

STEPS:
- Step 1: Identify the Metaphor: "Deh deval" (body is temple) appears in the context of rejecting *tirtha* (pilgrimage).
- Step 2: Deconstruct the Vehicle/Tenor: Vehicle = stone temple (external, built, accessed by feet, guarded by priests). Tenor = human body (internal, given, accessed by breath/attention, guarded by guru).
- Step 3: Analyze the Mapping: The protagonist maps sanctity from geography to biology. The "deity" inside is the *shabda* (sound/word); the "priest" is the *guru*; the "offering" is *surat* (attention).
- Step 4: Determine Attitude Toward External: The external world is not "evil" but *redundant*—why fetch water from a well when you are the ocean? The tone is dismissal, not hatred.
- Step 5: Determine Attitude Toward Internal: The internal world is the *only* field of action (*karmabhumi*). The protagonist's urgency ("listen, O mind") shows the interior is where the real battle/war is fought.
- Step 6: Synthesize: The metaphor characterizes the protagonist as a radical interiorizer who relocates the sacred from public space to private consciousness, democratizing salvation.

REASONING: Metaphor analysis at Class 11 requires moving beyond "X stands for Y" to "X *reconfigures* Y." The steps force the student to map the metaphor's entailments (priest->guru, offering->attention) and read the protagonist's psychology from that reconfiguration.

ANSWER: The "body as temple" metaphor reveals a protagonist who views the external ritual world as a category error—like searching for a voice inside a letter. By transferring temple architecture (sanctum, deity, priest, offering) onto the body (heart, *shabda*, guru, *surat*), he characterizes himself as a spiritual architect who has inspected both structures and found the external one empty. His attitude toward pilgrimages is not hostility but pity: they are "bathing the shadow while the substance is dry." Toward the internal world, he is fiercely proprietary—"this temple is mine, the key is *shabda*, the gatekeeper is *guru*." This metaphor *is* his theology: incarnation replaces institution.

## WORKED_EXAMPLE_3
PROBLEM: Synthesize the protagonist's characterization across the poem and the biographical note to explain how Dadu's historical identity as a *pinjara* (cotton-carder) from a "low" caste shapes the protagonist's voice, vocabulary, and target audience.

STEPS:
- Step 1: Extract Historical Facts: Dadu = *pinjara* (cotton-carder), Muslim birth, Hindu guru (Budhanath), lived in Amber/Jaipur, composed in Braj, attracted both Hindus/Muslims.
- Step 2: Identify Textual Markers: Vocabulary: *dhuni* (cotton-bow metaphor for cleaning mind), *kharak boli* (rough/plain speech), address to "bhai" (brother) not "bhakt" (devotee). Audience: "common people" (*sadhu jan*), not scholars.
- Step 3: Map History to Text: The cotton-carder's tool (*dhuni*) becomes the protagonist's central metaphor for *sadhana* (cleaning the mind's dirt). The "rough speech" is the carder's language—functional, unpolished, effective.
- Step 4: Analyze Voice: The protagonist speaks *from* the margins *to* the margins. He doesn't "descend" to the people; he *is* the people. His authority is horizontal (shared labor), not vertical (grace from above).
- Step 5: Analyze Target: He targets the "deluded" (*bhramit*) regardless of caste—the pandit *and* the mullah, the yogi *and* the householder. His critique is class/caste-blind because his own identity transcends both.
- Step 6: Evaluate Significance: This makes the protagonist a rare literary figure: a subaltern voice that *theorizes* its own subalternity as spiritual advantage ("the last shall be first").

REASONING: This example combines textual analysis (vocabulary, metaphor) with historical materialism (caste, labor, language) — a senior-secondary competency. The 6 steps model the "contextualization" demanded in CBSE's long-answer questions (6 marks).

ANSWER: The protagonist's voice is irreducibly shaped by Dadu's *pinjara* identity. The cotton-carder's bow (*dhuni*)—which beats cotton to remove impurities—becomes the poem's central metaphor for the Guru's word beating the mind clean of *mala* (dirt/ego). This is not decorative; it's an epistemology grounded in labor. His vocabulary (*kharak boli*, *bhai*, *sahaj*) is the language of the workshop, not the academy, positioning the protagonist as a fellow-worker in the "factory of liberation." Consequently, his target audience is the *mehnatkash* (laboring) humanity—he addresses the "mind" as a co-worker ("O mind, let's card this cotton together"). The biographical note's mention of "Hindus and Muslims both followed him" is prefigured in the protagonist's refusal of *Hindu/Muslim* binaries: "Neither temple nor mosque, the body is the shrine." Thus, the historical Dadu's marginality becomes the poetic protagonist's methodological center—a brilliant inversion that defines the *sant* tradition's literary genius.

## COMPETENCY_QUESTION_1
QUESTION: "The protagonist in Dadu's poem is not a character but a *method*." Analyze this statement with reference to the poem's structure (dialogue, imperative, negation) and the protagonist's relationship with the reader/listener.

COMPETENCY: Critical Thinking - Literary Analysis and Synthesis

STEPS:
- Step 1: Unpack the claim: "Not a character" = no fixed personality, backstory, arc. "A method" = a pedagogical device, a way of knowing.
- Step 2: Analyze Structure as Method: The poem moves via *apophasis* (neti-neti: not this, not that) — negation of external forms *is* the method. The imperatives ("Sunat", "Jaanat", "Mukh bolo") are methodological instructions.
- Step 3: Analyze Dialogue as Method: The protagonist doesn't monologue; he interrogates the listener ("Why do you wander?"). The reader is forced into the disciple's seat.
- Step 4: Synthesize: The protagonist *performs* the path. His "character" = the enactment of *shabda-yoga*. The listener doesn't "learn about" him; they *become* him by following the imperatives.
- Step 5: Conclude: Thus, the protagonist is a *technology of transformation*, not a portrait.

ANSWER: The statement is profoundly accurate. The protagonist has no biography within the poem—no childhood, no doubts, no growth. He appears fully formed as the *Guru's voice*. The poem's structure is algorithmic: Step 1: Negate false loci (temple, idol, scripture, caste). Step 2: Affirm true locus (body, breath, *shabda*). Step 3: Give the tool (Guru's word). Step 4: Command practice ("Mukh bolo ram"). The protagonist *is* this algorithm in human form. His relationship with the reader is not empathetic (we don't "feel for him") but operative (we "use him"). When he says "I say what I saw," he hands us the lens. Character analysis here means analyzing the *function* of the voice: it is a *sadhana* instrument. The protagonist disappears when the method works—the ultimate Nirguna irony.

DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: Compare the protagonist's construction of "self" (*atman*) in this poem with the "self" in a Saguna Bhakti poem (e.g., Surdas's *bhramara geet* or Mirabai's *pads*). How does the *absence* of a personal deity (Krishna/Ram) change the protagonist's psychological profile—his desire, anxiety, and agency?

COMPETENCY: Comparative Literary Analysis and Theological Reasoning

STEPS:
- Step 1: Define the Saguna Protagonist's Self: Relational, dependent, *dasya/bhava* (servant/lover), defined by *virah* (separation), agency surrendered to Beloved's will. Anxiety = "Will He accept me?"
- Step 2: Define Dadu's Nirguna Protagonist's Self: Substantive, autonomous, *jnana/virakti*, defined by *avikalpa* (non-dual certainty), agency = *purushartha* (effort via *shabda*). Anxiety = "Am I distracted?"
- Step 3: Analyze Desire: Saguna = desire *for* the Person (form). Nirguna = desire *as* the Person (formless). The protagonist doesn't "want" God; he *unveils* God.
- Step 4: Analyze Agency: Saguna protagonist waits for *kripa* (grace). Nirguna protagonist *practices* *surat-shabda-yoga* (attention on sound). The imperatives ("sunat", "karat") show active agency.
- Step 5: Evaluate Psychological Profile: The Nirguna protagonist is psychologically "flatter" (less emotional turbulence) but "deeper" (ontological confidence). He resembles a scientist of consciousness, not a lover.
- Step 6: Board-Exam Link: This comparison is a classic 6-marker "Compare the nature of bhakti in..." question. Use terms: *prema* vs *jnana*, *duality* vs *non-duality*, *external locus* vs *internal locus*.

ANSWER: The Nirguna protagonist constructs the self as *atman*—already divine, merely obscured—whereas the Saguna protagonist constructs the self as *jiva*—eternally distinct, reaching toward the Divine. In Surdas/Mira, the "I" is constituted by *lack* (separation from Krishna); desire is the engine, anxiety is the fuel. In Dadu, the "I" is constituted by *fullness* (the *shabda* within); desire is the obstacle, *virakti* is the method. Consequently, Dadu's protagonist exhibits zero devotional anxiety—no "when will He come?"—only pedagogical urgency: "Wake up, you are already That." His agency is 100% internal (control *surat*, repeat *shabda*), unlike the Saguna bhakta whose agency is mediated by the Beloved's *lila*. Psychologically, the Nirguna protagonist is a *sadhaka* (practitioner) with the steady focus of a surgeon; the Saguna protagonist is a *premi* (lover) with the volatility of a poet. This doesn't make him "less emotional"—the poem's compassion for the deluded is intense—but his emotion is *cognitive* (clarity as compassion), not *affective* (longing as love). For the board exam: tabulate "Locus of Divinity," "Primary Emotion," "Means," "Agency" — this comparison *is* the answer.

DIFFICULTY: hard