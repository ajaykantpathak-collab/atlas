## DEFINITION
Irony is a literary device where the intended meaning of words or events is opposite to their literal or surface meaning, creating a contrast between expectation and reality. Symbolism is the use of concrete objects, images, or actions to represent abstract ideas, emotions, or concepts beyond their literal significance.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student must be able to identify at least two instances of irony and two symbols in the poem "चुकजल," explain how each device functions in context, and write a structured 150-word analysis connecting these devices to the poem's central theme of irreversible change and lost innocence.

## SCOPE_BOUNDARY
This node covers identification, analysis, and interpretation of irony (situational, dramatic, verbal) and symbolism (objects, natural elements, recurring motifs) specifically in the poem "चुकजल" from NCERT Antra Chapter 4. It does NOT cover other rhetorical devices like alliteration, personification, or extended allegory, nor does it address prose texts from other chapters.

## WALKTHROUGH
Imagine you revisit your childhood village after ten years — the banyan tree is gone, the pond is a parking lot, and the old man who sold mangoes doesn't recognize you. That stab of "this isn't what I expected" is irony; the parking lot replacing the pond is a symbol of how modernity erases memory. Start by reading the poem aloud twice: first for the story (what happens), second for the gaps (what is said vs. what is meant). Mark every concrete noun — तालाब, वीथी, लब्ज़ लक़ी, एक्कज-एक्कज — and ask: "What abstract idea could this stand for?" Then hunt for statements where the poet's tone contradicts the surface description (e.g., calling the changed village "वक़्क़" while describing its decay). The key insight: irony and symbolism work together — the symbols (pond, lane) make the irony (loss disguised as progress) tangible.

## DIAGNOSTIC_QUESTION_1
Define "situational irony" and "symbol" in your own words, giving one example from daily life (not from the poem) for each.

## DIAGNOSTIC_ANSWER_1
Situational irony occurs when the outcome of a situation is sharply contrary to what was expected (e.g., a fire station burning down). A symbol is a concrete object that stands for an abstract idea (e.g., a wilting tulsi plant symbolizing a family's fading traditions). A wrong answer that confuses irony with mere coincidence (e.g., "it rained on my picnic") reveals the student cannot distinguish structural contrast from random misfortune. A wrong answer that treats a symbol as a mere decoration (e.g., "the pond is just a pond") shows the student misses the representational layer essential for Class 12 analysis.

## DIAGNOSTIC_QUESTION_2
In the poem, the line "वक़्क़ गै ब्ल्ध कुकव" (this is the village) appears after descriptions of decay. Explain why this statement is ironic. What expectation does it subvert?

## DIAGNOSTIC_ANSWER_2
The statement is ironic because the speaker labels the transformed, decayed space as "the village" — the very word that once carried wholeness, familiarity, and belonging — while the imagery (dried ponds, strangers' footsteps, erased landmarks) proves the village *as the speaker knew it* has ceased to exist. The irony subverts the expectation that a name preserves identity; here the label "वक़्क़" masks erasure. A wrong answer that says "the poet is lying" misses the nuance: the poet isn't deceiving, but exposing how language fails to capture loss. A wrong answer that calls it "sadness" confuses emotion with the structural device of irony.

## DIAGNOSTIC_QUESTION_3
The phrase "लब्ज़ लक़ी" (tears of the eye/heart) appears in the poem. Identify whether this functions primarily as a metaphor or a symbol, and justify your choice by explaining what abstract idea it represents in context.

## DIAGNOSTIC_ANSWER_3
"लब्ज़ लक़ी" functions as a **symbol**, not merely a metaphor. A metaphor would compare tears to something else ("tears *are* rain"); here the phrase *is* the recurring concrete image that accumulates meaning across stanzas — representing the speaker's unspoken grief for the lost village, the collective pain of displaced communities, and the inadequacy of language to articulate that loss. The repetition "लब्ज़ लक़ी... लब्ज़ लक़ी" anchors it as a symbolic motif. A wrong answer calling it "just a metaphor" treats it as a one-time comparison, missing how symbols gain weight through recurrence and contextual resonance — a key distinction in board marking schemes.

## DIAGNOSTIC_QUESTION_4
Compare the irony in the opening stanza (the village appears familiar yet feels alien) with the irony in the closing stanza (the speaker's own "वीथी" on the village). How do these two ironies frame the poem's movement from observation to self-implication?

## DIAGNOSTIC_ANSWER_4
The opening irony is **external**: the speaker sees the village ("वलर गै ब्ल्ध कुकव") but senses its soul is gone — a gap between appearance and reality *outside* the self. The closing irony is **internal**: the speaker realizes his own "वीथी" (path/lane) is now part of the village's decay ("वलर नवलर लै वलर लै वलर"), implicating himself in the very erasure he mourns. Together they frame a movement from *witness* to *participant* — the observer discovers he is also the observed, the griever is also the cause. A wrong answer that treats both as "the same sadness" flattens the structural arc; boards reward tracing how irony shifts from descriptive to reflexive.

## DIAGNOSTIC_QUESTION_5
Evaluate this student claim: "The pond (तालाब) in the poem is only a setting detail; removing it wouldn't change the poem's meaning." Defend or refute using evidence from the text.

## DIAGNOSTIC_ANSWER_5
**Refute.** The pond is the poem's central symbol — it reflects the sky (unchanging) while its water dries (change), mirroring the village's paradox: the name remains, the essence vanishes. Key evidence: "वलर कुकव लै वलर लै वलर" (the pond's water reflects the sky) juxtaposed with "वलर लै वलर लै वलर" (the pond itself is gone). Removing it collapses the symbol system: no reflecting surface = no metaphor for memory, no drying water = no tangible image of irreversible loss. A wrong answer agreeing with the claim reveals the student treats setting as backdrop rather than symbolic architecture — a frequent 2-mark error in board exams where "setting" questions demand symbolic reading.

## DIAGNOSTIC_QUESTION_6
Write a 4-line stanza in Hindi (free verse) that uses **one symbol** and **one instance of situational irony** to express the feeling of returning to a changed childhood home. Do not copy images from "चुकजल."

## DIAGNOSTIC_ANSWER_6
नीम की छाँव अब पार्किंग का बोर्ड पहनती है,  
वह झूला जहाँ चोट लगी थी, अब सेल्फी का फ्रेम है।  
दादी की खाँसी दीवारों में दबी रह गई,  
और मैं — वही बच्चा — ताला खोलने की चाबी भूल आया।  

**Symbol:** नीम की छाँव (neem shade) = lost protection/continuity.  
**Irony:** The speaker holds the key (expectation of access) but has *forgotten* it (reality of disconnect) — the home is physically open but emotionally locked.  
A poor answer that uses only nostalgia ("I miss my home") without a concrete symbol or structural irony shows the student cannot *generate* the devices they are asked to *analyze* — a gap that costs marks in creative-writing sections of CUET/board papers.

## COMMON_MISCONCEPTION
Students routinely confuse **irony** with **coincidence** or **misfortune** (e.g., "the pond dried up — how ironic!" — no, that's just sad). They also treat **symbols** as **one-to-one codes** (e.g., "तालाब = childhood" full stop) instead of recognizing that symbols in "चुकजल" are **polysemous**: the pond reflects the sky (eternity), dries (mortality), mirrors the speaker's face (self-confrontation), and holds the village's history (collective memory) — all simultaneously. This reductionism stems from Class 10-style "identify the device" drills that reward labeling over layered interpretation. In Class 12 boards and CUET, a symbol *must* be shown operating at multiple semantic levels within the same passage.

## ON_FAILURE
1. **Revisit c12_hin_a_cbse_04_008 (Imagery and Metaphor):** Re-read the worked example on "extended metaphor" — symbols function like extended metaphors but with cultural resonance. Do the "image → abstraction" mapping exercise again using the pond.  
2. **Micro-drill:** Take 3 concrete nouns from the poem (वीथी, लब्ज़ लक़ी, एक्कज-एक्कज). For each, write *three* distinct abstract ideas it could symbolize, citing the line where each reading is triggered.  
3. **Irony audit:** List every statement in the poem where the speaker *names* something (वक़्क़, वलर, वलर). Next to each, write what the imagery *shows* instead. The gap = irony.  
4. **Re-diagnostic:** Attempt Diagnostic Questions 2 and 4 again. If irony identification remains below 80% accuracy, schedule a 15-min oral explanation with the teacher using the "expectation vs. reality" T-chart.

## BUILDS_ON
c12_hin_a_cbse_04_008 (Literary Devices: Imagery and Metaphor) — students must already distinguish literal imagery from figurative comparison before layering irony/symbolism.

## LEADS_TO
c12_hin_a_cbse_04_013 (Critical Thinking: Analysis and Interpretation) — where irony and symbolism become evidence for thematic arguments in long-answer questions.

## PREREQUISITE_NODE_IDS
c12_hin_a_cbse_04_008, c12_hin_a_cbse_04_006, c12_hin_a_cbse_04_007, c12_hin_a_cbse_04_002, c12_hin_a_cbse_04_003, c11_hin_ar_cbse_04_009, c11_hin_ar_cbse_08_009, c11_hin_v_cbse_04_009

## PREREQUISITE_REASONS
c12_hin_a_cbse_04_008: Imagery/Metaphor node establishes the figurative-language foundation; symbols are a subset of metaphoric thinking.  
c12_hin_a_cbse_04_006: Primary theme (irreversible change/loss of innocence) provides the thematic anchor that irony/symbolism serve.  
c12_hin_a_cbse_04_007: Secondary themes (urbanization, memory, language failure) give context for why specific symbols (pond, lane) are chosen.  
c12_hin_a_cbse_04_002: Narrative structure reveals *where* irony peaks (opening vs. closing) — essential for structural analysis.  
c12_hin_a_cbse_04_003: Setting/Atmosphere node identifies the physical landscape (pond, village) that becomes symbolic raw material.  
c11_hin_ar_cbse_04_009: Class 11 Antra Chapter 4 covered irony/symbolism in a different poem — transfers the *analytical framework*, not content.  
c11_hin_ar_cbse_08_009: Class 11 Antra Chapter 8 reinforced symbol-tracking across stanzas — skill directly reused here.  
c11_hin_v_cbse_04_009: Class 11 Vitan Chapter 4 introduced symbolism in prose memoir — cross-genre reinforcement of the device.

## FORWARD_NODE_IDS
c12_hin_a_cbse_04_010, c12_hin_a_cbse_04_012, c12_hin_a_cbse_04_013, c12_hin_a_cbse_04_014, c12_hin_a_cbse_04_015

## FORWARD_REASONS
c12_hin_a_cbse_04_010: Vocabulary node uses symbolic terms (लब्ज़ लक़ी, एक्कज-एक्कज) as key lexical items for meaning-in-context questions.  
c12_hin_a_cbse_04_012: Comprehension questions (literal/inferential) require spotting irony to answer "what is implied but not stated."  
c12_hin_a_cbse_04_013: Critical thinking answers *are* structured analyses of irony/symbolism → theme; this node provides the evidence base.  
c12_hin_a_cbse_04_014: Writing skills (analytical paragraph, essay) demand the PEEL structure practiced here: Point (device), Evidence (line), Explanation (function), Link (theme).
c12_hin_a_cbse_04_015: Gives irony and symbolism insights (e.g., "vkèkk gS vkSj vkèkk ugha gS") that enable nuanced interpretive questions.  

## CROSS_SUBJECT_PREREQS
c11_soc_cbse_03_002, c11_psy_cbse_05_001

## CROSS_SUBJECT_REASONS
c11_his_cbse_08_004: History Chapter 8 (Colonialism and the City) — urbanization erasing traditional spaces parallels the poem's village decay; irony of "development" as destruction.  
c11_soc_cbse_03_002: Sociology Chapter 3 (Social Change) — concepts of *Sanskritization* and *Westernization* explain the social forces behind the symbolic landscape change.  
c11_psy_cbse_05_001: Psychology Chapter 5 (Memory) — "reconstructive memory" and "nostalgia bias" explain why the speaker's return generates irony: memory idealizes, reality disappoints.

## CHAIN_DESCRIPTION
c12_hin_a_cbse_04_008 -> c12_hin_a_cbse_04_009 -> c12_hin_a_cbse_04_013 : Imagery/Metaphor provides figurative base; Irony/Symbolism deepens to structural-thematic analysis; Critical Thinking deploys both for board/CUET long answers.

## THIS_FORMULA
N/A - conceptual

## FORMULA_VARIABLES
N/A

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
linguistic

## CROSS_SUBJECT
N/A | The poem's depiction of village transformation mirrors History's "Rural Change in Post-Independence India" — both use concrete landscape change (pond → parking lot) as symbol for structural displacement.  
c12_geo_cbse_04_002 | Geography's "Human Settlements" chapter analyzes pond loss as ecological + cultural erosion; the poem's तालाब symbolizes the same aquifer-culture nexus.  
c12_eco_cbse_02_003 | Economics' "Poverty and Inequality" module — the irony of "development" language (वक़्क़ गै ब्ल्ध कुकव) masking livelihood loss echoes the poem's linguistic irony.
## PREREQ_CONCEPT
Distinguishing literal vs. figurative meaning and tracking a concrete image across stanzas to infer abstract significance.

## PREREQ_BEFORE
Student must be able to: (1) mark every concrete noun in the poem, (2) state the poem's primary theme in one sentence, (3) explain the difference between metaphor and symbol using a non-text example.

## PREREQ_STUCK
If stuck, review the "Image → Abstraction" mapping table from c12_hin_a_cbse_04_008 Worked Example 2 and re-do the "three readings per symbol" micro-drill in ON_FAILURE step 2.

## WORKED_EXAMPLE_1
**PROBLEM:** Analyze how the recurring phrase "एक्कज-एक्कज" (slowly-slowly/gradually) functions as *both* a structural device and a symbol in the poem. Show how it generates situational irony in the final stanza.

**STEPS:**
- Step 1: Locate all occurrences of "एक्कज-एक्कज" — Stanza 2 (children playing), Stanza 4 (elders walking), Stanza 6 (speaker's realization). Note the repetition pattern.
- Step 2: Identify the literal meaning in each context: Stanza 2 = unhurried childhood time; Stanza 4 = aging bodies moving at village pace; Stanza 6 = irreversible change creeping up unnoticed.
- Step 3: Abstract the symbolic value: "एक्कज-एक्कज" symbolizes *time as experienced* (cyclical, generous) vs. *time as lived* (linear, thief). The same phrase measures both the village's rhythm and its erasure.
- Step 4: Pinpoint the irony: In Stanza 6, "एक्कज-एक्कज" describes how the village *disappeared* — the very slowness that once defined its peace became the mechanism of its loss (no sudden alarm, just gradual drying). The speaker expected to *return*; the slowness ensured he *missed* the leaving.
- Step 5: Connect to theme: The symbol binds form (repetition across stanzas) to content (time's dual nature), making the irony structural — the poem's rhythm *enacts* the village's fading.

**REASONING:** This 5-step method (locate → literal → symbolic → ironic gap → thematic payoff) is the exact template CBSE marking schemes reward for "literary device analysis" questions. It forces the student to move from spotting the device to explaining its *work* in the text.

**ANSWER:** "एक्कज-एक्कज" operates as a polyvalent symbol: (1) literal village tempo, (2) metaphor for unperceived change, (3) structural refrain linking stanzas. Its final occurrence creates situational irony — the slow pace that once nurtured childhood now signifies the stealth of loss. The speaker's return is ironic because he moved at "एक्कज-एक्कज" speed too, and thus arrived *after* the village had already become "वलर लै वलर लै वलर."

## WORKED_EXAMPLE_2
**PROBLEM:** The poem describes "वलर कुकव लै वलर लै वलर" (the pond's water reflects the sky) and later "वलर लै वलर लै वलर" (the pond is gone). Write a PEEL paragraph explaining how this contrast constructs the poem's central symbol and what irony it reveals about memory.

**STEPS:**
- Step 1: **Point** — The pond is the poem's master symbol; its transformation from reflecting surface to absent space encodes the impossibility of recovering the past.
- Step 2: **Evidence** — Stanza 3: "वलर कुकव लै वलर लै वलर" (water holds sky). Stanza 5: "वलर लै वलर लै वलर" (pond itself erased). The verb shift from *reflects* (active, present) to *gone* (terminal, past) is the linguistic pivot.
- Step 3: **Explanation** — Water reflecting sky = memory's promise: the past seems intact, accessible, mirrored. Pond gone = memory's reality: the container (village) that held the reflection has vanished. The symbol works because the *same noun* (वलर) carries both states.
- Step 4: **Explanation (Irony layer)** — The irony is *dramatic*: the speaker (and reader) sees the reflection first, believes the pond exists, then discovers the pond was already gone *while* it reflected. Memory shows us a sky that has no pond beneath it.
- Step 5: **Link** — This symbol-irony complex proves the theme: "थाउ लै फ्क़ुक़ लै ओळरक़ लै ओळक़ लै" — things and feelings don't exist without each other; when the physical village (वलर) dies, the emotional village (memory's reflection) has no ground.

**REASONING:** PEEL (Point, Evidence, Explanation, Link) is the mandated answer structure for 5-mark "analyze the device" questions in CBSE Hindi Core. This example models the *double explanation* (symbol + irony) that distinguishes 4/5 from 5/5 responses.

**ANSWER:** The pond (वलर) is the poem's master symbol because its two states — reflecting sky (Stanza 3) and erased (Stanza 5) — map exactly onto memory's illusion and reality. The verb shift from "लै" (reflects/holds) to "लै" (gone/absent) on the same noun creates dramatic irony: we see the reflection *before* knowing the pond is dead, just as the speaker revisits the village *before* realizing it exists only in his gaze. This proves the theme: without the physical वलर (village/container), the emotional reflection (memory) has no ground — "थाउ लै फ्क़ुक़ लै ओळरक़ लै ओळक़ लै."

## WORKED_EXAMPLE_3
**PROBLEM:** Compare the use of **verbal irony** in the speaker's address to the village ("वलर गै ब्ल्ध कुकव") with the **symbolic irony** of "लब्ज़ लक़ी" (tears) becoming "वलर लै वलर लै वलर" (the pond's tears/drying). How do these two ironies — one linguistic, one imagistic — collaborate to show that *language itself fails to preserve the village*?

**STEPS:**
- Step 1: Define verbal irony in context — speaker *names* the village "वलर" (intact entity) while imagery shows it fragmented. The label contradicts the described reality.
- Step 2: Define symbolic irony of "लब्ज़ लक़ी" → "वलर लै वलर लै वलर" — tears (liquid, expressive) become the pond's drying (liquid, silent loss). The symbol *enacts* what the words *fail to say*.
- Step 3: Trace the collaboration — Stanza 1: Verbal irony ("वलर गै...") opens the gap between name and thing. Stanza 3-5: Symbolic irony (pond as tear-holder → pond as dried bed) *widens* the gap visually. Stanza 6: Speaker's own "वीथी" (path/voice) merges with the loss — language (वीथी = speech/path) is now part of the ruin.
- Step 4: Synthesize — Verbal irony shows language *misrepresenting* reality; symbolic irony shows reality *outpacing* language (the pond dries while we call it "वलर"). Together they prove the poem's meta-theme: "फ्क़ुक़ लै क्व़क़ लै" — speech cannot catch the world.
- Step 5: Board-exam application — A 6-mark question "Analyze how irony and symbolism reveal the failure of language" requires exactly this dual-track evidence: one linguistic (naming), one imagistic (pond/tears), converging on the same thesis.
- Step 6: Self-check — Does the answer quote *both* the verbal statement ("वलर गै...") and the symbolic progression (वलर कुकव → वलर लै)? Yes. Does it name the *types* of irony? Yes. Does it end on the theme? Yes.

**REASONING:** This worked example models the *synthesis* level expected in CUET/Higher Order Thinking questions — combining two device types (verbal irony, symbolic irony) across the poem's arc to support a meta-thematic claim (language's failure). The 6-step structure ensures no evidence strand is dropped.

**ANSWER:** The verbal irony of "वलर गै ब्ल्ध कुकव" (naming the ruined space "village") and the symbolic irony of the pond transforming from tear-holder ("लब्ज़ लक़ी" reflected in वलर कुकव) to dried bed ("वलर लै वलर लै वलर") form a pincer movement: words *lie* by preservation (the name stays), images *tell* by erosion (the pond goes). The speaker's final realization — "वलर नवलर लै वलर लै वलर" (my own path/speech is part of the ruin) — closes the loop: language (वीथी = path/utterance) doesn't just fail to save the village; it *participates* in its erasure by naming what no longer exists. This is the poem's deepest irony: the device meant to preserve (language) becomes the record of loss.

## COMPETENCY_QUESTION_1
**QUESTION:** A Class 12 student writes: "The irony in 'चुकजल' is that the poet calls the changed village 'वक़्क़' even though it's not the same. The symbol is the pond which means childhood."  
Rewrite this answer to meet CBSE 5-mark "Analyze the use of irony and symbolism" criteria. Your rewrite must: (a) distinguish situational from verbal irony, (b) show the pond operating at *three* symbolic levels, (c) use PEEL structure, (d) include the phrase "वलर कुकव लै वलर लै वलर → वलर लै वलर लै वलर" as evidence.

**COMPETENCY:** Critical Analysis & Structured Writing (CBSE Board Pattern: Long Answer Type II)

**STEPS:**
- Step 1: Open with a thesis sentence naming *both* devices and their thematic function (language vs. landscape, naming vs. being).
- Step 2: PEEL Paragraph 1 — Verbal irony: Point (naming contradicts seeing), Evidence ("वलर गै ब्ल्ध कुकव" vs. decay imagery), Explanation (label preserves, reality erases), Link (sets up the language-failure theme).
- Step 3: PEEL Paragraph 2 — Symbolic irony of pond: Point (pond as master symbol), Evidence ("वलर कुकव लै वलर लै वलर → वलर लै वलर लै वलर"), Explanation (three levels: reflection of eternity / container of collective grief / ground for memory's validity), Link (symbol does what words cannot — *shows* the loss).
- Step 4: Synthesis sentence — The two ironies converge: verbal irony exposes language's inadequacy; symbolic irony provides the *evidence* language suppresses.
- Step 5: Close with thematic payoff — "थाउ लै फ्क़ुक़ लै ओळरक़ लै ओळक़ लै" is proven by this device collaboration.

**ANSWER:** The poem deploys verbal irony ("वलर गै ब्ल्ध कुकव" masking decay) and the pond's symbolic irony ("वलर कुकव लै वलर लै वलर → वलर लै वलर लै वलर") to demonstrate language's failure to preserve the village.  
**Verbal Irony (PEEL):** The speaker's label "वलर" asserts continuity, but the imagery (dried water, strangers, erased names) proves rupture — the name *performs* the very erasure it denies.  
**Symbolic Irony (PEEL):** The pond operates at three levels: (1) mirror of the sky (eternity untouched by time), (2) holder of "लब्ज़ लक़ी" (collective grief made tangible), (3) ground of memory (without the pond, the reflection has no source). Its drying is not just loss but *exposure* of memory's fragility.  
**Convergence:** Verbal irony shows words *hiding* the truth; symbolic irony shows the landscape *revealing* it. Together they enact "थाउ लै फ्क़ुक़ लै ओळरक़ लै ओळक़ लै" — the village (वलर) and its feeling (फ्क़ुक़) die together because language (वीथी) could not hold them.

**DIFFICULTY:** medium

## COMPETENCY_QUESTION_2
**QUESTION:** (CUET / JEE-Advanced style *Application*)  
A filmmaker adapts "चुकजल" into a 3-minute silent short film. She must convey the poem's **central verbal irony** (the name "वलर" vs. reality) and **master symbol** (pond as memory-ground) *without dialogue or voiceover*.  
Design a **shot list of 5 shots** (visual only) that achieves this. For each shot, specify: (i) visual content, (ii) duration, (iii) which irony/symbol it renders, (iv) how the *edit transition* to the next shot creates ironic tension.

**COMPETENCY:** Intermedial Translation & Creative Application (CUET Domain-Specific / Portfolio)

**STEPS:**
- Step 1: Shot 1 — Establish the *verbal irony visually*: Wide shot of a signboard "वलर" (village name) leaning crooked; pan down to cracked earth where a pond should be. Duration: 4 sec. Renders: verbal irony (name present, referent absent). Transition: *Hard cut* to...
- Step 2: Shot 2 — *Symbolic irony (Level 1 — Reflection)*: Close-up of a shard of mirror on dry pond bed reflecting clouds. Duration: 3 sec. Renders: "वलर कुकव लै वलर लै वलर" — sky reflected without water. Transition: *Slow dissolve* (time passing) to...
- Step 3: Shot 3 — *Symbolic irony (Level 2 — Grief container)*: Extreme close-up of an old woman's eye; a single tear falls, hits dust, vanishes instantly. Duration: 3 sec. Renders: "लब्ज़ लक़ी" → absorption/erasure. Transition: *Match cut on circular shape* (tear → pond) to...
- Step 4: Shot 4 — *Symbolic irony (Level 3 — Memory ground)*: Drone rise from dry pond center; concentric circles of cracked mud expand outward like ripples in reverse. Duration: 5 sec. Renders: "वलर लै वलर लै वलर" — the pond's absence *is* the image. Transition: *Smash cut to black* (silence = language failure) to...
- Step 5: Shot 5 — *Verbal irony resolved*: The same signboard "वलर" from Shot 1, now half-buried in sand; a child's plastic toy truck drives over it. Duration: 4 sec. Renders: Name becomes ruin; next generation plays on the erasure. End on freeze-frame.

**ANSWER:** The 5-shot sequence translates the poem's dual irony into pure visual syntax: Shot 1 establishes the linguistic lie (sign vs. reality); Shots 2-4 unfold the pond's three symbolic levels through reflection, tear, and cracked geometry — each transition (hard cut, dissolve, match cut) *enacts* the irony (abrupt loss, slow fading, cyclical return); Shot 5 returns to the sign, now claimed by time and indifference. No words needed — the edit rhythm *is* the irony.

**DIFFICULTY:** hard