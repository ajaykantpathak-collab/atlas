## DEFINITION
Plot and narrative structure in poetry refers to the organized sequence of events, thoughts, or emotional progression that the poet presents through the speaker's voice. Unlike prose, a poem's narrative structure may be non-linear, fragmented, or lyrical, but it still follows a deliberate pattern (exposition, conflict, climax, resolution) that shapes the reader's understanding of the central experience.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student can independently map the narrative arc of Meera's poem by identifying the speaker's emotional progression across stanzas, explain how structural shifts (e.g., address to friend, description of physical state, final renunciation) advance the devotional narrative, and write a structured answer using the PEEL method with textual evidence.

## SCOPE_BOUNDARY
This node covers analysis of narrative structure in Meera's pad (poem) from Class 11 Aroh Chapter 10, focusing on sequencing of the speaker's experience, structural devices (address, imagery progression, refrain), and answer-writing technique. It does NOT cover plot analysis of prose fiction, nor does it require memorizing the full poem text.

## WALKTHROUGH
Imagine you are telling a friend about a movie you watched, but you only have 30 seconds — you wouldn't list every scene; you'd give the turning points: "First the hero is lost, then she meets a guide, then she faces her fear, finally she finds peace." Meera's poem works the same way: it compresses a spiritual journey into a few stanzas. To analyze its narrative structure, start by reading the poem aloud to hear the emotional beats. First, identify the speaker (Meera) and her audience (her friend/sakhi). Then trace the sequence: Stanza 1 establishes her inner state (mind fixed on Giridhar), Stanza 2 shows physical consequences (body wasting, ornaments discarded), Stanza 3 is the climax — a direct plea to stop worldly questioning. Notice how each stanza escalates the renunciation. The key insight: the poem's structure mirrors the bhakti path — from internal devotion to external rejection of norms to final surrender.

## DIAGNOSTIC_QUESTION_1
What is the primary difference between analyzing plot in a short story and analyzing narrative structure in a lyric poem like Meera's pad?

## DIAGNOSTIC_ANSWER_1
In a short story, plot follows external events with clear cause-effect chains (exposition → rising action → climax → falling action → resolution). In a lyric poem, narrative structure tracks the speaker's internal emotional or spiritual progression, often through associative leaps, imagery clusters, and tonal shifts rather than chronological events. A wrong answer (e.g., "poems don't have plots") reveals the student hasn't grasped that narrative structure in poetry operates on psychological/spiritual time, not clock time.

## DIAGNOSTIC_QUESTION_2
In Meera's poem, the speaker addresses her "sakhi" (friend) in the opening line. How does this direct address function structurally in the poem's narrative?

## DIAGNOSTIC_ANSWER_2
The address to the sakhi establishes the dramatic situation (exposition): it frames the poem as a confidential confession, creating intimacy and justifying the speaker's vulnerability. It also sets up the conflict — the world (represented by the sakhi) expects conventional behavior, while the speaker has already crossed into divine madness. A wrong answer (e.g., "it's just a poetic convention") misses how the addressee shapes the poem's argumentative structure — the entire poem is a persuasive speech *to* the sakhi, not merely a description.

## DIAGNOSTIC_QUESTION_3
Apply the concept of "rising action" to Meera's poem: identify the specific images in the middle stanza that escalate the speaker's renunciation of worldly life, and explain how they build toward the climax.

## DIAGNOSTIC_ANSWER_3
The middle stanza progresses from internal state to external markers: "valqou ty lhafp&lhafp" (eyes rolling in trance) → "izse&csfy cks;h" (love's fever) → "nwèk dh eFkfu;k¡ cM+s izse ls foyks;h" (body wasting from intense love) → "nfèk efFk ?k`r dkf<+ fy;ks" (discarding ornaments/jewelry). Each image strips away another layer of social identity (body, beauty, adornment), escalating toward the climax where she rejects all worldly inquiry. A wrong answer that lists images without showing *progression* (e.g., "she looks sick and removes jewelry") fails to see structural escalation.

## DIAGNOSTIC_QUESTION_4
Compare the narrative function of the refrain "nkfl ehjka yky fxjèkj! rkjks vc eksgh" (O Meera's Lord Giridhar, now what can I do?) with the final line's direct command to the sakhi. How does this structural contrast resolve the poem's tension?

## DIAGNOSTIC_ANSWER_4
The refrain (repeated or implied as a structural anchor) is an inward cry to the Divine — helpless surrender. The final line ("vc r csfy iSQfy xbZ] vk.kan&iQy gks;h" — now love has awakened, I have become indifferent to the world) turns outward, addressing the human world with authority. The structure moves from *petitioning God* to *commanding the world*, resolving the tension by showing the devotee's power comes from submission. A wrong answer treating both as "emotional expressions" misses the strategic reversal of power dynamics encoded in the structure.

## DIAGNOSTIC_QUESTION_5
Evaluate this student claim: "Meera's poem has no real narrative because nothing happens — she just says she loves Krishna." Is this a valid critique of the poem's narrative structure? Justify your answer.

## DIAGNOSTIC_ANSWER_5
Invalid critique. The poem enacts a complete spiritual narrative: the *event* is the speaker's irreversible transformation from a socially embedded woman (with ornaments, family, body) to a singular devotee. The "action" is internal and symbolic — discarding jewelry, wasting body, rejecting social speech — each a narrative beat. The structure *is* the enactment of renunciation. A student making this claim confuses "external plot events" with "narrative structure of consciousness," a category error at senior secondary level.

## DIAGNOSTIC_QUESTION_6
Write a 4-line stanza in Hindi (or English) that mimics Meera's narrative structure: establish a speaker-addressee relationship, show escalating renunciation through three concrete images, and end with a decisive rejection of the addressee's worldview.

## DIAGNOSTIC_ANSWER_6
Example (Hindi):
"Sakhi, mann mera shyam sang laga, tu samjhe na koi baat,
Pehen ke maal ke haath, chhoda ghar-bar ki saari raat,
Tan ghal ghal ke kanchan jaisa, naina bhae bawre,
Ab na puchh mere dard ki dawa, main toh ho gayi tumse nyare."
A poor answer would lack addressee, show no image progression, or end weakly. This tests whether the student can *operationalize* the structural pattern creatively.

## COMMON_MISCONCEPTION
Students often believe a poem must tell a chronological story with characters and events (like a mini-novel) to have a "plot." They miss that bhakti poetry's narrative is the *trajectory of the soul* — the structure maps the devotee's inner journey from separation to union, using associative imagery rather than external action. For example, they'll say "Meera didn't *do* anything in the poem" ignoring that discarding ornaments (nfèk efFk ?k`r dkf<+ fy;ks) is a enacted narrative climax symbolizing total social rupture.

## ON_FAILURE
1. Have the student read the poem aloud *three times*: first for sound, second to mark every concrete image (body, jewelry, eyes, friend), third to number the stanzas and label each one's function (confession → evidence → climax → verdict).
2. Draw a 4-box storyboard: Box 1 = Speaker + Addressee; Box 2 = Internal State; Box 3 = Physical Proof; Box 4 = Final Declaration. Fill each with one Hindi phrase from the poem.
3. Ask: "If this were a film scene, what would the camera show in each box?" This forces visualization of narrative beats.
4. Finally, co-write a PEEL paragraph for Stanza 2: Point (Escalation), Evidence (three images), Explanation (each strips identity), Link (builds to final rejection).

## BUILDS_ON
c11_hin_ar_cbse_10_001 (Context: Meera's historical rebellion against feudal patriarchy provides the external conflict that the poem's internal narrative structure resolves).

## LEADS_TO
c11_hin_ar_cbse_10_003 (Setting and Atmosphere: The poem's narrative structure creates its emotional landscape — the "setting" is the speaker's body and the "atmosphere" is the intensity of viraha).

## PREREQUISITE_NODE_IDS
c11_hin_ar_cbse_10_001
## PREREQUISITE_REASONS
c11_hin_ar_cbse_10_001: Understanding Meera's historical context (feudal Rajputana, patriarchal constraints, bhakti as rebellion) is essential to read the poem's narrative structure as a *strategic* renunciation, not just emotional outpouring.

## FORWARD_NODE_IDS
c11_hin_ar_cbse_10_003, c11_hin_ar_cbse_10_004, c11_hin_ar_cbse_10_006, c11_hin_ar_cbse_10_005, c11_hin_ar_cbse_10_007, c11_hin_ar_cbse_10_008, c11_hin_ar_cbse_10_010, c11_hin_ar_cbse_10_012, c11_hin_ar_cbse_10_013, c11_hin_ar_cbse_10_014, c11_hin_ar_cbse_10_015, c12_hin_a_cbse_09_002, c12_hin_ar_cbse_10_002

## FORWARD_REASONS
c11_hin_ar_cbse_10_003: Narrative structure establishes the emotional trajectory that creates the poem's atmosphere (viraha, ananda, determination). c11_hin_ar_cbse_10_004: The protagonist (Meera-as-speaker) is constructed *through* the narrative choices — what she reveals, in what order, to whom. c11_hin_ar_cbse_10_006: The primary theme (prem as mukti) is enacted, not stated — the structure *is* the theme's proof.
c11_hin_ar_cbse_10_005: Establishes the narrative structure of the biographical note and poem so students can locate where each supporting character appears.  
c11_hin_ar_cbse_10_007: Narrative structure shows how Meera's life events map onto poetic persona.  
c11_hin_ar_cbse_10_008: Narrative structure shows how the poem progresses from literal weaving to spiritual allegory.  
c11_hin_ar_cbse_10_010: Familiarity with the poem's narrative structure helps locate where key words appear and their dramatic function.  
c11_hin_ar_cbse_10_012: Understanding plot/narrative structure helps locate where explicit information appears in the poem.  
c11_hin_ar_cbse_10_013: Narrative structure understanding helps locate where key metaphors appear in the poem's progression.  
c11_hin_ar_cbse_10_014: Narrative structure of the pads (two-part progression) determines how students organize chronological or thematic essays.  
c11_hin_ar_cbse_10_015: Plot/narrative structure helps students track the poem's progression as an argument, not just verses.  
c12_hin_a_cbse_09_002: Built vocabulary for discussing narrative techniques.  
c12_hin_ar_cbse_10_002: Provides foundational knowledge of plot diagrams and narrative techniques (flashback, in media res) needed to analyze Class 12 text complexity.  
c11_hin_ar_cbse_10_004: Teaches narrative structure of the poem (stanza progression) so students can locate character-revealing moments.  
c11_hin_ar_cbse_10_006: अगला तार्किक चरण: The primary theme is the central, unifying idea that the author explores throughout the text, reveal... इस नोड की अवधारणाओं को सीधे उपयोग/विस्तारित करता है।  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
No prior class nodes available for cross-subject linking.

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_10_001 -> c11_hin_ar_cbse_10_002 -> c11_hin_ar_cbse_10_003

## THIS_FORMULA
N/A - conceptual

## FORMULA_VARIABLES
N/A

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
analytical

## CROSS_SUBJECT
c11_history_bhakti_movement | The poem's narrative structure mirrors the historical bhakti trajectory: personal devotion → social transgression → institutional rejection → spiritual autonomy. Meera's structural choices reflect the movement's core conflict.
c11_psychology_narrative_identity | The poem demonstrates narrative identity construction: the speaker *becomes* a devotee by telling her story in this specific sequence (confession → evidence → verdict), illustrating how self-narration creates the self.

## PREREQ_CONCEPT
Understanding that bhakti poetry uses first-person voice as both historical testimony and spiritual enactment — the "I" is simultaneously Meera-the-princess and Meera-the-devotee.

## PREREQ_BEFORE
Student must know Meera's historical identity (Rajput princess, widow, devotee of Giridhar) and the social taboos she violated (public singing, mixing with lower castes, rejecting sati).

## PREREQ_STUCK
Review c11_hin_ar_cbse_10_001's "Before You Read" section on Meera's life and the bhakti movement's challenge to feudal orthodoxy.

## WORKED_EXAMPLE_1
PROBLEM: Analyze how the opening stanza of Meera's pad establishes the narrative conflict between the speaker's internal reality and the external world's expectations. Use the PEEL structure.
STEPS:
- Step 1: Identify the narrative elements in Stanza 1 — Speaker (Meera), Addressee (Sakhi), Core Statement ("mann mera shyam sang laga"), Implied Conflict ("tu samjhe na koi baat").
- Step 2: Recognize the structural function: This is the *exposition* — it establishes the dramatic situation (private confession to a friend) and the central tension (incommunicability of divine love).
- Step 3: Select evidence: "esjs rks fxjèkj xksiky] nwljks u dksbZ tk osQ flj eksj&eqoqQV" (My mind is fixed on Giridhar, no one else understands this talk of love).
- Step 4: Explain how evidence works: The address to "sakhi" creates intimacy; the absolute claim ("nwljks u dksbZ") shuts out the world; "flj eksj&eqoqQV" frames love as a secret language.
- Step 5: Link to narrative arc: This opening *starts* the story at the point of no return — the speaker has already crossed over, and the poem will now justify that crossing.
REASONING: The PEEL method forces the student to move from structural identification (Point) to textual proof (Evidence) to analytical reasoning (Explanation) to narrative significance (Link) — mirroring how the poem itself builds its argument.
ANSWER: The opening stanza functions as narrative exposition by establishing a confidential address to the sakhi, immediately positioning the speaker's consciousness as already transformed ("mann mera shyam sang laga"). The evidence "nwljks u dksbZ tk osQ flj eksj&eqoqQV" creates the central conflict: the speaker's reality is incommunicable to the world. This structural choice — beginning *after* the transformation — makes the poem a defense/celebration of a completed inner journey, not a story of becoming.

## WORKED_EXAMPLE_2
PROBLEM: Trace the "escalation of renunciation" across the poem's three stanzas. Show how each stanza strips away a layer of the speaker's social identity.
STEPS:
- Step 1: Define the layers of social identity for a Rajput princess: 1) Mental allegiance (to family/dharma), 2) Physical body (as family honor), 3) Adornments (jewelry/clothes as status markers), 4) Social speech/behavior.
- Step 2: Map Stanza 1 to Layer 1: "mann mera shyam sang laga" — mental allegiance shifted from family/duty to Giridhar.
- Step 3: Map Stanza 2 to Layers 2 & 3: "valqou ty lhafp&lhafp" (eyes/body in trance), "nwèk dh eFkfu;k¡ cM+s izse ls foyks;h" (body wasting), "nfèk efFk ?k`r dkf<+ fy;ks" (discarding ornaments) — body and adornments rejected.
- Step 4: Map Stanza 3/Refrain to Layer 4: "vc r csfy iSQfy xbZ] vk.kan&iQy gks;h" — social speech/behavior abandoned; she now speaks *from* the divine position, indifferent to worldly norms.
- Step 5: Synthesize: The narrative structure *is* the sequential shedding of identity — each stanza enacts one layer's renunciation, culminating in a new identity (devotee) that has authority over the old world.
REASONING: This step-by-step mapping teaches students to read narrative structure as *thematic enactment* — the form doesn't just convey meaning, it *performs* the spiritual journey.
ANSWER: The poem's three-stanza structure enacts a systematic identity-stripping: Stanza 1 renounces mental allegiance to worldly dharma; Stanza 2 renounces the physical body (trance, wasting) and status symbols (ornaments discarded); Stanza 3 renounces social performance ("now love has awakened, I have become indifferent to the world"). The narrative arc moves from inner shift → outer signs → total behavioral rupture, making structure the vehicle of the theme "prem as mukti."

## WORKED_EXAMPLE_3
PROBLEM: A board exam question asks: "Meera's poem is not a narrative of events but a narrative of *consciousness*. Explain with reference to structural progression." Write a 150-word answer integrating context, structure, and theme.
STEPS:
- Step 1: Deconstruct the prompt — key terms: "narrative of consciousness," "structural progression," "explain with reference." Requires PEEL × 3 (one per stanza) + synthesis.
- Step 2: Draft Topic Sentence: Meera's pad structures the speaker's spiritual awakening as a three-stage narrative of consciousness: internal fixation, somatic manifestation, and social rupture.
- Step 3: Stanza 1 PEEL: Point (Internal fixation), Evidence ("mann mera shyam sang laga"), Explanation (consciousness anchored in divine, not social, reality), Link (sets up incommunicability).
- Step 4: Stanza 2 PEEL: Point (Somatic manifestation), Evidence ("nwèk dh eFkfu;k¡ cM+s izse ls foyks;h"), Explanation (body becomes text of devotion, wasting = offering), Link (internal made visible).
- Step 5: Stanza 3 PEEL: Point (Social rupture), Evidence ("vc r csfy iSQfy xbZ] vk.kan&iQy gks;h"), Explanation (new consciousness speaks with authority, rejects worldly categories), Link (completes narrative arc).
- Step 6: Synthesis: The structure *enacts* the bhakti claim that love restructures consciousness itself — no external events needed because the self *is* the event.
REASONING: Board answers require compressed analytical density — each sentence must carry concept + evidence + interpretation. This worked example models that compression.
ANSWER: Meera's pad enacts a narrative of consciousness through its three-stanza progression. Stanza 1 establishes the speaker's mental reorientation ("mann mera shyam sang laga"), positioning divine love as an incommunicable internal reality ("nwljks u dksbZ tk osQ flj eksj&eqoqQV"). Stanza 2 somatizes this consciousness: the body wastes ("nwèk dh eFkfu;k¡ cM+s izse ls foyks;h") and ornaments are discarded ("nfèk efFk ?k`r dkf<+ fy;ks"), making the inner state externally legible as renunciation. Stanza 3 culminates in social rupture — the awakened consciousness ("vc r csfy iSQfy xbZ") speaks with authority, indifferent to worldly norms ("vk.kan&iQy gks;h"). The structure thus performs the bhakti thesis: love restructures the self from within, rendering external events secondary. The poem *is* the narrative of that restructuring.

## COMPETENCY_QUESTION_1
QUESTION: In Meera's poem, the speaker's body becomes a "site of narrative" — its wasting, trance, and discarded ornaments *tell* the story of her devotion. Choose ONE physical image from the middle stanza and explain how it functions as a narrative event that advances the poem's structural argument.
COMPETENCY: Literary Analysis - Interpreting somatic imagery as narrative agency
STEPS:
- Step 1: Select a specific image (e.g., "nfèk efFk ?k`r dkf<+ fy;ks" — discarding gold ornaments).
- Step 2: Identify its literal meaning (removing jewelry) and its social meaning (rejecting married/widowed status, wealth, family honor).
- Step 3: Explain its narrative function: it is an *enacted* renunciation, not a description — the act of discarding *is* the plot point.
- Step 4: Connect to structural progression: this image comes *after* mental fixation (Stanza 1) and *before* final verbal authority (Stanza 3), making it the material proof that enables the final declaration.
ANSWER: The image "nfèk efFk ?k`r dkf<+ fy;ks" (discarding gold ornaments) functions as the poem's material climax. For a Rajput princess, ornaments signify marital status, family wealth, and social identity. Their removal is not metaphorical — it is a performed narrative event that severs her from the feudal order. Structurally, it bridges the internal fixation (Stanza 1) and the final authoritative voice (Stanza 3): the body's wasting and adornment's rejection *prove* the consciousness shift, making the final declaration earned, not asserted. The narrative advances through the body's testimony.
DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: The poem uses a "frame narrative" structure: the entire pad is addressed to the sakhi, but the refrain "nkfl ehjka yky fxjèkj! rkjks vc eksgh" addresses Giridhar. Analyze how this dual address creates a structural tension that resolves in the final line. How does this reflect the bhakti tension between *laukik* (worldly) and *parlaukik* (divine) duties?
COMPETENCY: Structural Analysis - Mapping address shifts onto thematic dualities
STEPS:
- Step 1: Identify the two addressees: Sakhi (worldly confidante, represents society/family) and Giridhar (divine beloved, represents ultimate truth).
- Step 2: Map the address shifts: Stanza 1 opens to Sakhi; Refrain cries to Giridhar; Final line returns to Sakhi but with transformed authority.
- Step 3: Analyze the tension: The speaker is caught between two claims — the sakhi expects explanation/justification within worldly logic; Giridhar demands total surrender beyond logic.
- Step 4: Show resolution: The final line ("vc r csfy iSQfy xbZ] vk.kan&iQy gks;h") resolves by *speaking to the sakhi from the position of Giridhar* — she no longer explains, she declares. The worldly addressee is now addressed *from* the divine standpoint.
- Step 5: Connect to bhakti theology: This mirrors the bhakti resolution — worldly duties (laukik) are not rejected from outside but *transcended from within* divine love (parlaukik). The structure enacts this transcendence.
ANSWER: The poem's dual address creates a structural dialectic: the sakhi embodies the *laukik* demand for accountability (why have you changed?), while Giridhar embodies the *parlaukik* claim of total possession. The refrain's cry to Giridhar ("now what can I do?") admits helplessness before the divine. The resolution comes when the speaker turns back to the sakhi not to justify but to *announce* ("now love has awakened, I have become indifferent to the world"). She speaks *from* the divine position *to* the worldly one — structurally enacting the bhakti insight that true worldly renunciation is not rejection but subsumption in a higher allegiance. The frame narrative thus performs the theology.
DIFFICULTY: hard