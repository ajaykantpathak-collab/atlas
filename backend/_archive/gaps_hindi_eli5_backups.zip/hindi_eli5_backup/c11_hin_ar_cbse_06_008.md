## DEFINITION
Imagery is the use of vivid and descriptive language that appeals to the senses (sight, sound, smell, touch, taste) to create mental pictures and sensory experiences for the reader. Metaphor is a figure of speech that directly compares two unrelated things by stating one thing is another, transferring qualities from the source domain to the target domain without using "like" or "as".

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student can identify specific images and metaphors in the text, explain how they appeal to particular senses, and analyze how they reinforce the themes of educational pressure, social inequality, or character psychology in the chapter. The student can also construct a PEEL-structured analytical paragraph citing textual evidence.

## SCOPE_BOUNDARY
This node covers identification, classification, and thematic analysis of imagery (visual, auditory, tactile, olfactory, gustatory) and metaphor (explicit and implicit) within the prescribed play "जटुह" (jtuh). It does not cover other figures of speech like simile, personification, or symbolism (covered in node 009), nor does it require analysis of poetic devices since the text is dramatic prose.

## WALKTHROUGH
Imagine you are watching a news report about a coaching factory in Kota where thousands of students cram into small rooms, the air thick with tension and the smell of stale coffee. The reporter describes it as a "pressure cooker" where dreams are boiled down to rank numbers. That description uses imagery (smell, heat, sound) and metaphor (pressure cooker) to make you feel the students' reality. Now open your textbook to the scene where जटुह describes the tuition center: notice how the playwright uses sensory details — the "गंध" of sweat, the "ध्वनि" of pages turning, the "दृश्य" of hunched backs — and metaphors like "भट्टी" (furnace) for the classroom. Your task is to spot these, name the sense they target, and explain what they reveal about the education system's dehumanizing effect.

## DIAGNOSTIC_QUESTION_1
Define imagery and metaphor in your own words, and give one example of each from everyday language (not from the textbook).

## DIAGNOSTIC_ANSWER_1
Imagery: language that creates sensory impressions (e.g., "The kitchen smelled of frying onions and cumin" — olfactory imagery). Metaphor: a direct comparison without 'like/as' (e.g., "Time is a thief" — time steals moments). A wrong answer that confuses metaphor with simile ("Time is like a thief") reveals the student hasn't grasped the structural difference. A wrong answer that gives only visual imagery ("The sky was blue") shows limited understanding of the five senses.

## DIAGNOSTIC_QUESTION_2
In the stage direction describing the tuition center (page 70: "एक छोटा-सा कमरा... गंध आ रही है"), identify two sensory images and state which sense each appeals to. Then explain why the playwright might have chosen those specific senses.

## DIAGNOSTIC_ANSWER_2
Visual: "छोटा-सा कमरा" (cramped space), Olfactory: "पसीने और स्याही की गंध" (smell of sweat and ink). The playwright chooses smell and sight to evoke claustrophobia and the physical toll of rote learning. A wrong answer that only lists visual details ("desks, chairs") misses the olfactory dimension crucial for atmosphere. A wrong answer that says "to make it realistic" without linking to theme (dehumanization) shows superficial comprehension.

## DIAGNOSTIC_QUESTION_3
Find a metaphor in जटुह's dialogue on page 72 where he compares the education system to something else. Quote the line, identify the two things compared, and explain the implied criticism.

## DIAGNOSTIC_ANSWER_3
Line: "यह तो भट्टी है, भट्टी!" (This is a furnace, a furnace!). Comparison: tuition center = furnace. Implied criticism: students are raw material being melted down; the process is violent, industrial, and strips individuality. A wrong answer that picks a simile ("जैसे भट्टी") shows confusion between metaphor and simile. A wrong answer that explains only the literal meaning ("it's hot") misses the metaphorical transfer of qualities (transformation, destruction, heat).

## DIAGNOSTIC_QUESTION_4
Compare the imagery used to describe वत्सला's home (page 73: "साफ़-सुथरा... फूलों की खुशबू") with the imagery of the tuition center. What contrast does this create, and how does it reflect the play's theme of inequality?

## DIAGNOSTIC_ANSWER_4
वत्सला's home: visual cleanliness, olfactory floral fragrance, tactile comfort → peace, privilege. Tuition center: visual crowding, olfactory sweat/ink, auditory noise → stress, exploitation. The contrast highlights how educational pressure falls unequally: the wealthy experience learning as cultivation (gardens), the poor as industrial processing (furnace). A wrong answer that only lists differences without synthesizing the thematic link (inequality) fails analysis. A wrong answer that says "one is nice, one is bad" lacks textual evidence and sensory precision.

## DIAGNOSTIC_QUESTION_5
Evaluate the effectiveness of the metaphor "बच्चे कच्ची मिट्टी के घड़े हैं" (children are unbaked clay pots) used by the principal on page 80. Does it justify the tuition system or critique it? Support your judgment with two reasons.

## DIAGNOSTIC_ANSWER_5
The metaphor critiques the system: (1) It implies children are passive raw material to be molded by external forces (teachers/parents), denying agency. (2) "Unbaked" suggests fragility — the system's heat (pressure) may crack them rather than strengthen them. The principal uses it to justify control ("we must shape them"), but the play subverts this by showing cracked pots (student breakdowns). A wrong answer that says "it justifies because teachers shape children" ignores the play's ironic framing. A wrong answer that calls it "just a comparison" fails evaluation.

## DIAGNOSTIC_QUESTION_6
Write a 4-line poetic stanza using at least two sensory images and one metaphor to describe a student's experience inside a modern coaching center. Do not copy from the text.

## DIAGNOSTIC_ANSWER_6
Example: "Fluorescent light hums like a trapped bee (auditory imagery + simile), / Rows of desks — a grid of grey concrete (visual imagery), / Each notebook a brick in the wall of ranks (metaphor: notebook = brick), / Sweat drips on algebra, evaporating dreams (tactile + olfactory imagery + metaphor)." A poor answer uses only visual imagery, no metaphor, or clichés ("books are mountains") without fresh sensory grounding. It reveals inability to transfer the skill creatively.

## COMMON_MISCONCEPTION
Students often think imagery is only visual ("pictures in the mind") and miss auditory, olfactory, tactile, gustatory images. They also confuse metaphor with simile, believing any comparison is a metaphor. In this play, they might label "जटुह की आवाज़ भारी थी" (Jtuh's voice was heavy) as a metaphor for sadness, but it's literal description of vocal quality; the metaphor would be "जटुह की आवाज़ पत्थर थी" (his voice was stone). They also tend to identify a metaphor but not explain the *transfer of qualities* (what attributes of the source — furnace, clay, thief — map onto the target).

## ON_FAILURE
1. Sensory walk: Take the student through a familiar scene (school canteen at lunch). Ask: "What do you see? Hear? Smell? Feel? Taste?" List five sensory details. 2. Metaphor mapping: Give a simple metaphor ("Homework is a mountain"). Draw two columns: Source (mountain) → Target (homework). List qualities: steep, exhausting, requires climbing, summit = completion. Practice with three examples from the text. 3. Color-code the play: Highlight visual images in yellow, auditory in blue, olfactory in green, tactile in orange, gustatory in pink. Highlight metaphors in red and draw arrows showing quality transfer. 4. Write one PEEL paragraph using the color-coded evidence.

## BUILDS_ON
Character analysis (node 004, 005) and theme analysis (node 006, 007) provide the thematic framework (educational pressure, inequality) that imagery and metaphor serve.

## LEADS_TO
Irony and Symbolism (node 009) where metaphors often become sustained symbols; Vocabulary in Context (node 010) where metaphorical word meanings are explored; Critical Thinking (node 013) where device analysis supports interpretation.

## PREREQUISITE_NODE_IDS
c11_hin_ar_cbse_06_001, c11_hin_ar_cbse_06_002, c11_hin_ar_cbse_06_003, c11_hin_ar_cbse_06_004, c11_hin_ar_cbse_06_005, c11_hin_ar_cbse_06_006, c11_hin_ar_cbse_06_007
## PREREQUISITE_REASONS
c11_hin_ar_cbse_06_001: Context/background knowledge needed to understand the social setting that imagery reflects.
c11_hin_ar_cbse_06_002: Plot structure knowledge helps locate where devices appear in narrative arc.
c11_hin_ar_cbse_06_003: Setting/atmosphere analysis directly relies on imagery; this node deepens it.
c11_hin_ar_cbse_06_004: Protagonist's psychology is revealed through metaphors he uses/attracts.
c11_hin_ar_cbse_06_005: Supporting characters' contrasting worlds are built through imagery.
c11_hin_ar_cbse_06_006: Primary theme (education system critique) is reinforced by devices analyzed here.
c11_hin_ar_cbse_06_007: Secondary themes (gender, class) are encoded in sensory contrasts.

## FORWARD_NODE_IDS
c11_hin_ar_cbse_06_009, c11_hin_ar_cbse_06_010, c11_hin_ar_cbse_06_011, c11_hin_ar_cbse_06_012, c11_hin_ar_cbse_06_013, c11_hin_ar_cbse_06_014, c11_hin_ar_cbse_06_015, c12_hin_a_cbse_04_008, c12_hin_a_cbse_05_008, c12_hin_a_cbse_16_008, c12_hin_ar_cbse_06_002, c12_hin_ar_cbse_06_003, c12_hin_ar_cbse_06_008

## FORWARD_REASONS
c11_hin_ar_cbse_06_009: Irony and symbolism often extend metaphors into structural patterns.
c11_hin_ar_cbse_06_010: Vocabulary study includes metaphorical usages of key words (e.g., "भट्टी", "घड़ा").
c11_hin_ar_cbse_06_011: Grammar node examines how figurative language bends syntactic rules.
c11_hin_ar_cbse_06_012: Comprehension questions require device identification for inferential answers.
c11_hin_ar_cbse_06_013: Critical thinking uses device analysis as evidence for interpretation.
c11_hin_ar_cbse_06_014: Writing skills apply PEEL structure practiced here to exam answers.
c11_hin_ar_cbse_06_015: Speaking/listening discussions reference textual imagery for oral analysis.
c12_hin_a_cbse_04_008: Analysis of auditory imagery in "Utsah" — helps hear the rhythm in "èkhjs&èkhjs".  
c12_hin_a_cbse_05_008: Develops ability to distinguish metaphor from simile and symbol.  
c12_hin_a_cbse_16_008: Practices sensory classification with exam-style questions.  
c12_hin_ar_cbse_06_002: Prior work on imagery helps spot the image clusters that mark structural shifts.  
c12_hin_ar_cbse_06_003: Class 11 imagery/metaphor node — needed because setting details in this poem *are* the primary metaphors (lamp, plough, sleep).  
c12_hin_ar_cbse_06_008: Provides foundational definitions and identification practice for imagery and metaphor in Class 11 context of the same chapter.  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
none

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_06_001 -> c11_hin_ar_cbse_06_008 -> c11_hin_ar_cbse_06_009: Context establishes the world; imagery/metaphor analysis reveals its texture; irony/symbolism shows its deeper structural contradictions.

## THIS_FORMULA
N/A - conceptual

## FORMULA_VARIABLES
N/A

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
conceptual

## CROSS_SUBJECT
c11_sociology_social_stratification | The play's imagery of tuition centers vs. affluent homes mirrors sociological concepts of cultural capital and reproduction of inequality through education.
c11_psychology_child_development | Metaphors like "clay pots" and "furnace" reflect psychological debates on stress, agency, and developmental trauma in high-pressure academic environments.

## PREREQ_CONCEPT
Understanding of the play's central conflict: the clash between child-centered learning and market-driven coaching culture.

## PREREQ_BEFORE
Student must have read the full play and completed nodes on plot, character, and theme to know *where* and *why* devices operate.

## PREREQ_STUCK
If stuck, re-read the stage directions on pages 70 and 73 and the principal's monologue on page 80 — these are device-dense passages.

## WORKED_EXAMPLE_1
PROBLEM: Analyze how visual and olfactory imagery in the opening stage direction (page 70) establishes the atmosphere of the tuition center and foreshadows the theme of dehumanization.
STEPS:
- Step 1: Locate the stage direction: "एक छोटा-सा कमरा... पसीने और स्याही की गंध आ रही है।" Identify all sensory adjectives and nouns.
- Step 2: Classify each image by sense: "छोटा-सा कमरा" (visual, spatial), "धुएँ से काली दीवारें" (visual, color), "पसीने और स्याही की गंध" (olfactory), "खड़खड़ाहट" (auditory), "गर्मी" (tactile).
- Step 3: Determine the cumulative effect: The images cluster around confinement (small room), pollution (black walls), bodily strain (sweat), mechanical noise (rattling), and heat — creating a sensory portrait of an oppressive, industrial space.
- Step 4: Connect to foreshadowing: This atmosphere predicts the treatment of students as raw material (ink/sweat = byproducts of production) and the physical/mental toll revealed later (Vatsala's breakdown, Jtuh's rebellion).
- Step 5: Formulate analytical claim: The playwright uses multi-sensory imagery not merely for realism but to encode the center as a dehumanizing machine, establishing the play's central critique before any dialogue occurs.
REASONING: This step-by-step moves from concrete identification to classification to synthesis to thematic linkage, modeling the analytical ladder required for board answers.
ANSWER: The opening stage direction uses visual (cramped room, blackened walls), olfactory (sweat and ink), auditory (rattling), and tactile (heat) imagery to create a suffocating, factory-like atmosphere. This sensory cluster foreshadows the theme of dehumanization by portraying the tuition center as an industrial space where children's bodies and minds are processed like raw material, setting up the play's critique of commodified education.

## WORKED_EXAMPLE_2
PROBLEM: Explain the metaphor "यह कोचिंग नहीं, कत्लगाह है" (This is not coaching, it's a slaughterhouse) spoken by Jtuh on page 75. Identify the tenor, vehicle, and ground, and analyze how it characterizes Jtuh's evolving consciousness.
STEPS:
- Step 1: Identify the metaphor components: Tenor (target) = coaching center/tuition system. Vehicle (source) = slaughterhouse (कत्लगाह). Ground (shared qualities) = systematic killing, violence, innocence of victims, industrial efficiency, blood/gore as byproduct.
- Step 2: Verify it is a metaphor (direct equation, no 'like/as').
- Step 3: Map qualities: Slaughterhouse → innocent animals killed for profit; Coaching → students' spirits/dreams killed for ranks/fees. Blood → sweat/tears/mental health. Butcher → teacher/owner. Conveyor belt → assembly-line teaching.
- Step 4: Situate in character arc: Early Jtuh complies; this metaphor marks his awakening. He names the horror, rejecting euphemisms ("coaching", "guidance"). The violent vehicle reflects his anger and moral clarity.
- Step 5: Link to theme: The metaphor escalates the play's critique from "flawed system" to "structural violence", aligning with the furnace and clay-pot metaphors to form a network of industrial/violent imagery.
- Step 6: Draft PEEL paragraph: Point (metaphor reveals Jtuh's radicalization), Evidence (quote), Explanation (tenor/vehicle/ground + character moment), Link (connects to systemic critique).
REASONING: This models the precise terminology (tenor/vehicle/ground) expected in senior secondary analysis and shows how a single metaphor operates at character and thematic levels simultaneously.
ANSWER: In "यह कोचिंग नहीं, कत्लगाह है", the tenor is the tuition system, the vehicle is a slaughterhouse, and the ground includes systematic destruction of innocence, profit-driven violence, and industrial processing. The metaphor marks Jtuh's shift from compliance to resistance: by naming the center a slaughterhouse, he strips away legitimizing language and exposes the moral anatomy of the enterprise. It functions as a thematic keystone, connecting the furnace (heat/transformation) and clay-pot (molding) metaphors into a coherent imagery of violence against childhood.

## WORKED_EXAMPLE_3
PROBLEM: Compare the metaphorical framing of education in the Principal's "clay pot" metaphor (page 80) and Jtuh's "slaughterhouse" metaphor (page 75). How do they represent opposing ideologies, and which does the play endorse? Support with two pieces of evidence from the text's resolution.
STEPS:
- Step 1: Analyze Principal's metaphor: Tenor = child/student. Vehicle = unbaked clay pot (कच्ची मिट्टी का घड़ा). Ground = malleability, need for external shaping, fragility, potential to become useful vessel. Ideology: paternalistic, authoritarian, child as passive recipient, education as molding by experts.
- Step 2: Analyze Jtuh's metaphor: Tenor = tuition system. Vehicle = slaughterhouse. Ground = violence, death of spirit, profit from destruction, innocence slaughtered. Ideology: critical, resistant, system as perpetrator, child as victim.
- Step 3: Identify opposition: Principal sees education as constructive shaping (potter/clay); Jtuh sees it as destructive processing (butcher/animal). One justifies control; the other indicts it.
- Step 4: Examine resolution evidence: (a) Vatsala's breakdown and recovery through self-directed learning (not molding) supports Jtuh's view. (b) The final protest where students reject tuition fees and demand humane treatment enacts the slaughterhouse metaphor's rebellion.
- Step 5: Evaluate endorsement: The play's structure — giving Jtuh the last word, showing the Principal's rules collapsing, centering student agency — endorses the slaughterhouse critique. The clay pot metaphor is voiced by an authority figure the play satirizes.
- Step 6: Synthesize: The dueling metaphors dramatize the ideological battle; the narrative resolution adjudicates in favor of the metaphor that acknowledges violence and agency.
REASONING: This example requires comparing two metaphors across ideological, structural, and narratological dimensions — a high-order skill combining device analysis with thematic evaluation.
ANSWER: The Principal's "clay pot" metaphor frames education as benevolent shaping (potter/clay ideology), while Jtuh's "slaughterhouse" frames it as systemic violence (butcher/animal ideology). The play endorses Jtuh's metaphor: Evidence 1 — Vatsala heals not through molding but by reclaiming her voice (self-agency). Evidence 2 — The student protest dismantles the Principal's authority, proving the "clay" can resist the "potter". The narrative arc validates the metaphor that names oppression over the one that legitimizes control.

## COMPETENCY_QUESTION_1
QUESTION: The play uses the recurring image of "ink-stained fingers" (स्याही लगे उंगलियां) for students and "clean hands" for administrators. Analyze how this tactile/visual contrast functions as a metonymic metaphor for class division and epistemic injustice. Write a structured response with point, evidence, explanation, and link.
COMPETENCY: Literary analysis with socio-critical lens
STEPS:
- Step 1: Identify the two images and their sensory modes (tactile/visual).
- Step 2: Define metonymy and explain how "ink-stained fingers" stands for student labor, "clean hands" for administrative privilege.
- Step 3: Analyze the metaphorical transfer: ink = knowledge work made visible on bodies; cleanliness = distance from labor, purity of authority.
- Step 4: Connect to epistemic injustice: whose knowledge counts? Students produce the "ink" (answers, ranks) but administrators own the "clean" certification.
- Step 5: Conclude with link to play's resolution where ink-stained fingers write protest letters.
ANSWER: The contrast between "ink-stained fingers" (students) and "clean hands" (administrators) operates as a metonymic metaphor: the physical trace of writing becomes a class marker. Ink stains signify the bodily labor of memorization and examination — the student's skin absorbs the system's demands. Clean hands signify the administrator's exemption from that labor; their authority remains untouched by the sweat and strain of production. This enacts epistemic injustice: the knowledge produced by stained fingers is certified by clean hands, which control the credentials. The play's resolution subverts this when stained fingers write the protest petition — the tools of oppression become instruments of resistance. The metaphor thus maps the material hierarchy of educational capital.
DIFFICULTY: hard

## COMPETENCY_QUESTION_2
QUESTION: Design a 3-panel storyboard for a key scene in the play that uses imagery and metaphor to show a student's internal state. Panel 1: dominant sensory image. Panel 2: a metaphor visualized. Panel 3: a shift in imagery signaling change. Annotate each panel with the device, sense, and thematic function.
COMPETENCY: Creative synthesis and multimodal representation
STEPS:
- Step 1: Choose a scene (e.g., Vatsala's breakdown in the tuition center, page 73).
- Step 2: Panel 1 — Dominant sensory image: Close-up of Vatsala's desk — visual: blurred letters; auditory: ticking clock magnified; tactile: pen pressing into palm. Annotate: "Visual + auditory + tactile overload → sensory imagery of panic."
- Step 3: Panel 2 — Metaphor visualized: Vatsala as a clay pot on a potter's wheel (Principal's metaphor) but the wheel spins too fast, clay flying off — cracks appearing. Annotate: "Metaphor: student = clay pot; vehicle = pottery; ground = fragility under pressure. Thematic function: external control vs. internal collapse."
- Step 4: Panel 3 — Shift in imagery: Vatsala opens window; visual: sky, tree; olfactory: rain on dust; auditory: bird call. Annotate: "Shift from industrial imagery (clock, wheel) to natural imagery (sky, rain) → thematic shift from coercion to autonomy."
- Step 5: Ensure each annotation names device, sense, and function.
ANSWER: Panel 1: Extreme close-up of Vatsala's desk. Blurred text (visual), amplified clock ticks (auditory), pen digging into palm (tactile). Annotation: Multi-sensory imagery of anxiety — the tuition center invades her sensorium. Panel 2: Split frame — left: Principal as potter shaping clay pot (Vatsala); right: pot cracking on speeding wheel. Annotation: Metaphor (student=clay pot) visualized; ground = fragility under systemic speed; critiques molding ideology. Panel 3: Window opens. Sky (visual), petrichor (olfactory), koel call (auditory). Annotation: Imagery shift from mechanical to natural senses signals reclamation of self; foreshadows her recovery through self-directed learning.
DIFFICULTY: medium