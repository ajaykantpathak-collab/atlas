## DEFINITION
Imagery (प्रतिबिंब/चित्रण) is the use of vivid, sensory language that appeals to the five senses (sight, sound, touch, taste, smell) to create mental pictures and evoke emotions. Metaphor (रूपक/उपमा) is a figure of speech that directly equates two unlike things without using "like" or "as" (e.g., "breath is a wave"), transferring qualities from the vehicle (wave) to the tenor (breath) to reveal hidden similarities.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student can independently identify at least three distinct sensory images and two metaphors in the poem "लज्जत ले`fr", explain how each device contributes to the central theme of maternal memory and childhood innocence, and write a structured PEEL-paragraph analysis quoting specific lines (referenced by stanza/description) with interpretive commentary.

## SCOPE_BOUNDARY
This node covers only the identification, classification, and interpretive analysis of imagery (visual, auditory, tactile, kinesthetic) and metaphor (simple, extended, implied) within the prescribed poem "लज्जत ले`fr" by फुज्यक. It does NOT cover other poetic devices (simile, personification, irony, symbolism — handled in node 009), nor does it address prose passages or other chapters.

## WALKTHROUGH
Imagine you are sitting in the exam hall and the question reads: "Analyze how the poet uses imagery and metaphor to convey the mother's absence in 'लज्जत ले`fr'." Your mind goes blank because you only memorized definitions. Instead, start by reading the poem aloud — notice the *sound* of "Fkj&Fkj&Fkj" on the child's tiny hands. That onomatopoeia is your entry point: it is tactile *and* auditory imagery. Next, hunt for comparisons that lack "जैसा" or "सा" — e.g., "फिज़; एकु लहर हक" (breath *is* a wave). Mark each with a coloured pencil: pink for visual, blue for auditory, green for tactile, yellow for metaphor. Now ask: *What does each image make me feel?* The "blue line in the eyes" (नीली रेखा) suggests purity; the "wave of breath" suggests life's rhythm. Finally, connect every device to the core emotion: the child's innocent play *becomes* the mother's living presence. That connection is your answer.

## DIAGNOSTIC_QUESTION_1
Define 'imagery' and 'metaphor' in your own words, giving one example of each from daily life (not from the poem).

## DIAGNOSTIC_ANSWER_1
Imagery: Language that triggers sensory experience, e.g., "The aroma of frying cumin seeds filled the kitchen" (olfactory). Metaphor: Direct equation of two unlike things, e.g., "Time is a thief" (time steals moments). A wrong answer that gives a simile ("Time is *like* a thief") or a vague definition ("Imagery is description") reveals confusion between explicit comparison and direct identification, or between sensory evocation and mere adjectives.

## DIAGNOSTIC_QUESTION_2
In the poem, the line "नसक फूकग वेवी उओय" (garbled) is described in the textbook as depicting the child's "आनंदमयी अवस्था". Which *specific* sense does the phrase "फिज़; एकु लहर हक" (breath became a wave of rhythm) primarily appeal to, and why is it a metaphor rather than a simile?

## DIAGNOSTIC_ANSWER_2
It primarily appeals to the *kinesthetic* sense (movement/rhythm) and secondarily to *tactile* (breath as physical wave). It is a metaphor because it equates "फिज़" (breath) directly with "लहर" (wave) without "जैसा/सा". A student who says "visual" or "auditory" misses the internal bodily rhythm; one who calls it a simile because "wave suggests similarity" fails to spot the absent comparative marker — the hallmark of metaphor.

## DIAGNOSTIC_QUESTION_3
Apply the PEEL structure to analyze the metaphor "ज्वार-भाटा रूप धरि जागत ओहि" (the tide-form awakens there). Write a 4-sentence paragraph: Point, Evidence (quote), Explanation, Link to theme.

## DIAGNOSTIC_ANSWER_3
**Point:** The poet transforms the child's playful swaying into the vast, rhythmic tide. **Evidence:** "ज्वार-भाटा रूप धरि जागत ओहि" (stanza 3). **Explanation:** By making the child *embody* the ocean's tide, the metaphor magnifies a small gesture into a cosmic, eternal rhythm, suggesting the mother's love is as natural and unstoppable as tides. **Link:** Thus, the child's innocent movement becomes the vehicle that resurrects the absent mother's presence. A weak answer lists the quote but skips Explanation or Link, treating the metaphor as decoration rather than meaning-maker.

## DIAGNOSTIC_QUESTION_4
Compare the visual imagery in the first stanza ("नीली रेखा आँखों में", "माथे पर रेखा") with the tactile imagery in the third stanza ("नन्हे हाथों पर फा-फा-फा", "साँस लहर बनी"). How do the two imagery clusters jointly construct the child's *embodied innocence*?

## DIAGNOSTIC_ANSWER_4
The first stanza's visual images (blue line, forehead mark) frame the child as a *seen* object — pure, marked, almost painted. The third stanza's tactile images (hands patting, breath waving) frame the child as a *feeling* agent — active, warm, alive. Together they move the reader from passive observation to visceral participation: we *see* the innocence, then *feel* its pulse. A student who only lists images separately misses the *progression* from external to internal, which is the poem's structural strategy.

## DIAGNOSTIC_QUESTION_5
Evaluate the claim: "The metaphor 'साँस एकु लहर हक' (breath is a rhythm-wave) is more effective than 'ज्वार-भाटा रूप धरि' (tide-form taken) because the former is internal and the latter external." Defend or refute with textual reasoning.

## DIAGNOSTIC_ANSWER_5
Refute. Both metaphors are *internalized*: the tide metaphor describes the child's *body* swaying ("जागत ओहि" — awakens there), making the external ocean an internal rhythm. The breath-wave metaphor *is* the mechanism of that internalization. Their power lies in *layering*: breath → wave → tide → cosmic cycle. Privileging one over the other ignores the poem's cumulative metaphorical architecture. A student who agrees falls for the "internal vs. external" binary and misses the *nesting* of metaphors.

## DIAGNOSTIC_QUESTION_6
Create a new four-line stanza for the poem that introduces a *fresh* metaphor for the mother's memory (e.g., "memory is a lamp") and uses at least two sensory images (one auditory, one olfactory). Write in Hindi (Devanagari or transliteration).

## DIAGNOSTIC_ANSWER_6
Example:
"याद सखी दीपक जली अँधियारी रात में,
घी की महक फैल गई आँगन के पार,
पायल की झनकार बजी माँ के गीत सी,
साँस-साँस में बसी वह ममता की धार।"
A poor answer uses a simile ("याद जैसी दीपक") or only visual imagery, showing inability to transfer the device-creation skill to new content.

## COMMON_MISCONCEPTION
Students treat *every* descriptive phrase as imagery and *every* comparison as metaphor. In this poem, they often label "माथे पर रेखा" (line on forehead) as a metaphor because it "stands for" the child's fate, but it is literal visual imagery — the poet actually sees a line. Conversely, they miss the implied metaphor in "फिज़; एकु लहर हक" because "हक" (became) looks like a verb of change, not equation. The error stems from hunting for *symbolic meaning* instead of analyzing *linguistic structure*: metaphor = A *is* B (no comparative word); imagery = sensory word cluster.

## ON_FAILURE
1. Revisit **c11_hin_ar_cbse_01_008** (Class 11 Imagery/Metaphor basics) and re-do the "device hunt" exercise on a simple poem (e.g., "पुष्प की अभिलाषा"). 2. Use two highlighters: one for sensory words (see/hear/touch/taste/smell), another for "is/equals/becomes" linking two nouns. 3. Write three PEEL paragraphs on that poem, each focusing on *one* device. 4. Return to "लज्जत ले`fr" and repeat the highlight+PEEL drill. 5. Re-attempt Diagnostic Questions 2–4.

## BUILDS_ON
Class 11 skill of distinguishing literal description from figurative comparison (c11_hin_ar_cbse_01_008).

## LEADS_TO
Analysis of irony and symbolism in the same poem (c12_hin_a_cbse_02_009), where metaphors become ironic counters.

## PREREQUISITE_NODE_IDS
c11_hin_ar_cbse_01_008, c11_hin_ar_cbse_08_008, c11_hin_ar_cbse_16_008, c11_hin_v_cbse_01_008, c11_hin_v_cbse_05_008, c12_hin_a_cbse_02_001, c12_hin_a_cbse_02_002, c12_hin_a_cbse_02_003, c12_hin_a_cbse_02_004, c12_hin_a_cbse_02_005, c12_hin_a_cbse_02_006, c12_hin_a_cbse_02_007
## PREREQUISITE_REASONS
c11_hin_ar_cbse_01_008: Foundation in identifying imagery/metaphor in Class 11 Antra Chapter 1.
c11_hin_ar_cbse_08_008: Reinforcement in Class 11 Antra Chapter 8 (mid-course practice).
c11_hin_ar_cbse_16_008: Mastery-level practice in Class 11 Antra final chapter.
c11_hin_v_cbse_01_008: Exposure to imagery/metaphor in Vitan (prose-poetry blend) Chapter 1.
c11_hin_v_cbse_05_008: Advanced practice in Vitan final chapter.
c12_hin_a_cbse_02_001: Context/background of poet फुज्यक essential for biographical metaphors.
c12_hin_a_cbse_02_002: Narrative structure tells us *where* devices cluster (stanza 1 vs 3).
c12_hin_a_cbse_02_003: Setting/atmosphere (child's play space) frames the sensory palette.
c12_hin_a_cbse_02_004: Protagonist (child) is the *tenor* of most metaphors.
c12_hin_a_cbse_02_005: Supporting character (mother) is the *absent vehicle* evoked by devices.
c12_hin_a_cbse_02_006: Primary theme (maternal memory) is the *target* of all device analysis.
c12_hin_a_cbse_02_007: Secondary themes (innocence, time) nuance the metaphorical mapping.

## FORWARD_NODE_IDS
c12_hin_a_cbse_02_009, c12_hin_a_cbse_02_010, c12_hin_a_cbse_02_011, c12_hin_a_cbse_02_012, c12_hin_a_cbse_02_013, c12_hin_a_cbse_02_014, c12_hin_a_cbse_02_015
## FORWARD_REASONS
c12_hin_a_cbse_02_009: Irony/symbolism often *subvert* the metaphors established here (e.g., tide metaphor becomes ironic when mother never returns).
c12_hin_a_cbse_02_010: Key vocabulary ("ज्वार-भाटा", "लहर", "फिज़") locks in metaphorical meaning.
c12_hin_a_cbse_02_011: Grammatical forms (compound verbs "धरि जागत", "हक") encode metaphorical agency.
c12_hin_a_cbse_02_012: Literal/inferential comprehension questions *require* device identification as evidence.
c12_hin_a_cbse_02_013: Critical interpretation builds *on* the device-analysis scaffold constructed here.
c12_hin_a_cbse_02_014: Writing tasks (analytical paragraph) directly apply the PEEL drill practiced here.
c12_hin_a_cbse_02_015: Discussion points (e.g., "Is the child a metaphor for time?") extend the metaphorical thinking.

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
No cross-subject nodes provided in prior class list; all listed nodes are Hindi literature.

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_16_008 -> c12_hin_a_cbse_02_008 -> c12_hin_a_cbse_02_009

## THIS_FORMULA
PEEL Analysis Template for Poetic Devices: **P**oint (name device + location) → **E**vidence (quote line/phrase) → **E**xplain (how device works: sensory channel / tenor-vehicle mapping) → **L**ink (connect to theme/emotion).

## FORMULA_VARIABLES
N/A - conceptual

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
linguistic

## CROSS_SUBJECT
N/A | The poet फुज्यक (1898–1961) wrote during the Chhayavaad-to-Pragativad transition; understanding the historical shift from romantic imagery to social metaphor illuminates why his metaphors blend personal memory with collective rhythm.
 N/A | The poem's tactile/kinesthetic imagery (hands patting, breath waving) mirrors Piaget's sensorimotor stage — the child knows the world through bodily action, which the poet metaphorically elevates to cosmic tide.
## PREREQ_CONCEPT
Distinguishing *literal sensory description* (imagery) from *figurative equation* (metaphor) using linguistic markers (comparative words absent/present).

## PREREQ_BEFORE
Student must be able to underline all sensory adjectives/verbs in a stanza and circle every "A है B" construction without "जैसा/सा".

## PREREQ_STUCK
Review "tenor-vehicle" terminology and the "comparative marker test" from c11_hin_ar_cbse_01_008.

## WORKED_EXAMPLE_1
PROBLEM: Analyze the visual and tactile imagery in the opening description of the child (stanza 1) and explain how they prepare the reader for the metaphor in stanza 3.
STEPS:
- Step 1: Isolate the first stanza lines describing the child — "नीली रेखा आँखों में", "माथे पर रेखा", "नन्हे हाथों पर फा-फा-फा" (note: last phrase is actually stanza 3, but we treat the *cluster* of child-images across stanzas 1 & 3 as the poet's portrait).
- Step 2: Classify each phrase by sense: "नीली रेखा" = visual (color + shape); "माथे पर रेखा" = visual + tactile (location on skin); "फा-फा-फा" = auditory (sound of patting) + tactile (hand movement).
- Step 3: Note the progression — static visual marks (lines) → dynamic tactile-sound action (patting). The child moves from *being seen* to *doing*.
- Step 4: Connect to stanza 3 metaphor "ज्वार-भाटा रूप धरि जागत ओहि" — the patting motion *becomes* the tide's rhythm. The earlier tactile-auditory "फा-फा-फा" is the *raw material* the metaphor transforms.
- Step 5: Interpret thematic function: the innocent play (patting) is not just cute; it is the *vehicle* that carries the mother's absent presence back as tidal rhythm.
REASONING: The poem builds metaphor *from* accumulated imagery. By cataloguing senses first, we see the metaphor not as decoration but as *synthesis* of the child's embodied actions.
ANSWER: The opening visual imagery ("blue line", "forehead mark") frames the child as a delicate, marked canvas. The tactile-auditory "फा-फा-फा" on tiny hands shifts mode to active movement. This movement is exactly what the stanza-3 metaphor "ज्वार-भाटा रूप धरि" (assumes tide-form) magnifies: the child's patting *is* the tide. Thus, imagery provides the *data*; metaphor provides the *meaning* — maternal memory lives in the child's rhythmic body.

## WORKED_EXAMPLE_2
PROBLEM: The line "साँस एकु लहर हक" (breath became a rhythm-wave) appears in stanza 3. Identify the tenor and vehicle, list the qualities transferred, and explain why the poet chooses "लहर" (wave) over "लहरें" (waves, plural).
STEPS:
- Step 1: Identify the grammatical structure: "साँस" (subject) + "एकु" (one/whole) + "लहर" (wave, singular) + "हक" (became). No "जैसा/सा" → metaphor.
- Step 2: Tenor = "साँस" (breath/life-force); Vehicle = "लहर" (wave/rhythm).
- Step 3: Qualities transferred: wave = rhythmic, cyclical, powerful, continuous, natural, vast. These map onto breath: involuntary rhythm, life-sustaining, connects body to cosmos.
- Step 4: Singular "लहर" (not plural) suggests *one unified rhythm* — the child's single breath *is* the entire wave, not a series. It fuses the micro (one breath) with macro (ocean tide), echoing "ज्वार-भाटा" (tide) two lines later.
- Step 5: Thematic payoff: the mother's memory is not a static picture but a *living rhythm* that rises/falls like breath/tide. Singular wave = each moment of remembrance is complete.
REASONING: Metaphor analysis requires grammatical precision (singular vs plural), quality-mapping, and thematic integration — not just "it means breath is like a wave".
ANSWER: Tenor: साँस (breath). Vehicle: लहर (wave, singular). Transferred qualities: rhythm, cyclicality, vitality, natural force, unity. Singular "लहर" compresses the infinite tide into one breath, making the child's tiny respiration the vessel of the mother's eternal return. The metaphor turns biology (breathing) into cosmology (tide).

## WORKED_EXAMPLE_3
PROBLEM: Write a board-style 3-mark answer: "How does the poet use the metaphor of 'टाइड' (tide) to convey the persistence of maternal memory? Support with two textual details."
STEPS:
- Step 1: Deconstruct the question — needs (a) identification of tide metaphor, (b) explanation of "persistence", (c) two textual details.
- Step 2: Locate the metaphor: "ज्वार-भाटा रूप धरि जागत ओहि" (stanza 3) and its precursor "साँस एकु लहर हक".
- Step 3: Define "persistence" in this context: tide is *inevitable*, *cyclical*, *uncontrollable by human will* — like memory that returns regardless of time/distance.
- Step 4: Select Detail 1: "जागत ओहि" (awakens there) — present participle shows *ongoing* action, not past event. Memory *keeps* waking in the child's body.
- Step 5: Select Detail 2: "वक़दर बदल दे ठग" (change the weather/time) — the speaker *commands* the tide/breath to alter reality, showing memory's active power to resurrect the mother ("ईहु" = mother).
- Step 6: Synthesize in PEEL: Point → tide metaphor = persistence. Evidence → "जागत ओहि" + "वक़दर बदल दे ठग". Explanation → cyclical waking + imperative power. Link → thus memory is not passive nostalgia but living force.
REASONING: Board marking scheme awards 1 mark for device identification, 1 for textual evidence, 1 for thematic linkage. The worked example models the exact 3-sentence density required.
ANSWER: The poet equates the child's swaying to "ज्वार-भाटा" (tide), making maternal memory an *inevitable, cyclical force* like the sea. Textual details: (1) "जागत ओहि" (awakens there) — present tense shows memory *repeatedly* rises in the child's body; (2) "वक़दर बदल दे ठग" (change the weather/time) — the speaker commands the tide-breath to alter reality, proving memory's active, persistent power to resurrect the mother. Thus, the tide metaphor transforms nostalgia into a living, unstoppable rhythm.

## COMPETENCY_QUESTION_1
QUESTION: A student writes: "The poem uses the metaphor 'साँस एकु लहर हक' to show that the child's breathing is regular like waves." Identify the *two* analytical flaws in this statement and rewrite it as a correct PEEL Point sentence.
COMPETENCY: Critical analysis of peer response / metalanguage precision
STEPS:
- Step 1: Spot flaw 1 — "regular like waves" uses "like", turning metaphor into simile.
- Step 2: Spot flaw 2 — "show that breathing is regular" reduces metaphor to *description of breathing pattern* instead of *meaning-transfer* (breath *becomes* cosmic rhythm).
- Step 3: Recall correct PEEL Point structure: "The poet metaphorically equates the child's breath with a singular wave to..."
- Step 4: Draft corrected Point: "The poet metaphorically equates the child's breath with a singular wave to elevate a biological rhythm into a cosmic tide that resurrects the absent mother."
ANSWER: Flaws: (1) Uses "like" → mislabels metaphor as simile. (2) Focuses on *regularity* (literal trait) instead of *ontological equation* (breath = wave). Corrected Point: "The poet metaphorically equates the child's breath with a singular wave to elevate a biological rhythm into a cosmic tide that resurrects the absent mother."
DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: The poem's final stanza shifts from metaphor to direct address: "वक़दर बदल दे ठग... फिज़; एकु लहर हक... नय जीवन के लोज पर मृजक". Explain how the *imperative mood* ("बदल दे") interacts with the established breath-wave-tide metaphor to transform the poem from *elegy* to *incantation*. Write a 150-word analytical paragraph.
COMPETENCY: Synthetic interpretation (metaphor + grammar + genre shift)
STEPS:
- Step 1: Establish baseline — stanzas 1-3 build breath→wave→tide metaphor cluster, creating a *descriptive* elegy (mourning mother's absence).
- Step 2: Identify shift — stanza 4 opens with imperative "वक़दर बदल दे ठग" (change the weather/time), addressing the tide-breath as an *agent*.
- Step 3: Analyze interaction — the metaphor *provided* the agency: only if breath *is* wave/tide can it *command* weather. The vehicle (tide) grants power to the tenor (breath/memory).
- Step 4: Define genre shift — elegy = lament for dead; incantation = ritual speech to *invoke* change. The imperative turns memory into spell.
- Step 5: Synthesize — the metaphor is not ornamental; it *enables* the magical speech act. The child's patting (tide) becomes the poet's wand.
- Step 6: Write paragraph integrating steps 1-5 with textual anchors.
ANSWER: The poem begins as elegy, constructing the breath-wave-tide metaphor to *describe* how the child's body recalls the mother. But the final stanza's imperative "वक़दर बदल दे ठग" (change the weather/time) hijacks that metaphor: because breath *has become* wave/tide ("फिज़; एकु लहर हक"), it now possesses the tide's primordial power to alter reality. The metaphor thus shifts from *explanatory* (this is how memory works) to *performative* (memory *does* work — it commands time). The child's patting ("फा-फा-फा"), once innocent play, is revealed as the somatic engine of an incantation that summons the mother ("ईहु") onto "नय जीवन के लोज" (waves of new life). The poem does not merely mourn; it *casts* the metaphor as spell.
DIFFICULTY: hard