## DEFINITION
Imagery (बिंब/प्रतिबिंब) is the use of vivid, sensory language that appeals to the five senses (sight, sound, smell, touch, taste) to create mental pictures and evoke emotional responses. Metaphor (रूपक/उपमा) is a figure of speech that directly equates two unlike things by stating one *is* the other, transferring qualities from the source domain to the target domain without using comparative words like "like" or "as."

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student must independently identify at least three distinct images and two metaphors in the chapter, explain the sensory channel each image activates, and articulate how each metaphor structures the reader's understanding of British imperialism by mapping specific source-domain attributes onto the target domain of colonial rule.

## SCOPE_BOUNDARY
This node covers identification, classification, and functional analysis of imagery (visual, auditory, tactile, olfactory, gustatory) and metaphor (simple, extended, implied) specifically within the satirical monologue addressing Lord Curzon in Chapter 4. It does NOT cover simile, personification, symbolism, or irony (addressed in node 009), nor does it require analysis of rhyme scheme or meter (prose text).

## WALKTHROUGH
Imagine you are watching a political cartoon where a giant bulldozer labeled "British Law" crushes a tiny hut labeled "Indian Rights" — you instantly *see* the injustice without reading a word. That is the power of imagery: it bypasses abstract argument and strikes the senses directly. Now open the text to the passage where the narrator describes the "huge bulldozer meant to crush rebellion, its roar cutting through the air with great speed" — ask yourself: which sense does "roar" activate? Which sense does "cutting through the air" activate? Next, locate the metaphor where the narrator says "your and your queen's laundry used to be washed in the tears of great kings and their mothers' milk" — notice how "laundry" (domestic chore) becomes the vehicle for "exploitation" (tense political reality). The key insight: imagery makes the abstract *felt*; metaphor makes the unfamiliar *understood* by borrowing the logic of the familiar.

## DIAGNOSTIC_QUESTION_1
Define "imagery" and "metaphor" in your own words, and give one example of each from everyday language (not from the textbook).

## DIAGNOSTIC_ANSWER_1
Imagery: language that creates sensory experiences (e.g., "The sizzling sound of pakoras hitting hot oil made my stomach growl" — auditory + olfactory + gustatory). Metaphor: direct equation of two unlike things (e.g., "Time is a thief" — time ≠ thief, but steals moments). A wrong answer that defines imagery as "description" or metaphor as "comparison using like/as" reveals confusion with *descriptive writing* or *simile* respectively — the student has not grasped the sensory-specificity of imagery or the *identity-claim* nature of metaphor.

## DIAGNOSTIC_QUESTION_2
In the passage describing the "huge bulldozer" (vnuk DyoZQ), the narrator writes: "its roar cutting through the air with great speed." Identify the *two* distinct sensory images embedded here and explain why the author combines them instead of using just one.

## DIAGNOSTIC_ANSWER_2
Auditory image: "roar" (sound of machinery/violence). Tactile/kinesthetic image: "cutting through the air" (physical force, resistance, speed). The combination creates a *synesthetic* effect — the sound becomes tangible, the violence becomes audible — forcing the reader to experience the bulldozer as a total sensory assault, not just a visual object. A wrong answer that lists only "sound" or only "movement" shows the student misses how imagery clusters work synergistically to amplify thematic impact (here: the overwhelming, multi-sensory brutality of state power).

## DIAGNOSTIC_QUESTION_3
The narrator states: "Your and your queen's laundry used to be washed in the tears of great kings and their mothers' milk." Identify the *tenor* (target), *vehicle* (source), and *ground* (shared attributes) of this metaphor. Then rewrite the metaphor as a simile and explain what is lost in the translation.

## DIAGNOSTIC_ANSWER_3
Tenor: British exploitation of India's resources and dignity. Vehicle: washing laundry in tears/milk. Ground: both involve (a) intimate violation, (b) using something sacred/life-giving for mundane/dirty purposes, (c) repetitive, systematic extraction. Simile version: "British rule *was like* washing laundry in tears and milk." Loss: the *identity claim* ("is") forces the reader to inhabit the metaphor's logic — exploitation *becomes* a domestic chore, making the horror banal and routine. The simile creates distance; the metaphor creates complicity. A wrong answer that swaps tenor/vehicle or identifies ground as merely "sadness" shows inability to deconstruct metaphor's structural mapping.

## DIAGNOSTIC_QUESTION_4
Compare the *visual imagery* of "the tears of great kings" with the *tactile imagery* of "mothers' milk" in the same metaphor. How do these two images together construct a gendered critique of colonialism that a single image could not achieve?

## DIAGNOSTIC_ANSWER_4
"Tears of great kings" — visual, public, masculine, political sovereignty violated. "Mothers' milk" — tactile, intimate, feminine, biological nurturance violated. Together they span the *public-political* and *private-domestic* spheres, the *masculine* and *feminine* bodies of the nation, showing colonialism as total violation — not just of territory but of life-source itself. A single image would reduce the critique to either political *or* cultural harm. A wrong answer that treats both as merely "sad images" misses the strategic gendered architecture of the metaphor — a senior-secondary error where students read for emotion but not for *structural patterning*.

## DIAGNOSTIC_QUESTION_5
Evaluate the claim: "The extended metaphor of the 'two eyes of the phantom' (f'ko'kaHkq osQ nks xk;sa) is more effective than the 'bulldozer' imagery because it operates at the conceptual level rather than the sensory level." Defend or refute with textual evidence.

## DIAGNOSTIC_ANSWER_5
Refute. The "two eyes" metaphor (conceptual: surveillance, duality, inescapable gaze) and "bulldozer" imagery (sensory: sound, force, speed) operate at *different registers* for *different rhetorical purposes* — the former establishes the *omnipresence* of colonial ideology, the latter enacts its *violent implementation*. Effectiveness is not hierarchical; they are complementary. The text needs both: the metaphor to explain *why* resistance feels futile (you are always watched), the imagery to make *how* suppression feels (you are crushed). A wrong answer that picks one as "better" reveals a reductive "device-spotting" mindset rather than functional analysis — the student treats devices as ornaments, not as rhetorical strategies.

## DIAGNOSTIC_QUESTION_6
Write a 4-line original metaphor-cluster (two connected metaphors) that captures the experience of a student facing board exams, using *only* imagery from a kitchen (cooking, utensils, ingredients, heat). Do not use "exam," "study," "marks," or "result."

## DIAGNOSTIC_ANSWER_6
Example: "The syllabus is a pressure cooker whistle / screaming through three a.m. steam. / My memory, a dough over-kneaded / tears itself on the rolling pin." Criteria for good answer: (1) two distinct metaphors linked by a shared kitchen logic, (2) each metaphor maps source→target with clear ground (pressure/time, fragility/exhaustion), (3) imagery activates auditory (whistle), tactile (steam, dough, rolling pin), thermal (heat). A poor answer that uses kitchen words but no metaphorical mapping (e.g., "I cook food late at night") shows the student cannot *generate* metaphorical thought — only recognize it.

## COMMON_MISCONCEPTION
Students treat imagery and metaphor as *decorative labels* to be hunted and named ("Here is a visual image," "Here is a metaphor") rather than as *functional components* of the text's argument. In this chapter, the specific error is reading the "laundry washed in tears/milk" metaphor as merely "showing British cruelty" — missing how the *domestic vehicle* (laundry, a woman's chore) implicitly genders the colonizer as a housewife managing a household, thereby *feminizing and trivializing* imperial power while simultaneously exposing its intimate violation. Students miss this because they stop at *tenor identification* and do not analyze *vehicle semantics*.

## ON_FAILURE
Step 1: Return to the "laundry" metaphor. Ask the student: "List every word in the vehicle domain (laundry, wash, tears, milk). What *kind* of work is laundry? Who traditionally does it? What does that imply about how the narrator frames British rule?" Step 2: Have the student draw a two-column map: Vehicle Attributes → Transferred to Tenor. Step 3: Ask: "If the metaphor were 'British rule is a butcher cutting meat,' how would the critique change?" This forces attention to *vehicle choice* as rhetorical strategy, not accident.

## BUILDS_ON
Close reading of narrative voice and satirical tone established in nodes 002 (Plot) and 003 (Setting/Atmosphere) — the student must already hear the narrator's ironic persona before analyzing how imagery/metaphor serve that persona.

## LEADS_TO
Node 009 (Irony and Symbolism) — the metaphorical structure analyzed here (domestic vehicle for political tenor) is the foundation for recognizing the *ironic gap* between Curzon's self-presentation and the narrator's metaphorical reframing, and for identifying *symbols* (e.g., the bulldozer as symbol of industrialized violence) that emerge from sustained imagery clusters.

## PREREQUISITE_NODE_IDS
c11_hin_ar_cbse_04_002, c11_hin_ar_cbse_04_003, c11_hin_ar_cbse_04_006, c11_hin_ar_cbse_04_001, c11_hin_ar_cbse_04_007

## PREREQUISITE_REASONS
c11_hin_ar_cbse_04_002: Understanding the plot structure (satirical monologue addressing Curzon) is essential to contextualize *why* specific images/metaphors appear at specific moments in the argument.
c11_hin_ar_cbse_04_003: The atmosphere of oppression and resistance established in the setting analysis provides the thematic framework that the imagery/metaphors concretize.
c11_hin_ar_cbse_04_006: The primary theme (colonial exploitation and Indian resilience) is the *tenor* that the chapter's metaphors collectively map — without thematic clarity, metaphor analysis becomes device-spotting.
c11_hin_ar_cbse_04_001: "Before You Read: की समझ आवश्यक है, क्योंकि यह नोड (Imagery (बिंब/प्रतिबिंब) is the use of vivid, sensory language that appeals to the five se...) इसी आधार पर आगे बढ़ता है।  
c11_hin_ar_cbse_04_007: Imagery/metaphor analysis requires thematic awareness to interpret symbolic patterns.  

## FORWARD_NODE_IDS
c11_hin_ar_cbse_04_009, c11_hin_ar_cbse_04_013, c11_hin_ar_cbse_04_014, c11_hin_ar_cbse_04_010, c11_hin_ar_cbse_04_011, c11_hin_ar_cbse_04_015, c12_hin_a_cbse_04_008, c12_hin_a_cbse_05_008, c12_hin_a_cbse_16_008, c12_hin_ar_cbse_04_003

## FORWARD_REASONS
c11_hin_ar_cbse_04_009: Irony and symbolism analysis requires the metaphorical mappings established here (e.g., the "laundry" metaphor creates the ironic frame that node 009 will analyze).
c11_hin_ar_cbse_04_013: Critical thinking/interpretation questions in board exams demand evidence-based analysis of how imagery/metaphor construct meaning — this node provides the analytical toolkit.
c11_hin_ar_cbse_04_014: Writing skills (analytical paragraphs, essays) require the PEEL structure modeled in the worked examples here — point, evidence (quoted image/metaphor), explanation (mapping), link (theme).
c11_hin_ar_cbse_04_010: Imagery/Metaphor analysis trains the "contextual lens" needed to see words as symbols (e.g., जूते as metaphor).  
c11_hin_ar_cbse_04_011: Imagery and metaphor analysis prepares students to see language as a stylistic tool.  
c11_hin_ar_cbse_04_015: Equips students to name and discuss imagery/metaphor as textual evidence during dialogue.  
c12_hin_a_cbse_04_008: Introduction to extended metaphor in "Ram Ki Shakti Puja" — prepares for "vkèkk" conceit in "cukjl".  
c12_hin_a_cbse_05_008: Introduces thematic linking of devices in Class 11 poems.  
c12_hin_a_cbse_16_008: Extends to sustained metaphors across longer passages.  
c12_hin_ar_cbse_04_003: Builds on Class 11 skill of identifying sensory imagery (c11_hin_ar_cbse_04_008) and distinguishing literal from figurative meaning (c11_hin_ar_cbse_04_013).  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
none

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_04_002 -> c11_hin_ar_cbse_04_008 -> c11_hin_ar_cbse_04_009

## THIS_FORMULA
METAPHOR ANALYSIS FRAMEWORK: (1) Identify Vehicle (source image) and Tenor (target concept). (2) List 3-4 key attributes of the Vehicle. (3) Map each attribute to the Tenor (Ground). (4) Evaluate: What does this mapping *reveal* and what does it *conceal* about the Tenor? (5) Connect to thematic argument of the text.

## FORMULA_VARIABLES
Vehicle = Source domain image (e.g., laundry, bulldozer, eyes); Tenor = Target domain concept (e.g., colonial exploitation, state violence, surveillance); Ground = Shared attributes enabling the mapping (e.g., repetition, intimacy, violation); Thematic Argument = Central claim of the text (e.g., colonialism as intimate violation disguised as administration).

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
analytical

## CROSS_SUBJECT
c11_history_colonialism | The "laundry in tears/milk" metaphor maps directly onto the economic history concept of "drain of wealth" (Dadabhai Naoroji) — the domestic chore of laundry becomes a metaphor for systematic resource extraction, making abstract economic exploitation sensorially tangible.
c11_political_science_imperialism | The "two eyes of the phantom" metaphor operationalizes Foucault's concept of the *panoptic gaze* — colonial power as internalized surveillance. The literary device makes the political theory accessible through the concrete image of an inescapable watcher.

## PREREQ_CONCEPT
Satirical monologue structure: a single speaker adopting a persona to address an absent power figure, using irony to invert power dynamics.

## PREREQ_BEFORE
The student must be able to identify the narrator's voice as distinct from the author's voice, and recognize that the address to "Lord Curzon" is a rhetorical device, not a historical letter.

## PREREQ_STUCK
Review the "Before You Read" context (node 001) and the "Plot and Narrative Structure" analysis (node 002) to re-establish the speaker, audience, and satirical frame.

## WORKED_EXAMPLE_1
PROBLEM: Analyze the visual and auditory imagery in the passage describing the narrator's return to India: "I saw the same tax collectors... your police still baton-charge... the same old story." Explain how the imagery cluster constructs the theme of *continuity of oppression* despite regime change.

STEPS:
- Step 1: Identify the sensory channel of each image. "Tax collectors" → visual (uniforms, ledgers, bodies); "police baton-charge" → visual (batons, bodies falling) + auditory (thuds, cries) + tactile (impact, pain).
- Step 2: Note the repetition marker "same" (वही) attached to each image — this is not incidental description but *patterned imagery* signaling structural repetition.
- Step 3: Map the imagery to the tenor "continuity of oppression." The visual sameness of uniforms/ledgers/batons across time = the institutional machinery of colonialism persists regardless of individual officers or policies.
- Step 4: Analyze the *absence* of expected change imagery. No images of new buildings, reformed laws, or relieved faces — the imagery *denies* the colonial claim of "progress" by showing only recurrence.
- Step 5: Connect to the chapter's central argument: the narrator's lived experience (imagery of his own body — "my back bent lower," "my intestines shrank") becomes the *measuring instrument* for this continuity. The personal sensory record validates the political claim.

REASONING: This worked example models the move from *device identification* to *functional analysis* — showing how imagery clusters (not isolated images) serve the text's argument. The 5-step framework (identify channel → detect patterning → map to tenor → analyze absences → connect to embodied experience) is transferable to any prose text.

ANSWER: The passage uses a cluster of visual-auditory-tactile images ("tax collectors," "baton-charge," "bent back," "shrunken intestines") bound by the repetition marker "same" to construct oppression as a *sensory constant* across time. The imagery denies the colonial narrative of "development" by presenting only recurrence. The narrator's body serves as the archive of this continuity — his bent back *is* the evidence.

## WORKED_EXAMPLE_2
PROBLEM: The narrator describes the British educational policy: "Your education policy became a whirlpool in this country... it swallowed the country's wealth." Deconstruct this metaphor using the 5-step framework. Then explain why "whirlpool" (भंवर) is a more potent vehicle than "pit" (गड्ढा) or "trap" (जाल) would be.

STEPS:
- Step 1: Vehicle = "whirlpool" (भंवर); Tenor = British education policy in India.
- Step 2: Vehicle attributes: (a) circular, self-perpetuating motion, (b) pulls everything toward center by force of its own rotation, (c) destroys what enters by drowning/churning, (d) natural phenomenon disguised as geography (looks like water, acts like death).
- Step 3: Attribute mapping: (a) Education policy creates self-reproducing demand for English degrees → circular motion. (b) Pulls Indian wealth (fees, salaries, books) toward British center → centripetal force. (c) Destroys indigenous knowledge systems (Sanskrit, Persian, vernaculars) → drowning/churning. (d) Presented as "modernization" (natural/good) but functions as extraction → deceptive appearance.
- Step 4: Evaluate vehicle choice. "Pit" implies static hole — passive, avoidable. "Trap" implies intentional design by a trapper — too simple, too human. "Whirlpool" captures *systemic, self-sustaining, deceptively natural* violence — the policy *is* the motion, not a tool used by an agent.
- Step 5: Connect to theme: The metaphor reframes "education" (normally positive) as a *hydrodynamic force of destruction* — aligning with the chapter's broader strategy of inverting colonial virtues into Indian catastrophes.

REASONING: This example demonstrates the *comparative vehicle analysis* (Step 4) that distinguishes senior-secondary analysis from middle-school device-spotting. The student must articulate *why this vehicle* — not just what it means.

ANSWER: The "whirlpool" metaphor maps the systemic, self-perpetuating, deceptively natural destruction of indigenous knowledge and extraction of wealth onto the colonial education policy. "Whirlpool" is superior to "pit" or "trap" because it encodes *motion, inevitability, and disguise* — the policy was not a static hole or a deliberate snare but a dynamic force that presented itself as the natural flow of progress while actively drowning alternatives.

## WORKED_EXAMPLE_3
PROBLEM: The text contains an extended metaphor of the "phantom" (फाँक) with "two eyes" (नक्सी) that "never blink." Trace this metaphor across three separate passages in the chapter. For each occurrence, identify: (a) the specific vehicle attributes activated, (b) the tenor aspect illuminated, and (c) how the metaphor *evolves* across the three passages to deepen the critique.

STEPS:
- Step 1: Locate Passage 1 (early chapter): "One eye watches the peasant's empty bowl, the other watches the merchant's swollen safe." Vehicle attributes: dual gaze, simultaneous surveillance of poverty and wealth. Tenor aspect: colonial state as *extractor* (takes from poor) and *protector* (guards rich) — the two eyes are functionally linked.
- Step 2: Locate Passage 2 (mid chapter): "Those two eyes saw the 1857 rebellion and blinked not; they saw the famine of 1899 and blinked not." Vehicle attributes: unblinking = no empathy, no hesitation, historical continuity. Tenor aspect: colonial violence as *structural*, not episodic — the gaze persists across events.
- Step 3: Locate Passage 3 (climax): "And now those eyes watch me writing this, and I watch them back." Vehicle attributes: reciprocal gaze, shattered passivity. Tenor aspect: the *subject* (Indian narrator) reclaims agency by returning the look — the metaphor reverses.
- Step 4: Synthesize evolution: Passive object of gaze → historical witness of atrocity → active subject returning gaze. The metaphor *structures the narrative arc* from subjugation to resistance.
- Step 5: Connect to board-exam answer structure: A high-scoring response would trace this evolution in 4-5 sentences, quoting key phrases (not full lines), and conclude: "The phantom's eyes metamorphose from instrument of oppression to site of resistance, embodying the chapter's central movement from silence to speech."

REASONING: This worked example models *extended metaphor tracking* — a skill explicitly tested in CBSE competency questions (e.g., "How does the metaphor of X develop across the text?"). The 5-step method (locate → analyze each occurrence → synthesize evolution → connect to narrative arc → format for exam) prepares students for the 5-mark long-answer pattern.

ANSWER: The "two eyes of the phantom" metaphor evolves across three stages: (1) Dual extraction (watching poverty and wealth simultaneously) — establishes colonial political economy. (2) Historical unblinking witness (1857, 1899 famine) — establishes structural violence. (3) Reciprocal gaze (narrator watches back) — establishes resistance. The metaphor thus carries the chapter's entire argumentative trajectory from diagnosis to defiance.

## COMPETENCY_QUESTION_1
QUESTION: The narrator describes the British legal system: "The law's arms are very long, but its fingers only pick the pockets of the poor." Identify the metaphor (vehicle, tenor, ground). Then explain how the *personification* of "law" as a body with "arms" and "fingers" interacts with the *metaphor* of "picking pockets" to produce a critique that neither device could achieve alone.

COMPETENCY: Literary device interaction analysis — explaining how personification and metaphor combine to create a compound rhetorical effect.

STEPS:
- Step 1: Identify the personification: Law = human body (arms, fingers).
- Step 2: Identify the metaphor: Law's action = pickpocketing (vehicle) targeting the poor (tenor).
- Step 3: Analyze interaction: Personification makes the law *agentive* (it has a body, it acts). Metaphor makes the action *criminal* (pickpocketing = theft, not justice). Together: The law is not a neutral system but a *criminal body* — the very institution meant to prevent theft *performs* theft.
- Step 4: Evaluate combined effect: The critique is not "law is unfair" (abstract) but "law is a thief in uniform" (concrete, visceral, ironic). The personification provides the *actor*; the metaphor provides the *crime*.

ANSWER: Vehicle: pickpocketing. Tenor: British legal system's operation in India. Ground: selective extraction, stealth, criminality, targeting the vulnerable. The personification ("arms," "fingers") gives the abstract law a physical, intentional body; the metaphor ("pick pockets") assigns that body a criminal act. Their interaction produces the devastating irony: the law *embodies* the crime it claims to punish. This compound device transforms a policy critique into a moral indictment.

DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: In the final section, the narrator addresses the Indian reader: "This country's educated sons... have become clerks in the offices of your oppression." Earlier, he used the "whirlpool" metaphor for education policy. Now he uses "clerks" (a literal description) as an *implied metaphor* for the *outcome* of that whirlpool. Construct an analytical paragraph (PEEL structure) arguing that the shift from explicit metaphor (whirlpool) to implied metaphor (clerks) mirrors the shift from *colonial design* to *internalized outcome*.

COMPETENCY: Advanced metaphor analysis — tracing how metaphorical mode (explicit vs. implied) maps onto historical causality (policy → subject formation).

STEPS:
- Step 1: Point — The shift from "whirlpool" (explicit metaphor) to "clerks" (implied metaphor) enacts the historical movement from external imposition to internalized complicity.
- Step 2: Evidence — "Whirlpool" (explicit: "education policy *became* a whirlpool") names the colonial mechanism. "Clerks" (implied: educated sons *are* clerks) names the Indian product — the metaphor is implied because "clerks" is literally true but *metaphorically* signifies "colonized minds."
- Step 3: Explanation — Explicit metaphor = colonial policy *as* destructive force (visible, attributable to British). Implied metaphor = Indian agency *as* colonial reproduction (invisible, attributable to Indians). The shift in metaphorical mode mirrors the shift in *locus of responsibility*.
- Step 4: Link — This mirrors the chapter's final challenge: "What will you do?" — the implied metaphor traps the reader in the very complicity it describes, demanding self-recognition.
- Step 5: Concluding synthesis — The text's metaphorical architecture moves the reader from *analyzing the oppressor* (whirlpool) to *interrogating the self* (clerk).

ANSWER: The paragraph would open with the Point above, quote "whirlpool" and "clerks" as Evidence, explain the Explicit→Implied shift as mapping onto External→Internal causality, link to the final rhetorical challenge, and conclude that the metaphorical form *performs* the political argument. A high-scoring answer demonstrates that metaphor is not ornamental but *architectural* to the text's ethical demand.

DIFFICULTY: hard