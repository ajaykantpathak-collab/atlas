## DEFINITION
Irony (व्यंग्य/विडंबना) is a literary device where the intended meaning of words or events is opposite to their literal or expected meaning, creating a contrast between appearance and reality. Symbolism (प्रतीकवाद) is the use of concrete objects, images, or actions to represent abstract ideas, emotions, or concepts beyond their literal sense. In Varjik's poems "नहीं वोस्यक" and "मैंने देखा, एक चाँद", irony exposes the gap between societal labels and true worth, while symbols like the flower, moon, and breeze embody labor, freedom, and fragility.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student must independently identify at least two instances of irony and two symbols in the prescribed poems, explain the gap between literal and intended meaning for irony, and articulate the abstract idea each symbol represents, using textual evidence in structured PEEL paragraphs.

## SCOPE_BOUNDARY
This node covers irony and symbolism exclusively in the two poems of Chapter 3 (Varjik's "नहीं वोस्यक" and "मैंने देखा, एक चाँद") as per NCERT Class 12 Hindi Antra. It does not cover other literary devices (e.g., metaphor, imagery) already addressed in node c12_hin_a_cbse_03_008, nor does it analyze poems from other chapters.

## WALKTHROUGH
Imagine you see a sign saying "Silence Please" in a library where everyone is shouting — that jarring mismatch is irony in real life. Now, open the poem "नहीं वोस्यक": the title declares what the flower is *not* (a night-blooming flower), yet the entire poem celebrates what it *is* — a flower born of labor, blooming in daylight. That contradiction is the entry point. First, read both poems aloud to hear the tone. Second, underline phrases where the poet denies an expectation (irony) or uses a concrete image to carry a deeper meaning (symbolism). Third, ask: "What is the poet *really* saying about society, labor, or freedom?" The key insight: Varjik uses irony to dismantle stereotypes and symbols to elevate ordinary things into emblems of human dignity.

## DIAGNOSTIC_QUESTION_1
Define irony and symbolism in your own words, giving one example from daily life for each (not from the poems).

## DIAGNOSTIC_ANSWER_1
Irony: A situation where the outcome is contrary to what was expected (e.g., a fire station burning down). Symbolism: Using an object to represent a deeper idea (e.g., a dove representing peace). A wrong answer that defines irony as "sarcasm" or "lying" reveals confusion between verbal irony and situational irony; a wrong answer that equates symbolism with "metaphor" shows inability to distinguish a sustained representative object from a direct comparison.

## DIAGNOSTIC_QUESTION_2
In "नहीं वोस्यक", the poet repeatedly says "यह फूल नहीं वोस्यक" (this flower is not a night-flower). Explain why this repetition creates irony rather than mere negation.

## DIAGNOSTIC_ANSWER_2
The repetition sets up an expectation of a night-flower (associated with darkness, passivity, fleeting beauty) only to replace it with a flower of "श्रम" (labor), "वसंत" (spring), and "उन्मुक्तता" (freedom). The irony lies in the contrast between the stereotypical romantic image of a night-flower and the robust, labor-born reality the poet champions. A student who says "it just emphasizes it's not a night flower" misses the thematic contrast and treats irony as simple denial.

## DIAGNOSTIC_QUESTION_3
Identify one symbol in "मैंने देखा, एक चाँद" and explain how the poet develops its symbolic meaning across the poem. Quote the relevant lines by description (not full stanza).

## DIAGNOSTIC_ANSWER_3
The moon (चाँद) functions as a symbol of fragile freedom. Initially described as a "white flower" (सफेद फूल), its color fades at the touch of a gentle breeze (मंद पवन का स्पर्श), and the moonlight spreads like "olive oil" (जैतून के तेल) carrying the "scent of freedom" (उन्मुक्तता की गंध). The progression from static beauty → vulnerability → expansive fragrance maps the journey of freedom from ideal to threatened to pervasive. A wrong answer that only identifies "moon = beauty" ignores the dynamic development and the specific abstract idea (freedom) tied to the symbol.

## DIAGNOSTIC_QUESTION_4
Compare the use of irony in the two poems. How does the target of irony differ in "नहीं वोस्यक" versus "मैंने देखा, एक चाँद"?

## DIAGNOSTIC_ANSWER_4
In "नहीं वोस्यक", irony targets societal categorization: the label "वोस्यक" (night-flower) represents passive, decorative beauty imposed by tradition, which the poet rejects in favor of labor-born vitality. In "मैंने देखा, एक चाँद", irony is subtler — the moon, a celestial symbol of constancy, is shown as fragile and changeable (color fading at a breeze's touch), ironically mirroring how freedom appears eternal but is actually vulnerable. A student who claims both poems use irony to "criticize society" without distinguishing the specific targets (labels vs. illusions of permanence) shows superficial comparative analysis.

## DIAGNOSTIC_QUESTION_5
Evaluate the effectiveness of the symbol "श्रम" (labor) in "नहीं वोस्यक". Does treating labor as a cultivator of the flower strengthen or weaken the poem's message? Justify.

## DIAGNOSTIC_ANSWER_5
It strengthens the message because it transforms labor from a burden into a creative, life-giving force — the flower *is* "वह फूल जिसे श्रम ने उगाया है" (the flower that labor has grown). This personification makes the abstract dignity of labor tangible and beautiful, aligning with the poem's theme of redefining worth. A student who says "it's just a metaphor" fails to evaluate the symbolic weight: the symbol operates across the whole poem, not as a one-off comparison, and its effectiveness lies in making the political (labor rights) aesthetic.

## DIAGNOSTIC_QUESTION_6
Write a 4-line stanza in Hindi that uses irony to describe a common school experience, and include one symbol that represents an abstract idea (e.g., hope, pressure, freedom). Do not copy from the textbook.

## DIAGNOSTIC_ANSWER_6
Example: "घंटी बजी, कक्षा खाली / गुरुजी बोले, 'पढ़ो मतवाली' / दीवार पर टँगा एक टूटा पंखा / घूमता रहा, थकान का गवाह।" Irony: teacher tells students not to study (opposite of expectation). Symbol: broken fan = relentless exhaustion. A poor answer that writes a sincere description without contradiction (no irony) or uses a direct comparison like "पढ़ाई पहाड़ है" (simile, not symbol) shows inability to generate the devices independently.

## COMMON_MISCONCEPTION
Students often conflate **symbolism with metaphor** — they think any comparison is a symbol. In these poems, the moon is a symbol because it *recurs* and *accumulates meaning* (fragility → freedom) across stanzas, whereas a metaphor is a localized "A is B" statement. Similarly, they mistake **irony for mere surprise or coincidence** — e.g., calling the flower's brightness "ironic" because it's not a night-flower. True irony requires a *structural contradiction* between expectation (set up by the title/repetition) and fulfillment (labor-born flower). This error costs marks in board answers where examiners expect precise device identification with textual anchoring.

## ON_FAILURE
1. Revisit node c12_hin_a_cbse_03_008 (Imagery and Metaphor) to sharpen the distinction: metaphor = explicit comparison; symbol = sustained representation. 2. Re-read "नहीं वोस्यक" marking every occurrence of "नहीं" and "यह" — trace how the poem builds an expectation then subverts it (irony structure). 3. For symbolism, list all concrete nouns in "मैंने देखा, एक चाँद" (चाँद, फूल, पवन, तेल, गंध) and write the abstract idea each *could* represent; then verify against the poem's closing lines. 4. Re-diagnostic: Write one PEEL paragraph analyzing the irony in the title "नहीं वोस्यक" using the structure: Point → Evidence (line reference) → Explanation (expectation vs reality) → Link (theme of labor dignity).

## BUILDS_ON
c12_hin_a_cbse_03_008 (Literary Devices: Imagery and Metaphor) — establishes the baseline of figurative language before advancing to structural devices like irony and multi-layered symbols.

## LEADS_TO
c12_hin_a_cbse_03_010 (Vocabulary in Context) — understanding irony/symbolism clarifies nuanced word choices; c12_hin_a_cbse_03_012 (Comprehension) — inferential questions often hinge on recognizing these devices; c12_hin_a_cbse_03_013 (Critical Thinking) — deeper interpretation requires device analysis.

## PREREQUISITE_NODE_IDS
c12_hin_a_cbse_03_008, c11_hin_ar_cbse_15_009, c11_hin_v_cbse_05_009, c12_hin_a_cbse_03_006

## PREREQUISITE_REASONS
c12_hin_a_cbse_03_008: Provides foundation in figurative language (metaphor, imagery) needed to distinguish symbolism from metaphor.
c11_hin_ar_cbse_15_009: Class 11 Antra Chapter 15 covers irony and symbolism in poetry, giving prior exposure to definitions and simpler examples.
c11_hin_v_cbse_05_009: Class 11 Vitan Chapter 5 includes analysis of symbolic language in prose, reinforcing cross-genre recognition.
c12_hin_a_cbse_03_006: Irony/symbolism (child as savior, society as threat) deepens the thematic reading.  

## FORWARD_NODE_IDS
c12_hin_a_cbse_03_010, c12_hin_a_cbse_03_012, c12_hin_a_cbse_03_013, c12_hin_a_cbse_03_014, c12_hin_a_cbse_03_015

## FORWARD_REASONS
c12_hin_a_cbse_03_010: Vocabulary items like "वोस्यक", "उन्मुक्तता", "जैतून" carry symbolic weight understood only after this node.
c12_hin_a_cbse_03_012: Inferential comprehension questions (e.g., "Why does the poet reject the night-flower label?") require irony/symbolism analysis.
c12_hin_a_cbse_03_013: Critical interpretation of the poet's worldview (labor dignity, freedom) is built on decoding these devices.
c12_hin_a_cbse_03_014: Irony/symbolism analysis elevates "Explanation" from literal to interpretive.  
c12_hin_a_cbse_03_015: अगला तार्किक चरण: Speaking and Listening: इस नोड की अवधारणाओं को सीधे उपयोग/विस्तारित करता है।  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
No prior-class nodes from other subjects are listed in the provided data; cross-subject links are established at Class 12 level in the CROSS_SUBJECT section below.

## CHAIN_DESCRIPTION
c12_hin_a_cbse_03_008 -> c12_hin_a_cbse_03_009 -> c12_hin_a_cbse_03_012

## THIS_FORMULA
N/A - conceptual

## FORMULA_VARIABLES
N/A

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
conceptual

## CROSS_SUBJECT
N/A | The poem "नहीं वोस्यक" uses the flower of labor as a symbol of self-reliance, paralleling History's theme of Swadeshi movement where khadi (spun cloth) became a symbol of economic independence and dignity of labor.
 N/A | Irony in "मैंने देखा, एक चाँद" — the moon's fragility symbolizing freedom's vulnerability — connects to Sociology's analysis of how rights appear guaranteed but are structurally fragile for marginalized groups.
## PREREQ_CONCEPT
Ability to distinguish metaphor (local comparison) from symbol (sustained representation) and to detect expectation-reality gaps (irony) — developed in Class 11 poetry analysis nodes.

## PREREQ_BEFORE
Student must know: (1) definition of metaphor and imagery, (2) how to annotate a poem for repeated words and structural shifts, (3) the PEEL answer structure for literary analysis.

## PREREQ_STUCK
If stuck, review "Symbol vs Metaphor" distinction in c12_hin_a_cbse_03_008 and practice annotating expectation-setting lines in any Class 11 poem (e.g., c11_hin_ar_cbse_15_009).

## WORKED_EXAMPLE_1
PROBLEM: Analyze the irony in the opening stanza of "नहीं वोस्यक" where the poet lists what the flower is NOT before revealing what it IS.
STEPS:
- Step 1: Identify the expectation set by the title and first line — "नहीं वोस्यक" primes the reader for a poem about a night-flower (romantic, nocturnal, passive).
- Step 2: Note the repetition of "नहीं" (not) in lines 1-3 — each negation reinforces the absent category, building anticipation for the positive definition.
- Step 3: Locate the turn: "यह फूल है... यह सुगंध है... यह वसंत है" — the poem pivots to assertions of presence, each linked to labor (श्रम), openness (उन्मुक्त), and spring (वसंत).
- Step 4: Explain the ironic gap — the night-flower symbolizes elite, effortless beauty; the actual flower symbolizes democratic, earned beauty. The irony critiques aesthetic hierarchies.
- Step 5: Connect to theme — this irony establishes the poem's central argument: true worth comes from labor, not lineage or convention.
REASONING: The steps move from surface structure (repetition/negation) to thematic payoff, modeling how to trace irony from device to meaning — a board-exam required skill.
ANSWER: The irony lies in the structural reversal: the poem denies the conventional symbol (night-flower) to install a new symbol (labor-flower), exposing the hollowness of inherited aesthetic categories and elevating the dignity of work.

## WORKED_EXAMPLE_2
PROBLEM: Explain how the symbol of "बreeze" (पवन) in "मैंने देखा, एक चाँद" transforms from a physical touch to a carrier of abstract meaning.
STEPS:
- Step 1: Locate the breeze's first appearance — "मंद पवन का स्पर्श" (gentle breeze's touch) causing the moon-flower's color to fade.
- Step 2: Observe the immediate effect — "जैतून के तेल की तरह / फैली चाँदनी" (moonlight spread like olive oil) — a simile linking breeze to expansion.
- Step 3: Identify the culminating phrase — "उन्मुक्तता की गंध से" (with the scent of freedom) — the breeze becomes the agent that releases freedom's fragrance.
- Step 4: Trace the symbolic arc — physical touch → chemical spreading (oil) → olfactory abstraction (scent of freedom). The breeze symbolizes the subtle, uncontrollable force that liberates constrained beauty.
- Step 5: Relate to poem's closure — the final line "यह फूल... यह चाँद... यह उन्मुक्तता" fuses moon, flower, and freedom; the breeze is the catalyst making the symbol active, not static.
REASONING: This models symbol-tracking across a poem — a competency needed for "analyze the development of a symbol" questions in boards and CUET.
ANSWER: The breeze symbolizes the gentle but inevitable force of liberation; its progression from tactile to olfactory imagery mirrors how freedom spreads invisibly yet pervasively, turning the moon from a passive object into an active emblem.

## WORKED_EXAMPLE_3
PROBLEM: Compare the function of irony in both poems to show how Varjik uses it to redefine "worth" — one in social terms, one in existential terms.
STEPS:
- Step 1: In "नहीं वोस्यक", map the irony: Title/label (वोस्यक) = socially sanctioned beauty (night, elite, decorative) vs. Reality (श्रम का फूल) = labor-born, daytime, life-giving. Worth is redefined from *inherited status* to *earned creation*.
- Step 2: In "मैंने देखा, एक चाँद", map the irony: Moon = culturally fixed symbol of permanence, distance, purity vs. Poem's moon = fragile, responsive, fading at a touch, yet spreading freedom. Worth is redefined from *static perfection* to *vulnerable generativity*.
- Step 3: Identify the common mechanism — both poems set up a cultural symbol (night-flower, moon) and subvert it through sensory evidence (color fading, labor growing) to install a human-centered value (labor, freedom).
- Step 4: Note the difference in tone — first poem is declarative, collective ("यह फूल जिसे श्रम ने उगाया"); second is observational, personal ("मैंने देखा"). Irony serves polemic in first, revelation in second.
- Step 5: Synthesize — Varjik's irony is not mere contradiction; it's a hermeneutic tool to strip away false absolutes and install lived experience as the measure of worth.
- Step 6: Board-exam application — a 5-mark question "How does the poet use irony to challenge established symbols?" would require this dual-poem synthesis with textual anchors.
REASONING: This multi-step comparative analysis mirrors the highest-order board questions (competency-based) and JEE-style literary reasoning where device-function mapping across texts is tested.
ANSWER: Varjik deploys irony as a corrective lens: in Poem 1 it dismantles class-coded beauty (night-flower) to install labor as the true aesthetic; in Poem 2 it destabilizes metaphysical fixity (moon) to install freedom as fragile yet expansive. Both re-center worth on human agency.

## COMPETENCY_QUESTION_1
QUESTION: A student writes: "The irony in 'नहीं वोस्यक' is that the poet says it's not a night-flower but then describes a flower anyway." Identify the flaw in this understanding and rewrite the answer to show correct analysis of irony's structural role.
COMPETENCY: Critical analysis of literary device function
STEPS:
- Step 1: Identify the error — the student reduces irony to factual contradiction ("not X but X") missing the *semantic contrast* between two *kinds* of flowers (night-flower vs labor-flower).
- Step 2: Explain what irony actually does here — it juxtaposes two value systems: passive/received beauty vs active/earned beauty.
- Step 3: Draft corrected answer using PEEL: Point (irony redefines beauty), Evidence (title vs "श्रम ने उगाया"), Explanation (night-flower = tradition, labor-flower = progress), Link (theme of dignity).
- Step 4: Ensure the rewrite uses terms "expectation", "subversion", "symbolic replacement".
ANSWER: Flaw: Treats irony as logical negation rather than value inversion. Corrected: "The poem's irony lies in its structural subversion: the repeated negation 'नहीं वोस्यक' evokes the culturally revered night-flower (symbol of effortless, aristocratic beauty) only to replace it with a flower born of 'श्रम' (labor), 'वसंत' (spring), and 'उन्मुक्तता' (freedom). This ironic reversal dismantles the hierarchy that privileges inherited aesthetic categories over the creative dignity of work, making the laborer the true cultivator of beauty."
DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: In "मैंने देखा, एक चाँद", the moon's color fades at the touch of a breeze, yet the moonlight spreads "like olive oil" carrying "the scent of freedom". Construct an argument evaluating whether this sequence resolves or deepens the irony of the moon as a symbol of permanence.
COMPETENCY: Evaluative interpretation with textual synthesis
STEPS:
- Step 1: State the traditional symbol — moon = constancy, immortality, unchanging (cultural trope).
- Step 2: Identify the poem's irony — the moon is fragile ("रंग उड़ गया"), responsive to a mere breeze.
- Step 3: Analyze the spreading moonlight — "जैतून के तेल की तरह फैली" suggests viscosity, coverage, penetration — not disappearance but transformation.
- Step 4: Evaluate the "scent of freedom" — freedom is not a static state but a dynamic, spreading influence; the moon's fading color *enables* its fragrance.
- Step 5: Conclude — the irony deepens: permanence was an illusion; true worth lies in the capacity to disseminate freedom. The symbol evolves from "moon as object" to "moon as event of liberation".
- Step 6: Write a 150-word argument with claim, evidence, reasoning, and nuanced conclusion.
ANSWER: The sequence deepens the irony. The moon's cultural symbolism rests on fixity — it watches, unchanged. Varjik's moon, however, *changes*: its color flees at a breeze's touch, seemingly confirming fragility. But this very fragility triggers the spreading of moonlight "like olive oil" — a substance that penetrates, coats, endures. The final metamorphosis into "उन्मुक्तता की गंध" (scent of freedom) reveals that the moon's value was never in its unchanging face but in its capacity to release freedom into the world. Irony thus shifts from "moon is not permanent" to "permanence is the wrong virtue; generative vulnerability is the true mark of freedom." The symbol is not destroyed but transfigured.
DIFFICULTY: hard