## DEFINITION
Literal comprehension involves understanding information directly stated in the text (facts, names, sequences, explicit descriptions). Inferential comprehension requires deriving implied meanings by connecting textual clues—such as character actions, dialogue, imagery, and context—to draw conclusions about motives, themes, relationships, or authorial intent that are not openly declared.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student can independently classify a question as literal or inferential, retrieve exact textual evidence for literal answers, and construct a logical inference for inferential answers by citing at least two specific textual clues and explaining the reasoning link using the PEEL (Point, Evidence, Explanation, Link) structure.

## SCOPE_BOUNDARY
This node covers strategies for answering literal and inferential questions based solely on the chapter "Fe;k¡ ulh#íhu" (The Old Woman). It does not cover critical appreciation, creative writing tasks, grammatical analysis, or comparative studies with other texts.

## WALKTHROUGH
Imagine you are reading a social media post about a street vendor in your city: the post explicitly states their name, age, and what they sell (literal), but to understand *why* they continue this work despite hardships, you must piece together clues like their pride in a family recipe, a mention of a sick child, or a refused job offer (inferential). Similarly, when approaching a comprehension question on "Fe;k¡ ulh#íhu", first read the question and underline keywords. Ask: "Can I point to a single sentence that answers this?" If yes, it's literal—quote or paraphrase that sentence. If not, it's inferential—hunt for 2-3 clues (dialogue, description, contrast, repetition) that *together* imply the answer. The key insight: literal answers live *in the text*; inferential answers live *in your reasoning* but must be *anchored* in the text.

## DIAGNOSTIC_QUESTION_1
Define literal comprehension and give one example of a literal question from the chapter "Fe;k¡ ulh#íhu".

## DIAGNOSTIC_ANSWER_1
Literal comprehension is the ability to identify information explicitly stated in the text. Example: "What does the old woman (fe;k¡ ulh#íhu) make for a living?" Answer: She makes baskets (jksVh). A wrong answer—such as "She is poor and struggles"—reveals the student is confusing explicit facts with inferred socioeconomic status, indicating they cannot distinguish directly stated details from implied conditions.

## DIAGNOSTIC_QUESTION_2
The narrator initially refers to the old woman as "ukuckbZ" (illiterate). Explain in your own words what this label reveals about the narrator's assumption regarding her skill and knowledge.

## DIAGNOSTIC_ANSWER_2
The label reveals the narrator's biased assumption that basket-weaving is unskilled manual labor requiring no formal education or intellectual capacity, equating literacy only with school-based reading/writing. A wrong answer like "It shows she never went to school" merely repeats the literal label without interpreting the narrator's *attitude*, showing the student misses the inferential layer of social prejudice embedded in the word choice.

## DIAGNOSTIC_QUESTION_3
Read this hypothetical excerpt based on the chapter's style: "Her fingers flew over the bamboo strips, weaving a pattern her grandmother taught her, humming a tune that matched the rhythm of her work." Identify whether the following question is literal or inferential, then answer it: "What does the humming suggest about her relationship with her craft?"

## DIAGNOSTIC_ANSWER_3
This is an **inferential** question. The text does not explicitly state her feelings. Steps: 1) Note the clues: "fingers flew" (skill/ease), "pattern her grandmother taught her" (tradition), "humming a tune that matched the rhythm" (joy/absorption). 2) Connect clues: The humming indicates deep familiarity, comfort, and emotional connection—she doesn't just *do* the work; she *inhabits* it. 3) Answer: The humming suggests she finds joy, pride, and a meditative flow in her craft, viewing it as a living heritage rather than mere labor. A wrong answer quoting only "grandmother taught her" treats it as literal fact retrieval, missing the synthesis of action, tradition, and sound required for inference.

## DIAGNOSTIC_QUESTION_4
Compare the narrator's attitude toward the old woman in the opening scene (where he asks about her literacy) and the closing scene (after she recites the verse). What specific textual evidence shows this shift?

## DIAGNOSTIC_ANSWER_4
Opening: Narrator asks condescendingly, "D;k vki ukuckbZ gSa?" (Are you illiterate?) and offers money dismissively ("vxj vki dks Hkstk enjls rks..."). Closing: He listens "vk¡[kksa osQ oaQps" (with ears wide open) to her verse, feels "cksyh" (shame), and reflects on the narrowness of his definition of literacy. Evidence of shift: 1) Change from interrogative to attentive posture. 2) Internal monologue admitting "esjk D;k lkI+kQ u Fkk" (I had no answer). 3) Final realization that true knowledge isn't certificate-bound. A wrong answer stating only "he became respectful" without citing the specific behavioral and internal changes shows inability to trace character arc through textual evidence.

## DIAGNOSTIC_QUESTION_5
Evaluate whether the title "Fe;k¡ ulh#íhu" (The Old Woman) adequately captures the central theme of the chapter, or if a title highlighting her skill (e.g., "The Basket Weaver") would be more appropriate. Justify using textual evidence.

## DIAGNOSTIC_ANSWER_5
"Fe;k¡ ulh#íhu" is deliberately reductive—it mirrors the narrator's (and society's) initial gaze that sees only age/gender, rendering her skill invisible. The chapter's arc *subverts* this title by revealing her as a poet, teacher, and philosopher. A title like "The Basket Weaver" would center her agency and craft, aligning better with the theme of unrecognized wisdom. However, the given title *is* appropriate *ironically*: it hooks the reader's bias, making the revelation sharper. A weak answer choosing one title without acknowledging the irony shows failure to evaluate authorial intent and the interplay between form and theme.

## DIAGNOSTIC_QUESTION_6
Write a 4-line diary entry from the old woman's perspective the night after the narrator leaves, inferring her unspoken thoughts about the encounter. Use at least one textual clue to ground your inference.

## DIAGNOSTIC_ANSWER_6
*Criteria for a strong answer:* 1) Voice reflects her dignity and oral tradition (e.g., simple, rhythmic language). 2) References a specific textual moment (e.g., the narrator's "cksyh" or her verse about "Hkêòh"). 3) Shows emotional complexity—not just victory, but perhaps weariness at having to prove her worth. *Example:* "He came asking for letters, left hearing the song of bamboo. My hands knew what his certificates forgot. The night is quiet; the strips wait for morning." A poor answer invents generic gratitude ("I am happy he learned") without textual anchoring, revealing the student treats inference as imagination unmoored from evidence.

## COMMON_MISCONCEPTION
Students treat inferential questions as "guess what the author meant" and either: (a) quote a single unrelated line as "proof", or (b) write a personal opinion with zero textual support. For example, asked "Why does the old woman refuse the narrator's money?", a student might write "Because she is proud" (opinion) or quote "vki gh crkb," (irrelevant dialogue). The error stems from not understanding that an inference is a **logical bridge** between *multiple* explicit clues (her self-reliance shown in "ulhgr dkgs dh fe;k¡", her definition of literacy in the verse, the narrator's own shame) and the implicit motive. They miss the step of *collecting* clues before *connecting* them.

## ON_FAILURE
1. **Model the bridge**: Take a simple inferential question ("Why did the narrator feel shame?"). Write a 3-column table on board: **Clue 1** (Text: "vk¡[kksa osQ oaQps ge ij isQj fn,A") → **Clue 2** (Text: "esjk D;k lkI+kQ u Fkk") → **Clue 3** (Text: "rkyhe dh rkyhe gh cM+h ph”k gksrh gS"). **Inference**: He realized his narrow definition of literacy failed against her lived wisdom. 2. **Guided practice**: Give a familiar text (e.g., a Class 10 Hindi chapter). Ask students to highlight *only* the clues for a given inference. 3. **Graphic organizer drill**: Use a "Text says / I infer / Because" sheet for 5 chapter questions. 4. **Peer review**: Students swap answers and check: "Does every 'I infer' have at least two 'Text says' arrows pointing to it?"

## BUILDS_ON
Thorough knowledge of plot sequence (node 002), protagonist's characterization (node 004), and primary theme of traditional wisdom vs. formal literacy (node 006).

## LEADS_TO
Critical analysis of author's craft and thematic depth (node 013) and structured analytical writing for board exams (node 014).

## PREREQUISITE_NODE_IDS
c11_hin_ar_cbse_02_002, c11_hin_ar_cbse_02_004, c11_hin_ar_cbse_02_006, c11_hin_ar_cbse_02_010, c11_hin_ar_cbse_02_009, c11_hin_ar_cbse_02_011

## PREREQUISITE_REASONS
c11_hin_ar_cbse_02_002: Plot knowledge is essential to locate events and dialogues for literal retrieval and to establish the narrative timeline for inferences.
c11_hin_ar_cbse_02_004: Understanding the old woman's traits (skill, dignity, oral wisdom) provides the character foundation for inferring her motives and responses.
c11_hin_ar_cbse_02_006: The central theme (redefining literacy/education) is the lens through which major inferential questions about the chapter's message are answered.
c11_hin_ar_cbse_02_010: Vocabulary mastery (e.g., ukuckbZ, ulhgr, bYe, Hkêòh) is prerequisite for comprehending both questions and textual evidence accurately.
c11_hin_ar_cbse_02_009: Comprehension questions require identifying and explaining irony/symbolism as textual evidence  
c11_hin_ar_cbse_02_011: Comprehension questions require understanding of indirect speech to interpret reported dialogues.  

## FORWARD_NODE_IDS
c11_hin_ar_cbse_02_013, c11_hin_ar_cbse_02_014, c11_hin_ar_cbse_02_015, c12_hin_a_cbse_01_012, c12_hin_a_cbse_03_012, c12_hin_a_cbse_17_012, c12_hin_al_cbse_03_012, c12_hin_ar_cbse_04_012, c12_hin_ar_cbse_05_012, c12_hin_v_cbse_02_012

## FORWARD_REASONS
c11_hin_ar_cbse_02_013: Critical thinking requires moving beyond "what happens" and "what is implied" to "how the author constructs meaning"—a direct extension of inferential skills.
c11_hin_ar_cbse_02_014: Writing skills tasks (analytical paragraphs, character sketches) demand the PEEL structure mastered here: Point (inference), Evidence (quotes), Explanation (reasoning), Link (theme).
c11_hin_ar_cbse_02_015: Literal/inferential comprehension ensures baseline textual accuracy — no discussion survives factual errors.  
c12_hin_a_cbse_01_012: Prior practice with different poems builds transferable comprehension strategies  
c12_hin_a_cbse_03_012: Reinforced practice with different text types  
c12_hin_a_cbse_17_012: Practice with varied genres (story, essay, memoir) in Class 11 builds transferable evidence-location skills.  
c12_hin_al_cbse_03_012: Reinforces inference across different text types (prose/poetry).  
c12_hin_ar_cbse_04_012: अगला तार्किक चरण: Literal comprehension is the ability to extract explicitly stated facts, details, and sequences dire... इस नोड की अवधारणाओं को सीधे उपयोग/विस्तारित करता है।  
c12_hin_ar_cbse_05_012: Class 11 Chapter 2 practiced evidence-chaining for inferential answers.  
c12_hin_v_cbse_02_012: Further practice with different genres.  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
No prior class nodes available for cross-subject mapping in this subject.

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_02_002 -> c11_hin_ar_cbse_02_012 -> c11_hin_ar_cbse_02_013

## THIS_FORMULA
N/A - conceptual

## FORMULA_VARIABLES
N/A

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
linguistic

## CROSS_SUBJECT
c11_history_02 | Analyzing historical sources requires distinguishing explicit statements (literal) from implied biases, audience, and context (inferential), mirroring textual comprehension skills.
c11_geography_03 | Interpreting map data, satellite images, and case studies involves reading direct facts (literal) and inferring processes, patterns, and human-environment interactions (inferential).

## PREREQ_CONCEPT
Ability to distinguish between explicitly stated information and implicitly suggested meaning in a narrative text.

## PREREQ_BEFORE
Student must have read the full chapter "Fe;k¡ ulh#íhu" and be familiar with the storyline, main characters, and key vocabulary listed in the textbook glossary.

## PREREQ_STUCK
Review the chapter summary (node 002) and the protagonist's character profile (node 004) to refresh specific textual details needed for evidence.

## WORKED_EXAMPLE_1
PROBLEM: Answer the following question from the chapter: "Why does the old woman say 'rkyhe dh rkyhe gh cM+h ph”k gksrh gS' (even the smallest mistake becomes a big deal) in the context of the narrator's visit?"
STEPS:
- Step 1: Identify question type. "Why" signals inferential—need to explain motive/meaning behind a quoted statement.
- Step 2: Locate the quote in the text (near the end, after the narrator's failed interrogation). Note the speaker (old woman) and listener (narrator).
- Step 3: Gather surrounding clues: (a) Narrator's persistent questioning about formal literacy. (b) Old woman's earlier verse defining true education as practical wisdom. (c) Narrator's resulting shame ("cksyh"). (d) The metaphor of "ph”k" (mistake/sin) in a craft context.
- Step 4: Synthesize inference: She implies that the narrator's obsession with certificates is a fundamental error ("ph”k") because it blinds him to real knowledge; in her world (craft/life), such an error has massive consequences ("cM+h ph”k").
- Step 5: Structure PEEL answer: Point: She critiques the narrator's value system. Evidence: Quote her verse on "Hkêòh" and his "cksyh". Explanation: The "ph”k" is misdefining literacy; "cM+h" consequence is losing access to genuine wisdom. Link: Reinforces theme—traditional knowledge systems have their own rigorous standards.
REASONING: This models the inferential process: quote → context → multiple clues → logical synthesis → thematic link. It prevents the common error of treating the quote as a standalone proverb.
ANSWER: The old woman uses the metaphor of craftsmanship—where a tiny error ruins the whole piece—to tell the narrator that his narrow equation of literacy with schooling is a fatal conceptual error. By ignoring her practical, oral, and ecological knowledge, he commits a "big mistake" that cuts him off from a vast reservoir of wisdom, as shown by his own shame when he cannot answer her counter-questions about nature and survival.

## WORKED_EXAMPLE_2
PROBLEM: "The narrator's offer of money to the old woman is rejected. Provide two distinct pieces of textual evidence that explain *why* she refuses, and state the character trait this reveals."
STEPS:
- Step 1: Classify question—partly literal (find evidence of refusal/reason), partly inferential (deduce trait).
- Step 2: Scan for money-offer scene. Locate: "vxj vki dks Hkstk enjls rks cPpk u dPph esa cSBk..." (If you want to give money, let the child sit in the lap...).
- Step 3: Identify Evidence 1 (Direct speech): She refuses via a riddle/condition: money only if he makes a child sit in lap / in courtyard / on tree—impossible tasks implying money isn't the transaction she values.
- Step 4: Identify Evidence 2 (Narrative description): "fe;k¡ ulh#íhu us vk¡[kksa osQ oaQps ge ij isQj fn,A" (She looked at us with wide ears/attention)—showing she is evaluating *him*, not seeking alms. Her later verse on self-reliance ("ge Hkêòh cukuk u lh[krs...") confirms economic independence as principle.
- Step 5: Infer trait: **Fierce dignity / Professional pride**. She views her craft as skilled labor deserving fair exchange, not charity.
- Step 6: Write structured response: Point: Refusal stems from professional self-worth. Evidence 1: The impossible conditions for accepting money. Evidence 2: Her verse asserting "we don't create problems, we don't beg." Explanation: Both show she frames the interaction as expert-client, not beggar-donor. Link: Embodies theme of "ulhgr" (skill) as identity.
REASONING: Demonstrates how literal evidence (dialogue, description) fuels inferential conclusion (trait). The two evidences must be distinct—one verbal, one behavioral/philosophical.
ANSWER: Evidence 1: She sets absurd conditions for taking money ("cPpk u dPph esa cSBk..."), implying the offer insults her trade. Evidence 2: Her verse declares "ge Hkêòh cukuk u lh[krs / Hkêòh dks vk¡p nsuk u lh[krs" (we don't create problems, we don't beg), establishing self-reliance as creed. Trait revealed: **Professional dignity**—she demands recognition as a skilled artisan, not pity as an old woman.

## WORKED_EXAMPLE_3
PROBLEM: "Trace the evolution of the narrator's understanding of 'literacy' (bYe/ukuckbZ) across the chapter. Use three textual milestones to support your analysis."
STEPS:
- Step 1: Define the scope—inferential tracking of a concept across the narrative arc.
- Step 2: Milestone 1 (Beginning): Literal statement of narrator's definition. Text: He asks "D;k vki ukuckbZ gSa?" and thinks "fe;k¡ ukuckbZ] dksbZ ubZ ph”k f[kyk ldrs gSa\"?" (Can an illiterate old woman invent a new thing?). Definition: Literacy = formal schooling/certificate.
- Step 3: Milestone 2 (Middle - The Test): Narrator challenges her to prove literacy. Text: "D;k muls cuh ,slh ph”k!" (What can she create?). She responds with the verse on practical wisdom. Narrator's reaction: "cksyh" (shame). Definition challenged: Literacy includes oral composition, ecological knowledge.
- Step 4: Milestone 3 (End - Internalization): Narrator's reflection. Text: "rkyhe dh rkyhe gh cM+h ph”k gksrh gS" (he absorbs her metaphor) and final thought: "dgkor tc Hkh x<+h xbZ gks] gekjs cq”kqxks± osQ djrc ij gh iwjh mrjrh gSA" (A story reaches the heart of the matter). Definition transformed: Literacy = lived, tested wisdom that resonates universally.
- Step 5: Synthesize analysis: The narrator moves from institutional to functional to existential definition. Each milestone uses a structural device: dialogue → poetic counter-narrative → metaphorical realization.
- Step 6: Write answer with clear transitions: "Initially... However... Ultimately..."
REASONING: This multi-step worked example combines literal retrieval (milestones) with inferential synthesis (evolution of concept), modeling the high-order "trace the development" board question pattern. It requires integrating plot (node 002), character arc (node 004), and theme (node 006).
ANSWER: The narrator's concept of literacy undergoes a three-stage inversion. **Stage 1 (Institutional):** He equates literacy with formal certification, dismissing her as "ukuckbZ" and questioning her capacity for innovation ("dksbZ ubZ ph”k"). **Stage 2 (Functional):** Her verse—listing survival skills (reading nature, making shelter, teaching children without schools)—forces him to confront a literacy rooted in competence ("bYe" as practical knowledge). His "cksyh" marks the fracture. **Stage 3 (Existential):** He internalizes her metaphor ("rkyhe dh rkyhe gh cM+h ph”k"), realizing that misreading a human being's worth is the gravest error. The story ("dgkor") becomes the true literacy test—one he barely passes.

## COMPETENCY_QUESTION_1
QUESTION: Based on the chapter, explain how the old woman's spontaneous verse ("ge crZu èkksuk u lh[krs / ge Hkêòh cukuk u lh[krs...") functions as a *counter-curriculum* to the narrator's school-based definition of education. Use at least two specific lines from the verse and link each to a concrete skill or value she embodies.
COMPETENCY: Critical Thinking & Textual Evidence (CBSE Competency: Analysis and Interpretation)
STEPS:
- Step 1: Deconstruct the prompt: "counter-curriculum" means an alternative syllabus/value system. Identify the narrator's curriculum (formal, certificate-based).
- Step 2: Select Line 1: "ge crZu èkksuk u lh[krs / ge Hkêòh cukuk u lh[krs" → Link to skill: **Ecological literacy / Sustainable living** (she reads nature, builds shelter without harming environment).
- Step 3: Select Line 2: "Hkêòh dks vk¡p nsuk u lh[krs / rks D;k ge lhèks&lhèks ukuckbZ dk gquj lh[k tkrs!" → Link to value: **Self-reliance & Dignity of Labor** (refusal to beg/create dependency; craft as empowerment).
- Step 4: Contrast with narrator: He represents a system that produces "cksyh" (shame) when faced with real-life problems; she represents a system that produces solutions.
- Step 5: Conclude: The verse isn't just defense—it's a pedagogic intervention re-centering education on survival, ethics, and autonomy.
ANSWER: The verse operates as a lived curriculum that replaces abstract certification with demonstrable competence. Line 1 ("ge crZu èkksuk u lh[krs...") maps to her skill as a **builder and ecologist**—she constructs shelter ("Hkêòh") using only what the forest offers, without exploitation, a practical science no textbook teaches. Line 2 ("Hkêòh dks vk¡p nsuk u lh[krs...") maps to her **ethical economy**—she earns through "ulhgr" (skill), refusing the dependency the narrator's money implies. Together, they expose the narrator's education as "lhèks&lhèks" (hollow) because it cannot feed, house, or dignify a person without external aid. Her curriculum graduates survivors; his graduates petitioners.
DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: Compare the old woman's relationship with her craft (basket-weaving) to the narrator's relationship with his writing. What does this contrast reveal about the chapter's critique of modern intellectual labor versus traditional skilled labor? Support with three textual references.
COMPETENCY: Comparative Analysis & Thematic Interpretation (CBSE Competency: Evaluation and Synthesis)
STEPS:
- Step 1: Identify the two relationships: Old woman ↔ Craft (physical, hereditary, rhythmic, identity-defining). Narrator ↔ Writing (intellectual, professional, detached, identity-questioned).
- Step 2: Reference 1 (Old woman): "fe;k¡ e'kgwj gSa NIiu fdLe dh jksfV;k¡ cukus osQ fy," (She is making baskets to make a living)—craft as survival + art. "vk¡[kksa osQ oaQps ge ij isQj fn,A" (total sensory immersion).
- Step 3: Reference 2 (Narrator): "geus tks vanj >k¡dk rks ik;k] fe;k¡ pkjikbZ ij cSBs chM+h dk e”kk ys jgs gSa" (We sat on chairs, she on ground)—physical/elevated distance mirroring intellectual distance. His writing is observed as "dgkor" (story) extracted from her life.
- Step 4: Reference 3 (Climax): Old woman's verse on "Hkêòh" (making shelter) vs. Narrator's admission "esjk D;k lkI+kQ u Fkk" (I had no answer)—her labor produces tangible shelter; his labor produces a story *about* her labor.
- Step 5: Synthesize critique: Modern intellectual labor (writing) extracts, frames, and often misunderstands traditional labor; traditional labor is holistic—epistemology, ontology, and ethics unified. The chapter valorizes the maker over the chronicler.
- Step 6: Structure comparative answer: Similarity (both create), Difference (integration vs. separation), Implication (critique of alienation).
ANSWER: The contrast exposes a hierarchy of alienation. **Reference 1:** The old woman's craft is somatic and ancestral—"NIiu fdLe dh jksfV;k¡" (nimble fingers making baskets)—her body, memory, and ecology are one productive unit. **Reference 2:** The narrator's writing is positional and extractive—he sits "pkjikbZ ij" (on chairs) literally and metaphorically above her, turning her life into "dgkor" (story) for his audience. **Reference 3:** At the climax, her verse on "Hkêòh" (making shelter) represents labor that *directly* sustains life; his confession "esjk D;k lkI+kQ u Fkk" reveals labor that *interprets* life but cannot enact its basics. The chapter critiques modern intellectual work as parasitic on traditional knowledge: it borrows authority from the maker's reality while remaining functionally illiterate in the maker's world. True literacy, the text argues, belongs to the one who can say "I made this, I live this," not "I wrote about this."
DIFFICULTY: hard