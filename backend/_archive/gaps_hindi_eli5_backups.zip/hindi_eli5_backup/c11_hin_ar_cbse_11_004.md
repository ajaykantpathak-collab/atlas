## DEFINITION
Character analysis of the protagonist in poetry involves examining the poetic persona (the 'I' or speaker) through their voice, emotions, memories, relationships, and internal conflicts as revealed in the verses, to understand how the poet constructs identity and conveys the central theme.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student can independently identify the poetic persona's traits across at least three stanzas, cite specific lines as evidence, explain how literary devices shape the portrayal, and write a structured PEEL paragraph linking the protagonist's characterization to the poem's central theme of nostalgia and displacement.

## SCOPE_BOUNDARY
This node covers analysis of the first-person speaker in "Ghar Ki Yaad" — their emotional arc, relationship with parents, concept of home, and use of repetition as characterization. It does NOT cover supporting characters (father, mother) in depth, which is addressed in node c11_hin_ar_cbse_11_005, nor thematic analysis beyond what the protagonist reveals, which is covered in nodes c11_hin_ar_cbse_11_006 and c11_hin_ar_cbse_11_007.

## WALKTHROUGH
Imagine you receive a voice note from a childhood friend who moved abroad years ago — they describe their current apartment, then suddenly start recalling the smell of your mother's cooking, the sound of the temple bell, the exact crack in the courtyard wall. You realize they aren't just describing a house; they're revealing who they are through what they miss. That is exactly how to approach the protagonist in "Ghar Ki Yaad": start by reading the poem aloud to hear the rhythm of longing, then mark every 'main' (I) statement, trace how the speaker's self-description shifts from physical displacement to emotional fragmentation, and finally ask: what does this speaker's memory select, distort, or obsess over? The key insight is that in lyric poetry, the protagonist IS the act of remembering — their character is built not from actions but from what they choose to recall and how they frame it.

## DIAGNOSTIC_QUESTION_1
In the poem "Ghar Ki Yaad," who is the protagonist, and how is this established in the very first stanza?

## DIAGNOSTIC_ANSWER_1
The protagonist is the poetic persona (the speaker/narrator) who uses first-person pronouns like "main" (I) and "mere" (my) — established immediately in the opening lines where the speaker says "vkt ikuh fxj jgk gS" (I have been away for a long time) and "jkr Hkj fxjrk jgk gS" (I have filled my heart with longing). A wrong answer that names "the poet Hokhhu Prasad Vajpayee" directly reveals the misconception of conflating the biographical author with the constructed poetic persona — a critical distinction at senior secondary level where the speaker is a literary device, not necessarily the historical writer.

## DIAGNOSTIC_QUESTION_2
Explain in your own words how the repetition of the refrain "ikuh fxj jgk gS / ?kj u"kj esa frj jgk gS" functions as characterization of the protagonist, not just as a musical device.

## DIAGNOSTIC_ANSWER_2
The refrain acts as a psychological anchor: each recurrence shows the protagonist's mind circling back to the same irreducible truth — physical distance ("ikuh fxj") and emotional displacement ("?kj u"kj esa frj"). It characterizes the speaker as someone trapped in a loop of involuntary memory, unable to assimilate into the present. A wrong answer that only calls it "a chorus for rhythm" or "emphasis on missing home" misses the analytical leap: repetition here maps the protagonist's obsessive-compulsive mental state, revealing character through form.

## DIAGNOSTIC_QUESTION_3
Apply the PEEL structure to write a 4-sentence analysis of how the protagonist's description of the childhood home ("pkj HkkbZ pkj cfgusa") reveals their internal state. Use one specific phrase from the poem as evidence.

## DIAGNOSTIC_ANSWER_3
**Point:** The protagonist's enumeration of "four walls, four doors" reduces the childhood home to a geometric skeleton, revealing emotional detachment from the present. **Evidence:** The phrase "pkj HkkbZ pkj cfgusa" (four walls, four doors) strips the house of sensory warmth. **Explanation:** By counting architectural elements instead of describing lived moments (smells, sounds, textures), the speaker shows how memory has fossilized into schematic recall — the precision masks grief. **Link:** This quantified nostalgia mirrors the poem's central tension: the protagonist measures loss in structural units because feeling it directly is unbearable. A wrong answer that merely paraphrases "the house had four walls and four doors" fails to move from textual detail to psychological inference — the hallmark of Class 11 analytical writing.

## DIAGNOSTIC_QUESTION_4
Analyze the shift in the protagonist's self-portrayal between the middle stanzas (addressing the father) and the closing stanzas (declaring "eSa e"ks esa gw¡ lgh gS / ?kj ugha gw¡ cl ;gh gS"). What does this progression reveal about the character's journey?

## DIAGNOSTIC_ANSWER_4
In the middle stanzas, the protagonist defines themselves relationally — "firk th ftudks cq<+kik" (father who raised me), "ek¡ us dgk gksxk" (mother will say) — positioning themselves as a child seeking validation. In the closing stanzas, they claim epistemic authority: "eSa e"ks esa gw¡ lgh gS" (I am right in my own eyes) and reject external judgment ("rqe cjl yks os u cjlsa"). This traces a trajectory from filial dependence to radical self-possession, where the act of remembering becomes an act of self-creation. A wrong answer that sees only "the speaker misses parents then feels confident" misses the structural irony: the protagonist achieves autonomy precisely through the memory of the home they claim to have left behind.

## DIAGNOSTIC_QUESTION_5
Evaluate this claim: "The protagonist of 'Ghar Ki Yaad' is unreliable because their memory idealizes the past — the father had 'not even one virtue' and the mother's voice 'never reaches the ears,' yet the speaker longs for them." Defend or refute using textual evidence.

## DIAGNOSTIC_ANSWER_5
The claim misunderstands poetic truth: the protagonist explicitly acknowledges the father's flaws ("firk th ftudks cq<+kik ,d {k.k Hkh ugha O;kik") and the mother's silence ("ekSr osQ vkxs u fgposaQ"), yet longs for them *because of*, not despite, these imperfections. The longing is for the *relationship*, not a perfected image. The protagonist's reliability lies in their refusal to sanitize memory — they remember the father's absence of virtue *and* the mother's unheard voice *and* still declare "blh cl ls lc fojl gS" (from this very burning everything is born). A wrong answer that agrees with "unreliable narrator" applies a novelistic trope to lyric poetry, where the speaker's subjectivity *is* the truth being explored.

## DIAGNOSTIC_QUESTION_6
Create a 4-line stanza in the voice of the protagonist ten years after the poem ends, maintaining the same refrain structure but reflecting a changed relationship with memory. Write in Hindi (Devanagari or transliteration).

## DIAGNOSTIC_ANSWER_6
A strong response mirrors the original's anaphora and refrain while showing evolution:
"ab ikuh u fxj jgk gS / ?kj u"kj esa frj u jgk gS /
pkj HkkbZ ab khy tk, / pkj cfgusa vkSj vkSj khy tk, /
firk th dk cq<+kik ab i<+k gw¡ / ek¡ dh uhyh ab le>k gw¡ /
eSa e"ks esa gw¡ lgh gS / ?kj ab gw¡ cl ;gh gS"
This retains the four-wall/four-door motif and the final assertion of self-rightness but transforms "longing" into "reading/understanding" and "burning" into accepted foundation. A poor answer merely repeats the original refrain without temporal shift or psychological growth, revealing inability to synthesize characterization into creative extension.

## COMMON_MISCONCEPTION
Students conflate the *poet* (Hokhhu Prasad Vajpayee, a historical figure who participated in the freedom struggle and edited newspapers) with the *protagonist* (the constructed first-person voice of this specific poem). They write "the poet misses his home" instead of "the speaker constructs a self through selective memory." This error stems from middle-school habit of treating poems as autobiographical diary entries. At Class 11, the protagonist is a literary artifact — their "biography" exists only within the poem's lines. For example, the poem's father is "cq<+kik" (raised me) but "d {k.k Hkh ugha O;kik" (had not a single virtue) — a deliberate characterization choice by the poet, not a factual report on Vajpayee's actual father.

## ON_FAILURE
Step 1: Have the student underline every first-person pronoun (main, mere, mujh, mujhe) in the poem — count them (there are 27+). Step 2: Ask: "Does the poem tell us the speaker's name, caste, profession, or city? No. So who is 'main'?" Step 3: Show two contrasting readings of stanza 3: (A) "The poet's father was bad" vs (B) "The speaker *chooses* to remember the father as flawed — why?" Step 4: Assign a 3-sentence rewrite: "In this poem, the protagonist is not the poet but a voice that..." This forces the distinction between author and persona through textual evidence, not lecture.

## BUILDS_ON
c11_hin_ar_cbse_11_003 (Text: Setting and Atmosphere) — the protagonist's characterization is inseparable from the spatial memory of "ghar" established in the setting node.

## LEADS_TO
c11_hin_ar_cbse_11_005 (Character Analysis: Supporting Characters) — the father and mother exist only as the protagonist's memory constructs them; their analysis depends on first understanding the remembering subject.

## PREREQUISITE_NODE_IDS
c11_hin_ar_cbse_11_001, c11_hin_ar_cbse_11_002, c11_hin_ar_cbse_11_003
## PREREQUISITE_REASONS
c11_hin_ar_cbse_11_001: Context node provides the poet's biography and historical moment (freedom struggle, journalism) — essential to distinguish author from persona.
c11_hin_ar_cbse_11_002: Narrative structure node maps the poem's stanza-by-stanza progression — the protagonist's emotional arc follows this architecture.
c11_hin_ar_cbse_11_003: Setting node establishes "ghar" as both physical space and psychological anchor — the protagonist is defined by their relationship to this setting.

## FORWARD_NODE_IDS
c11_hin_ar_cbse_11_005, c11_hin_ar_cbse_11_006, c11_hin_ar_cbse_11_013, c11_hin_ar_cbse_11_008, c11_hin_ar_cbse_11_012, c11_hin_ar_cbse_11_014, c12_hin_a_cbse_11_004, c12_hin_ar_cbse_11_004, c12_hin_ar_cbse_11_001

## FORWARD_REASONS
c11_hin_ar_cbse_11_005: Supporting characters (father, mother) are filtered through the protagonist's memory; their analysis requires the protagonist's lens as established here.
c11_hin_ar_cbse_11_006: The primary theme (nostalgia as self-construction) emerges directly from the protagonist's characterization — theme analysis builds on character analysis.
c11_hin_ar_cbse_11_013: Critical thinking questions demand synthesis of character, theme, and device — this node provides the character foundation.
c11_hin_ar_cbse_11_008: Identifies the protagonist (the poet himself) whose perspective generates the images and metaphors.  
c11_hin_ar_cbse_11_012: Protagonist (poet persona) analysis supplies the 'speaker' context for inferring tone.  
c11_hin_ar_cbse_11_014: Protagonist analysis supplies character-based evidence.  
c12_hin_a_cbse_11_004: Class 11 foundation on character analysis methods (round/flat, direct/indirect characterization, PEEL structure) — this node deepens, not repeats, that skill.  
c12_hin_ar_cbse_11_004: Class 11 protagonist analysis provides foundational skills for character study (traits, evidence, arc).  
c12_hin_ar_cbse_11_001: If stuck on "psychoanalytic story" definition: Re-read c11_hin_ar_cbse_11_002 (Plot of R;kxi=k) and c11_hin_ar_cbse_11_004 (Character Analysis of R;kxi=k protagonist) — they demonstrate the method in action.  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
No prior class nodes available for cross-subject links in Hindi Aroh.

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_11_003 -> c11_hin_ar_cbse_11_004 -> c11_hin_ar_cbse_11_005: Setting establishes the spatial memory that constructs the protagonist, whose remembering self then generates the supporting characters as memory-figures.

## THIS_FORMULA
N/A - conceptual

## FORMULA_VARIABLES
N/A

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
conceptual

## CROSS_SUBJECT
c11_history_nationalism | The protagonist's displaced longing for "ghar" parallels the historical experience of Partition-era displacement and the construction of national identity through selective memory — both involve defining self by what is lost.
c11_geography_human_geography | The poem's "four walls, four doors" quantification of home reflects geographical concepts of place attachment and topophilia — the protagonist's emotional bond to spatial coordinates mirrors how communities construct identity through territorial memory.
c11_psychology_memory | The refrain's repetitive structure models the psychological phenomenon of intrusive autobiographical memory in nostalgia — the protagonist's looping recall demonstrates how identity stabilizes through recurring memory retrieval.
c11_sociology_socialization | The father-son dynamic ("firk th ftudks cq<+kik") illustrates primary socialization's incomplete internalization — the protagonist rejects the father's virtues yet replicates his authority in the final self-declaration.

## PREREQ_CONCEPT
Distinction between author (biographical person) and poetic persona (constructed speaker) — the foundational concept for all lyric poetry analysis at senior secondary level.

## PREREQ_BEFORE
Student must be able to identify first-person pronouns in Hindi poetry and understand that "main" in a poem is a literary role, not the poet's autobiography.

## PREREQ_STUCK
Review the "author vs. persona" distinction using a simple comparison: read a diary entry vs. a poem's first stanza — list what each reveals about the writer vs. the speaker.

## WORKED_EXAMPLE_1
PROBLEM: Analyze how the protagonist's characterization in Stanza 2 ("?kj u”kj esa frj jgk gS / ?kj fd eq>ls nwj gS tks / ?kj [kq'kh dk iwj gS tks") establishes the central conflict of the poem. Write a PEEL paragraph.

STEPS:
- Step 1: Identify the protagonist's self-statements in Stanza 2 — the speaker locates themselves in "?kj u”kj" (home's courtyard) and defines "ghar" through two metaphors: "nwj" (new/fresh) and "[kq'kh dk iwj" (threshold of ruin).
- Step 2: Note the grammatical shift — "eq>ls" (to me) makes the definition subjective; the home is not objectively new or ruined but *experienced* as such by the protagonist.
- Step 3: Connect the opposing metaphors — "nwj" suggests renewal/possibility, "[kq'kh dk iwj" suggests decay/ending. The protagonist holds both simultaneously, revealing internal contradiction.
- Step 4: Link to central conflict — this duality mirrors the poem's core tension: memory as both sustenance ("nwj") and wound ("[kq'kh dk iwj"). The protagonist is characterized by this paradox.
- Step 5: Draft PEEL: Point — The protagonist embodies the poem's central conflict through contradictory metaphors for home. Evidence — In Stanza 2, the speaker calls home both "nwj" (fresh) and "[kq'kh dk iwj" (ruin's threshold). Explanation — These opposites coexist because the protagonist's memory simultaneously revives and destroys the past; the courtyard ("u”kj") becomes a site where presence and absence occupy the same space. Link — This characterization establishes that the poem's conflict is not external (loss of home) but internal (the protagonist's memory makes home both alive and dead).
- Step 6: Verify against text — The analysis uses only Stanza 2 lines, explains the metaphor pair, and connects to the poem's larger arc (later stanzas resolve this into "blh cl ls lc fojl gS").

REASONING: This example models the senior-secondary skill of reading characterization through metaphorical logic rather than plot summary. The 6 steps move from textual micro-detail (pronouns, metaphors) to macro-structure (central conflict), which is the analytical depth board exams require.

ANSWER:
The protagonist embodies the poem's central conflict through contradictory metaphors for home. In Stanza 2, the speaker calls home both "nwj" (fresh/new) and "[kq'kh dk iwj" (threshold of ruin). These opposites coexist because the protagonist's memory simultaneously revives and destroys the past; the courtyard ("u”kj") becomes a site where presence and absence occupy the same space. This characterization establishes that the poem's conflict is not external (loss of home) but internal (the protagonist's memory makes home both alive and dead).

## WORKED_EXAMPLE_2
PROBLEM: The protagonist addresses the father in Stanza 4 ("firk th ftudks cq<+kik / ,d {k.k Hkh ugha O;kik") and the mother in Stanza 5 ("ek¡ us dgk gksxk / nq%[k fdruk cgk gksxk"). Compare how these two addresses characterize the protagonist differently. Write a structured comparison.

STEPS:
- Step 1: Isolate the father-address (Stanza 4) — the protagonist speaks *about* the father in third person ("firk th... cq<+kik") but *to* an implied listener. The characterization: the speaker evaluates the father morally ("no virtue") yet acknowledges the care ("cq<+kik" — raised/nurtured).
- Step 2: Isolate the mother-address (Stanza 5) — the protagonist *ventriloquizes* the mother ("ek¡ us dgk gksxk" — mother will say), imagining her future speech. The characterization: the speaker needs the mother's voice to validate their suffering ("nq%[k fdruk cgk gksxk" — how much pain you endured).
- Step 3: Identify the structural difference — Father: past tense, judgment, distance. Mother: future tense, empathy, intimacy. The protagonist positions themselves as judge of father, supplicant to mother.
- Step 4: Analyze what this reveals about the protagonist's gendered/psychic economy — The father represents authority to be assessed; the mother represents comfort to be sought. The protagonist's self splits into evaluator and child.
- Step 5: Synthesize into comparison — Both addresses show the protagonist constructing identity *through* parental figures, but the father-address asserts autonomy ("I judge you"), while the mother-address seeks fusion ("speak for me").
- Step 6: Write the comparison paragraph using contrastive connectors (vipreet, jahaan... wahaan) — "Jahaan pita ke sandarbh mein protagonist nyayadhish hai, wahaan ma ke sandarbh mein yachak."

REASONING: This worked example teaches comparative character analysis — a frequent board exam pattern ("Compare the protagonist's relationship with X and Y"). The 6 steps enforce textual grounding (specific stanzas), structural awareness (tense, person), and psychological inference, avoiding the common student error of listing "father is strict, mother is kind" without analyzing the *protagonist's* role in creating those portrayals.

ANSWER:
The protagonist's address to the father positions them as a moral evaluator: "firk th ftudks cq<+kik / ,d {k.k Hkh ugha O;kik" — past tense, third-person judgment, acknowledging care but denying virtue. This characterizes the speaker as one who has outgrown filial piety into critical autonomy. In contrast, the mother-address ("ek¡ us dgk gksxk / nq%[k fdruk cgk gksxk") uses future tense and ventriloquism — the protagonist *needs* the mother's voice to articulate their own pain. Jahaan pita ke sandarbh mein protagonist nyayadhish hai (judge), wahaan ma ke sandarbh mein yachak (supplicant). Both reveal the protagonist constructing selfhood through parental figures, but the father enables separation while the mother enables merger — the poem's central psychological dialectic.

## WORKED_EXAMPLE_3
PROBLEM: The poem's final stanza declares: "eSa e"ks esa gw¡ lgh gS / ?kj ugha gw¡ cl ;gh gS / foaQrq ;g cl cM+k cl gS / blh cl ls lc fojl gS". Analyze how this declaration redefines the protagonist's character arc across the entire poem. Integrate evidence from at least three earlier stanzas.

STEPS:
- Step 1: Parse the final declaration — "eSa e"ks esa gw¡ lgh gS" (I am right in my own eyes) claims epistemic sovereignty; "?kj ugha gw¡ cl ;gh gS" (home is not this, this burning is) redefines home not as the lost house but as the *act of burning/longing itself*; "blh cl ls lc fojl gS" (from this very burning everything is born) makes suffering generative.
- Step 2: Trace back to Stanza 1 — "vkt ikuh fxj jgk gS / jkr Hkj fxjrk jgk gS" — the protagonist begins defined by absence (distance, longing-filled heart). The "cl" (burning) of the end is the matured form of the "jkr" (longing) of the beginning.
- Step 3: Trace back to Stanza 3 — "pkj HkkbZ pkj cfgusa / Hkqtk HkkbZ I;kj cfgusa" — the quantified house (4 walls, 4 doors) becomes the raw material for the "cl" (burning). The protagonist transforms structural memory into creative fire.
- Step 4: Trace back to Stanza 6 — "ik¡o tks ihNs gVkrk / dks[k dks esjh ytkrk" — the image of the threshold that "swallows the lane" and "doorframe that holds the door" prefigures the final "cl" as a portal: the burning *is* the threshold between past and self.
- Step 5: Synthesize the arc — Protagonist moves from: (1) displaced subject (Stanza 1) → (2) architectural rememberer (Stanza 3) → (3) parental judge/supplicant (Stanzas 4-5) → (4) threshold-dweller (Stanza 6) → (5) self-authorizing creator (Stanza 7). The character *becomes* the poem's central metaphor: home is not a place you return to but a fire you become.
- Step 6: Write the integrated analysis — The final stanza retroactively recharacterizes the entire poem: every earlier memory was not retrieval but *preparation* for this self-declaration. The protagonist does not find home; they forge selfhood in the "cl" of longing, making the poem an ars poetica of identity-formation through nostalgia.

REASONING: This is the highest-order worked example — it demands whole-poem synthesis, inter-stanza tracing, and conceptual reinterpretation (the "ars poetica" insight). Board exam long-answer questions (6 marks) require exactly this: a thesis supported by distributed textual evidence showing character development across the text. The 6 steps model the planning process students must internalize for timed exam writing.

ANSWER:
The final stanza redefines the protagonist not as one who *misses* home but as one who *becomes* home through the alchemy of longing. "eSa e"ks esa gw¡ lgh gS" claims the self as its own standard — a radical shift from Stanza 1's "vkt ikuh fxj jgk gS" where identity depends on spatial displacement. The "cl" (burning) that "fojl" (gives birth to everything) is the matured form of Stanza 1's "jkr" (longing) and Stanza 3's quantified "pkj HkkbZ pkj cfgusa" — the architectural skeleton becomes fuel. Stanza 6's "ik¡o tks ihNs gVkrk" (threshold swallowing the lane) prefigures this: the protagonist *is* the threshold where past enters and self exits. The arc traces: displaced subject → architectural rememberer → parental judge/supplicant → threshold-dweller → self-authorizing creator. The poem thus characterizes the protagonist as an artist of memory: they do not recover the lost house; they burn it to forge a self that declares, "I am right in my own eyes."

## COMPETENCY_QUESTION_1
QUESTION: A Class 11 student writes this answer to "How is the protagonist characterized in 'Ghar Ki Yaad'?": "The protagonist is the poet himself. He misses his home and parents. He describes the house with four walls and four doors. He says his father had no virtues. In the end he says he is right and home is the burning. This shows he loves his home." Identify THREE specific analytical weaknesses in this answer and rewrite it as a Level 5 (excellent) board exam response using PEEL structure.

COMPETENCY: Critical evaluation of peer response and analytical writing improvement

STEPS:
- Step 1: Identify Weakness 1 — Conflates poet and protagonist ("protagonist is the poet himself") without recognizing the constructed persona.
- Step 2: Identify Weakness 2 — Lists details (4 walls, father's virtues) without interpreting what they *reveal* about the speaker's psychology.
- Step 3: Identify Weakness 3 — Treats the final declaration as summary ("shows he loves his home") instead of analyzing its redefinition of "home" as "burning/longing."
- Step 4: Rewrite using PEEL with distributed evidence — Point: The protagonist constructs identity through selective, contradictory memory. Evidence: Stanza 1's "jkr Hkj fxjrk" + Stanza 3's "pkj HkkbZ" + Stanza 4's "firk th... {k.k Hkh ugha" + Stanza 7's "eSa e"ks esa lgh". Explanation: Each memory-choice reveals a speaker who measures loss geometrically, judges parents unsentimentally, yet claims self-authority from that very judgment. Link: The protagonist is not a nostalgic lover of home but an architect of selfhood who uses memory's "cl" as creative fire.
- Step 5: Polish for exam register — Use terms like "poetic persona," "epistemic sovereignty," "generative paradox," "retrospective recharacterization."

ANSWER:
**Weaknesses:** (1) Author-persona conflation — "protagonist is the poet" ignores the literary construction of the speaker. (2) Descriptive listing — details (4 walls, father's flaws) are cited without psychological inference. (3) Reductive closure — final stanza read as "loves home" instead of "redefines home as the burning of longing."

**Level 5 Rewrite:**
The poetic persona in "Ghar Ki Yaad" constructs identity through a paradoxical memory that simultaneously preserves and incinerates the past. In Stanza 1, the speaker defines themselves through absence — "vkt ikuh fxj jgk gS / jkr Hkj fxjrk jgk gS" — establishing displacement as their ground zero. Stanza 3's geometric reduction — "pkj HkkbZ pkj cfgusa" — reveals a mind that quantifies grief into countable units, avoiding raw affect. Stanza 4's unsentimental judgment — "firk th ftudks cq<+kik / ,d {k.k Hkh ugha O;kik" — shows the protagonist claiming moral authority over the very figure who "raised" them. These choices culminate in Stanza 7's epistemic sovereignty: "eSa e"ks esa gw¡ lgh gS / ?kj ugha gw¡ cl ;gh gS / blh cl ls lc fojl gS." The protagonist does not recover home; they transmute longing ("jkr") into creative fire ("cl") that *generates* selfhood. The character is thus an ars poetica: the poem demonstrates that identity is forged not in return but in the burning that makes return unnecessary.

DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: "In lyric poetry, the protagonist is less a person than a pattern of pronouns and metaphors." Apply this statement to "Ghar Ki Yaad" by analyzing how the protagonist's character emerges from (a) the grammar of self-reference (pronouns, verb forms) and (b) the metaphorical cluster of "cl" (burning/fire) across the poem. Write a 150-word analytical response.

COMPETENCY: Linguistic-stylistic analysis of poetic characterization

STEPS:
- Step 1: Map the pronoun grammar — Count "main" (explicit), "mujh/mujhe" (object), "mere" (possessive), and implicit subject in verb endings ("jgk gS", "fxjrk jgk gS", "cq<+kik", "O;kik"). Note the shift from experiential ("fxjrk" — I have been staying) to agentive ("cq<+kik" — raised me, but *I* evaluate) to declarative ("gw¡ lgh gS" — am right).
- Step 2: Trace the "cl" metaphor cluster — Stanza 1: implied in "jkr" (longing as internal heat). Stanza 6: "cksy esa ckny xjtrk / dke esa >a>k yjtrk" (burning in jealousy, burning in work). Stanza 7: explicit "cl ;gh gS / blh cl ls lc fojl gS." The metaphor evolves from sensation → description → ontological claim.
- Step 3: Synthesize — The protagonist *is* the trajectory from "main fxjrk" (I remain/stay) to "main gw¡ lgh" (I am right) — a grammatical journey from passive endurance to active self-definition, mirrored by "cl" moving from latent heat to generative principle.
- Step 4: Draft 150-word response integrating (a) and (b) — The protagonist emerges not as a biography but as a pronominal trajectory: from the experiential "main fxjrk" (Stanza 1) through the evaluative "firk th... cq<+kik" (Stanza 4) to the declarative "main gw¡ lgh" (Stanza 7). Verb forms shift from stative ("jgk gS") to perfective ("cq<+kik") to present-assertive ("gw¡ lgh gS"), marking a subject gaining agency through speech. Simultaneously, the "cl" cluster — latent in "jkr Hkj" (longing-filled heart), explicit in "cksy esa ckny" (burning in jealousy), culminating in "cl ;gh gS / blh cl ls lc fojl gS" — maps this agency onto a generative metaphysics: the protagonist *becomes* the fire that burns the past to birth the self. Character here is not essence but enactment — a pattern of pronouns claiming authority and metaphors transmuting absence into creation. The "I" that begins in displacement ends as the standard of its own truth; the "burning" that begins as ache ends as ontology.
- Step 5: Verify word count and analytical density — ~145 words, integrates grammar and metaphor, uses terminology (stative, perfective, ontological, generative).

REASONING: This competency question tests the senior-secondary skill of stylistic analysis — reading character through linguistic form rather than content summary. It combines grammatical knowledge (verb aspects, pronoun cases) with metaphor theory, mirroring the interdisciplinary rigor of CBSE's new competency-based questions. The 5-step process ensures students don't just list devices but show how they *constitute* character.

ANSWER:
The protagonist emerges not as a biography but as a pronominal trajectory: from the experiential "main fxjrk" (Stanza 1) through the evaluative "firk th... cq<+kik" (Stanza 4) to the declarative "main gw¡ lgh" (Stanza 7). Verb forms shift from stative ("jgk gS") to perfective ("cq<+kik") to present-assertive ("gw¡ lgh gS"), marking a subject gaining agency through speech. Simultaneously, the "cl" cluster — latent in "jkr Hkj" (longing-filled heart), explicit in "cksy esa ckny" (burning in jealousy), culminating in "cl ;gh gS / blh cl ls lc fojl gS" — maps this agency onto a generative metaphysics: the protagonist *becomes* the fire that burns the past to birth the self. Character here is not essence but enactment — a pattern of pronouns claiming authority and metaphors transmuting absence into creation. The "I" that begins in displacement ends as the standard of its own truth; the "burning" that begins as ache ends as ontology.

DIFFICULTY: hard