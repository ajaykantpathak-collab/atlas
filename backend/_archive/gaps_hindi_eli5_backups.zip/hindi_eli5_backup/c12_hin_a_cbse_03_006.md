## DEFINITION
The primary theme of a literary work is its central, unifying idea or insight about life/human nature that the author conveys through the narrative/poetic elements; the message is the specific moral, lesson, or appeal the author intends the reader to take away. In poetry, the primary theme emerges from the interplay of recurring images, refrains, tone, and the speaker's attitude toward the subject.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student can independently identify the primary theme of both poems in Chapter 3, cite specific textual evidence (images, refrains, key lines) to support the interpretation, and articulate the poet's intended message about childhood innocence and society's responsibility toward it in a structured board-exam answer (Point-Evidence-Explanation-Link format).

## SCOPE_BOUNDARY
This node covers ONLY the primary theme and core message of the two poems in Chapter 3 ("नहीं वोस्यक" and "मैंने देखा, एक चाँद" by वकील). It does NOT cover secondary themes (node 007), literary devices (nodes 008-009), vocabulary (node 010), or comprehension questions (node 012). It assumes familiarity with plot/narrative (node 002), setting (node 003), and character analysis (nodes 004-005).

## WALKTHROUGH
Imagine you're explaining to a younger sibling why the poet keeps repeating "नहीं वोस्यक लुस्ग हकक गस xoZ Hkjk enekrk" — what is the ONE big idea he won't let go of? Start by reading both poems aloud, noticing the recurring image of the child (नहीं) and the moon (चाँद). Mark every stanza where the poet directly addresses society ("iafDr", "लोक", "जगत"). Ask: "What does the poet want us to DO with this child?" The answer to that question — the appeal to protect innocence — is the primary theme. The message is the urgent call to action embedded in that appeal. Connect the moon-imagery in the second poem to the "नहीं" of the first: both symbolize a purity that the adult world threatens.

## DIAGNOSTIC_QUESTION_1
What is the difference between the 'subject' of a poem and its 'primary theme'? Give a one-sentence distinction.

## DIAGNOSTIC_ANSWER_1
The subject is the topic (e.g., "a child" or "the moon"); the primary theme is the poet's insight about that topic (e.g., "childhood innocence is a fragile treasure that society must actively protect"). A wrong answer that equates the two (e.g., "The theme is the child") reveals the student cannot distinguish topic from thematic statement — a fundamental error that leads to vague, plot-summary answers in board exams.

## DIAGNOSTIC_QUESTION_2
In "नहीं वोस्यक", the refrain "ij bldks Hkh iafDr dks ns nks" appears four times. Explain in your own words what the poet is asking of 'iafDr' (life/world) and why he repeats this exact line instead of varying the wording.

## DIAGNOSTIC_ANSWER_2
The poet demands that life/the world accept and make space for the innocent child ("नहीं") just as it accepts others. The repetition mimics a plea or mantra, emphasizing urgency and the child's persistent right to belong. A wrong answer that says "the poet repeats it for rhythm" or "to show the child is small" misses the rhetorical function: repetition here is a demand for justice, not decoration. This confusion between structural device and thematic purpose costs marks in 'effect of refrain' questions.

## DIAGNOSTIC_QUESTION_3
APPLY: The second poem ends with "lwus fojkV~ osQ lEeq[k gj vkyksd&Nqvk viukiu gS mUekspu u'ojrk osQ nkx ls!" Using the primary theme you identified, explain how the image of the moon's smile (चाँद की मुस्कान) functions as evidence for that theme. Write a 3-sentence PEE (Point-Evidence-Explanation) paragraph.

## DIAGNOSTIC_ANSWER_3
Point: The moon's smile embodies the pure, uncorrupted joy that the theme identifies as needing protection. Evidence: The lines describe the smile as rising from "u'ojrk osQ nkx" (the peak of wonder) and causing "mUekspu" (intoxication/absorption) in the observer. Explanation: Unlike adult smiles tinged with calculation, this smile is spontaneous and transformative, proving the child's innocence has redemptive power — which is exactly why the poet demands society preserve it. A weak answer describes the moon's beauty without linking it to the theme of societal responsibility.

## DIAGNOSTIC_QUESTION_4
ANALYZE: Compare the tone of the speaker in the first three stanzas of "नहीं वोस्यक" (questioning, wondering) with the tone in the last two stanzas (declarative, demanding). How does this tonal shift reinforce the primary theme?

## DIAGNOSTIC_ANSWER_4
The opening stanzas use rhetorical questions ("xhr ftUgsa fiQj vkSj dkSu xk,xk", "eksrh lPps fiQj dkSu Ñrh yk,xk") to establish the child's mysterious, almost sacred origin — positioning innocence as a gift. The closing stanzas shift to imperative statements ("bldks HkfDr dks ns nks", "fpj&v[kaM viukik") asserting the child's right to exist fully in the world. This movement from awe to advocacy mirrors the theme: recognizing innocence's value (awe) compels active protection (advocacy). An answer that only lists tones without explaining the thematic progression fails the 'analyze' requirement.

## DIAGNOSTIC_QUESTION_5
EVALUATE: A student claims: "The primary theme of both poems is simply 'children are cute'." Critique this interpretation using specific textual evidence from both poems. Is this a valid reading? Why/why not?

## DIAGNOSTIC_ANSWER_5
Invalid. "Children are cute" reduces a complex thematic argument to a superficial observation. Evidence against: In Poem 1, the child is described as "izÑr" (transcendent), "Lo;ाHkw" (self-illumined), "czã" (pure) — metaphysical qualities far beyond cuteness. The poet warns society that rejecting this child leads to "jk"Vª e"kcwr" (national decline). In Poem 2, the child's smile induces "mUekspu" (deep absorption) and comes from "u'ojrk" (wonder), suggesting spiritual nourishment. The theme is the *necessity* of innocence for human/societal health, not its adorability. This misconception leads to answers that miss the poem's socio-philosophical dimension — a common Board exam trap.

## DIAGNOSTIC_QUESTION_6
CREATE: Write a new fourth stanza for "नहीं वोस्यक" that maintains the refrain "ij bldks Hkh iafDr dks ns nks" but introduces a specific modern threat to childhood innocence (e.g., screens, competition, pollution) that the poet Vakeel might have addressed today. Keep the meter and rhyme scheme consistent with the original.

## DIAGNOSTIC_ANSWER_6
Example stanza:
"यह स्क्रीन की चमक, यह दौड़ अंधी,
यह धुएँ का पहाड़, यह जिंदगी बेढब।
नहीं वोस्यक लुस्ग हकक गस xoZ Hkjk enekrk,
ij bldks Hkh iafDr dks ns nks।"
A strong answer mirrors the original's contrast between the child's purity and the world's corruption, uses the same refrain placement, and introduces a concrete contemporary threat. A weak answer writes a generic moralistic stanza without the poem's rhythmic drive or the specific "child vs. world" tension.

## COMMON_MISCONCEPTION
Students often confuse the *primary theme* with the *most repeated word or image*. Because "नहीं" (the child) and "चाँद" (moon) appear frequently, they write "The theme is the child/moon." This is a category error: a noun phrase cannot be a theme. A theme must be a complete declarative sentence expressing an insight (e.g., "Society's survival depends on protecting the innate purity of children"). This mistake stems from primary-school training where 'theme = topic'. In Class 12 Board/Competitive exams, such answers receive zero credit for thematic analysis because they demonstrate no interpretive thinking.

## ON_FAILURE
1. Have the student re-read both poems and write one complete sentence starting with "The poet believes that..." for each poem. 2. Compare the two sentences; synthesize into a single statement covering both. 3. Verify: Does the statement explain WHY the poet repeats the refrain? Does it account for the moon imagery? If not, revise. 4. Practice converting the final statement into a PEE answer using one piece of evidence from each poem. Revisit node c12_hin_a_cbse_03_002 (Plot/Narrative) to ensure the sequence of ideas in the poems is clear.

## BUILDS_ON
Class 11 skill of moving from subject to theme statement (c11_hin_ar_cbse_01_006) and identifying refrain function (c11_hin_ar_cbse_01_008).

## LEADS_TO
Secondary themes (node 007) which explore nuances like the mother-child bond, nature imagery, and the poet's self-reflection — all branching from the primary theme established here.

## PREREQUISITE_NODE_IDS
c12_hin_a_cbse_03_001, c12_hin_a_cbse_03_002, c12_hin_a_cbse_03_003, c12_hin_a_cbse_03_004, c12_hin_a_cbse_03_005, c11_hin_ar_cbse_01_006, c11_hin_ar_cbse_02_006, c11_hin_ar_cbse_03_006, c11_hin_ar_cbse_01_008

## PREREQUISITE_REASONS
c12_hin_a_cbse_03_001: Provides biographical/historical context (Vakeel's life, freedom struggle) essential to grasp the poet's societal concern.
c12_hin_a_cbse_03_002: Establishes the narrative flow of each poem — the movement from description to appeal — which structures the thematic argument.
c12_hin_a_cbse_03_003: Clarifies the atmosphere (innocence vs. corruption) that the theme operates within.
c12_hin_a_cbse_03_004: The protagonist "नहीं" is the embodiment of the theme; understanding his portrayal is prerequisite.
c12_hin_a_cbse_03_005: Supporting figures (mother, wind, society) represent forces the theme negotiates with.
c11_hin_ar_cbse_01_006: Class 11 foundation for distinguishing subject vs. theme and writing thematic statements.
c11_hin_ar_cbse_02_006: Practice with refrain-as-thematic-anchor in a different poem.
c11_hin_ar_cbse_03_006: Exposure to child-centered themes in Class 11 (e.g., Nirala's poems) builds comparative context.
c11_hin_ar_cbse_01_008: Class 11 skill of moving from subject to theme statement (c11_hin_ar_cbse_01_006) and identifying refrain function (c11_hin_ar_cbse_01_008).  

## FORWARD_NODE_IDS
c12_hin_a_cbse_03_007, c12_hin_a_cbse_03_008, c12_hin_a_cbse_03_009, c12_hin_a_cbse_03_013, c12_hin_a_cbse_03_012, c12_hin_a_cbse_03_014, c12_hin_a_cbse_03_015

## FORWARD_REASONS
c12_hin_a_cbse_03_007: Secondary themes (motherhood, nature, self) are sub-branches of the primary theme established here.
c12_hin_a_cbse_03_008: Imagery/metaphor analysis (moon, wind, screen) serves as evidence for the primary theme.
c12_hin_a_cbse_03_009: Irony/symbolism (child as savior, society as threat) deepens the thematic reading.
c12_hin_a_cbse_03_013: Critical thinking questions require a firm primary theme as the anchor for all interpretation.
c12_hin_a_cbse_03_012: Primary theme guides thematic inferences  
c12_hin_a_cbse_03_014: Primary theme is the "Link" destination in every PEEL paragraph.  
c12_hin_a_cbse_03_015: अगला तार्किक चरण: Speaking and Listening: इस नोड की अवधारणाओं को सीधे उपयोग/विस्तारित करता है।  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
No cross-subject Hindi nodes exist in the provided prior-class list; thematic analysis of childhood innocence connects to Class 12 Sociology/Psychology but those nodes are not in the given data.

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_01_006 -> c12_hin_a_cbse_03_006 -> c12_hin_a_cbse_03_007

## THIS_FORMULA
N/A - conceptual

## FORMULA_VARIABLES
N/A

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
conceptual

## CROSS_SUBJECT
N/A | The poem's warning that rejecting the child leads to "jk"Vª e"kcwr" (national decline) mirrors sociological theories on intergenerational transmission of values and social cohesion.
 N/A | The depiction of the child's "u'ojrk" (wonder) and "mUekspu" (absorption) aligns with developmental psychology's emphasis on innate curiosity and flow states in early childhood.
## PREREQ_CONCEPT
Ability to synthesize a thematic statement from recurring images, refrains, and tonal shifts — not just identify topics.

## PREREQ_BEFORE
Student must know how to annotate a poem for repeated phrases, shifts in address (question → command), and symbolic imagery (moon, wind, screen).

## PREREQ_STUCK
If stuck, review "How to write a theme statement" from Class 11 (c11_hin_ar_cbse_01_006) and practice on a simple poem like "बचपन" (Bachpan) before returning.

## WORKED_EXAMPLE_1
PROBLEM: Using only the first poem "नहीं वोस्यक", derive the primary theme in a single sentence and support it with three pieces of evidence from different stanzas.
STEPS:
- Step 1: List the recurring elements: the refrain "ij bldks Hkh iafDr dks ns nks", the epithets for the child (लुस्ग, xoZ, enekrk, xhr, eksrh, लफेक्क, वफ}rh;, एक्क, xksjl, vaoqQj, izÑr, Lo;ाHkw, czã, v;qr%), and the shift from questions to commands.
- Step 2: Group the epithets: they move from physical innocence (लुस्ग, xoZ) to metaphysical purity (izÑr, Lo;ाHkw, czã) to social identity (xksjl = new, vaoqQj = unique). This progression shows the child as a complete, sacred being.
- Step 3: Note the addressee shifts: stanzas 1-3 address the child ("तू", "यह") in wonder; stanzas 4-5 address society/life ("iafDr", "लोक", "जगत") in demand. The theme lives in this pivot.
- Step 4: Synthesize: The poet presents the child as an intrinsically perfect being whose rightful place in the world is being denied; therefore, the primary theme is "Society has a moral obligation to actively include and protect the innate purity of children."
- Step 5: Select evidence: (a) Refrain repetition = urgency of obligation. (b) "izÑr, Lo;ाHkw, czã" = innate purity as given fact. (c) Final stanza's "fpj&v[kaM viukik" (crooked paths become straight) = transformative power of inclusion.
REASONING: This step-by-step mirrors the Board's expected answer structure: identify pattern → group evidence → articulate insight → quote textual support. It avoids the "topic trap" by forcing a complete sentence with a verb expressing the poet's stance.
ANSWER: Primary Theme: "Society has a moral obligation to actively include and protect the innate purity of children." Evidence: 1. Refrain "ij bldks Hkh iafDr dks ns nks" repeated four times as a demand. 2. Stanza 3 epithets "izÑr, Lo;ाHkw, czã" establish the child's transcendent purity. 3. Final stanza's claim that the child makes "fpj&v[kaM viukik" (crooked paths straight) proves inclusion benefits society itself.

## WORKED_EXAMPLE_2
PROBLEM: The second poem "मैंने देखा, एक चाँद" does not mention "नहीं" explicitly. Explain how its primary theme aligns with the first poem's, using the moon-child parallel.
STEPS:
- Step 1: Identify the central image: "cw¡n" (moon) described as "lkxj osQ >kx ls" (from the peak of the mountain) — elevated, distant, pure.
- Step 2: Analyze the action: The moon "jax xbZ {k.kHkj" (sheds its whiteness/smile) "<yrs lwjt dh vkx ls" (from the touch of shy breeze). The smile is spontaneous, triggered by nature, not performance.
- Step 3: Analyze the effect on speaker: "lwus fojkV~ osQ lEeq[k gj vkyksd&Nqvk viukiu gS mUekspu u'ojrk osQ nkx ls" — the vast sky's smile intoxicates the observer with wonder. The child's innocence transforms the adult viewer.
- Step 4: Connect to Poem 1: In Poem 1, the child "नहीं" is the agent of transformation ("fpj&v[kaM viukik"). In Poem 2, the moon-child's smile is the catalyst. Both poems argue that childlike purity has redemptive power for the corrupted adult world.
- Step 5: Formulate aligned theme: "The unmediated innocence of the child (whether called 'नहीं' or symbolized by the moon) possesses a transformative, healing power that the adult world desperately needs and must therefore safeguard."
REASONING: This example teaches cross-poem synthesis — a frequent Board requirement ("Compare the theme of the two poems"). It uses the "symbol → effect → thematic function" chain, which is the analytical standard for poetry comparison.
ANSWER: Both poems share the primary theme: childhood innocence is a redemptive force that society must protect. Poem 1 states it as a demand ("give him to life"); Poem 2 demonstrates it through the speaker's experience of wonder ("mUekspu") triggered by the moon-child's spontaneous smile. The moon in Poem 2 is the poetic equivalent of "नहीं" in Poem 1 — both are figures of pure, uncorrupted being whose presence heals the observer.

## WORKED_EXAMPLE_3
PROBLEM: A Board exam question asks: "वकील की कविताओं में 'नहीं' और 'चाँद' बाल-मासूमियत के प्रतीक हैं। इस कथन की पुष्टि करते हुए बताइए कि कवि समाज से क्या अपील करता है?" Write a 100-word structured answer.
STEPS:
- Step 1: Deconstruct the prompt: (a) Confirm symbols, (b) State appeal, (c) 100 words → requires conciseness + structure.
- Step 2: Open with direct thematic statement (1 sentence): "दोनों कविताओं में 'नहीं' और 'चाँद' निष्कलुष बाल-मासूमियत के प्रतीक हैं जिनमें समाज को रूपांतरित करने की शक्ति है।"
- Step 3: Evidence from Poem 1 (2 sentences): "पहली कविता में 'नहीं' को 'लुस्ग, xoZ, enekrk' से 'izÑr, Lo;ाHkw, czã' तक वर्णित कर कवि उसकी दैवीय पवित्रता स्थापित करता है। बार-बार 'iafDr dks ns nks' कहकर वह समाज से इस मासूमियत को अपनाने की माँग करता है।"
- Step 4: Evidence from Poem 2 (2 sentences): "दूसरी कविता में 'चाँद' की सहज मुस्कान 'u'ojrk osQ nkx' से निकलकर द्रष्टा को 'mUekspu' (आत्मविस्मृति) देती है, सिद्ध करती है कि बाल-सुलभ आनंद वयस्क जगत को चंगा करता है।"
- Step 5: Synthesize the appeal (1 sentence): "अतः कवि की अपील है: समाज बाल-मासूमियत को बोझ न समझे, उसकी रक्षा करे — क्योंकि उसी में समाज का कल्याण निहित है।"
- Step 6: Word count check ≈ 95 words. Perfect.
REASONING: This models the exact PEEL (Point-Evidence-Explanation-Link) structure CBSE marking schemes reward. It balances both poems, uses technical terms (प्रतीक, रूपांतरित, आत्मविस्मृति) appropriately, and ends with the "so what" (समाज का कल्याण) — the message.
ANSWER: दोनों कविताओं में 'नहीं' और 'चाँद' निष्कलुष बाल-मासूमियत के प्रतीक हैं जिनमें समाज को रूपांतरित करने की शक्ति है। पहली कविता में 'नहीं' को 'लुस्ग, xoZ, enekrk' से 'izÑr, Lo;ाHkw, czã' तक वर्णित कर कवि उसकी दैवीय पवित्रता स्थापित करता है। बार-बार 'iafDr dks ns nks' कहकर वह समाज से इस मासूमियत को अपनाने की माँग करता है। दूसरी कविता में 'चाँद' की सहज मुस्कान 'u'ojrk osQ nkx' से निकलकर द्रष्टा को 'mUekspu' (आत्मविस्मृति) देती है, सिद्ध करती है कि बाल-सुलभ आनंद वयस्क जगत को चंगा करता है। अतः कवि की अपील है: समाज बाल-मासूमियत को बोझ न समझे, उसकी रक्षा करे — क्योंकि उसी में समाज का कल्याण निहित है।

## COMPETENCY_QUESTION_1
QUESTION: The poem "नहीं वोस्यक" uses the word "v;qr%" (ten) in the final stanza: "ftKklq] izcq¼] lnk J¼ke;] bldks HkfDr dks ns nks". Critics suggest this alludes to the ten directions (दश दिशाएँ) or the ten months of gestation. Evaluate which interpretation better supports the primary theme of societal inclusion. Justify with textual reasoning.
COMPETENCY: Critical Interpretation & Evidence-Based Argumentation
STEPS:
- Step 1: Identify the two interpretations: (A) Ten directions = universal space, everywhere. (B) Ten months = biological gestation, natural right to life.
- Step 2: Test Interpretation A against the poem's societal appeal: "ftKklq] izcq¼] lnk J¼ke;" (directions, corners, all places) + "v;qr%" (ten) → the child belongs in every direction/space. This expands "iafDr" (life/world) to the cosmos — society cannot confine the child.
- Step 3: Test Interpretation B: Gestation reference emphasizes the child's pre-birth right, but the poem addresses an already-born child ("xhr", "eksrh" as metaphors for the living child). The appeal is to *current* society, not pre-natal.
- Step 4: Check refrain context: "ij bldks Hkh iafDr dks ns nks" is about giving space *now* in the world. "दश दिशाएँ" resonates with "fpj&v[kaM viukik" (making crooked paths straight everywhere).
- Step 5: Conclude: Interpretation A (ten directions) better supports the theme because it universalizes the child's claim on the world, matching the poem's societal scope.
ANSWER: The "ten directions" (दश दिशाएँ) reading is stronger. The final stanza lists spatial expanses ("ftKklq] izcq¼] lnk J¼ke;") and demands the child be given to "HkfDr" (every direction). "v;qr%" as ten directions completes this spatial totality: the child's innocence deserves a place in the entire cosmos, not just a corner. The gestation reading, while poetically plausible, narrows the theme to a biological claim rather than the poem's socio-spatial demand for inclusion. The primary theme — society's obligation to make room for innocence — requires the universal spatial metaphor.
DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: Design a 3-question interview for the poet Vakeel that would reveal his primary theme more deeply than a standard "What is the theme?" question. For each question, explain what specific aspect of the theme it targets and why a generic question would fail to elicit that insight.
COMPETENCY: Metacognitive Question Design & Thematic Precision
STEPS:
- Step 1: Identify gaps in generic questions: "What is the theme?" invites a noun-phrase answer ("childhood"). We need questions that force the poet to articulate the *relationship* between innocence and society.
- Step 2: Question 1 (Target: The shift from wonder to demand): "आपने कविता के पहले भाग में 'नहीं' से प्रश्न पूछे हैं ('किसने चुराया चाँद?'), लेकिन अंत में समाज को आदेश दे रहे हैं — यह परिवर्तन आपके मन में कब और कैसे आया?" Targets the tonal pivot that encodes the theme.
- Step 3: Question 2 (Target: The moon-child equivalence): "दूसरी कविता में चाँद की मुस्कान 'उन्माद' लाती है, जबकि पहली में 'नहीं' 'टेढ़े रास्ते सीधे' करता है — क्या ये दोनों एक ही शक्ति के दो रूप हैं?" Forces the poet to confirm the cross-poem thematic unity.
- Step 4: Question 3 (Target: The consequence of refusal): "आप लिखते हैं कि 'नहीं' को न अपनाने से 'राष्ट्र एकाकी' होगा — क्या यह चेतावनी है या अनिवार्य सत्य? क्या समाज के पास विकल्प है?" Probes the theme's urgency and the poet's view on societal agency.
- Step 5: Explain why generic fails: A generic question allows the poet to say "I write about children." These questions demand the *argument* — the "so what" and "what if" — which is the theme.
ANSWER: Interview:
1. "Your opening stanzas marvel at the child with questions ('Who stole the moon?'), but the closing stanzas command society ('Give him to life'). At what moment did wonder become demand?" → Targets the thematic pivot from recognition to responsibility.
2. "The moon's smile intoxicates with wonder; the child straightens crooked paths. Are these the same redemptive power viewed from inside (experience) and outside (effect)?" → Targets the unity of symbol and consequence across poems.
3. "You warn that rejecting the child makes the nation 'lonely' (एकाकी). Is this a prophecy or a description of the present? Can society choose otherwise?" → Targets the theme's stakes and the poet's moral realism.
Generic "What is your theme?" fails because it treats theme as a label, not an argument. These questions treat theme as a living tension the poet navigates.
DIFFICULTY: hard