## DEFINITION
Critical Thinking: Analysis and Interpretation is the advanced literary skill of deconstructing a text's explicit and implicit layers—examining how narrative choices, character arcs, symbolism, and socio-cultural context interact to produce meaning—then synthesizing an evidence-based interpretation that evaluates the author's purpose, the text's ideological stance, and its relevance to contemporary realities.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student must independently produce a 300-400 word analytical response that: (1) identifies a complex pattern or tension in the text (e.g., the protagonist's simultaneous resistance to and complicity in patriarchal structures), (2) supports the claim with 3+ specific textual evidences spanning different sections, (3) explains how literary devices (irony, symbolism, narrative voice) reinforce the interpretation, and (4) connects the analysis to broader socio-historical contexts without reducing the text to a mere social document.

## SCOPE_BOUNDARY
This node covers higher-order analysis of "vkyks&vk¡èkkfj" including: intertextual reading of the protagonist's writing journey as meta-commentary on authorship, the symbolic function of domestic spaces (kitchens, courtyards, employers' homes), the unreliable/limited perspective of first-person narration, and the text's critique of middle-class liberalism. It does NOT cover basic plot summary, character listing, or identification of isolated literary devices—those are prerequisites from nodes 002-011.

## WALKTHROUGH
Imagine you're sitting in a board exam and the question asks: "How does the protagonist's relationship with writing evolve from survival strategy to act of rebellion?" Don't start by retelling the story. Instead, ask yourself: *What are the three distinct phases of her writing life, and what specific textual moments mark each transition?* First, locate the earliest reference to writing (the diary gifted by rkrq'k). Second, trace how writing shifts from private catharsis to public assertion (the manuscript sent to publishers). Third, identify the moment she claims the title "writer" (the final pages where she reflects on vk'kkiw.kkZ nsoh). Now connect each phase to a structural element: the diary's physical constraints mirror her social confinement; the manuscript's rejection letters mirror societal gatekeeping; the final reflection's meta-fictional tone mirrors her hard-won authorial authority. The key insight: the text's form *enacts* the protagonist's liberation—her sentences grow longer, her vocabulary expands, her narrative control tightens as she gains autonomy.

## DIAGNOSTIC_QUESTION_1
Define "narrative unreliability" in first-person autobiographical fiction and give one example from "vkyks&vk¡èkkfj" where the protagonist's self-reporting contradicts textual evidence.

## DIAGNOSTIC_ANSWER_1
Narrative unreliability occurs when a first-person narrator's account is compromised by limited self-awareness, emotional bias, or intentional self-justification, creating a gap between what the narrator claims and what the text's details reveal. In "vkyks&vk¡èkkfj," the protagonist repeatedly asserts "eq>s dke osQ ckjs esa oqQN ugha tkurh" (I know nothing about work matters) while simultaneously managing complex household budgets, negotiating wages, and strategically changing employers—evidence that she possesses significant practical intelligence she disavows. A wrong answer that merely identifies her as "honest" or "simple" reveals the student confuses the narrator's *self-presentation* with the author's *characterization*, missing Chandrakanta's deliberate irony.

## DIAGNOSTIC_QUESTION_2
Explain in your own words how the recurring motif of "keys" (ckFk:e, tk¡p, dj.k) functions as a structural metaphor for the protagonist's evolving agency across the narrative.

## DIAGNOSTIC_ANSWER_2
Keys initially symbolize the protagonist's *exclusion*—she carries employers' keys but never owns a key to her own space (pages 22-23: "ckFk:e dh vlqfoèkk ugha Fkh"). Mid-narrative, keys become instruments of *negotiated access*—she duplicates keys to move between households efficiently, turning employers' property into her mobility tool. In the climax, the key metaphor inverts: she gifts rkrq'k a diary with its own lock ("fp_h dksydkrk"), claiming the power to lock/unlock her own story. A wrong answer listing key references without tracing the *progression* from passive to active agency reveals the student treats motifs as static symbols rather than dynamic structural devices that evolve with character arc.

## DIAGNOSTIC_QUESTION_3
Apply the concept of "double voicing" (Bakhtin) to analyze the scene where the protagonist teaches the employer's children to read while remaining illiterate herself (pages 24-25). Write a 4-sentence analysis identifying both voices and their tension.

## DIAGNOSTIC_ANSWER_3
The scene operates in double voice: the *dominant voice* is the employer's liberal rhetoric ("cPpksa dks i<+kbZ&fy[kkbZ dh njdkj gS") which frames education as universal right; the *subaltern voice* is the protagonist's embodied reality ("esjk i<+uk&fy[kuk Hkh ugha gks ldk") where education is a privilege extracted from her labor. The tension erupts when she performs the teacher's role—holding chalk, guiding fingers—while her own fingers remain "v[kckj" (ink-stained) from domestic work. This isn't mere irony; it's structural violence made visible: the literacy she enables for others is built on the illiteracy enforced upon her. A wrong answer that calls this "sad" or "unfair" without naming the *two competing discourses* reveals the student cannot distinguish thematic observation from discursive analysis.

## DIAGNOSTIC_QUESTION_4
Compare the protagonist's relationship with rkrq'k (the male employer who mentors her writing) and lquhy (the female employer who exploits her). Analyze how the text uses gendered power dynamics to complicate the "savior" narrative.

## DIAGNOSTIC_ANSWER_4
rkrq'k and lquhy represent two faces of patriarchal control: lquhy exercises *direct domination* through physical surveillance, wage theft, and bodily control (locking her in, monitoring bathroom use); rkrq'k exercises *benevolent paternalism* through "mentorship" that extracts intellectual labor (publishing her work under his guidance, controlling her literary access). Crucially, the text refuses to romanticize rkrq'k—his final demand that she send her son away for "better opportunities" (page 50) mirrors lquhy's family separation, revealing both men as agents of the same system. The protagonist's breakthrough comes not through either man but through *rejecting both frameworks* when she claims "esjs fy[kkoV igys eq>s dkI+kQh d"V nsrh Fkh. vc d"V nsus dh ckr rks nwj" (page 50). A wrong answer praising rkrq'k as "the good employer" reveals the student reads character intentions literally rather than analyzing structural positioning.

## DIAGNOSTIC_QUESTION_5
Evaluate the critical claim: "The protagonist's authorship at the novel's end represents genuine liberation, not co-optation." Defend or challenge using three textual evidences from the final 10 pages.

## DIAGNOSTIC_ANSWER_5
The claim is *partially defensible but incomplete*. Evidence for liberation: (1) She physically possesses her manuscript ("fp_h fy[kus dk flj&iSj eSa tkurh ugha Fkh fiQj Hkh tSls cu iM+k fy[kk"), (2) She rejects rkrq'k's editorial control ("rkrq'k us dgk] rqEgsa bu lc ckrksa dks ysdj vHkh ekFkk&iPph djus dh ”k:jr ugha gSA rqe viuk dke fd, tkvks"), (3) She frames writing as intergenerational gift ("ge nksuksa tc ,d nwljs ls feysaxs rks th&Hkjdj g¡lsaxs"). Evidence for co-optation: (1) Her publication depends on rkrq'k's connections ("rkrq'k osQ ikl ls ,d caèkq osQ ikl dksydkrk Hkst fn;k"), (2) The publisher's contract demands "eksM+ rd igq¡pkuk" (compromise), (3) The final image of her writing "tsBw dh ftruh fpf_;k¡ vkrha mruh esjh bPNk gksrh" suggests her labor still fuels male creativity. The synthesis: liberation is *contested and conditional*, not absolute. A wrong answer taking a binary stance ("yes she's free" or "no she's trapped") reveals the student cannot hold dialectical complexity—a core requirement for Class 11 critical analysis.

## DIAGNOSTIC_QUESTION_6
Create an alternative ending for the protagonist's conversation with her son (je.k nk) on page 39-40 where she *refuses* to let him go to the city. Write 6-8 lines of dialogue that maintain her voice and reveal a new dimension of her character.

## DIAGNOSTIC_ANSWER_6
A strong response captures her voice—direct, unadorned, mixing Hindi and dialect ("csch," "Bhd," "vkSj")—while showing *strategic maternal resistance* rather than passive sacrifice. Example: **"je.k nk] rqe ugha tksxk. ;g ?kj rqEgkjk gS] rqEgkjk fdjk;k gS. eSaus yxk gS rqEgkjs ckck us yM+dk [ksyrs ns[kk Fkk—eSa u gh dj ldrk. rqe yahan i<+s] fy[ks] dke djs] lekin yahan. tc rqEgkjk Lokeh vkrs gS] rks mUgsa viuk ?kj feysxh] ugha rqEgkjs cPps."** This reveals her newfound understanding that *space ownership* precedes *personal freedom*—a dimension absent in the original where she acquiesces. A weak answer that makes her suddenly articulate in standard Hindi or gives a melodramatic speech reveals the student hasn't internalized the character's linguistic register or the text's realist aesthetic.

## COMMON_MISCONCEPTION
Students conflate *critical analysis* with *theme identification*—they list "women's empowerment," "education," "exploitation" as if naming themes constitutes analysis. The specific error: treating the text as a transparent window onto social issues rather than a *constructed artifact* where form (fragmented chronology, recursive narration, meta-fictional ending) *performs* the content. For example, a student writes "The story shows domestic workers are exploited" and cites three scenes of mistreatment. This is comprehension, not analysis. Analysis would ask: *How does the narrative structure—repeated cycles of employment, departure, return—mimic the trap of migratory labor? Why does the prose style shift from fragmented sentences in early employment scenes to complex subordinate clauses in the writing scenes?* Students miss this because school assessments often reward theme-spotting over formal analysis.

## ON_FAILURE
Step 1: Give the student a single paragraph from the text (e.g., pages 27-28 where she describes the "dejs esa rhu vkyekfj;k¡"). Ask: "Count the sentences. Count the clauses per sentence. Now compare to the first paragraph on page 21. What changed?" Step 2: Have them map the *syntactic change* to the *psychological change*—shorter sentences = survival mode; complex sentences = reflective mode. Step 3: Assign a micro-task: "Rewrite the page 21 paragraph using page 28's sentence structures. What is lost? What is gained?" Step 4: Only after this formal exercise, return to the analytical question: "How does Chandrakanta use syntax to enact the protagonist's intellectual awakening?" This moves them from *what happens* to *how it is made to happen*.

## BUILDS_ON
This node synthesizes all prior chapter nodes (001-012) by requiring students to integrate plot knowledge, character understanding, thematic awareness, and device identification into coherent interpretive arguments.

## LEADS_TO
This node enables c11_hin_v_cbse_03_014 (Writing Skills) where students produce analytical essays, and c11_hin_v_cbse_03_015 (Speaking/Listening) where they defend interpretations in discussion.

## PREREQUISITE_NODE_IDS
c11_hin_v_cbse_03_002, c11_hin_v_cbse_03_004, c11_hin_v_cbse_03_006, c11_hin_v_cbse_03_008, c11_hin_v_cbse_03_009, c11_hin_v_cbse_03_012, c11_hin_v_cbse_03_001, c11_hin_v_cbse_03_003, c11_hin_v_cbse_03_005, c11_hin_v_cbse_03_007, c11_hin_v_cbse_03_011

## PREREQUISITE_REASONS
c11_hin_v_cbse_03_002: Plot and narrative structure knowledge is needed to trace non-linear chronology and recursive patterns.
c11_hin_v_cbse_03_004: Protagonist analysis provides the psychological baseline for interpreting her evolving consciousness.
c11_hin_v_cbse_03_006: Primary theme identification supplies the interpretive framework for deeper analysis.
c11_hin_v_cbse_03_008: Imagery and metaphor recognition allows analysis of symbolic patterns (keys, ink, thresholds).
c11_hin_v_cbse_03_009: Irony and symbolism understanding is essential for reading the gap between narrator's voice and author's intent.
c11_hin_v_cbse_03_012: Literal and inferential comprehension skills are the foundation for evidence-based argumentation.
c11_hin_v_cbse_03_001: "Before You Read: की समझ आवश्यक है, क्योंकि यह नोड (Critical Thinking:) इसी आधार पर आगे बढ़ता है।  
c11_hin_v_cbse_03_003: Critical interpretation requires synthesizing how setting-atmosphere-character interact across the full narrative arc — this node provides the setting-atmosphere foundation.  
c11_hin_v_cbse_03_005: Critical Thinking: Analysis and Interpretation demands comparative character analysis across the text, building directly on this node's skills.  
c11_hin_v_cbse_03_007: Critical thinking requires synthesizing primary + secondary themes into a coherent interpretive argument for board exams.  
c11_hin_v_cbse_03_011: Critical interpretation requires linguistic evidence (e.g., honorific shifts prove changing power dynamics; dialect use proves resistance).  

## FORWARD_NODE_IDS
c11_hin_v_cbse_03_014, c11_hin_v_cbse_03_015, c12_hin_a_cbse_17_013, c12_hin_al_cbse_02_013, c12_hin_v_cbse_03_013

## FORWARD_REASONS
c11_hin_v_cbse_03_014: Analytical interpretations developed here become the thesis statements and evidence base for written essays.
c11_hin_v_cbse_03_015: The dialectical reasoning practiced here (holding competing interpretations) structures seminar discussions and oral defenses.
c12_hin_a_cbse_17_013: Strengthens skill of connecting textual details to larger ideas.  
c12_hin_al_cbse_02_013: Vitan Chapter 3 — analysis of fragmented narrative.  
c12_hin_v_cbse_03_013: Class 11 critical thinking practice establishes the analytical vocabulary and habits this node deepens.  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS


## CHAIN_DESCRIPTION
c11_hin_v_cbse_03_006 -> c11_hin_v_cbse_03_013 -> c11_hin_v_cbse_03_014: Thematic understanding feeds critical analysis which feeds analytical writing.

## THIS_FORMULA
Critical Interpretation = (Textual Evidence × Literary Device Analysis) + (Socio-Historical Contextualization) - (Reductive Theme-Spotting)

## FORMULA_VARIABLES
Textual Evidence: Specific, quoted/paraphrased details from the text supporting the claim.
Literary Device Analysis: Explanation of how form (structure, style, narration, symbolism) shapes meaning.
Socio-Historical Contextualization: Connection to material conditions (caste, class, gender, labor history) without deterministic reduction.
Reductive Theme-Spotting: The error of substituting theme labels for analysis (to be minimized).

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
analytical

## CROSS_SUBJECT
c11_sociology_gender_inequality | The protagonist's negotiation of domestic work across multiple households illustrates intersectional oppression—caste (implied by "csch" address), class (migrant laborer), gender (vulnerability to sexual harassment, reproductive labor exploitation)—core to sociology's matrix of domination framework.
c11_history_women_movement | Her authorship journey parallels the historical emergence of Dalit women's autobiography (e.g., Urmila Pawar's "Aaydan," Baby Kamble's "The Prisons We Broke") where writing itself constitutes political resistance against archival silencing.
c11_civics_rights_dignity | The text dramatizes Article 21 (right to dignity) and Article 23 (prohibition of forced labor) violations in informal employment, making abstract constitutional rights concrete through narrative particularity.

## PREREQ_CONCEPT
Students must understand that literary texts are *constructed artifacts* where authorial choices (structure, diction, perspective) produce meaning—not transparent reflections of reality.

## PREREQ_BEFORE
Students must have completed literal comprehension (node 012) and thematic identification (nodes 006-007) for "vkyks&vk¡èkkfj" before attempting critical analysis.

## PREREQ_STUCK
If stuck, return to node 009 (Irony and Symbolism) and re-analyze the "keys" and "ink" motifs as dynamic, evolving symbols rather than static decorations.

## WORKED_EXAMPLE_1
PROBLEM: Analyze how Chandrakanta uses the recursive narrative structure (repeated cycles of employment → crisis → departure → new employment) to enact the protagonist's psychological condition. Write a 150-word analytical paragraph using PEEL structure.

STEPS:
- Step 1: Identify the structural pattern—locate at least 4 employment cycles in the text (lquhy's house, lkgc's house, rkrq'k's first phase, rkrq'k's second phase, final independent phase) and note the recurring elements: false promises, bodily surveillance, wage disputes, forced departure.
- Step 2: Connect structure to psychology—the repetition mirrors the "trauma loop" where the protagonist cannot integrate experience into narrative memory; each new employer initially appears as "savior" (rkrq'k: "eq>s txg Hkh ns ldrs gSa"), replicating the hope-betrayal cycle.
- Step 3: Analyze the *variation* within repetition—first cycles end in flight ("eq>s dy gh dgha vkSj ?kj <w¡<+ yw¡xh"); middle cycles end in negotiation ("eSa lkspk vc esjk Hkyk blh esa gS"); final cycle ends in *refusal to flee* ("eSa oqQN cksyrh... blosQ igys gh mlus fiQj dgk] ek] ,d dfork lqukvks u").
- Step 4: Examine the meta-structural break—the narrative itself *stops repeating* when she begins writing; the text's final pages shift from chronological recounting to reflective essay ("vc rd ftruk eSa fy[k pqdh Fkh"), formally enacting her escape from the loop.
- Step 5: Synthesize—the recursive structure is not lazy plotting but mimetic form: the novel *feels* trapped until the protagonist writes her way out, making the reader experience her confinement and liberation through reading rhythm.

REASONING: This analysis moves beyond "the story repeats" to "the repetition *performs* entrapment, and the formal break *performs* liberation"—the core move from thematic to formal analysis required at Class 11.

ANSWER: Chandrakanta's recursive employment-cycle structure (four major cycles across 36 pages) mimetically enacts the protagonist's psychological entrapment in migratory domestic labor. Each cycle—lquhy's deception, lkgc's surveillance, rkrq'k's paternalism, the final household's exploitation—repeats the hope-betrayal pattern: initial kindness ("Bhd gS, eq>s dke osQ ckjs esa oqQN irk pysxk") curdles into control ("lkgc vkdj eq>s Hkhrj ys x, vkSj lc le>k&cq>k fn;k"). Crucially, the *variations* trace her growing agency: Cycle 1 ends in silent flight ("eq>s cdrs&cdrs pyh xbZ"); Cycle 3 ends in negotiated writing time ("rkrq'k us eq>ls dgk] csch] rqe viuk dke fd, tkvks"); Cycle 4 ends in *refusal to leave* ("eSa oqQN cksyrh"). The narrative form itself transforms: early chapters use paratactic, fragmented sentences ("Ms<+ lIrkg gq, tk jgs Fks vkSj dke dgha fey ugha jgk Fkk") mimicking survival cognition; final pages deploy hypotactic, reflective prose ("vc rd ftruk eSa fy[k pqdh Fkh mls rkrq'k us I+kQksVks&dkWih djk osQ vius ,d caèkq osQ ikl dksydkrk Hkst fn;k Fkk") enacting authorial control. The structure doesn't just *describe* liberation—it *performs* it, forcing the reader to inhabit the protagonist's journey from object to subject of narrative.

## WORKED_EXAMPLE_2
PROBLEM: The text contains two distinct "writing scenes": (A) the diary gift scene (pages 27-28) and (B) the manuscript submission scene (pages 42-43). Compare how each scene uses the physical object (diary vs. manuscript) to symbolize the protagonist's relationship to authorship. Write a 200-word comparative analysis.

STEPS:
- Step 1: Isolate Scene A details—rkrq'k gifts a locked diary ("fp_h dksydkrk"), controls the key initially ("mUgksaus crk;k fd fp_h dksydkrk ls muosQ ,d caèkq us Hksth gSA"), frames writing as private therapy ("fy[kus&i<+uk rks vc gksus ls jgkA").
- Step 2: Isolate Scene B details—she prepares a manuscript independently ("isu vkSj dkWih gkFk esa fy, eSa lkspus yxh"), faces editorial gatekeeping ("Hkxoku us le>us dh {kerk gh ugha nh eq>s"), negotiates publication terms ("mlosQ igys rqEgsa viuh dgkuh dks fdlh ,d eksM+ rd igq¡pkuk gksxk").
- Step 3: Analyze the diary as *contained space*—the lock symbolizes rkrq'k's permissioned authorship; she writes *inside* his framework ("rkrq'k us lpeqp gh ,d ghjk [kkst fudkyk gS").
- Step 4: Analyze the manuscript as *circulating commodity*—the loose pages ("fdrkc&dkWih") represent writing entering public sphere; her refusal to edit for marketability ("eSa ckaXyk i<+ ldrk gw¡] fy[k ugha ldrk") asserts aesthetic autonomy.
- Step 5: Synthesize the trajectory—from writing *authorized by* patriarch (diary/key) to writing *authorized by* self (manuscript/voice), with the pivotal moment being her rejection of rkrq'k's editorial authority ("rkrq'k us dgk] og rqe ugha le>ksxh. eSaus dgk] eSa lpeqp gh oqQN ugha le>rh").

REASONING: This comparison requires tracking a single symbol (writing object) across the narrative arc, revealing how material conditions of authorship (privacy vs. publicity, gift vs. commodity, permission vs. right) map onto the protagonist's political consciousness.

ANSWER: The diary and manuscript function as material bookends of the protagonist's authorship journey. The diary (Scene A) is a *gifted, locked enclosure*—rkrq'k presents it as benevolence ("fp_h dksydkrk ls muosQ ,d caèkq us Hksth gSA") but retains epistemological control: he defines its purpose ("fy[kus&i<+uk rks vc gksus ls jgkA"), monitors its content ("rkrq'k us eq>ls cSB tkus dks dgk vkSj fiQj fp_h i<+dj lqukus yxs"), and frames her writing as therapeutic ("rqEgkjs ys[ku mRÑ"V gSA"). The lock is literal and metaphorical: her voice is permitted only within his key. The manuscript (Scene B) is a *self-produced, unbound circulation object*—she purchases paper herself ("isu vkSj dkWih gkFk esa fy, eSa lkspus yxh"), confronts institutional gatekeeping ("Hkxoku us le>us dh {kerk gh ugha nh eq>s"), and crucially *refuses* the editor's demand for compromise ("mlosQ igys rqEgsa viuh dgkuh dks fdlh ,d eksM+ rd igq¡pkuk gksxk"). Where the diary's privacy protected her, the manuscript's publicity endangers her—but she chooses publicity. The transition from "rkrq'k us lpeqp gh ,d ghjk [kkst fudkyk gS" (he defines her labor's value) to "eSa ckaXyk i<+ ldrk gw¡] fy[k ugha ldrk" (she defines her aesthetic boundaries) marks the shift from *authorized subject* to *authorizing agent*. The physical objects thus trace the political economy of authorship: from patron-dependent scribal culture to market-mediated literary autonomy.

## WORKED_EXAMPLE_3
PROBLEM: The novel's final paragraph (page 57) shifts from first-person past tense to a direct address to the reader ("rqEgkjs fy[kkoV... rqEgkjs rkrq'k... rqEgkjs tsBw"). Analyze this sudden point-of-view shift as a meta-fictional strategy. What does it achieve that a conventional ending could not? Write a 250-word analysis.

STEPS:
- Step 1: Locate the exact shift—identify the sentence where "eSa" (I) becomes "rqe" (you) addressing "rqEgkjs" (your) repeatedly: "rqEgkjs fy[kkoV igys eq>s dkI+kQh d"V nsrh Fkh... rqEgkjs rkrq'k vkSj rqEgkjs tsBw] nksuksa osQ gh lkspus&fopkjus dk dksbZ var ugha."
- Step 2: Catalog the addressees—she addresses her manuscript ("rqEgkjs fy[kkoV"), her mentor ("rqEgkjs rkrq'k"), her peer ("rqEgkjs tsBw"), and implicitly the *reader* ("rqEgsa" appears 7 times in 3 paragraphs).
- Step 3: Analyze the rhetorical effect—the shift converts the novel from *autobiography* (my story) to *manifesto* (our struggle). By addressing "rqEgkjs tsBw" (your TsBw), she universalizes her experience: every woman writer has a tsBw (the peer who validates), a rkrq'k (the patriarch who gatekeeps), a manuscript (the contested property).
- Step 4: Connect to the text's central tension—the protagonist spends 350 pages *spoken about* (by employers, neighbors, family); the final address *speaks back*, claiming the "I" that addresses "you" as equal.
- Step 5: Evaluate against conventional ending—a conventional ending would show her "success" (publication, award, recognition). This ending refuses closure: "vc viuk fy[kk Lo;a gh lqèkkj ysuk gksxk" (your writing will eventually find its own form). The open future is the point—liberation is process, not event.
- Step 6: Synthesize—the POV shift enacts the text's feminism: not "I made it" but "we are making it," turning the reader into co-conspirator.

REASONING: This analysis demonstrates the highest-order skill: reading a formal choice (POV shift) as ideological intervention. It connects micro-level syntax ("rqe" vs "eSa") to macro-level politics (individual vs. collective liberation), which is exactly what board examiners reward in "critical appreciation" questions.

ANSWER: The terminal point-of-view shift—from "eSa" (I) narrating past events to "rqe" (you) addressing present co-subjects—is Chandrakanta's most radical formal innovation. For 350 pages, the protagonist has been the *object* of others' gazes: lquhy's surveillance ("lquhy us muls dgk] lj] vkius dgk Fkk u\"), lkgc's judgment ("lkgc us eq>s Hkhrj ys x, vkSj lc le>k&cq>k fn;k"), rkrq'k's mentorship ("rkrq'k us lpeqp gh ,d ghjk [kkst fudkyk gS"). Even her writing is initially framed through rkrq'k's eyes ("rkrq'k us eq>ls dgk] csch] rqEgkjh fp_h vkbZ gSA"). The final three paragraphs shatter this objectification. By addressing "rqEgkjs fy[kkoV," "rqEgkjs rkrq'k," "rqEgkjs tsBw," she constructs a *triangulated community of women writers*—each with her manuscript, her patriarch, her peer. The shift from past tense ("fy[k pqdh Fkh") to present imperative ("fy[kks vkSj i<+ks") and future certainty ("vc viuk fy[kk Lo;a gh lqèkkj ysuk gksxk") transforms autobiography into *instruction manual for collective becoming*. A conventional ending—publication contract, literary award, public recognition—would reinforce the individualist success narrative that patriarchy co-opts. Instead, the open address ("ge nksuksa tc ,d nwljs ls feysaxs rks th&Hkjdj g¡lsaxs") refuses closure: liberation is not a destination she reaches alone but a relational practice she invites the reader into. The "you" is not generic; it is the specific woman reader who, like the protagonist, has been told "rqEgsa D;k irk ugha" (you don't know anything). The novel ends not with a period but with an outstretched hand.

## COMPETENCY_QUESTION_1
QUESTION: "Chandrakanta's 'vkyks&vk¡èkkfj' uses the protagonist's illiteracy-to-literacy trajectory not as a linear progress narrative but as a critique of the very concept of 'literacy' as defined by dominant culture." Evaluate this statement by analyzing three specific moments where the text distinguishes between *functional literacy* (reading/writing for survival) and *critical literacy* (reading/writing for resistance).

COMPETENCY: Critical evaluation of textual evidence to assess an interpretive claim

STEPS:
- Step 1: Define the two literacy types in context—functional: signing name, reading wages, following recipes; critical: analyzing power structures, producing counter-narratives, claiming authorship.
- Step 2: Identify Moment 1 (pages 24-25): Teaching employer's children—she performs functional literacy (letter recognition) while denied critical literacy (her own schooling); the gap exposes literacy as class-gated.
- Step 3: Identify Moment 2 (pages 27-28): Diary writing—initially functional (catharsis, memory aid: "fy[kus&i<+uk rks vc gksus ls jgkA"), becomes critical when she analyzes her condition ("eSaus lkspk] lpeqp eq>ls vU;k; gqvkA og FkksM+h nsj esjs psgjs dh vksj ns[krs jgs").
- Step 4: Identify Moment 3 (pages 50-51): Manuscript refusal—she rejects publisher's demand for "eksM+" (compromise), choosing critical literacy (truth-telling) over functional literacy (marketable product).
- Step 5: Synthesize—the trajectory is not illiterate→literate but *functional→critical*, and the text critiques a society that only values the former.

ANSWER: The statement is substantially correct. The text distinguishes functional literacy (instrumental, compliant) from critical literacy (analytical, resistant) at three pivotal moments. First, the tutoring scene (pp. 24-25): she teaches "v{kj" (letters) to privileged children while her own "i<+uk&fy[kuk Hkh ugha gks ldk"—functional literacy serves the employer's class reproduction; critical literacy (questioning why *she* teaches what *she* cannot learn) remains latent. Second, the diary phase (pp. 27-28): rkrq'k frames writing as "fy[kus&i<+uk rks vc gksus ls jgkA" (therapy, habit)—functional literacy as emotional regulation. But her entries evolve into social analysis: "lkspk fd bl cspkjh dks fdl vijkèk osQ ihNs viuk ?kj&ifjokj NksM+ cPpksa osQ lkFk ;gk¡ vosQys jgus dks ckè; gksuk iM+k!"—critical literacy as structural critique. Third, the publication negotiation (pp. 50-51): the publisher demands "eksM+ rd igq¡pkuk" (trim to marketable length)—functional literacy as commodity. Her refusal ("eSa ckaXyk i<+ ldrk gw¡] fy[k ugha ldrk") asserts critical literacy as *non-negotiable truth-telling*. The trajectory thus critiques a literacy regime that certifies functional competence (signing wage registers, reading recipes) while suppressing critical consciousness (analyzing exploitation, producing counter-history). The protagonist becomes "literate" not when she learns letters but when she *refuses* the functional script.

DIFFICULTY: hard

## COMPETENCY_QUESTION_2
QUESTION: The novel presents two mother figures— the protagonist (biological mother who stays) and vk'kkiw.kkZ nsoh (adoptive mother who writes). Compare their maternal practices through the lens of "strategic essentialism" (Spivak). How does each woman deploy or refuse the "mother" identity to negotiate patriarchal structures? Support with two textual evidences per figure.

COMPETENCY: Application of theoretical framework (strategic essentialism) to literary character analysis

STEPS:
- Step 1: Define strategic essentialism in this context—temporarily adopting an essentialized identity ("mother") to claim rights/space, while knowing the identity is socially constructed.
- Step 2: Analyze protagonist's motherhood—Evidence 1: She uses "cPpksa dks ysdj" (for the children) to justify staying in exploitative work (p. 23: "cPpksa dks ikyw¡xh&ikslw¡xh vkSj D;k ?kj dk fdjk;k nw¡xh!"); Evidence 2: She *refuses* the "sacrificing mother" script when she denies je.k nk's departure (p. 39: "eSa u gh dj ldrk... rqe yahan i<+s] fy[ks, dke djs"]), weaponizing motherhood for *autonomy* not sacrifice.
- Step 3: Analyze vk'kkiw.kkZ nsoh's motherhood—Evidence 1: She performs "mother" publicly to legitimize her writing (p. 43: "vk'kkiw.kkZ nsoh fnu Hkj osQ dke fucVkdj ml le; fy[kus&i<+us cSBrh Fkha tc lc yksx lks pqosQ gksrs Fks")—strategic deployment of domesticity to authorize public voice; Evidence 2: Her "u”kj pk;" (mother's kitchen) becomes literary metaphor (p. 56: "mcyrs&mcyrs dkI+kQh de jg x;k Fkk")—she *reclaims* domestic labor as creative source, not oppression.
- Step 4: Compare—protagonist uses motherhood to *resist* structural violence (staying put); vk'kkiw.kkZ nsoh uses motherhood to *access* public sphere (writing). Both are strategic; neither is "natural."
- Step 5: Conclude—the text shows "mother" as a tactical position, not an essence, enabling different survival strategies for different class positions.

ANSWER: Both women practice strategic essentialism—tactically inhabiting "motherhood" to navigate patriarchy—but from divergent class positions yielding different strategies. The protagonist (migrant domestic worker) deploys motherhood as *shield*: she endures lquhy's abuse ("cPpksa dks ikyw¡xh&ikslw¡xh vkSj D;k ?kj dk fdjk;k nw¡xh!") and lkgc's surveillance because "cPpksa dks ysdj vc eSa dgk¡ tkmQ¡!" (p. 23). Yet she *refuses* the script of infinite sacrifice when je.k nk's city job threatens family rupture: "eSa u gh dj ldrk... rqe yahan i<+s] fy[ks, dke djs" (p. 39). Here motherhood becomes *boundary-drawing*—she claims the right to define her children's futures, not just serve them. vk'kkiw.kkZ nsoh (established writer, middle-class) deploys motherhood as *passport*: she writes "fnu Hkj osQ dke fucVkdj" (after finishing daily chores) when "lc yksx lks pqosQ gksrs Fks" (p. 43)—performing domesticity to legitimize her public authorship in a society that doubts women writers. Her "u”kj pk;" (mother's kitchen) transforms from site of oppression to "mcyrs&mcyrs dkI+kQh de" (delicate utensils clinking)—a poetic revaluation of reproductive labor (p. 56). The protagonist uses motherhood to *stop* exploitation; vk'kkiw.kkZ nsoh uses it to *start* authorship. Neither treats motherhood as biological destiny; both wield it as political instrument. The text thus theorizes maternity as a *site of class-differentiated strategy*—poor mothers essentialize to survive; professional mothers essentialize to speak.

DIFFICULTY: medium