## DEFINITION
"Before You Read: Context and Background" provides the essential historical, biographical, and literary framework needed to understand the poet ?kukuan (1673–1760) and the two devotional poems (dfoÙk) prescribed in this chapter. It covers his guru-disciple relationship, his place in the Braj Bhakti tradition, his linguistic style (refined Braj mixed with folk idiom), and the central themes of guru-bhakti, longing (viraha), and spiritual dialogue that appear in the poems.

## COGNITIVE_LEVEL
understand

## MASTERY_CRITERIA
The student can explain, in their own words, how ?kukuan’s life events (exile, guru’s curse, wandering) shaped his poetic voice, identify the two poems’ core subjects (intense longing for guru; rhetorical defence of guru’s greatness), and connect these to the broader Nirgun/Sagun Bhakti synthesis in Braj literature.

## SCOPE_BOUNDARY
This node covers only the poet’s biography, historical context, language characteristics, and a high-level preview of the two poems’ themes. It does NOT include stanza-by-stanza analysis, literary device identification, vocabulary glossary, or comprehension questions — those are handled in subsequent nodes (c12_hin_a_cbse_09_002 onward).

## WALKTHROUGH
Imagine you receive a heartfelt letter written in a dialect you barely know, from a person who claims they were exiled by a king because their guru cursed them — would you understand the pain without knowing the backstory? That is exactly why we start here. First, place ?kukuan in 18th-century Delhi/Braj region and note his dual identity as a court poet turned wandering mendicant. Second, trace the guru-disciple bond with Latu (lqtku) that defines his entire oeuvre: the king’s anger, the guru’s curse, and the poet’s lifelong use of the guru’s name as a poetic signature. Third, observe his language — a deliberate blend of polished Braj (cztHkk"kk) and raw folk speech (dks eèkqjrk) — which makes his guru-bhakti both literary and accessible. Fourth, preview the two poems: Poem 1 is a viraha-padye (longing verse) where the speaker counts sleepless nights; Poem 2 is a samvad (dialogue) challenging anyone to measure the guru’s greatness. Finally, connect this to the Bhakti movement’s shift from temple ritual to personal, emotional surrender — the key insight that unlocks every subsequent analysis in this chapter.

## DIAGNOSTIC_QUESTION_1
Who was ?kukuan’s guru, and what pivotal event altered the poet’s life trajectory?

## DIAGNOSTIC_ANSWER_1
?kukuan’s guru was Latu (lqtku). Because of his close relationship with Latu, ?kukuan gained a place in the king’s court (ckn'kkg), but the king later became angry and exiled him; simultaneously, Latu cursed him, forcing ?kukuan to wander as a mendicant (HkDr) — this dual rejection (court and guru) became the emotional core of his poetry. A wrong answer (e.g., naming Kabir or Tulsidas as guru, or missing the exile/curse) reveals the student has not grasped the biographical catalyst that distinguishes ?kukuan from other Bhakti poets.

## DIAGNOSTIC_QUESTION_2
Explain why ?kukuan is described as "lk{kkr jlewfrZ" (intense emotional poet) and how his language reflects this intensity.

## DIAGNOSTIC_ANSWER_2
?kukuan earners the label "lk{kkr jlewfrZ" because his verses fuse raw emotional states — love (xaHkhj), curiosity (fueZy), playfulness (vkosxe;), and peace-giving devotion (O;koqQy) — into a single poetic voice. His language (Hkk"kk) is deliberately dual: it uses refined Braj (cztHkk"kk) for literary craftsmanship (dkO;Hkk"kk) while retaining folk simplicity (dks eèkqjrk) so ordinary listeners feel the guru’s presence directly. A wrong answer that only mentions "Braj language" or only "emotion" misses the deliberate synthesis that makes his work both artistically sophisticated and popularly accessible — a key Board exam point.

## DIAGNOSTIC_QUESTION_3
The first poem begins "cgqr fnuku dks vofèk vklikl ijs..." — without quoting the poem, describe the speaker’s situation and the poetic device used to convey the passage of time.

## DIAGNOSTIC_ANSWER_3
The speaker has spent countless nights (cgqr fnuku) awake, watching the path (vklikl ijs) for the guru’s arrival, while days pass in repetitive, fruitless waiting. The poet uses anaphora-like repetition ("dfg dfg", "xfg xfg") to mimic the monotonous, cyclical dragging of time — each couplet mirrors another sleepless night. A student who merely translates the lines without identifying the structural repetition (dfg dfg / xfg xfg) as a time-dilation device fails to apply the "form mirrors content" principle tested in both Board and CUET questions.

## DIAGNOSTIC_QUESTION_4
Compare the emotional tone of Poem 1 (viraha/longing) with Poem 2 (samvad/challenge). What does this shift reveal about ?kukuan’s conception of guru-bhakti?

## DIAGNOSTIC_ANSWER_4
Poem 1 is inward, private, soaked in separation-pain (viraha) — the devotee counts nights alone. Poem 2 turns outward, public, rhetorical — the devotee challenges the world ("vkukdkuh vkjlh fugkfjcks djkSxs dkSykSa") to find a flaw in the guru. Together they show guru-bhakti as both intimate surrender and unshakeable public conviction: the same poet who weeps in private will defend the guru’s greatness in the marketplace. A student who treats the poems as unrelated "two separate pieces" misses the dialectic structure ?kukuan builds across his corpus — a common Board exam trap.

## DIAGNOSTIC_QUESTION_5
Evaluate the claim: "?kukuan’s use of folk dialects (e.g., 'owQdHkjh', 'cgjk;cs') weakens his literary status compared to poets who use pure Braj." Defend your judgment with evidence from the poet’s described style.

## DIAGNOSTIC_ANSWER_5
The claim is false. The NCERT explicitly states ?kukuan’s language is "ifj"o`Qr vkSj lkfgfR;d cztHkk"kk" (refined and folk Braj) and that he is "cztHkk"kk izoh.k gh ugha ltZukRed dkO;Hkk"kk osQ iz.ksrk Hkh Fks" — not merely a folk poet but a conscious literary craftsman who *chooses* folk words (owQdHkjh = harsh speech, cgjk;cs = deaf to reason) for expressive precision. His "dks eèkqjrk dk pje fodkl" shows simplicity evolving into complexity, not lack of skill. A student who equates dialect with inferiority reveals a colonial-era bias that Board examiners explicitly penalize; competitive exams (CUET, JEE language sections) test this exact sociolinguistic awareness.

## DIAGNOSTIC_QUESTION_6
Write a 4-line stanza in Hindi (Braj-influenced) that mimics ?kukuan’s technique: use repetition to show time dragging, and address the guru directly with a term of endearment.

## DIAGNOSTIC_ANSWER_6
Example (student’s original lines):
"rain rain beet gayi sakhi, nahin aaye mere guru raja,
din din takat rahi akhiya, thak gayi ab meri ankh raja."
Criteria: (1) repetition of time-unit (rain/din), (2) direct address to guru (guru raja), (3) Braj-flavored vocabulary (sakhi, akhiya). A poor answer uses modern Khari Boli without repetition or direct address, showing the student cannot internalize the poet’s structural and tonal choices — a gap that hurts creative-writing tasks in Board Section C.

## COMMON_MISCONCEPTION
Students often confuse ?kukuan with the more famous "Kabir" or "Surdas" because all three are Bhakti-era, use Braj, and write guru-bhakti. They then attribute Kabir’s nirgun abstraction or Surdas’s Krishna-leela narratives to ?kukuan. The specific error: writing in exams that "?kukuan nirgun brahm ka kavi hai" or "?kukuan ne Krishna ki leela gai hai." Why it happens: textbooks group Bhakti poets together, and students memorize labels without differentiating *personal* guru-bhakti (human guru, historical relationship) from *deity* bhakti (Krishna/Ram) or *formless* bhakti (nirgun). ?kukuan’s guru Latu was a historical person; the poet’s exile and curse are biographical facts, not mythological tropes — this distinction is the single most frequent Board marking-scheme differentiator.

## ON_FAILURE
Step 1: Re-read the NCERT introductory paragraph (before the poems) and underline every biographical fact (dates, guru’s name, king’s court, exile, curse, mendicant life). Step 2: Create a two-column table: left column = life event, right column = poetic consequence (e.g., exile → wandering imagery; curse → guru’s name as refrain). Step 3: Watch a 5-minute YouTube lecture on "Braj Bhakti poets: ?kukuan" (search exactly) to hear the dialect pronunciation. Step 4: Re-attempt Diagnostic Questions 1 and 4; if still incorrect, revisit Class 11 node c11_hin_ar_cbse_09_001 (Context/Background for a Bhakti poet) and repeat the table exercise for that poet to master the method.

## BUILDS_ON
Class 11 skill of extracting biographical catalysts from introductory textbook passages (e.g., c11_hin_ar_cbse_01_001).

## LEADS_TO
Detailed stanza-wise analysis of Poem 1 and Poem 2 in c12_hin_a_cbse_09_002 (Plot/Narrative Structure) and c12_hin_a_cbse_09_003 (Setting/Atmosphere).

## PREREQUISITE_NODE_IDS
c11_hin_ar_cbse_01_001, c11_hin_ar_cbse_09_001

## PREREQUISITE_REASONS
c11_hin_ar_cbse_01_001: Teaches the "Before You Read" method — identifying poet’s era, language, major themes, and biographical triggers — which is the exact scaffold needed for ?kukuan.
c11_hin_ar_cbse_09_001: ciation. Step 4: Re-attempt Diagnostic Questions 1 and 4; if still incorrect, revisit Class 11 node c11_hin_ar_cbse_09_001 (Context/Background for a Bhakti poet) and repeat the table exercise for that poet to master the method.  

## FORWARD_NODE_IDS
c12_hin_a_cbse_09_002, c12_hin_a_cbse_09_003, c12_hin_a_cbse_09_004, c12_hin_a_cbse_09_006, c12_hin_a_cbse_09_008, c12_hin_a_cbse_09_010, c12_hin_a_cbse_09_013, c12_hin_a_cbse_09_015, c11_hin_ar_cbse_09_010

## FORWARD_REASONS
c12_hin_a_cbse_09_002: Requires knowledge of the poems’ core situations (viraha vs. samvad) to analyze narrative progression. c12_hin_a_cbse_09_003: Needs the historical setting (18th-century Braj, wandering mendicant life) to explain atmosphere in the poems.
c12_hin_a_cbse_09_004: Provides historical context (Kukuan's life, Lakshmi's identity) essential to read the protagonist as autobiographical.  
c12_hin_a_cbse_09_006: Provides the historical/biographical context (poet's exile, guru devotion) essential for grounding the theme in lived experience.  
c12_hin_a_cbse_09_008: Context/Background gives the cultural setting (Braj, 17th century, Krishna bhakti, veil customs) essential for interpreting *why* certain senses are chosen (e.g., auditory over visual due to purdah).  
c12_hin_a_cbse_09_010: अगला तार्किक चरण: Vocabulary in Context: इस नोड की अवधारणाओं को सीधे उपयोग/विस्तारित करता है।  
c12_hin_a_cbse_09_013: Context/background establishes Kabir's historical position (15th century, Bhakti, nirguna) — essential for Context step in analysis method.  
c12_hin_a_cbse_09_015: Provides historical context of Kukuan and Braj Bhasha tradition essential for framing discussion points authentically.  
c12_hin_a_cbse_09_003: Provides historical context of Kakuan and the bhakti tradition, essential to understand why the setting is rural and devotional.  
c11_hin_ar_cbse_09_010: 9_010: Class 11 Kabir vocabulary node established basic glossary usage and Braj Bhasha familiarity. c12_hin_a_cbse_09_001: Context/Background node provides the Nirguna Bhakti framework essential for theological nuances of 'iSt' and 'iR;kfu'  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
c12_history_bhakti_movement_01: Provides the socio-religious context (Nirgun/Sagun synthesis, guru-centric sects, royal patronage) that explains why a king would exile a poet over a guru’s curse. c12_geography_braj_region_01: Maps the Braj linguistic area (Mathura-Vrindavan-Delhi corridor) where ?kukuan lived, wandered, and composed — essential for understanding his dialect choices.

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_01_001 -> c12_hin_a_cbse_09_001 -> c12_hin_a_cbse_09_002

## THIS_FORMULA
N/A - conceptual

## FORMULA_VARIABLES
N/A

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
conceptual

## CROSS_SUBJECT
N/A | Explains the 18th-century Bhakti sect dynamics (guru authority, royal courts, mendicant orders) that frame ?kukuan’s life.
 N/A | Locates the Braj cultural zone where ?kukuan’s language (cztHkk"kk + dks eèkqjrk) was spoken, linking dialect to geography.
 N/A | Illuminates the power relation between king (ckn'kkg), guru (izse), and poet (dfo) — a hierarchy the poems both reflect and subvert.
## PREREQ_CONCEPT
Ability to read a textbook’s introductory note and extract: (1) poet’s dates/region, (2) key life events, (3) language classification, (4) major thematic preoccupations.

## PREREQ_BEFORE
Student must have practiced the "Before You Read" template on at least two Class 11 Antra chapters (e.g., Chapters 1 and 9).

## PREREQ_STUCK
If stuck, review the "Context and Background" section of Class 11 Chapter 1 (c11_hin_ar_cbse_01_001) and imitate its note-taking structure for ?kukuan.

## WORKED_EXAMPLE_1
PROBLEM: A Board exam question asks: "?kukuan ki kavya-bhasha ki visheshtayen likhiye." (Write the features of ?kukuan’s poetic language.) Student must produce a 4-point answer with textual evidence.

STEPS:
- Step 1: Recall the NCERT descriptor: "ifj"o`Qr vkSj lkfgfR;d cztHkk"kk" — note both adjectives.
- Step 2: Unpack "ifj"o`Qr" = refined, grammatically polished, suitable for literary composition (dkO;Hkk"kk).
- Step 3: Unpack "lkfgfR;d" = folk, colloquial, drawn from everyday speech of Braj region (dks eèkqjrk).
- Step 4: Synthesize: the poet deliberately fuses high literary register with raw folk idiom to make guru-bhakti both artistically credible and emotionally immediate.
- Step 5: Cite evidence: use of folk words like "owQdHkjh" (harsh speech) and "cgjk;cs" (deaf to reason) inside metrically regular Braj couplets.

REASONING: Board marking scheme awards 1 mark per distinct feature + 1 mark for synthesis + 1 mark for textual example. This 5-step method ensures all three mark categories are hit.

ANSWER: ?kukuan’s poetic language is (1) refined Braj (ifj"o`Qr cztHkk"kk) — grammatically polished for literary art; (2) folk Braj (lkfgfR;d cztHkk"kk) — uses colloquial words like owQdHkjh, cgjk;cs; (3) a conscious synthesis (ltZukRed dkO;Hkk"kk) where simplicity evolves into complexity; (4) this dual register makes guru-bhakti accessible to common listeners while satisfying scholarly aesthetics.

## WORKED_EXAMPLE_2
PROBLEM: A CUET-style question: "Which of the following best describes the structural relationship between the two ?kukuan poems in the textbook?" Options: (A) Both are viraha lyrics. (B) First is viraha, second is samvad defending guru. (C) Both are nirgun bhajans. (D) First is Krishna-leela, second is guru-mahima.

STEPS:
- Step 1: Identify Poem 1’s core: "cgqr fnuku dks vofèk vklikl ijs" — speaker waits countless nights → viraha (longing).
- Step 2: Identify Poem 2’s core: "vkukdkuh vkjh fugkfjcks djkSxs dkSykSa" — rhetorical challenge to detractors → samvad (dialogue/defence).
- Step 3: Eliminate (A): Poem 2 is not viraha. Eliminate (C): Nirgun bhajan implies formless god; these address a human guru. Eliminate (D): No Krishna reference.
- Step 4: Confirm (B) matches the viraha-to-samvad arc traced in the Walkthrough.
- Step 5: Select (B) and note the dialectic: private pain → public proclamation.

REASONING: Competitive exams test genre recognition (viraha vs. samvad) and the ability to map poems to sub-genres. The 5-step elimination mirrors the "assertion-reason" logic in CUET Hindi.

ANSWER: (B) First is viraha (longing), second is samvad (dialogue) defending the guru’s greatness.

## WORKED_EXAMPLE_3
PROBLEM: A 5-mark Board question: "?kukuan ke jeevan ki ghatnaon ne unki kavya-sadhna ko kaise prabhavit kiya? Do udaharan dekar samjhayein." (How did life events shape his poetry? Give two examples.)

STEPS:
- Step 1: List three key life events from NCERT: (i) guru Latu’s favour → court position, (ii) king’s anger → exile, (iii) guru’s curse → mendicant wandering.
- Step 2: Select two events with clearest poetic consequences: (ii) exile and (iii) curse.
- Step 3: Map exile → Poem 1’s setting: "vklikl ijs" (watching the path) reflects a wanderer scanning roads for the guru; "HkDr" life = no fixed abode.
- Step 4: Map curse → Poem 2’s defiance: "vkukdkuh vkjlh fugkfjcks" — the world (including the king who exiled him) is challenged to find fault in the guru who cursed him; the curse becomes a badge of honour.
- Step 5: Synthesize: biographical trauma transforms into aesthetic strategy — personal suffering becomes universal devotional template.
- Step 6: Write answer in PEEL format: Point (event), Evidence (poem line), Explanation (link), Link (back to thesis).

REASONING: Board 5-mark questions demand "do udaharan" (two examples) with explicit text-to-life mapping. This 6-step method guarantees two distinct event→poem linkages plus a synthesizing insight — the difference between 3/5 and 5/5.

ANSWER: (1) Exile forced ?kukuan into mendicant wandering (HkDr); this appears in Poem 1 where the speaker spends "cgqr fnuku" (countless nights) on the path ("vklikl ijs") waiting for the guru — the physical road mirrors the spiritual path. (2) The guru’s curse, meant as punishment, becomes the poet’s pride: Poem 2 opens with a challenge to the world ("vkukdkuh vkjlh fugkfjcks djkSxs dkSykSa") to measure the guru’s worth, turning social disgrace into devotional authority. Thus, life’s ruptures become poetry’s structure.

## COMPETENCY_QUESTION_1
QUESTION: A student writes in the Board exam: "?kukuan nirgun ke kavi the kyunki unhone guru ko nirakar mana." Identify the factual error, explain why it is wrong using NCERT evidence, and state the correct classification.

COMPETENCY: Critical textual analysis / factual accuracy

STEPS:
- Step 1: Spot the claim: "?kukuan nirgun ke kavi the" (poet of formless Brahman).
- Step 2: Check NCERT: "?kukuan ewyr% izse dh ihM+k osQ dfo gSa" — he is primarily a poet of *guru-bhakti* (personal guru), not nirgun.
- Step 3: Check guru description: "izse dk vR;ar xaHkhj... O;Dr gqvk" — guru is a concrete, lovable, playful, peace-giving *person* (Latu), not formless.
- Step 4: Formulate correction: ?kukuan is a Sagun Bhakti poet (with attributes) centred on a historical human guru; his bhakti is personal, not abstract nirgun.

ANSWER: Error: labelling ?kukuan "nirgun kavi". NCERT says he is "izse dh ihM+k osQ dfo" (poet of guru-devotion) and describes the guru with human qualities (love, curiosity, playfulness). Correct classification: Sagun Bhakti poet (guru-centric, historical guru Latu).

DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: "?kukuan ki do kavitayen pathyapustak mein di gayi hain. Pehli kavita 'viraha' ki hai, dusri 'samvad' ki. Ye dono ek hi bhakti-ke-anubhav ke do pehlu hain." Is statement sahi hai ya galat? Apne jawab ko do kavitaon ki visheshtayon se sambandhit karke spashth kijiye.

COMPETENCY: Synthesis across texts / argumentative writing

STEPS:
- Step 1: Accept the premise: two poems, two modes (viraha, samvad).
- Step 2: Define viraha in Poem 1: private, temporal (counting nights), somatic (sleeplessness), inward.
- Step 3: Define samvad in Poem 2: public, rhetorical (challenging detractors), intellectual (demanding proof), outward.
- Step 4: Argue unity: both stem from the *same* guru-bhakti — separation pain (viraha) fuels the conviction that the guru is beyond criticism (samvad). The mendicant who weeps at night (Poem 1) is the same who debates by day (Poem 2).
- Step 5: Conclude: statement is correct; the dialectic of private surrender and public defence constitutes a single, coherent devotional subjectivity.

ANSWER: Sahi hai. Pehli kavita viraha (antah, raat, intezar) hai, dusri samvad (bahir, din, bahas) hai. Dono ek hi guru-bhakti ke do anubhav hain: jo raat ko guru ke bina tadapta hai (dfg dfg vkou), wahi din ko guru ki mahima ke liye duniya ko lalkarta hai (vkukdkuh vkjlh). Viraha samvad ka aadhar hai; samvad viraha ka prakatikaran.

DIFFICULTY: hard