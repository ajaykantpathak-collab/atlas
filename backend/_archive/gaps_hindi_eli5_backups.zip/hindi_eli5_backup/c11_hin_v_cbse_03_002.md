## DEFINITION
Plot is the causal sequence of events that make up a story, structured typically as exposition, rising action, climax, falling action, and resolution. Narrative structure refers to the framework that organizes these events, including point of view (first-person, third-person), temporal arrangement (chronological, flashback), and narrative voice.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student can independently map the five stages of Freytag's Pyramid onto the story "वकील की बेटी" and explain how the first-person narrative structure shapes the reader's understanding of the protagonist's internal journey.

## SCOPE_BOUNDARY
This node covers identification and analysis of plot stages (exposition, rising action, climax, falling action, resolution) and narrative structure elements (first-person perspective, chronological flow with reflective pauses) specific to the NCERT story "वकील की बेटी". It does not cover character analysis, thematic development, or literary devices, which are addressed in subsequent nodes.

## WALKTHROUGH
Imagine you are describing a film to a friend: you don't just list scenes randomly; you shape the telling with a beginning that sets the scene, a middle where tensions build, a peak moment, and an ending that resolves things. The same applies to "वकील की बेटी". First, identify the narrator — a widowed domestic worker in a lawyer's household. Next, list the key events in the order they are narrated. Then group these events into the five plot stages. Finally, notice how the first-person voice ("मैं") and the narrator's reflective comments (e.g., while writing her own story) create a narrative structure that is both chronological and introspective. The key insight is that the plot's external events (gaining literacy, writing a story) mirror the internal narrative arc of finding her voice.

## DIAGNOSTIC_QUESTION_1
Define 'plot' and 'narrative structure' in your own words, distinguishing between the two.

## DIAGNOSTIC_ANSWER_1
Plot is the logical, causal arrangement of events (e.g., "The queen died, then the king died of grief"), while narrative structure is the technique used to present those events (e.g., first-person narration, flashbacks, chapter divisions). A wrong answer that treats them as synonyms reveals a misunderstanding of the difference between *what happens* (story/plot) and *how it is told* (narrative structure).

## DIAGNOSTIC_QUESTION_2
The story is told in first-person. Explain how this choice affects what the reader knows about the lawyer's wife (रक्रक) compared to a third-person omniscient narration.

## DIAGNOSTIC_ANSWER_2
First-person limits the reader to the narrator's observations, interpretations, and biases. We see रक्रक only through the narrator's eyes — her curiosity, encouragement, and occasional condescension. A third-person omniscient narrator could reveal रक्रक's private thoughts (e.g., her own loneliness). A wrong answer that claims first-person gives *more* access to other characters reveals confusion about narrative perspective limitations.

## DIAGNOSTIC_QUESTION_3
Identify the inciting incident in the plot of "वकील की बेटी" and state the stage of Freytag's Pyramid it belongs to.

## DIAGNOSTIC_ANSWER_3
The inciting incident is when रक्रक (the lawyer's wife) discovers the narrator's desire to read/write and actively encourages her by giving her a notebook and pen. This occurs in the **rising action** stage, as it disrupts the narrator's routine (exposition) and sets the central conflict — the struggle for self-expression — in motion. A wrong answer identifying the narrator's employment as the inciting incident confuses *exposition* (status quo) with the *inciting incident* (disruption).

## DIAGNOSTIC_QUESTION_4
Analyze how the narrative structure uses reflective pauses (e.g., the narrator commenting on her own writing process) to deepen the theme of self-discovery.

## DIAGNOSTIC_ANSWER_4
The reflective pauses — such as when the narrator describes her hesitation while writing ("मैं सोचती रही कि क्या लिखूँ") or her surprise at her own progress — break the chronological flow. They function as structural markers of her evolving self-awareness. Each pause shows the gap between her past self (illiterate, invisible) and present self (writer, visible). A wrong answer that treats these pauses as mere 'digressions' misses their structural role in mirroring the protagonist's internal climax alongside the external one.

## DIAGNOSTIC_QUESTION_5
Evaluate whether the climax of the story — the narrator reading her story to रक्रक — is effectively placed. Justify your view using plot structure principles.

## DIAGNOSTIC_ANSWER_5
Yes, it is effectively placed. The climax occurs after sustained rising action (learning to write, drafting, fear of judgment) and before the falling action (publication, recognition, रक्रक's death). It resolves the central tension: *will her voice be heard?* The immediate emotional payoff (रक्रक's tears, validation) provides the necessary turning point. A wrong answer calling it 'anti-climactic' because it lacks dramatic action fails to recognize that in a character-driven story, the climax is internal/emotional, not external/physical.

## DIAGNOSTIC_QUESTION_6
Create a brief outline (5-6 bullet points) for an alternative ending where the narrator *does not* show her writing to रक्रक. Ensure your outline follows a logical plot structure.

## DIAGNOSTIC_ANSWER_6
A strong outline would retain the five stages but alter the resolution: e.g., (1) Exposition: same; (2) Rising action: narrator writes secretly; (3) Climax: रक्रक discovers the notebook accidentally; (4) Falling action: confrontation or silent misunderstanding; (5) Resolution: narrator stops writing or leaves the house, silencing her voice. A poor outline that merely changes the last event without restructuring the climax/falling action reveals an inability to see plot as an interconnected causal chain.

## COMMON_MISCONCEPTION
Students often equate 'plot' with a simple chronological summary of *all* events (story). They miss that plot selects and arranges events causally (e.g., the narrator's husband's death is backstory, not a plot event in the present timeline). They also confuse 'narrative structure' with only 'point of view', ignoring temporal devices like the reflective pauses that function as structural flashbacks. This error stems from middle-school teaching that focuses on 'what happens next' rather than 'why this event follows that one structurally'.

## ON_FAILURE
1. **Re-teach Story vs. Plot**: Use a familiar folktale (e.g., "The Thirsty Crow"). Story = crow drops pebbles, water rises, drinks. Plot = crow is thirsty (exposition) → tries to reach water but fails (rising action) → gets idea to drop pebbles (climax) → water rises (falling action) → drinks (resolution). 2. **Timeline Activity**: Have student draw a horizontal timeline of the narrator's *life* (birth, marriage, widowhood, employment). Then draw a second timeline of the *narrated events* (starting from her arrival at the lawyer's house). The gap shows narrative selection. 3. **Color-code the Text**: Print a short excerpt. Use three colors: one for present action, one for reflection/flashback, one for dialogue. Visualizing the structural mix clarifies narrative structure. 4. **Freytag Mapping**: Provide a blank pyramid. Student places 5-6 key events from the story on it, justifying each placement in one sentence.

## BUILDS_ON
c11_hin_v_cbse_03_001 (Before You Read: Context and Background) — understanding the socio-historical reality of widows in pre-independence India frames the protagonist's initial conflict.

## LEADS_TO
c11_hin_v_cbse_03_003 (Setting and Atmosphere) — the plot's progression is inextricably tied to the domestic spaces (kitchen, verandah, study) that constitute the setting.

## PREREQUISITE_NODE_IDS
c11_hin_v_cbse_03_001
## PREREQUISITE_REASONS
c11_hin_v_cbse_03_001: Provides essential background on the author (कृष्णा सोबती), the social milieu of 1930s-40s North India, and the position of widowed women, without which the protagonist's constraints and aspirations in the plot cannot be fully understood.

## FORWARD_NODE_IDS
c11_hin_v_cbse_03_003, c11_hin_v_cbse_03_004, c11_hin_v_cbse_03_006, c11_hin_v_cbse_03_005, c11_hin_v_cbse_03_007, c11_hin_v_cbse_03_008, c11_hin_v_cbse_03_009, c11_hin_v_cbse_03_010, c11_hin_v_cbse_03_011, c11_hin_v_cbse_03_012, c11_hin_v_cbse_03_013, c11_hin_v_cbse_03_015, c12_hin_a_cbse_09_002

## FORWARD_REASONS
c11_hin_v_cbse_03_003: Plot events are anchored in specific settings (the lawyer's kitchen, the verandah where she writes); analyzing plot first allows setting analysis to explain *how* space shapes action.
c11_hin_v_cbse_03_004: The protagonist's character arc (from silent worker to confident writer) is revealed *through* the plot stages; plot analysis provides the scaffold for character analysis.
c11_hin_v_cbse_03_006: The primary theme (self-realization through literacy) emerges from the resolution of the plot; understanding the plot's climax and resolution is prerequisite for thematic interpretation.
c11_hin_v_cbse_03_005: Plot and Narrative Structure establishes the sequence of events where supporting characters enter/exit, enabling analysis of their narrative timing.  
c11_hin_v_cbse_03_007: Plot structure (episodic, non-linear) determines *where* and *how* secondary themes surface (e.g., literacy theme appears only after Krishnakant entry).  
c11_hin_v_cbse_03_008: Plot structure reveals *where* key imagery clusters appear (opening routine, crisis moments, resolution) — analysis requires locating devices in narrative sequence.  
c11_hin_v_cbse_03_009: Plot/narrative structure provides the sequence of events where ironic contradictions unfold (e.g., lawyer's shifting behavior across time).  
c11_hin_v_cbse_03_010: Plot knowledge needed to situate vocabulary in narrative sequence (e.g., "fp_h" meaning changes pre/post literacy).  
c11_hin_v_cbse_03_011: Plot/narrative structure knowledge situates grammatical shifts at specific narrative moments (e.g., tense shift when narrator begins writing).  
c11_hin_v_cbse_03_012: Plot knowledge provides the chronological framework to locate literal answers.  
c11_hin_v_cbse_03_013: Plot and narrative structure knowledge is needed to trace non-linear chronology and recursive patterns.  
c11_hin_v_cbse_03_015: कथानक और आख्यान संरचना की समझ चर्चा में घटनाक्रम को तार्किक क्रम में रखने के लिए ज़रूरी है।  
c12_hin_a_cbse_09_002: Vitan chapter 3 narrative structure practice.  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
none

## CHAIN_DESCRIPTION
c11_hin_v_cbse_03_001 -> c11_hin_v_cbse_03_002 -> c11_hin_v_cbse_03_003

## THIS_FORMULA
N/A - conceptual

## FORMULA_VARIABLES
N/A

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
analytical

## CROSS_SUBJECT
c11_history_womens_social_reform | The protagonist's journey from domestic invisibility to literary voice mirrors the historical trajectory of women's education and widow remarriage debates in colonial India, linking plot analysis to historical agency.
c11_sociology_gender_division_of_labor | The narrative structure highlights the gendered nature of domestic work (cooking, cleaning, childcare) as the protagonist's initial 'plot role', enabling sociological analysis of how labor defines identity.

## PREREQ_CONCEPT
Basic understanding of story elements (character, setting, conflict) and the ability to write a coherent summary in Hindi.

## PREREQ_BEFORE
Student must be able to orally summarize the story "वकील की बेटी" in 5-6 sentences covering the beginning, middle, and end.

## PREREQ_STUCK
If unable to summarize, revisit the 'Before You Read' node (c11_hin_v_cbse_03_001) and re-read the story focusing only on the narrator's actions, not descriptions.

## WORKED_EXAMPLE_1
PROBLEM: Map the five stages of Freytag's Pyramid onto the story "वकील की बेटी" using specific textual events.

STEPS:
- Step 1: List the major narrated events in chronological order: (a) Narrator works as domestic help in lawyer's house; (b) रक्रक notices her interest in books; (c) रक्रक gives her a notebook and pen; (d) Narrator struggles to write her first story; (e) Narrator reads her story to रक्रक; (f) रक्रक is moved and encourages her; (g) Narrator's writing improves and gets published; (h) रक्रक dies; (i) Narrator reflects on her journey.
- Step 2: Identify the **Exposition**: Events (a) — the narrator's routine, her widowhood, children, and employment establish the status quo and initial conflict (silence/invisibility).
- Step 3: Identify the **Inciting Incident & Rising Action**: Event (b) and (c) — रक्रक's intervention disrupts the routine. Events (d) — the struggle to write, fear of judgment, secret practice — build tension.
- Step 4: Identify the **Climax**: Event (e) — the narrator reads her story aloud to रक्रक. This is the moment of maximum emotional tension: will her voice be accepted or rejected?
- Step 5: Identify the **Falling Action**: Events (f) and (g) — validation, continued writing, publication, growing confidence. The tension dissipates as the new status quo (writer identity) establishes.
- Step 6: Identify the **Resolution**: Events (h) and (i) — रक्रक's death marks the end of the mentorship; the narrator's final reflection ("मैंने अपनी कहानी खुद लिखी") confirms her autonomous voice. The plot circle closes.

REASONING: This mapping works because it follows the causal chain: external opportunity (रक्रक's gift) → internal effort (writing) → public test (reading aloud) → validation → independence. Each stage is defined by a shift in the protagonist's agency.

ANSWER: 
Exposition: Narrator's life as invisible domestic worker. 
Rising Action: रक्रक's encouragement → narrator's secret writing attempts. 
Climax: Narrator reads her story to रक्रक. 
Falling Action: Validation, publication, growing confidence. 
Resolution: रक्रक's death; narrator's self-affirmation as a writer.

## WORKED_EXAMPLE_2
PROBLEM: Explain how the first-person narrative structure creates dramatic irony in the scene where the narrator first receives the notebook from रक्रक.

STEPS:
- Step 1: Define dramatic irony: reader knows more than the character at that moment.
- Step 2: Identify the narrative perspective: first-person ("मैं") — we only know the narrator's thoughts *at the time of narration*, which includes hindsight.
- Step 3: Locate the scene: रक्रक hands the narrator a notebook, saying "लिखो". The narrator (past self) feels fear, inadequacy ("मुझे लिखना नहीं आता").
- Step 4: Identify the narrator's present knowledge (at time of telling): She *is* a published writer. The opening lines establish her current authority.
- Step 5: Analyze the irony: The reader, aware of the narrator's eventual success (from the narrative frame), feels the poignancy of her past fear. The structure — starting with the established writer looking back — creates this irony.
- Step 6: Connect to theme: The irony underscores the distance traveled, reinforcing the theme of latent potential.

REASONING: The narrative structure uses a retrospective first-person voice. The gap between the narrating-I (confident writer) and the experiencing-I (fearful servant) generates dramatic irony without any third-person intervention.

ANSWER: The retrospective first-person structure lets the narrating-I (successful writer) recount the experiencing-I's (fearful servant) reaction to the notebook. The reader knows the outcome (she becomes a writer), creating dramatic irony that highlights her unrecognized potential at that moment.

## WORKED_EXAMPLE_3
PROBLEM: The story uses a 'story within a story' structure (the narrator writes a story about a girl similar to herself). Analyze how this meta-narrative device functions in the overall plot and narrative structure.

STEPS:
- Step 1: Identify the two narrative levels: Level 1 (frame) = narrator's life in lawyer's house. Level 2 (embedded) = the story she writes ("वकील की बेटी" within "वकील की बेटी").
- Step 2: Trace the introduction of Level 2: It begins in the rising action when रक्रक says "अपनी कहानी लिखो".
- Step 3: Analyze the parallelism: The embedded story's protagonist mirrors the narrator — widowed, working, silenced. The embedded story's plot *is* the narrator's desired plot.
- Step 4: Locate the structural convergence: The climax of Level 1 (reading aloud) *is* the moment Level 2 is revealed to the audience (रक्रक). The two plots merge.
- Step 5: Evaluate the effect: The meta-narrative turns the act of writing into the plot's central action. It transforms the narrator from *subject of* a story to *author of* the story.
- Step 6: Synthesize: The narrative structure thus performs the theme — the form (writing a story) enacts the content (finding voice). Without the embedded story, the climax would be external (getting a job); with it, the climax is internal (becoming a subject).

REASONING: The 'story within a story' is not decorative; it is the structural engine of the protagonist's transformation. The narrative structure mirrors the thematic arc: silence → writing → reading aloud → being heard.

ANSWER: The embedded story serves as the structural manifestation of the narrator's internal journey. Its creation spans the rising action; its reading constitutes the climax; its acceptance resolves the plot. The meta-narrative device collapses the distance between the protagonist's lived reality and her imagined agency, making the narrative structure itself the vehicle of empowerment.

## COMPETENCY_QUESTION_1
QUESTION: The story 'वकील की बेटी' uses a first-person narrative to trace the protagonist's journey from invisibility to voice. Identify the turning point in the plot where the narrator's 'voice' becomes literal, and explain how the narrative structure supports this transformation.

COMPETENCY: Analytical interpretation of plot and narrative structure

STEPS:
- Step 1: Define 'voice' in both metaphorical (agency) and literal (written/spoken words) senses.
- Step 2: Identify the turning point: the scene where the narrator reads her written story aloud to रक्रक (the climax).
- Step 3: Explain how the narrative structure builds to this: retrospective narration establishes the endpoint first; chronological middle shows the struggle; the reading scene is the structural pivot where written words become spoken voice.
- Step 4: Analyze the role of the reflective pauses: they mark the stages of voice acquisition (hesitation → drafting → reading → publication).

ANSWER: The turning point is the narrator reading her story to रक्रक. The narrative structure supports this by framing the entire story as a retrospective act of voice (the narrating-I already has voice), using chronological progression to show the *process* of gaining it, and placing the oral reading at the climax where private writing becomes public speech. The reflective comments ("मैं सोचती रही...") structurally punctuate the internal shifts accompanying each external step.

DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: Critically evaluate the effectiveness of the story's resolution. Does the ending provide a satisfying closure to the central conflict? Justify your answer with reference to the plot structure and narrative perspective.

COMPETENCY: Critical evaluation of literary structure

STEPS:
- Step 1: State the central conflict: the narrator's struggle for self-expression and recognition in a patriarchal domestic space.
- Step 2: Describe the resolution: रक्रक's death, the narrator's continued writing, her final reflection on authorship.
- Step 3: Evaluate closure on the plot level: The external conflict (dependence on रक्रक) ends with रक्रक's death, but the internal conflict (self-worth) resolves positively through the narrator's autonomous writing. The plot structure provides closure because the falling action shows sustained independence (publication, teaching children).
- Step 4: Evaluate closure on the narrative level: The first-person perspective allows the narrator to *declare* her own closure ("मैंने अपनी कहानी खुद लिखी"). The narrative structure ends where it began — with the narrator writing — but the *meaning* of writing has transformed.
- Step 5: Judge effectiveness: The resolution is effective because it avoids melodrama; the quiet structural circularity (writing at start and end) mirrors the realistic, ongoing nature of empowerment.

ANSWER: Yes, the resolution is effective. The plot structure resolves the external dependency (रक्रक's mentorship ends with her death) while the narrative structure confirms internal autonomy (the narrator's voice frames the ending). The circular return to writing — now as an act of self-definition rather than assigned task — provides thematic closure that aligns with the story's realistic, non-fairy-tale tone.

DIFFICULTY: hard