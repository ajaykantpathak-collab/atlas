## DEFINITION
Writing Skills based on the chapter refers to the ability to compose structured, evidence-based analytical answers (such as character sketches, theme analyses, and literary device explanations) for CBSE Class 12 Hindi board examinations, using the PEEL (Point, Evidence, Explanation, Link) framework and drawing specifically from the life, works, and language of the poet रसखान (Raskhan) as presented in Chapter 6 of *Antra*.

## COGNITIVE_LEVEL
apply

## MASTERY_CRITERIA
The student can independently write a 100-150 word board-style answer for any literature question from this chapter that: (1) states a clear analytical point in the opening sentence, (2) cites at least two specific textual details (events, lines, or vocabulary) as evidence, (3) explains how each detail supports the point, and (4) concludes by linking the point to a broader theme (e.g., भक्ति, प्रेम, सामाजिक समरसता) without merely summarizing the plot.

## SCOPE_BOUNDARY
This node covers only the writing of analytical answers for the prose and poetry sections of Chapter 6 (रसखान) — including character portrayal of रसखान, theme of Krishna-bhakti, use of Braj Bhasha, and literary devices in the given excerpts. It does NOT cover creative writing (story, poem, letter), other chapters, or grammar exercises.

## WALKTHROUGH
Imagine you open the board paper and see: "रसखान के व्यक्तित्व में भक्ति और मानवता का कैसा समन्वय है? पाठ के आधार पर लिखिए।" A struggling student often writes a biography summary: "रसखान का जन्म 1532 में हुआ..." — this scores 1/5 because it lacks analysis. To begin, ask: "What is the *one* central idea I must prove?" (e.g., "रसखान की भक्ति सामाजिक बंधनों से मुक्त है।") Next, scan the chapter for two concrete pieces of evidence: the prose line where he leaves royal comforts for Vrindavan, and the poem line "एहि अँसुवा नयनन के भाग्य..." showing intense personal devotion. Then, for each evidence, explain *how* it shows freedom from social norms. Finally, end with: "इस प्रकार रसखान की भक्ति मानव-निर्मित जाति-धर्म की सीमाओं को तोड़कर सार्वभौमिक प्रेम की स्थापना करती है।" The key insight: every sentence after the first must either give evidence or explain it — never just narrate.

## DIAGNOSTIC_QUESTION_1
रसखान के जीवन से संबंधित एक विशिष्ट घटना बताइए जो उनकी कृष्ण-भक्ति की तीव्रता को दर्शाती हो। (केवल याद करने वाला प्रश्न)

## DIAGNOSTIC_ANSWER_1
उत्तर: रसखान द्वारा राजसी सुख त्यागकर वृंदावन में बस जाना और वहाँ भजन-कीर्तन में लीन रहना।  
गलत उत्तर का विश्लेषण: यदि छात्र केवल "वे कृष्ण के भक्त थे" लिखते हैं, तो यह दर्शाता है कि वे पाठ के विशिष्ट प्रसंग (वृंदावन प्रवास, राजसी वैभव का त्याग) को याद नहीं रख पाए हैं — बोर्ड परीक्षा में ऐसे उत्तर को 1 अंक भी नहीं मिलता क्योंकि उसमें पाठाधारित साक्ष्य नहीं है।

## DIAGNOSTIC_QUESTION_2
पाठ में दिए गए पद "एहि अँसुवा नयनन के भाग्य..." में 'अँसुवा' शब्द का प्रयोग कवि ने किस भाव को व्यक्त करने के लिए किया है? अपने शब्दों में समझाइए। (बोध स्तर)

## DIAGNOSTIC_ANSWER_2
उत्तर: 'अँसुवा' (आँसू) के माध्यम से कवि ने विरह-जनित व्याकुलता और कृष्ण-दर्शन की तीव्र लालसा को व्यक्त किया है; आँसू यहाँ केवल शोक के नहीं, बल्कि प्रेम की पराकाष्ठा के प्रतीक हैं।  
गलत उत्तर का विश्लेषण: यदि छात्र लिखते हैं "कवि रो रहे हैं क्योंकि कृष्ण नहीं मिले", तो यह दर्शाता है कि उन्होंने शब्द के प्रतीकात्मक अर्थ (भक्ति में आँसू = प्रेम का चरम) को नहीं समझा — वे शाब्दिक अर्थ पर अटक गए हैं, जो बोर्ड में आंशिक अंक ही दिलाता है।

## DIAGNOSTIC_QUESTION_3
निम्नलिखित कमजोर उत्तर को PEEL ढांचे का प्रयोग करके सुधारिए:  
"रसखान बहुत बड़े भक्त थे। उन्होंने सब छोड़ दिया। उनकी कविता में प्रेम है।" (लागू करने वाला प्रश्न)

## DIAGNOSTIC_ANSWER_3
सुधारा गया उत्तर (चरणबद्ध):  
1. **Point**: रसखान की भक्ति सामाजिक प्रतिष्ठा और पारिवारिक बंधनों से ऊपर उठकर निर्गुण-सी सगुण उपासना बन जाती है।  
2. **Evidence**: पाठ में लिखा है "फारसी-अरबी जानने वाले रसखान ने वृंदावन में भजन-कीर्तन को ही जीवन बना लिया" और पद में "एहि अँसुवा नयनन के भाग्य बिरह बिथा बिनु कह्यौ न जाय"।  
3. **Explanation**: पहला साक्ष्य दर्शाता है कि उन्होंने विद्वत्ता और राजकीय सम्मान त्याग दिए; दूसरा साक्ष्य दिखाता है कि विरह-वेदना उनकी भक्ति का प्राण है, न कि केवल रीति-रिवाज।  
4. **Link**: इस प्रकार रसखान भक्ति को बाह्य आडंबर से मुक्त करके अंतःकरण की शुद्ध भावना के रूप में प्रतिष्ठित करते हैं।  
गलत उत्तर का विश्लेषण: यदि छात्र केवल शब्द बदल देते हैं (जैसे "रसखान महान भक्त थे" के स्थान पर "रसखान उच्चकोटि के भक्त थे") लेकिन साक्ष्य और व्याख्या नहीं जोड़ते, तो वे PEEL की संरचना को नहीं समझ पाए — वे अभी भी सारांश लिख रहे हैं, विश्लेषण नहीं।

## DIAGNOSTIC_QUESTION_4
रसखान के पदों में ब्रजभाषा के प्रयोग और उनकी सूफी पृष्ठभूमि के बीच क्या संबंध है? पाठ के किन्हीं दो उदाहरणों से विश्लेषण कीजिए। (विश्लेषण स्तर)

## DIAGNOSTIC_ANSWER_4
उत्तर: ब्रजभाषा का प्रयोग रसखान की सूफी परंपरा (प्रेम-मार्गी साधना) को कृष्ण-भक्ति की लोकभाषा में ढालने का साधन है।  
उदाहरण 1: पद में "उहद", "लकुटी", "चहँ" जैसे ठेठ ब्रज शब्द सूफी 'इश्क' को गोपी-भाव में व्यक्त करते हैं।  
उदाहरण 2: गद्यांश में "हजारी-जै का इजसे" शीर्षक स्वयं फारसी-हिंदी मिश्रण है, जो उनकी द्विभाषी संवेदना दर्शाता है।  
विश्लेषण: भाषा का यह चयन दर्शाता है कि रसखान ने भक्ति को किसी एक संप्रदाय की जागीर न मानकर जनमानस की भाषा में उतारा।  
गलत उत्तर का विश्लेषण: यदि छात्र केवल "उन्होंने ब्रजभाषा में लिखा क्योंकि वे ब्रज में रहते थे" लिखते हैं, तो वे भाषा-चयन के पीछे की सांस्कृतिक-साहित्यिक रणनीति (सूफी प्रेम-तत्व को कृष्ण-भक्ति में रूपांतरित करना) को नहीं पकड़ पाए — यह बोर्ड में 'विश्लेषण' अंक नहीं दिला पाएगा।

## DIAGNOSTIC_QUESTION_5
"रसखान की भक्ति में सामाजिक समरसता का संदेश निहित है।" इस कथन का मूल्यांकन कीजिए। क्या आप सहमत हैं? पाठाधारित तर्क दीजिए। (मूल्यांकन स्तर)

## DIAGNOSTIC_ANSWER_5
उत्तर: हाँ, सहमत हूँ। रसखान मुस्लिम कुल में जन्मे, फारसी-अरबी के विद्वान, राजदरबारी — फिर भी उन्होंने जाति-धर्म की दीवारें तोड़कर कृष्ण-भक्ति अपनाई। पाठ में उनका वृंदावन में साधु-संगति करना, "हजारी-जै" (मुस्लिम नाम) के साथ "रसखान" (हिंदू भक्त नाम) का सहअस्तित्व, और पदों में गोपियों के प्रेम को सर्वोच्च मानना — ये सभी सामाजिक समरसता के प्रमाण हैं।  
मूल्यांकन: यह केवल व्यक्तिगत आस्था नहीं, बल्कि मध्यकालीन भारतीय समाज में भक्ति आंदोलन की उस धारा का प्रतिबिंब है जिसने वर्णाश्रम से ऊपर प्रेम को रखा।  
गलत उत्तर का विश्लेषण: यदि छात्र केवल "हाँ, वे सबसे प्रेम करते थे" लिखकर रुक जाते हैं, तो वे पाठ के विशिष्ट प्रसंगों (नाम, भाषा, जीवन-चयन) को तर्क के रूप में प्रस्तुत नहीं कर पाते — बोर्ड में ऐसे उत्तर को 'मूल्यांकन' के अंक नहीं मिलते क्योंकि उसमें पाठाधारित औचित्य नहीं है।

## DIAGNOSTIC_QUESTION_6
रसखान के किसी एक पद के आधार पर 4 पंक्तियों की एक नई कविता लिखिए जो विरह-भक्ति के उसी भाव को आधुनिक हिंदी में व्यक्त करे। (सृजन स्तर)

## DIAGNOSTIC_ANSWER_6
अपेक्षित उत्तर (मानदंड):  
- कविता में विरह की व्याकुलता हो (जैसे "रात भर जागूँ, तेरी राह तकूँ")।  
- भक्ति का भाव व्यक्तिगत हो, रीति-रिवाज से मुक्त (जैसे "मंदिर नहीं जाता, तेरा नाम ही पूजा")।  
- कम से कम एक रूपक/प्रतीक हो (जैसे "आँसू मोती बन बिखरे")।  
उदाहरण:  
"तेरी राह निहारते नयन थक गए,  
आँसू मोती बन बिखरे पलकों पर।  
मंदिर-मस्जिद की देहरी लाँघकर,  
तेरा नाम ही अब मेरा ठौर ठिकाना।"  
खराब उत्तर का विश्लेषण: यदि छात्र केवल "कृष्ण तुम कहाँ हो, मुझे बुला लो" जैसी सीधी याचना लिखते हैं, तो वे विरह-भक्ति के सौंदर्यात्मक पक्ष (रूपक, अंतःकरण की गहराई) को नहीं पकड़ पाए — यह दर्शाता है कि उन्होंने पद के कलात्मक ढांचे को नहीं समझा।

## COMMON_MISCONCEPTION
छात्र अक्सर समझते हैं कि 'लेखन कौशल' का अर्थ है पाठ का सारांश लिखना या पात्र का जीवन-परिचय देना। वे PEEL संरचना को 'पहले परिचय, फिर मध्य, फिर अंत' के पारंपरिक निबंध-ढांचे से भ्रमित करते हैं और इसीलिए साक्ष्य (Evidence) और व्याख्या (Explanation) को अलग-अलग चरणों में नहीं लिखते। उदाहरण के लिए, प्रश्न "रसखान की भाषा की विशेषताएँ बताइए" पर वे लिखते हैं: "रसखान की भाषा सरल और मधुर है। उन्होंने ब्रजभाषा में लिखा।" — इसमें न तो विशिष्ट शब्दों के उदाहरण हैं (साक्ष्य), न यह व्याख्या कि उन शब्दों से क्या प्रभाव उत्पन्न होता है (व्याख्या)। यह भ्रम इसलिए होता है क्योंकि कक्षा 10 तक 'सारांश लेखन' और 'पात्र-परिचय' ही प्रमुख रूप से पूछे जाते रहे हैं, जबकि कक्षा 12 में 'विश्लेषणात्मक उत्तर' अपेक्षित है।

## ON_FAILURE
1. छात्र को c12_hin_a_cbse_06_012 (बोधगम्यता) और c12_hin_a_cbse_06_013 (आलोचनात्मक चिंतन) नोड्स पर वापस भेजें: उनसे कहें कि वे पाठ से 5 विशिष्ट वाक्य/पंक्तियाँ चुनें जो रसखान की भक्ति की तीव्रता दर्शाती हों, और प्रत्येक के सामने लिखें कि वह वाक्य *क्या सिद्ध करता है*।  
2. फिर PEEL शीट दें: चार कॉलम (Point, Evidence, Explanation, Link) — उन्हें एक प्रश्न पर पूरा करने को कहें।  
3. पुनः निदान: वही प्रश्न दें जो पहले गलत हुआ था, और जाँचें कि क्या अब उत्तर में चारों चरण स्पष्ट हैं। यदि नहीं, तो चरण 2 दोहराएँ लेकिन इस बार आप स्वयं एक नमूना उत्तर लिखकर दिखाएँ और उनसे तुलना करवाएँ।

## BUILDS_ON
This node builds on the comprehension (literal/inferential) and critical thinking (analysis/interpretation) skills developed in the immediately preceding sibling nodes, requiring students to transform understood content into structured written arguments.

## LEADS_TO
This node enables the Speaking and Listening node (c12_hin_a_cbse_06_015) where students must orally present and defend the same analytical points they have learned to write here.

## PREREQUISITE_NODE_IDS
c12_hin_a_cbse_06_012, c12_hin_a_cbse_06_013, c11_hin_ar_cbse_01_014, c11_hin_v_cbse_01_014, c12_hin_a_cbse_06_001, c12_hin_a_cbse_06_005, c12_hin_a_cbse_06_006, c12_hin_a_cbse_06_011

## PREREQUISITE_REASONS
c12_hin_a_cbse_06_012: Provides literal and inferential understanding of the text — without this, students cannot extract accurate evidence.
c12_hin_a_cbse_06_013: Develops analytical and interpretive skills — essential for the 'Explanation' and 'Link' steps of PEEL.
c11_hin_ar_cbse_01_014: Class 11 Antra writing skills foundation — introduced basic answer structuring for literature.
c11_hin_v_cbse_01_014: Class 11 Vitan writing skills foundation — practiced evidence-based writing in non-fiction context.
c12_hin_a_cbse_06_001: Writing tasks (e.g., article on Raskhan) need this background.  
c12_hin_a_cbse_06_005: Character analysis of supporting characters involves examining secondary figures in a lite... की समझ आवश्यक है, क्योंकि यह नोड (Writing Skills based on the chapter refers to the ability to compose structured, evidence-...) इसी आधार पर आगे बढ़ता है।  
c12_hin_a_cbse_06_006: Writing tasks (essay, article) need a precise theme statement as thesis.  
c12_hin_a_cbse_06_011: Writing skills tasks (e.g., "Explain the language of Raskhan") demand the terminology and analytical framework built here.  

## FORWARD_NODE_IDS
c12_hin_a_cbse_06_015
## FORWARD_REASONS
c12_hin_a_cbse_06_015: Speaking and Listening requires students to orally articulate the same analytical points, evidence, and thematic links they have mastered in writing — this node provides the prepared content and structure for that oral presentation.

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
c12_history_bhakti_movement: Understanding the Bhakti movement's social context (c. 14th-17th century) explains why Raskhan's Muslim-to-Hindu-bhakti transition is historically significant — connects to History chapter on medieval religious movements.
c12_geography_braj_region: Knowledge of Braj region's geography (Mathura-Vrindavan) and cultural landscape clarifies why Raskhan chose Vrindavan and how the region's linguistic milieu shaped his Braj Bhasha poetry — connects to Geography chapter on cultural regions.

## CHAIN_DESCRIPTION
c12_hin_a_cbse_06_012 -> c12_hin_a_cbse_06_014 -> c12_hin_a_cbse_06_015

## THIS_FORMULA
PEEL Structure for Literature Answers: **P**oint (Clear analytical claim) → **E**vidence (Specific textual detail: line, event, word) → **E**xplanation (How evidence proves the point) → **L**ink (Connect to broader theme/author's intent)

## FORMULA_VARIABLES
P = Opening sentence stating the analytical argument (not a fact). E = Direct reference to text (prose line, poem line, vocabulary, event) — must be specific. E = 2-3 sentences explaining the significance of the evidence, using literary terminology (e.g., प्रतीक, रूपक, विरह, लोकभाषा). L = Concluding sentence tying the point to a universal theme (भक्ति, प्रेम, सामाजिक समरसता, भाषा की शक्ति) or author's purpose.

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
linguistic

## CROSS_SUBJECT
N/A | Raskhan's life exemplifies the Bhakti movement's transcendence of religious boundaries — his shift from Sufi-influenced courtier to Krishna devotee in Vrindavan mirrors the historical pattern of poet-saints (Kabir, Raidas, Dadu) who challenged orthodoxy through personal devotion.
 N/A | The Braj region's sacred geography (Yamuna, Govardhan, Vrindavan) and its living tradition of Krishna-lila performance directly shaped Raskhan's poetic imagery (e.g., references to 'कुंज', 'गोपी', 'बंसी') and his decision to settle there — a case study of cultural geography influencing literary production.
## PREREQ_CONCEPT
Ability to distinguish between *summary* (what happens) and *analysis* (why it matters and how it works) — the core shift from Class 10 to Class 12 literature writing.

## PREREQ_BEFORE
Student must have read Chapter 6 completely, identified at least 5 key textual details (events, lines, words), and understood the central themes (भक्ति, प्रेम, भाषा, सामाजिक समरसता) as discussed in nodes 006, 007, 008, 009.

## PREREQ_STUCK
If stuck, revisit c12_hin_a_cbse_06_012 (Comprehension) to re-extract textual evidence, and c12_hin_a_cbse_06_013 (Critical Thinking) to practice interpreting that evidence — then return to PEEL practice.

## WORKED_EXAMPLE_1
PROBLEM: बोर्ड परीक्षा प्रश्न: "रसखान के व्यक्तित्व में विद्वत्ता और भक्ति का कैसा समन्वय है? पाठ के आधार पर 100-120 शब्दों में लिखिए।" एक कमजोर छात्र का उत्तर: "रसखान बहुत विद्वान थे। उन्हें फारसी, अरबी आती थी। फिर वे कृष्ण के भक्त बन गए। उन्होंने वृंदावन में रहकर भजन किया।" — इस उत्तर को सुधारकर PEEL ढांचे में लिखिए।
STEPS:
- Step 1: Identify the core analytical claim (Point) — not a list of facts. The claim: "रसखान की विद्वत्ता उनकी भक्ति का विरोध नहीं करती, बल्कि उसे गहराई और अभिव्यक्ति की शक्ति देती है।"
- Step 2: Select two precise textual evidences. Evidence 1: Prose line — "फारसी और अरबी दोनों भाषाओं पर रसखान का समान अधिकार था... उन्होंने वैराग्य लेकर वृंदावन में डेरा डाला।" Evidence 2: Poetic vocabulary — पद में "उहद", "लकुटी", "चहँ" जैसे ठेठ ब्रज शब्दों के साथ "इजसे", "हजारी" जैसे फारसी शब्दों का सहअस्तित्व।
- Step 3: Write Explanation for each evidence. For Evidence 1: विद्वत्ता ने उन्हें शास्त्रीय परंपराओं (सूफी, वैष्णव) को समझने का आधार दिया, पर भक्ति ने उसे अनुभव में बदला। For Evidence 2: भाषा का यह मिश्रण दर्शाता है कि उनकी भक्ति किसी एक संप्रदाय की जागीर नहीं, बल्कि सांस्कृतिक संश्लेषण का परिणाम है।
- Step 4: Craft the Link. "इस प्रकार रसखान विद्वत्ता को भक्ति का आडंबर न बनाकर, उसे जनमानस की भाषा (ब्रज) में ढालकर भक्ति को लोक-सुलभ बनाते हैं।"
- Step 5: Assemble into a coherent 110-word paragraph, checking that every sentence after the first is either Evidence or Explanation, and the last is Link.
REASONING: This process forces the student to move from 'knowing facts' to 'building an argument' — the exact skill CBSE marking scheme rewards (2 marks for point+link, 2 marks for evidence+explanation, 1 mark for language).
ANSWER: रसखान की विद्वत्ता उनकी भक्ति का विरोध नहीं करती, बल्कि उसे गहराई और अभिव्यक्ति की शक्ति देती है। पाठ में लिखा है कि "फारसी और अरबी दोनों भाषाओं पर रसखान का समान अधिकार था... उन्होंने वैराग्य लेकर वृंदावन में डेरा डाला" — यह दर्शाता है कि शास्त्रीय ज्ञान ने उन्हें संप्रदायों के पार देखने की दृष्टि दी। उनके पदों में "उहद", "लकुटी" (ब्रज) के साथ "इजसे", "हजारी" (फारसी) शब्दों का सहअस्तित्व इसी संश्लेषण का प्रमाण है: भक्ति किसी एक भाषा की मोहताज नहीं। इस प्रकार रसखान विद्वत्ता को भक्ति का आडंबर न बनाकर, उसे जनमानस की भाषा में ढालकर भक्ति को लोक-सुलभ बनाते हैं।

## WORKED_EXAMPLE_2
PROBLEM: प्रश्न: "रसखान के पदों में विरह-वेदना का चित्रण कैसे हुआ है? दो उदाहरण देकर समझाइए।" छात्र अक्सर केवल पद की पंक्तियाँ उद्धृत कर देते हैं और उनकी व्याख्या नहीं करते। PEEL का प्रयोग करके एक मॉडल उत्तर लिखिए।
STEPS:
- Step 1: Point — "रसखान विरह को केवल दुःख नहीं, बल्कि भक्ति की परिपक्वता और प्रेम की परीक्षा के रूप में चित्रित करते हैं।"
- Step 2: Evidence 1 — पद की पंक्ति: "एहि अँसुवा नयनन के भाग्य बिरह बिथा बिनु कह्यौ न जाय"। Evidence 2 — पद की पंक्ति: "निसि बासर नैनन कों नीर भरी, बिरह-ब्याधि तन मन घेरी"।
- Step 3: Explanation 1 — 'अँसुवा' (आँसू) को 'नयनन के भाग्य' कहकर कवि विरह को सौभाग्य में बदल देते हैं: रोना ही दर्शन का साधन बन जाता है। Explanation 2 — 'बिरह-ब्याधि' (विरह रूपी रोग) तन-मन दोनों को घेर लेता है, यह दर्शाता है कि प्रेम साधारण भावना नहीं, पूर्ण समर्पण है।
- Step 4: Link — "इस प्रकार रसखान विरह को विरहणी गोपियों के माध्यम से उस उच्च भक्ति-साधना के रूप में प्रस्तुत करते हैं जहाँ पीड़ा ही परमात्मा से मिलन का मार्ग बनती है।"
- Step 5: Verify word count (approx. 100 words) and ensure no narrative summary.
REASONING: The question demands 'चित्रण' (portrayal) not 'उल्लेख' (mention) — hence Explanation must unpack the imagery and its philosophical implication, which is exactly what PEEL's E-step enforces.
ANSWER: रसखान विरह को केवल दुःख नहीं, बल्कि भक्ति की परिपक्वता और प्रेम की परीक्षा के रूप में चित्रित करते हैं। पद में "एहि अँसुवा नयनन के भाग्य बिरह बिथा बिनु कह्यौ न जाय" — यहाँ आँसुओं को 'नयनों का भाग्य' कहकर कवि विरह को सौभाग्य में बदल देते हैं: रोना ही दर्शन का साधन बन जाता है। दूसरी पंक्ति "निसि बासर नैनन कों नीर भरी, बिरह-ब्याधि तन मन घेरी" विरह को 'व्याधि' (रोग) बताती है जो तन-मन दोनों को घेर लेती है, अर्थात प्रेम साधारण भावना नहीं, पूर्ण समर्पण है। इस प्रकार रसखान विरह को विरहणी गोपियों के माध्यम से उस उच्च भक्ति-साधना के रूप में प्रस्तुत करते हैं जहाँ पीड़ा ही परमात्मा से मिलन का मार्ग बनती है।

## WORKED_EXAMPLE_3
PROBLEM: एक कठिन प्रश्न जो पाठ के गद्यांश और पद दोनों को जोड़ता है: "रसखान की भक्ति में 'लोक' और 'शास्त्र' का कैसा संबंध है? पाठ के गद्यांश और पद — दोनों के आधार पर विश्लेषण कीजिए।" (इसमें तीन अवधारणाएँ मिलती हैं: गद्य-पद संबंध, लोक/शास्त्र द्वंद्व, और संश्लेषण।)
STEPS:
- Step 1: Deconstruct the question — it asks for the relationship between 'लोक' (folk/popular, represented by Braj Bhasha, gopi-bhav, Vrindavan life) and 'शास्त्र' (classical/scholastic, represented by Persian/Arabic learning, courtly culture) in Raskhan's bhakti.
- Step 2: Point — "रसखान शास्त्रीय विद्वत्ता को लोक-भक्ति की सेवा में लगाकर दोनों के बीच सेतु निर्मित करते हैं, न कि उन्हें विरोधी मानते हैं।"
- Step 3: Evidence from Prose (शास्त्र) — "फारसी और अरबी दोनों भाषाओं पर रसखान का समान अधिकार था... जयपुर दरबार में मान-सम्मान पाते थे।" Evidence from Poetry (लोक) — पदों में ब्रजभाषा के ठेठ शब्द ("उहद", "लकुटी", "चहँ", "अँसुवा") और गोपी-भाव का चित्रण।
- Step 4: Explanation — शास्त्रीय ज्ञान (फारसी/अरबी) ने उन्हें सूफी प्रेम-तत्व (इश्क़-मजाज़ी से इश्क़-हक़ीक़ी) समझने में मदद की, जिसे उन्होंने कृष्ण-भक्ति (गोपी-भाव) में रूपांतरित किया। लोक-भाषा (ब्रज) ने उस अनुभूति को जनमानस तक पहुँचाया।
- Step 5: Synthesis — "हजारी-जै का इजसे" शीर्षक स्वयं इस संश्लेषण का प्रतीक है: फारसी 'हजारी' (हाजिरी/उपस्थिति) + ब्रज 'इजसे' (इच्छा/लालसा) = विद्वान की उपस्थिति भक्त की लालसा में।
- Step 6: Link — "इस प्रकार रसखान भक्ति को न तो शुष्क शास्त्रार्थ बनने देते हैं, न अंधी लोक-आस्था — वे ज्ञान को प्रेम का वाहन बनाते हैं।"
REASONING: This question tests 'Analyze' + 'Evaluate' — student must compare two textual modes (prose/poetry) and two cultural registers (śāstra/loka), then synthesize. PEEL expands naturally: two Evidences (one from each register), combined Explanation, unified Link.
ANSWER: रसखान शास्त्रीय विद्वत्ता को लोक-भक्ति की सेवा में लगाकर दोनों के बीच सेतु निर्मित करते हैं, न कि उन्हें विरोधी मानते हैं। गद्यांश बताता है कि "फारसी और अरबी दोनों भाषाओं पर रसखान का समान अधिकार था... जयपुर दरबार में मान-सम्मान पाते थे" — यह उनका 'शास्त्र' पक्ष है। पदों में "उहद", "लकुटी", "चहँ", "अँसुवा" जैसे ठेठ ब्रज शब्द और गोपी-भाव — यह 'लोक' पक्ष है। शास्त्रीय ज्ञान ने उन्हें सूफी प्रेम-तत्व समझने में मदद की, जिसे उन्होंने कृष्ण-भक्ति में ढाला; लोक-भाषा ने उसे जनमानस तक पहुँचाया। शीर्षक "हजारी-जै का इजसे" (फारसी 'हजारी' + ब्रज 'इजसे') इसी संश्लेषण का प्रतीक है। इस प्रकार रसखान भक्ति को न शुष्क शास्त्रार्थ बनने देते, न अंधी लोक-आस्था — वे ज्ञान को प्रेम का वाहन बनाते हैं।

## COMPETENCY_QUESTION_1
QUESTION: निम्नलिखित दो उत्तरों में से कौन-सा बेहतर है और क्यों? CBSE मार्किंग स्कीम के अनुसार अंक दीजिए।  
प्रश्न: "रसखान की भाषा की विशेषताएँ बताइए।"  
उत्तर A: "रसखान की भाषा सरल, मधुर और ब्रजभाषा में है। उन्होंने फारसी शब्दों का भी प्रयोग किया है।"  
उत्तर B: "रसखान की भाषा ब्रजभाषा की माधुर्य और फारसी की सटीकता का अद्वितीय मिश्रण है। पद में 'उहद', 'लकुटी' (ठेठ ब्रज) के साथ 'इजसे', 'हजारी' (फारसी) शब्दों का सहप्रयोग उनकी द्विभाषी संवेदना दर्शाता है। यह मिश्रण भक्ति को किसी एक संप्रदाय की सीमा से मुक्त करके सर्वसुलभ बनाता है।"
COMPETENCY: Critical Evaluation of Answer Quality (Analytical Thinking)
STEPS:
- Step 1: Identify the question demand — 'विशेषताएँ' requires specific features with examples, not just labels.
- Step 2: Evaluate Answer A — gives only labels (सरल, मधुर, ब्रजभाषा, फारसी), no textual evidence, no explanation of effect. Would score 1/3 (only content recall).
- Step 3: Evaluate Answer B — gives specific lexical evidence (उहद/लकुटी vs इजसे/हजारी), explains the significance (द्विभाषी संवेदना, संप्रदाय-मुक्त भक्ति), uses analytical vocabulary (मिश्रण, सहप्रयोग, सर्वसुलभ). Would score 3/3.
- Step 4: Conclude: Answer B is superior because it follows PEEL implicitly: Point (मिश्रण), Evidence (शब्द युग्म), Explanation (द्विभाषी संवेदना), Link (सर्वसुलभ भक्ति).
ANSWER: उत्तर B बेहतर है। CBSE मार्किंग स्कीम के अनुसार: उत्तर A = 1 अंक (केवल तथ्यात्मक उल्लेख, साक्ष्य और व्याख्या नहीं)। उत्तर B = 3 अंक (स्पष्ट बिंदु, विशिष्ट पाठाधारित साक्ष्य, प्रभाव की व्याख्या, विषयगत संबंध)। उत्तर B PEEL संरचना का अनुसरण करता है: Point → Evidence → Explanation → Link, जबकि उत्तर A केवल सूचीबद्ध तथ्य देता है।
DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: आपने रसखान के पद "एहि अँसुवा नयनन के भाग्य..." का विश्लेषण किया है। अब कल्पना कीजिए कि यही भाव एक आधुनिक दलित कवयित्री अपनी कविता में व्यक्त कर रही है — वह 'आँसू' को 'भाग्य' नहीं, बल्कि 'प्रतिरोध' कहेगी। दोनों दृष्टिकोणों (रसखान और आधुनिक दलित कवयित्री) की तुलना करते हुए एक पैराग्राफ लिखिए जो भक्ति और प्रतिरोध के संबंध को स्पष्ट करे। पाठाधारित साक्ष्य और तार्किक तर्क दोनों का प्रयोग कीजिए।
COMPETENCY: Intertextual Synthesis and Creative Application (Higher-Order Thinking)
STEPS:
- Step 1: Recall Raskhan's stance — आँसू = भाग्य (दैवीय कृपा, समर्पण, विरह में भी आनंद)।
- Step 2: Construct the modern Dalit poet's stance — आँसू = प्रतिरोध (अन्याय के विरुद्ध आवाज, चुप्पी तोड़ना, अधिकार माँगना)।
- Step 3: Find common ground — दोनों में आँसू निष्क्रिय नहीं हैं; दोनों उन्हें शक्ति में बदलते हैं (रसखान: भक्ति-शक्ति; दलित कवयित्री: सामाजिक-शक्ति)।
- Step 4: Identify divergence — रसखान की शक्ति आत्मिक/आध्यात्मिक मुक्ति की ओर; दलित कवयित्री की शक्ति सामाजिक/राजनीतिक मुक्ति की ओर।
- Step 5: Write paragraph using PEEL: Point (आँसू दोनों में शक्ति-रूप हैं), Evidence 1 (रसखान: "नयनन के भाग्य"), Evidence 2 (दलित कविता: "आँसू नहीं, शस्त्र हैं हमारे"), Explanation (दोनों असहायता को एजेंसी में बदलते हैं), Link (भक्ति और प्रतिरोध दोनों मनुष्य को गरिमा देते हैं — बस मुक्ति का क्षितिज भिन्न है)।
REASONING: This question tests the competency 'Creative Application' by asking students to transfer analytical framework (PEEL) to a novel comparative context — exactly what NEP 2020 and CUET demand. It requires deep understanding of Raskhan's bhakti (not just memory) and ability to map it onto a contemporary discourse.
ANSWER: रसखान और आधुनिक दलित कवयित्री — दोनों आँसू को निष्क्रिय पीड़ा नहीं, बल्कि सक्रिय शक्ति मानते हैं, पर उस शक्ति की दिशा भिन्न है। रसखान लिखते हैं "एहि अँसुवा नयनन के भाग्य" — यहाँ आँसू दैवीय कृपा का प्रसाद हैं, विरह में भी आनंद का स्रोत; यह भक्ति-शक्ति है जो आत्मा को परमात्मा से जोड़ती है। इसके विपरीत दलित कवयित्री आँसू को 'प्रतिरोध' कहेगी: "ये आँसू नहीं, शस्त्र हैं हमारे / जो चुप्पी की दीवारें तोड़ते हैं" — यह सामाजिक-शक्ति है जो उत्पीड़न के विरुद्ध अधिकार माँगती है। समानता यह है कि दोनों दृष्टियाँ आँसू को असहायता से मुक्त करके एजेंसी (कर्तृत्व) में बदलती हैं। अंतर यह है कि रसखान की मुक्ति आध्यात्मिक/आंतरिक है (कृष्ण-मिलन), जबकि दलित कवयित्री की मुक्ति सामाजिक/बाह्य है (समता-अधिकार)। इस प्रकार भक्ति और प्रतिरोध — दोनों मनुष्य को गरिमा देते हैं, बस मुक्ति का क्षितिज भिन्न है।
DIFFICULTY: hard