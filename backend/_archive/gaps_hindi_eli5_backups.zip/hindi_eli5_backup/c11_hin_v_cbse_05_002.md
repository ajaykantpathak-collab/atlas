## DEFINITION
Plot and narrative structure refer to the sequence of events in a story and the framework that organizes them, including exposition, rising action, climax, falling action, and resolution, as well as techniques like flashback, foreshadowing, and narrative perspective.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student must be able to identify the five stages of plot in the given text, explain how narrative techniques (e.g., flashback, parallel plots) shape the story, and write a structured analysis linking structure to theme.

## SCOPE_BOUNDARY
This node covers plot stages, narrative techniques (linear/non-linear, flashback, foreshadowing), and narrative perspective in the chapter's story. It does not cover setting, character analysis, or themes in depth (those are separate nodes).

## WALKTHROUGH
Imagine you are watching a movie and the scenes jump between past and present – you wonder why the director chose that order. Similarly, in "जक्तLFकku ध jtr cव¡nas", the author uses a non-linear narrative to reveal the protagonist's trauma. To begin, ask: "What is the first event the reader encounters, and is it the chronological start?" Then map each major event to the plot pyramid. Next, identify any shifts in time or perspective. Finally, connect the structural choices to the story's emotional impact.

## DIAGNOSTIC_QUESTION_1
Define 'exposition' in the context of plot structure and state its primary function in a narrative.

## DIAGNOSTIC_ANSWER_1
Exposition is the opening section of a story that introduces the setting, characters, and initial situation. Its primary function is to provide necessary background information so the reader understands the context before the conflict begins. A wrong answer (e.g., defining exposition as the climax) reveals the student cannot distinguish between plot stages.

## DIAGNOSTIC_QUESTION_2
In "जक्तLFकku ध jtr cव¡nas", the story opens with the protagonist as an adult reflecting on childhood. Explain why this opening is not the chronological exposition and what narrative technique is being used.

## DIAGNOSTIC_ANSWER_2
The opening uses a flashback (or in media res) technique: it starts at a later point (adult reflection) and then goes back to childhood events. The chronological exposition would be the childhood events themselves. A wrong answer (e.g., saying it's linear) shows the student misses non-linear storytelling.

## DIAGNOSTIC_QUESTION_3
Given a short summary of a story where the climax occurs at the midpoint, apply the concept of 'falling action' to list two consequences that must follow the climax in the narrative structure.

## DIAGNOSTIC_ANSWER_3
After the climax, falling action includes: (1) the immediate aftermath of the decisive event (e.g., the protagonist's decision consequences), and (2) the resolution of secondary conflicts. Steps: identify climax, then trace what happens next. A wrong answer (listing events before climax) shows confusion between rising and falling action.

## DIAGNOSTIC_QUESTION_4
Compare the narrative structure of "जक्तLFकku ध jtr cव¡nas" (which uses flashbacks) with a linear story. Analyze how the non-linear structure affects the reader's understanding of the protagonist's trauma.

## DIAGNOSTIC_ANSWER_4
The non-linear structure mirrors the protagonist's fragmented memory, forcing the reader to piece together the trauma just as the character does. In a linear story, trauma is revealed chronologically, reducing psychological tension. A wrong answer (e.g., saying both are same) indicates inability to link structure to psychological effect.

## DIAGNOSTIC_QUESTION_5
Evaluate the author's choice to end the story with an open resolution rather than a clear closure. Defend your judgment with reference to the story's central theme.

## DIAGNOSTIC_ANSWER_5
An open resolution reinforces the theme of enduring trauma and the impossibility of complete healing, making the reader sit with the discomfort. A closed resolution would undermine the realism. A wrong answer (preferring closed ending) may show a misunderstanding of thematic resonance.

## DIAGNOSTIC_QUESTION_6
Create a brief alternative ending for "जक्तLFकku ध jtr cव¡nas" that changes the narrative structure from open to closed resolution, and explain how this alters the story's message.

## DIAGNOSTIC_ANSWER_6
Alternative ending: The protagonist finds a letter that brings full closure and forgiveness. This shifts the message from 'trauma lingers' to 'healing is possible', altering the theme. A poor answer would not explain the thematic shift.

## COMMON_MISCONCEPTION
Students often think 'plot' is just a summary of events, ignoring the author's deliberate ordering (e.g., flashbacks, parallel plots). They also confuse 'climax' with the most exciting action rather than the turning point of the conflict. For example, in this story, the climax is the protagonist's internal realization, not the external event.

## ON_FAILURE
If a student cannot distinguish plot stages, have them: (1) List all major events in chronological order. (2) Map each to the plot pyramid. (3) Identify where the narrative order differs from chronological order. (4) Discuss why the author reordered them. Use a familiar story like "Cinderella" to practice before applying to the text.

## BUILDS_ON
c11_hin_v_cbse_05_001 (Before You Read: Context and Background) provides the historical and biographical context needed to understand why the author chose this narrative structure.

## LEADS_TO
c11_hin_v_cbse_05_003 (Setting and Atmosphere) because narrative structure determines how setting is revealed (e.g., through flashbacks).

## PREREQUISITE_NODE_IDS
c11_hin_v_cbse_05_001
## PREREQUISITE_REASONS
c11_hin_v_cbse_05_001: Understanding the author's background and the historical context (Partition, displacement) is essential to grasp why the narrative uses non-linear structure to depict trauma.

## FORWARD_NODE_IDS
c11_hin_v_cbse_05_003, c11_hin_v_cbse_05_004, c11_hin_v_cbse_05_006, c11_hin_v_cbse_05_005, c11_hin_v_cbse_05_007, c11_hin_v_cbse_05_008, c11_hin_v_cbse_05_009, c11_hin_v_cbse_05_010, c11_hin_v_cbse_05_012, c11_hin_v_cbse_05_013, c11_hin_v_cbse_05_015, c12_hin_a_cbse_09_002

## FORWARD_REASONS
c11_hin_v_cbse_05_003: Plot structure determines how setting is introduced (e.g., flashbacks reveal past settings). c11_hin_v_cbse_05_004: Character development is tied to plot stages; the protagonist's arc follows the narrative structure. c11_hin_v_cbse_05_006: Themes are conveyed through structural choices like climax and resolution.
c11_hin_v_cbse_05_005: Understanding narrative structure reveals why the author places specific encounters at specific junctures.  
c11_hin_v_cbse_05_007: Plot structure knowledge needed to locate where secondary themes emerge (subplots, parallel scenes).  
c11_hin_v_cbse_05_008: Plot structure tells *where* key descriptive passages occur (climax, resolution).  
c11_hin_v_cbse_05_009: Establishes plot sequence so students can locate ironic moments (e.g., locking the house) and symbolic objects (trunk, cot) at specific narrative points.  
c11_hin_v_cbse_05_010: Plot and Narrative Structure supplies the specific scenes and conflicts where words like *विस्थापन* and *मुआवज़ा* operate, allowing contextual analysis.  
c11_hin_v_cbse_05_012: Plot structure knowledge helps locate where in the narrative explicit answers reside and where gaps require inference.  
c11_hin_v_cbse_05_013: Understanding plot and narrative structure is necessary to analyze how the story's progression serves its theme.  
c11_hin_v_cbse_05_015: Narrative structure knowledge allows referencing specific plot points as evidence  
c12_hin_a_cbse_09_002: Vitan chapter 5 narrative structure practice.  
c11_hin_v_cbse_05_004: Plot structure gives the event sequence to analyze as character-driven choices.  
c11_hin_v_cbse_05_006: Plot provides the sequence of systemic oppressions (landlord → contractor → city) that *build* the theme cumulatively.  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
none

## CHAIN_DESCRIPTION
c11_hin_v_cbse_05_001 -> c11_hin_v_cbse_05_002 -> c11_hin_v_cbse_05_003

## THIS_FORMULA
N/A - conceptual

## FORMULA_VARIABLES
N/A

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
analytical

## CROSS_SUBJECT
c11_history_partition_narratives | The story's non-linear narrative mirrors the fragmented memory of Partition survivors, a concept studied in history oral testimonies.
c11_psychology_trauma_memory | The narrative structure reflects how traumatic memory works (flashbacks, dissociation), linking to psychology concepts of PTSD.

## PREREQ_CONCEPT
Understanding of basic plot elements (exposition, rising action, climax, falling action, resolution) from earlier classes.

## PREREQ_BEFORE
Student must be able to identify the sequence of events in a simple linear story.

## PREREQ_STUCK
Review the five-stage plot pyramid (Freytag's Pyramid) and practice labeling events in a known story like "The Thirsty Crow".

## WORKED_EXAMPLE_1
PROBLEM: Analyze the plot structure of "जक्तLFकku ध jtr cव¡nas" by identifying the five stages and noting any deviations from linear order.
STEPS:
- Step 1: Read the story and list all major events in the order they appear in the text (narrative order).
- Step 2: Rearrange the same events in chronological order (story order).
- Step 3: Compare the two lists to identify flashbacks, foreshadowing, or in media res.
- Step 4: Map each narrative event to the five plot stages (exposition, rising action, climax, falling action, resolution) based on the narrative order.
- Step 5: Write a paragraph explaining how the non-linear arrangement affects the reader's experience of the protagonist's trauma.
REASONING: Separating narrative order from chronological order reveals the author's structural choices. Mapping to plot stages shows how the story builds tension despite non-linearity.
ANSWER: The story begins in media res with the adult protagonist (narrative exposition), then flashes back to childhood (chronological exposition). The rising action includes the displacement and loss. The climax is the moment of realization about the 'crows' symbolism. Falling action shows the adult's continued haunting. Resolution is open-ended. The non-linear structure mimics traumatic memory.

## WORKED_EXAMPLE_2
PROBLEM: Identify two instances of foreshadowing in the story and explain how they prepare the reader for the climax.
STEPS:
- Step 1: Scan the text for hints, symbols, or dialogue that suggest future events.
- Step 2: Select two clear examples (e.g., the recurring image of crows, the protagonist's childhood fear).
- Step 3: For each, state what later event it hints at.
- Step 4: Explain how each foreshadowing builds tension or thematic depth.
- Step 5: Connect the foreshadowing to the story's central theme of inescapable past.
REASONING: Foreshadowing is a narrative device that links structure to theme; identifying it requires close reading of details across the narrative.
ANSWER: (1) Early mention of crows circling the village foreshadows the violence of Partition. (2) The protagonist's nightmare as a child foreshadows his adult insomnia. Both create a sense of inevitability.

## WORKED_EXAMPLE_3
PROBLEM: Compare the narrative perspective in "जक्तLFकku ध jtr cव¡nas" (first-person retrospective) with a third-person omniscient version. How would the plot structure change?
STEPS:
- Step 1: Identify the current narrative perspective (first-person, looking back).
- Step 2: List what the narrator knows and when they know it (limited to their memory).
- Step 3: Imagine a third-person omniscient narrator: they could show other characters' thoughts and events outside the protagonist's memory.
- Step 4: Analyze how this would change the plot structure: more linear, less fragmented, possibly multiple plotlines.
- Step 5: Evaluate the effect on theme: loss of subjective trauma experience, gain of broader historical context.
- Step 6: Conclude why the author chose first-person retrospective for this story.
REASONING: Narrative perspective shapes plot structure by controlling information flow; changing perspective alters the structural possibilities and thematic focus.
ANSWER: First-person retrospective forces non-linear, fragmented structure mirroring memory. Third-person omniscient would allow linear, multi-threaded narrative, diluting the personal trauma theme. The author's choice maximizes emotional impact.

## COMPETENCY_QUESTION_1
QUESTION: In "जक्तLFकku ध jtr cव¡nas", the climax is an internal realization rather than an external event. Explain how the narrative structure (use of flashbacks) builds toward this internal climax. Use the PEEL structure (Point, Evidence, Explanation, Link) in your answer.
COMPETENCY: Literary analysis and structured writing
STEPS:
- Step 1: State the point: The non-linear structure builds toward the internal climax by layering memories.
- Step 2: Provide evidence: Describe two flashbacks that reveal escalating trauma.
- Step 3: Explain how each flashback adds a piece to the puzzle leading to the realization.
- Step 4: Link back to the theme: The structure enacts the process of remembering.
ANSWER: The non-linear structure builds toward the internal climax by layering fragmented memories. For instance, the flashback to the crowded train (evidence 1) shows the chaos of displacement, while the later flashback to the silent village (evidence 2) reveals the aftermath. Together, they lead the protagonist to realize that the 'crows' symbolize the unburied dead (explanation). This structural mimicry of traumatic recall links to the theme that the past is never fully past (link).
DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: The story uses a circular narrative structure, ending where it began (the adult protagonist reflecting). Critically evaluate whether this circularity provides closure or reinforces the theme of unresolved trauma. Support your evaluation with three structural details.
COMPETENCY: Critical evaluation and evidence-based argument
STEPS:
- Step 1: Define circular narrative in this context.
- Step 2: Identify three structural details: (a) opening and closing scene similarity, (b) the recurrence of the crow motif, (c) the lack of new information in the final scene.
- Step 3: Argue that circularity reinforces unresolved trauma because the protagonist is in the same psychological state.
- Step 4: Counter-argument: Some may say the act of narrating is a form of closure.
- Step 5: Conclude with your judgment, weighing both sides.
ANSWER: The circular structure reinforces unresolved trauma. The opening and closing scenes are nearly identical – the protagonist watching crows – showing no psychological progress. The crow motif recurs without transformation, symbolizing persistent memory. The final scene adds no new insight, only repetition. While narration itself could be therapeutic, the text offers no indication of healing. Thus, the structure enacts the theme of inescapable past.
DIFFICULTY: hard