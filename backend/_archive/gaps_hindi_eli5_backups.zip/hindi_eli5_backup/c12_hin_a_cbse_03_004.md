## DEFINITION
Character analysis of the protagonist in poetry involves examining the poetic persona (speaker) and the central human subjects portrayed — their traits, emotions, conflicts, and symbolic significance — through close reading of imagery, tone, diction, and structural choices to uncover how the poet constructs identity and conveys thematic meaning.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student can independently identify the poetic persona and central human subjects in both poems, cite specific textual evidence (imagery, metaphors, repetitions) to support claims about their characterization, and explain how characterization advances the poems' critique of social norms and affirmation of human dignity.

## SCOPE_BOUNDARY
This node covers character analysis of the poetic persona and the two central subjects — the "small nose" (nhi) in poem 1 and the "small girl" (cw¡n) in poem 2 — in Nagarjun's poems "nhi vosQyk" and "eSaus ns[kk] ,d cw¡n". It does NOT cover supporting characters (N/A exist in these poems), theme analysis (covered in nodes 006-007), or literary devices in isolation (covered in nodes 008-009).

## WALKTHROUGH
Imagine you're scrolling through social media and see a post mocking someone's "unconventional" nose or a photo of a poor child smiling — your immediate reaction reveals what society has taught you to value. Nagarjun's poems force us to confront that conditioning. Begin by reading both poems aloud twice: first for sound and rhythm, second to mark every adjective, verb, and metaphor attached to the nose and the girl. Ask: "Who is speaking? What does the speaker *choose* to notice? What does the repetition of 'ns nks' (give it to the present) demand of us?" The key insight: the protagonist isn't just the nose or the girl — it's the *act of seeing differently* that the poet performs and invites us to replicate.

## DIAGNOSTIC_QUESTION_1
In "nhi vosQyk," the poetic speaker describes the nose as "Lusg Hkjk," "xoZ Hkjk," and "enekrk." What is the *grammatical form* of these three words, and what does their repetition at the end of each stanza (as a refrain) structurally achieve?

## DIAGNOSTIC_ANSWER_1
The three words are adjectives in the masculine singular direct case (Lusg, xoZ, enekrk) modifying "nhi" (feminine noun treated as masculine in poetic convention or via implied "nhi [nak]"). The refrain "nhi vosQyk Lusg Hkjk gS xoZ Hkjk enekrk] ij bldks Hkh iafDr dks ns nks" appears verbatim at the end of all four stanzas, creating a cyclical structure that mimics insistence — each stanza adds a new metaphorical identity (xhr/eksrh, vf}rh;/esjk, eèkq/xksjl/vaoqQj, izÑr/Lo;aHkw/czã/v;qr) but returns to the same core affirmation, enacting the poem's argument that the nose's worth is non-negotiable regardless of how it's framed. A wrong answer (e.g., calling them nouns or missing the refrain's structural function) reveals the student hasn't tracked how form enacts meaning — they're treating the poem as a list of statements rather than a designed argument.

## DIAGNOSTIC_QUESTION_2
The poem "eSaus ns[kk] ,d cw¡n" opens with "lkxj osQ >kx ls" (from the edge of the lane) and describes the girl's face shining "jax xbZ {k.kHkj <yrs lwjt dh vkx ls." A student writes: "The poet contrasts the dark lane with the girl's bright face to show hope in poverty." Why is this answer *incomplete* for a Class 12 board-level response?

## DIAGNOSTIC_ANSWER_2
The answer identifies a binary contrast (dark/light) but misses the *causal mechanism*: "lwjt" (saliva/spittle) is a visceral, bodily substance associated with deprivation, yet it becomes the *source* of light ("jax xbZ {k.kHkj"). The verb "xbZ" (scattered/spread) suggests involuntary, organic radiance — not a metaphorical "hope" imposed by the observer but an intrinsic luminosity arising *from* her condition. The phrase "u'ojrk osQ nkx ls" (from the sparkle of novelty/wonder) locates the light in the girl's *perception*, not her circumstances. An incomplete answer treats imagery as decoration; a complete answer traces how the poet transforms a marker of poverty (lwjt) into evidence of the girl's uncolonized joy, making her the agent of her own radiance.

## DIAGNOSTIC_QUESTION_3
Apply the "PEEL" structure (Point, Evidence, Explanation, Link) to analyze *one* metaphor from "nhi vosQyk" that redefines the nose's social meaning. Write a full paragraph.

## DIAGNOSTIC_ANSWER_3
**Point:** The metaphor "xhr" (plough) and "eksrh" (farmer's wife) in stanza 2 redefines the nose as an instrument of labor and partnership, not ornament.  
**Evidence:** "iuMqCckµ;s eksrh lPps fiQj dkSu Ñrh yk,xk\" ;g lfeèkkµ,slh vkx gBhyk fcjyk lqyxk,xkA"  
**Explanation:** "xhr" (plough) evokes the nose as a tool that furrows the earth — essential, grounded, productive. "eksrh" (farmer's wife) positions it as a lifelong companion in sustenance. The rhetorical question "dkSu Ñrh yk,xk?" (who else could bear it?) challenges the reader: if you dismiss this nose, you dismiss the labor it represents. The simile "lfeèkkµ,slh vkx" (breath like this) equates the nose's breath with the rhythm of work.  
**Link:** This metaphor shifts valuation from *aesthetic conformity* (straight, sharp nose) to *functional dignity* — the nose as proof of a life that works, endures, and feeds others. A weak answer would merely label it "a metaphor for hard work" without unpacking the gendered pairing (xhr/eksrh) or the rhetorical challenge to the reader's prejudice.

## DIAGNOSTIC_QUESTION_4
Compare how the two poems construct the *agency* of their central subjects. The nose in poem 1 is addressed directly ("ij bldks Hkh iafDr dks ns nks"); the girl in poem 2 is observed ("eSaus ns[kk"). What does this difference in address mode reveal about each poem's theory of dignity?

## DIAGNOSTIC_ANSWER_4
Poem 1 uses *apostrophe* (direct address to the nose) and imperative ("ns nks" — give it to the present), positioning the nose as a *claimant* demanding recognition *now*. The refrain "iafDr dks ns nks" makes dignity a present-tense right, not a future reward. Poem 2 uses *witnessing* ("eSaus ns[kk" — I saw) and the girl's radiance is *self-generated* ("u'ojrk osQ nkx ls" — from the sparkle of her wonder). The speaker doesn't grant her dignity; he *records* its prior existence. Together, the poems argue: dignity is either *demanded* (poem 1, for the marginalized body part/identity) or *witnessed* (poem 2, for the marginalized child) — never bestowed. A student who misses the grammatical shift (imperative vs. perfective "ns[kk") conflates the poems' distinct political strategies.

## DIAGNOSTIC_QUESTION_5
Evaluate this claim: "Nagarjun's 'nhi vosQyk' is a body-positivity poem before its time." Support or refute using *two* specific textual strategies from the poem.

## DIAGNOSTIC_ANSWER_5
**Supported, with nuance.** Strategy 1: *Re-semanticization of descriptors* — "Lusg" (small), "xoZ" (crooked/askew), "enekrk" (unique/peerless) are reclaimed from stigma to pride via the refrain. The poem doesn't just say "it's okay"; it assigns *positive value* to the very traits society mocks. Strategy 2: *Expansive metaphorical mapping* — each stanza maps the nose to a new role (xhr/eksrh, vf}rh;/esjk, eèkq/xksjl/vaoqQj, izÑr/Lo;aHkw/czã/v;qr) covering agriculture, identity, survival, spirituality. This proliferation refuses a single "correct" nose shape, insisting multiplicity *is* the norm. However, "body-positivity" risks depoliticizing the poem: Nagarjun links the nose to *labor* (xhr), *survival* (vaoqQj — protecting the flame), and *collective history* (v;qr — ten generations). The dignity claimed is *structural*, not merely personal. A refutation that ignores the political-economic metaphors (eèkq, xksjl, vaoqQj) reduces the poem to a self-help slogan.

## DIAGNOSTIC_QUESTION_6
Write a 4-line stanza in Nagarjun's style (refrain + new metaphor pair) for a *different* stigmatized body feature (e.g., dark skin, scar, limp). Your stanza must follow the poem's rhyme scheme (AABB/CCDD) and end with "ij bldks Hkh iafDr dks ns nks."

## DIAGNOSTIC_ANSWER_6
Example for a scar (dM+q):  
;g dM+q gSµthou dh nwèk] ;g dM+q gSµvkRe dh cUnA  
;g nq%[k gSµizkIr dh] ;g lq/k gSµvusd dUnAA  
;g dM+q] nq%[k] lq/k Hkjk gS] xoZ Hkjk enekrk]  
ij bldks Hkh iafDr dks ns nksA  
**Criteria for a good answer:** (1) Maintains the refrain exactly, (2) Uses two metaphorical identities (here: nwèk/cUn, nq%[k/lq/k) that *revalue* the feature, (3) Rhymes in couplets (nwèk/cUn, dUn/lq/k — approximate), (4) Ends with the imperative demand. A poor answer either breaks the refrain, uses clichés without revaluation (e.g., "scar is beautiful"), or misses the poem's insistence on *functional/historical* metaphors over aesthetic ones.

## COMMON_MISCONCEPTION
Students treat "character analysis" in poetry as describing *personality traits* (kind, brave, sad) of the speaker or subject, as they would for a novel protagonist. They write: "The nose is confident because it says 'give it to the present.'" This misses that *poetic characterization works through metaphor, address mode, and structural repetition* — the nose doesn't "have" confidence; the poem *constructs* its confidence through the imperative refrain and the accumulation of metaphors. The error stems from importing prose-novel frameworks into lyric poetry, where "character" = a pattern of linguistic choices, not a psychological interior.

## ON_FAILURE
1. Have the student read *only* the refrain of "nhi vosQyk" five times aloud, noting the shift from statement ("gS") to command ("ns nks").  
2. Give them a two-column table: Column A = metaphor from poem (xhr, eèkq, izÑr, etc.); Column B = what social role/value that metaphor *claims* for the nose. Fill 3 rows together.  
3. Ask: "If the poem described the nose as 'sundar' (beautiful) instead of 'Lusg/xoZ/enekrk,' what political work would be lost?" Guide them to: it would concede the opponent's vocabulary.  
4. Re-attempt DIAGNOSTIC_QUESTION_4 with the table as scaffold.

## BUILDS_ON
Class 11 Character Analysis: Protagonist (c11_hin_ar_cbse_01_004) where students learned to track character through action, dialogue, and authorial description in prose narratives.

## LEADS_TO
Character Analysis: Supporting Characters (c12_hin_a_cbse_03_005) — though these poems have no supporting characters, the skill transfers to analyzing *voices* in dramatic monologues and multi-speaker poems in later chapters.

## PREREQUISITE_NODE_IDS
c12_hin_a_cbse_03_001, c12_hin_a_cbse_03_002, c11_hin_ar_cbse_01_004, c11_hin_v_cbse_01_004, c12_hin_a_cbse_03_003

## PREREQUISITE_REASONS
c12_hin_a_cbse_03_001: Provides biographical/historical context for Nagarjun's Marxist-humanist lens, essential to reading the nose/girl as political subjects.  
c12_hin_a_cbse_03_002: Establishes narrative structure (stanza progression, refrain function) needed to analyze how characterization unfolds across the poem.  
c11_hin_ar_cbse_01_004: Introduced character analysis terminology (traits, motivation, arc) which must be *unlearned/adapted* for poetic persona.  
c11_hin_v_cbse_01_004: Prior practice with poetic persona in Class 11 Vitan poems (e.g., "Bharat Mata") bridges to this more complex dual-poem analysis.
c12_hin_a_cbse_03_003: The speaker in both poems is defined by their response to setting — the collective "we" in "nhi vosQyk" and the solitary "I" in "eSaus ns[kk]" — character analysis requires this setting-attitude link.  

## FORWARD_NODE_IDS
c12_hin_a_cbse_03_005, c12_hin_a_cbse_03_006, c12_hin_a_cbse_03_013, c12_hin_a_cbse_03_008, c12_hin_a_cbse_03_012

## FORWARD_REASONS
c12_hin_a_cbse_03_005: The "no supporting characters" realization in this node prepares students to analyze *absent* voices (society, beauty norms) as implicit antagonists in the next node.  
c12_hin_a_cbse_03_006: Characterization evidence (metaphors of labor, witnessing of joy) directly feeds theme extraction (dignity of labor, resistance to aesthetic fascism).  
c12_hin_a_cbse_03_013: Critical thinking node requires the close-reading habits (tracking refrain, address mode, metaphor clusters) built here.
c12_hin_a_cbse_03_008: Protagonist (the speaker/poet-persona) is the *tenor* of many metaphors — his voice shapes the vehicle.  
c12_hin_a_cbse_03_012: Protagonist analysis requires inferring motives  

## CROSS_SUBJECT_PREREQS
c11_hin_ar_cbse_03_004, c11_hin_ar_cbse_08_004, c11_hin_v_cbse_03_004
## CROSS_SUBJECT_REASONS
c11_hin_ar_cbse_03_004: Class 11 Antra Chapter 3 protagonist analysis (likely "Devsena" or similar) established baseline character-tracking in prose.  
c11_hin_ar_cbse_08_004: Class 11 Antra Chapter 8 protagonist analysis introduced poetic persona in a different poet's work.  
c11_hin_v_cbse_03_004: Class 11 Vitan Chapter 3 protagonist analysis (non-fiction/memoir) contrasts with lyric poetry's constructed persona.

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_01_004 -> c12_hin_a_cbse_03_004 -> c12_hin_a_cbse_03_006

## THIS_FORMULA
N/A - conceptual

## FORMULA_VARIABLES
N/A

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
conceptual

## CROSS_SUBJECT
N/A | Nagarjun's poems resist colonial/brahminical aesthetic standards (sharp nose, fair skin) — connects to History Chapter on "Social Reform Movements" where body politics were contested.  
 N/A | The "nhi" (small nose) and "cw¡n" (poor girl) represent bodies marked by caste/class/gender exclusion — applies Sociology concepts of "stigma" and "embodied inequality" to literary analysis.  
 N/A | The refrain "iafDr dks ns nks" (give it to the present) enacts a *rights-claiming* performative — links to Political Science "Rights as Claims" framework in Class 12.
## PREREQ_CONCEPT
Understanding that lyric poetry constructs "character" through *linguistic patterns* (refrain, address, metaphor clusters) rather than narrative actions.

## PREREQ_BEFORE
Student must recognize the refrain structure in "nhi vosQyk" and the witnessing frame in "eSaus ns[kk] ,d cw¡n" — i.e., have completed nodes 001 (context) and 002 (plot/structure).

## PREREQ_STUCK
If stuck, return to c12_hin_a_cbse_03_002 and map the stanza-by-stanza progression of metaphors in "nhi vosQyk" — characterization *is* that progression.

## WORKED_EXAMPLE_1
PROBLEM: Analyze how the metaphor cluster in Stanza 3 of "nhi vosQyk" ("eèkq," "xksjl," "vaoqQj") characterizes the nose as a site of *survival* rather than beauty. Use PEEL structure.

STEPS:
- Step 1: Identify the three metaphors in Stanza 3 — "eèkq" (flame/lamp), "xksjl" (life-breath/lifeline), "vaoqQj" (protector of flame) — and note they form a semantic field of *sustenance and preservation*.
- Step 2: Retrieve the Hindi glosses: eèkq = "Lo;a dky dh ekSuk dk ;qx&lap;" (curl of the flame of the household lamp), xksjl = "thou&dkeèksuq dk ve`r&iwr i;" (vein/pulse of life-activity), vaoqQj = "iQksM+ èkjk dks jfo dks rdrk fuHkZ;" (one who makes the lamp's flame burn steadily).
- Step 3: Explain the shift from Stanza 2 (labor/partnership) to Stanza 3 (survival/continuity) — the nose is no longer just *working*; it is *keeping alive* the fragile flame of domestic existence. "vaoqQj" is transitive: the nose *acts on* the flame.
- Step 4: Link to characterization — the nose emerges as a *guardian of continuity*, not a passive feature. The imperative "bldks Hkh 'kfDr dks ns nks" (give this too to the present) demands recognition of this guardianship *now*.
- Step 5: Connect to whole-poem arc — Stanza 4 will elevate this to lineage ("v;qr" — ten generations), making the nose a vessel of *intergenerational survival*.

REASONING: The PEEL structure forces the student to move from lexical identification (Step 1-2) to semantic analysis (Step 3) to character-level synthesis (Step 4) to structural positioning (Step 5) — mirroring how the poem itself builds the nose's persona cumulatively.

ANSWER: The nose in Stanza 3 is characterized as the unsung sustainer of domestic life. The metaphors "eèkq" (flame-curl), "xksjl" (life-pulse), and "vaoqQj" (flame-keeper) form a tight semantic cluster: the nose tends the fragile fire that is the household's continuity. Unlike Stanza 2's agricultural metaphors (production), these are *preservation* metaphors — the nose ensures the flame doesn't die. The command "bldks Hkh 'kfDr dks ns nks" insists this sustaining role be acknowledged in the present, not romanticized in memory. This shifts the nose's characterization from "worker" to "guardian of existence itself."

## WORKED_EXAMPLE_2
PROBLEM: In "eSaus ns[kk] ,d cw¡n," the speaker says "lwus fojkV~ osQ lEeq[k gj vkyksd&Nqvk viukiu gS mUekspu u'ojrk osQ nkx ls!" Analyze how the *syntax* of this sentence (especially "viukiu" and "mUekspu") constructs the girl's agency.

STEPS:
- Step 1: Parse the sentence structure — main clause: "gj vkyksd&Nqvk viukiu gS mUekspu" (the very shine of the full moon is [being] eclipsed/dimmed), causal phrase: "u'ojrk osQ nkx ls" (from the sparkle of novelty/wonder).
- Step 2: Focus on "viukiu" (reflexive pronoun, "its own self") — it appears *before* the verb "gS," emphasizing the moon's shine as *intrinsic property* now being compromised.
- Step 3: Analyze "mUekspu" (causative passive of "mUek" = to dim/eclipse) — the moon's light isn't fading; it's *being dimmed* by something stronger. The agent of dimming is "u'ojrk osQ nkx" (the girl's wonder-sparkle).
- Step 4: Characterize the girl — she doesn't "outshine" the moon actively; her *innocent perception* ("u'ojrk") *compels* nature to yield. Her agency is *epistemic*: her way of seeing reorders reality.
- Step 5: Contrast with poem 1 — the nose *demands* recognition ("ns nks"); the girl *obliterates* the benchmark (moon) by simply seeing with wonder. Both reject external standards, but the girl's method is pre-linguistic, pre-political.

REASONING: This example teaches students to read *grammar as characterization* — the causative passive "mUekspu" and reflexive "viukiu" are not decorative; they encode the poem's theory of the child's power.

ANSWER: The syntax positions the girl's wonder ("u'ojrk") as an active force that *causes* the moon's intrinsic shine ("viukiu gj") to be eclipsed ("mUekspu"). She doesn't compete; her perception rewrites the hierarchy of light. The moon, symbol of conventional beauty/purity, yields to the "nkx" (sparkle) of a poor child's unconditioned gaze. Her agency is ontological: by seeing the world as new ("u'ojrk"), she makes it new.

## WORKED_EXAMPLE_3
PROBLEM: Synthesize a cross-poem argument: How do the two poems together define "dignity" for the marginalized? Use evidence from both poems' *closing moves* (refrain in poem 1; final image in poem 2).

STEPS:
- Step 1: Isolate poem 1's closing move — the refrain "ij bldks Hkh iafDr dks ns nks" repeated four times, each time after a new metaphorical identity. The repetition *is* the argument: dignity = present-tense recognition of multiplying identities.
- Step 2: Isolate poem 2's closing move — "u'ojrk osQ nkx ls" (from the sparkle of wonder/novelty) as the *source* of the girl's radiance. The poem ends on her perception, not her poverty.
- Step 3: Identify the shared structure — both poems *refuse the deficit frame*. Poem 1: "Lusg/xoZ" are not lacks but "enekrk" (peerless). Poem 2: "lwjt" (spittle/poverty) is not shame but the medium of "jax xbZ {k.kHkj" (scattered smile-light).
- Step 4: Define dignity synthetically — Dignity = the *capacity to generate value from within one's marked condition*, coupled with the *demand/witness* that this value be recognized *now* (iafDr).
- Step 5: Note the political distinction — Poem 1 addresses the *oppressor* ("iafDr dks ns nks" = give it to the present/power). Poem 2 addresses the *reader-witness* ("eSaus ns[kk" = I saw, now you see). Dignity requires both *self-valuation* and *public acknowledgment*.
- Step 6: Connect to Nagarjun's Marxist-humanism (from node 001) — the poems enact "Lora=krk" (independence/autonomy) of the oppressed subject: not granted, but *performed* (poem 1) and *witnessed* (poem 2).

REASONING: This multi-step synthesis models the "Critical Thinking" competency (node 013) — moving from textual evidence to conceptual abstraction to political framing, exactly what board exam 6-mark questions and CUET literary analysis demand.

ANSWER: Together, the poems define dignity as a two-sided act: (1) *Self-valuation* — the marginalized subject (nose/girl) generates worth from their stigmatized condition via metaphor (nose as xhr/vaoqQj) or perception (girl's u'ojrk); (2) *Public claim/witness* — poem 1's imperative "iafDr dks ns nks" demands the present/power recognize this worth *now*; poem 2's "eSaus ns[kk" positions the reader as witness to a worth that *pre-exists* recognition. Dignity is not bestowed; it is *performed* (poem 1) and *attested* (poem 2). The nose says "I am xhr, eèkq, izÑr — recognize me." The girl says nothing; her wonder speaks. Both refuse the deficit gaze.

## COMPETENCY_QUESTION_1
QUESTION: A Class 12 student writes this answer to "How does Nagarjun characterize the 'nhi' in 'nhi vosQyk'?" — "The poet calls the nose small, crooked, and unique. He compares it to a plough, a farmer's wife, a flame, and a life-pulse. This shows the nose is important for poor people. The refrain repeats so we remember it." Identify *three* specific weaknesses in this answer relative to board exam marking scheme expectations, and rewrite it as a 4-mark response.

COMPETENCY
Textual evidence integration and analytical depth

STEPS:
- Step 1: Identify weakness 1 — lists metaphors without analyzing *how* each revalues the nose (no "Explanation" in PEEL).
- Step 2: Identify weakness 2 — "important for poor people" reductively biographizes the poem; misses the *universalizing* move (v;qr = ten generations, izÑr = spiritual).
- Step 3: Identify weakness 3 — treats refrain as memory aid ("so we remember it") not as *performative demand* ("iafDr dks ns nks").
- Step 4: Rewrite using PEEL for *two* metaphor clusters + refrain analysis, with precise terminology (apostrophe, semantic field, imperative mood).

ANSWER:
**Weaknesses:** (1) Metaphor list without semantic analysis — "plough/farmer's wife" not linked to labor dignity; "flame/life-pulse" not linked to survival. (2) "Important for poor people" imposes extrinsic biography; the poem's metaphors span agriculture, domesticity, spirituality, lineage — the nose represents *human* dignity, not only poverty. (3) Refrain misread as mnemonic; it is an *imperative address* to the present/power ("iafDr dks ns nks" = give it to the now), enacting a rights-claim.

**Rewritten 4-mark response:**  
Nagarjun characterizes the "nhi" through a *cumulative metaphorical architecture* that revalues stigmatized traits into sites of dignity. Stanza 2's "xhr/eksrh" (plough/farmer's wife) embeds the nose in *productive labor* — it furrows and sustains. Stanza 3's "eèkq/xksjl/vaoqQj" (flame-curl/life-pulse/flame-keeper) shifts to *preservation* — the nose guards the fragile continuity of domestic life. The refrain "ij bldks Hkh iafDr dks ns nks" (give this too to the present), repeated in the imperative mood via apostrophe, transforms description into *demand*: dignity is a present-tense right, not a retrospective honor. The nose's characterization thus moves from labor → survival → lineage (stanza 4's "v;qr") → spiritual autonomy ("izÑr/Lo;aHkw"), refusing any single reductive identity.

DIFFICULTY
medium

## COMPETENCY_QUESTION_2
QUESTION: "The girl in 'eSaus ns[kk] ,d cw¡n' has no voice — she is only seen, never heard. Therefore, the poem silences her." Evaluate this feminist reading. Does the poem's *form* (structure, imagery, verb choices) support or undermine the claim? Write a structured argument with 3 textual anchors.

COMPETENCY
Critical evaluation of interpretive claims using formal evidence

STEPS:
- Step 1: Acknowledge the surface validity — the girl speaks zero lines; the speaker is male ("eSaus" — I saw).
- Step 2: Anchor 1 — Verb "xbZ" (scattered/spread) in "jax xbZ {k.kHkj" is *intransitive*; the smile-light spreads *from her face* without external cause. She is the *source*, not the object.
- Step 3: Anchor 2 — "u'ojrk osQ nkx" (sparkle of wonder/novelty) locates agency in her *perception*. "u'ojrk" (newness/wonder) is an epistemic stance: she sees the world as new, unburdened by prejudice. The moon is eclipsed *by her gaze* (mUekspu).
- Step 4: Anchor 3 — The poem's *frame* ("eSaus ns[kk") is a *witnessing act*, not a ventriloquism. The speaker does not *give* her voice; he *clears space* for her radiance to be recorded. The final exclamation "u'ojrk osQ nkx ls!" centers her wonder as the poem's *source of truth*.
- Step 5: Conclude — The poem does not "give voice"; it *refuses to speak for her*. Her silence is not absence but *presence* — the "nkx" (sparkle) that outshines the moon. A feminist reading must distinguish *silencing* (erasure) from *strategic witnessing* (recording unmediated agency).

ANSWER:
The claim mistakes *absence of speech* for *absence of agency*. Three formal anchors refute it: (1) **Intransitive radiance** — "jax xbZ {k.kHkj" (the smile-light scattered) uses "xbZ" intransitively: the light emanates *from her*, uncaused. She is luminous *by nature*, not by the speaker's gaze. (2) **Epistemic sovereignty** — "u'ojrk osQ nkx" (sparkle of wonder) makes her *perception* the active force that "mUekspu" (eclipses) the moon, symbol of patriarchal/aesthetic authority. Her wonder rewrites the world. (3) **Witnessing, not ventriloquism** — The frame "eSaus ns[kk" (I saw) positions the speaker as *recorder*, not author. The poem ends on *her* "nkx," not his insight. The form enacts: dignity = being seen *as you are*, not being made to speak *as we want*. The poem silences the *speaker's* interpretation to let the girl's wonder speak.

DIFFICULTY
hard