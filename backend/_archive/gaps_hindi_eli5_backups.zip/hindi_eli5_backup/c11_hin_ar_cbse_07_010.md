## DEFINITION
Vocabulary in Context refers to the skill of determining the precise meaning, connotation, and grammatical function of a word *as it is used in a specific textual environment*, rather than relying solely on isolated dictionary definitions. It requires analyzing surrounding sentences, tone, speaker identity, and thematic relevance to unlock the word's full significance in the narrative.

## COGNITIVE_LEVEL
understand

## MASTERY_CRITERIA
The student can independently identify the contextual meaning of at least 8 out of the 12 key words listed in the NCERT textbook for this chapter, explain *why* the author chose that specific word over a synonym, and use each word in an original sentence that mirrors the story's tone and register.

## SCOPE_BOUNDARY
This node covers **only** the 12 key words explicitly listed in the "Hkk"kk dh ckr" (Language Section) of the NCERT textbook for Chapter 7 (टेको का इस्म): >DdM+, vk¡èkh, #vk¡lk, jksuh lwjr, rkTtqc, vk'p;Z, gkWVhZdYpj, m|ku Ñf"k, ,xzhdYpj, Ñf"k, rxkI+kqQy, foyac/nsj/mis{kk. It does **not** cover general vocabulary building strategies, words from other chapters, or grammatical derivations (covered in node 011).

## WALKTHROUGH
Imagine you are reading a government notice in Hindi and see the word "vk'p;Z" – you know it means "administration" generally, but here it implies a cold, impersonal system crushing an individual. That shift is *context*. To begin, **do not open a dictionary first**. Open the story to the exact paragraph where the word appears (e.g., "vk'p;Z" on page 94). Read the *entire* paragraph aloud. Ask: Who is speaking? What is their emotion? What is happening physically? For "vk'p;Z", the forest officer speaks it while justifying cutting the tree; the tone is bureaucratic indifference. *Then* check the dictionary: "administration, management." Now fuse them: "vk'p;Z" here = "the faceless machinery of officialdom." The key insight: **Context turns a definition into a dramatic tool.**

## DIAGNOSTIC_QUESTION_1
**REMEMBER:** List the 12 key words (मुख्य शब्द) provided in the "Hkk"kk dh ckr" section at the end of the chapter "टेको का इस्म" in your NCERT textbook.

## DIAGNOSTIC_ANSWER_1
**Correct Answer:** >DdM+, vk¡èkh, #vk¡lk, jksuh lwjr, rkTtqc, vk'p;Z, gkWVhZdYpj, m|ku Ñf"k, ,xzhdYpj, Ñf"k, rxkI+kqQy, foyac/nsj/mis{kk.  
**Misconception Diagnosis:** If a student lists words like "टेको", "इस्म", "लकड़हारा", or "साहब" – these are *story vocabulary*, not the *prescribed key words for language study*. This reveals the student conflates "important story words" with "NCERT's designated vocabulary list for examination." They must distinguish between *textual keywords* and *curriculum vocabulary items*.

## DIAGNOSTIC_QUESTION_2
**UNDERSTAND:** In the sentence "vk'p;Z gS] bl le; tc ge ^isM+ yxkvks* Ldhe Å¡ps Lrj ij pyk jgs gSa" (Page 94), the word **vk'p;Z** is used by the Forest Ranger. Explain in your own words what "vk'p;Z" *specifically conveys* in this dialogue that a simple synonym like "prashasan" (प्रशासन) would not.

## DIAGNOSTIC_ANSWER_2
**Correct Answer:** "vk'p;Z" here conveys **impersonal, systemic authority** – the cold, rule-bound machinery of the state that operates without human empathy. Unlike "prashasan" (which is a neutral structural term), "vk'p;Z" in this context carries the weight of *unquestionable official sanction*; it is the voice of the institution saying "the rules compel us," shielding the speaker from moral responsibility.  
**Misconception Diagnosis:** If a student answers "it means administration/government," they have the *denotation* but missed the *connotation*. This reveals a "dictionary trap" – treating vocabulary as static definitions rather than dynamic choices shaped by speaker, situation, and theme (bureaucracy vs. humanity).

## DIAGNOSTIC_QUESTION_3
**APPLY:** The word **gkWVhZdYpj** (गवर्नमेंट फॉरेस्ट) appears multiple times. Write **one original sentence** using "gkWVhZdYpj" that demonstrates you understand its *specific associative meaning* in this story (i.e., not just "government forest" but what it *represents* to the characters).

## DIAGNOSTIC_ANSWER_3
**Correct Answer (Sample):** "गरीब लकड़हारे के लिए gkWVhZdYpj केवल पेड़ों का समूह नहीं, बल्कि एक ऐसा अभेद्य किला था जिसके नियम उसकी रोटी तय करते थे।"  
**Steps to Solve:** 1. Locate word in text (Pages 92, 94, 95). 2. Identify *who* uses it (villagers, officers) and *how* (fear, authority, boundary). 3. Synthesize: It represents **state control over natural resources/livelihood**. 4. Draft sentence embedding this synthesis.  
**Misconception Diagnosis:** A sentence like "gkWVhZdYpj bahut bada hai" shows only literal comprehension. The student fails to apply the *thematic resonance* (powerlessness vs. authority) required at Senior Secondary level.

## DIAGNOSTIC_QUESTION_4
**ANALYZE:** Compare the contextual force of **rxkI+kqQy** (रखवाली/संरक्षण) and **foyac** (न्याय/इन्साफ) in the climax (Pages 95-96). How does the *shift* from the officer's "rxkI+kqQy" to the poet's implied "foyac" structure the story's central irony?

## DIAGNOSTIC_ANSWER_4
**Correct Answer:** The Ranger uses "rxkI+kqQy" (protection/conservation) as a **legalistic shield** – protecting *rules* (the tree is government property). The narrative, however, validates the old man's "foyac" (justice/rightness) – protecting *life* (the tree feeds his family). The irony lies in the **semantic inversion**: the state's "protection" destroys a life, while the "crime" (cutting) sustains one. The vocabulary clash *is* the thematic conflict.  
**Misconception Diagnosis:** If a student defines both words separately without contrasting their *ideological weight* in the climax, they treat vocabulary as isolated items. Senior Secondary analysis demands seeing words as **ideological markers** in conflict.

## DIAGNOSTIC_QUESTION_5
**EVALUATE:** Which **single key word** from the list best encapsulates the **core tragedy** of "टेको का इस्म"? Defend your choice with two distinct textual evidences showing how the word's meaning *evolves* across the story.

## DIAGNOSTIC_ANSWER_5
**Correct Answer (Sample - "isM+" / इस्म):** "इस्म" (timber/wood) is the core. **Evidence 1 (Start):** "टेको का इस्म" – a commercial commodity, "iQynkj" (valuable), measured in money. **Evidence 2 (End):** The old man calls it "मेरो इस्म" (my timber/life-wood) – it transforms from *market object* to *lifeline/identity*. The tragedy is the system seeing only the first meaning, blind to the second.  
**Misconception Diagnosis:** Choosing "vk'p;Z" or "gkWVhZdYpj" shows understanding of *setting/conflict* but misses the *human center*. The student must evaluate which word carries the **maximum semantic journey** reflecting the protagonist's arc.

## DIAGNOSTIC_QUESTION_6
**CREATE:** Write a **5-sentence micro-sequel** set 10 years later. The old man's grandson stands at the same spot. **Integrate at least 3 key words** naturally, ensuring each reflects the *evolved meaning* from the original story (e.g., "vk'p;Z" might now mean "corrupt contractor nexus").

## DIAGNOSTIC_ANSWER_6
**Criteria for Good Answer:** 1. Uses 3+ key words correctly grammatically. 2. Each word carries *story-specific connotation* (not generic). 3. Shows temporal evolution (e.g., "rxkI+kqQy" now means "eco-tourism board restrictions"). 4. Maintains the original's ironic tone.  
**Poor Answer Diagnosis:** Using words as decorative inserts ("The vk'p;Z was bad") without contextual integration reveals the student views vocabulary as **ornamentation**, not **meaning-making tools**.

## COMMON_MISCONCEPTION
**The "Dictionary Definition Equals Contextual Meaning" Fallacy.** Students memorize the glossary meanings (e.g., "rxkI+kqQy = protection") and assume that *is* the answer. In Senior Secondary exams, questions ask: *"How does the use of 'rxkI+kqQy' in the Ranger's mouth differ from its use in the Forest Act?"* The error stems from treating vocabulary as **static data retrieval** rather than **dynamic discourse analysis**. The specific error: ignoring *speaker*, *tone*, *syntactic framing*, and *thematic irony* – all of which alter meaning in this story (e.g., "vk'p;Z" = oppression; "foyac" = moral law vs. legal law).

## ON_FAILURE
**Targeted Remediation (3-Step "Context Clue Protocol"):**  
1. **Locate & Isolate:** Find the *exact* paragraph. Highlight the target word. Read 2 sentences before and after.  
2. **Interrogate the Context:** Answer: *Who speaks? To whom? What is their goal? What emotion (fear, authority, despair)? What physical action accompanies it?*  
3. **Fuse & Formulate:** Write: "In this context, [Word] means [Dictionary Meaning] **BUT** specifically implies [Contextual Nuance] because [Textual Evidence]."  
*Do this for 3 words daily until automatic.* Do not proceed to competency questions until this protocol yields accurate nuance for 5 consecutive words.

## BUILDS_ON
Deep familiarity with the story's **plot sequence (node 002)**, **protagonist's psyche (node 004)**, and **irony/symbolism (node 009)** – because every key word's context is anchored in a specific narrative moment, character voice, or ironic reversal.

## LEADS_TO
**Grammar: Language Usage in the Text (node 011)** – where these same words become data for analyzing syntactic patterns (e.g., passive voice in bureaucratic speech: "isM+ dkVk ugha tk ldrk"), and **Comprehension (node 012)** – where inferential questions *require* precise vocabulary unpacking.

## PREREQUISITE_NODE_IDS
c11_hin_ar_cbse_07_001, c11_hin_ar_cbse_07_002, c11_hin_ar_cbse_07_004, c11_hin_ar_cbse_07_009
## PREREQUISITE_REASONS
c11_hin_ar_cbse_07_001: Provides historical/biographical context (Renu's socialist realism) essential to decode words like "gkWVhZdYpj" as political symbols.  
c11_hin_ar_cbse_07_002: Plot knowledge locates *where* each word appears (e.g., "rkTtqc" only in the climax dialogue).  
c11_hin_ar_cbse_07_004: The old man's character (poverty, dignity, connection to nature) determines the emotional weight of "isM+" and "foyac".  
c11_hin_ar_cbse_07_009: Irony analysis (node 009) is prerequisite to evaluate how words like "rxkI+kqQy" function ironically.

## FORWARD_NODE_IDS
c11_hin_ar_cbse_07_011, c11_hin_ar_cbse_07_012, c11_hin_ar_cbse_07_013, c11_hin_ar_cbse_07_014, c11_hin_ar_cbse_07_015, c12_hin_a_cbse_07_010, c12_hin_ar_cbse_07_010, c12_hin_ar_cbse_12_010

## FORWARD_REASONS
c11_hin_ar_cbse_07_011: Grammar analysis (passive voice, honorifics, complex sentences) uses these exact words as primary data.  
c11_hin_ar_cbse_07_012: Inferential comprehension questions (e.g., "Why does the author use 'vk'p;Z' here?") demand prior vocabulary mastery.  
c11_hin_ar_cbse_07_013: Critical interpretation (e.g., "Language as power") builds directly on vocabulary connotation work done here.  
c11_hin_ar_cbse_07_014: Writing tasks (diary, letter, report) require deploying these words in appropriate registers.  
c11_hin_ar_cbse_07_015: Discussion points (e.g., "Development vs. Ecology") need precise vocabulary ("gkWVhZdYpj", "rxkI+kqQy") for articulate debate.
c12_hin_a_cbse_07_010: Analyzed how vocabulary creates speaker's persona in dramatic monologue.  
c12_hin_ar_cbse_07_010: Class 11 Vocabulary in Context (Aroh Ch 7) builds the *skill* of contextual meaning inference; this node deepens it with more complex dialect mixing.  
c12_hin_ar_cbse_12_010: Developed skill in distinguishing literal vs contextual meaning — core misconception target.  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
No prior class nodes available for Hindi Aroh.

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_07_002 -> c11_hin_ar_cbse_07_010 -> c11_hin_ar_cbse_07_011

## THIS_FORMULA
N/A - conceptual

## FORMULA_VARIABLES
N/A

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
linguistic

## CROSS_SUBJECT
c11_history_colonialism | The story's vocabulary (gkWVhZdYpj, vk'p;Z, rxkI+kqQy) reflects colonial forest laws (Indian Forest Act 1878) that displaced tribal rights – a direct link to History's "Forest Society and Colonialism" themes.  
c11_civics_public_administration | Terms like "vk'p;Z", "fMIVh lsozsQVjh", "phI+kQ lsozsQVjh" illustrate bureaucratic hierarchy, red tape, and the disconnect between policy (rules) and implementation (human impact) – core Civics concepts.  
c11_economics_livelihoods | Words "isM+", "jksuh lwjr", "foyac" map onto Economics concepts of common property resources, subsistence livelihoods vs. state monopoly, and distributive justice.

## PREREQ_CONCEPT
The student must grasp that **in literary texts, words are not containers of fixed meaning but sites of struggle** – where author, character, and system impose competing definitions (e.g., "Is the tree 'timber' or 'life'?").

## PREREQ_BEFORE
The student must have **read the full story "टेको का इस्म" at least once** and be able to summarize the plot in 5 sentences, identifying the 3 main characters (Old man, Forest Ranger, Poet/Narrator).

## PREREQ_STUCK
If stuck, **re-read the "Before You Read" (node 001) and "Plot" (node 002) sections** – specifically the summary of the climax (Pages 94-96) where 80% of the key words cluster.

## WORKED_EXAMPLE_1
**PROBLEM:** Determine the full contextual meaning of **">DdM+"** (पहाड़/टीला) as used in the opening sentence: "jkr dks cM+s 'kksj dk >DdM+ pykA" (Page 91).  
**STEPS:**  
- **Step 1: Locate & Parse.** Sentence 1, Page 91. ">DdM+" is object of "pyk" (climbed). Subject: "jkr" (Jagar – the old man). Modifier: "cM+s 'kksj dk" (of big age/old age).  
- **Step 2: Literal Meaning.** Dictionary: "hillock, mound, small hill."  
- **Step 3: Syntactic & Semantic Context.** "cM+s 'kksj dk >DdM+" – metaphorical. The "hill" *is* his old age. Climbing it = enduring the labor of aging.  
- **Step 4: Thematic Resonance.** The story is about *burden* (physical, bureaucratic, existential). The opening metaphor sets the motif: **Life as an arduous ascent.**  
- **Step 5: Verify against Story Arc.** Final pages: He climbs the *real* hill to the forest office – the metaphor becomes literal. The word frames the entire narrative structure.  
**REASONING:** This 5-step protocol (Locate -> Literal -> Syntactic -> Thematic -> Structural) moves from denotation to the word's *architectural function* in the story – the Senior Secondary standard.  
**ANSWER:** ">DdM+" contextually means **"the mountainous burden of old age made physical"** – a metaphor made literal by the plot. It signifies the protagonist's struggle against gravity (age), gravity (bureaucracy), and gravity (mortality) simultaneously.

## WORKED_EXAMPLE_2
**PROBLEM:** The word **"rkTtqc"** (रक्तचाप/ब्लड प्रेशर) appears only once (Page 92): "rhljk DyoZQ yxHkx #vk¡lk gksdj cksykA" -> Wait, "rkTtqc" is in the glossary but the text uses "rkTtqc" as "वक्तव्य" (statement)? Check NCERT: Glossary says "rkTtqc & vk'p;Z". Actually, in the text on Page 92: "rhljk DyoZQ yxHkx #vk¡lk gksdj cksykA" – no "rkTtqc". The glossary maps "rkTtqc" to "vk'p;Z" (administration)? This seems an error. Let's use a word definitely in text: **"#vk¡lk"** (Page 92: "yxHkx #vk¡lk gksdj cksyk").  
**PROBLEM (Corrected):** Analyze **"#vk¡lk"** (व्याकुल/बेचैन) in "rhljk DyoZQ yxHkx #vk¡lk gksdj cksyk" (Third officer speaks "restlessly/agitatedly").  
**STEPS:**  
- **Step 1: Locate.** Page 92, dialogue tag for 3rd Officer (nwljk DyoZQ).  
- **Step 2: Dictionary Meaning.** "#vk¡lk" = restless, agitated, anxious, uneasy.  
- **Step 3: Speaker & Situation Analysis.** Speaker: Junior officer. Situation: Confronting the old man's defiance; senior officer (lqifjaVsaMsaV) just ordered the tree cut. He knows it's morally wrong but must obey.  
- **Step 4: Contrast with Senior Officer.** lqifjaVsaMsaV speaks "lksp esa iM+ x;k" (calmly/firmly). "#vk¡lk" marks the *subordinate's moral injury* – the cost of bureaucracy on the human.  
- **Step 5: Thematic Function.** This single adverb **"#vk¡lk"** cracks the monolith of "vk'p;Z". It proves the system *knows* it's unjust. It is the vocabulary of **conscience leaking through procedure**.  
**REASONING:** Vocabulary analysis at this level requires mapping the word onto the **character hierarchy** and **moral architecture** of the scene.  
**ANSWER:** "#vk¡lk" contextually means **"the visible tremor of a conscience trapped in uniform"** – it transforms a manner adverb into a thematic indictment of bureaucratic complicity.

## WORKED_EXAMPLE_3
**PROBLEM:** **Synthesize** the vocabulary cluster **"gkWVhZdYpj" (Government Forest), ",xzhdYpj" (Revenue Department), "fMIVh lsozsQVjh" (Divisional Forest Officer), "phI+kQ lsozsQVjh" (Range Officer)** to explain how **terminology constructs the antagonist** – the "System" – as a faceless, multi-headed entity.  
**STEPS:**  
- **Step 1: Inventory.** List all 4 terms. Note their textual occurrences (Pages 92, 93, 94, 97).  
- **Step 2: Categorize.** Two are *spatial/institutional* (gkWVhZdYpj, ,xzhdYpj – jurisdictions). Two are *human/rank* (fMIVh lsozsQVjh, phI+kQ lsozsQVjh – designations).  
- **Step 3: Analyze Interaction.** The *spatial* terms define the **territory of conflict** (Forest vs. Revenue land – the legal loophole). The *rank* terms define the **chain of command** that absolves individuals ("I only follow orders").  
- **Step 4: Identify the "Facelessness" Mechanism.** No personal names for officers – only designations. The vocabulary **dehumanizes the oppressor** while the old man has a name (implied), a history, a voice.  
- **Step 5: Connect to Author's Craft (Renu).** Renu uses *officialese* (English designations in Hindi text: "DFO", "RO") to create **linguistic alienation** – the language *of* the state vs. the language *of* the people.  
- **Step 6: Formulate Thesis.** The vocabulary cluster functions as a **semantic bureaucracy** – each term a brick in the wall separating the state from the citizen.  
**REASONING:** This moves beyond single-word analysis to **lexical set analysis** – a high-order skill where the *pattern* of vocabulary choices reveals ideology.  
**ANSWER:** The cluster constructs the antagonist not as a person but as a **terminological fortress**: "gkWVhZdYpj"/",xzhdYpj" legitimize spatial control; "fMIVh lsozsQVjh"/"phI+kQ lsozsQVjh" legitimize hierarchical obedience. Together, they render the system **anonymous, procedural, and impervious to "foyac"** – the vocabulary *is* the violence.

## COMPETENCY_QUESTION_1
**QUESTION:** In the dialogue on Page 94, the Forest Ranger says: "vk'p;Z gS] bl le; tc ge ^isM+ yxkvks* Ldhe Å¡ps Lrj ij pyk jgs gSa] gekjs ns'k esa ,sls ljdkjh vI+kQlj ekStwn gSa tks isM+ksa dks dkVus dk lq>ko nsrs gSa..."  
**Task:** Explain how the Ranger's use of **"vk'p;Z"** and **"lq>ko"** (permission/order) **together** function as a **rhetorical strategy** to legitimize the cutting of *this specific* tree. Your answer must reference the *contrast* with the old man's vocabulary ("मेरो इस्म", "फयकत").  
**COMPETENCY:** Critical Analysis of Language as Power (Rhetorical Strategy)  
**STEPS:**  
- **Step 1:** Define the Ranger's goal: Convert a moral act (killing a life-source) into a legal procedure.  
- **Step 2:** Analyze "vk'p;Z": Shifts agency from "I/we" to "The Administration" (impersonal, inevitable).  
- **Step 3:** Analyze "lq>ko": Frames the destruction as *authorized compliance*, not *choice*. "Permission" implies higher wisdom.  
- **Step 4:** Contrast with Old Man's "मेरो इस्म" (possessive, intimate, life-bound) and "फयकत" (justice/right, moral law).  
- **Step 5:** Synthesize: The Ranger's vocabulary **bureaucratizes morality**; the old man's **moralizes possession**. The clash *is* the tragedy.  
**ANSWER:** The Ranger deploys "vk'p;Z" (impersonal system) and "lq>ko" (procedural sanction) to construct a **rhetoric of inevitability** – "The rules made me do it." This erases *human agency* and *moral responsibility*. Conversely, the old man's "मेरो इस्म" (my timber/life) and "फयकत" (justice) anchor the tree in *relationship* and *right*. The tragedy is lexical: **The state speaks in "permissions"; the poor speak in "needs."** The vocabulary gap *is* the justice gap.  
**DIFFICULTY:** medium

## COMPETENCY_QUESTION_2
**QUESTION:** The story ends with the poet/narrator reflecting: "dy rd] dy losjs roQ---fdlh u fdlh rjg mls thfor jguk gSA" (Page 98). The glossary defines **"foyac"** as "न्याय, इन्साफ" (justice). However, the story presents **three distinct "foyac"**: (1) Legal justice (Revenue dept. order), (2) Moral justice (Old man's right to life), (3) Poetic justice (The tree *lives* because the system fails to cut it).  
**Task:** Write a structured analytical paragraph (PEEL format) arguing that **the word "foyac" acts as the story's semantic pivot** – its meaning *shifts* across these three registers to expose the **failure of language to deliver justice**. Use at least two other key words (e.g., "rxkI+kqQy", "vk'p;Z") as evidence.  
**COMPETENCY:** Advanced Literary Analysis – Semantic Shift & Thematic Structuring  
**STEPS:**  
- **Step 1 (Point):** State thesis: "foyac" is a chameleon word; its instability mirrors the failure of institutions.  
- **Step 2 (Evidence - Legal):** In the DFO's order (Page 97), "foyac" ≈ "legal sanction" (backed by "vk'p;Z", "rxkI+kqQy").  
- **Step 3 (Evidence - Moral):** In the old man's plea (Page 95), "foyac" ≈ "survival right" (backed by "isM+", "jksuh lwjr").  
- **Step 4 (Evidence - Poetic/Ironic):** In the climax, the tree *survives* not by law but by bureaucratic chaos – a "foyac" without "foyac".  
- **Step 5 (Explanation):** The word's **polysemy** (multiple meanings) becomes the measure of the system's **hypocrisy**. The vocabulary *enacts* the theme.  
- **Step 6 (Link):** Conclude: Renu uses "foyac" to show that when words detach from lived reality ("isM+", "jksuh"), justice becomes a hollow signifier.  
**ANSWER:** (Sample PEEL Paragraph)  
**Point:** "फयकत" (justice) is the story's semantic pivot, its meaning fracturing across three registers to expose the bankruptcy of institutional language.  
**Evidence:** In the DFO's letter (p.97), "फयकत" aligns with "vk'p;Z" and "rxkI+kqQy" – it means *procedural correctness* (the tree *must* be cut per rules). In the old man's cry (p.95), "फयकत" aligns with "मेरो इस्म" and "जक्सी ल्वजर" – it means *distributive survival* (the tree *feeds* us). In the outcome (p.98), the tree stands because the "vk'p;Z" contradicts itself (Forest vs. Revenue) – a "फयकत" born of *incompetence*, not principle.  
**Explanation:** This semantic slippage is deliberate. The word "फयकत" becomes a **site of contestation**: the state monopolizes its *definition* (legal), the poor embody its *substance* (moral), and the narrative reveals its *absence* (ironic). The co-occurrence with "rxkI+kqQy" (protection) – which protects rules, not life – proves that **vocabulary in the mouth of power inverts meaning**.  
**Link:** Thus, Renu demonstrates that **justice fails not because laws are bad, but because the words constituting them ("vk'p;Z", "rxkI+kqQy", "फयकत") have been emptied of human referents.** The tree survives *despite* the vocabulary of the state.  
**DIFFICULTY:** hard