## DEFINITION
Imagery is the use of vivid, sensory language that appeals to the five senses (sight, sound, smell, touch, taste) to create concrete mental pictures and physical sensations in the reader's mind. Metaphor is a figure of speech that makes an implicit, direct comparison between two unrelated things by stating one *is* the other, transferring the qualities of the vehicle (image) onto the tenor (subject) without using comparative words like "like" or "as".

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
Student can independently identify and categorize sensory imagery (visual, auditory, tactile, olfactory, gustatory) and metaphors in the chapter, deconstruct the tenor/vehicle relationship in at least two complex metaphors, and write a structured analytical paragraph explaining how these devices construct the protagonist's dignity and the story's social critique.

## SCOPE_BOUNDARY
This node covers identification, classification, and analytical interpretation of imagery and metaphor *specifically within the short story "vejdkar" (fe;k¡ ulh#íhu)*. It does not cover simile, personification, irony, or symbolism (addressed in node c11_hin_ar_cbse_02_009), nor does it teach general definitions without textual application.

## WALKTHROUGH
Imagine you are describing your grandmother's hands to a friend. You don't just say "they were old." You say: "The skin was thin as tissue paper, mapped with blue veins, smelling faintly of turmeric and mustard oil from a lifetime of cooking, rough pads pressing a cool cloth to my fevered forehead." That is imagery (visual, tactile, olfactory) and metaphor ("mapped with blue veins"). In "vejdkar," Ñ".kk lkscrh uses exactly this craft to make fe;k¡ ulh#íhu unforgettable. We will learn to hunt for sensory words in the text, sort them by sense, spot where the author says "A is B" (metaphor), and then ask: "What does this comparison reveal about her life that a plain statement cannot?" This moves you from spotting devices to analyzing *why* the author chose them—a core Board exam skill.

## DIAGNOSTIC_QUESTION_1
Define imagery and metaphor in your own words, giving one original example for each (not from the textbook).

## DIAGNOSTIC_ANSWER_1
**Correct Answer:** Imagery: Descriptive language appealing to senses (e.g., "The monsoon air smelled of wet earth and frying pakoras"). Metaphor: Direct comparison without 'like/as' (e.g., "The classroom was a pressure cooker before exams").  
**Wrong Answer Reveals:** If a student gives "Her smile was like sunshine" as a metaphor, they confuse simile with metaphor. If they only give visual examples for imagery, they lack awareness of multi-sensory description.

## DIAGNOSTIC_QUESTION_2
In the line *"ekSleksa dh ekj ls idk psgjk] vk¡[kksa esa dkb;k¡ Hkksykiu vkSj is'kkuh ij e¡ts gq, dkjhxj osQ rsoj"* (page 22), identify **three distinct sensory images** and the specific sense each appeals to.

## DIAGNOSTIC_ANSWER_2
**Correct Answer:** 1. *idk psgjk* (sweat dripping) – Visual + Tactile (wetness/heat). 2. *dkb;k¡ Hkksykiu* (rough lines) – Visual (deep creases) + Tactile (rough texture). 3. *dkjhxj osQ rsoj* (rage of hard skin) – Tactile (hardness) + Thermal (heat of anger).  
**Wrong Answer Reveals:** Listing only "sweat" and "lines" as visual imagery misses the tactile/thermal layers. Students often default to visual-only reading, ignoring how the author builds physical presence through touch and temperature.

## DIAGNOSTIC_QUESTION_3
Find a metaphor in the chapter **not** discussed in the walkthrough. Quote the phrase, identify the **tenor** (subject) and **vehicle** (image), and explain the **ground of comparison** (shared quality).

## DIAGNOSTIC_ANSWER_3
**Correct Answer (Example):** Phrase: *"rkyhe dh rkyhe gh cM+h ph”k gksrh gS"* (page 24). Tenor: The emotional hurt of a mother dismissed about her son's future. Vehicle: A physical wound. Ground: Just as even a tiny wound causes disproportionate pain and cannot be ignored, a "small" slight to her son's dignity is a massive injury to her maternal pride.  
**Steps:** 1. Locate a statement where A is equated to B. 2. Label Tenor (abstract) and Vehicle (concrete). 3. Articulate the shared attribute (pain/disproportion).  
**Wrong Answer Reveals:** Identifying *"fe;k¡ ulh#íhu"* as a metaphor (it's a nickname/character). Or stating the comparison is "she is hurt" without naming the two distinct domains (physical wound vs emotional insult).

## DIAGNOSTIC_QUESTION_4
Compare the **tactile imagery** of fe;k¡ ulh#íhu's hands in the opening kitchen scene (page 22) and the closing illness scene (page 28: *"fudkyh ranwj ls fuxyh vkSj g”ke"*). What does the **shift** from *active roughness* to *passive decay* reveal about her character arc and the story's theme?

## DIAGNOSTIC_ANSWER_4
**Correct Answer:** Opening: *Hkksykiu* (rough), *dkjhxj* (hard), *rsoj* (heat) → Hands as tools of skilled, proud labor; roughness = competence. Closing: *fuxyh* (withered), *g”ke* (dry/brittle), *xqe'kqnk* (trembling) → Hands as ruins of a used-up life; decay = societal discard. The shift traces the arc from **dignity through work** to **indignity through neglect**, making the theme of "invisible labor exploited" physically palpable.  
**Wrong Answer Reveals:** Describing both scenes separately without comparing the *change*. Missing that "roughness" was positive (skill) while "withered" is negative (abandonment). Failing to link the bodily change to the social critique.

## DIAGNOSTIC_QUESTION_5
Evaluate the effectiveness of the compound metaphor chain *"ckOkQj[kkuh&'khjeky&rkI+kQrku&csluh&[kehjh&:ekyh&xko&nhnk&xk”kscku&rqudh"* (page 27). Does piling up ten metaphors in one word **enhance** or **obscure** her characterization? Defend your judgment with two textual reasons.

## DIAGNOSTIC_ANSWER_5
**Correct Answer:** **Enhances.** Reason 1: The density mimics the narrator's overwhelmed realization—she cannot be reduced to a single label ("cook"). Reason 2: Juxtaposed opposites (*ckOkQj[kkuh* "fear-keeper" vs *nhnk* "soft"; *xko* "fire" vs *rqudh* "dust/earth") capture her paradoxical complexity—authoritative yet nurturing, fierce yet grounded—reflecting the story's argument that marginalized women contain multitudes.  
**Wrong Answer Reveals:** Calling it "confusing" or "too much" without analyzing the *function* of accumulation. Treating it as a vocabulary list rather than a rhetorical strategy. Missing the juxtaposition of binary opposites.

## DIAGNOSTIC_QUESTION_6
**Create** a 4-sentence character snapshot of a street vendor (e.g., *gol-gappe wala* or *chai-wala*) using: **two distinct sensory images** (different senses) and **one original metaphor**. Label each device in brackets.

## DIAGNOSTIC_ANSWER_6
**Expected Criteria:**  
- Sentence 1: Visual image [Visual Imagery] (e.g., "His cart, a pyramid of glowing brass pots, caught the sodium light [Visual Imagery].")  
- Sentence 2: Olfactory/Auditory/Tactile image [Olfactory Imagery] (e.g., "The air thrummed with the hiss of frying dough and the sharp perfume of cumin water [Auditory + Olfactory Imagery].")  
- Sentence 3: Metaphor [Metaphor] (e.g., "His hands were spiderwebs of oil-stained lines, weaving each plate with surgical speed [Metaphor].")  
- Sentence 4: Synthesis.  
**Poor Answer Reveals:** Using two visual images only. Using a simile ("hands *like* spiderwebs") instead of metaphor. Metaphor with no clear tenor/vehicle link.

## COMMON_MISCONCEPTION
**Misconception:** "Imagery is just 'descriptive writing' or 'visual description,' and metaphor is just 'a fancy comparison.'"  
**Why it persists:** Class 10 teaching often reduces imagery to "word pictures" and metaphor to "A is B" without sensory categorization or tenor/vehicle analysis. In this chapter, students read the heavy dialogue and miss the **tactile/thermal imagery** (heat, roughness, trembling) because it's embedded in speech tags. They also mistake the **compound metaphors** (Sanskritized *samasa* chains) for mere vocabulary words, not recognizing each component (*ckOkQ, 'khje, rkI+kQ...*) as a distinct metaphorical attribute. This leads to Board answers like "The author uses good imagery to describe her" without quoting sensory evidence or explaining effect.

## ON_FAILURE
**Step 1 (Sensory Audit):** Give the student a 5-column table (Sight, Sound, Smell, Touch, Taste). Assign: "Scan pages 22–28. Put *every* sensory phrase in the correct column. Find at least 3 per column."  
**Step 2 (Metaphor Surgery):** For the compound word on page 27, have them physically cut the word into its 10 components on paper slips. On the back of each, write: Literal Meaning → Metaphorical Quality → Textual Evidence.  
**Step 3 (Tenor/Vehicle Drill):** Give 5 metaphors from the text. Student must fill a template: *Tenor = ______ | Vehicle = ______ | Shared Quality = ______ | Effect = ______.*  
**Step 4 (PEEL Paragraph):** Write one analytical paragraph using the structure: **P**oint (device used), **E**vidence (quote), **E**xplanation (sensory impact/tenor-vehicle), **L**ink (theme/character).

## BUILDS_ON
Close reading of the protagonist's characterization (node c11_hin_ar_cbse_02_004) and the story's setting/atmosphere (node c11_hin_ar_cbse_02_003), which are largely constructed through these devices.

## LEADS_TO
Analysis of higher-order devices—Irony and Symbolism (node c11_hin_ar_cbse_02_009)—which often *subvert* the imagery/metaphors established here (e.g., the "nurturing fire" imagery becomes ironic in the cold ending).

## PREREQUISITE_NODE_IDS
c11_hin_ar_cbse_02_001, c11_hin_ar_cbse_02_002, c11_hin_ar_cbse_02_003, c11_hin_ar_cbse_02_004, c11_hin_ar_cbse_02_007

## PREREQUISITE_REASONS
c11_hin_ar_cbse_02_001: Author's minimalist style ("de fy[kuk fof'k"V fy[kuk") dictates why she uses dense metaphors instead of lengthy description.  
c11_hin_ar_cbse_02_002: Plot knowledge locates *where* key imagery clusters appear (kitchen vs hospital scenes).  
c11_hin_ar_cbse_02_003: Setting (kitchen heat, hospital sterility) is built through thermal/tactile imagery; understanding atmosphere primes device detection.  
c11_hin_ar_cbse_02_004: Character analysis of fe;k¡ ulh#íhu provides the "tenor" for every metaphor—her dignity, labor, marginalization.
c11_hin_ar_cbse_02_007: Imagery and metaphor are the primary vehicles through which secondary themes are conveyed. c11_hin_ar_cbse_02_009: Irony and symbolism deepen the thematic resonance of secondary ideas. c11_hin_ar_cbse_02_013: Critical thinking requires synthesizing primary and secondary themes into a coherent interpretation.  

## FORWARD_NODE_IDS
c11_hin_ar_cbse_02_009, c11_hin_ar_cbse_02_013, c11_hin_ar_cbse_02_014, c11_hin_ar_cbse_02_015, c12_hin_a_cbse_04_008, c12_hin_a_cbse_05_008, c12_hin_a_cbse_06_008, c12_hin_a_cbse_12_008, c12_hin_a_cbse_16_008, c12_hin_ar_cbse_02_008, c12_hin_a_cbse_01_008, c11_hin_ar_cbse_01_008, c12_hin_a_cbse_02_003

## FORWARD_REASONS
c11_hin_ar_cbse_02_009: Irony often works by undercutting established metaphors (e.g., "nurturing mother" metaphor vs ironic neglect); symbolism extends metaphor into recurring motifs.  
c11_hin_ar_cbse_02_013: Critical thinking questions (e.g., "How does the author critique class through literary devices?") require this node's analytical toolkit.
c11_hin_ar_cbse_02_014: Imagery/metaphor identification enables quoting specific literary devices as 'Evidence'.  
c11_hin_ar_cbse_02_015: Imagery/metaphor (streetlight, three stages poem) supplies the symbolic evidence for interpretive claims.  
c12_hin_a_cbse_04_008: Reinforcement across multiple chapters — exposure to varied poets (Nirala, Pant, Mahadevi) builds device-recognition fluency.  
c12_hin_a_cbse_05_008: Reinforces identification skills across different poetic forms in Class 11.  
c12_hin_a_cbse_06_008: Extended practice with metaphor in narrative poetry (e.g., Padmavat) preparing for Raskhan's lyrical density.  
c12_hin_a_cbse_12_008: अगला तार्किक चरण: Imagery is the use of vivid, sensory language that appeals to the five senses (sight, sound, smell,... इस नोड की अवधारणाओं को सीधे उपयोग/विस्तारित करता है।  
c12_hin_a_cbse_16_008: Reinforces identification practice across multiple Class 11 texts, building pattern recognition.  
c12_hin_ar_cbse_02_008: Prior practice in identifying imagery/metaphor in a different poem; this node deepens to analysis.  
c12_hin_a_cbse_01_008: Class 11 understanding of basic poetic devices (imagery, metaphor, simile) from multiple chapters (e.g., c11_hin_ar_cbse_01_008, c11_hin_ar_cbse_02_008).  
c11_hin_ar_cbse_01_008: : Introduced imagery and metaphor definitions and basic identification in Class 11 Antra Chapter 1. c11_hin_ar_cbse_02_008: Reinforced the same devices in a different text, showing variety. c11_hin_v_cbse_01_008: Covered literary devices in  
c12_hin_a_cbse_02_003: Revisit Class 11 imagery node (c11_hin_ar_cbse_02_008) if sensory identification is weak.  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
none

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_02_004 -> c11_hin_ar_cbse_02_008 -> c11_hin_ar_cbse_02_009

## THIS_FORMULA
N/A - conceptual

## FORMULA_VARIABLES
N/A

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
analytical

## CROSS_SUBJECT
c11_english_literary_devices | Both Hindi and English literature use imagery and metaphor as core poetic/prose devices; the analytical framework (identify, categorize, interpret effect via tenor/vehicle) is identical across languages.  
c11_psychology_perception | Imagery directly relates to sensory perception and mental representation; understanding how language evokes embodied simulation (e.g., reading "rough hands" activates somatosensory cortex) connects to cognitive psychology concepts of grounded cognition.

## PREREQ_CONCEPT
Ability to distinguish literal from figurative language and identify sensory adjectives/verbs in Hindi prose.

## PREREQ_BEFORE
Student must have read the full chapter "vejdkar" (fe;k¡ ulh#íhu) and completed the plot/character nodes (c11_hin_ar_cbse_02_002, 004).

## PREREQ_STUCK
Re-read the chapter with a highlighter: **Yellow** for visual, **Blue** for tactile/thermal, **Green** for auditory/olfactory, **Pink** for "A is B" statements (metaphors). Do not analyze yet—just collect.

## WORKED_EXAMPLE_1
**PROBLEM:** Analyze the imagery in the opening description of fe;k¡ ulh#íhu (page 22: *"ekSleksa dh ekj ls idk psgjk] vk¡[kksa esa dkb;k¡ Hkksykiu vkSj is'kkuh ij e¡ts gq, dkjhxj osQ rsoj"*). Identify three distinct sensory images, classify each by sense, and explain how they jointly establish her character before she speaks a word.

**STEPS:**
- Step 1: **Locate & Segment** – Isolate the three noun phrases: *idk psgjk* (sweat dripping), *dkb;k¡ Hkksykiu* (rough lines), *dkjhxj osQ rsoj* (rage of hard skin).
- Step 2: **Classify by Sense** – *idk psgjk*: Visual (beads) + Tactile (wetness) + Thermal (heat). *dkb;k¡ Hkksykiu*: Visual (deep creases) + Tactile (rough ridges). *dkjhxj osQ rsoj*: Tactile (hardness/callous) + Thermal (burning heat) + Kinesthetic (tension).
- Step 3: **Interpret Character** – Sweat/heat = physical labor intensity. Rough lines/hard skin = years of repetitive skilled work (rolling rotis, chopping). "Rage" (rsoj) personifies the skin—her body *holds* anger at exploitation.
- Step 4: **Synthesize** – The cluster constructs a **body archive**: her flesh records her history. She enters as a *worker*, not a victim; the imagery demands respect for her labor.
- Step 5: **Link to Theme** – This pre-dialogue characterization sets up the story's central argument: domestic work is *skilled, embodied knowledge*, not menial drudgery.

**REASONING:** This 5-step method (Locate → Classify → Interpret → Synthesize → Link) moves from textual evidence to thematic insight, mirroring the Board's "Reference to Context" and "Long Answer" marking rubrics.

**ANSWER:** The passage deploys a triad of tactile-thermal imagery: (1) *idk psgjk* (sweat) – visual beads + tactile wetness + thermal heat; (2) *dkb;k¡ Hkksykiu* (rough lines) – visual depth + tactile ridges; (3) *dkjhxj osQ rsoj* (hard skin's rage) – tactile callousness + thermal burning + kinesthetic tension. Together, they inscribe her biography on her body: the kitchen's heat, the knife's pressure, the roti's demand. The personification *rsoj* (rage) in her skin suggests her labor is not passive endurance but suppressed resistance. This imagery establishes her as a **master artisan** before the narrative voice diminishes her to "cook," framing the story's critique of invisible labor.

## WORKED_EXAMPLE_2
**PROBLEM:** Deconstruct the metaphor *"rkyhe dh rkyhe gh cM+h ph”k gksrh gS"* (page 24, spoken by fe;k¡ ulh#íhu to the narrator). Identify Tenor, Vehicle, Ground, and explain how it functions as a **speech act** that shifts power in the conversation.

**STEPS:**
- Step 1: **Identify the Metaphor** – The sentence equates "smallest slight" (implied tenor) with "smallest wound" (explicit vehicle).
- Step 2: **Map Tenor & Vehicle** – Tenor (abstract subject): The narrator's dismissive question about her son's education ("What will he do with studies?"). Vehicle (concrete image): A physical wound (*ph”k*), specifically the *smallest* one (*rkyhe dh rkyhe*).
- Step 3: **Articulate Ground of Comparison** – Shared attributes: (a) Disproportionate pain – a paper cut hurts more than a clean gash; a casual insult wounds deeper than a slap. (b) Invisibility – small wounds bleed internally; marginalization hurts silently. (c) Universality – *everyone* knows a tiny wound's sting; she forces him into that shared body knowledge.
- Step 4: **Analyze Speech Act Function** – She is not describing; she is *accusing*. The metaphor performs: "Your words = violence." It forces the educated narrator (lkfgc) to confront his linguistic violence. Power shifts: she, the "illiterate cook," schools the professor in emotional physics.
- Step 5: **Contextualize** – This follows his suggestion that her son become a *chowkidar* (watchman). The metaphor reclaims her son's potential: "You treat his future as a scratch; I feel it as a hemorrhage."

**REASONING:** Metaphor analysis at senior secondary level requires moving beyond "A=B" to **pragmatic function**—what the metaphor *does* in the interaction. This connects device analysis to character dynamics and social power, a key Board competency.

**ANSWER:** Tenor = Narrator's casual dismissal of her son's education. Vehicle = *rkyhe dh rkyhe ph”k* (smallest wound). Ground = Disproportionate pain + invisibility + universal bodily truth. As a speech act, it converts his abstract opinion into visceral violence, flipping the epistemic hierarchy: the marginalized mother becomes the teacher of human vulnerability. The metaphor *is* her resistance.

## WORKED_EXAMPLE_3
**PROBLEM:** The compound metaphor chain *"ckOkQj[kkuh&'khjeky&rkI+kQrku&csluh&[kehjh&:ekyh&xko&nhnk&xk”kscku&rqudh"* (page 27) appears in the narrator's internal monologue as he watches her being humiliated. **Deconstruct four component metaphors**, translate their literal→figurative meaning, and explain how their **accumulation (anadiplosis-like density)** serves the author's minimalist aesthetic ("de fy[kuk fof'k"V fy[kuk").

**STEPS:**
- Step 1: **Morphological Segmentation** – Break the *samasa* (compound) into 10 components: *ckOkQj[kkuh* + *'khjeky* + *rkI+kQrku* + *csluh* + *[kehjh* + *:ekyh* + *xko* + *nhnk* + *xk”kscku* + *rqudh*.
- Step 2: **Decode Four Key Components** –  
  (a) *ckOkQj[kkuh* = *ckOkQ* (dread/fear) + *j[kkuh* (keeping) → **One who commands awe/authority** (not just "scary").  
  (b) *'khjeky* = *'khje* (green/fresh/life) + *ky* (making) → **Life-giver, nurturer** (like spring).  
  (c) *csluh* = *csl* (sharp/keen) + *uh* → **Sharp-tongued, intellectually piercing** (not merely rude).  
  (d) *nhnk* = *nhnk* (soft/tender) → **Gentle, vulnerable** (juxtaposed with *csluh/xko*).
- Step 3: **Analyze Juxtaposition** – The chain forces **binary opposites** into coexistence: Authority (*ckOkQj[kkuh*) ↔ Tenderness (*nhnk*); Fire (*xko*) ↔ Earth/Dust (*rqudh*); Solitude (*:ekyh*) ↔ Nurturance (*'khjeky*). She is not a "type"; she is a **contradiction held in tension**.
- Step 4: **Link to Minimalist Aesthetic** – Ñ".kk lkscrh's dictum "write less = write better" is enacted here: **one word replaces a chapter of characterization**. The density *is* the style—each metaphor is a compressed chapter.
- Step 5: **Thematic Payoff** – The narrator realizes *in that moment* that reducing her to "ukuckbZ" (cook) is a categorical error. The compound word *performs* the epiphany: language itself cannot contain her.

**REASONING:** This example integrates **Hindi morphology (samasa)**, **literary device analysis**, and **authorial style**—exactly the multi-layered reasoning Board examiners reward in "Critical Appreciation" questions.

**ANSWER:** Four decoded metaphors: (1) *ckOkQj[kkuh* = Authority/Awe-keeper; (2) *'khjeky* = Life-giver/Nurturer; (3) *csluh* = Sharp-witted/Piercing; (4) *nhnk* = Tender/Soft. Their accumulation creates a **kaleidoscopic portrait** where contradictions (fire/dust, authority/tenderness) coexist without resolution. This density *enacts* the author's minimalist philosophy: the compound word is a "narrative singularity" packing a novel's characterization into a single lexical unit. It forces the narrator (and reader) to confront the inadequacy of the label "cook"—the device *performs* the story's central argument about the complexity of marginalized lives.

## COMPETENCY_QUESTION_1
**QUESTION:** In the outburst *"ge crZu èkksuk u lh[krs / ge Hkêòh cukuk u lh[krs / Hkêòh dks vk¡p nsuk u lh[krs / rks D;k ge lhèks&lhèks ukuckbZ dk gquj lh[k tkrs!"* (page 25), identify the **central metaphor** and the **sustained imagery cluster** supporting it. Write a structured analytical response (Point–Evidence–Explanation–Link) explaining how the **kitchen hierarchy** becomes a **metaphor for social hierarchy**.

**COMPETENCY:** Literary Analysis – Extended Metaphor & Social Allegory  
**STEPS:**
- Step 1: Identify the central metaphor (*lhèks&lhèks ukuckbZ dk gquj* = "fodder for the lowest cook") and the imagery cluster (*crZu, Hkêòh, vk¡p* = grains, bread, water).
- Step 2: Map the kitchen hierarchy (Head Cook → Assistants → Lowest Cook) onto social hierarchy (Elite → Middle → Marginalized/Dalit/Women).
- Step 3: Explain the metaphorical transfer: "Fodder" (animal feed) → Human beings denied basics. The *lowest cook* gets waste; the *marginalized* get denied rights.
- Step 4: Link to theme: The domestic sphere is a microcosm of the caste/class order; feeding others while starving is structural violence.

**ANSWER:**  
**Point:** The central metaphor *"lhèks&lhèks ukuckbZ dk gquj"* (fodder for the lowest cook) equates the marginalized to animal feed, sustained by the imagery cluster *crZu* (grains), *Hkêòh* (bread), *vk¡p* (water) – the trinity of sustenance.  
**Evidence:** She lists what "we" (the marginalized) are denied: *crZu èkksuk* (grain to eat), *Hkêòh cukuk* (bread to make), *vk¡p nsuk* (water to give).  
**Explanation:** The kitchen hierarchy—where the *lhèks ukuckbZ* (lowest cook) receives only *gquj* (fodder/waste) after feeding everyone—maps directly onto the social order. The metaphor transfers the **dehumanization of animal husbandry** onto **human labor relations**: just as cattle eat leftovers, the underclass receives discarded rights (education, dignity, water). The domestic space is not a metaphor *for* society; it *is* the site where society rehearses its cruelty.  
**Link:** This kitchen-as-microcosm metaphor structures the entire story: fe;k¡ ulh#íhu feeds the narrator's household (intellectual elite) but her own son is denied the "bread" of education. The metaphor makes systemic injustice **visceral and domestic**, not abstract.

**DIFFICULTY:** medium

## COMPETENCY_QUESTION_2
**QUESTION:** Trace the **evolution of fire/thermal imagery** across three key moments: (1) Opening kitchen – *"dkjhxj osQ rsoj"* (rage of hard skin/heat), (2) Mid-story confrontation – *"Hkêòh lqyxk nks rks dke ls fucVsa"* (take two rotis and get lost from work), (3) Ending – *"fudkyh ranwj ls fuxyh vkSj g”ke"* (withered, dry like dry wood/grass). How does this thermal arc **enact the extraction and exhaustion of her labor**? Write a 150-word analytical response quoting each phrase.

**COMPETENCY:** Comparative Imagery Tracking – Motif Evolution & Thematic Enactment  
**STEPS:**
- Step 1: Extract the three thermal phrases with context.
- Step 2: Analyze Moment 1: *rsoj* (heat/rage) = **Productive fire** – her labor generates heat; she *controls* the flame.
- Step 3: Analyze Moment 2: *Hkêòh lqyxk* (rotis taken) = **Extracted fire** – the product of her fire (rotis) is seized; "get lost from work" = expelled from the hearth.
- Step 4: Analyze Moment 3: *fuxyh vkSj g”ke* (withered/dry) = **Extinguished fire** – no fuel left; body becomes *ranwj* (kindling) consumed by its own burning.
- Step 5: Synthesize arc: Productive → Extracted → Extinguished. The imagery *enacts* the Marxist concept of surplus value extraction via the body's thermodynamics.

**ANSWER:** The thermal imagery traces a **thermodynamics of exploitation**. (1) *"dkjhxj osQ rsoj"* (p.22): Her calloused hands hold *rsoj* – productive heat/rage of skilled labor; she *is* the hearth. (2) *"Hkêòh lqyxk nks rks dke ls fucVsa"* (p.26): The *product* of her fire (rotis) is casually seized; she is expelled from the kitchen – the fire is **alienated** from the worker. (3) *"fudkyh ranwj ls fuxyh vkSj g”ke"* (p.28): Her body becomes *ranwj* (kindling), *fuxyh* (withered), *g”ke* (dry) – the fire has **consumed its host**. The arc *productive heat → extracted product → human ash* materializes the extraction of surplus labor without jargon. The kitchen, site of nurture, becomes a crematorium. The imagery does not just *describe* her exhaustion; its cooling trajectory *performs* the violence of a system that burns women's bodies to feed others and discards the cinders.

**DIFFICULTY:** hard