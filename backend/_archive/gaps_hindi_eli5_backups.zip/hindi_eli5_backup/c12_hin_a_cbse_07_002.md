## DEFINITION
Plot and narrative structure in a narrative poem refers to the sequence of events, images, and emotional beats arranged across stanzas that together tell a story — including the exposition (setting the scene), rising action (building tension through repetition and detail), climax (moment of highest emotional intensity), and resolution (implied or open-ended conclusion), all shaped by the poet's choice of stanza breaks, refrain, and narrative perspective.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student can trace the narrative arc across all stanzas of "ckjgeklk," identify how each stanza advances the story of the waiting woman (ukxerh), explain how folk narrative techniques (repetition, dialogue, nature as witness) structure the plot, and write a structured answer using the PEEL method linking structural choices to the poem's emotional core.

## SCOPE_BOUNDARY
This node covers the narrative structure of the folk poem "ckjgeklk" by Mahadevi Verma — its stanza-wise progression, narrative techniques, and how the plot unfolds through a woman's wait. It does NOT cover thematic analysis (node 006), literary devices in isolation (nodes 008, 009), or character analysis of the protagonist (node 004) — though it references them.

## WALKTHROUGH
Imagine you're listening to your grandmother tell a story at night — she doesn't just say "she waited," she paints the oil lamp flickering, the cricket's chirp, the clock ticking, and repeats the wait until you feel it in your bones. That's what "ckjgeklk" does: it's a folk narrative poem where the plot isn't told in straight lines but built through layered images across stanzas. Start by reading the poem aloud — notice how each stanza adds a new sensory detail (the lamp, the night, the morning, the dialogue). Ask: what changes from stanza 1 to stanza 4? What repeats? The key insight: in folk narratives, the structure IS the emotion — repetition isn't filler, it's the heartbeat of waiting.

## DIAGNOSTIC_QUESTION_1
What is the primary narrative event that structures the entire poem "ckjgeklk" across its stanzas?

## DIAGNOSTIC_ANSWER_1
The poem is structured around a woman (ukxerh) waiting through the night for her beloved, with each stanza marking a progression of time (evening → deep night → morning) and her emotional state. A wrong answer (e.g., "it's about nature description" or "it's a love song without narrative") reveals the student is reading stanzas as isolated images rather than a sequential narrative arc — they miss the temporal progression that IS the plot.

## DIAGNOSTIC_QUESTION_2
Explain in your own words how the poet uses the passage of time (evening, night, morning) to structure the narrative in "ckjgeklk."

## DIAGNOSTIC_ANSWER_2
The poem moves through three temporal phases: Stanza 1 establishes evening (lamp lit, woman waiting), Stanza 2 deepens into night (darkness, silence, her persistent wait), Stanza 3 shifts to morning (birds, light, unresolved wait). This temporal scaffolding creates rising tension — the longer the night, the heavier the wait. A wrong answer that lists images without sequencing them (e.g., "there's a lamp and birds") shows the student cannot distinguish between static description and dynamic narrative structure.

## DIAGNOSTIC_QUESTION_3
In Stanza 2, the lines "pdbZ fufl fcNqjSa fnu feykA / jSfu vosQfy lkFk u¯g l[khA" appear. Apply the concept of narrative pacing: what do these lines do to the story's rhythm, and why?

## DIAGNOSTIC_ANSWER_3
These lines slow the narrative pace — "the whole day passed in vain / the night didn't pass with him" — stretching time to mirror the woman's subjective experience of endless waiting. The shift from "day passed" (external time) to "night didn't pass" (internal time) marks a structural turning point: the plot moves from external observation to internal endurance. A wrong answer that only translates the lines misses how pacing functions as a structural device — the student sees words, not narrative engineering.

## DIAGNOSTIC_QUESTION_4
Compare the narrative function of the refrain-like repetitions in Stanza 1 ("?kj ?kj phj jpk lc dkgw¡") and Stanza 4 ("rsfg fcuq tkM+ u NwVS ekgk¡AA / rw¡ lks Hk¡oj eksj tkscu iwQywAA"). How do they differ in what they reveal about the plot's progression?

## DIAGNOSTIC_ANSWER_4
Stanza 1's repetition ("house to house, calling out") shows active seeking — the plot's exposition: she searches, calls, initiates. Stanza 4's repetition ("don't let the morning come / let the lamps burn, let him tell stories") shows resigned endurance — the plot's climax: she no longer seeks, she begs time to stop. The structural shift from outward action to inward plea marks the narrative's emotional peak. A wrong answer that treats both as "repetition for emphasis" misses the directional change in the protagonist's agency across the narrative arc.

## DIAGNOSTIC_QUESTION_5
Evaluate this interpretation: "The poem has no real plot — it's just a series of folk images strung together." Defend or critique using structural evidence from the poem.

## DIAGNOSTIC_ANSWER_5
Critique: The poem has a clear three-act narrative structure. Act 1 (Stanza 1): Exposition — woman waits, lamp burns, she calls out. Act 2 (Stanza 2): Rising action — day passes, night deepens, silence grows, her wait intensifies. Act 3 (Stanza 3-4): Climax — morning approaches, she pleads for night to stay, beloved's return remains unresolved. The folk images (lamp, birds, oil, stories) are not decorative; they are the plot's scaffolding. A student who agrees with the interpretation confuses "non-linear" with "plotless" — folk narratives often use circular/repetitive structures, not absence of structure.

## DIAGNOSTIC_QUESTION_6
Write a 4-line stanza that could fit between Stanza 2 and Stanza 3 of "ckjgeklk," maintaining the poem's narrative structure, folk voice, and temporal progression. Use Hindi (Devanagari).

## DIAGNOSTIC_ANSWER_6
A strong answer would show: (1) temporal bridge — deep night to pre-dawn, (2) folk diction (e.g., "अँधियारी," "बटोही," "दियना"), (3) emotional continuity — her vigil continues, (4) structural function — heightens tension before morning. Example: "गहराई रात, बुझत न दियना बात / बटोही न आयो, काहे रे रात / अँखियाँ पथराई, आस न टूट / भोर न आवै, रुक जा रे भोर।" A poor answer would use modern language, break the folk rhythm, or introduce a new character/event — showing the student doesn't grasp how narrative structure constrains creative extension.

## COMMON_MISCONCEPTION
Students treat "ckjgeklk" as a lyric poem (about feeling) rather than a narrative poem (about a sequence of events). They write answers like "the poet expresses sadness through nature imagery" — missing that the sadness is EARNED through a structured wait: lamp lit → night deepens → morning threatens → plea for time to stop. The misconception arises because the poem uses folk repetition and dialect, which students associate with "simple songs," not crafted narrative architecture. They don't see that each stanza is a narrative beat: action → endurance → crisis → plea.

## ON_FAILURE
Step 1: Have the student create a 4-box storyboard — one box per stanza — drawing only what HAPPENS (not what is described). Box 1: Woman lights lamp, looks out. Box 2: Sun sets, moon rises, she still looks. Box 3: Birds stir, light grows, she panics. Box 4: She prays to night, clings to darkness. Step 2: Ask "What changes from box to box?" — force them to name the narrative action. Step 3: Re-read the poem mapping each Hindi line to a box. Step 4: Re-attempt Diagnostic Question 4 — if they still see only "repetition," repeat with a familiar folk song (e.g., "Kesariya Balam") and map its narrative beats.

## BUILDS_ON
Class 11 narrative poem analysis (c11_hin_ar_cbse_01_002, c11_hin_v_cbse_01_002) where students learned to identify stanza-wise progression in folk-style poems.

## LEADS_TO
Character Analysis: Protagonist (c12_hin_a_cbse_07_004) — the narrative structure reveals the ukxerh's agency, endurance, and voice, which become the basis for character analysis.

## PREREQUISITE_NODE_IDS
c12_hin_a_cbse_07_001, c11_hin_ar_cbse_01_002, c11_hin_v_cbse_01_002
## PREREQUISITE_REASONS
c12_hin_a_cbse_07_001: Provides context on Mahadevi Verma's folk inspiration and the cultural background of "ckjgeklk" — essential to understand why the narrative uses dialect and folk conventions.
c11_hin_ar_cbse_01_002: Class 11 foundation in analyzing narrative structure in Hindi folk poems — stanza sequencing, temporal markers, refrain function.
c11_hin_v_cbse_01_002: Class 11 Vitan exposure to narrative poetry analysis — reinforces the skill of tracking plot through poetic structure.

## FORWARD_NODE_IDS
c12_hin_a_cbse_07_004, c12_hin_a_cbse_07_006, c12_hin_a_cbse_07_008, c12_hin_a_cbse_07_003, c12_hin_a_cbse_07_005, c12_hin_a_cbse_07_010, c12_hin_a_cbse_07_012, c12_hin_a_cbse_07_013, c12_hin_a_cbse_07_015

## FORWARD_REASONS
c12_hin_a_cbse_07_004: The narrative structure (her actions across stanzas) provides the evidence base for protagonist character analysis — what she does reveals who she is.
c12_hin_a_cbse_07_006: The primary theme (waiting, separation, feminine endurance) emerges FROM the narrative arc — structure carries theme.
c12_hin_a_cbse_07_008: Imagery and metaphor (lamp, night, birds) are not decorative; they are structural markers of narrative time — analyzing them requires knowing their plot function.
c12_hin_a_cbse_07_003: Plot/narrative structure of the poem — the four-stanza progression IS the narrative arc; atmosphere analysis depends on recognizing this structure.  
c12_hin_a_cbse_07_005: Establishes the narrative structure (stanza progression) so you can locate where each supporting character enters.  
c12_hin_a_cbse_07_010: Establishes narrative structure so vocabulary can be mapped to speaker's emotional arc.  
c12_hin_a_cbse_07_012: Understanding narrative/poetic structure tells you *where* to look for clues (stanza vs prose paragraph).  
c12_hin_a_cbse_07_013: Establishes narrative structure (three stanzas as temporal progression) needed for analysis  
c12_hin_a_cbse_07_015: Narrative structure of the three stanzas provides discussion architecture  

## CROSS_SUBJECT_PREREQS
c11_hin_ar_cbse_01_002, c11_hin_v_cbse_01_002
## CROSS_SUBJECT_REASONS
c11_hin_ar_cbse_01_002: Builds directly on Class 11 Antra narrative poem analysis skills — same analytical framework applied at higher depth.
c11_hin_v_cbse_01_002: Class 11 Vitan's narrative poetry work provides cross-textual reinforcement of folk narrative conventions.

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_01_002 -> c12_hin_a_cbse_07_002 -> c12_hin_a_cbse_07_004

## THIS_FORMULA
Narrative Arc Mapping = Stanza 1 (Exposition: Setting + Inciting Wait) → Stanza 2 (Rising Action: Time Passing + Intensifying Wait) → Stanza 3 (Crisis: Morning Threatens) → Stanza 4 (Climax/Plea: Negotiation with Time) → Unresolved Resolution (Open Ending)

## FORMULA_VARIABLES
N/A

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
analytical

## CROSS_SUBJECT
N/A | Folk narrative poems like "ckjgeklk" share oral storytelling traditions with Bhakti/Sufi poetry — both use repetition, dialect, and temporal progression to convey spiritual/emotional journeys. Understanding narrative structure in one illuminates the other.
 N/A | The poem's setting (oil lamps, night vigil, agrarian timekeeping) reflects pre-electricity rural life — geographical context explains why "night" is a structural antagonist and "morning" a threat to the narrative's emotional space.
## PREREQ_CONCEPT
Ability to distinguish between lyric structure (emotional states) and narrative structure (sequenced events) in poetry.

## PREREQ_BEFORE
Student must know how to identify stanzas, track time markers (evening/night/morning), and recognize refrain/repetition as structural — not just decorative — elements.

## PREREQ_STUCK
Review "narrative vs lyric poetry" distinction and "stanza as narrative beat" concept from Class 11 Antra Chapter 1 (c11_hin_ar_cbse_01_002).

## WORKED_EXAMPLE_1
PROBLEM: Analyze how the first stanza of "ckjgeklk" establishes the narrative exposition — setting, protagonist, inciting situation, and narrative voice — using specific textual evidence.

STEPS:
- Step 1: Identify the stanza's temporal marker — "vxgu nsol" (evening time) sets the narrative clock at day's end.
- Step 2: Locate the protagonist and her action — "ukf;dk fojg dh vfXu esa ty jgh gS" (woman sitting in lamp's light) establishes WHO and WHERE.
- Step 3: Find the inciting situation — "uk;d dks lans'k Hkst jgh gS" (sending message to beloved) — the narrative catalyst: she acts, initiating the wait.
- Step 4: Analyze narrative voice — third-person folk narrator ("dfo us... fp=k.k fd;k") creates distance, like a village storyteller, framing the wait as communal witness.
- Step 5: Connect to folk convention — the exposition doesn't explain WHY she waits; it presents the wait as ritual, typical of folk narratives where backstory is assumed.

REASONING: Folk narrative exposition works differently from novelistic exposition — it drops us INTO the ritual moment without backstory. The lamp (fojg) isn't just setting; it's the narrative's central symbol: light against dark, hope against absence. The stanza compresses the entire narrative premise into one framed scene.

ANSWER: Stanza 1 establishes exposition through: (1) Temporal anchor — evening (vxgu nsol); (2) Spatial anchor — lamp-lit space (fojg dh vfXu); (3) Protagonist — ukxerh (woman) in active wait; (4) Inciting action — sending message (lans'k Hkst); (5) Folk narrative voice — third-person storyteller framing. The lamp becomes the structural axis around which the night's narrative will revolve.

## WORKED_EXAMPLE_2
PROBLEM: Trace how Stanza 2 ("iwl tkM+ FkjFkj ru dk¡ikA / fcjg ckf<+ Hkk nk#u lhmQA...") functions as the rising action — specifically, how it escalates the narrative tension established in Stanza 1.

STEPS:
- Step 1: Compare temporal markers — Stanza 1: "vxgu nsol" (evening); Stanza 2: "iwl tkM+" (deep night), "pdbZ fufl fcNqjSa fnu feyk" (whole day passed in vain) — time has MOVED.
- Step 2: Identify escalation in protagonist's action — Stanza 1: she sends message (active outreach); Stanza 2: "fcjg lpku Hk¡oS ru pk¡M+k" (she keeps lamp burning, tends it) — shifts from outreach to maintenance, showing wait has lengthened.
- Step 3: Analyze nature's narrative role — "lkSj lqisrh vkoS twM+h" (wind blows, leaves rustle) — nature becomes witness/antagonist; silence deepens ("jSfu vosQfy lkFk u¯g l[kh" — night doesn't pass with him).
- Step 4: Locate the structural pivot — "th;r [kkb eq¡ u¯g Nk¡M+k" (her eyes don't close) — the body now enacts the wait; internal state (sleeplessness) externalized.
- Step 5: Explain rising action logic — each detail (lamp tended, day wasted, night stretching, eyes open) adds weight to the wait; the plot thickens not through new events but through ACCUMULATION of endurance.

REASONING: In folk narrative, rising action often lacks "events" — the event IS the passage of time. Stanza 2 uses accumulation (lamp + day + night + wind + eyes) to make the wait palpable. The structure mimics the woman's experience: each line = another hour endured.

ANSWER: Stanza 2 is rising action because it: (1) Advances narrative time from evening to deep night; (2) Shifts protagonist from active seeking to passive endurance (tending lamp vs sending message); (3) Introduces nature as silent witness/pressure (wind, silence, morning threat); (4) Externalizes internal state (sleepless eyes); (5) Builds tension through accumulation — the longer the stanza's list, the heavier the wait. No new plot event occurs — the wait itself IS the plot thickening.

## WORKED_EXAMPLE_3
PROBLEM: The poem's final stanza (Stanza 4) ends with an unresolved plea: "rsfg fcuq tkM+ u NwVS ekgk¡AA / rw¡ lks Hk¡oj eksj tkscu iwQywAA" (Don't let morning come / let lamps burn, let him tell stories). Analyze how this functions as a folk narrative climax AND open resolution — and why this structural choice is thematically necessary.

STEPS:
- Step 1: Define folk narrative climax — not a dramatic confrontation but a moment of maximum emotional pressure where the protagonist confronts the limiting force (here: time/morning).
- Step 2: Map the climax's components — (a) Direct address to morning ("rsfg fcuq tkM+ u NwVS") — she negotiates with cosmic time; (b) Negotiation terms ("rw¡ lks Hk¡oj eksj tkscu") — she offers continued vigil (lamps, stories) in exchange for more night; (c) Beloved's return framed as story ("iou gksb >ksyk") — his return becomes narrative, not reality.
- Step 3: Analyze why it's open resolution — the poem ends on her plea, not his arrival. The narrative arc completes emotionally (she has exhausted action, now only prayer remains) but not plot-wise (beloved absent).
- Step 4: Connect to folk tradition — folk narratives often end at the threshold of resolution (e.g., "Kesariya Balam" ends with call, not reunion). The structure honors the wait itself as the story.
- Step 5: Link to Mahadevi Verma's adaptation — she takes a folk form (chakgeklak = call-and-response folk song) and deepens it: the "response" never comes, making the call the entire poem. The structure ENACTS the theme: waiting as feminine spiritual practice.
- Step 6: Evaluate structural necessity — a closed ending (he arrives) would betray the folk ethos where separation (viraha) is the sacred space. The open structure IS the meaning.

REASONING: This analysis requires synthesizing narrative theory (climax/resolution), folk literary conventions (viraha poetry, chakgeklak form), and authorial adaptation. The student must see structure not as container but as argument.

ANSWER: Stanza 4 is a folk narrative climax because it concentrates the poem's entire emotional pressure into a single negotiated plea to time itself. It is an open resolution because the narrative question ("will he return?") remains unanswered — but the structural question ("can she endure?") is answered: yes, she transforms waiting into worship (lamps, stories). The structure necessitates this openness: in viraha tradition, the beloved's absence is the condition of the devotee's completeness. A closed ending would collapse the spiritual architecture. Mahadevi Verma uses the folk form's inherent circularity (call without guaranteed response) to make structure = theology.

## COMPETENCY_QUESTION_1
QUESTION: A student writes: "The poem 'ckjgeklk' describes a woman waiting for her husband. The poet uses nature imagery like lamps, birds, and wind to show her loneliness." Critique this answer using the concept of narrative structure. What is missing? How would you rewrite it to show structural awareness?

COMPETENCY: Critical analysis of peer response / structural literacy

STEPS:
- Step 1: Identify the error — the answer treats the poem as static description ("describes," "uses imagery to show") rather than dynamic narrative ("structures," "progresses through," "escalates via").
- Step 2: Name the missing element — no mention of temporal progression (evening→night→morning), no recognition of stanzas as narrative beats, no analysis of how repetition builds tension.
- Step 3: Explain why this loses marks — CBSE marking scheme for "plot and narrative structure" requires tracing sequence and structural function, not listing images.
- Step 4: Rewrite using PEEL — Point: The poem structures a night-long wait through three temporal phases. Evidence: Stanza 1 (evening/lamp/message), Stanza 2 (deep night/sleeplessness), Stanza 3-4 (morning threat/plea). Explanation: Each stanza advances narrative time and emotional stakes. Link: The structure makes waiting an active, escalating spiritual act, not passive loneliness.

ANSWER: The original answer fails because it reduces narrative structure to thematic decoration. It misses: (1) Stanza-as-beat progression, (2) Time as antagonist, (3) Repetition as pacing device, (4) Open ending as structural choice. Rewritten answer: "The poem 'ckjgeklk' constructs its narrative through a three-phase temporal architecture: Stanza 1 establishes evening exposition (lamp lit, message sent); Stanza 2 escalates into deep night rising action (day wasted, eyes sleepless, lamp tended); Stanzas 3-4 reach climax as morning threatens, resolving in an open plea where the protagonist negotiates with time itself. The folk refrain shifts from outward call (Stanza 1) to inward prayer (Stanza 4), structurally enacting the transformation of waiting from action to devotion. Nature imagery (lamp, wind, birds) functions as structural markers of narrative time, not mere atmosphere."

DIFFICULTY
medium

## COMPETENCY_QUESTION_2
QUESTION: The folk form "chakgeklak" traditionally involves a call-and-response structure between separated lovers. Mahadevi Verma's "ckjgeklk" adapts this form but only gives us the woman's call — the man's response is absent. Analyze how this structural adaptation (monologue replacing dialogue) reshapes the narrative arc and what it reveals about the poet's reimagining of folk tradition. Support with specific structural evidence from at least two stanzas.

COMPETENCY: Intertextual analysis / form-content synthesis / feminist literary reading

STEPS:
- Step 1: Define traditional chakgeklak structure — alternating stanzas: woman calls, man responds; circular, communal, resolved through reunion or promised return.
- Step 2: Identify Verma's structural deviation — all four stanzas are the woman's voice (or folk narrator describing her); no male voice appears. The "response" slot is empty.
- Step 3: Trace narrative consequence — without response, the call must escalate. Stanza 1: call to beloved ("lans'k Hkst"). Stanza 2: call to nature/lamp ("fcjg lpku Hk¡oS"). Stanza 3: call to morning ("rsfg fcuq tkM+ u NwVS"). The addressee shifts from human → elemental → cosmic.
- Step 4: Analyze thematic reshaping — the narrative becomes not about reunion but about the woman's autonomous endurance. She doesn't wait FOR him; she waits AS her practice. The structure centers her agency.
- Step 5: Connect to Verma's feminist reimagining — she takes a form defined by dialogue and makes it a monologue of feminine spiritual authority. The absent response is not lack — it's the space where her voice expands to fill the night.

REASONING: This question demands synthesis of folk form knowledge, structural analysis, and gendered literary history — exactly the multi-concept competency CBSE and CUET reward. The student must use stanza-specific evidence (not general claims) to prove the structural argument.

ANSWER: Traditional chakgeklak is dialogic: woman's viraha call → man's assurance/return promise → circular resolution. Verma's adaptation removes the male voice entirely, converting dialogue into a four-stanza monologue of escalating address: Stanza 1 addresses the absent beloved ("uk;d dks lans'k"); Stanza 2 addresses the lamp/night as witnesses ("fcjg lpku Hk¡oS"); Stanzas 3-4 address morning/time itself ("rsfg fcuq tkM+ u NwVS"). This structural shift reorients the narrative arc from "separation awaiting reunion" to "separation as spiritual completeness." The woman's wait no longer depends on his return — the poem's climax is her refusal to let morning end her vigil. The absent response becomes the condition of her narrative sovereignty. Verma uses folk form's own circularity (call without guaranteed answer) to center feminine endurance as the poem's true resolution.

DIFFICULTY
hard