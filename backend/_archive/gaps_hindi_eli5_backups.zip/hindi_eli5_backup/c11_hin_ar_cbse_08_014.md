## DEFINITION
Writing Skills: Based on the Chapter refers to the ability to compose structured, evidence-based answers for examination questions on Chapter 8 "Hkkjr ekrk" (India, the Mother) by Jawaharlal Nehru, using the PEEL method (Point, Evidence, Explanation, Link) to demonstrate comprehension, analysis, and critical interpretation of the text's themes, literary devices, and historical context.

## COGNITIVE_LEVEL
apply

## MASTERY_CRITERIA
The student can independently write a 150-200 word long-answer response to a board-style question on Chapter 8 that includes a clear thesis statement, at least two pieces of specific textual evidence (paraphrased or quoted), analytical explanation connecting evidence to the point, and a concluding link to the chapter's central idea of unity in diversity.

## SCOPE_BOUNDARY
This node covers writing analytical answers (short and long) for CBSE Class 11 Hindi Aroh Chapter 8 exam questions. It does NOT cover creative writing, letter writing, essay writing on unrelated topics, or speaking/listening skills (covered in node 08_015).

## WALKTHROUGH
Imagine you're in the exam hall facing a 6-mark question: "How does Nehru redefine 'Bharat Mata' in the chapter? Support with textual evidence." You know the story but your answer reads like a plot summary and scores only 2/6. Why? Because you missed the PEEL structure: you didn't make a clear analytical point, embed specific evidence, explain its significance, or link back to the theme. Start by reading the question carefully, underline keywords (redefine, Bharat Mata, textual evidence). Then recall the key scenes: Nehru's travels, the peasant's question, his realization that Bharat Mata is the people. Next, draft a thesis: "Nehru shifts Bharat Mata from a geographical abstraction to a living collective of people." Now find two evidence points: the peasant's question ("Who is this Bharat Mata?") and Nehru's final definition ("You are Bharat Mata"). Explain each: the question exposes the gap between nationalist rhetoric and lived reality; the answer redefines nationhood as human dignity. Finally, link to unity in diversity: this redefinition makes every Indian, regardless of region/religion, a part of Bharat Mata. The key insight: exam answers are arguments, not summaries.

## DIAGNOSTIC_QUESTION_1
What does the acronym PEEL stand for in the context of writing structured answers for literature questions?

## DIAGNOSTIC_ANSWER_1
PEEL stands for Point (topic sentence stating the argument), Evidence (specific textual detail/quote), Explanation (analysis of how evidence supports the point), and Link (connecting back to the question/theme). A wrong answer (e.g., "Paragraph, Example, Explain, Line") reveals the student lacks the meta-cognitive framework for answer construction and will likely produce disorganized, summary-heavy responses.

## DIAGNOSTIC_QUESTION_2
A student writes: "Nehru travelled across India and talked to peasants. He realised Bharat Mata is not land but people. This shows unity in diversity." Identify which PEEL component is missing and why this answer would score low on a 6-mark question.

## DIAGNOSTIC_ANSWER_2
The answer has Point and Link but lacks specific Evidence (no paraphrased incident/quote) and Explanation (no analysis of *how* the realization occurs or *why* it signifies unity). Without Evidence/Explanation, the answer remains a plot summary. A student who misses this thinks "knowing the story" equals "writing an answer" – the core misconception.

## DIAGNOSTIC_QUESTION_3
Rewrite the weak answer from Question 2 into a strong PEEL paragraph for a 3-mark question. Include one specific textual reference (paraphrased) and analytical explanation.

## DIAGNOSTIC_ANSWER_3
**Strong Answer:** Nehru redefines Bharat Mata as the collective people of India, not its geography (Point). When a peasant in a remote village asks, "Who is this Bharat Mata whose victory you shout?" (Evidence), it exposes the disconnect between elite nationalist slogans and the masses' lived reality (Explanation). Nehru's reply – "You are Bharat Mata" – transforms the nation into a living relationship of shared dignity, making unity in diversity a human truth, not a political slogan (Link). A weak rewrite would still lack the causal explanation connecting the peasant's question to the conceptual shift.

## DIAGNOSTIC_QUESTION_4
Compare two approaches to answering "Discuss the role of irony in Nehru's portrayal of 'Bharat Mata'." Approach A: Lists three ironic statements from the text. Approach B: Argues that irony reveals the gap between abstract nationalism and concrete humanity, using the peasant scene as central evidence. Which approach demonstrates higher-order analysis? Justify.

## DIAGNOSTIC_ANSWER_4
Approach B demonstrates analysis (Bloom's Level 4) because it identifies a *pattern* (irony as a structural device) and explains its *thematic function* (exposing the abstract/concrete gap). Approach A is mere identification (Level 1). A student choosing A thinks literary devices are "things to spot" rather than "tools the author uses to shape meaning" – a critical senior-secondary misconception.

## DIAGNOSTIC_QUESTION_5
Evaluate this claim: "For a 6-mark question on Chapter 8, writing a 300-word detailed summary of Nehru's travels guarantees full marks because it shows thorough knowledge of the text." Defend your evaluation with reference to CBSE marking rubrics.

## DIAGNOSTIC_ANSWER_5
The claim is false. CBSE rubrics allocate marks for: Understanding (2), Analysis/Interpretation (2), Expression/Structure (2). A summary scores only on Understanding (max 2/6). It fails Analysis (no argument, no device discussion) and Expression (no PEEL, no thesis). A student believing this confuses "content knowledge" with "answer writing skill" – they need to practice converting knowledge into structured arguments.

## DIAGNOSTIC_QUESTION_6
Create a 4-mark question on Chapter 8 that tests *both* theme (unity in diversity) and literary device (metaphor), then write a model PEEL answer for it.

## DIAGNOSTIC_ANSWER_6
**Question:** "How does Nehru use the metaphor of 'Bharat Mata' to embody the theme of unity in diversity? Support with two textual details." **Model Answer:** Nehru transforms 'Bharat Mata' from a territorial metaphor into a humanistic one to embody unity in diversity (Point). Initially, the slogan "Bharat Mata ki Jai" treats the nation as a sacred geography (Evidence 1: the slogan's abstract reverence). Through the peasant's question and Nehru's response – "The mountains, rivers, forests... are Bharat Mata, but ultimately *you* are Bharat Mata" (Evidence 2: the redefinition) – the metaphor shifts to the diverse people themselves (Explanation). This makes unity organic: every Indian, irrespective of region/faith, *is* the nation, making diversity the very substance of unity (Link). A poor answer would list metaphors without explaining the *shift* or its *thematic consequence*.

## COMMON_MISCONCEPTION
Students believe that "writing skills" for literature means memorizing model answers or writing long summaries. They think the examiner wants to see *how much* they remember (plot points, character names) rather than *how well* they can construct an argument using the text. This leads to answers that are factually accurate but analytically empty – e.g., listing all places Nehru visited without connecting any to the theme of "discovering India." The root cause: they treat the chapter as information to reproduce, not as a text to argue about.

## ON_FAILURE
1. **Diagnose:** Give the student a 3-mark question and ask them to highlight their Point, Evidence, Explanation, Link in four different colors. If they can't, they lack structural awareness. 2. **Model:** Show a side-by-side comparison: a 40-word summary (1/3) vs. a 60-word PEEL answer (3/3) for the same question. 3. **Scaffold:** Provide a fill-in-the-blank PEEL template for the next practice question: "Nehru shows ______ (Point). For example, ______ (Evidence). This reveals ______ (Explanation). Therefore ______ (Link)." 4. **Practice:** Assign three 3-mark questions requiring only Evidence+Explanation (Point/Link given). Gradually remove scaffolds.

## BUILDS_ON
Critical Thinking: Analysis and Interpretation (c11_hin_ar_cbse_08_013) – provides the analytical insights (themes, devices, Nehru's perspective) that become the "Points" in PEEL answers.

## LEADS_TO
Speaking and Listening: Discussion Points (c11_hin_ar_cbse_08_015) – the structured arguments developed in writing become the foundation for coherent oral presentations and debates on the chapter.

## PREREQUISITE_NODE_IDS
c11_hin_ar_cbse_08_001, c11_hin_ar_cbse_08_002, c11_hin_ar_cbse_08_003, c11_hin_ar_cbse_08_004, c11_hin_ar_cbse_08_005, c11_hin_ar_cbse_08_006, c11_hin_ar_cbse_08_007, c11_hin_ar_cbse_08_008, c11_hin_ar_cbse_08_009, c11_hin_ar_cbse_08_010, c11_hin_ar_cbse_08_011, c11_hin_ar_cbse_08_012, c11_hin_ar_cbse_08_013
## PREREQUISITE_REASONS
c11_hin_ar_cbse_08_001: Context/background knowledge needed for historical framing in answers.
c11_hin_ar_cbse_08_002: Plot/narrative structure provides the sequence of events to reference as evidence.
c11_hin_ar_cbse_08_003: Setting/atmosphere details enrich descriptive evidence.
c11_hin_ar_cbse_08_004: Protagonist analysis supplies Nehru's perspective as the central "voice" in answers.
c11_hin_ar_cbse_08_005: Supporting characters (peasant, crowds) provide concrete evidence for arguments.
c11_hin_ar_cbse_08_006: Primary theme (unity in diversity) is the ultimate "Link" for most answers.
c11_hin_ar_cbse_08_007: Secondary themes (nationalism, identity) offer alternative "Points" for varied questions.
c11_hin_ar_cbse_08_008: Imagery/metaphor analysis provides literary device evidence for technique questions.
c11_hin_ar_cbse_08_009: Irony/symbolism analysis enables higher-order analysis in long answers.
c11_hin_ar_cbse_08_010: Vocabulary ensures precise terminology (e.g., नफुइक, <इस) in written expression.
c11_hin_ar_cbse_08_011: Grammar/usage knowledge ensures syntactically correct Hindi answers.
c11_hin_ar_cbse_08_012: Comprehension skills ensure accurate literal/inferential reading of questions.
c11_hin_ar_cbse_08_013: Critical thinking provides the analytical depth (interpretation, evaluation) required for 6-mark answers.

## FORWARD_NODE_IDS
c11_hin_ar_cbse_08_015, c12_hin_a_cbse_05_014, c12_hin_ar_cbse_08_014

## FORWARD_REASONS
c11_hin_ar_cbse_08_015: Structured written arguments (PEEL) directly translate into organized speaking points for discussions/debates on the chapter's themes.
c12_hin_a_cbse_05_014: अगला तार्किक चरण: Writing Skills based on the chapter refers to the ability to compose structured, evidence-based resp... इस नोड की अवधारणाओं को सीधे उपयोग/विस्तारित करता है।  
c12_hin_ar_cbse_08_014: Previous chapter's writing practice — reinforces transfer of skill across texts.  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS


## CHAIN_DESCRIPTION
c11_hin_ar_cbse_08_013 -> c11_hin_ar_cbse_08_014 -> c11_hin_ar_cbse_08_015: Critical thinking generates analytical content; writing skills structure it into exam answers; speaking skills extend it into oral discourse.

## THIS_FORMULA
PEEL Structure: Point (Thesis/Argument) → Evidence (Textual Detail) → Explanation (Analysis) → Link (Back to Question/Theme)

## FORMULA_VARIABLES
P = Point: One clear analytical claim answering the question (e.g., "Nehru redefines Bharat Mata as the people"). E = Evidence: Specific textual reference (paraphrased incident, quoted phrase, or device example). E = Explanation: 2-3 sentences analyzing *how* the evidence proves the point (literary effect, thematic significance, authorial intent). L = Link: One sentence connecting the point back to the question's key terms or the chapter's central idea.

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
linguistic

## CROSS_SUBJECT
c11_history_nationalism | Nehru's "Discovery of India" journey mirrors the historian's method: using primary encounters (peasants, workers) to construct a national narrative. Writing answers on this chapter practices source-based historical argumentation.
c11_civics_unity_in_diversity | The chapter's climax – "You are Bharat Mata" – operationalizes the constitutional ideal of fraternity. Answers citing this link literary analysis to political philosophy, a key Class 11 competency.

## PREREQ_CONCEPT
Mastery of PEEL paragraph structure and the ability to distinguish plot summary from analytical argument.

## PREREQ_BEFORE
Student must have completed nodes 08_001 to 08_013 (i.e., read the chapter, understood themes, characters, devices, and vocabulary) before attempting answer writing.

## PREREQ_STUCK
If stuck, return to c11_hin_ar_cbse_08_006 (Primary Theme) and c11_hin_ar_cbse_08_008 (Imagery/Metaphor) – these two nodes supply 80% of the "Points" and "Evidence" for exam questions.

## WORKED_EXAMPLE_1
PROBLEM: Improve this weak 3-mark answer: "Nehru went to many villages. He asked people about Bharat Mata. They didn't know. He told them they are Bharat Mata. This shows unity in diversity." (Current score: 1/3)
STEPS:
- Step 1: Identify the question demand: "How does Nehru make the abstract concept of Bharat Mata concrete for ordinary people?" (Implied question).
- Step 2: Identify missing PEEL components: No clear Point (just narrative), vague Evidence ("many villages", "people"), no Explanation of *method*, Link is asserted not argued.
- Step 3: Draft a sharp Point: "Nehru uses direct dialogue with the marginalized to transform Bharat Mata from an abstract slogan into a lived human identity."
- Step 4: Select precise Evidence: Replace "many villages" with "a peasant in a remote village" and quote the specific question: "Who is this Bharat Mata whose victory you shout?" Replace "told them" with Nehru's specific reply: "You are Bharat Mata."
- Step 5: Add Explanation: The peasant's ignorance exposes the elite-mass disconnect; Nehru's reply bridges it by locating nationhood in the person, not the land.
- Step 6: Strengthen Link: "Thus, unity in diversity becomes tangible: every diverse individual *is* the nation."
REASONING: The revision moves from narration (what happened) to argumentation (how the author achieves an effect). Specificity of evidence (naming the peasant, quoting the question) signals close reading. Explanation unpacks the *significance* of the evidence, not just its content.
ANSWER: **Improved Answer (3/3):** Nehru uses direct dialogue with the marginalized to transform Bharat Mata from an abstract slogan into a lived human identity (Point). When a peasant in a remote village asks, "Who is this Bharat Mata whose victory you shout?" (Evidence), it exposes the disconnect between nationalist rhetoric and the masses' reality (Explanation). Nehru's reply – "You are Bharat Mata" – anchors nationhood in human dignity, making unity in diversity a concrete relationship, not an abstract ideal (Link).

## WORKED_EXAMPLE_2
PROBLEM: Write a 6-mark answer from scratch for: "Analyze how Nehru's travel narrative structure reinforces the theme of unity in diversity in Chapter 8."
STEPS:
- Step 1: Deconstruct the question: Key terms = "travel narrative structure", "reinforces", "unity in diversity". Requires analysis of *form* (structure) serving *theme*.
- Step 2: Recall structural elements from node 08_002: Linear journey (North to South, plains to mountains), episodic encounters (peasant, workers, students), culminating realization.
- Step 3: Formulate thesis (Point): "The linear-episodic structure mimics the act of discovery, moving from geographical fragmentation to human unity."
- Step 4: Select Evidence 1 (Structure): The opening describes Nehru "moving from one province to another" seeing "mountains, rivers, forests" – geographical diversity.
- Step 5: Select Evidence 2 (Structure): The middle episodes are discrete encounters (peasant, factory workers, students) – human diversity.
- Step 6: Select Evidence 3 (Structure): The climax converges in the peasant scene where geography ("mountains, rivers") is explicitly subordinated to people ("you are Bharat Mata").
- Step 7: Write Explanation for each: The geographical catalog *sets up* diversity; the episodic encounters *particularize* it; the climax *resolves* it into unity.
- Step 8: Craft Link: The structure itself performs the thematic journey: from 'India as map' to 'India as people'.
REASONING: A 6-mark answer requires 3 distinct analytical moves (hence 3 evidence points). Connecting structure to theme is a classic senior-secondary "form-content" question. The PEEL structure is applied at the whole-answer level: thesis = Point, three body paragraphs = Evidence+Explanation, conclusion = Link.
ANSWER: **Model Answer (6/6):** The linear-episodic structure of Nehru's travel narrative performs the thematic journey from geographical fragmentation to human unity (Point). The opening catalog – "from the mountains of the north to the seas of the south" – establishes India's overwhelming physical diversity (Evidence 1). The middle episodes – the peasant's question, the factory workers' silence, the students' enthusiasm – fragment this geography into distinct human encounters, each revealing a different facet of Indian life (Evidence 2). The climactic convergence, where Nehru lists the mountains/rivers/forests *only to subordinate them* to "you, the people," structurally enacts the subordination of territory to humanity (Evidence 3). This movement from land to people, from catalogue to conversation, from diversity to shared identity, makes the narrative structure itself an argument for unity in diversity (Link).

## WORKED_EXAMPLE_3
PROBLEM: A student writes a 6-mark answer on "Irony in Chapter 8" but scores 3/6. Their answer: "There is irony when the peasant doesn't know Bharat Mata. Also when Nehru says mountains are Bharat Mata but then says people are. Irony shows Nehru's confusion." Diagnose and rewrite.
STEPS:
- Step 1: Diagnose errors: (a) "Nehru's confusion" misreads authorial intent as character flaw. (b) Lists irony instances without a unifying analytical Point. (c) No Explanation of *how* irony functions (contrast, revelation). (d) Link is vague.
- Step 2: Formulate correct analytical Point: "Nehru employs situational irony to expose the hollowness of abstract nationalism and ground nationhood in lived humanity."
- Step 3: Evidence 1: The peasant's question ("Who is Bharat Mata?") creates situational irony: the slogan-chanting nationalist (Nehru) is questioned by the "ignorant" peasant who actually embodies the nation.
- Step 4: Explanation 1: This irony inverts power: the elite's symbol is meaningless without the masses' recognition.
- Step 5: Evidence 2: The verbal irony in "The mountains... are Bharat Mata... but ultimately *you* are Bharat Mata" – the word "but" pivots from expected (geography) to unexpected (people).
- Step 6: Explanation 2: This verbal irony performs the conceptual shift: it *enacts* the redefinition through linguistic contradiction.
- Step 7: Synthesis Link: Both ironies serve the same thematic work: dismantling the top-down nation to reveal the bottom-up nation.
- Step 8: Check PEEL compliance: One thesis, two evidence-explanation pairs, thematic link. No plot summary.
REASONING: The original answer commits the "device spotting" error (Diagnostic Q4). The rewrite demonstrates that irony is not decorative but *argumentative* – it drives Nehru's thesis. Senior-secondary analysis requires explaining the *rhetorical work* a device does.
ANSWER: **Rewritten Answer (6/6):** Nehru employs situational and verbal irony to dismantle abstract nationalism and ground nationhood in lived humanity (Point). The peasant's question – "Who is this Bharat Mata?" – creates situational irony: the "ignorant" villager exposes the emptiness of the elite's slogan, inverting the expected knowledge hierarchy (Evidence 1). This irony reveals that a nation unknown to its people is a fiction (Explanation 1). The verbal irony of "The mountains... are Bharat Mata... *but* ultimately *you* are Bharat Mata" uses contradiction to perform the conceptual shift from territory to people (Evidence 2). The pivot "but" enacts the redefinition linguistically, making the reader experience the shift (Explanation 2). Together, these ironies argue that unity in diversity is not a geographical fact but a human relationship forged in mutual recognition (Link).

## COMPETENCY_QUESTION_1
QUESTION: Read the following student answer to a 3-mark question: "Nehru's language in Chapter 8 is very simple. He uses words like 'kisan', 'mazdoor', 'student'. This shows he wanted to connect with common people. So his language proves the theme of unity in diversity." Identify TWO specific weaknesses in this answer relative to PEEL criteria, and rewrite it to score 3/3.
COMPETENCY: Critical evaluation of answer quality (metacognition) and application of PEEL to improve writing.
STEPS:
- Step 1: Identify Weakness 1: "Language is very simple" is a vague Point – not analytical. It describes style but doesn't argue *how* language serves theme.
- Step 2: Identify Weakness 2: The Evidence is a list of words, not a specific textual instance showing language *in action* (e.g., a dialogue, a rhetorical choice). No Explanation of *effect*.
- Step 3: Formulate a sharp Point: "Nehru's deliberate use of colloquial Hindi and direct address collapses the distance between narrator and subject, enacting unity in diversity at the linguistic level."
- Step 4: Select precise Evidence: The peasant's question in rustic Hindi ("Kaun hai ye Bharat Mata?") vs. Nehru's response blending Sanskritized ("Himalaya", "Ganga") and colloquial ("tum", "tumhi") registers.
- Step 5: Write Explanation: The code-switching mirrors the chapter's argument: unity does not erase diversity (different registers coexist) but relates them in a single conversation.
- Step 6: Write Link: Thus, linguistic form mirrors thematic content – the sentence structure *is* unity in diversity.
ANSWER: **Weaknesses:** (1) Point is descriptive, not analytical. (2) Evidence is a word list, not a textual moment; no Explanation of rhetorical effect. **Rewritten Answer (3/3):** Nehru's deliberate code-switching between Sanskritized and colloquial Hindi enacts unity in diversity at the linguistic level (Point). In the climax, the peasant asks in rustic dialect, "Kaun hai ye Bharat Mata?" while Nehru's reply weaves "Himalaya, Ganga, khet-khalihan" (Sanskritized) with "tum, tumhi ho" (colloquial intimacy) (Evidence). This linguistic hybridity mirrors the chapter's thesis: unity does not homogenize diversity (registers remain distinct) but relates them in a shared address (Explanation). The sentence structure itself performs the national ideal – diverse tongues in one conversation (Link).
DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: "Nehru's 'Discovery of India' journey in Chapter 8 is not a physical travelogue but an intellectual archaeology: he digs through layers of geography, history, and mythology to unearth the *living* nation." Write a 150-word analytical response evaluating this interpretation. Your answer must: (a) Take a clear stance (agree/disagree/qualify), (b) Use at least three distinct textual evidences from different parts of the chapter, (c) Analyze one literary device, (d) Conclude with the implication for the concept of 'Bharat Mata'.
COMPETENCY: Synthesizing thematic analysis, textual evidence, and literary device analysis into a coherent argument – mirroring CBSE 6-mark "Evaluate/Analyze" questions.
STEPS:
- Step 1: Stance: Qualify – the journey is *both* physical and intellectual; the physical encounters *trigger* the archaeological digging.
- Step 2: Evidence 1 (Geography layer): Opening description of "Himalaya, Ganga, Vindhyachal, Narmada" – the geological stratum.
- Step 3: Evidence 2 (History/Mythology layer): References to "Ashoka, Akbar, Buddha, Guru Nanak" – the historical/mythic stratum.
- Step 4: Evidence 3 (Living layer): The peasant encounter – the human stratum where digging stops because the "artifact" speaks.
- Step 5: Device Analysis: Metaphor of "archaeology" itself – Nehru as archaeologist, India as site. The "spade" is conversation.
- Step 6: Implication for Bharat Mata: She is not a statue unearthed but a voice that answers back – the nation as subject, not object.
- Step 7: Structure as PEEL macro: Thesis (Stance) → Three Evidence+Explanation pairs → Device Analysis → Thematic Link.
REASONING: This question tests the highest-order writing skill: constructing an independent critical argument using the chapter as evidence. It combines thematic knowledge (08_006, 08_007), device analysis (08_008, 08_009), and structural awareness (08_002) into a single exam-style response.
ANSWER: **Model Response:** I qualify the metaphor: Nehru's journey is a physical travelogue that *becomes* intellectual archaeology through the encounter with living people (Stance). The opening geographical catalogue – "Himalaya, Ganga, Vindhyachal" – forms the surface stratum (Evidence 1). The historical allusions – "Ashoka's pillars, Akbar's fatehpur, Buddha's stupas" – are the buried layers (Evidence 2). But the archaeological metaphor breaks at the peasant encounter: the "artifact" (the peasant) asks, "Who is Bharat Mata?" forcing the archaeologist to realize the nation is not a dead past but a speaking subject (Evidence 3). The extended metaphor of digging (device) thus self-destructs: the spade of conversation hits not pottery but a person (Analysis). Consequently, Bharat Mata is not a goddess unearthed from soil but the peasant herself – the nation as *subjectivity*, not *objectivity* (Link).
DIFFICULTY: hard