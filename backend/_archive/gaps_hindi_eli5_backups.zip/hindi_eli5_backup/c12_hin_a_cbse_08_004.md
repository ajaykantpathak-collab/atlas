## DEFINITION
Character analysis of the protagonist in poetry involves systematically examining the poetic persona's emotions, motivations, inner conflicts, and spiritual journey as revealed through the speaker's own words, the imagery associated with them, and the structural progression of the poem, distinguishing the constructed 'I' of the poem from the historical poet.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student can independently identify three distinct character traits of the poetic protagonist across the three poems, cite specific textual evidence (lines/images) for each trait, explain how poetic devices (metaphor, repetition, tone) construct that trait, and articulate how the protagonist evolves from sorrow to surrender.

## SCOPE_BOUNDARY
This node covers deep analysis of the protagonist (the poetic persona/devotee) in the three poems of Chapter 8 (fo|kifr's poems). It does NOT cover the poet's biography (node 001), the poems' narrative sequence (node 002), setting/atmosphere (node 003), supporting characters (node 005), or thematic synthesis (nodes 006, 007).

## WALKTHROUGH
Imagine you overhear someone praying in a temple — their voice shakes, they repeat certain phrases, they move from despair to quiet trust. That person is the protagonist of these poems. To analyze them, don't start with the poet's life; start with the *voice* in the poem. Ask: What does this speaker *do* (verbs: weep, call out, wait)? What *images* cluster around them (darkness, locked door, thirst)? How does the *structure* (three poems = three movements) show a journey? The key insight: the protagonist is not the poet but a crafted spiritual persona whose vulnerability *is* their strength.

## DIAGNOSTIC_QUESTION_1
In the first poem, the protagonist says "eksjk fivre iklA" (my heart is at your door). What single character trait does this line primarily establish, and which word in the line is the strongest evidence?

## DIAGNOSTIC_ANSWER_1
The line establishes **humble surrender / helpless dependence**. The strongest evidence is **"ikl" (door/threshold)** — it places the protagonist physically and emotionally at the boundary, not inside, waiting for grace. A wrong answer (e.g., "love" or "faith" without the spatial metaphor) reveals the student is naming emotions rather than analyzing how the *image* constructs the character's posture.

## DIAGNOSTIC_QUESTION_2
A student writes: "The protagonist in poem 2 is angry at God because he says 'tue vcfèk ge :i fugkjy u;u u frjfir Hksy'." Explain why this interpretation misreads the protagonist's emotional state, using the phrase "u;u u frjfir Hksy" as evidence.

## DIAGNOSTIC_ANSWER_2
The phrase "u;u u frjfir Hksy" means "the *us* (devotee/self) has not become *firm/resolved/complete*." It expresses **incompleteness and restless longing**, not anger. The protagonist blames their own unripened state ("ge :i fugkjy" — this form hasn't been seen/realised), not God. A wrong answer reveals the student imposes a rebellious modern template onto a bhakti persona whose core dynamic is *self-accusation*, not divine accusation.

## DIAGNOSTIC_QUESTION_3
Apply the "action–image–tone" method to the third poem's opening: "oqQlqfer dkuu gsfj deyeqf[k] / ewfn jg, nq u;ku". List one action, one central image, and the tone they create together for the protagonist.

## DIAGNOSTIC_ANSWER_3
**Action:** "gsfj" (watching/guarding — the protagonist keeps vigil). **Central Image:** "dkuu" (doorway/threshold) combined with "deyeqf[k]" (equal to the body — a doorway as tall as the self). **Tone:** Quiet, embodied patience — the protagonist *becomes* the threshold. A wrong answer (e.g., action="praying", image="door") misses the fusion of body and architecture that defines this protagonist's spirituality.

## DIAGNOSTIC_QUESTION_4
Compare the protagonist's relationship to "time" in Poem 1 ("eèkqiqj cl js du vitl ysy" — time passes, morning comes) and Poem 3 ("rksgj fcjg fNu Nu&Nu ruq fNuµ" — moment by moment, slowly). What does this shift reveal about the protagonist's spiritual maturation?

## DIAGNOSTIC_ANSWER_4
In Poem 1, time is **external and cyclic** (night→morning), marking the protagonist's *waiting*. In Poem 3, time is **internal and granular** ("Nu&Nu" — moment by moment), marking the protagonist's *presence*. The shift reveals maturation from *anticipating* grace to *inhabiting* each moment as grace. A wrong answer treating both as "time passes" misses the epistemological shift from future-oriented longing to present-oriented awareness.

## DIAGNOSTIC_QUESTION_5
Evaluate this claim: "The protagonist is a passive victim of circumstance; the poems only show suffering." Use evidence from all three poems to defend or refute.

## DIAGNOSTIC_ANSWER_5
**Refute.** The protagonist exercises **radical agency through vulnerability**. Poem 1: actively places heart at the door ("eksjk fivre ikl"). Poem 2: diagnoses own state ("ge :i fugkjy u;u u frjfir Hksy") — self-knowledge is agency. Poem 3: transforms body into threshold ("dkuu gsfj deyeqf[k]") and commands the divine ("dj nsb >k¡ib dku" — open the door). Suffering is the *medium*, not the *message*; the message is the protagonist's fierce, deliberate self-offering. A wrong answer conflates "helplessness" with "passivity," missing the bhakti tradition's paradox: total surrender = total action.

## DIAGNOSTIC_QUESTION_6
Write a 4-line stanza in the voice of this protagonist *after* the third poem ends, maintaining the same diction (use at least two words from the word-list: e.g., "fNu", "deyeqf[k]", "gsfj", "ekèkc") and the established tone of embodied waiting.

## DIAGNOSTIC_ANSWER_6
**Sample criteria for a strong answer:**
- Uses protagonist's lexicon (e.g., "fNu fNu gsfj jg, ekèkc deyeqf[k]")
- Maintains first-person vulnerability ("I watch," not "he watches")
- Shows continuity: the door is still closed but the watching is now the goal
- Rhythm echoes the original's slow, repetitive cadence
A poor answer writes *about* the protagonist in third person, uses modern vocabulary ("hope", "faith"), or resolves the tension (door opens) — violating the poem's open-ended devotional stance.

## COMMON_MISCONCEPTION
Students conflate the **historical poet (fo|kifr, 1380–1460, multilingual scholar-saint)** with the **literary protagonist (the "I" of the poems)**. They write biographical facts (he knew Sanskrit, he was a king's guru) as character traits of the speaker. This happens because the textbook preface gives the poet's biography *before* the poems, priming students to read the poems as autobiography. The error costs marks because board exams ask "What does the *protagonist* feel?" not "What did the *poet* do?" — and competitive exams (CUET, IPMAT) test the distinction between author and persona explicitly.

## ON_FAILURE
1. **Re-read the preface (node 001) and the poems side-by-side:** Highlight every "I/me/my" in the poems. Ask: "Does the text *say* the speaker is a king's guru? No — it says 'my heart is at your door'." 
2. **Do a "Persona vs Poet" T-chart:** Left column = textual evidence from poems only; Right column = preface facts. Only left column counts for character analysis.
3. **Re-attempt Diagnostic Q2 & Q5** using *only* left-column evidence. If the student still imports biography, have them write a 50-word defense of the protagonist's traits *without using the poet's name once*.

## BUILDS_ON
The skill of distinguishing speaker from author, introduced in Class 11 poetry analysis (e.g., Kabir, Meera), now applied to a more interior, less narrative persona.

## LEADS_TO
Theme analysis (node 006: how the protagonist's journey embodies "prem-marg") and Critical Thinking (node 013: comparing this protagonist with other bhakti personas).

## PREREQUISITE_NODE_IDS
c12_hin_a_cbse_08_001, c12_hin_a_cbse_08_002, c12_hin_a_cbse_08_003, c11_hin_ar_cbse_08_004

## PREREQUISITE_REASONS
c12_hin_a_cbse_08_001: Provides the poet's biography which must be *set aside* to isolate the literary persona.
c12_hin_a_cbse_08_002: Establishes the three-poem sequence as a structural arc (sorrow → diagnosis → vigil) that shapes the protagonist's evolution.
c12_hin_a_cbse_08_003: Supplies the atmosphere (night, threshold, locked door) that the protagonist inhabits and interacts with.
c11_hin_ar_cbse_08_004: Built foundational character-analysis vocabulary (traits, evidence, development) on simpler narrative poems.
## FORWARD_NODE_IDS
c12_hin_a_cbse_08_005, c12_hin_a_cbse_08_006, c12_hin_a_cbse_08_013, c12_hin_a_cbse_08_007

## FORWARD_REASONS
c12_hin_a_cbse_08_005: Supporting characters (the Divine, the "fiz;re", the "xksoqQy") are defined *relationally* by the protagonist's stance toward them.
c12_hin_a_cbse_08_006: The primary theme (surrender as empowerment) *is* the protagonist's arc; theme analysis requires a finished character portrait.
c12_hin_a_cbse_08_013: Critical interpretation (e.g., "Is this protagonist feminist? feudal? modern?") needs a rigorously established baseline character.
c12_hin_a_cbse_08_007: Protagonist (Kabir as speaker) embodies the themes.  

## CROSS_SUBJECT_PREREQS
c11_hin_ar_cbse_08_004

## CROSS_SUBJECT_REASONS
c11_hin_ar_cbse_08_004: Direct predecessor in the Antra textbook — same skill (protagonist analysis) on different poems; this node deepens it with more interior, less dramatic personas.
c11_hin_v_cbse_08_004: Vitan's character analysis (prose) teaches evidence-based trait inference; this node transfers that method to poetic compression and ambiguity.

## CHAIN_DESCRIPTION
c12_hin_a_cbse_08_001 -> c12_hin_a_cbse_08_004 -> c12_hin_a_cbse_08_006

## THIS_FORMULA
N/A - conceptual

## FORMULA_VARIABLES
N/A

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
analytical

## CROSS_SUBJECT
N/A | The protagonist embodies the nirguna/saguna synthesis typical of 15th-century Sant tradition; historical context explains why "doorway" and "threshold" are central metaphors.
 N/A | The protagonist's trajectory (external waiting → internal vigil) maps onto Maslow's self-actualisation via self-transcendence; useful for CUET psychology-literature crossover questions.
## PREREQ_CONCEPT
Distinguishing the *poetic persona* (constructed 'I') from the *historical author* — the single most tested concept in Class 12 poetry analysis.

## PREREQ_BEFORE
Student must be able to underline every first-person pronoun and verb in the three poems and sort them into: physical actions, mental states, and spiritual claims.

## PREREQ_STUCK
If stuck, revisit the "Speaker ≠ Poet" mini-lesson from Class 11 Antra Chapter 8 (node c11_hin_ar_cbse_08_004) and re-do its Worked Example 2 on Kabir's "I".

## WORKED_EXAMPLE_1
PROBLEM: Analyze how the protagonist's **physical posture** evolves across the three poems. Use only verbs and body-images from the text.

STEPS:
- Step 1: Extract all body-related verbs/images from Poem 1. Found: "fivre ikl" (heart at door), "xw¡trs jgrs" (wandering in lanes), "eu Hkkou" (calling out with heart). Posture: *outward-reaching, mobile, vocal*.
- Step 2: Extract from Poem 2. Found: "lf[k gs" (he says/see), "vuqHko eks" (calls out), "ns[kk" (seeing/looking), "Hksy" (being/existing). Posture: *diagnostic, stationary, witnessing own lack*.
- Step 3: Extract from Poem 3. Found: "gsfj" (watching/guarding), "deyeqf[k]" (equal to body), "xj," (walking/moving), "yf[keknsb" (surrendering body). Posture: *architectural, fused with threshold, surrendered yet alert*.
- Step 4: Synthesize the arc: Mobile supplicant → Self-aware witness → Threshold-embodiment. The body shifts from *instrument of search* to *site of encounter*.
- Step 5: Connect to central idea: The protagonist doesn't "find" God; they *become* the space where finding happens. This is the Sant tradition's core insight.

REASONING: This method (verb/image tracking → posture naming → arc synthesis) forces textual evidence and avoids biography. It mirrors the CBSE marking scheme's requirement: "textual reference + interpretive leap."

ANSWER: The protagonist's posture evolves from **wandering with heart at door** (Poem 1) to **standing still, diagnosing own unripeness** (Poem 2) to **becoming the doorway itself, watching moment by moment** (Poem 3). Key evidence: "xw¡trs jgrs" → "lf[k gs" → "dkuu gsfj deyeqf[k]".

## WORKED_EXAMPLE_2
PROBLEM: The protagonist addresses the Divine differently in each poem. Trace the shift in **mode of address** and explain what it reveals about the changing relationship.

STEPS:
- Step 1: Identify address terms in Poem 1. "fivre" (your door), "xksoqQy" (beloved/friend), "eèkqiqj" (morning/sunrise). Mode: *Lover/Friend awaiting dawn* — intimate, expectant, temporal.
- Step 2: Identify in Poem 2. No direct address; third-person "ukf;dk" (helpless one), "fiz;re" (poet/protagonist). Mode: *Self-reflection / diagnostic monologue* — the Divine is the silent standard against which the self is measured.
- Step 3: Identify in Poem 3. ">k¡ib dku" (open the door), "ekèkc" (ears — "listen"), "jeku" (beloved). Mode: *Commanding vulnerability* — the protagonist, now the doorway, demands entry *for* the Divine.
- Step 4: Analyse the shift: External beloved (Poem 1) → Internalised standard (Poem 2) → Indwelling guest (Poem 3). The protagonist *reverses* the host/guest hierarchy.
- Step 5: Link to bhakti theology: This mirrors the Upanishadic "atithi devo bhava" turned inward — the devotee prepares the inner sanctum so the Divine *must* enter.

REASONING: Tracking address terms (vocative case, pronouns, epithets) is a high-yield CBSE skill. It reveals relationship dynamics without needing the poet's biography. The three-step shift (await → measure → host) is a clear, mark-fetching structure.

ANSWER: The address shifts from **"Beloved/Friend at dawn"** (intimate expectation) to **silent benchmark** (self-measurement) to **"Open the door, Beloved, I am the threshold"** (sovereign hospitality). The protagonist moves from *seeking* to *being the condition of meeting*.

## WORKED_EXAMPLE_3
PROBLEM: A board exam question asks: "The protagonist's 'helplessness' (ukf;dk) is actually their greatest strength. Justify with evidence from all three poems." Write a structured 100-word answer using PEEL (Point, Evidence, Explanation, Link).

STEPS:
- Step 1 (Point): The protagonist's confessed helplessness ("ukf;dk", "u;u u frjfir Hksy") is a *strategic spiritual posture*, not a deficit.
- Step 2 (Evidence 1): Poem 1 — "eksjk fivre ikl" places the heart *voluntarily* at the door; helplessness is chosen vulnerability.
- Step 3 (Evidence 2): Poem 2 — "ge :i fugkjy u;u u frjfir Hksy" shows *self-knowledge* (the protagonist sees their own unripeness clearly), which the Gita calls "buddhi-yoga" — strength.
- Step 4 (Evidence 3): Poem 3 — "dkuu gsfj deyeqf[k]" transforms the body *into* the doorway; helplessness becomes *architecture* — the Divine *needs* this doorway to enter.
- Step 5 (Explanation): In Sant poetics, "ukf;dk" = "nirbhar" (dependence) which alone invites "kripa" (grace). The protagonist *masters* helplessness.
- Step 6 (Link): Thus the poems redefine strength as *capacity for surrender* — the central theme of the chapter.

REASONING: PEEL forces the "Evidence → Explanation" pairing that CBSE rubrics reward. Using the text's own terms ("ukf;dk", "frjfir", "deyeqf[k]") shows linguistic precision. The theological link (nirbhar→kripa) adds the "competitive exam depth" (CUET/IPMAT) by connecting to Indian philosophy.

ANSWER: The protagonist's helplessness is a cultivated spiritual strength. In Poem 1, they *choose* to place their heart at the door ("eksjk fivre ikl") — vulnerability as agency. In Poem 2, they *diagnose* their own unripeness ("ge :i fugkjy u;u u frjfir Hksy") — self-knowledge as power. In Poem 3, they *become* the threshold ("dkuu gsfj deyeqf[k]") — helplessness transmuted into the very structure that enables divine entry. As the Sant tradition teaches: "nirbhar te kripa" — only total dependence invites grace. The protagonist masters this paradox.

## COMPETENCY_QUESTION_1
QUESTION: The protagonist in Poem 2 says "lf[k gs] fd iqNfl vuqHko eks" ("He sees that some call goes out"). Who is the "he" (lf[k) — the protagonist observing themselves, or the poet observing the protagonist? Justify your answer using the poem's grammar and the chapter's overall structure.

COMPETENCY: Critical Thinking – Perspective Analysis (identifying narrative voice and its implications)

STEPS:
- Step 1: Note the shift from "I" (Poem 1: "eksjk", "eu") to "he" (Poem 2: "lf[k", "ukf;dk") to "I" again (Poem 3: "ewfn jg,", "dj nsb").
- Step 2: Analyse grammar: "lf[k gs" (he sees/says) + "ukf;dk" (the helpless one) in third person. But the content ("ge :i fugkjy u;u u frjfir Hksy") is *intimate self-knowledge* only the protagonist could have.
- Step 3: Consider structure: Three poems = three stanzas of *one* lyric sequence (common in Sant poetry). The "he" is the protagonist **witnessing their own state** — a meditative distancing (sakshi-bhava).
- Step 4: Reject "poet observing protagonist": The preface (node 001) is separate; the poems don't mention the poet's name, scholarship, or court. The "fiz;re" in Q2 of the textbook refers to the *speaker of the poem*, not the historical author.
- Step 5: Conclude: "lf[k" = protagonist in *witness mode*, a deliberate shift from immersion (Poem 1) to clarity (Poem 2) before re-immersion (Poem 3).

ANSWER: The "he" (lf[k) is the **protagonist observing themselves** (sakshi-bhava). Grammatically, the third-person "ukf;dk" carries first-person content ("my form not realised"). Structurally, the three poems form one persona's arc: immersion → witnessing → embodiment. The historical poet never appears inside the poems.

DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: Design a **comparative table** (3 rows × 4 columns) that a student could use in the exam to contrast this chapter's protagonist with the protagonist of Class 11 Antra Chapter 8 (Kabir's "Santan ko kahan siyau..."). Columns: Core Metaphor, Relationship to Divine, Role of Body, Resolution. Fill it for *both* protagonists.

COMPETENCY: Synthesis – Cross-textual Comparison (board competency: "compare and contrast"; CUET skill: tabular synthesis)

STEPS:
- Step 1: Recall Kabir's protagonist (Class 11): Core Metaphor = **Weaver/Cloth**; Relationship = **Iconoclast/Direct access**; Body = **Loom/Tool**; Resolution = **Realisation in this life**.
- Step 2: Extract fo|kifr's protagonist (this chapter): Core Metaphor = **Threshold/Doorway**; Relationship = **Lover/Host**; Body = **Doorway itself**; Resolution = **Open-ended vigil**.
- Step 3: Build table with precise phrasing for exam use.
- Step 4: Add a one-sentence synthesis: "Kabir's protagonist *weaves* truth; fo|kifr's protagonist *waits* as truth's door."
- Step 5: Verify each cell uses textual terms (e.g., "deyeqf[k]" not "body"; "ujd" not "God").

ANSWER:
| Aspect | fo|kifr's Protagonist (Ch 8) | Kabir's Protagonist (Cl 11 Ch 8) |
|---|---|---|
| Core Metaphor | Threshold / Doorway (dkuu, deyeqf[k]) | Weaver / Cloth (julaha, chadariya) |
| Relationship to Divine | Lover awaiting / Host preparing (fivre, >k¡ib dku) | Seeker bypassing ritual / Direct knower (santan, siyau) |
| Role of Body | Becomes the doorway (dkuu gsfj deyeqf[k]) | Instrument of weaving (kargha, tana-bana) |
| Resolution | Perpetual vigil (fNu fNu gsfj) — grace *may* enter | Completed realisation (jhini chadariya) — truth *woven* |

Synthesis: Kabir's protagonist **achieves** by active weaving; fo|kifr's protagonist **receives** by becoming the space of reception.

DIFFICULTY: hard