## DEFINITION
Literal comprehension questions require students to retrieve explicitly stated information from the text, while inferential comprehension questions demand logical deduction by combining textual evidence with contextual knowledge to derive meaning not directly written. At the senior secondary level, this distinction involves identifying textual markers (keywords, tense, modality) that signal explicit versus implicit meaning, and constructing answers using the PEEL structure (Point, Evidence, Explanation, Link) with appropriate Hindi terminology like "spaṣṭ uttar" (explicit answer) and "anumānātmak uttar" (inferential answer).

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student can independently classify any question from the chapter as literal or inferential, locate precise textual evidence for literal answers, and construct a 4-step inferential answer (claim + textual clue + logical bridge + thematic connection) for questions about Nehru's evolving understanding of "Bharat Mata" and the peasant's identity.

## SCOPE_BOUNDARY
This node covers only the comprehension strategy of distinguishing and answering literal versus inferential questions using the "Bharat Mata" chapter text. It does NOT cover critical analysis (node 013), creative writing (node 014), or speaking skills (node 015). Grammar (node 011) and vocabulary (node 010) are used as tools but not taught here.

## WALKTHROUGH
Imagine you're sitting in the board exam and see Question 3: "नेहरू जी ने 'भारत माता' की परिभाषा कैसे बदली?" You panic because the answer isn't in one sentence. Start by asking: "Is this answer written directly in the text (literal) or must I connect pieces (inferential)?" First, scan for keywords like "नेहरू ने कहा," "लिखा है" — these signal literal retrieval. For inferential, look for "क्यों," "कैसे," "क्या प्रभाव पड़ा" — these require bridging. In this chapter, Nehru's journeys (literal events) become evidence for his realization that people = nation (inferential theme). Practice: underline every "किसान," "मजदूर," "जनता" reference — these are your evidence bank for inferential answers about unity in diversity.

## DIAGNOSTIC_QUESTION_1
पाठ में नेहरू जी द्वारा 'भारत माता' शब्द का प्रयोग सबसे पहले किस संदर्भ में किया गया है? (केवल पाठ से सीधा उत्तर दें)

## DIAGNOSTIC_ANSWER_1
उत्तर: नेहरू जी ने 'भारत माता' शब्द का प्रयोग सबसे पहले तब किया जब वे एक गांव में किसानों से बात कर रहे थे और एक किसान ने उनसे पूछा "भारत माता कौन है?" (पैरा 3-4)। गलत उत्तर बताता है कि छात्र पाठ में 'पहले प्रयोग' को खोजने के बजाय अपने पूर्व ज्ञान से उत्तर दे रहा है — यह literal retrieval skill की कमी दर्शाता है।

## DIAGNOSTIC_QUESTION_2
नेहरू जी लिखते हैं: "भारत माता की जय! इस नारे से उनका अभिप्राय उन लाखों-करोड़ों किसानों-मजदूरों की जय से था।" यह कथन literal है या inferential? समझाएं।

## DIAGNOSTIC_ANSWER_2
उत्तर: यह inferential कथन है क्योंकि नेहरू जी ने सीधे नहीं लिखा "मेरा अभिप्राय किसानों से है" — उन्होंने नारे और जनता के बीच तार्किक संबंध स्थापित किया है। गलत उत्तर (literal कहना) दर्शाता है कि छात्र 'स्पष्ट कथन' और 'लेखक द्वारा निकाला गया निष्कर्ष' में अंतर नहीं कर पा रहा — यह वरिष्ठ माध्यमिक स्तर की आम भ्रांति है जहां 'लिखा हुआ' और 'समझा हुआ' मिल जाते हैं।

## DIAGNOSTIC_QUESTION_3
पाठ के पैरा 2 में नेहरू जी अपनी यात्राओं का वर्णन करते हैं। इस पैरा से एक literal प्रश्न और एक inferential प्रश्न बनाइए, फिर दोनों के उत्तर दीजिए।

## DIAGNOSTIC_ANSWER_3
उत्तर: Literal: "नेहरू जी ने यात्राओं में किन-किन क्षेत्रों का भ्रमण किया?" — उत्तर: "मैदानों से लेकर पहाड़ों तक, नगरों से लेकर गांवों तक।" Inferential: "इन यात्राओं ने नेहरू जी की भारत की समझ को कैसे बदला?" — उत्तर: "यात्राओं ने उन्हें किताबी ज्ञान से हटाकर जीवित भारत (जनता) से जोड़ा, जिससे 'भारत माता' अमूर्त अवधारणा से मूर्त जनता बनी।" गलत उत्तर में दोनों प्रश्नों के उत्तर समान शैली में देना दर्शाता है कि छात्र प्रश्न-प्रकार के अनुसार उत्तर-रणनीति नहीं बदल पाता।

## DIAGNOSTIC_QUESTION_4
पाठ में नेहरू जी एक किसान के प्रश्न "भारत माता कौन है?" का उत्तर देते हुए कहते हैं: "तुम ही भारत माता हो।" इस संवाद का विश्लेषण करते हुए बताएं कि नेहरू जी का यह कथन किस प्रकार literal तथ्य से inferential सत्य की ओर बढ़ता है?

## DIAGNOSTIC_ANSWER_4
उत्तर: Literal तथ्य: किसान ने पूछा, नेहरू ने उत्तर दिया "तुम ही हो"। Inferential सत्य: यह कथन केवल उस किसान के लिए नहीं, समस्त भारतीय जनता के लिए प्रतीकात्मक घोषणा बन जाता है — 'माता' भूमि नहीं, जनता है। गलत उत्तर केवल संवाद सारांश देता है, प्रतीकात्मक विस्तार नहीं पकड़ता — यह दर्शाता है कि छात्र पाठगत प्रसंग को विषयगत थीम (जनता = राष्ट्र) से जोड़ने में असमर्थ है।

## DIAGNOSTIC_QUESTION_5
"नेहरू जी का 'भारत माता' अवधारणा का पुनर्निर्माण केवल बौद्धिक अभ्यास नहीं, राजनीतिक कर्म था।" इस कथन का मूल्यांकन पाठ के साक्ष्य सहित कीजिए। क्या आप सहमत हैं?

## DIAGNOSTIC_ANSWER_5
उत्तर: सहमत, क्योंकि पाठ में नेहरू जी यात्राओं को "देश की खोज" नहीं "देश के निर्माण की योजना" (पैरा 1) बताते हैं — यात्राएं नीति-निर्माण का आधार बनीं (योजना आयोग, वैज्ञानिक संस्थान)। असहमति का तर्क कमजोर होगा क्योंकि पाठ स्पष्टतः 'ज्ञान' को 'कर्म' से जोड़ता है। गलत मूल्यांकन केवल भावनात्मक सहमति देता है, पाठगत साक्ष्य (योजना निर्माण, संस्थान स्थापना) उद्धृत नहीं करता — यह board exam में 'व्याख्या बिना साक्ष्य' की त्रुटि है।

## DIAGNOSTIC_QUESTION_6
अपने शब्दों में एक inferential प्रश्न बनाइए जो पाठ के दो अलग-अलग पैराग्राफों को जोड़ता हो, फिर उसका 4-चरणीय PEEL उत्तर लिखिए।

## DIAGNOSTIC_ANSWER_6
उत्तर: प्रश्न: "नेहरू जी की प्रारंभिक यात्राओं (पैरा 2) और स्वतंत्रता पश्चात् योजनाओं (पैरा 1) में क्या सातत्य है?" PEEL उत्तर: (P) दोनों में जनता केंद्रीय है। (E) पैरा 2: "लाखों-करोड़ों किसानों-मजदूरों" से मिलना; पैरा 1: "देश के निर्माण की योजनाएं... जनता के लिए"। (E) यात्राओं ने जनता की आवश्यकताओं को प्रत्यक्ष दिखाया → योजनाओं ने उन आवश्यकताओं को संस्थागत रूप दिया। (L) यह सातत्य दर्शाता है कि नेहरू जी के लिए 'देश' अमूर्त भूगोल नहीं, सजीव जनता है। खराब उत्तर केवल पैरा 1 या 2 से साक्ष्य देता है, दोनों को नहीं जोड़ता — यह cross-paragraph synthesis की कमी दर्शाता है।

## COMMON_MISCONCEPTION
छात्र समझते हैं कि 'inferential' का अर्थ 'अनुमान लगाना' या 'मन से उत्तर लिखना' है, जबकि वरिष्ठ माध्यमिक स्तर पर inferential का अर्थ है: **पाठगत साक्ष्य (textual evidence) + तार्किक पुल (logical bridge) + प्रसंगगत ज्ञान (contextual knowledge) = न्यायसंगत निष्कर्ष**। उदाहरण: "नेहरू जी किसानों से प्रेम करते थे" — यह अनुमान है, inferential उत्तर नहीं। सही inferential: "नेहरू जी ने किसानों को 'भारत माता' कहा (साक्ष्य), जो उनकी समाजवादी दृष्टि (प्रसंग) से मेल खाता है जहां श्रमिक वर्ग राष्ट्र का निर्माता है (तार्किक पुल)।" छात्र यह भूल करते हैं क्योंकि कक्षा 10 तक 'अनुमान' और 'अनुमानात्मक समझ' में अंतर नहीं सिखाया जाता।

## ON_FAILURE
1. छात्र को पाठ के 5 वाक्य दें और कहें: "हर वाक्य के आगे L (literal) या I (inferential) लिखो कि यह वाक्य सीधा तथ्य दे रहा है या निष्कर्ष।" 2. फिर पूछें: "I वाले वाक्यों में कौन-से शब्द/पद निष्कर्ष की ओर संकेत करते हैं?" (जैसे: 'इसका अर्थ है', 'स्पष्ट होता है', 'प्रतीत होता है')। 3. अब एक inferential प्रश्न दें और कहें: "उत्तर लिखने से पहले 3 साक्ष्य पाठ से छांटकर लाओ।" 4. अंत में PEEL ढांचे में उत्तर लिखवाएं — हर चरण के बाद पूछें: "यह साक्ष्य है या व्याख्या?" यह चरणबद्ध अभ्यास 2-3 बार करने से भ्रांति टूटती है।

## BUILDS_ON
c11_hin_ar_cbse_08_002 (Plot and Narrative Structure) — because understanding Nehru's journey sequence provides the textual timeline needed to locate literal evidence and trace inferential development.

## LEADS_TO
c11_hin_ar_cbse_08_013 (Critical Thinking: Analysis and Interpretation) — because mastery of literal/inferential distinction is prerequisite for higher-order analysis of themes, biases, and authorial intent.

## PREREQUISITE_NODE_IDS
c11_hin_ar_cbse_08_002, c11_hin_ar_cbse_08_004, c11_hin_ar_cbse_08_010, c11_hin_ar_cbse_08_006, c11_hin_ar_cbse_08_008, c11_hin_ar_cbse_08_009, c11_hin_ar_cbse_08_011

## PREREQUISITE_REASONS
c11_hin_ar_cbse_08_002: Plot structure gives the chronological framework to locate literal events (journeys, meetings) and trace how they build inferential understanding.
c11_hin_ar_cbse_08_004: Character analysis of Nehru as narrator-protagonist reveals his evolving perspective — essential for inferring authorial intent behind statements.
c11_hin_ar_cbse_08_010: Vocabulary in context (e.g., 'nfD[ku', 'tq"k', 'd'ked'k') provides precise terminology to distinguish literal descriptions from inferential concepts.
c11_hin_ar_cbse_08_006: Comprehension questions require thematic understanding to answer inferential "why" and "how" questions.  
c11_hin_ar_cbse_08_008: Comprehension questions (literal/inferential) require identifying devices to answer "how does the author convey..." questions.  
c11_hin_ar_cbse_08_009: Comprehension questions often ask "explain the irony in the farmer's reply" — this node supplies the method.  
c11_hin_ar_cbse_08_011: Understanding language usage (vocabulary in context and noun forms) is essential for answering literal and inferential comprehension questions that test nuanced meaning.  

## FORWARD_NODE_IDS
c11_hin_ar_cbse_08_013, c11_hin_ar_cbse_08_014, c11_hin_ar_cbse_08_015, c12_hin_ar_cbse_04_012, c12_hin_ar_cbse_08_012

## FORWARD_REASONS
c11_hin_ar_cbse_08_013: Critical analysis requires separating textual fact (literal) from interpreted meaning (inferential) before evaluating author's arguments.
c11_hin_ar_cbse_08_014: Writing skills (answers, essays) demand PEEL structure which is built on literal evidence + inferential explanation — this node teaches that foundation.
c11_hin_ar_cbse_08_015: Literal and inferential comprehension ensures students can accurately reference textual details during discussion.  
c12_hin_ar_cbse_04_012: अगला तार्किक चरण: Literal comprehension is the ability to extract explicitly stated facts, details, and sequences dire... इस नोड की अवधारणाओं को सीधे उपयोग/विस्तारित करता है।  
c12_hin_ar_cbse_08_012: कक्षा 11 में इसी कौशल का आधारभूत अभ्यास हुआ था; यहाँ उसे कविता की जटिलता पर लागू करना है।  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
none

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_08_002 -> c11_hin_ar_cbse_08_012 -> c11_hin_ar_cbse_08_013

## THIS_FORMULA
PEEL Structure for Inferential Answers: Point (दावा) → Evidence (पाठगत साक्ष्य) → Explanation (तार्किक व्याख्या) → Link (विषयगत संबंध)

## FORMULA_VARIABLES
Point: प्रश्न का सीधा उत्तर (1 वाक्य); Evidence: पाठ से उद्धृत/संदर्भित अंश (लाइन/पैरा संख्या सहित); Explanation: साक्ष्य कैसे दावे का समर्थन करता है (कारण-कार्य संबंध); Link: उत्तर को अध्याय की मुख्य थीम/लेखक के उद्देश्य से जोड़ना

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
linguistic

## CROSS_SUBJECT
c11_history_nationalism | Both Nehru's text and history curriculum examine how 'nation' is constructed through symbols (Bharat Mata) and mass mobilization — literal events (travels, speeches) become inferential evidence for nationalist imagination.
c11_civics_constitution | The chapter's inferential leap from 'people' to 'nation' mirrors Constitutional philosophy (Preamble: 'We the People') — literal citizens become inferential sovereign through democratic theory.

## PREREQ_CONCEPT
Distinction between explicitly stated information (spaṣṭa) and implied meaning (anumānita) in Hindi prose, with ability to locate textual evidence using paragraph/line references.

## PREREQ_BEFORE
Student must be able to: (1) summarize each paragraph in 1 sentence, (2) identify 5 key terms from vocabulary node (nfD[ku, ifPNe, ;d&lk¡, tq"k, d'ked'k), (3) state Nehru's role as narrator-protagonist.

## PREREQ_STUCK
If stuck, review c11_hin_ar_cbse_08_002 (Plot) for event sequence and c11_hin_ar_cbse_08_010 (Vocabulary) for term meanings — these provide the 'what' and 'words' needed for comprehension.

## WORKED_EXAMPLE_1
PROBLEM: बोर्ड परीक्षा प्रश्न: "नेहरू जी ने 'भारत माता' को केवल भौगोलिक इकाई न मानकर जन-समुदाय क्यों माना? पाठ के आधार पर समझाइए।" (3 अंक)
STEPS:
- Step 1: प्रश्न प्रकार पहचानें — 'क्यों' और 'समझाइए' inferential प्रश्न के संकेतक हैं; उत्तर पाठ में सीधे नहीं लिखा, तर्क से निकालना होगा।
- Step 2: थीम पहचानें — प्रश्न 'भारत माता की परिभाषा' पर केंद्रित है, जो अध्याय का केंद्रीय विचार है।
- Step 3: पाठगत साक्ष्य खोजें — पैरा 3-4: किसान का प्रश्न "भारत माता कौन है?", नेहरू का उत्तर "तुम ही हो"; पैरा 5: "भारत माता निजी व्यक्तियों की नहीं... लाखों-करोड़ों किसानों-मजदूरों की जय"; पैरा 1: "देश के निर्माण की योजनाएं... जनता के लिए"।
- Step 4: तार्किक पुल बनाएं — नेहरू जी यात्राओं में जनता से मिले (लiteral) → उनकी पीड़ा/आकांक्षा देखी → समझा कि 'माता' = भूमि नहीं, संतान (जनता) है → यह समाजवादी दृष्टि से मेल खाता है जहां राष्ट्र का अर्थ श्रमिक जन है।
- Step 5: PEEL में ढालें — Point: नेहरू जी के लिए भारत माता = जनता। Evidence: "तुम ही भारत माता हो" (पैरा 4), "लाखों-करोड़ों किसानों-मजदूरों की जय" (पैरा 5)। Explanation: भौगोलिक सीमाएं स्थिर हैं, जनता जीवित/सक्रिय है; राष्ट्र निर्माण जनता की भागीदारी से होता है (योजना आयोग उदाहरण)। Link: यह परिभाषा उपनिवेशवाद-विरोधी संघर्ष को जन-आंदोलन बनाती है।
- Step 6: शब्द-सीमा जांचें — 3 अंक = 60-80 शब्द; उत्तर संक्षिप्त, साक्ष्य-समृद्ध, थीम-संबद्ध हो।
REASONING: यह 6-चरणीय प्रक्रिया सुनिश्चित करती है कि छात्र प्रश्न-प्रकार पहचाने, साक्ष्य खोजे, तर्क बनाए, बोर्ड-मानक संरचना (PEEL) में लिखे, और शब्द-सीमा का पालन करे — ये सभी वरिष्ठ माध्यमिक परीक्षा की मांगें हैं।
ANSWER: नेहरू जी ने 'भारत माता' को जन-समुदाय माना क्योंकि उनकी यात्राओं ने दिखाया कि राष्ट्र की जीवंत शक्ति भौगोलिक सीमाओं में नहीं, किसानों-मजदूरों के श्रम और सपनों में है। पैरा 4 में किसान को वे कहते हैं: "तुम ही भारत माता हो" और पैरा 5 में स्पष्ट करते हैं कि "भारत माता की जय" का अर्थ "लाखों-करोड़ों किसानों-मजदूरों की जय" है। यह दृष्टि उनके समाजवादी चिंतन से मेल खाती है जहां राष्ट्र-निर्माण जनता की सक्रिय भागीदारी से होता है (पैरा 1: योजनाएं जनता के लिए)।

## WORKED_EXAMPLE_2
PROBLEM: अभ्यास प्रश्न: "पाठ में नेहरू जी की यात्राओं के दो उद्देश्य बताइए।" (2 अंक) — यह literal प्रश्न है।
STEPS:
- Step 1: प्रश्न प्रकार पहचानें — 'बताइए' + 'दो उद्देश्य' = literal retrieval; उत्तर पाठ में स्पष्टतः लिखे हैं।
- Step 2: कीवर्ड स्कैन करें — 'उद्देश्य', 'लक्ष्य', 'कारण', 'चाहते थे', 'इरादा' जैसे शब्द पैरा 1-2 में खोजें।
- Step 3: सटीक वाक्य लोकेट करें — पैरा 1: "देश की खोज... देश के निर्माण की योजना बनाने के लिए"; पैरा 2: "अपनी इस खोज में... जनता को जानने की उत्कंठा"।
- Step 4: उत्तर संक्षिप्त करें — बोर्ड परीक्षा में 2 अंक = 2 बिंदु, प्रत्येक 15-20 शब्द; अनावश्यक व्याख्या न जोड़ें।
- Step 5: सत्यापन — दोनों उद्देश्य पाठ से सीधे उठाए गए हैं? हां। कोई inferential मिलावट तो नहीं? नहीं।
REASONING: Literal प्रश्नों में छात्र अक्सर अनावश्यक व्याख्या जोड़कर समय गंवाते हैं या अपने ज्ञान से उत्तर देते हैं। यह 5-चरणीय प्रक्रिया सटीक retrieval और संक्षिप्त प्रस्तुति सिखाती है — बोर्ड परीक्षा में समय प्रबंधन के लिए आवश्यक।
ANSWER: (1) देश की वास्तविकता जानकर देश-निर्माण की योजनाएं बनाना (पैरा 1)। (2) जनता से सीधे मिलकर उनकी स्थिति, आकांक्षाएं और एकता समझना (पैरा 2)।

## WORKED_EXAMPLE_3
PROBLEM: संयुक्त प्रश्न: "नेहरू जी के कथन 'हम सब एक ही नाव के यात्री हैं' (पैरा 4) का अर्थ स्पष्ट कीजिए और बताइए कि यह कथन पाठ की किस मुख्य थीम को अभिव्यक्त करता है।" (4 अंक) — इसमें literal (अर्थ) + inferential (थीम) दोनों हैं।
STEPS:
- Step 1: प्रश्न विघटित करें — भाग A: "अर्थ स्पष्ट कीजिए" (literal + सूक्ष्म व्याख्या); भाग B: "कौन-सी थीम अभिव्यक्त" (inferential)।
- Step 2: भाग A के लिए साक्ष्य — पैरा 4: "सबकी राहें एक-सी... एक ही नाव के यात्री" — संदर्भ: किसानों-मजदूरों की साझी पीड़ा (भूख, गरीबी, शोषण)।
- Step 3: भाग A का उत्तर — Literal अर्थ: सभी भारतीयों (नेहरू सहित) की नियति साझी है; रूपक: नाव = राष्ट्र, यात्री = नागरिक, लहरें = साम्राज्यवाद/गरीबी।
- Step 4: भाग B के लिए थीम पहचानें — पाठ की मुख्य थीम: 'विविधता में एकता' / 'जनता ही राष्ट्र' / 'साझा संघर्ष'। पैरा 3, 5, 6 से पुष्टि।
- Step 5: भाग B का तार्किक पुल — 'एक नाव' रूपक → व्यक्तिगत भिन्नताओं (धर्म, क्षेत्र, वर्ग) के ऊपर साझा नियति → यह 'विविधता में एकता' थीम का रूपकात्मक कथन है।
- Step 6: संयुक्त उत्तर PEEL में — Point: कथन साझी नियति और एकता व्यक्त करता है। Evidence: "एक ही नाव के यात्री" (पैरा 4), "हिंदू-मुसलमान... सबकी राहें एक-सी" (पैरा 3)। Explanation: रूपक दर्शाता है कि उपनिवेशवाद और गरीबी सबको समान रूप से प्रभावित करते हैं, इसलिए मुक्ति भी सामूहिक है। Link: यह 'भारत माता = जनता' परिभाषा का विस्तार है — जनता की एकता ही राष्ट्र की शक्ति है।
REASONING: संयुक्त प्रश्न बोर्ड परीक्षा में आम हैं (3-4 अंक)। यह उदाहरण दिखाता है कि literal और inferential भागों को अलग-अलग हल करके फिर जोड़ना कैसे आवश्यक है — छात्र अक्सर दोनों को मिला देते हैं या थीम को साक्ष्य बिना बताते हैं।
ANSWER: 'एक ही नाव के यात्री' का अर्थ: सभी भारतीय नागरिकों की नियति साझी है — उपनिवेशवादी शोषण और गरीबी रूपी लहरें सबको समान डुबोती/तैराती हैं। यह कथन पाठ की केंद्रीय थीम 'विविधता में एकता' (साझा संघर्ष, साझी मुक्ति) अभिव्यक्त करता है। पैरा 3 में नेहरू जी लिखते हैं: "हिंदू-मुसलमान... सबकी राहें एक-सी" और पैरा 5 में: "भारत माता... लाखों-करोड़ों किसानों-मजदूरों की जय" — रूपक पुष्टि करता है कि राष्ट्र की एकता भौगोलिक नहीं, जनता के साझे अनुभव और संघर्ष में निहित है।

## COMPETENCY_QUESTION_1
QUESTION: पाठ के पैरा 2 और पैरा 5 को पढ़कर बताइए: नेहरू जी की यात्राओं ने उनकी 'भारत माता' अवधारणा को कैसे रूपांतरित किया? अपने उत्तर में दोनों पैराग्राफों से कम से कम एक-एक साक्ष्य उद्धृत करें और PEEL संरचना का प्रयोग करें।
COMPETENCY: Cross-paragraph synthesis with evidence-based inferential reasoning
STEPS:
- Step 1: दोनों पैराग्राफों में 'भारत माता' या समतुल्य पद खोजें — पैरा 2: "देश की खोज", "जनता को जानने की उत्कंठा"; पैरा 5: "भारत माता... लाखों-करोड़ों किसानों-मजदूरों की जय"।
- Step 2: रूपांतरण की दिशा पहचानें — अमूर्त/पुस्तकीय (पैरा 2 प्रारंभ) → मूर्त/जीवंत (पैरा 5)।
- Step 3: PEEL बिंदु बनाएं — Point: यात्राओं ने पुस्तकीय ज्ञान को जीवंत अनुभव में बदला। Evidence: पैरा 2 "किताबों में पढ़ा था... पर देखा नहीं था", पैरा 5 "तुम ही भारत माता हो"। Explanation: प्रत्यक्ष संपर्क ने अमूर्त 'देश' को सजीव 'जनता' बनाया। Link: यह रूपांतरण नेहरू की नीतियों (योजना आयोग, पंचवर्षीय योजनाओं) का आधार बना।
- Step 4: उत्तर लिखें — संकेत: 80-100 शब्द, दोनों पैरा के साक्ष्य अनिवार्य।
ANSWER: नेहरू जी की यात्राओं ने 'भारत माता' को पुस्तकीय अवधारणा से जीवंत जन-समुदाय में रूपांतरित किया। पैरा 2 में वे स्वीकारते हैं: "किताबों में पढ़ा था... पर देखा नहीं था" — यात्राओं से पहले 'देश' अमूर्त था। पैरा 5 में किसान से संवाद के बाद वे घोषित करते हैं: "भारत माता... लाखों-करोड़ों किसानों-मजदूरों की जय" — अब 'माता' भूगोल नहीं, श्रमिक जनता है। यह रूपांतरण दर्शाता है कि नेहरू जी के लिए राष्ट्र निर्माण का अर्थ नीतियां बनाना नहीं, जनता की आकांक्षाओं को संस्थागत रूप देना था (पैरा 1: योजनाएं जनता के लिए)।
DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: "नेहरू जी का 'भारत माता' रूपक उपनिवेशवाद-विरोधी राष्ट्रवाद का सामाजिक-लोकतांत्रिक संस्करण है।" इस कथन का मूल्यांकन पाठ के तीन अलग-अलग प्रसंगों से साक्ष्य लेकर कीजिए। आपके उत्तर में literal तथ्य और inferential व्याख्या स्पष्टतः अलग-अलग चिह्नित होने चाहिए।
COMPETENCY: Multi-evidence evaluation with explicit literal/inferential demarcation
STEPS:
- Step 1: कथन के तीन घटक पहचानें — (i) उपनिवेशवाद-विरोधी, (ii) राष्ट्रवाद, (iii) सामाजिक-लोकतांत्रिक।
- Step 2: प्रत्येक घटक के लिए एक प्रसंग/साक्ष्य लोकेट करें — (i) पैरा 6: "अंग्रेजी राज... शोषण", (ii) पैरा 3: "हिंदू-मुसलमान... एक ही नाव", (iii) पैरा 5: "किसानों-मजदूरों की जय", पैरा 1: "योजनाएं जनता के लिए"।
- Step 3: Literal/Inferential टैग करें — Literal: उद्धृत वाक्य; Inferential: व्याख्या कि यह सामाजिक-लोकतांत्रिक राष्ट्रवाद कैसे दर्शाता है।
- Step 4: संश्लेषण करें — तीनों प्रसंग मिलकर कथन की पुष्टि करते हैं: उपनिवेशवाद विरोध (प्रसंग 1) + धार्मिक एकता (प्रसंग 2) + वर्ग-केन्द्रीयता (प्रसंग 3) = सामाजिक-लोकतांत्रिक राष्ट्रवाद।
- Step 5: मूल्यांकन भाषा में उत्तर दें — "कथन सुसंगत है क्योंकि..." / "आंशिक रूप से सही है क्योंकि..."
ANSWER: कथन सुसंगत है। Literal साक्ष्य 1 (पैरा 6): "अंग्रेजी राज ने... शोषण किया" → Inferential: उपनिवेशवाद-विरोधी चेतना का आधार। Literal साक्ष्य 2 (पैरा 3): "हिंदू-मुसलमान... सबकी राहें एक-सी" → Inferential: धार्मिक विभाजन से ऊपर राष्ट्रीय एकता — लोकतांत्रिक राष्ट्रवाद का लक्षण। Literal साक्ष्य 3 (पैरा 5): "भारत माता... किसानों-मजदूरों की जय" + पैरा 1: "योजनाएं... जनता के लिए" → Inferential: राष्ट्र की परिभाषा में श्रमिक वर्ग को केंद्रीय रखना सामाजिक-लोकतांत्रिक दृष्टि दर्शाता है (बुर्जुआ राष्ट्रवाद से भिन्न)। तीनों प्रसंग मिलकर सिद्ध करते हैं कि नेहरू जी का 'भारत माता' रूपक केवल भावनात्मक प्रतीक नहीं, राजनीतिक-आर्थिक कार्यक्रम का घोषणापत्र है।
DIFFICULTY: hard