## DEFINITION
Vocabulary in Context: Key Words refers to the skill of determining the precise meaning of specific words or phrases as they are used within a particular literary text, considering the historical period, dialect, cultural connotations, and poetic intent, rather than relying solely on standard dictionary definitions.

## COGNITIVE_LEVEL
understand

## MASTERY_CRITERIA
The student can independently identify archaic or dialect-specific words in Kabir's poem, explain their contextual meaning with textual evidence, and differentiate between the literal/dictionary meaning and the poetic/connotative meaning in at least three key words from the chapter.

## SCOPE_BOUNDARY
This node covers only the key vocabulary items explicitly listed in the NCERT 'kCnkFkZ vkSj fVIi.kh' section for Chapter 9 (iR;kfu, vkukdkuh, vkjlh, owQdHkjh, iSt, cgjk;cs) and the strategy for decoding similar words in the poem. It does not cover grammatical analysis (node 011), comprehension questions (node 012), or literary devices (nodes 008, 009).

## WALKTHROUGH
Imagine you are reading a 15th-century saint-poet's verse and you stumble on "vkukdkuh" — your modern Hindi dictionary says "speech" but the line "vkukdkuh vkjlh fugkfjcks djkSxs dkSykSa" makes no sense with that meaning. You feel stuck because the word seems familiar but the meaning slips away. Start by reading the **entire stanza aloud** to hear the rhythm and emotion. Then, **isolate the target word** and examine the words immediately before and after it (the co-text). Ask: "What action or feeling is the poet describing here?" Use the **cultural/historical context** (Bhakti movement, weaver's life, Nirguna Bhakti) to guess the nuance. Finally, **verify with the NCERT gloss** but also note where the gloss simplifies the poetic force. The key insight: in poetry, words are not containers of fixed meaning; they are events that happen in a specific linguistic and emotional environment.

## DIAGNOSTIC_QUESTION_1
What is the meaning of 'iR;kfu' as given in the NCERT glossary for this chapter, and what is its root verb in Sanskrit?

## DIAGNOSTIC_ANSWER_1
The NCERT glossary defines 'iR;kfu' as 'fo'okl djuk' (to praise/glorify). Its root is the Sanskrit verb 'iR;' (to praise). A wrong answer (e.g., 'to sing' or 'to pray') reveals the student is confusing synonyms or importing general bhakti vocabulary instead of using the specific gloss provided. This error leads to misreading the opening line "cfr;kfu dh iR;kfu" as "singing of songs" rather than "the act of glorifying/praising the Lord," missing the deliberate, declarative force of 'iR;kfu'.

## DIAGNOSTIC_QUESTION_2
In the line "vkukdkuh vkjlh fugkfjcks djkSxs dkSykSa", the word 'vkukdkuh' is glossed as 'Vkyus dh ckr' (the matter of speaking). Explain why the poet chooses this abstract noun form instead of a simple verb like 'vkuk' (to speak) in this rhetorical question.

## DIAGNOSTIC_ANSWER_2
The abstract noun 'vkukdkuh' (the act/instance of speaking) objectifies speech itself, turning the act of utterance into a tangible 'thing' that can be 'fugkfjcks' (shaken/disturbed). The poet asks: "Who can disturb the *very phenomenon* of speaking?" using a verb would reduce it to an action someone does. A wrong answer focusing only on dictionary meaning ("speech") misses the philosophical weight: Kabir elevates human speech to a cosmic principle that cannot be shaken by worldly powers. This misconception causes students to treat vocabulary as interchangeable synonyms rather than as precise poetic choices.

## DIAGNOSTIC_QUESTION_3
Apply the 'context-clue' strategy to determine the meaning of 'owQdHkjh' in the line "owQdHkjh ewdrk cqyk; vki cksfygSA" given that the gloss says 'iqdkj Hkjh' (filling the lap). What specific cultural practice does this phrase invoke, and how does it change the meaning of 'ewdrk' (patience/endurance) in this context?

## DIAGNOSTIC_ANSWER_3
Step 1: Identify the phrase 'owQdHkjh ewdrk' — the compound suggests 'patience that fills the lap'. Step 2: Recall the cultural practice: in North Indian tradition, a woman seeking a boon (especially a son) holds out her aanchal (lap) to a saint/deity; the saint 'fills the lap' by granting the wish. Step 3: 'ewdrk' (patience/endurance) here is not passive waiting but the *active, expectant posture* of a devotee presenting her lap. Step 4: The poet says the Divine Mother (or the Guru) fills that lap — meaning the devotee's sustained spiritual practice is rewarded. A student who only knows 'ewdrk = patience' misses the vivid ritual imagery and the transactional intimacy between devotee and Divine.

## DIAGNOSTIC_QUESTION_4
Compare the usage of 'iSt' (gloss: 'cgl' — heart/mind) in Kabir's line "tkfu;Sxks Vsd Vjsa dkSu èkkS eyksfygSAA" with its usage in Tulsidas's 'Ramcharitmanas' (e.g., 'iSt dev'). Analyze how the *same word* carries different theological weight in Nirguna vs Saguna bhakti vocabulary.

## DIAGNOSTIC_ANSWER_4
In Kabir (Nirguna), 'iSt' refers to the *formless inner witness* — the 'cgl' where the Divine resides without attributes. The line asks: "Who can know the secret of that Inner Dweller?" In Tulsidas (Saguna), 'iSt dev' means 'chosen deity with form' (Ram/Krishna). Kabir uses 'iSt' to deny external form; Tulsidas uses it to affirm a specific form. A student who treats 'iSt' as a static synonym for 'God' fails to see how vocabulary encodes sectarian theology. This analytical gap appears in board exams when questions ask "explain the significance of the word 'iSt' in the given line" — the answer must reference Nirguna interiority.

## DIAGNOSTIC_QUESTION_5
Evaluate the NCERT gloss 'cgjk;cs = cgjs cuus dh] dkuksa ls u lquus dh' (making noise, not listening to anyone) for the word in the line "#bZ fn, jgkSxs dgk¡ ykS cgjk;cs dh\". Does this gloss capture the full poetic force? Justify your evaluation with reference to the poem's theme of spiritual awakening vs worldly noise.

## DIAGNOSTIC_ANSWER_5
The gloss is *necessary but insufficient*. It captures the surface behavior (loud, heedless) but misses the *metaphorical resonance*: 'cgjk;cs' represents the **worldly chaos (samsara)** that drowns the 'anhad naad' (unstruck sound) of inner truth. The poem contrasts this noise with the silence of 'vkukdkuh' (true speech) and 'iR;kfu' (praise). A full evaluation must note that the gloss reduces a thematic symbol to a behavioral adjective. Students who accept the gloss uncritically write shallow answers like "the poet says people are noisy" instead of "the poet contrasts the cacophony of worldly attachment (cgjk;cs) with the silent language of the soul."

## DIAGNOSTIC_QUESTION_6
Create a two-line couplet (doha/chaupai style) using **three** of the six key vocabulary words (iR;kfu, vkukdkuh, vkjlh, owQdHkjh, iSt, cgjk;cs) in a *new context* (e.g., a student's exam anxiety, a farmer's prayer) that demonstrates their contextual meanings correctly.

## DIAGNOSTIC_ANSWER_6
Example: "parIkxw dE bhIq mnu, owQdHkjh mMgY iSt\ nklY vkukdkuh qb, iR;kfu kry suinSY mt\\" (Fearful mind in exam, asks chosen deity with outstretched lap / When true speech emerges, praise happens automatically). A good answer uses each word in its *grammatical and semantic slot*: owQdHkjh as active petitioning, iSt as internal anchor, vkukdkuh as authentic utterance, iR;kfu as spontaneous gratitude. A poor answer forces words into wrong slots (e.g., "iR;kfu krY owQdHkjh" — treating owQdHkjh as an object of praise), revealing the student hasn't internalized the syntactic frames.

## COMMON_MISCONCEPTION
Students treat the NCERT glossary meanings as **exhaustive definitions** to be memorized for fill-in-the-blanks, ignoring that Kabir's vocabulary operates in **semantic fields** (e.g., 'vkukdkuh' connects to 'vkjlh' [rumour/false speech] and 'iR;kfu' [true speech]). They write "vkukdkuh means speech" in exams but cannot explain why the poet contrasts it with 'vkjlh' in the same line. This happens because Class 11 vocabulary nodes focused on *word-meaning matching*; Class 12 demands *word-in-system analysis*. The error costs marks in 3-mark "explain with context" questions and in CUET/Hindi literature entrance questions on textual semantics.

## ON_FAILURE
1. **Revisit the poem's audio recording** (NCERT/CIET) — hear the rhythm of 'vkukdkuh vkjlh' as a rhythmic pair. 2. **Make a 3-column table**: Word | NCERT Gloss | Poetic Function (contrast, metaphor, ritual, theological). Fill for all 6 words. 3. **Re-do Diagnostic Q2 & Q4** using the table. 4. **Ask teacher/peer**: "Show me one line where 'iSt' means something different in another Bhakti poet." If unable to do step 4, revisit Class 11 node **c11_hin_ar_cbse_09_010** (Kabir vocabulary) and **c11_hin_ar_cbse_10_010** (Surdas vocabulary) to compare Nirguna vs Saguna lexicon.

## BUILDS_ON
Class 11 skill of using glossaries (c11_hin_ar_cbse_09_010) to now perform contextual semantic analysis in a Nirguna Bhakti text.

## LEADS_TO
Grammar: Language Usage in the Text (c12_hin_a_cbse_09_011) where these same words are analyzed for morphological structure (e.g., 'vkukdkuh' = vkuk + ktvul suffix) and syntactic role.

## PREREQUISITE_NODE_IDS
c11_hin_ar_cbse_09_010, c12_hin_a_cbse_09_001, c12_hin_a_cbse_09_002, c11_hin_ar_cbse_10_010

## PREREQUISITE_REASONS
c11_hin_ar_cbse_09_010: Class 11 Kabir vocabulary node established basic glossary usage and Braj Bhasha familiarity. c12_hin_a_cbse_09_001: Context/Background node provides the Nirguna Bhakti framework essential for theological nuances of 'iSt' and 'iR;kfu'. c12_hin_a_cbse_09_002: Plot/Narrative Structure node gives the poem's dramatic situation (weaver-poet addressing Divine Mother) which frames the vocabulary's emotional tone.
c12_hin_a_cbse_09_001: "Before You Read: की समझ आवश्यक है, क्योंकि यह नोड (Vocabulary in Context:) इसी आधार पर आगे बढ़ता है।  
c12_hin_a_cbse_09_002: Plot and narrative structure in poetry refers to the organized sequence of events, conflic... की समझ आवश्यक है, क्योंकि यह नोड (Vocabulary in Context:) इसी आधार पर आगे बढ़ता है।  
c11_hin_ar_cbse_10_010: poet." If unable to do step 4, revisit Class 11 node c11_hin_ar_cbse_09_010 (Kabir vocabulary) and c11_hin_ar_cbse_10_010 (Surdas vocabulary) to compare Nirguna vs Saguna lexicon.  

## FORWARD_NODE_IDS
c12_hin_a_cbse_09_011, c12_hin_a_cbse_09_012, c12_hin_a_cbse_09_013, c12_hin_a_cbse_09_008, c12_hin_a_cbse_09_014, c12_hin_a_cbse_09_015

## FORWARD_REASONS
c12_hin_a_cbse_09_011: Grammar node analyzes the morphology/syntax of these exact words (e.g., 'owQdHkjh' as compound noun). c12_hin_a_cbse_09_012: Comprehension questions require precise vocabulary understanding to answer inferential questions. c12_hin_a_cbse_09_013: Critical Thinking asks for interpretation of themes (e.g., 'true speech vs noise') built on these vocabulary distinctions.
c12_hin_a_cbse_09_008: Vocabulary in Context is non-negotiable — Braj words like "फनुक" (गति/चाल), "वकुदकुह" (कठोर वचन), "फुगफजक्स" (काँपना) carry the sensory load; guessing meanings leads to wrong imagery classification.  
c12_hin_a_cbse_09_014: Vocabulary meanings ensure accurate Evidence quotation and interpretation  
c12_hin_a_cbse_09_015: Key vocabulary (owQdHkjh, fugkfjcks, iSt) must be pronounced and defined correctly in formal Hindi during discussion.  
c12_hin_a_cbse_09_012: Key vocabulary (owQdHkjh, iSt, cgjk;cs) must be understood to locate literal meaning.  
c12_hin_a_cbse_09_013: Vocabulary (Braj/Awadhi terms: iSt, owQdHkjh, cqyk;) enables linguistic Craft analysis.  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
No direct cross-subject prerequisite nodes in the provided list; all prior nodes are Hindi literature. Cross-subject links are established in the CROSS_SUBJECT section below.

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_09_010 -> c12_hin_a_cbse_09_010 -> c12_hin_a_cbse_09_011

## THIS_FORMULA
N/A - conceptual

## FORMULA_VARIABLES
N/A

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
linguistic

## CROSS_SUBJECT
N/A | The Nirguna vocabulary (iSt, iR;kfu, vkukdkuh) encodes specific theological positions (formless divine, interiority, rejection of ritual) that are central to the 'Medieval Bhakti-Sufi Traditions' chapter in Class 12 History. Understanding 'iSt' as 'inner witness' not 'chosen deity' is a historical interpretive skill.
 N/A | The skill of 'contextual semantic analysis' (distinguishing dictionary vs poetic meaning, tracing semantic fields) is identical to the 'close reading' competency required for Class 12 English Elective/Core poetry (e.g., analyzing Donne's 'canonization' or Dickinson's 'brain'). The methodological steps (co-text, cultural code, thematic resonance) transfer directly.
## PREREQ_CONCEPT
Ability to use a provided glossary while recognizing its limitations for poetic language.

## PREREQ_BEFORE
Student must have read the poem at least twice (once silently, once aloud) and attempted the NCERT 'kCnkFkZ' exercise.

## PREREQ_STUCK
If stuck on a word's poetic force, review the **'Context and Background' node (c12_hin_a_cbse_09_001)** for the weaver-saint's life situation — vocabulary meaning is anchored in his lived reality.

## WORKED_EXAMPLE_1
PROBLEM: Explain the meaning and significance of the phrase "vkukdkuh vkjlh" in the second stanza of the poem. Why are these two words placed together?

STEPS:
- Step 1: Locate the line: "vkukdkuh vkjlh fugkfjcks djkSxs dkSykSa\" — it is a rhetorical question in the second stanza (after the opening praise).
- Step 2: Retrieve glosses: vkukdkuh = 'Vkyus dh ckr' (the matter of true speech/utterance); vkjlh = 'fL=k;ksa }kjk v¡xwBs esa iguk tkus okyk 'kh'kk' (rumour/gossip heard through messengers/tradition).
- Step 3: Analyze the syntactic pairing: they are compound subjects of 'fugkfjcks' (can shake/disturb). The poet asks: "Who can shake *both* true utterance *and* hearsay?"
- Step 4: Interpret the semantic contrast: vkukdkuh = direct, experiential, authoritative speech (the Guru's/poet's voice); vkjlh = indirect, derivative, unstable hearsay (scriptural ritualism, priestly tradition). Kabir claims his speech is unshakeable *because* it is not based on vkjlh.
- Step 5: Connect to theme: This vocabulary pair establishes the poem's central epistemological claim — **direct experience (vkukdkuh) vs borrowed knowledge (vkjlh)**. The vocabulary *is* the argument.

REASONING: The steps move from textual location -> gloss retrieval -> syntactic analysis -> semantic contrast -> thematic integration. This mirrors the board exam expectation for 3-mark 'explain with context' answers: quote, gloss, analyze function, link to central idea.

ANSWER: "vkukdkuh vkjlh" pairs the poet's direct, experiential utterance (vkukdkuh) against tradition-bound hearsay (vkjlh). Placed as joint objects of 'who can shake', they declare that the poet's Nirguna realization renders both his own true speech and the world's false rumours equally immovable — because truth is self-authenticating. This vocabulary contrast structures the poem's defence of direct bhakti over ritual mediation.

## WORKED_EXAMPLE_2
PROBLEM: The gloss for 'cgjk;cs' is 'cgjs cuus dh, dkuksa ls u lquus dh'. A student writes in the exam: "The poet scolds people for being loud and disobedient." Why is this answer incomplete for a 3-mark question? Rewrite it to full marks standard.

STEPS:
- Step 1: Identify the gap: the student treated 'cgjk;cs' as a character trait of 'people' rather than a **symbolic state** contrasted with spiritual silence.
- Step 2: Re-read the line: "#bZ fn, jgkSxs dgk¡ ykS cgjk;cs dh\\ dcgw¡ rkS esfj;S iqdkj dku [kksfy gSA" — the poet asks *where* such noise exists, implying it is absent in the realized state.
- Step 3: Map the semantic field: cgjk;cs (worldly cacophony) ↔ vkukdkuh (true speech) ↔ iR;kfu (praise) ↔ tku ?kuvkuan (deep silence/listening). The poem moves from noise to silence to true speech.
- Step 4: Draft the full answer using PEEL: Point — 'cgjk;cs' symbolizes the distractions of samsara. Evidence — the line places it in a rhetorical question about its absence in the liberated state. Explanation — the 'noise' is not literal sound but the clamour of desires, rituals, and duality that drowns the 'anhad naad'. Link — Kabir's vocabulary maps the spiritual journey from noise (cgjk;cs) to silent knowing (tku ?kuvkuan).
- Step 5: Verify against marking scheme: 1 mark for symbolic meaning, 1 for textual evidence, 1 for thematic linking.

REASONING: Board exams reward answers that show the word *working inside the poem's architecture*, not just its dictionary definition. The rewrite demonstrates the 'vocabulary in context' competency: meaning emerges from systemic relations, not isolation.

ANSWER: Improved answer: "In Kabir's poem, 'cgjk;cs' (literally: making noise, not listening) functions as a metaphor for the **cacophony of worldly attachments and ritualistic distractions** that prevent the seeker from hearing the inner unstruck sound (anhad naad). The rhetorical question '#bZ fn, jgkSxs dgk¡ ykS cgjk;cs dh' implies that in the state of true realization (where the Divine Mother fills the devotee's lap), this noise ceases. Thus, the word marks the **threshold between ignorance (noise) and knowledge (silence/true speech)** central to Nirguna bhakti."

## WORKED_EXAMPLE_3
PROBLEM: A CUET Hindi question asks: "In Kabir's vocabulary, how does the meaning of 'iSt' differ from its meaning in Tulsidas? Cite one line from each poet to support your answer." Construct a model answer.

STEPS:
- Step 1: Define the core difference: Nirguna (Kabir) 'iSt' = formless inner reality (cgl/heart); Saguna (Tulsidas) 'iSt' = chosen deity with form (iSt dev).
- Step 2: Select Kabir line: From this poem — "tku ?kuvkuan ;ksa eks¯g rqEgS iSt ijh" (The secret of that Inner Dweller...). Here 'iSt' is the *object of inner knowing*, located in the body-heart.
- Step 3: Select Tulsidas line: From Ramcharitmanas, Bal Kand — "iSt devu bhajahu mana bhai" (Worship your chosen deity, O mind). Here 'iSt devu' = Ram with form, attributes, lilas.
- Step 4: Analyze the grammatical marker: Kabir uses bare 'iSt' (masculine, singular, abstract); Tulsidas uses compound 'iSt devu' (deity). The compound signals Saguna specificity.
- Step 5: Synthesize: Kabir's vocabulary *empties* 'iSt' of form to point to the formless; Tulsidas's vocabulary *fills* 'iSt' with a specific divine personality. Both use the same Sanskrit root (iSt = desired/liked) but the **theological grammar** diverges.
- Step 6: Format for CUET: Concise, comparative, evidence-based. Use terminology: 'Nirguna interiority' vs 'Saguna iconicity'.

REASONING: Competitive exams (CUET, JNU entrance) test *comparative philology* across Bhakti poets. The worked example models how vocabulary nodes feed directly into higher-order comparative questions. Steps enforce: definition -> textual evidence -> grammatical marker -> theological synthesis -> exam formatting.

ANSWER: "Kabir (Nirguna): 'iSt' = the formless Divine residing in the heart (cgl), known only through inner silence. Line: 'tku ?kuvkuan ;ksa eks¯g rqEgS iSt ijh' — 'iSt' is the secret inner reality. Tulsidas (Saguna): 'iSt dev' = the chosen personal deity (Ram) with form and attributes. Line: 'iSt devu bhajahu mana bhai' — 'iSt devu' is the object of devotional worship. Difference: Kabir uses 'iSt' to denote **subjective interiority**; Tulsidas uses 'iSt dev' to denote **objective iconicity**. The shared root 'iSt' (desired) is inflected by their respective theologies."

## COMPETENCY_QUESTION_1
QUESTION: A Class 12 student writes in a board exam answer: "The word 'owQdHkjh' means filling the lap. The poet says the Mother fills the lap with patience." The teacher gives 1/3 marks. Using the vocabulary-in-context framework, explain **why** this answer is insufficient and what **two specific elements** are missing for full marks.

COMPETENCY: Critical analysis of exam answer quality (metacognitive skill)

STEPS:
- Step 1: Identify the student's error: they paraphrased the gloss + line literally without decoding the **cultural ritual** (aanchal bharna) or the **metaphorical transfer** (ewdrk = spiritual practice, not literal patience).
- Step 2: Name missing element 1: **Cultural code activation** — the answer must mention the North Indian ritual of a devotee holding out her aanchal (lap) to a saint/goddess for a boon (typically a son). 'owQdHkjh' invokes this specific visual.
- Step 3: Name missing element 2: **Semantic revaluation** — 'ewdrk' (patience/endurance) is revalued from 'passive waiting' to 'active, expectant spiritual posture'. The 'filling' is the grace granted *to* that posture.
- Step 4: Formulate the feedback: "Your answer treats vocabulary as static labels. Full marks require showing how the word *activates a cultural scene* and *shifts meaning* in the poetic system."

REASONING: This competency question tests the student's ability to *evaluate* an answer using the very framework taught in this node — moving beyond "what does it mean?" to "how does it mean in this text?" This is a high-order skill for board exam self-assessment and competitive exam answer-writing.

ANSWER: The answer is insufficient because it (1) fails to activate the cultural ritual of 'aanchal bharna' (holding out the lap for a boon) which gives 'owQdHkjh' its emotional and visual force, and (2) misses the metaphorical revaluation of 'ewdrk' from 'patience' to 'sustained spiritual practice as expectant posture'. For full marks, the answer must explain: "The poet uses the ritual image of a devotee presenting her lap (owQdHkjh) to the Divine Mother; her 'ewdrk' (spiritual endurance) is the outstretched lap, and the Mother's grace 'fills' it — transforming waiting into receiving."

DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: Design a **vocabulary mapping exercise** for a peer who struggles with Kabir's archaic words. The exercise must use the six key words from this chapter and require the peer to: (a) group them into two semantic fields, (b) draw one connecting arrow between fields with a label, (c) write one "context sentence" for each word that *does not quote the poem* but shows the word's force. Provide the **answer key** for your exercise.

COMPETENCY: Pedagogical content knowledge (creating learning scaffolds)

STEPS:
- Step 1: Determine semantic fields from poem's architecture: Field A = **Language of Truth** (vkukdkuh, iR;kfu, iSt); Field B = **Language of Illusion/World** (vkjlh, owQdHkjh, cgjk;cs). *Rationale: The poem contrasts true utterance/praise/inner-dweller with hearsay/ritual-noise/worldly-cacophony.*
- Step 2: Draw connecting arrow: Field A --(cuts through/replaces)--> Field B. Label: "Guru's grace / Direct realization".
- Step 3: Write context sentences (non-poem):
  - vkukdkuh: "The surgeon's vkukdkuh in the operating theatre — calm, precise, born of years of practice — silenced the interns' nervous chatter."
  - iR;kfu: "Her daily iR;kfu of the rising sun was not prayer but a alignment of her breath with the cosmos."
  - iSt: "In the chaos of the protest, he found his iSt — the unshakeable core that no slogan could touch."
  - vkjlh: "WhatsApp forwards are modern vkjlh — hearsay dressed as truth, travelling faster than verification."
  - owQdHkjh: "The farmer's owQdHkjh before the rain god was not superstition but a lifetime's dialogue with the soil."
  - cgjk;cs: "The 24-hour news cycle is pure cgjk;cs — loud, repetitive, designed so we never hear the silence between stories."
- Step 4: Verify each sentence uses the word in its **poetic sense** (authoritative speech, interior praise, inner anchor, derivative noise, ritual petition, systemic cacophony) not the literal gloss.

REASONING: This create-level task forces the student to *teach* the vocabulary, proving mastery. It requires semantic field analysis (analyze), metaphorical transfer (apply), and pedagogical design (create) — aligning with NEP 2020's emphasis on student-generated scaffolds. The answer key models the 'context sentence' technique for competitive exam vocabulary questions (e.g., CUET "use in a sentence" but with depth).

ANSWER: [Exercise + Answer Key as described in Steps 1-4 above. Full key includes the two fields, the arrow label, and the six context sentences with annotations explaining why each captures the poetic force.]

DIFFICULTY: hard