## DEFINITION
Critical Thinking: Analysis and Interpretation is the ability to examine a literary text beyond its surface meaning by breaking down its components (theme, character, language, structure), evaluating the author's choices, and synthesizing evidence to form an independent, reasoned judgment about the text's significance and artistry.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student can independently select relevant textual evidence, explain how literary devices shape meaning, compare multiple interpretations, and construct a coherent analytical argument that addresses "how" and "why" questions about the text.

## SCOPE_BOUNDARY
This node covers critical analysis of Raskhan's poetry and prose excerpts in Chapter 6 (Antra), focusing on thematic depth, stylistic features, and socio-cultural context. It does NOT cover creative writing based on the chapter (node 014) or oral discussion skills (node 015).

## WALKTHROUGH
Imagine you are asked: "Raskhan was a Muslim poet writing Krishna bhakti poetry — does his background change how you read his imagery?" Start by re-reading the prescribed poems ("Hajar Jake ka Izse" and the Jakefpfjrekul excerpts) with a pencil in hand. Mark every metaphor, simile, and archaic word (like 'Bk<+s', 'dksg', 'fel') that creates the pastoral Braj atmosphere. Next, group these marks into clusters: nature imagery, devotional intensity, linguistic fusion. Then ask: "What effect does each cluster produce?" For example, the blending of Persianised vocabulary with Brajbhasha enacts the very synthesis Raskhan embodies. Finally, connect each cluster to the central theme of selfless surrender (izse) to see how form reinforces meaning. The key insight: critical interpretation is not guessing — it is evidence-based pattern recognition.

## DIAGNOSTIC_QUESTION_1
Define 'critical interpretation' in the context of Hindi literature and distinguish it from 'literal comprehension'.

## DIAGNOSTIC_ANSWER_1
Critical interpretation goes beyond retrieving facts (who, what, where) to analyzing how language, structure, and context create meaning. It asks: "Why did the poet choose this metaphor? How does the rhythm mirror the emotion? What cultural codes are invoked?" A wrong answer that merely summarizes the poem ("Raskhan describes Krishna's beauty") reveals the student is stuck at literal comprehension and has not learned to examine craft and effect.

## DIAGNOSTIC_QUESTION_2
In the line "gkjsagq [ksy ftrko¯g eksgh" (Stanza 1), the poet uses a compound verb. Explain in your own words how this grammatical choice intensifies the emotional appeal compared to a simple verb like "gkjs [ksy".

## DIAGNOSTIC_ANSWER_2
The compound verb "ftrko¯g" (from ftrk + ok¯g) adds a sense of completed action with lingering effect — "has made [someone] play and the resonance continues" — whereas "gkjs [ksy" would be a flat command. The extra layer conveys the gopi's overwhelmed state: the flute's melody has already captured her, and the impact persists. A wrong answer that only translates the line ("he made the flute play") misses the aspectual nuance and shows the student cannot link grammar to affective meaning.

## DIAGNOSTIC_QUESTION_3
Apply the concept of 'syncretism' (fusion of Hindu-Muslim cultural elements) to analyze the opening stanza of "Hajar Jake ka Izse". Identify two specific linguistic or imagistic markers of syncretism and explain their function.

## DIAGNOSTIC_ANSWER_3
Markers: (1) "jkepfjrekul" — a Persianised title (jke + pfjrekul) for a Brajbhasha epic, signaling cross-cultural authorship. (2) "v;ksè;k" (worship/ritual) used alongside "dk'kh" (poetry) — blending Islamic devotional vocabulary with Hindu poetic tradition. Function: They enact the poet's lived synthesis, making the text itself a site of communal harmony. A wrong answer that lists only thematic syncretism ("he writes about Krishna") without textual linguistic evidence shows the student cannot ground interpretation in close reading.

## DIAGNOSTIC_QUESTION_4
Compare the portrayal of Radha's viraha (separation) in Raskhan's "Hajar Jake ka Izse" (Stanza 2: "jk?kkS! ,d ckj fiQfj vkokS") with a typical Barahmasa poem. What structural difference in the expression of longing do you observe, and what does it suggest about Raskhan's devotional stance?

## DIAGNOSTIC_ANSWER_4
Barahmasa typically cycles through twelve months, externalizing viraha through seasonal changes. Raskhan compresses the anguish into a single, urgent apostrophe ("jk?kkS!") followed by direct address to Krishna ("esjs jke ykfMys!"), bypassing nature imagery entirely. This suggests a devotional stance where the devotee's relationship with the divine is immediate, personal, and unmediated by ritual or calendar — a hallmark of Pushtimarg-influenced bhakti. A wrong answer that only notes "both talk about separation" fails to analyze structural strategy and its theological implication.

## DIAGNOSTIC_QUESTION_5
Evaluate the claim: "Raskhan's use of simple, colloquial Brajbhasha (e.g., 'Bk<+s', 'dksg', 'fel') makes his poetry accessible but limits its philosophical depth." Defend or refute with textual evidence.

## DIAGNOSTIC_ANSWER_5
Refute. Simplicity of vocabulary ≠ simplicity of thought. In "eSa tkum¡ fut ukFk lqHkkmQA" the colloquial "fut" (broken) and "lqHkkmQ" (helpless) convey existential surrender more powerfully than Sanskritized abstractions could. The philosophical depth lies in the *izse* theology — total self-offering — which demands ordinary language to express an extraordinary psychological state. A wrong answer that agrees with the claim reveals a bias equating lexical difficulty with intellectual weight, a common misconception in literature assessment.

## DIAGNOSTIC_QUESTION_6
Create a four-line stanza in Brajbhasha (or Hindi approximating its rhythm) that imitates Raskhan's style of addressing Krishna, using at least two archaic words from the chapter (e.g., 'lqfp', 'dksno', 'lqlkyh') and one compound verb. Explain your choices in two sentences.

## DIAGNOSTIC_ANSWER_6
Sample stanza: "lqfp dksno ckfy lqlkyh, jke tumhro izse izHkq / fel dksg Bk<+s eSa, lq[kkjke lqfu ugh nq[kq //" Choices: "lqfp" (pure/true) and "lqlkyh" (beloved) echo the gopi's intimate register; compound verb "izHkq" (has done/made) mirrors Raskhan's aspectual richness. A poor answer that uses modern Hindi words ("sachcha", "pyaari") or lacks compound verbs shows the student cannot internalize the stylistic fingerprint they were asked to analyze.

## COMMON_MISCONCEPTION
Students believe "critical analysis" means criticizing the text (finding faults) or offering personal opinions unsupported by the text. For example, writing "Raskhan's poem is boring because it repeats 'jke' too much" instead of analyzing how repetition of "jke" creates a mantric rhythm that enacts *izse*. This error stems from confusing everyday "criticism" with academic "critique" and from not learning the evidence–claim–warrant structure.

## ON_FAILURE
1. Revisit node c12_hin_a_cbse_06_008 (Imagery and Metaphor) and 009 (Irony and Symbolism) to rebuild device-identification skill. 2. Practice the "Quote–Effect–Link" drill: pick one line, write its literal meaning, name the device, explain its emotional effect, link to theme. Do this for five lines from the chapter. 3. Re-attempt Diagnostic Question 3 and 4; if still unable to produce textual evidence, review Class 11 node c11_hin_ar_cbse_01_013 (Critical Thinking) for the evidence–claim model.

## BUILDS_ON
Literal and inferential comprehension (node 012) and literary device identification (nodes 008, 009).

## LEADS_TO
Writing analytical answers for board exams (node 014) and structured oral arguments (node 015).

## PREREQUISITE_NODE_IDS
c12_hin_a_cbse_06_001, c12_hin_a_cbse_06_002, c12_hin_a_cbse_06_003, c12_hin_a_cbse_06_004, c12_hin_a_cbse_06_005, c12_hin_a_cbse_06_006, c12_hin_a_cbse_06_007, c12_hin_a_cbse_06_008, c12_hin_a_cbse_06_009, c12_hin_a_cbse_06_010, c12_hin_a_cbse_06_011, c12_hin_a_cbse_06_012, c11_hin_ar_cbse_01_013, c11_hin_v_cbse_01_013
## PREREQUISITE_REASONS
c12_hin_a_cbse_06_001: Provides historical context of Raskhan's life and Bhakti movement essential for situating interpretation.
c12_hin_a_cbse_06_002: Establishes narrative structure of the excerpts, needed to analyze how form shapes meaning.
c12_hin_a_cbse_06_003: Supplies setting/atmosphere details (Braj, pastoral) that inform imagistic analysis.
c12_hin_a_cbse_06_004: Character analysis of Krishna/Hajar Jake as understood in the text, prerequisite for evaluating portrayal.
c12_hin_a_cbse_06_005: Supporting characters (gopis, Radha) whose voices appear in poems; needed for multi-perspective analysis.
c12_hin_a_cbse_06_006: Primary theme (izse, surrender) — the central lens for all critical interpretation.
c12_hin_a_cbse_06_007: Secondary themes (syncretism, linguistic fusion) that enrich comparative analysis.
c12_hin_a_cbse_06_008: Imagery and metaphor identification — raw material for analytical arguments.
c12_hin_a_cbse_06_009: Irony and symbolism — higher-order devices needed for evaluate/create tasks.
c12_hin_a_cbse_06_010: Vocabulary (archaic words) — essential for close reading of linguistic choices.
c12_hin_a_cbse_06_011: Grammar usage (compound verbs, case endings) — enables grammatical-stylistic analysis.
c12_hin_a_cbse_06_012: Literal and inferential comprehension — baseline without which critical analysis has no foundation.
c11_hin_ar_cbse_01_013: Class 11 critical thinking foundation — introduces evidence–claim–warrant model.
c11_hin_v_cbse_01_013: Class 11 Vitan critical thinking — reinforces analytical habits across textbooks.

## FORWARD_NODE_IDS
c12_hin_a_cbse_06_014, c12_hin_a_cbse_06_015
## FORWARD_REASONS
c12_hin_a_cbse_06_014: Writing skills require the analytical arguments and textual evidence built here to structure board-exam answers.
c12_hin_a_cbse_06_015: Speaking/listening discussions need interpreted positions and evidence to sustain academic dialogue.

## CROSS_SUBJECT_PREREQS
c11_hin_ar_cbse_01_013, c11_hin_v_cbse_01_013
## CROSS_SUBJECT_REASONS
c11_hin_ar_cbse_01_013: Establishes the critical thinking framework (evidence–claim–warrant) used across all literature analysis.
c11_hin_v_cbse_01_013: Provides parallel practice in interpreting different genres (prose/poetry) from Class 11 Vitan.

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_01_013 -> c12_hin_a_cbse_06_013 -> c12_hin_a_cbse_06_014

## THIS_FORMULA
N/A - conceptual

## FORMULA_VARIABLES
N/A

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
analytical

## CROSS_SUBJECT
N/A | Raskhan's life and poetry exemplify Hindu-Muslim syncretism in the Bhakti movement; historical context of Akbar's court and Pushtimarg sect informs interpretation of his devotional stance.
 N/A | The Braj landscape (Yamuna, forests, seasonal cycles) is not mere backdrop but an active participant in the poetry; geographical knowledge of Brajbhoomi deepens imagistic analysis.
 N/A | Raskhan's synthesis models pre-modern pluralism; analyzing his work builds civic understanding of India's composite culture beyond textbook definitions.
## PREREQ_CONCEPT
Evidence-based literary analysis: every claim about the text must be anchored in a specific word, phrase, or structural feature.

## PREREQ_BEFORE
Student must be able to identify at least three literary devices in the prescribed poems and explain their literal meaning.

## PREREQ_STUCK
If stuck, review "Imagery and Metaphor" (c12_hin_a_cbse_06_008) and "Grammar: Language Usage" (c12_hin_a_cbse_06_011) to rebuild device-spotting and grammatical awareness.

## WORKED_EXAMPLE_1
PROBLEM: Analyze how Raskhan uses nature imagery in the first stanza of "Hajar Jake ka Izse" to externalize the gopi's internal state of surrender.
STEPS:
- Step 1: Isolate the nature images in Stanza 1 — "gkjsagq [ksy" (flute playing), "ftrko¯g eksgh" (made resound), "xqj xkslkb¡" (dense forest), "lkfgc fl; jkew" (Krishna playing flute).
- Step 2: Identify the literary device — personification of the flute ("ftrko¯g" implies agency), auditory imagery ("gkjsagq"), spatial imagery ("xqj xkslkb¡").
- Step 3: Determine the emotional correlate — the flute's sound penetrating the forest mirrors the gopi's heart being penetrated by Krishna's call; the density of the forest mirrors the density of her longing.
- Step 4: Connect to theme of izse — the gopi does not resist; the music "makes" her respond, just as surrender is a response to divine initiative.
- Step 5: Formulate the analytical claim — "Raskhan transforms the pastoral setting into a psychological landscape where external sound becomes internal summons, enacting the theology of grace-led surrender."
REASONING: This five-step move from inventory -> device -> correlation -> thematic link -> synthesized claim models the exact structure board examiners reward in 5-mark questions.
ANSWER: The stanza uses auditory and spatial imagery to blur the boundary between the forest and the devotee's consciousness. The compound verb "ftrko¯g" (caused to resound) shifts agency to Krishna's flute, suggesting surrender is not self-generated but evoked. This mirrors the Pushtimarg doctrine where *pushti* (grace) precedes *seva* (service).

## WORKED_EXAMPLE_2
PROBLEM: Compare the tone of address in "Hajar Jake ka Izse" (Stanza 2: "jk?kkS! ,d ckj fiQfj vkokS") with the tone in the prose excerpt where Hajar Jake describes his own devotion ("tuuh fuj[kfr cku èkuqfg;k¡"). How does the shift from poetry to prose alter the rhetorical effect?
STEPS:
- Step 1: Identify the speaker and addressee in each — Poem: gopi addressing Krishna (direct, urgent). Prose: Hajar Jake addressing reader/listener (reflective, narrative).
- Step 2: Mark tonal markers — Poem: exclamation "jk?kkS!", imperative "fiQfj vkokS", colloquial "fuiV fclkjs". Prose: past tense narration "tuuh fuj[kfr", descriptive "ckj ckj mj uSufu".
- Step 3: Analyze rhetorical purpose — Poem creates immediacy and intimacy (I-Thou). Prose creates authority and testimony (I-It-You).
- Step 4: Link to genre expectations — Poetry (xhrkoyh) favors emotional compression; prose (nksgkoyh) favors explanatory expansion.
- Step 5: Synthesize — The shift from poetic apostrophe to prose autobiography mirrors Raskhan's dual identity as devotee-poet and historical subject, reinforcing the chapter's theme of lived synthesis.
REASONING: This comparison demonstrates how form (verse vs prose) and tone co-construct meaning, a key skill for "compare and contrast" board questions.
ANSWER: The poetic address is vertically oriented (devotee to Divine), using vocative and imperative to collapse distance. The prose address is horizontally oriented (writer to reader), using narrative past to establish credibility. Together they perform the integration of *bhakti* (vertical) and *itihas* (horizontal) that defines Raskhan's unique voice.

## WORKED_EXAMPLE_3
PROBLEM: A board exam question asks: "Raskhan's poetry is a meeting point of Persian and Braj traditions. Discuss with reference to language, imagery, and theme." Write a structured answer outline with three main points, each supported by a specific textual detail.
STEPS:
- Step 1: Deconstruct the prompt — three required dimensions: language, imagery, theme. Each needs one concrete textual anchor.
- Step 2: Language anchor — Title "jkepfjrekul" (Persian suffix -kul + Sanskrit jke) + vocabulary "v;ksè;k" (Arabic/Persian root) alongside Braj "dk'kh".
- Step 3: Imagery anchor — Pastoral Braj imagery ("xqj xkslkb¡", "gkjsagq [ksy") fused with Sufi metaphor of lover-beloved ("izse" as *ishq*-style surrender).
- Step 4: Theme anchor — *Izse* (self-offering) expressed through *pushtimarg* theology (Hindu) but articulated in a language that crosses communal lines, embodying *sulh-i-kul* (universal peace) ideal.
- Step 5: Structure the answer — Introduction: thesis statement. Body Paragraph 1: Language fusion with quote. Body Paragraph 2: Imagery fusion with quote. Body Paragraph 3: Thematic fusion with quote. Conclusion: significance for composite culture.
- Step 6: Check marking scheme alignment — 3 points × (claim + evidence + explanation) = 5-6 marks; intro/conclusion = 1-2 marks. Total 6-8 marks as per CBSE pattern.
REASONING: This worked example models the planning phase for a long-answer question, teaching students to map prompt requirements to textual evidence before writing.
ANSWER: Outline:
Thesis: Raskhan's poetry materializes Indo-Islamic synthesis at linguistic, imagistic, and theological levels.
1. Language: "jkepfjrekul" — Persian plural suffix on Sanskrit stem; "v;ksè;k" (worship) in Braj verse.
2. Imagery: Flute in forest (Braj pastoral) becomes call to *izse* (Sufi *da'wat*).
3. Theme: *Izse* as *pushtimarg* surrender articulated in a vernacular that belongs to both traditions.
Conclusion: The text itself becomes a site of *sulh-i-kul*, not just a description of it.

## COMPETENCY_QUESTION_1
QUESTION: "The gopi's cry 'jk?kkS!' in Stanza 2 is not merely an exclamation — it is a theological statement." Using the concept of *pushtimarg* (grace-centered devotion), explain this claim in 80-100 words with two textual supports.
COMPETENCY: Analytical reasoning with theological-literary synthesis
STEPS:
- Step 1: Recall *pushtimarg* doctrine — *pushti* (grace) is antecedent to *seva*; the soul cannot initiate surrender.
- Step 2: Locate "jk?kkS!" — it is a spontaneous outburst, not a calculated prayer.
- Step 3: Link — the cry erupts *after* the flute has already acted ("gkjsagq [ksy ftrko¯g"), showing grace precedes response.
- Step 4: Select second support — "eSa tkum¡ fut ukFk lqHkkmQA" (I am broken, helpless) confirms the devotee's passivity before grace.
- Step 5: Compose concise answer integrating doctrine and text.
ANSWER: In Pushtimarg, the soul is *nirupadhik* (without merit) until grace descends. The gopi's "jk?kkS!" is a reflex to the flute's prior action ("ftrko¯g eksgh"), not a voluntary invocation. Her subsequent confession "eSa tkum¡ fut ukFk lqHkkmQA" admits total helplessness — the hallmark of *pushti*-led surrender. Thus the exclamation enacts the theology: grace calls, the broken vessel answers.
DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: Design a 3-minute classroom presentation that teaches peers how to move from "identifying a metaphor" to "analyzing its function in Raskhan's poem". Include a step-by-step demo using the metaphor "lqfp dksno" (pure beloved/flute?) from the text. Specify the three slides you would show and the script for each.
COMPETENCY: Pedagogical content knowledge / metacognitive communication
STEPS:
- Step 1: Define the learning objective — peers must see the gap between labeling and analyzing.
- Step 2: Slide 1 — "Trap: Labeling ≠ Analyzing". Show metaphor "lqfp dksno" with two columns: Label (Metaphor: flute = pure beloved) vs Analysis (Why 'pure'? Why 'beloved'? What does it do to the gopi's desire?).
- Step 3: Slide 2 — "Bridge: The Function Question". Script: "Ask: What work does this metaphor do? It transfers the flute's physical purity (single reed, unbroken sound) to Krishna's ontological purity, making the gopi's longing a quest for the unconditioned."
- Step 4: Slide 3 — "Practice: Your Turn". Give a new line "ckj ckj mj uSufu ykofr izHkqtw dh yfyr iufg;k¡" and ask peers to write one analytical sentence using the function question.
- Step 5: Closing — emphasize that board examiners reward the move from "this is a metaphor" to "this metaphor does X because Y".
ANSWER: Presentation outline with slides and scripts as above. The demo models metacognition — making the invisible analytical move visible — which is the highest-order skill for competitive exams like CUET that test "thinking about thinking".
DIFFICULTY: hard