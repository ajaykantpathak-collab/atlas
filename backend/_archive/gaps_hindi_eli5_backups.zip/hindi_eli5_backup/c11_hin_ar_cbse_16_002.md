## DEFINITION
Narrative structure in poetry refers to the organized progression of ideas, images, and emotions across stanzas that creates a coherent story-like arc, moving from an initial situation through development to a resolution or revelation, even without conventional plot elements like characters or events.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student can identify the three-stage narrative arc (invitation → enumeration → affirmation) in the poem, trace how each stanza advances the poetic argument, and explain how structural choices reinforce the theme of seeking refuge from modern alienation.

## SCOPE_BOUNDARY
This node covers the narrative progression across the three stanzas of "vkvks] feydj cpk,¡" — how the poem moves from a direct address to a catalog of things to hide from, ending in a defiant affirmation. It does NOT cover detailed imagery analysis (node 008), irony/symbolism (node 009), or thematic interpretation (nodes 006-007) which are treated separately.

## WALKTHROUGH
Imagine you are telling a friend about a bad day — you don't just dump all details at once; you start with "You won't believe what happened," then list events in order, ending with "And that's why I'm exhausted." This poem works the same way: the poet begins with an urgent invitation ("come, let's hide"), builds a catalog of modern burdens in the middle stanza, and ends with quiet resistance ("even in this night, there's still much to hide"). Notice how the first stanza uses imperative verbs ("cpk,¡" — hide), the second stacks noun phrases in a rhythmic list, and the third shifts to declarative confidence. The structure itself performs the hiding — each stanza tucks the reader deeper into the poem's sanctuary.

## DIAGNOSTIC_QUESTION_1
What is the primary structural movement from stanza one to stanza three in "vkvks] feydj cpk,¡"?

## DIAGNOSTIC_ANSWER_1
The poem moves from a direct imperative address ("come, let's hide") in stanza one, to an expansive catalog of modern afflictions in stanza two, to a quiet declarative affirmation of resilience in stanza three. A wrong answer that only identifies "three stanzas" or "hiding theme" reveals the student sees static parts rather than dynamic progression — they miss how structure enacts the poem's argument.

## DIAGNOSTIC_QUESTION_2
Why does the poet use a list format (noun phrases without verbs) in the second stanza instead of complete sentences?

## DIAGNOSTIC_ANSWER_2
The verbless noun phrases ("Hkhrj dh vkx", "èkuq"k dh Mksjh", "rhj dk uqdhykiu") create a breathless accumulation that mimics how modern burdens pile up without resolution — each phrase is a weight added to the pile. A student who says "it's poetic style" or "for rhythm" misses the functional connection: the fragmentary syntax structurally enacts the fragmentation of experience the poem describes.

## DIAGNOSTIC_QUESTION_3
If you were to insert a fourth stanza that continues the poem's narrative logic, what structural shift would it require and why?

## DIAGNOSTIC_ANSWER_3
A fourth stanza would need to shift from affirmation to action — perhaps a call to rebuild or transform — because the three-stanza arc (invitation → burden → resistance) completes a defensive cycle; continuing requires offensive movement. A student who suggests "more things to hide from" or "happy ending" reveals they see the poem as additive rather than argumentative — they don't grasp that narrative structure in poetry follows dialectical logic, not linear addition.

## DIAGNOSTIC_QUESTION_4
Compare the narrative function of the refrain "vkvks] feydj cpk,¡" (repeated in stanza 1 and 3) with the catalog in stanza 2. How do these two structural elements work in opposition?

## DIAGNOSTIC_ANSWER_4
The refrain acts as structural anchor — a recurring return to the core imperative that frames the poem as circular sanctuary — while the catalog acts as linear expansion, stretching the poem outward into the world's chaos. The tension between circular return and linear expansion creates the poem's structural energy. A student who only notes "repetition for emphasis" misses the architectural opposition: one structure contains, the other releases.

## DIAGNOSTIC_QUESTION_5
Evaluate whether the poem's three-stanza structure is inevitable or arbitrary. Could the same content work in two stanzas or five?

## DIAGNOSTIC_ANSWER_5
The three-stanza structure is inevitable because it maps onto the classical rhetorical triad: exordium (invitation), enumeratio (catalog), peroratio (closing affirmation). Two stanzas would collapse the necessary mediation between self and world; five would dilute the tension between containment and exposure. A student who says "poet's choice" or "any number works" reveals they view structure as decorative rather than argumentative — they don't see that poetic form encodes philosophical logic.

## DIAGNOSTIC_QUESTION_6
Write a three-stanza poem (4-6 lines each) that uses the same narrative arc — invitation → catalog → affirmation — but about a different modern pressure (e.g., digital overload, exam stress, urban noise).

## DIAGNOSTIC_ANSWER_6
A strong response mirrors the structural logic: Stanza 1 uses second-person imperative addressing a companion ("Come, let's log off / put the phone face down"); Stanza 2 catalogs fragments without verbs ("Blue light's glare / notification's ping / scroll's endless fall / algorithm's guess"); Stanza 3 shifts to quiet declarative resistance ("Even in this wired night / we hold our silence"). A weak answer that rhymes or describes feelings without the three-move arc shows the student cannot transfer structural understanding to new content.

## COMMON_MISCONCEPTION
Students treat "narrative structure" in poetry as merely counting stanzas or identifying beginning/middle/end. They miss that in lyric poetry, structure IS argument — the stanza breaks, line lengths, syntactic patterns, and refrain placement collectively perform the poem's philosophical movement. For example, they see the second stanza's list as "imagery" rather than a structural enactment of accumulation, or they read the refrain's return as "repetition for beauty" rather than a structural anchor that makes the catalog's chaos bearable.

## ON_FAILURE
1. Have the student physically map the poem: draw three boxes labeled "Invitation," "The World," "The Return" and place each line in its box — this makes the argument visible.
2. Ask them to read only the first lines of each stanza aloud: "vkvks] feydj cpk,¡" → "Hkhrj dh vkx" → "vkvks] feydj cpk,¡" — hear how the refrain frames the chaos.
3. Give them a scrambled version of stanza 2's phrases and ask them to reorder — they'll discover no "correct" order exists, proving the list's power is accumulative, not sequential.
4. Finally, have them rewrite stanza 3 as a question ("Is there still much to hide?") — they'll feel how the declarative form is a structural choice, not inevitable.

## BUILDS_ON
c11_hin_ar_cbse_16_001 (Before You Read: Context and Background) — understanding the poet's Punjabi roots and translation context frames why the poem uses a three-stanza structure rooted in Punjabi folk forms.

## LEADS_TO
c11_hin_ar_cbse_16_003 (Setting and Atmosphere) — the narrative structure creates the poem's "hidden" setting; c11_hin_ar_cbse_16_008 (Literary Devices: Imagery and Metaphor) — structural choices determine which images accumulate and where.

## PREREQUISITE_NODE_IDS
c11_hin_ar_cbse_16_001
## PREREQUISITE_REASONS
c11_hin_ar_cbse_16_001: The context node establishes the poet's bilingual background (Punjabi to Hindi) and the folk-song tradition that informs the poem's tripartite structure — without this, students read the three stanzas as arbitrary rather than culturally coded.

## FORWARD_NODE_IDS
c11_hin_ar_cbse_16_003, c11_hin_ar_cbse_16_008, c11_hin_ar_cbse_16_012, c11_hin_ar_cbse_16_004, c11_hin_ar_cbse_16_005, c11_hin_ar_cbse_16_006, c11_hin_ar_cbse_16_007, c11_hin_ar_cbse_16_009, c11_hin_ar_cbse_16_010, c12_hin_a_cbse_09_002, c12_hin_a_cbse_16_002, c12_hin_a_cbse_16_003, c12_hin_ar_cbse_03_002

## FORWARD_REASONS
c11_hin_ar_cbse_16_003: The narrative structure creates the poem's shifting atmosphere — from intimate address to expansive world to enclosed sanctuary — which the setting node analyzes.
c11_hin_ar_cbse_16_008: The catalog in stanza 2 is where imagery clusters; understanding its structural role (accumulation vs. selection) is prerequisite for analyzing metaphor density.
c11_hin_ar_cbse_16_012: Comprehension questions often ask "how does the poem progress?" — this node provides the structural vocabulary to answer precisely.
c11_hin_ar_cbse_16_004: Plot/structure node establishes the three-stanza arc (awakening → witness → vision) that shapes the speaker's evolving role.  
c11_hin_ar_cbse_16_005: Establishes the poem's list-like narrative structure—essential for seeing how supporting characters accumulate stanza by stanza.  
c11_hin_ar_cbse_16_006: Establishes the poem's two-part structure (invitation + expansive list → ruined settlement affirmation) which is the scaffold for theme tracing.  
c11_hin_ar_cbse_16_007: Ensures familiarity with the poem's narrative flow and stanza sequence.  
c11_hin_ar_cbse_16_009: Understanding the poem's narrative structure (invocation → catalog of sufferers → final paradox) is necessary to track how irony and symbolism evolve across stanzas.  
c11_hin_ar_cbse_16_010: Understanding the poem's narrative flow (village to city, past to present) is essential to see where key words appear and why they matter at those moments.  
c12_hin_a_cbse_09_002: Consolidated narrative analysis across genres.  
c12_hin_a_cbse_16_002: Established the vocabulary of plot stages and narrative techniques in Class 11; this node applies them to a more complex, non-linear text.  
c12_hin_a_cbse_16_003: Class 11 plot structure reinforces how setting drives narrative.  
c12_hin_ar_cbse_03_002: Represents the culmination of Class 11 narrative analysis across 16 chapters — ensures student has practiced structural mapping on diverse poetic forms before tackling Class 12 complexity.  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
none

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_16_001 -> c11_hin_ar_cbse_16_002 -> c11_hin_ar_cbse_16_003

## THIS_FORMULA
Narrative Arc in Lyric Poetry = Exordium (Stanza 1: Imperative Address) + Enumeratio (Stanza 2: Verbless Catalog) + Peroratio (Stanza 3: Declarative Affirmation with Refrain Return)

## FORMULA_VARIABLES
Exordium: Opening rhetorical move that establishes speaker-addressee relationship and central imperative; Enumeratio: Middle section using accumulative syntax to map the opposing force; Peroratio: Closing move that synthesizes and reasserts agency through structural return.

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
analytical

## CROSS_SUBJECT
c11_history_colonial_education | The poem's critique of modern alienation connects to history of colonial education systems that disrupted indigenous knowledge structures — both analyze how institutional modernity fragments lived experience.
c11_sociology_social_change | The catalog of burdens (heat, cold, dust, noise) maps onto sociological concepts of anomie and urban alienation — structural enumeration mirrors sociological inventory of modern stressors.
c11_politicalscience_rights_education | The poem's "hiding" as resistance parallels political theory on right to privacy and mental space — narrative structure enacts the claim to interiority that rights discourse protects.

## PREREQ_CONCEPT
Understanding that lyric poetry can have narrative logic without characters or plot — structure carries the argument.

## PREREQ_BEFORE
Student must recognize that stanza breaks are structural decisions, not just line groupings, and that syntactic patterns (imperative vs. noun phrases vs. declarative) signal rhetorical moves.

## PREREQ_STUCK
Review the concept of "rhetorical structure" in c11_hin_ar_cbse_16_001 — specifically how Punjabi folk forms use three-part address/catalog/return patterns.

## WORKED_EXAMPLE_1
PROBLEM: A student writes: "The poem has three stanzas. First stanza says come let's hide. Second stanza lists many things like heat, cold, dust. Third stanza says come let's hide again and there is still much to hide. The structure is simple." Diagnose what this analysis misses and demonstrate a structural reading.

STEPS:
- Step 1: Identify the student's error — they treat stanzas as containers of content rather than moves in an argument; they see "repetition" not "refrain return."
- Step 2: Apply the tripartite formula — label each stanza's rhetorical function: Exordium (invitation), Enumeratio (catalog), Peroratio (affirmation with return).
- Step 3: Analyze syntactic shift — Stanza 1 uses imperative verbs (cpk,¡, cpk,¡, gfM+;k); Stanza 2 uses only noun phrases (zero finite verbs); Stanza 3 uses declarative verb (gS) + imperative return.
- Step 4: Explain how syntax enacts argument — the verbless catalog creates weight without agency; the final declarative "gS" (is) asserts existence against erasure.
- Step 5: Connect to theme — the structure performs the hiding: the refrain frames the chaos, the catalog is what we hide FROM, the final affirmation is what we hide FOR.
REASONING: This works because it moves from labeling to functional analysis — showing HOW structure argues, not just WHAT it contains. The syntactic evidence (verb forms) makes the argument visible and verifiable.
ANSWER: The poem's three-stanza structure enacts a complete rhetorical argument: Stanza 1 (Exordium) establishes the sanctuary through imperative address; Stanza 2 (Enumeratio) maps the hostile world through accumulative noun phrases that deny agency to the burdens; Stanza 3 (Peroratio) reclaims agency through declarative affirmation ("gS" — is/exists) and circular refrain return. The structure IS the hiding — each stanza tucks the reader deeper into resistance.

## WORKED_EXAMPLE_2
PROBLEM: In a board exam, a question asks: "How does the poet use the second stanza's structure to convey the overwhelming nature of modern life?" Write a 4-mark answer using PEEL structure.

STEPS:
- Step 1: Point — The second stanza's verbless noun-phrase catalog structurally enacts the overwhelming, agentless accumulation of modern burdens.
- Step 2: Evidence — Reference the syntactic pattern: "Hkhrj dh vkx / èkuq"k dh Mksjh / rhj dk uqdhykiu / oqQYgkM+h dh èkkj" — nine consecutive fragments, zero finite verbs, each a genitive construction (X's Y).
- Step 3: Explanation — The genitive chain (possessive links) makes each burden feel owned by the world, not the self; the absence of verbs denies the speaker any action toward or against them; the line-break stacking creates visual and rhythmic pile-up.
- Step 4: Link — This structural choice makes the reader feel the weight the speaker describes — form performs content — preparing the necessity of the third stanza's refuge.
- Step 5: Polish for board format — Combine into a coherent paragraph with clear topic sentence, textual evidence, analysis, and thematic connection.
REASONING: Board examiners reward answers that connect form to meaning with specific textual evidence. The PEEL structure ensures each component is present. The syntactic analysis (genitive, verbless) provides the "E" and "E" that most students omit.
ANSWER: The poet structures the second stanza as a verbless catalog of genitive noun phrases ("Hkhrj dh vkx," "èkuq"k dh Mksjh," etc.) which performs the overwhelming nature of modern life through three syntactic choices: (1) Zero finite verbs deny the speaker agency — burdens simply exist, unacted upon; (2) Genitive constructions ("X's Y") frame each affliction as the world's possession, not the self's experience; (3) Line-break accumulation creates visual and rhythmic pile-up mimicking how stressors accumulate without resolution. This structural enactment makes the third stanza's declarative affirmation ("gS") a necessary syntactic rebellion — the first finite verb in the poem asserts existence against the catalog's erasure.

## WORKED_EXAMPLE_3
PROBLEM: Compare the narrative structure of "vkvks] feydj cpk,¡" with a typical Hindi film song structure (mukhda-antara-mukhda). How does the poem subvert the folk-song tradition it inherits?

STEPS:
- Step 1: Recall film song structure — Mukhda (refrain, emotional core), Antara (verse, narrative detail), Mukhda (return) — typically 2-3 antaras between mukhdas.
- Step 2: Map poem onto this — Stanza 1 = Mukhda (imperative refrain), Stanza 2 = Single Antara (but expanded to 16 lines vs typical 4-6), Stanza 3 = Mukhda return (with variation).
- Step 3: Identify subversion 1 — The poem has ONLY ONE antara where film songs have multiple; this compresses the world's chaos into one overwhelming catalog rather than episodic verses.
- Step 4: Identify subversion 2 — The mukhda in film songs is melodic/emotional; here it's imperative/philosophical ("cpk,¡" — hide, not "remember me").
- Step 5: Identify subversion 3 — The return in stanza 3 adds "vc Hkh gekjs ikl!" (still we have it) — the refrain gains new weight from the catalog, whereas film mukhdas repeat identically.
- Step 6: Synthesize — The poem uses folk structure but inverts its function: from entertainment (repetition for pleasure) to resistance (repetition as survival).
REASONING: This connects to c11_hin_ar_cbse_16_001 (context node) about the poet's Punjabi folk roots. It shows advanced analysis: not just identifying structure but evaluating how a writer transforms inherited forms. This is exactly the "critical thinking" competency board exams test.
ANSWER: The poem inherits the Punjabi folk/film song triad (mukhda-antara-mukhda) but subverts it structurally: (1) Compression — one 16-line antara replaces multiple short verses, forcing all modern burdens into a single overwhelming encounter; (2) Functional inversion — the mukhda shifts from melodic refrain to philosophical imperative ("hide"), making the return in stanza 3 an earned affirmation ("vc Hkh gekjs ikl") rather than mere repetition; (3) Agency shift — film songs address a beloved; this poem addresses a co-resister ("viuh cfLr;ksa" — your shadows). The folk structure becomes a vessel for existential resistance rather than romantic longing.

## COMPETENCY_QUESTION_1
QUESTION: A Class 11 student claims: "The poem just repeats 'come let's hide' at the start and end — the middle part could be in any order, it's just a list." Using structural evidence, explain why this claim misunderstands how the poem's narrative architecture works.

COMPETENCY: Critical analysis of poetic structure — evaluating a claim using textual evidence

STEPS:
- Step 1: Identify the claim's error — it treats the catalog as unordered set rather than structured accumulation, and the refrain as decoration rather than structural frame.
- Step 2: Analyze the catalog's internal architecture — though verbless, the 16 lines group into thematic clusters: elemental (heat/cold), environmental (dust/fog), bodily (thirst/hunger), social (lies/betrayal), existential (fear/death) — a progression from physical to metaphysical.
- Step 3: Analyze the refrain's structural work — first occurrence ESTABLISHES the sanctuary; second occurrence CONFIRMS it survives the catalog. The catalog is the TEST the refuge passes.
- Step 4: Demonstrate order-dependence — if "death/fear" came first, the poem would collapse into despair; the progression from survivable (heat) to unsurvivable (death) builds tension the refrain resolves.
ANSWER: The student's claim fails because it ignores two structural realities: (1) The catalog has a hidden thematic architecture — it moves from elemental discomforts (heat, cold) through bodily needs (thirst, hunger) to social betrayals (lies, fraud) to existential threats (fear, death) — a deliberate escalation that makes the final refuge feel earned, not arbitrary. (2) The refrain performs different rhetorical work each time: Stanza 1's "cpk,¡" is a PROPOSAL (let's create a sanctuary); Stanza 3's "cpk,¡" is a DECLARATION (the sanctuary exists and endures). The catalog is the crucible between proposal and proof — its specific ordering tests the refuge's capacity. Randomizing the catalog would destroy the poem's dialectical logic.
DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: The poem's third stanza begins with the refrain's return but adds "vc Hkh gekjs ikl!" (even now, still with us!). Some editors suggest moving this line to the poem's very end as a separate fourth stanza. Argue for or against this editorial change using structural principles.

COMPETENCY: Editorial judgment — evaluating structural consequences of formal changes

STEPS:
- Step 1: Analyze current structure — Stanza 3 fuses refrain return + affirmation + inventory ("bl nkSj esa Hkh cpkus dks cgqr oqQN cpk gS") in one breath — a single syntactic unit (declarative sentence with embedded clauses).
- Step 2: Simulate the proposed change — Separating "vc Hkh gekjs ikl" as Stanza 4 would create: Stanza 3 (refrain + inventory) → Stanza 4 (affirmation alone).
- Step 3: Evaluate consequences — Current fusion makes affirmation INSEPARABLE from the act of hiding; proposed separation makes affirmation a COMMENTARY on hiding. The former enacts resilience; the latter describes it.
- Step 4: Consider rhythmic impact — Current 3-stanza symmetry (imperative / catalog / imperative-declarative) mirrors the folk triad; 4 stanzas breaks the triadic logic into a quadripartite structure with no cultural precedent.
- Step 5: Judge — The change weakens the poem by converting performed resistance into reported resilience, and breaks the culturally coded three-part form.
ANSWER: Against the change. The poem's power lies in the third stanza's syntactic fusion: the refrain ("vkvks] feydj cpk,¡"), the affirmation ("vc Hkh gekjs ikl"), and the inventory ("bl nkSj esa Hkh cpkus dks cgqr oqQN cpk gS") form a single declarative sentence — the hiding, the survival, and the proof are grammatically inseparable. Splitting "vc Hkh gekjs ikl" into a fourth stanza would: (1) Convert performed resistance (hiding WHILE affirming) into reported resilience (hiding THEN commenting); (2) Break the folk-derived triadic structure (exordium-enumeratio-peroratio) that gives the poem its cultural authority; (3) Dilute the refrain's structural work — currently it frames the entire poem as a circular sanctuary; a fourth stanza would make the refrain merely penultimate, not final. The three-stanza form is not a container but the argument itself.
DIFFICULTY: hard