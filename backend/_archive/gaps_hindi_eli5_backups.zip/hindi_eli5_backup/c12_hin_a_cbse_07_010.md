## DEFINITION
Vocabulary in Context refers to the skill of determining the precise meaning of words and phrases as they are used in a specific literary text, considering dialect, tone, imagery, and cultural nuances, rather than relying solely on dictionary definitions.

## COGNITIVE_LEVEL
understand

## MASTERY_CRITERIA
The student can independently identify 10-12 key words from the poem "ckjgeklk", explain their contextual meaning in Hindi, and justify why the poet's choice of that specific dialect word enhances the emotional or thematic effect in that stanza.

## SCOPE_BOUNDARY
This node covers only the vocabulary from the prescribed poem "ckjgeklk" in Chapter 7 (Antra). It does NOT cover grammar rules (node 011), comprehension questions (node 012), or literary devices like irony/symbolism (node 009) — those are separate nodes.

## WALKTHROUGH
Imagine you are reading a WhatsApp message from your grandmother in your mother tongue — you understand each word, but the *feeling* behind "थक गई हूँ" hits differently than "I am tired." That is vocabulary in context. Start by reading the poem aloud twice: first for rhythm, second to circle every word that feels unfamiliar or carries a 'village flavor' (like *nsol*, *fufl*, *lhÅ*). Do not open the glossary yet. Guess the meaning from the surrounding lines — e.g., in stanza 1, *nsol* appears with *?kVk* and *ck<+h*, so it likely relates to time of day. Then verify with the NCERT glossary. The key insight: the poet chooses *nsol* over *fnol* because it carries the scent of the soil, the labor of the fields, and the intimacy of the speaker's world — a dictionary word cannot replace that.

## DIAGNOSTIC_QUESTION_1
What is the primary reason the poet uses dialect words like *nsol*, *fufl*, and *lhÅ* instead of standard Hindi equivalents like *din*, *raat*, and *kamar* in the poem "ckjgeklk"?

## DIAGNOSTIC_ANSWER_1
Correct answer: To authentically capture the rural speaker's voice, cultural rootedness, and emotional intimacy, making the monologue feel lived and genuine rather than literary or translated. A wrong answer like "to make the poem difficult" or "because old Hindi was different" reveals the student misses the aesthetic and thematic purpose of dialect — it is not about difficulty but about *truth to character and setting*.

## DIAGNOSTIC_QUESTION_2
In stanza 2, the line *pdbZ fufl fcNqjSa fnu feykA* uses *fufl* (night) and *fnu* (day) together. Explain how the juxtaposition of these two dialect words in the same line deepens the portrayal of the woman's waiting.

## DIAGNOSTIC_ANSWER_2
Correct answer: *fufl* (dark, labor-filled night) and *fnu* (scorching, endless day) together show that her waiting is unbroken by time — she exists in a timeless cycle of longing where neither night brings rest nor day brings relief. A wrong answer that only defines the words separately misses the structural contrast: the poet compresses 24 hours of suffering into one line through dialect pairing.

## DIAGNOSTIC_QUESTION_3
A student writes: "*cklj* means *din* (day) and *i¡[kh* means *raat* (night) — so the poem just says days and nights pass." Using the poem's context, explain why this translation loses the poem's emotional core.

## DIAGNOSTIC_ANSWER_3
Correct answer: *cklj* implies a day of toil under the sun (*cklj* suggests *din charhana* — the day climbing, peaking), and *i¡[kh* suggests a night that *settles* heavily (*i¡[kh* from *i{kh* — to sit/stay). The standard words *din/raat* are neutral time markers; the dialect words embody the physical weight of time on the woman's body. The student's error: treating vocabulary as interchangeable labels rather than carriers of sensory experience.

## DIAGNOSTIC_QUESTION_4
Compare the use of *ek¡g* (stanza 3) and *ek¡gqV* (stanza 4). Both relate to 'monsoon/clouds', but their grammatical forms and contextual roles differ. Analyze how this morphological shift changes the imagery.

## DIAGNOSTIC_ANSWER_4
Correct answer: *ek¡g* (noun, masculine) = the monsoon season as an external event arriving (*ek¡g ijS vc ikyk* — monsoon has come now). *ek¡gqV* (adjective/feminine) = the sky *becoming* monsoon-like (*osQfgd ¯lxkj dks ifgj iVksjk* — the whole sky turns cloud-heavy). The shift from noun to adjective transforms monsoon from a 'guest who arrives' to a 'state that envelops', mirroring the woman's internal state from anticipation to immersion. A wrong answer that treats them as synonyms misses the grammatical-emotional mapping.

## DIAGNOSTIC_QUESTION_5
Critique this interpretation: "The words *jdr* (burning), *xjk* (scorched), and *tM+dkyk* (intense heat) in stanza 2 are just literal descriptions of summer weather." Defend or reject with textual evidence.

## DIAGNOSTIC_ANSWER_5
Correct answer: Reject. These words form a semantic cluster of *internal* burning: *jdr* (heart burning), *xjk* (hopes scorched), *tM+dkyk* (memories turning to ash). In context, *o"kkZ dk gksuk rFkk iou dk cguk Hkh fojg rki dks c<+k jgk gSA* — the heat is metaphorical, the fever of separation. A student who calls it 'weather description' fails to distinguish literal vs. figurative vocabulary layers — a critical board exam error.

## DIAGNOSTIC_QUESTION_6
Write two original lines in Braj/Awadhi dialect (or your own mother tongue) describing a farmer waiting for rain, using at least three words that carry cultural weight untranslatable into standard Hindi. Gloss each word with its contextual meaning.

## DIAGNOSTIC_ANSWER_6
Expected answer: Example (Braj): *बूंदन को तरसे नैन, धरती फटी जाय / बैन बिना कटै न रैन, पिया बिन कस होय* — Gloss: *बैन* (not just 'conversation' but intimate night-talk), *कटै* (not 'pass' but 'get cut/endured like a wound'), *कस* (not 'how' but 'with what strength/right'). A poor answer uses Hindi words with dialect spelling (*barish* → *barisan*) showing no grasp of untranslatable cultural lexicon.

## COMMON_MISCONCEPTION
Students memorize the NCERT glossary meanings (*nsol = din, fufl = raat*) and reproduce them in exams as 'meanings'. They do not realize that **board marking schemes award marks for explaining *why* that specific dialect word is used in *that* line** — e.g., *nsol* carries the connotation of 'day spent in field labor', not just 'daytime'. The error: treating vocabulary as static definitions rather than dynamic, context-dependent signifiers. This costs 1-2 marks per question in 3-marker 'explain with reference to context' questions.

## ON_FAILURE
If a student cannot move beyond glossary meanings: (1) Give them stanza 1 only. Ask: "Why *nsol*? Why not *din*? What picture comes to mind with *nsol* that *din* erases?" (2) Have them replace each dialect word with its standard Hindi equivalent and read aloud — they will hear the loss of rhythm, earthiness, intimacy. (3) Assign: "Find 3 words in your home language that have no exact Hindi/English equivalent. Write what they *feel* like." Re-diagnose with Diagnostic Question 2.

## BUILDS_ON
Class 11 vocabulary nodes (e.g., c11_hin_ar_cbse_01_010) where students learned to use glossaries; this node shifts from *using* glossaries to *interrogating* word choice.

## LEADS_TO
Node c12_hin_a_cbse_07_011 (Grammar: Language Usage) where dialect grammar (verb forms, case endings) is analyzed, and node c12_hin_a_cbse_07_013 (Critical Thinking) where vocabulary evidence supports thematic interpretation.

## PREREQUISITE_NODE_IDS
c11_hin_ar_cbse_01_010, c11_hin_ar_cbse_02_010, c11_hin_ar_cbse_03_010, c11_hin_ar_cbse_04_010, c11_hin_ar_cbse_05_010, c11_hin_ar_cbse_06_010, c11_hin_ar_cbse_07_010, c11_hin_ar_cbse_08_010, c11_hin_ar_cbse_09_010, c11_hin_ar_cbse_10_010, c11_hin_ar_cbse_11_010, c11_hin_ar_cbse_12_010, c11_hin_ar_cbse_13_010, c11_hin_ar_cbse_14_010, c11_hin_ar_cbse_15_010, c11_hin_ar_cbse_16_010, c11_hin_v_cbse_01_010, c11_hin_v_cbse_02_010, c11_hin_v_cbse_03_010, c11_hin_v_cbse_04_010, c11_hin_v_cbse_05_010, c12_hin_a_cbse_07_001, c12_hin_a_cbse_07_002, c12_hin_a_cbse_07_009

## PREREQUISITE_REASONS
c11_hin_ar_cbse_01_010: Built foundational skill of using NCERT glossary for dialect words in Antra poems.
c11_hin_ar_cbse_02_010: Practiced identifying context clues for unfamiliar words in narrative texts.
c11_hin_ar_cbse_03_010: Learned to distinguish literal vs. contextual meaning in folk-style poetry.
c11_hin_ar_cbse_04_010: Exposure to regional vocabulary in classical poets (Kabir, Surdas).
c11_hin_ar_cbse_05_010: Developed habit of reading aloud for phonetic cues to meaning.
c11_hin_ar_cbse_06_010: Compared standard vs. dialect synonyms in modern poetry.
c11_hin_ar_cbse_07_010: Analyzed how vocabulary creates speaker's persona in dramatic monologue.
c11_hin_ar_cbse_08_010: Studied semantic clusters (heat, rain, night) in nature poetry.
c11_hin_ar_cbse_09_010: Practiced glossing untranslatable cultural terms.
c11_hin_ar_cbse_10_010: Linked vocabulary choices to theme of separation (viraha).
c11_hin_ar_cbse_11_010: Explored morphological variations (ekg vs ekgqV) in context.
c11_hin_ar_cbse_12_010: Wrote original lines using mother-tongue vocabulary.
c11_hin_ar_cbse_13_010: Evaluated peer translations for loss of cultural nuance.
c11_hin_ar_cbse_14_010: Connected vocabulary to oral tradition and performance.
c11_hin_ar_cbse_15_010: Prepared for board-style 'meaning in context' questions.
c11_hin_ar_cbse_16_010: Synthesized vocabulary analysis with imagery and tone.
c11_hin_v_cbse_01_010: Vitran textbook practice with simpler dialect texts.
c11_hin_v_cbse_02_010: Reinforced context-clue strategy for vocabulary.
c11_hin_v_cbse_03_010: Applied vocabulary skills to prose passages.
c11_hin_v_cbse_04_010: Compared vocabulary across genres (poetry vs prose).
c11_hin_v_cbse_05_010: Consolidated Class 11 vocabulary competency.
c12_hin_a_cbse_07_001: Provides historical/cultural context of efyd eqgEen tk;lh and Braj Bhasha.
c12_hin_a_cbse_07_002: Establishes narrative structure so vocabulary can be mapped to speaker's emotional arc.
c12_hin_a_cbse_07_009: Vocabulary work (Braj words like "lans'k", "yad", "ewy") needs the symbolic/ironic context to explain *why* specific words carry emotional weight.  

## FORWARD_NODE_IDS
c12_hin_a_cbse_07_011, c12_hin_a_cbse_07_012, c12_hin_a_cbse_07_013, c12_hin_a_cbse_07_014, c12_hin_a_cbse_07_015

## FORWARD_REASONS
c12_hin_a_cbse_07_011: Dialect vocabulary informs grammatical analysis (verb forms, case markers in Braj).
c12_hin_a_cbse_07_012: Comprehension answers require precise vocabulary interpretation for inferential questions.
c12_hin_a_cbse_07_013: Critical interpretation uses vocabulary evidence to support thematic claims.
c12_hin_a_cbse_07_014: Writing tasks (character sketch, thematic essay) demand quoting and glossing key words.
c12_hin_a_cbse_07_015: Dialect vocabulary enables authentic textual citation  

## CROSS_SUBJECT_PREREQS
c11_hin_ar_cbse_07_010, c11_hin_ar_cbse_10_010
## CROSS_SUBJECT_REASONS
c11_hin_ar_cbse_07_010: Direct predecessor — same skill (vocabulary in context) applied to Class 11 dramatic monologue; this node deepens it with more complex dialect.
c11_hin_ar_cbse_10_010: Theme of separation (viraha) vocabulary cluster (rain, night, fire) recurs — student transfers analytical framework.

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_07_010 -> c12_hin_a_cbse_07_010 -> c12_hin_a_cbse_07_11 (Grammar) and c12_hin_a_cbse_07_13 (Critical Thinking)

## THIS_FORMULA
N/A - conceptual

## FORMULA_VARIABLES
N/A

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
linguistic

## CROSS_SUBJECT
N/A | Bhakti poets (Surdas, Mirabai) use Braj/Awadhi vocabulary identically — analyzing *tk;lh* trains the same skill needed for History source-based questions on Bhakti texts.
 N/A | Words like *cklj* (day climbing), *i¡[kh* (night settling), *fgoapy* (clouds gathering from east) encode agricultural timekeeping — Geography case studies on traditional cropping calendars use identical lexical data.
## PREREQ_CONCEPT
Ability to use context clues (surrounding words, imagery, speaker's situation) to hypothesize meaning before consulting glossary.

## PREREQ_BEFORE
Student must have read the poem aloud at least twice and marked 15+ unfamiliar words.

## PREREQ_STUCK
If stuck, revisit Class 11 node c11_hin_ar_cbse_07_010 (Vocabulary in Context: Key Words) — specifically the 'context-clue strategy' worked example for Kabir's dohas.

## WORKED_EXAMPLE_1
PROBLEM: Analyze the word *lhÅ* in stanza 1 (*tukok lhmQA*). The glossary says *lhÅ = 'khr* (moment). But *kshan* (standard Hindi) also means moment. Why does the poet choose *lhÅ* here?
STEPS:
- Step 1: Locate the word in context — *?kj ?kj phj jpk lc dkgw¡ / iyfV u cgqjk xk tks fcNksbZA / fl;fj vfxfu fcjfgfu fg; tkjkA / ;g nq[k nxèk u tkuS oaQrwA / nwHkj nq[k lks tkb fdfe dk<+hAA / tjS fcjg T;ksa nhid ckrhAA / rkS iS tkb gksb l¡x ihmQAA* — the speaker describes a moment so intense it feels like a lifetime.
- Step 2: Compare *lhÅ* (Braj) vs *kshan* (Sanskrit/Hindi). *kshan* is clinical, measurable, neutral. *lhÅ* (from *lakshana* — mark/sign) implies a *marked* moment, a moment that *leaves a mark*, a moment pregnant with significance.
- Step 3: Check phonetics — *lhÅ* is heavy, lingers on the tongue (*lh* + *Å*), mimicking the stretching of time in grief. *kshan* is light, quick.
- Step 4: Connect to speaker — she is a rural woman for whom time is not clock-time but event-time. *lhÅ* = the moment the beloved's memory strikes.
- Step 5: Verify with theme — the poem contrasts clock-time (seasons, day/night) with psychological time. *lhÅ* anchors the latter.
REASONING: This 5-step method (locate → compare → phonetics → persona → theme) works for any dialect word. It moves from textual evidence to interpretive claim — exactly what board exams reward.
ANSWER: *lhÅ* is chosen over *kshan* because it denotes a *subjectively weighted, memorable instant* — the moment grief becomes physical — aligning with the speaker's lived, non-clock time and the poem's theme of timeless waiting.

## WORKED_EXAMPLE_2
PROBLEM: The glossary gives *fg;k = ân;* (grace/beauty). In stanza 1: *dk¡ik fg;k tukok lhmQA*. A student writes: "The woman's beauty is fading." Is this correct? Justify using context.
STEPS:
- Step 1: Read the full stanza — the speaker describes the woman: *vxgu nsol ?kVk fufl ck<+hA / vc èkfu nsol fcjg Hkk jkrhA* — she is awake all day and night, eyes fixed on the path.
- Step 2: Note *fg;k* modifies *dk¡ik* (body) and *tukok* (wasted/emaciated). *dk¡ik fg;k tukok* = body, once graceful, now wasted.
- Step 3: Check *tukok* glossary: *izrhr gqvk* (wasted away). So *fg;k* refers to *past* grace, not current beauty.
- Step 4: Synthesize — the line contrasts *former grace* (*fg;k*) with *present emaciation* (*tukok*) within the *same moment* (*lhÅ*). The tragedy is the collapse of grace into wasting.
- Step 5: Formulate answer — "The student is partially wrong. *fg;k* here means 'former grace/beauty' now lost. The line mourns the *destruction* of grace by waiting, not the fading of beauty."
REASONING: Vocabulary in context requires reading the *syntactic environment* (what modifies what) and *temporal markers* (past vs present). Glossary alone gives *static* meaning; syntax gives *dynamic* meaning.
ANSWER: No, the interpretation is incorrect. *fg;k* refers to the woman's *past* grace ("body once full of grace"), now contrasted with *tukok* (wasted away). The line captures the *moment* (*lhÅ*) when grace collapses into emaciation — the tragedy of waiting made visible.

## WORKED_EXAMPLE_3
PROBLEM: Stanza 4 uses *pk¡pfj* (glossary: *gksyh osQ le; [ksys tkus okyk pjpfj uked ,d [ksy ftlesa lHkh ,d&nwljs ij jax Mkyrs gSa*). The line: *iQkx djfg lc pk¡pfj tksjhA*. Explain how this single dialect word *pk¡pfj* condenses the poem's central metaphor of *time as a cyclical, collective game*.
STEPS:
- Step 1: Unpack glossary definition — *pk¡pfj* = a game played at a specific season (*gksyh osQ le;*), where everyone takes turns (*lHkh ,d&nwljs ij jax Mkyrs gSa*). It is seasonal, communal, rule-bound, cyclical.
- Step 2: Locate in line — *iQkx djfg lc pk¡pfj tksjhA* (monsoon plays *pk¡pfj* with lightning). The monsoon (*iQkx*) is the *player*, lightning (*tksjh*) is the *move/turn*.
- Step 3: Map to poem's time structure — Stanza 1: *nsol/fufl* (day/night cycle). Stanza 2: *cklj/i¡[kh* (day/night again). Stanza 3: *ek¡g* (monsoon arrives). Stanza 4: *iQkx* (monsoon *plays*).
- Step 4: Analyze metaphor — Waiting is not linear suffering but a *game* the monsoon plays *with* the woman. Each lightning flash = a turn. She is both player and pawn. The cyclical *pk¡pfj* mirrors her cyclical hope/despair.
- Step 5: Connect to *eoqQ* (stanza 4 end: *eoqQ rsfg ekjx gksb ijkSa* — "firmly, the clouds thunder"). *eoqQ* = *dnkfpr/ekuks* (resolute/oath-bound). The game has rules; the monsoon *keeps its oath* to return. Her waiting is her *move* in the game.
- Step 6: Final claim — *pk¡pfj* transforms 'waiting' from passive endurance into *ritual participation* in a cosmic seasonal game. This is the poem's philosophical core.
REASONING: This example shows how ONE dialect word, fully unpacked (etymology → glossary → syntax → stanza → whole poem → philosophy), becomes the key to the text. This is the depth JEE/NEET humanities passages and CUET critical reasoning demand.
ANSWER: *pk¡pfj* condenses the metaphor by framing the monsoon's arrival and the woman's waiting as a *seasonal, communal, rule-bound game of turns*. The monsoon plays its turn (lightning); she plays hers (waiting). The cyclical nature of *pk¡pfj* mirrors the poem's day/night/season cycles, elevating her personal grief to a cosmic ritual where both nature and human keep their *eoqQ* (oath) to return and wait.

## COMPETENCY_QUESTION_1
QUESTION: In the poem "ckjgeklk", the word *nwHkj* (glossary: *dfBu] eqf'dy* — deep, profound) appears in *nwHkj nq[k lks tkb fdfe dk<+hAA*. A student claims: "*nwHkj* here means 'deep night'." Using the poem's imagery of *eyes (nq[k)* and *path (dk<+h)*, evaluate this claim and explain what *nwHkj* actually modifies and why it matters.
COMPETENCY: Textual Evidence-Based Reasoning
STEPS:
- Step 1: Identify the syntactic unit — *nwHkj nq[k* (deep/profound eyes), not *nwHkj fufl* (deep night).
- Step 2: Analyze *nq[k* (eyes) in context — *?kj ?kj phj jpk lc dkgw¡ / iyfV u cgqjk xk tks fcNksbZA* — eyes fixed on every lane, not blinking.
- Step 3: Interpret *nwHkj* modifying *nq[k* — eyes that have *gone deep* into the path, eyes that have *become* the path. Not 'deep night' but 'eyes deepened by staring'.
- Step 4: Thematic link — *nwHkj nq[k* = the internalization of waiting; the path lives inside her gaze. This supports the poem's fusion of subject and landscape.
ANSWER: The claim is incorrect. *nwHkj* modifies *nq[k* (eyes), not *fufl* (night). It means 'profound/deepened' — her eyes have grown deep from unblinking fixation on the path (*dk<+h*). This shifts focus from external time (night) to internal transformation (eyes becoming the path), central to the poem's portrayal of waiting as self-erasure.
DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: The poem uses three distinct words for 'rain/clouds': *ek¡g* (stanza 3), *ek¡gqV* (stanza 4), *iQkx* (stanza 4). Create a 3-column table: Word | Grammatical Form | Contextual Function | Thematic Effect. Then write a 50-word synthesis: How does this lexical gradient enact the woman's journey from hope to dissolution?
COMPETENCY: Linguistic Analysis & Synthesis
STEPS:
- Step 1: *ek¡g* — Noun (masc.) — "Monsoon has come" (*ek¡g ijS vc ikyk*) — External event, arrival, hope.
- Step 2: *ek¡gqV* — Adjective (fem.) — "Sky turns monsoon-heavy" (*osQfgd ¯lxkj dks ifgj iVksjk*) — State change, envelopment, immersion.
- Step 3: *iQkx* — Noun (masc., agent) — "Monsoon plays *pk¡pfj* with lightning" (*iQkx djfg lc pk¡pfj tksjh*) — Active player, cyclical agent, cosmic game.
- Step 4: Synthesize gradient — Noun (event) → Adjective (atmosphere) → Agent (force). The woman moves from *waiting for* (ek¡g) → *drowning in* (ek¡gqV) → *participating with* (iQkx) the monsoon. Her agency is not lost but *ritualized*.
ANSWER: Table: ek¡g | Noun | Arrival event | Hope ignited | ; ek¡gqV | Adjective | Sky's transformation | Immersion, no escape | ; iQkx | Agent noun | Cosmic player in seasonal game | Ritualized participation. Synthesis: The lexical shift from noun to adjective to agent traces her journey from anticipating a savior (ek¡g), to being consumed by the atmosphere (ek¡gqV), to recognizing her waiting as a move in an eternal, rule-bound game (iQkx) — where both she and the monsoon keep their oath (eoqQ).
DIFFICULTY: hard