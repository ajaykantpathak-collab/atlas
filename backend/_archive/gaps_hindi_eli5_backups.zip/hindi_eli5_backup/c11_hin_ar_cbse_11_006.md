## DEFINITION
The primary theme of a literary work is its central, unifying idea or insight about human experience that the author conveys through the narrative elements; the message is the specific moral, lesson, or perspective the author intends the reader to derive from that theme. In poetry, the primary theme emerges from the interplay of imagery, tone, structure, and the speaker's emotional journey, while the message crystallizes the universal truth embedded in the personal experience.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student can independently identify the primary theme of "?kj dh ;kn" by tracing the evolution of the speaker's emotional state across stanzas, cite specific imagery (e.g., the four walls, the father's silence, the mother's unfinished letter) as evidence, and articulate the poem's message about the dual nature of memory as both sustenance and sorrow in a structured analytical paragraph.

## SCOPE_BOUNDARY
This node covers the identification and analysis of the *primary* theme (the anguish of separation from home and the erosion of memory) and its core message (home as an emotional anchor that defines identity). It does NOT cover secondary themes like the passage of time, generational roles, or the act of writing itself, which are addressed in node c11_hin_ar_cbse_11_007.

## WALKTHROUGH
Imagine you have moved to a new city for Class 11 and, late at night, the smell of your mother's cooking suddenly flashes in your mind — that instantaneous, visceral pull is the heart of this poem. To analyze its theme, first read the poem aloud to hear the rhythm of longing in the refrain "ikuh fxj jgk gS". Next, map the speaker's journey: Stanza 1 establishes physical distance, Stanza 2 introduces the symbolic "four walls/four doors" as the container of memory, Stanza 3 shifts to the parents' fading presence, and Stanza 4 culminates in the speaker's realization that *he* has become the keeper of the home's story. Notice how the refrain shortens and internalizes — from "ghar" to "ghar nahi" — mirroring the fading memory. The key insight: the poem argues that we do not just remember home; we *become* its living archive, and that role is both a privilege and a wound.

## DIAGNOSTIC_QUESTION_1
What is the literal meaning of the refrain "ikuh fxj jgk gS" and how does its repetition structure the poem's emotional arc?

## DIAGNOSTIC_ANSWER_1
The refrain literally means "a very long separation persists" or "the separation has become very long." Its repetition acts as a structural heartbeat: each recurrence marks a deepening of the speaker's awareness — first as a factual statement of distance, then as an emotional weight ("jkr Hkj fxjrk jgk gS"), then as a realization of parental aging, and finally as an internalized identity ("ghar nahi gw¡ cl ;gh gS"). A wrong answer that only translates the phrase without explaining its *progressive* function reveals the student sees repetition as mere decoration rather than a thematic engine.

## DIAGNOSTIC_QUESTION_2
The poem describes the home as having "pkj HkkbZ pkj cfgusa" (four walls, four doors). Explain why the poet chooses this specific architectural imagery instead of describing the home's beauty or size.

## DIAGNOSTIC_ANSWER_2
The "four walls, four doors" imagery reduces the home to its bare geometric essence, symbolizing that the physical structure is secondary to the *containment* of memories and relationships. It reflects the speaker's mental state: stripped of ornamentation, focused only on the boundaries that once held love ("firk th", "ek¡") and now hold absence. A wrong answer focusing on literal architecture or vastu shastra misses the metaphorical function — the student is reading descriptively, not analytically.

## DIAGNOSTIC_QUESTION_3
In Stanza 3, the father says "I;kj esa cgrs jgs gSa" (they keep walking in the courtyard) and the mother's letter remains unfinished. Apply the concept of 'unfinished action' to explain how these details develop the theme of *eroding memory*.

## DIAGNOSTIC_ANSWER_3
The father's aimless walking and the mother's incomplete letter represent memories that have lost their narrative closure — the father no longer has a purpose (no "k.k" / work), the mother's communication is cut off. This mirrors the speaker's own fading recall: "mls fy[kuk ugha vkrk / tks fd mldk i=k ikrk". The erosion is not sudden but a daily attrition ("dke esa >a>k yjtrk"). A wrong answer that treats these as mere plot details fails to see how *form* (unfinished actions) enacts *theme* (memory's fragmentation).

## DIAGNOSTIC_QUESTION_4
Compare the speaker's relationship to "home" in Stanza 1 ("?kj u”kj esa frj jgk gS") versus Stanza 4 ("?kj ugha gw¡ cl ;gh gS"). Analyze how this shift redefines the primary theme from *longing for a place* to *bearing a legacy*.

## DIAGNOSTIC_ANSWER_4
In Stanza 1, home is an external locus ("u”kj") where the speaker waits, passive and located *inside* the memory. In Stanza 4, the speaker declares "eSa e”ks esa gw¡ lgh gS / ?kj ugha gw¡ cl ;gh gS" — home has migrated *into* the speaker; he *is* the remnant ("cl"). The theme transforms from spatial separation to ontological responsibility: the poem's message is that exile makes you the home's sole witness. A wrong answer that only notes "he misses home more" misses the metaphysical inversion — the student hasn't grasped the shift from object to subject.

## DIAGNOSTIC_QUESTION_5
The poem ends with the lines "gs lthys gjs lkou / gs fd esjs iq.; ikou". Evaluate whether this conclusion offers resolution or perpetuates the anguish, using the poem's own logic.

## DIAGNOSTIC_ANSWER_5
It perpetuates the anguish *as* a form of resolution. The pledge "rqe cjl yks os u cjlsa / ik¡posa dks os u rjlsa" (I won't let you go, I won't let memories fade) is a vow to resist the very erosion the poem documents. But the preceding line "dke djrk gw¡ fd dguk / uke djrk gw¡ fd dguk" (I work to speak / I work to name) admits this is labor, not grace. The poem's logic: memory survives only through active, painful curation. A wrong answer calling it "hopeful" or "sad" flattens the complexity — the student is imposing external binaries instead of reading the text's internal tension.

## DIAGNOSTIC_QUESTION_6
Write a four-line stanza in Hindi that could serve as a *fifth stanza* to this poem, maintaining the refrain's rhythm and advancing the theme of the speaker becoming the home's living archive. Do not copy any existing lines.

## DIAGNOSTIC_ANSWER_6
A strong response will:
1. Use the refrain's meter (e.g., "gk;] ikuh fxj jgk gS" or a variation)
2. Introduce a new concrete image of the speaker *enacting* memory (e.g., cooking a familiar dish, teaching a child a lullaby)
3. Show the shift from "remembering" to "embodying"
4. End with a line that echoes "ghar nahi gw¡ cl ;gh gS" in spirit.
Example: "gk;] ab main hi banaun vo hi dal-chawal / gk;] ab main hi sunaun vohi lori / gk;] haathon mein unki khushbu ab bhi hai / gk;] ghar nahi main hoon, bas yahi kahaani."
A poor answer uses abstract nouns ("pyaar", "yaadein") without sensory grounding, showing the student cannot translate thematic analysis into creative synthesis.

## COMMON_MISCONCEPTION
Students conflate *theme* with *subject* or *plot summary*, writing "The poem is about missing home" instead of "The poem explores how forced separation transforms a physical home into an internalized, fragmented archive that the exile must actively sustain." They also mistake the *refrain* for a chorus — expecting it to return identically — and miss how FeJ varies it ("jkr Hkj fxjrk", "izk.k eu f?kjrk") to chart psychological progression. This error stems from middle-school training that treats poems as "messages in a bottle" rather than as dynamic arguments made through form.

## ON_FAILURE
1. **Re-anchor with the refrain**: Have the student write each variant of the refrain on a separate card and arrange them in order, then speak aloud the *emotional difference* between "fxj jgk gS" (neutral) → "fxjrk jgk gS" (weighted) → "f?kjrk" (aching) → internalized "cl ;gh gS".
2. **Map the "Four Walls"**: Draw a rectangle labeled "pkj HkkbZ pkj cfgusa". Inside, place sticky notes for each memory (father's silence, mother's letter, childhood games). Outside, write what *erodes* them (time, distance, death). Discuss: "Which memories stay inside? Which escape?"
3. **Role-play the final declaration**: Student speaks Stanza 4 as a monologue to an empty room. Ask: "Who is 'rqe' (you) in 'rqe cjl yks os u cjlsa'? The parents? The memories? The home itself?" This forces the shift from *missing* to *keeping*.

## BUILDS_ON
This node builds on the student's ability to trace a speaker's emotional arc through structural repetitions (learned in c11_hin_ar_cbse_11_002 Plot and Narrative Structure) and to interpret symbolic imagery (c11_hin_ar_cbse_11_003 Setting and Atmosphere).

## LEADS_TO
This node enables the analysis of secondary themes (c11_hin_ar_cbse_11_007) such as the gendered nature of memory (mother's letter vs father's silence) and the meta-theme of poetry as preservation (c11_hin_ar_cbse_11_013 Critical Thinking).

## PREREQUISITE_NODE_IDS
c11_hin_ar_cbse_11_001, c11_hin_ar_cbse_11_002, c11_hin_ar_cbse_11_003, c11_hin_ar_cbse_11_004, c11_hin_ar_cbse_11_005
## PREREQUISITE_REASONS
c11_hin_ar_cbse_11_001: Provides biographical context (FeJ's own exile from Punjab) essential to reading the speaker as a persona shaped by Partition displacement.
c11_hin_ar_cbse_11_002: Establishes the poem's non-linear narrative structure — the movement from present longing to past scenes to future vow — which the theme analysis must follow.
c11_hin_ar_cbse_11_003: Identifies the atmosphere of "tsy&izokl" (childhood separation) and "voèkkj.kk" (physical/emotional pain) as the tonal bedrock of the theme.
c11_hin_ar_cbse_11_004: Analyzes the speaker as a witness-figure whose evolving consciousness (from waiting to working to vowing) *is* the thematic argument.
c11_hin_ar_cbse_11_005: Details the parents' characterization (father's purposelessness, mother's interrupted communication) as the specific human content that the theme of "eroding memory" acts upon.

## FORWARD_NODE_IDS
c11_hin_ar_cbse_11_007, c11_hin_ar_cbse_11_008, c11_hin_ar_cbse_11_009, c11_hin_ar_cbse_11_013, c11_hin_ar_cbse_11_010, c11_hin_ar_cbse_11_011, c11_hin_ar_cbse_11_012, c11_hin_ar_cbse_11_014, c11_hin_ar_cbse_11_015, c12_hin_a_cbse_11_006, c12_hin_ar_cbse_11_006, c12_hin_ar_cbse_12_006

## FORWARD_REASONS
c11_hin_ar_cbse_11_007: The primary theme (memory as archive) creates the framework to explore secondary themes: time's erosion, the gendered labor of remembering, writing as resistance.
c11_hin_ar_cbse_11_008: The central imagery (four walls, unfinished letter, courtyard walking) are the primary metaphors whose analysis deepens the theme.
c11_hin_ar_cbse_11_009: The irony (home persists only in the one who left) and symbolism (refrain as heartbeat) are the devices that *construct* the primary theme.
c11_hin_ar_cbse_11_013: Critical interpretation (e.g., "Is the poem nostalgic or anti-nostalgic?") requires a settled understanding of the primary theme as a baseline.
c11_hin_ar_cbse_11_010: The primary theme (home as memory vs home as loss) is the lens through which every key word must be analyzed.  
c11_hin_ar_cbse_11_011: Theme analysis identifies the poem's central themes (nostalgia, loss, the persistence of memory, home as identity), which are the *meaning* that grammatical structures serve. Without thematic clarity, grammar analysis becomes identification of features without explanation of function — the student needs to know what emotion or theme the grammar is constructing.  
c11_hin_ar_cbse_11_012: Primary theme (memory/loss) is the overarching framework for valid inferences.  
c11_hin_ar_cbse_11_014: Primary theme identification anchors the "Link" step in PEEL.  
c11_hin_ar_cbse_11_015: Primary theme (nostalgia as psychological imprisonment) gives the discussion its conceptual anchor.  
c12_hin_a_cbse_11_006: Class 11 theme-analysis practice provides the methodological foundation for multi-text synthesis.  
c12_hin_ar_cbse_11_006: Class 11 theme analysis of "नमक का दरोगा" established the method of tracking a central idea across dialogue and narrative — directly transferable here.  
c12_hin_ar_cbse_12_006: Grammar of thematic writing (abstract nouns, nominalization).  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
none

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_11_001 -> c11_hin_ar_cbse_11_002 -> c11_hin_ar_cbse_11_003 -> c11_hin_ar_cbse_11_004 -> c11_hin_ar_cbse_11_005 -> c11_hin_ar_cbse_11_006 -> c11_hin_ar_cbse_11_007 -> c11_hin_ar_cbse_11_013

## THIS_FORMULA
N/A - conceptual

## FORMULA_VARIABLES
N/A

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
conceptual

## CROSS_SUBJECT
c11_history_partition_displacement | The poem's context of Partition-era migration (FeJ's life) connects to History's study of 1947 displacement; the "four walls" become a synecdoche for the lost homeland, enabling analysis of how literature archives collective trauma.
c11_psychology_memory_consolidation | The poem enacts psychological theories of memory decay and effortful retrieval (Stanza 4's "dke djrk gw¡ fd dguk"); students can compare the speaker's "active curation" with the concept of memory reconsolidation in cognitive psychology.

## PREREQ_CONCEPT
The student must understand that in poetry, *form enacts meaning* — structural choices (refrain variation, stanza progression, imagery clusters) are not decorative but are the primary evidence for thematic claims.

## PREREQ_BEFORE
The student must be able to distinguish between a poem's *subject* (what it's about: missing home) and its *theme* (what it says about that subject: memory transforms the exile into the home's living archive).

## PREREQ_STUCK
If stuck, review the concept of "refrain as structural argument" from c11_hin_ar_cbse_11_002 (Plot and Narrative Structure) and practice mapping emotional shifts across refrain variations in any familiar poem/song.

## WORKED_EXAMPLE_1
PROBLEM: A student writes in a board exam: "The main theme of '?kj dh ;kn' is homesickness. The poet misses his parents and his house. The refrain 'ikuh fxj jgk gS' shows he has been away for a long time." Upgrade this answer to a senior-secondary level analytical response using the PEEL structure (Point, Evidence, Explanation, Link).

STEPS:
- Step 1: Identify the weakness — the answer states subject ("homesickness") not theme, cites no specific imagery, treats refrain as static repetition, and lacks analytical vocabulary.
- Step 2: Formulate a precise thematic point: "The primary theme is the transmutation of physical separation into an ontological burden — the exile becomes the home's sole living archive."
- Step 3: Select evidence: (a) Refrain evolution: "ikuh fxj jgk gS" → "jkr Hkj fxjrk jgk gS" → "ghar nahi gw¡ cl ;gh gS". (b) "pkj HkkbZ pkj cfgusa" as minimal container. (c) Father's "I;kj esa cgrs" and mother's unfinished letter as eroding memory. (d) Final vow "dke djrk gw¡ fd dguk" as active preservation.
- Step 4: Write PEEL paragraph: Open with thematic point. Quote refrain variants to show progression. Explain how "four walls" reduces home to a memory-vessel. Explain how parental fading forces speaker's role-shift. Link to message: memory is not passive nostalgia but ethical labor.
- Step 5: Verify against marking scheme: Does it use textual evidence? Yes. Does it analyze form? Yes. Does it articulate a message? Yes. Is it in formal Hindi/English? Yes.

REASONING: This upgrade works because it moves from *description* (what happens) to *interpretation* (how the poem constructs meaning through its specific choices). The PEEL structure ensures each claim is anchored in the text, which is the board exam's core requirement for "analysis and interpretation" questions.

ANSWER:
**Upgraded Answer:** "The primary theme of '?kj dh ;kn' is not merely homesickness but the *metamorphosis of memory into identity*. The poem traces how forced separation (tsy&izokl) compels the speaker to internalize the home he has lost. This is structurally enacted through the refrain's evolution: the neutral 'ikuh fxj jgk gS' (Stanza 1) deepens into the weighted 'jkr Hkj fxjrk jgk gS' (Stanza 2), then the aching 'izk.k eu f?kjrk' (Stanza 3), culminating in the metaphysical declaration 'ghar nahi gw¡ cl ;gh gS' (Stanza 4) — the home no longer exists externally; the speaker *is* its remnant (cl). The imagery of 'pkj HkkbZ pkj cfgusa' strips the house to its geometric essence, making it a vessel for memory rather than a dwelling. The parents' fading presence — father walking aimlessly ('I;kj esa cgrs'), mother's letter forever incomplete ('mls fy[kuk ugha vkrk') — externalizes the erosion of recall. The poem's message emerges in the final vow: 'dke djrk gw¡ fd dguk / uke djrk gw¡ fd dguk' — memory survives only through deliberate, painful curation. Thus, the theme redefines exile not as loss but as the assumption of a sacred, burdensome stewardship."

## WORKED_EXAMPLE_2
PROBLEM: The exam asks: "Explain how the image of the mother's unfinished letter ('mls fy[kuk ugha vkrk / tks fd mldk i=k ikrk') functions as a central symbol for the poem's primary theme." Write a 4-step analytical response.

STEPS:
- Step 1: Define the symbol's literal level — the mother cannot finish a letter because she forgets the ending, or the act of writing itself is interrupted by age/illness.
- Step 2: Connect to the theme of *eroding memory* — the unfinished letter mirrors the speaker's own fragmented recall ("nq[k ugha fiQj", "ilkjk"). Both are narratives cut short by time/distance.
- Step 3: Analyze the symbol's *active* dimension — the letter is a bridge *to* the speaker; its incompleteness severs communication. Yet the speaker *responds* by writing the poem ("fy[k jgk gw¡"), completing the circuit. The poem *becomes* the finished letter.
- Step 4: Synthesize into the primary theme — the symbol encapsulates the shift from *receiving* memory (passive) to *generating* it (active). The message: when the original witnesses fail, the exile must become the author of the home's story.

REASONING: This response demonstrates the senior-secondary skill of reading a single image as a microcosm of the entire thematic architecture. It avoids paraphrase by focusing on the symbol's *function* (bridge, rupture, replacement) and its structural position (Stanza 3, pivot to speaker's vow in Stanza 4).

ANSWER:
"The mother's unfinished letter operates as the poem's central symbol for the *fragility and transfer of memory*. Literally, it depicts maternal decline — the 'i=k' (letter/news) that should connect home to exile remains perpetually open-ended ('mls fy[kuk ugha vkrk'). Symbolically, this incompleteness mirrors the speaker's own failing recall ('nq[k ugha fiQj', 'ilkjk'), making the letter an objective correlative for the theme of memory's erosion. Crucially, the symbol pivots from rupture to repair: the mother's silence ('dk ;gk¡ rd Hkh ilkjk') is answered by the speaker's writing ('fy[k jgk gw¡', 'i<+ jgk gw¡'). The poem *becomes* the completed letter — the 'i=k' that finally *does* reach its destination. Thus, the symbol enacts the primary theme: memory is not a static heirloom but a relay race; when the first runner (mother) drops the baton, the exile (speaker) must pick it up and run. The message: we do not just inherit home; we must *rewrite* it into existence."

## WORKED_EXAMPLE_3
PROBLEM: A board-level competency question: "The poem '?kj dh ;kn' uses the refrain not as a mere repetition but as a device to chart the speaker's psychological transformation. Analyze this statement with reference to at least three variations of the refrain and their corresponding stanzas." Write a 6-step response.

STEPS:
- Step 1: Deconstruct the prompt — it demands: (a) refrain as *device*, not decoration; (b) psychological transformation (not just emotion); (c) three specific variations + stanza mapping.
- Step 2: Catalog the variations with stanza numbers:
  1. Stanza 1: "ikuh fxj jgk gS" (factual duration)
  2. Stanza 2: "jkr Hkj fxjrk jgk gS" + "izk.k eu f?kjrk" (visceral weight)
  3. Stanza 3: Refrain returns but context shifts to parents' decline
  4. Stanza 4: Internalized negation "ghar nahi gw¡ cl ;gh gS" (identity shift)
- Step 3: Analyze Variation 1 (Stanza 1) — "fxj jgk gS" uses stative verb; speaker is *located* in separation. Psychology: denial/endurance phase. "u”kj esa frj" — waiting inside memory.
- Step 4: Analyze Variation 2 (Stanza 2) — "jkr Hkj" (chest filled) and "f?kjrk" (heart bursts) somaticize the separation. Psychology: embodiment of grief. The "four walls/doors" image appears here — the container is feeling the pressure.
- Step 5: Analyze Variation 3 (Stanza 4) — "ghar nahi gw¡ cl ;gh gS" uses copular negation + noun phrase. The speaker *denies* being the home, *affirms* being the remnant. Psychology: acceptance + agency. The vow "dke djrk gw¡ fd dguk" follows immediately — transformation complete.
- Step 6: Synthesize — The refrain's trajectory: External fact → Internal sensation → Ontological redefinition. This *is* the psychological transformation. The device (refrain variation) *performs* the theme.

REASONING: This response meets the highest band because it treats the refrain as a *time-lapse camera* for the psyche. Each variation is not just a repeat but a *mutation* that reveals a new layer of the speaker's consciousness. The step-by-step mapping of linguistic change (verb choice, negation, noun phrase) to psychological state is exactly what "analyze" requires at Class 11.

ANSWER:
"The refrain in '?kj dh ;kn' functions as a psychological seismograph, registering the speaker's shift from passive victim of distance to active architect of memory. Three key variations map this transformation:

1. **Stanza 1: 'ikuh fxj jgk gS' (Separation persists as fact).** The stative construction ('jgk gS') presents separation as an external condition. The speaker resides *within* the memory ('?kj u”kj esa frj jgk gS'), psychologically frozen in a waiting mode — the 'tsy&izokl' (childhood separation) is a past event still governing the present.

2. **Stanza 2: 'jkr Hkj fxjrk jgk gS / izk.k eu f?kjrk' (Separation becomes somatic crisis).** The verb shifts to 'fxjrk' (has become long) and the imagery internalizes: 'jkr Hkj' (chest filled), 'eu f?kjrk' (heart bursts). The separation is no longer *around* him; it occupies his body. The simultaneous introduction of 'pkj HkkbZ pkj cfgusa' suggests the home's boundaries are now the speaker's ribcage — the container has moved from architecture to anatomy.

3. **Stanza 4: 'ghar nahi gw¡ cl ;gh gS' (Separation resolves into identity).** The refrain is shattered and rebuilt. The negation 'ghar nahi' rejects the external referent; the affirmation 'cl ;gh gS' (I am the remnant) claims the home's essence as self. The immediate pivot to 'dke djrk gw¡ fd dguk' (I work to speak) marks the psychological arrival: from *enduring* memory to *curating* it.

The refrain thus does not repeat — it *evolves*, each variation a developmental milestone. The device enacts the theme: memory's erosion forces the exile to become its living archive."

## COMPETENCY_QUESTION_1
QUESTION: "A Class 11 student claims: 'The poem is sad because the poet cannot go back home.' Using the poem's own evidence, explain why this reading reduces a complex thematic argument to a simple emotional label. What does the poem *do* with that sadness that makes it thematically significant?"

COMPETENCY: Critical Thinking - Evaluating Interpretations

STEPS:
- Step 1: Acknowledge the student's reading as a valid *entry point* (the poem *is* sad) but identify the reduction: it treats sadness as the *endpoint* rather than the *raw material*.
- Step 2: Cite Stanza 4's reframing: "dke djrk gw¡ fd dguk" — sadness is converted into *labor*. The poem does not wallow; it *works*.
- Step 3: Cite the refrain's evolution — sadness deepens into responsibility ("cl ;gh gS").
- Step 4: Articulate the thematic significance: Sadness is the fuel for the ethical act of preservation. The message: Grief, when metabolized through language, becomes stewardship.
- Step 5: Conclude: The poem's significance lies not in *expressing* homesickness but in *theorizing* it as a creative, identity-forming force.

ANSWER:
"The student's reading commits the 'affective fallacy' — judging the poem by the emotion it evokes rather than the intellectual structure it builds. The poem *uses* sadness as its raw material to construct a theory of memory. Evidence: (1) The final stanza rejects passivity: 'dke djrk gw¡ fd dguk / uke djrk gw¡ fd dguk' — sadness is the *workshop*, not the product. (2) The refrain's trajectory from 'fxj jgk gS' (description) to 'cl ;gh gS' (definition) shows sadness *transforming into identity*. (3) The mother's unfinished letter (symbol of failed transmission) is answered by the poem itself (successful transmission). The poem's thematic significance: it argues that exile does not merely *cause* grief; it *assigns* a vocation — the exile becomes the home's 'i=k' (letter/news), its living archive. Sadness is the price of that vocation, not its definition."

DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: "The poem's primary theme can be read as a critique of nostalgia. Develop this argument by analyzing how the poem distinguishes between *nostalgia* (passive longing for an idealized past) and *memory-work* (active, painful curation of the past). Use three specific textual moments to support your analysis."

COMPETENCY: Analytical Reasoning - Conceptual Distinction and Textual Evidence

STEPS:
- Step 1: Define the distinction for this poem: Nostalgia = "ghar u”kj esa frj jgk gS" (waiting inside a frozen past); Memory-work = "dke djrk gw¡ fd dguk" (laboring to name/keep the past alive in the present).
- Step 2: Textual Moment 1 — Stanza 1 vs Stanza 4: The speaker *leaves* the "u”kj" (courtyard/inner space of nostalgia) to become "cl ;gh" (the remnant) in the present. Nostalgia stays; memory-work moves.
- Step 3: Textual Moment 2 — The parents: Father's "I;kj esa cgrs" (aimless walking in the courtyard) is nostalgia's stasis — the past replaying itself without purpose. Mother's unfinished letter is nostalgia's silence. The speaker *breaks* this cycle by writing.
- Step 4: Textual Moment 3 — The vow "rqe cjl yks os u cjlsa / ik¡posa dks os u rjlsa" — this is not "I miss you" (nostalgia) but "I will not let you go" (memory-work as ethical commitment). The verb "cjlsa" (let go) implies active holding.
- Step 5: Synthesize: The poem critiques nostalgia by showing its insufficiency — it cannot feed the father, finish the letter, or sustain the home. Only memory-work (the poem itself) can. The primary theme *is* this critique.

ANSWER:
"The poem structurally enacts a critique of nostalgia by staging the speaker's graduation from its passive chamber ('?kj u”kj esa frj jgk gS') to the active forge of memory-work ('dke djrk gw¡ fd dguk'). Three textual moments prove this:

1. **Spatial Exit (Stanza 1 → Stanza 4):** The opening 'u”kj' (courtyard) is nostalgia's enclosed garden — safe, static, backward-looking. The closing 'cl ;gh gS' (I am the remnant) places the speaker *outside* that garden, in the present, bearing its weight. Nostalgia dwells; memory-work *carries*.

2. **Parental Stasis vs. Speaker's Kinetic Vow (Stanza 3):** The father 'I;kj esa cgrs jgs gSa' (keeps walking in the courtyard) — a perfect image of nostalgia's futile circling. The mother's letter 'mls fy[kuk ugha vkrk' — nostalgia's broken syntax. The speaker responds not with more longing but with 'fy[k jgk gw¡' (I am writing), 'i<+ jgk gw¡' (I am reading). The poem *is* the completed letter, the purposeful walk.

3. **The Anti-Nostalgic Vow (Stanza 4):** 'rqe cjl yks os u cjlsa' uses the causative 'cjlsa' (cause to go/let go) — an act of fierce *retention*, not sweet reminiscence. 'ik¡posa dks os u rjlsa' (won't let memories slip) — 'rjlsa' (let slip) implies vigilance. Nostalgia is soft; this is armor.

The poem's message: Nostalgia is a luxury of those who *have* a home to return to; memory-work is the survival strategy of those who *are* the home. The primary theme is this升华 (sublimation) of longing into legacy."

DIFFICULTY: hard