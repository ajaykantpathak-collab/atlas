## DEFINITION
Literal comprehension questions require answers directly stated in the text, while inferential comprehension questions demand logical reasoning to derive answers implied but not explicitly written, using textual evidence as support.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student can independently classify any question from the chapter as literal or inferential, locate precise textual evidence for literal answers, and construct a logical inference chain (claim + evidence + reasoning) for inferential answers that aligns with the poet's intent.

## SCOPE_BOUNDARY
This node covers only the comprehension questions appended to Dadu's poem in Chapter 9 (Aroh Bhag 1). It does not include critical analysis of themes, literary devices, or creative writing tasks, which are addressed in subsequent nodes.

## WALKTHROUGH
Imagine you are solving a mystery: the text is the crime scene, literal questions are the fingerprints you can see, and inferential questions are the motive you must deduce from those fingerprints. Start by reading the poem aloud to hear its rhythm, then underline every concrete detail (names, actions, objects) — these are your literal anchors. Next, identify the questions that ask "why" or "what does this imply" — these require you to connect two or more literal details using logic. The key insight: every valid inference must be traceable to at least one explicit line in the poem; if you cannot point to the line, the inference is unsupported.

## DIAGNOSTIC_QUESTION_1
What is the defining difference between a literal comprehension question and an inferential comprehension question?

## DIAGNOSTIC_ANSWER_1
A literal question's answer is directly stated in the text (e.g., "What does the poet say about the world?"), while an inferential question requires combining textual clues to reach a conclusion not explicitly written (e.g., "Why does the poet call the world a fleeting spectacle?"). A wrong answer that merely says "literal is easy, inferential is hard" reveals the student confuses difficulty with the actual cognitive process; they have not grasped that inference is evidence-based reasoning, not guessing.

## DIAGNOSTIC_QUESTION_2
In the poem, Dadu says "ge rkS ,d ,d dfj tkaukaA" (We are all travelers on a journey). Is the question "What does the poet compare human life to?" literal or inferential? Explain your reasoning.

## DIAGNOSTIC_ANSWER_2
It is a literal question because the metaphor "dfj tkauka" (travelers on a journey) is explicitly stated in the first line. A student who labels it inferential likely mistakes any figurative language for inference; they need to understand that identifying a directly quoted metaphor is retrieval, not deduction.

## DIAGNOSTIC_QUESTION_3
The poem states: "tSls ck<+h dk"V gh dkVS vfxfu u dkVS dksbZA" (Like a bubble of water, it bursts and is no more). Using this line, answer the inferential question: "What does the bubble imagery suggest about the poet's view of worldly attachments?" Show your evidence-reasoning chain.

## DIAGNOSTIC_ANSWER_3
Evidence: The bubble is fragile, bursts instantly, and leaves nothing behind. Reasoning: The poet equates worldly life (dk"V) to a bubble to convey its impermanence and insubstantiality; therefore, attachments to such a fleeting existence are futile. A wrong answer that says "it means life is beautiful" ignores the bursting action and shows the student is importing personal optimism instead of following the text's logic.

## DIAGNOSTIC_QUESTION_4
Compare the two questions from the textbook: (1) "dchj dh n`f"V esa bZ'oj ,d gSA blosQ leFkZu esa mUgksaus D;k roZQ fn, gSa\" and (2) "ekuo 'kjhj dk fuekZ.k fdu iap rRoksa ls gqvk gS\"? Classify each and justify why the second demands a higher-order reading skill.

## DIAGNOSTIC_ANSWER_4
Question 1 is literal — it asks for the poet's stated description of the world (bZ'oj) and the reasons he gives, which are listed in the poem. Question 2 is inferential — "ekuo 'kjhj" (human suffering) is not a phrase used in the poem; the student must synthesize multiple stanzas (the journey, the bubble, the thorn, the unfulfilled desires) to construct the causes. A student who treats both as literal will simply copy lines for Q2 without synthesizing, missing the analytical demand.

## DIAGNOSTIC_QUESTION_5
A student answers Question 3 ("blosQ vkèkkj ij crkb, fd dchj dh n`f"V esa bZ'oj dk D;k Lo:i gS\") by writing: "The poet says the world is false because it is like a bubble." Evaluate this answer: is it sufficient for an inferential question? Why or why not?

## DIAGNOSTIC_ANSWER_5
The answer is insufficient. It states the metaphor (literal) but does not explain the *Lo:i* (nature/essence) — i.e., *why* the bubble comparison leads to the conclusion of falsity. A complete inferential answer must articulate the logical bridge: the bubble's instantaneous bursting proves the world lacks enduring substance, which is the definition of 'false' in the poet's vocabulary. A student who thinks this is sufficient confuses quoting evidence with explaining its implication.

## DIAGNOSTIC_QUESTION_6
Create a new inferential question based on the last two lines of the poem ("fujHkS Hk;k dNw ufga C;kiS dgS dchj fnokaukaA") that forces the examinee to connect the poet's personal resolve with the broader philosophical message. Provide the ideal answer structure.

## DIAGNOSTIC_ANSWER_6
Question: "Dadu declares he will not abandon his path even if his body perishes. What does this reveal about the relationship between spiritual conviction and mortal existence in his philosophy?" Ideal structure: (1) Claim: Spiritual conviction transcends physical mortality. (2) Evidence: "fujHkS Hk;k dNw ufga C;kiS" (body may perish, but the resolve remains). (3) Reasoning: The poet separates the eternal pursuit (nhokuk) from the temporary vessel, asserting that truth-seeking is not contingent on bodily survival. A poor answer merely paraphrases the line without extracting the philosophical relationship.

## COMMON_MISCONCEPTION
Students often believe inferential questions are answered by "reading between the lines" in a vague, subjective way. They write personal opinions ("I feel the poet is sad") instead of text-bound deductions. This happens because they confuse *inference* (logic from evidence) with *interpretation* (personal response). For example, in Q3 above, a student writes "The bubble shows life is precious because it's short" — the text actually says the opposite (it's false *because* it's short). The error stems from importing external values rather than following the poet's internal logic.

## ON_FAILURE
1. Have the student re-read the poem and highlight every concrete noun and verb (journey, bubble, thorn, body, resolve). 2. For each inferential question, ask: "Which two highlighted words must I connect to answer this?" 3. Practice writing the connection as a because-statement: "The poet says X because the text shows Y and Z." 4. Check: if the because-statement uses a word not in the poem, revise until every term is textually grounded.

## BUILDS_ON
This node builds on the student's ability to identify explicit textual details (literal comprehension) developed in earlier reading nodes.

## LEADS_TO
This node enables critical analysis (c11_hin_ar_cbse_09_013) where inferences become the evidence for thematic interpretation.

## PREREQUISITE_NODE_IDS
c11_hin_ar_cbse_09_001, c11_hin_ar_cbse_09_002, c11_hin_ar_cbse_09_003, c11_hin_ar_cbse_09_008, c11_hin_ar_cbse_09_010, c11_hin_ar_cbse_09_011, c11_hin_ar_cbse_09_009

## PREREQUISITE_REASONS
c11_hin_ar_cbse_09_001: Context about Dadu's life and Bhakti movement clarifies why he uses worldly metaphors for spiritual truths.
c11_hin_ar_cbse_09_002: Understanding the poem's narrative structure (stanza progression) helps locate where literal details appear.
c11_hin_ar_cbse_09_003: The atmosphere of impermanence (setting) is the implicit premise for many inferences.
c11_hin_ar_cbse_09_008: Recognizing imagery (bubble, thorn) is essential to distinguish literal metaphors from inferred meanings.
c11_hin_ar_cbse_09_010: Vocabulary glosses (e.g., nkstx, varfj) prevent misreading key terms in questions.
c11_hin_ar_cbse_09_011: Grammar knowledge (verb forms, case endings) ensures accurate parsing of the Braj Bhasha lines.
c11_hin_ar_cbse_09_009: Comprehension questions require identifying and explaining irony/symbolism in specific lines.  

## FORWARD_NODE_IDS
c11_hin_ar_cbse_09_013, c11_hin_ar_cbse_09_014, c11_hin_ar_cbse_09_015, c12_hin_a_cbse_09_012, c12_hin_ar_cbse_04_012, c12_hin_ar_cbse_09_012

## FORWARD_REASONS
c11_hin_ar_cbse_09_013: Critical thinking requires validated inferences as building blocks for thematic analysis.
c11_hin_ar_cbse_09_014: Writing answers to long questions demands the PEEL structure practiced here (Point, Evidence, Explanation, Link).
c11_hin_ar_cbse_09_015: Discussion points in speaking/listening rely on students defending inferences with textual evidence.
c12_hin_a_cbse_09_012: Same chapter in Class 11 (if covered) provides spiral reinforcement.  
c12_hin_ar_cbse_04_012: अगला तार्किक चरण: Literal comprehension is the ability to extract explicitly stated facts, details, and sequences dire... इस नोड की अवधारणाओं को सीधे उपयोग/विस्तारित करता है।  
c12_hin_ar_cbse_09_012: Direct prior practice with literal/inferential distinction in Class 11 Chapter 9.  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
none

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_09_001 -> c11_hin_ar_cbse_09_012 -> c11_hin_ar_cbse_09_013

## THIS_FORMULA
Inference = Claim + Textual Evidence (1+ explicit lines) + Reasoning (logical link explaining how evidence proves claim)

## FORMULA_VARIABLES
Claim: The conclusion answering the inferential question. Textual Evidence: Direct quote or precise paraphrase from the poem. Reasoning: The logical explanation connecting evidence to claim using the poem's internal logic.

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
analytical

## CROSS_SUBJECT
c11_history_bhakti_movement | The Bhakti poets' use of everyday metaphors (bubble, journey) to convey spiritual truths mirrors Dadu's technique; historical context explains why these images resonated.
c11_philosophy_indian_epistemology | The distinction between pratyaksha (direct perception/literal) and anumana (inference) in Indian logic directly parallels literal vs. inferential comprehension.

## PREREQ_CONCEPT
Ability to distinguish between explicitly stated information and implied meaning in a literary text.

## PREREQ_BEFORE
Student must be able to locate and quote specific lines from the poem that answer factual questions.

## PREREQ_STUCK
If stuck, review the vocabulary gloss (c11_hin_ar_cbse_09_010) and the imagery analysis (c11_hin_ar_cbse_09_008) to ensure each word in the question is understood.

## WORKED_EXAMPLE_1
PROBLEM: Textbook Question 1: "dchj dh n`f"V esa bZ'oj ,d gSA blosQ leFkZu esa mUgksaus D;k roZQ fn, gSa\" (In Dadu's view the world is false. What reasons has he given for this?) Classify the question type and write a structured answer.

STEPS:
- Step 1: Identify question type — "D;k roZQ fn, gSa" asks for reasons explicitly stated; this is a literal comprehension question.
- Step 2: Scan the poem for explicit statements about the world's falsity. Locate stanza 1: "ge rkS ,d ,d dfj tkaukaA" (we are travelers) and stanza 2: "tSls ck<+h dk"V gh dkVS vfxfu u dkVS dksbZA" (like a water bubble it bursts).
- Step 3: List each reason as a separate point using the poet's own imagery: (a) Life is a journey with no permanent abode. (b) Worldly existence is as fragile and momentary as a water bubble. (c) Desires remain unfulfilled ("ek;k nsf[k osQ txr yqHkkauka dkgs js uj xjckaukaA").
- Step 4: Organize into a coherent answer: "Dadu calls the world false because (1) humans are mere travelers passing through, (2) life bursts like a bubble leaving no trace, and (3) worldly desires never reach fulfillment."
- Step 5: Verify each point has a direct line reference; no external interpretation added.

REASONING: Literal questions test retrieval accuracy. The answer must mirror the text's own reasoning without adding inferential leaps. Structuring as a numbered list ensures completeness and clarity for board marking.

ANSWER: Dadu presents three reasons for the world's falsity: (1) Human life is a transient journey (stanza 1). (2) Worldly existence is as fleeting and insubstantial as a water bubble that bursts instantly (stanza 2). (3) Desires rooted in the senses remain perpetually unfulfilled (stanza 2, line 3). These are explicitly stated in the poem.

## WORKED_EXAMPLE_2
PROBLEM: Textbook Question 3: "tSls ck<+h dk"V gh dkVS vfxfu u dkVS dksbZA lc ?kfV varfj rw¡gh O;kid /jS l:iS lksbZAA blosQ vkèkkj ij crkb, fd dchj dh n`f"V esa bZ'oj dk D;k Lo:i gS\" (Like a water bubble... Based on this, explain the nature of the world's falsity in Dadu's view.) Classify and answer using the inference formula.

STEPS:
- Step 1: Classify — "blosQ vkèkkj ij crkb" (explain based on this) signals an inferential question; the answer is not directly given but must be derived from the bubble metaphor.
- Step 2: Extract evidence: "ck<+h dk"V" (water bubble), "dkVS vfxfu u dkVS dksbZA" (bursts and is no more), "lc ?kfV varfj" (momentary existence), "rw¡gh O;kid /jS l:iS lksbZ" (even great beings cannot stabilize it).
- Step 3: Formulate claim: The world's falsity lies in its inherent impermanence and inability to provide lasting stability.
- Step 4: Build reasoning: The bubble metaphor shows the world has no substantial reality — it appears, exists for a moment, and vanishes without residue. Even powerful beings (O;kid) cannot make it permanent, proving its falsity is structural, not accidental.
- Step 5: Write answer using Claim-Evidence-Reasoning: "The falsity of the world (bZ'oj) in Dadu's view is its radical impermanence. The bubble imagery (ck<+h dk"V) demonstrates that worldly existence has no enduring substance — it bursts and disappears completely (dkVS vfxfu u dkVS dksbZA). The poet emphasizes that even great yogis (O;kid) cannot arrest this dissolution, confirming that instability is the world's essential nature (Lo:i)."

REASONING: Inferential questions require the student to articulate the logical bridge between metaphor and meaning. The CER structure ensures the inference is text-bound and logically sound.

ANSWER: The nature of the world's falsity is its radical impermanence and structural instability. Evidence: the bubble metaphor (ck<+h dk"V) and the statement that even great beings cannot stabilize it (rw¡gh O;kid /jS l:iS lksbZ). Reasoning: A bubble has no independent existence; it appears and vanishes in a moment. Similarly, the world offers no lasting foothold — its very essence (Lo:i) is to burst and disappear, making any attachment to it fundamentally false.

## WORKED_EXAMPLE_3
PROBLEM: Textbook Question 4: "dchj us vius dks nhokuk D;ksa dgk gS\" (Why has Dadu called his own path 'nhokuk' — i.e., why does he refuse to abandon his resolve?) This combines literal detail (the word 'nhokuk') with inferential reasoning about the poet's motivation.

STEPS:
- Step 1: Identify the key term — "nhokuk" (from the last line: "fujHkS Hk;k dNw ufga C;kiS dgS dchj fnokaukaA" — body may perish, but Dadu says he will not give up). Note: "nhokuk" means 'to abandon/leave'; the poet says he will *not* do it.
- Step 2: Gather literal supports: (a) The world is false (bZ'oj). (b) The body is mortal (fujHkS Hk;k dNw). (c) The spiritual pursuit is the only enduring reality implied by contrast.
- Step 3: Infer the motivation: Because the world is false and the body perishes, clinging to them is futile; the only meaningful action is to hold fast to the spiritual path (nhokuk = not abandoning the search for truth).
- Step 4: Synthesize: Dadu refuses to abandon his resolve because he recognizes that worldly existence (bubble) and the physical body are transient, while the pursuit of truth is the sole response that transcends this impermanence.
- Step 5: Check against the poem's logic: The progression from world's falsity → body's mortality → unwavering resolve is the poem's argumentative arc.
- Step 6: Draft final answer: "Dadu declares he will not abandon his path (nhokuk) because he sees the world as false (bZ'oj) and the body as mortal (fujHkS Hk;k dNw). Since both are impermanent, the only purposeful stance is to remain steadfast in the spiritual quest, which alone has enduring value."

REASONING: This question blends literal vocabulary (nhokuk) with inference about motivation. The six-step process ensures the student moves from word-level understanding to thematic synthesis, modeling the multi-step reasoning expected in board exams.

ANSWER: Dadu refuses to abandon his resolve because he has realized the world's falsity (bZ'oj) and the body's mortality (fujHkS Hk;k dNw). In a reality where everything perishes like a bubble, the only meaningful action is to hold fast to the spiritual path; abandoning it would be surrendering to the very impermanence he has exposed.

## COMPETENCY_QUESTION_1
QUESTION: A student writes this answer to Question 2: "Human suffering is caused by desire, attachment, and ignorance." The answer is true in general Buddhist philosophy but receives only 1/3 marks in the CBSE marking scheme for this poem. Explain why, using the distinction between literal/inferential comprehension and text-bound inference.

COMPETENCY: Text-bound inferential reasoning — the ability to restrict inferences strictly to the given text's evidence and logic.

STEPS:
- Step 1: Recognize the question asks for causes of "ekuo 'kjhj" (human suffering) *as per Dadu's poem*, not general philosophy.
- Step 2: Locate the poem's explicit causes: the journey metaphor (no permanent rest), the bubble (impermanence), the thorn (pain in worldly life), unfulfilled desires (ek;k nsf[k osQ txr).
- Step 3: Compare student's answer: "desire, attachment, ignorance" — only "desire" appears (as unfulfilled longing); "attachment" and "ignorance" are not in the poem.
- Step 4: Conclude: The answer imports external concepts; board exams reward text-fidelity. A full-mark answer would list the poem's specific images: transient journey, bursting bubble, thorn-like pains, unfulfilled sensory cravings.

ANSWER: The answer loses marks because it substitutes the poem's specific textual evidence (journey, bubble, thorn, unfulfilled desires) with generic philosophical terms (attachment, ignorance) not found in Dadu's verses. CBSE inferential questions require the inference chain to be built exclusively from the given text; external knowledge, even if philosophically congruent, is treated as irrelevant to the comprehension task.

DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: The poem uses two central metaphors: the journey (dfj tkauka) and the bubble (ck<+h dk"V). A board exam question asks: "Compare the function of these two metaphors in establishing the poem's central argument about the world's falsity." Write a response that integrates literal identification, inferential reasoning, and structural analysis.

COMPETENCY: Multi-concept synthesis — combining metaphor analysis, inferential logic, and structural awareness to answer a high-order comparative question.

STEPS:
- Step 1: Identify each metaphor's literal occurrence: journey in stanza 1, bubble in stanza 2.
- Step 2: Infer each metaphor's distinct implication: journey → homelessness, directionlessness, endless movement; bubble → fragility, instantaneous dissolution, zero substance.
- Step 3: Analyze structural progression: stanza 1 presents the human condition (we are travelers); stanza 2 reveals the ontological status of the world itself (it is a bubble). The argument moves from subjective experience to objective nature.
- Step 4: Synthesize: The journey metaphor establishes the *experiential* falsity (we never arrive); the bubble metaphor establishes the *ontological* falsity (the world itself has no staying power). Together they prove the world is false at both levels.
- Step 5: Write integrated answer: "The journey metaphor (stanza 1) portrays the world's falsity as experienced by the individual — a ceaseless wandering without destination. The bubble metaphor (stanza 2) portrays the world's falsity as its intrinsic nature — a momentary appearance that bursts into nothingness. The poem's structure moves from human condition to cosmic reality, jointly demonstrating that the world is false because it offers neither lasting shelter nor substantial existence."

ANSWER: The journey metaphor establishes the experiential dimension of falsity — humans are perpetual travelers never finding a permanent home. The bubble metaphor establishes the ontological dimension — the world itself is a momentary, substanceless appearance that vanishes instantly. Structurally, the poem progresses from the subjective human plight (stanza 1) to the objective nature of reality (stanza 2), together proving the world's falsity is total: it fails both as a dwelling and as a reality.

DIFFICULTY: hard