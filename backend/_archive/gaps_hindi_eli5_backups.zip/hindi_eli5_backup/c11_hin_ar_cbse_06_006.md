## DEFINITION
Primary theme is the central idea or underlying message that the author conveys through the narrative, characters, and conflicts. In "जतू", the primary theme is the critique of corporal punishment in education and the advocacy for a humane, fear-free learning environment.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student must be able to identify the primary theme of the play, support it with at least three textual evidences (plot events, character dialogues, conflicts), and explain how the theme reflects the author's message about education and discipline.

## SCOPE_BOUNDARY
This node covers identifying and analyzing the primary theme of "जतू" with textual evidence. It does not cover secondary themes (node 007), literary devices (nodes 008-009), or comprehension questions (node 012).

## WALKTHROUGH
Imagine you are a student who has just watched a play where a teacher refuses to hit a child despite pressure from the principal and parents. You ask: "Why does the teacher take such a risk?" To find the primary theme, first recall the main conflict (teacher vs. system). Then trace how the conflict resolves and what the protagonist stands for. Notice recurring dialogues about "V~;w'ku" (punishment) and "i<+us" (learning). The key insight: the theme emerges from the protagonist's consistent stance and the play's resolution, showing that true education requires empathy, not fear.

## DIAGNOSTIC_QUESTION_1
What is the definition of 'primary theme' in a literary work?

## DIAGNOSTIC_ANSWER_1
The primary theme is the central idea or message that the author explores throughout the text, often revealed through the main conflict, character choices, and resolution. A wrong answer (e.g., "the summary of the story") reveals confusion between plot and theme.

## DIAGNOSTIC_QUESTION_2
In "जतू", the principal says: "बच्चे दे”क्‍सज नहीं, गक्सफक्रक्ज हैं" (Children are not delicate, they are tough). What does this statement reveal about the principal's belief regarding discipline?

## DIAGNOSTIC_ANSWER_2
The principal believes that physical punishment is necessary and harmless because children can withstand it. A wrong answer (e.g., "the principal cares for children") misses the irony and shows inability to infer character ideology from dialogue.

## DIAGNOSTIC_QUESTION_3
Apply the concept of theme to a new situation: If a story shows a doctor refusing to prescribe unnecessary antibiotics despite patient pressure, what could be the primary theme? Write a one-sentence theme statement.

## DIAGNOSTIC_ANSWER_3
The primary theme could be: "Ethical integrity in profession requires resisting external pressure to uphold long-term well-being." A wrong answer that only describes the plot ("A doctor refuses antibiotics") shows inability to abstract theme from narrative.

## DIAGNOSTIC_QUESTION_4
Analyze how the conflict between जतू and the principal develops the primary theme of the play. Cite two specific incidents.

## DIAGNOSTIC_ANSWER_4
The conflict develops the theme by contrasting two educational philosophies: (1) When the principal insists on punishment for Vfer, जतू refuses, showing her commitment to non-violent discipline. (2) When the principal cites rules, जतू challenges the rule's morality. A wrong answer that only narrates the fight without linking to theme shows lack of analytical skill.

## DIAGNOSTIC_QUESTION_5
Evaluate whether the play's ending (where जतू gets support from the inspector and the rule is changed) strengthens or weakens the primary theme. Justify.

## DIAGNOSTIC_ANSWER_5
The ending strengthens the theme because it validates जतू's stance through systemic change, showing that principled resistance can reform the system. A wrong answer saying "it weakens because it's unrealistic" ignores the author's intent to inspire hope.

## DIAGNOSTIC_QUESTION_6
Create a new scene (5-6 lines of dialogue) for "जतू" where the theme of fear-free education is highlighted through a conversation between जतू and a parent who initially demanded punishment.

## DIAGNOSTIC_ANSWER_6
A good answer will have dialogue showing the parent's change of heart, referencing the child's improved learning without fear. A poor answer will have the parent still demanding punishment, missing the theme.

## COMMON_MISCONCEPTION
Students often think the primary theme is simply "corporal punishment is bad." This is a topic, not a theme. A theme is a complete statement about the topic, e.g., "Corporal punishment undermines true learning because it replaces understanding with fear." Students make this error because they confuse subject with theme statement.

## ON_FAILURE
If a student gives a topic instead of a theme statement, guide them: (1) Identify the topic (corporal punishment). (2) Ask: "What does the play say about this topic?" (3) Formulate a sentence with a verb showing the author's perspective. (4) Test it against the text: does the play support this?

## BUILDS_ON
This node builds on the understanding of plot (node 002) and character analysis of the protagonist (node 004) and supporting characters (node 005).

## LEADS_TO
This node enables analysis of secondary themes (node 007), literary devices that reinforce theme (nodes 008-009), and critical thinking questions (node 013).

## PREREQUISITE_NODE_IDS
c11_hin_ar_cbse_06_001, c11_hin_ar_cbse_06_002, c11_hin_ar_cbse_06_003, c11_hin_ar_cbse_06_004, c11_hin_ar_cbse_06_005
## PREREQUISITE_REASONS
c11_hin_ar_cbse_06_001: Provides background on the author and the educational context necessary to understand the theme's relevance.
c11_hin_ar_cbse_06_002: The plot structure reveals the central conflict that embodies the theme.
c11_hin_ar_cbse_06_003: The setting (school office, staff room) creates the atmosphere of institutional pressure.
c11_hin_ar_cbse_06_004: जतू's character traits (principled, empathetic) directly express the theme.
c11_hin_ar_cbse_06_005: Supporting characters (principal, Vfer, parents) represent opposing viewpoints that highlight the theme.

## FORWARD_NODE_IDS
c11_hin_ar_cbse_06_007, c11_hin_ar_cbse_06_008, c11_hin_ar_cbse_06_009, c11_hin_ar_cbse_06_010, c11_hin_ar_cbse_06_011, c11_hin_ar_cbse_06_012, c11_hin_ar_cbse_06_013, c11_hin_ar_cbse_06_014, c11_hin_ar_cbse_06_015, c12_hin_ar_cbse_06_006, c12_hin_ar_cbse_12_006, c12_hin_ar_cbse_13_006

## FORWARD_REASONS
c11_hin_ar_cbse_06_007: Secondary themes (e.g., gender bias, systemic inertia) branch from the primary theme.
c11_hin_ar_cbse_06_008: Imagery and metaphor (e.g., "फरयक" as fear) deepen the primary theme.
c11_hin_ar_cbse_06_009: Irony (principal's "discipline" vs. actual education) and symbolism (the rulebook) serve the theme.
c11_hin_ar_cbse_06_010: Key vocabulary (V~;w'ku, i<+us, fu;e) carries thematic weight.
c11_hin_ar_cbse_06_011: Language usage (formal vs. colloquial) reflects power dynamics central to theme.
c11_hin_ar_cbse_06_012: Comprehension questions often ask for theme identification.
c11_hin_ar_cbse_06_013: Critical thinking requires evaluating the theme's relevance today.
c11_hin_ar_cbse_06_014: Writing tasks (e.g., article on corporal punishment) use the theme as thesis.
c11_hin_ar_cbse_06_015: Discussion points debate the theme's application in modern schools.
c12_hin_ar_cbse_06_006: Class 11 foundation on identifying primary theme vs. moral in poetry.  
c12_hin_ar_cbse_12_006: Develops skill of using textual evidence for thematic claims.  
c12_hin_ar_cbse_13_006: s Sikh peasant loyalty by framing it as religious duty, severing the soldier from his roots." (From c11_hin_ar_cbse_06_006).  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
none

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_06_002 -> c11_hin_ar_cbse_06_006 -> c11_hin_ar_cbse_06_007

## THIS_FORMULA
Theme = Central Conflict + Protagonist's Stance + Resolution's Implication

## FORMULA_VARIABLES
Central Conflict: The main struggle (here, teacher vs. system on punishment). Protagonist's Stance: The consistent position taken by the main character (जतू's refusal). Resolution's Implication: What the outcome suggests about the author's message (rule change validates her).

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
analytical

## CROSS_SUBJECT
c11_history_education_reforms | The play reflects historical debates on colonial vs. indigenous education methods and corporal punishment in Indian schools.
c11_civics_child_rights | The theme connects to the Right to Education Act and laws banning corporal punishment, illustrating civic awareness.

## PREREQ_CONCEPT
Understanding that theme is not the plot but the author's comment on a universal human experience, derived from recurring patterns in the narrative.

## PREREQ_BEFORE
Student must be able to summarize the plot and describe the protagonist's key decisions.

## PREREQ_STUCK
If stuck, review the protagonist's three major confrontations (with principal, with parent, with inspector) and note what she says each time.

## WORKED_EXAMPLE_1
PROBLEM: Identify the primary theme of "जतू" using the formula: Theme = Central Conflict + Protagonist's Stance + Resolution's Implication.
STEPS:
- Step 1: Identify the central conflict: जतू refuses to give corporal punishment to Vfer despite the principal's orders and parental pressure.
- Step 2: Determine the protagonist's stance: जतू consistently argues that punishment creates fear, not learning, and that education should be based on love and understanding.
- Step 3: Analyze the resolution: The inspector supports जतू, the rule is changed to ban punishment in that school, and the principal is forced to accept.
- Step 4: Combine: The conflict is about disciplinary methods; the stance is anti-punishment; the resolution validates the stance. Therefore, the theme is: "A fear-free, empathetic approach to education is more effective and morally superior to corporal punishment, and principled resistance can bring systemic change."
- Step 5: Verify with text: Check that the play shows Vfer learning better without punishment (e.g., his improved scores), and that the system changes.
REASONING: This step-by-step method ensures the theme is grounded in textual evidence, not just a moral platitude.
ANSWER: The primary theme of "जतू" is that true education flourishes in an environment free from fear and physical punishment, and a teacher's moral courage can challenge and change oppressive systems.

## WORKED_EXAMPLE_2
PROBLEM: A student writes: "The theme of 'जतू' is that teachers should not beat students." Improve this statement to a senior-secondary level theme statement.
STEPS:
- Step 1: Recognize the student's statement is a topic-based moral, not a theme statement.
- Step 2: Identify the missing elements: the 'why' (reason) and the broader implication (systemic change, educational philosophy).
- Step 3: Add the reason: beating creates fear which hinders learning.
- Step 4: Add the broader implication: the play shows that systemic change is possible when individuals stand on principle.
- Step 5: Synthesize: "The play 'जतू' demonstrates that corporal punishment is counterproductive to genuine learning because it substitutes fear for understanding, and it celebrates the power of individual integrity to reform an unjust educational system."
REASONING: A strong theme statement includes the author's perspective on the topic and the narrative's resolution.
ANSWER: Improved theme statement: "The play 'जतू' demonstrates that corporal punishment is counterproductive to genuine learning because it substitutes fear for understanding, and it celebrates the power of individual integrity to reform an unjust educational system."

## WORKED_EXAMPLE_3
PROBLEM: Compare the primary theme of "जतू" with the theme of another story you have studied where a protagonist resists an unjust system (e.g., "The Letter" by Dhumketu or "The Last Lesson" by Alphonse Daudet). Write a comparative analysis in 100 words.
STEPS:
- Step 1: Recall the primary theme of "जतू" (as derived in Example 1).
- Step 2: Identify the other story's theme (e.g., "The Last Lesson": linguistic identity and regret for neglected education).
- Step 3: Find common ground: both deal with education system and individual vs. system.
- Step 4: Contrast: "जतू" focuses on disciplinary method and active resistance leading to change; "The Last Lesson" focuses on cultural loss and passive realization.
- Step 5: Analyze how each author uses the protagonist's journey to convey the theme.
- Step 6: Write a concise comparative paragraph linking both.
REASONING: Comparing themes across texts deepens understanding of how different authors handle similar conflicts.
ANSWER: Both "जतू" and "The Last Lesson" critique educational systems, but "जतू" presents active resistance against corporal punishment leading to systemic reform, while "The Last Lesson" portrays passive regret over lost linguistic heritage. जतू's victory is institutional; M. Hamel's is moral. Both affirm that education's true value transcends mere instruction.

## COMPETENCY_QUESTION_1
QUESTION: The play "जतू" ends with the inspector ordering a new rule: "No teacher shall inflict corporal punishment." Some critics argue this ending is too idealistic and undermines the realism of the play. Do you agree? Support your answer with two arguments from the text.
COMPETENCY: Critical evaluation of textual resolution in relation to theme.
STEPS:
- Step 1: State your position (agree/disagree).
- Step 2: Argument 1: The inspector's intervention is foreshadowed by जतू's earlier mention of higher authorities, making it plausible.
- Step 3: Argument 2: The play is a 'problem play' meant to propose solutions, not just depict reality; the idealistic ending serves the didactic purpose.
- Step 4: Conclude how this affects the theme: it reinforces the message that change is possible.
ANSWER: I disagree that the ending undermines realism. First, the inspector's arrival is prepared by जतू's reference to "उच्च अधिकारियों" (higher authorities), making it a logical narrative development. Second, as a social drama, the play aims to inspire reform; the idealistic resolution strengthens the theme that principled resistance can transform systems, which is the author's message.
DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: In the play, जतू says: "शिक्षा का उद्देश्य भय पैदा करना नहीं, समझ विकसित करना है।" (The aim of education is not to create fear but to develop understanding.) Using this quote as a lens, analyze how three different characters (जतू, प्रिंसिपल, वफर) embody or contradict this idea. What does this reveal about the play's primary theme?
COMPETENCY: Multi-character thematic analysis with textual evidence.
STEPS:
- Step 1: Break down the quote into two parts: anti-fear, pro-understanding.
- Step 2: Analyze जतू: she embodies both by refusing punishment and using dialogue to teach.
- Step 3: Analyze प्रिंसिपल: he contradicts by equating discipline with fear/punishment.
- Step 4: Analyze वफर: he initially fears punishment but thrives when taught with understanding (his scores improve).
- Step 5: Synthesize: The contrast among characters structures the theme, showing the practical failure of fear-based methods and the success of understanding-based methods.
ANSWER: जतू embodies the quote by replacing punishment with conversation, leading to वफर's academic improvement. The principal contradicts it, believing "बच्चे दे”क्‍सज नहीं" and that rules require punishment. वफर's arc—from fearful student to confident learner—proves the quote's validity. This triangulation reveals the primary theme: education rooted in empathy and reason outperforms fear-based authority, and the system must align with this truth.
DIFFICULTY: hard