## DEFINITION
Supporting characters in a poem are the distinct personas, roles, or voices adopted by the poetic speaker to embody different facets of the central subject. In "यह नारी वोश्यक," the woman is not a single static figure but appears through a sequence of symbolic identities — क्षत्राणी (warrior), एकल नारी (solitary woman), वफादार पत्नी (faithful wife), माता (mother), निशा (night), and प्रकाश (light) — each functioning as a "supporting character" that reveals a layer of her composite identity.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student can independently identify each symbolic role in the poem, cite the specific stanza and imagery that constructs it, explain how the refrain "यह नारी वोश्यक... इज्जत इसे भी दो नारी को" frames each role, and articulate how the accumulation of these roles builds the poem's central argument about the dignity of womanhood.

## SCOPE_BOUNDARY
This node covers the six symbolic roles (क्षत्राणी, एकल नारी, वफादार पत्नी, माता, निशा, प्रकाश) in Varjk's poem "यह नारी वोश्यक" as supporting personas. It does NOT cover the protagonist analysis (the poet's narrative voice), other poems in the chapter, or biographical details of the poet beyond what illuminates the text.

## WALKTHROUGH
Imagine you are directing a play where one actress must portray six different women without changing costume — only her posture, voice, and a single prop shift each time. That is exactly what Varjk does in this poem: the refrain "यह नारी वोश्यक" is the spotlight, and each stanza introduces a new "character" through a metaphor. Begin by reading the poem aloud twice — first for rhythm, then to mark every stanza that introduces a new image (क्षत्राणी, एकल, वफादार, माता, निशा, प्रकाश). Ask: "What specific action or object defines this role?" (e.g., क्षत्राणी = तलवार/रणभेरी; माता = आँचल/दूध). The key insight is that the refrain does not merely repeat — it accumulates authority, demanding respect for *each* role, not just the idealized one.

## DIAGNOSTIC_QUESTION_1
Identify the six symbolic roles (supporting characters) of the woman presented in the poem "यह नारी वोश्यक" and the stanza number where each first appears.

## DIAGNOSTIC_ANSWER_1
The six roles are: 1) क्षत्राणी (warrior woman) — Stanza 2 ("क्षत्राणी यह..."), 2) एकल नारी (solitary woman) — Stanza 2 ("एकल यह..."), 3) वफादार पत्नी (faithful wife) — Stanza 3 ("यह वफादार यह..."), 4) माता (mother) — Stanza 3 ("यह माता यह..."), 5) निशा (night) — Stanza 4 ("यह निशा यह..."), 6) प्रकाश (light) — Stanza 4 ("यह प्रकाश यह..."). A wrong answer that lists only "woman" or "nari" reveals the student has not grasped that the poem *constructs* womanhood through distinct, named personas rather than describing a single generic figure.

## DIAGNOSTIC_QUESTION_2
Explain in your own words why the poet uses the refrain "यह नारी वोश्यक... इज्जत इसे भी दो नारी को" after *each* new role instead of only once at the end.

## DIAGNOSTIC_ANSWER_2
The refrain acts as a rhetorical hammer: each repetition forces the reader to grant dignity to *that specific role* before moving to the next. If placed only at the end, the demand for respect would apply to an abstract "woman"; by repeating it, the poet insists that the warrior, the solitary woman, the wife, the mother, the night, and the light *each* deserve individual recognition. A wrong answer that says "for emphasis" or "poetic structure" misses the argumentative function — the refrain is the poem's thesis restated as a demand after every piece of evidence.

## DIAGNOSTIC_QUESTION_3
In Stanza 3, the lines "यह वफादार यह... / यह माता यह..." present two roles. Choose ONE and write a 3-sentence PEEL paragraph (Point, Evidence, Explanation, Link) analyzing how the imagery constructs that role.

## DIAGNOSTIC_ANSWER_3
Example for माता: **Point:** The mother is portrayed as the sustainer of life through self-effacing nurture. **Evidence:** The lines "अपने आँचल का दूध पिलाकर / बड़ा करती है" use the metonymy of आँचल (veil) for motherhood and the verb पिलाकर (feeds) to show active, physical labor. **Explanation:** Unlike the warrior's sword or the wife's loyalty, the mother's power is invisible, repetitive, and biological — yet the poem equates it with the others by the refrain. **Link:** This forces the reader to respect domestic labor as equally "वश्यक" (worthy of respect) as public valor. A weak answer would merely translate the lines without analyzing *how* the imagery (आँचल, दूध, बड़ा करती) builds the role.

## DIAGNOSTIC_QUESTION_4
Compare the imagery of "निशा" (night) in Stanza 4 with "क्षत्राणी" (warrior) in Stanza 2. What opposing qualities do they represent, and why does the poem place them in the *same* woman?

## DIAGNOSTIC_ANSWER_4
क्षत्राणी is associated with "तलवार" (sword), "रणभेरी" (war drum), "अग्नि" (fire) — active, public, aggressive, visible power. निशा is "अंधकार" (darkness), "नींद" (sleep), "सपने" (dreams) — passive, private, receptive, invisible. The poem places them together to shatter the binary that a woman is *either* strong *or* soft; she embodies both the capacity for battle and the necessity of rest/regeneration. A wrong answer that calls them "opposites" without explaining the *synthesis* (the poem demands respect for *both* in one being) misses the feminist argument: womanhood is not a single role but a containment of contradictions.

## DIAGNOSTIC_QUESTION_5
Evaluate the criticism: "The poem reduces women to biological and social roles (mother, wife, night) and fails to represent the modern, independent woman." Defend or refute using textual evidence.

## DIAGNOSTIC_ANSWER_5
Refute. The poem *includes* traditional roles but revalues them: the "एकल नारी" (solitary woman) stands alone, "अपने पैरों पर खड़ी" (standing on her own feet), explicitly independent. The "क्षत्राणी" wields a sword in the public sphere (रणभेरी). The refrain "इज्जत इसे भी दो" demands respect *for each role on its own terms*, not because they serve men. The poem's strategy is to legitimize *all* ways women exist — including the modern independent one (एकल) — by forcing the patriarchal gaze to honor each. A wrong answer that agrees with the criticism ignores the "एकल" stanza and misreads the refrain as endorsement of tradition rather than a demand for dignity *within* tradition.

## DIAGNOSTIC_QUESTION_6
Write a seventh stanza for the poem introducing a contemporary role of women (e.g., scientist, athlete, CEO) that maintains the poem's refrain, rhythm, and metaphorical density. Use Hindi.

## DIAGNOSTIC_ANSWER_6
Example:
यह वैज्ञानिक यह
गणित के सूत्रों में
ब्रह्मांड की गूँज सुनती
अणु-परमाणु को नचाती
सत्य की खोज में
रात-दिन एक करती
यह नारी वोश्यक
लुसग है, ओज है, एनेर्रक है
इज्जत इसे भी दो नारी को।
A poor answer would write a slogan ("नारी शक्ति जिंदाबाद") without metaphor (no imagery of lab, equations, universe), breaking the poem's pattern of concrete symbol (तलवार, आँचल, अंधकार, प्रकाश).

## COMMON_MISCONCEPTION
Students treat the poem as a *list* of separate women ("one woman is a warrior, another is a mother") rather than a *layered portrait of one woman* who simultaneously contains all these identities. They write: "The poet describes different types of women" — missing that the refrain "यह नारी" (this woman, singular) and the final synthesis "यह वफादार यह माता... यह निशा यह प्रकाश" (Stanza 4) grammatically bind all roles to a single subject. This error stems from reading each stanza in isolation instead of tracking the accumulating subject "यह नारी" across the whole poem.

## ON_FAILURE
1. Have the student read the poem aloud *only* the lines beginning with "यह नारी" (the refrain) to hear the accumulating insistence. 2. Give a two-column worksheet: Column A = Role (क्षत्राणी, एकल, etc.), Column B = Key Image (तलवार, पैर, आँचल, अंधकार, प्रकाश). Student fills Column B by scanning the poem — this forces stanza-by-stanza evidence gathering. 3. Ask: "If this poem were a film, would the same actress play all six roles or six different actresses?" The answer (same actress) unlocks the singular subject. 4. Re-attempt Diagnostic Question 4 to verify synthesis understanding.

## BUILDS_ON
Character Analysis: Protagonist (c12_hin_a_cbse_03_004) — the protagonist node established the poet's narrative voice; this node extends that by analyzing the voices *within* the poem.

## LEADS_TO
Theme: Primary Theme and Message (c12_hin_a_cbse_03_006) — the accumulation of roles directly constructs the theme of multifaceted dignity.

## PREREQUISITE_NODE_IDS
c12_hin_a_cbse_03_004, c11_hin_ar_cbse_01_005, c12_hin_a_cbse_03_002
## PREREQUISITE_REASONS
c12_hin_a_cbse_03_004: Understanding the poet's narrative voice (protagonist) is necessary to distinguish it from the symbolic voices (supporting characters) within the poem.
c11_hin_ar_cbse_01_005: Class 11 introduced the framework of analyzing supporting characters in prose/poetry; this node applies it at a higher symbolic density.
c12_hin_a_cbse_03_002: Plot and Narrative Structure established the poem's stanzaic progression, which this node uses to sequence the roles.
## FORWARD_NODE_IDS
c12_hin_a_cbse_03_006, c12_hin_a_cbse_03_013, c12_hin_a_cbse_03_014, c12_hin_a_cbse_03_008, c12_hin_a_cbse_03_012

## FORWARD_REASONS
c12_hin_a_cbse_03_006: The six roles and their collective demand for respect are the textual evidence for the primary theme (dignity of womanhood in all its forms).
c12_hin_a_cbse_03_013: Critical Thinking requires synthesizing the roles into an interpretive argument (e.g., "Does the poem essentialize or liberate?").
c12_hin_a_cbse_03_014: Writing Skills tasks (analytical paragraph, essay) will directly use the PEEL structure practiced here.
c12_hin_a_cbse_03_008: Supporting characters (society, "लोग", "वायु") appear as metaphorical forces (wind that strips colour).  
c12_hin_a_cbse_03_012: Supporting characters expand inferential base  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
c12_history_women_indian_nationalism: The poem's "क्षत्राणी" and "एकल नारी" echo historical figures (Rani Lakshmibai, Pandita Ramabai) and the nationalist discourse on women's roles — connecting literary symbol to historical agency.
c12_sociology_gender_socialization: The poem enacts the sociological concept of "multiple role burden" and "role conflict" — the woman as warrior, mother, night, light — making it a literary case study for gender role analysis.

## CHAIN_DESCRIPTION
c12_hin_a_cbse_03_004 -> c12_hin_a_cbse_03_005 -> c12_hin_a_cbse_03_006

## THIS_FORMULA
N/A - conceptual

## FORMULA_VARIABLES
N/A

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
analytical

## CROSS_SUBJECT
N/A | The poem's warrior woman (क्षत्राणी) and solitary woman (एकल नारी) mirror the dual historiography of women in nationalism: as martial icons and as autonomous reformers.
 N/A | The six roles operationalize the sociological framework of "role set" — a single status (woman) requiring enactment of multiple, often contradictory, roles (warrior vs. nurturer, public vs. private).
## PREREQ_CONCEPT
Ability to distinguish between a poem's speaker (protagonist) and the personas it deploys (supporting characters), and to read metaphor as character construction.

## PREREQ_BEFORE
Student must be able to identify the speaker of a poem, recognize a refrain, and explain how a concrete image (e.g., तलवार, आँचल) functions as a symbol for an abstract quality.

## PREREQ_STUCK
If stuck, revisit c12_hin_a_cbse_03_004 (Protagonist) for speaker analysis and c12_hin_a_cbse_03_008 (Imagery and Metaphor) for symbol-decoding practice.

## WORKED_EXAMPLE_1
PROBLEM: Analyze how the role of "क्षत्राणी" (warrior woman) is constructed in Stanza 2 and what specific demand for respect it makes.
STEPS:
- Step 1: Locate the stanza — "क्षत्राणी यह / तलवार उठाये / रणभेरी बजाये / अग्नि सी धधकती / यह नारी वोश्यक..."
- Step 2: Identify the central metaphor — "अग्नि सी धधकती" (burning like fire) compares the woman's energy to an uncontrolled, destructive-creative force.
- Step 3: List the concrete actions — "तलवार उठाये" (wields sword), "रणभेरी बजाये" (beats war drum) — these are traditionally male, public, martial acts.
- Step 4: Connect to the refrain — the immediate follow-up "इज्जत इसे भी दो नारी को" demands that this *martial* woman be honored, not domesticated.
- Step 5: Interpret the significance — the poem refuses to confine womanhood to the private sphere; the warrior is a legitimate, respectable identity.
REASONING: The stanza uses the "weapon + fire" cluster to build a character defined by agency and public power. The refrain then converts that character portrait into a political demand. This pattern (image cluster → character → demand) repeats for all six roles.
ANSWER: The क्षत्राणी is constructed through martial imagery (तलवार, रणभेरी) and the fire metaphor to represent women's legitimate claim to public power and aggression. The refrain demands society grant this identity the same respect given to male warriors.

## WORKED_EXAMPLE_2
PROBLEM: The poem pairs "निशा" (night) and "प्रकाश" (light) in the final stanza. Explain how this pairing resolves the tension between the earlier roles.
STEPS:
- Step 1: Recall earlier roles — क्षत्राणी (active/public), एकल (independent), वफादार (relational), माता (nurturing). These pull in different directions.
- Step 2: Analyze निशा imagery — "अंधकार में / सपने बोती" (sows dreams in darkness) → passive, interior, generative, hidden labor.
- Step 3: Analyze प्रकाश imagery — "किरणें बिखेरती / पथ दिखाती" (scatters rays, shows path) → active, exterior, guiding, visible labor.
- Step 4: Observe the grammatical merger — "यह निशा यह प्रकाश" (this night this light) joined by "यह... यह" (this... this) equating them as simultaneous attributes of the *same* "नारी".
- Step 5: Synthesize — Night and light are not opposites to be chosen between; they are phases of the same cycle. The woman *contains* the cycle. The poem resolves role conflict by making containment the definition of womanhood.
REASONING: The final stanza moves from social roles (warrior, wife, mother) to cosmic principles (night, light), universalizing the argument. The pairing shows that the "supporting characters" are not alternatives but simultaneous dimensions.
ANSWER: The निशा-प्रकाश pairing resolves the poem's tension by reframing all previous roles as phases of a single cyclical reality — the woman is both the hidden gestation (night) and the visible guidance (light), making the demand for respect absolute and unconditional.

## WORKED_EXAMPLE_3
PROBLEM: A board exam question asks: "How does the poet use the refrain to structure the poem's argument? Answer in 80-100 words." Write a model answer using the PEEL structure across the whole poem.
STEPS:
- Step 1: Point — The refrain "यह नारी वोश्यक... इज्जत इसे भी दो नारी को" is the poem's structural spine, converting each stanza's portrait into a cumulative demand.
- Step 2: Evidence 1 (Stanza 2) — After क्षत्राणी and एकल portraits, the refrain demands respect for female aggression and autonomy.
- Step 3: Evidence 2 (Stanza 3) — After वफादार and माता portraits, it demands respect for relational and reproductive labor.
- Step 4: Evidence 3 (Stanza 4) — After निशा and प्रकाश, it demands respect for the cosmic totality of womanhood.
- Step 5: Explanation — The repetition is not decorative; it performs the argument: *each* role, *each* stanza, *each* woman deserves dignity. The "भी" (also) accumulates: respect for this *and* this *and* this.
- Step 6: Link — Thus the refrain transforms a descriptive poem into a feminist manifesto, making structure = argument.
REASONING: Board exams reward answers that connect form (refrain repetition) to meaning (cumulative demand). The PEEL structure across multiple stanzas demonstrates the "analytical" competency.
ANSWER: The refrain acts as the poem's argumentative engine. After each symbolic portrait — warrior (Stanza 2), solitary woman (Stanza 2), faithful wife (Stanza 3), mother (Stanza 3), night (Stanza 4), light (Stanza 4) — the line "इज्जत इसे भी दो नारी को" converts description into demand. The particle "भी" (also) accumulates: respect is due not to an idealized woman but to *each* concrete manifestation. By repeating the demand six times, the structure enacts the poem's thesis: womanhood is a constellation of roles, each independently worthy of dignity. The refrain thus makes poetic form identical to political content.

## COMPETENCY_QUESTION_1
QUESTION: Read the following lines from a hypothetical eighth stanza written in Varjk's style:
"यह कवि यह / शब्दों को गढ़ती / मौन को तोड़ती / सत्य की तलवार लिए / यह नारी वोश्यक / लुसग है, ओज है, एनेर्रक है / इज्जत इसे भी दो नारी को।"
Identify the new role introduced, the central metaphor, and explain how this role both continues and extends the poem's existing pattern of roles.
COMPETENCY: Literary Analysis - Pattern Recognition and Extension
STEPS:
- Step 1: Identify the role — "कवि" (poet/writer) from "यह कवि यह / शब्दों को गढ़ती".
- Step 2: Identify the metaphor — "सत्य की तलवार" (sword of truth) links writing to the warrior's sword (Stanza 2) but shifts the battlefield to language.
- Step 3: Map to existing pattern — Like क्षत्राणी, she wields a तलवार; like एकल, she breaks silence ("मौन को तोड़ती"); like प्रकाश, she illuminates ("सत्य").
- Step 4: Explain the extension — This role moves womanhood into the *intellectual/creative* public sphere, claiming authority over narrative itself — the ultimate extension of "इज्जत इसे भी दो".
ANSWER: The new role is the Woman as Poet/Truth-teller. The central metaphor is the "सत्य की तलवार" (sword of truth), transforming the warrior's physical weapon into an intellectual one. It continues the pattern by echoing क्षत्राणी's sword, एकल's autonomy, and प्रकाश's illumination, but extends it by claiming the power to *define* womanhood through language — making the poet the architect of the very respect the poem demands.
DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: Assertion (A): The poem "यह नारी वोश्यक" essentializes women by defining them only through biological and relational roles (mother, wife, night).
Reason (R): The poem's structure — six distinct roles framed by a single refrain — presents womanhood as a fixed set of archetypes rather than a fluid identity.
Choose the correct option:
(a) Both A and R are true and R correctly explains A.
(b) Both A and R are true but R does not explain A.
(c) A is true but R is false.
(d) A is false but R is true.
Justify your choice with textual evidence.
COMPETENCY: Critical Evaluation - Assertion Reasoning with Textual Evidence
STEPS:
- Step 1: Test Assertion (A) — Does the poem define women *only* through biology/relations? No: "क्षत्राणी" (warrior) and "एकल" (solitary/independent) are neither biological nor relational; they are agentic, public roles. So A is FALSE.
- Step 2: Test Reason (R) — Does the structure present a *fixed* set? The refrain's "भी" (also) and the final cosmic pairing (निशा/प्रकाश) suggest openness — the list is illustrative, not exhaustive. The hypothetical 7th stanza (Competency Q1) proves extensibility. So R is FALSE.
- Step 3: Since both are false, but option (d) says "A is false but R is true" — that's incorrect. Wait, the options don't have "both false". Re-read: (d) A is false but R is true. But we found R false. So N/A match? Actually, standard AR questions have four options covering all combos. Here (d) is the closest if R were true. But R is false. Let's adjust: The correct answer is that A is false (poem includes non-biological roles) and R is false (structure is additive, not fixed). Since that combo isn't listed, the question must be designed so that R is *true* in a specific reading? Let's re-evaluate R: "presents womanhood as a fixed set of archetypes" — the poem *does* present six fixed archetypes in the text. But the *refrain's logic* resists fixation. For exam purposes, students often misread the list as fixed. The *correct* evaluation: A is false (text contradicts), R is false (structure is additive). But since the options don't include "both false", we must choose the *best* fit. Actually, in CBSE AR questions, sometimes the options are: (a) Both true, R explains A; (b) Both true, R doesn't explain; (c) A true, R false; (d) A false, R true. If both are false, the question is flawed. Let's change R to make it true: "The poem's structure uses a repetitive refrain to demand respect for each role individually." That would be true. But we must work with given R. Let's redesign the question to have a valid answer.
REVISED QUESTION:
Assertion (A): The poem reduces women to traditional roles.
Reason (R): The poem includes the roles of mother and wife which are traditional.
Options: (a) Both true, R explains A. (b) Both true, R doesn't explain. (c) A true, R false. (d) A false, R true.
Now: A is false (poem includes warrior, solitary). R is true (poem *does* include mother/wife). So (d) A false, R true. Justification: The poem *includes* traditional roles (R true) but does not *reduce* women to them because it equally valorizes non-traditional roles like warrior and solitary woman (A false).
ANSWER: (d) A is false but R is true. Justification: The poem *does* depict mother and wife (supporting R), but it *also* depicts the warrior (क्षत्राणी) and the solitary independent woman (एकल) who stands "on her own feet" — therefore it does not *reduce* women to traditional roles (refuting A). The presence of traditional roles alongside radical ones shows expansion, not reduction.
DIFFICULTY: hard