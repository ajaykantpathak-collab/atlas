## DEFINITION
Literal comprehension questions require students to locate and retrieve explicitly stated information from the text (facts, details, sequences, definitions). Inferential comprehension questions require students to derive implied meaning by combining textual evidence with logical reasoning — reading between the lines to understand character motives, thematic implications, or authorial intent that are not directly stated.

## COGNITIVE_LEVEL
understand

## MASTERY_CRITERIA
The student can independently classify any comprehension question as literal or inferential, answer literal questions by quoting or paraphrasing exact textual evidence with location references (paragraph/line), and answer inferential questions by stating a clear claim, citing at least two pieces of textual evidence, and explaining the logical bridge connecting evidence to inference.

## SCOPE_BOUNDARY
This node covers strategies for answering literal and inferential questions specifically for the prose chapter "लाफ़नक" (iQ.kh'ojukFk ^js.kq*). It does NOT cover critical analysis/evaluation (node c12_hin_a_cbse_12_013), creative writing (node c12_hin_a_cbse_12_014), or speaking/listening (node c12_hin_a_cbse_12_015). It focuses exclusively on the comprehension question types appearing in CBSE Class 12 Hindi Core/ Elective board exams and CUET language section.

## WALKTHROUGH
Imagine you are sitting in the exam hall, reading the unseen passage or the textbook extract from "लाफ़नक". You see a question: "लाफ़नक की बूढ़ी माँ ने गजाधर को क्या करने को कहा?" — you can point to the exact line. But the next question asks: "लाफ़नक की बूढ़ी माँ ने गजाधर से भोजन क्यों नहीं किया?" — the text never says "because..." explicitly. This is where most students freeze: they either guess wildly or write a literal answer for an inferential question. The key is to first **tag the question type** (L or I). For Literal: scan for keywords (names, verbs, numbers), copy/paraphrase the exact sentence. For Inferential: hunt for **clues** (dialogue, actions, descriptions, repetitions), then build a **claim + evidence + reasoning** chain. The insight: every valid inference must be *grounded* in the text — if you cannot underline the sentences that led you there, the inference is unsupported.

## DIAGNOSTIC_QUESTION_1
**Question:** Define the difference between a literal comprehension question and an inferential comprehension question in your own words. Give one example of each type based on the story "लाफ़नक".

## DIAGNOSTIC_ANSWER_1
**Correct Answer:** A literal question asks for information directly stated in the text (e.g., "गजाधर ने लाफ़नक को क्या दिया?" — answer: "जनेऊ और पैसे", explicitly mentioned). An inferential question asks for meaning derived from clues (e.g., "लाफ़नक ने गजाधर का जनेऊ क्यों स्वीकार किया?" — answer requires inferring her emotional state from her actions: "क्योंकि वह गजाधर को अपना बेटा मानने लगी थी, जिसका प्रमाण उसके द्वारा 'बेटा' संबोधन और रोना है").  
**What a wrong answer reveals:** If the student gives two literal questions or two inferential questions, they cannot distinguish the cognitive demand. If the inferential example is answered with a direct quote, they treat inference as retrieval. If the literal example requires reasoning, they overcomplicate explicit facts.

## DIAGNOSTIC_QUESTION_2
**Question:** Read this question: "गजाधर ने लाफ़नक की बात क्यों नहीं मानी और गाँव छोड़कर चला गया?" Is this literal or inferential? Explain *why* by referring to the text structure — what would a literal version of this question look like?

## DIAGNOSTIC_ANSWER_2
**Correct Answer:** This is an **inferential** question. The text describes Gajadhar's actions (leaving, not listening) but never explicitly states his *reason* (e.g., "क्योंकि वह बूढ़ी माँ का भार नहीं उठाना चाहता था" or "क्योंकि उसे शहर में नौकरी मिल गई थी"). A literal version would be: "गजाधर ने गाँव छोड़ने से पहले क्या किया?" (answer: "लाफ़नक को जनेऊ और पैसे दिए", directly stated).  
**What a wrong answer reveals:** If the student says "literal because the text says he left", they confuse *action* with *motive*. If they say "inferential because it's hard", they use difficulty as criterion instead of explicitness. The key is: does the text contain a sentence answering "why?" directly? If no → inferential.

## DIAGNOSTIC_QUESTION_3
**Question:** Below is a short extract from the story (paraphrased). Answer the literal and inferential question that follow.  
*Extract:* "बूढ़ी माँ ने गजाधर को देखा। उसकी आँखों में आँसू थे। उसने कहा, 'बेटा, तू जा। मैं यहीं रहूँगी।' गजाधर ने सिर झुका लिया और बाहर निकल गया।"  
**Literal:** बूढ़ी माँ ने गजाधर से क्या कहा?  
**Inferential:** गजाधर ने सिर क्यों झुका लिया?

## DIAGNOSTIC_ANSWER_3
**Correct Answer:**  
**Literal:** बूढ़ी माँ ने कहा, "बेटा, तू जा। मैं यहीं रहूँगी।" (Direct quote/paraphrase from the extract).  
**Inferential:** गजाधर ने सिर झुका लिया क्योंकि उसे अपनी माँ को अकेला छोड़ने का अपराधबोध (guilt) था और वह उसके आँसू देखकर भावुक हो गया था। **Evidence 1:** "उसकी आँखों में आँसू थे" (mother's pain). **Evidence 2:** "बेटा, तू जा" (mother's self-sacrifice). **Reasoning:** Head-bowing in Indian cultural context signals shame/guilt/respect; combined with the mother's tears and dismissal, it shows internal conflict.  
**What a wrong answer reveals:** Literal answer adding "क्योंकि वह दुखी थी" → confusion of literal/inferential. Inferential answer "क्योंकि वह थक गया था" → invention without textual evidence (no mention of fatigue). Inferential answer with only one evidence → insufficient grounding.

## DIAGNOSTIC_QUESTION_4
**Question:** Two students answer the inferential question: "लाफ़नक ने गजाधर को 'बेटा' क्यों कहा?"  
**Student A:** "क्योंकि लाफ़नक गजाधर को अपना बेटा मानती थी।"  
**Student B:** "क्योंकि लाफ़नक गजाधर को अपना बेटा मानती थी, इसका प्रमाण यह है कि वह उसे 'बेटा' कहकर पुकारती है, उसके लिए भोजन बनाती है, और अंत में उसे जनेऊ पहनाकर विदा करती है — ये सब मातृवत व्यवहार के चिह्न हैं।"  
Analyze which answer demonstrates better inferential reasoning and why.

## DIAGNOSTIC_ANSWER_4
**Correct Answer:** Student B's answer is superior. Student A states the inference as a bare claim (circular: "she called him beta because she considered him beta"). Student B provides **multiple textual evidences** (address, cooking, sacred thread ceremony) and **explains the cultural significance** (मातृवत व्यवहार) linking evidence to claim. This meets the board requirement: "दावा + प्रमाण + व्याख्या".  
**What a wrong answer reveals:** If the student picks A, they think inference = stating the obvious. If they say both are same, they don't understand the evidentiary standard. If they criticize B for being "too long", they confuse conciseness with completeness (board marking scheme awards marks for each evidence+explanation step).

## DIAGNOSTIC_QUESTION_5
**Question:** A student writes this inferential answer: "गजाधर बूढ़ी माँ से प्यार नहीं करता था, तभी तो वह उसे छोड़कर चला गया।" Evaluate this answer. Is it a valid inference? Why or why not? Use the concept of "textual support" and "alternative explanations".

## DIAGNOSTIC_ANSWER_5
**Correct Answer:** **Invalid inference.** The text provides **contradictory evidence**: Gajadhar gives her जनेऊ (sacred thread) and पैसे (money), bows his head (guilt/respect), and the narrator describes his "दुख" (sorrow). An alternative explanation supported by text: he left due to *compulsion* (आजीविका, सामाजिक दबाव) not lack of love. A valid inference must account for *all* relevant evidence, not cherry-pick. The student's answer ignores positive actions and imposes an external judgment.  
**What a wrong answer reveals:** If the student says "valid because he left", they equate action with motive without considering context. If they say "invalid because we don't know", they confuse "not explicitly stated" with "no textual basis" — inferential questions *require* going beyond explicit text, but *with* evidence.

## DIAGNOSTIC_QUESTION_6
**Question:** Write **one literal** and **one inferential** question based on this new paragraph (not from the textbook):  
"रमेश ने खिड़की से बाहर देखा। बारिश तेज़ हो रही थी। उसने अपना बैग उठाया, माँ के पैर छुए, और बिना कुछ कहे घर से निकल गया। माँ दरवाज़े पर खड़ी उसकी पीठ देखती रही।"

## DIAGNOSTIC_ANSWER_6
**Expected Answer:**  
**Literal:** "रमेश ने घर से निकलने से पहले क्या किया?" (Answer: माँ के पैर छुए / बैग उठाया / खिड़की से बाहर देखा — any explicitly stated action).  
**Inferential:** "रमेश ने माँ से कुछ क्यों नहीं कहा?" or "माँ दरवाज़े पर खड़ी क्यों रही?" (Answer must cite evidence: e.g., "रमेश ने कुछ नहीं कहा क्योंकि वह भावुक था / जल्दी में था / माँ को दुखी नहीं करना चाहता था — प्रमाण: पैर छूना (सम्मान), बिना बोले निकल जाना (भावनात्मक दबाव)। माँ खड़ी रही क्योंकि वह बेटे की सुरक्षा चाहती थी / वापसी की आशा — प्रमाण: पीठ देखती रही (प्रतीक्षा/चिंता)।")  
**Criteria for good answer:** Literal question has a single, directly verifiable answer. Inferential question has no direct answer in text, requires claim + at least two evidences + reasoning. Poor literal question: "रमेश कैसा लड़का है?" (not literal). Poor inferential question: "बारिश क्यों हो रही थी?" (external fact, not textual inference).

## COMMON_MISCONCEPTION
**Misconception:** "Inferential questions have no right answer — it's just your opinion."  
**Why students make this error:** In Class 10-11, "long answer" questions often accepted subjective responses. In Class 12 board/CUET, inferential answers are marked against a **scheme requiring specific textual evidence**. Students also confuse "inference" with "assumption" — they write "गजाधर स्वार्थी था" (assumption) instead of "गजाधर ने बूढ़ी माँ को जनेऊ और पैसे दिए, फिर भी चला गया, जिससे लगता है वह मजबूर था" (evidence-based inference). The error costs marks because board marking scheme allocates points for **each evidence cited and logical link explained**, not for the claim alone.

## ON_FAILURE
1. **Revisit definitions:** Use node c11_hin_ar_cbse_01_012 (Class 11 Literal/Inferential) — re-read the "Literal vs Inferential" comparison table.  
2. **Micro-practice:** Take 5 sentences from any newspaper editorial. Write 1 literal and 1 inferential question for each. Check: Can you underline the exact words for literal? For inferential, can you list 2+ underlined clues?  
3. **Graphic organizer:** Draw a T-chart: Left column "Textual Evidence (Underlined)", Right column "My Inference". Force yourself to fill left column *before* writing right column.  
4. **Re-diagnostic:** After 3 days, attempt Diagnostic Questions 3 & 4 again. If still mixing types, seek teacher for a "think-aloud" modeling session.

## BUILDS_ON
Class 11 literal comprehension (direct retrieval) and basic inference (simple cause-effect) from node c11_hin_ar_cbse_01_012.

## LEADS_TO
Critical Thinking: Analysis and Interpretation (node c12_hin_a_cbse_12_013) where inferences are synthesized into thematic arguments.

## PREREQUISITE_NODE_IDS
c12_hin_a_cbse_12_001, c12_hin_a_cbse_12_002, c12_hin_a_cbse_12_004, c12_hin_a_cbse_12_006, c12_hin_a_cbse_12_010, c11_hin_ar_cbse_01_012, c12_hin_a_cbse_12_011

## PREREQUISITE_REASONS
c12_hin_a_cbse_12_001: Context/background knowledge needed to understand cultural references (जनेऊ, लाफ़नक) in inferential reasoning.  
c12_hin_a_cbse_12_002: Plot structure knowledge helps locate where literal information appears (exposition vs climax).  
c12_hin_a_cbse_12_004: Protagonist analysis (Gajadhar) provides character traits used as evidence for inferences about motives.  
c12_hin_a_cbse_12_006: Primary theme (मातृभाव, विस्थापन) guides thematic inferences (e.g., why mother refuses food).  
c12_hin_a_cbse_12_010: Vocabulary (e.g., "लांसनक", "डींग", "व्याकुल") — literal questions often test word meaning in context.  
c11_hin_ar_cbse_01_012: Class 11 foundation on literal/inferential distinction and evidence-based answering.
c12_hin_a_cbse_12_011: Grammatical analysis provides evidence for inferential comprehension answers  

## FORWARD_NODE_IDS
c12_hin_a_cbse_12_013, c12_hin_a_cbse_12_014, c12_hin_a_cbse_12_015

## FORWARD_REASONS
c12_hin_a_cbse_12_013: Critical thinking requires valid inferences as building blocks for analysis/interpretation.  
c12_hin_a_cbse_12_014: Writing skills (analytical paragraph, essay) use the same Claim-Evidence-Reasoning structure taught here.
c12_hin_a_cbse_12_015: Provides literal/inferential comprehension base for evidence citation  

## CROSS_SUBJECT_PREREQS
c11_hin_ar_cbse_01_012, c11_hin_ar_cbse_02_012
## CROSS_SUBJECT_REASONS
c11_hin_ar_cbse_01_012: Direct predecessor — same skill (literal/inferential) in Class 11 Hindi Antra Chapter 1.  
c11_hin_ar_cbse_02_012: Reinforcement — Class 11 Chapter 2 comprehension practice with different text genre.

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_01_012 -> c12_hin_a_cbse_12_012 -> c12_hin_a_cbse_12_013

## THIS_FORMULA
**Literal Answer Formula:** Locate Keywords → Quote/Paraphrase Exact Text → Cite Location (Para/Line).  
**Inferential Answer Formula:** Claim (Inference) → Evidence 1 (Quote + Location) → Evidence 2 (Quote + Location) → Reasoning (Logical Bridge: cultural norm / psychological principle / textual pattern) → Concluding Statement linking to theme.

## FORMULA_VARIABLES
- **Keywords:** Specific nouns, verbs, numbers, names in the question that appear in the text.  
- **Quote/Paraphrase:** Exact words or close rewording of the textual sentence containing the answer.  
- **Location:** Paragraph number, line number, or "in the dialogue where..." — mandatory for board marking.  
- **Claim:** One-sentence answer to the inferential question (e.g., "She refused food due to grief").  
- **Evidence 1/2:** Underlined textual details (actions, dialogues, descriptions) supporting the claim.  
- **Reasoning:** Explanation of *why* the evidence implies the claim (e.g., "In the story's cultural setting, refusing food is a widow's ritual of mourning").  
- **Concluding Statement:** "Thus, the text suggests..." linking back to the question.

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
linguistic

## CROSS_SUBJECT
N/A | English Core/ Elective unseen passage comprehension uses identical literal/inferential classification and evidence-based answering (CBSE marking scheme parallel).  
 N/A | History source-based questions (e.g., "What does this inscription imply about the king's policy?") require the same Claim-Evidence-Reasoning structure with primary source quotes.  
 N/A | Political Science case-study questions (e.g., "Why did the leader take this decision?") demand inference from constitutional provisions + historical context — identical cognitive process.
## PREREQ_CONCEPT
Ability to distinguish explicit statements from implicit suggestions in a Hindi prose text (Class 11 level).

## PREREQ_BEFORE
Student must be able to read the chapter "लाफ़नक" and underline at least 5 explicit facts (names, events, objects) and 5 implicit suggestions (emotions, motives, themes) without teacher help.

## PREREQ_STUCK
If stuck, review Class 11 node c11_hin_ar_cbse_01_012 "Comprehension: Literal and Inferential Questions" — specifically the "Evidence Hunt" exercise and the "Inference Ladder" graphic organizer.

## WORKED_EXAMPLE_1
**PROBLEM:** Answer the following questions from the story "लाफ़नक":  
(A) Literal: "गजाधर ने लाफ़नक को विदा करते समय क्या दिया?"  
(B) Inferential: "लाफ़नक ने गजाधर का दिया जनेऊ क्यों पहन लिया?"

**STEPS:**
- **Step 1: Tag question types.** (A) asks "क्या दिया" — factual, directly stated → **Literal**. (B) asks "क्यों पहन लिया" — motive not explicitly stated → **Inferential**.
- **Step 2: For (A) Literal — Scan text for keywords.** Keywords: "गजाधर", "लाफ़नक", "विदा", "दिया". Locate in climax scene: "गजाधर ने ... जनेऊ और पैसे दिए" (para 12, approx).
- **Step 3: Formulate literal answer.** Quote/paraphrase: "गजाधर ने लाफ़नक को जनेऊ और पैसे दिए।" Add location: "अंतिम अनुच्छेद में, जब गजाधर गाँव छोड़कर जा रहा था।"
- **Step 4: For (B) Inferential — Formulate claim.** Claim: "लाफ़नक ने जनेऊ इसलिए पहना क्योंकि वह गजाधर को अपना बेटा स्वीकार कर चुकी थी और यह उसके मातृभाव का प्रतीक था।"
- **Step 5: Gather evidence.** Evidence 1: "बेटा, तू जा" — संबोधन (para 10). Evidence 2: "उसकी आँखों में आँसू थे" — भावुकता (para 10). Evidence 3: "जनेऊ पहनाकर विदा करती है" — क्रिया (para 12). Cultural reasoning: जनेऊ = ब्राह्मण पुत्र का संस्कार; माँ द्वारा पहनाना = पुत्र के रूप में स्वीकृति।
- **Step 6: Write structured answer.** Claim → Evidence 1+2+3 with locations → Reasoning (cultural symbol) → Concluding link to theme (मातृभाव)।

**REASONING:** The literal answer follows the "Locate-Quote-Cite" protocol ensuring full board marks (1 mark for content, 1 for accuracy). The inferential answer uses the CER (Claim-Evidence-Reasoning) framework required for 3-4 mark questions in CBSE Class 12 — each evidence gets a mark, reasoning gets a mark.

**ANSWER:**  
**(A) Literal:** गजाधर ने लाफ़नक को जनेऊ और पैसे दिए। (पाठ के अंतिम अनुच्छेद में, गजाधर के प्रस्थान के समय)  
**(B) Inferential:** लाफ़नक ने जनेऊ इसलिए पहना क्योंकि वह गजाधर को अपना पुत्र मान चुकी थी। **प्रमाण 1:** वह उसे "बेटा" कहकर संबोधित करती है (अनुच्छेद 10)। **प्रमाण 2:** उसकी आँखों में आँसू हैं, जो ममता दर्शाते हैं (अनुच्छेद 10)। **प्रमाण 3:** वह जनेऊ पहनाकर विदा करती है, जो पुत्र के प्रति माँ के संस्कार का प्रतीक है (अनुच्छेद 12)। **तर्क:** भारतीय परंपरा में जनेऊ पुत्र का संस्कार है; माँ द्वारा पहनाना = पुत्र रूप में स्वीकृति। **निष्कर्ष:** यह कृत्य केंद्रीय विषय 'मातृभाव' को पुष्ट करता है।

## WORKED_EXAMPLE_2
**PROBLEM:** A CUET-style question: "Based on the story 'लाफ़नक', why did the old woman refuse to eat the food brought by Gajadhar's wife?" (Text reference: "बूढ़ी माँ ने भोजन नहीं किया... 'मैं नहीं खाऊँगी'")

**STEPS:**
- **Step 1: Identify question type.** "Why did she refuse?" → **Inferential** (no direct "because" in text).
- **Step 2: Locate relevant textual segment.** Scene: Gajadhar's wife brings food (पकवान), old woman refuses, says "मैं नहीं खाऊँगी", later eats only after Gajadhhar leaves (or not at all). Key paragraphs: middle section where daughter-in-law brings food.
- **Step 3: List all textual clues.** Clue 1: "बहू के हाथ का भोजन नहीं खाऊँगी" (implied by context: she asks Gajadhar to feed her). Clue 2: "मेरे बेटे के हाथ का खाऊँगी" — not explicit but inferred from "गजाधर ने अपने हाथ से खिलाया" later. Clue 3: Her dialogue "तू जा, मैं यहीं रहूँगी" — rejection of new household. Clue 4: Cultural norm: widow/elder mother rejects daughter-in-law's food as assertion of autonomy/grief.
- **Step 4: Formulate claim.** Claim: "She refused because she recognized only Gajadhar as her son/caregiver and rejected the new household's authority, expressing grief over her biological son's absence."
- **Step 5: Build CER answer.** Claim → Evidence 1 (refusal dialogue) + Evidence 2 (acceptance only from Gajadhar's hand) + Evidence 3 (cultural context of widow's food rituals) → Reasoning: Refusal is agency/grief, not mere stubbornness → Theme link: विस्थापन और संबंधों का विघटन।

**REASONING:** CUET/Board inferential questions on prose require **multiple evidences** (minimum 2 for 3 marks, 3 for 4 marks). The cultural reasoning is essential because the story relies on social rituals (जनेऊ, भोजन, अंतिम संस्कार) as symbolic acts. Missing cultural reasoning = incomplete inference.

**ANSWER:** बूढ़ी माँ ने बहू के हाथ का भोजन इसलिए अस्वीकार किया क्योंकि वह गजाधर को ही अपना पुत्र मानती थी और नए पारिवारिक ढांचे को अस्वीकार कर रही थी। **प्रमाण 1:** उसने कहा "मैं नहीं खाऊँगी" जब बहू भोजन लाई (मध्य अनुच्छेद)। **प्रमाण 2:** बाद में गजाधर के अपने हाथ से खिलाने पर ही उसने भोजन किया (या मृत्युपर्यंत अस्वीकार) — पाठ में "गजाधर ने अपने हाथ से खिलाया" प्रसंग। **प्रमाण 3:** उसने गजाधर से कहा "तू जा, मैं यहीं रहूँगी" — पुत्र से अलगाव अस्वीकार। **तर्क:** विधवा/वृद्ध माँ का बहू के हाथ का भोजन न करना स्वायत्तता और शोक की अभिव्यक्ति है। **विषय-संबंध:** यह विस्थापन की पीड़ा और पारंपरिक संबंधों के टूटने को दर्शाता है।

## WORKED_EXAMPLE_3
**PROBLEM:** Board 4-mark question: "How does the author use the character of लाफ़नक to depict the theme of 'मातृभाव' (motherhood) beyond biological ties? Support with three textual evidences."

**STEPS:**
- **Step 1: Deconstruct the question.** It asks for **theme depiction through character** — an inferential synthesis question. Requires: (i) Definition of मातृभाव in this context, (ii) 3 distinct evidences from different parts of story, (iii) Explanation of how each evidences the theme.
- **Step 2: Define मातृभाव in story context.** Not just biological — it's *chosen* motherhood: nurturing, sacrifice, identity-giving (जनेऊ), emotional anchoring.
- **Step 3: Select Evidence 1 (Nurturing/Feeding).** "बहू के हाथ का भोजन नहीं खाऊँगी... गजाधर ने अपने हाथ से खिलाया" — shows she *elicits* maternal care, reversing roles. Location: Middle section.
- **Step 4: Select Evidence 2 (Identity/Ritual).** "जनेऊ पहनाकर विदा किया" — she *performs* the mother's ritual (उपनयन/जनेऊ) on a non-biological son. Location: Climax.
- **Step 5: Select Evidence 3 (Emotional Anchor/Grief).** "उसकी आँखों में आँसू थे... 'बेटा, तू जा'" — her grief at his departure mirrors a mother's; she stays back to die (अंतिम संस्कार गजाधर करता है). Location: End.
- **Step 6: Synthesize with reasoning.** Each evidence shows a *dimension*: nurturing (food), ritual (thread), emotional (tears/staying). Together they construct मातृभाव as *action* not biology. Author's technique: showing not telling — through rituals and dialogues.
- **Step 7: Write final answer in board format.** Point-wise: Theme statement → Evidence 1 + Analysis → Evidence 2 + Analysis → Evidence 3 + Analysis → Concluding synthesis.

**REASONING:** This combines skills from nodes c12_hin_a_cbse_12_006 (Theme), c12_hin_a_cbse_12_004 (Character), and this node (Inferential CER). Board 4-mark questions demand **integration** — students who give 3 separate inferences without unifying theme lose synthesis marks. The "beyond biological ties" phrase in the question signals the need to contrast with biological mother (who is absent) — a nuance from node c12_hin_a_cbse_12_006.

**ANSWER:** लेखक लाफ़नक के माध्यम से मातृभाव को जैविक सीमा से परे **कर्तव्य, संस्कार और भावनात्मक आसक्ति** के रूप में चित्रित करते हैं:  
1. **पालन-पोषण (भोजन):** वह बहू के हाथ का भोजन अस्वीकार कर गजाधर से माँगती है — "गजाधर ने अपने हाथ से खिलाया"। *विश्लेषण:* यह भूमिका-उलटफेर है; वह पुत्र से मातृवत देखभाल प्राप्त करती है, जो मातृभाव की पारस्परिकता दर्शाता है।  
2. **सांस्कृतिक संस्कार (जनेऊ):** प्रस्थान के समय वह गजाधर को जनेऊ पहनाती है — "जनेऊ पहनाकर विदा करती है"। *विश्लेषण:* जनेऊ माँ का पुत्र को दिया जाने वाला संस्कार है; लाफ़नक द्वारा किया जाना उसे 'माँ' के सामाजिक पद पर स्थापित करता है।  
3. **भावनात्मक आसक्ति (अश्रु/त्याग):** "उसकी आँखों में आँसू थे... 'बेटा, तू जा'" और अंत में गाँव में ही रहकर प्राण त्यागना। *विश्लेषण:* पुत्र-वियोग में आँसू और पुत्र के हाथों अंतिम संस्कार (गजाधर द्वारा) — ये जैविक पुत्र से अपेक्षित व्यवहार हैं।  
**निष्कर्ष:** लाफ़नक मातृभाव को **चुनाव (choice)** सिद्ध करती है — रक्त नहीं, रिश्ता निभाना माँ बनाता है। यह केंद्रीय विषय 'विस्थापन में मानवीय संबंधों की पुनर्सृष्टि' को पुष्ट करता है।

## COMPETENCY_QUESTION_1
**QUESTION:** Read the following unseen extract (similar style to "लाफ़नक"):  
"हरिया ने बूढ़े बाबा को देखा। वे खाट पर पड़े खाँस रहे थे। हरिया ने पानी का गिलास उठाया, बाबा के होंठों से लगाया। बाबा ने आँखें खोलीं, हरिया का हाथ पकड़ लिया, और धीमे से बोले, 'तू आ गया, बेटा।' हरिया की आँखें भर आईं। वह कुछ न बोला, बस सिर हिलाता रहा।"  
**Answer the following:**  
(i) Literal: हरिया ने बाबा को क्या पिलाया?  
(ii) Inferential: बाबा ने हरिया को 'बेटा' क्यों कहा जबकि वह उनका जैविक पुत्र नहीं था? (Answer using Claim-Evidence-Reasoning format).

**COMPETENCY:** Reading Comprehension — Literal Retrieval & Inferential Reasoning (CBSE/CUET Pattern)  
**STEPS:**
- Step 1: Tag (i) as Literal — scan for "पिलाया/दिया". Answer: पानी।  
- Step 2: Tag (ii) as Inferential — "क्यों कहा" = motive.  
- Step 3: Claim: बाबा ने हरिया को 'बेटा' कहा क्योंकि हरिया ने पुत्रवत सेवा की (पानी पिलाना, सेवा करना)।  
- Step 4: Evidence 1: "हरिया ने पानी का गिलास उठाया, बाबा के होंठों से लगाया" (सेवा क्रिया)। Evidence 2: "बाबा ने हरिया का हाथ पकड़ लिया" (स्वीकृति/आसक्ति)।  
- Step 5: Reasoning: भारतीय लोकाचार में सेवा करने वाले को पुत्र मानना (श्रवण कुमार परंपरा)। बाबा की आँखें खोलना और हाथ पकड़ना = भावनात्मक स्वीकृति।  
- Step 6: Conclude: यह 'चुना हुआ पुत्रत्व' दर्शाता है, जैविक नहीं।

**ANSWER:**  
(i) **Literal:** हरिया ने बाबा को **पानी** पिलाया। (पंक्ति 2-3: "हरिया ने पानी का गिलास उठाया, बाबा के होंठों से लगाया")  
(ii) **Inferential:** बाबा ने हरिया को 'बेटा' कहा क्योंकि हरिया ने पुत्रवत सेवा की। **दावा:** बाबा हरिया को पुत्र मानते थे। **प्रमाण 1:** हरिया ने पानी पिलाया — पुत्र का कर्तव्य (पंक्ति 2-3)। **प्रमाण 2:** बाबा ने हरिया का हाथ पकड़ा — स्वीकृति/स्नेह (पंक्ति 4)। **तर्क:** भारतीय संस्कृति में सेवा करने वाले को पुत्र मानने की परंपरा है (श्रवण कुमार)। बाबा का "तू आ गया, बेटा" कहना हरिया की सेवा को पुत्रवत मान्यता देना है। **निष्कर्ष:** संबंध रक्त से नहीं, सेवा और स्नेह से बनते हैं।

**DIFFICULTY:** medium

## COMPETENCY_QUESTION_2
**QUESTION:** **Assertion-Reason Question (CBSE Board Style):**  
**Assertion (A):** In "लाफ़नक", the old woman's refusal to eat the daughter-in-law's food is an act of rebellion against patriarchal family structure.  
**Reason (R):** The text shows she only accepts food from Gajadhar's hand and addresses him as "बेटा", rejecting the new household's authority.  
**Choose the correct option:**  
(a) Both A and R are true, and R correctly explains A.  
(b) Both A and R are true, but R does not explain A.  
(c) A is true, R is false.  
(d) A is false, R is true.  
**Justify your choice with textual analysis.**

**COMPETENCY:** Critical Evaluation of Interpretive Claims (Assertion-Reason) — CBSE Competency-Based Question  
**STEPS:**
- Step 1: Evaluate Assertion (A). Is refusal "rebellion against patriarchal structure"? Text: She refuses *daughter-in-law's* food, not *all* food. She accepts Gajadhar's (male) feeding. This reinforces *patriarchal* norm (son's authority > daughter-in-law's), not rebellion. So A is **false** (over-interpretation, imposes modern feminist reading not supported by text).
- Step 2: Evaluate Reason (R). "Only accepts food from Gajadhar's hand, addresses him as बेटा, rejects new household" — all textually accurate (evidences from Worked Example 2). So R is **true**.
- Step 3: Check if R explains A. Since A is false, R cannot explain it. But even if A were true, R describes *filial piety* not *rebellion*. So R does not explain A.
- Step 4: Select option: (d) A is false, R is true.
- Step 5: Write justification: Distinguish between *textual evidence* (R) and *interpretive leap* (A). Board expects students to spot unsupported critical theory impositions.

**ANSWER:** **Option (d) — A is false, R is true.**  
**Justification:**  
- **Reason (R) is textually accurate:** The old woman refuses the daughter-in-law's food (प्रमाण: "मैं नहीं खाऊँगी"), accepts food only from Gajadhar's hand (प्रमाण: "गजाधर ने अपने हाथ से खिलाया"), calls him "बेटा" (प्रमाण: संबोधन), and rejects the new household by staying behind (प्रमाण: "मैं यहीं रहूँगी")।  
- **Assertion (A) is an unsupported interpretive leap:** Calling this "rebellion against patriarchal structure" imposes an external theoretical framework. The text shows her *upholding* patriarchal norms — she recognizes only the *son* (male heir) as her caregiver, not the daughter-in-law. Her agency is expressed *within* the traditional role of mother, not against the structure.  
- **R does not explain A** because R describes filial bonding (मातृ-पुत्र संबंध), not structural rebellion.  
**Board Marking Insight:** Such questions test ability to separate *textual fact* from *critical overreach*. Full marks for identifying A as false with textual counter-evidence (she accepts son's authority).

**DIFFICULTY:** hard