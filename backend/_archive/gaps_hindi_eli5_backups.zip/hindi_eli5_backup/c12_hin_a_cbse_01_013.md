## DEFINITION
Critical thinking in literary analysis involves examining a text beyond its literal meaning to interpret themes, evaluate author's choices, analyze literary devices, and synthesize evidence to form reasoned interpretations supported by textual evidence.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
Student can independently analyze a poem's theme, identify and explain the effect of literary devices, compare two poems on similar/different themes, and write a structured analytical response using textual evidence following the PEEL framework.

## SCOPE_BOUNDARY
Covers analysis and interpretation of the two poems in Chapter 1 (नसोलसुक का छर and दकुसजफ्यक का छर) focusing on theme, imagery, symbolism, tone, and comparative analysis. Does not cover basic comprehension, vocabulary, or grammar which are addressed in previous nodes (c12_hin_a_cbse_01_010, 011, 012).

## WALKTHROUGH
Imagine the board exam asks: "Compare the vision of India in दकुसजफ्यक का छर with the personal spiritual journey in नसोलसुक का छर." Where do you begin? Most students freeze because they've only practiced comprehension questions. Start differently: re-read both poems with a pencil, marking every image that strikes you—don't analyze yet, just notice. Then ask: "What is the poet *doing* with this image?" In नसोलसुक, the cuckoo isn't just a bird—it's a summons to awakening. In दकुसजफ्यक, the Himalayas aren't just mountains—they're the nation's crown. Critical thinking means moving from "what happens" to "why the poet chose this image, this sound, this structure." The insight: every analytical answer has four moves—claim, evidence, explanation, link to theme. Master this pattern and no question can stump you.

## DIAGNOSTIC_QUESTION_1
What is the central theme of नसोलसुक का छर?

## DIAGNOSTIC_ANSWER_1
Central theme: The futility of worldly attachments and the search for spiritual liberation through self-realization. A wrong answer like "it's about a sad woman remembering her life" reveals the student only grasped the literal narrative, missing the philosophical/spiritual dimension that the poem's imagery (cuckoo, storm, nose-ring metaphor) consistently points toward. The error stems from treating the speaker's personal grief as the poem's subject rather than the vehicle for its universal theme.

## DIAGNOSTIC_QUESTION_2
Explain why the poet addresses "करुणा" (compassion) as "कोयल" (cuckoo) in नसोलसुक का छर.

## DIAGNOSTIC_ANSWER_2
The cuckoo's call signals spring/renewal; addressing compassion as cuckoo personifies it as a herald of spiritual awakening. A wrong answer like "because the cuckoo sings sweetly" misses the symbolic function entirely—it treats the image as decorative rather than functional. The student who gives this answer recognizes personification as a device but fails to analyze *why this specific bird*: the cuckoo (कोयल) in Indian poetic tradition announces बसंत (spring), just as करुणा announces the speaker's transition from worldly attachment to spiritual spring. This confusion between identifying a device and interpreting its purpose is the most common Class 12 error.

## DIAGNOSTIC_QUESTION_3
In दकुसजफ्यक का छर, the line "गसे ओकककक यक मकक लोसजकककक" uses a specific literary device. Identify it and explain its effect in 2-3 sentences.

## DIAGNOSTIC_ANSWER_3
Device: व्यक्ति अलंकार (personification) combined with रूपक (metaphor)—the land/crops/gold are figured as a mother singing a lullaby. Effect: Transforms geographical diversity into emotional unity; the lullaby implies intimate, equal care for all regions/children, making "unity in diversity" felt rather than argued. A wrong answer that only names "personification" without explaining the *maternal* imagery's unifying function shows mechanical device-spotting without analytical depth. Board exams award marks for the explanation, not the label.

## DIAGNOSTIC_QUESTION_4
Compare the use of nature imagery in both poems. How does the poet use nature differently in नसोलसुक का छर (personal/spiritual) vs दकुसजफ्यक का छर (national/collective)?

## DIAGNOSTIC_ANSWER_4
In नसोलसुक: nature mirrors inner turmoil and awakening—the storm reflects existential crisis, the cuckoo's call triggers self-confrontation, darkness symbolizes spiritual ignorance. In दकुसजफ्यक: nature symbolizes national grandeur and unity—the Himalayas as crown, rivers as lifelines, diverse flora/fauna as unity in diversity. A wrong answer that merely lists images from both poems ("Poem 1 has storm and cuckoo; Poem 2 has Himalayas and rivers") without comparing their *function* reveals inability to analyze authorial purpose. Analysis requires answering "what work does this image do in *this* poem?"

## DIAGNOSTIC_QUESTION_5
"त्रिलोचन शास्त्री's patriotic vision in दकुसजफ्यक का छर is more effective than his spiritual vision in नसोलसुक का छर." Defend or refute with evidence from both poems.

## DIAGNOSTIC_ANSWER_5
Refute with nuance: Both are effective but serve different purposes—effectiveness isn't comparable across domains. नसोलसुक uses intimate, personal imagery (cuckoo, storm, life's journey as nose-ring) for universal spiritual truth; its power lies in particularity. दकुसजफ्यक uses expansive, collective imagery (Himalayas, rivers, diversity) for national pride; its power lies in inclusivity. A wrong answer that picks one and dismisses the other ("दकुसजफ्यक is better because it's about India") reveals binary thinking and failure to evaluate *on the text's own terms*. Critical evaluation requires judging each work by its intended aim.

## DIAGNOSTIC_QUESTION_6
Write a 4-line stanza in Hindi that uses nature imagery to express EITHER personal spiritual longing (like नसोलसुक) OR national pride (like दकुसजफ्यक). Use at least one literary device consciously.

## DIAGNOSTIC_ANSWER_6
Good answer example (spiritual longing): "पककककक पकककक यक कोयल कूक / अककककक यक मन कक अककककक / फनत यक फनत कक पयकककक / मकककक कक ककक कककककक" — uses personification (wind as messenger), metaphor (breath as prayer), and auditory imagery consciously. Poor answer: "भारत महान है, हिमालय ऊँचा है / नदियाँ बहती हैं, हम सब एक हैं" — generic statements without conscious device use or imagery shows inability to apply analytical understanding creatively. The gap: student can recognize devices but cannot deploy them purposefully.

## COMMON_MISCONCEPTION
Students think "analysis" means listing literary devices found in the poem. They write: "The poet uses metaphor, simile, alliteration, personification." But they don't explain WHY the poet chose that device or HOW it creates meaning. Concrete example: Identifying "नकचय इन चय" (nose-ring of this world) as a metaphor but not explaining how it conveys the fragility and transience of worldly attachments—specifically, how a nose-ring is precious yet removable, worn by cultural convention but not part of the body's essence, just as relationships/possessions appear precious but death strips them away. The error: confusing *identification* (naming) with *analysis* (explaining function).

## ON_FAILURE
1. Have student pick ONE image from नसोलसुक का छर (e.g., "नकचय इन चय" or "गख गकस+ यकसवक यक लरयक नथ"). 2. Ask three questions in sequence: "What does this literally describe?" → "What does it suggest about the speaker's state of mind?" → "Why *this* specific image and not another?" 3. Guide them to write 3 sentences following PEEL: Point (the image suggests X), Evidence (the line "..."), Explanation (because a nose-ring is... therefore...), Link (this reinforces the theme of...). 4. Repeat with one image from दकुसजफ्यक का छर. 5. Only then attempt a comparative question. This isolates the analytical move they're missing.

## BUILDS_ON
Builds on c12_hin_a_cbse_01_012 (Comprehension: Literal and Inferential Questions) where students learned to extract explicit and implicit meaning from the text.

## LEADS_TO
Leads to c12_hin_a_cbse_01_014 (Writing Skills: Based on the Chapter) where analytical insights are structured into formal written responses for board exams.

## PREREQUISITE_NODE_IDS
c12_hin_a_cbse_01_006, c12_hin_a_cbse_01_007, c12_hin_a_cbse_01_008, c12_hin_a_cbse_01_009, c12_hin_a_cbse_01_012, c11_hin_ar_cbse_01_013, c12_hin_a_cbse_01_001, c12_hin_a_cbse_01_002, c12_hin_a_cbse_01_004, c12_hin_a_cbse_01_005, c12_hin_a_cbse_01_010, c12_hin_a_cbse_01_011

## PREREQUISITE_REASONS
c12_hin_a_cbse_01_006: Primary theme understanding needed as foundation for analysis
c12_hin_a_cbse_01_007: Secondary themes provide depth for comparative interpretation
c12_hin_a_cbse_01_008: Imagery and metaphor identification essential for device analysis
c12_hin_a_cbse_01_009: Irony and symbolism knowledge needed for deeper interpretation
c12_hin_a_cbse_01_012: Literal/inferential comprehension is prerequisite for critical analysis
c11_hin_ar_cbse_01_013: Class 11 critical thinking skills transfer to Class 12 complexity
c12_hin_a_cbse_01_001: Critical interpretation depends on historical-literary context.  
c12_hin_a_cbse_01_002: Critical interpretation requires the structural map built in this node as evidence for analytical claims.  
c12_hin_a_cbse_01_004: Critical thinking requires synthesizing character, theme, and device analysis — all rooted in protagonist understanding.  
c12_hin_a_cbse_01_005: Critical thinking node demands the comparative character analysis practiced here — e.g., "Compare how nsolsuk and dkusZfy;k use nature imagery" is a direct application.  
c12_hin_a_cbse_01_010: Critical interpretation uses vocabulary choices as *evidence* for claims about tone, theme, ideology.  
c12_hin_a_cbse_01_011: Critical interpretation requires analyzing how grammar shapes meaning.  

## FORWARD_NODE_IDS
c12_hin_a_cbse_01_014, c12_hin_a_cbse_01_015
## FORWARD_REASONS
c12_hin_a_cbse_01_014: Analytical insights become raw material for structured writing responses
c12_hin_a_cbse_01_015: Interpretive depth enables meaningful discussion and debate in speaking/listening

## CROSS_SUBJECT_PREREQS
c11_hin_ar_cbse_01_013, c11_hin_ar_cbse_02_013
## CROSS_SUBJECT_REASONS
c11_hin_ar_cbse_01_013: Class 11 Antra Chapter 1 critical thinking establishes analytical framework for poetry
c11_hin_ar_cbse_02_013: Class 11 Antra Chapter 2 critical thinking reinforces comparative analysis skills across texts

## CHAIN_DESCRIPTION
c12_hin_a_cbse_01_012 -> c12_hin_a_cbse_01_013 -> c12_hin_a_cbse_01_014

## THIS_FORMULA
PEEL Analysis Framework: Point (claim about text) → Evidence (quote/reference) → Explanation (how evidence supports point) → Link (connect to theme/author's purpose)

## FORMULA_VARIABLES
Point: विश्लेषण का मुख्य दावा; Evidence: पाठ से उद्धरण/संदर्भ; Explanation: साक्ष्य कैसे दावे का समर्थन करता है; Link: विषय/लेखक के उद्देश्य से संबंध

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
analytical

## CROSS_SUBJECT
N/A | Both दकुसजफ्यक का छर and history nationalism chapter examine construction of national identity through cultural symbols
 N/A | Poem's geographical imagery (Himalayas, rivers, diversity) connects to physical geography of India
 N/A | Unity in diversity theme in poem parallels federalism's accommodation of diversity
## PREREQ_CONCEPT
Ability to move beyond "what the text says" to "how the text creates meaning through author's choices."

## PREREQ_BEFORE
Student must have completed literal/inferential comprehension of both poems and identified basic literary devices (imagery, metaphor, personification, symbolism).

## PREREQ_STUCK
If stuck, revisit c12_hin_a_cbse_01_008 (Imagery and Metaphor) and c12_hin_a_cbse_01_009 (Irony and Symbolism) to strengthen device recognition before attempting analysis.

## WORKED_EXAMPLE_1
PROBLEM: Analyze how the metaphor "नकचय इन चय" (nose-ring of this world) in नसोलसुक का छर conveys the poem's central theme of worldly attachment's transience.

STEPS:
- Step 1: Identify the metaphor — "नकचय इन चय" compares worldly life to a nose-ring ornament
- Step 2: Analyze literal properties of a nose-ring — decorative, worn temporarily, can be removed, signifies marital bond but is ultimately external to the body
- Step 3: Map to thematic meaning — worldly attachments are similarly decorative/temporary, externally imposed, removable at death, not the essence of self
- Step 4: Connect to speaker's journey — नसोलसुक realizes these "ornaments" (relationships, possessions) cannot accompany her beyond death
- Step 5: Evaluate effectiveness — The domestic, feminine image of nose-ring makes the philosophical point accessible and emotionally resonant for the female speaker

REASONING: This step-by-step moves from device identification to thematic function, which is the core of critical analysis. Each step builds analytical depth: literal → symbolic → thematic → personal → evaluative.

ANSWER: The metaphor "नकचय इन चय" transforms the abstract concept of worldly attachment into a concrete, culturally resonant image. A nose-ring is precious yet temporary, worn by choice/culture but not part of the body's essence. Similarly, worldly bonds (family, wealth, status) appear precious but are transient—death removes them like an ornament. The metaphor works because it emerges organically from नसोलसुक's female perspective, making the spiritual realization personal and gendered rather than abstract philosophy.

## WORKED_EXAMPLE_2
PROBLEM: In दकुसजफ्यक का छर, the line "गसे ओकककक यक मकक लोसजकककक" uses personification. Explain how this personification contributes to the poem's vision of national unity.

STEPS:
- Step 1: Identify the personification — "गसे" (crops/fields) and "ओकककक" (gold) are described as "मकक" (mother's) "लोसजकककक" (lullaby/song)
- Step 2: Analyze the maternal imagery — Mother figure nurtures, unifies, provides equally to all children regardless of difference
- Step 3: Connect to geographical references — The poem lists diverse regions/features (Himalayas, rivers, deserts, forests); mother's lullaby implies they all belong to one family
- Step 4: Examine the unifying function — A lullaby is intimate, shared across generations; the land's "song" becomes shared cultural heritage
- Step 5: Link to "unity in diversity" theme — Personification transforms geographical diversity into familial unity, making patriotism emotional rather than abstract

REASONING: Personification here isn't decorative—it's the structural device that converts physical geography into emotional nationalism. The steps show how to trace device → function → theme, which is the analytical pattern board examiners reward.

ANSWER: The personification of land as mother singing a lullaby ("गसे ओकककक यक मकक लोसजकककक") converts India's physical diversity into a unified family. Just as a mother's lullaby embraces all her different children equally, the land nurtures its diverse regions (Himalayas, rivers, deserts, forests) as one family. This makes "unity in diversity" not a political slogan but an intimate, emotional truth—patriotism becomes filial love. The device is effective because it draws on the deeply rooted Indian cultural trope of भूमाता (Mother Earth).

## WORKED_EXAMPLE_3
PROBLEM: Compare and contrast the role of "sound/auditory imagery" in both poems: the cuckoo's call in नसोलसुक का छर vs the "lullaby" and "storm sounds" in दकुसजफ्यक का छर. How does sound function differently in personal spiritual awakening vs collective national identity?

STEPS:
- Step 1: Identify auditory images in नसोलसुक — "कोयल" (cuckoo's call), implied storm/thunder sounds, speaker's own voice addressing compassion
- Step 2: Identify auditory images in दकुसजफ्यक — "लोसजकककक" (lullaby), land's voice ("हककककक" implied), collective "we" in final affirmation
- Step 3: Analyze function in नसोलसुक — Cuckoo's call is solitary, internal, triggers personal memory/realization; sound marks moment of individual epiphany
- Step 4: Analyze function in दकुसजफ्यक — Lullaby is communal, intergenerational, shared cultural memory; sound binds diverse people into collective identity
- Step 5: Contrast the directionality — नसोलसुक: sound moves from outside → inside (personal transformation); दकुसजफ्यक: sound moves from inside → outside (collective expression)
- Step 6: Synthesize — Both use sound as catalyst, but one catalyzes self-knowledge, the other catalyzes national consciousness; both reflect poet's belief in sound's power to awaken

REASONING: This comparative analysis requires holding two poems in mind simultaneously, tracing a single element (sound) across both, and evaluating functional difference—exactly the multi-text analytical skill Class 12 board and CUET demand.

ANSWER: In नसोलसुक का छर, the cuckoo's call ("कोयल") functions as an internal summons—it pierces the speaker's solitude, triggering self-confrontation and spiritual awakening. The sound travels from external world to internal consciousness. In दकुसजफ्यक का छर, the "लोसजकककक" (lullaby) and land's voice are collective expressions—they emerge from the shared land and bind diverse listeners into a national "we." Sound here moves from collective heart outward as cultural affirmation. Both poems position sound as awakening force, but नसोलसुक uses it for individual liberation (मोक्ष) while दकुसजफ्यक uses it for collective identity (राष्ट्रबोध). This contrast reveals त्रिलोचन शास्त्री's dual concern: the self's journey and the nation's soul.

## COMPETENCY_QUESTION_1
QUESTION: The CBSE board asks: "नसोलसुक का छर में 'करुणा' को 'कोयल' कहकर संबोधित करने का औचित्य स्पष्ट कीजिए।" A student writes: "क्योंकि कोयल मीठा बोलती है और करुणा भी मीठी होती है।" Why is this answer insufficient for full marks? Rewrite it as a 3-mark answer using the PEEL framework.

COMPETENCY: Analytical writing — using textual evidence to explain authorial choice

STEPS:
- Step 1: Identify the gap — Student's answer only gives surface similarity (sweetness), misses symbolic/functional depth
- Step 2: Apply PEEL — Point: कोयल संबोधन करुणा को वसंत/जागरण का प्रतीक बनाता है; Evidence: "आ न करुणा की दशा दयक लक तक!" and context of spiritual awakening; Explanation: कोयल की कूक वसंत सूचक है, इसी तरह करुणा आध्यात्मिक जागरण की सूचक; Link: यह नसोलसुक के मोक्ष मार्ग का आरंभ है
- Step 3: Structure for 3 marks — Point (1 mark), Evidence (1 mark), Explanation (1 mark)
- Step 4: Write final answer in Hindi with proper terminology

ANSWER: कोयल संबोधन करुणा को केवल 'मीठा' नहीं, अपितु **आध्यात्मिक जागरण का अग्रदूत** बनाता है। (Point) पंक्ति "आ न करुणा की दशा दयक लक तक!" में करुणा को पुकारा गया है जैसे कोयल वसंत का संदेश लाती है। (Evidence) कोयल की कूक ऋतु-परिवर्तन की सूचक है—यह नसोलसुक के जीवन में आसक्ति से वैराग्य के संक्रमण का क्षण है। (Explanation) इस प्रकार कोयल-रूपी करुणा नसोलसुक को संसार-चक्र से मुक्ति की ओर प्रवृत्त करती है, जो कविता का केंद्रीय विषय है। (Link)

DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: A CUET-style question: "Both poems by त्रिलोचन शास्त्री in this chapter use the technique of 'addressing an abstract concept as a living being' (apostrophe). Compare the effect of this technique in नसोलसुक का छर (addressing करुणा) and दकुसजफ्यक का छर (addressing the nation as 'हमारा देश'). Write a 150-word analytical response."

COMPETENCY: Comparative analysis of literary technique across texts

STEPS:
- Step 1: Identify the technique in both — Apostrophe (संबोधन अलंकार): addressing absent/abstract as present/living
- Step 2: Analyze नसोलसुक — Addressing करुणा as कोयल: intimate, personal, transforms abstract virtue into living guide for individual soul
- Step 3: Analyze दकुसजफ्यक — Addressing nation as "वजकककक ;ग एनकककककक": collective, expansive, transforms geo-political entity into living mother-figure
- Step 4: Compare — Both make abstract tangible, but scale differs: individual salvation vs collective identity; feminine imagery in both (कोयल, माँ) but different registers
- Step 5: Synthesize in 150 words with clear structure

ANSWER: दोनों कविताओं में संबोधन अलंकार (अपोस्ट्रोफी) अमूर्त को सजीव बनाता है, परंतु प्रभाव भिन्न है। *नसोलसुक का छर* में "करुणा" को "कोयल" संबोधित करना **व्यक्तिगत, अंतरंग, आध्यात्मिक** है—करुणा एकाकी साधिका की मार्गदर्शक बनती है, जैसे कोयल की कूक वसंत (मोक्ष) का निजी संकेत दे। *दकुसजफ्यक का छर* में "वजकककक ;ग एनकककककक" संबोधन **सामूहिक, विस्तृत, राष्ट्रीय** है—देश माँ बनकर विविध संतानों (क्षेत्रों, नदियों, लोगों) को एक सूत्र में बाँधती है। पहली में ध्वनि (कूक) **आंतरिक जागरण** उत्पन्न करती है; दूसरी में ध्वनि (लोरी) **सामूहिक पहचान** दृढ़ करती है। त्रिलोचन शास्त्री इस प्रकार एक ही तकनीक से दो ध्रुवों—व्यक्ति की मुक्ति और राष्ट्र की एकता—को साधते हैं। (148 शब्द)

DIFFICULTY: hard