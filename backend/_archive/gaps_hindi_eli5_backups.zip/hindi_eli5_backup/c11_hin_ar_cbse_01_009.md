## DEFINITION
Irony is a literary device where the intended meaning of words or events is opposite to their literal or expected meaning, creating a contrast between appearance and reality. Symbolism is the use of concrete objects, characters, settings, or actions to represent abstract ideas, themes, or qualities beyond their literal sense.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student must independently identify at least two distinct types of irony (situational, dramatic, verbal) and two major symbols in "Udd ka Naksha," provide textual evidence for each, and explain in a structured paragraph how each device deepens the story's critique of colonial bureaucracy and human integrity.

## SCOPE_BOUNDARY
This node covers irony (situational, dramatic, verbal) and symbolism exclusively within Premchand's "Udd ka Naksha." It builds on imagery/metaphor (node 008) but does not address other devices like foreshadowing, allegory, or devices in other texts. It focuses on how these devices serve the story's thematic core: the conflict between systemic corruption and individual conscience.

## WALKTHROUGH
Imagine you spend weeks preparing a project honestly, but a classmate copies last-minute and gets higher marks — that bitter gap between effort and outcome is situational irony. Now open "Udd ka Naksha": notice how Vyasingh, the "corrupt" policeman, accidentally does more good by his trickery than the "honest" system ever did. That reversal is the story's central irony. Next, track the recurring "map" (naksha) — it starts as a literal survey document but becomes a symbol of moral navigation. Ask: what does the heart (udd) map? Not land, but loyalty. Your first step: list every moment where expectation flips. Second: flag objects that carry extra weight (the map, the job offer, the father's turban). Third: connect each to the theme of integrity versus survival.

## DIAGNOSTIC_QUESTION_1
Define situational irony and give one example from daily life (not from the story).

## DIAGNOSTIC_ANSWER_1
Situational irony occurs when the outcome of a situation is sharply contrary to what was expected or intended. Example: A fire station burning down while firefighters are out on a call. A wrong answer (e.g., "irony is just a coincidence" or "irony is when something funny happens") reveals the student conflates irony with mere surprise or humour, missing the structural contradiction between expectation and result that defines the device.

## DIAGNOSTIC_QUESTION_2
In "Udd ka Naksha," Vyasingh frames Eka Okha to secure him a government job. Explain why this is situational irony, not just a plot twist.

## DIAGNOSTIC_ANSWER_2
It is situational irony because Vyasingh's corrupt act (framing an innocent man) produces the opposite of its intended harm: it grants Eka Okha the secure livelihood and dignity that the "honest" system denied him. The outcome — a poor man's salvation through a crook's scheme — inverts the moral expectation that virtue rewards virtue. A wrong answer (e.g., "it's ironic because Vyasingh is bad") shows the student identifies character contrast but misses the structural reversal of intended vs. actual consequence.

## DIAGNOSTIC_QUESTION_3
Identify the central symbol in the story's title "Udd ka Naksha" and explain what abstract concept it represents, using one textual detail.

## DIAGNOSTIC_ANSWER_3
The "map of the heart" (udd ka naksha) symbolises moral orientation — the inner compass that guides choices between conscience and compromise. Textual detail: The story ends with Eka Okha literally holding a survey map while having proven his loyalty to truth over tenure, making the physical map a metaphor for his ethical bearings. A wrong answer (e.g., "it's just a map of the village") treats the symbol as literal setting, ignoring the abstraction (heart = conscience, map = guidance) that the title establishes.

## DIAGNOSTIC_QUESTION_4
Compare the dramatic irony in the scene where the British officer praises Vyasingh's "loyalty" with the verbal irony in Eka Okha's final refusal of the job. How do they target different aspects of colonial power?

## DIAGNOSTIC_ANSWER_4
Dramatic irony: the officer (and reader) knows Vyasingh manipulated the system, but the officer praises him as a model servant — exposing colonial bureaucracy's blindness to its own corruption. Verbal irony: Eka Okha says "I don't need your favour" while accepting the dignity the job offered — his words reject the patronage, but his act claims the self-respect the system tried to buy. Together, they dismantle colonial authority from both ends: the ruler's ignorance and the subject's resistance. A wrong answer that merely lists the two scenes without contrasting their targets (institutional blindness vs. individual agency) shows fragmented analysis.

## DIAGNOSTIC_QUESTION_5
Evaluate: Is the story's ending — Eka Okha unemployed but morally intact — a symbolic victory or a practical defeat? Defend your judgment with two pieces of evidence.

## DIAGNOSTIC_ANSWER_5
It is a symbolic victory. Evidence 1: Eka Okha returns the appointment letter, choosing poverty over complicity, making his empty hands a symbol of uncompromised conscience. Evidence 2: The final image of him walking away "with his head high" (sir uncha karke) transforms material loss into moral stature, aligning with the title's "map of the heart" — he has navigated correctly. A response calling it "defeat because he lost the job" prioritises plot outcome over thematic resolution, missing how Premchand uses symbolism to redefine victory in a colonised society.

## DIAGNOSTIC_QUESTION_6
Write a 4-line paragraph using verbal irony to describe a modern situation where a corrupt official is honoured for "transparency." Do not name the device explicitly.

## DIAGNOSTIC_ANSWER_6
The anti-corruption award glittered in his palms, polished by the very files he buried. "A beacon of integrity," the citation read, while his locker swallowed another crore. The audience clapped louder, grateful for such rare honesty. He smiled, knowing the best hideouts are built on applause. A poor answer would state the irony directly ("It is ironic that...") or write a sincere description, showing the student cannot wield the device — only recognise it.

## COMMON_MISCONCEPTION
Students often treat every unexpected event as irony, labelling coincidence ("Vyasingh met Eka Okha by chance") or misfortune ("Eka Okha lost his father") as ironic. They also confuse symbols with motifs, calling the recurring "turban" a symbol of honour without explaining how it *represents* an abstract idea (e.g., inherited duty vs. personal choice). The root error: they hunt for devices like items on a checklist instead of asking "What contrast does this create?" or "What idea does this object carry beyond itself?"

## ON_FAILURE
1. **Isolate the expectation**: Have the student write two columns — "What characters/readers expect" vs. "What actually happens" — for three key scenes. 2. **Symbol autopsy**: Pick one object (the map, the turban, the job letter). Ask: "If this object could speak, what abstract truth would it tell?" 3. **Re-read with a lens**: Assign a 5-minute re-read of the climax *only* tracking the map's appearances. 4. **Write one analytical sentence**: "The map symbolises X because the text shows Y when Z happens." Repeat until the pattern clicks.

## BUILDS_ON
Imagery and metaphor (node 008) established how sensory details carry suggestive meaning; irony and symbolism extend this by structuring whole narrative arcs around contradiction and representation.

## LEADS_TO
Critical thinking: analysis and interpretation (node 013) where students synthesise devices into thematic arguments, and comprehension (node 012) where device-awareness sharpens inferential answers.

## PREREQUISITE_NODE_IDS
c11_hin_ar_cbse_01_008, c11_hin_ar_cbse_01_002, c11_hin_ar_cbse_01_004, c11_hin_ar_cbse_01_001, c11_hin_ar_cbse_01_006

## PREREQUISITE_REASONS
c11_hin_ar_cbse_01_008: Imagery/metaphor training enables recognition of how concrete details (map, turban) operate symbolically.
c11_hin_ar_cbse_01_002: Plot knowledge provides the event sequence needed to spot expectation-outcome gaps (irony).
c11_hin_ar_cbse_01_004: Understanding Vyasingh and Eka Okha as characters is essential to see how their actions generate dramatic/verbal irony.
c11_hin_ar_cbse_01_001: "Context and Background" refers to the historical, social, biographical, and literary circ... की समझ आवश्यक है, क्योंकि यह नोड (Irony is a literary device where the intended meaning of words or events is opposite to th...) इसी आधार पर आगे बढ़ता है।  
c11_hin_ar_cbse_01_006: Irony and symbolism deepen the thematic expression.  

## FORWARD_NODE_IDS
c11_hin_ar_cbse_01_010, c11_hin_ar_cbse_01_012, c11_hin_ar_cbse_01_013, c12_hin_a_cbse_01_009, c12_hin_a_cbse_02_009, c12_hin_a_cbse_05_009, c12_hin_a_cbse_06_009, c12_hin_a_cbse_09_009, c12_hin_a_cbse_10_009, c12_hin_a_cbse_12_009, c12_hin_a_cbse_17_009, c12_hin_al_cbse_01_009, c12_hin_al_cbse_02_009, c12_hin_al_cbse_03_009, c12_hin_ar_cbse_01_009, c12_hin_ar_cbse_02_009, c12_hin_ar_cbse_03_009, c12_hin_ar_cbse_05_009, c12_hin_ar_cbse_09_009, c12_hin_ar_cbse_12_009

## FORWARD_REASONS
c11_hin_ar_cbse_01_010: Vocabulary in context (e.g., "naksha," "eaman," "farz") gains depth when students see how words function as symbols.
c11_hin_ar_cbse_01_012: Inferential comprehension questions often ask "What does the map represent?" or "Why is the ending ironic?" — direct application.
c11_hin_ar_cbse_01_013: Critical thinking requires evaluating how devices shape meaning — the capstone skill this node prepares.
c12_hin_a_cbse_01_009: अगला तार्किक चरण: Irony (विरोधाभास/व्यंग्य) in poetry is a literary device where the intended meaning of words or situ... इस नोड की अवधारणाओं को सीधे उपयोग/विस्तारित करता है।  
c12_hin_a_cbse_02_009: Class 11 introduced definitions and basic identification of irony/symbolism; this node demands contextual, dynamic analysis in a specific poetic text.  
c12_hin_a_cbse_05_009: अगला तार्किक चरण: Irony is a literary device where the intended meaning of words or a situation is opposite to their l... इस नोड की अवधारणाओं को सीधे उपयोग/विस्तारित करता है।  
c12_hin_a_cbse_06_009: Class 11 Antra Chapter 1 introduced irony and symbolism definitions and basic identification; this node deepens to multi-text analysis and board-style answer writing.  
c12_hin_a_cbse_09_009: Provides foundational definitions of irony and symbolism from Class 11 that this node deepens with complex textual application.  
c12_hin_a_cbse_10_009: Class 11 Antra Chapter 1 introduced irony/symbolism basics with simpler texts — foundational definitions and identification practice.  
c12_hin_a_cbse_12_009: Class 11 Irony and Symbolism node introduced the definitions and basic identification; this Class 12 node deepens into multi-layered analysis and thematic integration specific to "Laafank."  
c12_hin_a_cbse_17_009: Class 11 foundation on irony/symbolism definitions and basic identification — this node assumes that fluency.  
c12_hin_al_cbse_01_009: Class 11 Antra Chapter 1 Irony and Symbolism node introduces basic definitions and identification in a simpler text.  
c12_hin_al_cbse_02_009: Class 11 foundation on irony/symbolism definitions and identification techniques.  
c12_hin_al_cbse_03_009: Class 11 introduced irony and symbolism definitions and basic identification; this node applies them to a complex non-fiction narrative.  
c12_hin_ar_cbse_01_009: Class 11 foundation on irony/symbolism definitions and basic identification across multiple chapters.  
c12_hin_ar_cbse_02_009: Provides the Class 11 baseline definitions and simple examples of irony and symbolism that this node deepens.  
c12_hin_ar_cbse_03_009: Early Class 11 exposure establishes the terminology; this node assumes familiarity with terms like "situational irony" and "contextual symbol."  
c12_hin_ar_cbse_05_009: अगला तार्किक चरण: Irony (व्यंग्य/विडंबना) is a literary device where the intended meaning of words or situations is op... इस नोड की अवधारणाओं को सीधे उपयोग/विस्तारित करता है।  
c12_hin_ar_cbse_09_009: Class 11 introduction to irony and symbolism gives the basic definitions and simple examples.  
c12_hin_ar_cbse_12_009: अगला तार्किक चरण: Irony in this story is the contrast between appearance and reality — where the wealthy waste water c... इस नोड की अवधारणाओं को सीधे उपयोग/विस्तारित करता है।  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
None available from prior class nodes for Hindi Aroh.

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_01_008 -> c11_hin_ar_cbse_01_009 -> c11_hin_ar_cbse_01_013

## THIS_FORMULA
N/A - conceptual

## FORMULA_VARIABLES
N/A

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
analytical

## CROSS_SUBJECT
c11_history_colonialism | The story's critique of colonial bureaucracy (British officer, government jobs, loyalty oaths) mirrors History's study of colonial administrative structures and Indian responses — irony and symbolism become literary evidence of historical resistance.
c11_sociology_social_structure | Vyasingh and Eka Okha embody clashing value-systems (pragmatic corruption vs. principled poverty) — Sociology's analysis of role conflict and status inconsistency in stratified societies is enacted through these devices.

## PREREQ_CONCEPT
Understanding that literary devices are not decorative but structural — they organise the reader's moral and intellectual response to the narrative.

## PREREQ_BEFORE
Student must recall the story's key events (Vyasingh's framing, the job offer, Eka Okha's refusal) and character motivations without re-reading the full text.

## PREREQ_STUCK
If stuck, review the climax (Eka Okha tearing the appointment letter) and the opening (Vyasingh's monologue about "heart's map") — these two poles generate the story's central irony and symbol.

## WORKED_EXAMPLE_1
PROBLEM: Analyse how the "turban" (pagri) functions as a symbol in the conversation between Eka Okha and his father's memory. Provide textual evidence and explain its thematic contribution.

STEPS:
- Step 1: Locate the turban references — father's turban as "honour's crown" (maan ka taj), Eka Okha touching it before decisions, the British officer demanding its removal.
- Step 2: Identify the abstract ideas attached — inherited integrity, communal identity, resistance to colonial erasure.
- Step 3: Trace the symbol's arc — from father's living presence to memory object to contested site (officer's order) to Eka Okha's final adjustment (he straightens it, not removes it).
- Step 4: Connect to theme — the turban symbolises the non-negotiable self that colonial power cannot strip; Eka Okha's refusal to remove it mirrors his refusal of the compromised job.
- Step 5: Verify — does the text support this? Yes: "pagri utarna matlab apni pehchan mitana" (removing turban = erasing identity) is explicitly stated in the dialogue.

REASONING: This stepwise move from concrete object → associated abstractions → narrative arc → thematic function models the analytical chain students must internalise for board answers.

ANSWER: The turban symbolises inherited moral identity. Initially, it represents the father's legacy of honesty ("maan ka taj"). When the British officer orders its removal, it becomes the site of colonial humiliation versus cultural dignity. Eka Okha's act of straightening rather than removing it — "pagri theek ki, utari nahi" — enacts the story's core: integrity survives by adapting posture, not surrendering essence. This symbol anchors the theme that true honour is internal, not conferred by external authority.

## WORKED_EXAMPLE_2
PROBLEM: Identify and explain the dramatic irony in the scene where the British officer awards Vyasingh the "Rai Bahadur" title for "exemplary service."

STEPS:
- Step 1: Define dramatic irony — reader knows something a character (here, the officer) does not.
- Step 2: Establish the knowledge gap — reader knows Vyasingh fabricated the survey, framed Eka Okha, and manipulated records; the officer believes the official report.
- Step 3: Pinpoint the ironic moment — the citation praises "transparency," "loyalty," and "precision" — the exact qualities Vyasingh violated.
- Step 4: Analyse the effect — the honour legitimises corruption, exposing the colonial system's dependence on false paperwork over ground truth.
- Step 5: Link to broader critique — this moment mirrors how colonial governance rewarded performative compliance, making Vyasingh a symbol of systemic rot.

REASONING: Dramatic irony requires a three-part structure (reader knowledge, character ignorance, textual moment of collision). This example trains students to map all three before writing.

ANSWER: The dramatic irony lies in the British officer awarding Vyasingh "Rai Bahadur" for "exemplary transparency and loyalty" while the reader knows Vyasingh forged the very survey the citation celebrates. The officer's ignorance — "a model servant of the Crown" — clashes with the documented reality of bribery, coercion, and falsified maps. This irony does not just mock Vyasingh; it indicts a bureaucratic machine that mistakes paperwork for truth. The title becomes a medal for deception, symbolising how colonial authority sustains itself on manufactured realities.

## WORKED_EXAMPLE_3
PROBLEM: Compare the situational irony of Vyasingh's scheme (framing Eka Okha gets him a job) with the verbal irony of Eka Okha's final words: "Main naukri nahi chahiye, mujhe mera haq chahiye" (I don't want the job, I want my due). How do they together redefine "success" in the story?

STEPS:
- Step 1: Map Vyasingh's situational irony — corrupt means → honest outcome (Eka Okha gets secure employment).
- Step 2: Map Eka Okha's verbal irony — he rejects the job ("naukri nahi chahiye") but claims the dignity it represented ("haq").
- Step 3: Identify the shared target — both ironies attack the equation: government job = success.
- Step 4: Show the redefinition — Vyasingh's scheme proves the job is attainable without merit; Eka Okha's refusal proves the job is meaningless without self-respect.
- Step 5: Synthesise — "Success" shifts from external appointment (naksha on paper) to internal orientation (udd ka naksha).
- Step 6: Evidence — Vyasingh's later downfall (suspended for corruption) vs. Eka Okha's final walk ("sir uncha karke") confirms the story's moral geometry.

REASONING: This example combines two irony types and a symbol (the map) to demonstrate how devices collaborate — a board-level expectation where single-device analysis scores lower.

ANSWER: Vyasingh's situational irony (his corruption accidentally secures Eka Okha's livelihood) and Eka Okha's verbal irony (rejecting the job while claiming its true value — "haq") form a pincer movement on colonial success-metrics. The first proves the system rewards deceit; the second proves the subject can reclaim agency by refusing the reward. Together, they relocate "success" from the government letter (external, revocable) to the "map of the heart" (internal, inviolable). The story's final image — Eka Okha walking away with the physical map in hand but the moral map in his stride — fuses symbol and irony: the paper map is useless without the heart's orientation.

## COMPETENCY_QUESTION_1
QUESTION: In "Udd ka Naksha," the survey map begins as a tool of colonial control but ends as a symbol of Eka Okha's moral autonomy. Trace this transformation across three key moments in the story, quoting or paraphrasing textual evidence for each. Explain how the shift from external imposition to internal possession reflects the story's postcolonial critique.

COMPETENCY: Literary analysis with textual evidence and thematic synthesis

STEPS:
- Step 1: Identify Moment 1 — the map as colonial instrument (British officer orders survey for land revenue).
- Step 2: Identify Moment 2 — the map as Vyasingh's weapon (he falsifies it to frame Eka Okha).
- Step 3: Identify Moment 3 — the map as Eka Okha's reclaiming (he tears the appointment letter but keeps the map).
- Step 4: For each moment, note who holds the map and what it represents (state power, corrupt power, personal truth).
- Step 5: Synthesise — the physical object remains the same; its meaning changes with the holder's intent, proving meaning is not in the object but in the moral stance of the user.

ANSWER: Moment 1: The map is commissioned by the British officer — "sarkari naksha banao" — representing state extraction (land revenue, control). Moment 2: Vyasingh manipulates the same map — "naksha mein heraferi" — turning it into a tool of personal corruption, showing how colonial systems enable individual venality. Moment 3: Eka Okha refuses the job but retains the map — "naksha mere paas hai" — transforming it from a document of ownership into a record of his own integrity. The shift from officer's desk → Vyasingh's pocket → Eka Okha's hand mirrors the transfer of moral authority from coloniser → collaborator → resistant subject. The map's material persistence underscores the story's argument: tools of oppression can be repurposed for self-definition when conscience guides the hand.

DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: Premchand uses verbal irony in Eka Okha's dialogue with the British officer ("Huzoor, aapki meharbani se main buzdil ban jaunga" — "Sir, your kindness will make me a coward") to expose the psychological violence of colonial patronage. Analyse this line's layered irony: (a) the surface politeness vs. actual accusation, (b) the word "meharbani" (kindness) vs. the reality of coercion, (c) how "buzdil" (coward) redefines acceptance of the job as moral failure. Support each layer with textual context.

COMPETENCY: Close reading of verbal irony in socio-political context

STEPS:
- Step 1: Unpack the surface layer — Eka Okha uses honorifics ("Huzoor," "meharbani") performing the subordinate role expected by colonial etiquette.
- Step 2: Reveal the subtext — "meharbani" is ironic because the job offer is not a gift but a trap: acceptance = complicity in a fraudulent survey.
- Step 3: Analyse "buzdil" — in the story's moral economy, taking the job means endorsing Vyasingh's forgery and the officer's blindness; thus, "cowardice" = moral surrender, not physical fear.
- Step 4: Connect to the "map" symbol — the job is a false map (external validation); refusing it is the true map (internal compass).
- Step 5: Conclude — the verbal irony performs resistance within the master's language, a hallmark of Premchand's anti-colonial aesthetic.

ANSWER: (a) Surface politeness ("Huzoor, aapki meharbani") masks a direct indictment: the officer's "kindness" is the mechanism of corruption. (b) "Meharbani" is bitterly ironic — the offer is conditional on silence about Vyasingh's fraud; accepting it buys Eka Okha's conscience. The officer frames it as grace; Eka Okha names it as bribery. (c) "Buzdil" redefines the colonial subject's dilemma: physical courage (facing poverty) is honourable; moral cowardice (taking the tainted job) is shameful. The irony peaks when the "illiterate" villager schools the "educated" officer in ethics. Textual context: Eka Okha earlier tells Vyasingh, "Main bikta nahi" (I don't sell myself) — this line fulfils that promise. The verbal irony thus operates as a micro-rebellion: using the coloniser's courtesy forms to dismantle his moral authority.

DIFFICULTY: hard