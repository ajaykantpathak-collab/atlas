## DEFINITION
Secondary themes are the subordinate yet significant ideas that run parallel to the primary theme, explored through specific character perspectives, settings, or subplots to add layers of meaning and reveal the complexity of the central conflict.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student can independently identify at least two secondary themes in Vadde Gahansoh's poems, cite specific textual evidence (lines/images) for each, and explain in writing how each secondary theme intersects with and deepens the primary theme of tribal exploitation and resistance.

## SCOPE_BOUNDARY
This node covers the identification and analysis of secondary themes (gendered poverty, oral tradition as resistance, individual vs. collective voice, private/public divide) within the two poems of Chapter 14. It does not cover primary theme analysis (node 006), literary device identification (nodes 008, 009), or vocabulary/grammar (nodes 010, 011).

## WALKTHROUGH
Imagine you are listening to an elder in your village singing a folk song about a flood. The main story is the flood, but inside the lyrics you hear a mother worrying about her child's fever, a farmer mourning his lost seeds, and the singer's own voice cracking with memory. Those hidden stories—motherhood, livelihood, the singer's survival—are secondary themes. In Vadde's poems, the "flood" is tribal exploitation. To find the hidden stories, read the first poem as a collective cry (notice "हमारी झोंपड़ी") and the second as a private conversation (notice "मेरी झोंपड़ी", "मेरा पति"). Ask: *What changes when the voice shifts from 'we' to 'I'? What does the woman see that the collective doesn't?* The key insight: secondary themes live in the gaps between the collective and the individual, the field and the hut, the song and the silence.

## DIAGNOSTIC_QUESTION_1
What is the definition of a secondary theme in a literary text, and how does it differ from the primary theme?

## DIAGNOSTIC_ANSWER_1
A secondary theme is a recurring subordinate idea that supports, complicates, or contrasts with the primary theme, explored through specific subplots, character perspectives, or settings. Unlike the primary theme (the central, unifying message), secondary themes are narrower in scope but essential for textual depth. A wrong answer that equates secondary themes with "minor topics mentioned once" reveals the student cannot distinguish between a passing reference and a developed thematic thread.

## DIAGNOSTIC_QUESTION_2
In the first poem, the speaker describes the landlord's courtyard and the police station as sites of power. Besides exploitation, what secondary theme emerges from the spatial contrast between the "hut in the field" and the "landlord's courtyard"?

## DIAGNOSTIC_ANSWER_2
The spatial contrast establishes the secondary theme of **structural displacement and spatial inequality**—the physical segregation of the tribal poor (marginal huts) from centers of power (courtyards, police stations). This shows exploitation is not just economic but geographic. A wrong answer focusing only on "rich vs poor" misses the spatial dimension that makes displacement tangible and mappable.

## DIAGNOSTIC_QUESTION_3
The second poem is a dialogue between Vadde and her husband. Identify two secondary themes unique to this domestic conversation and provide one textual anchor (image/line) for each.

## DIAGNOSTIC_ANSWER_3
1. **Gendered experience of poverty**: Vadde's focus on the hut's decay ("टपकती झोंपड़ी", "दीवारें गिर रही हैं") and her bodily labor anchors the theme—poverty is lived domestically and physically by women. 2. **Intimate resistance through voice**: Her direct address ("तुम सुनो", "मेरा कहा मानो") asserts agency within patriarchy. A wrong answer listing only "poverty" or "marriage" fails to isolate the *gendered* and *resistive* nuances developed specifically in the second poem.

## DIAGNOSTIC_QUESTION_4
Compare the collective pronouns ("हमारा", "हम") in the first poem with the individual pronouns ("मेरी", "मेरा", "मैं") in the second. How does this pronoun shift reveal the secondary theme of the **individual vs. collective** in tribal resistance?

## DIAGNOSTIC_ANSWER_4
The first poem uses collective pronouns to frame exploitation as a shared tribal condition (communal identity), while the second shifts to individual pronouns to personalize the struggle (Vadde's specific hut, husband, body). This reveals that resistance operates at two levels: the collective political cry and the individual domestic survival. A wrong answer claiming both poems use the same "voice" ignores the deliberate strategic shift from "we" to "I" that maps the secondary theme.

## DIAGNOSTIC_QUESTION_5
The introductory note states these poems were "sung in Gondi," "preserved orally," and later translated. Evaluate whether the **preservation of oral tradition** functions as a secondary theme equally important to the content of the poems. Justify using the note and the poems.

## DIAGNOSTIC_ANSWER_5
Yes. The note's emphasis on "first written document" (पहला लिखित दस्तावेज) and the act of translation frames the *existence of the text itself* as resistance against cultural erasure. Poem 1's collective song form and Poem 2's dialogic structure mimic oral performance, making the *form* a carrier of the theme. A wrong answer treating the note as mere "background information" misses the meta-thematic layer: the poems are not just *about* resistance; their preservation *is* resistance.

## DIAGNOSTIC_QUESTION_6
Write a 4-line stanza in the style of Vadde's second poem (addressing the husband, domestic setting, simple rhythm) that introduces a new secondary theme: **the tension between traditional knowledge and modern schooling**.

## DIAGNOSTIC_ANSWER_6
A strong stanza would: (a) use direct address ("सुनो जी"), (b) reference a concrete domestic detail (fire, child, book), (c) show the tension (child reads but forgets the song), (d) maintain the conversational, rhythmic tone. Example: *"सुनो जी, लड़का स्कूल गया / किताब पढ़ी, गीत भुला दिया / चूल्हे की राख अब ठंडी है / बाप-दादा की बात नहीं रही।"* A poor answer would be abstract, lack the dialogic form, or use literary Hindi instead of the raw, spoken register.

## COMMON_MISCONCEPTION
Students often believe secondary themes are simply "other topics mentioned in the text" (e.g., "the poem mentions a hut, so 'huts' is a theme"). This confuses **motif** (recurring object/image) with **theme** (idea developed through that motif). In Vadde's poems, the "hut" is a motif; the *theme* is "domestic space as a site of gendered vulnerability and resistance." The error arises because students stop at noun-identification instead of asking: *What idea about the hut is being argued across the poem?*

## ON_FAILURE
If the student conflates motif and theme: 1) Have them list 5 nouns repeated in both poems (hut, field, landlord, song, body). 2) For each noun, ask: "What *idea* does the poet attach to this noun? Complete: 'The hut represents ___.'" 3) Group the completed sentences: which ones cluster together? (e.g., hut + body + domestic labor = gendered poverty). 4) Label each cluster a secondary theme. 5) Verify: does this cluster appear in *both* poems or develop across stanzas? If yes, it's a theme.

## BUILDS_ON
This node builds on the primary theme analysis (c11_hin_ar_cbse_14_006) where students established the central conflict of tribal exploitation and resistance.

## LEADS_TO
This node enables deeper analysis of literary devices (c11_hin_ar_cbse_14_008, c11_hin_ar_cbse_14_009) by providing thematic anchors for imagery, irony, and symbolism, and feeds into critical thinking (c11_hin_ar_cbse_14_013) and writing tasks (c11_hin_ar_cbse_14_014).

## PREREQUISITE_NODE_IDS
c11_hin_ar_cbse_14_001, c11_hin_ar_cbse_14_002, c11_hin_ar_cbse_14_003, c11_hin_ar_cbse_14_004, c11_hin_ar_cbse_14_005, c11_hin_ar_cbse_14_006
## PREREQUISITE_REASONS
c11_hin_ar_cbse_14_001: Context on Gond tribe and Vadde's life is essential to decode cultural references in secondary themes.
c11_hin_ar_cbse_14_002: Narrative structure of the two poems (collective song vs. domestic dialogue) determines where secondary themes surface.
c11_hin_ar_cbse_14_003: Setting (field, hut, courtyard) provides the spatial mapping for themes like displacement and private/public divide.
c11_hin_ar_cbse_14_004: Protagonist analysis (Vadde as a tribal woman poet) grounds the gendered secondary theme in a specific voice.
c11_hin_ar_cbse_14_005: Supporting characters (husband, landlord) embody the power dynamics that secondary themes critique.
c11_hin_ar_cbse_14_006: Primary theme (exploitation/resistance) is the anchor; secondary themes are defined by their relation to it.

## FORWARD_NODE_IDS
c11_hin_ar_cbse_14_008, c11_hin_ar_cbse_14_009, c11_hin_ar_cbse_14_012, c11_hin_ar_cbse_14_013, c11_hin_ar_cbse_14_014, c11_hin_ar_cbse_14_015, c12_hin_a_cbse_01_007, c12_hin_a_cbse_08_007, c12_hin_a_cbse_10_007, c12_hin_a_cbse_14_007, c12_hin_a_cbse_15_007

## FORWARD_REASONS
c11_hin_ar_cbse_14_008: Imagery (leaking hut, courtyard) and metaphor (body as field) are vehicles for secondary themes.
c11_hin_ar_cbse_14_009: Irony (song as weapon) and symbolism (hut = fragility/resilience) deepen secondary themes.
c11_hin_ar_cbse_14_012: Comprehension questions often ask: "Identify the theme of..." or "How does the poem show...?"
c11_hin_ar_cbse_14_013: Critical interpretation requires synthesizing primary and secondary themes into a coherent reading.
c11_hin_ar_cbse_14_014: Writing tasks (article, speech, letter) demand thematic depth beyond the main idea.
c11_hin_ar_cbse_14_015: Secondary themes (gender, class, silence) provide multiple discussion entry points.  
c12_hin_a_cbse_01_007: Chapter 14 wrote essays on themes.  
c12_hin_a_cbse_08_007: अगला तार्किक चरण: Secondary themes are the underlying, complementary ideas in a literary work that support, contrast w... इस नोड की अवधारणाओं को सीधे उपयोग/विस्तारित करता है।  
c12_hin_a_cbse_10_007: Links thematic analysis to board exam answer structures.  
c12_hin_a_cbse_14_007: Class 11 foundation on secondary themes in the same chapter.  
c12_hin_a_cbse_15_007: "भक्तिन" chapter's secondary themes (gender, caste, memory) provide comparative framework.  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
none

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_14_006 -> c11_hin_ar_cbse_14_007 -> c11_hin_ar_cbse_14_008

## THIS_FORMULA
N/A - conceptual

## FORMULA_VARIABLES
N/A

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
conceptual

## CROSS_SUBJECT
c11_history_tribal_societies | The secondary themes of displacement, oral tradition, and state power (police, court) in Vadde's poems directly mirror History's study of tribal societies under colonial and post-colonial forest laws and land alienation.
c11_sociology_social_inequality | The gendered poverty theme (woman's domestic burden, patriarchal conversation) and spatial inequality (hut vs courtyard) exemplify sociological concepts of intersectionality (caste/tribe + gender + class) and spatial segregation.

## PREREQ_CONCEPT
The student must have a clear, written statement of the primary theme (tribal exploitation and resistance through voice) from node 006 to use as the benchmark against which secondary themes are measured.

## PREREQ_BEFORE
The student should have read both poems completely, understood the introductory note about translation/oral preservation, and completed the character/setting analysis of nodes 003-005.

## PREREQ_STUCK
If stuck, re-read the introductory note (पृष्ठ 135-136) for the meta-context of oral preservation, and annotate the two poems for pronoun shifts (हम vs मैं) and setting shifts (field/courtyard vs hut/home).

## WORKED_EXAMPLE_1
PROBLEM: Identify the secondary theme of "gendered experience of poverty" in the second poem and support with three distinct textual evidences analyzed using PEEL structure.

STEPS:
- Step 1: Define the secondary theme: Poverty is not gender-neutral; Vadde's speech reveals how tribal women bear the domestic, physical, and emotional brunt of exploitation differently from men.
- Step 2: Scan the second poem for Vadde's specific concerns (not the husband's). Mark lines about the hut's condition, her body, and her speech acts.
- Step 3: Evidence 1 (Domestic space): The detailed description of the leaking hut ("छप्पर टपकता", "दीवारें गिरती") – Vadde monitors the shelter, making the hut an extension of her body/labor.
- Step 4: Evidence 2 (Bodily labor): Her reference to carrying loads, working the field, and the physical toll ("कमर टूट गई") – poverty is inscribed on the female body.
- Step 5: Evidence 3 (Voice as agency): Her imperative commands to the husband ("सुनो", "मानो", "जाओ") – she initiates action, resisting passivity.
- Step 6: Synthesis: These three strands (space, body, voice) form a cohesive sub-theme that intersects with the primary theme: exploitation is total because it is gendered.

REASONING: This models the PEEL (Point, Evidence, Explanation, Link) method required for board answers. It moves from thematic definition to close reading to structural synthesis, showing how a secondary theme is *built* from textual details.

ANSWER: The secondary theme of gendered poverty emerges through Vadde's proprietary care for the hut (domestic space as female domain), her articulated bodily exhaustion (labor as embodied suffering), and her directive speech (voice as resistance within patriarchy). Together, they prove that tribal exploitation operates through gender, making the woman's hut both a site of oppression and a platform for agency.

## WORKED_EXAMPLE_2
PROBLEM: Trace the secondary theme of "oral tradition as cultural resistance" across the introductory note and both poems. Write a structured analytical paragraph.

STEPS:
- Step 1: Locate the meta-data in the introductory note: "गोंडी में कविताएँ... मौखिक परंपरा में सुरक्षित", "हिंदी अनुवाद", "पहला लिखित दस्तावेज". This frames the *act of recording* as resistance to erasure.
- Step 2: Analyze Poem 1's form: Collective "हम", repetitive rhythm ("हाय रे", "हाय रे"), direct address to oppressors – features of oral protest song designed for communal singing and memorization.
- Step 3: Analyze Poem 2's form: Dialogue structure (Vadde ↔ husband), colloquial register ("पट्टी", "पटवारी"), immediate present tense – mimics a live performance, preserving the *voice* not just the words.
- Step 4: Connect form to theme: The poems do not just *describe* resistance; their oral-form-in-print *enacts* preservation. The translator (Flag) becomes a co-resister by fixing the fluid oral text.
- Step 5: Draft paragraph using PEEL: Point (oral preservation is a secondary theme), Evidence (note + Poem 1's collectivity + Poem 2's dialogic orality), Explanation (form = resistance), Link (deepens primary theme: voice survives writing).

REASONING: This example teaches intertextual thematic tracing (note + poem 1 + poem 2) and the sophisticated concept that *literary form carries thematic weight*—a key Class 11 analytical skill.

ANSWER: The secondary theme of oral tradition as resistance operates meta-textually: the note's emphasis on "first written document" reveals the precarity of Gond oraliture; Poem 1's choric structure ("हमारी झोंपड़ी", "हाय रे") preserves the collective protest song; Poem 2's dramatic dialogue freezes a living conversation. The text thus becomes an archive, making the *preservation of voice* a thematic act parallel to the *content of voice*.

## WORKED_EXAMPLE_3
PROBLEM: Compare the secondary theme of "displacement" in Poem 1 (macro/structural) and Poem 2 (micro/domestic). Write a 100-word comparative analysis using the "Private/Public Divide" framework.

STEPS:
- Step 1: Define the framework: Public sphere = landlord's courtyard, police station, court (Poem 1). Private sphere = hut, marital bed, woman's body (Poem 2).
- Step 2: Poem 1 evidence: "जमींदार के आँगन में", "थाने-कचहरी" – displacement as legal/spatial expulsion from land to margin.
- Step 3: Poem 2 evidence: "मेरी झोंपड़ी टपकती है", "दीवारें गिर रही हैं" – displacement as domestic collapse; the hut fails to protect.
- Step 4: Analyze the link: The public seizure of land (Poem 1) *causes* the private rotting of the hut (Poem 2). The landlord's courtyard and the leaking hut are two ends of the same extraction pipeline.
- Step 5: Evaluate significance: The private/public divide is porous; state power (police) enters the hut, and the hut's decay fuels the public protest.
- Step 6: Write comparative paragraph with transition words (जहाँ... वहाँ..., इसके विपरीत, इस प्रकार).

REASONING: This practices comparative analysis across two texts within one chapter—a frequent board exam pattern (e.g., "Compare the treatment of X in the two poems"). It forces the student to use a conceptual framework (public/private) rather than just listing similarities/differences.

ANSWER: Poem 1 maps displacement structurally: the tribal hut is pushed to the field's edge while the landlord's courtyard and state institutions (police, court) occupy the center. Poem 2 maps the same displacement domestically: the hut's leaking roof and crumbling walls make the loss of land palpable in the woman's daily life. The public seizure (Poem 1) and private decay (Poem 2) are causally linked—land alienation *produces* the uninhabitable hut. Vadde's dialogue bridges the spheres: she sends her husband to the public arena ("जाओ, पटवारी से कहो") because the private shelter has failed. The secondary theme thus reveals exploitation as a total invasion of both spheres.

## COMPETENCY_QUESTION_1
QUESTION: The chapter includes an introductory note by the translator (Flag) describing the poems as "the first written document of Gond resistance." How does this paratextual framing function as a meta-commentary on the secondary theme of **preservation of tribal voice**? Answer in 80-100 words with specific reference to the note.

COMPETENCY: Analytical writing with textual evidence (meta-textual analysis)

STEPS:
- Step 1: Identify the paratext: Flag's note on pages 135-136 describing the collection/translation process.
- Step 2: Define the secondary theme: Preservation of voice = resisting cultural erasure by fixing oral poems in print.
- Step 3: Select evidence: "मौखिक परंपरा में सुरक्षित", "हिंदी में अनुवाद", "पहला लिखित दस्तावेज", "लिखित रूप में प्रस्तुत".
- Step 4: Explain the meta-function: The note *performs* the theme it describes—by telling us *how* the poems survived, it makes the reader witness the act of preservation.
- Step 5: Link to poems: This framing elevates the poems from "tribal literature" to "acts of archival resistance."

ANSWER: Flag's note acts as a meta-commentary by explicitly narrating the journey from oral Gondi song to printed Hindi text, transforming the *process of preservation* into a thematic statement. Phrases like "मौखिक परंपरा में सुरक्षित" and "पहला लिखित दस्तावेज" frame the book itself as a site of resistance against the silencing of tribal voices. The note does not merely introduce the poems; it testifies that their survival in writing is a political act, making "preservation" a secondary theme enacted by the chapter's very existence.

DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: "Vadde's second poem shifts the gaze from the landlord's courtyard to the leaking hut." Using this shift, evaluate how the secondary theme of **the private/public divide** deepens the primary theme of exploitation. Write a 120-word response with at least two specific textual references (one from each poem).

COMPETENCY: Critical evaluation and synthesis (comparative thematic analysis)

STEPS:
- Step 1: Define the divide: Public = landlord's courtyard, police station, court (Poem 1). Private = hut, marital conversation, woman's body (Poem 2).
- Step 2: Poem 1 reference: "जमींदार के आँगन में" / "थाने-कचहरी" – exploitation as public, institutional performance.
- Step 3: Poem 2 reference: "मेरी झोंपड़ी टपकती है" / "तुम सुनो, मेरा कहा मानो" – exploitation as intimate, domestic reality.
- Step 4: Argue the collapse: The public power *invades* the private hut (leaks = neglect caused by land alienation); the private voice *challenges* public power (Vadde sends husband to court).
- Step 5: Conclude: The divide is a false binary; exploitation is total because it bridges both.

ANSWER: The first poem frames exploitation in the public arena—"जमींदार के आँगन" and "थाने-कचहरी" represent institutional power seizing land legally and violently. The second poem collapses this arena into the private hut: "मेरी झोंपड़ी टपकती है, दीवारें गिर रही हैं" shows how public dispossession rots the domestic shelter. Vadde's command "तुम जाओ, पटवारी से कहो" bridges the spheres—she deploys the private voice to confront the public record. The private/public divide is thus porous; the landlord's courtyard causes the hut's leak, and the hut's leak fuels the protest at the courtyard. This secondary theme deepens the primary one by proving exploitation is not an event "out there" but a condition "in here"—total, embodied, and inescapable.

DIFFICULTY: hard