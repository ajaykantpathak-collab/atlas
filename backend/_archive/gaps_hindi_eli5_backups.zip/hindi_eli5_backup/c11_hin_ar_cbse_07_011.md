## DEFINITION
Language Usage in the Text refers to the specific grammatical structures, vocabulary choices (especially Tatsam and administrative/botanical terminology), and syntactic patterns employed by the author Phanishwar Nath Renu in "टेकु का इस्म+" to convey the satirical tone, bureaucratic absurdity, and emotional depth of the narrative. It includes the use of compound sentences (la;qDr okD;) to reflect procedural complexity, precise Tatsam terms to mirror official language, and factual description (lk{kkRdkj) as a narrative device.

## COGNITIVE_LEVEL
apply

## MASTERY_CRITERIA
The student must be able to: (1) correctly use at least five Tatsam words from the text in original sentences that reflect their administrative/botanical context, (2) transform a given compound sentence from the text into two or more simple sentences without losing meaning or nuance, and (3) write a 80-100 word factual description of the old man's struggle using at least three text-specific terms.

## SCOPE_BOUNDARY
This node covers only the grammar exercises explicitly given in the textbook's "Hkk"kk dh ckr" section for Chapter 7: Tatsam word usage, compound-to-simple sentence transformation, and factual description writing. It does NOT cover general Hindi grammar topics like samas, sandhi, alankar, or verb conjugations unless they appear in the selected exercises.

## WALKTHROUGH
Imagine you are a forest officer reading the official order to cut Teku's tree – the language is cold, complex, and full of terms like "iQkWjsLV fMikVZeasV" and "gkWVhZdYpj fMikVZeasV". Now ask: why does Renu use such words in a story about a simple villager? First, identify all Tatsam words in the "Hkk"kk dh ckr" list and note their English equivalents (e.g., iQkWjsLV fMikVZeasV = Conservator of Forests). Next, locate the compound sentence in the exercise ("bldh ppkZ 'kgj esa Hkh iSQy xbZ vkSj 'kke rd xyh&xyh ls 'kk;j tek gksus 'kq: gks x,A") and mark the coordinating conjunction "vkSj" and the two independent clauses. Then, practice breaking it into two simple sentences while keeping the original tense and subject. Finally, attempt the factual description by adopting the voice of a reporter: gather facts from the story (tree's age, departments involved, old man's actions) and weave them with the learned terminology. The key insight: Renu's language choices are not decorative; they are the weapon of satire.

## DIAGNOSTIC_QUESTION_1
List the nine Tatsam words given in the "Hkk"kk dh ckr" section of the chapter and write the Hindi meaning of any three as provided in the 'kCn Nfo' section.

## DIAGNOSTIC_ANSWER_1
The nine words are: vts±V, iQkWjsLV fMikVZeasV, esacj, fMIVh lsozsQVjh, phI+kQ lsozsQVjh, fefuLVj, vaMj lsozsQVjh, gkWVhZdYpj fMikVZeasV, ,xzhdYpj fMikVZesaV. Meanings (any three): vts±V = accordingly/thus; gkWVhZdYpj fMikVZeasV = Chief Conservator of Forests; rxkI+kqQy = opposition/obstacle. A wrong answer (e.g., confusing fMIVh lsozsQVjh with phI+kQ lsozsQVjh) reveals the student has not distinguished the hierarchical administrative designations, which is crucial for understanding the bureaucratic satire.

## DIAGNOSTIC_QUESTION_2
Explain in your own words why the author uses a compound sentence (la;qDr okD;) like "bldh ppkZ 'kgj esa Hkh iSQy xbZ vkSj 'kke rd xyh&xyh ls 'kk;j tek gksus 'kq: gks x,A" instead of two simple sentences in the narrative.

## DIAGNOSTIC_ANSWER_2
The compound sentence mirrors the unbroken, suffocating spread of the news and the simultaneous progression of two events (crowd gathering and poet's fame spreading) – reflecting how bureaucracy and rumour work in tandem. A wrong answer that only defines "la;qDr okD;" as "two sentences joined by a conjunction" shows the student understands the structure but misses the stylistic function: the conjunction "vkSj" creates a breathless flow that mimics the uncontrollable spread of the story, a key satirical device.

## DIAGNOSTIC_QUESTION_3
Transform the following compound sentence from the text into two simple sentences (ljy okD;), ensuring both retain the original past tense and subject focus: "lsozsQVsfj;sV dk ykWu Hkk¡fr&Hkk¡fr osQ dfo;ksa ls Hkj x;k vkSj ncs gq, vkneh osQ pkjksa vksj dfo&lEesyu dk&lk okrkoj.k mRi  gks x;kA"

## DIAGNOSTIC_ANSWER_3
Step 1: Identify the two independent clauses joined by "vkSj": (a) "lsozsQVsfj;sV dk ykWu Hkk¡fr&Hkk¡fr osQ dfo;ksa ls Hkj x;k" (b) "ncs gq, vkneh osQ pkjksa vksj dfo&lEesyu dk&lk okrkoj.k mRi  gks x;k". Step 2: Keep the subject of first clause ("lsozsQVsfj;sV dk ykWu") and verb ("Hkj x;k"). Step 3: For second clause, the subject is "ncs gq, vkneh osQ pkjksa vksj" and verb phrase "dfo&lEesyu dk&lk okrkoj.k mRi  gks x;k". Step 4: Write as two separate sentences ending with full stops. Result: "lsozsQVsfj;sV dk ykWu Hkk¡fr&Hkk¡fr osQ dfo;ksa ls Hkj x;k. ncs gq, vkneh osQ pkjksa vksj dfo&lEesyu dk&lk okrkoj.k mRi  gks x;k." A wrong answer that changes tense to present or drops "dk&lk" reveals inability to preserve grammatical fidelity during transformation.

## DIAGNOSTIC_QUESTION_4
Analyze how the use of the Tatsam term "iQkWjsLV fMikVZeasV" (Working Plan Officer) instead of a simpler Hindi phrase like "karya yojna adhikari" contributes to the story's satire on colonial bureaucracy.

## DIAGNOSTIC_ANSWER_4
The term "iQkWjsLV fMikVZeasV" is an exact transliteration of the British-era designation, carrying the weight of imperial forest management systems that prioritized commercial exploitation over ecological or human concerns. Its use – alongside "gkWVhZdYpj fMikVZeasV", "fMIVh lsozsQVjh" – creates a dense thicket of officialese that alienates the reader just as it alienates the villagers, making the bureaucracy feel impenetrable and absurd. A wrong answer that only translates the word misses the intertextual critique: Renu uses the colonizer's own vocabulary to expose its inhumanity.

## DIAGNOSTIC_QUESTION_5
Evaluate whether the factual description (lk{kkRdkj) exercise at the end of the chapter ("lk{kkRdkj vius&vki esa ,d foèkk gSA...") is better served by a first-person narrative ("I saw...") or a third-person objective report ("The old man was seen..."). Justify with reference to the text's tone.

## DIAGNOSTIC_ANSWER_5
Third-person objective report is more appropriate because the story itself is narrated in third person with a detached, almost reportorial tone (e.g., "ekyh us ncs gq, vkneh dks nky&Hkkr f[kyk;k"), and the exercise asks for a "foèkk" (factual description) – a genre that demands impartial observation. First-person would introduce subjectivity contrary to the "lk{kkRdkj" requirement and the text's satirical distance. A wrong answer choosing first-person because "it's more emotional" confuses the genre of factual description with personal narrative, a common board-exam error.

## DIAGNOSTIC_QUESTION_6
Create an original compound sentence (la;qDr okD;) using at least two Tatsam words from the chapter's list, describing a hypothetical bureaucratic delay in a modern government office. Then break it into simple sentences.

## DIAGNOSTIC_ANSWER_6
Compound sentence: "vaMj lsozsQVjh ne fy[kk fd iQkWjsLV fMikVZeasV ki fjiksVZ ugha aayi gS vkSj isM+ dk ekeyk vf/kd der gks x;k gSA" (The DFO wrote that the Working Plan Officer's report hasn't come and the tree's matter has become very delayed.) Simple sentences: "vaMj lsozsQVjh ne fy[kk fd iQkWjsLV fMikVZeasV ki fjiksVZ ugha aayi gS. isM+ dk ekeyk vf/kd der gks x;k gSA." A poor answer that uses Tatsam words incorrectly (e.g., "gkWVhZdYpj fMikVZeasV" for a junior clerk) shows the student hasn't internalized the hierarchical meanings, leading to inaccurate satire.

## COMMON_MISCONCEPTION
Students often treat the Tatsam words as mere vocabulary to be memorized for meaning, not realizing that Renu uses them as *precision instruments* – each term denotes a specific rank in the colonial forest hierarchy (e.g., fMIVh lsozsQVjh = Range Officer, phI+kQ lsozsQVjh = Deputy Ranger, vaMj lsozsQVjh = Divisional Forest Officer). They also mistakenly believe transforming a compound sentence simply means inserting a full stop, ignoring that the subject of the second clause may be different and must be explicitly stated in the new simple sentence (e.g., in the exercise, the first clause's subject is "lsozsQVsfj;sV dk ykWu", the second's is "ncs gq, vkneh osQ pkjksa vksj" – both must appear in the split versions). This leads to fragmented or ambiguous sentences in board answers.

## ON_FAILURE
1. Have the student create a hierarchy chart of the forest designations from highest to lowest using the 'kCn Nfo' meanings, placing each Tatsam word in its correct rank. 2. Give them three compound sentences from the story text (not the exercise) and ask them to underline the two independent clauses and the conjunction, then rewrite as simple sentences while checking that each new sentence has a clear subject and verb. 3. Ask them to rewrite one paragraph from the story replacing all Tatsam terms with simpler Hindi – then discuss what is lost (satire, authenticity, hierarchical tension). 4. Finally, assign a timed practice: write a 50-word factual description of a school event using at least two Tatsam-style formal terms (e.g., "pradhanacharya", "sachiv") to build register awareness.

## BUILDS_ON
Vocabulary in Context (c11_hin_ar_cbse_07_010) and Literary Devices: Irony and Symbolism (c11_hin_ar_cbse_07_009) – because the administrative terminology functions as ironic symbolism.

## LEADS_TO
Comprehension: Literal and Inferential Questions (c11_hin_ar_cbse_07_012) and Writing Skills: Based on the Chapter (c11_hin_ar_cbse_07_014) – as grammar mastery enables accurate answer writing and creative tasks.

## PREREQUISITE_NODE_IDS
c11_hin_ar_cbse_07_010, c11_hin_ar_cbse_07_009, c11_hin_ar_cbse_07_008, c11_hin_ar_cbse_07_006, c11_hin_ar_cbse_07_002, c11_hin_ar_cbse_07_001
## PREREQUISITE_REASONS
c11_hin_ar_cbse_07_010: Provides the meanings of the Tatsam words essential for correct usage.
c11_hin_ar_cbse_07_009: Explains how irony operates through language, which is central to understanding why Renu chooses these specific terms.
c11_hin_ar_cbse_07_008: Covers metaphor/imagery that often intertwines with syntactic choices (e.g., the tree as a metaphor entangled in compound sentences).
c11_hin_ar_cbse_07_006: The primary theme (bureaucratic apathy vs. human connection) is conveyed through language usage; without theme awareness, grammar exercises become mechanical.
c11_hin_ar_cbse_07_002: Plot knowledge supplies the factual content needed for the lk{kkRdkj (factual description) exercise.
c11_hin_ar_cbse_07_001: Context of colonial forest laws explains the origin and force of the administrative terminology.

## FORWARD_NODE_IDS
c11_hin_ar_cbse_07_012, c11_hin_ar_cbse_07_013, c11_hin_ar_cbse_07_014, c11_hin_ar_cbse_07_015, c12_hin_a_cbse_04_011, c12_hin_a_cbse_07_011, c12_hin_a_cbse_09_011, c12_hin_a_cbse_11_011, c12_hin_a_cbse_12_011, c12_hin_a_cbse_17_011, c12_hin_ar_cbse_01_011, c12_hin_ar_cbse_02_011, c12_hin_ar_cbse_07_011, c12_hin_ar_cbse_09_011, c12_hin_ar_cbse_10_011, c12_hin_ar_cbse_11_011

## FORWARD_REASONS
c11_hin_ar_cbse_07_012: Comprehension questions often ask "Why does the author use this word/structure?" – requiring grammar/vocabulary analysis.
c11_hin_ar_cbse_07_013: Critical interpretation of the satire depends on recognizing linguistic devices (e.g., compound sentences mimicking bureaucratic red tape).
c11_hin_ar_cbse_07_014: Writing tasks (letter, report, article) demand the same formal register and sentence transformation skills practiced here.
c11_hin_ar_cbse_07_015: Discussion points include debating the language of power – students need the terminology to articulate arguments.
c12_hin_a_cbse_04_011: अगला तार्किक चरण: This node analyzes the grammatical structures, syntactic patterns, and language usage specific to th... इस नोड की अवधारणाओं को सीधे उपयोग/विस्तारित करता है।  
c12_hin_a_cbse_07_011: Class 11 Antra Chapter 7 grammar node covers similar dialect analysis (Braj/Awadhi) — establishes the analytical framework.  
c12_hin_a_cbse_09_011: Taught *artha* (meaning) vs *roop* (form) distinction — critical for not confusing Braj form with Khari Boli translation.  
c12_hin_a_cbse_11_011: Teaches causative morphology (-a- insertion) — distinguishes "<yks/k" vs "[kks/y".  
c12_hin_a_cbse_12_011: Introduction to stylistic analysis — how grammar creates tone  
c12_hin_a_cbse_17_011: Worked with philosophical Hindi prose — prepares for this text's register.  
c12_hin_ar_cbse_01_011: Reinforces infinitive+postposition purpose constructions.  
c12_hin_ar_cbse_02_011: Mastery of participial phrases and compounds.  
c12_hin_ar_cbse_07_011: Direct precedent for Tulsidas's language in Class 11.  
c12_hin_ar_cbse_09_011: Practises Personification analysis via verb voice shifts.  
c12_hin_ar_cbse_10_011: Character voice through syntax (Chapter 7).  
c12_hin_ar_cbse_11_011: Advances elliptical syntax recognition in speech representation  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
No prior class nodes available for cross-subject prerequisites.

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_07_010 -> c11_hin_ar_cbse_07_011 -> c11_hin_ar_cbse_07_014

## THIS_FORMULA
Compound Sentence Transformation Rule: [Clause1] + Coordinating Conjunction (vkSj/ysfdu/kintu) + [Clause2] → [Simple Sentence 1 with Subject1 + Verb1] . [Simple Sentence 2 with Subject2 + Verb2] . (Condition: Both clauses must be independent; retain original tense, person, and number.)

## FORMULA_VARIABLES
Clause1 = First independent clause (subject + predicate); Clause2 = Second independent clause (subject + predicate); Coordinating Conjunction = Linking word (vkSj, ysfdu, kintu, tatha, evam); Subject1/2 = Explicit subjects of each clause; Verb1/2 = Finite verbs matching original tense.

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
linguistic

## CROSS_SUBJECT
c11_history_forest_acts | The story's administrative terminology (iQkWjsLV fMikVZeasV, gkWVhZdYpj fMikVZeasV) directly reflects designations created under the Indian Forest Act, 1927 – understanding the historical hierarchy clarifies the power dynamics in the text.
c11_politicalscience_bureaucracy | The compound sentence structure mirrors the procedural delays and buck-passing in bureaucratic systems (e.g., "file moves from Range Officer to DFO to Conservator") – a live example of red tape in democratic governance.
c11_economics_environmental_valuation | The conflict over the tree's "value" (timber revenue vs. ecological/human worth) introduces the concept of externalities and non-market valuation – the old man's struggle embodies the failure of cost-benefit analysis to capture intrinsic value.
c11_geography_forest_conservation | The "Working Plan" (iQkWjsLV fMikVZeasV) is a real forestry management tool; the story critiques its rigid application without local ecological knowledge – linking to sustainable forest management principles.

## PREREQ_CONCEPT
Understanding of Tatsam vocabulary meanings and the ability to identify independent clauses in a Hindi sentence.

## PREREQ_BEFORE
Student must know the meanings of all nine Tatsam words listed in 'kCn Nfo' and be able to spot the subject and finite verb in a Hindi clause.

## PREREQ_STUCK
If stuck, review the 'kCn Nfo' table in the textbook and practice identifying clauses in simple Hindi sentences from previous chapters (e.g., Class 10 grammar exercises on sentence types).

## WORKED_EXAMPLE_1
PROBLEMA: Use the Tatsam word "gkWVhZdYpj fMikVZeasV" in an original sentence that reflects its correct administrative rank and context from the story, then explain why this word choice matters for the satire.

STEPS:
- Step 1: Recall from 'kCn Nfo' that "gkWVhZdYpj fMikVZeasV" = Chief Conservator of Forests (m|ku Ñf"k), the highest forest authority in the state.
- Step 2: Identify a situation in the story where this rank appears: the officer who writes the order to spare the tree after the poet's intervention.
- Step 3: Construct a sentence showing the power of this rank: "gkWVhZdYpj fMikVZeasV ne isM+ dks dkVus ka aadesh vapas le liya jab use pata chala ki isM+ ihVksfu;k ljdkj ka hai." (The Chief Conservator withdrew the cutting order when he learned the tree belonged to the erstwhile princely state.)
- Step 4: Verify the sentence uses correct grammar (subject "gkWVhZdYpj fMikVZeasV", verb "le liya", past tense) and context (authority overriding lower officers).
- Step 5: Explain the satirical significance: The tree is saved not by justice or ecology, but by a political technicality recognized only at the highest bureaucratic level – the word "gkWVhZdYpj" carries the weight of that arbitrary power.
- Step 6: Connect to board exam expectation: In "Hkk"kk dh ckr" Q1, examiners award marks for contextually appropriate usage, not just grammatical correctness.

REASONING: This step-by-step ensures the student moves from rote meaning to contextual deployment, which is the core competency tested in Class 11 Hindi board exams. The explanation step (5) trains them to justify word choice – a skill needed for Q3 (critical thinking) and writing tasks.

ANSWER: Sentence: "gkWVhZdYpj fMikVZeasV ne isM+ dks dkVus ka aadesh vapas le liya jab use pata chala ki isM+ ihVksfu;k ljdkj ka hai." Explanation: The term denotes the apex forest authority; its use highlights how a single signature from the top can reverse months of lower-level bureaucracy, underscoring the satire on centralized, unaccountable power.

## WORKED_EXAMPLE_2
PROBLEMA: Transform the compound sentence from the textbook exercise into simple sentences: "bldh ppkZ 'kgj esa Hkh iSQy xbZ vkSj 'kke rd xyh&xyh ls 'kk;j tek gksus 'kq: gks x,A"

STEPS:
- Step 1: Identify the coordinating conjunction: "vkSj" (and).
- Step 2: Split the sentence at "vkSj" into two clauses: Clause A = "bldh ppkZ 'kgj esa Hkh iSQy xbZ" ; Clause B = "'kke rd xyh&xyh ls 'kk;j tek gksus 'kq: gks x,A"
- Step 3: Check each clause for subject and verb. Clause A: Subject = "bldh ppkZ" (its fame/news), Verb = "iSQy xbZ" (spread/reached). Clause B: Subject = "'kk;j tek" (the poet's fame), Verb = "gks x,A" (became). Note: "'kke rd xyh&xyh ls" is an adverbial phrase modifying the verb.
- Step 4: Ensure each clause can stand alone as a complete sentence. Clause A is complete. Clause B has an implied subject "bldh" (its) referring back to the poet? Actually the text says "'kk;j tek" – the poet's fame. So subject is explicit.
- Step 5: Write two simple sentences, retaining original tense (past) and number (singular). Sentence 1: "bldh ppkZ 'kgj esa Hkh iSQy xbZ." Sentence 2: "'kke rd xyh&xyh ls 'kk;j tek gksus 'kq: gks x,A"
- Step 6: Verify no meaning is lost: The simultaneity conveyed by "vkSj" is now implied by sequence; the causal link (news spread → fame spread) is preserved by context.

REASONING: The transformation tests the student's ability to parse complex syntactic structures – a frequent board question (2-3 marks). Step 3 is critical because students often miss that "bldh" in Clause A refers to the tree's fame, while "'kk;j tek" in Clause B is a new subject; both must be explicit in the split versions.

ANSWER: 
1. bldh ppkZ 'kgj esa Hkh iSQy xbZ.
2. 'kke rd xyh&xyh ls 'kk;j tek gksus 'kq: gks x,A

## WORKED_EXAMPLE_3
PROBLEMA: Write a factual description (lk{kkRdkj) of the old man's struggle to save the tree, as requested in the textbook exercise (lk{kkRdkj vius&vki esa ,d foèkk gSA...), in 80-100 words using at least three Tatsam terms from the chapter.

STEPS:
- Step 1: Recall the exercise instruction: "lk{kkRdkj vius&vki esa ,d foèkk gSA tkequ osQ isM+ osQ uhps ncs vkneh osQ iQkby can gksus (e`R;q) osQ fy, f”kEesnkj fdlh ,d O;fDr dk dkYifud lk{kkRdkj djsa vkSj fy[ksaA" – write a factual description of one person's struggle for the old man under the tree.
- Step 2: Identify the "one person" – the old man (ncs gq, vkneh) himself, or the mother (ekyh), or the poet (dfo). The most factual is the old man's own struggle.
- Step 3: Gather facts from the text: (a) Tree planted by erstwhile ruler, (b) Multiple departments (forest, revenue, PWD) claim jurisdiction, (c) Old man refuses to leave tree's shade, (d) Poet's intervention, (e) Final order from Chief Conservator.
- Step 4: Select three Tatsam terms: iQkWjsLV fMikVZeasV (Working Plan Officer), vaMj lsozsQVjh (DFO), gkWVhZdYpj fMikVZeasV (Chief Conservator).
- Step 5: Draft in third-person objective style: "ncs gq, vkneh ne apne jeevan ke antim dino mein ihVksfu;k ljdkj dwara ropit isM+ ko bachane ke liye sangharsh kiya. van vibhag ke iQkWjsLV fMikVZeasV aur vaMj lsozsQVjh ne isM+ katne ka aadesh diya. vkneh isM+ ke neeche hi baithe rahe. ant mein gkWVhZdYpj fMikVZeasV ne aadesh vapas liya." (Word count ~70)
- Step 6: Expand to 80-100 words by adding procedural details: "isM+ ke katne ka aadesh iQkWjsLV fMikVZeasV ki fjiksVZ par adharit tha. vaMj lsozsQVjh ne isM+ ka moolyaankan karke katne ka aadesh diya. vkneh ne kisi bhi keemat par isM+ nahi chhoda. gkWVhZdYpj fMikVZeasV ne raajnaitik dabav ke baad aadesh nirast kiya."
- Step 7: Check against criteria: factual (no emotions), third person, uses three Tatsam terms, within word limit, covers the struggle arc.

REASONING: This example combines vocabulary deployment, genre awareness (factual description = objective, concise, third-person), and content retrieval from the plot – exactly the multi-concept competency board exams test in the writing section. The step-by-step isolates each demand of the prompt.

ANSWER: ncs gq, vkneh ne apne jeevan ke antim dino mein ihVksfu;k ljdkj dwara ropit isM+ ko bachane ke liye sangharsh kiya. van vibhag ke iQkWjsLV fMikVZeasV aur vaMj lsozsQVjh ne isM+ katne ka aadesh diya. vkneh isM+ ke neeche hi baithe rahe. ant mein gkWVhZdYpj fMikVZeasV ne raajnaitik dabav ke baad aadesh nirast kiya. (89 words)

## COMPETENCY_QUESTION_1
QUESTION: The textbook asks you to use "vts±V" in a sentence. A student writes: "vts±V main school jata hoon." The teacher marks it incorrect. Explain why this usage fails the "contextual appropriateness" criterion for the board exam, and write a correct sentence that would earn full marks.

COMPETENCY: Contextual vocabulary deployment in administrative/register-appropriate sentences.

STEPS:
- Step 1: Identify the meaning of "vts±V" from 'kCn Nfo': "accordingly / thus / in that manner" – a formal connective used in official orders or logical conclusions.
- Step 2: Analyze the student's sentence: "vts±V main school jata hoon" uses it as a casual time-marker ("then I go to school"), which is colloquial, not administrative.
- Step 3: Recognize the register mismatch: The chapter's language usage exercises expect sentences that reflect the bureaucratic/legal context of the story (forest department, court orders, official correspondence).
- Step 4: Construct a correct sentence: "van vibhag ne isM+ katne ka aadesh diya; vts±V vaMj lsozsQVjh ne karravai shuru kar di." (The forest dept gave the cutting order; accordingly the DFO started action.)
- Step 5: Verify: "vts±V" links a prior official decision to a consequential action – correct register, grammar, and context.

ANSWER: The student's sentence fails because "vts±V" is a formal Tatsam connective used in official/logical discourse, not daily routine. Correct sentence: "van vibhag ne isM+ katne ka aadesh diya; vts±V vaMj lsozsQVjh ne karravai shuru kar di." This shows the word functioning as a procedural link in administrative narrative.

DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: In the story, the sentence "lsozsQVsfj;sV dk ykWu Hkk¡fr&Hkk¡fr osQ dfo;ksa ls Hkj x;k vkSj ncs gq, vkneh osQ pkjksa vksj dfo&lEesyu dk&lk okrkoj.k mRi  gks x;k" appears. A board question asks: "How does the syntactic structure of this sentence reinforce the theme of bureaucratic entanglement?" Write a structured answer (Point-Evidence-Explanation-Link) using grammatical terminology.

COMPETENCY: Analyzing syntax-theme relationship in literary prose.

STEPS:
- Step 1: Identify the syntactic structure: Compound sentence (la;qDr okD;) with two independent clauses joined by "vkSj".
- Step 2: Note the subjects: Clause 1 = "lsozsQVsfj;sV dk ykWu" (the station premises – a space), Clause 2 = "ncs gq, vkneh osQ pkjksa vksj" (the old man's legs – a body part). The shift from space to body is abrupt.
- Step 3: Observe the verbs: "Hkj x;k" (got filled/crowded) – passive, involuntary; "mRi  gks x;k" (got created/formed) – bureaucratic, procedural.
- Step 4: Formulate Point: The compound sentence's coordination of two disparate events (crowd gathering, poetic celebration) without subordination mirrors how bureaucracy treats human suffering and official procedure as parallel, equally weighty processes.
- Step 5: Evidence: Quote the two clauses and the conjunction "vkSj".
- Step 6: Explanation: The lack of causal connective (like "isliye" or "kyonki") forces the reader to experience the simultaneity – the old man's vulnerability and the poets' revelry occur in the same breath, just as the file moves from Range Officer to DFO to Conservator without pausing for the human cost.
- Step 7: Link: This syntactic choice is a microcosm of the story's central irony – the tree's fate is decided in clauses, not conscience.

ANSWER: The compound sentence (la;qDr okD;) joins two independent clauses with "vkSj" without establishing causality: (1) "lsozsQVsfj;sV dk ykWu Hkk¡fr&Hkk¡fr osQ dfo;ksa ls Hkj x;k" (space filled by poets) and (2) "ncs gq, vkneh osQ pkjksa vksj dfo&lEesyu dk&lk okrkoj.k mRi  gks x;k" (old man's legs became site of poetic celebration). The coordination gives equal syntactic weight to a public spectacle and a private bodily experience, reflecting how bureaucratic machinery (evident in the chain of officers: fMIVh lsozsQVjh → phI+kQ lsozsQVjh → vaMj lsozsQVjh → gkWVhZdYpj fMikVZeasV) processes human lives as routine entries. The structure enacts the theme: procedure entangles humanity.

DIFFICULTY: hard