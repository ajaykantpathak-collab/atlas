## DEFINITION
Irony in Kabir's poetry is the deliberate contrast between surface meaning and deeper spiritual truth, often exposing religious hypocrisy through paradoxical statements. Symbolism uses concrete objects like the weaver's loom, thread, and cloth to represent abstract concepts such as the human soul, divine connection, and the fabric of existence.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student must be able to identify at least two instances of irony and two symbols in Kabir's verses, explain how each device functions to convey the poet's critique of ritualism, and write a structured 4-point answer connecting the device to the central theme of inner devotion versus outer show.

## SCOPE_BOUNDARY
This node covers irony and symbolism specifically in Kabir's sakhis and pads from the NCERT Class 11 Aroh Chapter 10 text. It does NOT cover other poetic devices like metaphor, imagery, or alliteration (covered in node c11_hin_ar_cbse_10_008), nor does it address Kabir's biography or historical context in detail (covered in node c11_hin_ar_cbse_10_001).

## WALKTHROUGH
Imagine you're watching a street magician who claims to pull a rabbit from an empty hat — you know the hat wasn't truly empty, just as Kabir knows rituals aren't truly spiritual. Start by reading the poem aloud and noticing where the literal words clash with what Kabir actually means — like when he calls everyone "fxjèkj" (brother) but then says "nwljks u dksbZ" (no one is a stranger), revealing the irony of artificial divisions. Next, underline concrete nouns — loom (lhafp), thread (ty), cloth (csfy) — and ask: what invisible thing could each represent? The loom becomes the world, the thread becomes breath or karma, the cloth becomes the lived life. Connect each symbol to Kabir's weaver identity: he turns his trade into theology. Finally, practice writing: "Kabir uses [device] in [line reference] to show [theme] because [explanation]."

## DIAGNOSTIC_QUESTION_1
What is the literal meaning of the word "lhafp" (loom) in Kabir's poetry, and what does it symbolize in the context of his spiritual philosophy?

## DIAGNOSTIC_ANSWER_1
The literal meaning of "lhafp" is the physical loom used by a weaver to interlace threads into cloth. Symbolically, it represents the world (samsara) or the human body where the warp and weft of karma, breath, and divine will are woven into a lived life. A wrong answer that only gives the literal meaning reveals the student cannot move from concrete object to abstract representation — a core skill for symbolism analysis at Class 11 level.

## DIAGNOSTIC_QUESTION_2
In the line "valqou ty lhafp&lhafp] izse&csfy cks;h", explain why the pairing "izse&csfy" (love and separation) creates irony when placed alongside the loom imagery.

## DIAGNOSTIC_ANSWER_2
The loom suggests a controlled, deliberate craft where the weaver decides the pattern, but "izse&csfy" (union and separation) are experiences that happen *to* the soul, not chosen by it — creating irony because the human (weaver) thinks they control the design, yet the true pattern (divine will) includes unavoidable separation. A wrong answer that treats both as mere decorative contrasts misses the tension between human agency and divine mystery that defines Kabir's irony.

## DIAGNOSTIC_QUESTION_3
Identify the irony in Kabir addressing the listener as "fxjèkj xksiky" (brother, friend) while simultaneously declaring "nwljks u dksbZ" (no one is new/stranger). Apply the concept of situational irony to explain its purpose.

## DIAGNOSTIC_ANSWER_3
Step 1: Recognize "fxjèkj xksiky" establishes an intimate, exclusive relationship (brother/friend). Step 2: Recognize "nwljks u dksbZ" dissolves all boundaries — if no one is a stranger, the special label "brother" becomes meaningless. Step 3: The irony lies in using a particular term of closeness to express universal oneness. Step 4: Purpose — Kabir exposes how religious labels (Hindu/Muslim, guru/disciple) create false divisions; true spirituality erases the need for special names. A wrong answer that calls this a "contradiction" rather than "irony" fails to see the intentional rhetorical strategy.

## DIAGNOSTIC_QUESTION_4
Compare the symbol of "ty" (thread) in Kabir's poetry with the symbol of "thread" in the Upanishadic concept of "Sutra-atman" (the thread-self that passes through all beings). Analyze how Kabir adapts this classical symbol for his bhakti message.

## DIAGNOSTIC_ANSWER_4
In the Upanishads, the thread (sutra) is a metaphysical principle — the subtle self that strings together all lives like gems on a necklace, emphasizing cosmic unity. Kabir adapts this by making the thread tangible: it is the weaver's cotton yarn, the breath (prana), the name of God (Ram), and the guru's teaching — all at once. The irony: a low-caste weaver's coarse thread becomes the vehicle for the highest truth, subverting the Brahminical monopoly on the "sutra" concept. A weak answer merely notes "both use thread" without analyzing the social-spiritual subversion.

## DIAGNOSTIC_QUESTION_5
Evaluate the claim: "Kabir's use of irony is more effective than his use of symbolism in dismantling ritualistic religion." Defend your position with two specific textual evidences.

## DIAGNOSTIC_ANSWER_5
A strong evaluation acknowledges both devices work together but argues irony is sharper for critique: (1) In "Hindu kahe mohe Ram piyara, Turk kahe Rahimana" — the irony of two groups fighting over names for the same nameless reality cuts deeper than any symbol. (2) "Pothi padhi padhi jag mua, pandit bhaya na koi" — the irony of death despite scriptural learning mocks ritual knowledge directly. Symbolism (loom, thread) builds positive theology; irony destroys false theology. A weak answer chooses one device without textual evidence or treats them as interchangeable.

## DIAGNOSTIC_QUESTION_6
Create a 4-line verse in Kabir's style (using Khari Boli with Braj touch) that employs both irony and a weaving symbol to critique a modern hypocrisy (e.g., social media spirituality, performative activism, or consumerist devotion).

## DIAGNOSTIC_ANSWER_6
Expected criteria: (1) Uses a weaving metaphor (loom/thread/cloth/shuttle) as central symbol. (2) Contains a clear ironic gap between appearance and reality. (3) Targets a specific modern hypocrisy. (4) Maintains Kabir's direct, rhythmic, couplet-like tone. Example: "Insta-pe Ram bhajai sab, dil mein laga bazaar / Ty toot gayo prem ka, baune lage kapda haar." A poor answer uses clichéd rhymes without irony or forces a symbol without organic connection to the critique.

## COMMON_MISCONCEPTION
Students often confuse Kabir's *paradoxes* with *irony* — they label every contradictory statement as "irony" without checking if there's an intentional gap between speaker's intent and literal meaning. For example, "I don't worship idols, I worship the formless" is a paradox (two truths held together), not irony. True irony in Kabir requires a *target* — usually a hypocritical priest, a proud scholar, or a ritualist — whose words or actions backfire. Students also treat symbols as fixed codes (loom = world, always) instead of seeing how Kabir shifts the loom's meaning: sometimes it's the body, sometimes the cosmos, sometimes the guru's teaching — context decides.

## ON_FAILURE
Step 1: Give the student three short Kabir lines — one paradox, one irony, one plain statement — and ask them to sort them. Step 2: For the irony, ask: "Who is being mocked here? What did they expect vs what happened?" Step 3: For symbols, give the same symbol (e.g., "charkha" / spinning wheel) in two different Kabir verses and ask: "Does it mean the same thing in both? Why or why not?" Step 4: Have them rewrite a non-ironic line into an ironic one by adding a hypocritical speaker. This builds the "target awareness" and "contextual flexibility" they lack.

## BUILDS_ON
Builds on the ability to distinguish literal vs figurative meaning (from c11_hin_ar_cbse_10_008 Imagery and Metaphor) and the understanding of Kabir's core theme: inner devotion over outer ritual (from c11_hin_ar_cbse_10_006 Primary Theme).

## LEADS_TO
Enables critical interpretation in c11_hin_ar_cbse_10_013 (Critical Thinking: Analysis and Interpretation) and provides textual evidence for writing tasks in c11_hin_ar_cbse_10_014 (Writing Skills: Based on the Chapter).

## PREREQUISITE_NODE_IDS
c11_hin_ar_cbse_10_001, c11_hin_ar_cbse_10_006, c11_hin_ar_cbse_10_008, c11_hin_ar_cbse_10_007

## PREREQUISITE_REASONS
c11_hin_ar_cbse_10_001: Provides Kabir's historical context (weaver, bhakti movement, rejection of orthodoxy) essential to decode why he chooses weaving symbols and targets rituals with irony.
c11_hin_ar_cbse_10_006: Establishes the central theme (inner love vs outer show) that all irony and symbolism in this chapter serve — without this, devices become ornamental, not functional.
c11_hin_ar_cbse_10_008: Teaches the baseline skill of moving from concrete image to abstract meaning (metaphor/imagery) which is the prerequisite for the more complex, multi-layered operation of symbolism.
c11_hin_ar_cbse_10_007: Irony and symbolism operate at the intersection of primary and secondary themes (e.g., "fxjèkj" as ironic honorific).  

## FORWARD_NODE_IDS
c11_hin_ar_cbse_10_013, c11_hin_ar_cbse_10_014, c11_hin_ar_cbse_10_010, c11_hin_ar_cbse_10_015, c12_hin_a_cbse_05_009, c12_hin_a_cbse_10_009, c12_hin_al_cbse_01_009, c12_hin_ar_cbse_09_009, c12_hin_ar_cbse_10_009, c12_hin_ar_cbse_12_009, c11_hin_ar_cbse_10_011

## FORWARD_REASONS
c11_hin_ar_cbse_10_013: Critical thinking requires the student to independently identify and interpret devices — this node gives the toolkit (irony/symbolism detection + structured explanation).
c11_hin_ar_cbse_10_014: Writing tasks (analytical paragraph, essay) demand textual evidence; mastery here provides quotable, analyzable device examples with theme connections ready for PEEL structure.
c11_hin_ar_cbse_10_010: Knowledge of irony and symbolism helps students grasp why the poet chooses simple folk words ("dkfu", "yksd") to convey profound spiritual love.  
c11_hin_ar_cbse_10_015: Irony/symbolism analysis (e.g., the weaver as supreme guru) deepens interpretive possibilities.  
c12_hin_a_cbse_05_009: अगला तार्किक चरण: Irony is a literary device where the intended meaning of words or a situation is opposite to their l... इस नोड की अवधारणाओं को सीधे उपयोग/विस्तारित करता है।  
c12_hin_a_cbse_10_009: Chapter 10 (Class 11) was a full biographical sketch — direct parallel to this chapter's form.  
c12_hin_al_cbse_01_009: Class 11 Antra Chapter 10 Irony and Symbolism node links to critical interpretation.  
c12_hin_ar_cbse_09_009: Adds comparative analysis of two poems.  
c12_hin_ar_cbse_10_009: Class 11 node provides the foundational definitions and simple identification practice for irony and symbolism.  
c12_hin_ar_cbse_12_009: अगला तार्किक चरण: Irony in this story is the contrast between appearance and reality — where the wealthy waste water c... इस नोड की अवधारणाओं को सीधे उपयोग/विस्तारित करता है।  
c11_hin_ar_cbse_10_011: he word meanings necessary to parse grammatical function; Literary Devices (c11_hin_ar_cbse_10_008, c11_hin_ar_cbse_10_009) establishes rhetorical awareness that language usage analysis deepens.  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
none

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_10_001 -> c11_hin_ar_cbse_10_009 -> c11_hin_ar_cbse_10_013 (Context enables device analysis which enables critical interpretation)

## THIS_FORMULA
N/A - conceptual

## FORMULA_VARIABLES
N/A

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
conceptual

## CROSS_SUBJECT
c11_history_bhakti_movement | Kabir's irony and weaving symbolism directly reflect the 15th-century socio-religious context: his critique of ritual mirrors the historian's analysis of Brahminical orthodoxy vs popular bhakti; his weaver identity connects to medieval Indian craft economies and caste dynamics.
c11_sociology_social_change | Kabir's use of irony to invert status (weaver > pandit) and symbolism to reclaim labor (weaving as sadhana) illustrates sociological concepts of symbolic resistance, status reversal, and religion as both opiate and instrument of liberation.

## PREREQ_CONCEPT
The student must understand that literary devices in bhakti poetry are not decorative — they are theological arguments made through form.

## PREREQ_BEFORE
The student must be able to paraphrase the selected Kabir verses in simple Hindi and state the central idea of each pad/sakhi before analyzing devices.

## PREREQ_STUCK
If stuck, review c11_hin_ar_cbse_10_006 (Theme: Primary Theme) — specifically the concept of "nirguna bhakti" and Kabir's rejection of "pakhand" (hypocrisy/ritualism) — because every irony and symbol in this chapter serves that specific theological fight.

## WORKED_EXAMPLE_1
PROBLEM: Analyze the irony and symbolism in the following Kabir verse (paraphrased): "The pandit reads scriptures all day but doesn't know the one word 'Ram'; the weaver chants 'Ram-Ram' at his loom and crosses the ocean of existence."

STEPS:
- Step 1: Identify the two contrasting figures — the pandit (learned, high status, ritualistic) and the weaver (unlettered, low status, devotional).
- Step 2: Detect the irony — the pandit *has* the knowledge (scriptures) but *misses* the essence (Ram); the weaver *lacks* formal knowledge but *attains* the goal (liberation). The expected outcome (pandit succeeds) is reversed.
- Step 3: Identify the symbol — the "loom" (lhafp) is not just workplace; it becomes the site of sadhana where each shuttle throw = each breath/chant, weaving the cloth of liberation.
- Step 4: Explain the theological argument — Kabir uses irony to attack *bookish knowledge* (pothi gyan) and symbolism to elevate *labor-infused devotion* (shram-sadhana). The loom symbol makes devotion tangible, accessible, and continuous.
- Step 5: Connect to theme — This reinforces the primary theme (c11_hin_ar_cbse_10_006): "Antar ki prit, bahar ka dambh nahi" (inner love, not outer show).

REASONING: The 5-step method forces the student to separate device detection (steps 1-3) from interpretation (step 4) and thematic integration (step 5) — mirroring the board exam's expectation of "identify, illustrate, explain, connect."

ANSWER: Kabir employs situational irony by reversing the expected spiritual hierarchy: the scripture-master pandit remains ignorant of the singular truth (Ram), while the illiterate weaver attains liberation through the loom-symbolized practice of nam-smaran. The loom functions as a polyvalent symbol — workplace, body, cosmos, and spiritual instrument — democratizing sadhana by rooting it in labor. Together, the devices argue that liberation comes not from textual authority but from embodied, continuous remembrance.

## WORKED_EXAMPLE_2
PROBLEM: In the line "vc r csfy iSQfy x;h] vk.kan&iQy gks;h" (now the cloth is finished, the warp and weft are separated), explain how the weaving symbolism shifts from process to completion, and what irony emerges at the moment of death.

STEPS:
- Step 1: Decode the weaving terms — "csfy" = finished cloth (life completed), "iSQfy" = finished/ended, "vk.kan" = warp (lengthwise threads, often symbolizing prana/karma), "iQy" = weft (crosswise threads, often symbolizing breath/actions).
- Step 2: Trace the symbol's evolution — earlier in the poem, the loom is active (lhafp&lhafp); here, the cloth is *off* the loom. The weaving (life) is done; the threads (karma/breath) separate.
- Step 3: Identify the irony — the weaver (soul) spent life *making* the cloth, but at death, the cloth (body/life) is taken away; the maker loses the made. The irony: we cling to what we create, yet creation is inherently separable from creator.
- Step 4: Link to Kabir's nirguna view — the finished cloth = the subtle body (linga sharira) carrying karmic impressions; separation of warp/weft = dissolution of prana and karma at death. Only the *witness* (the true weaver, the soul) remains.
- Step 5: Formulate the board-style answer — Point: Symbolism of completed cloth. Evidence: "vc r csfy iSQfy x;h". Explanation: Life as woven fabric ends; warp/weft (prana/karma) disengage. Link: Irony of attachment to the impermanent cloth; true self is the unattached weaver.

REASONING: This example models the "symbol trajectory" skill — tracking how a symbol changes meaning across a poem — and the "death irony" pattern common in Kabir (the moment of truth exposes lifelong illusion).

ANSWER: The verse shifts the loom symbol from *active process* (weaving = living) to *completed product* (cloth = lived life). "csfy iSQfy" signals the life-fabric is finished; "vk.kan&iQy gks;h" depicts the dissolution of the constituents (prana/karma) that held it together. The irony: the jiva identifies with the cloth (body/life) but the cloth is inherently separable from the weaver. Kabir thus uses weaving's terminal moment to reveal the nirguna truth — you are not the cloth, you are the witness of its weaving and unweaving.

## WORKED_EXAMPLE_3
PROBLEM: Compare Kabir's use of the "thread" (ty) symbol in two contexts: (A) "ty lhafp&lhafp" (the loom weaves thread) and (B) "guru ty dhari, shishya sujh" (the guru holds the thread, the disciple understands). Analyze how the same symbol serves different theological functions — cosmic vs pedagogical — and where irony appears in each.

STEPS:
- Step 1: Context A — "ty" as cosmic thread in "valqou ty lhafp&lhafp". Here, thread = the raw material of existence (breath, karma, divine will) being woven into the world-cloth by the supreme weaver (Kabir's Ram). Irony: humans think they weave their lives, but the *real* weaver is invisible.
- Step 2: Context B — "ty" as guru's teaching thread in "guru ty dhari...". Here, thread = the guru's instruction (upadesha), the subtle connection between guru and disciple. The guru "holds" (initiates, guides); the disciple "understands" (receives, realizes).
- Step 3: Compare agency — In A, agency is divine (cosmic weaving); in B, agency is shared (guru offers, disciple receives). The thread shifts from *deterministic* (karma) to *liberative* (grace/knowledge).
- Step 4: Locate irony in B — The irony: the thread is invisible, weightless, yet it binds guru-disciple more securely than any ritual thread (janeu). The low-caste weaver-guru's "cotton thread" of knowledge outweighs the Brahmin's sacred cotton thread.
- Step 5: Synthesize — Kabir redefines "thread" across registers: cosmic substrate, vital breath, guru's word, disciple's realization. The unifying irony: the most ordinary material (cotton thread) carries the highest truth, subverting purity hierarchies.
- Step 6: Board answer structure — Device: Symbol (thread) with contextual polysemy. Evidence A: "valqou ty..." Evidence B: "guru ty dhari..." Analysis: Shift from fate to freedom. Irony: Material insignificance vs spiritual potency. Theme link: Nirguna bhakti transcends caste/ritual.

REASONING: This 6-step worked example models the highest-order skill for Class 11: *comparative device analysis* across contexts within the same poet, showing how a symbol's meaning is not fixed but functionally deployed — exactly what competency questions demand.

ANSWER: In "valqou ty lhafp&lhafp", "ty" symbolizes the cosmic thread — the substrate of existence (prana/karma/divine will) woven into the world-cloth by the unseen weaver; irony lies in human delusion of authorship. In "guru ty dhari, shishya sujh", "ty" symbolizes the guru's upadesha — the invisible transmission of knowledge that binds disciple to truth; irony lies in this weightless thread replacing the heavy janeu as the true sacred bond. The symbol's trajectory moves from *cosmic determinism* (we are woven) to *liberative pedagogy* (we are guided to see the weaver). Both deploy the weaver's humble material to dismantle ritual hierarchy — the core nirguna strategy.

## COMPETENCY_QUESTION_1
QUESTION: A student writes: "Kabir uses the loom as a symbol of life. This is a metaphor because life is like a loom." Identify the two errors in this statement and rewrite it as a correct analytical sentence using the terminology and structure taught in this node.

COMPETENCY: Terminological precision and analytical writing structure (PEEL)

STEPS:
- Step 1: Identify Error 1 — "symbol of life" is vague; the loom symbolizes *specific aspects* (world, body, sadhana-site), not "life" generically.
- Step 2: Identify Error 2 — Calling a symbol a "metaphor" confuses categories; a symbol *can* work metaphorically but is a distinct device (symbol = concrete object standing for abstract concept across a work; metaphor = direct comparison in a phrase).
- Step 3: Apply PEEL — Point: Kabir deploys the loom as a polyvalent symbol. Evidence: "valqou ty lhafp&lhafp". Explanation: The loom represents the cosmos/body where karma-threads are woven; its operation mirrors the breath-cycle. Link: This grounds nirguna bhakti in the weaver's lived labor, making liberation tangible.
- Step 4: Write the corrected sentence integrating all four components.

ANSWER: Corrected: "Kabir deploys the loom (lhafp) as a polyvalent symbol — representing simultaneously the cosmos (valqou), the human body, and the site of devotional practice — as seen in 'valqou ty lhafp&lhafp', where the weaver's shuttle enacts the rhythm of breath and karma, thereby grounding formless devotion in the tangible labor of the low-caste artisan."

DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: "Kabir's irony targets only religious rituals, not social structures." Evaluate this claim by analyzing two verses where irony operates at the intersection of religion *and* caste/gender. Provide textual evidence and explain the dual critique.

COMPETENCY: Intersectional textual analysis and evidence-based evaluation

STEPS:
- Step 1: Reject the binary — Kabir's irony rarely separates religion from social structure; ritual purity *is* caste purity.
- Step 2: Select Verse 1 — "Pandit tu brahmin kaun, kaun achhoot?" (implied in multiple sakhis). Irony: The pandit claims purity by birth/ritual, but Kabir defines purity by *bhav* (intent) and *gyan*. The religious title "pandit" becomes the proof of ignorance.
- Step 3: Select Verse 2 — "Jati na pucho sadhu ki, puch lijiye gyan" (Don't ask a sadhu's caste, ask their knowledge). Irony: Society asks caste first; Kabir inverts the protocol. The social question (caste) is exposed as irrelevant to the religious goal (knowledge).
- Step 4: Analyze intersection — In both, religious authority (pandit, sadhu) is legitimated by social hierarchy (Brahmin, caste). Kabir's irony dismantles *both* by showing the religious criterion (knowledge/devotion) contradicts the social criterion (birth/ritual).
- Step 5: Conclude — The claim fails because Kabir's irony is structurally intersectional: ritual and caste are co-constitutive targets.

ANSWER: The claim is false. Kabir's irony simultaneously attacks religious ritual and its social scaffolding (caste). Evidence 1: In sakhis addressing the pandit, the irony of a "learned" Brahmin missing the formless Ram exposes how *ritual learning* (religious) and *birth privilege* (caste) together produce spiritual blindness. Evidence 2: "Jati na pucho sadhu ki" — the irony of society prioritizing caste over gnana reveals that *social protocol* blocks *religious truth*. The dual critique: orthodoxy uses ritual to sanction caste; Kabir uses irony to sever the link.

DIFFICULTY: hard