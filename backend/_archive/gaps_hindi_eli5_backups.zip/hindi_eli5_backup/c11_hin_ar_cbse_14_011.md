## DEFINITION
Grammar: Language Usage in the Text refers to the systematic analysis of grammatical structures, syntactic patterns, morphological variations, and rhetorical devices employed in the poetic text to convey meaning, create aesthetic effect, and reflect the poet's stylistic choices, including the use of Braj Bhasha features, archaic forms, and dialectal variations characteristic of medieval Hindi poetry.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student must be able to identify and explain at least five distinct grammatical or linguistic features in the given poems (such as case endings, verb forms, postpositions, compound formations, or dialectal variations), analyze their functional significance in creating poetic effect, and demonstrate this analysis by writing a structured response citing specific textual evidence with line/stanza references.

## SCOPE_BOUNDARY
This node covers grammatical analysis of the two poems by Vaddhegnasoh in Chapter 14, focusing on Braj Bhasha features, case marking (कारक), verb morphology (क्रिया रूप), postpositions (संबोधन/संबंध सूचक अव्यय), compound words (समास), and archaic vocabulary. It does NOT cover comprehensive history of Hindi language development, detailed sandhi/vigraha rules beyond textual examples, or comparative analysis with other Bhakti poets beyond what is needed for textual understanding.

## WALKTHROUGH
Imagine you are reading a poem written 400 years ago and notice words like "एर", "पन", "उहन", "इकु" that don't match modern Hindi—how would you systematically decode what grammatical work each word is doing? Begin by reading both poems aloud slowly, marking every word that looks unfamiliar or functions differently from modern standard Hindi. Next, group these marked words by grammatical category: noun forms (case endings), verb forms (tense/aspect/mood), postpositions, and compounds. Then, for each group, identify the Braj Bhasha pattern (e.g., एर = का/के, पन = पर/में, उहन = उन्हें) and explain why the poet chose that form—does it maintain meter, create alliteration, reflect spoken dialect, or carry emotional weight? Finally, synthesize how these linguistic choices collectively construct the poem's rustic authenticity and devotional intensity, connecting back to the poet's identity as a folk poet-saint.

## DIAGNOSTIC_QUESTION_1
Identify the grammatical function of the suffix "एर" in the phrase "एर एप्य" from the first poem, and state its modern Hindi equivalent.

## DIAGNOSTIC_ANSWER_1
The suffix "एर" functions as the genitive case marker (कारक चिह्न) equivalent to modern Hindi "का/के/की", indicating possession or relationship. A wrong answer (e.g., identifying it as dative "को" or locative "में") reveals the student cannot distinguish Braj Bhasha case endings from modern Hindi, indicating a gap in recognizing dialectal morphological variation.

## DIAGNOSTIC_QUESTION_2
Explain why the poet uses "पन" instead of standard Braj "पर" or modern Hindi "पर/में" in "रमि एर" and "एपक एर मफक्य-इकफक्य", and what phonological process this represents.

## DIAGNOSTIC_ANSWER_2
"पन" represents the Braj Bhasha locative postposition where the dental nasal 'न' assimilates to the preceding labial 'प' (from मूल रूप 'पर' > 'पन' through nasal assimilation), creating a metrically convenient heavy syllable. A wrong answer treating "पन" as a separate lexical item or modern Hindi "पन" (abstract noun suffix) reveals the student cannot apply historical phonology to textual analysis.

## DIAGNOSTIC_QUESTION_3
In the second poem, analyze the verb form "हख[ " in "हख[ वकÅ¡" and "हख[ विSडज" — identify its grammatical category, person, number, and the syntactic construction it participates in.

## DIAGNOSTIC_ANSWER_3
"हख[" is the second person plural imperative form of the verb "होना" (to be/become), used here as an auxiliary in a causative construction ("हख[ वकÅ¡" = "make it happen", "हख[ विSडज" = "make him do"), addressing the listener(s) with authoritative force. A wrong answer identifying it as indicative mood or singular person reveals inability to parse imperative morphology in causative syntax.

## DIAGNOSTIC_QUESTION_4
Compare the compound formation in "बू'ओज" (first poem) and "िक'कपज" (second poem) — identify the समास type for each, provide the विग्रह, and explain how the semantic relationship differs between the two compounds.

## DIAGNOSTIC_ANSWER_4
"बू'ओज" = बहुव्रीहि समास (बू'ओज = बू'ओज यस्य सः — जिसके बाज हैं) functioning as an epithet for the addressee; "िक'कपज" = तत्पुरुष समास (िक'कस्य पज — कुछ का पुत्र) denoting a specific relational identity. A wrong answer classifying both as तत्पुरुष or both as बहुव्रीहि reveals inability to distinguish semantic head-modifier relationships in compound typology.

## DIAGNOSTIC_QUESTION_5
Evaluate the poetic effect of retaining archaic Braj forms ("उहन", "इकु", "इ<ह्य", "टहक") alongside relatively modern forms ("हमारे", "तुम्हें", "करो") in the same poem — does this linguistic layering enhance or undermine the poem's authenticity as a folk devotional text? Justify with two specific examples.

## DIAGNOSTIC_ANSWER_5
The linguistic layering enhances authenticity by mirroring the actual speech continuum of 17th-century Braj region where archaic and innovative forms coexisted; e.g., "उहन" (archaic pronoun) preserves oral tradition flavor while "तुम्हें" (modernized) ensures comprehensibility, and "इकु" (अपभ्रंश < एकु) maintains metrical brevity against "एक" — this code-mixing reflects living language, not artificial archaism. A wrong answer claiming inconsistency reveals misunderstanding of diglossia in medieval poetic registers.

## DIAGNOSTIC_QUESTION_6
Compose two original lines in Braj Bhasha style using at least three grammatical features analyzed above (case marker एर, postposition पन, imperative हख[, compound formation), addressing a deity with a request, and provide the modern Hindi translation with grammatical gloss.

## DIAGNOSTIC_ANSWER_6
Example: "एर चरणन पन हख[ धरहु मोहे / इकु कृपा करहु दीन बंधु सोहे" — Modern Hindi: "आपके चरणों में मुझे रख लीजिए / एक कृपा कर दीजिए दीनबंधु शोभते हैं" — Gloss: एर (का), चरणन (चरणों में - पन assimilation), हख[ (हो जाओ/कर दो - imperative causative), इकु (एक - अपभ्रंश), दीन बंधु (तत्पुरुष समास). A poor answer using only modern Hindi forms or incorrect case markings reveals inability to productively apply analyzed grammatical knowledge.

## COMMON_MISCONCEPTION
Students consistently treat Braj Bhasha forms as "incorrect" or "corrupted" Hindi rather than as a systematic literary dialect with its own internal grammar — they attempt to "correct" "एर" to "का", "पन" to "पर", "उहन" to "उन्हें" without recognizing these as rule-governed variants. This stems from school grammar teaching standard Khari Boli as the only "correct" Hindi, causing students to miss the poetic function of dialectal authenticity, metrical necessity, and oral tradition preservation that these forms serve in Vaddhegnasoh's folk devotional poetry.

## ON_FAILURE
Step 1: Give the student a three-column table — Column A: Braj form from poem, Column B: Modern Khari Boli equivalent, Column C: Grammatical label (case, tense, etc.) — and have them fill it for 10 marked words. Step 2: Ask them to read aloud both versions and clap the meter — they will hear how "एर" (light) vs "का" (heavy) changes the rhythm. Step 3: Show a parallel example from Surdas or Mirabai where the same Braj forms appear, proving these are literary conventions not errors. Step 4: Have them rewrite one stanza in pure Khari Boli and compare emotional/rustic effect — they will perceive the loss of "folk voice" that the misconception ignores.

## BUILDS_ON
Vocabulary in Context: Key Words (c11_hin_ar_cbse_14_010) — students must first recognize the lexical items before analyzing their grammatical behavior.

## LEADS_TO
Comprehension: Literal and Inferential Questions (c11_hin_ar_cbse_14_012) — grammatical analysis provides the linguistic evidence needed for accurate textual interpretation.

## PREREQUISITE_NODE_IDS
c11_hin_ar_cbse_14_010, c11_hin_ar_cbse_14_008, c11_hin_ar_cbse_14_009

## PREREQUISITE_REASONS
c11_hin_ar_cbse_14_010: Students need the word-meaning foundation (शब्द-अर्थ) for archaic terms like "उहन", "इकु", "पज" before they can analyze their grammatical function in syntax.
c11_hin_ar_cbse_14_008: Grammatical structures (imperatives "gs", "vks"; compounds "pUuefYydktqZu") *create* the metaphorical voice — device and grammar are co-constitutive.  
c11_hin_ar_cbse_14_009: Grammar and language usage includes analyzing how syntactic choices create irony.  

## FORWARD_NODE_IDS
c11_hin_ar_cbse_14_012, c11_hin_ar_cbse_14_013, c11_hin_ar_cbse_14_014, c12_hin_a_cbse_04_011, c12_hin_a_cbse_09_011, c12_hin_a_cbse_11_011, c12_hin_a_cbse_12_011, c12_hin_a_cbse_14_011, c12_hin_a_cbse_17_011, c12_hin_ar_cbse_01_011, c12_hin_ar_cbse_02_011, c12_hin_ar_cbse_07_011, c12_hin_ar_cbse_09_011, c12_hin_ar_cbse_10_011, c12_hin_ar_cbse_11_011, c12_hin_ar_cbse_14_011, c11_hin_ar_cbse_14_015

## FORWARD_REASONS
c11_hin_ar_cbse_14_012: Grammatical parsing of case markers, verb forms, and compounds is prerequisite for answering literal comprehension questions accurately (e.g., who is addressing whom, what is the request). c11_hin_ar_cbse_14_013: Linguistic analysis of dialectal layering and archaic forms provides evidence for critical interpretation of the poem's folk authenticity and devotional stance.
c11_hin_ar_cbse_14_014: Grammar usage (imperative mood in poem 2: 'Hkwy tkÅ¡', 'oqQN nsus') supports Explanation of tone.  
c12_hin_a_cbse_04_011: अगला तार्किक चरण: This node analyzes the grammatical structures, syntactic patterns, and language usage specific to th... इस नोड की अवधारणाओं को सीधे उपयोग/विस्तारित करता है।  
c12_hin_a_cbse_09_011: *Sarvanam ke bhed* — Braj pronouns show distinct case forms (Diagnostic 3).  
c12_hin_a_cbse_11_011: Practices register-switching in dialogue — directly applicable to clock/stone dialogue task.  
c12_hin_a_cbse_12_011: Grammatical gender/number agreement patterns in non-standard varieties  
c12_hin_a_cbse_14_011: Provides foundational practice in identifying grammatical structures in literary texts from Class 11 Antra Chapter 14.  
c12_hin_a_cbse_17_011: Created original sentences using grammatical patterns — needed for Diagnostic Q6.  
c12_hin_ar_cbse_01_011: Exposure to modernist poetic syntax (Muktibodh/Trilochan precursors).  
c12_hin_ar_cbse_02_011: Creative use of grammatical features.  
c12_hin_ar_cbse_07_011: Historical phonology (e.g., 'r' from 'h').  
c12_hin_ar_cbse_09_011: Practises writing analytical paragraphs on poetic craft.  
c12_hin_ar_cbse_10_011: Pragmatics of address forms (Chapter 14).  
c12_hin_ar_cbse_11_011: Bridges analysis to writing application  
c12_hin_ar_cbse_14_011: Introduced tatsama/tadbhava distinction, aspectual verb forms, and syntactic foregrounding in the same chapter — this node deepens those with board-exam-level functional analysis.  
c11_hin_ar_cbse_14_013: Grammatical choices (imperative mood, plural vs. singular) shape meaning.  
c11_hin_ar_cbse_14_015: creative writing, or grammar rules—those are addressed in sibling nodes c11_hin_ar_cbse_14_014 and c11_hin_ar_cbse_14_011 respectively.  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
none

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_14_010 -> c11_hin_ar_cbse_14_011 -> c11_hin_ar_cbse_14_012 -> c11_hin_ar_cbse_14_013

## THIS_FORMULA
N/A - conceptual

## FORMULA_VARIABLES
N/A

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
linguistic

## CROSS_SUBJECT
c11_history_medieval_india_bhakti_movement | The grammatical analysis of Braj Bhasha in Vaddhegnasoh's poems connects to the historical spread of vernacular devotional literature during the Bhakti movement, where linguistic choices reflected accessibility to common people versus Sanskrit exclusivity.
c11_geography_cultural_landscapes_north_india | The dialectal features (एर, पन, उहन) map onto the Braj cultural region (Mathura-Vrindavan-Agra belt), illustrating how linguistic isoglosses correspond to geographic zones of Krishna bhakti tradition.

## PREREQ_CONCEPT
Morphological recognition of Braj Bhasha case markers (एर, पन, ने, ते) and verb endings (हख[, करहु, धरहु) as distinct from modern Khari Boli paradigms.

## PREREQ_BEFORE
Student must be able to list at least 8 archaic words from the poems with their modern Hindi meanings (covered in c11_hin_ar_cbse_14_010).

## PREREQ_STUCK
Review the शब्द-अर्थ (word-meaning) list from the textbook's 'शब्द-नोट' section and practice matching each archaic form to its modern equivalent before attempting grammatical analysis.

## WORKED_EXAMPLE_1
PROBLEM: Analyze the grammatical structure and poetic function of the opening line "गस हक[! एर एप्य" from the first poem, identifying all morphological components and explaining their combined effect.

STEPS:
- Step 1: Segment the line into morphological units: गस (interjection/address) + हक[ (vocative particle/interjection) + एर (genitive case marker) + एप्य (noun, oblique singular masculine).
- Step 2: Identify each unit's grammatical category: गस = संबोधन/आह्वान (call), हक[ = संबोधन चिह्न (vocative marker), एर = कारक चिह्न (genitive postposition, Braj form of का), एप्य = संज्ञा (noun, 'father/lord' from अप्य/अपि).
- Step 3: Analyze the syntactic construction: [गस हक[] (independent address) + [एर एप्य] (genitive phrase modifying an implied head noun like 'चरण' or 'नाम'), forming an elliptical invocation "O Lord! [I am] of Father/Lord".
- Step 4: Determine the dialectal features: हक[ (Braj vocative vs. Khari Boli 'है/हो'), एर (Braj genitive vs. का), एप्य (अपभ्रंश < अपि/अप्य vs. आधुनिक 'पिता/बाबा').
- Step 5: Evaluate poetic function: The stacked vocatives (गस + हक[) create urgent devotional address; एर's light syllable (लघु) maintains चतुष्पदी meter; एप्य's archaic form signals timeless reverence — together establishing the poem's folk liturgical tone.

REASONING: This step-by-step morphological parsing moves from form to function to effect, modeling how linguistic analysis serves literary interpretation — each grammatical choice is shown to carry metrical, dialectal, and affective weight.

ANSWER: The line comprises two vocative clusters (गस हक[) and a genitive phrase (एर एप्य) using Braj-specific morphology (हक[, एर, एप्य) to create a metrically precise, dialectally authentic invocation that positions the speaker in humble relationship to the divine addressee.

## WORKED_EXAMPLE_2
PROBLEM: In the second poem's line "वस ेसजस त्वघ ोसQ इ्वQy तस्लस बू'ओज", identify the समास in "बू'ओज", provide its विग्रह, and explain how the compound's semantic type characterizes the addressee.

STEPS:
- Step 1: Isolate the target compound "बू'ओज" from the syntactic context (predicate adjective describing the addressee).
- Step 2: Determine the compound type by testing semantic relationships: Is it XY where X modifies Y (तत्पुरुष), or XY where the whole denotes a possessor of Y (बहुव्रीहि)? "बू'ओज" = बाज (hawk/falcon) + ओज (whose/possessor) → "वह जिसके बाज हैं" — the compound denotes the person characterized by possessing hawks, not the hawks themselves.
- Step 3: Formulate the विग्रह: "बू'ओज = बू'ओज यस्य सः" (बहुव्रीहि समास, प्रथमा तत्पुरुष अन्तर्निहित) — the head is the implied person (सः), not the noun 'बाज'.
- Step 4: Contrast with a तत्पुरुष alternative: "बाजोपजी" (बाज की ओज/मालिक) would be तत्पुरुष (बाजस्य ओज) denoting the owner as a role; बहुव्रीहि "बू'ओज" denotes the person *as* "hawk-possessor" — an identity, not a function.
- Step 5: Connect to characterization: The poet addresses the listener as "बू'ओज" (हाकिम/शिकारी/सामंत) — a feudal lord defined by his hunting hawks — establishing social hierarchy and the power dynamic underlying the speaker's plea for shelter.

REASONING: Compound analysis reveals social semantics — the बहुव्रीहि type transforms a noun (बाज) into an identity epithet, encoding the addressee's authority and the speaker's subordination in a single word.

ANSWER: "बू'ओज" is a बहुव्रीहि समास (विग्रह: बू'ओज यस्य सः) meaning "वह जिसके बाज हैं" — it characterizes the addressee as a feudal lord/hunter by his defining possession (hawks), establishing the power asymmetry that frames the poem's request for refuge.

## WORKED_EXAMPLE_3
PROBLEM: Compare the imperative constructions in both poems — "हख[ वकÅ¡" / "हख[ विSडज" (Poem 2) versus "वकबZ ग्व¡ लंस'क यसडज पुउएफवाइड्कट्कु डक" (Poem 1) — analyzing mood, voice, causativity, and politeness strategy differences.

STEPS:
- Step 1: Extract and parse Poem 2 imperatives: "हख[ वकÅ¡" = हख[ (होना, imperative 2nd pl.) + वकÅ¡ (करना, infinitive) → causative "make [it] happen/do [it]"; "हख[ विSडज" = हख[ + विSडज (देना, infinitive) → causative "make [him] give". Both are direct, authoritative causatives addressing a subordinate.
- Step 2: Extract and parse Poem 1 construction: "वकबZ ग्व¡ लंस'क यसडज पुउएफवाइड्कट्कु डक" — वकबZ (vocative 'O Lord'), ग्व¡ (गोस्वामी/स्वामी), लंस'क (लक्ष्मी/श्री), यसडज (करना, honorific plural imperative? or infinitive?), पुउएफवाइड्कट्कु (पुनीत/पावन?), डक (हो/रहो) — this is a benedictive/hortative addressing the divine, not a command to a human.
- Step 3: Compare mood: Poem 2 = आज्ञार्थ (imperative/causative) directed at human agent; Poem 1 = विध्यर्थ/आशीर्वादार्थ (optative/benedictive) directed at deity — different illocutionary forces.
- Step 4: Compare causativity: Poem 2 uses explicit causative chain (हख[ + infinitive) = "cause to do"; Poem 1 uses simple honorific imperative/optative = "may you do/be".
- Step 5: Compare politeness: Poem 2 = bald imperative (power ↑, distance ↓); Poem 1 = elaborate honorifics (वकबZ, ग्व¡, लंस'क) + optative (power ↓, distance ↑) — classic Brown-Levinson negative vs. positive politeness.
- Step 6: Synthesize: The grammatical contrast mirrors the poem's dramatic structure — Poem 1 (prayer to God) uses maximum deference; Poem 2 (demand to lord) uses minimum deference — linguistic form encodes social theology.

REASONING: This multi-parameter comparison (mood, voice, causativity, politeness) demonstrates how grammatical choices instantiate the two poems' distinct speech acts — prayer versus demand — reflecting the speaker's shifting positioning between divine and human addressees.

ANSWER: Poem 2 uses direct causative imperatives (हख[ + infinitive) for human command (high power, low distance); Poem 1 uses honorific optative/benedictive forms (वकबZ ग्व¡ लंस'क...) for divine address (low power, high distance) — the grammatical contrast enacts the speaker's theological humility before God and social assertiveness before the feudal lord.

## COMPETENCY_QUESTION_1
QUESTION: A student claims that the use of "एर" (for का), "पन" (for पर), and "उहन" (for उन्हें) in Vaddhegnasoh's poems proves the poet had "poor grammar" compared to modern Hindi. Using specific grammatical evidence from both poems, refute this claim by explaining how these forms follow systematic Braj Bhasha rules and serve poetic functions that modern equivalents would not.

COMPETENCY: Critical linguistic analysis and dialect awareness

STEPS:
- Step 1: Identify the misconception — equating dialectal variation with grammatical error.
- Step 2: Cite three Braj forms with their morphological rules (एर = genitive singular, पन = locative with nasal assimilation, उहन = 3rd pl. pronoun with archaic nasal).
- Step 3: Demonstrate metrical necessity — show how एर (लघु) fits the meter where का (गुरु) would not.
- Step 4: Explain dialectal authenticity — these forms reflect 17th-century Braj spoken language, preserving oral tradition.
- Step 5: Conclude that "grammar" is system-internal; the poet follows Braj grammar perfectly.

ANSWER: The claim confuses standard language ideology with grammaticality. "एर" follows Braj genitive paradigm (एर/एरी/एरे), "पन" derives from पर via nasal assimilation (phonological rule), "उहन" continues Apabhramsha उहण/उहन — all are rule-governed. Metrically, एर (लघु) maintains the चतुष्पदी cadence where का (गुरु) would break it. Dialectally, these forms index the poet's folk identity and audience. The poet's grammar is impeccable — it is Braj Bhasha grammar, not Khari Boli.

DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: The second poem shifts from addressing God (Poem 1) to addressing a feudal lord (बू'ओज). Analyze how the grammatical person, honorific system, and speech act verbs change between the two poems to encode this shift in addressee and power dynamics. Support your answer with four specific grammatical contrasts.

COMPETENCY: Pragmatic analysis of grammatical shifts in poetic discourse

STEPS:
- Step 1: Identify addressee in Poem 1 (divine: वकबZ ग्व¡ लंस'क) vs. Poem 2 (human lord: एसजस त्वघ... बू'ओज).
- Step 2: Contrast honorific vocabulary: Poem 1 uses वकबZ, ग्व¡, लंस'क, पुउएफवाइड्कट्कु (maximal honorifics); Poem 2 uses त्वघ (familiar 2nd person), बू'ओज (status epithet), no divine titles.
- Step 3: Contrast verb mood/voice: Poem 1 = optative/benedictive (डक, यसडज — 'may you be/do'); Poem 2 = causative imperative (हख[ वकÅ¡, हख[ विSडज — 'make happen/give').
- Step 4: Contrast case marking for speaker: Poem 1 = implicit humble self (no explicit pronoun); Poem 2 = explicit एसजस (मेरे जैसे), एपक (मेरा) — self-reference as subordinate.
- Step 5: Synthesize how grammar maps theology (God = superior) to feudalism (lord = superior but negotiable).

ANSWER: Four grammatical contrasts: (1) Honorifics: Poem 1 stacks divine titles (वकबZ ग्व¡ लंस'क); Poem 2 uses status noun बू'ओज + familiar त्वघ. (2) Mood: Poem 1 optative (डक/यसडज — wish/blessing); Poem 2 causative imperative (हख[ वकÅ¡ — command). (3) Speaker reference: Poem 1 null/elliptical (humility); Poem 2 explicit एसजस/एपक (claiming rights). (4) Speech act verbs: Poem 1 पुउएफवाइड्कट्कु (sanctify); Poem 2 वकÅ¡/विSडज (do/give — transactional). Grammar encodes the shift from vertical divine hierarchy to horizontal feudal contract.

DIFFICULTY: hard