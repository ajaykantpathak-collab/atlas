## DEFINITION
Plot and narrative structure refers to the organization of events in a prose text, including the sequence of incidents (exposition, rising action, climax, falling action, resolution) and the techniques used to present them (chronological order, flashbacks, point of view). In a biographical sketch, it maps how the author selects and arranges life events to convey a central impression.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student can identify the five stages of plot in the given biographical excerpt, explain how the author orders events to highlight Kabir's teaching method, and write a structured answer using textual evidence.

## SCOPE_BOUNDARY
This node covers the narrative structure of the prose passage about Kabir's life incident in the chapter; it does not cover the poetic structure of Kabir's verses or the thematic analysis of his poems (covered in later nodes).

## WALKTHROUGH
Imagine you are asked to summarize the incident where Kabir teaches his disciples a lesson through a practical demonstration. You might recall the events but struggle to explain why the author presents them in that specific order. Begin by reading the prose passage once to get the gist, then re-read marking the key events: the setting (Kabir with disciples), the inciting incident (a question or situation), the demonstration (Kabir's action), the disciples' reaction, and the concluding moral. Notice how the author builds tension by describing the disciples' curiosity before revealing Kabir's unconventional method. The key insight is that the narrative structure mirrors Kabir's pedagogical approach: it moves from concrete experience to abstract realization.

## DIAGNOSTIC_QUESTION_1
What are the five standard stages of a narrative plot in order?

## DIAGNOSTIC_ANSWER_1
The five stages are: exposition, rising action, climax, falling action, and resolution. A wrong answer (e.g., listing only beginning, middle, end) reveals the student lacks the precise vocabulary needed for board exam analysis and cannot map the Kabir passage onto a structured framework.

## DIAGNOSTIC_QUESTION_2
In the Kabir biographical excerpt, the author describes Kabir's daily routine and his disciples' curiosity before narrating the specific incident of the weaving demonstration. Which plot stage does this initial description represent, and why?

## DIAGNOSTIC_ANSWER_2
This is the exposition stage because it establishes the setting (Kabir's workshop), the characters (Kabir and disciples), and the background context (Kabir's method of teaching through work). A wrong answer (e.g., calling it rising action) shows the student confuses background setup with the development of conflict.

## DIAGNOSTIC_QUESTION_3
Apply the concept of 'rising action' to the passage: identify two specific events that escalate the disciples' curiosity and lead to the climax.

## DIAGNOSTIC_ANSWER_3
Two events: (1) The disciples observe Kabir weaving silently and ask about the purpose of his unusual pattern. (2) Kabir ignores their questions and continues working, heightening their anticipation. A wrong answer that picks random details indicates the student cannot distinguish between events that build tension and those that are merely descriptive.

## DIAGNOSTIC_QUESTION_4
Analyze how the author uses the narrative technique of 'showing' (describing actions and dialogue) rather than 'telling' (directly stating the moral) during the climax of the incident. What effect does this create?

## DIAGNOSTIC_ANSWER_4
At the climax, the author describes Kabir cutting the woven cloth and distributing pieces, letting the disciples (and readers) infer the lesson on detachment. This creates an experiential realization mirroring Kabir's teaching style. A wrong answer that only identifies the moral without analyzing the technique shows the student misses the author's narrative craft.

## DIAGNOSTIC_QUESTION_5
Evaluate whether the resolution of the passage (the disciples' understanding) is effectively prepared by the preceding narrative structure. Justify your view with evidence.

## DIAGNOSTIC_ANSWER_5
Yes, the resolution is effective because the falling action shows the disciples reflecting on the pieces of cloth, and the resolution ties back to the exposition's mention of Kabir's practical pedagogy. A wrong answer that calls it abrupt or unearned reveals the student has not traced the causal chain from exposition through climax.

## DIAGNOSTIC_QUESTION_6
Create a brief alternative ending for the incident that changes the narrative structure from a linear chronological order to a flashback structure. Write 3-4 sentences showing how the story would begin.

## DIAGNOSTIC_ANSWER_6
A good answer begins in medias res: "Years later, a disciple recalled the day Kabir cut his woven cloth..." then flashes back to the event. A poor answer simply rewrites the same chronological order, showing the student cannot manipulate narrative time.

## COMMON_MISCONCEPTION
Students often think 'plot' is just a summary of what happens, and they miss that narrative structure includes the author's deliberate choices of pacing, omission, and perspective. For example, they may list the weaving incident events in order but fail to notice that the author omits Kabir's internal thoughts, forcing readers to infer his intent from actions alone.

## ON_FAILURE
If a student confuses plot summary with structure analysis, guide them to: (1) Draw a plot diagram for the passage labeling each stage. (2) For each stage, ask: 'What does the author want me to feel/think here?' (3) Compare the diagram with a simple summary to see the difference. (4) Practice writing one sentence per stage using the phrase 'The author uses [stage] to...'

## BUILDS_ON
c11_hin_ar_cbse_09_001 (Before You Read: Context and Background) provides the historical and biographical context needed to understand the setting and characters in the narrative.

## LEADS_TO
c11_hin_ar_cbse_09_003 (Setting and Atmosphere) which examines how the physical and social environment shapes the narrative events.

## PREREQUISITE_NODE_IDS
c11_hin_ar_cbse_09_001
## PREREQUISITE_REASONS
c11_hin_ar_cbse_09_001: Provides essential background on Kabir's life, the Bhakti movement, and the text's source, which frames the narrative's setting and character motivations.

## FORWARD_NODE_IDS
c11_hin_ar_cbse_09_003, c11_hin_ar_cbse_09_004, c11_hin_ar_cbse_09_006, c11_hin_ar_cbse_09_005, c11_hin_ar_cbse_09_007, c11_hin_ar_cbse_09_008, c11_hin_ar_cbse_09_009, c11_hin_ar_cbse_09_010, c11_hin_ar_cbse_09_012, c11_hin_ar_cbse_09_013, c12_hin_a_cbse_09_002, c12_hin_ar_cbse_09_002

## FORWARD_REASONS
c11_hin_ar_cbse_09_003: Understanding plot structure helps identify how setting functions at each stage. c11_hin_ar_cbse_09_004: Character analysis relies on seeing how the protagonist acts across the plot arc. c11_hin_ar_cbse_09_006: Primary theme emerges from the narrative's resolution and the climax's revelation.
c11_hin_ar_cbse_09_005: Establishes the narrative structure of the poem, helping locate where supporting characters appear in the sequence of a laborer's day.  
c11_hin_ar_cbse_09_007: Narrative structure knowledge helps locate where secondary themes cluster (opening vs closing stanzas, refrain patterns).  
c11_hin_ar_cbse_09_008: Establishes the poem's narrative situation (speaker addressing the beloved) without which the addressee of the metaphors is unclear.  
c11_hin_ar_cbse_09_009: Establishes the narrative structure of the verses so students can locate where irony/symbolism appear in the poem's progression.  
c11_hin_ar_cbse_09_010: Plot and narrative structure analysis establishes where key words appear in the narrative arc, which is essential because a word's connotation is contextually determined — the same word can carry different connotations at different points in the plot.  
c11_hin_ar_cbse_09_012: Understanding the poem's narrative structure (stanza progression) helps locate where literal details appear.  
c11_hin_ar_cbse_09_013: Narrative structure awareness helps track how the poem's argument unfolds across stanzas.  
c12_hin_a_cbse_09_002: Taught irony/symbolism as structural devices.  
c12_hin_ar_cbse_09_002: Direct Class 11 counterpart for this chapter's poem type; reinforces prior exposure to similar structural analysis.  
c11_hin_ar_cbse_09_004: Establishes the poem's narrative structure (dialogue, argument, realization) which shapes how the protagonist's voice unfolds across stanzas.  
c11_hin_ar_cbse_09_006: The poem's narrative movement (outer search → inner realization → declaration) *is* the thematic argument; without mapping this structure, theme remains a static label.  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
none

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_09_001 -> c11_hin_ar_cbse_09_002 -> c11_hin_ar_cbse_09_003

## THIS_FORMULA
N/A - conceptual

## FORMULA_VARIABLES
N/A

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
conceptual

## CROSS_SUBJECT
c11_history_bhakti_movement | The biographical narrative reflects the historical context of the Bhakti movement's challenge to ritualism, which the plot structure highlights through Kabir's actions.
c11_civics_social_reform | Kabir's teaching method in the narrative illustrates social reform through personal example, a concept studied in Civics.

## PREREQ_CONCEPT
Understanding the difference between a story (chronological events) and a plot (causally linked events structured by the author) - E.M. Forster's distinction.

## PREREQ_BEFORE
Student must know the basic definition of plot stages (exposition, rising action, climax, falling action, resolution) from Class 10.

## PREREQ_STUCK
Review the plot diagram (Freytag's pyramid) and practice labeling stages in a familiar short story.

## WORKED_EXAMPLE_1
PROBLEM: Identify the exposition, rising action, climax, falling action, and resolution in the Kabir biographical excerpt (the incident where Kabir teaches through weaving). Provide one textual evidence for each stage.
STEPS:
- Step 1: Read the prose passage carefully and list the sequence of events in order.
- Step 2: Match each event to a plot stage using definitions: exposition introduces setting/characters; rising action builds tension; climax is the turning point; falling action shows consequences; resolution concludes.
- Step 3: For exposition, note the opening lines describing Kabir's routine and disciples (evidence: 'Kabir used to weave... disciples watched').
- Step 4: For rising action, identify the disciples' questions and Kabir's silence (evidence: 'Disciples asked... Kabir kept weaving').
- Step 5: For climax, locate the moment Kabir cuts the cloth (evidence: 'Kabir took scissors and cut the woven cloth').
- Step 6: For falling action, note the distribution of pieces and disciples' reflection (evidence: 'He gave pieces... they understood').
- Step 7: For resolution, identify the concluding moral statement (evidence: 'Thus Kabir taught detachment through action').
REASONING: This step-by-step mapping ensures the student moves from passive reading to active structural analysis, using textual evidence as required in board answers.
ANSWER: Exposition: Kabir's daily weaving routine and disciples' presence. Rising action: Disciples' curiosity about the pattern and Kabir's silence. Climax: Kabir cuts the finished cloth. Falling action: Distribution of cloth pieces and disciples' realization. Resolution: The lesson on detachment is internalized.

## WORKED_EXAMPLE_2
PROBLEM: Explain how the author's choice to present the incident in chronological order (linear narrative) serves the theme of experiential learning. Write a structured answer using the PEEL method (Point, Evidence, Explanation, Link).
STEPS:
- Step 1: State the point: The linear narrative mirrors the step-by-step nature of Kabir's pedagogy.
- Step 2: Provide evidence: The passage moves from Kabir's routine (exposition) to the specific demonstration (climax) without flashbacks.
- Step 3: Explain: Just as Kabir makes disciples experience each stage of weaving before revealing the lesson, the reader experiences the narrative in real time, building understanding gradually.
- Step 4: Link: This structural choice reinforces the theme that truth is realized through direct experience, not abstract preaching.
- Step 5: Conclude with a sentence connecting to the chapter's broader message.
REASONING: The PEEL structure teaches exam-ready answer writing; linking narrative technique to theme is a higher-order skill tested in board exams.
ANSWER: The linear narrative structure mirrors Kabir's experiential pedagogy. The author presents events in chronological order — from Kabir's daily weaving to the climactic cutting of the cloth — without flashbacks or authorial commentary. This forces the reader, like the disciples, to progress through confusion to insight step by step. Thus, the narrative form enacts the theme: truth is learned through lived process, not mere words.

## WORKED_EXAMPLE_3
PROBLEM: Compare the narrative structure of this biographical incident with the structure of a typical Kabir poem (e.g., the poem 'Ge rakh ek ek dhaj...' in the same chapter). How does each structure suit its purpose?
STEPS:
- Step 1: Recall the plot structure of the prose incident (linear, five stages).
- Step 2: Analyze the poem's structure: it uses a series of metaphors (body as tent, breath as weaver) in a non-narrative, argumentative pattern.
- Step 3: Identify the purpose of the prose: to illustrate a teaching moment through story.
- Step 4: Identify the purpose of the poem: to convey philosophical truth through condensed imagery.
- Step 5: Compare: Prose uses temporal sequence to simulate experience; poem uses spatial metaphors to provoke insight.
- Step 6: Conclude: The prose's narrative arc builds empathy; the poem's juxtaposition shocks awareness.
REASONING: This integrates plot analysis with poetic structure (covered in later nodes), showing how form follows function across genres in the same chapter.
ANSWER: The biographical prose uses a linear narrative arc (exposition to resolution) to simulate the disciples' experiential learning, making the reader a participant. The poem uses a non-narrative, metaphorical structure (body as tent, breath as weaver) to deliver immediate philosophical insight. The prose builds understanding through time; the poem compresses truth into images. Both serve Kabir's aim but through different structural logics: one narrative, one lyrical.

## COMPETENCY_QUESTION_1
QUESTION: The biographical excerpt ends with the disciples understanding Kabir's lesson. Suppose the author had placed the moral lesson at the beginning (as a prologue) and then narrated the incident. How would this change the narrative structure and its impact on the reader? Explain using the concepts of exposition and climax.
COMPETENCY: Analyzing narrative perspective and structural choices
STEPS:
- Step 1: Identify the current structure: exposition -> rising action -> climax (cutting cloth) -> falling action -> resolution.
- Step 2: Describe the altered structure: prologue (moral) -> flashback narration of incident -> confirmation.
- Step 3: Analyze impact: The climax loses its surprise; the reader becomes an observer judging the disciples rather than sharing their discovery.
- Step 4: Connect to theme: Kabir's method is about direct experience; a prologue would turn it into instruction, contradicting the theme.
- Step 5: Conclude with evaluation.
ANSWER: Moving the moral to the start would convert the narrative from a discovery structure to a confirmation structure. The current climax (cutting the cloth) works because the reader, like the disciples, does not know the outcome. A prologue would make the climax merely illustrative, reducing tension and shifting the reader's role from participant to evaluator. This undermines the theme of experiential learning central to Kabir's pedagogy.
DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: In the passage, the author chooses not to reveal Kabir's internal thoughts during the weaving. Instead, only actions and dialogues are shown. Using the concept of 'narrative point of view', analyze how this choice affects the plot structure, particularly the rising action and climax.
COMPETENCY: Evaluating narrative technique and its structural function
STEPS:
- Step 1: Identify the point of view: third-person limited (external), showing actions/dialogue but not Kabir's mind.
- Step 2: Explain effect on rising action: The disciples' (and reader's) curiosity builds because Kabir's intention is hidden.
- Step 3: Explain effect on climax: The cutting of the cloth becomes a shock/revelation because there was no internal foreshadowing.
- Step 4: Contrast with an omniscient view: If Kabir's thoughts were given, the rising action would be weaker and the climax less powerful.
- Step 5: Relate to Kabir's teaching style: The narrative technique mirrors Kabir's 'show, don't tell' method.
ANSWER: The external point of view withholds Kabir's intent, making the rising action depend entirely on the disciples' growing puzzlement. The climax — the sudden cutting of the cloth — gains force because neither the disciples nor the reader anticipated it. An omniscient view revealing Kabir's plan would flatten the rising action and diminish the climax's impact. This structural choice enacts Kabir's pedagogy: truth arrives through unexpected action, not explanation.
DIFFICULTY: hard