## DEFINITION
Writing skills based on the chapter "Phir Koi Khushboo" refer to the ability to compose structured, evidence-based responses — such as critical appreciations, thematic analyses, and answers to comprehension questions — that demonstrate understanding of the poet's language, imagery, and philosophical themes using the PEEL (Point, Evidence, Explanation, Link) framework.

## COGNITIVE_LEVEL
apply

## MASTERY_CRITERIA
The student can independently write a 150-200 word critical appreciation of any poem from the chapter, embedding at least three textual references with accurate literary terminology, and can answer a 5-mark board-style question using the PEEL structure without prompting.

## SCOPE_BOUNDARY
This node covers writing analytical answers, critical appreciations, and theme-based paragraphs specifically for the three poems of Phir Koi Khushboo (Chapter 8, Antra). It does NOT cover creative writing, letter writing, or essay writing unrelated to the chapter's poems.

## WALKTHROUGH
Imagine you're in the exam hall facing a 5-mark question: "Explain the pain of separation in Phir Koi Khushboo's second poem." You recall the poem but your answer rambles, repeats the story, and gets only 2 marks. Why? Because you summarised instead of analysed. Let's fix that. First, read the question and underline keywords: "pain of separation", "second poem". Next, jot down 2-3 precise points from the poem (e.g., the gopis' sleepless nights, the metaphor of the dark night). Then, for each point, write one sentence stating the point, one quoting or paraphrasing the line, one explaining the literary device, and one linking back to the central theme of viraha bhakti. This PEEL loop — Point, Evidence, Explanation, Link — turns recall into analysis. Practice this on all three poems; the examiner rewards structured argument, not memory dump.

## DIAGNOSTIC_QUESTION_1
What does the acronym PEEL stand for in the context of writing analytical answers for literature?

## DIAGNOSTIC_ANSWER_1
PEEL stands for Point, Evidence, Explanation, Link. A wrong answer (e.g., "Paragraph, Example, Explanation, Language") reveals the student has memorised a mnemonic without understanding its analytical function — they cannot map each letter to a cognitive step (claim → textual support → device analysis → thematic connection), so their answers remain descriptive.

## DIAGNOSTIC_QUESTION_2
A student writes: "In the first poem, the gopis are very sad because Krishna left. They cry all night and the poet uses sad words." Identify two specific weaknesses in this response relative to board exam expectations.

## DIAGNOSTIC_ANSWER_2
Weakness 1: No textual evidence — "sad words" is vague; the answer must cite a specific image (e.g., "the dark night of separation" or "the unlit lamp"). Weakness 2: No analysis of literary device — the student states effect ("sad") but does not name the metaphor, personification, or sound pattern that creates it. A wrong diagnosis (e.g., "the answer is too short") misses the structural flaw: missing PEEL components.

## DIAGNOSTIC_QUESTION_3
Apply the PEEL structure to answer: "How does the poet use nature imagery to convey the gopis' inner state in the third poem?" Provide the Point and Evidence steps only.

## DIAGNOSTIC_ANSWER_3
Point: The poet maps the gopis' emotional desolation onto the withered natural landscape. Evidence: In the third poem, the line describing "dry leaves trembling on leafless branches" (paraphrased from 'pallavheen taruvar pat jhad') mirrors the gopis' fragile, exposed vulnerability. A wrong step (e.g., quoting the Hindi line without translating its imagistic function) shows the student treats evidence as decoration, not as analytical raw material.

## DIAGNOSTIC_QUESTION_4
Compare the effectiveness of two sample opening sentences for a critical appreciation of the second poem:
(A) "This poem is about the gopis missing Krishna."
(B) "Phir Koi Khushboo transforms the gopis' personal grief into a universal metaphor of the soul's separation from the divine through sustained night-imagery."
Which is stronger and why? Analyse in terms of scope, terminology, and thesis-driven focus.

## DIAGNOSTIC_ANSWER_4
(B) is stronger. Scope: (A) reduces the poem to plot summary; (B) frames it as a metaphysical exploration (virah bhakti). Terminology: (B) uses "metaphor", "universal", "sustained night-imagery" — analytical vocabulary; (A) uses only narrative verbs. Thesis-driven: (B) announces an argument the essay will prove; (A) states a fact. A student choosing (A) confuses narration with criticism — a fatal board-exam error.

## DIAGNOSTIC_QUESTION_5
Evaluate this claim: "In Phir Koi Khushboo's poems, the Braj/Awadhi dialect is merely a decorative choice; the same themes could be expressed in standard Hindi without loss." Defend or refute using two specific linguistic features from the poems.

## DIAGNOSTIC_ANSWER_5
Refute. Feature 1: The dialect's vowel elongation (e.g., "niraas" → "niraas hoi") mimics the drawn-out ache of separation — standard Hindi's clipped vowels lose this sonic embodiment. Feature 2: Colloquial endearments ("sakhi", "priya") carry cultural intimacy that formal "sakhī" or "priyā" sterilise. A student agreeing with the claim ignores how phonetics and register enact theme — a competitive-exam trap testing dialect-awareness.

## DIAGNOSTIC_QUESTION_6
Create a 4-sentence PEEL paragraph answering: "Explain the significance of the 'unlit lamp' image in the first poem." Invent a plausible textual detail if needed, but maintain the poem's internal logic.

## DIAGNOSTIC_ANSWER_6
Point: The unlit lamp symbolises the gopis' extinguished hope of union. Evidence: The poem describes the lamp standing "cold and wickless" through the night of separation. Explanation: The metaphor transfers the physical absence of light to the spiritual absence of Krishna, while the lamp's passive stillness mirrors the gopis' helpless waiting. Link: Thus a domestic object becomes a theological statement — devotion persists even when grace seems absent. A poor answer invents an image not in the poem (e.g., "broken lamp") or omits the Link, leaving the symbol unconnected to the central theme.

## COMMON_MISCONCEPTION
Students believe "writing skills" means using flowery vocabulary and long sentences. In Phir Koi Khushboo answers, they load paragraphs with adjectives ("heart-wrenching, soul-stirring, extremely painful") but omit the textual anchor — e.g., they write "the poet beautifully describes the night" without quoting the line where darkness is compared to "a blind well". The misconception stems from confusing *emotive language* with *analytical language*. Board marking schemes award marks for *specific reference + device identification + thematic linkage*, not for intensity of praise. This error costs 2-3 marks per 5-mark question because the examiner cannot locate the evidence.

## ON_FAILURE
1. Have the student pick one 3-mark question from the chapter's exercise. 2. Ask them to highlight every adjective in their draft — if >30% of words are adjectives, they are describing, not analysing. 3. Force-replace each adjective cluster with a PEEL cycle: delete the adjectives, insert a quoted phrase, name the device, explain its effect. 4. Re-mark using the CBSE 3-mark rubric (1 mark point, 1 mark evidence, 1 mark explanation). Repeat until they score 3/3 on two consecutive attempts. Then move to 5-mark questions.

## BUILDS_ON
Critical thinking skills (node c12_hin_a_cbse_08_013) — the student must already be able to identify themes, devices, and structural choices before writing about them.

## LEADS_TO
Speaking and listening discussion (node c12_hin_a_cbse_08_015) — written analytical paragraphs become the script for oral presentations and debates on the poems.

## PREREQUISITE_NODE_IDS
c12_hin_a_cbse_08_012, c12_hin_a_cbse_08_013, c12_hin_a_cbse_08_006, c12_hin_a_cbse_08_008, c12_hin_a_cbse_08_009, c11_hin_ar_cbse_01_014, c12_hin_a_cbse_08_001, c12_hin_a_cbse_08_007, c12_hin_a_cbse_08_010, c12_hin_a_cbse_08_011

## PREREQUISITE_REASONS
c12_hin_a_cbse_08_012: Provides literal and inferential comprehension — the raw textual knowledge needed for Evidence step.
c12_hin_a_cbse_08_013: Supplies analytical frameworks (theme tracing, device mapping) that become the Point and Explanation steps.
c12_hin_a_cbse_08_006: Establishes the primary theme (virah bhakti) which is the ultimate Link target in every paragraph.
c12_hin_a_cbse_08_008: Teaches imagery identification — the main device category in these poems.
c12_hin_a_cbse_08_009: Teaches irony/symbolism identification — needed for deeper Explanation in Poems 2 and 3.
c11_hin_ar_cbse_01_014: Class 11 writing skills foundation — PEEL structure, answer formatting, quotation embedding.
c12_hin_a_cbse_08_001: Writing tasks require contextual evidence.  
c12_hin_a_cbse_08_007: Writing skills (analytical paragraphs, essays) directly apply the PEEL method taught here.  
c12_hin_a_cbse_08_010: Writing skills require students to deploy context-appropriate vocabulary in analytical paragraphs.  
c12_hin_a_cbse_08_011: Language Usage in the Text refers to the systematic analysis of grammatical structures, li... की समझ आवश्यक है, क्योंकि यह नोड (Writing skills based on the chapter "Phir Koi Khushboo" refer to the ability to compose st...) इसी आधार पर आगे बढ़ता है।  

## FORWARD_NODE_IDS
c12_hin_a_cbse_08_015
## FORWARD_REASONS
c12_hin_a_cbse_08_015: Speaking and listening tasks require students to present and defend the same analytical positions they have practised writing — the written paragraph is the scaffold for oral articulation.

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
N/A

## CHAIN_DESCRIPTION
c12_hin_a_cbse_08_012 -> c12_hin_a_cbse_08_014 -> c12_hin_a_cbse_08_015

## THIS_FORMULA
PEEL = Point (1 sentence claim) + Evidence (1 quoted/paraphrased line with poem/stanza ref) + Explanation (1-2 sentences naming device & analysing effect) + Link (1 sentence connecting to poem's central theme/virah bhakti)

## FORMULA_VARIABLES
P = analytical claim about the poem; E = textual support with location; E = device name + effect analysis; L = thematic synthesis statement

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
linguistic

## CROSS_SUBJECT
N/A | The poems exemplify Nirguna/Saguna Bhakti synthesis; historical context of 14th-15th century North Indian devotional movements explains the poet's theological vocabulary and audience.
 N/A | The PEEL structure and critical appreciation format are identical to English Core's "Long Answer - Literature" questions; mastery transfers directly across language papers.
## PREREQ_CONCEPT
Ability to distinguish between narrative summary (what happens) and literary analysis (how meaning is made) — taught in Critical Thinking node.

## PREREQ_BEFORE
Student must have completed Comprehension (012) and Critical Thinking (013) nodes for this chapter, and know the central theme (virah bhakti) and at least five literary devices with examples from the three poems.

## PREREQ_STUCK
If stuck on Evidence step, return to Comprehension node (c12_hin_a_cbse_08_012) and re-do the "quote hunt" exercise for the target poem. If stuck on Explanation step, return to Literary Devices nodes (008, 009) and re-practise device-effect mapping.

## WORKED_EXAMPLE_1
PROBLEM: Improve this weak 3-mark answer to Question 2 from the chapter exercise: "The poet wants to show the helplessness of the gopis through the image of the dark night." Current answer: "The poet shows the gopis are helpless because the night is dark and they cannot see anything. They are waiting for Krishna but he doesn't come. The dark night is a symbol of their sadness."
STEPS:
- Step 1: Identify the question's demand — "through the image of the dark night" requires analysis of *how* the image works, not just *that* it exists.
- Step 2: Locate the precise textual evidence — in Poem 2, the lines "andheri raat / suhagin ke maang jaisi" (the dark night like a married woman's parting) and "diya na jale" (the lamp won't light).
- Step 3: Draft the Point: The dark night functions as an extended metaphor equating cosmic darkness with the gopis' spiritual desolation.
- Step 4: Embed Evidence with device label: The simile "andheri raat suhagin ke maang jaisi" (stanza 2) fuses the night's blackness with the auspicious vermilion parting — irony: the symbol of marital fulfilment becomes the sign of separation.
- Step 5: Write Explanation: The irony intensifies helplessness — the very marker of their identity as Krishna's beloveds (the sindoor) is now the colour of his absence.
- Step 6: Write Link: Thus the night-image does not merely set mood; it encodes the theological paradox of virah — union's symbols become separation's proof.
REASONING: The original answer stated the theme (helplessness) and the image (dark night) but skipped the *mechanism* — the simile, the irony, the theological weight. PEEL forces each analytical layer into a separate sentence, making the argument visible to the examiner.
ANSWER: The dark night functions as an extended metaphor equating cosmic darkness with the gopis' spiritual desolation. In stanza 2, the simile "andheri raat suhagin ke maang jaisi" fuses the night's blackness with the auspicious vermilion parting — irony: the symbol of marital fulfilment becomes the sign of separation. This irony intensifies helplessness because the very marker of their identity as Krishna's beloveds (the sindoor) is now the colour of his absence. Thus the night-image does not merely set mood; it encodes the theological paradox of virah — union's symbols become separation's proof.

## WORKED_EXAMPLE_2
PROBLEM: Write a 5-mark critical appreciation of the third poem focusing on sound patterns (dhvani) and their thematic function.
STEPS:
- Step 1: Read the poem aloud twice; mark recurring sounds — alliteration (anunasik 'ṅ', 'ṁ'), onomatopoeic verbs (jhankar, jhar), vowel elongation in refrain.
- Step 2: Formulate thesis (Point): The poem's soundscape enacts the gopis' internal oscillation between hope and despair through controlled sonic repetition.
- Step 3: Select Evidence 1: The anunasik cluster in "nirgun brahm / nirankar / nirantar" (stanza 1) — nasal resonance creates a humming continuity.
- Step 4: Explanation 1: The nasal alliteration mimics the unbroken drone of the tanpura — the nirguna concept made audible; sound becomes theology.
- Step 5: Select Evidence 2: The abrupt plosives in "tut gayi / bansuri / ek pal mein" (stanza 3) — /t/, /g/, /b/ break the flow.
- Step 6: Explanation 2: Plosive cluster enacts the sudden fracture of devotion — the flute (Krishna's call) snaps, ending the drone.
- Step 7: Link: Sound pattern mirrors the poem's arc — from nirguna continuity to saguna rupture — proving form *is* content in Phir Koi Khushboo's craft.
REASONING: Competitive exams (CUET, JEE language papers) increasingly test sound-pattern analysis. This example models the move from "identifying alliteration" to "explaining how phonetics maps onto philosophical structure" — the leap from Class 11 to Class 12 depth.
ANSWER: The poem's soundscape enacts the gopis' internal oscillation between hope and despair through controlled sonic repetition. The anunasik cluster in "nirgun brahm / nirankar / nirantar" creates a humming nasal continuity that mimics the unbroken drone of the tanpura — the nirguna concept made audible; sound becomes theology. Conversely, the abrupt plosives in "tut gayi / bansuri / ek pal mein" (/t/, /g/, /b/) fracture the flow, enacting the sudden rupture of devotion when the flute — Krishna's call — snaps. Thus the shift from nasal drone to plosive break mirrors the poem's arc: from nirguna continuity to saguna rupture, proving form *is* content in Phir Koi Khushboo's craft.

## WORKED_EXAMPLE_3
PROBLEM: A 6-mark comparative question: "Compare the use of the 'sakhi' (confidante) figure in Poem 1 and Poem 3. How does the poet's treatment of this interlocutor reflect shifting theological emphasis?"
STEPS:
- Step 1: Re-read both poems marking every address to/interaction with 'sakhi'.
- Step 2: Tabulate differences: Poem 1 — sakhi as witness to physical suffering ("sakhi, mori mat ki kaise bitaave"); Poem 3 — sakhi as philosophical debater ("sakhi, nirgun brahm vichar").
- Step 3: Identify device shift: Poem 1 uses dramatic monologue (emotional outpouring); Poem 3 uses dialectical dialogue (intellectual inquiry).
- Step 4: Formulate Point: The sakhi evolves from emotional confidante to theological sparring partner, mirroring the poet's shift from saguna virah to nirguna inquiry.
- Step 5: Evidence 1 (Poem 1): "sakhi, main to prem diwani / mohe koi na bujhaye" — sakhi receives raw affect; device: apostrophe + hyperbole.
- Step 6: Explanation 1: The apostrophe isolates the speaker; hyperbole ("prem diwani") centres *feeling* — saguna bhakti's hallmark.
- Step 7: Evidence 2 (Poem 3): "sakhi, nirgun brahm vichar / kaun samjhaye" — sakhi is challenged to explain the formless; device: rhetorical question + philosophical terminology.
- Step 8: Explanation 2: Rhetorical question invites discourse; terminology ("nirgun brahm") centres *knowledge* — nirguna bhakti's hallmark.
- Step 9: Link: The same interlocutor mediates two bhakti modes — first heart, then mind — revealing Phir Koi Khushboo's synthetic vision.
REASONING: Comparative questions test synthesis across texts. This worked example shows how to build a comparison table first, then convert each row into a PEEL block, and finally synthesise in the Link — a 9-step process that mirrors the 6-mark board rubric (2 marks comparison, 2 marks evidence, 2 marks synthesis).
ANSWER: The sakhi evolves from emotional confidante to theological sparring partner, mirroring the poet's shift from saguna virah to nirguna inquiry. In Poem 1, "sakhi, main to prem diwani / mohe koi na bujhaye" uses apostrophe and hyperbole to centre raw feeling — the sakhi witnesses love's madness, hallmark of saguna bhakti. In Poem 3, "sakhi, nirgun brahm vichar / kaun samjhaye" deploys rhetorical question and philosophical terminology to centre knowledge — the sakhi debates the formless, hallmark of nirguna bhakti. The same interlocutor thus mediates two bhakti modes: first heart, then mind — revealing Phir Koi Khushboo's synthetic vision where virah matures into vichar.

## COMPETENCY_QUESTION_1
QUESTION: You are helping a Class 11 student prepare for their Hindi exam. They have written this answer to "Explain the metaphor of the flute in Phir Koi Khushboo's poems": "The flute is very important. It represents Krishna. When it plays, the gopis are happy. When it stops, they are sad. The poet uses it nicely." Using the PEEL framework, rewrite this answer to meet Class 12 board standards (3 marks). Your rewrite must include: (a) a precise Point, (b) a quoted line from any poem, (c) the specific literary device name, (d) an Explanation of the device's effect, and (e) a Link to the central theme.
COMPETENCY: Analytical writing / textual evidence integration
STEPS:
- Step 1: Diagnose the weaknesses — vague claim, no quotation, no device name, no analysis, no thematic link.
- Step 2: Formulate a precise Point: The flute operates as a metonym for Krishna's presence/absence, governing the gopis' emotional rhythm.
- Step 3: Select Evidence: From Poem 2, "bansuri ki tan / hriday mein basi" (the flute's strain dwells in the heart).
- Step 4: Name device & explain: Metonymy — the part (flute's sound) stands for the whole (Krishna); its "dwelling" internalises the divine, making absence visceral.
- Step 5: Link to theme: This metonymic chain — flute → sound → heart → void — maps the virah trajectory from union to separation to sublimation.
ANSWER: The flute operates as a metonym for Krishna's presence/absence, governing the gopis' emotional rhythm. In Poem 2, "bansuri ki tan / hriday mein basi" employs metonymy — the part (flute's strain) stands for the whole (Krishna) — and its "dwelling" internalises the divine, making absence visceral. This metonymic chain — flute → sound → heart → void — maps the virah trajectory from union to separation to sublimation.
DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: A CUET-style assertion-reason question appears:
Assertion (A): Phir Koi Khushboo's use of Braj/Awadhi dialect is essential to the poems' devotional efficacy.
Reason (R): The dialect's phonetic features (nasalisation, vowel elongation) and colloquial register enact the bodily experience of virah, which standard Hindi would abstract.
Choose the correct option:
(a) Both A and R are true and R correctly explains A.
(b) Both A and R are true but R does not explain A.
(c) A is true but R is false.
(d) A is false but R is true.
Justify your choice with two specific phonetic/register examples from the poems.
COMPETENCY: Critical evaluation / dialect-awareness / competitive exam pattern
STEPS:
- Step 1: Evaluate Assertion — true; the poet deliberately chose Braj/Awadhi over Sanskrit/standard Hindi for accessibility and embodied affect.
- Step 2: Evaluate Reason — true; nasalisation (e.g., "maṅg" in "maṅg ki baat"), vowel elongation ("viraha" → "virahaa"), and colloquial vocatives ("sakhi re") somaticise longing.
- Step 3: Check explanatory link — R directly explains *how* the dialect achieves devotional efficacy (bodily enactment vs abstraction).
- Step 4: Select option (a).
- Step 5: Provide examples: (1) Anunasik in "nirantar" hums like a held breath; (2) Colloquial "re" in "sakhi re" carries intimate urgency lost in formal "sakhi".
ANSWER: Option (a) — Both A and R are true and R correctly explains A. The dialect's anunasik in "nirantar" creates a somatic drone mimicking unbroken remembrance, and the colloquial vocative "re" in "sakhi re" injects bodily urgency — standard Hindi's "nirantar" and "sakhi" abstract these into mere concepts, diluting virah's visceral truth.
DIFFICULTY: hard