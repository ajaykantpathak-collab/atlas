## DEFINITION
Setting and atmosphere in prose refer to the physical, temporal, and social environment in which a narrative unfolds, and the emotional mood or tone it evokes; in "Hkh'e lkguh," the shifting settings — Lucknow of 1938, Delhi of the Emergency era, Varanasi's literary circles — create a layered atmosphere that mirrors the author's intellectual journey and the nation's political transformation.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student must be able to (1) identify at least three distinct settings in the text with their temporal markers, (2) explain how each setting shapes the atmosphere through sensory details and historical context, and (3) write a structured 150-word analysis linking a specific setting to a character's internal state or a thematic concern using textual evidence.

## SCOPE_BOUNDARY
This node covers identification and analysis of physical places (Lucknow, Delhi, Varanasi), time periods (1938, Emergency, post-Emergency), and social milieux (literary addas, university, government office) in "Hkh'e lkguh" and their atmospheric effects; it does NOT cover character psychology in isolation, plot summary, or thematic essay writing — those are addressed in sibling nodes 004, 002, and 006 respectively.

## WALKTHROUGH
Imagine you are walking through the lanes of old Lucknow in 1938 — the smell of kebabs, the sound of Urdu poetry from a nearby mushaira, the tension of a looming war — and then suddenly you are in a Delhi government office during the Emergency, where whispers replace conversations. That jarring shift is exactly what Hkh'e lkguh achieves. Begin by listing every place-name and time-marker you can spot in the text: "lsokxzke 1938," "ve`rlj," "V~;wful," "fnYyh fo'ofo|ky;." Next, for each, note the sensory words the author uses — "jsyxkM+h oèkkZ," "fnuHkj rks iafMrth LFkkuh; usrkvksa osQ lkFk txg&txg ?kwers." Then ask: what mood does this create? Fear? Nostalgia? Intellectual excitement? Finally, connect that mood to what the protagonist is experiencing internally at that moment. The key insight: setting in this memoir is not backdrop; it is a character that presses on the narrator's consciousness.

## DIAGNOSTIC_QUESTION_1
Identify the three primary physical settings in "Hkh'e lkguh" and the approximate time period associated with each.

## DIAGNOSTIC_ANSWER_1
The three primary settings are: (1) Lucknow (lsokxzke) — 1938, pre-World War II; (2) Delhi (ve`rlj / fnYyh) — spanning the author's university years, Emergency (1975–77), and post-Emergency; (3) Varanasi (V~;wful) — during the Emergency period when the author visits Shrikant Verma. A wrong answer that lists only "Lucknow and Delhi" or misses the Emergency timeframe reveals the student treats setting as mere geography without temporal layering.

## DIAGNOSTIC_QUESTION_2
Explain how the description of the Lucknow coffee house ("jsyxkM+h oèkkZ") in the opening pages establishes an atmosphere of intellectual ferment and impending historical change.

## DIAGNOSTIC_ANSWER_2
The coffee house is described as a space where "lkjk fdLlk lquus dks feyk fd oSQls mUgksaus gFkdfM+;ksa lesr] Hkkxrh jsyxkM+h esa ls Nyk¡x yxkbZ vkSj fudy Hkkxus esa liQy gq, vkSj fiQj xqeuke jgdj cjlksa rd ,d txg vè;kiu dk;Z djrs jgs" — the sensory details of smoke, half-read newspapers, and prolonged debates create a dense, charged atmosphere. The mention of "i`Foh¯lg vk"kkn" and "jktsanz ckcw" juxtaposes colonial bureaucracy with nationalist fervour. A wrong answer focusing only on "people talking" misses how specific sensory and historical markers construct the atmosphere.

## DIAGNOSTIC_QUESTION_3
The author writes: "'kke dks izkFkZuk lHkk esa tk igq¡prk] tgk¡ lHkh vkJeoklh rFkk dLrwjck ,d vksj dks ikyFkh ekjs vkSj nksuksa gkFk xksn esa j[ks cSBh gksrha vkSj fcyoqQy esjh ek¡ tSlh yxrha." Apply the concept of atmosphere to explain what this evening scene in Lucknow conveys about the narrator's state of mind.

## DIAGNOSTIC_ANSWER_3
The scene uses sensory overload — auditory ("fcyoqQy"), visual ("ikyFkh ekjs," "gkFk xksn"), tactile ("ek¡ tSlh yxrha") — to create a suffocating, dreamlike atmosphere that mirrors the narrator's youthful confusion and awakening desires. The merging of "vkJeoklh rFkk dLrwjck" (the ordinary and the rugged) in one space reflects his own transitional phase between student and writer. A wrong answer that merely paraphrases the scene ("it was evening and he felt strange") fails to link atmospheric density to psychological state.

## DIAGNOSTIC_QUESTION_4
Compare the atmosphere of the Varanasi visit during Emergency (described in the "lnjeqdke" section) with the Lucknow coffee house atmosphere of 1938. What does the shift reveal about the author's evolving relationship with power and literature?

## DIAGNOSTIC_ANSWER_4
The 1938 coffee house is open, cacophonous, and idealistic — "vLFkk;h ljdkj dk cM+k ;ksxnku" coexists with literary dreams. The Varanasi Emergency visit is claustrophobic: "laHko gS laiknd egksn; us lqj{kk dh n`f"V ls gesa [kksydj u crk;k gks," "gekjk okrkZyki ”;knk nwj rd rks tk ugha ldrk Fkk." The shift from public debate to surveilled silence shows literature moving from resistance to survival. A wrong answer listing only "one was free, one was not" misses the nuanced continuity: Shrikant Verma remains the bridge, but his role changes from peer to power-broker.

## DIAGNOSTIC_QUESTION_5
Evaluate the author's choice to embed the folk-tale of the crow and the mother ("ck”khxj... ekrk efj;e") within the Varanasi Emergency setting. Does this narrative-within-narrative strengthen or dilute the oppressive atmosphere? Justify.

## DIAGNOSTIC_ANSWER_5
It strengthens the atmosphere by counterpoint: the folk-tale's raw, primal desperation ("flj osQ cy [kM+s gksdj] dHkh rjg&rjg vaxpkyu djrs gq, cM+h rUe;rk osQ lkFk") mirrors the political desperation outside, while its oral, communal telling ("es”k ij cSBs lHkh O;fDr nÙkfpr gksdj lqu jgs Fks") contrasts with the atomized fear of the Emergency. The tale becomes a coded resistance. A wrong answer calling it "a distraction" or "just a story" fails to see how embedded narratives can amplify atmosphere through thematic resonance.

## DIAGNOSTIC_QUESTION_6
Write a 100-word atmospheric description of a fictional fourth setting — a railway station platform in 1947 — that could fit into "Hkh'e lkguh," using at least three sensory details and one historical marker to evoke the same layered mood as the original text.

## DIAGNOSTIC_ANSWER_6
A strong answer will include: (1) sensory details — e.g., "steam hissing like suppressed screams," "smell of coal dust and mango pickle," "hands clutching tin trunks"; (2) historical marker — "partition notices peeling on walls," "a newspaper headline 'TRANSFER OF POWER'"; (3) mood — uncertainty, displacement, quiet endurance; (4) connection to narrator's voice — reflective, observant, slightly detached. A poor answer lists details without mood or uses generic partition clichés without the author's characteristic blend of personal and political.

## COMMON_MISCONCEPTION
Students often treat "setting" as a static list of places (Lucknow, Delhi, Varanasi) and "atmosphere" as a single adjective ("nostalgic," "tense"). In "Hkh'e lkguh," each setting carries multiple, shifting atmospheres: the Lucknow coffee house is simultaneously intellectually vibrant, politically charged, and personally claustrophobic for the young narrator. The error arises because students look for one dominant mood per setting instead of mapping how the same physical space generates different atmospheres for different characters at different moments — e.g., Shrikant Verma finds the coffee house energizing; the narrator finds it overwhelming. This flattening costs marks in board questions asking "how does the author create atmosphere?" and in CUET questions comparing settings across texts.

## ON_FAILURE
If the student cannot distinguish layered atmospheres within one setting: (1) Have them re-read the coffee house passage (pages 90–91) and highlight every sensory word in one colour, every historical reference in another, every emotional descriptor in a third. (2) Ask them to complete a three-column table: Sensory Detail | Historical Marker | Narrator's Feeling. (3) Then have them write two sentences: "The coffee house feels ___ because ___" and "But for Shrikant Verma it feels ___ because ___." (4) Re-diagnose with Question 2 — they should now produce an answer linking specific sensory-historical pairings to specific moods.

## BUILDS_ON
This node builds on the Class 11 skill of identifying setting details (c11_hin_ar_cbse_13_003) by adding temporal layering, sensory-atmosphere mapping, and the concept of setting as active psychological pressure.

## LEADS_TO
This node enables c12_hin_a_cbse_13_004 (Character Analysis: Protagonist) because the narrator's character is revealed through his responses to shifting atmospheres, and c12_hin_a_cbse_13_006 (Theme: Primary Theme) because the nation's political atmosphere is a central theme.

## PREREQUISITE_NODE_IDS
c12_hin_a_cbse_13_001, c12_hin_a_cbse_13_002, c11_hin_ar_cbse_13_003, c11_hin_ar_cbse_01_003, c11_hin_v_cbse_01_003

## PREREQUISITE_REASONS
c12_hin_a_cbse_13_001: Provides historical-literary context (Progressive Writers, Emergency) essential for decoding atmosphere.
c12_hin_a_cbse_13_002: Establishes narrative chronology so settings can be placed in correct sequence.
c11_hin_ar_cbse_13_003: Class 11 foundation — identifying physical/temporal setting markers in Hindi prose.
c11_hin_ar_cbse_01_003: Additional Class 11 practice with setting analysis in "Aroh" textbook.
c11_hin_v_cbse_01_003: Class 11 "Vitan" practice — non-fiction prose setting analysis.

## FORWARD_NODE_IDS
c12_hin_a_cbse_13_004, c12_hin_a_cbse_13_006, c12_hin_a_cbse_13_008, c12_hin_a_cbse_13_013, c12_hin_a_cbse_13_005, c12_hin_a_cbse_13_010

## FORWARD_REASONS
c12_hin_a_cbse_13_004: Protagonist's character is shaped by his navigation of these atmospheres.
c12_hin_a_cbse_13_006: Primary theme (artist vs. state, memory vs. history) emerges from setting-atmosphere interplay.
c12_hin_a_cbse_13_008: Imagery and metaphor (node 008) are the linguistic tools used to render atmosphere.
c12_hin_a_cbse_13_013: Critical interpretation (node 013) requires atmosphere analysis as evidence.
c12_hin_a_cbse_13_005: Setting/atmosphere (press office, prison, restaurant) shapes how characters behave and what they symbolize.  
c12_hin_a_cbse_13_010: Setting and atmosphere clarify words like "phoj" and "fno~Q".  

## CROSS_SUBJECT_PREREQS
c11_geo_cbse_07_002

## CROSS_SUBJECT_REASONS
c11_his_cbse_13_003: Class 11 History "Themes in Indian History Part III" — Nationalism and Partition — provides the historical backbone for the 1938 and 1947 atmospheres in the text.
c11_geo_cbse_07_002: Class 11 Geography "Human Geography" — cultural landscapes and sense of place — offers conceptual tools for analyzing how physical spaces acquire emotional meaning.

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_13_003 -> c12_hin_a_cbse_13_003 -> c12_hin_a_cbse_13_004

## THIS_FORMULA
N/A - conceptual

## FORMULA_VARIABLES
N/A

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
conceptual

## CROSS_SUBJECT
c12_hist_cbse_03_004 | The Emergency (1975–77) in Class 12 History "Contemporary India" provides the political context for the Varanasi/Delhi atmosphere in the text.
 N/A | Class 12 Political Science "Democratic Resurgence" — civil liberties during Emergency — explains the surveillance atmosphere ("laiknd egksn; us lqj{kk dh n`f"V") in the memoir.
 c12_soc_cbse_04_003 | Class 12 Sociology "Social Change and Development" — intellectuals and public sphere — illuminates the coffee house as a sociological space of debate.
## PREREQ_CONCEPT
Ability to distinguish physical setting (where/when) from atmosphere (mood/tone) and to trace how sensory language constructs the latter.

## PREREQ_BEFORE
Student must have read the full chapter "Hkh'e lkguh" at least once and marked all place-names, time-markers, and sensory adjectives.

## PREREQ_STUCK
If stuck, review Class 11 "Setting and Atmosphere" nodes (c11_hin_ar_cbse_13_003) for the basic identification framework, then practice on a short story like "Usne Kaha Tha" before returning to this longer memoir.

## WORKED_EXAMPLE_1
PROBLEM: Analyze how the author creates a sense of intellectual claustrophobia in the Delhi government office scene during Emergency (pages 96–97) using setting details.
STEPS:
- Step 1: Locate the passage — "mu fnuksa eSa vizQks&,f'k;kbZ ys[kd la?k esa dk;Zdkjh egkea=kh osQ in ij lfozQ; Fkk" to "gekjk okrkZyki ”;knk nwj rd rks tk ugha ldrk Fkk."
- Step 2: List physical setting markers — "dk;Zdkjh egkea=kh osQ in," "if=kdk ^yksVl* dk laikndh; dk;kZy;," "V~;wful esa gh fI+kQfyLrhuh vLFkk;h ljdkj," "cM+h >asi gqbZ."
- Step 3: List sensory/atmospheric words — "lqj{kk dh n`f"V," "vanj fyok ys x,A," "nksuksa dks fnu osQ Hkkstu ij vkeaf=kr," "okrkZyki ”;knk nwj rd rks tk ugha ldrk."
- Step 4: Map each physical marker to its atmospheric effect — government office = institutional power; sealed room = secrecy; surveillance language = fear; truncated conversation = self-censorship.
- Step 5: Synthesize — the setting transforms from a workplace into a trap; the "great hall" (>asi) becomes a pressure chamber where literature and survival negotiate.
REASONING: This step-by-step mapping mirrors the board exam expectation: identify evidence → categorize → explain effect → synthesize. It prevents the common error of quoting lines without analyzing their atmospheric function.
ANSWER: The Delhi office scene uses institutional architecture (minister's office, government press), temporal compression ("oqQNsd"), and surveillance vocabulary ("lqj{kk," "vkeaf=kr") to create an atmosphere where intellectual freedom is physically cornered. The "great hall" (>asi) ironically magnifies the characters' smallness. This claustrophobia is not metaphorical — it is built into the setting.

## WORKED_EXAMPLE_2
PROBLEM: The Lucknow coffee house appears twice — in 1938 (pages 90–91) and in memory during the Emergency (page 96). Compare the two atmospheric renderings and explain what the shift reveals about the narrator.
STEPS:
- Step 1: Extract 1938 descriptors — "jsyxkM+h oèkkZ," "i`Foh¯lg vk"kkn," "gFkdfM+;ksa lesr," "jktsanz ckcw," "ehjk csu," "[kku vCnqy."
- Step 2: Extract 1975 memory descriptors — "yxHkx ehyHkj osQ ?ksjs esa] ckj&ckj viuk ^xk¡x* ctkrk gqvk vkxs c<+rk tkrk," "iznf{k.kk izkFkZuk osQ oDr lekIr gksrh."
- Step 3: Identify continuities — coffee house as intellectual hub, Shrikant Verma's presence, sound of debate.
- Step 4: Identify ruptures — 1938: open, future-oriented, collective; 1975 memory: internal, past-oriented, solitary ("viuk ^xk¡x*").
- Step 5: Link to narrator's arc — 1938 narrator enters as observer; 1975 narrator revisits as survivor. The atmosphere shifts from possibility to elegy.
- Step 6: Formulate answer — The coffee house becomes a palimpsest: its 1938 atmosphere of "gFkdfM+;ksa lesr" (heated debates) is overwritten by 1975's "iznf{k.kk" (recognition/realization) that those debates could not prevent the Emergency.
REASONING: Comparative atmosphere analysis is a high-order skill tested in CBSE competency questions and CUET. The six-step method ensures temporal layering is not collapsed.
ANSWER: The 1938 coffee house breathes with collective argument and youthful idealism ("jktsanz ckcw"); the remembered coffee house in 1975 is a private echo chamber where the narrator hears only his own "xk¡x" (restlessness). The shift from "we debated" to "I remember" marks his transition from participant to witness — the atmosphere preserves the past but the narrator now inhabits it alone.

## WORKED_EXAMPLE_3
PROBLEM: The folk-tale of the crow and mother (pages 94–95) is told in Usgaonkar's Delhi drawing room during a dinner party. Analyze how the immediate setting (drawing room, elite guests, fine dining) interacts with the tale's setting (wilderness, starvation, primal sacrifice) to produce a complex atmosphere.
STEPS:
- Step 1: Describe the frame setting — "fnuHkj rks iafMrth LFkkuh; usrkvksa osQ lkFk txg&txg ?kwers," "cM+s yCèkizfr"B yksx," "usg: th dks u”knhd ls ns[k ikus dk esjs fy, ;g lqugjk ekSdk."
- Step 2: Describe the tale's setting — "isfjl 'kgj," "fxjts osQ cM+s fxjts," "njok”ks can," "flj osQ cy," "rUe;rk."
- Step 3: Identify the juxtaposition — civilized dinner vs. raw survival; intellectual anecdote vs. visceral fable; Urban elite vs. forest margins.
- Step 4: Analyze atmospheric tension — The drawing room's comfort ("lqugjk ekSdk") makes the tale's horror ("ekrk efj;e dh ewfrZ viuh txg ls fgyh gS") more shocking by contrast. The guests' detachment ("nÙkfpr gksdj lqu jgs") mirrors the nation's indifference to Emergency excesses.
- Step 5: Connect to author's technique — Hkh'e lkguh uses the frame setting to ironically heighten the tale's atmosphere; the tale then retroactively darkens the drawing room atmosphere.
- Step 6: Conclude — The complex atmosphere is one of complicit unease: the listeners (and reader) are implicated in the comfort that enables such stories to be mere entertainment.
REASONING: This example models the "setting-within-setting" analysis required for the highest board marks and for JEE-style literary reasoning questions that test layered textual awareness.
ANSWER: The drawing room's polished atmosphere — "lqugjk ekSdk" (rare delight) for the narrator — acts as an ironic frame. The folk-tale's wilderness atmosphere — starvation, maternal sacrifice, primal violence — pierces this comfort. The juxtaposition creates a dual atmosphere: surface civility haunted by submerged brutality. This mirrors the Emergency itself: drawing-room normalcy masking state violence. The author forces the reader to occupy both atmospheres simultaneously.

## COMPETENCY_QUESTION_1
QUESTION: In "Hkh'e lkguh," the author writes: "bl volj ij usg: th dks ftl c¡xys esa Bgjk;k x;k Fkk] og esjs iqQisQjs HkkbZ dk Fkk vkSj HkkbZ osQ vkxzg ij fd eSa iafMr th dh ns[kHkky esa mudk gkFk cVkm¡Q] eSa Hkh ml c¡xys esa igq¡p x;k Fkk." Using this moment, explain how a minor physical setting (a lane/alley — "c¡xys") becomes a site of atmospheric transformation for the narrator. Your answer must reference at least two sensory details and one historical implication.
COMPETENCY: Literary Analysis — Setting as Active Agent
STEPS:
- Step 1: Identify the setting — the narrow lane ("c¡xys") in Varanasi where Usgaonkar lives.
- Step 2: Note the narrator's physical action — "gkFk cVkm¡Q" (peering/intently looking) following Usgaonkar's gaze.
- Step 3: Extract sensory details — "u”knhd" (unfamiliar/strange), "ns[kHkky" (gaze/sight), the lane as a confined visual corridor.
- Step 4: Link to historical implication — Varanasi during Emergency; the lane represents the constricted public sphere where intellectuals are watched.
- Step 5: Explain atmospheric shift — from detached observer ("esjs iqQisQjs HkkbZ") to implicated participant ("eSa Hkh ml c¡xys esa igq¡p x;k").
ANSWER: The lane ("c¡xys") is physically narrow — a sensory corridor limiting vision ("ns[kHkky") — which mirrors the politically narrowed space of Emergency Varanasi. When the narrator follows Usgaonkar's gaze into this lane, the unfamiliarity ("u”knhd") triggers an atmospheric shift: he moves from sympathetic outsider ("iqQisQjs HkkbZ") to someone who "steps into" the constriction ("igq¡p x;k"). The lane thus materializes the Emergency's atmosphere — you cannot remain a bystander; the setting pulls you in. Historically, this mirrors how writers were forced to choose sides.
DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: A CUET-style question: "The atmosphere in 'Hkh'e lkguh' is not created by description alone but by the friction between what a setting promises and what it delivers." Evaluate this statement with reference to ANY TWO settings in the text. Your answer must: (a) name the two settings, (b) state the promise vs. delivery for each, (c) identify the specific textual friction, and (d) conclude what this reveals about the author's view of history.
COMPETENCY: Critical Evaluation — Historical Irony in Setting
STEPS:
- Step 1: Select two settings — e.g., (1) Lucknow University (fnYyh fo'ofo|ky;) and (2) Varanasi during Emergency (V~;wful lnjeqdke).
- Step 2: For Lucknow University — Promise: intellectual freedom, nationalist ferment ("tkfdj gqlSu dkWyst"). Delivery: bureaucratic routine ("tkfdj dk vè;kiu"), the narrator's eventual compromise ("vizQks&,f'k;kbZ ys[kd la?k esa dk;Zdkjh").
- Step 3: For Varanasi — Promise: spiritual/liberated space (ancient city, Shrikant's refuge). Delivery: surveillance state ("lqj{kk dh n`f"V"), sealed rooms, truncated speech.
- Step 4: Identify friction — University: youthful idealism vs. adult accommodation. Varanasi: sacred geography vs. profane power.
- Step 5: Synthesize — The author sees history as the systematic betrayal of spaces by power; atmosphere is the residue of that betrayal.
ANSWER: (a) Settings: Lucknow University (1950s) and Varanasi during Emergency (1975–77). (b) Lucknow University promises intellectual nationalism ("tkfdj gqlSu dkWyst") but delivers bureaucratic assimilation ("dk;Zdkjh egkea=kh"). Varanasi promises spiritual-autonomous refuge but delivers Emergency surveillance ("laiknd egksn; us lqj{kk dh n`f"V"). (c) Friction: In both, the setting's historical/cultural promise is violated by state power — the university by co-option, Varanasi by repression. (d) This reveals the author's view that history in postcolonial India is the story of spaces losing their promised atmospheres; the writer's task is to document that loss through the friction itself.
DIFFICULTY: hard