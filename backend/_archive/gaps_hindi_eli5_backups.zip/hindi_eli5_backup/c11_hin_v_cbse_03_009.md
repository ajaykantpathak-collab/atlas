## DEFINITION
Irony is a literary device where the intended meaning of words or situations differs significantly from their literal or expected meaning, often revealing a contradiction between appearance and reality. Symbolism is the use of concrete objects, characters, or actions to represent abstract ideas, themes, or emotions beyond their literal significance.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student must be able to identify at least three distinct instances of irony (situational, verbal, or dramatic) and two symbols in the text, explain how each operates with textual evidence, and articulate how these devices deepen the memoir's central themes of dignity, education, and gendered labor.

## SCOPE_BOUNDARY
This node covers irony and symbolism exclusively within the memoir "वकील साहब" (Chapter 3, Vitan). It does not cover other literary devices like imagery or metaphor (covered in node c11_hin_v_cbse_03_008), nor does it address irony/symbolism in other chapters or genres.

## WALKTHROUGH
Imagine you're reading a diary where someone writes "What a beautiful day!" during a terrible storm — you'd instantly sense the gap between words and reality. That's irony. Now think of a worn-out pen that represents someone's fight for education — that's symbolism. In "वकील साहब," the lawyer (रक्रक) encourages the narrator to write but also exploits her labor; this contradiction is situational irony. The pen and notebook (इककसव डिकिह) he gifts become symbols of her hard-won voice. Start by listing moments where actions contradict expectations, then trace objects that carry emotional weight beyond their function. The key insight: irony exposes social hypocrisy, while symbols map the narrator's inner journey from silence to self-expression.

## DIAGNOSTIC_QUESTION_1
Define situational irony and give one example from the memoir where the lawyer's actions contradict his professional identity as a legal expert.

## DIAGNOSTIC_ANSWER_1
Situational irony occurs when the outcome of a situation is opposite to what is logically or morally expected. In the memoir, the lawyer (रक्रक) — a professional trained in justice and rights — denies the narrator basic dignity (fair wages, respect, autonomy) while claiming to help her. A wrong answer (e.g., confusing it with verbal irony or giving a generic example like "rain on a wedding day") reveals the student cannot distinguish irony types or anchor the concept in the specific text.

## DIAGNOSTIC_QUESTION_2
Explain in your own words why the pen and notebook (इककसव डिकिह) function as a symbol rather than just a plot object. What abstract idea do they represent?

## DIAGNOSTIC_ANSWER_2
The pen and notebook symbolize the narrator's agency, literacy, and emerging selfhood — they are the tools through which she transforms from a silent worker into a writer who claims her story. A wrong answer (e.g., "they help her write" or "the lawyer gave them to her") shows the student treats them as literal gifts rather than recognizing their layered meaning: freedom, resistance, and the power of narrative. This confusion between literal function and symbolic resonance is the core misconception.

## DIAGNOSTIC_QUESTION_3
Identify one instance of dramatic irony in the text where the reader knows more than a character, and explain how it shapes our judgment of that character.

## DIAGNOSTIC_ANSWER_3
When the lawyer's wife (लकुहय) suspects the narrator of impropriety while the reader knows the narrator's thoughts are focused on survival and her children's education, dramatic irony exposes the wife's prejudice and class blindness. The reader sees the narrator's innocence; the wife sees only suspicion. A wrong answer (e.g., citing situational irony or missing the knowledge gap) indicates the student cannot track perspective differences between narrator, characters, and reader — essential for analyzing dramatic irony.

## DIAGNOSTIC_QUESTION_4
Compare the symbolic weight of the "kitchen" (रसोई) and the "writing desk" (लखने की मेज) in the narrator's life. How do these two spaces represent opposing forces?

## DIAGNOSTIC_ANSWER_4
The kitchen symbolizes enforced domesticity, invisible labor, and the reduction of her identity to "servant" — a space where she is defined by others' needs. The writing desk (or the act of writing anywhere) symbolizes intellectual freedom, self-definition, and resistance. Their opposition maps the central conflict: body vs. voice, service vs. creation. A wrong answer that treats both as mere physical locations misses the thematic architecture — the student hasn't learned to read spaces as symbolic landscapes.

## DIAGNOSTIC_QUESTION_5
Evaluate the author's use of verbal irony when the narrator says "मैं बहुत खुश हूँ" (I am very happy) in contexts where she is clearly exploited. Does this strengthen or weaken the memoir's critique? Justify.

## DIAGNOSTIC_ANSWER_5
The verbal irony strengthens the critique by exposing the performance of gratitude forced upon marginalized workers — the gap between spoken words and lived reality makes the exploitation more visceral. It forces the reader to hear the silence beneath the words. A wrong answer (e.g., "it shows she is actually happy" or "it's just politeness") reveals the student reads literally and misses how irony functions as social commentary. This is the difference between comprehension and critical analysis.

## DIAGNOSTIC_QUESTION_6
Create a new symbolic object that could represent the narrator's relationship with her children, and explain how it would function in the narrative. (Open-ended; 3-4 sentences.)

## DIAGNOSTIC_ANSWER_6
A strong answer might propose: "A shared tiffin box passed between them — dented, worn, but always filled. It symbolizes their bond sustained through separation, the mother's labor made tangible, and the hope she packs daily." A poor answer (e.g., "a photo of her children") treats the object as illustration rather than symbol — it doesn't carry thematic weight or narrative function. This tests whether the student understands symbolism as an active meaning-making device, not decoration.

## COMMON_MISCONCEPTION
Students often confuse *symbolism* with *imagery* — they identify descriptive details (e.g., "the kitchen was smoky") as symbols because they are vivid. But imagery appeals to senses; symbolism carries *abstract meaning*. In this text, the "smoky kitchen" is imagery; the kitchen *as a space that traps her identity* is symbolism. Students also mistake *coincidence* for *irony* — e.g., "the lawyer gave her a pen but didn't pay her fairly" is not irony unless the student articulates the *structural contradiction*: a guardian of law violating labor ethics. The error stems from hunting for "literary terms" rather than analyzing *how meaning is constructed through contradiction and representation*.

## ON_FAILURE
1. **Re-teach the distinction**: Use a two-column table — Column A: Literal/Imagery ("The pen writes"), Column B: Symbolic/Ironic ("The pen = her voice the world tried to silence"). Practice with 3 text objects. 2. **Model irony detection**: Walk through the "lawyer as rights-expert vs. rights-violator" paradox step-by-step: (a) State expected role, (b) State actual behavior, (c) Name the gap, (d) Link to theme. 3. **Anchor in theme**: Every device must answer "So what?" — e.g., "This irony reveals how education without empathy reproduces oppression." 4. **Assign micro-task**: Find one new irony and one new symbol in the next 5 pages; explain both in 2 sentences each using the template.

## BUILDS_ON
c11_hin_v_cbse_03_008 (Literary Devices: Imagery and Metaphor) — students must already distinguish sensory description from figurative meaning before tackling irony/symbolism's structural and representational complexity.

## LEADS_TO
c11_hin_v_cbse_03_013 (Critical Thinking: Analysis and Interpretation) — irony and symbolism are the primary lenses for the chapter's deeper thematic critique in the critical thinking node.

## PREREQUISITE_NODE_IDS
c11_hin_v_cbse_03_001, c11_hin_v_cbse_03_002, c11_hin_v_cbse_03_004, c11_hin_v_cbse_03_008, c11_hin_v_cbse_03_007

## PREREQUISITE_REASONS
c11_hin_v_cbse_03_001: Context/background establishes the memoir's socio-historical frame (gender, class, labor) essential for decoding irony's social critique.
c11_hin_v_cbse_03_002: Plot/narrative structure provides the sequence of events where ironic contradictions unfold (e.g., lawyer's shifting behavior across time).
c11_hin_v_cbse_03_008: Imagery/Metaphor node teaches figurative vs. literal reading — the direct scaffold for symbolism's representational logic.
c11_hin_v_cbse_03_007: Irony (e.g., employer teaching her to write while denying her dignity) and symbolism (the *fp_h* as both weapon and witness) deepen thematic analysis.  
c11_hin_v_cbse_03_004: Character analysis of the protagonist involves examining the narrator's personality, motiv... की समझ आवश्यक है, क्योंकि यह नोड (Irony is a literary device where the intended meaning of words or situations differs signi...) इसी आधार पर आगे बढ़ता है।  
## FORWARD_NODE_IDS
c11_hin_v_cbse_03_012, c11_hin_v_cbse_03_013, c11_hin_v_cbse_03_014, c12_hin_a_cbse_05_009, c12_hin_a_cbse_10_009, c12_hin_al_cbse_01_009, c12_hin_ar_cbse_09_009, c12_hin_v_cbse_03_009

## FORWARD_REASONS
c11_hin_v_cbse_03_012: Comprehension questions require identifying and explaining irony/symbolism as textual evidence for inferential answers.
c11_hin_v_cbse_03_013: Critical thinking demands analyzing how these devices construct the memoir's argument about dignity and voice.
c11_hin_v_cbse_03_014: Writing skills (analytical paragraphs, essays) require using irony/symbolism as analytical tools with textual citations.
c12_hin_a_cbse_05_009: अगला तार्किक चरण: Irony is a literary device where the intended meaning of words or a situation is opposite to their l... इस नोड की अवधारणाओं को सीधे उपयोग/विस्तारित करता है।  
c12_hin_a_cbse_10_009: Vitan Chapter 3 analyzed dramatic irony in interviews — narrator-subject dynamic.  
c12_hin_al_cbse_01_009: Class 11 Vitan Chapter 3 Irony and Symbolism node broadens genre exposure.  
c12_hin_ar_cbse_09_009: अगला तार्किक चरण: Irony is a literary device where the intended meaning of words or events contrasts sharply with thei... इस नोड की अवधारणाओं को सीधे उपयोग/विस्तारित करता है।  
c12_hin_v_cbse_03_009: Class 11 introduced basic definitions of irony and symbolism; this node deepens them with a specific complex text.  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
none

## CHAIN_DESCRIPTION
c11_hin_v_cbse_03_001 -> c11_hin_v_cbse_03_009 -> c11_hin_v_cbse_03_013: Context grounds the social irony; irony/symbolism analysis enables critical interpretation of the memoir's feminist and class critique.

## THIS_FORMULA
N/A - conceptual

## FORMULA_VARIABLES
N/A

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
analytical

## CROSS_SUBJECT
c11_history_03 | The memoir's depiction of domestic labor in postcolonial India connects to History's study of gendered work and caste-class intersections in modern Indian social history (e.g., Chapter on "Women, Caste and Reform" or "The Making of a Nation").
c11_sociology_02 | Sociology's concepts of "invisible labor," "symbolic violence" (Bourdieu), and "resistance through everyday practices" directly illuminate the irony of the lawyer's exploitation and the symbolism of writing as counter-hegemonic act.

## PREREQ_CONCEPT
The ability to distinguish literal description from figurative meaning (from Imagery/Metaphor node) and knowledge of the narrator's trajectory from the Character Analysis node.

## PREREQ_BEFORE
Student must know: (1) the narrator's basic biography (illiterate domestic worker → writer), (2) the lawyer's dual role as employer and mentor, (3) the difference between a metaphor (direct comparison) and a symbol (object carrying sustained abstract meaning).

## PREREQ_STUCK
If stuck, return to c11_hin_v_cbse_03_008 and practice: "List 3 metaphors in the text. Now ask: does this comparison *stand for* a larger idea across the whole memoir? If yes, it's a symbol."

## WORKED_EXAMPLE_1
PROBLEM: Analyze the situational irony in the lawyer (रक्रक) gifting the narrator a pen and notebook (इककसव डिकिह) while simultaneously denying her fair wages and autonomy. Use the 4-step PEEL structure.

STEPS:
- Step 1: Identify the contradiction — The lawyer is a legal professional sworn to uphold justice/rights, yet he exploits the narrator's labor (no fixed salary, excessive hours, emotional manipulation) while framing his "gift" as benevolence.
- Step 2: Locate textual evidence — The narrator notes: "रक्रक ने कहा... मैं तुम्हें एक फाउंटेन पेन और डायरी दे रहा हूँ... तुम्हारी कहानी लिखने के लिए" (Lawyer says: I'm giving you a fountain pen and diary to write your story) — but earlier she records: "मुझे न तो तनख्वाह मिलती न छुट्टी" (I got neither salary nor leave).
- Step 3: Explain the irony's function — The gift of writing tools (meant to empower) coexists with material exploitation (which disempowers). This gap exposes how "enlightened" employers can reproduce oppression through performative kindness.
- Step 4: Link to theme — This irony deepens the memoir's critique of paternalism: the lawyer controls the *terms* of her literacy (what she writes, when, for whom), making her voice an extension of his patronage, not true autonomy.
- Step 5: Conclude with significance — The situational irony reveals that legal knowledge ≠ moral integrity, and that tools of liberation can become instruments of control when power dynamics remain unchanged.

REASONING: This example models the PEEL method (Point, Evidence, Explanation, Link) required for board answers. It forces the student to move beyond "this is ironic" to "this irony *does* specific thematic work."

ANSWER: The lawyer's gift of writing materials is situational irony because his professional identity (upholder of rights) contradicts his actions (denial of labor rights). The pen/diary symbolize voice, but their giver controls the conditions of that voice. This irony exposes paternalistic exploitation masked as mentorship — a central theme of the memoir.

## WORKED_EXAMPLE_2
PROBLEM: Trace the evolution of the "kitchen" (रसोई) as a symbol across three phases of the narrator's stay in the lawyer's house. Explain how its symbolic meaning shifts.

STEPS:
- Step 1: Phase 1 (Arrival) — The kitchen is a site of *alienated labor*: "रसोई में धुआँ... मुझे खाँसी आती" (Smoke in kitchen... I coughed). It symbolizes her reduced identity — body as instrument, no self.
- Step 2: Phase 2 (During writing) — The kitchen becomes a *contested space*: She writes *in* the kitchen ("रसोई में बैठकर लिखती"), stealing moments between chores. The kitchen now holds both oppression and resistance — the pen intrudes on the ladle's territory.
- Step 3: Phase 3 (Departure) — The kitchen transforms into a *memory of triumph*: "मैंने रसोई को जीत लिया" (I conquered the kitchen) — not by owning it, but by refusing to let it define her. The symbol completes its arc: from cage to battlefield to conquered terrain.
- Step 4: Synthesize — The kitchen's shifting symbolism maps the narrator's journey from object to subject. It is not a static symbol; its meaning changes *because she changes*.
- Step 5: Connect to broader symbolism — Contrast with the "pen" (constant symbol of voice). The kitchen is dynamic; the pen is aspirational. Together they frame the dialectic of place vs. possibility.

REASONING: This example teaches *symbolic tracking* — a higher-order skill where students trace how a symbol's meaning evolves with character development, not just identify it once. It mirrors board questions on "development of a symbol."

ANSWER: The kitchen begins as a symbol of entrapment (smoke, cough, invisible labor), becomes a site of resistance (writing amidst chores), and ends as a symbol of conquered limitation. Its evolution mirrors the narrator's shift from passive worker to active author of her life.

## WORKED_EXAMPLE_3
PROBLEM: The narrator describes the lawyer's wife (लकुहय) as "संदेह की मूर्ति" (embodiment of suspicion). Analyze how *dramatic irony* operates in the wife's suspicion of the narrator's character, and how this irony serves the memoir's gender critique.

STEPS:
- Step 1: Establish the knowledge gap — The reader accesses the narrator's interiority: her devotion to children, her hunger for education, her moral clarity. The wife sees only: a young woman in her husband's house, receiving gifts (pen, diary), sharing meals.
- Step 2: Identify the irony type — Dramatic irony: Reader knows narrator's innocence; wife *does not*. The wife's suspicion is based on class/gender prejudice, not evidence.
- Step 3: Find textual anchors — Wife's actions: "लकुहय ने पूछा... तुम यहाँ क्या करती हो?" (Wife asked: What do you do here?), "लकुहय को शक था" (Wife suspected), vs. Narrator's thoughts: "मेरे बच्चे... उनकी पढ़ाई" (My children... their education).
- Step 4: Analyze the irony's gender critique — The wife, a woman of privilege, polices another woman's morality instead of recognizing shared patriarchal oppression. The irony *exposes* how class divides women: the wife becomes an agent of the same system that marginalizes her.
- Step 5: Link to symbolism — The "pen" the lawyer gives becomes a flashpoint: the wife sees it as proof of intimacy; the narrator sees it as tool of freedom. The object's *dual symbolic reading* by two women crystallizes the class divide.
- Step 6: Conclude — The dramatic irony doesn't just create tension; it indicts the wife's complicity. The memoir uses irony to show that oppression is not only top-down (lawyer→narrator) but horizontal (wife→narrator).

REASONING: This is the hardest worked example because it combines dramatic irony, gender theory, and symbolic polysemy (one object, two readings). It prepares students for competency questions asking for "multi-layered analysis of literary devices in service of social critique."

ANSWER: Dramatic irony arises because the reader knows the narrator's pure motives (children, education) while the wife projects sexual suspicion onto the pen/diary gift. This irony critiques how class privilege blinds women to shared gender oppression — the wife becomes the patriarch's proxy, reading the symbol of freedom (pen) as evidence of immorality. The device transforms a personal conflict into a structural commentary.

## COMPETENCY_QUESTION_1
QUESTION: In the memoir, the narrator writes: "रक्रक ने मुझे लिखना सिखाया, लेकिन मेरी मजदूरी नहीं दी" (The lawyer taught me to write, but didn't pay my wages). A student claims this is *verbal irony* because the narrator says one thing but means another. Is the student correct? Explain why or why not, using the definitions of verbal and situational irony.

COMPETENCY: Conceptual discrimination — distinguishing irony types and applying definitions to textual evidence.

STEPS:
- Step 1: Recall definition of verbal irony — Speaker says X but means Y (e.g., "Great job!" after a mistake). Requires *intentional* double meaning by the speaker.
- Step 2: Recall definition of situational irony — Outcome contradicts reasonable expectation based on role/context (e.g., fire station burns down). No speaker intent required.
- Step 3: Analyze the quoted sentence — The narrator is *reporting a fact*, not speaking ironically. She states two facts: (a) he taught writing, (b) he didn't pay. The *irony lies in the situation* (lawyer/mentor exploiting labor), not in her words.
- Step 4: Conclude — The student is incorrect. This is situational irony (role vs. behavior), not verbal irony (words vs. intent). The narrator's tone is direct, not sarcastic.

ANSWER: The student is wrong. Verbal irony requires the *speaker* to intend a meaning opposite to their words (e.g., sarcasm). Here, the narrator states facts plainly. The irony is *situational*: a lawyer (expected to uphold rights) violates labor rights while mentoring. The contradiction is in the *situation*, not the utterance.

DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: The "tiffin box" (टिफिन बॉक्स) the narrator carries to work appears in three key scenes: (1) packing it for her children before leaving, (2) the lawyer's wife commenting on its contents, (3) the narrator eating from it alone in the kitchen. Argue whether the tiffin box functions as a *symbol* in the memoir. If yes, what does it symbolize, and how does its meaning shift across the three scenes? If no, explain why it remains a mere plot object.

COMPETENCY: Symbolic tracking and thematic synthesis — evaluating an object's representational consistency and evolution across narrative moments.

STEPS:
- Step 1: Test symbolic criteria — Does the tiffin box carry abstract meaning beyond its literal function (carrying food)? Is that meaning sustained and developed?
- Step 2: Analyze Scene 1 — Packing it: "बच्चों के लिए रोटी-सब्जी... मेरी गैरहाजिरी में उनका पेट भरे" (Roti-sabzi for children... fill their stomachs in my absence). Here it symbolizes *maternal love made tangible* — her labor converted into care across distance.
- Step 3: Analyze Scene 2 — Wife's comment: "लकुहय ने टिफिन देखा... 'अच्छा खाना खाती हो'" (Wife saw tiffin... 'You eat well'). The wife reads it as *evidence of privilege* (class blindness). The object's meaning fractures: for narrator = love; for wife = entitlement.
- Step 4: Analyze Scene 3 — Eating alone: "रसोई में अकेली टिफिन खोलकर खाती" (Eating alone in kitchen opening tiffin). Now it symbolizes *isolation and self-sustenance* — she feeds herself what she packed for others. The circle completes: maternal labor → class misreading → solitary survival.
- Step 5: Synthesize — Yes, it is a symbol. It represents the *circulation of care under exploitation*: the narrator's labor feeds others (children, employer's family) while her own nourishment is marginal. Its shifting reading across scenes maps the memoir's core tension: love vs. labor, visibility vs. erasure.

ANSWER: Yes, the tiffin box is a symbol. It represents maternal labor and care under conditions of exploitation. Scene 1: Symbol of love across separation. Scene 2: Site of class misrecognition (wife sees privilege, not sacrifice). Scene 3: Emblem of solitary self-care — the carer feeding herself last. Its evolving meaning traces the narrator's journey from giving to claiming her own sustenance.

DIFFICULTY: hard