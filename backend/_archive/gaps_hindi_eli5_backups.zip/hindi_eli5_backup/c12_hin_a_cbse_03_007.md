## DEFINITION
Secondary themes are the subsidiary ideas, motifs, or concerns that run parallel to the primary theme in a literary work, enriching the text by adding layers of meaning, highlighting specific aspects of the human condition, or providing social, psychological, or philosophical commentary that supports or contrasts with the central message.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student can independently identify at least two secondary themes in Varjk's poems "नहीं वोस्यक" and "मैंने देखा, एक चाँद", trace each theme through specific stanzas/lines, and explain how they deepen the primary theme of human dignity and beauty in the ordinary.

## SCOPE_BOUNDARY
This node covers identification and analysis of secondary themes (individuality vs society, beauty in mundane objects, voice to the marginalized, transformative perception) in the two prescribed poems of Chapter 3. It does NOT cover primary theme analysis (node 006), literary devices (nodes 008-009), or comprehensive chapter summary.

## WALKTHROUGH
Imagine you're scrolling through social media and see a photo of a simple home-cooked meal — a plain roti on a plate — captioned "Moonlight on my dinner table." Suddenly, that ordinary roti looks poetic, almost sacred. That shift in perception is exactly what Varjk does in "मैंने देखा, एक चाँद": he takes a quotidian object and reveals its hidden dignity. In "नहीं वोस्यक", he does the same for a "small" person. To find secondary themes, start by asking: "What else is the poet saying besides the main message?" Look for recurring images (charkha, roti, marginalized figures), contrasts (small vs large, kitchen vs sky), and the emotional tone shifts. The key insight: secondary themes are not hidden; they are woven into the same lines that carry the primary theme — you just need to change your lens.

## DIAGNOSTIC_QUESTION_1
In Varjk's poem "नहीं वोस्यक", the line "यह तू है अक्रक चरखा जिसे फिर भी कोई और नहीं चलाता" primarily supports which secondary theme?

## DIAGNOSTIC_ANSWER_1
Correct answer: Individual autonomy and self-reliance (व्यक्तिगत स्वायत्तता और आत्मनिर्भरता). The metaphor of the "charkha that no one else turns" signifies that the individual, however small, controls their own destiny. A wrong answer like "industrial progress" reveals the student is reading the charkha as a historical symbol (Gandhi's spinning wheel) rather than a metaphor for personal agency in the poem's context.

## DIAGNOSTIC_QUESTION_2
Explain in your own words how the secondary theme of "beauty in the mundane" operates differently in the two poems: "नहीं वोस्यक" and "मैंने देखा, एक चाँद".

## DIAGNOSTIC_ANSWER_2
Correct answer: In "नहीं वोस्यक", beauty in the mundane is argued intellectually — the poet asserts that small things/people have intrinsic worth and demands society recognize it. In "मैंने देखा, एक चाँद", it is experienced sensorially — the poet *sees* a roti transform into a moon through heat/light, making the reader feel the wonder. A wrong answer that treats both as identical "descriptions of poor people's lives" misses the epistemic difference: one is a rhetorical demand, the other a perceptual revelation.

## DIAGNOSTIC_QUESTION_3
Apply the concept of "voice to the voiceless" to the last stanza of "नहीं वोस्यक" ("यह वह फोकल है... इसे भी खफा को दो"). Identify three specific marginalized figures named and explain what "giving them a place in literature" (साहित्य में जगह देना) concretely means in this context.

## DIAGNOSTIC_ANSWER_3
Correct answer: The stanza names: (1) लिंक-नज़फोर (the chained/unfree), (2) फपज-त्क्षद (the broken/fragmented), (3) वुक्जड-उस=क (the displaced/uprooted). "Giving them a place in literature" means making their lived reality the subject of poetry — not as objects of pity but as autonomous voices. A wrong answer listing generic "poor people" shows the student hasn't engaged with the poem's specific vocabulary of oppression (नज़फोर, त्क्षद, उस=क) which are precise sociological categories Varjk chooses.

## DIAGNOSTIC_QUESTION_4
Compare the role of "transformation" in both poems. In "नहीं वोस्यक", what transforms? In "मैंने देखा, एक चाँद", what transforms? How does this difference reflect the two poems' distinct approaches to dignity?

## DIAGNOSTIC_ANSWER_4
Correct answer: In "नहीं वोस्यक", *perception* transforms — society's view of the "small" person must change (intellectual transformation). In "मैंने देखा, एक चाँद", the *object itself* appears to transform — the roti becomes a moon through the poet's gaze (perceptual transformation). The first demands external justice; the second enacts internal revelation. A wrong answer saying "both show poor things becoming beautiful" conflates social advocacy with poetic epiphany, missing that Varjk uses two different mechanisms: argument vs vision.

## DIAGNOSTIC_QUESTION_5
Evaluate this student interpretation: "The secondary theme of 'मैंने देखा, एक चाँद' is hunger because the roti represents food scarcity." Is this a valid secondary theme? Justify using textual evidence.

## DIAGNOSTIC_ANSWER_5
Correct answer: No, it is not a valid secondary theme. The poem focuses on *aesthetic revelation* ("उ'ोजर्क के नक्स से" — from the edge of wonder) and the *dignity of labor* ("थौ-दकेसुक का वेअर-इवर इ;र" — the veined leaf of life-struggle). Hunger/scarcity is the socio-economic context, not the theme. The poet explicitly says the roti's color changes "from the heat of the tawa" (<yrs lwjt dh vkx ls), emphasizing creation/craft, not lack. A student who answers "yes" is imposing an external social issue onto a poem that deliberately transcends it through beauty.

## DIAGNOSTIC_QUESTION_6
Write a 4-line stanza in Varjk's style that introduces a new secondary theme: "the dignity of invisible labor" (e.g., a sanitation worker, a night watchman, a mother's unseen care). Use one metaphor and one direct address to society.

## DIAGNOSTIC_ANSWER_6
Expected answer criteria: (1) Names a specific invisible worker, (2) Uses a metaphor elevating their labor (e.g., "आप शहर की शिराओं में बहता सफाई का खून हैं"), (3) Directly addresses society ("सुनो नागरिको"), (4) Maintains Varjk's rhythmic, declarative tone. A poor answer would be a generic description without metaphor or address, showing the student hasn't internalized Varjk's technique of combining concrete imagery with rhetorical demand.

## COMMON_MISCONCEPTION
Students often confuse "secondary theme" with "subplot" or "minor topic mentioned once." They list things like "charkha," "roti," "kitchen," "night" as themes because these words appear in the text. Themes are *ideas* (e.g., "autonomy," "perceptual transformation"), not nouns. This error occurs because Class 10-11 teaching often asks "list the themes" and accepts word-level answers. In Class 12 board/competitive exams, a theme must be expressible as a complete proposition: "The poem argues that X" or "The poem reveals Y about Z."

## ON_FAILURE
If the student lists nouns instead of thematic statements: (1) Have them re-read the last stanza of "नहीं वोस्यक" and complete the sentence: "The poet is not just describing a charkha; he is arguing that ________." (2) Give them the formula: Theme = Subject + Poet's Stance (e.g., Subject: small person; Stance: has equal claim to dignity → Theme: Intrinsic dignity regardless of social scale). (3) Practice converting 5 nouns from the poem into thematic statements. (4) Re-attempt Diagnostic Question 2.

## BUILDS_ON
Primary theme identification (c12_hin_a_cbse_03_006) — you cannot distinguish secondary from primary without first establishing the central message.

## LEADS_TO
Literary Devices: Imagery and Metaphor (c12_hin_a_cbse_03_008) — secondary themes are often carried by specific image clusters and metaphors that this node will analyze technically.

## PREREQUISITE_NODE_IDS
c12_hin_a_cbse_03_006, c11_hin_ar_cbse_01_007, c11_hin_ar_cbse_03_007
## PREREQUISITE_REASONS
c12_hin_a_cbse_03_006: Primary theme must be established first to differentiate secondary themes. c11_hin_ar_cbse_01_007: Class 11 foundation on secondary theme identification in poetry (Aroh Chapter 1). c11_hin_ar_cbse_03_007: Class 11 practice with Varjk's style in Aroh Chapter 3 (if covered) or similar modernist poets.
c11_hin_ar_cbse_01_007: Secondary themes are the subordinate thematic threads that run parallel to the primary the... की समझ आवश्यक है, क्योंकि यह नोड (Secondary themes are the subsidiary ideas, motifs, or concerns that run parallel to the pr...) इसी आधार पर आगे बढ़ता है।  
c11_hin_ar_cbse_03_007: Secondary themes (गौण विषय) are the underlying ideas, motifs, or concerns that run paralle... की समझ आवश्यक है, क्योंकि यह नोड (Secondary themes are the subsidiary ideas, motifs, or concerns that run parallel to the pr...) इसी आधार पर आगे बढ़ता है।  

## FORWARD_NODE_IDS
c12_hin_a_cbse_03_008, c12_hin_a_cbse_03_013, c12_hin_a_cbse_03_012, c12_hin_a_cbse_03_014

## FORWARD_REASONS
c12_hin_a_cbse_03_008: Secondary themes are realized through imagery/metaphor — next node analyzes those vehicles. c12_hin_a_cbse_03_013: Critical thinking requires synthesizing primary + secondary themes for interpretation.
c12_hin_a_cbse_03_012: Secondary themes add inferential layers  
c12_hin_a_cbse_03_014: Secondary themes provide alternative "Points" for multi-theme questions.  
c12_hin_a_cbse_03_013: अगला तार्किक चरण: Critical thinking in literary analysis is the disciplined process of examining a text beyond its lit... इस नोड की अवधारणाओं को सीधे उपयोग/विस्तारित करता है।  

## CROSS_SUBJECT_PREREQS
c11_hin_ar_cbse_01_007, c11_hin_ar_cbse_03_007
## CROSS_SUBJECT_REASONS
c11_hin_ar_cbse_01_007: Builds on Class 11 secondary theme analysis in Aroh. c11_hin_ar_cbse_03_007: Reinforces pattern recognition across chapters/poets in Class 11.
c11_hin_ar_cbse_03_007: अन्य विषय की सहायता: Secondary themes (गौण विषय) are the underlying ideas, motifs, or concerns that run paralle... के तत्व इस नोड में प्रयुक्त होते हैं।  

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_01_007 -> c12_hin_a_cbse_03_006 -> c12_hin_a_cbse_03_007 -> c12_hin_a_cbse_03_008

## THIS_FORMULA
Theme Statement = Concrete Subject (from text) + Abstract Insight (poet's perspective) + Scope Modifier (universal/particular, intellectual/sensory)

## FORMULA_VARIABLES
Concrete Subject: Specific image/character/situation in poem (e.g., "charkha", "roti", "म्हायक-च्क्ग्क"). Abstract Insight: The poet's philosophical/emotional claim about that subject (e.g., "controls own destiny", "reveals cosmic beauty"). Scope Modifier: Whether the claim is demanded of society (universal) or experienced by speaker (particular), argued intellectually or felt sensorially.

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
analytical

## CROSS_SUBJECT
N/A | The poem "नहीं वोस्यक" mirrors sociological concepts of marginalization and voice — the "लिंक-नज़फोर, फपज-त्क्षद, वुक्जड-उस=क" map directly to categories of structural exclusion (caste, class, displacement) studied in Social Change and Social Problems.
 N/A | "मैंने देखा, एक चाँद" exemplifies top-down processing in perception: the poet's cognitive framework (seeing beauty in labor) transforms sensory input (roti) into a moon — a classic case of perceptual set influencing interpretation.
## PREREQ_CONCEPT
Ability to distinguish a text's central argument (primary theme) from its supporting or parallel concerns (secondary themes) using textual evidence.

## PREREQ_BEFORE
Student must have completed analysis of primary theme in Varjk's poems (node 006) and practiced secondary theme identification in Class 11 (Aroh/Vitan).

## PREREQ_STUCK
If stuck, review Class 11 Aroh Chapter 1 "नमक का दारोगा" or Chapter 3 "मीरा के पद" secondary theme exercises (node c11_hin_ar_cbse_01_007 / c11_hin_ar_cbse_03_007) to refresh the method.

## WORKED_EXAMPLE_1
PROBLEM: Identify and analyze the secondary theme of "intellectual vs sensory validation of dignity" in the two poems.

STEPS:
- Step 1: Locate the primary theme in both poems — human dignity of the ordinary/marginalized (established in node 006).
- Step 2: In "नहीं वोस्यक", find lines where dignity is *argued*: "नहीं वोस्यक लुसग हक है...", "यह तू है अक्रक चरखा..." — these are logical assertions addressing society ("इसे भी खफा को दो").
- Step 3: In "मैंने देखा, एक चाँद", find lines where dignity is *perceived*: "जाक्स न्हकु...", "उ'ोजर्क के नक्स से" — the speaker's vision transforms the roti; no argument is made to an audience.
- Step 4: Contrast the mechanisms: Poem 1 uses rhetoric (imperatives: "दो", "है") demanding external recognition; Poem 2 uses epiphany (declaratives: "देखा", "गए") enacting internal revelation.
- Step 5: Synthesize: The secondary theme is the *mode of validation* — Varjk shows dignity can be claimed intellectually (poem 1) or discovered sensorially (poem 2), both resisting reduction of the ordinary to insignificance.

REASONING: This works because it moves from the known (primary theme) to the new (secondary theme) by comparing the *how* across texts, using grammatical mood (imperative vs declarative) as evidence.

ANSWER: The secondary theme is "dual pathways to dignity: social demand vs perceptual gift." In "नहीं वोस्यक", dignity is a right demanded from society through rhetorical force. In "मैंने देखा, एक चाँद", dignity is a truth revealed to the observer through aesthetic attention. Both reject the equation small=insignificant, but one fights for it, the other finds it.

## WORKED_EXAMPLE_2
PROBLEM: Trace the secondary theme of "the body as site of labor and beauty" through specific images in both poems.

STEPS:
- Step 1: List body-related images in "नहीं वोस्यक": "अक्रक चरखा" (body as self-driven machine), "हाथ" (implied in "कोई और नहीं चलाता"), "फोकल" (throat/voice of the marginalized).
- Step 2: List body-related images in "मैंने देखा, एक चाँद": "वेअर-इवर इ;र" (veined leaf — body as organic map), "एकसुक" (sweat/heat of labor), "थौ-दकेसुक" (life-struggle embodied).
- Step 3: Analyze the connection: In both, the body is not a passive vessel but an active producer — the charkha *spins*, the roti *bears veins of labor*.
- Step 4: Note the difference: Poem 1 focuses on *agency* (body as autonomous actor), Poem 2 on *inscription* (body as record of work).
- Step 5: Formulate theme: "The laboring body as autonomous creator and beautiful text." This secondary theme elevates physical work from drudgery to artistry.

REASONING: By cataloguing body-images across poems, we avoid cherry-picking and see Varjk's consistent somatic focus — a hallmark of his modernist humanism.

ANSWER: Secondary theme: "The laboring body as site of autonomy and aesthetic inscription." In "नहीं वोस्यक", the body (charkha) asserts "no one else turns me" — autonomy. In "मैंने देखा, एक चाँद", the roti's "veined leaf" and "heat-born color" inscribe labor as beauty. Together, they reframe the marginalized body not as victim but as maker.

## WORKED_EXAMPLE_3
PROBLEM: A board exam question asks: "How do the secondary themes in Varjk's poems expand the concept of 'साहित्य में जगह' (place in literature) beyond mere representation?" Answer in 80-100 words with textual evidence.

STEPS:
- Step 1: Deconstruct the question: It asks for the *function* of secondary themes in expanding the primary demand ("place in literature").
- Step 2: Recall primary demand: "इसे भी खफा को दो" — give the marginalized a place in literature.
- Step 3: Identify how each secondary theme deepens this: (a) Autonomy theme: "Place" means not just depiction but *voice* — the charkha speaks for itself. (b) Perceptual beauty theme: "Place" means *aesthetic equivalence* — the roti equals the moon, not a pity-object. (c) Labor-as-text theme: "Place" means *epistemic authority* — the worker's body writes its own poetry ("वेअर-इवर इ;र").
- Step 4: Synthesize: Secondary themes shift "place in literature" from token inclusion to three radical acts: self-representation, aesthetic parity, epistemic sovereignty.
- Step 5: Draft answer using PEEL structure: Point (secondary themes redefine literary place), Evidence (quote "अक्रक चरखा", "उ'ोजर्क के नक्स से", "वेअर-इवर इ;र"), Explanation (each quote shows a dimension), Link (thus Varjk demands literature as justice, not charity).

REASONING: This models the exact board exam skill: using secondary themes to deepen a primary theme claim, with mandatory textual evidence and structured argument.

ANSWER: Varjk's secondary themes transform "place in literature" from representation to reclamation. The autonomy theme ("अक्रक चरखा जिसे फिर भी कोई और नहीं चलाता") makes literary space a site of self-determination, not portrayal. The perceptual beauty theme ("उ'ोजर्क के नक्स से" the roti becomes moon) demands aesthetic parity — the ordinary equals the cosmic. The labor-as-text theme ("थौ-दकेसुक का वेअर-इवर इ;र") grants the worker's body epistemic authority to write its own truth. Thus, "place" means literature as a tribunal of justice where the marginalized speak, shine, and theorize themselves.

## COMPETENCY_QUESTION_1
QUESTION: "Varjk's two poems present two different theories of how the marginalized gain dignity: one through social contract, one through aesthetic revelation." Evaluate this statement by analyzing one secondary theme from each poem that supports or challenges it.

COMPETENCY: Critical Analysis & Comparative Reasoning
STEPS:
- Step 1: Identify the two theories implied: social contract (society grants rights) vs aesthetic revelation (perception creates value).
- Step 2: From "नहीं वोस्यक", select secondary theme of *voice/agency* ("अक्रक चरखा") — supports social contract? Actually challenges it: the charkha *already* runs itself; society just needs to acknowledge ("दो"), not grant.
- Step 3: From "मैंने देखा, एक चाँद", select secondary theme of *perceptual transformation* ("उ'ोजर्क के नक्स से") — supports aesthetic revelation: dignity appears when seen rightly.
- Step 4: Synthesize: Both poems ultimately reject social contract as *source* of dignity; dignity is inherent. Poem 1 demands recognition of pre-existing autonomy; Poem 2 enacts revelation of pre-existing beauty.
- Step 5: Conclude: The statement is partially wrong — neither poem says society *confers* dignity via contract.

ANSWER: The statement misreads both poems. In "नहीं वोस्यक", the secondary theme of autonomy ("अक्रक चरखा") shows dignity is *inherent* — the marginalized already spin their own lives; literature/society must only *recognize* ("इसे भी खफा को दो"), not grant. In "मैंने देखा, एक चाँद", the secondary theme of perceptual revelation ("उ'ोजर्क के नक्स से") shows dignity is *discovered* through attentive seeing, not conferred. Both poems locate dignity in the subject (charkha, roti), not in society's contract. Varjk's dual strategy: demand recognition (poem 1) and model revelation (poem 2).
DIFFICULTY: hard

## COMPETENCY_QUESTION_2
QUESTION: Design a lesson plan activity for Class 10 students to discover secondary themes in "मैंने देखा, एक चाँด" without using the term "secondary theme." The activity must use the poem's sensory imagery and lead students to articulate the theme of "beauty as resistance to utilitarianism."

COMPETENCY: Pedagogical Content Knowledge & Creative Application
STEPS:
- Step 1: Hook — Show two images: a roti on a tawa (utilitarian) and a full moon (aesthetic). Ask: "Can the first become the second? How?"
- Step 2: Read poem aloud. Students mark every sensory word (जाक्स, न्हकु, एकसुक, एकसपु, उ'ोजर्क, नक्स).
- Step 3: In pairs, students answer: "What does the poet *do* to the roti with his gaze?" (Answer: He doesn't change the roti; he changes *how it appears*.)
- Step 4: Introduce "utilitarianism" simply: "Seeing things only for use." Ask: "How is the poet's gaze anti-utilitarian?" (He sees beauty where use-value dominates.)
- Step 5: Students write one sentence: "This poem says beauty is ________." Collect and discuss — guide toward "resistance," "rebellion," "a way of knowing."
- Step 6: Reveal: "You just found a secondary theme without naming it."

ANSWER: Activity: "The Alchemy of Attention." 1. Visual hook: roti vs moon. 2. Sensory word hunt. 3. Pair discussion: gaze as transformative act. 4. Concept introduction: utilitarian vs aesthetic gaze. 5. Student formulation: "Beauty is a refusal to see things only as useful." 6. Teacher names: "This is a secondary theme — beauty as resistance." Aligns with NCF 2005's constructivist approach; builds analytical skill for board exams.
DIFFICULTY: medium