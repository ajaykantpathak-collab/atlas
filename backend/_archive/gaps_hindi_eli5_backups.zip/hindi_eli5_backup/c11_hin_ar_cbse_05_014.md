## DEFINITION
Writing Skills based on the chapter refers to the ability to compose structured, evidence-based responses (short answers, long answers, character sketches, thematic analyses) that demonstrate comprehension, critical thinking, and linguistic precision using the PEEL (Point, Evidence, Explanation, Link) framework.

## COGNITIVE_LEVEL
apply

## MASTERY_CRITERIA
The student can independently write a board-standard answer for any question on "xyrk yksgk" by: (1) stating a clear point addressing the question, (2) citing specific textual evidence (incident, dialogue, description), (3) explaining how the evidence supports the point, and (4) linking back to the question's demand or the story's central theme.

## SCOPE_BOUNDARY
This node covers writing analytical and interpretive answers (30-40 words, 60-80 words, 100-120 words) for the prose chapter "xyrk yksgk" only. It does not cover creative writing (story, letter, article), poetry analysis, or grammar exercises unrelated to textual response writing.

## WALKTHROUGH
Imagine you are asked: "Write a character sketch of Eksgu in 100 words." You recall he is a lower-caste boy, but a blank page stares back. Begin by listing 3-4 defining traits (resilience, internalized inferiority, devotion to teacher). For each trait, hunt the text for one concrete incident (e.g., his silence when beaten, his joy at memorizing the poem). Now structure: Trait → Incident → What it reveals → Connect to caste theme. This PEEL chain turns memory into a marked answer.

## DIAGNOSTIC_QUESTION_1
What does the acronym PEEL stand for in the context of writing literature answers?

## DIAGNOSTIC_ANSWER_1
PEEL stands for Point, Evidence, Explanation, Link. A wrong answer (e.g., "Paragraph, Example, Explain, Line") reveals the student lacks a structured framework for answer writing and will likely produce unorganized summaries instead of analytical responses.

## DIAGNOSTIC_QUESTION_2
Explain in your own words why merely summarizing the plot of "xyrk yksgk" does not fetch full marks in a "character sketch of Eksgu" question.

## DIAGNOSTIC_ANSWER_2
A summary narrates events; a character sketch analyzes traits through events. If a student writes "Eksgu is a poor boy who works at the tea stall and learns a poem," they are summarizing. They miss explaining *how* the tea-stall incident reveals his helplessness or *why* memorizing the poem shows his yearning for dignity. This misconception stems from confusing "what happens" with "what it means."

## DIAGNOSTIC_QUESTION_3
A student writes: "Eksgu is oppressed because he is low caste. The teacher beats him. This shows caste discrimination." Apply the PEEL framework to improve this answer by adding specific textual evidence and deeper explanation.

## DIAGNOSTIC_ANSWER_3
Improved PEEL version: Point – Eksgu internalizes caste oppression. Evidence – When the teacher beats him for no fault, Eksgu "does not feel it right to protest" and thinks "this is how it has always been." Explanation – His silence is not weakness but conditioned acceptance; the text says he never saw his father protest either. Link – Thus, the story portrays caste discrimination as a psychological cage, not just physical violence. A wrong answer would keep the vague "teacher beats him" without quoting the exact behavioral detail (silence, father's example) that proves internalization.

## DIAGNOSTIC_QUESTION_4
Compare the responses of Eksgu and his father (Ishvar) to the teacher's injustice. Analyze how their differing reactions reveal the story's theme of generational change vs. stagnation.

## DIAGNOSTIC_ANSWER_4
Eksgu initially accepts injustice silently (stagnation), but later his subtle rebellion (memorizing the poem perfectly, correcting the teacher's pronunciation) shows awakening. Ishvar, however, warns Eksgu not to dream beyond his caste ("What will you do with education?") and later takes pride in Eksgu's menial job. The contrast highlights that the younger generation *can* question the system, but societal pressure (father's fear) pulls them back. A wrong answer would list both as "submissive" missing Eksgu's quiet intellectual resistance.

## DIAGNOSTIC_QUESTION_5
Evaluate the effectiveness of the story's ending where Eksgu rides away on the bicycle "like a free bird." Defend your judgment with textual reasoning.

## DIAGNOSTIC_ANSWER_5
The ending is ironically effective: the bicycle ride *looks* like freedom, but the text notes he rides "with the same blank eyes" and returns to the same tea stall. The "free bird" image is the narrator's/observer's projection, not Eksgu's reality. This irony underscores the story's central message – structural freedom requires more than a momentary escape. A weak evaluation would call it a "happy ending" ignoring the textual cues (blank eyes, return to stall) that signal continued entrapment.

## DIAGNOSTIC_QUESTION_6
Create a 60-word answer for: "How does the tea-stall setting function as a symbol in 'xyrk yksgk'?" Use PEEL structure.

## DIAGNOSTIC_ANSWER_6
Point: The tea stall symbolizes the inescapable caste trap. Evidence: Eksgu works there before and after school; the owner calls him "lowly" and the customers treat him as invisible. Explanation: The stall is a microcosm of society where his identity is reduced to "chamar boy" regardless of his education. Link: Thus, the setting reinforces that physical mobility (school) doesn't break social immobility. A poor answer would describe the stall physically (smell, cups) without connecting to caste symbolism.

## COMMON_MISCONCEPTION
Students believe "using difficult Hindi words" or "writing long paragraphs" earns marks. They stuff answers with vocabulary (e.g., *izfr}a}h, lsozsQVsfj;V*) without linking them to the question. In "xyrk yksgk", they might write "Eksgu's *izfr}a}h is broken" but not explain *which incident* breaks it or *how* it connects to the teacher's irony. This happens because they memorize glossary definitions (node 010) but skip the application step (node 013).

## ON_FAILURE
1. Pick one question from the textbook exercise (e.g., Q2: "Is the teacher a ideal teacher?"). 2. Force the student to write ONLY the Point sentence. 3. Ask: "Which ONE line from the story proves this?" – they must underline it in the text. 4. Have them write the Explanation sentence starting with "This shows that..." 5. Finally, add the Link sentence connecting to "caste discrimination in education". Repeat for 3 questions until PEEL becomes automatic.

## BUILDS_ON
Character analysis (nodes 004, 005), theme identification (nodes 006, 007), and critical thinking (node 013) provide the raw material (traits, themes, interpretations) that writing skills structure into answers.

## LEADS_TO
Speaking and Listening (node 015) where students must orally defend the same interpretations they now write, requiring the same evidence-to-claim logic.

## PREREQUISITE_NODE_IDS
c11_hin_ar_cbse_05_004, c11_hin_ar_cbse_05_005, c11_hin_ar_cbse_05_006, c11_hin_ar_cbse_05_007, c11_hin_ar_cbse_05_012, c11_hin_ar_cbse_05_013, c11_hin_ar_cbse_05_008, c11_hin_ar_cbse_05_009, c11_hin_ar_cbse_05_011

## PREREQUISITE_REASONS
c11_hin_ar_cbse_05_004: Provides protagonist traits and key incidents needed as evidence in answers.
c11_hin_ar_cbse_05_005: Supplies supporting characters' roles for comparative answers.
c11_hin_ar_cbse_05_006: Gives primary theme (caste oppression) for the Link step in PEEL.
c11_hin_ar_cbse_05_007: Offers secondary themes (education, dignity) for nuanced answers.
c11_hin_ar_cbse_05_012: Ensures literal comprehension of plot details before analysis.
c11_hin_ar_cbse_05_013: Develops interpretive claims that become the Point in PEEL.
c11_hin_ar_cbse_05_008: Writing skills (analytical paragraph) require quoting and explaining imagery/metaphor.  
c11_hin_ar_cbse_05_009: Writing tasks (e.g., character sketch, theme essay) demand integration of these devices.  
c11_hin_ar_cbse_05_011: Writing skills (article/speech) require demonstrating command of reported speech, compound verbs, and appropriate register – all practiced here.  

## FORWARD_NODE_IDS
c11_hin_ar_cbse_05_015, c12_hin_a_cbse_05_014, c12_hin_ar_cbse_05_014, c12_hin_ar_cbse_06_014

## FORWARD_REASONS
c11_hin_ar_cbse_05_015: Speaking tasks require the same structured argumentation (Point-Evidence-Explanation) now practiced in writing.
c12_hin_a_cbse_05_014: अगला तार्किक चरण: Writing Skills based on the chapter refers to the ability to compose structured, evidence-based resp... इस नोड की अवधारणाओं को सीधे उपयोग/विस्तारित करता है।  
c12_hin_ar_cbse_05_014: Class 11 writing skills foundation (basic PEEL, creative response) — this node advances to multi-text comparison  
c12_hin_ar_cbse_06_014: Creative response writing practice  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS


## CHAIN_DESCRIPTION
c11_hin_ar_cbse_05_004 -> c11_hin_ar_cbse_05_014 -> c11_hin_ar_cbse_05_015

## THIS_FORMULA
PEEL = Point (Direct answer to question) + Evidence (Specific textual detail: incident/dialogue/description) + Explanation (Analysis of evidence: what it reveals about character/theme) + Link (Connection to question's key word or chapter's central concern)

## FORMULA_VARIABLES
Point: One-sentence claim addressing the question keyword (e.g., "Eksgu represents internalized oppression").
Evidence: Concrete textual reference (e.g., "When the teacher beats him, Eksgu thinks 'this is how it has always been'").
Explanation: Interpretation of evidence (e.g., "His silence stems from generational conditioning, not cowardice").
Link: Tie-back to question/theme (e.g., "Thus, the story shows caste discrimination operates through psychological conditioning").

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
linguistic

## CROSS_SUBJECT
c11_history_caste_system | The story's depiction of hereditary occupation (tea stall, cleaning) mirrors historical caste-based division of labor studied in History.
c11_sociology_social_stratification | Eksgu's inability to convert education into social mobility illustrates the sociological concept of "closed stratification system".
c11_economics_poverty_alleviation | The father's fear of Eksgu's education ("What will you do with it?") reflects economic rationality in a system where low-caste education doesn't guarantee jobs.
c11_civics_social_justice | The teacher's hypocrisy (teaching equality, practicing discrimination) exemplifies the gap between constitutional ideals and social reality.

## PREREQ_CONCEPT
Student must be able to distinguish between *plot summary* (what happens) and *analytical claim* (what it means) – the core shift from Class 10 to Class 11 answer writing.

## PREREQ_BEFORE
Student should have completed the "Critical Thinking: Analysis and Interpretation" node (c11_hin_ar_cbse_05_013) where they practiced forming interpretive claims about the text.

## PREREQ_STUCK
If stuck, review the "Theme: Primary Theme and Message" node (c11_hin_ar_cbse_05_006) to recall the central concern (caste oppression) that every answer must ultimately link to.

## WORKED_EXAMPLE_1
PROBLEM: Write a 80-word answer: "How does the author use the 'poem memorization' episode to reveal Eksgu's character and the teacher's hypocrisy?"
STEPS:
- Step 1: Identify question keywords – "poem memorization episode", "Eksgu's character", "teacher's hypocrisy". Two distinct demands.
- Step 2: Recall the episode – Teacher forces Eksgu to memorize a poem for a function; Eksgu struggles but succeeds; teacher takes credit.
- Step 3: Draft Point for Eksgu – Eksgu's perseverance and hidden intelligence shine through his rote memorization despite humiliation.
- Step 4: Draft Evidence for Eksgu – He practices "day and night," corrects the teacher's pronunciation privately, but stays silent publicly.
- Step 5: Draft Explanation for Eksgu – His silent correction shows self-respect; his public silence shows forced submission.
- Step 6: Draft Point for Teacher – The teacher exploits Eksgu's labor for personal glory while denying him dignity.
- Step 7: Draft Evidence for Teacher – Teacher says "I taught him" at the function, but earlier beat him for no reason.
- Step 8: Link both to hypocrisy theme – Education becomes a tool for upper-caste display, not lower-caste empowerment.
REASONING: The question has two parts; PEEL must be applied twice (once per character) then synthesized. The Link step merges both analyses into the chapter's central irony.
ANSWER: The poem episode exposes Eksgu's quiet resilience and the teacher's performative benevolence. Eksgu memorizes the poem through "day and night" practice and even corrects the teacher's pronunciation in private, revealing sharp intellect and self-worth. Yet he endures public beating silently, showing internalized subjugation. Conversely, the teacher claims "I taught him" at the function after previously beating him unjustly, exposing how upper-caste educators appropriate lower-caste labor for social capital. Thus, education in the story reinforces caste hierarchy rather than dismantling it.

## WORKED_EXAMPLE_2
PROBLEM: Improve this weak 40-word answer: "The father Ishvar is a negative character because he doesn't support Eksgu's education. He says what will you do with education. He wants him to work at tea stall."
STEPS:
- Step 1: Diagnose weakness – It's a summary of father's dialogues, no analysis of *why* he thinks so, no textual nuance, no link to theme.
- Step 2: Formulate Point – Ishvar's opposition stems from protective realism, not negativity; he fears the system will crush Eksgu's dreams.
- Step 3: Select Evidence – His dialogue: "What will you do with education? You'll have to work at the tea stall." Also his pride when Eksgu gets the stall job.
- Step 4: Write Explanation – As a father who suffered caste violence, he sees education as a false promise; his "negativity" is survival wisdom.
- Step 5: Link to theme – This illustrates how caste oppression distorts even parental love into a tool of social reproduction.
REASONING: The improved answer replaces judgment ("negative character") with empathy ("protective realism") using the same dialogues but interpreted through the lens of structural oppression – a Class 11 analytical leap.
ANSWER: Ishvar is not simply "negative"; his resistance to Eksgu's education arises from lived experience of caste brutality. When he asks, "What will you do with education? You'll have to work at the tea stall," he voices a father's protective realism – he knows the system denies dignity to educated lower-caste men. His later pride in Eksgu's stall job confirms he equates survival with acceptance. Thus, the story portrays how caste oppression corrupts parental aspiration into complicity, making the family itself a site of social reproduction.

## WORKED_EXAMPLE_3
PROBLEM: Write a 120-word critical appreciation of the story's title "xyrk yksgk" (Strange Witness). Combine theme, symbolism, and narrative perspective.
STEPS:
- Step 1: Deconstruct title – "xyrk" (strange/unique) + "yksgk" (witness). Who is the witness? The narrator? The reader? Eksgu himself?
- Step 2: Identify narrative perspective – Third-person limited, focusing on Eksgu's consciousness but with authorial irony.
- Step 3: Connect "witness" to theme – The story bears witness to everyday caste violence that society ignores. The "strange" witness is the one who *sees* what others normalize.
- Step 4: Gather Evidence – Narrator describes Eksgu's beating as "routine"; teacher's hypocrisy as "usual"; father's fear as "natural".
- Step 5: Analyze Symbolism – The bicycle ride at end: Eksgu becomes a "strange witness" to his own fleeting freedom.
- Step 6: Synthesize with PEEL – Point: Title encapsulates the story's act of testimony. Evidence: Narrator's detailed recording of "normal" injustices. Explanation: By making the invisible visible, the story forces reader to witness. Link: Title thus functions as a meta-comment on literature's role in social justice.
REASONING: This question demands synthesis of multiple concepts (title, narrative technique, theme, symbolism). The 6-step process ensures each layer is grounded in text before synthesis.
ANSWER: The title "xyrk yksgk" (Strange Witness) operates at three levels. First, the narrator acts as a strange witness – documenting caste atrocities (beatings, humiliation, stolen credit) that society treats as ordinary. The detailed, matter-of-fact narration of "routine" injustice makes the familiar appear strange, forcing reader discomfort. Second, Eksgu himself becomes a witness to his own life – the final bicycle ride, where he "looks with blank eyes" at his momentary freedom, captures the tragedy of a consciousness that *sees* its cage but cannot break it. Third, the reader is positioned as the ultimate strange witness – invited to testify against a social order that renders such stories invisible. Thus, the title transforms the story from a mere narrative into an act of ethical testimony, aligning with the author's stated aim to give voice to "those whom history forgets."

## COMPETENCY_QUESTION_1
QUESTION: A student writes: "The teacher is a bad person because he beats Eksgu and takes credit for his poem." Using the PEEL framework, rewrite this answer to meet Class 11 board standards (60 words). The rewrite must include: (a) a nuanced character trait (not just "bad"), (b) specific textual evidence, (c) analysis of the teacher's motivation, (d) link to the story's critique of education.
COMPETENCY: Analytical Writing - Character Analysis with Textual Evidence
STEPS:
- Step 1: Replace "bad person" with a precise trait: "performative benevolence masking caste prejudice."
- Step 2: Choose two evidences: (i) beating Eksgu for no fault, (ii) claiming "I taught him" at function.
- Step 3: Analyze motivation – Teacher needs a "success story" for his image; Eksgu is a prop.
- Step 4: Link to critique – Education system rewards upper-caste performance, not lower-caste merit.
ANSWER: The teacher embodies performative benevolence masking deep caste prejudice. He beats Eksgu for a trivial error ("Why didn't you come yesterday?") revealing arbitrary power, yet later claims "I taught him" at the school function, appropriating Eksgu's labor for social capital. This duality shows he views Eksgu not as a student but as a prop for his own image. Thus, the story exposes how institutional education becomes a stage for upper-caste virtue-signaling while perpetuating the very hierarchy it claims to erase.
DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: "The ending of 'xyrk yksgk' is hopeless." Evaluate this statement in 100 words. Your answer must: (a) acknowledge the surface hopelessness, (b) introduce a counter-perspective using the "strange witness" concept, (c) cite the bicycle imagery and the narrator's tone, (d) conclude with the story's purpose as social testimony.
COMPETENCY: Critical Evaluation - Balanced Argument with Textual Synthesis
STEPS:
- Step 1: Concede surface reading – Bicycle ride ends at same tea stall; "blank eyes" suggest unchanged reality.
- Step 2: Introduce counter – The narrator's very act of writing makes the ending a testimony, not defeat.
- Step 3: Use bicycle imagery – "Free bird" is ironic freedom; but the *description* of it as strange witness creates historical record.
- Step 4: Cite narrator's tone – Clinical detailing of injustice ("routine beating", "usual hypocrisy") is an act of resistance.
- Step 5: Conclude – Story's purpose: to make the invisible visible; hopelessness is the reality, witnessing is the remedy.
ANSWER: On the surface, the ending is hopeless: Eksgu rides "like a free bird" but returns to the tea stall with "blank eyes," his material reality unchanged. However, the narrator's clinical tone – recording beatings as "routine," hypocrisy as "usual" – transforms the narrative into a strange witness (xyrk yksgk). The bicycle imagery, instead of false hope, becomes a documented moment of stolen dignity. By forcing the reader to *see* what society ignores, the story performs its true function: not to offer solutions, but to testify. As the author states, such stories give voice to "those whom history forgets." Thus, the ending's power lies in its refusal to falsify hope while insisting on the necessity of witness.
DIFFICULTY: hard