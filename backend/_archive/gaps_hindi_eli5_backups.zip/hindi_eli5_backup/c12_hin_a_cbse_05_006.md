## DEFINITION
The primary theme of a poem is its central, unifying idea that emerges from the interplay of imagery, tone, structure, and language; the message is the poet's implicit or explicit insight about human experience that the theme conveys. In Jagadish Lal's poems "olar vk;k" and "rksM+ks", the primary themes are respectively the inexorable passage of time and the persistence of memory, and the dignity of labor intertwined with existential questioning.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student can independently identify the primary theme of each poem, trace its development across stanzas using specific textual evidence (imagery, repetition, diction), and articulate the message in their own words with a structured PEEL (Point, Evidence, Explanation, Link) response suitable for a 3-5 mark board answer.

## SCOPE_BOUNDARY
This node covers only the primary theme and message of the two prescribed poems ("olar vk;k" and "rksM+ks") in NCERT Class 12 Hindi Antra Chapter 5. It does NOT cover secondary themes (node 007), literary devices in isolation (nodes 008-009), or comparative analysis with other poets/chapters.

## WALKTHROUGH
Imagine you are telling a friend about a movie you watched — you don't recount every scene; you say, "It's about how time catches up with everyone, but memories keep the past alive." That one-sentence core is the *theme*. Now, open your textbook to "olar vk;k". Read the first stanza aloud. Notice the rhythm of the old man's walk — slow, deliberate. Ask yourself: *What is the poet showing me through this image?* Not just "an old man walking" but "time made visible." Move stanza by stanza, marking words that repeat (time, memory, youth) and shifts in tone (nostalgia → acceptance). Do the same for "rksM+ks": the hammer strikes are not just sound; they are the heartbeat of labor. The theme emerges when you connect the *what* (images/actions) to the *why* (human condition). The key insight: **theme is not a topic (old age, labor) — it is a statement about that topic (old age reveals the fragility of vitality; labor reveals the search for meaning).**

## DIAGNOSTIC_QUESTION_1
What is the difference between a *topic* (विषय) and a *theme* (मुख्य भाव/थीम) in poetry? Give one example from "olar vk;k" to illustrate.

## DIAGNOSTIC_ANSWER_1
A topic is the surface subject (e.g., "old age" or "an old man walking"); a theme is the poet's insight about that subject (e.g., "Time erodes the body but memory preserves the self"). In "olar vk;k", the topic is the old man's daily walk; the theme is the inevitability of aging and the mind's resistance through memory. A wrong answer that lists only "old age" or "walking" reveals the student confuses subject with thematic statement — a critical error in board answers where examiners expect a complete sentence expressing an idea, not a noun phrase.

## DIAGNOSTIC_QUESTION_2
In "olar vk;k", the poet uses the phrase "veqd fnu veqd ckj enueghus dh gksosxh iapeh" (day after day, the sun of many seasons has risen). Explain in your own words what this line contributes to the primary theme. Do not just translate.

## DIAGNOSTIC_ANSWER_2
This line establishes the vast timescale over which the old man has lived — countless seasons, repetitive cycles — emphasizing that his present frailty is the result of a long, lived life, not a sudden event. It deepens the theme by contrasting the eternal, indifferent rhythm of nature (sun rising daily) with the finite, personal arc of human vitality. A wrong answer that merely translates ("the sun rose many days") shows the student sees imagery as decoration rather than as thematic evidence — they miss how *repetition of natural cycles* underscores *human transience*, a pattern examiners look for in "how does the poet convey..." questions.

## DIAGNOSTIC_QUESTION_3
Apply the PEEL structure to write a 3-sentence answer for: "How does the repetition of 'rksM+ks' (रक्षस) in the first stanza of the second poem establish its primary theme?"

## DIAGNOSTIC_ANSWER_3
**Point:** The thrice-repeated "rksM+ks" mimics the rhythmic hammer strikes of the stone-breaker, making the poem's sound enact its subject. **Evidence:** The opening lines "rksM+ks rksM+ks rksM+ks / ;s iRFkj ;s p^kuas" pair the word with the tools (hammer, chisel). **Explanation:** This sonic repetition transforms the word from a noun into a verb-like pulse, conveying that the act of breaking stones is continuous, defining, and inescapable — the very condition of the laborer's existence. **Link:** Thus, the repetition establishes the theme: labor as an unending, identity-shaping struggle. A wrong answer that says "it shows he works hard" without linking sound to meaning misses the *analytical* step — board marking schemes reward "how" (technique) + "why" (effect), not just "what" (content).

## DIAGNOSTIC_QUESTION_4
Compare the role of *nature imagery* in establishing the primary theme of "olar vk;k" versus "rksM+ks". How does the same element (nature) serve different thematic purposes?

## DIAGNOSTIC_ANSWER_4
In "olar vk;k", nature (sun, seasons, wind) is a *witness* and *contrast* — it cycles eternally while the human ages, highlighting transience. In "rksM+ks", nature (stone, dust, sky) is the *adversary* and *material* — the stone resists, the dust chokes, the sky watches indifferently, making labor a confrontation. The student must analyze *function*, not just list images. A wrong answer that says "both poems use nature imagery" without differentiating *thematic role* (contrast vs. confrontation) fails the "analyze" demand — it stays at identification level, losing 2+ marks in a 5-mark comparative question.

## DIAGNOSTIC_QUESTION_5
Evaluate this student claim: "The message of 'rksM+ks' is that hard work always leads to success." Defend or refute using textual evidence.

## DIAGNOSTIC_ANSWER_5
Refute. The poem offers no "success" in a conventional sense — the stones are broken but the laborer remains questioning ("ge bldks D;k dj Mkysa bl vius eu dh [kht dks\"). The message is existential: labor *is* the human condition, not a means to an end. The final stanza's rhetorical questions ("What do we do with this mountain of our heart's hardness?") suggest the real "stone" is internal, unbreakable by external effort. A student who agrees reveals a *moralistic misreading* — imposing a motivational slogan onto a poem about absurdity and endurance. Board examiners penalize answers that ignore the text's ambiguity and philosophical depth in favor of simplistic "lessons."

## DIAGNOSTIC_QUESTION_6
Create a 4-line stanza in Hindi (or Hindi-English mix) that captures the primary theme of *either* poem, using at least one image from the original and one original metaphor of your own.

## DIAGNOSTIC_ANSWER_6
Example for "olar vk;k":
*बूढ़े पैरों की थाप अब भी गिनती है मौसम,*
*सूरज उगा था तब भी, आज भी उगता है,*
*मेरी देह भले जीर्ण हो, पर स्मृति का दीपक —*
*हवा नहीं, वक्त भी जिसे न बुझा पाता।*
Criteria: Must show the theme (time vs. memory), use an original metaphor ("स्मृति का दीपक"), and echo an original image (sun/seasons). A poor answer that writes a generic moral ("बुढ़ापा दुखद है, पर यादें अच्छी हैं") without imagery or metaphor reveals the student cannot *transfer* thematic understanding into creative synthesis — the highest Bloom level.

## COMMON_MISCONCEPTION
Students consistently confuse *theme* with *moral* or *summary*. They write: "The theme of 'olar vk;k' is that we should respect elders" (moral) or "An old man remembers his youth while walking" (summary). The NCERT marking scheme explicitly distinguishes: theme = *the central idea explored* (e.g., "the tension between bodily decay and mental continuity"), moral = *a prescriptive lesson* (rarely the poet's intent in modern Hindi poetry), summary = *plot paraphrase*. This error stems from school-level "message hunting" habits where fables have clear morals; modern poetry like Jagadish Lal's *resists* single morals and instead *explores* complexity. Students also miss that a poem can have *one primary theme* with multiple facets — they either list disconnected topics or force a false unity.

## ON_FAILURE
1. **Revisit the distinction**: Have the student write three columns for "olar vk;k" — Topic / Summary Sentence / Theme Statement. Model one: Topic = "Old man's walk"; Summary = "An old man walks slowly, remembering his youth"; Theme = "Time inevitably ages the body, but memory allows the self to transcend the present moment." 2. **Color-code the poem**: Use three highlighters — one for *time/aging images*, one for *memory/youth images*, one for *structural markers* (repetition, stanza breaks). Ask: "Which color dominates each stanza? How does the balance shift?" 3. **Re-diagnostic**: Give a new 3-mark question: "Identify the primary theme of 'rksM+ks' and support with two images." Require a full PEEL paragraph. If the answer still states a moral or summary, repeat step 1 with "rksM+ks".

## BUILDS_ON
Character Analysis: Protagonist (c12_hin_a_cbse_05_004) and Supporting Characters (c12_hin_a_cbse_05_005) — the "old man" and "stone-breaker" function as poetic personae whose actions and inner lives embody the themes.

## LEADS_TO
Theme: Secondary Themes (c12_hin_a_cbse_05_007) — once the primary theme is secured, students can identify subsidiary strands (e.g., alienation, art's role) without conflating them with the core.

## PREREQUISITE_NODE_IDS
c12_hin_a_cbse_05_002, c12_hin_a_cbse_05_004, c12_hin_a_cbse_05_005, c11_hin_ar_cbse_05_006, c11_hin_v_cbse_05_006, c12_hin_a_cbse_05_001, c12_hin_a_cbse_05_003

## PREREQUISITE_REASONS
c12_hin_a_cbse_05_002: Plot/Narrative Structure gives the sequence of images/stanzas — theme emerges *across* this structure, not in isolated lines.
c12_hin_a_cbse_05_004: Protagonist Analysis establishes the old man and stone-breaker as personae — their consciousness *is* the thematic lens.
c12_hin_a_cbse_05_005: Supporting Characters (e.g., the implied "you" in "olar vk;k", the unseen questioner in "rksM+ks") frame the thematic address.
c11_hin_ar_cbse_05_006: Class 11 Antra Theme node — students already practiced theme identification; this node deepens to *message articulation* and *board-style justification*.
c11_hin_v_cbse_05_006: Class 11 Vitan Theme node — reinforces the skill across textbooks, ensuring transfer.
c12_hin_a_cbse_05_001: Primary theme (labour, change) is seeded in the background note.  
c12_hin_a_cbse_05_003: The theme of labor and resilience is embodied in the setting-atmosphere complex.  

## FORWARD_NODE_IDS
c12_hin_a_cbse_05_007, c12_hin_a_cbse_05_008, c12_hin_a_cbse_05_009, c12_hin_a_cbse_05_013, c12_hin_a_cbse_05_014, c12_hin_a_cbse_05_015

## FORWARD_REASONS
c12_hin_a_cbse_05_007: Secondary Themes require a firm primary theme anchor — otherwise students elevate minor motifs to primary status.
c12_hin_a_cbse_05_008: Imagery/Metaphor analysis *serves* theme — students now ask "What thematic work does this metaphor do?" not just "Identify the metaphor."
c12_hin_a_cbse_05_009: Irony/Symbolism similarly become thematic tools — e.g., the irony of "eternal sun vs. mortal man" serves the time theme.
c12_hin_a_cbse_05_013: Critical Thinking/Interpretation questions (board 5-markers, CUET style) demand thematic synthesis — this node provides the foundation.
c12_hin_a_cbse_05_014: Primary theme (aging/decay/memory) — the central "Point" for most answers.  
c12_hin_a_cbse_05_015: Identifies primary themes that become the core of discussion.  

## CROSS_SUBJECT_PREREQS
c11_hin_ar_cbse_05_006, c11_hin_v_cbse_05_006
## CROSS_SUBJECT_REASONS
c11_hin_ar_cbse_05_006: Class 11 Antra Chapter 5 theme analysis — same skill (identify + justify), lower complexity texts; confirms the *method* (PEEL, image-to-idea) is already known.
c11_hin_v_cbse_05_006: Class 11 Vitan Chapter 5 theme analysis — different genre (prose/non-fiction), same cognitive demand; proves theme extraction is genre-agnostic.

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_05_006 -> c12_hin_a_cbse_05_006 -> c12_hin_a_cbse_05_007

## THIS_FORMULA
N/A - conceptual

## FORMULA_VARIABLES
N/A

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
analytical

## CROSS_SUBJECT
N/A | The theme of "time as both destroyer and preserver" in "olar vk;k" parallels the historical concept of *continuity and change* in Indian civilization — e.g., how oral traditions (memory) preserve culture across dynastic cycles (time).
 N/A | The stone-breaker in "rksM+ks" embodies the *human-environment interaction* theme in geography: labor transforming raw material (stone) under physical constraints (heat, dust), raising questions of sustainability and dignity — directly linked to "informal sector labor" case studies.
## PREREQ_CONCEPT
The ability to distinguish *topic* (noun phrase) from *theme* (complete idea statement) and to trace a single idea across multiple stanzas using textual evidence.

## PREREQ_BEFORE
Student must have completed Character Analysis nodes (004, 005) and Plot/Narrative Structure (002) for this chapter, and recall the Class 11 theme-analysis method (PEEL, image-to-idea).

## PREREQ_STUCK
If stuck, review the PEEL structure using the Class 11 Antra Chapter 5 theme node (c11_hin_ar_cbse_05_006) — specifically the worked example there on "theme vs. moral."

## WORKED_EXAMPLE_1
PROBLEM: Analyze how the primary theme of "olar vk;k" (time's erosion of the body vs. memory's preservation of the self) is developed in the first two stanzas. Write a board-style 4-mark answer.

STEPS:
- Step 1: Identify the theme statement clearly — "The poem explores the tension between the body's inevitable aging and the mind's capacity to retain youth through memory."
- Step 2: Scan Stanza 1 for evidence of *bodily aging* — locate "cM+s&cM+s fi;jk, iÙks" (trembling steps), "f[kyh gqbZ gok" (withered body), "fiQjdh&lh vkbZ" (bent back). These are physical decay images.
- Step 3: Scan Stanza 1-2 for evidence of *memory/youth persisting* — locate "veqd fnu veqd ckj enueghus dh gksosxh iapeh" (countless suns risen), "dfork,¡ i<+rs jgus ls" (reading poems), "ngj&ngj ngosaQxs dgha <kd osQ taxy vke ckSj vkosaxs" (youth's energy still echoes in memory).
- Step 4: Explain the *contrast* — the same stanza holds both: the body walks slowly *now*, but the mind walks through *decades* of suns. The poet uses natural cycles (sun, seasons) as a measuring rod for human time.
- Step 5: Conclude with the thematic insight — "Thus, the primary theme is not merely 'old age' but the duality of human time: chronological time ages the body, while psychological time (memory) keeps the past alive."

REASONING: This models the exact board expectation: theme statement → stanza-wise evidence → explanation of *how* evidence builds theme → synthesized insight. It avoids summary by focusing on *tension/contrast* as the engine of theme.

ANSWER:
The primary theme of "olar vk;k" is the tension between the body's inevitable aging and the mind's capacity to preserve youth through memory. In Stanza 1, images of physical decay — "cM+s&cM+s fi;jk, iÙks" (trembling steps), "f[kyh gqbZ gok" (withered body), "fiQjdh&lh vkbZ" (bent back) — establish the body's surrender to time. Simultaneously, Stanza 1-2 invoke memory's vast archive: "veqd fnu veqd ckj enueghus dh gksosxh iapeh" (countless suns of countless days) and the recollection of youthful vigor ("ngj&ngj ngosaQxs dgha <kd osQ taxy vke ckSj vkosaxs"). The poet juxtaposes the *present* frailty against the *accumulated* past, using nature's cycles (sun, seasons) as an objective clock. The theme emerges in this contrast: chronological time erodes the body, but psychological time (memory, art, poetry) allows the self to transcend the present moment. The old man's walk is not just a physical act; it is a ritual of remembrance.

## WORKED_EXAMPLE_2
PROBLEM: The poem "rksM+ks" opens with the thrice-repeated word "rksM+ks" followed by tools ("iRFkj", "p^kuas"). Explain how this sonic and lexical patterning establishes the poem's primary theme of *labor as existential condition*. Write a 3-mark answer.

STEPS:
- Step 1: State the theme precisely — "Labor is not merely an occupation but the defining, unending condition of human existence, where the external act of breaking stones mirrors the internal struggle to break meaning from absurdity."
- Step 2: Analyze the sonic patterning — "rksM+ks rksM+ks rksM+ks" mimics the *rhythmic hammer strikes*; the repetition is not decorative but *performative* — the reader hears the work.
- Step 3: Analyze the lexical pairing — the immediate listing of tools ("iRFkj" hammer, "p^kuas" chisel) grounds the sound in material reality; the body and tool become one.
- Step 4: Connect to the stanza's closing lines — "fe^h esa jl gS ftlls mxrh nwc gS / vius eu osQ eSnkuksa ij O;kih oSQlh Åc gS" — the "flame in the stomach" (hunger/drive) and "frozen tears on the heart's corners" (suppressed pain) show labor is driven by need and endured with stoicism.
- Step 5: Synthesize — The opening's repetition + tool imagery + internal state = labor as *total condition*, not task. The theme is established before the narrative progresses.

REASONING: Board answers for "how does the poet convey..." require *technique → effect → theme* linkage. This example shows sound (repetition), diction (tools), and image (flame/teeth) all converging on one thematic point — the hallmark of a high-scoring response.

ANSWER:
The opening of "rksM+ks" establishes its primary theme — labor as the inescapable, identity-defining condition of human existence — through sonic, lexical, and imagistic convergence. The thrice-repeated "rksM+ks rksM+ks rksM+ks" enacts the rhythmic hammer strikes, making the poem's sound *perform* the labor it describes. This sonic pulse is immediately grounded in material reality by the tools "iRFkj" (hammer) and "p^kuas" (chisel), fusing body and instrument. The stanza then internalizes this externality: "fe^h esa jl gS ftlls mxrh nwc gS" (a flame burns in the stomach that knows no satiety — hunger/drive) and "vius eu osQ eSnkuksa ij O;kih oSQlh Åc gS" (frozen tears on the corners of one's own heart — stoic endurance). Thus, before any narrative unfolds, the poem declares: to break stones is to be human — driven by unending need, enduring unspoken pain, defined by the strike.

## WORKED_EXAMPLE_3
PROBLEM: A board exam question asks: "Compare the primary themes of 'olar vk;k' and 'rksM+ks'. How does Jagadish Lal use the figure of the *aging/working body* to explore two different facets of the human condition?" Write a 5-mark structured response.

STEPS:
- Step 1: Write a clear comparative thesis — "Both poems center the aging/working body, but 'olar vk;k' uses it to explore *time and memory*, while 'rksM+ks' uses it to explore *labor and existential questioning*."
- Step 2: Analyze "olar vk;k" body — the old man's body is a *site of memory*; its slowness ("cM+s fi;jk") contrasts with the mind's speed ("pyrs pyrs pyrs" — the mind races through decades). The body is *passive* (acted upon by time); the mind is *active* (retrieving, preserving).
- Step 3: Analyze "rksM+ks" body — the stone-breaker's body is a *site of action*; its strikes ("rksM+ks") are deliberate, rhythmic, transformative. The body is *active* (acting upon stone); but the *result* is questioned ("ge bldks D;k dj Mkysa..."). The body works, but the *meaning* of the work remains open.
- Step 4: Identify the pivot — In both, the body is the *interface* between self and world. In Poem 1, the interface *records* (memory inscribed on decaying flesh). In Poem 2, the interface *confronts* (will imposed on resistant matter).
- Step 5: Conclude with the poet's vision — "Jagadish Lal presents the body as both *vessel of time* and *agent of labor* — the two inescapable dimensions of being human. The primary themes are thus complementary: one asks 'What remains when the body fails?' (memory); the other asks 'What does the body achieve when it persists?' (questioning)."

REASONING: This is a *synthesis* task — the hardest board question type. It demands: (a) two clear theme statements, (b) a shared lens (the body), (c) contrastive analysis using that lens, (d) a unifying insight. The worked example shows how to structure comparison *thematically*, not poem-by-poem summary.

ANSWER:
Both poems center the aging/working body as the locus of the human condition, but they illuminate opposing facets. In "olar vk;k", the old man's body is a *site of memory* — its slowness ("cM+s&cM+s fi;jk, iÙks") contrasts with the mind's temporal reach ("pyrs pyrs pyrs" across decades of suns). The body is passive, acted upon by time; the mind actively preserves the past. The theme: **time erodes the body, but memory transcends it.** In "rksM+ks", the stone-breaker's body is a *site of action* — its rhythmic strikes ("rksM+ks rksM+ks rksM+ks") impose will on resistant matter. The body is active, transforming the world; yet the poem ends in existential questioning ("ge bldks D;k dj Mkysa bl vius eu dh [kht dks\"). The theme: **labor defines the self, but its meaning remains uncertain.** The pivot: in both, the body is the interface between self and world. Poem 1: interface as *recorder* (memory on decaying flesh). Poem 2: interface as *confronter* (will on stone). Jagadish Lal's vision: to be human is to inhabit a body that *both* records time's passage *and* resists it through labor — the two inescapable dimensions of existence.

## COMPETENCY_QUESTION_1
QUESTION: A student writes in a 3-mark answer: "The theme of 'olar vk;k' is that old age is sad but memories make us happy." Identify two specific weaknesses in this answer relative to CBSE marking expectations, and rewrite it to score full marks.

COMPETENCY: Critical evaluation of peer response / Answer improvement (CBSE Competency: "Applying literary analysis to improve written expression")

STEPS:
- Step 1: Identify Weakness 1 — "Old age is sad" reduces a complex theme (time/body/memory) to a simplistic emotion; "memories make us happy" ignores the poem's bittersweet tone (memories also highlight loss).
- Step 2: Identify Weakness 2 — No textual evidence; no analysis of *how* the poet conveys the theme (imagery, repetition, structure).
- Step 3: Rewrite using PEEL: Point (theme statement), Evidence (two specific images), Explanation (how they work together), Link (back to theme).
- Step 4: Ensure the rewrite uses the poet's name, poem title, and analytical vocabulary ("juxtaposes," "enacts," "transcends").

ANSWER:
Weakness 1: Thematic reductionism — "sad/happy" replaces the nuanced tension between *bodily decay* and *mental continuity* with a binary emotion. Weakness 2: Zero textual grounding — no image, line, or device cited; reads as opinion, not analysis. 
Rewritten full-mark answer: "Jagadish Lal's 'olar vk;k' explores the tension between the body's inevitable aging and the mind's capacity to preserve youth through memory. The poem juxtaposes images of physical decay — 'f[kyh gqbZ gok' (withered body), 'fiQjdh&lh vkbZ' (bent back) — with the vast archive of memory: 'veqd fnu veqd ckj enueghus dh gksosxh iapeh' (countless suns of countless seasons). This contrast, measured against nature's eternal cycles, conveys that chronological time erodes the body while psychological time (memory, poetry) allows the self to transcend the present. The theme is not 'sadness vs. happiness' but the duality of human temporality."

DIFFICULTY
medium

## COMPETENCY_QUESTION_2
QUESTION: In "rksM+ks", the final stanza poses a series of rhetorical questions: "ge bldks D;k dj Mkysa bl vius eu dh [kht dks\" (What do we do with this mountain of our heart's hardness?). Design a 4-step lesson plan for a peer who thinks rhetorical questions in poetry are "just decoration." Your plan must move them from misconception to analytical insight using *only* this poem.

COMPETENCY: Metacognitive scaffolding / Pedagogical design (CBSE Competency: "Creative and critical thinking; Communication")

STEPS:
- Step 1: **Confront the misconception directly** — Ask the peer to read the final stanza aloud *without* the questions (as statements). "We will break this mountain of heart's hardness. We will break the heart's stone." Have them compare the *feeling*: the statements sound like resolutions; the questions sound like *open wounds*. This proves questions ≠ decoration — they *create* the poem's unresolved tension.
- Step 2: **Map the questions to the poem's arc** — Trace: Stanza 1 (action: breaking stone) → Stanza 2 (internal state: hunger, frozen tears) → Stanza 3 (existential turn: breaking *heart's* stone). The questions *are* the turn — they shift the poem from *external labor* to *internal labor*.
- Step 3: **Analyze the central metaphor** — "eu dh [kht" (mountain of heart) = the internal equivalent of the external stones. The rhetorical questions ask: *Can the same hammer break this?* The peer must see the metaphor *enabled* by the questions.
- Step 4: **Synthesize into theme statement** — Co-write: "The rhetorical questions enact the poem's primary theme: external labor has a visible result (broken stones), but internal labor (breaking the heart's hardness) has no guaranteed outcome — the questions *are* the labor." The peer now sees questions as *thematic engine*.

ANSWER:
Lesson Plan: "From Decoration to Engine — Rhetorical Questions in 'rksM+ks'"
1. **Read & Feel**: Read final stanza as statements → as questions. Discuss: Statements = closure; Questions = opening. *Insight: Questions deny closure, mirroring the poem's theme of unending labor.*
2. **Trace the Arc**: Stanza 1 (stone) → Stanza 2 (body/hunger) → Stanza 3 (heart). *Insight: Questions mark the shift from breaking *outside* to breaking *inside*.*
3. **Unlock the Metaphor**: "eu dh [kht" = internal stone. Questions ask: *Does the hammer work here?* *Insight: The metaphor only lives because the questions refuse an answer.*
4. **Co-write Theme**: "Rhetorical questions enact the theme: external labor yields broken stones; internal labor yields only more questions — the questions *are* the unbroken stone."
Result: Peer moves from "questions are pretty" to "questions *are* the poem's argument."

DIFFICULTY
hard