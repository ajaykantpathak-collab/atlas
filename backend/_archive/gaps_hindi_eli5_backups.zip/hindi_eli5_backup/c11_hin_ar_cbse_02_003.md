## DEFINITION
Setting refers to the time, place, and physical environment in which a narrative unfolds, while atmosphere is the emotional mood or feeling evoked in the reader through descriptive details, sensory imagery, and narrative tone. In "फेरीवाले उलहनी," the evening street setting and the tense, conversational atmosphere reveal social hierarchies and the vendor's dignity.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student can identify specific textual evidence of setting (time markers, spatial details, sensory descriptions) and atmosphere (word choice, dialogue tone, pacing), then explain how these elements work together to develop character and theme in a structured analytical paragraph using the PEEL method.

## SCOPE_BOUNDARY
This node covers analysis of setting and atmosphere in the short story "फेरीवाले उलहनी" from NCERT Aroh Class 11 Chapter 2. It does NOT cover plot structure (node 002), character analysis (nodes 004-005), themes (nodes 006-007), or literary devices like imagery/metaphor (node 008) and irony/symbolism (node 009) — those are separate nodes.

## WALKTHROUGH
Imagine you're walking through a busy Indian market at 7 PM — the fading light, the smell of street food, the sound of vendors calling out, the tired but determined faces. Now ask: how does the writer make you *feel* that scene without just listing details? Start by marking every time reference (शाम, अंधेरा, रात) and place marker (सड़क, फुटपाथ, नुक्कड़) in the text. Then highlight words that create feeling: "उदास," "थकी," "उत्साह," "तनाव." Notice how the dialogue's rhythm — short, sharp exchanges versus long monologues — controls the atmospheric tension. The key insight: setting is the stage; atmosphere is the lighting and music that tell you how to feel about what happens on that stage.

## DIAGNOSTIC_QUESTION_1
In "फेरीवाले उलहनी," identify two specific time markers and two specific place markers that establish the physical setting of the opening scene.

## DIAGNOSTIC_ANSWER_1
Correct answer: Time markers — "शाम" (evening) and "अंधेरा घिरने लगा" (darkness gathering); Place markers — "सड़क के किनारे" (roadside) and "फुटपाथ पर" (on the pavement). A wrong answer (e.g., saying "morning" or "inside a shop") reveals the student cannot distinguish explicit textual evidence from assumptions, or confuses the opening scene with later scenes. This indicates a literal comprehension gap — the student needs practice locating explicit setting details before analyzing their effect.

## DIAGNOSTIC_QUESTION_2
Explain in your own words how the writer uses sensory details (sight, sound, smell) in the first three paragraphs to create an atmosphere of tired persistence rather than hopelessness.

## DIAGNOSTIC_ANSWER_2
Correct answer: The writer combines visual details ("थकी आँखें," "मैले कपड़े") with auditory details ("आवाज़ में थकान नहीं," "स्पष्ट उच्चारण") and the smell of "तेल और मसालों" to show a vendor who is physically worn but professionally sharp — the sensory mix creates dignity, not defeat. A wrong answer focusing only on "sadness" or "poverty" reveals the misconception that atmosphere = single emotion; the student misses how contrasting sensory layers (tired body + alert voice) build complex atmosphere. This shows the student reads for plot, not textual texture.

## DIAGNOSTIC_QUESTION_3
Apply the concept of "atmosphere shift" to the moment when लखपत enters the scene. Quote one line before and one line after his entry, then explain how the atmosphere changes using specific words from the text.

## DIAGNOSTIC_ANSWER_3
Correct answer: Before: "फेरीवाला अपनी धुन में मगन था" (vendor absorbed in his rhythm) — atmosphere: calm, routine. After: "लखपत ने कड़ककर पूछा" (Lakhpat asked sharply) — atmosphere: tense, confrontational. Shift created by "कड़ककर" (sharply) replacing "मगन" (absorbed), and interrogative tone replacing declarative. A wrong answer that only says "it gets tense" without quoting words reveals the student cannot link linguistic choices to atmospheric effect — they generalize instead of analyzing textual evidence.

## DIAGNOSTIC_QUESTION_4
Analyze how the physical setting of the "नुक्कड़ की चाय की दुकान" (corner tea stall) functions as more than background — how does it structure the social interactions and power dynamics between उलहनी, लखपत, and जक्सी?

## DIAGNOSTIC_ANSWER_4
Correct answer: The tea stall is a semi-public space where hierarchies play out: लखपत (authority figure) stands, उलहनी (vendor) sits lower on "पटरी," जक्सी (observer) leans — vertical positioning mirrors social power. The stall's "काँच के जार" (glass jars) and "बेंच" create physical barriers/territories. A wrong answer treating the stall as mere backdrop ("they just talk there") reveals the student misses how setting *organizes* character relationships — a senior-secondary error of ignoring spatial semantics in narrative.

## DIAGNOSTIC_QUESTION_5
Evaluate the claim: "The evening setting in 'फेरीवाले उलहनी' is merely a temporal backdrop; the story would work equally well at noon." Defend your judgment with three textual arguments.

## DIAGNOSTIC_ANSWER_5
Correct answer: The claim is false. Argument 1: "अंधेरा घिरने लगा" creates urgency — vendors must sell before total darkness, raising stakes. Argument 2: Evening shadows ("छायाएँ लंबी होती गईं") visually mirror the moral ambiguity लखपत introduces. Argument 3: The "शाम की भीड़" (evening crowd) — tired workers, returning students — forms a specific audience that witnesses the confrontation, making it public accountability, not private dispute. A wrong answer agreeing with the claim reveals the student treats setting as decorative, not functional — a fundamental misreading of narrative craft.

## DIAGNOSTIC_QUESTION_6
Create a 4-line atmospheric paragraph describing a street vendor's setting at a different time of day (early morning OR late night), using at least three sensory details and one word that establishes emotional tone. Do not name the time directly — let the details imply it.

## DIAGNOSTIC_ANSWER_6
Good answer example (early morning): "धुंध में लिपटी सड़क पर ठंडी भाप उठती चाय की गंध के साथ मिलती है; साइकिल की घंटी की टुन-टुन और अखबार के पन्नों की सरसराहट के बीच, एक अकेला ठेला अपनी रोशनी आप ही जलाता है — आशा, थकान से भारी नहीं." (Uses smell, sound, sight; "आशा" establishes tone; implies dawn without naming it.) A poor answer ("Morning time vendor sells tea. It is cold and quiet.") reveals the student cannot "show, not tell" — they lack the skill to construct atmosphere through sensory layering, only summarize.

## COMMON_MISCONCEPTION
Students believe "setting = where and when" and "atmosphere = mood," treating them as separate labels to identify rather than as constructed effects. They write: "The setting is evening street. The atmosphere is tense." This misses HOW the writer builds them: through specific word choices (कड़ककर vs मगन), spatial arrangements (standing vs sitting), sensory layering (smell + sound + sight), and temporal pressure (darkness approaching). The error stems from middle-school "identify the setting" worksheets that reward labeling over analysis. In Class 11 board exams, you must explain the *mechanism* — e.g., "The writer uses the encroaching darkness ('अंधेरा घिरने लगा') as a ticking clock that compresses the vendor's negotiating time, making लखपत's interrogation feel more predatory."

## ON_FAILURE
If the student cannot move beyond labeling, do this 3-step remediation: (1) Give them a 50-word setting description from the text with all atmospheric words removed (replace "कड़ककर" with "बोला," "थकी" with "पुरानी") — ask them to compare the flat version with the original and list what was lost. (2) Have them physically act out the tea stall scene: one student stands (लखपत), one sits on floor (उलहनी), one leans (जक्सी) — then discuss how body positions change the feeling of the dialogue. (3) Assign a micro-writing task: rewrite the opening paragraph changing ONLY the time to noon — what sensory details must change? What atmospheric effect is lost? This makes the constructive nature of setting/atmosphere visible.

## BUILDS_ON
c11_hin_ar_cbse_02_002 (Plot and Narrative Structure) — understanding the sequence of events lets you locate where setting shifts occur and how they pace the narrative.

## LEADS_TO
c11_hin_ar_cbse_02_004 (Character Analysis: Protagonist) — setting and atmosphere reveal उलहनी's character through his interaction with his environment.

## PREREQUISITE_NODE_IDS
c11_hin_ar_cbse_02_001, c11_hin_ar_cbse_02_002
## PREREQUISITE_REASONS
c11_hin_ar_cbse_02_001: Context and background knowledge about the author Ñ".kk lkscrh and the socio-cultural milieu of street vendors is essential to interpret setting details authentically.
c11_hin_ar_cbse_02_002: Plot structure knowledge helps identify where setting changes (scene breaks) and how atmosphere shifts at turning points (e.g., लखपत's entry).

## FORWARD_NODE_IDS
c11_hin_ar_cbse_02_004, c11_hin_ar_cbse_02_008, c11_hin_ar_cbse_02_013, c11_hin_ar_cbse_02_015, c12_hin_a_cbse_02_003, c12_hin_a_cbse_06_003, c12_hin_a_cbse_09_003, c12_hin_a_cbse_12_003, c12_hin_al_cbse_02_003, c12_hin_ar_cbse_01_003, c12_hin_ar_cbse_02_003

## FORWARD_REASONS
c11_hin_ar_cbse_02_004: Setting/atmosphere analysis provides the environmental context that shapes protagonist उलहनी's responses and dignity.
c11_hin_ar_cbse_02_008: Imagery and metaphor (node 008) are the primary tools the writer uses to construct atmosphere — this node prepares students to identify those devices.
c11_hin_ar_cbse_02_013: Critical thinking requires synthesizing setting, character, and theme — this node provides the setting/atmosphere analytical foundation.
c11_hin_ar_cbse_02_015: Setting/atmosphere (the professor's study vs. streetlight) supplies the spatial symbolism that fuels "where does real learning happen?" debates.  
c12_hin_a_cbse_02_003: Class 11 node on setting and atmosphere provides the foundational skill of identifying setting elements and sensory details.  
c12_hin_a_cbse_06_003: Reinforced practice with different texts builds pattern recognition  
c12_hin_a_cbse_09_003: Reinforces identification of Braj vocabulary for time/place, a recurring skill.  
c12_hin_a_cbse_12_003: Exposure to rural/urban setting contrasts in Class 11 Antra stories builds comparative framework  
c12_hin_al_cbse_02_003: Built foundational skill of marking sensory details in prose — this node deepens it to atmosphere analysis.  
c12_hin_ar_cbse_01_003: Practiced identifying atmosphere through imagery in a different poem (transfer practice).  
c12_hin_ar_cbse_02_003: Class 11 foundation of identifying setting/mood; this node advances from identification to mechanistic analysis.  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
none

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_02_001 -> c11_hin_ar_cbse_02_002 -> c11_hin_ar_cbse_02_003 -> c11_hin_ar_cbse_02_004 -> c11_hin_ar_cbse_02_013

## THIS_FORMULA
N/A - conceptual

## FORMULA_VARIABLES
N/A

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
analytical

## CROSS_SUBJECT
c11_history_colonialism | The street vendor's marginalized position in "फेरीवाले उलहनी" reflects colonial-era urban planning that pushed informal economies to city margins — setting as historical evidence.
c11_geography_urbanization | The "नुक्कड़ की चाय की दुकान" as a semi-public third place illustrates informal urban social infrastructure — setting as spatial sociology.
c11_economics_informal_sector | The vendor's time-pressure (selling before dark) mirrors the precarious economics of daily-wage informal labor — atmosphere as economic reality.

## PREREQ_CONCEPT
Ability to distinguish explicit textual details (stated directly) from implicit effects (created through word choice, arrangement, sensory layering).

## PREREQ_BEFORE
Student must have read the full story "फेरीवाले उलहनी" at least once and completed nodes 001 (context) and 002 (plot structure).

## PREREQ_STUCK
If stuck, re-read the opening two pages (pages 21-22 in NCERT) marking every word that appeals to the five senses — this builds the sensory inventory needed for atmosphere analysis.

## WORKED_EXAMPLE_1
PROBLEM: Analyze how the writer uses the progression of evening into night to structure the narrative tension in the first half of "फेरीवाले उलहनी." Write a PEEL paragraph.

STEPS:
- Step 1: Identify the time markers in sequence — "शाम" (para 1) → "अंधेरा घिरने लगा" (para 3) → "रात गहराने लगी" (para 5) → "पूरा अंधेरा" (para 7).
- Step 2: Map each marker to a narrative beat — शाम: vendor sets up routine; अंधेरा घिरने लगा: लखपत arrives; रात गहराने लगी: confrontation escalates; पूरा अंधेरा: vendor's forced departure.
- Step 3: Find atmospheric words at each stage — "मगन," "थकी पर स्पष्ट" → "कड़ककर," "तीखी" → "तनाव," "खामोशी" → "भारी," "निर्णायक."
- Step 4: Explain the mechanism — the natural light fade creates an irreversible deadline; the vendor cannot "buy time," making each interaction more urgent.
- Step 5: Connect to theme — the setting's temporal pressure mirrors the vendor's social precarity: both are forces he cannot control but must navigate with dignity.

REASONING: This 5-step process moves from evidence collection (steps 1-2) to pattern recognition (step 3) to causal explanation (step 4) to thematic synthesis (step 5) — the exact analytical ladder board exams reward.

ANSWER: The writer structures narrative tension through a precise evening-to-night progression that functions as an irreversible deadline. In paragraph 1, "शाम" establishes routine: the vendor is "मगन" (absorbed), his voice "थकी पर स्पष्ट" (tired but clear) — atmosphere: controlled dignity. By paragraph 3, "अंधेरा घिरने लगा" coincides with लखपत's entry ("कड़ककर पूछा"), shifting atmosphere to "तीखी" (sharp) confrontation. Paragraph 5's "रात गहराने लगी" parallels the escalating "तनाव" (tension) as लखपत demands identity papers. Finally, "पूरा अंधेरा" in paragraph 7 forces the vendor's departure under "भारी" (heavy) silence. This natural light fade is not backdrop but engine: it compresses the vendor's negotiating window, making लखपत's authority feel predatory. The setting thus embodies the theme — the vendor's dignity persists within constraints he didn't choose, just as he works within the day he cannot extend.

## WORKED_EXAMPLE_2
PROBLEM: The tea stall scene (pages 23-24) uses spatial arrangement to encode power dynamics. Analyze how the physical positioning of three characters — लखपत (standing), उलहनी (sitting on पटरी), जक्सी (leaning on दीवार) — creates atmosphere and reveals hierarchy. Use specific textual evidence.

STEPS:
- Step 1: Locate the spatial descriptors — "खड़ा था," "पटरी पर बैठा," "दीवार से टिका" — and note the vertical hierarchy: standing > leaning > sitting on ground.
- Step 2: Connect each position to character role — लखपत (authority/inspector) stands tall; उलहनी (vendor/subject) sits low; जक्सी (witness/mediator) leans — intermediate.
- Step 3: Analyze how the tea stall's physical features reinforce this — "काँच के जार" (display/barrier), "बेंच" (territory marker), "स्टोव की आँच" (heat center लखपत controls).
- Step 4: Explain atmospheric effect — the spatial rigidity creates a "courtroom" atmosphere without a court; the vendor's low position makes his calm responses ("जी, साहब") more powerful, not submissive.
- Step 5: Synthesize — the setting doesn't just host the scene; it *scripts* the power play. The vendor's refusal to stand when questioned ("बैठे-बैठे ही जवाब दिया") becomes an act of quiet resistance enabled by the spatial grammar.

REASONING: This example teaches spatial semantics — how physical arrangement in a setting functions as visual rhetoric. Steps 1-2 gather evidence, step 3 expands to environmental details, step 4 reads atmosphere from geometry, step 5 links to character agency.

ANSWER: The tea stall's spatial grammar encodes a three-tier hierarchy that the dialogue then performs. लखपत "खड़ा था" — vertical dominance of authority. उलहनी "पटरी पर बैठा" — grounded, vulnerable, yet his seated calm ("बैठे-बैठे ही जवाब दिया") refuses the hierarchy's demand for deference. जक्सी "दीवार से टिका" — peripheral witness, literally on the margins. The stall's material details amplify this: "काँच के जार" create transparent barriers (display without access), the "बेंच" is लखपत's territory (he occupies it), the "स्टोव की आँच" radiates from his side. Atmosphere: a makeshift tribunal where the architecture of the space — height, barriers, heat source — all favor the interrogator. Yet the vendor's atmospheric resistance comes from *not* moving: his seated stillness in the face of standing pressure creates a tension more powerful than if he'd stood. The setting thus reveals character: उलहनी's dignity is spatialized.

## WORKED_EXAMPLE_3
PROBLEM: Compare the atmosphere of the opening street scene (vendor alone, pages 21-22) with the closing scene (vendor leaving, pages 26-27). How does the writer use parallel and contrasting setting/atmosphere details to show what has changed and what hasn't for उलहनी? Write a structured comparative analysis.

STEPS:
- Step 1: Create a two-column evidence table. Opening: time "शाम," vendor "मगन," voice "स्पष्ट," crowd "आम," mood "नियमित." Closing: time "रात," vendor "चल पड़ा," voice "भारी," crowd "छँटी," mood "निर्णायक."
- Step 2: Identify parallels — same vendor, same street, same professional rhythm ("आवाज़ में वही स्पष्टता"), same dignity.
- Step 3: Identify contrasts — opening: autonomy ("अपनी धुन में"); closing: forced departure ("मजबूरी में"). Opening: potential customers; closing: only witnesses. Opening: light fading; closing: darkness total.
- Step 4: Analyze atmospheric shift — from "routine dignity" to "tested dignity." The atmosphere thickens: sensory details shift from "तेल-मसाले की गंध" (trade smells) to "धुएँ और ठंड" (hostile environment).
- Step 5: Explain the narrative function — the parallel structure proves the vendor's core self is unchanged; the contrasts show the world's hostility has intensified. The setting hasn't changed — the vendor's place in it has been forcibly clarified.
- Step 6: Connect to theme — the circular setting (same street) with linear atmospheric deterioration (calm → tension → expulsion) embodies the story's message: dignity is not granted by circumstances but maintained despite them.

REASONING: This 6-step comparative analysis models the highest-level board exam skill: tracking a motif (setting/atmosphere) across the full narrative arc, using parallel/contrast structure, and linking to theme. Steps 1-3 are evidence management; steps 4-6 are interpretation and synthesis.

ANSWER: The opening and closing street scenes form a deliberate atmospheric frame. Parallels: same "सड़क का किनारा," same vendor with "आवाज़ में वही स्पष्टता," same professional rhythm — proving उलहनी's essential dignity is intact. Contrasts: opening "शाम" with vendor "मगन" in "नियमित" routine; closing "रात" with vendor "मजबूरी में चल पड़ा" into "धुएँ और ठंड." Opening atmosphere: "तेल-मसाले की गंध" of trade, potential customers; closing: "छँटी हुई भीड़," only "गवाह" witnesses. The sensory shift from trade-smells to hostile "ठंड" and "धुआँ" marks the atmosphere's deterioration from routine to rupture. Yet the vendor's voice retains "स्पष्टता" — the atmosphere tests but doesn't break him. The circular setting (same street) with linear atmospheric decay (calm → tension → expulsion) enacts the theme: the world narrows around the marginalized, but their dignity is not the world's to give or take. The setting is constant; the vendor's negotiated space within it is what the story measures.

## COMPETENCY_QUESTION_1
QUESTION: In "फेरीवाले उलहनी," the writer never directly states "the atmosphere is tense." Instead, tension is built through three specific techniques: (a) temporal compression, (b) spatial hierarchy, (c) sensory contrast. Choose ONE technique and trace its operation across two distinct scenes, quoting exact words each time. Explain how the technique makes tension *felt* rather than *told*.

COMPETENCY: Textual evidence-based analysis of atmospheric construction techniques

STEPS:
- Step 1: Select one technique (e.g., sensory contrast) and define it in your own words for this story.
- Step 2: Locate Scene 1 (opening, pages 21-22) — find two contrasting sensory details (e.g., "तेल-मसाले की गंध" vs "ठंडी हवा").
- Step 3: Locate Scene 2 (tea stall confrontation, pages 23-24) — find two contrasting sensory details (e.g., "स्टोव की आँच" vs "कड़कती आवाज़").
- Step 4: Explain how each contrast creates micro-tension (comfort vs threat, routine vs disruption).
- Step 5: Conclude why "showing through sensory contrast" is more powerful than "telling: tension increased."

ANSWER: Technique: Sensory contrast. Scene 1 (opening): "तेल और मसालों की गंध" (warm, inviting, trade) contrasts with "ठंडी हवा का झोंका" (cold, indifferent, nature) — the vendor's warm labor meets the world's cold disregard. Scene 2 (tea stall): "स्टोव की आँच" (controlled heat, vendor's domain) contrasts with "लखपत की कड़कती आवाज़" (sharp, invasive sound) — physical warmth vs auditory aggression. In both scenes, the contrast is not described as "tense" — the reader *feels* the collision of opposing sensory vectors. This is more powerful than telling because it bypasses intellectual labeling and triggers embodied response: we sense the vendor's vulnerability before we analyze it. The technique makes atmosphere visceral, not verbal.

DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: A Class 11 student writes this exam answer: "The setting of 'फेरीवाले उलहनी' is a street in the evening. The atmosphere is sad and tense because the vendor is poor and the officer is rude." Identify THREE specific weaknesses in this answer using board exam marking criteria. Then rewrite the answer as a 4-sentence PEEL paragraph that would earn full marks.

COMPETENCY: Exam answer writing — evaluating and improving analytical responses

STEPS:
- Step 1: Identify Weakness 1 — "evening" is vague; no specific time markers (शाम/अंधेरा/रात progression).
- Step 2: Identify Weakness 2 — "sad and tense" labels atmosphere without evidence; no quoted words (कड़ककर, मगन, भारी).
- Step 3: Identify Weakness 3 — "poor/rude" reduces characters to labels; ignores how setting *constructs* their dynamic (spatial hierarchy, temporal pressure).
- Step 4: Write PEEL sentence 1 (Point): The writer constructs a deteriorating evening-to-night atmosphere that spatializes power and temporalizes vulnerability.
- Step 5: Write PEEL sentence 2 (Evidence): "अंधेरा घिरने लगा" coincides with लखपत's "कड़ककर पूछा," while उलहनी remains "पटरी पर बैठा" — vertical hierarchy encoded in space.
- Step 6: Write PEEL sentence 3 (Explanation): The encroaching darkness functions as an irreversible deadline that compresses the vendor's agency, making लखपत's standing interrogation feel predatory rather than procedural.
- Step 7: Write PEEL sentence 4 (Link): Thus setting and atmosphere are not background but the very mechanism through which dignity under pressure is dramatized.

ANSWER: Weaknesses: (1) Vague setting — no progression from शाम to पूरा अंधेरा; (2) Atmosphere labeled not analyzed — no textual words (कड़ककर, मगन, भारी) showing HOW tension is built; (3) Character reduction — "poor/rude" ignores spatial-temporal dynamics (standing/sitting, deadline pressure). Improved PEEL answer: The writer constructs a deteriorating evening-to-night atmosphere that spatializes power and temporalizes vulnerability. "अंधेरा घिरने लगा" coincides with लखपत's "कड़ककर पूछा," while उलहनी remains "पटरी पर बैठा" — vertical hierarchy encoded in space. The encroaching darkness functions as an irreversible deadline that compresses the vendor's agency, making लखपत's standing interrogation feel predatory rather than procedural. Thus setting and atmosphere are not background but the very mechanism through which dignity under pressure is dramatized.

DIFFICULTY: hard