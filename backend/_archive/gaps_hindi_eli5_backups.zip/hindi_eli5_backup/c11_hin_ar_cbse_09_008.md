## DEFINITION
Imagery (बिम्ब/प्रतिबिम्ब) is the use of vivid, sensory language that appeals to the five senses (sight, sound, smell, touch, taste) to create a concrete mental picture. Metaphor (रूपक/अन्योक्ति) is an implicit comparison between two unlike things without using comparative words (like, as), where one thing is described *as* the other to transfer qualities.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student must be able to independently identify specific images and metaphors in Dabir's poem, explain the sensory appeal of each image, articulate the tenor-vehicle relationship in each metaphor, and write a structured board-style answer linking these devices to the poem's central theme of divine love.

## SCOPE_BOUNDARY
This node covers only *imagery* (visual, auditory, tactile, olfactory, gustatory) and *metaphor* (standard, extended, implied) as they appear in the prescribed poem(s) of Chapter 9 (Dabir). It does NOT cover simile (उपमा), personification (मानवीकरण), irony (व्यंग्य), or symbolism (प्रतीकवाद) — those are in node c11_hin_ar_cbse_09_009. It does not cover other chapters or poets.

## WALKTHROUGH
Imagine you are listening to a friend describe a monsoon evening: "The air smells of wet earth, frogs chant in the ditch, and the sky is a bruised plum." You instantly *feel* that evening. That is imagery at work. Now, if your friend says, "My heart is a caged bird today," you understand sadness without them saying "I am sad" — that is metaphor. To begin analyzing Dabir's poem, first read it aloud *slowly* to catch the rhythm and sound. Second, underline every word that triggers a sense (e.g., 'dk"V' for touch, 'varfj' for sound). Third, circle any noun-phrase where A is called B directly (e.g., 'ck<+h dk"V gh dkVS'). Fourth, ask: "What quality of B is being transferred to A?" Finally, connect each device to the poem's core argument: the ineffable nature of the divine beloved.

## DIAGNOSTIC_QUESTION_1
Define 'imagery' (बिम्ब) and 'metaphor' (रूपक) in your own words, giving one original example for each (not from the textbook).

## DIAGNOSTIC_ANSWER_1
Imagery: Language appealing to senses (e.g., "The sizzling jalebi dripped golden syrup" — gustatory/tactile). Metaphor: Implicit comparison (e.g., "Time is a thief" — steals moments). A wrong answer (e.g., "Imagery is just description" or "Metaphor uses 'like'") reveals confusion between imagery and mere adjectives, or between metaphor and simile (उपमा).

## DIAGNOSTIC_QUESTION_2
In the poem, the line "tSls ck<+h dk"V gh dkVS vfxfu u dkVS dksbZ" appears. Explain why this is a metaphor and not a simile. What two things are being compared?

## DIAGNOSTIC_ANSWER_2
It is a metaphor because the beloved's body (tenor) is *directly equated* to a 'ck<+h dk"V' (vehicle — a sharp-edged sword) without 'like/as' (यथा/इव). The comparison transfers the sword's qualities: sharpness, danger, ability to pierce/cut. A wrong answer identifying it as simile (due to 'tSls') misses that 'tSls' here functions as 'just as/even as' introducing the *standard of comparison*, not a comparative particle for simile; the core assertion "gh dkVS" makes it a metaphor.

## DIAGNOSTIC_QUESTION_3
Identify ONE auditory image and ONE tactile image from the poem (describe the lines without quoting). Explain the specific sensation each evokes.

## DIAGNOSTIC_ANSWER_3
Auditory: The lines describing the beloved's speech/voice as 'varfj' (harsh/grating) evoke a jarring, painful sound — like metal on stone. Tactile: The 'ck<+h dk"V' (sharp sword) image evokes a stinging, cutting sensation on skin. A wrong answer citing visual images (e.g., "the beloved's form") shows the student cannot distinguish sensory modalities or locate non-visual imagery.

## DIAGNOSTIC_QUESTION_4
Compare the metaphor "ck<+h dk"V gh dkVS" with the implied metaphor in "ek;k nsf[k osQ txr yqHkkauka". How does the *vehicle* change across these two metaphors, and what does this shift reveal about the speaker's changing perception of the beloved?

## DIAGNOSTIC_ANSWER_4
First metaphor: Vehicle = 'sword' (external, violent, threatening). Second metaphor: Vehicle = 'fire/heat of the gaze' (internal, emanating from the beloved's eyes, transformative). The shift from weapon to elemental fire reveals the speaker's movement from fear of physical separation/pain to recognition of the beloved's gaze as a purifying, testing force — aligning with the Nirguna Bhakti idea of divine love as refining fire. A wrong answer treating both as "painful images" misses the theological progression from duality to intensity.

## DIAGNOSTIC_QUESTION_5
Critique the statement: "Dabir uses imagery only to decorate the poem; the metaphors are the real philosophical content." Defend or refute using evidence from the poem.

## DIAGNOSTIC_ANSWER_5
Refute. The olfactory/gustatory image "dksagjk lkauka" (bitter poison shared together) is not decoration — it *enacts* the central paradox: divine love is simultaneously poison (worldly suffering) and nectar (liberation), experienced *jointly* (lkauka). The imagery *is* the argument. A wrong answer agreeing reveals a hierarchical misconception that "figures of speech" are ornamental, not constitutive of meaning in Bhakti poetry.

## DIAGNOSTIC_QUESTION_6
Write a 4-line Hindi poem (any metre) on 'waiting for a friend' that uses at least two distinct sensory images and one metaphor. Do not use simile.

## DIAGNOSTIC_ANSWER_6
Example:
"राह तकती आँखें, धूल भरी हवा (visual/tactile),
घड़ी की टिक-टिक, दिल में शोर (auditory),
इंतज़ार एक सूखा कुआँ है (metaphor: waiting = dry well),
जिसमें बूँद की आस लिए बैठा हूँ।"
A poor answer using only visual images, or using "इंतज़ार *जैसे* सूखा कुआँ" (simile), shows inability to generate original metaphorical thinking or multi-sensory layering.

## COMMON_MISCONCEPTION
Students consistently confuse *metaphor* (रूपक) with *simile* (उपमा) in Hindi poetry because both compare. They see 'tSls' (like/as) in "tSls ck<+h dk"V gh dkVS" and instantly label it simile, ignoring that the *grammatical core* "gh dkVS" (is a sword) is an equation. They also restrict 'imagery' to visual descriptions (रूप वर्णन), missing auditory (varfj), tactile (dk"V), and gustatory (dksagjk) images that are central to Dabir's synesthetic style. This happens because Class 10 teaching often uses "identify the figure of speech" worksheets with clear-cut examples, not the ambiguous, layered usage of medieval saint-poets.

## ON_FAILURE
1. Give the student two columns: Column A — lines with 'like/as' (simile); Column B — lines where A *is* B (metaphor). Include Dabir's "tSls ck<+h dk"V gh dkVS" in Column B. Ask: "Where is the verb 'is' (घ/है)?" 2. Play an audio clip of a monsoon soundscape; ask them to list *only* non-visual sensations. Map each to a line in the poem. 3. Have them rewrite one metaphor as a simile ("The body is *like* a sword") and discuss what is lost (immediacy, identity). 4. Assign: Find one metaphor in a modern Hindi song (e.g., "Zindagi ek safar hai") and one in Dabir; compare directness.

## BUILDS_ON
Understanding the poem's literal narrative (node c11_hin_ar_cbse_09_002) and its primary theme of divine love as paradoxical union (node c11_hin_ar_cbse_09_006).

## LEADS_TO
Analysis of irony (virodhaabhaas) and symbolism (prateek) in the same poem (node c11_hin_ar_cbse_09_009), where the sword-image becomes a symbol of grace.

## PREREQUISITE_NODE_IDS
c11_hin_ar_cbse_09_001, c11_hin_ar_cbse_09_002, c11_hin_ar_cbse_09_006, c11_hin_ar_cbse_09_003, c11_hin_ar_cbse_09_007

## PREREQUISITE_REASONS
c11_hin_ar_cbse_09_001: Provides historical context of Nirguna Bhakti and Dabir's linguistic register (Sadhukkadi) essential for decoding metaphors.
c11_hin_ar_cbse_09_002: Establishes the poem's narrative situation (speaker addressing the beloved) without which the addressee of the metaphors is unclear.
c11_hin_ar_cbse_09_006: Supplies the thematic framework (divine love as destructive/creative) that gives the metaphors their philosophical weight.
c11_hin_ar_cbse_09_003: Imagery and metaphor are the primary tools that construct the atmosphere analyzed here; this node identifies the effects, the next node dissects the mechanisms.  
c11_hin_ar_cbse_09_007: Imagery analysis requires thematic mapping - each metaphor (knife, path, mirror) serves a specific secondary theme.  

## FORWARD_NODE_IDS
c11_hin_ar_cbse_09_009, c11_hin_ar_cbse_09_013, c11_hin_ar_cbse_09_012, c11_hin_ar_cbse_09_014, c12_hin_a_cbse_04_008, c12_hin_a_cbse_05_008, c12_hin_a_cbse_09_008, c12_hin_a_cbse_16_008, c12_hin_ar_cbse_09_003, c12_hin_ar_cbse_09_004, c12_hin_ar_cbse_09_008, c12_hin_ar_cbse_03_013, c12_hin_ar_cbse_09_005, c12_hin_ar_cbse_09_006, c11_hin_ar_cbse_09_015

## FORWARD_REASONS
c11_hin_ar_cbse_09_009: The sword/fire metaphors here become the *symbols* analyzed for irony (e.g., weapon as grace) in the next node.
c11_hin_ar_cbse_09_013: Critical interpretation requires the device-level evidence gathered here to build thematic arguments.
c11_hin_ar_cbse_09_012: Recognizing imagery (bubble, thorn) is essential to distinguish literal metaphors from inferred meanings.  
c11_hin_ar_cbse_09_014: Literary devices (Metaphor, Symbolism) are the analytical tools required for Explanation step.  
c12_hin_a_cbse_04_008: Visual imagery in "Premdasa" — contrast with "cukjl"’s multisensory approach.  
c12_hin_a_cbse_05_008: Shows how imagery creates tone in Class 11 poems.  
c12_hin_a_cbse_09_008: Provides foundational definitions and identification practice in accessible Khari Boli; without this, Class 12 Braj analysis is impossible.  
c12_hin_a_cbse_16_008: Teaches evidence-quoting format required for Board answers.  
c12_hin_ar_cbse_09_003: Imagery and metaphor identification skill — prerequisite for sensory clustering technique used here.  
c12_hin_ar_cbse_09_004: Class 11 imagery/metaphor analysis — provides the toolkit for decoding the persona's self-chosen metaphors.  
c12_hin_ar_cbse_09_008: Class 11 foundation on device identification and basic PEEL — this node assumes that fluency.  
c12_hin_ar_cbse_03_013: evisit Class 11 Chapter 8/9 Literary Devices nodes (c11_hin_ar_cbse_08_008, c11_hin_ar_cbse_08_009, c11_hin_ar_cbse_09_008, c11_hin_ar_cbse_09_009) and practice "device → effect → meaning" chains on isolated lines before full poems.  
c12_hin_ar_cbse_09_005: Review "personification vs. metaphor" distinction from Class 11 Literary Devices node c11_hin_ar_cbse_09_008 and protagonist analysis from c12_hin_ar_cbse_09_004.  
c12_hin_ar_cbse_09_006: If stuck, revisit "Literary Devices: Imagery and Metaphor" (c11_hin_ar_cbse_09_008) and practice mapping a metaphor's stages in a simpler poem.  
c11_hin_ar_cbse_09_015: Review the 'Literary Devices: Imagery and Metaphor' (c11_hin_ar_cbse_09_008) and 'Theme: Primary Theme' (c11_hin_ar_cbse_09_006) nodes to rebuild evidence-finding skills.  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
No prior class nodes available for cross-subject linking.

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_09_001 -> c11_hin_ar_cbse_09_008 -> c11_hin_ar_cbse_09_009

## THIS_FORMULA
N/A - conceptual

## FORMULA_VARIABLES
N/A

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
analytical

## CROSS_SUBJECT
c11_history_bhakti_movement | The metaphor of 'body as sword' reflects the Nirguna Sant tradition's use of bodily/violent imagery to describe spiritual transformation — a historical-literary intersection.
c11_geography_indian_monsoon | The olfactory image 'dksagjk' (bitter/poison) and tactile 'varfj' (harsh) echo the sensory experience of the pre-monsoon heat (Loo) in North India, grounding the poem's imagery in regional geography.

## PREREQ_CONCEPT
The student must grasp the Nirguna Bhakti concept of 'viraha' (separation) as a transformative fire, not merely sorrow.

## PREREQ_BEFORE
The student must have read the poem at least twice: once for literal meaning (using the word-meanings provided), once for sound/rhythm.

## PREREQ_STUCK
If stuck, re-read the 'Before You Read' section (node c11_hin_ar_cbse_09_001) focusing on Dabir's use of 'Sadhukkadi' language and the concept of 'prem' as a path of suffering.

## WORKED_EXAMPLE_1
PROBLEM: Analyze the visual and tactile imagery in the opening description of the beloved ("ge rkS ,d ,d dfj tkaukaA nksb dgSa frugha dkSa nkstx ftu ukfgau ifgpkaukaA") and explain how it prepares the reader for the central metaphor of the sword.

STEPS:
- Step 1: Identify the sensory words in the opening lines. 'dfj tkauka' (seeing/meeting) → visual; 'frugha dkSa' (fragrant body) → olfactory; 'nkstx' (unique/incomparable) → intellectual/abstract.
- Step 2: Classify each image by sense modality. Visual: the act of seeing the beloved. Olfactory: 'frugha' (fragrance) suggests divine perfume, traditionally associated with saints. Tactile: implied in 'dkSa' (body) as physical presence.
- Step 3: Note the *absence* of conventional beauty descriptors (no 'fair', 'lotus-eyed'). The imagery is minimal, austere, focusing on *presence* and *scent* — aligning with Nirguna rejection of form (roop).
- Step 4: Connect to the sword metaphor. The austerity of the opening imagery (no ornamentation) mirrors the 'ck<+h dk"V' (sharp sword) — both are stripped down, essential, dangerous. The fragrance 'frugha' contrasts with the later 'dksagjk' (bitter poison), setting up the sweet/bitter paradox.
- Step 5: Conclude: The opening imagery establishes the beloved as *transcendent yet sensorily real*, making the violent metaphor of the sword a logical intensification, not a contradiction.

REASONING: This step-by-step moves from sensory identification to thematic synthesis, modeling the board-exam requirement: "Quote → Device → Effect → Theme-link."

ANSWER: The opening uses sparse visual (meeting), olfactory (fragrant body), and implied tactile (body) imagery to present the beloved as formless-yet-present. This austerity prepares the reader for the sword metaphor by establishing a tone of raw, unadorned intensity where love is not decorative but cutting.

## WORKED_EXAMPLE_2
PROBLEM: The poem states "dksagjk lkauka" (bitter poison shared together). Identify the imagery type, the implicit metaphor, and explain how the compound word 'lkauka' (together) transforms the meaning.

STEPS:
- Step 1: Identify the primary imagery. 'dksagjk' (bitter/poison) → gustatory (taste) + olfactory (acrid smell). This is a concrete sensory image.
- Step 2: Detect the metaphor. 'Poison' (डसागजक) is the vehicle; 'the experience of divine love/separation' is the tenor. The beloved's love *is* poison — implicit metaphor.
- Step 3: Analyze the grammatical form. 'dksagjk' functions as an adjective/noun in apposition to the implied subject (love/experience).
- Step 4: Examine 'lkauka' (एक साथ / together). It is a compound adverb (लकु + आक). It shifts the agency: the poison is not *inflicted* by the beloved on the lover, nor *suffered alone*; it is *shared*.
- Step 5: Theological implication. In Nirguna Bhakti, the guru/disciple or devotee/divine share the 'poison' of worldly existence (samsara). The metaphor becomes mutual participation in suffering-as-liberation.
- Step 6: Board-answer formulation: "The gustatory image of 'डसागजक' (bitter poison) acts as a metaphor for the agony of divine love. The critical modifier 'लकौका' (together) converts a passive suffering into an active, joint ordeal, reflecting the Nirguna ideal of 'sahaja' — shared realization."

REASONING: This example demonstrates close reading of a single compound word ('lkauka') to unlock the metaphor's philosophical depth — a high-order skill for Class 11.

ANSWER: Gustatory/olfactory imagery ('डसागजक') carries an implicit metaphor: divine love = bitter poison. 'लकौका' (together) reconfigures the metaphor from unilateral punishment to bilateral participation, embodying the Nirguna tenet that liberation is co-experienced in the crucible of worldly pain.

## WORKED_EXAMPLE_3
PROBLEM: Compare the metaphorical structure of "ck<+h dk"V gh dkVS" (Stanza 1) and "ek;k nsf[k osQ txr yqHkkauka" (Stanza 2). Show how the shift in *vehicle* (sword → fire/gaze) advances the poem's argument about the nature of the divine.

STEPS:
- Step 1: Deconstruct Metaphor 1. Tenor: Beloved's body (dkSa). Vehicle: Sharp sword (ck<+h dk"V). Grounds of comparison: Sharpness, lethality, ability to sever. Tone: Threat, violence, externality.
- Step 2: Deconstruct Metaphor 2. Tenor: Beloved's gaze (nsf[k osQ txr). Vehicle: Fire/heat (yqHkkauka — that which burns). Grounds: Penetrating, purifying, internal, transformative. Tone: Intensity, testing, intimacy.
- Step 3: Trace the spatial shift. Sword is *external* (wielded *at* the lover). Gaze/fire is *emanating from* the beloved *into* the lover. The locus of agency moves from weapon to eyes.
- Step 4: Trace the temporal shift. Sword = instant cut (death/separation). Fire = sustained burning (tapasya/purification). Time expands from moment to process.
- Step 5: Link to Nirguna theology. Sword = 'maran' (death of ego) — sudden. Fire = 'tapas' (austerity) — gradual. Dabir encompasses both: the path requires the *threat* of ego-death (sword) and the *process* of purification (fire).
- Step 6: Synthesize for board answer. "The progression from 'खंडित खड्ग' (broken sword? No, sharp sword) to 'नयन की ताप' (heat of the gaze) maps the devotee's journey: initial terror at the beloved's destructive power → realization that the same power is a refining fire. The metaphorical vehicles are not random; they are staged theological milestones."

REASONING: This multi-step comparison requires holding two complex metaphors simultaneously, analyzing their components (tenor/vehicle/grounds), and mapping them onto a theological trajectory — exactly the "analyze" level expected in senior secondary.

ANSWER: Metaphor 1 (Body = Sharp Sword) presents divine love as external, lethal threat — the ego's fear of annihilation. Metaphor 2 (Gaze = Burning Fire) reconfigures that same power as internal, purifying intensity — the soul's acceptance of transformation. The shift from weapon to element, from instant cut to sustained burn, mirrors the Nirguna trajectory from 'virodh' (conflict) to 'sahaj' (natural union).

## COMPETENCY_QUESTION_1
QUESTION: "In Dabir's poem, the line 'lc ?kfV varfj rw¡gh O;kid /jS l:iS lksbZ' uses auditory imagery to convey a metaphysical claim. Identify the auditory image, state the implicit metaphor, and explain how the sound-quality ('varfj') encodes the poem's view of the Guru's word (shabda)."
COMPETENCY: Literary Analysis & Theological Interpretation
STEPS:
- Step 1: Locate the auditory image: 'varfj' (harsh, grating, discordant sound) describing the Guru's utterance/voice.
- Step 2: Identify the implicit metaphor: The Guru's word (shabda/upadesha) *is* a harsh, jarring sound (varfj) — not melodious, not comforting.
- Step 3: Explain the encoding: 'varfj' (वर्फज् — harsh/rough) contrasts with expected 'madhur' (sweet) spiritual discourse. It signifies that true *shabda* shatters complacency, like a discordant note breaking a melody.
- Step 4: Connect to Nirguna concept: The Guru's word is a 'sword' (previous metaphor) in sonic form — it cuts illusions. 'O;kid' (speaker/teacher) utters this 'varfj' sound to awaken, not to please.
ANSWER: The auditory image is 'varfj' (harsh/grating sound). The implicit metaphor: Guru's teaching = harsh sound. 'Varfj' encodes the Nirguna view that authentic *shabda* is deliberately unsettling — it does not soothe (like bhajan) but disrupts (like a alarm), functioning as the sonic equivalent of the 'sharp sword' to sever ignorance.
DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: "A student writes: 'Dabir's metaphors are violent (sword, fire, poison) because he was a weaver and knew physical pain.' Evaluate this biographical reading. Does it illuminate or reduce the poem? Support your judgment with two specific textual evidences from the metaphors analyzed in this node."
COMPETENCY: Critical Evaluation & Evidence-Based Argument
STEPS:
- Step 1: Acknowledge the biographical fact: Dabir was a weaver (julaha), familiar with physical labor and tools.
- Step 2: Test the claim against Metaphor 1 (sword). A weaver uses a shuttle, not a sword. The 'sword' is a *Kshatriya/renouncer* symbol, not a weaver's tool. The metaphor transcends biography.
- Step 3: Test against Metaphor 3 (poison shared together). 'डसागजक लकौका' implies a *mutual* metaphysical condition, not individual occupational hazard. The 'together' (लकौका) points to a universal spiritual pathology (samsara), not personal injury.
- Step 4: Evaluate: The biographical reading *reduces* the poem by collapsing theological symbols (sword of knowledge, fire of tapasya, poison of worldliness) into autobiographical anecdotes. It ignores the *intertextual* heritage: these are standard Nirguna motifs (found in Kabir, Gorakhnath).
- Step 5: Conclude: While biography informs the *register* (Sadhukkadi, loom imagery elsewhere), these specific metaphors operate at a doctrinal level that biography cannot explain.
ANSWER: The biographical reading reduces the poem. Evidence 1: The 'sword' (खड्ग) is a classical symbol of *jnana* (knowledge) in Sant tradition, not a weaver's implement. Evidence 2: 'डसागजक लकौका' (poison shared together) frames suffering as a *shared cosmic condition* (samsara), not an individual's occupational pain. The metaphors function doctrinally, not autobiographically.
DIFFICULTY: hard