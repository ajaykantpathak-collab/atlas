## DEFINITION
Writing Skills based on the chapter refers to the ability to compose structured, evidence-based responses — such as critical appreciation, thematic analysis, comparative evaluation, and inferential answers — that demonstrate deep engagement with the poems "olar vk;k" and "rksM+ks" by Kedarnath Singh, using textual evidence, literary devices, and contextual understanding.

## COGNITIVE_LEVEL
apply

## MASTERY_CRITERIA
The student can independently write a 150-200 word critical appreciation of either poem using the PEEL structure (Point, Evidence, Explanation, Link), embed at least two textual references with correct Hindi spelling, identify and explain the effect of two literary devices, and connect the poem's central idea to the broader theme of aging and memory — all within a 10-minute timed board-exam condition.

## SCOPE_BOUNDARY
This node covers writing structured answers for: (1) critical appreciation of "olar vk;k" and "rksM+ks", (2) thematic analysis of aging/decay/memory, (3) comparative analysis of the two poems, (4) character portrayal of the old woman and the poetic persona, (5) explanation of imagery/symbolism/irony with textual evidence. It does NOT cover creative writing (original poems), grammar exercises, or speaking/listening tasks (covered in node 015).

## WALKTHROUGH
Imagine you're in the exam hall, staring at a 6-mark question: "Critically appreciate the poem 'olar vk;k' with reference to the portrayal of old age." Your mind goes blank — you know the poem, but how do you *start*? Begin by reading the question twice and underlining keywords: "critically appreciate", "portrayal of old age". Next, recall the poem's three stanzas — the opening image of the old woman returning, the middle stanza with sensory details (sound of bangles, smell of earth), the closing philosophical turn. Now, structure your answer in four PEEL paragraphs: (1) Central idea — the poem captures the dignity and invisibility of old age. (2) Evidence — quote "veqd fnu veqd ckj enueghus dh gksosxh iapeh" and explain how repetition shows cyclical routine. (3) Device — identify the metaphor "ngj&ngj ngosaQxs dgha <kd osQ taxy" and analyze how it conveys frailty. (4) Link — connect to the poet's humanistic vision from the chapter introduction. The key insight: every sentence must earn marks by combining *textual proof* + *analysis* + *theme connection* — never just summary.

## DIAGNOSTIC_QUESTION_1
What is the first step you should take when a board exam question asks you to "critically appreciate" a poem from this chapter?

## DIAGNOSTIC_ANSWER_1
The first step is to deconstruct the question by underlining command words ("critically appreciate") and focus words ("portrayal of old age", "use of imagery") to determine exactly what the examiner wants — analysis with evidence, not summary. A wrong answer like "read the poem again" reveals the student doesn't understand that exam writing is a structured response to a specific prompt, not a memory dump.

## DIAGNOSTIC_QUESTION_2
In the poem "olar vk;k", the line "ngj&ngj ngosaQxs dgha <kd osQ taxy" uses a specific literary device. Identify the device and explain in one sentence how it contributes to the theme of aging.

## DIAGNOSTIC_ANSWER_2
The device is a metaphor (रूपक अलंकार) where "ngj&ngj ngosaQxs" (trembling footsteps) implicitly compares the old woman's walk to something fragile and unstable, conveying physical frailty and the loss of bodily control without stating it directly. A wrong answer like "it shows she walks slowly" reveals the student confuses *literal meaning* with *literary analysis* — they describe what happens but not *how the language creates meaning*.

## DIAGNOSTIC_QUESTION_3
A student writes this answer for a 4-mark question on "rksM+ks": "The poet repeats 'rksM+ks' many times to show he wants to break things. He breaks p^kusa, Ålj, catj. This shows anger." Rewrite this answer using the PEEL structure to make it board-exam ready.

## DIAGNOSTIC_ANSWER_3
**Improved PEEL answer:**  
**Point:** The repetition of "rksM+ks" (break) functions as a rhythmic incantation that transforms destruction into a ritual of liberation.  
**Evidence:** The refrain "rksM+ks rksM+ks rksM+ks" appears at the start of each stanza, followed by specific objects: ";s iRFkj ;s p^kuas" (this threshold, these doors), ";s Ålj catj" (this yard, this wall).  
**Explanation:** The anaphora creates a hammering rhythm that mirrors the physical act of breaking, while the progression from threshold → yard → heart (implied in "eu dh [kht") shows the demolition moving from external structures to internal barriers.  
**Link:** This reflects the poem's central theme — that true freedom for the elderly requires dismantling not just physical spaces but the emotional dependencies ("eu osQ Hkhrj dh Åc") that confine them.  
A weak rewrite that just adds adjectives reveals the student thinks "better vocabulary" equals "analysis" — they miss that PEEL requires *logical scaffolding*, not decoration.

## DIAGNOSTIC_QUESTION_4
Compare how "olar vk;k" and "rksM+ks" use sound devices (repetition, onomatopoeia, rhythm) to convey the experience of aging. Give one specific example from each poem.

## DIAGNOSTIC_ANSWER_4
In "olar vk;k", the repetition "veqd fnu veqd ckj" (day after day, again and again) creates a monotonous, cyclical rhythm that mirrors the old woman's unchanging routine — the sound *enacts* the tedium of aging. In "rksM+ks", the triple repetition "rksM+ks rksM+ks rksM+ks" acts like a percussive chant, its harsh plosives (k, M+) mimicking the violence of breaking — the sound *enacts* rebellion. A wrong answer that only lists "both use repetition" reveals the student cannot distinguish *how the same device functions differently* in different thematic contexts — a key comparative skill.

## DIAGNOSTIC_QUESTION_5
A classmate argues: "The poem 'rksM+ks' is just about an old man breaking his house — it's destructive and negative." Evaluate this interpretation using evidence from the text and the chapter's introductory note on Kedarnath Singh's poetic philosophy.

## DIAGNOSTIC_ANSWER_5
The interpretation is reductive and incorrect. The chapter introduction states Singh's poetry engages in "creative and analytical construction of life's contradictions" (थाउह के विरोधों की रचनात्मक और विश्लेषणात्मक रचना). In the poem, breaking "iRFkj" (threshold), "Ålj" (yard), "catj" (wall) and finally "eu dh [kht" (heart's wall) symbolizes dismantling *false securities* — the physical and emotional enclosures that isolate the elderly. The line "fe^h esa jl gksxk gh tc og ikslsxh cht dks / ge bldks D;k dj Mkysa bl vius eu dh [kht dks" implies the heart's wall *must* be broken for connection ("jl" = water/life) to enter. A student who agrees with the classmate reveals they read only the *surface action* and ignore the *symbolic logic* — a fatal error in literary analysis.

## DIAGNOSTIC_QUESTION_6
Write a 3-sentence "examiner's comment" for a 6-mark answer that: (a) correctly identifies the central theme of "olar vk;k" as "the invisibility of the elderly in modern society", (b) quotes "fujis{k cus jgrs gSa" but does not explain the metaphor, and (c) ends with a personal opinion ("I feel sad for old people") instead of a textual link.

## DIAGNOSTIC_ANSWER_6
**Examiner's comment:** "The answer correctly identifies the theme and selects relevant evidence, earning 2/6 for knowledge. However, the metaphor 'fujis{k cus jgrs gSa' (we keep getting wiped/erased) is quoted without unpacking how the passive verb form and domestic imagery (dusting/wiping) convey systemic erasure — losing 2 marks for analysis. The final personal opinion replaces the required textual-thematic synthesis, losing the last 2 marks. To improve: replace opinion with a link to the poet's humanistic concern for 'thoukuqHkoksa' (existential contradictions) as stated in the chapter intro." A student who writes "good try" as feedback reveals they confuse *encouragement* with *diagnostic assessment* — they cannot identify *which specific skill gaps* cost marks.

## COMMON_MISCONCEPTION
Students believe that "writing skills based on the chapter" means memorizing 2-3 model answers for likely questions. They prepare rote paragraphs on "theme of old age" or "use of imagery" and reproduce them regardless of the actual question. This fails because CBSE board exams (and CUET) now frame questions with specific constraints: "with reference to the last stanza", "contrast the tone of the two poems", "how does the poet use domestic objects as symbols?" A memorized answer on "imagery in general" scores 0/6 for a question asking specifically about *domestic objects as symbols in the last stanza*. The error stems from treating literature as *content to recall* rather than *skills to apply* — they don't realize the exam tests *adaptive analytical writing*, not memory.

## ON_FAILURE
1. **Diagnose the gap:** Ask the student to attempt a fresh 6-mark question *without notes* in 10 minutes. Collect the answer.  
2. **Mark against PEEL rubric:** Highlight each sentence as P, E, E, or L. Count how many paragraphs have all four.  
3. **Targeted remediation:**  
   - If missing **Point**: Practice writing one-sentence thesis statements for 5 past paper questions (node c12_hin_a_cbse_05_012).  
   - If missing **Evidence**: Drill "quote hunting" — give 3 themes, student finds 2 exact lines per theme from the poem (use node c12_hin_a_cbse_05_002 for narrative structure).  
   - If missing **Explanation**: Use the "So what?" ladder — for each quote, ask "So what does this show?" 3 times until reaching theme (node c12_hin_a_cbse_05_013).  
   - If missing **Link**: Practice "zoom out" sentences connecting poem to chapter intro / poet's philosophy (node c12_hin_a_cbse_05_001).  
4. **Re-diagnostic:** After 3 focused sessions, re-attempt a *different* 6-mark question under timed conditions. Score must improve by ≥2 marks.

## BUILDS_ON
This node builds on the ability to extract and interpret textual evidence (nodes 002-013) by teaching how to structure that evidence into exam-ready analytical writing.

## LEADS_TO
This node enables the Speaking and Listening node (c12_hin_a_cbse_05_015) where students must articulate the same analytical insights orally in discussion and presentation formats.

## PREREQUISITE_NODE_IDS
c12_hin_a_cbse_05_001, c12_hin_a_cbse_05_002, c12_hin_a_cbse_05_003, c12_hin_a_cbse_05_004, c12_hin_a_cbse_05_005, c12_hin_a_cbse_05_006, c12_hin_a_cbse_05_007, c12_hin_a_cbse_05_008, c12_hin_a_cbse_05_009, c12_hin_a_cbse_05_010, c12_hin_a_cbse_05_011, c12_hin_a_cbse_05_012, c12_hin_a_cbse_05_013, c11_hin_ar_cbse_01_014, c11_hin_ar_cbse_02_014, c11_hin_ar_cbse_03_014, c11_hin_ar_cbse_04_014, c11_hin_ar_cbse_05_014, c11_hin_ar_cbse_06_014, c11_hin_ar_cbse_07_014, c11_hin_ar_cbse_08_014, c11_hin_ar_cbse_10_014, c11_hin_ar_cbse_11_014, c11_hin_ar_cbse_12_014, c11_hin_ar_cbse_13_014, c11_hin_ar_cbse_14_014, c11_hin_ar_cbse_15_014, c11_hin_ar_cbse_16_014, c11_hin_v_cbse_01_014, c11_hin_v_cbse_02_014, c11_hin_v_cbse_03_014, c11_hin_v_cbse_04_014, c11_hin_v_cbse_05_014

## PREREQUISITE_REASONS
c12_hin_a_cbse_05_001: Provides context on Kedarnath Singh's philosophy — essential for the "Link" step in PEEL.  
c12_hin_a_cbse_05_002: Narrative structure of poems (stanza progression) — needed to organize evidence chronologically.  
c12_hin_a_cbse_05_003: Setting/atmosphere analysis — supplies evidence for "domestic space as symbol" answers.  
c12_hin_a_cbse_05_004: Protagonist analysis (old woman / poetic persona) — basis for character portrayal answers.  
c12_hin_a_cbse_05_005: Supporting characters (implied family/society) — evidence for "invisibility" theme.  
c12_hin_a_cbse_05_006: Primary theme (aging/decay/memory) — the central "Point" for most answers.  
c12_hin_a_cbse_05_007: Secondary themes (ritual, liberation, human connection) — for nuanced "Link" sentences.  
c12_hin_a_cbse_05_008: Imagery/metaphor identification — supplies the "Evidence" and "Explanation" for device analysis.  
c12_hin_a_cbse_05_009: Irony/symbolism — needed for higher-order analysis questions (e.g., "irony of care").  
c12_hin_a_cbse_05_010: Key vocabulary (e.g., oqQÅduk, pqjeqjk, r#oj) — ensures accurate quoting in Hindi.  
c12_hin_a_cbse_05_011: Grammar/language usage — enables correct Hindi sentence construction in answers.  
c12_hin_a_cbse_05_012: Literal/inferential comprehension — the foundation for reading the question correctly.  
c12_hin_a_cbse_05_013: Critical thinking/interpretation — the analytical engine for the "Explanation" step.  
c11_hin_ar_cbse_01_014 through c11_hin_v_cbse_05_014: Class 11 Writing Skills nodes — established PEEL structure, evidence embedding, and answer architecture; this node advances them to competitive-exam depth.
c11_hin_ar_cbse_01_014: Writing skills based on the chapter "इजसेपन" refers to the ability to compose structured,... की समझ आवश्यक है, क्योंकि यह नोड (Writing Skills based on the chapter refers to the ability to compose structured, evidence-...) इसी आधार पर आगे बढ़ता है।  
c11_hin_ar_cbse_02_014: Writing Skills based on the chapter "vejdkar" refers to the ability to construct structure... की समझ आवश्यक है, क्योंकि यह नोड (Writing Skills based on the chapter refers to the ability to compose structured, evidence-...) इसी आधार पर आगे बढ़ता है।  
c11_hin_ar_cbse_03_014: Writing skills based on a literary chapter refer to the ability to compose structured, evi... की समझ आवश्यक है, क्योंकि यह नोड (Writing Skills based on the chapter refers to the ability to compose structured, evidence-...) इसी आधार पर आगे बढ़ता है।  
c11_hin_ar_cbse_04_014: Writing skills based on the chapter "फोकलोर के फूल" (Folklore ke Phool) refer to the abili... की समझ आवश्यक है, क्योंकि यह नोड (Writing Skills based on the chapter refers to the ability to compose structured, evidence-...) इसी आधार पर आगे बढ़ता है।  
c11_hin_ar_cbse_05_014: Writing Skills based on the chapter refers to the ability to compose structured, evidence-... की समझ आवश्यक है, क्योंकि यह नोड (Writing Skills based on the chapter refers to the ability to compose structured, evidence-...) इसी आधार पर आगे बढ़ता है।  
c11_hin_ar_cbse_06_014: Writing skills based on the chapter refer to the ability to compose structured written res... की समझ आवश्यक है, क्योंकि यह नोड (Writing Skills based on the chapter refers to the ability to compose structured, evidence-...) इसी आधार पर आगे बढ़ता है।  
c11_hin_ar_cbse_07_014: Writing skills based on a literary chapter involve the ability to construct structured, ev... की समझ आवश्यक है, क्योंकि यह नोड (Writing Skills based on the chapter refers to the ability to compose structured, evidence-...) इसी आधार पर आगे बढ़ता है।  
c11_hin_ar_cbse_08_014: Writing Skills: की समझ आवश्यक है, क्योंकि यह नोड (Writing Skills based on the chapter refers to the ability to compose structured, evidence-...) इसी आधार पर आगे बढ़ता है।  
c11_hin_ar_cbse_10_014: Writing skills based on the chapter "Meera Ke Pad" refers to the ability to compose struct... की समझ आवश्यक है, क्योंकि यह नोड (Writing Skills based on the chapter refers to the ability to compose structured, evidence-...) इसी आधार पर आगे बढ़ता है।  
c11_hin_ar_cbse_11_014: Writing Skills based on the chapter refers to the ability to compose structured, evidence-... की समझ आवश्यक है, क्योंकि यह नोड (Writing Skills based on the chapter refers to the ability to compose structured, evidence-...) इसी आधार पर आगे बढ़ता है।  
c11_hin_ar_cbse_12_014: Writing skills based on the chapter refer to the ability to compose structured, evidence-b... की समझ आवश्यक है, क्योंकि यह नोड (Writing Skills based on the chapter refers to the ability to compose structured, evidence-...) इसी आधार पर आगे बढ़ता है।  
c11_hin_ar_cbse_13_014: Writing skills based on the chapter "lk;s esa /wi" refers to the ability to construct stru... की समझ आवश्यक है, क्योंकि यह नोड (Writing Skills based on the chapter refers to the ability to compose structured, evidence-...) इसी आधार पर आगे बढ़ता है।  
c11_hin_ar_cbse_14_014: Writing skills based on the chapter refer to the ability to construct structured, evidence... की समझ आवश्यक है, क्योंकि यह नोड (Writing Skills based on the chapter refers to the ability to compose structured, evidence-...) इसी आधार पर आगे बढ़ता है।  
c11_hin_ar_cbse_15_014: Writing skills based on the chapter refer to the ability to compose structured, evidence-b... की समझ आवश्यक है, क्योंकि यह नोड (Writing Skills based on the chapter refers to the ability to compose structured, evidence-...) इसी आधार पर आगे बढ़ता है।  
c11_hin_ar_cbse_16_014: Writing Skills based on the chapter refers to the ability to construct structured, evidenc... की समझ आवश्यक है, क्योंकि यह नोड (Writing Skills based on the chapter refers to the ability to compose structured, evidence-...) इसी आधार पर आगे बढ़ता है।  
c11_hin_v_cbse_01_014: Writing Skills based on the chapter refers to the ability to compose structured, evidence-... की समझ आवश्यक है, क्योंकि यह नोड (Writing Skills based on the chapter refers to the ability to compose structured, evidence-...) इसी आधार पर आगे बढ़ता है।  
c11_hin_v_cbse_02_014: Writing skills based on Chapter 2 ("जक्तLFkku dh jtr cw¡nas") refer to the ability to comp... की समझ आवश्यक है, क्योंकि यह नोड (Writing Skills based on the chapter refers to the ability to compose structured, evidence-...) इसी आधार पर आगे बढ़ता है।  
c11_hin_v_cbse_03_014: Writing skills based on a literary chapter involve the ability to compose structured, evid... की समझ आवश्यक है, क्योंकि यह नोड (Writing Skills based on the chapter refers to the ability to compose structured, evidence-...) इसी आधार पर आगे बढ़ता है।  
c11_hin_v_cbse_04_014: Writing skills based on the chapter "Hkkjrh; की समझ आवश्यक है, क्योंकि यह नोड (Writing Skills based on the chapter refers to the ability to compose structured, evidence-...) इसी आधार पर आगे बढ़ता है।  
c11_hin_v_cbse_05_014: Writing Skills based on the chapter refers to the ability to construct coherent, evidence-... की समझ आवश्यक है, क्योंकि यह नोड (Writing Skills based on the chapter refers to the ability to compose structured, evidence-...) इसी आधार पर आगे बढ़ता है।  

## FORWARD_NODE_IDS


## FORWARD_REASONS


## CROSS_SUBJECT_PREREQS
c11_hin_ar_cbse_01_014, c11_hin_ar_cbse_02_014, c11_hin_ar_cbse_03_014, c11_hin_ar_cbse_04_014, c11_hin_ar_cbse_05_014, c11_hin_ar_cbse_06_014, c11_hin_ar_cbse_07_014, c11_hin_ar_cbse_08_014, c11_hin_ar_cbse_09_014, c11_hin_ar_cbse_10_014, c11_hin_ar_cbse_11_014, c11_hin_ar_cbse_12_014, c11_hin_ar_cbse_13_014, c11_hin_ar_cbse_14_014, c11_hin_ar_cbse_15_014, c11_hin_ar_cbse_16_014, c11_hin_v_cbse_01_014, c11_hin_v_cbse_02_014, c11_hin_v_cbse_03_014, c11_hin_v_cbse_04_014, c11_hin_v_cbse_05_014
## CROSS_SUBJECT_REASONS
c11_hin_ar_cbse_01_014 through c11_hin_v_cbse_05_014: All Class 11 Hindi (Antra and Vitan) Writing Skills nodes established the foundational PEEL framework, evidence-based writing, and answer structuring that this Class 12 node deepens for board + competitive exam rigor.
c11_hin_ar_cbse_01_014: अन्य विषय की सहायता: Writing skills based on the chapter "इजसेपन" refers to the ability to compose structured,... के तत्व इस नोड में प्रयुक्त होते हैं।  
c11_hin_ar_cbse_02_014: अन्य विषय की सहायता: Writing Skills based on the chapter "vejdkar" refers to the ability to construct structure... के तत्व इस नोड में प्रयुक्त होते हैं।  
c11_hin_ar_cbse_03_014: अन्य विषय की सहायता: Writing skills based on a literary chapter refer to the ability to compose structured, evi... के तत्व इस नोड में प्रयुक्त होते हैं।  
c11_hin_ar_cbse_04_014: अन्य विषय की सहायता: Writing skills based on the chapter "फोकलोर के फूल" (Folklore ke Phool) refer to the abili... के तत्व इस नोड में प्रयुक्त होते हैं।  
c11_hin_ar_cbse_05_014: अन्य विषय की सहायता: Writing Skills based on the chapter refers to the ability to compose structured, evidence-... के तत्व इस नोड में प्रयुक्त होते हैं।  
c11_hin_ar_cbse_06_014: अन्य विषय की सहायता: Writing skills based on the chapter refer to the ability to compose structured written res... के तत्व इस नोड में प्रयुक्त होते हैं।  
c11_hin_ar_cbse_07_014: अन्य विषय की सहायता: Writing skills based on a literary chapter involve the ability to construct structured, ev... के तत्व इस नोड में प्रयुक्त होते हैं।  
c11_hin_ar_cbse_08_014: अन्य विषय की सहायता: Writing Skills: के तत्व इस नोड में प्रयुक्त होते हैं।  
c11_hin_ar_cbse_09_014: अन्य विषय की सहायता: Writing Skills: के तत्व इस नोड में प्रयुक्त होते हैं।  
c11_hin_ar_cbse_10_014: अन्य विषय की सहायता: Writing skills based on the chapter "Meera Ke Pad" refers to the ability to compose struct... के तत्व इस नोड में प्रयुक्त होते हैं।  
c11_hin_ar_cbse_11_014: अन्य विषय की सहायता: Writing Skills based on the chapter refers to the ability to compose structured, evidence-... के तत्व इस नोड में प्रयुक्त होते हैं।  
c11_hin_ar_cbse_12_014: अन्य विषय की सहायता: Writing skills based on the chapter refer to the ability to compose structured, evidence-b... के तत्व इस नोड में प्रयुक्त होते हैं।  
c11_hin_ar_cbse_13_014: अन्य विषय की सहायता: Writing skills based on the chapter "lk;s esa /wi" refers to the ability to construct stru... के तत्व इस नोड में प्रयुक्त होते हैं।  
c11_hin_ar_cbse_14_014: अन्य विषय की सहायता: Writing skills based on the chapter refer to the ability to construct structured, evidence... के तत्व इस नोड में प्रयुक्त होते हैं।  
c11_hin_ar_cbse_15_014: अन्य विषय की सहायता: Writing skills based on the chapter refer to the ability to compose structured, evidence-b... के तत्व इस नोड में प्रयुक्त होते हैं।  
c11_hin_ar_cbse_16_014: अन्य विषय की सहायता: Writing Skills based on the chapter refers to the ability to construct structured, evidenc... के तत्व इस नोड में प्रयुक्त होते हैं।  
c11_hin_v_cbse_01_014: अन्य विषय की सहायता: Writing Skills based on the chapter refers to the ability to compose structured, evidence-... के तत्व इस नोड में प्रयुक्त होते हैं।  
c11_hin_v_cbse_02_014: अन्य विषय की सहायता: Writing skills based on Chapter 2 ("जक्तLFkku dh jtr cw¡nas") refer to the ability to comp... के तत्व इस नोड में प्रयुक्त होते हैं।  
c11_hin_v_cbse_03_014: अन्य विषय की सहायता: Writing skills based on a literary chapter involve the ability to compose structured, evid... के तत्व इस नोड में प्रयुक्त होते हैं।  
c11_hin_v_cbse_04_014: अन्य विषय की सहायता: Writing skills based on the chapter "Hkkjrh; के तत्व इस नोड में प्रयुक्त होते हैं।  
c11_hin_v_cbse_05_014: अन्य विषय की सहायता: Writing Skills based on the chapter refers to the ability to construct coherent, evidence-... के तत्व इस नोड में प्रयुक्त होते हैं।  

## CHAIN_DESCRIPTION
c12_hin_a_cbse_05_013 -> c12_hin_a_cbse_05_014 -> c12_hin_a_cbse_05_015

## THIS_FORMULA
PEEL Structure for Literature Answers:  
**P** = Point (1 sentence: direct answer to question + thesis)  
**E** = Evidence (1-2 exact textual references with correct Hindi spelling)  
**E** = Explanation (2-3 sentences: how evidence proves point via device/technique)  
**L** = Link (1 sentence: connects to theme / poet's philosophy / broader context)

## FORMULA_VARIABLES
P = Thesis statement tailored to the specific question prompt  
E = Quoted line/phrase from poem (Devanagari script, accurate spelling)  
E = Analysis of literary device, diction, sound, structure, or imagery  
L = Connection to central theme, chapter introduction, or comparative insight

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
linguistic

## CROSS_SUBJECT
N/A | The theme of "invisibility of the elderly" in Kedarnath Singh's poems parallels the historical marginalization of senior citizens in post-colonial Indian social policy — both require evidence-based argumentation linking micro-narratives to macro-structures.  
 N/A | The poem "rksM+ks" depicts breaking psychological barriers ("eu dh [kht") in late adulthood, directly illustrating Erikson's stage of "Integrity vs. Despair" — literary analysis here applies developmental psychology concepts to textual evidence.
## PREREQ_CONCEPT
Evidence-based analytical writing using the PEEL paragraph structure, developed across Class 11 Hindi Writing Skills nodes.

## PREREQ_BEFORE
Student must be able to: (1) locate exact textual evidence for a given theme, (2) name and define at least 5 literary devices from the chapter, (3) write a coherent paragraph in formal Hindi.

## PREREQ_STUCK
If stuck, revisit **c12_hin_a_cbse_05_013 (Critical Thinking)** for interpretation practice and **c11_hin_ar_cbse_01_014 (Class 11 Writing Skills)** for PEEL refresher — do not reread the poem; practice *writing about it*.

## WORKED_EXAMPLE_1
PROBLEM: Write a 150-word critical appreciation of the poem "olar vk;k" focusing on how the poet uses sensory imagery to portray the old woman's routine.  
STEPS:
- Step 1: Analyze the prompt — keywords: "critical appreciation", "sensory imagery", "old woman's routine" — this demands PEEL paragraphs on specific senses (sound, smell, sight, touch).
- Step 2: Scan the poem for sensory clusters — Stanza 1: sound ("pqjeqjk, ik¡o rys / m¡Qps rjQoj ls fxjs"), smell ("f[kyh gqbZ gok vkbZ] fiQjdh&lh vkbZ"), touch ("cM+s&cM+s fi;jk, iÙks"). Stanza 2: sight ("jax&jl&xaèk ls yns&i¡Qns"), sound ("nÝ+rj esa Nq^h Fkh"), memory ("dfork,¡ i<+rs jgus").
- Step 3: Draft Point sentences for 3 PEEL paragraphs: (P1) Auditory imagery establishes the rhythm of her return. (P2) Olfactory/tactile imagery grounds her in domestic labor. (P3) Visual/memory imagery reveals her inner world.
- Step 4: Embed Evidence with Explanation: For P1, quote "pqjeqjk, ik¡o rys" — the onomatopoeic "pqjeqjk" (tinkling) and "m¡Qps" (jingling) mimic bangles/anklets, the sound *announcing* her presence before she's seen. For P2, quote "f[kyh gqbZ gok vkbZ] fiQjdh&lh vkbZ" — the compound adjectives "fiQjdh&lh" (freshly smeared) evoke the smell of cow-dung plaster, symbolizing her role as sustainer of the household hearth. For P3, quote "jax&jl&xaèk ls yns&i¡Qns nwj osQ fons'k" — the synesthesia (color → fountain) transforms memory into a living spring.
- Step 5: Craft Link sentences connecting each to the central theme: The sensory details collectively resist her invisibility — each image forces the reader to *witness* what society ignores ("fujis{k cus jgrs gSa").
REASONING: This works because each paragraph follows PEEL, uses exact textual evidence, analyzes *how* the device functions (not just what it is), and links to the theme — exactly what the CBSE marking scheme rewards.
ANSWER:  
केदारनाथ सिंह की कविता 'ओलर वक;क' में वृद्धा की दिनचर्या को संवेदनात्मक बिंबों के माध्यम से इस तरह उकेरा गया है कि उसकी अदृश्यता टूटती है। श्रव्य बिंब — "पजेकिक, इकिओ रिस / मेइपस रजक्वोज लस फजस" — उसकी उपस्थिति की घोषणा करते हैं: पाजेब की झनकार और घुंघरू की रुनझुन उसकी अनदेखी चाल को श्रव्य बनाते हैं। घ्राण और स्पर्श बिंब — "फक्यह गकबज गोक वकबज] फिकजध-लह वकबज" — गोबर से लीपे आँगन की गंध और ताजे लेप की शीतलता उसके घरेलू श्रम को मूर्त करते हैं। दृश्य-स्मृति बिंब — "जक्स-जल-क्षेक लस यनस-इक्वंस नवे उस फोंसक" — रंगों से फूटते स्रोत के रूपक में उसकी स्मृतियों को जीवंत जलस्रोत बना देते हैं। ये बिंब मिलकर उस वृद्धा को 'फुजिसक उस जग्रस गस' (मिटती हुई) नहीं, बल्कि एक सजीव, स्रष्टा उपस्थिति के रूप में स्थापित करते हैं — यही कवि का मानवीय प्रतिरोध है।

## WORKED_EXAMPLE_2
PROBLEM: "Compare the tone of the two poems 'olar vk;k' and 'rksM+ks'." Write a 100-word comparative answer.  
STEPS:
- Step 1: Define "tone" for comparison — attitude of the poetic voice toward the subject (old age). Identify tonal keywords: "olar vk;k" = observant, elegiac, dignified, melancholic; "rksM+ks" = imperative, rebellious, urgent, liberatory.
- Step 2: Select contrasting evidence — "olar": "fujis{k cus jgrs gSa" (passive erosion), "veqd fnu veqd ckj" (cyclical resignation). "rksM+ks": "rksM+ks rksM+ks rksM+ks" (active command), "xksM+ks xksM+ks xksM+ks" (final release).
- Step 3: Structure as a comparative PEEL — single paragraph with alternating points (not two separate summaries). Use connectives: "whereas", "in contrast", "while".
- Step 4: Draft: Point — The poems present complementary tonal poles of aging: witness vs. rebellion. Evidence/Explanation — "olar vk;k" adopts an elegiac witness-tone: "fujis{k cus jgrs gSa" (we keep getting erased) uses passive voice and domestic metaphor (dusting/wiping) to convey quiet erasure. In contrast, "rksM+ks" erupts in imperative rebellion: the anaphoric "rksM+ks rksM+ks rksM+ks" transforms breaking into a sacred chant, shifting from threshold ("iRFkj") to heart ("eu dh [kht"). Link — Together they map the dialectic of aging: the first poem *documents* the condition, the second *prescribes* its transcendence.
- Step 5: Verify word count (~100), Hindi terminology (कातर vs विद्रोही स्वर), and board-marking alignment (comparative analysis = 4+ marks).
REASONING: Comparative answers fail when students write two separate summaries. This method forces *synthesis* in every sentence — the examiner sees "comparison" not "description".
ANSWER:  
दोनों कविताएँ वृद्धावस्था के दो पूरक स्वर प्रस्तुत करती हैं: 'ओलर वक;क' में कातर साक्षी-भाव है, 'रकसकस' में विद्रोही मुक्ति-आदेश। 'ओलर' का स्वर विलापात्मक है — "फुजिसक उस जग्रस गस" (निष्क्रिय वाच्य, घरेलू रूपक) चुपचाप मिटते जाने को दर्ज करता है; "वेकद फनु वेकद कज" चक्रीय नियति की स्वीकृति ध्वनित करता है। इसके विपरीत 'रकसकस' आदेशात्मक विद्रोह है — "रकसकस रकसकस रकसकस" की अनुप्रासात्मक पुनरावृत्ति तोड़ने को पवित्र मंत्र बना देती है; "इरफकज" (देहरी) से "यू धा खट" (हृदय-दीवार) तक की यात्रा बाह्य से आंतरिक मुक्ति का मार्ग है। साथ में वे वृद्धावस्था की द्वंद्वात्मकता रचते हैं: पहली *दस्तावेज़* करती है, दूसरी *निर्देश* देती है।

## WORKED_EXAMPLE_3
PROBLEM: A 6-mark board question: "How does Kedarnath Singh use domestic objects (threshold, yard, wall, bangles, cow-dung plaster) as symbols in the two poems? Explain with examples."  
STEPS:
- Step 1: Deconstruct — "domestic objects as symbols", "two poems", "explain with examples" → requires mapping 4-5 objects across both poems to symbolic meanings tied to aging.
- Step 2: Create object-symbol table from chapter nodes (003, 008, 009):  
  | Object | Poem | Literal Role | Symbolic Meaning |  
  |--------|------|--------------|------------------|  
  | iRFkj (threshold) | rksM+ks | Entry point to home | Boundary between dependence/independence |  
  | Ålj (yard) | rksM+ks | Domestic space | Social confinement of elderly |  
  | catj (wall) | rksM+ks | Physical enclosure | Emotional isolation ("eu dh [kht") |  
  | pqjeqjk/bangles | olar vk;k | Ornament/sound | Identity, femininity, presence |  
  | gok/fiQjdh (cow-dung plaster) | olar vk;k | Floor coating | Sustaining labor, connection to earth |  
- Step 3: Structure as 4 PEEL paragraphs (one per major symbol cluster): Threshold+Yard+Wall (liberation), Bangles (identity), Plaster (labor), Heart-wall (synthesis).
- Step 4: Draft with precise Hindi terminology (प्रतीक, बिंब, रूपक, अनुप्रास) and chapter intro references ("थाउह के विरोधों की रचनात्मक रचना").
- Step 5: Final polish — ensure each paragraph has: Object name (Devanagari) → Quote → Device → Symbolic meaning → Theme link.
REASONING: This multi-step mapping prevents the common error of listing objects without symbolic analysis. The table method (Step 2) is a transferable exam strategy for any "symbolism" question.
ANSWER:  
केदारनाथ सिंह घरेलू वस्तुओं को वृद्धावस्था के प्रतीकों में रूपांतरित करते हैं। 'रकसकस' में "इरफकज" (देहरी), "आल्ज" (आँगन), "कत्ज" (दीवार) भौतिक घेरे हैं जिन्हें तोड़ने का आदेश "रकसकस रकसकस रकसकस" देता है — ये क्रमशः आश्रय, सामाजिक सीमा और भावनात्मक अलगाव ("यू धा खट") के प्रतीक हैं। 'ओलर वक;क' में "पजेकिक/इकिओ" (पाजेब/घुंघरू) उसकी स्त्रियोचित पहचान और उपस्थिति की घोषणा हैं — "मेइपस रजक्वोज लस फजस" अनुप्रास में उसकी अदृश्यता के विरुद्ध श्रव्य प्रतिरोध। "गोक/फिकजध-लह" (गोबर-लेप) उसके श्रम का बिंब है: "फक्यह गकबज गोक वकबज" में ताजे लेप की गंध पृथ्वी से उसके जुड़ाव और गृहस्थी की पोषक भूमिका को मूर्त करती है। अंत में "यू धा खट" (हृदय-दीवार) दोनों कविताओं को जोड़ता है: 'रकसकस' इसे तोड़ने का आह्वान करती है, 'ओलर' इसे "फोंसक" (स्रोत) की तरह बहते दिखाती है। इस प्रकार घरेलू वस्तुएँ वृद्धावस्था की भौतिक-भावनात्मक वास्तविकता की भाषा बन जाती हैं।

## COMPETENCY_QUESTION_1
QUESTION: A CUET practice question asks: "In 'olar vk;k', the line 'veqd fnu veqd ckj enueghus dh gksosxh iapeh' uses repetition to convey:  
(A) The old woman's forgetfulness  
(B) The cyclical monotony of her routine  
(C) The poet's boredom with the subject  
(D) The musicality of folk rhythm  
Select the correct option and justify your choice in 3 sentences using the PEEL method."  
COMPETENCY: Analytical reasoning with textual evidence in MCQ+justification format (CUET pattern)  
STEPS:
- Step 1: Eliminate distractors — (A) "forgetfulness" is not suggested; the line describes *her* routine, not memory lapse. (C) projects poet's boredom — unsupported. (D) "folk rhythm" is a surface reading; repetition here is thematic, not decorative.
- Step 2: Select (B) — "veqd fnu veqd ckj" (day after day, time after time) mimics the repetitive cycle of her return.
- Step 3: Write PEEL justification: Point — The repetition enacts cyclical monotony. Evidence — "veqd fnu veqd ckj" repeats "veqd" (each/every) with time nouns. Explanation — The syntactic parallelism creates a rhythmic inevitability, mirroring how her return is both predictable and unchanging. Link — This reinforces the poem's central tension: a life of ritual that society renders invisible ("fujis{k cus jgrs gSa").
ANSWER: Correct option: (B). The repetition "veqd fnu veqd ckj" structurally enacts the cyclical monotony of the old woman's routine — the parallel syntax creates a metronomic rhythm that mirrors her unvarying return. This technique transforms description into enactment, making the reader *feel* the tedium that the phrase "fujis{k cus jgrs gSa" (we keep getting erased) thematizes as social erasure.  
DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: Case-based: A student writes this 6-mark answer: "In 'rksM+ks', the poet wants to break his house because he is angry at his children for neglecting him. The repetition of 'rksM+ks' shows his anger. He breaks the door, yard, wall. Finally he breaks his heart. This is sad."  
As an examiner, write a diagnostic comment (4-5 sentences) identifying exactly which assessment objectives (AOs) this answer fails, and prescribe 3 specific remediation steps referencing the chapter nodes.  
COMPETENCY: Evaluative judgment of student work against board marking criteria (teacher/examiner competency)  
STEPS:
- Step 1: Identify AOs tested in 6-mark literature question: AO1 (knowledge of text), AO2 (analysis of language/structure), AO3 (contextual understanding), AO4 (coherent argument).
- Step 2: Map failures — AO1: Partial (identifies objects but misreads agency — "poet wants to break" vs. poetic persona's symbolic act). AO2: Failed — "shows his anger" is reductive label, no device analysis (anaphora, progression, imperative mood). AO3: Failed — ignores chapter intro on Singh's philosophy ("creative construction of contradictions"). AO4: Failed — narrative summary replaces analytical structure.
- Step 3: Prescribe remediation linked to nodes: (1) Revisit c12_hin_a_cbse_05_009 (Irony/Symbolism) to distinguish literal vs. symbolic breaking. (2) Practice PEEL on c12_hin_a_cbse_05_013 (Critical Thinking) prompts for "rksM+ks". (3) Study c12_hin_a_cbse_05_001 (Context) to integrate poet's philosophy into Link sentences.
ANSWER: **Examiner's Diagnostic Comment:** This answer scores 1/6. It demonstrates basic textual recall (AO1: 1 mark) but fails AO2 (analysis) by reducing the refrain to an emotion label ("anger") without examining how anaphora, imperative mood, and spatial progression (threshold→yard→heart) construct meaning. It fails AO3 (context) by ignoring the chapter introduction's framing of Singh's poetry as "creative construction of life's contradictions" — the breaking is liberation, not tantrum. It fails AO4 (structure) by narrating plot instead of arguing thesis. **Remediation:** (1) Re-study node c12_hin_a_cbse_05_009 to decode symbolic vs. literal action. (2) Write 3 PEEL paragraphs on "rksM+ks" using node c12_hin_a_cbse_05_013 prompts. (3) Re-read node c12_hin_a_cbse_05_001 and practice one "Link" sentence connecting poem to poet's philosophy per paragraph.  
DIFFICULTY: hard