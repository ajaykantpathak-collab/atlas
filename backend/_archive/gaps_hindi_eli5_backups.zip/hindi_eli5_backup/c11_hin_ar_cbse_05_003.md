## DEFINITION
Setting refers to the time, place, and social environment in which a narrative unfolds, while atmosphere is the emotional mood or tone created by descriptive details, sensory imagery, and cultural context that shapes the reader's experience of the story world.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student can identify at least three distinct settings in "xyrk yksgk," explain how each setting's physical and social details create a specific atmosphere, and trace how the atmosphere shifts across the narrative to reflect the protagonist's psychological journey and the story's thematic concerns about caste and innocence.

## SCOPE_BOUNDARY
This node covers analysis of physical settings (school, home, fields, village), temporal setting (childhood to adulthood), social setting (caste hierarchy), and the atmospheric effects created through sensory details and narrative perspective in "xyrk yksgk." It does NOT cover character analysis, theme development, or literary devices beyond their contribution to setting/atmosphere.

## WALKTHROUGH
Imagine walking into your grandmother's village house after many years - the smell of damp earth, the sound of the school bell, the hush that falls when a certain teacher enters the room. That immediate sensory flood is "atmosphere" created by "setting." In "xyrk yksgk," Shivani doesn't just describe places; she makes the village school (LowQy), the fields (xk¡o), and the home (?) breathe with caste tension and childhood wonder. To begin, ask: "Which three places does eksgu inhabit most vividly?" Then hunt for sensory words - smells, sounds, textures - in those scenes. Notice how the same schoolyard feels safe when eksgu is small but suffocating when he returns as an adult. The key insight: setting in this story is not backdrop; it is an active character that enforces social boundaries and measures the loss of innocence.

## DIAGNOSTIC_QUESTION_1
Identify the three primary physical settings in "xyrk yksgk" where the major events of eksgu's childhood unfold, as established in the narrative.

## DIAGNOSTIC_ANSWER_1
The three primary physical settings are: (1) the village school (LowQy) where eksgu studies under f=kyksd flag ekLVj, (2) eksgu's home (?) with his mother g¡lqos and father, and (3) the fields/village paths (xk¡o) where eksgu plays and works. A wrong answer listing generic "village" or "school and home" without the third setting reveals the student cannot distinguish between the domestic sphere, institutional sphere, and the liminal outdoor space that each carry distinct atmospheric weight in the story.

## DIAGNOSTIC_QUESTION_2
Explain how the atmosphere of the school (LowQy) shifts between eksgu's early childhood (pages 56-58) and his later return as a young adult (pages 62-64), citing one sensory detail from each phase.

## DIAGNOSTIC_ANSWER_2
In early childhood, the school atmosphere is one of awe and fear: the sensory detail of "f=kyksd flag ekLVj dk ;g lkekU; fu;e FkkA ltk ikus okys dks gh vius fy, gfFk;kj Hkh tqVkuk gksrk Fkk" (the teacher's rule that students must buy their own seats) creates an atmosphere of transactional authority and childish compliance. In the later return, the atmosphere becomes hollow and performative: the sensory detail of eksgu "i<+&fy[kdj oa'k dk nkfjnz~; feVk ns" (writing to give a false certificate to the teacher) reveals an atmosphere of corruption and emptied ritual. A wrong answer describing both phases as "strict" or "educational" misses the shift from naive reverence to cynical complicity that mirrors eksgu's loss of innocence.

## DIAGNOSTIC_QUESTION_3
Apply the concept of "social setting" to analyze how the village fields (xk¡o) function differently for eksgu versus the upper-caste characters (f=kyksd flag, xksiky flag). Provide one textual evidence for each.

## DIAGNOSTIC_ANSWER_3
For eksgu, the fields are a space of labor and vulnerability: "eksgu xk¡o vk;k gqvk Fkk... dke djrs gq, ns[krk jgk" (eksgu went to the fields... watching while working) - the fields represent inescapable caste-destined toil. For upper-caste characters, the fields are a space of leisure and power: "xksiky flag dh nqdku ls gqDosQ dk vkf[kjh d'k [khapdj f=kyksd flag LowQy dh pgkjnhokjh esa mrjrs gSa" (returning from xksiky flag's wedding, f=kyksd flag attends school inspection) - they traverse the same geography as inspectors and wedding guests, wielding authority. A wrong answer claiming "both work in fields" ignores the caste-coded difference between forced labor and supervisory privilege that the spatial setting encodes.

## DIAGNOSTIC_QUESTION_4
Analyze how the domestic setting (?) and its atmosphere transform after g¡lqos's death (pages 60-61), focusing on the shift in sensory details and power dynamics within the household.

## DIAGNOSTIC_ANSWER_4
Before g¡lqos's death, the home atmosphere is defined by her protective labor: "?kj dh nksuksa efgykvksa] ftUgsa og pkph vkSj HkkHkh dg dj iqdkjrk Fkk] dk gkFk c¡Vkus osQ vykok èkhjs&èkhjs og eqgYys dh lHkh pkfp;ksa vkSj HkkfHk;ksa osQ fy, dke&dkt esa gkFk c¡Vkus dk lkèku cu x;k" (both women... for the sake of the children's bread and butter, engaged in ceaseless work). The sensory details are of ceaseless cooking, serving, shielding. After her death, the home becomes a site of raw exploitation: "eksgu! FkksM+k ngh rks yk ns ck”kkj ls... eksgu! ;s diM+s èkksch dks ns rks vkA" (eksgu! Give some water quickly... eksgu! Give these rotis). The father's voice replaces the mother's shielding presence; the sensory shift is from the warmth of "csar" (ghee) and "pkfp;k" (bread) to the mechanical demand for service. A wrong answer focusing only on "sadness" misses the structural shift: the home ceases to be a refuge and becomes another institution extracting eksgu's labor.

## DIAGNOSTIC_QUESTION_5
Evaluate the narrative choice to frame the story's opening and closing around the same physical space (the village school/LowQy) but with radically different atmospheric effects. What does this circular structure achieve thematically?

## DIAGNOSTIC_ANSWER_5
The circular structure achieves a devastating thematic irony: the school opens as a space of potential ("eksgu osQ iSj vuk;kl gh f'kYidkj Vksys dh vksj eqM+ x,A" - eksgu's childhood was spent in the lap of innocent years) and closes as a space of certified complicity ("mUgsa okLrfodrk dk Kku gqvk rks u flI+kZQ xgjk nq[k gqvk cfYd os yksxksa dks vius LoIuHkax dh tkudkjh nsus dk lkgl ugha tqVk ik,A" - when they gained formal knowledge, they didn't find it strange to give false testimony). The atmosphere shifts from the "vuqxw¡t 'ks"k" (carefree laughter) of a child waiting for his father to the "okrkoj.k vkSj jkr&fnu osQ dke osQ cks> osQ dkj.k" (mechanical routine of daily work) of an adult perpetuating the system. This evaluates as a masterful structural choice because it forces the reader to measure the distance between innocence and compromise not through abstract commentary but through the same physical coordinates now saturated with different emotional residues. A wrong answer calling it "just a flashback structure" fails to see how the recurring setting acts as a measuring rod for moral erosion.

## DIAGNOSTIC_QUESTION_6
Create a 4-sentence atmospheric description of the village path (xk¡o) at dusk that captures the dual mood of childhood freedom and caste surveillance present in the text, using at least three sensory details (sound, smell, touch, sight).

## DIAGNOSTIC_ANSWER_6
A strong answer: "Dust rises from the village path like smoke as eksgu's bare feet kick up the day's heat, the scent of drying dung cakes mixing with marigold from the temple yard. Somewhere a flute plays a fragment of a wedding song, but the sound fractures when the headman's bicycle bell cuts through - a sharp, metallic reminder of who owns the road. The banyan tree's shadow stretches long, offering coolness that feels like permission, yet its trunk bears the carved initials of generations who passed this way only to return as their fathers' shadows. The air tastes of both mango blossoms and the iron tang of the well-water drawn by hands that never touch the bucket." A poor answer listing only pleasant sensory details ("birds singing, cool breeze, pretty flowers") reveals the student cannot hold the story's central tension: that every space of beauty in this village is also a space of caste inscription.

## COMMON_MISCONCEPTION
Students treat setting as a static backdrop - "the story takes place in a village" - and atmosphere as a single adjective - "the mood is sad." They miss that Shivani constructs setting as a dynamic caste-map: the same physical location (schoolyard, field, home) carries different atmospheric charges depending on who occupies it and when. For example, they describe the school as "strict" throughout, missing how its atmosphere mutates from a child's terrified awe (f=kyksd flag's "gfFk;kj" rule) to an adult's cynical performance (eksgu writing false certificates). This error stems from reading for plot events rather than reading for spatial politics - they track what happens, not how space shapes what can happen.

## ON_FAILURE
Step 1: Have the student draw a rough map of the village marking LowQy, eksgu's ?, the xk¡o, and the temple/well. Step 2: For each location, ask them to find two quotes - one from early childhood (pages 56-59) and one from the later timeline (pages 60-64) - and note the sensory words (smell, sound, touch) in each. Step 3: Ask: "Who has power in this space in quote 1? Who has power in quote 2? What sensory detail signals the shift?" Step 4: Guide them to write one comparative sentence per location using the template: "In [location], the atmosphere shifts from [sensory detail A suggesting feeling X] to [sensory detail B suggesting feeling Y], revealing [caste/innocence insight]." This forces attention to textual evidence and the dynamic nature of setting.

## BUILDS_ON
c11_hin_ar_cbse_05_002: Text: Plot and Narrative Structure (provides the chronological framework needed to track setting changes across time)

## LEADS_TO
c11_hin_ar_cbse_05_004: Character Analysis: Protagonist (eksgu's psychological development is inseparable from the settings he inhabits)

## PREREQUISITE_NODE_IDS
c11_hin_ar_cbse_05_001, c11_hin_ar_cbse_05_002
## PREREQUISITE_REASONS
c11_hin_ar_cbse_05_001: Provides historical context of caste hierarchy in rural Uttar Pradesh essential for decoding the social setting
c11_hin_ar_cbse_05_002: Establishes the narrative timeline (childhood to adulthood) necessary to track atmospheric shifts across the story's two temporal phases

## FORWARD_NODE_IDS
c11_hin_ar_cbse_05_004, c11_hin_ar_cbse_05_006, c11_hin_ar_cbse_05_008, c11_hin_ar_cbse_05_013, c11_hin_ar_cbse_05_015, c12_hin_a_cbse_05_003, c12_hin_a_cbse_06_003, c12_hin_ar_cbse_05_003

## FORWARD_REASONS
c11_hin_ar_cbse_05_004: eksgu's character arc is mapped through his changing relationship to each setting (school, home, fields)
c11_hin_ar_cbse_05_006: The primary theme of caste oppression is materialized through spatial segregation and atmospheric coding
c11_hin_ar_cbse_05_008: Imagery and metaphor (e.g., "ltZd dh ped" - the dead tree's shadow) are the primary tools Shivani uses to construct atmosphere
c11_hin_ar_cbse_05_013: Setting analysis is crucial for interpreting the village/city dichotomy.  
c11_hin_ar_cbse_05_015: Setting (village vs city) is Discussion Question 1 – requires analysis of spatial symbolism.  
c12_hin_a_cbse_05_003: Prior exposure to setting and atmosphere analysis in Class 11 poems gives the foundational vocabulary and method.  
c12_hin_a_cbse_06_003: Practice with historical-social setting layers  
c12_hin_ar_cbse_05_003: Builds directly on Class 11 skill of identifying setting components and labelling mood; this node assumes that foundation and extends it to dynamic analysis.  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
none

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_05_001 -> c11_hin_ar_cbse_05_002 -> c11_hin_ar_cbse_05_003 -> c11_hin_ar_cbse_05_004 -> c11_hin_ar_cbse_05_006

## THIS_FORMULA
N/A - conceptual

## FORMULA_VARIABLES
N/A

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
analytical

## CROSS_SUBJECT
c11_history_caste_studies | The story's spatial segregation (school seating, well access, field labor) mirrors historical caste geography where physical space encoded ritual purity/pollution boundaries
c11_sociology_rural_structure | The shifting atmosphere of the village school from colonial-era inspection to post-independence certification reflects sociological studies of how rural institutions reproduce hierarchy through ritual performance
c11_geography_cultural_landscape | The xk¡o (fields/village paths) functions as a cultural landscape where movement patterns (who walks where, when, with whom) reveal power relations - a core concept in cultural geography

## PREREQ_CONCEPT
Understanding that narrative time in this story operates in two distinct phases (childhood innocence vs. adult compromise) separated by g¡lqos's death and eksgu's certification.

## PREREQ_BEFORE
Student must be able to identify the story's two temporal phases and the major events in each (childhood: school, home, fields; adulthood: teaching, certification, return).

## PREREQ_STUCK
If stuck, review the narrative structure node (c11_hin_ar_cbse_05_002) focusing on the timeline split at g¡lqos's death and eksgu's appointment as teacher.

## WORKED_EXAMPLE_1
PROBLEM: Analyze how the school (LowQy) functions as a setting that both reflects and enforces caste hierarchy in "xyrk yksgk," using evidence from two different time periods in the narrative.

STEPS:
- Step 1: Identify the two time periods - early childhood (pages 56-59) when eksgu is a student, and adulthood (pages 62-64) when he returns as a certified teacher.
- Step 2: Locate textual evidence for the school's physical and social layout in each period. Childhood: "f=kyksd flag ekLVj dk ;g lkekU; fu;e FkkA ltk ikus okys dks gh vius fy, gfFk;kj Hkh tqVkuk gksrk Fkk" (teacher's rule: students must buy their own seats). Adulthood: "eksgu i<+&fy[kdj oa'k dk nkfjnz~; feVk ns" (eksgu writes false certificate for teacher).
- Step 3: Analyze the atmospheric effect of each detail. Childhood: The "gfFk;kj" (seat/bench) rule creates an atmosphere of transactional humiliation - education is a commodity, and the child's body (sitting on floor vs. bench) marks caste status. Adulthood: The false certificate creates an atmosphere of hollow ritual - the school has become a machine for producing paperwork that maintains the status quo.
- Step 4: Synthesize how the same physical space enforces hierarchy differently across time. In childhood, hierarchy is enforced through bodily discipline (where you sit). In adulthood, hierarchy is enforced through bureaucratic complicity (what you sign).
- Step 5: Connect to the story's central concern: the school transforms from a site of potential liberation to a site of certified oppression, mirroring eksgu's own trajectory from victim to accomplice.

REASONING: This analysis works because it tracks a single setting across the narrative's temporal split, showing how atmosphere is not inherent to a place but produced by changing power relations within it. The "gfFk;kj" and "feVk" (certificate) are parallel symbols - both are documents/objects that mediate access to dignity.

ANSWER: The school (LowQy) in "xyrk yksgk" operates as a caste-enforcing machine that mutates across time. In eksgu's childhood, the atmosphere is one of bodily humiliation: f=kyksd flag ekLVj's rule that students must purchase their own benches ("gfFk;kj") forces lower-caste children to sit on the floor, making caste visible through posture. The sensory detail of "fugkbZ ij Bhd ?kkV esa fljk u i¡Qlus osQ dkj.k yksgk mfpr <ax ls eqM+ ugha ik jgk Fkk" (the boy couldn't properly balance on the uneven ground) conveys the physical discomfort of this spatial apartheid. In eksgu's adulthood, the same school produces an atmosphere of bureaucratic corruption: eksgu writes a false certificate ("nkfjnz~; feVk") for the very teacher who humiliated him, certifying a school inspection that never properly occurred. The shift from "gfFk;kj" (bench) to "feVk" (certificate) marks the evolution of caste power from crude physical exclusion to sophisticated institutional fraud. The school thus reflects the story's tragedy: institutions meant to liberate become instruments of compromise.

## WORKED_EXAMPLE_2
PROBLEM: Trace how the domestic setting (?) shifts from a space of maternal protection to a site of patriarchal extraction after g¡lqos's death, using sensory details from the text.

STEPS:
- Step 1: Establish the pre-death domestic atmosphere. Locate the passage describing g¡lqos's labor: "?kj dh nksuksa efgykvksa... dk gkFk c¡Vkus osQ vykok èkhjs&èkhjs og eqgYys dh lHkh pkfp;ksa vkSj HkkfHk;ksa osQ fy, dke&dkt esa gkFk c¡Vkus dk lkèku cu x;k" (both women... ceaseless work for children's bread and butter).
- Step 2: Identify the sensory cluster of the protected home: "csar" (ghee), "pkfp;k" (bread), "fugkbZ" (warmth of hearth), the mother's voice shielding eksgu from father's anger.
- Step 3: Establish the post-death domestic atmosphere. Locate the father's demands: "eksgu! FkksM+k ngh rks yk ns ck”kkj ls... eksgu! ;s diM+s èkksch dks ns rks vkA" (eksgu! Give water quickly... give these rotis).
- Step 4: Contrast the sensory clusters. Before: warmth, smell of ghee, rhythmic sounds of cooking, mother's body as barrier. After: mechanical demands, father's voice, eksgu's body as servant, absence of "csar" (the ghee is now for the father's guests).
- Step 5: Analyze the power shift. The home's physical layout hasn't changed, but the atmospheric charge has flipped from nurture to extraction. The "ltZd dh ped" (dead tree's shadow) metaphor on page 64 - "mldh vk¡[kksa esa ,d ltZd dh ped Fkhµ ftlesa u LièkkZ Fkh vkSj u gh fdlh izdkj dh gkj&thr dk Hkko" (in his eyes was a dead tree's shadow... no greenness, no trace of life) - externalizes this domestic death.

REASONING: This works because it uses sensory evidence to track an atmospheric inversion in a static physical space. The home's architecture is unchanged; what changes is the emotional thermodynamics - who gives warmth, who receives it, who is consumed.

ANSWER: The domestic setting (?) undergoes a complete atmospheric inversion after g¡lqos's death. Before: the home breathes with maternal labor - "csar" (ghee) melted on "pkfp;k" (rotis), the "fugkbZ" (hearth) radiating warmth that is both physical and emotional, g¡lqos's body positioning itself between eksgu and his father's rage ("firk dh ckrsa lqudj Hkh mlus mudk Hkkj gydk djus dk dksbZ lq>ko ugha fn;k" - even hearing father's abuses, she didn't signal eksgu to retaliate). The atmosphere is one of buffered love: scarcity exists but is mediated by care. After: the same kitchen becomes a site of raw extraction. The father's voice replaces the mother's shield: "eksgu! FkksM+k ngh rks yk ns ck”kkj ls" - the demand for water and rotis is mechanical, stripped of endearment. The sensory detail of "csar" disappears from eksgu's plate; it now lubricates the father's social performance ("oa'khèkj ?kcjk x, vkSj cPps osQ Hkfo"; dks ysdj fpafrr jgus yxsA" - father went out, taking children's affection to show off). The "ltZd dh ped" (dead tree's shadow) in eksgu's eyes at the end externalizes this domestic death: the home that once nurtured now casts only a lifeless shadow. The physical setting is identical; the atmosphere has been hollowed out by the removal of the woman who made it a home rather than a household.

## WORKED_EXAMPLE_3
PROBLEM: Compare the atmospheric function of the village fields (xk¡o) for three different character groups: eksgu (lower-caste child), f=kyksd flag ekLVj (upper-caste teacher), and xksiky flag (upper-caste landowner). How does the same geography produce three distinct emotional geographies?

STEPS:
- Step 1: Map each character group's relationship to the xk¡o. eksgu: "eksgu xk¡o vk;k gqvk Fkk... dke djrs gq, ns[krk jgk" (goes to fields, watches while working) - labor and surveillance. f=kyksd flag: "xksiky flag dh nqdku ls gqDosQ dk vkf[kjh d'k [khapdj f=kyksd flag LowQy dh pgkjnhokjh esa mrjrs gSa" (returns from wedding, attends school inspection) - leisure and authority. xksiky flag: implied through wedding procession and land ownership - mastery and mobility.
- Step 2: Identify the sensory atmosphere for each. eksgu: heat on back ("Hk_h ij cSBdj"), dust in throat, fear of overseer's gaze. f=kyksd flag: cool evening return ("nwj ls lqurk jgk Fkk"), wedding sweets, bureaucratic ease. xksiky flag: wedding music ("fugkbZ ij j[ks yky xeZ yksgs ij iM+rh gFkkSM+s dh èki~&èki~ vkok”k"), procession spectacle, unchallenged movement.
- Step 3: Analyze how caste mediates sensory experience. The same dust is choking for eksgu, fragrant with celebration for xksiky flag, invisible to f=kyksd flag in his carriage. The same path is a trap for eksgu (surveillance), a corridor for f=kyksd flag (inspection route), a stage for xksiky flag (wedding procession).
- Step 4: Connect to the "fugkbZ" (banyan tree) as a shared but differently charged landmark. For eksgu: "fugkbZ ij Bhd ?kkV esa fljk u i¡Qlus" (can't balance on uneven ground) - instability. For others: shade, meeting point, landmark of power.
- Step 5: Synthesize the thematic implication. The xk¡o is not a neutral setting but a caste-coded emotional geography. Freedom of movement is the ultimate atmospheric privilege.
- Step 6: Link to the story's closing image: eksgu as adult still trapped in the same fields ("eksgu oqQN nsj rd mls dke djrs gq, ns[krk jgk" - eksgu watching while working till the end), while the upper-caste characters have long since moved into bureaucratic power.

REASONING: This multi-perspectival analysis reveals setting as a relational construct - the xk¡o has no single atmosphere; it generates atmosphere through the intersection of body, caste, and history. The "fugkbZ" serves as the objective correlative: same tree, radically different meanings.

ANSWER: The village fields (xk¡o) in "xyrk yksgk" function as a caste-coded emotional geography where the same physical space produces three distinct atmospheres. For eksgu, the xk¡o is an atmosphere of monitored labor: "Hk_h ij cSBdj gkFk Mkyus ij gqvk Fkk" (sitting on the ground, driving the stake) - the sensory cluster is heat on the back ("Hk_h"), dust in the throat, the overseer's gaze ("iqjksfgr [kkunku osQ ,d ;qod dk bl rjg osQ dke esa] mldh Hk_h ij cSBdj" - the work of a landless laborer, sitting on his haunches). The "fugkbZ" (banyan tree) offers no refuge: "fugkbZ ij Bhd ?kkV esa fljk u i¡Qlus osQ dkj.k yksgk mfpr <ax ls eqM+ ugha ik jgk Fkk" (the boy couldn't balance properly on the uneven ground) - instability incarnate. For f=kyksd flag ekLVj, the xk¡o is an atmosphere of bureaucratic transit: returning from xksiky flag's wedding ("nwj ls lqurk jgk Fkk" - walking carefree), he moves through the fields as an inspector ("LowQy dh pgkjnhokjh esa mrjrs gSa" - attends school inspection). The sensory details are wedding sweets, cool evening air, the ease of authorized movement. For xksiky flag (implied through his wedding procession), the xk¡o is an atmosphere of performative mastery: "fugkbZ ij j[ks yky xeZ yksgs ij iM+rh gFkkSM+s dh èki~&èki~ vkok”k" (gFkkSM+s's creaking wheels on the red xeZ carts stationed on the banyan platform) - the procession claims the space as stage. The same dust, same tree, same paths - but for eksgu they are a trap, for the teacher a corridor, for the landowner a throne. The story's tragedy: eksgu as adult remains in the first atmosphere ("eksgu oqQN nsj rd mls dke djrs gq, ns[krk jgk" - watching while working till the end), while the other two have converted spatial privilege into institutional power.

## COMPETENCY_QUESTION_1
QUESTION: In "xyrk yksgk," the village school (LowQy) appears in both the opening and closing sections of the story. Compare the atmospheric construction of this setting in these two sections. How does Shivani use sensory details and power dynamics to transform the school from a space of childhood awe into a space of adult complicity? Write a structured response with textual evidence.

COMPETENCY: Comparative textual analysis of setting and atmosphere across narrative time

STEPS:
- Step 1: Identify the two textual moments - childhood school (pages 56-58) and adult return (pages 62-64).
- Step 2: List sensory details and power markers for each moment (bench rule vs. false certificate; teacher's stick vs. teacher's request; child's fear vs. adult's cynicism).
- Step 3: Analyze how the atmosphere shifts from reverence to corruption.
- Step 4: Explain what this transformation reveals about the story's view of education and caste.

ANSWER: In the opening, the LowQy atmosphere is built on a child's terrified reverence: f=kyksd flag ekLVj's rule that "ltk ikus okys dks gh vius fy, gfFk;kj Hkh tqVkuk gksrk Fkk" (students must buy their own benches) creates a sensory world where caste is felt in the body - the cold floor vs. the purchased bench, the teacher's stick ("csar dk pkcqd" - the whip of authority), the "vuqxw¡t 'ks"k" (carefree laughter) that exists only outside school gates. The power dynamic is absolute: teacher as deity, student as supplicant. In the closing, the same school produces an atmosphere of hollow performance: eksgu "i<+&fy[kdj oa'k dk nkfjnz~; feVk ns" (writes a false certificate for the teacher) to legitimize a fake inspection. The sensory details shift from bodily fear to bureaucratic texture - ink, paper, the "okrkoj.k vkSj jkr&fnu osQ dke osQ cks> osQ dkj.k" (mechanical routine of daily work). The power dynamic has inverted: the teacher now needs eksgu's complicity to maintain his position. The transformation reveals Shivani's central irony: the institution meant to liberate through knowledge becomes the mechanism that certifies caste privilege. The "gfFk;kj" (bench) and "feVk" (certificate) are twin symbols - both are documents of access that the lower-caste body must either purchase or forge. The school's atmosphere thus traces the arc from innocent belief in the system to knowing participation in its fraud.

DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: The story uses the motif of the "fugkbZ" (banyan tree) as a fixed geographical anchor that witnesses the village's caste dramas across generations. Analyze how this single setting element functions as an atmospheric barometer for three different characters: eksgu as child, eksgu as adult, and f=kyksd flag ekLVj. What does the tree's changing atmospheric charge reveal about the possibility of change in this social order?

COMPETENCY: Symbolic setting analysis and thematic synthesis

STEPS:
- Step 1: Locate the fugkbZ references for each character (eksgu child: page 57 "fugkbZ ij Bhd ?kkV esa fljk u i¡Qlus"; eksgu adult: page 63 "fugkbZ ij j[ks yky xeZ yksgs ij iM+rh gFkkSM+s dh èki~&èki~ vkok”k"; f=kyksd flag: page 63 implied through inspection route).
- Step 2: Analyze the atmospheric charge for each - instability vs. procession vs. surveillance.
- Step 3: Compare how the same physical object generates different emotional geographies based on caste position.
- Step 4: Evaluate whether the tree's persistence as witness suggests continuity or the possibility of rupture.
- Step 5: Connect to the story's closing image of eksgu's "ltZd dh ped" (dead tree's shadow) in his eyes.

ANSWER: The fugkbZ (banyan tree) operates as the story's atmospheric barometer, registering the pressure of caste through three distinct readings. For eksgu as child, the tree is a site of physical precarity: "fugkbZ ij Bhd ?kkV esa fljk u i¡Qlus osQ dkj.k yksgk mfpr <ax ls eqM+ ugha ik jgk Fkk" (the boy couldn't balance properly on the uneven ground) - the atmosphere is one of bodily instability, the tree's roots mirroring the unlevel playing field of his caste destiny. For f=kyksd flag ekLVj, the tree is a bureaucratic landmark: his inspection route passes it ("LowQy dh pgkjnhokjh esa mrjrs gSa"), the atmosphere is one of authorized passage - he reads the tree as a coordinate on his map of control. For xksiky flag's wedding procession (the upper-caste apex), the tree becomes a triumphal stage: "fugkbZ ij j[ks yky xeZ yksgs ij iM+rh gFkkSM+s dh èki~&èki~ vkok”k" (gFkkSM+s's creaking wheels on the red carts stationed on the banyan platform) - the atmosphere is celebratory mastery, the tree decorated as a throne. The same tree, three atmospheres: the lower-caste body experiences it as obstacle, the middle-caste functionary as waypoint, the upper-caste landowner as property. The story's devastating conclusion transfers the tree's deadness into eksgu's gaze: "mldh vk¡[kksa esa ,d ltZd dh ped Fkh" (in his eyes was a dead tree's shadow) - the atmospheric barometer has flatlined. The fugkbZ's persistence across generations doesn't witness change; it measures the depth of stasis. Its roots go down as deep as the caste order. The only rupture is internal: eksgu's eyes becoming the dead tree's shadow - the atmosphere has been internalized as despair.

DIFFICULTY: hard