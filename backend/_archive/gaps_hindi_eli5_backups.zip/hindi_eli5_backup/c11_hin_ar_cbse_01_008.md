## DEFINITION
**Imagery (चित्रात्मकता)** refers to the use of vivid, sensory language that appeals to the five senses (sight, sound, smell, touch, taste) to create mental pictures and evoke physical sensations in the reader. **Metaphor (रूपक/प्रतीक)** is a figure of speech that directly equates two unlike things without using "like" or "as" (e.g., "Time is a thief"), transferring qualities from the vehicle (thief) to the tenor (time) to reveal hidden similarities. In *Ued ka Naksha*, Premchand uses olfactory imagery (smell of damp earth) to ground the narrative in rural reality and metaphors like "Death covering Life with a sheet" to universalize the peasant's struggle.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student can independently identify at least three distinct sensory images and two metaphors in the story, explain the specific sensory appeal of each image, and articulate how the metaphor's tenor-vehicle relationship deepens the theme of exploitation or resilience, using textual evidence in a structured PEEL paragraph.

## SCOPE_BOUNDARY
This node covers **only** imagery (all five sensory types) and metaphor (explicit and implicit) as employed in Premchand's *Ued ka Naksha*. It does **not** cover simile, personification, irony, symbolism, or other rhetorical devices (addressed in node c11_hin_ar_cbse_01_009). Analysis is restricted to the short story text, not the introductory biographical essay.

## WALKTHROUGH
Imagine you are watching a movie scene where the camera zooms in on a farmer's cracked heels, you hear the squelch of wet mud, and smell the sharp tang of urea fertilizer — that is **imagery** making the abstract "poverty" visceral. Now, if the director shows a withered tree standing alone in a barren field to *represent* that farmer without saying a word — that is **metaphor** (the tree *is* the farmer). In *Ued ka Naksha*, Premchand does both with words. Start by **reading aloud** the opening paragraph (the udad field description). **Circle every word that triggers a sense** (smell: *mQijh vk;*, touch: *yM+fd;k¡... c<+rh*, sight: *xkfM+;k¡*). Next, **hunt for direct equations** where A *is* B (e.g., "/eZ us /u dks iSjksa rys oqQpy Mkyk" — Death *is* a coverer). Ask: *What quality of the sheet (vehicle) is transferred to death (tenor)?* Finally, connect each device to the **theme of dehumanization** — how the sensory details make exploitation tangible, and how metaphors elevate a land dispute into a universal tragedy.

## DIAGNOSTIC_QUESTION_1
Define "imagery" and "metaphor" in your own words, giving one example of each from *Ued ka Naksha* (do not use the examples from the walkthrough).

## DIAGNOSTIC_ANSWER_1
**Correct Answer:** Imagery is language appealing to the five senses to create a concrete experience; e.g., the auditory image "xkfM+;k¡ dh xM+xM+kgV rFkk eYykgksa dk dksykgy" (crunching of ants and rustling of wings). Metaphor is an implicit comparison where one thing is named as another; e.g., "U;k; vkSj uhfr lc y{eh osQ gh f[kykSus gSa" (Ritual and tradition are both branches of selfishness) — here *selfishness* is the tenor, *tree* the implied vehicle.  
**Misconception Revealed:** If a student gives a simile ("memories *like* a creeper") as a metaphor, they confuse explicit comparison (using *like/as*) with implicit equation. If they only list visual images, they ignore olfactory/tactile/auditory dimensions crucial to Premchand's realism.

## DIAGNOSTIC_QUESTION_2
In the passage where IafMr Vyavsaya says "gekjs ljdkj rks vki gh gSa" (Our government *is* you), identify the tenor and vehicle. Explain why Premchand chooses a metaphor instead of a simile ("Our government is *like* you") in this confrontation.

## DIAGNOSTIC_ANSWER_2
**Correct Answer:** Tenor = the colonial contractor/bureaucrat (the oppressor); Vehicle = "you" (the peasant IafMr). The metaphor **collapses the distance** between ruler and ruled, forcing the contractor to see his own face in the victim. A simile ("like you") would keep them separate, allowing moral detachment; the metaphor *is* the accusation — it makes the contractor *become* the peasant's suffering, which is why he recoils ("oa'kh/j us vyksihnhu dks vkrs ns[kk rks mBdj lRdkj fd;k").  
**Misconception Revealed:** Students often treat metaphor as decorative. A wrong answer focuses on "beauty of language" rather than **rhetorical force** — the metaphor here is a weapon, not ornament. Missing the *tenor/vehicle* distinction shows they cannot deconstruct the comparison.

## DIAGNOSTIC_QUESTION_3
**Apply:** The story describes the night before the auction: "vknfe;ksa esa oqQN dkuk&iwQlh gqbZ] rc vkxs okys us dgkµiafMr vyksihnhu dh!" (Nights passed in sleeplessness, then the buyers shouted: "Where is IafMr Vyavsaya?"). Rewrite this as a **pure imagery paragraph** (no metaphors) that makes a city-bred reader *feel* the peasant's insomnia and terror. Use at least three senses.

## DIAGNOSTIC_ANSWER_3
**Sample Answer:** "The oil lamp sputtered, throwing dancing shadows on the mud walls (sight). The air thickened with the sour stench of fear-sweat and drying dung-cakes (smell). Every creak of the bamboo roof — a lizard? a thief? — made his fingers clutch the coarse blanket until knuckles whitened (touch). In the distance, the village watchman's stick struck the hour: *thud... thud... thud* — each blow a hammer on his chest (sound)."  
**Steps:** 1) Identify the core emotions: insomnia, dread, helplessness. 2) Map each to a sense: sight (shadows), smell (sweat/dung), touch (blanket/knuckles), sound (watchman's stick). 3) Choose concrete, rural-specific nouns (mud walls, dung-cakes, bamboo roof). 4) Avoid abstract nouns (fear, anxiety) — show, don't tell. 5) Verify no "like/as" or "is" comparisons remain.  
**Misconception Revealed:** Students often insert metaphors ("night *was* a black blanket") instead of raw sensory data. If the paragraph uses "he felt scared," they have not grasped *showing via imagery*.

## DIAGNOSTIC_QUESTION_4
**Analyze:** Compare the **olfactory imagery** in two scenes: (a) the opening udad field ("mQijh vk; cgrk gqvk lzksr...") and (b) the auction morning ("xkfM+;ksa dh ,d yach drkj iqy osQ ikj tkrh fn[kh"). How does the shift from *earth-smell* to *sugar/ant-smell* trace the narrative arc from rooted life to commodified death?

## DIAGNOSTIC_ANSWER_4
**Correct Answer:** Scene (a) — "mQijh vk;... osru euq"; nsrk gS" — the damp-earth smell is **life-giving, cyclic, communal** (shared by all peasants). It grounds IafMr in his identity as cultivator. Scene (b) — ants swarming sugar — introduces a **predatory, invasive smell** (formic acid, sweetness turned rotten). Sugar is a *cash crop* commodity; ants are the *market forces* (buyers, contractors) consuming the peasant's produce. The olfactory shift mirrors IafMr's journey: from **producer rooted in soil** to **commodity devoured by capital**. The earth smell nurtures; the sugar-ant smell destroys.  
**Misconception Revealed:** Treating both smells as mere "setting details." A weak answer lists smells without linking to **character arc** or **socio-economic metaphor**. Missing the *ant = buyer* metaphor (implicit in the imagery) shows inability to connect sensory detail to structural critique.

## DIAGNOSTIC_QUESTION_5
**Evaluate:** A critic claims: "Premchand's metaphor '/eZ us /u dks iSjksa rys oqQpy Mkyk' (Death covered Life with a sheet) is **sentimental melodrama** that undermines the story's realist credibility." Defend or refute using textual evidence.

## DIAGNOSTIC_ANSWER_5
**Correct Answer (Refute):** The metaphor is **not sentimental** — it is **structural realism**. In the village, death *is* a daily, mundane covering: the shroud (sheet) is the only "property" the peasant owns. The metaphor compresses the **material reality** (funeral rites, debt, land seizure) into one image. Evidence: Immediately after, the narrative lists concrete consequences — "iafMr vyksihnhu fujk'k gksdj cksysµvc blls vf/d esjk lkgl ugha" (IafMr died, and this [the land seizure] didn't stop). The sheet *is* the legal document, the auction notice, the contractor's pen. It elevates the specific to the universal *without* leaving the material plane.  
**Misconception Revealed:** Equating "metaphor" with "unrealistic/emotional." Students who agree with the critic confuse **poetic language** with **falsehood**. They miss that Premchand's metaphors *are* the peasant's cognitive framework — the peasant *thinks* in these metaphors.

## DIAGNOSTIC_QUESTION_6
**Create:** Write a **six-line free verse poem** from the perspective of the *udar field* (the black-gram crop) witnessing IafMr's auction. Use **only imagery** (no metaphors, similes, or abstract nouns) to convey the field's "grief." Each line must target a different sense (include proprioception/kinesthesia).

## DIAGNOSTIC_ANSWER_6
**Criteria for Good Answer:**  
Line 1 (Sight): "Yellow pods split open, spilling black pearls into dust."  
Line 2 (Sound): "The auctioneer's gavel cracks — *thak* — like a dry stem breaking." (Wait — "like" is simile. Remove: "The auctioneer's gavel cracks: *thak* — a dry stem breaking.")  
Line 3 (Smell): "Urea-sour air replaces the sweet rot of my ripening."  
Line 4 (Touch): "Iron-shod boots trample my furrows, grinding roots to powder."  
Line 5 (Taste): "Bitter ash of burnt stubble coats the tongue of the wind."  
Line 6 (Kinesthesia): "My center of gravity shifts — uprooted, I tilt toward the buyer's ledger."  
**Poor Answer Reveals:** Use of "sad," "helpless," "cry" (abstractions); "field *weeps* like a widow" (simile/personification); single-sense focus (only visual). Shows inability to **sustain sensory discipline** or **embody a non-human perspective**.

## COMMON_MISCONCEPTION
**Students believe imagery = "descriptive writing" and metaphor = "flowery language."** They treat both as *optional decorations* added for beauty, not as **structural tools** Premchand uses to encode the peasant's material reality. For example, they read "yM+fd;k¡ gaS] og ?kkl&iwQl dh rjg c<+rh pyh tkrh gS" (Memories *are* creepers crawling) and call it "nice description," missing that the **creeper metaphor** maps *parasitic growth* onto *memory* — memories don't just "visit"; they **strangle** the present, just as the contractor's debt strangles the crop. They also restrict imagery to **visual** ("I can *see* the field"), ignoring how Premchand's **olfactory/tactile dominance** (smell of earth, feel of mud, sound of gavel) forces the urban reader into the peasant's body. This misconception arises because school textbooks often teach devices as "identify and define" exercises, not "analyze function" exercises.

## ON_FAILURE
1. **Sensory Walk:** Take the student outside (or to a kitchen). Ask them to close eyes and name **only** smells, sounds, textures for 2 minutes. Write them down. This breaks "visual-only" habit.  
2. **Tenor-Vehicle Surgery:** Give a metaphor from the text ("U;k; vkSj uhfr lc y{eh osQ gh f[kykSus gSa"). Physically cut the sentence into two cards: **TENOR** (Ritual/Tradition) and **VEHICLE** (Branches of Selfishness). Ask: *What does a branch do? (draws sap, grows, breaks). What does ritual do? (draws money, grows rigid, breaks the peasant).* Tape them together. Repeat with 3 more metaphors.  
3. **Function Chart:** Make a 3-column table: **Device** | **Literal Meaning** | **Thematic Work** (e.g., "Ants on sugar" | Insects eating sweet | Market forces consuming peasant's labor). Fill for 5 devices. Forces shift from *identification* to *function*.  
4. **Rewrite Task:** Take a "decorative" student sentence ("The sunset was beautiful like a painting") and demand rewrite as **pure imagery** (no "beautiful," no "like") — e.g., "The horizon bled saffron into grey; crows cut the light into ribbons."

## BUILDS_ON
c11_hin_ar_cbse_01_006 (Primary Theme) and c11_hin_ar_cbse_01_007 (Secondary Themes) — literary devices are the *vehicles* that deliver the themes of exploitation, resilience, and dehumanization; without thematic context, device-spotting is empty.

## LEADS_TO
c11_hin_ar_cbse_01_009 (Irony and Symbolism) — metaphor mastery is prerequisite because symbolism *extends* metaphor (a symbol is a metaphor with open-ended referents), and irony often *subverts* metaphorical expectations (e.g., the "sheet" metaphor becomes ironic when the contractor uses actual shrouds for profit).

## PREREQUISITE_NODE_IDS
c11_hin_ar_cbse_01_001, c11_hin_ar_cbse_01_002, c11_hin_ar_cbse_01_003, c11_hin_ar_cbse_01_004, c11_hin_ar_cbse_01_005, c11_hin_ar_cbse_01_006, c11_hin_ar_cbse_01_007, c11_hin_ar_cbse_02_008, c11_hin_v_cbse_01_008

## PREREQUISITE_REASONS
c11_hin_ar_cbse_01_001: Context (colonial land revenue, Premchand's biography) explains *why* the metaphors target bureaucracy and debt.
c11_hin_ar_cbse_01_002: Plot structure identifies *where* key images/metaphors cluster (auction scene, death scene) for focused analysis.
c11_hin_ar_cbse_01_003: Setting/atmosphere analysis provides the sensory baseline (mud, heat, night) that imagery intensifies.
c11_hin_ar_cbse_01_004: Protagonist analysis (IafMr) reveals whose consciousness filters the imagery — his sensory world *is* the imagery.
c11_hin_ar_cbse_01_005: Supporting characters (contractor, wife, buyers) are the *vehicles* in many metaphors (e.g., contractor = government).
c11_hin_ar_cbse_01_006: Primary theme (exploitation) is the *meaning* that imagery/metaphor make tangible; without theme, devices are ornaments.
c11_hin_ar_cbse_01_007: Secondary themes (resilience, ritual vs. humanity) are encoded in specific metaphors (e.g., "ritual = branches of selfishness").
c11_hin_ar_cbse_02_008: : Introduced imagery and metaphor definitions and basic identification in Class 11 Antra Chapter 1. c11_hin_ar_cbse_02_008: Reinforced the same devices in a different text, showing variety. c11_hin_v_cbse_01_008: Covered literary devices in  
c11_hin_v_cbse_01_008: hapter 1. c11_hin_ar_cbse_02_008: Reinforced the same devices in a different text, showing variety. c11_hin_v_cbse_01_008: Covered literary devices in Vitan, providing cross-text practice. c12_hin_a_cbse_12_001: Context node gives author ba  

## FORWARD_NODE_IDS
c11_hin_ar_cbse_01_009, c11_hin_ar_cbse_01_010, c11_hin_ar_cbse_01_011, c11_hin_ar_cbse_01_012, c11_hin_ar_cbse_01_013, c11_hin_ar_cbse_01_014, c11_hin_ar_cbse_01_015, c12_hin_a_cbse_01_008, c12_hin_a_cbse_02_008, c12_hin_a_cbse_04_004, c12_hin_a_cbse_04_008, c12_hin_a_cbse_05_008, c12_hin_a_cbse_06_008, c12_hin_a_cbse_08_008, c12_hin_a_cbse_11_008, c12_hin_a_cbse_12_008, c12_hin_a_cbse_16_008, c12_hin_a_cbse_17_008, c12_hin_al_cbse_01_008, c12_hin_al_cbse_02_008, c12_hin_al_cbse_03_008, c12_hin_ar_cbse_01_008, c12_hin_ar_cbse_04_008, c12_hin_ar_cbse_11_008, c12_hin_ar_cbse_12_008, c12_hin_a_cbse_04_005, c12_hin_a_cbse_10_009, c12_hin_a_cbse_03_006

## FORWARD_REASONS
c11_hin_ar_cbse_01_009: Irony/symbolism build directly on metaphor mechanics (tenor/vehicle, implied comparison).
c11_hin_ar_cbse_01_010: Vocabulary in context requires distinguishing literal vs. figurative word senses (e.g., "y{eh" = branch vs. metaphorical branch).
c11_hin_ar_cbse_01_011: Grammar usage (e.g., nominal compounds like "mQijh+vk;") often creates dense imagery; syntax analysis supports device analysis.
c11_hin_ar_cbse_01_012: Comprehension questions frequently ask "What image suggests...?" or "Explain the metaphor..." — direct application.
c11_hin_ar_cbse_01_013: Critical interpretation *is* device analysis extended to whole-text argument.
c11_hin_ar_cbse_01_014: Writing skills (analytical paragraph) use the PEEL structure practiced here.
c11_hin_ar_cbse_01_015: Speaking/listening discussions need device-vocabulary to articulate responses.
c12_hin_a_cbse_01_008: Introduced imagery/metaphor identification in Class 11 Antra Chapter 1; this node deepens to analysis.  
c12_hin_a_cbse_02_008: Foundation in identifying imagery/metaphor in Class 11 Antra Chapter 1.  
c12_hin_a_cbse_04_004: Prior identification of personification and imagery enables spotting the techniques that construct this protagonist.  
c12_hin_a_cbse_04_008: Class 11 foundation — basic definitions and simple identification of imagery/metaphor in Antra poems.  
c12_hin_a_cbse_05_008: Provides foundational definitions of imagery and metaphor from Class 11 Aroh textbook.  
c12_hin_a_cbse_06_008: Class 11 foundation — basic definitions, identification drills, simple analysis of imagery/metaphor in Khusro/Kabir.  
c12_hin_a_cbse_08_008: Provides foundational definitions of imagery/metaphor and tenor-vehicle framework in accessible Khari Boli.  
c12_hin_a_cbse_11_008: Provides foundational definitions of imagery and metaphor (tenor, vehicle, ground) and basic identification practice.  
c12_hin_a_cbse_12_008: Introduced imagery and metaphor definitions and basic identification in Class 11 Antra Chapter 1. c11_hin_ar_cbse_02_008: Reinforced the same devices in a different text, showing variety. c11_hin_v_cbse_01_008: Covered literary devices in Vitan, providing cross-text practice. c12_hin_a_cbse_12_001: Context node gives author background and socio-cultural setting essential for interpreting metaphors rooted in market life. c12_hin_a_cbse_12_002: Plot node ensures student knows narrative sequence to place each device in correct scene. c12_hin_a_cbse_12_006: Primary theme node establishes the central ideas (isolation, dignity) that imagery and metaphor serve.  
c12_hin_a_cbse_16_008: Provides foundational definitions of imagery types and metaphor mechanics (tenor/vehicle) in Hindi literary context.  
c12_hin_a_cbse_17_008: Class 11 Antra foundation for identifying imagery/metaphor — provides the basic vocabulary (बिंब, रूपक, उपमा) and device-recognition practice this node deepens.  
c12_hin_al_cbse_01_008: Provides foundational definitions and identification practice for imagery and metaphor from Class 11 Hindi Aroh.  
c12_hin_al_cbse_02_008: Provides foundational definitions and practice of imagery/metaphor identification in Class 11 texts — without this, Class 12 analysis lacks vocabulary.  
c12_hin_al_cbse_03_008: Class 11 Antara introduction to imagery/metaphor definitions and identification.  
c12_hin_ar_cbse_01_008: Class 11 foundation on imagery/metaphor definitions and basic identification — this node deepens to analysis of extended metaphor and imagery clusters.  
c12_hin_ar_cbse_04_008: Class 11 foundation on imagery/metaphor definitions and basic identification — without this, Class 12 analysis has no vocabulary.  
c12_hin_ar_cbse_11_008: Provides foundational definitions of imagery/metaphor and practice with simpler texts.  
c12_hin_ar_cbse_12_008: Provides foundational definitions and practice with imagery and metaphor in Class 11 texts.  
c12_hin_a_cbse_04_005: If stuck, review "Personification as Characterization" in Class 11 poetry nodes (c11_hin_ar_cbse_01_008, c11_hin_v_cbse_01_008) and practice on a simpler poem like "पहाड़" (Antra Ch. 2).  
c12_hin_a_cbse_10_009: still stuck, ask your teacher for the "Symbol vs. Imagery" sorting worksheet used in Class 11 (node c11_hin_ar_cbse_01_008).  
c12_hin_a_cbse_03_006: Class 11 skill of moving from subject to theme statement (c11_hin_ar_cbse_01_006) and identifying refrain function (c11_hin_ar_cbse_01_008).  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
none

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_01_006 -> c11_hin_ar_cbse_01_008 -> c11_hin_ar_cbse_01_009 (Theme analysis provides the *why*; imagery/metaphor provides the *how*; irony/symbolism extends the *how* into deeper structural critique.)

## THIS_FORMULA
N/A - conceptual

## FORMULA_VARIABLES
N/A

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
conceptual

## CROSS_SUBJECT
c11_history_colonialism | The story's metaphors (contractor = government, sheet = legal document) encode the **colonial land revenue system** (zamindari/ryotwari); analyzing them requires understanding how British policy turned land into commodity and peasants into debt-slaves — the historical reality behind the literary devices.
c11_economics_rural_credit | The olfactory shift (earth → sugar/ants) mirrors the **transition from subsistence to cash-crop economy**; imagery of "mQijh vk;" (damp earth = use-value) vs. "xkfM+;k¡ ij iqy" (ants on sugar = exchange-value) illustrates Marx's use-value/exchange-value distinction in a pre-capitalist agrarian setting.
c11_psychology_trauma | IafMr's sensory hypersensitivity (hearing ants, smelling earth, feeling blanket) reflects **somatic markers of chronic stress/trauma**; the metaphors ("memories = creepers") are cognitive schemas organizing helplessness — literary analysis here bridges to psychological realism.

## PREREQ_CONCEPT
Understanding that **theme is not a message but a pattern of meaning** constructed through textual details (from c11_hin_ar_cbse_01_006/007). Without this, students hunt for devices as isolated ornaments rather than as theme-building machinery.

## PREREQ_BEFORE
Student must be able to: (1) Summarize the plot of *Ued ka Naksha* in 5 sentences, (2) State the primary theme (exploitation of peasant by colonial-bureaucratic nexus) with two textual evidences, (3) Define "tenor" and "vehicle" in a metaphor (Class 10 level).

## PREREQ_STUCK
If stuck, review **c11_hin_ar_cbse_01_006 (Primary Theme)** — specifically the distinction between *theme as topic* (e.g., "poverty") and *theme as statement* (e.g., "Colonial bureaucracy commodifies the peasant's life-force"). This distinction is the lens through which imagery/metaphor become analytically visible.

## WORKED_EXAMPLE_1
**PROBLEM:** Analyze the **tactile imagery** in the passage where IafMr's wife touches his dead body: "cw<+s eqa'khth rks igys gh ls oqQM+&cqM+k jgs Fks fd pyrs&pyrs bl yM+osQ dks le>k;k Fkk ysfdu blus ,d u lquhA lc euekuh djrk gSA" (The cold wife had already understood this while moving, but she didn't listen once. She just kept trembling.) Explain how touch conveys the **irreversibility of loss** better than dialogue could.

**STEPS:**
- Step 1: **Locate the sensory cluster** — "oqQM+&cqM+k" (cold/numb), "euekuh" (trembling), "pyrs&pyrs" (moving/mechanically). No visual, auditory, or olfactory words — pure touch/kinesthesia.
- Step 2: **Identify the tactile progression** — *numbness* (frozen grief) → *trembling* (body's revolt against numbness) → *mechanical motion* (autopilot survival). The body knows before the mind accepts.
- Step 3: **Contrast with dialogue absence** — "blus ,d u lquh" (she didn't listen once). Words belong to the living; touch belongs to the dying/dead. The silence *is* the tactile image.
- Step 4: **Connect to theme** — The peasant woman's body has always been a tool (labor, childbirth, endurance). Now, even her grief is **tactile labor** — trembling is work. The imagery says: *Loss is not an emotion; it is a physical condition of the oppressed body.*
- Step 5: **Verify with broader pattern** — Earlier, IafMr's "yM+fd;k¡... c<+rh" (creeping memories) was also tactile. Touch is the **peasant's epistemology** — they know the world through hands/feet/skin. The wife's tactile grief continues this epistemology.

**REASONING:** This 5-step method (locate cluster → trace progression → contrast with absent mode → thematic mapping → pattern verification) moves from *identification* to *interpretation* to *structural insight* — the exact trajectory board exams reward.

**ANSWER:** The tactile imagery (numbness → trembling → mechanical motion) embodies grief as **bodily knowledge** rather than emotional expression. By stripping dialogue ("blus ,d u lquh"), Premchand makes the wife's body the sole witness — her trembling *is* the truth of a life where even mourning is labor. This continues the story's pattern: peasants experience reality through skin (earth, mud, whip, blanket), so death must also be *felt*, not spoken.

## WORKED_EXAMPLE_2
**PROBLEM:** The metaphor "iafMr vyksihnhu bl vxkèk ou osQ flag Fks" (IafMr Vyavsaya was the flag of this helpless hope) appears after his death. Deconstruct the **tenor-vehicle relationship** and explain why "flag" (झंडा) is a more potent vehicle than "symbol" (प्रतीक) or "sign" (चिह्न) in the context of peasant resistance.

**STEPS:**
- Step 1: **Extract tenor & vehicle** — Tenor = IafMr Vyavsaya (the dead peasant leader); Vehicle = "flag" (banner, standard, rallying point).
- Step 2: **List vehicle's inherent properties** — A flag: (a) is *raised high* (visibility), (b) *belongs to a collective* (not individual), (c) *demands allegiance/salute*, (d) *falls only when the last bearer falls*, (e) is *made of cloth* (fragile, burnable).
- Step 3: **Map each property to tenor** — (a) IafMr's resistance made peasant suffering *visible* to the nation; (b) He was not a lone hero — "lkjs 'kgj esa gypy ep xbZ" (whole village trembled); (c) The contractor *had* to salute (acknowledge) him — "oa'kh/j us mBdj lRdkj fd;k"; (d) His death *is* the flag falling — but "vnkyr esa igq¡pus dh nsj Fkh" (hope of dawn remained); (e) His body was fragile ("mUgsa ns[krs gh yksx pkjksa rjI+kQ ls nkSM+s" — people watched from four directions).
- Step 4: **Compare with rejected vehicles** — "Symbol" is static, intellectual, detached (a scholar's word). "Sign" is passive, semiotic. "Flag" is **kinetic, communal, martial, sacrificial** — it *acts* in history.
- Step 5: **Historical resonance** — 1930s peasant movements (Kisan Sabhas) used red flags. The metaphor **anchors fiction in history** — IafMr *becomes* the unnamed flag-bearers of 1930s uprisings.

**REASONING:** Deconstruction (tenor/vehicle → vehicle properties → property-by-property mapping → comparative vehicle analysis → historical contextualization) ensures the student doesn't just "explain the metaphor" but *proves its necessity* — the highest band in board marking schemes.

**ANSWER:** "Flag" transforms IafMr from victim to **vanguard**. A symbol *represents*; a flag *leads*. The metaphor's power lies in its **collective kinetics** — a flag implies a marching column behind it (the villagers), a pole planted in contested soil (the auctioned land), and a wind that outlives the cloth (the "dawn" in the prison). "Symbol" would domesticate the rebellion into literature; "flag" keeps it in the street.

## WORKED_EXAMPLE_3
**PROBLEM:** **Synthesize** imagery and metaphor: The story opens with **olfactory imagery** ("mQijh vk; cgrk gqvk lzksr...") and closes with the **metaphor** "/eZ us /u dks iSjksa rys oqQpy Mkyk". Write a 150-word analytical paragraph showing how the **sensory opening** and **metaphorical closing** form a **structural frame** that encloses the peasant's journey from *embodied life* to *abstracted death* — and how the frame itself resists closure.

**STEPS:**
- Step 1: **Thesis statement** (Point): The story's frame — earth-smell opening, death-sheet closing — enacts the peasant's reduction from *sensory subject* to *bureaucratic object*, yet the frame's sensory persistence refuses full abstraction.
- Step 2: **Evidence 1 (Opening imagery)** — Quote "mQijh vk;... osru euq"; nsrk gS" (damp earth smell gives satisfaction). Analyze: *Osru* (satisfaction) is **visceral, immediate, non-monetary** — the peasant's body knows its worth through smell.
- Step 3: **Evidence 2 (Closing metaphor)** — Quote "/eZ us /u dks iSjksa rys oqQpy Mkyk". Analyze: The sheet *covers* the sensory body, turning the *smeller* into the *smelled* (corpse). Bureaucracy (Death as administrator) performs the covering.
- Step 4: **Evidence 3 (Frame resistance)** — The metaphor *uses* a sensory object (sheet) to describe abstraction. The sheet *has* texture, weight, smell (of the dead body). Even in death, the peasant **returns to earth** — "mQijh vk;" (damp earth) receives the sheet-covered body. The frame *leaks* sensory reality.
- Step 5: **Explanation** — The frame is not a circle but a **spiral**: earth → exploitation → death → earth. The olfactory opening *anticipates* the metaphorical closing (earth receives the sheet). The peasant's life-force (smell) outlasts the legal fiction (auction).
- Step 6: **Link to theme** — This structural frame mirrors the **cyclical resilience** of the peasantry: each auction (death) seeds the next resistance (earth). The devices are not decorative; they *are* the politics.

**REASONING:** This synthesis task demands **cross-device analysis** (imagery + metaphor), **structural awareness** (framing), and **thematic integration** — the trifecta of senior secondary competency. The 6-step scaffold ensures each claim is evidenced, explained, and elevated.

**ANSWER:** Premchand frames *Ued ka Naksha* between the **olfactory embrace of the earth** and the **metaphorical shroud of death**, tracing the peasant's forced journey from embodied producer to documented corpse. The opening — "mQijh vk; cgrk gqvk lzksr... osru euq"; nsrk gS" — roots value in the body's sensory commerce with soil: satisfaction (*osru*) is smelled, not calculated. The closing — "/eZ us /u dks iSjksa rys oqQpy Mkyk" — reveals the colonial bureaucracy's final transaction: Death (the administrator) covers Life (the sensory body) with a sheet (the legal document), converting the *smeller* into the *smelled*. Yet the frame refuses hermetic closure. The sheet *is* cloth — tactile, permeable, earth-bound. The damp earth that opened the story receives the sheeted body, leaking sensory reality into the metaphor's abstraction. This spiral (earth → auction → shroud → earth) encodes the peasantry's cyclical resilience: each bureaucratic death (auction) fertilizes the next sensory rebirth (sowing). The devices do not merely decorate; they *enact* the politics of embodiment versus erasure.

## COMPETENCY_QUESTION_1
**QUESTION:** In the scene where the contractor's men measure the field ("roZQ us Hkze dks iq"V fd;k"), the narrative inserts a **sudden shift to auditory imagery**: "xkfM+;ksa dh xM+xM+kgV rFkk eYykgksa dk dksykgy" (crunching of ants and rustling of wings). Why does Premchand interrupt the **visual-bureaucratic act** (measuring/land survey) with **insect sounds**? What does this juxtaposition reveal about the **epistemological conflict** between the colonial state and the peasant lifeworld?

**COMPETENCY:** Literary Analysis — Interrogating Device Function in Socio-Historical Context

**STEPS:**
- Step 1: Identify the two competing perceptual regimes: **Surveyor's gaze** (visual, geometric, abstract, ownership-producing) vs. **Insect sounds** (auditory, microscopic, chaotic, life-producing).
- Step 2: Explain the *measurement* as an act of **epistemic violence** — the field becomes "plot number," the crop becomes "yield estimate," the peasant becomes "defaulter."
- Step 3: Analyze the *insect sounds* as **counter-epistemology** — ants/wings are the field's *own* accounting system (pollination, decomposition, cycles) that ignores boundaries.
- Step 4: Argue that the **juxtaposition** (not integration) is deliberate: the sounds *invade* the survey moment, reminding the reader that the land is alive *before* it is measured.
- Step 5: Conclude: The auditory imagery **refuses the survey's silence** — it is the peasant lifeworld's "noise" that the colonial archive cannot record but the novel *must*.

**ANSWER:** The measurement scene enacts the colonial state's **visual appropriation** of land: "roZQ us Hkze dks iq"V fd;k" reduces the living field to linear geometry. Premchand sabotages this epistemic capture by injecting **auditory imagery of insects** — "xkfM+;ksa dh xM+xM+kgV rFkk eYykgksa dk dksykgy." The surveyor's eye seeks *silence, order, separability*; the insect sounds insist on *noise, entanglement, continuity*. Ants and wings are the field's indigenous accountants — they measure fertility in pollination, not acres. By letting this "noise" penetrate the bureaucratic moment, Premchand asserts that the **peasant lifeworld has its own irreducible epistemology** (sensory, cyclical, communal) that the colonial survey *cannot hear* but the realist novel *must amplify*. The juxtaposition is not decorative; it is a **narrative act of resistance**.

**DIFFICULTY:** hard

## COMPETENCY_QUESTION_2
**QUESTION:** A student writes: "Premchand uses the metaphor 'U;k; vkSj uhfr lc y{eh osQ gh f[kykSus gSa' to criticize Hindu rituals." **Evaluate this claim.** Does the metaphor *only* criticize rituals, or does it perform a more complex **ideological operation**? Support your evaluation with **two other metaphors** from the story that interact with this one.

**COMPETENCY:** Critical Evaluation — Metaphor Clusters and Ideological Nuance

**STEPS:**
- Step 1: **Unpack the claim's reductionism** — "criticize Hindu rituals" flattens the metaphor into a polemic. The vehicle "y{eh" (branches) implies **organic connection to a trunk** (selfishness) — rituals are not *false*; they are *functional outgrowths* of a material root (self-interest).
- Step 2: **Identify the trunk** — "y{eh" (selfishness) is the *material base* (economic power, patriarchal control). Rituals *serve* this base; they don't exist independently.
- Step 3: **Bring in Metaphor 2** — "iafMr vyksihnhu bl vxkèk ou osQ flag Fks" (IafMr = flag of helpless hope). The *flag* represents **collective resistance**; the *ritual branches* represent **structural complicity**. The story stages a **metaphoric war**: Flag vs. Branches.
- Step 4: **Bring in Metaphor 3** — "/eZ us /u dks iSjksa rys oqQpy Mkyk" (Death covers Life with sheet). The *sheet* is the **state's bureaucratic veil**; the *ritual branches* are the **tradition's ideological veil**. Both *cover* the peasant's body — one legally, one culturally.
- Step 5: **Synthesize** — The ritual metaphor does not merely "criticize religion"; it **exposes the materialist anatomy of ideology** — rituals grow *from* selfishness (class interest) and *alongside* state violence (sheet) to *double-veil* exploitation. IafMr's flag is the *only* metaphor that *unveils*.

**ANSWER:** The claim is **reductive and inaccurate**. The metaphor "rituals = branches of selfishness" performs a **materialist diagnosis**, not a religious critique. "Branches" (y{eh) implies: (1) Rituals are *organic outgrowths* of a material trunk (selfishness = economic power/patriarchy), not superstructural illusions; (2) They *share the trunk's sap* — the contractor uses rituals to legitimize seizure ("oa'kh/j us dBksj Loj esa dgkµ,d g”kkj ugha] ,d yk[k Hkh eq>s lPps ekxZ ls ugha gVk ldrs"). This metaphor **clusters** with two others to form an ideological triad:  
- **Flag** (IafMr = flag of hope) = **Resistance's visibility**  
- **Sheet** (Death = coverer of Life) = **State's legal veil**  
- **Branches** (Rituals = branches of selfishness) = **Tradition's cultural veil**  
The story reveals a **double veil** (sheet + branches) suffocating the peasant body. Only the *flag* (collective, kinetic, fragile) pierces them. Thus, the ritual metaphor's operation is **structural exposure of complicity** — far richer than "criticism of Hinduism."

**DIFFICULTY:** hard