## DEFINITION
Writing skills based on the chapter "lk;s esa /wi" refers to the ability to construct structured, evidence-based analytical responses about Nagarjun's poem, demonstrating comprehension of its socio-political themes, imagery, and poetic devices through the PEEL (Point-Evidence-Explanation-Link) framework.

## COGNITIVE_LEVEL
apply

## MASTERY_CRITERIA
The student can independently write a 150-200 word analytical answer on any aspect of the poem (theme, imagery, symbolism, tone) using the PEEL structure, embedding at least two textual references with accurate Hindi terminology, and connecting the analysis to the central idea of socio-political awakening.

## SCOPE_BOUNDARY
This node covers writing analytical answers, critical appreciation, and thematic essays specifically for "lk;s esa /wi" using PEEL structure. It does NOT cover creative writing, letter writing, or summary writing formats from the general writing skills syllabus.

## WALKTHROUGH
Imagine you're sitting in the exam hall facing a 6-mark question: "How does Nagarjun use the metaphor of darkness and light to depict socio-political change?" Your mind goes blank - you know the poem but don't know how to structure the answer. Start by identifying the core metaphor: darkness (stanzas 1-2) represents oppression/ignorance, light (stanza 3) represents awakening. Next, pick two concrete images - "nj[rksa dk lk;s" and "fly ns 'kqcku 'kk;j" - as your evidence. Then explain HOW each image works: the house darkness is personal but the dawn light is collective. Finally, link back to the poem's message about mass mobilization. The key insight: every analytical paragraph must move from textual detail to thematic significance, never just retell the poem.

## DIAGNOSTIC_QUESTION_1
What does the acronym PEEL stand for in the context of writing analytical answers for Hindi literature?

## DIAGNOSTIC_ANSWER_1
PEEL stands for Point (main argument), Evidence (textual reference), Explanation (analysis of evidence), Link (connection to theme/question). A wrong answer like "Paragraph, Example, Explain, Line" reveals the student memorized a mnemonic without understanding the analytical function of each component - they'll likely write descriptive paragraphs instead of analytical ones.

## DIAGNOSTIC_QUESTION_2
In the poem "lk;s esa /wi", the phrase "nj[rksa dk lk;s" appears in the first stanza. Explain why simply translating this as "darkness of the nights" would be an incomplete evidence point in a PEEL paragraph.

## DIAGNOSTIC_ANSWER_2
"nj[rksa dk lk;s" functions as a metaphor for systemic oppression and political darkness, not just literal night. A student who only translates literally misses the symbolic layer - they'll write "the poet describes dark nights" instead of "the poet uses night darkness as a metaphor for the ignorance enforced by feudal power structures." This reveals confusion between literal meaning and literary function, a critical gap at Class 11 level.

## DIAGNOSTIC_QUESTION_3
Write the 'Evidence' and 'Explanation' steps of a PEEL paragraph for this prompt: "Analyze the significance of the word 'fu"kke' in the final stanza." Use actual lines from the poem.

## DIAGNOSTIC_ANSWER_3
Evidence: The poet writes "rsjk fu"kke gS fly ns 'kqcku 'kk;j dh" in the third stanza. Explanation: "fu"kke" (ruler/authority) is juxtaposed with "fly ns 'kqcku 'kk;j" (dawn's red ray) - the traditional ruler is contrasted with the natural, inevitable force of awakening. The word choice suggests political authority is being challenged by a more powerful, organic force of mass consciousness. A wrong answer would merely define "fu"kke" as "king" without analyzing the contrast, showing inability to move from vocabulary to thematic interpretation.

## DIAGNOSTIC_QUESTION_4
Compare the imagery in the first two stanzas ("e;Llj", "nj[r") with the third stanza ("fly", "'kqcku 'kk;j"). What structural shift in the poem does this contrast reveal, and how should a student reflect this in their answer organization?

## DIAGNOSTIC_ANSWER_4
The shift moves from static, oppressive imagery (closed house, dark nights) to dynamic, liberating imagery (open sky, dawn light). This mirrors the poem's thematic movement from individual suffering to collective awakening. A strong answer organizes paragraphs chronologically: Paragraph 1 analyzes stanzas 1-2 as establishment of oppression; Paragraph 2 analyzes stanza 3 as rupture and hope. A student who treats all stanzas equally misses the poem's dramatic structure - they'll write a list of images instead of an argument about progression.

## DIAGNOSTIC_QUESTION_5
Evaluate this student's thesis statement for a 6-mark question on the poem: "Nagarjun's poem is about how poor people suffer in dark houses but then the sun rises and they become happy." Is this thesis exam-ready? Justify your evaluation.

## DIAGNOSTIC_ANSWER_5
No, this thesis is not exam-ready. It reduces a complex political allegory to a simplistic narrative, uses informal language ("poor people", "happy"), and misses the collective action dimension ("yksxksa dh vksj"). A Class 11 thesis must use analytical terminology: "Nagarjun employs the extended metaphor of domestic darkness to critique feudal oppression, culminating in the dawn imagery that symbolizes collective political consciousness." The weak thesis reveals the student cannot distinguish between plot summary and thematic argument - a fundamental skill gap for board exams.

## DIAGNOSTIC_QUESTION_6
Create an opening paragraph (Point + Evidence) for this question: "How does the poem depict the relationship between individual suffering and collective resistance?" Use the PEEL framework and reference specific poetic devices.

## DIAGNOSTIC_ANSWER_6
Point: Nagarjun structures the poem to show individual suffering as the catalyst for collective resistance. Evidence: The first stanza's domestic imagery - "dgk¡ rks r; Fkk fpjkxk¡ gjsoQ ?kj osQ fy,] dgk¡ fpjkx e;Llj ugha 'kgj osQ fy," - uses parallel structure and repetition of "dgk¡" to universalize personal grief, while the shift to plural "pyks ;gk¡ ls pysa vkSj mez Hkj osQ fy," in the second stanza transforms individual lament into a collective call to action. A poor answer would quote lines without naming the device (parallelism, shift from singular to plural) or explaining the structural function, showing inability to connect form to meaning.

## COMMON_MISCONCEPTION
Students believe that "writing based on the chapter" means summarizing the poem stanza-by-stanza in their own words. They write: "First stanza says there was a house for the bird, second stanza says nights are dark, third stanza says sun rises." This happens because Class 10 comprehension questions often accepted retelling, but Class 11 analytical writing requires ARGUMENT - a claim about the poem's meaning supported by HOW the poet achieves it (devices, structure, word choice). The misconception is reinforced when teachers ask "explain the poem" without modeling the difference between paraphrase and analysis.

## ON_FAILURE
If a student submits a summary instead of analysis: (1) Return the answer with each sentence labeled "Retell" or "Analyze" - they'll see 90% "Retell". (2) Give them a 3-sentence template: "The poet uses [device] in [line/stanza] to show [theme]. This [device] works by [mechanism]. This connects to the central idea of [theme] because [reason]." (3) Have them rewrite ONE paragraph using only this template with the poem's actual lines. (4) Only after mastering one analytical paragraph, expand to full answer.

## BUILDS_ON
c11_hin_ar_cbse_13_008 (Literary Devices: Imagery and Metaphor) and c11_hin_ar_cbse_13_013 (Critical Thinking: Analysis and Interpretation)

## LEADS_TO
c11_hin_ar_cbse_13_015 (Speaking and Listening: Discussion Points) where students defend their written interpretations orally

## PREREQUISITE_NODE_IDS
c11_hin_ar_cbse_13_008, c11_hin_ar_cbse_13_009, c11_hin_ar_cbse_13_012, c11_hin_ar_cbse_13_013, c11_hin_ar_cbse_13_001, c11_hin_ar_cbse_13_007, c11_hin_ar_cbse_13_010, c11_hin_ar_cbse_13_011

## PREREQUISITE_REASONS
c11_hin_ar_cbse_13_008: Student must identify and name imagery/metaphor (e.g., "nj[rksa dk lk;s") to use as Evidence in PEEL
c11_hin_ar_cbse_13_009: Student must recognize irony/symbolism (e.g., "fu"kke" vs "fly") to write Explanation step
c11_hin_ar_cbse_13_012: Student must distinguish literal vs inferential meaning to avoid summary trap
c11_hin_ar_cbse_13_013: Student must have practiced interpretation to generate Point and Link steps independently
c11_hin_ar_cbse_13_001: "Before You Read: की समझ आवश्यक है, क्योंकि यह नोड (Writing skills based on the chapter "lk;s esa /wi" refers to the ability to construct stru...) इसी आधार पर आगे बढ़ता है।  
c11_hin_ar_cbse_13_007: Writing skills (analytical paragraph, critical appreciation) require the PEEL structure: Point (secondary theme), Evidence (lines), Explanation (analysis), Link (to primary theme) — this node teaches the P and E.  
c11_hin_ar_cbse_13_010: Writing tasks (e.g., analytical paragraph) demand the ability to embed and explain key vocabulary as textual evidence.  
c11_hin_ar_cbse_13_011: Analytical writing tasks demand the metalanguage (case, aspect, samasa) developed here to structure arguments.  

## FORWARD_NODE_IDS
c12_hin_a_cbse_05_014, c12_hin_ar_cbse_13_014

## FORWARD_REASONS
c12_hin_a_cbse_05_014: अगला तार्किक चरण: Writing Skills based on the chapter refers to the ability to compose structured, evidence-based resp... इस नोड की अवधारणाओं को सीधे उपयोग/विस्तारित करता है।  
c12_hin_ar_cbse_13_014: Establishes the PEEL writing framework and practice with a similar text; Class 12 deepens it with more complex themes.  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
none

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_13_008 -> c11_hin_ar_cbse_13_014 -> c11_hin_ar_cbse_13_015

## THIS_FORMULA
PEEL Structure for Poetry Analysis: Point (thematic claim) → Evidence (specific line + device name) → Explanation (how device creates meaning) → Link (back to question/central idea)

## FORMULA_VARIABLES
Point = Analytical claim about theme/technique; Evidence = Direct reference (line/stanza) + Device name; Explanation = Mechanism of meaning-making; Link = Connection to prompt/central idea

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
linguistic

## CROSS_SUBJECT
c11_history_nationalism | The poem's theme of collective awakening against feudal oppression parallels the history of peasant movements and nationalist mobilization in colonial India
c11_politicalscience_democracy | The contrast between "fu"kke" (traditional authority) and "fly ns 'kqcku 'kk;j" (organic people's power) illustrates the political theory concept of legitimacy shift from monarchical to popular sovereignty

## PREREQ_CONCEPT
Ability to distinguish between paraphrasing (what happens) and analyzing (how meaning is created through poetic choices)

## PREREQ_BEFORE
Student must be able to identify at least 3 poetic devices in the poem and explain their effect in one sentence each

## PREREQ_STUCK
Review c11_hin_ar_cbse_13_008 (Imagery and Metaphor) and c11_hin_ar_cbse_13_009 (Irony and Symbolism) - practice naming devices with effect statements

## WORKED_EXAMPLE_1
PROBLEM: A student writes this answer for a 4-mark question: "The poem shows darkness and light. In first stanza, bird needs house. In second stanza, nights are dark. In third stanza, sun rises. This shows hope." Transform this into a PEEL-structured analytical paragraph.

STEPS:
- Step 1: Identify the core problem - the answer is a stanza-by-stanza summary with no analytical claim, no device identification, and no thematic vocabulary
- Step 2: Extract the latent argument - the student intuitively grasps the darkness-to-light progression but cannot articulate it as a crafted poetic strategy
- Step 3: Construct the Point: "Nagarjun uses the structural progression from domestic darkness to natural dawn to symbolize the shift from feudal subjugation to collective political consciousness."
- Step 4: Select Evidence with devices: Stanza 1 - "e;Llj" (metaphor for false security); Stanza 2 - "nj[rksa dk lk;s" (extended metaphor for systemic oppression); Stanza 3 - "fly ns 'kqcku 'kk;j" (symbol of inevitable awakening)
- Step 5: Write Explanation for each: The bird's house represents compromised safety under feudalism; the plural "nj[rksa" universalizes the experience; the dawn imagery is deliberately natural (not divine) to emphasize human agency
- Step 6: Craft Link: "This structural arc mirrors the historical trajectory from passive endurance to active resistance that characterizes Nagarjun's revolutionary poetics."

REASONING: The transformation works by moving from WHAT the poem says (summary) to HOW the poem means (analysis). Each PEEL component forces the writer to make an analytical choice: Point requires a thematic claim, Evidence requires device identification, Explanation requires mechanism analysis, Link requires thematic synthesis.

ANSWER: Nagarjun uses the structural progression from domestic darkness to natural dawn to symbolize the shift from feudal subjugation to collective political consciousness. In the first stanza, the metaphor "e;Llj" (nest/house) represents the false security of compromised existence under oppression. The second stanza extends this through "nj[rksa dk lk;s" - the plural "nights" universalizes individual suffering into systemic darkness. The rupture comes in stanza three where "fly ns 'kqcku 'kk;j" (dawn's red ray) emerges as a natural, inevitable force contrasting with the artificial "fu"kke" (ruler). This structural arc mirrors the historical trajectory from passive endurance to active resistance that characterizes Nagarjun's revolutionary poetics.

## WORKED_EXAMPLE_2
PROBLEM: Write a complete 6-mark answer for: "Analyze how Nagarjun uses the bird imagery in the first stanza to establish the poem's central conflict." Use PEEL structure across two paragraphs.

STEPS:
- Step 1: Deconstruct the prompt - it asks for analysis of SPECIFIC imagery (bird) in SPECIFIC location (stanza 1) for SPECIFIC function (establishing central conflict)
- Step 2: Formulate Point for Paragraph 1: "The bird's futile search for a house embodies the individual's vulnerability under systemic injustice."
- Step 3: Select Evidence: "dgk¡ rks r; Fkk fpjkxk¡ gjsoQ ?kj osQ fy,] dgk¡ fpjkx e;Llj ugha 'kgj osQ fy," - identify devices: repetition ("dgk¡"), contrast ("gjsoQ ?kj" vs "e;Llj"), irony (bird needs shelter but finds none)
- Step 4: Write Explanation: The repetition of "dgk¡" (somewhere) creates aimless wandering; "e;Llj" (nest) suggests natural right to shelter denied by "gjsoQ ?kj" (others' houses); the irony - a bird, symbol of freedom, cannot find its natural home
- Step 5: Link Paragraph 1: "This establishes the central conflict: the denial of basic dignity that fuels the poem's political awakening."
- Step 6: Formulate Point for Paragraph 2: "The bird's silence in stanza 1 contrasts with the collective voice in stanza 2, foreshadowing the shift from individual grief to mass mobilization."
- Step 7: Evidence: Stanza 1 has no direct speech; Stanza 2 opens with imperative "pyks ;gk¡ ls pysa vkSj mez Hkj osQ fy," - device: shift from description to address, singular to plural
- Step 8: Explanation: The bird's mute suffering becomes the collective's articulate demand; "mez Hkj" (fill the granary) transforms shelter-seeking into resource-claiming
- Step 9: Final Link: "Thus the bird imagery operates as a microcosm of the poem's macro-movement: from voiceless victim to empowered agent."

REASONING: This example demonstrates multi-paragraph PEEL writing where each paragraph has a distinct analytical focus (establishment vs development of conflict) but both serve the overall argument. The bird imagery is not just "mentioned" - its formal properties (repetition, contrast, silence vs speech) are analyzed as meaning-making choices.

ANSWER: The bird's futile search for a house embodies the individual's vulnerability under systemic injustice. The opening lines "dgk¡ rks r; Fkk fpjkxk¡ gjsoQ ?kj osQ fy,] dgk¡ fpjkx e;Llj ugha 'kgj osQ fy," use repetition of "dgk¡" to convey aimless wandering, while the contrast between "gjsoQ ?kj" (others' houses) and "e;Llj" (natural nest) highlights the denial of organic belonging. The irony - a bird, nature's symbol of freedom, unable to secure its natural shelter - establishes the central conflict: the systemic denial of basic dignity that fuels the poem's political awakening.

This individual silencing contrasts sharply with the collective voice emerging in stanza 2, foreshadowing the shift from individual grief to mass mobilization. Stanza 1 offers no direct speech - the bird suffers mutely. Stanza 2 opens with the imperative "pyks ;gk¡ ls pysa vkSj mez Hkj osQ fy," addressing a collective "you" and replacing shelter-seeking ("?kj") with resource-claiming ("mez Hkj"). The bird's mute suffering thus becomes the collective's articulate demand. The bird imagery operates as a microcosm of the poem's macro-movement: from voiceless victim to empowered agent.

## WORKED_EXAMPLE_3
PROBLEM: A board exam question asks: "Nagarjun's poem transforms personal sorrow into political hope. Discuss with reference to the progression of imagery across three stanzas." Write a 150-word answer integrating PEEL structure with comparative analysis.

STEPS:
- Step 1: Analyze the prompt's demand - "transforms personal sorrow into political hope" is the given thesis; "progression of imagery across three stanzas" is the required evidence base; "discuss" means evaluate the effectiveness of this transformation
- Step 2: Map imagery progression: Stanza 1 (domestic/bird imagery - personal), Stanza 2 (night/household imagery - communal suffering), Stanza 3 (dawn/sky imagery - political hope)
- Step 3: Draft thesis-driven Point: "The poem's three-stanza architecture enacts a deliberate metamorphosis from privatized grief to politicized hope through escalating spatial and temporal imagery."
- Step 4: Paragraph 1 (Stanza 1): Evidence - "fpjkx", "e;Llj", "?kj"; Devices - diminutive imagery, domestic confinement; Explanation - bird's sorrow is individualized, apolitical, contained within "?kj"
- Step 5: Paragraph 2 (Stanza 2): Evidence - "nj[rksa dk lk;s", "pyks ;gk¡ ls pysa"; Devices - pluralization, imperative mood, spatial expansion; Explanation - "nj[rksa" (plural nights) universalizes; "pyks" (leave) commands movement from private to public sphere
- Step 6: Paragraph 3 (Stanza 3): Evidence - "fly", "'kqcku 'kk;j", "cgj"; Devices - cosmic imagery, color symbolism (red=revolution), temporal finality; Explanation - dawn is inevitable, collective, irreversible - "cgj" (moment) suggests historical rupture
- Step 7: Synthesis Link: "The imagery progression is not decorative but dialectical: each stanza's spatial expansion (nest→house→sky) and temporal shift (moment→nights→dawn) materializes the political argument that personal pain, when collectivized, becomes revolutionary force."

REASONING: This example shows advanced PEEL usage where the thesis is provided by the question, and the student must structure evidence to prove it. The comparative analysis across stanzas requires explicit transitional language ("contrasts sharply", "escalating", "metamorphosis") - a key Class 11 skill distinguishing from Class 10's single-text analysis.

ANSWER: The poem's three-stanza architecture enacts a deliberate metamorphosis from privatized grief to politicized hope through escalating spatial and temporal imagery. Stanza 1 confines sorrow within domestic diminutives - "fpjkx" (bird), "e;Llj" (nest), "?kj" (house) - where the bird's search remains individualized and apolitical, trapped in the feudal household economy. Stanza 2 ruptures this containment through pluralization and imperative force: "nj[rksa dk lk;s" universalizes night as systemic oppression, while "pyks ;gk¡ ls pysa" commands exodus from private suffering into public action. The spatial shift from "?kj" to "mez" (granary/fields) redefines need from shelter to sustenance. Stanza 3 completes the transformation through cosmic inevitability: "fly ns 'kqcku 'kk;j" (dawn's red ray) deploys color symbolism (red = revolutionary rupture) and "cgj" (moment) marks historical rupture. The imagery progression is dialectical, not decorative: each stanza's spatial expansion (nest→house→sky) and temporal deepening (moment→nights→dawn) materializes the argument that personal pain, collectivized, becomes revolutionary force.

## COMPETENCY_QUESTION_1
QUESTION: You are helping a Class 11 peer who wrote this answer for a 3-mark question on "lk;s esa /wi": "The poet uses many metaphors like nest, night, and dawn. Nest means home. Night means sadness. Dawn means hope. So the poem is about hope." Identify exactly THREE specific weaknesses in this answer relative to Class 11 board expectations, and rewrite ONE paragraph demonstrating the correct analytical approach for the 'night' metaphor.

COMPETENCY: Critical evaluation of peer writing and analytical rewriting

STEPS:
- Step 1: Identify Weakness 1 - Device naming without analysis: "uses many metaphors" lists but doesn't explain HOW each metaphor functions
- Step 2: Identify Weakness 2 - Reductive equivalence: "Night means sadness" treats metaphor as code (A=B) rather than as complex meaning-making
- Step 3: Identify Weakness 3 - Missing structural awareness: No mention of how "night" operates differently in stanza 2 vs stanza 3, or its relationship to other images
- Step 4: Rewrite for 'night' metaphor using PEEL: Point - "The metaphor 'nj[rksa dk lk;s' transforms temporal darkness into structural oppression." Evidence - "nj[rksa dk lk;s yxrh gS" (stanza 2) with device: pluralization + spatial metaphor. Explanation - "nk[rksa" (plural) makes darkness systemic not episodic; "lk;s" (house) spatializes it as inhabited confinement. Link - "This redefines sorrow as political condition, preparing the collective call to action."

ANSWER: Three weaknesses: (1) Lists metaphors without analyzing their poetic function - "uses many metaphors" is identification, not analysis. (2) Reduces metaphors to simple equations ("Night means sadness") ignoring connotation, context, and complexity. (3) Treats images in isolation, missing the poem's structural progression from stanza 2's "nj[rksa dk lk;s" to stanza 3's "fly ns 'kqcku 'kk;j".

Rewritten paragraph: The metaphor "nj[rksa dk lk;s" transforms temporal darkness into structural oppression. In stanza 2, "nj[rksa dk lk;s yxrh gS" employs pluralization ("nj[rksa") to make darkness systemic rather than episodic, while the spatial metaphor "lk;s" (house) reconfigures time as inhabited confinement. This redefines sorrow as a political condition imposed by feudal structures, not merely personal grief. The plural "pyks" (leave) that follows transforms this diagnosis into a collective directive, making the night metaphor the pivot from passive endurance to active resistance.

DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: A 6-mark board question states: "The poem 'lk;s esa /wi' is structured as a journey from darkness to light. Analyze how the poet's language choices in EACH stanza advance this journey." Write a complete answer using a THREE-PARAGRAPH PEEL structure (one paragraph per stanza) that demonstrates stanza-specific language analysis while maintaining a unified argument about the journey motif.

COMPETENCY: Multi-paragraph analytical writing with structural coherence

STEPS:
- Step 1: Establish unified thesis (Point for whole answer): "Nagarjun engineers a linguistic journey from feudal darkness to revolutionary dawn through calculated shifts in diction, mood, and agency across three stanzas."
- Step 2: Paragraph 1 (Stanza 1 - Departure): Focus on language of confinement - "gjsoQ ?kj", "e;Llj", "fpjkx"; passive voice constructions; diminutive nouns; absence of verbs of action
- Step 3: Paragraph 2 (Stanza 2 - Transit): Focus on language of rupture - imperative "pyks", plural "nj[rksa", collective "mez Hkj"; shift from noun-heavy to verb-driven syntax; spatial prepositions ("ls", "osQ fy,")
- Step 4: Paragraph 3 (Stanza 3 - Arrival): Focus on language of inevitability - "rsjk" (therefore), "fu"kke" vs "fly", natural imagery as political statement; declarative certainty replacing imperative urging
- Step 5: Synthetic Link: "The journey is completed not by reaching a destination but by the language itself becoming the vehicle of transformation - from the bird's silent search to the dawn's spoken certainty."

ANSWER: Nagarjun engineers a linguistic journey from feudal darkness to revolutionary dawn through calculated shifts in diction, mood, and agency across three stanzas.

Stanza 1 establishes the point of departure through a lexicon of confinement. Nouns dominate - "fpjkx" (bird), "e;Llj" (nest), "?kj" (house) - all diminutive, domestic, and possessed by others ("gjsoQ ?kj"). The verb "Fkk" (was) traps the bird in past tense passivity; no imperative, no future, no agency. The repetition of "dgk¡" (somewhere) creates semantic drift without direction. This language enacts the feudal condition: subjectivity erased, shelter conditional, movement impossible.

Stanza 2 initiates transit through syntactic rupture. The imperative mood erupts - "pyks" (leave), "Hkj" (fill) - converting description into command. Pluralization transforms the subject: "nj[rksa" (nights), "pyks" (you all), "mez" (granaries/fields). Spatial prepositions ("ls" - from, "osQ fy," - for) replace static possession with directional movement. The syntax itself migrates from noun-phrases to verb-chains, enacting the shift from object to agent.

Stanza 3 arrives at dawn through the language of inevitability. The causal "rsjk" (therefore) replaces the imperative with declarative certainty. "fu"kke" (ruler) is named only to be dwarfed by "fly ns 'kqcku 'kk;j" (dawn's red ray) - political authority rendered insignificant before natural law. The final image "cgj" (moment) collapses historical time into revolutionary instant. The journey completes not at a destination but in the language itself: from the bird's silent search to the dawn's spoken certainty, diction has become the vehicle of liberation.

DIFFICULTY: hard