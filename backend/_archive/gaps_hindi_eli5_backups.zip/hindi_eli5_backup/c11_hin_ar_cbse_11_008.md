## DEFINITION
Imagery is the use of vivid and descriptive language that appeals to the senses (sight, sound, smell, touch, taste) to create mental pictures. Metaphor is a figure of speech that directly compares two unlike things by stating one is the other, without using 'like' or 'as'. In "Ghar ki Yaad", the poet uses imagery of the house, the father's voice, the burning lamp, and the fragrance of earth to evoke nostalgia, and metaphors such as the house becoming a 'temple of memories' and the father's voice a 'guiding light' to deepen the emotional resonance.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student can identify at least three distinct images and two metaphors in the poem, explain how each appeals to a specific sense, and articulate how they collectively reinforce the central theme of longing for home and the pain of separation.

## SCOPE_BOUNDARY
This node covers the identification, analysis, and interpretation of imagery (visual, auditory, olfactory, tactile) and metaphor in the poem "Ghar ki Yaad". It does not cover other literary devices such as irony, symbolism, personification, or simile, which are addressed in subsequent nodes.

## WALKTHROUGH
Imagine you are sitting in a hostel room far from home, and a sudden smell of rain on dry earth (mitti ki khushboo) transports you back to your childhood courtyard. That sensory trigger is exactly how imagery works in poetry. To begin analyzing "Ghar ki Yaad", first read the poem aloud and mark every word or phrase that makes you see, hear, smell, touch, or taste something. Next, circle comparisons where the poet says one thing *is* another (e.g., 'ghar mandir hai' – home is a temple). Then ask: which sense does each image target? What emotion does the metaphor amplify? Finally, connect each device to the poet's ache for his father's presence and the irretrievable past. The key insight is that Bachchan doesn't just describe memory – he makes the reader inhabit it through layered sensory details and metaphorical transformations.

## DIAGNOSTIC_QUESTION_1
What is the difference between imagery and metaphor? Give one example of each from the poem "Ghar ki Yaad" (you may describe the example without quoting full lines).

## DIAGNOSTIC_ANSWER_1
Imagery refers to descriptive language that appeals to the five senses (e.g., the visual image of the 'burning lamp' in the dark house, or the olfactory image of 'fragrance of earth'). Metaphor is a direct comparison between two unlike things without using 'like' or 'as' (e.g., the poet calls the house a 'temple of memories' or the father's voice a 'guiding light'). A wrong answer that confuses the two (e.g., calling a metaphor an image) reveals the student cannot distinguish between sensory evocation and figurative comparison.

## DIAGNOSTIC_QUESTION_2
In the poem, the poet writes about the 'fragrance of earth' (mitti ki sugandh) and the 'sound of father's footsteps'. Explain how these two images target different senses and what emotions they evoke in the context of the poem.

## DIAGNOSTIC_ANSWER_2
The 'fragrance of earth' appeals to the olfactory sense (smell) and evokes a deep, primal nostalgia for the soil of one's homeland, suggesting rootedness and loss. The 'sound of father's footsteps' appeals to the auditory sense and evokes longing for paternal protection and the rhythm of a familiar daily life. A wrong answer that treats both as merely 'descriptive' or assigns the same emotion to both shows the student cannot differentiate sensory channels or link them to specific emotional nuances.

## DIAGNOSTIC_QUESTION_3
Identify a metaphor in the poem where the house is compared to something else. Then, using that metaphor, explain how the poet transforms the physical house into an emotional space.

## DIAGNOSTIC_ANSWER_3
One metaphor is 'ghar mandir hai' (home is a temple). The physical house (bricks, walls, rooms) becomes a sacred space where memories are worshipped, and the poet's longing becomes a form of devotion. The steps: (1) locate the metaphor, (2) identify the two terms (house and temple), (3) explain the grounds of comparison (sanctity, reverence, ritual), (4) show how this shifts the reader's perception from a building to an emotional sanctuary. A wrong answer that only identifies the metaphor without explaining the transformation indicates surface-level recognition without analytical depth.

## DIAGNOSTIC_QUESTION_4
Compare the use of visual imagery in the first half of the poem (the dark house, the lamp) with the auditory imagery in the later half (father's voice, the poet's own voice). How do these two clusters of imagery work together to build the poem's movement from absence to presence?

## DIAGNOSTIC_ANSWER_4
The early visual imagery (darkness, a single lamp) establishes isolation and the physical emptiness of the house, emphasizing the poet's solitary vigil. The later auditory imagery (father's remembered voice, the poet's internal dialogue) fills that emptiness with sound, suggesting that memory animates the space. Together, they move the poem from a static picture of loss to a dynamic re-enactment of connection. A wrong answer that lists images without showing their structural relationship misses the poem's narrative arc.

## DIAGNOSTIC_QUESTION_5
Evaluate the effectiveness of the metaphor 'the house is a temple of memories' versus a possible simile 'the house is like a temple of memories'. Which creates a stronger emotional impact for the theme of irreversible loss, and why?

## DIAGNOSTIC_ANSWER_5
The metaphor is more effective because it asserts identity ('is') rather than similarity ('like'), making the house *become* the sacred space, leaving no distance between the object and its meaning. This absolute equation mirrors the poet's inability to separate his present self from his past; the loss is total and the memory is not just similar to worship – it *is* worship. A wrong answer that prefers the simile or sees no difference fails to grasp how metaphor's directness intensifies the theme of irrevocable fusion between place and emotion.

## DIAGNOSTIC_QUESTION_6
Write a four-line stanza (in Hindi or English) that uses at least two different sensory images and one metaphor to express your own memory of a place you miss. Do not copy from the poem.

## DIAGNOSTIC_ANSWER_6
A strong answer will include: (1) two distinct sensory images (e.g., 'the clatter of steel plates at dawn' – auditory; 'the cool marble under bare feet' – tactile), (2) one clear metaphor (e.g., 'that kitchen was a heartbeat'), and (3) a coherent emotional tone. A poor answer that uses only vague adjectives ('beautiful', 'nice'), mixes senses without clarity, or offers a simile instead of a metaphor shows the student cannot yet generate original figurative language.

## COMMON_MISCONCEPTION
Students often think that any descriptive phrase is imagery, and any comparison is a metaphor. For example, they may label 'the house was old and big' as imagery (it is factual, not sensory) or 'the house was like a palace' as a metaphor (it is a simile because of 'like'). In "Ghar ki Yaad", they might miss the metaphor 'ghar mandir hai' because it lacks a verb like 'is' in English, or they might treat the repeated phrase 'ikuh fxj jgk gS' as mere repetition rather than an auditory image of a persistent memory. This error arises because they rely on surface keywords instead of analyzing the function of the language.

## ON_FAILURE
If a student cannot distinguish imagery from metaphor, do this: (1) Give them three short sentences: one factual, one with imagery, one with metaphor. Ask them to label each and justify. (2) Have them close their eyes and describe a childhood memory using only senses – then ask which words created the strongest picture/sound/smell. (3) Show the line 'ghar mandir hai' and ask: 'Does the poet say the house is *like* a temple, or *is* a temple?' (4) Finally, have them rewrite a factual sentence into an image, then into a metaphor, explaining the shift each time.

## BUILDS_ON
This node builds on the student's basic understanding of the poem's narrative (c11_hin_ar_cbse_11_002) and its central theme of separation and memory (c11_hin_ar_cbse_11_006).

## LEADS_TO
This node enables the analysis of irony and symbolism in the same poem (c11_hin_ar_cbse_11_009) and provides the analytical foundation for critical interpretation (c11_hin_ar_cbse_11_013) and writing skills (c11_hin_ar_cbse_11_014).

## PREREQUISITE_NODE_IDS
c11_hin_ar_cbse_11_001, c11_hin_ar_cbse_11_002, c11_hin_ar_cbse_11_003, c11_hin_ar_cbse_11_004, c11_hin_ar_cbse_11_005, c11_hin_ar_cbse_11_006, c11_hin_ar_cbse_11_007
## PREREQUISITE_REASONS
c11_hin_ar_cbse_11_001: Provides historical and biographical context (Bachchan's life, freedom struggle) that shapes the poem's emotional landscape.
c11_hin_ar_cbse_11_002: Establishes the poem's narrative structure (memory unfolding in stages) so devices can be mapped to structural shifts.
c11_hin_ar_cbse_11_003: Clarifies the setting (the ancestral house, the night) which is the canvas for the imagery.
c11_hin_ar_cbse_11_004: Identifies the protagonist (the poet himself) whose perspective generates the images and metaphors.
c11_hin_ar_cbse_11_005: Explains the father's role, crucial for understanding the auditory imagery of his voice.
c11_hin_ar_cbse_11_006: The primary theme (longing for home) is the organizing principle that all imagery and metaphor serve.
c11_hin_ar_cbse_11_007: Secondary themes (time, identity, duty) deepen the metaphorical resonances.

## FORWARD_NODE_IDS
c11_hin_ar_cbse_11_009, c11_hin_ar_cbse_11_010, c11_hin_ar_cbse_11_011, c11_hin_ar_cbse_11_012, c11_hin_ar_cbse_11_013, c11_hin_ar_cbse_11_014, c11_hin_ar_cbse_11_015, c12_hin_a_cbse_04_008, c12_hin_a_cbse_05_008, c12_hin_a_cbse_16_008

## FORWARD_REASONS
c11_hin_ar_cbse_11_009: Irony and symbolism often coexist with imagery and metaphor; understanding the latter prepares students to see how symbols extend metaphors.
c11_hin_ar_cbse_11_010: Vocabulary in context relies on recognizing how words function as images or metaphorical vehicles.
c11_hin_ar_cbse_11_011: Grammar analysis (e.g., verb forms in metaphors) builds on identifying figurative constructions.
c11_hin_ar_cbse_11_012: Comprehension questions often ask 'what does this image suggest?' or 'explain the metaphor'.
c11_hin_ar_cbse_11_013: Critical interpretation requires synthesizing multiple devices, starting with imagery and metaphor.
c11_hin_ar_cbse_11_014: Writing skills (e.g., analytical paragraphs) use the PEEL structure taught here.
c11_hin_ar_cbse_11_015: Discussion points often revolve around the effectiveness of specific images/metaphors.
c12_hin_a_cbse_04_008: Olfactory imagery in "Gandh" — expands sensory repertoire beyond visual.  
c12_hin_a_cbse_05_008: Introduces extended metaphor tracking across stanzas.  
c12_hin_a_cbse_16_008: Practices comparative analysis of two metaphors in one text.  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
none

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_11_006 -> c11_hin_ar_cbse_11_008 -> c11_hin_ar_cbse_11_009

## THIS_FORMULA
Imagery = Sensory Word/Phrase + Target Sense (Visual/Auditory/Olfactory/Tactile/Gustatory) + Evoked Emotion. Metaphor = Tenor (Subject) + Vehicle (Object of Comparison) + Ground (Shared Attribute) without 'like/as'.

## FORMULA_VARIABLES
Sensory Word/Phrase: The specific language used (e.g., 'burning lamp'). Target Sense: Which of the five senses is engaged. Evoked Emotion: The feeling the image triggers in context. Tenor: The subject being described (e.g., 'house'). Vehicle: The thing it is compared to (e.g., 'temple'). Ground: The shared quality (e.g., 'sanctity, reverence').

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
analytical

## CROSS_SUBJECT
c11_history_indian_nationalism | The poem reflects the personal cost of the freedom struggle; Bachchan's longing for home mirrors the displacement of many Indians during the independence movement, and analyzing imagery helps students connect personal emotion to historical context.
c11_geography_migration_and_urbanization | The poem's contrast between the ancestral village house and the poet's current urban exile illustrates rural-to-urban migration; sensory images of earth, lamp, and father's voice map onto geographical concepts of place attachment and loss of cultural landscape.

## PREREQ_CONCEPT
The student must understand the poem's literal storyline: a poet away from home, remembering his father and childhood house at night.

## PREREQ_BEFORE
Before starting, the student should be able to summarize the poem in 3-4 sentences and identify the speaker, setting, and primary emotion.

## PREREQ_STUCK
If stuck, review the poem's narrative structure (c11_hin_ar_cbse_11_002) and the character of the father (c11_hin_ar_cbse_11_005) to ground the devices in the story.

## WORKED_EXAMPLE_1
PROBLEM: Analyze the visual and olfactory imagery in the opening stanza of "Ghar ki Yaad" and explain how they establish the poem's mood.
STEPS:
- Step 1: Read the opening stanza aloud and underline every word that triggers a sense. Note 'vkt ikuh fxj jgk gS' (darkness reigns), 'jkr Hkj fxjrk jgk gS' (cold spreads), 'izk.k eu f?kjrk jgk gS' (heart trembles with pain).
- Step 2: Classify each: 'darkness' and 'cold' are visual/tactile; 'heart trembles' is internal tactile/kinesthetic.
- Step 3: Identify the olfactory image in the next lines: '?kj fd eq>ls nwj gS tks' (the house has a fragrance) – this is smell.
- Step 4: Determine the mood: darkness and cold create loneliness and desolation; the sudden fragrance introduces a bittersweet nostalgia, softening the bleakness.
- Step 5: Connect to theme: the mood oscillates between present emptiness and past warmth, mirroring the poet's divided consciousness.
REASONING: By systematically categorizing sensory images and tracking their emotional valence, we see how Bachchan uses sensory contrast to enact the conflict between absence and memory.
ANSWER: The opening stanza uses visual/tactile imagery (darkness, cold) to establish a mood of isolation, then introduces olfactory imagery (fragrance of the house) to evoke a poignant longing, setting up the poem's central tension between the cold present and the warm past.

## WORKED_EXAMPLE_2
PROBLEM: Identify the metaphor in the lines where the poet addresses the house as 'ifjrki dk ?kj' (house of memory) and explain its function.
STEPS:
- Step 1: Locate the phrase 'ifjrki dk ?kj' in the poem (in the stanza beginning '?kj u"kj esa frj jgk gS').
- Step 2: Identify the tenor: the physical house. Identify the vehicle: a house belonging to memory (or memory personified as a dweller).
- Step 3: Determine the ground: the house is no longer a physical shelter but a vessel that holds and protects memories, just as a house holds people.
- Step 4: Analyze the effect: this metaphor transforms the house from a place the poet left into a place that *holds* him, reversing the relationship – the poet becomes the guest, memory the host.
- Step 5: Link to the poem's progression: this metaphor prepares for the later realization that the poet himself has become the memory ('eSa e"ks esa gw¡ lgh gS').
REASONING: Metaphors in this poem often work by reversing roles (house shelters memory → memory shelters poet), and tracking this reversal reveals the poem's philosophical depth.
ANSWER: The metaphor 'house of memory' redefines the house as a container of the past, making the poet a visitor in his own childhood home, which underscores the irreversibility of time and the poet's alienation from his former self.

## WORKED_EXAMPLE_3
PROBLEM: Compare the metaphor of the 'lamp' (deepak) in the poem with the metaphor of the 'father's voice' as a guiding light. How do both metaphors work together to represent hope and continuity?
STEPS:
- Step 1: Find the lamp reference: 'vkt xhrk ikB djosQ' (now the lamp burns) – the lamp is a metaphor for persistent memory/consciousness.
- Step 2: Find the father's voice reference: 'firk th ftudks cq<+kik' (father who scolded) and later 'firk th us dgk gksxk' (father will say) – the voice becomes a metaphor for moral guidance and continuity.
- Step 3: Analyze the lamp metaphor: it burns alone in the dark house, fragile but persistent, symbolizing the poet's solitary act of remembering.
- Step 4: Analyze the voice metaphor: the father's anticipated words ('gk; fdruk lgk gksxk') represent an unbroken thread of values and identity that survives physical absence.
- Step 5: Synthesize: the lamp is the *internal* light of memory; the father's voice is the *external* legacy that fuels it. Together they suggest that memory (lamp) is sustained by tradition (voice).
- Step 6: Connect to board exam answer structure: State point, quote evidence (describe lines), explain device, link to theme.
REASONING: This multi-step comparison requires identifying two distinct metaphors, analyzing their individual vehicles and grounds, and then synthesizing their thematic interplay – a skill directly tested in long-answer questions.
ANSWER: The lamp metaphor represents the poet's fragile but self-sustaining memory burning in the darkness of separation, while the father's voice metaphor represents the enduring moral and cultural inheritance that gives that memory direction. Together, they affirm that even in exile, the poet's identity is illuminated by both personal recollection and ancestral wisdom.

## COMPETENCY_QUESTION_1
QUESTION: In "Ghar ki Yaad", the poet uses the repeated refrain 'ikuh fxj jgk gS' (darkness reigns) at the end of several stanzas. Is this primarily an auditory image, a visual image, or a metaphor? Justify your answer by explaining how the repetition functions at the sensory and symbolic levels.
COMPETENCY: Literary analysis – identifying and justifying the classification of a literary device with textual evidence.
STEPS:
- Step 1: Recognize that 'ikuh' (darkness) is a visual concept, but 'fxj jgk gS' (reigns/spreads) personifies it, suggesting a metaphorical force.
- Step 2: Note the repetition creates an auditory pattern (rhythm, sound) when read aloud.
- Step 3: Argue that the primary device is visual imagery reinforced by personification (a type of metaphor), because the core meaning is the visual domination of darkness.
- Step 4: Explain how the repetition enacts the persistence of darkness, making the reader feel its weight both visually and aurally.
ANSWER: The refrain is fundamentally a visual image ('darkness') extended through personification ('reigns'), and its repetition adds an auditory dimension that mimics the relentless spread of night. It is not purely auditory because the source is visual; it is not a simple metaphor because the comparison is implicit personification. The device blends imagery and metaphor to embody the poem's central oppression of separation.
DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: The poem ends with the lines: 'er djks oqQN 'kksd dguk' (people say: speak the truth). Earlier, the poet says 'eSa e"ks esa gw¡ lgh gS' (I am right in my place). Using the metaphors of 'house as temple' and 'father's voice as guiding light', evaluate whether the poet's final assertion is an act of defiance or acceptance. Support your evaluation with at least two specific metaphors/images from the poem.
COMPETENCY: Critical interpretation – synthesizing multiple devices to defend a nuanced reading of the poem's resolution.
STEPS:
- Step 1: Recall the metaphor 'house as temple' – the poet has turned his memory into worship, suggesting acceptance of his role as a devotee of the past.
- Step 2: Recall the metaphor 'father's voice as guiding light' – the anticipated dialogue shows the poet internalizing his father's judgment, suggesting alignment with tradition.
- Step 3: Analyze the final line: 'speak the truth' – the poet claims his truth (his memory, his identity) against a world that may deny it.
- Step 4: Weigh defiance vs acceptance: the metaphors show he has *accepted* the past's authority (temple, father's voice) but *defies* the present's demand to forget or move on.
- Step 5: Conclude: it is a defiant acceptance – he accepts the past's claim on him to defy the present's erasure.
ANSWER: The poet's final assertion is a defiant acceptance. The 'house as temple' metaphor shows he has surrendered to memory's sanctity (acceptance), while the 'father's voice' metaphor shows he draws strength from that surrender to claim his truth against external pressure (defiance). The images of the solitary lamp and the unanswered letter ('i=k') further illustrate a self that persists in darkness, making 'speak the truth' an act of resistance rooted in reverence.
DIFFICULTY: hard