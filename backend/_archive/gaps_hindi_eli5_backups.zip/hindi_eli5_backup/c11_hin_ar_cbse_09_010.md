## DEFINITION
Vocabulary in context refers to the analysis of how specific word choices within a literary text shape meaning, tone, and theme through their denotation (literal dictionary meaning), connotation (associated emotional and cultural associations), register (level of formality), and semantic field (the network of related words a text draws upon). In Hindi Aroh Chapter 9, key words are not merely carriers of information but instruments of literary craft — each word choice opens or closes interpretive possibilities, positions the reader's sympathy, and constructs the thematic architecture of the chapter. Understanding vocabulary in context means reading words not as isolated units but as nodes in a semantic web where each word's meaning is activated, modified, and deepened by its surrounding textual environment.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student must independently identify at least five key words from the chapter, explain each word's denotation and connotation within its specific textual context, trace how at least two words participate in a semantic field that supports the chapter's central theme, and demonstrate how replacing a key word with a synonym would alter the tone or thematic implication of the passage. The student must also explain how the author's choice of register (formal, colloquial, archaic, technical) positions the reader and serves the chapter's argumentative or aesthetic purpose.

## SCOPE_BOUNDARY
This node covers the analysis of key vocabulary words in their textual context within Hindi Aroh Chapter 9, including denotation, connotation, register, semantic fields, and word choice as thematic strategy. It does NOT cover grammar and sentence structure (addressed in node 011), literary devices such as metaphor or irony (addressed in sibling device nodes), or plot and narrative structure (addressed in node 002). It does not extend to comparative vocabulary analysis across chapters or etymological analysis beyond what is necessary for understanding connotation.

## WALKTHROUGH
Imagine two friends describing the same rainy day: one says "it's pouring" (neutral, factual) and the other says "it's weeping" (personified, melancholic). Same event, different words, entirely different emotional worlds. That is vocabulary in context — the word *chooses* the meaning. Now open the chapter and pick a passage that strikes you. List every word that carries emotional or thematic weight — not just the "difficult" words but the *significant* ones. For each, ask three questions: (1) What does this word literally mean (denotation)? (2) What feelings, associations, or cultural meanings does it carry (connotation)? (3) Why did the author choose *this* word instead of a synonym — what would be lost with a different choice? Next, look for clusters of words that belong to the same semantic field — words about movement, words about stillness, words about light, words about sound. When an author repeatedly draws from one semantic field, that field becomes the chapter's *interpretive lens* — the theme is encoded not in any single word but in the *pattern* of word choices. The key insight: vocabulary analysis is not about looking up definitions but about understanding words as *choices* — each one an act of selection that opens one meaning and closes another.

## DIAGNOSTIC_QUESTION_1
Define "denotation" and "connotation" in your own words, then give one example from everyday Hindi usage where a word's connotation significantly differs from its denotation (not from the textbook).

## DIAGNOSTIC_ANSWER_1
Denotation is the literal, dictionary definition of a word — its neutral, context-free meaning. Connotation is the set of emotional, cultural, and associative meanings that a word carries beyond its literal definition. Example: the Hindi word "तांत्रिक" (tantrik) denotes "related to systems/techniques" but connotes mystery, occult power, and fear in popular usage. A wrong answer that defines connotation as "another meaning of the word" (treating it as a secondary denotation rather than an associative field) reveals the student has not grasped that connotation is *cultural and emotional*, not definitional — it lives in the reader's associations, not in the dictionary.

## DIAGNOSTIC_QUESTION_2
In the chapter, the author uses a specific word to describe a key action or state. Identify one word whose connotation shifts depending on its context within the chapter — a word that means something different early in the text versus later. Explain how the surrounding textual environment changes the word's connotative weight.

## DIAGNOSTIC_ANSWER_2
A strong answer identifies a word that the author uses in two different passages where the surrounding context alters its connotation. For example, if the author uses a word associated with "movement" early in the chapter in a context of freedom or journey, and later uses the same word in a context of displacement or compulsion, the denotation (physical movement) remains constant but the connotation shifts from liberation to loss. The textual environment — the verbs, adjectives, and images surrounding the word — determines which connotation is activated. A wrong answer that treats the word as having a fixed connotation regardless of context reveals the student does not understand that connotation is *contextually activated* — the same word can carry opposite emotional charges in different textual environments.

## DIAGNOSTIC_QUESTION_3
Identify a semantic field (a cluster of related words) that runs through the chapter — for example, words related to light/darkness, movement/stillness, sound/silence, or growth/decay. List at least four words from this field and explain how the field as a whole constructs one of the chapter's central themes.

## DIAGNOSTIC_ANSWER_3
A strong answer identifies a consistent semantic field (e.g., words of constraint: "बंधन" [bond], "कैद" [imprisonment], "रस्सी" [rope], "दीवार" [wall]) and explains that the repeated use of this field constructs the theme of confinement — not through a single statement but through the *accumulation* of related words that build an atmospheric sense of being trapped. The theme emerges from the *pattern* of word choices, not from any single word. A wrong answer that lists four words but cannot explain how they *collectively* construct a theme (treating each word as independently meaningful rather than as nodes in a semantic network) reveals the student can identify vocabulary but cannot perform *semantic field analysis* — the senior-secondary skill of reading words as an interconnected system rather than as isolated units.

## DIAGNOSTIC_QUESTION_4
Take one key word from the chapter and replace it with a close synonym. Write both the original sentence and the revised sentence. Then explain precisely what is gained and what is lost in the replacement — how the synonym changes the tone, connotation, or thematic implication of the passage.

## DIAGNOSTIC_ANSWER_4
A strong answer selects a word with a rich connotative field and a synonym that shares the denotation but differs in connotation. For example, replacing "घुटन" [choking/suffocation, connoting slow, internal, emotional suppression] with "रुकन" [stopping, connoting mechanical, external, neutral interruption] in a sentence about emotional experience. The original word carries the connotation of *internal, bodily, suffocating* emotion; the synonym carries only the denotation of *cessation of flow*. What is lost: the bodily, visceral quality of the experience. What is gained: clarity and neutrality — but at the cost of the emotional depth that the original word provided. A wrong answer that claims "the meaning is the same, just a different word" reveals the student treats synonyms as interchangeable — missing that in literary texts, *no synonym is truly equivalent* because each carries a unique connotative charge that shapes the reader's experience.

## DIAGNOSTIC_QUESTION_5
Analyze the author's use of register (formality level) in the chapter. Identify one passage where the register shifts — from formal to colloquial, or from elevated to plain — and explain how this shift serves a thematic or rhetorical purpose. Why does the author break the register at that specific point?

## DIAGNOSTIC_ANSWER_5
A strong answer identifies a register shift and explains its function. For example, if the author uses formal, literary Hindi throughout a passage of reflection and then shifts to colloquial, direct speech in a moment of emotional outburst, the register shift enacts the *breakdown of composure* — the formal register represents controlled, distanced narration, and the colloquial shift represents raw, unfiltered emotion breaking through. The shift is not arbitrary but *dramatizes* the emotional turning point: the author uses register as a *structural device* to mark the moment where the narrator's controlled surface cracks. A wrong answer that identifies a register shift but explains it as "the author's style" or "for variety" reveals the student sees register as decorative rather than *functional* — missing that register shifts are deliberate rhetorical acts that serve specific thematic purposes at specific narrative moments.

## DIAGNOSTIC_QUESTION_6
Select a key word from the chapter that you believe is the single most important word for understanding the chapter's central theme. Write a 4-5 sentence justification arguing why *this* word — and not a synonym or related word — is the key that unlocks the chapter's meaning. Address denotation, connotation, semantic field membership, and the consequence of its replacement.

## DIAGNOSTIC_ANSWER_6
A strong answer selects a word that is both thematically central and connotatively rich, and justifies its centrality through multiple analytical lenses. For example: "The word 'याद' [memory/remembrance] is the chapter's key because its denotation (the act of recalling) names the chapter's central action; its connotation (longing, loss, the ache of distance) names the chapter's central emotion; its semantic field (connecting to 'धुंध' [haze], 'बीता' [past], 'निशानी' [trace]) constructs the chapter's atmosphere of fading presence; and replacing it with 'स्मरण' [formal recollection] would strip the word of its emotional, bodily charge, reducing the chapter from an experience of longing to a clinical act of remembering." A poor answer that selects a word but justifies it only by its denotation ("it means X and X is the theme") reveals the student cannot perform multi-layered vocabulary analysis — the senior-secondary skill of reading a single word through denotation, connotation, semantic field, and replacement consequence simultaneously.

## COMMON_MISCONCEPTION
Students treat vocabulary analysis as *dictionary work* — they identify a "difficult" word, look up its meaning, write the definition, and stop. This misses the entire point of vocabulary in context: the word's meaning is not in the dictionary but in the *textual environment*. The specific error is treating synonyms as interchangeable — students write "this word means the same as that word" without recognizing that in literary texts, no two words are truly equivalent because each carries a unique connotative charge. A deeper error is identifying semantic fields but treating them as lists of related words rather than as *thematic systems* — the student catalogues "here are four words about darkness" without explaining how the *accumulation* of darkness-words constructs the theme of despair or ignorance. The root cause is that Class 10 vocabulary work focused on *comprehension* (what does this word mean?) while Class 11 requires *analysis* (why does this word mean what it means *here*, and what would change if it were different?).

## ON_FAILURE
Step 1: Select a key passage from the chapter (3-4 sentences). Have the student list every word they consider "significant" — not just unfamiliar words but words that carry emotional or thematic weight. Step 2: For each significant word, create a three-column table: Column A = denotation (dictionary meaning), Column B = connotation (emotional/cultural associations), Column C = "what would change if replaced with a synonym?" Step 3: Ask the student to circle all words in the passage that belong to the same semantic field (e.g., all words related to movement, all words related to sound). Then ask: "What theme does this cluster of related words construct? Is the theme stated anywhere explicitly, or does it emerge only from the word pattern?" Step 4: Have the student rewrite the passage replacing three key words with synonyms. Compare original and rewritten versions aloud. Ask: "What is lost? What is gained? Why did the author choose the original words?" This exercise forces the student to experience vocabulary as *choice* rather than as *given*.

## PREREQUISITE_NODE_IDS
c11_hin_ar_cbse_09_001, c11_hin_ar_cbse_09_002, c11_hin_ar_cbse_09_006, c12_hin_a_cbse_09_001

## PREREQUISITE_REASONS
c11_hin_ar_cbse_09_001: The "Before You Read" context establishes the biographical, historical, and cultural background necessary to understand the connotations of key words — a word's cultural associations depend on the reader knowing the cultural context, which this node provides.
c11_hin_ar_cbse_09_002: Plot and narrative structure analysis establishes where key words appear in the narrative arc, which is essential because a word's connotation is contextually determined — the same word can carry different connotations at different points in the plot.
c11_hin_ar_cbse_09_006: Theme analysis identifies the chapter's central themes, which are the *meaning* that semantic fields construct. Without thematic clarity, vocabulary analysis becomes listing rather than interpreting — the student needs to know what theme to connect the word patterns to.
c12_hin_a_cbse_09_001: 9_010: Class 11 Kabir vocabulary node established basic glossary usage and Braj Bhasha familiarity. c12_hin_a_cbse_09_001: Context/Background node provides the Nirguna Bhakti framework essential for theological nuances of 'iSt' and 'iR;kfu'  

## FORWARD_NODE_IDS
c11_hin_ar_cbse_09_011, c11_hin_ar_cbse_09_012, c11_hin_ar_cbse_09_013, c11_hin_ar_cbse_09_014, c12_hin_a_cbse_07_010, c12_hin_a_cbse_09_010, c12_hin_ar_cbse_09_010, c12_hin_ar_cbse_12_010

## FORWARD_REASONS
c11_hin_ar_cbse_09_011: Grammar and language usage analysis builds on vocabulary analysis — grammatical structures (tense, repetition, sentence type) work *with* word choice to construct meaning. Understanding which words are key (this node) is prerequisite to analyzing how those words are grammatically deployed (node 011).
c11_hin_ar_cbse_09_012: Character and characterization analysis requires vocabulary analysis — characters are constructed through their word choices (dialogue) and the narrator's word choices about them (description). This node provides the skill of reading word choice as characterization.
c11_hin_ar_cbse_09_013: Critical thinking and interpretation questions in board exams demand evidence-based analysis of how word choice shapes meaning — this node provides the analytical framework (denotation/connotation/semantic field/replacement) that the critical thinking node will require students to apply independently.
c11_hin_ar_cbse_09_014: Key vocabulary (lohd`fr, vfHkO;fDr, tqykgk) enables precise, high-scoring expression.  
c12_hin_a_cbse_07_010: Practiced glossing untranslatable cultural terms.  
c12_hin_a_cbse_09_010: Class 11 Kabir vocabulary node established basic glossary usage and Braj Bhasha familiarity. c12_hin_a_cbse_09_001: Context/Background node provides the Nirguna Bhakti framework essential for theological nuances of 'iSt' and 'iR;kfu'. c12_hin_a_cbse_09_002: Plot/Narrative Structure node gives the poem's dramatic situation (weaver-poet addressing Divine Mother) which frames the vocabulary's emotional tone.  
c12_hin_ar_cbse_09_010: Class 11 vocabulary-in-context skills provide the foundational approach.  
c12_hin_ar_cbse_12_010: Analyzed vocabulary in social-inequality themes — thematic predecessor.  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
none

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_09_006 -> c11_hin_ar_cbse_09_010 -> c11_hin_ar_cbse_09_013

## THIS_FORMULA
N/A - conceptual

## FORMULA_VARIABLES
N/A

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
analytical

## CROSS_SUBJECT
N/A

## PREREQ_CONCEPT
Understanding that a word's meaning in a literary text is not fixed by its dictionary definition but is *contextually constructed* — the surrounding text, the cultural background, the narrative position, and the semantic field all activate specific connotations while suppressing others. Vocabulary analysis is the skill of reading words as *choices* made by an author, each choice opening some meanings and closing others.

## PREREQ_BEFORE
The student must be able to: (1) identify the chapter's central themes (from node 006); (2) locate key passages in the narrative structure (from node 002); (3) distinguish literal from figurative language; (4) recognize that synonyms are not truly interchangeable in literary contexts — each word carries a unique connotative charge.

## PREREQ_STUCK
If the student cannot identify connotations beyond denotation, return to node 001 (Before You Read) and re-establish the cultural context. Then ask: "When you hear this word, what do you *feel*? What images come to mind? What memories does it trigger?" This shifts the student from dictionary-thinking to association-thinking, which is the foundation of connotative analysis.

## WORKED_EXAMPLE_1
PROBLEM: Identify a key word from the chapter that participates in a semantic field supporting the chapter's central theme. Analyze the word's denotation, connotation, and semantic field membership. Then explain how replacing this word with a synonym would alter the passage's thematic effect.

STEPS:
- Step 1: Select a key word — choose a word that appears significant in the chapter, one that carries emotional or thematic weight beyond its literal meaning.
- Step 2: Analyze denotation — state the word's literal, dictionary meaning. This is the neutral, context-free definition.
- Step 3: Analyze connotation — identify the emotional, cultural, and associative meanings the word carries *in this specific passage*. Ask: what does the word make the reader feel? What cultural associations does it trigger? What does it imply that the denotation does not?
- Step 4: Identify semantic field — list at least three other words in the same passage or nearby passages that belong to the same semantic field (related area of meaning). Explain how the *cluster* of related words constructs a theme that no single word could convey alone.
- Step 5: Replacement analysis — replace the key word with a close synonym. Write both versions. Explain what is lost: which connotation disappears? What emotional charge is absent in the synonym? What thematic implication is weakened? This demonstrates that the author's choice was not arbitrary but *loaded*.

REASONING: This worked example models the five-step vocabulary analysis framework: select → denotation → connotation → semantic field → replacement. The replacement step (Step 5) is the critical move that distinguishes senior-secondary analysis from middle-school comprehension — the student must articulate *why this word and not another*, demonstrating that word choice is a *deliberate rhetorical act*, not a matter of convenience.

ANSWER: A complete analysis identifies a key word, explains its denotation (literal meaning) and connotation (emotional/cultural associations), traces its membership in a semantic field that collectively constructs a theme, and demonstrates through synonym replacement that the author's specific word choice carries connotative weight that a synonym cannot replicate — proving that vocabulary in a literary text is a system of *choices*, each with thematic consequences.

## WORKED_EXAMPLE_2
PROBLEM: The chapter contains a passage where the author's word choices create a specific tone (e.g., melancholic, defiant, nostalgic, ironic). Identify the tone, list at least four words from the passage that collectively produce this tone, and explain how the *combination* of these words creates a tone that no individual word could achieve alone.

STEPS:
- Step 1: Identify the tone — read the passage aloud and name the dominant emotional register. Is it sad, angry, ironic, tender, harsh? The tone is the *overall emotional color* of the passage.
- Step 2: List tone-producing words — identify at least four words that contribute to this tone. These are not necessarily "emotional" words — even neutral-sounding words can produce tone through their connotative field.
- Step 3: Analyze each word's contribution — for each word, explain how its connotation (not just denotation) feeds into the overall tone. A word's connotation may *reinforce* the tone (e.g., a word of decay reinforcing melancholy) or *create tension* with it (e.g., a word of brightness in a melancholy passage creating bittersweet contrast).
- Step 4: Explain the combinatory effect — the tone emerges from the *interaction* of words, not from any single word. Like instruments in an orchestra, each word contributes a *layer* of tone; the overall effect is the *chord* they produce together. Identify which word is the *dominant* tone-producer and which words are *supporting* or *contrasting*.
- Step 5: Test the analysis — remove or replace one word and observe how the tone shifts. This confirms that the tone is *systemically* produced — each word is a necessary component of the tonal architecture.

REASONING: This worked example models *tone analysis through vocabulary* — the skill of reading tone not as a vague impression but as a *construct* built from specific word choices. The combinatory analysis (Step 4) is the critical senior-secondary move: the student must explain how words *interact* to produce tone, not merely list words that "sound" emotional. This skill is directly tested in board exam questions asking "What is the tone of this passage and how does the author create it?"

ANSWER: The passage's tone is produced by the *combination* of at least four key words whose connotations interact to create an emotional chord. No single word produces the tone alone — each contributes a layer (dominant, supporting, or contrasting), and the overall tone emerges from their interaction. Replacing any one word shifts the tone, confirming that tone is *systemically* constructed through vocabulary, not imposed from outside.

## WORKED_EXAMPLE_3
PROBLEM: Trace a single key word across three different passages in the chapter. For each occurrence, analyze how the word's connotation shifts depending on its context. Then explain how the word's *evolution* across the three passages mirrors or supports the chapter's narrative or thematic arc.

STEPS:
- Step 1: Select a recurring word — choose a word that appears in at least three different passages. The word should be significant enough that its repetition is *meaningful*, not merely functional.
- Step 2: Analyze Occurrence 1 — identify the passage context, the word's denotation (constant), and its connotation *as activated by this context*. What does the word *feel like* here? What associations are triggered by the surrounding text?
- Step 3: Analyze Occurrence 2 — same process. How has the connotation shifted? What in the new context activates different associations? The denotation is the same, but the connotation may be *opposite* — a word of freedom in a context of captivity connotes *denied* freedom, while the same word in a context of liberation connotes *achieved* freedom.
- Step 4: Analyze Occurrence 3 — same process. How has the word evolved by this third occurrence? Has it accumulated meaning from the previous two? Does it now carry the *memory* of its earlier uses?
- Step 5: Synthesize the evolution — map the connotative shifts onto the chapter's narrative or thematic arc. Does the word's journey mirror the narrator's journey? Does it trace the development of a theme from one stage to another? The word's evolution is a *microcosm* of the chapter's larger movement.

REASONING: This worked example models *word tracking* — the skill of following a single word across multiple occurrences and analyzing how its meaning *accumulates and transforms*. This is explicitly tested in CBSE competency questions ("How does the meaning of X change across the text?"). The synthesis step (Step 5) is the critical move: the student must connect the word's micro-evolution to the chapter's macro-arc, demonstrating that vocabulary is not static but *dynamic* — words grow and change as the text progresses, just as characters and themes do.

ANSWER: A recurring word's connotation evolves across three occurrences as the surrounding context shifts, creating a *connotative arc* that mirrors the chapter's narrative or thematic development. The word's denotation remains constant, but its connotation transforms — accumulating meaning from each previous use and carrying the memory of earlier contexts into later ones. This evolution makes the word a *microcosm* of the chapter's larger movement, demonstrating that vocabulary in a literary text is not a fixed system but a *living* one that grows with the narrative.

## COMPETENCY_QUESTION_1
QUESTION: A critic claims: "The author's vocabulary in this chapter is deliberately plain and everyday — the author avoids difficult or literary words to make the chapter's emotional world accessible to ordinary readers." (a) Identify two words from the chapter that either *support* or *challenge* this claim. (b) For each word, explain whether its plainness is *genuine accessibility* or *rhetorical strategy* — does the author use plain words because they are simple, or because plainness serves a specific thematic purpose? (c) Evaluate the critic's claim: is "plain vocabulary" the same as "simple meaning"?

COMPETENCY: Evaluating critical claims about vocabulary using textual evidence — distinguishing between surface simplicity and strategic plainness, a key analytical skill for board exam "evaluate" questions.

STEPS:
- Step 1: Test the claim — select two words that appear "plain" or "everyday." Check whether their denotation is indeed simple and accessible, or whether their connotation carries complexity that the surface plainness conceals.
- Step 2: Analyze Word 1 — if the word's denotation is plain but its connotation is rich (e.g., a common word that carries deep cultural or emotional associations in context), then the plainness is *strategic* — the author uses an accessible surface to carry a complex emotional or thematic payload. This *challenges* the critic's claim that plainness equals accessibility.
- Step 3: Analyze Word 2 — if the word is genuinely plain in both denotation and connotation (a functional word with no significant connotative charge), then it *supports* the claim for *that specific word*. But one plain word does not prove the whole vocabulary is plain — the critic overgeneralizes.
- Step 4: Evaluate the claim — "plain vocabulary" (simple denotation) is NOT the same as "simple meaning" (simple connotation). A word can be denotatively plain but connotatively complex. The author may choose plain words precisely because their *familiarity* allows complex connotations to slip into the reader's consciousness without resistance — plainness as a *delivery mechanism* for depth, not as a *substitute* for it.
- Step 5: Formulate judgment — the critic's claim is *partially valid* (the vocabulary is denotatively accessible) but *fundamentally misleading* (it conflates surface plainness with semantic simplicity, missing the strategic use of plain words to carry complex connotations).

ANSWER: (a) Two words: one denotatively plain but connotatively rich (challenging the claim), one genuinely plain in both dimensions (partially supporting it). (b) The first word's plainness is *strategic* — the author uses familiar surface to deliver complex emotional content; the second's plainness is *functional* — it serves the sentence without carrying thematic weight. (c) "Plain vocabulary" (simple denotation) is not the same as "simple meaning" (simple connotation). The critic conflates the two, missing that the author's plainness is a *rhetorical strategy* — using accessible words to carry inaccessible emotions — not a sign of semantic simplicity.

DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: Construct an analytical paragraph (PEEL structure) arguing that the chapter's *most thematically powerful* passage is also its *most vocabulary-rich* passage — that is, the author concentrates significant word choices precisely where the thematic stakes are highest. Identify the passage, list four key words from it, analyze their collective semantic function, and explain why the *density* of significant vocabulary at this point is not coincidental but structurally motivated.

COMPETENCY: Synthesizing vocabulary analysis with thematic argument — constructing an evidence-based paragraph that demonstrates how word density correlates with thematic intensity, a senior-secondary analytical skill.

STEPS:
- Step 1: Point — The chapter's most thematically powerful passage is also its most vocabulary-rich: the author concentrates significant word choices where the thematic stakes are highest, making vocabulary density a *structural indicator* of thematic climax.
- Step 2: Evidence — Identify the passage. List four key words from it. Quote each in its sentence. These words should span a semantic field (not four random difficult words but four words that *collectively* construct a theme).
- Step 3: Explanation — For each word, explain its denotation and connotation. Then explain how the four words *interact*: do they reinforce each other (building a single theme through accumulation)? Do they create tension (opposing connotations creating complexity)? The *density* of significant words at this point means the reader cannot escape the thematic weight — every word carries it, creating an immersive thematic environment.
- Step 4: Link — This vocabulary density is *structurally motivated*: the author saves the richest word choices for the passage where the theme reaches its greatest intensity, because at the thematic climax, the reader needs to *feel* the theme through every word, not just understand it through one. Sparse vocabulary would dilute the climax; dense vocabulary *saturates* it.
- Step 5: Concluding synthesis — The correlation between vocabulary richness and thematic power is not coincidental but *architectural*: the author builds toward the thematic climax partly through *increasing word significance*, making the reader's experience of language intensity mirror the thematic intensity.

ANSWER: The chapter's most thematically powerful passage is also its most vocabulary-rich because the author concentrates significant word choices where the thematic stakes are highest. Four key words from this passage span a single semantic field, collectively constructing the theme through accumulation rather than statement. The density of significant vocabulary at this point is structurally motivated: at the thematic climax, the author needs every word to carry thematic weight, creating a saturated environment where the reader *feels* the theme through the sheer density of significant language. Sparse vocabulary would dilute; dense vocabulary immerses. The correlation is architectural, not accidental.

DIFFICULTY: hard
