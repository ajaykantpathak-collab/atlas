## DEFINITION
Literal comprehension questions require answers directly stated in the text (who, what, where, when), while inferential comprehension questions require students to derive meaning by combining textual clues with background knowledge, reading between the lines to understand implied ideas, character motivations, or thematic significance.

## COGNITIVE_LEVEL
apply

## MASTERY_CRITERIA
The student can independently classify a comprehension question as literal or inferential, locate explicit textual evidence for literal answers, and construct a logical inference chain (text clue + background knowledge = conclusion) for inferential answers, citing specific lines or incidents from the chapter.

## SCOPE_BOUNDARY
This node covers only literal and inferential question types based on the chapter "viw osQ lkFk <kbZ lky". It does NOT cover evaluative/appreciation questions (node 013), creative writing tasks (node 014), or oral discussion skills (node 015). Vocabulary/grammar in context (nodes 010-011) are tools used here but not re-taught.

## WALKTHROUGH
Imagine you receive a WhatsApp forward: "Mummy ne kaha khana khake jana" – you know *exactly* what was said (literal). But if the message says "Mummy ne thali samne rakh di, aankhon mein pyaar tha" – you *infer* she cares without her saying "I love you". Start every comprehension task by reading the question first. Ask: "Can I point my finger at the exact sentence that answers this?" If YES → literal. If NO → inferential. For inferential, hunt for 2-3 textual clues (dialogue, description, action) and connect them to what you know about human behaviour or the story's context. The key insight: inferential answers are NOT guesses; they are evidence-based deductions.

## DIAGNOSTIC_QUESTION_1
What is the defining difference between a literal comprehension question and an inferential comprehension question?

## DIAGNOSTIC_ANSWER_1
A literal question's answer is explicitly written in the text (e.g., "What did the author find in the junk shop?" → "A small window"). An inferential question's answer is not directly stated; it requires combining textual clues (e.g., "Why did the author feel the window was 'destined' for the play?" → clues: window's size, shape, timely arrival, author's desperation). A wrong answer (e.g., "Inferential means it's not in the book") reveals the student thinks inference = guessing without evidence.

## DIAGNOSTIC_QUESTION_2
In the chapter, the author describes the junk dealer's son saying, "Ye meri chhoti bahen hai, iski shaadi ke liye rakha tha." The author does not comment on the dealer's poverty. What can you infer about the dealer's financial condition, and which two textual clues support this?

## DIAGNOSTIC_ANSWER_2
Inference: The dealer was very poor. Clue 1: He kept a window frame for his daughter's future wedding (a valuable asset), yet sold it cheaply. Clue 2: The author notes the dealer's "maati ka tel" (earth/clay oil lamp) and broken house, indicating extreme poverty. A wrong answer (e.g., "He was generous") shows the student misses economic pressure as the driver and focuses only on the act of selling.

## DIAGNOSTIC_QUESTION_3
Apply the literal/inferential distinction to this new question on the same chapter: "List the three things the author and his team did to the window frame before fitting it on stage." Is this literal or inferential? Answer it.

## DIAGNOSTIC_ANSWER_3
Literal. The text explicitly states: (1) cleaned the frame, (2) painted it, (3) fitted glass panes. Steps: 1. Identify question asks for listed actions. 2. Scan text for sequence of actions on the window. 3. Extract the three explicit steps. 4. Verify no interpretation needed. A wrong classification (e.g., "inferential because it needs sequencing") reveals confusion between 'multi-step literal retrieval' and 'inference'.

## DIAGNOSTIC_QUESTION_4
Analyze the author's statement: "Natak ka kaam chal raha tha, lekin mann mein ek dar baitha hua tha." The text does not name the fear. Using the preceding and following paragraphs, analyze what the fear was and why it was specific to *this* window.

## DIAGNOSTIC_ANSWER_4
The fear was that the window would not arrive/be ready in time for the play. Specificity: The window was *uniquely* perfect (exact size, arched top, wooden bars) and irreplaceable. Clues: Author's desperate search ("har jagah dhoondha"), the dealer's initial refusal, the time pressure ("do din bache the"). A weak answer ("fear of failure") is too generic; it misses the textual evidence linking the fear to *this specific window's* irreplaceability.

## DIAGNOSTIC_QUESTION_5
Evaluate this student's inferential answer: "The author loved the window because it was beautiful." Is this a strong or weak inference? Justify using the text.

## DIAGNOSTIC_ANSWER_5
Weak inference. The text emphasizes *utility* and *serendipity*, not beauty: "theek waisa hi chahiye tha" (exactly what was needed), "kismat ka khel" (stroke of luck), "natak ke liye zaroori" (necessary for the play). The author's relief is pragmatic ("kaam chal gaya"). A strong inference would be: "The author valued the window as a providential solution to a desperate production crisis." The student's answer projects personal aesthetic preference onto the text without evidence.

## DIAGNOSTIC_QUESTION_6
Create an inferential question about the junk dealer's character that requires connecting his dialogue ("shaadi ke liye rakha tha") with his action (selling it for very little). Provide the answer with a 3-step inference chain.

## DIAGNOSTIC_ANSWER_6
Question: "What does the dealer's decision to sell the window frame reveal about his priorities?" Answer: He prioritizes immediate survival over future social obligations. Chain: 1. Text: Frame saved for daughter's wedding (social duty). 2. Text: Sells it cheaply to author (economic compulsion). 3. Background: Extreme poverty forces liquidation of precious assets. Conclusion: Survival > tradition. A poor answer ("he was kind") ignores the economic pressure explicitly described in the setting.

## COMMON_MISCONCEPTION
Students believe "inferential" means "any answer not in the book is correct" – they treat inference as creative writing. In this chapter, they often write: "The author was happy because he liked old things" instead of "The author was relieved because the window solved the exact set-design crisis described on page 34." They miss that *valid* inferences are tightly constrained by textual evidence + logical reasoning, not personal imagination.

## ON_FAILURE
1. Give the student a 2-column table: Column A = Literal Question (answer in one sentence from text), Column B = Inferential Question (answer = Clue 1 + Clue 2 + Logic). 2. Practice with 5 questions from the chapter: physically highlight the answer sentence for literal; for inferential, highlight 2-3 clue sentences and write the logic bridge in a third color. 3. Use the "Because... therefore..." sentence frame: "The text says [clue 1] and [clue 2], therefore [inference]." 4. Verify every inference against the "So what?" test: Does this inference change how we understand the plot/character/theme? If not, it's likely a weak guess.

## BUILDS_ON
Basic reading comprehension and text-evidence citation skills developed in Class 10 (finding explicit answers).

## LEADS_TO
Critical Thinking: Analysis and Interpretation (node 013) where students evaluate author's craft, bias, and thematic depth using the same evidence-based reasoning.

## PREREQUISITE_NODE_IDS
c11_hin_ar_cbse_03_001, c11_hin_ar_cbse_03_002, c11_hin_ar_cbse_03_003, c11_hin_ar_cbse_03_004, c11_hin_ar_cbse_03_005, c11_hin_ar_cbse_03_006, c11_hin_ar_cbse_03_007, c11_hin_ar_cbse_03_008, c11_hin_ar_cbse_03_009, c11_hin_ar_cbse_03_010, c11_hin_ar_cbse_03_011
## PREREQUISITE_REASONS
c11_hin_ar_cbse_03_001: Context/background knowledge needed for inferential leaps (e.g., understanding 1970s theatre constraints).
c11_hin_ar_cbse_03_002: Plot sequence knowledge required to locate where events happen for literal retrieval.
c11_hin_ar_cbse_03_003: Setting/atmosphere details provide clues for inferences about mood and character.
c11_hin_ar_cbse_03_004: Protagonist's motives/feelings are central to inferential questions on his actions.
c11_hin_ar_cbse_03_005: Supporting characters (dealer, son, actors) drive key inferential moments.
c11_hin_ar_cbse_03_006: Primary theme (art vs. reality, serendipity) frames higher-order inferences.
c11_hin_ar_cbse_03_007: Secondary themes (poverty, dedication) inform character-based inferences.
c11_hin_ar_cbse_03_008: Imagery/metaphor analysis requires inferring meaning beyond literal description.
c11_hin_ar_cbse_03_009: Irony/symbolism detection is purely inferential skill application.
c11_hin_ar_cbse_03_010: Vocabulary in context (e.g., "oaQfVU;qbVh", "okLrqliZ") is essential for accurate literal/inferential reading.
c11_hin_ar_cbse_03_011: Grammar/usage nuances (tense, voice) affect literal meaning extraction.

## FORWARD_NODE_IDS
c11_hin_ar_cbse_03_013, c11_hin_ar_cbse_03_014, c11_hin_ar_cbse_03_015, c12_hin_a_cbse_03_012, c12_hin_a_cbse_17_012, c12_hin_al_cbse_03_012, c12_hin_ar_cbse_04_012, c12_hin_ar_cbse_05_012

## FORWARD_REASONS
c11_hin_ar_cbse_03_013: Critical thinking requires the evidence-based inference skill mastered here to analyze author's intent, bias, and thematic complexity.
c11_hin_ar_cbse_03_014: Writing skills (answers, essays) depend on structuring literal evidence and inferential reasoning into coherent paragraphs (PEEL).
c11_hin_ar_cbse_03_015: Speaking/listening discussions need students to distinguish factual recall from interpretive claims during peer dialogue.
c12_hin_a_cbse_03_012: Poetry-specific comprehension strategies  
c12_hin_a_cbse_17_012: Class 11 PEEL introduction — this node upgrades it to *dialectical PEEL* (counter-evidence integration).  
c12_hin_al_cbse_03_012: Provides prior exposure to environmental-theme inference patterns.  
c12_hin_ar_cbse_04_012: अगला तार्किक चरण: Literal comprehension is the ability to extract explicitly stated facts, details, and sequences dire... इस नोड की अवधारणाओं को सीधे उपयोग/विस्तारित करता है।  
c12_hin_ar_cbse_05_012: Class 11 Chapter 3 applied PEEL structure to poem-based inference.  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
none

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_03_002 -> c11_hin_ar_cbse_03_012 -> c11_hin_ar_cbse_03_013 (Plot knowledge enables literal/inferential comprehension which enables critical analysis)

## THIS_FORMULA
Inference = Textual Evidence (2+ specific details) + Logical Reasoning (background knowledge / cause-effect / character psychology) → Justified Conclusion

## FORMULA_VARIABLES
Textual Evidence: Direct quotes, paraphrased incidents, or descriptive details from the chapter. Logical Reasoning: Connection made using context, human behavior norms, or thematic patterns. Justified Conclusion: The inferential answer that explains 'why' or 'what it implies'.

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
linguistic

## CROSS_SUBJECT
c11_history_source_analysis | Both require distinguishing explicit source content (literal) from historical interpretation (inferential) using corroborating evidence.
c11_geography_map_interpretation | Reading a map involves literal symbols (legend) and inferential patterns (settlement reasons, climate impact) – same cognitive dual-process.

## PREREQ_CONCEPT
Ability to distinguish between explicitly stated information and implied meaning in a narrative text.

## PREREQ_BEFORE
Student must have read the full chapter "viw osQ lkFk <kbZ lky" and understood its plot, characters, and key vocabulary (nodes 001-011).

## PREREQ_STUCK
If stuck, re-read the "Text: Plot and Narrative Structure" (node 002) and "Vocabulary in Context" (node 010) to rebuild the factual and lexical foundation.

## WORKED_EXAMPLE_1
PROBLEM: Answer the inferential question: "Why did the author feel 'ek ajeeb si shanti' (a strange peace) after the window was finally fitted on stage?" Use the 3-step inference chain.
STEPS:
- Step 1: Identify the question as inferential (emotion reason not directly stated). Scan the last 3 paragraphs for clues about the author's state of mind.
- Step 2: Collect textual evidence: Clue A: "Natak ka kaam chal raha tha" (play work was ongoing - stress). Clue B: "Mann mein ek dar baitha hua tha" (fear sat in mind - anxiety about window). Clue C: "Ab wo dar nikal gaya" (that fear left) after window fitted.
- Step 3: Apply background knowledge: Completing a crucial, irreplaceable prop for a live performance releases performance anxiety. The "strange peace" = relief + validation of effort.
- Step 4: Synthesize: The peace came from resolution of the specific, high-stakes crisis (finding the exact window in time), not general happiness.
- Step 5: Verify against text: Author mentions "kismat ka khel" (stroke of luck) and "kaam ban gaya" (work got done) – confirms relief interpretation.
REASONING: This models the mandatory inference chain: locate clues → connect to context (theatre production pressure) → state conclusion that explains the textual emotion word ("shanti").
ANSWER: The author felt a strange peace because the successful fitting of the uniquely perfect window resolved the intense, specific anxiety about the play's set being incomplete, replacing fear of failure with relief that the production could proceed.

## WORKED_EXAMPLE_2
PROBLEM: Classify and answer: "What did the author's mother say when she saw the window frame in the house?" (Literal/Inferential?)
STEPS:
- Step 1: Read question – asks for exact words of a specific person at a specific moment.
- Step 2: Scan text for "mother", "window", "house", dialogue markers. Find paragraph: "Maa ne dekha to boli, 'Ye kahan se utha laya? Kabaddi wale ko de de!'"
- Step 3: Confirm answer is explicitly quoted. No interpretation needed.
- Step 4: Classify as LITERAL because answer is verbatim in text.
- Step 5: Formulate answer citing the exact line.
REASONING: Demonstrates literal retrieval: finger-on-text evidence, zero logic bridge needed. Reinforces that "who said what" questions are typically literal.
ANSWER: Literal. The mother said: "Ye kahan se utha laya? Kabaddi wale ko de de!" (Where did you pick this up from? Give it to the kabaddi/waste dealer!)

## WORKED_EXAMPLE_3
PROBLEM: A board-style competency question: "The window frame functions as a symbol of 'serendipity in art' in the chapter. Support this statement with ONE literal detail and ONE inferential reading from the text."
STEPS:
- Step 1: Deconstruct the prompt: Needs 1 literal fact + 1 inference, both supporting the symbol claim.
- Step 2: Select literal detail: "The frame was exactly the size and design needed for the play's window" (explicitly stated in search description).
- Step 3: Develop inferential reading: The frame's discovery in a junk shop, saved for a poor girl's wedding, sold for theatre – connects poverty, domestic hope, and artistic need in one object. This convergence is unplanned = serendipity.
- Step 4: Draft the inference using formula: Text (saved for wedding + sold for play) + Reasoning (different value systems intersecting by chance) → Conclusion (object embodies accidental meaning-making).
- Step 5: Check alignment: Does this prove 'serendipity in art'? Yes – art's need met by life's accident.
- Step 6: Write final answer in PEEL structure: Point → Literal Evidence → Inferential Explanation → Link to symbol.
REASONING: Combines both question types in one exam-style response. Shows literal grounds the inference; inference elevates the literal to thematic significance.
ANSWER: Literal detail: The author explicitly states the junk-shop frame matched the play's requirements perfectly ("theek waisa hi chahiye tha"). Inferential reading: That a frame preserved for a daughter's wedding (domestic future) was sold to complete a theatre set (artistic present) – and the author calls it "kismat ka khel" – transforms the object into a symbol of how art's necessities are mysteriously fulfilled by life's unpredictable collisions.

## COMPETENCY_QUESTION_1
QUESTION: Read the extract: "Jab hum us khidki ko stage par laga rahe the, to ek baar bhi nahi laga ki ye wo hi khidki hai jo kabaddi ke godam mein padi thi." Based on the chapter, is the narrator's statement literal or inferential? Explain why the narrator might perceive the window differently on stage versus in the godown, using one textual clue from each setting.
COMPETENCY: Textual Analysis & Perspective Taking
STEPS:
- Step 1: Identify the statement as the narrator's *perception* (inferential by nature – it's about his feeling, not the window's physical properties).
- Step 2: Find godown clue: "godam mein andhere mein padi hui, mitti-tel lagi hui" (lying in darkness, covered in dust/oil).
- Step 3: Find stage clue: "stage par roshni mein, rangeen, nayi si lag rahi thi" (in stage lights, painted, looking new).
- Step 4: Synthesize: Context (lighting, paint, purpose) transforms perception. The narrator infers the window's *identity* has shifted from junk to art-object.
- Step 5: Conclude: The statement is inferential – it describes a subjective transformation, not a physical change.
ANSWER: The statement is inferential. It reflects the narrator's subjective experience, not an objective fact. In the godown, the window was "andhere mein padi hui, mitti-tel lagi hui" (lying in darkness, covered in grime) – seen as waste. On stage, under lights and painted ("rangeen, nayi si"), it became a theatrical artifact. The narrator infers this contextual metamorphosis; the wood itself didn't change.
DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: "The chapter blurs the line between the play's fiction and the author's reality." Evaluate this claim by providing: (a) One literal example where the boundary is physically crossed, (b) One inferential example where the boundary is emotionally crossed, and (c) A judgment on whether this blurring strengthens the theme of 'art imitating life'.
COMPETENCY: Thematic Synthesis & Critical Evaluation
STEPS:
- Step 1: Literal boundary crossing: The "Hkwyks oqQÙkk" (fake baby) used in the play is *also* the prop the author's team struggles with in real rehearsal – same object, dual role.
- Step 2: Inferential boundary crossing: The author's anxiety ("mann mein dar") about the window mirrors the character's anxiety in the play – his real fear 'acts' the role. Text: "viw dh ek¡ loZt;k viw dks Hkkr f[kyk jgh gS" (mother bird feeding baby) parallels author nurturing the production.
- Step 3: Judge thematic impact: Yes, strengthens 'art imitating life'. The blurring makes the theatre a microcosm of real struggle (poverty, deadlines, hope). The literal prop and inferential emotion both show art *living* life, not just copying it.
- Step 4: Structure evaluation: Claim → Literal Evidence → Inferential Evidence → Reasoned Judgment.
- Step 5: Refine language for board answer: Use "parallelism", "metonymy", "experiential convergence".
ANSWER: (a) Literal: The wooden baby doll (Hkwyks oqQÙkk) functions simultaneously as a stage prop and a real backstage headache (lost, found, replaced). (b) Inferential: The author's desperate search for the window mirrors the play's theme of desperate longing – his real panic 'rehearses' the character's despair. (c) Judgment: This blurring powerfully strengthens 'art imitating life' because the production crises (literal) and the creator's psyche (inferential) become indistinguishable – the theatre *is* life compressed, not a separate imitation.
DIFFICULTY: hard