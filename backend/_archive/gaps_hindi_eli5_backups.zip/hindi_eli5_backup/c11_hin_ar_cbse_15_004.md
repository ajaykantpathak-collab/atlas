## DEFINITION
Character analysis of the protagonist in a poem involves examining the poetic persona (the speaker) as a constructed character by identifying their traits, motivations, and worldview through their reflections, tone, and choices expressed in the verses, and explaining how these reveal the poem's central concern.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student can independently identify three distinct personality traits of the poetic speaker in "lcls [krjukd", provide specific textual evidence (lines/stanza references) for each trait, and explain how the speaker's evolving perspective structures the poem's argument about life's difficulties.

## SCOPE_BOUNDARY
This node covers analyzing the speaker/persona as the protagonist of the poem "lcls [krjukd" (Chapter 15). It does NOT cover analysis of characters in the prose story "eerk dkfy;k" (which is a different chapter), nor does it cover thematic analysis or literary devices except as they illuminate the speaker's character.

## WALKTHROUGH
Imagine you are listening to a friend describe the hardest thing they've ever done — you instinctively judge their character by what they choose to share and how they describe it. Similarly, when you read "lcls [krjukd", the speaker is telling you what they find most difficult in life. Begin by reading the poem aloud to hear the speaker's voice: is it weary, defiant, tender? Next, mark every statement where the speaker says "I" or implies a personal stance (e.g., "eqnkZ 'kkafr ls Hkj tkuk"). Group these into categories: what they reject as 'not the hardest', what they accept as 'the hardest', and what they feel while doing it. Finally, ask: what kind of person *chooses* these specific difficulties as the ultimate test? That synthesis is your character analysis.

## DIAGNOSTIC_QUESTION_1
In the poem "lcls [krjukd", who is the 'protagonist' being analyzed when we do a character analysis?

## DIAGNOSTIC_ANSWER_1
The protagonist is the poetic speaker (the 'I' voice of the poem), a constructed persona distinct from the poet Vinod Kumar Shukla, who reflects on life's hardships. A wrong answer (e.g., naming the poet himself or a fictional character from a story) reveals the student confuses the author with the speaker or mistakes the poem for a narrative with external characters.

## DIAGNOSTIC_QUESTION_2
The speaker lists several things that are *not* the most difficult (esgur dh ywV, iqfyl dh ekj, xíkjh&yksHk dh eq_h). What does this repetitive negation reveal about the speaker's character?

## DIAGNOSTIC_ANSWER_2
It reveals a speaker who is intellectually rigorous and emotionally honest — they refuse easy, dramatic answers (war, grief, heartbreak) to dig toward a quieter, more universal truth. A wrong answer (e.g., "it shows the speaker is confused" or "it's just a poetic device") reveals the student sees structure as decoration rather than characterization, missing how the speaker's *process of elimination* defines their thoughtfulness.

## DIAGNOSTIC_QUESTION_3
Apply the 'show, don't tell' principle: The speaker never says "I am empathetic." Identify two specific images from the second half of the poem (after "lcls [krjukd gksrk gS") that *show* this empathy through concrete observation.

## DIAGNOSTIC_ANSWER_3
1. "vkidh dykbZ ij pyrh gqbZ Hkh tks / vkidh fuxkg esa #dh gksrh gS" (the shadow on your body that trembles in your breath) — shows intimate attention to another's physical vulnerability. 2. "tks ph'kksa ls mBrh vaèksiu dh Hkki ij <qyd tkrh gS" (that walks bowed under the weight of responsibilities tied to ankles) — shows recognition of invisible burdens. A wrong answer quoting abstract lines (e.g., "ejfl;k") reveals the student cannot distinguish between the speaker's *direct observation* and their *summary conclusions*.

## DIAGNOSTIC_QUESTION_4
Compare the speaker's definition of 'the most difficult' in the first stanza (negative definitions) with the final stanza (positive definition). What shift in the speaker's *values* does this structural movement expose?

## DIAGNOSTIC_ANSWER_4
The shift moves from rejecting external, dramatic crises (war, grief, betrayal) to affirming domestic, relational endurance (leaving home, witnessing loved ones' pain, carrying unseen burdens). This exposes a speaker who values *quiet, sustained caregiving* over *heroic suffering* — a profoundly anti-heroic, humanistic value system. A wrong answer focusing only on "the list gets longer" misses the qualitative value shift from public to private, dramatic to mundane.

## DIAGNOSTIC_QUESTION_5
Evaluate this claim: "The speaker in 'lcls [krjukd' is a passive victim of circumstances." Defend your judgment using the poem's closing image: "lcls [krjukd og xhr gksrk gS / vkiosQ dkuksa rd igq¡pus osQ fy, / tks ejfl;k i<+rk gS / vkrafdr yksxksa osQ njok"kksa ij / tks xaqMs dh rjg vdM+rk gS".

## DIAGNOSTIC_ANSWER_5
The claim is false. The closing image depicts the speaker as *actively* walking toward doors (agency), reading the unspoken pain of strangers (proactive empathy), and dissolving like fragrance (transformative action) — all choices of engagement, not passive endurance. A wrong answer agreeing with the claim reveals the student equates 'difficulty' with 'victimhood' and misses the poem's redefinition of strength as gentle persistence.

## DIAGNOSTIC_QUESTION_6
Write a 4-line stanza in the style of the poem that begins "lcls [krjukd og ______ gksrk gS" defining a new 'most difficult' act consistent with the speaker's established character (quiet, relational, observant). Use one concrete domestic image.

## DIAGNOSTIC_ANSWER_6
Example: "lcls [krjukd og jgrk gS / tc rqe xq:cpek dks / viuh Hkkouk ugha] 'kq: dh vo/kkj.kk cukdj / ns[k jgs gksA" (The most difficult is to stay / when you watch your child / make a mistake knowingly / and not interrupt.) A poor answer using a dramatic image (e.g., "dying in battle") reveals the student has not internalized the speaker's consistent logic: the hardest things are small, relational, and chosen.

## COMMON_MISCONCEPTION
Students conflate the *poet* (Vinod Kumar Shukla, a specific historical person with a biography) with the *speaker* (a literary construct who says "eqnkZ 'kkafr ls Hkj tkuk" — a universal human stance). They write "The poet thinks leaving home is hard because he left his village in 1947" — importing biography to explain a textual choice. This error stems from middle-school habit of 'author = narrator' and ignores that the poem *generalizes* ("vkidh", "gekjs") to make the speaker an everyman.

## ON_FAILURE
1. Have the student underline every occurrence of "I/me/my" (eqgCcr, eqnkZ, gekjs) and "you/your" (vkidh, vkiosQ) in the poem. 2. Ask: "Does the *poet* know *your* (the student's) trembling shadow or bowed walk? No. So who is speaking *to you*?" 3. Co-create a 'Speaker Profile Card': Name: The Witness. Age: Timeless. Occupation: Noticing what others ignore. Core Belief: Love is heavy work. 4. Re-read the poem *only* as this character's monologue.

## BUILDS_ON
c11_hin_ar_cbse_15_003 (Text: Setting and Atmosphere) — the poem's atmosphere of quiet domestic pressure shapes the speaker's values.

## LEADS_TO
c11_hin_ar_cbse_15_006 (Theme: Primary Theme and Message) — the speaker's character *is* the vehicle for the theme: "Endurance in ordinary love is the truest heroism."

## PREREQUISITE_NODE_IDS
c11_hin_ar_cbse_15_001, c11_hin_ar_cbse_15_002, c11_hin_ar_cbse_15_003
## PREREQUISITE_REASONS
c11_hin_ar_cbse_15_001: Provides biographical context of Vinod Kumar Shukla (essential to distinguish poet from persona).
c11_hin_ar_cbse_15_002: Establishes the poem's narrative structure (the negative-to-positive argument arc) which the speaker *enacts*.
c11_hin_ar_cbse_15_003: Identifies the atmosphere of "fnuksfnu vfèkdkfèkd u`'kal" (daily helplessness) that the speaker inhabits and resists.

## FORWARD_NODE_IDS
c11_hin_ar_cbse_15_005, c11_hin_ar_cbse_15_006, c11_hin_ar_cbse_15_008, c11_hin_ar_cbse_15_013, c11_hin_ar_cbse_15_007, c11_hin_ar_cbse_15_015, c12_hin_ar_cbse_15_004

## FORWARD_REASONS
c11_hin_ar_cbse_15_005: Supporting characters (the 'you', the 'child', the 'strangers at doors') are defined *only* through the speaker's gaze — analyze speaker first.
c11_hin_ar_cbse_15_006: The primary theme emerges *from* the speaker's final definition; you cannot state the theme without the speaker's authority.
c11_hin_ar_cbse_15_008: Imagery (shadow, fragrance, bowed walk) functions as the speaker's *eyes* — analyze character to unlock imagery.
c11_hin_ar_cbse_15_013: Critical interpretation (e.g., "Is this poem feminist? Marxist?") requires a fixed reading of the speaker's stance first.
c11_hin_ar_cbse_15_007: The poetic persona as the exhausted worker is the lens through which all secondary themes are filtered.  
c11_hin_ar_cbse_15_015: Protagonist analysis (the poetic voice) informs character-based interpretations.  
c12_hin_ar_cbse_15_004: Prior practice in character analysis of protagonists in Class 11 builds the analytical vocabulary (ethos, persona, textual vs. biographical) needed here.  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
No prior class nodes available for cross-subject linking.

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_15_003 -> c11_hin_ar_cbse_15_004 -> c11_hin_ar_cbse_15_006

## THIS_FORMULA
N/A - conceptual

## FORMULA_VARIABLES
N/A

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
conceptual

## CROSS_SUBJECT
c11_psychology_personality | The speaker's traits (empathy, resilience, anti-heroic values) map to Big Five traits (Agreeableness, Conscientiousness) and Viktor Frankl's 'meaning in suffering' — analyze the persona as a psychological case study.
c11_sociology_social_issues | The poem's redefinition of 'difficulty' from public crisis to invisible domestic labor (leaving home, caring, witnessing) mirrors sociological debates on 'unpaid care work' and gendered endurance — the speaker voices a structural reality.

## PREREQ_CONCEPT
Distinction between author (biographical person) and speaker (textual construct) — the foundational literary concept for all poem analysis.

## PREREQ_BEFORE
Student must be able to point to a line in the poem and say "This is the speaker talking, not the poet" and explain the difference.

## PREREQ_STUCK
Review "Author vs. Speaker" distinction using a simple example: In a horror movie, the director is not the monster; in a poem, the poet is not the 'I'.

## WORKED_EXAMPLE_1
PROBLEM: Analyze the speaker's character trait of 'intellectual honesty' using the first two stanzas of "lcls [krjukd".
STEPS:
- Step 1: Identify the speaker's method — they list three grand things (war grief, maternal sorrow, national betrayal) and explicitly deny each is "the most difficult" (lcls [krjukd ugha gksrh).
- Step 2: Note the tone — no melodrama, no exaggeration; each denial is calm, factual ("cqjk rks gS" — it is difficult, *but* not *the most*).
- Step 3: Infer the trait — a person who refuses to exploit big emotions for effect, who calibrates suffering precisely, is intellectually honest.
- Step 4: Find the structural function — this honesty earns trust for the poem's second half; we believe the final positive definition *because* the speaker didn't cheat earlier.
- Step 5: Connect to central idea — this trait makes the poem's conclusion (ordinary love is hardest) feel earned, not sentimental.
REASONING: Character in lyric poetry is built through *rhetorical moves* (what the speaker does with language), not just content. The negative definition *is* the characterization.
ANSWER: The speaker demonstrates intellectual honesty by calmly rejecting three socially sanctioned 'ultimate sufferings' (war, mother's grief, betrayal) as *not* the most difficult, refusing emotional inflation. This precision establishes their credibility for the poem's real claim: that quiet, daily relational endurance is the true peak of difficulty.

## WORKED_EXAMPLE_2
PROBLEM: Using stanzas 3-4 ("lcls [krjukd gksrk gS / eqnkZ 'kkafr ls Hkj tkuk..."), prove the speaker possesses 'radical empathy' — the ability to feel *with* others, not just *for* them.
STEPS:
- Step 1: Locate the shift — the speaker moves from abstract negations to concrete, second-person scenarios ("vkidh dykbZ", "vkidh fuxkg", "vkiosQ dkuksa").
- Step 2: Analyze the imagery — "dykbZ ij pyrh gqbZ Hkh tks / vkidh fuxkg esa #dh gksrh gS" (shadow on your body trembling in your breath): the speaker *sees* the micro-physical manifestation of another's fear.
- Step 3: Analyze the second image — "tks ph'kksa ls mBrh vaèksiu dh Hkki ij <qyd tkrh gS" (walking bowed under responsibilities tied to ankles): the speaker *feels the weight* of invisible social obligations on another's body.
- Step 4: Synthesize — the speaker doesn't sympathize from outside; they inhabit the other's breath and posture. This is radical empathy: imaginative embodiment.
- Step 5: Link to character arc — this empathy *is* the difficult act the poem defines; the speaker *performs* the hardest thing while describing it.
REASONING: In lyric poetry, character = perception. What the speaker notices and *how* they describe it (breath, ankles, shadow) constitutes their moral anatomy.
ANSWER: The speaker embodies radical empathy by describing two strangers' suffering from *inside* their bodies: the tremor of a shadow in breath, the bow of a spine under invisible ankle-weights. The speaker does not observe pityingly; they co-experience. This empathy is not a feeling but an act of attention — the poem's core definition of 'the most difficult'.

## WORKED_EXAMPLE_3
PROBLEM: The poem ends with the speaker identifying *themselves* as "lcls [krjukd og xhr gksrk gS" (the most difficult is that fragrance which reaches doors...). Trace the complete character arc from Stanza 1 to Stanza 5 in 6 steps.
STEPS:
- Step 1 (Stanza 1): The speaker is a **Critic** — dismantling false maxima (war, grief, betrayal) with surgical negation.
- Step 2 (Stanza 2): The speaker is a **Philosopher** — proposing a new candidate ("lcls [krjukd gksrk gS") and defining it through domestic verbs (Hkj tkuk, ej tkuk, ?kj ls fudyuk).
- Step 3 (Stanza 3): The speaker is a **Witness** — zooming into microscopic details of the leaving (shadow on skin, breath trembling, bowed walk, responsibilities at ankles).
- Step 4 (Stanza 4): The speaker is a **Historian of the Heart** — framing the departure as part of an ancient cycle ("vkRek dk lwjt Mwc tk," / "esgur dh ywV lcls [krjukd ugha") — situating the personal in the eternal.
- Step 5 (Stanza 5): The speaker is the **Fragrance (xhr)** — they *become* the difficult thing: moving toward closed doors (vkiosQ dkuksa rd igq¡pus), reading unspoken pain (ejfl;k i<+rk), dissolving on others' wounds (xaqMs dh rjg vdM+rk).
- Step 6 (Synthesis): The arc is **Critic → Philosopher → Witness → Historian → Fragrance** — a movement from *intellectual distance* to *embodied merger*. The speaker ends *inside* the difficulty they defined.
REASONING: Lyric character evolves *through* the poem's argument. Each stanza advances the speaker's relationship to the subject: from judging it, to defining it, to seeing it, to contextualizing it, to *becoming* it.
ANSWER: The speaker's character arc traces a complete ethical journey: they begin as a detached critic rejecting grand narratives, become a philosopher naming the true difficulty (domestic separation), deepen into a witness recording its bodily textures, widen into a historian linking it to timeless love, and finally *transform into the agent of that difficulty* — the fragrance that actively seeks closed doors to heal wounds. The speaker doesn't just describe the hardest thing; they *enact* it by the poem's end.

## COMPETENCY_QUESTION_1
QUESTION: A Class 11 student writes: "The protagonist of 'lcls [krjukd' is Vinod Kumar Shukla. He finds it hard to leave home because he was born in a village and moved to the city." Identify the two category errors in this answer and rewrite the opening paragraph of a correct character analysis.
COMPETENCY: Conceptual Clarity (Author vs. Speaker distinction) + Textual Grounding
STEPS:
- Step 1: Identify Error 1 — conflating poet (biographical) with speaker (textual construct).
- Step 2: Identify Error 2 — importing external biography (birth/village) to explain textual meaning.
- Step 3: Draft correct opening — name the speaker as a persona, anchor in poem's own logic (negative definitions), state the central trait.
- Step 4: Ensure zero biographical reference; use only textual evidence.
ANSWER: Errors: (1) The protagonist is the *poetic speaker*, not the poet Vinod Kumar Shukla. (2) The analysis uses biography (village/city move) instead of the poem's internal logic (the speaker's *own* criteria for difficulty). Correct opening: "The protagonist of 'lcls [krjukd' is the poetic persona — a reflective, intellectually honest witness who systematically rejects three grand sufferings (war, maternal grief, betrayal) as 'not the most difficult' to arrive at a quiet, domestic definition: the endurance of leaving home while carrying the trembling shadow of a loved one's pain. This speaker is defined not by biography but by a gaze that transforms invisible burdens into the poem's central truth."
DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: "The speaker in 'lcls [krjukd' is genderless." Evaluate this statement. Using *only* the poem's textual evidence (images, verbs, relational positions), argue whether the speaker's gender is indeterminate, fixed, or deliberately fluid — and explain why this matters for the poem's universal claim.
COMPETENCY: Textual Argumentation + Gender/Universality Analysis
STEPS:
- Step 1: Scan for gendered markers — pronouns (none in Hindi 'I'), gendered verb endings (none — 'Hkj tkuk', 'ej tkuk', 'i<+uk' are neutral), social roles (leaving home for work, carrying responsibilities, reading others' pain).
- Step 2: Assess the 'leaving home for work' (dke ij / ?kj ls fudyuk) — historically male-coded in Hindi belt, but poem uses 'gekjs' (our) and 'vkidh' (your), not 'meri'.
- Step 3: Assess the 'witnessing' role (shadow on *your* body, reading *others'* pain) — traditionally female-coded care work, but performed by speaker as *active agent* (igq¡pus, i<+rk, vdM+rk).
- Step 4: Synthesize — the poem *deliberately avoids* gender fixation; the speaker occupies both the leaver (provider) and the stay-behind (witness) through the 'you' address.
- Step 5: Conclude — gender fluidity *is* the mechanism of universality: the 'most difficult' belongs to *anyone* who loves and leaves, or stays and watches.
ANSWER: The speaker's gender is deliberately fluid/indeterminate. Textual evidence: (1) No gendered verb endings or pronouns for 'I'. (2) The speaker performs *both* the act of leaving for work (historically masculine) *and* the act of staying/witnessing the shadow on the beloved's body (historically feminine care). (3) The final transformation into 'fragrance' (xhr — grammatically masculine but symbolically fluid) that enters doors to heal wounds transcends role. This matters because the poem claims the 'most difficult' is a *human* constant, not a gendered one; fixing the speaker's gender would fracture the universal address ("vkidh", "gekjs", "vkiosQ").
DIFFICULTY: hard