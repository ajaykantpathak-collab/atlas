## DEFINITION
Writing skills based on the chapter "इजसेपन" refers to the ability to compose structured, evidence-based responses (character sketches, theme analyses, critical interpretations, and value-based answers) using textual evidence from Premchand's story "उद का नक्शा" while following the PEEL (Point, Evidence, Explanation, Link) framework expected in CBSE Class 11 board examinations.

## COGNITIVE_LEVEL
apply

## MASTERY_CRITERIA
The student can independently write a 150-200 word board-style answer that states a clear thesis, embeds two precise textual references (paraphrased or quoted), explains how each supports the thesis, and concludes by linking to the story's central theme of colonial oppression versus human dignity.

## SCOPE_BOUNDARY
This node covers writing analytical answers, character sketches, and thematic essays specifically for "उद का नक्शा" using PEEL structure; it does NOT cover creative writing formats (story, diary, letter) or grammar exercises, which are separate writing skill categories.

## WALKTHROUGH
Imagine you open your board exam paper and see: "व्याख्या कीजिए कि 'उद का नक्शा' में व्याकुल व्यासिंह ने किस प्रकार औपनिवेशिक सत्ता का प्रतिरोध किया" - your mind goes blank because you know the story but don't know how to *structure* the answer. Start by identifying the *demand word* (व्याख्या कीजिए = explain with evidence). Next, recall two concrete moments: when Vyaksihnhu refuses to salute the Daroga, and when he surrenders his job to protect the villagers. For each moment, apply PEEL: **P**oint (he resists through non-cooperation), **E**vidence (the scene where he says "सरकार हम नहीं जानते"), **E**xplanation (this verbal defiance undermines colonial authority), **L**ink (connects to the theme of dignity over survival). The key insight: board examiners reward *structured argumentation*, not story retelling.

## DIAGNOSTIC_QUESTION_1
What does the 'P' in PEEL stand for, and what is its specific function in a board exam answer for Hindi literature?

## DIAGNOSTIC_ANSWER_1
'P' stands for **Point** - a clear, one-sentence thesis statement that directly answers the question (e.g., "व्यासिंह का प्रतिरोध मौन असहयोग के रूप में प्रकट होता है"). A wrong answer like "Point means the main idea of the story" reveals the student confuses *structural component* with *content summary* and will likely write narrative retelling instead of analytical argument.

## DIAGNOSTIC_QUESTION_2
A student writes: "व्यासिंह बहुत बहादुर थे क्योंकि उन्होंने दरोगा को सलाम नहीं किया और नौकरी छोड़ दी।" Identify which PEEL component is missing and explain why this answer would score low in a Class 11 board exam.

## DIAGNOSTIC_ANSWER_2
The answer has **Point** (bravery) and **Evidence** (refused salute, quit job) but completely lacks **Explanation** (how/why these actions constitute resistance) and **Link** (connection to colonial oppression theme). This reveals the student treats evidence as self-explanatory - a Class 10 habit. In Class 11, examiners require explicit analytical commentary: *why* refusing salute challenges colonial hierarchy, *how* job sacrifice transforms personal loss into collective dignity.

## DIAGNOSTIC_QUESTION_3
Apply the PEEL framework to answer: "उद का नक्शा में व्याकुल व्यासिंह का चरित्र-चित्रण कीजिए।" Write only the **Point** and **Evidence** sentences for the first trait (fearlessness).

## DIAGNOSTIC_ANSWER_3
**Point:** व्याकुल व्यासिंह का चरित्र निडरता और स्वाभिमान की प्रतिमूर्ति है।  
**Evidence:** जब दरोगा ने उन्हें सलाम करने को कहा, तो उन्होंने स्पष्ट कहा - "सरकार हम नहीं जानते" और नौकरी छोड़ने का निर्णय लिया।  
*Reasoning check:* Evidence is specific (quotes dialogue, references action), not vague ("wo bahadur the"). A wrong answer using "वह बहुत बहादुर थे" as evidence shows confusion between *trait* and *textual proof*.

## DIAGNOSTIC_QUESTION_4
Compare these two Explanation sentences for the same evidence (Vyaksihnhu quitting job):  
(A) "इससे पता चलता है कि वे डरे नहीं।"  
(B) "नौकरी त्यागकर व्यासिंह ने औपनिवेशिक तंत्र की आर्थिक बेड़ियों को तोड़ा, जिससे गाँव वालों में प्रतिरोध की चेतना जागी।"  
Analyze which meets Class 11 analytical depth and why.

## DIAGNOSTIC_ANSWER_4
**(B)** meets Class 11 depth because it: (1) uses precise terminology ("औपनिवेशिक तंत्र", "आर्थिक बेड़ियाँ"), (2) explains *mechanism* (how job resignation breaks economic control), (3) extends impact beyond individual to collective ("गाँव वालों में चेतना") - linking to theme. **(A)** is Class 8 level: states the obvious, uses no literary vocabulary, treats character in isolation. Students choosing (A) typically confuse *narration* with *analysis*.

## DIAGNOSTIC_QUESTION_5
Evaluate this claim: "For a 6-mark question on theme, writing three separate PEEL paragraphs (each with different evidence) is better than one long paragraph with three evidences." Defend your judgment with board exam marking logic.

## DIAGNOSTIC_ANSWER_5
**Judgment: True.** CBSE marking schemes allocate marks per *distinct analytical point* (typically 2 marks per PEEL unit: 1 for Point+Evidence, 1 for Explanation+Link). Three separate paragraphs make each point *visibly distinct* to the examiner, reducing risk of missing a point in a dense block. One long paragraph risks: (a) examiner overlooking the second/third evidence, (b) Link sentences getting blurred, (c) word-limit violation. A student arguing "but it flows better" prioritizes aesthetics over marking reality.

## DIAGNOSTIC_QUESTION_6
Create a 2-sentence **Link** sentence that connects Vyaksihnhu's final surrender (going to jail) to the story's central theme, using the phrase "मानवीय गरिमा" (human dignity).

## DIAGNOSTIC_ANSWER_6
**Expected answer:** "अंततः व्यासिंह का कारावास स्वीकार करना सिद्ध करता है कि औपनिवेशिक दमन के सम्मुख मानवीय गरिमा केवल प्रतिरोध में नहीं, बल्कि परिणाम भोगने के साहस में निहित है।"  
*Criteria:* Must (1) reference the specific final action, (2) use the required phrase, (3) articulate a *thematic insight* (not plot summary). A poor answer: "इससे पता चलता है कि मानवीय गरिमा महत्वपूर्ण है" - circular, no textual anchoring, no analytical progression.

## COMMON_MISCONCEPTION
Students believe "good writing" in Hindi literature means using **difficult Sanskritised vocabulary** (e.g., "प्रतिफल" instead of "परिणाम", "अनुचर" instead of "सेवक"). They memorise word lists and force them into answers, producing unnatural, often incorrectly used language that obscures their actual analysis. This stems from confusing *language ornamentation* (Class 10 focus) with *analytical precision* (Class 11 requirement). Example: A student writes "व्यासिंह का त्याग **अतुलनीय** था" - "अतुलनीय" adds zero analytical value; "स्वाभिमान की रक्षा हेतु आत्म-बलिदान" would earn marks.

## ON_FAILURE
1. **Diagnose:** Ask the student to underline every "fancy word" in their last answer and replace each with the simplest Hindi equivalent. If meaning stays intact, the fancy word was decorative, not analytical.  
2. **Retrain:** Give a 3-sentence weak answer loaded with Sanskritised words. Have the student rewrite it using *only* words from the NCERT textbook glossary (शब्द-कोश) - this forces precision over ornamentation.  
3. **Practice:** Assign one daily 80-word PEEL answer where *vocabulary is restricted to textbook words + PEEL connectors* (इससे पता चलता है, यह दर्शाता है, इस प्रकार). Grade only on structure, not vocabulary.  
4. **Reinforce:** Show CBSE topper answer scripts (available on cbseacademic.nic.in) - highlight how they use *simple, precise* language, never ornamental.

## BUILDS_ON
c11_hin_ar_cbse_01_013 (Critical Thinking: Analysis and Interpretation) - students must first analyse the text before writing structured responses about it.

## LEADS_TO
c11_hin_ar_cbse_01_015 (Speaking and Listening: Discussion Points) - written analytical arguments form the basis for structured oral presentations and debates.

## PREREQUISITE_NODE_IDS
c11_hin_ar_cbse_01_001, c11_hin_ar_cbse_01_002, c11_hin_ar_cbse_01_004, c11_hin_ar_cbse_01_006, c11_hin_ar_cbse_01_013, c11_hin_ar_cbse_01_007, c11_hin_ar_cbse_01_008, c11_hin_ar_cbse_01_010, c11_hin_ar_cbse_01_011, c11_hin_ar_cbse_01_012

## PREREQUISITE_REASONS
c11_hin_ar_cbse_01_001: Provides historical context (colonial India, Premchand's background) essential for thematic Links in PEEL.
c11_hin_ar_cbse_01_002: Supplies plot structure knowledge to select appropriate Evidence from beginning/middle/climax.
c11_hin_ar_cbse_01_004: Gives protagonist analysis (Vyaksihnhu's traits) needed for character-sketch Points.
c11_hin_ar_cbse_01_006: Establishes primary theme (colonial oppression vs dignity) required for thematic Links.
c11_hin_ar_cbse_01_013: Develops interpretive skills to generate Explanation sentences beyond surface-level narration.
c11_hin_ar_cbse_01_007: Writing skills for analytical essays demand structured thematic paragraphs with textual evidence — this node teaches the evidence-to-argument pipeline.  
c11_hin_ar_cbse_01_008: Writing skills (analytical paragraph) use the PEEL structure practiced here.  
c11_hin_ar_cbse_01_010: Writing tasks (character sketch, thematic essay) demand deploying these words with correct register and collocation.  
c11_hin_ar_cbse_01_011: Grammar: की समझ आवश्यक है, क्योंकि यह नोड (Writing skills based on the chapter "इजसेपन" refers to the ability to compose structured,...) इसी आधार पर आगे बढ़ता है।  
c11_hin_ar_cbse_01_012: Writing skills (analytical essays) directly apply the PEEL structure and textual evidence discipline from this node  

## FORWARD_NODE_IDS
c11_hin_ar_cbse_01_015, c12_hin_a_cbse_01_014, c12_hin_a_cbse_02_014, c12_hin_a_cbse_03_014, c12_hin_a_cbse_04_014, c12_hin_a_cbse_05_014, c12_hin_a_cbse_06_014, c12_hin_a_cbse_08_014, c12_hin_a_cbse_09_014, c12_hin_a_cbse_10_014, c12_hin_a_cbse_12_014, c12_hin_a_cbse_16_014, c12_hin_a_cbse_17_014, c12_hin_al_cbse_01_014, c12_hin_al_cbse_02_014, c12_hin_al_cbse_03_014, c12_hin_ar_cbse_01_014, c12_hin_ar_cbse_02_014, c12_hin_ar_cbse_04_014, c12_hin_ar_cbse_06_014, c12_hin_ar_cbse_07_014, c12_hin_ar_cbse_08_014, c12_hin_ar_cbse_12_014

## FORWARD_REASONS
c11_hin_ar_cbse_01_015: Written PEEL arguments become speaking points; students convert each paragraph into a 1-minute oral presentation with the same structure.
c12_hin_a_cbse_01_014: Class 11 Antra writing skills foundation (PEEL structure introduction)  
c12_hin_a_cbse_02_014: Class 11 writing skills introduced PEEL; this node advances it with deeper textual evidence and competitive-exam length.  
c12_hin_a_cbse_03_014: Class 11 Antra writing skills foundation — PEEL introduced there.  
c12_hin_a_cbse_04_014: Prior class writing skills foundation (PEEL introduction).  
c12_hin_a_cbse_05_014: अगला तार्किक चरण: Writing Skills based on the chapter refers to the ability to compose structured, evidence-based resp... इस नोड की अवधारणाओं को सीधे उपयोग/विस्तारित करता है।  
c12_hin_a_cbse_06_014: Class 11 Antra writing skills foundation — introduced basic answer structuring for literature.  
c12_hin_a_cbse_08_014: Class 11 writing skills foundation — PEEL structure, answer formatting, quotation embedding.  
c12_hin_a_cbse_09_014: Class 11 writing skills foundation — basic answer structure upgraded to poetry analysis  
c12_hin_a_cbse_10_014: Class 11 Writing Skills (Aroh) established the foundational PEEL framework this node advances  
c12_hin_a_cbse_12_014: कक्षा 11 में लेखन कौशल का आधारभूत अभ्यास (PEEL का परिचय) पहले से सीखा गया मानकर चल रहे हैं।  
c12_hin_a_cbse_16_014: Class 11 Writing Skills introduced PEEL; this node applies it to a specific Class 12 text.  
c12_hin_a_cbse_17_014: Class 11 Antra writing skills baseline — PEEL structure, evidence integration.  
c12_hin_al_cbse_01_014: कक्षा 11 का लेखन कौशल आधारभूत PEEL संरचना और बोर्ड उत्तर लेखन का अभ्यास कराता है  
c12_hin_al_cbse_02_014: Class 11 Antraal writing skills foundation (PEEL basics).  
c12_hin_al_cbse_03_014: Class 11 Writing Skills node establishes the PEEL foundation and board-exam answer conventions.  
c12_hin_ar_cbse_01_014: Class 11 writing skills foundation (PEEL introduction) is directly built upon.  
c12_hin_ar_cbse_02_014: Class 11 writing skills node establishes the PEEL framework and evidence-based writing habit.  
c12_hin_ar_cbse_04_014: कक्षा 11 में सीखी PEEL संरचना और उत्तर-लेखन अभ्यास इस नोड का आधार हैं।  
c12_hin_ar_cbse_06_014: Class 11 foundation in PEEL structure for poetry response  
c12_hin_ar_cbse_07_014: Class 11 Writing Skills (Node 014) introduced PEEL basics — this node advances to *competitive-exam depth*.  
c12_hin_ar_cbse_08_014: Class 11 writing skills foundation — basic paragraph structure, evidence use, formal tone.  
c12_hin_ar_cbse_12_014: Class 11 PEEL foundation — this node advances it with competitive-exam depth  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
none

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_01_013 -> c11_hin_ar_cbse_01_014 -> c11_hin_ar_cbse_01_015

## THIS_FORMULA
PEEL Structure for Hindi Literature Answers:  
**P**oint (प्रतिपाद्य वाक्य) → **E**vidence (पाठ्य साक्ष्य) → **E**xplanation (विश्लेषण) → **L**ink (विषय से संबंध)

## FORMULA_VARIABLES
P = स्पष्ट थीसिस वाक्य जो प्रश्न का सीधा उत्तर देता है  
E = पाठ से सटीक उद्धरण या प्रसंग संदर्भ (अधिकतम 15 शब्द)  
E = साक्ष्य का विश्लेषण: यह थीसिस को कैसे सिद्ध करता है (कारण-कार्य संबंध)  
L = केंद्रीय विषय/संदेश से संबंध जोड़ने वाला समापन वाक्य

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
linguistic

## CROSS_SUBJECT
c11_history_nationalism | Colonial resistance in "उद का नक्शा" parallels historical Non-Cooperation Movement - both use non-violent refusal (job resignation / boycott) to challenge British authority; PEEL analysis of Vyaksihnhu mirrors historical source analysis.
c11_civics_rights | Story illustrates conflict between state power (Daroga) and individual dignity (Vyaksihnhu) - mirrors Fundamental Rights vs State Authority; writing thematic answers trains constitutional interpretation skill.

## PREREQ_CONCEPT
Student must understand that Class 11 Hindi literature answers are **arguments**, not summaries - each sentence must advance a claim supported by text.

## PREREQ_BEFORE
Student can identify: (1) the question's demand word (व्याख्या/विश्लेषण/चित्रण), (2) two relevant textual moments, (3) the story's central theme.

## PREREQ_STUCK
If stuck, review c11_hin_ar_cbse_01_013 (Critical Thinking) to practice extracting analytical points from text, then return to PEEL framing.

## WORKED_EXAMPLE_1
PROBLEM: A student writes this 6-mark answer: "उद का नक्शा का मुख्य विषय औपनिवेशिक शोषण है। व्यासिंह ने दरोगा को सलाम नहीं किया। उन्होंने नौकरी छोड़ दी। अंत में वे जेल चले गए। इससे पता चलता है कि शोषण बुरा है।" Transform this into a board-standard PEEL response.

STEPS:
- Step 1: Identify the question demand - "मुख्य विषय" requires thematic analysis with textual proof, not plot listing.
- Step 2: Break the weak answer into salvageable components: Point (colonial exploitation), Evidence 1 (refused salute), Evidence 2 (resigned job), Evidence 3 (went to jail), but missing Explanation and Link for each.
- Step 3: Build PEEL Paragraph 1: **P** = कहानी का केंद्रीय विषय औपनिवेशिक सत्ता द्वारा मानवीय गरिमा का हनन और उसके विरुद्ध मौन प्रतिरोध है। **E** = जब दरोगा ने व्यासिंह से सलाम माँगा, उन्होंने कहा - "सरकार हम नहीं जानते"। **E** = यह संवाद औपनिवेशिक प्रोटोकॉल की अवहेलना है; सलाम न करना प्रतीकात्मक असहयोग है जो सत्ता के मनोवैज्ञानिक नियंत्रण को भंग करता है। **L** = इस प्रकार व्यक्तिगत स्वाभिमान साम्राज्यवादी अनुशासन को चुनौती देता है।
- Step 4: Build PEEL Paragraph 2 (job resignation) and Paragraph 3 (jail) similarly, each with distinct Point.
- Step 5: Verify word count (≈180 words), check each paragraph has all 4 components, ensure thematic vocabulary (साम्राज्यवादी, मनोवैज्ञानिक नियंत्रण, प्रतीकात्मक असहयोग) replaces vague terms.

REASONING: The transformation teaches that *same content* earns 2/6 vs 6/6 based solely on structure. Each PEEL unit earns 2 marks; the original had 1 Point + 3 Evidences but zero Explanations/Links = ~2 marks. The restructured version has 3 complete PEEL units = 6 marks.

ANSWER: **Full restructured answer (3 PEEL paragraphs):**  
कहानी का केंद्रीय विषय औपनिवेशिक सत्ता द्वारा मानवीय गरिमा का हनन और उसके विरुद्ध मौन प्रतिरोध है। जब दरोगा ने व्यासिंह से सलाम माँगा, उन्होंने कहा - "सरकार हम नहीं जानते"। यह संवाद औपनिवेशिक प्रोटोकॉल की अवहेलना है; सलाम न करना प्रतीकात्मक असहयोग है जो सत्ता के मनोवैज्ञानिक नियंत्रण को भंग करता है। इस प्रकार व्यक्तिगत स्वाभिमान साम्राज्यवादी अनुशासन को चुनौती देता है।  
दूसरा, व्यासिंह ने नौकरी त्यागकर आर्थिक बंधन तोड़ा। "नौकरी छोड़ने का निर्णय लिया" प्रसंग दर्शाता है कि वे जीविका से ऊपर स्वाभिमान रखते हैं। यह त्याग व्यक्तिगत नहीं, सामूहिक चेतना का बीजारोपण करता है - गाँव वाले उनके पीछे खड़े होते हैं। इस प्रकार आर्थिक दासता का नकार सामूहिक प्रतिरोध का आधार बनता है।  
अंततः कारावास स्वीकारना प्रतिरोध की पराकाष्ठा है। जेल जाना "परिणाम भोगने का साहस" सिद्ध करता है कि गरिमा केवल विद्रोह में नहीं, बल्कि कीमत चुकाने में निहित है। कहानी इस प्रकार औपनिवेशिक दमन के सम्मुख मानवीय गरिमा को अजेय स्थापित करती है।

## WORKED_EXAMPLE_2
PROBLEM: Write a character sketch of दरोगा (Daroga) in 100 words using PEEL, showing how he represents colonial mindset. Use exactly two textual evidences.

STEPS:
- Step 1: Determine the Point - Daroga embodies colonial arrogance that equates authority with humiliation of natives.
- Step 2: Select Evidence 1 from early story: Daroga's demand "सलाम करो" and threat "नौकरी चली जाएगी" - shows power play.
- Step 3: Select Evidence 2 from climax: Daroga's reaction when Vyaksihnhu surrenders - "तुम्हारी बहादुरी पर मुझे नाज है" (sarcastic) - reveals colonial condescension.
- Step 4: Write PEEL: **P** = दरोगा औपनिवेशिक मानसिकता का प्रतीक है जो सत्ता को अपमान का पर्याय मानता है। **E** = उसने व्यासिंह को धमकाया - "सलाम करो, नहीं तो नौकरी चली जाएगी"। **E** = यह धमकी दर्शाती है कि औपनिवेशिक तंत्र आर्थिक भय (नौकरी) से मानसिक दासता लागू करता है; सलाम मात्र औपचारिकता नहीं, अधीनता की स्वीकृति है। **E** = अंत में व्यासिंह के समर्पण पर उसकी टिप्पणी - "तुम्हारी बहादुरी पर मुझे नाज है" - उपहासात्मक है, जो औपनिवेशिक श्रेष्ठता-बोध को उजागर करती है। **L** = इस प्रकार दरोगा का चरित्र दिखाता है कि औपनिवेशिक सत्ता सम्मान नहीं, भय और उपहास से शासन करती है।
- Step 5: Count words (≈105), confirm two distinct evidences, verify Link connects to "colonial mindset" theme.

REASONING: Character sketches in Class 11 require *representational analysis* (what the character *stands for*), not personality description. Two evidences are mandated by word limit; each must reveal a different facet (power exercise / ideological attitude).

ANSWER: दरोगा औपनिवेशिक मानसिकता का प्रतीक है जो सत्ता को अपमान का पर्याय मानता है। उसने व्यासिंह को धमकाया - "सलाम करो, नहीं तो नौकरी चली जाएगी"। यह धमकी दर्शाती है कि औपनिवेशिक तंत्र आर्थिक भय से मानसिक दासता लागू करता है; सलाम मात्र औपचारिकता नहीं, अधीनता की स्वीकृति है। अंत में व्यासिंह के समर्पण पर उसकी टिप्पणी - "तुम्हारी बहादुरी पर मुझे नाज है" - उपहासात्मक है, जो औपनिवेशिक श्रेष्ठता-बोध को उजागर करती है। इस प्रकार दरोगा का चरित्र दिखाता है कि औपनिवेशिक सत्ता सम्मान नहीं, भय और उपहास से शासन करती है।

## WORKED_EXAMPLE_3
PROBLEM: A 2023 CBSE question: "उद का नक्शा में 'नक्शा' शब्द केवल भौगोलिक नहीं, प्रतीकात्मक है। विवेचना कीजिए।" Write a 150-word answer integrating symbolism analysis (from c11_hin_ar_cbse_01_009) with PEEL structure.

STEPS:
- Step 1: Decode demand - "विवेचना कीजिए" = analyse with multiple perspectives; "प्रतीकात्मक" requires literary device knowledge (symbolism).
- Step 2: Recall symbolism node (c11_hin_ar_cbse_01_009): 'नक्शा' = colonial survey map (control) vs Vyaksihnhu's mental map of dignity (resistance).
- Step 3: Structure 2 PEEL paragraphs (symbolism needs depth, not breadth). Paragraph 1: Literal vs Symbolic map. Paragraph 2: Vyaksihnhu's counter-map.
- Step 4: Write Paragraph 1: **P** = 'नक्शा' द्वैध प्रतीक है: औपनिवेशिक सर्वेक्षण का उपकरण और मानवीय गरिमा का प्रतिरोध-मानचित्र। **E** = अंग्रेज अधिकारी "नक्शा बनाने" आते हैं - "भूखंड नापते, सीमाएँ खींचते"। **E** = यह भौगोलिक नक्शा भूमि को राजस्व-इकाई में बदलता है, किसान को 'रैयत' (दाता) से 'आंकड़ा' बना देता है; सीमाएँ स्वामित्व नहीं, शोषण तय करती हैं। **L** = इस प्रकार राजकीय नक्शा ज्ञान नहीं, अधिकार का दस्तावेज है।
- Step 5: Write Paragraph 2: **P** = व्यासिंह इसका प्रतिवाद एक वैकल्पिक नक्शे से करते हैं - संबंधों और गरिमा का नक्शा। **E** = वे गाँव वालों से कहते हैं - "यह जमीन हमारी है, हम इसके मालिक हैं"। **E** = यह कथन 'नक्शे' को कागजी सीमाओं से मुक्त कर सामूहिक स्मृति और श्रम में स्थापित करता है; दरोगा का नक्शा कागज पर है, व्यासिंह का नक्शा चेतना में। **L** = कहानी इस द्वंद्व से सिद्ध करती है कि सच्चा नक्शा भूगोल नहीं, मनुष्यता की सीमाएँ खींचता है।
- Step 6: Verify integration - used symbolism terminology (द्वैध प्रतीक, प्रतिवाद, वैकल्पिक नक्शा) from prerequisite node within PEEL.

REASONING: This example demonstrates cross-node synthesis - symbolism analysis (node 009) provides the *analytical lens*, PEEL (this node) provides the *writing scaffold*. Board questions increasingly combine literary devices with thematic analysis; students must migrate concepts across nodes fluidly.

ANSWER: 'नक्शा' द्वैध प्रतीक है: औपनिवेशिक सर्वेक्षण का उपकरण और मानवीय गरिमा का प्रतिरोध-मानचित्र। अंग्रेज अधिकारी "नक्शा बनाने" आते हैं - "भूखंड नापते, सीमाएँ खींचते"। यह भौगोलिक नक्शा भूमि को राजस्व-इकाई में बदलता है, किसान को 'रैयत' से 'आंकड़ा' बना देता है; सीमाएँ स्वामित्व नहीं, शोषण तय करती हैं। इस प्रकार राजकीय नक्शा ज्ञान नहीं, अधिकार का दस्तावेज है।  
व्यासिंह इसका प्रतिवाद एक वैकल्पिक नक्शे से करते हैं - संबंधों और गरिमा का नक्शा। वे गाँव वालों से कहते हैं - "यह जमीन हमारी है, हम इसके मालिक हैं"। यह कथन 'नक्शे' को कागजी सीमाओं से मुक्त कर सामूहिक स्मृति और श्रम में स्थापित करता है; दरोगा का नक्शा कागज पर है, व्यासिंह का नक्शा चेतना में। कहानी इस द्वंद्व से सिद्ध करती है कि सच्चा नक्शा भूगोल नहीं, मनुष्यता की सीमाएँ खींचता है।

## COMPETENCY_QUESTION_1
QUESTION: A Class 11 student writes this answer to "व्यासिंह का चरित्र-चित्रण कीजिए" (6 marks):  
"व्यासिंह एक आदर्श शिक्षक थे। वे बच्चों को पढ़ाते थे। उन्होंने दरोगा को सलाम नहीं किया। नौकरी छोड़ दी। जेल चले गए। वे बहुत बहादुर और ईमानदार थे।"  
Using PEEL criteria, diagnose exactly why this answer would score ≤2/6 and rewrite it as a 4/6 minimum answer (80 words) by adding ONLY Explanation and Link sentences - keep the student's Points and Evidences intact.

COMPETENCY: Diagnostic rewriting - identifying structural gaps and surgically inserting analytical components without changing content.

STEPS:
- Step 1: Map the student's sentences to PEEL: P1=आदर्श शिक्षक, E1=बच्चों को पढ़ाते थे, E2=सलाम नहीं किया, E3=नौकरी छोड़ दी, E4=जेल गए, P2=बहादुर/ईमानदार. Zero Explanations, zero Links.
- Step 2: Insert Explanation after each Evidence: After E1 add "इससे ग्रामीण चेतना जागी"; after E2 add "यह औपनिवेशिक प्रोटोकॉल की अवहेलना थी"; after E3 add "आर्थिक सुरक्षा से ऊपर स्वाभिमान चुना"; after E4 add "परिणाम भोगने का साहस दिखाया".
- Step 3: Add one Link at end connecting to theme: "इस प्रकार व्यासिंह शिक्षक नहीं, प्रतिरोध की प्रतिमूर्ति बनते हैं।"
- Step 4: Ensure total ≤80 words, Hindi fluency maintained.

ANSWER: व्यासिंह एक आदर्श शिक्षक थे। वे बच्चों को पढ़ाते थे, **इससे ग्रामीण चेतना जागी**। उन्होंने दरोगा को सलाम नहीं किया, **यह औपनिवेशिक प्रोटोकॉल की अवहेलना थी**। नौकरी छोड़ दी, **आर्थिक सुरक्षा से ऊपर स्वाभिमान चुना**। जेल चले गए, **परिणाम भोगने का साहस दिखाया**। वे बहुत बहादुर और ईमानदार थे। **इस प्रकार व्यासिंह शिक्षक नहीं, प्रतिरोध की प्रतिमूर्ति बनते हैं।** (76 words)  
*Diagnosis:* Original had 2 Points + 4 Evidences = 2 marks (1 per Point). Revised adds 4 Explanations + 1 Link = +3 marks → 5/6 achievable.

DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: "उद का नक्शा में प्रेमचंद ने संवादों के माध्यम से पात्रों की विचारधारा प्रकट की है।" इस कथन की पुष्टि करते हुए, व्यासिंह और दरोगा के किन्हीं दो-दो संवादों का चयन कर PEEL ढांचे में विश्लेषण कीजिए। (150 शब्द)

COMPETENCY: Evidence selection and comparative dialogue analysis - requires choosing precise quotes, analysing subtext, and maintaining dual-character PEEL structure.

STEPS:
- Step 1: Select Vyaksihnhu's dialogues: (1) "सरकार हम नहीं जानते" (refusal), (2) "यह जमीन हमारी है" (ownership claim).
- Step 2: Select Daroga's dialogues: (1) "सलाम करो, नहीं तो नौकरी चली जाएगी" (coercion), (2) "तुम्हारी बहादुरी पर मुझे नाज है" (mockery).
- Step 3: Build comparative PEEL: Paragraph 1 = Vyaksihnhu's dialogues showing resistance ideology. Paragraph 2 = Daroga's dialogues showing colonial ideology. Paragraph 3 = Contrastive Link.
- Step 4: Write with precise terminology: "संवाद युक्ति", "विचारधारात्मक द्वंद्व", "शक्ति-असमानता".
- Step 5: Verify 150-word limit, 2 dialogues each, clear PEEL in each paragraph.

ANSWER: व्यासिंह के संवाद प्रतिरोध की विचारधारा व्यक्त करते हैं। "सरकार हम नहीं जानते" कहकर वे औपनिवेशिक प्राधिकार की वैधता नकारते हैं - यह संवाद युक्ति मौन असहयोग को भाषा देती है। "यह जमीन हमारी है" कथन सामूहिक स्वामित्व की चेतना जगाता है, राजस्व-नक्शे के विरुद्ध जन-नक्शा खींचता है। दोनों संवाद व्यक्तिगत नहीं, सामाजिक प्रतिरोध का स्वर हैं।  
दरोगा के संवाद औपनिवेशिक विचारधारा उजागर करते हैं। "सलाम करो, नहीं तो नौकरी चली जाएगी" धमकी आर्थिक भय से मानसिक दासता लागू करती है - संवाद में शक्ति-असमानता निहित है। "तुम्हारी बहादुरी पर मुझे नाज है" उपहास औपनिवेशिक श्रेष्ठता-बोध दर्शाता है; प्रतिरोध को भी वह अपनी शर्तों पर परिभाषित करता है।  
दोनों पात्रों के संवादों का द्वंद्व दिखाता है कि भाषा ही विचारधारा का युद्धक्षेत्र है - व्यासिंह की भाषा मुक्ति की, दरोगा की भाषा नियंत्रण की। (148 words)

DIFFICULTY: hard