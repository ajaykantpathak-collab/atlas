## DEFINITION
Critical thinking in literary analysis is the disciplined process of examining a text beyond its literal meaning to uncover deeper layers of significance — evaluating how language, structure, and literary devices work together to convey theme, tone, and the author's perspective, and then forming an independent, evidence-based interpretation.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student can independently analyze a poem by identifying its structural and linguistic choices, interpreting their combined effect on meaning, and articulating a coherent critical interpretation supported by textual evidence — all while distinguishing between summary and analysis.

## SCOPE_BOUNDARY
This node covers critical analysis and interpretation of the two poems in Chapter 3 ("nhi vosQyk" and "eSaus ns[kk] ,d cw¡n") — focusing on how poetic devices, structure, and language create meaning. It does NOT cover plot summary, character sketches, or basic comprehension questions already addressed in prior nodes.

## WALKTHROUGH
Imagine you're reading "nhi vosQyk" for the first time — the poem repeats "nhi vosQyk" like a chant, but you're not sure why the poet insists the nose is small, ugly, and yet demands respect. Start by reading the poem aloud twice: first for sound and rhythm, second to mark every repetition, metaphor, and shift in tone. Notice how the refrain "ij bldks Hkh iafDr dks ns nks" changes from a plea to a demand. Ask: what does the nose represent? Why does the poet equate "iafDr" (dignity) with "y{; ,oa mís';" (rights and duties)? Connect the physical description (stanzas 2-4) to the philosophical claim (stanza 5). The key insight: the poem uses a seemingly trivial body part to make a profound argument about human dignity — analysis means tracing how the trivial becomes profound through poetic craft.

## DIAGNOSTIC_QUESTION_1
What is the primary difference between a summary of "nhi vosQyk" and a critical analysis of the same poem?

## DIAGNOSTIC_ANSWER_1
A summary retells what the poem says (e.g., "The poet describes a small nose and asks for dignity"); a critical analysis explains how the poem achieves its meaning (e.g., "The refrain's progression from request to demand mirrors the speaker's growing assertion of self-worth, while the metaphors in stanza 3 transform the nose into a symbol of marginalized identity"). A wrong answer that merely paraphrases the poem reveals the student conflates summary with analysis — a fundamental error that loses marks in both board and competitive exams.

## DIAGNOSTIC_QUESTION_2
In stanza 3 of "nhi vosQyk," the nose is called "eèkq" (inkwell), "xksjl" (pen), and "vaoqQj" (paper). A student writes: "These are just random objects the poet picked." Why is this interpretation insufficient?

## DIAGNOSTIC_ANSWER_2
The three metaphors form a deliberate triad: inkwell (source), pen (instrument), paper (surface) — together representing the complete apparatus of writing/creation. The nose is thus figured as the entire creative faculty, not a random assortment. A student who misses the systemic connection fails to see how the poet elevates a "small" organ to a cosmic creative principle — an error of under-reading metaphoric clusters, common in board exams where students list devices without interpreting their relational logic.

## DIAGNOSTIC_QUESTION_3
Apply the concept of "refrain evolution" to analyze how the repeated line "ij bldks Hkh iafDr dks ns nks" changes in force across the five stanzas of "nhi vosQyk."

## DIAGNOSTIC_ANSWER_3
Step 1: Identify the refrain in each stanza (appears as last line in all five). Step 2: Note the preceding context — stanza 1: physical description; stanza 2: existential questions ("xhr", "eksrh"); stanza 3: creative metaphors; stanza 4: moral virtues ("oqQRlk", "vieu", "voKk"); stanza 5: societal rejection ("fpj&v[kaM"). Step 3: Trace tonal shift — polite request → philosophical grounding → creative assertion → moral claim → defiant demand. Step 4: Conclude: the refrain accumulates moral weight as the poem builds evidence for the nose's dignity. A wrong answer that treats the refrain as mere repetition misses the poem's argumentative architecture — a key analytical skill tested in CUET and board competency questions.

## DIAGNOSTIC_QUESTION_4
Compare the treatment of "self-perception vs. societal perception" in "nhi vosQyk" and "eSaus ns[kk] ,d cw¡n." How do the two poems differ in their resolution of this tension?

## DIAGNOSTIC_ANSWER_4
In "nhi vosQyk," the speaker actively demands societal recognition ("iafDr dks ns nks") — resolution is external, confrontational. In "eSaus ns[kk] ,d cw¡n," the speaker observes the crow's blackness ("jax xbZ {k.kHkj") and feels wonder ("u'ojrk osQ nkx ls") — resolution is internal, aesthetic. The first poem weaponizes dignity; the second discovers beauty in perceived ugliness. A student who says "both are about accepting oneself" flattens the critical distinction between demand and discovery — a reductionist error that ignores how form (direct address vs. observation) shapes thematic resolution.

## DIAGNOSTIC_QUESTION_5
Evaluate this claim: "The poem 'nhi vosQyk' is ultimately a failure because it argues for dignity based on utility (the nose as writer, moral agent) rather than inherent worth." Defend or refute with textual evidence.

## DIAGNOSTIC_ANSWER_5
Refute. The poem's structure moves from utility (stanzas 2-3: creative function) to inherent moral qualities (stanza 4: "oqQRlk", "vieu", "voKk" — purity, patience, tolerance) to existential assertion (stanza 5: "folftZr" — self-complete). The final stanza's "fpj&v[kaM viukik" (blooms in its own way) declares worth independent of utility. A student who accepts the claim misreads the poem's dialectical progression — a critical error in evaluation questions where board marking schemes reward recognition of textual complexity over simplistic readings.

## DIAGNOSTIC_QUESTION_6
Write a four-line stanza in the style of "nhi vosQyk" that extends the poem's argument to another marginalized body part (e.g., ears, hands, feet), maintaining the refrain structure and metaphorical escalation.

## DIAGNOSTIC_ANSWER_6
Example for ears:
;g lksuk Lusg Hkjk
gS xoZ Hkjk enekrk] ij bldks Hkh iafDr dks ns nksA
;g lksuk gSµLo;a lk/kkj ds vuqHko dk i`Fkd lkFkZd]
;g lksuk gSµthou osQ lkFkZd dk izkFkZuk i`Fkd vkSj vkn'kZ]
;g lksuk gSµfuekZ.k dh ,d nknh] tks lkFkZd dks lkFkZd ls tksM+rk gSA
;g lksuk] Lusg Hkjk
gS xoZ Hkjk enekrk] ij bldks Hkh iafDr dks ns nksA
A strong answer mirrors the original's movement from physicality to function to moral/existential claim, ending with the refrain. A weak answer merely describes the body part without metaphorical escalation — revealing inability to internalize the poem's structural logic.

## COMMON_MISCONCEPTION
Students believe "critical analysis" means listing poetic devices (metaphor, alliteration, refrain) and defining them. They write: "The poet uses metaphor in stanza 3: nose as inkwell, pen, paper." This is device-spotting, not analysis. The error stems from classroom drills that reward identification over interpretation. In board exams, such answers get 1-2 marks out of 5; in CUET/JEE-style questions, they score zero because the question asks "analyze the effect," not "identify the device." The correct move: for every device, ask "What does this comparison achieve? How does it shift the poem's argument?" — and answer that.

## ON_FAILURE
If a student cannot move beyond device identification: 1) Have them re-read the poem with one question: "What is the poet trying to prove?" 2) Map each stanza to a stage of that proof (description → questioning → metaphorical elevation → moral enumeration → defiant assertion). 3) Practice the "So what?" drill: for each device, write one sentence starting "This device shows that..." 4) Re-attempt Diagnostic Question 3 with this scaffold. Revisit node c12_hin_a_cbse_03_008 (imagery) and c12_hin_a_cbse_03_009 (symbolism) to strengthen device-to-meaning links.

## BUILDS_ON
Literal and inferential comprehension (node c12_hin_a_cbse_03_012) — you cannot analyze what you do not first understand at surface and implied levels.

## LEADS_TO
Writing skills based on the chapter (node c12_hin_a_cbse_03_014) — critical analysis provides the evidence and argument structure required for analytical essays and long-answer questions.

## PREREQUISITE_NODE_IDS
c12_hin_a_cbse_03_012, c12_hin_a_cbse_03_008, c12_hin_a_cbse_03_009, c12_hin_a_cbse_03_006, c11_hin_ar_cbse_16_013, c12_hin_a_cbse_03_004, c12_hin_a_cbse_03_005, c12_hin_a_cbse_03_007, c12_hin_a_cbse_03_010, c12_hin_a_cbse_03_011

## PREREQUISITE_REASONS
c12_hin_a_cbse_03_012: Comprehension provides the factual and inferential base without which analysis has no textual anchor.
c12_hin_a_cbse_03_008: Imagery and metaphor identification is the raw material for interpretive analysis.
c12_hin_a_cbse_03_009: Irony and symbolism detection enables reading beyond the literal — essential for "nhi vosQyk"'s satirical undertones.
c12_hin_a_cbse_03_006: Primary theme recognition gives the analytic framework; analysis tests and refines thematic understanding.
c11_hin_ar_cbse_16_013: Class 11 critical thinking node establishes the analytical vocabulary and habits this node deepens.
c12_hin_a_cbse_03_004: Critical thinking node requires the close-reading habits (tracking refrain, address mode, metaphor clusters) built here.  
c12_hin_a_cbse_03_005: Critical Thinking requires synthesizing the roles into an interpretive argument (e.g., "Does the poem essentialize or liberate?").  
c12_hin_a_cbse_03_007: Secondary themes are the subsidiary ideas, motifs, or concerns that run parallel to the pr... की समझ आवश्यक है, क्योंकि यह नोड (Critical thinking in literary analysis is the disciplined process of examining a text beyo...) इसी आधार पर आगे बढ़ता है।  
c12_hin_a_cbse_03_010: Critical interpretation of themes like 'nature as divine' depends on precise understanding of words like 'izÑr', 'Lo;aHkw', 'fojkV~'.  
c12_hin_a_cbse_03_011: Critical interpretation of themes (individual vs society) depends on analyzing grammatical agency (imperative vs past perfect).  

## FORWARD_NODE_IDS
c12_hin_a_cbse_03_014, c12_hin_a_cbse_03_015
## FORWARD_REASONS
c12_hin_a_cbse_03_014: Writing skills require the analytical claims and textual evidence generated here to construct coherent essays.
c12_hin_a_cbse_03_015: Speaking/listening discussions need interpreted positions (not just summaries) to sustain meaningful debate.

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
N/A

## CHAIN_DESCRIPTION
c12_hin_a_cbse_03_012 -> c12_hin_a_cbse_03_013 -> c12_hin_a_cbse_03_014

## THIS_FORMULA
N/A - conceptual

## FORMULA_VARIABLES
N/A

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
conceptual

## CROSS_SUBJECT
N/A | Both subjects require identical analytical moves: device identification → effect explanation → thematic synthesis. The PEEL paragraph structure taught in English is directly transferable to Hindi long-answer writing.
 N/A | The poem's argument about dignity for the marginalized maps onto Tajfel's social identity theory — "nhi vosQyk" performs ingroup pride assertion against outgroup stigma, a concept examinable in both board psychology and CUET humanities.
## PREREQ_CONCEPT
The distinction between "what the text says" (comprehension) and "how the text means" (analysis) — specifically, understanding that poetic form (refrain, stanza structure, metaphor clusters) is not decorative but argumentative.

## PREREQ_BEFORE
Student must be able to independently paraphrase each stanza of both poems and identify at least three poetic devices per poem with line references.

## PREREQ_STUCK
If stuck, return to c12_hin_a_cbse_03_012 (comprehension) and re-do the inferential questions; then review c12_hin_a_cbse_03_008 and 009 with a focus on "effect" not "definition."

## WORKED_EXAMPLE_1
PROBLEM: Analyze how the metaphor cluster in stanza 3 of "nhi vosQyk" (nose as inkwell, pen, paper) transforms the poem's argument from physical description to creative agency.

STEPS:
- Step 1: Locate the metaphor cluster — stanza 3 lines: "eèkq", "xksjl", "vaoqQj" — and note they are presented as a definition ("eèkq gSµ...", "xksjlµ...", "vaoqQjµ...").
- Step 2: Identify the shared domain — all three are instruments of writing/creation (source, tool, surface). The nose is not just one tool but the entire writing apparatus.
- Step 3: Determine the semantic shift — earlier stanzas describe the nose passively (size, shape, parentage); here it becomes an active creative force. The verb "fuHkZ;" (to inspire/compel) assigns agency.
- Step 4: Connect to the refrain — the demand for dignity ("iafDr dks ns nks") is now grounded in creative necessity: a society that dismisses this nose dismisses creativity itself.
- Step 5: Evaluate the escalation — the poem moves from "this nose exists" (stanza 1) to "this nose creates" (stanza 3) to "this nose embodies moral virtues" (stanza 4). The metaphor cluster is the pivot from existence to value.

REASONING: This analysis works because it treats metaphors as argumentative moves, not ornaments. Each step builds a causal chain: device → semantic domain → agency shift → thematic grounding → structural escalation. This mirrors the "evidence → explanation → link" structure examiners reward.

ANSWER: The inkwell-pen-paper triad redefines the nose as the totality of creative production, transforming the poem from a plea for acceptance of a physical trait into a claim that marginalized identities are society's creative engine. The metaphor cluster is the structural hinge on which the poem's argument turns.

## WORKED_EXAMPLE_2
PROBLEM: Interpret the significance of the crow's blackness in "eSaus ns[kk] ,d cw¡n" — why does the speaker call it "jax xbZ {k.kHkj" (color flew from blackness) and feel "u'ojrk" (wonder) rather than revulsion?

STEPS:
- Step 1: Establish the cultural default — in Indian context, "kala" (black) often carries negative associations (kala dhan, kala jadu, fairness cream ads). The poem knows this.
- Step 2: Analyze the phrasing "jax xbZ {k.kHkj" — color didn't just "become" black; it "flew" from blackness, as if blackness is the source, not the stain. The verb "xbZ" (flew) implies lightness, freedom, origin.
- Step 3: Examine the light source — "<yrs lwjt dh vkx ls" (from the ray of the setting sun). The crow's blackness is revealed by fading light, not hidden by it. Darkness illuminates.
- Step 4: Read the emotional response — "u'ojrk osQ nkx ls" (from the wonder of novelty). The speaker experiences cognitive defamiliarization: the familiar crow becomes strange and wondrous.
- Step 5: Synthesize — the poem enacts a perceptual revolution: blackness is not absence of color but its concentrated source. The crow becomes a teacher of revised aesthetics.

REASONING: This interpretation follows the hermeneutic circle: cultural context → linguistic precision → imagery analysis → affective response → thematic synthesis. It avoids the trap of imposing external symbolism (e.g., "crow = death") by staying rooted in the poem's own lexical and syntactic choices.

ANSWER: The crow's blackness functions as an aesthetic epistemology — the poem teaches us to see darkness as generative (color's origin) rather than privative (color's absence). The speaker's wonder is the reader's intended epiphany: marginalized beauty requires a shift in the perceiver, not the perceived.

## WORKED_EXAMPLE_3
PROBLEM: Compare the rhetorical strategies of the two poems: "nhi vosQyk" uses direct address and demand; "eSaus ns[kk] ,d cw¡n" uses observation and revelation. Which strategy is more effective for asserting dignity, and why?

STEPS:
- Step 1: Map rhetorical mode — Poem 1: second-person imperative ("ns nks" — give it), apostrophe to "iafDr" (dignity personified). Poem 2: first-person perceptual report ("eSaus ns[kk]" — I saw), no direct address.
- Step 2: Identify implied audience — Poem 1: society ("lekt"), which must be compelled. Poem 2: the reader, who is invited to share the speaker's vision.
- Step 3: Analyze temporal structure — Poem 1: eternal present of demand (refrain repeats identically but accumulates force). Poem 2: single moment of perception ("eSaus ns[kk]") that expands into timeless insight.
- Step 4: Evaluate political implications — Poem 1 enacts rights-claiming discourse (Ambedkarite "educate, agitate, organize"). Poem 2 enacts aesthetic resistance (redefining beauty standards from within).
- Step 5: Judge effectiveness contextually — For legal/social rights: Poem 1's strategy is necessary (dignity as claim). For cultural/psychological liberation: Poem 2's strategy is deeper (dignity as realized perception). The poems are complementary, not competitive.
- Step 6: Conclude with textual synthesis — The chapter places them together to show dignity requires both external recognition (Poem 1) and internal revaluation (Poem 2).

REASONING: This comparison works because it uses rhetorical analysis (mode, audience, temporality) as the lens, not just thematic similarity. It respects each poem's distinct formal logic while showing how the anthology curates them into a dialectic. This is the level of synthesis expected in 6-mark board questions and CUET critical thinking passages.

ANSWER: Neither strategy is universally "more effective"; they operate at different registers of dignity. "nhi vosQyk" demands dignity as a right from society (external, agonistic); "eSaus ns[kk] ,d cw¡n" discovers dignity as an aesthetic truth in the self (internal, epiphanic). The chapter's pedagogy implies both are necessary — a sophisticated answer that earns full marks by refusing false binaries.

## COMPETENCY_QUESTION_1
QUESTION: A student writes in the board exam: "The poem 'nhi vosQyk' uses refrain to emphasize the main idea." The examiner awards 1 out of 3 marks. Using the marking scheme logic, explain what the student missed and rewrite the answer to secure full marks.

COMPETENCY: Exam technique — understanding marking scheme expectations for literary analysis
STEPS:
- Step 1: Identify the rubric gap — "emphasize the main idea" is a generic function of refrain; it does not specify which idea, how the refrain evolves, or what textual evidence supports the claim.
- Step 2: Recall the marking scheme requirement — CBSE awards marks for: (a) identification of device, (b) explanation of its specific function in this poem, (c) textual evidence (line/stanza reference), (d) connection to theme.
- Step 3: Draft improved answer — "The refrain 'ij bldks Hkh iafDr dks ns nks' appears in all five stanzas but its justificatory context shifts: stanza 1 (physical), 2 (existential), 3 (creative), 4 (moral), 5 (defiant). This evolution transforms the refrain from a polite request into an unassailable demand, mirroring the poem's argument that dignity is earned through layered self-knowledge."
- Step 4: Verify against rubric — device named, specific function explained, structural evidence given, thematic link made.

ANSWER: The student missed the refrain's dynamic evolution and its structural role in argument-building. The rewritten answer earns 3/3 by showing how form enacts meaning — the core competency for literary analysis questions.

DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: In a CUET-style critical reasoning passage, you are given a new 4-line poem fragment: "These hands are rough / They do not shine / But they built the bridge / You walk on." The question asks: "Which poem from your textbook — 'nhi vosQyk' or 'eSaus ns[kk] ,d cw¡n' — does this fragment most closely resemble in its rhetorical strategy? Justify with two points."

COMPETENCY: Transfer of analytical framework to unseen text — comparative rhetorical analysis
STEPS:
- Step 1: Analyze the fragment — speaker: first-person collective ("These hands"); tone: assertive pride; strategy: counter-description (rough/not shiny) followed by evidence of value (built the bridge); audience: implied "you" who benefits but may despise.
- Step 2: Compare with "nhi vosQyk" — both use direct address to a dismissive audience, both counter physical stigma with functional/moral value, both end on a note of indispensable contribution (nose as creator / hands as bridge-builders).
- Step 3: Compare with "eSaus ns[kk] ,d cw¡n" — that poem has no "you," no counter-argument, no claim of utility; it offers perceptual revaluation without confrontation.
- Step 4: Select and justify — Fragment resembles "nhi vosQyk" because: (1) both employ agonistic rhetoric (addressing a hostile/ignorant other), (2) both ground dignity in tangible, socially necessary labor/creation rather than inherent essence alone.
- Step 5: Formulate concise answer for exam conditions.

ANSWER: The fragment resembles "nhi vosQyk." Both use second-person confrontation to challenge societal devaluation of a stigmatized body part, and both justify dignity through demonstrable creative/constructive agency (nose as writer, hands as bridge-builders) rather than abstract appeal.

DIFFICULTY: hard