## DEFINITION
Imagery is the use of vivid and descriptive language that appeals to the senses (sight, sound, touch, taste, smell) to create mental pictures. Metaphor is a figure of speech that directly compares two unrelated things by stating one is the other, without using 'like' or 'as', to suggest a deeper resemblance.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student can identify specific images and metaphors in Kabir's poem, explain how they appeal to the senses, and analyze how they reinforce the poem's central theme of spiritual devotion versus worldly illusion.

## SCOPE_BOUNDARY
This node covers the identification and analysis of imagery (visual, auditory, tactile) and metaphor in the prescribed poem by Kabir (ehjk). It does not cover other literary devices like irony, symbolism, or simile, which are addressed in subsequent nodes.

## WALKTHROUGH
Imagine you are listening to a street musician in Varanasi singing Kabir's verses; the words paint a picture of a weaver at his loom, the rhythm of the shuttle, and the scent of incense. To begin analyzing the poem, first read it aloud to hear the cadence and notice which words trigger sensory experiences. Next, underline phrases that describe something you can see, hear, or feel. Then, ask yourself: what is being compared to what without using 'like' or 'as'? Finally, connect each image and metaphor to the poet's message about the soul's journey. The key insight is that Kabir uses everyday weaving imagery to metaphorically represent the divine fabric of existence.

## DIAGNOSTIC_QUESTION_1
What is the definition of a metaphor, and how does it differ from a simile?

## DIAGNOSTIC_ANSWER_1
A metaphor directly states that one thing is another (e.g., "Life is a journey"), while a simile uses 'like' or 'as' to compare (e.g., "Life is like a journey"). A wrong answer that confuses the two or says they are the same reveals the student cannot distinguish the structural difference, which is essential for identifying metaphors in the poem.

## DIAGNOSTIC_QUESTION_2
In the poem, the line "लारु फ<क्स cSfB&cSfB" (the shuttle moves back and forth) creates which type of imagery, and what sensory experience does it evoke?

## DIAGNOSTIC_ANSWER_2
This line creates visual and auditory imagery: the reader sees the shuttle moving and hears the rhythmic sound of the loom. A wrong answer that only says "it shows movement" misses the multi-sensory nature of Kabir's imagery, indicating the student is not attending to the full sensory appeal.

## DIAGNOSTIC_QUESTION_3
Identify a metaphor in the poem where the poet compares the human body or life to an object related to weaving. Explain the comparison.

## DIAGNOSTIC_ANSWER_3
The poem metaphorically equates the human body to a loom (or the fabric being woven). The weaver (Kabir) is the soul, the shuttle is the breath, and the cloth is the karma or life's work. A wrong answer that picks a literal description of weaving without recognizing the metaphorical layer shows the student cannot transfer the concept of metaphor to the specific context of the poem.

## DIAGNOSTIC_QUESTION_4
Compare the imagery of "वल्कौउ त्य ल्हाफ्प&ल्हाफ्प" (the intoxicating wine of love) with "इज़्से&क्स्फ्य क्स;्ह" (the cup of union). How do these two images work together to convey the intensity of spiritual longing?

## DIAGNOSTIC_ANSWER_4
The first image appeals to taste and intoxication, suggesting overwhelming divine love; the second adds a visual and tactile image of a cup, implying a vessel for that love. Together they create a progression from internal feeling to external ritual. A wrong answer that treats them as separate unrelated images fails to see the layered imagery building a single emotional arc.

## DIAGNOSTIC_QUESTION_5
Evaluate the effectiveness of Kabir's use of weaving metaphors to communicate his philosophical ideas to a common audience in 15th-century India.

## DIAGNOSTIC_ANSWER_5
The metaphors are highly effective because weaving was a familiar occupation; using its terminology (loom, shuttle, thread, cloth) made abstract spiritual concepts concrete and relatable. A wrong answer that calls them "just decorative" or "confusing" reveals an inability to assess literary devices in their historical and cultural context.

## DIAGNOSTIC_QUESTION_6
Write four original lines of poetry that use weaving imagery as a metaphor for a personal struggle or journey, incorporating at least two sensory images.

## DIAGNOSTIC_ANSWER_6
A good answer will have four lines, use weaving terms (thread, loom, shuttle, knot) metaphorically, and include at least two sensory details (e.g., "the rough thread bites my fingers", "the loom hums a low lullaby"). A poor answer that merely describes weaving literally without metaphorical meaning shows the student cannot create original metaphorical imagery.

## COMMON_MISCONCEPTION
Students often think that any descriptive word in the poem is an 'image' and any comparison is a 'metaphor'. For example, they may label "न्वेक ध एफ्कुफुइक्" (the threads of the new cloth) as a metaphor simply because it mentions cloth, missing that it is a literal description of the weaving process. They confuse literal domain-specific vocabulary with figurative language because Kabir's poem blends the literal craft of weaving with spiritual metaphor seamlessly.

## ON_FAILURE
1. Ask the student to list all weaving-related words in the poem (loom, shuttle, thread, cloth, weaver). 2. For each word, have them decide: is it used literally (describing the actual craft) or figuratively (representing something else)? 3. Guide them to see that words like "शटल" (shuttle) are literal in the first stanza but become metaphorical for "breath" or "time" in later context. 4. Practice with a simpler poem where the metaphor is more explicit (e.g., "Time is a river") before returning to Kabir.

## BUILDS_ON
Understanding the poem's narrative structure and primary theme (nodes 10_002 and 10_006) provides the context needed to interpret why Kabir chooses weaving imagery.

## LEADS_TO
Analysis of irony and symbolism (node 10_009) requires the foundational skill of distinguishing literal from figurative language established here.

## PREREQUISITE_NODE_IDS
c11_hin_ar_cbse_10_001, c11_hin_ar_cbse_10_002, c11_hin_ar_cbse_10_003, c11_hin_ar_cbse_10_006, c11_hin_ar_cbse_10_007
## PREREQUISITE_REASONS
c11_hin_ar_cbse_10_001: Context of Kabir's life and Bhakti movement explains why he uses weaving metaphors.
c11_hin_ar_cbse_10_002: Narrative structure shows how the poem progresses from literal weaving to spiritual allegory.
c11_hin_ar_cbse_10_003: Setting and atmosphere (the weaver's workshop) grounds the sensory imagery.
c11_hin_ar_cbse_10_006: Primary theme (devotion vs. illusion) is the target concept that the metaphors illuminate.
c11_hin_ar_cbse_10_007: Secondary themes (social equality, guru-disciple relationship) are also conveyed through the same imagery.

## FORWARD_NODE_IDS
c11_hin_ar_cbse_10_009, c11_hin_ar_cbse_10_010, c11_hin_ar_cbse_10_011, c11_hin_ar_cbse_10_012, c11_hin_ar_cbse_10_013, c11_hin_ar_cbse_10_014, c11_hin_ar_cbse_10_015, c12_hin_a_cbse_04_008, c12_hin_a_cbse_05_008, c12_hin_a_cbse_10_008, c12_hin_a_cbse_16_008, c12_hin_ar_cbse_10_008

## FORWARD_REASONS
c11_hin_ar_cbse_10_009: Irony and symbolism build on the ability to detect figurative language.
c11_hin_ar_cbse_10_010: Vocabulary in context relies on distinguishing literal and metaphorical meanings of key words.
c11_hin_ar_cbse_10_011: Grammar usage includes analyzing how metaphorical constructions function syntactically.
c11_hin_ar_cbse_10_012: Comprehension questions often ask for interpretation of images and metaphors.
c11_hin_ar_cbse_10_013: Critical thinking requires evaluating the effectiveness of these devices.
c11_hin_ar_cbse_10_014: Writing skills tasks may ask students to employ similar imagery in their own compositions.
c11_hin_ar_cbse_10_015: Speaking and listening discussions about the poem's imagery benefit from this analysis.
c12_hin_a_cbse_04_008: Metaphor of river in "Jal Hi Jeevan Hai" — parallel to water-as-life metaphor here.  
c12_hin_a_cbse_05_008: Practices comparative analysis of two poems' imagery.  
c12_hin_a_cbse_10_008: Direct prior exposure to imagery/metaphor definitions and poetic examples; this node transfers those skills to prose.  
c12_hin_a_cbse_16_008: Covers common errors (simile vs metaphor, generic vs specific imagery).  
c12_hin_ar_cbse_10_008: Class 11 foundation — definitions, basic identification, simple examples of imagery/metaphor in Hindi poetry/prose.  

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_10_001 -> c11_hin_ar_cbse_10_008 -> c11_hin_ar_cbse_10_009

## THIS_FORMULA
N/A - conceptual

## FORMULA_VARIABLES
N/A

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
conceptual

## CROSS_SUBJECT
c11_history_bhakti_movement | Kabir's weaving metaphors reflect the socio-religious context of the Bhakti movement, where artisan-poets used their craft vocabulary to democratize spirituality.
c11_geography_river_systems | The poem's imagery of threads and flow can be linked to geographical concepts of river networks as metaphors for life's journey, a common trope in Indian literature.
c11_civics_social_equality | Kabir's metaphor of the loom where all threads are equal regardless of color anticipates modern constitutional ideals of equality and fraternity.

## PREREQ_CONCEPT
Ability to distinguish literal language from figurative language in a text.

## PREREQ_BEFORE
Student must know the basic definitions of imagery (sensory language) and metaphor (direct comparison) from earlier classes.

## PREREQ_STUCK
Review the definitions of imagery and metaphor with simple examples (e.g., "The classroom was a zoo" vs "The classroom was noisy like a zoo").

## WORKED_EXAMPLE_1
PROBLEM: Analyze the visual and tactile imagery in the lines describing the weaver's loom ("लारु फ<क्स cSfB&cSfB, य्क्स्द&य्क्त [क्;्ह") and explain how they establish the poem's setting.
STEPS:
- Step 1: Read the lines aloud and list every word that appeals to sight (e.g., shuttle moving, cloth forming) and touch (e.g., rhythm of the loom, texture of thread).
- Step 2: Classify each as visual or tactile imagery.
- Step 3: Explain how the combined imagery creates a vivid workshop atmosphere — the reader 'sees' the shuttle's motion and 'feels' the rhythmic vibration.
- Step 4: Connect this setting to the poem's theme: the physical loom becomes the stage for the spiritual drama.
- Step 5: Verify by checking if the imagery supports the idea of the body as a loom and the soul as the weaver.
REASONING: By systematically identifying sensory words and linking them to the poem's central metaphor, the student learns to move from observation to interpretation.
ANSWER: The lines use visual imagery (shuttle moving back and forth, cloth being woven) and tactile imagery (the rhythmic beat, the texture of yarn) to immerse the reader in the weaver's world. This concrete setting later becomes the metaphorical framework for the soul's work.

## WORKED_EXAMPLE_2
PROBLEM: Identify the metaphor in "इज़्से क्स्फ्य इक़ुफ्य क्ष्;ह" (the cup of union is the intoxicating wine) and explain the two things being compared and the implied meaning.
STEPS:
- Step 1: Locate the phrase and note that it equates "cup of union" (इज़्से क्स्फ्य) with "intoxicating wine" (वल्कौउ त्य ल्हाफ्प&ल्हाफ्प) without using 'like' or 'as'.
- Step 2: Identify the tenor (the subject: spiritual union with the divine) and the vehicle (the image: wine/cup).
- Step 3: Analyze the qualities of wine (intoxication, loss of self, pleasure) that are transferred to the spiritual experience.
- Step 4: Discuss why Kabir chooses wine — a forbidden substance in orthodox Islam and Hinduism — to describe divine love, showing his iconoclasm.
- Step 5: Relate this metaphor to the poem's broader message of transcending religious boundaries.
REASONING: Breaking down metaphor into tenor and vehicle and then contextualizing the vehicle's cultural connotations deepens analysis beyond mere identification.
ANSWER: The metaphor equates the cup of divine union (tenor) with intoxicating wine (vehicle). It suggests that spiritual union intoxicates the devotee, dissolving ego and social norms, just as wine clouds the mind. Kabir's deliberate use of a taboo substance underscores his rejection of ritual orthodoxy.

## WORKED_EXAMPLE_3
PROBLEM: Trace the extended metaphor of weaving throughout the poem. Show how the literal weaving terms (loom, shuttle, thread, cloth, weaver) map onto spiritual concepts (body, breath, karma, life, soul) in at least four instances.
STEPS:
- Step 1: List all weaving terminology in the poem (e.g., लारु, फ<क्स, न्वेक, एफ्कुफुइक्, य्क्स्द, क्स्फ्य, एह्ज्का).
- Step 2: For each term, determine its literal meaning in the weaving craft.
- Step 3: Identify the spiritual concept it represents in the poem's allegory (e.g., लारु = breath/life force, फ<क्स = time/motion, न्वेक = karma/actions, एह्ज्का = the soul/weaver).
- Step 4: Create a mapping table with columns: Weaving Term, Literal Meaning, Spiritual Counterpart, Stanza Reference.
- Step 5: Analyze how the consistency of this extended metaphor structures the entire poem as an allegory.
- Step 6: Evaluate why an extended metaphor is more powerful than isolated metaphors for conveying a philosophical system.
REASONING: Extended metaphor (allegory) requires tracking a network of correspondences; the table method ensures systematic coverage and reveals the poem's architectural coherence.
ANSWER: The poem sustains an extended metaphor: the weaver (Kabir/soul) works on the loom (body) with the shuttle (breath) weaving the thread (karma) into cloth (life's fabric). The "cup of union" (क्ख्फ्य) is the final product offered to the divine. This sustained mapping transforms a craft description into a complete spiritual cosmology.

## COMPETENCY_QUESTION_1
QUESTION: The poem uses the metaphor of weaving to describe the human condition. Explain how the imagery of "न्वेक ध एफ्कुफुइक् क्म्+स इज़्से ल्स फोय्क्सुइक्" (the new cloth's threads are separated from the great wine/intoxication) illustrates the tension between worldly attachments and spiritual liberation. Use the PEEL structure (Point, Evidence, Explanation, Link).
COMPETENCY: Analytical interpretation of metaphor and imagery in a literary text.
STEPS:
- Step 1: State the point: the metaphor of cloth threads represents worldly bonds that must be detached for liberation.
- Step 2: Provide evidence: quote the phrase and note the sensory words (threads, separated, great wine).
- Step 3: Explain: the threads are individual karmic bonds; the 'great wine' is divine intoxication that dissolves them.
- Step 4: Link: this tension is central to Kabir's message that true devotion requires renouncing egoistic attachments.
ANSWER: The metaphor portrays worldly attachments as threads of a cloth that must be unraveled (separated) to experience the 'great wine' of divine union. The tactile image of separating threads conveys the painstaking effort of detachment, while the gustatory image of wine conveys the overwhelming reward. This encapsulates Kabir's teaching that liberation is both a labor and a grace.
DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: Compare Kabir's use of the weaving metaphor in this poem with the use of the 'potter and clay' metaphor in another Bhakti poet's work (e.g., Kabir's own "मिटि कहै कुम्हार से" or Ravidas's verses). Discuss how the choice of craft metaphor reflects the poet's social identity and intended audience. Provide at least three specific points of comparison.
COMPETENCY: Comparative literary analysis across texts with socio-cultural context.
STEPS:
- Step 1: Identify the core metaphor in each poem (weaving vs. pottery).
- Step 2: Note the poet's caste/occupation (Kabir as weaver, Ravidas as leather-worker/potter) and how the metaphor authenticates their voice.
- Step 3: Compare the imagery: weaving emphasizes interlacing threads (complexity, pattern, time), pottery emphasizes molding clay (plasticity, fire, form).
- Step 4: Compare the theological implication: weaving suggests karma as threads we create; pottery suggests the soul as clay shaped by God.
- Step 5: Conclude with how each metaphor serves the poet's critique of caste and ritual.
ANSWER: Kabir's weaving metaphor reflects his Julaha (weaver) identity, using terms like shuttle, loom, and thread to speak to fellow artisans and common people. The potter metaphor (in Ravidas or Kabir's other poems) uses clay, wheel, kiln to emphasize malleability and the transformative fire of devotion. Weaving highlights the devotee's active role in creating their destiny thread by thread; pottery highlights surrender to the Divine Potter. Both metaphors democratize spirituality by rooting it in low-caste labor, but weaving stresses process and pattern, while pottery stresses transformation through fire.
DIFFICULTY: hard