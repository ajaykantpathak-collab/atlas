## DEFINITION
Language Usage in the Text refers to the systematic analysis of grammatical structures, dialectal variations, sentence patterns, verb forms, honorific systems, and stylistic devices employed by the author (Jainendra Kumar) in "Laoofnak" to create authentic rural voices, convey social hierarchy, and advance thematic concerns through linguistic choices.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student must be able to: (1) Identify and classify at least 5 distinct grammatical/dialectal features in the story with textual evidence, and (2) Explain how each feature contributes to characterization, social realism, or thematic development in a structured analytical paragraph using the PEEL method.

## SCOPE_BOUNDARY
This node covers grammatical analysis of the story "Laoofnak" — including dialect vocabulary (Avadhi/Braj), sentence types in dialogue vs narration, honorific usage, verb tense/aspect patterns, and idiomatic constructions. It does NOT cover comprehensive Hindi grammar rules, sandhi/samas analysis, or poetic devices (covered in poetry nodes).

## WALKTHROUGH
Imagine you're listening to your grandmother tell a village story — you notice she uses words like "eka" for "ek" and "hum" for "main," and her sentences have a different rhythm than your textbook Hindi. That's exactly what Jainendra Kumar does in "Laoofnak": he captures the authentic voice of rural Uttar Pradesh through deliberate grammatical choices. Begin by reading the story aloud, marking every word that sounds "non-standard" or "dialectal" — these are your data points. Next, categorize them: are they vocabulary substitutions (dkcqyh for doctor), verb forms (dyius for dete hain), honorifics (HkkbZ for bhai), or sentence structures? Then ask: why THIS form HERE? How does the beggar woman's speech differ from Gyaneshwar's? The key insight: language usage isn't decoration — it's the primary tool for establishing the story's central conflict between urban modernity and rural tradition.

## DIAGNOSTIC_QUESTION_1
Identify three dialectal vocabulary items from the story "Laoofnak" and give their standard Hindi equivalents.

## DIAGNOSTIC_ANSWER_1
Correct answer: (1) dkcqyh&dk;nk → doctor (compounder), (2) ekjI+kQr → ekant (solitude/privacy), (3) ijsok → ishq (love/passion) or dard (pain). A wrong answer like "dkcqyh = dakhu" reveals the student is guessing from sound similarity rather than contextual inference — they haven't learned to use surrounding sentences (like "fuekSfN;s" suggesting medical context) to deduce meaning.

## DIAGNOSTIC_QUESTION_2
Explain in your own words why the author uses the compound verb construction "jkse&jkse dyius yxk" instead of the simple verb "dyius" or "dyk yxk" in the opening paragraph.

## DIAGNOSTIC_ANSWER_2
Correct answer: The reduplicated adverb "jkse&jkse" (slowly-slowly/gradually) combined with the compound verb "dyius yxk" (started giving/setting in) conveys the gradual, almost imperceptible onset of emotional numbness in the beggar woman — mirroring how grief settles layer by layer. A wrong answer like "it's just village style" misses the semantic precision: compound verbs (aspectual verbs) in Hindi encode inception, completion, or continuity; here "yxk" (from yA) marks inceptive aspect, which a simple verb cannot do.

## DIAGNOSTIC_QUESTION_3
In the dialogue "cM+h gosyh vc ukeek=k dks gh cM+h gosyh gSA" — identify the sentence type, the grammatical function of "vc" and "gh", and rewrite the sentence in standard modern Hindi while preserving the exact pragmatic force.

## DIAGNOSTIC_ANSWER_3
Correct answer: Sentence type = declarative/assertive with emphatic focus. "vc" = temporal adverb (now/at present), "gh" = emphatic particle (exclusively/just). Standard rewrite: "Ab badi gosai sirf badi gosai hai." A wrong answer that writes "Badi gosai ab badi gosai hai" loses the restrictive focus of "gh" — the student hasn't grasped that Hindi particles like "gh/hi" scope over the preceding constituent, not the whole sentence.

## DIAGNOSTIC_QUESTION_4
Compare the honorific system in Gyaneshwar's speech ("HkkbZ", "Hkxoku", "ek;th") with the beggar woman's speech ("cM+h cgqfj;k", "nq^h", "csVh"). What does this contrast reveal about their social positioning and the story's power dynamics?

## DIAGNOSTIC_ANSWER_4
Correct answer: Gyaneshwar uses kinship honorifics (HkkbZ = brother, Hkxoku = father, ek;th = mother) reflecting urban, relational respect; the beggar woman uses status-based terms (cM+h cgqfj;k = senior widow, nq^h = daughter-in-law, csVh = chhoti) reflecting rural hierarchy where age/gender/role determine address. The asymmetry — he calls her "mother" but she never reciprocates with "beta" — reveals his dependence on her charity despite his education. A wrong answer listing terms without analyzing reciprocity misses the power dynamic: language usage here encodes economic dependency masked as respect.

## DIAGNOSTIC_QUESTION_5
Evaluate the author's choice to render the beggar woman's internal monologue ("fdlosQ fy, bruk nq[k >syw¡\...") in the same dialectal register as her spoken dialogue. Does this enhance or undermine psychological realism? Justify.

## DIAGNOSTIC_ANSWER_5
Correct answer: It enhances psychological realism because in rural oral cultures, thought and speech share the same linguistic register — there's no "standard Hindi" inner voice. The dialect markers (vxguh ekku, fgdj, [kwu lw[k tkuk) in her thoughts prove she doesn't code-switch; her identity is linguistically unitary. A wrong answer claiming "it confuses readers" imposes a literate, diglossic urban norm on a character who exists outside that norm — revealing the student's own linguistic bias.

## DIAGNOSTIC_QUESTION_6
Write a 4-sentence paragraph in the beggar woman's voice describing her reaction to seeing a smartphone for the first time, using at least three dialectal features from the story (vocabulary, verb form, particle, or idiom).

## DIAGNOSTIC_ANSWER_6
Expected criteria: (1) Uses dialect vocabulary (e.g., "dkcqyh" for device, "vxguh" for strange), (2) Employs compound verb or aspectual form (e.g., "ns[k yxk" for started seeing), (3) Includes emphatic particle "gh/hi" or "bhI", (4) Maintains consistent rural register without code-switching. A poor answer using "mobile phone," "dekha," and standard grammar shows the student treats dialect as vocabulary substitution only, not as a coherent grammatical system.

## COMMON_MISCONCEPTION
Students treat "dialect" as merely a list of vocabulary substitutions (dkcqyh = doctor) and ignore the systematic grammatical differences: (1) Verb morphology — rural Avadhi uses "yxk" (inceptive) vs standard "shuru kiya", "dyius" (give) vs "dena"; (2) Pronominal system — "eka" for "ek", "hum" for "main" even in singular; (3) Postpositional variations — "osQ" for "ke", "esa" for "mein"; (4) Particle stacking — "vc gh" (now only) where standard uses "ab hi". They miss that Jainendra Kumar constructs a *grammar*, not a glossary.

## ON_FAILURE
Step 1: Have the student isolate 10 sentences from the beggar woman's dialogue and 10 from Gyaneshwar's. Step 2: Create a two-column table: Column A = her sentence, Column B = standard Hindi translation. Step 3: For each pair, identify EXACTLY what changed: verb ending? postposition? pronoun? particle? word order? Step 4: Generalize 3-4 grammatical rules from the patterns (e.g., "She consistently uses -us infinitive where standard uses -na"). Step 5: Re-read the story applying these rules — the "foreignness" will resolve into a coherent system.

## BUILDS_ON
Class 11 Grammar nodes where students learned basic sentence types, verb aspects, and honorific systems — now applied to literary dialect analysis.

## LEADS_TO
c12_hin_a_cbse_12_012 (Comprehension) where grammatical insights feed into inferential reading, and c12_hin_a_cbse_12_013 (Critical Thinking) where language usage becomes evidence for thematic interpretation.

## PREREQUISITE_NODE_IDS
c11_hin_ar_cbse_01_011, c11_hin_ar_cbse_02_011, c11_hin_ar_cbse_03_011, c11_hin_ar_cbse_04_011, c11_hin_ar_cbse_05_011, c11_hin_ar_cbse_06_011, c11_hin_ar_cbse_07_011, c11_hin_ar_cbse_08_011, c11_hin_ar_cbse_09_011, c11_hin_ar_cbse_10_011, c11_hin_ar_cbse_11_011, c11_hin_ar_cbse_12_011, c11_hin_ar_cbse_13_011, c11_hin_ar_cbse_14_011, c11_hin_ar_cbse_15_011, c11_hin_ar_cbse_16_011, c11_hin_v_cbse_01_011, c11_hin_v_cbse_02_011, c11_hin_v_cbse_03_011, c11_hin_v_cbse_04_011, c11_hin_v_cbse_05_011, c12_hin_a_cbse_12_001, c12_hin_a_cbse_12_010

## PREREQUISITE_REASONS
c11_hin_ar_cbse_01_011: Foundation in identifying sentence types (simple/compound/complex) in literary texts
c11_hin_ar_cbse_02_011: Practice with verb aspect (perfective/imperfective/habitual) in narrative contexts
c11_hin_ar_cbse_03_011: Exposure to honorific systems (tum/aap/tu) and their social indexing
c11_hin_ar_cbse_04_011: Analysis of dialect markers in Class 11 prose selections
c11_hin_ar_cbse_05_011: Worked examples of compound verb constructions (aspectual verbs)
c11_hin_ar_cbse_06_011: Training in distinguishing narrator's language from character's speech
c11_hin_ar_cbse_07_011: Introduction to stylistic analysis — how grammar creates tone
c11_hin_ar_cbse_08_011: Practice with PEEL paragraph structure for language analysis
c11_hin_ar_cbse_09_011: Vocabulary inference strategies using context clues
c11_hin_ar_cbse_10_011: Study of idiomatic expressions and their non-compositional meanings
c11_hin_ar_cbse_11_011: Comparison of urban vs rural registers in Class 11 texts
c11_hin_ar_cbse_12_011: Analysis of dialogue punctuation and reporting verbs
c11_hin_ar_cbse_13_011: Understanding of free indirect discourse in Hindi prose
c11_hin_ar_cbse_14_011: Grammatical gender/number agreement patterns in non-standard varieties
c11_hin_ar_cbse_15_011: Tense/aspect/mood system of modern standard Hindi vs dialects
c11_hin_ar_cbse_16_011: Board-style short answer writing for grammar questions
c11_hin_v_cbse_01_011: Exposure to Vyakaran (grammar) textbook rules for reference
c11_hin_v_cbse_02_011: Practice with sandhi/samas identification in literary texts
c11_hin_v_cbse_03_011: Study of verb valency and case marking in Hindi
c11_hin_v_cbse_04_011: Analysis of emphatic particles (hi, bhi, to) in discourse
c11_hin_v_cbse_05_011: Worked examples of rhetorical devices in prose
c12_hin_a_cbse_12_001: Grammar/usage points (dialect vs standard) are previewed in context.  
c12_hin_a_cbse_12_010: Vocabulary mastery enables analysis of compound formation (dkcqyh&dk;nk) and idiomatic syntax ([kkst [kcj).  

## FORWARD_NODE_IDS
c12_hin_a_cbse_12_012, c12_hin_a_cbse_12_013, c12_hin_a_cbse_12_014, c12_hin_a_cbse_12_015

## FORWARD_REASONS
c12_hin_a_cbse_12_012: Grammatical analysis provides evidence for inferential comprehension answers
c12_hin_a_cbse_12_013: Language usage patterns become primary data for thematic interpretation
c12_hin_a_cbse_12_014: Dialect awareness informs authentic dialogue writing in creative tasks
c12_hin_a_cbse_12_015: Gives grammatical features (dialect, oral syntax) to discuss storytelling voice  

## CROSS_SUBJECT_PREREQS
c12_hin_ar_cbse_12_011

## CROSS_SUBJECT_REASONS
c12_hin_ar_cbse_12_011: Same chapter's literary devices node — imagery/metaphor often realized through grammatical choices (e.g., compound verbs as metaphor for gradual change)
c12_hin_v_cbse_12_011: Vyakaran textbook rules provide the standard baseline against which dialect deviations are measured

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_05_011 -> c12_hin_a_cbse_12_011 -> c12_hin_a_cbse_12_013

## THIS_FORMULA
PEEL Analysis Framework for Language Usage: Point (identify feature) → Evidence (quote with line/context) → Explain (grammatical analysis: form, function, dialect rule) → Link (connect to characterization/theme/power dynamic)

## FORMULA_VARIABLES
Point = Specific grammatical feature (e.g., "inceptive compound verb yxk"); Evidence = Exact textual segment with location; Explain = Morphological/syntactic breakdown + dialect rule; Link = Thematic/character significance

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
linguistic

## CROSS_SUBJECT
N/A | The beggar woman's dialect reflects Avadhi-speaking rural Uttar Pradesh's kinship terminology and honorific system — directly illustrating sociology concepts of "folk culture" vs "urban culture" and linguistic markers of social stratification
 N/A | The story's linguistic landscape maps onto the Gangetic plain's dialect continuum — "dkcqyh" (from English "doctor" via rural phonology) shows how geographical isolation shapes lexical borrowing
## PREREQ_CONCEPT
Compound verb aspectual system (inceptive yA, completive le/dia, continuative rahA) and emphatic particle scope (hi/gh/bhi) — the two grammatical engines driving dialect characterization in the story.

## PREREQ_BEFORE
Student must confidently distinguish: (1) simple verb vs compound verb, (2) standard Hindi postpositions (ke, mein, se) vs Avadhi variants (osQ, esa, ls), (3) honorific pronouns (aap/tum/tu) vs kinship honorifics (bhai/maa/babuji).

## PREREQ_STUCK
If stuck on compound verbs: revisit Class 11 node c11_hin_ar_cbse_05_011 (aspectual verbs) and practice identifying yA/le/rahA in 5 story sentences. If stuck on particles: revisit c11_hin_v_cbse_04_011 (emphatic particles) and mark every hi/gh/bhi in the beggar woman's speech.

## WORKED_EXAMPLE_1
PROBLEM: Analyze the grammatical structure and dialectal significance of the sentence: "gjxksfcu us ns[kh viuh vk¡[kksa ls nzkSinh dh phjgj.k yhykA" (Gyaneshwar saw with his eyes the beggar woman's trembling like a leaf).

STEPS:
- Step 1: Identify the core clause structure — Subject (gjxksfcu us, ergative) + Verb (ns[kh, perfective transitive) + Object (yhyk, trembling) + Instrument (viuh vk¡[kksa ls, with his eyes) + Comparator (nzkSinh dh phjgj.k, like a leaf's trembling).
- Step 2: Flag dialectal features — "us" (ergative marker) is standard; "viuh" (reflexive possessive) is standard; "nzkSinh" (nazar+inh? or dialect for nazar?) — actually "nzkSinh" = nazar (sight) + inh (possessive?); "phjgj.k" = pharpharana (tremble) nominalized with -j.k suffix — this -j.k nominalizer is Avadhi (standard uses -na or -hat).
- Step 3: Analyze the comparator construction — "X dh Y" (X's Y) for "like X" is a dialectal calque; standard Hindi uses "X jaisa" or "X ki tarah". The possessive "dh" (standard "ki") marks genitive.
- Step 4: Interpret semantic effect — The nominalized verb "phjgj.k" (trembling-as-noun) objectifies the woman's fear, making it a visible thing Gyaneshwar "sees." The eye-instrument "vk¡[kksa ls" emphasizes his privileged visual access vs her bodily vulnerability.
- Step 5: Connect to theme — This grammatical framing enacts the story's central gaze dynamic: the educated male subject objectifies the rural female body through a linguistic structure that nominalizes her emotion and claims visual mastery.

REASONING: The PEEL framework forces separation of grammatical description (Steps 1-3) from literary interpretation (Steps 4-5). Dialect features aren't decorative — the -j.k nominalizer and "dh" comparator are systematic Avadhi grammar that the author deploys to construct a specific power relation.

ANSWER: The sentence uses standard ergative alignment (us) but Avadhi nominalization (-j.k) and genitive comparator (dh). This creates a grammatical hybridity mirroring Gyaneshwar's position: urban-educated syntax observing rural reality through a lens that objectifies it.

## WORKED_EXAMPLE_2
PROBLEM: The beggar woman says: "cFkqvk lkx [kkdj dc rd thm¡Q\" — Identify the verb forms, explain the aspectual meaning, and contrast with standard Hindi equivalent.

STEPS:
- Step 1: Segment the verb complex — "cFkqvk" (compound: cFk + qvk? Actually cFkqvk = cFk + qvk? No — "cFkqvk" = cFk (chhup) + qvk (from qA?); wait — "cFkqvk" = chhup-ke? Let's re-read: "cFkqvk lkx [kkdj dc rd thm¡Q". Parse: cFkqvk = cFk (chhup) + qvk (karke?); "lkx" = lag (lag); "[kkdj" = kha kar (eat having); "dc rd" = kab tak; "thm¡Q" = thaharoge (will stay/pause).
- Step 2: Identify each verb form — "cFkqvk" = conjunctive participle (chhupkar); "lkx" = main verb? No — "lkx" = lag (start) — but form is bare root? Actually "lkx" = lage (subjunctive?); "[kkdj" = conjunctive participle (khakar); "thm¡Q" = future habitual (thahroge).
- Step 3: Map to standard Hindi — "cFkqvk" → chhupkar (standard conjunctive); "lkx" → lage (subjunctive of lagna); "[kkdj" → khakar (standard); "thm¡Q" → thaharoge (future).
- Step 4: Analyze aspectual chain — "chhupkar lage khakar" = "having hidden, started eating" — the compound "lagna + conjunctive" encodes inceptive aspect (beginning of action). Standard would be "chhupkar khana shuru kiya" or "chhupkar khane lage".
- Step 5: Evaluate dialect specificity — The bare root "lkx" for subjunctive "lage" is Avadhi (standard requires -e ending). The future "thm¡Q" (thahroge) shows -oge ending (standard) but stem "tham" (standard "thahar") — phonological reduction.
- Step 6: Thematic link — The inceptive "lagna" chain mirrors her fragmented survival actions: hide → start eating → how long will (you) stay? Each verb marks a new desperate beginning.

REASONING: This example shows how aspectual verb chains (conjunctive + aspectual) in dialect compress what standard Hindi expresses with periphrasis. The student must track each verb's morphological form, not just meaning.

ANSWER: Dialect forms: cFkqvk (chhupkar), lkx (lage - bare subjunctive), [kkdj (khakar), thm¡Q (thahroge). Aspectual chain: conjunctive + inceptive lagna + conjunctive + future habitual. Standard equivalent: "chhupkar khane lage kab tak thahroge?" The bare subjunctive "lkx" and phonological reduction "tham" mark rural register.

## WORKED_EXAMPLE_3
PROBLEM: Compare the honorific address terms in two exchanges: (A) Gyaneshwar: "jke&jke HkkbZ! dgks, oqQ'ky lekpkj Bhd gS u\" (B) Beggar woman: "jke&jke] HkS;kth! Hkxoku dh n;k ls vkuanh gSA" — Analyze the grammatical form, social indexing, and power implication of each.

STEPS:
- Step 1: Extract address terms — Exchange A: "jke&jke" (reduplicated vocative), "HkkbZ" (brother). Exchange B: "jke&jke" (same), "HkS;kth" (father/respected male).
- Step 2: Analyze grammatical form — "jke&jke" = reduplicated proper noun vocative (affectionate/urgent); "HkkbZ" = kinship noun (brother) used as honorific; "HkS;kth" = honorific noun (father) with -th suffix (respect).
- Step 3: Determine social indexing — Gyaneshwar (urban, educated) uses "bhai" = lateral solidarity, fictive kinship across class. Beggar woman (rural, elderly) uses "pita/thakur" = vertical deference, acknowledging his gender/age authority despite her moral superiority.
- Step 4: Note reciprocity failure — He calls her "maa" (mother) elsewhere; she never calls him "beta" (son). The honorific flow is unidirectional: she grants him "thakur"; he offers "bhai" but claims "maa" for her.
- Step 5: Connect to economic power — She controls food/shelter (material power); he controls language/narrative (symbolic power). The honorific asymmetry encodes this: her "thakur" legitimizes his presence; his "bhai" masks his dependency.
- Step 6: Broader pattern — Track all address terms: she uses "nq^h" (bahu), "csVh" (chhoti), "ek;th" (maa) — all kinship/role-based. He uses "HkkbZ", "Hkxoku", "ek;th" — same set but deployed differently. The shared lexicon with divergent pragmatics IS the conflict.

REASONING: Honorifics aren't just polite words — they're grammaticalized social contracts. The analysis must move from form (morphology) → function (pragmatics) → ideology (power). This multi-step climb is what board examiners reward.

ANSWER: Both use "jke&jke" (reduplicated vocative) but diverge: Gyaneshwar's "HkkbZ" (bhai) claims fictive equality; beggar woman's "HkS;kth" (thakur/pita) asserts hierarchical deference. Non-reciprocity — she grants respect he doesn't return — encodes her material power (food/shelter) vs his symbolic power (naming/authority). The shared kinship lexicon with opposed pragmatics stages the story's central tension.

## COMPETENCY_QUESTION_1
QUESTION: In the passage "laofn;k MVdj [kkrk gS vkSj ^viQj* dj lksrk gS] ¯drq gjxksfcu dks uhan ugha vk jgh gSA" — the narrator explains the idiom "viQjuk" (viQj = biscuit? viQjuk = to eat biscuit?). Using contextual evidence from the story, deduce the actual meaning of "viQjuk" and explain why the narrator feels the need to gloss it for the reader. What does this glossing reveal about the implied reader of the text?

COMPETENCY: Linguistic inference + narrative theory (implied reader)
STEPS:
- Step 1: Locate the immediate context — the beggar woman has just been fed by Gyaneshwar; she eats "laofn;k" (begging food) and does "viQjuk".
- Step 2: Analyze morphological structure — "viQj" (noun) + "uk" (verbalizer suffix, Avadhi) = "to do viQj". Standard Hindi would use "khana" for eat; "viQj" is not standard for food.
- Step 3: Cross-reference with earlier usage — "viQjuk" appears in vocabulary list: "viQjuk — isV Hkjdj [kkuk" (to eat by breaking pieces). "isV" = piece/morsel.
- Step 4: Synthesize meaning — "viQjuk" = to eat by breaking into small pieces/morsels, characteristic of someone eating hungrily or with reverence for food.
- Step 5: Explain narrator's gloss — The narrator intervenes ("¯drq" = that is why) because "viQjuk" is opaque to urban/Hindi-belt readers. The gloss "laofn;k MVdj [kkrk gS vkSj viQj dj lksrk gS" defines it behaviorally.
- Step 6: Implied reader — The gloss assumes a reader fluent in standard Hindi but unfamiliar with rural Avadhi foodways — an urban, educated reader (like Gyaneshwar, like us). The text performs translation for its own audience.

ANSWER: "viQjuk" = to eat by breaking food into small pieces (isV Hkjdj [kkuk), reflecting the beggar woman's hungry/reverent eating style. The narrator glosses it because the implied reader is urban, standard-Hindi-speaking, and culturally distant from the character's embodied food practices — the text mediates between two linguistic worlds.

DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: The story ends with Gyaneshwar singing: "^uSgjk dks lq[k liu Hk;ks vc] ns'k fi;k dks Mksfy;k pyh&bZ&bZ&bZ] HkkbZ jksvks efr] ;gh dje dh xfr--- !!". Analyze how the grammatical shift from the story's dominant past tense narration to this present/future-oriented song lyric, combined with the shift from dialect to Sanskritized Hindi (lq[k, liu, Mksfy;k, efr, xfr), functions as a thematic resolution. Support with three specific grammatical contrasts.

COMPETENCY: Grammatical analysis + thematic synthesis (multi-concept)
STEPS:
- Step 1: Identify the tense/aspect shift — Story narration: predominantly past perfective (gqvk, x;k, dj, ns[kh, cksyk). Song: present imperative (Hk;ks), future (pyh), vocative (jksvks), nominalized abstract nouns (liu, xfr).
- Step 2: Identify the register shift — Story dialogue: Avadhi dialect (dkcqyh, ekjI+kQr, ijsok, lwik, jS;r, fgdj, viQjuk, pwM+k, cgqfj;k, n[ky). Song: tatsama Sanskritized (lq[k, liu, Mksfy;k, efr, xfr, dje).
- Step 3: Identify the syntactic shift — Story: paratactic, dialogue-heavy, elliptical. Song: highly structured, metaphorical, parallelistic (pyh&bZ&bZ&bZ reduplication).
- Step 4: Contrast 1 (Tense) — Past tense narrates what *happened* (fixed, irreversible); song's imperative/future projects what *should be* (aspirational, open). Gyaneshwar escapes the beggar woman's tragic stasis through linguistic futurity.
- Step 5: Contrast 2 (Register) — Dialect grounds the story in specific rural suffering; Sanskritized Hindi universalizes it into nationalist allegory ("ns'k" = nation, "dje" = yajna/sacrifice). The beggar woman becomes "Mother India."
- Step 6: Contrast 3 (Syntax) — Dialogue's fragmented, responsive syntax (question-answer, interruption) reflects power negotiation; song's monologic, rhythmic structure reflects authoritarian vision — Gyaneshwar now speaks *for* her, not *with* her.
- Step 7: Synthesis — The grammatical transformation enacts the story's ideological closure: rural particularity (dialect, past, dialogue) is sublated into national myth (Sanskritized, future, monologue). Whether this is resolution or appropriation is the critical question.

ANSWER: Three grammatical contrasts: (1) Past perfective narration vs imperative/future song — fixes history vs opens futurity. (2) Avadhi dialect vs tatsama Sanskritized register — particular suffering vs national allegory. (3) Dialogic/paratactic syntax vs monologic/parallelistic syntax — negotiated power vs authoritarian vision. The shift resolves the story by linguistically absorbing the beggar woman into a nationalist symbol, silencing her dialect voice.

DIFFICULTY: hard