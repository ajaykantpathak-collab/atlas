## DEFINITION
Character analysis of the protagonist involves examining the narrator's personality, motivations, development, relationships, and role in conveying the story's themes through her actions, speech, thoughts, and the author's narrative choices. In "वकील की बेटी," the protagonist is the unnamed first-person narrator—a domestic worker who becomes a writer—whose consciousness shapes the entire narrative.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
Student can write a structured character analysis of the protagonist using textual evidence (actions, dialogue, internal monologue, relationships) organized through the PEEL method, connecting her traits to the story's central themes of dignity, resilience, and social inequality.

## SCOPE_BOUNDARY
This node covers analysis of the narrator-protagonist only (the domestic worker woman), not supporting characters like the lawyer's daughter (lquhy), the husband (rkrq'k), or other employers. It focuses on character portrayal techniques: direct/indirect characterization, character arc, and thematic function.

## WALKTHROUGH
Think of someone you know who works in others' homes—what do you notice about how they're treated versus who they really are? Now open the story's first pages: the narrator describes her daily routine while neighbors interrogate her. Notice how the author gives us her *internal* thoughts ("eq>s oqQN ysuk&nsuk ugha Fkk") contrasting with her external silence. That gap—between what she thinks and what she's allowed to say—is where her character lives. Mark every "eSa" statement in the first five pages. You'll find she judges others more than they judge her. Key insight: The protagonist's strength lies not in dramatic rebellion but in quiet persistence and maintaining self-worth despite systems designed to erase it.

## DIAGNOSTIC_QUESTION_1
What is the name of the protagonist in "वकील की बेटी" and what is her primary occupation at the start of the story?

## DIAGNOSTIC_ANSWER_1
The protagonist is the unnamed narrator (a woman), and her primary occupation is domestic work in multiple households. A wrong answer (e.g., naming the lawyer's daughter as protagonist) reveals confusion between title character and narrative perspective—the chapter title names a supporting character, not the protagonist.

## DIAGNOSTIC_QUESTION_2
How does the author use the protagonist's internal monologue to establish her dignity despite her socioeconomic status? Give one specific example from the text.

## DIAGNOSTIC_ANSWER_2
The protagonist's internal monologue reveals self-respect through thoughts like refusing to feel ashamed of her work ("eq>s oqQN ysuk&nsuk ugha Fkk") and valuing her children's education over others' opinions. A wrong answer focusing only on external actions misses the author's technique of using first-person narration to contrast inner worth with outer circumstances—the dignity exists *because* we hear her unspoken judgments.

## DIAGNOSTIC_QUESTION_3
Using the PEEL structure, write a paragraph analyzing how the protagonist's interaction with the lawyer's daughter (lquhy) reveals her desire for self-improvement.

## DIAGNOSTIC_ANSWER_3
Point: The protagonist shows quiet ambition through her response to lquhy's encouragement. Evidence: When lquhy offers to teach her, she thinks "eSa lksprh fd lpeqp gh og eq>s cgqr pkgrs gSa" and later accepts writing materials. Explanation: Her internal acceptance contrasts with external hesitation, showing dignity-driven motivation rather than desperate gratitude. Link: This interaction catalyzes her transformation from passive worker to active learner. Wrong answers typically list events without analyzing the psychological subtext revealed through narrative access to her thoughts.

## DIAGNOSTIC_QUESTION_4
Compare the protagonist's relationship with her husband (rkrq'k) and with the lawyer's daughter (lquhy). How do these two relationships differently shape her character development?

## DIAGNOSTIC_ANSWER_4
With rkrq'k: mutual intellectual partnership, shared literary aspirations, emotional anchor ("rkrq'k osQ ;gk¡ tc igq¡prh vkSj og crkrs fd muosQ fdlh caèkq us muls fiQj esjs i<+kbZ&fy[kkbZ osQ ckjs esa iwNk gS rks [kq'kh esa eSa og lc Hkwy tkrh"). With lquhy: catalytic mentorship, initial kindness enabling literacy, but later class distance emerges. The husband relationship sustains long-term growth; the employer relationship initiates it but cannot transcend class barriers. Wrong answers treat both as simply "supportive" without analyzing power dynamics—rkrq'k is a partner; lquhy is a benefactor whose support has limits.

## DIAGNOSTIC_QUESTION_5
Critique the author's choice to keep the protagonist unnamed throughout the story. Does this strengthen or weaken her characterization as a representative of marginalized women?

## DIAGNOSTIC_ANSWER_5
Strengthens: The anonymity universalizes her experience—she represents countless invisible domestic workers. Her identity emerges through actions and voice, not a name. The moment she gains literary recognition ("vk'kkiw.kkZ nsoh"), she's still introduced through her writing, not a personal name. This mirrors how society sees the work before the person. Weakens: Some may argue it denies individual agency. A strong evaluation acknowledges both but concludes the artistic choice serves the thematic purpose of collective representation. Wrong answers pick one side without textual support for the counter-perspective.

## DIAGNOSTIC_QUESTION_6
Write a diary entry from the protagonist's perspective on the day she receives her first payment for writing, capturing her voice, vocabulary level, and emotional complexity.

## DIAGNOSTIC_ANSWER_6
A strong entry uses simple but dignified Hindi, references specific textual details (husband's reaction, children's pride, the physical sensation of holding money earned from words), and shows conflicting emotions: joy at validation, grief for mother who didn't live to see it, fear of whether she can sustain it. Poor entries use sophisticated vocabulary inconsistent with her character or miss the bittersweet layer beneath the triumph—the money matters because it buys her children's future, not because it proves her worth.

## COMMON_MISCONCEPTION
Students often confuse the protagonist (the narrator/domestic worker) with the title character "वकील की बेटी" (the lawyer's daughter, lquhy) because the chapter title names the latter. They then analyze lquhy's character instead of the narrator's. This happens because titles typically name protagonists, and students don't distinguish between "title character" and "narrative perspective character." The narrator is the protagonist; lquhy is a catalyst character who appears intermittently. The protagonist's consciousness spans the entire text; lquhy appears in only two major episodes.

## ON_FAILURE
1. Have student re-read the first 3 pages identifying every "eSa" (I) statement—this establishes the narrative voice.
2. Create a two-column chart: "Title Character (वकील की बेटी)" vs "Narrator/Protagonist" with textual evidence for each.
3. Ask: "Whose thoughts do we hear? Whose life spans the whole story? Who changes?"—all answers point to the narrator.
4. Practice writing one PEEL paragraph about the narrator using only "eSa" statements as evidence.

## BUILDS_ON
c11_hin_v_cbse_03_002 (Plot and Narrative Structure) - understanding first-person narrative perspective is essential before analyzing the narrator as character.

## LEADS_TO
c11_hin_v_cbse_03_005 (Character Analysis: Supporting Characters) - after mastering protagonist analysis, students apply similar techniques to lquhy, rkrq'k, and other figures.

## PREREQUISITE_NODE_IDS
c11_hin_v_cbse_03_001, c11_hin_v_cbse_03_002, c11_hin_v_cbse_03_003
## PREREQUISITE_REASONS
c11_hin_v_cbse_03_001: Context and Background provides the socio-historical setting (domestic work, gender, caste) necessary to understand the protagonist's constraints.
c11_hin_v_cbse_03_002: Plot and Narrative Structure establishes the first-person narrative framework—the protagonist IS the narrative voice.
c11_hin_v_cbse_03_003: Setting and Atmosphere explains the physical environments (employers' homes, her own home) that shape the protagonist's daily reality and psychological space.

## FORWARD_NODE_IDS
c11_hin_v_cbse_03_005, c11_hin_v_cbse_03_006, c11_hin_v_cbse_03_013, c11_hin_v_cbse_03_007, c11_hin_v_cbse_03_008, c11_hin_v_cbse_03_009, c11_hin_v_cbse_03_010, c11_hin_v_cbse_03_011, c11_hin_v_cbse_03_012, c11_hin_v_cbse_03_015, c12_hin_v_cbse_03_004

## FORWARD_REASONS
c11_hin_v_cbse_03_005: Supporting character analysis uses the same PEEL/evidence method mastered here, applied to lquhy, rkrq'k, etc.
c11_hin_v_cbse_03_006: Primary theme (dignity/resilience) is embodied in the protagonist; theme analysis requires tracing her character arc.
c11_hin_v_cbse_03_013: Critical thinking questions demand character-based interpretation—e.g., "How does the protagonist's voice challenge dominant narratives?"
c11_hin_v_cbse_03_007: Protagonist's evolving consciousness (from silence to speech) is the vehicle for all secondary themes.  
c11_hin_v_cbse_03_008: Protagonist analysis provides the *perceiving consciousness* — imagery is filtered through her sensory memory; metaphor reflects her internal framing of exploitation.  
c11_hin_v_cbse_03_009: अगला तार्किक चरण: Irony is a literary device where the intended meaning of words or situations differs significantly f... इस नोड की अवधारणाओं को सीधे उपयोग/विस्तारित करता है।  
c11_hin_v_cbse_03_010: Protagonist analysis reveals how the narrator's voice shapes word connotations (her internal vs. external vocabulary).  
c11_hin_v_cbse_03_011: Protagonist analysis establishes the narrator's social position, which grammatical choices (honorifics, dialect) index and negotiate.  
c11_hin_v_cbse_03_012: Protagonist analysis supplies the personality traits needed to justify inferences about her choices.  
c11_hin_v_cbse_03_015: नायिका के चरित्र विश्लेषण (उसकी मानसिकता, संघर्ष, विकास) के बिना चर्चा सतही रहेगी।  
c12_hin_v_cbse_03_004: Class 11 Vitan protagonist analysis — transfers human-character techniques to non-human protagonist.  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
none

## CHAIN_DESCRIPTION
c11_hin_v_cbse_03_002 -> c11_hin_v_cbse_03_004 -> c11_hin_v_cbse_03_005

## THIS_FORMULA
PEEL Method for Character Analysis: Point (trait/claim) → Evidence (textual detail: action/speech/thought) → Explanation (how evidence proves point) → Link (connect to theme/arc/author's purpose)

## FORMULA_VARIABLES
Point: Specific character trait or developmental claim (e.g., "The protagonist demonstrates quiet resilience")
Evidence: Concrete textual reference (paraphrased incident, quoted dialogue, described internal monologue)
Explanation: Analysis connecting evidence to point (why this action reveals this trait)
Link: Connection to broader theme, character arc, or authorial intention

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
analytical

## CROSS_SUBJECT
c11_sociology_social_stratification | The protagonist's experience as a domestic worker illustrates intersectional marginalization (gender, class, caste) central to sociological analysis of informal labor.
c11_psychology_identity_formation | Her journey from internalized inferiority to literary self-actualization maps onto Erikson's stages (industry vs inferiority, identity vs role confusion) and narrative identity theory.

## PREREQ_CONCEPT
First-person narrative perspective: The protagonist is the "I" who narrates, not a character observed from outside.

## PREREQ_BEFORE
Student must be able to distinguish between the narrator (protagonist) and other characters, and identify first-person narration.

## PREREQ_STUCK
If confused about who the protagonist is, review c11_hin_v_cbse_03_002 (Plot and Narrative Structure) focusing on narrative point of view.

## WORKED_EXAMPLE_1
PROBLEM: Analyze how the author establishes the protagonist's dignity in the opening section (pages 21-23) using the PEEL method.

STEPS:
- Step 1: Identify the claim - The protagonist maintains self-respect despite degrading circumstances.
- Step 2: Locate evidence - She thinks "eq>s oqQN ysuk&nsuk ugha Fkk" (I didn't want to ask or listen) when questioned intrusively; she refuses to explain herself to neighbors; she prioritizes her children's needs over social performance.
- Step 3: Apply PEEL - Point: Dignity through boundary-setting. Evidence: Internal refusal to perform gratitude or shame. Explanation: Her silence is not submission but protection of inner autonomy. Link: Establishes core trait that enables later transformation.
- Step 4: Verify against text - Check that this reading aligns with her later actions (refusing to stay where disrespected, demanding fair treatment).
- Step 5: Connect to theme - This quiet dignity becomes the foundation for her literary voice; the author shows resistance begins internally.

REASONING: The opening establishes baseline characterization before external catalysts (lquhy, rkrq'k) appear. Using PEEL forces students to move beyond "she is strong" to "the author shows strength through specific narrative choices."

ANSWER: The protagonist's dignity is established through narrative access to her internal resistance (refusing to perform gratitude/shame), contrasted with external compliance. The author uses first-person interiority to show that her submission is tactical, not psychological—a crucial distinction for a marginalized character.

## WORKED_EXAMPLE_2
PROBLEM: Trace the protagonist's character arc from passive endurance to active self-definition across three key turning points.

STEPS:
- Step 1: Identify turning point 1 (pages 24-26) - lquhy's encouragement and gift of writing materials. Protagonist moves from "vgk¡ dke djuk pkfg," to accepting literacy as possible for herself.
- Step 2: Identify turning point 2 (pages 36-38) - Husband rkrq'k's structured mentorship (giving diary, demanding daily writing). She shifts from learner to practitioner: "isu vkSj dkWih ys eSa ?kj xbZ vkSj mlh fnu ls nks&,d ist jks”k fy[kus yxh."
- Step 3: Identify turning point 3 (pages 48-50) - Public recognition as writer ("vk'kkiw.kkZ nsoh") and mother's death. She claims professional identity: "rqEgkjh dgkuh tkuus dh esjh cgqr bPNk gksrh gSA"
- Step 4: Analyze progression - Each turning point expands her agency: first someone believes in her, then someone structures her practice, finally she owns her achievement.
- Step 5: Note constants - Throughout, her motivation remains children's future and self-respect, not external validation.
- Step 6: Connect to structure - The three-part arc mirrors the three-act structure from c11_hin_v_cbse_03_002.

REASONING: Character arc analysis requires identifying structural turning points, not just listing events. The three turning points correspond to external catalyst, internalized discipline, and public recognition—a classic growth trajectory.

ANSWER: The protagonist evolves from a woman who "didn't want to ask or listen" (p.21) to one who commands literary respect (p.50). The arc moves: External validation (lquhy) → Internalized practice (rkrq'k's diary) → Professional identity (vk'kkiw.kkZ nsoh). Crucially, her core values (children, dignity) remain constant; only her means of expressing them expand.

## WORKED_EXAMPLE_3
PROBLEM: Compare the protagonist's characterization with a typical "victim narrative" of domestic workers. How does the author subvert expectations through specific narrative choices?

STEPS:
- Step 1: Define the typical victim narrative - passive suffering, rescue by benevolent employer, gratitude as primary emotion, no intellectual life shown.
- Step 2: Identify subversion 1 - Narrative authority: The protagonist is the narrator, not the observed. We see her judging others ("bu lc ckrksa ls eq>s oqQN ysuk&nsuk ugha Fkk").
- Step 3: Identify subversion 2 - Intellectual agency: Her desire for literacy comes from within ("eSa lksprh fd lpeqp gh og eq>s cgqr pkgrs gSa"), not just employer's offer.
- Step 4: Identify subversion 3 - Complex emotions: She feels "ek;k" (pain/sympathy) for employers' children but also "cqjk" (anger) at injustice—not simple gratitude.
- Step 5: Identify subversion 4 - Professional outcome: She becomes a writer on her own terms, not a "success story" of employer's charity. rkrq'k (husband) is co-architect, not lquhy.
- Step 6: Analyze author's technique - First-person narration + time span (years) + literary self-reflexivity (writing about writing) creates a subject, not an object.

REASONING: This analysis combines character study with narrative theory—a senior secondary skill. Students must recognize that characterization is constructed through narrative choices (POV, time, voice), not just character traits.

ANSWER: The author subverts the victim narrative by making the domestic worker the narrative subject (first-person narrator across decades), granting her intellectual agency (self-motivated literacy), complex emotional range (anger alongside empathy), and professional autonomy (writing career built with husband, not employer). The narrative form itself—a writer writing about becoming a writer—enacts the protagonist's journey from object to subject.

## COMPETENCY_QUESTION_1
QUESTION: The protagonist says: "eSa lksprh fd lpeqp gh og eq>s cgqr pkgrs gSa" (I felt that he loved me very much) about her husband rkrq'k, yet she also describes moments of conflict. Using two specific textual instances, analyze how the author portrays a marriage that is both supportive and fraught with gendered tensions.

COMPETENCY: Textual analysis with nuanced character relationship reading

STEPS:
- Step 1: Identify the supportive instance - rkrq'k giving diary, teaching writing, celebrating her success ("rkrq'k cksys] rqe ;fn jks”k fy[kksxh rks eSa rqEgsa vkSj Hkh I;kj d:¡xk")
- Step 2: Identify a tension instance - His frustration when she stops writing ("rkrq'k us fiQj dgk] ns[kks] rqe D;k dj jgh Fkha\ eSa cksyh] Åij MfLaVx dj jgh FkhA og cksys] rks tkvks viuk dke djksA")
- Step 3: Analyze the gendered dimension - He controls her writing schedule ("rqe viuk dke fd, tkvksA cl] fy[kks vkSj i<+ksA"), decides when she's ready for publication, frames her talent as his achievement ("rqEgkjs rkrq'k us lpeqp gh ,d ghjk [kkst fudkyk gS!")
- Step 4: Synthesize - The marriage enables her voice but also mediates it through male authority; the author refuses to idealize either character.

ANSWER: The author portrays a partnership that is genuinely loving (he teaches her, celebrates her, shares literary life) yet structured by patriarchal norms (he initiates, structures, claims partial ownership of her success). The protagonist's awareness ("eSa lpeqp gh oqQN ugha le>rh") shows her navigating this complexity without resentment—a nuanced portrayal avoiding both "supportive husband" cliché and "oppressive marriage" cliché.

DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: The protagonist's literacy journey transforms her from a worker who "didn't know how to ask" (p.21) to a published writer. Evaluate whether the text presents literacy as individual empowerment or as a socially mediated process. Support with three pieces of evidence showing how specific relationships enable or constrain her literary development.

COMPETENCY: Thematic synthesis through character analysis

STEPS:
- Step 1: Identify the individual empowerment reading - Her internal drive ("eSa rks i<+uk pkgrh gw¡"), her persistence ("fy[krs&fy[krs gh lc Bhd gks tk,xkA"), her professional pride.
- Step 2: Identify the socially mediated reading - lquhy's initial materials, rkrq'k's daily discipline and publishing connections, tsBw's editorial guidance, vk'kkiw.kkZ nsoh's mentorship.
- Step 3: Select evidence 1 (enabling) - lquhy's gift: "rkrq'k us eq>ls cSB tkus dks dgk vkSj fiQj fp_h i<+dj lqukus yxs] fiz; csch] eSa crk ugha ldrk rqEgkjh Mk;jh i<+dj eq>s fdruk vPNk yxk!" - shows literacy enters through relationship.
- Step 4: Select evidence 2 (constraining) - rkrq'k's control: "rqe viuk dke fd, tkvksA cl] fy[kks vkSj i<+ksA" - shows male gatekeeping of literary space.
- Step 5: Select evidence 3 (transformative community) - tsBw and vk'kkiw.kkZ nsoh's literary circle: "gesa dHkh oqQN vlkèkkj.k ns losaQA" - shows writing requires community.
- Step 6: Conclude - The text presents literacy as socially mediated individual agency: she provides the drive, others provide the infrastructure. Neither alone suffices.

ANSWER: Literacy in the text is neither purely individual nor purely social—it's a relational achievement. The protagonist supplies relentless internal motivation ("I wanted to learn"), but every material and institutional step requires others: lquhy's paper/pen, rkrq'k's diary/discipline/connections, tsBw's editorial eye, vk'kkiw.kkZ nsoh's publication access. The author honors her agency while acknowledging that a marginalized woman's literacy cannot be a solo act—it requires a network that is both enabling and constraining.

DIFFICULTY: hard