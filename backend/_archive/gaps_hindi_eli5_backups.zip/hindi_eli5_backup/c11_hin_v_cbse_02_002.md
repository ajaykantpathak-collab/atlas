## DEFINITION
Plot and Narrative Structure in non-fiction expository texts refers to the logical architecture through which the author organizes arguments, evidence, and thematic progression—comprising the sequencing of ideas (chronological, spatial, problem-solution, cause-effect), the use of narrative anchors (anecdotes, case studies, historical references), and the structural devices (transitions, repetitions, contrasts) that guide the reader from premise to conclusion.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student can independently map the text's macro-structure (identifying 4-5 major structural segments), explain how each segment advances the central argument about state borders and water politics, and justify why the author chose this specific sequencing over alternative organizational patterns.

## SCOPE_BOUNDARY
This node covers the structural analysis of "jktLFkku dh jtr cw¡nas" as an argumentative-expository text: its idea-sequencing, narrative anchors, and rhetorical architecture. It does NOT cover character analysis (nodes 004-005), thematic deep-dives (nodes 006-007), or literary devices (nodes 008-009)—those are separate nodes.

## WALKTHROUGH
Imagine you're given a 10-page government report on interstate water disputes—dense, factual, no dialogue, no "story." How would you find the "plot"? Start by asking: "What problem does the author want me to see, and in what order does he reveal it?" In this text, vuqie feJ opens with a visceral scene—laborers digging a canal in scorching heat, water evaporating before it reaches fields—this is the narrative hook (the "inciting incident"). Then he layers: geographical facts → historical water systems → colonial disruption → modern technological failures → human cost. Notice how each paragraph doesn't just add information; it escalates the stakes. The key insight: in non-fiction, plot = the architecture of persuasion. The "climax" isn't an event but a realization—the irony that borders drawn for administration become barriers to survival.

## DIAGNOSTIC_QUESTION_1
Identify the three distinct structural phases in the opening section (pages 9-11) where the author moves from immediate sensory observation to systemic analysis. Name each phase in one phrase.

## DIAGNOSTIC_ANSWER_1
Correct answer: (1) Visceral Scene-Setting (the canal-digging tableau), (2) Geographical-Typological Classification (types of water sources: surface, groundwater, rain-fed), (3) Historical-Continuity Disruption (traditional systems vs. colonial/modern interventions). A wrong answer listing "introduction, body, conclusion" reveals the student is applying fiction narrative labels (exposition-rising action-climax) to an expository text, missing that non-fiction structure is argument-driven, not event-driven.

## DIAGNOSTIC_QUESTION_2
The author inserts a detailed description of the 'johad' (traditional check-dam) construction process on pages 14-15. Explain why this technical description is placed AFTER the discussion of modern canal failures (pages 12-13) rather than at the beginning. What structural principle governs this sequencing?

## DIAGNOSTIC_ANSWER_2
Correct answer: The sequencing follows a "failure-before-alternative" rhetorical strategy—first establishing the inadequacy of modern techno-bureaucratic solutions (evaporation losses, siltation, displacement) to create a conceptual vacuum, then presenting indigenous knowledge as the organic answer. A wrong answer saying "chronological order" or "traditional comes first historically" reveals the student confuses historical chronology with textual architecture; the author deliberately inverts chronology for persuasive effect.

## DIAGNOSTIC_QUESTION_3
On page 16, the author describes how laborers' payment shifted from "annual grain share" to "cash wages" to "contract-based piece rates." Map this progression onto the text's larger argument about the changing relationship between state, resource, and citizen. Which structural device (contrast, parallelism, escalation, or framing) does this mini-sequence exemplify?

## DIAGNOSTIC_ANSWER_3
Correct answer: Escalation (specifically, escalating alienation). The three payment forms represent tightening state control: grain share → reciprocal relationship; cash wage → monetized transaction; piece-rate contract → atomized, expendable labor. This micro-escalation mirrors the macro-escalation from community-managed johads → state canals → corporate contracts. A wrong answer identifying "contrast" misses the directional worsening; "parallelism" ignores the causal chain; "framing" misidentifies the device as a wrapper rather than a progressive intensification.

## DIAGNOSTIC_QUESTION_4
Compare the structural function of the Rajasthan canal description (pages 10-11) with the Tamil Nadu temple-tank description (page 19). Both are case studies, but they serve opposite rhetorical purposes. Explain the difference using the concepts of "negative exemplar" and "positive exemplar" within the text's problem-solution architecture.

## DIAGNOSTIC_ANSWER_4
Correct answer: The Rajasthan canal is a negative exemplar—it demonstrates centralized, top-down engineering failure (evaporation, seepage, inequitable distribution, ecological disruption). The Tamil Nadu temple-tank is a positive exemplar—it demonstrates decentralized, community-governed success (groundwater recharge, equitable access, cultural embeddedness, resilience). Together they form a dialectical pair: the text's argument structure is thesis (modern failure) → antithesis (traditional success) → synthesis (policy implication: devolve control). A wrong answer treating both as "examples of water systems" misses their oppositional rhetorical roles.

## DIAGNOSTIC_QUESTION_5
The text ends (page 20) not with a policy prescription but with the image of "cw¡n&cw¡n jsr" (trickling streams) merging into "ehBk ikuh" (sweet water) in the johad. Evaluate whether this ending is structurally inevitable or a missed opportunity for explicit advocacy. Defend your judgment using the concept of "narrative closure" in argumentative non-fiction.

## DIAGNOSTIC_ANSWER_5
Correct answer: Structurally inevitable. The text's architecture is inductive—it builds from ground-level evidence upward, refusing the deductive "policy-first" frame of state reports. The final image enacts the very principle argued throughout: small, decentralized flows self-organizing into abundance without central command. An explicit prescription would violate the text's own logic (that solutions emerge from practice, not decree). A wrong answer calling it "weak ending" or "missing conclusion" reveals expectation of a conventional policy-paper structure (problem → analysis → recommendation), missing that this is a literary argument where form embodies content.

## DIAGNOSTIC_QUESTION_6
Write a 150-word "structural summary" of the text for a Class 11 student who hasn't read it, using ONLY structural terminology (no content summary). Include: opening hook, sequencing principle, two major structural pivots, dialectical pair, and closure strategy.

## DIAGNOSTIC_ANSWER_6
Expected answer: "The text opens with a visceral sensory hook (canal-digging in heat). Sequencing follows problem-escalation: immediate crisis → typological taxonomy → historical disruption → modern failure (negative exemplar: Rajasthan canal) → traditional success (positive exemplar: Tamil Nadu temple-tank) → synthesis in indigenous practice (johad). First pivot: shift from hydrology to political economy (page 12, labor payment systems). Second pivot: shift from rural to urban water stress (page 18, borewell culture). Dialectical pair: centralized state engineering vs. decentralized community governance. Closure: inductive enactment—final image of trickling streams self-organizing mirrors the argued principle, refusing prescriptive closure." A poor answer listing topics ("talks about canals, then johads, then borewells") reveals inability to distinguish structure from content.

## COMMON_MISCONCEPTION
Students treat "plot" in non-fiction as a chronological timeline of events described in the text (e.g., "first canals were built, then johads, then borewells"). They miss that the TEXT'S plot is the author's strategic sequencing of ideas—which deliberately scrambles chronology (traditional johads described AFTER modern canals) to create rhetorical tension. This error stems from importing fiction-narrative templates (exposition → rising action → climax) into expository analysis, ignoring that non-fiction plot = argument architecture.

## ON_FAILURE
Step 1: Give the student a 3-paragraph op-ed on a familiar topic (e.g., "Why Delhi's odd-even scheme fails"). Ask them to number the paragraphs 1-3 and write ONE WORD for each paragraph's FUNCTION (not topic): e.g., "hook," "evidence," "rebuttal," "call-to-action." Step 2: Have them physically cut and reorder the paragraphs—ask "Does the argument still work? Why/why not?" Step 3: Map this to the textbook: identify the "hook" paragraph (page 9 canal scene), the "evidence" section (pages 10-13 hydrology/history), the "rebuttal" (pages 14-17 johad as counter-model). Step 4: Explicitly name the principle: "Non-fiction plot = the minimum number of pieces that must stay in this order for the argument to hold."

## BUILDS_ON
c11_hin_v_cbse_02_001 (Before You Read: Context and Background) — provides the historical-geographical frame (colonial irrigation policies, princely states, post-independence water disputes) without which the text's structural choices appear arbitrary.

## LEADS_TO
c11_hin_v_cbse_02_003 (Text: Setting and Atmosphere) — the structural analysis reveals HOW the author constructs "setting" not as backdrop but as active argument (the canal, the johad, the borewell are each staged settings that perform rhetorical work).

## PREREQUISITE_NODE_IDS
c11_hin_v_cbse_02_001
## PREREQUISITE_REASONS
c11_hin_v_cbse_02_001: Provides the historical-geographical context (colonial canal policies, princely state water systems, post-1947 interstate disputes) that makes the author's structural choices—especially the traditional vs. modern dialectic—intelligible as deliberate rhetorical moves rather than random topic shifts.

## FORWARD_NODE_IDS
c11_hin_v_cbse_02_003, c11_hin_v_cbse_02_006, c11_hin_v_cbse_02_013, c11_hin_v_cbse_02_004, c11_hin_v_cbse_02_005, c11_hin_v_cbse_02_007, c11_hin_v_cbse_02_008, c11_hin_v_cbse_02_009, c11_hin_v_cbse_02_011, c11_hin_v_cbse_02_012, c11_hin_v_cbse_02_014, c11_hin_v_cbse_02_015, c12_hin_a_cbse_03_002, c12_hin_a_cbse_09_002, c12_hin_al_cbse_03_002, c12_hin_v_cbse_02_002

## FORWARD_REASONS
c11_hin_v_cbse_02_003: Structural mapping reveals that "setting" in this text is not passive backdrop but sequentially staged argumentative spaces (canal → johad → borewell → temple-tank) each performing specific rhetorical functions. c11_hin_v_cbse_02_006: The primary theme (decentralized wisdom vs. centralized control) IS the text's structural spine; you cannot analyze theme without seeing how the structure builds it dialectically. c11_hin_v_cbse_02_013: Critical interpretation requires evaluating structural integrity—does the inductive closure actually persuade, or does it evade policy responsibility? That judgment needs the structural map built here.
c11_hin_v_cbse_02_004: Plot and narrative structure knowledge helps locate the protagonist's actions within the story arc.  
c11_hin_v_cbse_02_005: Plot structure shows *when* each supporting character enters the narrative arc (laborers first, teacher mid-way, community at rituals).  
c11_hin_v_cbse_02_007: Plot and narrative structure knowledge allows students to locate where secondary themes appear in the narrative arc (e.g., during collective digging vs. during meals).  
c11_hin_v_cbse_02_008: Understanding the plot and narrative structure helps locate where key images and metaphors appear in the text's progression.  
c11_hin_v_cbse_02_009: Plot/narrative structure identifies key scenes (furnace work, inspection, wage payment) where devices operate.  
c11_hin_v_cbse_02_011: Understanding plot and narrative structure helps locate where descriptive vs. narrative language dominates.  
c11_hin_v_cbse_02_012: Understanding plot/narrative structure helps locate where specific details appear for evidence retrieval.  
c11_hin_v_cbse_02_014: Plot and narrative structure provides the event sequence (khadin construction, khai ceremony) that answers must reference accurately.  
c11_hin_v_cbse_02_015: Understanding plot and narrative structure provides the sequence of events for chronological discussion points.  
c12_hin_a_cbse_03_002: Further practice with structural analysis in a different Class 11 chapter.  
c12_hin_a_cbse_09_002: Vitan chapter 2 narrative structure practice.  
c12_hin_al_cbse_03_002: Practiced mapping spatial movement as structural device — directly applicable to the bankSj→usekoj→pacy walk.  
c12_hin_v_cbse_02_002: Deepens understanding of frame narrative and retrospective narration through a different text, giving the student a comparative lens.  
c11_hin_v_cbse_02_006: Plot events (advance payment, seasonal closure, kiln reopening) are the narrative backbone of the theme.  
c11_hin_v_cbse_02_013: Plot structure provides the narrative framework for analytical claims about pacing and emphasis.  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
none

## CHAIN_DESCRIPTION
c11_hin_v_cbse_02_001 -> c11_hin_v_cbse_02_002 -> c11_hin_v_cbse_02_003, c11_hin_v_cbse_02_006, c11_hin_v_cbse_02_013

## THIS_FORMULA
N/A - conceptual

## FORMULA_VARIABLES
N/A

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
analytical

## CROSS_SUBJECT
c11_geography_water_resources | The text's structural contrast between canal irrigation (surface water, high evaporation, centralized) and johad/tank systems (groundwater recharge, decentralized) mirrors the geography syllabus's comparative analysis of irrigation methods' ecological footprints and equity outcomes. c11_civics_federalism | The narrative pivot from colonial centralized water control to post-independence interstate disputes (pages 12-13, 19) enacts the civics concept of "water as a federalism fault line"—the text's structure performs the center-state tension over resource jurisdiction. c11_economics_sustainable_development | The escalating labor-payment sequence (grain-share → cash → piece-rate) structurally demonstrates the economics concept of "commons enclosure"—how resource governance shifts from community reciprocity to market alienation, a core sustainable development case study.

## PREREQ_CONCEPT
Understanding that expository texts have a "rhetorical architecture" (idea-sequencing, evidence-staging, dialectical pairs) distinct from fiction's event-sequencing.

## PREREQ_BEFORE
Student must distinguish "what the text says" (content) from "how the text builds its case" (structure)—able to label a paragraph's FUNCTION (hook, evidence, counterexample, synthesis) not just its TOPIC.

## PREREQ_STUCK
Review "rhetorical modes" (narration, description, exposition, argumentation) and practice labeling paragraph functions in a familiar editorial or speech.

## WORKED_EXAMPLE_1
PROBLEM: A Class 11 student reads pages 9-11 and writes: "The author describes canal digging, then lists water sources, then talks about history. It's informative but disorganized." Diagnose the structural blindness and demonstrate the correct analysis in 6 steps.

STEPS:
- Step 1: Identify the student's error—treating the text as a linear information dump rather than a strategic argument. The phrase "disorganized" reveals expectation of textbook-style topical grouping (all history together, all geography together).
- Step 2: Re-read page 9's opening tableau (laborers, heat, evaporating water) and label its FUNCTION: "visceral hook that makes the abstract problem (water loss) bodily felt before any data appears."
- Step 3: Trace the IMMEDIATE next move (page 10, "psyokath ;kuh pstkjks...")—the author zooms from ONE canal to the TYPOLOGY of water sources (surface, ground, rain). Label: "taxonomic grounding—establishes the conceptual vocabulary for the whole argument."
- Step 4: Notice the PIVOT on page 11 ("jsr osQ d.k cgqr gh ckjhd gksrs gSa")—shift from hydrology to UNPREDICTABILITY/CHAOS. Label: "problem complication—data alone won't solve it; the system is inherently unstable."
- Step 5: Identify the HISTORICAL LAYER (pages 11-12, "nkseV ;k dkyh fe^h...")—colonial disruption of traditional systems. Label: "genealogical depth—shows the crisis is manufactured, not natural."
- Step 6: Synthesize: The "disorganization" IS the structure—hook → taxonomy → complication → genealogy → (next section: alternative model). This sequence builds the reader's NEED for the johad solution before it appears.

REASONING: Non-fiction structure is the choreography of the reader's epistemic state—what they feel, know, doubt, and need at each stage. The student missed this because they tracked TOPICS not MOVES.

ANSWER: The text's opening structure (pages 9-12) follows a 4-move rhetorical arc: (1) Visceral Hook → (2) Conceptual Taxonomy → (3) Systemic Complication → (4) Historical Genealogy. Each move escalates the problem's perceived depth, preparing the reader for the indigenous-solution turn on page 13. The student's "disorganized" judgment reflects applying a reference-book schema (topic clusters) to a persuasive essay schema (problem escalation).

## WORKED_EXAMPLE_2
PROBLEM: The text devotes pages 14-15 to a granular, almost technical description of johad construction (materials, labor, seasonal timing, maintenance rituals). A student asks: "Why so much detail? Isn't this a digression from the main argument?" Demonstrate in 6 steps how this section is structurally indispensable.

STEPS:
- Step 1: Locate the section's position—IMMEDIATELY AFTER the modern canal failure analysis (pages 12-13) and BEFORE the borewell crisis (page 17). This sandwiching is intentional.
- Step 2: Identify the structural role: "positive exemplar" or "counter-model." The canal pages proved centralized engineering fails; the johad pages must PROVE an alternative works—technically, socially, ecologically.
- Step 3: Analyze the DETAIL TYPES: material specificity (clay, stone, lime), labor organization (community rotations), temporal logic (monsoon capture), maintenance ethics (collective responsibility). Each detail refutes a specific canal failure: evaporation → covered storage; siltation → desilting ritual; inequity → shared labor; state neglect → community ownership.
- Step 4: Notice the NARRATIVE VOICE SHIFT: from third-person reportage (canals) to second-person immersive ("pstks ;kuh fpukbZ dk Js"Bre dke..."). This enacts the argument: johads require PARTICIPATION, not observation.
- Step 5: Track the SCALE PROGRESSION: single johad (page 14) → cluster of 3-5 johads (page 15) → regional network (page 15, "rhl&pkyhl oqaQb;k¡"). This micro-to-macro scaling proves SCALABILITY—the standard objection to traditional systems.
- Step 6: Connect to the text's CLIMACTIC CLAIM (page 16): "oqaQbZ dk eq¡g NksVk j[kus osQ rhu cM+s dkj.k gSa"—the johad detail IS the evidence for this threefold claim (recharge, equity, resilience). Without the granular proof, the claim is assertion.

REASONING: In argumentative non-fiction, the "positive exemplar" must be at least as concretely evidenced as the "negative exemplar." The canal failure got 3 pages of hydrological data; the johad success needs equivalent technical credibility. The detail IS the argument.

ANSWER: The johad construction detail (pages 14-15) is the text's evidentiary core for its central thesis. Structurally, it functions as: (a) the positive dialectical pole to the canal's negative pole, (b) the technical proof of concept for the threefold claim on page 16, (c) the scalability demonstration (single → cluster → network), and (d) the participatory voice-shift that enacts the governance model it advocates. Removing it would collapse the argument from "proven alternative" to "nostalgic wish."

## WORKED_EXAMPLE_3
PROBLEM: The text's final two pages (19-20) introduce urban borewell culture, temple-tank revival in Tamil Nadu, and the johad image—all rapidly. A board exam question asks: "Analyze how the concluding section (pages 19-20) synthesizes the text's central argument through its structural design." Write a 6-step analytical response.

STEPS:
- Step 1: Map the concluding section's THREE SUB-UNITS: (A) Urban borewell crisis (page 19, "futh vkSj lkoZtfud laifÙk...") — the modern endpoint of the water trajectory. (B) Tamil Nadu temple-tank case (page 19-20, "tSlyesj f"kys osQ...") — the positive exemplar at regional scale. (C) Final johad image (page 20, "cw¡n&cw¡n jsr...") — the inductive closure.
- Step 2: Identify the TEMPORAL STRATEGY: The text has moved from colonial past → post-independence canals → 1980s johad revival → 1990s borewell boom → contemporary temple-tank restoration. This is NOT chronology; it's a "problem genealogy" showing each solution becoming the next problem.
- Step 3: Analyze the SPATIAL STRATEGY: Rural Rajasthan (canal/johad) → Urban India (borewell) → Rural Tamil Nadu (temple-tank) → Universal johad image. The geographic leap from Rajasthan to Tamil Nadu performs "federalism of solutions"—arguing decentralized water wisdom is pan-Indian, not regional.
- Step 4: Examine the DIALECTICAL RESOLUTION: The borewell (privatized, competitive, depleting) and temple-tank (communal, recharging, cultural) are the final thesis-antithesis. The johad image synthesizes them: it has the temple-tank's communal logic but the borewell's groundwater access—WITHOUT the borewell's extraction violence.
- Step 5: Evaluate the CLOSURE STRATEGY: No policy prescription. The final sentence ("blh [kM+h osQ cy ij [kkjs ikuh osQ chp ehBk ikuh nsrh [kM+h jgrh gS oqaQbZ") is a PRESENT-TENSE GENERIC TRUTH, not a future recommendation. This enacts the text's core claim: the solution ALREADY EXISTS in practice; recognition, not invention, is needed.
- Step 6: Connect to BOARD EXAM CRITERIA: "Synthesizes" means showing how disparate elements (urban/rural, modern/traditional, North/South, extraction/recharge) are structurally woven into a single coherent argument. The conclusion doesn't SUMMARIZE; it ENACTS the synthesis.

REASONING: Senior secondary analysis requires seeing structure as argumentative choreography—not what topics appear last, but how the final section resolves tensions built across the whole text. The three sub-units are not "additional examples"; they are the final dialectical moves.

ANSWER: The concluding section (pages 19-20) synthesizes the argument through a three-move dialectical structure: (1) Urban borewell crisis — the terminal failure of privatized extraction (thesis), (2) Tamil Nadu temple-tank revival — the proven success of cultural-commons governance (antithesis), (3) Generic johad image — the inductive synthesis showing the solution is already embedded in practice. Spatially, it jumps Rajasthan→Urban→Tamil Nadu→Universal to demonstrate pan-Indian applicability. Temporally, it traces each "solution" becoming the next "problem" (canal→borewell→tank revival). The present-tense generic closure ("jgrh gS") refuses prescriptive futurity, enacting the argument that decentralized water wisdom is a living, not proposed, reality. This structural design makes the conclusion the argument's logical necessity, not its summary.

## COMPETENCY_QUESTION_1
QUESTION: The author could have structured this text as a conventional policy report: Problem (water scarcity) → Causes (climate, population, mismanagement) → Solutions (rainwater harvesting, canal lining, demand management) → Recommendations. Instead, he chooses an inductive, dialectical, narrative-driven architecture. Identify THREE specific structural choices that differentiate this text from a policy report, and explain how EACH choice serves the author's deeper purpose of recentering "lok vidya" (people's knowledge) as legitimate expertise.

COMPETENCY: Critical analysis of rhetorical structure in non-fiction; ability to contrast organizational schemas and link form to ideological purpose.

STEPS:
- Step 1: Identify the policy-report schema (problem → cause → solution → recommendation) as the implicit comparator.
- Step 2: Choose three structural deviations: (a) Opening with visceral scene not problem statement, (b) Placing traditional knowledge AFTER modern failure not before, (c) Closing with enactment not prescription.
- Step 3: For each, trace the rhetorical effect on "lok vidya" positioning: (a) Visceral hook makes the reader experience the failure bodily, creating need for grounded knowledge; (b) Sequencing makes traditional knowledge the DISCOVERED answer not the GIVEN tradition; (c) Enactment closure makes the reader participate in the knowledge rather than receive it.
- Step 4: Synthesize: The structure doesn't just ARGUE for lok vidya; it PERFORMS its epistemology—knowledge from practice, not theory.

ANSWER: Three structural choices that recenter lok vidya: (1) Visceral opening (canal-digging heat) vs. abstract problem statement — forces reader into embodied knowing, the epistemological ground of lok vidya. (2) Traditional systems as "discovered counter-model" (pages 14-15) after modern failure (pages 12-13) vs. "heritage showcase" at start — positions lok vidya as pragmatic solution, not cultural nostalgia. (3) Inductive enactment closure ("cw¡n&cw¡n jsr... jgrh gS") vs. prescriptive recommendations — makes the reader witness the knowledge working, not be told it works. The structure thus performs the argument: lok vidya is not "traditional knowledge" (static, past) but "living practice" (present, generative).

DIFFICULTY: hard

## COMPETENCY_QUESTION_2
QUESTION: A Class 12 board exam question: "The text 'jktLFkku dh jtr cw¡nas' uses a 'negative exemplar → positive exemplar → inductive enactment' structure. Evaluate the effectiveness of this design for persuading a skeptical bureaucrat reader who believes 'modern engineering is scalable; traditional systems are not.' Your answer must reference at least two specific textual evidence-points and one structural principle."

COMPETENCY: Evaluative judgment of rhetorical effectiveness for a specific audience; evidence-based structural analysis; audience-aware argumentation.

STEPS:
- Step 1: Define the skeptical bureaucrat's mental model: scalability = uniform technical replicability; tradition = local, small, non-replicable.
- Step 2: Identify the text's structural counters to this model: (a) The johad CLUSTER evidence (page 15: "rhl&pkyhl oqaQb;k¡ Hkh fey tkrh gSa") — proves NETWORK scalability, not just unit replicability. (b) The Tamil Nadu temple-tank REGIONAL SYSTEM (page 19: "tSlyesj f"kys osQ ,d xk¡o [kM+sjksa dh <k.kh esa rks ,d lkS chl oqaQb;k¡ Fkha") — proves cross-ecological scalability. (c) The structural principle: DISTRIBUTED SCALABILITY (many small connected nodes) vs. CENTRALIZED SCALABILITY (one large node).
- Step 3: Evaluate effectiveness: The bureaucrat's objection is ANSWERED structurally—the text doesn't just claim scalability; its spatial progression (single johad → cluster → regional network → pan-Indian principle) DEMONSTRATES the scaling logic at each step.
- Step 4: Identify limitation: The text never addresses the bureaucrat's core incentive structure (budget control, measurable targets, contractor networks). The structure persuades epistemically but not institutionally.
- Step 5: Conclude: Highly effective for epistemic conversion; insufficient for institutional adoption without complementary policy-translation layer.

ANSWER: The structure is epistemically effective but institutionally incomplete for a bureaucrat reader. Effectiveness: The negative exemplar (Rajasthan canal: evaporation 40%, tail-end deprivation) establishes the centralized model's failure on the bureaucrat's own metrics (efficiency, equity). The positive exemplar sequence—single johad (page 14) → 3-5 johad cluster (page 15) → Tamil Nadu's 150+ temple-tank network (page 19)—structurally demonstrates DISTRIBUTED SCALABILITY: each unit is locally adapted, but the NETWORK LOGIC (recharge → sharing → resilience) replicates across ecologies. This directly counters "tradition doesn't scale." Structural principle: the text uses SPATIAL PROGRESSION (micro → meso → macro → universal) as proof of scaling logic. Limitation: The bureaucrat's decision calculus involves budget heads, contractor lobbies, and measurable output targets—the text's inductive enactment closure offers no "scheme," no "budget line," no "monitoring framework." The structure wins the argument but not the procurement process. For full persuasion, a companion "policy translation" document would be needed—mapping johad principles to MGNREGA guidelines, Jal Shakti Abhiyan metrics, etc.

DIFFICULTY: hard