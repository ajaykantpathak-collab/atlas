## DEFINITION
Plot and narrative structure in poetry refers to the organized sequence of events, actions, and perspectives that construct a story within the poem, including the exposition, rising action, climax, and resolution, as well as the narrative voice and temporal arrangement chosen by the poet.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student can independently map the narrative arc of both poems in the chapter, identify the narrative perspective (first-person/third-person), and explain how structural choices like stanza breaks and temporal shifts shape the story's emotional impact.

## SCOPE_BOUNDARY
This node covers the narrative structure of the two specific poems by Vadde Kanshi in Chapter 14 (Aroh Part 1). It does not cover prose narrative structures, other chapters, or detailed metrical analysis (covered in Literary Devices nodes).

## WALKTHROUGH
Imagine you are describing a viral Instagram reel to a friend who hasn't seen it: you don't just list random clips; you set the scene, build tension, hit the punchline, and give the aftermath. That instinctive ordering is narrative structure. Now, open your textbook to the first poem (the Braj Bhasha one). Before hunting for metaphors, ask: "Who is speaking? What happens first, next, last? Where does the tension peak?" Notice how the first poem compresses a whole life-cycle of injustice into two dense stanzas, while the second poem unfolds a single dramatic encounter in real-time dialogue. The key insight: narrative structure in poetry is not just *what* happens, but *how the poet orders and reveals it* through stanzas, line breaks, and voice.

## DIAGNOSTIC_QUESTION_1
What is the primary narrative perspective used in the first poem (स्टैनज़ा 1 और 2) of this chapter, and who is the implied speaker?

## DIAGNOSTIC_ANSWER_1
The first poem uses a third-person omniscient perspective initially, shifting to a collective voice of the oppressed (बाफिंज़ा/किसान) in the second stanza; the implied speaker is the poet Vadde Kanshi giving voice to the peasants. A wrong answer (e.g., "first-person poet" or "Vadde Kanshi herself") reveals the student confuses the *author* with the *narrative persona* and misses the dramatic voicing of the marginalized.

## DIAGNOSTIC_QUESTION_2
Explain in your own words how the narrative timeline differs between the two poems in this chapter.

## DIAGNOSTIC_ANSWER_2
The first poem spans a macro-timeline: generations of exploitation (historical past) → a specific king's betrayal (immediate past) → the poet's present act of writing (present). The second poem operates in micro-real-time: a single continuous scene where a bird pleads, the hunter hesitates, and a moral choice hangs unresolved. A wrong answer treating both as "past tense stories" reveals the student cannot distinguish compressed historical sweep from dramatic scenic immediacy.

## DIAGNOSTIC_QUESTION_3
Apply the concept of 'narrative climax' to the second poem: identify the exact turning point (line/stanza) where the hunter's internal conflict becomes external action, and justify your choice.

## DIAGNOSTIC_ANSWER_3
The climax occurs at the hunter's internal monologue: "और यदि मैं उसे मार डालूँ / तो कोई देख ले / और उसे छीन ले जाए" (lines 7-9). This is the turning point because the poem shifts from the bird's external plea to the hunter's internal moral calculus, freezing the action at the moment of decision. A wrong answer picking the bird's first speech reveals the student confuses *inciting incident* with *climax* and misses the protagonist shift from bird to hunter.

## DIAGNOSTIC_QUESTION_4
Analyze how the stanza structure in the first poem controls narrative pacing: why does the poet use only two stanzas to cover centuries of history?

## DIAGNOSTIC_ANSWER_4
The two-stanza structure creates a devastating acceleration: Stanza 1 establishes the eternal, cyclical oppression ("बाफिंज़ा पर फूँका लगाया") in a timeless present; Stanza 2 collapses a specific betrayal (king breaking promise) and its consequence (poet's rebellion) into a tight cause-effect chain. The lack of stanza breaks *within* each idea forces the reader to experience history as an unbroken weight, not a series of episodes. A wrong answer focusing on rhyme scheme reveals the student treats structure as decoration, not a pacing instrument.

## DIAGNOSTIC_QUESTION_5
Evaluate the effectiveness of the unresolved ending in the second poem ("यदि मैं उसे मार डालूँ..."). Does the open ending strengthen or weaken the narrative's thematic punch? Defend your view.

## DIAGNOSTIC_ANSWER_5
The open ending strengthens the theme: by denying resolution, the poem forces the reader to inhabit the hunter's moral paralysis, making *us* the ones who must decide between compassion and survival. This mirrors the peasant's eternal dilemma in Poem 1. A wrong answer demanding a "proper ending" reveals the student expects narrative closure as a default, missing how modernist poetry uses structural incompleteness as political commentary.

## DIAGNOSTIC_QUESTION_6
Create a third stanza for the first poem that logically extends the narrative arc from rebellion to consequence, maintaining the Braj Bhasha flavor and the collective voice.

## DIAGNOSTIC_ANSWER_6
A strong answer adds a stanza showing the aftermath: e.g., the poet's execution/silencing, but the seeds of revolt sprouting in other villages (cyclical return). It must use Braj vocatives (एरी, ओरी), present participles (चलत, बोलत), and the refrain "बाफिंज़ा पर..." to close the loop. A weak answer writes in modern Hindi, resolves happily, or shifts to first-person "I", revealing the student cannot sustain narrative voice, dialect register, or the poem's tragic logic.

## COMMON_MISCONCEPTION
Students treat the two poems as isolated "stories" and miss that they form a diptych: Poem 1 establishes the *systemic* narrative (class oppression across time), while Poem 2 enacts the *individual* moral crisis that the system produces. They also confuse the *poet's biography* (Vadde Kanshi's life) with the *narrative persona* in the poems, leading to biographical readings instead of structural analysis.

## ON_FAILURE
1. Have the student draw a two-column timeline: left column for Poem 1 (events: historical oppression → king's betrayal → poet's revolt), right column for Poem 2 (events: bird trapped → plea → hunter's dilemma). 2. Ask: "Which events are shown *happening now* vs *reported as past*?" 3. Color-code: red for present action, blue for backstory. 4. Finally, ask: "If you swapped the stanza order in Poem 1, how would the narrative impact change?" This forces structural thinking over content recall.

## BUILDS_ON
c11_hin_ar_cbse_14_001 (Context/Background) provides the historical reality (Bundelkhand famine, peasant revolts) that the narrative structure of these poems encodes and reorders.

## LEADS_TO
c11_hin_ar_cbse_14_003 (Setting and Atmosphere) – once the narrative skeleton is mapped, we examine how spatial/temporal setting fleshes out the bones.

## PREREQUISITE_NODE_IDS
c11_hin_ar_cbse_14_001
## PREREQUISITE_REASONS
c11_hin_ar_cbse_14_001: The context node supplies the historical events (1842 revolt, Vadde Kanshi's role) that the poems restructure; without it, students cannot distinguish poetic invention from historical record in the narrative.

## FORWARD_NODE_IDS
c11_hin_ar_cbse_14_003, c11_hin_ar_cbse_14_004, c11_hin_ar_cbse_14_006, c11_hin_ar_cbse_14_005, c11_hin_ar_cbse_14_007, c11_hin_ar_cbse_14_008, c11_hin_ar_cbse_14_009, c11_hin_ar_cbse_14_012, c11_hin_ar_cbse_14_013, c11_hin_ar_cbse_14_014, c11_hin_ar_cbse_14_015, c12_hin_a_cbse_09_002, c12_hin_a_cbse_14_002

## FORWARD_REASONS
c11_hin_ar_cbse_14_003: Narrative structure determines *when* and *where* the story unfolds; setting analysis needs the timeline first. c11_hin_ar_cbse_14_004: The protagonist (Vadde Kanshi/bird/hunter) is defined by their role in the narrative arc. c11_hin_ar_cbse_14_006: Primary theme (resistance) emerges from the structural contrast between the two poems' narratives.
c11_hin_ar_cbse_14_005: Establishes narrative structure of the poems (especially the dramatic monologue form of poem 2) which frames how supporting characters enter.  
c11_hin_ar_cbse_14_007: Narrative structure of the two poems (collective song vs. domestic dialogue) determines where secondary themes surface.  
c11_hin_ar_cbse_14_008: Narrative structure shows Poem 1 = past trauma, Poem 2 = present resistance — devices map onto this temporal shift.  
c11_hin_ar_cbse_14_009: Understanding plot and narrative structure helps locate where irony and symbolism appear in the poems.  
c11_hin_ar_cbse_14_012: Understanding plot sequence allows students to locate explicit facts for literal questions.  
c11_hin_ar_cbse_14_013: Establishes narrative structure of the poems (stanza progression) for structural analysis.  
c11_hin_ar_cbse_14_014: Narrative structure helps sequence evidence logically in the answer.  
c11_hin_ar_cbse_14_015: Narrative structure understanding helps students reference specific poem sections during discussion.  
c12_hin_a_cbse_09_002: Wrote structured analyses of narrative.  
c12_hin_a_cbse_14_002: Class 11 coverage of plot and narrative structure for this same chapter (if taught) or analogous stories; establishes foundational terminology.  
c11_hin_ar_cbse_14_004: Establishes the narrative structure of the two poems, helping identify the speaker's voice.  
c11_hin_ar_cbse_14_006: Narrative structure reveals how theme unfolds across the two poems  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
none

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_14_001 -> c11_hin_ar_cbse_14_002 -> c11_hin_ar_cbse_14_003

## THIS_FORMULA
N/A - conceptual

## FORMULA_VARIABLES
N/A

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
analytical

## CROSS_SUBJECT
c11_history_colonial_india | The poems restructure the 1842 Bundelkhand peasant revolt; analyzing narrative structure mirrors how historians select and sequence events to construct historical narratives.
c11_politicalscience_democracy | The hunter's dilemma in Poem 2 (individual conscience vs survival) dramatizes the civic tension between moral agency and structural coercion central to democratic theory.

## PREREQ_CONCEPT
Understanding the difference between *story* (chronological events) and *plot* (author's arrangement of events) – the foundational narratology distinction.

## PREREQ_BEFORE
Student must know the bare historical facts of the 1842 Bundelkhand revolt and Vadde Kanshi's biography from the Context node.

## PREREQ_STUCK
If stuck, review the "Story vs Plot" distinction using a familiar Bollywood movie: the *story* is the hero's life birth-to-death; the *plot* is the film's non-linear flashbacks, songs, and climax ordering.

## WORKED_EXAMPLE_1
PROBLEM: Map the complete narrative arc (Exposition, Rising Action, Climax, Falling Action, Resolution) of the first poem (Braj Bhasha poem, both stanzas). Identify where the poet compresses or expands time.

STEPS:
- Step 1: Identify the narrative voice and temporal anchor. The poem opens in a timeless present ("बाफिंज़ा पर फूँका लगाया" – habitual/generic), not a specific past. This is the Exposition: the eternal condition of the peasantry.
- Step 2: Locate the inciting incident. "एक बार... राजा ने... तीन किश्तें रखीं" – a specific historical breach of contract by the king. This shifts from generic to specific, launching the Rising Action.
- Step 3: Trace the causal chain. King breaks promise → peasants suffer → Vadde Kanshi confronts power → power rejects → she destroys the settlement. Each clause is a beat in the rising action.
- Step 4: Pinpoint the Climax. "बोस कूं नैकूं... नैकूं कूं बोस" – the moment of direct confrontation and destruction of the written record (the king's instrument of power). The poem's energy peaks here.
- Step 5: Assess Resolution. The poem ends *at* the climax; there is no falling action or resolution. The narrative arc is deliberately truncated, leaving the rebellion unconcluded – a structural enactment of "unfinished revolution".
- Step 6: Analyze time compression. Centuries of "फूँका लगाया" compressed into one line; the specific revolt expanded into detailed dialogue. The poet expands the moment of resistance, compresses the centuries of submission.

REASONING: This step-by-step forces the student to move from "what happens" to "how the poet orders time and focus". The missing resolution is not an oversight but a political statement – the narrative structure *is* the argument.

ANSWER: The narrative arc is: Exposition (eternal oppression) → Inciting Incident (king's betrayal) → Rising Action (confrontation) → Climax (destruction of settlement papers) → No Resolution (open-ended rebellion). Time is compressed for submission (1 line), expanded for resistance (detailed sequence).

## WORKED_EXAMPLE_2
PROBLEM: The second poem is a dramatic monologue/dialogue hybrid. Diagram the narrative perspective shifts: who speaks, to whom, and how the "camera angle" changes across the poem.

STEPS:
- Step 1: Segment the poem by speaker. Lines 1-6: Bird speaks to Hunter (Second-person address: "एरी... मोरी"). Lines 7-9: Hunter's internal monologue (First-person: "मैं... मुझे"). Lines 10-12: Hunter addresses Bird again (Second-person imperative: "जा... उड़ जा").
- Step 2: Identify the narrative "camera". Opens tight on Bird's perspective (subjective fear). Shifts to Hunter's interiority (subjective calculation). Ends on Hunter's external command but Bird's fate unknown.
- Step 3: Map the power dynamic. Initially Bird is supplicant (low power), Hunter holds power. At climax, Hunter *feels* powerless ("कोई देख ले / छीन ले जाए") – power shifts to unseen social surveillance.
- Step 4: Note the structural irony. The poem begins with Bird's *voice* (agency through speech) but ends with Hunter's *silence* (agency withheld). The narrative structure enacts the silencing of the vulnerable.
- Step 5: Connect to stanza form. The poem is written as a single block (no stanza breaks in the textbook print), mimicking the unbroken tension of the encounter. The lack of visual pauses forces the reader through the moral crisis in one breath.

REASONING: This analysis moves beyond "who says what" to "how the narrative structure distributes empathy and power". The perspective shifts are the engine of the poem's ethical challenge.

ANSWER: Perspective shifts: Bird (plea) → Hunter (internal crisis) → Hunter (external command). Camera shifts: Bird's eye → Hunter's mind → Hunter's hand. Power shifts: Hunter dominant → Hunter trapped by society → Bird's fate suspended. Single-stanza form = real-time pressure.

## WORKED_EXAMPLE_3
PROBLEM: Compare the narrative structures of both poems to argue how Vadde Kanshi uses *structural contrast* to deepen the theme of resistance. Write a 150-word analytical paragraph using PEEL structure.

STEPS:
- Step 1: Point – State the thesis: The two poems form a structural diptych where macro-history (Poem 1) and micro-ethics (Poem 2) mirror each other's unresolved tension.
- Step 2: Evidence 1 (Poem 1) – Cite structural feature: Two stanzas, historical sweep, missing resolution. "बोस कूं नैकूं" ends on action, not outcome.
- Step 3: Evidence 2 (Poem 2) – Cite structural feature: Single stanza, real-time dialogue, suspended climax. "यदि मैं उसे मार डालूँ" freezes at decision.
- Step 4: Explanation – Connect structures: Both deny closure. Poem 1 denies historical closure (revolt continues); Poem 2 denies moral closure (choice remains). The first uses *ellipsis* (skipping time), the second uses *expansion* (stretching a moment) – opposite techniques, same effect: keeping resistance alive in the present.
- Step 5: Link – Conclude: The poet refuses the comfort of "happy ending" or "tragic ending"; the open structures demand the reader continue the resistance in their own reading act.
- Step 6: Polish – Ensure terminology (ellipsis, expansion, diptych, closure) is used precisely; check PEEL flow.

REASONING: This example combines structural analysis of both poems (synthesis) with academic writing skills (PEEL), mirroring Board exam long-answer requirements.

ANSWER: (Sample paragraph) Vadde Kanshi engineers a structural diptych where Poem 1's historical ellipsis – compressing centuries into two stanzas and halting at the climax of revolt – mirrors Poem 2's scenic expansion – stretching a hunter's hesitation into a single unbroken stanza that freezes at the moment of choice. Both poems weaponize *non-closure*: the first denies historical resolution (the revolt's outcome is unwritten), the second denies moral resolution (the bird's fate is unsealed). Poem 1 uses macro-temporal gaps to suggest resistance is perennial; Poem 2 uses micro-temporal intensity to suggest resistance is an eternal *now*. Together, they argue that structural openness is the only honest form for a struggle that refuses to be archived as "past".

## COMPETENCY_QUESTION_1
QUESTION: The first poem is often called a "peasant epic in miniature". Using specific structural evidence (stanza division, temporal shifts, narrative voice), explain how the poem achieves epic scope within just two stanzas.

COMPETENCY: Literary Analysis – Structural Reasoning

STEPS:
- Step 1: Define "epic scope" in structural terms: vast time, collective protagonist, high stakes, elevated style.
- Step 2: Map Poem 1's structure onto these: Stanza 1 = vast time (generations) + collective voice (बाफिंज़ा). Stanza 2 = specific hero (Vadde Kanshi) + high stakes (land/life) + elevated Braj diction.
- Step 3: Identify the structural pivot: The shift from generic "बाफिंज़ा" (Stanza 1) to named "वद्दे" (Stanza 2) compresses the epic convention of "catalogue of heroes" into a single name representing the collective.
- Step 4: Note the missing epic element: *Resolution*. Classical epics end with order restored; this ends with order shattered. That *absence* is the modernist epic gesture.

ANSWER: The poem achieves epic scope through structural compression: Stanza 1 establishes the cosmic/collective scale (timeless oppression of बाफिंज़ा) using habitual aspect; Stanza 2 introduces the singular hero (वद्दे) who embodies the collective, enacting the epic 'aristeia' (heroic exploit) in the confrontation with the king. The shift from third-person generic to named protagonist mirrors the epic zoom from army to Achilles. Crucially, the poem *omits* the epic resolution (restoration of dharma), ending instead at the climax of rebellion – a structural refusal that redefines the epic for a colonized people: the struggle *is* the epic, not its victory.

DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: A critic claims: "The second poem fails as a narrative because it has no plot – just a static dialogue." Refute or defend this claim using narratological concepts (inciting incident, rising action, climax, character agency, narrative desire). Your answer must reference specific structural moments in the poem.

COMPETENCY: Critical Evaluation – Argumentation with Textual Evidence

STEPS:
- Step 1: Define "plot" vs "story" (E.M. Forster): Plot = causal chain, not just sequence. "The king died, then the queen died of grief" is plot.
- Step 2: Identify the causal chain in Poem 2: Bird trapped (situation) → Bird pleads (action) → Hunter calculates (internal reaction) → Hunter faces social threat (complication) → Hunter chooses mercy/inaction (climax of inaction). Each step causes the next.
- Step 3: Analyze "character agency": Bird *acts* through speech (rhetorical agency). Hunter *acts* through deliberation (moral agency). The unseen "society" acts through threat (structural agency). Agency is distributed, not absent.
- Step 4: Address "narrative desire": The poem's desire is *not* "will the bird die?" but "will the hunter reclaim humanity?" The climax answers this: he *cannot* act freely. That is a plot outcome.
- Step 5: Conclude: The poem has a dense plot of *moral psychology*; the critic mistakes external action for the only plot form.

ANSWER: The claim confuses *external event plot* with *internal moral plot*. The poem's inciting incident is the trap (pre-text); rising action is the bird's threefold plea (appeal to kinship, home, mercy); climax is the hunter's realization that his agency is nullified by social surveillance ("कोई देख ले / छीन ले जाए"); falling action is his command to fly – an act of resistance *against* the structure. The causal chain is: plea → conscience → fear → compromised mercy. The hunter's *inability* to kill is the plot's resolution: a tragedy of constrained agency. The static dialogue *is* the dynamic plot of a man losing his soul in real time. The critic reads for events; the poem writes ethics.

DIFFICULTY: hard