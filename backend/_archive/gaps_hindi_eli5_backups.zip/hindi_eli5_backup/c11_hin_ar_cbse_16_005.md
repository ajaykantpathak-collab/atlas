## DEFINITION
Character analysis of supporting characters in poetry involves examining the personified entities, addressees, and collective voices that surround the speaker, analyzing how their vulnerabilities, roles, and symbolic functions reinforce the poem's central concern. In "वक्ष, फेयद्ज़ चप्किं", supporting characters include the implied listener (the "you" addressed), the rural community ("we"), and the personified elements of nature and agrarian life (soil, night, sun, deer, crops, farmers) that are invoked as fragile beings needing protection.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student can identify at least three distinct supporting characters/groups in the poem, cite specific lines where they appear, explain what each represents in the rural context, and articulate how their collective portrayal builds the poem's argument for protecting a vanishing way of life.

## SCOPE_BOUNDARY
This node covers identification and analysis of supporting characters in the poem "वक्ष, फेयद्ज़ चप्किं" only. It does NOT cover the protagonist/speaker (covered in node c11_hin_ar_cbse_16_004), themes (nodes 006-007), literary devices (nodes 008-009), or comprehension questions (node 012).

## WALKTHROUGH
Imagine you're watching a village elder speaking to a young migrant leaving for the city: "Before you go, promise me you'll protect these things," and then he lists the soil, the night, the crops, the farmers. That's exactly what this poem does. Start by asking: "Who is the speaker talking TO, and WHO or WHAT is he talking ABOUT?" First, mark every direct address ("वक्ष", "चप्किं") and every noun that receives the action of covering/protecting. Notice how the list expands from natural elements (soil, night, sun) to animals (deer, bulls) to human activities (ploughing, hunger, laughter). Each item is a "supporting character" representing a facet of rural existence. The key insight: these aren't random images—they form a complete ecosystem of village life that the poem argues is endangered and worth collective protection.

## DIAGNOSTIC_QUESTION_1
In the poem "वक्ष, फेयद्ज़ चप्किं", who is the primary addressee of the speaker's appeal, and what grammatical form indicates this address?

## DIAGNOSTIC_ANSWER_1
The primary addressee is an implied listener/companion addressed as "वक्ष" (come) and "चप्किं" (let's cover - first person plural imperative), indicating a collective call to action. A wrong answer (e.g., identifying the poet as speaking to himself, or to God) reveals the student misses the communal/collective dimension of the appeal and the grammatical marker of shared responsibility in "चप्किं" (let us cover).

## DIAGNOSTIC_QUESTION_2
Explain in your own words why the poet includes both natural elements (like मिट्टी, रात, धूप) and human activities (like ह्क्र्ज, क्स्र्क्स, फेह) in the same list of things to be protected.

## DIAGNOSTIC_ANSWER_2
The poet blends nature and human life because in an agrarian society they are inseparable: the soil feeds the crops the farmer ploughs, the night cools the bulls that pull the plough, the sun ripens the grain that becomes food. A wrong answer treating them as separate categories shows the student hasn't grasped the poem's ecological worldview where human survival is woven into natural cycles—a core concept for Class 11 rural sociology links.

## DIAGNOSTIC_QUESTION_3
Apply the concept of "personification as supporting character" to the line "ह्क्र्ज की व्क्स, ऋकु्क की म्क्ज्ह". What human vulnerability is projected onto the deer and the season, and why does this matter for the poem's argument?

## DIAGNOSTIC_ANSWER_3
The deer's fear (व्क्स) and the season's fragility (म्क्ज्ह) are projected human anxieties: the deer represents innocent life threatened by habitat loss, the season represents the predictable natural cycles farmers depend on. This matters because it expands "protection" from human concerns to the entire biosphere. A wrong answer that treats these as mere decorative images misses how personification makes ecological crisis emotionally immediate—a key analytical skill for board exams.

## DIAGNOSTIC_QUESTION_4
Analyze how the progression from concrete nouns (मिट्टी, रात, धूप) to abstract nouns (ओक्य्ग्क्म्ह, व्द्क्मिउ, त्क>क:िउ) in the list of things to be covered changes the poem's emotional and intellectual demand on the reader.

## DIAGNOSTIC_ANSWER_4
The shift moves the appeal from protecting tangible, visible things (soil, night) to protecting intangible human experiences (helplessness, the act of covering, the urge to understand). This deepens the poem from a conservation plea to a philosophical defense of rural consciousness itself. A wrong answer that only lists the nouns without analyzing the abstract-concrete trajectory shows inability to track structural progression—a skill tested in 6-mark board questions.

## DIAGNOSTIC_QUESTION_5
Evaluate the effectiveness of the final stanza's shift to first-person plural ("हमारे", "हम") after the extended list of third-person entities. Does this strengthen or weaken the poem's call to collective action? Justify.

## DIAGNOSTIC_ANSWER_5
It strengthens the call by making the speaker and addressee part of the very fabric they've been asked to protect—they ARE the "क्प्प्स-ल्ह मेह्न" (laughing-crying together) and "क्प्प्स-ल्स लिउस" (taking laughter-crying). The shift from "cover IT" to "cover US" closes the distance between protector and protected. A wrong answer calling it a mere pronoun change misses the rhetorical climax where the community recognizes its own vulnerability—a sophisticated evaluation expected in competency-based questions.

## DIAGNOSTIC_QUESTION_6
Create a four-line stanza in the same style that adds a modern rural vulnerability (e.g., migrating youth, drying wells, chemical farming) to the poem's list, maintaining the rhythm and the imperative "वक्ष, फेयद्ज़ चप्किं" frame.

## DIAGNOSTIC_ANSWER_6
A strong answer will mirror the poem's noun+postposition+verb pattern (e.g., "सूखे कुएँ की प्यास / बंजर खेत की साँस / उजड़े गाँव की आस / वक्ष, फेयद्ज़ चप्किं") and connect the new vulnerability to an existing poem element. A poor answer that just writes a generic slogan reveals inability to internalize the poem's structural logic and linguistic texture—the highest creative competency.

## COMMON_MISCONCEPTION
Students often think "supporting characters" in a poem must be named human figures like in a story. They list only "the farmer" or "the deer" and miss that the poem's supporting cast includes abstract conditions (helplessness, understanding), collective voices ("हम"), and the addressee ("you"). This error comes from applying prose character-analysis templates to lyric poetry where "character" = any entity granted agency, vulnerability, or symbolic weight by the text.

## ON_FAILURE
1. Ask the student to reread the poem marking every noun that follows "चप्किं" (explicit or implied). 2. Have them sort these into: natural elements, animals, human roles, abstract states, and pronouns. 3. For each category, ask: "What happens to the poem's argument if this category is removed?" 4. Guide them to see that the poem's power comes from the TOTALITY of the list—each "character" is a thread in the rural fabric. Use the analogy of a jute rope: each fiber (supporting character) is weak alone, but together they make the rope that binds the community.

## BUILDS_ON
c11_hin_ar_cbse_16_004 (Character Analysis: Protagonist) where students learned to analyze the speaker's voice, stance, and relationship to the rural world.

## LEADS_TO
c11_hin_ar_cbse_16_006 (Theme: Primary Theme and Message) where the collective portrait of supporting characters becomes evidence for the theme of endangered rural wholeness.

## PREREQUISITE_NODE_IDS
c11_hin_ar_cbse_16_001, c11_hin_ar_cbse_16_002, c11_hin_ar_cbse_16_003, c11_hin_ar_cbse_16_004
## PREREQUISITE_REASONS
c11_hin_ar_cbse_16_001: Provides biographical/historical context (poet's rural upbringing, teacher-parents, economic hardship) that explains WHY these specific supporting characters matter to the poet.
c11_hin_ar_cbse_16_002: Establishes the poem's list-like narrative structure—essential for seeing how supporting characters accumulate stanza by stanza.
c11_hin_ar_cbse_16_003: Sets the agrarian setting (वक़्सोक्ल्ह लेख) whose elements (soil, night, crops) become the supporting characters.
c11_hin_ar_cbse_16_004: Analyzes the protagonist/speaker whose protective impulse creates the very frame that gathers the supporting characters.

## FORWARD_NODE_IDS
c11_hin_ar_cbse_16_006, c11_hin_ar_cbse_16_007, c11_hin_ar_cbse_16_008, c11_hin_ar_cbse_16_013, c12_hin_a_cbse_16_005, c12_hin_ar_cbse_06_005

## FORWARD_REASONS
c11_hin_ar_cbse_16_006: The primary theme (protection of rural wholeness) is built directly from the cumulative portrait of supporting characters analyzed here.
c11_hin_ar_cbse_16_007: Secondary themes (ecological balance, collective memory, language as preservation) emerge from specific supporting character groups.
c11_hin_ar_cbse_16_008: Imagery and metaphor (e.g., "मिट्टी का रंग" as identity, "उफ्न" as warmth) are the linguistic clothing of the supporting characters.
c11_hin_ar_cbse_16_013: Critical interpretation of the poem's socio-political argument requires the character-map built in this node.
c12_hin_a_cbse_16_005: Class 11 introduced foil, confidant, and symbolic function — the analytical vocabulary needed here.  
c12_hin_ar_cbse_06_005: Class 11 foundation on supporting character analysis in Aroh.  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
No prior class nodes available for cross-subject links.

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_16_004 -> c11_hin_ar_cbse_16_005 -> c11_hin_ar_cbse_16_006

## THIS_FORMULA
N/A - conceptual

## FORMULA_VARIABLES
N/A

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
conceptual

## CROSS_SUBJECT
c11_history_rural_society | The poem's supporting characters (farmers, bulls, plough, crops) map directly onto historical transformations in Indian agrarian society—colonial land revenue, commercialization, and post-independence Green Revolution—that History Chapter "Peasants and Farmers" covers.
c11_geography_agrarian_life | The natural elements invoked as characters (soil, night, sun, seasons) correspond to Geography's "Land Resources and Agriculture" chapter on how climate, soil types, and cropping patterns shape rural livelihoods.
c11_economics_rural_economy | The vulnerabilities listed (hunger, helplessness, migration implied by "उजड़े गाँव") connect to Economics' "Rural Development" chapter on poverty, credit, and non-farm employment.
c11_civics_community_rights | The collective "हम" and call to "चप्किं" (protect together) reflects Civics' "Local Governments" chapter on Gram Sabha's role in protecting community resources and cultural heritage.

## PREREQ_CONCEPT
Understanding that in lyric poetry, "character" extends beyond human figures to any entity the text endows with vulnerability, agency, or symbolic weight—and that the speaker's relationship to these entities structures the poem's argument.

## PREREQ_BEFORE
Student must be able to distinguish the speaker (protagonist) from the addressee and the listed entities, and recognize the poem's imperative structure ("वक्ष, फेयद्ज़ चप्किं") as the frame that gathers the supporting characters.

## PREREQ_STUCK
Review the protagonist analysis (node 004) focusing on the speaker's protective stance, then reread the poem asking "What all things does the speaker want US to protect?"—list them without filtering for "human-ness".

## WORKED_EXAMPLE_1
PROBLEM: Identify and analyze the "addressee" as a supporting character in the poem. What textual evidence defines this character, and what role does it play in the poem's communal argument?
STEPS:
- Step 1: Locate all direct addresses in the poem. The opening "वक्ष, फेयद्ज़ चप्किं" uses first-person plural imperative ("चप्किं" = let us cover), establishing the addressee as a partner in collective action, not a passive listener.
- Step 2: Note the absence of a named individual—the addressee is "you" as any member of the community, making the appeal universal within the rural collective.
- Step 3: Track how the addressee's role expands: from co-protector of concrete things (stanza 1-2) to co-bearer of abstract vulnerabilities (stanza 3: "हमारे इक्ल्य", "हमारे इक्व") to co-inhabitant of the final shared emotional space ("क्प्प्स-ल्ह मेह्न", "क्प्प्स-ल्स लिउस").
- Step 4: Contrast with the protagonist (speaker): the speaker initiates, but the addressee completes the "we". Without the addressee's implied acceptance, the call remains individual; with it, it becomes communal pledge.
- Step 5: Connect to the poem's central argument: the addressee represents the POSSIBILITY of collective resistance to cultural erasure. The poem doesn't just describe loss—it stages the formation of a protecting "we".
REASONING: This analysis moves beyond "who is spoken to" to "what function the addressee serves in the poem's argumentative architecture"—exactly what board examiners reward in 6-mark character-analysis questions.
ANSWER: The addressee is the unnamed, universalized community member whose implied consent transforms the speaker's individual plea into a collective covenant. Textual markers: plural imperative "चप्किं", final merger into "हमारे/हम". Role: co-agent of preservation, without whom the poem's call to action collapses into mere lament.

## WORKED_EXAMPLE_2
PROBLEM: Analyze how the group "किसान/हलवाहे" (farmers/ploughmen) functions as a supporting character despite appearing only once explicitly ("हल चलाने के लिये हल") and once implicitly ("खाने के लिये अन्न").
STEPS:
- Step 1: Identify the two explicit mentions: "हल चलाने के लिये हल" (plough for ploughing) and "खाने के लिये अन्न" (grain for eating). Both are purpose-clauses where the farmer is the implied agent.
- Step 2: Map the farmer's invisible presence across the list: the soil is their medium, the night their rest, the sun their clock, the bulls their partners, the crops their creation, the wool their winter, the hunger their risk, the laughter/crying their life.
- Step 3: Recognize the synecdoche: "हल" (plough) stands for the entire agricultural labor system—knowledge, rhythm, intergenerational skill. "अन्न" stands for the food sovereignty the poem defends.
- Step 4: Analyze the vulnerability: the farmer appears only through tools and needs, never as a subject with voice. This silence IS the characterization—they are the ones most endangered, most in need of being "covered" by language.
- Step 5: Link to the poet's biography (node 001): the poet, son of teachers but rooted in this world, gives voice to this silence. The farmer-supporting-character is the poem's moral center—unspoken, essential, vanishing.
REASONING: This demonstrates how to analyze a character who is structurally central but textually marginal—a sophisticated skill for analyzing subaltern voices in literature, directly relevant to CBSE's competency focus on marginalized perspectives.
ANSWER: The farmer is the absent center—the supporting character whose labor connects every other element in the list. Their characterization through tools (plough) and needs (grain) rather than speech or action mirrors their historical invisibility. The poem's act of listing what they need protected IS the act of making them visible.

## WORKED_EXAMPLE_3
PROBLEM: Compare the functioning of "नैसर्गिक पात्र" (natural entities: मिट्टी, रात, धूप, हिरन, ऋतु, फसल, ऊन, बैल) and "मानवीय अवस्थाएँ" (human conditions: असहायता, ढकने की इच्छा, समझने की इच्छा, भूख, रोना, पीना, लिखना, पढ़ना, बोलना, हँसना-रोना) as two tiers of supporting characters. How does their interplay create the poem's ecological worldview?
STEPS:
- Step 1: Categorize the list into Tier 1 (natural/biological entities, stanzas 1-2) and Tier 2 (human experiences/activities, stanza 3). Note the grammatical parallelism: both tiers use "के लिये" (for the sake of) structure.
- Step 2: Analyze Tier 1 as the LIFE-SUPPORT SYSTEM: each entity is a condition of possibility for agrarian existence. Soil = medium, night = recovery, sun = energy, deer = biodiversity indicator, season = temporal order, crop = yield, wool = shelter, bull = labor power.
- Step 3: Analyze Tier 2 as the MEANING-MAKING SYSTEM: helplessness (vulnerability), covering (care), understanding (knowledge), hunger (need), crying/drinking (bodily life), writing/reading/speaking (cultural transmission), laughing-crying together (shared affect).
- Step 4: Trace the CAUSAL CHAIN: Tier 1 degradation CAUSES Tier 2 erosion. No soil → no crop → hunger. No season → failed harvest → helplessness. No bull → no plough → lost skill → lost language (writing/reading/speaking).
- Step 5: Identify the BRIDGE ENTITIES: "बैल" (bull) is both biological entity and labor partner; "ऊन" (wool) is both animal product and human shelter; "फसल" (crop) is both plant and food. These hybrids embody the nature-culture continuum the poem defends.
- Step 6: Conclude: The poem's ecological worldview is not "nature for nature's sake" but "nature as the substrate of a specific human way of being." Protecting Tier 1 IS protecting Tier 2. The supporting characters are not two groups but one continuum.
REASONING: This multi-step comparison models the "analyze relationships between textual elements" competency that appears in CBSE's 5-6 mark questions requiring integration of textual evidence with conceptual framework.
ANSWER: The two tiers form a single ecological continuum where natural entities are the material preconditions for human experiences. The poem's genius is using parallel syntax ("के लिये") to equate protecting a season with protecting the urge to understand—both are "covering" acts. The hybrid entities (bull, wool, crop) are the textual sites where this unity is most visible. This interplay IS the poem's argument: rural life is not humans IN nature but humans AS nature.

## COMPETENCY_QUESTION_1
QUESTION: The poem lists "लिखने के लिये, पढ़ने के लिये, बोलने के लिये" (for writing, for reading, for speaking) among things to protect. Using evidence from the poem's supporting characters, explain why LANGUAGE itself becomes an endangered species in the rural world the poem depicts.
COMPETENCY: Textual evidence-based reasoning connecting character analysis to thematic implication
STEPS:
- Step 1: Identify where language acts appear (stanza 3: "लिखने के लिये, पढ़ने के लिये, बोलने के लिये").
- Step 2: Recall which supporting characters embody oral/literary tradition: the speaker (poet-teacher lineage), the addressee (listener who must receive), the collective "हम" (community that speaks together).
- Step 3: Connect to natural supporting characters that sustain language: "मिट्टी का रंग" (metaphor for rooted vocabulary), "बैल" (whose rhythms shape work-songs), "फसल" (whose cycles structure seasonal narratives).
- Step 4: Argue that when the natural characters die (soil degrades, bulls replaced by tractors, crops monocultured), the vocabulary, rhythms, and occasions for rural language vanish—making language a casualty of ecological loss.
ANSWER: Language is endangered because its material and social substrate—the supporting characters of soil, bull, crop, collective labor, shared laughter-crying—is being destroyed. The poem places "लिखने/पढ़ने/बोलने" in the same protective frame as "मिट्टी/रात/धूप" because they are co-dependent: no rural world, no rural language. The poet's own journey (village to university to poetry) embodies this fragility.
DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: A critic claims: "The poem's supporting characters are romanticized symbols, not realistic portrayals of rural suffering." Evaluate this claim by analyzing how the poem's character-list balances vulnerability and agency, using at least three specific supporting characters as evidence.
COMPETENCY: Critical evaluation integrating textual analysis with interpretive judgment
STEPS:
- Step 1: Define the critic's terms: "romanticized" = aestheticized, stripped of pain/power; "realistic" = showing suffering AND capacity to act.
- Step 2: Select three supporting characters: (a) "भूख" (hunger) - raw vulnerability, no agency; (b) "हल/किसान" (plough/farmer) - agency through labor, but vulnerability through dependence on nature; (c) "हँसना-रोना साथ-साथ" (laughing-crying together) - agency in collective affect, vulnerability in shared grief.
- Step 3: For each, cite textual positioning: "भूख" appears in a purpose clause ("खाने के लिये अन्न") showing it as a NEED to be met, not a metaphor. "हल" appears as tool-for-action ("चलाने के लिये"), emphasizing agency. "हँसना-रोना" appears in the final "हम" space, showing community's emotional resilience.
- Step 4: Synthesize: The list INCLUDES unromantic suffering (hunger, helplessness) AND labor-agency (plough, sowing, speaking) AND collective resilience (shared affect). It refuses both pity-only and heroism-only frames.
- Step 5: Conclude: The critic is partially right that the poem uses symbolic compression, but wrong that it ignores suffering or agency. The supporting characters collectively portray a "vulnerable agency" that is the poem's realistic core.
ANSWER: The claim fails because the supporting-character list explicitly includes non-romantic suffering (भूख, असहायता), labor-based agency (हल, बोना, काटना), and collective emotional resilience (हँसना-रोना साथ-साथ). The poem's realism lies in showing vulnerability and agency as co-present in the same characters—e.g., the farmer who ploughs (agency) but needs grain to survive (vulnerability). This "vulnerable agency" is the poem's anti-romantic core.
DIFFICULTY: hard