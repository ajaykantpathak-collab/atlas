## DEFINITION
Vocabulary in Context refers to the skill of determining the precise meaning of words as they are used in a specific passage, rather than relying solely on dictionary definitions. It involves analyzing surrounding sentences, tone, and grammatical cues to infer nuanced meanings of key terms.

## COGNITIVE_LEVEL
understand

## MASTERY_CRITERIA
The student can independently identify unfamiliar words in the chapter, explain their contextual meanings with textual evidence, and use each word correctly in an original sentence that reflects the same nuance.

## SCOPE_BOUNDARY
This node covers only the key vocabulary listed in the NCERT chapter "izse?ku dh Nk;k&Le`fr" (e.g., mRoaQBk, vko`r, yrk&izrku, ifj.kr, eq[rkj, veyk, okfdI+kQ, oØrk, ifjikVh, viHkza'k, fpÙkkd"kZd). It does not cover grammar rules, literary devices, comprehension questions, or writing skills — those are addressed in sibling nodes.

## WALKTHROUGH
Imagine you are reading a Hindi newspaper editorial and encounter the word "viHkza'k". You don't have a dictionary handy. How do you figure out what it means? You look at the words around it — "izkÑr Hkk"kkvksa dk ijorhZ :i" — and notice the formal tone. That's context clue hunting. In this node, we'll practice that exact skill on the chapter's 11 key words. First, we locate each word in the text. Next, we read the two sentences before and after it. Then we ask: "What role does this word play here — is it describing a person, a feeling, a place?" We match our guess to the glossary meaning given at the end of the chapter. Finally, we write our own sentence using the word in the same sense. This step-by-step habit turns passive reading into active vocabulary building.

## DIAGNOSTIC_QUESTION_1
What is the primary strategy for determining the meaning of a word in context?

## DIAGNOSTIC_ANSWER_1
The primary strategy is to examine the surrounding sentences — context clues such as synonyms, antonyms, examples, or grammatical structure — to infer the word's meaning in that specific usage. A wrong answer (e.g., "look it up in a dictionary immediately") reveals the student relies on external aids instead of developing independent inference skills, which is exactly what board exams test in unseen passages.

## DIAGNOSTIC_QUESTION_2
In the phrase "pkSèkjh lkgc osQ O;fDrRo dks crkus osQ fy, ikB esa oqQN e”ksnkj okD; vk, gSa", what does "e”ksnkj" likely mean, and which context clue helps you decide?

## DIAGNOSTIC_ANSWER_2
"e”ksnkj" means "descriptive" or "illustrative". The clue is the phrase "crkus osQ fy," (to describe) and "okD; vk, gSa" (sentences have come/are given) — the sentences serve to depict the personality. A wrong answer like "difficult" shows the student ignored the purpose clause and guessed from word shape alone.

## DIAGNOSTIC_QUESTION_3
The word "fpÙkkd"kZd" appears in the sentence: "jkr dks izk;% jkepfjrekul vkSj jkepafnzdk] ?kj osQ lc yksxksa dks ,d=k djosQ cM+s fpÙkkd"kZd <ax ls i<+k djrs Fks". Using context, explain what "fpÙkkd"kZd" conveys here.

## DIAGNOSTIC_ANSWER_3
"fpÙkkd"kZd" means "heart-touching" or "emotionally moving". The context shows the father reading aloud to the family ("?kj osQ lc yksxksa dks ... i<+k djrs Fks") and the description "cM+s fpÙkkd"kZd <ax ls" modifies the manner of reading — it evokes deep feeling. A student who answers "loud" or "fast" misses the emotional cue "fpÙk" (heart) embedded in the word.

## DIAGNOSTIC_QUESTION_4
Compare the use of "oØrk" in the glossary ("Vs<+kiu] oqQfVyrk") with its likely contextual meaning in a sentence like "mudh ckrphr dk <ax muosQ ys[kksa osQ <ax ls ,dne fujkyk gksrk Fkk". How does context refine the dictionary definition?

## DIAGNOSTIC_ANSWER_4
The glossary gives "restlessness, instability". In context, "oØrk" describes a quality of the conversation ("ckrphr dk <ax") that is "fujkyk" (unique/different) from the writing style — implying a spontaneous, flowing, perhaps slightly unstructured liveliness. Context narrows "instability" to "natural spontaneity in speech". A wrong answer that sticks only to "restlessness" fails to see the positive connotation added by "fujkyk" and the comparison to writing.

## DIAGNOSTIC_QUESTION_5
A student claims "viHkza'k" and "ukxj" are synonyms because both relate to language. Evaluate this claim using the glossary definition and the sentence "ukxj viHkza'k ls tks f'k"V yksxksa dh Hkk"kk fodflr gqbZ] ogh ukxjh dgykbZA".

## DIAGNOSTIC_ANSWER_5
The claim is false. "viHkza'k" is defined as "the standard form of developed languages which is considered the origin of ancient Indian languages" — a linguistic ancestor. "ukxj" means "dialect" or "vernacular". The sentence says the author wrote in the vernacular ("ukxj") that evolved from the standard ("viHkza'k"). They are in a source–derivative relationship, not synonyms. A student calling them synonyms confuses category with instance.

## DIAGNOSTIC_QUESTION_6
Create an original Hindi sentence using "yrk&izrku" that shows you understand its contextual meaning of "yearning for love / intense longing". The sentence must reflect a situation different from the chapter.

## DIAGNOSTIC_ANSWER_6
Example: "dqN o"kZ ckn] tc og vius fnol ij vk;k] mldk yrk&izrku os us mls ekurs ls vyx cgqr nksgjk fn;kA" (Years later, when he returned on his birthday, his longing for love made him embrace his mother very tightly.) A poor answer would use the word as a simple noun ("yrk&izrku gS") without showing the emotional intensity or the "yearning" aspect.

## COMMON_MISCONCEPTION
Students often treat the glossary meanings as fixed definitions and apply them mechanically to every occurrence. For example, they see "mRoaQBk" defined as "ykylk] cspSuh" and assume it always means "deeply affectionate". In the chapter, however, "mRoaQBk" describes the author's attachment to Premchand ("esjh fdruh mRoaQBk jgh gksxh") — it carries a tone of reverent devotion mixed with nostalgia, not just generic affection. This error happens because students memorize word–meaning pairs instead of analyzing how context shades meaning.

## ON_FAILURE
1. Have the student re-read the specific paragraph where the word appears, highlighting all adjectives and verbs within two sentences of the target word. 2. Ask: "What feeling or action is the author describing right here?" 3. Match that feeling to the glossary option that fits best. 4. Practice by writing two sentences: one using the word in the chapter's sense, one using a different sense (if possible). 5. Re-attempt Diagnostic Question 4 with a new word from the list.

## BUILDS_ON
Class 11 Vocabulary in Context nodes (e.g., c11_hin_ar_cbse_01_010) where students learned basic context-clue strategies.

## LEADS_TO
c12_hin_a_cbse_10_011 (Grammar: Language Usage in the Text) — precise vocabulary understanding is needed to analyze grammatical nuances.

## PREREQUISITE_NODE_IDS
c11_hin_ar_cbse_01_010, c11_hin_ar_cbse_02_010, c11_hin_ar_cbse_03_010, c12_hin_a_cbse_10_001, c12_hin_a_cbse_10_002, c12_hin_a_cbse_10_007

## PREREQUISITE_REASONS
c11_hin_ar_cbse_01_010: Introduced context-clue identification in Class 11 Antra Chapter 1.
c11_hin_ar_cbse_02_010: Reinforced vocabulary inference in a different prose piece.
c11_hin_ar_cbse_03_010: Provided practice with nuanced words in a third context.
c12_hin_a_cbse_10_001: Gives background on the author and era, essential for understanding archaic/formal word choices.
c12_hin_a_cbse_10_002: Familiarity with the plot ensures the student knows the narrative situation where each word appears.
c12_hin_a_cbse_10_007: Key vocabulary (fuLlansg, mnwZ csxe, ¯gnh 'kCn lkxj) are thematic keywords requiring contextual unpacking.  

## FORWARD_NODE_IDS
c12_hin_a_cbse_10_011, c12_hin_a_cbse_10_012, c12_hin_a_cbse_10_013, c12_hin_a_cbse_10_014

## FORWARD_REASONS
c12_hin_a_cbse_10_011: Grammar analysis requires exact word meanings to discuss syntax and register.
c12_hin_a_cbse_10_012: Comprehension questions often hinge on interpreting key vocabulary correctly.
c12_hin_a_cbse_10_013: Critical interpretation builds on precise lexical understanding to evaluate themes.
c12_hin_a_cbse_10_014: Vocabulary in Context provides the precise literary terminology (e.g., प्रवर्तक, पोषक, सौष्ठव) required for high-mark answers  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
c12_english_vocabulary_context: English Core also tests vocabulary in context in unseen passages; the inference strategy is identical.
c12_history_historical_terminology: Historical texts use archaic terms (like "viHkza'k") whose meaning shifts over time — same context-dependency skill.

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_01_010 -> c12_hin_a_cbse_10_010 -> c12_hin_a_cbse_10_011

## THIS_FORMULA
N/A - conceptual

## FORMULA_VARIABLES
N/A

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
linguistic

## CROSS_SUBJECT
N/A | Both subjects require inferring word meaning from surrounding text in unseen passages; the cognitive process (identify clues -> infer -> verify) is identical.
 N/A | Historical sources contain outdated terms (e.g., "viHkza'k") whose meaning must be reconstructed from context, just like literary Hindi words.
## PREREQ_CONCEPT
Ability to identify context clues (synonyms, antonyms, examples, grammatical role) in a Hindi sentence.

## PREREQ_BEFORE
Student must be comfortable reading Hindi prose at Class 12 level and using a Hindi–Hindi dictionary.

## PREREQ_STUCK
Review the "Context Clue Types" table from c11_hin_ar_cbse_01_010 and practice on five unfamiliar words from any Hindi newspaper editorial.

## WORKED_EXAMPLE_1
PROBLEM: Determine the contextual meaning of "eq[rkj" in the sentence: "ogk¡ vfèkdrj odhy] eq[rkjksa rFkk dpgjh osQ vI+kQljksa vkSj veyksa dh cLrh Fkh" and use it in a new sentence showing the same nuance.
STEPS:
- Step 1: Locate "eq[rkjksa" in the sentence — it appears in a list with "vfèkdrj odhy" (intellectual debates), "dpgjh" (profound), "vI+kQljksa" (complexities), "veyksa" (sorrows).
- Step 2: Note the common thread: all are nouns describing heavy, serious, abstract things associated with a "cLrh" (crowd/gathering) of people.
- Step 3: Check glossary: "eq[rkj" = "vfèkdkj izkIr O;fDr] O;fDr fo'ks"k osQ izfrfufèk osQ :i esa dk;Z djus dk vfèkdkjh] ,tsaV" (authoritative person, one who acts as representative of a person's authority).
- Step 4: Realize the glossary gives the literal meaning, but here it's used metaphorically — "eq[rkjksa" likely means "authoritative figures / experts / mentors" who dominate the intellectual atmosphere.
- Step 5: Verify: The phrase "vfèkdrj odhy] eq[rkjksa" pairs debates with authorities — fits perfectly.
- Step 6: Write original sentence: "fo|kfFkZ;ksa dh eq[rkjksa us uo;u dh nwj izfØ;k dks le>k;kA" (The academic authorities understood the new education policy deeply.)
REASONING: The word appears in a metaphorical cluster; the glossary gives the root meaning, but context shifts it to "intellectual authorities". This step-by-step prevents mechanical glossary copying.
ANSWER: Contextual meaning = "intellectual authorities / mentors". Original sentence: "fo|kfFkZ;ksa dh eq[rkjksa us uo;u dh nwj izfØ;k dks le>k;kA"

## WORKED_EXAMPLE_2
PROBLEM: The word "ifj.kr" is glossed as "vU; :i esa cnyk gqvk] ifj.kke ;k :ikarj dks izkIr". In the sentence "16 o"kZ dh voLFkk rd igq¡prs&igq¡prs rks leo;Ld ¯gnh&izsfe;ksa dh ,d [kklh eaMyh eq>s fey xbZ] ftuesa ... ifj.kr gqbZ Fkh", explain the shift from the glossary meaning to the contextual meaning.
STEPS:
- Step 1: Read the sentence — "16 o"kZ dh voLFkk rd ... leo;Ld ¯gnh&izsfe;ksa dh ,d [kklh eaMyh eq>s fey xbZ] ftuesa ... ifj.kr gqbZ Fkh".
- Step 2: Identify the subject: "eaMyh" (group/atmosphere) has become "ifj.kr".
- Step 3: Glossary says "changed into another form, indicating transformation or configuration".
- Step 4: Context: The group of scholars was not physically transformed; rather, its character/composition evolved into a recognized circle. So "ifj.kr" here means "crystallized / taken definite shape / became established".
- Step 5: The shift is from physical transformation to abstract formation.
- Step 6: Create a sentence showing this abstract sense: "us dke ds fy, dksbZ yojh ifj.kr u gks ikbZA" (No definite plan could be formed for that work.)
REASONING: The glossary gives a broad semantic range; context selects the "formation/establishment" sub-sense. Students must practice this narrowing.
ANSWER: Contextual meaning = "crystallized / took definite shape". The shift is from physical change to abstract establishment. Example sentence: "us dke ds fy, dksbZ yojh ifj.kr u gks ikbZA"

## WORKED_EXAMPLE_3
PROBLEM: A board exam question asks: "Explain how the author uses the word 'veyk' to convey the atmosphere of the gathering." The glossary says "veyk = deZpkjh eaMy" (tense atmosphere). The relevant passage: "veyksa dh cLrh Fkh" (there was a crowd of sorrows). Write a 3-point answer using PEEL structure.
STEPS:
- Step 1: Point — The word "veyk" (sorrow/grief) is used collectively ("veyksa dh cLrh") to show the gathering was not joyous but weighed by shared melancholy.
- Step 2: Evidence — The phrase appears alongside "vfèkdrj odhy, eq[rkjksa, dpgjh osQ vI+kQljksa" — intellectual debates, authorities, complexities — all serious, heavy themes.
- Step 3: Explanation — By pluralizing "veyk" into "veyksa" and calling it a "cLrh" (crowd), the author personifies sorrow as a tangible presence filling the room, suggesting each scholar carried private grief that collectively created a "deZpkjh eaMy" (tense/heavy atmosphere).
- Step 4: Link — This lexical choice reinforces the theme of intellectual burden in pre-independence Hindi literary circles.
- Step 5: Polish into board answer format: (1) Point, (2) Quote "veyksa dh cLrh", (3) Explain personification and pluralization, (4) Connect to theme.
REASONING: Competency questions demand evidence-based analysis. This worked example models the PEEL structure required for 3-mark board questions.
ANSWER: The author uses "veyk" in plural ("veyksa") and as a collective noun ("cLrh") to personify sorrow as a palpable crowd, showing the gathering's atmosphere was heavy with unspoken grief. This supports the theme of intellectuals bearing societal burdens.

## COMPETENCY_QUESTION_1
QUESTION: In the sentence "pkSèkjh lkgc osQ ikl gh ,d ySEi ty jgk FkkA ySEi dh cÙkh ,d ckj HkHkdus yxhA pkSèkjh lkgc ukSdjksa dks vkok”k nsus yxsA", the word "vkok”k" is not in the glossary. Using context clues from this paragraph and the earlier description of Premchand's personality, infer the meaning of "vkok”k" and explain why the author chose this word instead of a simpler synonym like "vkns'k" (order).
COMPETENCY: Vocabulary inference and authorial word choice analysis
STEPS:
- Step 1: Identify the situation — Premchand's lamp chimney breaks; he tells servants to do something.
- Step 2: Note the preceding description of Premchand: "mudh gj ,d vnk ls fj;klr vkSj rch;rnkjh Vidrh Fkh" (nature very gentle and courteous).
- Step 3: "vkok”k" implies a polite but firm directive, consistent with "fj;klr" (gentle) and "Vidrh" (humble). "vkns'k" would imply a harsh command, contradicting his character.
- Step 4: Infer meaning: "polite instruction / courteous direction".
- Step 5: Explain the choice: "vkok”k" preserves the author's portrayal of Premchand's dignity and kindness.
ANSWER: "vkok”k" means a polite, respectful instruction. The author chooses it over "vkns'k" to maintain consistency with Premchand's established gentle and courteous personality.
DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: The chapter uses both "viHkza'k" (standard language) and "ukxj" (vernacular). A competitive exam (CUET) asks: "How does the author's description of Premchand writing in 'ukxj' that evolved from 'viHkza'k' reflect the linguistic ideology of the early 20th century Hindi movement?" Answer in 4-5 sentences using evidence from the text.
COMPETENCY: Interdisciplinary analysis — vocabulary + historical context
STEPS:
- Step 1: Recall the sentence: "ukxj viHkza'k ls tks f'k"V yksxksa dh Hkk"kk fodflr gqbZ] ogh ukxjh dgykbZA".
- Step 2: Define both terms using glossary + context: "viHkza'k" = Sanskritized standard; "ukxj" = people's dialect.
- Step 3: Connect to historical context (from c12_hin_a_cbse_10_001): Early 20th century Hindi movement debated Sanskritized vs. vernacular Hindi.
- Step 4: Premchand's choice to write in the evolved vernacular shows his alignment with making literature accessible — a key ideological stance.
- Step 5: Synthesize: The vocabulary pair encapsulates the tension between elitist and populist language policies; Premchand's practice resolves it by valuing the living dialect.
ANSWER: The author contrasts "viHkza'k" (Sanskritized standard) with "ukxj" (evolved vernacular) to highlight Premchand's conscious choice to write in the people's language. This mirrors the Hindi movement's shift from pandit-dominated Sanskritized Hindi to a language rooted in spoken dialects. By stating Premchand wrote in the "ukxj" that developed from "viHkza'k", the text shows he respected tradition but prioritized accessibility — a core ideological stance of early 20th century Hindi litterateurs.
DIFFICULTY: hard