## DEFINITION
Vocabulary in Context is the skill of determining the precise meaning, connotation, and grammatical function of a word by analyzing its surrounding textual environment—sentence structure, narrative tone, character voice, and thematic resonance—rather than relying solely on dictionary definitions.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student must independently identify 8-10 key words from the chapter, explain how context shifts their literal meaning, and use each word in an original sentence that reflects the story's specific emotional or thematic weight.

## SCOPE_BOUNDARY
This node covers only the vocabulary explicitly listed in the NCERT 'kCn&Nfo' section and words critical to understanding character dynamics in "fe;k¡ ulh#íhu". It does not cover general Hindi vocabulary building, synonyms/antonyms drills, or grammar rules from other chapters.

## WALKTHROUGH
Imagine you're reading a WhatsApp message from a friend: "Bhai, aaj kal tu *ullu* ban gaya hai." You know *ullu* literally means owl, but here it means 'fool'—context changed everything. Now open "fe;k¡ ulh#íhu" at page 22 where the narrator says "fe;k¡ ulh#íhu dks ukuckb;ksa dk elhgk D;ksa dgk x;k gS". The word *ukuckbZ* appears in a heated argument about professional dignity. Step 1: Locate the word in the text. Step 2: Read the full paragraph—who is speaking, to whom, and what triggered this? Step 3: Note the emotional tone (anger? sarcasm? respect?). Step 4: Compare the dictionary meaning ('cook') with the contextual meaning ('someone reduced to a servant'). Step 5: Write one sentence using *ukuckbZ* with this exact contextual weight. This is how board examiners expect you to treat every key word.

## DIAGNOSTIC_QUESTION_1
What is the dictionary meaning of the word 'ukuckbZ' as listed in the NCERT 'kCn&Nfo' section at the end of the chapter?

## DIAGNOSTIC_ANSWER_1
The dictionary meaning given is 'rjg&rjg dh jksVh cukus&cspus dk dke djus okyk' (one who does the work of making various types of bread/rotis). A wrong answer like 'servant' or 'helper' reveals the student is confusing contextual implication with lexical definition—a critical error in board exams where 'kCn&vFkZ' questions demand the exact glossary meaning first.

## DIAGNOSTIC_QUESTION_2
In the sentence "fe;k¡ ulh#íhu us vk¡[kksa osQ oaQps ge ij isQj fn,A" (page 22), the word 'oaQps' is not in the glossary. Using context clues from the surrounding dialogue, explain what 'oaQps' likely means and why the author chose this specific word instead of a simpler synonym like 'nkM+s'.

## DIAGNOSTIC_ANSWER_2
'OaQps' means 'fiercely/sharply/intensely'—describing how Fele Uljhan fixed her gaze on the narrator. The author chose it over 'nkM+s' because 'oaQps' carries a connotation of penetrating scrutiny mixed with suppressed emotion, matching Fele's character as someone who 'sees through' hypocrisy. A wrong answer treating it as merely 'angrily' misses the layered characterization Fele embodies throughout the story.

## DIAGNOSTIC_QUESTION_3
The glossary defines 'v[kckjuohl' as 'i=kdkj' (editorial). On page 24, the character says: "ge rks v[kckj cukusokys vkSj v[kckj i<+usokys nksukas dks gh fuBYyk le>rs gSa". Explain why the author uses the abstract noun 'v[kckjuohl' (editorial-ship/editorial nature) here instead of the concrete 'v[kckj' (editorial), and how this grammatical shift reinforces the theme.

## DIAGNOSTIC_ANSWER_3
The suffix '-ohl' (tatsam abstract noun marker) transforms the concrete task into a professional identity/ethos. The speaker asserts that both makers and readers of editorials share a *professional conscience*—not just a mechanical activity. A student who only translates it as 'editorial work' misses the thematic claim about journalistic integrity that drives the narrator's conflict with Fele.

## DIAGNOSTIC_QUESTION_4
Compare the usage of 'rkyhe' in two sentences from page 24: (1) "rkyhe dh rkyhe gh cM+h ph”k gksrh gS" and (2) "rkyhe 'kCn dk nks ckj iz;ksx D;ksa fd;k gS". Analyze how repetition and syntactic position alter the semantic focus from 'small/little' to 'trivial/insignificant' in the first instance.

## DIAGNOSTIC_ANSWER_4
In (1), the reduplication 'rkyhe dh rkyhe' (the very smallest of the small) + 'gh' (emphatic particle) + 'cM+h ph”k' (big mistake) creates an oxymoronic structure: the *tiniest* thing becomes the *biggest* error. The syntactic framing forces 'rkyhe' to mean 'seemingly trivial but actually consequential'. In (2), it's a meta-linguistic reference to the word itself. Missing this shift leads to flat translations like 'small mistake' in board answers.

## DIAGNOSTIC_QUESTION_5
Evaluate the glossary definition of 'ulhgr' as 'lh[k] f'k{kk' (learning/education). Fele says on page 25: "dke djus ls vkrk gS] ulhgrksa ls ugha". Argue whether 'ulhgr' here means 'formal education' or 'bookish knowledge detached from practice', using at least two other scenes from the story as evidence.

## DIAGNOSTIC_ANSWER_5
It means 'bookish knowledge detached from practice'. Evidence: (1) Fele mocks the narrator's inability to recognize a 'ckn'kkg lyker' despite his degrees (page 25). (2) She contrasts her practical skill ("jksVh idkus dk bYe") with his theoretical "bYe" (page 22). The glossary's 'f'k{kk' is the *dictionary* meaning; Fele weaponizes the *contextual* meaning to expose class prejudice. An answer citing only the glossary fails the 'analysis' requirement.

## DIAGNOSTIC_QUESTION_6
Create an original 3-sentence mini-dialogue between two Class 11 students discussing a school event, correctly using *three* words from the chapter's glossary (e.g., 'eksgyr', 'yegk Hkj', 'ctk I+kQjekuk') in a way that preserves their contextual flavor from "fe;k¡ ulh#íhu".

## DIAGNOSTIC_ANSWER_6
Student A: "Yaar, *eksgyr* nikal gaya taiyari ka, ab *yegk Hkj* se stage pe jaana padega." Student B: "Tension mat le, *ctk I+kQjekar* de dena—'Maine toh sirf duty nibhai hai, baaki sab aap logon ka pyaar hai.'" Good answer: each word carries its story-weight (*eksgyr*=anxious waiting, *yegk Hkj*=forced confidence, *ctk I+kQjekuk*=diplomatic face-saving). Poor answer uses them as mere synonyms for 'time', 'walk', 'speak well'.

## COMMON_MISCONCEPTION
Students treat the 'kCn&Nfo' glossary as the *final authority* on word meaning. They memorize 'ukuckbZ = cook' and write in exams: "Fele called the narrator a cook." This ignores that in the story's sociolect, 'ukuckbZ' functions as a caste-class slur implying 'menial servant'. The glossary gives *denotation*; the text builds *connotation* through tone, speaker identity, and power dynamics. Board questions like "fe;k¡ ulh#íhu dks ukuckb;ksa dk elhgk D;ksa dgk x;k gS" (Q1, vH;kl) demand the *contextual* reason, not the dictionary meaning.

## ON_FAILURE
Step 1: Take the glossary word 'ukuckbZ'. Step 2: Find its *every* occurrence in the story (pages 22, 24, 25). Step 3: For each, note: Speaker → Listener → Triggering Event → Emotional Charge. Step 4: Make a 3-column table: Dictionary Meaning | Contextual Meaning | Evidence Phrase. Step 5: Practice the board answer template: "Yahan 'ukuckbZ' ka arth 'bawarchi' nahi, balki 'ghar ka naukar samjha jane wala insaan' hai kyunki..." Repeat for 5 glossary words.

## BUILDS_ON
c11_hin_ar_cbse_02_002 (Text: Plot and Narrative Structure) — you must know *when* and *why* a word is spoken to analyze its contextual weight.

## LEADS_TO
c11_hin_ar_cbse_02_012 (Comprehension: Literal and Inferential Questions) — vocabulary-in-context answers form the evidence base for inferential responses.

## PREREQUISITE_NODE_IDS
c11_hin_ar_cbse_02_001, c11_hin_ar_cbse_02_002, c11_hin_ar_cbse_02_004, c11_hin_ar_cbse_02_009

## PREREQUISITE_REASONS
c11_hin_ar_cbse_02_001: Context/background knowledge tells you Fele is a marginalized woman—essential to decode words like 'ulhgr' as class-coded.
c11_hin_ar_cbse_02_002: Plot structure reveals *which* scene a word appears in (climax vs. exposition changes meaning).
c11_hin_ar_cbse_02_004: Protagonist analysis shows Fele's voice is subversive—she reclaims words like 'ukuckbZ' ironically.
c11_hin_ar_cbse_02_009: PROBLEM: Combine vocabulary analysis with irony (c11_hin_ar_cbse_02_009). The word 'ctk I+kQjekuk' (glossary: 'Bhd ccr dguk' — to speak well/pleasantly) appears on page 27 when Fele says: "  

## FORWARD_NODE_IDS
c11_hin_ar_cbse_02_011, c11_hin_ar_cbse_02_012, c11_hin_ar_cbse_02_014, c11_hin_ar_cbse_02_013, c11_hin_ar_cbse_02_015, c12_hin_a_cbse_01_010, c12_hin_a_cbse_07_010, c12_hin_a_cbse_08_010, c12_hin_a_cbse_10_010, c12_hin_a_cbse_11_010, c12_hin_a_cbse_12_010, c12_hin_a_cbse_17_010, c12_hin_al_cbse_02_010, c12_hin_ar_cbse_02_010, c12_hin_ar_cbse_12_010

## FORWARD_REASONS
c11_hin_ar_cbse_02_011: Grammar node requires identifying word-class shifts (e.g., 'v[kckjuohl' as abstract noun) learned here.
c11_hin_ar_cbse_02_012: Comprehension answers need contextual vocabulary as textual evidence.
c11_hin_ar_cbse_02_014: Writing tasks (character sketch, theme essay) demand precise, context-aware word choice.
c11_hin_ar_cbse_02_013: Vocabulary precision (e.g., ukuckbZ, v[kckjuohl) determines accurate thematic labeling.  
c11_hin_ar_cbse_02_015: Vocabulary (uxhuklk”k, ehuklk”k, v[kckjuohl) equips students with precise analytical terminology for spoken arguments.  
c12_hin_a_cbse_01_010: Practised distinguishing शब्दार्थ vs भावार्थ in Class 11 poems — prerequisite for connotation analysis here.  
c12_hin_a_cbse_07_010: Practiced identifying context clues for unfamiliar words in narrative texts.  
c12_hin_a_cbse_08_010: Reinforces vocabulary skills across multiple Class 11 chapters, building transferable habit.  
c12_hin_a_cbse_10_010: Reinforced vocabulary inference in a different prose piece.  
c12_hin_a_cbse_11_010: अगला तार्किक चरण: Vocabulary in Context: इस नोड की अवधारणाओं को सीधे उपयोग/विस्तारित करता है।  
c12_hin_a_cbse_12_010: Practiced context-clue strategy on shorter texts.  
c12_hin_a_cbse_17_010: Practiced *tatsam/tadbhav* distinction in autobiographical prose — directly applicable to Deshpande's style.  
c12_hin_al_cbse_02_010: Practice in contextual meaning extraction from memoir/autobiographical texts.  
c12_hin_ar_cbse_02_010: Provides the foundational framework for denotation/connotation/register analysis that this node deepens. c12_hin_ar_cbse_02_001: Context/background node gives the Iraq War historical framing essential for interpreting words like "लकड़सुंघनी" (sanctions-era fuel scarcity). c12_hin_ar_cbse_02_002: Plot/narrative structure node identifies the poem's three sections (memory, destruction, aftermath) which map onto the vocabulary clusters (domestic → war → ruin). c12_hin_ar_cbse_02_008: Imagery/Metaphor node establishes the fire/light/darkness imagery system that the key vocabulary (ढिबरी, चिमनी, भभूका, राख) operationalizes.  
c12_hin_ar_cbse_12_010: Practiced context-clue application on narrative texts — direct predecessor skill.  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
none

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_02_002 -> c11_hin_ar_cbse_02_010 -> c11_hin_ar_cbse_02_012

## THIS_FORMULA
Contextual Meaning = Dictionary Meaning + (Speaker Identity × Power Dynamic) + (Syntactic Position × Emotional Tone) + (Thematic Resonance × Narrative Placement)

## FORMULA_VARIABLES
- Dictionary Meaning: Glossary definition from NCERT 'kCn&Nfo'
- Speaker Identity: Who utters the word (Fele, narrator, Lekhak, etc.)
- Power Dynamic: Social hierarchy between speaker and listener
- Syntactic Position: Word order, repetition, modifiers (e.g., 'rkyhe dh rkyhe')
- Emotional Tone: Anger, sarcasm, tenderness, irony
- Thematic Resonance: Connection to dignity, labor, prejudice, hypocrisy
- Narrative Placement: Opening, conflict, climax, resolution

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
linguistic

## CROSS_SUBJECT
c11_english_core_literature | Analyzing connotation vs. denotation in "The Portrait of a Lady" (Khushwant Singh) where 'grandmother' shifts from kinship term to symbol of fading tradition—identical skill to decoding 'ukuckbZ' in Fele Uljhan.
c11_sociology_indian_society | Understanding how language encodes caste/class hierarchy (e.g., 'chamar' as slur vs. occupational term) parallels Fele's weaponization of 'ukuckbZ' and 'ulhgr' to expose the narrator's blind privilege.

## PREREQ_CONCEPT
Ability to distinguish denotation (dictionary meaning) from connotation (contextual/emotional meaning) in Hindi literary texts.

## PREREQ_BEFORE
Student must have read the full story "fe;k¡ ulh#íhu" at least once and marked every glossary word in the text with a pencil.

## PREREQ_STUCK
Re-read the 'Before You Read' (c11_hin_ar_cbse_02_001) section on Nirmal Verma's focus on urban alienation and class—this frames why vocabulary carries socio-political weight.

## WORKED_EXAMPLE_1
PROBLEM: Analyze the word 'ejgwe' (glossary: 'ftldh e`R;q gks pqdh gks' — deceased) in the sentence on page 25: "okfyn lkfgc us lh[k osQ rkSj ij oqQN rks dgk gksxk" spoken by Fele about the narrator's father. Explain why Fele uses 'ejgwe' instead of 'svargiya' or 'mar gaye' and what this reveals about her worldview.

STEPS:
- Step 1: Locate the exact sentence on page 25: Fele says "vki tkuks tc cPpk mLrkn osQ ;gk¡ i<+us cSBrk gS rks mLrkn dgrk gS... dgks HkkbZ ehj lkfgc! lqcg u vkuk gqvk] ij D;ksa\" — wait, 'ejgwe' appears in the glossary but the text uses 'lqcg u vkuk gqvk'. Cross-check: the glossary entry 'ejgwe' likely corresponds to 'lqcg u vkuk' (not alive anymore) or similar phrasing in the narrative.
- Step 2: Identify speaker (Fele), listener (narrator), context (discussing narrator's father's absence during his childhood).
- Step 3: Note Fele's sociolect—she uses direct, unadorned language ('dke djus ls vkrk gS', 'ulhgrksa ls ugha'). 'Ejgwe' is a formal/legal term (from Persian 'wajah' via Urdu), often used in official records.
- Step 4: Contrast with alternatives: 'svargiya' (respectful, religious), 'mar gaye' (blunt, crude), 'lqcg u vkuk' (euphemistic). Fele chooses a term that is *factually precise but emotionally neutral*—like a record-keeper.
- Step 5: Connect to theme: Fele refuses sentimental hypocrisy. The narrator's class uses 'svargiya' to mask neglect; Fele uses 'ejgwe' / 'lqcg u vkuk' to state bare truth. Her vocabulary *is* her resistance.

REASONING: This 5-step close reading moves from textual location → speaker stance → lexical register → contrastive analysis → thematic synthesis. Board answers require this full chain, not just 'ejgwe means dead'.

ANSWER: Fele uses 'ejgwe' (or its textual equivalent 'lqcg u vkuk') to strip death of ritualistic reverence, exposing the narrator's father's physical absence as a concrete fact—not a sacred memory. This aligns with her philosophy: "dke djus ls vkrk gS, ulhgrksa ls ugha" — reality lies in action/presence, not in learned rituals of mourning. The word choice reinforces her role as the story's moral compass who cuts through middle-class pretension.

## WORKED_EXAMPLE_2
PROBLEM: The glossary defines 'yegk Hkj' as '{k.kHkj' (proud/stiff walk). On page 26, the narrator describes Fele: "fe;k¡ ulh#íhu gekjh vksj oqQN ,sls ns[kk fd, fd mUgsa gels tokc ikuk gksA fiQj cM+s gh e¡ts vank”k esa dgkµ^dgus dk eryc lkfgc ;g fd rkyhe dh rkyhe Hkh cM+h ph”k gksrh gSA*" Immediately after, Fele walks away. Analyze how 'yegk Hkj' *could* describe her exit, and why the narrator *avoids* using it despite the glossary pairing.

STEPS:
- Step 1: Verify glossary entry: 'yegk Hkj — ,d izdkj dh jksVh tks :eky dh rjg cM+h vkSj cgqr iryh gksrh gS' (a swing that rises high and is very loose). Wait—this defines 'yegk Hkj' as a *swing*, not a walk! The glossary has a metaphorical entry.
- Step 2: Re-read page 26 action: Fele turns away after her final truth-bomb. The narrator watches her leave.
- Step 3: Apply the *metaphor*: A 'yegk Hkj' (high, loose swing) moves with momentum, unrestrained, reaching height then falling freely—no rigid control. Fele's departure has this energy: unapologetic, sweeping, untethered to the narrator's expectations.
- Step 4: Analyze narrator's avoidance: He *feels* the metaphor but cannot articulate it—his 'ulhgr' (bookish language) fails him. He only manages "cM+s gh e¡ts vank”k" (very softly). The glossary gives him the word *retrospectively*; in the moment, he lacks the vocabulary for her dignity.
- Step 5: Board-level insight: The gap between *experiencing* a contextual meaning and *possessing* the word for it is the story's central tragedy.

REASONING: This example teaches students to cross-reference glossary definitions with *actual textual usage*—sometimes the glossary explains a metaphor the character *embodies* but the narrator *cannot name*. This meta-awareness scores high in 'Critical Thinking' questions.

ANSWER: 'Yegk Hkj' (the high, loose swing) metaphorically captures Fele's exit—uncontrolled, soaring, defying the narrator's gravity. The narrator avoids the term because his educated vocabulary ('ulhgr') cannot grasp her raw authenticity; he only whispers. The glossary entry exists *for the reader*, not the narrator, highlighting the irony that the 'uneducated' Fele lives the metaphor the 'educated' narrator can only later label.

## WORKED_EXAMPLE_3
PROBLEM: Combine vocabulary analysis with irony (c11_hin_ar_cbse_02_009). The word 'ctk I+kQjekuk' (glossary: 'Bhd ccr dguk' — to speak well/pleasantly) appears on page 27 when Fele says: "ctk I+kQjek;k gS] ij ;g rks crkb, gh crkb, fd tc vki... bl dke ij yxs rks okfyn lkfgc us lh[k osQ rkSj ij oqQN rks dgk gksxk". Identify the *double irony* in Fele using this phrase while confronting the narrator.

STEPS:
- Step 1: Define 'ctk I+kQjekuk' literally: to speak pleasingly/diplomatically, often insincerely.
- Step 2: Identify Speaker: Fele (marginalized, blunt). Listener: Narrator (privileged, evasive). Context: Fele demands he admit what his father *would have said* to her.
- Step 3: First Irony (Situational): Fele—who supposedly lacks 'ulhgr' and 'ctk I+kQjekuk'—uses the *exact phrase* 'ctk I+kQjekuk' correctly and strategically to trap the narrator. She weaponizes his vocabulary.
- Step 4: Second Irony (Performative): She *performs* 'ctk I+kQjekuk' ("ctk I+kQjek;k gS] ij...") — speaking politely *while* delivering a brutal truth. The form (pleasant speech) contradicts the content (accusation).
- Step 5: Contrast with Narrator: He *has* the education for 'ctk I+kQjekuk' but fails to use it honestly. He earlier "iapg”kkjh vank”k ls flj fgyk;k" (spoke sharply in feigned anger) — false 'ctk I+kQjekuk'.
- Step 6: Thematic Synthesis: The word 'ctk I+kQjekuk' becomes a site of class struggle. Fele reclaims it as *truth-telling tool*; the narrator exposes it as *evasion tactic*.

REASONING: This 6-step analysis integrates vocabulary-in-context (this node) with irony (sibling node 009). Board competency questions increasingly demand such cross-conceptual synthesis. The steps model: Definition → Context → Irony Layer 1 → Irony Layer 2 → Counter-example → Theme.

ANSWER: Fele's use of 'ctk I+kQjekuk' carries double irony: (1) The 'uneducated' cook deploys the sophisticated term more precisely than the 'educated' narrator, exposing his hollow 'ulhgr'. (2) She performs 'pleasant speech' *while* stripping the narrator of his pretensions—her 'ctk I+kQjekuk' is a surgical knife, not a social lubricant. The word thus crystallizes the story's central inversion: true dignity lies in Fele's blunt honesty, not the narrator's polite evasions.

## COMPETENCY_QUESTION_1
QUESTION: A board exam question asks: "fe;k¡ ulh#íhu ne 'uxhuklk”k' (uxhuk tM+us okyk) aur 'ehuklk”k' (ehukdkjh djus okyk) jaise shabdon ka prayog kyon kiya? Spast kijiye." Using the glossary definitions and two specific scenes from the story, write a 4-point structured answer following the PEEL format (Point, Evidence, Explanation, Link).

COMPETENCY: Contextual vocabulary analysis with structured answer writing (PEEL)

STEPS:
- Step 1: Recall glossary: 'uxhuklk”k' = one who breaks fast; 'ehuklk”k' = one who causes pain. Note both are agentive nouns in '-lk”k' (doer of action).
- Step 2: Locate Scene 1 (p. 24): Fele describes her past—forced to break fast for others' rituals ("vki gh crkb, fd vkiosQ cq”kqxks± us 'kkgh ckophZ[kkus esa rks dke fd;k gh gksxk").
- Step 3: Locate Scene 2 (p. 27): Fele's poem: "ge crZu èkksuk u lh[krs / ge Hkêòh cukuk u lh[krs / Hkêòh dks vk¡p nsuk u lh[krs / rks D;k ge lhèks&lhèks ukuckbZ dk gquj lh[k tkrs\*" — she identifies as one who *endures* ehuk (pain) and *refuses* to be uxhuklk”k (fast-breaker for show).
- Step 4: Draft PEEL: Point = Fele uses these words to contrast performative piety vs. authentic suffering. Evidence = Scene 1 (uxhuklk”k as forced role) + Scene 2 (ehuklk”k as lived reality). Explanation = The '-lk”k' suffix makes them identity labels; Fele rejects the first, owns the second. Link = This vocabulary choice embodies the story's theme: dignity in labor, not ritual.

ANSWER: Fele employs 'uxhuklk”k' and 'ehuklk”k' to expose the hypocrisy of ritualistic religiosity versus genuine human suffering. (Point) In the flashback (p. 24), she recalls how the narrator's family forced her to break fasts ('uxhuk tM+us') for their ceremonies while denying her basic dignity—making 'uxhuklk”k' a label of *imposed servility*. Later (p. 27), her poem declares: "ge crZu èkksuk u lh[krs... rks D;k ge lhèks&lhèks ukuckbZ dk gquj lh[k tkrs" — claiming 'ehuklk”k' (pain-endurer) as her *true* identity earned through labor. (Evidence) The agentive suffix '-lk”k' transforms acts into identities: she refuses the identity of a ritual prop ('uxhuklk”k') and asserts the identity of a worker who bears real pain ('ehuklk”k'). (Explanation) This lexical precision crystallizes the story's core message: a society that values 'ulhgr' (bookish ritual) over 'dke' (actual work) reduces humans to functionaries; Fele's vocabulary reclaims her humanity. (Link)

DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: "Nirmal Verma's 'fe;k¡ ulh#íhu' demonstrates that vocabulary is not a static list but a site of power struggle." Defend this statement by analyzing how *three* glossary words ('ukuckbZ', 'ulhgr', 'v[kckjuohl') shift in meaning depending on *who speaks them* and *at what narrative moment*. Write a response suitable for a 6-mark 'Critical Thinking' question.

COMPETENCY: Multi-word contextual analysis with narrative awareness and thematic synthesis

STEPS:
- Step 1: Select three words with clear speaker shifts: 'ukuckbZ' (narrator/Fele), 'ulhgr' (narrator/Fele), 'v[kckjuohl' (narrator/Lekhak).
- Step 2: Map each word to Speaker A vs. Speaker B + Narrative Moment (Early vs. Late).
- Step 3: For 'ukuckbZ': Narrator (p. 22, early) = neutral job title; Fele (p. 25, climax) = class slur reclaimed as pride ("dke djus ls vkrk gS").
- Step 4: For 'ulhgr': Narrator (p. 22, early) = his degree/privilege; Fele (p. 25, climax) = "ulhgrksa ls ugha" — hollow theory vs. practice.
- Step 5: For 'v[kckjuohl' (p. 24, mid): Narrator = professional identity; Fele = "v[kckj cukusokys vkSj v[kckj i<+usokys nksukas dks gh fuBYyk le>rs gSa" — shared ethical duty *beyond* class.
- Step 6: Synthesize: Each shift marks a power reversal. The 'static' glossary cannot capture this; only contextual tracking reveals vocabulary as contested terrain.

ANSWER: Verma proves vocabulary is a power arena through three pivotal shifts: (1) 'UkuckbZ': The narrator initially uses it as a neutral occupational label (p. 22: "ukuckbZ fe;k¡ dYyu"), but Fele reclaims it at the climax (p. 25) as a badge of productive dignity—"dke djus ls vkrk gS, ulhgrksa ls ugha"—turning the narrator's class marker into her moral superiority. (2) 'Ulhgr': The narrator wears it as cultural capital (his degrees); Fele dismantles it as "ulhgrksa ls ugha" (p. 25), exposing how 'education' blinds him to the 'ckn'kkg lyker' standing before him. The *same word* becomes his shield and her sword. (3) 'V[kckjuohl': Introduced as the narrator's professional domain (p. 24), Fele redefines it as a *shared conscience*—"v[kckj cukusokys vkSj v[kckj i<+usokys nksukas dks gh fuBYyk le>rs gSa"—forcing him to acknowledge her as an equal participant in truth-telling. These shifts occur precisely at narrative turning points (confrontation, revelation, climax), proving that in Verma's world, words are not containers of fixed meaning but weapons in a class war. The glossary freezes the *outcome*; the story reveals the *battle*.

DIFFICULTY: hard