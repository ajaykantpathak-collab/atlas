## DEFINITION
Irony is a literary device where the intended meaning of words or events is opposite to their literal or surface meaning, creating a contrast between expectation and reality. Symbolism is the use of objects, characters, settings, or actions to represent abstract ideas, qualities, or concepts beyond their literal significance, allowing the writer to convey deeper thematic layers.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student must be able to (1) identify specific instances of verbal, situational, and dramatic irony in the chapter and explain how each creates contrast between expectation and reality, and (2) identify at least three symbols in the text, explain their literal and figurative meanings, and connect them to the chapter's central themes of literary legacy, mentorship, and the simplicity of greatness.

## SCOPE_BOUNDARY
This node covers irony and symbolism exclusively in the context of Chapter 10 "izse?ku" (the biographical sketch of Premchand). It does NOT cover imagery and metaphor (covered in node c12_hin_a_cbse_10_008), nor does it address other literary devices like alliteration, personification, or hyperbole. The analysis is limited to the prescribed NCERT text.

## WALKTHROUGH
Imagine you are reading a story where a famous, award-winning author is described as sitting on a broken cot in a modest house, wearing simple clothes, while visitors expect a grand mansion — this jarring contrast is irony at work. Now think of the "broken cot" itself: it's not just furniture; it represents the writer's humility, his connection to ordinary people, and the idea that true greatness needs no ornamentation — that's symbolism. In this chapter, begin by re-reading the text with two colored pens: mark every moment where what is said clashes with what is meant (irony), and circle every object or detail that seems to carry extra weight (symbolism). Ask yourself: "What is the narrator really telling us about Premchand through these contrasts and symbols?" The key insight is that irony reveals character through contradiction, while symbolism reveals theme through representation — both require you to read between the lines, not just on them.

## DIAGNOSTIC_QUESTION_1
Define verbal irony, situational irony, and dramatic irony with one example each from everyday life (not from the textbook).

## DIAGNOSTIC_ANSWER_1
Verbal irony: saying "What beautiful weather!" during a violent storm — the speaker means the opposite. Situational irony: a fire station burning down — the outcome contradicts the expected function of the place. Dramatic irony: in a horror movie, the audience knows the killer is behind the door but the character does not — the audience has knowledge the character lacks. A wrong answer (e.g., confusing situational irony with mere coincidence, or thinking verbal irony is just sarcasm) reveals the student cannot distinguish the structural basis of each type: verbal relies on speaker intent, situational on outcome vs. expectation, dramatic on audience vs. character knowledge.

## DIAGNOSTIC_QUESTION_2
In the chapter, the narrator describes Premchand's house as having a "broken cot" (टूटी खाट) and "modest surroundings" while also noting he was a celebrated writer. Explain why this is situational irony, not just a description of poverty.

## DIAGNOSTIC_ANSWER_2
It is situational irony because there is a sharp contradiction between the external expectation (a famous, respected writer should live in comfort or grandeur) and the actual reality (he lives simply with a broken cot). The irony deepens when we learn this simplicity was a conscious choice, not compulsion — Premchand *could* have lived differently but chose not to. A wrong answer that calls this "just a fact about his poverty" misses the structural contrast between *public stature* and *private simplicity* that the narrator deliberately constructs to reveal Premchand's values. The student who misses this fails to see irony as a crafted literary device, not an accidental circumstance.

## DIAGNOSTIC_QUESTION_3
The narrator mentions the term "फुल्लनसग" (phullansag) used by the literary circle to describe themselves. Identify the type of irony here and explain how it functions as a self-deprecating label that actually reveals the group's genuine passion for literature.

## DIAGNOSTIC_ANSWER_3
This is verbal irony — the term "फुल्लनसग" (literally "idle/nonsensical people" or "good-for-nothings") is used *ironically* by the group to label themselves. On the surface, it sounds self-mocking or dismissive, but in context, it signals their deep, almost obsessive engagement with literature: they meet regularly, discuss works intensely, and take writing seriously. The irony functions as a bonding mechanism — only insiders understand the term is a badge of honor disguised as insult. A wrong answer that takes the label literally (e.g., "they called themselves useless") shows the student cannot detect tone and context-dependent meaning, a critical skill for Board unseen passages and CUET comprehension.

## DIAGNOSTIC_QUESTION_4
Analyze the "broken cot" (टूटी खाट) as a symbol in the chapter. What does it literally represent, and what three abstract ideas does it symbolize? Connect each to a specific detail from the text.

## DIAGNOSTIC_ANSWER_4
Literally: a damaged, low-quality sleeping cot in Premchand's house. Symbolically: (1) **Humility despite greatness** — the narrator notes Premchand's national fame but chooses this detail to show he didn't perform status; (2) **Connection to the common man** — the cot is like those in any poor household, symbolizing his refusal to distance himself from the people he wrote about; (3) **Literary authenticity over material comfort** — the narrator contrasts this cot with the "grandeur" visitors expected, implying his real wealth was his writing. A weak answer lists only one meaning or gives generic symbols ("simplicity," "poverty") without textual anchoring — this fails the Board requirement of "evidence-based interpretation."

## DIAGNOSTIC_QUESTION_5
Evaluate the narrator's statement: "Premchand wrote in the language of the common man, yet scholars now study him in air-conditioned rooms." Is this an effective use of irony to critique the institutionalization of literature? Justify your position with two arguments.

## DIAGNOSTIC_ANSWER_5
Yes, it is effective situational irony. Argument 1: The contrast between the *origin* of Premchand's language (streets, villages, oral storytelling) and its *current site of study* (elite academic spaces) exposes how literature can be detached from its living source. Argument 2: The irony implicates the reader — we are likely those "scholars in AC rooms" — forcing self-reflection on whether we honor the *spirit* or just the *text*. A "No" answer is acceptable only if it argues the irony is heavy-handed or clichéd, *with textual support*. A weak answer ("yes it's good" without analysis) shows the student cannot evaluate literary technique — a skill tested in Board competency questions and CUET critical reasoning.

## DIAGNOSTIC_QUESTION_6
Write a 4-line paragraph describing a teacher you admire, using *one* symbol and *one* instance of situational irony to reveal their character without directly stating adjectives like "kind" or "brilliant."

## DIAGNOSTIC_ANSWER_6
Sample: "Ma'am Sharma's chalk-stained fingers — her only jewelry — trace equations on a cracked blackboard in a classroom where the AC has never worked. Students from the neighboring elite school sneak in to attend her free Saturday sessions, while her own school's toppers skip them for coaching classes." Symbol: chalk-stained fingers = dedication made visible. Situational irony: the "less privileged" classroom attracts the "privileged" students. A poor answer uses direct adjectives ("She is kind and brilliant") or includes symbol/irony but doesn't integrate them to *show* character — revealing the student still thinks "describing" equals "listing traits."

## COMMON_MISCONCEPTION
Students consistently confuse **symbolism** with **imagery** — they think any vivid description (e.g., "the room smelled of old paper and ink") is a symbol. In this chapter, they label the "ink-stained fingers" or "Hindi dictionary" as symbols *without* explaining what abstract idea each represents. The error stems from treating "symbol" as a synonym for "important detail" rather than "a concrete thing standing for an abstract concept." For example, Premchand's *dictionary* is literally a book; it becomes a symbol *only* when linked to "the bridge between classical tradition and modern expression" or "the democratization of language." Without that conceptual leap, it's just imagery. This mistake costs marks in Board 3-markers where "identify and explain the symbol" requires the *interpretive step*, not just the *identification step*.

## ON_FAILURE
Step 1: Re-read the chapter *only* for concrete objects (cot, dictionary, pen, chair, room, clothes). List them. Step 2: For each, ask: "What *idea* does this object carry beyond its function?" Write the idea in one phrase (e.g., cot → "chosen simplicity"). Step 3: Verify each with a textual anchor — find the sentence where the narrator *reflects* on the object, not just describes it. Step 4: Revisit node **c12_hin_a_cbse_10_008** (Imagery and Metaphor) and complete its Diagnostic Questions 3 and 4 — the distinction between "image as sensory detail" and "image as symbol" is explicitly taught there. Step 5: Re-attempt Diagnostic Question 4 above. If still stuck, ask your teacher for the "Symbol vs. Imagery" sorting worksheet used in Class 11 (node **c11_hin_ar_cbse_01_008**).

## BUILDS_ON
This node builds on **c12_hin_a_cbse_10_008** (Literary Devices: Imagery and Metaphor) where students learned to distinguish sensory description from figurative meaning — a prerequisite for identifying symbols that *use* imagery but transcend it.

## LEADS_TO
This node enables **c12_hin_a_cbse_10_013** (Critical Thinking: Analysis and Interpretation) where students synthesize irony, symbolism, imagery, and theme into full-length analytical answers for Board and CUET.

## PREREQUISITE_NODE_IDS
c12_hin_a_cbse_10_008, c11_hin_ar_cbse_01_009, c11_hin_ar_cbse_02_009, c11_hin_ar_cbse_03_009, c11_hin_ar_cbse_04_009, c11_hin_ar_cbse_05_009, c11_hin_ar_cbse_06_009, c11_hin_ar_cbse_07_009, c11_hin_ar_cbse_08_009, c11_hin_ar_cbse_09_009, c11_hin_ar_cbse_10_009, c11_hin_ar_cbse_11_009, c11_hin_ar_cbse_12_009, c11_hin_ar_cbse_13_009, c11_hin_ar_cbse_14_009, c11_hin_ar_cbse_15_009, c11_hin_ar_cbse_16_009, c11_hin_v_cbse_01_009, c11_hin_v_cbse_02_009, c11_hin_v_cbse_03_009, c11_hin_v_cbse_04_009, c11_hin_v_cbse_05_009, c12_hin_a_cbse_10_007, c11_hin_ar_cbse_01_008

## PREREQUISITE_REASONS
c12_hin_a_cbse_10_008: Imagery and Metaphor node teaches the sensory-to-figurative bridge essential for recognizing symbols that begin as images.
c11_hin_ar_cbse_01_009: Class 11 Antra Chapter 1 introduced irony/symbolism basics with simpler texts — foundational definitions and identification practice.
c11_hin_ar_cbse_02_009: Chapter 2 applied irony/symbolism to a different genre (poetry) — shows device versatility across forms.
c11_hin_ar_cbse_03_009: Chapter 3 used symbolism in a historical narrative — builds context for biographical symbolism here.
c11_hin_ar_cbse_04_009: Chapter 4 focused on verbal irony in dialogue — directly relevant to narrator's self-deprecating labels.
c11_hin_ar_cbse_05_009: Chapter 5 analyzed situational irony in character arcs — prepares for Premchand's life-as-irony structure.
c11_hin_ar_cbse_06_009: Chapter 6 explored dramatic irony in narrator-reader gaps — key for this chapter's reflective narration.
c11_hin_ar_cbse_07_009: Chapter 7 linked symbols to cultural memory — relevant for Premchand as cultural icon.
c11_hin_ar_cbse_08_009: Chapter 8 practiced multi-symbol tracking — needed for this chapter's cot/dictionary/pen cluster.
c11_hin_ar_cbse_09_009: Chapter 9 connected irony to authorial intent — critical for evaluating narrator's choices.
c11_hin_ar_cbse_10_009: Chapter 10 (Class 11) was a full biographical sketch — direct parallel to this chapter's form.
c11_hin_ar_cbse_11_009: Chapter 11 used irony in satirical writing — shows irony's range beyond biography.
c11_hin_ar_cbse_12_009: Chapter 12 examined symbolism in folk motifs — relevant for Premchand's folk roots.
c11_hin_ar_cbse_13_009: Chapter 13 analyzed irony in epistolic form — expands structural understanding.
c11_hin_ar_cbse_14_009: Chapter 14 traced symbol evolution across a novel — models longitudinal symbolic reading.
c11_hin_ar_cbse_15_009: Chapter 15 combined irony+symbolism in a single essay — direct rehearsal for this node's competency.
c11_hin_ar_cbse_16_009: Chapter 16 was a Board-style practice set — builds exam temperament.
c11_hin_v_cbse_01_009: Vitan Chapter 1 introduced irony in memoir — personal narrative parallel.
c11_hin_v_cbse_02_009: Vitan Chapter 2 used symbolism in travel writing — setting-as-symbol practice.
c11_hin_v_cbse_03_009: Vitan Chapter 3 analyzed dramatic irony in interviews — narrator-subject dynamic.
c11_hin_v_cbse_04_009: Vitan Chapter 4 explored verbal irony in letters — written voice analysis.
c11_hin_v_cbse_05_009: Vitan Chapter 5 synthesized devices in a full memoir — capstone for Class 11.
c12_hin_a_cbse_10_007: Irony and symbolism deepen secondary themes (e.g., father burning books vs. later supporting Hindi lexicon = structural irony).  
c11_hin_ar_cbse_01_008: still stuck, ask your teacher for the "Symbol vs. Imagery" sorting worksheet used in Class 11 (node c11_hin_ar_cbse_01_008).  

## FORWARD_NODE_IDS
c12_hin_a_cbse_10_012, c12_hin_a_cbse_10_013, c12_hin_a_cbse_10_014, c12_hin_a_cbse_10_011

## FORWARD_REASONS
c12_hin_a_cbse_10_012: Comprehension questions require identifying irony/symbolism in inferential answers (e.g., "Why does the narrator emphasize the broken cot?").
c12_hin_a_cbse_10_013: Critical Thinking demands synthesizing irony and symbolism with theme/character for 5-6 mark analytical answers.
c12_hin_a_cbse_10_014: Writing Skills tasks (e.g., "Write a character sketch using symbols") directly apply this node's techniques.
c12_hin_a_cbse_10_011: Irony/Symbolism shows how form carries meaning; this node extends that principle to grammatical form.  

## CROSS_SUBJECT_PREREQS
c11_hin_ar_cbse_01_009, c11_hin_ar_cbse_10_009
## CROSS_SUBJECT_REASONS
c11_hin_ar_cbse_01_009: First exposure to irony/symbolism in Hindi literary analysis — established the metalanguage (विरोधाभास, प्रतीक) used in this node.
c11_hin_ar_cbse_10_009: Class 11 biographical sketch chapter provided the *exact same genre* (writer's life narrated by admirer) — this node deepens that template with Board-level complexity.

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_10_009 -> c12_hin_a_cbse_10_009 -> c12_hin_a_cbse_10_013

## THIS_FORMULA
N/A - conceptual

## FORMULA_VARIABLES
N/A

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
conceptual

## CROSS_SUBJECT
N/A | Premchand's writing emerges from the same nationalist-cultural milieu (1920s-30s) — his symbolism (e.g., the cot as "swadeshi simplicity") reflects historical consciousness; analyzing this connects literary devices to history's "cultural nationalism" theme.
 N/A | The irony of a literary giant living simply mirrors the sociological tension between *achieved status* (writer's fame) and *ascribed lifestyle* (voluntary simplicity) — a case study in status inconsistency and value-driven role performance.
 N/A | Premchand's choice of modest living despite commercial success illustrates "non-monetary utility maximization" — an economics concept where agents optimize for cultural/social capital over income, visible in the text's symbolic details.
## PREREQ_CONCEPT
Distinction between sensory imagery (appealing to five senses) and symbolism (concrete object → abstract idea) — taught in c12_hin_a_cbse_10_008.

## PREREQ_BEFORE
Student must be able to: (1) define the three irony types with non-text examples, (2) explain why a detail becomes a symbol only when linked to an abstract concept, and (3) write a PEEL paragraph (Point-Evidence-Explanation-Link) for a 3-mark Board answer.

## PREREQ_STUCK
If stuck on symbol identification, review the "Image-to-Symbol Ladder" exercise in c12_hin_a_cbse_10_008 Worked Example 2 — it trains the exact cognitive move needed here.

## WORKED_EXAMPLE_1
PROBLEM: The narrator describes Premchand's pen as "an ordinary reed pen (कमल की कलम) that he used for years, refusing fountain pens." Analyze this as a symbol in 4 steps: identify literal object, state symbolic meaning, give textual evidence, connect to theme.

STEPS:
- Step 1: Identify the literal object — a simple reed pen (कमल की कलम), hand-cut, used for years, while fountain pens were available and common among writers of his stature.
- Step 2: Determine the symbolic meaning — the reed pen represents *rootedness in Indian tradition* and *resistance to colonial modernity*; it is not just a tool but a statement of cultural identity.
- Step 3: Locate textual evidence — the narrator notes: "मिक्की थ उनखज दक्स हक्स"क फोड्लर गक्स" (Premchand wrote in the language of the people) and "मिक्की थ उनखज दक्स हक्स"क फोड्लर गक्स" (he wrote in the language of the common man) — the pen is the physical extension of that language choice.
- Step 4: Connect to theme — the pen symbolizes the chapter's central theme: *authenticity over affectation*. Just as Premchand chose the cot over a bed, he chose the reed pen over the fountain pen — both symbols of a writer who measured success by connection to readers, not by tools of status.
- Step 5: Verify against definition — does the reed pen stand for an abstract idea (cultural authenticity, anti-colonial stance, artistic integrity)? Yes. Is this meaning supported by the narrator's commentary? Yes. Is it more than just "he liked old pens"? Yes.

REASONING: This 5-step process (Object → Meaning → Evidence → Theme → Verification) mirrors the Board's expected answer structure for "Explain the significance of..." questions. It forces the student to move from concrete to abstract *with textual proof*, avoiding the "it represents simplicity" vague answer.

ANSWER: The reed pen (कमल की कलम) symbolizes Premchand's commitment to indigenous expression and his rejection of colonial cultural markers. Textually, it parallels his choice of Khari Boli over Sanskritized Hindi and his simple lifestyle — all reflecting the theme that true literary greatness lies in authenticity, not adornment.

## WORKED_EXAMPLE_2
PROBLEM: In the episode where the narrator's father scolds him for reading Premchand instead of "serious" Sanskrit texts, saying "This is the biggest waste of time" — identify the irony type, explain the contrast, and state what it reveals about generational attitudes to Hindi literature.

STEPS:
- Step 1: Identify the irony type — this is **dramatic irony**. The *father* (character) believes Premchand's work is trivial ("waste of time"), but the *narrator* (and reader, who knows Premchand's canonical status) knows it is foundational to modern Hindi literature.
- Step 2: Map the knowledge gap — Father's knowledge: Premchand = popular fiction, not "real" scholarship. Narrator/Reader's knowledge: Premchand = architect of modern Hindi prose, novelist of national significance. The irony exists *because* the audience knows more than the speaker.
- Step 3: Explain the contrast — The father represents the traditional Sanskritized elite for whom "literature" = classical texts; Premchand represents the new, democratic Hindi literature. The father's dismissal is historically ironic — he rejects what history will enshrine.
- Step 4: Connect to generational attitude — This moment encapsulates the *institutional resistance* Hindi faced from classical gatekeepers. The irony is not just personal (father vs. son) but historical: the "waste of time" becomes the *curriculum*.
- Step 5: Link to chapter's broader irony — The narrator later becomes a Hindi professor; the "waste of time" becomes his life's work. The father's words are ironically prophetic in reverse.

REASONING: Dramatic irony is the hardest for students to spot because it requires tracking *two knowledge states* (character vs. audience). This step-by-step mapping (Speaker's Belief vs. Reality Known to Reader) is a transferable heuristic for any dramatic irony question in Board or CUET.

ANSWER: Dramatic irony. The father dismisses Premchand as trivial, but the reader knows Premchand is the founder of modern Hindi fiction. This reveals the generational clash between Sanskritized orthodoxy and the emerging Hindi literary public sphere — the father voices the establishment view that the narrator (and history) will overturn.

## WORKED_EXAMPLE_3
PROBLEM: The chapter contains a cluster of symbols: the **broken cot**, the **reed pen**, the **ink-stained fingers**, and the **Hindi dictionary**. Write a unified analysis showing how these four symbols *together* construct the theme of "greatness in simplicity." Use 6 steps.

STEPS:
- Step 1: List each symbol with its literal referent — Cot: damaged sleeping furniture. Pen: hand-cut reed writing tool. Fingers: permanently stained with ink. Dictionary: well-used, annotated Hindi lexicon.
- Step 2: Assign each a primary symbolic meaning — Cot → voluntary simplicity / identification with the poor. Pen → cultural rootedness / anti-colonial tool choice. Fingers → labor of writing as physical craft / no separation between life and work. Dictionary → language as living practice / scholarship grounded in usage.
- Step 3: Find the *connecting thread* — All four are **deliberate choices**, not impositions of poverty. Premchand *could* have had a bed, fountain pen, clean hands, and academic grammars — he chose these instead. The cluster symbolizes *agency in simplicity*.
- Step 4: Show how the narrator *frames* them — The narrator doesn't just list them; he contrasts each with what a "great writer" supposedly has (grand house, modern pen, manicured hands, Sanskrit dictionary). The irony *creates* the symbolism.
- Step 5: Synthesize into theme statement — "Greatness in simplicity" is not an aesthetic preference but an ethical stance: the writer's authority comes from sharing the reader's condition, not rising above it.
- Step 6: Evaluate the cluster's rhetorical effect — By grouping these symbols, the narrator builds a *cumulative portrait* — no single symbol carries the full weight; together they make the theme undeniable. This is "symbolic density" — a hallmark of biographical sketch as a genre.

REASONING: Board 5-6 mark questions often ask "How do symbols work together to develop a theme?" This 6-step cluster analysis (Inventory → Individual Meaning → Connecting Logic → Narrative Framing → Theme Synthesis → Rhetorical Evaluation) is the exact cognitive scaffold for such answers. It moves beyond "identify symbols" to "analyze symbolic architecture."

ANSWER: The four symbols form a cohesive cluster representing Premchand's ethical-aesthetic philosophy: the cot (lifestyle), pen (medium), fingers (labor), and dictionary (language) — all chosen, not compelled. Their collective contrast with elite alternatives constructs the theme that literary authority derives from solidarity with the common reader, not distinction from them. The narrator uses irony (expectation vs. reality) to activate each symbol's thematic charge.

## COMPETENCY_QUESTION_1
QUESTION: The narrator says: "Premchand wrote for the peasant, but today his books are prescribed for the professor's exam." Identify the irony type, explain the two layers of contrast, and argue whether this irony *strengthens* or *undermines* Premchand's legacy. Support with one textual detail.

COMPETENCY: Critical Analysis and Argumentation (CBSE Competency: "Analyze and evaluate literary devices in context")

STEPS:
- Step 1: Identify irony type — Situational irony (outcome contradicts intention: written for peasants, studied by professors).
- Step 2: Layer 1 contrast — *Intended audience* (peasant, oral culture, lived experience) vs. *Actual institutional audience* (professor, exam, academic abstraction).
- Step 3: Layer 2 contrast — *Language of origin* (colloquial, accessible, spoken) vs. *Language of study* (annotated, theorized, exam-oriented).
- Step 4: Take a position — This irony *strengthens* the legacy because it proves the work's universality: what speaks to the peasant *also* challenges the professor. The text supports this: "हक्स"क फोड्लर गक्स" (he wrote in the language of the people) — the same language now reaches the academy.
- Step 5: Conclude — The irony is not a betrayal but a testament to the work's depth; Premchand would likely smile at this "फुल्लनसग" (good-for-nothing) outcome.

ANSWER: Situational irony with two contrasts: (1) peasant ↔ professor, (2) lived language ↔ academic text. It strengthens the legacy — the work's journey from village chaupal to university syllabus demonstrates its enduring relevance across classes. Textual anchor: "हक्स"क फोड्लर गक्स" shows the language's democratic origin, which the irony now reveals as universally potent.

DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: A CUET-style assertion-reason question:
Assertion (A): The "broken cot" in the chapter functions as a *sustained symbol* rather than a passing image.
Reason (R): The narrator returns to the cot at three distinct narrative moments, each time attaching a new thematic layer (humility, writer's craft, legacy).
Choose the correct option:
(a) Both A and R are true, and R correctly explains A.
(b) Both A and R are true, but R does not explain A.
(c) A is true, R is false.
(d) A is false, R is true.

COMPETENCY: Literary Device Analysis / Assertion-Reason Reasoning (CUET Pattern)

STEPS:
- Step 1: Verify Assertion (A) — A "sustained symbol" recurs and accumulates meaning. Does the cot do this? Yes — mentioned in the house visit, later in the father's memory, and finally in the narrator's reflection.
- Step 2: Verify Reason (R) — Does the narrator return to it thrice with new layers? Text check: (1) First visit: physical description → humility. (2) Father's anecdote: cot as writing space → craft. (3) Ending reflection: cot as monument → legacy. Yes, three moments, three layers.
- Step 3: Check explanatory link — R *explains* A because sustained symbolism *is defined by* recurrence with semantic accretion. The three returns *are* the mechanism of sustenance.
- Step 4: Select option — (a) Both true, R explains A.
- Step 5: Meta-note — This tests the student's ability to distinguish "repetition" from "sustained symbolism" — a Board/CUET differentiator.

ANSWER: (a) Both A and R are true, and R correctly explains A. The cot's three reappearances with deepening meaning (humility → craft → legacy) are the textual mechanism that makes it a sustained symbol rather than a one-time image.

DIFFICULTY: hard