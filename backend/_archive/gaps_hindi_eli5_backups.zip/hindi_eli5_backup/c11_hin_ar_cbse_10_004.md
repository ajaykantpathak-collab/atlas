## DEFINITION
Character analysis of the protagonist involves examining the poet's persona as revealed through his verses—his beliefs, values, tone, and relationship with the divine and society—using textual evidence from the poem and biographical context.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student can write a structured 150-word character sketch of Kabir citing at least two specific lines from the poem and connecting them to his philosophical stance, using the PEEL format (Point, Evidence, Explanation, Link).

## SCOPE_BOUNDARY
This node covers analyzing Kabir's persona as reflected in the prescribed poem (stanza 1) and the introductory biographical note; it does not cover analysis of supporting characters or themes beyond what reveals Kabir's character.

## WALKTHROUGH
Imagine you are asked to introduce Kabir to a friend who has never read him—what would you say beyond "he was a weaver poet"? Start by reading the poem aloud and noticing the direct address to the divine ("fxjèkj xksiky") and the rejection of rituals ("nwljks u dksbZ tk osQ flj eksj&eqoqQV"). Then look at the biographical note: he challenged caste and orthodoxy. Connect the poem's tone of intimate devotion and fearless questioning to his life. The key insight: Kabir's character emerges from the tension between his humble social identity and his uncompromising spiritual authority.

## DIAGNOSTIC_QUESTION_1
What is the primary source for analyzing Kabir's character in this chapter—the biographical note, the poem, or both? Explain in one sentence.

## DIAGNOSTIC_ANSWER_1
Both the biographical note and the poem are primary sources; the note gives historical context (weaver, disciple of Ramananda, iconoclast) while the poem reveals his inner voice, tone, and spiritual stance. A wrong answer that picks only one source shows the student hasn't grasped that character analysis in poetry requires synthesizing external facts with the speaker's own words.

## DIAGNOSTIC_QUESTION_2
In the line "esjs rks fxjèkj xksiky] nwljks u dksbZ tk osQ flj eksj&eqoqQV", what does the phrase "eksj&eqoqQV" suggest about Kabir's attitude toward conventional worship? Answer in your own words.

## DIAGNOSTIC_ANSWER_2
"eksj&eqoqQV" (bell and conch) symbolize ritualistic Hindu worship; Kabir's rejection ("nwljks u dksbZ tk osQ flj") shows he dismisses external rituals as irrelevant to true devotion. A wrong answer that merely translates the words without interpreting the symbolic rejection indicates the student is stuck at literal comprehension and misses the character trait of iconoclasm.

## DIAGNOSTIC_QUESTION_3
Using the PEEL structure, write a four-sentence paragraph showing how the poem's opening line establishes Kabir's relationship with the divine. Use the line "esjs rks fxjèkj xksiky" as evidence.

## DIAGNOSTIC_ANSWER_3
Point: Kabir addresses God as a personal, accessible master. Evidence: "esjs rks fxjèkj xksiky" (my lord is the king of Kashi). Explanation: By calling God "my king of Kashi" he claims an intimate, exclusive bond that bypasses priests and temples. Link: This possessive "esjs" (my) reflects his lifelong assertion of direct access to the divine. A weak answer that omits the "Link" step or fails to connect "esjs" to his biography shows inability to integrate text and context.

## DIAGNOSTIC_QUESTION_4
Compare the Kabir of the biographical note (weaver, social reformer) with the Kabir speaking in the poem (devotee, rebel). What single character trait unifies both portrayals? Justify with one detail from each source.

## DIAGNOSTIC_ANSWER_4
Fearless independence unifies both: the note says he "ges'kk fojksèk fd;k" (broke social and religious shackles) and the poem shows him rejecting ritual symbols ("nwljks u dksbZ tk osQ flj eksj&eqoqQV"). A wrong answer that lists two different traits (e.g., "humble" and "devout") misses the synthesis required at the analysis level.

## DIAGNOSTIC_QUESTION_5
Critique this student statement: "Kabir's character is simply that of a devotee who loves God." Is it sufficient for a Class 11 answer? Why or why not?

## DIAGNOSTIC_ANSWER_5
Insufficient. It ignores his rebellious tone, rejection of rituals, and the socio-historical context of a low-caste weaver challenging orthodoxy. A Class 11 answer must address complexity: Kabir is simultaneously a devotee, a social critic, and a poet who uses vernacular to democratize spirituality. A wrong answer that calls it "good enough" reveals the student equates character analysis with a single adjective.

## DIAGNOSTIC_QUESTION_6
Compose a two-line doha in Hindi (or English) that captures Kabir's character as you understand it from this chapter, using the same rhyme scheme (AABB) as Kabir's dohas.

## DIAGNOSTIC_ANSWER_6
Example: "जुलाहा तन साधु मन, जाति न पूछो कोय / अंतर राम बसे रे, खोलो अपना द्वार।" A good answer mirrors Kabir's vernacular style, contrasts social identity with spiritual essence, and uses the doha meter. A poor answer that writes a generic moral lesson without the tension of identity shows the student hasn't internalized Kabir's unique voice.

## COMMON_MISCONCEPTION
Students often treat Kabir's "I" in the poem as a generic devotee rather than the historical Kabir—missing that his low-caste weaver identity is inseparable from his spiritual authority. They write "Kabir loves God" but omit that his love is a radical act of equality. This happens because they separate the biographical note (history) from the poem (literature) instead of seeing the poem as Kabir's own testimony.

## ON_FAILURE
Step 1: Have the student re-read the biographical note and underline every word describing Kabir's social position (julaha, neech jat, etc.). Step 2: In the poem, circle every first-person pronoun ("esjs", "esjks", "nkfl ehjka") and ask: "Who is speaking? A Brahmin priest? A king? A weaver?" Step 3: Guide them to write one sentence linking the two: "Because Kabir was a weaver considered low-caste, his claim 'my Lord is the king of Kashi' is a political act." Step 4: Assign a fresh PEEL paragraph using this link.

## BUILDS_ON
This node builds on the skill of identifying speaker and tone from the "Setting and Atmosphere" node (c11_hin_ar_cbse_10_003) where students learned how context shapes voice.

## LEADS_TO
This node enables the analysis of supporting characters (c11_hin_ar_cbse_10_005) by establishing the protagonist's worldview against which others (like the priest or the orthodox) are contrasted.

## PREREQUISITE_NODE_IDS
c11_hin_ar_cbse_10_001, c11_hin_ar_cbse_10_002, c11_hin_ar_cbse_10_003
## PREREQUISITE_REASONS
c11_hin_ar_cbse_10_001: Provides historical and cultural context (Bhakti movement, Kabir's background) essential for interpreting the protagonist's social stance.
c11_hin_ar_cbse_10_002: Teaches narrative structure of the poem (stanza progression) so students can locate character-revealing moments.
c11_hin_ar_cbse_10_003: Develops skill in identifying tone and atmosphere, which directly reveals the protagonist's attitude.

## FORWARD_NODE_IDS
c11_hin_ar_cbse_10_005, c11_hin_ar_cbse_10_006, c11_hin_ar_cbse_10_013, c11_hin_ar_cbse_10_007, c11_hin_ar_cbse_10_014, c11_hin_ar_cbse_10_015

## FORWARD_REASONS
c11_hin_ar_cbse_10_005: Supporting characters (orthodox priests, society) are defined by their opposition to Kabir's character established here.
c11_hin_ar_cbse_10_006: Primary theme (nirguna bhakti, social equality) is embodied in the protagonist's character.
c11_hin_ar_cbse_10_013: Critical thinking requires a solid character foundation to evaluate interpretations.
c11_hin_ar_cbse_10_007: Protagonist analysis establishes Meera's agency as the driver of thematic complexity.  
c11_hin_ar_cbse_10_014: Meera as protagonist — her agency, rebellion, spirituality — is the core subject of character-sketch questions.  
c11_hin_ar_cbse_10_015: Protagonist analysis (Kabir as speaker) is the foundation for discussing voice and persona.  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
none

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_10_003 -> c11_hin_ar_cbse_10_004 -> c11_hin_ar_cbse_10_005

## THIS_FORMULA
PEEL Structure for Character Analysis: Point (trait) + Evidence (line from poem/note) + Explanation (how evidence shows trait) + Link (connect to broader context/theme)

## FORMULA_VARIABLES
Point = specific character trait (e.g., iconoclastic, intimate devotion); Evidence = direct quote or paraphrase from text; Explanation = analysis of language/tone; Link = connection to biography, theme, or historical context.

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
analytical

## CROSS_SUBJECT
c11_history_bhakti_movement | Kabir's character reflects the 15th-century Bhakti movement's challenge to caste and ritual; his voice illustrates the social history of religious reform.
c11_sociology_indian_social_structure | Kabir's rejection of caste-based rituals (janeu, temple entry) exemplifies sociological concepts of social stratification and counter-culture.

## PREREQ_CONCEPT
Ability to distinguish between the poet (historical person) and the speaker (poetic persona) and to synthesize both for character analysis.

## PREREQ_BEFORE
Student must know how to identify tone, imagery, and first-person perspective in a poem (from Setting and Atmosphere node).

## PREREQ_STUCK
If stuck, review "Tone and Mood in Poetry" (c11_hin_ar_cbse_10_003) and practice identifying speaker's attitude in a short unseen poem.

## WORKED_EXAMPLE_1
PROBLEM: Analyze how Kabir's self-identification as a "julaha" (weaver) shapes his spiritual authority in the poem's first stanza.
STEPS:
- Step 1: Identify the given—biographical note says Kabir was a julaha; poem uses first-person possessive "esjs" and addresses God directly.
- Step 2: Recall the concept—character analysis requires linking social identity to poetic voice.
- Step 3: Find evidence—note: "ehjk lxq.k /kjk dh egRoiw.kZ HkDr dof;=kh"; poem: "esjs rks fxjèkj xksiky" and "nkfl ehjka yky fxjèkj!".
- Step 4: Analyze—the poem's speaker claims God as his personal king ("esjs") while the note says he was a low-caste weaver; the juxtaposition shows spiritual authority transcending caste.
- Step 5: Interpret—Kabir's character is defined by this paradox: socially marginalized yet spiritually central; the doha form itself (vernacular) enacts this democratization.
REASONING: The steps move from textual details to synthesis, modeling how to avoid the common misconception of separating biography from poem.
ANSWER: Kabir's weaver identity is not background but the source of his spiritual authority; by calling God "my king" in the vernacular of a julaha, he asserts that divine access belongs to the marginalized, making his character a living critique of caste hierarchy.

## WORKED_EXAMPLE_2
PROBLEM: The poem uses domestic metaphors ("ifr lksbZ", "NkafM+ n;h oqQy dh dkfu"). Explain how these metaphors reveal Kabir's character as a householder-saint.
STEPS:
- Step 1: Identify the metaphors—wife ("ifr"), household ("NkafM+"), cooking ("dkfu").
- Step 2: Connect to biographical note—Kabir was a grihastha (householder), not a renunciate.
- Step 3: Analyze tone—the metaphors are affectionate ("lksbZ") and everyday ("oqQy dh dkfu"), showing he finds divinity in ordinary life.
- Step 4: Contrast with orthodox ideal—traditional saints renounce home; Kabir sanctifies it.
- Step 5: Conclude—his character embodies "sahaj" (natural) spirituality: no ritual, no renunciation, just devotion amid daily chores.
REASONING: This example shows how to use metaphor analysis for character, moving beyond literal meaning to thematic significance.
ANSWER: The domestic metaphors reveal Kabir as a saint who refuses the ascetic/householder binary; his character is grounded in the conviction that the divine is accessible in the kitchen, not only in the temple.

## WORKED_EXAMPLE_3
PROBLEM: Write a 120-word board-style answer: "How does Kabir's character emerge from the tension between his social identity and his spiritual voice? Support with two textual references."
STEPS:
- Step 1: Deconstruct the prompt—needs tension, social identity, spiritual voice, two references.
- Step 2: Draft Point—Kabir's character is forged in the tension between his low-caste weaver status and his unmediated claim on the divine.
- Step 3: Select Evidence 1—Biographical note: "ehjk lxq.k /kjk dh egRoiw.kZ HkDr dof;=kh" (weaver by caste).
- Step 4: Select Evidence 2—Poem: "esjs rks fxjèkj xksiky" (my Lord is king of Kashi) + rejection of rituals.
- Step 5: Write Explanation—The possessive "esjs" and the dismissal of "eksj&eqoqQV" show he bypasses Brahminical mediation; his social marginalization becomes spiritual empowerment.
- Step 6: Write Link—This tension is the engine of his poetry: he speaks for all excluded by orthodoxy, making his character a symbol of spiritual democracy.
- Step 7: Assemble using PEEL, check word count, ensure formal Hindi/English as required.
REASONING: This worked example models the full exam answer writing process—planning, evidence selection, PEEL assembly, and polishing.
ANSWER: Kabir's character emerges from the creative tension between his identity as a julaha (weaver), socially deemed low-caste, and his spiritual voice that claims direct ownership of the divine ("esjs rks fxjèkj xksiky"). The biographical note establishes his marginalized position ("lxq.k /kjk dh egRoiw.kZ HkDr"), yet the poem's opening line asserts an intimate, exclusive relationship with God that requires no priest, temple, or ritual ("nwljks u dksbZ tk osQ flj eksj&eqoqQV"). This paradox—social outsider, spiritual insider—defines his iconoclastic character. By speaking in the vernacular of the marginalized, he transforms his personal exclusion into a universal critique of caste-based spirituality. Thus, Kabir's character is not merely devout; it is a radical assertion that spiritual authority resides in sincerity, not birth.

## COMPETENCY_QUESTION_1
QUESTION: A student writes: "Kabir is a great devotee because he calls God his master." Using the concept of character analysis, explain why this answer would score low in a Class 11 exam and rewrite it to meet the standard.
COMPETENCY: Critical evaluation of answer quality (meta-cognition) and application of PEEL.
STEPS:
- Step 1: Identify the weakness—vague trait ("great devotee"), no evidence from poem, no link to context.
- Step 2: Recall board expectations—specific trait, textual evidence, analysis, context link.
- Step 3: Rewrite Point—Kabir's devotion is characterized by fearless intimacy and rejection of ritual.
- Step 4: Add Evidence—"esjs rks fxjèkj xksiky" and "nwljks u dksbZ tk osQ flj eksj&eqoqQV".
- Step 5: Add Explanation and Link—connect "esjs" to his low-caste status and the democratization of bhakti.
ANSWER: The original answer is reductive: it names a generic trait without textual support or socio-historical nuance. Improved answer: Kabir's devotion is marked by radical intimacy and iconoclasm. He addresses God as "esjs rks fxjèkj xksiky" (my Lord is the king of Kashi), using the possessive "esjs" to claim direct access, and explicitly rejects ritual symbols ("nwljks u dksbZ tk osQ flj eksj&eqoqQV"). As a julaha historically barred from temples, this claim is both spiritual and political. His character thus embodies nirguna bhakti's core: the divine belongs to the sincere, not the ritually pure.
DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: The poem's first stanza ends with "nkfl ehjka yky fxjèkj! rkjks vc eksgh". Analyze how this closing line transforms our understanding of Kabir's character from the opening line. What does the shift from statement to exclamation reveal?
COMPETENCY: Close reading of poetic structure (shift in tone) and its implication for character.
STEPS:
- Step 1: Compare opening ("esjs rks fxjèkj xksiky") and closing ("nkfl ehjka yky fxjèkj! rkjks vc eksgh").
- Step 2: Identify grammatical shift—declarative to vocative exclamation; "nkfl" (O) marks direct address.
- Step 3: Analyze tone shift—calm assertion to urgent, personal cry.
- Step 4: Connect to character—shows Kabir not as static iconoclast but as a living, yearning devotee; the exclamation humanizes the rebel.
- Step 5: Synthesize—character is dynamic: both the confident claimant of divine kinship and the desperate seeker crying "now, at this moment".
ANSWER: The opening line is a calm, declarative claim of spiritual ownership ("my Lord is the king of Kashi"); the closing line shifts to an urgent, direct address ("O Kabir, your king of Kashi! now, at this moment"). This movement from statement to exclamation reveals a character who is not merely intellectually rebellious but existentially dependent on the divine. The vocative "nkfl" and the temporal urgency "vc" (now) show that Kabir's iconoclasm springs from lived, immediate need—not abstract principle. His character thus integrates the theologian and the thirsty soul.
DIFFICULTY: hard