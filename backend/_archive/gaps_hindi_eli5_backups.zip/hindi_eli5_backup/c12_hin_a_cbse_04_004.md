## DEFINITION
Character analysis of a protagonist in poetry involves identifying the central figure (which may be a person, personified object, or abstract entity), examining how the poet constructs its identity through imagery, action, speech, and interaction with other elements, and interpreting what this figure represents in relation to the poem's central theme.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student can independently identify the protagonist of the poem "cukjl", cite at least three distinct textual evidences (imagery, personification, repetition) that build its character, and explain how this character embodies the poem's theme of urban decay and resilient humanity.

## SCOPE_BOUNDARY
This node covers character analysis of the protagonist in the poem "cukjl" (the street personified) and the child in "fn'kk". It does NOT cover supporting characters (node 005), thematic analysis (nodes 006-007), or literary devices in isolation (nodes 008-009).

## WALKTHROUGH
Imagine you are asked: "Is the street just a background in this poem, or does it have a personality?" Start by reading the poem aloud — notice how the street "breathes" (olar), "swallows" (mrjuk), and "fills" (Hkjrk). That's your first clue: the street is alive. Next, mark every verb attached to the street: vkrk, [kqyrk, Hkjrk, [kkyh. Then ask: what human qualities does it show? Patience, endurance, absorption. Finally, connect this to the child in the second poem — both survive in the same harsh space. The key insight: the protagonist is not a person but a place that *acts* like a person, making the environment itself the main character.

## DIAGNOSTIC_QUESTION_1
In the poem "cukjl", which entity is the central figure around whom the imagery and action revolve?

## DIAGNOSTIC_ANSWER_1
The street (cukjl) itself is the protagonist. A wrong answer (e.g., "the child" or "the poet") reveals the student is looking for a human character only and misses the personification that makes the setting the active agent.

## DIAGNOSTIC_QUESTION_2
Explain in your own words how the poet gives human qualities to the street in the first two stanzas.

## DIAGNOSTIC_ANSWER_2
The street "breathes" (olar vkrk), "swallows" a lamp-post (coaMj), and its "throat" (thHk) vibrates — all biological actions. A student who only lists adjectives (dark, narrow) misses the *verbs* that enact personification, showing they confuse description with character construction.

## DIAGNOSTIC_QUESTION_3
Apply the concept of "character through action" to the line: "[kkyh dVksjksa esa olar dk mrjuk!" What does this action reveal about the street's character?

## DIAGNOSTIC_ANSWER_3
The street "swallows the breath in broken lanes" — it consumes, digests, and survives the pollution/chaos. This shows resilience and voracious endurance. A wrong answer focusing only on "pollution" misses the *agency* of the street; the street isn't a victim, it's an actor.

## DIAGNOSTIC_QUESTION_4
Compare the protagonist of "cukjl" (the street) with the protagonist of "fn'kk" (the child). What shared trait emerges from how both are portrayed?

## DIAGNOSTIC_ANSWER_4
Both exhibit quiet endurance without complaint — the street "fills and breaks and fills again" (Hkjrk vkSj [kkyh gksrk), the child says "I am helpless" (eSa Lohdkj d:¡) yet survives. A student who says "both are poor" imposes external judgment instead of reading the textual stance of dignity in suffering.

## DIAGNOSTIC_QUESTION_5
Evaluate the critic's claim: "The street in 'cukjl' is a passive setting, not a character." Defend or refute using two specific textual strategies the poet uses.

## DIAGNOSTIC_ANSWER_5
Refute. Strategy 1: Grammatical agency — the street is the *subject* of 12+ active verbs (vkrk, ns[kk, [kqyrk, Hkjrk, [kkyh). Strategy 2: Emotional focalization — the poem ends with the street's "tiny hand" (nwljh Vk¡x) reaching out, making it the final emotional center. A student who agrees fails to distinguish *setting* (static backdrop) from *character* (dynamic agent).

## DIAGNOSTIC_QUESTION_6
Write a four-line stanza from the street's perspective, using the same personification techniques (active verbs, sensory imagery, repetition) to show its reaction to a new metro construction.

## DIAGNOSTIC_ANSWER_6
Example: "Drill bites my ribs / I swallow the dust, I cough steel / My veins hum with borrowed current / Still I stretch, still I hold." A poor answer writes *about* the street in third person ("The street feels pain") instead of *as* the street, showing they haven't internalized the protagonist's voice.

## COMMON_MISCONCEPTION
Students treat "character analysis" as listing physical traits (dark, narrow, crowded) because they're used to story characters. In this poem, the protagonist has no physical body — its *character* is built entirely through **verbs of action** (breathing, swallowing, filling, breaking) and **repetition** (èkhjs&èkhjs). They miss that the street's "personality" is its *endurance*, not its appearance.

## ON_FAILURE
1. Re-read stanza 1-2 aloud, circling every verb whose subject is the street. 2. Classify each verb: biological (breathes, swallows), mechanical (fills, breaks), emotional (reaches). 3. Write one sentence: "The street is a character because it ______." 4. Re-attempt Diagnostic Question 3 with this verb-list.

## BUILDS_ON
Class 11 skill of identifying personification (c11_hin_ar_cbse_01_008) and inferring character from action (c11_hin_ar_cbse_01_004).

## LEADS_TO
Theme analysis (c12_hin_a_cbse_04_006) where the protagonist's endurance becomes the vehicle for the poem's message about urban survival.

## PREREQUISITE_NODE_IDS
c12_hin_a_cbse_04_001, c12_hin_a_cbse_04_002, c12_hin_a_cbse_04_003, c11_hin_ar_cbse_01_004, c11_hin_ar_cbse_01_008
## PREREQUISITE_REASONS
c12_hin_a_cbse_04_001: Provides poet background and context of urban Hindi poetry essential to read the street as a conscious entity.  
c12_hin_a_cbse_04_002: Establishes narrative structure — the poem moves *through* the street's body, making it the structural spine.  
c12_hin_a_cbse_04_003: Sets atmosphere (noise, dust, decay) which the protagonist *inhabits* and *enacts*.  
c11_hin_ar_cbse_01_004: Prior practice analyzing protagonist in Class 11 poems (e.g., "Kabir's sakhi") builds the skill of reading non-human agency.  
c11_hin_ar_cbse_01_008: Prior identification of personification and imagery enables spotting the techniques that construct this protagonist.

## FORWARD_NODE_IDS
c12_hin_a_cbse_04_005, c12_hin_a_cbse_04_006, c12_hin_a_cbse_04_013, c12_hin_a_cbse_04_008

## FORWARD_REASONS
c12_hin_a_cbse_04_005: Supporting characters (child, fruit-seller, commuters) are defined *by their interaction with the street-protagonist*.  
c12_hin_a_cbse_04_006: The primary theme (survival with dignity) is *embodied* in the street's cyclical endurance.  
c12_hin_a_cbse_04_013: Critical interpretation requires a firm grasp of *who* the poem centers — without this, analysis drifts to vague generalizations.
c12_hin_a_cbse_04_008: Protagonist (the village) — metaphor personifies it.  

## CROSS_SUBJECT_PREREQS
c11_hin_ar_cbse_04_004, c11_hin_v_cbse_04_004
## CROSS_SUBJECT_REASONS
c11_hin_ar_cbse_04_004: Antra Class 11 character analysis of protagonists in poems like "Utsaah" establishes the method of reading central figures through verb-choice and repetition.  
c11_hin_v_cbse_04_004: Vitan Class 11 character analysis in prose (e.g., "Bazaar Darshan") teaches tracking a character's response to environment — directly transferable to the street's response to urbanization.

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_01_004 -> c12_hin_a_cbse_04_004 -> c12_hin_a_cbse_04_006

## THIS_FORMULA
Protagonist Identity = Σ (Active Verbs with Entity as Subject) + Σ (Personified Attributes) + Structural Centrality (opening/closing focus) + Thematic Embodiment

## FORMULA_VARIABLES
- Active Verbs: Actions where the entity is grammatical subject (e.g., vkrk, [kqyrk, Hkjrk)  
- Personified Attributes: Biological/emotional terms applied to entity (olar, thHk, Vk¡x)  
- Structural Centrality: Entity appears in first image, last image, and recurring refrain  
- Thematic Embodiment: Entity's actions mirror the poem's central message (endurance = survival)

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
analytical

## CROSS_SUBJECT
N/A | The street-protagonist mirrors geographic concepts of "urban morphology" and "informal settlement resilience" — the poem's [kkyh dVksjksa (broken lanes) and olar (breath/pollution) are literary equivalents of slum ecology.  
 N/A | The child's "Lohdkj" (helplessness) and the street's cyclical endurance reflect sociological "agency within structure" — both navigate systemic neglect without romanticization.
## PREREQ_CONCEPT
Personification as character construction (not just decoration) — the street *is* its actions.

## PREREQ_BEFORE
Student must distinguish between "setting description" (adjectives) and "character enactment" (verbs + agency).

## PREREQ_STUCK
If stuck, revisit Class 11 Antra Chapter 1 "Utsaah" where the cloud is protagonist — analyze its verbs (ghumta, barsata) as character traits.

## WORKED_EXAMPLE_1
PROBLEM: Using the formula, prove that the street (cukjl) is the protagonist of the poem "cukjl" and not merely the setting.

STEPS:
- Step 1: List all verbs where "cukjl" or its pronouns (bl 'kgj, yg, ;g) are the grammatical subject. Found: vkrk (breathes), ns[kk (showed), [kqyrk (slithers), Hkjrk (fills), [kkyh (breaks), Hkjrk (fills again) — 6 active verbs in 3 stanzas.
- Step 2: Identify personified attributes: olar (breath/life), thHk (throat), n'kk'oesèk (lane as body part), Vk¡x (hand), nwljh Vk¡x (tiny hand) — 5 biological terms.
- Step 3: Check structural centrality: Poem opens with "cukjl dfork" (street poem), first line "bl 'kgj esa olar vpkud vkrk gS", ends with "viuh nwljh Vk¡x ls fcyoqQy cs[kcj!" — street frames the entire poem.
- Step 4: Map to theme: The cycle Hkjrk -> [kkyh -> Hkjrk (fills, breaks, fills) mirrors the theme of resilient survival in "fn'kk" where child says "eSa Lohdkj d:¡" yet persists.
- Step 5: Conclude: All four formula components are satisfied at high density — the street is the protagonist.

REASONING: This method moves beyond "important character" to measurable textual evidence. Setting gets adjectives; protagonist gets verbs, body parts, structural framing, and thematic weight.

ANSWER: The street is the protagonist because it performs 6+ actions, possesses 5+ human organs, frames the poem structurally, and enacts the central theme of cyclical endurance.

## WORKED_EXAMPLE_2
PROBLEM: Analyze how the repetition "èkhjs&èkhjs" (slowly-slowly) constructs the street's character across stanzas 3-4.

STEPS:
- Step 1: Locate all occurrences: Stanza 3: "èkhjs&èkhjs mM+rh gS", "èkhjs&èkhjs pyrs gSa", "èkhjs&èkhjs ctrs gSa", "'kke èkhjs&èkhjs gksrh gS" — 4 times in 8 lines.
- Step 2: Categorize what happens "slowly": èkhjs mM+rh (darkness rises), pyrs (people walk), ctrs (spittle falls), 'kke gksrh (cough emerges) — all involuntary, biological, inevitable processes.
- Step 3: Analyze grammatical role: "èkhjs&èkhjs" modifies verbs whose subjects are either the street's elements (darkness, cough) or people *on* the street — the street's rhythm dictates the tempo of life on it.
- Step 4: Connect to character: This repetition makes "slowness" the street's defining trait — not laziness, but *endurance tempo*. It cannot rush; it absorbs time.
- Step 5: Contrast with "vkneh n'kk'oesèk ij tkrk gS" (goes to the lane's crossroads) — the street's slowness is punctuated by sudden junctions, showing it has a nervous system.

REASONING: Repetition here isn't emphasis — it's *characterization through rhythm*. The street's heartbeat is "èkhjs&èkhjs".

ANSWER: The refrain "èkhjs&èkhjs" acts as the street's pulse, governing the involuntary biological rhythms (darkness, walking, spitting, coughing) of everyone on it, establishing the protagonist as a slow, patient, absorbing entity.

## WORKED_EXAMPLE_3
PROBLEM: Compare the protagonist of "cukjl" (street) with the protagonist of "fn'kk" (child) to derive the chapter's unified view of "urban protagonist".

STEPS:
- Step 1: Extract street's core actions: breathes, swallows, fills, breaks, fills, reaches out (tiny hand).
- Step 2: Extract child's core actions: cries (irax mM+k), speaks truth ("mèkj gS"), accepts helplessness ("eSa Lohdkj d:¡"), recognizes fruit-seller first time.
- Step 3: Find shared pattern: Both *acknowledge reality without illusion* — street: "tks gS og lqxcqxkrk gS / tks ugha gS og isaQdus yxrk gS" (what is, is clear / what isn't, seems like illusion); child: "ftèkj mldh iarx Hkkxh tk jgh Fkk" (whose half is going) — both see loss clearly.
- Step 4: Find shared stance: Neither blames, neither heroizes. Street "fcuk fdlh lwpuk osQ ?kql tkvks" (without anyone's notice, quietly goes); child "eSa Lohdkj d:¡" (I am helpless) — quiet dignity.
- Step 5: Synthesize: The "urban protagonist" in this chapter is *the ordinary entity that endures by seeing clearly and acting small* — street's "nwljh Vk¡x" (tiny hand), child's "igyh ckj" (first time) recognition.
- Step 6: Thematic link: This connects to Chapter's larger message (node 006) — survival is not grand resistance but daily, clear-eyed persistence.

REASONING: Class 12 board exams often ask "compare the central figures of the two poems". This worked example models the exact comparative structure: extract actions -> find pattern -> name shared stance -> link to theme.

ANSWER: Both protagonists are defined by clear-eyed, non-heroic endurance — the street through its cyclical biology, the child through its articulate helplessness. Together they define the chapter's urban protagonist: the one who survives by seeing truth and offering a "tiny hand".

## COMPETENCY_QUESTION_1
QUESTION: A student writes: "The protagonist of 'cukjl' is the poet because he describes the street." Using the concept of grammatical agency and structural centrality, explain why this is incorrect and who the actual protagonist is.

COMPETENCY: Critical reading / Textual evidence evaluation

STEPS:
- Step 1: Identify the claim's error — confuses *speaker* with *protagonist*.
- Step 2: Apply grammatical agency test — count verbs where "poet" (eSaus) is subject vs "street" (cukjl/bl 'kgj) is subject. Poet: 2 verbs (ns[kk, tkuk). Street: 6+ verbs.
- Step 3: Apply structural centrality test — poet appears in last 2 lines of second poem only; street frames entire first poem.
- Step 4: Conclude: Protagonist = entity with most agency + structural presence = street.

ANSWER: The poet is the *observer* (2 verbs, marginal position); the street is the *protagonist* (6+ active verbs, opens/closes poem, possesses human organs). The student confused narrative voice with central character.

DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: The poem ends with the street's "nwljh Vk¡x" (tiny hand) reaching out "fcyoqQy" (intensely). A critic calls this "sentimental weakness". Defend the street's action as *strategic resilience* using three textual evidences from the poem.

COMPETENCY: Argumentative interpretation / Thematic synthesis

STEPS:
- Step 1: Reject "weakness" reading — "tiny" refers to scale, not power. The hand belongs to the entity that "swallows lamp-posts" (coaMj) and "fills and breaks and fills" (Hkjrk [kkyh Hkjrk).
- Step 2: Evidence 1: "vxj è;ku ls ns[kks rks ;g vkèkk gS" — the street *is* the reality (vkèkk), not an illusion. Its reach is reality asserting itself.
- Step 3: Evidence 2: "tks gS og lqxcqxkrk gS" — the street sees clearly. The reach is a *deliberate* act of clarity, not emotional impulse.
- Step 4: Evidence 3: Parallel in "fn'kk" — child's "igyh ckj tkuk fgeky; fdèkj gS" (first time recognizing fruit-seller) is also a small, clear-eyed reach toward connection. Both are strategic: survival requires connection.
- Step 5: Synthesize: The "tiny hand" is the street's *only* tool to bridge the alienation of "lbZ lk¡>" (lost moments) — it's resilience in miniature form.

ANSWER: The gesture is strategic resilience because: (1) it comes from an entity that dominates its space (swallows lamp-posts), (2) it enacts the street's core trait of clear-sightedness (lqxcqxkrk), (3) it mirrors the child's first recognition — both are small, deliberate acts of connection that sustain survival in a fragmenting city.

DIFFICULTY: hard