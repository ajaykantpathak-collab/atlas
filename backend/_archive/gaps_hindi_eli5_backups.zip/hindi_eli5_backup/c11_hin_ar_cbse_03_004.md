## DEFINITION
Character analysis of the protagonist involves examining the narrator's personality, motivations, conflicts, and growth through their actions, speech, thoughts, and relationships in the autobiographical narrative "viw osQ lkFk <kbZ lky". The protagonist here is the first-person narrator (iFksj ikapkyh), a playwright-director whose journey of staging a play with child actors reveals his artistic integrity, empathy, and struggle against practical constraints.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student can write a structured 150-word character sketch of the narrator using the PEEL method (Point, Evidence, Explanation, Link) with at least three distinct textual evidences from different episodes, explaining how each evidence reveals a specific trait and connects to the central theme of artistic dedication vs. reality.

## SCOPE_BOUNDARY
This node covers analysis of the narrator (author) as protagonist only. It does NOT cover analysis of the child actors (Hkwyks, nqxkZ), the old caretaker (lkmaM), or the play's fictional characters. It focuses on traits revealed through the staging process: resourcefulness, sensitivity to children, artistic vision, and handling of crises.

## WALKTHROUGH
Imagine you are directing a school play with zero budget, untrained children, and a collapsing set - what would you do? The narrator faces exactly this when staging "Viv" on a small stage. To analyze him, first identify his ROLE: he is the director, writer, and narrator. Next, track his ACTIONS across three crises: finding a stage (using a courtyard), managing child actors' fear (the "Hkwyks" duplicate scene), and the final performance chaos (rain, missing props). Then examine his INTERNAL RESPONSES: he feels "csgky" (ashamed) when the stage is inadequate, "fpYykuk" (restless) during crises, but persists. Finally, connect these to his CORE TRAITS: artistic commitment (refusing to compromise the play's vision), empathy (protecting children's dignity), and resilience (improvising solutions). The key insight: his greatness lies not in perfect execution but in preserving the children's creative spirit amid chaos.

## DIAGNOSTIC_QUESTION_1
What is the narrator's primary role in the chapter "viw osQ lkFk <kbZ lky"?

## DIAGNOSTIC_ANSWER_1
The narrator (iFksj ikapkyh) is the playwright-director staging his play "Viv" with child actors on a small makeshift stage. A wrong answer (e.g., "he is an actor in the play" or "he is a spectator") reveals the student cannot distinguish between the narrator's real-life role and the play's fictional characters, indicating a failure to grasp the autobiographical nature of the narrative.

## DIAGNOSTIC_QUESTION_2
Explain in your own words why the narrator feels "csgky" (ashamed) when his mother suggests using their courtyard for the play's stage.

## DIAGNOSTIC_ANSWER_2
The narrator feels ashamed because his professional artistic vision demands a proper theatre space, but financial constraints force him to use a domestic courtyard - highlighting the gap between artistic aspiration and material reality. A wrong answer (e.g., "he is shy about his mother seeing the play") shows the student misses the thematic conflict between artistic dignity and practical compromise, reducing a complex emotion to simple embarrassment.

## DIAGNOSTIC_QUESTION_3
The narrator discovers two different boys playing "Hkwyks" (Viv) during rehearsals. Apply the concept of "director's dilemma" to explain what this reveals about his leadership style.

## DIAGNOSTIC_ANSWER_3
Instead of punishing the deception, he observes both boys' performances and lets the better actor continue, revealing a child-centered, merit-based leadership that prioritizes artistic outcome over authority. A wrong answer (e.g., "he scolds them for cheating") reveals the student imposes adult authoritarian expectations on a collaborative creative process, missing the narrator's protective empathy for child actors.

## DIAGNOSTIC_QUESTION_4
Analyze how the narrator's handling of the rain crisis during the final performance (using umbrellas as props, continuing despite chaos) reflects his core philosophy of theatre.

## DIAGNOSTIC_ANSWER_4
He transforms disaster into creative improvisation - umbrellas become stage props, chaos becomes part of the performance - proving his belief that theatre lives in adaptability and the actor's spirit, not perfect conditions. A wrong answer (e.g., "he was helpless and the show failed") shows the student cannot see artistic agency in chaos, missing the central theme: theatre is "life itself" (thou dh miyfC/;ka), not a polished product.

## DIAGNOSTIC_QUESTION_5
Evaluate whether the narrator succeeds as a director by the end of the chapter. Justify using two contrasting pieces of evidence.

## DIAGNOSTIC_ANSWER_5
He succeeds artistically (children perform authentically, audience moved) but fails logistically (rain ruins set, props lost, old caretaker dies unseen). This duality proves his definition of success: "the play reaches the small stage" (lkFk <kbZ lky) matters more than perfection. A wrong answer (e.g., "he fails because of the rain") reveals a binary success/failure mindset, ignoring the narrator's own metric: the children's creative experience outweighs material outcomes.

## DIAGNOSTIC_QUESTION_6
Write a 50-word diary entry from the narrator's perspective the night after the final performance, capturing his dominant emotion and its source.

## DIAGNOSTIC_ANSWER_6
A strong entry shows bittersweet fulfillment: pride in children's courage ("Hkwyks dk Hkkr [kkuk") grief for the old caretaker ("lkmaM dh mrk"), and quiet acceptance that theatre's magic survives chaos. A poor entry (e.g., "I am happy the play ended") reveals inability to synthesize conflicting emotions, missing the narrator's complex reflective voice that defines his character.

## COMMON_MISCONCEPTION
Students confuse the narrator (real-life director) with the play's protagonist "Viv" (fictional character played by Hkwyks). They write character sketches of Viv using the boy actor's traits (fear, forgetting lines) instead of analyzing the narrator's directorial choices. This happens because the chapter title "viw osQ lkFk <kbZ lky" centers the play's name, and the boy playing Viv gets significant textual space. The narrator's "I" statements get overlooked as mere reporting rather than character revelation.

## ON_FAILURE
1. Ask student to highlight every "eSa" (I) statement in the text and categorize: action (I did), feeling (I felt), decision (I decided). 2. Create a two-column table: "Narrator's Action" vs "What it Reveals". 3. Practice writing one PEEL paragraph using the "rain crisis" episode: Point (He values process over perfection), Evidence (used umbrellas as props), Explanation (improvisation kept children acting), Link (shows theatre as living art). 4. Contrast with Viv's character: "Viv is a role; the narrator is the creator."

## BUILDS_ON
c11_hin_ar_cbse_03_002: Text: Plot and Narrative Structure (provides the sequence of crises the narrator faces)

## LEADS_TO
c11_hin_ar_cbse_03_005: Character Analysis: Supporting Characters (the narrator's traits are illuminated through his interactions with child actors and caretaker)

## PREREQUISITE_NODE_IDS
c11_hin_ar_cbse_03_001, c11_hin_ar_cbse_03_002, c11_hin_ar_cbse_03_003
## PREREQUISITE_REASONS
c11_hin_ar_cbse_03_001: Context about the author's background (playwright, children's theatre pioneer) establishes why he undertakes this difficult staging.
c11_hin_ar_cbse_03_002: Plot structure identifies the three major crises (stage, casting, performance) that test the narrator's character.
c11_hin_ar_cbse_03_003: Setting (courtyard stage, rain, chaotic atmosphere) creates the physical constraints shaping the narrator's responses.

## FORWARD_NODE_IDS
c11_hin_ar_cbse_03_005, c11_hin_ar_cbse_03_006, c11_hin_ar_cbse_03_013, c11_hin_ar_cbse_03_011, c11_hin_ar_cbse_03_012, c11_hin_ar_cbse_03_014, c11_hin_ar_cbse_03_015, c12_hin_al_cbse_02_004, c12_hin_al_cbse_03_004, c12_hin_ar_cbse_01_004, c12_hin_ar_cbse_06_004, c12_hin_ar_cbse_08_004, c12_hin_ar_cbse_10_004, c12_hin_v_cbse_03_004

## FORWARD_REASONS
c11_hin_ar_cbse_03_005: Supporting characters (Hkwyks, nqxkZ, lkmaM) are defined by their relationship to the narrator's directorial choices.
c11_hin_ar_cbse_03_006: Primary theme (artistic integrity amid chaos) emerges directly from the narrator's actions and philosophy.
c11_hin_ar_cbse_03_013: Critical interpretation requires evaluating the narrator's reliability and ethical stance as both creator and chronicler.
c11_hin_ar_cbse_03_011: Character Analysis: Protagonist establishes the narrator's dual role (grandson / director), which drives the code-switching between intimate and formal registers.  
c11_hin_ar_cbse_03_012: Protagonist's motives/feelings are central to inferential questions on his actions.  
c11_hin_ar_cbse_03_014: नायक (इफ्फन) के चरित्र-चित्रण के बिंदु Point और Explanation के आधार बनते हैं।  
c11_hin_ar_cbse_03_015: Protagonist analysis (playwright's psyche) enables role-play and perspective-taking.  
c12_hin_al_cbse_02_004: Prior practice in protagonist analysis (Class 11 Antaral Chapter 3).  
c12_hin_al_cbse_03_004: Class 11 foundation in character analysis methods (traits, evidence, PEEL) which this node deepens with dual-timeline complexity.  
c12_hin_ar_cbse_01_004: Covered dialogic persona in Trilochan's Class 11 poems — prepares for the address-response structure in this chapter's Trilochan poem.  
c12_hin_ar_cbse_06_004: अगला तार्किक चरण: Character analysis of the protagonist in poetry involves identifying the central personified figure,... इस नोड की अवधारणाओं को सीधे उपयोग/विस्तारित करता है।  
c12_hin_ar_cbse_08_004: Teaches linking character traits to poetic devices (metaphor, imagery).  
c12_hin_ar_cbse_10_004: Practices analysis of marginalized protagonist in "Miyan Nasiruddin" — builds skill for reading subaltern voices.  
c12_hin_v_cbse_03_004: Class 11 Aroh protagonist analysis — reinforces core methods (PEEL structure, textual evidence).  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
none

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_03_002 -> c11_hin_ar_cbse_03_004 -> c11_hin_ar_cbse_03_005

## THIS_FORMULA
N/A - conceptual

## FORMULA_VARIABLES
N/A

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
conceptual

## CROSS_SUBJECT
c11_history_nationalism_arts | The narrator's struggle to create indigenous children's theatre mirrors post-independence cultural nation-building where artists built institutions from scratch.
c11_psychology_child_development | His child-centered directing (protecting dignity, fostering creativity) aligns with Vygotsky's zone of proximal development and Rogers' unconditional positive regard.

## PREREQ_CONCEPT
Understanding first-person autobiographical narrative vs. play-within-story structure.

## PREREQ_BEFORE
Student must distinguish between: (1) the narrator's real experiences, (2) the play "Viv" being staged, (3) the child actors' real personalities vs. their roles.

## PREREQ_STUCK
Review "Plot and Narrative Structure" node to map the narrator's journey through three crises: finding stage -> casting crisis -> performance chaos.

## WORKED_EXAMPLE_1
PROBLEM: Write a character sketch of the narrator focusing on his "resourcefulness in crisis" using the PEEL structure. Use the courtyard stage episode.
STEPS:
- Step 1: Identify the trait to prove - "resourcefulness in crisis" (Point).
- Step 2: Locate evidence - narrator uses mother's courtyard when no stage available, converts domestic space into theatre (Evidence).
- Step 3: Explain how this shows resourcefulness - he sees possibility where others see limitation; "ml txg x,], rks og txg ge igpku gh ugha ik," (Explanation).
- Step 4: Link to broader character - this improvisational mindset recurs in casting crisis and rain crisis (Link).
- Step 5: Verify against text - he repeats "fI+kQYe dk dke vkxs Hkh <kbZ lky pyus okyk gS" showing consistent commitment despite constraints.
REASONING: The PEEL structure forces textual grounding. The courtyard episode is the first crisis establishing his pattern of creative problem-solving. Connecting it to later crises proves consistency of character.
ANSWER: The narrator's defining trait is resourcefulness in crisis. When no theatre is available, he transforms his mother's courtyard into a stage ("ml txg x,], rks og txg ge igpku gh ugha ik,"), seeing artistic possibility in domestic space. This improvisational mindset recurs when he handles the dual-Hkwyks casting crisis by judging on merit, and during the rain disaster where umbrellas become props. His repeated refrain "fI+kQYe dk dke vkxs Hkh <kbZ lky pyus okyk gS" reveals a director who values the play's life over perfect conditions.

## WORKED_EXAMPLE_2
PROBLEM: Analyze how the narrator's empathy for child actors shapes his directorial decisions. Use the "Hkwyks duplicate" and "rain performance" episodes.
STEPS:
- Step 1: State the trait - "protective empathy for child actors" (Point).
- Step 2: Evidence 1 - discovers two boys playing Hkwyks, doesn't punish but evaluates artistically ("nks vyx&vyx oqQÙkksa ls dke fy;k gS") (Evidence).
- Step 3: Explain - prioritizes children's creative experience over adult authority; lets better actor continue (Explanation).
- Step 4: Evidence 2 - during rain, continues performance to protect children's effort ("cPps osQ Hkko ns[kdj tku tkrh gS fd og vc oqQN ugha [kk,xk") (Evidence).
- Step 5: Synthesize - empathy drives both artistic and ethical choices; he shields them from failure (Link).
- Step 6: Connect to theme - this empathy makes theatre a "safe space" for children, central to his philosophy.
REASONING: Empathy is shown through actions, not statements. Comparing two crises reveals consistent pattern: he adapts the process to serve the child, not the child to serve the process. This distinguishes him from conventional authoritarian directors.
ANSWER: The narrator's empathy manifests as protective flexibility. When he discovers two boys secretly sharing the Hkwyks role, he doesn't scold but observes both performances ("nks vyx&vyx oqQÙkksa ls dke fy;k gS"), letting merit decide. During the rain-soaked finale, he continues the show because stopping would crush the children's spirit ("cPps osQ Hkko ns[kdj tku tkrh gS fd og vc oqQN ugha [kk,xk"). In both cases, he subordinates directorial control to the children's creative dignity, making theatre a nurturing space rather than a demanding one.

## WORKED_EXAMPLE_3
PROBLEM: Evaluate the narrator's reliability as a chronicler of his own failure/success. Use the old caretaker's death scene and the final audience reaction.
STEPS:
- Step 1: Identify the evaluation challenge - narrator judges himself; we must assess his self-portrait (Point).
- Step 2: Evidence of potential bias - he calls the chaotic rain performance "vc dh dgk¡ vk x, gSa ge" with wonder, possibly romanticizing disaster (Evidence).
- Step 3: Counter-evidence of honesty - he records his shame ("csgky"), panic ("fpYykuk"), and the caretaker's unnoticed death ("mlosQ ekfyd dk ikyu ugha dj jgk gSA") without self-exoneration (Evidence).
- Step 4: Analyze audience reaction - "fpYykuk" spectators, children's genuine fear ("Hkwyks oqQÙkk Hkh Nykax yxkdj") validate the chaos (Explanation).
- Step 5: Judge reliability - he is reliable because he includes damaging details (forgetting caretaker, chaos) that a self-glorifying narrator would omit (Link).
- Step 6: Connect to literary device - this unreliable-yet-honest narration creates dramatic irony: we see his blind spots (neglecting caretaker) he doesn't explicitly condemn.
REASONING: Senior secondary analysis requires evaluating narrative voice. The narrator's inclusion of his moral blind spots (the caretaker's death unnoticed amid artistic triumph) proves reliability through self-incrimination. This complexity is a hallmark of sophisticated autobiographical writing.
ANSWER: The narrator is remarkably reliable precisely because he documents his failures. He admits shame at the courtyard stage ("csgky"), panic during crises ("fpYykuk"), and most damningly, his obliviousness to the old caretaker's death during the performance ("mlosQ ekfyd dk ikyu ugha dj jgk gSA"). A self-serving narrator would omit the caretaker's lonely death. The audience's restless reaction ("fpYykuk") and children's genuine terror validate his account of chaos. His reliability lies in refusing to make himself the hero - the play's messy life is the true protagonist.

## COMPETENCY_QUESTION_1
QUESTION: "The narrator says 'fI+kQYe dk dke vkxs Hkh <kbZ lky pyus okyk gS' (the play's work was still reaching the small stage). Using this as your central argument, write a 120-word analysis of how THREE specific crises reveal his evolving definition of theatrical success."
COMPETENCY: Analytical Writing with Textual Synthesis
STEPS:
- Step 1: Deconstruct the quote - "small stage" = modest conditions, "reaching" = persistence, not arrival.
- Step 2: Select three crises: courtyard stage, dual-Hkwyks casting, rain performance.
- Step 3: For each, show how his success metric shifts: from proper venue -> child's authentic performance -> play's life amid chaos.
- Step 4: Synthesize - success is the process of keeping the play alive, not the product.
- Step 5: Conclude with the quote as thematic anchor.
ANSWER: The narrator's evolving definition of success moves from external validation to internal vitality. Crisis 1 (courtyard stage): success = finding ANY space ("ml txg x,], rks og txg ge igpku gh ugha ik,") - physical realization. Crisis 2 (dual Hkwyks): success = child's authentic acting ("nks vyx&vyx oqQÙkksa ls dke fy;k gS") - artistic integrity over authority. Crisis 3 (rain): success = performance continuing ("cPps osQ Hkko ns[kdj tku tkrh gS") - life force over perfection. The refrain "fI+kQYe dk dke vkxs Hkh <kbZ lky pyus okyk gS" captures this: theatre succeeds not when conditions are perfect, but when the play persists through imperfect conditions. His success is the play's survival.
DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: "The narrator neglects the dying caretaker (lkmaM) during the final performance. Does this moral failure undermine his artistic achievement? Argue using the text's own value system."
COMPETENCY: Ethical Evaluation with Textual Evidence
STEPS:
- Step 1: Identify the narrator's value system - theatre as "thou dh miyfC/;ka" (life's activities), children's creative spirit paramount.
- Step 2: Locate the caretaker's death - occurs DURING the play's climax, narrator learns after.
- Step 3: Analyze narrator's reaction - "vc ;gk¡ èkhjt j[kus osQ flok nwljk mik; ugha Fkk" (no chance to stop), immediate guilt ("dV~! dV~!").
- Step 4: Apply text's values - the play IS life; the caretaker's death is life intersecting art. The narrator's horror shows he doesn't separate them.
- Step 5: Judge - failure is real but doesn't negate achievement; it deepens it by proving theatre's stakes are real life.
- Step 6: Conclude - the text suggests art that ignores life is false; his guilt validates his humanity.
ANSWER: The neglect is a genuine moral failure - he prioritizes the performance over a dying man. However, the text's own value system ("fI+kQYe dk dke vkxs Hkh <kbZ lky pyus okyk gS" and theatre as "thou dh miyfC/;ka") frames this collision as the inevitable cost of total artistic commitment. His immediate horror ("dV~! dV~!") and the haunting final image of the caretaker's "okLrqliZ" (final message) prove he doesn't rationalize it. The achievement isn't undermined but humanized: great theatre demands great sacrifice, and the narrator's guilt is the price of authenticity. The play succeeds BECAUSE it nearly destroys him.
DIFFICULTY: hard