## DEFINITION
Writing skills based on the chapter "Meera Ke Pad" refers to the ability to compose structured, evidence-based responses — such as analytical paragraphs, character sketches, thematic essays, and critical appreciations — that demonstrate understanding of Meera's poetry, her bhakti philosophy, and the literary devices she employs, using the PEEL (Point, Evidence, Explanation, Link) framework aligned with CBSE Class 11 board examination patterns.

## COGNITIVE_LEVEL
apply

## MASTERY_CRITERIA
The student can independently write a 150-200 word analytical response on Meera's poetry that includes a clear thesis statement, at least two textual references (paraphrased or quoted), explanation of literary devices (metaphor, imagery, symbolism), and a concluding link to the central theme of nirgun-sagun bhakti synthesis, all within 15 minutes under exam conditions.

## SCOPE_BOUNDARY
This node covers writing analytical answers, character sketches of Meera, thematic essays on bhakti and social reform, and critical appreciation of her pads — using only content from Chapter 10 (Aroh). It does NOT cover creative writing (poetry composition), letter writing, or unseen passage comprehension, which belong to other sections of the syllabus.

## WALKTHROUGH
Imagine you sit in the exam hall and see this question: "Meera's poetry blends personal devotion with social rebellion. Discuss with reference to the prescribed pads." Your mind goes blank — where do you even begin? Start by recalling the two pads in your textbook: the first where she calls Krishna her "fxjèkj" (husband) and rejects worldly ties, and the second where she describes her physical suffering ("valqou ty lhafp&lhafp") as love's fire. Don't summarize the poem — that's the trap most students fall into. Instead, pick ONE idea (e.g., "Meera redefines marriage as spiritual union"), find a line that proves it ("esjs rks fxjèkj xksiky"), explain HOW the metaphor works (rejecting mortal husband for divine), and link it to the bigger theme (bhakti as liberation from patriarchal norms). That four-move pattern — Point, Evidence, Explanation, Link — is your scaffold for every answer. Practice it until it becomes automatic.

## DIAGNOSTIC_QUESTION_1
What is the PEEL structure for writing analytical answers in CBSE Class 11 Hindi, and what does each letter stand for?

## DIAGNOSTIC_ANSWER_1
PEEL stands for Point (main argument), Evidence (textual reference), Explanation (analysis of evidence), and Link (connection to theme/question). A wrong answer — such as listing "Paragraph, Example, Explain, Line" — reveals the student memorized an acronym without understanding the *function* of each component; they will likely write summaries instead of analysis because they don't grasp that "Explanation" requires interpreting *how* the evidence works, not just repeating it.

## DIAGNOSTIC_QUESTION_2
A student writes: "Meera loves Krishna very much. She says he is her husband. She suffers a lot but still loves him. This shows her devotion." Why is this answer insufficient for a 5-mark Class 11 question, even though the content is factually correct?

## DIAGNOSTIC_ANSWER_2
The answer is a narrative summary, not an analytical response — it states *what happens* but not *how* the poet achieves meaning. It lacks: (1) a clear thesis (Point), (2) specific textual evidence with line references (Evidence), (3) analysis of literary devices like metaphor ("fxjèkj") or imagery ("valqou ty lhafp&lhafp") (Explanation), and (4) connection to the broader theme of nirgun bhakti challenging social orthodoxy (Link). A student who cannot identify these gaps will continue writing story-retellings instead of literary analysis.

## DIAGNOSTIC_QUESTION_3
Using the PEEL framework, write a 4-sentence analytical paragraph responding to: "How does Meera use the metaphor of marriage in the first pad to express her spiritual relationship with Krishna?" Use only ideas from the chapter — do not quote the poem verbatim.

## DIAGNOSTIC_ANSWER_3
**Point:** Meera redefines marriage as an exclusive spiritual bond with Krishna, rejecting conventional marital and social obligations.  
**Evidence:** In the opening pad, she addresses Krishna as "fxjèkj xksiky" (my husband Krishna) and declares "esjks ifr lksbZ" (no one else is mine).  
**Explanation:** The metaphor transforms the sacramental Hindu marriage — traditionally a social duty — into a personal, voluntary surrender to the divine, where the "husband" is not a mortal man but the nirgun brahman manifest as Krishna.  
**Link:** This establishes bhakti as a path of radical autonomy, where the devotee chooses God over family, caste, and royal duty — the central conflict of Meera's life and poetry.  
*A student who merely paraphrases ("Meera calls Krishna her husband") without analyzing the *subversive function* of the metaphor misses the Explanation step and scores 1/5.*

## DIAGNOSTIC_QUESTION_4
Compare the tone and imagery in the two prescribed pads of Meera. How does the shift from declarative confidence ("esjs rks fxjèkj xksiky") to physical suffering ("valqou ty lhafp&lhafp") deepen the portrayal of bhakti as both empowerment and ordeal?

## DIAGNOSTIC_ANSWER_4
The first pad uses assertive, declarative tone ("esjs rks...") and relational imagery (husband, co-wife, household) to frame bhakti as a *chosen identity* — Meera claims agency by naming Krishna her sole relation. The second pad shifts to visceral, somatic imagery ("lhafp&lhafp" — burning, "csfy iSQfy" — pierced, "vk.kan&iQy" — restless) and paradox ("nfèk efFk ?k`r dkf<+ fy;ks" — the physician himself is the disease) to portray love as a *consuming fire* that dismantles the body. Together, they show bhakti not as passive sentiment but as a transformative crisis: the first pad is the *decision*, the second the *consequence*. A student who only lists images ("fire, pain, physician") without tracing the *tonal arc* from agency to surrender fails to analyze the structural progression central to the chapter's interpretation.

## DIAGNOSTIC_QUESTION_5
Evaluate this student claim: "Meera's poetry is only about personal devotion; it has no social or political relevance." Defend or refute using evidence from the chapter's critical commentary (the prose sections before/after the pads).

## DIAGNOSTIC_ANSWER_5
The claim is **refuted** by the chapter's own critical apparatus. The prose introduction explicitly states Meera "nkf;Ro vkSj oqQy dh e;kZnk osQ uke ij yxk, x, lkekftd vkSj oSpkfjd caèkuksa dk ges'kk fojksèk fd;k" (exposed social and religious hypocrisies in the name of widowhood and purity) and that she "inkZ izFkk dk Hkh ikyu ugha fd;k" (did not observe purdah even initially). Her refusal of sati, rejection of royal protocol, and mingling across caste lines ("lkoZtfud :i ls ukpus&xkus") are *enacted* in the pads through metaphors that collapse social hierarchies (calling Krishna "husband" voids her widow status; addressing all as "lksbZ" — none — dissolves caste kinship). A student who accepts the claim uncritically has not read the *critical commentary* as textual evidence — a common error when students treat prose sections as "background" rather than examinable content.

## DIAGNOSTIC_QUESTION_6
Write a 3-sentence "thesis statement + two supporting claims" outline for an essay on: "Meera's pads in Aroh Chapter 10 present bhakti as a feminist resistance to patriarchal structures." Do not write the full essay — only the outline.

## DIAGNOSTIC_ANSWER_6
**Thesis:** Meera's prescribed pads reconfigure bhakti as feminist resistance by substituting divine love for marital duty, thereby dismantling the patriarchal triad of husband, family, and caste that defines a Rajput woman's identity.  
**Claim 1:** The metaphor "fxjèkj xksiky" replaces the mortal husband with Krishna, voiding widowhood rituals (sati, purdah) and claiming sexual-spiritual autonomy.  
**Claim 2:** The imagery of "valqou ty lhafp&lhafp" reframes female suffering not as shameful victimhood but as sacred knowledge — the "physician" (society/patriarchy) cannot cure what it caused.  
*A weak answer would list themes ("devotion, pain, rebellion") without a *contested, arguable thesis* or *claims tied to specific textual strategies* — revealing the student confuses "topic" with "argument."*

## COMMON_MISCONCEPTION
Students believe "writing skills based on the chapter" means *summarizing the poem in their own words* or *memorizing a model answer*. They treat the pads as content to reproduce, not as texts to *analyze*. For example, when asked "Discuss Meera's concept of love," a student writes: "Meera loves Krishna. She calls him her husband. She suffers pain. But she is happy." This is a *plot summary of the pads*, not an analytical response. The error stems from Class 10 training where "explain the poem" often meant "paraphrase each stanza." In Class 11, the same verb "explain" demands *literary analysis* — how metaphor, tone, and structure *create* meaning. Students don't realize the *question verb* has upgraded but their *response strategy* hasn't.

## ON_FAILURE
If a student submits a summary instead of analysis: (1) Return the answer with three highlighters — yellow for *summary* (what happens), pink for *evidence* (quotes/references), green for *analysis* (why it matters). Ask: "Where is the green?" (2) Model the conversion: take their summary sentence "Meera suffers pain" → rewrite as "The imagery 'valqou ty lhafp&lhafp' transforms physical agony into spiritual purification, suggesting bhakti reframes suffering as knowledge." (3) Assign a 5-minute drill: give them *one* line from the pad ("nfèk efFk ?k`r dkf<+ fy;ks") and ask for *only* the Explanation step — no Point, no Evidence, no Link. Repeat until they can generate analytical language automatically.

## BUILDS_ON
c11_hin_ar_cbse_10_013 (Critical Thinking: Analysis and Interpretation) — students must first interpret the pads' themes, devices, and tone before they can write about them analytically.

## LEADS_TO
c11_hin_ar_cbse_10_015 (Speaking and Listening: Discussion Points) — written analytical responses form the script/preparation for structured oral discussions and debates on Meera's poetry.

## PREREQUISITE_NODE_IDS
c11_hin_ar_cbse_10_001, c11_hin_ar_cbse_10_002, c11_hin_ar_cbse_10_003, c11_hin_ar_cbse_10_004, c11_hin_ar_cbse_10_005, c11_hin_ar_cbse_10_006, c11_hin_ar_cbse_10_007, c11_hin_ar_cbse_10_008, c11_hin_ar_cbse_10_009, c11_hin_ar_cbse_10_010, c11_hin_ar_cbse_10_011, c11_hin_ar_cbse_10_012, c11_hin_ar_cbse_10_013
## PREREQUISITE_REASONS
c11_hin_ar_cbse_10_001: Provides historical-biographical context (Meera's life, Rajput milieu) essential for situating arguments in social reality.
c11_hin_ar_cbse_10_002: Narrative structure of the pads (two-part progression) determines how students organize chronological or thematic essays.
c11_hin_ar_cbse_10_003: Atmosphere of devotion and suffering informs tone analysis in critical appreciation answers.
c11_hin_ar_cbse_10_004: Meera as protagonist — her agency, rebellion, spirituality — is the core subject of character-sketch questions.
c11_hin_ar_cbse_10_005: Supporting characters (Rana, in-laws, society) appear as foils in thematic answers on patriarchy/orthodoxy.
c11_hin_ar_cbse_10_006: Primary theme (nirgun-sagun bhakti synthesis) is the "Link" target for every PEEL paragraph.
c11_hin_ar_cbse_10_007: Secondary themes (gender, caste, body, autonomy) provide alternative essay angles beyond the main theme.
c11_hin_ar_cbse_10_008: Imagery and metaphor (fire, marriage, physician) are the *Evidence* students must quote and explain.
c11_hin_ar_cbse_10_009: Irony (physician as disease) and symbolism (fire = love = knowledge) are high-value analysis points for top-band answers.
c11_hin_ar_cbse_10_010: Key vocabulary (fxjèkj, lhafp, csfy, efFk) enables precise textual reference without full quotation.
c11_hin_ar_cbse_10_011: Grammar usage (Brajbhasha forms, verb patterns) helps students paraphrase accurately in Hindi.
c11_hin_ar_cbse_10_012: Literal/inferential comprehension ensures students don't misread the pads' surface meaning before analyzing.
c11_hin_ar_cbse_10_013: Critical interpretation skills (identifying subtext, ideology, resistance) are the *thinking* that writing makes visible.

## FORWARD_NODE_IDS
c11_hin_ar_cbse_10_015, c12_hin_a_cbse_05_014

## FORWARD_REASONS
c11_hin_ar_cbse_10_015: Written analytical responses (this node) become the prepared arguments, evidence bank, and rhetorical structures students deploy in speaking/listening assessments — debates, seminars, and viva voce on Meera's poetry.
c12_hin_a_cbse_05_014: अगला तार्किक चरण: Writing Skills based on the chapter refers to the ability to compose structured, evidence-based resp... इस नोड की अवधारणाओं को सीधे उपयोग/विस्तारित करता है।  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
none

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_10_013 -> c11_hin_ar_cbse_10_014 -> c11_hin_ar_cbse_10_015

## THIS_FORMULA
PEEL Framework for Literary Analysis:  
**P** = Point (Thesis/Claim answering the question)  
**E** = Evidence (Specific textual reference: line, image, device, word)  
**E** = Explanation (How the evidence works: device effect, connotation, irony, ambiguity)  
**L** = Link (Connect back to question + forward to broader theme: nirgun-sagun bhakti, social resistance, feminist reading)

## FORMULA_VARIABLES
P = One-sentence claim directly addressing the question keyword (e.g., "metaphor," "tone," "resistance")  
E = Textual detail from the prescribed pads (paraphrased line, identified device, or key word with pad/line reference)  
E = 2-3 sentences analyzing *how* the evidence creates meaning — not what it says  
L = 1 sentence tying the point to the chapter's central theme AND the question's demand

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
linguistic

## CROSS_SUBJECT
c11_history_bhakti_movement | The chapter's portrayal of Meera as a 16th-century Rajput princess rejecting sati, purdah, and caste norms mirrors the History syllabus's coverage of the Bhakti Movement's social challenge to Brahmanical patriarchy — writing answers here reinforces historical analysis of religion as protest.  
c11_sociology_gender_caste | Meera's subversion of "widowhood" (refusing sati, claiming Krishna as husband) and caste boundaries (mingling freely) provides a literary case study for Sociology's units on gendered rituals, caste endogamy, and women's agency in pre-modern India — analytical writing here builds sociological argumentation skills.  
c11_political_science_rights_dissent | The pads frame devotion as *consent* ("esjs rks fxjèkj xksiky" — *I* choose my lord) rather than duty, prefiguring Political Science concepts of individual autonomy, dissent against state/orthodoxy, and the body as site of resistance — writing skills transfer to framing rights-based arguments.

## PREREQ_CONCEPT
Literary analysis terminology (metaphor, imagery, tone, symbolism, irony) and the ability to distinguish *summary* (what happens) from *analysis* (how meaning is made).

## PREREQ_BEFORE
Student must have completed critical interpretation of both pads (node c11_hin_ar_cbse_10_013) — i.e., can orally explain *why* the marriage metaphor is subversive and *how* the fire imagery functions paradoxically.

## PREREQ_STUCK
If stuck, review c11_hin_ar_cbse_10_008 (Imagery and Metaphor) and c11_hin_ar_cbse_10_009 (Irony and Symbolism) — these provide the device-vocabulary needed for the Explanation step of PEEL.

## WORKED_EXAMPLE_1
PROBLEM: A Class 11 student writes this answer to a 5-mark question: "Meera's first pad shows her love for Krishna. She says he is her husband and no one else is hers. She calls her co-wives 'cSfB&cSfB' and says they are worldly. This shows her devotion." Identify the specific PEEL failures and rewrite the answer to score 5/5.

STEPS:
- Step 1: Diagnose the answer — it is entirely Point + weak Evidence (paraphrase), zero Explanation (no device analysis), zero Link (no theme connection).
- Step 2: Extract the usable kernel — the student correctly identifies the marriage metaphor and co-wife reference as central.
- Step 3: Upgrade to PEEL — craft a Point that answers "how" not "what": "Meera deploys the marriage metaphor to reconfigure devotion as exclusive, voluntary surrender that voids social kinship."
- Step 4: Insert precise Evidence: "Addressing Krishna as 'fxjèkj xksiky' and declaring 'esjks ifr lksbZ' (no one else is mine), she renames the co-wives 'cSfB&cSfB' (worldly, fleeting) — a metaphor transferring wifely duty from mortal rivals to the divine."
- Step 5: Add Explanation: "The Braj term 'fxjèkj' (husband) carries sacramental weight in Rajput culture; by applying it to Krishna, Meera performs a symbolic remarriage that nullifies her widowhood and the sati expectation, while 'cSfB&cSfB' reduces social relations to impermanence."
- Step 6: Close with Link: "Thus the pad establishes bhakti not as sentiment but as structural resistance — the first move in Meera's lifelong replacement of patriarchal order with divine sovereignty."

REASONING: The original answer fails because it treats the text as a story to retell. The rewrite succeeds by making every sentence *do analytical work*: the Point frames an argument, the Evidence names the device (metaphor, renaming), the Explanation unpacks cultural connotation (sacramental weight, widowhood nullification), and the Link scales up to the chapter's central thesis (bhakti as resistance). This mirrors the CBSE marking scheme's demand for "critical appreciation with textual support."

ANSWER: **Rewritten 5/5 answer:**  
Meera deploys the marriage metaphor to reconfigure devotion as exclusive, voluntary surrender that voids social kinship. Addressing Krishna as "fxjèkj xksiky" and declaring "esjks ifr lksbZ," she renames the co-wives "cSfB&cSfB" — a metaphor transferring wifely duty from mortal rivals to the divine. The Braj term "fxjèkj" carries sacramental weight in Rajput culture; by applying it to Krishna, Meera performs a symbolic remarriage that nullifies her widowhood and the sati expectation, while "cSfB&cSfB" reduces social relations to impermanence. Thus the pad establishes bhakti not as sentiment but as structural resistance — the first move in Meera's lifelong replacement of patriarchal order with divine sovereignty.

## WORKED_EXAMPLE_2
PROBLEM: "Compare the role of the body in the two prescribed pads of Meera." A student writes: "In the first pad, the body is not mentioned. In the second pad, Meera says her body burns and she is in pain. So the body is only in the second pad." Explain why this is a flawed comparison and write a correct comparative analysis using PEEL.

STEPS:
- Step 1: Identify the error — the student reads "body" literally (explicit mention) rather than as a *conceptual category* (embodiment, suffering, gendered corporeality).
- Step 2: Re-read Pad 1 for implicit body references — "fxjèkj" (husband implies marital body), "ifr" (relations imply kinship body), "cSfB&cSfB" (co-wives as embodied rivals).
- Step 3: Formulate a comparative Point: "Both pads center the female body, but Pad 1 treats it as a *site of social inscription* (wife, widow, co-wife) while Pad 2 treats it as a *site of spiritual transcription* (burning, pierced, healed by love)."
- Step 4: Evidence for Pad 1: "The metaphor 'fxjèkj' inscribes the body with marital duty; 'ifr lksbZ' erases kinship inscriptions; 'cSfB&cSfB' marks co-wives as bodily competitors."
- Step 5: Evidence for Pad 2: "Somatic imagery 'valqou ty lhafp&lhafp' (body burning), 'csfy iSQfy' (pierced), 'nfèk efFk ?k`r dkf<+ fy;ks' (physician-disease paradox) rewrites pain as sacred knowledge."
- Step 6: Explanation + Link: "The shift from social body to mystical body mirrors Meera's life — from princess constrained by Rajput bodily codes to saint whose stigmata authenticate her authority. Bhakti here is not escape *from* the body but its *reclamation*."

REASONING: Comparison questions require a *unified framework* (here: "body as site") applied to both texts, not a list of presences/absences. The PEEL structure forces the student to build that framework in the Point, then deploy differentiated Evidence/Explanation for each pad, and Link them through the chapter's arc. This is the "analytical comparison" pattern CBSE rewards in 6-8 mark questions.

ANSWER: **Correct comparative analysis:**  
Both pads center the female body, but Pad 1 treats it as a *site of social inscription* (wife, widow, co-wife) while Pad 2 treats it as a *site of spiritual transcription* (burning, pierced, healed by love). In Pad 1, the metaphor "fxjèkj" inscribes the body with marital duty; "ifr lksbZ" erases kinship inscriptions; "cSfB&cSfB" marks co-wives as bodily competitors for the husband's attention. In Pad 2, somatic imagery — "valqou ty lhafp&lhafp" (body burning), "csfy iSQfy" (pierced), "nfèk efFk ?k`r dkf<+ fy;ks" (physician-disease paradox) — rewrites pain as sacred knowledge where the healer *is* the wound. The shift from social body to mystical body mirrors Meera's life: from princess constrained by Rajput bodily codes to saint whose stigmata authenticate her authority. Bhakti here is not escape *from* the body but its *reclamation* — the central argument of the chapter's critical commentary.

## WORKED_EXAMPLE_3
PROBLEM: A 6-mark board question: "Meera's poetry blends the nirgun (formless) and sagun (with-form) traditions of bhakti. Discuss with reference to the prescribed pads and the chapter's critical commentary." Plan and write a full structured answer using PEEL for each paragraph (3 paragraphs = 3 PEEL cycles).

STEPS:
- Step 1: Unpack the question — key terms: "nirgun," "sagun," "blend," "prescribed pads," "critical commentary." Requires 3 distinct arguments (one per paragraph).
- Step 2: Argument 1 (Pad 1 = sagun dominance with nirgun undertone): Point — "Pad 1 presents Krishna as sagun beloved (fxjèkj xksiky) while the exclusivity 'ifr lksbZ' gestures toward nirgun non-duality." Evidence — "fxjèkj" (personal deity), "cSfB&cSfB" (worldly forms rejected). Explanation — Sagun form (Krishna) becomes the *gate* to formless truth (no other relations). Link — This mirrors the chapter's claim: "Ñ".k osQ izse dh nhokuh ehjk ij lwfI+kQ;ksa osQ izHkko" (nirgun influence visible).
- Step 3: Argument 2 (Pad 2 = nirgun intensity through sagun imagery): Point — "Pad 2 uses sagun bodily imagery (burning, piercing) to convey nirgun annihilation of self." Evidence — "valqou ty lhafp&lhafp," "csfy iSQfy," "nfèk efFk ?k`r dkf<+ fy;ks." Explanation — The body (sagun) is destroyed to realize the formless; the "physician" (guru/God) *is* the disease — non-dual paradox. Link — Confirms the commentary: "dyk dk vHkko gh mldh lcls cM+h dyk" (art's effect is its highest art — form dissolves in impact).
- Step 4: Argument 3 (Life-poetry synthesis = lived synthesis): Point — "The critical commentary frames Meera's life as the *enactment* of this blend: sagun rituals (temple worship) serving nirgun liberation (caste/gender transcendence)." Evidence — "nkf;Ro vkSj oqQy dh e;kZnk... lkekftd vkSj oSpkfjd caèkuksa dk ges'kk fojksèk" (exposed social/religious hypocrisies). Explanation — Her public sagun worship (dancing before Krishna) *performs* nirgun equality (no purdah, no caste barrier). Link — The pads are not poems *about* synthesis; they *are* the synthesis in language — sagun words carrying nirgun realization.
- Step 5: Assemble with transitions — each paragraph ends by forwarding the next: "Pad 1 opens the door... Pad 2 walks through it... The commentary shows Meera *living* the threshold."
- Step 6: Final polish — check each paragraph has P-E-E-L, Hindi terminology (nirgun/sagun), and board-exam tone (assertive, analytical, no "I think").

REASONING: High-mark questions require *sustained multi-paragraph argumentation*, not a single PEEL. This worked example teaches students to *segment* a complex prompt into 3-4 sub-claims, each getting a full PEEL cycle, with transitions that show architectural thinking. The nirgun/sagun blend is the chapter's *interpretive key* (explicit in commentary) — mastering this answer pattern prepares students for any "discuss with reference to text and commentary" question in Hindi Core.

ANSWER: **Full 6-mark structured answer (3 PEEL paragraphs):**  

**Paragraph 1 (Sagun form as gateway to nirgun truth):**  
Meera's first pad presents Krishna as a sagun beloved — "fxjèkj xksiky" (my husband Krishna) — while the declaration "esjks ifr lksbZ" (no one else is mine) gestures toward nirgun non-duality. The metaphor "fxjèkj" anchors devotion in a personal, formed deity accessible to human love, yet the exclusivity it demands — rejecting all "cSfB&cSfB" (worldly, fleeting relations) — mirrors the nirgun insistence on *ekatva* (oneness). Sagun form here is not an end but a *gate*: the intensity of singular attachment to Krishna dissolves the multiplicity of social bonds, enacting the commentary's observation that "Ñ".k osQ izse dh nhokuh ehjk ij lwfI+kQ;ksa osQ izHkko" (nirgun influence is visible in Meera).  

**Paragraph 2 (Sagun body transmuted into nirgun fire):**  
The second pad intensifies this blend by using sagun bodily imagery — "valqou ty lhafp&lhafp" (body burning), "csfy iSQfy" (pierced) — to convey nirgun annihilation of the separate self. The paradox "nfèk efFk ?k`r dkf<+ fy;ks" (the physician himself is the disease) collapses the duality of healer/patient, subject/object — a hallmark of nirgun realization where God is not *other* but the very process of dissolution. The sagun body becomes the *fuel* for nirgun fire; form is consumed to reveal the formless, confirming the chapter's aesthetic principle: "dyk dk vHkko gh mldh lcls cM+h dyk" (art's effect is its highest art).  

**Paragraph 3 (Life as the lived synthesis of text and commentary):**  
The critical commentary frames Meera's life as the *enactment* of this poetic blend: sagun rituals (temple worship, kirtan) serving nirgun liberation (caste/gender transcendence). Her public devotion — "nkf;Ro vkSj oqQy dh e;kZnk osQ uke ij yxk, x, lkekftd vkSj oSpkfjd caèkuksa dk ges'kk fojksèk" (exposing social and religious hypocrisies in the name of widowhood and purity) — uses sagun bhakti's visibility to dismantle nirgun barriers. The pads are not poems *about* synthesis; they *are* the synthesis in language — sagun words (husband, fire, physician) carrying nirgun realization (non-duality, ego-death, freedom). Meera thus embodies the chapter's thesis: bhakti as "eqfDr" (liberation) achieved *through* "Kku" (knowledge) mediated by "laokn" (dialogue/communion) — the very structure of her poetry.

## COMPETENCY_QUESTION_1
QUESTION: A Class 11 student is asked: "How does Meera use the image of 'fire' (lhafp) in the second pad to redefine suffering?" The student writes: "Meera says her body burns with fire. This shows she is in pain because of love. Fire is a symbol of love's intensity." The teacher returns it with "Summary, not analysis. Rewrite using PEEL." Rewrite the answer correctly, showing all four PEEL components explicitly labeled.

COMPETENCY: Literary analysis writing — converting summary to analysis using PEEL framework

STEPS:
- Step 1: Identify the student's Point (implicit: fire shows love's intensity) — too vague, not arguable.
- Step 2: Sharpen the Point: "Meera reconfigures fire from a destructive force into a *purificatory knowledge* that transforms the sufferer into a knower."
- Step 3: Select precise Evidence: "valqou ty lhafp&lhafp" (body burning continuously), "nfèk efFk ?k`r dkf<+ fy;ks" (physician = disease).
- Step 4: Write Explanation: The reduplication "lhafp&lhafp" suggests *chronic, deliberate* burning — not accidental but sustained. The physician-disease paradox means the *source* of pain (love/Krishna) is also the *cure* — suffering is not to be removed but *understood*.
- Step 5: Write Link: This redefinition aligns with the chapter's nirgun framework where "Kku" (knowledge) arises from "laokn" (communion) — fire is the medium of that communion.

ANSWER:  
**P (Point):** Meera reconfigures fire from a destructive force into a *purificatory knowledge* that transforms the sufferer into a knower.  
**E (Evidence):** The reduplicated imagery "valqou ty lhafp&lhafp" (body burning continuously) and the paradox "nfèk efFk ?k`r dkf<+ fy;ks" (the physician himself is the disease).  
**E (Explanation):** The iterative "lhafp&lhafp" marks the burning as *chronic and deliberate* — not accidental pain but sustained spiritual practice. The physician-disease identity means the *source* of suffering (love/Krishna) is also its *meaning*; the cure is not removal but *recognition* — the devotee becomes the "efFk" (knower) through "lhafp" (burning).  
**L (Link):** This aligns with the chapter's nirgun framework where "Kku" (knowledge) arises from "laokn" (communion) and "eqfDr" (liberation) follows "Hkkouk" (longing) — fire is the medium of that transformative communion, making suffering the *method* of bhakti, not its obstacle.

DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: "Meera's pads in Aroh Chapter 10 are not just devotional poems; they are political acts of resistance." Write a 200-word analytical essay defending this statement. Your answer must: (a) define "political" in this context, (b) use evidence from *both* pads, (c) incorporate the chapter's critical commentary, (d) employ at least three literary device terms (metaphor, irony, symbolism, imagery, tone), and (e) follow PEEL structure across 3 paragraphs.

COMPETENCY: Synthesis writing — integrating textual analysis, critical commentary, and theoretical framing into a sustained argument

STEPS:
- Step 1: Define "political" in the opening thesis — not party politics but *power relations*: patriarchy, caste, royal authority, religious orthodoxy.
- Step 2: Paragraph 1 (Pad 1 = resistance to patriarchal kinship): Point — Marriage metaphor as political refusal. Evidence — "fxjèkj xksiky," "ifr lksbZ," "cSfB&cSfB." Devices — metaphor, tone (declarative). Explanation — Voids widowhood, sati, purdah. Link — First political act: claiming sovereignty over self.
- Step 3: Paragraph 2 (Pad 2 = resistance to medicalized/orthodox control): Point — Fire imagery resists the "physician" (priest/doctor/state). Evidence — "valqou ty lhafp&lhafp," "nfèk efFk ?k`r dkf<+ fy;ks." Devices — irony, paradox, somatic imagery. Explanation — The body refuses external cure; pain becomes autonomous knowledge. Link — Second political act: epistemic sovereignty.
- Step 4: Paragraph 3 (Commentary = historical confirmation): Point — The prose commentary reads the poems as *enacted* resistance. Evidence — "nkf;Ro vkSj oqQy dh e;kZnk... caèkuksa dk ges'kk fojksèk," "inkZ izFkk dk Hkh ikyu ugha fd;k." Devices — symbolism (body as site), narrative framing. Explanation — Life validates text; text theorizes life. Link — Synthesis: poetry as praxis.
- Step 5: Polish for flow, terminology density, and board-exam concision.

ANSWER:  
Meera's pads are political acts because they contest the *power relations* that define a 16th-century Rajput woman: patriarchal kinship, caste endogamy, royal authority, and Brahmanical orthodoxy. "Political" here means the struggle over who controls the female body, its labor, its rituals, and its meaning.  

In Pad 1, the marriage metaphor functions as a *political refusal*. By naming Krishna "fxjèkj xksiky" and declaring "esjks ifr lksbZ," Meera voids the widow's script — no sati, no purdah, no levirate. The declarative tone ("esjs rks...") claims sovereignty: she *chooses* her lord, rejecting the "cSfB&cSfB" (fleeting, worldly) kinship network that would dispose of her body. The metaphor transfers wifely allegiance from mortal husband to divine, making devotion a *legal* act of self-possession.  

Pad 2 escalates this to *epistemic resistance*. The somatic imagery — "valqou ty lhafp&lhafp," "csfy iSQfy" — and the ironic paradox "nfèk efFk ?k`r dkf<+ fy;ks" (physician = disease) reject external authority over her suffering. The "physician" represents priest, doctor, king — all who claim to *cure* her deviance. Meera's body, burning with love, becomes a *site of autonomous knowledge*: pain is not pathology but revelation. The irony dismantles the cure/control binary.  

The critical commentary confirms this reading as *history*, not metaphor: "nkf;Ro vkSj oqQy dh e;kZnk osQ uke ij yxk, x, lkekftd vkSj oSpkfjd caèkuksa dk ges'kk fojksèk" — she exposed hypocrisies *in the name of* widowhood and purity. Her refusal of "inkZ izFkk" (purdah) and "lkoZtfud ukpus&xkus" (communal dining) enact the pads' politics. The poems are not *about* resistance; they *are* resistance — language as praxis, bhakti as revolution.

DIFFICULTY: hard