## DEFINITION
Plot in a narrative poem refers to the sequence of events arranged by the poet to convey a story, while narrative structure is the deliberate organization of those events — such as chronological order, flashbacks, or parallel timelines — to shape meaning and emotional impact. In "लज्जत लेखा", the poet uses a non-linear structure opening with a portrait, then moving through memory to reveal the protagonist's life and death.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student can independently map the narrative arc of the poem, identify structural devices (e.g., frame, flashback, circular ending), and explain how the chosen structure reinforces the central theme of fleeting life and memory.

## SCOPE_BOUNDARY
This node covers analysis of plot sequence and narrative structure in the poem "लज्जत लेखा" only. It does not cover detailed character analysis, thematic exploration, or literary devices beyond structural ones — those are addressed in subsequent nodes.

## WALKTHROUGH
Imagine you open a family album and see a faded photograph of a young woman you never met. The photo sparks curiosity: Who was she? What happened? The poem "लज्जत लेखा" works exactly like that — it begins with a portrait (the frame), then takes you backward into her childhood, forward to her marriage, and ends with her untimely death, before returning to the poet’s present reflection. To analyze its structure, first read the poem aloud to hear the shifts in time. Next, mark each stanza with a temporal marker: "present", "past childhood", "marriage", "death", "present again". Then ask: Why does the poet start at the end? How does this order deepen the sense of loss? The key insight is that structure is not just a container — it *is* the meaning.

## DIAGNOSTIC_QUESTION_1
Define "plot" and "narrative structure" in the context of a narrative poem. How do they differ from a simple summary?

## DIAGNOSTIC_ANSWER_1
Plot is the causal sequence of events (what happens and why); narrative structure is the artistic arrangement of those events (order, pacing, perspective). A summary merely lists events in chronological order, ignoring the poet's deliberate reordering for effect. A wrong answer that equates plot with summary reveals the student confuses *content* with *form* — a critical error in board answers where "structure" carries separate marks.

## DIAGNOSTIC_QUESTION_2
The poem opens with the line "ns[kk fookg vkewy uoy" (I saw a portrait...). Why does the poet choose to begin with the portrait rather than the protagonist's birth or childhood? Explain in your own words.

## DIAGNOSTIC_ANSWER_2
The portrait acts as a *frame* — it anchors the reader in the poet's present moment of discovery, creating mystery and emotional distance before diving into the past. This mirrors how memory works: we encounter traces (photos, objects) before reconstructing stories. A wrong answer that says "to introduce the character" misses the structural function: the frame controls *how* we receive the story, not just *what* we learn.

## DIAGNOSTIC_QUESTION_3
Given the following stanza from another narrative poem: "The letter arrived at noon / Her hands shook as she broke the seal / Ten years earlier he had sailed / Now the sea gave back its due." Identify the narrative structure used here and explain its effect in 2-3 sentences.

## DIAGNOSTIC_ANSWER_3
This uses a *flashback* structure: the present moment (letter arrival) triggers a jump to the past (his sailing). The effect is to compress time, making the past feel immediate and the loss sudden. A wrong answer that only identifies "past and present" without naming "flashback" or explaining the emotional compression shows inability to apply structural terminology — a skill tested in both board and CUET questions.

## DIAGNOSTIC_QUESTION_4
Compare the narrative structure of "लज्जत लेखा" with a traditional linear short story. Identify two structural differences and explain how each difference serves the poem's theme of impermanence.

## DIAGNOSTIC_ANSWER_4
Difference 1: The poem uses a *circular frame* (portrait → memory → portrait) while a linear story moves straight from birth to death. The circle mimics the mind's return to a fixed image, emphasizing that memory is static while life flows. Difference 2: The poem condenses decades into stanzas, skipping transitional events — this elliptical pacing mirrors how grief telescopes time. A wrong answer that only lists "non-linear vs linear" without linking to theme fails the "analyze" requirement of competency questions.

## DIAGNOSTIC_QUESTION_5
Critique the following student claim: "The poem would be clearer if the poet told the story in chronological order from childhood to death." Defend or refute using evidence from the poem's structure.

## DIAGNOSTIC_ANSWER_5
Refute. Chronological order would dilute the central irony: the portrait *is* the only tangible remains of a life that vanished. Starting with the portrait forces the reader to experience the same shock and curiosity as the poet. The non-linear structure *enacts* the theme — life is not lived in order, it is remembered in fragments. A wrong answer that agrees with the student reveals a preference for clarity over artistic intent, missing the core literary principle that form *is* content.

## DIAGNOSTIC_QUESTION_6
Write a 4-stanza narrative poem (4 lines each) about a personal object (e.g., a watch, a letter, a toy) that uses a frame structure similar to "लज्जत लेखा": begin with the object in the present, flashback to its origin, show a turning point, and end back at the object with changed meaning.

## DIAGNOSTIC_ANSWER_6
A successful poem will: (1) Stanza 1 — describe the object now (dusty, kept), (2) Stanza 2 — flashback to when it was new/given, (3) Stanza 3 — a moment of crisis or change involving the object, (4) Stanza 4 — return to the object now, but with emotional weight (e.g., "I wind it still / though its hands froze / the day you left"). A poor answer that writes a linear story without the frame shows inability to *create* using the structural concept — the highest Bloom level.

## COMMON_MISCONCEPTION
Students often treat "plot" as a mere list of "what happens" and "structure" as synonymous with "paragraphs" or "stanzas". In "लज्जत लेखा", they write: "First the poet sees a portrait, then he describes her childhood, then marriage, then death." This ignores *why* the poet orders events this way — the portrait is not just the first event; it is a structural frame that shapes the entire reading experience. The misconception arises because school summaries train students to retell chronologically, but board exams ask "How does the structure contribute to meaning?" — a question that cannot be answered by a timeline.

## ON_FAILURE
If a student cannot distinguish plot from structure: (1) Give them a 3-sentence story: "She died. She was born. She lived." Ask: "Is this a plot? Why/why not?" (2) Show the same events in chronological order vs the poem's order. Ask: "What changes in how you feel?" (3) Have them draw a *story map* with arrows for time jumps, labeling each jump (frame, flashback, return). (4) Re-diagnose using Diagnostic Question 2 — if they now mention "frame" or "mystery", the misconception is broken.

## BUILDS_ON
Understanding of basic story elements (beginning, middle, end) from Class 11 narrative analysis (c11_hin_ar_cbse_01_002).

## LEADS_TO
Character analysis (c12_hin_a_cbse_02_004) because narrative structure determines *when* and *how* we meet the protagonist.

## PREREQUISITE_NODE_IDS
c12_hin_a_cbse_02_001, c11_hin_ar_cbse_01_002, c11_hin_ar_cbse_02_002
## PREREQUISITE_REASONS
c12_hin_a_cbse_02_001: Provides biographical and historical context (poet's life, era) essential to interpret why the poet chooses this structure.
c11_hin_ar_cbse_01_002: Introduces plot vs structure distinction in Class 11 — this node deepens it for board-level analysis.
c11_hin_ar_cbse_02_002: Reinforces narrative structure concepts with a different text, allowing transfer of skill.

## FORWARD_NODE_IDS
c12_hin_a_cbse_02_003, c12_hin_a_cbse_02_004, c12_hin_a_cbse_02_006, c12_hin_a_cbse_02_005, c12_hin_a_cbse_02_007, c12_hin_a_cbse_02_008, c12_hin_a_cbse_02_012, c12_hin_a_cbse_02_013

## FORWARD_REASONS
c12_hin_a_cbse_02_003: Setting and atmosphere are revealed *through* the narrative structure (e.g., the portrait's room vs the remembered village).
c12_hin_a_cbse_02_004: Character analysis depends on structural choices — we know the protagonist only through the framed memories.
c12_hin_a_cbse_02_006: Primary theme (impermanence) is enacted by the circular, fragmented structure.
c12_hin_a_cbse_02_005: Narrative structure knowledge helps locate where supporting characters appear in the poem's progression.  
c12_hin_a_cbse_02_007: Narrative structure knowledge helps locate where secondary themes surface in the poem's progression.  
c12_hin_a_cbse_02_008: Narrative structure tells us *where* devices cluster (stanza 1 vs 3).  
c12_hin_a_cbse_02_012: Plot/narrative structure provides the sequence of events to locate literal answers.  
c12_hin_a_cbse_02_013: Supplies narrative structure knowledge to analyze how the poem's "story" is organized.  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
c12_history_02_001: Historical context of early 20th-century North Indian social customs (child marriage, widowhood) informs the plot events the poet selects and orders.
c12_psychology_02_001: Memory psychology (flashbulb memories, reconstructive nature) explains why the poem's structure mimics cognitive processes — a cross-disciplinary lens for "why this structure?".

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_01_002 -> c12_hin_a_cbse_02_002 -> c12_hin_a_cbse_02_004

## THIS_FORMULA
N/A - conceptual

## FORMULA_VARIABLES
N/A

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
conceptual

## CROSS_SUBJECT
N/A | The poem's plot events (child marriage, early death) reflect historical social realities; analyzing structure requires knowing which events are historically typical vs individually tragic.
 N/A | The frame-flashback-frame structure mirrors how autobiographical memory works — the "self" is constructed through narrative identity, a concept from narrative psychology.
## PREREQ_CONCEPT
Ability to distinguish *chronological order* (time sequence of events) from *narrative order* (presentation sequence in the text).

## PREREQ_BEFORE
Student must be able to identify the basic events of the poem in chronological order (birth → childhood → marriage → death → portrait) before analyzing why the poet reorders them.

## PREREQ_STUCK
If stuck, review Class 11 node c11_hin_ar_cbse_01_002 "Text: Plot and Narrative Structure" — specifically the worked example on flashback in "उषा" poem.

## WORKED_EXAMPLE_1
PROBLEM: Map the narrative structure of "लज्जत लेखा" by labeling each stanza with its temporal setting and structural function (e.g., frame, flashback, climax, resolution). Use the poem's 5 stanzas as given in the textbook.

STEPS:
- Step 1: Read the poem once silently, then aloud. Mark any time-indicating words: "ns[kk" (saw - present), "ek¡ dh oqQy" (mother's early teaching - past), "vkdk'k cny dj" (time changed - transition), "eq> HkkX;ghu dh rw lacy" (father's letter later - further past), "ctzikr" (final plea - present/future).
- Step 2: Identify the *frame*: Stanza 1 (portrait in present) and Stanza 5 (poet's vow at the portrait) form the opening and closing frame. Label both "Frame - Present".
- Step 3: Identify the *flashback sequence*: Stanza 2 (mother's teaching, childhood), Stanza 3 (marriage, "vkdk'k cny dj"), Stanza 4 (father's letter, death). Label these "Flashback - Childhood", "Flashback - Marriage", "Flashback - Death" respectively.
- Step 4: Note the *non-chronological order*: The poem moves Present → Childhood → Marriage → Death → Present. The chronological order would be Childhood → Marriage → Death → Portrait → Poet's reflection. The poet omits the portrait's creation and the long gap after death.
- Step 5: Interpret the structural effect: The frame creates a "bookend" that traps the life story inside a single gaze. The elliptical flashback (skipping years) mimics memory's selectivity. The return to frame in Stanza 5 transforms the portrait from an object into a promise ("viZ.k dj] djrk eSa rsjk riZ.k").

REASONING: This 5-step mapping forces the student to separate *what happens* (plot) from *how it's told* (structure), then link each structural choice to thematic meaning — the exact skill tested in 4-6 mark board questions.

ANSWER:
Stanza 1: Frame (Present) — Portrait discovery.
Stanza 2: Flashback (Childhood) — Mother's teaching, "lq[k&nq[k esa jgs".
Stanza 3: Flashback (Marriage) — "vkdk'k cny dj cuk egh", shift to marital home.
Stanza 4: Flashback (Death) — Father's letter, "nq[k gh thou dh dFkk jgh".
Stanza 5: Frame (Present) — Poet's vow at the portrait.
Structural insight: The circle (frame-flashback-frame) enacts the theme — life is a fleeting story held in a static image.

## WORKED_EXAMPLE_2
PROBLEM: The poem uses "elliptical narration" — it skips large time gaps (e.g., between marriage and death). Choose one gap and explain how the omission serves the poem's emotional design.

STEPS:
- Step 1: Identify a major time gap. The jump from Stanza 3 (marriage, "xk;k LoxhZ;k&fiz;k&lax") to Stanza 4 (father's letter announcing death, "gks x;k C;kg") skips the entire married life — possibly years.
- Step 2: Ask what *would* be in the gap: daily routines, children, joys, sorrows. The poet deliberately excludes them.
- Step 3: Connect omission to the poem's central image: "लज्जत लेखा" means "account of shame/regret" or "taste of memory". The gaps *are* the regret — what is left out hurts more than what is told.
- Step 4: Compare with a linear biography: a biography would fill the gap; the poem's power comes from the silence. The father's letter ("eq> HkkX;ghu dh rw lacy") arrives like a sudden blow — no buildup, no preparation.
- Step 5: Formulate the analytical point: Elliptical narration mimics grief's shock. The reader, like the poet, is denied the "middle" of the story, forced to confront the end abruptly.

REASONING: This example teaches students to analyze *absence* as a structural device — a sophisticated move that distinguishes high-scoring answers (which discuss "silences", "gaps", "ellipsis") from average ones (which only discuss what is present).

ANSWER:
The gap between marriage and death (Stanza 3 to 4) is the most significant ellipsis. By skipping the married life, the poet denies the reader any comfort of a "full life lived". The sudden father's letter — "nq[k gh thou dh dFkk jgh" — lands with the weight of the unspoken years. The structure thus performs the theme: life is not in the living, but in the fragments that remain.

## WORKED_EXAMPLE_3
PROBLEM: Compare the narrative structure of "लज्जत लेखा" with that of the poem "उषा" (Class 11, Chapter 1) which also uses a frame-flashback structure. Identify one similarity and one difference in how each uses the frame to convey its theme.

STEPS:
- Step 1: Recall "उषा" structure: Opens with dawn (frame), flashes back to the poet's childhood memory of dawn, returns to present dawn with changed perception. Theme: continuity of nature vs human transience.
- Step 2: Recall "लज्जत लेखा" structure: Opens with portrait (frame), flashes back through life events, returns to portrait with vow. Theme: fragility of life, duty of memory.
- Step 3: Similarity: Both use a *circular frame* (present → past → present) to show how the present moment is haunted/transformed by the past. The frame is not decorative — it is the lens.
- Step 4: Difference: In "उषा", the frame (dawn) is a *natural, recurring phenomenon* — the return brings acceptance. In "लज्जत लेखा", the frame (portrait) is a *human artifact, singular and final* — the return brings responsibility ("viZ.k dj] djrk eSa rsjk riZ.k").
- Step 5: Synthesize: The similarity shows a shared literary tradition (frame narrative in Hindi poetry). The difference reveals each poet's philosophical stance: nature's eternity vs human mortality.
- Step 6: Board-exam application: A question asking "Compare the use of frame narrative in two poems you have studied" would reward this exact comparative structure.

REASONING: This worked example models the *comparative analysis* required in competency-based questions (CBSE 2024+ pattern) and CUET. It forces the student to move beyond single-text analysis to intertextual structural reasoning.

ANSWER:
Similarity: Both poems employ a circular frame (present → past → present) where the opening image (dawn/portrait) is revisited at the end with transformed significance — the frame encloses and gives meaning to the flashback.
Difference: "उषा" uses a natural, cyclical frame (dawn) suggesting renewal and continuity; "लज्जत लेखा" uses a static, human-made frame (portrait) suggesting finality and the burden of remembrance. The former resolves in acceptance; the latter resolves in active commitment ("riZ.k").

## COMPETENCY_QUESTION_1
QUESTION: A student writes in the board exam: "The plot of 'लज्जत लेखा' is that a girl is born, grows up, gets married, and dies young. The poet sees her portrait and feels sad." The examiner awards 1 out of 4 marks. Using your knowledge of plot vs narrative structure, rewrite the answer to earn full marks. Your rewrite must include: (a) correct terminology, (b) identification of structural devices, (c) link to theme.

COMPETENCY: Critical analysis of narrative structure with precise terminology

STEPS:
- Step 1: Identify the errors in the student's answer: (i) Confuses plot with chronological summary, (ii) Omits structural terms (frame, flashback, elliptical narration), (iii) No link between structure and theme.
- Step 2: Apply the correct framework: Plot = causal sequence; Structure = frame-flashback-frame with elliptical gaps.
- Step 3: Draft the improved answer using PEEL: Point (structure), Evidence (stanza references), Explanation (effect), Link (theme).
- Step 4: Verify against marking scheme: 1 mark for terminology, 1 for device identification, 1 for effect analysis, 1 for theme link.

ANSWER:
"The poem employs a **circular frame narrative**: it opens and closes at the portrait (Stanzas 1 & 5), enclosing an **elliptical flashback sequence** (Stanzas 2–4) that jumps from childhood to marriage to death, omitting the intervening years. This **non-linear structure** mirrors the fragmentation of memory — the portrait is not merely an illustration but a **structural frame** that forces the reader to experience the life as a recovered fragment. The **ellipsis** between marriage and death (Stanza 3 to 4) enacts the theme of life's brevity: we are denied the 'middle', confronted only with the sudden end ('nq[k gh thou dh dFkk jgh'). Thus, structure *performs* the central idea — memory is not a full story but a 'लज्जत लेखा', a taste of regret."

DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: The poem's final stanza contains the line: "bl iFk ij] esjs dk;Z ldy gksa Hkz"V 'khr osQ&ls 'krny!" (Let my work be complete on this very spot, shedding drops of blood!). Some critics argue this vow *breaks* the poem's elegiac tone, turning it into a heroic resolution. Evaluate this claim by analyzing how the narrative structure prepares for or contradicts this ending.

COMPETENCY: Evaluative interpretation of structural closure

STEPS:
- Step 1: Define "elegiac tone" — mournful, reflective, accepting loss.
- Step 2: Trace the structural buildup: Frame (portrait) → Flashback (life) → Frame (portrait). The return to frame in Stanza 5 is *not* a simple return — the poet now speaks *to* the portrait, making a vow.
- Step 3: Analyze the shift: The first frame was observational ("ns[kk fookg"); the second frame is performative ("viZ.k dj] djrk eSa rsjk riZ.k"). The structure *demands* action because the flashback revealed a life cut short — the poet inherits the unfinished "dk;Z".
- Step 4: Evaluate the critic's claim: The vow does not *break* the elegiac tone; it *completes* it. The circular structure would be hollow if it ended in mere sadness. The "heroic" vow is the only logical closure for a frame that began with a silent portrait — the portrait *speaks* through the poet.
- Step 5: Conclude: The structure (frame → flashback → transformed frame) is designed precisely to convert passive grief into active remembrance. The critic mistakes *intensification* for *contradiction*.

ANSWER:
The claim misreads the structural logic. The poem's circular frame is not a static picture frame but a dynamic *speech act*: the first frame is the poet *seeing*; the flashback is the poet *receiving* the life story; the final frame is the poet *answering*. The vow ("riZ.k") is the structural payoff of the elliptical flashback — because the life was truncated (gaps, sudden death), the memory-bearer must "complete the work". The elegiac tone deepens into ethical commitment; it does not vanish. The structure *requires* this transformation — without it, the frame would be decorative, not meaningful.

DIFFICULTY: hard