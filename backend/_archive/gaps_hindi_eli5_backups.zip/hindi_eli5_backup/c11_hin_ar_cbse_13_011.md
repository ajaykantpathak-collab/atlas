## DEFINITION
Language Usage in the Text refers to the systematic analysis of grammatical structures, syntactic patterns, morphological choices, and phonological features employed by the poet to create specific aesthetic and semantic effects in the poem, moving beyond mere identification of literary devices to understanding how language *functions* as a meaning-making system.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student must be able to deconstruct a given stanza from the poem to identify at least three distinct grammatical/syntactic features (e.g., case endings, verb aspect, word order inversion, compound formation) and explain how each feature contributes to the poem's tone, rhythm, or thematic emphasis in a structured analytical paragraph.

## SCOPE_BOUNDARY
This node covers grammatical and linguistic analysis of the poem 'lk;s esa /wi' including syntax (word order, ellipsis), morphology (compound words, derivational suffixes), phonology (sound patterns, rhyme), and poetic license (deviation from standard grammar). It does NOT cover literary device identification (metaphor, irony - covered in c11_hin_ar_cbse_13_008, 009) or vocabulary meanings (covered in c11_hin_ar_cbse_13_010).

## WALKTHROUGH
Imagine you are listening to a street play where the actor suddenly switches from formal Hindi to a rustic dialect for just one line - you instinctively feel the shift in authenticity and emotion. Similarly, when you read Nagarjun's poem, you might stumble over phrases like "fpjkxk¡ gjsoQ" or "fly ns 'kqcku 'kk;j" because they don't follow standard textbook grammar. Begin by reading the poem aloud twice: first for flow, second with a pencil marking every word that feels "grammatically unusual" - unexpected case endings, missing verbs, inverted order, or coined compounds. Ask: "Why did the poet break the rule *here*?" The key insight is that in poetry, grammatical deviation is never accidental; it is a calibrated tool to compress meaning, mimic speech rhythms, or foreground the speaker's lived reality.

## DIAGNOSTIC_QUESTION_1
Identify the grammatical term for the formation of the word "eqrebu" (vk'oLr) as used in the poem's third stanza, and state the root word and suffix involved.

## DIAGNOSTIC_ANSWER_1
The word "eqrebu" is a **tatsama** derivative formed from the root "eqre" (vk'kq) + suffix "bu" (cqd) functioning as an adjective meaning 'influential/powerful'. A wrong answer (e.g., calling it a samasa or ignoring the suffix) reveals the student cannot distinguish between derivational morphology (word formation) and compounding, a critical gap for analyzing poetic neologisms.

## DIAGNOSTIC_QUESTION_2
Explain in your own words why the poet uses the oblique case form "nj[rksa" (isM+) in the first line of stanza one instead of the direct case "nj[k", and what syntactic role it plays in the phrase "nj[rksa osQ lk;s esa /wi yxrh gS".

## DIAGNOSTIC_ANSWER_2
"nj[rksa" is the **oblique plural** form required because it is governed by the postposition "osQ" (genitive case marker). The phrase means "darkness resides in the lanes of the settlement". A wrong answer (e.g., saying it's direct case or subject) shows the student misses how case governance dictates noun morphology in Hindi, leading to misparsing of the spatial relationship central to the poem's setting.

## DIAGNOSTIC_QUESTION_3
Apply the concept of **ellipsis (lghu)** to the second stanza's opening line: "dgk¡ rks r; Fkk fpjkxk¡ gjsoQ ?kj osQ fy,]". Reconstruct the full implied sentence, identify the omitted verb, and explain how its absence affects the stanza's rhythm.

## DIAGNOSTIC_ANSWER_3
Full reconstruction: "dgk¡ rks r; Fkk [th] fpjkxk¡ gjsoQ ?kj osQ fy,]". The copula "th" (was) is omitted. This ellipsis creates a telegraphic, memory-like fragmentation, accelerating the pace to mimic the fleeting nature of recollection. A wrong answer (failing to identify the omitted copula or its rhythmic function) indicates the student treats poetry as prose with line breaks, missing how grammatical economy drives poetic tempo.

## DIAGNOSTIC_QUESTION_4
Analyze the compound word "fly ns 'kqcku 'kk;j" in the final stanza. Break it into its constituent morphemes, identify the samasa type for each segment, and explain how the compounding compresses the socio-political critique.

## DIAGNOSTIC_ANSWER_4
"fly" (fruit/result) + "ns" (genitive postposition, frozen) + "'kqcku" (dry/hard) + "'kk;j" (twig/branch) = **Bahuvrihi compound** functioning as an adjective: "he whose twig is the dry fruit of power". The frozen genitive "ns" and bahuvrihi structure fuse 'power', 'barrenness', and 'fragility' into a single epithet for the ruler. A wrong answer (treating as separate words or misidentifying samasa) reveals inability to see how morphological fusion encodes layered satire in a single breath.

## DIAGNOSTIC_QUESTION_5
Evaluate the poet's deliberate use of **non-standard verb agreement** in "u gks deh”k rks ik¡oksa ls isV <¡d ysaxs" (If not the body, then bones will be picked from the streets). Does the plural verb "ysaxs" agree with "ik¡oksa" (plural) or "deh”k" (singular)? Defend your answer with grammatical reasoning and thematic justification.

## DIAGNOSTIC_ANSWER_5
The verb "ysaxs" (plural, future) agrees with **"ik¡oksa"** (plural subject), not "deh”k". Grammatically, the conditional "u gks deh”k" sets up a hypothetical where "ik¡oksa" becomes the active subject of the main clause. Thematically, this shift from singular body to plural bones **enacts the fragmentation of the individual into collective debris**, reinforcing the poem's theme of dehumanization. A wrong answer (claiming agreement with 'deh"k' or ignoring agreement) shows the student misses how grammatical number operates as a semantic device.

## DIAGNOSTIC_QUESTION_6
Create a new two-line stanza in Nagarjun's style for this poem, using **at least two grammatical deviations** (e.g., case stacking, verb ellipsis, inverted word order, coined compound) to depict a modern urban struggle (e.g., gig worker, migrant laborer). Annotate your deviations.

## DIAGNOSTIC_ANSWER_6
**Stanza:**  
"App osQ fy, rks Hkh 'kjhj ugha mils]  
Rating osQ dkj.k jindgi gys yxhA"  

**Deviations annotated:**  
1. **Case Stacking/Genitive Chain**: "App osQ fy," (for the sake of App) - frozen English genitive in Hindi syntax, mimicking corporate jargon intrusion.  
2. **Verb Ellipsis**: "jindgi gys yxhA" (life has stalled) - omission of auxiliary "h" (hai) in "gys yxh" for "gayi hai", creating a truncated, exhausted rhythm.  
A poor answer (standard grammar, no annotation, or deviations without poetic function) reveals the student views grammar as rigid rules rather than a flexible resource for voice.

## COMMON_MISCONCEPTION
Students often conflate **'grammatical analysis'** with **'literary device spotting'**. They identify "metaphor in line 3" but cannot explain *how* the genitive case in "fpjkxk¡ gjsoQ" constructs that metaphor spatially. They treat the poem's language as decorative vocabulary rather than a syntactic engine. For example, they miss that "csdjkj" (cspSu) is not just a 'difficult word' but a **tatsama adjective in predicative position** implying innate, unchangeable poverty, distinct from a mere synonym swap.

## ON_FAILURE
1. **Isolate the syntax**: Take one troubling line (e.g., "rsjk fu”kke gS fly ns 'kqcku 'kk;j dh"). Write its **standard Hindi prose paraphrase** ("uska shasan us sukhi twig ke phal jaisa hai").  
2. **Map deviations**: List every difference: word order (SOV vs OSV), compound fusion ("fly ns 'kqcku 'kk;j" vs "fly ke 'kqcku 'kk;j"), case marking.  
3. **Question each deviation**: "What is lost/gained by fusing 'fly ns'?" (Loss of explicit possession, gain of inherent attribute).  
4. **Generalize**: Create a "Deviation → Effect" table for 5 lines. This trains the eye to see grammar as *choice*, not error.

## BUILDS_ON
Builds on the student's ability to parse basic Hindi case system (karak), verb morphology (tense/aspect/agreement), and compound formation (samasa) from Class 9-10 grammar.

## LEADS_TO
Enables advanced stylistic analysis in c11_hin_ar_cbse_13_013 (Critical Thinking) where linguistic evidence must support thematic arguments, and c11_hin_ar_cbse_13_014 (Writing Skills) where grammatical precision is required for analytical essays.

## PREREQUISITE_NODE_IDS
c11_hin_ar_cbse_13_001, c11_hin_ar_cbse_13_002, c11_hin_ar_cbse_13_010, c11_hin_ar_cbse_13_008

## PREREQUISITE_REASONS
c11_hin_ar_cbse_13_001: Provides historical context (Emergency, Nagarjun's activism) essential to decode why grammatical deviations carry political weight.  
c11_hin_ar_cbse_13_002: Establishes narrative voice and stanza structure; language usage analysis requires knowing *who* speaks and *where* in the poem.  
c11_hin_ar_cbse_13_010: Supplies glossed vocabulary (e.g., fu”kke, ,gfr;kr) without which morphological segmentation is impossible.
c11_hin_ar_cbse_13_008: m standard grammar). It does NOT cover literary device identification (metaphor, irony - covered in c11_hin_ar_cbse_13_008, 009) or vocabulary meanings (covered in c11_hin_ar_cbse_13_010).  

## FORWARD_NODE_IDS
c11_hin_ar_cbse_13_012, c11_hin_ar_cbse_13_013, c11_hin_ar_cbse_13_014, c12_hin_a_cbse_04_011, c12_hin_a_cbse_09_011, c12_hin_a_cbse_11_011, c12_hin_a_cbse_12_011, c12_hin_a_cbse_13_011, c12_hin_a_cbse_17_011, c12_hin_ar_cbse_01_011, c12_hin_ar_cbse_02_011, c12_hin_ar_cbse_07_011, c12_hin_ar_cbse_09_011, c12_hin_ar_cbse_10_011, c12_hin_ar_cbse_11_011

## FORWARD_REASONS
c11_hin_ar_cbse_13_012: Comprehension questions often ask "Why this word form?" - grammatical analysis provides the evidence for inferential answers.  
c11_hin_ar_cbse_13_013: Critical interpretation requires citing syntactic choices (e.g., ellipsis as trauma marker) as textual proof.  
c11_hin_ar_cbse_13_014: Analytical writing tasks demand the metalanguage (case, aspect, samasa) developed here to structure arguments.
c12_hin_a_cbse_04_011: अगला तार्किक चरण: This node analyzes the grammatical structures, syntactic patterns, and language usage specific to th... इस नोड की अवधारणाओं को सीधे उपयोग/विस्तारित करता है।  
c12_hin_a_cbse_09_011: *Kriya ke bhed* (transitive/intransitive) — needed for compound verb analysis (Diagnostic 2).  
c12_hin_a_cbse_11_011: Covers authorial voice through grammar — needed for narrator vs. character speech analysis.  
c12_hin_a_cbse_12_011: Understanding of free indirect discourse in Hindi prose  
c12_hin_a_cbse_13_011: Class 11 Antra Chapter 13 grammar node establishes baseline skills in analyzing language usage in literary prose — this node deepens them for Class 12 complexity.  
c12_hin_a_cbse_17_011: Evaluated linguistic arguments in essays — needed for Diagnostic Q5.  
c12_hin_ar_cbse_01_011: Practice with multi-stanza grammatical pattern tracking.  
c12_hin_ar_cbse_02_011: Exam-oriented practice.  
c12_hin_ar_cbse_07_011: Advanced chhand variations.  
c12_hin_ar_cbse_09_011: Develops comparative analysis of language usage across poems.  
c12_hin_ar_cbse_10_011: Word-formation in descriptive prose (Chapter 13).  
c12_hin_ar_cbse_11_011: Links linguistic choice to critical interpretation  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
none

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_13_001 -> c11_hin_ar_cbse_13_011 -> c11_hin_ar_cbse_13_013: Context grounds grammatical choices in history; grammatical analysis feeds critical interpretation.

## THIS_FORMULA
**Grammatical Deviation Analysis Protocol**:  
1. Identify Surface Form (SF) in poem.  
2. Construct Standard Prose Equivalent (SPE).  
3. List Morpho-Syntactic Differences (Δ).  
4. Map each Δ to Semantic/Pragmatic Effect (E).  
5. Synthesize: Σ(Δ→E) = Poetic Function.

## FORMULA_VARIABLES
SF = Surface Form (actual word/phrase in poem); SPE = Standard Prose Equivalent (grammatically regular paraphrase); Δ = Difference (deviation type: case, agreement, ellipsis, compounding, word order); E = Effect (rhythmic, semantic, thematic, pragmatic); Σ = Synthesis across stanza/poem.

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
linguistic

## CROSS_SUBJECT
c11_english_linguistics | Conceptual bridge: Both use 'deviation from norm' (foregrounding) as core analytical framework; Nagarjun's syntactic violations parallel Hopkins' 'sprung rhythm' or cummings' orthographic rebellion.  
c11_sociology_social_change | Conceptual bridge: The poem's grammatical encoding of powerlessness (passive constructions, pluralization of body parts) mirrors sociological concepts of 'structural violence' and 'bureaucratic dehumanization' in informal labor studies.

## PREREQ_CONCEPT
Proficiency in Hindi karak (case) system, verb conjugation (person/number/gender/aspect), and samasa (compound) classification up to Class 10 level.

## PREREQ_BEFORE
Student must be able to independently parse a simple Hindi sentence into subject, object, verb, and case markers, and identify samasa types (Tatpurusha, Karmadharaya, Bahuvrihi, Dvandva).

## PREREQ_STUCK
If stuck, review **Class 10 Hindi Vyakaran: Karak evam Kriya** (Case and Verb) chapters, focusing on oblique case formation with postpositions (ne, ko, se, ka/ke/ki) and future tense agreement rules.

## WORKED_EXAMPLE_1
PROBLEM: Analyze the grammatical structure and poetic function of the phrase **"fpjkxk¡ gjsoQ ?kj osQ fy,"** (Stanza 2, Line 1) focusing on case morphology and word order.

STEPS:
- Step 1: **Identify Surface Form**: Segment the phrase: fpjkxk¡ (Noun, Plural, Oblique?) + gjsoQ (Postposition 'for') + ?kj (Noun, Singular, Oblique) + osQ (Postposition 'of', Genitive) + fy, (Postposition 'for', Dative).
- Step 2: **Determine Standard Prose Equivalent (SPE)**: "fpjkx ds ?kj ke liye" (For the house of the poor). Note: Standard Hindi uses singular "fpjkx" (direct) + "ka" (genitive) for possessor, not oblique plural + "ke liye".
- Step 3: **List Morpho-Syntactic Differences (Δ)**:  
  Δ1: "fpjkxk¡" (Oblique Plural) vs "fpjkx" (Direct Singular) - **Number & Case shift**.  
  Δ2: "gjsoQ" (Postposition 'for') inserted before "?kj osQ" - **Extra dative layer**.  
  Δ3: Word Order: [Possessor + for] + [Possessed + of] + for vs Standard [Possessor + of] + [Possessed] + for.
- Step 4: **Map Δ to Effect (E)**:  
  E1 (Plural Oblique): Generalizes "the poor" into a **class/category**, not an individual; oblique case marks them as *ground* for the subsequent possession, emphasizing their structural marginality.  
  E2 (Double Dative "gjsoQ...fy,"): Creates **recursive purposiveness** - the house is *for* the poor, *for* whom? The redundancy mimics bureaucratic circularity or the endless deferral of housing rights.  
  E3 (Inversion): Fronting "fpjkxk¡ gjsoQ" places the **beneficiary/victim** at the absolute syntactic foreground before the object (house), mirroring the poem's political stance.
- Step 5: **Synthesize**: The phrase grammatically enacts the **bureaucratic trap**: the poor (plural, oblique, backgrounded) are the stated beneficiaries of a house (possessed, genitive) that exists only in a chain of 'for's (datives) never materializing. The grammar *is* the critique.

REASONING: This protocol moves beyond 'identifying case' to showing how case *choice* (plural oblique vs singular direct) and *layering* (double dative) construct the poem's political argument at the micro-syntactic level.

ANSWER: The phrase uses plural oblique possessor + double dative layering + beneficiary-fronting to syntactically simulate the endless deferral and categorical erasure of the poor in state housing schemes.

## WORKED_EXAMPLE_2
PROBLEM: Explain the morphological composition and syntactic role of **"fu”kke"** (Stanza 3, Line 3) and why the poet chooses this tatsama form over its tadbhava equivalent "hakim" or "sarkar".

STEPS:
- Step 1: **Morphological Segmentation**: fu”kke = fu (prefix 'vi-' = special/intensive) + “kk (root 'raj' = rule/king) + e (suffix forming masculine noun/agent). Literally: 'one who rules specially/supremely'.
- Step 2: **Identify Grammatical Category**: Masculine, Singular, Direct Case noun functioning as **Subject** of "gS" (is) in "rsjk fu”kke gS".
- Step 3: **Contrast with Tadbhava Alternatives**:  
  "hakim" (Persian loan, administrative officer) → connotes *appointed functionary*.  
  "sarkar" (Persian loan, government) → connotes *institution/collectivity*.  
  "fu”kke" (Sanskrit tatsama) → connotes *legitimized sovereignty, traditional kingship, absolute authority*.
- Step 4: **Analyze Poetic Function of Choice**: The poem critiques **modern democratic power masquerading as feudal sovereignty**. Using the high Sanskritic "fu”kke" for a contemporary ruler (likely Indira Gandhi during Emergency) creates **ironic elevation** - it grants the ruler the *mythic stature* of a ancient king to better expose the *barbarism* of "fly ns 'kqcku 'kk;j" (dry twig's fruit). The grammatical gender (masculine) also overrides the ruler's biological gender, symbolizing the **masculinist nature of authoritarian power**.
- Step 5: **Connect to Stanza Syntax**: As subject of "gS" (copula) linking to the metaphor "fly ns 'kqcku 'kk;j dh", the noun's semantic weight (sovereignty) is directly equated with barrenness. A lighter word ("hakim") would weaken the metaphoric equation: Sovereignty = Barrenness.

REASONING: Morphological etymology (tatsama vs tadbhava) is not trivia; it encodes the poem's historical consciousness. The grammatical gender mismatch (masculine noun for female ruler) is a deliberate syntactic-semantic clash revealing power's gendered performance.

ANSWER: "fu”kke" (tatsama, masculine singular subject) is chosen over "hakim/sarkar" to invoke traditional kingship, enabling an ironic equation of modern authoritarian sovereignty with feudal barrenness via the bahuvrihi metaphor.

## WORKED_EXAMPLE_3
PROBLEM: Perform a full **Grammatical Deviation Analysis** on the final line: **"s ,gfr;kr ”k:jh gS bl cgj osQ fy,"** (Stanza 3, Line 4). Combine morphology, syntax, and phonology.

STEPS:
- Step 1: **Surface Form (SF)**: s (conjunction 'and/also') + ,gfr;kr (Adjective/Noun, Masc. Sing. Direct) + ”k:jh (Noun, Fem. Sing. Direct) + gS (Verb, 3rd Sing. Present) + bl (Dem. Adj. Sing. Oblique) + cgj (Noun, Masc. Sing. Oblique) + osQ (Postposition) + fy, (Postposition).
- Step 2: **Standard Prose Equivalent (SPE)**: "yah bhi lokpriya hai is desh ke liye" (This is also popular for this country). Note: "cgj" (world) is poetic/archaic for "desh/duniya".
- Step 3: **List Deviations (Δ)**:  
  Δ1 (Morphology): ",gfr;kr" (tatsama compound: loka+priya → lokpriya → metathesis/assimilation → ,gfr;kr) vs common "lokpriya". The form **phonologically mimics the vernacular/rustic pronunciation** (Nagarjun's Maithili/Hindi belt), grounding high concept in oral soil.  
  Δ2 (Syntax): **Adjective-Noun Inversion**: ",gfr;kr ”k:jh" (Popular fame) vs SPE "lokpriya prasiddhi". The head noun ”k:jh (fame) follows modifier, but the modifier is a *compound adjective* bearing the weight.  
  Δ3 (Case/Postposition): "bl cgj osQ fy," (for this world) - triple layer: Demonstrative + Noun(obl) + Genitive + Dative. SPE uses simple "is desh ke liye".  
  Δ4 (Phonology/Prosody): The line scans as **Jagati (48 matras)** with heavy caesura after "gS": "s ,gfr;kr ”k:jh gS | bl cgj osQ fy,". The clustering of retroflex/alveolar stops (rk, rj, gj, q) in second half creates **harsh, percussive closure**.
- Step 4: **Map Δ to Effects (E)**:  
  E1: Vernacular phonology in ",gfr;kr" → **Authenticity/Subaltern voice** claiming the concept of 'popular'.  
  E2: Modifier-Head order (,gfr;kr ”k:jh) → **Fame is redefined as 'people's affection'**, not state propaganda.  
  E3: Triple postposition layer → **Bureaucratic weight/burden**; the 'world' is not a home but a target of policy.  
  E4: Harsh phonetics + caesura → **Finality/Inevitability**; the statement lands like a gavel.
- Step 5: **Synthesize (Σ)**: The line grammatically performs the poem's central thesis: **True sovereignty (,gfr;kr ”k:jh) emerges from the people's vernacular life, but is crushed under the bureaucratic phonology of the state (bl cgj osQ fy,)**. The grammar *enacts* the conflict.

REASONING: This example demonstrates the **multi-level integration** required at Class 11: phonology validates morphology, syntax encodes ideology, and prosody seals the argument. No single level suffices.

ANSWER: The line fuses vernacular phonology (,gfr;kr), ideological syntax (modifier-head redefinition), bureaucratic case-stacking (bl cgj osQ fy,), and percussive prosody to enact the clash between popular legitimacy and state power in its very grammatical fabric.

## COMPETENCY_QUESTION_1
QUESTION: In the first stanza, the poet writes "u gks deh”k rks ik¡oksa ls isV <¡d ysaxs". A student claims: "The verb 'ysaxs' is grammatically incorrect because the subject 'deh”k' is singular, so it should be 'ysxh'." Using your knowledge of Hindi syntax and the poem's context, refute this claim and explain the actual grammatical logic.

COMPETENCY: Syntactic Analysis & Argumentation

STEPS:
- Step 1: Identify the true syntactic subject of the main clause (ik¡oksa, not deh”k).
- Step 2: Explain the conditional structure ("u gks deh”k" = if body is not) which makes 'deh"k' part of a subordinate clause, not the main subject.
- Step 3: Demonstrate subject-verb agreement: ik¡oksa (Plural) + ysaxs (Plural Future) = Correct Agreement.
- Step 4: Argue why the 'error' claim reflects a prose-biased reading that misses poetic condensation (ellipsis of 'th' in conditional) and thematic intent (plural bones = collective fate).

ANSWER: The claim is false. The main clause subject is "ik¡oksa" (bones, plural), governing the plural verb "ysaxs". "deh”k" is the subject of the elliptical conditional clause "u gks [th] deh”k". The student's error stems from treating the conditional as the main clause. Poetically, the plural agreement enacts the fragmentation of the singular body into collective debris, reinforcing the theme of dehumanization.

DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: Nagarjun's poem uses the compound **"e;Llj"** (miyC/) in the vocabulary list, glossed as 'nest/dwelling'. In the poem text, the form **"e;Llj ugha"** appears. Analyze this as a **morpho-syntactic unit**: identify its internal structure, its syntactic function in the line "dgk¡ fpjkx e;Llj ugha 'kgj osQ fy,", and explain how the **negation scope** interacts with the compound's semantics to produce the stanza's central irony.

COMPETENCY: Morpho-Syntactic Analysis & Semantic Interpretation

STEPS:
- Step 1: Deconstruct "e;Llj": e; (locative prefix 'in/at') + Llj (root 'lay' = abide/dwell) → tatsama compound noun (masc. sing. direct) = 'dwelling/nest'. Note: It is a **Karmadharaya samasa** (appositional: 'abiding-place').
- Step 2: Analyze syntactic slot: "fpjkx e;Llj ugha 'kgj osQ fy,". Here "e;Llj ugha" functions as a **negated predicate nominal** (predicate adjective phrase) for the topic "fpjkx" (the poor). Structure: [Topic: fpjkx] [Predicate: e;Llj ugha] [Purpose adjunct: 'kgj osQ fy,].
- Step 3: Determine negation scope: "ugha" negates the *entire predicate nominal* "e;Llj". It asserts: "The poor are **not a dwelling/nest**".
- Step 4: Semantic irony: A 'nest' (e;Llj) implies **shelter, safety, belonging, organic growth**. The line says the poor are *not even a nest* **for the sake of the sky ('kgj)**. The purpose adjunct "'kgj osQ fy," (for the sky) suggests the sky *needs* a nest (poetic inversion: usually birds need sky). The irony: The poor are denied the very status (nest/dwelling) that would give meaning to the vastness above them. They are **structurally excluded from being 'ground' for anything**.
- Step 5: Synthesize: The morphologically rich tatsama "e;Llj" (carrying cultural weight of 'home') is negated to expose the **ontological homelessness** imposed by the state. The grammar (negated predicate nominal + purposive dative) constructs the irony: *To be a nest for the sky is a privilege the poor are refused.*

ANSWER: "e;Llj" (Karmadharaya compound, 'dwelling') functions as a negated predicate nominal for "fpjkx". The negation "ugha" denies the poor the ontological status of 'shelter', while the dative "'kgj osQ fy," ironically positions the sky as the beneficiary of a nesting that is structurally withheld, encoding the poem's critique of existential exclusion.

DIFFICULTY: hard