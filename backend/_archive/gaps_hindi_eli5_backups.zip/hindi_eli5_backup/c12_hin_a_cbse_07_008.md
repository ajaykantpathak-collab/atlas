## DEFINITION
Imagery (प्रतिबिंब/बिंब) refers to the use of vivid, sensory language that appeals to the five senses (sight, sound, smell, touch, taste) to create mental pictures and evoke physical sensations. Metaphor (रूपक/अनुप्रास) is a figure of speech that directly compares two unrelated things by stating one *is* the other, transferring qualities from the vehicle (source) to the tenor (target) without using "like" or "as". In "ckjgeklk", imagery constructs the monsoon world, while metaphor fuses nature with human longing.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student can independently identify at least three distinct sensory images and two metaphors in the poem, explain how each device operates (vehicle/tenor for metaphor; sense appealed for imagery), and articulate how they jointly develop the central theme of viraha (separation) and milan (union) in a structured board-style answer with textual evidence.

## SCOPE_BOUNDARY
This node covers *only* imagery (visual, auditory, tactile, olfactory, gustatory) and metaphor (simple, implied, extended) as they appear in the poem "ckjgeklk" from NCERT Antra Chapter 7. It does NOT cover irony, symbolism, simile, personification, or other rhetorical devices (covered in node 009), nor does it cover vocabulary meanings (node 010) or grammar (node 011).

## WALKTHROUGH
Imagine you are sitting by a window during the first heavy monsoon shower — the smell of wet earth (mitti ki khushboo), the sound of droplets on tin roofs, the sudden coolness on your skin. The poem "ckjgeklk" makes you *feel* that moment through words. To begin, read the first stanza aloud slowly. Circle every word that triggers a sensory experience: *fufl* (visual/rain), *Hk¡ojk* (tactile/cold), *dkx* (visual/fire-light), *nxèkS* (visual/lightning). That is imagery. Next, ask: "Is the poet *only* describing weather?" Notice how *iQkxqu iou* (black clouds) become the beloved's *ckjg* (dark tresses) and *fcjg* (rain) becomes *vfèkd larIr* (intense union). That transfer — nature *becoming* human emotion — is metaphor. The key insight: in this folk-poem (lok-geet), imagery grounds the metaphor in physical reality so the abstract feeling of longing becomes tangible.

## DIAGNOSTIC_QUESTION_1
Define 'imagery' (बिंब/प्रतिबिंब) and 'metaphor' (रूपक) in your own words, giving one example from daily life for each (not from the poem).

## DIAGNOSTIC_ANSWER_1
Imagery: Language that appeals to the senses (e.g., "The kitchen smelled of frying cumin and ghee" — olfactory/gustatory). Metaphor: Direct comparison saying A *is* B (e.g., "Time is a thief" — time steals moments). A wrong answer that gives a simile ("Time is *like* a thief") reveals confusion between metaphor and simile. A wrong answer that lists only visual imagery reveals a narrow sensory understanding.

## DIAGNOSTIC_QUESTION_2
In stanza 1 of "ckjgeklk", the line *fi; lkSa dgsgq l¡nslM+k] ,s Hk¡ojk ,s dkx* appears. Identify the two dominant sensory images here and explain why the poet juxtaposes *Hk¡ojk* (cold) and *dkx* (fire/heat) in the same breath.

## DIAGNOSTIC_ANSWER_2
Dominant images: tactile (cold rain *Hk¡ojk*) and visual/thermal (fire *dkx*). The juxtaposition mirrors the lover's internal conflict — the external monsoon chill contrasts with the internal burning of separation (*viraha*). A student who only says "it shows rain and fire" misses the emotional function. A student who calls it "irony" confuses contrast with irony (covered later). The correct response links sensory contrast to psychological state.

## DIAGNOSTIC_QUESTION_3
Apply the concept of 'vehicle' and 'tenor' to the metaphor in stanza 3: *rqEg fcuq oaQrk èkfu g#bZ] ru fruqoj Hkk Mksy*. Identify vehicle, tenor, and the ground (shared quality). Write the metaphor in the form "Tenor is Vehicle".

## DIAGNOSTIC_ANSWER_3
Tenor: The beloved's dark tresses (*oaQrk èkfu* / *ckjg*). Vehicle: Black monsoon clouds (*iQkxqu iou* / *fcuq*). Ground: Darkness, density, moisture-laden potential. Metaphor statement: "The beloved's tresses *are* black monsoon clouds." A wrong answer swapping vehicle/tenor shows structural misunderstanding. A wrong answer citing "similarity" instead of identity ("tress *like* clouds") reveals similic thinking.

## DIAGNOSTIC_QUESTION_4
Analyze how the *extended metaphor* of the monsoon season operates across all three stanzas. Trace the progression: stanza 1 (anticipation), stanza 2 (arrival/intensification), stanza 3 (culmination/union). How does the imagery shift to support this arc?

## DIAGNOSTIC_ANSWER_4
Stanza 1: *fufl* (rain) as hope — visual/tactile imagery of drops, lightning (*nxèkS*). Stanza 2: *pdbZ vkSj dksfdyk* (thunder/lightning) as escalating passion — auditory (*Hk¡oS*) and tactile (*cklj*). Stanza 3: *iQkxqu iou* (black clouds) fully become *ckjg* — visual darkness, olfactory (*ty* / water), tactile union (*larIr*). The shift from discrete drops to enveloping cloud-cover mirrors the shift from *viraha* to *milan*. A weak answer lists images stanza-wise without showing the *progressive metaphorical mapping*.

## DIAGNOSTIC_QUESTION_5
Evaluate the effectiveness of the folk-meter (nksgk-pkSikbZ) and Braj Bhasha diction in conveying the metaphor of rain-as-lover. Would the same metaphor work in a Sanskritised *kavya* style? Justify with two specific textual features.

## DIAGNOSTIC_ANSWER_5
The folk meter's repetitive, song-like rhythm (*tjS fcjg T;ksa nhid ckrh*) mimics the relentless monsoon and the heartbeat of longing — essential for the metaphor's physicality. Braj words like *lhmQ*, *l¡nslM+k*, *fruqoj* carry erotic-earthy connotations lost in Sanskritised *varsha*/*megha*. In a *kavya* style, the metaphor would become decorative/allegorical; here it remains visceral. A student saying "both are good" fails to evaluate *register-specific effect*.

## DIAGNOSTIC_QUESTION_6
Create a four-line stanza in Hindi (any dialect) that uses *at least two sensory images* and *one metaphor* to express "waiting for a message on your phone". Do not use the words "phone", "message", "screen", or "wait".

## DIAGNOSTIC_ANSWER_6
Example:  
*रात अंधेरी, टिमटिमाता एक तारा* (visual)  
*सांसों में बजती, खामोश पुकारा* (auditory)  
*उंगलियां थकीं, पर धड़कन है बेकरार* (tactile)  
*यह सन्नाटा ही अब, तेरा इंतज़ार* (metaphor: silence = the wait/your arrival).  
A poor answer uses simile ("जैसे...") or lists images without a unifying metaphor, showing inability to synthesize devices creatively.

## COMMON_MISCONCEPTION
Students treat every comparison in the poem as a metaphor. In "ckjgeklk", lines like *fcjg ckf<+ Hkk nk#u lhmQ* ("rain falls heavily, very cold") are *literal description* (imagery), not metaphor. The metaphor occurs only when the rain/cloud *becomes* the beloved (*iQkxqu iou >dksjs 'khr dks pkSxquk c<+k jgs gSa* — black clouds embrace the dark tresses). Students also confuse *personification* (giving human action to nature: *iou pkSxquk c<+k jgs gSa* — clouds embracing) with *metaphor* (identity: clouds *are* tresses). The error stems from not testing "A *is* B" — if you can replace "is" with "resembles", it's likely personification or simile, not metaphor.

## ON_FAILURE
1. Re-read stanza 3 aloud. Physically underline every verb. Ask: "Is this verb describing weather or a human action?" 2. Make a two-column table: Column A = Nature word (e.g., *iou*), Column B = Human word (e.g., *ckjg*). Draw arrows only where the text *equates* them (metaphor) vs. where nature *acts like* a human (personification). 3. Revisit Class 11 node **c11_hin_ar_cbse_07_008** (Literary Devices: Imagery and Metaphor) for the vehicle/tenor drill. 4. Re-attempt Diagnostic Question 3 with a fresh poem (e.g., Nirala's *Ram Ki Shakti Puja* cloud imagery) to test transfer.

## BUILDS_ON
Class 11 understanding of basic literary device definitions (imagery, metaphor, personification) and ability to locate them in a text.

## LEADS_TO
Node **c12_hin_a_cbse_07_009** (Literary Devices: Irony and Symbolism) where the same poem's *symbolic* use of *iou* (cloud) as both obstacle and messenger is analysed, requiring the metaphor foundation built here.

## PREREQUISITE_NODE_IDS
c12_hin_a_cbse_07_001, c12_hin_a_cbse_07_002, c12_hin_a_cbse_07_003, c12_hin_a_cbse_07_006, c11_hin_ar_cbse_07_008, c12_hin_a_cbse_07_007

## PREREQUISITE_REASONS
c12_hin_a_cbse_07_001: Provides poet background (Mirabai era, folk tradition) essential for register analysis.  
c12_hin_a_cbse_07_002: Establishes narrative arc (viraha → milan) which the metaphors structurally mirror.  
c12_hin_a_cbse_07_003: Setting/atmosphere node trains sensory detection — prerequisite for imagery identification.  
c12_hin_a_cbse_07_006: Primary theme (prem/viraha) is the *tenor* for all major metaphors; must be known first.  
c11_hin_ar_cbse_07_008: Class 11 node where vehicle/tenor terminology and imagery taxonomy were introduced.
c12_hin_a_cbse_07_007: Literary devices like imagery and metaphor are the vehicles through which secondary themes are conveyed — analyzing themes prepares students to see how devices function thematically.  

## FORWARD_NODE_IDS
c12_hin_a_cbse_07_009, c12_hin_a_cbse_07_012, c12_hin_a_cbse_07_013, c12_hin_a_cbse_07_014, c12_hin_a_cbse_07_015

## FORWARD_REASONS
c12_hin_a_cbse_07_009: Irony/Symbolism node extends metaphor analysis — e.g., the cloud *symbolises* separation *and* union ironically.  
c12_hin_a_cbse_07_012: Comprehension questions (literal/inferential) require device identification as evidence.  
c12_hin_a_cbse_07_013: Critical thinking/interpretation tasks demand synthesis of imagery+metaphor+theme.
c12_hin_a_cbse_07_014: Equips student with specific metaphors and symbols (peacock, rain) to embed as textual evidence.  
c12_hin_a_cbse_07_015: Imagery/metaphor analysis supplies textual evidence  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
No prior-class cross-subject nodes exist in the provided list for Hindi Antra.

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_07_008 -> c12_hin_a_cbse_07_008 -> c12_hin_a_cbse_07_009

## THIS_FORMULA
N/A - conceptual

## FORMULA_VARIABLES
N/A

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
analytical

## CROSS_SUBJECT
N/A | The poem's folk register (nksgk-pkSikbZ) and Braj Bhasha reflect the Bhakti tradition's democratization of Sanskrit poetics — metaphor here serves devotion (prem-bhakti) not ornament.  
 N/A | The imagery precisely maps Indian monsoon phenomenology: *fufl* (onset), *pdbZ/dksfdyk* (convective thunderstorms), *iQkxqu iou* (stratiform overcast) — geography validates the poem's sensory accuracy.
## PREREQ_CONCEPT
Vehicle/Tenor distinction (I.A. Richards) and sensory imagery taxonomy (visual, auditory, tactile, olfactory, gustatory).

## PREREQ_BEFORE
Student must have read the full poem "ckjgeklk" at least twice — once for narrative, once marking sensory words — and know the chapter's primary theme (viraha/milan in folk tradition).

## PREREQ_STUCK
If stuck on vehicle/tenor, review the "Time is a thief" drill from Class 11 (c11_hin_ar_cbse_07_008) — replace "time" with "cloud", "thief" with "lover's tresses".

## WORKED_EXAMPLE_1
PROBLEM: Analyse the visual and tactile imagery in the opening quartet (lines 1-4) of stanza 1: *vxgu nsol ?kVk fufl ck<+h / vc èkfu nsol fcjg Hkk jkrh / dk¡ik fg;k tukok lhmQA / ?kj ?kj phj jpk lc dkgw¡A*

STEPS:
- Step 1: Read the four lines aloud in Braj, noting rhythm. Identify the speaker (the woman/ukxerh) addressing the beloved (èkfu).
- Step 2: List every noun/adjective invoking a sense: *?kVk* (visual: dark), *fufl* (visual/tactile: rain drops), *fcjg* (visual/auditory: rain), *Hk¡ojk* (tactile: cold), *dk¡ik* (visual: day), *fg;k* (gustatory/olfactory: fragrance), *tukok* (tactile: wet/damp), *lhmQ* (visual: greenery), *phj* (auditory: patter), *jpk* (visual: water), *lc* (tactile: touch), *dkgw¡* (visual: spread).
- Step 3: Classify each: Visual: ?kVk, fufl, fcjg, dk¡ik, lhmQ, jpk, dkgw¡. Tactile: Hk¡ojk, tukok, lc. Auditory: fcjg, phj. Olfactory/Gustatory: fg;k.
- Step 4: Explain the *cluster effect*: The stanza opens with visual darkness (?kVk) broken by rain (fupl/fcjg), immediately grounded in tactile cold (Hk¡ojk) and smell of wet earth (fg;k). The progression from sky to courtyard (?kj ?kj) expands the sensorium from personal to domestic.
- Step 5: Connect to theme: This sensory saturation *is* the arrival of the monsoon — the external correlative for the internal arrival of longing. The imagery does not decorate; it *constitutes* the emotional event.

REASONING: The folk poem uses dense, clustered imagery (not isolated images) to create an immersive monsoon sensorium. Each sense reinforces the others — the sound of rain (phj) confirms the touch (lc), the smell (fg;k) confirms the sight (lhmQ). This inter-sensory density mirrors the overwhelming nature of *viraha*.

ANSWER: The opening quartet deploys 11 distinct sensory markers across 4 senses in 4 lines. Visual dominates (6 markers) establishing the monsoon palette (dark sky, green earth, spreading water). Tactile (cold, wet, touch) and auditory (patter, rain roar) ground the experience physically. Olfactory (fragrance) evokes the *mitti ki khushboo* — the quintessential monsoon trigger. Together they create a *synesthetic* opening where the beloved's absence is felt through nature's presence.

## WORKED_EXAMPLE_2
PROBLEM: Identify and explain the central metaphor in stanza 2: *iwl tkM+ FkjFkj ru dk¡ikA / fcjg ckf<+ Hkk nk#u lhmQA / oaQr dgk¡ gkSa ykxkSa fg;jSA / lkSj lqisrh vkoS twM+hA*

STEPS:
- Step 1: Locate the pivot line where nature becomes human. Line 3: *oaQr dgk¡ gkSa ykxkSa fg;jSA* — "Where have the paths gone, friend?" is the woman speaking to her *sakhi* (friend), but *oaQr* (path/way) also means the rain's path.
- Step 2: Identify the extended metaphor: The *monsoon day* (ru dk¡ik) = *the day of union*. The *heavy cold rain* (fcjg ckf<+ Hkk nk#u lhmQ) = *the intensity of meeting*. The *lost paths* (oaQr dgk¡) = *the dissolution of separation*.
- Step 3: Map vehicle → tenor for each element:  
  Vehicle (Nature) → Tenor (Human/Emotion)  
  *ru dk¡ik* (this day) → *milan ka din* (day of union)  
  *fcjg ckf<+* (heavy rain) → *teevra anubhuti* (intense feeling)  
  *nk#u lhmQ* (very green) → *hara-bhara man* (flourishing heart)  
  *oaQr* (path) → *viraha ka marg* (path of separation)  
  *ykxkSa fg;jS* (where gone?) → *viraha ka ant* (end of separation)
- Step 4: Note the *grammatical metaphor*: *twM+hA* (dawn breaks) — the verb *twM+h* (to break/dawn) applies to day *and* to the breaking of the separation-night. The folk syntax *lkSj lqisrh vkoS* (walking, stepping, moving) describes both the woman's gait and the rain's advance.
- Step 5: Verify against theme: The metaphor transforms the entire stanza from weather-report to love-narrative without a single comparative word (like/as). The *identity* claim is sustained across 4 lines.

REASONING: In folk poetry (lok-kavya), metaphor is often *sustained* (extended) across a stanza rather than momentary. The lack of explicit comparative markers (*iva*, *samana*) is a genre marker — the identity is asserted through parallel syntax and shared epithets. The student must recognise that *every noun* in this stanza does double duty.

ANSWER: Stanza 2 operates as a sustained metaphor where the monsoon day *is* the day of union. The heavy rain *is* the overwhelming emotion of meeting. The greening landscape *is* the lover's revitalised heart. The lost paths *are* the erased distance of separation. The dawn *is* the end of the dark night of viraha. This is an *extended metaphor* (सतत रूपक) characteristic of Braj folk songs (lok-geet).

## WORKED_EXAMPLE_3
PROBLEM: Synthesise: How do the *imagery clusters* of stanza 1 (anticipation) and the *extended metaphor* of stanza 2 (arrival) prepare the *metaphorical climax* of stanza 3 (union)? Write a 100-word board-style answer.

STEPS:
- Step 1: Recall stanza 1 imagery cluster: visual darkness (?kVk), tactile cold (Hk¡ojk), olfactory earth (fg;k), auditory patter (phj) — all *external*, *approaching*, *fragmented* (drops, lightning flashes).
- Step 2: Recall stanza 2 extended metaphor: ru dk¡ik = milan din; fcjg = prem; oaQr lost = viraha ended — *internalised*, *totalising*, *sustained*.
- Step 3: Analyse stanza 3 metaphor: iQkxqu iou (black clouds) = ckjg (dark tresses); >dksjs 'khr (dark night) = viraha raat; pkSxquk c<+k (embracing) = milan. The imagery here fuses: visual (black clouds/tresses), tactile (embrace), olfactory (ty/water = sweat/tears), auditory (Hkk Mksy = sound of union).
- Step 4: Trace the structural arc: Fragmented sensory impressions (stanza 1) → Coherent metaphorical narrative (stanza 2) → Complete metaphorical identification where nature *becomes* the lovers' bodies (stanza 3). The imagery *densifies* from discrete drops to enveloping cloud-cover; the metaphor *deepens* from day=union to cloud=tresses.
- Step 5: Draft answer using PEEL: Point (progressive fusion), Evidence (specific images/metaphors), Explanation (mechanism), Link (theme of prem as natural force).

REASONING: Board answers require *integration* across stanzas, not isolated device-spotting. The progression from imagery → metaphor → metaphorical identification is the poem's formal enactment of the thematic progression from viraha → milan. The student must show this structural parallelism.

ANSWER: The poem moves from discrete sensory imagery (stanza 1: dark sky, cold drops, wet fragrance, patter sound) to a sustained metaphor where the monsoon day *is* the union day (stanza 2), culminating in total metaphorical identification where black clouds *become* the beloved's tresses embracing in the dark night (stanza 3). Imagery densifies: drops → rain → enveloping cloud. Metaphor deepens: external correlative → narrative parallel → ontological fusion. This formal arc mirrors the thematic arc: viraha's fragmented longing → milan's overwhelming presence → complete union where lover and nature are indistinguishable. The folk meter's repetition (tjS fcjg / fcjg Hkk) mimics this intensification.

## COMPETENCY_QUESTION_1
QUESTION: "In 'ckjgeklk', the monsoon is not a backdrop but a protagonist." Using evidence from *any two stanzas*, explain how the poet uses imagery and metaphor *together* to give the monsoon human agency and emotion. (Competency: Literary Analysis & Evidence-Based Reasoning)

COMPETENCY
Literary Analysis & Evidence-Based Reasoning

STEPS:
- Step 1: Select Stanza 1 (imagery-heavy) and Stanza 3 (metaphor-heavy).
- Step 2: From Stanza 1, cite *fcjg Hkk jkrh* (rain falls heavily) + *phj jpk lc dkgw¡* (water spreads touching every house) — imagery showing monsoon's *volitional movement* and *pervasive touch*.
- Step 3: From Stanza 3, cite *iQkxqu iou >dksjs 'khr dks pkSxquk c<+k jgs gSa* (black clouds embracing dark tresses) — metaphor where clouds *perform* the lover's embrace.
- Step 4: Synthesise: The imagery establishes the monsoon's physical agency (it moves, spreads, touches); the metaphor transfers human intentionality (embracing, longing) onto that physical agency. The monsoon *acts* like a lover because it *is* the lover in the poem's logic.

ANSWER: In stanza 1, auditory-tactile imagery (*phj jpk lc dkgw¡* — water pattering, spreading, touching every house) portrays the monsoon as an active agent that *chooses* to pervade the space. In stanza 3, the metaphor *iQkxqu iou >dksjs 'khr dks pkSxquk c<+k jgs gSa* (black clouds embracing dark tresses) directly attributes the *human action of embrace* to the clouds. The imagery provides the physical verbs (fall, spread, touch); the metaphor provides the intentional verbs (embrace, long). Together they make the monsoon a protagonist who *enacts* the union the human lovers await.

DIFFICULTY
medium

## COMPETENCY_QUESTION_2
QUESTION: Compare the metaphor *iQkxqu iou = ckjg* (black clouds = dark tresses) in "ckjgeklk" with the metaphor *megha = duta* (cloud = messenger) in Kalidasa's *Meghadutam*. How does the *folk register* (lok-bhasha) of "ckjgeklk" transform the *classical convention*? Answer in 150 words. (Competency: Intertextual Comparison & Cultural Contextualization)

COMPETENCY
Intertextual Comparison & Cultural Contextualization

STEPS:
- Step 1: Identify the classical convention: In *Meghadutam*, the cloud is a *separate entity* (duta/messenger) carrying a message *between* separated lovers. Vehicle (cloud) ≠ Tenor (lover); relationship = instrumental.
- Step 2: Identify the folk transformation: In "ckjgeklk", *iQkxqu iou* (cloud) *becomes* *ckjg* (tresses/lover). Vehicle = Tenor; relationship = identity/union.
- Step 3: Link to register: Classical Sanskrit *kavya* uses *upama* (simile) and *utpreksha* (poetic fancy) — distance maintained. Folk Braj *lok-geet* uses *roopak* (metaphor) and *sakshatkaran* (direct enactment) — distance collapsed.
- Step 4: Connect to *prem-bhakti* theology: The folk metaphor reflects *non-dual* (advaitic) love where nature and self, human and divine, are one. The classical metaphor reflects *dualistic* (dvaitic) separation requiring mediation.
- Step 5: Conclude: The folk register doesn't just "use metaphor differently" — it enacts a different ontology of love.

ANSWER: Kalidasa's *megha-duta* operates in a dualistic framework: the cloud is an *intermediary* (vehicle ≠ tenor), carrying words across distance. The metaphor is instrumental — nature *serves* love. In "ckjgeklk", the Braj folk register collapses this distance: *iQkxqu iou* (black clouds) *are* *ckjg* (the beloved's tresses/body). The metaphor is ontological — nature *is* love. This shift from *duta* (messenger) to *svarupa* (own form) mirrors the Bhakti movement's move from ritual mediation to direct, embodied devotion. The folk meter (nksgk-pkSikbZ) and erotic-earthy diction (*lhmQ*, *fruqoj*, *ty*) make the metaphor visceral, not decorative. Where classical poetry *describes* longing through cloud-imagery, folk poetry *enacts* union through cloud-becoming-lover. The register *is* the metaphysics.

DIFFICULTY
hard