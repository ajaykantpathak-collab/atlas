## DEFINITION
Plot and Narrative Structure refers to the organized sequence of events (plot) and the deliberate arrangement of those events through narrative techniques (structure) such as chronology, point of view, flashback, frame story, and allegory to shape the reader's experience and convey thematic meaning.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
Student can independently map the five-stage plot structure (exposition, rising action, climax, falling action, resolution) for each of the three stories, identify and explain the effect of specific narrative structural devices (frame narrative, allegory, non-linear commentary), and write a structured analytical paragraph using the PEEL method with textual evidence.

## SCOPE_BOUNDARY
This node covers plot dissection and narrative structure analysis for the three stories in Chapter 11: "ckyd cp x;k", "?kM+h osQ iq”ksZ", and "<sys pqu yks". It does NOT cover character analysis, thematic interpretation, literary devices (imagery, irony), or vocabulary — those are addressed in subsequent sibling nodes.

## WALKTHROUGH
Imagine you are describing a Bollywood movie to a friend who hasn't seen it — you don't just list scenes randomly; you structure it: "First the hero is introduced, then the conflict starts, then the interval twist, then the climax fight, then the happy ending." That's plot structure. Now, what if the movie starts with the hero in jail, then flashes back to his childhood? That's narrative structure — the *telling* differs from the *happening*. In this chapter, Panchakaji uses three distinct structures: a realistic linear tale ("ckyd cp x;k"), a philosophical frame narrative ("?kM+h osQ iq”ksZ"), and an allegorical fable ("<sys pqu yks"). To begin, read each story once just for *what happens* (plot), then re-read marking *how it's told* (structure). The key insight: structure is not a container for plot — it *is* meaning. The watch metaphor in the second story isn't decoration; it structures the argument about education. The bird's body parts in the third aren't just characters; they structure a political allegory.

## DIAGNOSTIC_QUESTION_1
Define 'plot' and 'narrative structure' in your own words, and give one example of how they differ in any story you know.

## DIAGNOSTIC_ANSWER_1
Plot is the chronological sequence of events (what happens); narrative structure is the author's chosen arrangement of those events (how it's told). Example: In *The God of Small Things*, the plot begins with Sophie Mol's funeral, but the narrative structure jumps between 1969 and 1993. A wrong answer that equates the two (e.g., "plot is the structure of the story") reveals the student cannot distinguish *fabula* (story) from *syuzhet* (discourse) — a critical distinction for Class 12 board answers and CUET literary analysis.

## DIAGNOSTIC_QUESTION_2
In "?kM+h osQ iq”ksZ", the author uses a watch repair scene to frame a philosophical argument about education. Explain why this is a 'frame narrative' and not just a 'setting description'.

## DIAGNOSTIC_ANSWER_2
A frame narrative embeds a secondary story (the watchmaker's lecture) within a primary narrative (the narrator's visit), using the inner story to comment on the outer. The watch scene is not mere setting because it carries the *entire thematic argument* — the watch becomes a metaphor for the child's mind. A student who calls it "setting" confuses *physical backdrop* with *structural device*; they miss that removing the watch scene collapses the story's argument, whereas changing the room's color would not.

## DIAGNOSTIC_QUESTION_3
Given these jumbled events from "ckyd cp x;k": (A) The boy says "Yaw", (B) The teacher asks questions about history/geography, (C) The father and teacher watch the boy struggle, (D) The boy is brought to school, (E) The boy refuses to name his book. Arrange them in correct *plot order* (exposition → resolution) and label each stage.

## DIAGNOSTIC_ANSWER_3
Correct order: D (Exposition: boy brought to school), B (Rising Action: teacher tests knowledge), C (Rising Action: adults observe struggle), E (Climax: boy's defiant refusal "I am a wild tribal"), A (Falling Action/Resolution: boy says "Yaw" and flees). A student who places A before E misses that the single word "Yaw" is the *release* of tension after the climax of refusal — they confuse emotional peak with structural climax.

## DIAGNOSTIC_QUESTION_4
Compare the narrative structure of "?kM+h osQ iq”ksZ" and "<sys pqu yks". How does the use of *allegory* in the latter change the relationship between plot events and thematic meaning compared to the *frame narrative* in the former?

## DIAGNOSTIC_ANSWER_4
In "?kM+h osQ iq”ksZ", the frame creates *distance*: the watchmaker's words are reported, allowing reader skepticism. In "<sys pqu yks", allegory creates *equivalence*: each bird part *is* a social class (peasant, soldier, priest, etc.), so plot events (the bird choosing a part) directly map to political choices. The former uses structure to *mediate* meaning; the latter uses structure to *enact* meaning. A student who says "both use symbols" misses that allegory *is* the structure — there is no 'literal' plot separate from the symbolic one.

## DIAGNOSTIC_QUESTION_5
Evaluate: Is the climax of "<sys pqu yks" the moment the bird chooses the stomach, or the poet's final couplet ("cdkSy dchj osQ...")? Justify with reference to how narrative structure shapes thematic closure.

## DIAGNOSTIC_ANSWER_5
The structural climax is the bird's choice — that's the plot's turning point where the allegory's central conflict (which organ rules?) is decided. The couplet is a *coda* (epilogue) that re-frames the allegory as a warning about *present* exploitation ("vkt dk dcwrj vPNk gS dy osQ eksj ls"). A student who picks the couplet confuses *thematic emphasis* with *structural climax* — they need to distinguish *plot peak* from *authorial commentary*. This error costs marks in "analysis of structure" board questions.

## DIAGNOSTIC_QUESTION_6
Rewrite the ending of "ckyd cp x;k" as a *circular narrative* that returns to the opening image (the boy being dragged to school) but with the boy's internal perspective revealed. Write 4-5 sentences in Hindi.

## DIAGNOSTIC_ANSWER_6
A strong answer: "phir vhI dk;ZHkwfe] vhI ckyd] vhI jkspd ykM+] nhikr eSa ugha FkkA eSaus ^yaw* D;ksa dgk] bls dsl D;ksa ugha ldrk\ vc uqekb'k ds fudky esa eSaus viuh thfor o`{k dk iqdkj ugha] viuh euq"; dk lq[kk cuk;k FkkA firk vkSj vè;kid abHc u ns[ks] muds ?kM+h esa eSaus viuh rjyrk ns[kh FkhA eSa cp ugha x;k] eSa lq[kk dj x;kA" — This uses circular structure to reframe the escape as agency. A weak answer just repeats the original ending — revealing the student cannot manipulate structure to shift perspective.

## COMMON_MISCONCEPTION
Students treat "plot summary" as "structure analysis". They write: "First this happened, then that happened" and call it structure. In "?kM+h osQ iq”ksZ", they summarize the watchmaker's lecture instead of analyzing *why* the author uses a watch metaphor to *structure* the critique of colonial education. The error: confusing *content* (what the watchmaker says) with *form* (why a watch, why a repair scene, why second-hand narration). This happens because school exams often reward summary; boards and CUET reward *structural reasoning*.

## ON_FAILURE
If a student cannot separate plot from structure:
1. Have them draw two timelines for "ckyd cp x;k": Timeline A = events in story-world chronological order (boy wakes → dragged → tested → refuses → says yaw → runs). Timeline B = events in text order (identical here — linear).
2. Then do the same for "?kM+h osQ iq”ksZ": Timeline A = narrator arrives → sees watchmaker → hears lecture → leaves. Timeline B = watchmaker's lecture *contains* a flashback to history of timekeeping → returns to present.
3. Ask: "Where do the timelines diverge? What does that divergence *do* to the reader's understanding?"
4. Re-diagnose with Diagnostic Question 2.

## BUILDS_ON
Class 11 skill of identifying Freytag's Pyramid stages in a single linear narrative (c11_hin_ar_cbse_11_002).

## LEADS_TO
Character Analysis (c12_hin_a_cbse_11_004) — because character choices *are* plot events, and narrative structure reveals character interiority.

## PREREQUISITE_NODE_IDS
c12_hin_a_cbse_11_001, c11_hin_ar_cbse_11_002
## PREREQUISITE_REASONS
c12_hin_a_cbse_11_001: Provides author context (Panchakaji's historical work, linguistic expertise) essential for understanding why he chooses specific narrative forms.
c11_hin_ar_cbse_11_002: Establishes baseline plot analysis vocabulary (exposition, climax, etc.) and practice with linear narratives.

## FORWARD_NODE_IDS
c12_hin_a_cbse_11_003, c12_hin_a_cbse_11_004, c12_hin_a_cbse_11_005, c12_hin_a_cbse_11_006, c12_hin_a_cbse_11_007, c12_hin_a_cbse_11_008, c12_hin_a_cbse_11_009, c12_hin_a_cbse_11_010, c12_hin_a_cbse_11_012, c12_hin_a_cbse_11_013, c12_hin_a_cbse_11_015

## FORWARD_REASONS
c12_hin_a_cbse_11_003: Setting analysis requires knowing *where/when* plot events occur — structure dictates temporal/spatial shifts.
c12_hin_a_cbse_11_004: Protagonist's arc is mapped onto plot stages; structure reveals internal vs external conflict.
c12_hin_a_cbse_11_005: Supporting characters often function as structural foils or narrative devices (e.g., the watchmaker).
c12_hin_a_cbse_11_006: Plot knowledge is needed to trace how events develop the theme.  
c12_hin_a_cbse_11_007: Plot structure knowledge helps locate where secondary themes emerge (e.g., climax, resolution).  
c12_hin_a_cbse_11_008: Plot and narrative structure knowledge is needed to locate *where* devices appear in the story sequence.  
c12_hin_a_cbse_11_009: Plot knowledge required to track where irony/symbolism occur in narrative sequence.  
c12_hin_a_cbse_11_010: अगला तार्किक चरण: Vocabulary in Context: इस नोड की अवधारणाओं को सीधे उपयोग/विस्तारित करता है।  
c12_hin_a_cbse_11_012: Plot knowledge allows locating events for literal answers.  
c12_hin_a_cbse_11_013: Plot knowledge needed to select relevant scenes for evidence.  
c12_hin_a_cbse_11_015: Plot knowledge allows referencing specific events during discussion.  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
N/A

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_11_002 -> c12_hin_a_cbse_11_002 -> c12_hin_a_cbse_11_003

## THIS_FORMULA
N/A - conceptual

## FORMULA_VARIABLES
N/A

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
analytical

## CROSS_SUBJECT
N/A | The frame narrative in "?kM+h osQ iq”ksZ" critiques colonial education policy — the watch metaphor mirrors Macaulay's "minute" structuring Indian minds; structural analysis here parallels historical source analysis.
 N/A | "<sys pqu yks" allegorizes federalism/centralization: the bird's body parts debate *is* a structural representation of power-sharing conflicts; narrative structure maps directly to political theory.
## PREREQ_CONCEPT
Freytag's Pyramid (five-stage plot structure) and basic narrative devices (flashback, frame story, allegory) from Class 11.

## PREREQ_BEFORE
Student can label the five plot stages in a linear short story and define frame narrative and allegory.

## PREREQ_STUCK
Review Freytag's Pyramid using a known Class 11 story (e.g., "The Portrait of a Lady" from Hornbill) — map each paragraph to a plot stage.

## WORKED_EXAMPLE_1
PROBLEM: Analyze the plot structure of "ckyd cp x;k" using Freytag's Pyramid. Identify the exact textual moment for each stage and explain how the linear structure reinforces the theme of colonial education's violence.

STEPS:
- Step 1: Read the story once marking only *events* (not descriptions). List them in order: Boy brought to school → Teacher asks questions → Father/teacher observe → Boy refuses to name book → Boy says "Yaw" → Boy runs away.
- Step 2: Map each event to Freytag's stages: Exposition (boy brought), Rising Action (questions, observation), Climax (refusal "I am a wild tribal"), Falling Action (single word "Yaw"), Resolution (flight).
- Step 3: Verify linearity — no flashbacks, no frame. The structure *is* the straight line of colonial imposition: entry → testing → breaking → exit.
- Step 4: Connect structure to theme: The rigid linearity mirrors the rigid curriculum — no space for the child's knowledge. The climax is a *structural rupture* (the boy speaks his truth) that the structure cannot contain, so he exits the narrative (runs away).
- Step 5: Write PEEL paragraph: Point (Linear structure enacts colonial violence), Evidence (Climax at refusal, not at "Yaw"), Explanation (Structure denies child's knowledge until rupture), Link (Thus structure = theme).

REASONING: This 5-step process moves from event identification (remember) to structural mapping (understand) to thematic synthesis (analyze) — exactly what board "analyze the plot structure" questions require.

ANSWER: The story follows a strict linear Freytag structure. Exposition: tribal boy dragged to colonial school. Rising Action: teacher's Eurocentric questions (history, geography, kings). Climax: boy's defiant self-definition "I am a wild tribal" — the only moment his voice enters the structure. Falling Action: "Yaw" (yes/okay) — submission or dismissal? Resolution: he runs, exiting the narrative space. The linearity *is* the violence: no flashback to his world, no frame to contextualize — just imposition → rupture → escape.

## WORKED_EXAMPLE_2
PROBLEM: Explain how the narrative structure of "?kM+h osQ iq”ksZ" (frame narrative + extended metaphor) constructs the argument that "education must develop the individual's mind, not stuff it for exams".

STEPS:
- Step 1: Identify the two narrative layers: Outer frame (narrator visits school, sees watchmaker) → Inner frame (watchmaker's lecture on time/education). Note: the lecture *contains* a mini-history of timekeeping (flashback within frame).
- Step 2: Analyze the watch metaphor as structural backbone: Watch = child's mind; Repair = education; Watchmaker = true teacher; Owner = system/parents. The metaphor *structures* the argument — each part of the watch maps to an educational principle.
- Step 3: Trace how the frame creates authority: The narrator *witnesses* the lecture, lending empirical weight to the philosophy. We don't just hear the argument; we see the watchmaker's "thin body, sunken eyes" — embodiment of neglected wisdom.
- Step 4: Contrast with linear argument: A direct essay would say "education should...". The frame *shows* a living example (watchmaker) whose very existence proves the argument. Structure performs the proof.
- Step 5: Synthesize: The frame narrative transforms abstract critique into embodied witness. The flashback to history of time (sundials → clocks) structurally parallels the history of education (gurukul → colonial) — structure *is* the comparison.

REASONING: Frame narrative analysis requires identifying layers, mapping metaphor to structure, and evaluating rhetorical effect — a 5-step move from identification to synthesis.

ANSWER: The story uses a double frame: (1) Narrator's visit frames (2) Watchmaker's lecture, which itself contains a historical flashback. The watch metaphor structurally organizes the entire critique: mainspring = child's curiosity, gears = subjects, hands = output, repair = nurturing not forcing. The frame gives the philosophy *evidentiary weight* — we see the watchmaker's poverty and wisdom. The historical flashback structurally equates colonial time-discipline with colonial mind-discipline. The structure doesn't just hold the argument; it *proves* it by showing a man who lives it.

## WORKED_EXAMPLE_3
PROBLEM: Compare the narrative structures of all three stories in the chapter. How does each structure serve a distinct thematic purpose: (a) exposing colonial violence, (b) advocating educational philosophy, (c) allegorizing political exploitation?

STEPS:
- Step 1: Create a 3-column table: Story | Structure Type | Key Structural Device | Thematic Function.
- Step 2: Fill for "ckyd cp x;k": Linear realism | Zero structural mediation (no flashback, frame, allegory) | Exposes colonial violence by *denying* the child's world any narrative space — the structure *enacts* erasure.
- Step 3: Fill for "?kM+h osQ iq”ksZ": Frame narrative + extended metaphor | Watch as structural metaphor + witness frame | Advocates philosophy by *embodying* it in a character and *witnessing* him — structure converts opinion into testimony.
- Step 4: Fill for "<sys pqu yks": Allegorical fable | One-to-one mapping (bird parts = classes) + poetic coda | Allegorizes exploitation by making structure *equal* to politics — no gap between story and meaning.
- Step 5: Synthesize comparison: Panchakaji uses three structures for three *kinds* of truth: (a) Linear = historical fact (this happened), (b) Frame = philosophical witness (this is wise), (c) Allegory = structural law (this is how power works).
- Step 6: Write comparative thesis: The chapter itself is a triptych of narrative forms, each matched to its epistemic claim — a meta-structural choice.

REASONING: This 6-step comparative analysis (catalog → map → contrast → synthesize → theorize) mirrors the highest-level board competency questions (case-based, multi-text) and CUET literary analysis.

ANSWER: "ckyd cp x;k" uses brutal linearity to enact colonial erasure — the child's world gets zero narrative space. "?kM+h osQ iq”ksZ" uses a witness frame + watch metaphor to give philosophy evidentiary weight — structure = testimony. "<sys pqu yks" uses pure allegory where structure *is* political theory — bird parts = classes, choice = policy. Together, they form a meta-narrative: fact → wisdom → law. Panchakaji doesn't just write three stories; he deploys three *epistemic structures*.

## COMPETENCY_QUESTION_1
QUESTION: A Class 12 student writes: "The plot of '?kM+h osQ iq”ksZ' is that a man visits a school and listens to a watchmaker talk about time." Identify the competency gap in this answer and rewrite it as a structural analysis statement using the terms 'frame narrative' and 'extended metaphor'.

COMPETENCY: Conceptual Understanding → Structural Terminology Application
STEPS:
- Step 1: Identify the error — the student summarized the *outer frame's plot* but ignored the *inner frame's argument* and the *metaphor's structural role*.
- Step 2: Recall definition: Frame narrative = story within a story where inner comments on outer. Extended metaphor = sustained mapping across the narrative.
- Step 3: Rewrite: "The narrative employs a frame structure where the narrator's visit (outer frame) authenticates the watchmaker's lecture (inner frame), which operates as an extended metaphor mapping watch mechanics to educational philosophy."
- Step 4: Verify — does the rewrite use structural terms to explain *how* the story works, not just *what* happens? Yes.

ANSWER: Competency gap: Confusing plot summary (level 1) with structural analysis (level 4). Rewritten: "Panchakaji constructs a frame narrative in which the narrator's empirical observation of the watchmaker legitimizes the inner discourse, while the watch functions as an extended metaphor structurally equating horology with pedagogy — each mechanical component (mainspring, gear, hand) maps to an educational principle (curiosity, curriculum, outcome)."

DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: In "<sys pqu yks", the bird chooses the stomach as the ruling organ. Using the concept of 'allegorical structure', explain why this choice is structurally inevitable — i.e., why the narrative structure *demands* the stomach, not the eyes or wings. Then, evaluate whether the final couplet ("vkt dk dcwrj vPNk gS dy osQ eksj ls...") strengthens or fractures the allegorical structure.

COMPETENCY: Critical Thinking → Structural Reasoning & Evaluation
STEPS:
- Step 1: Define allegorical structure: one-to-one, sustained mapping where narrative agents *are* abstract concepts (Stomach = peasantry/labor, Eyes = intellectuals, Wings = military, etc.).
- Step 2: Analyze the bird's body as a political body: The stomach *consumes* and *distributes* — it is the metabolic base. In Marxist terms (which the allegory invokes), the economic base determines the superstructure. The structure *requires* the base to rule.
- Step 3: Test alternatives: If eyes ruled → idealist error (intellectuals don't produce). If wings ruled → militarist error (force doesn't sustain). The allegory's logic (production → distribution → survival) structurally necessitates the stomach.
- Step 4: Evaluate the couplet: It shifts from *allegorical past* ("once a bird...") to *direct present* ("today's exploitation is..."). This *fractures* the allegorical structure by breaking the one-to-one mapping — the poet steps out of the fable to address the reader directly.
- Step 5: Judge: The fracture is *deliberate and effective* — it converts the allegory from a closed fable into an open political intervention. The structure serves the theme by *breaking* itself at the end.

ANSWER: The allegorical structure maps bird anatomy to social anatomy: stomach = productive base (peasants/workers), eyes = ideological superstructure (intellectuals), wings = coercive apparatus (military). Since the fable's logic is materialist (survival depends on production), the stomach *must* win — the structure encodes historical materialism. The final couplet fractures the allegory by switching from third-person fable to second-person address ("vkt dk dcwrj..."), but this fracture is the poem's political point: allegory explains the structure; the couplet demands action *against* it. The structure doesn't just represent exploitation; it enacts the break from it.

DIFFICULTY: hard