## DEFINITION
Literal comprehension questions require retrieving explicitly stated information from the text, while inferential comprehension questions demand drawing logical conclusions by combining textual evidence with reasoning, going beyond what is directly written.

## COGNITIVE_LEVEL
apply

## MASTERY_CRITERIA
The student can independently classify a question as literal or inferential, locate exact textual evidence for literal answers, and construct inferential answers using a "claim + evidence + reasoning" structure that links implicit meaning to specific lines in the poem.

## SCOPE_BOUNDARY
This node covers strategies for answering literal and inferential questions based solely on the poem "vkvks] feydj cpk,¡" from the NCERT textbook. It does not cover critical appreciation, creative writing, or grammar rules, which are addressed in subsequent nodes.

## WALKTHROUGH
Imagine you are sitting in the exam hall and the first question asks, "What does the poet compare words to in the opening lines?" while the second asks, "Why does the poet feel the need to invite the reader to witness rural life?" The first is literal — you just need to spot the simile in stanza one. The second is inferential — you must connect the invitation to the poem's theme of vanishing folk culture. Start by reading the question twice, underline keywords, then scan the poem for those words or their synonyms. For literal questions, copy or paraphrase the exact line. For inferential questions, ask yourself: "What is the poet implying about society, human nature, or the theme here?" and find two supporting details. The key insight: every inferential answer is built on literal facts; you cannot infer without first observing.

## DIAGNOSTIC_QUESTION_1
What is the basic difference between a literal comprehension question and an inferential comprehension question?

## DIAGNOSTIC_ANSWER_1
A literal question asks for information directly stated in the text (e.g., "What color is the ekVh?"), while an inferential question asks for meaning that is implied but not directly written (e.g., "Why does the poet describe the ekVh as 'fe^h'?"). A wrong answer that says "literal questions are easy and inferential are hard" reveals the student is confusing difficulty level with cognitive process, and may not know how to locate explicit evidence versus how to synthesize implicit meaning.

## DIAGNOSTIC_QUESTION_2
In the poem, the line "Hkksykiu fny dk vD[kM+iu] tq>k:iu Hkh" appears. A student answers the inferential question "Why are both vD[kM+iu and tq>k:iu mentioned together?" with "Because the poet likes both happiness and sadness." Explain why this answer is incomplete.

## DIAGNOSTIC_ANSWER_2
The answer is incomplete because it treats the inference as a personal preference of the poet rather than a thematic statement about the totality of rural life. The correct inference connects the duality to the poem's central message: folk life embraces both joy (vD[kM+iu) and struggle (tq>k:iu) as inseparable parts of an authentic existence. A wrong answer reveals the student is making a surface-level emotional guess instead of linking textual contrast to the theme of holistic acceptance developed in the "Theme" nodes (c11_hin_ar_cbse_16_006, c11_hin_ar_cbse_16_007).

## DIAGNOSTIC_QUESTION_3
Apply the literal comprehension strategy to this question: "According to the poem, what are the three things the poet says are 'for children' (cPpksa osQ fy,)?" List the steps you would take to find the answer.

## DIAGNOSTIC_ANSWER_3
Steps: 1) Identify keywords: "cPpksa osQ fy," and "three things". 2) Scan the poem for the phrase "cPpksa osQ fy," — it appears in the second long stanza. 3) Locate the exact line: "cPpksa osQ fy, eSnku". 4) Note that only one item is explicitly listed for children in that line; the other two lines mention "i'kqvksa osQ fy, gjh&gjh ?kkl" and "cw<+ksa osQ fy, igkM+ksa dh 'kkfUr". 5) Compile the three explicit items: eSnku, gjh&gjh ?kkl, igkM+ksa dh 'kkfUr. A wrong answer that guesses "toys, games, stories" shows the student did not scan for the exact textual phrase and relied on external assumptions.

## DIAGNOSTIC_QUESTION_4
Analyze the following inferential question: "The poem ends with 'FkksM+s&ls lius / vkvks] feydj cpk,¡A' What does the repetition of 'FkksM+' (big/large) three times suggest about the poet's vision of life?" Break down the literary device and its thematic effect.

## DIAGNOSTIC_ANSWER_4
The repetition of "FkksM+" (FkksM+k&lk fo'okl, FkksM+h&lh mEehn, FkksM+s&ls lius) is an example of anaphora and amplification. It suggests that life's canvas is expansive enough to contain grand illusions (fo'okl), deep affections (mEehn), and ultimate liberation (lius). The progression from external world to inner feeling to transcendence mirrors the poem's movement from sensory observation to spiritual invitation. A wrong answer that only says "it shows emphasis" misses the structural progression and fails to connect the device to the theme of boundless inclusivity established in the "Literary Devices" nodes (c11_hin_ar_cbse_16_008, c11_hin_ar_cbse_16_009).

## DIAGNOSTIC_QUESTION_5
Evaluate this student's answer to an inferential question: "Question: 'Why does the poet use the image of 'ukpus osQ fy, [kqyk vk¡xu' (for the sad, a dry smile)? Answer: 'The poet wants to show that sad people smile fakely.'" Is this a valid inference? Justify.

## DIAGNOSTIC_ANSWER_5
No, it is not a valid inference because it imposes a negative judgment ("fakely") not supported by the text. The phrase "[kqyk vk¡xu" (dry smile) in context suggests a smile that has no moisture of tears left — a smile of resignation, endurance, or quiet acceptance after prolonged sorrow, not deceit. The poem celebrates authenticity of folk emotions. A valid inference would be: "The dry smile represents the stoic resilience of rural folk who have exhausted their tears and now face hardship with a weathered, enduring grace." The wrong answer reveals the student is projecting urban cynicism onto a folk sensibility, ignoring the cultural context built in node c11_hin_ar_cbse_16_001.

## DIAGNOSTIC_QUESTION_6
Create a literal and an inferential question based on the line: "BaMh gksrh fnup;kZ esa / thou dh xekZgV". Your questions must be answerable only from the poem's internal logic.

## DIAGNOSTIC_ANSWER_6
Literal: "What two things are described as happening in the 'fnup;kZ' (afternoon)?" (Answer: BaMh gksrh and thou dh xekZgV). Inferential: "Why might the poet choose the afternoon — a time of harsh light and heat — to depict the 'xekZgV' (agony/convulsion) of life?" (Answer: Afternoon symbolizes the peak of life's struggles where illusions fade and raw reality is exposed, aligning with the poem's theme of unflinching truth-telling). A poor answer would create questions that require outside knowledge (e.g., "What is the scientific reason for afternoon heat?") showing the student doesn't understand "text-dependent" questioning.

## COMMON_MISCONCEPTION
Students believe inferential questions have "no right answer" and that any personal opinion counts as a valid inference. They write answers like "I think the poet is sad because..." without anchoring in textual evidence. This error stems from confusing literary inference with subjective reader-response. In board exams, an inference is only valid if it is logically derived from specific textual cues (word choice, imagery, structure, tone) and aligns with the poem's established themes. For example, saying "The poet hates cities" is an opinion; saying "The poet contrasts urban artificiality ('v'kksd flag') with folk authenticity to critique modernity" is a text-based inference supported by the poet's biography (node c11_hin_ar_cbse_16_001) and the irony device (node c11_hin_ar_cbse_16_009).

## ON_FAILURE
1. Have the student re-read the poem with a highlighter, marking only explicit facts (names, colors, actions, direct descriptions) in one color and implied ideas (emotions, judgments, thematic suggestions) in another. 2. Practice converting 5 literal questions into inferential ones by adding "Why," "How," or "What does this suggest about..." to the same factual base. 3. For each inferential question, require the student to write: "The text says _____, which implies _____ because _____." 4. Use the vocabulary node (c11_hin_ar_cbse_16_010) to clarify words like 'vD[kM+iu' and 'tq>k:iu' that are often misinterpreted, as lexical gaps are the primary cause of faulty inferences.

## BUILDS_ON
This node builds on the student's ability to identify explicit textual details (literal comprehension) developed through plot, setting, and vocabulary nodes.

## LEADS_TO
This node enables critical thinking (c11_hin_ar_cbse_16_013) where students evaluate interpretations, and writing skills (c11_hin_ar_cbse_16_014) where they embed literal and inferential evidence in structured answers.

## PREREQUISITE_NODE_IDS
c11_hin_ar_cbse_16_001, c11_hin_ar_cbse_16_002, c11_hin_ar_cbse_16_003, c11_hin_ar_cbse_16_006, c11_hin_ar_cbse_16_010, c11_hin_ar_cbse_16_011, c11_hin_ar_cbse_16_007, c11_hin_ar_cbse_16_008, c11_hin_ar_cbse_16_009

## PREREQUISITE_REASONS
c11_hin_ar_cbse_16_001: Provides biographical and socio-cultural context essential for valid inferences about the poet's intent.
c11_hin_ar_cbse_16_002: Establishes the narrative sequence; literal questions often test plot points.
c11_hin_ar_cbse_16_003: Sets the atmospheric backdrop; many inferences rely on setting-mood connections.
c11_hin_ar_cbse_16_006: Primary theme (holistic acceptance of life) is the anchor for all thematic inferences.
c11_hin_ar_cbse_16_010: Key vocabulary (vkcks&gok, vD[kM+iu, tq>k:iu, lksaèkkiu, mEehn) must be understood to avoid lexical errors in both literal and inferential answers.
c11_hin_ar_cbse_16_011: Grammatical structures (e.g., imperative mood in "vkvks", "cpk,¡") signal tone and intention for inference.
c11_hin_ar_cbse_16_007: Comprehension questions test thematic understanding directly.  
c11_hin_ar_cbse_16_008: Inferential comprehension questions require explaining *how* imagery/metaphor constructs meaning beyond literal sense.  
c11_hin_ar_cbse_16_009: Inferential comprehension questions often ask "What does X symbolize?" or "Why is the tone ironic?" — this node provides the toolkit.  

## FORWARD_NODE_IDS
c11_hin_ar_cbse_16_013, c11_hin_ar_cbse_16_014, c11_hin_ar_cbse_16_015, c12_hin_a_cbse_16_012, c12_hin_ar_cbse_04_012, c12_hin_a_cbse_16_001

## FORWARD_REASONS
c11_hin_ar_cbse_16_013: Critical thinking requires evaluating multiple inferences; this node supplies the evidence-base.
c11_hin_ar_cbse_16_014: Writing skills (analytical paragraphs, essays) demand the PEEL structure practiced here: Point (inference), Evidence (literal quote), Explanation, Link.
c11_hin_ar_cbse_16_015: Speaking/listening discussions need students to distinguish factual recall from interpretive claims during peer dialogue.
c12_hin_a_cbse_16_012: अगला तार्किक चरण: Literal comprehension questions require answers directly stated in the text (facts, events, dialogue... इस नोड की अवधारणाओं को सीधे उपयोग/विस्तारित करता है।  
c12_hin_ar_cbse_04_012: अगला तार्किक चरण: Literal comprehension is the ability to extract explicitly stated facts, details, and sequences dire... इस नोड की अवधारणाओं को सीधे उपयोग/विस्तारित करता है।  
c12_hin_a_cbse_16_001: key terms (e.g., "वककक", "थकककक"). c11_hin_ar_cbse_01_012: Class 11 literal/inferential foundation. c11_hin_ar_cbse_16_012: Previous chapter's comprehension practice.  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
none

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_16_002 -> c11_hin_ar_cbse_16_012 -> c11_hin_ar_cbse_16_013

## THIS_FORMULA
Literal Answer = Direct Textual Evidence (Quote/Paraphrase) | Inferential Answer = Claim + Textual Evidence (Quote/Paraphrase) + Reasoning (Link to Theme/Device/Context)

## FORMULA_VARIABLES
N/A

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
linguistic

## CROSS_SUBJECT
c11_history_rural_society | The poem's depiction of folk life (rituals, labor, oral tradition) connects to historical study of pre-modern village communities and their cultural resilience.
c11_sociology_folk_culture | Concepts of 'lok jeevan' (folk life) and 'lok sanskriti' (folk culture) in the poem align with sociological analysis of community bonds, collective identity, and the impact of modernization on traditional societies.

## PREREQ_CONCEPT
Ability to distinguish between explicitly stated information and implied meaning in a literary text.

## PREREQ_BEFORE
Student must have read the poem "vkvks] feydj cpk,¡" at least twice and completed the vocabulary exercise (c11_hin_ar_cbse_16_010) for key terms.

## PREREQ_STUCK
If stuck, review the poem's summary and key vocabulary list in node c11_hin_ar_cbse_16_002 and c11_hin_ar_cbse_16_010 respectively.

## WORKED_EXAMPLE_1
PROBLEM: Answer the literal question: "What are the four groups of people mentioned in the stanza beginning with 'ukpus osQ fy,' and what is the poet's wish for each?" (Based on the poem's second long stanza)
STEPS:
- Step 1: Identify the target stanza — it is the stanza listing purposes for different groups (ukpus, xkus, g¡lus, jksus, cPpksa, i'kqvksa, cw<+ksa).
- Step 2: Scan for the four groups explicitly asked for. The question specifies "four groups" but the stanza lists seven. Select the first four distinct groups: ukpus (the sad), xkus (the angry), g¡lus (the laughing), jksus (the sleeping).
- Step 3: For each group, locate the exact phrase starting with "osQ fy," that follows the group name.
- Step 4: Extract the wished action: ukpus -> [kqyk vk¡xu (dry smile), xkus -> xhr (laughter), g¡lus -> FkksM+h&lh f[kyf[kykgV (hearty guffaw), jksus -> eq_h Hkj ,dkUr (deep peaceful sleep).
- Step 5: Format the answer clearly as a list matching group to wish, using the poem's exact vocabulary.
REASONING: Literal questions require precise retrieval. The stanza uses a parallel structure (group + osQ fy, + wish), making it a catalog. The student must recognize the pattern and extract each pair without omitting or adding interpretation.
ANSWER: 1. ukpus (sad people) osQ fy, [kqyk vk¡xu (a dry smile). 2. xkus (angry people) osQ fy, xhr (laughter). 3. g¡lus (laughing people) osQ fy, FkksM+h&lh f[kyf[kykgV (hearty guffaw). 4. jksus (sleeping people) osQ fy, eq_h Hkj ,dkUr (deep peaceful sleep).

## WORKED_EXAMPLE_2
PROBLEM: Answer the inferential question: "The poet writes 'Hkhrj dh vkx / èkuq"k dh Mksjh / rhj dk uqdhykiu / oqQYgkM+h dh èkkj'. What does this cluster of images suggest about the poet's view of rural labor?" (Based on the third long stanza)
STEPS:
- Step 1: Identify the four images: Hkhrj dh vkx (heat of the plough), èkuq"k dh Mksjh (fragrance of sweat), rhj dk uqdhykiu (melody of the path), oqQYgkM+h dh èkkj (pain of the thorn).
- Step 2: Classify each image by sensory domain: tactile (heat), olfactory (fragrance), auditory (melody), tactile/pain (thorn).
- Step 3: Note the pairing of positive and negative sensations: heat/fragrance (productive labor), melody/pain (journey's cost). This duality mirrors the vD[kM+iu/tq>k:iu duality earlier.
- Step 4: Infer the attitude: The poet does not romanticize labor (acknowledges heat, thorns, pain) nor condemn it (celebrates fragrance, melody). The view is one of integrated acceptance — labor is sacred because it engages the whole sensorium.
- Step 5: Connect to the poem's central theme (from node c11_hin_ar_cbse_16_006): "Come, let us witness" — the invitation is to see this wholeness, not a sanitized version.
- Step 6: Draft answer using claim-evidence-reasoning: Claim = The poet views rural labor as a holistic, sacred act embracing both joy and suffering. Evidence = The sensory cluster juxtaposing 'èkuq"k dh Mksjh' with 'oqQYgkM+h dh èkkj'. Reasoning = This mirrors the poem's philosophy that authenticity requires embracing life's totality.
REASONING: Inferential questions require synthesizing multiple textual details into a coherent interpretation. The step-by-step breakdown ensures the inference is grounded in textual patterns (sensory imagery, duality) and thematic context, not personal projection.
ANSWER: The cluster suggests the poet sees rural labor as a complete sensory experience where hardship (heat, thorns) and fulfillment (fragrance of sweat, melody of the path) are inseparable. By engaging touch, smell, hearing, and pain simultaneously, the images convey that authentic work is not merely toil but a form of embodied worship — a theme central to the poem's invitation to witness folk life without illusion.

## WORKED_EXAMPLE_3
PROBLEM: A board exam question asks: "How does the poet use the imperative mood throughout the poem to structure the reader's journey from observation to participation? Support your answer with three examples from different stanzas." (Combines grammar from c11_hin_ar_cbse_16_011 with comprehension)
STEPS:
- Step 1: Recall grammar concept: Imperative mood expresses commands, requests, invitations (verbs like vkvks, cpk,¡, feydj, le>kSrs).
- Step 2: Scan the poem for imperative verbs. Find: Stanza 1: "vkvks] feydj cpk,¡" (Come, see). Stanza 2: "le>kSrs" (understand - implied imperative in "cM+s le>kSrs"). Stanza 3: "cpk,¡ mls" (see it). Final refrain: "vkvks] feydj cpk,¡".
- Step 3: Analyze progression: First imperative (vkvks, feydj cpk,¡) = invitation to physical witnessing. Middle imperative (le>kSrs/cpk,¡ mls) = invitation to intellectual/emotional understanding. Final imperative (vkvks, feydj cpk,¡) = renewed, urgent call to participatory empathy.
- Step 4: Link to reader's journey: The repetition transforms the reader from outsider observer to engaged witness. The grammar enacts the theme: seeing leads to understanding leads to solidarity.
- Step 5: Select three distinct examples spanning the poem: 1) Opening "vkvks] feydj cpk,¡" (stanza 1). 2) "cM+s le>kSrs" / "cpk,¡ mls" (stanza 2). 3) Closing "vkvks] feydj cpk,¡" (final line).
- Step 6: Structure answer: State the grammatical pattern, give each example with stanza reference, explain the shift in cognitive demand (see -> understand -> see deeply), conclude with thematic significance.
REASONING: This worked example demonstrates the cross-node integration required at Class 11: grammar (imperative mood) is not isolated but a tool for thematic development. The 6-step process ensures the student connects linguistic form to literary function.
ANSWER: The poet employs the imperative mood to choreograph the reader's movement from passive looking to active witnessing. (1) In the opening stanza, "vkvks] feydj cpk,¡" commands physical presence — "come and see." (2) In the central stanza, "cM+s le>kSrs" (understand deeply) and "cpk,¡ mls" (see it closely) escalate the demand to intellectual and empathetic engagement with the "ph”k" (wounds) of folk society. (3) The closing refrain "vkvks] feydj cpk,¡" returns to the initial verbs but now charged with the weight of all that has been revealed — it is no longer a casual invitation but a moral summons. The grammatical repetition thus structures the poem as an expanding circle of consciousness.

## COMPETENCY_QUESTION_1
QUESTION: "A student writes the following answer to an inferential question: 'The poet repeats "vkvks] feydj cpk,¡" at the end to show he really wants us to come.' The question was: 'Discuss the significance of the refrain in the poem.' Evaluate this answer. What is missing? Rewrite the answer to meet board exam standards."
COMPETENCY: Critical evaluation of peer response and application of textual evidence to improve answer quality.
STEPS:
- Step 1: Identify the weakness: The student's answer is a literal paraphrase of the verb ("really wants us to come") and ignores the structural, thematic, and emotional evolution of the refrain.
- Step 2: Determine what a board-standard answer requires: (a) Identification of refrain as a poetic device. (b) Analysis of how context changes meaning between first and last occurrence. (c) Connection to central theme (witnessing folk life). (d) Use of at least one other textual detail to support.
- Step 3: Draft improved answer using PEEL: Point = The refrain acts as a structural anchor that deepens from invitation to imperative. Evidence = Opening "vkvks] feydj cpk,¡" precedes the catalog of folk images; closing refrain follows the depiction of suffering (tq>k:iu, oqQYgkM+h dh èkkj) and grandeur (FkksM+k&lk fo'okl). Explanation = The second occurrence carries the accumulated weight of all the images witnessed, transforming a simple call into a demand for solidarity with the marginalized. Link = This mirrors the poem's arc from seeing to understanding to standing with.
- Step 4: Ensure vocabulary from node c11_hin_ar_cbse_16_010 (e.g., 'vkcks&gok', 'ph”k') and theme from c11_hin_ar_cbse_16_006 are integrated.
ANSWER: The student's answer is inadequate because it treats the refrain as mere repetition of desire rather than a structural device that accumulates meaning. A board-level answer: The refrain "vkvks] feydj cpk,¡" functions as a circular structural device that marks the reader's epistemic journey. Initially, it is an aesthetic invitation to witness the "iwjh ÅtkZ" (complete panorama) of folk life. By the end, after the reader has been shown the "ph”k" (wounds) of feudal exploitation ("firk vkSj pkpk f'k{kd"), the duality of "vD[kM+iu] tq>k:iu", and the grandeur of "FkksM+k&lk fo'okl", the same words become an ethical summons. The repetition signals that true seeing ("feydj cpk,¡") requires not just eyes but conscience — aligning with the poet's Marxist-humanist perspective noted in the chapter introduction.
DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: "The poem contains the line: 'laFkkyh lekt vkSj mlosQ jkx&cksèk ls xgjk tqM+ko igys ls Fkk] ufl±x dh f'k{kk osQ le; ckgj dh nqfu;k ls Hkh ifjp; gqvkA' (From the poet's biography in the textbook). Using this context, answer the inferential question: 'Why does the poet choose the imperative "vkvks" (come) rather than "vk,¡" (go) or "ns[k,¡" (look)?' Your answer must integrate biographical context, grammatical choice, and thematic intent."
COMPETENCY: Synthesis of biographical context, grammatical analysis, and thematic inference.
STEPS:
- Step 1: Analyze the grammatical distinction: "vkvks" (come - movement toward speaker) vs "vk,¡" (go - movement away) vs "ns[k,¡" (look - static observation). "vkvks" implies the speaker is already at the destination and invites the listener to join them there.
- Step 2: Recall biographical context: The poet (fueZyk iqrqy) emerged from folk roots, was educated in urban modernity, then returned to folk sensibility. He stands *inside* the folk world ("vknfe;ksa ij cgl") looking out.
- Step 3: Infer thematic intent: "vkvks" positions the poet as a guide *within* the folk world, not an outsider pointing at it ("ns[k,¡") or sending the reader away ("vk,¡"). It enacts the poem's politics: the urban reader must *enter* the folk space to understand it, not observe it from a distance.
- Step 4: Connect to the specific biographical line: The poet's consciousness ("cksèk fodflr gqvk") was formed by both folk roots ("nqfu;k") and urban education ("ufl±x dh f'k{kk"). The imperative "vkvks" bridges these — he calls from the folk side.
- Step 5: Compose answer integrating all three layers: grammar (deictic center), biography (positionality), theme (bridging worlds).
ANSWER: The choice of "vkvks" (come) over "vk,¡" (go) or "ns[k,¡" (look) is a deliberate deictic and political act. Grammatically, "vkvks" places the speaker at the destination — the folk world ("vknfe;ksa ij cgl") — and summons the listener to move *toward* that center. Biographically, the poet's consciousness was "fodflr" (developed) through the "fozQ;k&izfrfozQ;k" (dialectic) of folk roots ("nqfu;k") and urban education ("ufl±x dh f'k{kk"). He now stands *within* the folk epistemology, having returned to it. "ns[k,¡" would imply a detached, anthropological gaze — the very "v'kksd flag" (urban language) perspective the poem critiques. "vk,¡" would exile the reader from the experience. "vkvks" insists on participatory witness: the reader must cross the threshold into the "nkSj" (time/space) of folk life to grasp its "okLrfod fLFkfr" (objective reality). The verb itself performs the poem's central argument: understanding requires presence, not observation.
DIFFICULTY: hard