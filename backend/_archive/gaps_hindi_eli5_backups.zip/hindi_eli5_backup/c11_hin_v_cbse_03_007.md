## DEFINITION
Secondary themes are the subordinate yet significant ideas that run parallel to the primary theme, enriching the narrative by exploring specific dimensions of human experience such as gender, class, education, or relationships, and they interact with the primary theme to create a multi-layered textual meaning.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student must be able to independently identify at least three distinct secondary themes in "vkyks&vk¡èkkfj", provide specific textual evidence (incidents, dialogues, character interactions) for each, and write a structured analytical paragraph explaining how each secondary theme complicates, supports, or contrasts with the primary theme of dignity and self-assertion.

## SCOPE_BOUNDARY
This node covers the identification, evidence-gathering, and analytical writing for secondary themes in Krishna Sobti's "vkyks&vk¡èkkfj". It does NOT cover the primary theme analysis (node 006), literary devices like imagery/irony (nodes 008, 009), or plot summary (node 002). It focuses exclusively on thematic layers beyond the central struggle for dignity.

## WALKTHROUGH
Imagine you are listening to a friend describe their first job — they talk about the hard work (primary struggle), but also mention how they learned to speak up, how the boss's wife taught them to use a computer, and how they finally rented their own room. Those extra threads — learning, mentorship, independence — are secondary themes. In this chapter, start by re-reading the protagonist's interactions with the *rkrq'k* (Krishnakant) and *tsBw* (Tasveeri) households. Look for recurring patterns: every time she picks up a pen, every time an employer crosses a boundary, every time she negotiates her space. Mark these passages. The key insight is that secondary themes are not just "topics" like "education"; they are the author's commentary on how education *functions* in a marginalized woman's life — as liberation, as burden, as identity.

## DIAGNOSTIC_QUESTION_1
List three secondary themes present in "vkyks&vk¡èkkfj" with one specific textual reference (incident or dialogue) for each.

## DIAGNOSTIC_ANSWER_1
**Correct Answer:** 
1. **Education/Literacy as Liberation** – The protagonist learning to read/write under Krishnakant's guidance (e.g., the diary-writing episode where she says "fy[kus dks rqe viuh thou&dgkuh Hkh fy[k ldrh gksA").
2. **Complex Employer-Employee Dynamics** – The contradictory behavior of the first employer's wife who questions her presence but later relies on her completely ("rqe ;gk¡ vosQyh jgrh gks\ rqEgkjk Lokeh dgk¡ jgrk gS\").
3. **Search for Home/Belonging** – The protagonist's repeated displacement and final settlement in her own room ("eSa lksprh fd mlls vPNh txg dgk¡ fey ldrh gSA").

**Wrong Answer Reveals:** If a student lists topics like "poverty," "hard work," or "women's issues" without a *thematic statement* (e.g., "education empowers" vs just "education") or textual anchor, they confuse *subject* with *theme*. If they cite only the primary struggle (dignity), they haven't distinguished primary from secondary.

## DIAGNOSTIC_QUESTION_2
Explain in your own words how the theme of "writing as self-fashioning" operates differently from the theme of "literacy as skill acquisition" in the text.

## DIAGNOSTIC_ANSWER_2
**Correct Answer:** 
"Literacy as skill acquisition" refers to the functional learning of reading/writing (Krishnakant giving her a notebook, teaching letters, the practical goal of signing her name). "Writing as self-fashioning" is the protagonist's *agential* use of that skill to construct her identity — she writes her autobiography (*fp_h*), revises her past, and claims authorship ("eSa viuk dke fd, tkvksA cl] fy[kks vkSj i<+ksA"). The first is externally initiated; the second is internally driven.

**Wrong Answer Reveals:** If the student treats both as the same "learning to write," they miss the crucial shift from *passive recipient* of education to *active producer* of narrative. This confusion flattens the protagonist's agency, a central concern in senior-secondary feminist/Dalit literary analysis.

## DIAGNOSTIC_QUESTION_3
In the episode where the protagonist's mother (*ek*) dies and she cannot attend the funeral, identify which secondary theme is most sharply illuminated and explain how the narrative structure (flashback, dialogue) serves that theme.

## DIAGNOSTIC_ANSWER_3
**Correct Answer:** 
The theme **"The Invisibility of Domestic Labor in Kinship"** is illuminated. The structural juxtaposition — her employer Krishnakant urging her to go ("rqe vkt gh tkdj mls ys vkvks") while her own brother (*ckck*) refuses to inform her in time ("eq>s fdlh us ugha crk;k") — uses dialogue and delayed revelation to show that her labor in the employer's house has replaced her role in the natal family. The flashback to her mother's earlier death (*ckck* not telling her) creates a pattern: the domestic worker's body is present in the employer's home, but absent in her own family's rituals.

**Wrong Answer Reveals:** If the student says "grief" or "family conflict," they name an emotion or plot point, not a theme. If they ignore the structural device (flashback/repetition), they miss how *form* reinforces *theme* — a board-exam expectation for "analyze" level questions.

## DIAGNOSTIC_QUESTION_4
Compare the secondary themes of "maternal substitution" (the protagonist as mother-figure to employers' children) and "biological motherhood denied" (her own children sent away). How does this contrast structure the novel's critique of gendered labor?

## DIAGNOSTIC_ANSWER_4
**Correct Answer:** 
The protagonist mothers *vtqZu nk*'s children (*lq[knhi*, *je.k*), *tsBw*'s children, and even *rkrq'k* emotionally ("rkrq'k us dgk] csch] rqEgkjs caèkq rqEgkjk fdruk mRlkg c<+k jgs gSa"), performing affective labor that is valued. Simultaneously, her own sons (*HkkbZ*, *ckck*) are raised by others, and she cannot mother them ("cPpksa dks iky&iksldj cM+k djus dh rjI+kQ eSa vfèkd è;ku nsus yxh"). This structural irony — mothering *for wages* vs. mothering *by right* — critiques how capitalism and patriarchy extract reproductive labor from poor women while denying them the social status of motherhood. The text does not romanticize either; it shows the *cost* of both.

**Wrong Answer Reveals:** If the student only lists "she loves children" or "she misses her kids," they describe character feelings, not thematic structure. If they don't use the term "affective labor" or "reproductive labor" (or Hindi equivalents like *bavfFkZd dke* / *jansankhya dke*), they lack the conceptual vocabulary for Class 11 board answers.

## DIAGNOSTIC_QUESTION_5
Evaluate the claim: "The secondary theme of 'male mentorship' (Krishnakant, Tasveer, Hukam Singh) ultimately reinforces patriarchal dependency rather than subverting it." Defend or refute with three textual instances.

## DIAGNOSTIC_ANSWER_5
**Correct Answer (Refutation with Nuance):** 
While Krishnakant initiates her literacy ("eSa rqEgsa ,d ph"k ns jgk gw¡"), controls her publishing ("rkrq'k us viuh fy[kus dh Vsfcy osQ Mªkj ls ,d isu vkSj dkWih fudkyh"), and Tasveer facilitates her mobility, the protagonist *subverts* this mentorship by:
1. **Refusing patronage** – She rejects Krishnakant's offer to keep her children ("rqe vius cM+s yM+osQ dks dkyh iwtk ij oqQN fnuksa osQ fy, ys vkuk") asserting maternal autonomy.
2. **Claiming authorship** – She insists her writing is hers ("eSa viuk dke fd, tkvksA cl] fy[kks vkSj i<+ksA mlh ls lc oqQN vius vki gh rqEgkjs fnekx esa ?kql tk,xkA").
3. **Economic independence** – She buys her own room ("?kj fey Hkh x;k") using her earnings, not their charity.
The men *enable* but do not *define* her liberation. The theme is "strategic use of patriarchal resources," not dependency.

**Wrong Answer Reveals:** A binary "yes/no" answer without textual nuance fails. If the student says "Krishnakant helped her so it's patriarchy," they ignore her agency. If they say "she became independent so no patriarchy," they ignore structural constraints. Board exams reward *qualified* judgments with evidence.

## DIAGNOSTIC_QUESTION_6
Write a 100-word thematic statement for a *new* secondary theme you detect in the text: "The Body as Site of Resistance." Use two specific bodily actions (e.g., cooking, walking, writing, bleeding) as evidence.

## DIAGNOSTIC_ANSWER_6
**Expected Criteria:** 
- Names the theme clearly: "The Body as Site of Resistance."
- Identifies two *specific* bodily acts: e.g., (1) Her hands cooking elaborate meals (*rsy&lkcqu] [kkuk&ihuk] diM+s&oiM+s*) while enduring verbal abuse, transforming labor into art; (2) Her fingers writing *fp_h* despite cramps ("fy[kus esa Hkwysa bruh fd mldk dksbZ fBdkuk ugha"), reclaiming the body from domestic drudgery.
- Connects both to resistance: The body that *serves* also *creates* and *records*.
- Uses analytical vocabulary: "embodied agency," "somatic resistance," or Hindi equivalents (*sharirik pratirodh*, *dehik swatantrata*).

**Poor Answer Reveals:** Vague statements like "she works hard with her body" or "she writes with her hands" without linking to *resistance* or *theme*. Missing the analytical leap from *action* to *meaning*.

## COMMON_MISCONCEPTION
Students treat "secondary themes" as a checklist of topics (caste, gender, poverty) rather than as *arguable propositions* the text explores. They write "Caste is a secondary theme" instead of "The text interrogates how caste operates invisibly in domestic spaces through food rules (separate utensils, *lqvj ihNs*), spatial segregation (*V^h osQ fy, ckgj tkuk*), and the protagonist's own internalized hierarchy (*vtqZu nk* vs *je.k nk*)." The error stems from middle-school "theme = topic" teaching. At Class 11, theme = *author's perspective on a topic* + *textual development*.

## ON_FAILURE
1. **Re-read three key chapters** (Krishnakant's house, Tasveer's house, the final room) with a highlighter: mark every moment the protagonist *chooses* (not just endures).
2. **Convert topics to thematic statements**: For each highlighted moment, complete: "The text suggests that [topic] ______." (e.g., "Education ______" → "Education is a tool the protagonist weaponizes against erasure.")
3. **Map to primary theme**: Draw arrows — does this secondary theme *support*, *complicate*, or *contradict* "dignity through self-assertion"?
4. **Write one PEEL paragraph** per theme using the template: Point → Evidence (quote/incident) → Explanation (how evidence proves point) → Link (to primary theme/broader context).

## BUILDS_ON
Primary theme identification and protagonist's character arc (nodes 004, 006) — secondary themes only become visible *through* the protagonist's choices and the primary conflict.

## LEADS_TO
Literary devices analysis (nodes 008, 009) — metaphors of writing/cooking/space *encode* these secondary themes; and Critical Thinking (node 013) where thematic synthesis is required for board-level long answers.

## PREREQUISITE_NODE_IDS
c11_hin_v_cbse_03_001, c11_hin_v_cbse_03_002, c11_hin_v_cbse_03_004, c11_hin_v_cbse_03_005, c11_hin_v_cbse_03_006
## PREREQUISITE_REASONS
c11_hin_v_cbse_03_001: Context of domestic work in 1960s-70s India is essential to read themes historically, not just personally.
c11_hin_v_cbse_03_002: Plot structure (episodic, non-linear) determines *where* and *how* secondary themes surface (e.g., literacy theme appears only after Krishnakant entry).
c11_hin_v_cbse_03_004: Protagonist's evolving consciousness (from silence to speech) is the vehicle for all secondary themes.
c11_hin_v_cbse_03_005: Supporting characters (Krishnakant, Tasveer, employers) embody thematic counterpoints — each represents a different relationship to power.
c11_hin_v_cbse_03_006: Primary theme (dignity/self-assertion) is the anchor; secondary themes only make sense in relation to it.

## FORWARD_NODE_IDS
c11_hin_v_cbse_03_008, c11_hin_v_cbse_03_009, c11_hin_v_cbse_03_013, c12_hin_a_cbse_01_007, c12_hin_a_cbse_08_007, c12_hin_a_cbse_10_007, c12_hin_v_cbse_03_007, c11_hin_v_cbse_03_015

## FORWARD_REASONS
c11_hin_v_cbse_03_008: Imagery of *pen*, *kitchen*, *room*, *train* materialize secondary themes (literacy, labor, mobility) — devices *are* thematic vehicles.
c11_hin_v_cbse_03_009: Irony (e.g., employer teaching her to write while denying her dignity) and symbolism (the *fp_h* as both weapon and witness) deepen thematic analysis.
c11_hin_v_cbse_03_013: Critical thinking requires synthesizing primary + secondary themes into a coherent interpretive argument for board exams.
c12_hin_a_cbse_01_007: Vitan Chapter 3 added socio-political dimension to themes.  
c12_hin_a_cbse_08_007: अगला तार्किक चरण: Secondary themes are the underlying, complementary ideas in a literary work that support, contrast w... इस नोड की अवधारणाओं को सीधे उपयोग/विस्तारित करता है।  
c12_hin_a_cbse_10_007: Practice with thematic tracing in essay/memoir hybrids.  
c12_hin_v_cbse_03_007: Class 11 foundation on secondary themes in the same chapter — student already knows the basic concept.  
c11_hin_v_cbse_03_015: character sketches in isolation—those are addressed in sibling nodes c11_hin_v_cbse_03_002 through c11_hin_v_cbse_03_007.  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
(No prior class nodes available for Hindi Vitan)

## CHAIN_DESCRIPTION
c11_hin_v_cbse_03_006 -> c11_hin_v_cbse_03_007 -> c11_hin_v_cbse_03_008

## THIS_FORMULA
N/A - conceptual

## FORMULA_VARIABLES
N/A

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
analytical

## CROSS_SUBJECT
c11_history_social_change | The chapter reflects shifting gender/caste/class structures in post-independence urban India; secondary themes like "literacy as mobility" connect to History's focus on social reform movements and women's education policies.
c11_sociology_gender_class | The intersection of domestic labor, affective work, and maternal substitution maps directly to Sociology concepts of "gendered division of labor," "reproductive labor," and "stratification within informal work."
c11_economics_informal_sector | The protagonist's wage negotiations, lack of contracts, and spatial precarity illustrate Economics themes of "informal employment vulnerability" and "non-monetary compensation (food/shelter vs cash)."

## PREREQ_CONCEPT
Ability to distinguish *topic* (e.g., "education") from *theme* (e.g., "education as a contested site of empowerment and surveillance") and to trace a theme across non-linear narrative episodes.

## PREREQ_BEFORE
Student must have completed the Primary Theme node (006) and Character Analysis nodes (004, 005) — they provide the "who" and "what" for the "how" and "why" of secondary themes.

## PREREQ_STUCK
If stuck, return to the Primary Theme node (006) and re-do the "Theme vs Topic" exercise: list 5 topics from the text, then convert each into a thematic statement with evidence.

## WORKED_EXAMPLE_1
**PROBLEM:** Analyze the secondary theme "Food as Language of Power and Care" in the text. Provide three textual instances and explain how this theme complicates the primary theme of dignity.

**STEPS:**
- **Step 1: Identify the theme statement.** Not just "food" but "Food mediates power (who eats what, who serves) and care (who cooks for whom, who remembers preferences)."
- **Step 2: Locate Instance 1 — Power.** First employer's household: Protagonist cooks elaborate meals (*fposQu&foosQu] fcj;kuh] iqyko] dckc] vkyw&ijkBk] iqnhuk&ijkBk*) but eats separately; the *lqvj ihNs* (water barrier) enforces caste hierarchy through food rules.
- **Step 3: Locate Instance 2 — Care/Resistance.** Krishnakant's house: She cooks *xje&xje [kkuk* (two separate meals) for herself and him, but he eventually eats her food ("rkrq'k us ns[kdj dgk] ;g rks rqEgkjk gS!"). Her cooking becomes a bridge, not a barrier.
- **Step 4: Locate Instance 3 — Maternal Substitution.** Tasveer's house: She feeds *lq[knhi* and *je.k* with *fposQu* ph”ksa, performing motherhood through food ("eSa mldk [kkuk mlls iwNdj gh cukrh"). The children's desire for her cooking (*vtZqu nk osQ mBus ij mlosQ fy, oqQN [kkuk&okuk Hkh rks cukuk gksrk*) shows food as emotional currency.
- **Step 5: Synthesize complication.** Food begins as a tool of *subordination* (caste segregation), becomes a site of *negotiated intimacy* (Krishnakant), and finally a mode of *agential mothering* (Tasveer's kids). This trajectory mirrors the primary theme: dignity is not won by rejecting service, but by *redefining* the terms of service — "I cook, therefore I am."

**REASONING:** This worked example models the board-exam requirement: (a) precise thematic statement, (b) chronological textual evidence showing development, (c) analytical connection to primary theme. It avoids listing "food scenes" and instead reads food as a *sign system*.

**ANSWER:** The secondary theme "Food as Language of Power and Care" traces a three-stage arc: (1) Caste-enforced separation (first household, separate utensils/water); (2) Negotiated reciprocity (Krishnakant accepting her food, breaking *lqvj*); (3) Chosen maternal labor (cooking *fposQu* for Tasveer's children). This complicates the primary theme by showing dignity is not escape from domestic work but *reclamation* of its affective and cultural value — the protagonist's hands that once served *lqvj*-bound meals later cook *fposQu* as an act of love, not servitude.

## WORKED_EXAMPLE_2
**PROBLEM:** The text presents two contrasting father-figures: the biological father (*ckck*) and the mentor Krishnakant (*rkrq'k*). Analyze how the secondary theme "Chosen vs. Given Kinship" operates through this contrast.

**STEPS:**
- **Step 1: Define the thematic contrast.** "Given kinship" (birth father: absent, alcoholic, dies unknown) vs. "Chosen kinship" (Krishnakant: teaches, publishes, offers home, but also controls).
- **Step 2: Evidence for Given Kinship failure.** *ckck* never informs her of mother's death ("eq>s fdlh us ugha crk;k"), visits only to ask for money ("ckck us iwNk] rsjk cM+k yM+dk dgk¡ jgrk gS"), and dies without reconciliation ("esjs nknk] cÅnh] HkkbZ dksbZ cgqr nwj rks jgrs ugha Fks").
- **Step 3: Evidence for Chosen Kinship complexity.** *rkrq'k* gives literacy ("eSa rqEgsa ,d ph"k ns jgk gw¡"), publishes her (*fp_h* in magazine), but also claims ownership ("rkrq'k us dgk] csch] rqEgkjs caèkq rqEgkjk fdruk mRlkg c<+k jgs gSa").
- **Step 4: Evidence for Third Term — Self-Kinship.** The protagonist ultimately *mothers herself* — buys her room ("?kj fey Hkh x;k"), raises her children alone ("esjs rhuksa cPps Fks"), and writes her *fp_h* ("eSa viuk dke fd, tkvksA").
- **Step 5: Analyze thematic function.** The contrast doesn't just favor chosen over given; it shows *both* patriarchal figures (bio father, mentor) fail her fully. Her dignity comes from *refusing* the binary — she becomes her own kin. The theme "Chosen vs. Given Kinship" thus *deconstructs* kinship itself.

**REASONING:** This example demonstrates senior-secondary skill: moving beyond binary comparison (A vs B) to dialectical synthesis (A and B both insufficient → C). It uses specific dialogues (father asking for money, Krishnakant claiming royalties) and links to the primary theme of *self-assertion*.

**ANSWER:** The theme "Chosen vs. Given Kinship" is not a simple replacement narrative. The biological father (*ckck*) embodies toxic patriarchy — absent, extractive, unmourned. Krishnakant (*rkrq'k*) embodies benevolent patriarchy — empowering but proprietary (claiming her writing's royalties, directing her life). The protagonist's dignity emerges in *rejecting both as ultimate authorities*: she refuses *ckck*'s money-demand, negotiates *rkrq'k*'s control ("eSa viuk dke fd, tkvksA"), and establishes autonomous kinship — her room, her children, her *fp_h*. The theme thus critiques *all* patriarchal kinship, aligning with the primary theme of self-assertion.

## WORKED_EXAMPLE_3
**PROBLEM:** Synthesize three secondary themes — "Literacy as Liberation," "Domestic Space as Political Space," and "Female Solidarity across Class" — into a single analytical argument about the novel's feminist methodology. Use at least four textual references.

**STEPS:**
- **Step 1: Thesis Statement.** The novel's feminist methodology is *materialist* — it grounds abstract liberation (literacy) in concrete spaces (kitchen, room, train) and relational networks (women employers, daughters, sisters).
- **Step 2: Literacy as Liberation — Materialist Reading.** Not "education = freedom" abstractly. Evidence: She learns to write *in the kitchen* ("rkrq'k us eq>ls cSB tkus dks dgk vkSj fiQj fp_h i<+dj lqukus yxs"), uses *fp_h* to claim wages ("MkWDVj esjh tk¡p dj nok fy[k nsrk"), and writes *on the job* ("fy[kus cSBus ls gh fy[kk tk ldrk gS"). Literacy is *embedded* in labor.
- **Step 3: Domestic Space as Political Space — Three Rooms.** (a) First house: *V^h* (toilet) as caste border ("lqvj ihNs ls vkdj rax djuk 'kq: dj nsrsA"). (b) Krishnakant's house: *dkWih* (study) as contested zone ("rkrq'k us viuh fy[kus dh Vsfcy osQ Mªkj ls ,d isu vkSj dkWih fudkyh"). (c) Own room: *?kj* as sovereignty ("eSa lksprh fd mlls vPNh txg dgk¡ fey ldrh gSA"). Space is not backdrop; it's the *arena* of struggle.
- **Step 4: Female Solidarity across Class — Fractured but Real.** (a) *tsBw* (employer's wife) shares *fp_h* writing ("tsBw dh ftruh fpf_;k¡ vkrha mruh esjh bPNk gksrh fd fy[k¡w"). (b) *vtqZu nk* (employer) respects her motherhood ("ns[kks] vHkh os NksVs gSa] vHkh mudk 'kSrkuh djus dk le; gSA"). (c) *lquhfr* (orphan girl) mirrors protagonist's past ("mlosQ ek osQ u jgus ls fdruk d"V gksrk gS og eSa tkurh gw¡"). Solidarity is *not* sisterhood-by-default; it's forged through *shared vulnerability to patriarchy*.
- **Step 5: Synthesis — Feminist Methodology.** The novel refuses: (i) Romanticizing literacy (it brings surveillance too), (ii) Romanticizing home (it's a site of caste/gender violence), (iii) Romanticizing sisterhood (class divides persist). Its feminism is *intersectional* — dignity is won *at the intersection* of pen, stove, and train compartment.
- **Step 6: Board-Exam Answer Structure.** Write as: "Sobti's feminist methodology in 'vkyks&vk¡èkkfj' is materialist-intersectional. She demonstrates that literacy (evidence: diary in kitchen), space (evidence: three rooms), and solidarity (evidence: Tasveer/Vidya/Lakshmibai) are co-constitutive. The protagonist's dignity emerges not from any single factor but from her *strategic navigation* of all three. This aligns with the primary theme of self-assertion as *praxis*, not essence."

**REASONING:** This example models the highest-order board skill: *thematic synthesis*. It requires holding three themes simultaneously, showing their interdependence, and naming the *methodology* (materialist-intersectional feminism) — exactly what "Critical Thinking" (node 013) and 6-mark questions demand.

**ANSWER:** The novel's feminist methodology is materialist-intersectional. Literacy is not a magic key but a tool forged *in* the kitchen (diary written between meals) and used *for* material gains (royalty notebook for wages). Domestic space is not passive setting but political terrain: the segregated *V^h* (caste), the contested *dkWih* (intellectual ownership), the owned *?kj* (autonomy). Female solidarity is not universal sisterhood but tactical alliance across class: Tasveer shares writing anxiety, Vidya respects maternal labor, Lakshmibai mirrors orphanhood. The protagonist's dignity — the primary theme — is the *praxis* of navigating these three interlocking fields. This synthesis meets the board's "analyze and evaluate" rubric: multiple themes, textual density, conceptual vocabulary, primary-theme linkage.

## COMPETENCY_QUESTION_1
**QUESTION:** "The secondary theme of 'mobility' (trains, buses, walking) in 'vkyks&vk¡èkkfj' functions as a metaphor for the protagonist's social mobility — but only partially. Analyze this claim with reference to three specific journeys in the text, explaining where the metaphor holds and where it breaks down."

**COMPETENCY:** Analytical reasoning with metaphorical interpretation and textual evidence.

**STEPS:**
- **Step 1:** Identify three journeys: (a) First train to city (escape), (b) Daily commute to Krishnakant's house (negotiated), (c) Final move to own room (arrival).
- **Step 2:** For each, map physical movement to social movement: (a) Village → City = entry into wage labor, but also caste anonymity; (b) Daily travel = literacy acquisition, but also surveillance (*rkrq'k* tracking her); (c) Own room = autonomy, but precarious (eviction threat).
- **Step 3:** Identify where metaphor holds: Physical distance from village = psychological distance from feudal patriarchy.
- **Step 4:** Identify where it breaks: Mobility is *circular* (she returns to village for mother's death, children's school); the train compartment replicates caste/gender hierarchies (*vkil esa u tkus D;k ckrsa djrs*).
- **Step 5:** Conclude: Mobility is *necessary but insufficient* for dignity — the novel's materialist feminism.

**ANSWER:** The mobility metaphor holds for Journey 1 (train to city = entry into modernity/wage labor) and Journey 3 (moving into own room = spatial sovereignty). It breaks for Journey 2 (daily commute): the train/bus is where she faces harassment (*vkil esa u tkus D;k ckrsa djrs*), where Krishnakant monitors her (*rkrq'k us dgk] tc Hkh dHkh eSa ckgj ?kweus fudyw¡ rks vutku yksxksa ls ”;knk ckrsa u d:¡*), and where she carries the village in her body (*cpiu esa esjh nhnh eq>s idM+ dj tcjnLrh*). The novel thus refuses a linear "mobility = progress" narrative; social mobility is fragmented, contested, and embodied — aligning with the primary theme that dignity is *daily practice*, not destination.

**DIFFICULTY:** medium

## COMPETENCY_QUESTION_2
**QUESTION:** "Evaluate the narrative strategy of using *fp_h* (autobiography-within-autobiography) as a structural device to explore the secondary theme 'Writing as Witnessing.' How does this meta-narrative technique complicate the reader's understanding of the protagonist's reliability, agency, and the ethics of representation? Support with four textual details."

**COMPETENCY:** Critical evaluation of narrative form and thematic function (meta-fiction analysis).

**STEPS:**
- **Step 1:** Define the device: The protagonist writes *fp_h* (her life story) which *is* the text we are reading (*vkyks&vk¡èkkfj* = *vkyks&vk¡èkkfj* 1). Krishnakant edits/publishes it ("rkrq'k us eq>ls I+kQksVks&dkWih djk osQ vius ,d caèkq osQ ikl dksydkrk Hkst fn;k").
- **Step 2:** Reliability complication: She admits gaps ("eSa lksprh fd lpeqp brus fnuksa ckn eq>s ,d lgsyh feyhA eSaus mUgsa rc rd ns[kk ugha Fkk"), memory lapses ("i<+rs gq, ,d ckj Hkh rqEgsa Mk¡Vus dh bPNk ugha gksrh"), and Krishnakant's editorial control ("rkrq'k us mUgsa I+kQksu ij lqukrs"). The "I" is *constructed*, not transparent.
- **Step 3:** Agency complication: Writing *is* agency ("eSa viuk dke fd, tkvksA cl] fy[kks vkSj i<+ksA"), but the *conditions* of writing (Krishnakant's notebook, Tasveer's encouragement, publisher's demand) mean agency is *distributed*. She cannot write without the "ph"k" (notebook) given by patriarch.
- **Step 4:** Ethics of representation: She writes *others* (employers, children, mother) into her story — "tsBw dh fpf_;k¡ i<+dj ckj&ckj bPNk gksrh fd muosQ lkFk ckrsa d:¡] g¡lw¡] [ksyw¡]." Do they consent? The text raises but doesn't resolve this. The *fp_h* becomes a *site* of ethical negotiation.
- **Step 5:** Synthesis: The meta-narrative forces the reader to ask: *Who owns this story?* The answer — "vkyks&vk¡èkkfj1" (Krishna Sobti's signature at end) — reclaims authorship *from* Krishnakant *to* the author, modeling the protagonist's journey. The device *enacts* the theme.

**ANSWER:** The *fp_h* device transforms "Writing as Witnessing" from theme to *method*. It complicates reliability by exposing memory as fragmented ("Mk¡Vus dh bPNk ugha") and authorship as mediated (Krishnakant's editorial hand). It complicates agency by showing writing requires patriarchal resources (notebook, publisher, mentor) even as it resists patriarchy. It raises ethics: the protagonist witnesses others (Tasveer's madness, Vidya's orphanhood, mother's silence) without their voice. Crucially, the novel's final signature — "vkyks&vk¡èkkfj1" — performs the ultimate witnessing: the real author (Sobti) witnesses the fictional protagonist witnessing herself. This meta-layer elevates the secondary theme into a *poetics of testimony*, demanding the reader recognize that every "I" in marginalized writing is a collective, contested, and hard-won construction.

**DIFFICULTY:** hard