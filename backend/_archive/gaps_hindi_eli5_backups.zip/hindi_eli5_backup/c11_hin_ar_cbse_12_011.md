## DEFINITION
Language usage in a literary text refers to the author's deliberate choices in vocabulary, syntax, dialect, and grammatical structures to create specific effects, convey themes, and reflect character or setting.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student can identify and explain at least three distinct language features (e.g., dialect words, syntactic patterns, lexical choices) in the poem and articulate how each contributes to the poem's meaning, tone, or characterization.

## SCOPE_BOUNDARY
This node covers analysis of vocabulary (including dialect words), sentence structures, and grammatical deviations in the poem "Paik Dkys Dkys vPNj ugha phUgrh". It does not cover literary devices like metaphor or irony (covered in nodes 008, 009) or comprehension questions (node 012).

## WALKTHROUGH
Have you ever noticed how your grandmother's Hindi differs from your textbook Hindi? That difference is "language usage" — a writer's toolkit for building character. Begin by reading the poem aloud, listening for words that sound "non-standard" (like *phUgrh*, *dkys dkys*, *vPNj*). Circle them. Next, group these findings: which are vocabulary choices? Which are verb endings? Which are sentence patterns? Finally, ask: "Why did Renu choose *this* word over the standard one?" The answer reveals how language itself becomes a character in the poem, embodying the clash between oral folk culture and formal education.

## DIAGNOSTIC_QUESTION_1
What is meant by 'language usage' in the context of a literary text?

## DIAGNOSTIC_ANSWER_1
Language usage refers to the writer's deliberate choices in words, sentence structures, and grammatical forms to achieve artistic effects. A wrong answer (e.g., "it means the language of the text") shows the student confuses the analytical concept with mere identification of the language used.

## DIAGNOSTIC_QUESTION_2
In the poem, the word 'phUgrh' is used. Explain why the poet might have chosen this non-standard form instead of standard Hindi 'padhna' or 'parhna'.

## DIAGNOSTIC_ANSWER_2
The poet uses 'phUgrh' (Bhojpuri dialect) to authentically represent the village woman's speech, establishing her character, social background, and the poem's rural setting. A wrong answer (e.g., "it's a mistake" or "the poet didn't know standard Hindi") reveals the student doesn't understand dialect as a deliberate stylistic choice for characterization.

## DIAGNOSTIC_QUESTION_3
Identify two sentences in the poem where the verb comes at the end (SOV order) but with a non-standard auxiliary or verb ending, and rewrite them in standard Hindi.

## DIAGNOSTIC_ANSWER_3
Example 1: "paik dkys dkys vPNj ugha phUgrh" → Standard: "पाइक धीरे-धीरे नहीं पढ़ती।" (Non-standard: *phUgrh* for *padhti*). Example 2: "rqe dkxn gh xksnk djrs gks fnu Hkj" → Standard: "तुम दिन भर दिन ही काटते हो।" (Non-standard: *dkxn* for *din*, *xksnk* for *kate*, *gh* emphatic particle, *fnu Hkj* for *din bhar*). Steps: locate non-standard verb forms, identify dialect features, convert to standard Hindi. Wrong answer indicates inability to distinguish dialect grammar from standard grammar.

## DIAGNOSTIC_QUESTION_4
Compare the language of the pawn (paik) and the poet-narrator. How do their grammatical differences reflect their social positions?

## DIAGNOSTIC_ANSWER_4
The pawn uses rural dialect (Bhojpuri), simple sentences, non-standard verb endings (*phUgrh*, *djrs gks*), and colloquial vocabulary (*dkxn*, *fnu Hkj*). The narrator uses standard Hindi, complex sentences, tatsam vocabulary (*cksypky*, *pqVhyk*, *ukVdh;*), and literary register. This contrast highlights the education gap, social hierarchy, and the central conflict between oral folk culture and formal literacy. Wrong answer shows failure to link grammatical choices to characterization and theme.

## DIAGNOSTIC_QUESTION_5
Do you think the use of dialect words like 'dkys dkys', 'pqipki', 'ckye' enriches the poem or makes it inaccessible? Justify.

## DIAGNOSTIC_ANSWER_5
It enriches the poem by adding authenticity, rhythmic texture, and cultural specificity; the context and provided glosses make it accessible to non-dialect speakers. A one-sided answer (only "enriches" or "inaccessible") without textual justification shows superficial evaluation. Strong answers note that the dialect *is* the poem's music — removing it would flatten the pawn's voice.

## DIAGNOSTIC_QUESTION_6
Write a four-line stanza in your mother tongue/dialect about a daily activity, then translate it into standard Hindi, noting what is lost/gained.

## DIAGNOSTIC_ANSWER_6
Student produces a stanza in their dialect, translates it, and comments on loss of flavor/rhythm/cultural nuance versus gain of wider comprehensibility. Poor answer: only translation without reflection on the linguistic trade-offs, indicating they haven't grasped the functional value of dialect in literature.

## COMMON_MISCONCEPTION
Students think non-standard grammar in literature is "incorrect" or "mistakes" rather than deliberate representation of speech communities. They also confuse dialect (rule-governed regional variety) with slang (informal, often generational). For example, they may label *phUgrh* as "wrong Hindi" instead of recognizing it as a perfectly regular Bhojpuri verb form. This error stems from equating "standard language" with "correct language" and not studying sociolinguistics.

## ON_FAILURE
1. Play an audio recording of a Bhojpuri speaker reading the poem; ask students to transcribe phonetically what they hear. 2. Create a three-column table: Dialect Word | Standard Hindi Equivalent | Grammatical Category (verb, adverb, etc.). Fill 5 rows together. 3. Discuss: "If Renu wrote *padhti* instead of *phUgrh*, what would the poem lose?" 4. Practice converting two dialect lines to standard Hindi, then reading both aloud to hear the rhythmic difference.

## BUILDS_ON
Vocabulary in Context (node 010) where key dialect words were introduced and glossed.

## LEADS_TO
Comprehension: Literal and Inferential Questions (node 012) where language understanding aids interpretation; Critical Thinking: Analysis and Interpretation (node 013) where linguistic evidence supports thematic claims.

## PREREQUISITE_NODE_IDS
c11_hin_ar_cbse_12_010, c11_hin_ar_cbse_12_001

## PREREQUISITE_REASONS
c11_hin_ar_cbse_12_010: Vocabulary in Context provides the meanings of dialect words essential for analyzing language usage.
c11_hin_ar_cbse_12_001: Grammar node analyses the non-standard constructions context explains.  

## FORWARD_NODE_IDS
c11_hin_ar_cbse_12_012, c11_hin_ar_cbse_12_013, c12_hin_a_cbse_04_011, c12_hin_a_cbse_09_011, c12_hin_a_cbse_11_011, c12_hin_a_cbse_12_011, c12_hin_a_cbse_17_011, c12_hin_ar_cbse_01_011, c12_hin_ar_cbse_02_011, c12_hin_ar_cbse_07_011, c12_hin_ar_cbse_09_011, c12_hin_ar_cbse_10_011, c12_hin_ar_cbse_11_011

## FORWARD_REASONS
c11_hin_ar_cbse_12_012: Comprehension questions require understanding of language nuances to answer inferential questions. c11_hin_ar_cbse_12_013: Critical thinking builds on language analysis to interpret deeper socio-cultural meanings.
c12_hin_a_cbse_04_011: अगला तार्किक चरण: This node analyzes the grammatical structures, syntactic patterns, and language usage specific to th... इस नोड की अवधारणाओं को सीधे उपयोग/विस्तारित करता है।  
c12_hin_a_cbse_09_011: *Vakya bhed* (sentence types) — imperative mood analysis (Diagnostic 4) builds on this.  
c12_hin_a_cbse_11_011: Teaches grammatical evidence for inference — bridges to c12_hin_a_cbse_11_012.  
c12_hin_a_cbse_12_011: Analysis of dialogue punctuation and reporting verbs  
c12_hin_a_cbse_17_011: Connected grammar to theme in Class 11 texts — transferable to this chapter.  
c12_hin_ar_cbse_01_011: Links grammar to interpretive claims — precursor to competency questions.  
c12_hin_ar_cbse_02_011: Synthesis of grammar and meaning.  
c12_hin_ar_cbse_07_011: Register difference between poetry and prose commentary.  
c12_hin_ar_cbse_09_011: Reinforces sound-pattern analysis (rhythm, alliteration).  
c12_hin_ar_cbse_10_011: Syntactic patterning for characterization (Chapter 12).  
c12_hin_ar_cbse_11_011: Connects grammar to thematic inference  
c11_hin_ar_cbse_12_013: अगला तार्किक चरण: Critical thinking in literary analysis is the disciplined process of actively examining a text's exp... इस नोड की अवधारणाओं को सीधे उपयोग/विस्तारित करता है।  

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_12_010 -> c11_hin_ar_cbse_12_011 -> c11_hin_ar_cbse_12_012

## THIS_FORMULA
N/A - conceptual

## FORMULA_VARIABLES
N/A

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
linguistic

## CROSS_SUBJECT
c11_sociology_culture | Dialect in literature reflects sociolinguistic reality and identity, a core concept in sociology of language.
c11_geography_human | Regional language variations map to geographical boundaries, illustrating linguistic geography and cultural diffusion.

## PREREQ_CONCEPT
Understanding of standard Hindi grammar and awareness of dialectal variations.

## PREREQ_BEFORE
Student must know basic Hindi parts of speech and sentence structure (subject-object-verb order).

## PREREQ_STUCK
Review Class 10 Hindi grammar: verb conjugations, case endings, and common dialect differences (e.g., Bhojpuri vs standard Hindi).

## WORKED_EXAMPLE_1
PROBLEM: Analyze the language usage in the first stanza of the poem: "paik dkys dkys vPNj ugha phUgrh / budh Hkk"kk Nk;koknh :ekfu;r ls eqDr gS..." Identify three features of non-standard grammar/dialect and explain their effect.
STEPS:
- Step 1: Read the stanza aloud, noting words that differ from standard Hindi (e.g., 'dkys dkys', 'vPNj', 'phUgrh', 'Nk;koknh', ':ekfu;r').
- Step 2: Categorize each: 'dkys dkys' (reduplication for manner), 'vPNj' (dialect for 'nahin'), 'phUgrh' (dialect verb form for 'padhti'), 'Nk;koknh' (tatsam but used in specific sense), ':ekfu;r' (Persian loanword).
- Step 3: Identify grammatical patterns: verb-final order, use of dialect verb endings (-rh), postposition usage.
- Step 4: Explain effect: creates authentic voice of the pawn, establishes rural setting, contrasts with narrator's standard Hindi.
- Step 5: Connect to theme: language as a marker of education and social divide.
REASONING: This step-by-step moves from identification to categorization to functional analysis, modeling the analytical process required for board exams.
ANSWER: The stanza uses Bhojpuri dialect features: reduplicated adverb 'dkys dkys' (slowly), negative particle 'vPNj' (not), and verb 'phUgrh' (reads). These create the pawn's authentic voice, highlighting her illiteracy and the poem's theme of education disparity.

## WORKED_EXAMPLE_2
PROBLEM: The pawn says: "rqe dkxn gh xksnk djrs gks fnu Hkj". Convert this to standard Hindi and analyze the grammatical differences.
STEPS:
- Step 1: Identify non-standard forms: 'dkxn' (for 'din'), 'gh' (emphatic particle), 'xksnk' (for 'kate'), 'djrs gks' (for 'karte ho'), 'fnu Hkj' (for 'din bhar').
- Step 2: Map each to standard Hindi: 'दिन', 'ही', 'कटते', 'करते हो', 'दिन भर'.
- Step 3: Rewrite full sentence: "तुम दिन ही काटते हो दिन भर।" (Better: "तुम दिन भर दिन ही काटते हो।")
- Step 4: Analyze differences: phonological (dkxn/din), morphological (xksnk/kate), syntactic (gh placement), lexical (fnu Hkj/din bhar).
- Step 5: Discuss effect: the dialect version has rhythmic, oral quality; standard version loses the folk flavor.
REASONING: Conversion exercise reinforces grammatical analysis and highlights the aesthetic function of dialect.
ANSWER: Standard Hindi: "तुम दिन भर दिन ही काटते हो।" Differences: dialect phonology (dkxn), morphology (xksnk for कटते), syntax (घ as emphatic), vocabulary (फनु ह्ज for दिन भर). The dialect version captures the pawn's speech rhythm and cultural context.

## WORKED_EXAMPLE_3
PROBLEM: Compare the language of the pawn's direct speech (e.g., "paik dgrh gS% rqe dkxn gh xksnk djrs gks...") with the narrator's description (e.g., "f=kykspu dk dfo cksypky dh Hkk"kk dks pqVhyk vkSj ukVdh; cukdj dforkvksa dks u;k vk;ke nsrk gSA"). How do syntax, vocabulary, and register differ? What does this contrast achieve?
STEPS:
- Step 1: Extract pawn's speech lines and narrator's descriptive lines.
- Step 2: Analyze pawn's speech: simple sentences, dialect vocabulary (dkxn, gh, xksnk, fnu Hkj), colloquial verb forms (djrs gks), direct address, imperatives.
- Step 3: Analyze narrator's language: complex sentences, tatsam vocabulary (cksypky, pqVhyk, ukVdh;, u;k vk;ke), passive constructions, third-person perspective, literary register.
- Step 4: Contrast: pawn = oral, dialectal, concrete, emotional; narrator = written, standard, abstract, analytical.
- Step 5: Synthesize: The contrast dramatizes the clash between oral folk culture and literate literary culture, central to the poem's theme.
- Step 6: Relate to board exam answer structure: Point (contrast), Evidence (examples), Explanation (function), Link (theme).
REASONING: This multi-step comparison builds the higher-order skill of synthesizing linguistic analysis with thematic interpretation, exactly what board competency questions demand.
ANSWER: The pawn's speech uses Bhojpuri dialect (dkxn, fnu Hkj), simple SOV sentences, and colloquial verb forms, reflecting her oral, uneducated identity. The narrator employs Sanskritized Hindi (cksypky, pqVhyk), complex syntax, and literary register, reflecting his educated, authorial voice. This linguistic gap embodies the poem's central conflict: the marginalization of folk voices in formal education systems.

## COMPETENCY_QUESTION_1
QUESTION: In the poem, the pawn refuses to read saying "eSa rks ugha i<+¡wxh" and later "eSa rks C;kg dHkh u d:¡xh". Analyze how the poet uses verb tense and aspect in these two lines to reveal the pawn's changing attitude toward literacy.
COMPETENCY: Analyzing grammatical choices to interpret character development
STEPS:
- Step 1: Identify the verbs: 'i<+¡wxh' (future tense, first person singular feminine) and 'd:¡xh' (past tense, first person singular feminine).
- Step 2: Analyze first line: future tense 'i<+¡wxh' (will not read) shows present refusal, active resistance.
- Step 3: Analyze second line: past tense 'd:¡xh' (never saw) reveals lifelong deprivation, structural reason for refusal.
- Step 4: Connect: shift from future refusal to past explanation deepens character from stubborn to victim of circumstance.
- Step 5: Write answer with evidence and interpretation.
ANSWER: The first line uses future tense ('i<+¡wxh' - will not read) showing active resistance. The second uses past tense ('d:¡xh' - never saw) revealing the structural cause: she never had access to schooling. The tense shift transforms her from a defiant character to a symbol of systemic exclusion.
DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: The poem uses the reduplicated form 'dkys dkys' (slowly slowly) and 'tSls&rSls' (like this, like that). Explain the grammatical function of reduplication in these two cases and evaluate how each contributes to the poem's rhythmic and thematic texture.
COMPETENCY: Analyzing morphological patterns (reduplication) for literary effect
STEPS:
- Step 1: Define reduplication in Hindi: repetition of a word for emphasis, distribution, or manner.
- Step 2: Analyze 'dkys dkys': adverbial reduplication indicating slow, gradual manner (process).
- Step 3: Analyze 'tSls&rSls': pronominal reduplication with conjunction, meaning 'in various ways' or 'here and there', showing diversity/irregularity.
- Step 4: Compare rhythmic effect: 'dkys dkys' creates a slow, plodding rhythm matching the pawn's reading; 'tSls&rSls' creates a lilting, repetitive rhythm matching the poem's refrain-like quality.
- Step 5: Thematic link: 'dkys dkys' reflects the slow, hard path to literacy; 'tSls&rSls' reflects the varied, organic connection of poetry to life.
- Step 6: Conclude with evaluation: both use reduplication but for different semantic and rhythmic purposes, enriching the poem's oral musicality.
ANSWER: 'dkys dkys' (adverbial reduplication) denotes gradual manner, mimicking the pawn's laborious reading pace. 'tSls&rSls' (pronominal reduplication) means 'in various ways', reflecting poetry's multifaceted presence in life. The former creates a slow, heavy rhythm; the latter a flowing, repetitive rhythm. Together they establish the poem's folk-song cadence while deepening its thematic contrast between struggle and organic belonging.
DIFFICULTY: hard