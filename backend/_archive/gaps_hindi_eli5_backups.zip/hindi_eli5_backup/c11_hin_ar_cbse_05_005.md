## DEFINITION
Character analysis of supporting characters examines how secondary figures in a narrative reveal the protagonist's traits, advance thematic concerns, and embody social forces through their actions, speech, relationships, and narrative function. In senior secondary Hindi literature, this requires tracing each supporting character's arc across the text, identifying their symbolic role in the caste/class hierarchy, and explaining how their interactions with the protagonist expose systemic oppression.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student can independently select textual evidence for at least three supporting characters, explain each character's symbolic function in the caste-oppression theme, and write a structured board-level answer comparing how two supporting characters represent different facets of the same social system.

## SCOPE_BOUNDARY
This node covers analysis of èkujke (father), ekLVj f=kyksd flag (teacher), g¡lqos (mother), oa'khèkj (progressive teacher), and xaxkjke (peer) from "xyrk yksgk." It does NOT cover the protagonist eksgu (covered in c11_hin_ar_cbse_05_004) or thematic analysis (covered in c11_hin_ar_cbse_05_006/007).

## WALKTHROUGH
Imagine you're watching a play where the main actor (eksgu) stands center stage, but the lighting, background music, and other actors make his struggle visible. Supporting characters in "xyrk yksgk" are that lighting and music — they don't just "help" the story; they *are* the caste system in human form. Start by asking: "Which character makes me angriest when they mistreat eksgu?" That emotional reaction is your entry point. Then trace that character's every appearance — what they say, what they do, what others say about them. Notice how èkujke and ekLVj f=kyksd flag both wield authority but differently: one through family tradition, one through institutional power. The key insight: supporting characters in this story are not individuals with full inner lives; they are *positions* in a caste hierarchy. Your analysis must show how each position reinforces the others.

## DIAGNOSTIC_QUESTION_1
Identify the four major supporting characters in "xyrk yksgk" and state one defining action for each that reveals their role in the caste hierarchy.

## DIAGNOSTIC_ANSWER_1
The four major supporting characters are: (1) èkujke — eksgu's father, who denies him food and treats him as a servant (e.g., making him serve guests while hungry); (2) ekLVj f=kyksd flag — the teacher who humiliates eksgu by making him clean the school and denying him water; (3) g¡lqos — eksgu's mother, who silently endures and works tirelessly but cannot protect her son; (4) oa'khèkj — the progressive teacher who arranges eksgu's marriage and treats him with dignity. A wrong answer that lists only names without defining actions reveals the student cannot distinguish character *function* from character *presence*. A wrong answer that misses oa'khèkj reveals the student overlooks the counter-narrative of resistance.

## DIAGNOSTIC_QUESTION_2
Explain in your own words why èkujke refuses to acknowledge eksgu as his son despite biological ties, using the concept of "internalized caste consciousness."

## DIAGNOSTIC_ANSWER_2
èkujke has internalized the caste ideology that defines his identity: he sees himself not as a father but as a "tkfrxr ghurk" (caste-proud person) for whom maintaining caste purity matters more than kinship. He treats eksgu as "eksgu dk vfèkdkj" (eksgu's owner/master) because the caste system teaches him that a lower-caste person — even his own son — is property, not family. His refusal to teach eksgu the Gayatri Mantra or let him study stems from the belief that knowledge is the exclusive right of upper castes. A wrong answer that calls èkujke "cruel" or "heartless" without naming caste ideology reveals the student views this as individual moral failure rather than systemic conditioning. A wrong answer that blames poverty reveals the student misses the text's explicit focus on caste (tkfrxr ghurk) as the driver.

## DIAGNOSTIC_QUESTION_3
Apply the "foil character" concept: How does oa'khèkj's treatment of eksgu contrast with ekLVj f=kyksd flag's treatment, and what does this contrast reveal about the possibility of change within the system?

## DIAGNOSTIC_ANSWER_3
Step 1: Identify ekLVj f=kyksd flag's actions — he forces eksgu to clean the school, denies him water, humiliates him publicly, and predicts he will become a great sweeper (LowQy). Step 2: Identify oa'khèkj's actions — he arranges eksgu's marriage, invites him home, feeds him, treats him as an equal, and helps him get education. Step 3: The contrast — both are teachers (same institutional role), but one weaponizes the institution for caste oppression, the other uses it for human dignity. Step 4: What this reveals — the system (school) is not inherently oppressive; *who occupies the role* determines its function. Change is possible but requires conscious rejection of caste conditioning (oa'khèkj had to overcome his own upbringing). A wrong answer that only lists differences without the "same role, different choice" analysis misses the structural insight. A wrong answer that calls oa'khèkj "good" and ekLVj "bad" reduces structural analysis to moral labeling.

## DIAGNOSTIC_QUESTION_4
Analyze g¡lqos's silence throughout the story. Is her silence submission, resistance, or both? Support with three textual instances.

## DIAGNOSTIC_ANSWER_4
g¡lqos's silence is *both* submission and resistance — a "double-voiced" survival strategy. Instance 1 (Submission): She works "èkhjs&èkhjs" (endlessly) for upper-caste households, accepting dehumanizing labor without protest, because open resistance would destroy her family's survival. Instance 2 (Resistance): When ekLVj f=kyksd flag humiliates eksgu, she does not defend the teacher; her silence withholds legitimacy from his authority. Instance 3 (Resistance): She enables eksgu's fleeting moments of childhood (letting him play, protecting him from èkujke's worst cruelties) — her care is a quiet refusal to let the caste system fully define her son. A wrong answer that calls her "passive" or "weak" imposes a middle-class feminist lens that ignores the material constraints of a Dalit woman in a feudal village. A wrong answer that calls her "strong" without acknowledging the cost (her body broken by labor) romanticizes suffering.

## DIAGNOSTIC_QUESTION_5
Evaluate the statement: "xaxkjke is the most important supporting character because he alone treats eksgu as an equal." Defend or critique using textual evidence.

## DIAGNOSTIC_ANSWER_5
Critique: xaxkjke's equality is *conditional* and *individual* — he helps eksgu personally (shares food, defends him) but never challenges the caste system structurally. He remains within the system, even benefiting from it (he is a student, not a sweeper). Contrast with oa'khèkj who uses institutional power to create structural change (arranging marriage, enabling education). xaxkjke's kindness is affectively powerful but politically insufficient — it's charity, not solidarity. A correct evaluation must distinguish *interpersonal kindness* from *structural challenge*. A wrong answer that agrees uncritically reveals the student conflates "nice to protagonist" with "thematically significant." A wrong answer that dismisses xaxkjke entirely misses how the text uses him to show that individual goodness exists but cannot dismantle caste alone.

## DIAGNOSTIC_QUESTION_6
Create a 4-line dialogue between èkujke and oa'khèkj where they argue about eksgu's future, using each character's authentic voice and ideological position from the text.

## DIAGNOSTIC_ANSWER_6
èkujke: "LowQy dk vkSj LowQy gh gksxk] tkfrxr dk niyam kbhu ugha tutrkA" (A sweeper's son becomes a sweeper; caste law never breaks.)
oa'khèkj: "Niyam tukde bnane osQ fy, bnते hैं] èkujke jI — ek nirbhik kadam sb bdL detA hE।" (Rules are made to be broken — one fearless step changes everything.)
èkujke: "tuhM pVh-iliKe logM kI bAten ho] hmari aukad yahi hE।" (That's educated talk — our station is this.)
oa'khèkj: "Aukad bnati hE] paida nhiM hotI — mEne apni bnAi, eksgu bhI bnayeGaa।" (Station is made, not born — I made mine, eksgu will make his.)
A poor answer would have both characters speak in modern vocabulary, miss the ideological core (caste determinism vs. agency), or make èkujke sound sympathetic. The dialogue must show èkujke's *conviction* (not just stubbornness) and oa'khèkj's *earned* authority (he "made" his station).

## COMMON_MISCONCEPTION
Students treat supporting characters as "minor" — less important than the protagonist — and write superficial sketches (appearance, a few traits) instead of analyzing their *structural function*. In "xyrk yksgk," the supporting characters *are* the caste system made visible: èkujke = familial caste enforcement, ekLVj f=kyksd flag = institutional caste enforcement, g¡lqos = gendered caste labor, oa'khèkj = institutional rupture, xaxkjke = individual humanity within the system. The misconception arises because school teaches "character sketch" as a static description (age, clothes, personality) rather than "character analysis" as dynamic textual evidence + thematic function. Students also project modern morality: they judge èkujke as "bad father" instead of analyzing him as "caste-subject father."

## ON_FAILURE
Step 1: Give the student a two-column table. Column A: "Character's Action/Dialogue" (quote 3-4 textual moments). Column B: "What Caste Position This Embodies" (e.g., "Father denying son food = Patriarchal Caste Authority"). Step 2: Model one row together using èkujke. Step 3: Have the student complete the table for ekLVj f=kyksd flag and g¡lqos. Step 4: Ask: "If you removed this character, what would the caste system lose?" This forces structural thinking. Step 5: Only then introduce the term "supporting character" — redefine it as "a character who carries a structural position necessary for the theme to be visible."

## BUILDS_ON
c11_hin_ar_cbse_05_004 (Character Analysis: Protagonist) — students must already understand eksgu's trauma, aspirations, and silence to analyze how supporting characters reflect, amplify, or resist them.

## LEADS_TO
c11_hin_ar_cbse_05_006 (Theme: Primary Theme and Message) — supporting character analysis provides the evidence base for arguing that caste oppression is the primary theme.

## PREREQUISITE_NODE_IDS
c11_hin_ar_cbse_05_001, c11_hin_ar_cbse_05_002, c11_hin_ar_cbse_05_004
## PREREQUISITE_REASONS
c11_hin_ar_cbse_05_001: Provides historical context of Dalit literature and caste oppression essential for reading supporting characters as structural positions.
c11_hin_ar_cbse_05_002: Plot knowledge needed to locate each supporting character's key scenes and narrative function.
c11_hin_ar_cbse_05_004: Protagonist analysis establishes eksgu's arc; supporting characters only make sense in relation to his experience.

## FORWARD_NODE_IDS
c11_hin_ar_cbse_05_006, c11_hin_ar_cbse_05_007, c11_hin_ar_cbse_05_013, c11_hin_ar_cbse_05_008, c11_hin_ar_cbse_05_014, c11_hin_ar_cbse_05_015, c12_hin_a_cbse_05_005, c12_hin_ar_cbse_05_005, c12_hin_ar_cbse_06_005, c11_hin_ar_cbse_05_010

## FORWARD_REASONS
c11_hin_ar_cbse_05_006: Primary theme (caste oppression) is evidenced through supporting characters' collective function.
c11_hin_ar_cbse_05_007: Secondary themes (education as liberation, gendered labor, resistance) are carried by specific supporting characters.
c11_hin_ar_cbse_05_013: Critical thinking requires synthesizing character analysis into interpretive arguments about the text's ideology.
c11_hin_ar_cbse_05_008: Supporting characters' perspectives (Thakur family) are often conveyed through metaphorical language.  
c11_hin_ar_cbse_05_014: Supplies supporting characters' roles for comparative answers.  
c11_hin_ar_cbse_05_015: Supporting characters (Thakur, Ekujke, Gillo) provide counterpoints needed for balanced discussion.  
c12_hin_a_cbse_05_005: Class 11 Antra Chapter 5 introduced the concept of 'functional characters' in poetry (e.g., in 'गंगा' or 'संध्या के बाद'), providing the analytical vocabulary.  
c12_hin_ar_cbse_05_005: Class 11 supporting character node builds the foundational skill of distinguishing protagonist from supporting cast.  
c12_hin_ar_cbse_06_005: Class 11 foundation on supporting character analysis in Aroh.  
c11_hin_ar_cbse_05_010: If stuck, review the character analysis of Thakur Phoolchand Singh (c11_hin_ar_cbse_05_004) and Ehsan (c11_hin_ar_cbse_05_005) - every key vocabulary word in this chapter is filtered through their opposing positions.  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
none

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_05_004 -> c11_hin_ar_cbse_05_005 -> c11_hin_ar_cbse_05_006

## THIS_FORMULA
N/A - conceptual

## FORMULA_VARIABLES
N/A

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
analytical

## CROSS_SUBJECT
c11_sociology_caste_system | The supporting characters in "xyrk yksgk" embody sociological concepts: èkujke represents family as agent of caste socialization; ekLVj f=kyksd flag represents education as institution of caste reproduction; g¡lqos represents intersection of caste and gender in labor exploitation.
c11_history_dalit_movements | oa'khèkj's character mirrors historical figures like Jyotirao Phule and Savitribai Phule who used education to challenge caste; the story's depiction of institutional resistance connects to history of Dalit access to schooling.

## PREREQ_CONCEPT
Understanding that in Dalit literature, characters often function as *typified positions* within a caste hierarchy rather than fully individualized psychologies.

## PREREQ_BEFORE
Student must be able to summarize eksgu's key conflicts (hunger, humiliation, desire for education, marriage) from the protagonist analysis node.

## PREREQ_STUCK
Review c11_hin_ar_cbse_05_004's worked examples on tracing eksgu's silence and resistance — then map each supporting character to one of those conflicts.

## WORKED_EXAMPLE_1
PROBLEM: Write a board-exam style answer (80-100 words) analyzing how ekLVj f=kyksd flag represents institutional casteism in "xyrk yksgk." Use the PEEL structure: Point, Evidence, Explanation, Link.

STEPS:
- Step 1 (Point): State the analytical claim clearly — ekLVj f=kyksd flag embodies how educational institutions reproduce caste hierarchy instead of dismantling it.
- Step 2 (Evidence): Select two precise textual moments: (a) He forces eksgu to clean the school premises while upper-caste students study; (b) He predicts eksgu will become a "great sweeper" (LowQy) and denies him water from the common pot.
- Step 3 (Explanation): Unpack each evidence. (a) Cleaning vs. studying spatializes caste: the school physically enacts "manual labor for Dalits, intellectual labor for upper castes." (b) The prediction is not prophecy but *enforcement* — by denying education (water/knowledge), he ensures the prophecy self-fulfills. His authority as teacher makes this violence legitimate.
- Step 4 (Link): Connect to the story's central theme — ekLVj f=kyksd flag proves that "modern" institutions (schools) are not automatically progressive; they become caste weapons when occupied by caste-conscious actors. This sets up the contrast with oa'khèkj.
- Step 5 (Polish): Check word count, ensure Hindi terminology (iqjksfgrkbZ, tkfrxr foHkktu, vfèkdkj) is used correctly, verify PEEL flow.

REASONING: This example models the exact board-exam skill: moving from textual detail to structural analysis using disciplinary vocabulary. The 5 steps mirror the cognitive process: claim → evidence → reasoning → thematic synthesis → formal writing.

ANSWER:
ekLVj f=kyksd flag dgkuh mein sansthanik tkfrvaad ka prateek hain. Wo vidyalaya — jo gyan aur samanta ka sthan hona chahiye — ko varna vyavastha ka upkaran bana dete hain. Pratham, wo eksgu se vidyalaya ki safai karwate hain jabki anya chhatra padhte hain; yah 'shram ka vibhajan' caste ke aadhar par spatial roop se dikhata hai. Dvitiye, wo eksgu ko pani pilane se inkar karte hain aur bhavishyavani karte hain ki wo 'mahan LowQy' banega; yeh bhavishyavani nahi, niyojan hai — shiksha (pani/gyan) se vंचit karke wo caste niyati ko nishchit karte hain. Unki shikshak ki authority yeh hinsa ko vaimanikta deti hai. Yeh oa'khèkj ke saath tulna mein ubharta hai: sansthan (vidyalaya) swatah nahi badalta, usme kaun baithta hai — yah tay karta hai ki wo dakshinapan ya mukti ka sthan banega.

## WORKED_EXAMPLE_2
PROBLEM: Compare g¡lqos and oa'khèkj as two figures who "help" eksgu but from radically different positions. Write a structured comparison (100-120 words) showing how their help differs in nature, power, and limitation.

STEPS:
- Step 1: Create a comparison matrix with three rows: Nature of Help, Source of Power, Limitation.
- Step 2: Fill for g¡lqos — Nature: Care labor (feeding, protecting, emotional shielding); Power: Maternal love + survival knowledge (knows how to navigate the village); Limitation: No institutional power, cannot change structural conditions, her body bears the cost (broken by labor).
- Step 3: Fill for oa'khèkj — Nature: Structural intervention (arranges marriage, enables education, uses teacher authority); Power: Institutional position (teacher) + conscious ideological rejection of caste; Limitation: Individual actor, cannot dismantle system alone, his help requires eksgu's own agency (eksgu must study, must leave).
- Step 4: Synthesize — g¡lqos sustains eksgu's *life* (biological/emotional survival); oa'khèkj opens eksgu's *future* (social mobility). Both are necessary; neither is sufficient alone.
- Step 5: Write the answer using comparative connectors (jahaan... wahaan, ek taraf... doosri taraf, lekin) and textual anchors (g¡lqos ki 'èkhjs-èkhjs mehnat', oa'khèkj ka 'csar ka mi;ksx').

REASONING: Comparison questions are high-frequency in board exams. This example teaches the matrix method — forcing students to analyze *across* characters on the same parameters — rather than writing two separate character sketches. The three parameters (nature, power, limitation) are derived from the story's own logic: help in a caste society is always mediated by power.

ANSWER:
g¡lqos aur oa'khèkj — dono eksgu ke sahayak hain — lekin unki sahayata ki prakriti, shakti ka srot, aur simayen bhinn hain. g¡lqos ki sahayata 'palna-purna' hai: wo 'èkhjs-èkhjs' mehnat karke eksgu ko bhookh se bachati hai, uski maansik raksha karti hai, lekin uski shakti keval maatr-sneh aur gaon ki jeevit anubhuti tak simit hai; wo sansthanik badlav nahi la sakti, aur iska moolya uski tooti hui sharir chukati hai. Viparit, oa'khèkj ki sahayata 'sansthanik hस्तक्षेप' hai: wo shikshak ke pad ka upyog karke eksgu ka vivah karwate hain, ushe shiksha dilwate hain, aur caste ke niyam todte hain; unki shakti 'chayanit vichardhara' (csar ka prayog) se aati hai. Lekin wo bhi akela vyavastha nahi tod sakte — eksgu ki khud ki agency (padhai, gaon chhodna) zaroori hai. Ek jeevan bachati hai, doosra bhavishya kholti hai; dono milkar hi mukti ki sambhavna banate hain.

## WORKED_EXAMPLE_3
PROBLEM: A board exam question asks: "xyrk yksgk mein tkfrxr Hinsa keval ekLVj f=kyksd flag jaise 'khulney dushman' dwara nahi, balki apne logon (jaise èkujke) dwara bhi sarjak hoti hai." Is kathan ka moolyankan kijiye do peedak charitron ke sandarbh mein. (Evaluate this statement with reference to two supporting characters.)

STEPS:
- Step 1: Deconstruct the prompt — it demands evaluation (not just description), focuses on "caste violence by own people," and requires two supporting characters.
- Step 2: Select èkujke (father) and g¡lqos (mother) — both are "own people" but enact violence differently.
- Step 3: Analyze èkujke — Direct violence: denies food, forces servitude, withholds education, internalizes caste pride ("tkfrxr ghurk"). His violence is *active enforcement* — he *performs* the caste system within the family.
- Step 4: Analyze g¡lqos — Structural complicity: her silence and labor sustain the household that enables èkujke's authority; she socializes eksgu into acceptance ("chhote chhote kaamo mein lage rehna"). But crucially — her violence is *coerced*; she has no power to resist without destroying her children. This distinction (active enforcer vs. coerced sustainer) is the evaluation's core.
- Step 5: Synthesize — The statement is *partially true but incomplete*. èkujke proves it fully: caste violence is intimate, familial. g¡lqos complicates it: "own people" can also be victims who unwillingly sustain the system. The real insight: caste makes *everyone* in the family its agent, but with vastly different agency.
- Step 6: Write the answer with evaluative language (ek taraf... doosri taraf, yeh adhoora sach hai, asli samajh yeh hai) and close by linking to the story's tragedy — eksgu is betrayed by both the system and his blood.

REASONING: This is the hardest worked example because it combines evaluation + comparison + thematic synthesis — exactly what 6-mark board questions demand. The 6 steps model the full analytical arc: prompt analysis → character selection → individual analysis → dialectical synthesis → thematic linkage → formal writing.

ANSWER:
Yeh kathan adhoora sach hai — sahi hai lekin poora nahi. ekLVj f=kyksd flag ke alawa, tkfrxr hinsa parivar ke andar bhi hoti hai, lekin uska swaroop bhinn hota hai. èkujke (pita) 'sakriya karta' hain: wo bete ko bhookha rakh kar mehmaanon ko khilate hain, use 'eksgu ka vfèkdkj' samajhte hain, Gayatri Mantra nahi sikhate, aur 'tkfrxr ghurk' hokar caste niyam implement karte hain. Unki hinsa *chayanit* aur *adhikarik* hai. Lekin g¡lqos (ma) 'majboor sahyogini' hain: unki 'èkhjs-èkhjs' mehnat aur chuppi wahi parivar chalti hai jahan èkujke ka adhipatya chalta hai; wo eksgu ko 'chhote kaam' mein laga kar caste sanskar deti hain. Par unki agency nahi hai — virodh karne par bachche bhookhe marenge. Toh 'apne log' hinsa karte hain, lekin *saman adhikar se nahi* — pita *shoshak* ke roop mein, ma *shoshit-sahayak* ke roop mein. Dgkuh ki tragedi yeh hai ki eksgu ko bahar (shikshak) aur andar (pita), dono taraf se ghira hua milta hai; ma ki mamta bhi ushe mukti nahi, keval jeevit rakhti hai.

## COMPETENCY_QUESTION_1
QUESTION: In "xyrk yksgk," the character of xaxkjke appears briefly but significantly. Using the concept of "interstitial resistance" (resistance within the cracks of the system), explain how xaxkjke's friendship with eksgu both challenges and fails to challenge the caste order. Support with two specific textual moments.

COMPETENCY: Textual Analysis with Theoretical Lens (Applying a critical concept to literary evidence)

STEPS:
- Step 1: Define "interstitial resistance" in your own words — small acts of humanity in the gaps of an oppressive system that don't overthrow it but refuse its totalizing logic.
- Step 2: Identify Moment 1 — xaxkjke shares his food/tiffin with eksgu when eksgu is hungry (text: "xaxkjke vpkud py cls rks èkujke us lgt Hkko ls mudh fojklr l¡Hkky yh"). Explain how this challenges caste pollution rules (sharing food across caste).
- Step 3: Identify Moment 2 — xaxkjke defends eksgu verbally or physically when others mock him (text: "xaxkjke bldk pquko Lo;a djrs Fks"). Explain how this challenges caste humiliation.
- Step 4: Analyze the failure — xaxkjke never confronts èkujke or ekLVj f=kyksd flag; he doesn't use his privilege to demand systemic change; he remains a student within the same school. His resistance is *affective*, not *structural*.
- Step 5: Conclude — xaxkjke proves that caste can be cracked interpersonally but not dismantled individually; structural change requires institutional power (like oa'khèkj) or collective action.

ANSWER:
"Interstitial resistance" — vyavastha ki dararon mein chhote chhote virodh — xaxkjke ki dosti mein dikhai deta hai. Pehla, wo eksgu ke saath apna tiffin baant ta hai (eksgu bhookha hone par), jo caste ke 'chhua-chhut' niyam ko todta hai: khana baantna = ritual purity ka khandan. Dusra, wo eksgu ka bachav karta hai jab anya uska mazak udate hain (xaxkjke uska paksh lette hain), jo caste ke apmaan ko manchahin karna hai. Lekin yeh resistance 'interstitial' hi rehti hai: xaxkjke na to èkujke se ladte hain, na ekLVj f=kyksd flag ko challenge karte hain, na vidyalaya ke niyam badalte hain. Wo keval 'accha dost' bante hain — vyavastha ke andar reh kar. Yeh dikhata hai ki vyaktigat manavta (xaxkjke) zaroori hai lekin kaafi nahi; caste todne ke liye sansthanik shakti (oa'khèkj jaisa) ya samuhik karyavahi chahiye.

DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: The story ends with eksgu leaving the village for the city, carrying his mother's blessing but his father's curse. Construct an argument (150-180 words) that the *supporting characters collectively* determine whether eksgu's departure is escape or exile. Use at least three supporting characters as evidence.

COMPETENCY: Synthesis and Argumentation (Integrating multiple character analyses into a coherent thesis)

STEPS:
- Step 1: Formulate the thesis — Departure is *both* escape and exile, and each supporting character tips the balance toward one pole.
- Step 2: Evidence 1 (g¡lqos → Escape) — Her blessing ("cspkjs iafMr th dks rks I+kqQlZr ugha jgrh...") frames departure as liberation; she pushes him out to save his life, making it escape.
- Step 3: Evidence 2 (èkujke → Exile) — His curse and refusal to acknowledge eksgu ("eksgu yyk cpiu ls gh cM+s cqf¼eku Fks") frames departure as rejection; he makes eksgu an outsider in his own home, making it exile.
- Step 4: Evidence 3 (oa'khèkj → Escape with agency) — He equips eksgu with education and marriage (social tools), transforming flight into strategic mobility; he makes escape *possible*.
- Step 5: Evidence 4 (ekLVj f=kyksd flag → Exile as systemic verdict) — His prediction that eksgu will only be a sweeper follows eksgu to the city; the caste label travels with him.
- Step 6: Synthesize — The village doesn't just "let him go"; each character's action writes a different meaning onto his departure. The text refuses a single label — that ambiguity *is* the Dalit migrant condition.

ANSWER:
Eksgu ka gaon chhodna na keval 'bhagna' (escape) hai na keval 'nirvasan' (exile) — yeh dono ek saath hain, aur har peedak charitra is dwandwa ko alag-alag disha deta hai. g¡lqos ka aashirvaad ("cspkjs iafMr... fdlh ke ghar fHktok nsne par...") use 'mukti' ka roop deti hai: wo use *dhakelti* hai bahar, taaki wo zinda rahe — yahan departure *escape* hai. Viparit, èkujke ka shraap aur swikaroty ka abhav ("cpiu ls gh cM+s cqf¼eku") use 'paraya' bana deta hai: uska apna ghar hi use nikaal deta hai — yahan departure *exile* hai. oa'khèkj is dwandwa ko *sambhavna* mein badalte hain: shiksha aur vivah dekar wo bhagna ko *ranneetik chal* bana dete hain — escape with agency. Lekin ekLVj f=kyksd flag ki bhavishyavani ("mahan LowQy") uska peecha sheher tak karti hai: caste ka theppa saath chalta hai. Toh gaon chhodna ek hi samay mein: ma ka pyaar (mukti), pita ka tyag (nirvasan), guru ka hathiyaar (adhikar), aur dusre guru ka shraap (niyati). Yeh ambivalence hi 'xyrk yksgk' ki asli kahani hai — Dalit pravasi ki sthiti ek label mein nahi bandhi ja sakti.

DIFFICULTY: hard