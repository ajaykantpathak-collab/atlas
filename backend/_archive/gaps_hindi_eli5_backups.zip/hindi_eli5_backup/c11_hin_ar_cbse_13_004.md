## DEFINITION
Character analysis of the protagonist in a poem involves examining the speaker's persona, their attitudes, values, conflicts, and development as revealed through the poem's imagery, tone, diction, and structure.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student can write a structured character analysis of the poem's protagonist using textual evidence from at least three stanzas, explaining how the poet's choices reveal the protagonist's worldview and social consciousness.

## SCOPE_BOUNDARY
This node covers analysis of the protagonist (speaker/persona) in Nagarjun's poem "lk;s esa /wi" only. It does not cover supporting characters (node 005), themes (nodes 006-007), or literary devices in isolation (nodes 008-009).

## WALKTHROUGH
Imagine you're sitting in a dark room at night, hearing the wind outside, and you start thinking about the unfairness you see in the world—that's the protagonist's starting point. To begin analysis, first identify who is speaking: the "I" in the poem. Then, trace what the speaker observes (the woods, the night, the stars) and how they react (anger, solidarity with the poor). Notice the shift from description to rebellion. The key insight: the protagonist isn't just a person in the woods; they are the poet's voice challenging social injustice.

## DIAGNOSTIC_QUESTION_1
Who is the protagonist in the poem "lk;s esa /wi"? Provide a one-sentence answer based on the text.

## DIAGNOSTIC_ANSWER_1
The protagonist is the first-person speaker ("eSa"), who represents the poet Nagarjun himself as a conscious observer and revolutionary voice. A wrong answer (e.g., "the woods" or "the night") reveals the student cannot distinguish between setting and persona, a fundamental error in poetic analysis.

## DIAGNOSTIC_QUESTION_2
Explain in your own words why the protagonist feels restless in the first stanza. What does this restlessness signify about their character?

## DIAGNOSTIC_ANSWER_2
The protagonist's restlessness stems from witnessing the exploitation and hypocrisy of society (the "deceiver" who exploits both home and street). This signifies a deeply empathetic and socially aware character who cannot remain indifferent to injustice. A wrong answer focusing only on physical discomfort (cold, darkness) misses the metaphorical layer and shows literal comprehension only.

## DIAGNOSTIC_QUESTION_3
Apply the concept of "dual address" (the word 'fpjkx' used in two contexts) to analyze the protagonist's view of power. How does this word choice reveal the protagonist's analytical mind?

## DIAGNOSTIC_ANSWER_3
The protagonist uses 'fpjkx' first for the domestic exploiter (landlord/moneylender) and then for the systemic exploiter (state/ruler), showing they see oppression operating at both personal and structural levels. This reveals a character who analyzes power structurally, not just emotionally. A wrong answer that treats both uses as identical misses the progression from micro to macro exploitation.

## DIAGNOSTIC_QUESTION_4
Analyze the three stanzas as three stages of the protagonist's consciousness. What does each stage reveal about their evolving character?

## DIAGNOSTIC_ANSWER_4
Stanza 1: Personal anguish at domestic exploitation (empathetic observer). Stanza 2: Expansion to systemic exploitation (political analyst). Stanza 3: Revolutionary commitment (active resister). Together they show a character moving from feeling to analysis to action. A wrong answer that merely summarizes each stanza's imagery without linking to character development fails the analytical requirement.

## DIAGNOSTIC_QUESTION_5
Evaluate the effectiveness of the protagonist's final declaration ("rsjk fu”kke gS fly ns ”kqcku 'kk;j dh"). Does it strengthen or weaken their character portrayal? Justify.

## DIAGNOSTIC_ANSWER_5
It strengthens the portrayal by transforming the protagonist from a sufferer into a leader who claims authority ("fu”kke") to speak for the oppressed ("cgj"). The metaphor of giving light ("fly ns") to the dark world ("cgj") shows agency and hope. A wrong answer calling it "arrogant" or "just poetic" fails to evaluate the strategic shift from victimhood to empowerment.

## DIAGNOSTIC_QUESTION_6
Create a two-stanza poem in Hindi (4 lines each) where a similar protagonist observes a modern injustice (e.g., urban displacement, digital divide) and declares resistance. Use the same structural progression: observation → analysis → commitment.

## DIAGNOSTIC_ANSWER_6
A good answer will show: Stanza 1: Concrete imagery of the injustice (e.g., bulldozers, glowing screens). Stanza 2: Identification of the exploiter (builder, algorithm) and declaration of resistance. Poor answers will be generic slogans without imagery or will miss the two-stage progression, revealing inability to transfer the structural pattern.

## COMMON_MISCONCEPTION
Students often think the protagonist in a poem is always the poet themselves in a biographical sense, leading them to write about Nagarjun's life instead of analyzing the constructed persona. For example, they might write "Nagarjun was a communist so the protagonist is communist" without showing how the poem's specific lines construct that stance. This error occurs because they confuse authorial intent with textual evidence.

## ON_FAILURE
If a student makes this error, first ask them to highlight every "eSa" (I) and "my" reference in the poem. Then, have them list what the text explicitly says about this "I" (observes, feels, declares). Next, ask: "Does the poem say he is a communist, or does it show him siding with the poor?" Finally, guide them to rewrite their analysis using only textual evidence, framing it as "The speaker portrays themselves as..." not "Nagarjun was..."

## BUILDS_ON
This node builds on the ability to identify the speaker/persona in a poem (covered in Class 10 poetry basics) and the skill of using textual evidence for claims.

## LEADS_TO
This node enables deeper theme analysis (nodes 006-007) where the protagonist's character becomes the lens for interpreting the poem's central ideas about exploitation and resistance.

## PREREQUISITE_NODE_IDS
c11_hin_ar_cbse_13_001, c11_hin_ar_cbse_13_002, c11_hin_ar_cbse_13_003
## PREREQUISITE_REASONS
c11_hin_ar_cbse_13_001: Provides background on Nagarjun's revolutionary context essential to understand the protagonist's stance.
c11_hin_ar_cbse_13_002: Establishes the poem's narrative structure (three stanzas = three stages) which frames the protagonist's development.
c11_hin_ar_cbse_13_003: Explains the setting (woods, night) that shapes the protagonist's mood and metaphors.

## FORWARD_NODE_IDS
c11_hin_ar_cbse_13_005, c11_hin_ar_cbse_13_006, c11_hin_ar_cbse_13_013, c11_hin_ar_cbse_13_007, c12_hin_ar_cbse_13_004, c12_hin_ar_cbse_13_007

## FORWARD_REASONS
c11_hin_ar_cbse_13_005: Supporting characters (the exploited, the exploiters) are defined in relation to the protagonist's perspective.
c11_hin_ar_cbse_13_006: The primary theme (resistance to exploitation) emerges directly from the protagonist's character arc.
c11_hin_ar_cbse_13_013: Critical interpretation requires a solid protagonist analysis as foundation for evaluating the poem's ideological stance.
c11_hin_ar_cbse_13_007: The protagonist (the speaking "I" who identifies with the children) is the lens through which secondary themes are witnessed and voiced.  
c12_hin_ar_cbse_13_004: Class 11 character analysis foundation (traits, motivation, conflict) is the methodological prerequisite.  
c12_hin_ar_cbse_13_007: Character analysis of Igyoku required — themes are embodied through his choices  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
none

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_13_001 -> c11_hin_ar_cbse_13_004 -> c11_hin_ar_cbse_13_006

## THIS_FORMULA
N/A - conceptual

## FORMULA_VARIABLES
N/A

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
analytical

## CROSS_SUBJECT
c11_history_social_movements | The protagonist's evolution from observer to resister mirrors the historical progression of peasant movements in India (e.g., Telangana, Naxalbari) where intellectuals joined grassroots struggles.
c11_civics_power_structures | The poem's dual use of 'fpjkx' (deceiver) for both local landlord and state ruler illustrates the civics concept of power operating at multiple levels (local/state) and the need for structural analysis.

## PREREQ_CONCEPT
Ability to distinguish between poet and persona, and to trace character development across poetic stanzas using textual evidence.

## PREREQ_BEFORE
Student must know how to identify first-person perspective in poetry and understand that a poem's "I" is a constructed voice, not necessarily the autobiographical author.

## PREREQ_STUCK
Review "Speaker vs. Poet" distinction from Class 10 poetry chapter (e.g., in "The Road Not Taken" the speaker is a persona, not Frost himself).

## WORKED_EXAMPLE_1
PROBLEM: Analyze how the protagonist's character is revealed through the imagery of darkness and light in the first two stanzas of "lk;s esa /wi".
STEPS:
- Step 1: Identify all darkness/light images in Stanza 1 (night, woods, stars) and Stanza 2 (darkness of exploitation, false light of exploiters).
- Step 2: Note the protagonist's position: they are in the darkness but can see the stars ("xqyeksgj") — they have vision others lack.
- Step 3: Contrast with the exploiters who create darkness for others ("fpjkx" who deceive) — the protagonist sees through this deception.
- Step 4: Connect to character: the protagonist is a truth-seeker who navigates darkness with clarity, unlike the complacent or deceived.
- Step 5: Verify with text: The protagonist says "eSa csdjkj gw¡ vkok”k esa vlj osQ fy," — they are awake/aware in the night of exploitation.
REASONING: This step-by-step moves from concrete imagery to abstract character trait, using the poem's central metaphor cluster. It models how to build an analytical paragraph: evidence → interpretation → character insight.
ANSWER: The protagonist emerges as a lucid consciousness in a dark world. The woods/night represent societal ignorance and oppression; the stars represent truth/revolutionary ideas. By positioning themselves as one who sees the stars ("xqyeksgj") while others are deceived ("fpjkx"), the protagonist claims the role of the awakened intellectual who guides the oppressed ("cgj") toward light ("fly").

## WORKED_EXAMPLE_2
PROBLEM: Write a PEEL paragraph analyzing the protagonist's attitude toward the exploited ("cgj") in the final stanza.
STEPS:
- Step 1: Point — The protagonist identifies completely with the oppressed, not as an outsider but as their voice.
- Step 2: Evidence — "ft,¡ rks vius cxhps esa xqyeksgj osQ rys] ejsa rks xSj dh xfy;ksa esa xqyeksgj osQ fy," (They carry stars in pockets; I carry stars for the suffering).
- Step 3: Explanation — "cxhps esa rys" suggests private hoarding of hope; "xSj dh xfy;ksa esa fy," suggests active distribution of hope to the wounded. The protagonist transforms revolutionary consciousness into collective resource.
- Step 4: Link — This cements the protagonist as organic intellectual (Gramsci) who doesn't just theorize but serves the masses, completing the arc from personal anguish (Stanza 1) to systemic analysis (Stanza 2) to committed action (Stanza 3).
- Step 5: Concluding sentence — Thus, the final stanza redefines the protagonist from a sufferer to a leader whose authority ("fu”kke") comes from service, not power.
REASONING: PEEL structure ensures each analytical claim is grounded in text and linked to the larger character arc. The Gramsci reference (optional for advanced students) shows cross-disciplinary depth.
ANSWER: The protagonist's attitude toward the exploited is one of radical solidarity and servant-leadership. While others hoard revolutionary ideas ("xqyeksgj") for themselves ("vius cxhps esa... rys"), the protagonist dedicates them to healing the wounded ("xSj dh xfy;ksa esa... fy,"). This contrast reveals a character who transforms intellectual capital into communal care, claiming legitimacy ("fu”kke") through service to the "cgj" (masses). The protagonist thus embodies the organic intellectual who emerges from the people and returns to empower them.

## WORKED_EXAMPLE_3
PROBLEM: Compare the protagonist of "lk;s esa /wi" with the protagonist of another Nagarjun poem you have studied (e.g., "Akhir Mein" or "Badal Ko Ghirte Dekha Hai"). How does the persona differ in its relationship to power?
STEPS:
- Step 1: Recall the other poem's protagonist — e.g., in "Badal Ko Ghirte Dekha Hai", the speaker watches clouds gather, symbolizing impending revolution, but remains an observer.
- Step 2: Identify the core stance toward power in each: "lk;s esa /wi" protagonist actively confronts and names the deceiver ("fpjkx") and claims authority to give light; the other poem's protagonist may witness but not directly challenge.
- Step 3: Analyze linguistic markers: "lk;s esa /wi" uses imperative/declarative mood ("rsjk fu”kke gS", "eSa csdjkj gw¡"); the other may use more descriptive/conditional language.
- Step 4: Connect to historical context: "lk;s esa /wi" reflects the Emergency period (1975) when direct resistance was dangerous yet necessary; the other poem may reflect a different political moment.
- Step 5: Synthesize: The "lk;s esa /wi" protagonist is more confrontational and self-authorizing, representing a shift from prophetic warning to active leadership in Nagarjun's poetic persona.
- Step 6: Conclude: This comparison shows Nagarjun crafting different personas for different strategic purposes — not a fixed "Nagarjun voice" but situationally responsive protagonists.
REASONING: This multi-step comparison requires holding two complex textual analyses simultaneously and evaluating them against historical context — a high-level analytical skill for board exams.
ANSWER: The protagonist of "lk;s esa /wi" is distinctively confrontational and self-authorizing compared to the more observational persona in "Badal Ko Ghirte Dekha Hai". In the latter, the speaker watches clouds ("badal") as metaphors for mass upsurge but remains at a distance ("dekha hai"). In "lk;s esa /wi", the protagonist enters the fray: they name the enemy ("fpjkx"), claim the right to illuminate ("fu”kke gS fly ns"), and position themselves among the wounded ("xSj dh xfy;ksa"). This reflects the Emergency context where passive prophecy was insufficient; the poem constructs a protagonist who embodies resistance as immediate, personal, and collective. Nagarjun thus deploys persona strategically: the cloud-watcher warns, the woods-walker acts.

## COMPETENCY_QUESTION_1
QUESTION: The protagonist in "lk;s esa /wi" says: "eSa csdjkj gw¡ vkok”k esa vlj osQ fy," (I am deeply seated in the lap of longing for freedom). Using this line as anchor, explain how the poem constructs the protagonist's 'longing' not as passive desire but as active resistance. Support with two other textual details.
COMPETENCY: Analytical interpretation with textual evidence
STEPS:
- Step 1: Define "vlj" (longing) in context — not wishful thinking but a driving force that positions the protagonist ("csdjkj gw¡" — deeply seated).
- Step 2: Identify first evidence: The protagonist's wakefulness in the night of exploitation ("x”ky osQ 'ksjksa esa osQanzh; Hkko" — restlessness in every stanza).
- Step 3: Identify second evidence: The final declaration of authority to give light ("fu”kke gS fly ns") — longing translates into empowerment of others.
- Step 4: Synthesize: The longing is the engine that moves the protagonist from observation (Stanza 1) to analysis (Stanza 2) to action (Stanza 3).
ANSWER: The protagonist's "vlj" (longing for freedom) is constructed as an active, embodied resistance. "csdjkj gw¡" (deeply seated) implies it's not fleeting but foundational to their being. This longing manifests as: (1) Persistent restlessness — the protagonist cannot sleep/accept the exploitation ("x”ky osQ 'ksjksa esa osQanzh; Hkko"), each stanza escalating the confrontation; (2) Transformative agency — the longing culminates in claiming "fu”kke" (authority) to distribute light ("fly") to the dark world ("cgj"). Thus, longing here is revolutionary praxis: it fuels the journey from witness to warrior.
DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: A student writes: "The protagonist is angry at the rich." Why is this an inadequate character analysis for a Class 11 board answer? Rewrite it as a high-scoring analysis statement using the PEEL structure and at least two poetic devices.
COMPETENCY: Critical evaluation of answer quality / Meta-cognitive writing skill
STEPS:
- Step 1: Identify the flaws: "angry" reduces complex affect to a single emotion; "the rich" oversimplifies the layered exploiters (domestic + systemic); lacks textual evidence; ignores poetic craft.
- Step 2: Recall poetic devices in the poem: metaphor (darkness/light), repetition ("fpjkx"), contrast (hoarding vs. distributing stars), symbol (stars = revolutionary consciousness).
- Step 3: Draft PEEL: Point — The protagonist's outrage is structurally analytical, not merely emotional. Evidence — The dual use of "fpjkx" (Stanza 1 & 2) maps exploitation from household to state. Explanation — This metaphorical patterning shows the protagonist diagnoses power systemically. Link — Thus, the protagonist embodies a Marxist organic intellectual, not just an angry individual.
- Step 4: Refine for board-exam language: Use terms "metonymic progression", "dialectical awareness", "revolutionary subjectivity".
ANSWER: The original statement fails because it: (a) reduces a dialectical consciousness to a single emotion ("angry"), (b) homogenizes the exploiters ("the rich") ignoring the poem's metonymic progression from "fpjkx" as household deceiver to "fpjkx" as state ruler, (c) provides zero textual evidence, (d) ignores poetic devices that construct the protagonist's analytical mind. High-scoring rewrite: "The protagonist's resistance stems from a dialectical awareness of exploitation's layered structure, evident in the metonymic repetition of 'fpjkx' — first for the domestic oppressor ('gjsoQ ?kj osQ fy,') then for the sovereign power ('eqrebu gSa fd iRFkj fi?ky ugha ldrk'). This poetic patterning constructs the protagonist as a Gramscian organic intellectual who diagnoses power systemically, transforming personal anguish ('osQanzh; Hkko') into collective revolutionary agency ('fu”kke gS fly ns ”kqcku 'kk;j dh')."
DIFFICULTY: hard