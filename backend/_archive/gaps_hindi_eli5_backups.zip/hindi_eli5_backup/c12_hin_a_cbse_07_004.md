## DEFINITION
Character analysis of the protagonist in Bihari's *ckjgeklk* involves examining the nayika (heroine) through her emotional states, actions, speech, and the poet's descriptive imagery across the poem's seasonal settings, revealing her as the embodiment of *viraha* (separation-longing) in the *shringara rasa* tradition.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student can independently identify the nayika's defining traits across at least three stanzas, cite specific imagery as evidence, explain how each trait reflects *viraha bhava*, and write a structured 150-word character sketch using the PEEL method (Point, Evidence, Explanation, Link) that would score full marks in a CBSE 5-marker.

## SCOPE_BOUNDARY
This node covers ONLY the protagonist (nayika/ukf;dk) of *ckjgeklk* — her portrayal through seasonal imagery, emotional progression, and linguistic markers in Bihari's Braj Bhasha couplets. It does NOT cover supporting characters (sakhi, nayak), other poems by Bihari, or comparative analysis with other *ritikaleen* poets — those are in sibling nodes.

## WALKTHROUGH
Imagine you're asked in the board exam: "Bihari's nayika is not just a woman waiting — she is *viraha* personified. Explain with reference to *ckjgeklk*." Where do you begin? Don't start memorizing lines. Start by asking: "What does the nayika *do* in each stanza?" In stanza 1, she sits by the door in rain, describing her state to a sakhi. In stanza 2, she endures winter night, body stiffening. In stanza 3, summer heat burns her. Notice the pattern? Each stanza = a season = a physical manifestation of her inner longing. The protagonist isn't described through adjectives — she is *revealed* through what she endures. Your job: trace that revelation across the three stanzas, using the imagery (rain, cold, heat) as your evidence. The key insight: in *ritikavya*, the nayika's character *is* her emotional response to separation — there is no "personality" apart from *viraha*.

## DIAGNOSTIC_QUESTION_1
What is the primary emotion (*sthayi bhava*) that defines the protagonist (nayika) in Bihari's *ckjgeklk*, and which *rasa* does it belong to?

## DIAGNOSTIC_ANSWER_1
The primary emotion is *viraha* (separation-longing), which is the *sthayi bhava* of *shringara rasa* (specifically *vipralambha shringara*). A wrong answer like "love" or "sadness" reveals the student confuses the general feeling with the specific technical term *viraha* required by CBSE marking scheme, and misses the *rasa* classification that connects to Class 11 *rasa-siddhant* (c11_hin_ar_cbse_07_006).

## DIAGNOSTIC_QUESTION_2
In stanza 1 of *ckjgeklk*, the nayika says: "fi; lkSa dgsgq l¡nslM+k] ,s Hk¡ojk ,s dkx". Explain in your own words what this line reveals about her character — do NOT translate word-for-word.

## DIAGNOSTIC_ANSWER_2
The line reveals her *proactive articulation of suffering* — she doesn't just suffer silently; she narrates her condition ("lans'k") to the sakhi, making her pain communicable and witnessed. This shows *viraha* as an active, expressive state, not passive endurance. A wrong answer that merely translates ("she tells her condition of cold and heat") misses the character insight: the nayika *performs* her longing, which is a hallmark of *ritikaleen* nayika typology (*abhisarika* / *virahotkanthita*).

## DIAGNOSTIC_QUESTION_3
Apply the PEEL method to write a 4-sentence paragraph proving: "The nayika's physical body becomes a map of her inner longing." Use evidence from ANY one stanza.

## DIAGNOSTIC_ANSWER_3
**Point:** The nayika's body registers each season as a symptom of *viraha*. **Evidence:** In stanza 2, "iwl tkM+ FkjFkj ru dk¡ik" (winter night, body trembling) and "fcjg ckf<+ Hkk nk#u lhmQ" (cold severe, frost biting). **Explanation:** The trembling ("FkjFkj") and biting cold ("nk#u") are not just weather descriptions — they are the body *enacting* the internal chill of separation. **Link:** Thus, Bihari makes the nayika's physiology the literal inscription of her emotion. A wrong answer that lists quotes without the "Explanation" step fails the *analytical* requirement of CBSE 3-markers.

## DIAGNOSTIC_QUESTION_4
Compare the nayika's portrayal in stanza 1 (rain) vs stanza 3 (summer). What does the *shift in imagery* tell you about the *duration* and *intensity* of her *viraha*?

## DIAGNOSTIC_ANSWER_4
Rain (stanza 1) = acute, fresh separation — she still speaks ("lans'k Hkst jgh"), body responsive ("Hk¡ojs rFkk dkx"). Summer (stanza 3) = prolonged, chronic separation — "iQkxqu iou >dksjs 'khr dks pkSxquk c<+k" (scorching wind dries the body), "fx;¡ u¯g gkj jgh" (breath not staying). The shift from *communicative suffering* to *physiological collapse* shows *viraha* deepening over time. A wrong answer that only contrasts "rain vs heat" misses the temporal progression that proves the nayika's *endurance* — a key trait CBSE asks for in "character sketch over time" questions.

## DIAGNOSTIC_QUESTION_5
Evaluate this claim: "Bihari's nayika in *ckjgeklk* has no individuality — she is merely a *type* (nayika-bheda) from *rasa-shastra*." Defend or refute using textual evidence.

## DIAGNOSTIC_ANSWER_5
Refute. While she fits *virahotkanthita* typology (Class 11 *rasa-siddhant*), Bihari individuates her through *specificity of sensation*: "lkSj lqisrh vkoS twM+h" (limbs contracting/expanding), "fgoapy cw<+h" (withered like a dried creeper), "jdr <jk ek¡lw xjk" (burning like fire). These are not generic — they are *observed* bodily details that make her *this* woman in *this* moment. A wrong answer that agrees ("yes, she's a type") ignores the *lokdharmi* (realistic) layer Bihari adds — his innovation noted in the NCERT intro ("vykSfdd vkSj ijks{k lÙkk dk vkHkkl").

## DIAGNOSTIC_QUESTION_6
Create a 4-line Braj Bhasha couplet (in Devanagari) that could be a *fourth stanza* for *ckjgeklk*, depicting the nayika in *autumn (sharad)* — maintaining her established character traits and the poem's rhythmic pattern.

## DIAGNOSTIC_ANSWER_6
A valid attempt must: (a) use Braj vocabulary (e.g., *kans, sharad, chandni, shital*), (b) show the nayika's body responding to autumn *as viraha* (e.g., "shital hawa tan jharat, chandni kyari kyari"), (c) keep the *doha* metre (24+24 matras), (d) end with a line addressing the sakhi or nayak. Poor answer: generic autumn description without the nayika's *viraha* lens — reveals the student hasn't internalized that *setting = character* in this poem.

## COMMON_MISCONCEPTION
Students treat the nayika as a "character with a personality" (shy, brave, clever) like in a novel. They write: "The nayika is patient because she waits through three seasons." **Why this is wrong:** In *ritikavya*, the nayika *is* the *bhava* — she doesn't *have* patience; she *enacts* *viraha*. Her "waiting" is not a choice (personality) but her *ontological state*. CBSE examiners deduct marks for imposing modern psychological realism on a *lakshana-granth* character. The NCERT explicitly says: "tk;lh us bl dkO;&jpuk osQ fy, nksgk&pkSikbZ dh 'kSyh viukbZ gSA" — he chose the *nayika-bheda* framework deliberately.

## ON_FAILURE
1. Re-read c12_hin_a_cbse_07_001 (Context) to re-ground in *ritikaleen* conventions. 2. Re-do c12_hin_a_cbse_07_003 (Setting) — trace how *each season's imagery* maps to a *specific bodily sensation* of the nayika. 3. Practice the "Image → Sensation → Emotion" chain on stanza 2: cold wind (image) → trembling limbs (sensation) → *viraha* chill (emotion). 4. Re-attempt Diagnostic Q3 with this chain — if still stuck, revisit Class 11 *nayika-bheda* (c11_hin_ar_cbse_07_004).

## BUILDS_ON
Class 11 *nayika-bheda* and *rasa-siddhant* (c11_hin_ar_cbse_07_004, c11_hin_ar_cbse_07_006) — the typological framework that Bihari both uses and particularizes.

## LEADS_TO
c12_hin_a_cbse_07_005 (Supporting Characters) — the sakhi's role as witness/foil to the nayika's *viraha*; c12_hin_a_cbse_07_006 (Primary Theme) — *viraha* as the structural spine of the poem.

## PREREQUISITE_NODE_IDS
c12_hin_a_cbse_07_001, c12_hin_a_cbse_07_002, c12_hin_a_cbse_07_003, c11_hin_ar_cbse_07_004, c11_hin_ar_cbse_07_006
## PREREQUISITE_REASONS
c12_hin_a_cbse_07_001: Provides Bihari's *lokdharmi* context and *ritikaleen* conventions essential to read the nayika correctly.
c12_hin_a_cbse_07_002: Establishes the poem's three-stanza seasonal structure — the scaffold for the nayika's emotional arc.
c12_hin_a_cbse_07_003: Teaches how setting (rain/winter/summer) functions as *objective correlative* for the nayika's inner state.
c11_hin_ar_cbse_07_004: Supplies the *nayika-bheda* terminology (*virahotkanthita*, *abhisarika*, etc.) needed for precise analysis.
c11_hin_ar_cbse_07_006: Gives the *rasa-shastra* foundation (*sthayi bhava*, *vipralambha shringara*) without which "character" cannot be defined in this tradition.

## FORWARD_NODE_IDS
c12_hin_a_cbse_07_005, c12_hin_a_cbse_07_006, c12_hin_a_cbse_07_012, c12_hin_a_cbse_07_013, c12_hin_a_cbse_07_014, c12_hin_a_cbse_07_015

## FORWARD_REASONS
c12_hin_a_cbse_07_005: The sakhi (supporting character) exists only in relation to the nayika's *viraha* — her dialogues are responses to the protagonist's utterances.
c12_hin_a_cbse_07_006: The primary theme *is* the nayika's *viraha* — theme and protagonist are co-extensive in *ritikavya*.
c12_hin_a_cbse_07_012: Comprehension questions (literal/inferential) directly test the nayika's portrayal — e.g., "How does the nayika describe her state in stanza 1?"
c12_hin_a_cbse_07_013: Critical thinking requires evaluating the nayika as *type vs individual* — the exact debate in Diagnostic Q5.
c12_hin_a_cbse_07_014: Writing skills (character sketch, analytical paragraph) apply the PEEL method practiced in this node's worked examples.
c12_hin_a_cbse_07_015: Protagonist (ukxerh) characterization anchors voice adoption  

## CROSS_SUBJECT_PREREQS
c11_hin_ar_cbse_07_004, c11_hin_ar_cbse_07_006
## CROSS_SUBJECT_REASONS
c11_hin_ar_cbse_07_004: Class 11 *nayika-bheda* provides the taxonomic vocabulary (*virahotkanthita*, *khandita*, etc.) that makes Class 12 analysis precise rather than impressionistic.
c11_hin_ar_cbse_07_006: Class 11 *rasa-siddhant* (*sthayi bhava*, *vibhava-anubhava-vyabhichari*) gives the theoretical lens to read the nayika's body as *anubhava* (physical manifestation) of *viraha*.

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_07_004 -> c12_hin_a_cbse_07_004 -> c12_hin_a_cbse_07_005

## THIS_FORMULA
N/A - conceptual

## FORMULA_VARIABLES
N/A

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
conceptual

## CROSS_SUBJECT
N/A | Bihari's *ritikavya* emerges from the same Braj cultural milieu as the *Bhakti movement* — the nayika's *viraha* mirrors the *bhakta's* longing for Krishna; both use *shringara* as spiritual metaphor.
 N/A | The poem illustrates *embodied cognition* — the nayika's emotions are not "in the mind" but distributed across bodily sensations (trembling, burning, breathlessness), a core concept in modern affective science.
## PREREQ_CONCEPT
*Viraha* as *sthayi bhava* of *vipralambha shringara* — the nayika's character *is* this emotion in dramatic form.

## PREREQ_BEFORE
Student must know the three *nayika-bheda* categories (*mugdha*, *madhya*, *pragalbha*) and the eight *ashta nayika* types — especially *virahotkanthita* — from Class 11 *rasa-shastra*.

## PREREQ_STUCK
If stuck on "why is she not a real person?", revisit Class 11 *nayika-bheda* (c11_hin_ar_cbse_07_004): the *lakshana-granth* tradition defines characters by *defining traits* (lakshanas), not psychological depth.

## WORKED_EXAMPLE_1
PROBLEM: Write a 100-word character sketch of the nayika in *ckjgeklk* for a 3-mark CBSE question. Use the PEEL structure explicitly.

STEPS:
- Step 1: Identify the core trait — she is the *embodiment of viraha* (Point).
- Step 2: Select one piece of evidence per stanza: Stanza 1 — "lans'k Hkst jgh" (communicating suffering); Stanza 2 — "iwl tkM+ FkjFkj ru dk¡ik" (body trembling in cold); Stanza 3 — "iQkxqu iou >dksjs 'khr dks pkSxquk c<+k" (scorching wind drying body) (Evidence).
- Step 3: Explain each: Stanza 1 shows *viraha* as expressive; Stanza 2 shows *viraha* as physiological; Stanza 3 shows *viraha* as cumulative destruction (Explanation).
- Step 4: Link together: The progression from speech to tremor to desiccation maps *viraha* deepening across time — the nayika *is* this temporal arc (Link).
- Step 5: Polish into formal Hindi: "ckjgeklk ki nayika viraha ki pratimoorti hain..." (Final answer).

REASONING: CBSE marking scheme awards 1 mark for trait identification, 1 for textual evidence, 1 for analytical linkage. The PEEL structure guarantees all three. Using *one evidence per stanza* covers the whole poem — a common board requirement ("textual reference").

ANSWER: ckjgeklk ki nayika viraha ki pratimoorti hain. Pratham padya mein vah sakhi se apni sthiti ka lans'k karti hain ("lans'k Hkst jgh"), jo viraha ki abhivyaktishilta dikhata hai. Dvitiye padya mein sheet rat mein uska sharir kanpta hai ("FkjFkj"), jo viraha ka sharirikaran hai. Tritiye padya mein lu ke tapte hawa ushe sukha deti hai ("pkSxquk c<+k"), jo viraha ki sanchayi hui vidaraka shakti hai. Ye tin avasthayen — vakya, kampan, shoshan — viraha ke badhte hue charan hain. Nayika koi vyaktigat charitra nahin, viraha ka kalatmak vikas hai.

## WORKED_EXAMPLE_2
PROBLEM: A board question asks: "How does Bihari use *nature imagery* to reveal the nayika's inner state? Answer with reference to two stanzas." Write a 4-point structured answer.

STEPS:
- Step 1: Deconstruct the question — it asks for *nature imagery → inner state* mapping, not just description. Two stanzas required.
- Step 2: Choose Stanza 1 (rain) and Stanza 3 (summer) for maximum contrast.
- Step 3: For each stanza, apply the formula: Nature Image → Bodily Sensation → Inner State. Stanza 1: Rain/cold/heat (nature) → "Hk¡ojs rFkk dkx" (sensation) → Fresh, communicative *viraha* (state). Stanza 3: Scorching wind/sun (nature) → "fx;¡ u¯g gkj jgh" (sensation) → Exhausted, near-collapse *viraha* (state).
- Step 4: Synthesize: Nature is not background — it is the *instrument* that measures the nayika's *viraha* intensity.
- Step 5: Format as four numbered points for the examiner.

REASONING: CBSE "how does the poet use..." questions test *technique awareness*. The 3-step chain (Image → Sensation → State) is the standard analytical move for *ritikavya* where nature = *vibhava* (determinant) of *rasa*. Numbered points ensure the examiner sees both stanzas clearly.

ANSWER:
1. Varsharitu (padya 1): Varsh, sheet, tap — ye prakritik tatva nayika ke tan ko "Hk¡ojs rFkk dkx" banate hain, jo navin viraha ki teevrata aur abhivyakti ki shakti ka sanket dete hain.
2. Grishmaritu (padya 3): "iQkxqu iou" aur "cgk" (suraj) nayika ke "fx;¡" ko sukha dete hain ("u¯g gkj jgh"), jo diर्घ viraha dwara sharir ke vinash ka prateek hain.
3. Prakriti ke ye do chitra — varsha ki aardra teevrata se grishma ki shushka vidaraka tak — nayika ke viraha ki samayik gati ko mapte hain.
4. Bihari prakriti ko keval alankar nahin, viraha ke 'anubhava' ka pratyaksha madhyam banate hain.

## WORKED_EXAMPLE_3
PROBLEM: Combine character analysis with *alankar* (literary device) — a 5-mark competency question: "Analyze how Bihari's use of *upama* (simile) in stanza 2 deepens our understanding of the nayika's *viraha*." Requires integrating c12_hin_a_cbse_07_008 (Imagery and Metaphor) with this node.

STEPS:
- Step 1: Locate the *upama* in stanza 2 — "fgoapy cw<+h" (withered like a dried creeper) and "jdr <jk ek¡lw xjk" (burning like fire).
- Step 2: Identify the *upamana* (vehicle) and *upameya* (tenor) for each: creeper → nayika's body; fire → nayika's *viraha*.
- Step 3: Analyze the *similarity ground* (sadharmya): Creeper = once green, now dry, rootless, at mercy of wind — nayika = once vibrant, now desiccated by separation, dependent on nayak's return. Fire = consumes fuel, self-sustaining heat — *viraha* = consumes the body, generates its own heat ("jdr").
- Step 4: Explain the *deepening*: Literal description ("body trembles") tells *what happens*; *upama* tells *what it means* — the nayika is *uprooted* (creeper) and *self-consuming* (fire). This moves analysis from *observation* to *interpretation*.
- Step 5: Conclude: The similes transform the nayika from a woman-in-pain to a *cosmic principle* — *viraha* as elemental force.
- Step 6: Write the final answer in 5 crisp sentences for 5 marks.

REASONING: Competency questions (NEP 2020) test *inter-conceptual linking*. This problem forces the student to use *alankar* knowledge (sibling node) to *illuminate character* (this node) — exactly what "critical thinking" (c12_hin_a_cbse_07_013) demands. The 6-step chain ensures no leap from device to meaning.

ANSWER: Bihari do upamayen prayog karte hain: "fgoapy cw<+h" (sookha hua bel) aur "jdr <jk ek¡lw xjk" (aag jaisa jalna). Pehli upama nayika ko 'uprooted' dikhati hai — bel ki tarah vah apne mool (nayak) se kat kar sookh rahi hai. Doosri upama viraha ko 'self-consuming energy' banati hai — aag ki tarah vah khud ko hi jala kar roshni deti hai. Ye upamayen nayika ke sharirik lakshan ko darshanik arth dete hain: vah keval dukhiyari nahin, viraha ki swabhavik shakti hain. Is prakar alankar charitra ko 'vyakti' se 'tatva' tak uthate hain.

## COMPETENCY_QUESTION_1
QUESTION: A student writes: "The nayika in *ckjgeklk* is very strong because she survives three harsh seasons." Using the concept of *viraha* as *sthayi bhava* (not personality trait), explain why this answer would lose marks in CBSE evaluation. Rewrite the answer correctly in 50 words.

COMPETENCY: Critical evaluation of peer response / Metacognitive correction

STEPS:
- Step 1: Identify the error — "strong" and "survives" impose modern psychological resilience on a *ritikaleen* nayika.
- Step 2: Recall the theoretical corrective: *viraha* is not an experience she *has*; it is what she *is* (sthayi bhava).
- Step 3: Explain the marking consequence: CBSE rubric for "character analysis in *ritikavya*" requires *typological language* (*virahotkanthita*, *anubhava*), not trait adjectives.
- Step 4: Rewrite using correct vocabulary: "The nayika embodies *viraha* through three seasonal *anubhavas* — her body enacts separation's progression from expression (stanza 1) to tremor (stanza 2) to desiccation (stanza 3)."

ANSWER: The original answer imposes "strength" (personality trait) on a *lakshana-granth* character defined by *bhava*. In *ritikavya*, the nayika *is viraha* — her body is its *anubhava*. Correct version: "The nayika manifests *viraha* through three seasonal *anubhavas*: expressive suffering in rain (stanza 1), physiological tremor in winter (stanza 2), and bodily desiccation in summer (stanza 3) — tracing *vipralambha shringara*'s deepening arc."

DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: Design a 4-question interview for the nayika of *ckjgeklk* that a talk-show host might ask — but each question must reveal a specific *rasa-shastra* concept (*vibhava, anubhava, vyabhichari bhava, sthayi bhava*) through her answers. Write the questions only.

COMPETENCY: Creative application of theoretical framework / Interdisciplinary synthesis (Literature + Rasa theory)

STEPS:
- Step 1: Map the four *rasa* components to interview angles: *vibhava* (determinant) → cause; *anubhava* (consequent) → bodily sign; *vyabhichari* (transitory) → fleeting feeling; *sthayi* (permanent) → core identity.
- Step 2: Draft Question 1 (*vibhava*): "What moment made this waiting begin?" — elicits the *alambana vibhava* (nayak's absence).
- Step 3: Draft Question 2 (*anubhava*): "Your body speaks — what is it saying tonight?" — elicits *kampa, sveda, ashru* etc. from the stanzas.
- Step 4: Draft Question 3 (*vyabhichari*): "Between the cold and the heat, what feelings come and go?" — elicits *chinta, glani, autsukya* etc.
- Step 5: Draft Question 4 (*sthayi*): "If *viraha* had a face, would it be yours?" — elicits the *sthayi bhava* as identity.
- Step 6: Verify each question is answerable *only* from the poem's textual evidence — no invention.

ANSWER:
1. "Vah kaun sa pal tha jab aapka 'viraha' shuru hua — kya nayak ke jaane ka, ya kisi anya karan ka?" (*Alambana vibhava*)
2. "Aaj raat sheet mein aapka sharir kanp raha hai — ye kampan kya kehna chahta hai?" (*Anubhava*)
3. "Varsha se grishma tak, beech mein kaun si bhavnayein aayi-gayi — chinta, glani, asha?" (*Vyabhichari bhava*)
4. "Agar 'viraha' ko roop dena pade, kya vah aapka hi chehra hoga?" (*Sthayi bhava*)

DIFFICULTY: hard