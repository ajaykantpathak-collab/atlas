## DEFINITION
Plot and narrative structure refers to the deliberate arrangement of events in a story—exposition, rising action, climax, falling action, and resolution—and the techniques (chronology, pacing, perspective) used to organize them. In "तेंदुए का शिशु," Renu employs a linear chronological structure where bureaucratic obstacles create the rising action, and the mother leopard's instinctual return forms the climax.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student can independently map the five stages of Freytag's pyramid onto the story with specific textual evidence, explain how the repetition of bureaucratic encounters functions as a structural device, and articulate why the linear chronology serves the theme of nature versus administration.

## SCOPE_BOUNDARY
This node covers plot architecture of "तेंदुए का शिशु" including: five-act structure mapping, narrative pacing through dialogue-driven bureaucratic scenes, structural parallelism between forest department and police encounters, and how chronology builds tension. It does NOT cover character psychology (node 004, 005), thematic analysis (nodes 006, 007), setting (node 003), or literary devices (nodes 008, 009).

## WALKTHROUGH
Imagine you find a lost child at a railway station and call the police, but they say "file a report at Platform 3, then get it stamped at the Superintendent's office, then bring it back"—by the time you finish, the child's mother has already found them. This story works exactly like that. Begin by listing every scene where an official refuses or delays help: the forest guard, the ranger, the police, the superintendent. Notice how each refusal repeats the same pattern—rules cited, forms demanded, jurisdiction claimed. That repetition IS the plot structure. The climax isn't a fight or chase; it's the mother leopard bypassing the entire system. The resolution comes when bureaucracy is circumvented, not satisfied. Your key insight: in this story, structure mimics the very bureaucracy it critiques—circular, repetitive, and ultimately overcome by instinct.

## DIAGNOSTIC_QUESTION_1
What are the five stages of Freytag's pyramid (plot structure) in their correct order?

## DIAGNOSTIC_ANSWER_1
Exposition → Rising Action → Climax → Falling Action → Resolution. A wrong answer (e.g., putting climax before rising action, or omitting falling action) reveals the student memorized terms but doesn't understand their causal sequence: each stage *causes* the next. In this story, the exposition (cub found) *causes* rising action (bureaucratic delays) which *causes* climax (mother's return).

## DIAGNOSTIC_QUESTION_2
In "तेंदुए का शिशु," the forest guard, ranger, and police officer all refuse immediate help. How does this repetition function structurally—why doesn't the author just show one refusal?

## DIAGNOSTIC_ANSWER_2
Each refusal escalates the institutional hierarchy (guard → ranger → police → superintendent), widening the bureaucratic net and raising stakes. A single refusal would show indifference; the *sequence* shows a *system* designed to delay. A wrong answer ("to make the story longer" or "to show different characters") misses that structure *is* the critique: the plot's rising action *is* the bureaucracy expanding.

## DIAGNOSTIC_QUESTION_3
Map the following events to Freytag's stages: (a) Mother leopard appears at the tea garden, (b) Cub discovered under the bush, (c) Forest guard cites rules and refuses to act, (d) Superintendent permits shooting the mother instead of releasing cub, (e) Cub returned to mother, bureaucracy bypassed.

## DIAGNOSTIC_ANSWER_3
(b) Exposition — cub discovered, initial situation established. (c) Rising Action begins — first bureaucratic obstacle. (d) Rising Action peaks — highest authority gives cruelest order (shoot mother). (a) Climax — mother leopard arrives, natural instinct confronts administrative power. (e) Falling Action + Resolution — cub returned, system circumvented. Wrong mapping (e.g., calling (d) the climax) reveals confusion between *highest tension* (climax) and *highest bureaucratic absurdity* (which sets up the climax).

## DIAGNOSTIC_QUESTION_4
Compare the forest department encounter (pages 91-93) and the police encounter (pages 94-95). How does the narrative structure use *parallelism* between these two sequences?

## DIAGNOSTIC_ANSWER_4
Both sequences follow: Official arrives → cites rules/jurisdiction → demands paperwork → delays action → mother leopard's presence forces confrontation → official relents or is bypassed. The parallelism structures the rising action as *escalating institutional failure*: forest dept (local) fails → police (higher) fails → superintendent (highest) orders violence. A wrong answer listing only surface similarities ("both have officers") misses that structural parallelism *accelerates* the plot toward climax by showing no level of bureaucracy works.

## DIAGNOSTIC_QUESTION_5
The story uses strict linear chronology—no flashbacks, no parallel plots. Evaluate: does this structural choice strengthen or weaken the theme of "nature versus bureaucracy"? Justify.

## DIAGNOSTIC_ANSWER_5
Strengthens. Linear chronology mirrors bureaucratic *process* (step 1, step 2, step 3) and makes the reader experience the same frustrating delay as the characters. The mother leopard's arrival *only at the end* creates maximum tension because we've endured every bureaucratic minute. A non-linear structure (e.g., starting with mother's arrival) would relieve tension prematurely and center human perspective. Wrong evaluation ("weakens because it's slow") confuses *pacing* with *structure*; the slowness *is* the structural point.

## DIAGNOSTIC_QUESTION_6
Rewrite the story's resolution (last 2 pages) from the mother leopard's perspective, using *non-linear* structure: start with her reunion with the cub, then flash back to her wait. Keep the same events but change the narrative structure.

## DIAGNOSTIC_ANSWER_6
A strong answer opens with sensory reunion (smell, touch, sound), then fragments backward: the long night watching, the gunshot fear, the human voices arguing, the cub's cry guiding her. It uses present tense for reunion, past for flashbacks. A weak answer merely reorders events without *structural purpose*—e.g., starting at the end but still telling it chronologically. This reveals the student doesn't grasp that structure *shapes meaning*, not just sequence.

## COMMON_MISCONCEPTION
Students equate "plot" with "what happens" (summary) and "structure" with "beginning-middle-end" (vague). They miss that **repetition is a structural choice**: the three bureaucratic refusals (forest guard, ranger, police) aren't "more plot"—they're a *pattern* that builds the rising action. They also think the climax is "the cub is saved" rather than "the mother leopard arrives," confusing *outcome* with *turning point*. This error stems from middle-school teaching that reduces plot to a list of events rather than a causal chain shaped by authorial design.

## ON_FAILURE
1. Show a 2-minute clip from a familiar film (e.g., *3 Idiots*: Virus's repeated "no" to Joy Lobo's project → escalating to Director → climax at delivery). Map it to Freytag together. 2. Give the student a 6-panel storyboard template. Have them draw *only* the bureaucratic refusal scenes (guard, ranger, police, superintendent) — one panel each. 3. Ask: "What changes in each panel? What stays the same?" Guide them to see: hierarchy rises, wording repeats, outcome repeats. 4. Then add Panel 5: Mother leopard arrives. Panel 6: Cub goes to her. Now they *see* the structure.

## BUILDS_ON
c11_hin_ar_cbse_07_001 (Context and Background) — provides author's biographical context (Renu's administrative experience) and historical setting (colonial tea gardens) essential to understanding why bureaucracy is the antagonist.

## LEADS_TO
c11_hin_ar_cbse_07_003 (Setting and Atmosphere) — the tea garden's physical layout (bushes, bungalows, office) structures character movement; c11_hin_ar_cbse_07_004 (Character Analysis: Protagonist) — the mother leopard's actions *are* the climax; c11_hin_ar_cbse_07_006 (Theme: Primary Theme) — structure *enacts* the theme.

## PREREQUISITE_NODE_IDS
c11_hin_ar_cbse_07_001
## PREREQUISITE_REASONS
c11_hin_ar_cbse_07_001: Provides essential context on Renu's administrative background and colonial tea garden setting, without which the bureaucratic antagonist and its structural role cannot be understood.

## FORWARD_NODE_IDS
c11_hin_ar_cbse_07_003, c11_hin_ar_cbse_07_004, c11_hin_ar_cbse_07_006, c11_hin_ar_cbse_07_005, c11_hin_ar_cbse_07_007, c11_hin_ar_cbse_07_008, c11_hin_ar_cbse_07_010, c11_hin_ar_cbse_07_011, c11_hin_ar_cbse_07_012, c11_hin_ar_cbse_07_013, c11_hin_ar_cbse_07_014, c11_hin_ar_cbse_07_015, c12_hin_a_cbse_09_002, c12_hin_ar_cbse_07_002

## FORWARD_REASONS
c11_hin_ar_cbse_07_003: Plot movement is constrained by tea garden geography (bushes, office, bungalow) — setting *structures* the action. c11_hin_ar_cbse_07_004: The mother leopard's off-stage journey *is* the structural climax; analyzing her as protagonist requires plot mapping first. c11_hin_ar_cbse_07_006: The theme "nature vs bureaucracy" is enacted *through* structure (repetition = bureaucracy, instinct = climax).
c11_hin_ar_cbse_07_005: Establishes plot sequence so students know *when* each supporting character enters/exits.  
c11_hin_ar_cbse_07_007: Plot and narrative structure mastery allows the student to map thematic beats onto specific structural turns (exposition, jurisdictional conflict, climax, resolution).  
c11_hin_ar_cbse_07_008: Students need the plot sequence (tree planted → nest discovered → bureaucratic debate → tree saved by protocol) and character roles (officers, bird, governor's letter) to locate where imagery/metaphor appear and what narrative work they do.  
c11_hin_ar_cbse_07_010: Plot knowledge locates *where* each word appears (e.g., "rkTtqc" only in the climax dialogue).  
c11_hin_ar_cbse_07_011: Plot knowledge supplies the factual content needed for the lk{kkRdkj (factual description) exercise.  
c11_hin_ar_cbse_07_012: Plot structure provides the event timeline; literal questions often target specific plot points.  
c11_hin_ar_cbse_07_013: Plot/structure knowledge provides the event sequence to analyze.  
c11_hin_ar_cbse_07_014: Plot structure knowledge required to select relevant textual evidence  
c11_hin_ar_cbse_07_015: Plot/narrative structure provides the sequence of events participants must reference accurately  
c12_hin_a_cbse_09_002: Explored secondary themes through structural parallels.  
c12_hin_ar_cbse_07_002: अगला तार्किक चरण: Plot and Narrative Structure in this chapter refers to the organization of events in the selected ep... इस नोड की अवधारणाओं को सीधे उपयोग/विस्तारित करता है।  
c11_hin_ar_cbse_07_004: Plot structure knowledge lets students pinpoint the protagonist's entry, conflict moments, and climax.  
c11_hin_ar_cbse_07_006: Plot structure provides the sequence of conflicts and resolutions needed to trace the theme.  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
No prior class nodes available for Hindi Aroh.

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_07_001 -> c11_hin_ar_cbse_07_002 -> c11_hin_ar_cbse_07_003

## THIS_FORMULA
Freytag's Pyramid applied to "तेंदुए का शिशु": Exposition (cub discovered) → Rising Action (bureaucratic refusals at 4 escalating levels) → Climax (mother leopard's arrival) → Falling Action (cub released) → Resolution (bureaucracy circumvented).

## FORMULA_VARIABLES
N/A - conceptual

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
analytical

## CROSS_SUBJECT
c11_polity_bureaucracy | The story's depiction of forest department, police, and administrative hierarchy mirrors real bureaucratic structures studied in Political Science — rules, jurisdiction, file movement, and the gap between policy and ground reality.
c11_geography_human_environment | Tea garden setting and human-wildlife conflict reflects geographical concepts of human-environment interaction in plantation regions — habitat fragmentation, edge effects, and administrative boundaries overriding ecological ones.

## PREREQ_CONCEPT
Understanding of basic story elements (beginning, middle, end) and cause-effect relationships from earlier classes.

## PREREQ_BEFORE
Student should have read the complete story "तेंदुए का शिशु" and can recall the basic sequence: cub found → officials called → mother arrives → cub returned.

## PREREQ_STUCK
If stuck, review the story summary in c11_hin_ar_cbse_07_001 and identify the main conflict: human bureaucracy (rules, hierarchy, delay) versus natural instinct (immediate, direct, effective).

## WORKED_EXAMPLE_1
PROBLEM: Map the complete plot of "तेंदुए का शिशु" onto Freytag's five stages, citing one specific textual moment for each stage.

STEPS:
- Step 1: Identify the exposition — the opening situation before conflict. In the story, the leopard cub is discovered under a bush in the tea garden (page 91: "तेंदुए का एक शिशु... झाड़ी में पड़ा मिला"). This establishes the normal world disrupted.
- Step 2: Trace the rising action through *each* bureaucratic encounter. First, the forest guard cites rules and refuses (page 91: "नियम है... बिना इजाजत नहीं छू सकते"). Second, the ranger demands written permission (page 92). Third, the police officer insists on jurisdiction (page 94: "यह वन विभाग का मामला है"). Fourth, the superintendent orders shooting the mother (page 95). Each escalates authority and cruelty.
- Step 3: Locate the climax — the turning point where tension peaks and direction changes. The mother leopard appears at the garden edge (page 97: "एक तेंदुआ... झाड़ी के पास आ खड़ा हुआ"). This is the climax because natural force confronts administrative power directly.
- Step 4: Identify falling action — events after climax moving toward resolution. The officials, fearing consequences, allow the cub to be taken to the mother (page 98: "शिशु को ले जाकर... झाड़ी के पास रख दिया").
- Step 5: State the resolution — the new equilibrium. The mother takes the cub and leaves; bureaucracy is bypassed, not satisfied (page 98: "तेंदुआ शिशु को दबोचकर... चला गया"). The system did not work; instinct did.

REASONING: This mapping works because it follows *causal chain*, not just chronological list. Each bureaucratic refusal *causes* the next higher authority to be called, escalating until nature intervenes. The climax is not "cub saved" but "mother arrives" because that moment *forces* the resolution.

ANSWER: Exposition: Cub discovered in tea garden bush. Rising Action: Four escalating bureaucratic refusals (guard → ranger → police → superintendent). Climax: Mother leopard appears at garden edge. Falling Action: Officials permit cub's release to mother. Resolution: Mother takes cub; bureaucracy circumvented.

## WORKED_EXAMPLE_2
PROBLEM: Analyze how dialogue drives plot progression in the bureaucratic scenes (pages 91-95). Select three dialogue exchanges and explain how each advances the plot structurally.

STEPS:
- Step 1: Select Exchange 1 — Forest guard to mother (page 91): "नियम है... बिना इजाजत नहीं छू सकते." This establishes the *first structural barrier*: rules over life. Plot moves from discovery to obstacle.
- Step 2: Select Exchange 2 — Ranger to mother (page 92): "लिखित आदेश लाइए... तब कुछ कर सकते हैं." This *escalates* the barrier: now paperwork is required, adding time delay. Plot moves from verbal refusal to procedural trap.
- Step 3: Select Exchange 3 — Superintendent's written order (page 95): "यदि शिशु नहीं दिया जा सकता तो मादा तेंदुए को गोली मार दी जाए." This is the *peak of rising action*: bureaucracy now mandates violence. Plot reaches maximum institutional absurdity.
- Step 4: Analyze structural function: Each exchange follows the pattern — Authority cites rule → Demands compliance → Delays action. The repetition *is* the rising action. No new information is given; the *structure* builds tension through frustration.
- Step 5: Connect to climax: The mother leopard's silent arrival (no dialogue) *breaks* the dialogue pattern. Structure shifts from human talk to animal action.

REASONING: In this story, dialogue *is* bureaucracy — formal, rule-bound, evasive. The plot advances not through what characters *do* but through what they *say to avoid doing*. The climax's silence contrasts structurally with the dialogue-heavy rising action.

ANSWER: Three key exchanges: (1) Guard cites rules — establishes barrier. (2) Ranger demands written order — escalates to procedural trap. (3) Superintendent orders shooting mother — peaks at institutional cruelty. Each follows pattern: rule → demand → delay. The mother's silent arrival breaks the pattern, structurally marking the climax.

## WORKED_EXAMPLE_3
PROBLEM: The story has two institutional sequences: Forest Department (pages 91-93) and Police/Administration (pages 94-95). Compare their structural parallelism and explain how the second sequence *intensifies* the first.

STEPS:
- Step 1: Map Forest Department sequence: Guard (local) → Ranger (middle) → both cite rules → both demand paperwork → both refuse action → mother leopard's presence forces guard to act.
- Step 2: Map Police/Administration sequence: Police officer (higher jurisdiction) → Superintendent (highest) → both cite jurisdiction → both demand procedure → Superintendent orders violence → mother leopard's presence forces compliance.
- Step 3: Identify parallel elements: (a) Official arrives, (b) Cites rule/jurisdiction, (c) Demands procedure, (d) Refuses immediate help, (e) Mother leopard's proximity forces change.
- Step 4: Analyze intensification: Forest dept = local, rule-bound, passive. Police/Admin = higher authority, jurisdictional, *active cruelty* (shoot order). The stakes rise from "delay" to "death."
- Step 5: Analyze structural purpose: The parallelism creates *rhythm* — the reader expects the pattern, knows it will fail, feels the inevitability. The second sequence *must* be worse, or the pattern would be mere repetition, not escalation.
- Step 6: Connect to theme: Structure enacts "bureaucracy expands to fill the space available" — each level adds more rules, less humanity.

REASONING: Structural parallelism with escalation is a classic narrative technique (like three fairy tale trials). Here, the "trials" are bureaucratic levels. The second sequence isn't a copy — it's a *variation* that raises stakes from procedural to lethal, making the mother's instinctual intervention the *only* possible resolution.

ANSWER: Both sequences follow: Official → Rule citation → Procedure demand → Refusal → Mother's presence forces action. Second sequence intensifies: Forest dept (local, passive delay) → Police/Admin (higher, active cruelty via shoot order). Parallelism creates reader expectation of failure; escalation makes mother's arrival the *only* structural exit.

## COMPETENCY_QUESTION_1
QUESTION: In "तेंदुए का शिशु," the author could have condensed the four bureaucratic refusals into one scene. Why does he choose to show each separately, and how does this structural choice shape the reader's experience of the theme? Answer with reference to at least two specific refusals.

COMPETENCY: Analyzing narrative structure's relationship to theme

STEPS:
- Step 1: Identify the structural choice — four separate refusal scenes (guard, ranger, police, superintendent) instead of one composite scene.
- Step 2: Explain the effect of separation — each scene adds time, hierarchy, and procedural detail. The reader *lives through* the delay.
- Step 3: Connect to theme — bureaucracy is experienced as *process*, not moment. Separate scenes mimic the victim's experience: "first this office, then that office."
- Step 4: Use specific refusals — Guard's "नियम है" (rule as shield) vs Superintendent's "गोली मार दी जाए" (rule as weapon). The progression from passive to active cruelty is only visible *because* scenes are separate.

ANSWER: Separate scenes force the reader to endure bureaucratic time — each refusal adds a layer of hierarchy (local → regional → state) and shifts from passive rule-citing (guard: "नियम है") to active cruelty (superintendent: "गोली मार दी जाए"). Condensing them would make bureaucracy look like a single bad decision; separating them reveals it as a *system* where each level escalates inhumanity. The structure *enacts* the theme: bureaucracy expands, nature waits.

DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: The story uses strict linear chronology with no flashbacks or parallel narratives. Evaluate whether this structural choice is the *most effective* for the theme of "institutional failure versus natural instinct." Consider an alternative structure (e.g., starting in media res with the mother leopard's arrival, then flashing back) and argue why Renu's choice is superior or inferior.

COMPETENCY: Evaluating narrative structure effectiveness

STEPS:
- Step 1: State Renu's choice — strict linear chronology from cub discovery to mother's departure.
- Step 2: Analyze its effect — reader experiences bureaucratic delay in real time; tension builds through accumulation; mother's arrival is *earned* surprise.
- Step 3: Propose alternative — in media res opening with mother at garden edge, then flashbacks to bureaucratic scenes.
- Step 4: Evaluate alternative — would center human drama (officials arguing) and make mother's arrival a *given*, not a climax. Would relieve tension of "will she come in time?"
- Step 5: Judge superiority — Linear is superior because it aligns reader's frustration with characters', makes bureaucracy the *protagonist* of the first 90% of the story, and lets instinct *rupture* the structure. Alternative would domesticate the wild ending.

ANSWER: Linear chronology is superior. It forces the reader to endure the same procedural purgatory as the characters — each refusal lands with cumulative weight. An in media res opening would frame the mother's arrival as backstory payoff rather than structural rupture. The theme "instinct vs institution" requires institution to *occupy the narrative space* first; only linear structure lets bureaucracy dominate 90% of the text so that the final 10% (mother's arrival) feels like a structural breakthrough, not just a plot point.

DIFFICULTY: hard