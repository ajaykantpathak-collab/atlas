## DEFINITION
Literal comprehension questions require students to retrieve explicitly stated information from the text (facts, details, sequence of events), while inferential comprehension questions demand logical deduction of implicit meaning by combining textual evidence with contextual knowledge (character motives, thematic implications, authorial intent).

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student can independently distinguish between literal and inferential question types, locate precise textual evidence for literal answers, and construct a 3-step inferential chain (evidence → reasoning → conclusion) for implicit questions, scoring 80%+ on unseen passages from the chapter.

## SCOPE_BOUNDARY
Covers literal (fact-based) and inferential (reasoning-based) comprehension questions specific to "टकेसुर का इमली" (Chapter 7, Aaroh). Does NOT cover critical analysis, creative writing, or grammar exercises, which are addressed in sibling nodes 013, 014, 015.

## WALKTHROUGH
Imagine you are a detective arriving at the village square where the ancient tamarind tree stands. The officials (literal facts) give you the written order to cut it, but the old poet (inferential layer) whispers that the tree holds the village's soul. To solve the case, you first note down every visible order, name, and date (literal). Then you ask: *Why does the poet risk his life? What does the tree symbolize beyond wood?* You connect the poet's songs, the officials' hesitation, and the historical decree to infer the theme of cultural memory versus bureaucratic indifference. The key insight: literal questions are the fingerprints; inferential questions are the motive.

## DIAGNOSTIC_QUESTION_1
Identify the official designation of the character who first orders the tree to be cut in the story.

## DIAGNOSTIC_ANSWER_1
Correct Answer: The District Magistrate (जिलाधिकारी / कलेक्टर) orders the tree to be cut initially. A wrong answer (e.g., "the engineer" or "the mother") reveals the student cannot distinguish between the issuing authority and the executing agents, indicating weak literal retrieval of hierarchical roles in the narrative.

## DIAGNOSTIC_QUESTION_2
Explain in your own words why the old man (नछ गकवक वकनेह) refuses to leave the tree even when threatened with death.

## DIAGNOSTIC_ANSWER_2
Correct Answer: The old man identifies himself as a poet whose life's work (songs, poems) is inseparable from the tree; the tree is the physical anchor of his creative identity and the village's collective memory. A wrong answer focusing only on "stubbornness" or "fear of death" shows the student treats the character as a flat plot device rather than inferring the symbolic fusion of artist, art, and habitat.

## DIAGNOSTIC_QUESTION_3
The mother (एकी) says: "वपंक गकवक रुक एगक्जस औवक्जर िज फजक, वक्सज देज िज फजरक रक्स झ<+ ध गह ववव तकरह।" What literal danger does she describe, and what inferential warning about the tree's roots does she imply?

## DIAGNOSTIC_ANSWER_3
Correct Answer: Literal: If the tree falls on the road, a big accident will occur. Inferential: The tree's roots have spread under the road, so cutting it destabilizes the road itself—nature and infrastructure are entangled. A wrong answer that only states the literal danger misses the ecological/structural inference, showing inability to read spatial causality in the text.

## DIAGNOSTIC_QUESTION_4
Compare the responses of the Engineer (इककफजावसामसाव) and the District Magistrate (जिलाधिकारी) when they learn the tree was planted by a former ruler. What does this contrast reveal about their respective relationships to authority?

## DIAGNOSTIC_ANSWER_4
Correct Answer: The Engineer immediately halts work citing departmental jurisdiction, showing rigid procedural compliance. The Magistrate investigates and transfers the decision to the Forest Department, revealing political pragmatism. The contrast infers that bureaucracy follows rules, while administration negotiates power—both fail to value the tree intrinsically.

## DIAGNOSTIC_QUESTION_5
Evaluate the statement: "The story portrays the government machinery as entirely heartless." Defend your judgment using two specific textual episodes.

## DIAGNOSTIC_ANSWER_5
Correct Answer: The statement is partially false. Episode 1: The Magistrate *does* halt cutting when historical significance emerges, showing procedural humanity. Episode 2: The Forest Department officer saves the tree by invoking a higher ecological law. The machinery is rigid, not heartless—it responds to legal/historical frameworks, not emotional appeals. A student calling it wholly heartless fails to evaluate nuance in institutional behavior.

## DIAGNOSTIC_QUESTION_6
Write a 50-word diary entry from the perspective of the tamarind tree on the night before the Forest Officer arrives, blending literal sensory details from the text with an inferred emotional voice.

## DIAGNOSTIC_ANSWER_6
Expected criteria: Must include (a) literal detail: "roots under the road," "birds' nests," "poet's songs"; (b) inferred voice: ancient witness, quiet resilience, fear of saws. Poor answer: generic "I am scared" without textual anchors. Good answer: "Tonight my roots tremble under the asphalt; the poet's verses rustle in my leaves like prayers. The saws paused today—will the green seal hold?"

## COMMON_MISCONCEPTION
Students treat *every* "Why?" question as inferential and *every* "What?" question as literal. In this chapter, "Why did the mother warn about the road?" is literal (text states the reason explicitly), while "What does the tree represent?" is inferential (requires synthesis of poet's songs, history, and ecology). The error stems from equating question *form* with cognitive *demand* rather than analyzing whether the answer resides in a single sentence or requires cross-paragraph synthesis.

## ON_FAILURE
1. Give the student a two-column table: Column A = 5 explicit sentences from the text; Column B = 5 questions. Ask them to match each question to the *exact sentence* that answers it. 2. For unmatched questions, ask: "Which *two* sentences must you combine?" 3. Label each matched pair as L (literal) or I (inferential). 4. Repeat with a fresh paragraph until the student verbalizes the rule: "Literal = one sentence. Inferential = bridge between sentences."

## BUILDS_ON
c11_hin_ar_cbse_07_002 (Plot and Narrative Structure) – students must know the sequence of events before they can locate literal details or trace inferential threads.

## LEADS_TO
c11_hin_ar_cbse_07_013 (Critical Thinking: Analysis and Interpretation) – inferential comprehension is the scaffold for higher-order thematic analysis.

## PREREQUISITE_NODE_IDS
c11_hin_ar_cbse_07_001, c11_hin_ar_cbse_07_002, c11_hin_ar_cbse_07_004, c11_hin_ar_cbse_07_010, c11_hin_ar_cbse_07_011

## PREREQUISITE_REASONS
c11_hin_ar_cbse_07_001: Context/background knowledge (historical setting, administrative hierarchy) is essential to infer why officials behave as they do.
c11_hin_ar_cbse_07_002: Plot structure provides the event timeline; literal questions often target specific plot points.
c11_hin_ar_cbse_07_004: Protagonist analysis (the old poet) supplies character motives needed for inferential questions about his refusal to leave.
c11_hin_ar_cbse_07_010: Vocabulary in context (e.g., इककफजावसामसाव, गकडकडवइडजपजपवज) ensures students comprehend the literal meaning of key administrative terms.
c11_hin_ar_cbse_07_011: Comprehension questions often ask "Why does the author use this word/structure?" – requiring grammar/vocabulary analysis.  

## FORWARD_NODE_IDS
c11_hin_ar_cbse_07_013, c11_hin_ar_cbse_07_014, c11_hin_ar_cbse_07_015, c12_hin_ar_cbse_04_012, c12_hin_ar_cbse_07_012

## FORWARD_REASONS
c11_hin_ar_cbse_07_013: Critical thinking requires the evidence-gathering (literal) and reasoning (inferential) skills honed here.
c11_hin_ar_cbse_07_014: Writing answers (long/short) demands the PEEL structure practiced in this node's worked examples.
c11_hin_ar_cbse_07_015: Literal/inferential comprehension ensures factual accuracy in textual references  
c12_hin_ar_cbse_04_012: अगला तार्किक चरण: Literal comprehension is the ability to extract explicitly stated facts, details, and sequences dire... इस नोड की अवधारणाओं को सीधे उपयोग/विस्तारित करता है।  
c12_hin_ar_cbse_07_012: Class 11 comprehension practice with similar poems builds foundational skill.  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
No prior class nodes available for cross-subject linking in this Hindi Aaroh chapter.

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_07_002 -> c11_hin_ar_cbse_07_012 -> c11_hin_ar_cbse_07_013

## THIS_FORMULA
Inferential Answer = Textual Evidence (Quote/Paraphrase) + Contextual Knowledge (Historical/Cultural/Character) + Logical Bridge (Therefore/This implies)

## FORMULA_VARIABLES
Textual Evidence: Direct words or paraphrased action from the story. Contextual Knowledge: Background from node 001 (e.g., British-era tree, bureaucratic hierarchy). Logical Bridge: Explicit connective reasoning showing how evidence leads to conclusion.

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
analytical

## CROSS_SUBJECT
c11_history_colonial_administration | The story's conflict between a British-era tree and post-Independence road-widening mirrors History's theme of colonial legacy vs. modern development; inferential questions here parallel analyzing primary sources for bias.
c11_civics_bureaucracy_and_citizen | The layered official responses (Engineer → Magistrate → Forest Dept.) exemplify Civics' study of administrative procedure and citizen rights; literal questions map to "who does what," inferential to "why the system responds this way."

## PREREQ_CONCEPT
Ability to differentiate between explicitly stated information and implicitly suggested meaning in a narrative text.

## PREREQ_BEFORE
Student must have read the full story "टकेसुर का इमली" at least once and completed nodes 001, 002, 004, 010.

## PREREQ_STUCK
If stuck, re-read the "Before You Read" (node 001) for historical context and the "Vocabulary" (node 010) for administrative terms—these unlock 60% of literal blocks.

## WORKED_EXAMPLE_1
PROBLEM: Answer the inferential question: "Why does the poet (नछ गकवक वकनेह) say 'मेरी कविताओं का संबन्ध इस इमली से है' (My poems' relationship is with this tamarind) when the Magistrate offers compensation?"
STEPS:
- Step 1: Locate the literal scene – Magistrate offers money/land; poet refuses, citing the tree.
- Step 2: Retrieve character knowledge (node 004) – the poet's songs are *about* the tree, composed under it, inspired by its birds/shade.
- Step 3: Retrieve historical context (node 001) – tree planted by a former ruler; it is a living archive of local culture.
- Step 4: Construct the bridge – The tree is not property but *muse*; compensation replaces wood, not the creative ecosystem.
- Step 5: Formulate answer using the formula: Evidence (poet's dialogue) + Context (songs born here) + Bridge (art cannot be relocated like furniture).
REASONING: This models the 3-part inferential chain required for board answers: evidence → context → synthesis.
ANSWER: The poet refuses because his creative identity is rooted in the tree; the tree is the subject, setting, and inspiration of his poetry. Money or land cannot replicate the sensory and historical matrix that generates his art.

## WORKED_EXAMPLE_2
PROBLEM: A literal question asks: "List the three departments whose officials visit the site before the final decision." Write a board-style answer.
STEPS:
- Step 1: Scan the narrative for official designations in order of appearance.
- Step 2: Identify: (1) Public Works Department (engineer/supervisor), (2) Revenue/District Administration (Magistrate), (3) Forest Department (Range Officer).
- Step 3: Verify each has a distinct scene – PWD marks the tree, Magistrate hears the poet, Forest Officer saves the tree.
- Step 4: Format as a numbered list with precise Hindi designations: 1. लोक निर्माण विभाग (सहायक अभियंता), 2. जिला प्रशासन (जिलाधिकारी), 3. वन विभाग (रेंज ऑफिसर).
- Step 5: Check against marking scheme – one mark per correct department; no extra marks for elaboration.
REASONING: Literal questions reward precision and brevity; this trains students to extract only what is asked.
ANSWER: 1. लोक निर्माण विभाग (सहायक अभियंता), 2. जिला प्रशासन (जिलाधिकारी), 3. वन विभाग (रेंज ऑफिसर).

## WORKED_EXAMPLE_3
PROBLEM: "The story suggests that laws protect nature only when it serves human history." Evaluate this claim using two inferential chains from the text.
STEPS:
- Step 1: Deconstruct the claim into two propositions: (a) Laws protect nature. (b) Only when tied to human history.
- Step 2: Find evidence for (a) – Forest Officer invokes the Forest Conservation Act to stop cutting.
- Step 3: Find evidence for (b) – The *initial* stay came because the tree was planted by a former ruler (historical value), not ecological value.
- Step 4: Find counter-evidence – The poet argues for the tree's *intrinsic* worth (songs, birds, shade); the Forest Officer *also* cites ecological risk (roots under road).
- Step 5: Synthesize – The claim is partially true: the *first* legal intervention was history-based, but the *final* protection blends history + ecology.
- Step 6: Write evaluation: "The claim holds for the Magistrate's stay (historical precedent) but fails for the Forest Officer's order, which adds ecological reasoning (root-road stability). Thus, law here responds to both history and science."
REASONING: Combines literal retrieval (Act names, officer roles) with dual inferential threads (history vs. ecology) – a 4-mark board pattern.
ANSWER: The claim is partially correct. The first legal halt (Magistrate) relied solely on the tree's historical planting by a former ruler. However, the final protection (Forest Officer) invoked the Forest Conservation Act *and* cited the tree's ecological role in stabilizing the road. Law ultimately responded to both human history and natural science.

## COMPETENCY_QUESTION_1
QUESTION: A Class 11 student writes this answer to "Why did the mother warn the poet about the road?": "Because she loved her son and didn't want him to die." Identify the comprehension error and rewrite the answer to score full marks.
COMPETENCY: Error diagnosis and answer restructuring (literal vs. inferential confusion)
STEPS:
- Step 1: Identify the question type – "Why did the mother warn..." targets the *content* of her warning, not her motive.
- Step 2: Locate the literal text – Mother says: "If the tree falls on the road, a big accident will happen."
- Step 3: Note the student's error – They answered an inferential *motive* question (love/fear) for a literal *content* question.
- Step 4: Rewrite using literal evidence only: "The mother warned that if the tree fell on the road, a major accident would occur because its roots had spread under the road."
ANSWER: Error: The student inferred emotional motive (love/fear) instead of retrieving the explicitly stated physical danger (tree falling on road → accident). Correct answer: The mother warned that the tree's roots had spread under the road; if it fell, it would cause a major accident on the highway.
DIFFICULTY: easy

## COMPETENCY_QUESTION_2
QUESTION: "The conflict in 'टकेसुर का इमली' is not between man and nature, but between two human systems." Defend or refute this statement using three textual anchors (literal) and two inferential links.
COMPETENCY: Thematic synthesis with evidence grading (literal anchoring + inferential weaving)
STEPS:
- Step 1: Identify the two systems – Bureaucratic development (PWD, Magistrate) vs. Cultural-ecological memory (Poet, Villagers, Forest Act).
- Step 2: Anchor 1 (literal) – PWD marks tree for road widening (development system).
- Step 3: Anchor 2 (literal) – Magistrate stays order citing historical planting (administrative system responding to history).
- Step 4: Anchor 3 (literal) – Forest Officer invokes Forest Conservation Act (legal-ecological system).
- Step 5: Inferential link 1 – The poet never opposes the road; he opposes *erasure of memory*. Nature is the medium, not the antagonist.
- Step 6: Inferential link 2 – The systems clash *through* the tree; the tree is the contested site, not an active combatant.
- Step 7: Conclude – Statement defended: Conflict is inter-systemic (development vs. heritage/ecology), mediated by nature.
ANSWER: The statement is defensible. Three literal anchors: (1) PWD's road-widening order, (2) Magistrate's historical-precedent stay, (3) Forest Officer's Conservation Act order. Two inferential links: (a) The poet defends cultural memory, not the tree as biology; (b) The tree is the silent locus where bureaucratic and ecological-legal systems negotiate. The antagonist is not nature but competing human frameworks of value.
DIFFICULTY: hard