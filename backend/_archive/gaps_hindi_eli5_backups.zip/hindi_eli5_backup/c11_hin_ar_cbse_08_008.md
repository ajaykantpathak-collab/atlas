## DEFINITION
Imagery (प्रतिबिंब/चित्रण) refers to the use of vivid, sensory language that appeals to the five senses (sight, sound, smell, touch, taste) to create mental pictures in the reader's mind. Metaphor (रूपक/उपमा) is a figure of speech that directly compares two unrelated things by stating one *is* the other, without using "like" or "as," to reveal a hidden similarity. In this chapter, both devices work together to transform abstract ideas like "nation" and "unity" into tangible, emotional experiences.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student must be able to independently identify at least three distinct images and two metaphors from the text, explain the sensory appeal of each image, unpack the tenor-vehicle relationship in each metaphor, and articulate how both devices collectively reinforce the central theme of unity in diversity.

## SCOPE_BOUNDARY
This node covers identification, analysis, and interpretation of imagery (visual, auditory, tactile, kinesthetic) and metaphor (simple, extended, implied) specifically within the prose text "Hkkjr ekrk" (Chapter 8). It does NOT cover irony, symbolism, personification, or other figures of speech addressed in node c11_hin_ar_cbse_08_009, nor does it cover poetic devices from poetry chapters.

## WALKTHROUGH
Imagine you are sitting in a train watching India rush past your window — the snow-capped Himalayas, the green paddy fields of Bengal, the arid deserts of Rajasthan, the bustling streets of Mumbai. The author, Tokanath Singh, does exactly this in the chapter: he takes you on a mental journey across India using words as his camera. To begin analyzing imagery and metaphor, first re-read the text with a highlighter in hand. Ask yourself: "Which sentences make me *see*, *hear*, or *feel* something physically?" Mark those — they are imagery. Then ask: "Where does the author say one thing *is* another to explain a complex idea?" For example, when he says "India Mother is the form of millions of people," he is not describing a statue; he is using a metaphor to redefine the nation. The key insight is that in this chapter, imagery builds the *physical reality* of India's diversity, while metaphor builds the *conceptual unity* that binds it — together, they make the abstract idea of "nation" feel as real as the soil under your feet.

## DIAGNOSTIC_QUESTION_1
Define "imagery" (प्रतिबिंब) and "metaphor" (रूपक) in your own words, giving one example of each from everyday language (not from the textbook).

## DIAGNOSTIC_ANSWER_1
Imagery is descriptive language that appeals to the senses (e.g., "The air smelled of wet earth and frying pakoras" — olfactory and gustatory imagery). Metaphor is a direct comparison without "like/as" (e.g., "Time is a thief" — time is not literally a thief, but it steals moments). A wrong answer that confuses metaphor with simile ("Time is *like* a thief") reveals the student does not grasp the *direct equation* at the heart of metaphor. A wrong answer that gives only visual imagery ("The sunset was red") reveals a narrow, sight-only understanding of imagery.

## DIAGNOSTIC_QUESTION_2
In the passage, the author writes: "rdyhI+ksaQ ,d&lh Fkhaµ;kuh xjhcksa] d"kZnkjksa] i¡wthifr;ksa osQ f'koaQts] "kehankj] egktu] dM+s yxku vkSj lwn] iqfyl osQ "kqYe" (From the snowy Himalayas to the southern seas...). Identify *three* distinct sensory images in this sentence and name the sense each appeals to. Why does the author pile up so many images in one sentence?

## DIAGNOSTIC_ANSWER_2
1. "Fkhaµ;kuh xjhcksa" (snowy peaks) — visual + tactile (cold). 2. "d"kZnkjksa] i¡wthifr;ksa osQ f'koaQts" (roar of rivers and forests) — auditory. 3. "dM+s yxku vkSj lwn" (thick snow and salt) — tactile + gustatory. The accumulation creates a *panoramic sweep* — it forces the reader to experience India's vast geography in a single breath, mirroring the author's own journey. A wrong answer that lists only visual images or misses the "piling up" technique shows the student sees words but not the *rhetorical purpose* of sensory density.

## DIAGNOSTIC_QUESTION_3
Apply the concept of "tenor" (subject) and "vehicle" (image used for comparison) to this metaphor from the text: "Hkkjr ekrk njvly ;gh djksM+ksa yksx gSa" (India Mother is verily millions of people). Identify the tenor, the vehicle, and the *ground* (shared quality). Then rewrite the metaphor as a simile and explain what is lost in the translation.

## DIAGNOSTIC_ANSWER_3
Tenor: "Hkkjr ekrk" (Mother India — the abstract concept of nation). Vehicle: "djksM+ksa yksx" (millions of people — concrete reality). Ground: Both are *living, breathing, collective entities* whose identity emerges from multiplicity. Simile version: "Mother India is *like* millions of people." What is lost: the *ontological claim* — the metaphor asserts identity ("is"), making the nation *constituted by* people, not merely *resembling* them. A wrong answer that swaps tenor/vehicle or cites "love" as the ground shows the student cannot distinguish the *structural logic* of metaphor from its emotional effect.

## DIAGNOSTIC_QUESTION_4
Analyze how the *extended metaphor* of "journey" (tylk/सफ़र) operates across the chapter. The author says: "vdlj tc eSa ,d tyls ls nwljs tyls esa tkrk gksrk] vkSj bl rjg pDdj dkVrk jgrk gksrk Fkk..." (Whenever I moved from one place to another...). Trace three stages of this journey-metaphor and explain how each stage deepens the reader's understanding of "unity."

## DIAGNOSTIC_ANSWER_4
Stage 1: Physical journey — train travel across regions (concrete movement). Stage 2: Intellectual journey — questioning people about "Bharat Mata" (seeking definition). Stage 3: Spiritual/epiphanic journey — realizing "I am India Mother" (internalization). Each stage peels a layer: geography → ideology → identity. The metaphor works because *movement* mirrors *understanding* — you cannot grasp unity by standing still. A wrong answer that lists places visited but misses the *progressive deepening* treats the journey as itinerary, not as a *structuring metaphor* for discovery.

## DIAGNOSTIC_QUESTION_5
Evaluate the effectiveness of the metaphor "fons'k rjDdh" (foreign rule/colonialism as a "demon/ogre") used implicitly when the author describes "vejhdk us oSQlh rjDdh dh gSA" (The British created that chaos). Does this metaphor clarify or obscure the historical reality of colonial exploitation? Justify with reference to the text's tone.

## DIAGNOSTIC_ANSWER_5
The metaphor *clarifies emotionally but obscures analytically*. "Rajdh" (demon) personifies colonialism as a singular malevolent agent, which matches the text's passionate, narrative tone and makes the injustice *viscerally* felt — aligning with the author's goal of awakening national consciousness. However, it *obscures* the structural, economic, and administrative mechanisms of exploitation (which the author elsewhere analyzes rationally). A strong evaluation acknowledges *both*: the metaphor serves the *rhetorical purpose* (mobilizing feeling) but fails the *explanatory purpose* (analyzing cause). A wrong answer that calls it "good" or "bad" without this dual lens shows binary thinking unsuited to literary analysis.

## DIAGNOSTIC_QUESTION_6
Create your own metaphor for "India" (not "Mother India") using a *concrete, everyday object* from an Indian kitchen or street. Write the metaphor, identify tenor/vehicle/ground, and explain why your chosen vehicle makes the abstract idea of "nation" accessible to a Class 11 student.

## DIAGNOSTIC_ANSWER_6
Example: "India is a *thali* — many distinct dishes in separate katoris, eaten together with the same hand." Tenor: India. Vehicle: Thali. Ground: Unity without uniformity; diversity held by a shared practice (eating together). This works for Class 11 because the thali is a *universal, tactile, daily experience* — not a lofty symbol. A poor answer uses a cliché ("India is a garden") without grounding the vehicle in *lived sensory reality*, showing the student cannot bridge abstraction and concreteness.

## COMMON_MISCONCEPTION
Students consistently confuse **imagery** with **metaphor** in this chapter because both create "pictures." They label *any* vivid description ("snowy peaks," "roaring rivers") as a metaphor, not realizing imagery *shows* while metaphor *equates*. For example, when the text says "fganqLrku osQ unh vkSj igkM+] taxy vkSj [ksr" (the warmth and depth of unity, heat and juice), students call this a metaphor for "unity's qualities." It is not — it is *tactile/gustatory imagery* describing unity's *felt texture*. The error stems from middle-school teaching that lumps all "figurative language" together without teaching the *mechanism*: imagery = sensory evocation; metaphor = cross-domain mapping (A is B).

## ON_FAILURE
Step 1: Give the student two side-by-side sentences from the text — one pure imagery ("dM+s yxku" — thick snow), one pure metaphor ("Hkkjr ekrk djksM+ksa yksx gS" — Mother India is millions of people). Step 2: Ask: "Which one makes you *feel cold*? Which one makes you *rethink what a nation is*?" Step 3: Explicitly name the mechanism: "Imagery = sensory trigger. Metaphor = conceptual transfer." Step 4: Have them re-read the chapter and color-code: yellow for imagery (label the sense), blue for metaphor (label tenor/vehicle). Step 5: Discuss *why* the author needs both — imagery grounds the metaphor in physical reality so the abstract claim feels earned.

## BUILDS_ON
Close reading of the text's plot, setting, and character (nodes 001-005) to locate where devices appear.

## LEADS_TO
Analysis of irony and symbolism (node 009), which require the same close-reading muscle but operate on *contrast* and *representation* rather than sensory evocation and equation.

## PREREQUISITE_NODE_IDS
c11_hin_ar_cbse_08_001, c11_hin_ar_cbse_08_002, c11_hin_ar_cbse_08_003, c11_hin_ar_cbse_08_007

## PREREQUISITE_REASONS
c11_hin_ar_cbse_08_001: Context/background knowledge (author's life, historical moment) is essential to understand *why* certain metaphors (e.g., "foreign rule as demon") carry specific political weight.
c11_hin_ar_cbse_08_002: Plot/narrative structure reveals the *journey framework* that organizes the extended metaphor of travel-as-discovery.
c11_hin_ar_cbse_08_003: Setting/atmosphere analysis trains the eye to spot sensory details (Himalayas, deserts, crowds) that constitute the chapter's imagery.
c11_hin_ar_cbse_08_007: Imagery and metaphor are the primary literary vehicles for secondary themes (e.g., geographical imagery for unity-in-diversity)  

## FORWARD_NODE_IDS
c11_hin_ar_cbse_08_009, c11_hin_ar_cbse_08_012, c11_hin_ar_cbse_08_013, c11_hin_ar_cbse_08_014, c12_hin_a_cbse_02_008, c12_hin_a_cbse_04_008, c12_hin_a_cbse_05_008, c12_hin_a_cbse_08_009, c12_hin_a_cbse_16_008, c12_hin_ar_cbse_08_008, c12_hin_ar_cbse_03_013

## FORWARD_REASONS
c11_hin_ar_cbse_08_009: Irony and symbolism build on the same close-reading skills but shift focus from *sensory/conceptual equivalence* (imagery/metaphor) to *gap between appearance/reality* (irony) and *object-as-meaning* (symbolism).
c11_hin_ar_cbse_08_012: Comprehension questions (literal/inferential) require identifying devices to answer "how does the author convey..." questions.
c11_hin_ar_cbse_08_013: Critical thinking/interpretation demands evaluating *why* the author chose these specific devices for this theme — the culmination of device analysis.
c11_hin_ar_cbse_08_014: Imagery/metaphor analysis provides literary device evidence for technique questions.  
c12_hin_a_cbse_02_008: Reinforcement in Class 11 Antra Chapter 8 (mid-course practice).  
c12_hin_a_cbse_04_008: Symbolic imagery in "Kavitavali" — bridge to symbolism in next node.  
c12_hin_a_cbse_05_008: Expands repertoire of sensory categories (kinesthetic, organic).  
c12_hin_a_cbse_08_009: Class 11 imagery/metaphor work builds the habit of moving from concrete to abstract.  
c12_hin_a_cbse_16_008: Links imagery to character psychology — essential for Lahko analysis.  
c12_hin_ar_cbse_08_008: Direct predecessor — covers basic definitions of imagery/metaphor, tenor/vehicle/ground, sensory modalities.  
c12_hin_ar_cbse_03_013: If stuck on device-function explanation: revisit Class 11 Chapter 8/9 Literary Devices nodes (c11_hin_ar_cbse_08_008, c11_hin_ar_cbse_08_009, c11_hin_ar_cbse_09_008, c11_hin_ar_cbse_09_009) and practice "device → effect → meaning" cha  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
none

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_08_001 -> c11_hin_ar_cbse_08_008 -> c11_hin_ar_cbse_08_009 (Context enables device identification; device analysis enables deeper rhetorical analysis)

## THIS_FORMULA
N/A - conceptual

## FORMULA_VARIABLES
N/A

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
linguistic

## CROSS_SUBJECT
c11_history_nationalism | The metaphor "Hkkjr ekrk = djksM+ksa yksx" (Mother India = millions of people) mirrors the historical shift from *territorial* to *popular* sovereignty in Indian nationalism — the same conceptual move Tagore and Gandhi debated.
c11_geography_unity_in_diversity | The cumulative imagery of "Fkhaµ;kuh xjhcksa" to "iqfyl osQ "kqYe" (Himalayas to southern seas) is a literary enactment of India's *physiographic diversity* — the text uses literary device to perform what geography describes as fact.

## PREREQ_CONCEPT
Tenor-Vehicle-Ground structure of metaphor (I.A. Richards' framework) and the five sensory modalities of imagery.

## PREREQ_BEFORE
Student must be able to distinguish literal from figurative language and name the five senses.

## PREREQ_STUCK
Review "figures of speech" basics from Class 9-10 Hindi grammar (अलंकार) — specifically the difference between *Rupak Alankar* (metaphor) and *Vyanjana* (suggestion/imagery).

## WORKED_EXAMPLE_1
PROBLEM: Analyze the imagery in this passage: "eSa mÙkj&ifPNe esa [kScj osQ njsZ ls ysdj èkqj nfD[ku esa dU;koqQekjh rd dh viuh ;k=kk dk gky crkrk" (I narrate my journey from the rugged hills of the northwest to the deep southern seas and Dhanushkodi). Identify the spatial imagery, the kinesthetic imagery, and explain how the *scale* of the journey functions as a visual metaphor for the *scope* of the author's inquiry.

STEPS:
- Step 1: Locate the spatial markers — "mÙkj&ifPNe" (northwest), "èkqj nfD[ku" (deep south), "dU;koqQekjh" (Dhanushkodi, southern tip). These create a *diagonal visual sweep* across the subcontinent.
- Step 2: Identify kinesthetic imagery — ";k=kk dk gky" (narrative of journey), "tkrk gksrk" (moving), "pDdj dkVrk" (wandering). The verbs enact *physical exertion* and *continuous motion*.
- Step 3: Note the sensory contrast — "[kScj osQ njsZ" (rugged hills) implies tactile hardness, cold; "èkqj nfD[ku" implies vastness, salinity, humidity. The imagery engages touch and temperature.
- Step 4: Analyze the metaphorical function — the *geographical span* (Kashmir to Kanyakumari) mirrors the *intellectual span* (simple villagers to complex political ideas). The journey's length = the inquiry's depth.
- Step 5: Connect to theme — this opening imagery establishes the *method*: unity is not found in books but by *traversing diversity bodily*. The map becomes the method.

REASONING: The steps move from literal identification (where/what) to sensory classification (which sense) to structural analysis (how it organizes the text) to thematic synthesis (what it means for the central idea). This mirrors the board exam expectation: "quote → identify device → explain effect → link to theme."

ANSWER: The passage uses diagonal spatial imagery (NW to SE) and kinesthetic verbs to enact a physical journey that *is* the intellectual method. The scale of the landscape mirrors the scope of the question "What is India?" — making the abstract inquiry tangible through sensory geography.

## WORKED_EXAMPLE_2
PROBLEM: Unpack the implied metaphor in: "vkf[kj ,d g^s&d^s tkV us] tks vufxur ihf<+;ksa ls fdlkuh djrk vk;k Fkk] tokc fn;k fd Hkkjr ekrk ls mudk eryc èkjrh ls gSA" (A sturdy farmer... said his connection to Mother India is through the land). Identify the tenor, vehicle, and ground. Then explain why the author chooses a *farmer* (not a scholar, soldier, or politician) as the voice for this metaphor.

STEPS:
- Step 1: Identify the metaphor — "Hkkjr ekrk ls mudk eryc èkjrh ls gS" (his relation to Mother India is through the land). Tenor: Relationship with nation. Vehicle: Relationship with land/soil. Ground: Both are *life-sustaining, generative, inherited bonds* that require nurture.
- Step 2: Analyze "g^s&d^s tkV" (sturdy/strong-built farmer) — this is *characterizing imagery* (visual + tactile) that makes the speaker credible. "vufxur ihf<+;ksa ls fdlkuh" (ploughing with bullocks) — occupational imagery, evoking smell of earth, sound of plough, rhythm of labor.
- Step 3: Contrast with alternative voices — A scholar would say "through history," a soldier "through defense," a politician "through Constitution." The farmer says "through *land*."
- Step 4: Evaluate the rhetorical choice — Land is the *most primordial, shared, tangible* basis of nationhood. It bypasses language, religion, caste. The farmer's voice *embodies* the metaphor: he doesn't just state it, he *lives* it.
- Step 5: Link to chapter's argument — This moment crystallizes the author's realization: "Hkkjr ekrk njvly ;gh djksM+ksa yksx gSa" (Mother India is verily millions of people). The farmer *is* one of those millions; his metaphor *proves* the author's thesis.

REASONING: The analysis moves from device identification to speaker characterization to comparative rhetoric to thematic proof. Board exams reward this layered reading: the device is not decorative — it *advances the argument*.

ANSWER: The metaphor equates nation-bond with land-bond (tenor/vehicle/ground = relationship/nurture/inheritance). The farmer is chosen because his *daily labor* makes the metaphor literal — he touches the nation every day. This grounds the abstract "Mother India" in the most concrete, universal, pre-political reality: soil.

## WORKED_EXAMPLE_3
PROBLEM: The author writes: "fganqLrku og lc oqQN gS] ftls mUgksaus le> j[kk gS] ysfdu og blls Hkh cgqr ";knk gSA fganqLrku osQ unh vkSj igkM+] taxy vkSj [ksr] tks gesa vUu nsrs gSa] ;s lHkh gesa v"kh"k gSaA ysfdu vkf[kjdkj ftudh fxurh gS] os gSa fganqLrku osQ yksx] muosQ vkSj esjs tSls yksx] tks bl lkjs ns'k esa iSQys gq, gSaA" (Unity is very simple... but it is also very deep. The warmth, depth, heat and juice of unity... are all ours. But those on whom its existence depends are the people of unity...). Trace how the *sensory imagery cluster* ("unh, igkM+, taxy, [ksr" — warmth, depth, heat, juice) prepares the reader for the *definitional metaphor* that follows ("unity = people"). Write a 4-step analytical paragraph.

STEPS:
- Step 1: Map the imagery cluster — "unh" (thermal/tactile), "igkM+" (spatial/tactile), "taxy" (thermal/energetic), "[ksr" (gustatory/vital). Together they cover *four senses* and suggest unity as *living, nourishing, enveloping force* — not an abstract contract.
- Step 2: Note the possessive pronoun shift — "gesa vUu nsrs gSa" (give to us) → "gesa v"kh"k gSa" (are ours). The imagery *transfers ownership* from external gift to internal possession.
- Step 3: Identify the pivot — "ysfdu vkf[kjdkj ftudh fxurh gS..." (But those on whom its existence depends...). The sensory buildup *creates the need* for a source. Warmth needs a fire; juice needs fruit; depth needs ground.
- Step 4: Reveal the metaphor — "os gSa fganqLrku osQ yksx" (they are the people of unity). The metaphor *resolves* the imagery: people are the *source* of the warmth/depth/heat/juice. The imagery was the *effect*; the metaphor names the *cause*.

REASONING: This worked example models the *causal link* between imagery and metaphor in the text — imagery makes the abstract quality *felt*; metaphor explains *where it comes from*. Board-level answers must show this dynamic, not just list devices.

ANSWER: The tactile-thermal-gustatory imagery cluster ("warmth, depth, heat, juice") materializes unity as a living, nourishing presence. The possessive shift ("give us" → "are ours") internalizes it. The pivot ("but those on whom it depends") creates a causal gap that the metaphor "unity = people" fills — people are not just *participants* in unity; they are its *generative substance*. The imagery earns the metaphor.

## COMPETENCY_QUESTION_1
QUESTION: In the chapter, the author encounters a farmer who says his relation to "Bharat Mata" is through the land (èkjrh). Later, the author concludes: "Hkkjr ekrk njvly ;gh djksM+ksa yksx gSa" (Mother India is verily millions of people). Using the concepts of *metaphor* and *imagery*, explain how the farmer's statement *functions as evidence* for the author's final metaphor. Your answer must reference tenor/vehicle/ground and at least one sensory image.

COMPETENCY: Literary analysis — using device terminology to trace argument structure

STEPS:
- Step 1: Identify the farmer's metaphor: Tenor = relationship with nation; Vehicle = relationship with land; Ground = generative, inherited, nurtured bond.
- Step 2: Identify the sensory imagery anchoring the vehicle: "vufxur ihf<+;ksa ls fdlkuh" (ploughing with bullocks) — tactile, olfactory, kinesthetic imagery of labor on soil.
- Step 3: Identify the author's final metaphor: Tenor = Mother India; Vehicle = millions of people; Ground = collective, living, constitutive identity.
- Step 4: Explain the evidentiary link — The farmer *is* one of the "millions of people." His land-bond *is* the concrete form of the people-bond. The imagery of ploughing *makes the vehicle tangible* — it proves the metaphor is not poetic fancy but lived reality.

ANSWER: The farmer's metaphor (nation-bond = land-bond) operates as a *synecdoche* — a part standing for the whole. The tactile-kinesthetic imagery of "ploughing with bullocks" grounds the vehicle (land) in physical labor, making the abstract "relation to Mother India" visible and verifiable. Since the farmer *embodies* "millions of people," his lived metaphor *validates* the author's culminating metaphor: Mother India *is* such people. The imagery bridges the two metaphors — soil → farmer → people → nation.

DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: The chapter uses the *extended metaphor of journey* (tylk) to structure the author's discovery of "unity." However, the text also contains *ironic moments* — e.g., people fight over "Bharat Mata's form" while ignoring her living reality (the people). Write a critical paragraph analyzing how *imagery* and *metaphor* interact with *irony* (previewing node 009) to deepen the theme. Use the phrase "unh vkSj igkM+" (warmth and depth) in your analysis.

COMPETENCY: Synthesis across literary devices — seeing how multiple devices co-construct theme

STEPS:
- Step 1: State the journey-metaphor's trajectory — physical travel → intellectual questioning → epiphanic realization.
- Step 2: Locate the irony — people worship "Bharat Mata" as symbol (form) but neglect "Bharat Mata" as people (substance). The author notes: "oqQN tokc u cu iM+us ij os ,d&nwljs dh rjI+kQ ;k esjh rjI+kQ ns[kus yx tkrs" (they look at each other's or my face blankly).
- Step 3: Analyze the imagery cluster "unh vkSj igkM+" (warmth and depth) — tactile/spatial imagery that *redefines* unity as *felt connection*, not abstract slogan.
- Step 4: Show the interaction — The journey-metaphor *exposes* the irony (by traveling, the author sees the gap). The imagery *resolves* it (by offering "warmth/depth" as the true form of unity). The final metaphor ("Mother India = people") *synthesizes* both: the journey was necessary to find the people; the irony was the obstacle; the imagery was the clue.
- Step 5: Conclude — Devices do not operate in isolation. The journey frames the inquiry; irony sharpens the problem; imagery suggests the solution; metaphor states the truth.

ANSWER: The journey-metaphor structures the author's empirical quest — he must *move* to discover that unity is not a statue but "unh vkSj igkM+" (warmth and depth), a tactile-spatial imagery cluster that makes unity *sensuous* and *relational*. This imagery ironically contrasts with the rigid, fought-over "form" of Bharat Mata — the irony being that those who claim to love her most (by fighting for her image) miss her living reality (the people). The culminating metaphor "Hkkjr ekrk = djksM+ksa yksx" resolves the tension: the journey's movement, the irony's exposure, and the imagery's invitation converge in the realization that the nation *is* its people. Each device performs a distinct rhetorical labor: journey = method, irony = critique, imagery = evidence, metaphor = thesis.

DIFFICULTY: hard