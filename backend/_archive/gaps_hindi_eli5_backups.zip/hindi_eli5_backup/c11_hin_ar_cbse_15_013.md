## DEFINITION
Critical thinking in literary analysis is the disciplined process of examining a text's explicit and implicit meanings by evaluating evidence, identifying underlying assumptions, and synthesizing multiple perspectives to form an independent, reasoned interpretation.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student can independently deconstruct a poem's central argument by tracing the development of its central metaphor across stanzas, evaluating the effectiveness of its rhetorical strategies, and articulating a nuanced interpretation supported by textual evidence that acknowledges ambiguity.

## SCOPE_BOUNDARY
This node covers advanced analytical skills for the poem "Sabse Khatarnak" (Paash) including metaphorical mapping, ideological critique, and intertextual connections; it does NOT cover basic comprehension, vocabulary, or identification of literary devices which are addressed in prior nodes.

## WALKTHROUGH
Imagine you are a detective examining a crime scene where the "crime" is the normalization of injustice. You don't just list clues (literary devices); you ask why the poet chose the metaphor of a "dead watch" over a "broken clock" and what that choice reveals about his view of time and resistance. Begin by re-reading the poem aloud, noting where your voice naturally changes pace or tone—those shifts often mark analytical entry points. Next, isolate the central metaphor (the "most dangerous" thing) and trace its evolution from abstract concept to concrete image across the three sections. Then, interrogate the poem's silences: whose voices are absent, and what historical realities (like the 1984 anti-Sikh riots or Punjab insurgency) haunt the text without being named. Finally, synthesize your findings into a thesis that explains how the poem transforms personal despair into collective political warning.

## DIAGNOSTIC_QUESTION_1
What is the central metaphor of the poem "Sabse Khatarnak" and how does the poet define it in the opening lines?

## DIAGNOSTIC_ANSWER_1
The central metaphor is "the most dangerous thing" (sabse khatarnak), defined not as physical violence but as the numbing of human sensitivity—specifically, "not feeling the heat of injustice" and "the silence of the oppressed." A wrong answer (e.g., identifying "death" or "war" as the central metaphor) reveals the student is reading literally and missing the poem's core argument that psychological capitulation is more destructive than physical harm.

## DIAGNOSTIC_QUESTION_2
Explain in your own words why the poet repeats the phrase "sabse khatarnak" (most dangerous) at the start of each stanza. What rhetorical effect does this anaphora create?

## DIAGNOSTIC_ANSWER_2
The repetition acts as a rhythmic hammer, forcing the reader to confront a growing list of societal cancers; it shifts from defining the concept to exemplifying it, creating a cumulative force that mirrors the insidious spread of apathy. A wrong answer (e.g., "it emphasizes the title" or "it makes the poem musical") shows the student recognizes the device but cannot connect form to ideological function—treating technique as decoration rather than argument.

## DIAGNOSTIC_QUESTION_3
Apply the concept of "false consciousness" to interpret the lines: "ghar se nikalna kaam par / aur kaam se ghar aana" (leaving home for work and returning from work). How does this routine represent the "most dangerous" state?

## DIAGNOSTIC_ANSWER_3
The routine embodies false consciousness because the worker's mechanical compliance—leaving home, laboring, returning—masks exploitation; the repetition normalizes alienation, making the worker an unwitting collaborator in their own dehumanization. A wrong answer (e.g., "it shows hard work is dangerous" or "it describes a daily schedule") fails to apply the Marxist lens implicit in Paash's poetry, reducing a systemic critique to a personal lament.

## DIAGNOSTIC_QUESTION_4
Analyze the shift in imagery from domestic spaces ("ghar", "chulha", "bachche") in the middle section to public/political spaces ("sadak", "chowk", "sansad") in the final section. What does this spatial progression reveal about the poem's theory of change?

## DIAGNOSTIC_ANSWER_4
The movement from private to public space maps the poet's diagnosis: apathy begins in the intimate sphere (family, hearth) but metastasizes into the political arena (streets, parliament), implying that resistance must also travel this trajectory—personal awakarning must become collective action. A wrong answer (e.g., "the poet describes different places" or "it shows life has many parts") treats imagery as descriptive backdrop rather than as a structured argument about the anatomy of oppression.

## DIAGNOSTIC_QUESTION_5
Evaluate the effectiveness of the poem's ending: "sabse khatarnak wo suraj hota hai / jo andheron mein bhi chamakta rahe" (the most dangerous is that sun which keeps shining even in darkness). Does this image resolve the poem's tension or deepen it? Justify your stance.

## DIAGNOSTIC_ANSWER_5
The ending deepens the tension by redefining hope itself as potentially dangerous— a sun shining in darkness suggests a false dawn that legitimizes the status quo, refusing the necessary darkness of confrontation. This subverts the conventional symbol of the sun as hope, aligning with the poem's project of inverting comfortable certainties. A wrong answer (e.g., "it gives a message of hope" or "it ends on a positive note") reveals an inability to read against the grain, defaulting to conventional symbol interpretation instead of engaging the poet's deliberate irony.

## DIAGNOSTIC_QUESTION_6
Create a four-line stanza in the style of Paash that extends the poem's logic to a contemporary issue (e.g., digital surveillance, climate apathy, or algorithmic bias). Use anaphora and a central metaphor that inverts a positive concept.

## DIAGNOSTIC_ANSWER_6
A strong response will maintain the anaphoric structure ("sabse khatarnak..."), identify a modern "comfort" (e.g., "the algorithm that feeds you only what you like"), and invert it into a tool of control ("sabse khatarnak wo feed hai jo tumhe tumhara hi chehra dikhaye"). A weak response mimics the form without the ideological bite—e.g., merely listing bad things—showing the student can imitate structure but not the critical thinking that generates the poem's power.

## COMMON_MISCONCEPTION
Students often treat "critical thinking" as "finding faults" or "disagreeing with the poet." In this poem, they may argue "Paash is too pessimistic" or "he ignores the good in routine," missing that the poem is a diagnostic tool, not a descriptive one. The error stems from confusing literary analysis with personal opinion: they evaluate the poem's worldview as if it were a policy proposal, rather than analyzing how the poem constructs its argument through metaphor, structure, and historical allusion.

## ON_FAILURE
1. Ask the student to list three things they do every day without thinking (e.g., scrolling phone, commuting, saying "I'm fine"). 2. Have them write one sentence explaining how each routine might serve a system they oppose. 3. Return to the poem and map each of Paash's examples (work routine, reading newspaper, watching sunset) to this new list. 4. Finally, rewrite their "disagreement" as an analytical question: "What structural purpose does the poet's refusal of hope serve in the poem's argument?"

## BUILDS_ON
This node builds on the identification of literary devices (irony, symbolism, imagery) and thematic understanding (primary/secondary themes) established in nodes 008, 009, 006, and 007.

## LEADS_TO
This node enables the writing skills node (014) where students craft analytical essays, and the speaking/listening node (015) where they defend interpretations in discussion.

## PREREQUISITE_NODE_IDS
c11_hin_ar_cbse_15_006, c11_hin_ar_cbse_15_007, c11_hin_ar_cbse_15_008, c11_hin_ar_cbse_15_009, c11_hin_ar_cbse_15_012, c11_hin_ar_cbse_15_001, c11_hin_ar_cbse_15_004, c11_hin_ar_cbse_15_005, c11_hin_ar_cbse_15_010, c11_hin_ar_cbse_15_011

## PREREQUISITE_REASONS
c11_hin_ar_cbse_15_006: Primary theme understanding provides the interpretive anchor for critical analysis.
c11_hin_ar_cbse_15_007: Secondary themes offer multiple analytical entry points beyond the central metaphor.
c11_hin_ar_cbse_15_008: Imagery and metaphor analysis skills are prerequisite for deconstructing the poem's central metaphor.
c11_hin_ar_cbse_15_009: Irony and symbolism recognition is essential for reading the poem's subversive endings.
c11_hin_ar_cbse_15_012: Inferential comprehension skills allow moving beyond literal meaning to ideological critique.
c11_hin_ar_cbse_15_001: "Before You Read: की समझ आवश्यक है, क्योंकि यह नोड (Critical thinking in literary analysis is the disciplined process of examining a text's ex...) इसी आधार पर आगे बढ़ता है।  
c11_hin_ar_cbse_15_004: Critical interpretation (e.g., "Is this poem feminist? Marxist?") requires a fixed reading of the speaker's stance first.  
c11_hin_ar_cbse_15_005: Critical interpretation requires synthesizing how the ensemble of figures constructs the poem's political argument.  
c11_hin_ar_cbse_15_010: Critical interpretation (e.g., "How does the poem redefine courage?") builds on precise understanding of redefined key terms.  
c11_hin_ar_cbse_15_011: Critical thinking needs grammatical precision to argue interpretations (e.g., "Does the genitive case imply ownership or inevitability?").  

## FORWARD_NODE_IDS
c11_hin_ar_cbse_15_014, c11_hin_ar_cbse_15_015, c12_hin_a_cbse_15_013, c12_hin_al_cbse_02_013, c12_hin_ar_cbse_03_013, c12_hin_ar_cbse_15_001, c12_hin_ar_cbse_15_013

## FORWARD_REASONS
c11_hin_ar_cbse_15_014: Analytical interpretations generated here become the thesis statements and evidence for structured essay writing.
c11_hin_ar_cbse_15_015: The nuanced readings developed here provide the substantive content for seminar discussions and oral defenses.
c12_hin_a_cbse_15_013: Prior practice in moving from literal to critical interpretation.  
c12_hin_al_cbse_02_013: Connected personal memory to collective cultural memory.  
c12_hin_ar_cbse_03_013: अगला तार्किक चरण: Critical Thinking: इस नोड की अवधारणाओं को सीधे उपयोग/विस्तारित करता है।  
c12_hin_ar_cbse_15_001: Develops critical thinking skills needed to distinguish structural analysis from moral commentary.  
c12_hin_ar_cbse_15_013: Class 11 critical thinking foundation — basic argument mapping and assumption identification.  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
none

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_15_006 -> c11_hin_ar_cbse_15_013 -> c11_hin_ar_cbse_15_014

## THIS_FORMULA
Analytical Framework: METAPHOR MAP → IDEOLOGICAL INTERROGATION → STRUCTURAL SYNTHESIS → EVIDENTIARY THESIS

## FORMULA_VARIABLES
METAPHOR MAP: Trace the central metaphor's evolution across textual segments; IDEOLOGICAL INTERROGATION: Question whose interests the text's assumptions serve; STRUCTURAL SYNTHESIS: Connect formal choices (anaphora, enjambment, stanza breaks) to argumentative moves; EVIDENTIARY THESIS: Formulate a claim supported by at least three distinct textual warrants.

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
analytical

## CROSS_SUBJECT
c11_history_nationalism | The poem's critique of normalized oppression parallels historical analyses of how colonial hegemony manufactured consent through routine and education.
c11_politicalscience_power | Paash's concept of "most dangerous" maps onto Gramsci's cultural hegemony—where domination operates through common sense rather than coercion.
c11_economics_labour | The depiction of the worker's daily cycle illustrates Marx's theory of alienation: labor external to the worker, not part of their nature.

## PREREQ_CONCEPT
Students must understand that literary texts construct arguments through form as much as content, and that metaphors function as conceptual frameworks, not merely decorative comparisons.

## PREREQ_BEFORE
Students should be able to independently identify the poem's central metaphor, list its three major examples of "dangerous" things, and explain the function of anaphora in the poem's structure.

## PREREQ_STUCK
If stuck, review the distinction between "symbol" (a thing representing another) and "conceit" (an extended metaphor governing a whole work) using the "dead watch" vs. "sun in darkness" contrast.

## WORKED_EXAMPLE_1
PROBLEM: Analyze how the metaphor of "murdā ghari" (dead watch) in the poem functions as a critique of mechanical time discipline in industrial capitalism.
STEPS:
- Step 1: Locate the metaphor in the text—identify the stanza where "murdā ghari" appears and note its immediate context (the worker's routine).
- Step 2: Deconstruct the metaphor's components: "murdā" (dead) + "ghari" (watch/clock). Contrast with "living time" (biological, seasonal, revolutionary).
- Step 3: Connect to historical context: Paash wrote during Punjab's Green Revolution and industrial exploitation; factory sirens replaced natural rhythms.
- Step 4: Analyze the metaphor's ideological work: a dead watch still shows time—it legitimizes the schedule that enslaves. The danger is not stopped time but falsely functioning time.
- Step 5: Synthesize: The metaphor condenses the poem's thesis—systems that appear functional (ticking watch) are most lethal when they measure only exploitation.
REASONING: This step-by-step moves from textual evidence to historical-materialist interpretation, modeling how critical thinking layers close reading with context.
ANSWER: The "dead watch" symbolizes a timekeeping device that has lost its organic connection to human life but continues to regulate it. Its danger lies in its apparent functionality—it ticks, workers obey, production continues—masking the death of agency. The metaphor critiques not time itself but the colonization of time by capital, making the watch a synecdoche for all ideological apparatuses that naturalize oppression.

## WORKED_EXAMPLE_2
PROBLEM: Evaluate the claim: "Paash's poem is ultimately nihilistic because it labels hope (the sun) as dangerous."
STEPS:
- Step 1: Define nihilism in literary terms—rejection of all meaning, value, hope.
- Step 2: Catalogue the poem's positive valuations: it values "feeling the heat of injustice," "raising voice," "eyes that see," "hands that work for change."
- Step 3: Analyze the "sun" image: it is dangerous only when it "shines in darkness"—i.e., when it offers false illumination that prevents necessary confrontation with reality.
- Step 4: Contrast with genuine hope in the poem: the "spark" (chinar) that starts a fire, the "voice" that breaks silence. These are active, not passive.
- Step 5: Conclude: The poem rejects passive optimism (waiting for dawn) to affirm militant hope (making dawn). This is anti-nihilistic.
REASONING: The evaluation requires distinguishing between the poem's target (complacency) and its project (revolutionary consciousness), preventing a surface-level misreading.
ANSWER: The claim is false. The poem does not reject hope; it rejects hope as a sedative. By labeling the "sun in darkness" dangerous, Paash attacks the illusion of automatic progress. The poem's energy is directed toward awakening—"sabse khatarnak" is a diagnostic, not a prognosis. Its final stance is radically hopeful: it believes humans can recognize their own dehumanization and act.

## WORKED_EXAMPLE_3
PROBLEM: Compare Paash's use of anaphora in "Sabse Khatarnak" with Faiz Ahmed Faiz's anaphora in "Bol" (Speak). How does each poet use repetition to construct a different theory of political speech?
STEPS:
- Step 1: Identify the anaphoric phrase in each poem: Paash uses "sabse khatarnak"; Faiz uses "bol" (speak).
- Step 2: Map the syntactic role: Paash's phrase is a predicate nominative (defining a subject); Faiz's is an imperative verb (commanding action).
- Step 3: Trace the progression: Paash's repetition accumulates definitions, building a taxonomy of oppression; Faiz's repetition escalates urgency, expanding the space of the speakable.
- Step 4: Analyze the implied audience: Paash addresses the already-oppressed to diagnose their condition; Faiz addresses the silenced to command their liberation.
- Step 5: Connect to historical moments: Paash (1980s Punjab insurgency) writes against normalization of terror; Faiz (1940s colonial Pakistan) writes against censorship.
- Step 6: Synthesize: Paash's anaphora is diagnostic (naming the disease); Faiz's is therapeutic (prescribing the cure). Both use repetition as political architecture, but one builds a mirror, the other a megaphone.
REASONING: This cross-textual analysis demonstrates higher-order critical thinking: comparing formal strategies across contexts to reveal distinct political epistemologies.
ANSWER: Paash's "sabse khatarnak" constructs a forensic catalog—each repetition adds a specimen to the pathology of apathy. Faiz's "bol" constructs a performative utterance—each repetition enacts the freedom it demands. Paash's anaphora is analytical (breaking down); Faiz's is synthetical (building up). The former says "see how deep the rot goes"; the latter says "speak, for your lips are free."

## COMPETENCY_QUESTION_1
QUESTION: The poem states: "sabse khatarnak wo din hota hai / jab insān khamosh ho jaye" (the most dangerous day is when a human falls silent). Using evidence from at least two other stanzas, explain how the poem defines "silence" not as absence of sound but as a specific political act. What are the three forms this silence takes in the poem?
COMPETENCY: Interpretive Reasoning with Textual Evidence
STEPS:
- Step 1: Reject the literal definition of silence as "not speaking."
- Step 2: Identify Stanza 2: silence as routine compliance ("ghar se nikalna kaam par").
- Step 3: Identify Stanza 3: silence as consumption of state propaganda ("akhbar padhna").
- Step 4: Identify Stanza 4: silence as aesthetic detachment ("suraj ko dekhna").
- Step 5: Synthesize: Silence = active participation in the status quo through normalized behaviors.
ANSWER: The poem redefines silence as complicity. Three forms: (1) Mechanical routine—leaving for work and returning without questioning exploitation; (2) Epistemic surrender—reading newspapers that manufacture consent instead of critical thought; (3) Aesthetic escapism—watching the sunset as spectacle rather than seeing the suffering it illuminates. Each is an act, not a void.
DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: A critic argues: "Paash's poem fails because it offers no alternative vision—only a list of what is dangerous." Write a 150-word rebuttal using the poem's own logic to show that the alternative is embedded in the diagnosis itself. Reference the concepts of "negative dialectics" and "immanent critique."
COMPETENCY: Critical Argumentation and Theoretical Application
STEPS:
- Step 1: Define negative dialectics (Adorno): truth emerges from exposing what is false, not positing a positive utopia.
- Step 2: Define immanent critique: using a system's own standards to reveal its contradictions.
- Step 3: Show how the poem performs immanent critique: it takes "normal" life (work, news, sunset) and reveals each as "most dangerous" by the system's own humanistic values.
- Step 4: Demonstrate the embedded alternative: every "sabse khatarnak X" implies "therefore, the opposite of X is necessary"—feeling, speaking, seeing, acting.
- Step 5: Conclude: The poem's alternative is the reader's awakened practice, not a blueprint in the text.
ANSWER: The critic mistakes diagnosis for prescription. Paash employs negative dialectics: by naming each "most dangerous" thing, he simultaneously illuminates its antithesis as the site of resistance. The poem's immanent critique measures everyday life against the humanism it betrays—work should be creative, not mechanical; news should inform, not anesthetize; the sun should reveal, not blind. The alternative is not a future program but a present imperative: to stop performing the "most dangerous" acts. The poem's form—relentless negation—is its positive method: it clears the ideological ground where agency can grow. To demand a manifesto is to misunderstand the poem as a tool of consciousness-raising, not policy-making.
DIFFICULTY: hard