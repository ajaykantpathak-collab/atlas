## DEFINITION
Vocabulary in Context is the analytical skill of determining the precise meaning, connotation, and grammatical function of an unfamiliar word by examining its surrounding linguistic environment—including syntactic structure, semantic associations, tone, and thematic relevance—rather than relying solely on dictionary definitions. At the senior secondary level, this involves identifying context clues (definition, synonym, antonym, example, inference, and morphological) to interpret authorial intent and nuance in literary texts.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student can independently identify the meaning of 5 unfamiliar words from the chapter "Ued ka Nakjksxk" using at least three different types of context clues, justify each inference with textual evidence, and use the words in original sentences that reflect the story's socio-historical register.

## SCOPE_BOUNDARY
This node covers context-clue strategies (definition, restatement, contrast, example, inference, word-structure) applied specifically to key vocabulary from Premchand's "Ued ka Nakjksxk" (e.g., *cjoaQnkth, lnkozr, eq[rkj, vykSfdd, dkrj, veys, vjnyh, pijklh, rtoh"k, vdkjFk, iNfg,¡*). It does NOT cover exhaustive vocabulary lists, dictionary skills in isolation, or words outside the prescribed chapter.

## WALKTHROUGH
Imagine you are reading a newspaper editorial about rural unemployment and encounter the word "agrarian" in the sentence: "The agrarian crisis deepened as monsoon failures destroyed the kharif crop." You don't reach for a dictionary; you notice "crop," "monsoon," "kharif," and "rural" and infer it relates to farming. Similarly, in "Ued ka Nakjksxk," when Premchand writes *"nkjksxk in osQ fy, rks odhyksa dk Hkh th yypkrk Fkk"* (for the post of a clerk, even graduates queued up), the phrase "graduates queued up" signals *th yypkrk* implies desperate competition. We begin by locating the target word, marking the sentence boundaries, hunting for signal words (like *ysfdu, blhfy, ,sls, tSls*), and asking: "What does the surrounding situation demand this word to mean?" The key insight: context is not just nearby words—it is the character's voice, the historical setting (colonial bureaucracy), and the thematic tension (dignity vs. survival).

## DIAGNOSTIC_QUESTION_1
Define "context clue" and name the six standard types taught at senior secondary level.

## DIAGNOSTIC_ANSWER_1
A context clue is a hint within the same sentence or surrounding sentences that helps a reader deduce the meaning of an unfamiliar word. The six standard types are: (1) Definition/Explanation, (2) Restatement/Synonym, (3) Contrast/Antonym, (4) Example/Illustration, (5) Inference/General Context, and (6) Word Structure/Morphology (roots, prefixes, suffixes). A wrong answer that lists only "synonym and antonym" reveals the student reduces context clues to binary opposition and misses inference—the most critical type for literary texts where meaning is layered.

## DIAGNOSTIC_QUESTION_2
In the sentence *"eaq'kh oa'kh/j pkSaosQ. iafMr vyksihnhu bl bykosQ osQ lcls izfrf"Br ”kehankj Fks"* (Akhbar Ojha said. Iftar Bahadur was the most loyal servant of this garden), explain how the word *izfrf"Br* (loyal/devoted) is clarified by the *rest of the paragraph* without using a dictionary.

## DIAGNOSTIC_ANSWER_2
The paragraph shows Iftar Bahadur managing the garden single-handedly ("#i;s dk ysu&nsu djrs Fks"), enduring harsh conditions ("cM+k yack&pkSM+k Fkk"), and earning the narrator's trust ("vaxjs”k vI+kQlj muosQ bykosQ esa f'kdkj [ksyus vkrs"). These behavioral examples function as *illustration clues* that define *izfrf"Br* as "steadfast in duty despite hardship." A student who only cites the dictionary meaning "faithful" misses the textual evidence that the author *shows* loyalty through actions, a key analytical distinction for board answers.

## DIAGNOSTIC_QUESTION_3
Apply the *contrast clue* strategy to determine the meaning of *vykSfdd* in the phrase *"vykSfdd ohjrk"* (from the sentence: *¯drq /eZ vykSfdd ohjrk osQ lkFk bl cgqla[;d lsuk osQ lEeq[k vosQyk ioZr dh Hkk¡fr vVy*). Write the antonym context phrase and the inferred meaning.

## DIAGNOSTIC_ANSWER_3
The contrast phrase is *"vfopfyr [kM+k"* (paid/fixed salary) which appears in coordination with *vykSfdd ohjrk* via *lkFk* (with). *vfopfyr* means "remunerated/paid," so *vykSfdd* must mean "unpaid/voluntary/honorary." Inferred meaning: *vykSfdd* = honorary / without salary / voluntary. A wrong answer guessing "difficult" or "hard" shows the student ignored the coordinate structure *X lkFk Y* and failed to see the salary vs. no-salary opposition central to the clerk's exploitation.

## DIAGNOSTIC_QUESTION_4
Analyze how the *morphological structure* of *cjoaQnkth* (cjoaQ + nkth) and its *syntactic position* in *"iVokjhfxjh dk loZlEekfur in NksM+&NksM+dj yksx bl foHkkx dh cjoaQnkth djrs Fks"* help deduce its precise meaning in the colonial office context.

## DIAGNOSTIC_ANSWER_4
Morphologically: *cjoaQ* (tour/inspection) + *nkth* (agent suffix, like *karkarta*) → "one who tours/inspects." Syntactically: it is the object of *djrs Fks* (used to do) and modified by *foHkkx dh* (of the department). Context: people "NksM+&NksM+dj" (peering/straining necks) to watch the *in* (procession/arrival). Inferred meaning: *cjoaQnkth* = "inspecting officer / touring official / departmental inspector." A student answering "traveler" misses the official, authoritative nuance required by *foHkkx dh* and the subordinates' anxious posture.

## DIAGNOSTIC_QUESTION_5
Evaluate the claim: "In *Ued ka Nakjksxk*, the word *vdkjFk* (in *i<+uk&fy[kuk lc vdkjFk x;k*) means merely 'compulsion.' Defend or refute using thematic evidence from the story's climax."

## DIAGNOSTIC_ANSWER_5
Refute. *vdkjFk* here means "inescapable necessity born of existential crisis," not mere external compulsion. Thematic evidence: The narrator says this *after* Iftar Bahadur's suicide, when the father (Ojha) finally sends the son to school—*blh le> ij* (on this very understanding). The "necessity" is the realization that literacy is the only weapon against the dehumanizing bureaucracy that killed Iftar. *vdkjFk* carries the weight of *moral imperative* + *survival strategy*. A student calling it "force" ignores the agency shift: the father *chooses* education as resistance, making *vdkjFk* an internalized resolve, not external pressure.

## DIAGNOSTIC_QUESTION_6
Create an original sentence using *rtoh"k* (will/testament) that mirrors the legal-finality tone of *"fMIVh eftLVªsV us viuh rtoh”k esa fy[kk"* (Mrs. Edwards wrote in her will) and embed a context clue of the *definition type* that would help a peer infer its meaning.

## DIAGNOSTIC_ANSWER_6
Sample answer: *"The zamindar dictated his rtoh”k—a legal document declaring the distribution of his estate after death—to the munim in the presence of two witnesses."* The embedded definition clue is the appositive phrase *"a legal document declaring the distribution of his estate after death."* A weak answer would use *rtoh"k* loosely as "wish" (e.g., "It was his rtoh”k to eat mangoes"), missing the juridical gravity Premchand attaches to it when Mrs. Edwards' will *legally* secures Iftar's pension—a pivotal plot turn.

## COMMON_MISCONCEPTION
Students believe "vocabulary in context" means guessing a word's *dictionary definition* from the sentence it sits in. In senior secondary Hindi literature, words like *veys* (laborer/bonded worker), *vjnyh* (servitude), or *pijklh* (capital-related) carry *historical, caste, and economic connotations* that a single sentence cannot yield. For example, *veys* in *"veys /eZ dks nkjksxkth dks xkfy;k¡ nsrk gqvk"* is not just "worker"—the context of *nkjksxkth* (clerk) handing money to *veys* while *iafMr* watches reveals a *power hierarchy*: clerk > laborer > Iftar. Guessing "worker" loses the colonial feudal nuance essential for "Character Analysis" (node 004) and "Theme" (node 006).

## ON_FAILURE
1. **Isolate the clause**: Have the student copy the exact sentence containing the target word and bracket the main clause. 2. **Hunt for signals**: Highlight conjunctions (*ysfdu, blhfy, ;fn, tSls*), punctuation (dashes, commas), and repeated nouns/pronouns referring to the word. 3. **Map the semantic field**: List all words in the paragraph related to the target word's domain (e.g., for *vjnyh*: *ukSdj, pkdj, eqÝ+r, fo}rk, eeZKrk* → domain: bonded labor/debt trap). 4. **Write a "context definition"**: Not a dictionary gloss, but a sentence: "*vjnyh* means the state of being trapped in hereditary debt-bondage where labor replaces currency." 5. **Verify with thematic payoff**: Check if this definition illuminates a character's motive or a theme (e.g., Iftar's *vjnyh* explains why he cannot quit). Repeat with three words from the *kCn&Nfo* list.

## BUILDS_ON
c11_hin_ar_cbse_01_002 (Text: Plot and Narrative Structure) – because plot events create the situational context that locks word meanings.

## LEADS_TO
c11_hin_ar_cbse_01_011 (Grammar: Language Usage in the Text) – because syntactic analysis of context clues (case endings, verb forms, compound types) is the bridge to formal grammar.

## PREREQUISITE_NODE_IDS
c11_hin_ar_cbse_01_002, c11_hin_ar_cbse_01_003, c11_hin_ar_cbse_01_004, c11_hin_ar_cbse_01_006, c11_hin_ar_cbse_01_008, c11_hin_ar_cbse_01_001, c11_hin_ar_cbse_01_009

## PREREQUISITE_REASONS
c11_hin_ar_cbse_01_002: Plot knowledge provides the situational "where/when" that anchors word meanings (e.g., *cjoaQnkth* only makes sense during the inspection scene).
c11_hin_ar_cbse_01_003: Setting/atmosphere (colonial office, summer heat) supplies the physical context that shades words like *th yypkrk* (queueing in heat = desperation).
c11_hin_ar_cbse_01_004: Character analysis reveals idiolect—Iftar's rustic speech vs. Ojha's bureaucratic Hindi—which determines register-specific meanings.
c11_hin_ar_cbse_01_006: Primary theme (dignity vs. exploitation) is the thematic lens through which ambiguous words (*vdkjFk, rtoh"k*) must be read.
c11_hin_ar_cbse_01_008: Imagery/metaphor nodes train the eye to spot figurative usage (e.g., *yM+fd;k¡ gaS] og ?kkl&iwQl dh rjg c<+rh pyh tkrh gSa* – metaphors that redefine *yM+fd;k¡*).
c11_hin_ar_cbse_01_001: "Context and Background" refers to the historical, social, biographical, and literary circ... की समझ आवश्यक है, क्योंकि यह नोड (Vocabulary in Context is the analytical skill of determining the precise meaning, connotat...) इसी आधार पर आगे बढ़ता है।  
c11_hin_ar_cbse_01_009: Vocabulary in context (e.g., "naksha," "eaman," "farz") gains depth when students see how words function as symbols.  

## FORWARD_NODE_IDS
c11_hin_ar_cbse_01_011, c11_hin_ar_cbse_01_012, c11_hin_ar_cbse_01_013, c11_hin_ar_cbse_01_014, c12_hin_a_cbse_01_010, c12_hin_a_cbse_02_010, c12_hin_a_cbse_02_011, c12_hin_a_cbse_03_010, c12_hin_a_cbse_06_010, c12_hin_a_cbse_07_010, c12_hin_a_cbse_08_010, c12_hin_a_cbse_10_010, c12_hin_a_cbse_11_010, c12_hin_a_cbse_12_010, c12_hin_a_cbse_17_010, c12_hin_al_cbse_01_010, c12_hin_al_cbse_02_010, c12_hin_al_cbse_03_010, c12_hin_ar_cbse_01_010, c12_hin_ar_cbse_06_010, c12_hin_ar_cbse_07_010, c12_hin_ar_cbse_12_010

## FORWARD_REASONS
c11_hin_ar_cbse_01_011: Grammar analysis requires identifying word-class and morphological markers first established here (e.g., *nkth* suffix in *cjoaQnkth*).
c11_hin_ar_cbse_01_012: Literal/inferential comprehension questions often hinge on precise vocabulary (e.g., "Why is *vykSfdd* significant?").
c11_hin_ar_cbse_01_013: Critical interpretation of authorial stance (e.g., Premchand's use of *veys* vs. *mazdur*) depends on connotative precision.
c11_hin_ar_cbse_01_014: Writing tasks (character sketch, thematic essay) demand deploying these words with correct register and collocation.
c12_hin_a_cbse_01_010: Introduced the context-clue method (morphology, syntax, tone) for inferring meaning — the foundational skill this node advances.  
c12_hin_a_cbse_02_010: Class 11 Vocabulary in Context node — established the basic context-clue method (syntax, tone, surrounding words) which this node deepens for poetic register.  
c12_hin_a_cbse_02_011: Class 11 vocabulary node builds strategies for context-based meaning inference.  
c12_hin_a_cbse_03_010: Builds the foundational skill of using NCERT glossary and context clues for Hindi literary texts.  
c12_hin_a_cbse_06_010: Class 11 Antra Vocabulary node establishes the method of contextual meaning analysis (वाच्यार्थ/लाक्षणिकार्थ) and etymological categorisation (तत्सम/तद्भव/देशज/विदेशज) used here.  
c12_hin_a_cbse_07_010: Built foundational skill of using NCERT glossary for dialect words in Antra poems.  
c12_hin_a_cbse_08_010: Class 11 vocabulary foundation — context-clue strategies, glossary use, archaic word handling.  
c12_hin_a_cbse_10_010: Introduced context-clue identification in Class 11 Antra Chapter 1.  
c12_hin_a_cbse_11_010: अगला तार्किक चरण: Vocabulary in Context: इस नोड की अवधारणाओं को सीधे उपयोग/विस्तारित करता है।  
c12_hin_a_cbse_12_010: Introduced the 4 context-clue types used here.  
c12_hin_a_cbse_17_010: Introduced "Vocabulary in Context" methodology (context clues, register analysis) — foundational skill.  
c12_hin_al_cbse_01_010: Class 11 vocabulary node established the baseline method of context-clue analysis.  
c12_hin_al_cbse_02_010: Foundation in identifying आंचलिक शब्द and ध्वन्यात्मक शब्द in prose texts.  
c12_hin_al_cbse_03_010: First Class 11 vocabulary node introducing the core skill of distinguishing dictionary vs. contextual meaning using NCERT glossaries.  
c12_hin_ar_cbse_01_010: Provides the foundational method of context-clue analysis and connotation mapping.  
c12_hin_ar_cbse_06_010: Class 11 vocabulary node establishes baseline context-clue and glossary-use skills.  
c12_hin_ar_cbse_07_010: Class 11 Aroh Ch 1 Vocabulary node establishes the baseline methodology (context > dictionary) used across all chapters.  
c12_hin_ar_cbse_12_010: Established foundational context-clue strategy (definition/synonym/antonym/example/inference) used here for advanced cultural-semantic analysis.  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS


## CHAIN_DESCRIPTION
c11_hin_ar_cbse_01_002 -> c11_hin_ar_cbse_01_010 -> c11_hin_ar_cbse_01_011 (Plot context enables vocabulary inference which enables grammatical analysis of those same words).

## THIS_FORMULA
Context Clue Identification Protocol (CCIP):
1. Locate target word + sentence boundaries.
2. Mark syntactic role (subject, object, modifier, predicate).
3. Scan ±2 sentences for signal types: Definition (ysfdu, arth), Synonym (,sls, tSls), Antonym (ysfdu, pr), Example (mnkgj.k, tSls), Morphology (roots, suffixes), Inference (thematic fit).
4. Formulate Contextual Operational Definition (COD): "In this passage, Word X means [specific nuance] because [evidence]."
5. Validate COD against character voice, historical setting, and theme.

## FORMULA_VARIABLES
- Target Word: The unfamiliar lexical item.
- Syntactic Role: Grammatical function in the sentence (karta, karma, visheshan, kriya-visheshan).
- Signal Type: Category of context clue (Def, Syn, Ant, Ex, Morph, Inf).
- Evidence Span: Exact phrase/clause providing the clue.
- COD: Contextual Operational Definition – the inferred meaning justified by evidence.

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
linguistic

## CROSS_SUBJECT
c11_history_colonialism | The vocabulary *cjoaQnkth, lnkozr, nkjksxk, vykSfdd* are direct lexical fossils of the British Raj's revenue and administrative apparatus; analyzing them is doing micro-history of colonial bureaucracy.
c11_economics_rural_livelihoods | Terms *veys, vjnyh, eq[rkj, pijklh* operationalize concepts of "unfree labor," "debt bondage," "subsistence income," and "capitalist exploitation" in a concrete narrative setting.
c11_civics_social_justice | The semantic field of *fo}rk, lgkuqHkwfr, dkuwu, iats* maps onto civic concepts of "rights," "dignity," "oppression," and "identity" – the story is a case study in denial of social justice.

## PREREQ_CONCEPT
Ability to segment a Hindi sentence into clause constituents (subject, predicate, modifiers) and identify basic parts of speech (noun, verb, adjective, postposition) – taught in Class 9-10 Hindi grammar.

## PREREQ_BEFORE
Student must be able to: (1) parse a simple Hindi sentence into *karta, karma, kriya*; (2) recognize common suffixes (*-ta, -pan, -ai, -kar, -nkth*); (3) distinguish literal vs. figurative language (metaphor, irony) from Node 008/009.

## PREREQ_STUCK
If stuck on clause parsing → review Class 10 Hindi Grammar "vakya vishleshan" (sentence analysis). If stuck on suffixes → review "pratyay" (suffixes) list. If stuck on figurative vs. literal → revisit Node 008 (Imagery) and 009 (Irony/Symbolism).

## WORKED_EXAMPLE_1
PROBLEM: Determine the contextual meaning of *lnkozr* in the sentence: *"yk[kksa #i;s dk ysu&nsu djrs Fks] b/j NksVs ls cM+s dkSu ,sls Fks] tks muosQ Í.kh u gksaA O;kikj Hkh cM+k yack&pkSM+k Fkk. cM+s pyrs&iqj”ks vkneh FksA vaxjs”k vI+kQlj muosQ bykosQ esa f'kdkj [ksyus vkrs vkSj muosQ esgeku gksrsA ckjgksa ekl lnkozr pyrk Fkk."* (Para 8)

STEPS:
- Step 1: Locate *lnkozr* – it modifies *pyrk Fkk* (used to occur/go) in the last sentence. Syntactic role: adverbial modifier of frequency/time.
- Step 2: Scan ±2 sentences for signals. Preceding sentences describe Iftar's duties: managing garden (*#i;s dk ysu&nsu*), enduring heat/cold (*yack&pkSM+k*), walking long distances (*pyrs&iqj”ks vkneh*), commanding respect (*f'kdkj [ksyus*). The word *ckjgksa* (sometimes/often) appears right before *lnkozr*.
- Step 3: Identify clue type. *ckjgksa* is a frequency adverb; *lnkozr* co-occurs with it modifying *pyrk Fkk*. This is a **Synonym/Restatement Clue** (*ckjgksa* ≈ *lnkozr*) reinforced by **Inference Clue** (the described routine implies regularity).
- Step 4: Morphological check: *lnkozr* (लनकोजर) – likely *laghu* + *kojar*? No, context suggests *lnkozr* = *lagatar* (continuous) or *niyamat* (regular). Dictionary confirms: *lnkozr* = लगातार, निरंतर (continuous, regular).
- Step 5: Formulate COD: In this passage, *lnkozr* means "regularly/continuously/every month" because it restates *ckjgksa ekl* (sometimes every month) and the context describes a relentless, unbroken routine of service.
- Step 6: Thematic validation: This "continuous" service underscores Iftar's *izfrf"Br* (loyalty) – the very trait Ojha praises – making his later betrayal by the system more tragic.

REASONING: The protocol forces the student to move beyond "lnkozr = regularly" to "lnkozr = the unbroken monthly cycle that defines Iftar's exploited loyalty," which is the depth required for "Character Analysis" answers.

ANSWER: *lnkozr* = लगातार / निरंतर / प्रति माह नियमित रूप से। Contextual Operational Definition: "The unbroken monthly routine of Iftar Bahadur's service to the garden, highlighting his steadfastness which the colonial bureaucracy ultimately disregards."

## WORKED_EXAMPLE_2
PROBLEM: Decode *vjnyh* (or *vkWMZjyh*) in the climactic dialogue: *"iafMr th] eq>esa bruh lkeF;Z ugha gS fd vkidh mnkjrk dh iz'kalk dj lowQ¡A ¯drq eSa ,sls mPp in osQ ;ksX; ugha gw¡A vyksihnhu g¡ldj cksysµeq>s bl le; ,d v;ksX; euq"; dh gh ”k:jr gSA oa'kh/j us xaHkhj Hkko ls dgkµ;ksa eSa vkidk nkl gw¡A vki tSls dhfrZoku] lTtu iqjQ"k dh lsok djuk esjs fy, lkSHkkX; dh ckr gSA ¯drq eq>esa u fo|k gS] u cqf¼] u og LoHkko] tks bu =kqfV;ksa dh iwfrZ dj nsrk gSA ,sls egku dk;Z osQ fy, ,d cM+s eeZK vuqHkoh euq"; dh ”k:jr gSA vyksihnhu us dyenku ls dye fudkyh vkSj mls oa'kh/j osQ gkFk esa nsdj cksysµu eq>s fo}rk dh pkg gS] u vuqHko dh] u eeZKrk dh] u dk;Z oqQ'kyrk dhA"* (Para 15)

STEPS:
- Step 1: Locate *vjnyh* – it appears in the *kCn&Nfo* list at the end, but in the text the concept is enacted in Iftar's speech: *"u eq>s fo}rk dh pkg gS] u vuqHko dh] u eeZKrk dh] u dk;Z oqQ'kyrk dh"* (I ask for freedom, not favor, not charity, not employment).
- Step 2: Syntactic role in the list: *vjnyh (vkWMZjyh)* – glossed as *"fdlh cM+s vI+kQlj osQ lkFk jgus okyk [kkl pijklh"* (servitude living with a big officer). This is a **Definition Clue** provided by the textbook editor.
- Step 3: But for *in-context* analysis, we must use the *speech context*. Iftar contrasts *fo}rk* (freedom) with *vuqHko* (obligation), *eeZKrk* (charity), *dk;Z oqQ'kyrk* (duty/service). This is an **Antonym/Contrast Clue** cluster: *vjnyh* is the condition *opposed* to *fo}rk*.
- Step 4: Morphology: *vjnyh* from *vjan* (to serve/attend) + *-ya* (state noun) → state of serving. *vkWMZjyh* = *v* (intensive) + *kWMZ* (work/service) + *-ya* → intense service bondage.
- Step 5: Historical inference: *pijklh* (capital-related) in the gloss links *vjnyh* to *capitalist/feudal servitude* – not just service, but *bonded* service tied to debt/land.
- Step 6: COD: In this climax, *vjnyh* means "hereditary debt-bondage servitude where the servant's body and labor are de facto property of the master, disguised as loyalty." Iftar rejects the *label* of loyal servant (*izfrf"Br*) to claim the *reality* of *vjnyh* – and demands *fo}rk* (legal freedom) as right, not grace.
- Step 7: Thematic payoff: This single word encapsulates the story's central thesis: colonial bureaucracy (*nkjksxk*) and feudal patronage (*oa'kh/j*) together sustain *vjnyh*; only literacy (*i<+uk&fy[kuk*) can break it.

REASONING: This example demonstrates how senior secondary vocabulary work must fuse textbook gloss, textual co-text, morphological analysis, and historical knowledge to produce a COD that serves thematic interpretation – exactly what "Critical Thinking" (Node 013) demands.

ANSWER: *vjnyh* = बंधुआ मजदूरी / गुलामी की वह अवस्था जहाँ सेवक की देह और श्रम मालिक की संपत्ति-समान समझे जाएँ। Contextual Operational Definition: "The structural condition of unfree labor that Iftar Bahadur names and refuses in his final act of agency, transforming from 'loyal servant' (izfrf"Br) to 'claimant of rights' (fo}rk ka dawedar)."

## WORKED_EXAMPLE_3
PROBLEM: The word *eq[rkj* appears twice with shifting senses: (A) *"eq[rkj vkSj pknj ij j[kuh pkfg,A ,slk dke <w¡<+uk tgk¡ oqQN mQijh vk; gksA"* (Para 6) and (B) *"firkth us vk'khokZn fn;kA oa'kh oa'kh/j vkKkdkjh iq=k FksA ;s ckrsa è;ku ls lquha vkSj rc ?kj ls py [kM+s gq,A bl foLr`r lalkj esa muosQ fy, /S;Z viuk fe=k] cqf¼ viuh iFkizn'kZd vkSj vkRekoyacu gh viuk lgk;d FkkA ysfdu vPNs 'koqQu ls pys Fks] tkrs gh tkrs ued foHkkx osQ nkjksxk in ij izfrf"Br gks x,A"* (Para 7). Trace the semantic shift and explain its narrative function.

STEPS:
- Step 1: Instance A – *eq[rkj* in *"eq[rkj vkSj pknj ij j[kuh pkfg,A"* Context: Father advising son on clerk's job. *pknj* = fan (status symbol), *eq[rkj]* paired with it. Signal: *mQijh vk;* (good salary) follows. **Clue Type: Example/Illustration** – things bought with salary. *eq[rkj]* here = "livelihood / means of subsistence / rozi-roti."
- Step 2: Instance B – *eq[rkj* in *"muosQ fy, /S;Z viuk fe=k] cqf¼ viuh iFkizn'kZd vkSj vkRekoyacu gh viuk lgk;d Fkk"* (for them, service was their livelihood, honor, identity). But then: *"ysfdu vPNs 'koqQu ls pys Fks] tkrs gh tkrs ued foHkkx osQ nkjksxk in ij izfrf"Br gks x.A"* (but attraction pulled them to clerkship). **Clue Type: Contrast** – *eq[rkj* (traditional service) vs. *nkjksxk in* (modern clerkship).
- Step 3: Semantic Shift: In A, *eq[rkj* = **economic survival** (father's pragmatic view: "take the job, it pays"). In B, *eq[rkj* = **hereditary vocation + identity + honor** (the world Iftar leaves behind). The shift is from *material* to *existential*.
- Step 4: Narrative Function: This polysemy structures the father-son conflict. Father sees *eq[rkj* as *vykSfdd ohjrk* vs. *vfopfyr [kM+k* (unpaid vs. paid labor) – economic calculation. Iftar initially shares this (*izfrf"Br* clerk), but the story reveals *eq[rkj* as *vjnyh* (bondage) in both forms. The word *eq[rkj* thus becomes a **thematic pivot**: it starts as "solution" (father), becomes "trap" (Iftar's realization), and ends as "false consciousness" (Ojha's final *eq[rkj* = pension struggle).
- Step 5: Board-level synthesis: A "Vocabulary in Context" answer must show this trajectory: *eq[rkj* (Para 6) → *eq[rkj* (Para 7) → *vjnyh* (Para 15) → *fo}rk* (Para 15). The vocabulary *is* the plot.

REASONING: This worked example models the "multi-step analytical reasoning" required: tracking a lexical item across the narrative arc, correlating its senses with character perspectives, and linking to thematic architecture – the hallmark of a 5-mark "Analyze the significance of..." board question.

ANSWER: *eq[rkj* shifts from "material livelihood" (father's pragmatic calculus) to "hereditary identity-honor-vocation" (Iftar's lost world) to "structural bondage" (story's verdict). This semantic trajectory mirrors the narrative arc: economic compulsion → feudal loyalty → colonial exploitation → demand for freedom.

## COMPETENCY_QUESTION_1
QUESTION: In the sentence *"nqfu;k lksrh Fkh] ij nqfu;k dh thHk tkxrh Fkh"* (Para 11), the word *thHk* is not in the *kCn&Nfo* list. Using **only** the co-text of this paragraph (the flute music, the night setting, Iftar's memories, the approaching crisis), infer the meaning of *thHk* and identify the **dominant context clue type** used. Justify why this meaning is thematically resonant with the *iNfg,¡* (flute) motif.

COMPETENCY: Lexical Inference & Thematic Integration
STEPS:
- Step 1: Isolate the sentence and its immediate neighbors (the flute playing, the sleeping laborers, the "Xokyk" – the one who plays flute).
- Step 2: Note *thHk* modifies *tkxrh Fkh* (used to be heard/perceived). *nqfu;k* (flute) is the subject.
- Step 3: Scan for clues: *lksrh Fkh* (sounded), *tkxrh Fkh* (was heard), *dfYir jks”kukeps Hkjusokys* (tired laborers sleeping), *tkyh nLrkos”k cukusokys* (creating peaceful atmosphere). *thHk* qualifies the *perception* of the flute.
- Step 4: Dominant clue: **Inference from Atmosphere/Register**. The paragraph contrasts the flute's *thHk* sound with the "vfèkdkjh oxZ" (official class) and "jsy esa fcuk fVdV lI+kQj djusokys ckcw yksx" (white people doing no work in heat). The flute is the *only* organic sound.
- Step 5: Infer meaning: *thHk* = distinct, clear, piercing, resonant, audible above silence – "spष्ट / सुस्पष्ट / गूंजता हुआ".
- Step 6: Thematic resonance: The flute (*iNfg,¡*) is Iftar's *voice* – his *fo}rk* (freedom) expressed in art. *thHk* means this voice *cuts through* the oppressive silence of the *vjnyh* system. It is the "clear sound" of humanity that the bureaucracy (*nkjksxk*) cannot mute.

ANSWER: *thHk* = स्पष्ट / सुस्पष्ट / गूंजता हुआ (distinct, clear, resonant). Dominant clue: **Inference from Atmospheric Contrast** (flute's clarity vs. oppressive silence of power). Thematic resonance: The *thHk* flute is the auditory symbol of Iftar's irreducible selfhood – the "clear note" that survives even when his body is broken by *vjnyh*.

DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: Premchand uses the pair *U;k; vkSj uhfr* (Para 9: *"U;k; vkSj uhfr lc y{eh osQ gh f[kykSus gSa] bUgsa og tSls pkgrh gaS] upkrh gSa"*) and later *U;k; osQ eSnku esa /eZ vkSj /u esa ;q¼ Bu x;kA* (Para 11). Analyze how the **contextual meaning** of *U;k;* shifts between these two occurrences, identifying the specific context clues (syntactic, semantic, thematic) that drive the shift. Explain why this polysemy is central to the story's critique of feudal-colonial power.

COMPETENCY: Semantic Analysis & Socio-Historical Interpretation
STEPS:
- Step 1: Occurrence 1 (Iftar's speech): *"U;k; vkSj uhfr lc y{eh osQ gh f[kykSus gSa"* – *U;k;* is paired with *uhfr* (tradition/custom), both possessed by *y{eh* (master). Clue: **Coordination + Possessive Structure** (*y{eh osQ*). Meaning: "Master's rights / proprietary claims / feudal entitlements."
- Step 2: Occurrence 2 (Narrator's analysis): *"U;k; osQ eSnku esa /eZ vkSj /u esa ;q¼ Bu x;k"* – *U;k;* is head of *eSnku* (domain/sphere), contrasted with *èkeZ* (law/state) and */u* (custom). Clue: **Analytical Frame** (*eSnku esa*... *esa ;q¼*). Meaning: "Legal/jurisdictional authority / sovereign right / state power."
- Step 3: Shift Driver: Speaker shift (Character → Narrator) + Register shift (Feudal discourse → Political theory discourse). Iftar speaks as *subject* experiencing *U;k;* as oppression; Narrator analyzes *U;k;* as *structure* enabling oppression.
- Step 4: Thematic Centrality: The slippage from "master's right" to "state authority" **is** the story's argument: colonial law (*èkeZ*) did not abolish feudal *U;k;* – it **absorbed and legitimized** it. The clerk (*nkjksxk*) becomes the new *y{eh* wielding *U;k;* via *èkeZ*. Iftar's suicide exposes this continuity.
- Step 5: Board Answer Structure: (1) Quote both loci. (2) Tabulate shift: Feudal → Colonial-Legal. (3) Name clues: Possessive coordination vs. Domain/Contrast frame. (4) Thesis: *U;k;* is the master-key vocabulary exposing the feudal-colonial nexus.

ANSWER: *U;k;* shifts from **"feudal master's customary entitlement"** (Iftar's voice: *y{eh osQ U;k;*) to **"state-sanctioned jurisdictional authority"** (Narrator's voice: *U;k; osQ eSnku esa èkeZ*). Clues: Possessive coordination (*y{eh osQ*) vs. Abstract domain frame (*eSnku esa... ;q¼*). This polysemy encodes the story's core thesis: the colonial bureaucracy (*nkjksxk*) did not replace feudal power (*y{eh*) – it **institutionalized** it, turning *U;k;* from personal caprice into systemic law, making *vjnyh* inescapable.

DIFFICULTY: hard