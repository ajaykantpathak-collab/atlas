## DEFINITION
Writing skills based on the chapter refer to the ability to compose structured written responses—such as character sketches, dialogues, one-act play conversions, letters, reports, and analytical essays—that demonstrate deep understanding of the play's themes, characters, dramatic techniques, and socio-cultural context, using textual evidence and appropriate literary conventions.

## COGNITIVE_LEVEL
apply

## MASTERY_CRITERIA
The student can independently write a character sketch using the PEEL structure with at least three textual evidences, compose a dialogue adhering to stage-direction conventions, and convert a prose passage into a one-act play with proper formatting (scene division, stage directions, character list).

## SCOPE_BOUNDARY
This node covers writing tasks directly derived from the chapter "jtuh" (character analysis, dialogue writing, one-act play conversion, letter/report writing, thematic essays). It does not cover general creative writing unrelated to the text, nor does it teach basic grammar or vocabulary; those are addressed in sibling nodes.

## WALKTHROUGH
Imagine you are a journalist assigned to cover the protest meeting depicted in the play. You need to write a report that captures the tension, the speakers' arguments, and the atmosphere. Begin by rereading the protest scene (pages 83-84) and listing key details: who spoke, what they said, stage directions describing the crowd. Next, organize these details into a report structure: headline, lead paragraph (who, what, when, where), body with direct quotes paraphrased, and concluding observation. Connect this to the familiar task of writing a news report for your school magazine. The key insight is that writing based on a dramatic text requires selecting evidence, maintaining the author's tone, and adapting it to the target format's conventions.

## DIAGNOSTIC_QUESTION_1
What are the four essential components of a character sketch written for a board exam answer?

## DIAGNOSTIC_ANSWER_1
The four components are: (1) a clear topic sentence stating the dominant trait, (2) textual evidence (paraphrased or quoted), (3) explanation of how the evidence reveals the trait, and (4) a linking sentence connecting the trait to the play's theme. A wrong answer that lists only "introduction, body, conclusion" reveals the student is applying a generic essay structure instead of the analytical PEEL method required for literary analysis.

## DIAGNOSTIC_QUESTION_2
In the play, Jyoti writes a letter to Vimal. Explain why the letter format is more effective than a dialogue for conveying her inner conflict at that moment.

## DIAGNOSTIC_ANSWER_2
The letter allows Jyoti to express thoughts she cannot voice face-to-face due to social constraints; it provides a private, reflective space where she can articulate her dilemma about tuition culture without interruption. A wrong answer focusing only on "letter is written, dialogue is spoken" shows the student misses the dramatic function of the letter as a soliloquy substitute that reveals interiority.

## DIAGNOSTIC_QUESTION_3
Convert the following prose situation into a one-act play opening scene (max 150 words): "A teacher discovers a student has been forced by parents to take private tuition. The student is exhausted and afraid to speak."

## DIAGNOSTIC_ANSWER_3
A good conversion includes: (1) a scene heading (e.g., "Staff Room. Afternoon."), (2) a character list, (3) stage directions describing setting and body language, (4) dialogue that reveals the conflict through subtext, (5) a closing stage direction hinting at tension. A weak answer writes a narrative paragraph without stage directions or character tags, indicating the student does not grasp the visual, performative nature of drama.

## DIAGNOSTIC_QUESTION_4
Compare the tone of Jyoti's dialogue with Lekhraj (pages 70-71) and her dialogue with Vimal (pages 69-70). How does the playwright use language to show Jyoti's shifting power dynamics?

## DIAGNOSTIC_ANSWER_4
With Lekhraj, Jyoti uses formal, assertive sentences ("मुझे आपकी दखलअंदाज़ी पसंद नहीं") and rhetorical questions, positioning herself as an equal challenging authority. With Vimal, she uses hesitant fragments ("वो... वो..."), apologetic particles ("शायद"), and seeks validation ("आप क्या समझते हैं?"), revealing vulnerability. A wrong answer that only quotes lines without analyzing syntactic choices shows the student cannot connect linguistic form to character dynamics.

## DIAGNOSTIC_QUESTION_5
Critique the following student claim: "The protest scene is unrealistic because a principal would never allow a teacher to publicly criticize the management." Defend or refute using dramatic conventions.

## DIAGNOSTIC_ANSWER_5
Refute: One-act plays often compress reality for thematic impact; the scene uses heightened realism (a convention of social drama) to expose systemic hypocrisy. The principal's silence is a dramatic device showing institutional complicity. A wrong answer that agrees with the claim treats the play as a documentary, missing the distinction between mimesis and theatrical representation.

## DIAGNOSTIC_QUESTION_6
Write a 100-word diary entry from Vimal's perspective on the night he receives Jyoti's letter, capturing his emotional turmoil and decision about the tuition.

## DIAGNOSTIC_ANSWER_6
A strong entry uses first-person present tense, sensory details ("कागज़ की गंध"), internal monologue ("क्या मैं सचमुच कमज़ोर हूँ?"), and ends with a resolved action ("कल मैं प्रिंसिपल से मिलूँगा"). A poor entry merely summarizes the plot in third person, showing the student cannot adopt a character's subjective voice.

## COMMON_MISCONCEPTION
Students often treat writing tasks as plot summary, listing events in chronological order without analysis. They believe "writing based on the chapter" means retelling the story, not constructing an argument using the text as evidence. This stems from middle-school habits where comprehension answers were rewarded for coverage rather than depth. For example, in a character sketch of Jyoti, a student writes: "Jyoti is a teacher. She talks to Vimal. She writes a letter. She goes to the protest." This ignores the requirement to interpret her motivations, contradictions, and thematic significance.

## ON_FAILURE
1. Show the student a side-by-side comparison: a plot-summary paragraph vs. a PEEL-structured character sketch on the same character. 2. Highlight the four PEEL components in color (Point, Evidence, Explanation, Link). 3. Have the student practice by taking one trait ("idealistic") and finding two quotes from the play, then writing the Explanation and Link sentences aloud. 4. Assign a micro-task: convert a single dialogue exchange into a diary entry, focusing on interiority.

## BUILDS_ON
Deep comprehension of the play's plot, characters, themes, and dramatic devices (covered in nodes 06_001 to 06_013).

## LEADS_TO
Speaking and listening activities (node 06_015) where students present their written analyses orally and debate interpretations.

## PREREQUISITE_NODE_IDS
c11_hin_ar_cbse_06_001, c11_hin_ar_cbse_06_002, c11_hin_ar_cbse_06_004, c11_hin_ar_cbse_06_006, c11_hin_ar_cbse_06_008, c11_hin_ar_cbse_06_012, c11_hin_ar_cbse_06_013, c11_hin_ar_cbse_06_005, c11_hin_ar_cbse_06_007, c11_hin_ar_cbse_06_009, c11_hin_ar_cbse_06_010, c11_hin_ar_cbse_06_011

## PREREQUISITE_REASONS
c11_hin_ar_cbse_06_001: Provides historical context of tuition culture needed for thematic essays.
c11_hin_ar_cbse_06_002: Understanding plot structure is essential for writing summaries and scene conversions.
c11_hin_ar_cbse_06_004: Protagonist analysis supplies evidence for character sketches.
c11_hin_ar_cbse_06_006: Primary theme (education vs. commercialization) is the backbone of analytical essays.
c11_hin_ar_cbse_06_008: Knowledge of imagery/metaphor enables analysis of language in dialogue writing.
c11_hin_ar_cbse_06_012: Literal and inferential comprehension ensures accurate textual referencing.
c11_hin_ar_cbse_06_013: Critical thinking skills allow evaluation of dramatic choices in critique tasks.
c11_hin_ar_cbse_06_005: Writing skills (character sketch, analytical paragraph) directly apply this analysis.  
c11_hin_ar_cbse_06_007: Writing tasks (article, speech, letter) on education reform demand thematic depth beyond the primary message.  
c11_hin_ar_cbse_06_009: Writing tasks (e.g., analytical paragraph) demand evidence of these devices.  
c11_hin_ar_cbse_06_010: Writing tasks require using chapter vocabulary appropriately in analytical essays.  
c11_hin_ar_cbse_06_011: Writing tasks (e.g., converting scene to story) require replicating the play's linguistic texture.  

## FORWARD_NODE_IDS
c11_hin_ar_cbse_06_015, c12_hin_a_cbse_05_014, c12_hin_ar_cbse_06_014

## FORWARD_REASONS
c11_hin_ar_cbse_06_015: Written analyses form the basis for structured group discussions and oral presentations in the speaking/listening node.
c12_hin_a_cbse_05_014: अगला तार्किक चरण: Writing Skills based on the chapter refers to the ability to compose structured, evidence-based resp... इस नोड की अवधारणाओं को सीधे उपयोग/विस्तारित करता है।  
c12_hin_ar_cbse_06_014: Direct predecessor — same skill at Class 11 level  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
none

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_06_006 -> c11_hin_ar_cbse_06_014 -> c11_hin_ar_cbse_06_015

## THIS_FORMULA
PEEL Structure for Literary Writing: Point (topic sentence) + Evidence (textual detail) + Explanation (analysis) + Link (connection to theme/question)

## FORMULA_VARIABLES
Point: Central claim about character/theme/technique; Evidence: Specific line, action, or stage direction from the play; Explanation: How the evidence proves the point using literary reasoning; Link: Tie-back to the exam question or overarching theme.

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
linguistic

## CROSS_SUBJECT
c11_history_social_reform_movements | The play's protest scene mirrors 1970s teachers' movements; writing a report on it requires historical context of labor struggles in education.
c11_civics_rights_and_duties | Jyoti's letter raises issues of professional ethics and workers' rights; analytical essays can reference constitutional provisions on fair working conditions.
c11_english_drama_writing | Converting prose to one-act play teaches dramatic conventions (stage directions, subtext) directly applicable to English Core's drama section.

## PREREQ_CONCEPT
Ability to locate and cite textual evidence to support an interpretive claim.

## PREREQ_BEFORE
Student must have read the full play and completed comprehension questions (node 06_012) to have a bank of evidence.

## PREREQ_STUCK
If stuck, review node 06_012 (Comprehension) and 06_013 (Critical Thinking) for evidence-gathering practice.

## WORKED_EXAMPLE_1
PROBLEM: Write a character sketch of Jyoti (150 words) focusing on her evolution from compliance to resistance, using the PEEL structure.
STEPS:
- Step 1: Identify the question's demand: "evolution from compliance to resistance" means tracing a change, not listing static traits.
- Step 2: Select three key moments: (a) early dialogue with Yashoda where she accepts tuition culture (p.69), (b) confrontation with Lekhraj where she questions the system (p.71), (c) letter to Vimal where she takes a stand (p.72).
- Step 3: Draft Point sentence: "Jyoti transforms from a compliant teacher into a resistant voice against commercialized education."
- Step 4: For each moment, write Evidence + Explanation: e.g., "Initially she tells Yashoda, 'ट्यूशन तो पढ़ाना ही पड़ता है' (p.69), revealing resignation. Later she challenges Lekhraj: 'आपको दखलअंदाज़ी पसंद नहीं' (p.71), showing emerging agency."
- Step 5: Write Link: "This arc embodies the play's central theme: individual conscience awakening against institutional decay."
REASONING: The PEEL structure forces analytical depth; each piece of evidence is interpreted, not just cited. The three moments cover beginning, middle, end, satisfying the "evolution" requirement.
ANSWER: Jyoti transforms from a compliant teacher into a resistant voice against commercialized education. Initially she tells Yashoda, "ट्यूशन तो पढ़ाना ही पड़ता है" (p.69), revealing resignation to systemic pressure. Later she challenges Lekhraj: "आपको दखलअंदाज़ी पसंद नहीं" (p.71), using formal assertiveness to claim professional autonomy. Finally, her letter to Vimal—written in private but addressed publicly—declares, "मैं ट्यूशन नहीं पढ़ाऊँगी" (p.72), converting inner conflict into public action. This arc embodies the play's central theme: individual conscience awakening against institutional decay.

## WORKED_EXAMPLE_2
PROBLEM: Convert the prose passage "The principal calls Jyoti to his office and warns her about the protest. Jyoti listens silently but her eyes show defiance." into a one-act play scene with stage directions.
STEPS:
- Step 1: Determine scene heading: "Principal's Office. Morning." based on context.
- Step 2: List characters: PRINCIPAL, JYOTI.
- Step 3: Write opening stage direction describing setting and body language: "A cluttered desk. PRINCIPAL sits, signing papers. JYOTI stands, hands folded, gaze lowered but jaw tight."
- Step 4: Craft dialogue that conveys warning and defiance through subtext: PRINCIPAL: "कल की घटना... प्रशासन नाराज़ है।" JYOTI: (pause) "घटना? या सच बोलने की सज़ा?" PRINCIPAL: "चेतावनी समझो।" JYOTI: (meeting his eyes) "समझ लिया।"
- Step 5: Add closing stage direction: "JYOTI turns, walks out without bowing. PRINCIPAL watches, pen suspended."
- Step 6: Verify format: character names centered, stage directions in brackets/italics, present tense.
REASONING: The conversion must externalize internal states (defiance) through visible actions and loaded dialogue, adhering to the playwright's toolkit taught in the chapter's "iVdFkk dh nqfu;k" section.
ANSWER:
[Principal's Office. Morning. A cluttered desk. PRINCIPAL sits, signing papers. JYOTI stands, hands folded, gaze lowered but jaw tight.]
PRINCIPAL: कल की घटना... प्रशासन नाराज़ है।
JYOTI: (pause) घटना? या सच बोलने की सज़ा?
PRINCIPAL: चेतावनी समझो।
JYOTI: (meeting his eyes) समझ लिया।
[JYOTI turns, walks out without bowing. PRINCIPAL watches, pen suspended.]

## WORKED_EXAMPLE_3
PROBLEM: Write a 200-word analytical essay answering: "How does the playwright use the motif of 'letters' to structure the narrative and reveal character?" (Combines theme, structure, and character analysis.)
STEPS:
- Step 1: Deconstruct the prompt: three tasks—identify letters, explain structural role, link to character revelation.
- Step 2: List letters in the play: (1) Jyoti's letter to Vimal (p.72), (2) Vimal's reply (implied), (3) the principal's official notice (p.80), (4) the protest petition (p.83).
- Step 3: Analyze structural function: letters divide the play into phases—private dilemma, institutional response, collective action.
- Step 4: Analyze character revelation: Jyoti's letter shows introspection; principal's notice shows bureaucratic coldness; petition shows collective courage.
- Step 5: Draft thesis: "Letters function as structural pivots and character mirrors, moving the narrative from private conscience to public resistance."
- Step 6: Write essay using PEEL for each letter, integrating quotes and stage directions.
REASONING: This multi-concept task requires synthesizing nodes 06_002 (structure), 06_004 (character), 06_006 (theme), and 06_009 (symbolism). The motif of letters is a senior-secondary level symbol (not just a plot device).
ANSWER: Letters function as structural pivots and character mirrors, moving the narrative from private conscience to public resistance. Jyoti's handwritten letter to Vimal (Act I) opens the interior space: "मैं ट्यूशन नहीं पढ़ाऊँगी" reveals her moral rupture. The principal's typed notice (Act II)—cold, impersonal, "अनुशासनहीनता"—contrasts bureaucratic power with human vulnerability. The protest petition (Act III), signed collectively, transforms individual dissent into communal claim. Each letter shifts the dramatic focus: private → institutional → collective. Stage directions amplify this: Jyoti writing alone (spotlight), the principal reading with "ठंडी मुस्कान", the crowd holding papers "एकजुट". Thus, the motif structures the three-act arc while exposing each character's relationship to authority.

## COMPETENCY_QUESTION_1
QUESTION: A student writes a character sketch of Vimal stating: "Vimal is weak because he takes tuition." Using the play's evidence, explain why this is a reductive reading and rewrite the sketch (100 words) to show his complexity.
COMPETENCY: Critical analysis and evidence-based revision
STEPS:
- Step 1: Identify the reduction: equating a single action (taking tuition) with a fixed trait (weakness) ignores context.
- Step 2: Find counter-evidence: Vimal refuses to let Jyoti pay for his tuition (p.70), expresses guilt ("मेरा फ़र्ज़ था"), and ultimately joins the protest (p.84).
- Step 3: Articulate complexity: Vimal is trapped by economic necessity but retains moral awareness.
- Step 4: Rewrite using PEEL: Point (Vimal embodies the conflict between survival and dignity), Evidence (his dialogue with Jyoti), Explanation (shows agency within constraints), Link (represents the common teacher's dilemma).
ANSWER: The label "weak" ignores Vimal's economic compulsion and moral struggle. He tells Jyoti, "मेरा फ़र्ज़ था" (p.70), accepting tuition not from greed but duty to family. His guilt surfaces when he avoids her eyes: "नज़रें चुराता है" (stage direction). Yet he ultimately marches in the protest (p.84), reclaiming agency. Vimal thus embodies the conflict between survival and dignity—neither wholly weak nor strong, but humanly trapped.
DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: The play ends with Jyoti leading a protest. Imagine an alternate ending where she accepts the principal's warning. Write a 150-word dialogue scene (with stage directions) for this alternate ending, then write a 50-word justification explaining how this change alters the play's thematic message.
COMPETENCY: Creative adaptation and thematic evaluation
STEPS:
- Step 1: Recall the original ending: Jyoti defies the principal, leads protest (p.84-85).
- Step 2: Design alternate scene: Principal's office, Jyoti submits, signs apology.
- Step 3: Write dialogue showing internal defeat: JYOTI: "मैं माफ़ी माँग लूँगी।" PRINCIPAL: "यही समझदारी है।"
- Step 4: Add stage directions: "JYOTI's hand trembles. The letter—her earlier symbol of resistance—lies crumpled in her bag."
- Step 5: Write justification: The alternate ending shifts theme from "conscience can resist" to "system crushes individual", making the play a tragedy of compliance rather than a drama of awakening.
ANSWER:
[Principal's Office. Day. JYOTI sits, shoulders slumped. PRINCIPAL extends a paper.]
PRINCIPAL: दस्तख़त करो। कल से सब सामान्य।
JYOTI: (whisper) मैं माफ़ी माँग लूँगी।
PRINCIPAL: यही समझदारी है।
[JYOTI signs. Her hand trembles. The letter to Vimal—crumpled—peeks from her bag.]
Justification: This ending transforms the play from a testament to moral courage into a tragedy of surrender, suggesting institutional power is absolute and individual conscience futile—undermining the original's call to collective action.
DIFFICULTY: hard