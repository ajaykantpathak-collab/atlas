## DEFINITION
Irony is a literary device where the intended meaning of words or situations is opposite to their literal or expected meaning, creating a contrast between appearance and reality. Symbolism is the use of concrete objects, characters, or actions to represent abstract ideas, qualities, or concepts beyond their literal sense.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student can identify specific instances of irony and symbolism in Dajju's verses, explain how each device functions to convey the poet's spiritual and social message, and write a structured analytical response connecting these devices to the central themes of devotion and social equality.

## SCOPE_BOUNDARY
This node covers verbal irony, situational irony, and dramatic irony as they appear in Dajju's poetry, along with key symbols like the bird (tqykgk), the body as a cage, and the guru-disciple relationship. It does NOT cover other literary devices like imagery, metaphor, or alliteration (covered in node c11_hin_ar_cbse_09_008), nor does it address the biography of Dajju beyond what illuminates the devices.

## WALKTHROUGH
Imagine you hear someone say "What beautiful weather!" while standing in a torrential downpour — you instantly recognize the gap between words and reality. That gap is irony. Now think of a dove representing peace — the bird is real, but it carries an invisible meaning. In Dajju's poetry, he uses both tools to attack hollow rituals and caste pride. Begin by reading the prescribed verses aloud, marking every line where the literal meaning clashes with the implied meaning (irony) and every concrete image that seems to stand for an abstract truth (symbolism). Ask: "What is the poet really saying beneath the surface?" The key insight is that Dajju's irony exposes hypocrisy while his symbols make the formless divine tangible for the common listener.

## DIAGNOSTIC_QUESTION_1
Define verbal irony and give one example from everyday Hindi conversation (not from the textbook).

## DIAGNOSTIC_ANSWER_1
Verbal irony occurs when a speaker says something but means the opposite, often for critique or humor. Example: A student arriving late to class hears the teacher say, "बहुत जल्दी आ गए आप!" (You've arrived very early!). A wrong answer that merely defines irony as "saying the opposite" without the element of intentional contrast or context reveals the student confuses irony with simple negation or lying.

## DIAGNOSTIC_QUESTION_2
In Dajju's verse where he calls the body a "cage" (पिंजरा) and the soul a "bird" (टिटिहरी/पक्षी), explain why this is symbolism and not just a metaphor. Use the distinction between the two devices.

## DIAGNOSTIC_ANSWER_2
Symbolism operates across the whole work — the bird/cage image recurs and carries the weight of the soul's entrapment in matter, becoming a standing emblem for the human condition. A metaphor is a localized comparison ("life is a journey"). If the student says "both compare two things," they miss that a symbol functions as a persistent, multi-layered signifier woven into the poem's architecture, not a single decorative comparison.

## DIAGNOSTIC_QUESTION_3
Read these two lines from the chapter: "कहत कबीर सुनो भई साधो, सबही खाल की श्वास" and "पोथी पढ़ि पढ़ि जग मुआ, पंडित भया न कोय". Identify the TYPE of irony in each line and justify your classification in one sentence per line.

## DIAGNOSTIC_ANSWER_3
First line: verbal irony — Kabir addresses "holy ones" (साधो) while implying they are far from saintly. Second line: situational irony — the expected outcome (reading scriptures makes one wise) is reversed (the reader dies unenlightened). A wrong answer labeling both as "verbal irony" shows the student cannot distinguish between irony residing in spoken words versus irony residing in the situation's outcome.

## DIAGNOSTIC_QUESTION_4
Compare the symbol of the "bird" (टिटिहरी/पक्षी) in Dajju's poetry with the symbol of the "caged bird" in Maya Angelou's poem "Caged Bird". How does the cultural context shift the symbolic meaning even though the core image is similar?

## DIAGNOSTIC_ANSWER_4
Dajju's bird represents the individual soul (जीवात्मा) yearning for union with the Divine (परमात्मा) — a spiritual liberation from the cycle of birth-death. Angelou's bird symbolizes the African-American struggle against racial oppression — a socio-political liberation. The student who writes "both mean freedom" misses that symbols are culturally coded; the same image carries different freight depending on the belief system and historical moment it emerges from.

## DIAGNOSTIC_QUESTION_5
Critique this student statement: "Dajju uses irony only to mock priests and pandits; it has no positive spiritual function." Defend or refute using evidence from the verses.

## DIAGNOSTIC_ANSWER_5
Refute. Dajju's irony clears false paths so the true path (नाम-स्मरण, गुरु-भक्ति) can shine. Example: mocking external rituals ("माला फेरत जुग भया") creates a vacuum that the positive teaching ("मन का मनका फेर") fills. A student who agrees with the statement sees irony as purely destructive, missing its constructive role in nirguna bhakti — it is a surgical tool, not a sledgehammer.

## DIAGNOSTIC_QUESTION_6
Compose a four-line Hindi couplet (दोहा) that uses BOTH irony and a symbol to convey a message about modern education (e.g., degrees vs. wisdom, coaching vs. understanding). Label which line carries irony and which image is the symbol.

## DIAGNOSTIC_ANSWER_6
Sample: "डिग्री सजे दीवार पे, ज्ञान रहा बेचार / कोचिंग के पिंजरे में, उड़ न पाया सार" — Irony in line 1 (degree displayed but wisdom absent); Symbol: "पिंजरा" (coaching centre as cage trapping the bird of true understanding). A poor answer uses irony and symbol as decoration without integrating them into a coherent critique, showing the student treats devices as ornaments rather than meaning-making tools.

## COMMON_MISCONCEPTION
Students often think any contradiction is irony and any comparison is symbolism. Specifically, they label Dajju's line "काँकर पाथर जोरि के, मस्जिद लई बनाय" as "symbolism of the mosque" — but the mosque here is a literal building, not a symbol; the irony lies in building a house for the Formless using stones. They also confuse the *bird* metaphor in one verse with a *symbol* across the poem, not seeing that a symbol must recur and accrue meaning.

## ON_FAILURE
Step 1: Give the student three clear columns — Literal Meaning / Intended Meaning / Device Name. Step 2: Take one verse (e.g., "पोथी पढ़ि पढ़ि जग मुआ") and fill the columns together: Literal = reading books till death; Intended = bookish knowledge fails to give liberation; Device = Situational Irony. Step 3: For symbolism, ask: "Does this image appear in 3+ verses? Does it carry the poem's central idea?" If yes, it's a symbol. Step 4: Practice with two new verses, letting the student fill columns independently, then discuss.

## BUILDS_ON
c11_hin_ar_cbse_09_008 (Literary Devices: Imagery and Metaphor) — students must already distinguish metaphor (local comparison) from symbol (recurring, structural signifier).

## LEADS_TO
c11_hin_ar_cbse_09_013 (Critical Thinking: Analysis and Interpretation) — irony and symbolism are core tools for the deeper interpretive tasks in that node.

## PREREQUISITE_NODE_IDS
c11_hin_ar_cbse_09_001, c11_hin_ar_cbse_09_002, c11_hin_ar_cbse_09_008, c11_hin_ar_cbse_09_003, c11_hin_ar_cbse_09_007

## PREREQUISITE_REASONS
c11_hin_ar_cbse_09_001: Provides historical context of Nirguna Bhakti and Dajju's social milieu, essential to decode why he uses irony against ritualism.
c11_hin_ar_cbse_09_002: Establishes the narrative structure of the verses so students can locate where irony/symbolism appear in the poem's progression.
c11_hin_ar_cbse_09_008: Teaches metaphor and imagery — prerequisite to understanding how symbolism extends and differs from metaphor.
c11_hin_ar_cbse_09_003: Irony (the small lamp containing infinite fire) and symbolism (fire = knowledge/purification) deepen the atmospheric complexity; they require the atmosphere baseline established here.  
c11_hin_ar_cbse_09_007: Irony and symbolism operate at the intersection of primary and secondary themes (e.g., "sharp knife" symbolizes both simplicity and violence against hierarchy).  

## FORWARD_NODE_IDS
c11_hin_ar_cbse_09_012, c11_hin_ar_cbse_09_013, c11_hin_ar_cbse_09_014, c12_hin_a_cbse_05_009, c12_hin_a_cbse_10_009, c12_hin_al_cbse_01_009, c12_hin_ar_cbse_09_009, c12_hin_ar_cbse_12_009, c12_hin_ar_cbse_03_013

## FORWARD_REASONS
c11_hin_ar_cbse_09_012: Comprehension questions require identifying and explaining irony/symbolism in specific lines.
c11_hin_ar_cbse_09_013: Critical analysis tasks demand evaluating how these devices shape the poem's philosophical argument.
c11_hin_ar_cbse_09_014: Writing tasks (analytical paragraph, essay) require using irony/symbolism as evidence for thematic claims.
c12_hin_a_cbse_05_009: अगला तार्किक चरण: Irony is a literary device where the intended meaning of words or a situation is opposite to their l... इस नोड की अवधारणाओं को सीधे उपयोग/विस्तारित करता है।  
c12_hin_a_cbse_10_009: Chapter 9 connected irony to authorial intent — critical for evaluating narrator's choices.  
c12_hin_al_cbse_01_009: Class 11 Antra Chapter 9 Irony and Symbolism node introduces comparative analysis.  
c12_hin_ar_cbse_09_009: Consolidates Class 11 board-style questions on both devices.  
c12_hin_ar_cbse_12_009: अगला तार्किक चरण: Irony in this story is the contrast between appearance and reality — where the wealthy waste water c... इस नोड की अवधारणाओं को सीधे उपयोग/विस्तारित करता है।  
c12_hin_ar_cbse_03_013: 8/9 Literary Devices nodes (c11_hin_ar_cbse_08_008, c11_hin_ar_cbse_08_009, c11_hin_ar_cbse_09_008, c11_hin_ar_cbse_09_009) and practice "device → effect → meaning" chains on isolated lines before full poems.  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
none

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_09_001 -> c11_hin_ar_cbse_09_002 -> c11_hin_ar_cbse_09_008 -> c11_hin_ar_cbse_09_009 -> c11_hin_ar_cbse_09_012 -> c11_hin_ar_cbse_09_013 -> c11_hin_ar_cbse_09_014

## THIS_FORMULA
N/A - conceptual

## FORMULA_VARIABLES
N/A

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
conceptual

## CROSS_SUBJECT
c11_history_medieval_bhakti | The Nirguna Bhakti movement's critique of ritualism (irony) and use of everyday symbols (charkha, bird, loom) mirrors Dajju's poetic strategy — history explains the *why* behind the devices.
c11_sociology_indian_social_structure | Dajju's irony targets caste hierarchy (varna/jati); sociology provides the structural framework to analyze how literary devices function as social resistance.

## PREREQ_CONCEPT
Distinction between metaphor (single-point comparison) and symbol (recurring, multi-valent signifier) from c11_hin_ar_cbse_09_008.

## PREREQ_BEFORE
Student must be able to identify a metaphor in a Hindi poem and explain its two terms (tenor and vehicle).

## PREREQ_STUCK
Review the "Metaphor vs. Symbol" table in c11_hin_ar_cbse_09_008 and practice labeling five images from any Hindi poem as metaphor or symbol with justification.

## WORKED_EXAMPLE_1
PROBLEM: Analyze the irony in the verse: "माला फेरत जुग भया, फिरा न मन का फेर / कर का मनका डार दे, मन का मनका फेर". Identify the type, explain the contrast, and state its thematic function.

STEPS:
- Step 1: Identify the literal action described — rotating a rosary (माला फेरना) for ages (जुग भया).
- Step 2: Identify the stated result — the mind's orientation (मन का फेर) has not changed.
- Step 3: Classify the irony — situational irony, because the expected outcome (rosary leads to inner transformation) is contradicted by the actual outcome (no inner change).
- Step 4: Explain the verbal irony in the imperative — "कर का मनका डार दे" (discard the hand's bead) uses verbal irony: the speaker tells the listener to throw away the very object they revere, highlighting its futility.
- Step 5: Connect to theme — the irony dismantles external ritual (बाह्य आडंबर) to establish internal devotion (अंतरंग भक्ति) as the true path, core to Nirguna Bhakti.
REASONING: The step-by-step isolation of literal vs. intended meaning trains the student to see irony as a structural gap, not just a clever phrase. Linking the two irony types (situational + verbal) in one verse shows density of technique.
ANSWER: The verse employs situational irony (lifelong rosary fails to turn the mind) and verbal irony (command to discard the rosary). Together they enact the Nirguna argument: mechanical ritual is sterile; only the "bead of the mind" (मन का मनका) — constant remembrance — liberates.

## WORKED_EXAMPLE_2
PROBLEM: Trace the symbol of the "bird" (पक्षी/टिटिहरी) across three verses in the chapter. For each occurrence, note the context and explain how the symbol's meaning deepens.

STEPS:
- Step 1: Locate Verse 1 where the bird is called "दास कबीर का टिटिहरी" — context: the poet identifies himself as a humble bird calling out in the wilderness; meaning: the devotee's voice is small but persistent.
- Step 2: Locate Verse 2 where the bird is "पिंजरे में बंद पक्षी" — context: the body is a cage, the soul trapped; meaning: the human condition of spiritual entrapment in matter.
- Step 3: Locate Verse 3 where the bird "उड़ गया आकाश में" — context: guru's grace releases the soul; meaning: liberation (मोक्ष) as the bird's natural flight toward the infinite.
- Step 4: Synthesize — the symbol evolves from identity (poet as bird) to condition (soul in cage) to destiny (freed soul), creating a narrative arc for the spiritual journey.
- Step 5: Verify against theme — each stage reinforces the central message: recognition of entrapment → need for guru → liberation through grace.
REASONING: Tracking a symbol across multiple verses prevents the "single-verse metaphor" error. The three-stage arc (identity → bondage → freedom) shows how Dajju builds a coherent symbolic system, not isolated images.
ANSWER: The bird symbol progresses through three phases: (1) Self-identification — "I am Kabir's tittihari" (humble messenger); (2) Existential state — soul caged in body (bondage); (3) Liberated state — flight into the sky (moksha via guru-kripa). This triadic movement structures the poem's spiritual argument.

## WORKED_EXAMPLE_3
PROBLEM: A board exam question asks: "Dajju's irony is not merely satirical; it is soteriological (liberation-oriented)." Write a 120-word analytical paragraph using two verses to prove this claim. Follow the PEEL structure.

STEPS:
- Step 1: P (Point) — Draft a topic sentence stating the thesis: Dajju's irony exposes false paths to clear space for the true path of naam-bhakti.
- Step 2: E (Evidence) — Select Verse A: "पोथी पढ़ि पढ़ि जग मुआ" (situational irony: scriptural learning ≠ wisdom) and Verse B: "काँकर पाथर जोरि के" (verbal/situational irony: building a mosque for the Formless).
- Step 3: E (Explanation) — For each verse, explain the irony mechanism and then pivot to the positive alternative implied: Verse A implies "गुरु का शब्द" (guru's word); Verse B implies "दिल में बसे" (indwelling divine).
- Step 4: L (Link) — Conclude by linking both verses to the soteriological aim: irony functions as "apophatic theology" — saying what God is not (not in books, not in stones) to point toward what God is (in the heart, in the guru's word).
- Step 5: Polish — Check word count, ensure Hindi terms (सगुण/निर्गुण, शब्द, गुरु-कृपा) are used correctly, and verify PEEL flow.
- Step 6: Self-assess against marking scheme — does it have Point, two Evidences, Explanation linking irony to liberation, and Link back to thesis?
REASONING: This example models the exact board-exam skill: writing a compact, evidence-rich analytical paragraph under word limit. The six steps mirror the cognitive process: thesis → evidence selection → device analysis → thematic synthesis → linguistic precision → exam-readiness check.
ANSWER: Dajju's irony is soteriological because it negates false means (books, temples) to affirm the true means (naam, guru). In "पोथी पढ़ि पढ़ि जग मुआ", situational irony shows scriptural erudition fails to conquer death; the implied alternative is the guru's spoken word (शब्द) that awakens. In "काँकर पाथर जोरि के", verbal irony mocks building a stone mosque for the Formless; the implied truth is the divine indwells the heart (दिल में बसे). Both ironies perform apophatic clearing — stripping away externals so the internal path (मन का मनका फेर) stands revealed. Thus irony is not satire for its own sake but a surgical instrument for liberation.

## COMPETENCY_QUESTION_1
QUESTION: In the verse "जाति न पूछो साधु की, पूछ लीजिए ज्ञान / मोल करो तलवार का, पड़ा रहन दो म्यान", identify the literary device in the second line and explain how it functions as both a symbol and an ironic statement about social hierarchy.

COMPETENCY: Literary Analysis — Device Identification and Thematic Integration
STEPS:
- Step 1: Identify the device in "मोल करो तलवार का, पड़ा रहन दो म्यान" — it is a symbolic metaphor where तलवार = true knowledge/character, म्यान = caste/externals.
- Step 2: Explain the symbolism — the sword's value lies in its edge (knowledge), not its sheath (caste); the sheath is necessary for protection but irrelevant to the sword's essence.
- Step 3: Identify the irony — situational irony: society values the sheath (caste) over the sword (merit), reversing the logical order of worth.
- Step 4: Connect to Dajju's Nirguna stance — the verse enacts the movement's core principle: spiritual worth transcends birth; irony exposes the social lie, symbol offers the alternative criterion.
ANSWER: The second line uses a sustained symbol (sword/sheath) wrapped in situational irony. Symbolically, तलवार = ज्ञान/गुण (intrinsic worth), म्यान = जाति/वर्ण (accidental covering). Ironically, society prices the sheath and ignores the blade — a reversal of true value. Dajju thus uses the device to dismantle caste hierarchy and establish merit-based spiritual equality.
DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: Compare the use of the "body as cage" symbol in Dajju's poetry with its use in the Katha Upanishad (रथ रूपक: शरीरं रथम् विद्धि). How does the shift from a chariot (रथ) to a cage (पिंजरा) reflect a change in the metaphysical view of the body from classical Vedanta to Nirguna Bhakti? Write a 150-word comparative analysis.

COMPETENCY: Cross-Textual Comparative Analysis — Symbol Evolution Across Traditions
STEPS:
- Step 1: Recall the Katha Upanishad metaphor — body = chariot (रथ), intellect = charioteer (सारथि), senses = horses (इन्द्रिय-घोड़े), self = passenger (आत्मा). The body is a *vehicle* for the journey.
- Step 2: Recall Dajju's symbol — body = cage (पिंजरा), soul = bird (पक्षी). The body is a *prison* from which the soul must escape.
- Step 3: Analyze the metaphysical shift — Chariot implies the body is a necessary, controllable instrument for reaching the goal (Karma/Jnana Yoga). Cage implies the body is an obstacle, a source of bondage (Bhakti/Yoga of surrender).
- Step 4: Link to theological difference — Upanishad: self-mastery through discipline (यम/नियम). Dajju: self-surrender through grace (गुरु-कृपा, नाम-स्मरण). The symbol encodes the shift from *effort* to *grace*.
- Step 5: Synthesize in 150 words — structure: opening thesis, Upanishad symbol, Dajju symbol, philosophical contrast, concluding implication for spiritual practice.
ANSWER: The Katha Upanishad's chariot (रथ) symbolizes the body as a disciplined vehicle — intellect guides the sense-horses, carrying the passenger-self toward Brahman. Mastery of the chariot is the path. Dajju replaces the chariot with a cage (पिंजरा): the body entraps the bird-soul, and liberation comes not by driving the cage but by the guru opening the door. The chariot affirms the body's instrumental value in a framework of self-effort (ज्ञान/कर्म योग); the cage negates it in a framework of grace (भक्ति/प्रपत्ति). This symbolic shift marks the historical transition from Vedantic self-power to Nirguna Bhakti's other-power — from "I must steer" to "He must release." The cage thus becomes a potent symbol of the devotee's helplessness and the guru's necessity.
DIFFICULTY: hard