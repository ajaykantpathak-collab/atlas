## DEFINITION
Secondary themes are subsidiary central ideas that run parallel to the primary theme in a literary work, exploring related social, psychological, or philosophical issues to add depth, complexity, and realism to the narrative. They are not the main message but complement it by illuminating different facets of the human condition depicted in the story.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student can independently identify at least two distinct secondary themes in "Phulwari," cite specific textual evidence (dialogue, incident, or character action) for each, and explain in writing how each secondary theme intersects with and enriches the primary theme of social hypocrisy and exploitation.

## SCOPE_BOUNDARY
This node covers the identification, textual substantiation, and analytical explanation of secondary themes in Nirmal Verma's "Phulwari" (Chapter 2, Aroh). It does not cover the primary theme (addressed in node 006), detailed literary device analysis (nodes 008, 009), or grammar/vocabulary (nodes 010, 011).

## WALKTHROUGH
Imagine you are reading a newspaper report about a 12-year-old girl working in a middle-class household, making flower garlands for temples, while the family's children go to school. You feel a mix of anger and helplessness. Now, open "Phulwari" and ask: beyond the obvious injustice, what other quiet tragedies does the story whisper about? Begin by listing every recurring concern that is not the main plot — Phulwari's illiteracy, the pandit's greed, the narrator's complicit silence, the ritualistic use of flowers. Group these into 2-3 broad ideas (e.g., "stolen childhood," "hollow religiosity"). For each, find two precise moments in the text where it surfaces. Finally, write one paragraph per secondary theme showing how it deepens the primary theme of systemic exploitation.

## DIAGNOSTIC_QUESTION_1
What is the definition of a secondary theme in literature, and how does it differ from the primary theme?

## DIAGNOSTIC_ANSWER_1
A secondary theme is a subsidiary central idea that supports and enriches the primary theme by exploring related issues; the primary theme is the dominant, overarching message of the work. A wrong answer that equates secondary themes with subplots or minor characters reveals a confusion between narrative structure (what happens) and thematic structure (what the work means).

## DIAGNOSTIC_QUESTION_2
In "Phulwari," the primary theme is the exploitation of the marginalized by the privileged. Explain in your own words how the theme of "hollow religiosity" functions as a secondary theme in the story.

## DIAGNOSTIC_ANSWER_2
Hollow religiosity appears when characters use religious rituals (garland-making, temple offerings) to mask their cruelty or indifference toward Phulwari, turning sacred acts into tools of exploitation. A wrong answer that merely lists religious symbols without linking them to the characters' hypocrisy shows the student cannot distinguish motif from theme.

## DIAGNOSTIC_QUESTION_3
Apply the concept of secondary themes to a new context: In a story about a migrant construction worker building a luxury mall, the primary theme is economic disparity. Propose one plausible secondary theme and describe two specific scenes that would illustrate it.

## DIAGNOSTIC_ANSWER_3
A plausible secondary theme is "invisible labor erasing identity." Scene 1: The worker's name is never used; he is called only "mistri" or "oye." Scene 2: His fingerprints on the marble are wiped away before the inauguration. A wrong answer that suggests "friendship among workers" without showing how it connects to economic disparity reveals an inability to anchor secondary themes to the primary theme.

## DIAGNOSTIC_QUESTION_4
Analyze the relationship between the secondary theme of "stolen childhood" and the primary theme of exploitation in "Phulwari." Use two distinct textual references to support your analysis.

## DIAGNOSTIC_ANSWER_4
Stolen childhood intensifies exploitation by showing its intergenerational impact: Phulwari makes garlands for gods she cannot name (showing denied education) and mimics adult bargaining language (showing forced maturity). A wrong answer that treats the two themes as parallel but unrelated indicates failure to see thematic layering.

## DIAGNOSTIC_QUESTION_5
Evaluate the author's choice to make the narrator an educated, sympathetic observer who ultimately does nothing to change Phulwari's condition. How does this narrative decision strengthen or weaken the secondary theme of "complicit silence"?

## DIAGNOSTIC_ANSWER_5
It strengthens the theme by implicating the reader's own class: the narrator's inaction mirrors the reader's passive consumption of the story, making complicity visceral. A wrong answer that calls the narrator "kind" because he notices her suffering misses the critical edge of Verma's irony.

## DIAGNOSTIC_QUESTION_6
Create a 4-line dialogue between Phulwari and the narrator ten years later that reveals the long-term consequence of the secondary theme "education as an unattainable privilege."

## DIAGNOSTIC_ANSWER_6
Phulwari: "Didi, mere bachche bhi phool gूंthte hain." Narrator: "Par maine to socha tha tum padh likh jaogi." Phulwari: "Sapne bhi to phool jaise hi toot-te hain." Narrator: (chup rehti hai). A poor answer that gives Phulwari a happy ending ignores the story's realistic trajectory and the theme's tragic weight.

## COMMON_MISCONCEPTION
Students often believe any recurring topic (e.g., "flowers," "poverty," "temple") is automatically a secondary theme. They fail to grasp that a theme must be a complete idea — a statement about the topic (e.g., "flowers become instruments of exploitation" not just "flowers"). This error arises because textbooks sometimes list "themes" as single words, and students memorize labels without converting them into thematic statements.

## ON_FAILURE
1. Ask the student to write "Flowers are..." and complete the sentence with what the story proves about flowers. 2. Have them do the same for "Education is...", "Religion is...", "Childhood is...". 3. Discard completions that are mere plot summaries; keep only those that express a judgment or insight. 4. Show how each surviving statement connects to the primary theme of exploitation.

## BUILDS_ON
Primary theme identification and character analysis (nodes 004, 005, 006) provide the foundation for recognizing how secondary themes extend the central argument.

## LEADS_TO
Analysis of literary devices (nodes 008, 009) and critical interpretation (node 013) where thematic evidence is drawn from imagery, irony, and symbolism.

## PREREQUISITE_NODE_IDS
c11_hin_ar_cbse_02_002, c11_hin_ar_cbse_02_004, c11_hin_ar_cbse_02_005, c11_hin_ar_cbse_02_006
## PREREQUISITE_REASONS
c11_hin_ar_cbse_02_002: Plot knowledge is needed to locate thematic incidents. c11_hin_ar_cbse_02_004: Protagonist's actions and speech reveal thematic concerns. c11_hin_ar_cbse_02_005: Supporting characters embody competing values that generate secondary themes. c11_hin_ar_cbse_02_006: Primary theme must be established first to distinguish secondary themes from it.
c11_hin_ar_cbse_02_004: Character analysis of the protagonist involves a systematic examination of the central cha... की समझ आवश्यक है, क्योंकि यह नोड (Secondary themes are subsidiary central ideas that run parallel to the primary theme in a...) इसी आधार पर आगे बढ़ता है।  
c11_hin_ar_cbse_02_005: Secondary themes (dignity of labor, resistance through silence, identity as performance) emerge through supporting character arcs  
c11_hin_ar_cbse_02_006: Secondary themes branch out from the primary theme once it is clearly identified.  

## FORWARD_NODE_IDS
c11_hin_ar_cbse_02_008, c11_hin_ar_cbse_02_009, c11_hin_ar_cbse_02_013, c11_hin_ar_cbse_02_015, c12_hin_a_cbse_01_007, c12_hin_a_cbse_08_007, c12_hin_a_cbse_10_007, c12_hin_a_cbse_12_007, c12_hin_a_cbse_17_007, c12_hin_al_cbse_01_007, c12_hin_al_cbse_03_007, c12_hin_ar_cbse_01_007, c12_hin_ar_cbse_02_006, c12_hin_ar_cbse_02_007, c12_hin_ar_cbse_07_007, c12_hin_ar_cbse_08_007, c12_hin_ar_cbse_11_007

## FORWARD_REASONS
c11_hin_ar_cbse_02_008: Imagery and metaphor are the primary vehicles through which secondary themes are conveyed. c11_hin_ar_cbse_02_009: Irony and symbolism deepen the thematic resonance of secondary ideas. c11_hin_ar_cbse_02_013: Critical thinking requires synthesizing primary and secondary themes into a coherent interpretation.
c11_hin_ar_cbse_02_015: Secondary themes (exploitation, deception, oral vs. written tradition) enrich counter-arguments and complication moves.  
c12_hin_a_cbse_01_007: Chapter 2 (Class 11) practiced tracking multiple themes across a longer narrative.  
c12_hin_a_cbse_08_007: अगला तार्किक चरण: Secondary themes are the underlying, complementary ideas in a literary work that support, contrast w... इस नोड की अवधारणाओं को सीधे उपयोग/विस्तारित करता है।  
c12_hin_a_cbse_10_007: Reinforces theme identification across diverse texts (memoir, story, essay).  
c12_hin_a_cbse_12_007: Another Class 11 example reinforces thematic pattern recognition across stories.  
c12_hin_a_cbse_17_007: Another Class 11 chapter practiced thematic layering in a different text.  
c12_hin_al_cbse_01_007: Class 11 practice with "मियाँ नसीरुद्दीन" secondary themes (communal harmony vs prejudice)  
c12_hin_al_cbse_03_007: Practice with thematic layers in a different text.  
c12_hin_ar_cbse_01_007: Exposure to multiple texts in Class 11 develops comparative theme-spotting skill.  
c12_hin_ar_cbse_02_006: Class 11 practice in distinguishing primary from secondary themes.  
c12_hin_ar_cbse_02_007: Class 11 practice in identifying secondary themes in other poems builds the analytical habit.  
c12_hin_ar_cbse_07_007: Practice with multiple theme strands in Chapter 2  
c12_hin_ar_cbse_08_007: Exposure to folk-culture themes in "Miyan Nasiruddin" prepares students for Phani Kumar's similar concerns.  
c12_hin_ar_cbse_11_007: Class 11 practice with "Miyan Nasiruddin" builds skill in tracking multiple themes.  
c11_hin_ar_cbse_02_009: अगला तार्किक चरण: Irony in "फेंकू उल्हनिहु" is the contrast between appearance and reality where Phenku's mastery of b... इस नोड की अवधारणाओं को सीधे उपयोग/विस्तारित करता है।  
c11_hin_ar_cbse_02_013: Secondary themes add nuance; critical interpretation weaves them into the primary argument.  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
none

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_02_006 -> c11_hin_ar_cbse_02_007 -> c11_hin_ar_cbse_02_008

## THIS_FORMULA
N/A - conceptual

## FORMULA_VARIABLES
N/A

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
analytical

## CROSS_SUBJECT
c11_history_colonialism | The story reflects the disruption of traditional livelihoods and the emergence of a marginalized servant class under colonial modernity, paralleling historical shifts in labor relations.
c11_sociology_social_stratification | Phulwari's position illustrates intersectional marginalization — caste, class, gender, and age — providing a literary case study for sociological concepts of structural inequality.

## PREREQ_CONCEPT
The student must understand that a theme is a complete declarative statement about a universal idea, not a single word or topic.

## PREREQ_BEFORE
The student must have read the full story "Phulwari" and completed the primary theme analysis (node 006).

## PREREQ_STUCK
If stuck, review the primary theme statement from node 006 and the character sketches of Phulwari and the narrator from nodes 004 and 005.

## WORKED_EXAMPLE_1
PROBLEM: Identify and analyze the secondary theme of "hollow religiosity" in "Phulwari" with textual evidence.
STEPS:
- Step 1: Recall the primary theme — exploitation of the marginalized by the privileged through systemic hypocrisy.
- Step 2: Scan the text for repeated religious references: temple garlands, pandit's rituals, Phulwari's work as "seva."
- Step 3: Select two key moments: (a) The pandit rejects Phulwari's garlands for minor flaws while accepting her labor; (b) The narrator notes the flowers are for "bhagwan" but the transaction is purely commercial.
- Step 4: Formulate the thematic statement: "Religious rituals are reduced to commercial transactions that justify exploitation."
- Step 5: Explain how this deepens the primary theme: It shows exploitation is sanctified, making resistance harder because it appears sacrilegious.
REASONING: This step-by-step moves from known (primary theme) to pattern recognition (religious motifs) to evidence selection to thematic articulation to synthesis — mirroring the analytical process required in board exams.
ANSWER: Secondary theme: "Religious rituals mask and legitimize economic exploitation." Evidence 1: Pandit's scrutiny of garland quality while ignoring the child's hunger. Evidence 2: Narrator's observation that flowers reach god only after passing through market hands. Connection: This sanctification of labor makes the primary theme of exploitation more insidious and systemic.

## WORKED_EXAMPLE_2
PROBLEM: Trace the secondary theme of "language as a tool of power" through Phulwari's interactions.
STEPS:
- Step 1: List all scenes where language differences are highlighted: Phulwari's dialect vs. narrator's standard Hindi, pandit's Sanskritized commands, the English-medium school reference.
- Step 2: Identify the power dynamic in each: Who speaks, who is silenced, who corrects whom.
- Step 3: Choose two contrasting moments: (a) Phulwari uses respectful "aap" but is addressed as "tu"; (b) Narrator thinks in polished Hindi but speaks to her in simplified commands.
- Step 4: Articulate the theme: "Linguistic hierarchy reinforces social hierarchy, denying the marginalized even the dignity of equal speech."
- Step 5: Link to primary theme: Language inequality makes exploitation invisible by normalizing the master-servant speech code.
REASONING: The example demonstrates how to derive a theme from a linguistic pattern rather than a plot event, a higher-order skill tested in competency questions.
ANSWER: Secondary theme: "Language encodes and enforces power relations." Evidence: Phulwari's "I+kQjekb,A" (respectful) vs. narrator's "vkils oqQN ,d loky iwNus Fks" (casual command). The narrator's internal monologue uses complex syntax while his speech to her is reductive. This linguistic apartheid naturalizes the exploitation central to the primary theme.

## WORKED_EXAMPLE_3
PROBLEM: Compare the secondary themes of "stolen childhood" and "complicit silence" and evaluate which more effectively indicts the educated middle class.
STEPS:
- Step 1: Define each theme with a full statement: (A) "Childhood is stolen when survival forces adult responsibilities on a child." (B) "Silence of the privileged witness makes them accomplices to injustice."
- Step 2: Map textual evidence for A: Phulwari making garlands at dawn, knowing flower rates, bargaining like an adult, her rhyme about three schools she never attended.
- Step 3: Map evidence for B: Narrator's internal outrage but external inaction, his offering tea instead of advocacy, the final scene where he watches her leave without intervention.
- Step 4: Analyze narrative technique: Verma uses free indirect discourse for the narrator's guilt, but Phulwari's stolen childhood is shown through objective action — making A more visible, B more unsettling.
- Step 5: Evaluate: Complicit silence more directly indicts the middle class because it implicates the narrator (and by extension the reader) as active participants, whereas stolen childhood evokes pity which can be passively felt.
- Step 6: Conclude: Both are essential; A shows the victim's reality, B shows the perpetrator's psychology.
REASONING: This multi-step comparison requires evaluating thematic function and narrative strategy — exactly the "analysis and interpretation" competency tested in board exams.
ANSWER: "Complicit silence" is the sharper indictment. While "stolen childhood" (evidenced by Phulwari's adult vocabulary and lost schooling) generates sympathy, "complicit silence" (evidenced by the narrator's tea offering and final inaction) generates uncomfortable self-recognition in the target reader. Verma's use of the narrator's educated consciousness as the locus of silence makes the middle class complicity inescapable.

## COMPETENCY_QUESTION_1
QUESTION: In "Phulwari," the narrator observes Phulwari making garlands for a temple festival. He thinks, "These flowers will adorn the deity, but the hands that strung them will never enter the sanctum." Identify the secondary theme this reflection illuminates. Then, using one other incident from the story, explain how Verma uses the contrast between sacred space and marginalized labor to deepen the primary theme of exploitation.
COMPETENCY: Analytical interpretation with textual synthesis
STEPS:
- Step 1: Identify the secondary theme from the quoted reflection (sacred/profane divide or hollow religiosity).
- Step 2: Recall another incident where temple/ritual space excludes Phulwari (e.g., pandit's rejection, festival procession).
- Step 3: Explain the structural contrast: sacred output vs. profane labor conditions.
- Step 4: Argue how this contrast exposes exploitation as culturally sanctioned.
ANSWER: The reflection illuminates the secondary theme "hollow religiosity" or "sacralization of exploitation." Another incident: During the festival, Phulwari watches the procession from behind a wall — her garlands on the deity, her body barred from the space. Verma juxtaposes the flower's sanctified journey with the child's excluded body, proving that exploitation is not merely economic but ritualistically ordained. This makes the primary theme systemic rather than individual.
DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: A critic argues that "Phulwari" is not about exploitation but about the resilience of the human spirit, citing Phulwari's rhyme about three schools and her final assertive question to the narrator. Evaluate this reading by analyzing how the secondary themes of "stolen childhood" and "education as privilege" either support or contradict the resilience interpretation. Conclude with your reasoned judgment.
COMPETENCY: Critical evaluation of competing interpretations
STEPS:
- Step 1: Summarize the critic's claim (resilience focus).
- Step 2: Analyze the rhyme scene: Phulwari recites a fantasy of schooling — does it show resilience or highlight absence?
- Step 3: Analyze the final question: "D;k ge lhèks&lhèks ukuckbZ dk gquj lh[k tkrs!" — is this defiance or despair?
- Step 4: Weigh evidence: The rhyme is a "what if" not a reality; the final outburst acknowledges systemic trap.
- Step 5: Judge: The resilience reading romanticizes survival; the secondary themes frame her agency within structural impossibility.
ANSWER: The resilience reading collapses under the weight of the secondary themes. Phulwari's school rhyme ("u dPph esa cSBk / u cSBk og iDdh esa / u nwljh esa / vkSj tk cSBk rhljh esa") is a lament disguised as play — it enumerates what she *cannot* have. Her final challenge ("Do we serve only the illiterate?") is not empowerment but a bitter diagnosis of her trapped condition. The secondary themes of stolen childhood and education-as-privilege prove her spirit is not "resilient" in a redemptive sense but *crushed yet conscious* — a far more damning indictment of the social order. The critic mistakes articulate suffering for triumph.
DIFFICULTY: hard