## DEFINITION
Character analysis of the protagonist involves examining the narrator's personality, motivations, development, and role in conveying the central theme through their actions, reflections, and interactions with other characters in an autobiographical or narrative text.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student must independently identify at least three distinct character traits of Nehru as protagonist, support each with specific textual evidence from different sections of the chapter, and explain how his character evolution reveals the theme of unity in diversity.

## SCOPE_BOUNDARY
This node covers character analysis of Jawaharlal Nehru as the narrator-protagonist in "Bharat Mata" (Chapter 8, Aroh), focusing on his intellectual journey, empathetic engagement with common people, and evolving understanding of nationalism. It does NOT cover supporting characters, thematic analysis beyond character-theme linkage, or literary devices.

## WALKTHROUGH
Imagine you are sitting with your grandfather who tells you about his journey across India in the 1930s—he describes meeting a farmer in a dusty village who shouts "Bharat Mata ki Jai" and when asked who Bharat Mata is, the farmer points to himself and his neighbors. You realize the storyteller isn't just recounting events; he's revealing how his own thinking changed. That's exactly what we do here: we trace Nehru's journey from an intellectual observing India to a leader who internalizes that India is its people. Start by marking every first-person statement ("मैंने देखा", "मैं सोचता था", "मेरी समझ में आया")—these are your evidence anchors. Then group them into phases: initial curiosity, confrontation with reality, and final realization. The key insight: the protagonist's character arc IS the chapter's argument about nationalism.

## DIAGNOSTIC_QUESTION_1
Who is the protagonist of the chapter "Bharat Mata" and what is his primary role in the narrative?

## DIAGNOSTIC_ANSWER_1
The protagonist is Jawaharlal Nehru, who serves as the first-person narrator traveling across pre-independence India, engaging with peasants and workers, and undergoing an intellectual transformation about the meaning of "Bharat Mata." A wrong answer (e.g., "Bharat Mata is the protagonist" or "the peasant is the protagonist") reveals the student confuses the symbolic figure or a supporting character with the narrative consciousness driving the text.

## DIAGNOSTIC_QUESTION_2
Explain in your own words how Nehru's understanding of "Bharat Mata" changes from the beginning to the end of his travels.

## DIAGNOSTIC_ANSWER_2
Initially, Nehru approaches "Bharat Mata" as an abstract concept—geography, history, culture—and asks people to define it intellectually. Through repeated encounters, especially with the peasant who identifies Bharat Mata with the people themselves, he realizes Bharat Mata is not land or legend but the living millions—their suffering, aspirations, and unity. A wrong answer that only describes the peasant's definition without tracing Nehru's internal shift shows the student treats the text as information transfer rather than a character's epistemic journey.

## DIAGNOSTIC_QUESTION_3
Identify two specific incidents from the chapter where Nehru's interaction with ordinary Indians reveals a trait of his character. Name the trait and quote the evidence.

## DIAGNOSTIC_ANSWER_3
Incident 1: Nehru asks peasants "Who is Bharat Mata?" and listens patiently to their confused but profound answers—trait: intellectual humility and empathy. Evidence: "मैं उनसे पूछता... वे चकरा जाते... लेकिन उनकी आँखों में एक चमक आ जाती." Incident 2: He describes traveling "from the Khyber Pass to Kanyakumari" meeting "millions like me"—trait: solidarity with common people despite elite background. Evidence: "मैं उन लाखों लोगों में से एक हूँ... जो इस विशाल देश में रहते हैं." A wrong answer listing traits without textual anchoring or citing only the peasant's words (not Nehru's actions) shows inability to distinguish character revelation from plot summary.

## DIAGNOSTIC_QUESTION_4
Compare Nehru's initial intellectual framework for understanding India (historical, geographical, cultural) with the framework he adopts after his travels. What does this shift reveal about his character development?

## DIAGNOSTIC_ANSWER_4
Initially, Nehru frames India through "history, geography, culture, rivers, mountains"—an external, scholarly lens. Post-travels, he frames India through "people, their joys and sorrows, their unity despite diversity"—an internal, humanistic lens. This shift reveals his character evolving from a detached observer to an empathetic participant who validates lived experience over textbook categories. A wrong answer that only lists the two frameworks without analyzing what the transition says about Nehru's growing political maturity misses the analytical demand.

## DIAGNOSTIC_QUESTION_5
Evaluate whether Nehru's final conclusion—"Bharat Mata is essentially these millions of people"—is a genuine discovery or a rhetorical strategy to forge national unity. Justify with textual evidence.

## DIAGNOSTIC_ANSWER_5
It is a genuine discovery grounded in lived encounter, not mere rhetoric. Evidence: Nehru admits initial confusion ("मेरी समझ में नहीं आता था"), describes the peasant's answer as revelatory ("एक गँवार किसान ने... मेरी आँखें खोल दीं"), and frames his realization as personal ("मैंने समझा"). The iterative process—repeated questioning, genuine surprise, gradual conviction—marks authentic epistemological change. A wrong answer claiming it's "just political speech" ignores the text's confessional tone and the protagonist's documented intellectual honesty, revealing the student's cynicism overriding textual evidence.

## DIAGNOSTIC_QUESTION_6
Write a 150-word diary entry from Nehru's perspective on the night after the peasant defines Bharat Mata as "us people," capturing his internal conflict and resolution.

## DIAGNOSTIC_ANSWER_6
A strong entry uses first-person voice, references the specific encounter (dusty road, peasant's weathered face, the phrase "Bharat Mata ki jai"), shows intellectual conflict ("All my books on Indian civilization never prepared me for this"), and resolves with transformed understanding ("Tonight I don't see a map—I see faces"). It should mirror Nehru's reflective, lyrical prose style. A poor entry writes in third person, genericizes the encounter ("met a villager"), or skips the conflict—revealing the student cannot inhabit the protagonist's consciousness or distinguish diary reflection from narrative summary.

## COMMON_MISCONCEPTION
Students conflate "Bharat Mata" (the symbol) with the protagonist, treating the chapter as a description of a goddess rather than a portrait of Nehru's mind. They write: "The protagonist is Bharat Mata, who represents India's unity." This error arises because the title centers the symbol, the peasant's voice is powerful, and Nehru's self-effacing tone ("मैं घूमता रहा," "मैं पूछता रहा") makes his agency invisible. The misconception is reinforced when teachers ask "What does Bharat Mata mean?" instead of "How does Nehru's understanding change?"

## ON_FAILURE
Step 1: Have the student highlight every sentence beginning with "मैं" (I) in the chapter—there are 15+. Step 2: Ask: "Who is doing the seeing, asking, traveling, understanding in each?" Step 3: Create a two-column table: Column A = Nehru's action/statement; Column B = What it reveals about him. Step 4: Guide them to see the pattern: the "I" is the constant consciousness; Bharat Mata is the variable he's solving for. Step 5: Re-read the peasant scene noting Nehru's reaction ("चकित रह गया," "सोचने लगा")—the protagonist is the one changed by the answer.

## BUILDS_ON
c11_hin_ar_cbse_08_002 (Plot and Narrative Structure) – understanding the journey structure frames Nehru's character arc as the narrative spine.

## LEADS_TO
c11_hin_ar_cbse_08_005 (Character Analysis: Supporting Characters) – the peasant's character gains meaning only as a mirror to Nehru's transformation.

## PREREQUISITE_NODE_IDS
c11_hin_ar_cbse_08_001, c11_hin_ar_cbse_08_002, c11_hin_ar_cbse_08_003
## PREREQUISITE_REASONS
c11_hin_ar_cbse_08_001: Context on Nehru's historical role and the freedom struggle era is essential to situate the protagonist's background and motivations.
c11_hin_ar_cbse_08_002: The plot's journey structure (travel → encounters → realization) maps directly onto the protagonist's character development phases.
c11_hin_ar_cbse_08_003: The settings (villages, roads, fields) are not backdrop but active catalysts that shape the protagonist's epistemic shift.

## FORWARD_NODE_IDS
c11_hin_ar_cbse_08_005, c11_hin_ar_cbse_08_006, c11_hin_ar_cbse_08_013, c11_hin_ar_cbse_08_007, c11_hin_ar_cbse_08_009, c11_hin_ar_cbse_08_012, c11_hin_ar_cbse_08_014, c12_hin_a_cbse_08_004

## FORWARD_REASONS
c11_hin_ar_cbse_08_005: Supporting characters (peasant, workers) function as foils and catalysts for the protagonist; analyzing them requires the protagonist baseline.
c11_hin_ar_cbse_08_006: The primary theme (unity in diversity) emerges through the protagonist's character arc; theme analysis depends on character analysis.
c11_hin_ar_cbse_08_013: Critical interpretation of the text's nationalist argument requires evaluating the protagonist's reliability and perspective.
c11_hin_ar_cbse_08_007: Protagonist analysis (Nehru as narrator) reveals how his perspective shapes which secondary themes emerge and how they're framed  
c11_hin_ar_cbse_08_009: Protagonist analysis (Nehru as questioner) reveals his intentional use of irony as pedagogical tool.  
c11_hin_ar_cbse_08_012: Character analysis of Nehru as narrator-protagonist reveals his evolving perspective — essential for inferring authorial intent behind statements.  
c11_hin_ar_cbse_08_014: Protagonist analysis supplies Nehru's perspective as the central "voice" in answers.  
c12_hin_a_cbse_08_004: Built foundational character-analysis vocabulary (traits, evidence, development) on simpler narrative poems.  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
none

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_08_002 -> c11_hin_ar_cbse_08_004 -> c11_hin_ar_cbse_08_005

## THIS_FORMULA
N/A - conceptual

## FORMULA_VARIABLES
N/A

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
conceptual

## CROSS_SUBJECT
c11_history_nationalism_in_india | Nehru's character in this chapter reflects the historical shift from elite nationalist discourse to mass-based mobilization—his journey mirrors the Congress's own evolution in the 1930s-40s.
c11_civics_constitutional_values | The protagonist's realization that "Bharat Mata = the people" prefigures the Preamble's "We the People" and the constitutional principle of popular sovereignty.

## PREREQ_CONCEPT
Understanding first-person narrative perspective and the distinction between narrator-as-character vs. narrator-as-observer.

## PREREQ_BEFORE
Student must be able to identify first-person markers in Hindi text and distinguish between what the narrator reports and what the narrator reflects.

## PREREQ_STUCK
Review "first-person narrative voice" (कथावाचक की दृष्टि) from Class 10 Hindi—specifically how "मैं" creates both proximity and subjectivity.

## WORKED_EXAMPLE_1
PROBLEM: Analyze how Nehru's character trait of "intellectual humility" is established in the opening section of the chapter (before the peasant encounter). Use the PEEL structure: Point, Evidence, Explanation, Link.

STEPS:
- Step 1: Identify the point to prove—Nehru approaches common people not as a leader instructing them but as a learner seeking their wisdom.
- Step 2: Locate textual evidence in the opening paragraphs—phrases like "मैं उनसे पूछता था," "उनकी बातें सुनता था," "मेरी समझ में नहीं आता था" show active listening and admitted ignorance.
- Step 3: Explain how each phrase builds the trait—"पूछता था" (repeated questioning) shows curiosity not arrogance; "सुनता था" (listening) shows respect for subaltern knowledge; "समझ में नहीं आता" (admitting confusion) models intellectual honesty.
- Step 4: Link to broader characterization—this humility makes his later transformation credible; he doesn't impose the "correct" answer but lets it emerge from the people.
- Step 5: Connect to theme—this trait embodies the democratic ethos the chapter champions: truth comes from below, not above.

REASONING: The PEEL structure forces evidence-based character analysis rather than impressionistic description. Each step moves from textual micro-detail to macro-characterization to thematic significance—mirroring board exam answer expectations.

ANSWER: Nehru's intellectual humility is established through his repeated self-positioning as questioner and listener rather than authority. The text states: "मैं उनसे पूछता था... उनकी बातें सुनता था... मेरी समझ में नहीं आता था." The iterative questioning ("पूछता था" – habitual action) reveals genuine curiosity, not performative engagement. Admitting "मेरी समझ में नहीं आता" before a peasant audience—risking loss of face for a national leader—demonstrates epistemic vulnerability. This humility is not weakness but method: it creates the condition for the peasant's insight to penetrate. The trait thus anchors the chapter's democratic argument—that national identity is discovered through dialogue with the masses, not decreed by elites.

## WORKED_EXAMPLE_2
PROBLEM: Trace Nehru's character development across three phases using specific textual anchors: (1) The Intellectual Observer, (2) The Confronted Questioner, (3) The Internalized Leader. For each phase, give one quote and explain the shift.

STEPS:
- Step 1: Define Phase 1 (Intellectual Observer)—Nehru frames India through abstract categories. Find quote: "इतिहास, भूगोल, संस्कृति, नदियाँ, पहाड़" – shows scholarly, external gaze.
- Step 2: Define Phase 2 (Confronted Questioner)—Nehru's framework collapses in face of lived reality. Find quote: "एक गँवार किसान ने... मेरी आँखें खोल दीं" – "गँवार" (illiterate) vs. "आँखें खोल दीं" (enlightened) marks the inversion of epistemic authority.
- Step 3: Define Phase 3 (Internalized Leader)—Nehru adopts the people's definition as his own. Find quote: "मैं उन लाखों लोगों में से एक हूँ" – shift from "मैं" (separate observer) to "उनमें से एक" (participant).
- Step 4: Analyze the trajectory—movement from distance to proximity, from categories to people, from knowing about to being with.
- Step 5: Evaluate narrative function—this three-phase arc structures the chapter's argument: nationalism is not learned but lived.

REASONING: This example teaches phase-based character analysis—a higher-order skill than trait-listing. It requires tracking a dynamic character across the narrative arc, using contrastive quotes, and linking structural position to thematic payoff.

ANSWER: Phase 1 – Intellectual Observer: "मैं इतिहास, भूगोल, संस्कृति, नदियाँ, पहाड़... इन सबके बारे में सोचता था." Nehru's gaze is taxonomic; India is an object of study. Phase 2 – Confronted Questioner: "एक गँवार किसान ने... मेरी आँखें खोल दीं." The peasant—dismissed by category "गँवार"—becomes the teacher. Nehru's epistemic hierarchy inverts. Phase 3 – Internalized Leader: "मैं उन लाखों लोगों में से एक हूँ... जो इस विशाल देश में रहते हैं." The protagonist dissolves the subject-object gap; he no longer studies "them" but identifies as "us." The shift from "सोचता था" (intellectual activity) to "हूँ" (ontological state) marks complete internalization. This arc validates the chapter's thesis: the nation is not a concept to be defined but a community to be belonged to.

## WORKED_EXAMPLE_3
PROBLEM: The chapter contains a tension: Nehru is both an elite, Western-educated leader AND a protagonist who claims solidarity with "गँवार किसान" (illiterate peasants). Analyze how the text negotiates this tension through specific narrative strategies. Does it resolve or sustain the tension?

STEPS:
- Step 1: Identify the tension markers—Nehru's background ("विलायत में पढ़ा," "बड़े जमींदार का बेटा") vs. his self-presentation ("धूल भरी सड़कों पर," "मैले-कुचैले कपड़ों में").
- Step 2: Find Strategy 1 – Physical immersion: "मैं गाँव-गाँव घूमा," "पैदल चला," "उनके साथ खाया" – bodily co-presence bridges social distance.
- Step 3: Find Strategy 2 – Linguistic alignment: He records peasant speech in their idiom ("भारत माता की जय," "हम लोग") without correcting or translating into elite register.
- Step 4: Find Strategy 3 – Epistemic surrender: "मेरी आँखें खोल दीं" – he accepts their definition as superior to his own, reversing the teacher-student hierarchy.
- Step 5: Assess resolution—The tension is sustained, not resolved. The final "मैं उनमें से एक हूँ" is aspirational, not achieved; the narrative ends with him still addressing "you" (the reader/listener) as separate from "them."
- Step 6: Connect to historical authenticity—this unresolved tension reflects Nehru's real historical position: a leader who championed the masses but remained structurally distinct from them.

REASONING: This example models sophisticated character analysis—moving beyond "traits" to examine how a text manages contradictions in its protagonist. It combines close reading (specific phrases), structural awareness (narrative strategies), and historical consciousness (Nehru's actual position)—exactly the multi-layered thinking board exams reward.

ANSWER: The text negotiates the elite-mass tension through three strategies: (1) Physical immersion—"पैदल चला," "उनके साथ रहा" reduces distance through shared bodily experience. (2) Linguistic respect—peasant speech is quoted verbatim ("भारत माता की जय," "हम लोग"), not paraphrased into Nehru's Sanskritized Hindi, granting them epistemic dignity. (3) Epistemic surrender—"मेरी आँखें खोल दीं" positions the peasant as knower, Nehru as learner. However, the tension is sustained, not resolved. The closing "मैं उन लाखों लोगों में से एक हूँ" uses "उन" (them) even while claiming unity—a grammatical trace of irreducible distance. The narrative ends with Nehru addressing an audience ("आप लोग"), maintaining his role as speaker-for, not speaker-from-within. This honesty—refusing false fusion—strengthens the protagonist's credibility and mirrors the historical Nehru: a leader who represented the people without pretending to be indistinguishable from them.

## COMPETENCY_QUESTION_1
QUESTION: "Nehru's character in 'Bharat Mata' is not static—he undergoes a transformation that mirrors the chapter's central argument." Do you agree? Support your answer with three distinct moments from the text where his thinking shifts, explaining what triggers each shift.

COMPETENCY: Analytical interpretation linking character development to thematic argument

STEPS:
- Step 1: State your position clearly (agree/disagree/qualified agreement).
- Step 2: Identify Moment 1 (initial framework), the trigger (travel/encounters), and the shift (questioning abstract categories).
- Step 3: Identify Moment 2 (peasant encounter), the trigger (peasant's answer), and the shift (from geography to people).
- Step 4: Identify Moment 3 (final realization), the trigger (cumulative experience), and the shift (intellectual to ontological identification).
- Step 5: Synthesize—explain how these three shifts collectively embody the chapter's argument about nationalism.

ANSWER: I agree. The protagonist's transformation structurally enacts the chapter's thesis. Moment 1: Nehru begins with "इतिहास, भूगोल, संस्कृति" as his framework—triggered by his travels ("त्यागों में घूमता रहा"), he finds these categories inadequate to explain the emotional force of "भारत माता की जय." Shift: from taxonomic to experiential inquiry. Moment 2: The peasant's answer—"हम लोग ही भारत माता हैं"—triggered by direct dialogue, shatters his framework. Shift: from external symbols to living people as the nation's essence. Moment 3: After "लाखों मील की यात्रा," he internalizes: "मैं उन लाखों लोगों में से एक हूँ." Trigger: cumulative immersion. Shift: from knowing about the nation to being the nation. These three shifts—intellectual doubt, epistemic inversion, ontological identification—mirror the chapter's argument that nationalism is not a doctrine but a discovered belonging.

DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: A critic argues: "Nehru's 'discovery' of the people is a literary construct—he was always a nationalist leader; the chapter merely stages a conversion narrative for political effect." Evaluate this critique using textual evidence. Does the text support or undermine the critic's claim?

COMPETENCY: Critical evaluation of narrative reliability and authorial intention

STEPS:
- Step 1: Unpack the critic's claim—it alleges the transformation is performative, not genuine.
- Step 2: Identify textual evidence SUPPORTING the critic: Nehru's prior political stature (PM, Congress president), the chapter's rhetorical structure (conversion narrative), the symbolic utility of "गँवार किसान" as authentic voice.
- Step 3: Identify textual evidence UNDERMINING the critic: Nehru's admitted confusion ("समझ में नहीं आता"), the iterative process (repeated questioning over time), the self-deprecating tone ("चकित रह गया"), the absence of triumphalism.
- Step 4: Weigh the evidence—does the text's confessional mode and processual detail outweigh the structural suspicion?
- Step 5: Conclude with a nuanced judgment: the text invites both readings but its granular honesty (recording his own ignorance) makes the performed-discovery reading less parsimonious than the genuine-discovery reading.

ANSWER: The critique is plausible but the text undermines it through three features: (1) Process over event—the discovery isn't a single epiphany but "लाखों मील की यात्रा" of repeated encounters; conversion narratives typically compress time, this expands it. (2) Vulnerability display—Nehru records his confusion ("मेरी समझ में नहीं आता"), his surprise ("चकित रह गया"), and the peasant's superiority ("गँवार किसान ने आँखें खोल दीं"). A staged narrative would protect the leader's authority. (3) Linguistic fidelity—peasant speech is preserved in raw form, not polished for effect. However, the critic's structural point holds: the chapter IS a crafted narrative, not a raw diary. The most defensible position: the transformation is real but the telling is shaped—Nehru genuinely learned from the people, then crafted the narrative to communicate that learning. The text's honesty about its own construction ("मैं क्र्रम क्र्रम से बताता हूँ") supports this dual reading.

DIFFICULTY: hard