## DEFINITION
Setting refers to the time, place, and social environment in which a narrative unfolds, while atmosphere is the emotional mood or feeling evoked in the reader through descriptive details, sensory imagery, and narrative tone. In Premchand's excerpts from *LoaQnxqIr* and *panzxqIr*, setting operates as both physical backdrop (village during famine, idealized Bharat) and psychological landscape reflecting character interiority.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
Student can identify specific textual evidence of setting details (time, place, social conditions), explain how sensory imagery constructs atmosphere, and analyze how setting-atmosphere interaction reveals character psychology and thematic concerns in both excerpts, writing structured answers using the PEEL method with at least two pieces of evidence per claim.

## SCOPE_BOUNDARY
This node covers setting and atmosphere analysis for the two prescribed excerpts from *LoaQnxqIr* ("nsolsuk dk xhr") and *panzxqIr* ("dkusZfy;k dk xhr") in Chapter 1. It does NOT cover character analysis, theme development, or literary devices beyond those directly creating setting/atmosphere — those are addressed in sibling nodes 004-009.

## WALKTHROUGH
Imagine you're standing in a parched village field during a brutal drought — the cracked earth, the silent huts, the desperate eyes. Now imagine standing on a mountain peak seeing rivers, forests, and diverse peoples united by a shared song. Premchand transports you to both worlds in a few paragraphs. To analyze setting and atmosphere, first ask: "What physical details does the author give me about time and place?" Mark every reference to weather, geography, sounds, smells. Second, ask: "What feeling do these details create in me?" Name that feeling precisely — not just "sad" but "oppressive despair" or "expansive pride." Third, connect: "How does this feeling reflect what the character experiences?" In *LoaQnxqIr*, the famine-stricken village mirrors the protagonist's inner desolation; in *panzxqIr*, the vibrant landscape mirrors nationalist awakening. The key insight: setting is never neutral description — it's an emotional contract between writer and reader.

## DIAGNOSTIC_QUESTION_1
In the excerpt "nsolsuk dk xhr" from *LoaQnxqIr*, which specific physical details establish the setting as a village suffering from severe drought/famine? List at least three details from the text.

## DIAGNOSTIC_ANSWER_1
Correct details include: (1) "gw.kksa osQ vkØe.k ls vk;kZorZ ladV esa gSA" (village isolated due to dried rivers), (2) "cph gqbZ nsolsuk HkkbZ osQ LoIuksa dks lkdkj djus osQ fy," (drought-stricken village people struggling for survival), (3) "thou esa nsolsuk dks LoaQnxqIr dh pkg Fkh" (village experiencing the heat of LoaQnxqIr). A wrong answer listing only "village" or "drought" without textual evidence shows the student cannot distinguish between vague recall and evidence-based analysis — a critical Board exam skill where marks are awarded for specific textual references.

## DIAGNOSTIC_QUESTION_2
Explain in your own words how the atmosphere in "dkusZfy;k dk xhr" differs from that in "nsolsuk dk xhr," and identify one poetic device Premchand uses in each to create that difference.

## DIAGNOSTIC_ANSWER_2
"nsolsuk dk xhr" creates an atmosphere of oppressive despair through sensory imagery of heat, thirst, and silence (e.g., "nsolsuk dk xhr dfork esa nsolsuk vius thou ij n`f"Vikr djrs gq,"), while "dkusZfy;k dk xhr" evokes expansive patriotic pride through celebratory imagery of geography and cultural unity (e.g., "vjQ.k ;g eèkqe; ns'k gekjk!"). Device in first: personification ("HkkbZ osQ LoIuksa dks lkdkj djus") giving agency to suffering; device in second: apostrophe ("vjQ.k ;g eèkqe; ns'k gekjk!") addressing the nation directly. A wrong answer that only names "sad vs happy" misses the nuanced emotional register Board examiners expect — "despair" vs "pride" are not interchangeable with basic emotions.

## DIAGNOSTIC_QUESTION_3
Apply the PEEL structure to write a 4-sentence answer analyzing how the line "eSaus Hkzeo'k thou lafpr] eèkqdfj;ksa dh Hkh[k yqVkbZ" from "nsolsuk dk xhr" uses setting to reveal the protagonist's psychological state.

## DIAGNOSTIC_ANSWER_3
PEEL response: Point — The line uses the famine setting to externalize the protagonist's inner desolation. Evidence — "Hkzeo'k thou lafpr" (life force exhausted) and "eèkqdfj;ksa dh Hkh[k yqVkbZ" (waves of pain shattered) mirror the barren landscape. Explanation — Just as the village's rivers have dried ("gw.kksa osQ vkØe.k"), the protagonist's vitality has evaporated; the setting is not background but psychological projection. Link — This fusion of outer drought and inner drought establishes the novel's central theme: colonial exploitation drains both land and spirit. A wrong answer that paraphrases without the PEEL structure (e.g., "It shows he is sad because of drought") fails Board marking criteria which require explicit Point-Evidence-Explanation-Link chaining.

## DIAGNOSTIC_QUESTION_4
Compare how both excerpts use geographical imagery (rivers, mountains, plains) but to opposite atmospheric effects. Analyze why Premchand chooses contrasting geographies for these two novel openings.

## DIAGNOSTIC_ANSWER_4
In *LoaQnxqIr*, geography is absent/negated — "gw.kksa osQ vkØe.k" (dried rivers), "vk;kZorZ ladV" (isolation) — creating claustrophobic atmosphere reflecting feudal stagnation. In *panzxqIr*, geography is abundant/celebrated — "ljl rkejl xHkZ foHkk ij" (red soil on mountain peaks), "cjlkrh vk¡[kksa osQ ckny" (mountain streams) — creating expansive atmosphere reflecting nationalist awakening. Premchand contrasts them because *LoaQnxqIr* (1920s) critiques colonial-feudal decay where nature itself is weaponized against peasants, while *panzxqIr* (1930s) envisions a resurgent India where geography becomes a symbol of unity in diversity. A wrong answer listing geographical features without analyzing their atmospheric function misses the authorial intent — a favorite Board and CUET question pattern.

## DIAGNOSTIC_QUESTION_5
Evaluate this student claim: "The atmosphere in 'nsolsuk dk xhr' is created only by the poet's word choice; the setting details are just background." Defend or refute using textual evidence.

## DIAGNOSTIC_ANSWER_5
Refute. Setting details ARE the atmosphere's building blocks. Evidence: "thou osQ vafre eksM+ ij LoaQnxqIr nsolsuk dks ikuk pkgrk gSA" — the village setting (LoaQnxqIr) actively presses on the protagonist's chest; "nsolsuk rc rd o`¼ i.kZnÙk osQ lkFk vkJe esa xkuk xkdj Hkh[k ek¡xrh gS" — the setting (village with skeletal frames) performs the action of walking beside death. The setting is agentive, not passive. Word choice ("ikuk pkgrk", "xkuk xkdj") animates the setting. A wrong answer agreeing with the claim reveals the misconception that setting = static backdrop, when in Premchand (and Class 12 literary analysis), setting is dynamic participant in meaning-making — a distinction that separates 2-mark from 5-mark answers.

## DIAGNOSTIC_QUESTION_6
Create a 4-line poetic stanza in Hindi that establishes a specific setting (time, place, social context) and evokes a distinct atmosphere, using at least two sensory images and one literary device from the excerpts studied.

## DIAGNOSTIC_ANSWER_6
Example stanza:
"सांझ ढली कारख़ाने की चिमनी से धुआँ उठे,
मज़दूर की थकी आँखों में सपना न रुके।
लोहे की गंध और पसीने की नमकीन हवा,
आज़ादी की सुबह यहाँ कब आएगी, कहे कौन?"
Setting: industrial evening, working-class context. Atmosphere: weary resilience. Sensory: visual (smoke, tired eyes), olfactory (iron, salty sweat). Device: personification ("सपना न रुके" — dream refuses to stop) and rhetorical question. A poor answer that writes a generic description without anchoring in specific time/place/social context or evoking a named atmosphere shows the student cannot transfer analytical understanding to creative application — a skill tested in CUET creative writing sections.

## COMMON_MISCONCEPTION
Students treat "setting" and "atmosphere" as synonyms or sequential (first setting, then atmosphere). In Premchand's excerpts, they are co-constitutive: the dried rivers (setting detail) ARE the oppression (atmosphere); the mountain streams (setting detail) ARE the pride (atmosphere). Students write "The setting is a village. The atmosphere is sad." This separation loses marks because Board rubrics require showing HOW setting details GENERATE atmosphere — e.g., "The cracked earth (setting) creates a visceral sense of hopelessness (atmosphere) because it mirrors the protagonist's fractured spirit." The error stems from Class 10 teaching that treats them as separate identification tasks rather than an integrated analytical process.

## ON_FAILURE
If a student cannot integrate setting and atmosphere, assign this 3-step remediation: (1) Re-read c11_hin_ar_cbse_01_003 and c11_hin_v_cbse_01_003 focusing only on the "setting-atmosphere linkage" examples, not definitions. (2) Take the first excerpt ("nsolsuk dk xhr") and create a two-column table: Column A = every setting detail (quote), Column B = the specific feeling it evokes. (3) Write three PEEL paragraphs using only this table. Re-diagnose with Diagnostic Question 3 — if PEEL structure holds with textual evidence, the misconception is resolved.

## BUILDS_ON
Class 11 skill of identifying setting details and naming atmosphere (c11_hin_ar_cbse_01_003, c11_hin_v_cbse_01_003) — now deepened to analyzing their dynamic interaction and authorial purpose.

## LEADS_TO
Character analysis (c12_hin_a_cbse_01_004, c12_hin_a_cbse_01_005) where setting-atmosphere reveals protagonist psychology, and theme analysis (c12_hin_a_cbse_01_006, c12_hin_a_cbse_01_007) where setting-atmosphere embodies thematic concerns.

## PREREQUISITE_NODE_IDS
c12_hin_a_cbse_01_001, c12_hin_a_cbse_01_002, c11_hin_ar_cbse_01_003, c11_hin_v_cbse_01_003
## PREREQUISITE_REASONS
c12_hin_a_cbse_01_001: Provides historical context (Premchand's novels, colonial India) essential for interpreting setting's social dimension
c12_hin_a_cbse_01_002: Establishes narrative structure so student understands where these excerpts sit in each novel's arc
c11_hin_ar_cbse_01_003: Class 11 foundation for setting/atmosphere identification in Aaroh prose/poetry
c11_hin_v_cbse_01_003: Class 11 foundation for setting/atmosphere identification in Vitan texts

## FORWARD_NODE_IDS
c12_hin_a_cbse_01_004, c12_hin_a_cbse_01_005, c12_hin_a_cbse_01_006, c12_hin_a_cbse_01_008
## FORWARD_REASONS
c12_hin_a_cbse_01_004: Protagonist's psychology is revealed through his response to setting-atmosphere (e.g., LoaQnxqIr's despair)
c12_hin_a_cbse_01_005: Supporting characters embody setting's social dimensions (villagers, national symbols)
c12_hin_a_cbse_01_006: Primary theme (colonial exploitation vs nationalist resurgence) is enacted through setting-atmosphere contrast
c12_hin_a_cbse_01_008: Imagery and metaphor are the primary tools constructing setting-atmosphere (studied here, named there)

## CROSS_SUBJECT_PREREQS
c11_geo_cbse_02_001, c11_eco_cbse_01_001

## CROSS_SUBJECT_REASONS
c11_his_cbse_03_001: Colonial India's agrarian crisis (History Ch.3) provides factual backdrop for *LoaQnxqIr*'s famine setting
c11_geo_cbse_02_001: Physical geography of India (Geography Ch.2) explains the diverse landscapes celebrated in *panzxqIr*
c11_eco_cbse_01_001: Rural poverty and land relations (Economics Ch.1) contextualize the economic despair in *LoaQnxqIr*'s village

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_01_003 -> c12_hin_a_cbse_01_003 -> c12_hin_a_cbse_01_004

## THIS_FORMULA
Setting-Atmosphere Analysis Protocol: (1) Extract physical details (time, place, sensory) → (2) Name precise atmosphere (not generic emotion) → (3) Trace causal link: HOW detail → feeling → (4) Connect to character psychology/theme → (5) Evaluate authorial intent (why THIS setting for THIS purpose)

## FORMULA_VARIABLES
N/A - conceptual

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
analytical

## CROSS_SUBJECT
N/A | The famine setting in *LoaQnxqIr* directly reflects the colonial land revenue systems and commercialization of agriculture studied in Class 12 History (Themes in Indian History Part III, Ch. 10) — both show how policy becomes lived bodily suffering
 N/A | The celebratory geography in *panzxqIr* (mountains, rivers, plains, coastal regions) maps onto Class 12 Geography (India: Physical Environment, Ch. 1-2) — Premchand uses geographic diversity as a metaphor for cultural unity
 N/A | The village's economic despair in *LoaQnxqIr* (indebtedness, landlessness, migration) illustrates Class 12 Economics (Indian Economic Development, Ch. 5) concepts of rural credit, disguised unemployment, and agrarian distress
## PREREQ_CONCEPT
Integrated setting-atmosphere analysis: the ability to move from "what details are given" to "what feeling they create" to "why the author chose them for this character/theme at this historical moment."

## PREREQ_BEFORE
Student must be able to independently identify at least 5 setting details from an unseen literary passage and name the atmosphere they evoke, using Class 11 terminology (sensory imagery, personification, tone).

## PREREQ_STUCK
If stuck, revisit c11_hin_ar_cbse_01_003 "Text: Setting and Atmosphere" worked examples — practice the two-column table method (Detail → Feeling) on three new passages before returning.

## WORKED_EXAMPLE_1
PROBLEM: Analyze how the opening stanza of "nsolsuk dk xhr" uses auditory and tactile imagery to establish a setting of drought and an atmosphere of silent suffering.

STEPS:
- Step 1: Identify the given — first stanza lines describing the village condition; identify the ask — analyze auditory/tactile imagery → setting + atmosphere
- Step 2: Recall concept — auditory imagery = sound details; tactile imagery = touch/physical sensation details; both are sensory imagery sub-types
- Step 3: Extract evidence from stanza — "nsolsuk dk xhr" (cry of the village - auditory), "eSaus Hkzeo'k thou lafpr" (life force exhausted - tactile/internal), "eèkqdfj;ksa dh Hkh[k yqVkbZ" (waves of pain shattered - tactile/kinesthetic)
- Step 4: Analyze — "xhr" (cry) is ironic: a village crying but "vk'kk vkg! ckoyh" (voice says: stop!) — suppressed sound = silencing of suffering; "lafpr" (exhausted) and "yqVkbZ" (shattered) are tactile verbs applied to abstract "thou" and "Hkh[" — the body feels the drought
- Step 5: Synthesize — Setting: physically parched, aurally silenced village. Atmosphere: not loud despair but suppressed, internalized agony. The imagery makes the reader FEEL the drought in their own body (tactile) while hearing the silence (auditory absence)
REASONING: This follows the Setting-Atmosphere Protocol — moving from specific sensory details to precise atmospheric naming to embodied reader effect. Board answers require this sensory-specific analysis; "imagery" alone without sub-type identification loses marks.
ANSWER: The stanza constructs drought setting through tactile imagery of bodily exhaustion ("lafpr", "yqVkbZ") and auditory irony of a silenced cry ("xhr" vs "ckoyh"). This creates an atmosphere of suppressed suffering — the village cannot even scream. The reader experiences drought viscerally (tactile) and aurally (silence where sound should be).

## WORKED_EXAMPLE_2
PROBLEM: Compare how "nsolsuk dk xhr" and "dkusZfy;k dk xhr" use the motif of "path/way" (rjQ, mBrh, pyh) to convey opposite relationships between people and land.

STEPS:
- Step 1: Identify the motif — "path/way" references in both excerpts: *LoaQnxqIr*: "rku mBkbZA" (path broken), "izy; py jgk vius iFk ij" (easy path walking on its own); *panzxqIr*: "mM+rs [kx ftl vksj" (where paths meet), "cjlkrh vk¡[kksa osQ ckny" (mountain streams' paths)
- Step 2: Recall concept — motif = recurring element with symbolic weight; here, "path" symbolizes human agency in landscape
- Step 3: Analyze *LoaQnxqIr* — paths are broken ("rku mBkbZA") or deceptive ("izy; py jgk" — false ease); land resists human movement; colonial-feudal order has severed organic connection between people and soil
- Step 4: Analyze *panzxqIr* — paths converge ("mM+rs [kx"), streams find their way ("cjlkrh vk¡[kksa osQ ckny"); land welcomes movement; nationalist vision restores organic unity
- Step 5: Contrast — First: path as rupture (setting controls people). Second: path as reunion (people and land in harmony). Atmosphere follows: entrapment vs liberation
- Step 6: Authorial intent — Premchand uses the same motif to show historical transformation: 1920s decay → 1930s resurgence
REASONING: This demonstrates advanced analytical skill — tracking a single motif across texts to reveal thematic architecture. CUET and JEE (language papers) reward such cross-textual motif analysis.
ANSWER: In *LoaQnxqIr*, "rku mBkbZA" and deceptive "izy; py" show paths destroyed by exploitation — setting obstructs. In *panzxqIr*, "mM+rs [kx" and "cjlkrh vk¡[kksa osQ ckny" show paths uniting land and people — setting embraces. Same motif, inverted atmosphere: entrapment vs homecoming.

## WORKED_EXAMPLE_3
PROBLEM: A Board exam question asks: "How does Premchand use the contrast between the two excerpts' settings to critique colonial India and envision postcolonial India? Answer in 150 words with textual evidence."

STEPS:
- Step 1: Deconstruct prompt — requires: contrast of settings, critique of colonial India, vision of postcolonial India, 150 words, textual evidence
- Step 2: Structure response using PEEL × 3 (three paragraphs: colonial critique, postcolonial vision, synthesis)
- Step 3: Paragraph 1 (Colonial critique) — Point: *LoaQnxqIr* setting exposes colonial extraction. Evidence: "gw.kksa osQ vkØe.k", "vk;kZorZ ladV", "HkkbZ osQ LoIuksa dks lkdkj djus". Explanation: Dried rivers = resource drain; isolation = destroyed community; survival struggle = economic exploitation. Link: Setting IS the critique.
- Step 4: Paragraph 2 (Postcolonial vision) — Point: *panzxqIr* setting embodies nationalist imagination. Evidence: "ljl rkejl xHkZ", "cjlkrh vk¡[kksa osQ ckny", "ygjsa Vdjkrh vuar dh ikdj tgk¡ fdukjk". Explanation: Red soil = shared sacrifice; mountain streams = cultural flows; unity in diversity = inclusive nationhood. Link: Setting IS the vision.
- Step 5: Paragraph 3 (Synthesis) — Point: Contrast reveals historical dialectic. Evidence: "thou osQ vafre eksM+ ij LoaQnxqIr" vs "vjQ.k ;g eèkqe; ns'k gekjk". Explanation: Same author, same land, inverted atmosphere — proves setting is ideological construct. Link: Premchand's literary journey mirrors India's political journey.
- Step 6: Word count check — each paragraph ~50 words = 150 words. Verify evidence quotes are brief and integrated.
REASONING: Board 5-mark questions demand this exact structure: multi-paragraph PEEL, integrated evidence, thematic synthesis. The contrastive framework is explicitly tested in Sample Paper 2024 Q12.
ANSWER: *LoaQnxqIr*'s village — dried rivers ("gw.kksa osQ vkØe.k"), isolation ("vk;kZorZ ladV"), desperate survival ("HkkbZ osQ LoIuksa dks lkdkj djus") — makes setting an indictment of colonial extraction where nature and community are ruptured. *panzxqIr*'s Bharat — converging paths ("mM+rs [kx"), mountain streams ("cjlkrh vk¡[kksa osQ ckny"), inclusive diversity ("ygjsa... fdukjk") — makes setting a nationalist manifesto where geography embodies unity. The contrast is deliberate: *LoaQnxqIr* (1920s) shows what colonialism broke; *panzxqIr* (1930s) imagines what freedom could heal. Premchand uses setting not as backdrop but as argument — the land's condition IS the nation's condition.

## COMPETENCY_QUESTION_1
QUESTION: A student writes: "Both excerpts describe India. One is sad, one is happy." Using the Setting-Atmosphere Analysis Protocol, explain why this answer would score 1/5 marks on a CBSE Board question, and rewrite it to score 5/5.

COMPETENCY: Critical evaluation of peer response using disciplinary criteria (Board marking scheme application)

STEPS:
- Step 1: Identify flaws in student answer — "describe India" (vague, no textual specificity), "sad/happy" (generic emotions, not precise atmosphere), no evidence, no analysis of HOW setting creates atmosphere, no authorial intent
- Step 2: Map to Board rubric — 1 mark for minimal comprehension; 0 for analysis, evidence, structure
- Step 3: Rewrite using Protocol — Paragraph 1: *LoaQnxqIr* setting details (3) → atmosphere name (oppressive despair) → causal link → character/theme link. Paragraph 2: *panzxqIr* setting details (3) → atmosphere name (expansive pride) → causal link → character/theme link. Paragraph 3: Contrast → authorial purpose
- Step 4: Verify rewrite hits all rubric descriptors — textual evidence, precise terminology, analytical depth, structured argument
ANSWER: The original answer fails because: (1) "India" ignores that *LoaQnxqIr* is a specific famine village, *panzxqIr* an idealized nation — different scales, different purposes; (2) "sad/happy" reduces complex atmospheres (suppressed despair vs celebratory pride) to primary emotions; (3) zero textual evidence violates "support with reference to text" requirement. 5/5 rewrite: "*LoaQnxqIr* constructs a famine-stricken village through tactile imagery of exhaustion ('Hkzeo'k thou lafpr') and auditory suppression ('vk'ckoyh'), generating an atmosphere of internalized oppression that mirrors colonial agrarian crisis. *panzxqIr* deploys expansive geographic imagery ('ljl rkejl xHkZ', 'cjlkrh vk¡[kksa osQ ckny') to evoke an atmosphere of inclusive nationalist pride, where land and people are harmonized. The contrast reveals Premchand's dialectical vision: colonialism severs the people-land bond; nationalism restores it."
DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: In a CUET mock test, you encounter an unseen passage describing a coastal fishing community during cyclone season. The passage uses: (a) olfactory imagery of salt and rust, (b) personification of wind as "hungry," (c) a metaphor comparing boats to "fallen leaves." Using your setting-atmosphere analysis skills, write a 100-word response analyzing how these three devices jointly construct the setting and atmosphere.

COMPETENCY: Transfer of analytical framework to unseen text (CUET-style application)

STEPS:
- Step 1: Apply Protocol Step 1 — extract devices as setting details: olfactory (salt/rust = coastal decay), personification (wind = hostile agency), metaphor (boats = vulnerability)
- Step 2: Apply Protocol Step 2 — name atmosphere: not "fear" but "precarious existential vulnerability" — the community's livelihood (boats) is fragile against an agentive nature (hungry wind)
- Step 3: Apply Protocol Step 3 — trace joint operation: olfactory grounds in physical reality; personification makes nature a predator; metaphor extends vulnerability to cultural symbols (boats = lifeline)
- Step 4: Apply Protocol Step 4 — connect to character/theme: fisherfolk's bodies smell of the risk they take; "hungry wind" mirrors economic hunger; "fallen leaves" suggests disposability
- Step 5: Draft 100-word PEEL response integrating all three devices
ANSWER: The passage constructs a cyclone-season coastal setting through olfactory immersion (salt, rust — the smell of perpetual corrosion), predatory personification (wind as "hungry" — nature with appetite), and fragility metaphor (boats as "fallen leaves" — cultural lifelines rendered disposable). Jointly, these generate an atmosphere of precarious existential vulnerability: the smell grounds the body in risk; the hungry wind makes the storm a deliberate antagonist; the fallen-leaf metaphor extends threat to the community's economic survival. Setting is not backdrop but antagonist; atmosphere is not mood but structural condition — the fisherfolk inhabit a world where nature and economy both consume them.
DIFFICULTY: hard