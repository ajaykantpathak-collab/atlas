We are creating a node for Class 12 Hindi (Antra) Chapter 7: "iafMr panzèkj 'kekZ xqysjh" (which is the poem "ckjgeklk" by Kabir, as per the NCERT reference text). The node is about "Theme: Secondary Themes".

We have the NCERT reference text which includes the poem "ckjgeklk" (Kabir's poem) and some questions. The chapter is about Kabir's poem. The primary theme node (c12_hin_a_cbse_07_006) would have covered the main theme. This node covers secondary themes.

We need to create a detailed pedagogy for struggling students. We must follow the exact format with all sections.

Let's analyze the poem from the reference text to identify secondary themes.

The poem "ckjgeklk" is a Kabir poem. The reference text shows three stanzas (or parts) with Hindi words and their meanings. The poem deals with themes like:
- The futility of worldly attachments
- The importance of spiritual awakening
- The transient nature of life
- The role of a guru
- The contrast between worldly pleasures and spiritual bliss
- The inevitability of death
- The concept of Maya (illusion)
- The path of devotion (bhakti)

Since the primary theme node (006) likely covers the main theme (e.g., spiritual realization, devotion to God, rejection of rituals), the secondary themes could be:
1. The transience of life and inevitability of death
2. The illusion of worldly attachments (Maya)
3. The importance of the Guru's guidance
4. The futility of rituals without inner devotion
5. The contrast between the material and spiritual worlds
6. The concept of the body as a temporary vessel

We need to create content that builds on Class 11 knowledge (theme analysis) and goes deeper for Class 12 board and competitive exams (like CUET, etc.). The node must be at the highest depth.

We must not reproduce the poem. We can reference stanzas by number and describe lines.

We'll create the sections as required.

Let's start with the definition.

## DEFINITION
Secondary themes are the underlying ideas, motifs, or messages that run parallel to the primary theme of a literary work, enriching the text by adding layers of meaning, highlighting contrasts, and deepening the reader's understanding of the human condition. In Kabir's "ckjgeklk," while the primary theme is the attainment of spiritual liberation through true devotion (bhakti) and the guidance of a Guru, secondary themes include the impermanence of the physical body, the deceptive nature of worldly pleasures (Maya), the futility of external rituals without inner purity, and the urgency of spiritual awakening before death.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student can independently identify at least three secondary themes in the poem, trace each theme across specific stanzas with textual evidence (paraphrased or referenced by stanza/line), and explain how each secondary theme interacts with and reinforces the primary theme of spiritual liberation.

## SCOPE_BOUNDARY
This node covers the identification, analysis, and interpretation of secondary themes in Kabir's poem "ckjgeklk" from the Class 12 Hindi Antra textbook (Chapter 7). It does not cover the primary theme (covered in node c12_hin_a_cbse_07_006), detailed literary devices (covered in nodes 008, 009), or comprehensive vocabulary/grammar (nodes 010, 011). It focuses solely on thematic analysis at a depth suitable for CBSE Board 80-mark paper and CUET/UG entrance exams.

## WALKTHROUGH
Imagine you are listening to an old folk song that your grandmother sings — at first it sounds like a simple tune about daily life, but as you listen closely, you realize it carries hidden warnings about the fleeting nature of youth and the importance of preparing for the inevitable. Similarly, Kabir's poem "ckjgeklk" appears to describe a conversation between a weaver and a seeker, but beneath the surface lie multiple warnings about life's illusions. Begin by re-reading the poem silently, then aloud, noticing recurring words like "death" (mrityu), "body" (sharir), "illusion" (maya), and "Guru". Mark stanzas where these appear. Ask: What is the poet warning us about besides the main message of devotion? List these warnings — each is a secondary theme. Then, for each, find two pieces of evidence from different stanzas. Finally, write a one-sentence statement linking each secondary theme to the primary theme. The key insight: secondary themes are not separate; they are the supporting pillars that make the primary theme stand firm.

## DIAGNOSTIC_QUESTION_1
What is the definition of a secondary theme in literature, and how does it differ from the primary theme? Answer in 2-3 sentences.

## DIAGNOSTIC_ANSWER_1
A secondary theme is a subordinate but significant idea that runs alongside the primary theme, adding depth and complexity to the work. While the primary theme is the central, unifying message (e.g., spiritual liberation through true devotion in "ckjgeklk"), secondary themes explore related facets like the transience of life or the deception of Maya. A wrong answer would confuse secondary themes with literary devices (like metaphor) or treat them as equally central, revealing the student cannot distinguish hierarchical thematic structure.

## DIAGNOSTIC_QUESTION_2
In Kabir's "ckjgeklk," the primary theme is spiritual liberation through the Guru's guidance. Explain in your own words how the theme of 'the impermanence of the body' functions as a secondary theme. Use one specific reference from the poem (mention stanza number and key idea) to support your explanation.

## DIAGNOSTIC_ANSWER_2
The impermanence of the body serves as a secondary theme by creating urgency for spiritual action — the body is a temporary vessel that decays, so one must seek the Guru before death. In Stanza 1, the weaver describes the body as a fragile structure ("fufl ck<+h") that will eventually perish, emphasizing that worldly attachments are futile because the body itself is not permanent. A wrong answer would merely quote lines without explaining the thematic function, or confuse this with the primary theme of devotion, showing the student cannot articulate how secondary themes support the main message.

## DIAGNOSTIC_QUESTION_3
Apply the concept of secondary themes to a new context: In a short story about a student preparing for board exams who neglects health and relationships, the primary theme is 'the cost of single-minded ambition.' Identify two plausible secondary themes and briefly justify each with a hypothetical scene from the story.

## DIAGNOSTIC_ANSWER_3
Two secondary themes: (1) The fragility of mental health — shown when the student has a panic attack before a mock test, revealing that ambition without balance leads to breakdown. (2) The irreplaceability of human connection — shown when the student receives a letter from a grandparent and realizes they have missed years of moments, underscoring that success is hollow without love. A wrong answer would list topics like 'exams' or 'stress' without thematic statements, or fail to link scenes to the themes, indicating the student cannot transfer the analytical skill to unfamiliar texts.

## DIAGNOSTIC_QUESTION_4
Analyze how the secondary theme of 'the deception of worldly pleasures (Maya)' interacts with the primary theme of 'true devotion' in "ckjgeklk." Compare the treatment of this theme in Stanza 1 and Stanza 3. What contrast does Kabir create?

## DIAGNOSTIC_ANSWER_4
In Stanza 1, worldly pleasures are depicted as seductive but hollow — the weaver describes the body enjoying sensory delights ("Hk¡ojk ,s dkx") while the soul remains trapped. In Stanza 3, the same pleasures are shown as chains that bind ("fcjg iou gksb >ksyk") and the seeker realizes they are illusions ("ty vax ykx lj ph:"). The contrast moves from unconscious entanglement to conscious rejection, mirroring the journey from ignorance to awakening. This interaction strengthens the primary theme: only by seeing through Maya can one turn to true devotion. A wrong answer would describe each stanza separately without comparing them or miss the progression from entrapment to realization, showing inability to analyze thematic development across the text.

## DIAGNOSTIC_QUESTION_5
Evaluate the following student claim: "The theme of 'Guru's grace' in 'ckjgeklk' is a secondary theme because it appears less frequently than the theme of death." Defend or refute this using evidence from the poem. Your answer must include a clear judgment and two textual reasons.

## DIAGNOSTIC_ANSWER_5
Refute. The Guru's grace is not secondary in importance but catalytic — it is the means to liberation, making it structurally central even if mentioned in fewer stanzas. Evidence: (1) In Stanza 2, the seeker's transformation occurs only when the Guru imparts knowledge ("lq#t tM+kb yad fnfl rkik"), showing grace as the turning point. (2) In Stanza 3, the seeker attributes freedom to the Guru's intervention ("rqEg fcuq oaQrk èkfu g#bZ"), placing grace as the cause of release from Maya. Frequency ≠ thematic weight. A wrong answer would agree based on counting mentions, revealing a quantitative rather than qualitative understanding of thematic hierarchy.

## DIAGNOSTIC_QUESTION_6
Create a four-line poem (in Hindi or English) that conveys a primary theme of 'hope after failure' and weaves in two secondary themes: 'the passage of time' and 'the value of small beginnings.' Title your poem and underline the words/phrases that signal each secondary theme.

## DIAGNOSTIC_ANSWER_6
Title: "नई सुबह"  
टूटे सपनों की राख़ पर, _समय_ पैर रख आगे बढ़ता हूँ (secondary: passage of time)  
_छोटे कदमों_ से ही सही, मंज़िल की ओर चलता हूँ (secondary: value of small beginnings)  
निराशा की लंबी रात बीती, आशा का सूरज उगता है  
हार नहीं, यह नई शुरुआत — जीवन फिर मुस्कुराता है  

A good answer uses imagery to show both secondary themes distinctly and links them to the primary theme. A poor answer would state themes explicitly without poetic embedding, or have disjointed lines, showing the student cannot synthesize themes creatively.

## COMMON_MISCONCEPTION
Students often think secondary themes are just 'sub-topics' or 'less important topics' that can be listed without analysis. They write: "Secondary themes are death, Maya, and Guru" — treating them as labels. The error is not explaining HOW each theme operates in the text: through which images, in which stanzas, and how it reinforces the primary theme. This happens because Class 11 teaching often stops at identification. In Class 12 board exams, such answers get 1/3 marks because they lack 'analysis' and 'textual evidence' required by the marking scheme. Competitive exams like CUET ask: 'How does the theme of Maya serve the poem's central argument?' — requiring functional analysis, not listing.

## ON_FAILURE
If a student cannot distinguish primary vs secondary themes or cannot trace a theme across stanzas: (1) Have them re-read the poem and highlight every reference to body, death, time, Guru, illusion — use different colors for each. (2) Ask: "Which of these does Kabir return to most? Which one solves the problem?" — that's the primary theme. (3) For each other color, write one sentence: "This theme shows ___ and it pushes the seeker toward ___." (4) Practice with a simpler text (e.g., a Panchatantra story) to build the skill, then return to Kabir. Re-diagnose using Diagnostic Question 2.

## BUILDS_ON
This node builds on the skill of identifying the primary theme (node c12_hin_a_cbse_07_006) and the Class 11 foundation of theme analysis (e.g., c11_hin_ar_cbse_01_007, c11_hin_ar_cbse_07_007) where students learned to distinguish main and supporting ideas in literary texts.

## LEADS_TO
This node enables deeper critical interpretation (node c12_hin_a_cbse_07_013) where students synthesize primary and secondary themes with literary devices to form original analytical arguments for long-answer questions.

## PREREQUISITE_NODE_IDS
c12_hin_a_cbse_07_006, c11_hin_ar_cbse_07_007, c11_hin_ar_cbse_01_007
## PREREQUISITE_REASONS
c12_hin_a_cbse_07_006: Provides the primary theme of the same poem, which is the anchor for analyzing how secondary themes relate to it.
c11_hin_ar_cbse_07_007: Class 11 node on secondary themes in a different chapter — establishes the foundational skill of identifying and explaining secondary themes.
c11_hin_ar_cbse_01_007: Another Class 11 secondary themes node — reinforces the concept across multiple texts, ensuring transferable skill.

## FORWARD_NODE_IDS
c12_hin_a_cbse_07_008, c12_hin_a_cbse_07_009, c12_hin_a_cbse_07_013, c12_hin_a_cbse_07_015

## FORWARD_REASONS
c12_hin_a_cbse_07_008: Literary devices like imagery and metaphor are the vehicles through which secondary themes are conveyed — analyzing themes prepares students to see how devices function thematically.
c12_hin_a_cbse_07_009: Irony and symbolism often encode secondary themes (e.g., the body as a symbol of Maya) — theme analysis is prerequisite for device analysis.
c12_hin_a_cbse_07_013: Critical thinking requires synthesizing themes, devices, and context into coherent arguments — this node provides the thematic raw material.
c12_hin_a_cbse_07_015: Secondary themes (nature, time, gender) expand discussion avenues  

## CROSS_SUBJECT_PREREQS
c11_hin_ar_cbse_07_013, c11_hin_ar_cbse_01_013
## CROSS_SUBJECT_REASONS
c11_hin_ar_cbse_07_013: Critical thinking in Class 11 Hindi (Aroh) develops analytical reasoning about texts, which transfers directly to thematic analysis in Class 12.
c11_hin_ar_cbse_01_013: Another critical thinking node from Class 11 — builds the habit of evidence-based interpretation across chapters.

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_07_007 -> c12_hin_a_cbse_07_007 -> c12_hin_a_cbse_07_013

## THIS_FORMULA
N/A - conceptual

## FORMULA_VARIABLES
N/A

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
conceptual

## CROSS_SUBJECT
N/A | The poem reflects the Nirguna Bhakti tradition; understanding its themes requires knowledge of the historical context of Kabir and the Bhakti movement's challenge to ritualism and caste.
 N/A | The poem's emphasis on the body's impermanence and detachment from material world connects to geographical concepts of human adaptation and cultural perceptions of nature/body.
 N/A | The critique of worldly pleasures (Maya) as deceptive parallels the economic concept of diminishing marginal utility and irrational consumer choices driven by illusion of satisfaction.
 N/A | Kabir's synthesis of Hindu-Muslim spiritual ideas exemplifies pluralistic thought; thematic analysis of unity beyond rituals supports civics concepts of secularism and inclusive identity.
## PREREQ_CONCEPT
Ability to distinguish between a text's central argument (primary theme) and its supporting, enriching ideas (secondary themes) using textual evidence.

## PREREQ_BEFORE
Student must have completed the primary theme analysis of this poem (node 006) and be familiar with the poem's narrative flow, key vocabulary, and the concept of Nirguna Bhakti.

## PREREQ_STUCK
If stuck, review the primary theme of "ckjgeklk" (spiritual liberation through Guru's grace) and the Class 11 notes on theme hierarchy (node c11_hin_ar_cbse_07_007).

## WORKED_EXAMPLE_1
PROBLEM: Analyze the secondary theme of 'the inevitability of death' in Kabir's "ckjgeklk." Trace its presence across at least two stanzas and explain how it creates urgency for the primary theme of spiritual awakening.

STEPS:
- Step 1: Identify the primary theme (from node 006) — spiritual liberation through true devotion and Guru's grace.
- Step 2: Scan the poem for references to death, decay, end of life, or time running out. Note stanza numbers and key phrases (without quoting entire lines).
- Step 3: In Stanza 1, the weaver describes the body as a temporary structure ("fufl ck<+h") that will eventually break — death is implied as the inevitable end of the physical form.
- Step 4: In Stanza 3, the seeker realizes death is approaching ("fcjg iou gksb >ksyk") and worldly ties cannot stop it — the tone shifts from description to personal realization.
- Step 5: Connect: The inevitability of death is not just a fact but a catalyst — it forces the seeker to seek the Guru NOW. Without this urgency, devotion remains postponed. Thus, the secondary theme of death serves the primary theme by creating the necessary urgency for spiritual action.

REASONING: This works because it moves from identification to functional analysis — showing HOW the theme operates in the poem's argument, not just WHERE it appears. Board exams award full marks only for such analytical links.

ANSWER: The secondary theme of death's inevitability appears in Stanza 1 (body's fragility) and Stanza 3 (imminent departure). It functions as a wake-up call: the body will perish, so the soul must be liberated through the Guru before it is too late. This urgency makes the primary theme of devotion time-sensitive and existentially necessary.

## WORKED_EXAMPLE_2
PROBLEM: A student writes: "The secondary themes in 'ckjgeklk' are Maya, death, and Guru." The teacher returns it with "Incomplete — no analysis." Rewrite the answer to meet CBSE Class 12 marking scheme (3 marks).

STEPS:
- Step 1: Recognize the error — listing themes without evidence or functional explanation.
- Step 2: For each theme, add: (a) stanza reference, (b) key idea/image, (c) how it supports the primary theme.
- Step 3: For Maya: Stanza 1 & 3 — worldly pleasures shown as binding illusions ("Hk¡ojk ,s dkx" → "ty vax ykx lj ph:") — reveals the trap from which devotion frees the seeker.
- Step 4: For death: Stanza 1 & 3 — body's decay and approaching end — creates urgency for seeking Guru.
- Step 5: For Guru: Stanza 2 & 3 — Guru's knowledge transforms the seeker ("lq#t tM+kb yad") and is credited for freedom — shows the means to liberation, making devotion possible.
- Step 6: Conclude with a synthesizing sentence: "Together, these secondary themes construct the existential crisis that only true devotion (primary theme) resolves."

REASONING: The marking scheme requires: identification (1 mark), textual evidence (1 mark), analytical link to primary theme (1 mark). This structure ensures all three.

ANSWER: 
1. Maya (Illusion): In Stanza 1, sensory pleasures ("Hk¡ojk ,s dkx") entrap the soul; in Stanza 3, they are recognized as chains ("fcjg iou gksb >ksyk"). This progression from entanglement to awareness prepares the ground for the primary theme — only by piercing Maya can one turn to true devotion.
2. Death: Stanza 1 hints at the body's fragility ("fufl ck<+h"); Stanza 3 makes it immediate ("fcjg iou gksb >ksyk"). Death's certainty creates the urgency that makes spiritual awakening a necessity, not a choice.
3. Guru's Grace: Stanza 2 shows the Guru imparting discriminative knowledge ("lq#t tM+kb yad"); Stanza 3 attributes liberation to the Guru's intervention ("rqEg fcuq oaQrk èkfu g#bZ"). The Guru is the active agent of the primary theme — without grace, devotion remains theoretical.

These secondary themes are not decorative; they structure the poem's argument: Maya binds, death presses, Guru liberates.

## WORKED_EXAMPLE_3
PROBLEM: Compare the treatment of the secondary theme 'the body as a site of spiritual struggle' in Kabir's "ckjgeklk" and a Class 11 poem from Aroh (e.g., "Meera Ke Pad" or "Surdas Ke Pad"). Write a 150-word comparative analysis for a CUET-style question.

STEPS:
- Step 1: Recall the Class 11 poem's treatment of the body — e.g., in Meera's poems, the body is a temple for Krishna, longing for union; in Surdas, the body is a vessel for divine play.
- Step 2: In "ckjgeklk," the body is a fragile, decaying structure ("fufl ck<+h") and a prison of Maya ("Hk¡ojk ,s dkx") — the struggle is to transcend it through knowledge.
- Step 3: Identify the difference: Kabir (Nirguna) sees the body as an obstacle to be seen through; Meera/Surdas (Saguna) see it as a medium for loving devotion.
- Step 4: Find a similarity: Both traditions acknowledge the body's temporariness and the need to direct it toward the divine.
- Step 5: Structure the comparison: (a) State the theme, (b) Kabir's view with evidence, (c) Saguna poet's view with evidence, (d) Philosophical difference (Nirguna vs Saguna), (e) Shared insight.
- Step 6: Write concisely, using terms like "Nirguna Bhakti," "Saguna Bhakti," "Maya," "Prema Bhakti."

REASONING: CUET and competitive exams test comparative literary analysis across texts and traditions. This requires synthesizing Class 11 and 12 knowledge, using precise terminology, and showing conceptual depth.

ANSWER: In Kabir's "ckjgeklk" (Nirguna tradition), the body is a transient, illusory cage ("fufl ck<+h") where Maya binds the soul through sensory pleasures ("Hk¡ojk ,s dkx"). The struggle is epistemological: to realize the body's unreality through the Guru's knowledge and detach. In contrast, Meera's pads (Saguna tradition) treat the body as a devoted bride's abode — "this body is Yours, O Giridhar" — where longing (viraha) sanctifies the flesh. The body is not rejected but offered. Yet both acknowledge its mortality: Kabir warns "death approaches" ("fcjg iou gksb >ksyk"); Meera sings "this body will perish, only Your name remains." The difference lies in the path: Nirguna uses viveka (discrimination) to transcend the body; Saguna uses prema (love) to surrender it. Both converge on the insight that the body's true purpose is divine realization — whether by seeing through it or giving it wholly.

## COMPETENCY_QUESTION_1
QUESTION: Read the following assertion and reason. Choose the correct option.
Assertion (A): In "ckjgeklk," the secondary theme of Maya is not merely decorative but structurally necessary for the poem's argument.
Reason (R): The poem moves from the seeker's entanglement in Maya (Stanza 1) to its explicit recognition as illusion (Stanza 3), and this progression mirrors the journey from ignorance to knowledge that the primary theme (Guru-led liberation) depends on.
Options:
(a) Both A and R are true, and R correctly explains A.
(b) Both A and R are true, but R does not explain A.
(c) A is true, R is false.
(d) A is false, R is true.

COMPETENCY: Critical Thinking - Argument Analysis
STEPS:
- Step 1: Evaluate Assertion (A) — Is Maya structurally necessary? Yes, because without the problem (Maya), the solution (liberation) has no stakes.
- Step 2: Evaluate Reason (R) — Does the poem show this progression? Yes, Stanza 1 shows unconscious entanglement, Stanza 3 shows conscious rejection.
- Step 3: Check if R explains A — R describes the structural role of Maya in enabling the primary theme's arc. This is exactly why Maya is structurally necessary.
- Step 4: Select option (a).

ANSWER: (a) Both A and R are true, and R correctly explains A. The progression from entanglement to recognition of Maya is the very structure that makes the primary theme of liberation meaningful and earned.
DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: A CUET-style case-based question: 
"Read the excerpt from a student's essay on 'ckjgeklk':
'Kabir uses the image of the weaver's loom not just as a metaphor for the body but as a structural device to layer three secondary themes: the rhythm of breath (life/death), the thread of Guru's word (knowledge), and the fabric of Maya (illusion). The loom's shuttle moving back and forth mirrors the soul's oscillation between attachment and detachment.'
Based on the poem, evaluate this interpretation. Is the loom image explicitly present in the text? If not, what textual evidence supports or contradicts the student's reading? Write a 100-word critique."

COMPETENCY: Textual Evidence Evaluation / Intertextual Reasoning
STEPS:
- Step 1: Check the poem for explicit loom/weaver imagery. The poem is by Kabir (a weaver), but "ckjgeklk" does NOT explicitly mention loom, shuttle, or thread. The student is importing biographical knowledge.
- Step 2: Assess if the themes map to the poem without the loom. Breath/life-death: yes (Stanza 1, 3). Guru's word: yes (Stanza 2). Maya as fabric: metaphorical stretch — Maya is described as sensory pleasures and bonds, not woven fabric.
- Step 3: The interpretation is creative but not textually grounded in THIS poem. It conflates Kabir's biography with the poem's internal imagery.
- Step 4: A valid critique must: (a) note the absence of loom imagery in the text, (b) acknowledge the thematic parallels are plausible but inferred, (c) warn against reading biography into text without textual anchors.
- Step 5: Write concisely.

ANSWER: The interpretation is imaginative but not textually supported. The poem "ckjgeklk" contains no reference to a loom, shuttle, or thread — these are biographical imports from Kabir's life. While the three themes (breath/death, Guru's word, Maya) are genuinely present, mapping them onto a loom structure is an external imposition. Stanza 1 describes the body as a fragile structure ("fufl ck<+h"), not a woven fabric. Stanza 2 focuses on the Guru's knowledge ("lq#t tM+kb yad"), not a thread. Stanza 3 depicts Maya as binding chains ("fcjg iou gksb >ksyk"), not textile. Good literary analysis stays anchored in the text's own images; biographical context enriches but cannot replace textual evidence.
DIFFICULTY: hard