## DEFINITION
The primary theme is the central, unifying idea or insight about human experience that the text explores through its narrative elements; the message is the author's implied perspective or call to action regarding that theme, often revealing a critique of societal structures.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student can independently identify the primary theme of the chapter, cite at least three distinct textual evidences (plot events, character actions, setting details) that develop this theme, and articulate the author's message in a coherent paragraph using the PEEL structure.

## SCOPE_BOUNDARY
This node covers only the identification and analysis of the *primary* theme (the exploitation of brick-kiln labourers and the irony of state-driven development) and the author's core message. It does NOT cover secondary themes (e.g., environmental degradation, gender dynamics) which are addressed in node c11_hin_v_cbse_02_007, nor does it cover literary devices like irony or symbolism in isolation (nodes 008, 009).

## WALKTHROUGH
Imagine you pass a construction site and see workers carrying bricks in the scorching heat — you might wonder who they are and why their labour builds cities they cannot live in. This chapter makes that invisible labour visible. To find the primary theme, start by listing the recurring conflicts: the kiln owner’s indifference, the workers’ physical degradation, the seasonal cycle of debt, and the state’s absence. Next, ask what *idea* connects all these conflicts — not just "brick-making" but "systemic exploitation masked as progress." Then, trace how the protagonist Harkhu’s helplessness and the kiln’s cyclical cruelty reinforce this idea. Finally, formulate the message: the author urges us to recognize that development built on dehumanisation is a hollow irony, demanding structural empathy, not charity.

## DIAGNOSTIC_QUESTION_1
What is the difference between a 'topic' (subject) and a 'theme' in a literary text?

## DIAGNOSTIC_ANSWER_1
A topic is the surface-level subject (e.g., "brick kilns" or "migrant labour"), stated in a word or phrase. A theme is a complete sentence expressing the author's insight about that topic (e.g., "Industrial progress in India relies on the invisible, cyclic exploitation of landless labourers"). A wrong answer (e.g., "The theme is brick-making") reveals the student conflates subject with thematic statement, a fundamental category error that prevents deeper analysis.

## DIAGNOSTIC_QUESTION_2
The chapter describes the kiln owner as "not a cruel man" yet the workers suffer immensely. Explain how this characterization supports the primary theme rather than contradicting it.

## DIAGNOSTIC_ANSWER_2
The owner's lack of personal malice highlights *structural* exploitation: the system (seasonal debt, piece-rate wages, state indifference) forces even "non-cruel" employers to perpetuate cruelty. The theme is not about individual villainy but systemic complicity. A wrong answer (e.g., "The owner is actually kind, so there is no exploitation") shows the student reads character morality in isolation, missing the sociological critique central to the chapter.

## DIAGNOSTIC_QUESTION_3
Using the PEEL structure, write a short paragraph proving that the *seasonal cycle of the kiln* (not just the working conditions) is a key driver of the primary theme.

## DIAGNOSTIC_ANSWER_3
**Point:** The kiln’s seasonal rhythm entraps workers in a cycle of debt and physical ruin. **Evidence:** The text details how advance payments (*pesgi*) bind families for months, how monsoon halts work but not interest, and how the kiln reopens only when labourers are desperate. **Explanation:** This cycle transforms temporary poverty into hereditary bondage; the "advance" is not a loan but a leash. **Link:** Thus, the calendar itself becomes an instrument of exploitation, reinforcing the theme of systemic, inescapable oppression. A weak answer lists hardships without connecting them to the *cyclical structure* as a causal mechanism.

## DIAGNOSTIC_QUESTION_4
Compare the depiction of the state (*jktLFkku*) in the title and the final paragraphs. How does the irony in the title "जक्तLFककु ध जत्र चव¡नस" deepen the primary theme?

## DIAGNOSTIC_ANSWER_4
The title promises state power/protection; the text shows the state only as the distant consumer of bricks (roads, buildings) while its laws (minimum wage, safety) are absent at the kiln. The irony — state power *is* the irony — elevates the theme from "labour exploitation" to "state-sanctioned exploitation." A wrong answer treats the title as merely descriptive ("the chapter is about state kilns") missing the satirical gap between constitutional mandate and ground reality that the author constructs.

## DIAGNOSTIC_QUESTION_5
Critique the view that the chapter’s message is simply "we should help the poor." Defend a more precise formulation of the author’s message using textual evidence.

## DIAGNOSTIC_ANSWER_5
The text shows charity (e.g., the owner’s occasional *pesgi* or festival bonus) fails to break the cycle; only systemic change (enforced wages, land reform, kiln regulation) can. The message is: *Development that ignores the producer’s humanity is structurally violent and politically illegitimate.* A "help the poor" reading individualises a structural problem, echoing the very paternalism the chapter critiques (e.g., the owner’s "kindness" as a trap).

## DIAGNOSTIC_QUESTION_6
Write a 4-line poem or a 50-word micro-story from the perspective of a brick that *embodies* the primary theme of the chapter.

## DIAGNOSTIC_ANSWER_6
*Clay remembers the hand that pressed it,*
*Fire forgets the breath that fed it.*
*Wall stands tall on buried sighs —*
*Progress counts bricks, not lives.*
A poor answer writes a generic sad poem about bricks without linking each line to a specific textual mechanism (advance debt, seasonal cycle, state absence) showing the theme wasn't internalised.

## COMMON_MISCONCEPTION
Students often equate the primary theme with the *most repeated topic* (e.g., "brick-making process" or "hard work of labourers") because the text spends many pages describing technical steps (moulding, drying, firing). They miss that the *process description serves the theme* — the meticulous detail of *how* bricks are made exposes *how* labour is extracted. The theme is not "brick-making is hard" but "the brick-making industry is engineered to externalise its human cost onto the most vulnerable."

## ON_FAILURE
1. **Re-anchor**: Give the student three sentence stems: "The text shows that brick kilns run on ______," "The state's role is ______," "Harkhu’s story proves that ______." Have them complete using only plot points from nodes 002, 004. 2. **Contrast**: Provide two thematic statements — one topical ("Brick kilns employ migrants"), one analytical ("Migrant labour is trapped by advance-debt cycles that the state ignores") — and ask which *explains* the other. 3. **Visual Map**: Draw a 3-circle Venn: Plot Events, Character Choices, Setting Constraints. Place 5 textual details in overlaps. The theme lives in the triple overlap. 4. **Message Draft**: Ask: "If the author wrote a letter to the Labour Minister, what *one* demand would she make?" That demand = message.

## BUILDS_ON
Character analysis (nodes 004, 005) and plot structure (node 002) provide the raw evidence; setting (node 003) provides the structural constraints that make the theme systemic rather than individual.

## LEADS_TO
Secondary themes (node 007) such as environmental cost and gendered labour; literary devices (nodes 008, 009) that *encode* the primary theme (e.g., the kiln as symbol); critical thinking (node 013) and writing tasks (node 014) that require thematic argumentation.

## PREREQUISITE_NODE_IDS
c11_hin_v_cbse_02_001, c11_hin_v_cbse_02_002, c11_hin_v_cbse_02_003, c11_hin_v_cbse_02_004, c11_hin_v_cbse_02_005
## PREREQUISITE_REASONS
c11_hin_v_cbse_02_001: Context on migrant labour and kiln economy frames why exploitation is structural.
c11_hin_v_cbse_02_002: Plot events (advance payment, seasonal closure, kiln reopening) are the narrative backbone of the theme.
c11_hin_v_cbse_02_003: The kiln’s physical geography (isolation, heat, temporary shelters) materialises the workers’ entrapment.
c11_hin_v_cbse_02_004: Harkhu’s internal conflict (dignity vs. survival) personifies the theme.
c11_hin_v_cbse_02_005: Supporting characters (owner, contractor, fellow workers) show the theme’s social breadth.

## FORWARD_NODE_IDS
c11_hin_v_cbse_02_007, c11_hin_v_cbse_02_008, c11_hin_v_cbse_02_009, c11_hin_v_cbse_02_012, c11_hin_v_cbse_02_013, c11_hin_v_cbse_02_014, c12_hin_v_cbse_02_006

## FORWARD_REASONS
c11_hin_v_cbse_02_007: Secondary themes branch from the primary theme’s core conflict (exploitation).
c11_hin_v_cbse_02_008: Imagery (fire, clay, smoke) and metaphor (kiln as furnace of lives) aesthetically render the primary theme.
c11_hin_v_cbse_02_009: Irony (title vs. reality) and symbolism (brick as frozen labour) are the *techniques* conveying the theme.
c11_hin_v_cbse_02_012: Comprehension questions often ask "What is the central idea?" — direct application.
c11_hin_v_cbse_02_013: Critical interpretation *is* thematic analysis extended to evaluation.
c11_hin_v_cbse_02_014: Writing tasks (article, speech, letter) require a clear thematic thesis statement.
c12_hin_v_cbse_02_006: अगला तार्किक चरण: The primary theme of a literary work is its central, unifying idea or insight about human experience... इस नोड की अवधारणाओं को सीधे उपयोग/विस्तारित करता है।  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
(No prior class nodes available for Hindi Vitan; cross-subject links are built forward in CROSS_SUBJECT below.)

## CHAIN_DESCRIPTION
c11_hin_v_cbse_02_002 -> c11_hin_v_cbse_02_006 -> c11_hin_v_cbse_02_007

## THIS_FORMULA
N/A - conceptual

## FORMULA_VARIABLES
N/A

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
analytical

## CROSS_SUBJECT
c11_economics_labour_market_segmentation | The chapter illustrates dual labour markets: kiln workers are in the informal segment with no wage floor, job security, or social protection — a live case study for Class 11 Economics' "Employment: Growth, Informalisation" unit.
c11_sociology_structural_inequality | The advance-debt cycle (*pesgi*) mirrors the sociological concept of "debt bondage" and "caste-class nexus" in rural India, linking to Class 11 Sociology's "Social Structure, Stratification and Social Processes."
c11_geography_industrial_location_factors | Kiln locations (riverbeds for clay, near towns for transport) exemplify Weber’s least-cost location theory modified by labour exploitation — relevant to Class 11 Geography's "Industrial Location" chapter.
c11_civics_rights_of_marginalised | The absence of state enforcement of labour laws at kilns demonstrates the gap between *de jure* rights (Articles 23, 24, 43) and *de facto* reality — core to Class 11 Political Theory's "Rights" and "Social Justice" chapters.

## PREREQ_CONCEPT
Ability to distinguish plot summary from thematic inference, and to treat setting as an active constraint on character agency (not just backdrop).

## PREREQ_BEFORE
Student must have completed a close reading of the chapter with annotations on: (a) every instance of money/debt, (b) every description of physical suffering, (c) every reference to the state/law/outside world.

## PREREQ_STUCK
If stuck, review **c11_hin_v_cbse_02_004 (Character Analysis: Protagonist)** focusing on Harkhu’s decision points — each decision reveals a structural constraint that *is* the theme.

## WORKED_EXAMPLE_1
PROBLEM: A student writes: "The main theme of the chapter is the hard life of brick kiln workers." Upgrade this to a board-exam quality thematic statement with textual anchoring.

STEPS:
- Step 1: Identify the weakness — "hard life" is a topic/observation, not a thematic insight; it lacks the *systemic cause* and *authorial perspective*.
- Step 2: Recall the three structural pillars from the text: (i) advance-debt bondage (*pesgi*), (ii) seasonal unemployment forced by monsoon/kiln cycle, (iii) state/legal absence at the production site.
- Step 3: Synthesize into a complete sentence: "The chapter exposes how the brick-kiln industry, driven by state infrastructure demand, structurally entraps migrant families in cyclic debt-bondage through seasonal piece-rate labour."
- Step 4: Select three precise evidences: (a) Harkhu’s *pesgi* of ₹5000 binding his family for 6 months, (b) the kiln’s closure in monsoon leaving workers income-less but debt-intact, (c) the final paragraph’s contrast between the smooth roads built and the broken bodies unseen.
- Step 5: Verify — does the statement explain *why* the life is hard (structure, not accident) and *who* benefits (state/development)? Yes. This is now a defensible primary theme.

REASONING: Thematic statements must be arguable, causally explanatory, and textually grounded. The upgrade moves from description to analysis by naming the mechanism (debt-bondage, seasonality, state complicity).

ANSWER: **Primary Theme:** "The brick-kiln industry, fuelled by state-led construction, operates through a seasonal debt-bondage system that converts migrant families' labour into infrastructure while externalising their survival costs." **Message:** "Development that renders its producers invisible and rightless is morally illegitimate; the state must enforce labour dignity at the point of production, not just consume its output."

## WORKED_EXAMPLE_2
PROBLEM: The exam asks: "How does the description of the kiln’s *technical process* (moulding, drying, firing) contribute to the primary theme?" Write a structured answer.

STEPS:
- Step 1: Deconstruct the prompt — it asks for *function of technical description* in *thematic development*, not a summary of the process.
- Step 2: List the technical stages with their human counterparts from text: (a) Clay preparation → workers' bodies softened by hunger; (b) Moulding → repetitive motion erasing individuality; (c) Drying → exposure to sun mirroring workers' exposure to elements; (d) Firing → kiln heat consuming workers' health like fuel.
- Step 3: Identify the pattern — each technical stage is a metaphor for human extraction. The process *is* the exploitation mechanism.
- Step 4: Formulate the argument: The detailed process description serves three thematic functions: (i) it makes visible the *quantum* of labour per brick (countering invisibility), (ii) it parallels the *stages of worker depletion* (body → identity → health → life), (iii) it contrasts the *permanence of the brick* with the *transience of the worker*.
- Step 5: Write the PEEL answer: **Point:** The technical procession is not documentary but thematic metaphor. **Evidence:** The text spends 3 pages on moulding/drying/firing while workers' wages are mentioned in one sentence ("₹2 per 1000 bricks"). **Explanation:** This disproportion mirrors the economy: immense labour value, negligible labour cost. **Link:** Thus, the process description *enacts* the theme — the brick is the worker's life solidified.

REASONING: Students often describe *what* happens in the kiln. The skill is to pivot to *what the description does* for the theme. The parallelism between material transformation and human degradation is the analytical key.

ANSWER: The kiln’s technical process (clay→mould→dry→fire) structurally mirrors the worker’s degradation (body→labour→health→life), making the brick a materialised metaphor for extracted humanity. The text’s disproportionate attention to process over wages replicates the industry’s logic: the product matters, the producer doesn’t.

## WORKED_EXAMPLE_3
PROBLEM: A board question: "The title 'जक्तLFककु ध जत्र चव¡नस' is the key to the chapter’s message. Discuss with reference to the ending." (6 marks)

STEPS:
- Step 1: Decode the title — *jktLFkku* = state/power, *jtr* = irony/paradox, *cw¡nas* = smile/grimace. Literal: "The State's Power's Ironic Smile." The state smiles (builds roads) because the kiln suffers (workers die).
- Step 2: Analyse the ending — the final paragraphs contrast the "smooth roads" and "tall buildings" (state's achievement) with the "broken bodies," "unpaid wages," and "silent return" of workers. The state is absent as a regulator, present only as a consumer.
- Step 3: Connect title to ending — the "irony" is that state power *derives* from the very exploitation it constitutionally forbids. The "smile" is the finished infrastructure; the "grimace" is the kiln reality.
- Step 4: Extract the message — the author refuses to separate "development" from "exploitation." The message: *Legitimate power cannot be built on illegitimate labour.*
- Step 5: Structure the 6-mark answer: (1) Title interpretation (2 marks), (2) Ending analysis with 2 quotes/paraphrases (2 marks), (3) Synthesis: how title frames the ending as systemic critique, not episodic tragedy (2 marks).
- Step 6: Refine language for board style — use terms: "structural irony," "constitutional mandate vs. ground reality," "externalisation of social cost."

REASONING: This question tests the highest skill: using a literary device (ironic title) to unlock the message, grounded in textual evidence. The 6 marks demand a mini-essay with clear segmentation.

ANSWER: The title encapsulates the chapter’s core irony: the state’s visible power (roads, buildings) is materially sustained by the invisible, rights-less labour of kiln workers. The ending juxtaposes the "smooth highways" — the state’s smile — with Harkhu’s family returning "empty-handed, coughing" — the grimace. The state appears only as a consumer of bricks, never as a guarantor of wages or safety. Thus, the "irony" is structural: constitutional protections (Art. 23, 43) are suspended at the kiln gate. The message is unambiguous: development that consumes its makers’ dignity is a paradox the republic must resolve, not celebrate.

## COMPETENCY_QUESTION_1
QUESTION: A Class 11 student argues: "The primary theme is 'poverty' because the workers are very poor." Evaluate this claim. Is 'poverty' a theme? If not, what is the thematic relationship between poverty and the primary theme? Use the chapter to justify.

COMPETENCY: Critical evaluation of thematic formulation; distinguishing condition from structure.

STEPS:
- Step 1: Define 'theme' vs. 'condition' — poverty is a *condition* depicted; theme is the *explanatory framework* the text builds around it.
- Step 2: Show from text — poverty pre-exists the kiln (workers arrive poor), but the kiln *reproduces and deepens* it through *pesgi*, piece-rates, seasonal lockout. The theme is this *reproduction mechanism*, not poverty itself.
- Step 3: Identify the author's move — the text asks "Why does poverty persist despite hard work?" Answer: because the system is designed to extract surplus, not sustain life.
- Step 4: Formulate corrected theme — "Cyclic exploitation of pre-existing poverty by informal industrial structures."
- Step 5: Conclude — 'Poverty' is the raw material; 'exploitation of poverty' is the theme.

ANSWER: 'Poverty' is a depicted condition, not a theme. The primary theme is *how the kiln system structurally converts poverty into hereditary bondage via advance-debt, seasonal unemployment, and state absence*. The text shows workers entering poor and leaving poorer — the theme is the *mechanism of impoverishment*, not the state of being poor.

DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: The chapter ends with the image of the "brick" travelling from kiln to road to building. Trace this journey in the text and explain how it serves as a *structural metaphor* for the primary theme. Your answer must integrate: (a) the physical journey, (b) the social relations at each stage, (c) the final irony.

COMPETENCY: Synthesis of narrative trajectory, social structure, and symbolic meaning; board-style long answer writing.

STEPS:
- Step 1: Map the brick’s physical journey — (i) clay pit (riverbed), (ii) moulding yard (worker’s hands), (iii) drying field (sun/rain), (iv) kiln firing (coal/fire), (v) truck transport, (vi) construction site (cement/mason), (vii) finished wall/road.
- Step 2: At each stage, name the social relation — (i) landless labourer digging clay, (ii) moulder paid per piece, (iii) family guarding stacks unpaid, (iv) fireman breathing soot, (v) contractor deducting breakage, (vi) mason unaware of kiln, (vii) citizen driving on road.
- Step 3: Identify the metaphor — the brick *carries* the labour but *erases* the labourer. At each transfer, the worker’s identity is stripped; only the commodity remains.
- Step 4: Link to primary theme — this erasure *is* the exploitation: value moves upward, vulnerability stays downward.
- Step 5: Final irony — the road enables the state’s mobility; the worker is immobilised by debt. The brick connects them but the state denies the link.
- Step 6: Write integrated answer with PEEL paragraphs for each stage, culminating in the metaphor’s thematic payoff.

ANSWER: The brick’s journey from riverbed to highway is the chapter’s central structural metaphor. At the clay pit, the landless body bends; at the mould, the piece-rate hand repeats; at the drying field, the family watches unpaid; at the kiln, the fireman’s lungs blacken; on the truck, the contractor counts; at the site, the mason lays; on the road, the citizen drives. Each transfer extracts value and discards the human. The brick arrives clean, red, uniform — the worker’s sweat fired into invisibility. The irony: the road that carries the state’s "progress" is paved with the very rights the state guarantees but fails to enforce at the kiln. The brick thus materialises the theme: **development as the organised forgetting of its producers.**

DIFFICULTY: hard