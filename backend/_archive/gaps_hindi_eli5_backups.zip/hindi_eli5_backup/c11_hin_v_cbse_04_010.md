## DEFINITION
Vocabulary in context refers to the analysis of how specific word choices within a literary text shape meaning, tone, and theme through their denotation (literal dictionary meaning), connotation (associated emotional and cultural associations), word families (groups of words sharing a common root or semantic core), and register (level of formality). In Hindi Vitan Chapter 4, key words are not merely carriers of information but instruments of literary and argumentative craft — each word choice opens or closes interpretive possibilities, positions the reader's response, and constructs the thematic architecture of the chapter. Understanding vocabulary in context means reading words not as isolated dictionary entries but as nodes in a semantic web where each word's meaning is activated, modified, and deepened by its surrounding textual environment, its cultural resonances, and its relationship to other words in the same word family.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student must independently identify at least five key words from the chapter, explain each word's denotation and connotation within its specific textual context, trace at least two words to their word families (root, derivatives, related forms) and explain how the family relationship enriches the word's meaning in context, and demonstrate how replacing a key word with a synonym would alter the tone or thematic implication of the passage. The student must also analyze how the author's choice of register (formal, colloquial, archaic, technical) positions the reader and serves the chapter's argumentative purpose, and explain how the denotation-connotation gap in at least one key word creates a layer of meaning that a surface reading would miss.

## SCOPE_BOUNDARY
This node covers the analysis of key vocabulary words in their textual context within Hindi Vitan Chapter 4, including denotation, connotation, word families, register, semantic fields, and word choice as thematic strategy. It does NOT cover grammar and sentence structure (addressed in node 011), literary devices such as metaphor or irony (addressed in sibling device nodes), or plot and narrative structure (addressed in node 002). It does not extend to comparative vocabulary analysis across chapters or detailed etymological analysis beyond what is necessary for understanding word families and connotations.

## WALKTHROUGH
Imagine a doctor who tells a patient "you have a *condition*" versus one who says "you have a *disease*." Both words denote the same medical reality, but "condition" connotes neutrality and manageability while "disease" connotes severity and threat. Same denotation, different connotation, entirely different emotional world. That is the denotation-connotation gap — the space where literary meaning lives. Now open the chapter and pick a passage that strikes you. List every word that carries emotional or thematic weight. For each, ask: (1) What does this word literally mean (denotation)? (2) What feelings, associations, or cultural meanings does it carry beyond the literal (connotation)? (3) Is there a gap between what the word *says* and what it *implies* — and does the author exploit that gap? Next, take a key word and trace its *family* — its root, its derivatives, its related forms. A word family is not just a list of relatives; it is a *semantic genealogy* that reveals the word's core meaning and its variations. When an author chooses one member of a word family over another, the choice activates the *family resonance* — the reader senses the presence of the root even in its derivative, and the unchosen family members hover as *ghosts* around the chosen one, enriching its meaning through what they *could* have said. Then look for the author's register choices — formal words in colloquial contexts, colloquial words in formal contexts, archaic words in modern contexts. A register *mismatch* is never accidental: it signals a deliberate disruption that draws attention to the word and marks a thematic point. The key insight: vocabulary analysis is not about looking up definitions but about understanding words as *choices* — each one an act of selection that opens one meaning, closes another, and activates a family of related meanings that surround the chosen word like an aura.

## DIAGNOSTIC_QUESTION_1
Define "denotation" and "connotation" in your own words, then give one example from everyday Hindi usage where the denotation-connotation gap creates a layer of meaning that a surface reading would miss (not from the textbook).

## DIAGNOSTIC_ANSWER_1
Denotation is the literal, dictionary definition of a word — its neutral, context-free meaning. Connotation is the set of emotional, cultural, and associative meanings that a word carries beyond its literal definition. The denotation-connotation gap is the space between what a word *says* (denotation) and what it *implies* (connotation) — and authors exploit this gap to create layered meaning. Example: the Hindi word "साधारण" (sadharan) denotes "ordinary, common" but connotes "unremarkable, insignificant, beneath notice." When a character is described as "साधारण," the denotation is neutral (ordinary) but the connotation is dismissive (not worth attention) — the gap between "ordinary" and "insignificant" is where the author's judgment hides. A wrong answer that defines connotation as "a secondary meaning" (treating it as an alternative denotation rather than an associative field) reveals the student has not grasped that connotation is *cultural and emotional*, not definitional — it lives in the reader's associations and the word's cultural history, not in the dictionary.

## DIAGNOSTIC_QUESTION_2
In the chapter, identify a key word where the denotation-connotation gap is significant — where what the word *says* differs from what it *implies*. Explain how the author exploits this gap to create a layer of meaning that a surface reading would miss. What would a reader who reads only for denotation fail to understand?

## DIAGNOSTIC_ANSWER_2
A strong answer identifies a word whose denotation is neutral or straightforward but whose connotation carries an emotional or thematic charge that the denotation does not announce. The author exploits the gap by using the word in a context where the denotation seems innocent but the connotation is loaded — the surface reading (denotation only) misses the *judgment* or *attitude* that the connotation smuggles in. A reader who reads only for denotation would understand *what* the word refers to but miss *how* the author feels about it — the connotation is the author's *evaluation* hidden inside the word's *description*. A wrong answer that identifies a word but treats its connotation as simply "another meaning" (rather than an evaluative or emotional layer) reveals the student can identify the gap but cannot analyze its *function* — the gap is not just a difference but a *strategy* for embedding judgment in description.

## DIAGNOSTIC_QUESTION_3
Take a key word from the chapter and trace its *word family* — its root, its derivatives, and its related forms. List at least three family members. Explain how the family relationship enriches the chosen word's meaning in context. Does the author's choice of *this* family member over *another* activate a specific resonance?

## DIAGNOSTIC_ANSWER_3
A strong answer identifies a word, traces its root (e.g., a Sanskrit or Hindi root), lists at least three derivatives or related forms, and explains how the family relationship enriches the word's meaning. For example, if the root carries a core meaning of "movement" and the author chooses a derivative that connotes *constrained* or *forced* movement (rather than free movement), the choice activates the family resonance of *movement* while specifying it as *coerced* — the reader senses the *possibility* of free movement (from the family) while recognizing its *denial* (from the specific derivative chosen). The unchosen family members (the derivatives connoting free movement) hover as *ghosts* — their absence makes the chosen word's specificity more poignant. A wrong answer that lists family members but treats them as independent words (rather than as variations of a shared core meaning) reveals the student can identify word families but cannot perform *family resonance analysis* — the senior-secondary skill of reading a word's meaning as *enriched* by its family relationships.

## DIAGNOSTIC_QUESTION_4
Identify a semantic field (a cluster of related words) that runs through the chapter — for example, words related to growth/decay, freedom/constraint, light/darkness, sound/silence. List at least four words from this field and explain how the field as a whole constructs one of the chapter's central themes. Is the theme stated explicitly anywhere, or does it emerge only from the word pattern?

## DIAGNOSTIC_ANSWER_4
A strong answer identifies a consistent semantic field (e.g., words of constraint: "बंधन" [bond], "कैद" [imprisonment], "रस्सी" [rope], "दीवार" [wall]) and explains that the repeated use of this field constructs the theme of confinement — not through a single explicit statement but through the *accumulation* of related words that build an atmospheric sense of being trapped. The theme emerges from the *pattern* of word choices, not from any single word or explicit statement. If the theme is *never* stated explicitly, this makes the semantic field the *primary vehicle* of the theme — the reader *feels* the confinement without being *told* about it, which is more powerful because the reader constructs the theme themselves from the evidence of the word pattern. A wrong answer that lists four words but cannot explain how they *collectively* construct a theme reveals the student can identify vocabulary but cannot perform *semantic field analysis* — the senior-secondary skill of reading words as an interconnected system rather than as isolated units.

## DIAGNOSTIC_QUESTION_5
Analyze the author's use of register in the chapter. Identify one passage where the register shifts — from formal to colloquial, from elevated to plain, or from modern to archaic. Explain how the register shift serves a thematic or rhetorical purpose. Why does the author break the register at that specific point?

## DIAGNOSTIC_ANSWER_5
A strong answer identifies a register shift and explains its function. For example, if the author uses formal, literary Hindi throughout a passage of analysis and then shifts to colloquial, direct language in a moment of emotional intensity, the register shift enacts the *breakdown of analytical distance* — the formal register represents the author's controlled, intellectual engagement, and the colloquial shift represents raw, personal feeling breaking through. The shift is not arbitrary but *dramatizes* the emotional turning point: the author uses register as a *structural device* to mark the moment where intellectual analysis gives way to personal investment. A wrong answer that identifies a register shift but explains it as "the author's style" or "for variety" reveals the student sees register as decorative rather than *functional* — missing that register shifts are deliberate rhetorical acts that serve specific thematic purposes at specific argumentative moments.

## DIAGNOSTIC_QUESTION_6
Select a key word from the chapter that you believe is the single most important word for understanding the chapter's central theme. Write a 4-5 sentence justification arguing why *this* word — and not a synonym or related word — is the key that unlocks the chapter's meaning. Address denotation, connotation, word family, and the consequence of its replacement.

## DIAGNOSTIC_ANSWER_6
A strong answer selects a word that is both thematically central and connotatively rich, and justifies its centrality through multiple analytical lenses. For example: "The word [X] is the chapter's key because its denotation (literal meaning) names the chapter's central subject; its connotation (emotional/cultural associations) names the chapter's central attitude; its word family (root and derivatives) connects it to a semantic genealogy that enriches its meaning with the resonance of related forms; and replacing it with a synonym would strip the word of its connotative charge and its family resonance, reducing the chapter from a layered argument to a flat statement." A poor answer that selects a word but justifies it only by its denotation ("it means X and X is the theme") reveals the student cannot perform multi-layered vocabulary analysis — the senior-secondary skill of reading a single word through denotation, connotation, word family, and replacement consequence simultaneously.

## COMMON_MISCONCEPTION
Students treat vocabulary analysis as *dictionary work* — they identify a "difficult" word, look up its meaning, write the definition, and stop. This misses the entire point of vocabulary in context: the word's meaning is not in the dictionary but in the *textual environment*. The specific error is treating synonyms as interchangeable — students write "this word means the same as that word" without recognizing that in literary texts, no two words are truly equivalent because each carries a unique connotative charge and a unique family resonance. A deeper error is identifying word families but treating them as lists of related words rather than as *semantic genealogies* — the student catalogues "here are three derivatives of this root" without explaining how the *family relationship* enriches the chosen word's meaning through the resonance of unchosen family members. The root cause is that Class 10 vocabulary work focused on *comprehension* (what does this word mean?) while Class 11 requires *analysis* (why does this word mean what it means *here*, what family does it belong to, and what would change if it were different?).

## ON_FAILURE
Step 1: Select a key passage from the chapter (3-4 sentences). Have the student list every word they consider "significant" — not just unfamiliar words but words that carry emotional or thematic weight. Step 2: For each significant word, create a four-column table: Column A = denotation (dictionary meaning), Column B = connotation (emotional/cultural associations), Column C = word family (root, derivatives, related forms), Column D = "what would change if replaced with a synonym?" Step 3: Ask the student to circle all words in the passage that belong to the same semantic field. Then ask: "What theme does this cluster of related words construct? Is the theme stated explicitly, or does it emerge only from the word pattern?" Step 4: Have the student rewrite the passage replacing three key words with synonyms. Compare original and rewritten versions aloud. Ask: "What is lost? What is gained? Why did the author choose the original words?" This exercise forces the student to experience vocabulary as *choice* rather than as *given*.

## PREREQUISITE_NODE_IDS
c11_hin_v_cbse_04_001, c11_hin_v_cbse_04_002, c11_hin_v_cbse_04_006, c11_hin_v_cbse_04_005

## PREREQUISITE_REASONS
c11_hin_v_cbse_04_001: The "Before You Read" context establishes the biographical, historical, and cultural background necessary to understand the connotations of key words — a word's cultural associations depend on the reader knowing the cultural context, which this node provides.
c11_hin_v_cbse_04_002: Plot and narrative structure analysis establishes where key words appear in the narrative arc, which is essential because a word's connotation is contextually determined — the same word can carry different connotations at different points in the narrative.
c11_hin_v_cbse_04_006: Theme analysis identifies the chapter's central themes, which are the *meaning* that semantic fields construct. Without thematic clarity, vocabulary analysis becomes listing rather than interpreting — the student needs to know what theme to connect the word patterns to.
c11_hin_v_cbse_04_005: Key vocabulary is often embedded in descriptions of supporting characters' tools/techniques.  

## FORWARD_NODE_IDS
c11_hin_v_cbse_04_011, c11_hin_v_cbse_04_012, c11_hin_v_cbse_04_013, c12_hin_a_cbse_04_010, c12_hin_a_cbse_07_010

## FORWARD_REASONS
c11_hin_v_cbse_04_011: Grammar and language usage analysis builds on vocabulary analysis — grammatical structures (sentence types, verb forms, rhetorical questions) work *with* word choice to construct meaning. Understanding which words are key (this node) is prerequisite to analyzing how those words are grammatically deployed (node 011).
c11_hin_v_cbse_04_012: Character and characterization analysis requires vocabulary analysis — characters are constructed through their word choices (dialogue) and the narrator's word choices about them (description). This node provides the skill of reading word choice as characterization.
c11_hin_v_cbse_04_013: Critical thinking and interpretation questions in board exams demand evidence-based analysis of how word choice shapes meaning — this node provides the analytical framework (denotation/connotation/word family/replacement) that the critical thinking node will require students to apply independently.
c12_hin_a_cbse_04_010: Class 11 Vitan Vocabulary node reinforced the skill in a different textual genre (prose/non-fiction).  
c12_hin_a_cbse_07_010: Compared vocabulary across genres (poetry vs prose).  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
none

## CHAIN_DESCRIPTION
c11_hin_v_cbse_04_006 -> c11_hin_v_cbse_04_010 -> c11_hin_v_cbse_04_013

## THIS_FORMULA
N/A - conceptual

## FORMULA_VARIABLES
N/A

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
analytical

## CROSS_SUBJECT
N/A

## PREREQ_CONCEPT
Understanding that a word's meaning in a literary text is not fixed by its dictionary definition but is *contextually constructed* — the surrounding text, the cultural background, the word family, and the semantic field all activate specific connotations while suppressing others. Vocabulary analysis is the skill of reading words as *choices* made by an author, each choice opening some meanings and closing others, and each choice activating a family of related meanings that enrich the chosen word beyond its surface definition.

## PREREQ_BEFORE
The student must be able to: (1) identify the chapter's central themes (from node 006); (2) locate key passages in the narrative structure (from node 002); (3) distinguish literal from figurative language; (4) recognize that synonyms are not truly interchangeable in literary contexts — each word carries a unique connotative charge and family resonance.

## PREREQ_STUCK
If the student cannot identify connotations beyond denotation, return to node 001 (Before You Read) and re-establish the cultural context. Then ask: "When you hear this word, what do you *feel*? What images come to mind? What other words does it remind you of — and are those words in the same family?" This shifts the student from dictionary-thinking to association-thinking and family-thinking, which are the foundations of connotative and word family analysis.

## WORKED_EXAMPLE_1
PROBLEM: Identify a key word from the chapter where the denotation-connotation gap is significant. Analyze the word's denotation, connotation, and word family. Then explain how the author exploits the denotation-connotation gap to create a layer of meaning that a surface reading would miss, and how the word family enriches the chosen word's meaning through the resonance of unchosen family members.

STEPS:
- Step 1: Select a key word — choose a word whose denotation seems neutral or straightforward but whose connotation carries an emotional or thematic charge.
- Step 2: Analyze denotation — state the word's literal, dictionary meaning. This is the neutral, context-free definition that a surface reading would access.
- Step 3: Analyze connotation — identify the emotional, cultural, and associative meanings the word carries *in this specific passage*. Ask: what does the word make the reader feel? What cultural associations does it trigger? What does it *imply* that the denotation does not *state*?
- Step 4: Trace the word family — identify the word's root and list at least three derivatives or related forms. Explain how the family relationship enriches the chosen word: the family shares a *core meaning* (the root), and each member specifies it differently. The author's choice of *this* member over *another* activates a specific resonance — the unchosen members hover as *ghosts*, their absence making the chosen word's specificity more pointed.
- Step 5: Analyze the denotation-connotation gap — the gap is where the author *hides judgment in description*. The denotation *describes* (neutral); the connotation *evaluates* (loaded). A surface reader sees only the description; a deep reader feels the evaluation. The word family enriches the gap: the family resonance adds *depth* to the connotation (the chosen word carries the *echo* of its relatives), making the hidden judgment more *resonant* without making it more *visible*.

REASONING: This worked example models the five-step vocabulary analysis framework: select → denotation → connotation → word family → gap analysis. The gap analysis (Step 5) is the critical move that distinguishes senior-secondary analysis from middle-school comprehension — the student must articulate *how the author exploits the gap* between what the word says and what it implies, and *how the word family deepens the gap* by adding resonance without adding visibility.

ANSWER: A complete analysis identifies a key word, explains its denotation (literal meaning) and connotation (emotional/cultural associations), traces its word family (root and derivatives) to show how family resonance enriches the chosen word's meaning, and demonstrates that the author exploits the denotation-connotation gap to embed judgment in description — creating a layer of meaning that a surface reading (denotation only) would miss. The word family deepens the gap by adding resonance from unchosen relatives, making the hidden judgment more *felt* without making it more *stated*.

## WORKED_EXAMPLE_2
PROBLEM: The chapter contains a passage where the author's word choices create a specific tone (e.g., reflective, urgent, ironic, elegiac). Identify the tone, list at least four words from the passage that collectively produce this tone, and explain how the *combination* of these words — drawn from the same or related word families — creates a tone that no individual word could achieve alone.

STEPS:
- Step 1: Identify the tone — read the passage aloud and name the dominant emotional register. Is it reflective, urgent, ironic, elegiac, defiant? The tone is the *overall emotional color* of the passage.
- Step 2: List tone-producing words — identify at least four words that contribute to this tone. Note whether any of these words belong to the same word family or semantic field — if they do, the family/field relationship *amplifies* the tone through resonance.
- Step 3: Analyze each word's contribution — for each word, explain how its connotation (not just denotation) feeds into the overall tone. A word's connotation may *reinforce* the tone (e.g., a word of loss reinforcing elegiac tone) or *create tension* with it (e.g., a word of defiance in an elegiac passage creating a complex, bittersweet tone).
- Step 4: Explain the combinatory effect — the tone emerges from the *interaction* of words, not from any single word. If multiple words share a word family or semantic field, the family/field relationship creates *resonance amplification*: each word's connotation is *deepened* by the presence of its relatives, making the tone more *saturated* than any single word could produce. Identify which word is the *dominant* tone-producer and which words are *supporting* or *contrasting*.
- Step 5: Test the analysis — remove or replace one word and observe how the tone shifts. If the removed word was a family member, its removal also *weakens the resonance* of the remaining family members — the tone does not just lose one word's contribution but loses the *amplification* that the family relationship provided.

REASONING: This worked example models *tone analysis through vocabulary and word families* — the skill of reading tone not as a vague impression but as a *construct* built from specific word choices and amplified by family/field relationships. The combinatory analysis (Step 4) is the critical senior-secondary move: the student must explain how words *interact* to produce tone, and how word family relationships *amplify* the tone through resonance. This skill is directly tested in board exam questions asking "What is the tone of this passage and how does the author create it?"

ANSWER: The passage's tone is produced by the *combination* of at least four key words whose connotations interact to create an emotional chord. If multiple words share a word family or semantic field, the family/field relationship creates *resonance amplification* — each word's connotation is deepened by the presence of its relatives, making the tone more saturated than any single word could produce. No single word produces the tone alone; each contributes a layer (dominant, supporting, or contrasting), and the overall tone emerges from their interaction, amplified by family resonance.

## WORKED_EXAMPLE_3
PROBLEM: Trace a single key word across three different passages in the chapter. For each occurrence, analyze how the word's connotation shifts depending on its context and how different family members appear or are implied in each occurrence. Then explain how the word's *evolution* across the three passages — including its family variations — mirrors or supports the chapter's narrative or thematic arc.

STEPS:
- Step 1: Select a recurring word — choose a word that appears in at least three different passages, ideally with variations in form (different family members) or context. The word should be significant enough that its recurrence is *meaningful*, not merely functional.
- Step 2: Analyze Occurrence 1 — identify the passage context, the word's denotation (constant), and its connotation *as activated by this context*. Note which family members appear explicitly and which are *implied* by the root's presence. What does the word *feel like* here? What associations are triggered by the surrounding text and the family resonance?
- Step 3: Analyze Occurrence 2 — same process. How has the connotation shifted? Has a *different family member* appeared, activating a different resonance? The denotation is the same (or closely related), but the connotation may be *opposite* — a word of freedom in a context of captivity connotes *denied* freedom, while the same word in a context of liberation connotes *achieved* freedom. The family resonance may also shift: one derivative connotes *process*, another connotes *result*.
- Step 4: Analyze Occurrence 3 — same process. How has the word evolved by this third occurrence? Has it accumulated meaning from the previous two? Does it now carry the *memory* of its earlier uses? Are all family members now *present* (explicitly or implicitly), creating a *saturated* resonance that no single occurrence could achieve?
- Step 5: Synthesize the evolution — map the connotative shifts and family variations onto the chapter's narrative or thematic arc. Does the word's journey mirror the chapter's movement? Does the family's progressive appearance trace the development of a theme from one stage to another? The word's evolution — including its family variations — is a *microcosm* of the chapter's larger movement.

REASONING: This worked example models *word tracking with family analysis* — the skill of following a single word and its family across multiple occurrences and analyzing how meaning *accumulates and transforms* through both contextual shifts and family variations. The synthesis step (Step 5) is the critical move: the student must connect the word's micro-evolution (including family resonance) to the chapter's macro-arc, demonstrating that vocabulary is not static but *dynamic* — words and their families grow and change as the text progresses.

ANSWER: A recurring word's connotation evolves across three occurrences as the surrounding context shifts and different family members appear or are implied, creating a *connotative arc* that mirrors the chapter's narrative or thematic development. The word's denotation remains constant (or closely related across family members), but its connotation transforms — accumulating meaning from each previous use and carrying the memory of earlier contexts into later ones. The family's progressive appearance creates *saturated resonance* — by the third occurrence, the word carries the echo of all its relatives, making it a *microcosm* of the chapter's larger movement.

## COMPETENCY_QUESTION_1
QUESTION: A critic claims: "The author's vocabulary in this chapter is deliberately plain and everyday — the author avoids difficult or literary words to make the chapter's argument accessible to ordinary readers." (a) Identify two words from the chapter that either *support* or *challenge* this claim. (b) For each word, explain whether its plainness is *genuine accessibility* or *rhetorical strategy* — does the author use plain words because they are simple, or because plainness serves a specific thematic purpose? (c) Evaluate the critic's claim: is "plain vocabulary" the same as "simple meaning"? Use the denotation-connotation distinction to support your evaluation.

COMPETENCY: Evaluating critical claims about vocabulary using textual evidence — distinguishing between surface simplicity and strategic plainness, a key analytical skill for board exam "evaluate" questions.

STEPS:
- Step 1: Test the claim — select two words that appear "plain" or "everyday." Check whether their denotation is indeed simple and accessible, or whether their connotation carries complexity that the surface plainness conceals.
- Step 2: Analyze Word 1 — if the word's denotation is plain but its connotation is rich (e.g., a common word that carries deep cultural or emotional associations in context), then the plainness is *strategic* — the author uses an accessible surface to carry a complex emotional or thematic payload. This *challenges* the critic's claim that plainness equals accessibility.
- Step 3: Analyze Word 2 — if the word is genuinely plain in both denotation and connotation (a functional word with no significant connotative charge), then it *supports* the claim for *that specific word*. But one plain word does not prove the whole vocabulary is plain — the critic overgeneralizes.
- Step 4: Evaluate the claim using denotation-connotation — "plain vocabulary" (simple denotation) is NOT the same as "simple meaning" (simple connotation). A word can be denotatively plain but connotatively complex. The author may choose plain words precisely because their *familiarity* allows complex connotations to slip into the reader's consciousness without resistance — plainness as a *delivery mechanism* for depth, not as a *substitute* for it. The denotation-connotation distinction exposes the critic's error: the critic sees only the denotation (plain) and misses the connotation (complex).
- Step 5: Formulate judgment — the critic's claim is *partially valid* (the vocabulary is denotatively accessible) but *fundamentally misleading* (it conflates surface plainness with semantic simplicity, missing the strategic use of plain words to carry complex connotations through the denotation-connotation gap).

ANSWER: (a) Two words: one denotatively plain but connotatively rich (challenging the claim), one genuinely plain in both dimensions (partially supporting it). (b) The first word's plainness is *strategic* — the author uses familiar surface to deliver complex emotional content through the denotation-connotation gap; the second's plainness is *functional* — it serves the sentence without carrying thematic weight. (c) "Plain vocabulary" (simple denotation) is not the same as "simple meaning" (simple connotation). The critic conflates the two, missing that the author's plainness is a *rhetorical strategy* — using accessible words to carry inaccessible connotations — not a sign of semantic simplicity.

DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: Construct an analytical paragraph (PEEL structure) arguing that the chapter's use of *word families* — the author's choice of specific derivatives from shared roots — is a more sophisticated vocabulary strategy than the use of individual key words, because word families create *resonance* (the echo of unchosen relatives) that individual words cannot achieve. Identify a passage where two or more family members appear, analyze how their co-presence creates resonance, and explain why this resonance is more effective than using unrelated words with similar denotations.

COMPETENCY: Synthesizing word family analysis with thematic argument — constructing an evidence-based paragraph that demonstrates how family resonance creates meaning beyond what individual words can achieve, a senior-secondary analytical skill.

STEPS:
- Step 1: Point — The chapter's use of word families is a more sophisticated vocabulary strategy than individual key words because family co-presence creates *resonance* — the echo of unchosen relatives — that individual words cannot achieve.
- Step 2: Evidence — Identify a passage where two or more family members (derivatives of the same root) appear. Quote each in its sentence. Show that they share a root but differ in connotation (each derivative specifies the root's core meaning differently).
- Step 3: Explanation — When two family members co-occur, the reader senses the *shared root* beneath both — the core meaning that unites them. This creates *resonance*: each word is enriched by the other's presence because the reader *feels* the family relationship. The resonance adds a layer of meaning that neither word carries alone: the *relationship* between the derivatives becomes meaningful (e.g., if one derivative connotes *process* and another connotes *result*, their co-presence creates a *process-to-result* narrative within a single passage). Using unrelated words with similar denotations would lose this resonance — the words would be *parallel* (each carrying its own meaning) but not *related* (sharing a root that deepens both).
- Step 4: Link — This resonance is more effective than individual key words because it creates *depth without explicit statement*: the family relationship *implies* a connection (process → result, potential → actualization) without *stating* it. The reader *feels* the connection through the family resonance rather than being *told* about it, which is more persuasive because the reader constructs the meaning themselves.
- Step 5: Concluding synthesis — The author's use of word families is a *structural* vocabulary strategy, not a decorative one: by choosing derivatives of the same root, the author creates a *semantic genealogy* within the passage — a network of related meanings that resonate with each other, producing depth that individual words, however well-chosen, cannot achieve.

ANSWER: The chapter's use of word families is a more sophisticated vocabulary strategy than individual key words because family co-presence creates *resonance* — the echo of the shared root that enriches each derivative beyond its individual meaning. When two or more family members co-occur, the reader senses the shared root beneath both, creating a layer of meaning (the *relationship* between the derivatives) that neither word carries alone. This resonance is more effective than using unrelated words with similar denotations because it creates *depth without explicit statement*: the family relationship implies a connection without stating it, making the reader construct the meaning themselves. The author's word family strategy is structural, not decorative — it creates a semantic genealogy within the passage.

DIFFICULTY: hard
