## DEFINITION
Plot is the structured sequence of events in a narrative, organized into five stages: exposition (introduction of setting, characters, and initial situation), rising action (development of conflict), climax (turning point of maximum tension), falling action (events after the climax leading toward resolution), and resolution (final outcome). Narrative structure refers to the techniques used to present the plot, such as chronological order, point of view, dialogue, and descriptive passages.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student can independently identify and label the five stages of Freytag's Pyramid in "उद्देश्य का नक्शा" (Uddeshya ka Naksha), explain how the third-person omniscient narrator shapes the reader's understanding of the station master's internal conflict, and trace how the linear chronological structure builds tension toward the climax.

## SCOPE_BOUNDARY
This node covers plot structure (exposition, rising action, climax, falling action, resolution) and narrative techniques (linear chronology, third-person omniscient narration, use of dialogue and description) specifically in Premchand's "उद्देश्य का नक्शा". It does NOT cover character analysis, thematic interpretation, setting analysis, or literary devices like irony/symbolism — those are addressed in sibling nodes c11_hin_ar_cbse_01_003 through c11_hin_ar_cbse_01_009.

## WALKTHROUGH
Have you ever noticed how a good movie hooks you in the first few minutes, builds tension until you're on the edge of your seat, then releases it? That's plot structure at work. In Premchand's "उद्देश्य का नक्शा", we start by asking: what is the "normal world" of the station master before the disruption? The opening paragraphs establish the sleepy railway station, the station master's routine, and his philosophical outlook — that's the exposition. Then the arrival of the railway inspector disrupts this equilibrium. As you read, mark each event that increases the pressure on the station master: the inspector's demands, the station master's resistance, the threat of transfer. The moment the station master submits his resignation is the climax — the turning point where his dignity clashes with the system. After that, events move quickly toward resolution: the inspector's changed attitude, the station master's departure. Notice how Premchand uses a linear timeline (no flashbacks) and an all-knowing narrator who reveals both the station master's thoughts and the inspector's perspective. This structure makes the conflict feel inevitable and universal.

## DIAGNOSTIC_QUESTION_1
What is the definition of 'exposition' in the context of plot structure?

## DIAGNOSTIC_ANSWER_1
Exposition is the opening stage of a plot where the author introduces the setting, main characters, and the initial situation or status quo before the main conflict begins. A wrong answer (e.g., "the most exciting part" or "the ending") reveals the student confuses exposition with climax or resolution, indicating they cannot distinguish the foundational setup from later plot stages.

## DIAGNOSTIC_QUESTION_2
In your own words, explain how the first two pages of "उद्देश्य का नक्शा" function as exposition. What specific details about the station master's character and his world are established?

## DIAGNOSTIC_ANSWER_2
The opening establishes the station master (IafMr vyksihnhu) as a principled, philosophical man who values dignity over compliance, living a quiet routine at a minor railway station during British India. It sets the colonial bureaucratic context and his reputation for integrity. A wrong answer that only summarizes events ("he wakes up, drinks tea, goes to work") without identifying the *characterization* and *conflict seeds* shows the student cannot distinguish mere event-listing from analytical exposition analysis.

## DIAGNOSTIC_QUESTION_3
Identify three specific events from the story that belong to the 'rising action' stage. For each, explain how it escalates the central conflict between the station master and the system.

## DIAGNOSTIC_ANSWER_3
1) The railway inspector's surprise inspection and demand for bribes — introduces external pressure. 2) The station master's refusal to falsify records — escalates to direct defiance. 3) The inspector's threat of transfer and departmental inquiry — raises stakes to career survival. A wrong answer that picks random events (e.g., "the station master eats lunch") or fails to link each event to *escalating tension* shows the student cannot trace cause-effect progression in rising action.

## DIAGNOSTIC_QUESTION_4
Compare the climax of "उद्देश्य का नक्शा" with a typical commercial short story climax. How does Premchand's choice of a quiet resignation letter as the turning point (rather than a dramatic confrontation) affect the story's thematic impact?

## DIAGNOSTIC_ANSWER_4
The climax is the station master submitting his resignation — a quiet, internal decision — not a shouted argument. This underscores the theme of dignified resistance: his power lies in moral refusal, not physical force. A typical commercial story might use a public showdown. A wrong answer that identifies the inspector's anger or the station master's departure as the climax reveals the student equates "climax" with "loudest moment" rather than "point of irreversible change for the protagonist".

## DIAGNOSTIC_QUESTION_5
Evaluate whether the resolution of "उद्देश्य का नक्शा" provides closure or leaves the central conflict open. Support your judgment with two textual details.

## DIAGNOSTIC_ANSWER_5
The resolution provides *personal* closure (the station master leaves with dignity intact) but *systemic* openness (the corrupt bureaucracy continues unchanged). Textual details: 1) The inspector's reluctant respect ("उनकी आँखों में एक अजीब-सी चमक थी") shows individual acknowledgment, 2) The final image of the station master walking away into an uncertain future ("फिर वे चल दिए... पता नहीं कहाँ") emphasizes the system's persistence. A wrong answer claiming "happy ending" or "total defeat" shows binary thinking, missing Premchand's nuanced critique of colonial institutions.

## DIAGNOSTIC_QUESTION_6
Rewrite the final paragraph of the story from the inspector's first-person perspective, maintaining the same plot events but changing the narrative structure to a retrospective frame (looking back years later). How does this shift alter the reader's sympathy?

## DIAGNOSTIC_ANSWER_6
A strong response uses first-person ("I watched him walk away..."), past tense, and reflective tone ("Years later, I still wonder..."). It should show the inspector's delayed guilt or admiration. This shifts sympathy toward the inspector's internal conflict, making the station master a distant symbol rather than a close focal character. A poor answer merely changes pronouns without adding reflection or time shift, revealing the student doesn't grasp how *narrative perspective* (not just plot events) controls emotional alignment.

## COMMON_MISCONCEPTION
Students often believe "plot" is just a synonym for "summary of what happens" and that "narrative structure" means only "beginning, middle, end". They miss that *structure* is the *deliberate arrangement* of events — e.g., why Premchand places the station master's philosophical monologue *before* the inspector's arrival (to establish his moral baseline) rather than after. They also confuse the *climax* (turning point) with the *most dramatic scene* (the inspector's angry outburst), not realizing the resignation letter — a quiet act — is the true structural climax because it's the point of no return for the protagonist's agency.

## ON_FAILURE
If a student cannot map the plot stages: 1) Have them list 8-10 key events in chronological order on sticky notes. 2) Ask them to physically arrange the notes on a Freytag's Pyramid diagram drawn on paper. 3) For each event, ask: "Does this *introduce*, *complicate*, *turn*, *unwind*, or *conclude*?" 4) Finally, have them write one sentence per stage explaining the *function* (not just content) of that stage in *this specific story*. This tactile, function-focused method breaks the "summary habit".

## BUILDS_ON
Basic understanding of story elements (beginning, middle, end) and character motivation from Class 10 prose studies.

## LEADS_TO
Character analysis (c11_hin_ar_cbse_01_004, c11_hin_ar_cbse_01_005) — because plot actions reveal character; theme analysis (c11_hin_ar_cbse_01_006, c11_hin_ar_cbse_01_007) — because plot structure embodies theme; setting analysis (c11_hin_ar_cbse_01_003) — because setting constraints drive plot.

## PREREQUISITE_NODE_IDS
c11_hin_ar_cbse_01_001
## PREREQUISITE_REASONS
c11_hin_ar_cbse_01_001: Provides essential historical context (British India, railway expansion, colonial bureaucracy) and author background (Premchand's reformist intent) without which the plot's conflict (individual vs. system) lacks its socio-political grounding.

## FORWARD_NODE_IDS
c11_hin_ar_cbse_01_003, c11_hin_ar_cbse_01_004, c11_hin_ar_cbse_01_005, c11_hin_ar_cbse_01_006, c11_hin_ar_cbse_01_008, c11_hin_ar_cbse_01_009, c11_hin_ar_cbse_01_010, c11_hin_ar_cbse_01_011, c11_hin_ar_cbse_01_012, c11_hin_ar_cbse_01_013, c11_hin_ar_cbse_01_014, c11_hin_ar_cbse_01_015, c12_hin_a_cbse_01_002, c12_hin_a_cbse_02_002, c12_hin_a_cbse_03_002, c12_hin_a_cbse_04_002, c12_hin_a_cbse_05_002, c12_hin_a_cbse_06_002, c12_hin_a_cbse_07_002, c12_hin_a_cbse_08_002, c12_hin_a_cbse_09_002, c12_hin_a_cbse_10_002, c12_hin_a_cbse_12_002, c12_hin_a_cbse_14_002, c12_hin_a_cbse_17_002, c12_hin_al_cbse_01_002, c12_hin_al_cbse_02_002, c12_hin_al_cbse_03_002, c12_hin_ar_cbse_01_002, c12_hin_ar_cbse_03_002, c12_hin_ar_cbse_05_002, c12_hin_ar_cbse_07_002, c12_hin_ar_cbse_09_002, c12_hin_ar_cbse_12_002, c12_hin_ar_cbse_14_002

## FORWARD_REASONS
c11_hin_ar_cbse_01_003: Plot events are anchored in the station's physical atmosphere; understanding structure helps isolate setting's causal role. c11_hin_ar_cbse_01_004: The protagonist's choices at each plot stage (especially climax) are the primary evidence for character analysis. c11_hin_ar_cbse_01_005: Supporting characters' actions (inspector, wife, villagers) are plot functions; structure reveals their narrative purpose. c11_hin_ar_cbse_01_006: The primary theme (dignity vs. systemic corruption) is enacted through the plot's architecture — climax and resolution embody the thematic statement.
c11_hin_ar_cbse_01_008: Plot structure identifies *where* key images/metaphors cluster (auction scene, death scene) for focused analysis.  
c11_hin_ar_cbse_01_009: Plot knowledge provides the event sequence needed to spot expectation-outcome gaps (irony).  
c11_hin_ar_cbse_01_010: Plot knowledge provides the situational "where/when" that anchors word meanings (e.g., *cjoaQnkth* only makes sense during the inspection scene).  
c11_hin_ar_cbse_01_011: Plot knowledge is needed to contextualize who speaks when and why. c11_hin_ar_cbse_01_010: Vocabulary in Context provides the lexical base; this node extends to grammatical function. c11_hin_ar_cbse_01_008: Literary Devices covers metaphor/imagery; this node focuses on grammatical/stylistic devices.  
c11_hin_ar_cbse_01_012: Plot and narrative structure knowledge is essential to locate evidence in the correct scene sequence  
c11_hin_ar_cbse_01_013: Plot understanding needed before analyzing structure and meaning  
c11_hin_ar_cbse_01_014: Supplies plot structure knowledge to select appropriate Evidence from beginning/middle/climax.  
c11_hin_ar_cbse_01_015: Provides plot and narrative structure knowledge needed to reference specific incidents in discussion.  
c12_hin_a_cbse_01_002: Introduces the concept of lyrical narrative structure in Class 11 Antra poems — this node deepens that skill.  
c12_hin_a_cbse_02_002: Introduces plot vs structure distinction in Class 11 — this node deepens it for board-level analysis.  
c12_hin_a_cbse_03_002: Introduces basic concepts of poetic narrative structure (stanza, refrain, progression) in Class 11 Antra.  
c12_hin_a_cbse_04_002: Class 11 Antra Chapter 1 introduced the five-stage narrative arc applied to narrative poems — this node extends it to dual-poem comparison and structural device analysis.  
c12_hin_a_cbse_05_002: Introduces basic narrative structure concepts in poetry, which this node deepens.  
c12_hin_a_cbse_06_002: Introduces Freytag's pyramid (exposition, rising action, climax) used to map the biographical sketch.  
c12_hin_a_cbse_07_002: Class 11 foundation in analyzing narrative structure in Hindi folk poems — stanza sequencing, temporal markers, refrain function.  
c12_hin_a_cbse_08_002: Introduces the concept of “narrative beats in poetry” — the analytical framework used here.  
c12_hin_a_cbse_09_002: Class 11 introduced narrative arc terminology (exposition, climax, etc.) in prose; this node transfers that to poetry.  
c12_hin_a_cbse_10_002: Introduced basic narrative structure terms (plot, flashback, perspective) in Class 11 Antra prose.  
c12_hin_a_cbse_12_002: Provides foundational understanding of plot stages and narrative devices from Class 11.  
c12_hin_a_cbse_14_002: General Class 11 introduction to plot elements and narrative perspective, prerequisite for Class 12 analytical depth.  
c12_hin_a_cbse_17_002: Introduces fundamental plot terminology (exposition, climax, resolution) and narrative patterns (linear, flashback) that are the analytical tools for this node.  
c12_hin_al_cbse_01_002: Class 11 Plot basics — establishes Freytag's Pyramid and linear narrative vocabulary needed to identify deviations.  
c12_hin_al_cbse_02_002: Establishes foundational knowledge of narrative structure (linear, non‑linear, flashback) that this Class 12 node deepens with a complex text.  
c12_hin_al_cbse_03_002: Introduced narrative time vs. story time in Class 11 Antaral — essential for analyzing the spiral structure here.  
c12_hin_ar_cbse_01_002: Provides foundational narrative vocabulary (exposition, climax, etc.) and story-mountain technique — essential vocabulary for this node's poetry adaptation.  
c12_hin_ar_cbse_03_002: Introduces basic narrative structure terminology (exposition, climax, resolution) applied to poetry — the foundational vocabulary this node deepens.  
c12_hin_ar_cbse_05_002: Establishes the foundational vocabulary (stanza, enjambment, volta, thematic progression) without which structural analysis is impossible.  
c12_hin_ar_cbse_07_002: अगला तार्किक चरण: Plot and Narrative Structure in this chapter refers to the organization of events in the selected ep... इस नोड की अवधारणाओं को सीधे उपयोग/विस्तारित करता है।  
c12_hin_ar_cbse_09_002: Establishes baseline of poetic narrative structure — stanzaic logic, metaphorical progression — which this node deepens.  
c12_hin_ar_cbse_12_002: Provides foundational plot pyramid terminology (exposition, climax, etc.) and narrative perspective definitions.  
c12_hin_ar_cbse_14_002: Introduces basic plot vs. story distinction and frame narrative using "नमक का दरोगा".  
c11_hin_ar_cbse_01_004: Plot node establishes the sequence of events (clinic confrontation, resignation, father's death) that structure the character's arc  
c11_hin_ar_cbse_01_005: Plot structure determines when/where supporting characters enter and exit.  
c11_hin_ar_cbse_01_006: Plot structure reveals the thematic arc through conflict, climax, resolution.  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
none

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_01_001 -> c11_hin_ar_cbse_01_002 -> c11_hin_ar_cbse_01_003

## THIS_FORMULA
Freytag's Pyramid: Exposition → Rising Action → Climax → Falling Action → Resolution

## FORMULA_VARIABLES
Exposition: Introduction of setting, characters, status quo; Rising Action: Series of events complicating the conflict; Climax: Turning point of maximum tension/irreversible decision; Falling Action: Consequences of climax leading toward end; Resolution: Final outcome, new equilibrium.

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
analytical

## CROSS_SUBJECT
c11_history_colonial_india | The story's plot is driven by colonial railway administration — its hierarchies, inspection systems, and corruption — making historical knowledge of British India's bureaucratic machinery essential to grasp the conflict's realism.
c11_civics_bureaucracy | The station master vs. inspector conflict dramatizes the classic public administration tension: rule-following integrity versus systemic pressure for compliance, illustrating Weberian bureaucracy's dehumanizing potential.

## PREREQ_CONCEPT
Ability to distinguish between *event sequence* (what happens) and *plot structure* (why events are ordered this way for effect).

## PREREQ_BEFORE
Student must have read "उद्देश्य का नक्शा" completely at least once and be able to recall the main characters (station master, inspector, wife) and the central conflict (integrity vs. bureaucratic demand).

## PREREQ_STUCK
If stuck, review the story summary focusing only on the station master's *decisions* (not descriptions) — his choice to refuse the bribe, his choice to resign, his choice to leave — as these are the plot's structural joints.

## WORKED_EXAMPLE_1
PROBLEM: Map the exposition of "उद्देश्य का नक्शा" onto Freytag's first stage. Identify exactly which paragraphs constitute the exposition and justify why the exposition ends where it does.
STEPS:
- Step 1: Re-read the story's opening (first 3-4 paragraphs). List every detail about setting (time, place, atmosphere), character (station master's appearance, habits, reputation), and initial situation (his routine, philosophy).
- Step 2: Identify the "inciting incident" — the event that disrupts the status quo. Here, it is the arrival of the railway inspector's advance notice / the inspector's actual arrival.
- Step 3: Mark the boundary: exposition ends at the last sentence describing the "normal world" before the inspector's influence enters. In this story, it ends when the station master learns of the inspection.
- Step 4: Verify: Does this section *only* introduce, or does it also complicate? Confirm no conflict escalation occurs here.
- Step 5: Write a structured answer: "Exposition spans paragraphs 1-3. It establishes [specific details]. It ends at paragraph 4 when [inciting incident] occurs, shifting to rising action."
REASONING: This method forces the student to distinguish "introductory material" from "conflict initiation" — a critical analytical skill for board exams where "identify the exposition" requires textual precision.
ANSWER: The exposition comprises the initial description of the sleepy station, the station master's principled character, his daily routine, and his philosophical outlook on duty. It ends precisely when the news of the railway inspector's impending arrival disrupts this equilibrium — marking the transition to rising action.

## WORKED_EXAMPLE_2
PROBLEM: Trace the rising action in "उद्देश्य का नक्शा" by identifying four escalating complications. For each, state the complication and explain how it narrows the station master's options.
STEPS:
- Step 1: Define rising action for this story: the phase where the inspector's demands create mounting pressure on the station master's principles.
- Step 2: Scan the text for inspector-station master interactions. Highlight four moments where the stakes increase.
- Step 3: First complication: Inspector's verbal demand for "cooperation" (bribe) — station master can still refuse verbally.
- Step 4: Second complication: Inspector threatens formal report/transfer — station master's job security is now at risk.
- Step 5: Third complication: Station master's wife pleads for compromise — domestic pressure adds emotional weight.
- Step 6: Fourth complication: Inspector gives final ultimatum with deadline — time runs out, forcing the climax decision.
- Step 7: Synthesize: Each step reduces the station master's maneuvering room from "professional disagreement" to "existential choice".
REASONING: Rising action is not just "more events" but *progressive narrowing of protagonist's agency*. This step-by-step mapping teaches the causal chain logic examiners expect in "explain how tension builds" questions.
ANSWER: The rising action escalates through: (1) Inspector's implicit bribe demand — moral test; (2) Explicit threat of transfer/disciplinary action — career threat; (3) Wife's emotional appeal — personal/domestic pressure; (4) Final ultimatum with deadline — forces the irreversible resignation decision at climax.

## WORKED_EXAMPLE_3
PROBLEM: Analyze how the narrative structure (linear chronology, third-person omniscient narrator) shapes the reader's experience of the climax in "उद्देश्य का नक्शा". Contrast with how a first-person flashback structure would change the effect.
STEPS:
- Step 1: Identify the narrative structure elements: story moves forward in real time (linear); narrator knows thoughts of both station master and inspector (omniscient).
- Step 2: Analyze the climax scene (resignation submission). Note how linear structure builds *anticipation* — we experience each hour of the deadline day.
- Step 3: Note how omniscient narrator shows *both* the station master's calm resolve ("उनके मन में एक अजीब-सी शांति थी") AND the inspector's surprise ("अफसर अवाक् रह गया") — creating dramatic irony and moral clarity.
- Step 4: Imagine a first-person flashback: station master narrating years later ("I remember that day..."). This would add nostalgia, self-justification, and distance — reducing immediate tension.
- Step 5: Imagine inspector's first-person: would center bureaucratic logic, making station master seem rigid/foolish.
- Step 6: Conclude: Premchand's choices maximize *objective moral weight* — the structure itself argues for the station master's righteousness by showing both inner states without filter.
REASONING: This connects structural choices to thematic effect — a high-order skill for "analyze the author's craft" questions. It moves beyond *what* happens to *how the telling shapes meaning*.
ANSWER: The linear chronology creates real-time suspense; the omniscient narrator grants equal access to both characters' interiority at the climax, validating the station master's dignity while exposing the inspector's hollow authority. A first-person retrospective would introduce subjectivity and temporal distance, weakening the climax's ethical immediacy and universalizing force.

## COMPETENCY_QUESTION_1
QUESTION: "In 'उद्देश्य का नक्शा', the climax is often misidentified as the inspector's angry outburst. Using the definition of climax as 'the point of irreversible change for the protagonist', prove with two textual evidences that the true climax is the station master's decision to resign."
COMPETENCY: Analytical reasoning with textual evidence
STEPS:
- Step 1: State the definition of climax used (turning point of no return for protagonist).
- Step 2: Identify the inspector's outburst — explain why it is *not* irreversible for the station master (he could still comply).
- Step 3: Identify the resignation moment — quote/describe the exact action (writing/submitting letter).
- Step 4: Provide Evidence 1: The station master's internal monologue showing finality ("अब कोई समझौता नहीं").
- Step 5: Provide Evidence 2: The narrative consequence — after this, events accelerate toward departure (falling action).
- Step 6: Conclude: Only the resignation meets the structural definition.
ANSWER: The climax is the station master writing and submitting his resignation. Evidence 1: The text states "उन्होंने त्यागपत्र लिख डाला... उनके मन में एक अजीब-सी शांति थी" — the word "शांति" (peace) signals resolved internal conflict, the hallmark of a true turning point. Evidence 2: Immediately after, the narrative shifts to consequences (inspector's reaction, packing, departure) — the structural hallmark of falling action. The inspector's anger is merely a complication; the station master could still have withdrawn. The resignation is the point of no return.
DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: "Premchand uses a linear chronological structure in 'उद्देश्य का नक्शा'. Argue whether a non-linear structure (e.g., starting with the station master walking away, then flashing back) would strengthen or weaken the story's critique of colonial bureaucracy. Support with three structural reasons."
COMPETENCY: Evaluative argumentation on narrative craft
STEPS:
- Step 1: Define the current structure's effect: linear chronology creates inevitability — we see the system grind the individual down in real time.
- Step 2: Reason 1: Linear structure mirrors bureaucratic time — procedural, relentless, inescapable. Flashbacks would introduce subjective memory, softening the system's mechanical cruelty.
- Step 3: Reason 2: Current structure withholds the station master's philosophical clarity until the climax — his principles are *tested* then *proven*. A flashback opening with his departure would frame him as a victim, not a moral agent.
- Step 4: Reason 3: Omniscient linear narration allows the inspector's perspective to be shown *contemporaneously*, exposing the system's internal logic. A retrospective frame would filter everything through one character's hindsight, losing the systemic critique.
- Step 5: Conclude: Linear structure is essential to the story's political argument — it makes bureaucracy a character, not just a backdrop.
ANSWER: A non-linear structure would weaken the critique. (1) Linear chronology replicates the bureaucratic machine's forward momentum — no escape, no reordering — making the station master's resistance feel like swimming against a current. Flashbacks imply agency over narrative time, contradicting the theme of systemic entrapment. (2) The current structure forces the reader to *experience* the pressure buildup day-by-day; a flashback opening resolves tension prematurely. (3) The omniscient linear view exposes the inspector's calculations *as they happen*, revealing bureaucracy's banality. A single perspective (even the station master's) would personalize what Premchand intends as structural indictment.
DIFFICULTY: hard