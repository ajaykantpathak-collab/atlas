## DEFINITION
Plot and narrative structure in poetry refers to the deliberate organization of images, ideas, and emotions through stanzas, refrains, and shifts in perspective to create a coherent progression that leads the reader from an initial observation or statement to a thematic resolution. Unlike prose fiction, poetic narrative structure often relies on associative leaps, recurring motifs, and the accumulation of metaphorical layers rather than a linear sequence of events.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student can independently map the stanza‑by‑stanza progression of both poems, identify the structural role of the refrain in "नहीं वोश्यक" and the observation‑reflection arc in "मैंने देखा, एक चुनाव", and explain how each structure serves the poem’s central concern with identity and impermanence.

## SCOPE_BOUNDARY
This node covers only the analysis of narrative structure (stanza organization, refrain function, progression of metaphors, observation‑to‑reflection movement) in the two prescribed poems by Viren Dangwal. It does not include detailed thematic interpretation, exhaustive literary‑device identification, vocabulary, or grammar exercises — those are handled in sibling nodes.

## WALKTHROUGH
Imagine you hear a song where the chorus returns after every verse, but each verse adds a new detail that changes how you understand the chorus. That is exactly what Viren Dangwal does in "नहीं वोश्यक". Start by reading the poem aloud and marking each stanza. Notice the repeating line — that is your anchor. Then list the metaphors introduced in each stanza (xhr, eksrh, vf}rh;, etc.) and ask: what new facet of the "नहीं" does each metaphor reveal? For "मैंने देखा, एक चुनाव", there is no refrain; instead, the poem moves from a concrete visual moment (a twig changing colour in sunlight) to a philosophical generalization about change. Trace that movement line by line. The key insight is that structure is not a container — it is the argument itself.

## DIAGNOSTIC_QUESTION_1
What is the exact refrain line in "नहीं वोश्यक" and how many times does it appear in the poem?

## DIAGNOSTIC_ANSWER_1
The refrain is "ये नहीं वोश्यक लुसग हक खोज हक एनेरक] ij bldks Hkh iafDr dks ns nks" and it appears at the end of each of the four stanzas. A wrong answer (e.g., quoting only part of the line or miscounting stanzas) shows the student has not physically marked the poem’s stanzas and is relying on memory rather than textual evidence — a habit that loses marks in board exams where exact quoting is required.

## DIAGNOSTIC_QUESTION_2
In your own words, explain why the poet repeats the refrain "ij bldks Hkh iafDr dks ns nks" after every metaphor. What would be lost if the refrain appeared only once at the end?

## DIAGNOSTIC_ANSWER_2
The refrain acts as a recursive invitation: each new metaphor (star, beloved, eternal, flame, new, spark) is presented as another facet of the same elusive "नहीं", and the refrain forces the reader to re‑evaluate the entire poem’s subject in light of that new facet. If it appeared only once, the poem would read as a simple list; the repetition creates a cumulative, almost ritualistic insistence that the "नहीं" cannot be pinned down. A wrong answer that treats the refrain as mere decoration or musical effect misses the structural logic that each return of the refrain re‑contextualizes all previous metaphors — a classic competitive‑exam trap where students confuse form with ornament.

## DIAGNOSTIC_QUESTION_3
Apply the concept of "narrative progression" to "मैंने देखा, एक चुनाव". Identify the exact line where the poem shifts from description to reflection, and explain how that shift structures the poem’s meaning.

## DIAGNOSTIC_ANSWER_3
The shift occurs at "eq> dks nh[k x;k%" (I showed it to you / I realized). Before this line, the poem describes the visual phenomenon: a twig catching colour from the setting sun. After this line, the poet generalizes: "lwus fojkV~ osQ lEeq[k gj vkyksd&Nqvk viukiu gS mUekspu u'ojrk osQ nkx ls!" (From the very heart of the great forest, the colour flies away like a bird, vanishing from the claw of novelty). The structure is observation → epiphany → universal statement. A wrong answer that picks a later line (e.g., the last line) reveals the student cannot distinguish between the moment of perception and the moment of articulation — a skill directly tested in CBSE’s inferential questions.

## DIAGNOSTIC_QUESTION_4
Compare the narrative structures of the two poems. One uses a catalogue of metaphors framed by a refrain; the other uses a single observed moment that expands into a generalization. How does each structure serve its respective theme?

## DIAGNOSTIC_ANSWER_4
"नहीं वोश्यक" explores the multiplicity and elusiveness of identity — the refrain‑catalogue structure enacts the very impossibility of fixing the "नहीं" in a single definition. "मैंने देखा, एक चुनाव" explores the fleeting nature of beauty/change — the observation‑reflection structure mirrors the instantaneous loss of colour, making the reader experience the same sudden vanishing. A wrong answer that merely lists structural features (refrain vs. no refrain) without linking to theme shows superficial analysis; board exams demand the "how" and "why" of structural choices.

## DIAGNOSTIC_QUESTION_5
Which poem’s narrative structure do you find more effective in conveying its central idea? Defend your choice with specific structural evidence from both poems.

## DIAGNOSTIC_ANSWER_5
Both are effective but for different reasons. "नहीं वोश्यक"’s refrain creates a hypnotic, almost incantatory insistence that perfectly embodies the theme of an identity that refuses to be named — the structure *is* the argument. "मैंने देखा, एक चुनाव"’s sudden shift from image to abstraction mimics the very transience it describes, making the reader feel the loss. A defensible evaluation must cite: (a) the refrain’s recursive re‑framing in poem 1, and (b) the pivotal line "eq> dks nh[k x;k%" as a structural hinge in poem 2. A wrong answer that chooses based on personal preference ("I like the second poem because it’s shorter") without structural evidence fails the competency of evidence‑based literary judgment.

## DIAGNOSTIC_QUESTION_6
Write a four‑stanza poem (4 lines each) about a simple object (a key, a leaf, a stone) that uses a refrain at the end of each stanza to reveal a new metaphorical layer of that object, mimicking the structure of "नहीं वोश्यक".

## DIAGNOSTIC_ANSWER_6
A successful response will: (1) choose a concrete object, (2) craft a refrain that invites re‑interpretation (e.g., "This key opens more than doors"), (3) ensure each stanza introduces a distinct metaphor (a key as a secret, as a memory, as a choice, as a burden), and (4) end each stanza with the exact same refrain. A poor response either varies the refrain wording, uses the same metaphor repeatedly, or writes free verse without stanza breaks — indicating the student has not internalized the structural template.

## COMMON_MISCONCEPTION
Students often equate "plot" in poetry with a story involving characters and events. They therefore say "नहीं वोश्यक has no plot" and miss its narrative structure of accumulating metaphors. Similarly, they treat the refrain as a decorative repetition rather than a structural device that re‑contextualizes each preceding stanza. This error stems from applying prose‑narrative expectations to lyric poetry and from not physically annotating the poem’s stanzas and refrain.

## ON_FAILURE
1. Have the student read "नहीं वोश्यक" aloud twice, clapping on the refrain each time to hear its recurrence. 2. Give a printed copy; ask them to draw a box around every refrain and number the stanzas. 3. In the margin, write the metaphor of each stanza (xhr, eksrh, etc.). 4. Ask: "After stanza 2, what does the refrain mean? After stanza 3, how has the meaning shifted?" 5. Repeat with "मैंने देखा, एक चुनाव": highlight the observational lines in one colour, the reflective lines in another, and draw an arrow at the pivot line. This concrete annotation routine builds the habit of structural mapping required for both board and competitive answers.

## BUILDS_ON
Class 11 understanding of stanza, refrain, and metaphor as structural elements in poetry (c11_hin_ar_cbse_01_002, c11_hin_v_cbse_01_002).

## LEADS_TO
Theme analysis (c12_hin_a_cbse_03_006, c12_hin_a_cbse_03_007) and literary‑device analysis (c12_hin_a_cbse_03_008, c12_hin_a_cbse_03_009) where structural insights become evidence for thematic and stylistic arguments.

## PREREQUISITE_NODE_IDS
c12_hin_a_cbse_03_001, c11_hin_ar_cbse_01_002, c11_hin_v_cbse_01_002, c11_hin_ar_cbse_02_002, c11_hin_v_cbse_02_002
## PREREQUISITE_REASONS
c12_hin_a_cbse_03_001: Provides biographical and historical context for Viren Dangwal, essential for understanding the poet’s voice.
c11_hin_ar_cbse_01_002: Introduces basic concepts of poetic narrative structure (stanza, refrain, progression) in Class 11 Antra.
c11_hin_v_cbse_01_002: Reinforces the same concepts in the Vitan textbook, ensuring exposure to multiple texts.
c11_hin_ar_cbse_02_002: Offers a second poem‑based example of narrative structure in Class 11.
c11_hin_v_cbse_02_002: Further practice with structural analysis in a different Class 11 chapter.

## FORWARD_NODE_IDS
c12_hin_a_cbse_03_003, c12_hin_a_cbse_03_004, c12_hin_a_cbse_03_006, c12_hin_a_cbse_03_008, c12_hin_a_cbse_03_005, c12_hin_a_cbse_03_010, c12_hin_a_cbse_03_012, c12_hin_a_cbse_03_014, c12_hin_a_cbse_03_015

## FORWARD_REASONS
c12_hin_a_cbse_03_003: Setting and atmosphere analysis requires understanding how the poem’s structure creates its mood.
c12_hin_a_cbse_03_004: The speaker/persona in these poems functions as a protagonist; structural choices reveal the speaker’s consciousness.
c12_hin_a_cbse_03_006: Primary theme cannot be argued without structural evidence (e.g., the refrain’s insistence on multiplicity).
c12_hin_a_cbse_03_008: Imagery and metaphor are the building blocks of the narrative structure analysed here.
c12_hin_a_cbse_03_005: Plot and Narrative Structure established the poem's stanzaic progression, which this node uses to sequence the roles.  
c12_hin_a_cbse_03_010: Establishes narrative structure of the poems so students can locate where key words appear.  
c12_hin_a_cbse_03_012: Narrative structure helps locate literal details in sequence  
c12_hin_a_cbse_03_014: Narrative structure of poems (stanza division, refrain) informs structural analysis.  
c12_hin_a_cbse_03_015: अगला तार्किक चरण: Speaking and Listening: इस नोड की अवधारणाओं को सीधे उपयोग/विस्तारित करता है।  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
N/A

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_01_002 -> c12_hin_a_cbse_03_002 -> c12_hin_a_cbse_03_003

## THIS_FORMULA
N/A - conceptual

## FORMULA_VARIABLES
N/A

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
analytical

## CROSS_SUBJECT
N/A | The poem "नहीं वोश्यक" explores the tension between individual identity and societal labelling, linking to Civics concepts of individual rights, social conformity, and the politics of naming.
 N/A | The poem "मैंने देखा, एक चुनाव" reflects on fleeting choice and irreversible change, connecting to Economics concepts of decision‑making under scarcity, opportunity cost, and the transience of value.
## PREREQ_CONCEPT
Ability to identify stanzas, refrain, and metaphor in a poem (Class 11 level).

## PREREQ_BEFORE
Student must be able to mark stanzas and refrain on a printed poem and list the metaphors in sequence.

## PREREQ_STUCK
If stuck, revisit Class 11 node c11_hin_ar_cbse_01_002 (Plot and Narrative Structure) and practice stanza‑by‑stanza annotation on any short lyric poem.

## WORKED_EXAMPLE_1
PROBLEM: Analyse the narrative structure of "नहीं वोश्यक" and explain how the refrain organises the poem’s exploration of identity.
STEPS:
- Step 1: Read the poem aloud twice. On the second reading, number the stanzas (1–4) and underline the identical refrain at the end of each.
- Step 2: Identify the central subject — the "नहीं" — and note that it is never defined directly.
- Step 3: For each stanza, write the metaphor introduced (Stanza 1: xhr / star; Stanza 2: eksrh / beloved; Stanza 3: vf}rh; / eternal, eèkq / flame; Stanza 4: xksjl / new, vaoqQj / spark).
- Step 4: Explain how each metaphor adds a layer: star → distant beauty; beloved → intimate love; eternal flame → timelessness; new spark → fleeting novelty. The refrain after each forces the reader to hold all layers simultaneously.
- Step 5: Conclude that the catalogue‑with‑refrain structure enacts the poem’s thesis: identity is a multiplicity that resists final naming.
REASONING: The refrain is not mere repetition; it is a structural hinge that recursively re‑frames the accumulating metaphors. This step‑by‑step mapping mirrors the CBSE marking scheme’s expectation of "identify → illustrate → explain → evaluate".
ANSWER: The poem uses a four‑stanza catalogue structure unified by a refrain. Each stanza offers a new metaphor for the elusive "नहीं", and the refrain’s return compels a re‑reading of all previous metaphors, creating a layered portrait of identity that cannot be reduced to a single definition.

## WORKED_EXAMPLE_2
PROBLEM: Trace the observation‑to‑reflection narrative arc in "मैंने देखा, एक चुनाव" and show how the line break at "eq> dks nh[k x;k%" functions as a structural pivot.
STEPS:
- Step 1: Divide the poem into two sections: lines 1–4 (observation) and lines 5–8 (reflection). Mark the pivot line "eq> dks nh[k x;k%".
- Step 2: List the concrete sensory details in the first section: "लकड़ के >कx ls", "जैक्स ब्ज़ {क.कहज", "<यर्स ल्वजत ध वकस लस" (twig, colour change, heat of setting sun).
- Step 3: Identify the abstract generalization in the second section: "ल्वुस फोजक्व~ ओसक लएेक[क ग्ज व्कयक्सद-न्कवक वियुकिउ गस मउएक्सपु उ'ओजरक ओसक नक्स लस!" (colour flies from the forest’s heart like a bird, vanishing from novelty’s claw).
- Step 4: Explain the pivot: the poet moves from "I saw" to "I showed/realized", turning a private visual moment into a universal statement about impermanence.
- Step 5: Evaluate the effect: the structure makes the reader witness the exact instant perception becomes insight, mirroring the sudden loss of colour.
REASONING: The poem’s power lies in its minimal two‑part structure; the pivot line is the only explicit first‑person verb of cognition, making it the structural fulcrum. This analysis demonstrates the "Point–Evidence–Explanation–Link" answer format required in board exams.
ANSWER: The poem progresses from a concrete visual observation of a twig catching the sunset’s colour to a philosophical reflection on transience. The line "eq> dks nh[k x;k%" acts as the structural hinge, converting perception into generalization and enacting the theme of fleeting beauty.

## WORKED_EXAMPLE_3
PROBLEM: Compare the narrative structures of "नहीं वोश्यक" and "मैंने देखा, एक चुनाव" and argue which structure more effectively serves its poem’s central concern.
STEPS:
- Step 1: Create a two‑column table. Column A: "नहीं वोश्यक" — structure = refrain‑framed catalogue of 4 metaphors. Column B: "मैंने देखा, एक चुनाव" — structure = bipartite observation → reflection.
- Step 2: Identify each poem’s central concern: Poem A = multiplicity/elusiveness of identity; Poem B = impermanence of beauty/change.
- Step 3: Map structure to concern: Poem A’s recurring refrain forces the reader to hold multiple, contradictory metaphors simultaneously — the structure *performs* elusiveness. Poem B’s single pivot enacts the suddenness of loss — the structure *performs* impermanence.
- Step 4: Note the difference in reader experience: Poem A builds cumulatively (each stanza adds); Poem B shifts abruptly (before/after pivot).
- Step 5: Judge effectiveness: Both are perfectly matched; Poem A’s structure is more complex (requires holding 4 layers), Poem B’s is more dramatic (single turn). For board exams, a balanced answer acknowledging both is safest.
- Step 6: Synthesize: "Each poem’s structure is the embodiment of its theme; neither is superior — they are structural solutions to different poetic problems."
REASONING: Comparative structural analysis is a high‑order skill tested in CBSE’s long‑answer questions and in CUET/IPMAT critical‑thinking passages. The table method ensures systematic coverage.
ANSWER: "नहीं वोश्यक" uses a refrain‑catalogue to enact identity’s multiplicity; "मैंने देखा, एक चुनाव" uses an observation‑reflection binary to enact impermanence. Both structures are uniquely effective because each formal choice directly performs the poem’s central idea.

## COMPETENCY_QUESTION_1
QUESTION: How does the refrain in "नहीं वोश्यक" transform the poem from a simple descriptive list into a layered exploration of identity? Use the terms "recursive re‑framing" and "cumulative metaphor" in your answer.
COMPETENCY: Literary analysis – structural reasoning
STEPS:
- Step 1: Define "recursive re‑framing" in this context: each return of the refrain forces a re‑reading of all prior metaphors.
- Step 2: Define "cumulative metaphor": each stanza adds a new metaphor without discarding the previous ones.
- Step 3: Show how the first metaphor (xhr/star) is re‑framed when the second (eksrh/beloved) appears, and so on.
- Step 4: Conclude that the refrain is the mechanism that binds the cumulative metaphors into a single, unresolved portrait.
ANSWER: The refrain acts as a recursive frame: every time it returns, the reader must integrate the new metaphor (star, beloved, eternal flame, new spark) with all earlier ones, creating a cumulative portrait of identity that remains deliberately open‑ended. Without the refrain, the metaphors would sit side‑by‑side; with it, they dialogue across stanzas.
DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: The poem "मैंने देखा, एक चुनाव" uses a single visual image to trigger a philosophical reflection. Analyse how the narrative structure (observation → pivot → generalization) mirrors the poem’s theme of fleeting beauty. Write your answer in the PEEL format (Point, Evidence, Explanation, Link).
COMPETENCY: Critical thinking – structure‑theme synthesis
STEPS:
- Step 1 (Point): State that the poem’s two‑part structure enacts the sudden loss it describes.
- Step 2 (Evidence): Quote the observational imagery (twig, sunset heat, colour change) and the pivot line "eq> dks nh[k x;k%".
- Step 3 (Explanation): Explain how the pivot converts a sensory moment into an abstract truth, and how the final image of colour flying "like a bird from the forest’s heart" mirrors the twig’s loss.
- Step 4 (Link): Connect back to the theme: the structure *is* the vanishing — the poem itself loses its concrete grounding and becomes abstraction.
- Step 5: Polish into a coherent paragraph using PEEL.
ANSWER: Point: The poem’s bipartite structure mirrors the fleeting nature of beauty. Evidence: The first four lines present a concrete scene — "लकड़ के >कx ls जैक्स ब्ज़ {क.कहज <यर्स ल्वजत ध वकस लस" — while the pivot "eq> डकस नह[क क्स;क%" shifts to generalization: "ल्वुस फोजक्व~ ओसक लएेक[क ग्ज व्कयक्सद-न्कवक वियुकिउ गस मउएक्सपु उ'ओजरक ओसक नक्स लस!" Explanation: The sudden structural turn from observation to reflection enacts the instantaneous loss of colour; the poem’s own form moves from solid image to vanishing metaphor. Link: Thus, the narrative structure does not merely describe transience — it performs it.
DIFFICULTY: hard