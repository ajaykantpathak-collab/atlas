## DEFINITION
Critical Thinking: Analysis and Interpretation is the higher-order cognitive process of deconstructing a literary text to examine its underlying structures, evaluating the author's choices (language, structure, perspective), and synthesizing evidence to form reasoned judgments about the text's meaning, purpose, and socio-cultural implications.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student can independently select relevant textual evidence from multiple sections of the chapter, explain how literary devices and narrative choices shape meaning, evaluate competing interpretations of the text's central conflict (water scarcity vs. traditional knowledge), and articulate a coherent analytical argument in structured board-exam format.

## SCOPE_BOUNDARY
This node covers analytical frameworks for interpreting the chapter's critique of modernization, the symbolism of the potter's craft, and the socio-ecological commentary on water crisis. It does NOT cover basic comprehension, vocabulary, or grammatical analysis (covered in nodes 010-012), nor does it teach creative writing or speaking skills (nodes 014-015).

## WALKTHROUGH
Imagine you're at a family gathering in Rajasthan during peak summer, and the water tanker arrives two hours late—everyone rushes with buckets, arguments break out, and your grandmother mutters, "In our time, the earthen pot kept water cool all day without electricity." That lived experience is exactly what this chapter forces you to analyze: the clash between modern water dependency and indigenous wisdom. Begin by identifying the central tension—scarcity versus sustainability—then trace how the author uses the potter's labor (pages 9-18) as a metaphor for disappearing ecological knowledge. Notice the shift from descriptive narration (pot-making process) to analytical commentary (soil types, water conservation). The key insight: this isn't just a documentary about pots; it's an argument about what development costs.

## DIAGNOSTIC_QUESTION_1
Define 'critical analysis' in the context of Hindi literary prose and distinguish it from 'summary' or 'comprehension' using one specific example from the chapter's description of the three soil types (इक्यजिकुह, इकरक्यिकुह, जस्तक.खिकुह).

## DIAGNOSTIC_ANSWER_1
Critical analysis examines *how* and *why* the author presents the three soil types as a classification system reflecting ecological wisdom—e.g., noting that जस्तक.खिकुह (alluvial soil) is positioned as the synthesis of the other two, mirroring the chapter's argument for integrating traditional and modern knowledge. A summary would merely list the three types and their properties. A wrong answer that just defines the soils reveals the student confuses content recall with analytical reasoning.

## DIAGNOSTIC_QUESTION_2
The author describes the potter's work as "एक विशेष प्रकार की फपुकबज" (a special kind of artistry) on page 14. Explain in your own words why this phrase functions as an interpretive claim rather than a factual observation, and what it reveals about the author's perspective on labor.

## DIAGNOSTIC_ANSWER_2
The phrase is interpretive because "विशेष प्रकार की" imposes a value judgment—elevating manual labor to artistry—that isn't empirically verifiable like "the pot is made of clay." It reveals the author's perspective that traditional craft embodies intellectual and aesthetic depth erased by industrial modernity. A wrong answer treating it as factual description shows the student cannot distinguish authorial stance from textual data.

## DIAGNOSTIC_QUESTION_3
Apply the concept of 'irony' (from node 009) to analyze the passage on pages 16-17 where the author notes that potters now receive "वषक हकज" (annual salary) and "फोकग जैसे ऐक्सी" (facilities like leave) but the craft itself is dying. Identify the specific irony and explain its function in the chapter's argument.

## DIAGNOSTIC_ANSWER_3
The irony is situational: state recognition (salary, leave) arrives precisely when the craft's ecological relevance is collapsing due to groundwater depletion and plastic containers. This irony functions to critique tokenistic preservation—formal employment without ecological sustainability is hollow. A wrong answer identifying only "sadness" or "change" misses the structural contradiction the author constructs.

## DIAGNOSTIC_QUESTION_4
Compare the narrative treatment of the potter's craft in the first half (pages 9-13: process, soil, technique) with the second half (pages 14-19: economics, social status, ecological crisis). Analyze how this structural shift transforms the text from ethnography to argument.

## DIAGNOSTIC_ANSWER_4
The first half uses thick description (soil ratios, firing stages, seasonal rhythms) to establish the craft's epistemological sophistication—knowledge embedded in practice. The second half shifts to causal analysis (market forces, water table decline, policy failure) to show that knowledge's fragility. The structural pivot enacts the argument: you cannot understand the crisis without first respecting the knowledge being lost. A wrong answer describing only "more details then opinions" misses the rhetorical strategy.

## DIAGNOSTIC_QUESTION_5
Evaluate the author's claim on page 19 that "फुथ गकसर गक, हक लकेओजतफुद {ककककक पर ओककककबज पर ककककककक कककककककक" (Even while decaying, rural society's imprint remains on urban pots). Defend or challenge this claim using evidence from the text's treatment of the जककककककककककक (water crisis) and the potter's changing role.

## DIAGNOSTIC_ANSWER_5
The claim is partially defensible: the pot's form (cooling efficiency, material) still carries rural ecological logic, but its social meaning has fractured—urban buyers value aesthetics, not water security. The text supports this tension: page 18 notes pots now need "रकककक" (polish) for city markets, while page 19 admits "कककककककककककककककककक" (social acceptance comes only after persistent effort). A strong evaluation acknowledges both continuity and rupture. A wrong answer giving only "yes" or "no" fails the evaluative demand.

## DIAGNOSTIC_QUESTION_6
Create an analytical paragraph (80-100 words) interpreting the symbol of the "िककककक" (the crow) in the chapter's title "जककककककककक ककककककक" using the chapter's central themes of thirst, knowledge, and survival. Your paragraph must include a topic sentence, two pieces of textual evidence, and a concluding insight.

## DIAGNOSTIC_ANSWER_6
The crow symbolizes the desperate search for sustainable knowledge in a desiccated polity. Like the crows pecking at dry riverbeds (p.9: "कककककककककककककक"), modern society scavenges fragmented solutions—borewells, tankers, plastic—while ignoring the potter's integrated water wisdom (p.17: "ककककककककककककककककककक"). The crow's thirst is not merely biological; it is civilizational. A poor answer describes the literal bird or writes a summary, revealing inability to construct symbolic interpretation from textual evidence.

## COMMON_MISCONCEPTION
Students equate "critical thinking" with "finding faults" or "giving opinions," leading them to write subjective reactions ("I feel the author is nostalgic") instead of evidence-based analysis ("The author structures the potter's declining income alongside rising water scarcity to argue that economic marginalization and ecological collapse are co-produced"). This error stems from school-level "critical appreciation" exercises that rewarded personal response over textual argumentation.

## ON_FAILURE
1. Show the student two paragraphs on the same topic: one opinion-based ("The author seems sad about pots dying"), one analytical ("The author juxtaposes the potter's 5-day firing cycle with the tanker's 2-hour delivery to contrast temporalities of trust"). 2. Ask them to label each sentence as "claim," "evidence," or "warrant." 3. Have them rewrite the opinion paragraph by inserting textual evidence after every claim. 4. Practice this template on three chapter passages until the structure becomes automatic.

## BUILDS_ON
The student's ability to identify literary devices (nodes 008-009) and trace themes (nodes 006-007) across the text.

## LEADS_TO
Structured analytical writing for board exams (node 014) and evidence-based discussion (node 015).

## PREREQUISITE_NODE_IDS
c11_hin_v_cbse_02_002, c11_hin_v_cbse_02_003, c11_hin_v_cbse_02_006, c11_hin_v_cbse_02_007, c11_hin_v_cbse_02_008, c11_hin_v_cbse_02_009, c11_hin_v_cbse_02_012, c11_hin_v_cbse_02_004, c11_hin_v_cbse_02_005, c11_hin_v_cbse_02_010, c11_hin_v_cbse_02_011

## PREREQUISITE_REASONS
c11_hin_v_cbse_02_002: Plot structure provides the narrative framework for analytical claims about pacing and emphasis.
c11_hin_v_cbse_02_003: Setting analysis (water-scarce landscape) is the ecological substrate of the chapter's argument.
c11_hin_v_cbse_02_006: Primary theme (tradition vs. modernity) is the interpretive lens for all critical analysis.
c11_hin_v_cbse_02_007: Secondary themes (labor dignity, knowledge systems) provide sub-arguments to synthesize.
c11_hin_v_cbse_02_008: Imagery and metaphor are the textual evidence for analytical claims.
c11_hin_v_cbse_02_009: Irony and symbolism are the key rhetorical strategies requiring interpretation.
c11_hin_v_cbse_02_012: Inferential comprehension is the baseline skill for moving to analysis.
c11_hin_v_cbse_02_004: Critical thinking about the protagonist's reliability and perspective is required for deeper interpretation.  
c11_hin_v_cbse_02_005: Critical thinking requires evaluating *whose knowledge counts*—this node supplies the character-based evidence base.  
c11_hin_v_cbse_02_010: Vocabulary in Context refers to the skill of determining the precise meaning of key terms... की समझ आवश्यक है, क्योंकि यह नोड (Critical Thinking:) इसी आधार पर आगे बढ़ता है।  
c11_hin_v_cbse_02_011: Critical interpretation of authorial stance relies on analysing syntactic and lexical patterns established here.  

## FORWARD_NODE_IDS
c11_hin_v_cbse_02_014, c11_hin_v_cbse_02_015, c12_hin_a_cbse_17_013, c12_hin_al_cbse_02_013, c12_hin_v_cbse_02_013

## FORWARD_REASONS
c11_hin_v_cbse_02_014: Analytical frameworks developed here directly structure the argumentative writing tasks in the writing skills node.
c11_hin_v_cbse_02_015: Interpretive claims tested here become the speaking points for structured discussion in the listening/speaking node.
c12_hin_a_cbse_17_013: Further practice in interpreting cultural/philosophical references.  
c12_hin_al_cbse_02_013: Vitan Chapter 2 — practice with testimonio/memoir hybrid.  
c12_hin_v_cbse_02_013: Another Vitan chapter's critical thinking model — demonstrates transfer across texts.  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
none

## CHAIN_DESCRIPTION
c11_hin_v_cbse_02_006 -> c11_hin_v_cbse_02_013 -> c11_hin_v_cbse_02_014

## THIS_FORMULA
Analytical Paragraph Structure: [Topic Sentence: Interpretive Claim] + [Evidence 1: Textual Detail with Page/Line Reference] + [Warrant 1: Explanation of How Evidence Supports Claim] + [Evidence 2: Contrasting/Complementary Detail] + [Warrant 2: Synthesis] + [Concluding Insight: Connection to Broader Theme]

## FORMULA_VARIABLES
Topic Sentence: A debatable interpretive statement about the text's meaning or strategy. Evidence: Specific textual detail (quoted or paraphrased with location). Warrant: The reasoning linking evidence to claim. Concluding Insight: The claim's significance for the chapter's central argument.

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
analytical

## CROSS_SUBJECT
c11_geography_water_scarcity | The chapter's analysis of groundwater depletion, traditional water harvesting (earthen pots as passive cooling), and soil-water relationships directly parallels Class 11 Geography's "Water Resources" chapter—both examine how indigenous knowledge systems manage scarcity versus state-led extraction regimes.
c11_economics_informal_sector | The potter's transition from autonomous craftsperson to wage laborer with "annual salary" but vanishing craft mirrors the Economics textbook's analysis of informal sector displacement—both texts use a specific community to illustrate structural economic transformation.

## PREREQ_CONCEPT
The ability to distinguish between what a text *says* (content) and what a text *does* (rhetorical strategy, ideological positioning).

## PREREQ_BEFORE
Student must have completed close reading of the full chapter and be able to locate specific passages (soil classification, firing process, economic shift, water crisis commentary) without re-reading the entire text.

## PREREQ_STUCK
If stuck, return to node 006 (Primary Theme) and node 009 (Irony/Symbolism)—these two nodes provide the interpretive vocabulary and thematic anchor for all analytical work in this chapter.

## WORKED_EXAMPLE_1
PROBLEM: Analyze how the author uses the technical description of pot-firing stages (pages 14-15: पहली फुंकाई, दूसरी फुंकाई, तीसरी फुंकाई) to make an argument about the fragility of traditional knowledge systems.
STEPS:
- Step 1: Identify the claim to be analyzed—the firing process description is not merely technical documentation but a rhetorical device demonstrating knowledge complexity.
- Step 2: Locate the three firing stages in the text: पहली फुंकाई (initial firing with cow-dung cakes), दूसरी फुंकाई (second firing with wood), तीसरी फुंकाई (final firing with specific temperature control), noting the precise material and temporal conditions for each.
- Step 3: Analyze the language: the author uses passive construction ("फुंकाई की जाती है") for the process but shifts to active risk ("जरा सी चूक से सारा श्रम व्यर्थ") to emphasize human judgment over mechanical reproducibility.
- Step 4: Connect to the broader argument: this irreducible tacit knowledge—embodied, contextual, non-codifiable—is what modernization erases when it replaces pots with plastic tanks.
- Step 5: Synthesize: the technical description functions as an epistemological proof—traditional craft is not "unscientific" but differently scientific, and its loss is an intellectual impoverishment.
REASONING: This analysis moves from textual micro-detail (firing stages) to macro-argument (knowledge systems) by treating technical description as evidence of epistemic sophistication, not just process documentation.
ANSWER: The three firing stages—each requiring specific fuel, temperature judgment, and timing—constitute a knowledge system where expertise resides in the potter's embodied perception (smoke color, flame sound, ash texture), not in written manuals. The author's shift from passive process description to active risk language ("जरा सी चूक") rhetorically enacts the argument: this knowledge cannot be standardized, only apprenticed. When the market demands "पॉलिश" (polish) over function (page 18), it demands the erasure of this epistemic depth.

## WORKED_EXAMPLE_2
PROBLEM: The chapter presents two contrasting water economies: the earthen pot economy (pages 9-13) and the tanker/borewell economy (pages 16-19). Analyze how the author structures this contrast to critique "development."
STEPS:
- Step 1: Map the two economies' defining features from the text. Earthen pot economy: decentralized, soil-dependent, seasonal rhythm, potter-community knowledge, zero energy cost, biodegradable. Tanker economy: centralized, electricity-dependent, on-demand, state-mediated, high energy cost, plastic waste.
- Step 2: Identify the structural device—the author interleaves them. Pages 9-13 establish the pot economy's internal logic; pages 16-19 intrude the tanker economy as disruption (water table drop, salinity, potter's redundancy).
- Step 3: Analyze the pivotal transition on page 16: "अब कच्ची मिट्टी के बर्तन कम बनते हैं" (Now raw clay pots are made less)—the passive voice obscures agency, mimicking how displacement happens without visible decision.
- Step 4: Evaluate the critique: the author does not romanticize the past (notes potters' poverty, caste marginalization) but shows the replacement system creates new vulnerabilities (tanker mafia, salinity, total dependency).
- Step 5: Formulate the analytical claim: the contrast is not nostalgia but a systems analysis—development replaces a resilient, distributed water culture with a fragile, centralized one.
REASONING: This worked example demonstrates comparative structural analysis—reading the text's organization as an argumentative move, not just information delivery.
ANSWER: The author constructs a dialectical contrast: the pot economy's resilience lies in its distribution (every household, every season, local soil) while the tanker economy's fragility lies in its centralization (single pipeline, electricity grid, distant aquifer). The structural interleaving—pot-making knowledge detailed before its disruption—is rhetorical: you must understand what is lost before recognizing the inadequacy of the replacement. The critique targets not modernity per se but the epistemic arrogance that dismisses distributed knowledge as "backward."

## WORKED_EXAMPLE_3
PROBLEM: Synthesize the chapter's treatment of caste (implied in "कुंभकार" community, "पुश्तैनी धंधा"), ecology (soil types, water table), and state policy (salary, leave, recognition) to evaluate whether the author presents the potter's crisis as primarily cultural, ecological, or political.
STEPS:
- Step 1: Extract all textual references to caste/community: "पुश्तैनी धंधा" (hereditary occupation, p.14), "कुंभकार" (potter caste), "विशेष जाति" (special caste, p.16), "अनुसूचित जाति के अंतर्गत" (under scheduled caste, p.16).
- Step 2: Extract ecological references: three soil types (p.13), water table decline (p.17: "पानी का स्तर नीचे"), salinity (p.17: "खारा पानी"), seasonal rhythm disruption.
- Step 3: Extract policy references: "वाषिक वेतन" (annual salary), "छुट्टी जैसी सुविधाएं" (leave facilities), "पुरस्कार" (awards), "प्रदर्शनी" (exhibitions)—all on pages 16-17.
- Step 4: Analyze intersections: caste determines who holds the knowledge; ecology determines its viability; policy recognizes the person but not the system. The salary comes when the clay runs out.
- Step 5: Evaluate the author's weighting: the text spends 10 pages on ecology/technique, 3 on economics/policy, 1 on caste—suggesting ecology is the primary lens, but the final page (19) reframes it politically: "समाज अपनी लाज रखता है" (society saves face) only after persistent struggle.
- Step 6: Synthesize: the crisis is presented as *politico-ecological*—caste is the historical condition, ecology the material limit, policy the inadequate response. The author refuses a single-axis explanation.
REASONING: This example models multi-axis synthesis—required for board exam "evaluate" questions—showing how to weigh textual emphasis across themes without reductionism.
ANSWER: The author presents the crisis as politico-ecological with caste as the historical substrate. Evidence: 70% of the text details soil-water-craft ecology; policy interventions appear only as late, reactive gestures (salary after redundancy); caste is the unspoken backdrop of "hereditary" knowledge. The concluding irony—state recognition arrives when the craft is ecologically unviable—makes the political critique explicit: the state preserves the *symbol* (potter as awardee) while enabling the *conditions* (groundwater mining) that destroy the practice.

## COMPETENCY_QUESTION_1
QUESTION: The chapter ends with the image of urban households keeping pots as "सजावट" (decoration) while villages lose the water table that made pots necessary. Using the analytical framework of "symbolic displacement," write a 120-word argument explaining how this final image encapsulates the chapter's critique of urban consumption of rural ecology.
COMPETENCY: Interpretive Argumentation with Textual Synthesis
STEPS:
- Step 1: Define "symbolic displacement" in this context—the object (pot) is displaced from its material function (water cooling) to a symbolic function (aesthetic/rural nostalgia) in a different social site (urban home).
- Step 2: Locate the textual evidence: page 19 "शहरी घरों में मटके सजावट बन गए," page 17 "पानी का स्तर नीचे," page 18 "पॉलिश किए मटके बिकते हैं."
- Step 3: Structure the argument: (a) the pot's material logic (evaporative cooling) requires groundwater; (b) urban extraction lowers that groundwater; (c) the pot survives only as decontextualized sign; (d) this is the chapter's central irony.
- Step 4: Draft with analytical paragraph structure: topic sentence, evidence 1 + warrant, evidence 2 + warrant, concluding insight.
ANSWER: The urban decorative pot is a tombstone for rural water security. The chapter establishes the pot's material logic: evaporative cooling requires porous clay fired at specific temperatures (pp.14-15) and—crucially—groundwater within reach of village wells (p.17). Urban water demand (tankers, borewells) lowers that same water table, making village pottery ecologically impossible. Yet the pot reappears in cities as "पॉलिश किया हुआ सजावट" (p.18)—stripped of function, retaining only the sign of "tradition." This symbolic displacement is the chapter's damning verdict: urban India consumes rural ecology twice—first as water, then as aesthetic. The pot on the city shelf is not survival; it is evidence of what was extracted.
DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: A board exam question asks: "The author calls the potter's knowledge 'अनकहा विज्ञान' (unspoken science). Analyze this claim by comparing the text's treatment of the three soil types (इक्यजिकुह, इकरक्यिकुह, जस्तक.खिकुह) with modern soil science classification. What does the comparison reveal about the politics of knowledge in the chapter?"
COMPETENCY: Cross-epistemic Analysis and Critical Evaluation
STEPS:
- Step 2: Map the chapter's soil taxonomy: इक्यजिकुह (black cotton clay, high plasticity, water-retentive), इकरक्यिकुह (red lateritic, sandy, permeable), जस्तक.खिकुह (alluvial, balanced, synthesized by river action). Note the classification criteria: color, texture, water behavior, firing outcome.
- Step 3: Contrast with modern soil science (USDA/WRB): classification by horizonation, parent material, climate, organic matter—laboratory-measurable, universalizable, text-based.
- Step 4: Analyze the political implication: the potter's taxonomy is *functional* (what works for pots here), the scientific taxonomy is *taxonomic* (what fits a global schema). The chapter values the former because it encodes watershed-specific hydrology.
- Step 5: Evaluate the claim "अनकहा विज्ञान": it is not "unscientific" but *differently epistemic*—oral, embodied, context-bound. The politics: development discourse recognizes only the latter, rendering the former invisible until it fails.
- Step 6: Synthesize in exam format: claim, evidence from text, cross-epistemic comparison, political conclusion.
ANSWER: The phrase "अनकहा विज्ञान" names a knowledge system that is scientific in method (observation, classification, predictive testing—e.g., "जस्तक.खिकुह इकरक्यिकुह से बेहतर पकती है") but oral in transmission and functional in validation. Modern soil science classifies by horizons and chemistry; the potter classifies by *behavior in fire and water*. The chapter shows this functional taxonomy encodes micro-watershed hydrology: इक्यजिकुह holds water (good for storage), इकरक्यिकुह drains (good for firing), जस्तक.खिकुह balances both (river's gift). When the state recognizes the potter with "वेतन" but ignores the soil knowledge, it performs epistemic extraction—taking the labor, leaving the science. The politics of knowledge here is: only codified, transferable knowledge counts as "science"; situated, embodied knowledge becomes "craft"—and thus disposable.
DIFFICULTY: hard