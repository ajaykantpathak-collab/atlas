## DEFINITION
Writing Skills based on the chapter refers to the ability to compose structured, evidence-based responses to questions about the poem "?kj dh ;kn" by Hkokuh izlkn feJ, using the PEEL (Point, Evidence, Explanation, Link) framework to analyze themes, literary devices, character portrayals, and emotional undertones.

## COGNITIVE_LEVEL
apply

## MASTERY_CRITERIA
The student can independently write a 150-200 word answer to a poem-based question that states a clear point, quotes or paraphrases specific lines as evidence, explains the significance of that evidence, and links it back to the central idea of longing for home and generational disconnect.

## SCOPE_BOUNDARY
This node covers writing analytical answers for exam questions on "?kj dh ;kn" (e.g., theme, imagery, father's character, irony). It does NOT cover creative writing (composing original poems), speaking/listening tasks, or grammar exercises unrelated to textual analysis.

## WALKTHROUGH
Imagine you sit in the exam hall and see the question: "How does the poet convey the pain of separation from home in '?kj dh ;kn'?" Your mind goes blank. Where do you begin? Start by recalling the poem's core conflict: the speaker is physically distant but emotionally tethered. Next, hunt for two concrete images — the "four walls, four doors" repetition and the father's silent endurance. Then, structure each paragraph using PEEL: make a Point about repetition showing entrapment, give Evidence from the stanza describing the house's structure, Explain how the counting of walls/doors mirrors obsessive memory, and Link to the theme of inescapable longing. The key insight is that examiners reward answers that move beyond "the poet feels sad" to "the poet uses structural repetition in stanza X to mirror the cyclical nature of memory."

## DIAGNOSTIC_QUESTION_1
What does the acronym PEEL stand for in the context of writing literature answers?

## DIAGNOSTIC_ANSWER_1
PEEL stands for Point, Evidence, Explanation, Link. A wrong answer (e.g., "Paragraph, Example, Explain, Language") reveals the student has memorised a mnemonic without understanding its functional components — they cannot map each letter to a specific writing action, so their answers will lack structural discipline.

## DIAGNOSTIC_QUESTION_2
A student writes: "The poet misses his home a lot. He repeats 'four walls, four doors' to show this." Why is this answer insufficient for a Class 11 board exam?

## DIAGNOSTIC_ANSWER_2
The answer states a valid observation but lacks Evidence (no line reference), Explanation (no analysis of *why* repetition conveys pain), and Link (no connection to broader themes like generational disconnect). A wrong diagnosis (e.g., "it's too short") shows the student confuses length with analytical depth — they need to learn that a three-sentence PEEL paragraph scores higher than a page of narration.

## DIAGNOSTIC_QUESTION_3
Apply the PEEL structure to answer: "What does the father's silence represent in the poem?" Use the father's description in the later stanzas.

## DIAGNOSTIC_ANSWER_3
Point: The father's silence embodies stoic endurance of displacement. Evidence: The lines describing him as having "not a single flaw" yet carrying "burdens that still walk today" (stanza referencing father's unspoken struggles). Explanation: The poet contrasts the father's outward calm with the weight of unvoiced history — his silence is not absence but a language of survival. Link: This mirrors the speaker's own inability to articulate grief, showing how displacement silences generations. A wrong answer that only quotes "father had no flaw" without explaining the irony reveals the student treats evidence as decoration, not argument.

## DIAGNOSTIC_QUESTION_4
Compare two student responses to "Analyse the use of irony in the poem." Response A: "It is ironic that the poet calls the house 'not a home'." Response B: "The irony lies in the house being physically intact ('four walls, four doors') while the emotional anchor is broken — the speaker carries the house inside but cannot return." Which response demonstrates higher-order analysis and why?

## DIAGNOSTIC_ANSWER_4
Response B demonstrates analysis because it identifies a structural contradiction (physical permanence vs emotional rupture) and links it to the central paradox of memory. Response A merely labels a surface-level contradiction without exploring how the poet *constructs* irony through juxtaposition. A student who chooses A confuses identification with analysis — they need practice breaking down *how* a device operates across stanzas.

## DIAGNOSTIC_QUESTION_5
Evaluate this claim: "The poem's free verse form weakens its emotional impact because it lacks rhythmic discipline." Defend or refute using evidence from the poem's structure.

## DIAGNOSTIC_ANSWER_5
Refute. The free verse mirrors the fragmentation of memory — irregular line lengths (e.g., the abrupt short line "vkneh ls Hkkxrk gw¡" amidst longer lines) enact the sudden stab of grief. The repetition of "gk; js] ,slk u dguk" creates its own incantatory rhythm without metre. A student who agrees with the claim imposes a rigid definition of "poetic form" and fails to see how form *serves* content in modern Hindi poetry — a senior-secondary misconception rooted in Class 10's focus on rhyme schemes.

## DIAGNOSTIC_QUESTION_6
Create a new exam-style question on "?kj dh ;kn" that requires the examinee to connect the mother's portrayal to the theme of unacknowledged labour. Provide a model PEEL outline for the answer.

## DIAGNOSTIC_ANSWER_6
Question: "How does the poet use the mother's domestic actions to highlight the invisibility of women's emotional labour in displacement?" Model Outline: Point: The mother's routine chores become rituals of holding the family together. Evidence: References to "ewB mudh feyk ysdj" (serving food) and "nq%[k MV dj Bsyrk" (churning butter) in the middle stanzas. Explanation: These acts are framed as eternal ("gk; js] ikuh fxj jgk gS") — her labour sustains the *idea* of home even when the physical home is lost. Link: This elevates the mother from a background figure to the architect of emotional survival, paralleling the father's silent endurance but through active nurture. A weak question would ask "Describe the mother" — testing recall, not synthesis.

## COMMON_MISCONCEPTION
Students believe "writing skills" means using flowery vocabulary and long sentences. In "?kj dh ;kn" answers, they write: "The poet's heart wrenches with poignant agony as he reminisces about his ancestral abode." This earns low marks because it replaces textual evidence with emotional adjectives. The board marking scheme awards points for *specific references to lines/devices* and *analytical connections*, not expressive language. Students make this error because school assessments till Class 10 often rewarded "good expression" over "textual proof."

## ON_FAILURE
1. Show the student a side-by-side comparison: a 2/5 answer (flowery, no quotes) vs a 5/5 answer (plain language, two line references, PEEL structure). 2. Give them a highlighter and ask: "Mark every claim in the 5/5 answer that is backed by a line from the poem." 3. Have them rewrite the 2/5 answer by inserting two concrete references from the poem (e.g., "the line 'pkj HkkbZ pkj cfgusa'") and adding one Explanation sentence per reference. 4. Repeat with a new question until they self-correct.

## BUILDS_ON
c11_hin_ar_cbse_11_013 (Critical Thinking: Analysis and Interpretation) — students must first interpret the poem before writing about it.

## LEADS_TO
c11_hin_ar_cbse_11_015 (Speaking and Listening: Discussion Points) — written analysis forms the script for oral presentation.

## PREREQUISITE_NODE_IDS
c11_hin_ar_cbse_11_001, c11_hin_ar_cbse_11_002, c11_hin_ar_cbse_11_003, c11_hin_ar_cbse_11_004, c11_hin_ar_cbse_11_005, c11_hin_ar_cbse_11_006, c11_hin_ar_cbse_11_007, c11_hin_ar_cbse_11_008, c11_hin_ar_cbse_11_009, c11_hin_ar_cbse_11_010, c11_hin_ar_cbse_11_011, c11_hin_ar_cbse_11_012, c11_hin_ar_cbse_11_013

## PREREQUISITE_REASONS
c11_hin_ar_cbse_11_001: Context/background knowledge needed to frame historically grounded answers.
c11_hin_ar_cbse_11_002: Plot/narrative structure understanding helps sequence evidence logically.
c11_hin_ar_cbse_11_003: Setting/atmosphere analysis provides evidence for mood-based questions.
c11_hin_ar_cbse_11_004: Protagonist analysis supplies character-based evidence.
c11_hin_ar_cbse_11_005: Supporting character analysis (father, mother) provides evidence for relationship questions.
c11_hin_ar_cbse_11_006: Primary theme identification anchors the "Link" step in PEEL.
c11_hin_ar_cbse_11_007: Secondary themes allow nuanced answers for multi-theme questions.
c11_hin_ar_cbse_11_008: Imagery/metaphor knowledge supplies device-based evidence.
c11_hin_ar_cbse_11_009: Irony/symbolism knowledge enables higher-order analysis answers.
c11_hin_ar_cbse_11_010: Vocabulary precision ensures accurate quoting/paraphrasing.
c11_hin_ar_cbse_11_011: Grammar usage helps write error-free analytical sentences.
c11_hin_ar_cbse_11_012: Comprehension practice builds literal/inferential evidence retrieval.
c11_hin_ar_cbse_11_013: Critical thinking develops the "Explanation" and "Link" steps.

## FORWARD_NODE_IDS
c12_hin_a_cbse_05_014, c12_hin_a_cbse_11_014, c12_hin_ar_cbse_11_014

## FORWARD_REASONS
c12_hin_a_cbse_05_014: अगला तार्किक चरण: Writing Skills based on the chapter refers to the ability to compose structured, evidence-based resp... इस नोड की अवधारणाओं को सीधे उपयोग/विस्तारित करता है।  
c12_hin_a_cbse_11_014: Class 11 writing skills foundation — PEEL was introduced there; this node advances it.  
c12_hin_ar_cbse_11_014: Class 11 writing skills introduced PEEL; this node deepens it with chapter-specific textual density.  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
none

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_11_013 -> c11_hin_ar_cbse_11_014 -> c11_hin_ar_cbse_11_015

## THIS_FORMULA
PEEL = Point (1 sentence answering the question) + Evidence (1-2 specific line references/paraphrases) + Explanation (2-3 sentences analysing the evidence) + Link (1 sentence connecting to central theme/question)

## FORMULA_VARIABLES
Point = Direct answer to the question prompt; Evidence = Textual support from the poem (line description or key phrase); Explanation = Analysis of how evidence proves the point; Link = Connection to broader theme (longing, displacement, generational memory)

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
linguistic

## CROSS_SUBJECT
c11_history_partition_displacement | The poem's theme of forced migration and memory of lost home parallels Partition narratives in History (e.g., oral testimonies of refugees carrying "keys to houses they cannot return to").
c11_geography_migration_patterns | The speaker's physical distance vs emotional attachment illustrates geographers' concept of "place attachment" vs "space" — relevant to migration case studies.
c11_economics_livelihood_loss | The father's "burdens that still walk today" reflects intergenerational economic trauma of displaced communities losing land-based livelihoods.
c11_civics_identity_citizenship | The poem's tension between "house" (legal/physical entity) and "home" (emotional belonging) mirrors Civics debates on citizenship, domicile, and belonging.

## PREREQ_CONCEPT
Ability to retrieve and paraphrase specific textual details from the poem (covered in c11_hin_ar_cbse_11_012 Comprehension).

## PREREQ_BEFORE
Student can locate at least three key images in the poem (e.g., the house structure, father's silence, mother's chores) and state their literal meaning.

## PREREQ_STUCK
If stuck, review c11_hin_ar_cbse_11_012 (Comprehension) and c11_hin_ar_cbse_11_008 (Imagery and Metaphor) to rebuild evidence bank.

## WORKED_EXAMPLE_1
PROBLEM: Write a PEEL paragraph answering: "How does the repetition of 'four walls, four doors' contribute to the poem's theme?"
STEPS:
- Step 1: Identify the question's core demand — analyse a specific device (repetition) and its thematic function.
- Step 2: Recall the exact lines: the poem opens with "pkj HkkbZ pkj cfgusa" repeated in multiple stanzas, creating a chant-like structure.
- Step 3: Draft Point: The repetition transforms the house from a physical structure into an obsessive mental map.
- Step 4: Insert Evidence: The phrase appears in the opening stanza and returns in the middle section ("pkj HkkbZ pkj cfgusa / Hkqtk HkkbZ I;kj cfgusa") with slight variation (adding "Hkqtk" — strong/secure).
- Step 5: Write Explanation: The counting of walls/doors mimics a child's ritual to ward off fear; the variation "Hkqtk" (strong) contrasts with the speaker's current vulnerability, showing memory idealises what reality eroded.
- Step 6: Craft Link: This structural repetition mirrors the poem's central argument — home is not built of bricks but of recursive memory that both traps and sustains the displaced.
REASONING: Each step forces the student to move from device identification to thematic synthesis, which is the Class 11 board expectation. Skipping Step 5 (Explanation) produces a "device-spotting" answer that scores 1/3.
ANSWER: The repetition of "four walls, four doors" transforms the house from a physical structure into an obsessive mental map. In the opening stanza and again in the middle section ("pkj HkkbZ pkj cfgusa / Hkqtk HkkbZ I;kj cfgusa"), the poet chants the house's architecture like a protective mantra. The counting mimics a child's ritual to ward off fear, while the added word "Hkqtk" (strong/secure) ironically contrasts with the speaker's present helplessness — memory idealises what displacement has eroded. This structural repetition mirrors the poem's central argument: home is not built of bricks but of recursive memory that both traps and sustains the displaced.

## WORKED_EXAMPLE_2
PROBLEM: Improve this weak answer: "The poet is very sad because he cannot go back to his village. He remembers his father and mother. The poem is emotional."
STEPS:
- Step 1: Diagnose weaknesses — no specific references, no device analysis, vague emotion words ("sad", "emotional"), no thematic vocabulary.
- Step 2: Identify three upgrade targets: (a) replace "sad" with precise emotional state (longing/grief/displacement), (b) insert two concrete images (father's silence, mother's chores), (c) name one literary device (repetition/imagery/irony).
- Step 3: Retrieve evidence from prior nodes: father's "not a single flaw" (c11_hin_ar_cbse_11_004), mother's "churning butter" (c11_hin_ar_cbse_11_005), repetition of house structure (c11_hin_ar_cbse_11_008).
- Step 4: Rebuild using PEEL for each point. Paragraph 1: Point = Displacement creates generational silence. Evidence = Father's description. Explanation = Silence as survival language. Link = Speaker inherits this silence. Paragraph 2: Point = Domestic rituals anchor memory. Evidence = Mother's chores. Explanation = Labour as emotional architecture. Link = Home lives in repeated acts.
- Step 5: Polish transitions and ensure each paragraph ends with a thematic Link sentence.
REASONING: This models the revision process examiners expect — turning a narrative summary into an analytical argument by layering evidence and terminology from earlier chapter nodes.
ANSWER: Displacement in "?kj dh ;kn" manifests as a generational inheritance of silence. The father carries "burdens that still walk today" without a "single flaw" in his outward composure — his silence is not absence but a survival language forged by unspoken history. The speaker confesses "I cannot say what I want to say," revealing how displacement mutes emotional articulation across generations. Simultaneously, the mother's domestic rituals — "serving food," "churning butter" — become the invisible architecture of home. These acts, framed as eternal ("gk; js, ikuh fxj jgk gS"), sustain the *idea* of home when the physical structure is lost. Together, parental silence and maternal labour construct a home that exists not in "four walls, four doors" but in the recursive memory of those who cannot return.

## WORKED_EXAMPLE_3
PROBLEM: Answer a 6-mark question: "The poem uses the house as a symbol. Analyse how the symbol evolves across the poem." (Requires tracing symbol across 3+ stanzas.)
STEPS:
- Step 1: Deconstruct the question — "symbol evolves" demands chronological tracking, not static definition. "6 marks" = 3 developed PEEL points or 2 extended PEEL paragraphs.
- Step 2: Map the house symbol across stanzas using c11_hin_ar_cbse_11_003 (Setting) and c11_hin_ar_cbse_11_009 (Symbolism): Stanza 1 = physical house (countable walls/doors). Middle stanzas = internalised house (carried in memory, "vk¡[kksa esa rSj jgk gS"). Later stanzas = metaphorical house ("?kj ugha gw¡ cl ;gh gS" — not house but its shadow).
- Step 3: Draft Point 1: The house begins as a measurable, possessable object. Evidence: "pkj HkkbZ pkj cfgusa" — quantified, owned. Explanation: Quantification reflects a child's proprietary security.
- Step 4: Draft Point 2: The house becomes an internal, inescapable presence. Evidence: "vk¡[kksa esa rSj jgk gS" (lives in the eyes/mind). Explanation: Shift from external to internal shows displacement internalises space.
- Step 5: Draft Point 3: The house dissolves into "shadow" — a symbol of irretrievable loss. Evidence: "?kj ugha gw¡ cl ;gh gS" (not house but its shadow). Explanation: "Shadow" implies form without substance, presence without access — the ultimate displacement metaphor.
- Step 6: Synthesise Link: The symbol's trajectory (object -> memory -> shadow) charts the speaker's journey from belonging to alienation, making the house the poem's central organising metaphor.
REASONING: Senior-secondary questions often require tracing a motif's evolution — this worked example models the "zoom out" from stanza-level evidence to whole-poem architecture.
ANSWER: The house in "?kj dh ;kn" evolves from a quantifiable shelter to an internalised obsession and finally to an irretrievable shadow. Initially, the poet counts "four walls, four doors" — the house is a measurable, owned object reflecting a child's proprietary security. As displacement deepens, the house migrates inward: "it lives in the eyes" (vk¡[kksa esa rSj jgk gS), no longer a structure but a persistent mental image that the speaker cannot evict. In the concluding realization, the house dissolves: "it is not the house, it is its shadow" (?kj ugha gw¡ cl ;gh gS). The metaphor of "shadow" captures form without substance — the outline of belonging remains, but the substance of return is gone. This three-stage evolution (object → memory → shadow) maps the speaker's trajectory from rootedness to alienation, making the house the poem's central organising symbol.

## COMPETENCY_QUESTION_1
QUESTION: A Class 11 student writes this answer to "Explain the significance of the mother's chores in the poem": "The mother works very hard. She cooks and churns butter. This shows she loves her family. Without her the house would fall apart." The teacher returns it with "Needs textual evidence and analytical vocabulary." Rewrite the answer using PEEL, incorporating at least two specific references from the poem and the term "emotional labour."
COMPETENCY: Analytical writing with textual evidence and subject-specific terminology
STEPS:
- Step 1: Identify the two concrete references available: "ewB mudh feyk ysdj" (serving food) and "nq%[k MV dj Bsyrk" (churning butter) from the middle stanzas.
- Step 2: Formulate Point: The mother's domestic acts constitute unacknowledged emotional labour that sustains the family's sense of home.
- Step 3: Insert Evidence: The poem lists her routine — "serving food," "churning butter" — framed as perpetual ("gk; js, ikuh fxj jgk gS").
- Step 4: Write Explanation: These chores are not mere maintenance; they ritualise care, converting raw displacement into daily survivable rhythm. The term "emotional labour" names this invisible work of holding affect together.
- Step 5: Craft Link: While the father's silence endures, the mother's active nurture builds the emotional architecture the speaker carries into exile.
ANSWER: The mother's domestic acts constitute unacknowledged emotional labour that sustains the family's sense of home. The poem details her routine — "serving food" (ewB mudh feyk ysdj) and "churning butter" (nq%[k MV dj Bsyrk) — presented as eternal fixtures ("gk; js, ikuh fxj jgk gS"). These chores are not mere maintenance; they ritualise care, converting the raw trauma of displacement into a daily survivable rhythm. The term "emotional labour" precisely names this invisible work of holding the family's affective world together. While the father's silence embodies stoic endurance, the mother's active nurture constructs the emotional architecture the speaker carries into exile — home lives not in walls but in her repeated, uncelebrated acts.
DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: "The poem's central irony is that the speaker carries the house within but cannot inhabit it." Write a 150-word analytical response that: (a) defines the irony using the poem's own vocabulary, (b) traces its development across three stanzas, (c) connects it to the title "?kj dh ;kn" (Memory of Home), and (d) uses the phrase "structural paradox" at least once.
COMPETENCY: Synthesising irony analysis with structural awareness and title significance
STEPS:
- Step 1: Define the irony using poem's vocabulary: "?kj ugha gw¡ cl ;gh gS" (not house but its shadow) — the structural paradox of presence-in-absence.
- Step 2: Trace across three stanzas: Stanza 1 (physical house counted), Middle stanzas (house internalised in memory/eyes), Final stanza (house reduced to shadow).
- Step 3: Connect to title: ";kn" (memory) is the only space where the house exists — the title names the irony.
- Step 4: Embed "structural paradox" in the analysis of how the poem's form (repetition → dissolution) enacts the content.
- Step 5: Ensure each paragraph ends with a Link to the title's significance.
REASONING: This question tests the highest board competency — integrating device analysis, structural tracking, title interpretation, and prescribed terminology in a single coherent argument.
ANSWER: The poem's central irony is a structural paradox: the speaker possesses the house completely in memory ("vk¡[kksa esa rSj jgk gS") yet cannot inhabit it physically. This paradox unfolds in three movements. First, the house appears as a countable, owned object — "four walls, four doors" — quantifiable security. Second, displacement internalises it: the house becomes an inescapable mental presence, living in the speaker's gaze, sustained by parental labour (father's silent endurance, mother's churning rituals). Third, the final stanza strips even this internal house to its essence: "?kj ugha gw¡ cl ;gh gS" — not the house but its shadow. The title ";kn" (memory) names this irony: memory is the *only* domicile available. The poem's form enacts this paradox — repetitive counting mimics obsessive possession, while the concluding dissolution into "shadow" mirrors the structure's collapse. Thus, the structural paradox of "having without holding" becomes the poem's definition of displacement.
DIFFICULTY: hard