## DEFINITION
Character analysis of supporting characters involves examining how secondary figures in a literary work function to develop the protagonist, advance the plot, embody themes, and create a believable fictional world through their distinct traits, motivations, relationships, and narrative purpose.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student can identify at least three supporting characters from "viw osQ lkFk <kbZ lky", explain their specific narrative functions with textual evidence, and analyze how each character's presence deepens the portrayal of the playwright-protagonist or illuminates the story's central concerns about art, sacrifice, and community.

## SCOPE_BOUNDARY
This node covers analysis of supporting characters in "viw osQ lkFk <kbZ lky" (the narrator-child, mother, sister, actors Hkwyks and Jhfuokl, the old woman, landlord, neighbors). It does not cover the protagonist (iFksj ikapkyh, covered in node 004) or thematic synthesis (nodes 006, 007).

## WALKTHROUGH
Imagine you're directing a play: the lead actor cannot create a world alone — every supporting role, from the worried mother in the wings to the devoted old woman in the front row, builds the reality the protagonist inhabits. In "viw osQ lkFk <kbZ lky", begin by listing every character who is not the playwright. For each, ask: What do they do? What do they say? How do they react to the playwright's struggle? What would be lost if they were removed? Group them by sphere: family (mother, siblings), theater troupe (actors, director), community (landlord, neighbors, old woman). The key insight: supporting characters are not background decoration; they are the ecosystem that makes the protagonist's artistic battle visible, tangible, and meaningful.

## DIAGNOSTIC_QUESTION_1
Identify three supporting characters from "viw osQ lkFk <kbZ lky" and state one specific textual action each performs that directly impacts the playwright's journey.

## DIAGNOSTIC_ANSWER_1
Correct answer: (1) Mother (loZt;k) — manages household chaos during rehearsals and silently endures financial anxiety, grounding the playwright's art in domestic sacrifice. (2) First Hkwyks oqQÙkk — rehearses the lead role with talent ("gels Bhd crkZo djus yxkA") but abandons the production for better pay, triggering a crisis. (3) Veteran actor Jhfuokl — embodies the old man (feBkbZokys) with professional dedication until his death halts rehearsals and forces a hollow replacement. A wrong answer lists the playwright himself, gives vague actions like "they help," or ignores textual specifics, revealing confusion between protagonist/supporting roles or inability to link character action to narrative consequence.

## DIAGNOSTIC_QUESTION_2
Explain in your own words how the narrator-child's dual perspective (participant and retrospective narrator) shapes our understanding of the mother's worry and the actors' dedication.

## DIAGNOSTIC_ANSWER_2
Correct answer: The child-narrator initially perceives rehearsals as play ("cPps baVjO;w osQ fy, vkrs Fks") and his mother's anxiety as mere scolding ("ck,¡ gkFk esa og Fkkyh"), but the adult narrator's hindsight frames these as sacrifice and professionalism. This gap creates dramatic irony: the reader sees the mother's fear for survival and the actors' precarious commitment more clearly than the child did. A wrong answer treats the narrator as purely a child or purely an adult, missing the irony that makes the supporting characters' struggles poignant rather than incidental.

## DIAGNOSTIC_QUESTION_3
Apply the concept of "foil" to compare the two actors who play Hkwyks. How does their contrast deepen the story's commentary on artistic integrity versus economic survival?

## DIAGNOSTIC_ANSWER_3
Correct answer: The first Hkwyks is talented but leaves for money ("vc D;k gksxk... og oqQÙkk vc bl nqfu;k esa ugha gSA"), exposing theater's commercial vulnerability. The replacement looks identical ("Hkwyks tSlk gh fn[krk Fkk") but lacks artistic spark, symbolizing how the market replaces substance with semblance. Together they illustrate that the playwright's battle is not just to stage a play but to preserve art's soul in a system that commodifies it. A wrong answer notes only physical similarity/difference without analyzing what the contrast reveals about the theme of artistic compromise.

## DIAGNOSTIC_QUESTION_4
Analyze how the old woman (pqUuhckyk nsoh) and the neighbors (lqcksèk nk) function as a collective "chorus" commenting on the playwright's work. What does their presence suggest about the relationship between art and audience?

## DIAGNOSTIC_ANSWER_4
Correct answer: The old woman's faithful attendance ("cgqr fnuksa rd gesa vyx&vyx leL;kvksa ls tw>uk iM+kA") and the neighbors' gossip ("fpYykrs... fI+kQYe okys vk, gSa") act as a Greek chorus: they witness, judge, and validate the artistic process. Their presence proves art cannot exist in isolation — it requires a community, however flawed, to complete its meaning. The old woman represents the ideal audience (patient, believing); the neighbors represent the curious public. A wrong answer treats them as mere background color or describes actions without interpreting their symbolic function as the social fabric that sustains or threatens art.

## DIAGNOSTIC_QUESTION_5
Evaluate the claim: "Jhfuokl's death is the structural and thematic climax of the supporting cast's arc, forcing the playwright to confront the mortality of his artistic lineage." Defend or challenge with evidence.

## DIAGNOSTIC_ANSWER_5
Correct answer (defend): Jhfuokl's death ("Jhfuokl dh Hkwfedk tks lTtu dj jgs Fks] mudk nsgkar gks x;k") disrupts rehearsals, erases the living link to theatrical tradition ("mudk psgjk igys okys Jhfuokl ls feyrk&tqyrk ugha Fkk"), and forces a rushed, inferior replacement — mirroring the playwright's fear that his art may die with him. The search for a successor becomes a metaphor for artistic legacy. A wrong answer gives a simple yes/no without using specific incidents (his professionalism, the replacement's hollowness, the playwright's reaction) to justify the evaluation, revealing an inability to synthesize character arc with structural and thematic analysis.

## DIAGNOSTIC_QUESTION_6
Create a 5-line character sketch of the landlord (ekfyd) that invents one plausible, text-consistent detail about his private reaction to the rehearsals, and explain how this detail would deepen his narrative function.

## DIAGNOSTIC_ANSWER_6
Expected answer: The landlord threatens eviction over noise ("mlosQ dkj.k ge mls ekj ugha losQA og ^okLrqliZ* Fkk") yet tolerates weeks of disruption, suggesting pragmatic acceptance beneath bureaucratic sternness. Invented detail: He secretly pauses at the window during a climactic scene, visibly moved, but hardens his face when noticed. This transforms him from antagonist into a reluctant participant in the art he claims to oppose, embodying society's contradictory relationship with culture — officially hostile, privately hungry. A poor answer makes him a cartoon villain or ignores his ambiguity, missing how his complexity reflects the story's nuanced view of art's social embeddedness.

## COMMON_MISCONCEPTION
Students treat supporting characters as "extras" who merely fill scenes: "The mother cooks and worries," "The actors just act," "The neighbors watch." This error stems from focusing on plot function (what they do) rather than narrative function (what they represent). For example, they miss that the old woman's daily presence *is* the play's first successful run — she embodies the ideal audience without which the playwright's labor has no purpose. They also confuse the narrator-child with the adult author, flattening the irony that lets us see supporting characters more clearly than the child narrator does.

## ON_FAILURE
If a student reduces supporting characters to plot devices, guide them through a "Character Purpose Map": (1) Pick one supporting character. (2) List three specific actions from the text. (3) For each action, ask: "What does this reveal about the playwright's struggle?" and "What theme does it highlight?" (4) Write one synthesis sentence: "This character exists to show ___." (5) Repeat for two more characters. This shifts focus from *action* to *significance* and builds the analytical habit of connecting character to theme.

## BUILDS_ON
This node builds on the protagonist analysis (c11_hin_ar_cbse_03_004) because supporting characters are defined by their relationship to the protagonist's goals and conflicts.

## LEADS_TO
This node enables theme analysis (c11_hin_ar_cbse_03_006, c11_hin_ar_cbse_03_007) because supporting characters often personify thematic ideas (sacrifice, community, tradition vs. modernity).

## PREREQUISITE_NODE_IDS
c11_hin_ar_cbse_03_001, c11_hin_ar_cbse_03_002, c11_hin_ar_cbse_03_004
## PREREQUISITE_REASONS
c11_hin_ar_cbse_03_001: Provides historical context of Indian theater and the playwright's real-life struggle, essential to understand the world supporting characters inhabit.
c11_hin_ar_cbse_03_002: Plot knowledge locates where each supporting character enters/exits and how their actions drive narrative turning points.
c11_hin_ar_cbse_03_004: Protagonist analysis establishes the central figure (playwright) against whom all supporting characters are defined.

## FORWARD_NODE_IDS
c11_hin_ar_cbse_03_006, c11_hin_ar_cbse_03_007, c11_hin_ar_cbse_03_013, c11_hin_ar_cbse_03_012, c11_hin_ar_cbse_03_015, c12_hin_a_cbse_12_005, c12_hin_al_cbse_01_005, c12_hin_al_cbse_03_005, c12_hin_ar_cbse_03_005, c12_hin_ar_cbse_06_005

## FORWARD_REASONS
c11_hin_ar_cbse_03_006: Supporting characters often embody the primary theme (artistic struggle vs. survival); their analysis feeds directly into theme identification.
c11_hin_ar_cbse_03_007: Secondary themes (family vs. vocation, tradition vs. commerce) are carried by specific supporting characters.
c11_hin_ar_cbse_03_013: Critical thinking requires synthesizing character analysis into broader interpretive arguments about the text's meaning.
c11_hin_ar_cbse_03_012: Supporting characters (dealer, son, actors) drive key inferential moments.  
c11_hin_ar_cbse_03_015: Supporting characters (director, actors, villagers) offer multiple viewpoints for debate.  
c12_hin_a_cbse_12_005: अगला तार्किक चरण: Supporting character analysis examines how secondary characters in a narrative — through their disti... इस नोड की अवधारणाओं को सीधे उपयोग/विस्तारित करता है।  
c12_hin_al_cbse_01_005: Deepens understanding of how supporting characters embody social themes in Hindi literature.  
c12_hin_al_cbse_03_005: Class 11 introduced foil/archetype terminology (प्रतिबिंब, प्रतीक) essential for Class 12 analytical depth.  
c12_hin_ar_cbse_03_005: Class 11 foundation on identifying flat/round, static/dynamic characters in poetry.  
c12_hin_ar_cbse_06_005: Class 11 foundation on supporting character analysis in Aroh.  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
none

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_03_004 -> c11_hin_ar_cbse_03_005 -> c11_hin_ar_cbse_03_006

## THIS_FORMULA
N/A - conceptual

## FORMULA_VARIABLES
N/A

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
analytical

## CROSS_SUBJECT
c11_history_nationalism: The theater troupe's struggle mirrors the broader cultural nationalist project of building indigenous artistic institutions under colonial rule.
c11_sociology_social_change: The troupe represents a microcosm of traditional art confronting market forces, illustrating the sociological tension between community-embedded and commodified cultural production.

## PREREQ_CONCEPT
Understanding the playwright-protagonist's central conflict (artistic vision vs. material survival) is essential because every supporting character is analyzed by how they illuminate, challenge, or embody that conflict.

## PREREQ_BEFORE
Student must have completed the protagonist analysis (node 004) and know the basic plot sequence (node 002) of "viw osQ lkFk <kbZ lky".

## PREREQ_STUCK
If stuck, review the playwright's character sketch (node 004) and the plot summary (node 002) to recall the specific crises where supporting characters become decisive.

## WORKED_EXAMPLE_1
PROBLEM: Analyze how the first Hkwyks oqQÙkk functions as a supporting character to develop the theme of artistic integrity versus economic survival.
STEPS:
- Step 1: Identify the character and his key textual actions: He is cast as the lead, rehearses with genuine talent ("gels Bhd crkZo djus yxkA"), but abruptly leaves the troupe when the playwright cannot match a better offer.
- Step 2: Determine his narrative relationship to the protagonist: He is the playwright's first concrete hope for a successful production; his departure is a direct blow to the play's viability.
- Step 3: Extract precise evidence: The text notes his physical suitability ("xnZu ij yxk ikmMj"), the playwright's dependence ("viw dh Hkwfedk osQ fy, eq>s ftl rjg dk yM+dk pkfg, Fkk"), and the sudden void ("vc D;k gksxk... og oqQÙkk vc bl nqfu;k esa ugha gSA").
- Step 4: Analyze thematic significance: His exit dramatizes the central tension — in a colonial capitalist economy, artistic commitment is a luxury few can afford. He becomes the living proof that talent is commodified.
- Step 5: Connect to the story's central idea: The playwright's struggle is not merely writing a play but holding together a collective enterprise in a system that does not value art for art's sake. This character makes that systemic issue personal, immediate, and devastating.
REASONING: This analysis follows the PEEL structure (Point, Evidence, Explanation, Link) moving from concrete textual detail to abstract thematic insight. It demonstrates how a supporting character's brief arc can crystallize the work's central concern.
ANSWER: The first Hkwyks oqQÙkk serves as the catalyst for the playwright's deepest crisis. His talent validates the play's artistic potential, but his departure for financial reasons exposes the harsh reality that artistic labor is subject to market forces. He embodies the story's core conflict: the vulnerability of art in a world that measures value in currency, not creativity.

## WORKED_EXAMPLE_2
PROBLEM: Compare the mother (loZt;k) and the old woman (pqUuhckyk nsoh) as supporting characters. How do their contrasting relationships to the playwright reveal the dual pressures of his existence?
STEPS:
- Step 1: Map the mother's textual portrayal: Domestic anchor ("loZt;k viw dks Hkkr f[kyk jgh gSA"), manager of household scarcity ("[kkus esa mldk iwjk è;ku ugha gSA"), silent bearer of rehearsal chaos ("ck,¡ gkFk esa og Fkkyh vkSj nkfgus gkFk esa fuokyk ysdj cPps osQ ihNs nkSM+rh gS").
- Step 2: Map the old woman's textual portrayal: Devoted audience ("cgqr fnuksa rd gesa vyx&vyx leL;kvksa ls tw>uk iM+kA"), validator of the art ("lkmaM Bhd gS u\*... ^gk¡*"), embodiment of faithful reception.
- Step 3: Contrast their bonds: The mother is bound by blood and duty — she endures the *cost* of his art. The old woman chooses to be there out of love for art — she affirms its *value*.
- Step 4: Analyze what each reveals about the playwright: The mother shows his failure as a provider; the old woman shows his success as a creator. Together they frame his life as suspended between private sacrifice and public vocation.
- Step 5: Synthesize: The playwright exists at the intersection of these two women — one who pays the price, one who witnesses the worth. Their contrast deepens his portrayal from "struggling artist" to "man torn between obligation and calling."
REASONING: Comparing two supporting characters across spheres (domestic/public) reveals how the author uses them to construct a multidimensional portrait of the protagonist. Each character illuminates a different facet of the protagonist's reality, and their juxtaposition creates thematic depth.
ANSWER: The mother and the old woman function as twin pillars of the playwright's world: the private sphere of familial sacrifice and the public sphere of artistic recognition. The mother's silent endurance underscores the personal cost of his passion (hunger, chaos, anxiety), while the old woman's faithful attendance affirms its social worth (validation, continuity, meaning). Their contrast reveals the playwright not just as a victim of circumstances but as a figure navigating the irreconcilable demands of father/husband and artist/culture-maker.

## WORKED_EXAMPLE_3
PROBLEM: The veteran actor Jhfuokl dies mid-production. Analyze how his character arc — from introduction to death to replacement — structures the narrative and deepens the theme of artistic legacy.
STEPS:
- Step 1: Trace Jhfuokl's introduction: An aging actor, once prominent ("igys okys Jhfuokl"), now playing a minor role (feBkbZokys) with professional rigor ("mudk psgjk igys okys Jhfuokl ls feyrk&tqyrk ugha Fkk").
- Step 2: Note his symbolic weight: He represents the living tradition of theater — craft, discipline, continuity ("feyrk&tqyrk nwljk vkneh dgk¡ ls feysxk").
- Step 3: Identify the crisis point: His death ("Jhfuokl dh Hkwfedk... mudk nsgkar gks x;k") halts rehearsals, creating a vacuum the playwright must fill urgently.
- Step 4: Analyze the replacement: The new actor lacks Jhfuokl's depth ("igys okys Jhfuokl tSls gh Fks... ysfdu 'kjhj ls os igys Jhfuokl tSls gh Fks"), proving that tradition cannot be instantly replicated.
- Step 5: Connect to the protagonist: The playwright loses not just an actor but a link to the artistic lineage he aspires to join. The frantic search for a successor mirrors his own anxiety: will his work outlive him?
- Step 6: Conclude thematic function: Jhfuokl's arc transforms him from supporting character into thematic device — the ghost of theater past warning that art survives only if someone carries it forward. His death marks the passing of an era and the fragility of oral/performative tradition.
REASONING: This example demonstrates how a supporting character's entire arc can be read as a structural and thematic element. It requires synthesizing plot points, character details, and symbolic interpretation — a key Class 11 analytical skill that moves beyond "what happens" to "what it means and how it's built."
ANSWER: Jhfuokl's character arc moves from living embodiment of theatrical tradition to its absent memory. His professionalism contrasts with the commercial instability surrounding the troupe. His death creates a narrative vacuum that the playwright must fill, symbolizing the burden of artistic succession. Thus, a minor character becomes the vehicle for the story's meditation on legacy, loss, and the precarious transmission of culture.

## COMPETENCY_QUESTION_1
QUESTION: In "viw osQ lkFk <kbZ lky," the landlord (ekfyd) threatens eviction but ultimately tolerates months of disruptive rehearsals. Using textual evidence, analyze how this ambiguity makes him a more effective supporting character than a purely villainous antagonist would be.
COMPETENCY: Literary Analysis - Character Complexity and Social Realism
STEPS:
- Step 1: Identify the landlord's textual actions: He complains about noise, threatens eviction ("mlosQ dkj.k ge mls ekj ugha losQA og ^okLrqliZ* Fkk"), yet takes no action for weeks.
- Step 2: Explain why pure villainy would weaken the story: A cartoonish antagonist would simplify the conflict into good artist vs. bad society, reducing the realism of the playwright's negotiated existence.
- Step 3: Analyze the ambiguity's function: His tolerance suggests hidden humanity, pragmatic calculation, or secret appreciation — reflecting how communities simultaneously resist and accommodate art. He is part of the social ecosystem, not an external enemy.
- Step 4: Connect to theme: This complexity mirrors the story's nuanced view that artistic survival depends on messy coexistence, not heroic victory. The landlord embodies the society that grumbles but makes space.
ANSWER: The landlord's ambiguity makes him a realistic social force rather than a plot device. His threats create genuine tension, but his inaction reveals the quiet complicity of a world that officially resists art yet privately depends on it. He represents the "okLrqliZ" — the unspoken rules that govern everyday life — and his failure to enforce them shows that even bureaucracy has a human margin. This supports the theme that art survives not by conquering society but by negotiating its contradictions.
DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: The narrator is both a character (the playwright's child) and the adult author reconstructing memory. Analyze how this dual perspective shapes the portrayal of TWO supporting characters, and explain why this narrative strategy deepens the reader's engagement with the supporting cast.
COMPETENCY: Narrative Perspective and Characterization
STEPS:
- Step 1: Establish the narrator's dual role: Participant-child during events ("cPps baVjO;w osQ fy, vkrs Fks") and retrospective author ("orZeku esa dksydkrk iFksj ikapkyh fI+kQYe dk ,d n`';").
- Step 2: Analyze effect on mother's portrayal: Child sees irritation ("ck,¡ gkFk esa og Fkkyh"); adult narrator reveals the fear beneath ("loZt;k viw dks Hkkr f[kyk jgh gSA"). The gap creates dramatic irony — we understand her sacrifice before the child did.
- Step 3: Analyze effect on actors' portrayal: Child sees play ("jsyxkM+h ns[krs gSa"); adult narrator reveals professional desperation (first Hkwyks leaving, Jhfuokl's rigor). The reader must "read past" the child's naivety to grasp the actors' stakes.
- Step 4: Synthesize narrative purpose: The perspective gap forces the reader into active interpretation — we become co-creators of the supporting characters' depth. This mirrors the playwright's own struggle to be understood: just as he needs an audience that sees beyond surface, the text needs a reader who reads beyond the child's eyes.
ANSWER: The child-narrator's limited perspective acts as a filter: supporting characters initially appear through a naive lens (mother as scolder, actors as playmates, landlord as ogre), but the adult narrator's retrospective voice gradually corrects this, revealing their depth, dignity, and desperation. This technique engages the reader in an act of empathy — we must do the interpretive work the child could not. It turns reading into a rehearsal of the very attentiveness the old woman models: patient, faithful, seeing what the surface hides. The supporting characters thus become not just figures in a memory but figures in a moral education — ours.
DIFFICULTY: hard