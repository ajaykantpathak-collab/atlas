## DEFINITION
Imagery is the use of vivid, sensory language that appeals to the five senses (sight, sound, smell, touch, taste) to create mental pictures and evoke emotions. Metaphor is a figure of speech that directly compares two unrelated things by stating one *is* the other, transferring qualities from the source domain to the target domain without using "like" or "as". In Class 12, we analyze how these devices work together to build theme, tone, and the poet's worldview.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student can independently identify specific images and metaphors in an unseen poem, explain their sensory appeal and comparative logic, and write a structured analytical paragraph (Point-Evidence-Explanation-Link) showing how they develop the central idea — all within the time constraints of a board exam.

## SCOPE_BOUNDARY
This node covers identification, classification, and analytical writing on imagery (visual, auditory, tactile, olfactory, gustatory, kinesthetic) and metaphor (simple, extended, mixed, dead) **only within the prescribed poem "cukjl" and similar NCERT poems**. It does NOT cover other figures of speech (simile, personification, symbolism, irony) — those are in node c12_hin_a_cbse_04_009.

## WALKTHROUGH
Imagine you are reading a WhatsApp forward describing a monsoon evening in your ancestral village: the smell of wet earth, the sound of rain on tin roofs, the feel of mud squelching underfoot. That message uses **imagery** to make you *experience* the scene. Now, if the sender writes, "The village is a sleeping child wrapped in a gray blanket," that is a **metaphor** — it reshapes your understanding by fusing two unlike things. In this node, you will learn to (1) read the poem aloud to catch sound-images, (2) underline every sensory word and label its sense, (3) spot every "A is B" statement and name the two domains, (4) ask "Why this image? Why this metaphor here?" and (5) write a PEEL paragraph that links the device to the poem's theme of rootedness and change. The key insight: imagery *shows*; metaphor *reveals* — and together they make the abstract tangible.

## DIAGNOSTIC_QUESTION_1
Define "imagery" and "metaphor" in your own words, giving one example of each from everyday language (not from the textbook).

## DIAGNOSTIC_ANSWER_1
Imagery: Language that appeals to the senses (e.g., "The aroma of frying pakoras filled the kitchen" — olfactory). Metaphor: A direct comparison saying one thing is another (e.g., "Time is a thief" — time ≠ thief, but steals moments). A wrong answer that says "Metaphor uses like or as" reveals confusion with **simile**; a wrong answer that lists only visual images reveals a narrow sense of imagery.

## DIAGNOSTIC_QUESTION_2
In the poem "cukjl", the line "vkèkk ty esa gS / vkèkk ea=k esa" repeats "vkèkk" (essence/life-force) six times. Explain what sense(s) this repetition appeals to and why the poet might choose **repetition of a noun** rather than a string of adjectives.

## DIAGNOSTIC_ANSWER_2
The repetition appeals primarily to the **kinesthetic and tactile senses** (the feeling of life pulsing through water, mud, air) and secondarily to the **auditory sense** (the rhythmic chant-like quality). Noun repetition creates a **concrete, grounding presence** — "vkèkk" becomes a physical substance you can touch — whereas adjectives would keep it abstract. A student who only says "it emphasizes importance" misses the sensory and structural function; they are treating repetition as a decorative device rather than a meaning-making one.

## DIAGNOSTIC_QUESTION_3
Identify the metaphor in the stanza beginning "bl 'kgj esa olar / vpkud vkrk gS". Name the **tenor** (target) and **vehicle** (source), and explain what quality of the vehicle is transferred to the tenor.

## DIAGNOSTIC_ANSWER_3
Tenor: the village lane / the scene of rain. Vehicle: "èkwy dk ,d coaMj" (a blanket of the sky). The metaphor transfers the qualities of a **blanket — covering, warmth, protection, softness, all-encompassing** — onto the rain-soaked lane. A wrong answer that swaps tenor/vehicle or says "the sky is a blanket" misidentifies the direction of comparison; a student who cannot name the transferred quality is only labeling, not analyzing.

## DIAGNOSTIC_QUESTION_4
Compare the **visual imagery** in the first two stanzas (rain, mud, lanes) with the **tactile/kinesthetic imagery** in the stanza "èkhjs&èkhjs mM+rh gS / èkhjs&èkhjs pyrs gSa yksx". How does the shift in sensory focus reflect the poem's movement from **external observation** to **internal experience**?

## DIAGNOSTIC_ANSWER_4
The first stanzas use **visual images** (olar, vpkud, coaMj, thHk, canjksa, ueh, ped, fHk[kkfj;ksa) — the poet *sees* the village from outside. The "èkhjs&èkhjs" stanza shifts to **bodily sensation**: mud rising, feet sinking, people walking, slipping, breathing — the reader *feels* the village from inside. This mirrors the thematic shift from describing a place to embodying its rhythm. A student who merely lists images without linking the sensory shift to the thematic shift is doing identification, not analysis.

## DIAGNOSTIC_QUESTION_5
Evaluate the claim: "The metaphor 'vkèkk ugha gS / tks gS og [kM+k gS' (stanza 4) is a **dead metaphor** because 'vkèkk' (life-force) has become a cliché in Hindi poetry." Defend or refute using evidence from the poem's context.

## DIAGNOSTIC_ANSWER_5
**Refute.** A dead metaphor is one whose comparative force is lost through overuse (e.g., "leg of the table"). Here, "vkèkk" is **redefined** in the very next lines: "vkèkk 'ko esa / vkèkk uhan esa / vkèkk 'ka[k esa" — the poet *reanimates* the word by listing its concrete manifestations (rain, mud, sky, breath, crops, sweat). The metaphor becomes a **structuring conceit** for the whole poem. A student who agrees with the claim fails to see how context revitalizes language; they are applying a label without checking textual evidence.

## DIAGNOSTIC_QUESTION_6
Write a **four-line free-verse poem** about a familiar street in your city during a sudden summer storm, using **at least two distinct types of imagery** and **one original metaphor** (not a cliché). Label each device in brackets.

## DIAGNOSTIC_ANSWER_6
Example answer:
"Neon signs bleed into puddles [visual imagery]  
Auto-rickshaws cough, sputter, surrender [auditory imagery]  
The flyover becomes a spine of light [metaphor: flyover = spine]  
And we, ants, carry our wet briefcases home [visual + kinesthetic imagery]"  
A poor answer uses only visual imagery, relies on a cliché metaphor ("storm was a monster"), or fails to label devices — showing they cannot *produce* what they are asked to *analyze*.

## COMMON_MISCONCEPTION
Students often treat **imagery** and **metaphor** as interchangeable "figurative language" and write answers like "The poet uses imagery and metaphor to make the poem beautiful." This is wrong because: (1) Imagery is **sensory evocation**; metaphor is **conceptual mapping** — they operate at different cognitive levels. (2) In "cukjl", the mud imagery (tactile, visual) *grounds* the reader, while the "vkèkk" metaphor *elevates* that mud to a philosophical principle. Conflating them leads to vague, mark-losing answers in board exams (where "explain the effect" requires distinguishing *showing* from *revealing*) and in CUET (where "identify the device and its function" demands precision).

## ON_FAILURE
1. **Revisit sensory listing**: Take any paragraph from a Hindi newspaper (e.g., a weather report) and highlight every word appealing to sight, sound, smell, touch, taste. Label each. Do this for 3 days.  
2. **Metaphor surgery**: Pick 5 common metaphors ("time is money", "heart of stone", etc.). For each, write the tenor, vehicle, and **one quality transferred**. Then change the vehicle to a fresh one and see how the meaning shifts.  
3. **Re-diagnostic**: After step 2, attempt Diagnostic Question 3 again. If you still swap tenor/vehicle, watch a 5-min video on "I.A. Richards' metaphor theory" (tenor/vehicle/ground) and redo.

## BUILDS_ON
Class 11 node c11_hin_ar_cbse_01_008 (Literary Devices: Imagery and Metaphor) where students learned basic definitions and identification in simpler poems.

## LEADS_TO
Node c12_hin_a_cbse_04_009 (Literary Devices: Irony and Symbolism) where students will see how imagery/metaphor set up ironic contrasts and symbolic resonances in the same poem.

## PREREQUISITE_NODE_IDS
c11_hin_ar_cbse_01_008, c11_hin_ar_cbse_02_008, c11_hin_ar_cbse_03_008, c11_hin_ar_cbse_04_008, c11_hin_ar_cbse_05_008, c11_hin_ar_cbse_06_008, c11_hin_ar_cbse_07_008, c11_hin_ar_cbse_08_008, c11_hin_ar_cbse_09_008, c11_hin_ar_cbse_10_008, c11_hin_ar_cbse_11_008, c11_hin_ar_cbse_12_008, c11_hin_ar_cbse_13_008, c11_hin_ar_cbse_14_008, c11_hin_ar_cbse_15_008, c11_hin_ar_cbse_16_008, c11_hin_v_cbse_01_008, c11_hin_v_cbse_02_008, c11_hin_v_cbse_03_008, c11_hin_v_cbse_04_008, c11_hin_v_cbse_05_008, c12_hin_a_cbse_04_001, c12_hin_a_cbse_04_002, c12_hin_a_cbse_04_003, c12_hin_a_cbse_04_004, c12_hin_a_cbse_04_005, c12_hin_a_cbse_04_006, c12_hin_a_cbse_04_007
## PREREQUISITE_REASONS
c11_hin_ar_cbse_01_008: Class 11 foundation — basic definitions and simple identification of imagery/metaphor in Antra poems.  
c11_hin_ar_cbse_02_008: Reinforcement across multiple chapters — exposure to varied poets (Nirala, Pant, Mahadevi) builds device-recognition fluency.  
c11_hin_ar_cbse_03_008: Practice with longer poems where imagery clusters develop themes.  
c11_hin_ar_cbse_04_008: Introduction to extended metaphor in "Ram Ki Shakti Puja" — prepares for "vkèkk" conceit in "cukjl".  
c11_hin_ar_cbse_05_008: Work with kinesthetic imagery in folk-style poems — directly relevant to "cukjl"’s tactile focus.  
c11_hin_ar_cbse_06_008: Analysis of auditory imagery in "Utsah" — helps hear the rhythm in "èkhjs&èkhjs".  
c11_hin_ar_cbse_07_008: Metaphor chains in "Badal Ko Ghirte Dekha" — model for stanza 4's "vkèkk" repetition.  
c11_hin_ar_cbse_08_008: Symbolic imagery in "Kavitavali" — bridge to symbolism in next node.  
c11_hin_ar_cbse_09_008: Visual imagery in "Premdasa" — contrast with "cukjl"’s multisensory approach.  
c11_hin_ar_cbse_10_008: Metaphor of river in "Jal Hi Jeevan Hai" — parallel to water-as-life metaphor here.  
c11_hin_ar_cbse_11_008: Olfactory imagery in "Gandh" — expands sensory repertoire beyond visual.  
c11_hin_ar_cbse_12_008: Gustatory imagery in "Annadata" — completes five-sense toolkit.  
c11_hin_ar_cbse_13_008: Mixed metaphor detection — avoids confusion in complex stanzas.  
c11_hin_ar_cbse_14_008: Dead vs. live metaphor exercise — directly used in Diagnostic Q5.  
c11_hin_ar_cbse_15_008: Writing PEEL paragraphs for device analysis — board-exam answer structure.  
c11_hin_ar_cbse_16_008: Unseen poem practice — builds exam-speed identification.  
c11_hin_v_cbse_01_008: Vitan poems add modernist imagery — broadens stylistic range.  
c11_hin_v_cbse_02_008: Metaphor in free verse — "cukjl" is free verse.  
c11_hin_v_cbse_03_008: Imagery clusters in "Apne Apne Pinjre" — cluster analysis skill.  
c11_hin_v_cbse_04_008: Metaphor of cage — structural metaphor like "vkèkk".  
c11_hin_v_cbse_05_008: Synthesis of devices in long poem — holistic analysis.  
c12_hin_a_cbse_04_001: Context of OsnkjukFk lg — biographical lens on imagery choices.  
c12_hin_a_cbse_04_002: Narrative structure — where imagery peaks in the poem's arc.  
c12_hin_a_cbse_04_003: Setting/atmosphere — imagery *creates* the atmosphere.  
c12_hin_a_cbse_04_004: Protagonist (the village) — metaphor personifies it.  
c12_hin_a_cbse_04_005: Supporting characters (rain, mud, people) — vehicles for metaphors.  
c12_hin_a_cbse_04_006: Primary theme (rootedness) — devices serve theme.  
c12_hin_a_cbse_04_007: Secondary themes (change, memory) — metaphors shift across themes.

## FORWARD_NODE_IDS
c12_hin_a_cbse_04_009, c12_hin_a_cbse_04_010, c12_hin_a_cbse_04_011, c12_hin_a_cbse_04_012, c12_hin_a_cbse_04_013, c12_hin_a_cbse_04_014, c12_hin_a_cbse_04_015
## FORWARD_REASONS
c12_hin_a_cbse_04_009: Irony/symbolism often *emerge from* metaphoric tension (e.g., "vkèkk" as life vs. mud as decay).  
c12_hin_a_cbse_04_010: Vocabulary nodes need device-awareness — "vkèkk" is a key term with layered meanings.  
c12_hin_a_cbse_04_011: Grammar usage (repetition, compound words) is a device itself — "èkhjs&èkhjs" is reduplication.  
c12_hin_a_cbse_04_012: Comprehension questions ask "How does the poet convey X?" — answer = imagery/metaphor analysis.  
c12_hin_a_cbse_04_013: Critical thinking requires evaluating device effectiveness — built on this node's evaluate-level skill.  
c12_hin_a_cbse_04_014: Writing tasks (e.g., "Write a diary entry as the village") demand using imagery/metaphor creatively.  
c12_hin_a_cbse_04_015: Speaking/listening discussions on "Is the village alive?" need metaphorical reasoning.

## CROSS_SUBJECT_PREREQS
c11_hin_ar_cbse_01_008, c11_hin_v_cbse_01_008
## CROSS_SUBJECT_REASONS
c11_hin_ar_cbse_01_008: Hindi Core (Antra) and Hindi Elective (Vitan) both teach imagery/metaphor but with different text complexities — cross-referencing deepens device recognition.  
c11_hin_v_cbse_01_008: Vitan's modernist poems use fragmented imagery — contrasts with Antra's lyrical imagery, sharpening analytical flexibility.

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_01_008 -> c12_hin_a_cbse_04_008 -> c12_hin_a_cbse_04_009

## THIS_FORMULA
PEEL Paragraph Structure for Device Analysis: **Point** (Name device + location) → **Evidence** (Quote line/phrase) → **Explanation** (Sensory appeal / Tenor-Vehicle-Ground) → **Link** (Connect to theme/tone/poet's intent).

## FORMULA_VARIABLES
Point = Specific device claim (e.g., "The poet uses tactile imagery in stanza 2"); Evidence = Exact words from poem (e.g., "fHk[kkfj;ksa osQ dVksjksa dk fupkV [kkyhiu"); Explanation = How the device works (e.g., "fupkV appeals to touch, suggesting abundance and fertility"); Link = Thematic payoff (e.g., "This reinforces the theme of the village as a nurturing, life-giving space").

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
linguistic

## CROSS_SUBJECT
N/A | Both subjects require identifying sensory imagery and metaphor in poetry, writing PEEL paragraphs, and explaining effect on theme — the analytical vocabulary (tenor, vehicle, ground, conceit) is identical.  
 N/A | Folk songs and oral epics (studied in History's culture modules) use the same metaphoric logic (e.g., "earth as mother") — analyzing "cukjl" builds skill for interpreting primary cultural texts.
## PREREQ_CONCEPT
Understanding the difference between **literal description** and **figurative comparison** — the boundary where imagery becomes metaphor.

## PREREQ_BEFORE
Student must be able to list the five senses and give a non-literary example of each; must know the terms "tenor" and "vehicle" from Class 11.

## PREREQ_STUCK
If stuck, review "tenor/vehicle/ground" using the Class 11 poem "Badal Ko Ghirte Dekha" (node c11_hin_ar_cbse_07_008) where the cloud is explicitly compared to a messenger.

## WORKED_EXAMPLE_1
PROBLEM: Analyze how the **visual and tactile imagery** in the opening stanza of "cukjl" (lines describing "olar vpkud vkrk gS" to "fHk[kkfj;ksa osQ dVksjksa dk fupkV [kkyhiu") establishes the poem's **atmosphere of fertile immersion**.

STEPS:
- Step 1: Read the stanza aloud; mark every word that triggers a sensory image. Label each: V (visual), T (tactile), A (auditory), O (olfactory), G (gustatory), K (kinesthetic).
- Step 2: Group the images by sense. You will find dense V+T clustering: "olar" (V), "vpkud" (V), "coaMj" (V+T), "thHk" (V), "canjksa" (V), "ueh" (T), "ped" (T), "fHk[kkfj;ksa" (V), "dVksjksa" (T), "fupkV [kkyhiu" (T+K).
- Step 3: Ask: Why so much touch/mud? The poem wants the reader to **feel the weight and richness** of the village soil — not just see it. The word "fupkV" (overflowing, abundant) turns mud from nuisance to nourishment.
- Step 4: Connect to atmosphere. The cumulative effect is **immersion** — the reader is "in" the mud, not looking at it. This prepares the later metaphor "vkèkk ty esa gS" (life is in the water/mud).
- Step 5: Write a PEEL paragraph using the formula. Point: The opening stanza uses dense visual-tactile imagery to create an atmosphere of fertile immersion. Evidence: "fHk[kkfj;ksa osQ dVksjksa dk fupkV [kkyhiu". Explanation: "fupkV" (brimming) + "dVksjksa" (mud) appeals to touch and kinesthesia, suggesting the land is saturated with life-potential. Link: This sensory grounding makes the abstract metaphor "vkèkk" (life-force) believable when it appears in stanza 4.

REASONING: The steps move from sensory inventory (identification) to functional grouping (classification) to thematic linkage (analysis) — mirroring the board exam's expected progression from "identify" to "explain effect".

ANSWER: The stanza's visual-tactile density (mud, water, crops, overflowing) forces the reader into bodily contact with the village's fertility, establishing an atmosphere where the land is not a backdrop but a living, enveloping presence — the necessary ground for the poem's central metaphor of "vkèkk".

## WORKED_EXAMPLE_2
PROBLEM: The poem repeats "èkhjs&èkhjs" (slowly-slowly) four times in stanza 3. Explain how this **repetition functions as a kinesthetic metaphor** for the village's temporal rhythm.

STEPS:
- Step 1: Locate the stanza: "èkhjs&èkhjs mM+rh gS / èkhjs&èkhjs pyrs gSa yksx / èkhjs&èkhjs ctrs gSa ?kaVs / 'kke èkhjs&èkhjs gksrh gS".
- Step 2: Identify the literal meaning: actions (mud rising, people walking, children slipping, breathing) happen slowly.
- Step 3: Detect the metaphor: "èkhjs&èkhjs" (adverbial repetition) becomes a **vehicle** for the **tenor** "village time". The quality transferred: **unhurried, cyclical, bodily-paced time** — unlike clock time.
- Step 4: Analyze the kinesthetic effect: Saying "èkhjs&èkhjs" aloud forces the speaker to slow down; the reduplication mimics the **drag of feet in mud**. The device *enacts* what it describes.
- Step 5: Link to theme. The poem contrasts this rhythm with modern speed ("lbZ lk¡>" — heartbeat of the city). The metaphor argues that **true life (vkèkk) only exists in slow time**.
- Step 6: Write a PEEL paragraph. Point: The reduplication "èkhjs&èkhjs" acts as a kinesthetic metaphor for the village's slow, bodily time. Evidence: "èkhjs&èkhjs mM+rh gS / èkhjs&èkhjs pyrs gSa yksx". Explanation: The repeated syllables physically slow the reader's voice, mimicking the effort of walking in mud; this transfers the quality of "slow, effortful movement" onto the abstract concept of village time. Link: This metaphorical slowing resists the city's fractured pace, embodying the poem's defense of rooted, sustainable living.

REASONING: This example shows how a **grammatical feature** (reduplication) can be analyzed as a **metaphor** — a higher-order skill needed for competitive exams like CUET where language and literature overlap.

ANSWER: "èkhjs&èkhjs" is not just an adverb; it is a performed metaphor where sound, syntax, and sense fuse to make the reader *experience* village time as slow, heavy, and life-sustaining — directly opposing the "lbZ lk¡>" of urban haste.

## WORKED_EXAMPLE_3
PROBLEM: **Synthesize** the water imagery (stanzas 1, 2, 4) and the "vkèkk" metaphor (stanza 4) to explain how the poem constructs an **ecological worldview** in which the village is a **living organism**.

STEPS:
- Step 1: Trace water images across stanzas. Stanza 1: "olar", "vpkud", "coaMj", "thHk", "ueh", "ped". Stanza 2: "èkwy", "?kkV", "vkf[kjh iRFkj". Stanza 4: "vkèkk ty esa / vkèkk ea=k esa / vkèkk iwQy esa / vkèkk 'ko esa / vkèkk uhan esa / vkèkk 'ka[k esa".
- Step 2: Note the progression: **rain → standing water → life-force in every element**. Water moves from atmospheric phenomenon to ontological principle.
- Step 3: Identify the extended metaphor: The village **is** a body; water **is** its blood/sap/breath. Tenor = village ecosystem; Vehicle = living body; Ground = water circulates, nourishes, defines vitality.
- Step 4: Find the organism imagery: "cukjl ,d feFkd cu pqdk 'kgj gS" (village is a living being), "vkèkk n'kk'oesèk" (vital point/origin), "vkèkk ty" (blood/fluids), "vkèkk 'ko" (breath), "vkèkk uhan" (warmth), "vkèkk 'ka[" (crops/food).
- Step 5: Analyze the ecological claim. The poem argues: **No water → no vkèkk → no village organism**. This is not sentiment; it's a materialist ecology where culture (songs, breathing, crops) depends on hydrology.
- Step 6: Write a synthesis paragraph. Point: The poem builds an ecological worldview through an extended body-metaphor fueled by water imagery. Evidence: Stanza 4's anaphoric "vkèkk ... esa" series. Explanation: Each line maps a bodily fluid/function (blood, sea, breath, warmth, food) onto a village element, making the village a **single metabolic system**. Link: This metaphorical biology explains why the poet ends with "fcyoqQy cs[kcj!" — the city's blinkered view cannot see this living whole.

REASONING: Synthesis across stanzas is a **board exam long-answer skill** (6-8 marks) and a **CUET critical thinking task** — requiring integration of imagery tracking, metaphor mapping, and thematic argument.

ANSWER: The poem's water imagery accumulates into an extended metaphor of the village as a living organism whose "vkèkk" (vital force) *is* water in its multiple forms — rain, mud, river, breath, heat, crop. This metaphorical biology makes the village's survival a physiological fact, not a nostalgic wish, and indicts the modern gaze that misses the living system behind the mud.

## COMPETENCY_QUESTION_1
QUESTION: A Class 12 student writes in the board exam: "The poet uses the metaphor 'vkèkk ty esa gS' to show that water is important for life." The examiner awards 1 out of 3 marks. Using the PEEL criteria, explain **what is missing** and rewrite the answer to earn full marks.

COMPETENCY: Critical evaluation of peer answer / Exam answer improvement

STEPS:
- Step 1: Identify the weakness: The student states the **ground** (water = life) but omits **Point** (device name + location), **Evidence** (quotation), and **Link** (theme/tone/poet's intent).
- Step 2: Apply PEEL: Point = "The poet employs an extended metaphor in stanza 4, equating 'vkèkk' (vital force) with water in its various forms." Evidence = "vkèkk ty esa gS / vkèkk ea=k esa / vkèkk iwQy esa ...". Explanation = "The anaphora maps water onto blood, sea, breath, warmth, crops — making water the village's circulatory system." Link = "This metaphor transforms a physical fact (rain) into a philosophical claim: the village is a living body whose survival depends on ecological integrity, countering the modern view of nature as resource."
- Step 3: Check mark allocation: 1 mark for device identification, 1 for textual evidence, 1 for thematic link — total 3.
- Step 4: Write the improved answer in exam-appropriate Hindi.

REASONING: Board marking schemes explicitly reward **device naming + quotation + effect explanation + thematic connection**. This competency trains students to self-assess against the rubric.

ANSWER: Missing: (i) Naming "extended metaphor" and "anaphora", (ii) Quoting the full "vkèkk ... esa" series, (iii) Explaining the body-mapping, (iv) Linking to the poem's ecological critique. Improved answer: "डॉ. ओंकारनाथ सिंह ने चौथे पद में 'वीक' (प्राणशक्ति) का विस्तारक रूपक (extended metaphor) प्रयुक्त किया है जहाँ अनुप्रासात्मक पुनरावृत्ति 'वीक त्य एसा / वीक एआ= एसा / वीक इवक एसा...' द्वारा जल को शरीर के रक्त, समुद्र, श्वास, उष्णता, फसल — अर्थात् संपूर्ण चयापचय तंत्र — के रूप में प्रस्तुत किया गया है। यह रूपक गाँव को एक जीवित जीव में रूपांतरित करता है और आधुनिक संसाधनवादी दृष्टि को चुनौती देता है।"

DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: In the poem "cukjl", the line "lbZ lk¡>" appears in the final stanza. Some critics call it a **synesthetic metaphor** (merging sound and sight). Argue for or against this label, using the poem's sensory trajectory. Then, propose **one alternative metaphor** for the village's vitality that would shift the poem's tone from **celebratory** to **elegiac**, and explain the shift.

COMPETENCY: Critical interpretation + Creative application (evaluate + create)

STEPS:
- Step 1: Define synesthetic metaphor: a metaphor that fuses two different senses (e.g., "loud color"). "lbZ lk¡>" = "heartbeat's flash/glimmer" — merges **auditory** (heartbeat/lub-dub) with **visual** (flash/lightning). Yes, it is synesthetic.
- Step 2: Trace sensory trajectory: Stanza 1 = visual+tactile (mud, rain). Stanza 2 = auditory+visual (thunder, lightning). Stanza 3 = kinesthetic+tactile (slow movement). Stanza 4 = multisensory "vkèkk" catalog. Stanza 5 = synesthetic "lbZ lk¡>". The poem **builds** toward this fusion — the village's vitality becomes a single sensory event.
- Step 3: Argue FOR: The synesthesia enacts the poem's claim that in the village, senses are not separated; life is a unified field. "lbZ lk¡>" is the **metaphoric climax**.
- Step 4: Create an elegiac alternative: "सूखी नदी की पसली" (ribcage of a dried river). Tenor = village vitality; Vehicle = skeletal remains of a river. Transferred qualities: **absence, fragility, past fullness, irreversible loss**.
- Step 5: Explain tonal shift: "vkèkk" metaphors assert **presence**; "सूखी नदी की पसली" asserts **absence**. The tone moves from "life is here, pulsing" to "life was here, now only bones remain". The poem would become a lament for ecological death.

REASONING: This question tests the highest Bloom levels — evaluating a critical term and creating a new metaphor with controlled tonal effect — exactly the skill needed for CUET's "creative response" and JEE Advanced's "literary analysis" (if Hindi is chosen).

ANSWER: "lbZ lk¡>" is a valid synesthetic metaphor — it fuses the sound of a heartbeat with the sight of a flash, capping the poem's sensory integration. An elegiac alternative: "वीक सूखी नदी की पसली में अटकी साँस" (breath stuck in the ribcage of a dried river). This replaces the fluid, abundant "वीक" with a rigid, hollow structure, shifting tone from celebration of vitality to mourning of its loss — the village becomes a relic, not a living organism.

DIFFICULTY: hard