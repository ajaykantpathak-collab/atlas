## DEFINITION
Irony (विडंबना) is a literary device where the intended meaning of words or events contradicts their literal or expected meaning, revealing a deeper, often bitter truth. Symbolism (प्रतीकवाद) uses concrete objects, characters, or actions to represent abstract ideas, where the "iron chain" (जत्र जंजीर) embodies both the product of labor and the systemic bondage of the Agaria community.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student must independently identify at least two distinct types of irony (situational, dramatic, verbal) and two symbols in the text, explain their function with textual evidence, and articulate how they jointly expose the exploitation of the Agaria iron-smelters.

## SCOPE_BOUNDARY
This node covers irony and symbolism exclusively in "जत्र जंजीर" (Chapter 2, Vitan). It does NOT cover imagery/metaphor (covered in node 008), other rhetorical devices, or general definitions without textual application. It focuses on how these devices reveal socio-economic critique.

## WALKTHROUGH
Imagine you watch a blacksmith forge a strong chain, yet that same chain is used to bind his own hands—this is the central irony of the chapter. Begin by asking: "Where do the Agarias' labor and its reward violently diverge?" Scan the text for moments where expectation clashes with outcome (e.g., they produce iron for the state but remain impoverished). Then hunt for recurring concrete images—chain, underground stream, fire, furnace—that carry weight beyond their physical presence. The key insight: irony exposes the injustice; symbols make that injustice tangible and unforgettable.

## DIAGNOSTIC_QUESTION_1
Define situational irony and give one example from the chapter where the Agarias' labor produces an outcome opposite to what they deserve.

## DIAGNOSTIC_ANSWER_1
Situational irony occurs when actions produce results starkly contrary to intentions or justice. In the chapter, Agarias smelt high-quality iron for the state's weapons and infrastructure, yet they live in abject poverty, malnourished and bondaged—their labor strengthens the very system that exploits them. A wrong answer (e.g., "irony means sarcasm") reveals confusion between verbal irony and situational irony, and failure to link the device to the text's socio-economic critique.

## DIAGNOSTIC_QUESTION_2
Explain in your own words why the "underground stream" (भूमिगत नदी) functions as a symbol, not just a geographical detail. What abstract idea does it represent?

## DIAGNOSTIC_ANSWER_2
The underground stream symbolizes the hidden, suppressed suffering and invisible exploitation of the Agarias—just as the stream flows unseen beneath the surface, their pain and systemic injustice remain invisible to the state and society. A wrong answer (e.g., "it shows water scarcity") treats it as literal description, missing the symbolic leap from physical phenomenon to socio-political metaphor, a hallmark of senior-secondary analysis.

## DIAGNOSTIC_QUESTION_3
Identify one instance of dramatic irony in the passage where the reader knows more than the officials inspecting the furnaces. Quote the relevant lines (paraphrased) and explain the gap in awareness.

## DIAGNOSTIC_ANSWER_3
When officials inspect furnaces and record "production data" (उत्पादन आंकड़े), the reader knows each kilogram of iron represents stolen labor, depleted forests, and starving families—knowledge the officials deliberately ignore. Steps: (1) Locate inspection scene, (2) Note officials' perspective (bureaucratic), (3) Contrast with Agarias' lived reality (exploitation), (4) Name the gap: dramatic irony. A wrong answer that merely quotes lines without explaining the awareness gap shows inability to distinguish dramatic irony from mere description.

## DIAGNOSTIC_QUESTION_4
Compare the symbol of "fire" (आग/भट्टी) in the Agarias' furnace with the symbol of "chain" (जंजीर). How do their meanings intersect to deepen the theme of bonded labor?

## DIAGNOSTIC_ANSWER_4
Fire represents both creative labor (transforming ore to iron) and destructive consumption (burning forests, bodies, futures). The chain represents the product (iron) and the process (bondage). Their intersection: the fire forges the chain that binds the maker—labor creates its own shackles. A weak answer lists meanings separately without synthesizing how the two symbols co-produce the theme of self-perpetuating exploitation.

## DIAGNOSTIC_QUESTION_5
Evaluate: "The title 'जत्र जंजीर' (Iron Chain) is more ironic than symbolic." Defend or refute with two textual arguments.

## DIAGNOSTIC_ANSWER_5
Refute—the title is equally both. As symbol: the chain concretizes abstract bondage. As irony: the Agarias forge chains for others' freedom while remaining chained themselves. Argument 1: The chain is the physical output (symbol) whose purpose (state power) contradicts the maker's condition (irony). Argument 2: The chain's strength (quality) is praised, yet the maker's strength is depleted (ironic inversion). A wrong answer picking only one side reveals reductive thinking that separates devices the text fuses.

## DIAGNOSTIC_QUESTION_6
Write a 4-line poetic stanza from the perspective of an Agaria elder, using the furnace as a symbol and embedding one ironic twist in the final line.

## DIAGNOSTIC_ANSWER_6
Example: "भट्टी तपे, लोहा ढले, जंजीर बने सघन / हाथ हमारे जलें, राज सजे हर क्षण / धुएँ में खो गई सुबह, राख हुई पहचान / लोहा हमने गढ़ा, पर गुलाम हुए हम ही जान।" A poor answer uses furnace only literally ("fire burns hot") without symbolic weight, or states irony explicitly ("it is ironic that...") instead of enacting it through contrast.

## COMMON_MISCONCEPTION
Students conflate symbolism with imagery, treating every descriptive detail (e.g., "smoke," "hammer") as a symbol. They also restrict irony to verbal sarcasm, missing situational and dramatic irony that structure the chapter's critique. This happens because Class 10 taught "symbol = object representing something" without the senior-secondary requirement: the symbol must be *recurrent*, *textually anchored*, and *thematically consequential*. Similarly, irony was taught as "saying opposite of what you mean," not as structural contradiction between labor and reward.

## ON_FAILURE
Step 1: Give the student two columns—"Literal Detail" vs. "Symbolic Meaning"—and have them classify 5 textual elements (furnace, chain, stream, forest, inspector's pen). Step 2: For irony, provide a 3-row table: "Expectation / Reality / Type of Irony" using the Agarias' wages, the state's rhetoric, and the furnace's output. Step 3: Ask them to rewrite one paragraph replacing symbols with literal language, then discuss what is lost. Step 4: Assign a micro-essay: "How does the chain symbolize what irony exposes?" forcing synthesis.

## BUILDS_ON
c11_hin_v_cbse_02_008 (Literary Devices: Imagery and Metaphor) — students already distinguish literal from figurative language.

## LEADS_TO
c11_hin_v_cbse_02_013 (Critical Thinking: Analysis and Interpretation) — where irony and symbolism become tools for full-text critique.

## PREREQUISITE_NODE_IDS
c11_hin_v_cbse_02_001, c11_hin_v_cbse_02_002, c11_hin_v_cbse_02_008, c11_hin_v_cbse_02_006, c11_hin_v_cbse_02_007

## PREREQUISITE_REASONS
c11_hin_v_cbse_02_001: Context/background provides the historical reality (Agaria exploitation) that irony and symbolism critique.
c11_hin_v_cbse_02_002: Plot/narrative structure identifies key scenes (furnace work, inspection, wage payment) where devices operate.
c11_hin_v_cbse_02_008: Imagery and metaphor training gives the figurative-language foundation; symbolism extends metaphor into sustained, thematic representation.
c11_hin_v_cbse_02_006: Irony (title vs. reality) and symbolism (brick as frozen labour) are the *techniques* conveying the theme.  
c11_hin_v_cbse_02_007: Irony and symbolism (e.g., water giving life but reflecting caste divisions) deepen secondary theme analysis.  

## FORWARD_NODE_IDS
c11_hin_v_cbse_02_012, c11_hin_v_cbse_02_013, c11_hin_v_cbse_02_014, c12_hin_a_cbse_05_009, c12_hin_a_cbse_10_009, c12_hin_al_cbse_01_009, c12_hin_ar_cbse_09_009, c12_hin_v_cbse_02_009

## FORWARD_REASONS
c11_hin_v_cbse_02_012: Comprehension questions require identifying and explaining irony/symbolism for inferential answers.
c11_hin_v_cbse_02_013: Critical analysis builds on device identification to evaluate author's purpose and socio-political commentary.
c11_hin_v_cbse_02_014: Writing tasks (analytical paragraph, essay) demand structured use of textual evidence on these devices.
c12_hin_a_cbse_05_009: अगला तार्किक चरण: Irony is a literary device where the intended meaning of words or a situation is opposite to their l... इस नोड की अवधारणाओं को सीधे उपयोग/विस्तारित करता है।  
c12_hin_a_cbse_10_009: Vitan Chapter 2 used symbolism in travel writing — setting-as-symbol practice.  
c12_hin_al_cbse_01_009: Class 11 Vitan Chapter 2 Irony and Symbolism node reinforces with non-fiction context.  
c12_hin_ar_cbse_09_009: अगला तार्किक चरण: Irony is a literary device where the intended meaning of words or events contrasts sharply with thei... इस नोड की अवधारणाओं को सीधे उपयोग/विस्तारित करता है।  
c12_hin_v_cbse_02_009: Reinforced practice with irony/symbolism in a different Vitan chapter (Class 11 Chapter 2).  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
none

## CHAIN_DESCRIPTION
c11_hin_v_cbse_02_008 -> c11_hin_v_cbse_02_009 -> c11_hin_v_cbse_02_013

## THIS_FORMULA
N/A - conceptual

## FORMULA_VARIABLES
N/A

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
analytical

## CROSS_SUBJECT
c11_history_industrialisation | The chapter's depiction of traditional iron-smelting communities mirrors the colonial-era destruction of indigenous industries; irony/symbolism here parallel historical analysis of economic exploitation.
c11_economics_labour_markets | The Agarias' condition illustrates "unfree labour" and "monopsony power" (single buyer—state—dictating wages); literary devices make abstract economic coercion visceral.

## PREREQ_CONCEPT
Ability to distinguish literal description from figurative representation (from Imagery/Metaphor node) and knowledge of the Agaria community's historical exploitation (from Context node).

## PREREQ_BEFORE
Student must recall the sequence of iron-production stages (mining, smelting, forging) and the power dynamic between Agarias and state officials.

## PREREQ_STUCK
Revisit c11_hin_v_cbse_02_001 (Context) for Agaria socio-economic reality and c11_hin_v_cbse_02_008 (Imagery/Metaphor) for figurative language basics.

## WORKED_EXAMPLE_1
PROBLEM: Analyze how the "inspector's pen" (निरीक्षक की कलम) functions as a symbol of bureaucratic violence in the furnace-inspection scene. Use the 4-step analytical method.

STEPS:
- Step 1: Locate the scene—officials arrive, measure output, record numbers in registers, ignore human cost.
- Step 2: Identify the object—the pen that transforms living labor into dead statistics.
- Step 3: Establish symbolic resonance—pen = state power, reductionism, erasure of suffering; it "writes" the Agarias out of their own product.
- Step 4: Connect to theme—the pen is mightier than the hammer; bureaucratic violence completes what physical violence begins.
- Step 5: Verify with text—contrast "कलम चलती रही" (pen kept moving) with "मजदूर की साँस फूलती रही" (worker's breath kept rising).

REASONING: This method moves from concrete textual detail to abstract representation to thematic synthesis—the exact progression board exams reward.

ANSWER: The inspector's pen symbolizes the bureaucratic apparatus that converts the Agarias' flesh-and-blood labor into abstract production data, rendering their exploitation invisible and administratively legitimate. It represents state power that records but does not see, writes but does not witness.

## WORKED_EXAMPLE_2
PROBLEM: Identify and explain the verbal irony in the phrase "उत्पादन में वृद्धि, राष्ट्र की प्रगति" (increase in production, nation's progress) as it appears in official reports about the furnaces.

STEPS:
- Step 1: Isolate the phrase—official slogan celebrating output metrics.
- Step 2: Define verbal irony—words stating one thing while context reveals the opposite truth.
- Step 3: Map the contradiction—"production increase" = more Agaria suffering; "nation's progress" = deepening bondage of a community.
- Step 4: Determine speaker vs. author stance—officials speak it sincerely; author (वuqie feJ) deploys it ironically.
- Step 5: Explain effect—exposes the moral vocabulary of exploitation; progress built on unfreedom.

REASONING: Verbal irony here operates at the systemic level—not a character's quip but the state's own language turned against itself.

ANSWER: The phrase is verbally ironic because the official discourse equates higher iron output with national progress, while the narrative reveals each ton of iron represents depleted forests, malnourished families, and strengthened bondage. The words "प्रगति" (progress) and "वृद्धि" (growth) acquire a hollow, accusatory resonance in the text's context.

## WORKED_EXAMPLE_3
PROBLEM: Trace the dual symbolism of "राख" (ash) across three scenes: (a) furnace waste, (b) cremation of an Agaria worker, (c) the inspector's cigarette ash. Explain how this recurrence binds ecological, bodily, and bureaucratic destruction.

STEPS:
- Step 1: Scene (a)—furnace ash = spent ore, depleted forest, wasted byproduct of extraction.
- Step 2: Scene (b)—cremation ash = worker's body returned to the same earth that fed the furnace; labor consumes the laborer.
- Step 3: Scene (c)—cigarette ash = inspector's casual disposal, mirroring state's disposal of lives; ash as indifferent residue.
- Step 4: Synthesize—ash is the common denominator: what remains after value is extracted. Nature → body → bureaucracy all reduced to ash.
- Step 5: Link to central motif—the "iron chain" is forged in fire but ends in ash; the chain's permanence is illusory.
- Step 6: Thematic payoff—symbolic recurrence structures the chapter's argument: exploitation is totalizing, leaving only ash.

REASONING: Senior-secondary analysis requires tracking a symbol's migration across contexts to reveal structural coherence—this is the "symbolic cluster" method examiners expect.

ANSWER: "राख" operates as a unifying symbol of terminal extraction. In the furnace, it marks ecological depletion; at the pyre, it marks the worker's body as final fuel; in the inspector's hand, it marks bureaucratic indifference. The three ashes form a symbolic chain: the earth gives ore, the body gives labor, the state gives orders—all end in ash. The iron chain (जत्र जंजीर) is the only thing that seems to survive, but even it will rust to dust.

## COMPETENCY_QUESTION_1
QUESTION: The chapter describes a moment when an Agaria elder says, "हम लोहा गढ़ते हैं, लोहा हमें गढ़ता है" (We forge iron, iron forges us). Identify the literary device(s) at play and explain how this statement encapsulates the chapter's central irony through symbolic language.

COMPETENCY: Interpret figurative language and structural irony in a textual utterance.

STEPS:
- Step 1: Identify the device—chiasmus (reversal structure) + symbolism (iron as agent).
- Step 2: Decode the symbol—iron = material product, economic system, historical force.
- Step 3: Explain the irony—the makers become the made; agency reverses into determinism.
- Step 4: Connect to chapter's arc—from human skill to systemic trap.

ANSWER: The statement uses chiasmus to enact the chapter's core situational irony: the Agarias' labor (forging iron) creates the very material conditions (iron chain, state power, market logic) that determine their unfreedom. "Iron" symbolizes the socio-economic structure that emerges from their work and returns to enslave them. The reversal "लोहा हमें गढ़ता है" personifies iron as an active historical agent—symbolism elevated to structural critique.

DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: A board exam asks: "How does the author use the symbol of the 'underground stream' (भूमिगत नदी) to sustain dramatic irony throughout the chapter? Support with two specific textual moments." Write a structured answer using the PEEL method (Point, Evidence, Explanation, Link).

COMPETENCY: Construct an exam-style analytical response integrating symbolism and dramatic irony with textual evidence.

STEPS:
- Step 1: Point—The underground stream symbolizes invisible exploitation, creating dramatic irony between surface appearance (normal furnace work) and subterranean reality (systemic drain).
- Step 2: Evidence 1—Description of stream flowing unseen beneath furnace sites while officials measure only visible output.
- Step 3: Explanation 1—Reader knows the stream mirrors the hidden costs (health, ecology, freedom) absent from official records.
- Step 4: Evidence 2—Moment when stream's course shifts after monsoon, threatening furnaces, paralleling how policy shifts threaten Agarias unseen.
- Step 5: Link—The symbol sustains dramatic irony by making the reader permanently aware of what power ignores.

ANSWER: The underground stream functions as a sustained symbol of the Agarias' invisible exploitation, generating dramatic irony by contrasting what the state sees (production) with what the text reveals (depletion). First, the stream flows "unseen beneath the furnace grounds" (अदृश्य बहती नदी) while officials record only kg of iron—the reader knows the stream carries away the community's water, health, and autonomy, unrecorded in registers. Second, when monsoons shift the stream's course and threaten furnace stability, the officials react to structural risk but not human cost—mirroring how policy changes destabilize Agarias' lives without their consent. In both moments, the symbol makes the reader complicit in a knowledge the powerful refuse: that the real current runs underground, and it is eroding the foundations.

DIFFICULTY: hard