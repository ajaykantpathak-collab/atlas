## DEFINITION
Character analysis of supporting characters in poetry involves examining the roles, traits, and symbolic functions of secondary personas (such as addressees, foils, or symbolic figures) that interact with the main speaker to advance the poem's themes and emotional depth.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student can identify supporting characters in Vaddegnasoh's poems, explain their symbolic significance, and write a structured analysis using textual evidence to show how they illuminate the protagonist's struggle and the poem's central themes.

## SCOPE_BOUNDARY
This node covers analysis of supporting characters (the Bazoj, the father, and the poetess as a persona) in the two prescribed poems of Chapter 14. It does not cover protagonist analysis (covered in node 004) or thematic analysis beyond character-function (covered in nodes 006-007).

## WALKTHROUGH
Imagine you are listening to a friend pour out their heart to a silent listener – that listener shapes the conversation without speaking a word. In Vaddegnasoh's second poem, the speaker addresses a "बज़ोज" (Bazoj), a symbolic figure who never replies but defines the speaker's desperation. Begin by rereading the poem and marking every reference to the Bazoj: what is asked of it, how the speaker describes it, and what its silence implies. Then compare this to the father figure mentioned in the introductory note – though absent from the poem's lines, his presence frames the daughter's plight. The key insight: supporting characters in poetry are often silent symbols that reflect the protagonist's inner world and the socio-historical constraints she battles.

## DIAGNOSTIC_QUESTION_1
In Vaddegnasoh's second poem, who is the "बज़ोज" addressed by the speaker, and what single word in the poem indicates the speaker's relationship to it?

## DIAGNOSTIC_ANSWER_1
The "बज़ोज" is the addressee, a symbolic figure (likely a bird or messenger) to whom the speaker entrusts her message. The word "बज़ोज" itself, repeated in the opening line, establishes the relationship of supplicant to a hoped-for intermediary. A wrong answer (e.g., identifying Bazoj as the protagonist or a human friend) reveals the student has not distinguished between the speaking "I" and the addressed "you" in lyric poetry.

## DIAGNOSTIC_QUESTION_2
Explain in your own words why the father, though not directly speaking in the poem, functions as a supporting character in the second poem.

## DIAGNOSTIC_ANSWER_2
The father is the unseen authority whose "अन्य बेटी" (other daughter) is the speaker; his patriarchal control creates the "विलक्षण परिस्थिति" (extraordinary situation) that forces the daughter to seek the Bazoj's help. His absence from the dialogue makes his power more oppressive. A wrong answer that says "the father is not a character because he doesn't appear" shows the student conflates character presence with physical appearance, missing how off-stage figures drive poetic conflict.

## DIAGNOSTIC_QUESTION_3
Apply the concept of a "foil" to the Bazoj: how does the Bazoj's imagined nature (silent, mobile, free) contrast with the speaker's condition (voiced, trapped, suffering) in the second poem? Use two specific details from the poem.

## DIAGNOSTIC_ANSWER_3
The Bazoj is asked to fly ("उड़ जाय") and enter the house freely ("पूरा रास्ता खुल जाए"), contrasting with the speaker who is confined ("मेरा घर") and in physical pain ("गहन शारीरिक पीड़ा"). The Bazoj's potential to return with a reply ("कोई जवाब आ जाए") highlights the speaker's current voicelessness in the patriarchal structure. A wrong answer that merely lists traits without contrasting them reveals inability to analyze relational character dynamics.

## DIAGNOSTIC_QUESTION_4
Analyze how the first poem's abstract addressee (the repeated "एर एर" and imperative verbs) functions differently as a supporting character than the concrete Bazoj in the second poem.

## DIAGNOSTIC_ANSWER_4
The first poem's addressee is an abstract, almost incantatory force ("एर एर" as a rhythmic invocation) representing internalized oppression or societal "बंधन" (constraints), whereas the Bazoj is a personalized, externalized hope for communication. The first poem's supporting "character" is a collective antagonist; the second's is a potential ally. A wrong answer treating both as similar addressees misses the shift from existential questioning to interpersonal plea.

## DIAGNOSTIC_QUESTION_5
Evaluate the claim: "Vaddegnasoh uses supporting characters not as individuals but as symbols of the freedom struggle." Defend or refute with evidence from both poems and the biographical note.

## DIAGNOSTIC_ANSWER_5
The claim is partially true but reductive. In the second poem, the Bazoj symbolizes the yearning for liberated communication (mirroring the poet's own silenced voice in the freedom movement), and the father represents colonial/patriarchal authority. However, the biographical note shows Vaddegnasoh herself was a historical actor – the supporting characters are grounded in her lived reality, not mere allegory. A wrong answer that fully agrees ignores the poems' intimate, bodily specificity (e.g., "गहन शारीरिक पीड़ा"); one that fully disagrees misses the allegorical layer the introduction explicitly highlights.

## DIAGNOSTIC_QUESTION_6
Create a four-line stanza in which a new supporting character (a tree, a wind, or a lamp) responds to the speaker's plea in the second poem, maintaining the poem's tone and the character's symbolic role.

## DIAGNOSTIC_ANSWER_6
A strong answer will invent a character (e.g., an old neem tree) that witnesses the speaker's pain but cannot move, offering shade instead of flight – thus extending the theme of constrained agency. The stanza should use the poem's diction (e.g., "एर", "बज़ोज") and show the new character's limitations. A poor answer writes a generic motivational reply, ignoring the poem's desperate, bodily tone and the historical weight of silence.

## COMMON_MISCONCEPTION
Students often think "supporting characters" in poetry must be human figures who speak or act visibly. They overlook silent addressees (like the Bazoj), off-stage authorities (the father), and abstract forces (the "बंधन" in poem 1) as characters. This error arises because they apply prose-fiction character criteria (dialogue, action, description) to lyric poetry, where character is constructed through address, allusion, and symbolic function.

## ON_FAILURE
If a student cannot identify non-human/off-stage supporting characters, guide them through three steps: (1) List every noun/pronoun that is not the speaker ("I") in the poem – include "बज़ोज", "पिता", "एर", "बंधन". (2) For each, ask: "Does this entity affect the speaker's choices or emotions?" (3) Classify each as addressee, antagonist, witness, or symbol. Use the biographical note to confirm the father's role. Then have them write one sentence per entity explaining its function.

## BUILDS_ON
This node builds on the protagonist analysis (node 004) where the speaker's voice and situation were established; supporting characters are defined relationally to that protagonist.

## LEADS_TO
This node enables theme analysis (nodes 006-007) because the supporting characters embody the thematic conflicts (freedom vs. constraint, voice vs. silence) that the themes abstract.

## PREREQUISITE_NODE_IDS
c11_hin_ar_cbse_14_001, c11_hin_ar_cbse_14_002, c11_hin_ar_cbse_14_004
## PREREQUISITE_REASONS
c11_hin_ar_cbse_14_001: Provides historical context (freedom movement, poet's biography) essential to interpret the father and Bazoj as more than fictional figures.
c11_hin_ar_cbse_14_002: Establishes narrative structure of the poems (especially the dramatic monologue form of poem 2) which frames how supporting characters enter.
c11_hin_ar_cbse_14_004: Defines the protagonist (the speaker/daughter); supporting characters are analyzed only in relation to her.

## FORWARD_NODE_IDS
c11_hin_ar_cbse_14_006, c11_hin_ar_cbse_14_007, c11_hin_ar_cbse_14_008, c11_hin_ar_cbse_14_009, c11_hin_ar_cbse_14_013, c11_hin_ar_cbse_14_014, c12_hin_a_cbse_14_005, c12_hin_ar_cbse_06_005, c12_hin_ar_cbse_14_005, c12_hin_a_cbse_14_001

## FORWARD_REASONS
c11_hin_ar_cbse_14_006: Primary theme (freedom/voice) emerges from protagonist-supporting character dynamics.
c11_hin_ar_cbse_14_007: Secondary themes (patriarchy, bodily suffering, poetic resistance) are carried by specific supporting figures.
c11_hin_ar_cbse_14_008: Imagery/metaphor (e.g., Bazoj as bird/messenger) is attached to supporting characters.
c11_hin_ar_cbse_14_009: Irony/symbolism (silent Bazoj vs. speaking poet) operates through supporting character contrasts.
c11_hin_ar_cbse_14_013: Supporting characters (king, clouds, lightning) function as symbols needing interpretation.  
c11_hin_ar_cbse_14_014: Supporting characters (the king, the bird) function as foils; essential for comparative Points.  
c12_hin_a_cbse_14_005: अगला तार्किक चरण: A supporting character is a fictional figure who interacts with the protagonist to advance the plot,... इस नोड की अवधारणाओं को सीधे उपयोग/विस्तारित करता है।  
c12_hin_ar_cbse_06_005: Class 11 foundation on supporting character analysis in Aroh.  
c12_hin_ar_cbse_14_005: Class 11 practice in identifying character functions (flat/round, foil) applies directly.  
c12_hin_a_cbse_14_001: rotagonist analysis establishes the central figure against which supporting characters are defined. c11_hin_ar_cbse_14_005: Class 11 practice in identifying foil, catalyst, and thematic embodiment roles.  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
none

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_14_001 -> c11_hin_ar_cbse_14_005 -> c11_hin_ar_cbse_14_006

## THIS_FORMULA
N/A - conceptual

## FORMULA_VARIABLES
N/A

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
analytical

## CROSS_SUBJECT
c11_history_nationalism | The poet's biography links her poetry to the Indian freedom movement; the father figure mirrors colonial authority and the Bazoj represents the yearning for liberated communication, making character analysis a window into historical consciousness.
c11_civics_gender | The daughter-father-Bazoj triangle illustrates patriarchal control over women's mobility and voice; analyzing supporting characters reveals how literature encodes civic struggles for gender equality.

## PREREQ_CONCEPT
Understanding of dramatic monologue form and the distinction between speaker (protagonist) and addressee (supporting character) in lyric poetry.

## PREREQ_BEFORE
Student must be able to identify the speaker ("I") in both poems and summarize the speaker's explicit situation (confinement, pain, plea).

## PREREQ_STUCK
Review the dramatic monologue structure in node 002 and the protagonist's profile in node 004; then reread poem 2 marking every "you" and third-person reference.

## WORKED_EXAMPLE_1
PROBLEM: Analyze the role of the "बज़ोज" (Bazoj) as a supporting character in the second poem. Write a structured paragraph using the PEEL method (Point, Evidence, Explanation, Link).

STEPS:
- Step 1: Identify the Point – The Bazoj functions as a symbol of unattainable freedom and the speaker's only hoped-for link to the outside world.
- Step 2: Gather Evidence – Locate three references: (a) "बज़ोज" addressed directly in opening line; (b) requested to fly ("उड़ जाय") and enter house ("पूरा रास्ता खुल जाए"); (c) expected to return with a reply ("कोई जवाब आ जाए").
- Step 3: Explain Evidence – The verbs "उड़ जाय", "खुल जाए", "आ जाए" are in subjunctive/optative mood, showing the speaker's wish, not reality. The Bazoj's mobility contrasts with her confinement ("मेरा घर", "गहन शारीरिक पीड़ा"). Its silence (no direct speech) mirrors the poet's own silenced voice in history.
- Step 4: Link to Theme – This supporting character embodies the poem's central tension: the desperate need for communication across patriarchal/colonial barriers. The Bazoj's failure to appear (implied by the poem's continuation) deepens the tragedy.
- Step 5: Draft PEEL Paragraph – (Point) The Bazoj is not a mere bird but a projected ideal of agency. (Evidence) The speaker commands it to "उड़ जाय" and bring a "जवाब". (Explanation) Its imagined flight and return enact the freedom the speaker lacks. (Link) Thus the Bazoj crystallizes the theme of voice versus silence that runs through Vaddegnasoh's work.

REASONING: The steps move from identification to thematic synthesis, modeling the board-exam expectation of evidence-based character analysis. The PEEL structure ensures each claim is anchored in the text.

ANSWER: The Bazoj serves as a silent, mobile foil to the trapped, vocal protagonist. By investing it with the power to fly and return, the speaker externalizes her own thwarted desire for agency. Its symbolic weight is confirmed by the biographical note: Vaddegnasoh herself was exiled for her voice, making the Bazoj a poetic stand-in for the uncensored communication she was denied.

## WORKED_EXAMPLE_2
PROBLEM: Compare the function of the father (mentioned in the introductory note) and the "बंधन" (constraints) addressed in the first poem as supporting antagonistic forces. Write a comparative analysis in 4-5 sentences.

STEPS:
- Step 1: Identify the two forces – Father (poem 2, biographical note) and "बंधन" (poem 1, line "बंदिशों पर सवाल उठाया गया है").
- Step 2: Note their nature – Father is a specific historical/patriarchal figure; "बंधन" is an abstract, collective societal force.
- Step 3: Find textual links – Poem 1 uses imperatives ("एर एर") to challenge "बंधन"; Poem 2's speaker seeks escape from father's house via Bazoj.
- Step 4: Analyze relationship to protagonist – Both provoke the speaker's resistance: poem 1 through direct questioning, poem 2 through covert plea.
- Step 5: Synthesize – The father personalizes the abstract "बंधन"; the poems together show oppression as both systemic and intimate.

REASONING: This comparison requires holding two poems side by side and using the biographical note as a bridge – a skill tested in board exam long-answer questions.

ANSWER: In poem 1, the "बंधन" is an impersonal structure the speaker confronts through rhetorical questions ("एर एर"), making it a diffuse antagonist. In poem 2, the father (though off-stage) is the concrete source of the speaker's confinement; his authority is the lived instantiation of those "बंधन". The Bazoj's plea targets the father's power indirectly. Together, the two supporting forces reveal Vaddegnasoh's dual strategy: naming the abstract system and dramatizing its intimate enforcement.

## WORKED_EXAMPLE_3
PROBLEM: The introductory note states Vaddegnasoh "अपनी वकालत के लिए गहन शारीरिक पीड़ा से अपनी व्यथा प्रकट करना चाहती हैं" (wanted to express her anguish through intense physical pain for her advocacy). Analyze how the supporting characters in both poems collaborate to make the speaker's bodily suffering visible and political. Write a 6-step analysis.

STEPS:
- Step 1: Define the claim – The poet uses supporting characters to stage the speaker's body as a site of resistance.
- Step 2: Poem 1 – The abstract addressee ("एर एर") is invoked through the speaker's bodily rhythms (breath, pain sounds), turning constraints into visceral experience.
- Step 3: Poem 2 – The Bazoj is asked to witness the speaker's "गहन शारीरिक पीड़ा" and carry it beyond the house; the father's house is the container of that pain.
- Step 4: Biographical link – Vaddegnasoh's own exile and hunger strikes (historical fact) make the speaker's pain autobiographical; supporting characters become witnesses to historical truth.
- Step 5: Political dimension – The Bazoj's flight represents the poem itself traveling beyond censorship; the father's silence represents state/patriarchal censorship.
- Step 6: Conclusion – Supporting characters transform private suffering into public testimony; without them, the speaker's pain remains unheard.

REASONING: This multi-step analysis integrates textual details, biographical context, and political interpretation – the highest-order skill for Class 12 board exams.

ANSWER: The supporting characters (the invoked "एर एर", the Bazoj, the father) form a chain: the speaker's body generates the cry ("एर एर"), the Bazoj is the attempted vehicle for that cry's escape, and the father is the barrier. The biographical note confirms this is not metaphor alone – Vaddegnasoh's body was the medium of her protest. Thus, supporting characters are not decorative; they are the mechanism by which lyric poetry becomes political action.

## COMPETENCY_QUESTION_1
QUESTION: In the second poem, the speaker says: "मेरा घर पूरा रास्ता खुल जाए" (let my house's whole path open). Explain how this line uses the supporting character (Bazoj) to reveal the speaker's spatial and social confinement. Use the concept of "threshold" (दहलीज़) in your answer.

COMPETENCY: Literary analysis – interpreting spatial metaphor through character interaction

STEPS:
- Step 1: Identify the literal request – The speaker asks the Bazoj to make the path open.
- Step 2: Connect to supporting character – The Bazoj is the agent who can cross the threshold; the speaker cannot.
- Step 3: Analyze "threshold" – The house represents patriarchal enclosure; the "रास्ता" (path) is the threshold between private captivity and public freedom.
- Step 4: Link to biography – Vaddegnasoh's own exile meant crossing a literal threshold; the poem re-enacts that moment.
- Step 5: Formulate answer – The line shows the speaker's confinement is spatial (locked house) and social (needs a mediator). The Bazoj's imagined crossing highlights the speaker's immobility.

ANSWER: The line "मेरा घर पूरा रास्ता खुल जाए" uses the Bazoj as the only entity capable of breaching the threshold of the patriarchal home. The speaker, confined by "गहन शारीरिक पीड़ा" and paternal authority, cannot open the path herself. The Bazoj's requested flight – entering and exiting freely – marks the threshold as a gendered border. Historically, Vaddegnasoh crossed such a border into exile; the poem internalizes that crossing as a desperate wish. Thus, the supporting character Bazoj makes visible the threshold the protagonist cannot cross alone.

DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: "Supporting characters in Vaddegnasoh's poems are not individuals but functions." Critically evaluate this statement with reference to both poems and the biographical note. Your answer must address: (a) the Bazoj, (b) the father, (c) the abstract addressee in poem 1, and (d) the poet's own historical persona.

COMPETENCY: Critical evaluation – balancing textual evidence with historical context

STEPS:
- Step 1: Break down the statement – "Functions" means they serve thematic/symbolic roles rather than having independent personality.
- Step 2: Analyze Bazoj – It has no voice, no backstory, only the speaker's projection; it functions as hope/messenger. But the speaker's detailed instructions give it quasi-personhood.
- Step 3: Analyze father – He has historical reality (the king who exiled her) but zero dialogue; he functions as patriarchal law. Yet the biographical note gives him individual agency (he got scared, exiled her, broke promises).
- Step 4: Analyze poem 1 addressee – "एर एर" is purely a rhetorical device, a function of the poem's incantatory mode. No individuality.
- Step 5: Analyze poet's persona – Vaddegnasoh herself is a supporting character in her own mythology (the "अन्य बेटी"); the note frames her as a historical actor, not just a function.
- Step 6: Synthesize – The statement is true for poem 1's addressee, partially true for Bazoj, false for father and poet. The poems blur function and individuality to show how history makes symbols of people.

ANSWER: The statement oversimplifies. In poem 1, the addressee is purely a function – an incantatory "एर एर" with no individuality. The Bazoj in poem 2 begins as a function (messenger of hope) but gains textual density through the speaker's intimate instructions, becoming a projected self. The father, though off-stage, is individualized by the biographical note: a king who "got scared," exiled her, broke promises – a historical individual whose actions catalyze the poem. Vaddegnasoh herself, referenced as "पिता की अन्य बेटी," is both a function (the rebellious daughter) and a documented revolutionary. The poems' power lies in this tension: supporting characters are functions that the historical moment forces into individuality. A board-level answer must show this nuance, not a binary yes/no.

DIFFICULTY: hard