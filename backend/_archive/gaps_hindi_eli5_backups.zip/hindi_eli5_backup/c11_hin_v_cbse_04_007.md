## DEFINITION
Secondary themes are the supporting ideas that run alongside the primary theme, enriching the text by exploring specific dimensions such as regional diversity, historical evolution, social function, and the interplay between folk and classical traditions in Indian arts.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student can identify at least three distinct secondary themes in the chapter, trace each theme across multiple art forms (painting, music/dance, sculpture), and explain how they collectively reinforce the primary theme of unity in diversity.

## SCOPE_BOUNDARY
This node covers identification and analysis of secondary themes in "Hkkjrh; dyk,¡" (Indian Arts) including folk-classical continuum, regional variations, art-life-ritual connection, and patronage systems. It does NOT cover primary theme analysis (node 006), literary devices (nodes 008-009), or comprehension questions (node 012).

## WALKTHROUGH
Imagine you're visiting a museum where Madhubani paintings, Bharatanatyam sculptures, and Khajuraho carvings are displayed together. You notice they look different but share something deeper. Start by asking: "What ideas keep appearing across the painting, music, and sculpture sections besides the main message?" Look for recurring patterns: how village art becomes court art, how every region has its own style yet shares common roots, how art serves rituals and daily life. The key insight is that secondary themes are like threads in a fabric - each distinct but together creating the complete picture of Indian artistic heritage.

## DIAGNOSTIC_QUESTION_1
Name any three secondary themes present in the chapter "Hkkjrh; dyk,¡" based on your reading of the text.

## DIAGNOSTIC_ANSWER_1
Correct answer: (1) Folk-to-classical evolution continuum, (2) Regional diversity within cultural unity, (3) Art as expression of rituals and life cycles, (4) Patronage systems (royal/temple/community), (5) Interconnectedness of art forms. A wrong answer listing only one theme or confusing primary theme ("diversity of Indian arts") with secondary themes reveals inability to distinguish hierarchical thematic structure. Students often mistake examples (Madhubani, Bharatanatyam) for themes.

## DIAGNOSTIC_QUESTION_2
Explain in your own words how the "folk-to-classical evolution" theme manifests differently in painting versus sculpture according to the text.

## DIAGNOSTIC_ANSWER_2
Correct answer: In painting, the text describes rock art → folk styles (Madhubani, Warli) → court styles (Mughal, Rajput) → modern revival. In sculpture, it traces Indus Valley → folk traditions (terracotta, tribal) → temple sculpture (Khajuraho, Konark) → classical norms (Shilpa Shastras). A wrong answer giving identical evolution for both or missing the textual evidence (Shilpa Shastras for sculpture, court patronage for painting) shows superficial reading without comparative analysis across art forms.

## DIAGNOSTIC_QUESTION_3
The text states: "लोक कला और शास्त्रीय कला के बीच कभी भी सम्बन्ध टूटने नहीं पाया" (The connection between folk and classical art never broke). Apply this concept to explain why the author mentions both "यक्ष-यक्षिणी" (Yaksha-Yakshini) sculptures and "आदिवासी नृत्य" (tribal dance) in the same chapter.

## DIAGNOSTIC_ANSWER_3
Correct answer: Yaksha-Yakshini represent early classical/folk transition figures that influenced later temple iconography, while tribal dances preserve the living folk tradition that feeds classical forms like Kathakali. Both exemplify the unbroken continuum - classical forms draw vitality from folk roots, folk forms gain recognition through classical frameworks. A wrong answer treating them as separate unrelated examples misses the structural argument about mutual nourishment across time.

## DIAGNOSTIC_QUESTION_4
Compare how "regional diversity" and "cultural unity" function as twin secondary themes. Use specific textual evidence from at least two art forms to show how the text balances these opposing forces.

## DIAGNOSTIC_ANSWER_4
Correct answer: Regional diversity: Madhubani (Bihar), Warli (Maharashtra), Phad (Rajasthan) for painting; Kathak (North), Bharatanatyam (Tamil Nadu), Kathakali (Kerala) for dance; distinct materials/styles in sculpture. Cultural unity: Shared Natyashastra/Shilpa Shastra foundations, common ritual purposes (worship, festivals), similar guru-shishya parampara, shared mythological sources (Ramayana, Mahabharata). A wrong answer listing only diversity examples or only unity factors fails to analyze the dialectic tension the text maintains.

## DIAGNOSTIC_QUESTION_5
Evaluate the author's claim that "आधुनिक काल में ये कलाएँ व्यक्तिगत अभिव्यक्ति का साधन बन गई हैं" (In modern times these arts have become means of individual expression). Does the textual evidence support this as a secondary theme or contradict the chapter's overall thrust?

## DIAGNOSTIC_ANSWER_5
Correct answer: The claim appears only in the concluding paragraph as a contemporary observation, not a developed theme. The chapter's thrust emphasizes collective/community creation (folk arts), ritual function, and guru-shishya tradition - all anti-individualistic. Textual evidence: "लोक कलाओं का सम्बन्ध लोक से है" (folk arts connect to people/community), "सामूहिक रूप से की जाती हैं" (performed collectively). A wrong answer accepting the claim uncritically shows inability to distinguish passing mention from sustained thematic development.

## DIAGNOSTIC_QUESTION_6
Create a thematic map showing how the secondary theme "art-ritual-life connection" branches across the three art forms (painting, music/dance, sculpture) with at least two specific examples per art form from the text.

## DIAGNOSTIC_ANSWER_6
Expected answer: A visual/conceptual map with three main branches:
Painting: (1) Madhubani on wedding walls, (2) Phad scrolls for deity narratives, (3) Warli for harvest rituals.
Music/Dance: (1) Temple dance (Devadasi tradition), (2) Folk dances for festivals (Bihu, Garba), (3) Classical ragas for time/season.
Sculpture: (1) Temple iconography for worship, (2) Terracotta for village deities, (3) Funerary sculptures. A poor answer with generic statements ("used in festivals") without text-specific examples reveals failure to extract concrete evidence from the chapter.

## COMMON_MISCONCEPTION
Students confuse "secondary themes" with "sub-topics" or "examples." They list Madhubani, Kathak, Khajuraho as themes instead of identifying the ideas these examples illustrate (e.g., regional diversity, folk-classical continuum, ritual function). This happens because the text is example-dense and concept-sparse - students latch onto visible proper nouns rather than abstracting the underlying thematic threads the author weaves through those examples.

## ON_FAILURE
Step 1: Give the student a two-column table - Column A: "Examples from Text" (Madhubani, Yaksha, Natyashastra), Column B: "Idea It Illustrates." Step 2: Have them fill Column B for 5 examples. Step 3: Ask them to group Column B entries into 3-4 clusters - these clusters ARE the secondary themes. Step 4: Verify each cluster appears in at least two art form sections. This forces abstraction from example to theme and cross-art-form verification.

## BUILDS_ON
Primary theme identification (node 006) - students must first grasp the central message before detecting supporting themes.

## LEADS_TO
Literary devices analysis (nodes 008-009) - understanding themes enables recognizing how imagery, irony, and symbolism serve thematic development.

## PREREQUISITE_NODE_IDS
c11_hin_v_cbse_04_001, c11_hin_v_cbse_04_002, c11_hin_v_cbse_04_003, c11_hin_v_cbse_04_006, c11_hin_v_cbse_04_005

## PREREQUISITE_REASONS
c11_hin_v_cbse_04_001: Context/background knowledge needed to understand cultural references in thematic analysis
c11_hin_v_cbse_04_002: Plot/narrative structure knowledge helps trace how themes unfold across the chapter's organization
c11_hin_v_cbse_04_003: Setting/atmosphere understanding aids in recognizing how regional/ritual contexts generate themes
c11_hin_v_cbse_04_006: Primary theme must be established first as the anchor for identifying secondary themes
c11_hin_v_cbse_04_005: Secondary themes (regional diversity, tradition-modernity) are carried by specific supporting figures.  

## FORWARD_NODE_IDS
c11_hin_v_cbse_04_008, c11_hin_v_cbse_04_009, c11_hin_v_cbse_04_013, c11_hin_v_cbse_04_014, c11_hin_v_cbse_04_015, c12_hin_a_cbse_01_007, c12_hin_a_cbse_04_007, c12_hin_a_cbse_08_007, c12_hin_a_cbse_10_007

## FORWARD_REASONS
c11_hin_v_cbse_04_008: Imagery and metaphor analysis requires thematic awareness to explain why specific images serve specific themes
c11_hin_v_cbse_04_009: Irony and symbolism interpretation depends on knowing which themes they reinforce or complicate
c11_hin_v_cbse_04_013: Critical thinking/interpretation builds directly on thematic analysis as foundation for higher-order evaluation
c11_hin_v_cbse_04_014: Secondary themes (patronage, ritual, geography) provide the sub-arguments for multi-point answers.  
c11_hin_v_cbse_04_015: Secondary Themes node supplies sub-themes (regional diversity, art-ritual link) for discussion branching.  
c12_hin_a_cbse_01_007: Vitan Chapter 4 linked themes to narrative structure.  
c12_hin_a_cbse_04_007: Class 11 Vitan Chapter 4 secondary themes node reinforces the same analytical skill across a different text type (prose/non-fiction), ensuring transferability.  
c12_hin_a_cbse_08_007: अगला तार्किक चरण: Secondary themes are the underlying, complementary ideas in a literary work that support, contrast w... इस नोड की अवधारणाओं को सीधे उपयोग/विस्तारित करता है।  
c12_hin_a_cbse_10_007: Exposure to linguistic identity in post-colonial Hindi discourse.  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
none

## CHAIN_DESCRIPTION
c11_hin_v_cbse_04_006 -> c11_hin_v_cbse_04_007 -> c11_hin_v_cbse_04_008

## THIS_FORMULA
N/A - conceptual

## FORMULA_VARIABLES
N/A

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
conceptual

## CROSS_SUBJECT
c11_history_medieval_india | The chapter's discussion of Mughal/Rajput painting patronage and temple sculpture evolution directly parallels history syllabus coverage of medieval art patronage systems and regional kingdoms
c11_geography_indian_culture | Regional art forms (Madhubani, Warli, Kathakali) exemplify geography's cultural geography concepts: diffusion, adaptation, and cultural landscapes shaped by physical environment
c11_sociology_indian_society | Folk vs classical art distinction mirrors sociology's great tradition/little tradition framework; community-based creation vs individual authorship reflects social structure concepts

## PREREQ_CONCEPT
Students must understand the difference between a text's central argument (primary theme) and its supporting conceptual threads (secondary themes) before analyzing this chapter.

## PREREQ_BEFORE
Student should have completed reading the full chapter "Hkkjrh; dyk,¡" and identified its primary theme (unity in diversity of Indian arts rooted in life/ritual).

## PREREQ_STUCK
If stuck, review node c11_hin_v_cbse_04_006 (Primary Theme) and re-read the chapter's opening and concluding paragraphs which frame the thematic architecture.

## WORKED_EXAMPLE_1
PROBLEM: Analyze how the secondary theme "patronage and institutional support" operates across the three art forms in the chapter. Provide textual evidence for each.
STEPS:
- Step 1: Scan the text for keywords indicating patronage: "राजा", "मंदिर", "दरबार", "संरक्षण", "आश्रय", "शासक" across all three art form sections
- Step 2: Extract painting evidence: "राजाओं और विभिन्न रियासतों के संरक्षण में", "मुगल दरबार", "राजपूत शैली", "जयपुर, जोधपुर, बीकानेर" as court centers
- Step 3: Extract music/dance evidence: "मंदिरों में नृत्य", "देवदासी परंपरा", "राजदरबारों में संगीत", "तानसेन", "बैजू बावरा" as court musicians
- Step 4: Extract sculpture evidence: "मंदिर स्थापत्य", "खजुराहो, कोणार्क", "शिल्पशास्त्र", "शिल्पियों की परंपरा" as temple-guided creation
- Step 5: Synthesize: All three show shift from community/ritual patronage (folk) → institutional patronage (temple/court) → modern state/academy patronage, but sculpture remains most tied to religious institutions
REASONING: This step-by-step scanning across art forms prevents cherry-picking and reveals the comparative dimension essential for secondary theme analysis at Class 11 level.
ANSWER: The patronage theme operates as a triple continuum: Painting shows clearest court patronage evolution (Mughal → Rajput → Company style); Music/Dance shows dual temple-court patronage (Devadasi → Darbar); Sculpture shows strongest temple institutional control (Shilpa Shastras governing form). All three face modern disruption of traditional patronage.

## WORKED_EXAMPLE_2
PROBLEM: The chapter mentions "शिल्पशास्त्र" (Shilpa Shastra) for sculpture and "नाट्यशास्त्र" (Natyashastra) for dance. Analyze how the "codification vs living tradition" tension functions as a secondary theme.
STEPS:
- Step 1: Locate all references to textual codification: "शिल्पशास्त्र", "नाट्यशास्त्र", "भरत मुनि", "नियम", "सूत्र", "लक्षण" in sculpture and dance sections
- Step 2: Locate all references to living/oral tradition: "गुरु-शिष्य परंपरा", "मौखिक", "लोक में प्रचलित", "पीढ़ी दर पीढ़ी", "अनुभव" in all three art forms
- Step 3: Compare sculpture: Shilpa Shastras provide fixed iconometry (तालमान) but text notes "लोक शिल्प" operates outside them - tension between canonical and folk sculpture
- Step 4: Compare dance: Natyashastra provides मागि (classical) framework but देशी (regional) styles like Kathakali, Manipuri maintain distinct identities - text shows coexistence
- Step 5: Compare painting: No single canonical text cited; instead "चित्रसूत्र" mentioned but folk painting (Madhubani, Warli) thrives without textual authority - weakest codification
- Step 6: Conclude: The theme reveals a spectrum - sculpture most codified, dance moderately codified with strong regional variants, painting least codified - yet all maintain folk-classical dialogue
REASONING: This comparative analysis across art forms using textual evidence demonstrates the analytical depth expected in board exams for theme tracing.
ANSWER: Codification vs living tradition operates as a gradient secondary theme: Sculpture (high codification via Shilpa Shastras, but folk terracotta/tribal sculpture persists), Dance (Natyashastra provides framework but Desi styles flourish), Painting (minimal textual authority, maximum folk vitality). The text celebrates this tension as creative friction, not contradiction.

## WORKED_EXAMPLE_3
PROBLEM: Trace the secondary theme "gender and artistic practice" across the chapter. The text mentions Devadasis, female folk painters, and temple sculptors. Analyze how gender roles in art production differ across the three forms.
STEPS:
- Step 1: Identify all gendered references: "देवदासी" (dance), "महिलाएँ भित्तिचित्र बनाती हैं" (Madhubani/Warli painting), "शिल्पी" (sculpture - implicitly male), "स्त्रियाँ लोक नृत्य करती हैं" (folk dance)
- Step 2: Analyze painting: Explicit female agency - "महिलाएँ अपनी दीवारों पर चित्र बनाती हैं", "मधुबनी में महिलाओं की कला", ritual painting as women's domain
- Step 3: Analyze dance: Dual track - Devadasis (temple women with ritual status) vs court dancers (often stigmatized) vs folk dance (community participation, gender-segregated forms like Garba women, Bhangra men)
- Step 4: Analyze sculpture: Text uses "शिल्पी" (masculine), "कारीगर" - no mention of female sculptors; temple building as male guild activity; contrast with women making terracotta figurines for domestic rituals
- Step 5: Synthesize pattern: Painting = women as primary creators (domestic/ritual space); Dance = women as performers but controlled by patriarchal institutions (temple/court); Sculpture = men as creators (public/monumental space), women in auxiliary roles (terracotta)
- Step 6: Connect to primary theme: This gendered division reflects broader "unity in diversity" - different art forms negotiate gender differently within shared cultural framework
REASONING: This worked example models the multi-step comparative thematic analysis required for competency questions - tracking one theme across three art forms with textual evidence and structural synthesis.
ANSWER: Gender operates distinctly per art form: Painting empowers women as ritual creators in domestic space (Madhubani, Warli, Sanjhi); Dance positions women as sacred performers (Devadasi) or folk participants but under patriarchal control; Sculpture marginalizes women from monumental creation (male guilds/Shilpa Shastras) relegating them to domestic terracotta. The chapter implicitly critiques this through folk examples where women's artistry is central.

## COMPETENCY_QUESTION_1
QUESTION: "The chapter 'Hkkjrh; dyk,¡' presents Indian arts as a conversation between the 'great tradition' (शास्त्रीय) and 'little tradition' (लोक)." Using evidence from at least two art forms, explain how the secondary theme of "folk-classical dialogue" structures the chapter's argument. How does this dialogue differ from a simple hierarchy?
COMPETENCY: Analytical interpretation with textual evidence
STEPS:
- Step 1: Define "great tradition" and "little tradition" in context of the chapter (Shilpa Shastra/Natyashastra vs folk practices)
- Step 2: Select painting evidence: Rock art → folk styles → court styles → modern revival showing two-way influence (Mughal miniatures absorbing folk palette, modern artists returning to folk)
- Step 3: Select sculpture evidence: Yaksha-Yakshini (folk deities entering classical iconography) → temple sculpture → contemporary folk terracotta influencing modern sculptors
- Step 4: Explain non-hierarchical nature: Text uses "सम्बन्ध कभी टूटने नहीं पाया" (connection never broke), "लोक कला से शास्त्रीय कला बनी" (classical emerged from folk), "शास्त्रीय कला लोक को प्रभावित करती है" (classical influences folk) - bidirectional
- Step 5: Conclude: Dialogue = mutual nourishment, not top-down imposition
ANSWER: The folk-classical dialogue structures the chapter as a dynamic continuum, not a hierarchy. Painting: Folk Madhubani/Warli styles feed into court painting (Mughal/Rajput absorb folk motifs), while modern artists (Jamini Roy) return to folk simplicity. Sculpture: Tribal Yaksha figures become classical temple guardians; contemporary sculptors (Ramkinkar Baij) draw from Santhal forms. Dance: Natyashastra codifies but Desi styles (Kathakali, Manipuri) retain folk vitality. The text explicitly rejects hierarchy: "लोक कला और शास्त्रीय कला के बीच कभी भी सम्बन्ध टूटने नहीं पाया" - they are interlocutors, not superior/inferior.
DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: A board exam question asks: "Analyze how the author uses the secondary theme of 'ritual-functionality' to argue against viewing Indian arts as merely aesthetic objects." Using all three art forms, construct a 150-word analytical response with textual evidence.
COMPETENCY: Structured analytical writing for board examination
STEPS:
- Step 1: Formulate thesis: Ritual-functionality is the thread proving Indian arts are embedded in life, not detached aesthetics
- Step 2: Painting evidence: "भित्तिचित्र विवाह-उत्सव में", "फड़ देवताओं की कथा कहते हैं", "वार्ली फसल उत्सव में" - art as ritual action
- Step 3: Dance evidence: "मंदिर नृत्य पूजा का अंग", "लोक नृत्य सामाजिक-धार्मिक अनुष्ठान", "शास्त्रीय नृत्य मार्गी-पूजा" - dance as worship
- Step 4: Sculpture evidence: "मंदिर स्थापत्य पूजा के लिए", "प्रतिमा प्राण-प्रतिष्ठा", "ग्राम देवता की मूर्ति" - sculpture as divine embodiment
- Step 5: Synthesize: All three reject "art for art's sake" - beauty serves function; author's phrase "सौन्दर्य बोध ही नहीं, जीवन बोध" (not just aesthetic sense but life sense)
- Step 6: Write concise response integrating evidence
ANSWER: The author deploys ritual-functionality across all three arts to refute aesthetic detachment. Painting: Madhubani walls sanctify weddings; Phad scrolls narrate deities for worship; Warli diagrams invoke harvest gods. Dance: Temple dance (Devadasi) is ritual offering; folk dances (Bihu, Garba) mark agricultural cycles; classical dance retains मागि (worship) origin. Sculpture: Temple icons undergo प्राण-प्रतिष्ठा becoming deities; terracotta horses guard village boundaries; funerary sculptures mediate grief. The text's culminating claim - "ये कलाएँ सौन्दर्य बोध ही नहीं, जीवन बोध हैं" (these arts are not just aesthetic sense but life sense) - synthesizes this evidence. Ritual-functionality proves Indian arts are "कर्म" (action), not "दर्शन" (spectacle) alone.
DIFFICULTY: hard