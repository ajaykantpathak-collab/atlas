## DEFINITION
Literal comprehension questions require answers directly stated in the text, while inferential comprehension questions require students to draw conclusions by combining textual evidence with reasoning, reading between the lines to understand implied meaning, author's intent, or underlying themes.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student can independently distinguish between literal and inferential question types, locate exact textual evidence for literal answers, and construct logical inferences supported by specific textual clues for inferential answers, writing structured responses using the Point-Evidence-Explanation-Link (PEEL) format.

## SCOPE_BOUNDARY
This node covers strategies for answering literal and inferential comprehension questions based on the poems "cukjl" and "fn'kk" by Osankukphat Lag in Class 12 Hindi Antra Chapter 4. It does NOT cover critical analysis, creative writing, or speaking/listening skills (addressed in subsequent nodes).

## WALKTHROUGH
Imagine you're sitting in the CBSE Board exam hall, staring at a comprehension question about the poem "cukjl" asking: "Why does the poet describe the village as 'vkèkk ty esa' (in the lap of nature)?" You panic because the exact phrase "vkèkk ty esa" doesn't appear as an answer in the text. This is where knowing the difference between literal and inferential questions saves you. Start by reading the question carefully: does it ask "What does the text say?" (literal) or "What does the text suggest?" (inferential). For literal questions, scan the poem for keywords and quote directly. For inferential questions, hunt for clues — imagery, repetition, tone, contrast — then connect them logically. The key insight: every inferential answer must be anchored in textual evidence, never pure guesswork. Master this two-step habit — identify question type, then apply the matching strategy — and you'll stop losing marks on "unseen" poetry comprehension.

## DIAGNOSTIC_QUESTION_1
Identify whether the following question is literal or inferential: "कविता 'चुजल' में 'ल्बज ल्क¡>' वाक्यांश का शाब्दिक अर्थ क्या है?"

## DIAGNOSTIC_ANSWER_1
This is a **literal comprehension question** because it asks for the direct, dictionary meaning of a specific phrase ("lbZ lk¡>") used in the poem. The answer can be found by looking up the phrase or understanding its explicit definition in the text's vocabulary section. A wrong answer (classifying it as inferential) reveals the student confuses "meaning of a phrase" with "implied significance" — they think any question about poetic language requires interpretation, not realizing some questions only test vocabulary recall.

## DIAGNOSTIC_QUESTION_2
Explain in your own words why the poet repeats "èkhjs&èkhjs" (step by step) multiple times in the poem "cukjl". What does this repetition suggest about the village life?

## DIAGNOSTIC_ANSWER_2
The repetition of "èkhjs&èkhjs" is an **inferential question** because the poem never explicitly states "repetition suggests monotony." The student must infer from the accumulating images (people walking step by step, children playing step by step, evenings falling step by step) that village life follows a slow, cyclical, unchanging rhythm. A wrong answer (quoting the lines without explaining the effect) shows the student treats inference as quotation — they locate the words but miss the analytical leap: repetition as a device to convey timelessness and lack of dramatic change.

## DIAGNOSTIC_QUESTION_3
APPLY the PEEL structure to answer this inferential question: "कविता 'फँक' में कवि 'वकèkk' (nature) को 'वकèkk ugha' (not nature) क्यों कहता है? पाठ्य साक्ष्य देकर समझाइए।"

## DIAGNOSTIC_ANSWER_3
**Step 1 (Point):** The poet calls nature "not nature" to challenge the reader's superficial perception of the natural world.  
**Step 2 (Evidence):** In stanza 2, the lines "tks gS og [kM+k gS fcuk fdlh LraHk osQ / tks ugha gS mls Fkkes gS" contrast what appears solid ("[kM+k") with what is absent but felt ("Fkkes").  
**Step 3 (Explanation):** The paradox "vkèkk gS / vkèkk ugha gS" forces the reader to look beyond physical forms (trees, rivers) to the invisible life-force ("vkèkk 'ko esa", "vkèkk uhan esa") that sustains them.  
**Step 4 (Link):** This reflects the poem's central theme: true nature is not the visible landscape but the unseen vitality ("vkneh osQ mBs gq, gkFkksa") that modern humans ignore.  
A wrong answer (merely listing the lines without the paradox explanation) reveals the student cannot move from evidence to interpretation — they treat PEEL as a checklist, not a reasoning chain.

## DIAGNOSTIC_QUESTION_4
ANALYZE the difference in answering strategy between these two questions from the same poem "fn'kk":
(a) "बच्चे ने 'मेकज-मेकज' क्यों कहा?"  
(b) "बच्चे के 'मेकज-मेकज' कहने से कवि को कौन-सा अहसास होता है?"  
Explain how the textual evidence required differs for each.

## DIAGNOSTIC_ANSWER_4
**Question (a) is literal**: The answer is explicitly in the text — "ftèkj mldh iarx Hkkxh tk jgh Fkh" (because his wings were being clipped). Evidence = direct quote of the child's stated reason.  
**Question (b) is inferential**: The poet's feeling ("Lohdkj" — wonder/astonishment) is stated, but *why* he feels it requires inference: the child's innocent acceptance of death ("eSa Lohdkj d:¡") contrasts with adult fear, revealing life's fragility. Evidence = the child's words ("eSa Lohdkj d:¡") + poet's reaction ("eSaus igyh ckj tkuk fgeky; fdèkj gS!") + the irony of a dying child teaching the poet about death.  
A wrong answer (giving the same evidence for both) shows the student cannot distinguish "what happened" from "what it means to the narrator" — they conflate plot detail with emotional impact.

## DIAGNOSTIC_QUESTION_5
EVALUATE this student's answer to an inferential question:  
**Question:** "कविता 'चुजल' में 'वकèkk' (nature) की कौन-सी छवि उभरती है?"  
**Student's Answer:** "कविता में प्रकृति सुंदर और शांत दिखाई देती है क्योंकि कवि ने 'ल्बज ल्क¡>', 'वपुकव [कkyhiu' जैसे शब्दों का प्रयोग किया है।"  
Is this answer sufficient for a 3-mark CBSE board question? Justify your evaluation.

## DIAGNOSTIC_ANSWER_5
**No, this answer is insufficient for 3 marks.** It identifies *positive* imagery ("lbZ lk¡>", "fupkV [kkyhiu") but ignores the poem's **dual portrayal** of nature: beauty ("vkèkk ty esa") AND harshness ("vkèkk 'ka[k esa", "vkèkk mBs gq, gkFkksa"). A 3-mark answer must: (1) acknowledge both aspects, (2) cite evidence for each (e.g., "vkèkk iwQy esa" for nurturing, "vkneh osQ mBs gq, gkFkksa" for raw power), and (3) explain the *significance* — nature as a complete, indifferent reality, not just a pretty backdrop. The student's answer reflects a common error: **cherry-picking evidence that supports a simplistic "nature is beautiful" reading**, missing the poem's philosophical depth. This costs marks because CBSE marking schemes reward nuanced, textually comprehensive responses.

## DIAGNOSTIC_QUESTION_6
CREATE a new inferential question based on the last stanza of "fn'kk" ("eSaus igyh ckj tkuk fgeky; fdèkj gS!") that requires the examinee to connect the poet's realization to the poem's central theme. Provide the ideal answer outline.

## DIAGNOSTIC_ANSWER_6
**Created Question:** "कविता 'फँक' की अंतिम पंक्ति 'eSaus igyh ckj tkuk fgeky; fdèkj gS!' में कवि के 'पहली बार' जानने का क्या अभिप्राय है? यह अहसास कविता के केंद्रीय विषय से कैसे जुड़ता है?"  
**Ideal Answer Outline:**  
1. **Point:** "First time" signifies the poet's awakening to mortality through a child's innocent acceptance, contrasting adult denial of death.  
2. **Evidence:** Child says "eSa Lohdkj d:¡" (I am not afraid) while the poet, an adult, is shaken ("eSaus igyh ckj tkuk...").  
3. **Explanation:** The child embodies *living in the present* ("fn'kk" = moment), unafraid of the inevitable, while adults intellectualize death. The poet learns *from* the child — role reversal.  
4. **Link to Theme:** Central theme = life's fragility and the wisdom of accepting impermanence ("ge cPpksa ls oqQN&u&oqQN lh[k ldrs gSa"). The "first time" marks the poet's shift from fear to understanding.  
A poor created question (e.g., "What does the poet feel?") would be too vague, testing only recall of "Lohdkj", not the thematic connection. This reveals the student doesn't grasp that inferential questions must target *implicit relationships*, not explicit statements.

## COMMON_MISCONCEPTION
**Misconception:** "Inferential questions have no right answer — any interpretation is correct as long as you write something."  
**Why students make this error:** In Class 10-11, teachers sometimes overemphasize "multiple perspectives" in literature without teaching *textual grounding*. Students then write vague, subjective responses ("I feel the poet is sad") instead of evidence-based inferences ("The poet's use of 'Lohdkj' in contrast to the child's fearlessness suggests astonishment at innate courage"). They confuse *personal opinion* with *textually supported inference*.  
**Concrete example:** For "cukjl", a student writes: "The village seems boring because nothing happens." This is an opinion. The inferential answer: "The repetition of 'èkhjs&èkhjs' across diverse activities (walking, playing, evening falling) suggests a timeless, cyclical rhythm where change is imperceptible — not boredom, but continuity." The latter uses the *poet's own structural choice* as evidence.

## ON_FAILURE
**Remediation Path:**  
1. **Revisit Node c12_hin_a_cbse_04_010 (Vocabulary in Context)** — practice identifying explicit vs. implicit meanings of 5 key phrases from "cukjl" (e.g., "lqxcqxkuk", "fupkV", "n'kk'oesèk"). Write two sentences per phrase: one literal definition, one inferred connotation in the poem.  
2. **Revisit Node c11_hin_ar_cbse_01_012 (Class 11 Comprehension)** — redo 3 inferential questions from any Class 11 poem using the PEEL template: Point → Quote Evidence → Explain Link → Connect to Theme. Get teacher feedback on whether Evidence actually supports Point.  
3. **Re-diagnostic:** Attempt Diagnostic Questions 3 and 4 again after 48 hours. If you still quote without explaining the *inferential leap* (Step 3 in PEEL), schedule a 15-min conference with your teacher to model the "Evidence → Explanation" transition using a think-aloud protocol.

## BUILDS_ON
Builds on Class 11 comprehension skills (literal recall + basic inference) by adding structured answer writing (PEEL), dual-evidence requirements for 3-mark questions, and explicit question-type classification.

## LEADS_TO
Enables Critical Thinking (c12_hin_a_cbse_04_013) where students evaluate multiple interpretations, and Writing Skills (c12_hin_a_cbse_04_014) where they compose full-length analytical answers.

## PREREQUISITE_NODE_IDS
c12_hin_a_cbse_04_010, c12_hin_a_cbse_04_011, c11_hin_ar_cbse_01_012, c11_hin_v_cbse_01_012, c12_hin_a_cbse_04_002, c12_hin_a_cbse_04_008, c12_hin_a_cbse_04_009

## PREREQUISITE_REASONS
c12_hin_a_cbse_04_010: Vocabulary mastery is needed to distinguish literal word meanings from inferred connotations in the poems.
c12_hin_a_cbse_04_011: Understanding grammatical structures (tense, voice, sentence types) helps identify how the poet's language choices create implicit meaning.
c11_hin_ar_cbse_01_012: Class 11 Antra comprehension node established baseline literal/inferential distinction; this node deepens it with board-exam answer structures.
c11_hin_v_cbse_01_012: Class 11 Vitan comprehension node provided practice with prose inference; this node transfers those skills to poetry.
c12_hin_a_cbse_04_002: Comprehension questions (literal/inferential) require identifying *where* in the narrative arc information appears — e.g., "When does the reader learn the father is dead?" = structural inference.  
c12_hin_a_cbse_04_008: Comprehension questions ask "How does the poet convey X?" — answer = imagery/metaphor analysis.  
c12_hin_a_cbse_04_009: Comprehension questions (literal/inferential) require spotting irony to answer "what is implied but not stated."  

## FORWARD_NODE_IDS
c12_hin_a_cbse_04_013, c12_hin_a_cbse_04_014
## FORWARD_REASONS
c12_hin_a_cbse_04_013: Literal/inferential comprehension provides the textual evidence base required for critical analysis and interpretation of themes, devices, and authorial intent.
c12_hin_a_cbse_04_014: Structured PEEL responses mastered here become the paragraph building blocks for longer writing tasks (analytical essays, character sketches) based on the chapter.

## CROSS_SUBJECT_PREREQS
c12_hist_cbse_02_005

## CROSS_SUBJECT_REASONS
c12_eng_core_cbse_01_012: English Core's "Reading Comprehension" node teaches identical literal/inferential classification and evidence-based answering — skills transfer directly across languages.
c12_hist_cbse_02_005: History's "Interpreting Sources" node requires distinguishing explicit statements in primary sources from historian's inferences — same analytical framework applied to historical texts.

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_01_012 -> c12_hin_a_cbse_04_012 -> c12_hin_a_cbse_04_013

## THIS_FORMULA
PEEL Answer Structure for Inferential Questions:  
**P**oint (Inference statement) → **E**vidence (Direct quote/paraphrase with line/stanza ref) → **E**xplanation (How evidence proves point — the inferential leap) → **L**ink (Connect to theme/author's purpose/broader context)

## FORMULA_VARIABLES
P = Inference claim (one clear sentence answering the question)  
E = Textual evidence (exact words from poem with location)  
E = Analytical reasoning (why this evidence supports the claim)  
L = Thematic connection (how this inference relates to central idea)

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
linguistic

## CROSS_SUBJECT
N/A | Both Hindi and English Core board exams use identical comprehension assessment objects: literal retrieval (1 mark) and inferential reasoning (2-3 marks) with evidence citation. The PEEL structure is explicitly taught in English and directly applicable to Hindi answers.
c12_hist_cbse_02_005 | History source-based questions require students to distinguish "what the source explicitly says" (literal) from "what the source implies about the period" (inferential). The same evidence→explanation→significance chain is used in 8-mark history answers.
## PREREQ_CONCEPT
Ability to locate explicit information in a poetic text and differentiate it from implied meaning — developed through Class 11 poetry comprehension practice.

## PREREQ_BEFORE
Student must be able to: (1) identify stanza/line references in "cukjl" and "fn'kk", (2) define 10+ key vocabulary terms from the poems, (3) state the central theme of each poem in one sentence.

## PREREQ_STUCK
If stuck on inference, return to the poem's imagery clusters (e.g., all "vkèkk" references in "fn'kk") and ask: "What contrast or pattern does the poet create here?" — patterns drive inference.

## WORKED_EXAMPLE_1
PROBLEM: Answer this 3-mark CBSE board question on "cukjl": "कविता में 'वकèkk' (nature) के किन दो विरोधाभासी रूपों का चित्रण हुआ है? उदाहरण सहित समझाइए।"

STEPS:
- Step 1: Classify the question — "किन दो रूपों" asks for explicit textual categories, but "विरोधाभासी" (contradictory) and "उदाहरण सहित समझाइए" requires inferential analysis of how the poet juxtaposes them.
- Step 2: Scan the poem for "vkèkk" references. Identify two clusters: (a) Nurturing/Beautiful: "vkèkk ty esa", "vkèkk ea=k esa", "vkèkk 'ko esa" (Stanza 2) and (b) Raw/Indifferent Power: "vkèkk 'ka[k esa", "vkèkk uhan esa", "vkneh osQ mBs gq, gkFkksa" (Stanza 3).
- Step 3: Select strongest evidence. For (a): "vkèkk ty esa gS / vkèkk ea=k esa" — nature as protective lap, nurturing mother. For (b): "vkèkk 'ka[k esa / vkneh osQ mBs gq, gkFkksa osQ LraHk" — nature as fierce gaze, raw energy of storms.
- Step 4: Construct PEEL for each form. P1: Nature as nurturer. E1: "vkèkk ty esa". E1-exp: "ty" (lap) and "ea=k" (mother) metaphors convey care. L1: Reflects villagers' dependent, harmonious relationship. P2: Nature as untamed force. E2: "vkneh osQ mBs gq, gkFkksa". E2-exp: "mBs gq, gkFkksa" (flaring nostrils) suggests uncontrollable power. L2: Reminds humans of their fragility ("viuh nwljh Vk¡x ls fcyoqQy cs[kcj").
- Step 5: Synthesize into a unified answer showing the duality is intentional — the poet presents nature as complete reality, not romanticized.

REASONING: This question tests the student's ability to handle a "dual-aspect" inferential question — very common in CBSE 3-markers. The steps enforce evidence categorization before writing, preventing the common error of listing random images without structural contrast.

ANSWER:  
कविता 'चुजल' में प्रकृति के दो विरोधाभासी रूप चित्रित हैं:  
1. **पालन-पोषण करने वाली ममतामयी प्रकृति** — "वकèkk ty esa" (प्रकृति गोद में है), "वकèkk ea=k esa" (प्रकृति माँ में है) जैसे रूपकों द्वारा व्यक्त। यह ग्रामीण जीवन की सुरक्षा और आश्रय-भावना दर्शाता है।  
2. **उग्र, निस्संग शक्ति के रूप में प्रकृति** — "वकèkk 'ka[k esa" (प्रकृति भृकुटि में), "वकनेह के म्ब्स गे ग्क्फ्क्का" (आंधी के भभकते नथुनों) के बिंब द्वारा। यह मनुष्य की क्षुद्रता और प्रकृति की अनियंत्रित ऊर्जा का बोध कराता है।  
कवि इस द्वैत को रोमांटिक नहीं करता; दोनों रूप एक साथ सत्य हैं — यही कविता का केंद्रीय दर्शन है।

## WORKED_EXAMPLE_2
PROBLEM: A student writes this answer for a 2-mark inferential question on "fn'kk": "कवि को बच्चे से मृत्यु का ज्ञान पहली बार क्यों हुआ?"  
**Student's Answer:** "क्योंकि बच्चे ने कहा 'eSa Lohdkj d:¡' और कवि डर गया।"  
Improve this answer to earn full 2 marks using PEEL.

STEPS:
- Step 1: Diagnose the weakness — the answer states plot facts (literal) but misses the *inferential core*: why is this "first time" (igyh ckj) significant for an adult poet?
- Step 2: Identify the missing inference — the poet, despite adult experience, learns *acceptance* from a dying child. The contrast: child faces death fearlessly ("Lohdkj"), poet discovers death's true nature ("fgeky; fdèkj") through that fearlessness.
- Step 3: Locate precise evidence for the inference: Child's words "ftèkj mldh iarx Hkkxh tk jgh Fkh" (wings being clipped) + "eSa Lohdkj d:¡" + Poet's realization "eSaus igyh ckj tkuk fgeky; fdèkj gS!".
- Step 4: Build PEEL. P: The poet learns *fearless acceptance* of mortality from the child's innocent equanimity. E: Child says "eSa Lohdkj d:¡" while his "iarx Hkkxh tk jgh" (wings/life fading). E-exp: Adult intellectualizes death; child lives the moment ("fn'kk") without resistance. L: This embodies the theme — "ge cPpksa ls oqQN&u&oqQN lh[k ldrs gSa" (we can learn from children).
- Step 5: Write the polished 2-mark answer within 40 words.

REASONING: Board examiners award 2 marks for: (1) correct inference (1 mark) + (2) relevant textual evidence (1 mark). The student's original answer had evidence but no inference statement. The improved version makes the inference explicit and ties evidence to it.

ANSWER:  
कवि को 'पहली बार' मृत्यु का वास्तविक ज्ञान इसलिए हुआ क्योंकि एक मरता हुआ बच्चा ("ftèkj mldh iarx Hkkxh tk jgh Fkh") निडरता से कहता है "eSa Lohdkj d:¡" — यह वयस्कों के मृत्यु-भय के विपरीत, क्षणजीवी स्वीकृति ("fn'kk") दर्शाता है। कवि समझता है कि मृत्यु अंत नहीं, जीवन की सहज परिणति है ("ge cPpksa ls oqQN&u&oqQN lh[k ldrs gSa")।

## WORKED_EXAMPLE_3
PROBLEM: Combined application — Answer this 4-mark case-based question (CBSE new pattern):  
"Read the extract from 'cukjl':  
'bls vpkud ns[kks / vn~Hkqr gS bldh cukoV / ;g vkèkk ty esa gS / vkèkk ea=k esa / ... / vxj è;ku ls ns[kks / rks ;g vkèkk gS / vkSj vkèkk ugha gS'  
Based on this extract, explain how the poet uses the 'nature is / nature is not' paradox to redefine the human-nature relationship. Support with two distinct textual evidences from the extract."

STEPS:
- Step 1: Parse the case-based format — extract provided, so no need to hunt for lines. Focus on the paradox structure: affirmative stanzas ("vkèkk ty esa", "vkèkk ea=k esa") vs. negative twist ("vkèkk gS / vkSj vkèkk ugha gS").
- Step 2: Identify the redefinition — the poet shifts nature from *object* (ty, ea=k, iwQy, 'ko, uhan, 'ka[ — nouns/locations) to *subject/force* ("vkèkk gS" — nature *is*; "vkèkk ugha gS" — not the static forms). Human role changes from observer ("ns[kks") to participant ("è;ku ls ns[kks" — see with insight).
- Step 3: Select Evidence 1 (Affirmative): "vkèkk ty esa / vkèkk ea=k esa" — nature as nurturing spaces. This reflects traditional human view: nature as resource/refuge.
- Step 4: Select Evidence 2 (Paradox): "tks gS og [kM+k gS fcuk fdlh LraHk osQ / tks ugha gS mls Fkkes gS" — what exists is solid but supportless; what doesn't exist is yearned for. This deconstructs the static view.
- Step 5: Explain the inferential leap — "è;ku ls ns[kks" (see with insight/inner vision) is the key. Ordinary sight sees forms ("[kM+k"); insight sees the formless vitality ("vkèkk"). The relationship transforms from *exploitation* to *communion*.
- Step 6: Structure as two mini-PEELs (one per evidence) + concluding synthesis for 4 marks.

REASONING: Case-based questions (now 20-25% of CBSE Hindi paper) test if students can analyze a given extract without relying on full-text memory. The paradox technique is a favorite in modern Hindi poetry — mastering its decoding here prepares for unseen poems in competitive exams (CUET, etc.).

ANSWER:  
कवि 'वकèkk गस / वकèkk नह गस' विरोधाभास द्वारा मानव-प्रकृति संबंध को **उपभोग से सहभागिता** में पुनर्परिभाषित करता है:  

**साक्ष्य 1 (पारंपरिक दृष्टि):** "वकèkk ty esa / वकèkk ea=k esa" — प्रकृति को 'गोद', 'माँ' जैसे आश्रय-स्थानों तक सीमित करता है। यहाँ मानव ग्रहणकर्ता (receiver) है, प्रकृति साधन।  

**साक्ष्य 2 (विरोधाभासी उद्घाटन):** "जो है वह क्म्क गस फ्कु फ्दलह ल्रहक के / जो नह गस उसे फ्क्केस गस" — दृश्य रूप ("क्म्क") आधारहीन हैं; अदृश्य लालसा ("फ्क्केस") ही सत्य है। "इकु लस नस्क्स" (अंतर्दृष्टि से देखो) कहकर कवि मानव को द्रष्टा से सहभागी बनाता है — प्रकृति अब वस्तु नहीं, चेतन शक्ति ("वकनेह के म्ब्स गे ग्क्फ्क्का") है जिससे संवाद संभव है।  

यह पुनर्परिभाषा ग्रामीण जीवन की 'चुजल' (सरलता) में निहित पारस्परिकता का सूत्र है।

## COMPETENCY_QUESTION_1
QUESTION: A CBSE Sample Paper question asks: "कविता 'फँक' में 'मेकज-मेकज' (meKj-meKj) शब्द की पुनरावृत्ति क्या दर्शाती है? पाठ्य साक्ष्य देकर उत्तर दीजिए।"  
A student answers: "यह शब्द मृत्यु की आहट को दर्शाता है क्योंकि बच्चे के पंख कट रहे हैं।"  
Critique this answer. What competency is being tested? How would you guide the student to improve it?

COMPETENCY
Textual Evidence Integration — ability to link a literary device (repetition) to its specific thematic function using precise textual support, not general plot summary.

STEPS:
- Step 1: Identify the competency gap — the student names the device (repetition) and a theme (death) but treats repetition as mere decoration ("demonstrates") rather than a structural strategy that *creates* meaning.
- Step 2: Locate the exact textual function — "meKj-meKj" appears as the child's vocalization while "iarx Hkkxh tk jgh" (wings/clipping). The repetition mimics the *rhythmic, inevitable* sound of life ebbing — not just "death's approach" but the *child's calm articulation* of it.
- Step 3: Formulate the improved inference — repetition = child's rhythmic acceptance ("meKj-meKj" = steady, unhurried) contrasting with adult panic. Evidence: "meKj-meKj mlus dgk ftèkj mldh iarx Hkkxh tk jgh Fkh" + "eSa Lohdkj d:¡".
- Step 4: Write the model answer showing device→effect→evidence chain.

ANSWER:  
**Critique:** The answer identifies the theme (death) but misses *how* repetition *functions* — it states "what" not "how". 1/2 marks.  
**Improved Answer:** "मेकज-मेकज" की पुनरावृत्ति बच्चे की **मृत्यु को लयबद्ध, सहज स्वीकृति** दर्शाती है, न कि भय। साक्ष्य: "मेकज-मेकज — उसक लए मेकज गस फ्तेकज म्लध इरक्स ह्क्ख त्क जघ" — पुनरावृत्ति पंख कटने की अनवरत प्रक्रिया को ध्वन्यात्मक रूप देती है। साथ ही "eSa Lohdkj d:¡" से स्पष्ट है कि यह ध्वनि प्रतिरोध नहीं, समर्पण की है।  
**Guidance:** Always ask: "What does the repetition *do* rhythmically/emotionally that a single word wouldn't?" — that's the inferential leap.

DIFFICULTY
medium

## COMPETENCY_QUESTION_2
QUESTION: (CUET/Higher-order) Compare the inferential strategy required for these two questions from different poems in the same chapter:  
Q1 (from "cukjl"): "कवि 'चुजल' को 'फेक्ड वक्सुक कुक गस' (a failed human village) क्यों कहता है?"  
Q2 (from "fn'kk"): "कविता के अंत में कवि 'फ्गेकी फ्देकज' (death's messenger) को 'पहली बार' क्यों जान पाता है?"  
Analyze how the *nature of inference* differs — one requires synthesizing scattered imagery, the other a pivotal narrative moment. Write a meta-explanation for a peer.

COMPETENCY
Metacognitive Analysis of Inference Types — ability to categorize inference questions by cognitive demand (synthesizing distributed evidence vs. interpreting a climactic moment) and articulate the distinct reading strategies each requires.

STEPS:
- Step 1: Classify Q1 — "cukjl as failed human village" is a **synthetic inference**. The phrase appears in the prose preface ("cukjl ,d feFkd cu pqdk 'kgj gS"), but the *poem* never uses "feFkd". The student must synthesize: (a) "vkLFkk] J¼k] fojfDr..." list of absences, (b) "gj dk;Z viuh ^jkS* esa gksrk gS" — self-reliant labor, (c) "fo'okl] vk'p;Z] HkfDr" as organic social bonds. Inference = the village *succeeds* as human community precisely by lacking modern "failures" (alienation, hierarchy).
- Step 2: Classify Q2 — "first time knowing death's messenger" is a **moment-based inference**. The climax ("eSaus igyh ckj tkuk fgeky; fdèkj gS!") is a single narrative peak. Inference = the poet's lifelong intellectual distance from death collapses in one child's fearless "Lohdkj". Evidence is concentrated in the final stanza.
- Step 3: Contrast strategies — Q1 needs **horizontal scanning** (collect motifs across stanzas: labor, relationships, absences). Q2 needs **vertical deepening** (zoom into one moment: child's words → poet's reaction → thematic resonance).
- Step 4: Articulate the meta-lesson — "Synthetic inference = build the picture from puzzle pieces. Moment inference = drill into the epicenter. Both need evidence, but the *search pattern* differs."
- Step 5: Provide a peer-friendly tip: "For Q1-type, make a 3-column table: Absence / Presence / Inference. For Q2-type, draw a 3-ring ripple: Event → Reaction → Realization."

ANSWER:  
**Q1 (cukjl) = Synthetic Inference**  
- Strategy: Horizontal evidence gathering across the poem.  
- Key move: The preface calls it "feFkd" (failed) ironically; the poem *shows* it thrives *without* modern markers of success (vkLFkk, J¼k, fojfDr...).  
- Evidence synthesis: No courts → self-governance ("gj dk;Z viuh ^jkS* esa"); no police → trust ("fo'okl] vk'p;Z] HkfDr"); no doctors → nature-healing ("vkèkk ty esa").  
- Inference: "Failed" by urban metrics = "Successful" by human metrics. The poet redefines success.

**Q2 (fn'kk) = Moment-Based Inference**  
- Strategy: Vertical deepening into the final stanza.  
- Key move: "igyh ckj" (first time) marks an epistemic break. The poet, presumably older, learns *from* a dying child.  
- Evidence concentration: Child's "eSa Lohdkj d:¡" + Poet's "eSaus igyh ckj tkuk..." + Theme "ge cPpksa ls oqQN&u&oqQN lh[k ldrs gSa".  
- Inference: Death is not an event to fear but a moment ("fn'kk") to inhabit — the child is the true messenger.

**Meta-Explanation for Peer:**  
"When you see 'why does the poet call X Y?' — hunt for *contradictions* between label and depicted reality (synthetic). When you see 'first time / suddenly / realizes' — zoom into the *turning point* and trace the before/after shift (moment-based). Both are inferential; the map you follow differs."

DIFFICULTY
hard