## DEFINITION
Character analysis of supporting characters in poetry involves examining how the poet portrays secondary figures (such as the beloved, a confidant, or an abstract entity) through direct address, metaphor, imagery, and tone, and how these portrayals serve the poem's central theme and the protagonist's emotional arc.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student can identify the supporting character (Latika) in Kukuan's two poems, cite specific lines and poetic devices that construct her portrayal, explain what these choices reveal about her role in the speaker's devotion, and connect this portrayal to the overarching theme of selfless love.

## SCOPE_BOUNDARY
This node covers the analysis of the beloved (लतिका) as the sole supporting character in the two prescribed poems of Chapter 9. It does not cover the protagonist (the poet-speaker) in detail (addressed in node c12_hin_a_cbse_09_004), nor does it extend to characters from other chapters or prose texts.

## WALKTHROUGH
Imagine you are reading a love letter where the writer never describes the recipient's appearance but constantly compares them to the moon, a cool breeze, and a life-giving river. How would you sketch the recipient's character? In Kukuan's poems, the beloved Latika never speaks; we know her only through the poet's metaphors. Begin by listing every direct address and every simile/metaphor used for her in both poems. Next, group these images: are they mostly about beauty, power, mercy, or distance? Then ask: what does the *choice* of these images tell us about the poet's view of her? Finally, connect this constructed image to the poem's central claim that the verses exist solely for her praise.

## DIAGNOSTIC_QUESTION_1
In the first poem, the poet addresses Latika with the phrase "पकड़ पियु ;स लंसलक्स य्स लतिका द्स" (Pakad piyu ;s lansalaks ys latika ds). What is the literal meaning of this address, and what does it immediately establish about the relationship between speaker and addressee?

## DIAGNOSTIC_ANSWER_1
The phrase means "Hold [my] hand, this is for Latika" or "Catch hold, beloved, these verses are for Latika." It establishes that the poems are explicitly dedicated to her, positioning her as the sole audience and purpose of the poetic act. A wrong answer (e.g., "The poet is asking Latika to hold his hand physically") reveals a literalist reading that misses the metaphorical dedication and the literary convention of offering verses to a patron/muse.

## DIAGNOSTIC_QUESTION_2
The first poem uses the line "द्ग द्ग व्कौ न्छ्य्स एउह्कौ द्स" (dag dag vkau Nchys euHkkou ds) and "क्स्ग क्स्ग ज्क्क्फ्र घ न्सा न्सा लुएकु द्स" (xfg xfg jk[kfr gh nSa nSa lueku ds). Explain in your own words what these paired images (burning/cooling, watching/weighing) suggest about the *effect* Latika has on the speaker, and therefore about her implied character.

## DIAGNOSTIC_ANSWER_2
The paired contrasts (burning vs. cooling the heart; watching vs. weighing the body) suggest Latika simultaneously inflames passion and brings peace, and that the speaker's very existence is measured by her gaze. This portrays her as a powerful, almost divine force who controls the speaker's inner state. A wrong answer that lists the images without synthesizing their combined effect (e.g., "It shows she is hot and cold") misses the *integration* of opposites that defines her characterization as a complete, governing presence.

## DIAGNOSTIC_QUESTION_3
In the second poem, the poet asks: "वुक्द्कुह व्क्ज्ल्ह फुग्क्फ्ज्क्स द्ज्क्स्यस द्स्य्क्स?" (vukdkuh vkjlh fugkfjcks djkSxs dkSyks?) and later says "ओव्क्द ह्क्ज्ह एव्द्र्क च्य्क; व्कि च्क्स्फ्य्ग्स" (owQdHkjh ewdrk cqyk; vki cksfy gS). Apply the concept of *rhetorical question* and *hyperbole* to explain how these lines construct Latika's character as someone whose *silence* and *anger* are both unbearable.

## DIAGNOSTIC_ANSWER_3
The rhetorical question "Who can endure your words/anger?" (implying no one can) elevates her speech to a lethal force. The hyperbole "You fill the cup of anger, I drink it" (owQdHkjh ewdrk cqyk; vki cksfy gS) portrays the speaker willingly consuming her wrath, framing her anger as a sacred offering. Together, they characterize Latika as a sovereign whose every mood is absolute and the speaker as a devotee who accepts both nectar and poison. A wrong answer that treats the rhetorical question as a genuine inquiry ("Maybe someone else can endure it") fails to see the poetic convention of exaggeration for devotional effect.

## DIAGNOSTIC_QUESTION_4
Compare the portrayal of Latika in Poem 1 (where she is addressed as the *recipient* of verses) with Poem 2 (where she is the *source* of anger/words the speaker endures). Analyze how the shift in grammatical agency (she receives vs. she acts) changes her character from a passive muse to an active divine power.

## DIAGNOSTIC_ANSWER_4
In Poem 1, Latika is the grammatical object ("for Latika"), static and receptive; the poet *gives*. In Poem 2, she is the implied subject of "vukdkuh" (your words) and the agent of "owQdHkjh" (filling the cup); she *acts* and the poet *receives*. This shift transforms her from a dedicatee into an active deity who tests the devotee. A wrong answer that says "She is the same in both" ignores the structural reversal of agency that is central to the bhakti tradition's progression from offering to surrender.

## DIAGNOSTIC_QUESTION_5
Evaluate the claim: "Latika in Kukuan's poems is not a real woman but a literary symbol of the Divine Beloved." Defend your position using at least two specific textual strategies (e.g., lack of physical description, use of stock bhakti metaphors, absence of reciprocal dialogue).

## DIAGNOSTIC_ANSWER_5
The claim is strongly supported. Strategy 1: Zero physical description — no eyes, hair, gait — only abstract effects (cooling heart, weighing body). Strategy 2: Stock bhakti metaphors (fire/water, cup of poison, testing devotee) align her with Krishna/Radha or God/devotee tropes, not individual portraiture. Strategy 3: She never speaks; the dialogue is monologic. A wrong answer that insists "She must be real because the poet says she lived in Delhi" confuses biographical context with textual construction; the *text* erases her individuality to elevate her to archetype.

## DIAGNOSTIC_QUESTION_6
Create a four-line stanza (in Hindi or Braj) that *Latika herself might speak* in reply to the poet, maintaining the same metaphorical register (fire/water, cup/gaze) but reversing the power dynamic. Explain your choice of one metaphor.

## DIAGNOSTIC_ANSWER_6
Example stanza: "मेरा ताप तुम्हारी शीतलता, मेरा क्रोध तुम्हारा अमृत / तुम जो पीते हो विष सदा, मैं हूँ तुम्हारी ही छाया।" (My heat is your coolness, my anger your nectar / You who always drink poison, I am your own shadow.) The metaphor "I am your shadow" reverses the gaze: she exists only as his projection, yet claims ownership of the dynamic. A poor answer would write a modern, colloquial reply ("Okay, thanks for the poems") breaking the register and missing the analytical requirement to sustain the poem's symbolic logic.

## COMMON_MISCONCEPTION
Students often treat Latika as a *historical person* with a recoverable biography (e.g., "She was a courtesan," "She was his wife") and write answers speculating about her real-life personality. This error stems from reading the biographical note in the textbook ("लतिका नाम की एक लेखिका से...") as the key to the poem, rather than recognizing that the *text* deliberately strips her of history, voice, and agency to make her a pure symbol of the Divine Beloved. The exam rewards analysis of the *literary construct*, not biographical guesswork.

## ON_FAILURE
If a student persists in biographical speculation, assign this 3-step remediation: (1) Re-read the two poems and highlight every adjective/metaphor applied to Latika; note that *N/A* describe her physical or social self. (2) Compare with the Class 11 node c11_hin_ar_cbse_09_005 (Character Analysis: Supporting Characters) where a similar distinction between "character in a story" and "addressee in a lyric" was made. (3) Write a 100-word answer to: "Why does the poet *choose* not to describe Latika's appearance?" — forcing focus on poetic strategy.

## BUILDS_ON
This node builds on the protagonist analysis (c12_hin_a_cbse_09_004) where the speaker's voice and devotion were established; the supporting character's portrayal is the mirror image of that devotion.

## LEADS_TO
This node enables the theme nodes (c12_hin_a_cbse_09_006, c12_hin_a_cbse_09_007) because the central theme of *nirgun bhakti* / *prem marg* is enacted precisely through the construction of the beloved as an absolute, formless ideal.

## PREREQUISITE_NODE_IDS
c12_hin_a_cbse_09_004, c12_hin_a_cbse_09_002, c12_hin_a_cbse_09_003, c11_hin_ar_cbse_09_005
## PREREQUISITE_REASONS
c12_hin_a_cbse_09_004: The protagonist's (poet's) character must be understood first, as the supporting character is defined entirely in relation to him.
c12_hin_a_cbse_09_002: Narrative structure (here, the two-poem sequence) shows the shift in agency that shapes Latika's portrayal.
c12_hin_a_cbse_09_003: Setting/atmosphere (the devotional space of Braj bhakti) provides the cultural codes for interpreting the metaphors.
c11_hin_ar_cbse_09_005: Class 11 introduced the distinction between narrative characters and lyric addressees; this node deepens that concept.

## FORWARD_NODE_IDS
c12_hin_a_cbse_09_006, c12_hin_a_cbse_09_007, c12_hin_a_cbse_09_008, c12_hin_a_cbse_09_009, c12_hin_a_cbse_09_013, c12_hin_a_cbse_09_015

## FORWARD_REASONS
c12_hin_a_cbse_09_006: The primary theme (devotion as self-surrender) is evidenced by how Latika is constructed.
c12_hin_a_cbse_09_007: Secondary themes (the power of the beloved's anger, the poet's humility) rely on this character analysis.
c12_hin_a_cbse_09_008: Imagery and metaphor are the *tools* used to build Latika's character; analyzing them here prepares for systematic device study.
c12_hin_a_cbse_09_009: Irony (the beloved's anger is nectar) and symbolism (cup, fire, gaze) are rooted in her portrayal.
c12_hin_a_cbse_09_013: Supporting characters (guru Ramanand, implied priest/ritualist) map the relational dynamics poems dramatize.  
c12_hin_a_cbse_09_015: Supporting figure (shishya) — his silence/absence in doha 1 vs. addressed presence in doha 2 — creates dialogic tension.  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
No cross-subject prerequisite nodes are available in the provided prior class data for Hindi Antra.

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_09_005 -> c12_hin_a_cbse_09_005 -> c12_hin_a_cbse_09_006

## THIS_FORMULA
N/A - conceptual

## FORMULA_VARIABLES
N/A

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
analytical

## CROSS_SUBJECT
N/A | The portrayal of Latika as an absolute, formless beloved mirrors the nirgun bhakti tradition where the devotee constructs the Divine through metaphor rather than iconography; analyzing her character teaches the historical skill of reading literature as religious practice.
 N/A | The method of inferring a character's traits solely from another character's speech (the "reflected appraisal" technique) is a core concept in social psychology and literary theory; this node applies it to a pre-modern Hindi text.
## PREREQ_CONCEPT
Understanding that in lyric poetry, a supporting character exists only as a construct of the speaker's language — there is no independent access to their thoughts or actions.

## PREREQ_BEFORE
The student must have read both poems in the chapter, understood the word-meanings (वाक्यार्थ), and completed the protagonist analysis (node c12_hin_a_cbse_09_004).

## PREREQ_STUCK
If stuck, re-read the two poems focusing *only* on lines where "लतिका" or second-person pronouns (तुम, त्वं, तेरे) appear; list them vertically to see the pattern.

## WORKED_EXAMPLE_1
PROBLEM: Analyze how the first poem (दोहा 1) constructs Latika's character through the metaphors of "fire/coolness" and "gazing/weighing" in the lines "द्ग द्ग व्कौ न्छ्य्स एउह्कौ द्स / क्स्ग क्स्ग ज्क्क्फ्र घ न्सा न्सा लुएकु द्स".

STEPS:
- Step 1: Identify the two pairs of contrasting verbs applied to the speaker's heart (हृदय) and body (शरीर) — "द्ग द्ग" (burning) vs. "न्छ्य्स" (cooling), and "क्स्ग क्स्ग" (watching) vs. "न्सा न्सा" (weighing/measuring).
- Step 2: Note the grammatical subject: the poet's heart/body are acted upon; Latika is the implied agent causing these states (her presence burns, her grace cools; her gaze watches, her judgment weighs).
- Step 3: Interpret the metaphors: Fire/coolness = she simultaneously ignites longing and grants peace (the classic viraha/milana duality). Gazing/weighing = she is the constant observer and ultimate evaluator of the devotee's worth.
- Step 4: Synthesize: These paired opposites portray Latika as a *totalizing presence* who encompasses both suffering and relief, scrutiny and validation — attributes of the Divine in bhakti poetry.
- Step 5: Connect to theme: This characterization supports the poem's opening claim that the verses exist *only* for her praise; she is the sole axis of the poet's universe.

REASONING: The poem uses antithetical parallelism (यमक/विरोधाभास) to show that the beloved is not one-dimensional (only kind or only cruel) but the source of *all* existential states for the devotee. This is the hallmark of the *prem marg* characterization.

ANSWER: Latika is portrayed as a sovereign divine force who simultaneously inflicts the pain of separation (fire, watching) and bestows the grace of union (coolness, weighing/acceptance). The poet does not describe her form; he describes her *effects*, making her character synonymous with the devotee's entire spiritual journey.

## WORKED_EXAMPLE_2
PROBLEM: In the second poem, the line "ओव्क्द ह्क्ज्ह एव्द्र्क च्य्क; व्कि च्क्स्फ्य्ग्स" (owQdHkjh ewdrk cqyk; vki cksfy gS) uses the metaphor of a "cup of anger." Analyze how this single metaphor redefines Latika's character from Poem 1.

STEPS:
- Step 1: Translate literally: "You fill the cup of anger, I drink it." Identify the agents: Latika (you) fills; poet (I) drinks.
- Step 2: Recognize the cultural code: In bhakti tradition, the guru/divine offers a "cup of poison" (विष का प्याला) which the disciple drinks as grace (प्रसाद). Anger = poison; drinking = willing acceptance.
- Step 3: Contrast with Poem 1: There, Latika was the *recipient* of verses (passive); here she is the *active bestower* of a trial. The power dynamic shifts from "I offer" to "She tests."
- Step 4: Infer character: Latika is not a passive muse but an active tester of devotion. Her anger is not a flaw but a pedagogical tool — the "cup" is deliberately filled *for* the devotee.
- Step 5: Link to the poem's closing threat: "द्ग्व¡ र्क्स एस्फ्ज;स इक्द्क्ज द्कु [क्क्स्फ्य्ग्स" (dcgw¡ rkS esfj;S iqdkj dku [kksfy gS) — "Someday you will have to answer." This confirms her role as ultimate judge.

REASONING: The metaphor compresses the entire guru-disciple / deity-devotee relationship into one image: the superior's wrath is the inferior's salvation. This is a sophisticated theological characterization achieved through a single domestic image (cup).

ANSWER: The "cup of anger" metaphor transforms Latika from a silent dedicatee (Poem 1) into an active, sovereign deity who *tests* the devotee by offering his own anger as grace. Her character is now defined by *agency* and *pedagogical cruelty* — she constructs the trial that proves the poet's love.

## WORKED_EXAMPLE_3
PROBLEM: Compare the two poems to trace the *development* of Latika's character across the sequence. Write a structured answer (Point-Evidence-Explanation-Link) showing how the poet moves from "offering" to "surrender" through his changing portrayal of her.

STEPS:
- Step 1: Establish the sequence: Poem 1 = dedication (poet → Latika); Poem 2 = dialogue/test (Latika → poet).
- Step 2: Point 1 (Agency shift): In Poem 1, Latika is grammatical object ("लतिका द्स"); in Poem 2, she is implied subject of speech/anger ("वुक्द्कुह", "ओव्क्द ह्क्ज्ह").
- Step 3: Evidence 1: Quote "पकड़ पियु ;स लंसलक्स य्स लतिका द्स" vs. "वुक्द्कुह व्क्ज्ल्ह फुग्क्फ्ज्क्स द्ज्क्स्यस द्स्य्क्स?".
- Step 4: Explanation 1: The shift from dative to ergative/agentive case markers (in Braj syntax) signals her elevation from recipient to ruler.
- Step 5: Point 2 (Metaphor cluster shift): Poem 1 uses elemental metaphors (fire/water, gaze/weight) — cosmic, impersonal. Poem 2 uses domestic/interpersonal metaphors (cup, drinking, answering) — intimate, relational.
- Step 6: Explanation 2: This moves her character from *cosmic force* to *personal deity* who engages in a relationship of demand and response.
- Step 7: Link: The progression mirrors the bhakti path: first *arpan* (offering), then *samarpan* (surrender to the beloved's will). Latika's character *is* the path.

REASONING: A comparative analysis across the two prescribed poems is a standard Board exam requirement (often 5-6 marks). The PEEL structure ensures each claim is textually grounded and linked to the chapter's central argument.

ANSWER: Across the two poems, Latika evolves from a passive recipient of the poet's verses (Poem 1: "these verses are for Latika") into an active, sovereign deity who tests the poet through her anger and demands accountability (Poem 2: "you fill the cup of anger, I drink it"). The metaphor shift from cosmic elements (fire/water) to intimate ritual (cup/drinking) marks her transformation from an abstract ideal into a personal divine presence. This character arc *enacts* the poem's central theme: true devotion moves from offering words to surrendering to the beloved's will.

## COMPETENCY_QUESTION_1
QUESTION: The poet uses the phrase "न्सा न्सा लुएकु" (nSa nSa lueku) — "weighing the body repeatedly." Explain how this specific metaphor of *weighing* (rather than, say, "measuring" or "counting") characterizes Latika's judgment. What does it imply about the *nature* of the poet's devotion?

COMPETENCY: Literary Analysis — interpreting the connotative precision of a single metaphor in context.

STEPS:
- Step 1: Define the literal action of "लुएकु" (weighing on a scale) vs. measuring length or counting.
- Step 2: Identify the cultural association: weighing implies a transaction, a market, a standard of value (gold, grain); it is mercantile, exact, and public.
- Step 3: Apply to context: The poet's *body* (his physical existence, his penances) is the commodity being weighed. Latika holds the scales.
- Step 4: Conclude: This characterizes her judgment as *transactional but absolute* — she determines the "weight" (worth) of his devotion. It implies the poet views his devotion as a measurable offering that must meet her standard.

ANSWER: "Weighing" (लुएकु) evokes the merchant's scale — precise, public, and value-determining. By choosing this over "measuring" (length) or "counting" (number), the poet portrays Latika's scrutiny as an assessment of *substance and worth*. Her character becomes the *exacting auditor* of his devotion. This implies the poet's love is not unconditional self-abandonment but a *calculated offering* that seeks validation — a subtle tension between surrender and the desire for recognition.

DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: A critic argues: "Kukuan's Latika is a misogynistic construct — a silent woman who exists only to absorb the male poet's projections of power and desire." Evaluate this claim using *only* the internal evidence of the two poems. Does the text support, contradict, or complicate this reading?

COMPETENCY: Critical Thinking — defending a nuanced textual judgment against an external theoretical framework.

STEPS:
- Step 1: Acknowledge the surface validity: Latika has no voice, no body, no agency independent of the poet's speech.
- Step 2: Counter with textual evidence: In Poem 2, she *does* act — she speaks (वुक्द्कुह), fills the cup (ओव्क्द ह्क्ज्ह), and demands an answer (इक्द्क्ज द्कु [क्क्स्फ्य्ग्स). Her silence in Poem 1 is a *generic convention* of the dedication verse (मंगलाचरण), not gendered silencing.
- Step 3: Contextualize with bhakti tradition: The "beloved" in *prem marg* poetry is often grammatically feminine but theologically the Supreme (male or female). The power dynamic is *devotee-deity*, not *man-woman*.
- Step 4: Synthesize: The claim imposes a modern gender lens on a pre-modern devotional structure where the *speaker* (male poet) adopts the *female* persona of the devotee (नायिका भेद) — so the "silent woman" is actually the *poet himself* in the second poem.
- Step 5: Final judgment: The claim is *reductive*; it mistakes the theological gender of the Divine Beloved for the social gender of a historical woman.

ANSWER: The claim is textually unsupported. Poem 2 grants Latika full agency (speech, anger, judgment), and the bhakti convention casts the *poet* as the feminine devotee (नायिका) yearning for the Divine. The "silent woman" is a misreading of the *dedication verse* genre and the *nayika-bheda* tradition. Latika's character is a theological construct of the Absolute, not a social portrait of a woman.

DIFFICULTY: hard