## DEFINITION
Plot and Narrative Structure refers to the organized sequence of events (plot) and the techniques used to present them (narrative structure) in a literary work. In "फेंकू उल्हनिहु," the plot follows a satirical episode where the narrator's interaction with his cook Phenku exposes colonial-era class hierarchies, while the narrative structure employs first-person retrospective narration, dialogue-driven scenes, and situational irony to critique social pretensions.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student can independently map the story's plot onto a modified Freytag's pyramid (exposition, inciting incident, rising action through dialogue, ironic climax, open-ended resolution) and explain how Yashpal's narrative choices—first-person voice, satirical dialogue, and deliberate pacing—serve the thematic critique of feudal servility.

## SCOPE_BOUNDARY
This node covers plot mapping and narrative technique analysis specific to "फेंकू उल्हनिहु" only. It does NOT cover character sketches (node 004, 005), thematic essays (nodes 006, 007), or literary device identification (nodes 008, 009) in depth—those are separate nodes. It assumes familiarity with basic story elements from Class 10.

## WALKTHROUGH
Imagine you're watching a street play where a servant outwits his master without ever raising his voice—that's the core experience of reading "फेंकू उल्हनिहु." Begin by asking: "What happens in this story, and in what order does the narrator reveal it?" First, isolate the five key scenes: (1) Phenku's introduction making puris, (2) the master's interrogation about his past, (3) the cook's wife's revelation, (4) the colonial officer anecdote, (5) the final philosophical exchange. Next, label each scene's plot function—notice how the "climax" isn't a dramatic event but a quiet realization. Then examine HOW the story is told: first-person narrator, heavy dialogue, gaps in time, and Phenku's monosyllabic responses that carry more weight than the narrator's long questions. The key insight: Yashpal inverts the traditional master-servant narrative by making the "simple" cook the moral center through narrative structure itself.

## DIAGNOSTIC_QUESTION_1
Identify the inciting incident in "फेंकू उल्हनिहु" that sets the narrator's investigation into Phenku's past in motion.

## DIAGNOSTIC_ANSWER_1
The inciting incident is the narrator noticing Phenku's unusual method of making puris—flinging them into the air ("फेंकू उल्हनिहु")—which prompts his curiosity about the cook's origins. A wrong answer (e.g., "the narrator hiring Phenku" or "the colonial officer anecdote") reveals the student confuses backstory with the narrative's present-time trigger, indicating they haven't distinguished between chronological order and narrative order.

## DIAGNOSTIC_QUESTION_2
Explain in your own words why Yashpal chooses first-person narration from the master's perspective rather than Phenku's or a third-person omniscient voice.

## DIAGNOSTIC_ANSWER_2
First-person master-narration creates dramatic irony: the narrator believes he is studying Phenku, but the narrative structure reveals the master's own colonial mindset and class blindness. The reader sees what the narrator cannot. A wrong answer focusing only on "authenticity" or "personal touch" misses the satirical function—the structure itself performs the critique by trapping us in the master's limited perspective.

## DIAGNOSTIC_QUESTION_3
Map the following five events onto a plot diagram (exposition, rising action, climax, falling action, resolution): (A) Narrator learns Phenku's wife calls him "उल्हनिहु", (B) Narrator watches Phenku make puris, (C) Phenku recounts the colonial officer demanding "फेंकू", (D) Narrator reflects on "रखेह की रखेह", (E) Phenku serves puris silently at the end.

## DIAGNOSTIC_ANSWER_3
Correct mapping: B (exposition) → A (inciting incident/rising action) → C (rising action peak) → D (climax: philosophical realization) → E (falling action/resolution: silent service as resistance). A wrong sequence (e.g., placing C before A) shows the student follows chronological logic rather than narrative logic—the colonial anecdote is a flashback positioned for maximum ironic impact, not temporal order.

## DIAGNOSTIC_QUESTION_4
Compare the narrative pacing of the puri-making scene (detailed, sensory) with the colonial officer anecdote (summarized, reported speech). What does this pacing contrast reveal about Yashpal's thematic priorities?

## DIAGNOSTIC_ANSWER_4
The slow, sensory pacing of the puri scene centers Phenku's skilled labor and dignity in the present; the rushed, reported anecdote marginalizes the colonial master's voice, reducing his authority to a ridiculous memory. This structural choice enacts the story's theme: the "servant's" craft outlasts the "master's" power. A student who only notes "one is long, one is short" without linking pacing to power dynamics misses the analytical leap from form to meaning.

## DIAGNOSTIC_QUESTION_5
Evaluate this claim: "The story's open ending—Phenku continuing to serve puris silently—is a narrative failure because it resolves no conflict." Defend or refute using structural evidence.

## DIAGNOSTIC_ANSWER_5
Refute. The open ending IS the resolution: it structurally mirrors the exposition (Phenku making puris) but transformed by the reader's new knowledge. The conflict (narrator's curiosity vs. Phenku's opacity) resolves not through revelation but through the narrator's—and reader's—shifted understanding. A student calling it "incomplete" expects conventional closure (conflict solved, mystery answered) and misses how satirical narratives use structural circularity to imply ongoing resistance.

## DIAGNOSTIC_QUESTION_6
Write a 50-word "missing scene" inserted between the colonial officer anecdote and the final reflection that maintains Yashpal's narrative voice and satirical tone. Use first-person narration and dialogue only.

## DIAGNOSTIC_ANSWER_6
Sample: "मैंने पूछा, 'फिर वह अँग्रेज़ गया कहाँ?' फेंकू ने पूरी हवा में उछाली। 'जहाँ से आया था।' 'और तुम?' 'यहीं।' उसने चटनी का कटोरा बढ़ाया। 'लीजिए, ठंडी न हो जाए।'" A poor answer uses third-person, explains feelings, or resolves the mystery—violating the story's rules: master asks, Phenku deflects, labor continues, dignity intact.

## COMMON_MISCONCEPTION
Students treat "plot" as "what happened in chronological order" and "narrative structure" as "beginning, middle, end." In "फेंकू उल्हनिहु," the colonial officer anecdote (chronologically earliest) appears 2/3 through the narrative as a flashback. Students who reorder events chronologically destroy the irony: the story's power comes from the narrator discovering Phenku's past AFTER we've seen his present dignity. The misconception stems from Class 10 habit of summarizing stories linearly rather than analyzing narrative sequencing as authorial choice.

## ON_FAILURE
If a student cannot separate chronological from narrative order: (1) Give them 5 event cards from the story; ask them to arrange in STORY ORDER (narrative) then CHRONOLOGICAL ORDER side-by-side. (2) For each displacement, ask: "What does the reader know at this narrative moment that they wouldn't if this came earlier/later?" (3) Connect to irony: the colonial anecdote placed late makes the master's past power look absurd against Phenku's present control. (4) Practice with a 3-sentence micro-fiction: write it in narrative order, then reorder chronologically, compare effects.

## BUILDS_ON
Basic understanding of story elements (plot, character, setting) and ability to identify first-person narration from Class 10 Hindi.

## LEADS_TO
Character analysis (nodes 004, 005) where narrative perspective shapes characterization, and theme analysis (nodes 006, 007) where plot structure enacts thematic arguments.

## PREREQUISITE_NODE_IDS
c11_hin_ar_cbse_02_001
## PREREQUISITE_REASONS
c11_hin_ar_cbse_02_001: Provides essential context on Yashpal's satirical style, colonial-era setting, and the concept of "उल्हनिहु" as cultural signifier—without this background, students cannot decode why the narrative structure emphasizes certain details (puri-making, the name) as satirical targets.

## FORWARD_NODE_IDS
c11_hin_ar_cbse_02_003, c11_hin_ar_cbse_02_004, c11_hin_ar_cbse_02_006, c11_hin_ar_cbse_02_005, c11_hin_ar_cbse_02_007, c11_hin_ar_cbse_02_008, c11_hin_ar_cbse_02_009, c11_hin_ar_cbse_02_010, c11_hin_ar_cbse_02_011, c11_hin_ar_cbse_02_012, c11_hin_ar_cbse_02_013, c11_hin_ar_cbse_02_014, c11_hin_ar_cbse_02_015, c12_hin_a_cbse_02_002, c12_hin_a_cbse_03_002, c12_hin_a_cbse_08_002, c12_hin_a_cbse_09_002, c12_hin_a_cbse_17_002, c12_hin_al_cbse_01_002, c12_hin_al_cbse_03_002, c12_hin_ar_cbse_02_002, c12_hin_ar_cbse_14_002

## FORWARD_REASONS
c11_hin_ar_cbse_02_003: Setting analysis requires understanding how the kitchen space structures the narrative's confined, repetitive rhythm. c11_hin_ar_cbse_02_004: Protagonist analysis depends on recognizing how narrative structure (Phenku's silence, narrator's voice) constructs character. c11_hin_ar_cbse_02_006: Primary theme (dignity in servitude) is enacted through plot structure—circular return to puri-making with transformed meaning.
c11_hin_ar_cbse_02_005: Plot structure knowledge required to place each supporting character's interventions in narrative sequence and causal chain  
c11_hin_ar_cbse_02_007: Plot knowledge is needed to locate thematic incidents. c11_hin_ar_cbse_02_004: Protagonist's actions and speech reveal thematic concerns. c11_hin_ar_cbse_02_005: Supporting characters embody competing values that generate secondary themes. c11_hin_ar_cbse_02_006: Primary theme must be established first to distinguish secondary themes from it.  
c11_hin_ar_cbse_02_008: Plot knowledge locates *where* key imagery clusters appear (kitchen vs hospital scenes).  
c11_hin_ar_cbse_02_009: Plot and narrative structure knowledge needed to locate irony/symbolism in correct narrative moments  
c11_hin_ar_cbse_02_010: Plot structure reveals *which* scene a word appears in (climax vs. exposition changes meaning).  
c11_hin_ar_cbse_02_011: Knowledge of plot and narrative structure helps locate the exact scenes from which grammar examples are drawn.  
c11_hin_ar_cbse_02_012: Plot knowledge is essential to locate events and dialogues for literal retrieval and to establish the narrative timeline for inferences.  
c11_hin_ar_cbse_02_013: Plot structure knowledge allows analysis of *why* events are ordered this way (e.g., flashback placement).  
c11_hin_ar_cbse_02_014: Plot knowledge provides the chronological framework to locate evidence accurately in answers.  
c11_hin_ar_cbse_02_015: Plot structure identifies the confrontation beats (arrival, interrogation, teaching scene, departure) that anchor discussion turning points.  
c12_hin_a_cbse_02_002: Reinforces narrative structure concepts with a different text, allowing transfer of skill.  
c12_hin_a_cbse_03_002: Offers a second poem‑based example of narrative structure in Class 11.  
c12_hin_a_cbse_08_002: Reinforces stanza-level progression tracking across multiple poems.  
c12_hin_a_cbse_09_002: Reinforced structural analysis across multiple texts.  
c12_hin_a_cbse_17_002: Reinforces plot analysis with a different text, giving practice in identifying non-linear structures.  
c12_hin_al_cbse_01_002: Class 11 Narrative techniques — covers flashback, foreshadowing, perspective; this node applies them analytically.  
c12_hin_al_cbse_03_002: Covered frame narratives and first-person retrospective narration — the exact mode used by izHkk"k tks'kh.  
c12_hin_ar_cbse_02_002: Established the foundational vocabulary (stanza, narrative voice, temporal shift, emotional arc) and practice with simpler poems; this node deepens that skill.  
c12_hin_ar_cbse_14_002: Reinforces flashback and non-linear narration in "अपनी-अपनी बीमारी".  
c11_hin_ar_cbse_02_004: Supplies the chronological sequence of Feeki Uljhan's appearances and her key interactions (with narrator, clerk, son) which are the raw data for analysis.  
c11_hin_ar_cbse_02_006: The plot structure provides the episodes through which the theme unfolds.  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
none

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_02_001 -> c11_hin_ar_cbse_02_002 -> c11_hin_ar_cbse_02_004

## THIS_FORMULA
Narrative Structure Analysis Framework: (1) Segment narrative into scenes, (2) Label each scene's plot function (exposition/inciting/rising/climax/falling/resolution), (3) Identify narrative devices per scene (POV, dialogue, time manipulation, pacing), (4) Map device → effect → theme for each scene, (5) Synthesize: how does the SEQUENCE of devices build the story's argument?

## FORMULA_VARIABLES
N/A

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
analytical

## CROSS_SUBJECT
c11_history_colonialism | The story's colonial officer anecdote and master-servant dynamic reflect historical power structures of British India; narrative structure critiques this history by centering the "native" servant's perspective.
c11_sociology_social_stratification | The plot enacts class performance: the narrator's interrogation mirrors sociological "gaze" on marginalized groups; Phenku's resistance through silence illustrates everyday resistance theory (James Scott).

## PREREQ_CONCEPT
Ability to distinguish between story events (fabula) and narrative presentation (syuzhet) at a basic level.

## PREREQ_BEFORE
Student must know: what a flashback is, what first-person narration means, and the five parts of a traditional plot diagram.

## PREREQ_STUCK
Review "flashback vs. chronological order" and "first-person narrator reliability" from Class 10 prose chapters (e.g., "बड़े भाई साहब" or "डायरी का एक पन्ना").

## WORKED_EXAMPLE_1
PROBLEM: Analyze how the opening scene (Phenku making puris) functions as exposition AND foreshadowing simultaneously. Use the Narrative Structure Analysis Framework.

STEPS:
- Step 1: Segment the opening—narrator watches Phenku "फेंकू" (fling) puris into the air, catch them, stack them. Sensory details: sound, motion, rhythm. No dialogue yet.
- Step 2: Label plot function—this is exposition: establishes setting (kitchen), protagonist (Phenku), his skill, and the narrator's observational stance.
- Step 3: Identify narrative devices—third-person observation within first-person frame (narrator watching "he"), slow pacing (detailed sensory verbs), zero backstory. The name "फेंकू उल्हनिहु" is withheld.
- Step 4: Map device→effect→theme—Slow pacing + sensory focus = centers Phenku's bodily knowledge. Withheld name = mystery. First-person gaze = power dynamic established. Theme seeded: labor as art, servant as master of craft.
- Step 5: Verify foreshadowing—The puri's circular motion (thrown up, caught) mirrors the story's circular structure. The name "फेंकू" (flinger) foreshadows the colonial anecdote where an Englishman demands "फेंकू" (throw it). The opening enacts what the anecdote recounts.

REASONING: This analysis shows how Yashpal compresss exposition and thematic foreshadowing into one scene through narrative pacing and selective revelation—typical of sophisticated short stories where every structural choice carries semantic weight.

ANSWER: The opening scene is a double-duty exposition: it introduces the "what" (Phenku's puri-making) while structurally encoding the "why" (circular mastery, colonial echo, dignity in repetition) through sensory pacing, withheld information, and the narrator's limited gaze—all before a single word of backstory is spoken.

## WORKED_EXAMPLE_2
PROBLEM: The colonial officer anecdote appears as reported speech within Phenku's dialogue, not as a dramatized flashback. Explain why this narrative choice strengthens the satire.

STEPS:
- Step 1: Locate the anecdote—it occurs mid-story when narrator presses Phenku on his name. Phenku recounts: English officer → demands puris → says "फेंकू" → Phenku complies → officer laughs → name sticks.
- Step 2: Identify the narrative form—reported speech (Phenku telling it), past tense, summarized ("बताया"), no sensory detail, no direct officer dialogue except the single word "फेंकू."
- Step 3: Compare alternative—imagine a dramatized flashback: scene shift, officer's voice, Phenku's fear, kitchen chaos. This would center the OFFICER's experience, give him narrative space.
- Step 4: Analyze actual choice's effect—Reported speech keeps narrative camera on Phenku. The officer exists only as Phenku's memory. The single word "फेंकू" becomes a linguistic artifact, not a living voice. Phenku controls the telling; the master (and reader) receives it passively.
- Step 5: Connect to satire—Satire works by diminishing the powerful. Denying the colonial officer a scene, a voice, a body reduces him to a ridiculous name-giver. The narrative structure enacts: "He named you, but you own the story."

REASONING: Narrative structure isn't just "what happens when"—it's "who gets to speak, for how long, in what form." Yashpal's choice to embed the colonial encounter in Phenku's reported speech is a structural act of decolonization: the master's curiosity becomes the vehicle for the servant's narrative sovereignty.

ANSWER: By rendering the colonial encounter as Phenku's summarized reported speech rather than a dramatized flashback, Yashpal structurally subordinates the colonizer's voice to the colonized's memory. The officer gets one word ("फेंकू"); Phenku gets the narrative frame. This pacing choice—rushing the anecdote, lingering on the present puri-making—satirizes colonial authority by denying it narrative weight.

## WORKED_EXAMPLE_3
PROBLEM: Trace how the story's circular structure (opening and closing with puri-making) transforms the reader's understanding of the final scene. Use the Framework across all 5 steps.

STEPS:
- Step 1: Segment both scenes—Opening: narrator watches, describes, wonders. Closing: narrator reflects ("रखेह की रखेह"), Phenku serves silently, narrator accepts puri.
- Step 2: Label plot functions—Opening = exposition. Closing = falling action/resolution. But note: no new plot event occurs in closing; it's a repeat with shifted consciousness.
- Step 3: Identify narrative devices in closing—First-person reflection (internal monologue), philosophical abstraction ("रखेह की रखेह"), Phenku's silence as dialogue, narrator's acceptance as action. Pacing: slow, contemplative.
- Step 4: Map device→effect→theme for closing—Reflection replaces observation. Silence replaces interrogation. Acceptance replaces curiosity. Theme: understanding comes not from extracting stories but from witnessing labor. The puri is no longer a mystery but a gift.
- Step 5: Synthesize structural argument—The circle is not closure but transformation. Same action (puri-making), same characters, same space—but the narrative structure has moved the reader from OUTSIDE (watching, questioning) to INSIDE (receiving, understanding). The plot resolves not by answering "Who is Phenku?" but by making the question irrelevant.

REASONING: Senior secondary analysis requires showing how narrative structure PERFORMS the theme. Here, circularity isn't a decorative device—it's the argument: dignity isn't revealed through biography but sustained through repeated, skilled labor. The structure forces the reader to experience this shift.

ANSWER: The circular structure transforms the final puri-serving from a routine act into a ceremonial exchange. Where the opening positioned the narrator as investigator and Phenku as specimen, the closing positions the narrator as recipient and Phenku as host. The narrative journey—exposition through interrogation to silent offering—enacts the thematic arc: from colonial curiosity to human recognition. The plot "ends" where it "began," but the narrative structure has inverted the power relation.

## COMPETENCY_QUESTION_1
QUESTION: In "फेंकू उल्हनिहु," the narrator never directly describes Phenku's inner thoughts. Yet the narrative structure conveys Phenku's dignity. Explain how THREE specific structural choices (e.g., scene sequencing, dialogue distribution, pacing, narrative gaps) achieve this effect without interiority.

COMPETENCY: Analyzing how narrative structure conveys characterization without direct access to consciousness.

STEPS:
- Step 1: Identify three structural choices—e.g., (a) Phenku's dialogue is minimal but placed at key turning points, (b) the colonial anecdote is framed as Phenku's memory not narrator's discovery, (c) the circular return to puri-making gives Phenku the first and last narrative action.
- Step 2: For each, explain the structural mechanism—(a) Dialogue distribution: narrator asks 12+ questions; Phenku answers in 1-3 words. The structure forces reader to lean into Phenku's silence. (b) Flashback framing: Phenku controls the colonial story's telling—he chooses what to reveal, when, how. (c) Circular action: Phenku's labor frames the narrative; the narrator's curiosity is the interstitial noise.
- Step 3: Synthesize—These choices create a "negative space" characterization: Phenku's dignity is the shape left after the narrator's invasive structure fails to contain him.
- Step 4: Connect to board exam answer format—Point: Structural choice X. Evidence: Specific scene/device. Explanation: How it positions reader relative to Phenku. Link: Contributes to thematic argument about resistance through endurance.

ANSWER: Three structural choices convey Phenku's dignity without interiority: (1) Asymmetric dialogue—the narrator's voluble curiosity vs. Phenku's monosyllabic control makes silence a form of authority. (2) Embedded flashback—the colonial anecdote arrives as Phenku's reported speech, not narrator's excavation, granting him narrative sovereignty over his own past. (3) Circular action framing—the story opens and closes on Phenku's puri-making, making his skilled labor the narrative constant against which the master's questioning appears transient. Together, these structures construct dignity as structural resistance: Phenku occupies the narrative's fixed points; the narrator merely moves between them.

DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: A Class 11 student writes: "The climax of 'फेंकू उल्हनिहु' is when Phenku tells the story of the English officer because that's the most exciting event." Using plot theory and textual evidence, evaluate this claim and explain what the ACTUAL structural climax is and why it matters for the story's satire.

COMPETENCY: Evaluating plot structure claims using narratological concepts and textual evidence.

STEPS:
- Step 1: Define climax in modern short story vs. traditional Freytag—modern climax is often the moment of maximum thematic revelation/irreversible change, not maximum external action.
- Step 2: Test the student's claim—the officer anecdote IS dramatic but occurs mid-narrative as backstory; it doesn't change the present situation. Phenku already has his name; the narrator already watches him cook.
- Step 3: Identify actual structural climax—the narrator's reflection "रखेह की रखेह... तो क्या हम लड़के-लड़के उचक्कों की तरह लहकते रहेंगे!" This internal realization, triggered by Phenku's wife's words, is the point of no return for the NARRATOR'S understanding.
- Step 4: Explain why this serves satire—the climax shifts from "what happened to Phenku" to "what the narrator understands about himself." The satire targets the master's consciousness, not the servant's history.
- Step 5: Board exam answer structure—State disagreement clearly. Define climax for this genre. Locate actual climax with textual anchor. Explain structural function. Conclude with thematic significance.

ANSWER: The claim confuses dramatic event with structural climax. The officer anecdote is rising action (backstory revelation). The true climax is the narrator's moment of self-recognition: "रखेह की रखेह..."—when Phenku's wife's words expose the narrator's own parasitic existence. This is the structural climax because: (a) it's the narrative's emotional peak, (b) it irreversibly alters the narrator's perspective, (c) it recontextualizes all prior scenes. For the satire, this matters: the target isn't colonialism alone but the native elite's complicity. The climax structure makes the master, not the servant, the object of critique.

DIFFICULTY: hard