## DEFINITION
Vocabulary in Context: Key Words refers to the process of identifying, understanding, and using the specific words and phrases from the chapter's three stories ("ckyd cp x;k", "?kM+h osQ iq”ksZ", "<sys pqu yks") that carry thematic weight, cultural nuance, or unique usage beyond their dictionary definitions, enabling deeper comprehension of the author's intent.

## COGNITIVE_LEVEL
understand

## MASTERY_CRITERIA
The student can independently locate a key word in the text, explain its contextual meaning with textual evidence, and use it correctly in a new sentence that reflects the story's tone and theme.

## SCOPE_BOUNDARY
This node covers only the key vocabulary listed in the NCERT 'kCnkFkZ vkSj fVIi.kh section for Chapter 11 (Antra). It does not cover grammar rules, literary device analysis, comprehension questions, or writing skills — those are addressed in sibling nodes.

## WALKTHROUGH
Imagine you are reading "ckyd cp x;k" and you stumble on the word "dksYgw" — you know it means a vehicle, but why does the author describe it as "cSy ck¡/dj rsy fudkyk tkrk Fkk"? Start by reading the paragraph aloud, noticing the sound and rhythm. Then, underline every unfamiliar word. For each, ask: "What is happening in the story at this exact moment?" Use the surrounding sentences (context clues) to guess the meaning before checking the textbook's glossary. Finally, write one original sentence using the word in a similar emotional context. The key insight: words are not just labels; they are chosen to evoke a specific feeling or cultural picture.

## DIAGNOSTIC_QUESTION_1
List any five key words from the story "ckyd cp x;k" along with their meanings as provided in the textbook's vocabulary section.

## DIAGNOSTIC_ANSWER_1
Correct answer: Any five from the list, e.g., okf"kZdksRlo (lkykuk tylk), uqekb'k (izn'kZuh] fn[kkok), dksYgw (rsy fudkyus dh e'khu ftlesa cSy ck¡/dj rsy fudkyk tkrk Fkk), ;koTtUe (thouHkj), mYykl ([kq'kh] g"kZ), oqQlhZukek (jkt dh vofèk). A wrong answer (e.g., giving dictionary meanings like "dksYgw = car") reveals the student is memorizing isolated definitions instead of the textbook's context-specific glosses, which are tailored to the story's setting.

## DIAGNOSTIC_QUESTION_2
In "ckyd cp x;k", the word "dksYgw" is glossed as "rsy fudkyus dh e'khu ftlesa cSy ck¡/dj rsy fudkyk tkrk Fkk". Explain why the author uses this specific descriptive phrase instead of simply saying "gाड़ी" or "वाहन".

## DIAGNOSTIC_ANSWER_2
The descriptive phrase paints a vivid picture of a slow, creaking, bullock-cart-like vehicle, emphasizing the teacher's poverty, the rural setting, and the hardship of his journey. It creates auditory imagery ("ck¡/dj") and visual imagery ("cSy") that a generic word would miss. A wrong answer that only says "it gives more detail" shows the student understands elaboration but misses the thematic function: the word choice reinforces the story's critique of an education system that neglects its teachers' basic dignity.

## DIAGNOSTIC_QUESTION_3
Use the word "mYykl" (meaning [kq'kh] g"kZ) in a sentence that reflects its exact usage in the scene where the teacher's father reacts to the child's answer.

## DIAGNOSTIC_ANSWER_3
Example sentence: "फिरक का मृदुल स्वर मृदुल मृदुल नहीं, बल्कि मृदुल मृदुल था, मानो वे अपने बेटे की सरलता पर गर्व और आश्चर्य दोनों एक साथ महसूस कर रहे हों।" (The father's voice was not just soft but *mṛdul* — a blend of tenderness and wonder at his son's innocence.) A wrong answer like "His voice was mṛdul because he was happy" treats the word as a simple synonym for "soft", ignoring the layered emotion (pride + surprise + affection) the context demands.

## DIAGNOSTIC_QUESTION_4
In "?kM+h osQ iq”ksZ", the author writes "n`"Vkar" (mnkgj.k) when explaining why he gives the example of the watch. Compare this with the everyday use of "mnkgj.k". How does the author's usage deepen the meaning of "example" in this philosophical context?

## DIAGNOSTIC_ANSWER_4
Everyday "mnkgj.k" is a simple illustration. Here, "n`"Vkar" becomes a metaphorical tool: the watch is not just an example but a *demonstration* of how society reduces time to a commodity. The author uses it to prove that even a child's intuition is corrupted by societal conditioning. A wrong answer that says "both mean the same thing" fails to see that the author elevates a concrete object into a philosophical argument — a shift from "illustration" to "evidence".

## DIAGNOSTIC_QUESTION_5
Which single key word from "<sys pqu yks" do you think best captures the story's central theme? Justify your choice with two textual references.

## DIAGNOSTIC_ANSWER_5
Strong candidate: "tl" (;k dhfrZ). The word appears in the closing couplet: "iRFkj iwts gfj feysa rks rw iwt igkjA blls rks pDdh Hkyh] ihl [kk; lalkjAA" Here "tl" (time/moment) carries the weight of the folk belief that birth-time determines destiny. It connects the astrologer's prophecy, the mother's anxiety, and the ironic twist. A weak answer picking "e^h" (seeds) without linking to the theme of fate vs. free will shows the student cannot distinguish between a recurring noun and a thematic keyword.

## DIAGNOSTIC_QUESTION_6
Write a 50-word continuation of "ckyd cp x;k" where the grown-up child meets the teacher years later. Use at least three key words from the vocabulary list (e.g., ;koTtUe, mYykl, oqQlhZukek) naturally.

## DIAGNOSTIC_ANSWER_6
Criteria: (1) All three words used in correct grammatical form, (2) Tone matches the story's reflective mood, (3) Words carry their contextual nuances (e.g., ;koTtUe implies a life of struggle, not just "life"). A poor answer forces words into a cheerful reunion scene, revealing the student sees vocabulary as decoration rather than as carriers of the story's emotional truth.

## COMMON_MISCONCEPTION
Students treat the vocabulary list as a memorization task: "word = meaning". They miss that words like "oqQlhZukek" (jkt dh vofèk) are *charged* with the author's irony — the teacher holds "power" only in the classroom, not in life. Similarly, "VaVk" (>a>V) in "?kM+h osQ iq”ksZ" is not just "haste"; it is the violent imposition of adult time-consciousness on a child's natural rhythm. The error stems from reading the glossary in isolation, not the story.

## ON_FAILURE
1. Re-read the specific paragraph where the word appears. 2. Cover the glossary; write your own contextual meaning in Hindi. 3. Compare with the textbook glossary — note every difference in nuance. 4. Write two sentences: one using the dictionary meaning, one using the contextual meaning. 5. Discuss the difference with a peer or teacher. 6. Re-attempt Diagnostic Questions 2 and 4.

## BUILDS_ON
Class 11 skill of using context clues to determine word meaning (e.g., c11_hin_ar_cbse_01_010, c11_hin_ar_cbse_02_010, c11_hin_v_cbse_01_010) and identifying tone through diction.

## LEADS_TO
Grammar: Language Usage in the Text (c12_hin_a_cbse_11_011) where these words' syntactic roles are analysed, and Comprehension (c12_hin_a_cbse_11_012) where vocabulary underpins inferential answers.

## PREREQUISITE_NODE_IDS
c12_hin_a_cbse_11_001, c12_hin_a_cbse_11_002, c12_hin_a_cbse_11_003, c11_hin_ar_cbse_01_010, c11_hin_ar_cbse_02_010, c11_hin_v_cbse_01_010, c12_hin_a_cbse_11_009

## PREREQUISITE_REASONS
c12_hin_a_cbse_11_001: Provides background on the author and era, essential for understanding archaic words like "tl". c12_hin_a_cbse_11_002: Plot knowledge lets you locate each word in its narrative moment. c12_hin_a_cbse_11_003: Setting details (rural school, folk culture) explain words like "dksYgw" and "e^h". c11_hin_ar_cbse_01_010: Introduced the strategy of context-clue vocabulary learning. c11_hin_ar_cbse_02_010: Practised distinguishing literal vs. contextual meaning. c11_hin_v_cbse_01_010: Built familiarity with Hindi literary vocabulary in Antra/Vitan.
c12_hin_a_cbse_11_009: Vocabulary like "व्यंग्य", "प्रतीक", "वाक्यवैपरीत्य" must be mastered for precise literary terminology in answers.  
c12_hin_a_cbse_11_002: Plot and Narrative Structure refers to the organized sequence of events (plot) and the del... की समझ आवश्यक है, क्योंकि यह नोड (Vocabulary in Context:) इसी आधार पर आगे बढ़ता है।  
c12_hin_a_cbse_11_003: Setting and Atmosphere refers to the time, place, social context, and emotional mood creat... की समझ आवश्यक है, क्योंकि यह नोड (Vocabulary in Context:) इसी आधार पर आगे बढ़ता है।  
c11_hin_ar_cbse_01_010: Vocabulary in Context is the analytical skill of determining the precise meaning, connotat... की समझ आवश्यक है, क्योंकि यह नोड (Vocabulary in Context:) इसी आधार पर आगे बढ़ता है।  
c11_hin_ar_cbse_02_010: Vocabulary in Context is the skill of determining the precise meaning, connotation, and gr... की समझ आवश्यक है, क्योंकि यह नोड (Vocabulary in Context:) इसी आधार पर आगे बढ़ता है।  
c11_hin_v_cbse_01_010: Vocabulary in context is the skill of determining the precise meaning of words and phrases... की समझ आवश्यक है, क्योंकि यह नोड (Vocabulary in Context:) इसी आधार पर आगे बढ़ता है।  

## FORWARD_NODE_IDS
c12_hin_a_cbse_11_011, c12_hin_a_cbse_11_012, c12_hin_a_cbse_11_013, c12_hin_a_cbse_11_014, c12_hin_a_cbse_11_015
## FORWARD_REASONS
c12_hin_a_cbse_11_011: Grammar analysis requires knowing the exact word forms (e.g., "mYykl" as adjective vs. noun). c12_hin_a_cbse_11_012: Comprehension answers need precise vocabulary to express inferences. c12_hin_a_cbse_11_013: Critical interpretation hinges on author's word choices (e.g., why "n`"Vkar" not "mnkgj.k"). c12_hin_a_cbse_11_014: Writing tasks (character sketch, theme essay) demand thematic vocabulary. c12_hin_a_cbse_11_015: Discussion points require articulate use of key terms.
c12_hin_a_cbse_11_012: Vocabulary clarifies literal meaning of key terms.  
c12_hin_a_cbse_11_013: अगला तार्किक चरण: Critical Thinking: इस नोड की अवधारणाओं को सीधे उपयोग/विस्तारित करता है।  
c12_hin_a_cbse_11_014: अगला तार्किक चरण: Writing Skills based on the chapter refers to the ability to compose structured, evidence-based resp... इस नोड की अवधारणाओं को सीधे उपयोग/विस्तारित करता है।  
c12_hin_a_cbse_11_015: Key vocabulary ensures precise, high‑register Hindi expression.  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
c12_history_time_perception: "?kM+h osQ iq”ksZ" explores how colonial modernity imposed mechanical time (watches) on indigenous cyclical time — a core theme in history of technology/society. c12_sociology_folk_culture: "<sys pqu yks" draws on oral folk traditions (eps±V vkWiQ osful, nqyZHk caèkq) where vocabulary like "tl", "e^h", "csVh" encodes cultural beliefs about destiny and agriculture.

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_01_010 -> c12_hin_a_cbse_11_010 -> c12_hin_a_cbse_11_011

## THIS_FORMULA
N/A - conceptual

## FORMULA_VARIABLES
N/A

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
linguistic

## CROSS_SUBJECT
N/A | The story "?kM+h osQ iq”ksZ" uses vocabulary (n`"Vkar, VaVk, ?kM+hlk”kh) to dramatize the historical shift from organic time to standardized clock-time, a key concept in historiography of modernity.
 N/A | "<sys pqu yks" embeds sociological concepts in words like "e^h" (seeds as cultural capital), "tl" (astrological time), and "csVh" (folk wisdom), illustrating how language preserves indigenous knowledge systems.
## PREREQ_CONCEPT
Ability to distinguish dictionary meaning from contextual meaning using textual evidence.

## PREREQ_BEFORE
Student must have read all three stories at least once and attempted the 'kCnkFkZ vkSj fVIi.kh exercise in the textbook.

## PREREQ_STUCK
If stuck, review the "context clues" strategy from Class 11 (c11_hin_ar_cbse_01_010): look for synonyms, antonyms, examples, and tone indicators in the surrounding sentences.

## WORKED_EXAMPLE_1
PROBLEM: Analyse the word "oqQlhZukek" in the sentence: "baXySaM osQ jktk vkBosa gsujh dh fL=k;ksa osQ uke vkSj is'kokvksa dk oqQlhZukek lquk x;k" (from "ckyd cp x;k").
STEPS:
- Step 1: Locate the sentence in the story — it occurs when the teacher recounts the chaotic history lesson he endured as a student.
- Step 2: Note the textbook glossary meaning: "jkt dh vofèk" (splendour of power).
- Step 3: Examine context: the teacher lists "baXySaM osQ jktk" (British power) and "gsujh" (Queen Victoria) — symbols of imperial authority imposed on a colonised classroom.
- Step 4: Contrast with the teacher's present powerlessness (broken vehicle, unpaid salary). The word "oqQlhZukek" is used ironically: the "splendour" belongs to a dead empire, not to him.
- Step 5: Synthesise: The author chooses this ornate, Sanskritised word to highlight the gap between colonial grandeur and post-colonial neglect of education.
REASONING: Each step moves from textual location to glossary to contextual irony to thematic significance — the full arc of vocabulary-in-context analysis.
ANSWER: "oqQlhZukek" here does not merely mean "grandeur"; it is a bitter reminder that the teacher's only inheritance from the Raj is a hollow ritual of reciting imperial names, while his real life lacks basic dignity.

## WORKED_EXAMPLE_2
PROBLEM: Compare the words "VaVk" (>a>V) and "ladV" (>a>V) — both appear in the glossary for "?kM+h osQ iq”ksZ" with similar meanings. Explain why the author uses both in close proximity.
STEPS:
- Step 1: Find occurrences: "VaVk" in "nwljs ls iwNus dk VaVk D;ksa\" and "ladV" in "fxurh ge tkurs gSa] vad igpkurs gSa] lqb;ksa dh pky Hkh ns[k ldrs gSa] fiQj vk¡[ksa Hkh gSa rks gesa gh u ns[kus nks".
- Step 2: Check glossary: both glossed as ">a>V] ladV" (haste, urgency).
- Step 3: Analyse nuance: "VaVk" (from Sanskrit वेग) suggests a sudden, forceful impulse — the adult's aggressive demand for immediate answers. "ladV" (from Sanskrit लाव) implies a continuous, restless hurry — the modern condition of always rushing, never observing.
- Step 4: Map to characters: The inspector's questioning carries "VaVk" (sharp, authoritative). The general human condition described later carries "ladV" (chronic, societal).
- Step 5: Conclude: The dual usage layers the critique — first a specific pedagogical violence, then a civilisational malaise.
REASONING: Close reading of near-synonyms reveals the author's precision: he uses two words to distinguish between an individual act of oppression and a systemic cultural disease.
ANSWER: "VaVk" = the inspector's abrupt, violent demand for speed; "ladV" = the pervasive, self-inflicted hurry of modern life that makes us blind to children's natural pace.

## WORKED_EXAMPLE_3
PROBLEM: Create a "Vocabulary Theme Map" for "<sys pqu yks" showing how at least six key words cluster around the central theme of "Folk Wisdom vs. Modern Rationality".
STEPS:
- Step 1: List all glossary words for this story: eps±V vkWiQ osful, iks£'k;k, izfrew£r, vdM+ck”k, tl, fe^h osQ Mxys.
- Step 2: Identify the central conflict: the folk tale's logic (choose a seed, accept destiny) vs. the narrator's rational analysis (seeds represent specific professions, outcomes are probabilistic).
- Step 3: Group words: (A) Folk register: eps±V vkWiQ osful (source text), iks£'k;k (protagonist of folk tale), tl (astrological time), fe^h osQ Mxys (folk metaphor for life's choices). (B) Rational register: izfrew£r (identical/copy — scientific classification), vdM+ck”k (egoistic/self-centred — psychological judgement).
- Step 4: Draw connections: "tl" bridges both — folk belief treats it as destiny; narrator treats it as birth-data. "fe^h osQ Mxys" is the folk metaphor that the narrator deconstructs into "e^h" = professions.
- Step 5: Write a 60-word explanation using the map: The vocabulary itself enacts the clash. Words like "iks£'k;k" and "tl" carry the weight of tradition; "izfrew£r" and "vdM+ck”k" impose a modern, analytical lens. The author's genius is letting both registers coexist without resolution.
- Step 6: Verify each word is used with its contextual meaning, not dictionary meaning.
REASONING: This multi-step task forces the student to see vocabulary as a system that structures the story's meaning, not a list of isolated items.
ANSWER: A completed theme map with two clusters, connecting arrows, and a written synthesis showing how diction encodes the theme.

## COMPETENCY_QUESTION_1
QUESTION: In "ckyd cp x;k", the author writes "firk dk ân; mYykl ls Hkj jgk Fks". If "mYykl" were replaced by "प्रेम" (prem) or "स्नेह" (sneh), how would the reader's understanding of the father's emotion change? Explain in 40-50 words.
COMPETENCY: Nuanced vocabulary analysis / authorial choice
STEPS:
- Step 1: Recall the glossary meaning of "mYykl" ([kq'kh] g"kZ — softness, tenderness).
- Step 2: Contrast with "prem" (love, broad) and "sneh" (affection, warm).
- Step 3: Identify the specific moment: father listening to child's innocent answer, eyes moist, voice choked.
- Step 4: Argue that "mYykl" captures a *quiet, almost fragile tenderness mixed with awe* — more precise than the broader "prem" or warmer "sneh".
ANSWER: "मृदुल" conveys a tenderness that is gentle, slightly trembling, and tinged with wonder at the child's purity — a momentary, almost sacred softness. "प्रेम" is too general; "स्नेह" is too warm and steady. The father's emotion here is a hushed, tearful marvel, not just affection.
DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: The word "tl" (;k dhfrZ) appears in the closing couplet of "<sys pqu yks": "iRFkj iwts gfj feysa rks rw iwt igkjA blls rks pDdh Hkyh] ihl [kk; lalkjAA". How does the use of this archaic, poetic word (instead of "समय" or "क्षण") shape the story's final message about destiny? Answer in 60-80 words.
COMPETENCY: Thematic vocabulary interpretation / archaic diction effect
STEPS:
- Step 1: Note "tl" is glossed as ";k dhfrZ" — a poetic/archaic term for time/moment.
- Step 2: Recognise the couplet is in Braj-inflected Khari Boli, evoking folk oral tradition.
- Step 3: Analyse effect: "tl" sounds ritualistic, inevitable, cosmic — aligning with the astrologer's prophecy that birth-time seals fate.
- Step 4: Contrast with "samay" (neutral, modern) or "kshan" (fleeting, philosophical). "tl" carries the weight of *written destiny* (लिखित).
- Step 5: Conclude: The word choice forces the reader to hear the folk voice, not the rational narrator, making the irony land harder — the rationalist narrator is ultimately speaking the folk language of fate.
ANSWER: "तल" (tl) is not merely 'time'; it is the *ordained moment* of birth that folk belief treats as an unchangeable script. By using this archaic, rhythmic word in the closing couplet, the author momentarily surrenders the narrative to the folk worldview: destiny is written in the "tl". Had he used "समय", the rational tone would persist, weakening the story's final twist where the modern narrator himself voices the fatalistic folk wisdom. The word makes the irony visceral.
DIFFICULTY: hard