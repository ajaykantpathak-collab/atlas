## DEFINITION
Language usage in the text refers to the specific grammatical structures, vocabulary choices, syntactic patterns, and stylistic features employed in the expository prose of "Hkkjrh; dyk,¡" to convey information about Indian art forms with precision, cultural authenticity, and academic register.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student must be able to identify and explain at least five distinct grammatical features (e.g., samasa types, karak usage, tense-aspect patterns, technical vocabulary formation, sentence complexity) in the chapter text and demonstrate how each contributes to the expository purpose and cultural register of the passage.

## SCOPE_BOUNDARY
This node covers grammatical analysis of the specific NCERT Vitan Chapter 4 text "Hkkjrh; dyk,¡" including samasa, karak, tense-aspect-mood, technical vocabulary (tat-samaj/deshaj), and syntactic patterns. It does NOT cover general Hindi grammar rules unrelated to this text, creative writing grammar, or poetry-specific devices.

## WALKTHROUGH
Imagine you're reading a museum catalog description of a Madhubani painting — you notice the language feels different from a WhatsApp message or a novel. That's because expository texts about culture use specific grammatical "tools" to sound authoritative yet accessible. Begin by selecting one paragraph from the chapter (e.g., the section on folk painting styles on page 62). Read it aloud and underline every compound word (samasa), case-marked noun (karak), and verb form you recognize. Ask: "Why did the author choose *this* compound instead of two separate words? Why *this* tense?" Connect each finding to how it helps define, classify, or elevate the subject matter. The key insight: grammar here isn't arbitrary — it's the architecture that makes cultural knowledge sound structured and credible.

## DIAGNOSTIC_QUESTION_1
Identify the samasa type in the compound word 'lkfgR;laxhrdyk' (लक्फ्गर्‍लक्ष्र्द्यक) from the shloka cited on page 64 and state its vigraha (विग्रह).

## DIAGNOSTIC_ANSWER_1
The compound 'lkfgR;laxhrdyk' is a **Tatpurusha Samasa (तत्पुरुष समास)** specifically **Shashthi Tatpurusha (षष्ठी तत्पुरुष)**. Vigraha: *lkfgR; ds laxhr dyk* (लक्फ्गर्‍ के लक्फ्गर्‍द्यक). A wrong answer (e.g., calling it Dvandva or Bahuvrihi) reveals the student cannot distinguish possessive/genitive relationships in compounds from coordinative or attributive ones — a critical gap for decoding technical Sanskritized terminology in the text.

## DIAGNOSTIC_QUESTION_2
Explain why the author uses the present habitual tense (*gh gSA*, *feyrs gSa*, *tkrh gSa*) throughout the descriptive sections rather than simple present or past tense.

## DIAGNOSTIC_ANSWER_2
The present habitual (vartaman abhyasa) conveys **timeless, recurring cultural truths** — art forms *continue to exist* and *characteristically behave* in certain ways across generations. Simple present would sound like a momentary observation; past tense would wrongly imply these traditions have ceased. A student who says "it's just the normal tense" misses how tense-aspect encodes the *living continuity* of the traditions described.

## DIAGNOSTIC_QUESTION_3
In the sentence "bu fp=kksa dh fo'ks"krk gS budh fofHkUu çdkj dh 'kSfy;k¡" (page 62), identify the karak of 'bu fp=kksa' and 'fofHkUu çdkj dh 'kSfy;k¡' and justify why the agent (karta) is not marked with 'ne' (ने).

## DIAGNOSTIC_ANSWER_3
'bu fp=kksa' = **Karta (कर्ता)** in nominative (prathamā) because the verb 'gS' (है) is stative/intransitive; 'fofHkUu çdkj dh 'kSfy;k¡' = **Karma (कर्म)** in nominative as the predicate nominative. 'Ne' is absent because the sentence is **equational (copular)**, not transitive — no action is performed *on* an object. A student marking 'bu fp=kksa ne' reveals confusion between transitive action verbs and stative copular structures, a persistent Class 11 error.

## DIAGNOSTIC_QUESTION_4
Compare the syntactic density of the sentence "gekjs ;gk¡ vkxs pydj laxhr dk tks fodkl gqvk bldh tkudkjh cgqr ugha feyrhA" (page 65) with "fp=kdkjh çkphu dky ls gh gekjs thou dk vfHkUu vax jgk gSA" (page 61). Which uses more subordinate clauses and what is the rhetorical effect?

## DIAGNOSTIC_ANSWER_4
The first sentence has **three subordinate clauses** (*gekjs ;gk¡*, *vkxs pydj*, *bldh tkudkjh cgqr ugha feyrh*) creating layered causality — it builds an argument about historical evidence. The second has **one non-finite clause** (*çkphu dky ls gh*) establishing temporal authority. The first's density mimics scholarly reasoning; the second's simplicity asserts foundational fact. A student calling both "complex sentences" misses how clause hierarchy maps to epistemic weight.

## DIAGNOSTIC_QUESTION_5
Evaluate the author's choice to use Sanskritized technical vocabulary (*ukV~;'kkL=k*, *uR;Z*, *vfHku;*, *laLdkjxhr*, *Írqxhr*) alongside regional terms (*jaxksyh*, *dksye*, *ck¡l u`R;*) in the same paragraphs. Is this code-mixing effective for the text's purpose?

## DIAGNOSTIC_ANSWER_5
**Yes, highly effective.** The Sanskritized terms (tat-samaj) provide **pan-Indian conceptual precision** (defining *what* the art *is* structurally), while regional terms (deshaj) provide **ethnographic authenticity** (naming *how* it lives locally). This mirrors the text's central thesis: classical and folk are inseparable layers of one tradition. A student calling it "confusing" or "inconsistent" fails to see register-switching as a deliberate rhetorical strategy enacting the content's unity-in-diversity.

## DIAGNOSTIC_QUESTION_6
Write a 3-sentence expository paragraph in the *exact grammatical register* of the chapter describing a fictional folk art form "Nilgiri Pottery" — use at least two tat-samaj compounds, one present habitual verb, one karak-marked noun phrase, and one non-finite clause.

## DIAGNOSTIC_ANSWER_6
*Sample answer:* "Nilgiri mRik-kala (tat-samaj: मृद् + कला) ukV~;'kkL=k ds fu;eksa ij vikisat gqbZ gS (present habitual). ykds ] fofHkUu çdkj ds lkexzh ;kpkjksa ls (karak: instrumental) cus tkus okyh ;s dyk çkphu parampara dks ifj"Ñr djrh gS (non-finite: ड्ज्र्द्ज)." A poor answer uses colloquial vocabulary (*bana hua hai*), misses habitual aspect (*hai* instead of *gqbZ gS*), or omits non-finite subordination — showing inability to replicate the text's grammatical "voice."

## COMMON_MISCONCEPTION
Students treat "grammar in text" as a **spot-the-device exercise** (e.g., "find 5 samasas") rather than **analyzing functional grammar** — *why this device here, for this meaning, in this register*. For example, they'll correctly identify 'mM+hlk dk vksfM+'kh' as a Tatpurusha but miss that the *Shashthi* case encodes the **institutional lineage** (the *gharana* system) which is the paragraph's central cultural claim. They confuse *identification* with *interpretation*.

## ON_FAILURE
1. **Re-teach functional question:** Give the student ONE sentence from the text. Ask: "What cultural fact is this sentence asserting? Now — which *specific* grammatical choice makes that assertion sound authoritative / timeless / precise?" 2. **Contrast pairs:** Show the original sentence vs. a colloquial rewrite (e.g., *ukV~;'kkL=k* → *mukhya shastra*). Have them list 3 meaning-differences. 3. **Guided reconstruction:** Provide a simplified version of a paragraph; student must "upgrade" it to chapter register by adding samasas, habitual aspect, non-finite clauses — explaining each upgrade's rhetorical work.

## BUILDS_ON
Vocabulary in Context: Key Words (c11_hin_v_cbse_04_010) — students must already recognize the chapter's technical lexicon before analyzing its grammatical behavior.

## LEADS_TO
Comprehension: Literal and Inferential Questions (c11_hin_v_cbse_04_012) — grammatical awareness enables precise evidence-based answers about *how* the text constructs meaning.

## PREREQUISITE_NODE_IDS
c11_hin_v_cbse_04_010, c11_hin_v_cbse_04_002, c11_hin_v_cbse_04_005

## PREREQUISITE_REASONS
c11_hin_v_cbse_04_010: Students need familiarity with the chapter's key technical vocabulary (tat-samaj/deshaj terms) before analyzing how those words function grammatically in compounds, case marking, and register.
c11_hin_v_cbse_04_002: Understanding the plot/narrative structure (expository, not narrative) sets expectations for the grammatical register — students must know this is *informational prose* to analyze its syntax appropriately.
c11_hin_v_cbse_04_005: Language usage varies when describing different supporting communities (Sanskritized vs. dialect terms).  

## FORWARD_NODE_IDS
c11_hin_v_cbse_04_012, c11_hin_v_cbse_04_013, c11_hin_v_cbse_04_014, c12_hin_a_cbse_04_011, c12_hin_a_cbse_09_011, c12_hin_a_cbse_12_011, c12_hin_ar_cbse_10_011

## FORWARD_REASONS
c11_hin_v_cbse_04_012: Grammatical precision (karak, tense, samasa) allows students to extract *exact* literal meaning and trace inferential threads without misreading agency, time, or logical relations.
c11_hin_v_cbse_04_013: Critical interpretation requires seeing how grammatical choices (e.g., habitual aspect = living tradition) enact the text's ideological stance — analysis depends on grammatical evidence.
c11_hin_v_cbse_04_014: Writing tasks (e.g., "explain the guru-shishya parampara in your own words") demand replication of the chapter's expository register — samasa density, formal vocabulary, non-finite subordination.
c12_hin_a_cbse_04_011: अगला तार्किक चरण: This node analyzes the grammatical structures, syntactic patterns, and language usage specific to th... इस नोड की अवधारणाओं को सीधे उपयोग/विस्तारित करता है।  
c12_hin_a_cbse_09_011: Additional *samas* practice — prevents Diagnostic 5 error.  
c12_hin_a_cbse_12_011: Analysis of emphatic particles (hi, bhi, to) in discourse  
c12_hin_ar_cbse_10_011: Vitan Chapter 4 — idiom density in speech representation.  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
none

## CHAIN_DESCRIPTION
c11_hin_v_cbse_04_010 -> c11_hin_v_cbse_04_011 -> c11_hin_v_cbse_04_012

## THIS_FORMULA
N/A - conceptual

## FORMULA_VARIABLES
N/A

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
linguistic

## CROSS_SUBJECT
c11_history_ancient_indian_culture | The chapter's grammatical register (Sanskritized technical terms, habitual aspect for living traditions) mirrors how historical texts describe cultural continuity — e.g., NCERT History "Themes in Indian History" uses identical linguistic strategies to present art/architecture as evolving yet rooted.
c11_sociology_indian_society | The code-mixing of classical (tat-samaj) and folk (deshaj) vocabulary grammatically enacts the sociology concept of "Sanskritization" and "dominant caste culture" vs. "folk culture" — language usage *is* the sociological argument here.

## PREREQ_CONCEPT
Expository prose register — the student must recognize that this text is *informational/descriptive* (not narrative, poetic, or persuasive) because its grammatical patterns (habitual present, nominal density, copular clauses) serve definition and classification, not storytelling.

## PREREQ_BEFORE
Student must be able to distinguish tat-samaj, tadbhava, deshaj, and videshaj vocabulary categories and identify basic samasa types (Tatpurusha, Dvandva, Bahuvrihi, Karmadharaya) from Class 9-10 grammar.

## PREREQ_STUCK
If stuck, review **Class 10 Hindi Bhasha aur Vyakaran: Samasa Vigraha and Karak Prakarana** — specifically Shashthi Tatpurusha for institutional/lineage terms and present habitual (vartaman abhyas) for timeless cultural facts.

## WORKED_EXAMPLE_1
PROBLEM: Analyze the grammatical construction of the sentence "Hkkjr yksd u`R;ksa ls le`¼ jgk gSA" (page 66) — identify all samasas, karak roles, tense-aspect, and explain how each choice supports the sentence's claim about folk dance's rootedness.

STEPS:
- Step 1: Segment the sentence into grammatical units: *Hkkjr* (भारत) + *yksd* (लोक) + *u`R;ksa* (नृत्यों) + *ls* (से) + *le`¼* (अविभाज्य/अभिन्न) + *jgk* (रहता) + *gSA* (है).
- Step 2: Identify samasas: *Hkkjryksd* = **Tatpurusha (Shashthi)** — vigraha: *Hkkjr ds yksd* (भारत के लोक); *u`R;ksa* = plural of *u`R;* (नृत्य) — no samasa here but a tadbhava noun from Sanskrit *nṛtya*.
- Step 3: Map karak roles: *Hkkjryksd u`R;ksa* = **Karma (कर्म)** in **Panchami (पञ्चमी)** via *ls* (से) — source/origin; *le`¼* = **Kriya-visheshan (क्रिया-विशेषण)** predicate adjective; *jgk gSA* = verb complex.
- Step 4: Analyze tense-aspect: *jgk gSA* = **Present Habitual (वर्तमान अभ्यास)** of *jgnA* (रहना) — indicates *permanent, characteristic state*, not temporary location.
- Step 5: Synthesize: The Shashthi Tatpurusha *Hkkjryksd* compactly encodes "folk dances *of* India" as a single classificatory unit; Panchami *ls* marks *origin/source* not instrument; habitual aspect asserts these dances *inherently, timelessly* belong to the land — grammar enacts "rootedness."

REASONING: Each grammatical layer (compound formation → case marking → aspect) adds a semantic brick: classification → spatial relation → temporal permanence. Together they build the sentence's cultural claim without rhetorical flourish.

ANSWER: The sentence uses a Shashthi Tatpurusha compound (*Hkkjryksd*) for taxonomic density, Panchami karak (*ls*) for source-location, and present habitual aspect (*jgk gSA*) for timeless continuity — jointly constructing the meaning "Indian folk dances are *inescapably, permanently* rooted in the land."

## WORKED_EXAMPLE_2
PROBLEM: The text states: "fo}kuksa dk ;g ekuuk gS fd yksd u`R; ls gh 'kkL=kh; u`R; fodflr gqvk gSA" (page 68). Rewrite this sentence in THREE different registers: (a) colloquial spoken Hindi, (b) formal administrative Hindi, (c) the chapter's expository register — then explain the grammatical shifts.

STEPS:
- Step 1: Analyze source sentence grammar: *fo}kuksa dk* (Karta, Shashthi Tatpurusha *fo}kuksa* = विद्वानों का) + *ekuuk* (Karma, nominalized verb) + *gS* (copula) + *yksd u`R; ls gh* (Panchami + emphasis particle) + *'kkL=kh; u`R;* (Karma, Tatpurusha) + *fodflr gqvk gSA* (passive perfective participle + auxiliary).
- Step 2: Colloquial rewrite: "Pandit log maante hain ki classical nritya lok nritya se hi bana hai." — Changes: *fo}kuksa* → *pandit log* (deshaj plural), *ekuuk* → *maante hain* (finite verb + pronoun), *fodflr gqvk* → *bana hai* (causative + perfective), loss of *gh* emphasis.
- Step 3: Administrative rewrite: "Vidvargon ka mat hai ki shastriya nritya ka vikas lok nritya se hua hai." — Changes: *fo}kuksa* → *vidvargan* (tat-samaj collective), *ekuuk* → *mat* (nominalized opinion), *fodflr* → *vikas* (abstract noun), passive → active noun phrase.
- Step 4: Chapter register (original): Retains *fo}kuksa dk ekuuk* (genitive + nominalized cognition), *gh* (restrictive focus particle), *fodflr gqvk* (Sanskritized passive participle *fodflr* + light verb *gqvk*) — high nominal density, zero finite main verb except copula.
- Step 5: Compare: Colloquial uses finite verbs + pronouns (interpersonal); administrative uses abstract nouns + active voice (bureaucratic agency); chapter uses nominalized cognition + passive participle + restrictive focus (epistemic authority + structural explanation).

REASONING: The chapter's register avoids human agents (*pandit log*, *vidvargan*) and instead makes *knowledge itself* the subject (*ekuuk*) — grammar depersonalizes authority into scholarly consensus. The passive participle *fodflr* centers the *art form* as patient of historical development, not the *people* who developed it.

ANSWER: Three rewrites demonstrate how the chapter's grammar (nominalized cognition, restrictive *gh*, Sanskritized passive participle) constructs impersonal, structural authority — unlike colloquial (interpersonal) or administrative (institutional) registers.

## WORKED_EXAMPLE_3
PROBLEM: The paragraph on page 67 ("Hkkjrh; u`R; dks ns•dj dqN yksx ,slk lksprs gSa fd ;g fl-iZQ gkFk vkSj iSj dh xfr ls tqM+k gSA...") contains a complex conditional-concessive structure. Map its full syntactic tree and explain how the grammar manages the counter-argument strategy.

STEPS:
- Step 1: Segment main clauses: (1) *Hkkjrh; u`R; dks ns•dj dqN yksx ,slk lksprs gSa* [Main Clause 1: Concession introduction] (2) *fd ;g fl-iZQ gkFk vkSj iSj dh xfr ls tqM+k gSA* [Subordinate Clause 1: Content of perception] (3) *vxyh ckj vki è;ku ls nsf•,xk Hkkjrh; u`R; esa lHkh vaxksa dh xfr@y; egRoiw.kZ gSA* [Main Clause 2: Counter-assertion with conditional *vxyh ckj*] (4) *Hkkjrh; urZdksa dks vk¡•] HkkSagks ;k fiQj ukfldk osQ ekè;e ls gh •q'kh] nq•] Øks/] ohHkRl vkfn Hkkoksa dks vfHkO;Dr djus esa egkjr gkfly gSA* [Main Clause 3: Evidence] (5) *bu Hkko&Hkafxekvksa osQ tfj;s egkHkkjr vkSj jkek;.k tSlh dFkkvksa rd dks dg nsus dh ijaijk u`R; dyk esa feyrh gSA* [Main Clause 4: Scope expansion].
- Step 2: Identify connective syntax: *dqN yksx ,slk lksprs gSa fd* (reportative frame) → *vxyh ckj* (conditional concessive: "if ever you observe closely") → *gh* (restrictive focus on *ekè;e ls*) → *tfj;s* (demonstrative correlative linking evidence to claim).
- Step 3: Analyze verb forms: *lksprs gSa* (habitual: general scholarly opinion), *gSA* (stative), *nsf•,xk* (perfective conditional: hypothetical close observation), *gSA* (stative), *gkfly gSA* (habitual capability), *feyrh gSA* (habitual occurrence).
- Step 4: Trace argument structure: Concession (some think X) → Conditional Rebuttal (if you look closely, Y is true) → Evidence (primitive expressions cover full emotional range) → Generalization (dance contains epic narratives). Grammar *stages* the persuasion: habitual for consensus, conditional for invitation to verify, habitual capability for structural claim.
- Step 5: Note nominal density in evidence clause: *vk¡•, HkkSagks, ukfldk, •q'kh, nq•, Øks/, ohHkRl* — seven distinct emotion nouns in instrumental/ablative phrases (*osQ ekè;e ls*) creating taxonomic exhaustiveness.
- Step 6: Synthesize: The grammar performs a **rhetorical dance** — opening with reported belief (distancing), inviting empirical verification (conditional), displaying categorical evidence (nominal list), concluding with structural claim (habitual). Each clause type does argumentative work.

REASONING: This isn't just "complex sentences" — it's a **grammatical architecture of persuasion** where clause types (reportative, conditional, evidential, generic) map to argument moves (concede, challenge, prove, generalize). The student who sees only "long sentence" misses the rhetorical choreography.

ANSWER: The paragraph deploys a 5-clause conditional-concessive structure: reportative frame → concessive content → conditional rebuttal → instrumental evidence list → habitual generalization. Grammar stages the counter-argument: *lksprs gSa* (consensus) → *vxyh ckj... nsf•,xk* (invitation to verify) → *gkfly gSA* (structural capacity) → *feyrh gSA* (timeless scope).

## COMPETENCY_QUESTION_1
QUESTION: A Class 11 student writes in an exam answer: "Bharatiya lok kalaon ka vikas shastriya kalaon se hua hai." The teacher marks it as "register mismatch." Using grammatical evidence from Chapter 4, explain WHY this sentence fails the chapter's expository register and rewrite it in the correct register with three specific grammatical upgrades.

COMPETENCY: Register analysis and transformation — applying grammatical knowledge to evaluate and produce discipline-appropriate academic Hindi.

STEPS:
- Step 1: Identify the register mismatches in the student's sentence: (a) *vikas* (abstract noun) replaces *fodflr* (Sanskritized passive participle) — loses "unfolding/evolution" nuance; (b) *shastriya kalaon se* (instrumental) replaces *yksd u`R; ls gh* (source + restrictive focus) — loses "exclusive origin" claim; (c) active causative *hua hai* replaces passive perfective *gqvk gSA* — centers agency over structural process.
- Step 2: Locate chapter models: Page 68 *fo}kuksa dk ;g ekuuk gS fd yksd u`R; ls gh 'kkL=kh; u`R; fodflr gqvk gSA* provides the target pattern.
- Step 3: Apply three upgrades: (1) *vikas* → *fodflr* (passive participle from *fodflr* 'to unfold/develop'); (2) *shastriya kalaon se* → *yksd u`R; ls gh* (source ablative + *gh*); (3) *hua hai* → *gqvk gSA* (perfective participle + copula).
- Step 4: Produce corrected sentence: "Vidvargan ka mat hai ki shastriya kala ka fodflr lok kala ls gh hua hai" — but better: *fo}kuksa dk ekuuk gS fd 'kkL=kh; kala fodflr gqbZ gS yksd kala ls gh.*

REASONING: The chapter's register uses nominalized cognition (*ekuuk*), restrictive focus (*gh*), and passive participle (*fodflr*) to present development as an impersonal, structurally necessary unfolding — not an event caused by agents. The student's sentence sounds like a news report; the chapter sounds like cultural historiography.

ANSWER: The sentence fails because it uses (1) active causative (*hua hai*) instead of passive perfective (*fodflr gqvk*), (2) instrumental (*se*) without restrictive *gh*, (3) tadbhava vocabulary (*vikas*) instead of tat-samaj (*fodflr*). Corrected: *"Vidvargan ka ekuuk gS fd 'kkL=kh; kala fodflr gqbZ gS yksd kala ls gh."* (Three upgrades: nominalized cognition, restrictive source, passive participle.)

DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: The chapter uses the compound *ukV~;'kkL=k* (उपवेद) repeatedly (pages 60, 63, 64, 67). A student claims: "It just means 'sub-Veda' — the author could simply write *upaved* in Devanagari." Using morphological, syntactic, and register evidence from the text, refute this claim and explain what *ukV~;'kkL=k* grammatically *does* that *upaved* cannot.

COMPETENCY: Morphological-semantic analysis — defending the functional necessity of a specific grammatical form in its textual context.

STEPS:
- Step 1: Analyze *ukV~;'kkL=k* morphologically: *ukV~;* (उप् 'sub-/auxiliary') + *'kkL=k* (वेद 'Veda') = **Karmadharaya Samasa** (कर्मधारय समास) where first member qualifies second — "Veda-that-is-subsidiary." *upaved* (उपवेद) is the *same* compound in un-Sandhi'd form — but the text *always* writes it with *Visarga sandhi* (उप् + वेद → उपवेद → *ukV~;'kkL=k* in Devanagari transliteration).
- Step 2: Check textual distribution: Appears 4× — each time as **authoritative categorizer**: *ukV~;'kkL=k esa ^uR;Z* vkSj *^u`R;* (page 66), *ukV~;'kkL=k dk ^ukV~;'kkL=k* (page 64), *budk vk/kj Hkjreqfu dk ^ukV~;'kkL=k* (page 63). Always in **genitive/locative phrases** framing it as *the* classificatory framework.
- Step 3: Test *upaved* substitution: "Upaved mein Nritya aur Natya..." — loses the **orthographic authority** of the *Visarga-marked* form which signals "this is a *technical term* from the *shastric tradition*." The *Visarga* (ः) is a grammatical fossil preserving the *Sandhi* rule *up + ved → upaved* — its visual presence marks the word as *belonging to the Sanskrit grammatical system*.
- Step 4: Syntactic evidence: The text *never* uses *upaved* without *ukV~;* prefix — *ukV~;'kkL=k* functions as a **fixed technical label** (like a proper noun). Writing *upaved* would decouple it from the *shastric metalanguage* the chapter inhabits.
- Step 5: Register argument: The chapter's expository register *is* the grammar of the *shastra* — using *ukV~;'kkL=k* (with Sandhi) performs *insider knowledge*; *upaved* performs *outsider transcription*. For a text arguing that classical art *derives authority from the shastra*, the grammatical form *enacts* the argument.

REASONING: The student confuses *citation form* (dictionary entry *upaved*) with *textual form* (contextual *ukV~;'kkL=k*). In a text whose thesis is "classical art's legitimacy comes from *shastric* codification," the Sandhi-preserving orthography *is* evidence — grammar as epistemology.

ANSWER: *ukV~;'kkL=k* is not interchangeable with *upaved* because: (1) its Visarga-marked orthography preserves the *Sandhi* of the *shastric* metalanguage, signaling technical term status; (2) it occurs only in genitive/locative frames (*ukV~;'kkL=k esa*, *ukV~;'kkL=k dk*) as a fixed classificatory label; (3) replacing it with *upaved* would strip the word of its *insider* grammatical authority — the very authority the chapter argues classical art derives from. The form *performs* the thesis.

DIFFICULTY: hard