## DEFINITION
The primary theme of a literary work is its central, unifying idea or insight about human experience that the author conveys through the narrative, imagery, and structure; the message is the specific moral, philosophical, or emotional conclusion the writer intends the reader to derive from that theme. In "vkvks] feydj cpk,¡", the primary theme is the **transformative acceptance of suffering** — the idea that embracing one's wounds, failures, and pains (rather than resisting them) is the necessary path to authentic healing, depth, and wholeness.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student can independently identify the primary theme of the poem, trace its development across at least three distinct stanzas using specific textual evidence (imagery, metaphors, lexical choices), and articulate the poet's message in their own words with a board-exam-ready structured answer (Point-Evidence-Explanation-Link).

## SCOPE_BOUNDARY
This node covers **only** the identification, analysis, and articulation of the *primary* theme and message of "vkvks] feydj cpk,¡". It does NOT cover secondary themes (node 007), detailed literary device analysis (nodes 008, 009), or comprehension questions (node 012). It assumes familiarity with the poem's literal meaning, narrative voice, and key vocabulary (nodes 001, 002, 010).

## WALKTHROUGH
Imagine you have just failed an important exam or faced a painful rejection — your instinct is to hide the hurt, pretend it doesn't matter, or distract yourself. Now, read the poem's opening invitation: "Come, let us embrace our wounds." The poet treats wounds not as shameful secrets but as honored guests. To find the primary theme, **first** read the poem aloud twice, noticing the refrain "cpk,¡" (embrace) and the list of what must be embraced (thorns, darkness, fatigue, terror, poison, deception). **Second**, mark every image that converts a negative experience into something generative (e.g., "thou ka vD[kM+iu" — the *desire* born from poison). **Third**, ask: "What single idea connects *all* these embraces?" The answer — that wholeness comes only through integrating, not rejecting, our brokenness — is the primary theme. **Fourth**, verify this against the closing stanza: "Even in this ruined settlement, there is much to embrace... still!" The message: **Life's meaning is salvaged precisely in the act of embracing what breaks us.**

## DIAGNOSTIC_QUESTION_1
What is the literal meaning of the refrain "vkvks] feydj cpk,¡" and which two words in the original Hindi establish the central action of the poem?

## DIAGNOSTIC_ANSWER_1
The refrain means "Come, let us embrace (our wounds/pains)" — "vkvks" (come) and "cpk,¡" (let us embrace) are the two key words establishing the central action. A wrong answer (e.g., translating "cpk,¡" as "hide" or "heal") reveals the student is relying on guesswork rather than the vocabulary glossary (vkcks&gok = tyok;q) and has not internalized the poem's core imperative.

## DIAGNOSTIC_QUESTION_2
Explain in your own words why the poet pairs "vD[kM+iu" (intense longing born of poison) and "tq>k:iu" (restlessness/questioning) with "Hkksykiu" (jealousy/envy) as things to be embraced. What does this pairing suggest about the poet's view of 'negative' emotions?

## DIAGNOSTIC_ANSWER_2
The poet groups jealousy (traditionally seen as petty) with profound longing and existential questioning to argue that *no* emotion is inherently wasteful — each carries energy that, when acknowledged, fuels growth. A wrong answer (e.g., "jealousy is bad so we must overcome it") reveals the moralistic misconception that the poem rejects: the poet does not ask us to *overcome* these emotions but to *embrace* them as part of the human fabric.

## DIAGNOSTIC_QUESTION_3
Apply the 'embrace' framework to a new context: A student fails their Class 11 mid-term exams. Using the poem's logic, list three specific 'wounds' this student must 'embrace' (not fix, not ignore) and explain what generative possibility each embrace might open.

## DIAGNOSTIC_ANSWER_3
1) The shame of failure → embracing it builds empathy for others struggling. 2) The anxiety about future → embracing it sharpens self-awareness of true priorities. 3) The envy of peers' success → embracing it reveals what the student genuinely values. A wrong answer listing "study harder," "ask teacher for help," or "forget it" shows the student is still in problem-solving mode, not the poem's acceptance mode.

## DIAGNOSTIC_QUESTION_4
Analyze how the imagery in the middle stanzas (e.g., "Hkhrj dh vkx", "rhj dk uqdhykiu", "taxy dh rk”kk gok") structurally supports the primary theme. Why does the poet move from nature imagery to human social rituals (cremation, marriage, children's games) in the same list?

## DIAGNOSTIC_ANSWER_4**
The progression from raw nature (cracked earth, parched rivers, scorching wind) to structured human rituals (cremation pyres, wedding mandaps, children's play) demonstrates that *embrace* operates at every scale — from elemental survival to cultural meaning-making. A wrong answer treating these as random images misses the structural argument: the poem claims embracing is the universal grammar of existence, not a personal coping strategy.

## DIAGNOSTIC_QUESTION_5
Evaluate the claim: "The poem's message is passive resignation — it asks us to accept suffering without trying to change the conditions that cause it." Defend your judgment using two specific textual evidences.

## DIAGNOSTIC_ANSWER_5
The claim is **false**. Evidence 1: "vD[kM+iu" (longing born of poison) and "tq>k:iu" (questioning/restlessness) are *dynamic* energies — they imply movement toward change, not stagnation. Evidence 2: The closing line "bl vfo'okl&Hkjs nkSj esa / FkksM+k&lk fo'okl / FkksM+h&lh mEehn / FkksM+s&ls lius" (in this ruined settlement... great settlements, great palaces, great islands) shows that embracing *creates* new worlds ("fo'okl") from ruins. A wrong answer agreeing with the claim confuses *acceptance of reality* with *inaction* — a critical Category 11 distinction.

## DIAGNOSTIC_QUESTION_6
Create a four-line stanza in Hindi (or English) that extends the poem's logic to a modern wound not mentioned in the text (e.g., digital burnout, climate anxiety, caste humiliation). Your stanza must use the refrain structure and include one concrete metaphor converting pain into generative energy.

## DIAGNOSTIC_ANSWER_6
Example (Hindi):  
"vkvks] feydj cpk,¡ / skreen dh is cahV dks / jo gksus dh vD[kM+iu dks / auh gksus dh tq>k:iu dks"  
(Come, let us embrace / the blue burn of screens / the longing born of disconnection / the questioning born of numbness)  
A poor answer writes a generic motivational quote ("don't give up") without the refrain, without a concrete metaphor, and without the poem's specific alchemy of *naming the wound first*.

## COMMON_MISCONCEPTION
Students conflate **"embrace" (cpk,¡ / tyok;q)** with **"endure" (bFkZ djuk)** or **"overcome" (ck<+uk)**. They read the poem as "be strong through pain" because Indian cultural conditioning valorizes *sahana* (endurance) and *vijay* (victory over adversity). The poem, however, demands *tyok;q* — an active, tender, non-hierarchical holding of the wound *as it is*, without the agenda of fixing it. This misconception leads to answers like "The poet says we should bear difficulties bravely" — which misses the radical vulnerability at the poem's core.

## ON_FAILURE
1) **Re-read the vocabulary box**: Have the student write "cpk,¡ = tyok;q = to hold close, to hug, to welcome" — NOT "to tolerate." 2) **Contrast exercise**: Give two sentences — "Maine apni asafalta ko *bardaasht* kiya" vs "Maine apni asafalta ko *gale lagaya*" — and ask which matches the poem. 3) **Trace the verb**: Have them circle every occurrence of "cpk,¡" and its implied objects (vkcks&gok, vD[kM+iu, tq>k:iu, etc.) and note: *none* are followed by "to fix" or "to remove." 4) **Personal anchor**: Ask them to recall a moment they *hugged* a crying friend vs. a moment they *told* a crying friend "be strong." The physical memory of embrace vs. instruction unlocks the distinction.

## BUILDS_ON
c11_hin_ar_cbse_16_002 (Plot and Narrative Structure) — the student must know the poem's movement from invitation → list of embraces → affirmation of value in ruins.

## LEADS_TO
c11_hin_ar_cbse_16_007 (Theme: Secondary Themes) — the primary theme provides the lens through which secondary themes (social critique, nature-human continuity, language as resistance) become visible.

## PREREQUISITE_NODE_IDS
c11_hin_ar_cbse_16_001, c11_hin_ar_cbse_16_002, c11_hin_ar_cbse_16_003, c11_hin_ar_cbse_16_004, c11_hin_ar_cbse_16_005

## PREREQUISITE_REASONS
c11_hin_ar_cbse_16_001: Provides biographical context (poet's rural roots, joint family, economic struggle) essential to reading the poem as lived philosophy, not abstract theory.
c11_hin_ar_cbse_16_002: Establishes the poem's two-part structure (invitation + expansive list → ruined settlement affirmation) which is the scaffold for theme tracing.
c11_hin_ar_cbse_16_003: The primary theme (rural rootedness vs. urban alienation) is enacted through setting and atmosphere; they are the theme's material form.  
c11_hin_ar_cbse_16_004: The speaker's ideological stance (anti-feudal, pro-marginalized) *is* the primary theme; theme analysis requires protagonist analysis first.  
c11_hin_ar_cbse_16_005: The primary theme (protection of rural wholeness) is built directly from the cumulative portrait of supporting characters analyzed here.  

## FORWARD_NODE_IDS
c11_hin_ar_cbse_16_007, c11_hin_ar_cbse_16_008, c11_hin_ar_cbse_16_013, c11_hin_ar_cbse_16_009, c11_hin_ar_cbse_16_010, c11_hin_ar_cbse_16_012, c12_hin_a_cbse_16_006, c12_hin_ar_cbse_12_006

## FORWARD_REASONS
c11_hin_ar_cbse_16_007: Secondary themes (social hypocrisy, ecological consciousness, linguistic decolonization) branch *from* the primary theme's core logic of embrace.
c11_hin_ar_cbse_16_008: Imagery and metaphor analysis requires the thematic anchor — e.g., "thou ka vD[kM+iu" is only fully readable as metaphor *through* the theme of generative embrace.
c11_hin_ar_cbse_16_013: Critical interpretation (e.g., "Is the poem feminist? Dalit? Ecological?") depends on first nailing the primary theme as the baseline.
c11_hin_ar_cbse_16_009: The primary theme (existential weariness under structural oppression) is the thematic anchor that gives irony and symbolism their purpose.  
c11_hin_ar_cbse_16_010: The primary theme (erosion of joint family values) determines which words are "key" - vocabulary serves theme, not vice versa.  
c11_hin_ar_cbse_16_012: Primary theme (holistic acceptance of life) is the anchor for all thematic inferences.  
c12_hin_a_cbse_16_006: Class 11 theme-analysis foundation (identifying theme vs. topic, evidence-based claim) is directly applied here at higher complexity.  
c12_hin_ar_cbse_12_006: Consolidation of theme analysis across Class 11 chapters.  

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_16_001 -> c11_hin_ar_cbse_16_002 -> c11_hin_ar_cbse_16_010 -> c11_hin_ar_cbse_16_006 -> c11_hin_ar_cbse_16_007 -> c11_hin_ar_cbse_16_013

## THIS_FORMULA
Primary Theme = (Recurring Imperative Verb + Scope of Objects) → (Transformative Logic) → (Closing Affirmation)  
Message = "What the poet wants the reader to *do* differently after reading" = **Embrace your specific wounds as the raw material of your wholeness.**

## FORMULA_VARIABLES
- Recurring Imperative Verb: The repeated action word anchoring the poem (here: "cpk,¡" / embrace)
- Scope of Objects: The exhaustive, heterogeneous list of what the verb acts upon (thorns, darkness, poison, jealousy, cremation, marriage, children's games...)
- Transformative Logic: The implicit alchemy converting each object from 'negative' to 'generative' (poison → longing, ruins → great settlements)
- Closing Affirmation: The final stanza's declaration of value persisting in devastation

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
analytical

## CROSS_SUBJECT
c11_psychology_mental_health | The poem's "embrace" mirrors Acceptance and Commitment Therapy (ACT)'s core process of *acceptance* — making room for painful feelings without struggle — which research shows reduces experiential avoidance and increases psychological flexibility.
c11_sociology_social_change | The list embracing "cremation, wedding mandaps, children's play" reflects the sociological concept of *ritual as social glue* — the poem argues that even in a "ruined settlement" (vfo'okl&Hkjs nkSj), these rituals persist and must be embraced to rebuild collective meaning.
c11_economics_development | The closing image "FkksM+k&lk fo'okl / FkksM+h&lh mEehn / FkksM+s&ls lius" (great settlements, great palaces, great islands) critiques GDP-centric development: the poet measures wealth by *what survives in ruins* (community, ritual, play), not by grand infrastructure.

## PREREQ_CONCEPT
The concept of **'motif-driven thematic analysis'** — identifying a repeated word/structure (here: "cpk,¡"), mapping its objects, and inferring the worldview that unifies them.

## PREREQ_BEFORE
Student must be able to: (a) list 8+ distinct objects of "cpk,¡" from the poem, (b) define each using the vocabulary box, (c) describe the poem's two-part structure (invitation → affirmation).

## PREREQ_STUCK
If stuck, return to **c11_hin_ar_cbse_16_010 (Vocabulary)** and **c11_hin_ar_cbse_16_002 (Structure)** — 90% of theme errors stem from fuzzy word meanings or missing the structural pivot at "bl vfo'okl&Hkjs nkSj esa".

## WORKED_EXAMPLE_1
PROBLEM: A student writes: "The primary theme of the poem is that we should be brave and face difficulties." Using the 4-step board-exam answer structure (Point-Evidence-Explanation-Link), guide them to upgrade this to a distinction-level answer.

STEPS:
- Step 1 (Identify the gap): The draft uses generic moral language ("brave", "face") absent from the poem. The poem never uses "himmat" (courage) or "samna" (confront). It uses "cpk,¡" (embrace) — a tender, non-aggressive verb.
- Step 2 (Retrieve evidence): List three objects of "cpk,¡" that contradict "bravery": "Hkhrj dh vkx" (cracked earth — passive, broken), "rhj dk uqdhykiu" (parched river's thirst — helpless longing), "cPpksa osQ fy, eSnku" (toys for children — play, not battle).
- Step 3 (Apply transformative logic): For each, show the alchemy: cracked earth → holds seeds; parched river → remembers flow; toys → imagine worlds. The logic is *generativity through vulnerability*, not strength through resistance.
- Step 4 (Formulate Point): "The primary theme is the generative power of embracing vulnerability — the poet argues that wholeness arises not from overcoming wounds but from holding them tenderly as sources of creativity."
- Step 5 (Draft Evidence-Explanation): "In stanza 2, the poet lists 'vD[kM+iu' (longing born of poison) and 'tq>k:iu' (restless questioning) alongside 'Hkksykiu' (jealousy) as objects of embrace. This triad converts toxic emotions into kinetic energies — longing fuels pursuit, questioning fuels inquiry, jealousy fuels clarity of desire."
- Step 6 (Link to message): "Therefore, the message is: Stop pathologizing your pain. Your shame, envy, burnout, grief are not errors to fix — they are the raw materials of your unique becoming."

REASONING: This models the exact PEEL structure examiners reward: thematic statement grounded in lexical precision, evidence from multiple stanzas, explicit analysis of the poem's internal logic, and a crisp message formulation.

ANSWER: **Upgraded Answer**: "The primary theme of 'vkvks] feydj cpk,¡' is the *transformative acceptance of suffering* — the insight that embracing one's wounds, failures, and 'negative' emotions (rather than resisting or fixing them) is the necessary condition for authentic healing and creative regeneration. The poem operationalizes this through the refrain 'cpk,¡' (embrace) applied to an expansive, non-hierarchical list: elemental wounds ('Hkhrj dh vkx', 'rhj dk uqdhykiu'), toxic emotions ('vD[kM+iu', 'tq>k:iu', 'Hkksykiu'), and social rituals ('xhrksa dh èkqu', 'cPpksa osQ fy, eSnku'). The transformative logic appears in compounds like 'vD[kM+iu' (poison → longing) where the wound *becomes* the energy for growth. The closing stanza affirms this: even in a 'ruined settlement' (vfo'okl&Hkjs nkSj), 'great settlements, great palaces, great islands' (FkksM+k&lk fo'okl...) emerge *through* embrace. Message: Your brokenness is not a flaw in your design — it is the design."

## WORKED_EXAMPLE_2
PROBLEM: The poem includes "oqQYgkM+h dh èkkj" (the scream of oppression) and "fe^h dk lksaèkkiu" (the melting of greed) in the same embrace-list. Analyze how this pairing complicates a purely *personal* reading of the theme and expands it into a *collective/political* dimension.

STEPS:
- Step 1 (Locate the pairing): Both appear in the middle stanza's long list, grammatically parallel as objects of "cpk,¡".
- Step 2 (Define each term precisely): "oqQYgkM+h" = systemic oppression/exploitation (not just personal sadness); "fe^h" = greed/avarice (a structural vice, not individual flaw). "èkkj" = scream (public, collective); "lksaèkkiu" = melting/dissolution (process, not event).
- Step 3 (Analyze the embrace-logic for each): Embracing the scream of oppression = refusing to silence testimony, making injustice visible. Embracing the melting of greed = witnessing the *process* of deconditioning from accumulation without moral judgment.
- Step 4 (Synthesize the complication): The poem refuses the binary of 'personal vs political pain'. The same verb "cpk,¡" applies to my jealousy *and* to caste violence *and* to capitalism's greed. This implies: **the personal is the political is the elemental** — all are wounds in the same fabric.
- Step 5 (Connect to primary theme): The primary theme *expands* from "self-acceptance" to "radical inclusivity of all suffering as transformable matter." The message becomes: *No wound is too structural, no vice too systemic, to be excluded from the embrace that regenerates.*
- Step 6 (Board-exam formulation): "The inclusion of 'oqQYgM+h dh èkkj' and 'fe^h dk lksaèkkiu' alongside personal wounds universalizes the theme: embrace is not self-help but a *revolutionary epistemology* — the only way to transmute structural violence into collective futurity."

REASONING: This example demonstrates how senior-secondary analysis must move beyond 'relatable' personal readings to structural readings grounded in precise lexical-semantic work — a key differentiator for 90%+ scores.

ANSWER: **The pairing forces the theme from 'personal healing' to 'collective transmutation'.** "oqQYgM+h dh èkkj" (scream of oppression) names systemic violence (caste, gender, class) as a wound *to be embraced* — meaning: we must hold the testimony of the oppressed without rushing to 'solutions' that erase their reality. "fe^h dk lksaèkkiu" (melting of greed) names the *internalized structural vice* as a process to be witnessed — not condemned, but embraced as it dissolves. Together, they collapse the private/public binary: the poem says *the same alchemy* (embrace → generativity) works on my envy *and* on Brahminical violence *and* on capitalist greed. The primary theme thus becomes: **Radical embrace as the only praxis that can metabolize historical trauma into liberated futures.** Message: "Do not bypass the scream. Do not spiritualize the melting. Embrace both — that is how ruined settlements grow great islands."

## WORKED_EXAMPLE_3
PROBLEM: A board exam question asks: "How does the poet use the metaphor of 'nkSj' (time/settlement/era) in the final stanza to redefine 'progress'? Answer with reference to the primary theme." Construct a 6-step answer integrating theme, metaphor, and message.

STEPS:
- Step 1 (Define 'nkSj' polysemy): In the poem, "nkSj" carries three simultaneous meanings: (a) time/era, (b) settlement/habitation, (c) astrological moment. The closing line "bl vfo'okl&Hkjs nkSj esa" (in this ruined-settlement era) activates all three.
- Step 2 (Contrast with dominant progress narrative): Dominant progress = linear, cumulative, shiny (smart cities, GDP growth). The poem's "vfo'okl&Hkjs nkSj" = non-linear, ruined, *already broken*.
- Step 3 (Locate the primary theme's operator): The theme (embrace-as-transmutation) enters *precisely here* — the poet does not say "rebuild the settlement." They say "in *this* ruined settlement... there is much to embrace."
- Step 4 (Analyze the triad of 'FkksM+'): "FkksM+k&lk fo'okl" (great settlements), "FkksM+h&lh mEehn" (great palaces), "FkksM+s&ls lius" (great islands) — all are *already present* in the ruins, *revealed* by embrace, not constructed anew.
- Step 5 (Synthesize redefinition): Progress is redefined from **building anew on cleared ground** to **recognizing grandeur already latent in the ruins through embrace**.
- Step 6 (Final message formulation): "The poem tells us: You do not need a 'new India' (naya bharat). You need the courage to embrace *this* India — its cracked earth, its parched rivers, its screams, its melting greed — and you will find the great settlements are *already here*, waiting in the ruins."

REASONING: This models the highest-order competency: using the primary theme as an analytical lens to decode a key metaphor's ideological work, then producing a message that speaks to contemporary discourse (development vs. ruin) — exactly what CBSE 'critical thinking' questions demand.

ANSWER: **The metaphor "nkSj" (era/settlement) redefines progress as *revelation through embrace* rather than *construction on erasure*.** The final stanza — "bl vfo'okl&Hkjs nkSj esa / FkksM+k&lk fo'okl / FkksM+h&lh mEehn / FkksM+s&ls lius" — uses "nkSj" as a triple entendre: the current historical moment, the physical habitat, and the karmic epoch. The primary theme (transformative embrace) operates here as an *epistemological tool*: only by embracing the "ruined settlement" (vfo'okl&Hkjs) — its thorns, poison, screams, melting greed — do the "great settlements, palaces, islands" *become visible*. They were always there, latent in the ruins. Thus progress is not the bulldozer that clears slums for highways; it is the embrace that sees the "great island" inside the slum's resilience. Message: **True development is not replacement — it is the radical embrace that transmutes ruin into revelation.**

## COMPETENCY_QUESTION_1
QUESTION: "The poem's primary theme is often summarized as 'acceptance of pain.' A Class 11 student argues: 'But acceptance is passive — the poem is actually about *active transformation*.' Evaluate this student's claim using three specific textual anchors from different stanzas. What distinction between 'acceptance' and 'embrace' does the poem enforce?"

COMPETENCY: Critical textual evaluation with conceptual precision (distinguishing near-synonyms through evidence)

STEPS:
- Step 1: Acknowledge the student's valid instinct — the poem *is* transformative — but note their vocabulary gap.
- Step 2: Anchor 1 (Stanza 1): "vkcks&gok" (thorns) are not 'accepted' — they are *embraced* ("cpk,¡") which implies *physical contact, warmth, inclusion* — not mere tolerance.
- Step 3: Anchor 2 (Stanza 2): "vD[kM+iu" (longing from poison) — the poison *becomes* longing *through* embrace; this is alchemical transmutation, not passive endurance.
- Step 4: Anchor 3 (Stanza 3): "bl vfo'okl&Hkjs nkSj esa... FkksM+k&lk fo'okl" — the ruined settlement *generates* great settlements *because* of embrace; acceptance would leave the settlement ruined.
- Step 5: Formulate the distinction: **Acceptance = cognitive assent to reality ('it is what it is'). Embrace = somatic, generative engagement ('I hold this, and in holding, it becomes something else').**

ANSWER: The student is **right about the poem's energy but wrong about the word 'acceptance'.** The poem enforces a sharp distinction: **Acceptance is static; embrace is kinetic.** Evidence: (1) "vkcks&gok ls cpk,¡" — you don't 'accept' thorns piercing you; you *hug* the thorn-bush, converting puncture into intimacy. (2) "vD[kM+iu" — poison doesn't just 'get accepted'; embraced, it *metabolizes* into longing (the engine of pursuit). (3) "vfo'okl&Hkjs nkSj" → "FkksM+k&lk fo'okl" — ruins don't become palaces by being 'accepted'; they become palaces *through the act of embrace* which reveals their latent grandeur. The poem's message: **Don't accept your wounds — that's stoicism. Embrace them — that's alchemy.**

DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: Design a 3-minute spoken-word performance piece (in Hindi or English) that *embodies* the poem's primary theme for a modern audience unfamiliar with the text. Your piece must: (a) open with the refrain logic ("Come, let us embrace..."), (b) include three contemporary wounds not in the poem (e.g., Instagram anxiety, climate grief, caste fatigue), (c) enact the transformative logic (wound → generative energy) for each, and (d) close with the "ruined settlement → great islands" move. Write the script and annotate *why* each choice maps to the poem's theme-mechanism.

COMPETENCY: Creative synthesis — transferring thematic structure to new content while preserving formal logic

STEPS:
- Step 1 (Refrain adaptation): "vkvks] feydj cpk,¡ / apne algorhythm ke zakhm / apne carbon ke kaante / apne jaati ke jalte sawal" — maps to "vkcks&gok ls cpk,¡" but updates the 'thorns' to algorithmic/caste/ecological wounds.
- Step 2 (Triad of transmutation): For each wound, create a compound like "vD[kM+iu": (a) "scroll-kshudha" (hunger from scrolling) → "vD[kM+iu" = longing for *real* connection; (b) "dhuan-mein-dharti" (earth in smoke) → "tq>k:iu" = questioning consumption; (c) "surname-ki-siul" (shadow of surname) → "lksaèkkiu" = melting of inherited privilege.
- Step 3 (Embodied delivery notes): Mark pauses after each "cpk,¡" — the *physical act* of opening arms is the poem's method. The performance *is* the embrace.
- Step 4 (Ruined settlement pivot): "Yeh toota-hua shehar / yeh faile-huye khet / yeh tuti-hui naukriyan / yahan bhi — FkksM+k&lk fo'okl / FkksM+h&lh mEehn / FkksM+s&ls lius" — directly transplants the closing stanza's logic.
- Step 5 (Annotation): Explain that the piece doesn't *explain* the theme — it *performs* the embrace, forcing the audience to feel the transmutation in real time, which is the poem's ultimate pedagogy.

ANSWER: **Script (annotated):**  
[Opens with arms wide]  
"vkvks] feydj cpk,¡ — apne Instagram ke andhere ko / us 'perfect life' ke vD[kM+iu ko / jo tumhe asli rishton ki bhook deta hai — **cpk,¡**  
[Pause. Hand on chest.]  
vkvks] feydj cpk,¡ — apne dhuen mein damagti dharti ko / us tapti hawa ke tq>k:iu ko / jo tumhe puchne par majboor karta: 'mera hissa kya?' — **cpk,¡**  
[Step forward.]  
vkvks] feydj cpk,¡ — apne surname ke bhaari saaye ko / us fe^h ke lksaèkkiu ko / jo dhalti raat mein pighalta hai — **cpk,¡**  
[Spin — arms encompassing audience.]  
Aur is vfo'okl&Hkjs nkSj mein — is toote shehar, in faile kheton, in tuti naukriyon ke beech —  
**FkksM+k&lk fo'okl hain. FkksM+h&lh mEehn hain. FkksM+s&ls lius hain.**  
Bas... **cpk,¡**  

**Annotations:** Each "cpk,¡" is a choreographed embrace — the body learns what the mind resists. The compounds (scroll-kshudha, dhuan-mein-dharti, surname-ki-siul) are neologisms mirroring "vD[kM+iu/tq>k:iu/lksaèkkiu" — wound *becomes* energy *in the naming*. The closing doesn't 'resolve' — it *reveals* the greatness already inside the ruin. This is the theme *enacted*, not described.

DIFFICULTY: hard