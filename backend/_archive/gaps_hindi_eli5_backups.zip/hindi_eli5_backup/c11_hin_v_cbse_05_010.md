## DEFINITION
Vocabulary in Context refers to the skill of determining the precise meaning, connotation, and grammatical function of key words as they are used within the specific sentences, paragraphs, and thematic framework of the chapter "jktLFkku dh jtr cw¡nas," rather than relying solely on isolated dictionary definitions.

## COGNITIVE_LEVEL
apply

## MASTERY_CRITERIA
The student must be able to identify at least five key thematic words from the chapter, explain how their contextual meaning shifts from their standard dictionary meaning, and use each word in an original sentence that reflects the chapter's socio-political tone.

## SCOPE_BOUNDARY
This node covers the identification, contextual analysis, and thematic significance of key vocabulary (e.g., administrative, ecological, and political terms) specifically within "jktLFkku dh jtr cw¡nas." It does not cover general vocabulary building, grammar rules for word formation, or vocabulary from other chapters.

## WALKTHROUGH
Imagine you are reading a news report about a local forest being cut down for a highway project; you see words like "acquisition," "rehabilitation," and "biodiversity" used in ways that feel heavier than their dictionary definitions. Similarly, in "jktLFkku dh jtr cw¡nas," words like *सत्ता* (power), *विस्थापन* (displacement), and *पर्यावरण* (environment) carry the weight of the villagers' struggle against systemic indifference. Begin by scanning the text for words that recur during moments of conflict or description of nature. Ask: "Does this word mean the same thing here as it does in my textbook?" Then, compare the dictionary definition with the author's usage in that specific paragraph. The key insight is that in this chapter, vocabulary is not just language—it is evidence of the clash between state policy and lived reality.

## DIAGNOSTIC_QUESTION_1
What is the primary difference between a dictionary definition of a word and its contextual meaning in a literary text like "jktLFkku dh jtr cw¡nas"?

## DIAGNOSTIC_ANSWER_1
A dictionary definition provides a standardized, decontextualized meaning, while contextual meaning is shaped by the author's tone, the specific situation in the narrative, and the thematic concerns of the chapter (e.g., *विस्थापन* implies not just "moving" but forced uprooting and cultural loss). A wrong answer suggests the student treats vocabulary as static labels rather than dynamic tools shaped by narrative perspective.

## DIAGNOSTIC_QUESTION_2
In the chapter, the word *सत्ता* (power/authority) appears frequently. Explain how its meaning in the phrase "सत्ता की संवेदनहीनता" (insensitivity of power) differs from its meaning in a standard civics textbook definition of "the state."

## DIAGNOSTIC_ANSWER_2
In the civics textbook, *सत्ता* is a neutral, structural term for legitimate governing authority. In the chapter, it acquires a negative connotation, personifying the state as a callous, monolithic entity indifferent to human suffering. A wrong answer reveals the student cannot detect connotation shifts or authorial bias encoded in vocabulary.

## DIAGNOSTIC_QUESTION_3
Choose the word *जड़ें* (roots) from the text. The author writes about "उखड़ती जड़ें" (uprooting roots). Write a sentence using *जड़ें* that captures the *metaphorical* sense used in the chapter (cultural/ancestral connection), not the botanical sense.

## DIAGNOSTIC_ANSWER_3
Example: "विकास के नाम पर जब गाँव उजड़े, तो केवल घर नहीं, पीढ़ियों की *जड़ें* भी काट दी गईं।" (In the name of development, when villages were destroyed, not just homes but the *roots* of generations were severed.) A wrong answer uses only the literal meaning (e.g., "पेड़ की जड़ें मिट्टी में गहरी जाती हैं"), showing inability to transfer metaphorical understanding to new production.

## DIAGNOSTIC_QUESTION_4
Compare the usage of *कानून* (law) and *न्याय* (justice) in the chapter. How does the author create a semantic gap between these two concepts through the narrative events?

## DIAGNOSTIC_ANSWER_4
The author uses *कानून* to denote the procedural, bureaucratic instrument used to acquire land (legal but oppressive), while *न्याय* represents the moral expectation of the villagers that remains unfulfilled. The gap highlights the failure of legal frameworks to deliver ethical outcomes. A wrong answer treats them as synonyms, missing the central thematic tension between legality and morality.

## DIAGNOSTIC_QUESTION_5
Critique this student statement: "The word *विकास* (development) in the chapter means the same as 'economic growth' in Economics textbooks." Defend your critique using evidence from the narrative perspective.

## DIAGNOSTIC_ANSWER_5
The critique is valid: in the chapter, *विकास* is an ironic term—it signifies destruction of habitat, loss of livelihood, and cultural erasure for the tribal villagers, whereas Economics defines it as a positive quantitative indicator. The narrative voice frames *विकास* as a euphemism for exploitation. A wrong answer accepts the student's statement, showing failure to recognize irony and perspective-dependent semantics.

## DIAGNOSTIC_QUESTION_6
Create a two-sentence "vocabulary profile" for the word *संघर्ष* (struggle) as used in this chapter. Include: (1) its grammatical category in the key sentence, (2) its thematic weight, and (3) an original phrase showing its collocation with another key word from the text.

## DIAGNOSTIC_ANSWER_6
Profile: *संघर्ष* functions as a masculine noun, often the subject of sentences describing collective action; it carries the weight of existential survival, not mere disagreement. Collocation: "अस्तित्व का संघर्ष" (struggle for existence) or "संघर्ष की जड़ें" (roots of struggle). A poor answer lists only the dictionary meaning or fails to identify a valid collocation from the text's semantic field.

## COMMON_MISCONCEPTION
Students believe that "vocabulary in context" simply means "guessing the meaning of a hard word from the surrounding sentence." They treat it as a local clue-hunt (synonym/antonym nearby) rather than a global thematic analysis. For example, they define *विस्थापन* as "shifting house" because the text mentions "घर छोड़ना," missing that the context of "जंगल," "पुरखों की जमीन," and "मुआवज़ा न मिलना" transforms it into "forced alienation from ecological and cultural heritage."

## ON_FAILURE
1. Have the student list 5 words they think are "key" to the chapter. 2. For each word, ask them to write the dictionary meaning in Column A and the "chapter meaning" in Column B using only phrases from the text (e.g., for *जंगल*: Column A = "forest"; Column B = "जीवन का आधार," "आजीविका," "संस्कृति"). 3. Force them to articulate the *gap* between Column A and B in one sentence: "The chapter adds the idea of ______ which the dictionary misses." 4. Finally, ask them to rewrite a textbook sentence using the "chapter meaning" to prove internalization.

## BUILDS_ON
c11_hin_v_cbse_05_002: Text: Plot and Narrative Structure (provides the narrative events where key words are situated)

## LEADS_TO
c11_hin_v_cbse_05_012: Comprehension: Literal and Inferential Questions (requires precise vocabulary understanding to answer inferential questions)

## PREREQUISITE_NODE_IDS
c11_hin_v_cbse_05_001, c11_hin_v_cbse_05_002, c11_hin_v_cbse_05_006, c11_hin_v_cbse_05_009

## PREREQUISITE_REASONS
c11_hin_v_cbse_05_001: Context and Background provides the socio-political setting (tribal displacement, development projects) essential to decode the connotative load of key vocabulary.
c11_hin_v_cbse_05_002: Plot and Narrative Structure supplies the specific scenes and conflicts where words like *विस्थापन* and *मुआवज़ा* operate, allowing contextual analysis.
c11_hin_v_cbse_05_006: Theme: Primary Theme and Message establishes the central conflict (power vs. powerless, development vs. destruction) that dictates the semantic direction of key terms.
c11_hin_v_cbse_05_009: - Step 5: Connect to literary device. This is lexical irony / semantic reversal (c11_hin_v_cbse_05_009), reinforcing the theme of power asymmetry.  

## FORWARD_NODE_IDS
c11_hin_v_cbse_05_011, c11_hin_v_cbse_05_012, c11_hin_v_cbse_05_014, c11_hin_v_cbse_05_015, c12_hin_a_cbse_07_010

## FORWARD_REASONS
c11_hin_v_cbse_05_011: Grammar: Language Usage in the Text requires identifying the grammatical categories (noun, verb, adjective) of these key words to analyze syntactic patterns.
c11_hin_v_cbse_05_012: Comprehension: Literal and Inferential Questions depends on precise vocabulary knowledge to distinguish what is stated vs. implied.
c11_hin_v_cbse_05_014: Writing Skills: Based on the Chapter demands using the chapter's own thematic vocabulary (e.g., *संवेदनहीनता*, *अस्तित्व*) to write analytical answers.
c11_hin_v_cbse_05_015: Key vocabulary (जर्जर, लोक-स्मृति, इतिहास-बोध) provides precise terminology  
c12_hin_a_cbse_07_010: Consolidated Class 11 vocabulary competency.  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
none

## CHAIN_DESCRIPTION
c11_hin_v_cbse_05_001 -> c11_hin_v_cbse_05_002 -> c11_hin_v_cbse_05_010 -> c11_hin_v_cbse_05_012 -> c11_hin_v_cbse_05_014

## THIS_FORMULA
N/A - conceptual

## FORMULA_VARIABLES
N/A

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
linguistic

## CROSS_SUBJECT
c11_political_science_rights | The chapter's vocabulary (*अधिकार*, *कानून*, *नीति*, *शासन*) directly mirrors Political Science concepts of state-citizen relations, rights violations, and policy implementation gaps, allowing students to map literary semantics to constitutional frameworks.
c11_geography_human_ecology | Terms like *पारिस्थितिकी* (ecology), *आजीविका* (livelihood), *वनाधिकार* (forest rights) connect to Human Ecology geography topics on resource dependence, sustainable development, and tribal geography, providing a spatial-dimension to vocabulary analysis.

## PREREQ_CONCEPT
The student must understand that words in literary texts function as "semantic containers" holding history, emotion, and ideology, not just referential labels.

## PREREQ_BEFORE
The student must have read the full chapter "jktLFkku dh jtr cw¡nas" at least once and identified the central conflict (tribal villagers vs. state development machinery).

## PREREQ_STUCK
If stuck, review the "Theme: Primary Theme and Message" (c11_hin_v_cbse_05_006) to re-anchor the ideological framework that shapes word meanings.

## WORKED_EXAMPLE_1
PROBLEM: Analyze the key word *मुआवज़ा* (compensation) in the chapter. Show how its contextual meaning exposes the gap between legal procedure and human loss.

STEPS:
- Step 1: Locate the word in the text. It appears in the context of the government acquiring land for the project. Note the sentence: "मुआवज़े के नाम पर कुछ रुपये थमा दिए गए" (A few rupees were handed over in the name of compensation).
- Step 2: Identify the dictionary/legal definition: "Monetary payment for loss or injury, calculated by market rates." This is the "State's view."
- Step 3: Analyze the modifiers in the text: "कुछ रुपये" (a few rupees), "थमा दिए गए" (handed over/dumped), implying inadequacy, disrespect, and transactional dismissal.
- Step 4: Identify what is *not* compensated: The text lists "जंगल," "नदी," "पूर्वजों की कब्रें," "संस्कृति" (forest, river, ancestors' graves, culture). These have zero market value but infinite use value.
- Step 5: Synthesize the contextual meaning: In this chapter, *मुआवज़ा* means "a bureaucratic ritual that legally sanctions theft by paying for the replaceable (land) while ignoring the irreplaceable (life-world)."
- Step 6: Verify against theme: This aligns with the primary theme "Development as Dispossession" (c11_hin_v_cbse_05_006).

REASONING: This 6-step process moves from textual evidence (location, modifiers) to semantic contrast (dictionary vs. text) to thematic synthesis, modeling the exact analytical depth required for board exam "explain with reference to context" questions.

ANSWER: In "jktLFkku dh jtr cw¡nas," *मुआवज़ा* is not merely "compensation" but a symbol of institutional violence—a paltry sum that quantifies land but erases the qualitative loss of ecological identity, ancestral memory, and cultural survival. The author uses the word ironically to expose the state's reduction of a holistic existence to a ledger entry.

## WORKED_EXAMPLE_2
PROBLEM: The word *अधिकार* (right/entitlement) appears in two distinct contexts: "वनाधिकार" (forest rights) and "अधिकारियों के अधिकार" (officials' powers). Compare their contextual meanings and grammatical construction.

STEPS:
- Step 1: Extract the two phrases. Phrase A: "उनके वनाधिकार छीन लिए गए" (Their forest rights were snatched away). Phrase B: "अधिकारियों ने अपने अधिकारों का दुरुपयोग किया" (Officials misused their powers).
- Step 2: Analyze grammatical role. In A, *वनाधिकार* is a compound noun (Tatpurusha Samas: वन + अधिकार), functioning as the direct object of "छीन लिए गए" (passive voice, victim subject). In B, *अधिकारों* is a plural noun in oblique case, object of "दुरुपयोग किया" (active voice, perpetrator subject).
- Step 3: Determine semantic valence. A: *अधिकार* = moral/legal entitlement rooted in tradition and survival (positive valence, loss = injustice). B: *अधिकार* = institutional authority derived from position (negative valence in context, misuse = oppression).
- Step 4: Identify the irony. The same root word denotes "that which is due to the powerless" and "that which is wielded by the powerful." The chapter structures this as a zero-sum transfer: the officials' *अधिकार* expands precisely by nullifying the villagers' *वनाधिकार*.
- Step 5: Connect to literary device. This is lexical irony / semantic reversal (c11_hin_v_cbse_05_009), reinforcing the theme of power asymmetry.

REASONING: This example demonstrates how vocabulary analysis at Class 11 level must integrate grammar (samasa, voice, case), semantics (valence, polysemy), and literary device identification to answer competency questions on "author's craft."

ANSWER: *वनाधिकार* (compound noun, passive object) signifies the villagers' inalienable, survival-based entitlement that is violently stripped away. *अधिकार* (plural noun, active instrument) signifies the state's procedural power that is weaponized against the vulnerable. The shared morphology masks a radical ethical opposition: one is a right *to* life; the other, a power *over* life.

## WORKED_EXAMPLE_3
PROBLEM: A board exam question asks: "Explain how the author uses the word *विकास* (development) as an ironic motif throughout the chapter. Support with three specific contextual instances." Construct a model answer using the PEEL structure (Point, Evidence, Explanation, Link).

STEPS:
- Step 1 (Point): State the thesis clearly. The author subverts the standard positive connotation of *विकास*, deploying it as an ironic motif that signifies "destruction disguised as progress."
- Step 2 (Evidence 1): Instance 1 - Project announcement. Context: "विकास के नाम पर बाँध बनेगा" (A dam will be built in the name of development). Analysis: *विकास* here is a performative utterance by the state, a banner legitimizing displacement.
- Step 3 (Evidence 2): Instance 2 - Villagers' reality. Context: "यह कैसा विकास जो जिंदगी छीन ले?" (What development is this that takes life?). Analysis: The rhetorical question inverts the term; *विकास* becomes the agent of death (*जिंदगी छीन ले*), not growth.
- Step 4 (Evidence 3): Instance 3 - Aftermath. Context: "विकास की सूखी टहनियाँ" (Dry branches of development - title reference). Analysis: The metaphor *सूखी टहनियाँ* (dry branches) visualizes *विकास* as lifeless, parasitic, and sterile—directly contradicting the biological metaphor of growth implied by the word.
- Step 5 (Explanation): Synthesize. The irony operates through sustained semantic inversion: the signifier (*विकास*) remains constant while the signified shifts from "growth/prosperity" (state discourse) to "ecocide/ethnocide" (victim discourse/narrative truth).
- Step 6 (Link): Conclude. This motif structures the reader's moral judgment, forcing us to question whose *विकास* it serves, directly serving the chapter's critique of top-down planning.

REASONING: This worked example models the full "competency answer" required for 5-6 mark board questions: it demands thesis-driven structure, multi-evidence citation, semantic analysis, and thematic linking—all rooted in vocabulary study.

ANSWER: The author transforms *विकास* into an ironic motif through sustained semantic inversion. (Point) In the state's discourse, "विकास के नाम पर बाँध बनेगा" frames it as a benevolent banner. (Evidence 1) The villagers' lived experience counters this: "यह कैसा विकास जो जिंदगी छीन ले?" turns the word into an agent of death. (Evidence 2) The title metaphor "जट्र cw¡nas" (dry branches) crystallizes the irony: development is not a flowering tree but dead wood. (Evidence 3) The word thus signifies not growth but the "development of underdevelopment" for the marginalized. (Explanation) This lexical strategy compels the reader to reject the state's vocabulary and adopt the victims' semantics. (Link)

## COMPETENCY_QUESTION_1
QUESTION: In the chapter, the word *नीति* (policy) is described as "ऊपर से बनी नीति" (policy made from above). Using this phrase, explain how the vocabulary choice reveals the *procedural exclusion* of the affected community. Your answer must reference: (a) the spatial metaphor "ऊपर से," (b) the grammatical agency implied, and (c) the thematic consequence.

COMPETENCY: Critical Vocabulary Analysis / Semantic Deconstruction

STEPS:
- Step 1: Decode the spatial metaphor "ऊपर से" (from above). It denotes both physical distance (capital city vs. village) and hierarchical distance (rulers vs. ruled).
- Step 2: Analyze grammatical agency. "बनी नीति" (policy was made) uses passive construction / impersonal verb, hiding the human agents (politicians, bureaucrats) and presenting the policy as an inevitable, objectified force.
- Step 3: Contrast with the absent agency of villagers. No verb like "बनाई गई" (was made by us) or "तय की गई" (was decided by us) applies to them. They are the *object* of the policy, not the *subject*.
- Step 4: State thematic consequence. This vocabulary enacts "epistemic injustice"—the community's knowledge of their ecology (*जंगल, नदी, जमीन*) is excluded from the definition of *नीति* itself.
- Step 5: Conclude with the word's redefined meaning. Here, *नीति* means "a top-down technical instrument that renders the governed invisible in their own governance."

ANSWER: The phrase "ऊपर से बनी नीति" uses the spatial metaphor "ऊपर से" to mark the unbridgeable distance between the decision-making centre and the affected periphery. The passive construction "बनी नीति" erases human agency, naturalizing the policy as a fact of nature rather than a political choice. Consequently, the villagers—who possess generational knowledge of the forest—are linguistically and procedurally excluded from the very concept of *नीति*. In this chapter, *नीति* ceases to mean "a plan for public welfare" and comes to mean "an exogenous imposition that legitimizes dispossession."

DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: The chapter title "jktLFkku dh jtr cw¡nas" (The Dry Branches of Power) is a metaphor. Deconstruct the vocabulary of this title: (1) Explain why *जट्र* (dry/dead) is semantically more potent than *सूखी* (dry) or *मुर्दा* (dead). (2) Analyze the possessive *धा* (of) — does it indicate ownership, attribution, or consequence? (3) Synthesize how this title vocabulary encapsulates the chapter's critique of the "development state." Write a 100-word analytical paragraph.

COMPETENCY: Advanced Literary Semantics / Title Deconstruction / Synthesis

STEPS:
- Step 1: Analyze *जट्र* vs. synonyms. *सूखी* is a physical state (reversible with water). *मुर्दा* is absolute finality (no life ever). *जट्र* implies "once living, now desiccated by external heat/neglect"—it retains the *memory* of life (green branches) but is now brittle, useless, dangerous (snaps easily). It matches the "development" that once promised fruit (growth) but delivers only breakage.
- Step 2: Analyze *धा* (possessive postposition). It signals *consequence/origin*, not ownership. The dry branches *belong to* the tree of power by inevitable biological logic: a tree that sucks all moisture (resources) from its roots (people) *produces* dry branches. It is the *fruit* of that power's nature.
- Step 3: Analyze *cw¡nas* (branches/twigs). Not the trunk (core power), not leaves (ephemeral policies), but branches—the extending arms of the state reaching into villages. They are "dry" because they have no sap (empathy, life-support) flowing through them.
- Step 4: Synthesize into paragraph. Combine: lexical choice (*जट्र*), grammatical relation (*धा* as consequence), and imagery (*cw¡nas* as state's reach) to argue the title diagnoses the state as a parasitic organism that kills its own support system.
- Step 5: Polish for board-exam tone: formal Hindi, precise terminology (रूपक, अर्थ-छवि, व्यंजना).

ANSWER: शीर्षक "जट्र cw¡nas" में *जट्र* शब्द *सूखी* या *मुर्दा* से अधिक व्यंजक है: *सूखी* भौतिक अवस्था है (पानी से हरी हो सकती है), *मुर्दा* अंतिम मृत्यु है, किंतु *जट्र* उस डाल को दर्शाता है जिसमें कभी रस था, जीवन था, पर बाहरी ताप (सत्ता की उपेक्षा) ने उसे निचोड़ डाला—अब वह भंगुर, अनुपयोगी और खतरनाक है। *धा* कारक यहाँ स्वामित्व नहीं, **परिणाम-निष्पत्ति** दर्शाता है: सत्ता रूपी वृक्ष ने जड़ों (जनता/जंगल) से रस खींचकर अपनी ही शाखाओं (नीतियों/योजनाओं) को *जट्र* बना दिया। *cw¡nas* (टहनियाँ) सत्ता की विस्तारित भुजाएँ हैं जो गाँवों तक पहुँचती हैं पर उनमें संवेदना-रस नहीं। इस प्रकार शीर्षक-विकास "विकास-राज्य" को एक परजीवी जीव के रूप में निदान करता है जो अपने आश्रयदाता को सुखाकर स्वयं भी मृतावशेष बन जाता है।

DIFFICULTY: hard