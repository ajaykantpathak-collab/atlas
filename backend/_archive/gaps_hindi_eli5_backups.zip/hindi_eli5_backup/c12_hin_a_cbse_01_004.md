## DEFINITION
Character analysis of the protagonist in poetry involves examining the speaker's personality, emotions, motivations, and development through their words, imagery, and tone, to understand their role in conveying the poem's central theme.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student can independently identify the protagonist's key traits in a poem, cite specific textual evidence (lines/stanzas), explain how the poet uses literary devices to reveal the protagonist's inner state, and connect the protagonist's journey to the poem's theme.

## SCOPE_BOUNDARY
This node covers analysis of the protagonist (poetic speaker) in the two poems "nsolsuk dk xhr" and "dkusZfy;k dk xhr" from Chapter 1 of Class 12 Hindi Antra. It does not cover supporting characters (node 005), themes (nodes 006-007), or literary devices in isolation (nodes 008-009).

## WALKTHROUGH
Imagine you are reading a poem where the speaker pours out their heart about lost love or love for the motherland. How do you move from "I feel sad" to a structured analysis that scores full marks? Start by reading the poem aloud to catch the tone — is it desperate, proud, resigned? Then mark every first-person statement ("I", "my", "me") because those are direct windows into the protagonist's mind. Next, note the images the protagonist chooses: in the first poem, the "broken dreams" and "crying night" reveal despair; in the second, the "crimson fields" and "guardian of the frontier" reveal fierce pride. Finally, ask: does the protagonist change from start to end? In the first poem, the speaker moves from pleading to acceptance; in the second, from observation to a vow. That arc is your analysis backbone.

## DIAGNOSTIC_QUESTION_1
What is the primary difference between analyzing a protagonist in a short story versus analyzing the poetic speaker in a lyric poem?

## DIAGNOSTIC_ANSWER_1
In a short story, the protagonist is a constructed character with external actions, dialogue, and narrator description; in a lyric poem, the protagonist is the speaker whose personality must be inferred solely from their own words, tone, and chosen imagery. A wrong answer that treats the poetic speaker exactly like a story character (e.g., looking for "actions" instead of "utterances") reveals the student hasn't grasped the fundamental textual difference.

## DIAGNOSTIC_QUESTION_2
In "nsolsuk dk xhr", the speaker says "eSaus Hkzeo'k thou lafpr" (I have ended my life). A student writes: "The protagonist commits suicide." Why is this a misreading of the poetic protagonist?

## DIAGNOSTIC_ANSWER_2
The line is metaphorical — "ended my life" means the speaker has given up hope or emotional vitality, not literal death; the poem continues with the speaker still speaking. A student who takes it literally misses the poetic convention of hyperbole and the distinction between the speaker's felt experience and actual plot events.

## DIAGNOSTIC_QUESTION_3
Apply the "PEEL" method (Point, Evidence, Explanation, Link) to analyze one trait of the protagonist in "dkusZfy;k dk xhr" using the image "gse oqaQHk ys m"kk losjs" (green fields waving like a flag).

## DIAGNOSTIC_ANSWER_3
Point: The protagonist possesses intense patriotic pride. Evidence: The image "green fields waving like a flag" (stanza 2). Explanation: The simile transforms ordinary crops into a national flag, showing the protagonist sees the land itself as a symbol of sovereignty. Link: This establishes the protagonist as a guardian whose identity is inseparable from the motherland. A weak answer would only identify the simile without explaining what it reveals about the speaker's mindset.

## DIAGNOSTIC_QUESTION_4
Compare the emotional arcs of the two protagonists: one in "nsolsuk dk xhr" and the other in "dkusZfy;k dk xhr". How does each poem's structure reflect its protagonist's inner journey?

## DIAGNOSTIC_ANSWER_4
The first protagonist moves from anguished pleading ("vkg! osnuk feyh fonkbZ!") to quiet resignation ("fo'o! u l¡Hkysxh ;g eq>ls"), mirrored by the poem's shift from exclamatory commands to a final resigned address to the world. The second protagonist moves from celebratory observation ("vjQ.k ;g eèkqe; ns'k gekjk!") to a solemn vow ("efnj m¡Q?krs jgrs tcµtxdj jtuh Hkj rkjk"), mirrored by the expansion from descriptive stanzas to a closing couplet of commitment. A student who only lists emotions without linking to structural shifts misses the analytical depth.

## DIAGNOSTIC_QUESTION_5
Evaluate this claim: "The protagonist of 'nsolsuk dk xhr' is weaker than the protagonist of 'dkusZfy;k dk xhr' because one gives up while the other fights." Use textual evidence to support or refute.

## DIAGNOSTIC_ANSWER_5
The claim imposes a value judgment alien to both poems. The first protagonist's "giving up" is an acceptance of fate after profound love ("eSaus fut nqcZy in&cy ij mlls gkjh&gksM+ yxkbZ" — I placed heavy stones on my fragile heart), which requires immense emotional strength. The second protagonist's "fighting" is a lifelong vigil ("efnj m¡Q?krs jgrs tcµtxdj jtuh Hkj rkjk"). Both show endurance; the difference is in the object of devotion (personal love vs. national duty). A student who agrees with the claim reveals a reductive binary understanding of strength.

## DIAGNOSTIC_QUESTION_6
Write a four-line stanza in Hindi (or transliterated) that could serve as the opening of a poem where the protagonist is a student facing board exams, using the same tone of intimate self-address found in "nsolsuk dk xhr".

## DIAGNOSTIC_ANSWER_6
Example: "vkg! pariksha feyh fonkbZ! / eSaus Hkzeo'k nis/kk lafpr] / chpksa dh Hkh[k yqVkbZA" (Alas, exams are passing! / I have finished my preparation / broken the dreams of pages.) A good answer mirrors the direct address to an abstract force ("pariksha"), the first-person declaration, and the metaphor of broken dreams. A poor answer would be a generic motivational quote without the raw, personal voice.

## COMMON_MISCONCEPTION
Students often treat the poetic speaker as the poet themselves (Tulsidas, 1889–1937) and write biographical details instead of analyzing the constructed persona. For example, they might say "The protagonist is a nationalist poet from the freedom struggle" for the second poem, ignoring that the poem creates a timeless guardian figure. This error occurs because the textbook provides the poet's bio right before the poems, priming students to conflate author and speaker.

## ON_FAILURE
If a student conflates poet and speaker, have them: (1) Re-read the biographical note and underline facts about the poet's life. (2) Re-read the poem and underline every "I/my/me" statement. (3) Make a two-column table: "Poet's Life" vs. "Speaker's Words". (4) Identify three details in the poem that have no basis in the bio (e.g., the speaker in poem 2 says "I stand on the frontier" — the poet may never have been a soldier). (5) Rewrite one analytical paragraph using only column 2 evidence.

## BUILDS_ON
Class 11 character analysis skills (identifying traits, using textual evidence) from nodes like c11_hin_ar_cbse_01_004.

## LEADS_TO
Character Analysis: Supporting Characters (c12_hin_a_cbse_01_005) where students apply similar analytical lenses to secondary figures.

## PREREQUISITE_NODE_IDS
c12_hin_a_cbse_01_001, c12_hin_a_cbse_01_002, c12_hin_a_cbse_01_003, c11_hin_ar_cbse_01_004
## PREREQUISITE_REASONS
c12_hin_a_cbse_01_001: Provides context about the author and era essential to avoid poet-speaker confusion.
c12_hin_a_cbse_01_002: Understanding plot/narrative structure helps locate the protagonist's key moments in the poem's progression.
c12_hin_a_cbse_01_003: Setting and atmosphere shape the protagonist's emotional landscape (e.g., the night setting in poem 1).
c11_hin_ar_cbse_01_004: Class 11 foundation in character analysis terminology and evidence-based writing.

## FORWARD_NODE_IDS
c12_hin_a_cbse_01_005, c12_hin_a_cbse_01_006, c12_hin_a_cbse_01_013
## FORWARD_REASONS
c12_hin_a_cbse_01_005: Supporting characters are analyzed using the same evidence-based method established here.
c12_hin_a_cbse_01_006: The protagonist's journey is the primary vehicle for the primary theme; theme analysis builds on protagonist analysis.
c12_hin_a_cbse_01_013: Critical thinking requires synthesizing character, theme, and device analysis — all rooted in protagonist understanding.

## CROSS_SUBJECT_PREREQS
c11_hin_ar_cbse_01_004, c11_hin_ar_cbse_02_004
## CROSS_SUBJECT_REASONS
c11_hin_ar_cbse_01_004: Reinforces character analysis framework from previous year's Hindi Core (Aroh) textbook.
c11_hin_ar_cbse_02_004: Provides additional practice with a different protagonist in the same genre (poetry), strengthening transfer.

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_01_004 -> c12_hin_a_cbse_01_004 -> c12_hin_a_cbse_01_005

## THIS_FORMULA
PEEL (Point, Evidence, Explanation, Link) for character analysis paragraphs.

## FORMULA_VARIABLES
Point = Claim about protagonist's trait/state; Evidence = Specific line/image from poem (stanza reference); Explanation = How evidence proves the point using literary reasoning; Link = Connection to poem's central idea or protagonist's arc.

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
analytical

## CROSS_SUBJECT
N/A | The second poem's protagonist embodies the nationalist fervor studied in History (e.g., revolutionary poetry as historical source).
 N/A | The first protagonist's journey from despair to acceptance mirrors coping mechanisms (emotion-focused vs. problem-focused) in Psychology.
## PREREQ_CONCEPT
Ability to distinguish between author, narrator, and poetic persona — a concept introduced in Class 11 poetry analysis.

## PREREQ_BEFORE
Student must know how to identify first-person voice, metaphor, simile, and tone in a poem.

## PREREQ_STUCK
Review Class 11 node c11_hin_ar_cbse_01_004 (Character Analysis: Protagonist) for the PEEL framework and practice with a simpler poem.

## WORKED_EXAMPLE_1
PROBLEM: Analyze the protagonist's state of mind in the opening stanza of "nsolsuk dk xhr" (lines: "vkg! osnuk feyh fonkbZ! / eSaus Hkzeo'k thou lafpr] eèkqdfj;ksa dh Hkh[k yqVkbZA").
STEPS:
- Step 1: Identify the speaker's direct statements — "I have ended my life" and "broken the dreams of the beloved" are first-person declarations.
- Step 2: Note the opening exclamation "vkg! osnuk feyh fonkbZ!" — the address to "osnuk" (a term of endearment) establishes intimate tone and immediacy.
- Step 3: Examine the metaphors: "thou lafpr" (life completed/ended) and "Hkh[k yqVkbZ" (dreams broken) — both suggest finality and irreversible loss, not temporary sadness.
- Step 4: Connect to the stanza's closing rhetorical question: "ftldh laHkkouk ugha] ftls }kj ij vk, gq, ykSVk fn;k Fkk mlosQ fy, iqdkj epkuk D;k rsjs fy, vPNh ckr gS\" — the speaker questions the value of sympathy for one who already gave their heart, revealing wounded pride beneath despair.
- Step 5: Synthesize: The protagonist is in a state of devastated resignation, feeling that their total emotional investment has been met with indifference, and now even well-meaning comfort feels insulting.
REASONING: Each step moves from surface utterances to deeper psychological inference, using the poem's own logic (metaphor, rhetorical question) rather than external assumptions.
ANSWER: The protagonist's mind is characterized by a paradoxical mix of complete surrender ("thou lafpr") and fierce dignity ("iqdkj epkuk D;k"), revealed through metaphor and direct address.

## WORKED_EXAMPLE_2
PROBLEM: Show how the protagonist's identity in "dkusZfy;k dk xhr" is constructed through geographic imagery in the first two stanzas.
STEPS:
- Step 1: List all place-based images in stanza 1: "tgk¡ igq¡p vutku f{kfrt dks feyrk ,d lgkjk" (where elderly and children find shelter together), "ljl rkejl xHkZ foHkk ij" (blood-red soil on the frontier), "ukp jgh rjQf'k[kk euksgj" (fragrant breeze stays day and night).
- Step 2: List images in stanza 2: "fNVdk thou gfj;kyh ij" (fearless life on the peaks), "y?kq lqjèkuq ls ia[k ilkjs" (from snowy peaks to green valleys), "'khry ey; lehj lgkjs" (dark monsoon clouds arrive).
- Step 3: Analyze the progression: stanza 1 establishes the land as a nurturing home (intergenerational shelter, constant fragrance); stanza 2 elevates it to a majestic, challenging realm (peaks, fearless life, sweeping geography).
- Step 4: Infer the protagonist's self-placement: by describing the land so intimately, the speaker identifies as its native guardian — one who knows every mood (breeze, monsoon) and every inhabitant (elderly, children).
- Step 5: Link to the protagonist's declaration in stanza 3: "mM+rs [kx ftl vksj eq¡g fd,µle> uhM+ fut I;kjk" (where rising sun kisses the high mountains) — the protagonist claims the land's most sublime moment as their own witness.
REASONING: The protagonist never says "I am a patriot"; instead, the accumulation of possessed geographic knowledge ("tgk¡", "ftl vksj") constructs identity implicitly.
ANSWER: The protagonist's identity as a rooted, watchful patriot emerges from the poet's choice to map the motherland through the speaker's all-encompassing gaze.

## WORKED_EXAMPLE_3
PROBLEM: Compare how the two protagonists use the motif of "night" — in "nsolsuk dk xhr" ("vk¡lw&ls fxjrs Fks izfr{k.k" — shadows fleeing from night) and in "dkusZfy;k dk xhr" (implied in "ukp jgh rjQf'k[kk euksgj" — fragrance stays day and night). What does this contrast reveal about their central conflicts?
STEPS:
- Step 1: In poem 1, night is associated with loss: "vk¡lw&ls fxjrs Fks izfr{k.k" (memories/shadows flee from night) and "jgh cpk, fiQjrh dcdh" (the night passed, but the lamp burned low) — night erodes the protagonist's past.
- Step 2: In poem 2, night is a time of continuity: "ukp jgh rjQf'k[kk euksgj" (fragrant breeze stays day and night) and "efnj m¡Q?krs jgrs tcµtxdj jtuh Hkj rkjk" (while stars blink, the vigil continues) — night is when the protagonist's watchfulness is tested and proven.
- Step 3: Identify the protagonist's relationship to night: Poem 1 protagonist is a victim of night (it steals memories, dims the lamp); Poem 2 protagonist is a master of night (it is the arena of their duty).
- Step 4: Connect to central conflict: Poem 1 conflict is internal — the protagonist battles the erosion of love by time/indifference; Poem 2 conflict is external — the protagonist battles threats to the motherland, with night as the testing ground.
- Step 5: Synthesize: The same motif (night) structures two opposite protagonist roles — passive sufferer vs. active sentinel — mirroring the poems' themes (personal grief vs. collective duty).
- Step 6: Note the structural echo: both poems use night as a temporal boundary, but poem 1 ends with night's victory ("fo'o! u l¡Hkysxh ;g eq>ls"), poem 2 ends with the protagonist's vow transcending night ("txdj jtuh Hkj rkjk").
REASONING: This comparison requires tracking a single motif across two texts, analyzing its function in each protagonist's arc, and linking to thematic divergence — a high-order skill for board and competitive exams.
ANSWER: Night exposes the first protagonist's helplessness against time, while it affirms the second protagonist's agency as a guardian; the motif thus becomes a lens to distinguish personal tragedy from national resolve.

## COMPETENCY_QUESTION_1
QUESTION: A Class 12 student writes in the board exam: "The protagonist of 'nsolsuk dk xhr' is Tulsidas himself, who was heartbroken in real life." Identify the conceptual error, explain why it loses marks, and rewrite the opening sentence of a correct analysis.
COMPETENCY: Critical Thinking — distinguishing author from persona
STEPS:
- Step 1: Identify the error — conflating the poet's biography with the poetic speaker.
- Step 2: Explain the marking impact — CBSE marking scheme awards zero for biographical substitution; analysis must be text-internal.
- Step 3: Provide a correct opening sentence that focuses on the speaker's textual construction.
- Step 4: Show how the correct opening enables evidence-based analysis.
ANSWER: Error: The student treats the poem as autobiography. The poem is a crafted persona; nowhere does the text name the speaker as Tulsidas. Marks lost: Content (0/2) because the answer does not analyze the poem. Correct opening: "The speaker in 'nsolsuk dk xhr' is a constructed persona who embodies the anguish of unrequited devotion, revealed through first-person metaphors of finality and wounded dignity."
DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: Using the PEEL framework, write a complete analytical paragraph (80-100 words) on how the protagonist of "dkusZfy;k dk xhr" transforms from an observer of the land to its sworn protector. Use at least two specific images from different stanzas.
COMPETENCY: Structured Analytical Writing — evidence-based character arc analysis
STEPS:
- Step 1: Write a clear Point sentence stating the transformation.
- Step 2: Select Evidence: one image from early stanzas (observer), one from later stanzas (protector).
- Step 3: Write Explanation for each, linking image to protagonist's shifting stance.
- Step 4: Write Link connecting the arc to the poem's patriotic theme.
- Step 5: Check word count and flow; ensure Hindi terms are transliterated or explained.
ANSWER: The protagonist in "dkusZfy;k dk xhr" evolves from a celebratory observer to a solemn guardian. Initially, he maps the land with sensory intimacy — "ukp jgh rjQf'k[kk euksgj" (fragrant breeze stays day and night) — positioning himself as a native who knows every mood. By the final couplet, he becomes the land's active sentinel: "efnj m¡Q?krs jgrs tcµtxdj jtuh Hkj rkjk" (while stars blink, the vigil continues). This shift from passive witness ("ukp jgh") to eternal watchman ("jtuh Hkj") mirrors the poem's movement from descriptive patriotism to committed sacrifice. The protagonist's identity thus merges with the motherland's endurance.
DIFFICULTY: hard