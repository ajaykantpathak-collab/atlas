## DEFINITION
Vocabulary in context refers to the skill of determining the precise meaning of a word or phrase by analyzing how it is used within a specific textual passage, rather than relying solely on its dictionary definition. It requires examining surrounding sentences, the speaker's tone, the narrative situation, and the author's intent to arrive at the contextual significance that the word carries in that particular moment.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student must be able to: (1) Identify the contextual meaning of at least 5 key words from the chapter "xyrk yksgk" by citing the specific textual evidence that shapes that meaning, and (2) Explain in writing how the contextual meaning differs from or enriches the standard dictionary definition for each word, using the PEEL structure (Point, Evidence, Explanation, Link).

## SCOPE_BOUNDARY
This node covers the 10-12 key vocabulary items explicitly listed in the "Hkk"kk dh ckr" section of the NCERT textbook for Chapter 5 ("xyrk yksgk"), focusing on how their meanings are activated by the story's caste-conflict setting, rural Uttar Pradesh dialect, and the protagonist Ehsan's psychological journey. It does NOT cover general vocabulary building strategies, synonyms/antonyms drills, or grammar rules (which are addressed in node c11_hin_ar_cbse_05_011).

## WALKTHROUGH
Imagine you overhear a friend say "Usne mere saath bada 'khel' kiya" - you know 'khel' means 'game', but here it clearly means 'deception' or 'betrayal'. That shift from dictionary meaning to contextual meaning is exactly what this skill tackles. In "xyrk yksgk", words like /kSaduh, l¡M+lh, gFkkSM+k carry the weight of rural caste hierarchy and Ehsan's humiliation. To begin, re-read the 2-3 sentences before and after each target word in the text. Ask: Who is speaking? What is the power dynamic? What emotion colors this moment? The key insight: in senior secondary exams, you are never asked for a dictionary meaning; you are asked "Is prasang mein 'shabd' ka kya arth hai?" - and the answer must quote the context.

## DIAGNOSTIC_QUESTION_1
What is the dictionary meaning of the word "/kSaduh" as provided in the textbook's 'kCn&Nfo section, and which character in the story is associated with this occupation?

## DIAGNOSTIC_ANSWER_1
The textbook defines /kSaduh as "yqgkj ;k lqukjksa dh vkx ngdkus okyh yksgs ;k ck¡l dh uyh" (a woman who pierces ears/nose for ornaments, or a needle-like tool). In the story, Ehsan's mother (firk) is associated with this work - she goes house to house doing /kSaduh to earn money. A wrong answer (e.g., saying it means 'sewing' or associating it with Ehsan's father) reveals the student has not consulted the textbook glossary or cannot link the vocabulary entry to the narrative detail.

## DIAGNOSTIC_QUESTION_2
In the sentence "firk dh ckrsa lqudj Hkh mlus mudk Hkkj gydk djus dk u mls vH;kl gh gS vkSj u oSlh xfr" (p. 57), the word "vH;kl" appears. The glossary does not list this word. Using contextual clues, explain what "vH;kl" means here and why the author chooses this specific word instead of a simpler synonym like "yksx" (skill) or "tkudkjh" (knowledge).

## DIAGNOSTIC_ANSWER_2
Contextually, "vH;kl" means "practice/experience/habit born of repeated doing" - the mother has no *practice* of refusing the landlord's son, no *experience* of saying no to feudal authority. The author chooses "vH;kl" over "yksx" because it implies a bodily, habitual conditioning from generations of subservience, not a learnable skill. A wrong answer giving only "knowledge/skill" misses the nuance of *internalized oppression* that "vH;kl" carries in this feudal context.

## DIAGNOSTIC_QUESTION_3
Apply the context-analysis method to the word "izfr}a}h" (listed in the glossary as "eqdkcyk djus okyk, foi{kh, fojks/h, izfri{kh"). In the passage "f=kyksd flag ekLVj dk ;g lkekU; fu;e FkkA ltk ikus okys dks gh vius fy, gfFk;kj Hkh tqVkuk gksrk Fkk_ vkSj ”kkfgj gS] cfy dk cdjk vius ls vfèkd ekLVj osQ larks"k dks è;ku esa j[kdj Vguh dk pquko ,sls djrk tSls og vius fy, ugha cfYd fdlh nwljs dks nafMr djus osQ fy, gfFk;kj dk pquko dj jgk gksA" (p. 59), what specific shade of "izfr}a}h" is activated, and how does the context modify the glossary definition?

## DIAGNOSTIC_ANSWER_3
Steps: (1) Glossary gives: devoted, loyal, obedient, servant-like. (2) Context: Thakur Phoolchand makes *Ehsan* (a child) do *his* penance (gfFk;kj) to ward off *Thakur's own* death-fear. (3) The shade activated: "self-sacrificing devotion imposed by power" - not voluntary loyalty but coerced servitude disguised as duty. (4) Modification: The glossary's positive/neutral terms (foi{kh, fojks/h) become ironic; the context reveals izfr}a}h as a tool of exploitation. A wrong answer merely copies the glossary without the ironic inversion shows inability to read against the grain.

## DIAGNOSTIC_QUESTION_4
Compare the contextual meanings of "gFkkSM+k" and "?kfl;kjs" - both glossed as "?kkl dkVus dk dke djus okys" (one who cuts grass/fodder). In the story, Ehsan is called "gFkkSM+k" by Thakur's household (p. 56: "gFkkSM+s dh èki~&èki~ vkok”k"), while the actual grass-cutters are "?kfl;kjs". Analyze why the author uses two different words for the same dictionary meaning, and what each word reveals about the speaker's attitude and the social hierarchy.

## DIAGNOSTIC_ANSWER_4
"gFkkSM+k" (used by Thakur's household for Ehsan) is a *caste-identity label* - it reduces the boy to his lowest hereditary occupation, stripping his name and student identity. "?kfl;kjs" (p. 60: "vuqHkoh ?kfl;kjksa us rs”kh ls ikuh dks dkVdj") is a *functional descriptor* for actual laborers doing the work. The author's choice exposes: (1) For the feudal lords, Ehsan *is* his caste (gFkkSM+k = identity trap); (2) For the narrative voice describing real workers, ?kfl;kjs = occupational role. A wrong answer saying "they mean the same thing" misses the central theme of caste-as-identity vs. work-as-function.

## DIAGNOSTIC_QUESTION_5
Evaluate the interpretation: "The word 'laVh' (gloss: iryh MaMh ;k NM+h) in the sentence 'lVkd~! ,d laVh mldh fiaMfy;ksa ij ekLlkc us yxkbZ Fkh' (p. 58) is used literally to mean a physical stick/staff that Thakur's wife uses to hit Ehsan." Defend or refute using textual evidence.

## DIAGNOSTIC_ANSWER_5
Refute. Context: "lVkd~! ,d laVh mldh fiaMfy;ksa ij ekLlkc us yxkbZ Fkh fd og VwV xbZA" - Thakur's wife places a *laVh* on his *shadow* to stop him from leaving. In rural folk belief, stepping on/stopping a person's shadow (fiaMfy;) with a stick (laVh) is a magical ritual to bind/stop them, not a physical beating. The word carries *superstitious/ritualistic* weight, not literal violence. A wrong answer taking it literally misses the cultural context of folk magic that the story uses to show the Thakurain's desperate, irrational control over Ehsan.

## DIAGNOSTIC_QUESTION_6
Create a new sentence using the word "vuqxw¡t" (gloss: izfrèofu] jg&jgdj dkuksa esa xw¡tus okyh vkok”k) that captures its contextual force in the story's opening paragraph: "eksgu osQ iSj vuk;kl gh f'kYidkj Vksys dh vksj eqM+ x,A mlosQ eu osQ fdlh dksus esa 'kk;n èkujke yksgkj osQ vkiQj dh og vuqxw¡t 'ks"k Fkh..." Your sentence must show the word describing a *mental state*, not a physical wait.

## DIAGNOSTIC_ANSWER_6
Example: "Pratiksha ke teen ghante baad bhi, uska man usi vuqxw¡t avastha mein tha - na gussa, na udaasi, sirf ek thithuri hui prateeksha jaise koi faisla ab bhi uske haath mein na ho." (Even after three hours of waiting, his mind remained in that same vuqxw¡t state - neither anger nor sadness, just a frozen waiting as if the decision was still not in his hands.) A poor answer uses it for a bus stop wait ("Main bus stop par vuqxw¡t khada tha"), missing the *helpless, internally suspended, psychologically heavy* quality the story gives it.

## COMMON_MISCONCEPTION
Students believe "vocabulary in context" means "find the dictionary meaning that fits best." They treat the glossary as the answer key and the text as a fill-in-the-blank. For example, seeing "vkiQj" glossed as "fcuk iz;kl osQ" (without order/system), they write "Ehsan's life was vkiQj = disordered" and stop. They miss that in the sentence "g¡lqos dh èkkj ij gkFk isQjrs gq, mls yxk og iwjh rjg oqaQn gks pqdh gSA" (p. 57), "vkiQj" describes the *sudden, unannounced, rule-less arrival of crisis* in a feudal household - the word carries the *terror of arbitrariness*, not just messiness. This error stems from Class 10 "word-meaning" questions where one-word answers sufficed; Class 11 demands "contextual significance" (prasangik arth).

## ON_FAILURE
If a student gives glossary-only meanings: (1) Return them to the exact paragraph where the word appears. (2) Ask: "Who is speaking/seeing this? What power do they hold? What is at stake?" (3) Have them rewrite the sentence replacing the target word with its glossary meaning - they will hear the loss of force. (4) Assign: "Write two sentences for each word: one using the dictionary meaning, one using the story's meaning. Explain the difference in 30 words." This forces the distinction between *denotation* and *contextual connotation*.

## BUILDS_ON
This node builds on c11_hin_ar_cbse_05_002 (Text: Plot and Narrative Structure) because without knowing the story's events, power dynamics, and Ehsan's trajectory, the contextual clues for each word are invisible.

## LEADS_TO
This node enables c11_hin_ar_cbse_05_012 (Comprehension: Literal and Inferential Questions) because comprehension answers require precise, contextually-grounded vocabulary to articulate inferences about character motivation and theme.

## PREREQUISITE_NODE_IDS
c11_hin_ar_cbse_05_001, c11_hin_ar_cbse_05_002, c11_hin_ar_cbse_05_008, c11_hin_ar_cbse_05_009, c11_hin_ar_cbse_05_004, c11_hin_ar_cbse_05_005

## PREREQUISITE_REASONS
c11_hin_ar_cbse_05_001: The "Before You Read" context on Shivani's background, the New Story Movement, and the feudal setting provides the socio-historical lens without which words like gFkkSM+k, izfr}a}h, laVh cannot be contextually decoded.
c11_hin_ar_cbse_05_002: The plot and narrative structure node establishes the sequence of events, character relationships, and the two timelines (childhood vs. adulthood) that determine which contextual meaning activates at which point in the story.
c11_hin_ar_cbse_05_008: Vocabulary in context requires understanding metaphorical usage of words (e.g., "ltZd", "ped").  
c11_hin_ar_cbse_05_009: Vocabulary work (e.g., izfr}a}h, laVh) deepens when students grasp their symbolic weight.  
c11_hin_ar_cbse_05_004: If stuck, review the character analysis of Thakur Phoolchand Singh (c11_hin_ar_cbse_05_004) and Ehsan (c11_hin_ar_cbse_05_005) - every key vocabulary word in this chapter is filtered through their opposing positions.  
c11_hin_ar_cbse_05_005: If stuck, review the character analysis of Thakur Phoolchand Singh (c11_hin_ar_cbse_05_004) and Ehsan (c11_hin_ar_cbse_05_005) - every key vocabulary word in this chapter is filtered through their opposing positions.  

## FORWARD_NODE_IDS
c11_hin_ar_cbse_05_012, c11_hin_ar_cbse_05_013, c11_hin_ar_cbse_05_011, c11_hin_ar_cbse_05_015, c12_hin_a_cbse_01_010, c12_hin_a_cbse_05_010, c12_hin_a_cbse_07_010, c12_hin_al_cbse_02_010, c12_hin_ar_cbse_05_010, c12_hin_ar_cbse_12_010

## FORWARD_REASONS
c11_hin_ar_cbse_05_012: Comprehension questions (literal and inferential) require students to use contextually precise vocabulary to frame answers - e.g., explaining Ehsan's "izfr}a}h" not as "loyalty" but as "coerced servitude" changes the entire answer's quality.
c11_hin_ar_cbse_05_013: Critical thinking/analysis questions demand vocabulary as analytical tools - e.g., analyzing the "vuqxw¡t" state as a metaphor for Dalit psychological suspension requires the contextual depth built here.
c11_hin_ar_cbse_05_011: Vocabulary node provides meanings of key grammatical terms (ykSgdeZ, samasa, loZuke) and dialect words used in exercises.  
c11_hin_ar_cbse_05_015: Key vocabulary (izfr}a}h, fo|kO;luh, lsozsQVsfj;V) enables precise academic discourse.  
c12_hin_a_cbse_01_010: Introduced CBSE 'आशय स्पष्ट कीजिए' pattern — this node applies it to Class 12 texts.  
c12_hin_a_cbse_05_010: Class 11 vocabulary node establishes the method of contextual analysis; Class 12 deepens it with more complex poems.  
c12_hin_a_cbse_07_010: Developed habit of reading aloud for phonetic cues to meaning.  
c12_hin_al_cbse_02_010: Prior work on glossary-based vocabulary exercises.  
c12_hin_ar_cbse_05_010: Provides the foundational framework of denotation/connotation/tonal analysis that this node deepens for experimental poetry.  
c12_hin_ar_cbse_12_010: Introduced cultural-connotation layer in vocabulary — essential for "gj&NB", "nlrik" etc.  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
none

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_05_001 -> c11_hin_ar_cbse_05_002 -> c11_hin_ar_cbse_05_010 -> c11_hin_ar_cbse_05_012 -> c11_hin_ar_cbse_05_013

## THIS_FORMULA
Contextual Meaning = Dictionary Definition + (Speaker/Character Perspective × Power Dynamic) + (Narrative Moment × Thematic Weight) + Cultural/Idiomatic Resonance

## FORMULA_VARIABLES
- Dictionary Definition: The standard glossary meaning provided in textbook
- Speaker/Character Perspective: Who uses/thinks the word (feudal lord, victim, narrator, folk voice)
- Power Dynamic: The caste/class/gender hierarchy operating in that scene
- Narrative Moment: Childhood trauma vs. adult reflection; crisis vs. routine
- Thematic Weight: How the word serves the story's central themes (caste, dignity, exploitation, resistance)
- Cultural/Idiomatic Resonance: Folk beliefs, rural idioms, ritual meanings (e.g., laVh on shadow)

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
linguistic

## CROSS_SUBJECT
c11_history_medieval_india | Understanding feudal vocabulary (zamindar, begar, jajmani) requires the same contextual analysis: words carry different weights when spoken by the landlord vs. the peasant, just as gFkkSM+k differs in Thakur's mouth vs. narrator's pen.
c11_economics_rural_development | Terms like "marginal farmer," "bonded labor," "minimum support price" shift meaning in policy documents vs. farmer protests vs. World Bank reports - identical to how izfr}a}h shifts from "devotion" (glossary) to "exploitation" (story context).

## PREREQ_CONCEPT
The prerequisite concept is "narrative point of view and power dynamics in feudal rural society" - without grasping who holds power and who suffers it in each scene, contextual vocabulary collapses to dictionary definitions.

## PREREQ_BEFORE
Before starting this node, the student must have read the full story "xyrk yksgk" at least once and completed the plot/character nodes (c11_hin_ar_cbse_05_002, 004, 005) to know Ehsan's two timelines and the Thakur household's power structure.

## PREREQ_STUCK
If stuck, review the character analysis of Thakur Phoolchand Singh (c11_hin_ar_cbse_05_004) and Ehsan (c11_hin_ar_cbse_05_005) - every key vocabulary word in this chapter is filtered through their opposing positions.

## WORKED_EXAMPLE_1
PROBLEM: Analyze the contextual meaning of "fugkbZ" in the passage: "eksgu oqQN nsj rd mls dke djrs gq, ns[krk jgk fiQj tSls viuk ladksp R;kxdj mlus nwljh idM+ ls yksgs dks fLFkj dj fy;k vkSj èkujke osQ gkFk ls gFkkSM+k ysdj uih&rqyh pksV ekjrs] vH;Lr gkFkksa ls èkkSaduh i¡wQddj yksgs dks nqckjk Hk_h esa xje djrs vkSj fiQj fugkbZ ij j[kdj mls Bksdrs&ihVrs lq?kM+ xksys dk :i ns MkykA" (p. 63). How does the context transform the glossary definition ("fo'ks"k izdkj dk yksgs dk Bksl VqdM+k")?

STEPS:
- Step 1: Identify the glossary meaning - a specialized saddle/seat for riding horses, a physical object for sitting.
- Step 2: Locate the word in the passage - "fugkbZ ij j[kdj mls Bksdrs&ihVrs lq?kM+ xksys dk :i ns Mkyk" - Ehsan places the *horse* on the fugkbZ and gives it the form of a dancing/prancing horse.
- Step 3: Analyze the action - Ehsan is not sitting on a saddle; he is *making the horse stand on its hind legs* (Bksdrs&ihVrs) and *shaping it into a prancing form* (lq?kM+ xksys dk :i). The fugkbZ here is the *horse's own body/haunches* become the base.
- Step 4: Determine the shift - The word moves from noun (object: saddle) to locative-adverbial (position: "on the haunches/rearing up"). The context forces a metonymic shift: the saddle's location → the horse's posture.
- Step 5: Connect to theme - This moment shows Ehsan's mastery over the animal, contrasting his total powerlessness before Thakur. The "fugkbZ" becomes the site where he *controls* a powerful beast, unlike his life where he is controlled.
REASONING: The steps move from static definition to dynamic scene analysis, tracking how verb semantics (j[kdj, ns Mkyk) reshape noun meaning, and linking to the story's central power/reversal motif.
ANSWER: In this context, "fugkbZ" does not mean "saddle." It means "the horse's rearing haunches/haunch-position" - the physical base created by the horse's own body when forced onto hind legs. The glossary gives the equestrian equipment term; the context reveals the *bodily reality* of the riding moment. This shift from equipment to anatomy mirrors Ehsan's shift from being a tool (equipment) in Thakur's hands to a rider (agent) on the horse's back.

## WORKED_EXAMPLE_2
PROBLEM: The word "vuk;kl" (gloss: fcuk iz;kl osQ - without arrangement/system) appears in the opening line: "eksgu osQ iSj vuk;kl gh f'kYidkj Vksys dh vksj eqM+ x,A" (p. 56). Explain how the contextual meaning exceeds the glossary definition, using the very next sentence: "mlosQ eu osQ fdlh dksus esa 'kk;n èkujke yksgkj osQ vkiQj dh og vuqxw¡t 'ks"k Fkh ftls og fiNys rhu&pkj fnuksa ls nqdku dh vksj tkrs gq, nwj ls lqurk jgk FkkA"

STEPS:
- Step 1: Note the glossary meaning - "without arrangement, unsystematic, haphazard."
- Step 2: Analyze the syntactic slot - "iSj vuk;kl" modifies "f'kYidkj Vksys" (intense heat of afternoon). It's not "a haphazard afternoon" but "an afternoon *without the arrangement/relief of*..."
- Step 3: Read the next clause - "mlosQ eu osQ fdlh dksus esa..." - Ehsan has *no expectation/relief* in his heart. The "vuk;kl" outside (no shade, no breeze, no water) mirrors the "vuk;kl" inside (no hope, no respite).
- Step 4: Identify the semantic expansion - "vuk;kl" becomes "total absence of mitigating structure" - physical (no shade/tree/water), temporal (endless afternoon), psychological (no hope), and social (no protector).
- Step 5: Link to the "vuqxw¡t 'ks"k" - The waiting cry is "vuqxw¡t" (helpless, suspended) *because* the world is "vuk;kl" (structureless, mercy-less). The two words form a semantic pair: external chaos ↔ internal paralysis.
REASONING: This example demonstrates how a simple negative prefix (vu- + k;kl) expands into a totalizing condition when the narrative juxtaposes physical environment with internal state - a classic literary device (pathetic fallacy) that the glossary cannot capture.
ANSWER: Contextually, "vuk;kl" means "utterly devoid of any relieving structure - no shade, no breeze, no water, no hope, no protector, no end in sight." It is not merely "disorganized"; it is *existentially bare*. The glossary gives a spatial/administrative sense (lack of arrangement); the context gives an *ontological* sense (lack of mercy/order/justice). The afternoon is vuk;kl because the feudal world offers Ehsan no arrangement of dignity.

## WORKED_EXAMPLE_3
PROBLEM: Compare the contextual trajectories of two words across the story: "gFkkSM+k" (grass-cutter, low-caste label) and "izfr}a}h" (devoted servant). Trace how each word's contextual meaning shifts from Part 1 (Ehsan's childhood) to Part 2 (Ehsan's adulthood return), and explain what the shifts reveal about the story's theme of "caste as inescapable identity vs. education as failed escape."

STEPS:
- Step 1: Establish Part 1 context for "gFkkSM+k" - Thakur's household calls child Ehsan "gFkkSM+k" (p. 56: "gFkkSM+s dh èki~&èki~ vkok”k"). It is an *identity imposition*: you are your caste, not a student.
- Step 2: Establish Part 1 context for "izfr}a}h" - Thakur makes Ehsan do penance (gfFk;kj) for Thakur's own death-fear (p. 59). Izfr}a}h = *coerced self-sacrifice* disguised as duty.
- Step 3: Trace Part 2 (adulthood) for "gFkkSM+k" - Ehsan returns educated (p. 62: "èkujke us Hkh ,d fnu muls eksgu osQ ckjs esa iwNk Fkk... mldh lsØsVsfj;V esa fu;qfDr gks xbZ gS"). Thakur's wife *still* calls him "gFkkSM+k" implicitly by treating him as servant. The word *refuses to update* despite his degree.
- Step 4: Trace Part 2 for "izfr}a}h" - Ehsan *performs* izfr}a}h (touches Thakur's feet, serves) but his internal monologue shows *alienation* (p. 64: "èkujke dh ladksp] vleatl vkSj èkeZ&ladV dh fLFkfr ls mnklhu eksgu larq"V Hkko ls..."). Izfr}a}h becomes *performative*, not internalized.
- Step 5: Synthesize the divergence - "gFkkSM+k" remains *externally imposed and frozen* (society won't let him escape); "izfr}a}h" becomes *internally hollowed out* (he performs it but feels nothing). The first shows caste's external grip; the second shows education's failure to liberate the soul.
- Step 6: Formulate the thematic insight - The vocabulary trajectory proves the story's thesis: "Education changes your degree, not your caste-label (gFkkSM+k); it makes your devotion a performance (izfr}a}h), not a feeling."
REASONING: This multi-step analysis meets the senior secondary requirement of tracing lexical semantics across narrative time and linking to thematic architecture - exactly what board "analytical/evaluative" questions demand.
ANSWER: "gFkkSM+k" contextually hardens from "caste-occupation label" (childhood) to "inescapable social identity that erases educational achievement" (adulthood). "izfr}a}h" contextually hollows from "coerced devotion mistaken for duty" (childhood) to "empty performance masking alienation" (adulthood). Together, they map the story's tragic arc: the label sticks, the devotion breaks. A board-level answer would quote: "eksgu yyk cpiu ls gh cM+s cqf¼eku Fks" (p. 62) for gFkkSM+k's persistence, and "mldh vk¡[kksa esa ,d ltZd dh ped Fkh" (p. 64) for izfr}a}h's death.

## COMPETENCY_QUESTION_1
QUESTION: In the sentence "f=kyksd flag ekLVj us mls iwjs LowQy dk ekWuhVj cuk j[kk Fkk" (p. 58), the word "ekWuhVj" is not in the textbook glossary. Using contextual clues from the entire Thakur-Ehsan relationship, explain the precise contextual meaning of "ekWuhVj" here. Why does the author choose this specific metaphor (ekWuhVj = pawn/collateral) rather than "naukari" (service) or "bandhua" (bonded labor)?

COMPETENCY
Contextual Lexical Inference and Authorial Choice Analysis

STEPS:
- Step 1: Identify the literal meaning of "ekWuhVj" - a pawned object, collateral kept against a loan, something held hostage until debt is paid.
- Step 2: Map to the context - Thakur has made Ehsan's *entire LowQy (service/servitude)* into an ekWuhVj. Not a specific loan, but his lifelong service is the "collateral."
- Step 3: Analyze the power dynamic - A pawn (ekWuhVj) has *no agency*, *no voice*, *no exit* until the owner (Thakur) releases it. Unlike "naukari" (contractual, quittable) or "bandhua" (legal category), "ekWuhVj" implies *total ownership by another* and *conditional existence*.
- Step 4: Connect to the story's central metaphor - Ehsan's life is not his own; it is "pawned" to Thakur from birth. The metaphor captures the *hereditary, inescapable, object-like* nature of his bondage.
- Step 5: Formulate the answer - "ekWuhVj" means "a human life held as collateral property." The author chooses it over naukari/bandhua because it conveys *absolute rightlessness* and *hereditary mortgaging* - Ehsan didn't sign a contract; he was born into the pawn.
ANSWER: Contextually, "ekWuhVj" means "a human existence mortgaged as collateral property, with zero autonomy and no redemption clause." The author rejects "naukari" (implies contract/wages/choice) and "bandhua" (implies a legal status that can be abolished) because "ekWuhVj" captures the *feudal logic*: Ehsan's life belongs to Thakur like a pawned ornament - to be used, risked, or forfeited at the owner's whim. The word carries the chill of *property*, not *person*.
DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: The story uses "lsozsQVsfj;V" (gloss: lfpoky; - retirement/pension) ironically in the context of Thakur Phoolchand Singh's anxiety about death: "?kkl dk ,d frudk rksM+dj nk¡r [kksnrs gq, mUgksaus crk;k Fkk fd mldh lsØsVsfj;V esa fu;qfDr gks xbZ gS vkSj 'kh?kz gh foHkkxh; ijh{kk,¡ nsdj og cM+s in ij igq¡p tk,xkA" (p. 62). However, the word *actually* applies to Ehsan's fate in the final paragraph. Analyze this ironic transference and explain how the vocabulary shift from Thakur to Ehsan encapsulates the story's critique of feudal modernity.

COMPETENCY
Irony Detection and Thematic Vocabulary Mapping

STEPS:
- Step 1: Note the literal usage - Thakur's *son* has got "lsØsVsfj;V" (pension/retirement benefits) and a government job. This is "modernity" - merit-based, contractual, state-protected.
- Step 2: Note the irony - Thakur *boasts* of this modern achievement to Ehsan, whose father did /kSaduh (traditional caste labor). The feudal lord celebrates *his* son's escape from feudalism via modernity.
- Step 3: Trace the transference - In the final paragraph (p. 64), Ehsan is described: "mldh vk¡[kksa esa ,d ltZd dh ped Fkhµ ftlesa u LièkkZ Fkh vkSj u gh fdlh izdkj dh gkj&thr dk Hkko." He has *no* lsozsQVsfj;V - no pension, no retirement, no security. His "retirement" is death in harness.
- Step 4: Analyze the structural irony - The word "lsozsQVsfj;V" (a modern bureaucratic term) enters the feudal household *only* for the oppressor's son. The oppressed (Ehsan) remains in pre-modern bondage *despite* his own education (he too has a degree, p. 62).
- Step 5: Synthesize the critique - The vocabulary shift exposes: Feudalism adopts modernity *selectively* - for its own reproduction (Thakur's son gets lsozsQVsfj;V), while the Dalit (Ehsan) gets *neither* feudal patronage (Thakur discards him) *nor* modern security (no job, no pension). The word "lsozsQVsfj;V" becomes the measure of *who belongs to the new India*.
ANSWER: The irony operates at three levels: (1) Situational - Thakur, the feudal relic, celebrates a modern bureaucratic term (lsozsQVsfj;V) for his son. (2) Structural - The term is *denied* to Ehsan despite his identical educational qualification (fu;qfDr). (3) Existential - Ehsan's "lsozsQVsfj;V" is the "ltZd dh ped" (dead man's shadow) in his eyes - his retirement is only death. The vocabulary shift from Thakur's pride to Ehsan's void maps the story's central thesis: In feudal modernity, caste determines who gets the *words* of the new order (pension, job, rights) and who remains trapped in the *silences* of the old order (bondage, anonymity, "fugkbZ ij j[kdj... Bksdrs&ihVrs" - performing on the master's terms till the end).
DIFFICULTY: hard