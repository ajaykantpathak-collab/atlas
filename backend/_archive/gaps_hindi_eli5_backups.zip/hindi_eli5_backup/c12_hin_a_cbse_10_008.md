## DEFINITION
Imagery (चित्रात्मकता) refers to the use of vivid, sensory language that appeals to the five senses (sight, sound, smell, touch, taste) to create mental pictures and evoke physical sensations in the reader's mind. Metaphor (रूपक/प्रतीक) is a figure of speech that directly compares two unrelated things by stating one *is* the other, transferring qualities from the source domain to the target domain without using comparative words like "like" or "as" (unlike simile). In Hindi prose, these devices transform abstract experiences (memory, emotion, intellectual growth) into concrete, relatable sensory experiences.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student can independently identify specific instances of imagery and metaphor in the prescribed text, classify the sensory mode of each image, explain the comparative logic of each metaphor (tenor/vehicle/ground), and write a structured 4-point board answer linking the device to the author's purpose (character revelation, theme development, atmosphere creation).

## SCOPE_BOUNDARY
This node covers **only** imagery (visual, auditory, olfactory, tactile, kinesthetic) and metaphor (simple, extended, implied) as they appear in the Chapter 10 prose text "जयशंकर प्रसाद" (Ramchandra Shukla's autobiographical sketch). It does NOT cover irony, symbolism, personification, or other figures of speech (those are in node c12_hin_a_cbse_10_009). It does NOT require analyzing poetry; the focus is prose narrative.

## WALKTHROUGH
Imagine you are reading Shukla's description of his childhood home in Kashi: the "narrow lanes," the "smell of damp earth," the "sound of temple bells." You instantly *see* the alley, *smell* the mud, *hear* the bells. That is imagery doing its work. Now ask: *Why did he choose those specific sensations?* Because they build the atmosphere of a traditional, scholarly Brahmin household — the setting that shaped his intellect. Next, notice when he calls his father's library a "मंदिर" (temple) or his intellectual awakening a "नई रोशनी" (new light). He is not just describing; he is *equating* one thing with another to transfer sanctity or illumination. That is metaphor. To master this node: (1) Read a passage aloud, (2) Highlight every sensory word, (3) Label the sense, (4) Find direct comparisons without "जैसे/वैसे", (5) Ask: "What quality is being transferred?" (6) Write the answer using the PEEL structure: Point (device identified), Evidence (quote), Explanation (sensory effect/comparative logic), Link (connection to theme/character).

## DIAGNOSTIC_QUESTION_1
Define 'imagery' (चित्रात्मकता) in the context of Hindi prose. List the five sensory types with one Hindi example word for each (e.g., visual: 'नील गगन').

## DIAGNOSTIC_ANSWER_1
**Correct Answer:** Imagery is the use of descriptive language appealing to the five senses to create mental representations. Five types: 1. Visual (दृश्य) — e.g., 'पीला पत्ता', 2. Auditory (श्रव्य) — e.g., 'मंदिर का घंटा', 3. Olfactory (घ्राण) — e.g., 'गुलाब की गंध', 4. Tactile (स्पर्श) — e.g., 'ठंडी हवा', 5. Gustatory (स्वाद) — e.g., 'मीठा आम'. Kinesthetic (गति/आंतरिक संवेदना) is often added as a sixth.
**Wrong Answer Reveals:** If a student gives only "description" or "picture-making" without sensory classification, they confuse imagery with general adjectives. If they miss olfactory/tactile, they rely only on visual memory — a common gap because textbooks over-emphasize visual imagery. If they cannot produce Hindi examples, they lack textual vocabulary.

## DIAGNOSTIC_QUESTION_2
In the text, Shukla writes: "पंडित जी के यहाँ पुस्तकों का एक बड़ा संग्रह था... वह मेरे लिए एक मंदिर के समान था।" Identify the figure of speech. Is it a metaphor or a simile? Justify your answer using the specific marker word.

## DIAGNOSTIC_ANSWER_2
**Correct Answer:** It is a **simile (उपमा)**, not a metaphor. The marker word **"के समान" (like/as)** explicitly signals a comparison. A metaphor would state "पुस्तकों का संग्रह एक मंदिर *था*" (was a temple) without the comparative particle.
**Wrong Answer Reveals:** If the student says "metaphor," they cannot distinguish direct equation (metaphor) from explicit comparison (simile) — a critical board exam distinction. If they identify the comparison but miss the marker "के समान," they are guessing based on meaning rather than linguistic form. This error costs 1 mark in "identify the device" questions.

## DIAGNOSTIC_QUESTION_3
**APPLY:** The text describes Shukla's first visit to the Nagari Pracharini Sabha library: "वहाँ पुस्तकों की गंध, पुराने कागज की गंध, धूल की गंध... एक विचित्र सुगंध सी फैली हुई थी।" Identify the **dominant sensory imagery** and explain **why the author chooses this specific sense** in this scene (2-3 sentences).

## DIAGNOSTIC_ANSWER_3
**Correct Answer:** Dominant imagery: **Olfactory (घ्राण)** — "पुस्तकों की गंध, पुराने कागज की गंध, धूल की गंध". Reason: Smell is the most primal, memory-triggering sense. By foregrounding the "ancient paper/dust smell," Shukla instantly transports the reader into the physical reality of a traditional Sanskrit library, establishing its antiquity, sanctity, and his own reverent awe — far more effectively than visual description of shelves could.
**Wrong Answer Reveals:** If the student says "visual" (because libraries are seen), they default to the easiest sense and miss the author's deliberate sensory strategy. If they identify olfactory but give a generic reason like "it creates atmosphere," they cannot link device to *specific* thematic purpose (here: tradition, intellectual lineage, personal initiation). This loses the "explanation" mark in 3-mark questions.

## DIAGNOSTIC_QUESTION_4
**ANALYZE:** Shukla writes about his intellectual transformation: "मेरे ज्ञान-चक्षु खुल गए" (my eyes of knowledge opened) and "अज्ञान का अंधकार छंट गया" (darkness of ignorance dispersed). Break down the **metaphorical system** at work here. Identify the Tenor (subject), Vehicle (image), and Ground (shared quality) for each. How do they work together as an **extended metaphor**?

## DIAGNOSTIC_ANSWER_4
**Correct Answer:**
1. "ज्ञान-चक्षु" (eyes of knowledge): Tenor = Intellectual understanding; Vehicle = Physical eyes/vision; Ground = Capacity to perceive/see clearly.
2. "अज्ञान का अंधकार" (darkness of ignorance): Tenor = Lack of knowledge; Vehicle = Physical darkness; Ground = Obstruction of vision, confusion, fear.
**Extended Metaphor:** Both draw from the **LIGHT/VISION source domain** to map the TARGET domain of intellectual awakening. They form a coherent system: ignorance = darkness/blindness; knowledge = light/sight. The "opening of eyes" *causes* the "dispersal of darkness" — a causal narrative within the metaphor.
**Wrong Answer Reveals:** If the student treats them as two separate, unrelated metaphors, they miss the *systemic* nature of extended metaphor — a key Class 12 analytical skill. If they cannot name Tenor/Vehicle/Ground (or Hindi equivalents: उपमान/उपमेय/साधारण धर्म), they lack the technical vocabulary required for "explain the metaphor" questions in boards/CUET.

## DIAGNOSTIC_QUESTION_5
**EVALUATE:** A student writes in their board answer: "लेखक ने 'ज्ञान-चक्षु' रूपक का प्रयोग किया है क्योंकि यह सुंदर लगता है और पाठक को अच्छा लगता है।" Critique this answer. What is missing? Rewrite the evaluation point to score full marks (2 marks).

## DIAGNOSTIC_ANSWER_5
**Correct Critique:** The answer is **superficial and subjective**. "सुंदर लगता है" (looks beautiful) and "पाठक को अच्छा लगता है" (reader likes it) are aesthetic judgments, not literary analysis. They ignore the *cognitive function* of the metaphor: how it structures the reader's understanding of an abstract process (learning) through a concrete physical experience (seeing).
**Full-Mark Rewrite:** "लेखक ने 'ज्ञान-चक्षु' रूपक द्वारा ज्ञानार्जन की अमूर्त प्रक्रिया को 'देखने' की मूर्त क्रिया में रूपांतरित किया है। 'चक्षु' (नेत्र) का उपमान लेकर लेखक यह संकेत करता है कि ज्ञान प्राप्ति निष्क्रिय ग्रहण नहीं, बल्कि सक्रिय दर्शन है — जैसे आँख खोलने पर अंधकार स्वतः छंट जाता है। यह रूपक 'अज्ञान के अंधकार' के साथ विस्तारित होकर बौद्धिक जागरण की अनिवार्यता और सहजता को स्थापित करता है।"
**Wrong Answer Reveals:** If the student defends the original answer, they confuse "appreciation" (रसास्वादन) with "analysis" (विश्लेषण) — the single biggest reason for losing marks in Section C (Literature) long answers.

## DIAGNOSTIC_QUESTION_6
**CREATE:** Write a 4-line Hindi prose paragraph describing your **first day at a new school/college** using: (a) at least **two distinct sensory images** (label them), (b) **one original metaphor** (not a cliché like "नई शुरुआत") to capture your emotional state. Do not use "जैसे/वैसे".

## DIAGNOSTIC_ANSWER_6
**Criteria for Good Answer:**
- Two *different* senses (e.g., Auditory: "कॉरिडोर में गूंजती पदचाप", Tactile: "ठंडी बेंच की खुरदरी सतह").
- One original metaphor with clear Tenor/Vehicle/Ground (e.g., "मेरी चिंता एक गाँठ थी जो गले में अटकी हुई थी" — Tenor=anxiety, Vehicle=knot in throat, Ground=suffocation, inability to speak/swallow).
- No comparative words (जैसे/वैसे).
- Prose form, not poetry.
**Poor Answer Reveals:** Using only visual imagery ("मैंने बड़ी इमारत देखी") shows sensory poverty. Using a simile ("चिंता जैसे पहाड़ थी") fails the metaphor constraint. Using a dead metaphor ("नया अध्याय") shows lack of creative engagement. This task tests *productive* mastery — essential for CUET creative writing and board "writing skills" questions.

## COMMON_MISCONCEPTION
**Misconception:** "Imagery is just flowery description / Metaphor is only for poetry / Any comparison is a metaphor."
**Why it persists:** In Classes 9-10, students learn devices through poems where imagery is dense and metaphors are explicit. In Class 12 prose (like Shukla's autobiographical sketch), imagery is **functional** (builds setting, reveals character psychology) and metaphors are often **embedded in syntax** (e.g., "ज्ञान-चक्षु" as a compound noun, not a separate sentence). Students scan for "like/as" (simile markers) and if absent, assume no comparison exists. They miss **lexicalized metaphors** (dead metaphors revived by context) and **kinesthetic/organic imagery** (internal body sensations) which are crucial in first-person narratives. Board marking schemes penalize "identification without function" — e.g., writing "visual imagery used" without saying *what* it visualizes and *why* it matters for the theme of 'intellectual heritage'.

## ON_FAILURE
**Remediation Path:**
1. **Revisit Class 11 Node:** `c11_hin_ar_cbse_10_008` (Literary Devices: Imagery and Metaphor in Class 11 Antra Chapter 10). Re-do the worked examples there focusing on *prose* passages, not poems.
2. **Sensory Walk Exercise:** Take a 5-minute walk (real or imagined). Write 1 sentence per sense (5 sentences) describing *only* raw sensation (no interpretation). Then rewrite each adding the *emotional tone* (fear, nostalgia, curiosity). This builds the "sensory vocabulary + function" link.
3. **Metaphor Dissection Drill:** Pick 3 metaphors from the Shukla text (e.g., "हिंदी की सेवा", "भाषा का मंदिर", "ज्ञान-चक्षु"). For each, fill a table: Tenor (उपमेय) | Vehicle (उपमान) | Ground (साधारण धर्म) | Contextual Function. Verify with teacher/answer key.
4. **Re-Diagnostic:** Attempt **Diagnostic Question 4** again without notes. If Tenor/Vehicle/Ground are correct and extended metaphor logic is explained, proceed. Else, repeat step 3 with new examples.

## BUILDS_ON
Class 11 node `c11_hin_ar_cbse_10_008` (Literary Devices: Imagery and Metaphor) where students learned basic definitions, identification in poetry, and simple explanation. Class 12 adds: prose context, extended metaphor systems, functional analysis (theme/character link), and board-answer writing structure (PEEL).

## LEADS_TO
Node `c12_hin_a_cbse_10_009` (Literary Devices: Irony and Symbolism) — irony often *subverts* the imagery/metaphor established earlier (e.g., the "temple of books" becomes a site of colonial neglect). Also leads to `c12_hin_a_cbse_10_013` (Critical Thinking: Analysis and Interpretation) where device analysis feeds into thematic essays.

## PREREQUISITE_NODE_IDS
c11_hin_ar_cbse_10_008, c12_hin_a_cbse_10_001, c12_hin_a_cbse_10_002, c12_hin_a_cbse_10_006, c12_hin_a_cbse_10_003, c12_hin_a_cbse_10_007

## PREREQUISITE_REASONS
c11_hin_ar_cbse_10_008: Direct prior exposure to imagery/metaphor definitions and poetic examples; this node transfers those skills to prose.
c12_hin_a_cbse_10_001: Context/Background knowledge (Shukla's life, Kashi, Nagari Pracharini Sabha) is essential to understand *why* specific images (temple bells, Sanskrit manuscripts) are chosen.
c12_hin_a_cbse_10_002: Plot/Narrative Structure tells us *where* in the narrative the devices appear (childhood vs. youth vs. maturity) — crucial for tracking extended metaphors across time.
c12_hin_a_cbse_10_006: Primary Theme (intellectual lineage, language activism) provides the "so what?" for every device analysis — the Link in PEEL.
c12_hin_a_cbse_10_003: Literary Devices: Imagery and Metaphor — the sensory imagery analyzed here is the raw material for identifying metaphors (e.g., ladder = intellectual ascent).  
c12_hin_a_cbse_10_007: Imagery and metaphor are the primary vehicles through which secondary themes are rendered sensory (e.g., "fpÙkkd"kZd" for literary awakening).  

## FORWARD_NODE_IDS
c12_hin_a_cbse_10_009, c12_hin_a_cbse_10_013, c12_hin_a_cbse_10_011, c12_hin_a_cbse_10_012, c12_hin_a_cbse_10_014, c12_hin_a_cbse_10_015

## FORWARD_REASONS
c12_hin_a_cbse_10_009: Irony and Symbolism often operate *on top of* established imagery/metaphor (e.g., the "light" metaphor is ironized when colonial education dims it). Understanding the base layer is prerequisite.
c12_hin_a_cbse_10_013: Critical Thinking essays require integrating device analysis (this node) with theme, character, and context (previous nodes) into a coherent argument.
c12_hin_a_cbse_10_011: Imagery/Metaphor analysis trains evidence-based reading; grammar analysis applies same rigor to syntax.  
c12_hin_a_cbse_10_012: Imagery/metaphor (e.g., "ân;&ifjp;" as womb of literary birth) are evidence for deeper inferences.  
c12_hin_a_cbse_10_014: Literary Devices: Imagery and Metaphor equips students to identify and write about Shukla's rhetorical strategies in portraying Prasad  
c12_hin_a_cbse_10_015: - Step 1: Recall Literary Devices nodes (c12_hin_a_cbse_10_008, 009) — they covered Shukla's imagery, irony, Sanskritized vocabulary, and sentence structure.  

## CROSS_SUBJECT_PREREQS
c11_hin_ar_cbse_10_008

## CROSS_SUBJECT_REASONS
c11_hin_ar_cbse_10_008: Same topic (Imagery/Metaphor) in Class 11 Antra (different chapter) — reinforces device recognition across texts.
c11_hin_v_cbse_10_008: Same topic in Class 11 Vitan (non-fiction prose) — crucial because Vitan's prose style (essays, memoirs) is closer to this Class 12 Antra chapter (autobiographical sketch) than Antra's poems/stories. Builds prose-specific device analysis skill.

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_10_008 -> c12_hin_a_cbse_10_008 -> c12_hin_a_cbse_10_009 : Progression from poetic device identification (Class 11) to prose functional analysis (Class 12) to advanced device interaction (irony/symbolism).

## THIS_FORMULA
**PEEL Answer Structure for Device Analysis:**
**P**oint: Name the device (Imagery type / Metaphor) + Location (para/line reference).
**E**vidence: Quote the exact phrase (Hindi).
**E**xplanation: (For Imagery) Sensory mode + Mental picture created + Emotional tone evoked. (For Metaphor) Tenor + Vehicle + Ground + Quality transferred.
**L**ink: Connect to Theme / Character Development / Author's Purpose / Atmosphere.

## FORMULA_VARIABLES
P = Point (Device name + Location); E1 = Evidence (Quoted phrase); E2 = Explanation (Sensory/Comparative analysis); L = Link (Thematic/Character function)

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
linguistic

## CROSS_SUBJECT
N/A | Both subjects require identifying imagery/metaphor, explaining sensory/comparative logic, and linking to theme using PEEL. Hindi prose (Shukla) and English prose (e.g., "The Last Lesson" memories) use similar autobiographical sensory triggers.
 N/A | Shukla's text is a primary source for Hindi linguistic nationalism. The "temple of books" metaphor reflects the historical project of constructing Hindi as a sacred national language — imagery serves ideological function. Analyzing this bridges literary device and historical consciousness.
## PREREQ_CONCEPT
Ability to distinguish **simile (explicit comparison with marker)** from **metaphor (implicit equation)** and to classify **sensory modality** of descriptive words.

## PREREQ_BEFORE
Student must have read the full Chapter 10 text ("जयशंकर प्रसाद" by Ramchandra Shukla) at least once and attempted the NCERT end-of-chapter questions (iz'u&vH;kl).

## PREREQ_STUCK
If stuck on metaphor analysis: Review the **Tenor-Vehicle-Ground** framework (उपमेय-उपमान-साधारण धर्म) from Class 11 Hindi grammar (रस/अलंकार chapter) or English "Figure of Speech" notes. Practice on 5 simple sentences daily.

## WORKED_EXAMPLE_1
**PROBLEM:** Analyze the imagery in this passage from the text (Paraphrased): "फाटक खुला तो देखा, एक लंबा बरामदा है। दोनों ओर कमरे हैं। कमरों में पुस्तकें भरी हैं। छत तक आलमारियाँ लगी हैं। धूल जमी है। एक विचित्र-सी गंध आ रही है — पुराने कागज की, चमड़े की, धूल की।" Identify all sensory images, classify them, and explain the cumulative atmosphere created.

**STEPS:**
- Step 1: Read the passage slowly. Underline every word/phrase that triggers a sense.
- Step 2: Classify each: "लंबा बरामदा" (Visual), "कमरों में पुस्तकें भरी हैं" (Visual/Spatial), "छत तक आलमारियाँ" (Visual/Verticality), "धूल जमी है" (Visual + Tactile — implies texture), "विचित्र-सी गंध" (Olfactory), "पुराने कागज की, चमड़े की, धूल की" (Specific Olfactory: musty, leathery, dusty).
- Step 3: Note the **absence** of Auditory (silence) and Gustatory. The silence is palpable — a library hush.
- Step 4: Synthesize: The imagery cluster (Visual height/depth + Olfactory decay/age + Tactile dust) creates an atmosphere of **antiquity, neglect, and sacred accumulation**. It is not just a room; it is a time-capsule.
- Step 5: Link to theme: This sensory portrait establishes the **weight of tradition** that the young Shukla inherits — the "भार" (burden/glory) of Sanskrit/Hindi scholarship.

**REASONING:** This step-by-step moves from micro-identification (word-level) to macro-function (theme-level), exactly what a 3-mark board question demands. Skipping Step 3 (noticing absent senses) misses the "silence" which is as meaningful as the smell.

**ANSWER:** The passage employs **Visual** (long verandah, rooms full of books, shelves to ceiling, dust), **Tactile** (dust settled — implying grit, age), and **Olfactory** (strange smell of old paper, leather, dust) imagery. The dominance of smell — the most memory-linked sense — combined with visual verticality (floor to ceiling) and tactile decay creates an atmosphere of **venerable antiquity and quiet neglect**. This sensory world embodies the theme: the magnificent but fragile heritage of Hindi/Sanskrit scholarship that the narrator must now preserve.

## WORKED_EXAMPLE_2
**PROBLEM:** Analyze the metaphor in Shukla's statement: "हिंदी की सेवा ही मेरे जीवन का व्रत बन गई।" (Service of Hindi became the vow of my life.) Identify Tenor, Vehicle, Ground. Explain why "व्रत" (vow/religious observance) is a more powerful vehicle than "कर्तव्य" (duty) or "काम" (work).

**STEPS:**
- Step 1: Identify the core comparison: "हिंदी की सेवा" (Tenor/उपमेय) = "व्रत" (Vehicle/उपमान). The copula "बन गई" (became) signals metaphor (no जैसे/वैसे).
- Step 2: Determine Ground (साधारण धर्म): What qualities of "व्रत" transfer to "सेवा"? V्रत implies: self-imposed, sacred, binding, lifelong, involves sacrifice/penance (तपस्या), moral/religious sanction, not contractual.
- Step 3: Contrast with alternatives: "कर्तव्य" (duty) = external obligation, professional, can be resigned. "काम" (work) = transactional, temporary, economic. Neither carries **sacredness** or **irrevocable personal commitment**.
- Step 4: Contextualize: Shukla writes this after describing his father's death, his own illness, and the colonial threat to Hindi. The metaphor elevates language activism to **spiritual sadhana (साधना)** — aligning with the "temple of books" imagery earlier.
- Step 5: Formulate PEEL answer.

**REASONING:** This example teaches **vehicle selection analysis** — a higher-order skill than mere identification. Board exams ask "Why this metaphor?" (3 marks). The contrast step (Step 3) is the key to full marks.

**ANSWER:** **Tenor:** हिंदी की सेवा (Hindi service). **Vehicle:** व्रत (Sacred vow/religious observance). **Ground:** Self-imposed, sacred, lifelong, sacrificial, morally binding commitment. The metaphor transforms professional linguistic work into **spiritual साधना**. Choosing "व्रत" over "कर्तव्य" or "काम" injects **religious sanctity and personal irreversibility** — essential because Shukla frames Hindi's survival as a *dharma* (धर्म) battle against colonial cultural erosion, echoing the "मंदिर" imagery of the library. It characterizes him not as an employee but as a **सेवक-भक्त** (servant-devotee).

## WORKED_EXAMPLE_3
**PROBLEM:** (Multi-concept: Imagery + Metaphor + Theme across time) The text moves from Shukla's childhood (Kashi lanes, father's library) to youth (Nagari Pracharini Sabha, college) to maturity (editor, historian). Trace the **extended metaphor of LIGHT/VISION** across these three stages. Quote one phrase per stage. Explain how the metaphor evolves from *passive reception* to *active illumination*.

**STEPS:**
- Step 1: Scan text for LIGHT/VISION lexical field: "ज्ञान-चक्षु", "अंधकार", "रोशनी", "प्रकाश", "देखना", "दिखाई देना", "उजाला".
- Step 2: Stage 1 (Childhood - Father's library): Phrase: "पुस्तकों का मंदिर... मेरे लिए एक मंदिर के समान था" (Simile, but light implied in sanctity). Better: "पिताजी की विद्वत्ता का प्रकाश" (Father's scholarship light) — *Passive*: He *receives* light from father/books.
- Step 3: Stage 2 (Youth - Nagari Pracharini Sabha): Phrase: "मेरे ज्ञान-चक्षु खुल गए" (My knowledge-eyes opened). *Transition*: Internal activation. The light is now *his own faculty*.
- Step 4: Stage 3 (Maturity - Historian/Editor): Phrase: "हिंदी साहित्य का इतिहास... नई रोशनी में देखा" (History of Hindi literature seen in new light) OR "भाषा का दीपक" (Lamp of language). *Active*: He *generates* light for others; becomes the illuminator.
- Step 5: Map evolution: Reception (Child) -> Awakening (Youth) -> Projection (Adult). This mirrors the **Bildungsroman** arc of the chapter.
- Step 6: Write integrated answer linking metaphor evolution to theme: **Intellectual Inheritance -> Autonomous Scholarship -> Institutional Leadership**.

**REASONING:** This combines imagery (light/dark sensory field), metaphor (extended system), and theme (intellectual growth) — exactly the synthesis required for 5-6 mark "Critical Thinking" questions (node 013) and CUET long answers.

**ANSWER:** The LIGHT/VISION metaphor structures Shukla's intellectual autobiography in three phases:
1. **Childhood (Passive Reception):** "पिताजी की विद्वत्ता का प्रकाश" — He bathes in the father's/books' radiance. Imagery: Visual (bright library), Olfactory (sacred smell). He is the *object* of illumination.
2. **Youth (Internal Awakening):** "मेरे ज्ञान-चक्षु खुल गए" / "अज्ञान का अंधकार छंट गया" — Metaphor shifts to *bodily faculty* (eyes). Kinesthetic imagery (opening eyes). He becomes *agent* of seeing.
3. **Maturity (Active Projection):** "हिंदी साहित्य के इतिहास को नई रोशनी में प्रस्तुत किया" / "भाषा का दीपक" — He *casts* light. Metaphor: Historian as lamp-bearer. The "temple" (Stage 1) becomes a "lighthouse" (Stage 3).
**Evolution:** The metaphor tracks the transfer of **authority** — from father/tradition to self/scholarship to institution/nation. This is the central theme: *The making of a modern Hindi intellectual.*

## COMPETENCY_QUESTION_1
**QUESTION:** In the chapter, Shukla describes the atmosphere of the Nagari Pracharini Sabha library using olfactory imagery ("पुराने कागज की गंध, चमड़े की गंध, धूल की गंध"). A student writes: "The author uses smell imagery to show the library was old and dirty." Evaluate this student's interpretation. Is it accurate? Complete? What would you add to make it a full-mark board answer? Rewrite the answer.

**COMPETENCY:** Critical Evaluation & Answer Improvement (CBSE Competency: Analytical Thinking / Effective Communication)

**STEPS:**
- Step 1: Identify the gap: "Old and dirty" reduces a rich sensory cluster to a negative physical description. It misses *reverence*, *antiquity as value*, *intellectual lineage*, and *personal initiation*.
- Step 2: Recall the context: This is Shukla's *first visit* as a young aspirant. The smell triggers awe, not disgust.
- Step 3: Identify the specific olfactory notes: "पुराने कागज" (manuscripts/tradition), "चमड़े" (bound volumes/scholarly labor), "धूल" (time/neglect but also preservation).
- Step 4: Link to theme: The smell *is* the scent of the **Hindi/Sanskrit knowledge tradition** — fragile, embodied, needing care.
- Step 5: Rewrite using PEEL: Point (Olfactory imagery), Evidence (quote), Explanation (sensory specifics + emotional tone: reverence/awe), Link (theme: inheriting the tradition).

**ANSWER:** The student's answer is **incomplete and tonally inaccurate**. "Old and dirty" implies neglect/decay; the text conveys **sacred antiquity**. The smell is not dirt — it is the **perfume of scholarship**.
**Full-Mark Rewrite:** "लेखक ने नागरी प्रचारिणी सभा के पुस्तकालय का वर्णन करते हुए घ्राण चित्रात्मकता (Olfactory Imagery) का प्रयोग किया है: 'पुराने कागज की गंध, चमड़े की गंध, धूल की गंध'। यह मात्र 'पुरानापन' या 'गंदगी' नहीं दर्शाता; बल्कि संस्कृत/हिंदी ज्ञान-परंपरा की **मूर्त, साँस लेती उपस्थिति** को उकेरता है। 'चमड़े की गंध' जिल्दसाज़ी के श्रम को, 'कागज की गंध' पांडुलिपियों की भंगुरता को, 'धूल' काल की परत को सूचित करती है। यह गंध युवा शुक्ल के लिए **श्रद्धा और उत्तरदायित्व** का बोध जगाती है — वह इस परंपचा का वारिस है। इस प्रकार, घ्राण चित्रात्मकता 'सांस्कृतिक विरासत के संरक्षण' के केंद्रीय विषय को संवेदनात्मक आधार देती है।"

**DIFFICULTY:** medium

## COMPETENCY_QUESTION_2
**QUESTION:** (Case-Based / Source-Based) Read the following excerpt from a student's practice essay on the chapter:
> "Shukla uses the metaphor 'ज्ञान-चक्षु' (eyes of knowledge) to say he became educated. It is a common metaphor. He also uses 'अंधकार' for ignorance. These are clichés and do not add much literary value. The chapter would be better without them."

**Task:** Write a **counter-argument** (150 words) defending the *literary and thematic necessity* of these metaphors in *this specific text*. Use the concepts of **lexicalized metaphor revival**, **extended metaphor system**, and **autobiographical authority**.

**COMPETENCY:** Argument Construction / Defense of Interpretation (CBSE Competency: Creative & Critical Thinking; CUET: Literary Analysis)

**STEPS:**
- Step 1: Reject the premise: "Cliché" (lexicalized metaphor) ≠ "ineffective." In autobiography, *reviving* dead metaphors through context gives them new life.
- Step 2: Define "lexicalized metaphor revival": "ज्ञान-चक्षु" is a fixed phrase (dictionary entry), but Shukla *enacts* it narratively — he describes the *moment* his eyes opened (meeting scholars, reading books). The metaphor becomes *dramatic action*.
- Step 3: Explain "extended metaphor system": "ज्ञान-चक्षु" + "अज्ञान का अंधकार" + "नई रोशनी" form a **coherent cognitive framework** (LIGHT/VISION) that structures the entire narrative arc (Childhood -> Youth -> Maturity). Removing them collapses the structural architecture.
- Step 4: Invoke "autobiographical authority": Shukla *is* the historian of Hindi literature. Using the *traditional* metaphoric vocabulary of that tradition (Sanskrit poetics: चक्षु, ज्योति, तमस्) is an act of **disciplinary fidelity** — he writes *in* the tradition he describes.
- Step 5: Synthesize into a tight paragraph.

**ANSWER:** The claim that "ज्ञान-चक्षु/अंधकार" are mere clichés confuses **lexicalization** with **contextual death**. In Shukla's autobiography, these lexicalized metaphors are **revived through narrative enactment**: the "opening of knowledge-eyes" is not asserted abstractly but dramatized through specific encounters (Nagari Pracharini Sabha, meeting scholars, reading manuscripts). Furthermore, they form an **extended metaphor system** (LIGHT/VISION) that provides the *architectural logic* of the chapter's three-stage Bildungsroman: passive reception (father's light) → active awakening (own eyes) → projective illumination (historian's lamp). Excising them would sever the thematic spine linking personal growth to the **intellectual genealogy of Hindi**. Crucially, Shukla writes *as* a historian *of* the tradition whose classical poetics (आलंकारिक शैली) employs these very tropes (चक्षु=ज्ञान, तमस्=अज्ञान). Using them is not laziness; it is **epistemological fidelity** — thinking *in* the language of the tradition he builds. The metaphors *are* the method.

**DIFFICULTY:** hard