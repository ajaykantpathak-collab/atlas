## DEFINITION
Language Usage in the Text refers to the systematic analysis of grammatical structures, dialectal features (specifically Braj Bhasha), and rhetorical devices employed by Meerabai in her poetry to convey devotional intensity and emotional nuance.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student must be able to identify and explain at least three distinct Braj Bhasha grammatical features (verb endings, case markers, archaic vocabulary) in the prescribed poem and articulate how each feature contributes to the poem's devotional tone and rhythmic quality.

## SCOPE_BOUNDARY
This node covers grammatical and stylistic analysis of the specific Meerabai poem prescribed in Class 11 NCERT (Aroh Chapter 10). It does not cover comprehensive Braj Bhasha grammar, other poets' works, or general Hindi grammar rules unrelated to the text.

## WALKTHROUGH
Imagine you are reading Meerabai's poem and stumble on words like "fxjèkj", "lhafp&lhafp", or "dkf<+" that don't follow modern Hindi grammar rules. Your first instinct might be to dismiss them as "old Hindi" or errors. Instead, pause and ask: "What systematic patterns govern these forms?" Begin by reading the poem aloud to hear the rhythm. Then, isolate one line and label each word's part of speech using modern Hindi grammar as a reference point. Next, identify where the forms diverge — verb endings like "x;h" vs modern "thī", case markers like "kau" vs "ko", or vocabulary like "dkfu" vs "dukh". Finally, connect each divergence to its effect: does it create rhyme, emphasize emotion, or reflect 16th-century spoken Braj? The key insight is that these are not mistakes but deliberate choices of a living dialect that Meerabai mastered for poetic expression.

## DIAGNOSTIC_QUESTION_1
What is the name of the literary dialect used by Meerabai in her poetry, and which modern Hindi region does it historically belong to?

## DIAGNOSTIC_ANSWER_1
The dialect is Braj Bhasha, historically spoken in the Braj region (Mathura-Vrindavan area) of present-day Uttar Pradesh. A wrong answer (e.g., "Awadhi" or "Khari Boli") reveals the student cannot distinguish between major medieval literary dialects, which is essential for recognizing why Meerabai's verb endings and vocabulary differ from modern standard Hindi.

## DIAGNOSTIC_QUESTION_2
Explain why Meerabai chose to compose in Braj Bhasha rather than Sanskrit, and how this choice relates to the Bhakti movement's core philosophy.

## DIAGNOSTIC_ANSWER_2
Meerabai used Braj Bhasha because the Bhakti movement emphasized direct, personal devotion accessible to common people, bypassing Sanskrit's priestly monopoly. A wrong answer focusing only on "she didn't know Sanskrit" or "it was her mother tongue" misses the socio-religious dimension: the deliberate democratization of spiritual expression through vernacular language, a hallmark of Nirguna and Saguna Bhakti traditions alike.

## DIAGNOSTIC_QUESTION_3
In the line "vc r csfy iSQfy x;h] vk.kan&iQy gks;h", identify the verb forms "x;h" and "gks;h", state their modern Hindi equivalents, and name the grammatical tense/aspect they represent.

## DIAGNOSTIC_ANSWER_3
"x;h" = "thī" (past habitual/feminine singular), "gks;h" = "huī" (past perfective/feminine singular). Both are feminine singular past forms in Braj Bhasha. A student who writes "thā/thī" for both or cannot distinguish habitual vs perfective aspect shows they are applying modern Hindi paradigms mechanically without recognizing Braj's distinct aspectual system.

## DIAGNOSTIC_QUESTION_4
Compare the case marking in "esjs rks fxjèkj xksiky" (my Giridhar Gopal) and "nwèk dh eFkfu;k¡" (of the new love). Why does the first use no postposition while the second uses "dh"? What does this reveal about Braj Bhasha's case system?

## DIAGNOSTIC_ANSWER_4
"esjs rks fxjèkj xksiky" uses the direct (nominative) case for the subject "Giridhar Gopal" with no postposition, while "nwèk dh eFkfu;k¡" uses the genitive postposition "dh" (of) showing possession. Braj Bhasha, like modern Hindi, marks only oblique cases with postpositions; the direct case remains unmarked. A wrong answer claiming "esjs" is a postposition or that both lines use the same case reveals confusion between pronoun case and noun case marking.

## DIAGNOSTIC_QUESTION_5
Evaluate the effect of the repeated alliteration (anupras) in "valqou ty lhafp&lhafp] izse&csfy cks;h" on the poem's emotional intensity. Would the same effect be achieved in modern Khari Boli? Justify.

## DIAGNOSTIC_ANSWER_5
The reduplicated "lhafp&lhafp" (wave after wave) and "izse&csfy" (love's longing) create sonic waves mimicking the overwhelming, repetitive nature of viraha (separation) longing. In Khari Boli, the phonetic inventory differs (e.g., loss of Braj's characteristic vowel length and consonant clusters), weakening the onomatopoeic resonance. A student who says "yes, alliteration works in any language" misses the phonological specificity: Braj's phonetics are integral to the aesthetic experience (rasa) of the poem.

## DIAGNOSTIC_QUESTION_6
Compose a two-line couplet in Braj Bhasha style (using appropriate verb endings, vocabulary, and rhyme) expressing the idea: "My heart longs for the divine vision." Do not copy from the textbook.

## DIAGNOSTIC_ANSWER_6
Example: "moro hiyo ḍole daraś kī ās, naina bane pīyasi pīyās." (My heart swings with hope of vision, eyes become thirsty with thirst.) A poor answer uses modern Hindi forms ("mera dil darta hai", "aankhein pyasi hain") showing inability to internalize Braj morphology (verb "ḍole" vs "ḍoltā hai", vocabulary "hiyo" vs "dil", rhyme "ās/pīyās").

## COMMON_MISCONCEPTION
Students treat Braj Bhasha forms as "incorrect" or "corrupted" modern Hindi rather than a rule-governed literary dialect with its own consistent grammar. For example, they see "fxjèkj" (Giridhar) and "xksiky" (Gopal) as spelling errors instead of recognizing the Braj phonological rule where Sanskrit 'r' becomes 'y' in final position (Giridhar → Giridhay → Girdhar/Giridhar in Braj orthography) and 'l' vocalization. This misconception arises because textbooks often present the poem without explicit contrastive grammar tables, leaving students to map forms onto their only known system (Khari Boli).

## ON_FAILURE
1. Create a three-column table: Column A = Braj form from poem (e.g., "x;h", "dkfu", "kau"), Column B = Modern Khari Boli equivalent ("thī", "dukh", "ko"), Column C = Grammatical category (past habitual feminine, noun masculine, dative postposition). 2. Have the student fill it for 10 words from the poem. 3. Ask them to formulate one generalization per category (e.g., "Braj past habitual feminine ends in -ī like Khari Boli but stem vowel differs"). 4. Finally, give a new Braj line and ask them to predict the Khari Boli translation using their generalizations.

## BUILDS_ON
Vocabulary in Context (c11_hin_ar_cbse_10_010) provides the word meanings necessary to parse grammatical function; Literary Devices (c11_hin_ar_cbse_10_008, c11_hin_ar_cbse_10_009) establishes rhetorical awareness that language usage analysis deepens.

## LEADS_TO
Comprehension: Literal and Inferential Questions (c11_hin_ar_cbse_10_012) requires grammatical parsing to answer "how" and "why" questions; Critical Thinking (c11_hin_ar_cbse_10_013) uses dialect analysis to evaluate Meerabai's subversion of patriarchal language norms.

## PREREQUISITE_NODE_IDS
c11_hin_ar_cbse_10_001, c11_hin_ar_cbse_10_010, c11_hin_ar_cbse_10_008, c11_hin_ar_cbse_10_009

## PREREQUISITE_REASONS
c11_hin_ar_cbse_10_001: Provides historical context of Meerabai's life and the Braj region, essential for understanding why she wrote in this dialect.
c11_hin_ar_cbse_10_010: Supplies meanings of key archaic words (dkfu, f<x, csfy, foyks;h) without which grammatical analysis is impossible.
c11_hin_ar_cbse_10_008: Introduces imagery and metaphor; language usage analysis explains how grammatical choices (e.g., reduplication) create those images.
c11_hin_ar_cbse_10_009: he word meanings necessary to parse grammatical function; Literary Devices (c11_hin_ar_cbse_10_008, c11_hin_ar_cbse_10_009) establishes rhetorical awareness that language usage analysis deepens.  

## FORWARD_NODE_IDS
c11_hin_ar_cbse_10_012, c11_hin_ar_cbse_10_013, c11_hin_ar_cbse_10_014, c11_hin_ar_cbse_10_015, c12_hin_a_cbse_04_011, c12_hin_a_cbse_09_011, c12_hin_a_cbse_10_011, c12_hin_a_cbse_11_011, c12_hin_a_cbse_12_011, c12_hin_a_cbse_17_011, c12_hin_ar_cbse_01_011, c12_hin_ar_cbse_02_011, c12_hin_ar_cbse_07_011, c12_hin_ar_cbse_09_011, c12_hin_ar_cbse_10_011, c12_hin_ar_cbse_11_011

## FORWARD_REASONS
c11_hin_ar_cbse_10_012: Literal comprehension questions (e.g., "Why does she call Giridhar 'fxjèkj'?") require case and vocabulary analysis taught here.
c11_hin_ar_cbse_10_013: Critical interpretation of Meerabai's rejection of royal language ("cztHkk"kk") in favor of Braj depends on understanding dialect as ideological choice.
c11_hin_ar_cbse_10_014: Writing skills tasks (e.g., "Write a diary entry as Meerabai") demand stylistic imitation of her grammatical register.
c11_hin_ar_cbse_10_015: Grammar/language usage (Brajbhasha/Khadi Boli mix, verb forms) aids close reading of tone.  
c12_hin_a_cbse_04_011: अगला तार्किक चरण: This node analyzes the grammatical structures, syntactic patterns, and language usage specific to th... इस नोड की अवधारणाओं को सीधे उपयोग/विस्तारित करता है।  
c12_hin_a_cbse_09_011: Practiced *pad-parichay* (word analysis) — directly used in WORKED_EXAMPLE steps.  
c12_hin_a_cbse_10_011: Introduces clause identification, voice, aspect — the analytical toolkit used here.  
c12_hin_a_cbse_11_011: Introduces nominal morphology (tatsam, tadbhav, deshaj) — classifies chapter vocabulary.  
c12_hin_a_cbse_12_011: Study of idiomatic expressions and their non-compositional meanings  
c12_hin_a_cbse_17_011: Applied etymology to interpret author's intent — models this node's approach.  
c12_hin_ar_cbse_01_011: Builds vocabulary for grammatical metalanguage (aspect, mood, voice).  
c12_hin_ar_cbse_02_011: Integration with literary devices.  
c12_hin_ar_cbse_07_011: Word-formation (samasa) in poetic compounds.  
c12_hin_ar_cbse_09_011: Further practice with metaphor/simile grammatical distinction.  
c12_hin_ar_cbse_10_011: Language usage in Class 11 Chapter 10 — direct precedent for this node.  
c12_hin_ar_cbse_11_011: Consolidates multi-feature integrated analysis  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
No prior class nodes exist for cross-subject links in this curriculum.

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_10_001 -> c11_hin_ar_cbse_10_011 -> c11_hin_ar_cbse_10_012

## THIS_FORMULA
Braj Bhasha Analysis Protocol: (1) Identify phonological shifts (Sanskrit → Braj), (2) Map verb morphology (tense/aspect/mood endings), (3) Track case/postposition system, (4) Catalog archaic lexical items, (5) Detect sound patterns (anupras, yamak), (6) Synthesize: How do 1-5 serve bhakti rasa?

## FORMULA_VARIABLES
N/A

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
linguistic

## CROSS_SUBJECT
c11_history_bhakti_movement | Meerabai's language choice exemplifies the Bhakti movement's vernacularization strategy, making divine access direct and emotional rather than ritualistic and Sanskrit-bound.
c11_sociology_indian_society | The poem's use of "yksd ykt" (folk speech) versus "cztHkk"kk" (refined/courtly language) illustrates how language marks social identity and resistance in medieval Indian society.

## PREREQ_CONCEPT
Basic Hindi grammar (karak, kriya, visheshan, samas) and awareness that medieval Hindi literature uses multiple literary dialects (Avadhi, Braj, Khari Boli).

## PREREQ_BEFORE
Student must have read the poem at least twice, understood its literal meaning via vocabulary node, and know Meerabai's historical context from the background node.

## PREREQ_STUCK
If stuck, review c11_hin_ar_cbse_10_010 (Vocabulary) for word meanings and c11_hin_ar_cbse_10_001 (Context) for why Braj Bhasha was Meerabai's medium.

## WORKED_EXAMPLE_1
PROBLEM: Analyze the grammatical structure of the opening line "esjs rks fxjèkj xksiky] nwljks u dksbZ" by identifying each word's part of speech, case, gender, number, and Braj-specific feature.

STEPS:
- Step 1: Segment the line into tokens: esjs / rks / fxjèkj / xksiky / nwljks / u / dksbZ.
- Step 2: Label each token using modern Hindi grammar as baseline: esjs (possessive pronoun, 1st person, masculine singular, oblique), rks (particle, emphasis), fxjèkj (proper noun, masculine singular), xksiky (proper noun, masculine singular), nwljks (adjective, masculine singular), u (negative particle), dksbZ (indefinite pronoun, masculine singular).
- Step 3: Identify Braj deviations: "esjs" shows Braj genitive form (vs Khari Boli "merā"); "fxjèkj" retains Sanskrit 'r' cluster (vs Braj tendency to simplify); "xksiky" shows final 'l' → 'y' shift (Gopāl → Gopāy → Gopāi? Actually "xksiky" reflects Braj pronunciation Gopāl with vocalized l); "nwljks" uses Braj adjectival ending -jks (vs Khari Boli -ā); "dksbZ" is common to both.
- Step 4: Determine syntactic relations: "esjs" modifies the compound subject "fxjèkj xksiky" (Giridhar Gopal) in nominative direct case (no postposition). "rks" adds emphasis "indeed". "nwljks u dksbZ" = "no other new [one]" — predicate nominative.
- Step 5: Interpret grammatical effect: The unmarked nominative case for the divine name elevates Giridhar Gopal as the absolute subject of devotion; the emphatic "rks" asserts exclusivity; the Braj forms root the utterance in the vernacular of Vraj bhumi, making the divine intimate.

REASONING: This step-by-step parsing moves from surface tokens to deep structure, revealing how grammar encodes theology. Each Braj feature is not decorative but functional: the genitive "esjs" claims possession, the nominative case marks the Lord as independent subject, the emphatic particle excludes rivals.

ANSWER: The line is a nominal sentence (no overt verb) with compound subject "Giridhar Gopal" in direct nominative case, modified by 1st person possessive "esjs" (Braj genitive). The predicate "nwljks u dksbZ" (no other new one) uses Braj adjectival form "nwljks". Braj features: genitive pronoun "esjs", adjectival ending -jks, lexical item "fxjèkj" (Giridhar). The grammar enacts complete surrender: "My [only] Lord is Giridhar Gopal; there is no other."

## WORKED_EXAMPLE_2
PROBLEM: Identify and classify the figures of sound (shabdalankar) in the line "valqou ty lhafp&lhafp] izse&csfy cks;h" and explain their thematic function.

STEPS:
- Step 1: Read the line aloud repeatedly to hear sound repetitions: valqou / ty / lhafp&lhafp / izse&csfy / cks;h.
- Step 2: Mark repeated phonemes: /l/ in "valqou", "lhafp&lhafp"; /f/ in "lhafp", "csfy"; /k/ in "cks;h"; /s/ in "izse", "csfy".
- Step 3: Classify each repetition: "lhafp&lhafp" = anupras (alliteration) via reduplication of entire word; also yamak (identical repetition with same meaning). "izse&csfy" = anupras on /s/ and /f/; also shlesha (pun) if "csfy" means both "longing" and "sip" (but here only longing). "valqou" and "lhafp" share /l/ and /v/ approx — weak anupras.
- Step 4: Analyze semantic reinforcement: "lhafp" = wave; reduplication "lhafp&lhafp" = wave after wave, mimicking the endless surges of viraha. "izse&csfy" = love's longing; the sibilant /s/ creates a hissing, breath-like quality evoking sighs.
- Step 5: Evaluate aesthetic contribution: The sound patterning transforms abstract emotion into sensory experience — the listener feels the waves and hears the sighs. This is dhvani (suggestion) through shabda (sound), a core principle of Indian poetics.
- Step 6: Compare with Khari Boli rendering: "lehron ki lehren, pyaas ki pyaas" — loses the labial /f/ and sibilant density, weakening the onomatopoeia.

REASONING: Sound figures in Bhakti poetry are not ornamental; they are the vehicle of rasa. The protocol (hear → mark → classify → semantic link → aesthetic evaluation → contrast) ensures analysis goes beyond labeling to interpretation.

ANSWER: Primary figures: (1) Anupras (alliteration) on /l/, /f/, /s/ clusters. (2) Yamak (identical repetition) in "lhafp&lhafp". (3) Reduplication as morphological intensifier. Thematic function: Sonic iconicity — the repeating waves (/l/, /f/) and sighing sibilants (/s/) embody the ceaseless, bodily nature of separation longing, making the abstract emotion palpable.

## WORKED_EXAMPLE_3
PROBLEM: Compare the verb systems in two lines: Line A: "vc r csfy iSQfy x;h] vk.kan&iQy gks;h" and Line B: "nfèk efFk ?k`r dkf<+ fy;ks] Mkfj n;h Nks;h". Identify all verb forms, their tense/aspect, person/number/gender, and explain the shift in temporal perspective.

STEPS:
- Step 1: Extract verb forms: Line A: "x;h", "gks;h". Line B: "fy;ks", "Nks;h".
- Step 2: Analyze Line A verbs: "x;h" (from Braj "jānā" → "jānh" + past habitual feminine singular ending -ī → "jānhī" → written "x;h") = "used to go / would go". "gks;h" (from "honā" → past perfective feminine singular "huī") = "became". Both feminine singular agreeing with implied subject "I" (Meerabai).
- Step 3: Analyze Line B verbs: "fy;ks" (from "phailnā" → past habitual? or perfective? Braj "phailā" + -s? Actually "fy;ks" = "phailī" feminine singular perfective) = "spread". "Nks;h" (from "nācnā" → "nācī" feminine singular perfective) = "danced". Both feminine singular perfective.
- Step 4: Determine tense/aspect contrast: Line A uses past habitual ("x;h" = repeated action in past) + perfective ("gks;h" = completed change of state). Line B uses two perfectives ("fy;ks", "Nks;h") describing a single episode.
- Step 5: Map temporal perspective: Line A = "Ever since that time, longing used to go and become intense" — ongoing process. Line B = "Suddenly, the fire of pain spread, [and] the anklets danced" — punctual climax.
- Step 6: Synthesize grammatical-stylistic effect: The shift from habitual to perfective mirrors the narrative arc from chronic viraha to acute ecstatic vision. Braj morphology enables this nuance: habitual -at/-īt vs perfective -yā/-ī.

REASONING: Verb aspect is the grammar of time consciousness. By systematically comparing aspectual choices across lines, we see how Meerabai structures spiritual experience linguistically — not just what happens, but how it happens in time.

ANSWER: Line A: "x;h" (past habitual feminine singular, "used to go"), "gks;h" (perfective feminine singular, "became"). Line B: "fy;ks" (perfective feminine singular, "spread"), "Nks;h" (perfective feminine singular, "danced"). Shift: habitual → perfective = chronic longing → sudden transformative moment. Braj aspectual distinction (habitual -at/-īt vs perfective -yā/-ī) maps the devotee's inner timeline.

## COMPETENCY_QUESTION_1
QUESTION: Given the following unseen line from a Meerabai poem: "moro man lāgio shyām kī preet, naina bane bāvarī rīt", identify three Braj Bhasha grammatical features (morphological, lexical, or syntactic) and explain how each contributes to the poem's devotional intimacy.

COMPETENCY: Analytical Reasoning (identify, classify, interpret grammatical features in unseen text)

STEPS:
- Step 1: Segment the line and tag each word for Braj features.
- Step 2: Select three distinct features (e.g., possessive pronoun "moro", verb form "lāgio", adjectival "bāvarī").
- Step 3: For each, state the Braj form, Khari Boli equivalent, grammatical category, and semantic-pragmatic effect.
- Step 4: Synthesize: How do these features collectively create intimacy?

ANSWER: 1. "moro" (1st person masc. sg. possessive) vs Khari Boli "merā" — the -o ending is characteristic Braj, marking the speaker's vernacular identity, making the devotion personal and rooted. 2. "lāgio" (verb "lāgnā" perfective masculine singular) vs "lagā" — the -io ending is Braj perfective; the verb means "attached/fixed", implying irreversible binding of heart to Shyam. 3. "bāvarī" (feminine singular adjective "mad/obsessed") vs "bāvarī" (same form but Braj uses it predicatively without copula) — the zero copula ("naina bane bāvarī rīt" = eyes have become mad custom) creates immediacy. Together: vernacular grammar = no distance between devotee and divine.

DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: Rewrite the modern Hindi sentence "मेरा मन कृष्ण की याद में तड़पता है" into Braj Bhasha style appropriate for a Meerabai poem, using correct verb morphology, case markers, vocabulary, and rhyme potential. Explain each choice.

COMPETENCY: Creative Application (synthesize grammatical knowledge to produce authentic dialect style)

STEPS:
- Step 1: Analyze source sentence: subject "mera man" (masc. sg.), verb "tadapta hai" (present habitual), PP "Krishna ki yaad mein".
- Step 2: Convert each element to Braj: "mera" → "moro/mērō"; "man" → "man/hiyo"; "Krishna" → "Shyam/Kanhaiya/Giridhar"; "ki" (genitive) → "kī/kar"; "yaad" → "yād/bisār"; "mein" (locative) → "mā̃h/mē"; "tadapta hai" → "ṭapṭāvai/ḍolai/calai" (present habitual 3rd sg. masc.).
- Step 3: Assemble with poetic rhythm: "moro hiyo ḍolai Shyam kī yād mā̃h" or "mērō man ṭapṭāvai Kanhaiyā kī bisār mē".
- Step 4: Add rhyme partner for stanza integration: e.g., "moro hiyo ḍolai Shyam kī yād mā̃h, naina bahrāve nīr kī dhār" (eyes shed tears' stream).
- Step 5: Justify each choice referencing Braj grammar rules learned.

ANSWER: Braj version: "moro hiyo ḍolai Shyam kī yād mā̃h". Choices: "moro" (Braj possessive -o), "hiyo" (Braj vocabulary for heart), "ḍolai" (present habitual 3rd masc. sg. ending -ai vs Khari Boli -tā hai), "Shyam" (preferred Braj name), "kī" (genitive postposition, same form), "yād" (tatsama retained), "mā̃h" (locative postposition "in" vs Khari Boli "mein"). Rhyme partner "dhār" enables AA scheme. Each choice reflects Braj phonology, morphology, and lexicon.

DIFFICULTY: hard