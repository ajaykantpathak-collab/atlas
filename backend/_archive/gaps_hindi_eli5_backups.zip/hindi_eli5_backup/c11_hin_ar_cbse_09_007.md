## DEFINITION
Secondary themes are the underlying ideas, motifs, or messages that run parallel to the primary theme in a literary work, enriching the text by exploring complementary social, philosophical, or emotional dimensions through specific imagery, character interactions, and narrative details.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student must be able to identify at least three distinct secondary themes in Dhabbuji's poetry, trace each theme across multiple stanzas with textual evidence, and explain how these themes interconnect with the primary theme of spiritual equality to create a cohesive social critique.

## SCOPE_BOUNDARY
This node covers identification and analysis of secondary themes (social equality, critique of ritualism, knowledge as liberation, simplicity as virtue) in Dhabbuji's selected verses from the NCERT Class 11 Aroh textbook. It does not cover primary theme analysis (node 006), literary devices (nodes 008-009), or vocabulary/grammar (nodes 010-011).

## WALKTHROUGH
Imagine you're scrolling through social media and see a post about a 600-year-old poet who said "don't ask my caste, ask my knowledge" - that's Dhabbuji. You've already found the main message (spiritual equality), but now ask: what other battles is he fighting through these verses? Start by re-reading the poem looking for repeated concerns beyond God-devotion - notice how often he mentions caste pride, ritual bathing, bookish knowledge versus lived wisdom, and the simplicity of his language. Each recurrence is a thread; pull them to reveal the secondary themes. The key insight: secondary themes aren't hidden - they're the patterns you see when you stop looking for "the one meaning" and start mapping "the many meanings working together."

## DIAGNOSTIC_QUESTION_1
What is the definition of a secondary theme in literature, and how does it differ from the primary theme in terms of textual prominence and function?

## DIAGNOSTIC_ANSWER_1
A secondary theme is a recurring idea that supports, complicates, or runs parallel to the primary theme, appearing with less frequency but adding depth to the work's social or philosophical scope. Unlike the primary theme which governs the entire work's central message, secondary themes operate as subsidiary threads - for example, in Dhabbuji's poetry, spiritual equality is primary while critique of ritualism is secondary. A wrong answer that equates secondary themes with "minor details" or "subplots" reveals confusion between thematic layers and narrative elements; secondary themes are conceptual, not plot-based.

## DIAGNOSTIC_QUESTION_2
In Dhabbuji's verse "cu iM+s rks lh/s&lh/s ugha rks njsjk nsdj" (If you ask caste, I won't tell; if you don't ask, I'll volunteer), explain how this couplet simultaneously advances the primary theme of spiritual equality AND a secondary theme. Identify the secondary theme and justify with textual reasoning.

## DIAGNOSTIC_ANSWER_2
The couplet advances the primary theme (spiritual equality transcends caste) while embedding the secondary theme of **anti-institutional assertiveness** - the poet refuses both the demand for caste identity AND the social expectation to conceal it. The dual structure ("if you ask... if you don't ask") shows strategic resistance: he won't validate caste inquiry, yet won't hide his identity either. A wrong answer identifying only "humility" or "devotion" misses the political dimension - this is not passive piety but active subversion of caste-based social protocols, a hallmark of Nirguna Bhakti's social critique.

## DIAGNOSTIC_QUESTION_3
Apply the concept of "secondary theme clustering" to identify three distinct secondary themes in Dhabbuji's poetry by analyzing these textual markers: (a) references to "ns'kkVu vkSj lRlax" (scriptures and Vedas), (b) "tkfr&Hksn, o.kZ&Hksn, laiznk;&Hksn" (caste, class, gender distinctions), (c) "deZdkaM vkSj osn&fopkj" (meditation and philosophical discourse). Map each marker to its theme.

## DIAGNOSTIC_ANSWER_3
(a) "ns'kkVu vkSj lRlax" → **Critique of ritualistic/bookish knowledge** - contrasts external textual authority with internal experiential wisdom (Kku). (b) "tkfr&Hksn, o.kZ&Hksn, laiznk;&Hksn" → **Dismantling social hierarchies** - explicitly names the three major axes of medieval inequality. (c) "deZdkaM vkSj osn&fopkj" → **Accessible spirituality** - rejects elite yogic/philosophical practices for direct devotion. A wrong answer that merges (a) and (c) as "rejecting tradition" fails to distinguish between rejecting *authority of texts* versus rejecting *exclusivity of practice* - a crucial nuance in Bhakti theology.

## DIAGNOSTIC_QUESTION_4
Analyze how the secondary theme of "simplicity as spiritual authenticity" operates through Dhabbuji's linguistic choices. The NCERT notes he used "lkI+kQ ,oa nks Vwd 'kCnksa" (simple and two-and-a-half words). Connect this stylistic feature to the poem's imagery of "ck<+h dk"V gh dkVS" (like a sharp knife's edge) and explain the thematic function.

## DIAGNOSTIC_ANSWER_4
The "sharp knife" metaphor embodies simplicity as *penetrating precision* - a simple blade cuts deeper than an ornate sword. Linguistically, "two-and-a-half words" (extreme brevity) mirrors this: minimal language carries maximum truth, just as a knife's edge concentrates force. Thematically, this makes simplicity not aesthetic but *epistemological* - truth requires no elaboration. A wrong answer treating this as mere "plain language for common people" misses the philosophical claim: simplicity is the *form* of authentic knowledge, not just its vehicle. The knife cuts through both caste pretension and scholarly verbosity simultaneously.

## DIAGNOSTIC_QUESTION_5
Evaluate the claim: "Dhabbuji's secondary themes are merely historical artifacts of 15th-century social reform, irrelevant to modern readers." Defend or refute using at least two secondary themes from the text and contemporary parallels.

## DIAGNOSTIC_ANSWER_5
Refute. The secondary theme of **knowledge gatekeeping** (critique of "ns'kkVu vkSj lRlax" as monopoly) maps directly to modern credentialism and academic elitism - who gets to define valid knowledge? The theme of **intersectional hierarchy** ("tkfr&Hksn, o.kZ&Hksn, laiznk;&Hksn") anticipates modern intersectionality theory by naming caste, class, gender as co-constitutive oppressions. These aren't artifacts but *analytical tools* - Dhabbuji's "knife" still cuts. A wrong answer agreeing with the claim reveals presentism: judging historical texts by whether they use modern vocabulary rather than whether they diagnose enduring structures.

## DIAGNOSTIC_QUESTION_6
Create a four-line contemporary poem in Hindi (or Hinglish) that adapts Dhabbuji's secondary theme of "simplicity as resistance" to a modern context (e.g., social media performativity, corporate jargon, academic gatekeeping). Use the "two-and-a-half words" principle - extreme brevity with sharp impact.

## DIAGNOSTIC_ANSWER_6
Example:
"Degree dikhao, naukri pao
Hunar chhupao, tag lagao
Sach much mein kaun puchta hai?
Kaam bolo, naam mitao."

Criteria: (1) Identifies a modern hierarchy (credentialism), (2) Uses minimal words for maximal cut, (3) Inverts the power dynamic (work > name), (4) Echoes Dhabbuji's refusal to perform identity. A poor answer would be verbose, lack a "knife edge" reversal, or merely describe simplicity without weaponizing it - missing that for Dhabbuji, simplicity is an *offensive* strategy, not a defensive one.

## COMMON_MISCONCEPTION
Students confuse "secondary themes" with "minor themes" or "sub-themes," treating them as less important versions of the primary theme. They write: "The main theme is equality; secondary themes are devotion and simplicity." This is wrong because secondary themes in Dhabbuji are not subordinate - they are *co-constitutive*. The critique of ritualism (ns'kkVu) doesn't just "support" equality; it explains *why* equality is blocked. The intersectional naming (tkfr, o.kZ, laiznk;) doesn't just "add" to equality; it maps the *structure* equality must dismantle. Students miss that secondary themes do analytical work the primary theme cannot do alone - they diagnose the machinery of oppression.

## ON_FAILURE
If a student lists themes without showing their structural role: (1) Have them create a two-column table: Column A = "What the primary theme CLAIMS" (equality), Column B = "What each secondary theme EXPLAINS/ATTACKS" (ritualism blocks it, hierarchy structures it, complexity masks it). (2) Ask: "If you removed this secondary theme, what would the primary theme fail to explain?" (3) Model with the "knife" metaphor: primary theme = the cut; secondary themes = the blade's thinness, the handle's grip, the motion's precision. All necessary for the cut to happen.

## BUILDS_ON
c11_hin_ar_cbse_09_006 (Theme: Primary Theme and Message) - students must first establish the central argument (spiritual equality) before mapping how secondary themes architecturally support, complicate, or extend it.

## LEADS_TO
c11_hin_ar_cbse_09_008 (Literary Devices: Imagery and Metaphor) - secondary themes are carried by specific images (knife, mirror, path); analyzing devices requires knowing which theme each image serves.

## PREREQUISITE_NODE_IDS
c11_hin_ar_cbse_09_001, c11_hin_ar_cbse_09_002, c11_hin_ar_cbse_09_006, c11_hin_ar_cbse_09_005

## PREREQUISITE_REASONS
c11_hin_ar_cbse_09_001: Provides historical context (Nirguna Bhakti, caste society) essential for recognizing secondary themes as social critique, not just piety.
c11_hin_ar_cbse_09_002: Narrative structure knowledge helps locate where secondary themes cluster (opening vs closing stanzas, refrain patterns).
c11_hin_ar_cbse_09_006: Primary theme identification is the anchor - secondary themes only become visible in relation to the established central argument.
c11_hin_ar_cbse_09_005: Secondary themes like bureaucratic complicity and collective resistance are carried by supporting characters.  

## FORWARD_NODE_IDS
c11_hin_ar_cbse_09_008, c11_hin_ar_cbse_09_009, c11_hin_ar_cbse_09_013, c11_hin_ar_cbse_09_015, c12_hin_a_cbse_01_007, c12_hin_a_cbse_08_007, c12_hin_a_cbse_09_007, c12_hin_a_cbse_10_007, c12_hin_ar_cbse_09_007, c12_hin_ar_cbse_10_007, c12_hin_ar_cbse_09_001

## FORWARD_REASONS
c11_hin_ar_cbse_09_008: Imagery analysis requires thematic mapping - each metaphor (knife, path, mirror) serves a specific secondary theme.
c11_hin_ar_cbse_09_009: Irony and symbolism operate at the intersection of primary and secondary themes (e.g., "sharp knife" symbolizes both simplicity and violence against hierarchy).
c11_hin_ar_cbse_09_013: Critical interpretation synthesizes all themes; secondary themes provide the evidence base for evaluative arguments.
c11_hin_ar_cbse_09_015: Secondary themes (social hypocrisy, inner purity) offer additional angles for discussion.  
c12_hin_a_cbse_01_007: Chapter 9 explored irony as thematic tool.  
c12_hin_a_cbse_08_007: अगला तार्किक चरण: Secondary themes are the underlying, complementary ideas in a literary work that support, contrast w... इस नोड की अवधारणाओं को सीधे उपयोग/विस्तारित करता है।  
c12_hin_a_cbse_09_007: Class 11 practice in identifying secondary themes in Antra poems provides methodological foundation.  
c12_hin_a_cbse_10_007: Familiarity with tradition-modernity tension as thematic dialectic.  
c12_hin_ar_cbse_09_007: अगला तार्किक चरण: Secondary themes are the underlying, supporting ideas in a literary work that complement the primary... इस नोड की अवधारणाओं को सीधे उपयोग/विस्तारित करता है।  
c12_hin_ar_cbse_10_007: अगला तार्किक चरण: Secondary themes are the underlying ideas, motifs, and concerns that run parallel to the primary the... इस नोड की अवधारणाओं को सीधे उपयोग/विस्तारित करता है।  
c12_hin_ar_cbse_09_001: st images. c12_hin_ar_cbse_09_006: Primary theme must be fixed first to define what is "secondary". c11_hin_ar_cbse_09_007: Class 11 practice in identifying secondary themes in simpler texts builds the analytical habit.  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
none

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_09_001 -> c11_hin_ar_cbse_09_006 -> c11_hin_ar_cbse_09_007 -> c11_hin_ar_cbse_09_008

## THIS_FORMULA
N/A - conceptual

## FORMULA_VARIABLES
N/A

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
conceptual

## CROSS_SUBJECT
c11_history_medieval_bhakti | The secondary themes in Dhabbuji (critique of ritualism, caste hierarchy, knowledge monopolies) are direct literary expressions of the same social forces studied in Medieval Indian History: the Nirguna Bhakti movement's challenge to Brahmanical orthodoxy and Sultanate-era social stratification.
c11_sociology_caste_gender | The explicit naming of "tkfr&Hksn, o.kZ&Hksn, laiznk;&Hksn" (caste, class, gender) in the NCERT background note provides a 15th-century articulation of intersectionality - a core concept in modern sociology - showing how pre-modern texts theorized overlapping oppressions.

## PREREQ_CONCEPT
Primary theme identification (spiritual equality as the central argument of Nirguna Bhakti) - without this anchor, secondary themes appear as disconnected topics rather than architectural supports.

## PREREQ_BEFORE
Student must be able to state the primary theme in one sentence with textual evidence, and distinguish between "theme" (abstract idea) and "topic" (subject matter like caste, God, knowledge).

## PREREQ_STUCK
Review c11_hin_ar_cbse_09_006 - specifically the worked example showing how to derive "spiritual equality transcends social hierarchy" from the refrain pattern and key verses.

## WORKED_EXAMPLE_1
PROBLEM: Analyze how the secondary theme of "experiential knowledge versus textual authority" develops across three stanzas of Dhabbuji's poem. The NCERT notes he gained knowledge "ns'kkVu vkSj lRlax ls" (from scriptures and Vedas) but his verses prioritize "Kku" (realized wisdom). Trace this tension.

STEPS:
- Step 1: Identify the textual markers - locate all references to books, Vedas, pandits, reading versus knowing, doing, experiencing in the given stanzas.
- Step 2: Categorize each marker - is it presented positively (as source), negatively (as obstacle), or dialectically (transcended)?
- Step 3: Map the progression - does the poem move from citing authority to rejecting it, or integrate both? Note the shift from "ns'kkVu vkSj lRlax" (external) to "fdrkch Kku osQ LFkku ij" (internal locus).
- Step 4: Connect to secondary theme statement - formulate: "Textual knowledge is necessary but insufficient; it must be transmuted into lived wisdom (Kku) through devotion, making the knower the new authority."
- Step 5: Verify against primary theme - explain how this secondary theme explains *why* equality is spiritual not social: because Kku is accessible to all regardless of caste, unlike Vedic study restricted to dvijas.

REASONING: This 5-step method moves from evidence collection to thematic synthesis, ensuring the secondary theme emerges from textual pattern not imposition. The dialectical reading (not simple rejection) reflects Nirguna Bhakti's nuanced stance: they used Sanskritic vocabulary to subvert Sanskritic authority.

ANSWER: The secondary theme unfolds as a three-stage argument: (1) Acknowledgment - "ns'kkVu vkSj lRlax ls Kku izkIr" (knowledge gained from scriptures) establishes legitimacy; (2) Relocation - "fdrkch Kku osQ LFkku ij vk¡[kksa ns[ks lR; vkSj vuqHko" (on the ground of realized knowledge, they placed love and devotion as primary) shifts authority from text to experience; (3) Democratization - since Kku comes through bhakti not birth, it undermines caste monopoly on truth. This makes "knowledge pathway" a secondary theme that structurally enables the primary theme of equality.

## WORKED_EXAMPLE_2
PROBLEM: The NCERT describes Dhabbuji as "deZdkaM vkSj osn&fopkj osQ fojksèkh" (proponent of meditation and philosophical discourse) yet his poetry uses "lkI+kQ ,oa nks Vwd 'kCnksa" (simple, two-and-a-half words). Analyze this apparent contradiction as a secondary theme: "simplicity as strategic subversion."

STEPS:
- Step 1: Define the contradiction - he mastered elite forms (yoga, philosophy, Sanskrit) but chose vernacular brevity. Why?
- Step 2: Find textual evidence - the "ck<+h dk"V gh dkVS" (sharp knife) metaphor; the couplet structure itself (extreme compression); the refusal of ornate imagery.
- Step 3: Analyze the function - simplicity here is not inability but *refusal*. It denies the audience the pleasure of aesthetic consumption, forcing confrontation with content.
- Step 4: Connect to social theme - ornate poetry = courtly/Brahmanical performance requiring patronage and Sanskrit literacy. Brevity = accessible, memorizable, weaponizable by anyone.
- Step 5: Synthesize the secondary theme - "Strategic simplicity: the poet masters complexity to reject it, making spiritual truth available to the excluded by stripping away the gatekeeping apparatus of literary culture."

REASONING: This analysis treats form as ideology. The "two-and-a-half words" claim (hyperbolic) signals that Dhabbuji's brevity is a *deliberate political act* - he could write kavya but chooses doha. The knife metaphor confirms: simplicity cuts; complexity decorates.

ANSWER: The secondary theme is **aesthetic resistance through radical accessibility**. Dhabbuji's mastery of "deZdkaM vkSj osn&fopkj" proves he isn't simple from ignorance - he's simple *on purpose*. The "sharp knife" verse performs this: it uses a complex metaphor (knife = language = truth) in minimal words to say "truth needs no decoration." This subverts the courtly tradition where poetic skill displayed status. By making the highest wisdom speak in the lowest register, he enacts the equality he preaches.

## WORKED_EXAMPLE_3
PROBLEM: Synthesize three secondary themes (critique of ritualism, dismantling hierarchy, simplicity as resistance) to explain the poem's closing stance: "ek;k nsf[k osQ txr yqHkkauka dkgs js uj xjckauka" (don't let the thief of ego steal the essence of the one vision). Show how each secondary theme illuminates a different dimension of "ego" (ahamkar) as the final barrier.

STEPS:
- Step 1: Deconstruct "ego" (ahamkar) in Bhakti framework - it's not individual pride but *structural identification* with caste, knowledge, ritual purity.
- Step 2: Map secondary theme 1 (ritualism) → ego as "I am pure because I bathe/recite" - external performance substituting for internal transformation.
- Step 3: Map secondary theme 2 (hierarchy) → ego as "I am superior because of birth" - the thief stealing the vision of oneness.
- Step 4: Map secondary theme 3 (simplicity) → ego as "I know because I use complex language" - intellectual pride blocking direct perception.
- Step 5: Show convergence - all three egos are *false authorities* (ritual, birth, scholarship) that the "one vision" (ek nsf[) dissolves.
- Step 6: Formulate unified reading - the closing verse doesn't just warn against pride; it identifies the *specific ego-forms* the poem has been dismantling. The "thief" steals by making the seeker mistake the container (caste, ritual, words) for the content (divine presence).

REASONING: This synthesis demonstrates how secondary themes are not parallel tracks but *converging diagnostics* of the same spiritual pathology. The closing verse functions as a thematic key: each secondary theme names one disguise of the thief.

ANSWER: The poem's architecture reveals ego as a three-headed thief: (1) Ritual ego - "I did the puja, I am holy" (critiqued by ns'kkVu/lRlax rejection); (2) Social ego - "I am high-born, I deserve grace" (dismantled by tkfr/o.kZ/laiznk; naming); (3) Intellectual ego - "I speak Sanskrit, I know truth" (subverted by lkI+kQ 'kCn). The "ek nsf[" (one vision) sees through all three because it operates at the level of Kku (realized wisdom) where containers dissolve. The secondary themes collectively answer: "What blocks the primary theme (equality)?" - not ignorance, but *false knowledge* in three guises.

## COMPETENCY_QUESTION_1
QUESTION: A Class 11 student writes in their board exam: "Dhabbuji's secondary themes are caste equality, devotion, and simple living." The examiner awards 1/3 marks. Using the distinction between *topic* and *theme*, and the concept of *thematic function*, explain why this answer is insufficient and rewrite it to score full marks.

COMPETENCY: Thematic analysis precision - distinguishing topic from theme, and stating thematic function (what the theme *does* in the text).

STEPS:
- Step 1: Identify the error - "caste equality" is the primary theme; "devotion" and "simple living" are topics, not themes. A theme must be a *proposition* (e.g., "devotion transcends ritual").
- Step 2: Explain thematic function - each secondary theme must be stated as a claim the text makes, with its role relative to the primary theme.
- Step 3: Rewrite using the formula: "Secondary Theme X: [Proposition] - [Function: how it supports/complicates primary theme] - [Evidence: textual marker]."
- Step 4: Provide the corrected answer for all three.

ANSWER: The original answer lists topics, not themes. Corrected version: (1) **Critique of ritualistic authority**: "Textual/ritual knowledge (ns'kkVu/lRlax) is insufficient without realized wisdom (Kku)" - Function: explains why caste-based religious monopoly is illegitimate - Evidence: "ns'kkVu vkSj lRlax ls Kku izkIr... fdrkch Kku osQ LFkku ij". (2) **Intersectional dismantling of hierarchy**: "Caste, class, and gender are co-constitutive barriers to spiritual vision" - Function: maps the structure equality must overcome - Evidence: "tkfr&Hksn, o.kZ&Hksn, laiznk;&Hksn osQ LFkku ij". (3) **Strategic simplicity as epistemic resistance**: "Radical linguistic accessibility enacts the equality it preaches" - Function: makes the primary theme formally realizable, not just verbally claimed - Evidence: "lkI+kQ nks Vwd 'kCn", "ck<+h dk"V gh dkVS".

DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: In a comparative question, you're asked: "How does Dhabbuji's treatment of 'knowledge' (Kku) as a secondary theme differ from Kabir's treatment in 'Pada 1' (Aroh Chapter 8)? Both reject bookish knowledge, but their *thematic strategies* differ. Analyze using the concepts of 'inversion' versus 'subversion'."

COMPETENCY: Comparative thematic analysis across texts - identifying distinct rhetorical strategies within shared thematic territory.

STEPS:
- Step 1: Recall Kabir's strategy in "Pada 1" - he *inverts* scholarly categories (pandit becomes ignorant, illiterate becomes wise) using paradox and shock.
- Step 2: Recall Dhabbuji's strategy - he *subverts* the knowledge hierarchy by relocating authority to the devotee's experience (Kku) without denying his own scriptural learning.
- Step 3: Define the distinction - Inversion = flipping the hierarchy (top becomes bottom). Subversion = dissolving the hierarchy's legitimacy (the ladder itself is false).
- Step 4: Map to secondary theme function - Kabir's inversion serves *provocation*; Dhabbuji's subversion serves *accessibility*.
- Step 5: Write the comparative answer with textual anchors from both poets.

ANSWER: Kabir uses **inversion**: "Pandit moorakh bhae, bed padhi padhi jaani" - the learned become fools, the unlearned know. This *flips* the hierarchy to shock the audience into recognition. Dhabbuji uses **subversion**: "ns'kkVu vkSj lRlax ls Kku izkIr... fdrkch Kku osQ LFkku ij" - he acknowledges scriptural learning but *relocates* its validity to the internal ground of realized wisdom. The hierarchy isn't flipped; its *foundation* is shifted from external text to internal experience. Thematic consequence: Kabir's secondary theme is "the world is upside down" (provocation); Dhabbuji's is "the ground has moved" (invitation). Both reject bookish authority, but Kabir attacks the *person* of the pandit; Dhabbuji attacks the *monopoly* of the text. This makes Dhabbuji's strategy more inclusive - the pandit too can access Kku by shifting ground.

DIFFICULTY: hard