## DEFINITION
Supporting characters are secondary figures in a narrative who interact with the protagonist to advance the plot, reveal thematic concerns, or highlight the protagonist's traits through contrast or parallelism; in travel literature like *Jammu-Kashmir ki Yatra Kahaniyan*, they embody the region's cultural diversity, historical memory, and socio-political realities through their distinct voices and lived experiences.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student can identify at least three supporting characters from the text, cite specific textual evidence for each character's role, and write a structured analytical paragraph explaining how each supporting character illuminates a distinct aspect of the central theme (cultural syncretism, displacement, or resilience) using the PEEL method.

## SCOPE_BOUNDARY
This node covers analysis of supporting characters in the prescribed travel narratives of Chapter 5 only; it does not cover character analysis of the protagonist (covered in node 004), thematic synthesis (nodes 006-007), or literary devices (nodes 008-009).

## WALKTHROUGH
Imagine you are traveling through Srinagar's old city and meet an elderly carpet weaver who tells you his grandfather wove shawls for Dogra kings—his story isn't the main plot, but it makes the history alive. Similarly, in our chapter, the supporting characters—like the Kashmiri Pandit neighbor, the Gujjar shepherd, or the Sikh truck driver—are not the narrator but they carry the weight of the region's layered identity. Begin by listing every named or distinctly described person the narrator encounters. Next, ask: what does this person represent—faith, displacement, continuity, resistance? Then find one concrete detail (dialogue, action, description) that proves your claim. Finally, connect that detail to the chapter's larger concern: how ordinary lives negotiate extraordinary histories.

## DIAGNOSTIC_QUESTION_1
Name any two supporting characters from the travel narratives in Chapter 5 and state one specific detail the text provides about each (e.g., occupation, community, or a quoted remark).

## DIAGNOSTIC_ANSWER_1
Correct answer: Examples include the Kashmiri Pandit neighbor who recalls shared festivals, and the Gujjar shepherd who describes seasonal migration routes. A wrong answer that only names "a local man" or "people" without textual specificity reveals the student has not done close reading and cannot distinguish supporting characters from background figures.

## DIAGNOSTIC_QUESTION_2
Explain in your own words how a supporting character in a travel narrative differs from a supporting character in a fictional short story, using an example from the chapter.

## DIAGNOSTIC_ANSWER_2
Correct answer: In travel narratives, supporting characters are real people encountered by the narrator, so their words carry testimonial weight and historical authenticity; e.g., the Sikh truck driver's account of 1947 violence is a primary source, not authorial invention. A wrong answer that treats them as fictional constructs shows misunderstanding of the genre's non-fictional contract with the reader.

## DIAGNOSTIC_QUESTION_3
The narrator meets a retired schoolteacher in Anantnag who says, "Our textbooks had chapters on both Lal Ded and Sheikh Noor-ud-din." Using this evidence, write a PEEL paragraph (Point, Evidence, Explanation, Link) showing how this character supports the theme of cultural syncretism.

## DIAGNOSTIC_ANSWER_3
Correct answer: Point—The retired schoolteacher embodies Kashmir's syncretic heritage. Evidence—He references textbooks teaching both Lal Ded (Hindu mystic) and Sheikh Noor-ud-din (Muslim saint). Explanation—This dual inclusion in state curriculum reflects institutionalized pluralism, not merely personal tolerance. Link—Thus, his testimony anchors the chapter's argument that Kashmir's identity is historically composite, not communally fractured. A wrong answer that only summarizes the quote without explaining its thematic function reveals inability to move from evidence to analysis.

## DIAGNOSTIC_QUESTION_4
Compare the function of the Gujjar shepherd and the Kashmiri Pandit migrant in the narrative. How does each character's mobility (or forced immobility) reveal a different dimension of the region's political geography?

## DIAGNOSTIC_ANSWER_4
Correct answer: The Gujjar shepherd's vertical transhumance (seasonal movement between pastures) represents traditional, ecologically determined mobility that predates borders; the Pandit migrant's forced exile represents political violence severing ancestral ties. Together they map two axes of displacement—one voluntary and cyclical, the other coerced and permanent. A wrong answer that treats both as "displaced people" misses the critical distinction between pastoral nomadism and ethnic cleansing, showing weak analytical differentiation.

## DIAGNOSTIC_QUESTION_5
Evaluate the narrator's decision to include the Sikh truck driver's graphic account of 1990s militancy. Does this strengthen or weaken the chapter's credibility as a travelogue? Justify with two reasons.

## DIAGNOSTIC_ANSWER_5
Correct answer: It strengthens credibility because (1) it adheres to the travelogue's ethical obligation to witness uncomfortable truths rather than aestheticize the landscape, and (2) the driver's community-specific perspective (Sikh minority experience) complicates the dominant binary narrative of Hindu-Muslim conflict. A wrong answer calling it "unnecessary violence" or "distracting" reveals a preference for sanitized travel writing and misunderstanding of testimonial literature's purpose.

## DIAGNOSTIC_QUESTION_6
Create a 150-word vignette in the voice of a supporting character from the chapter (e.g., the houseboat owner, the apple orchard worker) describing a single morning in their life, embedding at least two sensory details and one historical reference that the chapter implies but does not state directly.

## DIAGNOSTIC_ANSWER_6
Expected answer: A vignette in first person, e.g., "The dal lake mist clings to my shikara's wooden ribs as I polish the brass samovar—my grandfather ferried Nehru here in '47, he'd say, but tourists only ask for wifi passwords." Good answers show voice authenticity, sensory precision (mist, brass, wood), and implicit historical layering. Poor answers write in third person, lack sensory grounding, or insert explicit history lectures instead of lived memory.

## COMMON_MISCONCEPTION
Students often treat supporting characters in travel narratives as "local color" or decorative background, listing them like tourist attractions rather than analyzing their testimonial function. They write: "The author meets many interesting people like a shepherd, a teacher, a driver" without grasping that each encounter is a deliberately selected testimony that constructs the region's polyphonic truth. This error stems from reading travel writing as description rather than argument.

## ON_FAILURE
Step 1: Have the student re-read one encounter (e.g., the Pandit neighbor) and underline every verb attributed to that character—speaks, recalls, insists, laughs. Step 2: Ask: "What claim about Kashmir does this person's testimony support?" Step 3: Model the shift: "Not 'he tells a story' but 'he testifies that shared festivals existed before 1990.'" Step 4: Practice converting three such encounters from summary to analytical claims using the template: "Character X's [specific detail] demonstrates [theme Y] because [reason Z]."

## BUILDS_ON
c11_hin_v_cbse_05_004 (Character Analysis: Protagonist) — understanding the narrator's perspective is prerequisite to analyzing how supporting characters reflect, challenge, or complicate that perspective.

## LEADS_TO
c11_hin_v_cbse_05_006 (Theme: Primary Theme and Message) — supporting characters provide the evidentiary foundation for thematic synthesis.

## PREREQUISITE_NODE_IDS
c11_hin_v_cbse_05_001, c11_hin_v_cbse_05_002, c11_hin_v_cbse_05_004
## PREREQUISITE_REASONS
c11_hin_v_cbse_05_001: Context/background knowledge of Jammu-Kashmir's history and demographics is essential to decode what supporting characters represent.
c11_hin_v_cbse_05_002: Understanding narrative structure reveals why the author places specific encounters at specific junctures.
c11_hin_v_cbse_05_004: The narrator's stance (curious, complicit, critical) shapes how supporting characters are framed and must be analyzed first.

## FORWARD_NODE_IDS
c11_hin_v_cbse_05_006, c11_hin_v_cbse_05_007, c11_hin_v_cbse_05_013, c11_hin_v_cbse_05_012, c11_hin_v_cbse_05_014, c11_hin_v_cbse_05_015, c12_hin_a_cbse_05_005, c12_hin_ar_cbse_06_005

## FORWARD_REASONS
c11_hin_v_cbse_05_006: Primary theme (syncretism/resilience) is substantiated through supporting characters' testimonies.
c11_hin_v_cbse_05_007: Secondary themes (memory, displacement, ecological wisdom) emerge from distinct supporting character arcs.
c11_hin_v_cbse_05_013: Critical interpretation requires evaluating the narrator's ethics in representing real people as characters.
c11_hin_v_cbse_05_012: Supporting characters' roles create relational evidence for inferential questions about family/social dynamics.  
c11_hin_v_cbse_05_014: Supporting characters (landlord, contractor) are needed for answers on conflict and systemic oppression.  
c11_hin_v_cbse_05_015: Supporting characters (folk singers, villagers) provide counter-perspective evidence  
c12_hin_a_cbse_05_005: Class 11 Vitan Chapter 5 reinforced character-role analysis in non-fiction narratives, transferable to poetic personae.  
c12_hin_ar_cbse_06_005: Class 11 Vitan foundation on supporting character analysis.  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
none

## CHAIN_DESCRIPTION
c11_hin_v_cbse_05_001 -> c11_hin_v_cbse_05_002 -> c11_hin_v_cbse_05_004 -> c11_hin_v_cbse_05_005 -> c11_hin_v_cbse_05_006

## THIS_FORMULA
N/A - conceptual

## FORMULA_VARIABLES
N/A

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
analytical

## CROSS_SUBJECT
c11_history_nationalism_in_india | The chapter's supporting characters embody competing nationalisms (Indian, Kashmiri, religious) — analyzing them mirrors History's study of how ordinary people negotiate nationalist narratives in contested territories.
c11_geography_human_geography | The Gujjar shepherd's transhumance and the apple orchard worker's crop cycles illustrate human-environment interaction in fragile mountain ecosystems — a core Human Geography concept.

## PREREQ_CONCEPT
Close reading of non-fictional narrative: distinguishing authorial voice from reported speech, and recognizing testimonial evidence.

## PREREQ_BEFORE
Student must be able to locate direct speech and reported speech in the text and identify the speaker's community/role.

## PREREQ_STUCK
Review "reported speech vs. direct speech in travelogues" and "identifying speaker's social location from textual clues" from node 002.

## WORKED_EXAMPLE_1
PROBLEM: Analyze how the Kashmiri Pandit neighbor's description of shared Shivratri-Eid celebrations functions as evidence for the theme of syncretism.
STEPS:
- Step 1: Locate the encounter in the text — identify the chapter section where the narrator visits the Pandit neighbor in Jammu camp.
- Step 2: Extract exact textual evidence — the neighbor's words: "We would send sevaiyan for Eid, they brought walnuts for Shivratri."
- Step 3: Identify the thematic claim — the chapter argues Kashmir's culture is historically composite, not essentially divided.
- Step 4: Explain the evidence's function — the reciprocal gift-giving (sevaiyan/walnuts) is a material practice of shared ritual life, not mere tolerance.
- Step 5: Connect to broader argument — this micro-history counters the macro-narrative of inevitable communal hatred; the neighbor's nostalgia is political testimony.
REASONING: The steps move from textual location to evidence extraction to thematic mapping to functional explanation to argumentative significance — the full analytical arc required for board answers.
ANSWER: The Pandit neighbor's testimony of reciprocal festival offerings (sevaiyan for Eid, walnuts for Shivratri) serves as concrete evidence of lived syncretism. The specificity of food items — domestic, feminine, everyday — makes the claim visceral and irrefutable. This supports the chapter's central argument that Kashmir's division was political imposition, not cultural destiny.

## WORKED_EXAMPLE_2
PROBLEM: The Gujjar shepherd says, "Our goats know the mountain passes better than the army's maps." Write a PEEL paragraph analyzing this statement's significance.
STEPS:
- Step 1: Point — The shepherd's remark asserts indigenous ecological knowledge as superior to state cartography.
- Step 2: Evidence — Quote the exact line; note the metaphor "goats know... better than army's maps."
- Step 3: Explanation — The goats' instinctive navigation represents generations of pastoral wisdom; the army's maps represent militarized territorial control. The contrast exposes two competing epistemologies of the same landscape.
- Step 4: Link — This reinforces the chapter's critique of top-down state power that ignores local lifeworlds; the shepherd becomes a symbol of epistemic resistance.
REASONING: The PEEL structure forces the student to separate claim, evidence, analysis, and thematic connection — the exact skill board examiners reward.
ANSWER: The Gujjar shepherd's declaration that "our goats know the mountain passes better than the army's maps" asserts the primacy of indigenous pastoral knowledge over state militarized geography. The metaphor juxtaposes organic, intergenerational wisdom (goats' instinct) with imposed, violent order (army maps), revealing two incompatible ways of knowing the land. This testimony anchors the chapter's argument that Kashmir's people possess a sovereignty of belonging that precedes and exceeds political sovereignty.

## WORKED_EXAMPLE_3
PROBLEM: Compare the narrative function of the Sikh truck driver (who recounts 1990s militancy) and the houseboat owner (who laments declining tourism). How do their griefs differ in political implication?
STEPS:
- Step 1: Identify both encounters — locate the truck driver's testimony (likely in a journey sequence) and houseboat owner's lament (likely in Srinagar stay).
- Step 2: Categorize each grief — driver: targeted communal violence, loss of community members, trauma of witnessing; owner: economic displacement, loss of livelihood, nostalgia for cosmopolitan past.
- Step 3: Analyze political valence — driver's grief implicates militant ideology and state failure to protect minorities; owner's grief implicates conflict economy, militarization's deterrent effect on tourism, and erasure of pluralistic urban culture.
- Step 4: Examine narrator's framing — does the narrator treat both as equal victims? Or does the driver's testimony carry more moral weight due to direct violence?
- Step 5: Synthesize — the driver represents the shattering of social fabric; the owner represents the hollowing out of economic and cultural infrastructure. Together they map the totalizing impact of conflict.
- Step 6: Connect to chapter's architecture — these two encounters likely bookend a journey (outbound/return) or represent rural/urban poles, structuring the narrative's emotional arc.
REASONING: This multi-step comparison requires distinguishing types of violence (direct/structural), analyzing narrative positioning, and synthesizing — a high-order skill for 6-mark board questions.
ANSWER: The Sikh truck driver's grief stems from targeted communal massacre — a violent severing of the social contract — while the houseboat owner's grief stems from the slow strangulation of a pluralistic economy by militarization and fear. The driver's testimony indicts militant ideology and state complicity; the owner's indicts the conflict economy that makes hospitality impossible. Narratively, the driver often appears in transit (on highways of violence), the owner in stationary decay (Dal Lake's emptiness), mapping the spatial logic of Kashmir's tragedy: movement becomes dangerous, staying becomes unsustainable.

## COMPETENCY_QUESTION_1
QUESTION: A board exam question asks: "Supporting characters in *Jammu-Kashmir ki Yatra Kahaniyan* are not merely people the author meets; they are arguments the author makes. Explain with reference to any two supporting characters." Write a 120-word answer using the PEEL structure for each character.
COMPETENCY: Analytical writing with textual evidence and thematic synthesis
STEPS:
- Step 1: Select two supporting characters with distinct thematic functions (e.g., Pandit neighbor for syncretism, Gujjar shepherd for indigenous knowledge).
- Step 2: For each, write a PEEL paragraph: Point (what argument they embody), Evidence (specific quote/detail), Explanation (how evidence proves point), Link (connection to chapter's thesis).
- Step 3: Add a concluding sentence comparing their arguments — e.g., "Together they argue that Kashmir's past was plural and its present is contested."
- Step 4: Check word count, terminology (testimony, syncretism, epistemic resistance), and board-style formal tone.
ANSWER: The Kashmiri Pandit neighbor embodies the argument of historical syncretism: his recollection of reciprocal Shivratri-Eid offerings (sevaiyan/walnuts) proves composite culture was lived practice, not abstraction. This testimony counters the narrative of inevitable division. The Gujjar shepherd embodies the argument of epistemic sovereignty: his claim that "goats know passes better than army maps" asserts indigenous pastoral wisdom over militarized cartography. This testimony resists state erasure of local lifeworlds. Together, they argue that Kashmir's identity is rooted in plural coexistence and ecological belonging — both violently disrupted by political forces. The author does not merely record voices; he curates them as evidence for a historical thesis.
DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: "The narrator's ethical dilemma in representing real people as literary characters." Critically evaluate this statement with reference to the chapter. Discuss: (a) the risk of aestheticizing suffering, (b) the necessity of witness, and (c) how the text navigates this tension.
COMPETENCY: Critical evaluation of non-fictional ethics and narrative strategy
STEPS:
- Step 1: Define the ethical dilemma — travelogues transform living people into textual figures, risking exploitation or voyeurism.
- Step 2: Address (a) aestheticizing suffering — cite a moment where landscape description threatens to beautify ruin (e.g., "Dal Lake's tragic beauty").
- Step 3: Address (b) necessity of witness — cite a moment where silence would be complicity (e.g., truck driver's testimony demanding record).
- Step 4: Address (c) textual navigation — analyze specific strategies: using direct speech (preserving voice), refusing closure (ending encounters ambiguously), self-implication (narrator acknowledging own privilege as tourist).
- Step 5: Conclude with a judgment — the text largely succeeds because it centers the speakers' agency, not the narrator's empathy.
ANSWER: The dilemma is real: every encounter risks making suffering picturesque. The text negotiates this by (a) refusing aesthetic closure — the houseboat owner's lament ends not with sunset imagery but with "no bookings this season"; (b) privileging direct speech — the truck driver's graphic account is rendered verbatim, unmediated by narrator's commentary; (c) implicating the narrator — he admits "I came for beauty, they gave me history." This self-awareness prevents the narrator from becoming the hero of his own sensitivity. The supporting characters remain subjects of their own testimony, not objects of his gaze. The text succeeds as witness because it lets the ethical tension remain unresolved.
DIFFICULTY: hard