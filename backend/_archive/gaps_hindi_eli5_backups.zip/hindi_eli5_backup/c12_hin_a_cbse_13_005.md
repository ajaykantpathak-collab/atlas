## DEFINITION
Character analysis of supporting characters involves examining how secondary figures in a narrative — through their actions, dialogues, relationships, and symbolic roles — advance the plot, illuminate the protagonist, and embody the story’s themes. In "Hkh'e lkguh", this means dissecting characters like usg: th and ;kLlsj vjkI+kQkr to reveal how they represent intellectual and revolutionary nationalism respectively.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student can independently identify all supporting characters in the story, cite specific textual evidence (actions, speeches, narrator’s descriptions) for each trait, explain each character’s narrative function (foil, mentor, symbol, plot catalyst), and write a structured PEEL paragraph comparing two supporting characters’ contributions to the central theme of nationalism.

## SCOPE_BOUNDARY
This node covers detailed analysis of usg: th, ;kLlsj vjkI+kQkr, and minor characters (cyjkt, tokgjyky, jkes'ojh usg:) in "Hkh'e lkguh". It does NOT cover protagonist analysis (node 004), theme derivation (nodes 006, 007), or literary devices (nodes 008, 009) — those are separate nodes.

## WALKTHROUGH
Imagine you’re facing a 5‑mark board question: “Analyze the role of usg: th in shaping the narrator’s worldview.” You remember the protagonist xkaèkh, but usg: th feels fuzzy — you recall he edits a paper and tells a story, but how to structure the answer? Start by listing every scene where usg: th appears (press office, restaurant, V~;wful, his storytelling). Next, highlight his exact words and the narrator’s comments about him. Then group these into traits: intellectual guide, nationalist mentor, allegorical storyteller. Finally, use the PEEL framework: Point (he embodies intellectual nationalism), Evidence (edits “yksVl”, tells woodcutter story), Explanation (the allegory teaches self‑reliance), Link (this shapes the narrator’s shift from passive observer to active participant). The key insight: supporting characters are not background decoration; they are thematic engines.

## DIAGNOSTIC_QUESTION_1
List three supporting characters in "Hkh'e lkguh" and give one defining trait for each, based solely on the text.

## DIAGNOSTIC_ANSWER_1
Correct answer: (1) usg: th – intellectual nationalist (edits “yksVl”, uses allegory to teach self‑reliance); (2) ;kLlsj vjkI+kQkr – revolutionary sacrifice (endures torture, declares “os vkiosQ gh ugha gekjs Hkh usrk gSa”); (3) cyjkt – bridging connector (introduces narrator to xkaèkh, facilitates first meeting). A wrong answer that merely names characters without textual traits (e.g., “usg: th is a friend”) reveals the student cannot move beyond surface identification to evidence‑based characterization.

## DIAGNOSTIC_QUESTION_2
Explain why usg: th tells the woodcutter (ck”khxj) story to the narrator. What does this choice reveal about usg: th’s worldview?

## DIAGNOSTIC_ANSWER_2
Correct answer: usg: th uses the woodcutter’s self‑reliance (cutting his own wood, refusing to beg) as an allegory for national self‑determination — he wants the narrator to internalize that freedom must be earned through one’s own labor, not gifted. This reveals usg: th believes in intellectual awakening through indigenous metaphors, not abstract slogans. A wrong answer that says “to entertain” or “to pass time” shows the student misses the didactic function of embedded stories in realist fiction.

## DIAGNOSTIC_QUESTION_3
Using the PEEL structure, write a 4‑sentence paragraph analyzing ;kLlsj vjkI+kQkr’s patriotism with one piece of textual evidence.

## DIAGNOSTIC_ANSWER_3
Correct answer (sample): Point: ;kLlsj vjkI+kQkr embodies revolutionary patriotism through bodily sacrifice. Evidence: When tortured, he tells the narrator, “os vkiosQ gh ugha gekjs Hkh usrk gSa. mrus gh vknj.kh; ftrus vkiosQ fy,” (p. 97). Explanation: This dialogue equates the colonizer’s cruelty with a shared national duty to endure suffering, framing torture as collective responsibility. Link: His scarred body becomes a living symbol of the price of freedom, contrasting with usg: th’s intellectual resistance. A wrong answer that quotes without explaining the symbolism or omits the Link step shows inability to connect evidence to thematic significance.

## DIAGNOSTIC_QUESTION_4
Compare the methods of nationalism represented by usg: th and ;kLlsj vjkI+kQkr. How do their approaches differ in the story?

## DIAGNOSTIC_ANSWER_4
Correct answer: usg: th practices intellectual nationalism — editing “yksVl”, writing allegories, mentoring youth — working within cultural spaces to awaken consciousness. ;kLlsj vjkI+kQkr embodies revolutionary nationalism — direct confrontation, enduring physical torture, facing colonial courts — making the body a site of resistance. The former seeks mental decolonization; the latter accepts physical martyrdom. A wrong answer that calls both “freedom fighters” without distinguishing method reveals failure to analyze nuance in nationalist strategies portrayed in the text.

## DIAGNOSTIC_QUESTION_5
Which supporting character — usg: th or ;kLlsj vjkI+kQkr — has a greater impact on the narrator’s perspective? Justify with two textual reasons.

## DIAGNOSTIC_ANSWER_5
Correct answer: usg: th has greater impact because (1) the narrator explicitly states his worldview shifted after hearing usg: th’s stories and observing his mentorship (“xkaèkh th dh ns[kjs[k esa mldk bykt py jgk Fkk”), and (2) the narrator’s own career as a writer/editor mirrors usg: th’s path, showing lasting influence. ;kLlsj vjkI+kQkr inspires awe but remains a distant symbol. A wrong answer that picks ;kLlsj vjkI+kQkr solely because “he suffered more” confuses emotional intensity with narrative influence on the protagonist.

## DIAGNOSTIC_QUESTION_6
Write a diary entry (80‑100 words) from cyjkt’s perspective describing his first meeting with xkaèkh, incorporating cyjkt’s admiration for xkaèkh’s simplicity.

## DIAGNOSTIC_ANSWER_6
Criteria for a good answer: (a) first‑person voice as cyjkt, (b) references the press office setting and xkaèkh’s thumb‑impression signing, (c) expresses admiration for xkaèkh’s honesty/simplicity, (d) connects to cyjkt’s role as bridge between narrator and xkaèkh. A poor answer that writes in third person or omits the thumb‑impression detail shows the student cannot adopt a character’s perspective or recall specific textual markers.

## COMMON_MISCONCEPTION
Students often treat supporting characters as mere “helpers” to the protagonist, listing their actions without linking them to theme. In this story, the specific error is seeing usg: th only as “the narrator’s friend who tells a story” and missing that his woodcutter allegory is a deliberate pedagogical tool for nationalist education. Similarly, they reduce ;kLlsj vjkI+kQkr to “the tortured revolutionary” and overlook his deliberate rhetorical strategy (“mrus gh vknj.kh;”) that frames suffering as shared national duty. This happens because students hunt for plot points instead of analyzing authorial purpose behind each character’s design.

## ON_FAILURE
1. Re‑read the three key scenes: usg: th at the press (pp. 90‑91), usg: th’s storytelling at the restaurant (pp. 94‑95), and ;kLlsj vjkI+kQkr’s prison meeting (pp. 96‑97). 2. Create a two‑column table: Column A = exact quote/action; Column B = what it reveals about nationalism. 3. Write one PEEL paragraph for usg: th and one for ;kLlsj vjkI+kQkr using the table. 4. Self‑check: Does each paragraph have a clear Point, textual Evidence, Explanation of symbolism, and Link to the narrator’s growth? If not, repeat step 2 with a focus on symbolic meaning.

## BUILDS_ON
Character Analysis: Protagonist (node 004) where students learned to extract traits from textual evidence for the main character; now they apply the same skill to secondary figures.

## LEADS_TO
Theme: Primary Theme and Message (node 006) where the collective portrait of supporting characters converges into the story’s central nationalist theme.

## PREREQUISITE_NODE_IDS
c12_hin_a_cbse_13_004, c11_hin_ar_cbse_13_005, c12_hin_a_cbse_13_002, c12_hin_a_cbse_13_003, c12_hin_a_cbse_13_001

## PREREQUISITE_REASONS
c12_hin_a_cbse_13_004: Protagonist analysis provides the baseline framework (PEEL, evidence‑trait‑function) that students now transfer to supporting characters.
c11_hin_ar_cbse_13_005: Class 11 supporting‑character practice establishes the habit of distinguishing major vs. minor roles and using textual citations.
c12_hin_a_cbse_13_002: Plot structure knowledge tells students *when* each supporting character enters/exits, which frames their narrative weight.
c12_hin_a_cbse_13_003: Setting/atmosphere (press office, prison, restaurant) shapes how characters behave and what they symbolize.
c12_hin_a_cbse_13_001: "Before You Read: की समझ आवश्यक है, क्योंकि यह नोड (Character analysis of supporting characters involves examining how secondary figures in a...) इसी आधार पर आगे बढ़ता है।  

## FORWARD_NODE_IDS
c12_hin_a_cbse_13_006, c12_hin_a_cbse_13_007, c12_hin_a_cbse_13_013, c12_hin_a_cbse_13_014, c12_hin_a_cbse_13_010

## FORWARD_REASONS
c12_hin_a_cbse_13_006: Primary theme (nationalism) is built from the combined ideologies of usg: th (intellectual) and ;kLlsj vjkI+kQkr (revolutionary).
c12_hin_a_cbse_13_007: Secondary themes (mentorship, sacrifice, intergenerational duty) emerge directly from supporting‑character arcs.
c12_hin_a_cbse_13_013: Critical thinking tasks require comparing/contrasting character functions — exactly what this node trains.
c12_hin_a_cbse_13_014: Writing skills (character sketch, analytical paragraph) directly apply the PEEL models practiced here.
c12_hin_a_cbse_13_010: Supporting characters' dialogues introduce words like "py cluk".  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
c12_history_nationalist_movement: The story’s portrayal of moderate (usg: th) vs. revolutionary (;kLlsj vjkI+kQkr) nationalism mirrors the historical debate between constitutional agitation and armed struggle in the 1930s.
c12_civics_citizenship_values: Characters embody civic virtues — usg: th models informed citizenship through press freedom; ;kLlsj vjkI+kQkr models dissent and sacrifice for collective rights.

## CHAIN_DESCRIPTION
c12_hin_a_cbse_13_004 -> c12_hin_a_cbse_13_005 -> c12_hin_a_cbse_13_006

## THIS_FORMULA
N/A - conceptual

## FORMULA_VARIABLES
N/A

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
conceptual

## CROSS_SUBJECT
N/A | The dual portrayal of intellectual and revolutionary nationalism in the story reflects the real historical spectrum of the 1930s Indian freedom struggle.
 N/A | usg: th’s press work and ;kLlsj vjkI+kQkr’s courtroom defiance illustrate active citizenship and the right to dissent — core civics concepts.
## PREREQ_CONCEPT
Ability to extract character traits from textual evidence (actions, dialogues, narrator’s commentary) and organize them into a PEEL paragraph.

## PREREQ_BEFORE
Student must have read the full story "Hkh'e lkguh" and completed the protagonist analysis of xkaèkh (node 004).

## PREREQ_STUCK
If stuck, revisit the PEEL paragraph structure from Class 11 (c11_hin_ar_cbse_13_005) and the protagonist analysis steps in node 004.

## WORKED_EXAMPLE_1
PROBLEM: Write a 100‑word character sketch of usg: th using the PEEL structure, citing at least two textual details.

STEPS:
- Step 1: Identify usg: th’s key scenes — press office introduction (p. 90), restaurant storytelling (pp. 94‑95), V~;wful meeting (pp. 96‑97).
- Step 2: List traits with evidence: (a) Intellectual nationalist — edits “yksVl”, mentors narrator; (b) Allegorical teacher — woodcutter story teaches self‑reliance; (c) Bridge between generations — connects narrator to ;kLlsj vjkI+kQkr.
- Step 3: Choose a unifying Point: usg: th represents intellectual nationalism that awakens consciousness through indigenous metaphor.
- Step 4: Draft PEEL: Point (sentence 1), Evidence — “yksVl” editorship and woodcutter allegory (sentence 2), Explanation — allegory shifts narrator from passive to active (sentence 3), Link — narrator’s later writing career mirrors usg: th’s path (sentence 4).
- Step 5: Edit for word count and flow; ensure each claim has a textual anchor.

REASONING: The PEEL structure forces the student to move beyond listing traits to explaining *how* the text builds the character’s thematic role. Steps 1‑2 ensure evidence‑grounded claims; Steps 3‑4 build analytical depth; Step 5 hones exam‑ready conciseness.

ANSWER:
usg: th embodies intellectual nationalism, using cultural tools to awaken political consciousness. As editor of the nationalist paper “yksVl” and mentor to the narrator, he chooses allegory over rhetoric — his woodcutter story (ck”khxj cutting his own wood rather than begging) symbolizes self‑reliance as the foundation of freedom. This pedagogical method transforms the narrator from a curious observer into a committed writer, as seen when the narrator later adopts usg: th’s editorial role. Thus, usg: th’s quiet mentorship proves more enduringly influential than overt revolutionary acts.

## WORKED_EXAMPLE_2
PROBLEM: Analyze how ;kLlsj vjkI+kQkr’s physical suffering functions as a symbol in the story. Use two specific textual references.

STEPS:
- Step 1: Locate descriptions of ;kLlsj vjkI+kQkr’s body — “vn~Hkqr n`';” (p. 96), scars from torture, his dialogue in prison.
- Step 2: Identify the symbolic pattern: colonial violence marks the revolutionary’s body, but he reframes pain as shared national duty (“mrus gh vknj.kh;”).
- Step 3: Connect to broader symbolism: the scarred body = the wounded nation; endurance = collective resilience.
- Step 4: Contrast with usg: th’s unscarred intellectual body to highlight two nationalist strategies.
- Step 5: Write analysis: Point — ;kLlsj vjkI+kQkr’s tortured body symbolizes the somatic cost of freedom. Evidence — “vn~Hkqr n`';” and his declaration of shared duty. Explanation — the colonizer’s attempt to break him becomes proof of the nation’s unbreakable will. Link — this symbol haunts the narrator, making abstract nationalism visceral.
- Step 6: Verify that both textual references are integrated, not just quoted.

REASONING: This example teaches students to read physical description as symbolic language — a key skill for board “analyze” questions. Steps 1‑3 move from literal to figurative; Step 4 adds comparative depth; Steps 5‑6 produce exam‑standard analysis.

ANSWER:
;kLlsj vjkI+kQkr’s tortured body (“vn~Hkqr n`';”) operates as a living symbol of the nation under colonial violence. When he tells the narrator, “os vkiosQ gh ugha gekjs Hkh usrk gSa. mrus gh vknj.kh; ftrus vkiosQ fy,” he transposes personal suffering onto the collective, insisting that the scars inflicted by the ruler are actually the shared responsibility of the ruled. This reframing turns the revolutionary’s broken body into a testament to the nation’s capacity to endure and outlast oppression. Unlike usg: th’s intellectual resistance, ;kLlsj vjkI+kQkr’s symbolism is somatic — it forces the narrator (and reader) to *feel* the price of freedom, making nationalism visceral rather than abstract.

## WORKED_EXAMPLE_3
PROBLEM: Compare the narrative functions of cyjkt (the narrator’s brother) and tokgjyky (usg: th’s friend). How does each act as a connector, and what different worlds do they link?

STEPS:
- Step 1: List cyjkt’s appearances — introduces narrator to xkaèkh at press (p. 90), accompanies him throughout.
- Step 2: List tokgjyky’s appearances — appears at restaurant with usg: th (p. 94), tells the woodcutter story.
- Step 3: Define “connector” function: a character who bridges two otherwise separate narrative zones.
- Step 4: Analyze cyjkt: bridges narrator (middle‑class, educated) ↔ xkaèkh (working‑class, illiterate laborer). His familial bond makes the introduction natural.
- Step 5: Analyze tokgjyky: bridges usg: th’s intellectual circle ↔ folk allegory (woodcutter). His storytelling brings oral tradition into the nationalist salon.
- Step 6: Synthesize: both are connectors, but cyjkt connects *social classes* while tokgjyky connects *intellectual discourse* with *indigenous folk wisdom*. This dual bridging enriches the story’s exploration of nationalism across strata.
- Step 7: Write comparative paragraph using the above structure.

REASONING: This multi‑step comparison requires students to track minor characters across scenes, classify their structural roles, and evaluate their thematic contribution — a high‑order skill for 6‑mark board questions and competitive‑exam critical thinking.

ANSWER:
Both cyjkt and tokgjyky serve as narrative connectors, but they bridge fundamentally different worlds. cyjkt, the narrator’s brother, links the educated middle‑class narrator with the illiterate laborer xkaèkh, enabling the cross‑class encounter that anchors the story’s realism. His connector role is social and familial. tokgjyky, usg: th’s peer, links the urbane nationalist intellectuals (usg: th, narrator) with the indigenous folk wisdom embodied in the woodcutter ck”khxj. His connector role is cultural and epistemological. Together, they ensure the story’s nationalism is neither purely elite nor purely subaltern, but a dialogue between strata — a structural sophistication that elevates the text beyond simple propaganda.

## COMPETENCY_QUESTION_1
QUESTION: Read the following excerpt from usg: th’s dialogue (p. 97): “os vkiosQ gh ugha gekjs Hkh usrk gSa. mrus gh vknj.kh; ftrus vkiosQ fy.” Analyze the tone and rhetorical purpose of this statement in the context of the story’s depiction of nationalism.

COMPETENCY: Literary analysis and inference

STEPS:
- Step 1: Identify the speaker, audience, and immediate context (prison meeting, ;kLlsj vjkI+kQkr speaking to narrator).
- Step 2: Parse the literal meaning: “They are not only yours, they are ours too. They are as much duty‑bound as you.”
- Step 3: Determine tone — solemn, inclusive, reproachful yet unifying.
- Step 4: Explain rhetorical purpose: transforms personal torture into collective obligation; uses pronoun shift (“os” → “gekjs”) to dissolve individual/state boundary.
- Step 5: Connect to story’s nationalism: models revolutionary ethos where suffering is shared currency.

ANSWER:
The tone is solemn and inclusively reproachful. By shifting from “os” (they, the colonizers) to “gekjs” (ours), ;kLlsj vjkI+kQkr rhetorically annexes the enemy’s cruelty into a shared national duty — “mrus gh vknj.kh;”. This refuses the colonizer the monopoly on violence; instead, it frames endurance as a collective covenant. The statement’s purpose is to convert the narrator’s pity into responsibility, making the listener complicit in the revolutionary project. It encapsulates the story’s revolutionary nationalism: not abstract love for country, but concrete willingness to bear the ruler’s brutality as one’s own burden.

DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: Assertion (A): ;kLlsj vjkI+kQkr serves as a foil to xkaèkh in "Hkh'e lkguh". Reason (R): Both characters represent distinct facets of nationalism — xkaèkh embodies instinctive, labor‑based patriotism while ;kLlsj vjkI+kQkr embodies conscious, sacrifice‑based revolutionary nationalism. Evaluate the Assertion and Reason. Choose the correct option:
(a) Both A and R are true and R correctly explains A.
(b) Both A and R are true but R does not explain A.
(c) A is true but R is false.
(d) A is false but R is true.

COMPETENCY: Critical thinking and evaluation

STEPS:
- Step 1: Define foil — a character who contrasts with another to highlight particular qualities.
- Step 2: Check A: Does ;kLlsj vjkI+kQkr contrast with xkaèkh? Yes — xkaèkh is a simple laborer who loves country instinctively (“jks”k dk fu;e”); ;kLlsj vjkI+kQkr is an intellectual revolutionary who articulates nationalism as conscious sacrifice.
- Step 3: Check R: Does R accurately describe their nationalist facets? Yes — xkaèkh’s patriotism is shown through daily honesty and thumb‑impression dignity; ;kLlsj vjkI+kQkr’s is articulated in prison dialogue about shared duty.
- Step 4: Determine if R explains A: The contrast *is* the foil function — their differing nationalist expressions highlight each other’s mode. So R correctly explains A.
- Step 5: Select option (a).

ANSWER:
(a) Both A and R are true and R correctly explains A. ;kLlsj vjkI+kQkr’s conscious, articulated revolutionary nationalism throws xkaèkh’s instinctive, labor‑rooted patriotism into sharp relief, making each facet more visible — the textbook function of a foil.

DIFFICULTY: hard