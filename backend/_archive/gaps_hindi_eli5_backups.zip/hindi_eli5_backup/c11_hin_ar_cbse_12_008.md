## DEFINITION
Imagery (बिंब/प्रतीक) refers to the use of vivid, sensory language that creates mental pictures by appealing to the five senses (sight, sound, smell, touch, taste), while Metaphor (रूपक/उपमा) is a figure of speech that directly equates two unlike things without using "like" or "as" (जैसे/वैसे) to suggest a hidden similarity, transferring qualities from the vehicle (उपमान) to the tenor (उपमेय) for thematic depth.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student can independently identify at least three distinct images and two metaphors in the poem, explain how each appeals to specific senses, and articulate how the vehicle-tenor relationship in each metaphor reinforces the central theme of social discrimination and the girl child's resilience.

## SCOPE_BOUNDARY
This node covers identification, classification, and thematic analysis of imagery (visual, auditory, tactile) and metaphor (simple, extended, implied) specifically within the poem "पैक डक्यस डक्यस वीएंजु न पुख्ग्रह". It does NOT cover other figures of speech like simile (उपमा with 'जैसे'), personification (मानवीकरण), or hyperbole (अतिशयोक्ति), which are addressed in node c11_hin_ar_cbse_12_009.

## WALKTHROUGH
Imagine you are describing a monsoon evening to a friend who has never experienced one — you would not just say "it rained"; you would say "the smell of wet earth rose like incense, the drumroll on tin roofs drowned conversation, and cool needles pricked bare arms." That instinct to make the abstract tangible is exactly what the poet does with Paik's dark skin and her hunger for literacy. Begin by reading the poem aloud twice: first for the rhythm of the Rajasthani-inflected Hindi, second to underline every phrase that makes you see, hear, or feel something. Then circle every direct comparison where Paik or her world is equated to something else without "जैसे/वैसे". The key insight is that the poet uses the girl's body (dark skin, small hands) and her environment (threshold, letters, deity) as a compressed symbolic system — each image and metaphor does double duty: it paints a sensory scene AND advances the argument that education is the only weapon against caste-colour-gender oppression.

## DIAGNOSTIC_QUESTION_1
Define "imagery" (बिंब) and "metaphor" (रूपक) in your own words, and give one original example of each that is NOT from the textbook.

## DIAGNOSTIC_ANSWER_1
Imagery: Language that activates the five senses to create a concrete mental picture (e.g., "The kitchen smelled of cumin and burnt onions, and the pressure cooker hissed like an angry snake"). Metaphor: A direct equation between two unlike things to transfer meaning (e.g., "Her silence was a locked room with no keyhole"). A wrong answer that confuses metaphor with simile ("Her silence was like a locked room") reveals the student has not internalised the "absence of comparative particles" rule; a wrong answer that lists only visual imagery reveals a narrow sensory repertoire.

## DIAGNOSTIC_QUESTION_2
In the poem, the phrase "डक्यस डक्यस" (dark dark) appears repeatedly. Is this primarily an auditory image, a visual image, or a metaphor? Justify your classification in two sentences.

## DIAGNOSTIC_ANSWER_2
"डक्यस डक्यस" is primarily a **visual image** (दृश्य बिंब) because it forces the reader to see the girl's skin colour through insistent repetition; it becomes a metaphor only when the poet later equates that darkness with "ignorance" or "social stigma" in the lines where Paik says "रके दक्न घ क्क्षन्क् क्से" (they consider this darkness a flaw). A student who calls it only a metaphor misses the sensory grounding; a student who calls it only auditory confuses the phonetic repetition (alliteration) with the sense appealed to.

## DIAGNOSTIC_QUESTION_3
The poem contains the line: "पैक लूँज ध यम्ढ गे" (Paik is the threshold's Yama). Identify the tenor and the vehicle, then explain what quality of Yama is transferred to Paik in this context.

## DIAGNOSTIC_ANSWER_3
Tenor (उपमेय) = Paik; Vehicle (उपमान) = Yama (god of death/threshold guardian). The transferred quality is **inescapable authority at the boundary** — just as Yama decides who enters the afterlife, Paik's literacy decides who enters the world of written power. A wrong answer that says "Yama means death, so Paik brings death" shows literalism and ignores the "threshold guardian" aspect; a wrong answer that swaps tenor/vehicle reveals confusion about the direction of metaphorical transfer.

## DIAGNOSTIC_QUESTION_4
Compare the tactile imagery in "बुढ़ हक्क न्कोकोन्ह :ेक्फुर् ल्स् एक्द्र ग्स र्फ्क्क म्ल्दक ब्क्व ब्स्ब क्को ध त्केउ् ल्स् त्क्म्क ग्क्व्क" (Old language sticks to the tongue like dry roti) with the visual metaphor "पैक पक्सिक्सा द्क्स य्स्द्ज प्जोक्ग्ह द्जुस त्क्र्ह गे" (Paik wants to catch letters like butterflies). What does the shift from tactile to visual suggest about Paik's evolving relationship with language?

## DIAGNOSTIC_ANSWER_4
The tactile image (dry roti sticking) conveys **resistance and discomfort** — the old oral tradition is coarse, unyielding, and physically burdensome. The visual metaphor (catching letters like butterflies) conveys **agency, delight, and fragility** — literacy is something Paik actively pursues, finds beautiful, but must handle gently. The shift signals her movement from passive victim of tradition to active architect of her future. A student who only lists the two devices without contrasting their thematic function misses the analytical demand of the question.

## DIAGNOSTIC_QUESTION_5
Critique the following student interpretation: "The metaphor 'पैक वीएनह गे' (Paik is a bird) means she is free and happy." Is this reading adequate? Why or why not?

## DIAGNOSTIC_ANSWER_5
The reading is **inadequate** because it ignores the immediate context: "पैक वीएनह गे / पप्य गे / उ व [क व ह्ख गे / ध्खे ध्खे म्खेके द्ज्र्ह गे" (Paik is a bird / fragile / sometimes she trembles / sometimes she gives a shock like lightning). The metaphor carries **ambivalence** — bird suggests flight/freedom BUT also fragility ("पप्य") and sudden, startling power ("दक्ख्क्ष क्क्ष क्से"). A defensible interpretation must hold both freedom and vulnerability together. A student who offers only the positive reading demonstrates "cherry-picking" evidence, a common Board-exam error.

## DIAGNOSTIC_QUESTION_6
Write a four-line stanza (in Hindi or English) that uses at least two distinct sensory images and one metaphor to describe a child learning to read under a streetlamp at night. Label each device in brackets.

## DIAGNOSTIC_ANSWER_6
Example:  
"पीली रोशनी में अक्षर नाचते [visual image: पीली रोशनी, नाचते]  
ठंडी हवा पन्ने फड़फड़ाती [tactile image: ठंडी हवा, फड़फड़ाती]  
उसकी उँगलियाँ जुगनू हैं [metaphor: उँगलियाँ = जुगनू — small, self-generated light in darkness]  
अंधेरा हार मानता है।"  
A poor answer would use only visual images, or use a simile ("उँगलियाँ जुगनू जैसी हैं") instead of a metaphor, or fail to label devices — indicating the student cannot yet distinguish or deploy the tools independently.

## COMMON_MISCONCEPTION
Students consistently treat **repetition of a descriptive word** (e.g., "डक्यस डक्यस") as a metaphor simply because it is repeated, arguing "the poet repeats it so it must stand for something else." This error stems from confusing **phonetic patterning** (alliteration, refrain) with **semantic transfer** (metaphor). In this poem, "डक्यस डक्यस" is a visual image reinforced by repetition; it becomes a metaphor only when the text explicitly links that darkness to social stigma ("रके दक्न घ क्क्षन्क् क्से"). The misconception is reinforced by middle-school worksheets that label all repetition as "symbolism."

## ON_FAILURE
1. **Isolate the device**: Give the student two stripped sentences — "The night was dark dark dark" (repetition + visual image) vs. "The night was a black blanket" (metaphor). Ask: "Which one *says* A *is* B?"  
2. **Map the senses**: Have the student draw a 5-column table (Sight, Sound, Smell, Touch, Taste) and place every highlighted phrase from the poem into one column. If a phrase fits nowhere, it is likely a metaphor, not an image.  
3. **Vehicle-Tenor drill**: Provide five metaphors from the poem; for each, the student must fill a two-row table: Row 1 = Tenor (what is described), Row 2 = Vehicle (what it is equated to). No analysis allowed until the table is complete.  
4. **Re-read with the rule**: "No 'जैसे/वैसे' = metaphor. Appeals to a sense = image. Both can coexist in one line." Repeat aloud before every practice question.

## BUILDS_ON
c11_hin_ar_cbse_12_006 (Theme: Primary Theme and Message) — the central theme of discrimination and education provides the thematic lens through which imagery and metaphor must be interpreted.

## LEADS_TO
c11_hin_ar_cbse_12_009 (Literary Devices: Irony and Symbolism) — irony and symbolism operate at a higher level of abstraction, often building on the concrete images and metaphors established here.

## PREREQUISITE_NODE_IDS
c11_hin_ar_cbse_12_001, c11_hin_ar_cbse_12_002, c11_hin_ar_cbse_12_003, c11_hin_ar_cbse_12_006, c11_hin_ar_cbse_12_005, c11_hin_ar_cbse_12_007

## PREREQUISITE_REASONS
c11_hin_ar_cbse_12_001: Context/background knowledge of Rajasthani folk idiom and the poet's sociological stance is essential to decode culturally specific images (e.g., "द्यूदुक्क", "ग्क्ज्स क्क्क्स क्की ब्प्न्क").  
c11_hin_ar_cbse_12_002: Narrative structure tells us the poem moves from description → dialogue → resolution; metaphors cluster at turning points (Paik's speeches).  
c11_hin_ar_cbse_12_003: Setting/atmosphere (threshold, streetlamp, night) supplies the physical space where tactile and visual images are grounded.  
c11_hin_ar_cbse_12_006: Primary theme (education as emancipation) is the thematic anchor — every image/metaphor must be explained in relation to this anchor for full marks.
c11_hin_ar_cbse_12_005: Imagery of "डयड्कस इज टज फजस" and "ककसा-हकसालस" is carried by supporting characters.  
c11_hin_ar_cbse_12_007: द्वितीयक विषयों (जैसे जातिगत वंचना, स्त्री पीड़ा) की पहचान के बाद ही उनके लिए प्रयुक्त बिंबों (अंधेरे अक्षर, ड्योढ़ी का दीया) और रूपकों का विश्लेषण सार्थक होता है।  

## FORWARD_NODE_IDS
c11_hin_ar_cbse_12_009, c11_hin_ar_cbse_12_012, c11_hin_ar_cbse_12_013, c11_hin_ar_cbse_12_014, c11_hin_ar_cbse_12_015, c12_hin_a_cbse_04_008, c12_hin_a_cbse_05_008, c12_hin_a_cbse_16_008, c12_hin_ar_cbse_12_003

## FORWARD_REASONS
c11_hin_ar_cbse_12_009: Irony and symbolism often extend or subvert the metaphors established here (e.g., Paik as "bird" becomes ironic when she is caged by illiteracy).  
c11_hin_ar_cbse_12_012: Literal/inferential comprehension questions frequently ask "Which image shows Paik's fear?" — direct application of this node.  
c11_hin_ar_cbse_12_013: Critical analysis requires evaluating *why* the poet chose a butterfly metaphor over a bird metaphor — comparative device analysis.  
c11_hin_ar_cbse_12_014: Writing tasks (analytical paragraph, character sketch) demand embedding quoted images/metaphors as evidence using PEEL structure.
c11_hin_ar_cbse_12_015: Supplies the imagery analysis (dark/light, threshold) that students will cite as evidence.  
c12_hin_a_cbse_04_008: Gustatory imagery in "Annadata" — completes five-sense toolkit.  
c12_hin_a_cbse_05_008: Connects imagery to poet's biography and context.  
c12_hin_a_cbse_16_008: Introduces "image cluster" concept — recurring sensory patterns.  
c12_hin_ar_cbse_12_003: Review the 'Imagery and Metaphor' node (c11_hin_ar_cbse_12_008) for sensory identification practice, then return to this node.  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
No prior class nodes are available for cross-subject linking in Hindi Aroh.

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_12_006 -> c11_hin_ar_cbse_12_008 -> c11_hin_ar_cbse_12_009

## THIS_FORMULA
Metaphor Analysis Template:  
**Tenor (उपमेय) + Vehicle (उपमान) + Ground (साधारण्य) + Tension (विरोध/वैषम्य) = Thematic Function**  
Imagery Classification: **Sensory Modality (दृश्य/श्रव्य/स्पर्श/घ्राण/स्वाद) + Intensity Modifier (repetition, adjective, verb) + Thematic Anchor**

## FORMULA_VARIABLES
Tenor (उपमेय) = the subject being described (e.g., Paik); Vehicle (उपमान) = the object it is equated to (e.g., bird, Yama, butterfly); Ground (साधारण्य) = the shared quality transferred (e.g., fragility, authority, beauty); Tension (विरोध) = the dissimilarity that makes the metaphor striking (e.g., bird vs. human child, Yama vs. girl); Thematic Function = how the metaphor serves the central theme (discrimination/education).  
Sensory Modality = which of the five senses the image activates; Intensity Modifier = linguistic device that amplifies the image (repetition "डक्यस डक्यस", adjective "पप्य", verb "पकड़ना"); Thematic Anchor = the poem's central idea (education as liberation).

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
linguistic

## CROSS_SUBJECT
c11_history_colonialism | The poem's critique of caste-colour-gender intersectionality parallels the historical analysis of how colonial census categories solidified caste identities — both use "classification" as a tool of oppression.  
c11_sociology_social_exclusion | The metaphor of "threshold (लूँज)" guarded by Paik-as-Yama mirrors sociological concepts of "gatekeeping" in education access for marginalised communities.  
c11_psychology_cognitive_development | The butterfly metaphor for literacy acquisition aligns with Piaget's concrete-operational stage where children manipulate symbols — Paik "catching letters" is literal cognitive schema-building.

## PREREQ_CONCEPT
The student must understand the difference between **literal description** (what is physically present) and **figurative language** (what is implied through comparison), and must be able to locate the poem's central theme of education-based emancipation.

## PREREQ_BEFORE
The student should have completed a full reading of the poem with the teacher, marked all unfamiliar Rajasthani/Hindi words (using the 'शब्द-अर्थ' list), and written a one-paragraph summary of the poem's narrative arc.

## PREREQ_STUCK
If stuck, review the **Theme: Primary Theme and Message (c11_hin_ar_cbse_12_006)** node — specifically the section on "education as the only weapon against triple oppression" — because every image and metaphor in this poem serves that thesis.

## WORKED_EXAMPLE_1
PROBLEM: Analyse the metaphor "पैक लूँज ध यम्ढ गे" (Paik is the threshold's Yama) using the Tenor-Vehicle-Ground-Tension framework, and explain its thematic function in the poem's argument about literacy.

STEPS:
- Step 1: Identify the tenor — the subject being described. Here, "पैक" (Paik, the dark-skinned girl child) is the tenor.
- Step 2: Identify the vehicle — the object tenor is equated to. "यम्ढ" (Yama, god of death/threshold guardian) is the vehicle. Note: no "जैसे/वैसे" confirms metaphor.
- Step 3: Determine the ground (साधारण्य) — the shared quality transferred. Yama guards the threshold between life and afterlife; Paik guards the threshold between illiteracy and literacy for her community. The transferred quality is **gatekeeping authority at a decisive boundary**.
- Step 4: Identify the tension (विरोध) — the dissimilarity that creates poetic power. Yama is male, divine, fearsome, final; Paik is female, human child, vulnerable, tentative. This tension highlights the **absurdity and injustice** of placing the burden of social transformation on a marginalised girl.
- Step 5: State the thematic function. The metaphor argues that **literacy is a life-death threshold** for the oppressed, and that the child — not the state, not the priest — holds the key. It elevates Paik's struggle to mythic proportions while underscoring societal abdication.

REASONING: The framework forces separation of the metaphor's mechanics (tenor/vehicle) from its meaning (ground/tension), preventing the common error of collapsing them into a vague "Paik is powerful." Thematic function is the Board-exam requirement: "What does this metaphor *do* in the poem?"

ANSWER: Tenor = Paik; Vehicle = Yama; Ground = gatekeeping authority at a decisive boundary; Tension = divine male finality vs. vulnerable female child; Thematic Function = elevates literacy to a life-death threshold and indicts society for making a child its guardian.

## WORKED_EXAMPLE_2
PROBLEM: The poem uses the visual image "डक्यस डक्यस" (dark dark) and the tactile image "बुढ़ हक्क न्कोकोन्ह :ेक्फुर् ल्स् एक्द्र ग्स" (old language sticks to the tongue like dry roti). Classify each by sensory modality, identify the intensity modifier in each, and explain how the pairing supports the poem's contrast between **tradition** and **aspiration**.

STEPS:
- Step 1: Classify sensory modality. "डक्यस डक्यस" → visual (colour perception). "बुढ़ हक्क..." → tactile (texture of dry roti on tongue) + gustatory (taste of dryness).
- Step 2: Identify intensity modifiers. For "डक्यस डक्यस": **repetition** (epizeuxis) — the word is repeated without conjunction, forcing the eye to linger on the colour. For "बुढ़ हक्क...": **simile marker "ल्स्" (like)** — wait, this is a simile, not a pure image; the *image* is the tactile sensation of dry roti sticking, intensified by the **adjective "एक्द्र" (dry/hard)**.
- Step 3: Map each to tradition vs. aspiration. "डक्यस डक्यस" is the **given** — the body Paik is born into, the visual marker of her oppression (tradition/caste-colour). "बुढ़ हक्क..." is the **inherited burden** — the oral tradition that feels coarse, unyielding, physically uncomfortable (tradition/language).
- Step 4: Contrast with aspirational images later in the poem (e.g., "पकड़ना" letters like butterflies — visual + tactile, but **voluntary**, **delicate**, **beautiful**).
- Step 5: Synthesise. The poem moves from **imposed, coarse, repetitive visual/tactile images of oppression** to **chosen, fragile, kinetic images of literacy** — the sensory shift mirrors the thematic shift from victimhood to agency.

REASONING: Board questions often ask "How does the poet use imagery to show change?" This requires tracking sensory modality AND intensity modifiers across the poem's trajectory, not just listing images.

ANSWER: "डक्यस डक्यस" = visual image, intensified by repetition (epizeuxis), marking imposed identity. "बुढ़ हक्क..." = tactile-gustatory image, intensified by adjective "एक्द्र" (dry), marking inherited burden. Together they establish the sensory baseline of oppression against which aspirational images (butterfly, lamp, letters) shine.

## WORKED_EXAMPLE_3
PROBLEM: The poem contains an **extended metaphor** across stanzas 3-5 where Paik's learning process is equated to "catching butterflies" (पकड़ना), "lighting a lamp" (दीप जलाना), and "crossing a threshold" (देहरी पार करना). Trace the extended metaphor, identify the consistent tenor, the shifting vehicles, the evolving ground, and explain how the progression structures the poem's argument about **stages of empowerment**.

STEPS:
- Step 1: Confirm extended metaphor — a single tenor explored through multiple vehicles across contiguous stanzas. Tenor = **Paik's learning process / acquisition of literacy**.
- Step 2: List vehicles in sequence. Stanza 3: "पकड़ना" (catching) + "तितली" (butterfly) — vehicle = butterfly hunting. Stanza 4: "दीप जलाना" (lighting a lamp) — vehicle = lamp-lighting ritual. Stanza 5: "देहरी पार करना" (crossing threshold) — vehicle = threshold crossing.
- Step 3: Extract ground for each. Butterfly → **delicacy, beauty, voluntary pursuit, risk of crushing**. Lamp → **self-generated illumination, ritual significance, communal benefit (light spreads)**. Threshold → **irreversible transition, boundary between two worlds, agency of stepping across**.
- Step 4: Analyse evolution of ground. Stage 1 (butterfly): **individual, aesthetic, fragile** — learning as personal wonder. Stage 2 (lamp): **communal, ritual, generative** — learning as social responsibility. Stage 3 (threshold): **structural, permanent, transformative** — learning as systemic change.
- Step 5: Identify tension at each stage. Butterfly: child's small hands vs. wings' fragility. Lamp: one flame vs. surrounding darkness. Threshold: child's stature vs. height of the doorframe.
- Step 6: State structural argument. The extended metaphor **scaffolds empowerment** — from micro (fingers) to meso (home/community) to macro (social structure) — proving literacy is not a single event but a widening circle of agency.

REASONING: Extended metaphor questions (common in 5-mark Board items) require tracking *development* across the text, not just identifying isolated metaphors. The Tenor-Vehicle-Ground-Tension template applied sequentially reveals the poem's architectural logic.

ANSWER: Consistent tenor = Paik's literacy acquisition. Vehicles: butterfly (stanza 3) → lamp (stanza 4) → threshold (stanza 5). Grounds evolve: delicate voluntary pursuit → communal illumination → irreversible structural transition. The progression structures the poem's argument: empowerment begins in wonder, expands to service, culminates in systemic boundary-crossing.

## COMPETENCY_QUESTION_1
QUESTION: A Class 11 student writes in an exam: "The poet uses the metaphor 'पैक वीएनह गे' to show Paik is free." Using the Vehicle-Tenor-Ground-Tension framework, explain why this answer would receive only 1 out of 3 marks, and rewrite the answer to secure full marks.

COMPETENCY: Critical evaluation of peer response using metalanguage; application of metaphor analysis framework to improve exam writing.

STEPS:
- Step 1: Identify the missing components in the student's answer — it names tenor (Paik) and vehicle (bird) but omits ground (which quality?), tension (what contradiction?), and thematic function (what does it *do* in the poem?).
- Step 2: Retrieve the full context: "पैक वीएनह गे / पप्य गे / उ व [क व ह्ख गे / ध्खे ध्खे म्खेके द्ज्र्ह गे" — the metaphor is immediately qualified by "fragile," "trembles," "gives shock like lightning."
- Step 3: Apply framework: Tenor = Paik; Vehicle = bird; Ground = flight/freedom **AND** fragility/startling power; Tension = freedom vs. vulnerability; Thematic Function = embodies the dual condition of the empowered girl child — capable of flight but constantly threatened.
- Step 4: Rewrite the answer in PEEL structure: Point (metaphor encapsulates dual condition), Evidence (quote the four lines), Explanation (ground + tension), Link (connects to theme of education as both liberation and danger).

ANSWER: The original answer scores 1/3 because it reduces a complex metaphor to a single positive trait, ignoring the poem's immediate qualification ("पप्य", "कम्पती", "बिजली-सा झटका"). Full-mark rewrite: "The metaphor 'पैक वीएनह गे' (tenor: Paik, vehicle: bird) transfers the ground of **flight/freedom** but the subsequent lines 'पप्य गे / कम्पती / बिजली-सा झटका' introduce the tension of **fragility and volatile power**. This dual ground captures the poem's central paradox: literacy gives the marginalised girl wings, yet her flight remains fragile and her voice startling in a structure designed to silence her. The metaphor thus does not merely 'show she is free'; it **enacts the precariousness of that freedom**."

DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: The poem opens with a **refrain-like repetition** of a visual image ("डक्यस डक्यस") and closes with a **metaphor of threshold-crossing** ("द्यूदुक्क इक म्झ न त्कुस न्व्ख्ख गे / द्यूदुक्क इक ध्खे ल्ख्स ल्ख् न्ख्स गे / डक्यस इक इक क्त्ज फ्ज्स"). Construct an argument, using evidence from both the opening and closing, that the poem's structure **enacts** the journey from **objectification** to **subjectivity** through its shifting use of literary devices.

COMPETENCY: Structural analysis linking device evolution to thematic arc; synthesis of imagery and metaphor across whole text.

STEPS:
- Step 1: Analyse the opening device. "डक्यस डक्यस" (repeated 4× in first stanza) — visual image, third-person description, **passive objectification**. The girl is reduced to a colour; no agency, no voice. The repetition mimics societal stare.
- Step 2: Track the shift to metaphor with agency. Middle stanzas: Paik speaks ("मैं पढ़ूँगी", "पकड़ूँगी") — metaphors of **catching, lighting, crossing** where she is grammatical subject and semantic agent.
- Step 3: Analyse the closing metaphor. "द्यूदुक्क... डक्यस एक एक क्त्ज फ्ज्स" — the deity (द्यूदुक्क) now addresses Paik as "डक्यस" but the phrase "एक एक क्त्ज फ्ज्स" (each one a spark) **reclaims the visual marker** (darkness) and transforms it into **metaphorical energy** (sparks). The objectified image becomes the vehicle for her power.
- Step 4: Synthesise structural enactment. Device progression: **repeated visual image (object) → active metaphors (agent) → reclaimed visual image as metaphor (subject)**. The form mirrors the content: the literary devices themselves undergo the liberation the poem narrates.
- Step 5: Formulate thesis. The poem does not just *describe* the journey from objectification to subjectivity; its **device architecture performs it** — the refrain that once pinned her like a specimen becomes, in the final metaphor, the fuel of her fire.

ANSWER: The opening refrain "डक्यस डक्यस" functions as a visual image that objectifies Paik — she is seen, not heard; a colour, not a person. The middle section replaces static imagery with dynamic metaphors where Paik is the active tenor (catching butterflies, lighting lamps, crossing thresholds). The closing metaphor "डक्यस एक एक क्त्ज फ्ज्स" reclaims the very visual marker of her oppression ("डक्यस") and transposes it into a vehicle for generative power ("क्त्ज फ्ज्स" — sparks). Thus, the poem's **device trajectory — repetitive image → agentive metaphors → reclaimed image-as-metaphor — formally enacts the protagonist's movement from object to subject**. The structure *is* the argument.

DIFFICULTY: hard