## DEFINITION
Imagery (प्रतिबिंब/चित्रण) is the use of vivid, sensory language that appeals to the five senses (sight, sound, smell, touch, taste) to create mental pictures and evoke physical sensations in the reader. Metaphor (रूपक/रूपक अलंकार) is a figure of speech that directly equates two unlike things without using "like" or "as" (जैसे/वैसे), asserting that one thing *is* another to transfer qualities and deepen meaning.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student can independently identify specific imagery and metaphor instances in the text, explain which sense each image appeals to, articulate the two terms being equated in each metaphor, and analyze how both devices work together to reveal the story's central tension between bureaucratic indifference and organic life.

## SCOPE_BOUNDARY
This node covers identification, classification, and analytical explanation of imagery (visual, auditory, tactile, olfactory, gustatory) and metaphor (simple, extended, implied) specifically within "टकेस का इमली" (Chapter 7). It does NOT cover irony, symbolism, personification, or other figures of speech (those are in node c11_hin_ar_cbse_07_009), nor does it cover general comprehension or theme analysis.

## WALKTHROUGH
Imagine you're standing in that government office compound looking at the tamarind tree — what do you actually *see, hear, smell, feel*? That's where imagery lives: not in abstract ideas but in the sticky tamarind pulp on your fingers, the rustle of leaves, the officer's crisp uniform against rough bark. Start by reading the story aloud and physically marking every sensory detail with a colored pencil (green for visual, blue for auditory, red for tactile). Then hunt for metaphors: whenever the text says "X *is* Y" without "like," circle it — the tree *is* a witness, the nest *is* a fragile republic, bureaucracy *is* a machine that grinds life. The key insight: in this story, imagery makes the tree *alive* while metaphors expose how bureaucracy *kills* aliveness by reducing it to files and protocols.

## DIAGNOSTIC_QUESTION_1
Define imagery and metaphor in your own words, then give one example of each from "टकेस का इमली" without looking at the text.

## DIAGNOSTIC_ANSWER_1
**Correct answer:** Imagery = sensory language creating mental pictures (e.g., "इमली के पत्तों की सरसराहट" — auditory/visual). Metaphor = direct equation without "like/as" (e.g., "यह पेड़ नहीं, एक गवाह है" — tree = witness). **Wrong answer reveals:** If student gives "पेड़ *जैसे* एक बूढ़ा पहरेदार" — that's a simile (उपमा), not metaphor. If they say "पेड़ बहुत बड़ा था" — that's factual description, not imagery. Confusing simile with metaphor or description with imagery shows they haven't grasped the *structural difference* (direct equation vs. comparison vs. sensory evocation).

## DIAGNOSTIC_QUESTION_2
In the passage where the officer reads the governor's old letter ("इमली का यह पेड़... लगाया गया था"), the text describes the letter as "पीला पड़ा कागज़ जिस पर स्याही फैल गई थी." Is this imagery or metaphor? Explain which sense(s) it appeals to and why it matters at this moment in the story.

## DIAGNOSTIC_ANSWER_2
**Correct answer:** This is **visual and tactile imagery** — "पीला पड़ा" (visual: aged yellow), "स्याही फैल गई" (visual: blurred ink, tactile implication: fragile paper). It matters because the *physical decay of the document* mirrors the *moral decay of the system* — the protocol that could save the tree is itself rotting, just like the bureaucracy. **Wrong answer reveals:** Calling it "metaphor for lost history" misses the literal sensory grounding. Calling it "just description" misses how Renu uses sensory decay to *perform* institutional decay. The student who can't see the sensory→thematic bridge hasn't learned to read imagery *analytically*.

## DIAGNOSTIC_QUESTION_3
Find a metaphor in the dialogue between the Section Officer (अनुभाग अधिकारी) and the Deputy Secretary (उपसचिव) where bureaucracy is equated to something non-human. Quote the Hindi phrase, identify the two terms (A = B), and explain what quality of bureaucracy the metaphor transfers.

## DIAGNOSTIC_ANSWER_3
**Correct answer:** "यह फ़ाइल नहीं, एक मशीन है जो ज़िन्दगी पीसती चलती है" (This is not a file, it's a machine that keeps grinding life). A = फाइल/ब्यूरोक्रेसी, B = मशीन. Quality transferred: **mechanical, unfeeling, repetitive destruction** — bureaucracy doesn't *decide*, it *processes* life into pulp like a grinder. **Wrong answer reveals:** If student picks "फ़ाइल एक पहाड़ है" (file = mountain) — that's not in the text. If they say "metaphor shows bureaucracy is strong" — they missed the *violence* of "पीसती" (grinds). The error is reading metaphor as decoration rather than *argument*: Renu isn't describing bureaucracy; he's *accusing* it through metaphor.

## DIAGNOSTIC_QUESTION_4
Compare the imagery used for the **bird's nest** ("टहनियों का जाल," "अंडों की नाज़ुक सफेदी") with the imagery used for the **officer's file** ("मोटी फ़ाइल," "लाल फीता," "टाइपराइटर की खटखट"). How do these two imagery clusters create the story's central conflict without a single abstract word like "conflict" or "nature vs. system"?

## DIAGNOSTIC_ANSWER_4
**Correct answer:** Nest imagery = **organic, fragile, interwoven, silent** (जाल = woven, नाज़ुक = delicate, सफेदी = purity). File imagery = **industrial, rigid, bound, noisy** (मोटी = bulk, लाल फीता = binding/control, खटखट = mechanical sound). The conflict *is* the sensory clash: soft vs. hard, woven vs. bound, silence vs. clatter. Renu never says "nature vs. bureaucracy" — he makes you *feel* the nest's vulnerability against the file's weight through pure imagery. **Wrong answer reveals:** Listing images without contrasting their *sensory qualities* (e.g., "both are described in detail") shows the student sees imagery as inventory, not *architecture of meaning*. They're not analyzing how imagery *builds* theme.

## DIAGNOSTIC_QUESTION_5
The story ends with the tree saved because "पूर्व राज्यपाल ने लगाया था" (former governor planted it). Evaluate: Is the final image of the tree standing "अडिग" (unshaken) while "फ़ाइलें धूल खा रही हैं" (files eating dust) a **triumph of imagery over metaphor** or **metaphor over imagery**? Defend with evidence.

## DIAGNOSTIC_ANSWER_5
**Correct answer:** **Metaphor triumphs, but only because imagery set the stage.** The final *image* (tree standing, files dusty) is visual proof — but the *meaning* comes from the metaphor established earlier: "पेड़ = गवाह" (tree = witness) and "फ़ाइल = मशीन" (file = machine). The tree *as witness* outlasts the machine *as grinder* — that's a metaphorical victory. Imagery shows *what happened*; metaphor tells *what it means*. **Wrong answer reveals:** Saying "imagery wins because we see the tree" confuses *evidence* with *argument*. Saying "metaphor wins because it's deeper" ignores that without the sensory final image, the metaphor would be hollow rhetoric. The student who can't see the *partnership* of device and evidence hasn't mastered literary analysis.

## DIAGNOSTIC_QUESTION_6
Write a 4-line Hindi poem/stanza about a tree in a government office that uses **at least two distinct types of imagery** and **one metaphor** (not simile). Label each device in brackets.

## DIAGNOSTIC_ANSWER_6
**Expected answer criteria:**
- 4 lines in Hindi
- ≥2 imagery types labeled (e.g., [दृश्य], [श्रव्य], [स्पर्श], [घ्राण], [स्वाद])
- 1 metaphor labeled [रूपक] — direct equation, no "जैसे/वैसे"
- Metaphor must transfer a quality relevant to the tree/bureaucracy tension

**Example good answer:**
"टाइपराइटर की खटखट में दब गई चिड़िया की चहक [श्रव्य]
लाल फीते से बंधी फ़ाइलें खाती हैं धूल [दृश्य + स्पर्श]
यह इमली नहीं, **वक़्त का बहीखाता** है [रूपक: इमली = बहीखाता]
जिसके पन्ने हवा नहीं, **हुक्म** पलटते हैं [रूपक: हवा = हुक्म]"

**Poor answer reveals:** Using "जैसे" (simile), missing imagery labels, metaphor that doesn't transfer meaning (e.g., "पेड़ एक राजा है" — generic, not tied to bureaucracy), or only visual imagery. Shows student can't *generate* devices with analytical intent.

## COMMON_MISCONCEPTION
Students treat imagery and metaphor as **identification exercises** ("find the metaphor in para 3") rather than **analytical tools** ("how does this metaphor *argue*?"). Specifically in "टकेस का इमली," they spot "पेड़ = गवाह" but miss that the *entire bureaucratic machinery* is metaphorically a **digestive system** (फ़ाइलें *निगलती* हैं, *पचाती* हैं, *निकालती* हैं — swallow, digest, excrete). They also confuse **sensory detail** with **imagery**: "पेड़ 20 फीट ऊँचा था" is measurement, not imagery; "पेड़ की छाया में धूप सोती थी" (sunlight *slept* in the shade) is tactile+visual imagery *plus* personification. The root error: reading for *what happens* not *how language makes it happen*.

## ON_FAILURE
1. **Sensory Hunt**: Take the student to a real tree (or plant). Have them close eyes → list 3 sounds, 2 smells, 1 texture. Then open eyes → 3 visual details. Write each as a Hindi phrase. This grounds "imagery" in *body*, not textbook.
2. **Metaphor Surgery**: Give them 5 similes from the story (or made-up ones: "ब्यूरोक्रेसी *जैसे* एक दीवार"). Have them **cut "जैसे" and rewrite as direct equation** ("ब्यूरोक्रेसी *है* एक दीवार"). Ask: "What changed? What quality transferred *more forcefully*?" 
3. **Device→Effect Map**: On a two-column sheet: Column A = quoted device, Column B = "What does this make me *feel/think* about bureaucracy vs. life?" Do 3 imagery, 2 metaphors. No column B entry = not analysis.
4. **Peer Teach**: Student explains *one* metaphor to a classmate *without using the word "metaphor"* — only "The writer says X *is* Y so that we understand Z."

## BUILDS_ON
c11_hin_ar_cbse_07_002 (Text: Plot and Narrative Structure) — students must know the story's events, characters, and bureaucratic setting before analyzing how language shapes meaning.

## LEADS_TO
c11_hin_ar_cbse_07_009 (Literary Devices: Irony and Symbolism) — imagery/metaphor analysis prepares students to see how irony (gap between protocol and humanity) and symbolism (tree/nest as enduring life) extend the same textual strategies.

## PREREQUISITE_NODE_IDS
c11_hin_ar_cbse_07_002, c11_hin_ar_cbse_07_001, c11_hin_ar_cbse_07_003, c11_hin_ar_cbse_07_007

## PREREQUISITE_REASONS
c11_hin_ar_cbse_07_002: Students need the plot sequence (tree planted → nest discovered → bureaucratic debate → tree saved by protocol) and character roles (officers, bird, governor's letter) to locate where imagery/metaphor appear and what narrative work they do.
c11_hin_ar_cbse_07_001: "Before You Read: की समझ आवश्यक है, क्योंकि यह नोड (Imagery (प्रतिबिंब/चित्रण) is the use of vivid, sensory language that appeals to the five...) इसी आधार पर आगे बढ़ता है।  
c11_hin_ar_cbse_07_003: Imagery/metaphor (tree as mother, file as weapon) are setting-atmosphere devices.  
c11_hin_ar_cbse_07_007: Imagery and metaphor analysis requires knowing *what* themes the images serve (e.g., the tree-as-file imagery serves the "language as erasure" theme).  

## FORWARD_NODE_IDS
c11_hin_ar_cbse_07_009, c11_hin_ar_cbse_07_013, c11_hin_ar_cbse_07_011, c11_hin_ar_cbse_07_014, c12_hin_a_cbse_04_008, c12_hin_a_cbse_05_008, c12_hin_a_cbse_07_008, c12_hin_a_cbse_16_008, c12_hin_ar_cbse_07_004, c12_hin_ar_cbse_07_008

## FORWARD_REASONS
c11_hin_ar_cbse_07_009: Irony and symbolism in this story *build on* the imagery/metaphor foundation (e.g., the "tree = witness" metaphor enables the irony of officials saving it for wrong reasons; the nest imagery becomes a symbol of fragile democracy).
c11_hin_ar_cbse_07_013: Critical thinking/interpretation requires the device-analysis skills honed here — students must cite specific imagery/metaphors as evidence for interpretive claims.
c11_hin_ar_cbse_07_011: Covers metaphor/imagery that often intertwines with syntactic choices (e.g., the tree as a metaphor entangled in compound sentences).  
c11_hin_ar_cbse_07_014: Literary devices (irony, symbolism) enable deeper textual analysis  
c12_hin_a_cbse_04_008: Metaphor chains in "Badal Ko Ghirte Dekha" — model for stanza 4's "vkèkk" repetition.  
c12_hin_a_cbse_05_008: Trains students in writing device-analysis paragraphs.  
c12_hin_a_cbse_07_008: Class 11 node where vehicle/tenor terminology and imagery taxonomy were introduced.  
c12_hin_a_cbse_16_008: Introduces metaphor evolution tracking (static vs. dynamic).  
c12_hin_ar_cbse_07_004: Imagery/metaphor analysis needed to decode symbolic actions (e.g., "isV" = protective gaze, "txr" = single-minded focus).  
c12_hin_ar_cbse_07_008: Provides foundational definitions of imagery types and metaphor mechanics (vehicle/tenor) that Class 12 deepens into multi-poem thematic tracing.  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
none

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_07_002 -> c11_hin_ar_cbse_07_008 -> c11_hin_ar_cbse_07_009, c11_hin_ar_cbse_07_013

## THIS_FORMULA
**Imagery Analysis Formula:** sensory detail → sense appealed → narrative moment → thematic effect
**Metaphor Analysis Formula:** Term A (tenor) = Term B (vehicle) → shared quality (ground) → thematic argument

## FORMULA_VARIABLES
- Sensory detail: exact words from text evoking sight/sound/smell/touch/taste
- Sense appealed: दृश्य (visual), श्रव्य (auditory), स्पर्श (tactile), घ्राण (olfactory), स्वाद (gustatory)
- Narrative moment: specific scene/dialogue where image appears
- Thematic effect: what the image *does* to the story's meaning (e.g., "makes bureaucracy feel suffocating")
- Term A (tenor): the subject being described (e.g., bureaucracy, tree, nest)
- Term B (vehicle): the thing it's equated to (e.g., machine, witness, republic)
- Shared quality (ground): the attribute transferred (e.g., "mechanical," "silent endurance," "fragile sovereignty")
- Thematic argument: the claim the metaphor *makes* about the story's central tension

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
analytical

## CROSS_SUBJECT
c11_polity_democracy | The "nest as fragile republic" metaphor in "टकेस का इमली" directly parallels Constitutional concepts: fundamental rights (eggs/life) protected by institutional protocols (tree/governor's order) against state machinery (bureaucracy) — a living civics lesson in literary form.
c11_geography_ecology | The tactile/olfactory imagery of tamarind tree (imli) — its deep roots, seasonal flowering, bird habitats — grounds the story in specific Indian tropical dry deciduous ecology, making the "tree vs. office" conflict a microcosm of urban green-space loss.

## PREREQ_CONCEPT
Student must understand the **bureaucratic setting and plot arc** of "टकेस का इमली" — who the officers are, what the file contains, why the governor's letter matters — before analyzing how language devices shape the story's critique.

## PREREQ_BEFORE
Read the full story (Chapter 7) and be able to summarize: (1) the tree's history, (2) the nest discovery, (3) the three-level officer debate, (4) the governor's letter intervention, (5) the final outcome — in 5 sentences.

## PREREQ_STUCK
If stuck, re-read the **officer dialogue sections** (अनुभाग अधिकारी, उपसचिव, संयुक्त सचिव) and the **governor's letter scene** — these contain the densest imagery/metaphor clusters. Map each speaker's language: who uses sensory words? Who uses mechanistic metaphors?

## WORKED_EXAMPLE_1
PROBLEM: Analyze the imagery in the opening description: "इमली का वह पेड़ दफ़्तर के अहाते में खड़ा था — मोटा, पुराना, फैली हुई शाखाओं वाला। उसकी छाँव में धूप सोती थी।" Identify all sensory images, their senses, and explain how they characterize the tree *before* any human speaks.

STEPS:
- Step 1: Isolate each sensory phrase: "मोटा" (visual/tactile thickness), "पुराना" (visual age-markers: gnarled bark, hollows), "फैली हुई शाखाएँ" (visual spread), "छाँव में धूप सोती थी" (visual light/shadow + personification of sunlight sleeping).
- Step 2: Classify senses: दृश्य (मोटा, पुराना, फैली शाखाएँ, छाँव/धूप), स्पर्श (मोटा implies rough bark, छाँव implies coolness), *implied* घ्राण (old tamarind = earthy, fruity scent).
- Step 3: Map to narrative moment: This is the **establishing shot** — before bureaucracy enters, the tree *owns* the space. "धूप सोती थी" makes the tree a *guardian of rest*, not an object.
- Step 4: Analyze thematic effect: The tree is **alive, sovereign, ancient** — it *hosts* sunlight. This sets up the violation when officers later treat it as "फ़ाइल का विषय" (file subject). Imagery establishes the tree's *being* so bureaucracy's *reducing* it hurts.
- Step 5: Verify against story arc: Later, the Section Officer says "पेड़ काटना पड़ेगा" — the imagery clash (sleeping sunlight vs. cutting order) *is* the conflict. No abstract "nature vs. system" needed.

REASONING: This walkthrough models the **Imagery Analysis Formula** — each sensory detail is traced from text → sense → moment → effect. Students learn imagery isn't decoration; it's the story's *first argument*.

ANSWER: The opening uses **visual** (मोटा, पुराना, फैली शाखाएँ, छाँव/धूप), **tactile** (implied rough bark, cool shade), and **implied olfactory** (old tamarind scent) imagery to characterize the tree as an ancient, living sovereign that *hosts* light and rest. The personification "धूप सोती थी" (sunlight slept) transfers human vulnerability to nature — making the later bureaucratic threat feel like violence against a sleeper. This imagery cluster establishes the tree's *being* so its reduction to a "file subject" registers as violation.

## WORKED_EXAMPLE_2
PROBLEM: The Deputy Secretary says: "यह फ़ाइल नहीं, एक मशीन है जो ज़िन्दगी पीसती चलती है." Apply the Metaphor Analysis Formula to show how this single metaphor condenses the story's entire critique of bureaucracy.

STEPS:
- Step 1: Identify Term A (tenor) = "फ़ाइल / ब्यूरोक्रेसी" (the file/bureaucracy — what's being described).
- Step 2: Identify Term B (vehicle) = "मशीन" (machine — what it's equated to).
- Step 3: Extract shared quality (ground) from the verb "पीसती चलती है" (keeps grinding) → **mechanical, repetitive, destructive processing without consciousness**.
- Step 4: Locate narrative moment: Spoken when the file reaches Deputy Secretary — the *mid-point* where bureaucracy could stop but *chooses* to process. The metaphor *diagnoses* the system's nature.
- Step 5: Trace thematic argument: If bureaucracy = machine that grinds life, then **saving the tree requires breaking the machine** — which the Governor's letter (human authority) does. The metaphor predicts the ending: only *human* intervention (ex-governor's order) stops the *machine*.
- Step 6: Connect to imagery: The "लाल फीता" (red tape) imagery earlier *visualizes* the machine's binding mechanism; "टाइपराइटर की खटखट" *audibilizes* its grinding. Metaphor *names* what imagery *shows*.

REASONING: This models the **Metaphor Analysis Formula** — moving from identification (A=B) to ground (shared quality) to narrative function (diagnosis) to thematic argument (prediction). Students see metaphor as *analytical tool*, not label.

ANSWER: Term A = ब्यूरोक्रेसी/फ़ाइल, Term B = मशीन, Ground = "पीसती चलती है" → mechanical, unfeeling, repetitive destruction of life. The metaphor functions as **systemic diagnosis**: bureaucracy doesn't *decide*; it *processes* life into pulp. This explains why the file moves upward automatically (Section Officer → Deputy Secretary → Joint Secretary) — machines don't pause. The Governor's letter (human authority, historical continuity) is the *only* force that can halt the machine. The metaphor condenses the story's thesis: **life survives only when human memory interrupts mechanical protocol**.

## WORKED_EXAMPLE_3
PROBLEM: In the climax, the Joint Secretary reads the Governor's letter and the tree is saved. The text describes: "पेड़ वहीं खड़ा रहा — अडिग। फ़ाइलें धूल खाती रहीं।" Analyze how **imagery and metaphor work together** in this final image to resolve the story's central tension. Use both formulas.

STEPS:
- Step 1 (Imagery): Identify sensory details — "अडिग" (visual/tactile: unmoving, rooted), "धूल खाती रहीं" (visual: dust accumulation, tactile: gritty neglect, olfactory: stale air). Senses: दृश्य, स्पर्श, घ्राण.
- Step 2 (Imagery → moment): This is the **resolution image** — tree *still standing*, files *passively decaying*. The tree's stillness is *active endurance*; files' dust-eating is *passive rotting*.
- Step 3 (Metaphor): Recall earlier metaphor "पेड़ = गवाह" (tree = witness) and "फ़ाइल = मशीन" (file = machine). The final image *enacts* both: the witness *outlasts* the machine.
- Step 4 (Metaphor → argument): Ground of "गवाह" = silent, enduring testimony. Ground of "मशीन" = mechanical function requiring fuel (paper, orders). When fuel stops (Governor's order ends the chain), machine *stops* → becomes dust. Witness *continues*.
- Step 5 (Synthesis): Imagery provides **evidence** (tree stands, files dust); metaphor provides **framework** (witness vs. machine). Together they argue: **organic memory outlives mechanical protocol**. The tree doesn't *win* — it *endures*. The files don't *lose* — they *expire*.
- Step 6 (Board exam connection): A 5-mark answer would: (a) quote both images, (b) name senses, (c) name metaphors with terms/ground, (d) explain synthesis, (e) link to theme "bureaucracy vs. life."

REASONING: This advanced example combines both formulas and demands **synthesis** — the highest analytical skill. It mirrors board exam "analyze the ending" questions where students must show how devices *collaborate* to deliver thematic closure.

ANSWER: The final couplet resolves the tension through **imagery-metaphor partnership**. Imagery: "अडिग" (visual/tactile — rooted, unmoving endurance) + "धूल खाती रहीं" (visual/tactile/olfactory — passive decay, stale neglect). Metaphors enacted: "पेड़ = गवाह" (ground: silent testimony that persists) vs. "फ़ाइल = मशीन" (ground: mechanical function that ceases without input). The tree *as witness* simply *is* — its imagery is presence. The files *as machine* *stop* when the Governor's order (fuel) ends — their imagery is absence (dust). The story doesn't say "bureaucracy failed"; it *shows* the machine grinding to a halt while the witness remains. This is Renu's argument: **life doesn't defeat bureaucracy — it outlives it.**

## COMPETENCY_QUESTION_1
QUESTION: A Class 11 student writes: "रेणु ने इमली के पेड़ का वर्णन करने के लिए बहुत सुंदर इमेजरी का प्रयोग किया है जैसे 'मोटा, पुराना, फैली हुई शाखाएँ' — इससे पेड़ की सुंदरता पता चलती है।" Evaluate this response. What does it get right? What does it miss? Rewrite it as a **board-level analytical answer** (3-4 sentences) using the Imagery Analysis Formula.

COMPETENCY: Critical evaluation of peer response + analytical rewriting using disciplinary framework

STEPS:
- Step 1: Identify what the student response gets right — it quotes imagery and names the device.
- Step 2: Identify what it misses — treats imagery as *description/beauty* not *argument*; ignores senses, narrative moment, thematic effect; uses vague "सुंदरता" (beauty) instead of specific qualities (sovereignty, antiquity, vulnerability).
- Step 3: Apply Imagery Analysis Formula to rewrite: quote → sense → moment → effect.
- Step 4: Ensure board-exam structure: Point → Evidence → Analysis → Link to theme.

ANSWER: **Evaluation:** The response correctly identifies imagery and quotes text, but reduces it to "beauty description" — a **Class 9-level appreciation**, not Class 11 analysis. It misses: (1) sense classification, (2) narrative positioning (establishing shot), (3) thematic work (tree as sovereign being vs. bureaucratic object). **Board-level rewrite:** "रेणु प्रारंभ में ही इमली के पेड़ को 'मोटा, पुराना, फैली शाखाओं वाला' (दृश्य/स्पर्श इमेजरी) और 'छाँव में धूप सोती थी' (दृश्य + मानवीकरण) के माध्यम से एक **प्रभुसत्तासंपन्न, प्राचीन सजीव उपस्थिति** के रूप में स्थापित करते हैं — न कि सौंदर्य की वस्तु। यह इमेजरी पेड़ को 'फ़ाइल का विषय' बनाने वाली नौकरशाही हिंसा के विरुद्ध उसका **अस्तित्वगत दावा** दर्ज करती है: पेड़ काटा नहीं जा सकता क्योंकि वह *है*, मात्र *दिखता* नहीं।" (4 sentences, formula-driven, thematic precision)

DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: The story contains an **extended metaphor** where the bureaucratic file system is implicitly compared to a **digestive tract** (mouth → stomach → intestines → excretion). Trace this metaphor across **three specific moments** in the text (quote Hindi phrases), identify the digestive organ at each stage, and explain how the metaphor's *progression* structures the narrative arc from threat to resolution.

COMPETENCY: Cross-textual metaphor tracking + structural analysis + evidence-based argument

STEPS:
- Step 1: Identify Moment 1 (ingestion/mouth) — file enters system: "फ़ाइल अनुभाग अधिकारी के पास पहुँची" + "टाइपराइटर की खटखट" (teeth chewing paper).
- Step 2: Identify Moment 2 (stomach/digestion) — processing: "उपसचिव ने फ़ाइल देखी... 'यह मशीन है जो ज़िन्दगी पीसती है'" (acidic breakdown of life into pulp).
- Step 3: Identify Moment 3 (excretion/output) — resolution: "फ़ाइलें धूल खाती रहीं" (waste expelled, system empty).
- Step 4: Explain narrative function: The digestive metaphor *is* the plot — file moves through bureaucratic organs until the Governor's letter (foreign object/antidote) causes **rejection/expulsion** of the destructive process.
- Step 5: Synthesize: The metaphor progression (ingest → digest → excrete) maps exactly to **plot arc** (threat → processing → failed destruction), proving bureaucracy is a *biological system consuming life* — stopped only by *historical memory* (Governor's letter).

ANSWER: **Moment 1 (Mouth/Ingestion):** "फ़ाइल अनुभाग अधिकारी के पास पहुँची... टाइपराइटर की खटखट" — file *enters* the system, typewriter *chews* raw data into processed text. **Moment 2 (Stomach/Digestion):** "यह मशीन है जो ज़िन्दगी पीसती चलती है" — Deputy Secretary *names* the digestion: life ground into bureaucratic pulp. **Moment 3 (Excretion):** "फ़ाइलें धूल खाती रहीं" — processed waste (files) expelled into dust, system emptied. **Narrative structuring:** The digestive arc *is* the plot — bureaucracy *consumes* the tree threat (ingestion), *processes* it through hierarchical organs (digestion), but the Governor's letter acts as **indigestible memory** causing the system to **reject/expel** its own destructive output. The metaphor doesn't just describe — it *designs* the story's anatomy: life survives because bureaucracy, like a gut, cannot digest *history*.

DIFFICULTY: hard