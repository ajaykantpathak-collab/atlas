## DEFINITION
Critical Thinking: Analysis and Interpretation is the systematic process of examining a literary text beyond its surface meaning to uncover underlying themes, evaluate authorial choices, assess character motivations within socio-cultural contexts, and judge the effectiveness of dramatic techniques in conveying the intended message. It requires synthesizing textual evidence with contextual knowledge to form reasoned, defensible interpretations.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student can independently select relevant textual evidence from the play, connect it to broader themes (education system, parental pressure, teacher autonomy), evaluate conflicting perspectives of characters, and articulate a structured analytical argument using the PEEL (Point, Evidence, Explanation, Link) framework in board-exam style answers.

## SCOPE_BOUNDARY
This node covers critical analysis of the play "जतूह" (Jatuh) focusing on thematic depth, character dynamics, dramatic irony, and socio-cultural critique. It does NOT cover basic plot summary, character sketches, or vocabulary explanation (covered in nodes 001-012). It prepares for but does not include formal writing tasks (node 014) or discussion activities (node 015).

## WALKTHROUGH
Imagine you are a parent at a PTA meeting where the principal announces a new policy: "No student may take private tuition; school teaching is sufficient." You instantly think of Jatuh's Vimal, who scored 72/100 despite tuition, and the Director who defends the system. How do you argue your point using the play? Start by identifying the central conflict: institutional education vs. commercial coaching. Then trace how each character (Jatuh, Vimal, Yashoda, Director, Principal) embodies a stance. Notice the dramatic irony: the Director admits tuition is useless yet enforces rules that make it inevitable. Finally, connect this to the playwright's critique of a system that measures worth by marks, not learning. The key insight: critical analysis means exposing what the text *shows* versus what it *says*.

## DIAGNOSTIC_QUESTION_1
What is the primary dramatic function of the character 'Director' (फुंस'क) in the play "जतूह"? State in one sentence.

## DIAGNOSTIC_ANSWER_1
The Director represents institutional authority that perpetuates a contradictory system: he acknowledges the futility of tuition ("बच्चे देक्क्सज नहीं, गक्सफ'क;ज है") yet refuses to reform the system, exposing bureaucratic complicity. A wrong answer (e.g., "He is the villain who hates students") reveals the student confuses character role with moral judgment, missing the systemic critique.

## DIAGNOSTIC_QUESTION_2
Explain why Jatuh's statement "अच्छा है तो फिर दो, हमारे साथ---मरो, इस बेजा को" (Act 3) is an instance of dramatic irony. What does the audience know that the Principal does not?

## DIAGNOSTIC_ANSWER_2
The irony lies in Jatuh inviting the Principal to join her protest against the tuition system, while the audience knows the Principal is powerless to change it because he is bound by the same bureaucratic rules (he later admits "नियम...बेजा नहीं बदल सकते"). A wrong answer focusing only on Jatuh's anger misses the structural irony: the system traps both teacher and administrator.

## DIAGNOSTIC_QUESTION_3
Apply the concept of 'foil' to analyze how Yashoda (यशोदा) and Jatuh (जतूह) function as contrasting responses to the same oppressive system. Provide one textual evidence for each.

## DIAGNOSTIC_ANSWER_3
Yashoda internalizes oppression ("हम लोग तो नौकरी करते हैं...चुपचाप सहते हैं"), while Jatuh resists ("मैं कहती हूँ...नहीं मानूँगी"). Evidence: Yashoda says "अच्छा जी...मैं समझ गई" (submission); Jatuh says "नहीं, मैं नहीं मानूँगी" (defiance). A wrong answer listing traits without contrasting their *agency* shows misunderstanding of foil as a structural device.

## DIAGNOSTIC_QUESTION_4
Analyze the significance of the stage direction "नक़ल...नक़ल...नक़ल" (repeated thrice) in the tuition scene. How does this repetition function at literal, symbolic, and thematic levels simultaneously?

## DIAGNOSTIC_ANSWER_4
Literally: students mindlessly copy. Symbolically: education reduced to mechanical reproduction. Thematically: critiques a system valuing rote output over understanding. The triple repetition mirrors the three tuition subjects (Physics, Chemistry, Maths) and the three-way complicity (parents, tutors, schools). A wrong answer treating it as mere emphasis misses the layered signification.

## DIAGNOSTIC_QUESTION_5
Evaluate the playwright's choice to end the play with Jatuh and her sister eating "पूरी-सब्जी" while discussing the new tuition ban rule. Does this ending undermine or strengthen the play's critique? Justify.

## DIAGNOSTIC_ANSWER_5
It strengthens the critique through bitter realism: the mundane meal contrasts with the revolutionary meeting, showing that systemic change doesn't alter daily survival. The sister's pragmatic "नौकरी तो करनी है" (must keep the job) undercuts Jatuh's idealism, leaving the audience with unresolved tension — the hallmark of social realism. A wrong answer calling it a "happy ending" ignores the subtext of compromise.

## DIAGNOSTIC_QUESTION_6
Create a 4-line monologue for Vimal (विमल) ten years later, reflecting on his 72 marks in Home Science. It must reveal his current perspective on the tuition culture he experienced.

## DIAGNOSTIC_ANSWER_6
A strong monologue: "बहत्तर नंबर लाया था घरेलू विज्ञान में, / ट्यूशन के बावजूद, ट्यूशन के कारण नहीं। / आज जब मेरा बेटा रोता है फीस के लिए, / मैं कहता हूँ: बेटा, नंबर नहीं, हुनर कमा।" A weak answer (e.g., "I got good marks, tuition helped") fails to show character growth or thematic resonance, indicating the student cannot project textual evidence into imaginative extension.

## COMMON_MISCONCEPTION
Students equate "critical analysis" with "finding faults" in characters or plot. They write: "Jatuh is rude to the Director" or "The play is unrealistic because teachers don't speak like that." This error stems from confusing literary criticism (evaluation) with critical thinking (analysis of how meaning is constructed). They miss that Jatuh's rudeness is a deliberate dramatic device to expose the Director's hypocrisy, and the stylized dialogue serves Brechtian alienation, not realism.

## ON_FAILURE
1. Ask the student to list three things Jatuh *does* (not says) that challenge the system. 2. For each action, identify the stage direction or dialogue that shows the system's reaction. 3. Have them complete this sentence frame: "When Jatuh does X, the play reveals Y about the education system, because Z." 4. Practice converting one frame into a PEEL paragraph. This shifts focus from character judgment to structural analysis.

## BUILDS_ON
Literal and inferential comprehension (node 012) — students must first establish *what happens* before analyzing *why it matters*.

## LEADS_TO
Writing Skills: Based on the Chapter (node 014) — analytical insights become the content for structured essays, articles, and letters.

## PREREQUISITE_NODE_IDS
c11_hin_ar_cbse_06_001, c11_hin_ar_cbse_06_002, c11_hin_ar_cbse_06_003, c11_hin_ar_cbse_06_004, c11_hin_ar_cbse_06_005, c11_hin_ar_cbse_06_006, c11_hin_ar_cbse_06_007, c11_hin_ar_cbse_06_008, c11_hin_ar_cbse_06_009, c11_hin_ar_cbse_06_010, c11_hin_ar_cbse_06_011, c11_hin_ar_cbse_06_012
## PREREQUISITE_REASONS
c11_hin_ar_cbse_06_001: Context/background knowledge of the New Story Movement and Usha Priyamvada's style is essential to interpret her realist techniques.
c11_hin_ar_cbse_06_002: Plot structure knowledge allows identification of turning points (e.g., tuition scene, Director's office, final meeting) for analysis.
c11_hin_ar_cbse_06_003: Setting (school, tuition centre, home) functions as more than backdrop — it reflects power dynamics.
c11_hin_ar_cbse_06_004: Jatuh's characterization as protagonist provides the lens through which systemic critique is filtered.
c11_hin_ar_cbse_06_005: Supporting characters (Vimal, Yashoda, Director, Principal) represent stakeholder positions; their analysis requires prior understanding.
c11_hin_ar_cbse_06_006: Primary theme (education system vs. learning) is the core around which critical analysis revolves.
c11_hin_ar_cbse_06_007: Secondary themes (gender, bureaucracy, parental anxiety) enrich multi-dimensional interpretation.
c11_hin_ar_cbse_06_008: Imagery/metaphor (e.g., "नक़ल" as metaphor) are tools for deeper reading.
c11_hin_ar_cbse_06_009: Irony/symbolism (Director's dual role, food as compromise) are central to critical analysis.
c11_hin_ar_cbse_06_010: Key vocabulary (e.g., "नक़ल", "ट्यूशन", "नियम") carries ideological weight beyond dictionary meaning.
c11_hin_ar_cbse_06_011: Language usage (formal vs. colloquial, bureaucratic jargon) reveals power relations.
c11_hin_ar_cbse_06_012: Literal/inferential comprehension is the foundation; analysis builds on verified textual understanding.

## FORWARD_NODE_IDS
c11_hin_ar_cbse_06_014, c11_hin_ar_cbse_06_015, c12_hin_a_cbse_02_013, c12_hin_a_cbse_05_013, c12_hin_al_cbse_02_013, c12_hin_ar_cbse_03_013, c12_hin_ar_cbse_05_013, c12_hin_ar_cbse_06_003, c12_hin_ar_cbse_06_013

## FORWARD_REASONS
c11_hin_ar_cbse_06_014: Writing tasks (article, letter, essay) require the analytical arguments and textual evidence developed here.
c11_hin_ar_cbse_06_015: Discussion points (e.g., "Is tuition necessary?") demand the evaluative stances and multi-perspective understanding honed in this node.
c12_hin_a_cbse_02_013: Class 11 analysis of "Ram Ki Shakti Puja" trains epic-to-lyric comparative thinking.  
c12_hin_a_cbse_05_013: Class 11 Chapter 6 Critical Thinking node reinforces multi-stanza comparative analysis skills.  
c12_hin_al_cbse_02_013: Introduced the concept of 'memory as reconstruction' in a simpler text.  
c12_hin_ar_cbse_03_013: अगला तार्किक चरण: Critical Thinking: इस नोड की अवधारणाओं को सीधे उपयोग/विस्तारित करता है।  
c12_hin_ar_cbse_05_013: Previous chapter's critical thinking builds analytical continuity.  
c12_hin_ar_cbse_06_003: Class 11 critical thinking node — builds the analytical habit of asking "how does this detail create that effect?" required for PEEL paragraphs.  
c12_hin_ar_cbse_06_013: Builds on the critical thinking skills developed in Class 11 for a similar poetic genre.  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
none

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_06_012 -> c11_hin_ar_cbse_06_013 -> c11_hin_ar_cbse_06_014

## THIS_FORMULA
PEEL Analysis Framework: Point (interpretive claim) → Evidence (textual detail: dialogue, stage direction, structural feature) → Explanation (how evidence supports claim, linking to dramatic/literary device) → Link (connect to broader theme/authorial intent/socio-cultural context)

## FORMULA_VARIABLES
Point = Specific analytical claim about the play (e.g., "The play critiques performative bureaucracy"); Evidence = Exact textual reference (act, dialogue, stage direction); Explanation = Reasoning connecting evidence to claim using literary concepts (irony, foil, symbolism); Link = Connection to theme/author's purpose/context.

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
analytical

## CROSS_SUBJECT
c11_civics_democratic_rights | The play's depiction of institutional power (Director/Principal) versus individual agency (Jatuh) parallels civics concepts of state authority vs. citizen dissent, rule of law vs. justice.
c11_economics_human_capital | The tuition economy (parents paying for marks, tutors as service providers, schools as credentialing bodies) illustrates education as human capital investment with market distortions — a core economics concept.

## PREREQ_CONCEPT
PEEL paragraph structure and ability to distinguish literal vs. inferential meaning (from node 012).

## PREREQ_BEFORE
Student must be able to locate specific dialogues and stage directions in the play text and state their literal meaning.

## PREREQ_STUCK
If stuck, review node 012 (Comprehension) and practice converting three inferential answers into PEEL paragraphs.

## WORKED_EXAMPLE_1
PROBLEM: Analyze how the playwright uses the character of the Principal (प्रधानाचार्य) to deepen the critique of the education system. Write a PEEL paragraph.

STEPS:
- Step 1: Identify the Point — The Principal is not a passive bystander but an active maintainer of the status quo who admits the system's flaws yet refuses to act.
- Step 2: Gather Evidence — In Act 3, he says "नियम...बेजा नहीं बदल सकते" (rules cannot be changed) and later "मैं तो नौकरी करता हूँ" (I just do my job). Stage direction: "पिज्कलह नई रीढ़ नई देखते हुए" (looking at files, not at Jatuh).
- Step 3: Apply Concept — This characterizes him as a bureaucratic archetype: the "cog in the machine" who uses procedural helplessness as moral excuse. Contrast with Jatuh's "मैं नहीं मानूँगी."
- Step 4: Explain — His powerlessness is performative; he has authority (he calls the meeting) but chooses inertia. The stage direction "फाइलों में डूबा" symbolizes bureaucracy consuming humanity.
- Step 5: Link to Theme — This reinforces the central theme: the system survives not because of villains but because of functionaries who normalize dysfunction. Connect to Usha Priyamvada's New Story Movement focus on middle-class moral compromise.

REASONING: This works because it moves from character observation to structural analysis, using textual evidence to show how a minor character embodies systemic critique. The PEEL structure ensures each claim is anchored.

ANSWER: The Principal embodies bureaucratic complicity: though he acknowledges tuition's futility ("बच्चे देक्क्सज नहीं"), he hides behind procedural rigidity ("नियम नहीं बदल सकते") and professional detachment ("मैं तो नौकरी करता हूँ"). The stage direction "पिज्कलह नई रीढ़ नई देखते हुए" visually reinforces his refusal to engage morally. Unlike Jatuh's active resistance ("नहीं मानूँगी"), his passivity is a choice that sustains the system. Usha Priyamvada thus critiques not individual malice but the normalization of compromise in middle-class institutions — a hallmark of the New Story Movement.

## WORKED_EXAMPLE_2
PROBLEM: The play uses food (पूरी-सब्जी, खाना) as a recurring motif. Analyze its function at three levels: character, plot, and theme.

STEPS:
- Step 1: List all food references — Yashoda's "पूरी-सब्जी" in staff room (Act 1), Vimal's mother packing tiffin (Act 2), final scene: Jatuh and sister eating "पूरी-सब्जी" while discussing the new rule.
- Step 2: Character level — Yashoda's shared meal shows collegial bonding and normalization ("हम लोग तो...चुपचाप सहते हैं"). Vimal's tiffin represents parental care reduced to transactional support (marks for food). Jatuh's final meal shows solitary compromise.
- Step 3: Plot level — Food scenes punctuate structural beats: Act 1 (exposition of culture), Act 2 (rising action — Vimal's pressure), Act 3 (resolution — rule passed but life unchanged).
- Step 4: Theme level — Food = survival. The system forces characters to choose between principle and "रोटी". The final meal: the new rule exists, but they still eat the same food — systemic change without material change.
- Step 5: Synthesize — The motif traces the journey from collective complacency to individual rebellion to compromised coexistence, mirroring the play's ideological arc.

REASONING: This multi-level analysis demonstrates how a concrete motif carries abstract meaning, a key skill for board-exam "analyze the significance of..." questions.

ANSWER: Food operates as a leitmotif mapping the play's ideological trajectory. In Act 1, Yashoda's shared "पूरी-सब्जी" ritualizes collective resignation ("चुपचाप सहते हैं"). In Act 2, Vimal's tiffin box symbolizes parental love commodified into tuition investment. In Act 3, Jatuh eating alone with her sister while celebrating the tuition ban — "नया नियम आ गया...पर पूरी-सब्जी वही है" — encapsulates the bitter irony: regulatory victory without structural transformation. The motif thus binds character psychology, plot progression, and thematic argument into a single material thread.

## WORKED_EXAMPLE_3
PROBLEM: "The play 'जतूह' is not a critique of tuition but of the examination system that makes tuition inevitable." Evaluate this statement using evidence from at least three characters and two dramatic devices.

STEPS:
- Step 1: Deconstruct the claim — It shifts blame from symptom (tuition) to root cause (exam system). Check if text supports this.
- Step 2: Character 1 — Director: admits tuition useless ("देक्क्सज नहीं") but says "नक़ल...नक़ल" scene shows exams demand rote reproduction. His rule "90% marks for recognition" forces tuition.
- Step 3: Character 2 — Vimal: scores 72 despite tuition; his father says "ट्यूशन नहीं दिलाया तो फेल हो जाता". Exam fear drives tuition, not desire for learning.
- Step 4: Character 3 — Jatuh: she teaches well ("पूरा इसिज भद किया"), yet students need tuition because exam pattern ("बाजू-आईक्यू") rewards memorization, not understanding.
- Step 5: Device 1 — Dramatic Irony: Director's rule (90% for recognition) creates the tuition market he condemns.
- Step 6: Device 2 — Symbolism: "नक़ल" repetition symbolizes exam system reducing education to mechanical copying.
- Step 7: Synthesize — The statement is largely accurate: tuition is the parasite; the exam system is the host. The play attacks the host through the parasite.

REASONING: This combines character analysis, thematic interpretation, and dramatic device identification — exactly the multi-concept competency board exams demand.

ANSWER: The statement is valid. The Director's "90% marks" rule (Act 3) structurally incentivizes tuition; his admission "बच्चे देक्क्सज नहीं" makes him complicit. Vimal's 72 marks despite tuition prove the system rewards rote output ("नक़ल") over learning. Jatuh's effective teaching ("पूरा इसिज भद किया") fails because exams test memorization ("बाजू-आईक्यू"). Dramatic irony: the Director creates the demand he deplores. Symbolism: the triple "नक़ल" chant reduces education to mechanical reproduction. Thus, tuition is the symptom; the examination system is the disease.

## COMPETENCY_QUESTION_1
QUESTION: In the final scene, Jatuh says "एक काम और करो। पच्चीस रक़ीब को हम लोग इज़्ज़त की एक एहफ़वैक्स करें...जो जोक़ीब को...बुलंदी के साथ...". Explain how this line functions as a meta-theatrical comment on the play's own form. What is the "play within the play" being proposed, and why does the playwright choose this moment for it?

COMPETENCY: Interpret meta-theatricality and authorial self-reflexivity in a realist text.

STEPS:
- Step 1: Identify the literal proposal — Jatuh suggests staging a play about the tuition scandal for the Silver Jubilee.
- Step 2: Recognize meta-theatrical layer — The characters will perform their own story; the audience (us) watches a play about a play about the events we just watched.
- Step 3: Analyze function — It transforms lived trauma into artistic testimony, asserting agency: "we will tell our story our way."
- Step 4: Connect to playwright's intent — Usha Priyamvada (New Story Movement) believes in art as social intervention. The proposed play mirrors her own method: using fiction to expose reality.
- Step 5: Evaluate timing — Placed after the compromise (meal), it reclaims narrative control: the system won the policy battle, but artists win the meaning battle.

ANSWER: The line proposes a "play within a play" where the teachers dramatize their own struggle, turning institutional defeat into artistic testimony. Meta-theatrically, it mirrors Usha Priyamvada's own project: "जतूह" is that very play. By having Jatuh propose it *after* the compromised victory (tuition ban passed but daily life unchanged), the playwright asserts that while bureaucracy manages outcomes, art manages meaning. The Silver Jubilee setting — a celebration of institutional longevity — becomes the stage for subversion. This self-reflexive moment elevates the play from social realism to a manifesto for committed literature.

DIFFICULTY: hard

## COMPETENCY_QUESTION_2
QUESTION: Compare the representation of 'female agency' in Jatuh (जतूह) and Yashoda (यशोदा). How do their class positions (permanent vs. temporary teacher) and domestic roles (single vs. married) shape their resistance strategies? Use the concept of 'intersectionality' in your analysis.

COMPETENCY: Apply intersectional literary analysis to character comparison.

STEPS:
- Step 1: Define intersectionality in this context — overlapping identities (gender, employment status, marital status) creating distinct experiences of oppression/resistance.
- Step 2: Map Jatuh — Permanent, single, mid-career. Agency: vocal, public, ideological ("नहीं मानूँगी"). Can afford risk (job security).
- Step 3: Map Yashoda — Temporary, married, domestic burden ("बच्चे...पति"). Agency: quiet, private, pragmatic ("अच्छा जी...समझ गई"). Cannot risk job (family dependency).
- Step 4: Analyze key scene — Staff room meal (Act 1): Yashoda shares food (communal survival); Jatuh refuses to sign (individual protest). Same space, different intersectional positions.
- Step 5: Synthesize — The play refuses a monolithic "woman teacher" identity. Jatuh's privilege (permanence) enables her heroism; Yashoda's precarity forces complicity. Neither is judged — both are products of structure.

ANSWER: Jatuh and Yashoda represent intersectionally distinct female agencies. Jatuh — permanent, single, childless — wields institutional security as a shield for public dissent ("मैं नहीं मानूँगी"). Yashoda — temporary, married, mother — deploys domestic pragmatism as survival ("हम लोग तो नौकरी करते हैं...चुपचाप सहते हैं"). The staff-room meal scene crystallizes this: Yashoda's "पूरी-सब्जी" sharing ritualizes collective endurance; Jatuh's refusal to sign the attendance register enacts individual rupture. The play does not rank them; it shows how patriarchy and bureaucracy intersect differently across class/employment lines. Jatuh's final compromise (eating "पूरी-सब्जी" with sister) suggests even her agency is contingent. True resistance, the play implies, requires structural change, not just individual courage.

DIFFICULTY: hard