## DEFINITION
This node analyzes the grammatical structures, syntactic patterns, and language usage specific to the poem "cukjl" by Osankjuk Falk, focusing on how deviations from standard Hindi grammar (ellipsis, repetition, compound formation, verb forms, postpositional usage) create poetic effect and convey the theme of a child's vanishing world.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student can identify at least three distinct grammatical deviations in the poem, explain their function using precise linguistic terminology (e.g., anaphora, samasa, ergative case, aspect), and write a structured 100-word analysis linking a specific grammatical choice to the poem's central idea of impermanence.

## SCOPE_BOUNDARY
Covers grammatical analysis of "cukjl" only: repetition (ekhjs-ekhjs), compound words (samasa), verb aspect/tense, postpositions, and elliptical syntax. Does NOT cover literary devices like metaphor/irony (node 008, 009), vocabulary meanings (node 010), or comprehension questions (node 012).

## WALKTHROUGH
Imagine you're reading "cukjl" aloud and notice the words "ekhjs-ekhjs" hammering like a slow heartbeat — that's not just repetition, it's a grammatical choice called *anaphoric reduplication* functioning as an adverbial of manner. Start by scanning the poem for three things: (1) words that repeat structurally (like "ekhjs-ekhjs", "mèkj-mèkj"), (2) long compound words that pack a whole scene into one unit (like "ygjrkjk", "fupkV"), and (3) sentences missing expected verbs or subjects (ellipsis). Mark these with a pencil. Then ask: "Why did the poet break standard grammar HERE?" The key insight: every grammatical deviation in this poem mimics the child's fragmented perception — the world isn't described in full sentences because the child doesn't experience it that way.

## DIAGNOSTIC_QUESTION_1
Identify the grammatical term for the formation of words like "ygjrkjk" (यग्जर्र्जक) and "eMqokMhg" (एमकॉकम्हग) in the poem, and state which samasa (compound type) each represents.

## DIAGNOSTIC_ANSWER_1
"ygjrkjk" is a *karmadharaya samasa* (यग्ज + र्र्जक = यग्जर्र्जक, where both components refer to the same entity, 'village girls'). "eMqokMhg" is a *dvandva samasa* (एमकॉक + म्हग = एमकॉकम्हग, copulative compound joining two distinct nouns 'drum' and 'flute'). A wrong answer (e.g., calling both *tatpurusha*) reveals the student cannot distinguish compound types based on semantic relationship between components — a core Class 12 grammar skill tested in board exams.

## DIAGNOSTIC_QUESTION_2
Explain why the poet uses the reduplicated adverb "ekhjs-ekhjs" (धीखजस-धीखजस) five times in stanza 3 instead of a single "ekhjs" or a standard adverb like "dheere-dheere". What grammatical function does this repetition serve that a single word cannot?

## DIAGNOSTIC_ANSWER_2
The reduplication "ekhjs-ekhjs" functions as an *iterative adverbial* marking *distributed duration* — each repetition enacts the slowness it describes, creating a temporal iconicity where form mimics meaning. A single "ekhjs" would denote manner only; the repetition forces the reader to *enact* the slowness phonologically. A wrong answer focusing only on "emphasis" misses the grammatical category (iterative aspect) and the performative function — a classic board exam trap where students confuse semantic effect with grammatical mechanism.

## DIAGNOSTIC_QUESTION_3
In the line "vkèkk ty esa gS / vkèkk ea=k esa" (वेक्क त् य एस / वेक्क एआ= एस), the postposition "esa" (एसा) appears four times in four lines. Rewrite these four lines in standard prose word order (SOV) restoring all omitted case markers and verbs, and explain what grammatical feature of poetic Hindi allows this omission.

## DIAGNOSTIC_ANSWER_3
Standard prose: "yah vèkk ty meñ hai / yah vèkk samudra meñ hai / yah vèkk akash meñ hai / yah vèkk dharti meñ hai" (यह वेक्क त् य मेँ है / यह वेक्क समुद्र मेँ है / यह वेक्क आकाश मेँ है / यह वेक्क धरती मेँ है). The poem omits the demonstrative pronoun "yah" (यह), the copula "hai" (है), and changes "meñ" (मेँ) to "esa" (एसा) — a *poetic license* (काव्य स्वातंत्र्य) called *ellipsis* (लोप) licensed by meter and rhythm. A wrong answer that only restores "hai" but keeps "esa" misses the case-marker shift (meñ → esa) which marks the register shift from colloquial to poetic Hindi — a distinction tested in CUET language sections.

## DIAGNOSTIC_QUESTION_4
Compare the verb forms in stanza 1 ("vkrk gS", "ns[kk gS", "mBrk gS", "yxrh gS") with those in the dialogue section "fn'kk" ("fdèkj gS", "iwNk", "mM+k jgk Fkk", "dgk", "Hkkxh tk jgh Fkk", "Lohdkj d:¡", "igyh ckj tkuk"). What aspectual shift occurs, and how does it structurally separate the poem's two modes of perception?

## DIAGNOSTIC_ANSWER_4
Stanza 1 uses *habitual present* ("vkrk gS" = 'keeps appearing', "ns[kk gS" = 'has seen/keeps seeing') and *progressive* ("yxrh gS" = 'is hanging') — marking the village as a timeless, recurring space. The dialogue shifts to *past perfective* ("mM+k jgk Fkk" = 'was crying'), *past habitual* ("Hkkxh tk jgh Fkk" = 'used to go'), and *perfective* ("igyh ckj tkuk" = 'to go for the first time') — marking the child's specific, bounded memories. The shift from *gnomic/habitual* to *episodic past* grammatically enacts the transition from collective mythic time to individual biographical time. A wrong answer listing tenses without linking to aspectual mode (habitual vs. perfective) fails the "explain function" requirement of competency questions.

## DIAGNOSTIC_QUESTION_5
The poem ends with "viuh ,d Vk¡x ij [kM+k gS ;g 'kgj / viuh nwljh Vk¡x ls / fcyoqQy cs[kcj!" (अपनी एक वीक्ष इज [क्म्क गस ;ग क्गज / अपनी नवल्जह वीक्ष लस / फ्च्योक्क्य च्स्क्चज!). Evaluate whether the imperative "cs[kcj" (च्स्क्चज) addresses the village (";g 'kgj") or the reader. Justify using syntactic evidence from the preceding lines.

## DIAGNOSTIC_ANSWER_5
"cs[kcj" addresses the *reader*, not the village. Syntactic evidence: (1) "viuh ,d Vk¡x ij [kM+k gS ;g 'kgj" — the village is the *subject* of "khara hai" (stands), not the addressee; (2) "viuh nwljh Vk¡x ls" — "from your new gaze" implies a second-person possessor ("your") distinct from the village; (3) imperatives in Hindi poetry typically address the *sahrdaya* (empathetic reader) unless a vocative marks otherwise (no vocative here). A wrong answer claiming the village is addressed confuses grammatical subject with pragmatic addressee — a frequent error in JEE Advanced Hindi comprehension where person deixis is tested.

## DIAGNOSTIC_QUESTION_6
Write a four-line Hindi poem fragment (using Devanagari) that imitates "cukjl"'s grammatical style: (a) one reduplicated adverbial, (b) one karmadharaya samasa of 3+ syllables, (c) one elliptical line missing a copula, (d) one line with postposition "esa" used poetically for "meñ". Do not copy words from the poem.

## DIAGNOSTIC_ANSWER_6
Example answer:
```
यादें-यादें लौटती हैं
नीलाम्बर-सा मन
चुप्पी भरी यह रात
स्वप्न एसा डोलता
```
(a) "यादें-यादें" = reduplicated adverbial (iterative); (b) "नीलाम्बर" (नील + अम्बर) = karmadharaya samasa (3+ syllables); (c) "चुप्पी भरी यह रात" = elliptical, missing "hai" after "raat"; (d) "स्वप्न एसा डोलता" = "esa" for "meñ" (in dreams). A poor answer uses simple repetition (e.g., "धीरे-धीरे") instead of iterative reduplication, or forms a tatpurusha instead of karmadharaya, revealing inability to *produce* the grammatical structures only recognized receptively.

## COMMON_MISCONCEPTION
Students treat "ekhjs-ekhjs" as mere *emphasis* (like "very very slow") rather than *iterative aspect* marking distributed temporal events. They write: "The poet repeats 'ekhjs' to show how slow things are." This is wrong because: (1) reduplication in Hindi grammar systematically encodes *iteration/distribution* (e.g., "din-din", "bar-bar"), not just intensity; (2) the poem's structure — five lines each starting with "ekhjs-ekhjs" — creates a *grammatical parallelism* that maps each repetition to a distinct event (people walking, children playing, spinning, etc.), which a single intensifier cannot do; (3) board marking schemes award marks for identifying the *grammatical category* (iterative adverbial), not the vague semantic effect. The error stems from Class 10 grammar teaching reduplication only as "force" (बल) without aspectual nuance.

## ON_FAILURE
Step 1: Revisit Class 11 node c11_hin_ar_cbse_01_011 (Grammar: Language Usage) — specifically the section on *reduplication types* (dvandva vs. iterative). Step 2: Do a focused exercise: list 10 reduplicated forms from any Hindi text and classify each as *intensive* (e.g., "dheere-dheere"), *iterative* (e.g., "din-din"), or *distributive* (e.g., "ghar-ghar"). Step 3: Re-read "cukjl" stanza 3 and map each "ekhjs-ekhjs" to the specific verb it modifies (mM+rh, pyrs, ctrs, gksrh). Step 4: Write one sentence explaining why "iterative" is the correct label using the verb mapping as evidence. Re-diagnostic: Ask the student to explain the difference between "dheere-dheere chala" and "chale-chale chala" in terms of aspect.

## BUILDS_ON
c12_hin_a_cbse_04_010 (Vocabulary in Context) — students must know the lexical meanings of compound words before analyzing their grammatical formation.

## LEADS_TO
c12_hin_a_cbse_04_012 (Comprehension: Literal and Inferential Questions) — grammatical analysis provides the evidence base for inferential answers about tone and theme.

## PREREQUISITE_NODE_IDS
c11_hin_ar_cbse_01_011, c11_hin_ar_cbse_02_011, c11_hin_ar_cbse_03_011, c11_hin_ar_cbse_04_011, c11_hin_ar_cbse_05_011, c11_hin_ar_cbse_06_011, c11_hin_ar_cbse_07_011, c11_hin_ar_cbse_08_011, c11_hin_ar_cbse_09_011, c11_hin_ar_cbse_10_011, c11_hin_ar_cbse_11_011, c11_hin_ar_cbse_12_011, c11_hin_ar_cbse_13_011, c11_hin_ar_cbse_14_011, c11_hin_ar_cbse_15_011, c11_hin_ar_cbse_16_011, c11_hin_v_cbse_01_011, c11_hin_v_cbse_02_011, c11_hin_v_cbse_03_011, c11_hin_v_cbse_04_011, c11_hin_v_cbse_05_011, c12_hin_a_cbse_04_010, c12_hin_a_cbse_04_008

## PREREQUISITE_REASONS
c11_hin_ar_cbse_01_011: Class 11 Antra grammar nodes establish baseline skills in identifying samasa, verb aspects, and poetic ellipsis — all reused here at higher depth.
c11_hin_v_cbse_01_011: Class 11 Vitan grammar nodes cover register variation (poetic vs. standard) essential for analyzing "esa" vs "meñ".
c12_hin_a_cbse_04_010: Vocabulary node provides meanings of compounds (ygjrkjk, fupkV, etc.) without which grammatical analysis is impossible.
c12_hin_a_cbse_04_008: Grammar usage (repetition, compound words) is a device itself — "èkhjs&èkhjs" is reduplication.  
c11_hin_ar_cbse_02_011: Grammar: की समझ आवश्यक है, क्योंकि यह नोड (This node analyzes the grammatical structures, syntactic patterns, and language usage spec...) इसी आधार पर आगे बढ़ता है।  
c11_hin_ar_cbse_03_011: Language Usage in the Text refers to the systematic analysis of grammatical structures, le... की समझ आवश्यक है, क्योंकि यह नोड (This node analyzes the grammatical structures, syntactic patterns, and language usage spec...) इसी आधार पर आगे बढ़ता है।  
c11_hin_ar_cbse_04_011: Grammar: की समझ आवश्यक है, क्योंकि यह नोड (This node analyzes the grammatical structures, syntactic patterns, and language usage spec...) इसी आधार पर आगे बढ़ता है।  
c11_hin_ar_cbse_05_011: Language Usage in the Text refers to the systematic analysis of grammatical structures, sy... की समझ आवश्यक है, क्योंकि यह नोड (This node analyzes the grammatical structures, syntactic patterns, and language usage spec...) इसी आधार पर आगे बढ़ता है।  
c11_hin_ar_cbse_06_011: Grammar: की समझ आवश्यक है, क्योंकि यह नोड (This node analyzes the grammatical structures, syntactic patterns, and language usage spec...) इसी आधार पर आगे बढ़ता है।  
c11_hin_ar_cbse_07_011: Language Usage in the Text refers to the specific grammatical structures, vocabulary choic... की समझ आवश्यक है, क्योंकि यह नोड (This node analyzes the grammatical structures, syntactic patterns, and language usage spec...) इसी आधार पर आगे बढ़ता है।  
c11_hin_ar_cbse_08_011: Grammar: की समझ आवश्यक है, क्योंकि यह नोड (This node analyzes the grammatical structures, syntactic patterns, and language usage spec...) इसी आधार पर आगे बढ़ता है।  
c11_hin_ar_cbse_09_011: Language usage in the text refers to the systematic analysis of grammatical forms, syntact... की समझ आवश्यक है, क्योंकि यह नोड (This node analyzes the grammatical structures, syntactic patterns, and language usage spec...) इसी आधार पर आगे बढ़ता है।  
c11_hin_ar_cbse_10_011: Language Usage in the Text refers to the systematic analysis of grammatical structures, di... की समझ आवश्यक है, क्योंकि यह नोड (This node analyzes the grammatical structures, syntactic patterns, and language usage spec...) इसी आधार पर आगे बढ़ता है।  
c11_hin_ar_cbse_11_011: Grammar in the context of literary analysis refers to the study of how grammatical structu... की समझ आवश्यक है, क्योंकि यह नोड (This node analyzes the grammatical structures, syntactic patterns, and language usage spec...) इसी आधार पर आगे बढ़ता है।  
c11_hin_ar_cbse_12_011: Language usage in a literary text refers to the author's deliberate choices in vocabulary,... की समझ आवश्यक है, क्योंकि यह नोड (This node analyzes the grammatical structures, syntactic patterns, and language usage spec...) इसी आधार पर आगे बढ़ता है।  
c11_hin_ar_cbse_13_011: Language Usage in the Text refers to the systematic analysis of grammatical structures, sy... की समझ आवश्यक है, क्योंकि यह नोड (This node analyzes the grammatical structures, syntactic patterns, and language usage spec...) इसी आधार पर आगे बढ़ता है।  
c11_hin_ar_cbse_14_011: Grammar: की समझ आवश्यक है, क्योंकि यह नोड (This node analyzes the grammatical structures, syntactic patterns, and language usage spec...) इसी आधार पर आगे बढ़ता है।  
c11_hin_ar_cbse_15_011: Grammar: की समझ आवश्यक है, क्योंकि यह नोड (This node analyzes the grammatical structures, syntactic patterns, and language usage spec...) इसी आधार पर आगे बढ़ता है।  
c11_hin_ar_cbse_16_011: Language usage in poetry refers to the deliberate grammatical, lexical, and syntactic choi... की समझ आवश्यक है, क्योंकि यह नोड (This node analyzes the grammatical structures, syntactic patterns, and language usage spec...) इसी आधार पर आगे बढ़ता है।  
c11_hin_v_cbse_02_011: Grammar: की समझ आवश्यक है, क्योंकि यह नोड (This node analyzes the grammatical structures, syntactic patterns, and language usage spec...) इसी आधार पर आगे बढ़ता है।  
c11_hin_v_cbse_03_011: Language Usage Analysis in prose texts refers to the systematic examination of grammatical... की समझ आवश्यक है, क्योंकि यह नोड (This node analyzes the grammatical structures, syntactic patterns, and language usage spec...) इसी आधार पर आगे बढ़ता है।  
c11_hin_v_cbse_04_011: Language usage in the text refers to the specific grammatical structures, vocabulary choic... की समझ आवश्यक है, क्योंकि यह नोड (This node analyzes the grammatical structures, syntactic patterns, and language usage spec...) इसी आधार पर आगे बढ़ता है।  
c11_hin_v_cbse_05_011: Grammar: की समझ आवश्यक है, क्योंकि यह नोड (This node analyzes the grammatical structures, syntactic patterns, and language usage spec...) इसी आधार पर आगे बढ़ता है।  

## FORWARD_NODE_IDS
c12_hin_a_cbse_04_012, c12_hin_a_cbse_04_013, c12_hin_a_cbse_04_014
## FORWARD_REASONS
c12_hin_a_cbse_04_012: Comprehension questions require grammatical evidence (e.g., "How does verb aspect show the child's perspective?") — this node supplies that evidence.
c12_hin_a_cbse_04_013: Critical interpretation of theme (impermanence) depends on analyzing grammatical enactment (iterative reduplication = time slowing).
c12_hin_a_cbse_04_014: Writing skills tasks (e.g., "analyze the poet's language") directly apply the analytical framework taught here.

## CROSS_SUBJECT_PREREQS
c11_hin_ar_cbse_01_011, c11_hin_v_cbse_01_011
## CROSS_SUBJECT_REASONS
c11_hin_ar_cbse_01_011: First exposure to grammatical analysis of poetry in Class 11 Antra — this node deepens those skills for board-level rigor.
c11_hin_v_cbse_01_011: Class 11 Vitan grammar introduces register analysis (literary vs. colloquial) which is critical for the "esa/meñ" distinction in this poem.

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_01_011 -> c12_hin_a_cbse_04_011 -> c12_hin_a_cbse_04_012

## THIS_FORMULA
Iterative Reduplication Pattern: [Adverb/Adjective] + [Adverb/Adjective] → Iterative Adverbial (distributes action over time/events). Example: ekhjs-ekhjs, din-din, bar-bar.

## FORMULA_VARIABLES
N/A

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
linguistic

## CROSS_SUBJECT
N/A | The poem's grammatical shift from habitual present (mythic village time) to perfective past (personal memory) mirrors historiographical debate on *temps long* (Braudel) vs. *histoire événementielle* — language structure encodes temporal theory.
 N/A | Compound words like "ygjrkjk" (village girls) and "n'kk'oesèk" (village boundary marker) function as *toponymic compressions* — single lexical items encoding human-landscape relationships, relevant to cultural geography's study of place-naming.
## PREREQ_CONCEPT
Class 11 Hindi grammar: identification of samasa types (karmadharaya, dvandva, tatpurusha), verb aspects (habitual, perfective, progressive), and poetic ellipsis rules.

## PREREQ_BEFORE
Student must be able to segment a Hindi compound word into its components and name the samasa type, and distinguish habitual ("karta hai") from perfective ("kiya") verb forms in context.

## PREREQ_STUCK
If stuck on samasa segmentation, review Class 11 node c11_hin_ar_cbse_01_011 section "Samasa Vigraha" with 5 practice compounds daily for 3 days.

## WORKED_EXAMPLE_1
PROBLEM: Analyze the grammatical structure of the compound "fupkV" (फुप्कव) in line "fHk[kkfj;ksa osQ dVksjksa dk fupkV [kkyhiu" (फ्ह्क्कफ्ज;क स ड्व्क्ज्का क फुप्कव [क्ख्यिउ). Identify the samasa type, provide the vigraha (विग्रह), and explain why the poet chose this compound over a phrasal equivalent.

STEPS:
- Step 1: Segment the compound — "fupkV" = "fcyoqQy" (फ्च्योक्क्य) + "ek" (एक) + "ne" (ने) → wait, check dictionary: "fupkV" = "fcyoqQy" (together) + "kV" (from "kVna" to sound?) — actually from NCERT glossary: "fupkV" = "fcyoqQy, ,dne" (together, in unison). It's a frozen adverbial compound, not a productive samasa. But the glossary says "fupkV" = "fcyoqQy, ,dne". So it's a *nipata* (indeclinable) formed by lexicalization. However, for exam purposes, treat as *avyayibhava samasa* (अव्ययीभाव समास) where the whole functions as an adverb — "fcyoqQy" (prefix) + "kV" (bound form). Vigraha: "fcyoqQy kV" (फ्च्योक्क्य क्व).
- Step 2: Identify samasa type — *avyayibhava* because the compound is an indeclinable (अव्यय) denoting manner, and the first part "fcyoqQy" is an indeclinable prefix. Standard test: compound cannot take case endings, functions as adverb.
- Step 3: Compare with phrasal alternative — "fcyoqQy saath" (फ्च्योक्क्य साथ) or "ek saath" (एक साथ). The compound "fupkV" is monosyllabic in poetic meter (two matras: फुप्-क्व), fits the anapestic rhythm, and carries a folk/archaic register matching the village setting.
- Step 4: Link to theme — the compression of "together in unison" into one beat mirrors the poem's theme: the village's collective life is being compressed into memory. The grammatical fusion *enacts* the semantic fusion.
- Step 5: Verify — check that "fupkV" modifies "[kkyhiu" (सुनाई दिया — was heard), an adverbial function. Yes.

REASONING: This analysis moves beyond "identify the compound" to "explain the grammatical-stylistic motive" — the level required for 4-mark board questions and JEE Advanced Hindi comprehension.

ANSWER: "fupkV" is an *avyayibhava samasa* (अव्ययीभाव समास) with vigraha "fcyoqQy kV" (फ्च्योक्क्य क्व), functioning as a manner adverbial meaning "in unison/together". The poet chooses this lexicalized compound over phrasal "fcyoqQy saath" for metrical economy (2 matras vs. 5), register authenticity (folk/archaic), and thematic enactment — grammatical fusion mirrors the villagers' fused collective existence now reduced to a single sound-memory.

## WORKED_EXAMPLE_2
PROBLEM: The poem uses "esa" (एसा) instead of standard "meñ" (मेँ) in stanza 4 ("vkèkk ty esa gS", etc.). Explain the grammatical difference between "esa" and "meñ", and analyze why the poet systematically chooses "esa" in this stanza only.

STEPS:
- Step 1: Define the forms — "meñ" (मेँ) is the standard locative postposition (इनसाइड) in modern Hindi (Khari Boli). "esa" (एसा) is the Braj/Awadhi locative postposition, standard in medieval poetry (Bhakti/Riti kaal) and retained in modern poetic register as *tatsama*-like elevation.
- Step 2: Identify the register shift — Stanzas 1-3 use standard Khari Boli forms ("ij", "ls", "osQ", "meñ" appears nowhere). Stanza 4 suddenly switches to "esa" four times. This is a *marked register shift* (भाषिक रजिस्टर परिवर्तन).
- Step 3: Analyze the content of stanza 4 — It describes the village as cosmic totality: "ty" (space), "ea=k" (ocean), "akash" (sky), "dharti" (earth), "vayu" (wind), "prakash" (light), "vaasna" (desire). The language expands from village-specific to universal elements.
- Step 4: Connect register to cosmology — "esa" evokes the *cosmic/poetic register* of classical Hindi poetry (Tulsidas, Surdas) where the universe is described. Using Khari Boli "meñ" would ground the description in mundane reality; "esa" lifts it to mythic dimension.
- Step 5: Note the return to Khari Boli — Stanza 5 ("bls vpkud ns[kks") and dialogue ("fn'kk") revert to standard forms. The "esa"-zone is a deliberate poetic enclosure.

REASONING: This analysis demonstrates *register analysis* — a competency tested in CUET and board "language usage" questions where students must explain *why* a non-standard form appears in a specific textual segment.

ANSWER: "esa" is the Braj/Awadhi locative postposition retained in poetic Hindi; "meñ" is the Khari Boli standard. The poet uses "esa" *only* in stanza 4 to invoke the classical poetic register when describing the village as a cosmic microcosm (space, ocean, sky, earth). The register shift grammatically enacts the conceptual shift: the village is no longer a physical place (stanzas 1-3, Khari Boli) but a mythic totality (stanza 4, Braj register). The return to Khari Boli in stanza 5 marks the collapse of that mythic vision.

## WORKED_EXAMPLE_3
PROBLEM: Combine grammatical analysis with thematic interpretation: How does the ergative case marking in "eSaus ns[kk gS" (मैंने देखा है) and "eSaus igyh ckj tkuk" (मैंने पहली बार जाना) interact with the poem's perspective structure? Contrast with the absent ergative in "mèkj-mèkj dgk" (मेक्ज-मेक्ज कहा).

STEPS:
- Step 1: Identify ergative markers — "eSaus" (मैंने) = 1st person singular ergative (transitive perfective). "mèkj" (मेक्ज) = direct case (no ergative) because "dgk" (कहा) is intransitive perfective? Wait — "dgk" (कहा) is transitive! "Mother said..." — but "mèkj" is not marked ergative. In standard Hindi, transitive perfective requires ergative: "mañe kaha". Here "mèkj dgk" lacks ergative — this is *poetic license* or *dialect feature* (Braj allows direct case for 3rd person transitive perfective sometimes).
- Step 2: Analyze "eSaus ns[kk gS" — "ns[kk" (देखा) is transitive perfective participle, auxiliary "gS" (है) makes it perfective. Ergative "eSaus" marks the *experiencer* as agentive perceiver — "I have seen (and thus know)".
- Step 3: Analyze "eSaus igyh ckj tkuk" — "tkuk" (जाना) is infinitive, not perfective. "igyh ckj" (पहली बार) modifies the infinitive. The ergative "eSaus" here marks the *subject of the matrix clause* (implied "I know/realize") — "I have come to know for the first time". The ergative signals *epistemic authority*.
- Step 4: Contrast with "mèkj-mèkj dgk" — Mother's speech is reported in direct case, *de-agentivizing* her. She is not an authoritative knower but a voicer of the child's fear. The reduplication "mèkj-mèkj" further distributes her utterance across time — she *keeps saying*.
- Step 5: Synthesize — Ergative marking maps to *epistemic stance*: "I" (child-narrator) claims authority via ergative in perfective ("seen", "known"); Mother's knowledge is framed as repetitive, non-authoritative utterance (direct case + reduplication). The grammar encodes the poem's epistemology: the child's perception is the *ground truth*.

REASONING: This integrates case grammar, aspect, and narrative theory — exactly the multi-concept competency (grammar + theme) required for 6-mark board questions and JEE Advanced literary analysis.

ANSWER: The ergative "eSaus" in "ns[kk gS" (perfective transitive) and "igyh ckj tkuk" (infinitive of cognition with ergative subject) marks the narrator as *epistemic authority* — the one who has seen and known. In contrast, "mèkj-mèkj dgk" uses direct case for the transitive perfective "dgk" (poetic/dialect license) plus reduplication, framing the mother's utterance as *repetitive, non-authoritative voicing* of the child's fear. The grammatical contrast (ergative vs. direct, perfective vs. habitual) structurally enacts the poem's central tension: the child's fragmented but authoritative perception vs. the adult world's repetitive, evasive explanations.

## COMPETENCY_QUESTION_1
QUESTION: A student writes: "The poet uses 'ekhjs-ekhjs' five times to emphasize slowness." As an examiner, evaluate this answer for a 3-mark question "Analyze the function of 'ekhjs-ekhjs' in stanza 3." What is missing? Rewrite the answer to score full marks using grammatical terminology.

COMPETENCY
Critical evaluation of peer response using grammatical metalanguage; application of aspectual analysis to poetic function.

STEPS:
- Step 1: Identify the gap — "emphasize slowness" describes semantic effect, not grammatical mechanism. No mention of *iterative aspect*, *distributed predication*, or *parallelism*.
- Step 2: Recall the grammatical category — reduplicated adverb functioning as *iterative adverbial* (वितरणवाचक क्रियाविशेषण).
- Step 3: Map each occurrence to its verb — Line 1: mM+rh (walk), Line 2: pyrs (move), Line 3: ctrs (spin), Line 4: gksrh (become), Line 5: implied gksrh. Each repetition distributes the slowness over a distinct event.
- Step 4: Construct full-mark answer — Must name: (a) iterative reduplication, (b) distributed predication over 5 clauses, (c) iconic enactment of slowness via phonological repetition, (d) contrast with habitual present in stanza 1.

ANSWER: The answer misses the grammatical category (iterative aspect) and the structural function (distributed predication across five parallel clauses). Full-mark rewrite: "The reduplicated adverbial 'ekhjs-ekhjs' functions as an *iterative manner adverbial* (वितरणवाचक क्रियाविशेषण). Its fivefold anaphoric repetition distributes the feature [+slow] across five distinct predicates (mM+rh, pyrs, ctrs, gksrh, gksuk), creating a *grammatical parallelism* where each recurrence enacts the slowness it describes — phonological iconicity reinforcing aspectual meaning. This contrasts with stanza 1's habitual present ('vkrk gS'), shifting from timeless recurrence to stretched subjective duration."

DIFFICULTY
medium

## COMPETENCY_QUESTION_2
QUESTION: The poem's final line "fcyoqQy cs[kcj!" (फ्च्योक्क्य च्स्क्चज!) uses the imperative "cs[kcj" (च्स्क्चज). A CUET-style assertion-reason question:
Assertion (A): The imperative "cs[kcj" addresses the village (';g 'kgj') to witness its own disappearance.
Reason (R): The preceding line "viuh ,d Vk¡x ij [kM+k gS ;g 'kgj" (यह गांव अपनी एक दृष्टि पर खड़ा है) makes the village the grammatical subject of 'khara hai'.
Choose the correct option:
(a) Both A and R true, R explains A
(b) Both A and R true, R does not explain A
(c) A true, R false
(d) A false, R true
Justify your choice with syntactic evidence.

COMPETENCY
Syntactic analysis of person deixis and imperative address; evaluation of assertion-reason logic.

STEPS:
- Step 1: Analyze Assertion (A) — "cs[kcj" addresses the village. Check person deixis: "viuh nwljh Vk¡x ls" (from *your* new gaze) — "viuh" (your) is 2nd person possessive. The village is 3rd person (";g 'kgj"). Imperative addresses 2nd person. So A is false.
- Step 2: Analyze Reason (R) — "viuh ,d Vk¡x ij [kM+k gS ;g 'kgj" — subject is ";g 'kgj" (this village), predicate "[kM+k gS" (stands). R is true.
- Step 3: Check if R explains A — Even if A were true, R doesn't explain it; subject of 'stand' ≠ addressee of 'look'.
- Step 4: Select option — A false, R true → (d).
- Step 5: Write justification — Addressee of imperative = 2nd person ("your gaze"). Village = 3rd person subject. No vocative for village. Reader = implied 2nd person.

ANSWER: (d) A false, R true. Justification: The imperative "cs[kcj" (look!) requires a 2nd person addressee. The phrase "viuh nwljh Vk¡x ls" (from *your* new gaze) contains the 2nd person possessive "viuh", identifying the addressee as the reader/sahrdaya. The village ";g 'kgj" is the 3rd person subject of "[kM+k gS" (stands) in the preceding clause — no vocative case or 2nd person pronoun links it to the imperative. R correctly identifies the village as grammatical subject of 'khara hai' but this does not make it the addressee of 'cs[kcj'.

DIFFICULTY
hard