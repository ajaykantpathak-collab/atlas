## DEFINITION
"Context and Background" refers to the historical, social, biographical, and literary circumstances surrounding a text's creation. For Premchand's "Shatranj ke Khiladi" (The Chess Players), it includes the decline of feudalism in Awadh, British annexation policies (Doctrine of Lapse), Premchand's shift from idealistic to realistic writing, and the story's position as a critique of aristocratic decadence versus colonial exploitation.

## COGNITIVE_LEVEL
understand

## MASTERY_CRITERIA
The student can independently explain how the historical annexation of Awadh (1856) and Premchand's literary evolution (from *Sevasadan* to *Godaan*) shape the story's dual critique of the *nawabi* culture and British imperialism, using specific textual markers (e.g., the chess metaphor, Wajid Ali Shah's portrayal) to justify their analysis.

## SCOPE_BOUNDARY
This node covers: (1) Premchand's biography up to 1924 (publication of *Shatranj ke Khiladi*), (2) Historical context of Awadh's annexation and the 1857 revolt's shadow, (3) Literary context: transition from romantic/idealistic short story to social realism in Hindi, (4) The story's publication history (*Madhuri*, 1924). It does NOT cover: detailed plot summary, character sketches, or linguistic analysis of the text — those are addressed in sibling nodes 002–011.

## WALKTHROUGH
Imagine you are watching a period film where two nobles play chess while their kingdom collapses outside. Before judging the characters, you'd ask: "Why does the director show this contrast? What historical moment does this represent?" Similarly, before reading "Shatranj ke Khiladi," we must reconstruct the world Premchand wrote in: 1920s India, where the Non-Cooperation Movement was rising, but he chose to write about 1856 Lucknow. Step 1: Identify the author's life stage (Premchand at 44, government school inspector, disillusioned with colonial education). Step 2: Map the historical layer — the 1856 annexation of Awadh was a fresh wound in 1924, just as Jallianwala Bagh (1919) was fresh then. Step 3: Trace the literary shift — Premchand moved from *Premashram* (idealistic reform) to *Rangbhoomi* (complex realism); this story bridges that shift. Step 4: Notice the chess metaphor — it isn't just a game; it's a structural device mirroring political paralysis. The key insight: Context isn't background decoration; it's the lens that turns a story about two men playing chess into a national allegory.

## DIAGNOSTIC_QUESTION_1
What is the specific historical event that forms the immediate political backdrop of "Shatranj ke Khiladi," and in what year did it occur?

## DIAGNOSTIC_ANSWER_1
The annexation of Awadh by the British East India Company under Lord Dalhousie's Doctrine of Lapse in 1856. A wrong answer (e.g., "the 1857 Revolt" or "Battle of Plassey") reveals the student confuses the story's setting (pre-annexation decadence) with its consequential aftermath, missing Premchand's focus on the *moments before collapse* rather than the rebellion itself.

## DIAGNOSTIC_QUESTION_2
Premchand wrote this story in 1924. Explain why he chose to set it in 1856 Lucknow instead of writing about contemporary nationalist politics, considering his own life circumstances at the time.

## DIAGNOSTIC_ANSWER_2
Premchand (as a government employee under British rule) faced censorship risks writing directly about 1920s nationalism; the 1856 setting allowed allegorical critique of both feudal complicity (Mir/Roshan) and colonial manipulation (Company's chess-like strategy) while appearing "historical." A wrong answer focusing only on "he liked history" misses the strategic navigation of colonial censorship and the deliberate parallel between 1856 aristocratic negligence and 1920s elite disengagement from mass movements.

## DIAGNOSTIC_QUESTION_3
Apply the concept of "literary evolution" to explain how "Shatranj ke Khiladi" differs from Premchand's earlier story "Namak ka Daroga" (1911) in its treatment of morality.

## DIAGNOSTIC_ANSWER_3
"Namak ka Daroga" presents a clear moral binary (honest officer vs. corrupt merchant) with idealistic resolution; "Shatranj ke Khiladi" offers no moral center — Mir and Roshan are neither heroes nor villains but products of a decaying system, and the British are not merely oppressors but also modernizers (railways, courts). The student must trace: (1) Early Premchand = moral didacticism, (2) 1920s shift = psychological realism, (3) This story = systemic critique without redemption. A wrong answer listing only plot differences fails to connect form to the author's ideological journey.

## DIAGNOSTIC_QUESTION_4
Analyze the chess metaphor in the story's context: How does the *structure* of chess (rules, pieces, endgame) map onto the political structure of Awadh in 1856? Provide two specific mappings.

## DIAGNOSTIC_ANSWER_4
Mapping 1: The *immobility of the king* (Wajid Ali Shah) — in chess, the king moves one step; in Awadh, the Nawab is a puppet confined by British Resident's control. Mapping 2: *Sacrifice of pawns* (common people/soldiers) — Mir/Roshan ignore the "pawns" (peasants, sepoys) until the endgame (annexation) makes their loss irreversible. A wrong answer treating chess as mere "symbol of laziness" misses the structural isomorphism: the game's logic *is* the political logic Premchand exposes.

## DIAGNOSTIC_QUESTION_5
Evaluate the claim: "Premchand's portrayal of Wajid Ali Shah in the story is historically inaccurate but artistically necessary." Defend your position using the story's thematic priorities.

## DIAGNOSTIC_ANSWER_5
Artistically necessary. Historically, Wajid Ali Shah was a patron of arts, not merely a helpless addict; but Premchand *reduces* him to a "caged bird" (as the text says) to serve the theme: *institutional decay trickles down*. If the Nawab were competent, Mir/Roshan's chess obsession would be personal folly, not systemic rot. The distortion serves the allegory — the king's impotence mirrors the nobles' impotence. A wrong answer demanding historical fidelity ignores that Premchand writes *fable*, not chronicle; the "inaccuracy" is the point.

## DIAGNOSTIC_QUESTION_6
Create a 3-sentence "context card" for a Class 11 student that captures the *essential* triad: Author's Phase + Historical Moment + Literary Innovation, for "Shatranj ke Khiladi."

## DIAGNOSTIC_ANSWER_6
"Premchand at 44 (1924), transitioning from reformist idealism to systemic realism, uses the 1856 annexation of Awadh — the last major princely state swallowed by the Doctrine of Lapse — to invent a new Hindi short story form: the *allegorical realism* where a domestic game (chess) structurally replicates geopolitical checkmate, refusing both colonial apology and nationalist romance." A poor answer lists facts without synthesizing the *why* of the literary form.

## COMMON_MISCONCEPTION
Students treat "context" as a static list of dates (Premchand born 1880, story published 1924, Awadh annexed 1856) rather than a *dynamic tension* between three timelines: the story's diegetic time (1856), the writing time (1924), and the reading time (now). They miss that Premchand *chooses* 1856 *from* 1924 to speak to 1924 — e.g., the British officer's "polite" annexation mirrors the 1920s "reformist" colonial rhetoric (Montagu-Chelmsford Reforms). The error: context = trivia retrieval; correct: context = interpretive prism.

## ON_FAILURE
Step 1: Draw a three-column timeline on paper: Column A = 1856 events (annexation, Wajid Ali Shah exiled), Column B = 1924 events (Non-Cooperation Movement, Premchand resigns govt job, *Madhuri* publication), Column C = Textual echoes (find 3 lines in story where 1856 action mirrors 1924 reality). Step 2: For each column, ask: "What is the *mood*? (1856: false calm; 1924: suppressed rage; Text: ironic detachment)." Step 3: Write one paragraph connecting the three moods using the chess metaphor as the bridge. Step 4: Verify with teacher — does the paragraph explain *why* the story ends with Mir killing Roshan, not the British arriving?

## BUILDS_ON
Basic skill of distinguishing "setting" (where/when story happens) from "context" (why author chose that setting and what it means in author's time).

## LEADS_TO
Node c11_hin_ar_cbse_01_002 (Plot and Narrative Structure) — the non-linear narrative (starting with chess, flashing to history, ending in violence) is a direct formal consequence of the contextual tensions established here.

## PREREQUISITE_NODE_IDS
c11_hin_ar_cbse_02_001, c11_hin_ar_cbse_03_001, c11_hin_ar_cbse_08_001, c11_hin_v_cbse_01_001

## PREREQUISITE_REASONS
c11_hin_ar_cbse_02_001: g "Before You Read" for context — this node deepens it for Class 12's more complex modernist texts. c11_hin_ar_cbse_02_001: Builds familiarity with Nayi Kavita features (free verse, imagery) via earlier poems. c11_hin_ar_cbse_03_001: Reinfo  
c11_hin_ar_cbse_03_001: _cbse_02_001: Builds familiarity with Nayi Kavita features (free verse, imagery) via earlier poems. c11_hin_ar_cbse_03_001: Reinforces title-decoding as predictive skill. c11_hin_v_cbse_01_001: Provides parallel practice in Vitan textbook w  
c11_hin_ar_cbse_08_001: rical context, literary movement — as a mandatory first step for prose/poetry analysis in Class 11. c11_hin_ar_cbse_08_001: Covered Phanishwar Nath Renu's story "मैला आँचल" (Maila Anchal) in Class 11, giving students prior exposure to his r  
c11_hin_v_cbse_01_001: imagery) via earlier poems. c11_hin_ar_cbse_03_001: Reinforces title-decoding as predictive skill. c11_hin_v_cbse_01_001: Provides parallel practice in Vitan textbook with different poets/movements.  
## FORWARD_NODE_IDS
c11_hin_ar_cbse_01_002, c11_hin_ar_cbse_01_003, c11_hin_ar_cbse_01_004, c11_hin_ar_cbse_01_005, c11_hin_ar_cbse_01_006, c11_hin_ar_cbse_01_007, c11_hin_ar_cbse_01_008, c11_hin_ar_cbse_01_009, c11_hin_ar_cbse_01_010, c11_hin_ar_cbse_01_011, c11_hin_ar_cbse_01_012, c11_hin_ar_cbse_01_013, c11_hin_ar_cbse_01_014, c11_hin_ar_cbse_01_015, c12_hin_a_cbse_01_001, c12_hin_a_cbse_02_001, c12_hin_a_cbse_03_001, c12_hin_a_cbse_04_001, c12_hin_a_cbse_05_001, c12_hin_a_cbse_06_001, c12_hin_a_cbse_07_001, c12_hin_a_cbse_08_001, c12_hin_a_cbse_09_001, c12_hin_a_cbse_10_001, c12_hin_a_cbse_12_001, c12_hin_a_cbse_15_001, c12_hin_a_cbse_17_001, c12_hin_al_cbse_01_001, c12_hin_al_cbse_02_001, c12_hin_al_cbse_03_001, c12_hin_ar_cbse_01_001, c12_hin_ar_cbse_02_001, c12_hin_ar_cbse_03_001, c12_hin_ar_cbse_04_001, c12_hin_ar_cbse_06_001, c12_hin_ar_cbse_07_001, c12_hin_ar_cbse_08_001, c12_hin_ar_cbse_09_001, c12_hin_ar_cbse_10_001, c12_hin_ar_cbse_11_001, c12_hin_ar_cbse_12_001, c12_hin_ar_cbse_13_001, c12_hin_v_cbse_01_001, c12_hin_v_cbse_02_001, c12_hin_a_cbse_16_001

## FORWARD_REASONS
c11_hin_ar_cbse_01_002: Plot structure (circular/chess-like) derives from historical allegory established here. c11_hin_ar_cbse_01_003: Setting (Lucknow's *gharat* vs. *kothi*) is meaningless without 1856/1924 dual context. c11_hin_ar_cbse_01_004: Protagonists (Mir/Roshan) are archetypes of feudal decay, not individuals — context defines their typology. c11_hin_ar_cbse_01_005: Supporting characters (Nawab, British Resident, Begums) function as contextual forces. c11_hin_ar_cbse_01_006: Primary theme (decadence vs. modernity) is a contextual thesis. c11_hin_ar_cbse_01_007: Secondary themes (addiction, friendship, gender) are contextual symptoms. c11_hin_ar_cbse_01_008: Imagery (chess, birds, seasons) is contextual semiotics. c11_hin_ar_cbse_01_009: Irony (nobles playing while kingdom falls) is contextual structure. c11_hin_ar_cbse_01_010: Vocabulary (*nawabi*, *farman*, *talukdar*) is contextual lexicon. c11_hin_ar_cbse_01_011: Grammar (archaic *avधी*/*braj* forms) marks historical distance. c11_hin_ar_cbse_01_012: Comprehension questions test contextual inference. c11_hin_ar_cbse_01_013: Critical thinking requires contextual evaluation. c11_hin_ar_cbse_01_014: Writing tasks demand contextual argumentation. c11_hin_ar_cbse_01_015: Discussion points explore contextual relevance.
c12_hin_a_cbse_01_001: Introduced the "Before You Read" skill for Class 11 Aroh Chapter 1, establishing the habit of examining author background and historical context.  
c12_hin_a_cbse_02_001: Established the "Before You Read" pedagogical pattern — students know to expect biographical/historical framing.  
c12_hin_a_cbse_03_001: Introduced the "Before You Read" template (author bio → historical context → literary trends → thematic guesses) that this node deepens.  
c12_hin_a_cbse_04_001: Establishes the routine of reading "Before You Read" for context — this node deepens it for Class 12's more complex modernist texts. c11_hin_ar_cbse_02_001: Builds familiarity with *Nayi Kavita* features (free verse, imagery) via earlier poems. c11_hin_ar_cbse_03_001: Reinforces title-decoding as predictive skill. c11_hin_v_cbse_01_001: Provides parallel practice in Vitan textbook with different poets/movements.  
c12_hin_a_cbse_05_001: Introduced the “Before You Read” framework — using author bio and period to set expectations.  
c12_hin_a_cbse_06_001: Introduced the "Before You Read" skill for a medieval poet chapter, modeling how to extract biographical and historical context.  
c12_hin_a_cbse_07_001: Introduced the "Before You Read" skill at Class 11 level — identifying poet, period, genre — which this node advances to functional analysis.  
c12_hin_a_cbse_08_001: Introduced the skill of contextualising a literary text historically.  
c12_hin_a_cbse_09_001: Teaches the "Before You Read" method — identifying poet’s era, language, major themes, and biographical triggers — which is the exact scaffold needed for ?kukuan.  
c12_hin_a_cbse_10_001: First chapter of Class 11 Antra establishes the "Before You Read" routine — foundational for knowing *where to look* in the textbook.  
c12_hin_a_cbse_12_001: First exposure to 'Before You Read' structure in Class 11 Antra.  
c12_hin_a_cbse_15_001: Class 11 Antra Chapter 1 ("नमक का दारोगा") context node — establishes the method of using historical context (colonial salt tax) to decode irony, transferable here.  
c12_hin_a_cbse_17_001: Class 11 "Before You Read" for Namak ka Daroga — models how author context (Premchand, colonial era) shapes textual meaning; directly analogous to Mishra/Progressive era here.  
c12_hin_al_cbse_01_001: Introduced the step‑by‑step method of researching author biography, historical period, and key vocabulary before reading a Hindi prose chapter.  
c12_hin_al_cbse_02_001: Introduced the "Before You Read" routine for autobiographical sketches in Class 11 Antraal.  
c12_hin_al_cbse_03_001: Established the skill of reading "Before You Read" for author biography, historical context, and thematic framing in Class 11 Antra Chapter 1.  
c12_hin_ar_cbse_01_001: Class 11 "Before You Read" for Chapter 1 established the protocol of using context boxes — this node deepens that skill for Class 12 complexity.  
c12_hin_ar_cbse_02_001: Established the habit of using "Before You Read" as an interpretive lens for Hindi poetry.  
c12_hin_ar_cbse_03_001: Established the "Before You Read" routine — author, era, genre — which this node deepens with movement-specific analysis.  
c12_hin_ar_cbse_04_001: Introduces the 'Before You Read' strategy for Hindi prose/poetry in Class 11.  
c12_hin_ar_cbse_06_001: Establishes the "Before You Read" protocol — how to extract context before analyzing text.  
c12_hin_ar_cbse_07_001: First exposure to 'Before You Read' structure in Class 11 — teaches how to extract context from textbook introductory notes.  
c12_hin_ar_cbse_08_001: Introduced the "Before You Read" protocol — author biography, historical context, literary movement — as a mandatory first step for prose/poetry analysis in Class 11. c11_hin_ar_cbse_08_001: Covered Phanishwar Nath Renu's story "मैला आँचल" (Maila Anchal) in Class 11, giving students prior exposure to his regional setting, folk diction, and thematic concerns — essential baseline for recognizing continuities in his poetry.  
c12_hin_ar_cbse_09_001: Class 11 Chapter 1 established the baseline pre-reading strategy: identify author, era, and key terms before reading.  
c12_hin_ar_cbse_10_001: Introduces the “Before You Read” routine — identifying author, source, and setting — which this node deepens for a socially‑charged autobiographical sketch.  
c12_hin_ar_cbse_11_001: First Class 11 chapter established the "Before You Read" protocol (author, period, key terms) — procedural prerequisite.  
c12_hin_ar_cbse_12_001: Introduced the skill of using author biography and historical context to frame a story — directly applied here to Shekhar Joshi and 1970s Uttarakhand.  
c12_hin_ar_cbse_13_001: Introduces the "Before You Read" strategy for the first Aroh chapter — foundational skill.  
c12_hin_v_cbse_01_001: Provided the parallel Aroh pre-reading framework — reinforces the cross-textual skill of contextual framing, essential for board exam comparative questions.  
c12_hin_v_cbse_02_001: Covered *Namak ka Daroga* context — colonial administration's impact on ordinary lives, relevant to the *naukarshahi* patronage in this text.  
c11_hin_ar_cbse_01_003: Provides historical context of colonial bureaucracy and Premchand's reformist intent, essential for interpreting the social setting.  
c11_hin_ar_cbse_01_004: Context node provides colonial medical history background essential for understanding आयुर्विज्ञान's professional crisis  
c11_hin_ar_cbse_01_005: अगला तार्किक चरण: Supporting characters are fictional figures who interact with the protagonist to advance the plot, r... इस नोड की अवधारणाओं को सीधे उपयोग/विस्तारित करता है।  
c11_hin_ar_cbse_01_006: Provides historical context of colonial India necessary to understand the stakes.  
c11_hin_ar_cbse_01_007: अगला तार्किक चरण: Secondary themes are the subordinate thematic threads that run parallel to the primary theme, enrich... इस नोड की अवधारणाओं को सीधे उपयोग/विस्तारित करता है।  
c11_hin_ar_cbse_01_008: Context (colonial land revenue, Premchand's biography) explains *why* the metaphors target bureaucracy and debt.  
c11_hin_ar_cbse_01_009: अगला तार्किक चरण: Irony is a literary device where the intended meaning of words or events is opposite to their litera... इस नोड की अवधारणाओं को सीधे उपयोग/विस्तारित करता है।  
c11_hin_ar_cbse_01_010: अगला तार्किक चरण: Vocabulary in Context is the analytical skill of determining the precise meaning, connotation, and g... इस नोड की अवधारणाओं को सीधे उपयोग/विस्तारित करता है।  
c11_hin_ar_cbse_01_011: अगला तार्किक चरण: Grammar: इस नोड की अवधारणाओं को सीधे उपयोग/विस्तारित करता है।  
c11_hin_ar_cbse_01_012: अगला तार्किक चरण: Literal comprehension involves extracting explicitly stated information from the text (facts, events... इस नोड की अवधारणाओं को सीधे उपयोग/विस्तारित करता है।  
c11_hin_ar_cbse_01_013: Context/background knowledge essential for interpreting social commentary  
c11_hin_ar_cbse_01_014: Provides historical context (colonial India, Premchand's background) essential for thematic Links in PEEL.  
c11_hin_ar_cbse_01_015: अगला तार्किक चरण: Speaking and Listening: इस नोड की अवधारणाओं को सीधे उपयोग/विस्तारित करता है।  
c12_hin_a_cbse_16_001: If stuck, revisit the "Before You Read" section of any Class 11 Antra chapter (e.g., c11_hin_ar_cbse_01_001) and practice converting its bullet points into exam-style context statements.  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
none: No prior class cross-subject nodes provided in the map.

## CHAIN_DESCRIPTION
none -> c11_hin_ar_cbse_01_001 -> c11_hin_ar_cbse_01_002

## THIS_FORMULA
N/A - conceptual

## FORMULA_VARIABLES
N/A

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
conceptual

## CROSS_SUBJECT
c11_history_colonial_india | The Doctrine of Lapse (1848-1856) and annexation of Awadh are core History topics; Premchand's story fictionalizes the *cultural* impact of this political event on the *ashraf* class.
c11_sociology_social_change | The story illustrates "Sanskritization" in reverse: the *ashraf* (Muslim nobility) failing to adapt to colonial modernity, a classic case study in social mobility/blockage.
c11_political_science_colonialism | The British Resident's "soft power" (cultural patronage masking political control) exemplifies Gramscian hegemony — a Political Science concept applied to 1856 Lucknow.

## PREREQ_CONCEPT
Ability to distinguish between *diegetic time* (story's internal timeline) and *extradiegetic time* (author's historical moment) — a Class 10 skill refined here for allegorical reading.

## PREREQ_BEFORE
Student must know: (1) Premchand is the "Upanyas Samrat" of Hindi, (2) British annexed Awadh in 1856, (3) Short story as a genre emerged in Hindi in early 1900s.

## PREREQ_STUCK
If stuck, review Class 10 Hindi textbook's "Premchand" introduction chapter (typically in *Kshitij* or *Sparsh*) for his biography and the "Hindi Kahani ka Vikas" timeline.

## WORKED_EXAMPLE_1
PROBLEM: A student reads the opening paragraph of "Shatranj ke Khiladi" (provided in textbook) and sees only "two friends playing chess." Using context, explain how to read this as the *thesis statement* of the entire story.

STEPS:
- Step 1: Identify the given — the opening describes Mir and Roshan as "jagirdars" with "no work," playing chess from morning to night in a "dark room" while "the world changes outside."
- Step 2: Recall context — 1856 Awadh: jagirdars *lost* real power to British revenue settlements; 1924 India: landed elites disengaged from Non-Cooperation Movement.
- Step 3: Apply the "allegorical realism" concept — the "dark room" = feudal insulation; "world changes" = colonial modernity + nationalist awakening; chess = ritualized displacement of agency.
- Step 4: Analyze the syntax — Premchand uses *present continuous* ("khel rahe the") for a past event, collapsing 1856 into 1924 into "now."
- Step 5: Formulate thesis — The opening isn't scene-setting; it's a *diagnosis*: a class so addicted to symbolic conflict (chess) that it ignores material collapse (annexation).
- Step 6: Verify — Later, when Mir says "shatranj mein kya hai, ek baazi hi to hai" (chess is just a game), the irony is structural: he treats annexation as "just a move."

REASONING: This models the "context-first" reading protocol: every textual detail is a contextual code. The 6 steps move from textual evidence → historical knowledge → conceptual framework → linguistic analysis → thematic synthesis → forward validation.

ANSWER: The opening paragraph functions as the story's thesis: feudal aristocracy (Mir/Roshan) has replaced political action with aestheticized ritual (chess), enabling colonial takeover (British) — a pattern Premchand saw repeating in 1920s elite politics.

## WORKED_EXAMPLE_2
PROBLEM: The textbook's "Before You Read" section quotes Premchand's 1936 speech: "Literature is the mirror of society... it creates a new civilization." Using this, explain why *Shatranj ke Khiladi* has *no positive character* — not even the British.

STEPS:
- Step 1: Identify the quote's claim — literature doesn't just reflect; it *constructs* a new moral order by exposing the old.
- Step 2: Map to 1924 context — Premchand disillusioned with both *moderates* (elite petitioners = Mir/Roshan) and *extremists* (violent nationalists = not in story but implied in 1857 shadow).
- Step 3: Analyze character vacuum — No "hero" because Premchand refuses the *reformist* template (good Indian vs. bad British). The British officer (Captain Weston) is polite, cultured — *more* dangerous than a villain.
- Step 4: Connect to literary innovation — This "negative capability" (no moral center) is the *formal equivalent* of the historical situation: 1856 had no savior; 1924 had no clear path.
- Step 5: Synthesize — The absence of a positive character *is* the new civilization Premchand builds: a literature that refuses comfort, forcing the reader to *become* the conscience.

REASONING: This demonstrates how authorial theory (the quote) + historical moment (1924) + textual evidence (character design) combine to explain a formal choice that confuses students expecting a "hero."

ANSWER: Premchand omits a positive character because his 1924 conviction was that *both* feudal complacency and colonial "benevolence" were obstacles to genuine modernity; the story's moral vacuum forces the reader to occupy the ethical space the characters abandon.

## WORKED_EXAMPLE_3
PROBLEM: A board exam question asks: "How does Premchand use the historical setting of 1856 to comment on the political situation of 1924? Give three textual evidences." Construct a 4-point answer using PEEL structure.

STEPS:
- Step 1: **Point** — Premchand uses 1856 as an *allegorical mirror* for 1924: the chess-obsessed nobles = 1920s elite indifferent to mass mobilization; the "polite" British annexation = Montagu-Chelmsford "reforms" masking control.
- Step 2: **Evidence 1** — Text: "Wajid Ali Shah... ka shauk sirf shatranj tha" (Nawab's only passion was chess). Context: 1924 *zamindars* focused on cultural patronage (e.g., Hindi Sahitya Sammelan) while peasants joined Non-Cooperation.
- Step 3: **Evidence 2** — Text: British Resident says "hum aapki madad karna chahte hain" (we want to help you) while positioning troops. Context: 1919 Government of India Act "transferred subjects" to Indians but kept "reserved subjects" (police, revenue) with British.
- Step 4: **Evidence 3** — Text: Mir kills Roshan in a chess dispute, not fighting British. Context: 1920s communal tensions (e.g., 1923-24 riots) distracted nationalists from anti-colonial unity — internecine conflict serving imperial interests.
- Step 5: **Explanation** — Each evidence shows *structural parallel*, not analogy: the *logic* of displacement (chess for politics, culture for resistance, internal feud for anti-colonial war) is identical across 1856 and 1924.
- Step 6: **Link** — Therefore, the historical setting is not "background" but *argument*: Premchand proves history repeats as farce when classes fail to learn.

REASONING: This models the exact board-exam competency: "textual evidence + contextual reasoning + conceptual link." The 6 steps enforce the PEEL discipline (Point, Evidence, Explanation, Link) with the added senior-secondary demand of *structural* (not superficial) comparison.

ANSWER: Premchand's 1856 setting functions as a diagnostic allegory for 1924. (1) Nawab's chess obsession mirrors 1920s elite culturalism replacing political action — "Wajid Ali Shah ka shauk sirf shatranj tha." (2) British "friendly annexation" mirrors Montagu-Chelmsford reforms — Resident's "hum aapki madad karna chahte hain" masks troop deployment. (3) Mir killing Roshan over chess mirrors 1920s communal riots diverting anti-colonial energy. In each case, the *displacement mechanism* (ritual substituting for reality) is structurally identical, proving Premchand's thesis: a society that aestheticizes power loses it.

## COMPETENCY_QUESTION_1
QUESTION: "Premchand could have written a story about the 1857 Revolt (heroic, nationalist). Instead, he wrote about 1856 (decadent, static). Using the concept of 'literary strategy under censorship,' explain this choice in 4 sentences."

COMPETENCY
Historical empathy + authorial intention analysis

STEPS:
- Step 1: Acknowledge the censorship constraint — direct anti-colonial writing risked ban/imprisonment (Premchand was a govt employee).
- Step 2: Identify the strategic displacement — 1856 allows critique of *both* British (annexation) and Indians (complicity) without naming 1920s actors.
- Step 3: Explain the thematic payoff — 1856 shows the *root cause* (feudal paralysis) that made 1857 inevitable but doomed; this warns 1924 elites.
- Step 4: Conclude — The "static" setting is actually *dynamite*: it exposes the pre-condition of failure, which a heroic 1857 story would obscure.

ANSWER: Premchand chose 1856 over 1857 because colonial censorship permitted historical critique but banned contemporary polemic; the 1856 setting let him diagnose the *internal* rot (feudal addiction to ritual/chess) that invited external conquest, a diagnosis urgently relevant to 1924 elites disengaged from mass movements; a heroic 1857 story would have offered false comfort, while the static 1856 portrait forces recognition that *preparation* for freedom requires abandoning aristocratic self-absorption; thus, the "uneventful" year becomes the most politically explosive choice.

DIFFICULTY
medium

## COMPETENCY_QUESTION_2
QUESTION: "The story's chess metaphor operates at three levels: psychological (characters), sociological (class), and geopolitical (empire). Select ONE level and trace its development across the story's beginning, middle, and end using specific plot points (do not quote)."

COMPETENCY
Multi-level textual analysis + structural tracing

STEPS:
- Step 1: Choose sociological level (class) — most accessible for tracing.
- Step 2: Beginning — Mir/Roshan's chess is *leisure of privilege*; they ignore villagers' suffering (tax collectors, flood), showing class insulation.
- Step 3: Middle — Company's chess: Resident uses "rules" (treaty, law) to checkmate Nawab; Mir/Roshan remain oblivious, playing *their* game while *real* game (power) is decided elsewhere.
- Step 4: End — Mir kills Roshan over a chess move; simultaneously, the *real* checkmate completes (annexation). The class's internal violence (feudal fracture) mirrors its external erasure.
- Step 5: Synthesize — Chess begins as class *pastime*, becomes class *blindness*, ends as class *suicide*.

ANSWER: At the sociological level, chess traces the *ashraf* class's trajectory: (Beginning) It is their exclusive privilege — they play while peasants starve, establishing class autonomy as moral vacuity. (Middle) It becomes their epistemological blindspot — they analyze chess positions with scholarly rigor while the British Resident checkmates their sovereign using diplomatic "moves" they cannot read. (End) It turns into their fratricidal endgame — Mir murders Roshan over a disputed move *at the exact moment* the kingdom is annexed, proving the class destroyed itself by mistaking symbolic conflict for real power. The metaphor thus structures the class's historical arc from insulation to blindness to self-annihilation.

DIFFICULTY
hard