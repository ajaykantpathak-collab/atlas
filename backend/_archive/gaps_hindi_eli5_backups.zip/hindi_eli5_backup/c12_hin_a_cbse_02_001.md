## DEFINITION
"Before You Read: Context and Background" is a preparatory section that provides essential biographical, historical, and literary information about the author (फुज्क्यक/निराला) and the socio-cultural milieu of the chapter, enabling students to situate the text within its creative and ideological framework before engaging with the poem "लजकस्त ले`फर".

## COGNITIVE_LEVEL
understand

## MASTERY_CRITERIA
The student can independently explain how फुज्क्यक's life experiences (early parental loss, financial hardship, Kolkata years) shaped his poetic voice, and can identify at least three features of his literary style (language range, thematic preoccupations, form experimentation) that will appear in the prescribed poem.

## SCOPE_BOUNDARY
This node covers ONLY the author's biography up to 1961, the literary-historical context of Chhayavad and post-Chhayavad Hindi poetry, and the specific background of the poem "लजकस्त ले`फर". It does NOT include line-by-line analysis, poetic device identification, or thematic interpretation — those belong to subsequent nodes (c12_hin_a_cbse_02_002 through c12_hin_a_cbse_02_009).

## WALKTHROUGH
Imagine you are about to watch a film but the director gives you a 2-minute prelude: "This story was written by a man who lost his mother at 12, his father at 20, his wife at 35, and died alone in a Kolkata boarding house — yet his poems celebrate life's fleeting beauty." That prelude is this node. Start by reading the NCERT introductory pages (pp. 8–11) aloud, noting every proper noun (places, magazines, people). Circle the three tragedies that recur: maternal loss, conjugal loss, rootlessness. Ask: "Which of these would make a poet write about a father grieving a young daughter?" That question bridges biography to the poem's central situation. The key insight: फुज्क्यक transforms personal grief into universal human experience through deliberate artistic craft — not raw emotion alone.

## DIAGNOSTIC_QUESTION_1
Identify the three major personal losses फुज्क्यक suffered before age 40, and state the year his first published poem "तवघ्र की दह" appeared.

## DIAGNOSTIC_ANSWER_1
Correct answer: Mother's death (1918), father's death (shortly after), wife's death (year not specified in intro but implied early 1920s); first poem published in 1916. A wrong answer (e.g., "only mother died" or "first poem in 1922") reveals the student has not distinguished between life events and literary milestones, confusing chronological order — a critical error for tracing artistic development in board answers.

## DIAGNOSTIC_QUESTION_2
Explain in your own words why the NCERT introduction mentions फुज्क्यक's editorship of "लेउो;" (1922) and "एरोक्यक" (1923–24) alongside his creative writing.

## DIAGNOSTIC_ANSWER_2
Correct answer: These editorial roles placed him at the center of the Hindi literary public sphere, exposing him to contemporary debates (Chhayavad vs. pragativad), expanding his linguistic repertoire, and forcing disciplined engagement with language — all of which refined his poetic craft. A wrong answer ("just jobs he did") misses the causative link between editorial work and poetic innovation, a connection explicitly tested in CBSE "author's contribution to literature" long-answer questions.

## DIAGNOSTIC_QUESTION_3
The introduction states: "फुज्क्यक की काव्य-भाषा के विविध रूप और स्तर हैं।" Give ONE concrete example from the text of this linguistic range, naming the specific work and the register used.

## DIAGNOSTIC_ANSWER_3
Correct answer: "राम की शक्ति पूजा" uses highly Sanskritised, classical register (तत्सम-प्रधान), while "कुकुरमुत्ता" employs colloquial, rustic Avadhi/Bhojpuri-inflected Hindi (देशज-प्रधान). A student who cannot name a specific work and its register has not internalised the evidence-based claim — a gap that leads to vague, unsupported statements in board exams like "he used many styles."

## DIAGNOSTIC_QUESTION_4
Compare फुज्क्यक's thematic preoccupations as listed in the introduction (Indian history, mythology, contemporary life, existential questions) with the typical Chhayavad concerns (nature, love, mysticism, individualism). What does this comparison reveal about his poetic evolution?

## DIAGNOSTIC_ANSWER_4
Correct answer: फुज्क्यक begins within Chhayavad (early poems like "तवघ्र की दह") but expands beyond its self-centred lyricism to engage collective history ("राम की शक्ति पूजा"), social satire ("कुकुरमुत्ता"), and metaphysical inquiry ("सरोज-स्मृति"). This shows a trajectory from subjective romanticism to objective humanism — a paradigm shift examiners expect students to articulate in "development of poet's consciousness" questions.

## DIAGNOSTIC_QUESTION_5
Evaluate the claim: "फुज्क्यक की कविताओं में भारतीय ग्रामीण जीवन का चित्रण केवल भावुकता के लिए है, यथार्थपरक नहीं।" Use evidence from the introduction to support your judgment.

## DIAGNOSTIC_ANSWER_5
Correct evaluation: The claim is false. The introduction explicitly states: "भारतीय ग्रामीण जीवन से उनका लगाव उनकी अनेक कविताओं में व्यक्त हुआ है" and links it to "आधुनिक जीवन के विभिन्न पहलुओं का चित्रण" — indicating documentary realism alongside emotional resonance. Works like "कुकुरमुत्ता" satirise rural power structures. A student agreeing with the claim confuses Chhayavad's general tendency with फुज्क्यक's specific practice, losing marks for textual evidence.

## DIAGNOSTIC_QUESTION_6
Using only the biographical details in the introduction, draft a 4-line Hindi poem (any metre) that फुज्क्यक *might* have written in 1925, reflecting his then circumstances. Incorporate at least two proper nouns from the text.

## DIAGNOSTIC_ANSWER_6
Expected criteria: Poem must reference (a) Kolkata (बय्गककन) or a magazine (लेउो;/एरोक्यक), (b) personal loss (mother/wife), (c) use first-person voice, (d) show awareness of literary labour. Example: "बय्गककन की धुंध में लेउो; का संपादक / माँ-पत्नी की स्मृति लिए बैठा अकेला / शब्द तराशता हूँ, नहीं कोई सहारा / यही मेरी पूजा, यही मेरा खेला।" A poor answer (generic nature imagery, no biographical anchors) shows the student cannot synthesise life-text connections — the core skill for "creative response" board questions.

## COMMON_MISCONCEPTION
Students treat "Before You Read" as optional background reading rather than examinable content. They memorise the poet's birth/death years but cannot explain *how* the 1918 maternal death connects to the mother-figure in "सरोज-स्मृति" or the grieving father in "लजकस्त ले`फर". The NCERT introduction is not decorative — every detail (magazine names, places, family deaths) is a potential exam hook for "contextualise the poem" or "author's life and work" questions.

## ON_FAILURE
Step 1: Re-read pp. 8–11 with a highlighter. Mark every date, place, person, and work title in three colours: LIFE (red), LITERARY CAREER (blue), STYLE/THEME (green). Step 2: Create a two-column table: LEFT column = biographical fact; RIGHT column = probable textual manifestation (e.g., "wife's death" → "poems addressing absence/loss"). Step 3: Orally explain the table to a peer/teacher without notes. Step 4: Attempt Diagnostic Questions 2 and 4 again — they test the life-work synthesis most students miss.

## BUILDS_ON
Class 11 Hindi Antra Chapter 1 "Before You Read" (c11_hin_ar_cbse_01_001) where students first encountered author-context framing for literary texts.

## LEADS_TO
c12_hin_a_cbse_02_002 (Text: Plot and Narrative Structure) — the biographical-contextual lens established here will be applied to analyse the poem's narrative arc.

## PREREQUISITE_NODE_IDS
c11_hin_ar_cbse_01_001, c11_hin_ar_cbse_02_001, c11_hin_ar_cbse_03_001, c11_hin_ar_cbse_04_001, c11_hin_ar_cbse_05_001, c11_hin_ar_cbse_06_001, c11_hin_ar_cbse_07_001, c11_hin_ar_cbse_08_001, c11_hin_ar_cbse_09_001, c11_hin_ar_cbse_10_001, c11_hin_ar_cbse_11_001, c11_hin_ar_cbse_12_001, c11_hin_ar_cbse_13_001, c11_hin_ar_cbse_14_001, c11_hin_ar_cbse_15_001, c11_hin_ar_cbse_16_001, c11_hin_v_cbse_01_001, c11_hin_v_cbse_02_001, c11_hin_v_cbse_03_001, c11_hin_v_cbse_04_001, c11_hin_v_cbse_05_001
## PREREQUISITE_REASONS
c11_hin_ar_cbse_01_001: Established the "Before You Read" pedagogical pattern — students know to expect biographical/historical framing.
c11_hin_ar_cbse_02_001: Reinforced context-first approach across multiple Class 11 chapters.
c11_hin_ar_cbse_03_001: Built habit of linking author's life to textual concerns.
c11_hin_ar_cbse_04_001: Practised identifying literary movements (Chhayavad, Pragativad) in author introductions.
c11_hin_ar_cbse_05_001: Developed skill of extracting examinable details from introductory notes.
c11_hin_ar_cbse_06_001: Learnt to distinguish between author's life events and literary output chronology.
c11_hin_ar_cbse_07_001: Practised noting language/register variations mentioned in introductions.
c11_hin_ar_cbse_08_001: Internalised that "Before You Read" content appears in board exam long-answer questions.
c11_hin_ar_cbse_09_001: Gained experience connecting biographical trauma to poetic themes.
c11_hin_ar_cbse_10_001: Practised using introduction to predict poem's tone and subject.
c11_hin_ar_cbse_11_001: Learnt to identify editorial/literary-journal roles as formative influences.
c11_hin_ar_cbse_12_001: Developed note-making strategy for introductory sections.
c11_hin_ar_cbse_13_001: Practised framing "author's contribution" answers using introductory data.
c11_hin_ar_cbse_14_001: Reinforced that proper nouns (places, magazines, people) are high-yield exam material.
c11_hin_ar_cbse_15_001: Built stamina for reading dense Hindi literary prose in introductions.
c11_hin_ar_cbse_16_001: Consolidated all above skills across full Class 11 Antra textbook.
c11_hin_v_cbse_01_001: Parallel exposure to "Before You Read" in Vitan (prose) strengthened cross-genre transfer.
c11_hin_v_cbse_02_001: Reinforced context-first reading for non-fiction prose.
c11_hin_v_cbse_03_001: Practised linking author's professional life to writing style.
c11_hin_v_cbse_04_001: Developed skill of identifying socio-historical context in introductions.
c11_hin_v_cbse_05_001: Completed full Class 11 Hindi core curriculum — ready for Class 12 depth.

## FORWARD_NODE_IDS
c12_hin_a_cbse_02_002, c12_hin_a_cbse_02_003, c12_hin_a_cbse_02_004, c12_hin_a_cbse_02_005, c12_hin_a_cbse_02_006, c12_hin_a_cbse_02_007, c12_hin_a_cbse_02_008, c12_hin_a_cbse_02_009, c12_hin_a_cbse_02_013

## FORWARD_REASONS
c12_hin_a_cbse_02_002: Narrative structure analysis requires knowing the poet's intent (biography → craft).
c12_hin_a_cbse_02_003: Setting/atmosphere in the poem reflects Kolkata years and rural roots (from intro).
c12_hin_a_cbse_02_004: Protagonist (grieving father) mirrors फुज्क्यक's own paternal loss experience.
c12_hin_a_cbse_02_005: Supporting characters (mother-figure, daughter) connect to poet's maternal/conjugal loss.
c12_hin_a_cbse_02_006: Primary theme (grief, memory, transcendence) rooted in biographical tragedies.
c12_hin_a_cbse_02_007: Secondary themes (social ritual, gender, mortality) link to "Indian life portrayal" in intro.
c12_hin_a_cbse_02_008: Imagery/metaphor analysis needs the "language range" context (Sanskritised vs. colloquial).
c12_hin_a_cbse_02_009: Irony/symbolism detection requires knowing the poet's satirical works (कुकुरमुत्ता etc.).
c12_hin_a_cbse_02_013: Provides biographical/historical context essential for interpreting autobiographical elements.  

## CROSS_SUBJECT_PREREQS
c11_hin_ar_cbse_01_001, c11_hin_ar_cbse_02_001
## CROSS_SUBJECT_REASONS
c11_hin_ar_cbse_01_001: Established the transferable skill of "context-first reading" applicable to History (source context), Economics (policy context), and Political Science (constitutional context).
c11_hin_ar_cbse_02_001: Reinforced that introductory apparatus in *any* textbook (NCERT History themes, Economics chapters) serves the same pedagogical function — a meta-cognitive skill.

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_16_001 -> c12_hin_a_cbse_02_001 -> c12_hin_a_cbse_02_002 (Class 11 context-reading mastery enables Class 12 author-study depth which enables poem-level structural analysis)

## THIS_FORMULA
N/A - conceptual

## FORMULA_VARIABLES
N/A

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
conceptual

## CROSS_SUBJECT
N/A | Both require situating a primary source (poem/artefact) within its creator's life and historical moment — the "contextualisation" competency is identical.
 N/A | Just as फुज्क्यक's editorial work shaped his poetry, Nehruvian policy context shapes economic data interpretation — background knowledge determines analytical lens.
 N/A | The poet's engagement with "Indian history and mythology" parallels the Constitution's engagement with civilisational heritage — both negotiate tradition/modernity.
## PREREQ_CONCEPT
Author-context framing: the principle that biographical, historical, and professional details provided before a text are deliberate pedagogical scaffolds for interpretation.

## PREREQ_BEFORE
Student must be able to independently extract 5+ examinable facts from a textbook introduction and articulate one life-work connection hypothesis.

## PREREQ_STUCK
If unable to list 5 facts from pp. 8–11 in 3 minutes, revisit Class 11 "Before You Read" note-making drill (c11_hin_ar_cbse_08_001) and redo the two-column table exercise in ON_FAILURE.

## WORKED_EXAMPLE_1
PROBLEM: A CBSE 2023 sample paper asks: "फुज्क्यक के व्यक्तिगत जीवन की त्रासदियों ने उनकी काव्य-भाषा और विषय-वस्तु को कैसे प्रभावित किया? 'लजकस्त ले`फर' के संदर्भ में स्पष्ट कीजिए।" Use only the NCERT introduction (pp. 8–11) to outline a 6-mark answer structure.
STEPS:
- Step 1: List three biographical tragedies from intro (mother 1918, father/brother/sister shortly after, wife early 1920s) — these are the "given".
- Step 2: Identify two linguistic consequences stated in intro: (a) range from Sanskritised to colloquial, (b) "भाषा का सौन्दर्य, शब्दों की सार्थकता और अर्थ की गहनता" — these are the "effects on language".
- Step 3: Identify three thematic consequences: (a) "भारतीय इतिहास, पुराण और समसामयिक जीवन", (b) "आधुनिक जीवन के विभिन्न पहलुओं का चित्रण", (c) "मानवीय संवेदना के विविध रूप" — effects on subject matter.
- Step 4: Map to "लजकस्त ले`फर": grieving father = poet's own paternal role (implied); mother-memory = poet's maternal loss; ritual critique = "समाज से संबंध" awareness from intro.
- Step 5: Structure answer: Opening thesis (biography → art), 3 body paragraphs (language range, thematic expansion, specific poem links), concluding sentence (universalisation of personal grief).
REASONING: Board marking schemes reward explicit "introduction → poem" mapping. The intro is not background — it is evidence. Steps 1–3 mine evidence; Step 4 applies it; Step 5 packages for examiner.
ANSWER: Thesis: फुज्क्यक की व्यक्तिगत त्रासदियाँ (माता-पिता-पत्नी का निधन) उनकी काव्य-भाषा को द्विध्रुवीय (तत्सम-प्रधान से देशज-प्रधान तक) और विषय-वस्तु को व्यक्तिगत से सामाजिक-दार्शनिक बनाती हैं। 'लजकस्त ले`फर' में पिता का शोक कवि के अपने शोक का कलात्मक रूपान्तरण है — माँ की स्मृति (पंक्ति: "एक ही मेरी पहली सृष्टि") कवि की मातृ-शून्यता का प्रतिबिम्ब है, और सामाजिक कर्मकांड पर प्रश्न ("क्या कहें यहाँ, जो नहीं कहा") कवि की "समाज से संबंध" दृष्टि का विस्तार है।

## WORKED_EXAMPLE_2
PROBLEM: A student writes in a practice test: "फुज्क्यक छायावादी कवि थे इसलिए उनकी कविताओं में प्रकृति और प्रेम ही मुख्य विषय हैं।" Using the NCERT introduction, correct this misconception in a 3-sentence teacher feedback comment.
STEPS:
- Step 1: Locate the introductory claim: "फुज्क्यक की प्रमुख काव्य कृतियाँ हैं — इफजेय, क्षफरदक, वुकफेदक, रुचयह्न्कल..." — note the titles indicate thematic diversity beyond nature/love.
- Step 2: Locate the explicit thematic list: "भारतीय इतिहास, पुराण और समसामयिक जीवन का सांगोपांग चित्रण" and "आधुनिक जीवन के विभिन्न पहलुओं का चित्रण" — direct contradiction to "only nature/love".
- Step 3: Locate the stylistic range statement: "राम की शक्ति पूजा में संस्कृतनिष्ठ भाषा... कुकुरमुत्ता में देशज भाषा" — proves formal experimentation beyond Chhayavad lyricism.
- Step 4: Synthesise correction: Acknowledge Chhayavad origin, then cite intro evidence for evolution beyond it.
- Step 5: Phrase as constructive feedback referencing specific page lines.
REASONING: The intro explicitly positions फुज्क्यक as *transcending* Chhayavad. Students who stop at "Chhayavad poet" ignore the textbook's own framing — a self-penalising error.
ANSWER: "You correctly identify फुज्क्यक's Chhayavad beginnings (पृष्ठ 8: 'तवघ्र की दह' 1916), but the introduction explicitly states he moved beyond it: his major works engage 'भारतीय इतिहास, पुराण, समसामयिक जीवन' (पृष्ठ 9) and his language ranges from 'राम की शक्ति पूजा' की संस्कृतनिष्ठा to 'कुकुरमुत्ता' की देशजता (पृष्ठ 9). Please re-read pp. 8–9 and note the trajectory: Chhayavad → Pragativad → Experimental humanism."

## WORKED_EXAMPLE_3
PROBLEM: Integrate the NCERT introduction with a History Chapter 1 (Bricks, Beads and Bones) insight: both the Harappan civilisation and फुज्क्यक's poetry use "material culture" (objects, rituals, language) to reconstruct inner life. Write a 150-word comparative paragraph for an interdisciplinary project.
STEPS:
- Step 1: From History: Harappan seals, weights, pottery = material proxies for trade, authority, daily life (no deciphered script).
- Step 2: From Hindi intro: फुज्क्यक's "भाषा का सौन्दर्य, शब्दों की सार्थकता", "कर्मकांड", "ग्रामीण जीवन" = linguistic/ritual proxies for grief, memory, social structure.
- Step 3: Identify shared method: both use *formal patterns* (standardised weights / metrical regularity) to encode *human meaning* (economic trust / emotional truth).
- Step 4: Identify shared limitation: both require interpretive frameworks (archaeology / literary criticism) — neither is transparent.
- Step 5: Draft paragraph using comparative connectives (similarly, whereas, both...).
- Step 6: Verify word count and disciplinary vocabulary (material culture, proxy, encode, framework).
REASONING: NEP 2020 encourages cross-disciplinary thinking. This exercise trains students to see "contextualisation" as a universal academic move, not just a Hindi skill.
ANSWER: "हड़प्पा सभ्यता की मुहरें, बाट-बर्तन और फुज्क्यक की कविताओं की भाषिक संरचनाएँ — दोनों 'भौतिक संस्कृति' के अवशेष हैं जिनसे आंतरिक जीवन पुनर्निर्मित होता है। हड़प्पा के मानकीकृत बाट व्यापारिक विश्वास को सांकेतिक करते हैं; फुज्क्यक की द्विध्रुवीय भाषा (तत्सम-देशज) शोक और व्यंग्य को सांकेतिक करती है। दोनों में 'रूप' (form) 'अर्थ' (meaning) का वाहक है: मुहरों के पशु-चित्र प्रतीकात्मक सत्ता दर्शाते हैं, 'लजकस्त ले`फर' की माँ-मूर्ति स्मृति की सत्ता। अंतर यह: पुरातत्व मौन साक्ष्य पढ़ता है, साहित्य वाचाल साक्ष्य। फिर भी, दोनों अनुशासन 'संदर्भ-निर्भर व्याख्या' (context-dependent interpretation) की मांग करते हैं — यही अंतःविषयक पुल है।"

## COMPETENCY_QUESTION_1
QUESTION: The NCERT introduction states: "फुज्क्यक ने भारतीय इतिहास, पुराण और समसामयिक जीवन का सांगोपांग चित्रण किया है।" A Class 12 student claims this makes फुज्क्यक a "historian-poet". Evaluate this label using ONLY the introduction. In your answer, (a) define what "historian-poet" would mean, (b) cite two pieces of evidence supporting the label, (c) cite one piece of evidence complicating it, (d) give your reasoned verdict.
COMPETENCY: Critical thinking - evidence-based claim evaluation with nuanced judgment
STEPS:
- Step 1: Define "historian-poet" as one who uses poetic form to investigate, interpret, and represent historical processes — not merely reference them.
- Step 2: Evidence FOR: (i) "राम की शक्ति पूजा" reimagines epic moment as psychological crisis; (ii) "कुकुरमुत्ता" satirises feudal power structures as historical phenomenon.
- Step 3: Evidence AGAINST: Introduction emphasizes "मानवीय संवेदना के विविध रूप" and "आत्मानुभूति" — the primary lens is subjective experience, not historical analysis.
- Step 4: Verdict: "Historian-poet" is partially apt but reductive; "humanist-poet engaging history" is more precise per the intro's own phrasing.
ANSWER: (a) A historian-poet treats the past as an analytical field, using poetry to argue about causality, structure, or contingency — not just as backdrop. (b) Support: "राम की शक्ति पूजा" transforms a Puranic episode into a study of moral agency under duress; "कुकुरमुत्ता" uses a fungal metaphor to expose zamindari oppression as systemic. (c) Complication: The intro repeatedly centres "आत्मानुभूति", "व्यक्तिगत पीड़ा", "मानवीय संवेदना" — the poetic 'I' remains the organising consciousness, not a historical subject. (d) Verdict: The label captures his *range* but misses his *method* — he historicises the self rather than poeticising history. Better: "a poet who makes history intimate."
DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: Design a 5-minute classroom activity for Class 12 students who have read only the NCERT introduction (pp. 8–11) and have NOT yet read "लजकस्त ले`फर". The activity must (a) activate prior knowledge from Class 11 "Before You Read" nodes, (b) generate three testable hypotheses about the poem's content/form, and (c) include a peer-assessment rubric with two criteria. Provide the activity instructions, hypothesis template, and rubric.
COMPETENCY: Pedagogical design - creating scaffolded pre-reading tasks with metacognitive assessment
STEPS:
- Step 1: Activity name: "Biography → Poem Prediction Carousel". Time: 5 min. Group size: 4.
- Step 2: Each student gets one intro fact-card (e.g., "Mother died 1918", "Edited लेउो; 1922", "Wrote कुकुरमुत्ता"). They silently write one poem prediction on a shared sheet (2 min).
- Step 3: Sheet rotates; each student adds a second prediction building on previous (1.5 min).
- Step 4: Group selects top 3 hypotheses using rubric (1.5 min).
- Step 5: Hypothesis template: "Because [intro fact], the poem will likely [specific formal/thematic feature]."
- Step 6: Rubric: Criterion 1 — "Textual anchoring: Does hypothesis cite exact intro detail?" (Yes/Partial/No). Criterion 2 — "Specificity: Does hypothesis predict a *particular* device/theme (not vague 'sadness')?" (Yes/Partial/No).
ANSWER: Activity: "Biography → Poem Prediction Carousel". Materials: 4 fact-cards per group (cut from intro), 1 A4 sheet per group, rubric cards. Procedure: (1) Distribute cards. (2) Silent write: 1 prediction each. (3) Rotate sheet clockwise; add 1 prediction extending peer's idea. (4) Repeat till 3 rotations. (5) Group discussion: select 3 strongest using rubric. Hypothesis Template: "क्योंकि [परिचय तथ्य: जैसे 'पत्नी का निधन'], कविता में संभवतः [विशिष्ट विशेषता: जैसे 'प्रथम-व्यक्ति संबोधन में अनुपस्थिति का भाव' या 'अनुष्टुप छंद में शोक-गीत संरचना'] होगी।" Rubric: (1) पाठ-आधारितता: परिचय के सटीक शब्द/तथ्य का उद्धरण? (2) विशिष्टता: सामान्य 'दुःख' नहीं, विशेष शिल्प/विषय का पूर्वानुमान?
DIFFICULTY: hard