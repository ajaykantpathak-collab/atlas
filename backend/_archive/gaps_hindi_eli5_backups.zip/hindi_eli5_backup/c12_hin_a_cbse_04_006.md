## DEFINITION
The primary theme of a literary work is its central, unifying idea — the profound insight about life, human nature, or society that the text explores through its narrative elements. In poetry, the theme emerges from the interplay of imagery, tone, structure, and language, not merely from the subject matter. The message is the poet's specific stance or appeal arising from that theme.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student can (1) articulate the primary theme of 'cukjl' in a precise thematic statement (not a topic), (2) cite at least three distinct textual evidences from different stanzas supporting that theme, and (3) explain how the poem's progression from concrete imagery to abstract realization constructs the theme.

## SCOPE_BOUNDARY
This node covers ONLY the identification and analysis of the PRIMARY theme and message of the poem 'cukjl' (चुकजल) by Ashok Vajpeyi. It does NOT cover secondary themes (node 007), literary devices in isolation (nodes 008-009), vocabulary (010), grammar (011), or comprehension questions (012). It assumes plot, setting, and character analyses (nodes 001-005) are already mastered.

## WALKTHROUGH
Imagine you visit a village pond in peak summer — the water has receded, leaving cracked mud, stranded fish gasping, and an eerie silence where frogs once croaked. That visceral experience of witnessing life retreat is exactly where this poem begins. Start by re-reading the poem aloud, noticing how the first stanza presents the pond's physical decay ('olar dk vkxeu', 'fHk[kkfj;ksa dk fupkV [kkyhiu'), then the second stanza shifts to human activity fading ('èkhjs&èkhjs pyrs gSa yksx'), and the third stanza expands to a philosophical observation ('tks gS og [kM+k gS fcuk fdlh LraHk osQ'). The key insight: the poem doesn't just describe a drying pond; it uses that concrete scene as a metaphor for the universal condition of impermanence — where existence itself is revealed as a temporary consolidation of elements that inevitably disperse. Your task is to trace this movement from the particular (the pond) to the universal (the nature of being).

## DIAGNOSTIC_QUESTION_1
What is the difference between the 'subject' (विषय) and the 'theme' (मुख्य भाव/थीम) of a poem? Give an example from 'cukjl'.

## DIAGNOSTIC_ANSWER_1
Subject is the literal topic: 'a drying pond in summer'. Theme is the abstract insight: 'the inevitable dissolution of all formed existence and the silence that follows'. A wrong answer (e.g., 'the theme is the pond drying up') reveals the student conflates plot summary with thematic abstraction — a fundamental category error that prevents analytical writing.

## DIAGNOSTIC_QUESTION_2
The poem moves from 'olar dk mrjuk' (stanza 1) to 'èkhjs&èkhjs gksuk' (stanza 3). Explain in your own words what this progression signifies about the poem's thematic architecture.

## DIAGNOSTIC_ANSWER_2
The progression signifies a movement from sensory particularity (the sound of drying mud) to existential generality (the condition of 'becoming' itself). 'Olar dk mrjuk' is the audible symptom of water leaving; 'èkhjs&èkhjs gksuk' names the ontological process of entities losing their defining boundaries. A wrong answer that only lists the two phrases without explaining the shift from concrete to abstract shows the student sees isolated images but not the poem's structural logic.

## DIAGNOSTIC_QUESTION_3
Apply the concept of 'objective correlative' (T.S. Eliot) to this poem: which specific set of images in stanza 1 functions as the objective correlative for the theme of 'irreversible loss'? Justify your selection.

## DIAGNOSTIC_ANSWER_3
The images 'fHk[kkfj;ksa dk fupkV [kkyhiu' (expansive spread of fish skeletons) and '[kkyh dVksjksa esa olar dk mrjuk' (mud cracking in dry streambeds) form the objective correlative. They are concrete, sensory, and externally observable facts that evoke the internal state of irreversible loss without naming it. A wrong answer selecting 'vpkud vkrk gS' (afternoon falls) fails because it's a temporal marker, not a visceral correlative of loss.

## DIAGNOSTIC_QUESTION_4
Analyze how the repetition of 'èkhjs&èkhjs' (stanza 3) structurally enacts the theme it describes. Consider both semantic accumulation and rhythmic effect.

## DIAGNOSTIC_ANSWER_4
The reduplication 'èkhjs&èkhjs' performs what it denotes: each repetition is a further 'loosening' of the word's fixed identity, mimicking the theme of boundaries dissolving. Semantically, it accumulates instances (people walking, birds flying, memory fading) until the category 'èkhjs&èkhjs' swallows its own content. Rhythmically, the long vowels and aspirated consonants create a slowing, exhaling cadence — the sound of things letting go. A wrong answer treating it as mere emphasis ('the poet repeats to stress') misses the performative enactment.

## DIAGNOSTIC_QUESTION_5
Evaluate this claim: 'The poem's final stanza ("viuh ,d Vk¡x ij [kM+k gS ;g 'kgj...") resolves the tension between the particular scene and the universal theme by asserting the speaker's subjective perception as the only reality.' Defend or refute with textual evidence.

## DIAGNOSTIC_ANSWER_5
Refute. The final stanza does not resolve into subjectivity; it radicalizes the theme by declaring the pond's condition IS the universal condition ('vxj è;ku ls ns[kks rks ;g vkèkk gS'). The speaker's 'Vk¡x' (gaze) is not private — it's the necessary condition for the world to reveal its true nature as 'vkèkk' (existence). The line 'vkSj vkèkk ugha gS tks ugha gS' collapses the distinction between appearance and reality. A wrong answer accepting the claim reveals a misreading of 'Vk¡x' as individual perspective rather than ontological witness.

## DIAGNOSTIC_QUESTION_6
Create a four-line poetic response (in Hindi or English) that captures the primary theme of 'cukjl' without using any imagery from the original poem. Your response must show the movement from concrete to abstract.

## DIAGNOSTIC_ANSWER_6
Example criteria: (1) Opens with a tangible, decaying image (e.g., 'Peeling paint on a shut door'), (2) Shows the process of unmaking ('Layer by layer the colour surrenders'), (3) Names the universal principle ('All form is borrowed time'), (4) Ends in the silence after unmaking ('The wall remembers only wind'). A poor response stays at the descriptive level ('The door is old and broken') or jumps to abstraction without the concrete anchor.

## COMMON_MISCONCEPTION
Students consistently write: 'The theme of the poem is the drying pond' or 'The message is that water is precious.' This error arises because they equate the poem's *setting* (the pond) with its *theme*, and they look for a moral lesson ('save water') instead of an existential insight. The poem is not *about* a pond; it *uses* a pond to reveal the structure of impermanence (अनित्यता) that governs all existence. The 'message' is not ecological — it is ontological: to see the world 'è;ku ls' (with awareness) is to see it as 'vkèkk' (pure existence) constantly shedding its forms.

## ON_FAILURE
If a student cannot distinguish subject from theme: (1) Give them three familiar texts (e.g., 'The Road Not Taken', 'Madhushala', a recent film) and ask for subject vs. theme for each. (2) Use the formula: Subject = What happens (noun phrase); Theme = What it means about [life/humanity/time] (complete sentence with abstract noun). (3) Have them re-read stanza 3 of 'cukjl' and complete: 'The pond is not just a pond; the pond is a ______ of ______.' (Answer: manifestation, impermanence). (4) Re-diagnose with DIAGNOSTIC_QUESTION_1.

## BUILDS_ON
Character Analysis: Supporting Characters (c12_hin_a_cbse_04_005) — understanding how the 'fish skeletons' and 'people' function as non-human characters whose decay enacts the theme.

## LEADS_TO
Theme: Secondary Themes (c12_hin_a_cbse_04_007) — the primary theme of impermanence branches into secondary themes of memory, perception, and language's inadequacy.

## PREREQUISITE_NODE_IDS
c12_hin_a_cbse_04_001, c12_hin_a_cbse_04_002, c12_hin_a_cbse_04_003, c12_hin_a_cbse_04_004, c12_hin_a_cbse_04_005, c11_hin_ar_cbse_01_006, c11_hin_v_cbse_01_006
## PREREQUISITE_REASONS
c12_hin_a_cbse_04_001: Context/background establishes the poet's philosophical leanings (existential imagery).
c12_hin_a_cbse_04_002: Plot/narrative structure reveals the poem's movement from scene to abstraction.
c12_hin_a_cbse_04_003: Setting/atmosphere (the drying pond) is the objective correlative for the theme.
c12_hin_a_cbse_04_004: Protagonist analysis (the speaker's gaze) determines the thematic perspective.
c12_hin_a_cbse_04_005: Supporting characters (fish, birds, people) embody the theme in concrete forms.
c11_hin_ar_cbse_01_006: Class 11 Antra theme analysis builds the skill of thematic statement formulation.
c11_hin_v_cbse_01_006: Class 11 Vitan theme analysis reinforces distinguishing subject from theme.

## FORWARD_NODE_IDS
c12_hin_a_cbse_04_007, c12_hin_a_cbse_04_008, c12_hin_a_cbse_04_009, c12_hin_a_cbse_04_013, c12_hin_a_cbse_04_014, c12_hin_a_cbse_04_015

## FORWARD_REASONS
c12_hin_a_cbse_04_007: Primary theme established here allows identification of secondary themes (memory, language) as variations.
c12_hin_a_cbse_04_008: Imagery/metaphor analysis requires knowing the theme they serve.
c12_hin_a_cbse_04_009: Irony/symbolism (e.g., 'vkèkk' as both existence and non-existence) deepens thematic reading.
c12_hin_a_cbse_04_013: Critical thinking/interpretation applies the thematic framework to open-ended analysis.
c12_hin_a_cbse_04_014: Gives primary theme to link back to in the Link step.  
c12_hin_a_cbse_04_015: Provides the primary theme (urbanization vs rural simplicity) that discussion points must explore.  

## CROSS_SUBJECT_PREREQS
c11_hin_ar_cbse_06_006, c11_hin_v_cbse_04_006
## CROSS_SUBJECT_REASONS
c11_hin_ar_cbse_06_006: Theme analysis in 'Bharat Mata' (Class 11 Antra Ch6) practices moving from national symbol to existential theme.
c11_hin_v_cbse_04_006: Theme analysis in 'Jhansi Ki Rani' (Class 11 Vitan Ch4) practices distinguishing historical subject from universal theme.

## CHAIN_DESCRIPTION
c12_hin_a_cbse_04_005 -> c12_hin_a_cbse_04_006 -> c12_hin_a_cbse_04_007

## THIS_FORMULA
N/A - conceptual

## FORMULA_VARIABLES
N/A

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
conceptual

## CROSS_SUBJECT
N/A | The poem's core insight — 'tks gS og [kM+k gS fcuk fdlh LraHk osQ' (what exists is solid without any support) — directly parallels the Buddhist concept of *pratītyasamutpāda* (dependent origination) and the Advaitic *neti neti* negation of independent substance.
 N/A | The poem's opening stanza depicts a lotic ecosystem transitioning to a lentic terminal phase; the 'fHk[kkfj;ksa dk fupkV [kkyhiu' is a precise ecological indicator of deoxygenation and habitat collapse.
 N/A | The final stanza's 'vxj è;ku ls ns[kks' (if seen with awareness) illustrates top-down processing where cognitive schema (awareness of impermanence) transforms sensory input into ontological insight.
## PREREQ_CONCEPT
Distinguishing subject (concrete topic) from theme (abstract insight) — mastered in Class 11 theme nodes.

## PREREQ_BEFORE
Student must be able to write a thematic statement for at least two Class 11 poems using the 'Subject vs. Theme' formula.

## PREREQ_STUCK
Review Class 11 Antra Chapter 1 (c11_hin_ar_cbse_01_006) worked example on thematic statement construction.

## WORKED_EXAMPLE_1
PROBLEM: Using only stanzas 1 and 2 of 'cukjl', construct the primary thematic statement of the poem following the 4-step analytical method.
STEPS:
- Step 1: Identify the concrete subject of each stanza. Stanza 1: the drying pond's sensory details (cracked mud, fish skeletons, silent afternoon). Stanza 2: the fading human/natural activity (people walking slowly, birds flying low, memory fading).
- Step 2: Abstract the action verbs and state changes. 'mrjuk' (cracking), 'Hkj mBk' (filled/settled), 'fupkV' (expansive/spread), 'pyrs' (walking/moving), 'ctrs' (flying), 'n`<+rk' (erasing/fading).
- Step 3: Find the common denominator across these changes. All describe a loss of definition, volume, sound, movement — a transition from 'formed' to 'unformed', from 'presence' to 'trace'.
- Step 4: Formulate the thematic statement using an abstract noun phrase + qualifying clause. 'The poem's primary theme is the inevitable dissolution of all structured existence into formless silence, where even memory cannot arrest the unmaking.'
REASONING: This method forces the student to move from textual evidence (steps 1-2) to pattern recognition (step 3) to abstract formulation (step 4), preventing the 'subject as theme' error.
ANSWER: Primary Theme: The inevitable dissolution of all structured existence into formless silence, where even memory cannot arrest the unmaking. Message: To perceive this dissolution with awareness ('è;ku ls') is to see reality as it is — 'vkèkk' (pure existence) without the illusion of permanent form.

## WORKED_EXAMPLE_2
PROBLEM: A student writes: 'The message of the poem is that we should protect ponds from drying up.' Diagnose the error and rewrite the answer to meet board exam standards.
STEPS:
- Step 1: Identify the error category. The student has imposed an external ecological moral on a poem that is ontological, not environmental.
- Step 2: Locate the textual evidence that contradicts the 'protection' reading. Stanza 3: 'èkhjs&èkhjs gksus dh lkewfgd y; esa D;k&D;k c¡èkk gS' — the loosening is described as a 'leap from nearness', not a tragedy to prevent. Stanza 4: 'vxj è;ku ls ns[kks rks ;g vkèkk gS' — the drying is revealed as the true nature of existence.
- Step 3: Explain why the poem resists a conservationist reading. The pond is a metaphor; saving the literal pond would miss the point that ALL forms (including the observer) are 'vkèkk' — temporarily consolidated existence.
- Step 4: Rewrite using the board exam structure: Thematic statement + 2 textual evidences + explanation of poet's stance.
REASONING: Board exams reward answers that show the poem's internal logic, not external morals. The rewrite demonstrates how to pivot from a common-sense misreading to a text-grounded thematic reading.
ANSWER: Corrected Answer: The poem's message is not ecological conservation but ontological acceptance. The drying pond ('cukjl') serves as an objective correlative for the universal condition of impermanence (अनित्यता). As the poem progresses, the speaker realizes that the 'loosening' ('èkhjs&èkhjs') of boundaries — of mud, memory, identity — is not a defect but the very structure of 'vkèkk' (existence). The message: see the world 'with awareness' ('è;ku ls') to recognize that what appears as loss is actually the revelation of formless reality.

## WORKED_EXAMPLE_3
PROBLEM: Compare the primary theme of 'cukjl' with the primary theme of 'Bharat Mata' (Class 11 Antra Ch6). Both use a concrete entity (pond / nation) as a vehicle. Analyze the difference in their thematic destination.
STEPS:
- Step 1: Recall 'Bharat Mata' primary theme (from c11_hin_ar_cbse_06_006): The nation as a living, suffering mother whose body bears the scars of history, demanding not worship but justice.
- Step 2: Recall 'cukjl' primary theme (from Worked Example 1): The inevitable dissolution of all structured existence into formless silence.
- Step 3: Identify the shared structural move: both poems take a concrete, culturally charged entity (pond in summer / Bharat Mata) and use it to access a universal insight.
- Step 4: Contrast the direction of the universal insight. 'Bharat Mata' moves OUTWARD: from the specific body to a collective ethical imperative (justice, action). 'cukjl' moves INWARD: from the specific scene to an ontological realization (awareness, seeing).
- Step 5: Analyze the role of the speaker. In 'Bharat Mata', the speaker is a witness-accuser demanding response. In 'cukjl', the speaker is a seer whose 'Vk¡x' (gaze) completes the revelation.
- Step 6: Synthesize the comparison. Both use the concrete as a gateway, but 'Bharat Mata' opens onto ethics (what we must DO), while 'cukjl' opens onto epistemology/ontology (how we must SEE).
REASONING: This cross-text comparison is a classic board exam competency (comparative thematic analysis) and a CUET/JEE-style analytical reasoning task. It tests whether the student understands theme as a structural achievement, not just a label.
ANSWER: Both poems employ a concrete entity as an objective correlative for a universal theme, but their thematic vectors diverge. 'Bharat Mata' (Class 11) uses the nation's body to generate an ethical theme: historical injustice demands active resistance. The theme is teleological — oriented toward future action. 'cukjl' uses the drying pond to generate an ontological theme: all form is temporary consolidation destined to dissolve. The theme is realizational — oriented toward present perception ('è;ku ls ns[kks'). The former calls for 'karma'; the latter calls for 'jnana'.

## COMPETENCY_QUESTION_1
QUESTION: The poem 'cukjl' is often described as a 'poem of seeing' (दर्शन की कविता). Using the distinction between 'subject' and 'theme' established in this node, explain why this description is accurate. Your answer must reference the shift in the function of the speaker's gaze from stanza 1 to stanza 4.
COMPETENCY: Literary Analysis — Thematic Interpretation with Textual Evidence
STEPS:
- Step 1: Define 'poem of seeing' in this context: a poem where the act of perception constitutes the theme.
- Step 2: Analyze stanza 1: the gaze is passive, descriptive ('vkrk gS', 'ns[kk gS') — it records the pond's decay.
- Step 3: Analyze stanza 4: the gaze becomes conditional and constitutive ('vxj è;ku ls ns[kks rks ;g vkèkk gS') — it REVEALS the true nature of the pond as 'vkèkk'.
- Step 4: Conclude: the theme (impermanence as the structure of existence) is not IN the pond; it EMERGES through the aware gaze. Hence, the poem is an enactment of seeing-as-knowing.
ANSWER: The description is accurate because the poem's primary theme — that existence ('vkèkk') is the formless reality underlying all temporary forms — is not a property of the pond but a discovery made possible only by the speaker's 'aware seeing' ('è;ku ls ns[kks'). In stanza 1, the gaze observes symptoms ('olar dk mrjuk', 'fHk[kkfj;ksa dk [kkyhiu'). In stanza 4, the same gaze, now qualified by awareness, penetrates to the ontological ground: 'tks gS og [kM+k gS fcuk fdlh LraHk osQ'. The theme is the insight that seeing-with-awareness transforms the particular (drying pond) into the universal (vkèkk). The poem thus performs its own theme: it shows how seeing creates the seen.
DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: A critic argues: 'The repetition "èkhjs&èkhjs" in stanza 3 is a poetic device showing gradual fading; the final stanza's "vkèkk" is a philosophical concept showing sudden realization. The poem fails to bridge this gap between poetic process and philosophical conclusion.' Evaluate this criticism. Does the poem's structure successfully integrate the poetic and the philosophical? Support your evaluation with a close reading of the transition between stanzas 3 and 4.
COMPETENCY: Critical Evaluation — Structural Coherence and Thematic Unity
STEPS:
- Step 1: Unpack the critic's claim: they see a disjunction between the gradual, sensory 'èkhjs&èkhjs' (poetic) and the abstract, categorical 'vkèkk' (philosophical).
- Step 2: Examine the actual textual bridge. Stanza 3 ends: 'èkhjs&èkhjs gksuk / èkhjs&èkhjs gksus dh lkewfgd y; / n`<+rk ls ck¡èks gS lewps 'kgj dks'. Stanza 4 begins: 'bls vpkud ns[kks / vn~Hkqr gS bldh cukoV / ;g vkèkk ty esa gS...'
- Step 3: Analyze the logical connector. The 'leap from nearness' ('n`<+rk ls ck¡èks') in stanza 3 IS the bridge. The 'loosening' accumulates until the pond's 'nearness' (its familiar, formed identity) snaps — and that snap REVEALS 'vkèkk'.
- Step 4: Show how the form enacts the bridge. The reduplication 'èkhjs&èkhjs' performs the loosening; the sudden declarative ';g vkèkk gS' performs the snap. The poetic device (reduplication) and the philosophical term (vkèkk) are not separate — the device ENACTS the concept.
- Step 5: Conclude the evaluation. The criticism fails because it treats 'poetic' and 'philosophical' as separate registers. The poem demonstrates that the poetic process (gradual loosening of language/forms) IS the philosophical realization (existence without support).
ANSWER: The criticism is invalid. The poem does not juxtapose poetic process and philosophical conclusion; it makes the poetic process the very means of philosophical realization. The reduplication 'èkhjs&èkhjs' in stanza 3 is not merely a device 'showing' fading — it performs the ontological loosening of boundaries that the poem identifies as the nature of 'vkèkk'. The transition 'n`<+rk ls ck¡èks gS lewps 'kgj dks' (the leap from nearness takes the pond) marks the precise moment where the accumulated poetic loosening becomes the philosophical revelation. The pond's 'nearness' (its familiar, formed self) is what must be leapt from for 'vkèkk' to appear. Stanza 4's 'bls vpkud ns[kks' (see this in the afternoon) then invites the reader to replicate that leap. The structure is seamless: the poem's form (gradual reduplication → sudden declaration) mirrors its content (gradual dissolution → sudden insight into existence). The poetic and the philosophical are co-extensive.
DIFFICULTY: hard