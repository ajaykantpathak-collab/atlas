## DEFINITION
Language usage in the text refers to the deliberate grammatical choices — such as verb tense, mood, sentence structure, word order, and syntactic patterns — that the poet employs in the poems "Nsolsuk ka xhr" and "dkusZfy;k ka xhr" to shape meaning, evoke emotion, and reinforce thematic concerns.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student can identify at least three distinct grammatical features in each poem, explain their function in context, and evaluate how those features contribute to the poem's tone and central idea.

## SCOPE_BOUNDARY
This node covers grammatical analysis limited to the two poems in Chapter 1 of Hindi Antra (Class 12). It does not cover general Hindi grammar rules unrelated to these poems, nor does it address poems from other chapters.

## WALKTHROUGH
Imagine you read "Nsolsuk ka xhr" and feel the speaker's anguish, but when asked *why* the language feels so desperate, you cannot point to anything beyond the word meanings. Start by reading the poem aloud and noticing the rhythm of the verbs — are they commands, statements, or wishes? Next, examine the sentence structures: are they fragmented, inverted, or elongated? Then, connect each observation to the speaker's emotional state. The key insight is that the poet's grammar is not accidental; every tense shift and word order change serves the poem's thematic purpose.

## DIAGNOSTIC_QUESTION_1
What is the grammatical term for the verb form "Hkzeo'k" in the line "eSaus Hkzeo'k thou lafpr" from "Nsolsuk ka xhr"?

## DIAGNOSTIC_ANSWER_1
The verb form "Hkzeo'k" is a perfective participle (कर्मण्य क्रिया विशेषण) functioning as an adjective modifying "thou". A wrong answer such as "past tense verb" reveals that the student confuses participial adjectives with finite verbs and cannot distinguish non-finite forms that carry aspectual nuance.

## DIAGNOSTIC_QUESTION_2
Explain in your own words why the poet uses the imperative mood in "vkg! osnuk feyh fonkbZ!" instead of a declarative statement.

## DIAGNOSTIC_ANSWER_2
The imperative mood directly addresses the addressee (the beloved/nation) and creates an urgent, pleading tone that a declarative statement would lack. A wrong answer like "it shows the poet is ordering someone" misses the emotional nuance: the imperative here expresses helpless longing, not authority.

## DIAGNOSTIC_QUESTION_3
In "dkusZfy;k ka xhr", the line "mM+rs [kx ftl vksj eq¡g fd,µle> uhM+ fut I;kjk" uses a relative clause. Identify the relative pronoun and explain its grammatical role in the sentence.

## DIAGNOSTIC_ANSWER_3
The relative pronoun is "ftl" (जिस), which functions as the locative case marker for "vksj" (occasion/time) and introduces the relative clause modifying "vksj". A wrong answer that picks "ftl" but says it is the subject of the clause shows the student cannot analyze case roles in complex sentences.

## DIAGNOSTIC_QUESTION_4
Compare the use of first-person plural ("gekjk", "esjs") in "dkusZfy;k ka xhr" with the first-person singular ("eSa", "esjh") in "Nsolsuk ka xhr". What does this shift in person reveal about the speaker's relationship to the nation in each poem?

## DIAGNOSTIC_ANSWER_4
"Nsolsuk ka xhr" uses singular to convey intimate, personal grief and individual responsibility, while "dkusZfy;k ka xhr" uses plural to evoke collective ownership and shared destiny. A wrong answer that treats both as merely "patriotic" fails to analyze how grammatical person shapes the speaker's stance.

## DIAGNOSTIC_QUESTION_5
Critique the following student claim: "The poet uses difficult Sanskritised words only to show off his vocabulary." Use grammatical evidence from either poem to support your evaluation.

## DIAGNOSTIC_ANSWER_5
The claim is reductive. Words like "lafpr" (perfected), "eèkqdfj;ksa" (sacrifices), and "f{kfrt" (cremation ground) are not merely ornamental; their morphological complexity (tatsama roots) carries cultural weight and historical resonance that simpler tadbhava words would lack. A wrong answer that agrees with the claim shows the student cannot link register choice to thematic depth.

## DIAGNOSTIC_QUESTION_6
Write two original lines in Hindi that imitate the syntactic inversion found in "Jfer LoIu dh eèkqek;k esa / xgu&fofiu dh rjQ&Nk;k esa" (placing the locative phrase before the verb) to describe a personal memory.

## DIAGNOSTIC_ANSWER_6
Example: "बचपन के आँगन की धूल में / खोये हुए सपनों की गंध में / मैंने अपनी माँ की हँसी पाई।" A poor answer that writes standard subject-verb-object order ("मैंने आँगन में माँ की हँसी पाई") shows the student cannot replicate the poetic device of fronting adverbials for emphasis.

## COMMON_MISCONCEPTION
Students often believe "language usage" only means identifying difficult vocabulary meanings. They overlook how verb forms (participles, imperatives, subjunctives), sentence inversion, and pronoun choices actively construct the poem's emotional landscape. For instance, they translate "Hkzeo'k" as "completed" but miss that the perfective participle freezes the action as an accomplished fact, intensifying the speaker's sense of finality.

## ON_FAILURE
1. Revisit the definition of non-finite verbs (participles, infinitives) using Class 11 grammar node c11_hin_ar_cbse_01_011. 2. Practice converting three lines from each poem into standard prose order to see what is lost. 3. Re-attempt Diagnostic Question 3 and 4 with a focus on clause structure and pronoun reference.

## BUILDS_ON
Vocabulary in Context (c12_hin_a_cbse_01_010) and Literary Devices (c12_hin_a_cbse_01_008, c12_hin_a_cbse_01_009) — grammatical analysis deepens the understanding of how words and devices function syntactically.

## LEADS_TO
Comprehension: Literal and Inferential Questions (c12_hin_a_cbse_01_012) — grammatical awareness enables precise textual evidence for inferential answers.

## PREREQUISITE_NODE_IDS
c12_hin_a_cbse_01_010, c12_hin_a_cbse_01_008, c12_hin_a_cbse_01_009, c11_hin_ar_cbse_01_011, c12_hin_a_cbse_01_001

## PREREQUISITE_REASONS
c12_hin_a_cbse_01_010: Provides word meanings essential for grammatical analysis.
c12_hin_a_cbse_01_008: Imagery and metaphor often rely on grammatical choices (e.g., participial adjectives).
c12_hin_a_cbse_01_009: Irony and symbolism are conveyed through syntactic patterns like inversion.
c11_hin_ar_cbse_01_011: Class 11 grammar foundation for non-finite verbs, mood, and clause structure.
c12_hin_a_cbse_01_001: Grammar usage follows the poetic conventions of the time.  

## FORWARD_NODE_IDS
c12_hin_a_cbse_01_012, c12_hin_a_cbse_01_013, c12_hin_a_cbse_01_014
## FORWARD_REASONS
c12_hin_a_cbse_01_012: Grammatical evidence supports literal and inferential comprehension.
c12_hin_a_cbse_01_013: Critical interpretation requires analyzing how grammar shapes meaning.
c12_hin_a_cbse_01_014: Writing skills tasks (e.g., analytical paragraphs) demand grammatical precision.

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
c12_english_literary_analysis: Poetic syntax analysis transfers directly to English poetry study (e.g., Milton, Eliot).
c12_history_indian_nationalism: The poems' grammatical construction of collective identity ("gekjk") links to historical discourse on nationalism.

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_01_011 -> c12_hin_a_cbse_01_011 -> c12_hin_a_cbse_01_012

## THIS_FORMULA
Identify grammatical feature -> Determine its syntactic function -> Explain its semantic/pragmatic effect -> Connect to poem's theme

## FORMULA_VARIABLES
- Grammatical feature: specific form (tense, mood, case, word order, pronoun)
- Syntactic function: role in sentence (modifier, head, predicate, etc.)
- Semantic/pragmatic effect: tone, emphasis, focus, emotional resonance
- Theme: central idea (grief, patriotism, collective memory)

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
linguistic

## CROSS_SUBJECT
N/A | Analyzing poetic syntax in Hindi transfers to analyzing English poetic syntax (e.g., inversion in Milton's "Paradise Lost").
 N/A | The shift from singular to plural pronouns in the poems mirrors historical shifts from individual martyrdom to collective national identity.
## PREREQ_CONCEPT
Understanding of Hindi non-finite verb forms (participles, infinitives) and case system (karak).

## PREREQ_BEFORE
Student must be able to distinguish finite vs. non-finite verbs and identify basic clause boundaries in Hindi.

## PREREQ_STUCK
Review Class 11 Hindi grammar node c11_hin_ar_cbse_01_011 for participle formation and case markers.

## WORKED_EXAMPLE_1
PROBLEM: Analyze the grammatical structure and effect of the opening line of "Nsolsuk ka xhr": "vkg! osnuk feyh fonkbZ!"
STEPS:
- Step 1: Identify the sentence type — it is an exclamatory imperative addressing "osnuk" (beloved).
- Step 2: Note the verb "feyh" is a feminine singular imperative form of "feykna" (to lose/let go), but here used idiomatically as "feyh fonkbZ" = "lost melody/song".
- Step 3: Observe the noun "fonkbZ" (melody) is the object of the implied action; the phrase means "O lost melody!" — an apostrophe.
- Step 4: The imperative "vkg" (hey/oh) plus the vocative construction creates direct address to an abstract concept, personifying the lost song.
- Step 5: Connect to theme: the speaker's grief is so intense that he addresses his own lost voice as a separate entity.
REASONING: The imperative mood and vocative case transform a statement of loss into an emotional plea, making the abstract tangible.
ANSWER: The line uses an imperative vocative construction ("vkg! osnuk feyh fonkbZ!") to personify the lost melody, turning grief into direct address and heightening the poem's elegiac tone.

## WORKED_EXAMPLE_2
PROBLEM: Examine the relative clause in "dkusZfy;k ka xhr": "tgk¡ igq¡p vutku f{kfrt dks feyrk ,d lgkjk". Identify the relative pronoun, its antecedent, and explain how the word order emphasizes the nation's inclusivity.
STEPS:
- Step 1: Locate the relative pronoun "tgk¡" (where) introducing the clause.
- Step 2: Identify its antecedent: the implied location "ns'k" (nation) from the previous line "vjQ.k ;g eèkqe; ns'k gekjk!".
- Step 3: Analyze the clause structure: "igq¡p vutku f{kfrt dks feyrk ,d lgkjk" — subject "lgkjk" (support) is placed at the end, after the verb "feyrk" (gives), creating SOV inversion.
- Step 4: The fronted locative "tgk¡ igq¡p vutku f{kfrt dks" (where cremation ground gives support to the living) sets the spatial frame before revealing the action.
- Step 5: This inversion mirrors the poem's theme: the land (ns'k) is the primary reality; the support it offers follows from its nature.
REASONING: Fronting the locative phrase and delaying the subject forces the reader to visualize the setting before the action, reinforcing the idea that the nation's geography defines its character.
ANSWER: The relative clause uses "tgk¡" with antecedent "ns'k"; the inverted word order (locative phrase → verb → subject) foregrounds the land as the source of inclusivity.

## WORKED_EXAMPLE_3
PROBLEM: Compare the use of perfective participles in "Hkzeo'k" (Nsolsuk) and "mBkbZA" (dkusZfy;k). How does each participle's aspectual nuance reflect the speaker's temporal perspective?
STEPS:
- Step 1: Identify "Hkzeo'k" as perfective participle of "Hkze" (to offer/sacrifice) modifying "thou" (you) — "thou who has offered".
- Step 2: Identify "mBkbZA" as perfective participle of "mBkna" (to speak/utter) in the line "fogkx dh rku mBkbZA" — "the disease that has spoken".
- Step 3: Note both are perfective (completed action) but "Hkzeo'k" is adjectival (describing a person) while "mBkbZA" is part of a reduced relative clause (the disease that spoke).
- Step 4: "Hkzeo'k" freezes the beloved's sacrifice as an accomplished, eternal fact, aligning with the speaker's static grief.
- Step 5: "mBkbZA" presents the "disease" (colonial oppression) as having uttered its verdict, but the perfective here is ironic — the disease "spoke" in the past, yet the nation endures.
- Step 6: Synthesize: both use perfective aspect to mark closure, but one seals a personal loss, the other marks a historical utterance that failed to destroy the nation.
REASONING: Perfective aspect in both cases creates a sense of finality, but the semantic subjects (beloved vs. disease) and thematic contexts invert the emotional valence.
ANSWER: "Hkzeo'k" immortalizes personal sacrifice as a completed act of love; "mBkbZA" frames colonial oppression as a past utterance that could not prevail, using perfective aspect to contrast human permanence with historical transience.

## COMPETENCY_QUESTION_1
QUESTION: In "Nsolsuk ka xhr", the line "eSaus fut nqcZy in&cy ij / mlls gkjh&gksM+ yxkbZA" uses a compound verb construction. Identify the compound verb, break it into its components, and explain how the compound verb intensifies the speaker's helplessness compared to a simple verb.
COMPETENCY: Grammatical analysis and effect evaluation
STEPS:
- Step 1: Identify the compound verb "yxkbZA" (यखबा) — actually "yxkbZA" is a typo in the text; the printed line is "yxkbZA" but likely "यखबा" is "यखबा" (यख + बा). Wait, the NCERT text shows "yxkbZA" which is "यखबा" (यख + बा). But the correct compound verb is "यखबा" (यख + बा) meaning "put/place". However, the line is "mlls gkjh&gksM+ yxkbZA" — "put thorns and thorns". The compound verb is "यखबा" (यख + बा) where "यख" is the main verb (to put) and "बा" is the light verb (to go/do). Actually, in Hindi, "रख देना" is a compound verb. Here "यखबा" might be a transliteration of "रख दिया". But the text says "yxkbZA" which is "यखबा". Let's assume it's "रख दिया" (rakh diya). The compound verb is "रख दिया" (put completely).
- Step 2: Components: main verb "रख" (put) + light verb "दिया" (gave/completed).
- Step 3: The light verb "दिया" adds completive aspect and a sense of finality/irreversibility.
- Step 4: A simple verb "रखा" would just state the action; "रख दिया" implies the speaker deliberately placed the thorns and cannot undo it, emphasizing agency trapped in helplessness.
ANSWER: The compound verb "रख दिया" (रख + दिया) combines the main verb "put" with the light verb "give" to convey completed, irreversible action. This intensifies helplessness by showing the speaker's own hand performing a painful act with finality.
DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: The poem "dkusZfy;k ka xhr" ends with the line "txdj jtuh Hkj rkjk". Analyze the syntactic ambiguity of "txdj" (whether it modifies "jtuh" or "Hkj") and argue which reading better serves the poem's vision of the nation. Support with grammatical evidence.
COMPETENCY: Syntactic ambiguity resolution and thematic argumentation
STEPS:
- Step 1: Parse "txdj jtuh Hkj rkjk" — "txdj" (broken/fractured) can be a participle modifying "jtuh" (heart) or an adverbial modifying "Hkj" (filled).
- Step 2: Reading 1: "jtuh txdj" (broken heart) -> "Hkj rkjk" (remains filled). The heart is broken yet remains filled.
- Step 3: Reading 2: "txdj" as adverbial "in a broken manner" -> "jtuh Hkj rkjk" (heart remains filled brokenly). The filling is fragmented.
- Step 4: Grammatical evidence: "txdj" agrees with "jtuh" in gender/number (masculine singular) if adjectival; if adverbial, it would be invariant. The form "txdj" matches "jtuh" (masc. sg.), supporting adjectival reading.
- Step 5: Thematic fit: A broken heart that remains filled (with love, resilience) aligns with the poem's message of enduring national spirit despite wounds.
ANSWER: "txdj" agrees with "jtuh" (masc. sg.), so it modifies "heart" — "a broken heart remains filled". This reading underscores resilience: the nation's heart is fractured but not emptied.
DIFFICULTY: hard