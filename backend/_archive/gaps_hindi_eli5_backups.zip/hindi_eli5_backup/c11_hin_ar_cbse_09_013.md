## DEFINITION
Critical Thinking: Analysis and Interpretation is the systematic process of examining a literary text's layers—language, structure, context, and subtext—to uncover implicit meanings, evaluate the author's craft choices, and construct evidence-based interpretations that go beyond surface-level comprehension.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student can independently deconstruct a stanza from Dadu's poem, identify at least two literary devices with their functional impact, trace a theme across three textual moments, and write a 150-word analytical paragraph using the PEEL structure (Point, Evidence, Explanation, Link) with precise Hindi literary terminology.

## SCOPE_BOUNDARY
This node covers critical analysis of Dadu's Braj Bhasha verses in Chapter 9—specifically thematic interpretation, device-function analysis, and socio-historical contextualization. It does NOT cover creative writing based on the poem (node 014) or oral discussion skills (node 015), nor does it re-teach basic comprehension (node 012) or device identification (nodes 008-009).

## WALKTHROUGH
Imagine you're watching a street play in your neighborhood where actors wear masks—what they say differs from what their gestures reveal. Critical analysis is like removing those masks: first, you notice the poem's surface claim (stanza 1 declares "we are all one"), then you spot the tension between that claim and the imagery of "broken pots" (stanza 2) that suggests social fracture. Next, you ask: why does Dadu use the metaphor of a potter (kumbhar) shaping clay? Because in 15th-century Rajasthan, pottery was a low-caste occupation—by choosing this metaphor, Dadu elevates the marginalized. Finally, you connect this to the Bhakti movement's radical equality: the poem isn't just spiritual; it's a coded social critique. The key insight: every literary choice (word, image, rhythm) carries ideological weight—your job is to decode it.

## DIAGNOSTIC_QUESTION_1
What is the precise difference between 'inferential comprehension' (node 012) and 'critical interpretation' in the context of analyzing Dadu's poem?

## DIAGNOSTIC_ANSWER_1
Inferential comprehension deduces unstated factual information from textual clues (e.g., "Dadu criticizes caste because he mentions 'broken pots'"). Critical interpretation evaluates the *significance* of authorial choices—why the potter metaphor, why Braj Bhasha, how the rhythm enacts unity—and constructs an arguable claim about the poem's ideological work. A wrong answer conflates the two, treating interpretation as mere fact-retrieval, revealing the student hasn't grasped that critical thinking requires *evaluative judgment*, not just gap-filling.

## DIAGNOSTIC_QUESTION_2
In stanza 2, Dadu writes: "टूटे घट भरे न जायँ, भरे घट टूटे नाहिं" (Broken pots don't fill; filled pots don't break). A student says: "This means poor people stay poor and rich stay rich—Dadu accepts inequality." Why is this a misreading of the *function* of paradox in Bhakti poetry?

## DIAGNOSTIC_ANSWER_2
The paradox functions as *social inversion*, not endorsement: the "broken pot" (marginalized) *can* be filled by divine grace, while the "filled pot" (ritualistically proud) *will* break under ego. Bhakti poetry routinely uses paradox to destabilize hierarchy. A wrong answer treats the line as literal sociology, missing that poetic devices in this tradition *subvert* surface meaning—revealing the student reads metaphor as reportage, not as ideological strategy.

## DIAGNOSTIC_QUESTION_3
Apply the concept of 'intertextual resonance' to Dadu's line "सब घट में एक ही ज्योति" (One light in all pots). Identify one specific Upanishadic or Nirguna Bhakti precedent and explain how Dadu *transforms* it for a 15th-century artisan audience.

## DIAGNOSTIC_ANSWER_3
The Katha Upanishad (2.2.11) states "एकं ज्योतिर् बहुधा भवति" (One light becomes many). Dadu transforms this abstract metaphysics into material language: "घट" (earthen pot) replaces "देह" (body), grounding the divine in the potter's workshop. For artisans, the pot is livelihood, identity, caste-marker—Dadu re-signifies it as vessel of the divine, democratizing the Upanishadic insight. A weak answer cites the Upanishad but misses the *materialist translation*—showing inability to trace how form adapts to audience.

## DIAGNOSTIC_QUESTION_4
Analyze how the poem's *rhythmic structure* (चौपाई-दोहा cadence) performs the theme of 'unity in diversity.' Reference two specific metrical features and their semantic effect.

## DIAGNOSTIC_ANSWER_4
The chaupai (4-line, 16-matra) builds collective momentum—like workers singing in unison—while the doha (2-line, 24-matra) delivers the philosophical punch, mimicking the shift from communal labor to individual realization. The caesura after the 8th matra in each chaupai line creates a "call-response" rhythm, enacting dialogue between castes. A superficial answer notes "it has rhythm" without linking meter to meaning—revealing the student treats form as decoration, not as *enacted argument*.

## DIAGNOSTIC_QUESTION_5
Evaluate this claim: "Dadu's poem is primarily a spiritual text; its social critique is incidental." Defend or refute using three textual strategies Dadu employs to fuse the spiritual and the social.

## DIAGNOSTIC_ANSWER_5
Refute. Three fusion strategies: (1) **Vocabulary slippage**—"घट" means both 'body' (spiritual) and 'caste-occupation' (social); (2) **Communal voice**—"हम" (we) in stanza 1 includes the listener in a collective that transcends varna; (3) **Ritual inversion**—"पूजा-पाठ" (worship) is dismissed not as false but as *insufficient without social equity*, making spirituality *conditional* on justice. A wrong answer separates the two realms, missing that in Nirguna Bhakti, the spiritual *is* the social—revealing a modern secular-religious binary imposed on a pre-modern text.

## DIAGNOSTIC_QUESTION_6
Create a 4-line Hindi couplet (दोहा) in Dadu's voice that extends his critique to a 21st-century inequality (e.g., digital divide, gender wage gap, climate injustice). Use one metaphor from the original poem and one contemporary image.

## DIAGNOSTIC_ANSWER_6
Example: "टूटे घट अब स्क्रीन बने, ज्योति वही अँधेर में / डेटा के ठेकेदारों ने, बाँट दई अँधेर में" (Broken pots become screens now, the same light in darkness / Data-contractors have distributed darkness). Criteria: retains "घट/ज्योति" metaphor, introduces modern agent ("डेटा के ठेकेदार"), maintains doha meter (24 matra), and *extends* rather than repeats Dadu's logic. A poor answer writes a slogan without metaphorical continuity—showing inability to transfer analytical insight into creative synthesis.

## COMMON_MISCONCEPTION
Students equate 'critical analysis' with 'finding hidden meanings the author intended.' They hunt for a single 'correct' interpretation (e.g., "Dadu *meant* to attack Brahminism") rather than constructing *plausible, evidence-based readings* that acknowledge textual ambiguity. This stems from school exams rewarding 'standard answers' and from confusing authorial intent (unrecoverable) with textual effect (analyzable). For instance, a student insists stanza 3 *must* refer to Hindu-Muslim unity because "Dadu was a Hindu influenced by Sufism"—ignoring that the text never names communities, and that forcing historical biography onto the poem closes off other valid readings (caste, gender, class).

## ON_FAILURE
Step 1: Give the student two *contradictory* but equally text-supported readings of stanza 2 (e.g., "It's about caste" vs. "It's about ego"). Step 2: Ask them to list the *exact words* each reading relies on—showing both use the same words differently. Step 3: Introduce the concept of 'interpretive warrant': a claim is valid if it cites textual evidence *and* explains the inferential logic, not if it matches a key. Step 4: Have them write a 50-word defense of the reading they *disagree* with—building the muscle of seeing textual plurality.

## BUILDS_ON
Node 012 (Comprehension: Literal and Inferential Questions) provides the factual/textual foundation—evidence identification—that critical interpretation transforms into argument.

## LEADS_TO
Node 014 (Writing Skills: Based on the Chapter) where analytical paragraphs become structured exam answers; Node 015 (Speaking and Listening) where interpretations are debated orally.

## PREREQUISITE_NODE_IDS
c11_hin_ar_cbse_09_001, c11_hin_ar_cbse_09_002, c11_hin_ar_cbse_09_003, c11_hin_ar_cbse_09_004, c11_hin_ar_cbse_09_005, c11_hin_ar_cbse_09_006, c11_hin_ar_cbse_09_007, c11_hin_ar_cbse_09_008, c11_hin_ar_cbse_09_009, c11_hin_ar_cbse_09_010, c11_hin_ar_cbse_09_011, c11_hin_ar_cbse_09_012
## PREREQUISITE_REASONS
c11_hin_ar_cbse_09_001: Context/background knowledge (Bhakti movement, Dadu's biography, Braj Bhasha) is essential for historicizing interpretation.
c11_hin_ar_cbse_09_002: Narrative structure awareness helps track how the poem's argument unfolds across stanzas.
c11_hin_ar_cbse_09_003: Setting/atmosphere analysis provides the socio-material world the poem responds to.
c11_hin_ar_cbse_09_004: Protagonist analysis (Dadu as poetic persona) distinguishes voice from author.
c11_hin_ar_cbse_09_005: Supporting characters (implied audiences: potters, priests, seekers) shape address and tone.
c11_hin_ar_cbse_09_006: Primary theme identification gives the interpretive anchor.
c11_hin_ar_cbse_09_007: Secondary themes (labor, language, body) enable multi-thematic reading.
c11_hin_ar_cbse_09_008: Imagery/metaphor analysis supplies the device-toolkit for functional analysis.
c11_hin_ar_cbse_09_009: Irony/symbolism detection reveals subversive layers.
c11_hin_ar_cbse_09_010: Vocabulary precision (e.g., घट, ज्योति, निष्काम) prevents mistranslation.
c11_hin_ar_cbse_09_011: Grammar/usage knowledge (Braj verb forms, case endings) clarifies agency in lines.
c11_hin_ar_cbse_09_012: Literal/inferential comprehension ensures evidence is textually grounded.

## FORWARD_NODE_IDS
c11_hin_ar_cbse_09_014, c11_hin_ar_cbse_09_015, c12_hin_a_cbse_09_013, c12_hin_al_cbse_02_013, c12_hin_ar_cbse_03_013, c12_hin_ar_cbse_09_013

## FORWARD_REASONS
c11_hin_ar_cbse_09_014: Writing skills require the analytical paragraphs this node teaches—PEEL structure, evidence embedding, terminology.
c11_hin_ar_cbse_09_015: Discussion points need defensible interpretations, not just opinions—this node provides the argumentation framework.
c12_hin_a_cbse_09_013: Class 11 Chapter 9 Critical Thinking (if Kabir was covered) provides direct precedent for this poet.  
c12_hin_al_cbse_02_013: Worked on irony as a structural device.  
c12_hin_ar_cbse_03_013: अगला तार्किक चरण: Critical Thinking: इस नोड की अवधारणाओं को सीधे उपयोग/विस्तारित करता है।  
c12_hin_ar_cbse_09_013: Class 11 Critical Thinking node established the PEEL framework and device-to-theme linkage; this node deepens it for board-level complexity.  

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_09_012 -> c11_hin_ar_cbse_09_013 -> c11_hin_ar_cbse_09_014: Comprehension provides evidence; critical interpretation builds arguments; writing skills structure them for assessment.

## THIS_FORMULA
PEEL Analytical Paragraph Structure: **P**oint (arguable claim about text's meaning/function) → **E**vidence (quoted/paraphrased textual detail with location) → **E**xplanation (how evidence proves point via device/context/logic) → **L**ink (connect to broader theme/historical context/authorial strategy).

## FORMULA_VARIABLES
P = Interpretive claim (not fact); E = Specific textual reference (stanza, line, word); E = Analytical reasoning (device function, connotation, intertextuality, ideology); L = Thematic/historical/conceptual synthesis.

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
analytical

## CROSS_SUBJECT
c11_history_bhakti_movement | The poem is a primary source for 15th-century Rajasthan's social history—analyzing it as literature *and* history requires the same evidence-based inference skills.
c11_sociology_caste_structure | Dadu's potter metaphor encodes varna/jati dynamics; sociological concepts (ritual purity, occupational hierarchy) illuminate the poem's subversion.
c11_political_science_democracy | The poem's "equality of vessels" prefigures constitutional equality—tracing this lineage develops political theory reading skills.

## CROSS_SUBJECT_REASONS
c11_history_bhakti_movement: Interpreting Dadu requires situating him in the Nirguna Bhakti tradition's challenge to Brahminical authority—history provides the conflict the poem negotiates.
c11_sociology_caste_structure: The "घट" (pot) is a caste signifier (kumbhar = Shudra); sociology explains why this metaphor is radical, not just poetic.
c11_political_science_democracy: The shift from "birth-based worth" to "shared divine essence" mirrors the modern shift from status to citizenship—comparative analysis sharpens both.

## PREREQ_CONCEPT
Evidence-based inferential reasoning (from node 012): the ability to say "The text says X, therefore Y is implied" without external speculation.

## PREREQ_BEFORE
Student must fluently identify: (a) stanza boundaries, (b) key vocabulary (घट, ज्योति, निष्काम, गुरु), (c) two metaphors and one irony instance, and (d) the poem's central tension (unity claim vs. social fracture).

## PREREQ_STUCK
If stuck, return to node 008 (Imagery and Metaphor) and node 012 (Inferential Questions)—re-practice locating *exact words* that support an inference before attempting interpretation.

## WORKED_EXAMPLE_1
PROBLEM: Analyze how Dadu's use of the "potter-clay" metaphor (stanza 2) transforms the Upanishadic "body-vessel" trope to articulate a caste-critique. Write a PEEL paragraph.

STEPS:
- Step 1: Identify the core metaphor—"कुंभार घट गढ़ै" (potter shapes pot) in stanza 2—and its Upanishadic precursor (Katha Upanishad 2.2.11: body as chariot/pot).
- Step 2: Map the substitutions: Upanishad's abstract "body" → Dadu's material "घट" (earthen pot, made by low-caste kumbhar); "divine potter" → human "कुंभार" (artisan); "knowledge" → "प्रेम" (love/devotion).
- Step 3: Analyze the *functional shift*: the Upanishad legitimizes Brahminical knowledge; Dadu relocates divine agency to the artisan's labor, making caste-labor the site of revelation.
- Step 4: Select evidence: "टूटे घट भरे न जायँ" (broken pots don't fill)—"broken" = caste-damaged; "भरे घट टूटे नाहिं" (filled pots don't break)—"filled" = grace-replete. The paradox inverts ritual purity: the "impure" pot *can* hold grace.
- Step 5: Construct PEEL: Point—Dadu materializes metaphysics to democratize salvation. Evidence—stanza 2 lines on potter/clay. Explanation—substitutions elevate artisan; paradox subverts purity. Link—this fuses spiritual and social, making Bhakti a counter-hegemonic discourse.
- Step 6: Verify against text: Does every claim cite a word? Yes. Does it avoid biography? Yes. Does it use terminology (materialist translation, ritual inversion)? Yes.

REASONING: This models the full interpretive arc—intertextual tracing → semantic mapping → functional analysis → evidence selection → structured argument → self-check. Each step builds on the prior; skipping any produces a claim without warrant.

ANSWER: Dadu's potter-clay metaphor performs a materialist translation of the Upanishadic body-vessel trope to articulate caste-critique. In the Katha Upanishad, the body is a chariot driven by intellect (Brahminical knowledge); Dadu replaces "body" with "घट" (earthen pot)—the kumbhar's product, a Shudra occupation—and "divine potter" with the human "कुंभार," relocating agency to artisan labor. The paradox "टूटे घट भरे न जायँ, भरे घट टूटे नाहिं" inverts ritual logic: the "broken" (caste-oppressed) vessel *can* receive grace, while the "filled" (ritually proud) vessel *will* fracture. This fuses spiritual realization with social inversion, making the poem a counter-hegemonic text where salvation is not caste-gated but labor-grounded.

## WORKED_EXAMPLE_2
PROBLEM: The poem opens with "हम रकस एक घट तौका" (We are all one pot's fragments). A student argues: "This proclaims universal brotherhood—Dadu ignores caste." Using the concept of 'strategic essentialism,' evaluate this reading and offer a more nuanced interpretation.

STEPS:
- Step 1: Define strategic essentialism (Spivak): a marginalized group temporarily adopts a unified identity ("we are one") to challenge power, *without* erasing internal difference.
- Step 2: Test the student's reading: "ignores caste" assumes unity claims = erasure. But stanza 2 immediately introduces "टूटे घट" (broken pots)—caste fracture persists *within* the unity claim.
- Step 3: Locate the tension: Stanza 1 = aspirational unity (political strategy); Stanza 2 = material reality (caste damage). The poem *holds both*.
- Step 4: Identify the device: juxtaposition of collective voice ("हम") with fractured imagery ("टूटे घट"). The rhythm (chaupai unity vs. doha fracture) enacts this.
- Step 5: Formulate nuanced claim: Dadu deploys strategic essentialism—"हम" mobilizes collective resistance; "टूटे घट" refuses false harmony. The unity is *forged*, not found.
- Step 6: Write PEEL paragraph with this claim, citing stanza 1 "हम," stanza 2 "टूटे," and rhythmic shift.

REASONING: This example teaches students to (a) import a theoretical lens, (b) test a naive reading against textual counter-evidence, (c) locate structural tension, (d) name the device enacting it, and (e) produce a complex claim. It moves beyond "agree/disagree" to "complicate."

ANSWER: The reading that Dadu "ignores caste" mistakes strategic essentialism for naivety. Stanza 1's "हम रकस एक घट तौका" deploys collective identity as political tool—unifying potters, weavers, seekers against Brahminical exclusion. But stanza 2's "टूटे घट भरे न जायँ" immediately materializes caste fracture: the pots *are* broken by varna. The poem doesn't resolve this; it *stages* it. The chaupai's collective rhythm ("हम...हम...हम") fractures into the doha's philosophical isolation. Dadu's unity is a *demand* ("we *become* one"), not a description. This strategic essentialism—claiming oneness to fight the hierarchy that breaks it—is the poem's radical core.

## WORKED_EXAMPLE_3
PROBLEM: Compare Dadu's treatment of "गुरु" (guru) in stanza 3 with Kabir's "गुरु कुम्हार शिष्य कुंभ है" (Guru is potter, disciple clay). Analyze how each poet's *metaphorical role-assignment* reflects their distinct class positioning and pedagogical theory. Write a comparative analytical paragraph.

STEPS:
- Step 1: Extract Dadu's guru-image: "गुरु ज्ञान दीपक दियो, चेला भयो उजियार" (Guru gave knowledge-lamp, disciple became light). Guru = external illuminator; disciple = passive recipient who *becomes* light.
- Step 2: Extract Kabir's guru-image: "गुरु कुम्हार शिष्य कुंभ है, गढ़ि गढ़ि काढ़ै खोट" (Guru potter, disciple pot; shapes and removes flaws). Guru = active shaper; disciple = raw material *acted upon*.
- Step 3: Contextualize class position: Dadu (artisan, kumbhar caste) uses *light* metaphor—accessible, non-hierarchical, self-activating. Kabir (weaver, julaha caste) uses *pottery* metaphor—his own trade, implying guru *labor* on disciple.
- Step 4: Analyze pedagogical theory: Dadu = illumination model (knowledge transfer → internal realization). Kabir = formation model (repeated shaping → defect removal). Dadu trusts disciple's agency; Kabir emphasizes guru's corrective labor.
- Step 5: Trace metaphorical consistency: Dadu's "ज्योति" (light) recurs in stanza 1 ("एक ज्योति"); Kabir's "कुंभ" recurs in his corpus. Each poet builds a *coherent metaphorical system* from their craft.
- Step 6: Synthesize: Both democratize guru-authority (neither is Brahmin), but Dadu's light-model suits a community of *equals seeking*, Kabir's pottery-model suits a *hierarchical apprenticeship*. The difference reflects artisan vs. weaver guild structures.
- Step 7: Write comparative PEEL with cross-referenced evidence.

REASONING: This combines intertextual comparison, socio-historical contextualization, metaphor-system analysis, and theoretical synthesis—six distinct analytical moves. It demands the student hold two texts, two metaphors, two social contexts, and two pedagogies simultaneously.

ANSWER: Dadu and Kabir both reject Brahminical guru-authority but construct distinct pedagogical metaphors reflecting their artisan positions. Dadu's "गुरु ज्ञान दीपक दियो, चेला भयो उजियार" (stanza 3) figures the guru as lamp-lighter and disciple as self-illuminating—the light metaphor, recurring from stanza 1's "एक ज्योति," suggests knowledge *activates* inherent divinity, suiting a community of mobile seekers. Kabir's "गुरु कुम्हार शिष्य कुंभ है" draws from his weaver-potter milieu: the guru *labors* on raw clay, "गढ़ि गढ़ि काढ़ै खोट" (repeatedly shaping, removing flaws), implying discipleship as disciplined formation within a guild-like hierarchy. Dadu's model trusts the disciple's agency (becoming light); Kabir's emphasizes the guru's corrective work (removing खोट). Both democratize—neither guru is a Brahmin—but Dadu's illumination fits a fellowship of equals; Kabir's pottery fits an apprenticeship lineage. The metaphor *is* the social theory.

## COMPETENCY_QUESTION_1
QUESTION: A Class 11 exam asks: "दादू के पद में 'घट' रूपक की त्रिस्तरीय व्याख्या कीजिए: भौतिक, आध्यात्मिक, सामाजिक।" (Explain the three-tiered interpretation of the 'घट' metaphor in Dadu's verse: material, spiritual, social.) Outline the steps you would take to construct a 120-word answer that scores full marks.

COMPETENCY: Structured analytical writing with multi-layered textual evidence

STEPS:
- Step 1: Deconstruct the prompt—three tiers required, each needing distinct evidence from the poem.
- Step 2: Material tier: "घट" = earthen pot, made by kumbhar (cited: "कुंभार घट गढ़ै"). Evidence: physical object, craft product.
- Step 3: Spiritual tier: "घट" = body/vessel for divine light (cited: "सब घट में एक ही ज्योति"). Evidence: Upanishadic resonance, inner realization.
- Step 4: Social tier: "घट" = caste-identity marker (cited: "टूटे घट" = damaged by varna). Evidence: paradox inverts ritual purity.
- Step 5: Synthesize in PEEL: Point—the metaphor's density *is* the poem's argument. Evidence—three citations. Explanation—how tiers interact (material labor becomes spiritual site, social fracture becomes grace-condition). Link—this triad defines Nirguna Bhakti's materialist spirituality.

ANSWER: The metaphor "घट" operates at three inseparable tiers. Materially, it is the kumbhar's clay pot—"कुंभार घट गढ़ै" grounds divinity in Shudra labor. Spiritually, it is the body-vessel—"सब घट में एक ही ज्योति" translates Upanishadic metaphysics into artisan language. Socially, it is the caste-fractured self—"टूटे घट भरे न जायँ" encodes varna damage, yet the paradox asserts grace fills the broken. The tiers fuse: the potter's physical craft becomes the site of spiritual realization *because* it bears social oppression. This triadic density—object, soul, caste-status in one word—epitomizes Nirguna Bhakti's refusal to separate the material from the mystical.

DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: "दादू की भाषा (ब्रजभाषा) और शिल्प (चौपाई-दोहा) केवल सजावट नहीं, बल्कि उनके सामाजिक दृष्टिकोण का विस्तार हैं।" (Dadu's language [Braj Bhasha] and form [chaupai-doha] are not ornament but extensions of his social vision.) Critically evaluate this statement by analyzing *two* specific formal choices and their ideological effects.

COMPETENCY: Form-function-ideology analysis integrating linguistics, metrics, and social history

STEPS:
- Step 1: Unpack the claim—form as ideology, not decoration. Identify two formal choices: (a) Braj Bhasha over Sanskrit, (b) chaupai-doha alternation.
- Step 2: Analyze Braj Bhasha choice: It was the *spoken* language of artisans/peasants in Braj region—accessible, oral, non-Brahminical. Sanskrit was liturgical, exclusionary. Dadu's use performs *linguistic democracy*: the divine speaks in the people's tongue.
- Step 3: Analyze chaupai-doha structure: Chaupai (16-matra, 4-line) = collective, rhythmic, work-song-like (communal labor). Doha (24-matra, 2-line) = aphoristic, philosophical, individual realization. The *shift* from chaupai to doha enacts the journey from collective struggle to personal insight.
- Step 4: Connect to social vision: Language choice rejects priestly monopoly; meter choice enacts collective-to-individual pedagogical arc. Both serve the vision: spirituality *through* community, not escape *from* it.
- Step 5: Anticipate counter-argument: "Braj was also a literary court language." Rebut: Dadu's Braj is *colloquial*, not courtly—uses artisan vocabulary (घट, कुंभार, चाक), not sringara tropes.
- Step 6: Write evaluation paragraph with claim, two formal analyses, counter-rebuttal, synthesis.

ANSWER: The claim is accurate: Dadu's form *embodies* his politics. First, Braj Bhasha—not Sanskrit—makes the divine vernacular. His lexicon ("घट," "चाक," "कुंभार") is workshop-speech, not court-poetry; the guru speaks the disciple's language, collapsing the priest-laity gap. Second, the chaupai-doha alternation enacts social pedagogy: chaupai's 16-matra quatrains mimic collective work-rhythms (weavers, potters singing together), building communal consciousness; the resolving doha's 24-matra couplet distills individual realization ("चेला भयो उजियार"). The form *performs* the argument: unity is forged in shared rhythm, insight crystallizes in solitary aphorism. A counter-claim—that Braj was a literary lingua franca—ignores Dadu's deliberate colloquial register. Form here is not vehicle but *voice*.

DIFFICULTY: hard