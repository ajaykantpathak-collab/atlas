## DEFINITION
Imagery (बिंब/प्रतिबिंब) in poetry refers to the use of vivid, sensory language that creates mental pictures by appealing to the five senses (sight, sound, smell, touch, taste), while metaphor (रूपक/उपमा) is a figure of speech that directly equates two unlike things without using comparative words like "like" or "as" (जैसे/वैसे), transferring qualities from one domain to another to reveal hidden similarities. In Phonkri's Braj poetry, imagery draws from nature (seasons, flora, fauna) and domestic life, while metaphors often map spiritual longing onto physical separation.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student can independently identify at least three distinct images and two metaphors in a given stanza of Phonkri's poetry, explain the sensory modality each image activates, articulate the tenor (subject) and vehicle (image) of each metaphor, and write a 100-word board-style answer connecting these devices to the poem's central theme of viraha (separation longing) using the PEEL structure (Point, Evidence, Explanation, Link).

## SCOPE_BOUNDARY
This node covers identification, classification, and analytical explanation of imagery (visual, auditory, olfactory, tactile, gustatory) and metaphor (simple, extended, mixed) specifically in the three Phonkri poems prescribed in NCERT Class 12 Antra Chapter 8. It does NOT cover other alankaras (alliteration, hyperbole, personification) which are addressed in node c12_hin_a_cbse_08_009, nor does it cover prosody (chhand, rasa theory) beyond what is needed to explain device function.

## WALKTHROUGH
Imagine you are sitting in your grandmother's courtyard during monsoon — the smell of wet earth (mitti ki khushboo), the sound of raindrops on tin roofs, the sight of peacocks dancing. Phonkri's poetry works exactly like this sensory immersion: he doesn't just *tell* you the lover misses the beloved; he makes you *feel* the separation through images of withered flowers, silent flutes, and empty swings. Begin by reading one stanza aloud slowly, circling every word that triggers a sense. Ask: "Which sense does this word wake up?" Then hunt for direct equations — where the poet says "X *is* Y" (not "X is *like* Y"). That equation is your metaphor. The key insight: in Braj poetry, nature imagery is never decorative — it *is* the emotional state externalized.

## DIAGNOSTIC_QUESTION_1
Define "imagery" (बिंब) and "metaphor" (रूपक) in your own words, and give one example of each from daily Hindi usage (not from the textbook).

## DIAGNOSTIC_ANSWER_1
Imagery: Language that creates sensory experiences (e.g., "सुबह की चाय की खुशबू पूरे घर में फैल गई" — olfactory image). Metaphor: Direct identification of two unlike things (e.g., "वह शेर है" meaning he is brave, not literally a lion). A wrong answer that confuses metaphor with simile (using "जैसा/वैसा") reveals the student cannot distinguish direct equation from comparison — a critical error in board answers where "रूपक" and "उपमा" are separate marking points.

## DIAGNOSTIC_QUESTION_2
In Phonkri's first poem, the line "एकलफज हौं फिवक फचुक जस एसफग ज्ग्यक्स न ट्क" (एकलफज हौं फिवक फचुक जस एसफग ज्ग्यक्स न ट्क) contains a visual image. Identify the specific words creating this image and explain which *emotion* the withered flower represents, not just what it looks like.

## DIAGNOSTIC_ANSWER_2
Words: "फिवक फचुक" (withered, fallen). The withered flower represents the lover's vitality drained by separation (virah), not merely a dead plant. A wrong answer that only describes the flower's physical appearance ("it looks dry and fallen") shows the student treats imagery as decoration rather than emotional correlative — the exact mistake that loses the "explanation" mark in CBSE's 3-mark literary device questions.

## DIAGNOSTIC_QUESTION_3
Apply the tenor-vehicle framework to this metaphor from Poem 2: "तू वचेक गे ःइ फुग्क्ज्य उ;उ न फ्र्जफिर ह्स्य" (तू वचेक गे ःइ फुग्क्ज्य उ;उ न फ्र्जफिर ह्स्य). Identify the tenor (subject) and vehicle (image), then explain the *ground* (shared quality) that makes this metaphor work.

## DIAGNOSTIC_ANSWER_3
Tenor: The human soul/self (आत्मा/जीव). Vehicle: A bird that has not reached its nest despite lifetimes of flying. Ground: Restlessness, unfulfilled destination, innate homing instinct. A wrong answer that swaps tenor/vehicle or names "bird" as the subject shows the student memorizes definitions but cannot map them onto the poem's spiritual anatomy — a flaw that collapses under JEE-style "assertion-reason" questions on poetic structure.

## DIAGNOSTIC_QUESTION_4
Compare the *function* of visual imagery in Stanza 1 of Poem 1 ("य, ट्क, जस एक्स्जक फिवर्र इकल") with auditory imagery in Stanza 2 ("ल्ग फिफ्जर वुक्ज्ख क्क्फुव फ्र्य फ्र्य उवरु ग्क्स") — how does the shift from sight to sound deepen the portrayal of viraha?

## DIAGNOSTIC_ANSWER_4
Visual imagery (withered flower, empty swing) shows separation's *static* aftermath — what remains visible after the beloved's departure. Auditory imagery (repeated "फ्र्य फ्र्य" — fluttering wings, silent flute) introduces *movement* and *absence of expected sound*, conveying the lover's active, restless yearning. The shift from static sight to dynamic sound mirrors the progression from shock to active longing. A wrong answer listing images without contrasting their temporal/emotional function misses the structural logic examiners reward in 5-mark "analyze" questions.

## DIAGNOSTIC_QUESTION_5
Evaluate this student claim: "Phonkri's metaphors are simple substitutions — 'soul = bird', 'world = forest' — so they require no deep analysis." Defend or refute using evidence from Poem 3.

## DIAGNOSTIC_ANSWER_5
Refute. In Poem 3, "देक्यक द्कु ग्स्फ्ज देयेक्फक" (देक्यक द्कु ग्स्फ्ज देयेक्फक) — the world as a forest — is not a simple substitution; the compound "देक्यक" (world-forest) fuses Samsara's entanglement with the forest's density, while "दयेक्फक" (equal halves) suggests the soul's division between divine and worldly pull. The metaphor *enacts* the philosophical tension of Vishishtadvaita (qualified non-dualism) that Phonkri embodies. A wrong answer accepting the claim reveals inability to see metaphors as conceptual frameworks rather than ornamental labels — fatal for CUET/NEET humanities passages testing "author's craft."

## DIAGNOSTIC_QUESTION_6
Create a 4-line Hindi poem (any meter) about "exam stress" using at least two distinct sensory images and one metaphor where the tenor is "anxiety" and the vehicle is drawn from nature. Do not use similes.

## DIAGNOSTIC_ANSWER_6
Example:
कमरे में स्याही-सी रात गहराती है (visual: ink-dark night)
घड़ी की टिक-टिक चुभती है कानों में (auditory: clock ticking like thorns)
चिंता बरगद की जड़-सी पैर जकड़ लेती है (metaphor: anxiety = banyan roots gripping feet)
सुबह का सूरज नहीं, बस प्रश्न-पत्र चमकता है (visual: question paper replacing sun)
A poor answer using "चिंता *जैसे* बरगद की जड़" (simile) or only visual images shows the student cannot yet *generate* the devices they are asked to *analyze* — the ultimate test of internalization.

## COMMON_MISCONCEPTION
Students treat Braj vocabulary (e.g., "इकल" for eyelashes, "ल्क्व्क्सु" for swing) as *meaning* barriers rather than *imagery* carriers. They translate "इकल" → "eyelashes" and stop, missing that "इकल" (eyelashes) in "एकलफज हौं फिवक फचुक जस एसफग ज्ग्यक्स न ट्क" creates a tactile image of *tears trapped on lashes* — the physical sensation of suppressed grief. This happens because Class 11 focused on *word-meaning* (शब्दार्थ) while Class 12 demands *image-function* (बिंब-कार्य). The error costs 2-3 marks per device question when the marking scheme awards points for "sensory effect" and "emotional resonance," not glossary definitions.

## ON_FAILURE
Step 1: Revisit c11_hin_ar_cbse_01_008 (Class 11 Imagery/Metaphor) and re-do its Worked Example 1 using the *same* PEEL template but on a Phonkri stanza — this bridges the vocabulary-to-function gap. Step 2: Take one Phonkri stanza, list every noun/adjective, and for each write: "Sense triggered → Emotion conveyed → Theme link." Do this for 3 stanzas minimum. Step 3: Write one 80-word board answer analyzing a metaphor using the tenor-vehicle-ground framework explicitly. Step 4: Self-check against the marking scheme: Does my answer name the sense? Name the tenor/vehicle? Explain the ground? Link to viraha? If any "no," repeat Step 2 for that stanza.

## BUILDS_ON
c11_hin_ar_cbse_01_008 (Class 11 Literary Devices: Imagery and Metaphor) where students learned basic definitions and identification in simpler Khari Boli poems.

## LEADS_TO
c12_hin_a_cbse_08_009 (Literary Devices: Irony and Symbolism) where metaphor analysis extends to sustained symbolic systems (e.g., the flute as Krishna's call vs. lover's silence).

## PREREQUISITE_NODE_IDS
c11_hin_ar_cbse_01_008, c12_hin_a_cbse_08_001, c12_hin_a_cbse_08_002, c12_hin_a_cbse_08_006, c12_hin_a_cbse_08_003, c12_hin_a_cbse_08_007

## PREREQUISITE_REASONS
c11_hin_ar_cbse_01_008: Provides foundational definitions of imagery/metaphor and tenor-vehicle framework in accessible Khari Boli.
c12_hin_a_cbse_08_001: Supplies historical context (Phonkri's Bhakti background, Braj region) essential to decode nature imagery's cultural coding.
c12_hin_a_cbse_08_002: Establishes narrative structure (three poems = three stages of viraha) so imagery can be mapped to emotional arc.
c12_hin_a_cbse_08_006: Defines primary theme (viraha bhakti) which is the *target domain* for all metaphors in this chapter.
c12_hin_a_cbse_08_003: Setting details (rain, lightning, night sounds) function as imagery/metaphors analyzed in depth there  
c12_hin_a_cbse_08_007: Imagery and metaphor (lotus, breath, nine gates) are the *vehicles* of secondary themes — analyzing devices requires knowing the themes they carry.  

## FORWARD_NODE_IDS
c12_hin_a_cbse_08_009, c12_hin_a_cbse_08_012, c12_hin_a_cbse_08_013, c12_hin_a_cbse_08_010, c12_hin_a_cbse_08_014

## FORWARD_REASONS
c12_hin_a_cbse_08_009: Irony/symbolism analysis requires metaphor identification as prerequisite (e.g., recognizing the flute as metaphor before analyzing its ironic silence).
c12_hin_a_cbse_08_012: Comprehension questions (literal/inferential) test whether students can extract imagery-evidence for inferential answers.
c12_hin_a_cbse_08_013: Critical thinking tasks demand device-analysis as raw material for interpretation/argument.
c12_hin_a_cbse_08_010: Imagery and Metaphor node shows how specific words create images; vocabulary feeds into that analysis.  
c12_hin_a_cbse_08_014: Teaches imagery identification — the main device category in these poems.  

## CROSS_SUBJECT_PREREQS
c11_hin_ar_cbse_01_008, c11_hin_ar_cbse_02_008, c11_hin_ar_cbse_03_008, c11_hin_ar_cbse_04_008, c11_hin_ar_cbse_05_008, c11_hin_ar_cbse_06_008, c11_hin_ar_cbse_07_008, c11_hin_ar_cbse_08_008, c11_hin_ar_cbse_09_008, c11_hin_ar_cbse_10_008, c11_hin_ar_cbse_11_008, c11_hin_ar_cbse_12_008, c11_hin_ar_cbse_13_008, c11_hin_ar_cbse_14_008, c11_hin_ar_cbse_15_008, c11_hin_ar_cbse_16_008, c11_hin_v_cbse_01_008, c11_hin_v_cbse_02_008, c11_hin_v_cbse_03_008, c11_hin_v_cbse_04_008, c11_hin_v_cbse_05_008
## CROSS_SUBJECT_REASONS
c11_hin_ar_cbse_01_008: Repeated exposure to imagery/metaphor across 16 Antra + 5 Vitan chapters in Class 11 builds the device-recognition fluency needed for Class 12's analytical depth.
c11_hin_ar_cbse_02_008: Each chapter's distinct poet (Kabir, Meera, Surdas, etc.) trains students to spot how *different* Bhakti poets map *same* tenor (soul) to *different* vehicles (bird, fish, deer) — comparative skill essential for Phonkri.
c11_hin_ar_cbse_03_008: अन्य विषय की सहायता: Imagery (चित्रात्मकता/बिंब) refers to the use of vivid, sensory language that appeals to t... के तत्व इस नोड में प्रयुक्त होते हैं।  
c11_hin_ar_cbse_04_008: अन्य विषय की सहायता: Imagery (बिंब/प्रतिबिंब) is the use of vivid, sensory language that appeals to the five se... के तत्व इस नोड में प्रयुक्त होते हैं।  
c11_hin_ar_cbse_05_008: अन्य विषय की सहायता: Imagery is the use of vivid and descriptive language that appeals to the senses (sight, so... के तत्व इस नोड में प्रयुक्त होते हैं।  
c11_hin_ar_cbse_06_008: अन्य विषय की सहायता: Imagery is the use of vivid and descriptive language that appeals to the senses (sight, so... के तत्व इस नोड में प्रयुक्त होते हैं।  
c11_hin_ar_cbse_07_008: अन्य विषय की सहायता: Imagery (प्रतिबिंब/चित्रण) is the use of vivid, sensory language that appeals to the five... के तत्व इस नोड में प्रयुक्त होते हैं।  
c11_hin_ar_cbse_08_008: अन्य विषय की सहायता: Imagery (प्रतिबिंब/चित्रण) refers to the use of vivid, sensory language that appeals to th... के तत्व इस नोड में प्रयुक्त होते हैं।  
c11_hin_ar_cbse_09_008: अन्य विषय की सहायता: Imagery (बिम्ब/प्रतिबिम्ब) is the use of vivid, sensory language that appeals to the five... के तत्व इस नोड में प्रयुक्त होते हैं।  
c11_hin_ar_cbse_10_008: अन्य विषय की सहायता: Imagery is the use of vivid and descriptive language that appeals to the senses (sight, so... के तत्व इस नोड में प्रयुक्त होते हैं।  
c11_hin_ar_cbse_11_008: अन्य विषय की सहायता: Imagery is the use of vivid and descriptive language that appeals to the senses (sight, so... के तत्व इस नोड में प्रयुक्त होते हैं।  
c11_hin_ar_cbse_12_008: अन्य विषय की सहायता: Imagery (बिंब/प्रतीक) refers to the use of vivid, sensory language that creates mental pic... के तत्व इस नोड में प्रयुक्त होते हैं।  
c11_hin_ar_cbse_13_008: अन्य विषय की सहायता: Imagery is the use of vivid, sensory language that appeals to the five senses (sight, soun... के तत्व इस नोड में प्रयुक्त होते हैं।  
c11_hin_ar_cbse_14_008: अन्य विषय की सहायता: Imagery (बिंब/प्रतीक) refers to the use of vivid, sensory language that appeals to the fiv... के तत्व इस नोड में प्रयुक्त होते हैं।  
c11_hin_ar_cbse_15_008: अन्य विषय की सहायता: Imagery is the use of vivid, sensory language that appeals to the five senses (sight, soun... के तत्व इस नोड में प्रयुक्त होते हैं।  
c11_hin_ar_cbse_16_008: अन्य विषय की सहायता: Imagery (प्रतिबिंब/चित्रण) is the use of vivid, sensory language that appeals to the five... के तत्व इस नोड में प्रयुक्त होते हैं।  
c11_hin_v_cbse_01_008: अन्य विषय की सहायता: Imagery (fp=kiV laxhr) in this chapter refers to the author's technique of using vivid, se... के तत्व इस नोड में प्रयुक्त होते हैं।  
c11_hin_v_cbse_02_008: अन्य विषय की सहायता: Imagery is the use of vivid, sensory language that appeals to the five senses (sight, soun... के तत्व इस नोड में प्रयुक्त होते हैं।  
c11_hin_v_cbse_03_008: अन्य विषय की सहायता: Imagery (चित्रोपमा/बिम्ब) refers to the use of vivid, sensory language that appeals to the... के तत्व इस नोड में प्रयुक्त होते हैं।  
c11_hin_v_cbse_04_008: अन्य विषय की सहायता: Imagery (चित्रात्मकता) is the use of vivid, sensory language that appeals to the five sens... के तत्व इस नोड में प्रयुक्त होते हैं।  
c11_hin_v_cbse_05_008: अन्य विषय की सहायता: Imagery refers to the use of descriptive language that appeals to the five senses (sight,... के तत्व इस नोड में प्रयुक्त होते हैं।  

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_01_008 -> c12_hin_a_cbse_08_008 -> c12_hin_a_cbse_08_009 (Class 11 device foundations enable Class 12 Phonkri analysis which enables irony/symbolism synthesis)

## THIS_FORMULA
PEEL Analysis Template for Literary Devices: (P) Name device + location (stanza/line) → (E) Quote key words (max 6 words) → (E) Identify sense/tenor-vehicle/ground → (L) Connect to viraha theme + poet's intent.

## FORMULA_VARIABLES
P = Point (device name + textual location); E1 = Evidence (brief quote); E2 = Explanation (sensory modality OR tenor/vehicle/ground); L = Link (theme connection + authorial purpose)

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
linguistic

## CROSS_SUBJECT
N/A | Phonkri's imagery reflects 15th-century Braj Vaishnavism's "prema-bhakti" where nature mirrors divine-human longing — same cultural matrix as Mirabai/Surdas studied in History's Bhakti-Sufi traditions chapter.
 N/A | The specific flora/fauna images (कदंब, यमुना, मोर, बांसुरी) are geographically anchored in Braj's deciduous forests and riverine ecology — Geography's "cultural landscape" concept explains why these images resonate locally.
## PREREQ_CONCEPT
Tenor-vehicle-ground framework for metaphor analysis (I.A. Richards' terminology adapted for Hindi poetics).

## PREREQ_BEFORE
Student must distinguish simile (उपमा: explicit comparison via जैसा/वैसा/समान) from metaphor (रूपक: implicit equation) and identify five sensory modalities in Hindi vocabulary.

## PREREQ_STUCK
If confused between simile/metaphor, review c11_hin_ar_cbse_01_008 Worked Example 2 which contrasts "चाँद जैसा मुख" (simile) vs "मुख चाँद है" (metaphor) with same tenor/vehicle.

## WORKED_EXAMPLE_1
PROBLEM: Analyze the visual and tactile imagery in the opening lines of Phonkri's Poem 1 ("य, ट्क, जस एक्स्जक फिवर्र इकल") and explain how they jointly establish the viraha mood before any metaphor appears.
STEPS:
- Step 1: Read the stanza aloud in Braj, marking every noun/adjective that evokes a sense — "य" (this), "ट्क" (withered), "जस" (like), "एक्स्जक" (solitary), "फिवर्र" (fallen), "इकल" (eyelashes).
- Step 2: Classify each marked word by sensory modality: "ट्क/फिवर्र" = visual (withered/fallen flower), "इकल" = tactile (tears on lashes), "एक्स्जक" = visual + emotional (solitary swing).
- Step 3: For each image, write the *emotion* it physicalizes: withered flower = vitality drained; solitary swing = absence made visible; tears on lashes = grief held back.
- Step 4: Synthesize — the stanza uses *zero* metaphors but three coordinated images (visual x2, tactile x1) to show viraha as bodily experience, not abstract idea.
- Step 5: Verify against theme: This "imagery-first" strategy mirrors Bhakti poetics where the body *is* the site of divine longing — the images *are* the argument.
REASONING: This sequence trains the "sense → emotion → theme" chain that board marking schemes explicitly reward. Starting with sensory classification prevents the "meaning-only" trap.
ANSWER: The stanza opens with a cluster of visual-tactile images: the withered flower (visual: decay), the solitary swing (visual: empty space), and tears on eyelashes (tactile: suppressed grief). Together they externalize viraha as physical depletion — the lover's body mirrors the flower's withering, the swing's emptiness, the lashes' dampness. No metaphor is needed because the images *are* the metaphor: the lover *becomes* the withered flower. This imagery-first approach is characteristic of Phonkri's "sahaj" (natural) style where feeling precedes figuring.

## WORKED_EXAMPLE_2
PROBLEM: In Poem 2, the line "ल्ग फिफ्जर वुक्ज्ख क्क्फुव फ्र्य फ्र्य उवरु ग्क्स" contains an extended metaphor. Deconstruct it using tenor-vehicle-ground and explain why the repetition "फ्र्य फ्र्य" is structurally significant.
STEPS:
- Step 1: Identify the core equation — "ल्ग फिफ्जर वुक्ज्ख" (the bird of the soul) = metaphor where tenor = soul (जीवात्मा), vehicle = bird (पक्षी).
- Step 2: Map the extensions — "क्क्फुव" (cage) = vehicle for world/body (संसार/शरीर); "फ्र्य फ्र्य" (fluttering repeatedly) = vehicle for restless striving (बार-बार प्रयास); "उवरु ग्क्स" (does not fly up/escape) = vehicle for failure to attain liberation (मुक्ति न मिलना).
- Step 3: Articulate the ground for each mapping: bird↔soul = innate mobility + homing instinct; cage↔world = confinement + visibility of sky; fluttering↔striving = energy expenditure without progress.
- Step 4: Analyze "फ्र्य फ्र्य" (reduplication) — in Braj prosody, reduplication signals *continuous, habitual, fruitless action*. It transforms "fluttering" (single act) into "fluttering endlessly" (existential condition).
- Step 5: Connect to poem's philosophical layer — this extended metaphor encodes the Vishishtadvaita dilemma: the soul is *qualitatively* divine (bird's nature to fly) but *quantitatively* bound (cage's bars). The reduplication enacts the temporal stretch of samsaric cycles.
- Step 6: Check board answer readiness — can I write this in 3 PEEL paragraphs? Yes: P1=core metaphor, P2=extensions, P3=reduplication's temporal enactment.
REASONING: Extended metaphors in Bhakti poetry are philosophical arguments in image-form. The step-by-step mapping prevents "bird = soul" oversimplification that loses the cage/fluttering/escape architecture.
ANSWER: The extended metaphor "ल्ग फिफ्जर वुक्ज्ख क्क्फुव फ्र्य फ्र्य उवरु ग्क्स" maps the soul's samsaric predicament across three linked tenor-vehicle pairs: (1) Soul = Bird (ground: innate freedom-seeking), (2) World/Body = Cage (ground: confinement despite visible sky), (3) Striving = Fluttering (फ्र्य फ्र्य) (ground: energetic but directionless motion). The reduplication "फ्र्य फ्र्य" is the metaphor's engine — it converts a momentary action into a perpetual state, enacting the soul's beginningless cycles of failed escape. This is not ornamentation; it is Phonkri's philosophical thesis in image-form: the soul's nature is flight, its condition is cage, its history is फ्र्य फ्र्य.

## WORKED_EXAMPLE_3
PROBLEM: Compare how Poem 1 and Poem 3 use the *same* vehicle (flute/बांसुरी) for *different* tenors, and what this shift reveals about the progression from viraha (separation) to milan (union) in the three-poem sequence.
STEPS:
- Step 1: Locate flute references — Poem 1: "क्सो्क्क्य र्स्फ्ट एक्क्कीक क्ल जस दू वितल य्स्य" (flute mentioned in context of Radha's departure); Poem 3: "र्क्स्ग्ज फ्क्जग फ्नु नु रुक फ्नु म्यू" (flute as divine call in final stanza).
- Step 2: Identify tenors — Poem 1: Flute = vehicle for *absent beloved's voice* (tenor: Radha's call / memory of union); Poem 3: Flute = vehicle for *Krishna's divine summons* (tenor: Bhagavan's grace / call to liberation).
- Step 3: Analyze vehicle consistency — same physical object (bamboo flute, forest sound) but shifted referent: human beloved → divine beloved.
- Step 4: Trace emotional arc — Poem 1: Flute sound *triggers* viraha (sound of separation); Poem 3: Flute sound *resolves* viraha (sound of union/moksha).
- Step 5: Link to three-poem structure — Poem 1 = viraha (separation), Poem 2 = struggle (sadhana), Poem 3 = milan (union). The flute is the *leitmotif* binding the arc: it begins as wound, becomes path, ends as homecoming.
- Step 6: Board-answer compression — "The flute transforms from viraha's trigger (Poem 1) to moksha's signal (Poem 3), enacting the soul's journey from Radha's absence to Krishna's presence through the same sensory vehicle."
REASONING: This cross-poem comparison is exactly the "critical thinking" skill tested in c12_hin_a_cbse_08_013 and CBSE's 5-mark "compare/contrast" questions. It requires holding the whole chapter in view while zooming into device-level mechanics.
ANSWER: In Poem 1, the flute (बांसुरी/मुरली) is the auditory ghost of Radha — its sound *precipitates* the lover's collapse into viraha ("क्सो्क्क्य र्स्फ्ट एक्क्कीक क्ल जस दू वितल य्स्य"). In Poem 3, the same flute becomes Krishna's direct summons ("र्क्स्ग्ज फ्क्जग फ्नु नु रुक फ्नु म्यू") — its sound *consummates* the journey. The vehicle (flute's forest melody) remains constant; the tenor shifts from human beloved to divine beloved. This shift mirrors the Bhakti trajectory: the very sensory channel that once carried separation's pain becomes grace's conduit. Phonkri uses the flute as a structural hinge — the poem sequence moves *through* the flute, not past it.

## COMPETENCY_QUESTION_1
QUESTION: A Class 12 student writes this answer to "Explain the metaphor in 'तू वचेक गे ःइ फुग्क्ज्य उ;उ न फ्र्जफिर ह्स्य'": "The poet compares the soul to a bird. The bird flies but doesn't reach its nest. This shows the soul is restless." Identify two specific weaknesses in this answer relative to CBSE's 3-mark marking scheme for literary device questions, and rewrite it to full marks standard using the PEEL template.
COMPETENCY: Critical evaluation of peer response + application of marking criteria
STEPS:
- Step 1: Recall CBSE marking scheme for 3-mark device questions: 1 mark for correct identification, 1 mark for textual evidence, 1 mark for explanation of function/effect.
- Step 2: Audit the student answer — Strength: identifies tenor/vehicle. Weakness 1: No textual quote (fails evidence mark). Weakness 2: "Shows restlessness" is vague — misses the specific ground (homing instinct + beginningless cycles) and theme link (virah/bhakti).
- Step 3: Rewrite using PEEL: P = The metaphor "तू वचेक गे ःइ फुग्क्ज्य उ;उ न फ्र्जफिर ह्स्य" maps the soul (tenor) onto a bird failing to reach its nest (vehicle). E = "फुग्क्ज्य" (bird), "फ्र्जफिर" (not reaching nest), "वचेक गे" (since birth/lifetimes). E = The ground is the bird's innate homing instinct frustrated by invisible barriers — this enacts the soul's beginningless (वचेक गे) striving for liberation thwarted by maya. L = Thus the metaphor condenses the Vishishtadvaita doctrine: the soul's nature is divine motion, its bondage is structural, not accidental.
- Step 4: Verify word count (~80 words) and marking points coverage.
ANSWER: Weaknesses: (1) Zero textual quotation — CBSE requires "textual evidence" for the evidence mark. (2) "Restlessness" is a generic label; the explanation mark demands the *specific ground* (homing instinct + beginningless cycles) and *theme link* (virah/sadhana). Rewritten PEEL answer: "The metaphor 'तू वचेक गे ःइ फुग्क्ज्य उ;उ न फ्र्जफिर ह्स्य' equates the soul (tenor) with a bird that cannot reach its nest despite lifetimes of flying (vehicle). Key words: 'फुग्क्ज्य' (bird), 'फ्र्जफिर' (not reaching nest), 'वचेक गे' (since birth). The ground is the bird's instinctive homing drive meeting structural failure — this enacts the soul's beginningless (वचेक गे) striving for moksha blocked by maya. The metaphor thus compresses Vishishtadvaita: the soul's essence is divine motion, its bondage is ontological."
DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: "Phonkri's imagery is derivative — he just uses stock Braj nature tropes (Yamuna, kadamb, peacock, flute) that Surdas and Mirabai already used. There's no originality." Using evidence from all three poems, evaluate this claim. Your answer must: (a) acknowledge the shared trope repertoire, (b) demonstrate how Phonkri *re-functions* at least two shared images, and (c) conclude whether "derivative" is a valid critical judgment for Bhakti poetry.
COMPETENCY: Intertextual analysis + critical judgment + evidence synthesis
STEPS:
- Step 1: Concede the shared repertoire — yes, Yamuna/kadamb/peacock/flute appear across Braj Bhakti poets (Surdas, Mira, Raskhan). This is *sampradaya* (tradition), not plagiarism.
- Step 2: Select two shared images and contrast functions — Image 1: Flute. Surdas: Krishna's playful lure (leela). Phonkri Poem 1: Trigger of viraha (Radha's departure). Phonkri Poem 3: Instrument of grace (moksha call). Same object, three distinct theological functions.
- Step 3: Image 2: Peacock/Mor. Mirabai: Symbol of monsoon longing (visual). Phonkri Poem 2: "फ्र्य फ्र्य" wing-flutter = *kinetic* enactment of soul's futile striving (not visual beauty).
- Step 4: Synthesize — In Bhakti poetics, "originality" = *re-functionalization* of shared symbols to articulate a specific siddhanta (doctrine). Phonkri's Vishishtadvaita inflection (qualified non-dualism) demands the flute become a *philosophical hinge* (viraha→moksha) and the peacock become *metaphysics in motion* (फ्र्य फ्र्य).
- Step 5: Verdict — "Derivative" applies only if originality = novel imagery. For Bhakti, originality = novel *deployment* of sacred imagery. Phonkri passes the latter test decisively.
ANSWER: The claim mistakes *tradition* for *derivativeness*. Braj Bhakti operates through a shared symbolic lexicon (Yamuna, kadamb, mor, murali) — this is the *sampradaya's* common vocabulary, not a poet's private property. Phonkri's originality lies in *re-functionalization*: (1) The flute (मुरली) in Surdas signals Krishna's leela; in Phonkri Poem 1 it triggers viraha (Radha's absence); in Poem 3 it delivers moksha (Krishna's call). Same vehicle, three tenors mapping a complete theological arc. (2) The peacock (मोर) in Mirabai is visual monsoon-longing; in Phonkri Poem 2 its "फ्र्य फ्र्य" (wing-flutter) becomes the kinetic signature of the soul's beginningless, fruitless striving (वचेक गे). The reduplication transforms a decorative bird into a metaphysical engine. Verdict: "Derivative" is an invalid criterion for Bhakti criticism where *innovation = new doctrinal work done by old images*. Phonkri's images do Vishishtadvaita's work — that is their originality.
DIFFICULTY: hard