## DEFINITION
Imagery (चित्रात्मकता) refers to the use of vivid and descriptive language that appeals to the senses (sight, sound, smell, touch, taste) to create mental pictures. Metaphor (रूपक) is a figure of speech that directly compares two unrelated things by stating one *is* the other, without using "like" or "as" (unlike simile/उपमा), to transfer qualities and deepen meaning.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student can independently identify specific sensory images and metaphors in Raskhan's verses, explain the sensory appeal of each image, interpret the implied comparison in each metaphor, and articulate how both devices work together to convey the theme of divine love (भक्ति-शृंगार) in the prescribed poems.

## SCOPE_BOUNDARY
This node covers *only* imagery (types: visual, auditory, tactile, kinetic) and metaphor (simple, implied, extended) as they appear in the Raskhan poems prescribed in Class 12 Antra Chapter 6 (v/ksofj dkO;). It does NOT cover simile (उपमा), personification (मानवीकरण), irony (व्यंग्य), or symbolism (प्रतीकवाद) — those are handled in sibling nodes 009 and 010.

## WALKTHROUGH
Imagine you are listening to a bhajan describing Krishna's flute: you don't just hear words; you *see* the peacocks dancing, *feel* the cool Yamuna breeze, *smell* the kadamba flowers. That is imagery at work. Now, if the poet says "Krishna's flute is a call that pulls the soul like a magnet," that is a metaphor — the flute becomes a magnet without using "like." In this node, we will learn to spot these two devices in Raskhan's Braj Bhasha verses by: (1) reading aloud to catch sound-images, (2) underlining every noun/adjective that triggers a sense, (3) asking "What two things are being equated here?" for metaphors, and (4) linking the device to the poem's central emotion — the gopi's longing or Krishna's allure. The key insight: in Bhakti poetry, imagery makes the divine tangible, and metaphor dissolves the boundary between human and divine love.

## DIAGNOSTIC_QUESTION_1
Define 'imagery' (चित्रात्मकता) and 'metaphor' (रूपक) in your own words, giving one original example of each (not from the textbook).

## DIAGNOSTIC_ANSWER_1
**Correct Answer:** Imagery is descriptive language appealing to the five senses (e.g., "The sharp tang of raw mango made my mouth water" — gustatory). Metaphor is a direct comparison stating A is B (e.g., "Time is a thief" — time steals moments).  
**What a wrong answer reveals:** If the student gives a simile ("Time is *like* a thief") for metaphor, they confuse the two devices. If they define imagery only as "visual description," they miss auditory, tactile, olfactory, and kinetic images — a common gap because textbooks often emphasize visual examples.

## DIAGNOSTIC_QUESTION_2
In the opening lines of Raskhan's poem (the verse beginning "iqyfd ljhj lHkk¡ Hk,"), the poet writes "gkjsagw¡ [ksy ftrko¯g eksgh". Explain which *sense* this image primarily appeals to and *why* the poet chooses that specific sensory detail at the start of the poem.

## DIAGNOSTIC_ANSWER_2
**Correct Answer:** The image "gkjsagw¡ [ksy ftrko¯g eksgh" (the flute's melody spreads in all directions) appeals primarily to the **auditory sense** (sound). The poet opens with sound because the flute's call is the *catalyst* for the entire narrative — it awakens the gopis, disrupts their chores, and symbolizes the divine call that cannot be ignored. Starting with sound immerses the reader in the moment the ordinary world is pierced by the sacred.  
**What a wrong answer reveals:** If the student says "visual" because they picture the flute, they confuse the *object* (flute) with the *sensory quality described* (melody spreading). If they cannot explain *why* it is placed first, they treat imagery as decoration rather than structural strategy.

## DIAGNOSTIC_QUESTION_3
Apply the concept of metaphor to the line "eSa tkum¡ fut ukFk lqHkkmQA" (I am yours, not of anyone else). Identify the two terms being compared implicitly, state the *ground of comparison* (similarity), and explain what this metaphor reveals about the speaker's psychological state.

## DIAGNOSTIC_ANSWER_3
**Correct Answer:**  
- **Tenor (subject):** The speaker (gopi/soul).  
- **Vehicle (object):** "fut ukFk" (belonging exclusively to you / your property).  
- **Ground:** Total ownership, surrender, lack of autonomy — just as an owned object has no will separate from the owner.  
- **Psychological insight:** The metaphor transforms a *feeling* (devotion) into a *legal/ontological status* (property). It shows the gopi has internalized Krishna's mastery so completely that she no longer sees herself as an independent agent.  
**What a wrong answer reveals:** If the student only identifies "I" and "yours" without naming the implied noun "property/object," they miss the *reification* (turning abstract relation into concrete thing) that gives the metaphor its power. If they call it a simile because of "like" in translation, they ignore the original Braj syntax which has no comparative particle.

## DIAGNOSTIC_QUESTION_4
Analyze how the *cluster* of tactile and kinetic images in the lines "uhjt u;u usg ty ck<+s / fllqiu rsa ifjgjsm¡ u laxw" (body hairs stand, tears flow uncontrollably) works together to convey the *intensity* of the gopi's response to the flute. Why are these two specific senses (touch, movement) chosen over visual or auditory here?

## DIAGNOSTIC_ANSWER_4
**Correct Answer:** The tactile image "uhjt u;u usg ty ck<+s" (hairs stand on end / horripilation) and kinetic image "fllqiu rsa ifjgjsm¡ u laxw" (tears flow without restraint) are *involuntary bodily reactions* — they happen *to* the body, not *by* the will. By clustering them, Raskhan shows the flute's call bypasses the mind and hijacks the nervous system. Touch and movement are chosen because they are the most *visceral, undeniable* proofs of inner upheaval; visual/auditory images would keep the experience at a distance (watching/listening), whereas tactile/kinetic forces the reader to *feel* the gopi's loss of control.  
**What a wrong answer reveals:** Listing the images separately without explaining their *combined effect* shows fragmentary analysis. Choosing "visual" as the dominant sense indicates the student defaults to the most common imagery type instead of reading the specific sensory language.

## DIAGNOSTIC_QUESTION_5
Evaluate the claim: "Raskhan's metaphors in this poem are merely decorative embellishments; the same meaning could be conveyed literally without loss." Defend your position with two specific metaphors from the text.

## DIAGNOSTIC_ANSWER_5
**Correct Answer:** The claim is **false**. Two metaphors prove essential meaning would be lost:  
1. **"eksj vHkkx mnfèk voxkgw"** (Your glance/attention makes the mind intoxicated) — "voxkgw" (intoxicated) equates divine attention to an intoxicant. Literal paraphrase ("Your glance makes me happy") loses the *loss of self-control, the delirium, the dangerous sweetness* inherent in intoxication.  
2. **"eqoQrk izlo fd lacqd dkyh"** (Beloved, this night passes with difficulty) — "lacqd" (bitter/painful) transfers the quality of a bitter substance to *time itself*. Literal "the night is long" misses the *taste* of suffering — the night is not just long, it is *palatably bitter*.  
Metaphors here compress complex psycho-spiritual states into single sensory verbs; literal expansion flattens them.  
**What a wrong answer reveals:** Agreeing with the claim shows the student views figurative language as optional ornamentation (a Class 10-level misconception). Citing only visual metaphors (e.g., "flute = voice") ignores the more sophisticated somatic metaphors (intoxication, bitterness) that carry the poem's emotional weight.

## DIAGNOSTIC_QUESTION_6
Create a 4-line Hindi couplet (दोहा/चौपाई) on *any* subject that uses **at least two distinct types of imagery** and **one original metaphor**. Label each device in your answer.

## DIAGNOSTIC_ANSWER_6
**Sample Answer:**  
"सूरज ढला, चाँदी बिखरी नदिया पर, (Visual imagery: चाँदी बिखरी)  
शीतल हवा छू गई गालों को, (Tactile imagery: छू गई)  
नींद आई नहीं, सपना बन बैठी, (Metaphor: नींद = सपना / personification)  
रात भर जागी रही, पलकों की पालकी।" (Kinetic imagery: जागी रही)  
**Criteria for a good answer:** (1) Two *different* senses (not two visual), (2) Metaphor uses A-is-B structure without "जैसे/सा", (3) Devices are correctly labeled.  
**What a poor answer reveals:** Using two visual images ("red rose, blue sky") shows sensory monotony. Writing a simile ("नींद जैसे सपना") instead of metaphor shows confusion between the two devices. Missing labels indicates the student cannot *meta-cognitively* identify their own craft.

## COMMON_MISCONCEPTION
**Misconception:** "Imagery is only about *visual* descriptions (pictures in the mind), and metaphor is just a 'fancy synonym' for simile — both are optional decorations that make the poem 'beautiful'."  
**Why students make this error:**  
1. **Textbook bias:** School exercises often ask "चित्रात्मकता बताइए" and students quote only lines with color/shape words (e.g., "नील गगन", "हरी घास"), reinforcing the visual default.  
2. **Translation habit:** Hindi textbooks frequently gloss metaphors as "X is like Y" in Hindi explanations (e.g., "बांसुरी *जैसे* बुलावा है"), blurring the structural difference between metaphor (identity) and simile (comparison).  
3. **Exam pattern:** Board questions sometimes accept "beauty enhancement" as a function of literary devices, so students memorize that as the *only* function.  
**Concrete example:** In Raskhan's "egha ldy vujFk dj ewyk" (great fatigue removed, comfort came), a student writes "Visual imagery: the gopi looks tired then happy" — missing the *tactile/kinetic* image of fatigue *leaving the body* (vujFk) and comfort *arriving* (ewyk), and missing the metaphor of fatigue as a *removable burden*.

## ON_FAILURE
**Remediation Path (3 steps):**  
1. **Sensory Re-calibration (15 min):** Give the student a 4-line unseen Hindi poem. Ask them to *circle* every word triggering a sense and *label* the sense (V/A/T/O/G). If they find only visual, assign "Sensory Walk" homework: describe a familiar place (kitchen, bus stand) using *only* non-visual senses.  
2. **Metaphor Surgery (20 min):** Take 3 similes from the textbook (e.g., "चाँद *जैसे* मुखड़ा") and ask the student to convert each into a metaphor by deleting "जैसे" and restructuring ("चाँद मुखड़ा है"). Then have them explain *what is gained/lost* in each conversion (e.g., loss of hesitation, gain of immediacy).  
3. **Function-First Analysis (10 min):** Re-read Raskhan's "eksj vHkkx mnfèk voxkgw". Ask: "If Raskhan wrote 'Your glance makes me very happy' instead, what *specific feeling* disappears?" Force the student to name the lost nuance (intoxication/delirium). Repeat for two more metaphors.  
**Re-diagnostic:** After remediation, give DIAGNOSTIC_QUESTION_4 again with a *different* stanza. Mastery = correct sensory labels + explanation of *why* those senses cluster.

## BUILDS_ON
Class 11 node c11_hin_ar_cbse_01_008 (Literary Devices: Imagery and Metaphor) where students learned basic identification and definition; Class 12 deepens this to *cluster analysis*, *somatic metaphors*, and *thematic integration* in Bhakti poetry.

## LEADS_TO
c12_hin_a_cbse_06_009 (Literary Devices: Irony and Symbolism) — because metaphor often *becomes* symbol when repeated across a work (e.g., flute → symbol of divine call), and irony in Bhakti poetry (e.g., the Lord serving the devotee) relies on metaphoric role-reversal.

## PREREQUISITE_NODE_IDS
c12_hin_a_cbse_06_001, c12_hin_a_cbse_06_003, c12_hin_a_cbse_06_006, c12_hin_a_cbse_06_007, c11_hin_ar_cbse_01_008, c11_hin_ar_cbse_02_008, c11_hin_v_cbse_01_008
## PREREQUISITE_REASONS
c12_hin_a_cbse_06_001: Provides biographical/historical context of Raskhan (Muslim poet of Krishna bhakti) essential for interpreting his unique imagery.  
c12_hin_a_cbse_06_003: Establishes the setting (Vrindavan, Yamuna, kadamba groves) which is the *source domain* for most nature imagery in the poems.  
c12_hin_a_cbse_06_006: Primary theme (divine love as human love) is the *target domain* that metaphors map onto; without theme, metaphor analysis is rootless.  
c12_hin_a_cbse_06_007: Secondary themes (virah, union, guru-grace) determine *which* metaphors appear where (e.g., separation metaphors in virah stanzas).  
c11_hin_ar_cbse_01_008: Class 11 foundation — basic definitions, identification drills, simple analysis of imagery/metaphor in Khusro/Kabir.  
c11_hin_ar_cbse_02_008: Extended practice with metaphor in narrative poetry (e.g., Padmavat) preparing for Raskhan's lyrical density.  
c11_hin_v_cbse_01_008: Exposure to prose imagery/metaphor in Vitan essays, building cross-genre analytical flexibility.

## FORWARD_NODE_IDS
c12_hin_a_cbse_06_009, c12_hin_a_cbse_06_010, c12_hin_a_cbse_06_012, c12_hin_a_cbse_06_013, c12_hin_a_cbse_06_011, c12_hin_a_cbse_06_015

## FORWARD_REASONS
c12_hin_a_cbse_06_009: Irony and Symbolism build directly on metaphor (extended metaphor → symbol; metaphoric role-reversal → irony).  
c12_hin_a_cbse_06_010: Vocabulary in Context requires recognizing metaphorical usage of words (e.g., "voxkgw" = intoxicated, not literally drunk).  
c12_hin_a_cbse_06_012: Comprehension questions (literal/inferential) often ask "What does the image of X suggest?" — answered via imagery analysis.  
c12_hin_a_cbse_06_013: Critical Thinking tasks (e.g., "Compare Raskhan's flute imagery with Surdas's") demand the analytical toolkit built here.
c12_hin_a_cbse_06_011: Imagery/metaphor analysis often relies on grammatical form (e.g., nominalized verbs as metaphors); this node enables that link.  
c12_hin_a_cbse_06_015: इमेजरी/रूपक (रेनु, घुटुरुन्नि) पहचानने पर ही सौंदर्यात्मक विश्लेषण संभव।  

## CROSS_SUBJECT_PREREQS
c11_hin_ar_cbse_01_008, c11_hin_ar_cbse_02_008
## CROSS_SUBJECT_REASONS
c11_hin_ar_cbse_01_008: Same literary concepts (imagery, metaphor) applied to different poets (Khusro, Kabir) — enables comparative analysis across Bhakti poets.  
c11_hin_ar_cbse_02_008: Metaphor in epic narrative (Padmavat) vs. lyric (Raskhan) — teaches genre-sensitivity in device analysis.

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_01_008 -> c12_hin_a_cbse_06_008 -> c12_hin_a_cbse_06_009

## THIS_FORMULA
N/A - conceptual

## FORMULA_VARIABLES
N/A

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
linguistic

## CROSS_SUBJECT
N/A | Both require close reading of sensory language and figurative comparison; the PEEL (Point-Evidence-Explanation-Link) answer structure taught in English poetry analysis transfers directly to Hindi board answer-writing.  
 N/A | Raskhan's imagery/metaphors are *historical evidence* of syncretic culture — e.g., Muslim poet using Braj Bhasha, Hindu theological concepts (virah, prema) expressed through Persianate metaphors (voxkgw = mast/mastana). Analyzing devices here illuminates historical processes of cultural synthesis.
## PREREQ_CONCEPT
Ability to distinguish *literal* vs *figurative* language and to name the five senses — without this, imagery/metaphor identification is guesswork.

## PREREQ_BEFORE
Student must have completed Class 11 Literary Devices node (c11_hin_ar_cbse_01_008) and read the Raskhan poems in Class 12 textbook at least once (node 001 context).

## PREREQ_STUCK
If stuck on identifying senses, review "Sensory Word Bank" from Class 11 node c11_hin_ar_cbse_01_008 (appendix). If stuck on metaphor structure, revisit "Tenor-Vehicle-Ground" framework from same node.

## WORKED_EXAMPLE_1
PROBLEM: Analyze the imagery in the stanza "tuuh fuj[kfr cku èkuqfg;k¡ / ckj ckj mj uSufu ykofr izHkqtw dh yfyr iufg;k¡" (from the prose passage describing the gopi's memory). Identify all sensory images, classify each by sense, and explain how the *cluster* creates a flashback effect.

STEPS:
- Step 1: Read the lines aloud twice — first for meaning, second for sensory triggers. Note: "fuj[kfr cku" (bloomed bud), "èkuqfg;k¡" (fragrances), "uSufu" (intoxicating), "ykofr" (youth), "izHkqtw" (fresh/new), "yfyr iufg;k¡" (swinging memories).
- Step 2: Classify each trigger: "fuj[kfr cku" → Visual (shape/color of bud); "èkuqfg;k¡" → Olfactory (fragrance); "uSufu" → Gustatory/Tactile (intoxicating touch/taste); "ykofr" → Kinetic/Visual (youthful movement); "izHkqtw" → Tactile (freshness); "yfyr iufg;k¡" → Kinetic (swinging) + Visual (memories as objects swinging).
- Step 3: Observe the *sequence* — it moves from external nature (bud, fragrance) to internal sensation (intoxication, youth) to mental action (memories swinging). This mirrors the *process of remembering*: stimulus → sensation → recall.
- Step 4: Explain the flashback effect: The olfactory image "èkuqfg;k¡" is the *trigger* (smell is the strongest memory cue neurologically). The kinetic "yfyr iufg;k¡" (memories swinging like a pendulum) makes the abstract act of remembering *visible and rhythmic* — the past is not static, it swings into present.
- Step 5: Connect to theme: This sensory cluster establishes the *physicality of longing* — virah is not just an emotion but a full-body re-experiencing. The imagery prepares for the metaphor of "Hajir" (presence) in the next stanza.

REASONING: This 5-step method (Read → Classify → Sequence → Effect → Theme) forces the student to move from device-spotting to device-function — the core skill for Board 3-markers and CUET analytical questions.

ANSWER: The stanza uses a multi-sensory cluster (Visual: फूला कली; Olfactory: सुगंधियाँ; Gustatory/Tactile: उसुफु; Kinetic/Visual: यौवन, झूला) arranged in a stimulus-to-recall sequence. The olfactory trigger (सुगंधियाँ) initiates an involuntary flashback, while the kinetic metaphor of memories swinging (यफर इउफग;क¡) makes the psychological process tangible. Together they convey that virah (separation) is a somatic re-living, not mere mental recollection.

## WORKED_EXAMPLE_2
PROBLEM: In the line "dcgq¡ leqf> ouxeu jke dks jfg pfd fp=kfy[kh lh" (Sometimes the gopi showed Krishna a picture equal to herself), identify the metaphor, explain the *ground of comparison* between "gopi" and "picture," and interpret what this reveals about the gopi's self-perception in love.

STEPS:
- Step 1: Locate the comparison — "fp=kfy[kh lh" (showed a picture equal to [her]). The verb "fp=kfy[kh" (made a picture/portrait) is literal, but "leqf> ouxeu" (equal to herself) makes the *gopi herself* the standard of the picture. The metaphor is implied: **The gopi *is* a picture/portrait of Krishna.**
- Step 2: Identify Tenor and Vehicle: Tenor = Gopi (subject); Vehicle = Picture/Portrait (fp=k). The copula "fy[kh lh" (made/showed) equates them.
- Step 3: Determine Ground of Comparison: A picture (fp=k) is (a) a *representation* — it derives existence from the original; (b) *passive* — it does not act, only receives the gaze; (c) *defined by the artist* — Krishna is the painter, the gopi is the painted.
- Step 4: Interpret psychological state: The gopi sees herself *only* as Krishna's creation, not an independent being. Her agency is surrendered ("jfg pfd" — showed [him] a picture). She seeks validation *through* his gaze — "fp=kfy[kh" implies she *presents* herself for his inspection. This is the Bhakti ideal: the devotee as divine artifact.
- Step 5: Link to larger pattern: This metaphor recurs in Raskhan — the gopi as "chitthi" (letter), "bansuri" (flute), "pratibimb" (reflection). All are *media* that carry Krishna's presence. The "picture" metaphor specifically highlights *visual devotion* (darshan) — she wants to be the image he looks at.

REASONING: The steps move from linguistic form (verb + complement) to conceptual mapping (Tenor-Vehicle-Ground) to psychological/thematic payoff. This mirrors the "Identify → Analyze → Interpret → Contextualize" rubric used in Board marking schemes for 4-5 mark questions.

ANSWER: Metaphor: Gopi = Picture (fp=k). Ground: A picture is a passive representation created by and for the artist. Interpretation: The gopi internalizes her identity as Krishna's artifact — she exists to be seen by him. This reveals total surrender of agency and the centrality of *darshan* (mutual seeing) in Raskhan's Bhakti.

## WORKED_EXAMPLE_3
PROBLEM: Compare the use of *olfactory imagery* in Raskhan's "èkuqfg;k¡" (fragrances) and *tactile-kinetic imagery* in "uhjt u;u usg ty ck<+s / fllqiu rsa ifjgjsm¡ u laxw" (hairs stand, tears flow). How do these two distinct sensory clusters serve *different stages* of the gopi's response to the flute call?

STEPS:
- Step 1: Isolate the two clusters. Cluster A (Olfactory): "èkuqfg;k¡" — appears in the *memory/flashback* stanza (prose passage). Cluster B (Tactile-Kinetic): "uhjt u;u usg ty ck<+s / fllqiu rsa ifjgjsm¡ u laxw" — appears in the *immediate reaction* stanza (poem).
- Step 2: Analyze Cluster A function: Olfactory images are *retrospective* — smell triggers memory (Proustian effect). "èkuqfg;k¡" pulls the gopi *back* into past union (youth, bud, intoxication). It is *involuntary* and *transportive*.
- Step 3: Analyze Cluster B function: Tactile-kinetic images are *present-tense somatic rupture* — horripilation (uhjt u;u) and weeping (fllqiu) happen *now*, in the body, uncontrollably. They signal the *arrival* of the divine call in the present moment.
- Step 4: Contrast temporal orientation: Cluster A = Past → Present (memory invading now). Cluster B = Present → Future (body preparing for union/meeting). The flute call *bridges* them: smell remembers the Beloved; body readies for the Beloved.
- Step 5: Synthesize thematic progression: Raskhan uses olfactory imagery to establish the *depth of past intimacy* (why she loves) and tactile-kinetic imagery to show the *urgency of present longing* (how she loves now). The metaphor "flute = call" (implied in both) transforms memory into anticipation.
- Step 6: Board-exam application: A 5-mark question "चित्रात्मकता के माध्यम से रसखान ने विरह की किन अवस्थाओं को व्यक्त किया है?" requires exactly this two-cluster, two-stage analysis with textual evidence.

REASONING: This worked example models the *comparative analysis* skill needed for higher-order Board questions (6 markers) and CUET "match the following" / "assertion-reason" on literary devices. It forces the student to see imagery as *structural*, not decorative.

ANSWER: Olfactory cluster (सुगंधियाँ) operates in the *memory mode* — it evokes past union, making virah palpable through sensory recall. Tactile-kinetic cluster (रोमांच, अश्रु) operates in the *ecstatic mode* — it manifests present longing as involuntary bodily proof. Together they map the arc of virah: *remembrance* (smell) → *rupture* (body) → *readiness* (for union). The flute call is the catalyst that activates both clusters.

## COMPETENCY_QUESTION_1
QUESTION: A student writes in the Board exam: "रसखान के काव्य में बांसुरी की ध्वनि एक रूपक है जो कृष्ण के बुलावे को दर्शाती है।" The examiner awards 1/3 marks. Using the concept of *metaphor vs. symbol* and *textual evidence*, explain why this answer is incomplete and rewrite it for full marks.

COMPETENCY: Critical Analysis & Answer Writing (CBSE Board Pattern: 3-mark "Explain with reference to context")

STEPS:
- Step 1: Identify the error — the student calls the flute's *sound* a "metaphor for Krishna's call." But the sound is *literal* (the flute actually sounds); the *flute itself* (or its melody) becomes a metaphor/symbol. Confusing literal sound with figurative comparison.
- Step 2: Recall the distinction: Metaphor = "A is B" (flute *is* a call/magnet). Symbol = recurring object carrying layered meaning (flute = divine grace, formless call, etc.). The student's statement is a *paraphrase*, not device analysis.
- Step 3: Find textual evidence for *metaphor*: "eksj vHkkx mnfèk voxkgw" — the *glance/attention* (not sound) intoxicates. "gkjsagw¡ [ksy ftrko¯g eksgh" — the *melody spreads* (personification of sound as agent). The metaphor is in the *agency* given to melody.
- Step 4: Rewrite using PEEL: Point — Raskhan metaphorizes the flute's *melody* as an autonomous agent that intoxicates and summons. Evidence — "गगन सगुन फूटत भयो एकघ" (melody spreads) + "एखज वहक मनभय बोझगव" (glance intoxicates). Explanation — The melody is not just sound; it acts like an intoxicant (metaphor) that bypasses will. Link — This metaphor establishes the *irresistibility* of divine grace, central to Raskhan's Bhakti.

ANSWER: The original answer confuses literal description (flute sounds) with figurative analysis. For full marks: "Raskhan employs metaphor when he endows the flute's *melody* with human/divine agency: 'गगन सगुन फूटत भयो एकघ' (the melody spreads in all directions) personifies sound as an active summoner, and 'एखज वहक मनभय बोझगव' (your glance intoxicates the mind) equates divine attention to an intoxicant. These metaphors transform the flute from an instrument into the *embodiment of grace* — irresistible, intoxicating, and transformative — which is the theological core of Raskhan's Prema-bhakti."

DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: (CUET / JEE-style Assertion-Reason)  
**Assertion (A):** In Raskhan's poetry, tactile-kinetic imagery (horripilation, weeping, fainting) is more frequent and functionally significant than visual imagery.  
**Reason (R):** Because Raskhan's Bhakti emphasizes *prema* (intense emotional love) as a somatic, involuntary experience rather than a visual contemplation (darshan).  
Choose the correct option and justify with two textual references.

COMPETENCY: Analytical Reasoning & Textual Evidence (Competitive Exam Pattern: A-R + Evidence)

STEPS:
- Step 1: Evaluate Assertion (A) — Scan the prescribed verses. Visual images: "gkjsagw¡ [ksy" (melody spreading — auditory), "fp=kfy[kh" (picture — visual), "xqj xkslkb¡" (fresh shoots — visual). Tactile-kinetic: "uhjt u;u usg ty ck<+s" (horripilation), "fllqiu rsa ifjgjsm¡ u laxw" (tears flow), "egha ldy vujFk dj ewyk" (fatigue removed, comfort came — tactile), "vijkfèkgq ij dksg u dkmQ" (no care for body — kinetic neglect). Count: Tactile-kinetic > Visual. **Assertion TRUE.**
- Step 2: Evaluate Reason (R) — Raskhan's theology (from node 001 context): He follows *Pushti Marg* / *Prema-bhakti* where the body is the site of divine play (leela). The gopi's body *reacts* before the mind decides. This is *somatic devotion*. **Reason TRUE.**
- Step 3: Check R explains A — Yes. Because prema is somatic (R), the poetry *must* foreground bodily sensations (A) to be theologically accurate. Visual contemplation (darshan) is secondary to *feeling* the Lord's touch/call.
- Step 4: Select textual evidence: (1) "उह्जत उस उस त्य चकस" (horripilation) — tactile proof of flute's power. (2) "एघा लद्य वुजफक द्ज एव्यक" (great fatigue removed, comfort came) — tactile transition from pain to grace. Both are *bodily*, not visual.
- Step 5: Choose option: Both A and R true, R correctly explains A.

ANSWER: Option: Both A and R are true, and R is the correct explanation of A. Justification: Raskhan's Pushti-Marg theology locates bhakti in the body's involuntary responses (prema as somatic). Hence his imagery prioritizes tactile-kinetic sensations (रोमांच, अश्रु, थकान-मुक्ति) over visual descriptions. Evidence 1: "उह्जत उस उस त्य चकस" — the body's hairs stand erect at the flute's call, showing divine summons as physical force. Evidence 2: "एघा लद्य वुजफक द्ज एव्यक" — exhaustion (tactile) is *removed* and comfort *arrives* (kinetic), portraying grace as bodily restoration. Visual images (e.g., "चित्र समान") exist but serve the somatic metaphor (gopi as picture/body), not independent contemplation.

DIFFICULTY: hard