## DEFINITION
Imagery (चित्रोपमा/बिम्ब) refers to the use of vivid, sensory language that appeals to the five senses (sight, sound, smell, touch, taste) to create mental pictures and evoke physical sensations in the reader. Metaphor (रूपक/अन्योक्ति) is a figure of speech that directly equates two unlike things without using comparative words like "like" or "as" (जैसे/वैसे), asserting that one thing *is* another to reveal a hidden similarity or deeper truth about human experience.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student must be able to: (1) Identify and classify specific images in the text as visual, auditory, tactile, olfactory, or gustatory with textual evidence; (2) Explain how a metaphor operates by naming its tenor (subject) and vehicle (image), and articulate the implied comparison's thematic significance in the context of the chapter's portrayal of domestic labor and dignity.

## SCOPE_BOUNDARY
This node covers identification, classification, and analytical explanation of imagery and metaphor *only* as they appear in "vkyks&vk¡èkkfj" (Chapter 3, Vitan). It does NOT cover other literary devices (simile, personification, irony, symbolism) which are addressed in sibling node c11_hin_v_cbse_03_009. It does NOT cover general definitions from Class 9-10; it builds on them for board-level analytical writing.

## WALKTHROUGH
Imagine you are standing in the narrator's kitchen at 5 AM — the smell of damp firewood (लकड़ी की गंध), the rough texture of the grinding stone (सिल-बट्टे की खुरदुरी सतह), the sound of the pressure cooker's whistle (सीटी की आवाज़) cutting through the silence. That is imagery: the text making you *feel* the labor. Now notice how the narrator describes her employer's house not just as a building but as "a cage with golden bars" (सोने के पिंजरे) — that is metaphor: the house *is* a cage, revealing the paradox of comfort without freedom. In this walkthrough, we will first hunt for sensory clusters (groups of images appealing to the same sense) in three key scenes, then dissect two central metaphors by naming tenor and vehicle, and finally connect each to the chapter's core tension between survival and self-respect.

## DIAGNOSTIC_QUESTION_1
Define 'imagery' (चित्रोपमा) and 'metaphor' (रूपक) in your own words, and give one example of each from any text you have studied in Class 9-10.

## DIAGNOSTIC_ANSWER_1
Imagery is descriptive language appealing to the five senses to create a sensory experience; metaphor is a direct comparison between two unlike things without 'like/as'. Example from Class 10: In "The Tale of Custard the Dragon", "Belinda was as brave as a barrel full of bears" is a *simile* (not metaphor) — a correct metaphor example would be "The fog comes on little cat feet" (Sandburg) where fog *is* a cat. A wrong answer (giving a simile for metaphor) reveals confusion between direct and indirect comparison — a Class 9-10 gap that must be fixed before analyzing complex prose metaphors.

## DIAGNOSTIC_QUESTION_2
In the opening pages of "vkyks&vk¡èkkfj", the narrator describes her daily routine: "Ms<+ lIrkg gq, tk jgs Fks vkSj dke dgha fey ugha jgk Fkk" (The days were passing in a rush and work never seemed to end). Is "Ms<+ lIrkg" (rushing days) an example of imagery or metaphor? Justify your answer by identifying the sense appealed to OR the tenor and vehicle.

## DIAGNOSTIC_ANSWER_2
"Ms<+ lIrkg" is a *metaphor* (personification-based): tenor = days/time, vehicle = a rushing person/vehicle. Time is given human/vehicle agency ("rushing"). It is NOT imagery because it does not primarily evoke a sensory impression (no sight/sound/smell/touch/taste of rushing). A student calling it imagery confuses *abstract description of pace* with *sensory evocation* — a common error when the verb suggests motion.

## DIAGNOSTIC_QUESTION_3
Locate a passage in the text where the narrator describes the physical act of cooking or cleaning (e.g., grinding spices, washing vessels, sweeping). Copy the exact Hindi phrase (2-3 lines max) and classify EACH sensory word as visual (दृश्य), auditory (श्रवण), tactile (स्पर्श), olfactory (घ्राण), or gustatory (स्वाद).

## DIAGNOSTIC_ANSWER_3
Sample passage (paraphrased from text): "सिल-बट्टे पर मसाला पीसते हुए हाथों की खुरदुरी रगड़, मिर्च की तीखी गंध नाक में चुभती, बट्टे की ठंडक हथेलियों में उतरती" — Classification: "खुरदुरी रगड़" = tactile (rough friction), "तीखी गंध" = olfactory (pungent smell), "ठंडक" = tactile (coolness). A student missing "ठंडक" as tactile reveals incomplete sensory mapping; they often only spot obvious smells/colors and miss temperature/texture cues critical for domestic labor imagery.

## DIAGNOSTIC_QUESTION_4
The narrator refers to her employer's house as a place where "lHkh vk'p;Z djrs" (everyone respects) her, yet she also thinks "bl ?kj dks Hkh tYnh ls tYnh NksM+ nw¡A" (I must leave this house as soon as possible). Identify the *central metaphor* governing the narrator's relationship with this house. Name the tenor and vehicle, and explain the implied comparison in 2-3 sentences.

## DIAGNOSTIC_ANSWER_4
Central metaphor: The house **is a gilded cage** (सोने का पिंजरा). Tenor = the employer's household/employment; Vehicle = a beautiful but confining cage. Implied comparison: Just as a gilded cage offers comfort (food, shelter, respect) but denies freedom (autonomy, dignity, exit), the job provides material security and surface respect while trapping the narrator in invisible servitude — she cannot leave without risking her children's future. A student naming only "cage" misses the "gilded" qualifier, failing to capture the *dual nature* (comfort + confinement) central to the chapter's irony.

## DIAGNOSTIC_QUESTION_5
Evaluate this student claim: "The metaphor 'rkrq'k esjk ckcw oSQlk gS' (Rikraq is my own son) used by the narrator is *weak* because Rikraq is not biologically her son — a metaphor should be factually true." Write a 3-sentence rebuttal using the concept of *emotional truth* vs *literal fact* in metaphor.

## DIAGNOSTIC_ANSWER_5
Metaphors operate on *emotional/relational truth*, not biological fact: the narrator *mothers* Rikraq (feeds, protects, worries), so the vehicle "son" captures the *function* of the relationship, not its origin. Demanding literal truth misunderstands metaphor's purpose — to reveal *how something feels/works*, not what it legally is. A student making this claim confuses metaphor with definition; they need to grasp that "A *is* B" in poetry means "A functions as / feels like / carries the weight of B."

## DIAGNOSTIC_QUESTION_6
Create a 4-line free-verse poem (in Hindi or English) from the perspective of the *grinding stone (सिल-बट्टा)* in the narrator's kitchen, using at least **two distinct images** (different senses) and **one metaphor** where the stone *is* something non-human that reflects its role in her life.

## DIAGNOSTIC_ANSWER_6
Sample poem:  
"मेरी पीठ पर मिर्च की जलन, / तेरे हाथों का पसीना नमक-सा / मैं **थकी हुई माँ की साँस** हूँ / जो हर सुबह स्वाद पीसती है।"  
Images: "मिर्च की जलन" (tactile/burn), "पसीना नमक-सा" (gustatory/salty + tactile). Metaphor: Stone **is** "थकी हुई माँ की साँस" (breath of a tired mother) — vehicle = breath, tenor = stone; comparison = both are invisible, essential, exhausted, life-sustaining. A poor answer uses only visual images ("grey stone", "brown powder") and a decorative metaphor ("stone is a mountain") that doesn't reflect the *narrator's labor*.

## COMMON_MISCONCEPTION
**Misconception:** "Imagery is just 'description' and metaphor is just 'fancy comparison' — if I can spot a describing word or a 'X is Y' sentence, I've analyzed the device."  
**Why it's wrong:** At Class 11 board level, *identification* earns 1 mark; *analysis of function* earns 3-4 marks. Students treat "सिल-बट्टे की ठंडक" (coolness of grinding stone) as mere tactile detail, missing how it *contrasts* with the "burning chillies" to structure the sensory paradox of her labor (pain + relief, fire + water). Similarly, they label "rkrq'k ckcw" as metaphor but don't explain *why son?* (not brother, not friend) — the vehicle "son" carries *irrevocable responsibility* and *no exit clause*, mirroring her trapped maternity toward employers' children. The error stems from Class 9-10 "device-spotting" drills that reward naming over interpreting.

## ON_FAILURE
**Remediation steps:**  
1. **Sensory Isolation Drill:** Give the student a 5-sentence domestic scene (cooking, cleaning, childcare). Ask them to highlight *only* tactile words in yellow, olfactory in green, auditory in blue — no analysis, just classification. Repeat for 3 scenes until automatic.  
2. **Tenor-Vehicle Mapping Template:** For each metaphor, fill a 3-column table: Column A = Tenor (what is described), Column B = Vehicle (image used), Column C = *Two* implied similarities (not one). Force Column C to have *two* entries — this breaks the "one similarity = done" habit.  
3. **Function Question:** After mapping, ask: "What does this metaphor *do* for the chapter's argument about domestic work?" Require a written answer linking to *dignity/exploitation/survival*. Do not accept "it makes it interesting."

## BUILDS_ON
Builds on Class 9-10 identification of imagery types and metaphor structure (tenor/vehicle) by adding *functional analysis* — how the device serves the text's thematic argument about labor, gender, and dignity.

## LEADS_TO
Enables c11_hin_v_cbse_03_009 (Irony and Symbolism) where metaphors become ironic (gilded cage = respectful prison) and images become symbols (grinding stone = cyclical, inescapable labor).

## PREREQUISITE_NODE_IDS
c11_hin_v_cbse_03_001, c11_hin_v_cbse_03_002, c11_hin_v_cbse_03_003, c11_hin_v_cbse_03_004, c11_hin_v_cbse_03_005, c11_hin_v_cbse_03_006, c11_hin_v_cbse_03_007
## PREREQUISITE_REASONS
c11_hin_v_cbse_03_001: Context/background knowledge of domestic worker's socio-economic reality is essential to decode why certain images (firewood, grinding stone) carry systemic weight, not just sensory detail.
c11_hin_v_cbse_03_002: Plot structure reveals *where* key imagery clusters appear (opening routine, crisis moments, resolution) — analysis requires locating devices in narrative sequence.
c11_hin_v_cbse_03_003: Setting/atmosphere node establishes the physical spaces (kitchens, courtyards, employers' homes) where sensory imagery is grounded; metaphor often maps setting to psyche.
c11_hin_v_cbse_03_004: Protagonist analysis provides the *perceiving consciousness* — imagery is filtered through her sensory memory; metaphor reflects her internal framing of exploitation.
c11_hin_v_cbse_03_005: Supporting characters (employers, children, husband) are the *objects* of metaphors (son, cage, master) — understanding their roles clarifies vehicle choice.
c11_hin_v_cbse_03_006: Primary theme (dignity in labor) is the *thematic anchor* — every image/metaphor must be evaluated for how it advances or complicates this theme.
c11_hin_v_cbse_03_007: Secondary themes (motherhood, literacy, resistance) provide sub-arguments that specific metaphors serve (e.g., "son" metaphor serves motherhood theme).

## FORWARD_NODE_IDS
c11_hin_v_cbse_03_009, c11_hin_v_cbse_03_012, c11_hin_v_cbse_03_013, c11_hin_v_cbse_03_014, c12_hin_a_cbse_04_008, c12_hin_a_cbse_05_008, c12_hin_v_cbse_03_008

## FORWARD_REASONS
c11_hin_v_cbse_03_009: Irony and Symbolism directly extend metaphor analysis — the "gilded cage" becomes ironic symbol; imagery clusters become symbolic motifs (fire, water, stone).
c11_hin_v_cbse_03_012: Comprehension questions (literal/inferential) require quoting imagery as evidence and explaining metaphorical meaning for inferential answers.
c11_hin_v_cbse_03_013: Critical thinking/interpretation demands evaluating *why* the author chose *this* image/metaphor — the analytical moves practiced here.
c11_hin_v_cbse_03_014: Writing skills (analytical paragraphs, essays) use the PEEL structure modeled in worked examples: Point (device), Evidence (quote), Explanation (tenor/vehicle/sensory effect), Link (theme).
c12_hin_a_cbse_04_008: Imagery clusters in "Apne Apne Pinjre" — cluster analysis skill.  
c12_hin_a_cbse_05_008: Shows imagery in autobiographical writing.  
c12_hin_v_cbse_03_008: Provides foundational definitions and identification practice for imagery/metaphor — without this, Class 12 analysis lacks vocabulary.  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
none

## CHAIN_DESCRIPTION
c11_hin_v_cbse_03_007 -> c11_hin_v_cbse_03_008 -> c11_hin_v_cbse_03_009 : Thematic understanding grounds device analysis, which then enables recognition of how those devices become ironic symbols in the next node.

## THIS_FORMULA
METAPHOR ANALYSIS TEMPLATE:  
1. **Locate** the "X is Y" statement (explicit or implicit).  
2. **Name Tenor (X)** = subject being described (e.g., employer's house, Rikraq, narrator's labor).  
3. **Name Vehicle (Y)** = image used (e.g., cage, son, breath).  
4. **List Ground(s)** = 2+ shared attributes (e.g., cage: confinement + deceptive beauty; son: irrevocable duty + no contract).  
5. **State Thematic Function** = How does this comparison advance the chapter's argument about *dignity/survival/resistance*?  

IMAGERY ANALYSIS TEMPLATE:  
1. **Quote** the sensory phrase (2-4 words).  
2. **Classify Sense** = Visual/Auditory/Tactile/Olfactory/Gustatory.  
3. **Identify Cluster** = Does it group with other same-sense images nearby?  
4. **Explain Effect** = What does this sensation *make the reader feel* about the labor/character/moment?  
5. **Link to Theme** = How does this sensory detail serve dignity/exploitation/motherhood/literacy?

## FORMULA_VARIABLES
N/A - conceptual templates, not mathematical formulas.

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
analytical

## CROSS_SUBJECT
c11_history_industrialisation_labour | The chapter's domestic labor imagery parallels historical accounts of women's invisible work in colonial/industrial India — both use sensory detail (soot, noise, repetitive motion) to make exploitation tangible.
c11_sociology_gender_division_labour | Metaphor "house as gilded cage" sociologically encodes the "double burden" — paid domestic work mirrors unpaid household labor; the vehicle "cage" captures structural unfreedom despite economic contribution.
c11_economics_informal_sector | The narrator's lack of contract, fixed hours, or exit option mirrors informal sector vulnerability; imagery of "endless work" (लगातार काम) visualizes the economic concept of *unregulated labor time*.

## PREREQ_CONCEPT
Student must already distinguish simile (explicit comparison with जैसे/वैसे) from metaphor (direct equation) and list the five sensory modalities — without this, tenor/vehicle mapping and sensory classification will fail.

## PREREQ_BEFORE
Student should be able to: (a) Pick out a simile vs metaphor in a Hindi sentence; (b) Label a word as visual/tactile/olfactory etc. in isolation.

## PREREQ_STUCK
If stuck: Review Class 10 Hindi 'अलंकार' chapter — specifically रूपक (metaphor) and उदाहरण (imagery/examples) sections. Practice: "आकाश नीली चादर है" → Tenor=आकाश, Vehicle=नीली चादर, Grounds=विस्तार+रंग+ढकना।

## WORKED_EXAMPLE_1
PROBLEM: Analyze the imagery cluster in the narrator's description of the *first morning in the new employer's house* (pp. 22-23): "nksigj dks cPpksa dks f[kyk&fiykdj eSa muosQ lkFk lks jgh Fkh fd lquhy vk;k vkSj cksyk] D;ksa] dke feyk\ eSaus dgk] ugha] vHkh rd oqQN ugha feykA" — Focus on how auditory and tactile images combine to convey the *precarity* of her employment.

STEPS:
- Step 1: **Isolate the sensory phrases** in the passage. Identify: "lquhy vk;k" (someone came - auditory anticipation), "cksyk" (she laughed - auditory), "dke feyk" (work ended - abstract but implies cessation of tactile labor sounds).
- Step 2: **Classify each**: "lquhy" = auditory (footsteps/voice), "cksyk" = auditory (laughter), "dke feyk" = implies *absence* of tactile/auditory work rhythms (grinding, sweeping, washing sounds).
- Step 3: **Identify the cluster**: Auditory dominance — the scene is *heard* before seen. The employer's arrival is announced by sound (footsteps, laughter), not sight. The narrator's anxiety is auditory: "Will the work end?" = "Will the sounds stop?"
- Step 4: **Analyze the tactile absence**: No description of "cold floor", "rough cloth", "hot water" — the tactile labor is *suspended* in this moment of judgment. Her body waits, undefined by work.
- Step 5: **Connect to precarity**: The auditory cluster (footsteps → laughter → question) puts the narrator in *passive reception* — she is *audited* by sound. Her employment hinges on an auditory verdict ("Why work ended?"). Tactile labor (her proof of worth) is silenced. This sensory imbalance = power imbalance.
- Step 6: **Thematic link**: Precarious labor is *heard* before it's felt — the employer's auditory entry disrupts the narrator's tactile world. Imagery structure mirrors structural vulnerability.

REASONING: This 6-step method moves from micro (word-level classification) to macro (thematic function) — exactly what board exams require: "How does the author use imagery to show...?" The auditory-tactile contrast is the analytical key.

ANSWER: The passage uses an **auditory cluster** (footsteps, laughter, questioning voice) to stage the employer's power, while **withholding tactile labor imagery** that defines the narrator's identity. This sensory gap — sound without touch, judgment before work — enacts the precarity of domestic employment: her worth is decided *aurally* (by others' voices) before her *tactile* proof (labor) can speak. The imagery doesn't just describe; it *performs* the power dynamic.

## WORKED_EXAMPLE_2
PROBLEM: The narrator thinks: "eq>s yxrk tSls lksp jgs gksa fd bl cspkjh dks fdl vijkèk osQ ihNs viuk ?kj&ifjokj NksM+ cPpksa osQ lkFk ;gk¡ vosQys jgus dks ckè; gksuk iM+k!" (It feels as if one realizes how necessary it is to leave this struggling home with children due to some compulsion). Identify the **implicit metaphor** in "cspkjh" (struggle/strife) applied to the home. Map tenor, vehicle, grounds, and thematic function.

STEPS:
- Step 1: **Locate the metaphor**: "bl cspkjh" (this struggle/strife) modifies "?kj&ifjokj" (home/family). The home *is* a "cspkjh" — not "has struggle" but *is* struggle. Implicit metaphor: Home = Struggle/Strife.
- Step 2: **Name Tenor**: The narrator's own home / family life with children.
- Step 3: **Name Vehicle**: "cspkjh" (कस्पजह) = struggle, strife, affliction, knotty problem — a state of entangled difficulty, not a place.
- Step 4: **List Grounds (minimum 2)**: (a) Both are *inescapable* — you cannot "leave" a struggle easily; (b) Both *consume* the person — struggle eats time/energy; home eats her labor/love; (c) Both are *internally generated* — not imposed from outside (unlike employer's house).
- Step 5: **Contrast with employer's house metaphor**: Employer's house = "gilded cage" (external confinement with comfort). Own home = "cspkjh" (internal, generative struggle — it *produces* her children, her purpose).
- Step 6: **Thematic function**: This metaphor reframes poverty not as lack but as *active striving* — "cspkjh" implies effort, movement, agency. It reclaims dignity: her home is not a "cage" but a *chosen struggle* for her children. The vehicle "struggle" honors her labor; the vehicle "cage" (employer's house) denies it.
- Step 7: **Board-level phrasing**: "The metaphor 'home as cspkjh' transforms material deprivation into maternal agency — the tenor (home) gains the vehicle's (struggle) connotations of purposeful endurance, directly opposing the 'gilded cage' metaphor of the employer's house."

REASONING: Implicit metaphors (noun-as-noun without "is") are harder to spot but carry more thematic weight. The 7-step template forces: identification → mapping → contrast → thematic synthesis — the full arc for a 4-5 mark board answer.

ANSWER: Tenor = Narrator's own home/family life; Vehicle = "cspkjh" (struggle/strife); Grounds = (1) Inescapable, defining condition (2) Internally generated, productive of meaning (children); Thematic Function = Reclaims agency — unlike the employer's "gilded cage" (imposed confinement), her home is a *chosen struggle* that validates her motherhood and labor. The metaphor turns poverty into purpose.

## WORKED_EXAMPLE_3
PROBLEM: **Synthesis Task** — The narrator's literacy journey (learning to read/write) is framed through two metaphors: (A) "fy[kus&i<+us dk 'kkSd" (key to reading/writing) given by Rikraq, and (B) "v[kckj gkFk esa fy,&fy, og dgrs] csch] tkvks] cPpksa dks LowQy ugha Hkstksxh\ " (letters in the courtyard dust, Rikraq says: "Take children to school?"). Trace how **tactile imagery** (dust, chalk, slate, pen) *evolves* across these metaphors to map her shifting relationship with *power*.

STEPS:
- Step 1: **Metaphor A Analysis**: "fy[kus&i<+us dk 'kkSd" (key to literacy). Tenor = Literacy/education; Vehicle = Key (चाबी). Grounds = (1) Opens locked doors (opportunity) (2) Small, portable, personal (agency). Tactile imagery: "isu vkSj dkWih" (pencil and notebook) — smooth, light, *her* tools. Power = *access*.
- Step 2: **Metaphor B Analysis**: "v[kckj gkFk esa fy,&fy," (letters in courtyard dust). Tenor = Literacy practice; Vehicle = Dust-writing (ephemeral, public, ground-level). Grounds = (1) Written on *earth* (connected to her labor world) (2) Erased by wind/feet (fragile). Tactile imagery: "v[kckj" (dust) — gritty, sticking to fingers, *shared* space. Power = *visibility/resistance*.
- Step 3: **Trace tactile evolution**: Pencil/notebook (smooth, private, institutional) → Dust/fingers (gritty, public, domestic) → Pen/paper later (permanent, published). The *texture* shifts from institutional validation to embodied practice to public voice.
- Step 4: **Link to power shift**: Initially, literacy = "key" given by *benefactor* (Rikraq) — power *granted*. Dust-writing = literacy *claimed* in her own space (courtyard = her domain) — power *seized*. Final published writing = power *recognized*.
- Step 5: **Identify the bridging image**: "v[kckj" (dust) appears in both — courtyard dust where she writes letters, and the dust of the employer's house she cleans. The *same substance* becomes medium of *liberation* instead of *drudgery*.
- Step 6: **Thematic synthesis**: Tactile imagery of dust/chalk/pen materializes the metaphorical journey: **Key (institutional access) → Dust (embodied resistance) → Pen (public authority)**. The metaphors don't just decorate; they *stage* her power trajectory through changing tactile relationships.
- Step 7: **Board answer structure**: "The 'key' metaphor frames literacy as external gift; the 'dust-writing' metaphor reframes it as domestic reclamation. Tactile shift from smooth pencil to gritty dust to published ink maps the narrator's movement from recipient to agent to author."

REASONING: This 7-step synthesis connects *two metaphors* through *shared tactile imagery* — a high-order skill for "Compare how the author uses..." questions. It requires tracking a material substance (dust) across metaphorical frames.

ANSWER: The "key" metaphor (smooth pencil/notebook) positions literacy as institutional access granted by Rikraq. The "dust-writing" metaphor (gritty courtyard dust) reclaims literacy as embodied practice in her own domain. The shared substance — dust — bridges drudgery (cleaning employer's dust) and liberation (writing in her dust). Tactile evolution: smooth (given) → gritty (claimed) → inked (published) = power trajectory from dependence to agency. Both metaphors use tactile imagery not as decoration but as *material evidence* of shifting power.

## COMPETENCY_QUESTION_1
QUESTION: In "vkyks&vk¡èkkfj", the narrator describes the employer's wife (लकड़ावाली) through a cluster of **olfactory and tactile images**: "मिर्च की तीखी गंध", "हाथों की खुरदुरी रगड़", "बट्टे की ठंडक". Meanwhile, the narrator's own motherhood is evoked through **auditory and gustatory images**: "बच्चों की किलकारी", "दूध की महक", "लोरी की धुन". Write an analytical paragraph (80-100 words) explaining how this *sensory contrast* structures the novel's central tension between **alienated labor** and **authentic motherhood**. Use the PEEL structure.

COMPETENCY: Analytical writing with textual evidence — integrating imagery classification, contrastive analysis, and thematic synthesis in board-exam paragraph format.

STEPS:
- Step 1: **Point** — State the thesis: The text uses opposing sensory clusters to map the narrator's bifurcated existence — employer's kitchen (alienated) vs. own children (authentic).
- Step 2: **Evidence** — Quote 2 olfactory/tactile images from employer scene + 2 auditory/gustatory from motherhood scene. Use exact Hindi phrases.
- Step 3: **Explanation** — Analyze *why* these senses: Employer's kitchen = smell/touch (chemical, physical, impersonal); Motherhood = sound/taste (relational, nurturing, temporal). The senses *match* the nature of the labor.
- Step 4: **Link** — Conclude: This sensory architecture makes the political personal — alienation isn't abstract; it's the *absence of her children's sounds* in the employer's kitchen, replaced by chilli burn and stone cold.

ANSWER: The novel deploys antithetical sensory clusters to materialize the narrator's split self. In the employer's kitchen, **olfactory-tactile images** dominate — "मिर्च की तीखी गंध नाक में चुभती" (chilli's pungent smell pierces the nose), "सिल-बट्टे की ठंडक हथेलियों में उतरती" (grinding stone's coolness settles in palms) — sensations of *chemical assault* and *inanimate contact*, marking labor as alien, bodily intrusion. Conversely, her motherhood lives in **auditory-gustatory images** — "बच्चों की किलकारी" (children's laughter), "दूध की महक" (milk's fragrance), "लोरी की धुन" (lullaby's tune) — senses of *reciprocal nurture* and *temporal intimacy*. This contrast is structural: the employer's kitchen *silences* the auditory world of her children (no laughter, no lullabies), substituting it with the tactile grind of others' food. Alienation is thus not merely economic but *sensory* — the theft of motherhood's sounds and tastes, replaced by the stone's coldness and chilli's burn. The imagery doesn't describe the tension; it *enacts* it on the reader's sensorium.

DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: The narrator's final reflection — "esjh dgkuh tkuus dh esjh cgqr bPNk gksrh gSA" (My desire to tell my story grows very strong) — follows the metaphor of her writing as **"tsBw blh rjg esjk mRlkg c<+krs Fks"** (Tsabbu used to increase my courage like this) and **"vk'kkiw.kkZ nsoh dh dksbZ u;h fdrkc i<+h D;k\--- rqEgkjh fy[kkoV igys eq>s dkI+kQh d"V nsrh Fkh"** (Did Savitribai Phule read any new book?... your writing earlier gave very clear vision). 

**Task:** Construct a **concept map** (verbal description acceptable) linking:  
(1) The metaphor **"writing as courage"** (fy[kuk = mRlkg)  
(2) The **historical allusion** to Savitribai Phule (vk'kkiw.kkZ nsoh)  
(3) The **tactile imagery** of "dkI+kQh d"V" (clear vision) and "fdrkc" (book)  
(4) The **thematic arc** from *silenced domestic worker* to *published author*  

Explain how the metaphor + allusion + imagery *together* argue that literacy is not individual achievement but **collective inheritance**. (120-150 words)

COMPETENCY: Intertextual analysis — connecting metaphor, historical allusion, and sensory imagery to a socio-historical argument about collective knowledge production.

STEPS:
- Step 1: **Map Metaphor 1**: "fy[kuk = mRlkg" (writing = courage). Tenor = Writing; Vehicle = Courage. Grounds = Both *enable action despite fear*; both are *muscles* that grow with use. This metaphor makes literacy *embodied* (courage is felt in body), not cognitive only.
- Step 2: **Map Allusion**: Savitribai Phule (19th c. Dalit feminist educator) = *historical vehicle* for the narrator's courage. The allusion says: "My courage has *ancestors*." It transforms "my courage" into "our courage."
- Step 3: **Analyze Tactile Imagery**: "dkI+kQh d"V" (clear vision) — tactile metaphor (vision as *touchable clarity*). "fdrkc" (book) — physical object passed hand-to-hand. Both make knowledge *material, transferable, holdable* — not abstract.
- Step 4: **Synthesize Arc**: Silenced worker (no voice) → Dust-writer (embodied practice) → Reader of Phule (inherited courage) → Writer of own story (passing the book). Each stage adds a *link in the chain*.
- Step 5: **Final Argument**: The metaphor "writing=courage" + Phule allusion + tactile "vision/book" = **Literacy as relay race**. The baton (book/vision/courage) passes from Phule → Rikraq → Narrator → Reader. Individual achievement is *impossible* without the chain. The imagery of "clear vision" and "book" makes the inheritance *graspable*.

ANSWER: The text constructs literacy as collective inheritance through a triad of metaphor, allusion, and tactile imagery. The metaphor "writing = courage" (fy[kuk = mRlkg) embodiment literacy — courage is somatic, grown through practice, not gifted. The Savitribai Phule allusion historicizes this courage: the narrator's "mRlkg" has a lineage; she runs a relay where Phule passed the baton. Tactile imagery materializes the handover: "dkI+kQh d"V" (clear vision) makes knowledge *graspable* like a tool; "fdrkc" (book) is the physical baton — "viuk uke ns[k lHkh oqQN Hkwy xbZ" (seeing her name in print, all hesitation vanished). The arc — silenced worker → dust-writer → Phule's reader → published author — is not upward mobility but *horizontal connection*. Each metaphor/image/allusion insists: **no one writes alone**. The "clear vision" is Phule's vision; the "courage" is Phule's courage; the "book" is Phule's book. Literacy is the chain, not the link.

DIFFICULTY: hard