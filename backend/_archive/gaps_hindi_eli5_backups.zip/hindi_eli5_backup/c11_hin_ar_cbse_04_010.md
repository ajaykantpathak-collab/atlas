## DEFINITION
Vocabulary in Context is the skill of determining the precise meaning of words and phrases as they are used in a specific literary text by analyzing surrounding clues (definitions, synonyms, antonyms, examples, tone, and syntax) rather than relying solely on dictionary definitions. In "फकीरचंद" (Chapter 4), this involves decoding archaic administrative terms (वायसराय, लॉर्ड कर्जन), satirical inversions (फटे जूते as status symbol), and culturally loaded references (नेपोलियन, वेलिंगटन) to grasp the author's irony.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student can independently identify 5+ key terms from the chapter, cite the exact textual context (sentence/paragraph) for each, explain how the context modifies the dictionary meaning, and demonstrate how the word contributes to the chapter's central satire on colonial bureaucracy.

## SCOPE_BOUNDARY
This node covers ONLY vocabulary from NCERT Class 11 Hindi Aroh Chapter 4 "फकीरचंद" (चंद्रधर शर्मा गुलेरी). It does NOT cover general vocabulary building strategies, words from other chapters, or grammar rules (covered in node 011). Focus is on context-dependent meaning shifts in a satirical colonial-era narrative.

## WALKTHROUGH
Imagine you are reading the opening paragraph where फकीरचंद's "फटे जूते" are described not with pity but with a strange pride. You pause at "वायसराय" and "लॉर्ड कर्जन" — you know they are British officials, but why does the narrator mention them alongside a poor man's shoes? Start by circling every word that feels "heavy" or "out of place" (फकीरचंद, फटे जूते, वायसराय, लॉर्ड मिंटो, नेपोलियन, व्यंग्य). For each, ask: "What is the dictionary meaning? What is the *situation* in the story when this word appears? Does the author use it straight or with a twist?" The key insight: in satire, words often wear masks — "फटे जूते" means broken footwear literally, but contextually it means *dignity surviving imperial humiliation*.

## DIAGNOSTIC_QUESTION_1
Define "Vocabulary in Context" and give one example from Chapter 4 where the contextual meaning of a word differs from its dictionary meaning.

## DIAGNOSTIC_ANSWER_1
Vocabulary in Context means deriving word meaning from textual clues (surrounding sentences, tone, irony, cultural references) rather than dictionary alone. Example: "फटे जूते" — dictionary: torn footwear; context: symbol of फकीरचंद's unbroken self-respect against colonial power. A wrong answer (e.g., "it means old shoes") reveals the student treats words as static labels, missing the satirical layer where objects become metaphors.

## DIAGNOSTIC_QUESTION_2
In the sentence "वायसराय के सामने फकीरचंद के फटे जूते एक चुनौती थे", explain why "चुनौती" (challenge) is used instead of "शर्म" (shame) or "गरीबी" (poverty). What contextual clues in the chapter support this?

## DIAGNOSTIC_ANSWER_2
"चुनौती" reframes poverty as resistance. Context clues: (1) फकीरचंद stands "सीना तानकर" (chest out) before the Viceroy, (2) the narrator calls the shoes "फकीरचंद की आन" (his honour), (3) the Viceroy's discomfort shows the shoes *threaten* imperial authority. A wrong answer ("चुनौती means difficulty") shows the student reads literally, missing how satire inverts vocabulary to turn weakness into weapon.

## DIAGNOSTIC_QUESTION_3
The text references "नेपोलियन" and "वेलिंगटन" when describing फकीरचंद's walk. Apply the "Example Context Clue" strategy: what specific comparison is the author making, and how does it change the meaning of "फटे जूते"?

## DIAGNOSTIC_ANSWER_3
Strategy: Locate the reference (Para 3: "नेपोलियन और वेलिंगटन के जूते भी..."). The author *exemplifies* फकीरचंद's walk by comparing it to conquerors' boots — but the twist: those boots were polished, his are torn. Meaning shift: "फटे जूते" → not lack of resources, but *rejection of colonial polish*. A wrong answer ("author compares him to great men") misses the irony: the comparison *heightens* the satire by showing a barefoot Indian out-dignifying boot-wearing emperors.

## DIAGNOSTIC_QUESTION_4
Analyze how the word "व्यंग्य" (satire/irony) functions as a *master key* for unlocking the contextual meanings of at least three other key words in the chapter (e.g., फकीरचंद, फटे जूते, वायसराय, लॉर्ड कर्जन).

## DIAGNOSTIC_ANSWER_4
"व्यंग्य" signals that *all* key words operate in inversion mode: (1) फकीरचंद (dictionary: beggar) → context: *moral emperor*; (2) फटे जूते (dictionary: poverty) → context: *medal of honour*; (3) वायसराय/लॉर्ड कर्जन (dictionary: supreme authority) → context: *helpless before a poor man's integrity*. A wrong answer listing dictionary meanings without the "व्यंग्य" lens reveals the student cannot see the chapter as a unified satirical system where vocabulary is weaponized.

## DIAGNOSTIC_QUESTION_5
Evaluate this student claim: "The word 'फकीरचंद' just means a poor man's name; knowing the dictionary meaning of 'फकीर' (beggar) is enough to understand the character." Defend or refute using textual evidence.

## DIAGNOSTIC_ANSWER_5
Refute. "फकीर" = beggar (dictionary), but contextual clues invert it: (1) He refuses the Viceroy's offer ("नहीं चाहिए"), (2) He lectures the Viceroy on duty ("तुम्हारा कर्तव्य है"), (3) The narrator calls him "इस देश का असली मालिक" (true owner of this land). The name "फकीरचंद" becomes *ironic honorific* — he owns nothing material but possesses the only sovereignty that matters: self-respect. A student accepting the claim fails to see how context *redefines* proper nouns in satire.

## DIAGNOSTIC_QUESTION_6
Create a 2-sentence "vocabulary profile" for the word "लॉर्ड मिंटो" as used in this chapter. Your profile must include: (a) dictionary meaning, (b) contextual meaning, (c) the specific textual clue that forces the shift, and (d) the satirical effect.

## DIAGNOSTIC_ANSWER_6
Dictionary: British Viceroy (1905-1910). Contextual: Symbol of *hollow imperial ritual* — he performs "दरबार" (court) but cannot comprehend a poor man's dignity. Clue: Para 4 — "लॉर्ड मिंटो ने पूछा... फकीरचंद ने उत्तर दिया... लॉर्ड मिंटो चुप रह गए" (Minto asked... Fakirchand answered... Minto fell silent). Satirical effect: The "Lord" is silenced by the "Fakir", exposing colonial authority as performative. A weak profile misses the *silence* as the key textual clue that flips the power dynamic.

## COMMON_MISCONCEPTION
Students believe "vocabulary in context" means "guess the meaning from nearby words" — so they look only at the immediate sentence. In this chapter, the context is *structural*: the entire satirical framework (colonial setting, narrator's voice, historical references) determines meaning. For example, "फटे जूते" in Para 1 looks like poverty description; only in Para 5 (when the Viceroy reacts) does it become "चुनौती". Students who stop at Para 1 write "old shoes" and miss the exam-critical irony.

## ON_FAILURE
1. **Re-read with "Satire Lens" on**: Tell the student: "Assume every noun is a metaphor. Re-read Para 1-5 asking: 'What is this object *really* doing in the story?'" 2. **Map the Power Flip**: Draw a two-column table: Column A = British words (वायसराय, लॉर्ड, दरबार, जूते-पॉलिश), Column B = Indian words (फकीरचंद, फटे जूते, आन, सीना). For each pair, find the sentence where Column B defeats Column A. 3. **Anchor in History**: Show a 2-minute video/image of 1903 Delhi Durbar — connect "लॉर्ड कर्जन" to real history so "व्यंग्य" becomes tangible, not abstract. 4. **Practice "Context Expansion"**: Give a target word (e.g., "नेपोलियन"); student must cite *three* different paragraphs where its meaning deepens.

## BUILDS_ON
c11_hin_ar_cbse_04_001 (Before You Read: Context and Background) — provides the colonial historical framework (Curzon, Minto, 1903 Durbar) without which "वायसराय" and "लॉर्ड" remain mere names.

## LEADS_TO
c11_hin_ar_cbse_04_011 (Grammar: Language Usage in the Text) — vocabulary mastery enables analyzing *how* grammatical choices (passive voice, honorifics, verb tense shifts) reinforce the satirical meaning of key words.

## PREREQUISITE_NODE_IDS
c11_hin_ar_cbse_04_001, c11_hin_ar_cbse_04_002, c11_hin_ar_cbse_04_008, c11_hin_ar_cbse_04_009, c11_hin_ar_cbse_04_007

## PREREQUISITE_REASONS
c11_hin_ar_cbse_04_001: Provides essential historical context (Curzon, Minto, 1903 Durbar) to decode administrative vocabulary.
c11_hin_ar_cbse_04_002: Establishes narrative sequence so student knows *when* each key word appears (plot-dependent meaning shifts).
c11_hin_ar_cbse_04_008: Imagery/Metaphor analysis trains the "contextual lens" needed to see words as symbols (e.g., जूते as metaphor).
c11_hin_ar_cbse_04_009: Irony/Symbolism understanding is prerequisite — this chapter's vocabulary *is* its irony.
c11_hin_ar_cbse_04_007: Vocabulary in context is tied to the 'linguistic resistance' theme.  

## FORWARD_NODE_IDS
c11_hin_ar_cbse_04_011, c11_hin_ar_cbse_04_012, c11_hin_ar_cbse_04_013, c11_hin_ar_cbse_04_014, c11_hin_ar_cbse_04_015, c12_hin_a_cbse_01_010, c12_hin_a_cbse_04_010, c12_hin_a_cbse_07_010, c12_hin_al_cbse_02_010, c12_hin_ar_cbse_04_010, c12_hin_ar_cbse_04_011, c12_hin_ar_cbse_12_010

## FORWARD_REASONS
c11_hin_ar_cbse_04_011: Grammar analysis requires precise word meanings (e.g., honorific verb forms for वायसराय vs. फकीरचंद).
c11_hin_ar_cbse_04_012: Comprehension questions (literal/inferential) test vocabulary-in-context directly (CBSE pattern).
c11_hin_ar_cbse_04_013: Critical interpretation builds on decoded vocabulary (e.g., "फटे जूते" as national symbol).
c11_hin_ar_cbse_04_014: Writing tasks (article, letter) demand using chapter vocabulary with contextual accuracy.
c11_hin_ar_cbse_04_015: Discussion points require articulating nuanced word meanings (e.g., "What does 'फकीरचंद' represent?").
c12_hin_a_cbse_01_010: Developed 'vocabulary card' technique for revision — used in ON_FAILURE remediation.  
c12_hin_a_cbse_04_010: Class 11 Antra Vocabulary node established the *method* of context-based meaning (denotation vs connotation).  
c12_hin_a_cbse_07_010: Exposure to regional vocabulary in classical poets (Kabir, Surdas).  
c12_hin_al_cbse_02_010: Experience with onomatopoeia in descriptive passages.  
c12_hin_ar_cbse_04_010: Class 11 vocabulary-in-context baseline — identifies context-clue types (def, contrast, example, inference) used here.  
c12_hin_ar_cbse_04_011: Class 11 vocabulary node ensures familiarity with key lexical items that carry grammatical features (e.g., honorific pronouns).  
c12_hin_ar_cbse_12_010: Built stamina for multi-step contextual inference across longer passages.  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
No prior class nodes available for cross-subject links in Hindi Aroh.

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_04_001 -> c11_hin_ar_cbse_04_010 -> c11_hin_ar_cbse_04_011: Historical context enables vocabulary decoding, which enables grammatical analysis of satirical language.

## THIS_FORMULA
Context Clue Strategy (5 Types): 1. Definition/Restatement (author defines word), 2. Synonym (nearby word with similar meaning), 3. Antonym/Contrast (signal words: लेकिन, परंतु, बल्कि), 4. Example/Illustration (उदाहरणार्थ, जैसे), 5. Inference/Tone (overall mood, irony, satire) — **Inference is primary for this chapter.**

## FORMULA_VARIABLES
N/A - conceptual strategy, not mathematical formula

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
linguistic

## CROSS_SUBJECT
c11_history_colonialism | The chapter's vocabulary (वायसराय, लॉर्ड कर्जन, दरबार, 1903 डरबार) directly references British colonial administration; understanding the historical reality (Curzon's partition of Bengal, Durbar pageantry) is essential to grasp the satirical inversion of these terms.
c11_politicalscience_power_authority | The central conflict — फकीरचंद's "फटे जूते" challenging वायसराय's authority — illustrates the political theory distinction between *coercive power* (British state) and *moral authority* (colonized subject's dignity), a core Class 11 PolSc concept.

## PREREQ_CONCEPT
Historical context of 1903 Delhi Durbar and Lord Curzon's viceroyalty — without this, "वायसराय", "लॉर्ड कर्जन", "डरबार" are empty labels.

## PREREQ_BEFORE
Student must know: (1) Who was Lord Curzon? (2) What was the 1903 Delhi Durbar? (3) Basic meaning of "व्यंग्य" (satire) as a literary mode.

## PREREQ_STUCK
If stuck, review "Before You Read" (node 001) section on "Historical Background: 1903 Delhi Durbar and Curzon's Policies" — specifically the contrast between imperial spectacle and Indian poverty.

## WORKED_EXAMPLE_1
PROBLEM: Determine the contextual meaning of "आन" (honour/dignity) in the sentence: "फकीरचंद के फटे जूते उसकी आन थे, उसकी शान थे।" (Fakirchand's torn shoes were his honour, his pride.) Use the 5-step Context Clue Strategy.

STEPS:
- Step 1: Identify the target word ("आन") and its immediate syntactic context — predicate nominative after "थे", parallel to "शान" (pride/glory). Dictionary meaning: honour, dignity, self-respect.
- Step 2: Scan for Definition/Restatement clues — none explicit. Scan for Synonym — "शान" is a synonym in standard Hindi, but here both are *elevated* nouns applied to "फटे जूते" (torn shoes), creating semantic tension.
- Step 3: Apply Antonym/Contrast clue — Chapter's central contrast: Viceroy's polished boots vs. Fakirchand's torn shoes. The Viceroy has "शान" (imperial splendour) but loses "आन" (moral dignity) when silenced. Fakirchand has no "शान" but retains "आन".
- Step 4: Use Example/Illustration clue — Para 3: "नेपोलियन और वेलिंगटन के जूते भी..." compares Fakirchand's walk to conquerors. The *example* of emperors' boots illustrates that "आन" resides in the *walker*, not the footwear.
- Step 5: Apply Inference/Tone (Satire) — The narrator's voice is ironic: he *knows* shoes don't confer honour, yet *asserts* they do. This irony forces "आन" to mean: *self-generated dignity that no external power can strip*.

REASONING: The 5-step strategy moves from local (sentence) to global (chapter satire). Steps 1-2 fail alone because "आन = शान" is a circular synonym. Step 3 (contrast) cracks the code by linking to the colonial power dynamic. Step 4 (historical example) deepens it. Step 5 (satire tone) finalizes the contextual meaning as *resistance*.

ANSWER: Contextual meaning of "आन" = "Inner moral sovereignty that transforms material lack (टूटे जूते) into spiritual victory over colonial power." Not just "honour" — specifically *honour that colonizers cannot confiscate*.

## WORKED_EXAMPLE_2
PROBLEM: The word "डरबार" (Durbar/Court) appears in Para 2: "लॉर्ड कर्जन के डरबार में..." and Para 5: "फकीरचंद का डरबार...". Explain the contextual shift using the Inference/Tone strategy.

STEPS:
- Step 1: Locate both occurrences. Occurrence 1: "लॉर्ड कर्जन के डरबार में" — standard historical reference to 1903 Imperial Durbar. Occurrence 2: "फकीरचंद का डरबार" — narrator's metaphorical coinage.
- Step 2: Dictionary meaning: Royal court, ceremonial assembly. Context 1 fits dictionary; Context 2 violates it (a beggar has no court).
- Step 3: Identify the satirical signal — "फकीरचंद का डरबार" follows his refusal of Viceroy's charity and his lecture on duty. The *tone* shifts from descriptive to admiring-ironic.
- Step 4: Map the inversion — Curzon's Durbar: 1000s of princes, jewels, obeisance, British supremacy performed. Fakirchand's Durbar: 1 man, torn shoes, *he* commands silence, *he* defines duty. The word "डरबार" is *transferred* from oppressor to oppressed.
- Step 5: Articulate the shift — Context 1: "डरबार" = *ritual of subjugation* (Indians bow to British). Context 2: "डरबार" = *arena of moral judgment* (Indian judges British). The same word now means "space where true sovereignty resides."

REASONING: This is a "structural context clue" — the meaning shift occurs across paragraphs, not within one sentence. The satire *requires* the reader to hold both meanings simultaneously and feel the inversion. Standard "guess from nearby words" fails here; only the Inference/Tone strategy (Step 5) captures it.

ANSWER: "डरबार" shifts from "British imperial pageantry masking exploitation" to "the moral court where a colonized man's integrity tries the empire." The shift *is* the chapter's thesis.

## WORKED_EXAMPLE_3
PROBLEM: A Board exam question asks: "Explain how the contextual meaning of 'फकीरचंद' evolves from Para 1 to Para 6. Support with two textual evidences." Write a structured 4-point answer (PEEL format).

STEPS:
- Step 1: **Point** — "फकीरचंद" shifts from a proper noun denoting a destitute individual to a symbolic noun denoting *colonized India's indomitable self-respect*.
- Step 2: **Evidence 1 (Para 1-2)** — "फकीरचंद... फटे जूते पहने... भीख मांगता था" — dictionary-aligned meaning: literal beggar, object of pity. Context: Colonial gaze sees only poverty.
- Step 3: **Evidence 2 (Para 5-6)** — "फकीरचंद ने कहा... 'तुम्हारा कर्तव्य है...' लॉर्ड मिंटो चुप रह गए" — contextual meaning: moral sovereign who *commands* the Viceroy's silence. The name now carries the weight of "फकीर" (renunciant) + "चंद" (moon/light) → *light of renunciation*.
- Step 4: **Explanation** — The evolution is driven by the narrator's satirical reframing. Each paragraph adds a layer: Para 1 (colonial view), Para 3 (historical comparison to Napoleon), Para 4 (verbal duel), Para 5 (moral victory). The name accumulates meaning like a snowball.
- Step 5: **Link** — This evolution mirrors the chapter's arc: from colonial object to anti-colonial subject. "फकीरचंद" becomes a *concept* — any Indian who refuses to be defined by colonial categories.
- Step 6: **Exam Polish** — Use PEEL: Point (thesis), Evidence (quotes), Explanation (analysis), Link (theme). Board markers look for: (a) two distinct paragraphs cited, (b) "contextual meaning" phrase used, (c) connection to satire/colonialism.

REASONING: Board questions on vocabulary-in-context require *diachronic* analysis (meaning change across text), not static definition. The 6-step process ensures: thesis clarity, textual anchoring, analytical depth, and thematic linkage — the exact CBSE marking scheme for 3-4 mark questions.

ANSWER: [Model Answer] "फकीरचंद" evolves from a label of poverty to a symbol of moral sovereignty. In Para 1, he is "फटे जूते पहने भीख मांगता" — the colonial gaze reduces him to lack. By Para 6, he dictates duty to the Viceroy ("तुम्हारा कर्तव्य है"), silencing imperial authority. Evidence 1: "फकीरचंद के फटे जूते उसकी आन थे" (Para 1) — narrator *reclaims* the shoes as honour. Evidence 2: "लॉर्ड मिंटो चुप रह गए" (Para 5) — the name now commands the empire's silence. The satirical tone transforms "फकीर" (beggar) into "फकीर" (renunciant of colonial validation). Link: The name embodies the chapter's message — true power lies in self-definition, not imperial recognition.

## COMPETENCY_QUESTION_1
QUESTION: The word "व्यंग्य" (satire) appears in the chapter's end-of-text glossary but *not* in the main narrative. Yet every key word (फकीरचंद, फटे जूते, वायसराय, डरबार) functions *only* because of satire. Explain how a reader detects the "invisible satire" through vocabulary shifts alone. Give two specific words and their pre-satire vs. post-satire meanings.

COMPETENCY: Literary Analysis / Metacognitive Reading

STEPS:
- Step 1: Define "invisible satire" — satire not announced by explicit markers (like "व्यंग्यार्थ") but embedded in lexical choices.
- Step 2: Select Word 1: "वायसराय". Pre-satire (dictionary/historical): Supreme colonial authority. Post-satire (contextual): Helpless performer, silenced by a beggar. Detection clue: Verb shift — "पूछा" (asked) → "चुप रह गए" (fell silent).
- Step 3: Select Word 2: "फटे जूते". Pre-satire: Material deprivation. Post-satire: Moral armour. Detection clue: Noun modification — "फटे जूते" → "आन", "शान", "चुनौती" (honour, pride, challenge).
- Step 4: Synthesize — The reader detects satire by tracking *collocational clash*: words that "don't belong together" (beggar + honour, Viceroy + silence) forced into proximity by the narrator.

ANSWER: Satire is detected through *semantic collision* — the narrator places words in contexts where their dictionary meanings clash, forcing new meanings. (1) "वायसराय": Dictionary = power; Context = powerlessness (silenced by Fakirchand). Clue: "लॉर्ड मिंटो चुप रह गए" — the ultimate power performs powerlessness. (2) "फटे जूते": Dictionary = shame; Context = sovereignty. Clue: "फकीरचंद के फटे जूते उसकी आन थे" — the narrator *asserts* the opposite of dictionary logic. The reader realizes: *when the narrator calls rags "honour", satire is the only grammar that makes sense.*

DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: A Class 11 student writes in the exam: "The author uses difficult words like 'वायसराय', 'लॉर्ड कर्जन', 'नेपोलियन' to show his knowledge." Critique this answer using vocabulary-in-context principles. Then rewrite the answer to score full marks (3/3) for a question: "How do historical references function as vocabulary tools in the chapter?"

COMPETENCY: Critical Evaluation / Exam Answer Writing

STEPS:
- Step 1: **Critique** — The student's answer fails because: (a) It treats vocabulary as *display* (author's knowledge) not *function* (meaning-making). (b) It ignores *context* — these words are not "difficult"; they are *strategically chosen* for their cultural weight. (c) It misses *satire* — the references work by *contrast* (Napoleon's boots vs. Fakirchand's torn shoes), not by impressing the reader.
- Step 2: **Principle** — In this chapter, historical references are *contextual definers*: they provide the "Example Clue" that calibrates the meaning of Indian words (फकीरचंद, फटे जूते).
- Step 3: **Rewrite Structure (PEEL)** — Point: Historical references (नेपोलियन, वेलिंगटन, लॉर्ड कर्जन) serve as *satirical yardsticks* to measure the moral stature of Indian characters. Evidence: "नेपोलियन और वेलिंगटन के जूते भी... फकीरचंद की चाल के सामने फीके पड़ते थे" — the conquerors' boots become the *standard* that Fakirchand's bare feet *exceed*. Explanation: The references are not decoration; they create a *comparative context* where "फटे जूते" > "सम्राटों के जूते". Link: This vocabulary strategy enacts the chapter's thesis — colonial grandeur is hollow; Indian dignity is substantive.
- Step 4: **Exam Polish** — Use terms: "satirical yardstick", "comparative context", "semantic inversion". Quote the exact phrase. Connect to theme.

ANSWER: [Critique] The student's answer reflects a "vocabulary as decoration" misconception — it assumes the author's intent is lexical showmanship. In reality, Guleri uses historical references as *contextual tools* to redefine Indian words through ironic comparison. [Rewritten Full-Mark Answer] Historical references function as **satirical yardsticks** that recalibrate the meaning of indigenous vocabulary. When the narrator compares फकीरचंद's walk to "नेपोलियन और वेलिंगटन के जूते", he does not merely invoke history; he establishes a **comparative context** where the *absence* of boots (फटे जूते) signifies *superior* moral authority. The Viceroy's "लॉर्ड कर्जन" and "लॉर्ड मिंटो" references similarly create a **semantic inversion**: the highest imperial titles become markers of *moral smallness* when juxtaposed with फकीरचंद's silent dignity. Thus, these "difficult words" are not the author's vocabulary display — they are the *measure* against which the chapter redefines "आन", "शान", and "संप्रभुता" (sovereignty) for a colonized people.

DIFFICULTY: hard