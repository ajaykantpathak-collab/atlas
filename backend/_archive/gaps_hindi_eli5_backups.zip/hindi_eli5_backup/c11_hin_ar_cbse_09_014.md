## DEFINITION
Writing Skills: Based on the Chapter refers to the ability to compose structured, evidence-based responses (short answers, long answers, critical appreciations, and creative pieces like articles or speeches) that demonstrate deep understanding of the chapter's themes, characters, literary devices, and socio-historical context, using appropriate vocabulary, grammar, and the PEEL (Point, Evidence, Explanation, Link) framework.

## COGNITIVE_LEVEL
apply

## MASTERY_CRITERIA
The student can independently write a coherent 100-150 word long-answer response to a board-style question on the chapter, employing the PEEL structure with at least two specific textual references (paraphrased or quoted), analysis of one literary device, and a concluding link to the central theme, within 10 minutes.

## SCOPE_BOUNDARY
This node covers answer writing for literature questions (prose/poetry analysis, character sketches, theme exploration) and creative writing tasks (article, speech, diary entry) directly inspired by Chapter 9's themes of nationalism, poetic craft, and Dinkar's life. It does NOT cover formal letter writing formats, report writing, or unrelated creative writing topics outside the chapter's scope.

## WALKTHROUGH
Imagine you are in the Class 11 board exam and the question reads: "How does Dinkar use the metaphor of 'fire' to depict the poet's role in society? Answer in 120 words." You remember the poem but feel stuck on how to start and structure the answer. First, deconstruct the question: identify the key terms (metaphor, fire, poet's role, society). Second, recall specific lines from the poem where fire imagery appears (e.g., the poet as a spark that ignites change). Third, draft a Point sentence: "Dinkar portrays the poet as a transformative fire." Fourth, provide Evidence: reference the line about the poet's word being a spark. Fifth, Explain: analyze how fire symbolizes purification and revolution. Sixth, Link: connect to the theme of social awakening. This step-by-step PEEL process turns panic into a clear plan.

## DIAGNOSTIC_QUESTION_1
What does the acronym PEEL stand for in the context of writing literature answers?

## DIAGNOSTIC_ANSWER_1
PEEL stands for Point, Evidence, Explanation, Link. A wrong answer (e.g., "Paragraph, Example, Explain, Line") reveals the student lacks the fundamental structural vocabulary for answer writing and will produce disorganized, narrative responses instead of analytical arguments.

## DIAGNOSTIC_QUESTION_2
A student writes: "Dinkar was a great poet. He wrote about fire. It shows he liked freedom." Identify the two specific PEEL components missing from this response.

## DIAGNOSTIC_ANSWER_2
The response lacks **Evidence** (no specific textual reference or quoted line) and **Explanation** (no analysis of *how* the fire metaphor works or *why* it represents freedom). A wrong answer like "It misses Introduction and Conclusion" shows the student confuses essay structure with analytical paragraph structure.

## DIAGNOSTIC_QUESTION_3
Apply the PEEL structure to answer: "Explain the significance of the line 'cu iM+s rks lh/s&lh/s ugha rks njsjk nsdjA' in understanding Dinkar's poetic philosophy." Write only the **Point** and **Evidence** steps.

## DIAGNOSTIC_ANSWER_3
**Point:** The line encapsulates Dinkar's belief in the poet's duty to speak truth fearlessly regardless of consequences. **Evidence:** The couplet "cu iM+s rks lh/s&lh/s ugha rks njsjk nsdjA" (If you speak the truth, don't stammer; otherwise, stay silent) directly commands unambiguous courage. A wrong answer providing only a summary ("Dinkar says speak truth") misses the *command* tone and the binary choice presented, failing to isolate the textual evidence.

## DIAGNOSTIC_QUESTION_4
Compare the writing demands of a "Character Sketch of Dinkar" (5 marks) vs. "Critical Appreciation of the Poem" (5 marks). Analyze how the **Evidence** step differs in each.

## DIAGNOSTIC_ANSWER_4
In a Character Sketch, Evidence consists of **biographical facts and behavioral traits** from the prose background (e.g., "He studied Sanskrit and Persian," "He was called 'Kavi Kokil'"). In Critical Appreciation, Evidence must be **textual/poetic elements** (e.g., "The rhyme scheme AABB creates momentum," "The metaphor 'dk'kh dk tqykgk'"). A student using biographical facts in a poetry appreciation answer reveals inability to distinguish text-types and their respective evidence bases.

## DIAGNOSTIC_QUESTION_5
Evaluate this student's Link sentence for a theme-based answer: "Thus, Dinkar's poem shows nationalism is good." Is this an effective Link? Justify your evaluation.

## DIAGNOSTIC_ANSWER_5
**No, it is ineffective.** An effective Link must synthesize the Explanation back to the *specific question focus* using precise terminology. "Nationalism is good" is a vague, reductive generalization. A strong Link would be: "Thus, through the fire metaphor and imperative tone, Dinkar frames the poet as the conscience of the nation, transforming personal courage into collective awakening." A student defending the weak link confuses *theme statement* with *analytical synthesis*.

## DIAGNOSTIC_QUESTION_6
Create a 50-word diary entry from Dinkar's perspective on the night he decided to write "Hunkar," using **two** vocabulary words from the chapter (e.g., 'lohd`fr', 'vfHkO;fDr') and **one** literary device (simile/metaphor).

## DIAGNOSTIC_ANSWER_6
**Sample:** "Tonight, the **lohd`fr** (restlessness) in my veins burns like a **dk'kh dk tqykgk** (spark of fire). I cannot stay silent; my **vfHkO;fDr** (creative impulse) demands I give voice to the voiceless. The pen feels heavy, yet it is the only weapon." **Criteria:** Uses two target vocab words correctly in context, employs a simile ("like a spark"), and adopts first-person persona. A poor entry uses vocab mechanically without emotional context or misses the device.

## COMMON_MISCONCEPTION
Students believe "Writing Skills" means memorizing model answers for predicted questions. They treat the chapter as a set of facts to reproduce rather than a toolkit of themes, devices, and vocabulary to *construct* answers. For example, when asked "Discuss irony in the poem," a student reproduces a memorized paragraph on *theme* because they cannot *apply* the irony concept to the specific text. This stems from Class 10 rote-learning habits where questions were repetitive; Class 11 demands transferable analytical skills.

## ON_FAILURE
1. **Deconstruct the Prompt:** Give the student 3 past board questions. Have them highlight *command words* (analyze, discuss, justify) and *content words* (irony, Dinkar, nationalism) in two colors. 2. **Evidence Hunt:** For one question, set a 5-minute timer to find 3 exact textual references (line numbers/paraphrases) – no writing, just hunting. 3. **Oral PEEL:** Student explains the answer *orally* using PEEL steps while you scribe. 4. **Sentence Stems:** Provide stems: "The poet uses [device] to show..." / "This is evident in the line..." / "This reveals..." / "Therefore, [theme]..." Student completes stems in writing. 5. **Peer Compare:** Show a weak vs. strong answer (same content); student identifies PEEL differences using a checklist.

## BUILDS_ON
Deep comprehension of the chapter's themes (Nationalism, Poet's Duty), literary devices (Metaphor, Symbolism), and vocabulary (lohd`fr, vfHkO;fDr) from prior nodes.

## LEADS_TO
Speaking and Listening (c11_hin_ar_cbse_09_015) where students orally defend interpretations using the same PEEL structure and textual evidence practiced here.

## PREREQUISITE_NODE_IDS
c11_hin_ar_cbse_09_006, c11_hin_ar_cbse_09_008, c11_hin_ar_cbse_09_010, c11_hin_ar_cbse_09_012, c11_hin_ar_cbse_09_013, c11_hin_ar_cbse_09_009

## PREREQUISITE_REASONS
c11_hin_ar_cbse_09_006: Primary theme (Nationalism/Poet's Duty) provides the core argument for any long answer.
c11_hin_ar_cbse_09_008: Literary devices (Metaphor, Symbolism) are the analytical tools required for Explanation step.
c11_hin_ar_cbse_09_010: Key vocabulary (lohd`fr, vfHkO;fDr, tqykgk) enables precise, high-scoring expression.
c11_hin_ar_cbse_09_012: Literal/Inferential comprehension ensures accurate Evidence selection from text.
c11_hin_ar_cbse_09_013: Critical thinking provides the analytical depth for Explanation and Link steps.
c11_hin_ar_cbse_09_009: Writing tasks (analytical paragraph, essay) require using irony/symbolism as evidence for thematic claims.  

## FORWARD_NODE_IDS
c11_hin_ar_cbse_09_015
## FORWARD_REASONS
c11_hin_ar_cbse_09_015: Speaking and Listening requires students to articulate the same structured arguments (Point, Evidence, Explanation) orally in discussions and presentations, transferring written PEEL skills to verbal format.

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
none

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_09_012 -> c11_hin_ar_cbse_09_014 -> c11_hin_ar_cbse_09_015: Comprehension provides textual evidence; Writing Skills structures it into answers; Speaking and Listening transfers the structure to oral defense.

## THIS_FORMULA
PEEL Structure: **P**oint (Direct answer to question) -> **E**vidence (Specific textual reference) -> **E**xplanation (Analysis of device/meaning) -> **L**ink (Connection to theme/question)

## FORMULA_VARIABLES
P = Topic sentence answering the specific question keyword; E = Quote/paraphrase from poem/prose with location context; E = Analysis of literary technique/effect/author intent; L = Synthesis sentence tying back to central theme/question focus.

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
linguistic

## CROSS_SUBJECT
c11_history_nationalism | The chapter's theme of poetic nationalism parallels the History chapter on "Nationalism in India" where literature (Bankim, Tagore, Dinkar) fueled collective identity; students can use historical context as Evidence in answers.
c11_civics_freedom_of_expression | Dinkar's line "cu iM+s rks lh/s&lh/s ugha" embodies the Civics concept of Freedom of Speech (Article 19); students can link the poet's duty to constitutional rights in creative writing tasks.

## PREREQ_CONCEPT
PEEL paragraph structure and ability to locate textual evidence in a poem/prose.

## PREREQ_BEFORE
Student must be able to identify the central theme of the chapter and locate at least three literary devices with line references.

## PREREQ_STUCK
Review c11_hin_ar_cbse_09_008 (Literary Devices) and c11_hin_ar_cbse_09_012 (Comprehension) to rebuild evidence-location and device-analysis skills.

## WORKED_EXAMPLE_1
PROBLEM: Write a 100-word answer: "Analyze how Dinkar uses the metaphor of 'fire' to depict the poet's role in the poem." (Board 5-marker pattern)
STEPS:
- Step 1: Deconstruct question – Key terms: "metaphor of fire", "poet's role", "analyze" (requires device + effect).
- Step 2: Recall evidence – Identify fire imagery: "dk'kh dk tqykgk" (spark of fire), "lohd`fr" (restlessness as burning), the poet's word as "aag" (fire) that awakens.
- Step 3: Draft Point – "Dinkar employs the extended metaphor of fire to portray the poet as a revolutionary purifier of society."
- Step 4: Insert Evidence – "In the line describing the poet as 'dk'kh dk tqykgk', the 'spark' signifies latent revolutionary energy."
- Step 5: Write Explanation – "Fire destroys stagnation (old customs) and illuminates darkness (ignorance). The metaphor transforms the poet from a mere singer to an agent of social combustion."
- Step 6: Craft Link – "Thus, fire becomes the symbol of the poet's duty to ignite national consciousness, making poetry an act of moral courage."
REASONING: The PEEL structure forces analytical depth: Point answers "what", Evidence answers "where", Explanation answers "how/why", Link answers "so what". This mirrors the board marking scheme (1 mark each for Point, Evidence, Explanation, Link, Language).
ANSWER: Dinkar employs the extended metaphor of fire to portray the poet as a revolutionary purifier of society. In the line describing the poet as 'dk'kh dk tqykgk' (spark of fire), the 'spark' signifies latent revolutionary energy. Fire destroys stagnation (outworn traditions) and illuminates darkness (ignorance/apathy). The metaphor transforms the poet from a mere entertainer into an agent of social combustion – one who burns away falsehood. Thus, fire becomes the symbol of the poet's duty to ignite national consciousness, making poetry an act of moral courage rather than aesthetic pleasure. (98 words)

## WORKED_EXAMPLE_2
PROBLEM: Convert this weak answer into a strong PEEL response: "Dinkar was a nationalist poet. He wrote Hunkar. It inspired people. He used Sanskrit words. He is great." (Target: 80 words on "Dinkar's poetic style reflects his nationalist ideology.")
STEPS:
- Step 1: Diagnose weaknesses – The weak answer is a list of facts (biography, titles) with zero textual analysis, no device mention, no vocabulary, no PEEL structure.
- Step 2: Identify required content – Question asks for "poetic style" + "nationalist ideology". Need: Sanskritized vocabulary (style), imperative tone (style), fire metaphor (device), specific poem reference (evidence).
- Step 3: Draft Point – "Dinkar's Sanskritized diction and imperative tone fuse classical gravitas with nationalist urgency."
- Step 4: Select Evidence – "The couplet 'cu iM+s rks lh/s&lh/s ugha rks njsjk nsdjA' uses pure Sanskrit vocabulary (cu, iM+s, njsjk) and command syntax."
- Step 5: Write Explanation – "The Sanskritic register invokes cultural heritage; the imperative mood ('nsdj' – stay silent) demands binary moral choice, mirroring the freedom struggle's 'Do or Die' ethos."
- Step 6: Craft Link – "Therefore, style becomes ideology: the poet wields language itself as a weapon for national awakening."
REASONING: This models the "upgrade" process: from factual recall to analytical argument. The steps show how to map chapter content (vocabulary from node 010, devices from node 008, theme from node 006) onto the PEEL frame.
ANSWER: Dinkar's Sanskritized diction and imperative tone fuse classical gravitas with nationalist urgency. The couplet 'cu iM+s rks lh/s&lh/s ugha rks njsjk nsdjA' employs pure Sanskrit vocabulary (cu, iM+s, njsjk) and command syntax. The Sanskritic register invokes India's cultural heritage; the imperative mood ('nsdj' – stay silent) demands a binary moral choice, mirroring the freedom struggle's 'Do or Die' ethos. Therefore, style becomes ideology: the poet wields language itself as a weapon for national awakening. (82 words)

## WORKED_EXAMPLE_3
PROBLEM: Write a 120-word speech for morning assembly: "The Relevance of Dinkar's Poetry for Today's Youth," using **three** chapter elements: (1) a theme, (2) a literary device, (3) a vocabulary word.
STEPS:
- Step 1: Analyze task – Format: Speech (salutation, opening, body, conclusion). Audience: Youth. Constraint: Integrate 3 specific chapter elements naturally.
- Step 2: Select elements – Theme: Poet as nation's conscience (node 006). Device: Irony of "silence being louder than words" (node 009). Vocab: 'lohd`fr' (restlessness/urge) (node 010).
- Step 3: Outline PEEL-based body paragraphs – Para 1 (Theme): Dinkar's poet = today's activist. Para 2 (Device): Irony of silence = complicity. Para 3 (Vocab): 'Lohd`fr' as catalyst for action.
- Step 4: Draft with rhetorical devices – Use anaphora ("When... When... Then..."), direct address ("Friends"), and the chosen elements.
- Step 5: Verify constraints – Count words, check 3 elements included, ensure speech tone (not essay).
- Step 6: Polish language – Replace "Dinkar said" with "Dinkar roars"; ensure Hindi vocabulary used in English/Hindi bilingual flow as per CBSE Hindi exam norms.
REASONING: Creative writing tasks test *transfer* of analytical knowledge into a new genre. The steps enforce conscious selection of chapter assets (theme/device/vocab) rather than generic platitudes.
ANSWER: "Respected Principal, teachers, friends. When Dinkar writes 'cu iM+s rks lh/s&lh/s ugha', he defines the **poet as the nation's conscience** – a role every young citizen must inherit today. The **irony** that silence speaks louder than empty slogans haunts us: our inaction on climate, inequality, or corruption is a deafening endorsement. Let **lohd`fr** (that sacred restlessness) not be suppressed by comfort. Dinkar's fire wasn't metaphorical; it was a call to burn indifference. So, friends, let our pens, voices, and votes be the 'tqykgk' that lights the future. Jai Hind." (118 words)

## COMPETENCY_QUESTION_1
QUESTION: A board exam question asks: "The poem is not just about the past; it is a mirror for the present." Write a paragraph (100 words) defending or challenging this statement using **two** specific textual references and **one** literary device analysis.
COMPETENCY: Critical Thinking & Textual Application (CBSE Competency: "Analyze and evaluate the relevance of literary texts to contemporary contexts")
STEPS:
- Step 1: Take a clear stance (Defend/Challenge) in the Point sentence.
- Step 2: Select two distinct textual references (e.g., the 'fire' metaphor, the 'truth-speaking' couplet).
- Step 3: Analyze one device (e.g., symbolism of fire / imperative mood) showing *how* it creates present relevance.
- Step 4: Link the analysis to a specific modern issue (e.g., social media activism, climate justice) in the Link sentence.
ANSWER: I defend the statement. Dinkar's metaphor of the poet as 'dk'kh dk tqykgk' (spark of fire) symbolizes the individual's power to ignite systemic change – today, a single whistleblower's tweet can spark a global movement (#MeToo, climate strikes). The imperative couplet 'cu iM+s rks lh/s&lh/s ugha' uses **command syntax** to strip away neutrality; in an era of algorithmic echo chambers, this demand for unambiguous moral positioning challenges performative allyship. Thus, the poem's fusion of symbolic fire and syntactic urgency transforms it from a historical artifact into a tactical manual for contemporary civic courage. (96 words)
DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: "Dinkar's greatness lies not in what he wrote, but in how he made the reader feel responsible." Evaluate this critical opinion in 120 words. Your answer must: (a) Reference the prose background (biography), (b) Analyze a poetic device from the poem, (c) Use the vocabulary word 'vfHkO;fDr' (creative impulse), and (d) Conclude with a judgment on the opinion's validity.
COMPETENCY: Multi-Concept Synthesis & Evaluative Judgment (CBSE Competency: "Synthesize biographical, textual, and linguistic evidence to form a critical judgment")
STEPS:
- Step 1: Deconstruct the opinion – It claims *affective impact* (reader responsibility) > *textual output*.
- Step 2: Select biographical evidence – Dinkar's life: renouncing titles, writing 'Hunkar' during famine/war, facing colonial censorship (prose background).
- Step 3: Select poetic device – The **direct address/second person imperative** ("cu iM+s...") forces the reader into the dock.
- Step 4: Integrate 'vfHkO;fDr' – Link the poet's creative impulse to the reader's awakened conscience.
- Step 5: Synthesize judgment – The opinion is *partially valid*: the 'how' (device/life) creates the responsibility, but the 'what' (content) provides the framework.
ANSWER: The opinion is profoundly valid but incomplete. Dinkar's biography – refusing British honors, composing 'Hunkar' amid the 1943 Bengal famine – embodies the **vfHkO;fDr** (creative impulse) as moral witness; his life *is* the argument. Poetically, the **second-person imperative** in 'cu iM+s rks lh/s&lh/s ugha' syntactically traps the reader: there is no third-person escape. The device transforms the poem from object to interrogation. However, the *content* (the 'what') – the specific vision of justice, the Sanskritized lexicon of dignity – provides the *criteria* for that responsibility. Without the 'what', the 'how' is an empty gun. Dinkar's greatness lies in the inseparability of the two: the fire (what) *and* the burn (how). (118 words)
DIFFICULTY: hard