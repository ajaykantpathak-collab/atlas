## DEFINITION
"Before You Read: Context and Background" is a preparatory literary skill where students systematically gather and organize biographical, historical, cultural, and literary-movement information about an author and their work before engaging with the text, enabling deeper comprehension and informed analysis.

## COGNITIVE_LEVEL
understand

## MASTERY_CRITERIA
The student can independently construct a structured context profile for any Hindi literary text by extracting the author's life events, historical period, literary affiliations, major works, awards, and thematic preoccupations from reference materials, and explain how each element shapes the text's meaning.

## SCOPE_BOUNDARY
This node covers only the pre-reading context-building process for Chapter 3 (poet Vajra and his two poems "नहीं वोस्यक" and "मैंने देखा, एक छोटा"). It does NOT cover textual analysis, poetic devices, theme exploration, or comprehension questions — those belong to subsequent sibling nodes.

## WALKTHROUGH
Imagine you are about to watch a film directed by someone you've never heard of — you'd likely check their filmography, interviews, and the era they work in to set expectations. The same applies to Hindi literature: before reading Vajra's poems, you need to know he lived through the freedom struggle, went to jail, edited literary journals, and was shaped by both Sanskrit and English education. Start by listing the factual milestones from the NCERT biographical note (birth, education, political activity, literary career, awards). Next, group these into categories: personal history, historical context, literary influences, professional roles. Then, for each category, ask: "How might this have shaped his poetic voice?" For instance, his jail term (1942) connects to the poem's theme of a small bird's freedom versus confinement. Finally, write a 3-sentence context statement synthesizing the most relevant links. The key insight: context is not trivia — it is the lens through which the text becomes intelligible.

## DIAGNOSTIC_QUESTION_1
From the NCERT biographical note, list Vajra's real name, birth-death years, and the two universities/cities where he received his formal education.

## DIAGNOSTIC_ANSWER_1
Correct answer: Real name — Lal Pankaj Ghosh (लाल पंकज घोष); Birth-death — 1911–1987; Education — English and Sanskrit at Allahabad (इलाहाबाद) and Jhansi (झाँसी), later LLB. A wrong answer that gives only "Vajra" as the name or omits the dual-language education reveals the student treats the biographical note as a skimmable paragraph rather than a structured data source; they miss that his bilingual training directly explains the Sanskritized yet accessible diction in his poems.

## DIAGNOSTIC_QUESTION_2
Explain in your own words why Vajra's participation in the Quit India Movement (1942) and his subsequent imprisonment are relevant to interpreting the line "यह चिड़िया लुग है, छोटी है, प्यारी है" from "नहीं वोस्यक".

## DIAGNOSTIC_ANSWER_2
Correct answer: The poet's lived experience of state power suppressing individual freedom (jail for political dissent) sensitizes him to the vulnerability of the "small" (लुग, छोटी) against overwhelming forces; the poem's plea to accept the bird into the heart mirrors his own desire for society to shelter dissenting voices. A wrong answer that says "it shows he liked birds" or "it proves he was brave" reveals a literalist misconception — the student fails to see biography as a hermeneutic tool that illuminates thematic preoccupations (freedom, vulnerability, acceptance) rather than a source of autobiographical trivia.

## DIAGNOSTIC_QUESTION_3
Given the NCERT note that Vajra edited literary journals (लक्ष्य, नया भारत, हंस) and worked at All India Radio, predict two specific ways his editorial/radio experience might manifest in the craft of "मैंने देखा, एक छोटा" (e.g., rhythm, imagery, address to listener).

## DIAGNOSTIC_ANSWER_3
Correct answer: (1) The poem's insistent refrain "यह चिड़िया... इसे भी दिल को दे दो" mirrors radio's oral address — direct, repetitive, designed for a listening audience. (2) The compact, image-dense lines ("झरते पत्तों की खड़खड़ाहट", "उन्मुक्त आकाश") reflect editorial discipline: maximum evocative power in minimum words, honed by selecting others' work. A wrong answer that lists generic traits like "good vocabulary" shows the student cannot transfer professional biography into textual evidence; they treat roles as labels, not as formative practices.

## DIAGNOSTIC_QUESTION_4
Compare Vajra's literary trajectory (early freedom-struggle poetry → later philosophical/individualist poetry) with the shift between the two poems in this chapter: "नहीं वोस्यक" (communal appeal) vs. "मैंने देखा, एक छोटा" (individual observation). What does this comparison suggest about the poet's evolving worldview?

## DIAGNOSTIC_ANSWER_4
Correct answer: The early poem addresses a collective "आप" (you all) urging social acceptance of the marginalized bird — reflecting the freedom-struggle ethos of collective action. The later poem uses first-person "मैंने देखा" (I saw), focusing on a solitary moment of perception — reflecting a shift toward individual consciousness and aesthetic epiphany. This mirrors Vajra's own move from public activism to private literary cultivation. A wrong answer that calls both poems "similar because both are about birds" misses the structural shift from exhortation to observation, revealing an inability to map biographical phases onto textual strategies.

## DIAGNOSTIC_QUESTION_5
Evaluate this student claim: "Knowing Vajra won the Bharatiya Jnanpith Award proves his poems are great, so we don't need to analyze them closely." Provide a reasoned judgment using the distinction between extrinsic validation and intrinsic textual evidence.

## DIAGNOSTIC_ANSWER_5
Correct answer: The claim confuses authority with analysis. An award signals peer recognition at a historical moment; it does not replace the reader's task of examining how *this* poem achieves its effects through diction, rhythm, imagery, and structure. Close analysis reveals *why* the work earned recognition — e.g., the juxtaposition of "लुग" (small/insignificant) with "प्यारी" (beloved) in "नहीं वोस्यक" enacts the very acceptance the poem advocates. A wrong answer that agrees with the claim reveals a receipt-of-knowledge mindset: the student expects meaning to be certified from outside, not constructed through engagement.

## DIAGNOSTIC_QUESTION_6
Create a 4-sentence "Context Card" for Vajra that a Class 12 student could glue into their notebook, synthesizing: (a) one biographical fact, (b) one historical context, (c) one literary influence, (d) one thematic preoccupation visible in the two poems.

## DIAGNOSTIC_ANSWER_6
Strong answer example: "Vajra (1911–1987), born Lal Pankaj Ghosh, was imprisoned during the 1942 Quit India Movement, shaping his lifelong concern for individual freedom. His dual Sanskrit-English education fused classical metre with modern free verse. Editing journals like 'Hans' sharpened his ear for spoken rhythm, heard in the refrain 'इसे भी दिल को दे दो'. Both chapter poems explore the tension between the fragile individual (bird) and the encompassing world (sky, society)." A weak answer that lists disconnected facts ("born 1911, went to jail, got award, wrote poems") shows the student cannot synthesize — the core skill this node teaches.

## COMMON_MISCONCEPTION
Students treat "Before You Read" as a passive reading of the author blurb, memorizing dates and awards for a 1-mark factual recall question. They do not grasp that context-building is an *active analytical framework*: every biographical detail (jail, bilingualism, editorship) is a hypothesis about the text's meaning that must be tested against the poem's actual words. The error stems from years of textbook-end questions that reward fact-retrieval over interpretive linking.

## ON_FAILURE
Step 1: Have the student re-read the NCERT biographical note with a highlighter, marking only facts that could *plausibly connect* to a poem about a small bird or a moment of seeing. Step 2: For each highlighted fact, write one "If this shaped the poem, then I would expect to see..." prediction (e.g., "If jail shaped the poem → imagery of confinement/freedom"). Step 3: Read the two poems once, checking which predictions hold. Step 4: Discard unproductive facts; keep only those that illuminate textual evidence. This transforms context from trivia into a reusable heuristic.

## BUILDS_ON
Class 11 "Before You Read" nodes (e.g., c11_hin_ar_cbse_01_001) where students first practiced extracting author background from textbook blurbs.

## LEADS_TO
c12_hin_a_cbse_03_002 (Plot and Narrative Structure) — the context profile built here becomes the interpretive lens for analyzing how Vajra structures each poem's narrative movement.

## PREREQUISITE_NODE_IDS
c11_hin_ar_cbse_01_001, c11_hin_ar_cbse_02_001, c11_hin_ar_cbse_03_001, c11_hin_ar_cbse_03_015, c11_hin_ar_cbse_05_001, c11_hin_v_cbse_03_015

## PREREQUISITE_REASONS
c11_hin_ar_cbse_01_001: Introduced the "Before You Read" template (author bio → historical context → literary trends → thematic guesses) that this node deepens.
c11_hin_ar_cbse_02_001: Practised linking a poet's bilingual education (Sanskrit + vernacular) to diction choices — directly applicable to Vajra's Sanskrit-English training.
c11_hin_ar_cbse_03_001: Modelled connecting political biography (freedom struggle) to poetic theme (individual vs. collective) — the exact move needed for Vajra's 1942 imprisonment.
c11_hin_ar_cbse_03_015: itical thinking models the analytical moves (compare, evaluate, synthesize) required in discussion. c11_hin_ar_cbse_03_015: Class 11 Antra Chapter 3 speaking/listening practice provides the procedural foundation for structured discussion. c  
c11_hin_ar_cbse_05_001: M: Compare Vajra's Context Profile with that of another Hindi poet from Class 11 (e.g., Nirala from c11_hin_ar_cbse_05_001). Identify two shared historical forces, two divergent literary affiliations, and predict how these similarities/diff  
c11_hin_v_cbse_03_015: Chapter 3 speaking/listening practice provides the procedural foundation for structured discussion. c11_hin_v_cbse_03_015: Class 11 Vitan Chapter 3 speaking/listening extends exposure to discussion formats across textbooks.  

## FORWARD_NODE_IDS
c12_hin_a_cbse_03_002, c12_hin_a_cbse_03_003, c12_hin_a_cbse_03_004, c12_hin_a_cbse_03_006, c12_hin_a_cbse_03_008, c12_hin_a_cbse_03_010, c12_hin_a_cbse_03_012, c12_hin_a_cbse_03_014, c12_hin_a_cbse_03_015

## FORWARD_REASONS
c12_hin_a_cbse_03_002: The narrative structure of each poem (exhortation vs. observation) is interpreted through the biographical shift from activist to observer established here.
c12_hin_a_cbse_03_003: Setting/atmosphere (jail-era confinement vs. open sky) draws directly on the historical context of 1942 imprisonment.
c12_hin_a_cbse_03_004: Protagonist analysis (the bird as symbolic self) relies on the "individual freedom" thematic preoccupation synthesized in the Context Card.
c12_hin_a_cbse_03_006: Primary theme (vulnerability and acceptance) is pre-figured in the context profile's thematic preoccupation step.
c12_hin_a_cbse_03_008: Context/background of Varjak and his poetic philosophy is essential to know *why* he uses dense metaphor.  
c12_hin_a_cbse_03_010: Provides background on poet vKs; and his linguistic style, essential to anticipate his vocabulary innovations.  
c12_hin_a_cbse_03_012: Context/background needed to infer authorial intent  
c12_hin_a_cbse_03_014: Context/background needed to frame poet's intent in answers.  
c12_hin_a_cbse_03_015: Provides biographical/historical context of vKs; essential for interpreting his humanistic stance in discussion. c12_hin_a_cbse_03_002: Narrative structure of each poem (stanza progression, refrain placement) needed to navigate discussion flow. c12_hin_a_cbse_03_006: Primary theme (individual dignity vs. social exclusion) is the core discussion anchor. c12_hin_a_cbse_03_008: Imagery/metaphor analysis supplies the textual evidence for claims. c12_hin_a_cbse_03_009: Irony/symbolism understanding enables deeper interpretation (e.g., "vf}rh;" as ironic self-assertion). c12_hin_a_cbse_03_012: Literal/inferential comprehension ensures baseline understanding before analysis. c12_hin_a_cbse_03_013: Critical thinking models the analytical moves (compare, evaluate, synthesize) required in discussion. c11_hin_ar_cbse_03_015: Class 11 Antra Chapter 3 speaking/listening practice provides the procedural foundation for structured discussion. c11_hin_v_cbse_03_015: Class 11 Vitan Chapter 3 speaking/listening extends exposure to discussion formats across textbooks.  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
c11_his_cbse_13_001: The Quit India Movement (1942) context — Vajra's imprisonment is a literary instance of the history chapter's "mass civil disobedience and state repression" topic.
c11_pol_cbse_08_001: The poem's plea "इसे भी दिल को दे दो" (give it a place in the heart too) enacts the political theory concept of "inclusive citizenship" — protecting minority/dissenting voices within the polity.

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_03_001 -> c12_hin_a_cbse_03_001 -> c12_hin_a_cbse_03_002

## THIS_FORMULA
Context Profile = (Biographical Milestones) + (Historical Period Forces) + (Literary Affiliations & Roles) + (Awards/Recognition) → Thematic Hypotheses to Test in Text

## FORMULA_VARIABLES
Biographical Milestones: Birth/death, education, family, key life events (e.g., jail, migration). Historical Period Forces: Major national/events shaping the author's generation (e.g., freedom struggle, Partition, Emergency). Literary Affiliations & Roles: Movements, journals, mentors, professional positions (editor, broadcaster, teacher). Awards/Recognition: Prizes, honors — treated as reception history, not quality proof. Thematic Hypotheses: Testable predictions about what themes, images, tones the text might exhibit.

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
conceptual

## CROSS_SUBJECT
N/A | Vajra's 1942 imprisonment links the poem's freedom/constraint imagery to the History chapter on Quit India Movement — students see literature as historical evidence.
 N/A | The refrain "इसे भी दिल को दे दो" (make space in the heart for this too) mirrors the PolSci concept of minority rights and inclusive democracy — literature embodies political philosophy.
 N/A | The poet's shift from collective activism to individual observation reflects Sociology's "tradition to modernity" transition in intellectual roles — biography as social history.
## PREREQ_CONCEPT
Ability to extract structured information from a biographical note and categorize it into personal, historical, professional, and literary dimensions.

## PREREQ_BEFORE
Student must have practiced the Class 11 "Before You Read" template at least twice: (1) list facts, (2) group into categories, (3) generate thematic guesses.

## PREREQ_STUCK
If stuck, revisit c11_hin_ar_cbse_03_001 (Class 11 Chapter 3 Before You Read) and re-do its worked example with a different author — the template is identical, only the author changes.

## WORKED_EXAMPLE_1
PROBLEM: Using only the NCERT biographical note provided, build a complete Context Profile for Vajra organized into the four formula categories, then write two thematic hypotheses for the poem "नहीं वोस्यक".
STEPS:
- Step 1: Extract every factual milestone from the note — birth (1911 Agra), education (English+Sanskrit at Allahabad/Jhansi, LLB), political act (1942 Quit India, 4 years jail, 2 years underground), professional roles (journal editor: Lakshya, Naya Bharat, Hans; All India Radio; university teacher), literary output (3 poetry collections, stories, novels, essays, criticism), awards (Literary Academy, Bharat Bharati, Jnanpith), death (1987).
- Step 2: Sort into four columns: Biographical (birth, education, death), Historical (1942 jail, freedom struggle), Literary/Professional (editorship, radio, teaching, bilingual training), Recognition (awards).
- Step 3: For each column, write one "shaping influence" sentence: Biographical → bilingual diction; Historical → freedom/constraint dialectic; Literary/Professional → oral rhythm, editorial compression; Recognition → canonical status but not interpretive key.
- Step 4: Generate two thematic hypotheses for "नहीं वोस्यक": (H1) The poem will dramatize a small entity's right to exist against a dismissive majority — mirroring the jailed dissenter vs. state. (H2) The address will be direct and oral (refrain, imperative) — mirroring radio broadcast style.
- Step 5: Verify against the actual poem (later nodes) — both hypotheses hold: the bird is "लुग/छोटी" yet "प्यारी", and the refrain "इसे भी दिल को दे दो" is a direct oral appeal.
REASONING: The template forces disciplined extraction (Step 1), analytical categorization (Step 2), causal reasoning (Step 3), predictive modelling (Step 4), and empirical verification (Step 5) — the full context-to-text pipeline.
ANSWER: Context Profile complete with 4 categories, 4 shaping-influence sentences, 2 verified thematic hypotheses. Student now enters the poem with a calibrated interpretive lens.

## WORKED_EXAMPLE_2
PROBLEM: A Class 12 student writes this Context Card: "Vajra (1911–1987) was a freedom fighter who went to jail. He wrote many poems and got the Jnanpith Award. His poems are about nature." Diagnose the three specific weaknesses and rewrite it as a strong Context Card.
STEPS:
- Step 1: Identify weakness 1 — "freedom fighter who went to jail" is vague; misses the specific 1942 Quit India context and duration (4 years jail + 2 years underground) that sharpens the freedom/constraint theme.
- Step 2: Identify weakness 2 — "wrote many poems, got Jnanpith" lists output/award but omits formative roles (editor, radio, bilingual education) that explain *how* the poems are crafted.
- Step 3: Identify weakness 3 — "poems are about nature" reduces thematic preoccupation to a topic label; misses the specific tension (individual vs. collective, vulnerability vs. acceptance) visible in the two chapter poems.
- Step 4: Rewrite using the formula: Biographical → "Lal Pankaj Ghosh (Vajra), 1911–1987, Sanskrit-English bilingual education." Historical → "Imprisoned 1942–46 for Quit India Movement; 2 years underground." Literary/Professional → "Edited 'Hans', 'Naya Bharat'; All India Radio broadcaster; university teacher." Thematic Hypotheses → "Poems test whether the fragile individual (bird, dissenting voice) can claim space in a hostile world; form uses oral refrain and compressed imagery."
- Step 5: Condense to 4-sentence card: "Vajra (Lal Pankaj Ghosh, 1911–1987) fused Sanskrit-English bilingualism with editorial discipline from 'Hans' and All India Radio. His 1942–46 imprisonment for Quit India activism forged a lifelong dialectic of freedom vs. constraint. The Jnanpith Award marks canonical recognition, not interpretive closure. Both chapter poems stage a vulnerable small entity (bird) demanding acceptance — from society ('दिल को दे दो') and from perception ('मैंने देखा')."
REASONING: The diagnosis isolates the three most common student errors: vagueness on historical specificity, omission of craft-forming roles, and thematic reductionism. The rewrite models the target density.
ANSWER: Strong 4-sentence Context Card produced; weaknesses explicitly named and corrected.

## WORKED_EXAMPLE_3
PROBLEM: Compare Vajra's Context Profile with that of another Hindi poet from Class 11 (e.g., Nirala from c11_hin_ar_cbse_05_001). Identify two shared historical forces, two divergent literary affiliations, and predict how these similarities/differences would shape their respective treatments of "the individual vs. society".
STEPS:
- Step 1: Recall Nirala's Context Profile (Class 11 Ch 5): Born 1896, Bengali-origin in UP, Sanskrit-English-Hindi trilingual, no formal degree, lifelong poverty, associated with Chhayavad movement, edited 'Sudha', no major state awards during life, died 1961.
- Step 2: Map shared historical forces: (a) Both lived through late colonial period → freedom struggle as backdrop. (b) Both navigated Hindi's modernization (Sanskrit legacy vs. Khari Boli standard) → language as contested terrain.
- Step 3: Map divergent literary affiliations: (a) Nirala → Chhayavad (romantic-symbolist, self-consciously "modern" poetry collective); Vajra → post-Chhayavad, progressive/individualist, institutional (journals, radio, university). (b) Nirala → outsider/marginal within literary establishment; Vajra → insider/editor/broadcaster shaping the establishment.
- Step 4: Predict treatment of "individual vs. society": Nirala's individual is a tragic visionary (e.g., "Juhi Ki Kali" — the bud that blooms alone), alienated from society; Vajra's individual (bird) seeks *inclusion* ("दिल को दे दो"), appealing to society's conscience. Nirala's form breaks metre; Vajra's form uses refrain for communal address.
- Step 5: Verify with actual poems: Nirala's "Juhi Ki Kali" — solitary blooming, no appeal to others. Vajra's "नहीं वोस्यक" — direct address to "you" (society) to accept the bird. Prediction holds.
- Step 6: Synthesize insight: Shared history (colonialism) produces shared concern (individual dignity); divergent institutional positions (outsider vs. insider) produce divergent strategies (withdrawal vs. appeal).
REASONING: Cross-author comparison deepens context-building from single-author profiling to literary-historical patterning — a competitive-exam level skill (CUET/JEE-style comparative analysis).
ANSWER: Two shared forces (colonial modernity, Hindi standardization), two divergent affiliations (Chhayavad outsider vs. institutional insider), two contrastive predictions (tragic withdrawal vs. inclusive appeal) — all verified against textual evidence.

## COMPETENCY_QUESTION_1
QUESTION: A Class 12 student is given an unseen Hindi poem by a poet described as: "Born 1925 in Punjab, migrated during Partition, wrote for left-wing journals in the 1950s, taught Hindi at a university, known for blending Punjabi folk metre with modernist free verse." Using the Context Profile formula, write three specific thematic hypotheses for this poem, each linked to a distinct biographical/historical/professional factor.
COMPETENCY: Contextual Inference — generating testable literary hypotheses from author metadata.
STEPS:
- Step 1: Identify the four formula factors in the prompt: Biographical (Partition migration 1947), Historical (Partition trauma, postcolonial nation-building), Literary/Professional (left-wing journals → progressive ideology; university teacher → academic modernism; Punjabi folk + free verse → hybrid form).
- Step 2: Generate Hypothesis 1 from Partition migration: "The poem will feature imagery of dislocation, lost home, or fragmented identity — e.g., a speaker addressing a place they cannot return to."
- Step 3: Generate Hypothesis 2 from left-wing journal affiliation: "The poem will critique social inequality or celebrate collective resistance — e.g., a worker's voice, a call for redistribution."
- Step 4: Generate Hypothesis 3 from Punjabi folk metre + free verse blend: "The poem will use rhythmic repetition/refrain (folk) alongside enjambment/fragmentation (modernist) — form itself enacting tradition-modernity tension."
- Step 5: Check each hypothesis is specific, testable, and tied to a distinct factor — no overlap.
ANSWER: Three hypotheses: (1) Dislocation/fragmented identity from Partition migration. (2) Social critique/collective resistance from progressive journal background. (3) Form as tradition-modernity dialogue from folk-free verse hybridity. Each linked to a distinct factor.
DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: The NCERT note states Vajra "developed Hindi poetic language by giving words new meanings." In "नहीं वोस्यक", the word "लुग" (lug) typically means 'small/insignificant' in Braj, but here it appears alongside "प्यारी" (beloved). Using the Context Profile (bilingual education, editorial discipline, freedom-struggle imprisonment), explain how this semantic revaluation enacts the poem's central argument. Write a 5-sentence analytical paragraph.
COMPETENCY: Semantic Analysis — tracing how biographical context informs lexical innovation in the text.
STEPS:
- Step 1: Recall Context Profile factor — Sanskrit-English bilingual education gave Vajra access to Braj (लुग) and modern Hindi registers simultaneously.
- Step 2: Recall Context Profile factor — editorial work (selecting/refining others' poems) trained him to weigh each word's semantic weight and connotative range.
- Step 3: Recall Context Profile factor — 1942 imprisonment made "insignificant vs. valued" a lived political dichotomy (dissenter = state's 'लुग', but self's 'प्यारी').
- Step 4: Analyze the collision: By placing "लुग" (diminutive) and "प्यारी" (cherished) in apposition, the poem reclaims the label of insignificance — the bird *is* small, *and* that smallness is precisely why it deserves love.
- Step 5: Conclude: The semantic shift is not decorative; it performs the poem's ethics — inclusion does not require the marginal to become large, only to be seen as beloved in its marginality.
ANSWER: Vajra's bilingual training (Sanskrit/Braj + English/Hindi) equipped him to retrieve "लुग" from its dialectal margin; his editorial discipline honed the precision to juxtapose it with "प्यारी" without qualification; his imprisonment taught him that the state labels dissidents "insignificant" (लुग) to justify exclusion. The poem counters by asserting: "लुग है... प्यारी है" — small *and* beloved, the conjunction refusing the state's logic. This lexical revaluation enacts the central argument: dignity inheres in vulnerability itself, not in its overcoming.
DIFFICULTY: hard