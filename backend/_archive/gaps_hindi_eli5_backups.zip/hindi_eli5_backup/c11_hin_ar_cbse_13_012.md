## DEFINITION
Literal comprehension questions require answers directly stated in the text, while inferential comprehension questions require drawing conclusions by combining textual evidence with reasoning and context.

## COGNITIVE_LEVEL
understand

## MASTERY_CRITERIA
Student can correctly classify a question as literal or inferential, locate explicit evidence for literal answers, and construct inferential answers by synthesizing textual clues with logical reasoning in a structured PEEL response.

## SCOPE_BOUNDARY
Covers strategies for answering literal and inferential questions based on the poem "lk;s esa /wi" (Winter in the Village) by Nagarjun. Does not cover critical analysis of literary devices, theme exploration, or creative writing beyond comprehension responses.

## WALKTHROUGH
Imagine you receive a WhatsApp forward: "It's freezing in Delhi." That's literal — the message says it directly. But if your friend sends a photo of a steaming tea cup with "Finally!" you *infer* they were cold. With Nagarjun's poem, start by reading a question like "Where does the fog sit?" Scan Stanza 1 for keywords "fog" and "sit" — you find "nk[rksa osQ lk;s esa /wi yxrh gS". That's literal. Now take "Why does the poet call the fog a ruler?" The poem never says "fog is a metaphor for ruler" directly. You must connect "rsjk fu”kke gS" (Stanza 2) with the fog's stubborn sitting (Stanza 1) and the villagers' helplessness (Stanza 3). The key insight: literal = text *says*; inferential = text *suggests* + you *reason*.

## DIAGNOSTIC_QUESTION_1
Define literal comprehension and inferential comprehension in your own words. Give one example of each type of question for any text you know.

## DIAGNOSTIC_ANSWER_1
Literal comprehension involves retrieving information explicitly stated in the text (e.g., "What is the capital of France?" from a geography passage). Inferential comprehension involves deriving implied meaning by combining textual evidence with reasoning (e.g., "Why did the character refuse the offer?" requires analyzing motives). A wrong answer that swaps the definitions reveals the student cannot distinguish between *explicit statement* and *implied meaning* — the core skill for board exam comprehension.

## DIAGNOSTIC_QUESTION_2
Consider this line from Stanza 1: "dgk¡ rks r; Fkk fpjkxk¡ gjsoQ ?kj osQ fy,] dgk¡ fpjkx e;Llj ugha 'kgj osQ fy,A" Is the question "What two things does the poet say about the fog's past location?" literal or inferential? Justify your classification.

## DIAGNOSTIC_ANSWER_2
This is a **literal** question. The answer is directly in the lines: (1) sometimes the fog was for the houses, (2) sometimes the fog was not for the lanes. No reasoning beyond reading is needed. If a student classifies it as inferential, they likely confuse *paraphrasing* with *inferring* — they think any rewording of the text counts as inference, missing that inference requires going *beyond* the given words.

## DIAGNOSTIC_QUESTION_3
Answer this literal question using only Stanza 1: "What command does the poet give to the fog, and what reason does he imply for it?" Quote the exact phrase for the command.

## DIAGNOSTIC_ANSWER_3
**Step 1:** Identify keywords: "command" (order), "fog" (/wi), "Stanza 1".  
**Step 2:** Scan Stanza 1: "pyks ;gk¡ ls pysa vkSj mez Hkj osQ fy,A"  
**Step 3:** Extract command phrase: "pyks ;gk¡ ls pysa" (Fly away from here).  
**Step 4:** Extract implied reason: "mez Hkj osQ fy,A" (to fill the sacks).  
**Step 5:** Formulate answer: The poet commands the fog "pyks ;gk¡ ls pysa" (fly away from here) implying it should go fill the sacks (of the rulers/grain).  
A wrong answer that invents a reason like "to clear the sun" reveals the student imports outside knowledge instead of sticking to textual evidence.

## DIAGNOSTIC_QUESTION_4
Compare the approach for these two questions on the same poem:  
(A) "List the three things the villagers might do tomorrow according to Stanza 2."  
(B) "What does the phrase 'equkflc' (helpless) reveal about the villagers' economic agency?"  
Explain how your reading strategy differs for each.

## DIAGNOSTIC_ANSWER_4
For (A) — **literal**: Strategy = *Scan and Retrieve*. Locate Stanza 2, find future tense verbs ("ysaxs"), list the three actions explicitly stated.  
For (B) — **inferential**: Strategy = *Clue-Connect-Conclude*.  
1. Locate "equkflc" in context: "u gks deh”k rks ik¡oksa ls isV <¡d ysaxs] ;s yksx fdrus equkflc gSa bl lI+kQj osQ fy,A"  
2. Gather clues: "pluck straw from roofs" (desperation), "fill sacks of rulers" (exploitation), "sun's rays only in wrinkles" (futile hope).  
3. Conclude: "equkflc" signifies total lack of economic agency — they cannot resist exploitation nor secure basic needs.  
A wrong answer that uses the same scan-and-list method for (B) reveals inability to shift from *retrieval* to *synthesis* mode.

## DIAGNOSTIC_QUESTION_5
A student answers the inferential question "Why does the poet address the fog as 'you' (tu/tum)?" with: "Because the poet is talking to the fog directly." Evaluate this answer. Is it sufficient for a 2-mark board question? Why or why not?

## DIAGNOSTIC_ANSWER_5
**Evaluation: Insufficient (0/2 marks).**  
**Reason:** The answer states the *literal* grammatical fact (apostrophe/direct address) but misses the *inferential* significance. A 2-mark answer must explain the *effect*: Personifying the fog as a stubborn listener ("pyks ;gk¡ ls pysa") transforms it into an accountable oppressor — the poet confronts the systemic force (ruler/exploitation) as if it were a person who can be commanded. The student's answer shows **surface-level reading** — they identify the device but cannot infer its thematic function. This is the most common error in board exams: naming the device without explaining its purpose.

## DIAGNOSTIC_QUESTION_6
Create one literal and one inferential question based on Stanza 3 ("ft,¡ rks vius cxhps esa xqyeksgj osQ rys] ejsa rks xSj dh xfy;ksa esa xqyeksgj osQ fy,A"). Provide the ideal answer for each.

## DIAGNOSTIC_ANSWER_6
**Literal Q:** "Where does the sun keep its rays of hope according to the first line of Stanza 3?"  
**Ideal Answer:** "In its lap" (vius cxhps esa) — directly quoted.  

**Inferential Q:** "What does the contrast between the sun's 'lap' and the villagers' 'wrinkles' suggest about the accessibility of hope?"  
**Ideal Answer:** Hope (sun's rays) remains distant and possessive ("in its lap") while villagers only bear its *imprint* in their wrinkles — suggesting hope is visible but unattainable, etched only as signs of enduring hardship.  

A poor answer that makes the inferential question answerable by a single word ("sadness") reveals the student cannot construct *evidence-based* inferences — they guess emotions instead of analyzing textual contrast.

## COMMON_MISCONCEPTION
**Misconception:** "Inferential questions have no right answer — any personal opinion is correct if you explain it."  
**Why it happens:** Students confuse *inference* (evidence-based conclusion) with *subjective response* (personal feeling). In Class 10, they may have been encouraged to "share your view" in literature. In Class 11 board exams, inferential answers **must** be anchored in textual evidence.  
**Concrete Example:** For "What does the fog symbolize?", a student writes "The fog symbolizes my fear of exams because it's scary." This uses zero textual evidence (no reference to "fu”kke", "nk[rksa", "equkflc"). The examiner awards 0 marks because the inference is unmoored from the poem.

## ON_FAILURE
**Step 1:** Show a literal Q&A pair from the poem (e.g., Q: "Where is the fog?" A: "In the courtyard" — highlight "nk[rksa osQ lk;s esa" in text).  
**Step 2:** Present an inferential Q: "Why 'sitting' not 'floating'?" Model the **Evidence → Reasoning → Inference** chain:  
Evidence: "yxrh gS" (sits) + "pyks ;gk¡ ls pysa" (told to leave but stays)  
Reasoning: "Sitting" implies deliberate occupation, comfort, refusal to move.  
Inference: The fog acts like an entitled occupier — mirroring the ruler in Stanza 2.  
**Step 3:** Give a new stanza (e.g., Stanza 3). Ask student to highlight 2 clues, write 1 inference sentence using "This suggests..."  
**Step 4:** Reinforce mantra: **"Text says → I think → Because text shows."** No "I feel" without "Text shows."

## BUILDS_ON
Builds on vocabulary mastery (c11_hin_ar_cbse_13_010) and grammatical parsing (c11_hin_ar_cbse_13_011) to distinguish explicit vs. implicit meaning.

## LEADS_TO
Leads to critical thinking and interpretation (c11_hin_ar_cbse_13_013) where inferences become arguments for thematic analysis.

## PREREQUISITE_NODE_IDS
c11_hin_ar_cbse_13_001, c11_hin_ar_cbse_13_002, c11_hin_ar_cbse_13_010, c11_hin_ar_cbse_13_011, c11_hin_ar_cbse_13_007, c11_hin_ar_cbse_13_009

## PREREQUISITE_REASONS
c11_hin_ar_cbse_13_001: Context/background knowledge (rural winter, Nagarjun's Marxist lens) is essential to make valid inferences about socio-political metaphor.
c11_hin_ar_cbse_13_002: Understanding narrative structure (three stanzas = three movements) helps locate literal details in the correct stanza.
c11_hin_ar_cbse_13_010: Vocabulary (e.g., "e;Llj", "eqrebu", "fu”kke", "equkflc") must be known to access literal meaning before inferring.
c11_hin_ar_cbse_13_011: Grammar (imperative mood "pyks", pronoun "rsjk", case endings) clarifies who commands whom — critical for literal accuracy.
c11_hin_ar_cbse_13_007: Literal/inferential comprehension questions test whether students can *extract* thematic evidence from text — requires prior thematic framework.  
c11_hin_ar_cbse_13_009: Inferential comprehension questions (e.g., "Why does the poet call the peace 'hollow'?") require the analytical framework built here.  

## FORWARD_NODE_IDS
c11_hin_ar_cbse_13_013, c11_hin_ar_cbse_13_014, c12_hin_a_cbse_13_012, c12_hin_a_cbse_14_012, c12_hin_ar_cbse_04_012

## FORWARD_REASONS
c11_hin_ar_cbse_13_013: Critical thinking requires synthesizing multiple supported inferences into a coherent interpretation — this node provides the evidence-gathering foundation.
c11_hin_ar_cbse_13_014: Writing skills (analytical paragraph, long answer) demand structured use of literal quotes and inferential commentary — exactly what this node teaches.
c12_hin_a_cbse_13_012: Class 11 comprehension foundation for same chapter — students already practiced basic L/I distinction on this text.  
c12_hin_a_cbse_14_012: Previous chapter's comprehension practice reinforces the skill.  
c12_hin_ar_cbse_04_012: अगला तार्किक चरण: Literal comprehension is the ability to extract explicitly stated facts, details, and sequences dire... इस नोड की अवधारणाओं को सीधे उपयोग/विस्तारित करता है।  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
none

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_13_010 -> c11_hin_ar_cbse_13_012 -> c11_hin_ar_cbse_13_013

## THIS_FORMULA
N/A - conceptual

## FORMULA_VARIABLES
N/A

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
linguistic

## CROSS_SUBJECT
c11_history_colonialism | The poem's metaphor of fog-as-ruler exploiting villagers ("fly ns ”kqcku 'kk;j dh") mirrors colonial land revenue extraction — inference skills here transfer to analyzing primary sources in history.
c11_economics_rural_development | "equkflc" (helpless) villagers plucking roof-straw reflects asset depletion in agrarian distress — inferring economic condition from literary text parallels interpreting qualitative data in economics.

## PREREQ_CONCEPT
Ability to distinguish between information explicitly written in the text and meaning that must be deduced by connecting textual clues.

## PREREQ_BEFORE
Student must have read the poem "lk;s esa /wi" at least twice and understood the vocabulary list (e;Llj, eqrebu, csdjkj, fu”kke, ,gfr;kr, cgj, vlj).

## PREREQ_STUCK
If stuck, review Stanza-wise summary (c11_hin_ar_cbse_13_002) and Vocabulary in Context (c11_hin_ar_cbse_13_010) — then re-read the poem aloud focusing on verb tenses (past "Fkk", present "yxrh", future "ysaxs", imperative "pyks").

## WORKED_EXAMPLE_1
PROBLEM: Answer the inferential question: "Why does the poet use the imperative 'pyks' (fly away) when addressing the fog in Stanza 1?" using textual evidence.

STEPS:
- Step 1: Identify the keyword "pyks" (imperative verb) and locate it in Stanza 1: "pyks ;gk¡ ls pysa vkSj mez Hkj osQ fy,A"
- Step 2: Note the literal meaning: The poet commands the fog to leave.
- Step 3: Analyze the grammatical choice: Imperative mood ("pyks") indicates direct address to an animate, accountable entity — not a weather phenomenon.
- Step 4: Connect to Stanza 2 where fog is explicitly equated with ruler: "rsjk fu”kke gS fly ns ”kqcku 'kk;j dh" — the command becomes political confrontation.
- Step 5: Synthesize: The imperative transforms the fog from passive nature into an active oppressor who *can* be ordered to leave, implying the system is human-made and therefore resistible.
REASONING: This models the inferential ladder: grammatical observation → cross-stanza connection → thematic implication. Board examiners reward this progression.
ANSWER: The imperative "pyks" personifies the fog as a conscious agent who can obey commands. Since Stanza 2 reveals the fog *is* the ruler ("rsjk fu”kke gS"), the command becomes a political demand for the exploitative system to depart — suggesting the poet views oppression as a removable human construct, not inevitable nature.

## WORKED_EXAMPLE_2
PROBLEM: Answer the literal question: "According to Stanza 2, what three specific actions describe the fog's behavior towards the villagers?" Quote phrases.

STEPS:
- Step 1: Identify question type: literal retrieval from Stanza 2 only.
- Step 2: Read Stanza 2 carefully: "u gks deh”k rks ik¡oksa ls isV <¡d ysaxs] ;s yksx fdrus equkflc gSa bl lI+kQj osQ fy,A [kqnk ugha] u lgh] vkneh dk [okc lgh] dksbZ glhu u”kkjk rks gS u”kj osQ fy,A"
- Step 3: Extract three explicit actions/descriptions: 
  1. "ik¡oksa ls isV <¡d ysaxs" (will pluck straw from roofs tomorrow)
  2. "equkflc" (helpless — stated as condition)
  3. "vkneh dk [okc lgh" (the ruler's accounting is correct/inescapable)
- Step 4: Verify each is directly stated, not interpreted.
- Step 5: Format answer with quotes.
REASONING: Literal questions test precise retrieval. This example shows scanning for multiple distinct textual facts without merging them into a narrative.
ANSWER: (1) "ik¡oksa ls isV <¡d ysaxs" — they will pluck straw from roofs. (2) "equkflc" — they are helpless. (3) "vkneh dk [okc lgh" — the ruler's account/reckoning is exact.

## WORKED_EXAMPLE_3
PROBLEM: Board-style 4-mark question: "The poem progresses from a weather description to a political allegory. Trace this progression by analyzing the shift in the fog's portrayal across all three stanzas."

STEPS:
- Step 1: Deconstruct the question: Requires (a) literal description of fog in each stanza, (b) inferential analysis of shift, (c) synthesis into "progression".
- Step 2: Stanza 1 literal: Fog as weather — "nk[rksa osQ lk;s esa /wi yxrh gS" (sits in courtyards), "pyks ;gk¡ ls pysa" (commanded to leave).
- Step 3: Stanza 2 literal: Fog as ruler — "rsjk fu”kke gS" (your king/ruler), "fly ns ”kqcku 'kk;j dh" (fills rulers' sacks), villagers "equkflc" (helpless).
- Step 4: Stanza 3 literal: Fog as hope-blocker — Sun's "xqyeksgj osQ rys" (rays of hope in lap) vs villagers' "xSj dh xfy;ksa esa xqyeksgj" (hope only in wrinkles).
- Step 5: Inferential shift analysis: 
  Stanza 1: Physical discomfort (cold, visibility) → 
  Stanza 2: Structural exploitation (ruler extracts labor) → 
  Stanza 3: Psychological/spiritual suppression (hope made inaccessible).
- Step 6: Synthesize into thesis: The fog metamorphoses from natural phenomenon → socio-political instrument → internalized despair, mirroring how colonial/feudal oppression penetrates every layer of village life.
REASONING: This models the full board-exam competency: multi-stanza evidence gathering + layered inference + thematic synthesis. Each step builds on the previous — missing literal accuracy in Step 2/3/4 collapses the inference.
ANSWER: In Stanza 1, the fog is a literal winter mist "sitting in courtyards" — a physical nuisance the poet orders away. In Stanza 2, the fog is explicitly identified as "your ruler" ("rsjk fu”kke gS") who extracts the villagers' produce ("fill the sacks of the rulers"), rendering them "helpless" ("equkflc"). In Stanza 3, the fog blocks the sun so that "rays of hope" remain only in the sun's lap or etched in the villagers' wrinkles — never warming their lives. This three-stage portrayal transforms the fog from weather into a metaphor for an oppressive system that first surrounds, then exploits, and finally crushes hope — making the personal political and the seasonal eternal.

## COMPETENCY_QUESTION_1
QUESTION: Read these lines from Stanza 2: "u gks deh”k rks ik¡oksa ls isV <¡d ysaxs] ;s yksx fdrus equkflc gSa bl lI+kQj osQ fy,A"  
(a) What literal future action is predicted for the villagers?  
(b) Infer what "equkflc" implies about their relationship with the "vkneh" (ruler/accountant). Support with one more phrase from the same stanza.

COMPETENCY: Textual evidence usage and socio-economic inference
STEPS:
- Step 1: For (a), translate the conditional prediction: "If not today, tomorrow they will pluck straw from roofs."
- Step 2: For (b), define "equkflc" in context: helpless, lacking agency/resources.
- Step 3: Connect to "vkneh dk [okc lgh" — the ruler's accounting is inescapably accurate.
- Step 4: Infer relationship: Villagers are trapped in a system where their desperation (plucking roof) is calculated into the ruler's ledger.
- Step 5: Write structured answer with quotes.
ANSWER: (a) The literal prediction: "ik¡oksa ls isV <¡d ysaxs" — they will pluck straw from their roofs tomorrow (for fuel/sale). (b) "equkflc" implies total powerlessness — they cannot negotiate with the "vkneh" because "vkneh dk [okc lgh" (the ruler's account/reckoning is exact). The system measures their desperation as revenue; their survival acts (plucking roof) feed the ruler's ledger.
DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: "Nagarjun uses the fog as an extended metaphor that operates at three levels: physical, political, and existential. Explain this statement by tracing the fog's portrayal across the three stanzas with textual evidence."

COMPETENCY: Extended metaphor analysis and cross-stanza synthesis
STEPS:
- Step 1: Identify the three levels required: physical (Stanza 1), political (Stanza 2), existential (Stanza 3).
- Step 2: Stanza 1 physical evidence: "nk[rksa osQ lk;s esa /wi yxrh gS" — fog as tangible winter mist occupying space.
- Step 3: Stanza 2 political evidence: "rsjk fu”kke gS" — fog = ruler; "fly ns ”kqcku 'kk;j dh" — fog = extraction mechanism.
- Step 4: Stanza 3 existential evidence: "xqyeksgj osQ rys" (hope in sun's lap) vs "xSj dh xfy;ksa esa xqyeksgj" (hope only in wrinkles) — fog = barrier to fulfillment.
- Step 5: Synthesize: The metaphor extends because the *same entity* (fog) accumulates meaning without losing prior levels — it remains cold mist while becoming ruler while becoming hope-denier.
- Step 6: Structure answer with PEEL per stanza, then unifying conclusion.
ANSWER: Physically (Stanza 1), the fog is "nk[rksa osQ lk;s esa /wi yxrh gS" — a dense mist settling in courtyards, prompting the poet's imperative "pyks ;gk¡ ls pysa". Politically (Stanza 2), this same fog is revealed as "rsjk fu”kke gS" (your ruler) who orchestrates exploitation: "fly ns ”kqcku 'kk;j dh" (fills the rulers' sacks) while villagers are "equkflc" (helpless) and subject to "vkneh dk [okc lgh" (the accountant's exact reckoning). Existentially (Stanza 3), the fog blocks the sun so that "xqyeksgj" (hope/rays) remains trapped "vius cxhps esa" (in sun's lap) or only appears "xSj dh xfy;ksa esa" (in the wrinkles of faces) — hope is visible but uninhabitable. The metaphor extends because each stanza *adds* a dimension without cancelling the previous: the fog is simultaneously weather, regime, and spiritual blockade — reflecting how oppression in Nagarjun's village is atmospheric, structural, and internalized all at once.
DIFFICULTY: hard