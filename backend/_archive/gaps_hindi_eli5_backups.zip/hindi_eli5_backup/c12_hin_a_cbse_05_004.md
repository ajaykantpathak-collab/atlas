## DEFINITION
Character analysis of the protagonist involves a systematic examination of the central character's traits, motivations, development, and role in conveying the poem's themes through textual evidence such as imagery, actions, speech, and relationships.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student can independently identify the protagonist's key traits, cite specific textual evidence (images, lines, symbols), explain how the poet's language choices shape characterization, and connect the protagonist's journey to the poem's central themes of aging, memory, and mortality.

## SCOPE_BOUNDARY
This node covers character analysis of the protagonist (the old woman/olar) in the poem "olar vk;k" from NCERT Class 12 Hindi Antra Chapter 5. It does NOT cover supporting characters (node 005), themes in isolation (nodes 006-007), or literary devices as separate topics (nodes 008-009).

## WALKTHROUGH
Imagine you meet an elderly neighbor who sits on her porch every evening, watching the world change while she remains a silent witness to time. You wonder: what stories do her wrinkled hands hold? What does her gaze fixed on the horizon reveal? In "olar vk;k", the poet presents exactly such a figure — the old woman (olar) as the protagonist. To analyze her character, start by reading the poem aloud and marking every description of her physical presence, her actions, her internal world (memories, fears, acceptance), and her interactions with nature (the crow, the river, the sun). Notice how the poet uses rural dialects (ns'kt 'kCn) and vivid imagery (cM+s fi;jk, ugkbZ gok) not just as decoration but to build her authenticity. The key insight: the protagonist is not merely an old woman; she becomes a symbol of the universal human condition — the tension between clinging to life and surrendering to its inevitable end.

## DIAGNOSTIC_QUESTION_1
Identify the protagonist of the poem "olar vk;k" and state one physical detail the poet uses to establish her age and frailty in the opening stanza.

## DIAGNOSTIC_ANSWER_1
The protagonist is the old woman (olar). A physical detail is "cM+s&cM+s fi;jk, iÙks" (trembling, aged hands) which immediately conveys frailty and advanced age. A wrong answer (e.g., naming the poet or the crow as protagonist) reveals the student cannot distinguish the central character from the narrator or symbolic elements. Misidentifying the detail (e.g., citing the river) shows inability to locate textual evidence for physical characterization.

## DIAGNOSTIC_QUESTION_2
Explain in your own words how the line "vkt osQ euq"; dh vkèkqfud thou 'kSyh ij O;aX; fd;k gSA" (the poet has portrayed the realistic life-journey of the present old woman) guides your approach to analyzing her character.

## DIAGNOSTIC_ANSWER_2
This line signals that the characterization is grounded in realism, not idealization. The analysis must therefore focus on concrete, observable details of her daily existence (her chores, her body's decay, her memories) rather than abstract symbolism alone. A wrong answer that treats her as a purely allegorical figure (e.g., "she represents India's tradition") misses the NCERT's explicit emphasis on "vkèkqfud thou" (realistic life) and leads to answers that ignore textual evidence like "fiQjdh&lh vkbZ" (burning fever) or "ngj&ngj ngosaQxs" (slowly walking).

## DIAGNOSTIC_QUESTION_3
Apply the PEEL structure (Point, Evidence, Explanation, Link) to analyze the protagonist's relationship with nature using the image of the crow ("v'kksd") in the poem. Write a complete paragraph.

## DIAGNOSTIC_ANSWER_3
**Point:** The crow acts as a mirror to the protagonist's isolation and mortality. **Evidence:** The poem places the crow ("v'kksd") alongside other raw natural elements ("enu eghuk", "iapeh", "uanu&ou") that surround her. **Explanation:** The crow's harsh cry and scavenging nature reflect her own marginalized existence — both are "unwanted" yet persist in the landscape. The poet uses ns'kt (dialect) words for these elements to root her in a specific rural reality where nature is not romanticized but lived. **Link:** This connection reinforces the theme that aging is a natural, unavoidable process, not a tragedy. A weak answer would merely list the crow as a symbol of death without explaining the dialect choice or the "lived reality" aspect.

## DIAGNOSTIC_QUESTION_4
Analyze how the protagonist's internal conflict between "clinging to life" (euq"; dk izo`Qfr ls fj'rk) and "accepting death" (olar vk;k) is structured across the two poems "olar vk;k" and "rksM+ks". Compare the tone and imagery.

## DIAGNOSTIC_ANSWER_4
In "olar vk;k", the conflict is externalized through sensory imagery: the feverish body ("f[kyh gqbZ gok"), the slow walk ("ngj&ngj"), the memories of youth ("veqd fnu veqd ckj enueghus dh gksosxh iapeh"). The tone is observational, almost documentary. In "rksM+ks", the conflict becomes internal and urgent: the repetition "rksM+ks rksM+ks" mimics a heartbeat or a mantra, the imagery shifts to the body's betrayal ("eu osQ eSnkuksa ij O;kih oSQlh Åc"), and the direct address to the heart ("vkèks vkèks xkus") shows active negotiation with mortality. The structure moves from third-person portrait to first-person plea. A student who only lists images without comparing the shift from observation to invocation misses the structural progression of the protagonist's consciousness.

## DIAGNOSTIC_QUESTION_5
Evaluate the critic's claim: "The protagonist in 'olar vk;k' is passive; things happen to her, she does not act." Defend or refute using at least three textual references.

## DIAGNOSTIC_ANSWER_5
Refute. The protagonist exhibits quiet agency: (1) She actively remembers ("veqd fnu veqd ckj enueghus dh gksosxh iapeh" — she *chooses* to recall her youth), (2) She negotiates with her body ("vkèks vkèks xkus" — she urges her heart to keep beating), (3) She redefines her surroundings ("eu osQ Hkhrj dh Åc l`tu esa ckèkd gS" — she claims the pyre's fire as part of her life's culmination). Passivity would imply no internal response; her memories, prayers, and final acceptance are deliberate acts of meaning-making. A student agreeing with the critic confuses physical limitation with spiritual passivity, a common error when analyzing elderly characters.

## DIAGNOSTIC_QUESTION_6
Create a four-line stanza in Hindi (or Hindi-English mix) that captures the protagonist's voice at the moment she says "olar vk;k", using at least two dialect words (ns'kt 'kCn) from the poem and one image of nature.

## DIAGNOSTIC_ANSWER_6
Example:  
"ngj&ngj pair, ugkbZ gok,  
eu dh Åc, ab na rok.  
v'kksd bole, nadi beh,  
olar vk;k, poora keh."  
(Dialect words: ngj&ngj, ugkbZ; nature image: nadi/v'kksd). A poor answer would use only standard Hindi, lack the poem's rhythmic simplicity, or turn the moment into melodrama ("I am dying!") instead of the poem's quiet acceptance.

## COMMON_MISCONCEPTION
Students often treat the protagonist as a mere symbol of "old age" or "tradition" and write generic essays about Indian elderly women. They miss that j?kqohj lgk; constructs her through *specific* rural dialect (ns'kt), *specific* bodily sensations (fiQjdh fever, trembling hands), and *specific* rituals (rksM+ks — gathering wood for pyre). The error arises because students memorize "theme = aging" and force the character into that theme, instead of letting her unique textual details (e.g., "enueghuk" = olar's husband, not just any husband) generate the theme. This leads to answers that could apply to any poem about old age, scoring low on "textual evidence" in board marking schemes.

## ON_FAILURE
1. Re-read the poem aloud, circling every ns'kt word (enueghuk, ngj&ngj, fiQjdh, uanu&ou) and every bodily sensation.  
2. Revisit node c12_hin_a_cbse_05_002 (Plot) to map the protagonist's actions chronologically: remembering → walking → fever → gathering wood → addressing heart.  
3. Practice writing one PEEL paragraph using ONLY dialect words as evidence (e.g., "The word 'ngj&ngj' shows...").  
4. Re-attempt Diagnostic Question 4 with this constraint: every claim must quote a dialect word.

## BUILDS_ON
This node builds on the skill of identifying textual evidence for character traits introduced in Class 11 Character Analysis nodes (c11_hin_ar_cbse_05_004).

## LEADS_TO
This node enables deeper thematic analysis (nodes 006-007) where the protagonist's characterization becomes the primary evidence for themes of mortality and rural marginalization.

## PREREQUISITE_NODE_IDS
c12_hin_a_cbse_05_001, c12_hin_a_cbse_05_002, c12_hin_a_cbse_05_003, c11_hin_ar_cbse_05_004, c11_hin_v_cbse_05_004
## PREREQUISITE_REASONS
c12_hin_a_cbse_05_001: Provides biographical context of j?kqohj lgk; and his focus on rural marginalized voices, essential to understand why the protagonist speaks in dialect.  
c12_hin_a_cbse_05_002: Establishes the narrative arc (memory → present decay → ritual preparation) which structures the protagonist's psychological journey.  
c12_hin_a_cbse_05_003: Details the setting (rural riverbank, seasonal changes) that shapes the protagonist's daily reality and symbolic world.  
c11_hin_ar_cbse_05_004: Prior practice in protagonist analysis (Class 11 Antra Ch5) builds the methodological foundation (traits, evidence, development).  
c11_hin_v_cbse_05_004: Prior practice in protagonist analysis (Class 11 Vitan Ch5) reinforces the skill across different text types.

## FORWARD_NODE_IDS
c12_hin_a_cbse_05_005, c12_hin_a_cbse_05_006, c12_hin_a_cbse_05_007, c12_hin_a_cbse_05_013, c12_hin_a_cbse_05_008, c12_hin_a_cbse_05_014

## FORWARD_REASONS
c12_hin_a_cbse_05_005: Supporting characters (the crow, the river, the implied family) gain meaning only in relation to the protagonist's consciousness.  
c12_hin_a_cbse_05_006: The primary theme (mortality/acceptance) is embodied in the protagonist's arc; theme analysis requires her characterization as evidence.  
c12_hin_a_cbse_05_007: Secondary themes (rural neglect, memory as resistance) emerge from specific details of the protagonist's life.  
c12_hin_a_cbse_05_013: Critical interpretation (e.g., feminist, postcolonial readings) uses the protagonist's dialect and body as sites of analysis.
c12_hin_a_cbse_05_008: Protagonist's perspective shaped by metaphors.  
c12_hin_a_cbse_05_014: Protagonist analysis (old woman / poetic persona) — basis for character portrayal answers.  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
No cross-subject prerequisite nodes exist in the provided prior class data.

## CHAIN_DESCRIPTION
c12_hin_a_cbse_05_002 -> c12_hin_a_cbse_05_004 -> c12_hin_a_cbse_05_006

## THIS_FORMULA
N/A - conceptual

## FORMULA_VARIABLES
N/A

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
conceptual

## CROSS_SUBJECT
N/A | The protagonist's life reflects the transformation of rural India (joint family to isolation, traditional rituals vs modern neglect) — a case study for "Social Change in Modern India".  
 N/A | Her physical frailty and marginalization illustrate the geographic and demographic challenges of an ageing rural population (dependency ratio, healthcare access).  
 N/A | The use of ns'kt dialect and depiction of an elderly woman's invisibility connects to "Social Justice and Marginalized Groups" — voice, representation, dignity.
## PREREQ_CONCEPT
Ability to distinguish between a character's explicit actions and implicit psychological states using textual evidence.

## PREREQ_BEFORE
Student must know how to locate and cite specific lines/images from a poem to support a claim about character.

## PREREQ_STUCK
If stuck, review "Text: Plot and Narrative Structure" (c12_hin_a_cbse_05_002) to re-establish the sequence of the protagonist's experiences.

## WORKED_EXAMPLE_1
PROBLEM: Analyze how the poet uses the image of "fiQjdh&lh vkbZ" (burning fever) to reveal the protagonist's physical and emotional state. Write a structured answer for a 3-mark board question.

STEPS:
- Step 1: Identify the image — "fiQjdh&lh vkbZ" appears in the description of the old woman's body in "olar vk;k".
- Step 2: Classify the evidence — It is a physical symptom (fever) described through tactile imagery (burning) and dialect ("fiQjdh" = fiQjgjh, ydM+h dk f[kykSuk).
- Step 3: Explain physical state — The fever shows her body's vulnerability, the breakdown of thermoregulation in extreme age, and the immediacy of her suffering.
- Step 4: Explain emotional/psychological state — The "burning" also mirrors the "fire" of memories (veqd fnu veqd ckj...) and the impending pyre (rksM+ks). The fever is not just illness; it is the body enacting the cremation before death.
- Step 5: Link to theme — This dual literal/metaphorical function supports the theme of life-death continuity: the body already knows what the ritual will formalize.

REASONING: The steps move from literal meaning to metaphorical resonance, then to thematic synthesis — exactly the progression board examiners reward. Using the dialect glossary (fiQjdh = fiQjgjh) shows engagement with the poet's linguistic craft.

ANSWER: The image "fiQjdh&lh vkbZ" operates on two levels. Literally, it depicts the protagonist's frail body succumbing to fever — the "burning" (fiQjdh) conveys intense heat and discomfort, marking her physical decline. Metaphorically, this internal fire anticipates the external fire of the pyre (rksM+ks) she later prepares, suggesting her body already participates in the cremation ritual. The dialect word "fiQjdh" roots this universal experience in her specific rural reality. Thus, a single image fuses bodily decay, ritual inevitability, and the poem's central theme: life and death are not separate events but a continuous burning.

## WORKED_EXAMPLE_2
PROBLEM: The protagonist says "olar vk;k" (the old woman has come/arrived). Who is speaking? To whom? What does "arrived" mean in this context? Explain using the poem's shift from third to first person.

STEPS:
- Step 1: Locate the phrase — "olar vk;k" appears as the title and refrain of the first poem, and implicitly in the second poem's "vkèks vkèks xkus".
- Step 2: Identify the speaker in Poem 1 — Third-person narrator ("dfork dgrh gS", "dfo us... O;aX; fd;k") observing the old woman. "olar vk;k" here means "death/old age has arrived for her".
- Step 3: Identify the speaker in Poem 2 — The protagonist herself ("ge bldks D;k dj Mkysa bl vius eu dh [kht dks"). The refrain "rksM+ks rksM+ks" is her internal monologue.
- Step 4: Analyze the shift — The movement from "she" (observed) to "I" (experiencing) transforms "olar vk;k" from an external verdict to an internal acceptance. "Arrived" changes from "death has come to her" to "I have arrived at death's door".
- Step 5: Connect to characterization — This shift grants the protagonist subjectivity. She is not just the object of the poet's gaze; she becomes the speaker of her own ending.

REASONING: Many students miss the pronoun shift because the poems are printed separately. Tracking "dfork dgrh gS" vs "ge... Mkysa" is crucial for character agency.

ANSWER: In the first poem, a third-person narrator (the poet) declares "olar vk;k" — meaning old age/death has arrived *for* the woman. In the second poem, the protagonist speaks in first person ("ge" = we/I, "vkèks vkèks xkus" = beat, beat [my heart]), turning "olar vk;k" into her own acknowledgment: "I have arrived at this stage." The shift from object to subject is the poem's most powerful characterization technique: it gives the marginalized old woman the final word on her own life.

## WORKED_EXAMPLE_3
PROBLEM: Compare the protagonist's relationship with her husband ("enueghuk") in her memories vs. her current solitude. How does the poet use the single word "enueghuk" to convey a lifetime of partnership and loss? Write a 5-mark answer.

STEPS:
- Step 1: Define the term — "enueghuk" = dkenso dk eghuk (olar's husband), glossed in NCERT.
- Step 2: Locate its occurrence — Only once, in memory: "veqd fnu veqd ckj enueghus dh gksosxh iapeh" (long ago, many times, the fragrance of her husband's breath).
- Step 3: Analyze the memory — "iapeh" (fragrance/breath) is intimate, sensory, alive. "veqd fnu veqd ckj" emphasizes repetition, daily ritual. The husband was a constant, living presence.
- Step 4: Contrast with present — Now: "ngj&ngj ngosaQxs dgha <kd osQ taxy vke ckSj vkosaxs" (slowly, perhaps no one will fan the fevered body). The care she received (breath/fragrance) is replaced by absence (no one to fan).
- Step 5: Explain the word's weight — "enueghuk" is a compound (enu + eghuk) unique to this dialect. It fuses identity (husband of olar) and role. Its single appearance mirrors the finality of loss — he exists now only in that one olfactory memory.
- Step 6: Link to theme — The erasure of the husband mirrors the erasure of the rural world (joint family, rituals). The protagonist carries both losses.

REASONING: This example demonstrates "close reading" — extracting maximum meaning from a single, culturally specific word. It connects linguistic analysis (compound formation, dialect) to character psychology and social theme.

ANSWER: The word "enueghuk" (olar's husband) appears only once, in the line "veqd fnu veqd ckj enueghus dh gksosxh iapeh". This single occurrence carries the weight of a vanished lifetime. The memory is sensory — "iapeh" (fragrance of breath) — evoking intimate proximity: shared sleep, daily care, the rhythm of a long marriage. The repetition "veqd fnu veqd ckj" (day after day, many times) establishes him as the anchor of her routine. In the present, that anchor is gone: "ngj&ngj ngosaQxs dgha <kd osQ taxy vke ckSj vkosaxs" — perhaps no one will even fan her fevered body. The dialect compound "enu+eghuk" (she + husband) linguistically enacts their fusion; his absence fractures her identity. The poet uses one dialect word to condense a marriage, a world, and a grief that now defines the protagonist's solitude.

## COMPETENCY_QUESTION_1
QUESTION: A Class 12 student writes: "The protagonist is sad because she is old and alone." Why is this answer insufficient for a 4-mark board question on character analysis? Rewrite it using the PEEL structure with two specific textual references from "olar vk;k".

COMPETENCY: Critical Thinking - Evaluating answer quality and applying structured writing technique.

STEPS:
- Step 1: Identify the flaws — "sad" is vague; "old and alone" is generic, not text-specific; no evidence cited; no analysis of poet's craft.
- Step 2: Select two precise textual details — e.g., "fiQjdh&lh vkbZ" (physical suffering) and "veqd fnu veqd ckj enueghus dh gksosxh iapeh" (memory of husband).
- Step 3: Draft Point — The protagonist's emotional state is a complex interplay of bodily decay and selective memory, not simple sadness.
- Step 4: Draft Evidence + Explanation — The "burning fever" shows her body's rebellion; the husband's "fragrant breath" shows what she has lost. The dialect words "fiQjdh" and "iapeh" root these in her rural reality.
- Step 5: Draft Link — This complexity resists sentimentality and aligns with the poet's realist project.

ANSWER: The original answer fails because it substitutes a label ("sad") for analysis and offers zero textual evidence. Improved PEEL version: **Point:** The protagonist's inner life is a tension between present physical agony and past sensory richness. **Evidence:** Her "fiQjdh&lh vkbZ" (burning, fevered body) conveys visceral suffering, while the memory "veqd fnu veqd ckj enueghus dh gksosxh iapeh" (the fragrance of her husband's breath, day after day) evokes a lost world of intimacy. **Explanation:** The dialect term "fiQjdh" (fiQjgjh) makes the fever culturally specific, not universal; "iapeh" chooses smell — the most primal sense — for the husband's presence. **Link:** Together, they show a consciousness that registers decay without self-pity, embodying the poem's unsentimental realism.

DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: In the poem "rksM+ks", the protagonist urges her heart: "vkèks vkèks xkus / rksM+ks rksM+ks rksM+ks". A critic argues this is a moment of *resistance* against death. Another argues it is *acceptance*. Using the imagery of "eu dh [kht" (heart's wood) and "fe^h esa jl" (fire in the pyre), evaluate both views and state your judgment with reasoning.

COMPETENCY: Literary Argumentation - Weighing competing interpretations using textual evidence.

STEPS:
- Step 1: Unpack "resistance" reading — "vkèks vkèks xkus" (beat, beat) is a command to the heart to keep living; "rksM+ks" (gather wood) could be read as preparing for life (warmth) not death.
- Step 2: Unpack "acceptance" reading — "rksM+ks" explicitly means gathering wood for the pyre (cremation); "fe^h esa jl gksxk gh tc og ikslsxh cht dks" (fire will burn in pyre only when it gets wood) acknowledges the body as fuel; "eu osQ Hkhrj dh Åc l`tu esa ckèkd gS" (the fire of heart's suffering is integral to liberation).
- Step 3: Analyze "eu dh [kht" — "wood of the heart" = the self offered to fire. The heart's beating ("xkus") feeds the fire. Resistance would deny wood; acceptance *gathers* it.
- Step 4: Synthesize — The command "vkèks vkèks" is not to *avoid* death but to *meet* it fully alive. The heart beats *as* it is consumed. This is "active acceptance" — a third category.
- Step 5: Final judgment — The protagonist transforms the pyre from an external event into an internal offering. The repetition "rksM+ks rksM+ks" mirrors the heartbeat: each beat adds wood. She authors her own cremation.

ANSWER: Both binary readings are reductive. "Resistance" ignores that she *gathers* the wood (rksM+ks) herself. "Acceptance" misses the urgency of "vkèks vkèks" — a heart beating *hard* at the end. The synthesis: "eu dh [kht" (heart's wood) is the protagonist's agency. She does not passively wait for the pyre; she feeds it with her still-beating heart. The line "fe^h esa jl gksxk gh tc og ikslsxh cht dks" (fire burns only when it gets wood) makes her the *supplier* of the condition for her own liberation. Thus, "vkèks vkèks xkus" is the sound of a life fully lived *into* death. This active acceptance — gathering wood while the heart still hammers — is the poem's profound characterization of dignity.

DIFFICULTY: hard