## DEFINITION
Imagery (चित्रात्मकता/बिंब) refers to the use of vivid, sensory language that appeals to the five senses (sight, sound, smell, touch, taste) to create mental pictures and evoke physical sensations in the reader's mind. Metaphor (रूपक/रूपक अलंकार) is a figure of speech that directly equates two unlike things by stating one *is* the other (without using 'like' or 'as'), transferring the qualities of the source domain to the target domain to reveal a deeper similarity. In Class 11 Hindi Core, students must distinguish between *simple description* and *evocative imagery*, and between *simile (उपमा)* and *metaphor (रूपक)* by identifying the absence of comparative words (जैसे, समान, सा).

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student can independently locate a specific passage in "viw osQ lkFk <kbZ lky", identify whether it uses imagery or metaphor, name the specific sense appealed to (for imagery) or the two domains compared (for metaphor), and explain in 2-3 sentences how the device shapes the reader's emotional response or reinforces a theme (e.g., nostalgia, rural innocence, nature's power).

## SCOPE_BOUNDARY
This node covers *only* Imagery (types: visual, auditory, olfactory, tactile, gustatory) and Metaphor (simple, implied, extended) as they appear in Chapter 3 "viw osQ lkFk <kbZ lky". It does NOT cover Simile (उपमा), Personification (मानवीकरण), Symbolism (प्रतीकवाद), or Irony (व्यंग्य/विरोधाभास) — those are addressed in node c11_hin_ar_cbse_03_009. It does not require analysis of other chapters.

## WALKTHROUGH
Imagine you are describing your grandmother's kitchen to a friend who has never seen it. You wouldn't just say "it was nice"; you'd say "the air smelled of cumin and ghee, the floor was cool underfoot, the pressure cooker hissed a steady rhythm." That is **imagery** — you made them *feel* the kitchen. Now, if you said "Her kitchen was the heart of the house," that is a **metaphor** — you equated the kitchen to a heart to show it pumps life/love into the family. In this chapter, Iphik Ikapyh does exactly this: he doesn't just tell us the village well was important; he shows us the "cool shade of the banyan," the "rhythmic creak of the pulley," the "earthy smell of wet mud" (imagery). He doesn't just say the flood was scary; he writes "the river became a monstrous snake swallowing the village" (metaphor). Your task: read a paragraph, underline sensory words, ask "what two things are being equated here?", then write one sentence on the *effect*.

## DIAGNOSTIC_QUESTION_1
What is the precise technical difference between a Simile (उपमा अलंकार) and a Metaphor (रूपक अलंकार) in Hindi grammar? Answer in one sentence using the terms 'उपमेय', 'उपमान', and 'साधक शब्द'.

## DIAGNOSTIC_ANSWER_1
In a Simile (उपमा), the उपमेय (subject) and उपमान (object of comparison) are linked explicitly by a साधक शब्द (comparative word like 'जैसे', 'सा', 'समान', 'उपम'), whereas in a Metaphor (रूपक), the उपमेय is *directly stated to be* the उपमान with *no* साधक शब्द present — the identity is asserted, not compared. A wrong answer (e.g., "Simile uses 'like', metaphor doesn't") reveals the student knows the English rule but lacks the Hindi technical terminology (उपमेय/उपमान/साधक) required for Board answer writing.

## DIAGNOSTIC_QUESTION_2
In the passage describing the mango tree ("viw") in the story, the author writes: "viw osQ lkFk <kbZ lky rd dke dj ldh" (the shade of the mango tree reached the small well). A student claims this is a metaphor because the tree "covers" the well like a mother. Why is this *incorrect* identification? Explain using the definition of imagery vs. metaphor.

## DIAGNOSTIC_ANSWER_2
The sentence "viw osQ lkFk <kbZ lky rd dke dj ldh" is **visual and spatial imagery** (दृश्य/स्थानिक बिंब), not a metaphor. It describes the *physical extent* of the tree's shade using measurable, literal sensory detail (sight + spatial reach). No two unlike things are being equated; the shade *literally* reaches the well. The student's "mother" interpretation is a *personal association*, not a textual metaphor. A wrong answer reveals the confusion between *reader's emotional inference* and *author's explicit linguistic device* — a critical Board exam distinction.

## DIAGNOSTIC_QUESTION_3
Apply the concept: Below is a fabricated sentence *in the style of the chapter*: "बाढ़ का पानी गाँव की गलियों में ऐसे घुसा जैसे कोई चोर रात को घर में घुसता है।" Identify the device, name the दो उपमान (two domains compared), and rewrite it as a Metaphor (रूपक) by removing the साधक शब्द.

## DIAGNOSTIC_ANSWER_3
**Device:** Simile (उपमा अलंकार) — signaled by "जैसे".
**Domains:** उपमेय = बाढ़ का पानी (flood water), उपमान = चोर (thief).
**Metaphor Rewrite:** "बाढ़ का पानी गाँव की गलियों में चोर बनकर घुस आया।" (The flood water entered the village lanes *as a thief* / *became a thief*.)
**Steps:** 1) Spot "जैसे" → Simile. 2) Extract the two nouns compared. 3) Delete "जैसे" and restructure to assert identity (A *is* B). A wrong rewrite (e.g., "बाढ़ का पानी चोर की तरह घुसा") keeps the comparison, showing the student cannot operate the syntactic transformation required for Board "convert to metaphor" questions.

## DIAGNOSTIC_QUESTION_4
Analyze this actual textual moment: The author describes the bullocks (बैल) pulling the water-wheel (रहट) at the well: "बैलों की आँखों में एक अजीब-सी थकान और बेबसी थी, मानो वे बरसों से इस चक्र को ढो रहे हों।" Identify *both* devices operating here. Explain how they work *together* to create the theme of "enduring rural labor".

## DIAGNOSTIC_ANSWER_4
**Device 1: Visual/Tactile Imagery** — "आँखों में थकान और बेबसी" appeals to sight (drooping eyes) and tactile empathy (heaviness, exhaustion).
**Device 2: Simile (उपमा)** — "मानो वे बरसों से इस चक्र को ढो रहे हों" compares the bullocks' current feeling to the experience of years of labor (साधक शब्द: "मानो").
**Synergy:** The imagery makes the exhaustion *immediately sensory*; the simile *extends* that moment into a timeless history of repetitive toil. Together, they transform two animals into symbols of the village's cyclical, unending agrarian struggle. A weak answer lists devices separately without explaining the *combined thematic effect* — missing the "analyze" requirement.

## DIAGNOSTIC_QUESTION_5
Evaluate this student claim: "The chapter uses the metaphor 'viw osQ lkFk <kbZ lky' (the mango tree's shade *is* the small well) to show the tree protects the well." Is this a valid Board-level interpretation? Justify your evaluation with two specific reasons from the text.

## DIAGNOSTIC_ANSWER_5
**Invalid interpretation.** Reason 1: **Grammatical** — "viw osQ lkFk <kbZ lky rd dke dj ldh" uses the verb "पहुँचना/करना" (reached/did) describing an *action of extension*, not a copular "है" (is) equating two nouns. No metaphor exists. Reason 2: **Contextual** — The well (लड़की/कुएँ) is a separate, functional structure; the tree's shade *cools* it (functional imagery), it doesn't *become* it. The student confuses *spatial proximity imagery* with *metaphorical identity*. Board examiners penalize forcing metaphors where only imagery exists.

## DIAGNOSTIC_QUESTION_6
Create: Write a 4-line Hindi paragraph (गद्य) describing the *sound of the monsoon rain on the tin roof* (टिन की छत पर बारिश) using **at least two types of imagery** and **one original metaphor**. Do not copy from the textbook.

## DIAGNOSTIC_ANSWER_6
**Sample Answer:** "टिन की छत पर बूँदें नहीं, हज़ारों नन्हें घुंघरू नाच रहे थे (Auditory + Visual Imagery + Metaphor: बूँदें = घुंघरू)। लोहे की चादरें धड़क उठीं जैसे गाँव का दिल धड़कता हो (Simile for contrast)। मिट्टी की सौंधी गंध हवा में घुलकर रसोई तक पहुँच गई (Olfactory Imagery)। बारिश, गर्मी की जलती देह पर वैद्य का लेप बनकर गिरी (Metaphor: बारिश = लेप/दवा)।"
**Criteria for Good Answer:** 1) Two distinct sensory appeals (e.g., sound + smell). 2) One clear A=B metaphor without 'जैसे/सा'. 3) Contextually rooted in village monsoon. A poor answer uses only visual imagery, or uses "जैसे" in the metaphor line, or writes a poem instead of prose paragraph.

## COMMON_MISCONCEPTION
Students consistently confuse **Extended Description** (विस्तृत वर्णन) with **Imagery** (बिंब/चित्रात्मकता). They highlight long paragraphs about the village layout, the well's pulley system, or the flood timeline and label them "imagery" because they "create a picture." **Why this error occurs:** In middle school, "description" and "imagery" are used interchangeably. At Senior Secondary level, *imagery* requires **sensory specificity** (कौन सी इंद्रिय? — आँख, कान, नाक, त्वचा, जिह्वा) and **evocative economy** (few words, sharp sensation). A 5-line technical description of the रहट (water-wheel) mechanism is *expository prose*, not imagery. The Board awards marks only for identifying *sensory adjectives/verbs* (e.g., "चरमराती", "सोंधी", "ठंडी", "कर्कश") — not for summarizing the scene.

## ON_FAILURE
**Step 1:** Give the student a 3-sentence "non-imagery" description (e.g., "The well was deep and made of bricks. It had a pulley. Villagers drew water daily.") and a 1-sentence imagery version ("The brick well swallowed the bucket's echo, its pulley screeching like a tired bird."). **Step 2:** Ask: "Which sentence lets you *hear* the pulley? Which lets you *feel* the depth?" **Step 3:** Have them circle *only* the sensory words in the second sentence (स्वाद/गंध/स्पर्श/ध्वनि/रूप). **Step 4:** Drill: Convert 5 factual sentences from the chapter into imagery-rich versions by adding *one* sensory verb/adjective each. This trains the "sensory lens" distinct from "narrative lens."

## BUILDS_ON
c11_hin_ar_cbse_03_003 (Setting and Atmosphere) — Imagery is the primary tool the author uses to *construct* the setting and atmosphere analyzed in that node.

## LEADS_TO
c11_hin_ar_cbse_03_009 (Literary Devices: Irony and Symbolism) — Metaphor mastery is prerequisite for recognizing symbols (a symbol is an extended, culturally resonant metaphor) and irony (often created by metaphoric gap between appearance and reality).

## PREREQUISITE_NODE_IDS
c11_hin_ar_cbse_03_001, c11_hin_ar_cbse_03_002, c11_hin_ar_cbse_03_003, c11_hin_ar_cbse_03_006

## PREREQUISITE_REASONS
c11_hin_ar_cbse_03_001: Context/Background knowledge (author's life, village setting, autobiographical lens) is essential to understand *why* specific images/metaphors are chosen (e.g., the mango tree as childhood anchor).
c11_hin_ar_cbse_03_002: Plot/Narrative Structure tells *where* in the story key images appear (e.g., flood climax vs. peaceful well scenes) — device function changes with narrative position.
c11_hin_ar_cbse_03_003: Setting/Atmosphere node establishes the *sensory world* (village sounds, smells, textures) that the imagery draws from; without this, imagery analysis is rootless.
c11_hin_ar_cbse_03_006: Imagery and metaphor are the *vehicles* for the theme; analysis requires knowing the destination.  

## FORWARD_NODE_IDS
c11_hin_ar_cbse_03_009, c11_hin_ar_cbse_03_012, c11_hin_ar_cbse_03_013, c11_hin_ar_cbse_03_014, c11_hin_ar_cbse_03_015, c12_hin_a_cbse_03_008, c12_hin_a_cbse_04_008, c12_hin_a_cbse_05_008, c12_hin_a_cbse_16_008, c12_hin_ar_cbse_03_007, c12_hin_ar_cbse_03_008

## FORWARD_REASONS
c11_hin_ar_cbse_03_009: Irony/Symbolism builds directly on Metaphor (symbol = frozen metaphor; irony = metaphoric expectation vs. reality).
c11_hin_ar_cbse_03_012: Comprehension (Inferential) questions frequently ask "What does the image of X suggest about Y?" — requires device identification skill.
c11_hin_ar_cbse_03_013: Critical Thinking/Analysis tasks demand evaluating *how* language shapes meaning — imagery/metaphor are the core linguistic evidence.
c11_hin_ar_cbse_03_014: बिंब-रूपक आदि साहित्यिक उपकरण Explanation की गहराई बढ़ाते हैं।  
c11_hin_ar_cbse_03_015: Imagery/metaphor (e.g., "ल्हु" as crucible) gives linguistic tools for nuanced talk.  
c12_hin_a_cbse_03_008: Direct prior exposure to imagery/metaphor definitions and simple identification; this node deepens to analysis/evaluation.  
c12_hin_a_cbse_04_008: Practice with longer poems where imagery clusters develop themes.  
c12_hin_a_cbse_05_008: Builds analytical vocabulary for discussing sensory details.  
c12_hin_a_cbse_16_008: Adds complexity with implicit metaphors in poetic texts.  
c12_hin_ar_cbse_03_007: Class 11 imagery/metaphor node is needed because secondary themes in these poems are carried almost entirely through metaphors (house, game, word as child).  
c12_hin_ar_cbse_03_008: Provides foundational definitions of imagery types and tenor/vehicle/ground framework for metaphor analysis.  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
none

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_03_003 -> c11_hin_ar_cbse_03_008 -> c11_hin_ar_cbse_03_009 (Setting provides sensory raw material; this node teaches device identification; next node advances to higher-order figures).

## THIS_FORMULA
**Imagery Identification Formula:** `Sensory Word (Adjective/Verb/Noun) + Specific Sense Organ Targeted = Imagery Type`
**Metaphor Identification Formula:** `Noun A (उपमेय) + Copular Verb (है/था/हैं/थे) + Noun B (उपमान) + Absence of Comparative Marker (जैसे/सा/समान) = Metaphor`

## FORMULA_VARIABLES
- Sensory Word: Any word appealing to दृष्टि (sight), श्रवण (hearing), घ्राण (smell), स्पर्श (touch), रसना (taste)
- Sense Organ Targeted: The specific faculty the reader is made to use
- Noun A (उपमेय): The original subject being described
- Noun B (उपमान): The image/concept it is equated to
- Copular Verb: Linking verb asserting identity (है, था, होते, बने)
- Comparative Marker: Words like जैसे, सा, समान, उपम, मानो — **must be absent**

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
linguistic

## CROSS_SUBJECT
c11_history_nationalism | The chapter's village setting and flood imagery reflect pre-independence rural India's vulnerability to nature and colonial neglect — analyzing metaphor of "river as monster" connects to historical discourse on environmental history and peasant life.
c11_geography_human_environment | The detailed imagery of the well (रहट), mango tree, and bullocks illustrates traditional water-lifting technology and agro-pastoral adaptation — metaphor of "tree as mother" reflects cultural geography of sacred groves.

## PREREQ_CONCEPT
Ability to distinguish *literal description* (fact-based, denotative) from *figurative language* (connotative, sensory-evoking) — developed in Class 9-10 Hindi but must be sharpened with technical terminology (बिंब, रूपक, उपमेय, उपमान).

## PREREQ_BEFORE
Student must be able to underline all adjectives and verbs in a Hindi paragraph and categorize them by sense (दृश्य, श्रवण, etc.) — if they cannot do this mechanical step, they cannot analyze imagery.

## PREREQ_STUCK
Review "बिंब और अलंकार" (Imagery and Figures of Speech) from Class 10 NCERT Hindi (Kshitij/Kritika) Chapter "पद" or "साखी" — focus on the *definition tables* for बिंब (Imagery) and रूपक (Metaphor) with Hindi examples.

## WORKED_EXAMPLE_1
PROBLEM: Analyze the imagery in this passage from the chapter (paraphrased): "The floodwater entered the lanes silently at first, then rose steadily. The smell of wet mud and drowning crops filled the air. The sound of collapsing mud walls mixed with children's cries." Identify the three types of imagery, quote the exact sensory words, and explain the cumulative emotional effect.

STEPS:
- Step 1: Segment the passage into sensory clusters — Cluster 1: "entered silently, rose steadily" (Visual + Kinesthetic movement). Cluster 2: "smell of wet mud, drowning crops" (Olfactory + Visual). Cluster 3: "sound of collapsing walls, children's cries" (Auditory).
- Step 2: Label each cluster with the precise Hindi imagery type — Cluster 1: दृश्य/गतिज बिंब (Visual/Kinetic). Cluster 2: घ्राण/दृश्य बिंब (Olfactory/Visual). Cluster 3: श्रवण बिंब (Auditory).
- Step 3: Extract the *exact sensory vocabulary* — "चुपके से/धीरे-धीरे" (adverbs of manner → kinetic), "सोंधी गंध/डूबती फसल" (noun phrases → olfactory/visual), "गिरती दीवारों की आवाज़/बिलखते बच्चे" (noun+participle → auditory).
- Step 4: Analyze progression — The imagery moves from *distance* (water entering lanes) to *intimacy* (smell in air) to *violence* (walls collapsing, children crying) — mirroring the flood's escalating threat.
- Step 5: State cumulative effect — The layering of senses creates **immersive dread**: the reader cannot remain an observer; the olfactory and auditory details force visceral participation in the village's trauma, reinforcing the theme "nature's indifference to human settlement."

REASONING: This 5-step method (Segment → Label → Extract → Trace Progression → Synthesize Effect) is the Board-expected answer structure for "How does the author create atmosphere?" questions. It moves from identification (AO1) to analysis (AO2) to evaluation (AO3).

ANSWER: The passage employs Visual/Kinetic (water's silent entry), Olfactory/Visual (wet mud, drowning crops), and Auditory (collapsing walls, cries) imagery. Sensory words: "चुपके से", "सोंधी गंध", "गिरती दीवारों की आवाज़". The progression from distant visual to intimate smell to violent sound creates immersive dread, making the reader experience the flood's violation of the village.

## WORKED_EXAMPLE_2
PROBLEM: The author writes about the mango tree: "वह viw न था, हमारी माँ की गोद था।" (That mango tree was not a tree; it was our mother's lap.) Identify the metaphor, name the उपमेय and उपमान, explain the *ground of comparison* (सादृश्य), and state what theme this metaphor reinforces.

STEPS:
- Step 1: Apply Metaphor Formula — Locate copular verb "था" (was) linking two nouns. Check for comparative markers (जैसे/सा) — **absent**. Confirm: Metaphor (रूपक).
- Step 2: Identify domains — उपमेय (Subject) = "वह viw" (the mango tree). उपमान (Image) = "हमारी माँ की गोद" (our mother's lap).
- Step 3: Determine Ground of Comparison (सादृश्य) — What qualities of "mother's lap" are transferred to "mango tree"? Safety, warmth, unconditional shelter, nurturing, place of return. The tree *functions* emotionally as a mother.
- Step 4: Contextualize in chapter — The tree shelters the well, the children, the narrator's childhood. The metaphor appears when the adult narrator recalls the tree's shade reaching the well — linking physical shade to emotional refuge.
- Step 5: Link to Theme — Reinforces **Theme: Nature as Nurturer / Childhood as Lost Paradise**. The metaphor transforms a botanical entity into a maternal symbol, making the tree's eventual loss (implied by nostalgia) equivalent to losing mother's protection.

REASONING: Board answers for metaphor analysis require explicit naming of उपमेय/उपमान, articulation of सादृश्य (the "why"), and thematic linking. Skipping Step 3 (ground) yields incomplete marks.

ANSWER: Metaphor: "viw = माँ की गोद". उपमेय: आम का पेड़। उपमान: माँ की गोद। सादृश्य: सुरक्षा, छाया, पोषण, भावनात्मक आश्रय। विषयवस्तु से संबंध: प्रकृति का मातृत्व स्वरूप और बचपन का खोया हुआ स्वर्ग — पेड़ केवल वनस्पति नहीं, भावनात्मक आधार है।

## WORKED_EXAMPLE_3
PROBLEM: Compare the use of Imagery in two flood scenes: (A) "Water rose to the courtyards, mud walls dissolved." (B) "The river became a furious serpent, hissing and swallowing homes." Identify the dominant imagery type in each, the shift in agency, and how this shift serves the narrative arc from *observation* to *mythic terror*.

STEPS:
- Step 1: Analyze Scene A — "rose", "dissolved" = Visual + Kinetic imagery. Verbs are intransitive/passive. Water acts *physically* but without intent. Narrator is **observer** recording measurable change.
- Step 2: Analyze Scene B — "became a furious serpent", "hissing", "swallowing" = **Metaphor** (River = Serpent) + **Auditory** (hissing) + **Kinetic/Visual** (swallowing). The metaphor *personifies* the river with malicious agency.
- Step 3: Compare Agency — Scene A: Water as *natural force* (impersonal). Scene B: River as *mythic predator* (personal, intentional). The metaphor *creates* the agency shift.
- Step 4: Trace Narrative Function — Early flood (Scene A): Realistic, documentary tone — builds credibility. Climax flood (Scene B): Mythic, archetypal tone — elevates event to collective trauma. The shift mirrors the narrator's maturation: child sees water; adult remembers *monster*.
- Step 5: Synthesize for Board Answer — "The author shifts from denotative sensory imagery (visual/kinetic) to connotative metaphoric imagery (serpent metaphor + auditory personification) to transform a natural disaster into a mythic violation, reflecting the narrator's shift from child's perception to adult's symbolic memory."

REASONING: This compares *two passages* (a common Board "compare and contrast" task), requiring device identification, agency analysis, and structural/narrative reasoning — combining 3 concepts: Imagery types, Metaphor function, Narrative POV.

ANSWER: Scene A uses Visual/Kinetic imagery (impersonal observation). Scene B uses Metaphor (River=Serpent) + Auditory imagery (hissing) to assign malicious agency. The shift moves narrative from factual recording to mythic terror, paralleling the narrator's transition from child's eye to adult's symbolic memory.

## COMPETENCY_QUESTION_1
QUESTION: In the chapter, the well (कुआँ) is described through multiple images: "ठंडी छाया", "चरमराती रहट", "सोंधी गंध", "गहराई में झाँकता अंधेरा". A student writes: "The author uses visual, auditory, olfactory, and tactile imagery to describe the well." Upgrade this answer to a **Board-level 3-mark response** by adding *specific textual evidence* (words/phrases) and *analytical commentary* on *why* these particular senses are chosen for the well.

COMPETENCY: Textual Evidence Integration + Analytical Commentary (AO2 + AO3)

STEPS:
- Step 1: Acknowledge the student's correct identification of four imagery types.
- Step 2: For each type, insert the **exact Hindi phrase** from the text (or closest paraphrase if exact quote not memorized) that triggers that sense.
- Step 3: Add one analytical sentence per sense explaining the *functional reason*: e.g., "Tactile 'ठंडी छाया' contrasts the well's coolness with the scorching summer heat outside, establishing the well as a sanctuary."
- Step 4: Conclude with a synthesizing statement: "The multi-sensory portrait transforms the well from a mere water-source into a sensory anchor of village life."

ANSWER: The author constructs the well as a multi-sensory sanctuary: **Visual** — "ठंडी छाया" (cool shade) frames it as refuge; **Auditory** — "चरमराती रहट" (creaking water-wheel) embeds the rhythm of daily labor; **Olfactory** — "सोंधी गंध" (earthy smell) roots it in the fertile soil; **Tactile** — implied in "ठंडी" (cool touch) and "गहराई में झाँकता अंधेरा" (peering into dark depth) evokes vertigo and mystery. These senses are not decorative: they collectively oppose the harsh *visual* glare and *tactile* heat of the plains, making the well the village's sensory and social center. The well is *felt* before it is *used*.

DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: The chapter contains an **extended metaphor** where the **monsoon rain** is implicitly compared to a **festival/celebration** (उत्सव) across several paragraphs: "बूँदें नाचीं", "ढोल बजे", "गाँव जाग उठा", "बच्चे नहाए". Trace this extended metaphor through *three* distinct textual moments. For each moment, quote the metaphoric language, identify the **festival element** it maps to (e.g., music, dance, ritual bathing), and explain how the metaphor *reframes* a potentially destructive natural event (flood) as a **life-affirming cultural ritual**.

COMPETENCY: Extended Metaphor Tracking + Cultural Interpretation (AO3 + AO4)

STEPS:
- Step 1: Define "Extended Metaphor" (प्रसृत रूपक) — a single metaphor developed across multiple sentences/paragraphs with consistent mapping.
- Step 2: Locate Moment 1 (Arrival): "पहली बूँद पड़ी... बूँदें नाचने लगीं" → Maps to **Dance/Procession**. Reframes: Rain not as threat but as invited guest performer.
- Step 3: Locate Moment 2 (Intensity): "टिन की छतों पर ढोल-सा बजा" → Maps to **Music/Drums**. Reframes: Destructive pounding becomes celebratory rhythm.
- Step 4: Locate Moment 3 (Communal Participation): "बच्चे छतों पर नहाए... गाँव जाग उठा" → Maps to **Ritual Bathing/Awakening**. Reframes: Flood danger becomes purificatory communal rite.
- Step 5: Synthesize — The extended metaphor *culturally domesticates* nature: the monsoon, which later *does* cause flood (destruction), is first experienced through the village's festival lexicon, revealing a worldview where nature's cycles are **ritualized, not feared**.

ANSWER: Extended Metaphor: Monsoon = Festival.
Moment 1: "बूँदें नाचीं" → Dance. Reframes onset as joyous arrival.
Moment 2: "टिन की छतों पर ढोल-सा बजा" → Music. Reframes noise as rhythm.
Moment 3: "बच्चे छतों पर नहाए, गाँव जाग उठा" → Ritual Bath/Awakening. Reframes drenching as purification.
Significance: The metaphor encodes the village's **eco-cultural resilience** — they interpret nature's power through their own ritual grammar. The later flood tragedy is thus *doubly* tragic: it breaks the very metaphor that sustained them.

DIFFICULTY: hard