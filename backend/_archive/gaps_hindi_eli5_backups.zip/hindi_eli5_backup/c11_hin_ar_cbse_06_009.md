## DEFINITION
Irony is a literary device where the intended meaning of words or events is opposite to their literal or expected meaning, often highlighting a contradiction between appearance and reality. Symbolism is the use of objects, characters, or actions to represent abstract ideas or qualities beyond their literal sense, adding deeper layers of meaning to the text.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student must be able to identify at least two distinct types of irony (situational, dramatic, verbal) and two major symbols in the story "जूठन", explain their function with textual evidence, and articulate how each device reinforces the theme of caste-based oppression.

## SCOPE_BOUNDARY
This node covers irony and symbolism exclusively within the NCERT Class 11 Hindi Aroh Chapter 6 story "जूठन" by ओमप्रकाश वाल्मीकि. It does not cover imagery, metaphor, or other literary devices (addressed in node 008), nor does it extend to other chapters or poems.

## WALKTHROUGH
Imagine you are watching a teacher scold a student for being "dirty" while the teacher himself is sweeping dust under the rug — that jarring mismatch is irony. In "जूठन", the school is supposed to be a temple of equality, yet it forces a Dalit boy to clean toilets; that contradiction is the story's central irony. To begin, re-read the scenes where the headmaster assigns sweeping duties (pp. 70-71) and where the protagonist's name "जूठन" is revealed (p. 69). Ask: "What is expected in a school? What actually happens?" For symbolism, notice recurring objects: the broom (बुहारना), the leftover food (जूठन), the school building. Each stands for something larger — systemic oppression, dehumanization, institutional hypocrisy. The key insight: irony exposes the gap between ideals and reality; symbols condense that gap into tangible images you can point to in the text.

## DIAGNOSTIC_QUESTION_1
Define situational irony and give one example from "जूठन" where the outcome is the opposite of what the characters or reader expect.

## DIAGNOSTIC_ANSWER_1
Situational irony occurs when events turn out opposite to what is anticipated. In "जूठन", the headmaster, who should uphold education and equality, forces the Dalit protagonist to clean the school premises — a task that reinforces caste hierarchy instead of dismantling it. A wrong answer (e.g., "the boy is sad") shows the student confuses irony with mere misfortune or emotional tone, missing the structural contradiction between role and action.

## DIAGNOSTIC_QUESTION_2
Explain in your own words how the name "जूठन" functions as a symbol. What abstract idea does it represent beyond its literal meaning of "leftover food"?

## DIAGNOSTIC_ANSWER_2
The name "जूठन" symbolizes the Dalit community's treatment as social leftovers — discarded, considered impure, and denied dignity. It represents systemic dehumanization where an entire group is reduced to waste. A wrong answer (e.g., "it's just a nickname") reveals the student reads the name literally and misses the symbolic compression of caste oppression into a single word.

## DIAGNOSTIC_QUESTION_3
Identify an instance of dramatic irony in the story where the reader knows more than a character. Describe the scene and explain the effect on the reader.

## DIAGNOSTIC_ANSWER_3
When the headmaster praises the school's "discipline" and "cleanliness" (p. 71) while the reader knows this cleanliness is maintained by forcing a child to sweep instead of study, dramatic irony arises. The reader sees the hypocrisy the headmaster ignores. A wrong answer (e.g., "the boy feels bad") indicates the student cannot distinguish dramatic irony from character emotion; they must recognize the knowledge gap between reader and character.

## DIAGNOSTIC_QUESTION_4
Compare the broom (बुहारना) and the school building as symbols. How does each symbol reveal a different dimension of caste oppression?

## DIAGNOSTIC_ANSWER_4
The broom symbolizes forced menial labor imposed on Dalit children — the physical enactment of caste duty. The school building symbolizes the institution that legitimizes this oppression under the guise of education. Together, they show oppression as both daily practice (broom) and structural sanction (building). A wrong answer treating both as "just objects" fails to analyze how symbols operate at different levels: one micro (daily act), one macro (institutional framework).

## DIAGNOSTIC_QUESTION_5
Evaluate the author's use of verbal irony in the dialogue between the headmaster and the protagonist's father (pp. 72-73). Does it strengthen or weaken the critique of casteism? Justify.

## DIAGNOSTIC_ANSWER_5
The headmaster's polite, "reasonable" tone while denying the boy's right to education — e.g., "नियम हैं" (rules exist) — is verbal irony: his words claim fairness but enact exclusion. This strengthens the critique by exposing how casteism hides behind bureaucratic language. A wrong answer (e.g., "the headmaster is polite") misses the ironic gap between speech and intent, showing the student cannot detect tone-based irony.

## DIAGNOSTIC_QUESTION_6
Create a new symbolic object that could appear in a modern sequel to "जूठन" to represent the persistence of caste discrimination in urban schools. Explain its significance in 2-3 sentences.

## DIAGNOSTIC_ANSWER_6
A cracked digital tablet given only to Dalit students while others receive new ones — symbolizing the "digital divide" as the new broom. It represents how technological access replaces sweeping as the marker of exclusion. A poor answer (e.g., "a broken chair") lacks connection to contemporary structural inequality, showing the student cannot transfer symbolic thinking to new contexts.

## COMMON_MISCONCEPTION
Students often equate irony with any unfortunate event ("It's ironic that he failed") and treat symbols as mere metaphors ("The broom is a metaphor for cleaning"). In "जूठन", the irony is structural: the school's *function* (education) contradicts its *practice* (caste enforcement). The broom is not just a comparison — it *is* the material instrument of oppression, making it a symbol, not a metaphor. This error arises because middle-school teaching reduces irony to "opposite meaning" and symbolism to "stands for", without analyzing institutional contradiction or material embodiment.

## ON_FAILURE
1. Have the student list three expectations a parent has for a school (learning, safety, equality). 2. Next to each, write what actually happens to the protagonist in the text. 3. Ask: "Where is the gap? That gap is situational irony." 4. For symbols, give two objects (broom, name) and ask: "If you removed this object, would the caste system in the story still work the same way?" If yes, it's a prop; if no, it's a symbol because the system *runs through* it. 5. Practice with a fresh passage: identify one irony and one symbol using these tests.

## BUILDS_ON
Node c11_hin_ar_cbse_06_008 (Literary Devices: Imagery and Metaphor) — understanding metaphor as implicit comparison prepares the student to grasp symbolism as material embodiment of abstract forces.

## LEADS_TO
Node c11_hin_ar_cbse_06_013 (Critical Thinking: Analysis and Interpretation) — irony and symbolism are core tools for the deep textual analysis required in critical interpretation.

## PREREQUISITE_NODE_IDS
c11_hin_ar_cbse_06_001, c11_hin_ar_cbse_06_002, c11_hin_ar_cbse_06_004, c11_hin_ar_cbse_06_006, c11_hin_ar_cbse_06_008, c11_hin_ar_cbse_06_007

## PREREQUISITE_REASONS
c11_hin_ar_cbse_06_001: Context on Dalit autobiography and caste background is essential to recognize the systemic irony.
c11_hin_ar_cbse_06_002: Plot knowledge lets the student locate specific scenes where irony and symbols operate.
c11_hin_ar_cbse_06_004: Understanding the protagonist's experiences is needed to see how irony affects him personally.
c11_hin_ar_cbse_06_006: The primary theme (caste oppression) is what irony and symbolism serve; without it, devices become decorative.
c11_hin_ar_cbse_06_008: Prior work on metaphor builds the conceptual bridge to symbolism as embodied meaning.
c11_hin_ar_cbse_06_007: Irony and symbolism are primary vehicles for secondary themes (e.g., teacher's refusal = symbolic complicity).  

## FORWARD_NODE_IDS
c11_hin_ar_cbse_06_010, c11_hin_ar_cbse_06_011, c11_hin_ar_cbse_06_012, c11_hin_ar_cbse_06_013, c11_hin_ar_cbse_06_014, c11_hin_ar_cbse_06_015, c12_hin_a_cbse_05_009, c12_hin_a_cbse_10_009, c12_hin_al_cbse_01_009, c12_hin_ar_cbse_06_009, c12_hin_ar_cbse_09_009, c12_hin_ar_cbse_12_009

## FORWARD_REASONS
c11_hin_ar_cbse_06_010: Key vocabulary (जूठन, बुहारना, नियम) gains depth when understood as ironic/symbolic terms.
c11_hin_ar_cbse_06_011: Language usage analysis requires spotting ironic tone in dialogues.
c11_hin_ar_cbse_06_012: Inferential comprehension questions often ask "What does the broom symbolize?" or "Why is the headmaster's statement ironic?"
c11_hin_ar_cbse_06_013: Critical interpretation relies on explaining how irony and symbolism construct the theme.
c11_hin_ar_cbse_06_014: Writing tasks (e.g., analytical paragraph) demand evidence of these devices.
c11_hin_ar_cbse_06_015: Discussion points on caste and education are enriched by referencing specific ironic scenes and symbols.
c12_hin_a_cbse_05_009: अगला तार्किक चरण: Irony is a literary device where the intended meaning of words or a situation is opposite to their l... इस नोड की अवधारणाओं को सीधे उपयोग/विस्तारित करता है।  
c12_hin_a_cbse_10_009: Chapter 6 explored dramatic irony in narrator-reader gaps — key for this chapter's reflective narration.  
c12_hin_al_cbse_01_009: Class 11 Antra Chapter 6 Irony and Symbolism node connects to thematic analysis.  
c12_hin_ar_cbse_06_009: Class 11 node on same devices provides foundational definitions and simpler poem examples; essential for recognizing device types before complex application.  
c12_hin_ar_cbse_09_009: Connects irony to theme in shorter lyrics.  
c12_hin_ar_cbse_12_009: अगला तार्किक चरण: Irony in this story is the contrast between appearance and reality — where the wealthy waste water c... इस नोड की अवधारणाओं को सीधे उपयोग/विस्तारित करता है।  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
none

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_06_008 -> c11_hin_ar_cbse_06_009 -> c11_hin_ar_cbse_06_013

## THIS_FORMULA
N/A - conceptual

## FORMULA_VARIABLES
N/A

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
analytical

## CROSS_SUBJECT
c11_history_caste_system | The story's irony and symbols dramatize the historical persistence of caste hierarchy in colonial and post-colonial institutions, linking literary analysis to historical structures of oppression.
c11_sociology_social_stratification | Symbols like the broom and name "जूठन" illustrate sociological concepts of ritual purity, occupational immobility, and symbolic violence in everyday school settings.

## PREREQ_CONCEPT
Understanding that literary devices are not decorative but functional — they construct the text's critique of social reality.

## PREREQ_BEFORE
The student must know the story's plot, main characters, and the central theme of caste-based discrimination in education.

## PREREQ_STUCK
If stuck, review the headmaster's dialogues (pp. 70-73) and the sweeping scenes (pp. 71-72) to see the gap between words and actions, and the objects that carry that gap.

## WORKED_EXAMPLE_1
PROBLEM: Analyze the situational irony in the scene where the headmaster tells the protagonist's father, "नियम हैं, सबके लिए समान हैं" (Rules exist, they are equal for all) while the protagonist is made to sweep the school.

STEPS:
- Step 1: Identify the expected norm — a school rule should apply equally to all students regardless of caste.
- Step 2: Identify the actual practice — the rule is used to justify forcing only the Dalit boy to sweep, while upper-caste children study.
- Step 3: Name the irony type — situational irony, because the outcome (caste-based labor) contradicts the stated purpose of the rule (equality).
- Step 4: Explain the effect — the irony exposes the headmaster's hypocrisy and the institutionalization of casteism; the rule becomes a tool of oppression.
- Step 5: Connect to theme — this irony reinforces the theme that education systems can replicate social hierarchy instead of challenging it.

REASONING: The steps move from surface expectation to structural contradiction, ensuring the student sees irony as a system-level mismatch, not just a character's bad luck.

ANSWER: The headmaster's claim of equal rules is situationally ironic because the rule is applied selectively to enforce caste labor. The irony reveals that "equality" in the school is a façade masking caste oppression.

## WORKED_EXAMPLE_2
PROBLEM: Explain how the symbol of "जूठन" (leftover food) operates at three levels: literal, social, and psychological in the story.

STEPS:
- Step 1: Literal level — the protagonist is given leftover food from upper-caste households; the name "जूठन" comes from this practice.
- Step 2: Social level — the name marks him as permanently polluted, justifying his exclusion from equal treatment in school.
- Step 3: Psychological level — the internalization of "being leftover" shapes his self-perception until he resists through education.
- Step 4: Show textual evidence — the father's shame (p. 69), the headmaster's dismissal (p. 72), the protagonist's later assertion of identity.
- Step 5: Synthesize — the symbol condenses the entire caste experience: material deprivation, social stigma, and the struggle for self-definition.

REASONING: Breaking the symbol into levels prevents reduction to "just a name" and shows how symbolism works across material, structural, and subjective dimensions.

ANSWER: "जूठन" is a multi-level symbol: literally leftover food, socially a caste marker of impurity, psychologically an internalized identity that the protagonist overcomes through literacy.

## WORKED_EXAMPLE_3
PROBLEM: Compare the dramatic irony in the headmaster's inspection scene (p. 71) with the verbal irony in his conversation with the father (pp. 72-73). How do they together strengthen the critique of institutional casteism?

STEPS:
- Step 1: Dramatic irony in inspection — the headmaster praises the school's cleanliness; the reader knows it is cleaned by a child denied education.
- Step 2: Verbal irony in dialogue — the headmaster uses bureaucratic language ("नियम", "अनुशासन") to deny the boy's right, claiming fairness while practicing exclusion.
- Step 3: Contrast the two — dramatic irony reveals the *material reality* (sweeping body); verbal irony reveals the *ideological cover* (justifying language).
- Step 4: Show interdependence — the verbal irony legitimizes the dramatic irony; the rules cited verbally are what make the sweeping mandatory.
- Step 5: Link to theme — together they show casteism as both physical practice and discursive strategy, making the critique systemic.
- Step 6: Board-exam style answer structure — Point (two ironies), Evidence (scenes), Explanation (how they interlock), Link (theme of institutional hypocrisy).

REASONING: This multi-step comparison teaches the student to see literary devices as interacting components of a larger argument, not isolated examples.

ANSWER: The dramatic irony exposes the bodily reality of caste labor; the verbal irony exposes the linguistic masking of that reality. Together they demonstrate that the school sustains casteism through both forced work and bureaucratic rhetoric.

## COMPETENCY_QUESTION_1
QUESTION: In the story, the protagonist's mother says, "हमारे बच्चे पढ़-लिखकर क्या करेंगे?" (What will our children do by studying?). Identify the type of irony here and explain how it reflects the internalized oppression of the Dalit community.

COMPETENCY: Critical interpretation of irony as social commentary

STEPS:
- Step 1: Recognize the speaker's expectation — education is seen as futile for Dalits because caste barriers seem insurmountable.
- Step 2: Identify the irony — situational irony: the very tool that could liberate (education) is dismissed by the oppressed themselves due to historical experience.
- Step 3: Explain internalized oppression — the mother's words show how casteism makes its victims doubt their own agency.
- Step 4: Connect to the protagonist's arc — his eventual success as a writer proves the mother's fear wrong, deepening the irony retrospectively.

ANSWER: This is situational irony arising from internalized oppression: the mother, shaped by generations of exclusion, cannot imagine education changing their fate. The irony underscores how casteism colonizes the imagination of the oppressed.

DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: The school building in "जूठन" is described as "एक देवस्थान की तरह" (like a temple). Yet the protagonist sweeps its floors. Analyze this description as a symbol and explain the irony embedded in the comparison.

COMPETENCY: Synthesis of symbolism and irony to evaluate institutional critique

STEPS:
- Step 1: Identify the symbolic comparison — school as temple implies sanctity, purity, universal access.
- Step 2: Identify the reality — the temple-school admits the Dalit boy only as a sweeper, not a student.
- Step 3: Name the irony — situational irony: a space symbolizing spiritual equality practices physical untouchability.
- Step 4: Analyze the symbol's function — the building embodies the contradiction between constitutional ideals (education for all) and caste practice.
- Step 5: Evaluate author's intent — the temple metaphor heightens the moral indictment: the institution sacralizes its own hypocrisy.

ANSWER: The school-as-temple symbol represents the ideal of inclusive education. The irony lies in the building's sacred symbolism masking its role as a site of caste enforcement. This duality makes the critique sharper: the institution doesn't just fail its ideals — it actively uses them to legitimize exclusion.

DIFFICULTY: hard