## DEFINITION
Literal comprehension questions require answers directly stated in the text (who, what, where, when), while inferential comprehension questions require students to draw conclusions using textual evidence and reasoning (why, how, what does this imply). Both types demand evidence-based responses grounded in the poem's lines.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student can independently distinguish between literal and inferential questions, locate exact textual evidence for literal answers, and construct logical inferences supported by specific lines/phrases for inferential answers — writing structured responses using the Point-Evidence-Explanation format for both question types.

## SCOPE_BOUNDARY
This node covers strategies for answering literal and inferential comprehension questions based on the two poems in Chapter 1 (nsolsuk dk xhr and dkusZfy;k dk xhr). It does NOT cover critical analysis, thematic essays, or creative writing — those are addressed in subsequent nodes (c12_hin_a_cbse_01_013, c12_hin_a_cbse_01_014).

## WALKTHROUGH
Imagine you're sitting in the board exam and see a question: "nsolsuk ne apne priyatam ko 'ckoyh' kyon kaha?" — your mind goes blank because the word 'ckoyh' isn't explained in the poem directly. That's an inferential question. Start by reading the question twice: underline whether it asks "what does the text say?" (literal) or "what does the text suggest?" (inferential). For literal questions, scan the poem for keywords from the question — the answer is sitting there. For inferential questions, collect 2-3 relevant lines, identify the emotional tone or imagery, then explain the implied meaning. The key insight: every inferential answer must be anchored in literal evidence — no guessing, only logical deduction from the poet's chosen words.

## DIAGNOSTIC_QUESTION_1
What is the primary difference between a literal comprehension question and an inferential comprehension question in poetry analysis?

## DIAGNOSTIC_ANSWER_1
A literal question asks for information explicitly stated in the poem (e.g., "What did the poet say to the beloved?"), while an inferential question asks for meaning derived from evidence (e.g., "Why did the poet call the beloved 'ckoyh'?"). A wrong answer that says "literal means easy, inferential means hard" reveals the student confuses difficulty level with cognitive demand — they don't understand that both require textual evidence, just different types of reasoning.

## DIAGNOSTIC_QUESTION_2
In "nsolsuk dk xhr", the line "eSaus Hkzeo'k thou lafpr, eèkqdfj;ksa dh Hkh[k yqVkbZ" appears. A student answers: "The poet destroyed his life and the lives of sinners." What misconception does this reveal?

## DIAGNOSTIC_ANSWER_2
The student treats the metaphor "Hkzeo'k thou lafpr" (offered life) and "eèkqdfj;ksa dh Hkh[k yqVkbZ" (burned the boat of sinners) as literal actions. The correct interpretation: the poet metaphorically dedicated his life to love and severed ties with worldly norms. The misconception is reading poetic metaphors as factual events — a literal reading of figurative language. This shows the student hasn't learned to distinguish poetic device from literal statement.

## DIAGNOSTIC_QUESTION_3
Apply the Point-Evidence-Explanation (PEE) structure to answer this inferential question: "dkusZfy;k dk xhr mein 'mM+rs [kx' ka kya arth hai?" Use the poem's imagery.

## DIAGNOSTIC_ANSWER_3
Point: "mM+rs [kx" symbolizes the rising sun of freedom and new consciousness. Evidence: The line "mM+rs [kx ftl vksj eq¡g fd, µ le> uhM+ fut I;kjk" connects the rising moment to the awakening of the nation's destiny. Explanation: The poet uses dawn imagery to show India's freedom struggle reaching its peak — the "mM+rs [kx" is not just sunrise but the historical moment of national awakening. A wrong answer quoting only the dictionary meaning of "mM+rs" (rising) misses the symbolic layer — showing inability to connect image to theme.

## DIAGNOSTIC_QUESTION_4
Compare the use of "fire" imagery in both poems: "Hkh[k yqVkbZ" (nsolsuk) and "cjlkrh vk¡[kksa osQ ckny" (dkusZfy;k). What different emotional states do they represent?

## DIAGNOSTIC_ANSWER_4
In nsolsuk, "Hkh[k yqVkbZ" (burned the boat) represents self-sacrifice and irreversible commitment to love — fire as purification and severance. In dkusZfy;k, "cjlkrh vk¡[kksa osQ ckny" (mountains of shining embers) represents the fiery passion of revolutionaries — fire as collective energy and transformative power. A wrong answer saying "both show anger" reveals failure to analyze context: one is personal/spiritual, the other national/collective. The student misses how the same element serves different thematic purposes.

## DIAGNOSTIC_QUESTION_5
Evaluate this student answer to "nsolsuk ne apne priyatam ko 'ckoyh' kyon kaha?": "Kyunki priyatam ne uska saath chhod diya tha." Is this a valid inference? Justify.

## DIAGNOSTIC_ANSWER_5
No, this is an invalid inference. The poem shows the poet addressing the beloved as "ckoyh" (deceiver) while describing his own devotion ("eSaus Hkzeo'k thou lafpr") and the beloved's indifference ("viuh nzqreku nqcZyrkvksa... yksgk ysrh jgh gSA"). The text never states the beloved left — rather, the poet feels deceived by the beloved's attachment to worldly illusions ("gkjus dh fuf'prrk") while he remains devoted. The student invented a plot event not in the text — a common error of importing external narrative assumptions into lyric poetry.

## DIAGNOSTIC_QUESTION_6
Create an inferential question for "dkusZfy;k dk xhr" that requires connecting the line "gse oqaQHk ys m"kk losjs" to the poem's central theme of national pride. Write the question and a model answer using PEE.

## DIAGNOSTIC_ANSWER_6
Question: "dfork mein 'gse oqaQHk ys m"kk losjs' pankti ke madhyam se kavi ne Bharat ki kaun si visheshta ko ujagar kiya hai?" Model Answer: Point: The line highlights India's inclusive greatness. Evidence: "gse oqaQHk ys m"kk losjs µ Hkjrh <qydkrh lq[k esjs" — the poet says India's greatness embraces both the high mountains (Himalayas) and the oceans. Explanation: This geographical inclusivity mirrors cultural inclusivity — India's pride lies in unity of diversity, a core theme of the poem. A poor answer would only describe the geography without linking to "izkÑfrd lkSan;Z" — showing inability to move from literal image to thematic inference.

## COMMON_MISCONCEPTION
Students believe inferential questions allow "any opinion" as long as it sounds reasonable. They write answers like "I think the poet feels sad because..." without quoting a single line. The exact error: treating inference as subjective guesswork rather than evidence-based deduction. In board exams, this yields zero marks because CBSE marking scheme requires textual evidence for every inferential claim. The misconception stems from confusing "infer" with "imagine" — they don't realize inference = evidence + logic, not feeling + guess.

## ON_FAILURE
Step 1: Give the student a 4-line stanza from nsolsuk dk xhr and ask: "Underline every word that directly answers 'What did the poet do?'" — this isolates literal evidence. Step 2: Ask: "Now, using ONLY those underlined words, explain why the poet calls himself 'fonkbZ'." — forces inference from evidence. Step 3: Show a model PEE answer for the same question. Step 4: Have the student rewrite their original answer using the PEE template. Step 5: Re-diagnose with a fresh inferential question from dkusZfy;k dk xhr (e.g., on "efnj m¡Q?krs jgrs tc") to verify transfer.

## BUILDS_ON
Class 11 comprehension skills (c11_hin_ar_cbse_01_012 etc.) where students learned basic question types but not the rigorous PEE structure or metaphor-literal distinction required at Class 12 board level.

## LEADS_TO
Critical Thinking: Analysis and Interpretation (c12_hin_a_cbse_01_013) where students use these comprehension skills to evaluate themes, compare poems, and write analytical essays.

## PREREQUISITE_NODE_IDS
c12_hin_a_cbse_01_001, c12_hin_a_cbse_01_002, c12_hin_a_cbse_01_008, c12_hin_a_cbse_01_009, c12_hin_a_cbse_01_010, c12_hin_a_cbse_01_011, c11_hin_ar_cbse_01_012, c11_hin_ar_cbse_02_012, c12_hin_a_cbse_01_006

## PREREQUISITE_REASONS
c12_hin_a_cbse_01_001: Context/background knowledge needed to understand historical references in inferential answers (e.g., freedom struggle in dkusZfy;k)
c12_hin_a_cbse_01_002: Narrative structure helps locate where in the poem key evidence appears
c12_hin_a_cbse_01_008: Imagery/metaphor identification is essential for interpreting figurative language in inferential questions
c12_hin_a_cbse_01_009: Irony/symbolism knowledge needed for deeper inferences (e.g., "ckoyh" as ironic address)
c12_hin_a_cbse_01_010: Vocabulary meanings (e.g., "lafpr", "eèkqdfj;ksa") are prerequisite for literal accuracy
c12_hin_a_cbse_01_011: Grammar usage helps parse complex poetic constructions for exact meaning
c11_hin_ar_cbse_01_012: Class 11 literal/inferential foundation — this node advances it with PEE rigor
c11_hin_ar_cbse_02_012: Prior practice with different poems builds transferable comprehension strategies
c12_hin_a_cbse_01_006: Comprehension questions (literal/inferential) test theme-based inference.  

## FORWARD_NODE_IDS
c12_hin_a_cbse_01_013, c12_hin_a_cbse_01_014, c12_hin_a_cbse_01_015

## FORWARD_REASONS
c12_hin_a_cbse_01_013: Critical analysis requires precise comprehension as its evidence base — you cannot analyze what you haven't correctly understood
c12_hin_a_cbse_01_014: Writing skills (answers, essays) depend on the PEE structure mastered here for structured, evidence-based responses
c12_hin_a_cbse_01_015: Literal and inferential comprehension ensures students can accurately reference plot/narrative details during discussion.  

## CROSS_SUBJECT_PREREQS
c11_hin_ar_cbse_01_012, c11_hin_ar_cbse_02_012
## CROSS_SUBJECT_REASONS
c11_hin_ar_cbse_01_012: Establishes the baseline comprehension framework (literal vs inferential) that this Class 12 node deepens with board-exam rigor
c11_hin_ar_cbse_02_012: Provides practice with a different poem (Chapter 2 of Class 11) ensuring the skill transfers across texts — essential for unseen passages in CUET/board exams

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_01_012 -> c12_hin_a_cbse_01_012 -> c12_hin_a_cbse_01_013

## THIS_FORMULA
PEE Structure for Comprehension Answers: Point (direct answer) + Evidence (quoted line/phrase with stanza reference) + Explanation (how evidence proves point, linking to context/theme)

## FORMULA_VARIABLES
Point = one-sentence answer to the question; Evidence = exact words from poem with location (e.g., "stanza 2, line 3"); Explanation = 2-3 sentences connecting evidence to point using literary concepts (imagery, tone, symbolism, context)

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
linguistic

## CROSS_SUBJECT
N/A | The poem "dkusZfy;k dk xhr" explicitly references India's freedom struggle ("mM+rs [kx ftl vksj eq¡g fd, µ le> uhM+ fut I;kjk") — comprehension of this poem requires historical context of nationalist imagery (Himalayas, oceans, rising sun) taught in History Chapter 3
 N/A | The line "vutku dks Hkh lgkjk nsuk vkSj ygjksa dks Hkh fdukjk nsuk" reflects constitutional values of fraternity and justice — inferential questions on this require Civics understanding of Preamble ideals
## PREREQ_CONCEPT
Ability to distinguish poetic metaphor from literal statement — developed in Class 11 literary devices nodes (imagery, symbolism)

## PREREQ_BEFORE
Student must have read both poems at least twice, marked all metaphors/similes, and looked up vocabulary meanings from the textbook's 'kCnkFkZ section

## PREREQ_STUCK
If stuck on an inferential question, return to the literal evidence: "Which three lines in the poem mention the beloved's behavior?" — build inference only from those lines

## WORKED_EXAMPLE_1
PROBLEM: Answer the inferential question: "nsolsuk dk xhr mein kavi ne apne priyatam ko 'ckoyh' kyun kaha? Spasht kijiye." (2 marks)

STEPS:
- Step 1: Identify question type — "kyun" signals inferential; need to explain reason using textual evidence
- Step 2: Scan poem for "ckoyh" and surrounding context — found in stanza 3: "rwus [kks nh ldy dekbZA / p<+dj esjs thou&jFk ij / izy; py jgk vius iFk ij"
- Step 3: Collect literal evidence: (a) Poet devoted life: "eSaus Hkzeo'k thou lafpr" (stanza 1); (b) Beloved walks carelessly on poet's heart: "izy; py jgk vius iFk ij"; (c) Beloved attached to illusions: "viuh nzqreku nqcZyrkvksa... yksgk ysrh jgh gSA" (prose commentary)
- Step 4: Synthesize inference: The poet calls her 'ckoyh' not because she betrayed him actively, but because she remains indifferent to his total surrender while pursuing worldly illusions — her unawareness is the deception
- Step 5: Draft PEE answer: Point: Kavi priyatam ko 'ckoyh' isliye kehte hain kyunki usne kavi ke samarpan ka mulya nahi samjha. Evidence: "eSaus Hkzeo'k thou lafpr" aur "izy; py jgk vius iFk ij". Explanation: Kavi ne apna poora jeevan prem ke liye samarpit kar diya (lafpr), lekin priyatam uske hriday par beparwahi se chalti rahi, apni hi maya mein lina — yeh berukhi hi dhokha hai.

REASONING: The steps enforce evidence-first reasoning: locate keyword → gather literal facts → deduce implied meaning → structure as PEE. This mirrors CBSE marking scheme which awards 1 mark for correct point + 1 mark for textual support.

ANSWER: Kavi priyatam ko 'ckoyh' isliye kehte hain kyunki priyatam ne kavi ke poore samarpan (thou lafpr) ke baavjud uski bhavnaon ka khayal nahi rakha aur apni hi maya/nqcZy mein lina rahi — uski yeh beparwahi hi kavi ke liye dhokha hai. (Evidence: "eSaus Hkzeo'k thou lafpr" aur "izy; py jgk vius iFk ij")

## WORKED_EXAMPLE_2
PROBLEM: Answer the literal question: "dkusZfy;k dk xhr mein kavi ne Bharat ki kaun kaun si visheshtayen batayi hain?" (3 marks)

STEPS:
- Step 1: Identify question type — "kaun kaun si" asks for listed items explicitly in poem → literal
- Step 2: Divide poem into imagery clusters: geographical (stanza 1-2), cultural (stanza 3), spiritual (stanza 4)
- Step 3: Extract explicit descriptors: (a) "tgk¡ igq¡p vutku f{kfrt dks feyrk ,d lgkjk" — unity of labor and capital; (b) "lkj rkejl xHkZ foHkk ij" — red soil symbolizing sacrifice; (c) "fNVdk thou gfj;kyh ij µ eaxy oqaQoqQe lkjk" — vibrant life like blooming garden; (d) "mM+rs [kx ftl vksj eq¡g fd, µ le> uhM+ fut I;kjk" — dawn of destiny; (e) "cjlkrh vk¡[kksa osQ ckny" — revolutionary fire; (f) "ygjsa Vdjkrh vuar dh µ ikdj tgk¡ fdukjk" — generosity to young/old
- Step 4: Organize into 3-4 clear categories for 3-mark answer: Geographic diversity, Unity of opposites, Revolutionary spirit, Inclusive generosity
- Step 5: Write answer using exact phrases: "Kavi ne Bharat ki visheshtayen ye batayi hain: (1) Bhoogolik vividhata — 'gse oqaQHk ys m"kk losjs' (Himalaya se sagar tak); (2) Virodhiyon ka milan — 'vutku f{kfrt dks feyrk ,d lgkjk' (shram aur poonji ka sangam); (3) Krantikari chetna — 'cjlkrh vk¡[kksa osQ ckny' (kranti ki aag); (4) Samaveshi udayrata — 'ygjsa... fdukjk' (sabko dene wala)."

REASONING: Literal questions require exhaustive textual coverage without interpretation. The steps ensure no explicit detail is missed and answer is organized for maximum marks — each distinct feature from text = potential mark.

ANSWER: Kavi ne Bharat ki char mukhya visheshtayen batayi hain: (1) Bhoogolik vistar — 'gse oqaQHk ys m"kk losjs'; (2) Virodhiyon ka saamanjasya — 'vutku f{kfrt dks feyrk ,d lgkjk'; (3) Krantikari urja — 'cjlkrh vk¡[kksa osQ ckny'; (4) Samaveshi udayrata — 'ygjsa Vdjkrh vuar dh µ ikdj tgk¡ fdukjk'.

## WORKED_EXAMPLE_3
PROBLEM: A student writes this answer to "nsolsuk ke xhr mein 'nqcZy in cy' aur 'gkjh gksM+' ka bhav spast kijiye": "Iska matlab hai ki kavi ne apni ichchhaon ko tod diya." Remediate using PEE and metaphor analysis.

STEPS:
- Step 1: Diagnose error — student gives vague summary ("ichchhaon ko tod diya") without analyzing the specific metaphors "nqcZy in" (false eyelashes) and "cy" (eyelids) or "gkjh" (thick) "gksM+" (eyelashes)
- Step 2: Return to text — stanza 2: "eSaus fut nqcZy in&cy ij / mlls gkjh&gksM+ yxkbZA / ykSVk yks ;g viuh Fkkrh / esjh djQ.kk gk&gk [kkrh"
- Step 3: Analyze metaphor literally: "nqcZy in cy" = artificial beauty (false eyelashes on eyelids); "gkjh gksM+" = heavy, burdensome eyelashes. The poet places this artificial weight on his own eyes ("fut... yxkbZ")
- Step 4: Infer meaning: The poet deliberately blinds himself to reality by adopting the beloved's false beauty — he wears her illusion ("viuh Fkkrh") as his own, which then consumes him ("djQ.kk gk&gk [kkrh" — eats his sight like fire)
- Step 5: Construct corrected PEE: Point: Ye panktiyan kavi ke andhe prem ko darshati hain jahan wo priyatam ki jhooti sundarta ko apni aankhon par laga leta hai. Evidence: "eSaus fut nqcZy in&cy ij mlls gkjh&gksM+ yxkbZA". Explanation: 'nqcZy in' (jhooti palkein) priyatam ki maya ka prateek hain; kavi unhe apni 'cy' (aankhon) par laga ke sachai dekhna band kar deta hai. 'gkjh gksM+' ka bhar uski drishti jala deta hai ('djQ.kk gk&gk [kkrh') — yahi andhbhakti ka natija hai.
- Step 6: Verify against marking scheme — 1 mark for identifying metaphor, 1 for explaining consequence, 1 for linking to theme of self-deception

REASONING: This example combines metaphor analysis (from c12_hin_a_cbse_01_008) with inferential reasoning — showing how prerequisite nodes feed into comprehension. The 6 steps model the full analytical chain needed for 3-mark board questions.

ANSWER: 'nqcZy in cy' priyatam ki jhooti sundarta/maya ka prateek hai jo kavi apni aankhon par laga ke sachai se mukh mod leta hai. 'gkjh gksM+' is maya ka bhar hai jo kavi ki drishti jala deta hai ('djQ.kk gk&gk [kkrh') — ye kavi ke andhe samarpan ki keemat hai.

## COMPETENCY_QUESTION_1
QUESTION: "nsolsuk dk xhr" mein kavi ke "fonkbZ" hone ka karan kya hai? PEE format mein jawab dijiye. (Competency: Textual Evidence-Based Reasoning)

COMPETENCY
Textual Evidence-Based Reasoning

STEPS:
- Step 1: Locate "fonkbZ" in stanza 2: "vkg! osnuk feyh fonkbZ!"
- Step 2: Trace backward — what caused this cry? Stanza 1: "eSaus Hkzeo'k thou lafpr, eèkqdfj;ksa dh Hkh[k yqVkbZ" — total surrender
- Step 3: Trace forward — result? Stanza 2: "rwus [kks nh ldy dekbZA / p<+dj esjs thou&jFk ij / izy; py jgk vius iFk ij" — beloved's indifference
- Step 4: Synthesize: The cry "fonkbZ" (deceiver) erupts from the clash between poet's absolute devotion and beloved's careless trampling of that devotion
- Step 5: Write PEE: Point: Kavi 'fonkbZ' isliye kehta hai kyunki priyatam ne uske poore samarpan ka apman kiya. Evidence: "eSaus Hkzeo'k thou lafpr" (samarpan) vs "izy; py jgk vius iFk ij" (beparwahi). Explanation: Kavi ne apna jeevan daan kar diya (lafpr), lekin priyatam uske hriday par beparwah chalti rahi — yeh berukhi hi fonk hai.

ANSWER: Kavi 'fonkbZ' isliye kehta hai kyunki priyatam ne uske poore samarpan ka apman kiya. Evidence: "eSaus Hkzeo'k thou lafpr" (samarpan) vs "izy; py jgk vius iFk ij" (beparwahi). Explanation: Kavi ne apna jeevan daan kar diya (lafpr), lekin priyatam uske hriday par beparwah chalti rahi — yeh berukhi hi fonk hai.

DIFFICULTY
medium

## COMPETENCY_QUESTION_2
QUESTION: Compare how "fire" functions as a metaphor in both poems. In "nsolsuk dk xhr" it appears as "Hkh[k yqVkbZ" (burned the boat); in "dkusZfy;k dk xhr" as "cjlkrh vk¡[kksa osQ ckny" (mountains of shining embers). Explain the difference in what each fire *consumes* and what it *illuminates*. (Competency: Comparative Literary Analysis)

COMPETENCY
Comparative Literary Analysis

STEPS:
- Step 1: Identify both fire metaphors and their immediate contexts
- Step 2: Analyze nsolsuk's fire: "Hkh[k yqVkbZ" — subject "eSaus" (I), object "eèkqdfj;ksa dh Hkh[k" (boat of sinners). Fire consumes: the poet's own escape route to worldly life; illuminates: irreversible commitment to love
- Step 3: Analyze dkusZfy;k's fire: "cjlkrh vk¡[kksa osQ ckny" — subject implied revolutionary collective, object "ckny" (mountains/peaks). Fire consumes: old order, darkness; illuminates: "mM+rs [kx" (rising dawn of freedom), "ygjsa... fdukjk" (generous future)
- Step 4: Compare agency: nsolsuk fire = self-inflicted, personal, spiritual; dkusZfy;k fire = collective, historical, political
- Step 5: Compare outcome: nsolsuk fire leaves poet isolated ("viuh nzqreku nqcZyrkvksa... yksgk ysrh"); dkusZfy;k fire creates "lgkjk" (bridge) for "vutku" and "f{kfrt" (labor and capital)
- Step 6: Write structured comparison: "nsolsuk mein aag vyaktigat tyag hai jo kavi ko duniya se kaat deti hai; dkusZfy;k mein aag samuhik kranti hai jo naye Bharat ka raasta banati hai."

ANSWER: nsolsuk mein "Hkh[k yqVkbZ" ek vyaktigat, aatmik aag hai jo kavi ke duniya wapas jaane ke raaste (papis ki nauka) ko jala deti hai — ye uske prem ke atyantik samarpan ko dikhati hai. dkusZfy;k mein "cjlkrh vk¡[kksa osQ ckny" ek samuhik, rajnaitik aag hai jo purani vyavastha ko jala kar nayi subah ("mM+rs [kx") ka raasta saaf karti hai — ye rashtriya chetna ko dikhati hai. Pehli aag alagav paida karti hai, doosri jodti hai.

DIFFICULTY
hard