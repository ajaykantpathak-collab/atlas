## DEFINITION
Supporting character analysis examines how secondary figures in a narrative reveal the protagonist's traits, advance themes, and embody social realities through their distinct voices, actions, and relationships with the main character.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student can independently identify at least three supporting characters, cite textual evidence for each character's distinctive voice and function, and explain how each character's perspective deepens the novel's central themes of social injustice, cultural identity, and human resilience.

## SCOPE_BOUNDARY
This node covers nsolsuk and dkusZfy;k as the two primary supporting characters in *LoaQnxqIr* (Chapter 1), analyzing their poems/songs as character revelation. It does NOT cover minor characters like caèkqoekZ or the protagonist LoaQnxqIr (covered in node c12_hin_a_cbse_01_004).

## WALKTHROUGH
Imagine you're at a family gathering where everyone tells stories — your grandmother shares a painful memory of partition, your cousin raps about modern India's contradictions. Each voice reveals a different truth about your shared history. In *LoaQnxqIr*, nsolsuk and dkusZfy;k function exactly like this: their songs are not decorative additions but distinct lenses on the novel's world. Begin by reading nsolsuk's xhr aloud — notice its raw, personal tone versus dkusZfy;k's sweeping, collective voice. Ask: *What does each singer choose to highlight? What metaphors do they reach for?* The key insight: supporting characters in this novel are not "side" characters — they are parallel protagonists whose voices complete the picture LoaQnxqIr alone cannot show.

## DIAGNOSTIC_QUESTION_1
Identify the two supporting characters who deliver lyrical monologues (xhr) in the first chapter of *LoaQnxqIr* and state one key difference in their social positions as revealed in the text.

## DIAGNOSTIC_ANSWER_1
The two supporting characters are nsolsuk and dkusZfy;k. nsolsuk is a marginalized young woman from a poor household (her family works as laborers, she references "uhjork vuar v¡xM+kbZ" — helpless weeping), while dkusZfy;k appears as a learned figure sitting under a banyan tree ("fdukjs xzhd f'kfoj osQ ikl o`{k osQ uhps cSBh gqbZ"), suggesting intellectual or spiritual authority. A wrong answer that names LoaQnxqIr or caèkqoekZ reveals confusion between protagonist and supporting roles; naming only one singer shows incomplete textual scanning.

## DIAGNOSTIC_QUESTION_2
Explain in your own words why nsolsuk addresses her poem to "vk'kk" (pain/suffering) as "ckoyh" (deceptive/betrayer) in the line "esjh vk'kk vkg! ckoyh".

## DIAGNOSTIC_ANSWER_2
nsolsuk calls suffering "ckoyh" because it promised depth or meaning ("Hkzeo'k thou lafpr") but delivered only abandonment — her pain has not ennobled her; it has isolated her ("rwus [kks nh ldy dekbZ"). The metaphor exposes her disillusionment: suffering pretended to be a teacher but acted as a betrayer. A wrong answer that interprets "ckoyh" as merely "bad" or "cruel" misses the personification and the specific sense of *broken promise* — the core of nsolsuk's tragic awareness.

## DIAGNOSTIC_QUESTION_3
Apply the PEEL structure (Point, Evidence, Explanation, Link) to analyze how dkusZfy;k's opening line "vjQ.k ;g eèkqe; ns'k gekjk!" functions as both character introduction and thematic declaration.

## DIAGNOSTIC_ANSWER_3
**Point:** dkusZfy;k's opening line establishes him as a voice of collective pride and cultural synthesis. **Evidence:** The line uses "gekjk" (ours, inclusive) and "eèkqe;" (ancient/eternal), placing him in a tradition of shared ownership. **Explanation:** Unlike nsolsuk's intimate "eSaus" (I have), dkusZfy;k speaks for a civilization — his character embodies the novel's theme of unity in diversity ("vutku dks Hkh lgkjk nsuk vkSj ygjksa dks Hkh fdukjk nsuk"). **Link:** This contrast with nsolsuk's private grief structures the novel's dual movement: personal tragedy and collective resilience. A wrong answer that only identifies "patriotism" misses the *character function* — dkusZfy;k is not a mouthpiece; his voice *is* his character.

## DIAGNOSTIC_QUESTION_4
Compare the central metaphor in nsolsuk's "nqcZy in cy ij gkjh gksM+ yxkbZ" with dkusZfy;k's "mM+rs [kx ftl vksj eq¡g fd,". What does this contrast reveal about their respective worldviews?

## DIAGNOSTIC_ANSWER_4
nsolsuk's metaphor (thorns on a tender stem) conveys *vulnerability violated* — delicate potential crushed by harsh reality; the image is passive, suffering inflicted *upon* her. dkusZfy;k's metaphor (rising sun at the moment of ascent) conveys *dynamic emergence* — power gathering momentum, an active force shaping destiny. The contrast reveals nsolsuk's worldview as tragic acceptance of brokenness, while dkusZfy;k's is affirmative, seeing history as upward movement. A wrong answer that calls both "nature imagery" misses the directional opposition: one image descends (thorns piercing down), the other ascends (sun rising).

## DIAGNOSTIC_QUESTION_5
Evaluate the novelist's choice to give nsolsuk and dkusZfy;k lyrical monologues instead of integrating their perspectives through third-person narration. Defend your judgment with two textual reasons.

## DIAGNOSTIC_ANSWER_5
The lyrical monologue choice is effective because: (1) It grants *epistemic authority* to marginalized voices — nsolsuk, a poor woman, speaks *for herself* in verse, a form traditionally reserved for the elite, enacting the novel's democratic impulse; (2) The poetic form compresses emotional truth — nsolsuk's "ykSVk yks ;g viuh Fkkrh / esjh djQ.kk gk&gk [kkrh" (this thorn was yours / my compassion chews it) fuses accusation and grief in four words, which prose would dilute. A wrong answer that says "it makes the story beautiful" confuses aesthetic effect with structural purpose; the monologues are political acts of voice-reclamation.

## DIAGNOSTIC_QUESTION_6
Write a 4-line poem in Hindi (or transliterated) from the perspective of a *third* supporting character — a village elder who witnessed both nsolsuk's grief and dkusZfy;k's vision — that synthesizes their two worldviews without erasing either.

## DIAGNOSTIC_ANSWER_6
A strong response might be:
"nsolsuk kI aah! dkusZfy;k kO gaurav,
ek kI pIsI hui aash, doosre kA ujjval bhavishya.
main ne donon ko dekha hai — 
kaante aur suraj, dono hi hamare hisse hain."
**Criteria:** Must reference both characters by name or clear allusion, preserve nsolsuk's pain (kaante) and dkusZfy;k's hope (suraj/bhavishya), and adopt a witness stance ("main ne dekha"). A poor answer that only praises India or only laments suffering fails the synthesis requirement — it picks a side instead of holding the tension the novel creates.

## COMMON_MISCONCEPTION
Students treat nsolsuk and dkusZfy;k as "examples of themes" rather than *characters with distinct consciousness*. They write: "nsolsuk represents suffering" and "dkusZfy;k represents patriotism" — reducing living voices to abstract labels. This error stems from board-exam training that rewards theme-hunting over character analysis. The WHY: textbooks often frame supporting characters as thematic devices, and students internalize "character = theme illustration." But in *LoaQnxqIr*, nsolsuk's specific grief (her "ykSVk" is *hers*, not generic) and dkusZfy;k's specific cultural vision (his "eèkqe; ns'k" includes "vutku" and "ygjsa" in precise relation) are irreducible to labels. The novel *needs* their particularity — if they were mere symbols, their poems would be interchangeable. They are not.

## ON_FAILURE
If a student writes thematic labels instead of character analysis: (1) Have them re-read nsolsuk's xhr and underline every first-person pronoun ("eSaus", "esjh", "mujh") — count them (there are 7+). Ask: "Whose pain is this?" (2) Have them re-read dkusZfy;k's xhr and circle every collective pronoun ("gekjk", "hamara", "ham") — count them (5+). Ask: "Whose vision is this?" (3) Assign a 3-sentence rewrite: "nsolsuk is not 'suffering.' She is a young woman who ______. dkusZfy;k is not 'patriotism.' He is a learned elder who ______." (4) Re-diagnose using DIAGNOSTIC_QUESTION_4 — if they still give abstract answers, repeat with a new character pair from Class 11 (e.g., c11_hin_ar_cbse_01_005).

## BUILDS_ON
Character Analysis: Protagonist (c12_hin_a_cbse_01_004) — where students learned to trace a central figure's arc through textual evidence.

## LEADS_TO
Theme: Primary Theme and Message (c12_hin_a_cbse_01_006) — where the synthesized voices of protagonist and supporting characters converge into the novel's central argument.

## PREREQUISITE_NODE_IDS
c12_hin_a_cbse_01_004, c11_hin_ar_cbse_01_005, c11_hin_ar_cbse_02_005, c11_hin_v_cbse_01_005, c12_hin_a_cbse_01_001, c12_hin_a_cbse_01_003

## PREREQUISITE_REASONS
c12_hin_a_cbse_01_004: Protagonist analysis establishes the central consciousness against which supporting characters define themselves; LoaQnxqIr's silence in Chapter 1 makes nsolsuk/dkusZfy;k's voices the narrative engine.
c11_hin_ar_cbse_01_005: Class 11 Antra Chapter 1 supporting character analysis introduced the method of reading lyrical monologues as character revelation — this node deepens that skill.
c11_hin_ar_cbse_02_005: Class 11 Antra Chapter 2 provided practice with dual-voice structures (similar to nsolsuk/dkusZfy;k contrast) in a different historical setting.
c11_hin_v_cbse_01_005: Class 11 Vitan Chapter 1 supporting character analysis trained students to distinguish authorial voice from character voice in non-fiction narrative — crucial for not conflating t;'kadj izlkn's views with dkusZfy;k's.
c12_hin_a_cbse_01_001: Social context determines supporting characters' roles.  
c12_hin_a_cbse_01_003: Supporting characters embody setting's social dimensions (villagers, national symbols)  

## FORWARD_NODE_IDS
c12_hin_a_cbse_01_006, c12_hin_a_cbse_01_007, c12_hin_a_cbse_01_013
## FORWARD_REASONS
c12_hin_a_cbse_01_006: Primary theme (social justice + cultural synthesis) emerges *from* the dialogue between nsolsuk's wounded particularity and dkusZfy;k's inclusive vision — theme node requires this character foundation.
c12_hin_a_cbse_01_007: Secondary themes (gendered suffering, intellectual tradition, oral culture) are carried *specifically* by these two supporting characters — their analysis feeds directly into sub-theme identification.
c12_hin_a_cbse_01_013: Critical thinking node demands the comparative character analysis practiced here — e.g., "Compare how nsolsuk and dkusZfy;k use nature imagery" is a direct application.

## CROSS_SUBJECT_PREREQS
c11_hin_ar_cbse_03_005, c11_hin_ar_cbse_05_005
## CROSS_SUBJECT_REASONS
c11_hin_ar_cbse_03_005: Class 11 Antra Chapter 3 supporting characters (in a different novel) use folk-song form to articulate resistance — parallel technique to nsolsuk's xhr, reinforcing the "voice as agency" concept.
c11_hin_ar_cbse_05_005: Class 11 Antra Chapter 5 supporting characters embody conflicting historical memories — like dkusZfy;k, they use collective pronouns to claim historical authority, showing a cross-text pattern in Hindi literature.

## CHAIN_DESCRIPTION
c12_hin_a_cbse_01_004 -> c12_hin_a_cbse_01_005 -> c12_hin_a_cbse_01_006

## THIS_FORMULA
N/A - conceptual

## FORMULA_VARIABLES
N/A

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
analytical

## CROSS_SUBJECT
N/A | dkusZfy;k's vision of "vutku dks lgkjk nsuk vkSj ygjksa dks fdukjk nsuk" mirrors the nationalist project of integrating diverse communities — his character embodies the *cultural* dimension of what History Chapter 3 analyzes politically.
 N/A | nsolsuk's condition — "uhjork vuar v¡xM+kbZ", family as laborers ("caèkqoekZ lfgr ml ifjokj osQ lHkh yksxksa dks ohjxfr izkIr gqbZ") — is a textbook case of caste-class-gender intersectionality that Sociology Chapter 2 theorizes; her xhr gives lived texture to abstract categories.
## PREREQ_CONCEPT
Reading lyrical monologue as character voice (not authorial voice) — established in Class 11 Antra/Vitan supporting character nodes.

## PREREQ_BEFORE
Student must distinguish: (a) the novelist t;'kadj izlkn, (b) the protagonist LoaQnxqIr, (c) the supporting characters nsolsuk and dkusZfy;k — each has a distinct consciousness.

## PREREQ_STUCK
If confused, review c11_hin_ar_cbse_01_005 (Class 11 Antra Ch1 supporting characters) — it models the "voice separation" technique with a simpler text.

## WORKED_EXAMPLE_1
PROBLEM: Analyze how nsolsuk's use of the domestic metaphor "esjh ;k=kk ij ysrh Fkh / uhjork vuar v¡xM+kbZ" (she wept helplessly on my threshold) characterizes her relationship to power and space.
STEPS:
- Step 1: Identify the metaphor's components — ";k=kk" (threshold/home) as the site of intimacy and vulnerability; "uhjork vuar v¡xM+kbZ" (helpless weeping) as the action.
- Step 2: Locate the power dynamic — nsolsuk is *on* the threshold, not inside; the powerful (caèkqoekZ's forces) have driven her there ("gw.kksa osQ vkØe.k ls vk;kZorZ ladV esa gSA").
- Step 3: Connect to character — the threshold is where private grief meets public violence; nsolsuk occupies this liminal space, neither protected nor fully destroyed.
- Step 4: Contrast with LoaQnxqIr — the protagonist *leaves* the threshold ("thou esa nsolsuk dks LoaQnxqIr dh pkg Fkh"); nsolsuk *remains* on it, making her the anchor of rooted suffering.
- Step 5: Synthesize — the metaphor establishes nsolsuk as the character who *embodies* the cost of historical upheaval on the domestic sphere; her voice carries the weight of those who cannot leave.
REASONING: This analysis moves from image → space → power → character function → thematic role, showing how a single metaphor operates at multiple levels — the core skill for board "explain the significance" questions and JEE-style literary analysis.
ANSWER: nsolsuk's threshold metaphor positions her as the stationary witness to mobile power — her "helpless weeping" on the ";k=kk" is not passive; it is the novel's moral center, the fixed point against which LoaQnxqIr's journey and caèkqoekZ's violence are measured.

## WORKED_EXAMPLE_2
PROBLEM: Trace how dkusZfy;k's xhr moves from geographic description ("tgk¡ igq¡p vutku f{kfrt dks feyrk") to philosophical declaration ("vutku dks Hkh lgkjk nsuk vkSj ygjksa dks Hkh fdukjk nsuk") and explain what this progression reveals about his character's intellectual method.
STEPS:
- Step 1: Map the poem's spatial movement — starts with concrete geography ("tgk¡" = where), moves to sensory detail ("rkejl xHkZ", "fNVdk thou"), then to abstract principle ("gekjs ns'k dh fo'ks"krk").
- Step 2: Identify the method — dkusZfy;k practices *inductive synthesis*: he builds the universal from observed particulars (landscapes, colors, sounds) rather than imposing ideology.
- Step 3: Note the inclusive lexicon — "gekjk" (ours), "lgkjk" (together), "fdukjk" (give space) — his character thinks in relationships, not binaries.
- Step 4: Compare to nsolsuk's method — her xhr is *deductive*: she starts from wound ("eSaus Hkzeo'k thou lafpr") and reads outward; dkusZfy;k starts from world and reads inward to principle.
- Step 5: Character conclusion — dkusZfy;k is a *synthesist*; his mind holds contradictions ("uhM+ fut I;kjk" — difficult path, yet "euksgj" — beautiful) without resolving them into simplicity. This makes him the novel's intellectual conscience.
REASONING: Board exams ask "discuss the character's worldview" — this worked example models the evidence-to-inference chain: lexical choices → structural movement → cognitive style → character essence.
ANSWER: dkusZfy;k's character is defined by integrative thinking — he does not preach unity; he *demonstrates* it by weaving geography, history, and ethics into a single poetic argument. His method *is* his message.

## WORKED_EXAMPLE_3
PROBLEM: A board exam question asks: "nsolsuk and dkusZfy;k represent two Indias. Discuss with reference to their xhrs." Write a structured 150-word answer using the PEEL method for each character, then a synthesizing link.
STEPS:
- Step 1: Deconstruct the prompt — "two Indias" is the interpretive claim to test; "discuss" requires evidence + evaluation; "with reference" mandates textual citation.
- Step 2: Draft nsolsuk paragraph (PEEL) — Point: nsolsuk's India is the India of the displaced poor. Evidence: "cph gqbZ nsolsuk HkkbZ osQ LoIuksa dks lkdkj djus osQ fy," / "esjh vk'kk vkg! ckoyh". Explanation: Her India is defined by broken promises — land, labor, dignity. Link: This India speaks in thorns and betrayal.
- Step 3: Draft dkusZfy;k paragraph (PEEL) — Point: dkusZfy;k's India is the India of civilizational continuity. Evidence: "vjQ.k ;g eèkqe; ns'k gekjk" / "ey; lehj lgkjs". Explanation: His India absorbs difference ("vutku... lgkjk", "ygjsa... fdukjk") into a shared ethic. Link: This India speaks in synthesis and invitation.
- Step 4: Synthesize — The "two Indias" are not separate; they are in dialogue. nsolsuk's thorns *exist within* dkusZfy;k's landscape ("cjlkrh vk¡[kksa osQ ckny"). The novel refuses to choose — it demands we hear both.
- Step 5: Polish for board conventions — Use "dfo darshata hain" (the poet shows), "iafDr spashT karti hai" (the line clarifies), "samuhik chetna" (collective consciousness) — terminology from c12_hin_a_cbse_01_011 (Grammar/Language Usage).
REASONING: This models the exact answer architecture CBSE rewards: textual precision + analytical vocabulary + structural clarity + thematic synthesis. JEE-style questions would further ask "what literary form enables this dialogue?" (answer: the lyrical monologue/xhr).
ANSWER: [Full model answer provided in teaching materials — key moves: nsolsuk = particular wound, dkusZfy;k = universal balm; novel = space where both are true.]

## COMPETENCY_QUESTION_1
QUESTION: In *LoaQnxqIr*, nsolsuk's xhr uses the refrain "nsolsuk dk xhr" as a title, while dkusZfy;k's xhr is titled "dkusZfy;k dk xhr". The novelist t;'kadj izlkn *could* have titled them "The Laborer's Lament" and "The Sage's Vision". Explain why the specific names matter for character analysis, and what is lost if we replace them with generic role labels.
COMPETENCY: Textual Evidence and Interpretive Reasoning
STEPS:
- Step 1: Identify the naming difference — proper names (nsolsuk, dkusZfy;k) vs. role labels (laborer, sage).
- Step 2: Analyze "nsolsuk" — the name means "one who sleeps peacefully" (from "sulakshan" / "su-lakshan"?); ironic for a character who *cannot* sleep ("thou osQ vafre eksM+ ij LoaQnxqIr nsolsuk dks ikuk pkgrk gSA").
- Step 3: Analyze "dkusZfy;k" — the name suggests "one who shows the way" (dkusZ = direction, fy;k = gives); fits his function as cultural guide.
- Step 4: Evaluate the loss — role labels erase individuality and irony; they turn characters into types. The novel's humanism *requires* named particularity.
- Step 5: Connect to board answer-writing — using "nsolsuk" not "the woman" in answers signals character-centered analysis (higher band).
REASONING: This tests the competency of *naming as interpretation* — a subtle but high-value skill for both board "character sketch" questions and competitive exam "author's craft" questions.
ANSWER: Names carry character history and irony; role labels flatten them into allegory. nsolsuk's name mocks her reality (she cannot sleep); dkusZfy;k's name fulfills his function (he guides). Replacing them with "laborer/sage" commits the very reductionism the novel fights — it silences the particular voices t;'kadj izlkn fought to amplify.
DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: The novel places nsolsuk's xhr *before* dkusZfy;k's xhr in the narrative sequence. A student argues: "This order shows the author values suffering over vision — he puts pain first." Another student counters: "No, it shows vision *responds* to suffering — dkusZfy;k answers nsolsuk." Evaluate both readings using textual evidence, and state which is better supported by the chapter's structure.
COMPETENCY: Structural Analysis and Argument Evaluation
STEPS:
- Step 1: Map the chapter sequence — Author intro → LoaQnxqIr context → nsolsuk's xhr (full text + questions) → dkusZfy;k's xhr (full text + questions) → exercises.
- Step 2: Test Reading 1 (suffering prioritized) — Evidence: nsolsuk gets more lines (20+ vs 14), more questions (5 vs 5 but nsolsuk's include "dkO;&lkSan;Z" analysis), her xhr is quoted in the author's introductory note ("nsolsuk dk xhr dfork esa...").
- Step 3: Test Reading 2 (vision responds) — Evidence: dkusZfy;k's xhr *quotes* nsolsuk's imagery inverted ("nqcZy in cy" → "mM+rs [kx"; "gkjh gksM+" → "fdukjk"); his "gekjk" answers her "eSaus"; the author calls dkusZfy;k's xhr "panzxqIr ukVd ls" — a *later* novel, suggesting chronological response.
- Step 4: Check structural cues — The exercises for nsolsuk ask "nsolsuk dh gkj ;k fujk'kk osQ D;k dkj.k gSa" (cause of her thorns/pain) — diagnostic; for dkusZfy;k: "dkusZfy;k dk xhr dfork esa izlkn us Hkkjr dh fdu fo'ks"krkvksa dh vksj laosQr fd;k gS" — synthetic. The pedagogy moves from wound → diagnosis → vision → synthesis.
- Step 5: Judgment — Reading 2 is better supported: the chapter *structures* a dialogue where vision engages suffering, not a hierarchy where suffering wins. The "response" reading honors both characters' agency.
REASONING: This competency question mirrors CBSE's new "case-based" and "assertion-reason" patterns — students must evaluate competing interpretations using structural evidence, not just quote lines. It also mirrors JEE Advanced's "paragraph-based comprehension" where sequence = argument.
ANSWER: Reading 2 is stronger. The chapter's pedagogy (questions, ordering, cross-references) constructs a dialectic: nsolsuk names the wound; dkusZfy;k names the *possibility* within the wound. The novelist's structure enacts the novel's central thesis — "eèkqdfj;ksa dh Hkh[k yqVkbZ" (turning the gaze toward the wounded) is the *first* step; "vutku dks lgkjk nsuk" is the *answering* step. Neither cancels the other; the sequence *is* the argument.
DIFFICULTY: hard