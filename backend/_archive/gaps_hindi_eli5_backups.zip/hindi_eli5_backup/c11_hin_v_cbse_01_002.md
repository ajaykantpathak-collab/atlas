## DEFINITION
Plot and Narrative Structure refers to the organized sequence of events in a literary work and the techniques used to present them, including the arrangement of incidents (exposition, rising action, climax, falling action, resolution), narrative perspective, temporal manipulation, and the distinction between traditional theatrical structure (dialogue-driven, rule-bound) and cinematic structure (visual-driven, director-controlled, using sound and image as primary storytelling tools).

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student can independently map the narrative arc of the chapter onto Freytag's Pyramid, identify at least three structural differences between 'kkL=kh; laxhr and fp=kiV laxhr as described in the text, and explain how the author uses personal anecdote as a framing device to structure his argument about cinematic evolution.

## SCOPE_BOUNDARY
This node covers the structural analysis of the chapter "Hkkjrh; xkf;dkvksa esa cstksM+µyrk eaxs'kdj" — specifically the narrative framework, the contrast between classical and cinematic theatrical structures, and the author's use of autobiographical framing. It does NOT cover character analysis, themes, literary devices, or vocabulary — those are addressed in sibling nodes 004-011.

## WALKTHROUGH
Imagine you're watching a film and suddenly the screen goes black — you only hear sounds. That's exactly how this chapter begins: the author describes hearing a gramophone record before seeing anything visual. Start by asking: "What is the FIRST thing the author experiences — sound or sight?" This mirrors the chapter's core argument: cinematic theatre prioritizes the visual (fp=kiV) over the aural (Loj). Next, trace how the author structures his narrative: he opens with a personal memory (the gramophone), introduces the film "yrk eaxs'kdj" as a case study, then expands into a theoretical comparison of two theatre traditions. The key insight: the chapter itself mimics the cinematic structure it describes — it "shows" through concrete anecdote before it "tells" through analysis.

## DIAGNOSTIC_QUESTION_1
What are the three structural components (feuV) of a traditional play as referenced in the text, and which term does the author use for the middle component?

## DIAGNOSTIC_ANSWER_1
The three components are: प्रस्तावना (exposition), विकास (development/rising action), and उपसंहार (resolution). The author uses "विकास" for the middle component. A wrong answer (e.g., naming "climax" as a separate fourth part or using English terms like "rising action") reveals the student is imposing Western dramatic structure onto the Indian classical framework the text explicitly outlines, missing the text's indigenous terminology.

## DIAGNOSTIC_QUESTION_2
The author states: "fp=kiV laxhr dk rky izkFkfed voLFkk dk rky gksrk gS" (Cinematic theatre's director is the director of the fundamental state). Explain in your own words what "voLFkk" means in this context and why the director controls it rather than the playwright.

## DIAGNOSTIC_ANSWER_2
"voLFkk" here means the foundational visual-aural reality of the performance — the concrete images, sounds, and spatial arrangements that the audience directly perceives. In classical theatre, the playwright's script fixes the "state" through words; in cinematic theatre, the director constructs that state through camera, lighting, sound design, and editing. A wrong answer focusing only on "director vs playwright hierarchy" misses the ontological shift: the text argues cinematic theatre's very *substance* (voLFkk) is visual, not verbal, so control must shift to the visual architect.

## DIAGNOSTIC_QUESTION_3
Apply the concept of "xkuiu" (visual showing) to the chapter's opening anecdote. How does the gramophone incident function as a miniature "xkuiu" moment that foreshadows the chapter's central thesis?

## DIAGNOSTIC_ANSWER_3
The gramophone incident is a pure "xkuiu" moment: sound emerges without visible source (Loj without fp=k), creating mystery and anticipation — exactly what cinematic theatre does by separating sound from its origin and recombining them. The author hears "Loj" first, then later sees the film "yrk eaxs'kdj" — mirroring the historical shift from aural to visual primacy. A student who only summarizes the anecdote ("he heard a record") fails to see it as a structural microcosm of the macro-argument.

## DIAGNOSTIC_QUESTION_4
Compare the narrative function of "djQ.k jl" (delicate water/water-like subtlety) in the author's description of his own writing versus "xkuiu" in fp=kiV laxhr. How do these two concepts represent opposing structural principles?

## DIAGNOSTIC_ANSWER_4
"djQ.k jl" represents the author's literary method: subtle, inferential, flowing — where meaning emerges through suggestion and reader inference (like water finding its path). "xkuiu" represents cinematic method: direct, concrete, constructed — where meaning is built through visible/audible elements assembled by the director. The text positions them as complementary: literary narrative relies on the reader's imagination (djQ.k jl), cinematic narrative on the viewer's perception (xkuiu). A wrong answer treating them as synonyms ("both mean subtlety") misses the text's explicit contrast between linguistic suggestion and visual construction.

## DIAGNOSTIC_QUESTION_5
Evaluate the author's claim: "'kkL=kh; laxhr vkSj fp=kiV laxhr esa rqyuk gks gh ugha ldrh" (Classical and cinematic theatre cannot be compared). Is this a structural claim or an evaluative claim? Defend your answer using the text's own structural logic.

## DIAGNOSTIC_ANSWER_5
It is a structural claim grounded in incommensurable media: classical theatre's substance is "Loj" (speech) governed by fixed rules (fu;e), cinematic theatre's substance is "xkuiu" (visual showing) governed by directorial vision. The author argues they operate on different ontological planes — like comparing poetry to architecture. A student calling it "evaluative" (he prefers one) misses the text's rigorous formalism: the comparison fails because the *structural units* (Loj vs xkuiu) are non-convertible, not because one is better.

## DIAGNOSTIC_QUESTION_6
Create a three-panel storyboard (described in words) that captures the chapter's narrative structure: Panel 1 = the personal anecdote, Panel 2 = the case study (yrk eaxs'kdj), Panel 3 = the theoretical framework. For each panel, name the narrative technique used.

## DIAGNOSTIC_ANSWER_6
Panel 1: "Autobiographical Framing" — first-person memory of gramophone sound, establishing the aural-to-visual trajectory. Panel 2: "Concrete Exemplification" — the film "yrk eaxs'kdj" serves as a specific instance illustrating the general shift. Panel 3: "Analytical Abstraction" — the author moves from particular to universal, contrasting two theatre systems using indigenous terms (voLFkk, xkuiu, feuV). A poor answer lists events without naming the *structural role* each plays in the chapter's argument architecture.

## COMMON_MISCONCEPTION
Students confuse "plot" (what happens in the story) with "narrative structure" (how the story is arranged and told). In this chapter, the "plot" is simply: author hears gramophone → learns about film → analyzes theatre forms. But the *narrative structure* is a deliberate three-part argumentative arc: experiential hook → historical case study → theoretical synthesis. Students write plot summaries when asked for structural analysis because they've been trained in Class 10 to retell stories, not dissect their architecture.

## ON_FAILURE
Step 1: Have the student draw a horizontal line. Mark three points: "Gramophone Memory," "Film Case Study," "Theory of Two Theatres." Step 2: Ask: "What does each section DO for the reader?" (Hook → Illustrate → Generalize). Step 3: Give them a new short text (e.g., a film review) and ask them to map its structure using the same three labels. Step 4: Explicitly contrast: "Plot = beads. Structure = the string and the pattern." Repeat until they label function, not content.

## BUILDS_ON
c11_hin_v_cbse_01_001 (Before You Read: Context and Background) — provides the historical context of Indian cinema's emergence that makes the structural shift from classical to cinematic theatre intelligible.

## LEADS_TO
c11_hin_v_cbse_01_003 (Text: Setting and Atmosphere) — the structural distinction between verbal evocation (classical) and visual construction (cinematic) directly shapes how setting is created in each form.

## PREREQUISITE_NODE_IDS
c11_hin_v_cbse_01_001
## PREREQUISITE_REASONS
c11_hin_v_cbse_01_001: The context node establishes the historical transition from Parsi theatre to early cinema, which is the real-world backdrop for the structural shift the author analyzes; without it, the comparison of 'kkL=kh; and fp=kiV laxhr lacks historical grounding.

## FORWARD_NODE_IDS
c11_hin_v_cbse_01_003, c11_hin_v_cbse_01_004, c11_hin_v_cbse_01_006, c11_hin_v_cbse_01_005, c11_hin_v_cbse_01_007, c11_hin_v_cbse_01_008, c11_hin_v_cbse_01_010, c11_hin_v_cbse_01_011, c11_hin_v_cbse_01_012, c11_hin_v_cbse_01_013, c12_hin_a_cbse_01_002, c12_hin_a_cbse_03_002, c12_hin_a_cbse_04_002, c12_hin_a_cbse_06_002, c12_hin_a_cbse_07_002, c12_hin_a_cbse_09_002, c12_hin_a_cbse_10_002, c12_hin_al_cbse_03_002, c12_hin_v_cbse_01_002, c12_hin_v_cbse_02_002, c12_hin_ar_cbse_03_002

## FORWARD_REASONS
c11_hin_v_cbse_01_003: Understanding narrative structure (visual vs verbal) is prerequisite for analyzing how setting is *constructed* differently in cinematic vs classical theatre. c11_hin_v_cbse_01_004: The protagonist (author/narrator) is defined by his structural role as the bridge between two theatre traditions — his character emerges from the narrative architecture. c11_hin_v_cbse_01_006: The primary theme (evolution of artistic form) is enacted through the chapter's own narrative structure — form mirrors content.
c11_hin_v_cbse_01_005: Plot and narrative structure knowledge helps locate where supporting characters appear and function in the essay.  
c11_hin_v_cbse_01_007: Plot/narrative structure awareness helps locate where thematic reflections interrupt or frame the narrative.  
c11_hin_v_cbse_01_008: Establishes the narrative structure — the author's personal encounter with the painter — which is the experiential ground for all subsequent imagery.  
c11_hin_v_cbse_01_010: Teaches paragraph-level idea tracking, a prerequisite for locating and comparing a word's usage across the argument's structure.  
c11_hin_v_cbse_01_011: Plot and narrative structure analysis establishes where grammatical features appear in the chapter's argumentative arc, which is essential because sentence types and rhetorical questions are *structurally positioned* — they occur at specific points in the argument for specific rhetorical reasons.  
c11_hin_v_cbse_01_012: Plot knowledge allows locating events for literal questions.  
c11_hin_v_cbse_01_013: Understanding the narrative structure (anecdote -> theory -> generalization) is essential to analyze the argument's flow.  
c12_hin_a_cbse_01_002: Reinforces tracking emotional arcs in Vitan prose-poetry hybrids — complementary practice.  
c12_hin_a_cbse_03_002: Reinforces the same concepts in the Vitan textbook, ensuring exposure to multiple texts.  
c12_hin_a_cbse_04_002: Class 11 Vitan Chapter 1 covered narrative perspective in autobiographical narratives — essential for analyzing फ्नेक's child-narrator reliability.  
c12_hin_a_cbse_06_002: Covers Braj Bhasha poetic conventions (doha, chaupai) that structure Raskhan's verse.  
c12_hin_a_cbse_07_002: Class 11 Vitan exposure to narrative poetry analysis — reinforces the skill of tracking plot through poetic structure.  
c12_hin_a_cbse_09_002: Vitan chapter 1 narrative structure practice.  
c12_hin_a_cbse_10_002: Reinforced narrative analysis in Class 11 Vitan (different texts, same skills).  
c12_hin_al_cbse_03_002: Taught non-fictional narrative structures (memoir, travelogue) — this chapter is a memoir-essay hybrid.  
c12_hin_v_cbse_01_002: Establishes foundational knowledge of narrative structure types (linear, circular, flashback) and terminology (exposition, climax) which this node deepens with complex application.  
c12_hin_v_cbse_02_002: Introduces the concept of narrative arc and chronological vs. narrative order — the foundational skill for mapping this chapter's non-linear structure.  
c11_hin_v_cbse_01_004: Establishes the memoir's non-linear structure so students don't expect a conventional character arc.  
c11_hin_v_cbse_01_006: The plot events (artist's training, rejection, breakthrough) are the concrete evidence for the abstract theme.  
c12_hin_ar_cbse_03_002: If stuck, review the Class 11 poem "ckrsa" (c11_hin_v_cbse_01_002) — it has a clear narrative arc (word → words → language) and was analyzed for structure in the prior year. Re-do its structural map.  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
none

## CHAIN_DESCRIPTION
c11_hin_v_cbse_01_001 -> c11_hin_v_cbse_01_002 -> c11_hin_v_cbse_01_003

## THIS_FORMULA
N/A - conceptual

## FORMULA_VARIABLES
N/A

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
analytical

## CROSS_SUBJECT
c11_history_nationalism_in_india | The chapter's narrative of technological shift (gramophone → cinema) parallels the historical transition from colonial-era cultural forms to modern nationalist media; both use "before/after" structural framing.
c11_sociology_social_change | The structural contrast between rule-bound classical theatre (tradition) and director-driven cinematic theatre (modernity) exemplifies the sociological shift from ascribed to achieved authority in cultural production.

## PREREQ_CONCEPT
Understanding the difference between *story* (chronological events) and *discourse* (narrative arrangement) — the foundational narratological distinction.

## PREREQ_BEFORE
Student must be able to distinguish "what happens" from "how it is told" in any narrative text.

## PREREQ_STUCK
Review the story/discourse distinction using a familiar fairy tale: Cinderella's story = girl loses shoe, marries prince; discourse = starting at the ball, flashing back to the kitchen, etc.

## WORKED_EXAMPLE_1
PROBLEM: Map the chapter's narrative structure onto Freytag's Pyramid (Exposition, Rising Action, Climax, Falling Action, Resolution) and identify where the Indian classical terms (प्रस्तावना, विकास, उपसंहार) align or diverge.

STEPS:
- Step 1: Identify the Exposition — the author's gramophone memory (first paragraph). This establishes the "normal world" of aural experience and the inciting incident: hearing an unknown record.
- Step 2: Trace Rising Action — the investigation of the record's origin, discovery of the film "yrk eaxs'kdj," and the author's growing fascination. Each paragraph adds a layer: technical curiosity → historical context → artistic philosophy.
- Step 3: Locate the Climax — the theoretical declaration: "fp=kiV laxhr dk rky izkFkfed voLFkk dk rky gksrk gS" (para 4). This is the structural peak where personal experience crystallizes into formal argument.
- Step 4: Map Falling Action — the elaboration of differences: director vs playwright, xkuiu vs Loj, three feuV in both forms but differently realized. The argument unpacks the climax.
- Step 5: Identify Resolution — the final vision of cinema's future dominance (para 7): "fp=kiV laxhr lekt dh laxhr fo"k;d vfHk#fp esa izHkko'kkyh eksM+ yk;k gSA." The personal becomes historical.
- Step 6: Align Indian terms — प्रस्तावना = Exposition (gramophone hook), विकास = Rising Action + Climax (investigation to theory), उपसंहार = Falling Action + Resolution (elaboration to future vision). Note: Indian model compresses 5 Western stages into 3, reflecting the text's own structural economy.

REASONING: This mapping reveals the chapter's hybrid structure: it uses a classical three-act scaffolding (प्रस्तावना-विकास-उपसंहार) to deliver a modern cinematic argument (showing before telling). The Western 5-stage model exposes the internal complexity within each Indian stage.

ANSWER: The chapter follows a classical three-act structure mapped onto a modern theoretical argument. Exposition/प्रस्तावना = personal anecdote (gramophone). Rising Action+Climax/विकास = investigation leading to the director-centred thesis. Falling Action+Resolution/उपसंहार = systematic comparison concluding with cinema's societal dominance. The divergence: Western model separates climax from falling action; Indian model fuses them in "विकास" as the generative middle.

## WORKED_EXAMPLE_2
PROBLEM: The author uses "framing narrative" (the gramophone story) to introduce "embedded discourse" (theatre theory). Analyze how this structural choice serves the chapter's persuasive purpose for a 1950s Hindi reader unfamiliar with film theory.

STEPS:
- Step 1: Define the frame — the opening 2 paragraphs: first-person, sensory, domestic ("esjs dkuksa esa iM+k"), emotionally charged ("eSaus vuqHko fd;k", "eSa pfdr gks x;k").
- Step 2: Define the embedded discourse — paragraphs 3-7: third-person analytical, abstract terminology (voLFkk, xkuiu, feuV), historical sweep ("Hkkjrh; xkf;dkvksa esa").
- Step 3: Identify the bridge — paragraph 2 end: "yrk osQ igys izfl¼ xkf;dk uwjtgk¡ dk fp=kiV laxhr esa viuk ”kekuk Fkk." The personal memory connects to the historical figure.
- Step 4: Analyze rhetorical function — the frame makes the abstract concrete: the reader *experiences* the aural-to-visual shift before being *taught* it. This mirrors the cinematic principle "xkuiu" — show, don't just tell.
- Step 5: Evaluate audience adaptation — a 1950s reader knows gramophones, may not know film theory. The frame uses familiar experience (hearing a record) to scaffold unfamiliar concepts (cinematic structure).
- Step 6: Conclude structural logic — the chapter performs what it preaches: it uses cinematic narrative technique (visualizable anecdote → theoretical payoff) to argue for cinematic narrative supremacy.

REASONING: The frame-embedding structure is not decorative — it's the chapter's central structural metaphor. The author doesn't just *describe* the shift from aural to visual storytelling; he *enacts* it in his own narrative architecture.

ANSWER: The gramophone frame serves three structural functions: (1) Experiential hook — grounds abstract theory in bodily memory; (2) Metaphorical microcosm — the record's "sound without visible source" enacts the cinematic separation of Loj and fp=k; (3) Pedagogical scaffold — moves the reader from known (domestic listening) to unknown (film theory) via the bridge of a specific film (yrk eaxs'kdj). The structure *is* the argument.

## WORKED_EXAMPLE_3
PROBLEM: Compare the narrative structure of this chapter with a traditional 'kkL=kh; xk;d (classical play) as described in the text. How does the chapter's structure both embody and analyze the cinematic form?

STEPS:
- Step 1: Recall the text's description of classical play structure — "fu/kZfjr fu;eksa" (fixed rules), "lkjs Loj dksey yxrs gSa" (all speak in verse), "xaHkhj izÑfr dk yksdfiz; jkx" (heroic sentiment dominant). Structure is rigid, language-bound, sentiment-unified.
- Step 2: Recall the text's description of cinematic structure — "rky izkFkfed voLFkk dk rky" (director of fundamental state), "vkèks rkyksa dk mi;ksx" (uses multiple directors), "y;dkjh fcyoqQy vyx gksrh gSA" (scene-changes are frequent/fluid). Structure is flexible, visual-bound, multi-perspectival.
- Step 3: Analyze the chapter's own structure — It has no fixed rules (fu;e), mixes anecdote/theory/history (multiple "directors" of discourse), shifts sentiment (wonder → curiosity → analysis → prophecy), uses fluid transitions (paragraphs flow like film cuts).
- Step 4: Identify the meta-structural move — The chapter *performs* fp=kiV laxhr while *describing* it. Its "director" (author) controls the "voLFkk" (textual reality) through juxtaposition (gramophone vs film), montage (personal/historical/theoretical), and visualizable language ("Loj lhèks esjs dysts ls tk fHkM+k").
- Step 5: Contrast with classical alternative — A 'kkL=kh; treatment would have: invoked Bharata's Natyashastra as authority, used verse/prose alternation, maintained single rasa (likely adbhuta/wonder), avoided personal anecdote as "unclassical."
- Step 6: Synthesize — The chapter is a "fp=kiV" text about fp=kiV laxhr. Its structure validates its thesis: the very form of the writing proves the superiority of the cinematic mode for modern expression.

REASONING: This is the deepest structural insight: the text is self-referential. Its narrative architecture is not a container for the content — it *is* the content. The author doesn't just argue for cinematic structure; he writes *in* it.

ANSWER: The chapter structurally embodies fp=kiV laxhr: fluid transitions (like film cuts), directorial control over textual "voLFkk" (author selects/juxtaposes materials), multi-sensory appeal (sound → sight → intellect), and modern sentiment-mixing (nostalgia, analysis, prophecy). A classical play would cite authority, maintain rasa-purity, and use prescribed form. The chapter's structure *performs* the freedom it theorizes — making the analysis itself a cinematic act.

## COMPETENCY_QUESTION_1
QUESTION: The chapter opens with a gramophone record playing an unknown voice. By the end, the author claims cinema has become "lekt dh laxhr fo"k;d vfHk#fp" (society's theatre for special expression). Trace the *narrative logic* that connects these two moments. How does the structural journey from "unknown voice" to "social voice" mirror the historical trajectory the author describes?

COMPETENCY: Analyzing narrative structure as historical argument

STEPS:
- Step 1: Identify the opening structural unit — the gramophone as "mystery voice" (acousmatic sound: heard but source unseen). This represents pre-cinematic aural culture.
- Step 2: Identify the closing structural unit — cinema as "social voice" (collective expression, mass medium). This represents mature visual culture.
- Step 3: Map the intermediate structural bridges — (a) Identification of the voice (yrk eaxs'kdj) = naming/claiming; (b) Personal fascination = individual adoption; (c) Theoretical generalization = cultural legitimization; (d) Historical projection = future ownership.
- Step 4: Explain the mirroring — The narrative moves from private/anonymous (gramophone in a room) to public/authorized (cinema in society) exactly as the history moves from mechanical reproduction to artistic institution. The structure *enacts* the history.
- Step 5: Conclude — The chapter's narrative arc (mystery → knowledge → theory → prophecy) replicates the cultural arc of cinema in India (novelty → recognition → analysis → dominance).

ANSWER: The structural journey from "unknown voice" to "social voice" is the chapter's master narrative logic. The gramophone's disembodied sound (Loj without fp=k) poses the question cinema answers: how to give voice a visible, collective body. Each structural stage — identification, fascination, theorization, projection — corresponds to a historical phase of cinema's Indian trajectory. The narrative structure doesn't just describe this history; it replicates its logic: from acousmatic mystery to institutionalized visibility.

DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: The author states: "xkus dh lkjh feBkl] lkjh rkdr mldh jatdrk izkphu ok|;a=k" (The whole skill of acting, the whole beauty, its lifeblood is innate talent). Yet he also argues cinematic theatre requires "mÙke tkudkjh" (fundamental knowledge) of classical theatre. Using the chapter's narrative structure, resolve this apparent contradiction: how can cinematic theatre both *depend on* classical knowledge and *transcend* it?

COMPETENCY: Synthesizing structural evidence to resolve textual tension

STEPS:
- Step 1: Locate the two claims in the narrative structure — Claim A (innate talent) appears in the Resolution/उपसंहार (para 6), Claim B (classical knowledge needed) appears in the Development/विकास (para 4).
- Step 2: Analyze their structural positions — Claim B comes *during* the argument's building phase (director must know classical rules to break them); Claim A comes *after* the theory is established (ultimate success depends on something beyond rules).
- Step 3: Identify the mediating concept — "xkuiu" (visual showing). Classical knowledge provides the *material* (stories, sentiments, characters); cinematic structure provides the *form* (visual realization). Talent operates at the intersection.
- Step 4: Trace the narrative evidence — The author's own trajectory: he learns classical context (uwjtgk¡, fp=kiV history) → applies it to cinematic analysis → arrives at "innate talent" as the irreducible core. His narrative mirrors the director's path.
- Step 5: Resolve — Classical knowledge is the *scaffolding* (necessary during construction); innate talent is the *building* (what remains when scaffolding falls). The chapter's structure moves from scaffolding (theory/history) to building (the final vision of cinema's future).
- Step 6: Generalize — The narrative structure itself demonstrates: it uses classical terms (feuV, rasa) to build a cinematic argument, then transcends them in the final prophecy.

ANSWER: The contradiction resolves through the chapter's temporal structure. Classical knowledge (Claim B) occupies the "विकास" phase — the necessary apprenticeship where the director learns the grammar of Indian performance (rasa, feuV, stories). Innate talent (Claim A) occupies the "उपसंहार" phase — the mastery where rules become intuition. The narrative proves this: the author *uses* classical concepts to *reach* a vision beyond them. Cinematic theatre doesn't reject classical knowledge; it internalizes it as "xkuiu" material, then requires talent to shape that material into living visual form. The chapter's own arc — from learned analysis to prophetic vision — enacts this dialectic.

DIFFICULTY: hard