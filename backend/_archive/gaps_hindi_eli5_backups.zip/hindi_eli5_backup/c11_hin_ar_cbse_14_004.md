## DEFINITION
Character analysis of the protagonist involves examining the speaker's persona, traits, motivations, and development as revealed through the poetic voice, imagery, and themes in the poems.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student must be able to identify at least three distinct character traits of the speaker/protagonist, support each with specific evidence from both poems, and explain how these traits reflect the broader Adivasi resistance and identity.

## SCOPE_BOUNDARY
This node covers character analysis of the speaker/persona in the two poems by Vadda Gnosoh in Chapter 14. It does not cover analysis of supporting characters (node 005) or thematic analysis (nodes 006, 007).

## WALKTHROUGH
Imagine you are listening to an Adivasi elder narrate her life through poetry. You hear her describe a mysterious figure "Bafnaza" being crushed, and then she invites you into her house which is like a feast for darkness. To analyze the protagonist, first read both poems aloud to hear the rhythm and tone. Then, note the speaker's attitude toward oppression (first poem) and her defiant hospitality (second poem). Connect these to the historical context of the Jharkhand movement. The key insight is that the speaker embodies collective resistance through personal voice.

## DIAGNOSTIC_QUESTION_1
What is the primary voice or persona speaking in the two poems of Chapter 14?

## DIAGNOSTIC_ANSWER_1
The primary voice is that of the poet Vadda Gnosoh herself, speaking as an Adivasi woman and representative of her community. A wrong answer might identify "Bafnaza" or "Phako" as the protagonist, revealing confusion between a referenced character and the poetic speaker.

## DIAGNOSTIC_QUESTION_2
Explain in your own words how the speaker's attitude toward her house in the second poem reflects her broader worldview.

## DIAGNOSTIC_ANSWER_2
The speaker wants her house to remain fully open ("पूरी तरह खुला रहे") and not hide, even if it invites danger (darkness, pits). This shows her belief in transparency, fearlessness, and readiness to confront injustice. A wrong answer might focus only on literal architecture, missing the metaphorical defiance.

## DIAGNOSTIC_QUESTION_3
Apply the concept of "poetic persona" to identify two contrasting tones in the first poem (e.g., the description of Bafnaza) and the second poem (the invitation to the house). Provide one line from each poem as evidence.

## DIAGNOSTIC_ANSWER_3
First poem: tone of anguish/outrage at oppression ("बाफ़नज़ा पर लगाम का लगाना... यह मसखरी नहीं" - though the exact line is not quoted, the description says it's not mockery but heartfelt). Second poem: tone of defiant openness ("मेरे घर के द्वार जैसे भोज / अँधेरे को भी देख"). A wrong answer might confuse tone with mood or pick lines that don't contrast.

## DIAGNOSTIC_QUESTION_4
Analyze how the speaker's characterization across both poems constructs a collective Adivasi identity rather than just an individual one.

## DIAGNOSTIC_ANSWER_4
The speaker uses "मेरे घर" (my house) but links it to "पुएफयिड्कत्ज़ु" (Phako) and the community's struggle ("लईवकज लखोकन्ह वकन्क्षयु"). The first poem references "बाफ़नज़ा" as a symbol of the oppressed. The "I" represents the community. A wrong answer would treat the speaker as purely individual, ignoring the collective references.

## DIAGNOSTIC_QUESTION_5
Evaluate whether the speaker's defiance in the second poem ("यदि मैं उसे बुलाऊँ तो कोई आवाज आए") is an act of hope or desperation. Justify with textual evidence.

## DIAGNOSTIC_ANSWER_5
It is an act of hope grounded in collective solidarity: the belief that a call will be answered ("कोई आवाज आए") reflects faith in community response, not isolated desperation. A wrong answer might see it as naive optimism or pure desperation without recognizing the communal assurance.

## DIAGNOSTIC_QUESTION_6
Create a four-line poetic response from the perspective of the speaker's house, personified, reacting to the speaker's demand to stay open.

## DIAGNOSTIC_ANSWER_6
A strong response would personify the house echoing the speaker's resolve (e.g., "I stand unshut, my doors are arms / Embracing night, unafraid of harms / If pits are dug, I'll swallow them deep / My mistress calls, I wake from sleep"). A weak response would be generic or miss the defiant tone.

## COMMON_MISCONCEPTION
Students often think "character analysis" in poetry means describing a character mentioned in the poem (like Bafnaza or Phako) rather than analyzing the poetic speaker/persona. They confuse the subject of the poem with the voice of the poem. For example, they might write a paragraph about Bafnaza's suffering instead of the speaker's outrage at that suffering.

## ON_FAILURE
If a student makes this error, first ask: "Who is speaking these lines?" Have them highlight all first-person pronouns ("मैं", "मेरे", "हम") in both poems. Then ask: "What does the speaker reveal about herself through her reactions to Bafnaza and her house?" Guide them to list traits (courage, solidarity, defiance) with evidence. Finally, have them rewrite a paragraph focusing on the speaker.

## BUILDS_ON
c11_hin_ar_cbse_14_002 (Text: Plot and Narrative Structure) - understanding the narrative voice in the poems.

## LEADS_TO
c11_hin_ar_cbse_14_005 (Character Analysis: Supporting Characters) - analyzing other figures like Bafnaza and Phako.

## PREREQUISITE_NODE_IDS
c11_hin_ar_cbse_14_001, c11_hin_ar_cbse_14_002, c11_hin_ar_cbse_14_003
## PREREQUISITE_REASONS
c11_hin_ar_cbse_14_001: Provides historical context of Vadda Gnosoh and the Jharkhand movement essential for understanding the speaker's identity.
c11_hin_ar_cbse_14_002: Establishes the narrative structure of the two poems, helping identify the speaker's voice.
c11_hin_ar_cbse_14_003: Explains the setting/atmosphere (Adivasi life, oppression) that shapes the speaker's character.

## FORWARD_NODE_IDS
c11_hin_ar_cbse_14_005, c11_hin_ar_cbse_14_006, c11_hin_ar_cbse_14_013, c11_hin_ar_cbse_14_007, c11_hin_ar_cbse_14_008, c11_hin_ar_cbse_14_009, c11_hin_ar_cbse_14_012, c11_hin_ar_cbse_14_014, c12_hin_a_cbse_14_004, c12_hin_ar_cbse_14_004

## FORWARD_REASONS
c11_hin_ar_cbse_14_005: Supporting characters (Bafnaza, Phako) are understood in relation to the protagonist.
c11_hin_ar_cbse_14_006: The protagonist's traits directly embody the primary theme of resistance.
c11_hin_ar_cbse_14_013: Critical interpretation requires a solid grasp of the speaker's character.
c11_hin_ar_cbse_14_007: Protagonist analysis (Vadde as a tribal woman poet) grounds the gendered secondary theme in a specific voice.  
c11_hin_ar_cbse_14_008: Protagonist's character (endurance, agency) is *built* through the lamp metaphor — she *becomes* the lamp.  
c11_hin_ar_cbse_14_009: Protagonist analysis reveals the speaker's perspective, necessary for interpreting ironic statements.  
c11_hin_ar_cbse_14_012: Character analysis of vDdegknsoh provides the background knowledge needed to make valid inferences about her motives.  
c11_hin_ar_cbse_14_014: Protagonist analysis (vDdegknsoh as historical figure and poetic persona) informs the "Point" about agency.  
c12_hin_a_cbse_14_004: Established baseline character analysis vocabulary (traits, motivation, arc, direct/indirect characterization).  
c12_hin_ar_cbse_14_004: Class 11 character analysis foundation (trait identification, evidence use) is the direct skill prerequisite.  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
none

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_14_001 -> c11_hin_ar_cbse_14_004 -> c11_hin_ar_cbse_14_005

## THIS_FORMULA
N/A - conceptual

## FORMULA_VARIABLES
N/A

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
conceptual

## CROSS_SUBJECT
c11_history_jharkhand_movement | The speaker's voice reflects the Adivasi struggle for land and identity during the Jharkhand movement, linking literature to historical resistance.
c11_civics_indigenous_rights | The poems illustrate the assertion of cultural autonomy and collective rights, connecting to civics concepts of minority protections.

## PREREQ_CONCEPT
Understanding the distinction between a poetic speaker/persona and a character within the poem.

## PREREQ_BEFORE
Student must know how to identify first-person perspective and distinguish the narrator from other figures in the text.

## PREREQ_STUCK
Review "poetic persona" and "first-person narrative" from Class 10 poetry chapters (e.g., "Megh Aaye" or "Sandhya Ke Baad").

## WORKED_EXAMPLE_1
PROBLEM: Analyze the trait of "defiant resilience" in the speaker using evidence from both poems.
STEPS:
- Step 1: Identify the speaker's voice - note the use of "मैं" (I) and "मेरे" (my) in the second poem and the descriptive authority in the first poem.
- Step 2: Locate evidence of resilience in Poem 1: The speaker describes Bafnaza's oppression not as mockery ("मसखरी नहीं") but as a heartfelt reality, showing she witnesses and refuses to trivialize suffering.
- Step 3: Locate evidence in Poem 2: The speaker demands her house stay open ("पूरी तरह खुला रहे") even against darkness and pits, showing refusal to hide or compromise.
- Step 4: Synthesize: Both poems show the speaker confronting oppression directly - in Poem 1 by bearing witness, in Poem 2 by proactive defiance.
- Step 5: Connect to theme: This resilience embodies the Adivasi community's resistance to displacement and cultural erasure.
REASONING: The steps move from textual evidence to trait identification to thematic connection, modeling the PEEL structure required for board answers.
ANSWER: The speaker exhibits defiant resilience by refusing to minimize oppression (Poem 1) and by insisting on openness despite threats (Poem 2), representing collective Adivasi resistance.

## WORKED_EXAMPLE_2
PROBLEM: How does the speaker's relationship with "Phako" (पुएफयिड्कत्ज़ु) reveal her character?
STEPS:
- Step 1: Note the reference to Phako in the background text: Phako was a leader ("पुएफयिड्कत्ज़ु नो (फको) बुओसक वज्जे; फ्का") and the speaker's associate.
- Step 2: In Poem 2, the speaker says "लन्सक य्सदज पुएफयिड्कत्ज़ु दक" (taking Phako's name, or invoking Phako). This shows she draws strength from collective leadership.
- Step 3: The speaker does not act alone; she invokes a shared legacy ("लईवकज लखोकन्ह वकन्क्षयु" - for the peaceful Jharkhand movement).
- Step 4: Infer trait: The speaker is rooted in community history, not isolated; she sees herself as continuing a legacy.
- Step 5: Contrast with individualistic reading: This avoids the misconception of the speaker as a lone hero.
REASONING: This example teaches students to use background context (node 001) to deepen character analysis, a key Class 11 skill.
ANSWER: The speaker's invocation of Phako shows she is historically grounded, collectively oriented, and draws authority from the movement's lineage.

## WORKED_EXAMPLE_3
PROBLEM: Compare the speaker's portrayal of "Bafnaza" (Poem 1) and her own house (Poem 2) as symbols. What does this comparison reveal about her character?
STEPS:
- Step 1: Identify Bafnaza as a symbol of the oppressed individual/community being crushed ("बाफ़नज़ा पर लगाम का लगाना").
- Step 2: Identify the house as a symbol of the speaker's identity, space, and agency ("मेरे घर के द्वार जैसे भोज").
- Step 3: Note the contrast: Bafnaza is acted upon (passive victim), while the house is actively maintained open by the speaker (active agent).
- Step 4: Analyze the speaker's role: She is the witness for Bafnaza and the protector of the house. This dual role shows empathy and agency.
- Step 5: Synthesize: The speaker bridges collective suffering (Bafnaza) and collective resistance (open house), embodying the transition from victimhood to assertion.
- Step 6: Link to exam answer: This comparison allows a nuanced character sketch showing complexity.
REASONING: This multi-step analysis combines symbol interpretation with character inference, mirroring higher-order board questions.
ANSWER: The speaker emerges as both a compassionate chronicler of oppression (through Bafnaza) and an active architect of resistance (through the open house), revealing a character that transforms witness into action.

## COMPETENCY_QUESTION_1
QUESTION: The speaker in Vadda Gnosoh's poems says, "मेरे घर के द्वार जैसे भोज / अँधेरे को भी देख". Explain how this metaphor reveals two specific character traits of the protagonist. Support each trait with a separate piece of evidence from either poem.
COMPETENCY: Literary analysis with textual evidence
STEPS:
- Step 1: Decode the metaphor: the house's doors are like a feast for darkness, meaning they welcome even danger openly.
- Step 2: Identify trait 1: Fearlessness - evidence: "पूरी तरह खुला रहे और न फेले देखो" (let it stay fully open and not hide).
- Step 3: Identify trait 2: Defiant hospitality/solidarity - evidence from Poem 1: the speaker's refusal to treat Bafnaza's suffering as "मसखरी" (mockery) shows she takes oppression seriously and stands with victims.
- Step 4: Write a structured answer using PEEL for each trait.
ANSWER: The metaphor reveals fearlessness (she keeps doors open despite darkness) and defiant solidarity (she witnesses Bafnaza's pain without trivializing it). Both traits show a protagonist who confronts rather than avoids injustice.
DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: "The protagonist in these poems is not an individual but a collective voice." Evaluate this statement by analyzing the use of first-person singular ("मैं") and plural/collective references across both poems. Provide a balanced judgment with three textual reasons.
COMPETENCY: Critical evaluation and synthesis
STEPS:
- Step 1: List first-person singular instances: "मेरे घर", "मैं उसे बुलाऊँ", "मुझे दो" (Poem 2).
- Step 2: List collective references: "पुएफयिड्कत्ज़ु" (Phako, a leader), "लईवकज लखोकन्ह वकन्क्षयु" (for peaceful Jharkhand movement), "बाफ़नज़ा" as representative figure.
- Step 3: Argue how "मैं" functions as a representative "I" - the speaker speaks for the community.
- Step 4: Argue the counterpoint: the personal tone ("मेरे घर") creates intimacy, making the collective concrete.
- Step 5: Conclude: The statement is largely true; the singular voice is a synecdoche for the collective.
ANSWER: The statement is valid because the singular "I" consistently invokes collective history (Phako, movement), represents a shared plight (Bafnaza), and transforms personal space (house) into a communal symbol. The individual voice serves as a vessel for collective identity.
DIFFICULTY: hard