## DEFINITION
Character analysis of the protagonist involves systematically examining the central figure's personality traits, motivations, conflicts, development arc, and relationship to the text's themes through textual evidence — actions, dialogues, authorial descriptions, and narrative perspective — to construct an evidence-based interpretation of their role in the literary work.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student can independently identify 4-5 distinct personality traits of Raskhan from the biographical sketch and poems, support each trait with specific textual evidence (line references or paraphrased incidents), explain how these traits reveal his spiritual transformation, and write a structured 150-word character sketch following the Point-Evidence-Explanation-Link format.

## SCOPE_BOUNDARY
This node covers Raskhan (रसखान) as the protagonist of the chapter — his life journey, poetic voice, and spiritual evolution as presented in the biographical introduction and the two poetic extracts (हजारी-जिके का इज़ and the two पद). It does NOT cover supporting characters like Hajari (हजारी) or Jike (जिके) in depth, nor does it cover thematic analysis of Bhakti poetry beyond Raskhan's personal expression.

## WALKTHROUGH
Imagine you meet someone who completely changed their life path at age 30 — left their career, religion, and community to follow a spiritual calling. You'd want to understand *why* and *how* that transformation happened. Raskhan's story is exactly that: a Muslim poet in Mughal India who became a Krishna devotee. Begin by reading the biographical sketch (पृष्ठ 33-34) not as facts to memorize, but as clues to his character — notice words like "हृदय से विरक्त" (detached at heart), "प्रेम-विह्वल" (overwhelmed by love), "एकनिष्ठ" (single-minded). Then read the poems aloud: the first पद (हजारी-जिके का इज़) reveals his *external* devotion through Radha's voice; the second पद (तूथ फुज्खर...) reveals his *internal* state. Ask: "What does each word choice tell us about the person speaking?" The key insight: Raskhan's protagonist is not a static figure — he is a *journey* from worldly detachment to divine attachment, and the text gives us both the biographer's lens and the poet's own voice to trace that arc.

## DIAGNOSTIC_QUESTION_1
What is the primary difference between analyzing a protagonist in a fictional narrative versus analyzing a historical-poetic figure like Raskhan where the "character" is both the author and the subject of the biographical sketch?

## DIAGNOSTIC_ANSWER_1
In fictional narratives, the protagonist is a constructed character whose traits we infer only from the text's internal evidence (dialogue, action, narration). For Raskhan, we have a dual lens: the biographer's *external* account (facts, dates, reputation) AND the poet's *internal* voice (the poems expressing his bhakti). A wrong answer treats them as identical — e.g., "Both use dialogues and actions" — revealing the student misses that Raskhan's poems are *first-person spiritual testimony*, not fictional dialogue, and the biographical sketch is *non-fictional framing* that requires evaluating reliability (e.g., "कहा जाता है" / "it is said" signals hearsay).

## DIAGNOSTIC_QUESTION_2
The biographical sketch states: "रसखान का हृदय एकनिष्ठ प्रेम से भरा था" (Raskhan's heart was filled with single-minded love). A student writes: "This proves Raskhan was loving." Why is this an insufficient character analysis statement for Class 12 board standards?

## DIAGNOSTIC_ANSWER_2
The statement merely *repeats* the text's adjective ("एकनिष्ठ प्रेम") without *analyzing* how the text *demonstrates* that trait. Board-standard analysis requires: (1) identifying the specific *behavioral evidence* (e.g., leaving royal court, learning Braj Bhasha, composing in vernacular), (2) explaining the *psychological implication* (renunciation of status for spiritual pursuit), and (3) connecting to *textual technique* (the biographer uses "हृदय" as metaphor for inner transformation). A wrong answer reveals the student confuses *labeling* with *analyzing* — they extract adjectives but don't trace the evidence-to-inference chain.

## DIAGNOSTIC_QUESTION_3
In the first पद (हजारी-जिके का इज़), Radha says: "हजारी लखसुख लक्जी डज डगर डज" (Hajari, lakhs of joys...). A student claims this line shows Radha's "materialism" because she counts "lakhs of joys." Apply the concept of *dramatic persona* and *bhakti convention* to evaluate this interpretation.

## DIAGNOSTIC_ANSWER_3
The interpretation fails because it ignores two conventions: (1) *Dramatic persona* — Radha is a *character* Raskhan creates, not Raskhan himself; her "counting joys" is a poetic device (hyperbolic enumeration) to express *inexpressible* divine love, not literal materialism. (2) *Bhakti convention* — "लक्ष" (lakh) in Braj poetry conventionally signifies *infinity/abundance* of spiritual bliss (आनंद), not currency. Correct application: The line uses *hyperbolic quantification* to convey that divine love surpasses all measurable joy. A wrong answer reveals the student reads bhakti poetry literally, missing the *symbolic register* where numbers = boundlessness.

## DIAGNOSTIC_QUESTION_4
Compare Raskhan's portrayal of Krishna in the second पद ("गजसग्ंव [कस्य फ्ट्रकोघ एक्सघ") with the biographical sketch's description of his conversion ("जयदेव की भक्ति से प्रभावित होकर..."). What does the *shift* from third-person biography to first-person poetic address reveal about Raskhan's evolving self-conception?

## DIAGNOSTIC_ANSWER_4
The biography uses *external markers* (influence of Jayadeva, learning from Goswamis, settling in Vrindavan) — Raskhan as *disciple* receiving tradition. The poem uses *intimate address* ("मेरे प्राणनाथ", "मेरे मन मंदिर") — Raskhan as *direct participant* in divine play. The shift reveals his self-conception moved from *outsider adopting a path* to *insider inhabiting the bhakti universe*. Analytically: the biography shows *social conversion* (community, language, location); the poem shows *ontological conversion* (identity restructured around Krishna). A wrong answer lists similarities ("both show devotion") missing the *epistemological shift* from observed subject to speaking subject.

## DIAGNOSTIC_QUESTION_5
A board exam question asks: "रसखान के व्यक्तित्व में 'वैराग्य' और 'अनुराग' का द्वंद्व कैसे व्यक्त होता है?" (How is the conflict between detachment and attachment expressed in Raskhan's personality?). A student answers only with biographical facts: "He left his home and went to Vrindavan." Evaluate this answer against the marking scheme's requirement for "literary appreciation with textual evidence."

## DIAGNOSTIC_ANSWER_5
The answer scores 1/3 marks. It provides *plot-level fact* (physical departure) but zero *literary analysis*. The marking scheme requires: (1) *Textual evidence from poems* — e.g., second पद's "उहत उधूग दुज्ख दज य्वयक" (restless, suffering, burning) shows *internal* वैराग्य (detachment from world), while "आनि गस्ज गक्जसम ल्क व्क्सिज्क" (bringing joy to my mind-temple) shows *internal* अनुराग (attachment to Krishna). (2) *Device identification* — the poems use *antithesis* (विरोधाभास) and *intensifiers* (उहत, दुज्ख) to dramatize the conflict. (3) *Synthesis* — the conflict resolves not by rejecting world but by *transmuting* worldly love into divine love (the biographical "हजारी-जिके" becoming poetic "हजारी-जिके"). A wrong answer reveals the student treats biography as "content" and poetry as "decoration" instead of seeing them as *two registers of the same psychological journey*.

## DIAGNOSTIC_QUESTION_6
Write a 4-line "character capsule" for Raskhan that a Class 12 student could use as a memory anchor — each line must capture a distinct dimension (historical, linguistic, spiritual, literary) using only keywords/phrases from the chapter.

## DIAGNOSTIC_ANSWER_6
Expected answer (sample):
1. जट्ट मुसलमान → ब्रजभाषा कवि (Historical: identity crossing)
2. फारसी छोड़ → ब्रज अपनाया (Linguistic: deliberate vernacular choice)
3. जयदेव-प्रेरित → वृन्दावन-वासी (Spiritual: guru-parampara to direct residence)
4. हजारी-जिके → प्राणनाथ संबोधन (Literary: dramatic persona to intimate address)

Criteria: Each line must pair a *before* and *after* keyword from the text showing transformation. A poor answer lists static traits ("poet, devotee, Muslim, Hindi writer") revealing the student sees character as *noun list* not *verb trajectory*.

## COMMON_MISCONCEPTION
Students treat Raskhan's "conversion" as a single event (Muslim → Hindu) and write: "He changed his religion." This is historically inaccurate (he remained culturally Muslim, adopted Krishna *bhakti* not institutional Hinduism) and analytically shallow — it reduces a *gradual, layered spiritual reorientation* documented across the biographical sketch (learning Braj, studying Jayadeva, meeting Goswamis, settling in Vrindavan) and the poems (progressing from Radha's voice to direct address) into a binary switch. The error stems from reading *biography as plot summary* rather than *character as process*. Board examiners penalize this because the chapter's central theme is *syncretic devotion* (समन्वय), not conversion.

## ON_FAILURE
Step 1: Have the student re-read the biographical sketch (पृष्ठ 33-34) and underline every *process verb* — "सीखा" (learnt), "रहा" (stayed), "बनाया" (made), "प्रकट किया" (revealed) — circling the *time markers* ("बाद में", "फिर", "अंत में"). Step 2: In the poems, highlight *first-person markers* ("मेरे", "मैं", "मुझको") and *address terms* ("प्राणनाथ", "मन मंदिर") in two colors. Step 3: Create a two-column timeline: Left column = biographical actions (external), Right column = poetic expressions (internal) — match them chronologically. Step 4: Rewrite the "conversion" sentence as: "Raskhan's *gradual alignment* of outer life (language, location, community) with inner devotion (evident in shifting poetic voice) exemplifies bhakti as *lived synthesis*." Re-diagnostic: Ask student to explain one matched pair from their timeline in 3 sentences.

## BUILDS_ON
Class 11 character analysis (c11_hin_ar_cbse_01_004) where students learned to extract traits from fictional narratives using PEEL structure; this node extends that to a historical-poetic figure with dual textual registers (biography + poetry).

## LEADS_TO
c12_hin_a_cbse_06_005 (Supporting Characters) where Hajari/Jike's roles as dramatic foils to Raskhan's spiritual journey are analyzed, and c12_hin_a_cbse_06_006 (Primary Theme) where Raskhan's character arc becomes the vehicle for the theme of "prem-marg" (path of love).

## PREREQUISITE_NODE_IDS
c12_hin_a_cbse_06_001, c12_hin_a_cbse_06_002, c12_hin_a_cbse_06_003, c11_hin_ar_cbse_01_004, c11_hin_v_cbse_01_004
## PREREQUISITE_REASONS
c12_hin_a_cbse_06_001: Provides historical-cultural context (Mughal India, Bhakti movement, Braj Bhasha) essential to interpret Raskhan's choices as counter-cultural.
c12_hin_a_cbse_06_002: Establishes the chapter's narrative structure (biography → poem 1 → poem 2) which mirrors Raskhan's inner trajectory — needed to map character development onto textual sequence.
c12_hin_a_cbse_06_003: Explains the setting (Vrindavan, Goswami circles) as *active shaping force* on Raskhan's character, not mere backdrop.
c11_hin_ar_cbse_01_004: Transfers the PEEL (Point-Evidence-Explanation-Link) character analysis framework from fictional to historical-poetic texts.
c11_hin_v_cbse_01_004: Reinforces protagonist analysis in non-fiction prose (Vitan textbook), bridging to this chapter's biographical mode.

## FORWARD_NODE_IDS
c12_hin_a_cbse_06_005, c12_hin_a_cbse_06_006, c12_hin_a_cbse_06_013, c12_hin_a_cbse_06_012

## FORWARD_REASONS
c12_hin_a_cbse_06_005: Raskhan's protagonist analysis establishes the central consciousness against which supporting characters (Hajari, Jike, Goswamis) function as mirrors/foils.
c12_hin_a_cbse_06_006: The primary theme "prem as spiritual path" is *embodied* in Raskhan's character arc — theme analysis requires protagonist analysis as foundation.
c12_hin_a_cbse_06_013: Critical thinking questions (e.g., "Is Raskhan's bhakti syncretic or subversive?") demand a fully developed character interpretation as prerequisite.
c12_hin_a_cbse_06_012: Protagonist analysis provides character-specific evidence for inference.  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
c12_history_medieval_bhakti: Provides the historical framework of Nirguna/Saguna Bhakti, Sufi-Bhakti dialogue, and vernacularization that makes Raskhan's trajectory a *case study* not an anomaly.
c12_sociology_religious_syncretism: Supplies conceptual tools (syncretism, boundary-crossing, lived religion) to analyze Raskhan's character as *social performance* of spiritual integration.

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_01_004 -> c12_hin_a_cbse_06_004 -> c12_hin_a_cbse_06_006

## THIS_FORMULA
Character Sketch = Σ [Trait_i × (Biographical Evidence_i + Poetic Evidence_i) × Thematic Link_i] for i = 1 to n traits

## FORMULA_VARIABLES
Trait_i: Distinct personality dimension (e.g., एकनिष्ठता, वैराग्य-अनुराग संश्लेषण, भाषाई साहस)
Biographical Evidence_i: Specific fact/action from life-sketch (e.g., "फारसी छोड़ ब्रज सीखा")
Poetic Evidence_i: Specific line/device from poems (e.g., "प्राणनाथ संबोधन में आत्मसमर्पण")
Thematic Link_i: Connection to chapter's central theme (e.g., "प्रेम-मार्ग की सामाजिक-आध्यात्मिक अभिव्यक्ति")

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
analytical

## CROSS_SUBJECT
N/A | Raskhan's life exemplifies the 16th-17th century trend of Muslim poets adopting Krishna bhakti (Raskhan, Rahim, Taj) — his character analysis becomes a micro-history of religious fluidity in Mughal Braj.
 N/A | The protagonist's dual register (biography in Khari Boli, poetry in Braj) illustrates "code-switching as identity negotiation" — a sociological lens on linguistic choice as spiritual practice.
 N/A | Raskhan's trajectory maps onto Marcia's identity statuses: moratorium (searching) → achievement (committed bhakti) — the poems serve as "identity narratives" constructing a coherent self.
## PREREQ_CONCEPT
PEEL paragraph structure (Point-Evidence-Explanation-Link) applied to character analysis, transferred from Class 11 fictional texts to Class 12 historical-poetic composite text.

## PREREQ_BEFORE
Student must be able to: (1) distinguish narrator's voice from character's voice, (2) cite textual evidence with line/stanza references, (3) explain how a literary device (metaphor, address term, verb tense) constructs character.

## PREREQ_STUCK
If stuck on "how to analyze a real person as character," revisit c11_hin_v_cbse_01_004 (Vitan Chapter 1 protagonist analysis) — it teaches analyzing *real-life figures* (e.g., Bhagat Singh, Amrita Pritam) through textual representation, not biography.

## WORKED_EXAMPLE_1
PROBLEM: Analyze the trait "भाषाई साहस" (linguistic courage) in Raskhan using the PEEL structure. The chapter states he was born in a Persianate environment but chose Braj Bhasha for his Krishna poetry.

STEPS:
- Step 1 — Identify the trait: "भाषाई साहस" — deliberate choice of marginalized vernacular over prestige language (Persian) for spiritual expression.
- Step 2 — Locate biographical evidence: पृष्ठ 34, "रसखान को ... ब्रजभाषा पर अधिकार प्राप्त करने के लिए कठोर परिश्रम करना पड़ा" — shows *effort*, not innate ability; "हिंदी और ब्रज दोनों पर समान अधिकार" — marks *bilingual mastery* as conscious achievement.
- Step 3 — Locate poetic evidence: First पद uses Braj conventions (राधा-कृष्ण संवाद, गोपी-भाषा); second पद uses intimate Braj address ("मेरे प्राणनाथ", "मन मंदिर") — the *language itself* enacts devotion.
- Step 4 — Explain the link: Choosing Braj was not merely linguistic — it was *social relocation*. Persian = courtly power, Mughal identity; Braj = bhakti community, Krishna's vernacular. Raskhan's mastery of both allowed him to *translate* spiritual experience across worlds.
- Step 5 — Connect to theme: This trait embodies the chapter's central message — "प्रेम भाषा नहीं जानता, भाषा प्रेम बन जाती है" (Love knows no language; language becomes love). The protagonist's courage makes the theme *lived*.

REASONING: The PEEL structure forces movement from label (Point) to textual proof (Evidence) to interpretive reasoning (Explanation) to thematic significance (Link). For historical-poetic figures, Evidence *must* come from both registers (biography + poetry) or the analysis remains one-dimensional.

ANSWER:
Point: रसखान का 'भाषाई साहस' उनकी आध्यात्मिक प्रतिबद्धता का बाह्य प्रकटीकरण है।
Evidence: जीवनी में — "फारसी छोड़ ब्रज सीखा, कठोर परिश्रम से अधिकार पाया"; कविता में — ब्रज की गोपी-भाषा में राधा का संवाद (पद 1) और सीधे कृष्ण को "प्राणनाथ" संबोधन (पद 2)।
Explanation: फारसी मुगल दरबार की शक्ति-भाषा थी; ब्रज कृष्ण की लीला-भाषा। दोनों में निपुणता रसखान को 'द्विभाषी सेतु' बनाती है — वे भक्ति को दरबारी संस्कृति में अनूदित नहीं करते, बल्कि दरबारी संस्कृति को भक्ति की भाषा में ढालते हैं।
Link: यह साहस ही 'प्रेम-मार्ग' की सामाजिक क्रांतिकारिता है — भाषा-परिवर्तन पहचान-परिवर्तन है।

## WORKED_EXAMPLE_2
PROBLEM: The second पद contains the line: "उहत उधूग दुज्ख दज य्वयक" (restless, suffering, burning, pained). A student writes: "This shows Raskhan was sad." Diagnose the error and model a correct analytical response.

STEPS:
- Step 1 — Identify the error: The student conflates *emotional state* (sadness) with *spiritual condition* (virah-tapasa / separation-austerity). "उहत/दुज्ख" in bhakti poetics are not depression — they are *transformative fire* (तपस्या).
- Step 2 — Contextualize within the poem: The line precedes "आनि गस्ज गक्जसम ल्क व्क्सिज्क" (bringing joy to my mind-temple) — the suffering *precedes and produces* the joy. It is teleological: virah → milan.
- Step 3 — Connect to biography: The sketch describes his early life as "हृदय से विरक्त" (detached at heart) — worldly detachment *prepares* for divine attachment. The poem's "दुज्ख" is the *same psychological energy* redirected.
- Step 4 — Identify the device: *Antithesis* (विरोधाभास) — "दुज्ख" vs "गस्ज" (joy), "उहत" (restless) vs "मन मंदिर" (stable inner sanctuary). The structure enacts the transformation.
- Step 5 — Synthesize: The line does not depict "sadness" — it depicts *spiritual labor* (साधना). Raskhan's character is defined by *willingness to endure virah for milan*.

REASONING: Bhakti poetry operates on a *different emotional semantics* than modern psychology. "दुज्ख" here is a *technical term* (virah-dukh) meaning "the productive pain of separation that purifies love." Analyzing it as "sadness" imposes a contemporary clinical category on a premodern devotional framework.

ANSWER:
Correct analysis: "पद 2 की पंक्ति 'उहत उधूग दुज्ख दज य्वयक' रसखान की 'विरह-तपस्या' को व्यक्त करती है — यह अवसाद नहीं, प्रेम की शुद्धि-प्रक्रिया है। जीवनी का 'हृदय से विरक्त' (सांसारिक विरक्ति) यहाँ 'कृष्ण-अनुरक्त' (दिव्य अनुरक्ति) की पूर्वपीठिका बनता है। विरोधाभास अलंकार (दुज्ख/गस्ज, उहत/मन मंदिर) द्वारा कवि दर्शाते हैं कि वही ऊर्जा जो संसार से खींचती थी, अब कृष्ण की ओर प्रवाहित होती है। रसखान का व्यक्तित्व 'दुःख को साधना में रूपांतरित करने' की क्षमता में निहित है।"

## WORKED_EXAMPLE_3
PROBLEM: Board exam question (6 marks): "रसखान के व्यक्तित्व में 'सामाजिक सीमाओं का अतिक्रमण' (transgression of social boundaries) कैसे प्रतिबिंबित होता है? जीवनी और काव्य-दोनों के सन्दर्भ से विश्लेषण कीजिए।"

STEPS:
- Step 1 — Deconstruct the prompt: Three requirements — (a) identify specific boundaries crossed, (b) use biographical evidence, (c) use poetic evidence, (d) synthesize into character portrait.
- Step 2 — Map boundaries from biography: (1) Religious: Muslim → Krishna bhakta (not conversion, but *participation*), (2) Linguistic: Persian elite → Braj vernacular, (3) Spatial: Courtly/urban → Vrindavan forest-ashram, (4) Social: Jat nobility → Goswami disciple.
- Step 3 — Map boundaries from poems: (1) Gender/voice: Male poet → female persona (Radha/gopi) — *cross-gender ventriloquism*, (2) Human/Divine: Devotee addresses God as "प्राणनाथ" (life-lord) — *erotic-devotional boundary blur*, (3) Literary: Persianate imagery ("हजार", "लक्ष") → Braj bhakti lexicon — *register transgression*.
- Step 4 — Select strongest evidence pairs: Biography "जयदेव की भक्ति से प्रभावित" + Poem "मेरे प्राणनाथ" = *guru-parampara to direct intimacy*; Biography "ब्रजभाषा सीखी" + Poem "गोपी-भाषा में राधा" = *language as boundary-crossing tool*.
- Step 5 — Structure the 6-mark answer: Intro (thesis: Raskhan's character = boundary-crossing as spiritual method) → 3 PEEL paragraphs (Religious-Linguistic, Spatial-Communal, Gender-Voice) → Conclusion (transgression as synthesis, not rebellion).
- Step 6 — Verify marking scheme alignment: Each PEEL = 1.5 marks (Point 0.5, Evidence 0.5, Explanation 0.5). Thematic synthesis in conclusion = 1 mark. Total 6.

REASONING: High-mark board questions require *multi-register evidence* (biography + poetry) and *conceptual framing* ("boundary-crossing as method"). The worked example models how to move from textual details to an analytical thesis that satisfies the "literary appreciation" rubric.

ANSWER:
रसखान का व्यक्तित्व 'सीमा-अतिक्रमण' को विद्रोह नहीं, 'प्रेम-साधना' मानता है।
1. धार्मिक-भाषाई: मुस्लिम कुलोत्पन्न होकर ब्रजभाषा में कृष्ण-भक्ति (जीवनी: "फारसी छोड़ ब्रज सीखा"; कविता: गोपी-भाषा में राधा-संवाद) — भाषा-परिवर्तन पहचान-पुनर्निर्माण है।
2. सामाजिक-स्थानिक: जाट कुलीनता से गोस्वामी शिष्यत्व, नगरीय दरबार से वृन्दावन वन-आश्रम (जीवनी: "वृन्दावन में बसे"; कविता: "मन मंदिर" रूपक) — भौतिक विस्थापन आंतरिक पुनर्वास है।
3. लैंगिक-स्वर: पुरुष कवि द्वारा स्त्री-स्वर (राधा/गोपी) अपनाना, फिर सीधे कृष्ण को "प्राणनाथ" कहना (पद 1 → पद 2) — स्वर-परिवर्तन भक्ति की परिपक्वता है।
निष्कर्ष: रसखान सीमाएँ तोड़ते नहीं, उन्हें 'प्रेम' में विलीन करते हैं — यही उनका 'समन्वयवादी व्यक्तित्व' है।

## COMPETENCY_QUESTION_1
QUESTION: A Class 12 student writes this character sketch opening: "रसखान एक महान कवि थे जिन्होंने मुसलमान होकर भी कृष्ण की भक्ति की।" Identify three specific weaknesses in this opening for a board exam answer, and rewrite it to meet "literary appreciation" standards.

COMPETENCY: Critical evaluation of peer writing / Answer structuring for board exams

STEPS:
- Step 1 — Identify weakness 1: "महान कवि" — unsubstantiated value judgment; board exams require *evidence-based traits*, not honorifics.
- Step 2 — Identify weakness 2: "मुसलमान होकर भी" — frames identity as contradiction ("even though Muslim"), revealing communal bias; the text presents it as *continuity* ("समन्वय").
- Step 3 — Identify weakness 3: No textual anchor — zero reference to biography details or poetic lines; reads like general knowledge, not chapter-based analysis.
- Step 4 — Rewrite using PEEL: Point (specific trait), Evidence (biography + poem), Explanation (significance), Link (theme).

ANSWER:
Weaknesses: (1) "महान" — मूल्यांकन नहीं, विश्लेषण चाहिए; (2) "होकर भी" — द्वैतवाद दर्शाता है, पाठ का 'समन्वय' नहीं; (3) सन्दर्भहीन — पाठ-आधारित नहीं।
Rewritten opening: "रसखान का व्यक्तित्व 'भाषाई और आध्यात्मिक सीमाओं के संश्लेषण' (संश्लेषण, न कि अतिक्रमण) में निहित है — जीवनी में फारसी-परिवेश से ब्रजभाषा की ओर सचेत गमन ('कठोर परिश्रम से अधिकार पाया') और पद 2 में 'मेरे प्राणनाथ' के आत्मसमर्पण-युक्त संबोधन द्वारा यह संश्लेषण 'प्रेम-मार्ग' की जीवंत अभिव्यक्ति बनता है।"

DIFFICULTY
medium

## COMPETENCY_QUESTION_2
QUESTION: The chapter includes two distinct poetic extracts: (1) हजारी-जिके का इज़ (Radha's voice addressing Hajari/Jike), (2) तूथ फुज्खर... (poet's direct address to Krishna). Design a 4-step analytical framework a student can use to compare how *each extract constructs Raskhan's character differently* — one through dramatic mask, one through lyric intimacy. Apply your framework to produce one comparative insight.

COMPETENCY: Metacognitive strategy design / Comparative textual analysis

STEPS:
- Step 1 — Define the two registers: Register A = Dramatic persona (पद 1: राधा/गोपी का स्वर, तृतीय-व्यक्ति कथन), Register B = Lyric intimacy (पद 2: कवि का अपना स्वर, प्रथम-व्यक्ति संबोधन).
- Step 2 — Map character dimensions each register reveals: Register A → *devotional knowledge* (रसखान ब्रज-लीला की परंपरा जानता है, उसका पुनर्सृजन करता है), Register B → *devotional experience* (रसखान स्वयं लीला में भाग लेता है, केवल वर्णन नहीं करता).
- Step 3 — Identify the structural progression: Biography → Register A → Register B mirrors *learning → performing → being*. The character *moves* from outside the tradition to inside it.
- Step 4 — Formulate comparative insight: The shift from "हजारी-जिके" (third-party names, social world) to "प्राणनाथ" (direct address, sacred world) maps Raskhan's journey from *cultural translator* (rendering bhakti in Braj) to *cultural insider* (inhabiting bhakti).

REASONING: This competency tests whether the student can *design* an analytical method (not just apply one) and see the *structural logic* of the chapter's composition. The two poems are not random selections — they are *stages in the protagonist's self-fashioning*.

ANSWER:
Framework: (1) Register Identification (Persona vs Lyric), (2) Character Dimension Mapping (Knowledge vs Experience), (3) Structural Positioning (Sequence as Development), (4) Insight Synthesis (Translator → Insider).
Comparative Insight: पद 1 में रसखान 'परंपरा के वाहक' हैं (राधा की आवाज़ में ब्रज-संस्कृति को पुनर्जीवित करते हुए); पद 2 में वे 'परंपरा के निवासी' हैं (स्वयं कृष्ण से संवाद करते हुए)। यह परिवर्तन जीवनी के 'सीखने-बसने' क्रम का काव्यात्मक समकक्ष है — चरित्र 'बाहरी' से 'भीतरी' होता है।

DIFFICULTY
hard