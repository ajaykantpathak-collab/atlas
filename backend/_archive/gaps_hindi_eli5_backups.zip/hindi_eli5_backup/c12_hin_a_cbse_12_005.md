## DEFINITION
Supporting character analysis examines how secondary characters in a narrative — through their distinct traits, dialogues, actions, and relationships — reveal the protagonist's personality, advance the plot, embody thematic ideas, and reflect the social milieu, without being the central focus of the story.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student can identify at least three supporting characters in "laofn;k", cite specific textual evidence (actions, speech, descriptions) for each, explain their functional role in the narrative (foil, catalyst, thematic representative), and articulate how they deepen the story's exploration of rural life and storytelling tradition.

## SCOPE_BOUNDARY
This node covers only the supporting characters in the short story "laofn;k" (Badi Gosyani, Badi Chhutki, Chhoti Maa, the driver, villagers). It does NOT cover the protagonist (Gajakshaphu) — that is node c12_hin_a_cbse_12_004 — nor thematic analysis (nodes 006, 007) or literary devices (nodes 008, 009).

## WALKTHROUGH
Imagine watching a village play where the lead actor speaks most lines, but the old auntie sitting on the cot, the chatty neighbor, and the silent mother shape every decision he makes. That is exactly what happens in "laofn;k". Begin by listing every character who is NOT Gajakshaphu. For each, ask: What does the author explicitly describe about their appearance or manner? What do they say, and how do they say it? What do they do that changes the scene? How does Gajakshaphu react to them? Jot down page/line references. Then group your observations: which characters represent tradition, which represent modernity, which expose Gajakshaphu's vulnerability? The key insight is that supporting characters in this story are not decorative — they are the living archive of the oral culture Gajakshaphu embodies.

## DIAGNOSTIC_QUESTION_1
Name three supporting characters in "laofn;k" and give one defining trait for each based on the text.

## DIAGNOSTIC_ANSWER_1
Correct answer: (1) Badi Gosyani — talkative, manipulative, acts as the host who summons the storyteller; (2) Badi Chhutki — extremely old, frail, tells stories in a hypnotic voice, embodies the fading oral tradition; (3) Chhoti Maa — practical, protective of her son, skeptical of the storyteller's motives. A wrong answer that lists only "old women" or "villagers" without distinguishing traits shows the student cannot differentiate characterisation from mere presence.

## DIAGNOSTIC_QUESTION_2
Explain in your own words how Badi Chhutki's storytelling differs from Gajakshaphu's and why that difference matters.

## DIAGNOSTIC_ANSWER_2
Correct answer: Badi Chhutki tells stories from lived memory, in a slow, hypnotic rhythm that puts listeners into a trance, while Gajakshaphu performs professionally for survival. The difference matters because it shows storytelling as a communal ritual (hers) versus a commodified skill (his). A wrong answer that says "both tell stories" misses the contrast between organic tradition and professional performance — a central tension in the story.

## DIAGNOSTIC_QUESTION_3
Find two moments in the text where Chhoti Maa's dialogue reveals her distrust of Gajakshaphu. Quote or paraphrase each and explain what her suspicion tells us about the village's attitude toward outsiders.

## DIAGNOSTIC_ANSWER_3
Correct answer: (1) When she asks "क्या लेन-देन बाकी है?" after Gajakshaphu claims he has settled accounts — shows she monitors transactions closely. (2) When she warns "तुम्हारी माँ... तुमको छोड़कर चली जायेगी" — reveals she sees through his emotional manipulation. Both moments illustrate the village's sharp, transactional wariness toward itinerant performers. A wrong answer that picks random lines without linking to distrust shows inability to connect dialogue to character motive.

## DIAGNOSTIC_QUESTION_4
Compare the narrative function of Badi Gosyani and the driver (who takes Gajakshaphu to the village). How does each move the plot forward in a different way?

## DIAGNOSTIC_ANSWER_4
Correct answer: Badi Gosyani initiates the central conflict by inviting Gajakshaphu and setting the storytelling event in motion; she is the catalyst. The driver merely provides transportation and background information about the village's changed condition; he is an expository device. A wrong answer that treats both as "minor characters who help the hero" fails to distinguish catalytic agency from functional utility.

## DIAGNOSTIC_QUESTION_5
Evaluate the claim: "Badi Chhutki is the most important supporting character because she represents the authentic voice of the village." Defend or refute with textual evidence.

## DIAGNOSTIC_ANSWER_5
Correct evaluation: The claim is partially true but incomplete. Badi Chhutki does embody authentic oral tradition (her stories put the whole village in a trance), but Chhoti Maa represents the village's pragmatic survival instinct, and Badi Gosyani represents its gossipy social fabric. Together they form a triad of village voices. A wrong answer that simply agrees or disagrees without acknowledging the ensemble nature of the supporting cast shows reductive thinking.

## DIAGNOSTIC_QUESTION_6
Write a 150-word scene from Badi Chhutki's perspective describing Gajakshaphu's arrival, using her voice (slow, sensory, rooted in memory). Include at least two details from the text reimagined through her eyes.

## DIAGNOSTIC_ANSWER_6
A strong answer will use first-person, present-tense narration with sensory details (smell of dust, sound of cart wheels, feel of cot strings), reflect her frailty and authority, and incorporate textual facts: e.g., Gajakshaphu arriving in a cart, Badi Gosyani's summons, the village's changed layout. A weak answer will write in third person, use modern vocabulary, or omit her distinctive slow rhythm — showing failure to internalize character voice.

## COMMON_MISCONCEPTION
Students often treat supporting characters as a list of names with adjectives ("Badi Gosyani is talkative") and stop there. They miss that in "laofn;k" each supporting character is a deliberate thematic instrument: Badi Gosyani = the commodification of storytelling (she "sells" the event), Badi Chhutki = the pure, dying tradition, Chhoti Maa = the protective, pragmatic present. The error comes from reading for plot only, not for how character clusters map onto the story's central conflict: tradition vs. performance, memory vs. survival.

## ON_FAILURE
1. Re-read the story marking every speech by a non-protagonist character with a coloured pencil. 2. Make a three-column table: Character | Exact Words/Action | What This Reveals About Village Life. 3. For each character, write one sentence answering: "If this character were removed, what would the story lose?" 4. Discuss your table with a peer or teacher, focusing on the thematic triad (commodification, tradition, pragmatism). 5. Re-attempt Diagnostic Questions 2 and 4.

## BUILDS_ON
Character Analysis: Protagonist (c12_hin_a_cbse_12_004) — understanding Gajakshaphu's contradictions is essential to see how supporting characters reflect, challenge, or complete him.

## LEADS_TO
Theme: Primary Theme and Message (c12_hin_a_cbse_12_006) — the supporting characters collectively embody the story's core tension between oral tradition and modern disruption.

## PREREQUISITE_NODE_IDS
c12_hin_a_cbse_12_004, c12_hin_a_cbse_12_002, c11_hin_ar_cbse_01_005, c11_hin_ar_cbse_02_005, c11_hin_ar_cbse_03_005, c12_hin_a_cbse_12_001

## PREREQUISITE_REASONS
c12_hin_a_cbse_12_004: Protagonist analysis provides the central figure against which supporting characters are defined. c12_hin_a_cbse_12_002: Plot structure knowledge helps locate where each supporting character enters and exits the narrative. c11_hin_ar_cbse_01_005: Class 11 foundation on supporting character roles (foil, catalyst, etc.) is directly applied here. c11_hin_ar_cbse_02_005: Additional practice with rural narratives sharpens contextual reading. c11_hin_ar_cbse_03_005: Exposure to multiple texts builds comparative analytical skill.
c12_hin_a_cbse_12_001: Supporting characters represent the village community described in context.  
c12_hin_a_cbse_12_002: Supporting characters' roles are defined by their function in the plot.  
c11_hin_ar_cbse_01_005: Supporting characters are fictional figures who interact with the protagonist to advance t... की समझ आवश्यक है, क्योंकि यह नोड (Supporting character analysis examines how secondary characters in a narrative — through t...) इसी आधार पर आगे बढ़ता है।  
c11_hin_ar_cbse_02_005: Character analysis of supporting characters examines how secondary figures function in a n... की समझ आवश्यक है, क्योंकि यह नोड (Supporting character analysis examines how secondary characters in a narrative — through t...) इसी आधार पर आगे बढ़ता है।  
c11_hin_ar_cbse_03_005: Character analysis of supporting characters involves examining how secondary figures in a... की समझ आवश्यक है, क्योंकि यह नोड (Supporting character analysis examines how secondary characters in a narrative — through t...) इसी आधार पर आगे बढ़ता है।  

## FORWARD_NODE_IDS
c12_hin_a_cbse_12_006, c12_hin_a_cbse_12_013, c12_hin_a_cbse_12_014, c12_hin_a_cbse_12_007, c12_hin_a_cbse_12_010, c12_hin_a_cbse_12_015

## FORWARD_REASONS
c12_hin_a_cbse_12_006: Thematic analysis requires the character evidence gathered here. c12_hin_a_cbse_12_013: Critical thinking tasks demand multi-character interpretation. c12_hin_a_cbse_12_014: Writing skills (character sketch, thematic essay) use this analysis as raw material.
c12_hin_a_cbse_12_007: Supporting character analysis (cM+h cgqfj;k, cM+h gosyh) supplies the embodied carriers of secondary themes.  
c12_hin_a_cbse_12_010: Midwife's characterization gives emotional weight to 'Hkw[kh&I;klh' and 'flldrh'.  
c12_hin_a_cbse_12_015: Provides cM+h gosyh and cM+h cgqfj;k analyses for gendered storytelling debate  
c12_hin_a_cbse_12_013: अगला तार्किक चरण: Critical Thinking: इस नोड की अवधारणाओं को सीधे उपयोग/विस्तारित करता है।  
c12_hin_a_cbse_12_014: अगला तार्किक चरण: Writing skills based on a literary chapter refer to the ability to compose structured, evidence-base... इस नोड की अवधारणाओं को सीधे उपयोग/विस्तारित करता है।  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
No cross-subject nodes provided in prior class data.

## CHAIN_DESCRIPTION
c12_hin_a_cbse_12_004 -> c12_hin_a_cbse_12_005 -> c12_hin_a_cbse_12_006

## THIS_FORMULA
N/A - conceptual

## FORMULA_VARIABLES
N/A

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
analytical

## CROSS_SUBJECT
N/A | The story's depiction of Badi Chhutki as a living archive mirrors historical studies of oral tradition transmission in pre-literate societies.
 N/A | The triad of village women (gossip, elder, pragmatic mother) reflects sociological typologies of gendered roles in traditional North Indian villages.
## PREREQ_CONCEPT
Ability to extract character traits from textual evidence (dialogue, description, action) and distinguish direct vs. indirect characterization.

## PREREQ_BEFORE
Student must have completed protagonist analysis (c12_hin_a_cbse_12_004) and understand the story's plot outline (c12_hin_a_cbse_12_002).

## PREREQ_STUCK
If stuck, revisit the "Character Trait Evidence Table" method taught in c12_hin_a_cbse_12_004 and apply it to one supporting character at a time.

## WORKED_EXAMPLE_1
PROBLEM: Analyze how Badi Gosyani's first interaction with Gajakshaphu (summoning him to tell a story) establishes her role as the agent of commodification.
STEPS:
- Step 1: Locate the opening scene where Badi Gosyani calls out to Gajakshaphu — "अरे बुढ़िया, कहाँ मर गई?" — noting her peremptory tone.
- Step 2: Identify the transactional language: she treats the storytelling as a service to be summoned, not a gift to be requested.
- Step 3: Contrast with how villagers traditionally invite a storyteller (with respect, offerings) — the text mentions "लोककथा के प्रत्येक शब्द को... उसी लगन और लय में सुनना".
- Step 4: Connect to her later behaviour: she negotiates the "fee" (जगह-जगह कहानी पहुँचाने का काम), turning oral art into a circuit.
- Step 5: Conclude that her character embodies the shift from community ritual to market exchange.
REASONING: This step-by-step moves from textual detail to linguistic pattern to structural contrast to thematic implication — the exact analytical ladder board exams reward.
ANSWER: Badi Gosyani's opening summons uses imperative, dismissive address ("बुढ़िया") and immediate demand for performance, framing storytelling as on-demand labour. Unlike the traditional invitation described in the author's preface — where listeners honour each word with "लगन और लय" — she reduces the storyteller to a vendor. Her subsequent haggling over "कहानी पहुँचाने का काम" confirms she operates as a broker of narratives. Thus she personifies the commodification threatening the oral tradition Gajakshaphu represents.

## WORKED_EXAMPLE_2
PROBLEM: Explain how Badi Chhutki's physical description and storytelling style together create a symbol of vanishing authenticity.
STEPS:
- Step 1: Collect physical descriptors: "नब्बे साल की बुढ़िया", "हाथ-पैर काँपते", "आवाज़ में कम्पन", "खाट पर पड़ी रहती".
- Step 2: Collect storytelling descriptors: "कहानी सुनाते-सुनाते सो जाती", "श्रोता तक पहुँचते-पहुँचते कहानी बदल जाती", "सबके प्राण खींच लेती".
- Step 3: Note the paradox — her frailty coexists with hypnotic power over listeners.
- Step 4: Link to the author's comment: "लोककथा... जनमानस के अंतस्तल तक पहुँचती".
- Step 5: Argue that her decaying body and morphing stories represent a tradition that survives precisely through imperfection and embodiment.
REASONING: The example models how to synthesize scattered descriptive details into a coherent symbolic reading — a key competency for long-answer questions.
ANSWER: Badi Chhutki's trembling limbs and faltering voice ("हाथ-पैर काँपते", "आवाज़ में कम्पन") make her seem on the verge of extinction, yet her storytelling exerts a trance-like hold ("सबके प्राण खींच लेती"). The text notes stories change as they reach each listener ("श्रोता तक पहुँचते-पहुँचते कहानी बदल जाती"), mirroring how her own memory reshapes tales. This fusion of bodily decay and narrative fluidity makes her a living symbol of oral tradition: authentic not because it is fixed, but because it is embodied, vulnerable, and communally reshaped — exactly what the author calls "जनमानस के अंतस्तल तक पहुँचती".

## WORKED_EXAMPLE_3
PROBLEM: Compare Chhoti Maa's two interventions (warning Gajakshaphu about his mother, and refusing to let him stay) to show how she functions as the voice of pragmatic realism.
STEPS:
- Step 1: Quote first intervention: "तुम्हारी माँ... तुमको छोड़कर चली जायेगी" — identify it as a reality check on his emotional manipulation.
- Step 2: Quote second: "इस घर में तुम्हारा कोई काम नहीं" — identify it as boundary-setting against exploitation.
- Step 3: Analyse her language: direct, unadorned, focused on consequences ("भूखे मरोगे", "कौन खिलाएगा").
- Step 4: Contrast with Badi Chhutki's hypnotic, timeless storytelling and Badi Gosyani's performative gossip.
- Step 5: Connect to the story's broader tension: tradition (Badi Chhutki) vs. market (Badi Gosyani) vs. survival (Chhoti Maa).
- Step 6: Conclude that Chhoti Maa grounds the narrative in material necessity, preventing it from becoming pure nostalgia.
REASONING: This multi-step comparison across three characters demonstrates the "cluster analysis" skill needed for competency-based questions that ask "how do supporting characters collectively shape the theme?".
ANSWER: Chhoti Maa's two interventions cut through the story's lyrical atmosphere with blunt materialism. First, she exposes Gajakshaphu's lie about his mother ("तुम्हारी माँ... तुमको छोड़कर चली जायेगी"), refusing to let sentiment override fact. Second, she ejects him ("इस घर में तुम्हारा कोई काम नहीं"), prioritizing her household's survival over hospitality. Her vocabulary — "भूखे मरोगे", "कौन खिलाएगा" — is the language of subsistence. While Badi Chhutki embodies tradition's timeless flow and Badi Gosyani embodies its market corruption, Chhoti Maa embodies the present's hard calculus. Together the three women form a thematic triad: past, present, and the transaction that mediates them.

## COMPETENCY_QUESTION_1
QUESTION: The author describes Badi Chhutki's storytelling as "लोककथा... जनमानस के अंतस्तल तक पहुँचती". Using evidence from her scenes, explain how the narrative technique of showing her stories "changing as they reach each listener" (श्रोता तक पहुँचते-पहुँचते कहानी बदल जाती) enacts this definition.
COMPETENCY: Literary Analysis – Connecting Narrative Technique to Thematic Definition
STEPS:
- Step 1: Restate the author's definition in your own words.
- Step 2: Identify two textual moments where Badi Chhutki's story visibly shifts per listener.
- Step 3: Explain how each shift reflects the listener's own context (fear, hope, memory).
- Step 4: Conclude why this fluidity = "reaching the innermost core" rather than distortion.
ANSWER: The author defines folk tale as something that enters the collective innermost core ("जनमानस के अंतस्तल"). Badi Chhutki's stories mutate per listener: for the driver they become a roadmap, for Gajakshaphu a mirror of his abandonment, for the villagers a shared dream. Each mutation proves the tale is not a fixed text but a living conduit — it *becomes* the listener's innermost need. Thus the very instability the text notes ("कहानी बदल जाती") is the mechanism of deep penetration. The technique enacts the definition.
DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: A board exam question asks: "Supporting characters in 'laofn;k' are not merely helpers; they are the story's argument." Write a structured response (PEEL format) evaluating this statement with reference to all three major supporting women.
COMPETENCY: Argumentative Writing – Synthesising Character Analysis into Thematic Claim
STEPS:
- Step 1: Point — State your position (agree/disagree) in one sentence.
- Step 2: Evidence — For each woman, give one concise textual detail that supports your position.
- Step 3: Explanation — Link each detail to a specific thematic argument (tradition, commodification, survival).
- Step 4: Link — Show how the three arguments interlock to form the story's central debate.
- Step 5: Conclude with a sentence on why this makes them "the argument" not "helpers".
ANSWER: Point: I agree — the three women embody the story's central argument about oral culture's fate. Evidence 1: Badi Chhutki's morphing tales = tradition as living, communal memory. Evidence 2: Badi Gosyani's fee-haggling = tradition as marketable commodity. Evidence 3: Chhoti Maa's expulsion of the storyteller = tradition as unsustainable luxury. Explanation: Each woman personifies a distinct historical force acting on folk storytelling. Link: Their confrontation in the final scenes (Chhutki storytelling, Gosyani brokering, Maa ejecting) stages the argument dramatically. They are not helpers to Gajakshaphu; they are the battlefield on which his crisis plays out.
DIFFICULTY: hard