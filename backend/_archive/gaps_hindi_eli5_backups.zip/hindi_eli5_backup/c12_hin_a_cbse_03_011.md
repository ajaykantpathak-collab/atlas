## DEFINITION
Language Usage in the Text refers to the systematic analysis of grammatical structures, syntactic patterns, lexical choices, and stylistic devices employed by the poet (vKs;/Nagarjun) in the poems "nhi vosQyk" and "eSaus ns[kk] ,d cw¡n" to convey tone, theme, and emotional intensity. It includes examining verb moods (imperative, indicative), compound word formation (samAs), dialectal influences (Khari Boli/Braj/Awadhi), and deviations from standard grammar for poetic effect (poetic license).

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student can independently identify at least three distinct grammatical/stylistic features in a given stanza (e.g., use of imperative mood, specific samAs, dialectal verb forms), explain their semantic function with textual evidence, and evaluate how these choices reinforce the poem's central idea of individual dignity vs. societal conformity.

## SCOPE_BOUNDARY
This node covers ONLY the grammatical and linguistic analysis of the two poems in Chapter 3 ("nhi vosQyk" and "eSaus ns[kk] ,d cw¡n"). It does NOT cover plot summary, character sketches, thematic essays, or historical context of the poet — those are addressed in sibling nodes c12_hin_a_cbse_03_002, 03_004, 03_006, 03_007.

## WALKTHROUGH
Imagine you are reading "nhi vosQyk" aloud and notice the poet repeatedly commands "iafDr dks ns nks" — why does he use the imperative mood instead of a polite request? That observation is your entry point. First, read the poem aloud to catch the rhythm and sound patterns. Second, underline every verb and identify its mood (command, statement, wish). Third, circle compound words (like "ve`r&iwr", "mYyac&ckgq") and break them into components using samAs rules from Class 11. Fourth, note words that deviate from standard Khari Boli (e.g., "lfeèkk" for "fe="). Finally, connect each finding to the effect: the imperative mood asserts the individual's agency; the compounds compress complex social realities. The key insight: Nagarjun bends grammar to make language itself an act of rebellion.

## DIAGNOSTIC_QUESTION_1
Identify the grammatical mood of the verb "ns" in the refrain "ij bldks Hkh iafDr dks ns nks" and state its person and number.

## DIAGNOSTIC_ANSWER_1
The verb "ns" (from "nkA") is in the **imperative mood (vidhiliG)**, **second person (madhyam puruS)**, **singular number (ekavacan)**. A wrong answer (e.g., labeling it future tense or third person) reveals the student cannot distinguish mood from tense or identify the implied subject "tus" (you) addressing the "nhi" (nose) as an independent entity — a crucial personification device.

## DIAGNOSTIC_QUESTION_2
Explain in your own words why the poet uses the compound "ve`r&iwr" (ve`r :ih ifo=k nw/) instead of a simple phrase like "ve`r dk iwr" in the line ";g xksjlµthou&dkeèksuq dk ve`r&iwr i;]".

## DIAGNOSTIC_ANSWER_2
"ve`r&iwr" is a **tatpuruSa samAs (karmadharaya subtype)** where "ve`r" (root/origin) qualifies "iwr" (support/base), meaning "the very foundation of the root". The compound compresses a genitive phrase into a single dense image, suggesting the nose is not just *supported by* roots but *is* the root-support of life's struggle. A student who paraphrases as "ve`r ka aadhar" misses the semantic fusion: the compound makes the nose the *active agent* of grounding, not a passive recipient — essential for the poem's assertion of self-reliance.

## DIAGNOSTIC_QUESTION_3
In the line "eSaus ns[kk] ,d cw¡n lglk mNyh lkxj osQ >kx ls_", identify the case (karak) of "lkxj" and "cw¡n" and explain how the case marking shapes the visual perspective.

## DIAGNOSTIC_ANSWER_3
"lkxj" is in **ablative case (apadan karak, "osQ >kx ls")** indicating motion away from the source; "cw¡n" is in **accusative case (karm karak, direct object of "ns[kk]")**. The ablative on "lkxj" forces the reader's gaze to *originate* at the green branch, while the accusative on "cw¡n" makes the green bird the *focused endpoint*. A student who marks both as nominative fails to see the grammatical choreography: the poem literally moves the eye from branch to bird, enacting the sudden revelation of colour.

## DIAGNOSTIC_QUESTION_4
Compare the verb forms in the two poems: "ns nks" (imperative, repeated 4 times) vs. "ns[kk]" (past perfect, once). What does this contrast reveal about the speaker's agency in each poem?

## DIAGNOSTIC_ANSWER_4
"nhi vosQyk" uses **repeated imperative (vidhiliG)** — the speaker *commands* the nose to accept dignity, asserting active, ongoing agency. "eSaus ns[kk]" uses **past perfect (bhutakal, parokS)** — the speaker *recounts* a completed act of seeing, making agency retrospective and observational. The contrast shows Nagarjun's range: the first poem enacts resistance *through* grammar (imperative = performative utterance), the second reflects on beauty *after* the moment. A student who only labels tenses misses the pragmatic force: mood creates mode of existence.

## DIAGNOSTIC_QUESTION_5
Critique the view that Nagarjun's use of dialectal forms (e.g., "lfeèkk" for "fe=", "fcjyk" for "cgqrksa esa ,d") is merely "rustic flavour". Defend your position using two specific examples from the poems.

## DIAGNOSTIC_ANSWER_5
Dialect forms are **semantic precision tools**, not decoration. "lfeèkk" (from Braj "lfe=" + diminutive "kk") conveys *tender smallness* of the nose-tip — "fe=" is clinically anatomical; "lfeèkk" is affectionate, humanizing the body part that becomes a symbol of pride. "fcjyk" (Awadhi for "cgqrksa esa ,d") carries folk-rhythm that standard "ek" lacks, embedding the nose's uniqueness in oral tradition. A student calling it "rustic flavour" imposes a urban-centric hierarchy; the poems *elevate* the dialect to philosophical vocabulary.

## DIAGNOSTIC_QUESTION_6
Write a four-line stanza in Hindi imitating Nagarjun's style: use an imperative refrain, one tatpuruSa samAs, one dialectal word, and personify a body part to assert self-worth.

## DIAGNOSTIC_ANSWER_6
**Sample answer:**
^d~Bk d~Bk] lkFk&y{e.k]  
^tus] vk¡[k] vkSj vPNk dks ns nksA  
^lqcg] lqUnj] lqHkkf"kr]  
^;g gS eSa] ;g gS eSa] ;g gS eSaA**  
*Criteria:* Imperative "ns nks" (refrain), tatpuruSa "lkFk&y{e.k" (hath+yogya), dialect "vk¡[k]" (Awadhi for ears), personified body parts commanded. A poor answer uses standard vocabulary only, lacks refrain, or personifies without grammatical command structure — showing inability to internalize the *grammar of resistance*.

## COMMON_MISCONCEPTION
Students treat "Language Usage" as **vocabulary listing** (defining "izÑr", "Lo;aHkw", "v;qr%") rather than **grammatical analysis**. They write word-meanings from the textbook's 'kCnkFkZ' section and call it grammar. This error occurs because Class 10-11 "Grammar" nodes often focused on isolated definitions (samAs types, karak names) without applying them to *literary effect*. In Board exams, a question like "iafDr osQ vkèkkj ij O;f"V osQ lef"V esa foltZu dh mi;ksfxrk crkb," requires explaining *how* the imperative mood *creates* the fusion of individual/social — not defining "vidhiliG". Competitive exams (CUET) ask: "Which grammatical feature most directly enacts the poem's central argument?" — answer: the imperative refrain, not the vocabulary.

## ON_FAILURE
1. **Revisit Class 11 Grammar Node**: Go to `c11_hin_ar_cbse_03_011` (or any Chapter 3 grammar node) and re-do the samAs/karak exercises *using lines from that chapter's poem*. 2. **Mini-drill**: Take 5 lines from "nhi vosQyk", parse every verb (mood, tense, person), every compound (samAs type), every case marker. 3. **Re-diagnostic**: Answer Diagnostic Question 2 and 4 again *without notes*. If you still paraphrase instead of analyzing grammatical function, repeat step 2 with a peer — teach them the parsing; teaching forces precision.

## BUILDS_ON
Class 11 skill of identifying samAs types and karak in isolation (c11_hin_ar_cbse_03_011) — now applied to *interpretive* analysis of poetic effect.

## LEADS_TO
Comprehension node (c12_hin_a_cbse_03_012) where grammatical evidence supports inferential answers, and Writing Skills node (c12_hin_a_cbse_03_014) where students use similar structures in original composition.

## PREREQUISITE_NODE_IDS
c11_hin_ar_cbse_03_011, c12_hin_a_cbse_03_010
## PREREQUISITE_REASONS
c11_hin_ar_cbse_03_011: Provides foundational grammar toolkit (samAs classification, karak identification, mood recognition) used here for literary analysis.
c12_hin_a_cbse_03_010: Supplies contextual vocabulary meanings (e.g., "ve`r&iwr", "mYyac&ckgq") which are the raw material for grammatical decomposition.

## FORWARD_NODE_IDS
c12_hin_a_cbse_03_012, c12_hin_a_cbse_03_013, c12_hin_a_cbse_03_014
## FORWARD_REASONS
c12_hin_a_cbse_03_012: Comprehension questions require grammatical evidence (e.g., "How does the imperative mood show the nose's agency?").
c12_hin_a_cbse_03_013: Critical interpretation of themes (individual vs society) depends on analyzing grammatical agency (imperative vs past perfect).
c12_hin_a_cbse_03_014: Writing tasks (e.g., "compose a poem using imperative refrain") directly apply the stylistic patterns analyzed here.

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
c12_english_poetry_analysis: Same analytical framework — mood, personification, syntactic deviation — applied to English poems (e.g., Tagore's "Where the mind is without fear" uses imperative "let my country awake").
c12_history_literature_movements: Nagarjun's use of dialect/colloquial grammar reflects the *Progressive Writers' Movement* (1930s) which weaponized language to democratize literature — a historical context for his grammatical choices.

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_03_011 -> c12_hin_a_cbse_03_011 -> c12_hin_a_cbse_03_012

## THIS_FORMULA
N/A - conceptual

## FORMULA_VARIABLES
N/A

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
linguistic

## CROSS_SUBJECT
N/A | Both require parsing verb mood (imperative vs indicative) to determine speaker agency and tone.
 N/A | Nagarjun's dialect use illustrates how non-standard grammar asserts subaltern identity — a sociolinguistic case study.
## PREREQ_CONCEPT
Ability to parse Hindi verbs for mood (vidhiliG, bhavitavyata, etc.), identify samAs vigraha, and assign karak roles — all from Class 11 grammar.

## PREREQ_BEFORE
Student must fluently break "ve`r&iwr" into "ve`r :ih ifo=k nw/" (tatpuruSa) and identify "ns" as vidhiliG madhyam puruSa ekavacan.

## PREREQ_STUCK
If stuck on samAs vigraha or karak assignment, review Class 11 Chapter 3 grammar exercises (c11_hin_ar_cbse_03_011) focusing on *poetic* examples, not textbook sentences.

## WORKED_EXAMPLE_1
PROBLEM: Analyze how the grammatical structure of the refrain "ij bldks Hkh iafDr dks ns nks" (repeated 4 times) enacts the poem's central argument about individual dignity.
STEPS:
- Step 1: Identify the core verb "ns" (from "nkA") — mood: imperative (vidhiliG), person: second (madhyam), number: singular (ekavacan). The implied subject is "tus" (you, the nose).
- Step 2: Note the adverbial phrase "Hkh" (also/even) modifying the command — implies the nose *already* possesses dignity ("Lusg Hkjk, xoZ Hkjk, enekrk") and now must *extend* it to "iafDr" (existence/society).
- Step 3: Observe the case marking: "iafDr" is dative (sampradan karak, "dks") — the dignity is *given to* existence, not taken from it. The nose is the active giver.
- Step 4: Track repetition across 4 stanzas — each repetition adds a new layer of identity (root of life, support of struggle, foundation of freedom, anchor of truth). The grammar accumulates: imperative + dative + additive "Hkh" = performative expansion of agency.
- Step 5: Connect to theme: The grammatical choice (imperative command to a body part) *performs* the rebellion. A declarative sentence ("The nose gives dignity to existence") would describe; the imperative *enacts* the giving. The nose becomes a grammatical agent of social transformation.
REASONING: The analysis moves from micro-grammar (mood, case) to macro-function (performative utterance, thematic accumulation). Each step uses a specific grammatical term to make a literary claim.
ANSWER: The imperative mood transforms the nose from a passive organ into an active moral agent; the dative case frames dignity as a gift the individual *bestows* on society; the additive "Hkh" and repetition structurally enact the expanding scope of that gift — from biological root to political freedom. Grammar *is* the argument.

## WORKED_EXAMPLE_2
PROBLEM: Deconstruct the compound "mYyac&ckgq" (mBh gqbZ ck¡g okyk) in the line ";g mYyac&ckgq] ;g fpj&v[kaM viukik" and explain its poetic function.
STEPS:
- Step 1: Identify samAs type: "mYyac" (mBh) + "ckgq" (ck¡g) = **bahuvrihi samAs** (exocentric compound) — the compound describes an entity *possessing* the quality, not the quality itself. Here, the nose *has* "mBh gqbZ ck¡g".
- Step 2: Vigraha (analysis): "mBh gqbZ ck¡g ySs mldk mYyac ckgq gS" — "one whose nose has a bent/raised tip". Note: "ckgq" is from "ckgq" (to bend/raise), not standard "ckgq" — dialectal/poetic form.
- Step 3: Semantic nuance: "mBh" (raised) + "ckgq" (bent/hooked) suggests a nose that is *proudly upturned* yet *grounded* (hook implies connection). Not merely "sharp" or "flat" — a specific physiognomy of resistance.
- Step 4: Contextual placement: The compound appears in the final stanza alongside "fpj&v[kaM" (another bahuvrihi: "one whose wings are feathers" = bird-like freedom). The pair "mYyac&ckgq] fpj&v[kaM" creates a **parallel bahuvrihi series** — the nose is both rooted (hook) and free (wings).
- Step 5: Effect: The bahuvrihi structure *externalizes* the quality — the nose *is* the "mYyac&ckgq" one. The grammar makes the attribute inseparable from the identity. Standard phrasing ("mldk mYyac ckgq gS") would separate nose from attribute; the compound fuses them.
REASONING: Bahuvrihi compounds are Nagarjun's signature for defining identity through embodied traits. The step-by-step shows how grammatical form (exocentric compound) creates semantic fusion (identity = attribute).
ANSWER: "mYyac&ckgq" is a bahuvrihi samAs meaning "the one with a raised, hooked nose-tip". Its poetic function: (1) fuses the nose's physical shape with its moral posture (pride + groundedness), (2) pairs with "fpj&v[kaM" to create a dual image of rootedness and flight, (3) uses dialectal "ckgq" to anchor the abstraction in folk speech. The grammar *embodies* the poem's ideal individual.

## WORKED_EXAMPLE_3
PROBLEM: Compare the syntactic representation of time in the two poems: "nhi vosQyk" uses present imperative ("ns nks") repeated in a timeless present; "eSaus ns[kk] ,d cw¡n" uses past perfect ("ns[kk]") framed by a present recollection ("eSaus ns[kk]"). How does this syntactic contrast structure the poems' differing relationships to memory and action?
STEPS:
- Step 1: Map tense/mood distribution in "nhi vosQyk": 4 imperatives ("ns nks"), 1 present indicative ("gS" in "gS xoZ Hkjk"), 1 optative ("y{;" in "y{; ,oa mís';"). Zero past tense. The poem lives in **eternal present of command**.
- Step 2: Map tense/mood in "eSaus ns[kk]": Main verb "ns[kk]" (past perfect, bhutakal parokS) — completed perception. Frame "eSaus ns[kk]" is also past perfect but functions as *narrative present* (I have seen = I recall seeing). No imperatives. The poem lives in **recollected past**.
- Step 3: Analyze syntactic framing: "nhi vosQyk" opens with imperative refrain — *action initiates* the poem. "eSaus ns[kk]" opens with "eSaus ns[kk]" — *perception precedes* the poem; the poem is the aftermath of seeing.
- Step 4: Link to thematic contrast: Poem 1 (nos) is **prescriptive** — grammar enacts a demand for future dignity. Poem 2 (bird) is **descriptive/epiphanic** — grammar records a past moment where beauty *happened* to the speaker. The bird's colour change ("jax xbZ {k.kHkj") is described in present ("xbZ") but framed by past perception — a memory of a present moment.
- Step 5: Evaluate grammatical agency: In Poem 1, the speaker *commands* (imperative) — agency is volitional. In Poem 2, the speaker *witnesses* (past perfect) — agency is receptive. Yet both assert value: one by fiat, one by testimony.
- Step 6: Synthesis: Nagarjun uses **mood as mode of ethics**. Imperative = ethics of resistance (you *must* give dignity). Past perfect = ethics of attention (I *saw*, therefore it matters). The syntax *is* the philosophy.
REASONING: This worked example combines tense/mood analysis, syntactic framing, and thematic synthesis — the highest level of language usage analysis expected in Board HOTS questions and CUET literary criticism.
ANSWER: "nhi vosQyk" syntactically enacts an **ongoing ethical demand** through repeated present imperative + zero past tense — the nose *must* keep giving dignity. "eSaus ns[kk] ,d cw¡n" syntactically enacts a **completed epiphany** through past perfect framing — the bird's beauty *was* revealed, and the poem preserves that revelation. The first poem uses grammar to *command* the future; the second uses grammar to *sanctify* the past. Both use verb morphology as moral architecture.

## COMPETENCY_QUESTION_1
QUESTION: In "nhi vosQyk", the poet addresses the nose as "tus" (you) and commands it "iafDr dks ns nks". A student argues: "This is just personification — a decorative device." Using grammatical evidence (mood, case, person, repetition), refute this claim and explain how the grammar *constitutes* the poem's argument about individual agency.
COMPETENCY: Literary argumentation using grammatical evidence
STEPS:
- Step 1: Identify the grammatical features: imperative mood (vidhiliG), second person singular, dative case ("iafDr dks"), additive particle ("Hkh"), refrain repetition (4 stanzas).
- Step 2: Explain the pragmatic force of imperative: it is a *speech act* (command), not a description. The nose is constituted as an *agent* capable of moral action.
- Step 3: Analyze "Hkh" + dative: the nose *already has* dignity (Lusg, xoZ, enekrk) and is commanded to *extend* it — agency is transitive, not reflexive.
- Step 4: Show how repetition accumulates agency: each stanza adds a new domain (life-root, struggle-support, freedom-foundation, truth-anchor) — grammar builds a expanding sphere of influence.
- Step 5: Conclude: Personification would be "The nose *is* proud." Grammar here *makes* the nose an ethical subject. The device is constitutive, not decorative.
ANSWER: The imperative mood performs the very agency it describes; the dative case makes dignity a transferable asset the individual controls; the repetition structurally enacts the expansion of that control from self to society. Calling it "decorative personification" ignores how grammar *creates* the political subject.
DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: A CUET-style question: "In Nagarjun's 'eSaus ns[kk] ,d cw¡n', the line 'jax xbZ {k.kHkj] <yrs lwjt dh vkx ls' uses the instrumental case ('vkx ls') on 'lwjt'. If the poet had used the ablative case ('lwjt osQ vkx ls'), how would the causal relationship between light and colour-change be altered? Explain with reference to the poem's epistemology of perception."
COMPETENCY: Counterfactual grammatical reasoning / semantic precision
STEPS:
- Step 1: Identify current case: "vkx ls" — instrumental (karaN karak) indicating *means/instrument*. The light's rays *are the instrument* by which colour changes.
- Step 2: Hypothesize ablative: "lwjt osQ vkx ls" — ablative (apadan karak) indicating *source/origin*. The rays would be the *source from which* colour emerges, not the tool that effects change.
- Step 3: Semantic difference: Instrumental = light *acts on* the bird (external agent). Ablative = colour *emanates from* light (light as origin). The poem's current grammar: "jax xbZ {k.kHkj] <yrs lwjt dh vkx ls" — the bird's colour *changes* (xbZ, intransitive) *by means of* rays. The bird is patient; light is instrument.
- Step 4: Epistemological implication: Instrumental preserves the bird's *passive receptivity* — colour change happens *to* it via light. This matches the speaker's stance: "eSaus ns[kk]" (I witnessed). The speaker sees the bird *receiving* light. Ablative would make light the *source of being*, shifting agency to light — the bird would be a mere manifestation.
- Step 5: Connect to "u'ojrk osQ nkx ls" (from the peak of wonder) — the wonder comes from seeing *receptivity*, not emission. The instrumental case protects the bird's integrity as a distinct perceiver.
ANSWER: Instrumental ("vkx ls") makes light the *instrument* of change acting on the bird — preserving the bird as a distinct perceiving subject. Ablative ("osQ vkx ls") would make light the *origin* of colour, dissolving the bird into light's emanation. The poem's epistemology (wonder at the bird's *reception* of light) requires the instrumental.
DIFFICULTY: hard