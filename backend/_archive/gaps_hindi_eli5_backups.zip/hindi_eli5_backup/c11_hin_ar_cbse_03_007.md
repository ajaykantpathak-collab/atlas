## DEFINITION
Secondary themes (गौण विषय) are the underlying ideas, motifs, or concerns that run parallel to the primary theme in a literary work, enriching the narrative by adding layers of meaning, revealing character depth, and reflecting broader human experiences without dominating the central message.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student must be able to identify at least three distinct secondary themes in "विव ओसक साथ छोटी लड़की," trace each theme across multiple textual evidences, and explain how each secondary theme interacts with the primary theme of childhood theatrical ambition to deepen the narrative's emotional resonance.

## SCOPE_BOUNDARY
This node covers identification, textual tracing, and analytical explanation of secondary themes in the prescribed chapter only. It does not cover primary theme analysis (covered in node 006), literary devices (nodes 008-009), or comparative theme analysis across chapters.

## WALKTHROUGH
Imagine you're watching a school play where the main story is about a boy trying to stage a production, but you keep noticing other stories happening simultaneously: two friends arguing over a role, a child inventing props from scrap, an adult watching silently from the doorway. These parallel stories are secondary themes. To find them in "विव ओसक साथ छोटी लड़की," start by listing every challenge the narrator faces — rain, missing actors, no props, adult interference — then ask: what human experience does each challenge represent? The rain isn't just weather; it's unpredictability. The missing actors aren't just absentees; they're the fragility of childhood commitments. Connect each concrete obstacle to its abstract representation, and you'll uncover the secondary themes.

## DIAGNOSTIC_QUESTION_1
What is the definition of a secondary theme (गौण विषय) in a literary text, and how does it differ from the primary theme (मुख्य विषय)?

## DIAGNOSTIC_ANSWER_1
A secondary theme is a subordinate idea that runs alongside the primary theme, adding depth and complexity without being the central focus. The primary theme is the main message or dominant idea (here: the process and passion of staging a play), while secondary themes are parallel concerns like friendship, resourcefulness, or nostalgia that enrich the narrative. A wrong answer that equates secondary themes with "less important themes" reveals a misunderstanding — secondary themes are not less important; they are structurally parallel but thematically supportive, and their removal would flatten the text's emotional texture.

## DIAGNOSTIC_QUESTION_2
In the chapter, the narrator describes how they used a broken cot (खटिया) as a stage and lanterns (लालटेन) for lighting. Which secondary theme does this improvisation represent, and why is it not merely a plot detail?

## DIAGNOSTIC_ANSWER_2
This represents the secondary theme of "resourcefulness amid scarcity" (संसाधनहीनता में रचनात्मकता/जुगाड़). It is not merely a plot detail because it recurs across multiple episodes — the makeshift curtain, the borrowed lanterns, the improvised stage — forming a pattern that reveals the children's agency and creativity. A wrong answer identifying this as "poverty" or "setting description" misses the thematic function: the text celebrates the children's inventive spirit, not their lack. The improvisation is a thematic statement about childhood resilience.

## DIAGNOSTIC_QUESTION_3
Trace the secondary theme of "fragility of childhood alliances" (बचपन के गठबंधनों की नाजुकता) across three distinct episodes in the chapter. Provide textual evidence for each.

## DIAGNOSTIC_ANSWER_3
Episode 1: The actor playing the king (राजा) disappears before the performance, forcing a last-minute replacement — showing how childhood commitments dissolve under pressure. Episode 2: The narrator's friend refuses to lend his lantern unless he gets a role — revealing transactional fragility in friendships. Episode 3: The rain scatters the audience and actors alike, dissolving the collective enterprise instantly. A wrong answer listing only one episode or citing adult conflicts (like the landlord) fails to trace the theme across the narrative arc, indicating the student cannot distinguish recurring thematic patterns from isolated incidents.

## DIAGNOSTIC_QUESTION_4
Compare how the secondary theme of "adult world vs. child world" (बड़ों की दुनिया बनाम बच्चों की दुनिया) operates in the landlord episode (मकान मालिक का प्रसंग) versus the father's silent observation episode (पिता का मौन अवलोकन). What does this contrast reveal about the narrator's evolving perspective?

## DIAGNOSTIC_ANSWER_4
The landlord episode shows the adult world as obstructive and incomprehensible — he threatens to evict them over noise, representing external authority crushing childhood dreams. The father's episode shows the adult world as quietly supportive — he watches silently, then helps dismantle the set, representing internal validation. The contrast reveals the narrator's mature retrospective understanding: not all adults are antagonists; some witness and honour the child's labour. A wrong answer treating both adults as "oppressive" or "supportive" flattens the nuance, showing the student cannot analyze thematic complexity or narrative perspective shifts.

## DIAGNOSTIC_QUESTION_5
Evaluate the claim: "The secondary theme of nostalgia (स्मृति/उदासीनता) in this chapter is merely the author's sentimental indulgence and does not serve a structural purpose." Defend or refute with textual reasoning.

## DIAGNOSTIC_ANSWER_5
Refute. Nostalgia structures the entire narrative frame — the chapter opens and closes with the adult narrator returning to the village, finding the theatre space transformed into a modern settlement. This circular structure uses nostalgia not as sentiment but as a lens to measure loss: the physical space is gone, the collaborators are scattered, but the memory of collective creation endures. The final line — "we were the ones who made that play" — transforms nostalgia into affirmation of agency. A wrong answer agreeing with the claim reveals an inability to distinguish thematic function from emotional tone, a critical error in senior secondary literary analysis.

## DIAGNOSTIC_QUESTION_6
Write a 150-word paragraph from the perspective of the missing actor (the boy who was to play the king but vanished), explaining his absence using the secondary theme of "fear of failure vs. desire for belonging" (असफलता का भय बनाम अपनेपन की चाह). Stay true to the chapter's tone and context.

## DIAGNOSTIC_ANSWER_6
A strong answer will voice the boy's internal conflict: the terror of forgetting lines before the landlord's threatening presence, the shame of wearing a borrowed crown that keeps slipping, the pull of his mother's call for dinner versus the troupe's desperate rehearsals. It will use sensory details from the text — the smell of rain on dust, the lantern's flicker, the cot's creak — and end with his silent departure, not as betrayal but as self-preservation. A poor answer will write a generic "I was scared" monologue without textual anchoring, revealing the student cannot inhabit a minor character's perspective to illuminate a secondary theme, a key skill for board-level creative-critical tasks.

## COMMON_MISCONCEPTION
Students believe secondary themes are "sub-plots" or "minor topics" that can be listed like items (e.g., "friendship, rain, lanterns"). They fail to see that a secondary theme is an abstract idea (like "resourcefulness") traced through a pattern of concrete events (improvised stage, borrowed lanterns, makeshift curtain). They also confuse "theme" with "subject" — writing "rain" as a theme instead of "unpredictability of nature disrupting human plans." This error stems from middle-school habit of listing topics rather than analyzing thematic architecture.

## ON_FAILURE
Step 1: Give the student a two-column table — Column A: Concrete Events from Text (e.g., "cot used as stage"), Column B: Abstract Idea it Represents (e.g., "resourcefulness"). Step 2: Have them fill 5 rows independently. Step 3: Ask them to group rows with the same abstract idea — each group is a secondary theme. Step 4: Require them to write one analytical sentence per group explaining how that theme deepens the primary theme. This moves them from listing to patterning to analyzing.

## BUILDS_ON
Builds on the primary theme identification (node 006) where students established the central concern as "the process and passion of staging a childhood play."

## LEADS_TO
Enables critical thinking and interpretation (node 013) where students synthesize primary and secondary themes to form original analytical arguments about the text's significance.

## PREREQUISITE_NODE_IDS
c11_hin_ar_cbse_03_001, c11_hin_ar_cbse_03_002, c11_hin_ar_cbse_03_006, c11_hin_ar_cbse_03_005

## PREREQUISITE_REASONS
c11_hin_ar_cbse_03_001: Context and background knowledge of the author and setting is essential to distinguish autobiographical nostalgia from fictional construction.
c11_hin_ar_cbse_03_002: Plot and narrative structure knowledge allows students to map secondary themes onto specific narrative beats (exposition, complication, climax, resolution).
c11_hin_ar_cbse_03_006: Primary theme identification must be secure first — secondary themes are defined relationally to the primary theme.
c11_hin_ar_cbse_03_005: Secondary themes (family vs. vocation, tradition vs. commerce) are carried by specific supporting characters.  

## FORWARD_NODE_IDS
c11_hin_ar_cbse_03_013, c11_hin_ar_cbse_03_014, c11_hin_ar_cbse_03_012, c11_hin_ar_cbse_03_015, c12_hin_a_cbse_01_007, c12_hin_a_cbse_03_007, c12_hin_a_cbse_08_007, c12_hin_a_cbse_10_007, c12_hin_a_cbse_12_007, c12_hin_al_cbse_01_007, c12_hin_al_cbse_03_007, c12_hin_ar_cbse_03_007, c12_hin_ar_cbse_07_007, c12_hin_ar_cbse_08_007, c12_hin_ar_cbse_11_007

## FORWARD_REASONS
c11_hin_ar_cbse_03_013: Critical thinking requires synthesizing multiple thematic threads into coherent interpretive arguments.
c11_hin_ar_cbse_03_014: Writing skills tasks (analytical paragraphs, thematic essays) demand evidence-based thematic analysis.
c11_hin_ar_cbse_03_012: Secondary themes (poverty, dedication) inform character-based inferences.  
c11_hin_ar_cbse_03_015: Secondary themes (humor, collaboration, society-artist relation) expand discussion scope.  
c12_hin_a_cbse_01_007: Chapter 3 reinforced theme vs. topic distinction.  
c12_hin_a_cbse_03_007: अगला तार्किक चरण: Secondary themes are the subsidiary ideas, motifs, or concerns that run parallel to the primary them... इस नोड की अवधारणाओं को सीधे उपयोग/विस्तारित करता है।  
c12_hin_a_cbse_08_007: अगला तार्किक चरण: Secondary themes are the underlying, complementary ideas in a literary work that support, contrast w... इस नोड की अवधारणाओं को सीधे उपयोग/विस्तारित करता है।  
c12_hin_a_cbse_10_007: Practice tracing themes across longer narratives prepares for this memoir's complexity.  
c12_hin_a_cbse_12_007: Third Class 11 instance consolidates the move from topic to theme statement.  
c12_hin_al_cbse_01_007: Class 11 work on "अपने साथ" thematic layers (disability, dignity, social gaze)  
c12_hin_al_cbse_03_007: Reinforces the skill across multiple chapters.  
c12_hin_ar_cbse_03_007: Class 11 secondary theme node provides the foundational skill of identifying subordinate themes; Class 12 deepens it with intertextual analysis across two poems.  
c12_hin_ar_cbse_07_007: Reinforcement across Chapter 3  
c12_hin_ar_cbse_08_007: Analysis of gendered domesticity in "Aao Bachcho" creates sensitivity to the mother's kitchen/lap duality in this poem.  
c12_hin_ar_cbse_11_007: Class 11 work on "Aao Milkar Bachayen" reinforces theme-clustering technique.  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
none

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_03_006 -> c11_hin_ar_cbse_03_007 -> c11_hin_ar_cbse_03_013

## THIS_FORMULA
N/A - conceptual

## FORMULA_VARIABLES
N/A

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
conceptual

## CROSS_SUBJECT
c11_history_colonialism | The chapter's depiction of children staging a play amid adult indifference mirrors how colonial-era Indian theatre groups operated with minimal resources, using improvisation as resistance — a historical parallel to the secondary theme of resourcefulness.
c11_sociology_socialization | The children's self-organized rehearsal space, role negotiation, and conflict resolution illustrate peer-group socialization outside adult supervision, directly illustrating the secondary theme of childhood agency and social dynamics.

## PREREQ_CONCEPT
Secure identification of the primary theme: "The narrative centres on the author's childhood experience of staging a play, capturing the passion, chaos, and collaborative labour of theatrical creation."

## PREREQ_BEFORE
Student must be able to state the primary theme in one precise sentence and list 5-6 major plot events in sequence.

## PREREQ_STUCK
Review node 006 (Primary Theme) and node 002 (Plot Structure) — specifically the distinction between "what happens" (plot) and "what it means" (theme).

## WORKED_EXAMPLE_1
PROBLEM: Identify and trace the secondary theme of "performance vs. reality" (प्रदर्शन बनाम वास्तविकता) in the chapter, using three textual moments where the boundary between acting and living blurs.
STEPS:
- Step 1: Recall the primary theme (staging a play) and ask: where do characters stop acting and start being themselves, or vice versa?
- Step 2: Locate Moment 1 — The boy playing the queen (रानी) refuses to wear the fake jewellery unless it's real, blurring costume demand with authentic desire.
- Step 3: Locate Moment 2 — The landlord's threat makes the "villain" role terrifyingly real; the child actor freezes not from stage fright but genuine fear.
- Step 4: Locate Moment 3 — The father silently helping dismantle the set after the failed show performs "indifference" but enacts care, reversing the performance/reality binary.
- Step 5: Synthesize: The theme reveals that for children, play is not escape from reality but a laboratory for testing real emotions — the secondary theme deepens the primary theme by showing the play's stakes were never "just a game."
REASONING: This works because it uses the primary theme (the play) as the anchor, then finds moments where the play's artificiality collapses into lived experience — the hallmark of this secondary theme.
ANSWER: The secondary theme of "performance vs. reality" operates through three key moments: (1) The queen's demand for real jewellery exposes how children invest props with authentic desire. (2) The landlord's intrusion turns theatrical villainy into genuine threat, collapsing the safe frame of play. (3) The father's silent dismantling performs detachment while enacting love, showing adults too perform roles. Together, these moments prove the play was a space where children rehearsed real life — making the secondary theme a profound commentary on the primary theme.

## WORKED_EXAMPLE_2
PROBLEM: The chapter mentions the narrator returning years later to find the village transformed — "pucca houses" replacing mud huts, the performance space gone. Explain how this frame narrative develops the secondary theme of "impermanence of collective memory" (सामूहिक स्मृति की क्षणभंगुरता).
STEPS:
- Step 1: Identify the frame structure — the chapter opens and closes with the adult narrator's return visit.
- Step 2: Contrast the past collective act (children building a world together) with the present individual act (narrator alone, unrecognised).
- Step 3: Note the physical erasure — the cot, the lanterns, the audience, the actors — all gone, leaving no trace.
- Step 4: Observe the narrator's final reflection: memory is the only archive; no monument marks their labour.
- Step 5: Connect to primary theme: The play's primary achievement was the doing, not the artefact — the secondary theme of impermanence elevates the primary theme from "staging a play" to "creating meaning that outlasts its material conditions."
REASONING: The frame narrative is not decorative; it is the structural vehicle for this secondary theme. By bookending the vibrant past with the erased present, the text makes impermanence palpable, not abstract.
ANSWER: The frame narrative develops the secondary theme of impermanence by juxtaposing the dense, sensory-rich past (mud huts, lantern light, collective labour) with the sterile, individual present (pucca houses, electric lights, solitary narrator). The physical space that held their collective memory is erased; the collaborators are dispersed or dead. The narrator's unrecognised return — "no one knew we made that play" — makes the theme visceral. This does not diminish the primary theme; it crowns it: the play's value was in the doing, the togetherness, the fleeting sovereignty of childhood — a meaning that survives precisely because it was never dependent on permanence.

## WORKED_EXAMPLE_3
PROBLEM: A board exam question asks: "How do the secondary themes of 'resourcefulness' and 'fragility of childhood alliances' interact in the episode where the lanterns are borrowed and the actor disappears? Write a structured analytical paragraph (150 words)."
STEPS:
- Step 1: Deconstruct the prompt — two secondary themes, one episode, interaction required, structured paragraph.
- Step 2: Recall the episode — narrator borrows lanterns from a friend who demands a role; separately, the king-actor vanishes before showtime.
- Step 3: Map Theme A (resourcefulness): Borrowing lanterns = creative problem-solving with scarce resources.
- Step 4: Map Theme B (fragility of alliances): Friend's conditional lending = alliance contingent on personal gain; actor's disappearance = commitment dissolved by fear.
- Step 5: Analyze interaction — Resourcefulness is undermined by fragility: the lanterns are secured (resourcefulness wins) but the actor is lost (fragility wins). The play proceeds with light but no king — a partial victory.
- Step 6: Draft paragraph using PEEL: Point (themes interact dialectically), Evidence (lantern bargain, actor's absence), Explanation (resourcefulness solves material gaps but cannot secure human commitment), Link (this tension defines the primary theme's central conflict: making theatre with unreliable resources and people).
REASONING: This models the exact board-exam skill: multi-theme synthesis, textual evidence, analytical explanation, and thematic linking — all in one paragraph.
ANSWER: The lantern episode reveals a dialectic between resourcefulness and fragile alliances. The narrator secures lighting through improvised bargaining — a friend lends lanterns only if cast — demonstrating children's creative negotiation with scarcity (resourcefulness). Simultaneously, the same transaction exposes how childhood alliances are transactional: the friend leverages need for personal desire, and the king-actor vanishes when stakes rise, showing commitment dissolves under pressure (fragility). Resourcefulness solves the material problem (light) but cannot solve the human problem (loyalty). The play proceeds illuminated but king-less — a potent metaphor for the primary theme: theatrical creation depends on both inventive making and fragile human cooperation. The secondary themes do not merely coexist; they clash, and their tension is the engine of the narrative's emotional truth.

## COMPETENCY_QUESTION_1
QUESTION: In "विव ओसक साथ छोटी लड़की," the rain that interrupts the performance functions at three levels: literal (plot device), symbolic (thematic), and structural (narrative). Explain each level with textual evidence, and evaluate which level contributes most to the chapter's emotional core.
COMPETENCY: Multi-level textual analysis with evaluative judgment
STEPS:
- Step 1: Identify the literal level — rain as weather event that halts the performance, scatters audience, ruins props.
- Step 2: Identify the symbolic level — rain as uncontrollable force disrupting human plans; nature's indifference to childhood dreams; cleansing/destructive duality.
- Step 3: Identify the structural level — rain as narrative climax that forces the play's collapse, triggers the father's appearance, and precipitates the frame narrative's return.
- Step 4: Evaluate — the structural level is most critical because it transforms rain from event to meaning-maker: it ends the play but births the memory.
ANSWER: Literally, the rain floods the makeshift stage, dissolves the cardboard crown, and sends the audience fleeing — a plot obstacle. Symbolically, it represents the universe's indifference to children's meticulous preparations; the "sky tearing open" mirrors the fragility of their constructed world. Structurally, it is the climax that collapses the performance, summons the father's silent witness, and necessitates the dismantling that the adult narrator later recalls. The structural level contributes most to the emotional core because it converts a weather event into a narrative hinge: without the rain, the play might have "succeeded" conventionally, but the father would not have witnessed their labour, the narrator would not have felt the "weight of that night," and the frame narrative's return would lack its elegiac power. The rain makes the memory.
DIFFICULTY: hard

## COMPETENCY_QUESTION_2
QUESTION: The chapter presents two contrasting adult figures: the threatening landlord and the silent father. Using the secondary theme of "adult authority as both obstacle and witness," argue whether the text ultimately validates or subverts adult authority. Support with three textual instances.
COMPETENCY: Thematic argumentation with dialectical reasoning
STEPS:
- Step 1: Define the secondary theme — adult authority operates in dual modes: obstructive (landlord) and affirming (father).
- Step 2: Instance 1 — Landlord threatens eviction, embodies institutional power crushing childhood autonomy; the children must hide, whisper, perform in fear.
- Step 3: Instance 2 — Father watches the failed performance, says nothing, but helps dismantle the set; his silence is not absence but a different mode of presence.
- Step 4: Instance 3 — The narrator's adult return: he is now the authority figure, yet he seeks validation from the past, reversing the power dynamic.
- Step 5: Argue — The text subverts adult authority by showing its externality (landlord) as hollow and its internality (father) as love. The narrator's final stance — "we made that play" — claims authorship that no adult authorised.
ANSWER: The text subverts adult authority by exposing its two faces as fundamentally unequal. The landlord's authority is external, performative, and fragile — he threatens but cannot stop the play; his power depends on property, not understanding. The father's authority is internal, silent, and enduring — he does not forbid, he witnesses; his help in dismantling is not control but participation. The ultimate subversion occurs in the frame: the adult narrator returns not as authority but as pilgrim to his own past. The landlord's house is gone; the father's presence remains in memory. The children's theatre was never authorised by adults — it was authorised by their own collective will. The secondary theme reveals that adult authority is either irrelevant (landlord) or retrospectively honoured (father), but never the source of the children's agency. The text validates childhood sovereignty.
DIFFICULTY: medium