## DEFINITION
Writing Skills based on the chapter "vejdkar" refers to the ability to construct structured, evidence-based analytical responses (short answers, long answers, and critical essays) that demonstrate comprehension of the narrative, character dynamics, thematic concerns, and literary devices used by the author Ñ".kk lkscrh, while adhering to CBSE Class 11 Hindi Aroh board examination answer-writing conventions.

## COGNITIVE_LEVEL
apply

## MASTERY_CRITERIA
The student can independently write a 150-200 word analytical answer using the PEEL structure (Point, Evidence, Explanation, Link) that integrates at least two textual evidences from "vejdkar" to support a thematic or character-based claim, with accurate Hindi terminology and board-appropriate presentation.

## SCOPE_BOUNDARY
This node covers writing analytical answers (लघु उत्तरीय, दीर्घ उत्तरीय, निबंधात्मक) specifically for Chapter 2 "vejdkar" including character sketches of fe;k¡ ulh#íhu, theme analysis of education and social hierarchy, and critical appreciation of irony/symbolism. It does NOT cover creative writing formats (story, letter, article) or other chapters from the textbook.

## WALKTHROUGH
Imagine you sit for your Class 11 Hindi board exam and see a 6-mark question: "fe;k¡ ulh#íhu dk charitra chitran kijiye" — your mind goes blank despite knowing the story. Start by asking: "What is the ONE central trait that defines this character?" In "vejdkar", it is his paradoxical wisdom — he appears foolish but exposes systemic flaws. Next, hunt for two concrete textual moments: his interaction with the student about "rkyhe dh rkyhe gh cM+h ph”k" and his refusal to name the clerk. Write your Point: "fe;k¡ ulh#íhu ek aisa shikshak hain jo samajik vicharon ka khandan karte hain." Evidence: Quote the "ph”k" dialogue. Explanation: Show how this reveals his philosophy. Link: Connect to the chapter's critique of rote education. This PEEL cycle is your scaffold for every literature answer.

## DIAGNOSTIC_QUESTION_1
"vejdkar" adhyay se sambandhit kisi bhi prashn ka uttar likhte samay PEEL vidhi ke 'P' (Point) chरण में क्या लिखना अनिवार्य है?

## DIAGNOSTIC_ANSWER_1
Point chरण में प्रश्न के सीधे उत्तर के रूप में एक स्पष्ट, वाद-विवाद योग्य कथन (claim) लिखना होता है जो आपके पूरे उत्तर का केंद्रीय तर्क (central argument) बने। उदाहरण: "fe;k¡ ulh#íhu paramparik shiksha paddhati ke virodhi hain." गलत उत्तर जैसे "fe;k¡ ulh#íhu ek achche adhyapak the" केवल तथ्य बताते हैं, तर्क नहीं; इससे पता चलता है कि छात्र 'विषय-वस्तु' और 'तर्क' में अंतर नहीं समझते।

## DIAGNOSTIC_QUESTION_2
"vejdkar" पाठ में fe;k¡ ulh#íhu ke "rkyhe dh rkyhe gh cM+h ph”k gksrh gS" kथन ka theme se kya sambandh hai? Apne shabdon mein samjhayein.

## DIAGNOSTIC_ANSWER_2
यह कथन पाठ के केंद्रीय विषय — "छोटी-छोटी सच्चाइयों/बातों की उपेक्षा से बड़ी विकृतियाँ जन्म लेती हैं" — को व्यक्त करता है। fe;k¡ ulh#íhu iske through batchit shiksha pranali mein chhote star par hone wali aniyamitaon (jaise clerk ka bhrashtachar) ko ujagar karte hain jo bade star par vyavastha ko khokhla karti hain. गलत उत्तर अक्सर केवल कथन का शाब्दिक अर्थ बताते हैं (जैसे "छोटी बात बड़ी हो जाती है") बिना पाठ के व्यंग्यात्मक उद्देश्य (satirical purpose) से जोड़े, जिससे पता चलता है कि छात्र प्रसंगगत व्याख्या (contextual interpretation) नहीं कर पा रहे।

## DIAGNOSTIC_QUESTION_3
Neche diye gaye kamjor uttar ko PEEL vidhi ka upyog karke sudharein:
**Prashn:** "fe;k¡ ulh#íhu ki bhasha shaili ki visheshta kya hai?"
**Kamjor uttar:** "fe;k¡ ulh#íhu bahut achhi bhasha bolte the. wo vyangya ka prayog karte the. unki bhasha saral thi."

## DIAGNOSTIC_ANSWER_3
**Sudharit uttar (PEEL):**
**P:** fe;k¡ ulh#íhu ki bhasha shaili vyangya-pra-dhan, samvad-shaili yukt aur lok-bhasha ke prayog se yukt hai jo unki samajik sameeksha ko dhaar deti hai.
**E:** Jaise clerk ke sawal par unka uttar — "rkyhe dh rkyhe gh cM+h ph”k gksrh gS" — ek lokokti shaili mein gahir vyangya sametey hue hai.
**E:** Ye saral shabdon mein vyavastha par prahar karta hai; 'ph”k' shabd ka dvigun prayog anushasan ki chhoti khamiyon ko bade dosh ke roop mein darshata hai.
**L:** Is prakar unki bhasha keval sanchar ka madhyam nahin, balki samajik yatharth ko ughadne ka hastra banti hai.
**Diagnosis:** Original uttar mein koi Point nahin, koi textual Evidence nahin, aur Explanation ke sthan par keval visheshana (adjectives) hain — ye batata hai ki chhatra 'kya' aur 'kyon' ke antar ko samajh nahin pa rahe.

## DIAGNOSTIC_QUESTION_4
"vejdkar" mein do alag-alag prasangon ka tulnatmak vishleshan kijiye jahan fe;k¡ ulh#íhu apne 'ukuukbZ' (teacher) roop mein dikhai dete hain, aur batayein ki ye dono prasang milkar unke charitra ka kaunsa ayam ujagar karte hain.

## DIAGNOSTIC_ANSWER_4
**Prasang 1:** Chhatra se "bYe" (knowledge) ke bare mein samvad jahan wo 'v[kckjuohl' (bureaucrat) aur 'uxhuklk”k' (oppressor) shabdon ka prayog karke shiksha tantra ki khami ugharte hain.
**Prasang 2:** Clerk se baat karte hue "rkyhe dh rkyhe gh cM+h ph”k" bolkar prashasanik bhrashtachar ki mool vichar karte hain.
**Vishleshan:** Dono prasang milkar dikhate hain ki fe;k¡ ulh#íhu keval ek adhyapak nahin, balki ek 'samajik sameekshak' (social critic) hain jo shiksha aur prashasan — dono kshetro mein sthalit sत्ता ki kamjoriyon ko 'chhoti baaton' ke madhyam se ujagar karte hain. **Galat uttar** aksar dono prasangon ko alag-alag lekhte hain bina unke beech ke thematic link (shiksha-prashasan nexus) ko pakde, jo batata hai ki chhatra 'tulnatmak vishleshan' (comparative analysis) ke sthan par 'saransh lekhan' (summary writing) kar rahe hain.

## DIAGNOSTIC_QUESTION_5
Kya "vejdkar" ke ant mein fe;k¡ ulh#íhu ka clerk ko "dgkor" (dacoit) kehna uchit thha? Pustak ke pramanon ke adhar par apni rai dein aur uska khandan bhi samavesh karein.

## DIAGNOSTIC_ANSWER_5
**Rai:** Haan, ye uchit thha kyunki clerk 'kanoon ke rakshak' hokar 'kanoon ka ullanghankarta' bana hua tha — usne 'pDdj dkV' (file manipulate) ki thi.
**Praman:** "fnekx eas pDdj dkV xbZ gS" aur fe;k¡ ulh#íhu ka uttar: "dgkor ;g lPph Hkh gS fd ---"
**Khandan (Counter-view):** Kuchh sameekshak maante hain ki ye 'vyaktigat aakrosh' (personal outburst) tha, 'nyayik nirnay' nahin, kyunki fe;k¡ ulh#íhu ne kanooni prakriya ka palan nahin kiya.
**Nirnay:** Lekhak ne is vyangya ke through 'vyavastha ke andar ke dgkor' ko 'bahar ke dgkor' se zyada khatarnak dikhaya hai, isliye ye kathn 'uchit' hai as a literary device.
**Galat uttar** keval 'haan' ya 'nahin' mein dete hain bina praman aur khandan ke — ye 'mulyanirdharan' (evaluation) ki kami dikhata hai jo board ke 6-mark prashnon ke liye anivarya hai.

## DIAGNOSTIC_QUESTION_6
"vejdkar" adhyay ke adhar par ek naya samvad (dialogue) likhiye jahan fe;k¡ ulh#íhu aaj ke digital yug ke ek 'online shikshak' ko 'rkyhe dh rkyhe gh cM+h ph”k' ka arth samjha rahe hain. Samvad mein kam-se-kam 4 aadhin (exchanges) hon.

## DIAGNOSTIC_ANSWER_6
**Apakshit samvad (sample):**
**Online Shikshak:** "Sir, maine assignment checking mein ek chhoti galti ki — deadline miss ho gayi."
**fe;k¡ ulh#íhu:** "Beta, rkyhe dh rkyhe gh cM+h ph”k gksrh gS. Ek missed deadline kal batch ke 50 bacchon ka schedule bigadegi."
**Online Shikshak:** "Lekin sir, system hi aisa hai — auto-grading, LMS errors..."
**fe;k¡ ulh#íhu:** "System bhi to insano ne banaya. Jab tum 'chhoti galti' maaf karte ho, to system bhi 'badi galti' seekh jata hai. Clerk ne bhi to 'pDdj dkV' karte hue yahi socha hoga."
**Online Shikshak:** (chup ho jata hai)
**fe;k¡ ulh#íhu:** "Yeh 'chup' hi sabse bada khatra hai. Bolna seekho — phir 'ph”k' kabhi 'pahad' nahin banegee."
**Manak:** Samvad mein pाठ ka mukhya theme (chhoti aniyamitaon ka bada parinam), character ki awaz (vyangya-yukt saral bhasha), aur aaj ke sandarbh ka anuprayog (transfer of learning) dikhai dena chahiye. **Kamjor samvad** keval shabdon ki nकल karega bina thematic depth ke.

## COMMON_MISCONCEPTION
Students believe that "writing skills based on the chapter" means memorising 3-4 readymade answers for predicted questions. In reality, CBSE Class 11 Hindi Aroh exams increasingly ask *unseen* analytical questions (e.g., "fe;k¡ ulh#íhu ke charitra mein 'vyangya' ki bhumika ka vishleshan kijiye") where no memorised answer fits. The misconception arises because Class 10 rewarded reproduction of NCERT exercise answers; Class 11 demands *transfer* — applying PEEL to any question stem using textual evidence. A concrete error: a student writes a perfect memorised character sketch but fails a 3-marker asking "fe;k¡ ulh#íhu ke 'ukuukbZ' shabd ka vyangyaarth spashth kijiye" because they never analysed the *word* as evidence.

## ON_FAILURE
1. **Diagnose the gap:** Ask the student to write a 60-word answer to "fe;k¡ ulh#íhu ne 'rkyhe' shabd ka dvigun prayog kyun kiya?" in 5 minutes. If they paraphrase the story instead of analysing the *word*, the gap is evidence-use.
2. **Micro-drill:** Give them 3 specific quotes from the chapter (e.g., "v[kckjuohl", "uxhuklk”k", "rkyhe dh rkyhe gh cM+h ph”k") and ask: "Har quote ke liye ek alag 'Point' likho jo theme 'shiksha mein vyavastha' ko support kare." Do this daily for 3 days.
3. **Scaffolded PEEL:** Provide a half-written PEEL frame (P and E filled) for a new question; student completes E and L. Gradually remove scaffolds.
4. **Peer calibration:** Pair the student with a peer who scores well; have them exchange and mark each other's PEEL answers using a 4-point checklist (Point clear? Evidence quoted? Explanation links to point? Link closes the loop?).

## BUILDS_ON
This node builds on the ability to identify textual evidence (from Comprehension node c11_hin_ar_cbse_02_012) and interpret thematic significance (from Critical Thinking node c11_hin_ar_cbse_02_013).

## LEADS_TO
This node enables the Speaking and Listening node (c11_hin_ar_cbse_02_015) where students must orally defend their written interpretations in a discussion.

## PREREQUISITE_NODE_IDS
c11_hin_ar_cbse_02_002, c11_hin_ar_cbse_02_004, c11_hin_ar_cbse_02_006, c11_hin_ar_cbse_02_008, c11_hin_ar_cbse_02_009, c11_hin_ar_cbse_02_012, c11_hin_ar_cbse_02_013, c11_hin_ar_cbse_02_010, c11_hin_ar_cbse_02_011

## PREREQUISITE_REASONS
c11_hin_ar_cbse_02_002: Plot knowledge provides the chronological framework to locate evidence accurately in answers.
c11_hin_ar_cbse_02_004: Protagonist analysis supplies the core character traits (paradoxical wisdom, satirical voice) that become 'Points' in PEEL answers.
c11_hin_ar_cbse_02_006: Primary theme (education-system critique) is the 'Link' destination for every analytical answer.
c11_hin_ar_cbse_02_008: Imagery/metaphor identification enables quoting specific literary devices as 'Evidence'.
c11_hin_ar_cbse_02_009: Irony/symbolism analysis provides the interpretive depth required for 'Explanation' step.
c11_hin_ar_cbse_02_012: Literal/inferential comprehension ensures the student can distinguish plot fact from thematic inference — critical for valid Evidence.
c11_hin_ar_cbse_02_013: Critical interpretation practice trains the 'Explanation' muscle: moving from *what* the text says to *what it means*.
c11_hin_ar_cbse_02_010: Writing tasks (character sketch, theme essay) demand precise, context-aware word choice.  
c11_hin_ar_cbse_02_011: Writing skills tasks (e.g., diary entry, letter) need correct indirect speech and verb usage.  

## FORWARD_NODE_IDS
c11_hin_ar_cbse_02_015, c12_hin_a_cbse_03_014, c12_hin_a_cbse_04_014, c12_hin_a_cbse_05_014, c12_hin_ar_cbse_02_014, c12_hin_ar_cbse_06_014

## FORWARD_REASONS
c11_hin_ar_cbse_02_015: Speaking/Listening discussion requires students to articulate and defend the same analytical claims they write, using identical PEEL logic in real-time dialogue.
c12_hin_a_cbse_03_014: Practice with different poets/devices builds transferable skill.  
c12_hin_a_cbse_04_014: Prior practice with evidence-based writing.  
c12_hin_a_cbse_05_014: अगला तार्किक चरण: Writing Skills based on the chapter refers to the ability to compose structured, evidence-based resp... इस नोड की अवधारणाओं को सीधे उपयोग/विस्तारित करता है।  
c12_hin_ar_cbse_02_014: Another Class 11 writing node reinforces creative response formats (diary, letter, paragraph).  
c12_hin_ar_cbse_06_014: Prior practice with symbolism in "Meera Ke Pad"  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
none

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_02_004 -> c11_hin_ar_cbse_02_014 -> c11_hin_ar_cbse_02_015

## THIS_FORMULA
PEEL Structure for Literature Answers: **P** = Point (1 sentence claim answering the question directly) | **E** = Evidence (1-2 brief textual quotes/references with location) | **E** = Explanation (2-3 sentences analysing how evidence proves the point, using literary terminology) | **L** = Link (1 sentence connecting back to question/theme/author's purpose)

## FORMULA_VARIABLES
P: Central argument (vad-vivad yogya kathan) | E1: Primary textual quote (mool praman) | E2: Secondary textual quote (sahayak praman) | Ex: Analytical commentary (vyakhya) using terms like vyangya, pratik, bhasha-shaili | L: Thematic closure (vishayik samapti)

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
linguistic

## CROSS_SUBJECT
c11_history_nationalism_in_india | Both require constructing evidence-based arguments about colonial/ post-colonial power structures — fe;k¡ ulh#íhu's critique of bureaucratic education mirrors historical analysis of Macaulay's minute.
c11_political_science_constitution | The chapter's "rkyhe dh rkyhe gh cM+h ph”k" parallels the constitutional principle that minor procedural violations (Article 14, 21) undermine democratic governance — same analytical lens: small breach, systemic consequence.

## PREREQ_CONCEPT
Student must understand that board exam literature answers are *arguments*, not summaries — every sentence must advance a claim supported by text.

## PREREQ_BEFORE
Student should be able to locate any event/quote in "vejdkar" within 30 seconds (page/paragraph awareness) and name the chapter's three core themes: (1) critique of rote education, (2) bureaucratic corruption, (3) power of satirical language.

## PREREQ_STUCK
If stuck, review c11_hin_ar_cbse_02_013 (Critical Thinking) — specifically the worked example on "vyangya as a tool for social critique" — and re-read the clerk-fe;k¡ ulh#íhu dialogue (pages 24-26) with a highlighter marking every ironic statement.

## WORKED_EXAMPLE_1
PROBLEM: Write a 120-word answer to: "fe;k¡ ulh#íhu ke charitra mein 'vyangya' (satire) ki bhumika ka vishleshan kijiye." (Analyse the role of satire in fe;k¡ ulh#íhu's character.)
STEPS:
- Step 1: Identify the question demand — "vyangya ki bhumika" means how satire *functions* in his character, not just "he uses satire". This requires functional analysis.
- Step 2: Select two precise textual moments where his satire performs a specific function: (a) "v[kckjuohl / uxhuklk”k" naming of clerk — satire as diagnostic tool exposing systemic rot; (b) "rkyhe dh rkyhe gh cM+h ph”k" — satire as philosophical principle revealing cumulative corruption.
- Step 3: Draft Point: "fe;k¡ ulh#íhu ka vyangya keval hasya nahin, balki samajik sameeksha ka hastra hai jo vyavastha ke andar chhupe doshon ko ughadta hai."
- Step 4: Insert Evidence E1: Clerk-samvad mein "v[kckjuohl, uxhuklk”k, ehuklk”k" ki shreni. Explanation: Ye shabd-mala clerk ke vyaktigat aacharan ko sansthagat dosh (institutional flaw) mein badal deti hai — vyangya yahan 'naming and shaming' ka kaam karta hai.
- Step 5: Insert Evidence E2: "rkyhe dh rkyhe gh cM+h ph”k" dvaara. Explanation: Yahan vyangya ek 'siddhant' (principle) banta hai — chhoti aniyamitaon ka bada parinam — jo lekhak ka mukhya sandesh hai.
- Step 6: Link: "Is prakar vyangya fe;k¡ ulh#íhu ko keval ek adhyapak se uthakar ek 'samajik drashta' (social visionary) bana deta hai."
REASONING: This answer scores full marks because each PEEL component is distinct: P is debatable (not factual), E quotes exact words, Ex uses literary terms (naming-and-shaming, principle), L elevates to author's purpose. The 6-step process prevents the common error of merging Explanation into Evidence.
ANSWER: fe;k¡ ulh#íhu ka vyangya keval hasya nahin, balki samajik sameeksha ka hastra hai jo vyavastha ke andar chhupe doshon ko ughadta hai. Clerk-samvad mein "v[kckjuohl, uxhuklk”k, ehuklk”k" ki shreni clerk ke vyaktigat aacharan ko sansthagat dosh mein badal deti hai — vyangya yahan 'naming and shaming' ka kaam karta hai. Dusara, "rkyhe dh rkyhe gh cM+h ph”k" dvaara vyangya ek 'siddhant' banta hai: chhoti aniyamitaon ka bada parinam, jo lekhak ka mukhya sandesh hai. Is prakar vyangya fe;k¡ ulh#íhu ko keval ek adhyapak se uthakar ek 'samajik drashta' bana deta hai.

## WORKED_EXAMPLE_2
PROBLEM: Improve this weak 6-mark answer: "Prashn: 'vejdkar' mein shiksha pranali ki aalochana kaise ki gayi hai? Uttar: Is kahani mein shiksha pranali bahut kharab dikhai gayi hai. fe;k¡ ulh#íhu ek acche teacher the jo bachhon ko sahi seekhate the. Clerk bhrasht the. Lekhak ne vyangya ka prayog kiya hai."
STEPS:
- Step 1: Diagnose weaknesses — (a) No Point (just plot summary), (b) Zero textual Evidence, (c) "bahut kharab" is vague evaluation, (d) No literary terminology, (e) No Link to author's intent.
- Step 2: Formulate a sharp Point addressing "kaise" (how): "Ñ".kk lkscrh ne 'vejdkar' mein shiksha pranali ki aalochana fe;k¡ ulh#íhu ke vyangya-yukt samvadon ke madhyam se ki hai jo 'ratta-maran' (rote learning) aur 'babu-sanskriti' (clerical culture) ke gathjod ko ugharte hain."
- Step 3: Embed Evidence 1 from classroom scene: "fe;k¡ ulh#íhu ka chhatra se samvad — 'ge crZu èkksuk u lh[krs / ge Hkêòh cukuk u lh[krs' — ratta-maran ke khilaf mukti-kami shiksha ka pratik hai."
- Step 4: Explain Evidence 1: "Yahan 'crZu' (fear), 'Hkêòh' (violence), 'vk¡p' (bribe) ki triveni colonial shiksha ke teen stambh the; unka nishedh aaj bhi relevant hai."
- Step 5: Embed Evidence 2 from clerk scene: "Clerk ka 'pDdj dkVna' (file manipulation) aur fe;k¡ ulh#íhu ka 'dgkor' kehna — shiksha aur prashasan ke bhrasht gathjod ka pratyaksh praman."
- Step 6: Link to author's purpose: "Lekhak is dvigun aalochana (classroom + office) ke through dikhate hain ki shiksha jab 'seva' (service) ke sthan par 'naukri' (job) banti hai, to vyavastha 'dgkor' ban jati hai."
REASONING: The transformation follows a strict audit: every vague claim → specific textual anchor; every adjective → literary term; every plot point → analytical function. This mirrors the examiner's marking rubric: Content (2) + Expression (2) + Structure (2).
ANSWER: Ñ".kk lkscrh ne 'vejdkar' mein shiksha pranali ki aalochana fe;k¡ ulh#íhu ke vyangya-yukt samvadon ke madhyam se ki hai jo 'ratta-maran' aur 'babu-sanskriti' ke gathjod ko ugharte hain. fe;k¡ ulh#íhu ka chhatra se samvad — "ge crZu èkksuk u lh[krs / ge Hkêòh cukuk u lh[krs" — ratta-maran ke khilaf mukti-kami shiksha ka pratik hai; yahan 'crZu', 'Hkêòh', 'vk¡p' ki triveni colonial shiksha ke teen stambh the. Clerk ka 'pDdj dkVna' aur fe;k¡ ulh#íhu ka 'dgkor' kehna shiksha-prashasan ke bhrasht gathjod ka praman hai. Lekhak is dvigun aalochana ke through dikhate hain ki shiksha jab 'seva' ke sthan par 'naukri' banti hai, to vyavastha 'dgkor' ban jati hai.

## WORKED_EXAMPLE_3
PROBLEM: A new competency-based question: "fe;k¡ ulh#íhu ka kathan 'fe;k¡] dgha v[kckjuohl rks ugha gks\ ;g rks [kksft;ksa dh [kqjkI+kQkr gS' — iska sandarbh, arth aur pाठ ke mukhya theme se sambandh spashth kijiye." (Context, meaning, and thematic link of this statement.)
STEPS:
- Step 1: Deconstruct the question into three mandatory sub-answers: Sandarbh (context), Arth (meaning), Theme-sambandh (thematic link) — missing any loses marks.
- Step 2: Locate Sandarbh precisely: ye samvad fe;k¡ ulh#íhu aur uske chhatra ke beech hota hai jab chhatra puchhta hai "D;k iwNuk pkgrs gSa!" aur fe;k¡ ulh#íhu jawab dete hain — ye 'shiksha ke uddeshya' par charcha ka hissa hai.
- Step 3: Determine Arth using textual clues: "v[kckjuohl" = bureaucrat/clerical mindset; "[kksft;ksa dh [kqjkI+kQkr" = witness/observer of events. fe;k¡ ulh#íhu kahte hain: main kewal babu nahin jo file chalata hai, main ghatnaon ka sakshi hoon jo unka sach batata hai.
- Step 4: Connect to Theme 1 (Education critique): Ye kathan 'shikshak as bureaucrat' vs 'shikshak as conscience-keeper' ka antar spashth karta hai — pranali chahte hain ki teacher bhi babu ban jaye, fe;k¡ ulh#íhu iska virodh karte hain.
- Step 5: Connect to Theme 2 (Language as resistance): "[kksft;ksa dh [kqjkI+kQkr" hone ke nate wo 'bhasha' ka prayog karte hain sach bolne ke liye — "v[kckjuohl" shabd ka chayan hi vyangya hai.
- Step 6: Synthesise into a structured 100-word answer with clear sub-headings implied by flow.
REASONING: Competency questions test *disaggregation* — can the student separate context, meaning, theme? The 6-step forces this separation. Most students merge context+meaning, losing 2 marks. The thematic link must cite *specific* themes from c11_hin_ar_cbse_02_006/007, not generic "education".
ANSWER: **Sandarbh:** Ye samvad fe;k¡ ulh#íhu aur chhatra ke beech shiksha ke uddeshya par charcha ke dauran hota hai jab chhatra unki bhumika par prashn uthata hai. **Arth:** fe;k¡ ulh#íhu apne ko 'v[kckjuohl' (babugiri karne wala) nahin, balki '[kksft;ksa dh [kqjkI+kQkr' (ghatnaon ka sakshi/sameekshak) batate hain — jo keval aadesh maanta hai uske virodh jo sach dekhta-bolata hai. **Theme-sambandh:** (1) Shiksha pranali ki aalochana: pranali teacher ko 'v[kckjuohl' banana chahti hai; fe;k¡ ulh#íhu '[kqjkI+kQkr' bankar iska prativad karte hain. (2) Bhasha ka prativadi shakti: unka 'v[kckjuohl' shabd chayan hi vyangya hai jo sansthagat bhrashtachar ko naam deta hai. Is prakar ye kathan adhyay ke donon mukhya themes — shiksha mein swatantrata aur vyangya dwara samajik sameeksha — ko ek saath bandhta hai.

## COMPETENCY_QUESTION_1
QUESTION: "vejdkar" adhyay ke adhar par ek aisa prashn nirmit kijiye jo kisi chhatra ki 'analytical thinking' (vishleshanatmak soch) ka mulyankan kare, uska 'model answer' PEEL format mein likhiye, aur batayein ki is prashn mein 'remembering' (yad karna) kyun kaafi nahin hoga.
COMPETENCY: Question Design & Metacognitive Awareness (prashn nirman aur metacognitive jagrukta)
STEPS:
- Step 1: Identify a concept in the chapter that requires analysis, not recall — e.g., the *function* of the "tekr" (three grades) metaphor in the poem fe;k¡ ulh#íhu recites.
- Step 2: Frame a question that forces *comparison* and *interpretation*: "fe;k¡ ulh#íhu dwara sunayi gayi kavita mein 'tekr' (d{kk) ke roopak ka vishleshan kijiye — ye teen tekrein (u dPph, u iDdh, u nwljh) aaj ke shiksha paridrishya par kya tippani karti hain?"
- Step 3: Write Model Answer PEEL: P = Ye roopak shiksha ko 'sthanikrit' (spatialised) karke dikhata hai ki gyan ke teen star (physical, mental, spiritual) kaise upalabdh hain par 'nwljh' (higher consciousness) tak pahunchna vyavastha dwara bandh hai. E1 = "u dPph esa cSBk / u cSBk og iDdh esa / u nwljh esa" — teen sthitiyaan. Ex = 'dPph' = sharirik anushasan, 'iDdh' = mansik bandhan, 'nwljh' = atma-mukti; clerk/shiksha-tantra keval pehle do tak simit rakhna chahte hain. L = Isliye ye kavita keval kavita nahin, 'curriculum critique' hai.
- Step 4: Explain why remembering fails: Chhatra kavita yaad karke bhi ye nahin bata sakte ki 'nwljh' ka matlab yahan 'spiritual grade' nahin, 'critical consciousness' (Freire) hai — ye 'apply/analyse' mangta hai, 'remember' nahin.
ANSWER: **Prashn:** "fe;k¡ ulh#íhu dwara sunayi gayi kavita mein 'tekr' ke roopak ka vishleshan kijiye — ye teen tekrein aaj ke shiksha paridrishya par kya tippani karti hain?" **Model Answer:** Ye roopak shiksha ko 'sthanikrit' karke dikhata hai ki gyan ke teen star kaise upalabdh hain par 'nwljh' tak pahunchna vyavastha dwara bandh hai. "u dPph esa cSBk / u cSBk og iDdh esa / u nwljh esa" teen sthitiyaan hain: 'dPph' = sharirik anushasan, 'iDdh' = mansik bandhan, 'nwljh' = atma-mukti; clerk/shiksha-tantra keval pehle do tak simit rakhna chahte hain. Isliye ye kavita keval kavita nahin, 'curriculum critique' hai. **Reason:** Remembering the poem lines is insufficient because the question demands mapping the metaphor to *contemporary educational structure* (hidden curriculum, institutional control) — a transfer task requiring analysis.
DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: Do alag-alag board exam questions diye gaye hain. Un dono ke liye *ek hi* textual evidence (fe;k¡ ulh#íhu ka kathan: "rkyhe dh rkyhe gh cM+h ph”k gksrh gS") ka upyog karke do alag-alag PEEL answers likhiye, dikhaye ki ek hi evidence kaise do alag claims ko support kar sakta hai.
**Prashn A:** "fe;k¡ ulh#íhu ke darshanik drishtikon ka vishleshan kijiye."
**Prashn B:** "Lekhak ne vyangya ka prayog karke vyavastha ki aalochana kaise ki hai?"
COMPETENCY: Evidence Flexibility & Argumentative Versatility (praman ki lachilta aur tarkik vividhata)
STEPS:
- Step 1: For Prashn A (Philosophical viewpoint), frame Point: "fe;k¡ ulh#íhu ka darshan 'anuvritti' (cumulative causality) par adharit hai — chhoti naitik samjhauton ka bada samajik patan."
- Step 2: Use Evidence: "rkyhe dh rkyhe gh cM+h ph”k". Explanation: Ye 'butterfly effect' ka lok-roop hai; ek clerk ki ek file manipulation (chhoti ph”k) poore tantra ko 'dgkor' bana deti hai (badi ph”k).
- Step 3: Link: "Is darshan ke anusar zimmedari 'system' ki nahin, 'vyakti' ki chhoti-kirdaron mein hai."
- Step 4: For Prashn B (Satire/System critique), frame Point: "Lekhak vyangya ka upyog 'babugiri' ke 'normalisation' (samanyikaran) ko todne ke liye karte hain."
- Step 5: Same Evidence: "rkyhe dh rkyhe gh cM+h ph”k". Explanation: Yahan 'ph”k' shabd ka dvigun prayog — pehli baar 'chhoti galti' ke roop mein, dusri baar 'bade dosh' ke roop mein — clerk ke bhasha-manovigyan (language psychology) ko ugharta hai: wo apne kaam ko 'chhota' batake bade apradh ko chhupata hai.
- Step 6: Link: "Vyangya yahan 'euphemism' (mridu-bhasha) ka khandan karta hai jo vyavastha ko bachata hai."
ANSWER: **Prashn A Uttar:** fe;k¡ ulh#íhu ka darshan 'anuvritti' par adharit hai — chhoti naitik samjhauton ka bada samajik patan. "rkyhe dh rkyhe gh cM+h ph”k" ye 'butterfly effect' ka lok-roop hai; ek clerk ki ek file manipulation (chhoti ph”k) poore tantra ko 'dgkor' bana deti hai. Is darshan ke anusar zimmedari 'system' ki nahin, 'vyakti' ki chhoti-kirdaron mein hai. **Prashn B Uttar:** Lekhak vyangya ka upyog 'babugiri' ke 'normalisation' ko todne ke liye karte hain. "rkyhe dh rkyhe gh cM+h ph”k" mein 'ph”k' ka dvigun prayog clerk ke bhasha-manovigyan ko ugharta hai: pehli 'ph”k' = uski 'chhoti galti' ki sawikriti, dusri 'ph”k' = asli 'bada apradh'; vyangya is 'euphemism' ko todkar vyavastha ko nanga karta hai. **Key Insight:** Ek hi evidence, do alag 'Point' ke saath, do alag 'Explanation' paths par chalta hai — yahi 'evidence flexibility' board distinction dilati hai.
DIFFICULTY: hard