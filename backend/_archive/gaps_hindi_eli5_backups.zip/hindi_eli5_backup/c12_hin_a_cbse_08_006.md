## DEFINITION
The primary theme of Kabir's poetry in this chapter is **Nirguna Bhakti** — devotion to a formless, attribute-less Divine that transcends religious rituals, caste hierarchies, and scriptural literalism. The core message is that true spirituality lies in direct, personal experience of the Divine within oneself (*antar*), not in external practices like pilgrimage, idol worship, or rote recitation.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student can identify the central theme of Nirguna Bhakti across all three padas, cite specific lines as evidence, explain how Kabir uses contrast (ritual vs. inner realization) to convey the message, and articulate the theme in a structured board-exam answer using the PEEL method (Point, Evidence, Explanation, Link).

## SCOPE_BOUNDARY
This node covers **only** the primary theme and message of the three Kabir padas in Chapter 8 (Antra). It does NOT cover secondary themes (node 007), literary devices (nodes 008, 009), vocabulary (node 010), or grammar (node 011). It builds on plot/narrative (node 002), setting (node 003), and character analysis (nodes 004, 005) already completed.

## WALKTHROUGH
Imagine you're asked in the board exam: "Kabir's poetry rejects external rituals. Explain with reference to the prescribed padas." Most students panic and start retelling the poem. Instead, **start by asking: "What is the ONE big idea that connects all three padas?"** Read the first pada aloud — notice the contrast between "going to Kashi" and "finding the Divine at home." Mark words like *mandir*, *masjid*, *puja*, *namaz* vs *antar*, *ghat*, *surat*. That contrast IS the theme. Now trace it in pada 2 (yogi's outward austerities vs inner emptiness) and pada 3 (scholar's book knowledge vs lover's direct experience). The key insight: **Kabir doesn't just criticize rituals; he offers an alternative path — *surat shabd yog* (inner listening).** Structure your answer: State theme → Quote contrast → Explain significance → Link to Nirguna tradition.

## DIAGNOSTIC_QUESTION_1
What is the central theme of Kabir's poetry as presented in the three padas of Chapter 8? State it in one precise sentence using the term from the Nirguna tradition.

## DIAGNOSTIC_ANSWER_1
The central theme is **Nirguna Bhakti** — devotion to a formless, attribute-less Divine realized through inner experience (*antar*), rejecting external rituals, caste, and scriptural authority.  
**Wrong answer reveals:** If a student writes "Bhakti" or "devotion to God" without "Nirguna" or "formless," they confuse Kabir with Saguna poets like Tulsidas or Surdas. If they write "social reform," they mistake the *consequence* for the *core spiritual message*. Kabir's primary aim is metaphysical, not sociological.

## DIAGNOSTIC_QUESTION_2
In Pada 1, Kabir contrasts "going to Kashi" with "finding Ram in the heart." Explain in your own words WHY this contrast is the structural key to the primary theme. Do not just translate the lines.

## DIAGNOSTIC_ANSWER_2
The contrast structures the poem as **rejection → affirmation**: the first half enumerates what the Divine is NOT (not in Kashi, not in Kaaba, not in idol, not in Quran), the second half reveals where the Divine IS (in the heart, in the *surat*, in the *shabd*). This binary mirrors the Nirguna logic: *neti neti* (not this, not that) leading to direct realization.  
**Wrong answer reveals:** If the student merely lists the places mentioned (Kashi, Kaaba, temple, mosque), they treat the poem as a geography quiz. If they say "Kabir says God is everywhere," they miss the specific *interiority* — Kabir says God is in the *seeker's own body* (*dehi*), not diffusely "everywhere."

## DIAGNOSTIC_QUESTION_3
Apply the PEEL method to write a 4-sentence answer for: "How does Pada 2 use the figure of the Yogi to convey the primary theme?" Your Point must name the theme; Evidence must reference a specific image; Explanation must connect image to theme; Link must connect to Nirguna tradition.

## DIAGNOSTIC_ANSWER_3
**Point:** Pada 2 reinforces the Nirguna theme that external austerities cannot yield inner realization.  
**Evidence:** The Yogi "wears matted locks, smears ash, blows the horn" (*jata dhari, bhasm lagave, singi bajave*) yet "the inner knot remains untied" (*antargath na khule*).  
**Explanation:** The outward symbols (jata, bhasm, singi) are ritual substitutes for the real work — untying the *antargath* (inner knot of ignorance) through *surat shabd yog*. The body becomes a theater of performance, not a site of transformation.  
**Link:** This mirrors Kabir's consistent Nirguna stance: the body is the *only* temple, but only when the *surat* (attention) turns inward, not when it decorates the exterior.  
**Wrong answer reveals:** If Evidence quotes "Yogi" generically without the specific symbols, the answer lacks textual grounding. If Explanation says "Yogi is fake," it reduces Kabir's metaphysical critique to moral judgment.

## DIAGNOSTIC_QUESTION_4
Compare how Pada 1 and Pada 3 treat "knowledge" (*gyan*). Pada 1 targets ritual knowledge (pilgrimage, scripture); Pada 3 targets scholarly knowledge (*pandit*, *veda*, *kateb*). Analyze the shift in target and its significance for the primary theme.

## DIAGNOSTIC_ANSWER_4
**Shift:** Pada 1 attacks *popular* ritual knowledge (Hindu/Muslim practices accessible to laypeople); Pada 3 attacks *elite* textual knowledge (Sanskrit/Arabic scholarship of pandits/maulvis).  
**Significance:** Kabir's critique is totalizing — **no external knowledge system**, whether folk or scholarly, mediates the Divine. The "pandit" reading Vedas and "maulvi" reading Kateb are equally distant from *anubhav* (direct experience) as the pilgrim bathing in Ganga. The primary theme demands *unlearning* all borrowed knowledge to make space for *sv-anubhav* (self-experience).  
**Wrong answer reveals:** If the student says "both criticize religion," they miss the class/epistemology dimension. If they say "Pada 3 is harsher," they impose a tone judgment not in the text — both use identical logical structure: *external authority → false → internal authority → true*.

## DIAGNOSTIC_QUESTION_5
Evaluate this student claim: "Kabir's primary message is Hindu-Muslim unity." Defend or refute using evidence from the three padas. Your evaluation must distinguish between *theme* and *social implication*.

## DIAGNOSTIC_ANSWER_5
**Refute.** The claim confuses a **social implication** with the **primary theme**.  
**Evidence:**  
- Pada 1: Rejects *both* Kashi (Hindu) and Kaaba (Muslim) as sites of the Divine — not to reconcile them, but to declare both irrelevant to *antar*.  
- Pada 2: The Yogi is neither Hindu nor Muslim; he represents *renunciant tradition* — Kabir rejects his path too.  
- Pada 3: Pandit (Hindu) and Maulvi (Muslim) are paired as *equal failures* of textual authority.  
**Reasoning:** Kabir's unity is **negative** (shared error) not positive (shared truth). The primary theme is *metaphysical* (Nirguna realization), not *sociological* (communal harmony). Communal harmony is a *byproduct* of realizing the same formless Divine within all bodies — but the poems never say "Hindus and Muslims should unite." They say "Stop looking outside; look within."  
**Wrong answer reveals:** If the student cites "Kabir tried to unite Hindus and Muslims" as the *main message*, they import modern nationalist readings into a 15th-century mystic. Board examiners penalize this as "historical anachronism."

## DIAGNOSTIC_QUESTION_6
Create a 4-line poem in Hindi (or English) that captures Kabir's primary theme using the *same contrast structure* (rejection of external → affirmation of internal). Use at least two images from the prescribed padas.

## DIAGNOSTIC_ANSWER_6
**Example (Hindi):**  
मंदिर-मस्जिद छोड़ चले, वेद-कुरान धरि हाथ,  
अंतर गगन में ढूंढिए, जहाँ बसे दयानिधान।  
जोगी-जतन सब व्यर्थ हुए, जब तक न खुली गाँठ,  
सुरत शब्द की डोर से, बंधे परम तत्व साथ।  

**Criteria for good answer:**  
1. Uses rejection→affirmation structure  
2. References ≥2 images (e.g., mandir/masjid, ved/kuran, jogi/jatan, surat/shabd, ganth)  
3. Centers *antar* (inner) as the true locus  
4. Avoids moralizing ("be good") — stays metaphysical  
**Poor answer reveals:** If the poem says "God is in everyone, so love all," it collapses Kabir's rigorous *surat shabd yog* into generic humanism. If it keeps only rejection ("temples are fake") without affirmation ("heart is real"), it misses the constructive core of Nirguna Bhakti.

## COMMON_MISCONCEPTION
**Misconception:** "Kabir's main message is that all religions are the same / Hindu-Muslim unity / social equality."  
**Why students make this error:**  
1. **Textbook framing:** Many school editions introduce Kabir as "a saint who preached Hindu-Muslim unity" in the *Before You Read* section, priming students to read the poems through that lens.  
2. **Exam pattern memory:** Past board questions often asked "How does Kabir promote communal harmony?" — students memorize this as *the* theme.  
3. **Surface reading:** The poems explicitly name Hindu/Muslim symbols (Kashi/Kaaba, Pandit/Maulvi, Ram/Rahim), so students latch onto the *visible* contrast rather than the *structural* logic (external vs internal).  
**Why it's wrong:** Kabir's Nirguna Bhakti is **radically iconoclastic** — he rejects *both* traditions equally because *both* locate the Divine outside the self. "Unity" implies two valid paths converging; Kabir says *neither path is valid*. The primary theme is **epistemological** (how we know the Divine), not **sociological** (how communities relate). Board marking schemes explicitly require "Nirguna Bhakti / formless Divine / inner realization" as the theme; "communal harmony" fetches partial credit at best.

## ON_FAILURE
**Step 1:** Ask the student to re-read Pada 1 and underline every word referring to *external* practices (Kashi, Kaaba, mandir, masjid, puja, namaz, jog, jugat). Circle every word referring to *internal* reality (antar, ghat, dehi, surat, shabd).  
**Step 2:** Have them write two columns: "What Kabir Rejects" vs "What Kabir Affirms." Force them to see the pattern: *every* external practice is rejected; *only* internal realization is affirmed.  
**Step 3:** Give them this prompt: "If Kabir wanted Hindu-Muslim unity, he would say 'Both temple and mosque lead to God.' Find the line where he says that." (They won't find it — he says the opposite.)  
**Step 4:** Re-attempt Diagnostic Question 5. If they still write "unity," assign re-reading of **c11_hin_ar_cbse_08_006** (Class 11 Kabir theme node) with focus on the *neti neti* structure.

## BUILDS_ON
Builds on **Character Analysis: Protagonist (c12_hin_a_cbse_08_004)** where Kabir's persona as the *nirguna sadhak* was established — his voice, stance, and rhetorical strategies.

## LEADS_TO
Enables **Theme: Secondary Themes (c12_hin_a_cbse_08_007)** where social critique, guru-shishya tradition, and language politics are explored as *extensions* of the primary Nirguna framework.

## PREREQUISITE_NODE_IDS
c12_hin_a_cbse_08_002, c12_hin_a_cbse_08_003, c12_hin_a_cbse_08_004, c12_hin_a_cbse_08_005, c11_hin_ar_cbse_08_006, c12_hin_a_cbse_08_001

## PREREQUISITE_REASONS
c12_hin_a_cbse_08_002: Plot/narrative structure of the three padas provides the textual sequence needed to trace theme development.  
c12_hin_a_cbse_08_003: Setting (Kashi, Kaaba, yogic space, scholarly space) maps the *external* locations Kabir rejects.  
c12_hin_a_cbse_08_004: Kabir's persona as the speaking "I" (*main*) is the thematic anchor — the theme is *his* realization.  
c12_hin_a_cbse_08_005: Supporting figures (pandit, maulvi, yogi, pilgrim) are the foils against which the theme is defined.  
c11_hin_ar_cbse_08_006: Class 11 Kabir theme node establishes the Nirguna framework; Class 12 deepens it with textual evidence.
c12_hin_a_cbse_08_001: Primary theme (Nirgun Bhakti) is defined by the historical movement.  

## FORWARD_NODE_IDS
c12_hin_a_cbse_08_007, c12_hin_a_cbse_08_008, c12_hin_a_cbse_08_009, c12_hin_a_cbse_08_013, c12_hin_a_cbse_08_014

## FORWARD_REASONS
c12_hin_a_cbse_08_007: Secondary themes (social equality, guru, language) only make sense as *implications* of the primary Nirguna theme.  
c12_hin_a_cbse_08_008: Imagery/metaphor (jata, bhasm, singi, ganth, surat, shabd) are the *vehicles* of the primary theme.  
c12_hin_a_cbse_08_009: Irony/symbolism (e.g., the scholar as ignorant) operate *within* the primary theme's logic.  
c12_hin_a_cbse_08_013: Critical thinking requires the primary theme as the *interpretive lens* for analysis questions.
c12_hin_a_cbse_08_014: Establishes the primary theme (virah bhakti) which is the ultimate Link target in every paragraph.  

## CROSS_SUBJECT_PREREQS
c11_hin_ar_cbse_08_006, c11_hin_ar_cbse_09_006, c11_hin_ar_cbse_10_006
## CROSS_SUBJECT_REASONS
c11_hin_ar_cbse_08_006: Direct predecessor — same author, same Nirguna framework, simpler padas; this node advances to more complex textual evidence.  
c11_hin_ar_cbse_09_006: Dadu Dayal (next Nirguna poet in Class 11) uses identical *antargath/surat* vocabulary — shows tradition continuity.  
c11_hin_ar_cbse_10_006: Raidas (Nirguna saint, different caste) — demonstrates how the *same primary theme* manifests across social locations.

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_08_006 -> c12_hin_a_cbse_08_006 -> c12_hin_a_cbse_08_007 (Nirguna theme foundation → Kabir primary theme with textual evidence → secondary themes as extensions)

## THIS_FORMULA
**Theme Identification Formula for Nirguna Poetry:**  
`Primary Theme = (Rejection Set: All External Mediators) → (Affirmation Set: Internal Direct Realization)`  
Where:  
- Rejection Set = {rituals, pilgrimages, scriptures, scholars, yogic symbols, caste markers}  
- Affirmation Set = {antar, ghat, dehi, surat, shabd, anubhav, guru-kripa}  
- Logical Operator = *neti neti* (negation of externals) → *iti iti* (affirmation of internal)

## FORMULA_VARIABLES
Rejection Set: All nouns/verbs denoting outward religious practice (mandir, masjid, puja, namaz, tirath, ved, kateb, jata, bhasm, singi, pandit, maulvi, yogi)  
Affirmation Set: All nouns/verbs denoting inward spiritual practice (antar, ghat, dehi, surat, shabd, anubhav, ganth-kholna, guru-kripa)  
neti neti: Upanishadic negation logic — "not this, not this" — used by Kabir to clear external falsehoods  
iti iti: Positive affirmation — "this is it, this is it" — the inner reality left after negation

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
analytical

## CROSS_SUBJECT
N/A | Kabir's Nirguna theme reflects the 15th-century North Indian bhakti movement's shift from temple-centric Saguna to interiorized devotion — historical context for why "external vs internal" was a live debate.  
 N/A | The *neti neti* structure mirrors Advaita Vedanta's *via negativa* but Kabir democratizes it — no Sanskrit, no renunciation required, only *surat* in the householder's body.  
 N/A | Kabir's rejection of pandit/maulvi authority prefigures modern "disenchantment" (Weber) — charismatic authority (Kabir's *anubhav*) vs traditional authority (Veda/Kateb).
## PREREQ_CONCEPT
Understanding of **Nirguna vs Saguna Bhakti distinction** — specifically that Nirguna denies *all* form/attribute (including scripture, idol, pilgrimage) as mediators.

## PREREQ_BEFORE
Student must be able to: (1) Define Nirguna Bhakti in their own words, (2) Identify the speaking "I" in Kabir's padas as a *nirguna sadhak*, not a generic devotee, (3) Explain *neti neti* as a logical structure.

## PREREQ_STUCK
If stuck on "What is Nirguna?", revisit **c11_hin_ar_cbse_08_006** (Class 11 Kabir theme) and **c12_history_03_bhakti_sufi** (historical context of Nirguna movement).

## WORKED_EXAMPLE_1
PROBLEM: Board Exam Question (3 marks): "Identify the primary theme of Kabir's poetry in the prescribed padas. Support your answer with one example from each pada."  
STEPS:  
- Step 1: State the theme in one precise sentence using textbook terminology: "The primary theme is Nirguna Bhakti — realization of the formless Divine through inner experience (*surat shabd yog*), rejecting all external mediators."  
- Step 2: For Pada 1, select evidence showing rejection of external sites: "Kabir declares 'Kashi kaise chhute, Ram nahin chhute' — Kashi (external pilgrimage) is dispensable, but Ram (internal Divine) is not."  
- Step 3: For Pada 2, select evidence showing rejection of yogic symbols: "The Yogi's 'jata, bhasm, singi' fail to open the 'antargath' — outward austerities cannot substitute for inner unknotting."  
- Step 4: For Pada 3, select evidence showing rejection of textual authority: "The Pandit reads Vedas, Maulvi reads Kateb, but 'ant na paya' — book knowledge cannot reach the end/limit of the Divine."  
- Step 5: Synthesize: "All three padas follow the *neti neti* pattern: negate external mediators (pilgrimage, yoga, scripture) to affirm the sole mediator — *surat* (attention) turned inward toward *shabd* (sound/word)."  
REASONING: Board marking scheme awards 1 mark for correct theme identification with terminology, 1 mark for three specific textual references (one per pada), 1 mark for showing the *common pattern* across padas. The PEEL structure (Point-Evidence-Explanation-Link) ensures all three marks are addressed.  
ANSWER: The primary theme is Nirguna Bhakti — direct realization of the formless Divine within oneself (*antar*), rejecting all external rituals, symbols, and scriptures. Pada 1 rejects pilgrimage (Kashi/Kaaba) and ritual (puja/namaz) in favor of the Divine in the *dehi* (body). Pada 2 rejects yogic symbols (jata/bhasm/singi) because they leave the *antargath* (inner knot) tied. Pada 3 rejects scholarly authority (Pandit/Maulvi, Veda/Kateb) as they fail to attain *ant* (the ultimate). All three use *neti neti* negation to point to *surat shabd yog* as the only path.

## WORKED_EXAMPLE_2
PROBLEM: Competency-based question (Case-based): "A student writes: 'Kabir says God is in the heart, so we don't need temples.' Another writes: 'Kabir says temples are useless because God is everywhere.' Evaluate both statements. Which better captures the primary theme? Why?"  
STEPS:  
- Step 1: Analyze Statement 1 ("God is in the heart, so we don't need temples"): Identifies *location shift* (external → internal) and *practical consequence* (temples unnecessary). Matches Kabir's "Kashi kaise chhute" logic.  
- Step 2: Analyze Statement 2 ("God is everywhere, so temples are useless"): Uses "everywhere" (omnipresence) — a Saguna/theological concept. Kabir never says "God is everywhere"; he says "God is in *this* body (*dehi*), in *your* heart (*ghat*)."  
- Step 3: Check textual evidence: Pada 1 — "dehi mein ram"; Pada 2 — "antargath" in the body; Pada 3 — "ghat ghat mein wohi" (in *every* body, not "everywhere" diffusely). The locus is specifically the *human body*, not space in general.  
- Step 4: Evaluate: Statement 1 captures the **embodied interiority** central to Nirguna *surat shabd yog*. Statement 2 collapses Kabir's precise somatic spirituality into vague pantheism.  
- Step 5: Conclude: Statement 1 is better. It reflects the theme's *specificity* (body as temple) and *exclusivity* (only the body, not temples/mosques/books).  
REASONING: This tests whether students grasp that Kabir's "internal" is not a metaphor for "universal" but a **specific somatic practice** — the body is the *only* valid site. Competency questions often trap students with "sounds right but textually wrong" options.  
ANSWER: Statement 1 better captures the primary theme. Kabir locates the Divine specifically in the *seeker's body* (*dehi, ghat, antar*), not diffusely "everywhere." Statement 1's "heart" aligns with *antar/ghat*; its rejection of temples matches the *neti neti* logic. Statement 2's "everywhere" imports a Saguna/theological notion (omnipresence) absent in Kabir — he denies God is in Kashi/Kaaba *precisely because* God is only in the *sadhak's* body via *surat*. The theme is **exclusive interiority**, not universal presence.

## WORKED_EXAMPLE_3
PROBLEM: JEE/NEET/CUET-style Analytical Question: "Kabir's three padas form a logical triad: (1) Rejection of *popular* ritual, (2) Rejection of *renunciant* ritual, (3) Rejection of *scholarly* ritual. Explain how this triad structures the primary theme as a **totalizing critique of mediation**."  
STEPS:  
- Step 1: Map each pada to its target domain: Pada 1 = *laukik* (worldly/popular) ritual — pilgrimage, temple/mosque worship accessible to all. Pada 2 = *tyagi* (renunciant) ritual — yoga, austerity, symbols of the *sannyasi*. Pada 3 = *shastrik* (scriptural/scholarly) ritual — Veda/Kateb, pandit/maulvi, intellectual authority.  
- Step 2: Identify the shared structure: Each pada presents a *recognized spiritual authority* (pilgrim, yogi, scholar) and demonstrates its **failure to achieve the goal** (Ram, antargath-kholna, ant). The failure is structural: each authority looks *outward*.  
- Step 3: Show the progression: The critique widens from *mass practice* → *elite practice* → *highest intellectual practice*. No stratum of religious authority escapes.  
- Step 4: Connect to primary theme: Because *all* external authorities fail, the *only* remaining locus is the **individual's own body/attention** (*surat*). The theme is not "choose a better authority" but "**be your own authority via surat**."  
- Step 5: Note the Nirguna implication: This totalizing critique is what makes Kabir *Nirguna* — Saguna traditions accept *some* external mediators (murti, guru, scripture) as valid. Kabir accepts *N/A*.  
- Step 6: Formulate answer: "The triad enacts a *reductio ad absurdum* of mediation: if even the highest authorities (yogi, pandit) fail, mediation itself is the problem. The primary theme — Nirguna realization via *surat shabd yog* — is the *only* positive term left after total negation."  
REASONING: Competitive exams test ability to see **structural patterns** across texts. This triad (popular/renunciant/scholarly) is a classic Nirguna rhetorical move — seen in Dadu, Raidas, Nanak. Recognizing it shows deep thematic understanding beyond line-by-line explanation.  
ANSWER: The three padas systematically dismantle every category of spiritual mediation in 15th-century North India: popular (pilgrimage/temple), renunciant (yoga/austerity), scholarly (scripture/intellect). Each pada follows the same logic: present the mediator → show its failure → imply the alternative (internal *surat*). This *totalizing negation* (neti neti applied to all three domains) is the structural backbone of the primary theme — it leaves **no external mediator standing**, forcing the conclusion that realization is *exclusively* internal (*dehi/ghat/antar*), immediate (*surat*), and non-mediated (*shabd*). The theme is therefore not "reform of religion" but "transcendence of religion-as-mediation."

## COMPETENCY_QUESTION_1
QUESTION: A Class 12 student writes this answer for a 3-mark question on primary theme: "Kabir's main theme is that God is one and we should not fight over religion. In Pada 1 he says don't go to Kashi or Kaaba. In Pada 2 he says yogis waste time. In Pada 3 he says pandits and maulvis don't know. So he wants Hindu-Muslim unity."  
Identify **three specific errors** in this answer that would cause mark deduction in CBSE board evaluation. For each error, state: (a) what the student wrote, (b) what the marking scheme expects, (c) why the difference matters.  
COMPETENCY: Answer evaluation / Metacognitive awareness of marking criteria  
STEPS:  
- Step 1: Identify Error 1 — Theme misidentification. Student writes "God is one / Hindu-Muslim unity." Marking scheme expects "Nirguna Bhakti / formless Divine / inner realization (surat shabd yog)." Difference: "Unity" is a sociological byproduct; Nirguna is the metaphysical core.  
- Step 2: Identify Error 2 — Evidence selection. Student writes generic summaries ("don't go to Kashi or Kaaba," "yogis waste time," "pandits and maulvis don't know"). Marking scheme expects specific textual references with key terms: *dehi/antar/ghat*, *antargath/surat*, *ant/anubhav*. Difference: Generic summaries show comprehension; specific terms show *analytical* engagement with Nirguna vocabulary.  
- Step 3: Identify Error 3 — Logical structure. Student writes a list ("In Pada 1... In Pada 2... In Pada 3..."). Marking scheme expects the *neti neti* pattern: rejection of external → affirmation of internal, repeated across padas. Difference: List = description; pattern = analysis.  
- Step 4: Synthesize: All three errors stem from reading for *content* (what happens) not *structure* (how the theme is built).  
ANSWER:  
Error 1: Theme = "Hindu-Muslim unity" (sociological) vs expected "Nirguna Bhakti / surat shabd yog" (metaphysical). Matters because board syllabus defines Kabir as Nirguna poet; unity is a modern projection.  
Error 2: Evidence = generic paraphrase vs expected key terms (*dehi, antargath, surat, shabd, anubhav*). Matters because Nirguna vocabulary *is* the theme's language.  
Error 3: Structure = additive list vs expected *neti neti* triad (rejection→affirmation ×3). Matters because 3-mark questions require "analysis," not "narration."  
DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: "Kabir's primary theme is often summarized as 'God is within.' A critic argues: 'This is just Protestant interiority avant la lettre — Kabir secularizes religion by making the individual the sole authority.'"  
Using the three padas, **refute** this critic by showing how Kabir's *surat shabd yog* differs from Protestant "priesthood of all believers" in **three specific ways** grounded in the text. Your answer must use the terms *guru-kripa*, *shabd*, and *antargath*.  
COMPETENCY: Comparative textual analysis / Theoretical refutation  
STEPS:  
- Step 1: Identify the critic's claim — "individual as sole authority" = Protestant *sola scriptura* / *sola fide* adapted to interiority.  
- Step 2: Refutation 1 — *Guru-kripa* (Pada 3: "guru ki kripa te paaya"): Kabir's interiority **requires a guru** to transmit *shabd* and orient *surat*. The individual is *not* self-sufficient; authority shifts from *institution* (pandit/maulvi) to *lineage* (guru-parampara). Protestantism rejects mediating priesthood; Kabir *replaces* it with a living guru.  
- Step 3: Refutation 2 — *Shabd* as **objective reality**, not subjective faith: *Shabd* (the inner sound/word) is a *discoverable phenomenon* — "sunat hai surat" (surat hears it). It is not "belief" but *anubhav* (verifiable experience). Protestant interiority centers faith; Kabir centers *perception*.  
- Step 4: Refutation 3 — *Antargath* as **structural obstacle**, not just ignorance: The "inner knot" is a *psychosomatic blockage* requiring *technique* (surat-shabd yog) to untie, not mere intellectual assent. The body is a *machine* needing calibration; Protestantism treats the soul as a *subject* needing grace.  
- Step 5: Conclude: Kabir's interiority is **technical, initiatory, and somatic** — not individualistic or voluntaristic. The "sole authority" is the *shabd itself*, accessed via guru-given *surat*, not the unaided self.  
ANSWER:  
1. Guru-kripa (Pada 3): Kabir's path requires a guru to impart *shabd* and direct *surat* — "guru ki kripa te paaya." Authority is *transmitted*, not self-generated. Protestantism removes mediators; Kabir *replaces* institutional mediators with a living guru-parampara.  
2. Shabd as perception (Pada 1-2): *Shabd* is an *objective inner sound* ("surat shabd lagaayi") that the *surat* *hears* — a verifiable *anubhav*, not subjective belief. Protestant interiority = faith; Kabir = inner perception.  
3. Antargath as technique (Pada 2): The *antargath* is a psychosomatic knot needing *yogic technique* to untie ("antargath na khule" without *surat*). The body is a calibrated instrument; Protestantism treats the soul as a passive recipient of grace.  
Thus Kabir's "God within" is a **somatic practice under guidance**, not individualistic autonomy.  
DIFFICULTY: hard