## DEFINITION
Vocabulary in Context refers to the skill of determining the precise meaning, connotation, and grammatical function of specific words as they are used within a literary text, rather than relying solely on dictionary definitions. It involves analyzing how word choice shapes tone, imagery, and thematic depth in poetry and prose.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student can independently identify 5-7 key words from an unfamiliar Hindi poem, explain their contextual meaning with textual evidence, and analyze how each word contributes to the poem's central theme or emotional effect in a structured 4-point answer.

## SCOPE_BOUNDARY
This node covers vocabulary analysis specifically for the two poems in Chapter 14 (वड्डेगणेशी के दो पद) - focusing on words like इक़्क, ठहय, एन, पजकपज, पूएफवाइडकटज़क़ु and their contextual nuances. It does NOT cover general dictionary skills, synonyms/antonyms drills, or vocabulary from other chapters.

## WALKTHROUGH
Imagine you're reading a WhatsApp forward in Hindi where a friend uses the word "जुगाड़" - you instantly know it means an innovative fix, not just "arrangement" as the dictionary says. That's context at work. Now open your textbook to page 137-138 and read the first poem aloud. Notice how "इक़्क" doesn't just mean "one" here - it carries the weight of singularity, isolation, and defiance against a collective. Your first step: underline every word that feels "heavier" than its literal meaning. Second: ask what the poet gains by choosing this specific word over its synonyms. Third: trace that word's echo through the stanza. The key insight: in poetry, every word is a deliberate architectural choice, not decoration.

## DIAGNOSTIC_QUESTION_1
Define "vocabulary in context" and explain how it differs from looking up a word in a standard Hindi dictionary (शब्दकोश).

## DIAGNOSTIC_ANSWER_1
Vocabulary in context means determining a word's meaning based on how it functions within a specific sentence, stanza, or literary work - including its connotations, tone, and thematic resonance. A dictionary gives fixed, decontextualized definitions; context reveals living, situational meaning. A wrong answer (e.g., "both give the same meaning") reveals the student treats words as static labels rather than dynamic tools the poet shapes for effect.

## DIAGNOSTIC_QUESTION_2
In the first poem (stanza 1), the word "इक़्क" appears. A student writes: "इक़्क का अर्थ 'एक' होता है।" Why is this answer incomplete for a Class 11 board exam?

## DIAGNOSTIC_ANSWER_2
"इक़्क" here signifies not just numerical oneness but existential singularity - the lone voice of the reformer (वड्डेगणेशी) against entrenched orthodoxy. The answer "एक" misses the connotative layers: isolation, courage, and the burden of being the first to speak. A student giving only the dictionary meaning shows they cannot distinguish denotation from connotation - a critical gap for literary analysis.

## DIAGNOSTIC_QUESTION_3
Apply the context-analysis method to the word "ठहय" (from stanza 1, line 3: "ठहयक एन इक़्कुस <ह्य"). Determine its contextual meaning and explain how it shapes the imagery of that line.

## DIAGNOSTIC_ANSWER_3
Step 1: Literal meaning - "ठहय" suggests pausing, stopping, or a moment of stillness. Step 2: Context - the line describes a moment where time seems to freeze as the speaker confronts truth. Step 3: Connotation - it implies a deliberate, heavy pause, not a casual break; the weight of realization. Step 4: Effect - it creates a visual of suspended breath before revelation. Wrong answers (e.g., "waiting") miss the active, gravitational quality of the pause - the poem's turning point.

## DIAGNOSTIC_QUESTION_4
Compare the function of "एन" (stanza 1) and "पजकपज" (stanza 2). How does each word's sound (phonetics) reinforce its meaning in context?

## DIAGNOSTIC_ANSWER_4
"एन" (short, nasal, clipped) mirrors the abruptness of negation/refusal - a sharp closure. "पजकपज" (repetitive, plosive 'पज', rhythmic) mimics the bird's frantic wing-beats and the speaker's racing heart. The first enacts finality through brevity; the second enacts panic through repetition and percussive sound. A student who only gives semantic meanings misses how Hindi phonetics (ध्वनि-चित्रण) is a meaning-making device - a senior-secondary analytical skill.

## DIAGNOSTIC_QUESTION_5
Evaluate this student claim: "The word 'पूएफवाइडकटज़क़ु' in the introductory note is just a synonym for 'कवि' (poet). Replacing it with 'कवि' would not change the text's meaning." Defend or refute with evidence.

## DIAGNOSTIC_ANSWER_5
Refute. "पूएफवाइडकटज़क़ु" (पुएफवाइडकटज़क़ु = पुएफ + वाइड + कटज़ + क़ु) is a specific honorific denoting a poet-scholar of the Bhakti tradition, carrying historical weight, spiritual authority, and lineage - unlike the generic "कवि". The text uses it to position वड्डेगणेशी within a specific reformist lineage (संत परंपरा). Replacement flattens the text's cultural-historical framing. A student agreeing reveals inability to distinguish register, historical semantics, and authorial intent - treating words as interchangeable tokens.

## DIAGNOSTIC_QUESTION_6
Create a 4-line Hindi poem-stanza using any THREE key words from this chapter (इक़्क, ठहय, एन, पजकपज, पूएफवाइडकटज़क़ु) such that each word's contextual meaning in your stanza differs from its meaning in the textbook poems. Explain your choices.

## DIAGNOSTIC_ANSWER_6
Example stanza:
"इक़्क तारा टूटा आकाश से, ठहय गई सबकी साँस,
एन न बोला कोई, पजकपज दिल ने पूछा - कौन पास?"
Here: "इक़्क" = a fleeting singular event (not a person), "ठहय" = collective shock (not individual realization), "पजकपज" = anxious heartbeat (not bird's wings). Good answers show deliberate semantic shifting with awareness of original contexts. Poor answers merely recycle original contexts or use words as decorative fillers without functional integration.

## COMMON_MISCONCEPTION
Students believe "vocabulary in context" means finding the *one correct dictionary definition* that fits the sentence. They treat context as a multiple-choice filter rather than an expansive interpretive lens. For example, when analyzing "पजकपज", they search for "पजकपज = डर" in a dictionary, miss the onomatopoeic enactment of panic, and write "पजकपज का अर्थ डर है" - reducing a poetic device to a vocabulary label. This error stems from Class 9-10 "word-meaning" exercises that rewarded single-synonym answers, not analytical unpacking.

## ON_FAILURE
Step 1: Give the student a single line from the poem (e.g., "पजकपज! एर पवद वोलज") and ask: "What does the *sound* of पजकपज make you feel?" - bypassing meaning entirely. Step 2: Have them list 5 words that *sound* like panic (धड़क, काँप, थर्र, etc.) and compare phonetic textures. Step 3: Return to the line - now ask: "If the poet wrote 'डर' instead, what would be lost?" Step 4: Guide them to write: "पजकपज enacts panic through its repetitive plosives; 'डर' only names it." This shifts focus from definition to function.

## BUILDS_ON
This node builds on the skill of identifying literary devices (Node 14.008, 14.009) - specifically how imagery and sound devices operate through precise word choice.

## LEADS_TO
This node enables Comprehension: Literal and Inferential Questions (Node 14.012) where vocabulary analysis becomes evidence for inferential answers, and Critical Thinking (Node 14.013) where word-level analysis supports interpretive arguments.

## PREREQUISITE_NODE_IDS
c11_hin_ar_cbse_14_008, c11_hin_ar_cbse_14_009, c12_hin_a_cbse_14_001

## PREREQUISITE_REASONS
c11_hin_ar_cbse_14_008: Understanding imagery and metaphor provides the framework for analyzing how specific words create sensory effects.
c11_hin_ar_cbse_14_009: Knowledge of irony and symbolism enables recognizing when a word carries meanings beyond its literal sense.
c12_hin_a_cbse_14_001: 0: Established the core skill of context-dependent meaning extraction in Class 11 Antra Chapter 14. c12_hin_a_cbse_14_001: Provides author background and story context essential for understanding why Otkar chooses these specific words. c12_  

## FORWARD_NODE_IDS
c11_hin_ar_cbse_14_011, c11_hin_ar_cbse_14_012, c11_hin_ar_cbse_14_013, c11_hin_ar_cbse_14_014, c12_hin_a_cbse_07_010, c12_hin_a_cbse_14_010, c12_hin_ar_cbse_12_010, c12_hin_ar_cbse_14_010

## FORWARD_REASONS
c11_hin_ar_cbse_14_011: Vocabulary analysis feeds directly into grammar/language usage questions (e.g., identifying word-class shifts in context).
c11_hin_ar_cbse_14_012: Inferential comprehension requires citing specific words as evidence for implied meanings.
c11_hin_ar_cbse_14_013: Critical interpretation builds arguments on lexical choices - their connotations, historical weight, and phonetic effects.
c11_hin_ar_cbse_14_014: Key vocabulary (pjkpj, ik'k, <hy, pUuefYydktqZu) ensures precise terminology in Evidence/Explanation.  
c12_hin_a_cbse_07_010: Connected vocabulary to oral tradition and performance.  
c12_hin_a_cbse_14_010: Established the core skill of context-dependent meaning extraction in Class 11 Antra Chapter 14. c12_hin_a_cbse_14_001: Provides author background and story context essential for understanding why Otkar chooses these specific words. c12_hin_a_cbse_14_002: Narrative structure knowledge helps locate each vocabulary item in its plot moment for precise contextual analysis.  
c12_hin_ar_cbse_12_010: Applied vocabulary to critical interpretation — leads to competency questions.  
c12_hin_ar_cbse_14_010: Class 11 foundation in context-clue types (synonym/antonym/example) — students must know these basics before tackling connotative analysis.  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
none

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_14_008 -> c11_hin_ar_cbse_14_010 -> c11_hin_ar_cbse_14_012

## THIS_FORMULA
Contextual Meaning = Denotation + Connotation + Phonetic Effect + Syntactic Position + Intertextual/Historical Resonance

## FORMULA_VARIABLES
Denotation: Literal dictionary meaning; Connotation: Emotional/cultural associations; Phonetic Effect: Sound symbolism (ध्वनि-चित्रण); Syntactic Position: Grammatical role and placement in line; Intertextual/Historical Resonance: Echoes from literary tradition, Bhakti vocabulary, reformist discourse.

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
linguistic

## CROSS_SUBJECT
c11_history_social_reform_movements | The poems emerge from 19th-century Punjab's social reform context (सिंह सभा लहर); vocabulary like पूएफवाइडकटज़क़ु carries specific historical weight from that movement's lexicon.
c11_sociology_caste_structure | Words like इक़्क (singular voice against collective orthodoxy) and the bird metaphor (बज़ोज़) encode caste-experience semantics analyzable through sociological concepts of voice, agency, and resistance.

## PREREQ_CONCEPT
Literary devices (imagery, metaphor, sound devices) - specifically how poets compress meaning into individual lexical choices.

## PREREQ_BEFORE
Student must be able to identify at least 3 literary devices in a Hindi poem and explain their effect in 2-3 sentences.

## PREREQ_STUCK
Review "ध्वनि-चित्रण" (onomatopoeia/phonetic imaging) and "अनुप्रास" (alliteration) from Node 14.008 - these are the primary tools for analyzing words like पजकपज and ठहय.

## WORKED_EXAMPLE_1
PROBLEM: Analyze the word "इक़्क" in the first poem's opening line ("इक़्क! एर एपय") using the 5-component formula. Write a board-exam style answer (4 points).

STEPS:
- Step 1: Identify the word and its location - "इक़्क" opens the poem, standing alone as an exclamation before the address "एर एपय".
- Step 2: Determine denotation - numerical "one/alone"; connotation - singularity, isolation, uniqueness, the first voice.
- Step 3: Analyze phonetic effect - short vowel + geminate 'क़्क' creates a sharp, percussive, decisive sound - like a gavel strike or a bell.
- Step 4: Examine syntactic position - sentence-fragment exclamation, zero syntax, pure vocative force; it *is* the call before the addressee is named.
- Step 5: Trace intertextual resonance - echoes the Bhakti tradition's "एक ओंकार" (One Supreme) but secularized: the reformer's solitary conscience as divine mandate.
REASONING: This 5-layer unpacking moves from surface to depth, matching the board's expectation for "व्याख्या" questions where each layer earns a mark. The formula ensures no dimension is missed.
ANSWER: "इक़्क" का प्रसंगिक अर्थ: (1) शब्दार्थ: 'एक', 'अकेला'। (2) संकेतार्थ: सुधारक की एकाकी आवाज़, परंपरा के विरुद्ध पहला विद्रोह। (3) ध्वनि-प्रभाव: लघु स्वर + द्वित्व व्यंजन 'क़्क' से तीक्ष्ण, निर्णायक ध्वनि - जैसे घंटा या हथौड़ा। (4) वाक्यिक स्थिति: वाक्य-भंगिमा में उद्बोधन, संबोधन से पूर्व शुद्ध आह्वान। (5) अंतरपाठीय अनुगूंज: 'एक ओंकार' की भक्ति-परंपरा का धर्मनिरपेक्ष रूपांतर - सुधारक का विवेक ही ईश्वरीय आदेश।

## WORKED_EXAMPLE_2
PROBLEM: The second poem uses "पजकपज" as an onomatopoeic word. A Class 11 student writes: "पजकपज का अर्थ है डर या घबराहट।" Upgrade this to a 5-mark answer using the formula.

STEPS:
- Step 1: Acknowledge the student's denotation is correct but incomplete - "डर" is the referent, not the full meaning.
- Step 2: Analyze phonetic structure - reduplicated plosive 'पज' + vowel 'अ' + 'ज' creates staccato rhythm mimicking rapid heartbeat/wing-flutter.
- Step 3: Connect to imagery - the bird (बज़ोज़) trapped, beating wings against confinement; the speaker's own panic at the bird's fate.
- Step 4: Note syntactic doubling - "पजकपज! एर पवद वोलज" - the word *enacts* the panic it describes, then immediately commands speech.
- Step 5: Contrast with synonym - if "डर" were used, the line would *report* fear; "पजकपज" *performs* it.
REASONING: Board marking schemes reward "प्रभाव-व्याख्या" (explanation of effect) over "अर्थ-लेखन" (meaning-writing). The upgrade demonstrates the shift from vocabulary test to literary analysis.
ANSWER: "पजकपज" केवल 'डर' नहीं, बल्कि डर की **ध्वन्यात्मक अभिव्यक्ति** है। (1) पद-रचना: 'पज' का द्वित्व + 'अ' + 'ज' = तुकबंदी-रहित अनुप्रास जो हृदय की धड़कन/पंखों की फड़फड़ाहट की नकल करता है। (2) बिंब-संयोजन: बज़ोज़ का पिंजरे में फड़फड़ाना + कवि का अपना आतंक - द्वैत बिंब। (3) वाक्यिक कार्य: एकपदी उद्बोधन जो स्वयं क्रिया बन जाता है (न संज्ञा, न विशेषण - 'क्रियाविशेषणात्मक क्रिया')। (4) पर्याय-विस्थापन: 'डर' लिखने से अर्थ सूचनात्मक रह जाता; 'पजकपज' पाठक *में* घबराहट उत्पन्न करता है (प्रदर्शन, न कि वर्णन)।

## WORKED_EXAMPLE_3
PROBLEM: Compare how "ठहय" (Poem 1, line 3) and "एन" (Poem 1, line 4) function as *structural pivots* - words that shift the poem's momentum. Use the formula for both, then synthesize.

STEPS:
- Step 1: Analyze "ठहय" - Denotation: pause/stop; Connotation: gravitational halt, moment of truth; Phonetic: long vowel 'हय' + visarga-like 'य' = sustained breath-hold; Syntax: mid-line caesura, enjambment breaker; Intertextual: yogic "कुंभक" (breath retention) before realization.
- Step 2: Analyze "एन" - Denotation: no/refusal; Connotation: absolute rejection, boundary-drawing; Phonetic: nasal 'एँ' = closure through nasal resonance, no release; Syntax: line-end, final, no enjambment; Intertextual: Sant tradition's "ना" (negation as liberation).
- Step 3: Compare pivot mechanics - "ठहय" = vertical pause (time stops); "एन" = horizontal stop (movement refuses). One suspends, the other terminates.
- Step 4: Trace thematic arc - "ठहय" creates the epiphanic space; "एन" fills it with decisive action. The reformer *pauses* to see, then *refuses* to comply.
- Step 5: Synthesize for board answer - These two words form the poem's structural spine: perception (ठहय) → decision (एन).
REASONING: Senior-secondary analysis requires seeing words as *architectural elements*, not ornaments. This comparison demonstrates "संरचनात्मक विश्लेषण" (structural analysis) - a high-order competency.
ANSWER: "ठहय" और "एन" कविता के दो संरचनात्मक धुरी-बिंदु हैं। "ठहय" (पंक्ति 3): लंबा स्वर + विसर्ग-सा 'य' → श्वास-रोध (कुंभक), समय का निलंबन, बोध-पूर्व का गुरुत्वाकर्षण। वाक्यिक: मध्य-पंक्ति विराम, एनजैंबमेंट-भंग। "एन" (पंक्ति 4): अनुनासिक 'एँ' → ध्वनि-समापन, अस्वीकार की अंतिमता। वाक्यिक: पंक्ति-अंत, कोई एनजैंबमेंट नहीं। **संयुक्त कार्य**: "ठहय" = अवलोकन का क्षण (perception); "एन" = निर्णय का क्षण (decision)। सुधारक पहले *ठहरकर देखता है*, फिर *इनकार करता है*। यही कविता की नैतिक गति है।

## COMPETENCY_QUESTION_1
QUESTION: In the first poem, the address "एर एपय" (O Brother) follows "इक़्क". A student argues: "The word 'इक़्क' is redundant because 'एर एपय' already shows the speaker is addressing one person." Using vocabulary-in-context analysis, evaluate this claim and explain what "इक़्क" achieves that the address alone cannot.
COMPETENCY: Critical evaluation of lexical necessity vs. redundancy
STEPS:
- Step 1: Identify the student's error - confusing grammatical number (singular address) with existential singularity.
- Step 2: Analyze "इक़्क" as existential marker - the speaker's isolation, not the addressee's count.
- Step 3: Analyze "एर एपय" as relational marker - establishing fraternal appeal, shared humanity.
- Step 4: Contrast functions - "इक़्क" = vertical axis (self vs. tradition); "एर एपय" = horizontal axis (self vs. other).
- Step 5: Conclude - removal of "इक़्क" collapses the poem's central tension: the lone conscience appealing to collective brotherhood.
ANSWER: छात्र का दावा गलत है। "इक़्क" व्याकरणिक एकवचन नहीं, **अस्तित्वगत एकाकीपन** दर्शाता है - सुधारक की पूरी परंपरा के विरुद्ध अकेली आवाज़। "एर एपय" संबोधन है, संबंध-सेतु; "इक़्क" उद्घोषणा है, स्थिति-चिह्न। "इक़्क" हटाने से कविता का केंद्रीय तनाव (एक विवेक बनाम सामूहिक रूढ़ि) ढह जाता है। "एर एपय" अकेला रह जाए तो कविता मात्र संवाद बनकर रह जाएगी, आत्मसंघर्ष नहीं।
DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: The introductory prose note uses "पूएफवाइडकटज़क़ु" as an honorific for वड्डेगणेशी. The poems themselves use zero honorifics - the speaker addresses "एर एपय" and commands "पजकपज! एर पवद वोलज". Analyze this register shift (honorific in prose → zero honorific in poetry) as a deliberate lexical choice. What does it reveal about the text's view of authority and voice?
COMPETENCY: Register analysis and authorial stance interpretation
STEPS:
- Step 1: Define the registers - prose note: scholarly/historical register (सम्मानसूचक पदबंध); poems: direct speech register (संबोधन/आदेश)।
- Step 2: Analyze "पूएफवाइडकटज़क़ु" - positions the poet *externally* within tradition, legitimizing him for the reader.
- Step 3: Analyze poetic voice - zero honorifics = speaker claims *internal* authority, speaks *as* the reformer, not *about* him.
- Step 4: Connect to theme - social reform requires rejecting external validation (titles, lineage) in favor of direct moral voice.
- Step 5: Synthesize - the register shift *enacts* the reformer's journey: from recognized scholar (prose frame) to lone voice speaking truth to power (poem).
ANSWER: यह रजिस्टर-परिवर्तन अनायास नहीं, **थीमेटिक अभिनय** है। गद्य-टिप्पणी में "पूएफवाइडकटज़क़ु" बाह्य सत्ता (परंपरा, विद्वता, मान्यता) से वैधता दिलाता है - पाठक के लिए। कविताओं में शून्य-सम्मानसूचक = आंतरिक सत्ता (विवेक, सत्य, नैतिक बल) का दावा - कर्ता के लिए। सुधारक पहले 'मान्य कवि' (बाह्य) है, फिर 'इक़्क' आवाज़ (आंतरिक)। यह परिवर्तन सुधार-आंदोलन का केंद्रीय द्वंद्व दर्शाता है: **संस्थागत मान्यता बनाम नैतिक स्वायत्तता**। कविता *बताती* नहीं, *जीती* है यह द्वंद्व।
DIFFICULTY: hard