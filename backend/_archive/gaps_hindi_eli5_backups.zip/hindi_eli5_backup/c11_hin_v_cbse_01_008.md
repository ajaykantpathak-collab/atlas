## DEFINITION
Imagery (fp=kiV laxhr) in this chapter refers to the author's technique of using vivid, sensory language to create visual-pictorial quality in prose, where words function like brushstrokes to evoke mental pictures. Metaphor (xkuiu) operates as the fundamental creative faculty that transforms raw experience into artistic expression by establishing implicit comparisons between the seen world and the imagined realm, making the invisible visible through linguistic innovation.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student must be able to identify specific passages where the author uses visual imagery to blur the boundary between fp=kiV laxhr (visual art) and 'kkL=kh; laxhr (literary art), and explain how the concept of xkuiu (creative imagination) functions as an extended metaphor for the artistic process across at least three textual examples with analytical reasoning.

## SCOPE_BOUNDARY
This node covers the analysis of imagery and metaphor as discussed explicitly in the essay "Hkkjrh; xkf;dkvksa esa cstksM+µyrk eaxs'kdj" — focusing on the author's theoretical framework distinguishing visual from literary art, the three types of rhythm (foyafcry;, eè;y;, nzqry;), and the role of xkuiu. It does NOT cover general poetic devices from other chapters, nor does it require analyzing full poems — only the prose passages in this specific essay.

## WALKTHROUGH
Imagine you're standing before a painting in a museum — you see colors, lines, textures. Now imagine reading a paragraph that makes you *see* that same painting in your mind without any image present. That's the power of imagery in prose. Begin by asking students to recall a moment when a written description made them visualize something vividly — a market scene, a grandmother's kitchen, a monsoon afternoon. Then guide them to the text: the author claims fp=kiV laxhr uses "Loj" (lines/sounds) and "y;" (rhythm) to create "xkuiu" — a creative spark that makes the reader *experience* rather than just understand. Have students mark every passage where the author describes the painter's work or his own writing in visual terms. The key insight: in this essay, imagery is not decoration — it's the *method* by which the author argues that literary art can achieve the immediacy of visual art.

## DIAGNOSTIC_QUESTION_1
According to the author, what is the primary distinction between fp=kiV laxhr (visual art) and 'kkL=kh; laxhr (literary art) in terms of their "rky" (foundation/basis)?

## DIAGNOSTIC_ANSWER_1
The author states that fp=kiV laxhr's foundation is "izkFkfed voLFkk" (immediate/existential state) while 'kkL=kh; laxhr's foundation is "vius ifjÑr :i" (its own defined form). A wrong answer (e.g., "visual art uses colors, literary art uses words") reveals the student is confusing medium with ontological basis — they haven't grasped the author's philosophical distinction about *how* each art grounds itself in reality.

## DIAGNOSTIC_QUESTION_2
The author describes three types of "y;" (rhythm): foyafcry; (musical), eè;y; (poetic), and nzqry; (prosaic). Explain in your own words how nzqry; differs from the other two, and why the author considers it significant for prose writing.

## DIAGNOSTIC_ANSWER_2
Nzqry; is "rs"k" (prosaic/ordinary) — it lies between musical rhythm (foyafcry;) and poetic rhythm (eè;y;) in intensity. The author values it because prose's rhythm should feel natural, not artificially heightened. A wrong answer (e.g., "nzqry; is the most musical") shows the student hasn't understood the hierarchy: foyafcry; > eè;y; > nzqry; in musicality, but nzqry; is *appropriate* for prose's truth-telling function.

## DIAGNOSTIC_QUESTION_3
In the passage where the author describes the painter's first portrait ("izfl¼ xkf;dk uwjtgk¡ dk fp=kiV"), identify the specific visual imagery used and explain how it functions as a metaphor for the painter's artistic journey.

## DIAGNOSTIC_ANSWER_3
The imagery: "lqizfl¼ xk;d nhukukFk eaxs'kdj dh vtc xk;dh ,d nwljk Lo:i fy, mUgha dh csVh dh dksey vkok"k esa lquus dk vuqHko gqvkA" — the small room, the effort to capture a "new form." This functions as a metaphor for the painter's entire career: confined space (csVh dh dksey) yielding expansive vision (nwljk Lo:i). A wrong answer that only lists visual details without connecting to metaphor reveals the student treats imagery as decorative rather than structural.

## DIAGNOSTIC_QUESTION_4
The author writes: "fp=kiV laxhr us yksxksa osQ ^dku fcxkM+ fn,* ,slk vkjksi yxk;k tkrk jgk gSA ij eSa le>rk gw¡ fd fp=kiV laxhr us yksxksa osQ dku [kjkc ugha fd, gSa] myVs lqèkkj fn, gSaA" Analyze this claim. How does the author use metaphor here to redefine the relationship between visual art and human sensitivity?

## DIAGNOSTIC_ANSWER_4
The metaphor "dku fcxkM+ fn," (made eyes bloom) suggests visual art *awakens* latent perception rather than giving new eyes. The author redefines visual art not as a sensory transplant but as a catalyst for inherent human sensitivity (lqèkkj). A wrong answer taking "dku fcxkM+ fn," literally (art gives physical eyes) misses the metaphorical layer — the student fails to see that the author is making a philosophical argument *through* metaphor.

## DIAGNOSTIC_QUESTION_5
Evaluate the author's assertion: "'kkL=kh; laxhr Hkh jatd u gks] rks fcyoqQy gh uhjl BgjsxkA vukd"kZd izrhr gksxk vkSj mlesa oqQN deh&lh izrhr gksxhA" Do you agree that literary art *without* visual-pictorial quality becomes rigid and less impactful? Justify with reference to the essay's logic.

## DIAGNOSTIC_ANSWER_5
Yes, per the author's logic: fp=kiV laxhr provides the "mÙke tkudkjh" (foundational knowledge) that literary art needs to access "lkjh feBkl, lkjh rkdr" (deepest feeling, deepest rhythm). Without it, literary art loses its "jatdrk" (vitality/life-force) because it disconnects from the sensory ground of experience. A student who disagrees without engaging the author's definition of "xkuiu" as the bridge between the two arts shows evaluative failure — they're imposing external criteria instead of evaluating *within* the text's framework.

## DIAGNOSTIC_QUESTION_6
Write a 100-word prose paragraph describing a familiar Indian street scene (a bazaar, a temple courtyard, a railway platform) using the author's principle of "fp=kiV laxhr" — where words create visual immediacy through "Loj" (line-like precision) and "nzqry;" (prosaic rhythm). Do not use poetic devices like rhyme or overt metaphor. Let the imagery carry the metaphor.

## DIAGNOSTIC_ANSWER_6
A strong answer uses concrete sensory nouns (genda phool, jalebi ka tel, rail ka dhuwaan), rhythmic but unmetered sentences of varying length, and lets juxtaposition create meaning (e.g., "The chai wallah's kettle whistles. A cow chews plastic. The train arrives late."). A weak answer uses abstract adjectives ("beautiful," "chaotic"), forced metaphors ("the market is a river"), or poetic line breaks — revealing the student hasn't internalized the author's insistence on *prosaic* visual truth over poetic ornamentation.

## COMMON_MISCONCEPTION
Students conflate "imagery" with "figurative language" (metaphor, simile, personification) and hunt for decorative comparisons in the essay. But in this text, the author uses *imagery as argument* — the visual details of the painter's room, the "csVh dh dksey," the "nwljk Lo:i" are not ornamental; they *are* the evidence for his theory that literary art achieves vitality only when it adopts visual art's sensory precision. Students also miss that "xkuiu" is itself the essay's central *extended metaphor* — not a device to spot, but the conceptual engine driving the whole piece.

## ON_FAILURE
1. Have the student re-read only the first two pages, highlighting every concrete noun (room, paint, brush, canvas, light, sound). 2. Ask: "Which of these details could a camera capture? Which require the writer's perception?" 3. Map each highlighted detail to the author's claim about fp=kiV laxhr's "Loj" and "y;." 4. Finally, trace "xkuiu" across the essay: circle every occurrence and note what it *does* in each context (awakens, transforms, bridges, defines). This moves them from hunting devices to seeing how imagery *structures* the argument.

## BUILDS_ON
The concept of "xkuiu" (creative imagination) as the bridge between sensory experience and artistic expression, introduced in the essay's opening anecdote about the painter's first portrait.

## LEADS_TO
The analysis of irony and symbolism in the next node (c11_hin_v_cbse_01_009), where the author's visual-literary framework extends to how meaning is layered beyond the immediate image.

## PREREQUISITE_NODE_IDS
c11_hin_v_cbse_01_001, c11_hin_v_cbse_01_002, c11_hin_v_cbse_01_003, c11_hin_v_cbse_01_006, c11_hin_v_cbse_01_007

## PREREQUISITE_REASONS
c11_hin_v_cbse_01_001: Provides the historical-cultural context of Indian storytelling traditions that frames the author's argument about fp=kiV vs 'kkL=kh; laxhr.
c11_hin_v_cbse_01_002: Establishes the narrative structure — the author's personal encounter with the painter — which is the experiential ground for all subsequent imagery.
c11_hin_v_cbse_01_003: Develops the setting/atmosphere (the painter's room, the era) that the imagery in this node re-creates and theorizes.
c11_hin_v_cbse_01_006: Imagery/metaphor analysis requires knowing *what* the devices are illuminating – the primary theme.  
c11_hin_v_cbse_01_007: Imagery and metaphor analysis requires knowing which themes they serve (e.g., rhythm imagery serves the threefold rhythm theme).  

## FORWARD_NODE_IDS
c11_hin_v_cbse_01_009, c11_hin_v_cbse_01_013, c11_hin_v_cbse_01_012, c11_hin_v_cbse_01_014, c11_hin_v_cbse_01_015, c12_hin_a_cbse_01_008, c12_hin_a_cbse_02_008, c12_hin_a_cbse_04_008, c12_hin_a_cbse_05_008, c12_hin_a_cbse_06_008, c12_hin_a_cbse_12_008, c12_hin_a_cbse_17_008, c12_hin_al_cbse_03_008, c12_hin_v_cbse_01_008, c12_hin_v_cbse_02_008, c12_hin_a_cbse_04_005, c11_hin_ar_cbse_01_008

## FORWARD_REASONS
c11_hin_v_cbse_01_009: The imagery/metaphor framework here enables analyzing how irony and symbolism operate as *visual-literary hybrids* — e.g., the "dku fcxkM+ fn," metaphor is both image and ironic reversal.
c11_hin_v_cbse_01_013: Critical thinking requires the ability to trace how the author's theoretical claims (about xkuiu, Loj, y;) are *embodied* in his own prose style — a meta-analysis only possible after mastering this node.
c11_hin_v_cbse_01_012: Imagery/metaphor recognition is essential for inferring author's craft.  
c11_hin_v_cbse_01_014: Imagery and metaphor analysis trains evidence-spotting for literary devices.  
c11_hin_v_cbse_01_015: Imagery/metaphor analysis gives students concrete textual moments to cite (e.g., "blind eyes" metaphor).  
c12_hin_a_cbse_01_008: Reinforced device recognition in Vitan prose/poetry; provides cross-genre practice.  
c12_hin_a_cbse_02_008: Exposure to imagery/metaphor in Vitan (prose-poetry blend) Chapter 1.  
c12_hin_a_cbse_04_008: Vitan poems add modernist imagery — broadens stylistic range.  
c12_hin_a_cbse_05_008: Vitan textbook perspective on imagery in prose-poetry.  
c12_hin_a_cbse_06_008: Exposure to prose imagery/metaphor in Vitan essays, building cross-genre analytical flexibility.  
c12_hin_a_cbse_12_008: अगला तार्किक चरण: Imagery is the use of vivid, sensory language that appeals to the five senses (sight, sound, smell,... इस नोड की अवधारणाओं को सीधे उपयोग/विस्तारित करता है।  
c12_hin_a_cbse_17_008: Class 11 Vitan parallel node — reinforces device identification across different text types (essay vs. story).  
c12_hin_al_cbse_03_008: Class 11 Vitan parallel coverage of same devices — reinforces through different texts.  
c12_hin_v_cbse_01_008: Provides foundational definitions and identification practice for imagery/metaphor — without this, Class 12 functional analysis is impossible.  
c12_hin_v_cbse_02_008: Provides foundational definitions of imagery types and metaphor structure (tenor/vehicle) required for Class 12 analysis.  
c12_hin_a_cbse_04_005: If stuck, review "Personification as Characterization" in Class 11 poetry nodes (c11_hin_ar_cbse_01_008, c11_hin_v_cbse_01_008) and practice on a simpler poem like "पहाड़" (Antra Ch. 2).  
c11_hin_ar_cbse_01_008: hapter 1. c11_hin_ar_cbse_02_008: Reinforced the same devices in a different text, showing variety. c11_hin_v_cbse_01_008: Covered literary devices in Vitan, providing cross-text practice. c12_hin_a_cbse_12_001: Context node gives author ba  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
none

## CHAIN_DESCRIPTION
c11_hin_v_cbse_01_001 -> c11_hin_v_cbse_01_008 -> c11_hin_v_cbse_01_009: Context grounds the imagery-metaphor analysis, which then enables the irony-symbolism analysis that follows.

## THIS_FORMULA
N/A - conceptual

## FORMULA_VARIABLES
N/A

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
analytical

## CROSS_SUBJECT
c11_history_art_aesthetics | The essay's debate on fp=kiV vs 'kkL=kh; laxhr mirrors historical shifts in Indian aesthetic theory (from Chitrasutra to modern art criticism) — students can trace how the author positions himself in this lineage.
c11_psychology_perception_cognition | The concept of "xkuiu" as creative imagination aligns with cognitive psychology's "mental imagery" and "embodied cognition" — the author's claim that visual art "awakens" sensitivity (lqèkkj) parallels research on how aesthetic experience rewires perceptual pathways.

## PREREQ_CONCEPT
The distinction between sensory perception (seeing a painting) and aesthetic perception (experiencing its "xkuiu" — the creative spark that makes it art), introduced in the opening anecdote.

## PREREQ_BEFORE
Student must be able to locate the author's first-person narrative voice and distinguish it from his theoretical voice — the essay shifts between "I saw" and "I argue."

## PREREQ_STUCK
Review the "Before You Read" context (c11_hin_v_cbse_01_001) on the tradition of Indian xkf;dk (storytellers) and the historical place of visual narration — this frames why the author elevates fp=kiV laxhr as foundational.

## WORKED_EXAMPLE_1
PROBLEM: Analyze how the author uses the imagery of "Loj" (lines/sounds) in the passage "Lojksa osQ ozQec¼ lewgA Loj ekfydk esa cksy ('kCn) ugha gksrsA" to build his argument that visual art's language precedes and exceeds literary language.

STEPS:
- Step 1: Identify the core claim — "Loj" are not words but a "ozQec¼ lewg" (pure/sacred collective) that exist before language.
- Step 2: Trace the imagery — "Loj lqurs gh eSaus vuqHko fd;k fd ;g Loj oqQN fo'ks"k gS] jks"k dk ughaA" The author *personifies* Loj as having agency (they "tell" him something).
- Step 3: Connect to the fp=kiV/'kkL=kh; distinction — visual art accesses Loj directly; literary art mediates them through words ('kCn).
- Step 4: Analyze the metaphor — "Loj" functions as a metaphor for *pre-linguistic sensory truth*. The author claims fp=kiV laxhr speaks this truth; 'kkL=kh; laxhr translates it.
- Step 5: Evaluate the effect — this imagery elevates visual art to a primordial status, making the painter a "listener" to what language cannot yet name.

REASONING: The steps move from textual evidence to conceptual mapping to meta-level function — exactly the analytical progression board exams require for "how does the author use imagery to argue..." questions.

ANSWER: The author uses "Loj" as a controlling image-metaphor: it represents the raw sensory data that visual art captures directly (through line, color, rhythm) while literary art must approximate through words. By personifying Loj as "telling" him their nature, he enacts the very immediacy he theorizes — his prose *becomes* fp=kiV laxhr in that moment.

## WORKED_EXAMPLE_2
PROBLEM: The author describes three rhythms: foyafcry; (musical), eè;y; (poetic), nzqry; (prosaic). Using the passage "rhu&lk<s+ rhu feuV osQ xk, gq, 1- foyafcry; (èkheh) ii- eè;y; (chp dh) iii- nzqry; (rs"k)", explain how this classification functions as an extended metaphor for the hierarchy of artistic truth.

STEPS:
- Step 1: Map the three rhythms to their domains — foyafcry; = music (pure sound), eè;y; = poetry (structured sound), nzqry; = prose (speech-rhythm).
- Step 2: Note the spatial metaphor — "eè;y; ls nqxquh vkSj foyafcry; ls pkSxquh rs"k y; nzqry; dgykrh gSA" (nzqry; lies beyond poetic rhythm and before musical rhythm). This positions prose *between* the two "higher" arts.
- Step 3: Connect to the author's practice — he writes *in* nzqry; (prose rhythm) but *about* foyafcry; and eè;y;. His prose embodies the "rs"k" rhythm while analyzing the others.
- Step 4: Identify the metaphorical claim — artistic truth is not in the "highest" rhythm (music) but in the *appropriate* rhythm for the medium. Prose's truth is nzqry;.
- Step 5: Link to xkuiu — the painter's "xkuiu" operates at the foyafcry; level (pure creative spark); the author's prose translates it into nzqry; without losing its charge.

REASONING: This works because it treats the classification not as taxonomy but as metaphorical architecture — the hierarchy *is* the argument about where literary art finds its vitality.

ANSWER: The three rhythms form a spatial-metaphorical hierarchy where nzqry; (prosaic rhythm) is not "lower" but *grounded* — it is the rhythm of lived speech, the "rs"k" ground from which poetry and music rise. The author's prose *performs* this truth: its sentences have the irregular, breathing cadence of nzqry; while discussing the more rarified rhythms. This enactment is the essay's central metaphor: literary art *is* the translation of foyafcry; into nzqry; via xkuiu.

## WORKED_EXAMPLE_3
PROBLEM: The essay ends with the image: "fdruk cM+k gS gekjk HkkX;!" (How vast is our sky!). Trace how this final image retroactively transforms the opening anecdote (the painter's first portrait in a small room) into a metaphor for the expansive reach of fp=kiV laxhr. Combine analysis of imagery, metaphor, and narrative structure.

STEPS:
- Step 1: Reconstruct the opening image — "csVh dh dksey" (small room's constraint), "nwljk Lo:i" (new form), "Loj" entering the narrator's ears. Confined space, emergent vision.
- Step 2: Reconstruct the closing image — "HkkX;" (sky/space), "vkt ge lHkh osQ chp gS" (now it is among all of us), "tu&eu ij lrr izHkqRo" (deep impact on mind-heart). Expanded space, shared vision.
- Step 3: Identify the structural metaphor — the essay *enacts* the journey from csVh dh dksey to HkkX;. The narrative *is* the expansion.
- Step 4: Analyze "xkuiu" as the engine — the painter's xkuiu (in the small room) → the author's xkuiu (writing the essay) → the reader's xkuiu (receiving it). Each transfer expands the sky.
- Step 5: Connect to fp=kiV laxhr's social claim — "fp=kiV laxhr us yksxksa osQ dku fcxkM+ fn," — the "sky" is the collective sensitivity (lqèkkj) now awakened across "dksus&dksus" (villages) and "ijnsl" (cities).
- Step 6: Evaluate the literary achievement — the author uses nzqry; (prosaic rhythm) to carry foyafcry;-level vision (the sky). The final sentence's simplicity ("fdruk cM+k gS gekjk HkkX;!") *is* nzqry; performing foyafcry;.

REASONING: This multi-step synthesis mirrors board-level "critical appreciation" questions that demand tracing an image across the whole text while linking form to theme.

ANSWER: The "small room → vast sky" arc is the essay's master metaphor. The painter's csVh dh dksey contains the seed of fp=kiV laxhr's universal reach. The author's prose, written in nzqry;, carries this seed across time and space until the final exclamation — "How vast is our sky!" — where the reader's imagination (xkuiu) meets the painter's. The imagery is not illustrative; it *constitutes* the argument: visual art's truth begins in constraint and ends in shared expansiveness.

## COMPETENCY_QUESTION_1
QUESTION: The author claims: "fp=kiV laxhr xkus okys dks 'kkL=kh; laxhr dh mÙke tkudkjh gksuk vko';d gS" (The writer of visual art must have foundational knowledge of literary art). But he also says: "D;k 'kkL=kh; xk;dksa dks Hkh fp=kiV laxhr ls oqQN lh[kuk pkfg," (Should literary artists also learn from visual art?). Using the essay's imagery of "Loj" and "y;," argue *why* the second question is more urgent for the author — and what metaphorical role "xkuiu" plays in this asymmetry.

COMPETENCY: Critical analysis of asymmetric artistic influence using textual evidence and metaphorical reasoning

STEPS:
- Step 1: Locate both statements in the text — the first is presented as established ("vko';d gS"), the second as an open question ("iz'u iwNuk gS").
- Step 2: Analyze "Loj" as the shared substrate — visual art *is* Loj; literary art *uses* Loj as words. The painter already *inhabits* the medium the writer must study.
- Step 3: Trace "y;" — the painter works in foyafcry;/eè;y; (deeper rhythms); the writer works in nzqry;. The writer *needs* the painter's rhythmic depth to vitalize nzqry;.
- Step 4: Interpret "xkuiu" — it is the *transfer mechanism*. The painter's xkuiu generates foyafcry;; the writer's xkuiu must receive it and transmute it into nzqry;. Without this transfer, nzqry; becomes "uhjl" (rigid) and "deh&lh izrhr" (less impactful).
- Step 5: Conclude — the asymmetry exists because literary art *depends* on visual art for its sensory ground (mÙke tkudkjh), but visual art does not symmetrically depend on literary art. The urgency is existential for the writer.

ANSWER: The second question is more urgent because the author's entire argument demonstrates that 'kkL=kh; laxhr *cannot sustain its jatdrk (vitality) without fp=kiV laxhr's sensory foundation*. The metaphor of "Loj" shows visual art as the *source* (Loj exist before words); "y;" shows it as the *deeper rhythm* (foyafcry; > nzqry;); "xkuiu" is the *bridge* the writer must cross. The painter doesn't need the writer's knowledge to paint — but the writer *cannot write living prose* without the painter's vision. The asymmetry is not hierarchical; it's ontological.

DIFFICULTY: hard

## COMPETENCY_QUESTION_2
QUESTION: A Class 11 student writes in their board exam answer: "The author uses imagery like 'csVh dh dksey' and 'nwljk Lo:i' to describe the painter's room and art. This creates a vivid picture." Why is this answer insufficient for full marks? Rewrite it as a high-scoring response using the PEEL structure (Point, Evidence, Explanation, Link) that connects the imagery to the essay's central metaphor of "xkuiu."

COMPETENCY: Exam answer writing — transforming descriptive identification into analytical argument using PEEL structure

STEPS:
- Step 1: Diagnose the weakness — the student's answer only *identifies* imagery (Point + weak Evidence) but lacks Explanation (how it works) and Link (to central argument).
- Step 2: Draft Point — "The imagery of confinement ('csVh dh dksey') and emergence ('nwljk Lo:i') functions as the essay's governing metaphor for xkuiu's operation."
- Step 3: Draft Evidence — "In the opening anecdote, the painter's small room ('csVh dh dksey') contains the 'vuqHko' (effort/impulse) to capture a 'nwljk Lo:i' through 'Loj' that are 'oqQN fo'ks"k' (unique, not ordinary)."
- Step 4: Draft Explanation — "This spatial imagery enacts xkuiu's defining quality: it transforms constraint into creative expansion. The 'Loj' entering the narrator's ears ('Loj lqurs gh eSaus vuqHko fd;k') shows xkuiu as contagious — it passes from painter to witness through sensory immediacy."
- Step 5: Draft Link — "Thus the opening imagery is not descriptive scene-setting; it is the *thesis in image-form*: xkuiu begins in the particular (csVh dh dksey) and reaches the universal (HkkX;), which the final sentence confirms."

ANSWER: The imagery of 'csVh dh dksey' (small room's constraint) and 'nwljk Lo:i' (new form) is the essay's master metaphor for xkuiu — the creative imagination that transforms limitation into expansion. When the author writes 'Loj lqurs gh eSaus vuqHko fd;k fd ;g Loj oqQN fo'ks"k gS', the sensory image of lines/sounds entering his ears *enacts* xkuiu's transmission: the painter's confined vision becomes the narrator's awakened perception. This mirrors the essay's arc from individual encounter to collective awakening ('fp=kiV laxhr us yksxksa osQ dku fcxkM+ fn,'). The opening room is not a setting — it is the metaphorical womb of fp=kiV laxhr's universal reach, confirmed by the closing 'fdruk cM+k gS gekjk HkkX;!'

DIFFICULTY: medium