## DEFINITION
Irony is a literary device where the intended meaning of words or a situation is opposite to their literal or expected meaning, creating a contrast between appearance and reality. Symbolism is the use of concrete objects, actions, or characters to represent abstract ideas, emotions, or themes beyond their literal significance.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student can independently identify at least two distinct instances of irony and two symbols in the poems "Olar Vak" and "Raksaks", explain how each device functions in context, and write a structured board-style answer linking these devices to the central themes of aging, futility, and the human condition.

## SCOPE_BOUNDARY
This node covers irony (verbal, situational, dramatic) and symbolism specifically in the two poems of Chapter 5 ("Olar Vak" and "Raksaks"). It does not cover imagery, metaphor, or other figures of speech (addressed in node c12_hin_a_cbse_05_008), nor does it address literary devices in other chapters.

## WALKTHROUGH
Imagine you are reading "Olar Vak" and the old man says "I am waiting for death" while the poem vividly describes the stubborn persistence of life around him — that jarring gap is irony. Now notice the repeated refrain "Raksaks, raksaks, raksaks" in the second poem; the act of building a house becomes a symbol for the desperate human attempt to construct meaning against mortality. Begin by reading both poems aloud twice: first for literal sense, second to mark every statement that contradicts the visible reality (irony) and every concrete noun that recurs with emotional weight (symbol). Ask: "What does the poet *really* mean when the old man calls death a 'friend'? What does the 'house' stand for?" The key insight is that irony exposes the tragedy of self-deception, while symbolism elevates personal grief into a universal statement.

## DIAGNOSTIC_QUESTION_1
Define irony and symbolism in your own words, giving one example from everyday life for each.

## DIAGNOSTIC_ANSWER_1
Irony: a situation where the outcome is contrary to what was expected (e.g., a fire station burning down). Symbolism: an object representing a deeper idea (e.g., a dove representing peace). A wrong answer that defines irony as "funny coincidence" reveals confusion between irony and mere chance; a wrong answer that calls any mentioned object a symbol shows inability to distinguish literal from representational meaning.

## DIAGNOSTIC_QUESTION_2
In "Olar Vak", the speaker describes the old man's daily routine: "The sun rises, the birds sing, the old man waits." Explain the situational irony in this depiction of waiting.

## DIAGNOSTIC_ANSWER_2
The irony lies in the contrast between the vibrant, cyclical renewal of nature (sun, birds) and the old man's static, linear wait for an end that does not come. Nature's "morning" symbolizes beginnings, while the old man's wait is for a final ending — the two temporal orders clash. A wrong answer that only lists the routine without naming the contrast misses the analytical core; a student who calls it "sadness" confuses tone with irony.

## DIAGNOSTIC_QUESTION_3
Identify one symbol in "Raksaks" and explain how its meaning shifts across the three stanzas.

## DIAGNOSTIC_ANSWER_3
The "house" (ghar) is the central symbol. In stanza 1 it represents physical shelter ("walls, roof, doors"); in stanza 2 it becomes a metaphor for emotional security ("heart's walls, memory's roof"); in stanza 3 it ironically turns into a pyre ("when the house is ready, we burn it"). A wrong answer that treats the house only as a building fails to track the semantic shift; a student who says "the house symbolizes life" without stanza-by-stanza evidence gives a vague generalization.

## DIAGNOSTIC_QUESTION_4
Compare the use of verbal irony in "Olar Vak" (the old man's speech) with the structural irony in "Raksaks" (the refrain). How does each type serve the poem's theme?

## DIAGNOSTIC_ANSWER_4
In "Olar Vak", verbal irony appears when the old man calls death "my dear friend" (priya mitr) while his body recoils — the gap between word and feeling reveals denial. In "Raksaks", structural irony resides in the refrain "Raksaks, raksaks" which sounds like a construction chant but actually enacts the futility of building against time; the repetition mimics the monotonous, endless labor. A wrong answer that treats both as "irony" without distinguishing verbal vs. structural misses the nuance; a student who says "both show sadness" reduces device to theme.

## DIAGNOSTIC_QUESTION_5
Evaluate which poem uses symbolism more effectively to convey the inevitability of aging. Support your judgment with two textual reasons.

## DIAGNOSTIC_ANSWER_5
"Raksaks" uses symbolism more effectively because (1) the house symbol operates at three semantic levels (physical, emotional, existential) creating a layered architecture of meaning, and (2) the final transformation of house into pyre fuses symbol and irony into a single unforgettable image. "Olar Vak" relies more on imagery than sustained symbols. A wrong answer that picks "Olar Vak" because "it has more symbols" shows quantitative rather than qualitative evaluation; a student who cannot cite specific symbol transformations lacks evidentiary rigor.

## DIAGNOSTIC_QUESTION_6
Write a four-line stanza about an elderly person that uses both verbal irony and a recurring symbol (choose any object). Mark the ironic line and the symbol.

## DIAGNOSTIC_ANSWER_6
Example:  
"My legs are wings," he laughs, though stairs defeat him — (verbal irony marked)  
The cane he taps writes poems on the floor. (cane = symbol of dignity/voice)  
Each tap a stanza, each pause a rhyme,  
He walks the house he built, now walking him.  
A poor answer uses irony as mere sarcasm ("He's so fast he's slow") or picks a symbol without thematic resonance (e.g., "his watch" without linking to time's passage).

## COMMON_MISCONCEPTION
Students often equate irony with "unfortunate coincidence" (e.g., "It rained on my wedding day — how ironic!") and treat every noun in a poem as a symbol (e.g., "The bird is a symbol because it appears"). The first error stems from confusing Alanis Morissette-style usage with literary irony; the second arises from not testing whether the object carries *consistent* abstract meaning across the text. In "Raksaks", the "axe" (kulhari) appears once as a tool — it is *not* a symbol; the "house" appears in every stanza with shifting connotations — it *is* a symbol.

## ON_FAILURE
If a student cannot distinguish irony from coincidence: 1) Give three clear examples (verbal, situational, dramatic) from daily life and ask them to label the *expectation* vs. *reality* in each. 2) Return to "Olar Vak" stanza 2 and have them complete a two-column table: "What the old man says" vs. "What the poem shows". If a student over-identifies symbols: 1) Provide the "Symbol Test": Does the object appear ≥2 times? Does its meaning change/deepen? Does it connect to the theme? 2) Apply the test to five nouns from "Raksaks" (house, axe, wall, door, fire) and discuss results.

## BUILDS_ON
This node builds on the ability to distinguish literal from figurative language developed in c12_hin_a_cbse_05_008 (Imagery and Metaphor), where students learned that words can carry surplus meaning.

## LEADS_TO
This node enables c12_hin_a_cbse_05_013 (Critical Thinking: Analysis and Interpretation) where students synthesize devices into thematic arguments, and c12_hin_a_cbse_05_014 (Writing Skills) where they embed device-analysis in structured answers.

## PREREQUISITE_NODE_IDS
c12_hin_a_cbse_05_008, c11_hin_ar_cbse_01_009, c11_hin_ar_cbse_02_009, c11_hin_ar_cbse_03_009, c11_hin_ar_cbse_04_009, c11_hin_ar_cbse_05_009, c11_hin_ar_cbse_06_009, c11_hin_ar_cbse_07_009, c11_hin_ar_cbse_08_009, c11_hin_ar_cbse_09_009, c11_hin_ar_cbse_10_009, c11_hin_ar_cbse_11_009, c11_hin_ar_cbse_12_009, c11_hin_ar_cbse_13_009, c11_hin_ar_cbse_14_009, c11_hin_ar_cbse_15_009, c11_hin_ar_cbse_16_009, c11_hin_v_cbse_01_009, c11_hin_v_cbse_02_009, c11_hin_v_cbse_03_009, c11_hin_v_cbse_04_009, c11_hin_v_cbse_05_009, c12_hin_a_cbse_05_001, c12_hin_a_cbse_05_003, c12_hin_a_cbse_05_006, c12_hin_a_cbse_05_007

## PREREQUISITE_REASONS
c12_hin_a_cbse_05_008: Imagery and Metaphor establishes the foundation of figurative reading without which irony/symbolism cannot be distinguished from literal description.
c11_hin_ar_cbse_01_009 through c11_hin_v_cbse_05_009: Class 11 nodes on Irony and Symbolism across multiple chapters provide the cumulative prior exposure to definitions, identification practice, and simple analysis that Class 12 deepens.
c12_hin_a_cbse_05_001: Irony and symbolism (breaking the wheel as liberation) are foreshadowed.  
c12_hin_a_cbse_05_003: Irony and symbolism node will explore how the setting (field) becomes a symbol of life's furrow.  
c12_hin_a_cbse_05_006: Irony/Symbolism similarly become thematic tools — e.g., the irony of "eternal sun vs. mortal man" serves the time theme.  
c12_hin_a_cbse_05_007: Irony and symbolism often operate at the secondary theme level (e.g., the sickle as symbol of both destruction and care).  
c11_hin_ar_cbse_01_009: Irony is a literary device where the intended meaning of words or events is opposite to th... की समझ आवश्यक है, क्योंकि यह नोड (Irony is a literary device where the intended meaning of words or a situation is opposite...) इसी आधार पर आगे बढ़ता है।  
c11_hin_ar_cbse_02_009: Irony in "फेंकू उल्हनिहु" is the contrast between appearance and reality where Phenku's ma... की समझ आवश्यक है, क्योंकि यह नोड (Irony is a literary device where the intended meaning of words or a situation is opposite...) इसी आधार पर आगे बढ़ता है।  
c11_hin_ar_cbse_03_009: Irony is a literary device where there is a contrast between expectation and reality—what... की समझ आवश्यक है, क्योंकि यह नोड (Irony is a literary device where the intended meaning of words or a situation is opposite...) इसी आधार पर आगे बढ़ता है।  
c11_hin_ar_cbse_04_009: Irony (व्यंग्य) is a literary device in which the intended meaning of a statement, situati... की समझ आवश्यक है, क्योंकि यह नोड (Irony is a literary device where the intended meaning of words or a situation is opposite...) इसी आधार पर आगे बढ़ता है।  
c11_hin_ar_cbse_05_009: Irony is a literary device where the intended meaning of words or events is opposite to th... की समझ आवश्यक है, क्योंकि यह नोड (Irony is a literary device where the intended meaning of words or a situation is opposite...) इसी आधार पर आगे बढ़ता है।  
c11_hin_ar_cbse_06_009: Irony is a literary device where the intended meaning of words or events is opposite to th... की समझ आवश्यक है, क्योंकि यह नोड (Irony is a literary device where the intended meaning of words or a situation is opposite...) इसी आधार पर आगे बढ़ता है।  
c11_hin_ar_cbse_07_009: Irony is a literary device where the intended meaning of words or events is opposite to th... की समझ आवश्यक है, क्योंकि यह नोड (Irony is a literary device where the intended meaning of words or a situation is opposite...) इसी आधार पर आगे बढ़ता है।  
c11_hin_ar_cbse_08_009: Irony is a literary device where the intended meaning of words or situations contrasts sha... की समझ आवश्यक है, क्योंकि यह नोड (Irony is a literary device where the intended meaning of words or a situation is opposite...) इसी आधार पर आगे बढ़ता है।  
c11_hin_ar_cbse_09_009: Irony is a literary device where the intended meaning of words or situations is opposite t... की समझ आवश्यक है, क्योंकि यह नोड (Irony is a literary device where the intended meaning of words or a situation is opposite...) इसी आधार पर आगे बढ़ता है।  
c11_hin_ar_cbse_10_009: Irony in Kabir's poetry is the deliberate contrast between surface meaning and deeper spir... की समझ आवश्यक है, क्योंकि यह नोड (Irony is a literary device where the intended meaning of words or a situation is opposite...) इसी आधार पर आगे बढ़ता है।  
c11_hin_ar_cbse_11_009: Irony is a literary device where the intended meaning of words is opposite to their litera... की समझ आवश्यक है, क्योंकि यह नोड (Irony is a literary device where the intended meaning of words or a situation is opposite...) इसी आधार पर आगे बढ़ता है।  
c11_hin_ar_cbse_12_009: Irony in this poem is the contrast between the postman's role as a deliverer of written co... की समझ आवश्यक है, क्योंकि यह नोड (Irony is a literary device where the intended meaning of words or a situation is opposite...) इसी आधार पर आगे बढ़ता है।  
c11_hin_ar_cbse_13_009: Irony is a literary device where there is a contradiction between appearance and reality,... की समझ आवश्यक है, क्योंकि यह नोड (Irony is a literary device where the intended meaning of words or a situation is opposite...) इसी आधार पर आगे बढ़ता है।  
c11_hin_ar_cbse_14_009: Irony is a literary device where the intended meaning of words or events is opposite to th... की समझ आवश्यक है, क्योंकि यह नोड (Irony is a literary device where the intended meaning of words or a situation is opposite...) इसी आधार पर आगे बढ़ता है।  
c11_hin_ar_cbse_15_009: Irony in this poem is the sustained contrast between the speaker's repeated denial ("lcls... की समझ आवश्यक है, क्योंकि यह नोड (Irony is a literary device where the intended meaning of words or a situation is opposite...) इसी आधार पर आगे बढ़ता है।  
c11_hin_ar_cbse_16_009: Irony is a literary device where the intended meaning of words or situations is opposite t... की समझ आवश्यक है, क्योंकि यह नोड (Irony is a literary device where the intended meaning of words or a situation is opposite...) इसी आधार पर आगे बढ़ता है।  
c11_hin_v_cbse_01_009: Irony (व्यंग्य) is a literary device where the intended meaning of words or situations is... की समझ आवश्यक है, क्योंकि यह नोड (Irony is a literary device where the intended meaning of words or a situation is opposite...) इसी आधार पर आगे बढ़ता है।  
c11_hin_v_cbse_02_009: Irony (विडंबना) is a literary device where the intended meaning of words or events contrad... की समझ आवश्यक है, क्योंकि यह नोड (Irony is a literary device where the intended meaning of words or a situation is opposite...) इसी आधार पर आगे बढ़ता है।  
c11_hin_v_cbse_03_009: Irony is a literary device where the intended meaning of words or situations differs signi... की समझ आवश्यक है, क्योंकि यह नोड (Irony is a literary device where the intended meaning of words or a situation is opposite...) इसी आधार पर आगे बढ़ता है।  
c11_hin_v_cbse_04_009: Irony (विडंबना/व्यंग्य) is a literary device where the intended meaning of words or situat... की समझ आवश्यक है, क्योंकि यह नोड (Irony is a literary device where the intended meaning of words or a situation is opposite...) इसी आधार पर आगे बढ़ता है।  
c11_hin_v_cbse_05_009: Irony is a literary device where the intended meaning of words or events is opposite to th... की समझ आवश्यक है, क्योंकि यह नोड (Irony is a literary device where the intended meaning of words or a situation is opposite...) इसी आधार पर आगे बढ़ता है।  

## FORWARD_NODE_IDS
c12_hin_a_cbse_05_010, c12_hin_a_cbse_05_013, c12_hin_a_cbse_05_014, c12_hin_a_cbse_05_012

## FORWARD_REASONS
c12_hin_a_cbse_05_010: Vocabulary in Context requires recognizing how ironic word-choice and symbolic lexicon shape meaning.
c12_hin_a_cbse_05_013: Critical Thinking demands the ability to argue how irony and symbolism construct the chapter's themes.
c12_hin_a_cbse_05_014: Writing Skills expects students to embed device-analysis in formal answers using the PEEL structure practiced here.
c12_hin_a_cbse_05_012: Irony/symbolism recognition prevents literal reading of non-literal devices  

## CROSS_SUBJECT_PREREQS
c11_hin_ar_cbse_01_013, c11_hin_ar_cbse_02_013, c11_hin_ar_cbse_03_013, c11_hin_ar_cbse_04_013, c11_hin_ar_cbse_05_013, c11_hin_ar_cbse_06_013, c11_hin_ar_cbse_07_013, c11_hin_ar_cbse_08_013, c11_hin_ar_cbse_09_013, c11_hin_ar_cbse_10_013, c11_hin_ar_cbse_11_013, c11_hin_ar_cbse_12_013, c11_hin_ar_cbse_13_013, c11_hin_ar_cbse_14_013, c11_hin_ar_cbse_15_013, c11_hin_ar_cbse_16_013, c11_hin_v_cbse_01_013, c11_hin_v_cbse_02_013, c11_hin_v_cbse_03_013, c11_hin_v_cbse_04_013, c11_hin_v_cbse_05_013
## CROSS_SUBJECT_REASONS
c11_hin_ar_cbse_01_013 through c11_hin_v_cbse_05_013: Critical Thinking nodes across Class 11 chapters trained students in the analytical moves (evidence → inference → thematic claim) that this node now applies specifically to irony and symbolism.
c11_hin_ar_cbse_01_013: अन्य विषय की सहायता: Critical thinking in literary analysis involves examining a text beyond its literal meanin... के तत्व इस नोड में प्रयुक्त होते हैं।  
c11_hin_ar_cbse_02_013: अन्य विषय की सहायता: Critical thinking in literary analysis involves systematically examining a text's componen... के तत्व इस नोड में प्रयुक्त होते हैं।  
c11_hin_ar_cbse_03_013: अन्य विषय की सहायता: Critical thinking in literary analysis is the systematic process of examining a text's exp... के तत्व इस नोड में प्रयुक्त होते हैं।  
c11_hin_ar_cbse_04_013: अन्य विषय की सहायता: Critical Thinking: के तत्व इस नोड में प्रयुक्त होते हैं।  
c11_hin_ar_cbse_05_013: अन्य विषय की सहायता: Critical Thinking: के तत्व इस नोड में प्रयुक्त होते हैं।  
c11_hin_ar_cbse_06_013: अन्य विषय की सहायता: Critical Thinking: के तत्व इस नोड में प्रयुक्त होते हैं।  
c11_hin_ar_cbse_07_013: अन्य विषय की सहायता: Critical Thinking: के तत्व इस नोड में प्रयुक्त होते हैं।  
c11_hin_ar_cbse_08_013: अन्य विषय की सहायता: Critical Thinking: के तत्व इस नोड में प्रयुक्त होते हैं।  
c11_hin_ar_cbse_09_013: अन्य विषय की सहायता: Critical Thinking: के तत्व इस नोड में प्रयुक्त होते हैं।  
c11_hin_ar_cbse_10_013: अन्य विषय की सहायता: Critical Thinking: के तत्व इस नोड में प्रयुक्त होते हैं।  
c11_hin_ar_cbse_11_013: अन्य विषय की सहायता: Critical thinking in literary analysis is the disciplined process of examining a text's st... के तत्व इस नोड में प्रयुक्त होते हैं।  
c11_hin_ar_cbse_12_013: अन्य विषय की सहायता: Critical thinking in literary analysis is the disciplined process of actively examining a... के तत्व इस नोड में प्रयुक्त होते हैं।  
c11_hin_ar_cbse_13_013: अन्य विषय की सहायता: Critical thinking in literary analysis is the disciplined process of examining a text's co... के तत्व इस नोड में प्रयुक्त होते हैं।  
c11_hin_ar_cbse_14_013: अन्य विषय की सहायता: Critical Thinking: के तत्व इस नोड में प्रयुक्त होते हैं।  
c11_hin_ar_cbse_15_013: अन्य विषय की सहायता: Critical thinking in literary analysis is the disciplined process of examining a text's ex... के तत्व इस नोड में प्रयुक्त होते हैं।  
c11_hin_ar_cbse_16_013: अन्य विषय की सहायता: Critical thinking in literary analysis involves examining a text beyond its literal meanin... के तत्व इस नोड में प्रयुक्त होते हैं।  
c11_hin_v_cbse_01_013: अन्य विषय की सहायता: Critical thinking in literary analysis is the disciplined process of examining a text's ar... के तत्व इस नोड में प्रयुक्त होते हैं।  
c11_hin_v_cbse_02_013: अन्य विषय की सहायता: Critical Thinking: के तत्व इस नोड में प्रयुक्त होते हैं।  
c11_hin_v_cbse_03_013: अन्य विषय की सहायता: Critical Thinking: के तत्व इस नोड में प्रयुक्त होते हैं।  
c11_hin_v_cbse_04_013: अन्य विषय की सहायता: Critical Thinking: के तत्व इस नोड में प्रयुक्त होते हैं।  
c11_hin_v_cbse_05_013: अन्य विषय की सहायता: Critical thinking in literary analysis refers to the ability to examine a text beyond its... के तत्व इस नोड में प्रयुक्त होते हैं।  

## CHAIN_DESCRIPTION
c12_hin_a_cbse_05_008 -> c12_hin_a_cbse_05_009 -> c12_hin_a_cbse_05_013

## THIS_FORMULA
N/A - conceptual

## FORMULA_VARIABLES
N/A

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
analytical

## CROSS_SUBJECT
N/A | Both subjects require identifying and analyzing irony/symbolism in poetry; the analytical framework (device → evidence → effect → theme) is identical.
 N/A | The poems' themes of aging, denial, and meaning-making connect directly to developmental psychology concepts (e.g., Erikson's integrity vs. despair), allowing interdisciplinary literary-psychological analysis.
## PREREQ_CONCEPT
Distinguishing literal from figurative meaning and recognizing that literary devices are deliberate authorial choices, not accidental decorations.

## PREREQ_BEFORE
Student must be able to define irony (three types) and symbolism, and locate at least one example of each in any previously studied poem.

## PREREQ_STUCK
If stuck, revisit the "Symbol Test" (recurrence + semantic shift + thematic link) and the "Irony Triangle" (expectation vs. reality vs. awareness) from Class 11 notes.

## WORKED_EXAMPLE_1
PROBLEM: Analyze the verbal irony in the old man's address to death in "Olar Vak" (stanza 3) and explain how it reveals his psychological state.

STEPS:
- Step 1: Locate the exact lines where the old man speaks to death (e.g., "Aa ja, mere dost" — "Come, my friend"). Note the affectionate diction ("dost", "priya").
- Step 2: Identify the expectation created by the words: friendship implies welcome, warmth, mutual desire.
- Step 3: Contrast with the reality shown in the same stanza: his body "shrinks" (simtā), "trembles" (kāmpatā), "turns away" (muṛ jātā). The physical recoil contradicts the verbal embrace.
- Step 4: Name the device: verbal irony — the speaker says the opposite of what he feels/does.
- Step 5: Interpret the psychological function: the irony exposes denial. By calling death a friend, the old man attempts to master the terror he cannot control; the gap between word and body measures the depth of that terror.
- Step 6: Connect to theme: this moment crystallizes the poem's central tension — the human need to narrativize mortality versus the biological reality that refuses the narrative.

REASONING: The six-step method (locate → expect → contrast → name → interpret → connect) moves from textual evidence to thematic insight, which is exactly the trajectory board examiners reward.

ANSWER: The old man's "Come, my friend" is verbal irony because his welcoming words are belied by his body's terror (shrinking, trembling, turning away). This irony reveals his desperate denial: he masks existential dread with a fabricated friendship, trying to domesticate the undomesticatable. The poem thus uses irony not for wit but for tragic characterization.

## WORKED_EXAMPLE_2
PROBLEM: Trace the symbol of the "house" (ghar) across the three stanzas of "Raksaks" and explain how its evolving meaning structures the poem's argument.

STEPS:
- Step 1: Stanza 1 — list concrete details associated with "ghar": "walls" (dīvārẽ), "roof" (chhat), "doors" (darvāze), "courtyard" (āṅgan). At this level, the house is a physical shelter, a material project.
- Step 2: Stanza 2 — note the shift to abstract possessions: "heart's walls" (dil kī dīvārẽ), "memory's roof" (yādõ kī chhat), "hope's doors" (āśā ke darvāze). The house has become a metaphor for inner architecture — emotional security, identity, continuity.
- Step 3: Stanza 3 — observe the culminating irony: "When the house is ready / we burn it" (jab ghar taiyār hotā hai / use jala dete haiṁ). The symbol now fuses construction and destruction; the house is both life's work and its own pyre.
- Step 4: Synthesize the trajectory: physical → psychological → existential. Each stanza adds a semantic layer without discarding the previous ones (the physical house still exists while the metaphorical one is built).
- Step 5: Argue the structural role: the symbol *is* the poem's argument. The refrain "Raksaks" gains meaning only because the symbol accumulates weight; the final burning retroactively redefines all prior building as both necessary and futile.
- Step 6: Link to theme: the house symbolizes the human project of meaning-making — we build identities (stanza 2) on material foundations (stanza 1) knowing they will be consumed by time (stanza 3).

REASONING: Symbol-tracking requires stanza-by-stanza close reading followed by synthesis. The three-stage trajectory mirrors the poem's structure and demonstrates how a single symbol can carry an entire philosophical argument.

ANSWER: The "house" evolves from literal shelter (stanza 1) to metaphorical self (stanza 2) to existential paradox (stanza 3 — built only to be burned). This layered symbol structures the poem's argument: human life is a construction project whose completion is its own destruction. The refrain "Raksaks" echoes the labor; the final burning silences it.

## WORKED_EXAMPLE_3
PROBLEM: Compare how "Olar Vak" and "Raksaks" use irony and symbolism together to portray the inevitability of aging. Write a structured comparative paragraph.

STEPS:
- Step 1: Identify the core irony in each poem. "Olar Vak": verbal/situational irony of the old man's failed friendship with death. "Raksaks": structural irony of the refrain — building chant becomes funeral dirge.
- Step 2: Identify the core symbol in each. "Olar Vak": the "morning" (prabhāt) — recurring, indifferent, symbolizing nature's cyclical renewal that mocks human linear decline. "Raksaks": the "house" — as analyzed above.
- Step 3: Analyze interaction. In "Olar Vak", irony *exposes* the gap between the old man's narrative (death as friend) and the symbol's testimony (morning as indifferent renewal). In "Raksaks", irony *resides inside* the symbol — the house is both built and burned, the symbol itself is ironic.
- Step 4: Evaluate combined effect. "Olar Vak" uses irony and symbol side-by-side to create tragic pathos; "Raksaks" fuses them into a single symbol-irony complex that is more philosophically dense.
- Step 5: Draft the paragraph using PEEL: Point (both poems fuse irony and symbolism to portray aging's inevitability), Evidence (cite specific irony + symbol from each), Explanation (analyze interaction), Link (conclude that "Raksaks" achieves tighter integration).
- Step 6: Refine for board-exam language: use terms "verbal irony", "structural irony", "central symbol", "semantic layering", "thematic convergence".

REASONING: Comparative analysis at Class 12 level requires not just listing devices but showing how they *interact* differently across texts. The six-step method ensures methodological rigor and exam-ready articulation.

ANSWER: Both poems portray aging's inevitability through irony-symbol interplay, but with different architectures. In "Olar Vak", verbal irony (the old man's false friendship with death) stands beside the symbol of indifferent morning — nature's cyclical renewal mocks his linear wait, creating tragic dissonance. In "Raksaks", structural irony is embedded *within* the central symbol: the house is simultaneously life's construction and its own pyre, fusing irony and symbolism into a single paradox. The former uses devices in counterpoint; the latter achieves synthesis, making "Raksaks" the more philosophically compact portrayal of aging as a project that builds its own negation.

## COMPETENCY_QUESTION_1
QUESTION: "The old man in 'Olar Vak' calls death 'my dear friend' while his body trembles. The refrain in 'Raksaks' chants 'Build, build, build' for a house that will be burned. Using these two examples, explain how irony functions differently when it operates *through language* versus *through structure*."

COMPETENCY: Literary Analysis — Distinguishing Verbal vs. Structural Irony and Explaining Their Distinct Effects

STEPS:
- Step 1: Define verbal irony (language-level: saying opposite of what is meant) and structural irony (pattern-level: recurring form contradicts its apparent purpose).
- Step 2: Apply to "Olar Vak": the phrase "mere dost" is verbal irony — the gap is between word and feeling in a single utterance.
- Step 3: Apply to "Raksaks": the refrain "Raksaks" is structural irony — the gap is between the chant's constructive energy and the poem's destructive trajectory, revealed only across the whole text.
- Step 4: Contrast effects: verbal irony characterizes the speaker's psychology (denial); structural irony enacts the poem's philosophy (futility of human project).
- Step 5: Conclude with a synthesizing sentence about the two modes of ironic truth-telling.

ANSWER: Verbal irony in "Olar Vak" ("mere dost") operates at the micro-level of utterance: the old man's words betray his terror, exposing individual denial. Structural irony in "Raksaks" ("Raksaks, raksaks") operates at the macro-level of form: the building chant's rhythm persists even as the poem reveals the house's fate as a pyre, enacting the futility of all human construction. The first reveals a character's mind; the second reveals a condition of existence.

DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: A student claims: "In 'Raksaks', the axe (kulhārī) is a symbol of death because it cuts wood for the pyre." Evaluate this claim using the criteria for identifying a literary symbol. Then, propose a *better* symbol from the poem for mortality and justify your choice with textual evidence.

COMPETENCY: Critical Evaluation — Applying Symbol-Identification Criteria and Constructing a Counter-Argument with Evidence

STEPS:
- Step 1: State the three criteria for a literary symbol: (a) recurrence, (b) semantic shift/deepening, (c) thematic centrality.
- Step 2: Test the axe against each: appears only once (stanza 1), no semantic shift (remains a tool), peripheral to theme (construction, not mortality). Claim fails.
- Step 3: Propose the "house" (ghar) as the superior symbol for mortality.
- Step 4: Demonstrate how the house meets all three criteria: recurs in all three stanzas; shifts from physical → emotional → existential; structurally central (title refrain addresses it).
- Step 5: Add a nuance: the house's final transformation into pyre *is* the poem's statement on mortality — no separate death-symbol needed.

ANSWER: The claim fails because the axe appears once, carries no layered meaning, and serves the construction theme, not mortality. The house is the true mortality-symbol: it recurs across stanzas, deepens from shelter to self to pyre, and the poem's architecture revolves around it. The house *becomes* the pyre — mortality is not represented by a separate object but enacted by the symbol's own trajectory.

DIFFICULTY: hard