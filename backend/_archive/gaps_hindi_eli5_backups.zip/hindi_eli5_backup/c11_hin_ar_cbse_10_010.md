## DEFINITION
Vocabulary in Context is the skill of determining the meaning of unfamiliar or key words by analyzing the surrounding text, including syntactic clues, semantic associations, and the overall thematic atmosphere of the poem.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student can independently identify at least five key words from the poem, explain their contextual meanings with textual evidence, and articulate how each word's connotation shapes the poem's emotional tone and thematic depth.

## SCOPE_BOUNDARY
This node covers only the key vocabulary from Ehjk's poem in Chapter 10 (Aroh), focusing on context-based meaning inference and literary effect. It does not cover general dictionary skills, grammar rules, or vocabulary from other chapters.

## WALKTHROUGH
Imagine you are reading a poem and stumble on the word "dkfu" – you don't know it, but the line says "laru f<x cSfB&cSfB] yksd&ykt [kks;h". Ask yourself: what words surround it? What is the poet describing? Start by reading the stanza aloud to hear the rhythm. Then underline the unknown word and circle the words that give clues (like "yksd&ykt" suggesting folk simplicity). Next, check the glossary provided in the textbook. Finally, ask: why did the poet choose this specific word instead of a simpler synonym? The key insight is that in poetry, every word carries layers of cultural and emotional weight that a dictionary alone cannot reveal.

## DIAGNOSTIC_QUESTION_1
What is the primary strategy for determining the meaning of a key word in a poem when a dictionary definition is insufficient?

## DIAGNOSTIC_ANSWER_1
The primary strategy is to analyze the immediate linguistic context (surrounding words, syntax) and the broader thematic context (the poem's subject, tone, imagery) to infer the word's connotative meaning. A wrong answer that says "look it up in a dictionary" reveals the student relies solely on denotative meaning and misses the poetic nuance that context provides.

## DIAGNOSTIC_QUESTION_2
In the line "valqou ty lhafp&lhafp] izse&csfy cks;h", the word "csfy" is glossed as "izse dh csy". Explain in your own words why the poet might have chosen the compound "izse&csfy" instead of just "izse".

## DIAGNOSTIC_ANSWER_2
The compound "izse&csfy" (evening-shadow) evokes a specific visual and temporal atmosphere – the lengthening shadows of evening – which "izse" alone (evening) does not. It suggests a lingering, fading light that mirrors the poem's mood of longing. A wrong answer that says "they mean the same thing" shows the student does not grasp how compound words in Hindi poetry compress imagery and emotion.

## DIAGNOSTIC_QUESTION_3
Given the line "nfèk efFk ?k`r dkf<+ fy;ks] Mkfj n;h Nks;h", use context clues to deduce the meaning of "Nks;h" and explain how it contrasts with "fy;ks" in the same line.

## DIAGNOSTIC_ANSWER_3
"Nks;h" (from glossary: NkN, lkjghu va'k) means a deep, resonant sound or cry, while "fy;ks" means to speak/say. The contrast highlights the intensity of the moment: ordinary speech ("fy;ks") versus a primal, heart-wrenching cry ("Nks;h"). A wrong answer that defines "Nks;h" merely as "sound" misses the emotional weight and the deliberate contrast the poet creates.

## DIAGNOSTIC_QUESTION_4
Compare the effect of the word pair "eksj&eqoqQV" (in the first line) with "yksd&ykt" (in the second line). How do these compound words reflect two different worlds in the poem?

## DIAGNOSTIC_ANSWER_4
"eksj&eqoqQV" (beloved's playful gestures) conveys intimate, personal romance, while "yksd&ykt" (folk/simple, natural) evokes a communal, rustic simplicity. Together they juxtapose the private world of love with the public world of folk tradition. A wrong answer that treats them as mere adjectives fails to see the structural contrast the poet builds between elite courtly culture and folk authenticity.

## DIAGNOSTIC_QUESTION_5
Critique the following student interpretation: "The word 'foyks;h' (glossed as eFkh) simply means happiness, so the line 'nwèk dh eFkfu;k¡ cM+s izse ls foyks;h' means new happinesses are sheltered from the big evening." Is this interpretation adequate? Why or why not?

## DIAGNOSTIC_ANSWER_5
The interpretation is inadequate because "foyks;h" in context means "shelter/protection" (eFkh) not "happiness". The line actually means "the joys of the new (bride) are sheltered/protected from the great evening (of life's sorrows)". The student confused the gloss "eFkh" (which is the meaning of foyks;h) with the word "eFkfu;k¡" (joys). This reveals a failure to distinguish between the key word and its gloss, and to parse the grammatical structure.

## DIAGNOSTIC_QUESTION_6
Create a two-line Hindi couplet (dohe) using at least two key words from the poem (e.g., dkfu, csfy, foyks;h, Nks;h) that captures the poem's theme of love transcending social barriers. Explain your word choices.

## DIAGNOSTIC_ANSWER_6
A good answer would produce a couplet like: "dkfu bhul jaat sab, csfy base man maah; foyks;h mile prem ko, jagat mein yehi raah." And explain: "dkfu" (folk song) represents the voice of the people, "csfy" (evening shadow) symbolizes the fading of rigid norms, "foyks;h" (shelter) shows love's protection. A poor answer would use the words mechanically without connecting them to the theme, showing superficial engagement.

## COMMON_MISCONCEPTION
Students often think that the glossary meanings provided in the textbook (e.g., "dkfu = e;kZnk") are the only meanings needed, and that the word's function in the poem is exhausted by that synonym. They fail to see that in poetry, a word like "dkfu" carries cultural resonance (folk song tradition), metrical value, and emotional associations that the gloss "e;kZnk" (folk song) only partially captures. For example, they might write "dkfu means folk song" and stop, missing how "dkfu" evokes the oral tradition of the common people, contrasting with classical Sanskritized poetry.

## ON_FAILURE
1. Have the student read the stanza aloud three times, emphasizing the key word each time. 2. Ask: "What images, sounds, or feelings come to mind when you hear this word in this line?" 3. Together, list all words in the stanza that relate to the key word (e.g., for "dkfu": yksd, ykt, [kks;h). 4. Guide the student to write a "word portrait": a 3-sentence description of the word's personality in this poem (e.g., "dkfu is a rustic, honest voice that speaks without ornament"). 5. Finally, ask the student to replace the key word with its gloss and read again – discuss what is lost.

## BUILDS_ON
This node builds on the student's ability to identify literary devices (imagery, metaphor) from nodes c11_hin_ar_cbse_10_008 and c11_hin_ar_cbse_10_009, as vocabulary analysis requires recognizing how words create those devices.

## LEADS_TO
This node enables the grammar node (c11_hin_ar_cbse_10_011) where students analyze syntactic structures of these key words, and the comprehension node (c11_hin_ar_cbse_10_012) where they answer inferential questions using vocabulary insights.

## PREREQUISITE_NODE_IDS
c11_hin_ar_cbse_10_001, c11_hin_ar_cbse_10_002, c11_hin_ar_cbse_10_008, c11_hin_ar_cbse_10_009
## PREREQUISITE_REASONS
c11_hin_ar_cbse_10_001: Provides historical and cultural context of Ehjk and the Bhakti movement, essential for understanding the connotations of words like "dkfu" and "yksd".
c11_hin_ar_cbse_10_002: Familiarity with the poem's narrative structure helps locate where key words appear and their dramatic function.
c11_hin_ar_cbse_10_008: Understanding imagery allows students to see how key words like "csfy" and "lhafp&lhafp" build visual pictures.
c11_hin_ar_cbse_10_009: Knowledge of irony and symbolism helps students grasp why the poet chooses simple folk words ("dkfu", "yksd") to convey profound spiritual love.

## FORWARD_NODE_IDS
c11_hin_ar_cbse_10_011, c11_hin_ar_cbse_10_012, c11_hin_ar_cbse_10_013, c11_hin_ar_cbse_10_014, c11_hin_ar_cbse_10_015, c12_hin_a_cbse_07_010, c12_hin_ar_cbse_10_010, c12_hin_ar_cbse_12_010, c12_hin_a_cbse_09_010

## FORWARD_REASONS
c11_hin_ar_cbse_10_011: Vocabulary mastery allows analysis of grammatical forms (e.g., compound formation in "izse&csfy").
c11_hin_ar_cbse_10_012: Inferential comprehension questions often hinge on precise understanding of key words.
c11_hin_ar_cbse_10_013: Critical interpretation requires evaluating how word choice shapes meaning.
c11_hin_ar_cbse_10_014: Writing tasks (e.g., character sketch, theme essay) demand precise vocabulary usage.
c11_hin_ar_cbse_10_015: Discussion points rely on students articulating nuances of key terms.
c12_hin_a_cbse_07_010: Linked vocabulary choices to theme of separation (viraha).  
c12_hin_ar_cbse_10_010: Vocabulary in Context: Key Words (Class 11) introduced the core strategy of context-clue analysis; this node deepens it for board-level complexity.  
c12_hin_ar_cbse_12_010: Practiced creating original sentences with contextual nuance — Diagnostic Q6 skill.  
c12_hin_a_cbse_09_010: poet." If unable to do step 4, revisit Class 11 node c11_hin_ar_cbse_09_010 (Kabir vocabulary) and c11_hin_ar_cbse_10_010 (Surdas vocabulary) to compare Nirguna vs Saguna lexicon.  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
none

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_10_001 -> c11_hin_ar_cbse_10_010 -> c11_hin_ar_cbse_10_011

## THIS_FORMULA
N/A - conceptual

## FORMULA_VARIABLES
N/A

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
linguistic

## CROSS_SUBJECT
c11_history_bhakti_movement | The poem reflects the Bhakti movement's emphasis on vernacular language and folk forms; understanding key words like "dkfu" (folk song) requires knowledge of this historical context.
c11_sociology_social_stratification | The contrast between courtly language ("eksj&eqoqQV") and folk language ("yksd&ykt") mirrors social stratification in medieval India, a concept studied in sociology.

## PREREQ_CONCEPT
Ability to use context clues (syntactic, semantic, thematic) to infer word meaning in literary texts.

## PREREQ_BEFORE
Student must have read the poem at least twice and be familiar with the textbook glossary.

## PREREQ_STUCK
If stuck, review the concept of "context clues" from Class 10 Hindi (or English) and practice with simpler poems.

## WORKED_EXAMPLE_1
PROBLEM: Analyze the key word "dkfu" in the first stanza of Ehjk's poem. Explain its contextual meaning, its cultural connotations, and its contribution to the poem's theme.

STEPS:
- Step 1: Locate the word "dkfu" in the first line of the poem: "esjs rks fxjèkj xksiky] nwljks u dksbZ tk osQ flj eksj&eqoqQV] esjks ifr lksbZ NkafM+ n;h oqQy dh dkfu".
- Step 2: Examine the immediate context: "oqQy dh dkfu" – the word is part of a possessive phrase describing something belonging to "oqQy" (tradition/custom). The preceding words "eksj&eqoqQV" (beloved's playful gestures) contrast with "oqQy dh dkfu".
- Step 3: Consult the textbook glossary: "dkfu = e;kZnk" (folk song). Note that "e;kZnk" itself implies a song of the people, oral, traditional.
- Step 4: Analyze cultural connotations: In the Bhakti tradition, "dkfu" represents the voice of the common folk, as opposed to classical Sanskrit poetry. Ehjk, a Bhakti poet, uses this word to align his expression with the masses.
- Step 5: Connect to theme: The poet rejects elite courtly love ("eksj&eqoqQV") and embraces the folk tradition ("oqQy dh dkfu") as the true vehicle for divine love. The word "dkfu" thus becomes a symbol of democratic devotion.

REASONING: These steps move from textual location to dictionary support, then to cultural-historical context, and finally to thematic synthesis – mirroring the analytical process expected in board exams.

ANSWER: "dkfu" contextually means a folk song rooted in tradition ("oqQy"). Its connotations include orality, communal ownership, simplicity, and authenticity. In the poem, it signifies the poet's choice of the folk idiom over courtly sophistication to express love for the divine, reinforcing the theme of accessible, egalitarian devotion.

## WORKED_EXAMPLE_2
PROBLEM: The word "csfy" appears in the compound "izse&csfy" (line 2). Determine its meaning from context, explain the imagery created by the compound, and state its emotional effect.

STEPS:
- Step 1: Find the line: "laru f<x cSfB&cSfB] yksd&ykt [kks;h valqou ty lhafp&lhafp] izse&csfy cks;h".
- Step 2: Identify the compound "izse&csfy". The glossary gives "csfy = izse dh csy" (shadow of evening). "izse" means evening.
- Step 3: Visualize the imagery: "lhafp&lhafp" (trembling/shimmering) light, "ty" (lake/water) – the evening shadows are trembling on the water. The compound compresses "evening" and "shadow" into a single vivid image.
- Step 4: Analyze emotional effect: Evening shadows suggest the approach of darkness, transience, and a quiet melancholy. The trembling ("lhafp&lhafp") adds fragility. This mirrors the poet's inner state – a heart trembling with longing as the "evening" of separation approaches.
- Step 5: Relate to the poem's progression: The first line speaks of the beloved's playfulness; the second line shifts to a natural scene that reflects the poet's mood. "izse&csfy" marks this shift from external description to internal reflection.

REASONING: The steps demonstrate how to unpack a compound word, visualize its imagery, and connect it to the poem's emotional arc – a core skill for literary analysis.

ANSWER: "csfy" means "shadow" specifically of evening. The compound "izse&csfy" creates an image of trembling evening shadows on water, evoking transience and melancholy. It functions as an objective correlative for the poet's trembling heart, deepening the theme of love's vulnerability.

## WORKED_EXAMPLE_3
PROBLEM: Compare the words "foyks;h" (line 3) and "Nks;h" (line 4). Both are glossed as nouns (foyks;h = eFkh, Nks;h = NkN, lkjghu va'k). Analyze how their grammatical roles and connotations differ, and how they together structure the poem's emotional climax.

STEPS:
- Step 1: Locate both words. "foyks;h" in line 3: "nwèk dh eFkfu;k¡ cM+s izse ls foyks;h". "Nks;h" in line 4: "nfèk efFk ?k`r dkf<+ fy;ks] Mkfj n;h Nks;h".
- Step 2: Determine grammatical role. "foyks;h" appears as a predicate adjective/noun after "cM+s izse ls" (sheltered from the great evening) – it describes the state of "eFkfu;k¡" (joys). "Nks;h" appears at the end of the line as a noun, the object of the implied verb (the cry that is let out).
- Step 3: Contrast connotations. "foyks;h" (shelter/protection) suggests safety, maternal care, enclosure. "Nks;h" (deep cry/resonant sound) suggests release, breaking out, raw emotion.
- Step 4: Trace emotional arc. Line 3: the new bride's joys are *protected* from life's sorrows (evening). Line 4: the heart (?k`r) bursts into a deep cry (Nks;h) – the protection fails, raw emotion erupts.
- Step 5: Synthesize. The movement from "foyks;h" (containment) to "Nks;h" (explosion) structures the stanza's climax: the tension between social decorum (sheltered joys) and authentic feeling (uncontrollable cry).
- Step 6: Connect to Ehjk's style. This tension between restraint and expression is central to Ehjk's poetry, reflecting the Bhakti ideal of love that transcends social norms.

REASONING: This example requires multi-step grammatical analysis, semantic contrast, and structural synthesis – combining vocabulary, grammar, and literary interpretation.

ANSWER: "foyks;h" (shelter) functions as a protective stasis, describing the joys' condition. "Nks;h" (deep cry) functions as a climactic release, the heart's authentic utterance. Their opposition – containment vs. eruption – creates the stanza's emotional turning point, embodying the poem's theme of love breaking through social barriers.

## COMPETENCY_QUESTION_1
QUESTION: A student writes: "In Ehjk's poem, the word 'dkfu' means 'folk song' (e;kZnk). This shows the poet liked folk music." Evaluate this statement. What is missing from this analysis? Rewrite it as a board-exam quality answer.

COMPETENCY: Critical analysis of vocabulary in context – evaluating a peer's interpretation and constructing an improved response.

STEPS:
- Step 1: Identify the weakness: the statement only gives the denotative meaning (gloss) and a trivial inference ("liked folk music"). It ignores connotation, contrast, and thematic function.
- Step 2: Recall the context: "dkfu" appears in "oqQy dh dkfu" contrasted with "eksj&eqoqQV" (courtly love gestures).
- Step 3: Articulate the deeper significance: "dkfu" represents the Bhakti poet's deliberate choice of the vernacular, oral tradition to express divine love, rejecting elite Sanskritized aesthetics.
- Step 4: Draft the improved answer using the Point-Evidence-Explanation-Link structure.

ANSWER: The statement is reductive. "dkfu" does denote "folk song", but its contextual significance lies in its opposition to "eksj&eqoqQV" (beloved's playful gestures/courtly love). By choosing "oqQy dh dkfu" (the folk song of tradition), Ehjk aligns his poetry with the Bhakti movement's democratization of devotion – using the language of the common people (yksd&ykt) rather than the court. The word thus becomes a symbol of egalitarian spirituality, not merely a musical preference. Board-quality answer: "The word 'dkfu' (folk song) in 'oqQy dh dkfu' is not just a genre label; it marks the poet's conscious rejection of courtly aesthetics ('eksj&eqoqQV') in favor of the vernacular Bhakti tradition. It carries connotations of orality, communal ownership, and authenticity, reinforcing the poem's theme that true devotion arises from the folk soil, not royal courts."

DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: The poem uses two compound words: "eksj&eqoqQV" and "yksd&ykt". A student claims they are just decorative synonyms for "beautiful" and "simple". Using evidence from the poem's vocabulary and structure, refute this claim and explain how these compounds encode a cultural conflict.

COMPETENCY: Analyzing lexical choice as cultural commentary – synthesizing vocabulary, imagery, and historical context.

STEPS:
- Step 1: Decode each compound. "eksj&eqoqQV" = beloved's (eksj) playful gestures (eqoqQV) – associated with courtly, romantic love. "yksd&ykt" = folk (yksd) simple/natural (ykt) – associated with rustic authenticity.
- Step 2: Locate their positions. First line: "eksj&eqoqQV" describes the beloved's actions. Second line: "yksd&ykt [kks;h" describes the manner of seeing/looking.
- Step 3: Identify the conflict. The poet says: "My beloved's courtly playfulness does not attract me; I see through folk simplicity." This is a rejection of elite aesthetics in favor of folk truth.
- Step 4: Connect to Ehjk's biography. Ehjk was a saint-poet who wandered among common people, composing in Braj Bhasha. The vocabulary reflects his life choice.
- Step 5: Formulate the refutation. The compounds are not decorative; they are ideological markers. "eksj&eqoqQV" represents the feudal, gendered, performative love of the court. "yksd&ykt" represents the egalitarian, direct, unperformative vision of the Bhakti poet.

ANSWER: The claim is false. "eksj&eqoqQV" and "yksd&ykt" are not mere synonyms for "beautiful" and "simple"; they are condensed cultural signifiers. "eksj&eqoqQV" evokes the stylized, hierarchical world of courtly romance where love is a performance. "yksd&ykt" evokes the unmediated, communal world of folk perception where truth is direct. The poem's opening contrast – "nwljks u dksbZ tk osQ flj eksj&eqoqQV] esjks ifr lksbZ NkafM+ n;h oqQy dh dkfu" – explicitly rejects the former for the latter. This lexical choice encodes the Bhakti movement's core conflict: the democratization of spiritual experience against Brahmanical and feudal mediation. The compounds are the vocabulary of that revolution.

DIFFICULTY: hard