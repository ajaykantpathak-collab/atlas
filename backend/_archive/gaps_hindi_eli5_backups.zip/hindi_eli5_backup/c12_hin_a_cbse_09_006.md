## DEFINITION
The primary theme of a literary work is the central, unifying idea or insight about human experience that the author conveys through the narrative, characters, and imagery; the message is the specific perspective or lesson the author intends the reader to derive from that theme. In the context of this poem, the primary theme is the intense longing (viraha) of the devotee for the divine (Krishna) and the transformative power of selfless love (prem) that transcends physical separation, with the message that true devotion requires complete surrender and sees the beloved in every aspect of existence.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student can independently identify the primary theme of the poem, cite at least three specific textual evidences (images, metaphors, emotional shifts) that develop this theme, and articulate the poem's message in their own words while connecting it to the Bhakti tradition's concept of viraha-bhakti.

## SCOPE_BOUNDARY
This node covers the identification and analysis of the *primary* theme and message in the prescribed poem by ?kukuan. It does NOT cover secondary themes (node 007), detailed literary device analysis (nodes 008-009), or vocabulary/grammar (nodes 010-011). It assumes the student has already understood the plot/narrative (node 002), setting (node 003), and character sketches (nodes 004-005).

## WALKTHROUGH
Imagine you are listening to a friend describe a heartbreak — they don't just say "I'm sad"; they describe the empty chair, the song that plays on repeat, the way morning light hurts. A poem's theme works the same way: it's not announced in a label, it's built through accumulated sensory details. Start by reading the poem aloud twice — first for the rhythm and sound, second to mark every image that repeats (eyes, doors, paths, night). Ask: "What emotion do these images *together* create?" Then, connect that emotion to the poet's stated context (the introductory note about ?kukuan's devotion to his guru/lqtku). The key insight: the primary theme emerges from the *pattern* of images, not any single line.

## DIAGNOSTIC_QUESTION_1
What is the definition of 'primary theme' in a poem, and how does it differ from a 'summary of events'?

## DIAGNOSTIC_ANSWER_1
The primary theme is the central abstract idea (e.g., 'the transformative power of longing') that the poem explores through concrete images; a summary merely recounts what happens (e.g., 'the devotee waits at the door'). A wrong answer that gives a plot summary reveals the student conflates *what happens* with *what it means* — they are describing the vehicle, not the destination.

## DIAGNOSTIC_QUESTION_2
In your own words, explain why the poet uses the repeated imagery of 'eyes' (nS/nS) and 'path/door' (l¡ns/lqtku) in the first stanza. What single emotion do these combined images convey?

## DIAGNOSTIC_ANSWER_2
The eyes represent constant watchfulness and the path/door represents the boundary between separation and union; together they convey *anticipatory longing* — the physical manifestation of love that watches and waits. A wrong answer that lists the images without synthesizing them (e.g., "eyes see, doors open") shows the student can identify imagery but cannot perform the *synthesis* required for theme extraction.

## DIAGNOSTIC_QUESTION_3
Apply the 'pattern-of-images' method to the second stanza: the poet uses words like 'vkukdkuh' (speech of separation), 'fugkfjcks' (restlessness), and 'owQdHkjh' (forceful pulling). Identify the pattern and state what aspect of the primary theme this stanza deepens.

## DIAGNOSTIC_ANSWER_3
The pattern shifts from *visual waiting* (stanza 1) to *visceral suffering* (stanza 2) — the body itself becomes a site of separation. This deepens the theme by showing that viraha is not just an emotion but a physical, existential condition. A wrong answer that only translates the words misses the *shift* from external to internal, failing to see how the theme *develops* across stanzas.

## DIAGNOSTIC_QUESTION_4
Analyze the relationship between the poet's biographical context (devotion to guru lqtku, suffering persecution) and the poem's primary theme. How does the personal history *shape* the universal theme?

## DIAGNOSTIC_ANSWER_4
The poet's historical suffering (exile, persecution) becomes the *metaphorical raw material* for the spiritual longing — the physical exile maps onto the soul's exile from the divine. The theme gains authenticity because the poet *lived* the separation he describes. A wrong answer that treats biography as mere 'background info' fails to see that in Bhakti poetry, the poet's life *is* the text; the theme is forged in lived experience.

## DIAGNOSTIC_QUESTION_5
Evaluate this student interpretation: "The poem's message is that if you love someone enough, they will eventually come to you." Is this a valid reading of the poem's message? Justify using textual evidence.

## DIAGNOSTIC_ANSWER_5
Invalid. The poem ends with a *threat* ("dcgw¡ rkS esfj;S iqdkj dku [kksfy gS" — "otherwise I will curse you with such a gaze") and the devotee's agency lies in *her* unwavering gaze, not in the beloved's response. The message is about the *devotee's* power through surrender, not a transactional guarantee of union. A wrong answer that accepts the interpretation reveals a transactional view of devotion, missing the Bhakti ideal of nishkam (selfless) love.

## DIAGNOSTIC_QUESTION_6
Create a four-line stanza in Hindi (or English) that captures the *same primary theme* (viraha as transformative surrender) but uses *modern, urban imagery* (e.g., phone screens, metro doors, traffic lights) instead of the poem's traditional imagery.

## DIAGNOSTIC_ANSWER_6
A strong answer will maintain the *emotional architecture* — watching, waiting, the body remembering, the threat of a final gaze — while translating images (e.g., "Blue light watches the door / Thumb hovers on a name / This wait rewrites my bones / One unread message — and I become the curse"). A poor answer merely describes modern waiting without the *transformative surrender* — it becomes a WhatsApp status, not a poem.

## COMMON_MISCONCEPTION
Students often believe the primary theme is simply "devotion to Krishna" or "love for God" — a *label* they recall from the chapter introduction. They then hunt for lines that *confirm* this label (confirmation bias) instead of letting the poem's *own patterns* (the shift from visual to visceral, the final threat, the guru-reference) *build* a more precise theme: "viraha as a crucible that transforms the devotee's identity." This error costs marks because board answers require *textual derivation* of theme, not paraphrase of the preface.

## ON_FAILURE
1. Have the student re-read *only* the two stanzas (ignoring the preface) and list every concrete noun/verb (eyes, path, door, speech, restlessness, gaze, curse). 2. Group these into two clusters: 'Waiting/Watchfulness' and 'Suffering/Threat'. 3. Ask: "What happens to the devotee *because* of these two clusters?" 4. Guide them to formulate: "The waiting and suffering *redefine* the devotee — she becomes the one who can curse." 5. Only then re-read the preface to see how the poet's life *exemplifies* this derived theme.

## BUILDS_ON
Character analysis of the protagonist (node 004) and supporting characters (node 005) — the theme is enacted *through* the devotee's persona and her address to the absent beloved.

## LEADS_TO
Secondary themes (node 007) such as the guru-disciple dynamic and the social dimension of persecution, which expand but do not replace the primary viraha-theme.

## PREREQUISITE_NODE_IDS
c12_hin_a_cbse_09_001, c12_hin_a_cbse_09_002, c12_hin_a_cbse_09_003, c12_hin_a_cbse_09_004, c12_hin_a_cbse_09_005, c11_hin_ar_cbse_09_006
## PREREQUISITE_REASONS
c12_hin_a_cbse_09_001: Provides the historical/biographical context (poet's exile, guru devotion) essential for grounding the theme in lived experience.
c12_hin_a_cbse_09_002: Establishes the narrative structure (two stanzas = two phases of longing) which the theme analysis maps onto.
c12_hin_a_cbse_09_003: The setting (night, door, path) supplies the spatial imagery that *becomes* the theme's metaphorical vocabulary.
c12_hin_a_cbse_09_004: The protagonist's character (the devotee) is the *vehicle* of the theme; her traits (unwavering, transformative) are the theme in action.
c12_hin_a_cbse_09_005: The absent beloved (Krishna/guru) defines the *object* of longing; the power dynamic shapes the theme's surrender/resistance tension.
c11_hin_ar_cbse_09_006: Class 11 foundation on theme identification in Bhakti poetry (viraha, prem, samarpan) provides the conceptual toolkit.

## FORWARD_NODE_IDS
c12_hin_a_cbse_09_007, c12_hin_a_cbse_09_008, c12_hin_a_cbse_09_009, c12_hin_a_cbse_09_013, c12_hin_a_cbse_09_014, c12_hin_a_cbse_09_015

## FORWARD_REASONS
c12_hin_a_cbse_09_007: Secondary themes (guru-bhakti, social persecution) branch out from the established primary theme.
c12_hin_a_cbse_09_008: Imagery/metaphor analysis (node 008) requires the theme as *organizing principle* — devices serve the theme.
c12_hin_a_cbse_09_009: Irony/symbolism (node 009) like the 'curse' as grace only makes sense *through* the primary theme.
c12_hin_a_cbse_09_013: Critical thinking/interpretation (node 013) builds arguments *on* the thematic foundation established here.
c12_hin_a_cbse_09_014: Primary theme (virah-bhakti) is the mandatory Link in every PEEL paragraph  
c12_hin_a_cbse_09_015: Primary theme (guru-shishya parampara) is the thematic anchor for every discussion thread.  

## CROSS_SUBJECT_PREREQS
c11_hin_ar_cbse_09_006, c11_hin_ar_cbse_01_006
## CROSS_SUBJECT_REASONS
c11_hin_ar_cbse_09_006: Directly provides the Class 11 framework for analyzing primary theme in Bhakti poetry (viraha, guru-bhakti) which this node deepens.
c11_hin_ar_cbse_01_006: The first chapter of Class 11 Antra introduces the concept of 'mukhya bhav' (primary sentiment) in poetry, a prerequisite skill for theme extraction.

## CHAIN_DESCRIPTION
c12_hin_a_cbse_09_005 -> c12_hin_a_cbse_09_006 -> c12_hin_a_cbse_09_007

## THIS_FORMULA
Theme = Σ(Recurring Image Clusters × Emotional Shift Across Stanzas) → Contextualized by Poet's Lived Experience → Articulated as Abstract Insight + Intended Message

## FORMULA_VARIABLES
Recurring Image Clusters: Groups of concrete nouns/verbs that repeat (e.g., eyes, path, door). Emotional Shift: The change in dominant affect from stanza to stanza (e.g., anticipation → visceral suffering). Poet's Lived Experience: Biographical facts that authenticate the theme (exile, persecution). Abstract Insight: The universal human truth derived (viraha as transformation). Intended Message: The poet's directed lesson (surrender empowers).

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
analytical

## CROSS_SUBJECT
N/A | The poem exemplifies the Nirguna/Saguna Bhakti synthesis where personal suffering becomes spiritual metaphor — a core historical phenomenon in medieval Indian religious movements.
 N/A | The poem's imagery (Yamuna, groves, doorways) maps onto the sacred geography of Braj, where physical space is structured by devotional practice — theme and landscape are co-constituted.
## PREREQ_CONCEPT
The concept of *viraha-bhakti* (love-in-separation) as a transformative spiritual path, distinct from transactional prayer.

## PREREQ_BEFORE
Student must have completed nodes 001-005 (context, plot, setting, characters) and possess a working Hindi vocabulary for the poem's key terms (viraha, prem, samarpan, nishkam).

## PREREQ_STUCK
If stuck, revisit the *character analysis of the protagonist* (node 004) — the theme *is* the protagonist's inner journey externalized.

## WORKED_EXAMPLE_1
PROBLEM: Using the poem's first stanza only, derive the primary theme's *initial formulation* (before the second stanza deepens it). Show each step of the image-cluster method.
STEPS:
- Step 1: Read stanza aloud; mark every concrete noun/verb: 'fnuku' (days), 'vklikl ijs' (eyelids), '[kjs' (eyes), 'vjcjfu' (gazing), 'Hkjs' (stay), 'mfB tku' (your path), 'dfg dfg' (repeatedly), 'vkou' (calls), 'Nchys' (draws near), 'euHkkou' (heart), 'xfg xfg' (repeatedly), 'jk[kfr' (watches), 'nS nS' (eyes), 'lueku' (door).
- Step 2: Cluster by semantic field: Cluster A (Visual vigilance): vklikl ijs, [kjs, vjcjfu, jk[kfr, nS nS. Cluster B (Path/Threshold): mfB tku, lueku. Cluster C (Heart's pull): vkou, Nchys, euHkkou.
- Step 3: Identify the *dominant action*: 'watching the path at the door' — a sustained, repeated, embodied attention.
- Step 4: Name the emotion this cluster *enacts*: 'Anticipatory longing' (viraha as active waiting, not passive sadness).
- Step 5: Formulate initial theme statement: "The poem opens with viraha as a discipline of the senses — the devotee's eyes, heart, and threshold become instruments of loving attention."
REASONING: This method forces the student to *build* the theme from the text's own materials, avoiding the 'label-first' misconception. The clusters reveal the *anatomy* of the emotion.
ANSWER: Initial theme formulation: "Viraha as sensory discipline — the devotee transforms her body (eyes, heart, threshold) into a continuous act of waiting for the beloved's arrival."

## WORKED_EXAMPLE_2
PROBLEM: Trace how the second stanza *transforms* the initial theme (from Worked Example 1) into the final primary theme. Show the shift in image clusters and its thematic consequence.
STEPS:
- Step 1: List stanza 2 concrete nouns/verbs: 'vkukdkuh' (speech of separation), 'vkjlh' (trembling), 'fugkfjcks' (restlessness), 'djkSxs' (do), 'dkSykSa' (how), 'pfdr' (fear), 'R;sa' (nights), 'MksfygS' (pass), 'gw' (body), 'nsf[kgkSa' (breathe), 'fdrsd' (how much), 'iu' (this), 'ikfygkS' (happens), 'owQdHkjh' (forceful pulling), 'ewdrk' (pain), 'cqyk;' (intense), 'cksfygSA' (you do), '?kuvkuan' (memories), 'eks¯g' (alone), 'rqEgS' (you), 'iSt' (mountain), 'ijh' (on), 'esfj;S' (curse), 'iqdkj' (gaze), 'dku' (give), '[kksfy' (will make).
- Step 2: Compare clusters with Stanza 1: Stanza 1 = *external* (eyes, path, door). Stanza 2 = *internal/visceral* (trembling, breath, memories, gaze-as-weapon). The threshold has moved *inside* the body.
- Step 3: Identify the new emotional register: From 'waiting' to 'suffering that threatens to become agency' (the curse).
- Step 4: Synthesize: The theme shifts from *discipline* to *crucible* — the separation is so intense it *reconfigures* the devotee; her gaze becomes a mountain, her curse a potential grace.
- Step 5: Final primary theme statement: "Viraha is a crucible that transmutes the devotee's longing into a sovereign power — her waiting gaze becomes a mountain, her curse a grace — because love has made her identity inseparable from the beloved."
REASONING: The two-stanza structure enacts a *dialectic*: external waiting → internal transformation. The theme is not static; it *moves* with the poem.
ANSWER: The primary theme deepens from "viraha as sensory discipline" to "viraha as identity-transmuting crucible" — the devotee's suffering becomes her sovereignty.

## WORKED_EXAMPLE_3
PROBLEM: A board exam question asks: "Explain how the poet's personal history (given in the preface) illuminates the poem's primary theme. Give two textual evidences." Write a full 4-mark answer using the PEEL structure.
STEPS:
- Step 1 (Point): The poet ?kukuan's historical exile and persecution by the guru's rivals *lived* the viraha that the poem *articulates* — biography and text are continuous.
- Step 2 (Evidence 1): Textual: "vc u f?kjr ?ku vkuan funku dks" (now the memories of you do not let me sleep) — the insomnia of exile becomes the insomnia of separation.
- Step 3 (Evidence 2): Textual: "owQdHkjh ewdrk cqyk; vki cksfygSA" (you forcefully inflict intense pain) — the physical torture he endured maps onto the 'forceful pulling' of viraha.
- Step 4 (Explanation): In Bhakti tradition, the poet's body is the *site* where divine play (lila) and historical suffering coincide; the poem does not *describe* viraha, it *enacts* the poet's lived transformation of persecution into devotion.
- Step 5 (Link): Therefore, the primary theme — viraha as identity-transmuting crucible — is not a literary invention but a *spiritual autobiography*; the 'curse' in the final line is the poet's real historical resilience.
REASONING: Board marking schemes reward explicit PEEL structure, direct textual quotation, and the integration of context *into* the argument (not as a separate paragraph).
ANSWER: The poet's exile and persecution (preface) are the lived substrate of the poem's theme. Two evidences: (1) "vc u f?kjr ?ku vkuan funku dks" — the sleeplessness of political danger becomes the sleeplessness of divine longing. (2) "owQdHkjh ewdrk cqyk; vki cksfygSA" — the physical violence he suffered is reframed as the beloved's 'forceful' love. In Bhakti poetics, the poet's body is where history and lila merge; thus the theme 'viraha as crucible' is autobiography, not metaphor. The final 'curse' is his historical survival transmuted into spiritual sovereignty.

## COMPETENCY_QUESTION_1
QUESTION: A Class 12 student writes in their exam: "The main theme of the poem is devotion to Krishna." The examiner awards 1 out of 4 marks. Using the concepts from this node, explain *why* this answer is insufficient and rewrite it to earn full marks.
COMPETENCY: Critical evaluation of peer response / Exam answer writing skill
STEPS:
- Step 1: Identify the error: The answer states a *label* ("devotion to Krishna") without *deriving* it from the poem's specific imagery, structure, or emotional arc.
- Step 2: Explain what the marking scheme requires: (a) Identification of theme as a *process* (viraha → transformation), (b) Two textual evidences with analysis, (c) Connection to poet's context.
- Step 3: Rewrite using PEEL: Point — The theme is viraha as a crucible that transmutes longing into sovereign power. Evidence — Stanza 1's 'nS nS lueku' (eyes become door) shows sensory discipline; Stanza 2's 'esfj;S iqdkj' (cursing gaze) shows suffering become agency. Explanation — The shift from external waiting to internal mountain-gaze enacts the transformation. Link — The poet's lived exile (preface) authenticates this as spiritual autobiography.
- Step 4: Verify the rewrite hits all four marking points.
REASONING: This competency tests the student's ability to *diagnose* a weak answer and *construct* a strong one — a meta-cognitive skill essential for board exams.
ANSWER: The original answer fails because it substitutes a thematic *label* for thematic *analysis*. It ignores the poem's two-stanza dialectic (waiting → transformation), its specific imagery (eyes/door → trembling/gaze/curse), and the poet's biographical grounding. A full-mark rewrite: "The primary theme is viraha as an identity-transmuting crucible. Stanza 1 establishes waiting as sensory discipline ('nS nS lueku' — eyes become the threshold). Stanza 2 reveals this waiting reconfigures the devotee: her trembling body ('vkjlh fugkfjcks') and final 'mountain-gaze' ('esfj;S iqdkj') turn suffering into sovereign power. The poet's historical persecution (preface) confirms this is lived autobiography — the curse is resilience." (4/4 marks)
DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: Compare the primary theme of this poem with the primary theme of *any one* other Bhakti poem you have studied (e.g., Mirabai, Surdas, Kabir). Identify one *structural similarity* in how viraha is constructed and one *key difference* in the *resolution* offered. Support with one line from each poem (paraphrased if exact quote unknown).
COMPETENCY: Comparative literary analysis / Intertextual synthesis
STEPS:
- Step 1: Select comparison poem (e.g., Mirabai's "Govind ke gun gaao re" or Kabir's "Moko kahan dhundhe re bande").
- Step 2: Identify structural similarity: Both use *embodied imagery* (eyes, breath, body) to make viraha visceral, not abstract.
- Step 3: Identify key difference in resolution: ?kukuan's poem ends with *threatened agency* (curse/gaze as power) — the devotee *becomes* the divine force. Mirabai/Kabir typically end with *dissolution* (merger, annihilation of ego).
- Step 4: Provide paraphrased lines: ?kukuan: "dcgw¡ rkS esfj;S iqdkj dku [kksfy gS" (otherwise I will curse with such a gaze). Mirabai: "Mero to Giridhar Gopal, dusro na koi" (My only support is Giridhar, no other) — surrender, not threat.
- Step 5: Synthesize: The similarity shows a shared Bhakti *vocabulary of the body*; the difference reveals ?kukuan's unique *viraha-as-empowerment* vs. the more common *viraha-as-self-annihilation*.
REASONING: This requires intertextual thinking (competency for CUET/JEE-style questions) and precise textual anchoring — not vague generalizations about "Bhakti poetry."
ANSWER: Structural similarity: Both ?kukuan and Mirabai construct viraha through embodied metaphors — ?kukuan's 'nS nS lueku' (eyes as door) and Mirabai's 'nainaan mein samai re' (dwelling in the eyes) make longing a physical occupation of the senses. Key difference in resolution: ?kukuan's devotee *threatens* the beloved with a curse ("esfj;S iqdkj dku [kksfy gS") — viraha *empowers* her to command. Mirabai's devotee *dissolves* ("Mero to Giridhar Gopal, dusro na koi") — viraha *annihilates* all other identity. ?kukuan offers viraha-as-sovereignty; Mirabai offers viraha-as-merger.
DIFFICULTY: hard