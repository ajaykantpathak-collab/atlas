## DEFINITION
Setting refers to the time, place, and historical context in which a narrative unfolds, while atmosphere is the emotional mood or tone created through descriptive details, language choices, and narrative perspective that shapes the reader's experience of that setting.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student can identify specific textual evidence (descriptive passages, dialogue, historical references) that establishes setting and creates atmosphere, and explain how these elements work together to reinforce the text's satirical critique of colonialism.

## SCOPE_BOUNDARY
This node covers analysis of setting (historical period, physical locations, social context) and atmosphere (mood shifts, tonal irony, emotional climate) in the prescribed text "फोन्कब्ज़-लाहकक.क" only. It does not cover character analysis, theme development, or literary devices beyond their contribution to setting/atmosphere.

## WALKTHROUGH
Imagine you're watching a historical drama where the director uses dim lighting, colonial architecture, and tense background music to make you feel the oppression of British rule before any character speaks. That's what setting and atmosphere do in literature. Start by asking: "What year is it? Where are we? Who holds power?" In this text, the opening lines immediately place us in 1899-1905 India under Curzon's viceroyalty. Then trace how the atmosphere shifts from formal diplomatic language to raw emotional outburst - notice the contrast between Curzon's polished rhetoric and India's personified anguish. The key insight: the setting isn't just backdrop; the colonial power dynamic IS the atmosphere, created through irony where the colonizer's "civilizing mission" vocabulary clashes with the colonized's lived reality.

## DIAGNOSTIC_QUESTION_1
Identify the specific historical period and political context that forms the setting of "फोन्कब्ज़-लाहकक.क" as established in the opening paragraphs.

## DIAGNOSTIC_ANSWER_1
The setting is India during Lord Curzon's viceroyalty (1899-1905), a period marked by aggressive colonial policies including the Partition of Bengal (1905), suppression of nationalist movements, and the "civilizing mission" rhetoric. A wrong answer (e.g., "British rule generally" or "post-1857") reveals the student cannot distinguish specific colonial phases or connect the text's satire to Curzon's actual policies like the Universities Act or Calcutta Corporation Act referenced implicitly.

## DIAGNOSTIC_QUESTION_2
Explain how the opening dialogue between Curzon and personified India establishes a satirical atmosphere rather than a realistic historical conversation.

## DIAGNOSTIC_ANSWER_2
The atmosphere is satirical because the text constructs an impossible dialogue: a Viceroy speaking candidly about colonial exploitation to India personified as a wronged woman, using exaggerated politeness ("एकब यकमज!") masking threats. The irony lies in Curzon acknowledging Indian suffering ("यहाँ के लोगों को बड़ा दुःख है") while justifying it as necessary. A wrong answer treating this as realistic dialogue misses the allegorical frame - India cannot literally speak to a Viceroy - and fails to see how the absurd premise creates satirical distance for critique.

## DIAGNOSTIC_QUESTION_3
Apply the concept of "atmosphere shift" to analyze the transition from Curzon's formal address (paragraphs 1-3) to India's emotional outburst (paragraph 4 onwards). Identify three specific linguistic markers of this shift.

## DIAGNOSTIC_ANSWER_3
Three linguistic markers: (1) Pronoun shift from "आप/आपके" (formal respect) to "तू/तेरे" (intimate accusation); (2) Syntax shift from complex polite sentences ("वरन आप...") to fragmented exclamations ("हाय एकब यकमज!"); (3) Vocabulary shift from administrative euphemisms ("विकास", "सुधार") to visceral bodily metaphors ("छाती पर मूंग दलना", "खून चूसना"). A wrong answer listing only content changes (topic shift) without linguistic evidence shows inability to connect language form to atmospheric effect.

## DIAGNOSTIC_QUESTION_4
Analyze how the physical settings referenced (Delhi viceregal palace, Bengal partition, universities, municipalities) function symbolically to reinforce the colonial power structure. Compare any two.

## DIAGNOSTIC_ANSWER_4
The Viceregal Palace (Delhi) symbolizes centralized imperial authority - Curzon speaks from here, literally above India. The University represents colonial knowledge control - Curzon boasts of "शिक्षा का प्रसार" while the Universities Act (1904) actually restricted Indian autonomy. Both are physical sites where colonial power materializes: one political, one intellectual. A wrong answer describing them merely as "places mentioned" misses their metonymic function - each stands for a pillar of colonial control (administration, education) that the satire dismantles.

## DIAGNOSTIC_QUESTION_5
Evaluate the effectiveness of using personified India as a narrative device to create atmosphere. Does it strengthen or weaken the satirical critique? Justify with textual reasoning.

## DIAGNOSTIC_ANSWER_5
It strengthens the critique by embodying abstract colonial violence in a single suffering voice, making systemic oppression emotionally tangible. The atmosphere shifts from intellectual satire to visceral pain when India says "मेरी छाती पर मूंग दली जा रही है" - the metaphor transforms policy into bodily harm. However, it risks oversimplifying diverse Indian responses. A weak evaluation either praises it uncritically ("it's powerful") or dismisses it ("unrealistic") without analyzing how the device shapes the reader's emotional alignment with the colonized perspective.

## DIAGNOSTIC_QUESTION_6
Create a 4-line poetic response from the perspective of a specific physical location in the text (e.g., the partitioned Bengal border, a university hall, a municipal office) that captures the atmosphere of that space during Curzon's viceroyalty.

## DIAGNOSTIC_ANSWER_6
A strong response uses concrete imagery from the text (e.g., "बंगाल की सीमा पर खिंची लाल रेखा / जहाँ भाई-भाई का खून हुआ पानी / वायसराय के कलम की स्याही नहीं सूखी / इतिहास की किताब में दर्ज है निशानी") showing the location as witness to violence. A poor response uses generic patriotism ("भारत माता की जय") without anchoring in the text's specific historical moment or atmospheric details like the "red line" of partition or bureaucratic violence.

## COMMON_MISCONCEPTION
Students often treat setting as a static backdrop (time/place labels) and atmosphere as a single mood label ("sad," "angry"). In this text, the setting is dynamically constructed through conflicting perspectives (Curzon's administrative gaze vs. India's lived geography), and the atmosphere shifts deliberately: formal irony → suppressed rage → grief → defiant prophecy. Students miss that the satirical atmosphere is CREATED by the gap between Curzon's euphemistic vocabulary ("सुधार", "विकास") and the brutal reality those words mask ("खून चूसना", "छाती पर मूंग दलना"). They also confuse the author's voice with Curzon's voice, not recognizing the dramatic irony where Curzon's own words condemn him.

## ON_FAILURE
Step 1: Have the student list every location named in the text (Delhi, Bengal, universities, municipalities, Calcutta, London) and for each, write: "What does Curzon say about this place? What does India say? What actually happened historically?" Step 2: Create a two-column chart: Column A = Curzon's words (e.g., "शिक्षा का प्रसार"), Column B = India's counter-vocabulary (e.g., "गुलामी की जंजीर"). Step 3: Read aloud only Curzon's paragraphs, then only India's paragraphs - hear the tonal shift. Step 4: Write one paragraph explaining: "The atmosphere is not one mood but a collision between two vocabularies fighting over the same physical spaces."

## BUILDS_ON
c11_hin_ar_cbse_04_001 (Context and Background) - provides the historical knowledge of Curzon's policies needed to decode the setting's significance.

## LEADS_TO
c11_hin_ar_cbse_04_008 (Literary Devices: Imagery and Metaphor) - the bodily metaphors ("छाती पर मूंग दलना") that create atmosphere are analyzed as literary devices there.

## PREREQUISITE_NODE_IDS
c11_hin_ar_cbse_04_001, c11_hin_ar_cbse_04_002
## PREREQUISITE_REASONS
c11_hin_ar_cbse_04_001: Provides essential historical context (Curzon's viceroyalty, Partition of Bengal, nationalist movement) without which the setting's political significance is opaque.
c11_hin_ar_cbse_04_002: Establishes the narrative structure (dialogue form, allegorical frame) that determines how setting and atmosphere are delivered - the satirical atmosphere depends on the plot's impossible conversation premise.

## FORWARD_NODE_IDS
c11_hin_ar_cbse_04_008, c11_hin_ar_cbse_04_009, c11_hin_ar_cbse_04_013, c11_hin_ar_cbse_04_004, c11_hin_ar_cbse_04_005, c11_hin_ar_cbse_04_006, c11_hin_ar_cbse_04_007, c12_hin_a_cbse_06_003, c12_hin_ar_cbse_04_003

## FORWARD_REASONS
c11_hin_ar_cbse_04_008: The imagery and metaphors (bodily violation, bureaucratic violence) that create atmosphere are analyzed as literary devices in this node.
c11_hin_ar_cbse_04_009: The irony and symbolism (Curzon as colonial archetype, India as wronged mother) that structure the atmosphere are examined here.
c11_hin_ar_cbse_04_013: Critical interpretation of how setting/atmosphere serve the text's anti-colonial argument requires the analytical foundation built in this node.
c11_hin_ar_cbse_04_004: The oppressive atmosphere (famine, surveillance) shapes the protagonist's urgency and rhetoric.  
c11_hin_ar_cbse_04_005: The oppressive atmosphere (plague, inspection, fear) shapes supporting characters' behaviour and limits their agency.  
c11_hin_ar_cbse_04_006: Setting analysis reveals the phone booth as a metaphorical space for truth-telling.  
c11_hin_ar_cbse_04_007: Setting/atmosphere analysis reveals how physical space reinforces themes (e.g., the dak bungalow as colonial microcosm).  
c12_hin_a_cbse_06_003: Cumulative exposure to Braj/Avadhi dialect settings  
c12_hin_ar_cbse_04_003: Class 11 foundation on setting/atmosphere in poetry — this node deepens that skill with a more complex, modernist poem.  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
none

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_04_001 -> c11_hin_ar_cbse_04_003 -> c11_hin_ar_cbse_04_008: Historical context enables setting analysis, which feeds into imagery/metaphor analysis of atmospheric language.

## THIS_FORMULA
N/A - conceptual

## FORMULA_VARIABLES
N/A

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
analytical

## CROSS_SUBJECT
c11_history_colonialism | The text's setting (Curzon's viceroyalty, Partition of Bengal) directly references historical events studied in Class 11 History (Themes in Indian History Part III: Colonialism and the Countryside, Nationalism). Understanding British administrative strategies (Universities Act, Calcutta Corporation Act) is essential to decode the satire.
c11_politicalscience_constitution | The atmosphere of colonial dialogue - where power speaks through "reform" rhetoric while denying agency - connects to Political Science concepts of colonial discourse, hegemony, and the contrast between colonial governance and post-colonial constitutional values (Preamble's "Justice, Liberty, Equality").

## PREREQ_CONCEPT
Historical knowledge of Lord Curzon's specific policies (1899-1905) and the allegorical dialogue form where abstract entities (Empire, Nation) speak as characters.

## PREREQ_BEFORE
Student must know: Curzon's viceroyalty dates, Partition of Bengal (1905), and that this text uses personification (India as a woman) in a fictional dialogue - not a historical transcript.

## PREREQ_STUCK
If stuck, review c11_hin_ar_cbse_04_001 (Context and Background) for Curzon's policies and c11_hin_ar_cbse_04_002 (Plot and Narrative Structure) for the allegorical frame.

## WORKED_EXAMPLE_1
PROBLEM: Analyze how the opening paragraph establishes both the physical setting and the satirical atmosphere through Curzon's first speech. Use the PEEL structure (Point, Evidence, Explanation, Link).

STEPS:
- Step 1: Identify the given - Curzon's opening address in paragraph 1 ("एकब यकमज! वर ड्क्स वकिओसक...") - and the task: analyze setting + atmosphere establishment.
- Step 2: Identify the concepts - setting markers (time/place/power), atmosphere markers (tone/irony/vocabulary), and satirical mode (gap between stated intent and actual effect).
- Step 3: Extract evidence for setting: "इस देश में वर ग्क्स वकिओसक 'ककुल-ड्क्य ड्क वर ग्क्स" (temporal marker: Curzon's rule), "वरकिओसक ककुल-ड्क्य ड्क ह्क वरक" (spatial: "this country"), "लककजरह फुजाअकक्रक" (power: official authority). Extract evidence for atmosphere: "वरह ल्क्जह ड्क्स वरकसक फ्प्जल्फ्क्कब्ज़ ओक्ब्ल्जक ह्क्स ग्क्स" (euphemistic "development"), "वरकसक एक क्कज ड्क वकस" (condescending "one visit").
- Step 4: Explain - The setting is established through Curzon's proprietary language ("मेरा शासन", "यह देश") revealing colonial ownership mindset. The satirical atmosphere emerges from the dissonance: Curzon speaks of "development" while the reader knows (from historical context) this means exploitation. The formal politeness ("एकब यकमज!") masks the threat in "वरकिओसक ककुल-ड्क्य ड्क ह्क वरक".
- Step 5: Link to central idea - This opening establishes the core satirical dynamic: colonial power speaks the language of benevolence while exercising violence, and the atmosphere of irony invites the reader to read against Curzon's grain.

REASONING: The PEEL structure forces separation of observation (evidence) from interpretation (explanation), preventing the common error of substituting plot summary for analysis. The link step connects micro-analysis to macro-argument.

ANSWER: The opening paragraph establishes the physical setting as India under Curzon's viceroyalty through proprietary spatial-temporal markers ("इस देश में मेरा शासन"), while the satirical atmosphere is created through ironic dissonance: Curzon's benevolent vocabulary ("विकास", "सुधार", "एक बार का दौरा") clashes with the reader's historical knowledge of his repressive policies. The formal address "एकब यकमज!" sets a tone of performative respect that the subsequent threats undermine. This establishes the text's central satirical strategy: colonial rhetoric is its own indictment.

## WORKED_EXAMPLE_2
PROBLEM: Trace the atmosphere shift in India's personified response (paragraph 4: "हाय एकब यकमज!...") by identifying three tonal registers and the linguistic features that signal each.

STEPS:
- Step 1: Identify the passage - India's first speech starting "हाय एकब यकमज!" - and the task: map tonal shifts with linguistic evidence.
- Step 2: Segment the speech into three registers: (A) Lament/Grief ("हाय एकब यकमज!..."), (B) Accusatory Anger ("वरकसक न्व्ल्जह क्कज ड्क्स वरकस..."), (C) Prophetic Defiance ("वरकसक फ्क्ल्र्हीक्क ड्क्स वर...").
- Step 3: For Register A (Lament): Evidence - interjection "हाय", kinship terms "मेरा बेटा", "मेरी बेटी", bodily metaphor "छाती पर मूंग दलना". Linguistic features: exclamatory sentences, possessive pronouns, visceral imagery.
- Step 4: For Register B (Anger): Evidence - "वरकसक न्व्ल्जह क्कज ड्क्स वरकस", "खून चूसना", "लूटना". Linguistic features: second person direct address ("तू"), active verbs of violence, anaphora ("वरकसक... वरकसक...").
- Step 5: For Register C (Defiance): Evidence - "वरकसक फ्क्ल्र्हीक्क ड्क्स वर", "इतिहास... गवाह रहेगा". Linguistic features: future tense certainty, impersonal "इतिहास" as witness, prophetic register.
- Step 6: Synthesize - The atmosphere moves from private grief to public indictment to historical judgment, mirroring the nationalist movement's trajectory from petitioning to protest to sovereignty claim.

REASONING: This stepwise segmentation prevents the "single mood" error. Each register serves the satire differently: grief humanizes, anger politicizes, prophecy historicizes. The linguistic evidence anchors interpretation in textual detail.

ANSWER: Three tonal registers in India's response: (1) Maternal grief - marked by "हाय", kinship vocabulary ("बेटा/बेटी"), and bodily suffering metaphors ("छाती पर मूंग दलना"), creating intimate emotional atmosphere. (2) Accusatory rage - marked by shift to "तू" (tu), violent active verbs ("खून चूसना", "लूटना"), and anaphoric repetition ("तेरे... तेरे..."), creating confrontational atmosphere. (3) Prophetic defiance - marked by future tense certainty ("इतिहास गवाह रहेगा"), impersonal historical witness, and sovereignty claim ("मेरा राज आएगा"), creating transcendent atmosphere. The progression mirrors nationalist consciousness evolution.

## WORKED_EXAMPLE_3
PROBLEM: Compare how two physical settings - the Viceregal Palace (implied by Curzon's voice) and the partitioned Bengal border (referenced in "बंगाल के टुकड़े") - function as symbolic spaces where colonial power and resistance materialize. Integrate historical context from c11_hin_ar_cbse_04_001.

STEPS:
- Step 1: Identify the two settings - Viceregal Palace (seat of authority, Curzon's speaking position) and Bengal border (site of Partition violence, India's speaking position).
- Step 2: Recall historical context from prerequisite node: Curzon's 1905 Partition of Bengal divided nationalist stronghold; Viceregal Palace (later Rashtrapati Bhavan) symbolized imperial grandeur.
- Step 3: Analyze Palace as symbolic space - Curzon speaks FROM here: elevated, centralized, bureaucratic. Textual markers: "वरकिओसक ककुल-ड्क्य", "लककजरह फुजाअकक्रक", "विकास/सुधार" vocabulary. Atmosphere: cold administrative irony.
- Step 4: Analyze Bengal border as symbolic space - India speaks FROM here: fragmented, wounded, lived. Textual markers: "बंगाल के टुकड़े", "भाई-भाई का खून", "लाल रेखा". Atmosphere: visceral grief and rage.
- Step 5: Compare symbolic functions - Palace = colonial power made spatial (panopticon, bureaucracy, "civilizing mission" stage). Border = colonial violence made spatial (arbitrary division, communal fracture, resistance site).
- Step 6: Synthesize - The text's atmosphere is the tension BETWEEN these spaces: Curzon's palace-voice claims to order the border, but India's border-voice exposes the palace's violence. The satire lives in this spatial dialogue.

REASONING: This comparison requires integrating historical knowledge (prerequisite) with textual analysis. The spatial contrast structures the entire satirical atmosphere - the palace cannot see what the border feels. Students often analyze settings in isolation; this forces relational thinking.

ANSWER: The Viceregal Palace functions as the spatial embodiment of colonial epistemic violence: from this height, Curzon's gaze converts lived geography into administrative objects ("विकास", "सुधार", "शिक्षा"). The Palace atmosphere is bureaucratic irony - power speaking euphemisms. The partitioned Bengal border functions as the spatial embodiment of colonial material violence: the "लाल रेखा" (Radcliffe Line precursor) converts shared homeland into "टुकड़े", producing "भाई-भाई का खून". The border atmosphere is visceral testimony. The satirical atmosphere of the whole text is generated by the unbridgeable gap between these two spatial epistemologies - the Palace cannot comprehend the border's suffering, and the border refuses the Palace's vocabulary. This spatial dialectic IS the text's anti-colonial argument.

## COMPETENCY_QUESTION_1
QUESTION: The text creates its satirical atmosphere largely through lexical dissonance - the clash between Curzon's administrative euphemisms and India's visceral metaphors. Identify THREE pairs of contrasting terms (one from Curzon's vocabulary, one from India's) that refer to the SAME colonial action but create opposite atmospheric effects. Explain how each pair contributes to the satire.

COMPETENCY: Lexical analysis for atmospheric effect

STEPS:
- Step 1: List Curzon's euphemistic terms for colonial actions (e.g., "विकास", "सुधार", "शिक्षा का प्रसार", "कानून-व्यवस्था").
- Step 2: List India's metaphorical terms for the SAME actions (e.g., "लूटना", "खून चूसना", "गुलामी की जंजीर", "छाती पर मूंग दलना").
- Step 3: Match three pairs where both refer to the same policy/event (e.g., Partition = Curzon's "प्रशासनिक सुविधा" vs India's "बंगाल के टुकड़े"; Universities Act = Curzon's "शिक्षा का प्रसार" vs India's "गुलामी की जंजीर"; Taxation = Curzon's "राजस्व सुधार" vs India's "खून चूसना").
- Step 4: For each pair, explain the atmospheric contrast: Curzon's term creates bureaucratic normality; India's term creates bodily violation. The satire lies in the gap.

ANSWER: Three contrasting pairs: (1) Curzon: "प्रशासनिक सुविधा" (administrative convenience - for Partition) vs India: "बंगाल के टुकड़े" (Bengal's pieces). Curzon's term creates atmosphere of rational governance; India's creates atmosphere of vivisection. Satire: bureaucracy masks dismemberment. (2) Curzon: "शिक्षा का प्रसार" (spread of education - for Universities Act) vs India: "गुलामी की जंजीर" (chains of slavery). Curzon's term creates atmosphere of enlightenment; India's creates atmosphere of bondage. Satire: education as tool of subjection. (3) Curzon: "राजस्व सुधार" (revenue reform) vs India: "खून चूसना" (blood-sucking). Curzon's term creates atmosphere of technical adjustment; India's creates atmosphere of parasitic extraction. Satire: reform as predation.

DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: The atmosphere of "फोन्कब्ज़-लाहकक.क" is not uniform but progresses through distinct phases. Map the atmosphere's trajectory across the text by identifying FOUR turning points where the emotional register shifts significantly. For each turning point, cite the triggering textual event and the new atmospheric quality it introduces.

COMPETENCY: Structural atmosphere mapping

STEPS:
- Step 1: Define "atmospheric turning point" - a moment where tone/mood shifts due to narrative event or voice change.
- Step 2: Identify Turning Point 1: Curzon's opening speech → Atmosphere: Bureaucratic irony (colonial power performing benevolence).
- Step 3: Identify Turning Point 2: India's entry ("हाय एकब यकमज!") → Atmosphere: Visceral grief (maternal body violated).
- Step 4: Identify Turning Point 3: Curzon's refusal to listen ("वरकसक एक एकडक ड्क्स वर...") → Atmosphere: Cold dismissal (power's deafness performed).
- Step 5: Identify Turning Point 4: India's prophetic closure ("इतिहास गवाह रहेगा") → Atmosphere: Defiant historicity (colonized seizing narrative authority).
- Step 6: Explain how this trajectory structures the satire: from power's performance → to truth's exposure → to power's refusal → to resistance's prophecy.

ANSWER: Four atmospheric turning points: (1) Opening: Curzon's euphemistic benevolence establishes "bureaucratic irony" - power speaking development while delivering exploitation. Trigger: "एकब यकमज! वर ड्क्स वकिओसक..." (2) India's intervention: "हाय एकब यकमज!" shifts to "visceral grief" - the colonized body enters as witness. Trigger: personified India's first speech. (3) Curzon's dismissal: "वरकसक एक एकडक ड्क्स वर..." creates "cold deafness" - power refuses the truth it occasioned. Trigger: Curzon's refusal to hear "किसी की न सुनना". (4) India's prophecy: "इतिहास गवाह रहेगा" establishes "defiant historicity" - the colonized claims future judgment. Trigger: final prophetic speech. The trajectory moves from satire (gap between word/deed) to testimony (embodied truth) to exposure (power's bad faith) to reversal (resistance owns history).

DIFFICULTY: hard