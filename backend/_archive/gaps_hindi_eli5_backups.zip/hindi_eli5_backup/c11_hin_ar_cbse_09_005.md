## DEFINITION
Supporting characters in poetry are figures who interact with the main speaker/persona, embodying social forces or contrasting values, and whose actions, speech, or presence deepen the portrayal of the protagonist's reality and the poem's central theme.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student can identify at least two supporting characters in Dhoomil's poem "एक दिन एक दिन दौँका", cite specific lines as evidence, and explain how each character's role highlights the exploitation and resilience of the laborer-protagonist.

## SCOPE_BOUNDARY
This node covers analysis of supporting characters in the prescribed poems of Chapter 9 (Dhoomil), focusing on their function in revealing socio-economic themes. It does not cover character analysis in prose chapters or other poets.

## WALKTHROUGH
Imagine you are watching a street play where the main actor represents a daily-wage worker; the people who hand him tools, deduct his wages, or share his lunch break are not just extras—they are the supporting characters that make his struggle visible. In Dhoomil's poem, start by identifying the "we" (the collective laborer) as the protagonist, then look for any other figure that appears—like the clerk who records attendance or the contractor who sets the wage. Ask: what does this figure do? What does the protagonist say about them? How does their interaction expose the power imbalance? The key insight is that in protest poetry, supporting characters are often personifications of systemic oppression.

## DIAGNOSTIC_QUESTION_1
In the poem "एक दिन एक दिन दौँका", who is the primary speaker (protagonist) and what collective identity do they represent?

## DIAGNOSTIC_ANSWER_1
The primary speaker is the collective "we" (गे), representing daily-wage laborers who work from dawn to dusk. A wrong answer (e.g., identifying the poet as the speaker) reveals the student confuses the poet with the persona and misses the collective voice essential to protest poetry.

## DIAGNOSTIC_QUESTION_2
The poem mentions "lc ?kfV varfj rw¡gh O;kid /jS l:iS lksbZ" (the sharp sickle, the clerk sits with a heavy heart). Explain in your own words what the "O;kid" (clerk) symbolizes in the context of the laborer's day.

## DIAGNOSTIC_ANSWER_2
The clerk symbolizes the bureaucratic machinery that monitors and controls the laborer's work, reducing human effort to mere attendance and output. A wrong answer that treats the clerk as just a neutral observer shows the student misses the power dynamic: the clerk's "heavy heart" (लःस) implies complicity in exploitation.

## DIAGNOSTIC_QUESTION_3
Using the prose background about Dhoomil, identify two supporting characters commonly found in his poems (other than the laborer) and state one line from the given poem that hints at their presence.

## DIAGNOSTIC_ANSWER_3
The contractor (thekedar) and the clerk (munshi/O;kid) are recurring supporting characters. The line "lc ?kfV varfj rw¡gh O;kid /jS l:iS lksbZ" hints at the clerk; the contractor is implied in the wage negotiation ("cu iM+s rks lh/s&lh/s ugha rks njsjk nsdj" from the prose). A wrong answer that invents characters not in the text shows inability to connect prose context to poetic evidence.

## DIAGNOSTIC_QUESTION_4
Compare the function of the "sharp sickle" (ck<+h dk"V) and the "clerk" (O;kid) in the poem. How do both serve as instruments of the system that exploits the laborer?

## DIAGNOSTIC_ANSWER_4
The sickle is the tool of production that the laborer wields but does not own; the clerk is the tool of administration that records the laborer's output for the owner. Both are extensions of the exploitative system: one extracts physical labor, the other extracts surplus value. A wrong answer that treats the sickle as merely a farming tool misses the metaphorical equivalence Dhoomil draws between physical and bureaucratic violence.

## DIAGNOSTIC_QUESTION_5
Critique the view that the supporting characters in Dhoomil's poem are flat stereotypes. Use evidence from the poem and the prose background to defend your judgment.

## DIAGNOSTIC_ANSWER_5
They are not flat stereotypes but deliberate typifications: the clerk's "heavy heart" (लःस) suggests internal conflict, making him a complex cog in the machine. Dhoomil's prose says he portrays "ln~Hkko vkSj lekurk" (empathy and equality) even for oppressors. A wrong answer that calls them flat ignores the nuance Dhoomil builds through minimal detail.

## DIAGNOSTIC_QUESTION_6
Write a four-line stanza in the style of Dhoomil introducing a new supporting character—the "truck driver" who transports the harvested crop—showing his relationship to the laborer.

## DIAGNOSTIC_ANSWER_6
A good stanza will use simple, rustic vocabulary, collective voice, and show the driver as another exploited worker or as an agent of the market. Example: "ट्रक वाला आया धूल उड़ाता / हमारी फसल ले जाता बाज़ार / उसका पसीना भी हमारे जैसा / पर मालिक उसका भी कोई और।" A poor answer will use literary Hindi, miss the collective perspective, or make the driver a villain without systemic context.

## COMMON_MISCONCEPTION
Students often think "supporting characters" in a poem must be named individuals with dialogue. In Dhoomil's poetry, supporting characters are often systemic roles (clerk, contractor, landlord) represented through minimal imagery or a single line. They mistake the absence of proper names for absence of character, and therefore fail to analyze how a phrase like "O;kid" (clerk) carries the weight of an entire bureaucratic class.

## ON_FAILURE
If a student cannot identify supporting characters, guide them: (1) Re-read the poem circling every noun that denotes a person or role (e.g., O;kid, nkstx, frugha). (2) For each, ask: "Does this figure act upon the protagonist or react to them?" (3) Use the prose background to match roles (thekedar, munshi) to poetic hints. (4) Practice writing one-sentence character sketches: "The clerk represents the surveillance of labor."

## BUILDS_ON
Character Analysis: Protagonist (c11_hin_ar_cbse_09_004) where the student learned to identify the collective laborer as the main persona.

## LEADS_TO
Theme: Primary Theme and Message (c11_hin_ar_cbse_09_006) where the exploitation revealed by supporting characters becomes the central theme.

## PREREQUISITE_NODE_IDS
c11_hin_ar_cbse_09_001, c11_hin_ar_cbse_09_002, c11_hin_ar_cbse_09_004
## PREREQUISITE_REASONS
c11_hin_ar_cbse_09_001: Provides socio-historical context of Dhoomil's poetry necessary to understand the roles of supporting characters like thekedar and munshi.
c11_hin_ar_cbse_09_002: Establishes the narrative structure of the poem, helping locate where supporting characters appear in the sequence of a laborer's day.
c11_hin_ar_cbse_09_004: Defines the protagonist (collective laborer) against which supporting characters are defined by contrast and interaction.

## FORWARD_NODE_IDS
c11_hin_ar_cbse_09_006, c11_hin_ar_cbse_09_007, c11_hin_ar_cbse_09_013, c12_hin_a_cbse_09_005, c12_hin_ar_cbse_06_005, c12_hin_ar_cbse_09_005, c12_hin_ar_cbse_10_005

## FORWARD_REASONS
c11_hin_ar_cbse_09_006: The primary theme of exploitation emerges directly from the relationship between protagonist and supporting characters.
c11_hin_ar_cbse_09_007: Secondary themes like bureaucratic complicity and collective resistance are carried by supporting characters.
c11_hin_ar_cbse_09_013: Critical interpretation requires analyzing how supporting characters function as symbols of systemic forces.
c12_hin_a_cbse_09_005: Class 11 introduced the distinction between narrative characters and lyric addressees; this node deepens that concept.  
c12_hin_ar_cbse_06_005: Class 11 foundation on supporting character analysis in Aroh.  
c12_hin_ar_cbse_09_005: Class 11 node built the foundational skill of analyzing non-protagonist figures in poetry.  
c12_hin_ar_cbse_10_005: Class 11 Chapter 9 supporting character practice offers additional worked examples of the PEEL method applied to secondary figures.  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
none

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_09_004 -> c11_hin_ar_cbse_09_005 -> c11_hin_ar_cbse_09_006

## THIS_FORMULA
N/A - conceptual

## FORMULA_VARIABLES
N/A

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
analytical

## CROSS_SUBJECT
c11_history_colonialism | The poem's depiction of clerk and contractor mirrors colonial-era labor exploitation in plantations and railways, where bureaucratic roles enforced extraction.
c11_economics_labour_market | The power imbalance between laborer (protagonist) and clerk/contractor (supporting) illustrates monopsony power in rural labor markets.

## PREREQ_CONCEPT
Ability to distinguish between the poet and the poetic persona, and to recognize collective voice ("we") as protagonist.

## PREREQ_BEFORE
Student must have completed analysis of the protagonist in the same poem (node 004) and read the prose background on Dhoomil's thematic concerns.

## PREREQ_STUCK
Review the "Character Analysis: Protagonist" node (c11_hin_ar_cbse_09_004) and the prose section "डोमिल के बारे में" in the textbook.

## WORKED_EXAMPLE_1
PROBLEM: Analyze the clerk (O;kid) as a supporting character in the poem "एक दिन एक दिन दौँका". Use the PEEL structure: Point, Evidence, Explanation, Link to theme.
STEPS:
- Step 1: Identify the point: The clerk embodies the bureaucratic surveillance that turns the laborer's day into measurable units for exploitation.
- Step 2: Locate evidence: The line "lc ?kfV varfj rw¡gh O;kid /jS l:iS lksbZ" (the sharp sickle, the clerk sits with a heavy heart) places the clerk alongside the tool of labor.
- Step 3: Explain the evidence: The clerk's "heavy heart" (लःस) suggests he feels the weight of his role but continues to enforce the system; he records the laborer's output, enabling wage deduction.
- Step 4: Link to theme: This supports the primary theme of dehumanizing labor—where even the recorder of work becomes an instrument of oppression.
- Step 5: Connect to prose background: The prose notes Dhoomil portrays "ln~Hkko vkSj lekurk" (empathy and equality) for all, so the clerk is not a villain but a trapped functionary.
REASONING: The PEEL structure forces the student to move from identification to thematic significance, using both poem and prose context. Each step builds a board-exam ready paragraph.
ANSWER: The clerk (O;kid) is a supporting character who represents the administrative arm of exploitation. In the line "lc ?kfV varfj rw¡gh O;kid /jS l:iS lksbZ", he sits with a "heavy heart" (लःस) while the sharp sickle (ककछ दक़V) does its work, juxtaposing the tool of production with the tool of record-keeping. His "heavy heart" implies moral discomfort, yet he performs his duty, making him a complex figure of complicity. This aligns with the prose description of Dhoomil's characters showing "ln~Hkko vkSj lekurk" (empathy and equality), revealing that the system traps both laborer and clerk. Thus, the clerk deepens the theme of systemic dehumanization.

## WORKED_EXAMPLE_2
PROBLEM: The prose background mentions the contractor (thekedar) as a recurring figure in Dhoomil's poems. Although not named in the given poem, infer his presence from the line "cu iM+s rks lh/s&lh/s ugha rks njsjk nsdj" (if you speak, you'll be silenced; if not, you'll be pushed out). Analyze the contractor's implied role using the same PEEL structure.
STEPS:
- Step 1: Point: The contractor is the unseen authority who sets the terms of labor and silences dissent.
- Step 2: Evidence: The prose quotes Dhoomil's blunt style: "cu iM+s rks lh/s&lh/s ugha rks njsjk nsdj" (speak and be silenced, or be pushed out), reflecting the contractor's power.
- Step 3: Explanation: The laborer's collective voice ("ge") speaks in the poem, but the threat of "njsjk nsdj" (push out) looms—the contractor controls employment. The poem's description of relentless work ("ge rkS ,d ,d dfj tkauka") implies his demand for uninterrupted labor.
- Step 4: Link: This reveals the theme of coercive control—the laborer's body and voice are both monitored.
- Step 5: Synthesis: The contractor, though absent in body, haunts the poem as the source of the "heavy heart" of the clerk and the "sharp sickle" of work.
REASONING: This example teaches inference—a key board skill—where supporting characters are analyzed through their systemic effects even when not physically present in the poem.
ANSWER: The contractor (thekedar) is an implied supporting character whose power structures the entire poem. The prose records Dhoomil's own words: "cu iM+s rks lh/s&lh/s ugha rks njsjk nsdj" (if you speak, you'll be silenced; if not, you'll be pushed out), which captures the contractor's ultimatum. In the poem, the laborers work "एक दिन एक दिन दौँका" (day after day) without pause, reflecting the contractor's demand for continuous output. The clerk's "heavy heart" and the sickle's sharpness are both instruments of the contractor's will. Thus, the contractor functions as the invisible architect of exploitation, and his absence from the poem's lines makes his control more pervasive. This supports the theme of structural violence where the oppressor need not be present to be felt.

## WORKED_EXAMPLE_3
PROBLEM: Compare the supporting characters in Dhoomil's poem with those in a contemporary news report about migrant workers during lockdown (e.g., the contractor who abandoned them, the police who stopped them, the villagers who fed them). Write a structured comparative analysis paragraph.
STEPS:
- Step 1: Identify supporting characters in both texts: Poem -> clerk, implied contractor; News report -> contractor, police, villagers.
- Step 2: Categorize their functions: Exploitative (contractor, clerk), coercive (police), supportive (villagers).
- Step 3: Find a shared theme: The vulnerability of the laborer to multiple systemic forces.
- Step 4: Contrast the portrayal: Dhoomil's clerk has "heavy heart" (internal conflict); news report's police may be shown as duty-bound or brutal.
- Step 5: Analyze the literary effect: Dhoomil uses minimalism to suggest systemicity; news report uses concrete incidents.
- Step 6: Conclude: Both use supporting characters to map the ecology of exploitation, but poetry condenses it into typified roles.
REASONING: This cross-textual analysis builds higher-order thinking required for competency questions, linking literary analysis to real-world contexts.
ANSWER: In Dhoomil's poem, the clerk and implied contractor form a minimal but complete exploitative duo: one records, the other commands. In a lockdown migrant report, the cast expands: the contractor who flees, the police who block, the villagers who feed. Both texts use supporting characters to surround the laborer with forces that control his mobility and survival. However, Dhoomil's clerk carries a "heavy heart" (लःस), humanizing the bureaucrat as a trapped cog, while news reports often depict police as either faceless enforcers or individual heroes. The poem's typification (clerk = bureaucracy) makes the system visible; the report's specificity makes the crisis tangible. Together, they show that supporting characters in labor narratives are not mere background but the very architecture of oppression and resistance.

## COMPETENCY_QUESTION_1
QUESTION: "In Dhoomil's poem 'एक दिन एक दिन दौँका', the clerk (O;kid) is described as sitting with a 'heavy heart' (लःस). Some students argue this makes him a sympathetic character. Evaluate this claim using evidence from the poem and the prose background. Structure your answer in PEEL format."
COMPETENCY: Critical evaluation of character portrayal with textual evidence.
STEPS:
- Step 1: State your position (Point): The clerk's "heavy heart" evokes sympathy but does not make him a sympathetic character; it highlights his complicity.
- Step 2: Provide evidence (Evidence): Quote "lc ?kfV varfj rw¡gh O;kid /jS l:iS lksbZ" and the prose line "ln~Hkko vkSj lekurk" (empathy and equality).
- Step 3: Explain (Explanation): The phrase "लःस" suggests he feels the burden of his role, yet he continues to sit and record, enabling exploitation. Dhoomil's "empathy" is for the human condition, not endorsement of the clerk's actions.
- Step 4: Link (Link): Thus, the clerk is a tragic functionary, not an ally—deepening the theme of systemic entrapment.
ANSWER: The clerk's "heavy heart" (लःस) does not make him sympathetic; it makes him a portrait of complicity with a conscience. Evidence: "lc ?kfV varfj rw¡gh O;kid /jS l:iS lksbZ" places him beside the sharp sickle, equating his bureaucratic function with the physical tool of exploitation. The prose explains Dhoomil shows "ln~Hkko vkSj lekurk" (empathy and equality) toward all characters, meaning he humanizes the clerk without absolving him. The clerk's internal weight (लःस) contrasts with his external inaction—he still records the labor that decides the wage. This duality makes him a supporting character who embodies the system's ability to trap even its operators. Therefore, he is not a sympathetic figure but a damning indictment of a structure that turns humans into instruments.
DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: "Dhoomil's supporting characters (clerk, contractor, landlord) are often called 'typified' rather than 'individualized'. Explain this distinction and analyze how typification serves the poem's political purpose. Refer to at least two supporting characters from the chapter."
COMPETENCY: Literary analysis of characterization technique and its ideological function.
STEPS:
- Step 1: Define typification: representing a social class/role through a single figure, not unique personality.
- Step 2: Identify two supporting characters: the clerk (O;kid) and the contractor (thekedar).
- Step 3: Show typification in text: Clerk has no name, only role; contractor is implied through a proverbial threat.
- Step 4: Analyze political purpose: Typification exposes the system as impersonal and structural—exploitation is not about individual malice but role-based necessity.
- Step 5: Connect to theme: This aligns with Dhoomil's Marxist-influenced vision where "ln~Hkko vkSj lekurk" is the goal, but current reality is role-determined.
ANSWER: Typification means a character stands for an entire social category (e.g., "the clerk" = bureaucracy) rather than being a unique individual. In the poem, the clerk is never named, only designated by his role (O;kid), and his only trait is "लःस" (heavy heart)—a condition of his role. The contractor is absent but represented by the proverbial threat "cu iM+s rks lh/s&lh/s ugha rks njsjk nsdj", making him the voice of capital itself. This technique serves Dhoomil's political purpose: it shifts blame from "bad people" to "bad structures." The laborer's struggle is not against a cruel clerk or a greedy contractor personally, but against the roles they are forced to play. As the prose notes, Dhoomil portrays "ln~Hkko vkSj lekurk" (empathy and equality) by showing how the system dehumanizes everyone. Typification thus makes the poem a structural critique, not a personal drama, fulfilling the revolutionary aim of his poetry.
DIFFICULTY: hard