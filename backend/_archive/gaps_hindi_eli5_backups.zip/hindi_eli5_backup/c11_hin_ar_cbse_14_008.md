## DEFINITION
Imagery (बिंब/प्रतीक) refers to the use of vivid, sensory language that appeals to the five senses (sight, sound, smell, touch, taste) to create mental pictures, while Metaphor (रूपक/लाक्षणिक प्रयोग) is a figure of speech that directly compares two unrelated things by stating one *is* the other, without using comparative words like "like" or "as" (जैसे/वैसे). In Hindi poetry, imagery builds the poem's atmosphere (वातावरण) and metaphor reveals the poet's deeper philosophical vision (दार्शनिक दृष्टि).

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student can independently identify at least three distinct sensory images and two metaphors from the two poems in this chapter, quote the specific lines, explain the sensory appeal of each image, and articulate the implicit comparison in each metaphor with its thematic significance in 150-200 words.

## SCOPE_BOUNDARY
This node covers *only* imagery (visual, auditory, tactile, olfactory) and metaphor (simple, extended, and implied) as they appear in the two poems of "vDd osQ opu" by व्देद्ग्न्सोह. It does NOT cover simile (उपमा), personification (मानवीकरण), irony (व्यंग्य), or symbolism (प्रतीकवाद) — those are addressed in node c11_hin_ar_cbse_14_009. It also excludes vocabulary meanings (node 010) and grammar structures (node 011).

## WALKTHROUGH
Imagine you are sitting in a dark room during a power cut and someone lights a single diya — suddenly you *see* the dancing flame, *feel* its warmth, *smell* the ghee, and *hear* the faint crackle. That is imagery at work. Now, if you say "This diya is my hope," you have created a metaphor: the diya (concrete object) *is* hope (abstract concept). To analyze the poems, first read both poems aloud slowly, marking every word that triggers a sense. Second, circle every statement where Thing A is called Thing B without "like/as". Third, for each image, name the sense it appeals to. Fourth, for each metaphor, name the two things compared and the shared quality. Fifth, ask: "What theme does this device serve?" — that is your analytical insight.

## DIAGNOSTIC_QUESTION_1
What is the precise difference between imagery (बिंब) and metaphor (रूपक) in Hindi poetics? Write the definition of each in one sentence.

## DIAGNOSTIC_ANSWER_1
**Correct Answer:** Imagery (बिंब) is sensory language that evokes a concrete perceptual experience (e.g., "लाल आग" appeals to sight). Metaphor (रूपक) is an implicit identity statement equating two distinct entities based on a shared attribute (e.g., "जीवन एक दीपक है" equates life with a lamp).  
**Wrong Answer Reveals:** If a student says "both are comparisons" or "imagery uses like/as", they confuse metaphor with simile (उपमा) and treat imagery as a comparative device rather than an evocative one. This shows they have not distinguished *evocation* (बिंब) from *equation* (रूपक).

## DIAGNOSTIC_QUESTION_2
In the first poem, the line "gs Hkw[k! er epy" (roughly: "O sky! your shadow") uses imagery. Which *specific* sense does it primarily appeal to, and what emotional tone does that sensory detail establish? Explain in your own words without quoting the definition.

## DIAGNOSTIC_ANSWER_2
**Correct Answer:** The line appeals primarily to the *visual* sense (sight) by invoking the vast darkness of the sky casting a shadow. This creates a tone of awe mixed with oppression — the sky's shadow suggests an overwhelming, inescapable presence, setting a mood of existential weight.  
**Wrong Answer Reveals:** If the student says "it appeals to feeling" or "it shows sadness", they are interpreting *emotion* instead of identifying the *sensory channel*. This misconception — conflating the *sense triggered* with the *feeling produced* — is the most common Class 11 error in imagery analysis.

## DIAGNOSTIC_QUESTION_3
Apply the metaphor-identification test to this new line from an unseen poem: "यादें पुराने खतों की तरह पीली पड़ जाती हैं।" Is this a metaphor? Why or why not? If not, what device is it?

## DIAGNOSTIC_ANSWER_3
**Correct Answer:** No, this is *not* a metaphor. It uses "की तरह" (like), which makes it a **simile (उपमा)**, explicitly comparing memories to old letters using a comparative marker. A metaphor would drop "की तरह" and say "यादें पुराने खत हैं" (Memories *are* old letters).  
**Wrong Answer Reveals:** If the student calls it a metaphor because "two things are compared", they have not internalized the *structural* difference: metaphor = identity (A is B); simile = resemblance (A is like B). This is the single most frequent board-exam error in device identification.

## DIAGNOSTIC_QUESTION_4
Compare the *dominant* imagery in Poem 1 (nature/sky/darkness) with the *dominant* imagery in Poem 2 (lamp/house/light). How does the shift in sensory focus reflect the shift in the speaker's psychological state across the two poems?

## DIAGNOSTIC_ANSWER_4
**Correct Answer:** Poem 1 relies on *visual* and *tactile* imagery of vast darkness (sky, shadow, night) conveying helplessness and exposure. Poem 2 shifts to *visual* (lamp flame), *tactile* (warmth), and *olfactory* (ghee/oil smell) imagery of a small, controlled light inside a house — conveying agency, shelter, and fragile hope. The move from open-sky darkness to enclosed-house light mirrors the speaker's journey from passive suffering to active endurance.  
**Wrong Answer Reveals:** If the student lists images from both poems but does not *contrast* their sensory *quality* (vast vs. intimate, cold vs. warm) or link them to *psychological shift*, they are doing inventory, not analysis. Board examiners penalize "device-spotting" without "effect-explaining."

## DIAGNOSTIC_QUESTION_5
Evaluate this claim: "The metaphor 'बज़'ओज' (lamp) in Poem 2 is more effective than the imagery in Poem 1 because a metaphor *explains* the theme while imagery only *decorates* it." Defend or refute with evidence from both poems.

## DIAGNOSTIC_ANSWER_5
**Correct Answer:** The claim is **false**. Imagery in Poem 1 (e.g., "er epy" — your shadow) does not merely decorate; it *embodies* the theme of existential darkness *viscerally*, making the reader *feel* the weight before any intellectual understanding. The metaphor "बज़'ओज" (lamp = hope/guidance) *condenses* the theme intellectually. Both are essential: imagery = affective entry; metaphor = cognitive anchor. Effectiveness depends on *function*, not device hierarchy.  
**Wrong Answer Reveals:** If the student agrees, they hold the widespread misconception that "figures of speech = ornamentation (अलंकार)" and "imagery = decoration." Senior secondary analysis requires recognizing imagery as *structural* to meaning, not ornamental.

## DIAGNOSTIC_QUESTION_6
Write a four-line Hindi poem-stanza (छंद) on "exam stress" that uses **at least two distinct sensory images** and **one metaphor** (without "जैसे/वैसे"). Label each device in brackets after the line.

## DIAGNOSTIC_ANSWER_6
**Expected Answer Criteria:**  
- Line 1: Visual image (e.g., "सफेद कागज़ काली स्याही से डरता है" [दृश्य बिंब])  
- Line 2: Auditory image (e.g., "घड़ी की टिक-टिक दिल में हथौड़े-सी बजती है" [श्रव्य बिंब])  
- Line 3: Tactile image (e.g., "हथेलियाँ ठंडी, माथा तवे-सा तपता है" [स्पर्श बिंब])  
- Line 4: Metaphor (e.g., "परीक्षा एक अँधेरी सुरंग है जहाँ रोशनी मैं खुद हूँ" [रूपक])  
**Poor Answer Reveals:** If the student uses "जैसे/वैसे" in the metaphor line, or uses only visual images, or writes a simile instead of metaphor, they have not mastered the *structural constraints* of each device. This creation task exposes whether the distinction is operational or merely memorized.

## COMMON_MISCONCEPTION
**Specific Error:** Students believe "बिंब (imagery) = दृश्य वर्णन (visual description only)" and "रूपक (metaphor) = अलंकार (ornament)".  
**Why It Happens:** In Class 9-10, Hindi textbooks often teach अलंकार (figures of speech) as a *list of decorative devices* with examples like "चन्द्रमा मुख है" (metaphor) and "फूल-सा कोमल" (simile), reducing both to "beautification." The NCERT Class 11 Aroh chapter "vDd osQ opu" deliberately uses imagery to *construct* the poem's psychological reality (darkness as lived experience) and metaphor to *redefine* the self (lamp as agency). Students who memorize definitions but do not trace *function* will write "the poet uses imagery to make the poem beautiful" — a Class 10 answer that scores 1/4 in Class 11 boards.

## ON_FAILURE
1. **Sensory Sorting Drill:** Give the student 10 lines from the two poems (e.g., "epy", "lrk", "iqFky", "yypk", "bZ'oj", "pjkpj"). Ask them to sort each into: Visual / Auditory / Tactile / Olfactory / Gustatory. Do this *before* discussing meaning.  
2. **Metaphor Surgery:** Take a simile from the text or elsewhere (e.g., "जीवन फूल जैसा है"). Ask the student to *remove* "जैसा" and rewrite as metaphor ("जीवन फूल है"). Then ask: "What changed in the *force* of the statement?" Guide them to feel the shift from *comparison* to *identity*.  
3. **Function Mapping:** For each device found, fill a 3-column table: Device | Quoted Phrase | What Theme It *Serves* (not "what it means"). Force the link to theme (loneliness, hope, resistance).  
4. **Board-Style Practice:** Give a 3-mark question: "How does the imagery of darkness in Poem 1 prepare the reader for the metaphor of the lamp in Poem 2?" Require a 4-sentence PEEL answer.

## BUILDS_ON
c11_hin_ar_cbse_14_006 (Primary Theme) and c11_hin_ar_cbse_14_007 (Secondary Themes) — students must know the themes (existential darkness, fragile hope, resistance) *before* analyzing how devices serve them.

## LEADS_TO
c11_hin_ar_cbse_14_009 (Irony and Symbolism) — metaphor mastery is prerequisite for understanding symbol (where the metaphorical object *becomes* a recurring symbol) and irony (where the metaphorical meaning is subverted).

## PREREQUISITE_NODE_IDS
c11_hin_ar_cbse_14_001, c11_hin_ar_cbse_14_002, c11_hin_ar_cbse_14_003, c11_hin_ar_cbse_14_004, c11_hin_ar_cbse_14_005, c11_hin_ar_cbse_14_006, c11_hin_ar_cbse_14_007
## PREREQUISITE_REASONS
c11_hin_ar_cbse_14_001: Context/background tells us the poet is a tribal woman writing in Assamese, translated — crucial for reading the "lamp" metaphor as cultural resistance, not just domestic image.  
c11_hin_ar_cbse_14_002: Narrative structure shows Poem 1 = past trauma, Poem 2 = present resistance — devices map onto this temporal shift.  
c11_hin_ar_cbse_14_003: Setting (open sky vs. house) directly determines the imagery palette (vast darkness vs. intimate light).  
c11_hin_ar_cbse_14_004: Protagonist's character (endurance, agency) is *built* through the lamp metaphor — she *becomes* the lamp.  
c11_hin_ar_cbse_14_005: Supporting characters (king, husband) appear only as shadows in Poem 1 imagery — their absence in Poem 2 light is meaningful.  
c11_hin_ar_cbse_14_006: Primary theme (survival/resistance) is the *target* every device serves — analysis without theme is empty.  
c11_hin_ar_cbse_14_007: Secondary themes (gender, tribal identity, language) are encoded in specific metaphors (e.g., "bZ'ओज" as tribal knowledge-keeping).

## FORWARD_NODE_IDS
c11_hin_ar_cbse_14_009, c11_hin_ar_cbse_14_010, c11_hin_ar_cbse_14_011, c11_hin_ar_cbse_14_012, c11_hin_ar_cbse_14_013, c11_hin_ar_cbse_14_014, c11_hin_ar_cbse_14_015, c12_hin_a_cbse_04_008, c12_hin_a_cbse_05_008, c12_hin_a_cbse_14_008, c12_hin_a_cbse_16_008, c12_hin_ar_cbse_14_008

## FORWARD_REASONS
c11_hin_ar_cbse_14_009: Symbolism extends metaphor (a metaphor repeated across the text becomes a symbol); irony often subverts a metaphor's expectation — both require metaphor fluency.  
c11_hin_ar_cbse_14_010: Key vocabulary (e.g., "ik'k", "<hy", "en", "pjkpj") appears *inside* images/metaphors — meaning is unlocked only via device analysis.  
c11_hin_ar_cbse_14_011: Grammatical structures (imperatives "gs", "vks"; compounds "pUuefYydktqZu") *create* the metaphorical voice — device and grammar are co-constitutive.  
c11_hin_ar_cbse_14_012: Inferential comprehension questions (e.g., "Why 'bZ'ओज'?") demand device-based evidence.  
c11_hin_ar_cbse_14_013: Critical interpretation *is* device-analysis elevated to thematic argument.  
c11_hin_ar_cbse_14_014: Writing tasks (analytical paragraph, character diary) require quoting and explaining devices.  
c11_hin_ar_cbse_14_015: Discussion points (e.g., "Is the lamp a symbol of hope or burden?") need device-vocabulary to articulate.
c12_hin_a_cbse_04_008: Dead vs. live metaphor exercise — directly used in Diagnostic Q5.  
c12_hin_a_cbse_05_008: Models board-exam style answers for device questions.  
c12_hin_a_cbse_14_008: Class 11 foundation on imagery and metaphor definitions and simple identification.  
c12_hin_a_cbse_16_008: Prepares for multi-device interaction (imagery + metaphor + irony).  
c12_hin_ar_cbse_14_008: Provides foundational definitions and identification practice of imagery/metaphor in Class 11 texts; this node advances to thematic analysis in Class 12. c12_hin_ar_cbse_14_001: Context/background on Muktibodh's progressive ideology explains *why* he chooses sensory immersion — to make poverty tangible. c12_hin_ar_cbse_14_002: Plot/narrative structure knowledge helps locate *where* key images/metaphors appear (opening description, fakir's interior monologue, ending). c12_hin_ar_cbse_14_003: Setting/atmosphere node establishes the physical world (the hut, the lane) that imagery builds and metaphor transforms. c12_hin_ar_cbse_14_006: Primary theme (human dignity) is the anchor — all device analysis must link back to this.  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
No prior class nodes available for cross-subject mapping in Hindi Aroh.

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_14_001 -> c11_hin_ar_cbse_14_008 -> c11_hin_ar_cbse_14_009 : Context establishes the poet's tribal voice; imagery/metaphor analysis decodes that voice; symbolism/irony reveal its deeper cultural strategy.

## THIS_FORMULA
N/A - conceptual

## FORMULA_VARIABLES
N/A

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
linguistic

## CROSS_SUBJECT
c11_history_colonialism_tribal | The poet व्देद्ग्न्सोह's use of the lamp metaphor (बज़'ओज) reflects tribal oral tradition's resistance to colonial/state erasure — just as historical sources show tribal communities using cultural symbols (songs, objects) to assert identity against administrative categorization.  
c11_geography_human_environment | The imagery shift from open-sky darkness (Poem 1) to house-bound light (Poem 2) mirrors geographical concepts of "exposed landscape" vs. "settlement space" — the poem enacts the human need to create micro-climates of safety in hostile macro-environments.

## PREREQ_CONCEPT
The student must understand that literary devices in Class 11 are not "decorations" but *meaning-making tools* — each image/metaphor is a deliberate choice that constructs the poem's thematic argument.

## PREREQ_BEFORE
The student must have read both poems in the chapter at least twice, marked every sensory word, and underlined every "A is B" statement without "like/as".

## PREREQ_STUCK
If stuck, review the **Theme nodes (006, 007)** — every device analysis question in boards is secretly a theme question: "How does [device] develop [theme]?"

## WORKED_EXAMPLE_1
PROBLEM: Analyze the visual and tactile imagery in the first stanza of Poem 1 ("gs Hkw[k! er epy ... gs en! er dj engks'k") and explain how it establishes the poem's central conflict.

STEPS:
- Step 1: Read the stanza aloud twice. Mark every word that triggers a sense: "Hkw[" (sky - visual), "epy" (shadow - visual/tactile), "rM+i" (night - visual), "lrk" (darkness - visual), "ozQksèk" (lightning - visual), "epk" (your - possessive, intimate), "mFky&iqFky" (opening-closing - tactile/kinesthetic), "yksHk" (laughter? sound - auditory), "yypk" (weeping? - auditory), "engks'k" (silence - auditory absence).
- Step 2: Categorize each marked word by sense modality. Dominant: Visual (sky, shadow, night, darkness, lightning). Secondary: Tactile (opening/closing, implying physical pressure). Auditory: Laughter/weeping/silence — a soundscape of extremes.
- Step 3: Identify the *pattern*: The imagery moves from vast cosmic visuals (sky, night) to intimate bodily sensations (opening/closing, laughter/weeping). This is a "cosmic-to-corporeal" zoom.
- Step 4: Connect pattern to conflict. The vast darkness (sky/night) represents the *external* oppression (king's injustice, displacement). The bodily sensations (opening/closing, laughter/weeping) represent the *internal* response — the protagonist's body registering trauma. The conflict = external overwhelming force vs. internal fragile sensorium.
- Step 5: Verify with theme. The central theme (from node 006) is "survival through endurance." The imagery *enacts* this: the sky's shadow is the threat; the body's opening/closing is the endurance. No device is ornamental — each is a brick in the thematic architecture.

REASONING: This 5-step method (Read→Mark→Categorize→Pattern→Theme-Link) works because it forces the student to move from *inventory* (what devices are there?) to *function* (what do they do?). Board examiners reward the shift from "the poet uses visual imagery" to "the cosmic-to-corporeal zoom enacts the conflict between state power and tribal body."

ANSWER: The first stanza uses dominant visual imagery (sky, shadow, night, darkness, lightning) to establish an overwhelming external darkness — the king's injustice as cosmic force. Tactile imagery ("mFky&iqFky" — opening/closing) and auditory extremes ("yksHk"/"yypk" — laughter/weeping) bring the conflict into the protagonist's body. The "cosmic-to-corporeal" zoom structures the central conflict: vast oppressive power vs. intimate human endurance.

## WORKED_EXAMPLE_2
PROBLEM: Identify the central metaphor in Poem 2 ("gs esjs twgh osQ iwQy tSls bZ'ओज ...") and explain its three-layered comparison: literal object → implied comparison → thematic significance.

STEPS:
- Step 1: Locate the metaphor. The line "gs esjs twgh osQ iwQy tSls bZ'ओज" *appears* to use "tSls" (like) — but wait: the poem says "bZ'ओज" is *addressed* as "you" ("vkbZ gw¡ lans'k ysdj pUuefYydktqZu dk"). The speaker *speaks to* the lamp as if it *is* the guide. The metaphor is **implied/extended**: The lamp (बज़'ओज) = The Guide/Protector (pUuefYydktqZu nso's role).
- Step 2: Break the three layers. Layer 1 (Literal): A physical oil-lamp (बज़'ओज) — small flame, ghee/oil, wick, flickering in wind. Layer 2 (Implied Comparison): The lamp *is* the tribal leader/guide (pUuefYydktqZu nso) who "holds the light" for the community. Layer 3 (Thematic): The lamp *is* the act of *bearing witness* and *transmitting knowledge* across darkness — the poet's own role.
- Step 3: Find textual evidence for each layer. Layer 1: "pjkpj" (wick/oil), "lans'k" (flame), "Hkwy" (wind). Layer 2: "pUuefYydktqZu dk" (of the leader), "lans'k ysdj" (carrying the light). Layer 3: "viuk ?kj ... >ksyh iSQykÅ¡" (my house fully lit), "u feys Hkh[k" (not just showing) — the light *transforms* the space.
- Step 4: Analyze why "lamp" specifically. Not sun (too big), not torch (too modern), not fire (too destructive). Lamp = *domestic, portable, fueled by labor (ghee/oil), requires tending* — perfect for tribal female leadership: sustained, intimate, labor-based, vulnerable yet persistent.
- Step 5: Synthesize. The metaphor is not "lamp represents hope" (cliché). It is: **Leadership = the daily, vulnerable, laborious act of keeping a small flame alive in a specific house so others can find their way.** This redefines power from "king's sword" (Poem 1) to "woman's lamp" (Poem 2).

REASONING: Metaphor analysis at Class 11 requires *layering* (literal → implied → thematic) and *specificity* (why *this* vehicle?). The "three-layer" method prevents the generic "lamp = hope" answer. The textual evidence hunt (Step 3) ensures the interpretation is grounded, not imposed.

ANSWER: The central metaphor is the **lamp (बज़'ओज) as tribal guide/leader (पुएफयिडक्त्ज़ु न्सो)** — an extended, implied metaphor where the speaker addresses the lamp as the leader. Three layers: (1) Literal: a small, ghee-fueled, wind-vulnerable flame in a house. (2) Implied: the leader who "carries the light" (lans'k ysdj) for the community. (3) Thematic: leadership redefined as *domestic, laborious, intimate persistence* — not royal spectacle but a woman tending a flame so "my house is fully lit" (viuk ?kj ... >ksyh iSQykÅ¡). The metaphor shifts power from the king's sword (Poem 1) to the woman's lamp.

## WORKED_EXAMPLE_3
PROBLEM: A board-style 4-mark question: "How does the interplay of imagery and metaphor in the two poems trace the protagonist's journey from victimhood to agency? Answer with reference to at least two images and one metaphor."

STEPS:
- Step 1: Deconstruct the prompt. It demands: (a) interplay (not separate lists), (b) journey arc (victimhood → agency), (c) evidence: 2+ images + 1 metaphor, (d) 4 marks = ~80-100 words, structured.
- Step 2: Select evidence. Image 1 (Poem 1, victimhood): "er epy" (your shadow) + "rM+i er lrk" (night's darkness) — visual imagery of *being covered* by external darkness. Image 2 (Poem 2, agency): "viuk ?kj ... >ksyh iSQykÅ¡" (my house fully lit) — visual + tactile (warmth) imagery of *creating* light. Metaphor (bridge): "bZ'ओज" (lamp) = the *act* of turning victimhood into agency.
- Step 3: Trace the arc. Poem 1 imagery = *passive reception* of darkness (sky's shadow falls *on* her). Poem 2 imagery = *active projection* of light (she lights the lamp, *her* house is lit). The metaphor "lamp" is the *pivot* — the object she *holds* that transforms her from "one upon whom shadow falls" to "one who holds light for others."
- Step 4: Draft PEEL structure. Point: The poems trace a journey from imposed darkness to claimed light through a shift from receptive imagery to projective imagery, mediated by the lamp metaphor. Evidence: Poem 1's "er epy / rM+i er lrk" (visual: darkness descending). Poem 2's "viuk ?kj >ksyh iSQykÅ¡" (visual/tactile: light radiating from within her space). Explanation: The first images position her as object of oppression; the second positions her as subject of resistance. The lamp metaphor ("bZ'ओज = guide") is the *instrument* of this subjectification — she *becomes* the lamp. Link: Thus, devices do not merely describe the journey; they *enact* the epistemological shift from tribal victim to tribal leader.
- Step 5: Polish for board language. Use terms: "प्राप्त बिंब" (receptive imagery), "प्रक्षेपित बिंब" (projective imagery), "रूपक-संधि" (metaphor-hinge). Ensure 4-mark length.

REASONING: This example models the *exact* board-exam skill: integrating multiple devices into a *single thematic argument* with precise textual evidence and technical vocabulary. The "receptive→projective" frame is a high-level analytical lens that distinguishes Band 6 (90%+) answers.

ANSWER: The two poems map the protagonist's journey from victimhood to agency through a decisive shift from **receptive imagery** (darkness received) to **projective imagery** (light emitted), hinged on the **lamp metaphor**. In Poem 1, visual images "er epy" (your shadow) and "rM+i er lrk" (night's darkness) position her as passive recipient — darkness *falls upon* her, mirrorating the king's imposed injustice. In Poem 2, the visual-tactile image "viuk ?kj ... >ksyh iSQykÅ¡" (my house fully lit) shows her *generating* light from within her own space. The metaphor "बज़'ओज = पुएफयिडक्त्ज़ु" (lamp = guide) is the pivot: by *becoming* the lamp, she transforms the darkness that once covered her into the light she now *carries* for others. Devices thus enact, not just describe, her epistemological rise from tribal victim to tribal leader.

## COMPETENCY_QUESTION_1
QUESTION: A student writes: "The poet uses the image of lightning (ozQksèk) in Poem 1 to show that hope comes suddenly." Critique this interpretation using textual evidence. Is it a valid reading of the *imagery*? Why or why not?

COMPETENCY: Critical evaluation of peer interpretation / textual evidence reasoning

STEPS:
- Step 1: Locate "ozQksèक" in Poem 1 context. It appears in "ozQksèक] epk er mFky&iqFky" — lightning, *your* opening-and-closing. The lightning belongs to the *sky/night* ("epk" = your), not the speaker.
- Step 2: Analyze the imagery's tone. Lightning in this stanza is part of the *oppressive* cosmic display: sky's shadow, night's darkness, *then* lightning — all "your" (the sky's/king's). It illuminates only to reveal the terror; it "opens and closes" (mFky&iqFky) like a threatening eye.
- Step 3: Test the student's claim. "Hope comes suddenly" imposes a *positive* valence on an image that functions *negatively* in context. The poem's next lines: "yksHk] er yypk" (laughter? weeping?) — the lightning triggers *ambiguous* human sounds, not hope.
- Step 4: Formulate critique. The reading is **invalid** because it ignores: (a) possessive "epk" (your) attaching lightning to the oppressor, (b) the "mFky&iqFky" rhythm suggesting threat not promise, (c) the stanza's overall trajectory from darkness to bodily distress, not relief.
- Step 5: State what a valid reading would note: Lightning here is *terror's flash* — the moment the oppressor's power becomes visible, intensifying the victim's vulnerability.

ANSWER: The interpretation is **not valid**. The lightning (ozQksèक) appears as "epk er mFky&iqFky" — *your* (the sky's/oppressor's) opening-and-closing. It belongs to the cosmic force of darkness ("er epy", "rM+i er lrk"), not the speaker. Its rhythmic "opening-closing" (mFky&iqFky) evokes a predatory blink, not a hopeful flash. The following lines ("yksHk] er yypk") show it provokes *laughter/weeping ambiguity*, not hope. A valid reading: lightning = the oppressor's terrifying visibility, heightening the victim's exposure.

DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: The metaphor "बज़'ओज" (lamp) in Poem 2 is often read as "hope." But the poem says: "viuk ?kj ls D;k rkRi;Z gS\ bls Hkwyus dh ckr D;ksa dgh xbZ gS\" (What is the relation to my house? Why was it said to burn it?). Re-read the metaphor in light of this tension. Does the lamp represent *only* hope, or also *burden*? Argue with two pieces of evidence.

COMPETENCY: Nuanced interpretation / holding tension in metaphor / argumentation with evidence

STEPS:
- Step 1: Acknowledge the standard reading. "Lamp = hope/guidance" is supported by "lans'k ysdj pUuefYydktqZu dk" (carrying light for the leader) and ">ksyh iSQykÅ¡" (fully lit).
- Step 2: Introduce the counter-evidence. The rhetorical questions: "viuk ?kj ls D;k rkRi;Z gS" (what relation to my house?) and "bls Hkwyus dh ckr D;ksa dgh xbZ gS" (why was it said to burn it?). The house is *threatened with burning*; the lamp exists *in* that threatened house.
- Step 3: Analyze the metaphor's dual valence. The lamp is not a free-floating symbol of hope; it is a **domestic object inside a targeted house**. "pjkpj" (wick/oil) requires *constant feeding* — labor. "Hkwy" (wind) threatens it. The speaker *must* keep it alive *while* her house may be burnt.
- Step 4: Synthesize the argument. The lamp = **hope-as-burden** or **resistance-as-labor**. It is hope *because* it is a burden willingly borne. The metaphor's power lies in *refusing to separate* the two: the leader (pUuefYydktqZu nso) is not a savior on a hill but a woman tending a flame in a house the king wants to burn.
- Step 5: Select two precise evidences. Evidence 1: "pjkpj! er pwd volj" (wick! your oil flame) — the lamp's fragility (oil runs out, wick chars) = hope's fragility. Evidence 2: "dksbZ gkFk c<+k, oqQN nsus dks rks og fxj tk, uhps" (if someone gives a little shelter, they go under) — the lamp's light *endangers* those it shelters; hope carries risk.

ANSWER: The lamp metaphor **fuses hope and burden inseparably**. It is not "hope" as abstract optimism but **hope as sustained, endangered labor**. Evidence 1: "pjkpj! er pwd volj" — the wick and oil flame require *constant tending* (labor) and *inevitably consume themselves* (self-sacrifice). Evidence 2: The rhetorical challenge "bls Hkwyus dh ckr D;ksa dgh xbZ gS" (why was it said to burn it?) reveals the lamp exists in a house *marked for destruction* — its light is an act of defiance that *invites* the fire. The leader (pUuefYydktqZu) is not a distant beacon but a woman keeping a flame alive in a target zone. Thus, the metaphor redefines tribal leadership: not glory, but the daily, dangerous work of keeping light in a burnable house.

DIFFICULTY: hard