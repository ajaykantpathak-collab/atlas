## DEFINITION
Character analysis of supporting characters involves examining secondary figures in a literary text to understand their traits, motivations, relationships with the protagonist, and their function in advancing the plot or illuminating the theme. In Class 12 Hindi (Antra), this requires citing specific textual evidence from the chapter's prose excerpts (जयदेव, मैथिलीशरण गुप्त) and poem (रसखान की कविता) to justify inferences.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student can independently identify all supporting characters in the chapter's literary texts, extract 3+ pieces of textual evidence per character, explain each character's narrative function (foil, catalyst, thematic embodiment), and write a structured 100-150 word character sketch using the PEEL (Point, Evidence, Explanation, Link) format expected in CBSE board answers.

## SCOPE_BOUNDARY
This node covers supporting characters in the Chapter 6 literary texts only: the poem "हरि-केसव की प्रीति" (Hari-Kesav's love) and the prose excerpts from "जयदेव" and "मैथिलीशरण गुप्त". It does NOT cover the biographical sketch of रसखान (node 001) or the protagonist analysis of कृष्ण/जयदेव (node 004). It excludes thematic synthesis (node 006) and literary device identification (nodes 008, 009).

## WALKTHROUGH
Imagine you're asked: "How does Yashoda's anxiety in the prose excerpt reveal Krishna's divinity?" Don't just retell the story. First, re-read the specific prose segment (जयदेव अंश) and underline every line where Yashoda speaks, acts, or is described. Second, categorize these markings: her dialogues (speech), her actions (feeding, searching), others' reactions to her. Third, ask: "What does each category reveal about her personality AND about Krishna?" Fourth, connect one trait (e.g., maternal anxiety) to the theme (divine play/लीला). The key insight: supporting characters are mirrors — their limited perspective magnifies the protagonist's greatness.

## DIAGNOSTIC_QUESTION_1
Identify the two supporting characters who appear in BOTH prose excerpts (जयदेव and मैथिलीशरण गुप्त) but are absent from the poem "हरि-केसव की प्रीति".

## DIAGNOSTIC_ANSWER_1
Correct answer: यशोदा (Krishna's foster mother) and रोहिणी/बलराम की माता (implied in second excerpt). A wrong answer like "राधा" or "गोपियाँ" reveals the student cannot distinguish between the poem's characters (Hari/Kesav) and the prose excerpts' characters. This confusion stems from not separating the three distinct literary pieces in the chapter.

## DIAGNOSTIC_QUESTION_2
Explain in your own words why the author (जयदेव/मैथिलीशरण गुप्त) chooses to show Krishna's hunger through Yashoda's eyes rather than Krishna's own perspective.

## DIAGNOSTIC_ANSWER_2
Correct answer: Yashoda's limited human perspective (worry, inability to comprehend divine nature) creates dramatic irony — the reader knows Krishna is divine, but Yashoda sees only a hungry child. This contrast heightens the theme of लीला (divine play). A wrong answer like "to show mother's love" is incomplete; it misses the structural function of dramatic irony and the thematic purpose of contrasting human vs divine vision.

## DIAGNOSTIC_QUESTION_3
In the second prose excerpt (मैथिलीशरण गुप्त), Yashoda sends Krishna to Vrindavan. Using the PEEL structure, write ONE analytical paragraph (4-5 sentences) proving this action makes her a CATALYST for the plot.

## DIAGNOSTIC_ANSWER_3
Sample PEEL response: Point — Yashoda acts as a catalyst by forcing Krishna's departure. Evidence — She says "जा व्रज, देख अपने भूखे बालकों को" (Go to Vraj, see your hungry children). Explanation — This command initiates Krishna's physical journey to Vrindavan, shifting the setting from domestic space to pastoral लीला-ground. Link — Without her intervention, the narrative would remain static in Gokul; her maternal anxiety becomes the divine instrument for लीला's expansion. A wrong answer merely narrates the event without labeling the narrative function (catalyst) or using the term "dramatic agency".

## DIAGNOSTIC_QUESTION_4
Compare the portrayal of maternal anxiety in Yashoda (prose excerpt 1) vs. the implied mother-figure in the poem "हरि-केसव की प्रीति". How does the GENRE (prose vs poetry) change the depiction?

## DIAGNOSTIC_ANSWER_4
Correct answer: Prose (जयदेव) uses detailed narration — Yashoda's internal monologue, physical actions (चूल्हा जलाना, खोजना) — creating realistic, sustained anxiety. Poetry (रसखान) compresses it into lyrical intensity: "तूहीं फटु उकफ्क फुड ल्कप" — the mother's love is expressed through metaphor and rhythm, not narrative detail. A wrong answer lists similarities only ("both show love") ignoring how prose's expansive syntax vs poetry's condensed imagery shape the reader's emotional access.

## DIAGNOSTIC_QUESTION_5
Evaluate this student claim: "Rohini (Balram's mother) is a flat character because she has no dialogues in either excerpt." Defend or refute using textual evidence.

## DIAGNOSTIC_ANSWER_5
Refute. Flatness ≠ silence. Rohini functions as a thematic foil: her absence from dialogue contrasts with Yashoda's vocal anxiety, symbolizing the unseen, steadfast support behind divine missions. In the second excerpt, her implied presence (बलराम सहित) enables Krishna's journey — she releases Balram too. A wrong answer accepts the claim, confusing "flat" (lack of complexity) with "minor" (less page time). This reveals inability to distinguish character *role* from character *depth*.

## DIAGNOSTIC_QUESTION_6
Create a 4-line dialogue between Yashoda and Rohini that could be inserted into the second prose excerpt, revealing their contrasting attitudes toward Krishna's departure. Use vocabulary from the text (e.g., व्रज, लीला, माया).

## DIAGNOSTIC_ANSWER_6
Good answer example:
यशोदा: "व्रज भेजती हूँ कन्हैया को, मन काँपता है माया से।"
रोहिणी: "लीला है यह हरि की, बहन! बलराम संग जाएँगे दोनों।"
यशोदा: "भूखे बालक रोते द्वार, माँ का हृदय न समझे पार।"
रोहिणी: "जो पालत है जगत सारा, उसकी माँ तू, क्यों घबराई रे?"
Criteria: Uses text vocabulary, shows contrast (anxiety vs faith), maintains character voices. Poor answer: generic modern Hindi dialogue without textual vocabulary or thematic contrast.

## COMMON_MISCONCEPTION
Students treat supporting characters as "background decoration" and write only physical descriptions or plot summaries. They fail to see that in Bhakti literature, supporting characters (Yashoda, Rohini, Gopis) are THEOLOGICAL INSTRUMENTS — their human limitations (ignorance, anxiety, possessiveness) are deliberately crafted to highlight the protagonist's divinity (omniscience, detachment, लीला). For example, writing "Yashoda is a loving mother who cooks food" earns 1/5 marks; writing "Yashoda's culinary anxiety (चूल्हा जलाना) dramatizes the paradox of the Infinite submitting to finite hunger" earns full marks.

## ON_FAILURE
Step 1: Re-read node c12_hin_a_cbse_06_004 (Protagonist Analysis) to recall how Krishna's divinity is established. Step 2: Take the prose excerpt 1 (जयदेव). Highlight every verb associated with Yashoda in one color, every verb associated with Krishna in another. Step 3: For each Yashoda-verb, ask: "What does this human action reveal about the divine child?" Step 4: Write 3 PEEL paragraphs linking one verb each to a specific aspect of Krishna's divinity. Step 5: Self-check: Does each paragraph use the word "foil", "catalyst", or "dramatic irony"? If not, revise.

## BUILDS_ON
Character Analysis: Protagonist (c12_hin_a_cbse_06_004) — you must first know the protagonist's traits to see how supporting characters mirror/contrast them.

## LEADS_TO
Theme: Primary Theme and Message (c12_hin_a_cbse_06_006) — supporting characters' functions collectively construct the theme of लीला and भक्ति.

## PREREQUISITE_NODE_IDS
c12_hin_a_cbse_06_004, c12_hin_a_cbse_06_002, c11_hin_v_cbse_01_005, c11_hin_v_cbse_02_005, c11_hin_v_cbse_03_005, c12_hin_a_cbse_06_001, c12_hin_a_cbse_06_003

## PREREQUISITE_REASONS
c12_hin_a_cbse_06_004: Protagonist analysis provides the benchmark against which supporting characters are measured (foil/catalyst). c12_hin_a_cbse_06_002: Plot structure knowledge tells you WHERE supporting characters enter/exit and their narrative weight. c11_hin_v_cbse_01_005: Class 11 Antra character analysis basics (identifying traits, evidence). c11_hin_v_cbse_02_005: Class 11 practice with Bhakti poetry characters (different genre conventions). c11_hin_v_cbse_03_005: Class 11 practice with prose character sketches (PEEL structure foundation).
c12_hin_a_cbse_06_001: Supporting characters (gopis, cowherds) derive from the Bhakti milieu.  
c12_hin_a_cbse_06_003: Supporting characters (Hajar, mother) defined by their relationship to sacred spaces  
c12_hin_a_cbse_06_002: Plot and narrative structure refers to the organized sequence of events and the framework... की समझ आवश्यक है, क्योंकि यह नोड (Character analysis of supporting characters involves examining secondary figures in a lite...) इसी आधार पर आगे बढ़ता है।  
c11_hin_v_cbse_01_005: Character analysis of supporting characters involves examining how secondary figures in a... की समझ आवश्यक है, क्योंकि यह नोड (Character analysis of supporting characters involves examining secondary figures in a lite...) इसी आधार पर आगे बढ़ता है।  
c11_hin_v_cbse_02_005: Supporting characters in "जक्तLFkku dh jtr cw¡nas" are the collective voices—पस्तकाथ (labo... की समझ आवश्यक है, क्योंकि यह नोड (Character analysis of supporting characters involves examining secondary figures in a lite...) इसी आधार पर आगे बढ़ता है।  
c11_hin_v_cbse_03_005: Character analysis of supporting characters involves examining how secondary figures in a... की समझ आवश्यक है, क्योंकि यह नोड (Character analysis of supporting characters involves examining secondary figures in a lite...) इसी आधार पर आगे बढ़ता है।  

## FORWARD_NODE_IDS
c12_hin_a_cbse_06_006, c12_hin_a_cbse_06_013, c12_hin_a_cbse_06_014, c12_hin_a_cbse_06_012

## FORWARD_REASONS
c12_hin_a_cbse_06_006: Theme synthesis requires aggregating insights from all characters (protagonist + supporting). c12_hin_a_cbse_06_013: Critical thinking questions often ask "How does character X reveal theme Y?" — needs this node's analytical skill. c12_hin_a_cbse_06_014: Writing skills (character sketch, comparative essay) directly apply the PEEL templates practiced here.
c12_hin_a_cbse_06_012: Supporting characters offer additional textual clues.  
c12_hin_a_cbse_06_013: Supporting characters (gopis, Radha) whose voices appear in poems; needed for multi-perspective analysis.  
c12_hin_a_cbse_06_014: अगला तार्किक चरण: Writing Skills based on the chapter refers to the ability to compose structured, evidence-based anal... इस नोड की अवधारणाओं को सीधे उपयोग/विस्तारित करता है।  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
c12_history_bhakti_movement: Understanding 16th-century Bhakti context explains WHY poets use supporting characters as theological instruments (e.g., Yashoda's anxiety = soul's longing for God). c12_psychology_social_cognition: Theory of Mind concepts explain how readers infer divine nature through limited human perspectives (dramatic irony as cognitive gap).

## CHAIN_DESCRIPTION
c12_hin_a_cbse_06_004 -> c12_hin_a_cbse_06_005 -> c12_hin_a_cbse_06_006

## THIS_FORMULA
N/A - conceptual

## FORMULA_VARIABLES
N/A

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
analytical

## CROSS_SUBJECT
N/A | Supporting characters in Bhakti poetry (Yashoda, Gopis) function as allegorical representations of the individual soul (जीवात्मा) — their separation anxiety mirrors the devotee's separation from God.
 N/A | Character analysis requires Theory of Mind: inferring unspoken mental states (Yashoda's fear, Krishna's amusement) from textual behavior — a core social cognition skill tested in psychology.
## PREREQ_CONCEPT
PEEL paragraph structure (Point, Evidence, Explanation, Link) and ability to distinguish flat vs round characters.

## PREREQ_BEFORE
Student can write a 4-sentence PEEL paragraph for the protagonist (Krishna) using textual quotes.

## PREREQ_STUCK
If stuck on PEEL, revisit c12_hin_a_cbse_06_004 Worked Example 2. If stuck on textual evidence location, revisit c12_hin_a_cbse_06_002 Plot node.

## WORKED_EXAMPLE_1
PROBLEM: Write a character sketch of Yashoda in the first prose excerpt (जयदेव) using PEEL structure. Focus on her role as a FOIL to Krishna's divinity.

STEPS:
- Step 1: Identify the task — character sketch of supporting character (Yashoda) with specific narrative function (foil). Locate the text: first prose excerpt, lines describing Yashoda's actions/dialogues.
- Step 2: Extract evidence — (a) "चूल्हा जलाती", (b) "खोजती फिरती", (c) "रोती-बिलखती", (d) "नहीं जानती कन्हैया हरि हैं". These are 4 distinct behavioral units.
- Step 3: Map each evidence to a trait + foil function — (a) domestic labor → human limitation vs Krishna's cosmic control; (b) frantic search → ignorance vs Krishna's omniscience; (c) emotional outburst → attachment vs Krishna's detachment; (d) explicit ignorance statement → dramatic irony device.
- Step 4: Draft PEEL paragraphs — Paragraph 1 (Point: Yashoda embodies human ignorance; Evidence: "नहीं जानती..."; Explanation: creates dramatic irony; Link: establishes लीला framework). Paragraph 2 (Point: Maternal anxiety as divine instrument; Evidence: "चूल्हा जलाती/खोजती"; Explanation: human effort enables divine play; Link: theme of surrender).
- Step 5: Verify against CBSE marking — each paragraph has Point, textual quote, analytical explanation, thematic link. No plot summary. Uses terms "foil", "dramatic irony", "लीला".

REASONING: This works because it forces the student to move from "what she does" to "what her doing means structurally." The foil concept is the analytical bridge between character and theme.

ANSWER: Yashoda functions as a deliberate foil to Krishna's divinity. Her domestic labor ("चूल्हा जलाती") contrasts the Infinite submitting to finite hunger. Her frantic search ("खोजती फिरती") highlights Krishna's omniscience through her ignorance. Her explicit unawareness ("नहीं जानती कन्हैया हरि हैं") creates dramatic irony — the reader knows the divine identity she misses. Thus, her human limitations become the canvas on which Krishna's लीला is painted.

## WORKED_EXAMPLE_2
PROBLEM: Analyze how the character of Rohini (Balram's mother) — though silent and barely mentioned — acts as a STRUCTURAL CATALYST in the second prose excerpt (मैथिलीशरण गुप्त).

STEPS:
- Step 1: Locate Rohini's textual traces — Second excerpt: "बलराम सहित" (with Balram), "दोनों भ्राता" (both brothers). She is never named, only implied through Balram.
- Step 2: Determine narrative function — Balram cannot go to Vrindavan without his mother's permission. Her implied consent (sending both sons) enables the journey. This is catalytic agency without presence.
- Step 3: Connect to theme — Rohini represents the "silent assent" of the material world to divine will. Unlike Yashoda's vocal anxiety, Rohini's silence = acceptance. This duality (anxiety vs assent) maps the two human responses to लीला.
- Step 4: Compare with Yashoda — Yashoda = active resistance (worry, command to return); Rohini = passive facilitation (release). Both are necessary: resistance creates tension, assent enables motion.
- Step 5: Write analytical claim — "Rohini's absent presence catalyzes the spatial shift from Gokul to Vrindavan, embodying the theological principle that divine play requires both the devotee's struggle (Yashoda) and the world's surrender (Rohini)."

REASONING: This example teaches "reading absence" — a high-level skill for competitive exams (CUET, JEE Advanced comprehension). Students often ignore characters who don't speak; this shows how silence carries structural weight.

ANSWER: Rohini is a structural catalyst. Her implied consent ("बलराम सहित") releases both brothers for the Vrindavan journey — without it, Krishna goes alone, altering the लीला's fraternal dimension. Her silence contrasts Yashoda's vocal anxiety, representing the dual human response to divine will: struggle (Yashoda) and surrender (Rohini). The text uses her absence to show that the material world's silent assent is as necessary for लीला as the devotee's active love.

## WORKED_EXAMPLE_3
PROBLEM: Compare the portrayal of "maternal figure" across ALL THREE literary pieces in Chapter 6: Poem (हरि-केसव की प्रीति), Prose 1 (जयदेव), Prose 2 (मैथिलीशरण गुप्त). How does the SHIFT IN GENRE (poetry → prose → prose) transform the maternal archetype?

STEPS:
- Step 1: Identify maternal figures in each — Poem: Implicit mother (addressed as "मैया" in Hari's voice? Actually poem is Hari-Kesav dialogue; mother invoked metaphorically). Prose 1: Yashoda (explicit, central). Prose 2: Yashoda + implied Rohini.
- Step 2: Analyze genre constraints — Poetry (रसखान): condensed, lyrical, metaphorical — mother as "love's anchor" (भावनात्मक आधार). Prose 1 (जयदेव): narrative, descriptive, psychological — mother as "anxious caregiver" (यथार्थवादी चिंता). Prose 2 (मैथिलीशरण गुप्त): dramatic, dialogue-driven, theological — mother as "divine instrument" (लीला की साधन).
- Step 3: Trace evolution — From metaphor (poem) → realistic portrayal (prose 1) → theological agent (prose 2). The mother gains AGENCY across the chapter: poem = symbol; prose 1 = character; prose 2 = plot-mover.
- Step 4: Link to authorial intent — Raskhan (poet) uses mother as bhakti metaphor; Jayadeva (prose 1) uses her for narrative realism; Maithilisharan (prose 2) uses her for theological argument (divine play requires human participation).
- Step 5: Synthesize — The chapter deliberately layers three genre-lenses on the same archetype to show Bhakti's evolution: from feeling (काव्य) to storytelling (कथा) to philosophy (तत्व).

REASONING: This multi-text, multi-genre comparison is exactly what CBSE competency questions (case-based) and CUET literary analysis demand. It integrates nodes 002 (plot), 003 (setting), 008 (imagery), and this node.

ANSWER: The maternal archetype evolves from lyrical metaphor to theological agent across the chapter's three texts. In Raskhan's poem, "मैया" is a compressed symbol of unconditional love (भक्ति का रूपक). In Jayadeva's prose, Yashoda becomes a psychologically realistic mother — her anxiety (चूल्हा, खोज) grounds the divine in domestic detail. In Maithilisharan's prose, she transforms into a catalytic agent — her command "जा व्रज" structurally initiates the लीला. Genre drives this: poetry's condensation → prose's expansion → dramatic prose's agency. Together, they map the Bhakti trajectory: emotion → narrative → philosophy.

## COMPETENCY_QUESTION_1
QUESTION: A CBSE sample paper asks: "How does the character of Yashoda in the prose excerpt 'जयदेव' serve as a vehicle for dramatic irony? Support your answer with two specific textual references." Write a 60-word answer following board marking scheme.

COMPETENCY: Textual Analysis & Board Answer Writing
STEPS:
- Step 1: Define dramatic irony in this context — reader knows Krishna is God; Yashoda does not.
- Step 2: Select Reference 1 — "नहीं जानती कन्हैया हरि हैं" (explicit ignorance statement).
- Step 3: Select Reference 2 — "चूल्हा जलाती... खोजती फिरती" (actions based on ignorance).
- Step 4: Explain the irony mechanism — her human worry (cooking/searching) is futile for the Omnipotent, yet the text treats it as necessary for लीला.
- Step 5: Compress into 60 words with PEEL bones.

ANSWER: Yashoda creates dramatic irony because the reader knows Krishna's divinity while she sees only a child. Reference 1: "नहीं जानती कन्हैया हरि हैं" — her explicit ignorance contrasts reader's knowledge. Reference 2: "चूल्हा जलाती... खोजती फिरती" — her frantic domestic labor is ironic because the Universe's sustainer cannot be fed/found by human effort. Her anxiety thus becomes the canvas for लीला's revelation.
DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: (CUET-style) The chapter presents three maternal figures across poem/prose: the invoked "मैया" (poem), Yashoda (prose 1), and Yashoda+Rohini (prose 2). Argue whether this triangulation represents a DEVELOPMENT in the Bhakti conception of the Goddess/Devotee relationship, or merely different genre conventions. Use evidence from all three texts.

COMPETENCY: Intertextual Synthesis & Critical Argumentation
STEPS:
- Step 1: Thesis — It represents BOTH: genre conventions ENABLE the theological development. Poetry's metaphor → prose's realism → dramatic prose's agency = historical deepening of Bhakti thought.
- Step 2: Poem evidence — "मैया" as pure प्रेम (love) without narrative context = early Bhakti's emotional intensity.
- Step 3: Prose 1 evidence — Yashoda's anxiety (चूल्हा/खोज) introduces मानवीय कमजोरी (human frailty) — the devotee's limited vision.
- Step 4: Prose 2 evidence — Yashoda's command + Rohini's assent = devotee as ACTIVE PARTICIPANT in divine will (सहचरी भाव).
- Step 5: Synthesis — Genre shift (lyric→narrative→drama) mirrors Bhakti's shift from feeling → story → philosophy. The triangulation IS the development.

ANSWER: The triangulation represents theological development THROUGH genre evolution. Poem (Raskhan): "मैया" as pure प्रेम-metaphor — Bhakti as feeling. Prose 1 (Jayadeva): Yashoda's anxiety (चूल्हा/खोज) introduces the devotee's limited vision — Bhakti as human struggle. Prose 2 (Maithilisharan): Yashoda's command "जा व्रज" + Rohini's silent assent make mothers active instruments of लीला — Bhakti as divine-human collaboration. Genre conventions (lyric compression, narrative realism, dramatic agency) are the VEHICLES for this historical deepening from emotion to participation.
DIFFICULTY: hard