## DEFINITION
Literal comprehension questions require students to retrieve explicitly stated information from the text (facts, details, sequences), while inferential comprehension questions require students to derive implied meaning by combining textual evidence with logical reasoning, background knowledge, and contextual clues.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student can independently distinguish between literal and inferential question types, locate precise textual evidence for literal answers, and construct a 4-step PEEL response (Point, Evidence, Explanation, Link) for inferential answers that integrates at least two separate textual references with logical justification.

## SCOPE_BOUNDARY
This node covers strategies for answering CBSE Class 11 Hindi Vitan Chapter 2 comprehension questions (literal and inferential) using the text "jktLFkku dh jtr cw¡nas". It does NOT cover critical appreciation, creative writing, or grammar analysis, which are addressed in sibling nodes.

## WALKTHROUGH
Imagine you are sitting in the exam hall and see a question: "Why do laborers risk their lives building embankments in flood-prone areas?" Your first instinct might be to write a general answer about poverty. But the examiner wants textual proof. Start by identifying the question type: is it asking for a fact directly stated (literal) or a reason implied (inferential)? For literal questions, scan the text for keywords like "oqaQbZ", "psyokath", "ikuh". For inferential questions, hunt for two or more connected details—e.g., the description of soil types (ikyjikuh, ikrkyikuh, jstk.khikuh) and the laborers' daily wage struggle—then synthesize them. The key insight: every inferential answer must be anchored in explicit textual evidence, not personal opinion.

## DIAGNOSTIC_QUESTION_1
What is the fundamental difference between a literal comprehension question and an inferential comprehension question in the CBSE Class 11 Hindi examination context?

## DIAGNOSTIC_ANSWER_1
A literal question asks for information directly stated in the text (e.g., "What are the three types of soil mentioned?"), while an inferential question asks for implied meaning requiring logical deduction from textual clues (e.g., "Why is jstk.khikuh considered most suitable for embankments?"). A wrong answer that defines both as "questions from the text" reveals the student cannot distinguish retrieval from reasoning, leading to vague answers lacking evidence.

## DIAGNOSTIC_QUESTION_2
In the passage, the author describes three soil types: ikyjikuh, ikrkyikuh, and jstk.khikuh. If a question asks, "Which soil type is best for embankment construction and why?", is this literal or inferential? Explain your reasoning.

## DIAGNOSTIC_ANSWER_2
This is an inferential question. The text states properties of each soil (literal facts) but does not explicitly declare one as "best"; the student must compare permeability, stability, and labor requirements across paragraphs to infer jstk.khikuh's superiority. A wrong answer labeling it literal shows the student mistakes explicit comparison for direct statement, missing the need to synthesize evidence.

## DIAGNOSTIC_QUESTION_3
A student writes this answer to "Why do laborers continue dangerous embankment work?": "Because they are poor and need money." Using the PEEL structure, identify the missing component and rewrite the answer with two textual evidences from the passage.

## DIAGNOSTIC_ANSWER_3
The answer lacks Evidence (E) and Explanation (E) from the text. A PEEL rewrite: Point: Economic compulsion drives laborers. Evidence 1: Text states workers receive annual advance (o"kZ Hkj) binding them to contractors. Evidence 2: Daily wages are minimal (nks&rhu ?kM+k Hkj) barely sustaining families. Explanation: The advance system creates debt bondage; low wages prevent escape. Link: This systemic exploitation, not mere choice, forces continued risk. A wrong answer adding only "text says so" without quotes reveals inability to locate specific textual support.

## DIAGNOSTIC_QUESTION_4
Compare the literal detail "embankments are built in flood-prone areas" with the inferential claim "the state prioritizes embankments over permanent flood solutions." What textual evidence supports the inference, and what logical gap must the student bridge?

## DIAGNOSTIC_ANSWER_4
Evidence: Text notes embankments are recurring (izÑfr dh mnkjrk), require annual repair (futh gksrs gq, Hkh), and displacing villages (xk¡o lekt dh lkoZtfud "kehu). Gap: The student must connect recurring expenditure + displacement + lack of alternatives → state's short-term policy preference. A wrong answer citing only "embankments break every year" without linking to policy priority shows failure to bridge description to implication.

## DIAGNOSTIC_QUESTION_5
Evaluate this student claim: "The author romanticizes the laborers' suffering by describing the soil types in poetic detail." Defend or refute using the author's tone and purpose as evidenced in the text.

## DIAGNOSTIC_ANSWER_5
Refute. The soil classification (ikyjikuh, ikrkyikuh, jstk.khikuh) serves technical exposition: it explains *why* construction fails (permeability, stability) and *why* specific labor is needed. Tone is observational ("oqaQbZ dk eq¡g NksVk j[kus osQ rhu cM+s dkj.k"), not emotive. A wrong answer agreeing with "romanticizes" reveals confusion between descriptive precision and literary embellishment, missing the text's documentary purpose.

## DIAGNOSTIC_QUESTION_6
Create an inferential question based on the passage's description of the "advance system" (o"kZ Hkj) and the laborers' cycle of debt, then provide a model PEEL answer.

## DIAGNOSTIC_ANSWER_6
Question: "How does the advance system perpetuate intergenerational bondage among embankment laborers?" Model Answer: Point: The advance system creates hereditary debt bondage. Evidence 1: Text states workers' names are recorded in "fo'ks"k Hkkst dk vk;kstu" (special labor register) from first day. Evidence 2: Children inherit parents' unfinished advances ("vkSj blh dkj.k mu xk¡oksa osQ uke Hkh ikj ij gh gSa"). Explanation: Annual advances exceed repayment capacity; debt transfers to next generation. Link: This institutionalizes a caste-like labor hierarchy, making escape structurally impossible. A poor answer listing only "they owe money" misses the systemic, intergenerational mechanism.

## COMMON_MISCONCEPTION
Students believe inferential questions allow "any reasonable opinion" and treat textual evidence as optional decoration. They write general knowledge answers (e.g., "floods destroy crops") instead of text-bound inferences (e.g., "text shows floods destroy standing crops *and* deposit infertile sand, forcing repeated embankment cycles"). This error stems from middle-school "personal response" tasks where opinion was rewarded; at senior secondary level, inference *must* be evidence-anchored.

## ON_FAILURE
1. Give the student a two-column table: Column A = Literal questions from the text (with answers), Column B = Inferential questions (with PEEL outlines). 2. Have them highlight textual evidence in the passage for each Column B answer using two colors: one for Evidence 1, another for Evidence 2. 3. Practice converting a literal question ("What is jstk.khikuh?") into an inferential one ("Why does the author call jstk.khikuh 've`r tSlk ehBk ikuh'?") by adding "why" and requiring two textual supports. 4. Provide a checklist: "Does my answer quote/paraphrase two distinct text segments? Does my explanation connect them logically?"

## BUILDS_ON
Builds on the student's ability to identify explicit facts in the text (literal comprehension) developed in Class 10 reading sections.

## LEADS_TO
Enables critical analysis and interpretation (node c11_hin_v_cbse_02_013) where students evaluate authorial choices and thematic depth using the same evidence-based reasoning.

## PREREQUISITE_NODE_IDS
c11_hin_v_cbse_02_001, c11_hin_v_cbse_02_002, c11_hin_v_cbse_02_010, c11_hin_v_cbse_02_006, c11_hin_v_cbse_02_007, c11_hin_v_cbse_02_009, c11_hin_v_cbse_02_011

## PREREQUISITE_REASONS
c11_hin_v_cbse_02_001: Context/background knowledge (flood geography, labor sociology) is essential for making valid inferences about the text's setting and characters.
c11_hin_v_cbse_02_002: Understanding plot/narrative structure helps locate where specific details appear for evidence retrieval.
c11_hin_v_cbse_02_010: Vocabulary in context (e.g., ikyjikuh, ikrkyikuh, jstk.khikuh, o"kZ Hkj) must be mastered to accurately interpret both literal and inferential questions.
c11_hin_v_cbse_02_006: Comprehension questions often ask "What is the central idea?" — direct application.  
c11_hin_v_cbse_02_007: Comprehension questions (literal and inferential) test whether students can locate textual evidence for secondary themes.  
c11_hin_v_cbse_02_009: Comprehension questions require identifying and explaining irony/symbolism for inferential answers.  
c11_hin_v_cbse_02_011: Grammatical awareness enables precise literal comprehension (e.g., identifying who does what in passive constructions) and inference (e.g., why a term is used).  

## FORWARD_NODE_IDS
c11_hin_v_cbse_02_013, c11_hin_v_cbse_02_014, c11_hin_v_cbse_02_015, c12_hin_v_cbse_02_012

## FORWARD_REASONS
c11_hin_v_cbse_02_013: Critical thinking requires the evidence-location and synthesis skills honed here to analyze themes, irony, and authorial intent.
c11_hin_v_cbse_02_014: Writing skills (analytical paragraphs, essays) directly apply the PEEL structure practiced in inferential answer construction.
c11_hin_v_cbse_02_015: Literal and inferential comprehension ensures students can accurately reference text during speaking.  
c12_hin_v_cbse_02_012: Reinforces comprehension strategies across texts.  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
none

## CHAIN_DESCRIPTION
c11_hin_v_cbse_02_001 -> c11_hin_v_cbse_02_012 -> c11_hin_v_cbse_02_013

## THIS_FORMULA
PEEL Structure for Inferential Answers: Point (Direct answer to question) + Evidence 1 (Textual detail 1 with location) + Evidence 2 (Textual detail 2 with location) + Explanation (Logical connection between evidences and point) + Link (Connection to broader theme/author's purpose)

## FORMULA_VARIABLES
Point = Thesis statement answering the inferential question; Evidence 1 = First textual fact/quote supporting point; Evidence 2 = Second textual fact/quote from different paragraph supporting point; Explanation = Reasoning showing how evidences jointly prove point; Link = Sentence connecting point to chapter's central idea (labor exploitation, state policy, environmental fragility).

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
analytical

## CROSS_SUBJECT
c11_history_colonialism | The embankment labor system mirrors colonial-era indentured labor contracts (advance/debt bondage); understanding historical labor exploitation aids inference about systemic continuity.
c11_geography_flood_management | Knowledge of structural vs. non-structural flood control (embankments vs. floodplains) provides real-world context to evaluate the text's critique of state policy.

## PREREQ_CONCEPT
Ability to distinguish between explicitly stated information and implied meaning in a non-fiction Hindi prose text.

## PREREQ_BEFORE
Student must have read the full chapter "jktLFkku dh jtr cw¡nas" and understand the technical terms for soil types (ikyjikuh, ikrkyikuh, jstk.khikuh) and labor terms (o"kZ Hkj, psyokath, pstkjks).

## PREREQ_STUCK
If stuck, review the soil classification section (pages 12-13) and the advance-system description (pages 15-16) in the NCERT text; these contain the highest density of inferential question material.

## WORKED_EXAMPLE_1
PROBLEM: Answer the inferential question: "Why does the author describe the construction of embankments as a 'fo'ks"k dyk' (special art)?" using the PEEL structure with two textual evidences.
STEPS:
- Step 1: Identify question type – inferential (asks for reason behind author's phrase, not direct fact).
- Step 2: Locate the phrase "fo'ks"k dyk" in text (page 14) and note surrounding context: "oqaQbZ cukuk lpeqp ,d fo'ks"V dyk gS" followed by description of skills required.
- Step 3: Extract Evidence 1: Text lists specialized knowledge – "pstkjks oqQ'kyrk vkSj lkoèkkuh dh iwjh m¡QpkbZ ukirs gSa" (workers know art and have full skill knowledge).
- Step 4: Extract Evidence 2: Text details generational transmission – "bu {ks=kksa esa cM+s oqQ,¡ [kksnrs le; fe^h esa gks jgs ifjorZu ls [kfM+;k i^h dk irk py tkrk gS" (experience teaches them to read flood signs).
- Step 5: Synthesize Explanation: The "art" lies not in formal engineering but in embodied, intergenerational expertise reading terrain, soil, and river behavior – a knowledge system invisible to outsiders.
- Step 6: Formulate Link: This elevates laborers from mere "workers" to custodians of a fragile ecological craft, reinforcing the chapter's theme of marginalized expertise.
REASONING: The PEEL structure forces the student to move beyond "it's hard work" to a textually grounded analysis of why the author chooses the word "art" – connecting skill, intuition, and tradition.
ANSWER: Point: The author calls embankment building a "special art" because it demands embodied, generational expertise in reading river behavior and soil response, not just physical labor. Evidence 1: Workers possess "oqQ'kyrk vkSj lkoèkkuh dh iwjh m¡QpkbZ" (artistry and complete skill knowledge). Evidence 2: They learn to anticipate flood patterns ("[kfM+;k i^h dk irk py tkrk gS") through lived experience. Explanation: This knowledge is oral, situational, and acquired over lifetimes – qualities of a craft/art form. Link: By framing it as art, the author honors the laborers' invisible epistemology and critiques the state's treatment of them as unskilled.

## WORKED_EXAMPLE_2
PROBLEM: A literal question asks: "What are the three main reasons the text gives for embankments failing to hold water?" Provide the answer with exact textual references (paragraph/page).
STEPS:
- Step 1: Recognize question as literal – asks for explicitly listed reasons.
- Step 2: Scan text for failure causes; locate page 17: "oqaQbZ osQ eq¡g NksVk j[kus osQ rhu cM+s dkj.k gSa".
- Step 3: Extract Reason 1: "jsr esa tek ueh ls ikuh dh cw¡nsa cgqr /hjs&/hjs fjlrh gSa" (porous soil layers let water seep).
- Step 4: Extract Reason 2: "fnu Hkj esa ,d oqaQbZ eqf'dy ls bruk gh ikuh tek dj ikrh gS" (daily seepage exceeds capacity).
- Step 5: Extract Reason 3: "oaqQbZ osQ ry ij ikuh dh ek=kk bruh de gksrh gS" (water pressure on slope is too low to retain).
- Step 6: Format answer as numbered list with page citations.
REASONING: Literal questions require precise retrieval; the text explicitly numbers three reasons, so the answer must mirror that structure without adding interpretation.
ANSWER: 1. Highly permeable soil layers allow rapid seepage (page 17). 2. Daily seepage loss exceeds the embankment's retention capacity (page 17). 3. Insufficient water pressure on the embankment slope to counteract seepage (page 17).

## WORKED_EXAMPLE_3
PROBLEM: Combine literal and inferential skills: "The text states embankments are built annually (literal). Infer what this implies about the state's flood management policy, using two evidences from different sections of the chapter."
STEPS:
- Step 1: Confirm literal base: Page 14 – "gj fnu oqaQbZ [kksnus osQ lkFk&lkFk [khai1 uke dh ?kkl dk <sj tek dj fy;k tkrk gS" (every year embankment building starts with khai ritual).
- Step 2: Identify first inference evidence: Page 19 – "futh gksrs gq, Hkh lkoZtfud {ks=k esa cuh oqaQb;ksa ij xzke lekt dk vaoqQ'k yxk jgrk gS" (village society's pressure persists on existing embankments despite futility).
- Step 3: Identify second inference evidence: Page 19 – "cgqr ”k:jr iM+us ij gh lekt ubZ oqaQbZ osQ fy, viuh LohÑfr nsrk gS" (state accepts new embankments only after great insistence).
- Step 4: Synthesize inference: The state treats embankments as routine, low-cost palliatives rather than investing in permanent solutions; annual rebuilding sustains a contractor-laborer economy and avoids structural reform.
- Step 5: Draft PEEL answer: Point = Policy of recurring palliative over permanent solution. Evidence 1 = Annual ritualized rebuilding (page 14). Evidence 2 = State reluctance to fund alternatives until forced (page 19). Explanation = Cycle benefits contractors and maintains political status quo. Link = Reflects chapter's critique of developmental neglect.
REASONING: This example bridges literal fact (annual cycle) to systemic inference (policy choice) using spatially separated evidences, modeling the multi-location synthesis required in board exams.
ANSWER: The annual rebuilding ritual reveals a state policy of palliative maintenance over permanent flood management. Evidence 1: Construction restarts yearly with the "khai" ritual (page 14), institutionalizing recurrence. Evidence 2: The state sanctions new embankments only under intense local pressure ("cgqr ”k:jr iM+us ij", page 19), showing reluctance to innovate. Explanation: This cycle sustains a contractor-laborer dependency and avoids costly watershed management. Link: The text thus exposes how "development" becomes a ritualized expenditure rather than ecological solution.

## COMPETENCY_QUESTION_1
QUESTION: "The author writes: 'oqaQbZ ,d vkSj vFkZ esa oqQ,¡ ls fcyoqQy vyx gS' (An embankment is fundamentally different from a dam in one sense). Based on the text, explain this difference and infer why the author emphasizes it."
COMPETENCY: Textual Analysis and Inference
STEPS:
- Step 1: Locate the sentence (page 10) and its context: comparison of dam vs. embankment function.
- Step 2: Identify literal difference: Dams hold water from upstream; embankments exclude water from adjacent land ("oqQvk¡ Hkwty dks ikus osQ fy, curk gS ij oqaQbZ Hkwty ls Bhd oSls ugha tqM+rh").
- Step 3: Infer author's purpose: Emphasizing this distinction exposes the futility of applying dam-engineering logic to embankments – they face lateral pressure, not vertical storage.
- Step 4: Connect to theme: This technical distinction underpins the laborers' impossible task – they build structures that physics dictates will fail.
ANSWER: The literal difference: dams impound upstream water; embankments repel lateral floodwater. The author emphasizes this to show that embankments fight hydrostatic pressure they cannot structurally withstand ("oqaQbZ o"kkZ osQ ty dks cM+s fofp=k <ax ls lesVrh gS"). Inference: This mismatch explains why embankments require constant repair and why laborers' "art" is a Sisyphean response to flawed state engineering. The distinction frames the chapter's central tragedy: a technological solution misapplied to a dynamic river system.
DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: "Analyze how the description of the three soil types (ikyjikuh, ikrkyikuh, jstk.khikuh) functions both as technical exposition and as a metaphor for the laborers' social stratification. Support with three textual evidences."
COMPETENCY: Critical Interpretation and Synthesis
STEPS:
- Step 1: Retrieve literal soil properties: ikyjikuh = sandy, permeable, unstable (page 12); ikrkyikuh = clayey, impermeable but cracks (page 12); jstk.khikuh = balanced, stable, "ve`r tSlk ehBk ikuh" (page 13).
- Step 2: Map to social stratification: Laborers are categorized by skill/descent like soils by composition – "vyx&vyx txgksa ij [kfM+;k i^h osQ Hkh vyx&vyx uke gSa" (page 19).
- Step 3: Evidence 1: "jstk.khikuh [kfM+;k i^h osQ dkj.k ikrkyhikuh ls vyx cuk jgrk gS" (page 13) – best soil resists flood pressure like skilled laborers resist exploitation.
- Step 4: Evidence 2: "ikyjikuh vkSj ikrkyikuh osQ chp ikuh dk rhljk :i gS jstk.khikuh" (page 13) – hybrid resilience mirrors laborers' adaptive knowledge.
- Step 5: Evidence 3: "bl fof'k"V jstk.khikuh dks lesV ldus okyh oqaQbZ cukuk lpeqp ,d fo'ks"V dyk gS" (page 14) – only "artistic" labor can utilize the best soil, just as only experienced workers navigate the system.
- Step 6: Synthesize: Soil taxonomy mirrors labor hierarchy; both are naturalized by the state to justify differential treatment.
ANSWER: The soil classification operates dually. Literally, it explains engineering failure/success. Metaphorically, it maps onto labor stratification: ikyjikuh (migrant, unstable) = new/forced laborers; ikrkyikuh (rigid, cracking) = traditional but inflexible castes; jstk.khikuh (adaptive, resilient) = hereditary skilled workers ("pstkjks osQ cnys lkekU; x`gLFk", page 16). Evidence 1: jstk.khikuh forms where flood pressure meets resistance – like laborers' expertise forged under systemic pressure. Evidence 2: The "art" of embankment building applies only to jstk.khikuh – only the most skilled labor accesses the best material. Evidence 3: State recognition ("LohÑfr") comes only after "cgqr ”k:jr iM+us" – like soil that proves itself under flood. The author thus naturalizes labor hierarchy through soil science, critiquing how both are essential yet exploited.
DIFFICULTY: hard