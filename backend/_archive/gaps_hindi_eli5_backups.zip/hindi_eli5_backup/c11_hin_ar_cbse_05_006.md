## DEFINITION
The primary theme of a literary work is its central, unifying idea or universal truth about human experience that the author explores through plot, characters, and conflict; the message is the author's specific stance or moral insight on that theme, conveyed implicitly through the narrative's resolution and character arcs.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student can identify the primary theme of "जूही की कली" with textual evidence, explain how the author develops this theme through at least three narrative elements (plot, character, setting, dialogue), and articulate the story's message about caste-based discrimination and human dignity in a structured analytical paragraph.

## SCOPE_BOUNDARY
This node covers identifying and analyzing the PRIMARY theme (caste discrimination and the struggle for dignity/education) and the author's message in "जूही की कली." It does NOT cover secondary themes (gender roles, rural-urban divide, generational conflict) which are addressed in node c11_hin_ar_cbse_05_007.

## WALKTHROUGH
Imagine you're watching a news report about a talented student from a marginalized community who tops the board exams but still faces discrimination when renting a flat in a city — this real-world scenario mirrors the core conflict in "जूही की कली." To find the primary theme, start by asking: "What is the ONE big injustice the story revolves around?" Trace how Eksgu's every interaction — with Thakur Phalgun Singh, Thakurain, the schoolmaster, even his own father — is shaped by his caste identity. Notice how the narrative spans years, showing that education alone doesn't erase social prejudice. The key insight: the theme isn't just "caste is bad" but "caste operates as an invisible cage that persists even when the prisoner achieves merit."

## DIAGNOSTIC_QUESTION_1
What is the primary theme of "जूही की कली" as revealed through the protagonist Eksgu's life trajectory from childhood to adulthood?

## DIAGNOSTIC_ANSWER_1
The primary theme is the systemic caste-based discrimination that denies human dignity and equal opportunity to marginalized communities, persisting even when individuals achieve educational and professional success. A wrong answer (e.g., "the importance of hard work" or "father-son conflict") reveals the student is focusing on surface-level plot events rather than the structural oppression that shapes every character's choices and the story's outcome.

## DIAGNOSTIC_QUESTION_2
Explain in your own words why Thakurain's sympathetic behavior toward Eksgu (giving him food, defending him to her husband) does NOT contradict the story's primary theme of caste oppression.

## DIAGNOSTIC_ANSWER_2
Thakurain's kindness operates within caste boundaries — she treats Eksgu with paternalistic charity, not equality; she never challenges the system that keeps him a servant, and her "sympathy" reinforces his dependence. A wrong answer (e.g., "she is a good person so caste doesn't matter") reveals the student confuses individual kindness with structural change, missing how the story uses her character to show that benevolence without justice sustains oppression.

## DIAGNOSTIC_QUESTION_3
Apply the concept of "primary theme" to analyze this scene: When Eksgu returns as an educated BA, LLB graduate, Thakur Phalgun Singh still addresses him by his first name without honorifics, while Eksgu must use "Thakur Saheb." What does this interaction reveal about the story's message?

## DIAGNOSTIC_ANSWER_3
This scene proves the message: educational achievement cannot dismantle caste hierarchy because social power operates through ritualized humiliation, not merit. The honorific asymmetry shows caste is a performance of dominance. A wrong answer (e.g., "Thakur is old-fashioned" or "Eksgu should demand respect") reveals the student treats this as interpersonal conflict rather than systemic enactment of the theme.

## DIAGNOSTIC_QUESTION_4
Compare how the primary theme is developed through TWO different narrative elements: (a) the physical setting of the haveli vs. the school, and (b) the recurring motif of "नौकरी" (service/job) vs. "पढ़ाई" (education). How do these contrasts deepen the theme?

## DIAGNOSTIC_ANSWER_4
The haveli represents feudal entrapment (Eksgu sleeps on the floor, serves meals, is summoned by bell) while the school represents a forbidden space of equality (he sits on a mat like others, learns the same lessons) — the spatial contrast makes caste visible as geographic exclusion. The नौकरी/पढ़ाई motif shows the structural trap: his labor is exploited to sustain the very system that denies him education. A weak answer treats these as separate observations without showing how they jointly construct the theme of "caste as a closed system."

## DIAGNOSTIC_QUESTION_5
Evaluate this claim: "The story's ending — where Eksgu becomes a successful lawyer but the narrative closes with him still reflecting on his past servitude — suggests the author's message is pessimistic: caste oppression cannot be overcome." Defend or critique using textual evidence.

## DIAGNOSTIC_ANSWER_5
The message is not pessimistic but realist: the ending shows caste's psychological interiority — even external success doesn't erase internalized subordination. The author's message is that liberation requires collective structural change, not individual escape. A wrong evaluation (e.g., "it's a happy ending because he got a job") reveals the student reads for plot resolution rather than thematic resonance, missing how the final paragraphs frame Eksgu's memory as an open wound, not a closed chapter.

## DIAGNOSTIC_QUESTION_6
Create a 4-line dialogue between Eksgu and a young Dalit student today that captures the story's primary theme and message in a contemporary context. The dialogue must show both continuity and change.

## DIAGNOSTIC_ANSWER_6
A strong answer might be:
Student: "Sir, I topped the entrance exam but the landlord refused my application."
Eksgu: "They still read the name before the marksheet."
Student: "But we have laws now, reservations, courts."
Eksgu: "Laws change papers. We change minds by refusing to serve their tea."
This works because it transposes the theme (caste precedes merit) and message (collective refusal over individual achievement) into present tense. A poor answer makes Eksgu give generic advice ("study hard") showing the student hasn't internalized the story's structural critique.

## COMMON_MISCONCEPTION
Students often confuse "theme" with "topic" or "plot summary" — they write "the story is about a lower-caste boy who becomes a lawyer" (plot) or "the theme is caste system" (topic). The specific error: they treat theme as a noun phrase rather than a complete idea with a perspective. For example, they say "Theme = Caste Discrimination" instead of "Theme = Caste discrimination operates as a self-perpetuating system that denies dignity even to the meritorious." This happens because school-level teaching often asks "What is the theme?" expecting a one-word answer, not a thematic statement.

## ON_FAILURE
If a student gives a topic/plot instead of a theme: Step 1 — Ask "What is the story SAYING about caste discrimination?" not "What is it about?" Step 2 — Use the formula: "The story shows that [topic] + [verb phrase showing author's insight]." Step 3 — Have them complete: "The story shows that caste discrimination ______." Step 4 — Test their statement: "Can you find THREE moments in the text that prove this specific claim?" If they can't, the theme statement is too vague.

## BUILDS_ON
c11_hin_ar_cbse_05_002 (Plot and Narrative Structure) — understanding the chronological arc from childhood servitude to adult professional life is essential to see how the theme persists across time.

## LEADS_TO
c11_hin_ar_cbse_05_007 (Theme: Secondary Themes) — once the primary theme is established, students can identify how gender, education, and rural modernity intersect with it.

## PREREQUISITE_NODE_IDS
c11_hin_ar_cbse_05_001, c11_hin_ar_cbse_05_002, c11_hin_ar_cbse_05_004, c11_hin_ar_cbse_05_005, c11_hin_ar_cbse_05_003

## PREREQUISITE_REASONS
c11_hin_ar_cbse_05_001: Context on Shivpujan Sahay's reformist background and the "Nayi Kahani" movement explains why he centers caste oppression as primary theme.
c11_hin_ar_cbse_05_002: The plot's time-span (childhood to adulthood) and circular structure (return to haveli) are structural evidence for the theme's persistence.
c11_hin_ar_cbse_05_004: Eksgu's characterization — his silence, observance, internal conflict — embodies the theme psychologically.
c11_hin_ar_cbse_05_005: Thakur Phalgun Singh and Thakurain represent the oppressor class's dual face (brutality and benevolence), both serving the theme.
c11_hin_ar_cbse_05_003: The primary theme of caste oppression is materialized through spatial segregation and atmospheric coding  

## FORWARD_NODE_IDS
c11_hin_ar_cbse_05_007, c11_hin_ar_cbse_05_008, c11_hin_ar_cbse_05_009, c11_hin_ar_cbse_05_013, c11_hin_ar_cbse_05_014, c11_hin_ar_cbse_05_015, c12_hin_a_cbse_05_006, c12_hin_ar_cbse_05_001, c12_hin_ar_cbse_05_006, c12_hin_ar_cbse_12_006

## FORWARD_REASONS
c11_hin_ar_cbse_05_007: Secondary themes (gender, education, tradition-modernity) branch off the primary theme's trunk.
c11_hin_ar_cbse_05_008: Imagery (haveli darkness vs. school light, जूही की कली as fragile beauty in hostile soil) metaphorically extends the primary theme.
c11_hin_ar_cbse_05_009: Irony (educated lawyer still called by first name) and symbolism (the bell, the mat, the degree) are devices that sharpen the theme.
c11_hin_ar_cbse_05_013: Critical analysis requires a firm thematic anchor to evaluate interpretations.
c11_hin_ar_cbse_05_014: Gives primary theme (caste oppression) for the Link step in PEEL.  
c11_hin_ar_cbse_05_015: Primary theme (caste oppression/dignity) is the umbrella for all discussion points.  
c12_hin_a_cbse_05_006: Class 11 Antra Theme node — students already practiced theme identification; this node deepens to *message articulation* and *board-style justification*.  
c12_hin_ar_cbse_05_001: Covers 'Theme: Primary Theme and Message' in Class 11 Chapter 5, helping students identify how background informs theme.  
c12_hin_ar_cbse_05_006: Class 11 foundation on 'topic vs theme' and 'theme statement formulation' is the direct pedagogical prerequisite.  
c12_hin_ar_cbse_12_006: Exposure to theme in poetry vs. prose.  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
none

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_05_002 -> c11_hin_ar_cbse_05_006 -> c11_hin_ar_cbse_05_007

## THIS_FORMULA
Theme Statement = Topic (Caste Discrimination) + Author's Insight (verb phrase showing how it operates/impacts) + Universal Human Implication

## FORMULA_VARIABLES
Topic: The subject the story explores (e.g., caste discrimination). Author's Insight: The specific claim the narrative makes about the topic (e.g., "persists despite individual merit"). Universal Human Implication: What this reveals about power/dignity/society (e.g., "social hierarchy is maintained through ritualized humiliation, not ability").

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
analytical

## CROSS_SUBJECT
c11_sociology_social_stratification | The story illustrates how caste functions as a closed stratification system where ascribed status (birth) overrides achieved status (education), a core concept in sociology of Indian society.
c11_history_nationalist_movement | Shivpujan Sahay's writing reflects the 1930s-40s debate on social reform vs. political independence — the story critiques how nationalist discourse often ignored caste, paralleling Ambedkar's critique.

## PREREQ_CONCEPT
Understanding the difference between "topic" (a noun phrase) and "theme" (a complete propositional statement about the topic) is essential before analyzing primary theme.

## PREREQ_BEFORE
Student must be able to summarize the plot chronologically and identify the protagonist's key conflicts with at least three characters.

## PREREQ_STUCK
If stuck, review "Plot and Narrative Structure" (c11_hin_ar_cbse_05_002) focusing on the time-jumps and the final return scene — these structural choices ARE the theme made visible.

## WORKED_EXAMPLE_1
PROBLEM: A student writes: "The theme of जूही की कली is caste system." Help them convert this into a board-exam standard thematic statement using the formula.

STEPS:
- Step 1: Identify the topic noun phrase — "caste system" or "caste-based discrimination."
- Step 2: Ask what the story SHOWS about this topic — trace three key moments: (a) Child Eksgu barred from school despite Thakurain's wish, (b) Adult Eksgu with degrees still denied honorifics, (c) Thakurain's charity never challenges the structure.
- Step 3: Synthesize the verb phrase — "operates as a self-reproducing hierarchy that nullifies individual achievement."
- Step 4: Add universal implication — "revealing that social dignity cannot be earned through merit alone in a caste-ordered society."
- Step 5: Assemble full statement: "The primary theme is that caste-based discrimination operates as a self-reproducing hierarchy that nullifies individual achievement, revealing that social dignity cannot be earned through merit alone in a caste-ordered society."
REASONING: This 5-step process moves from topic to insight to universal claim, matching how board examiners evaluate thematic answers — they look for a complete idea with textual grounding, not a label.
ANSWER: Final thematic statement as above. The student now has a defensible, evidence-ready theme they can use in any analytical question.

## WORKED_EXAMPLE_2
PROBLEM: Analyze how the "school vs. haveli" spatial contrast develops the primary theme. Write a structured analytical paragraph (PEEL format).

STEPS:
- Step 1: Point — The spatial opposition between school and haveli materializes the theme of caste as geographic and psychological exclusion.
- Step 2: Evidence 1 — In the haveli, Eksgu sleeps on the floor, answers bells, serves meals; his body is positioned as service. In the school (briefly accessed), he sits on a mat, holds a slate, is addressed by name — his body is positioned as learner.
- Step 3: Evidence 2 — The schoolmaster's willingness to teach him is overruled by Thakur's authority, showing the haveli's power extends into the school space.
- Step 4: Explanation — The contrast proves caste is not just "attitude" but spatial control: who occupies which space, on what terms. The haveli absorbs the school's potential equality.
- Step 5: Link — This spatial reading supports the theme that caste is a total system enclosing the marginalized even in institutions meant to liberate.
REASONING: PEEL forces thematic analysis to be evidence-driven. Each "Evidence" step must cite a specific textual moment; "Explanation" connects it to the theme statement from Worked Example 1.
ANSWER: The spatial opposition between school and haveli materializes the theme of caste as geographic and psychological exclusion. In the haveli, Eksgu sleeps on the floor, answers bells, serves meals — his body is positioned as service. In the school, he briefly sits on a mat, holds a slate, is addressed by name — his body is positioned as learner. The schoolmaster's willingness to teach him is overruled by Thakur's authority, showing the haveli's power extends into the school space. This contrast proves caste is not just "attitude" but spatial control: who occupies which space, on what terms. The haveli absorbs the school's potential equality. This spatial reading supports the theme that caste is a total system enclosing the marginalized even in institutions meant to liberate.

## WORKED_EXAMPLE_3
PROBLEM: The board asks: "Shivpujan Sahay's story shows that 'education is not enough' to overcome caste oppression. Discuss with reference to the narrative arc." Write a 150-word answer integrating plot, character, and theme.

STEPS:
- Step 1: Deconstruct the prompt — it demands a thesis-driven argument using narrative arc (beginning-middle-end) as evidence for the theme.
- Step 2: Thesis — The narrative arc from denied schooling to professional degree to continued subordination proves education alone cannot dismantle caste because caste operates through social ritual, not economic or educational capital.
- Step 3: Beginning evidence — Child Eksgu's desire to study is crushed by Thakur's refusal; his labor funds the haveli but he cannot enter the classroom.
- Step 4: Middle evidence — Thakurain's charity (food, old clothes) substitutes for justice; Eksgu's father accepts servitude as destiny, showing internalized oppression.
- Step 5: End evidence — Adult Eksgu (BA, LLB) returns; Thakur still calls him "Eksgu" while demanding "Thakur Saheb"; the degree is invisible to caste eyes.
- Step 6: Synthesis — The arc is circular, not linear: the ending mirrors the beginning, confirming the theme that caste is a closed loop.
REASONING: This 6-step structure mirrors the "competency question" pattern in CBSE Class 12 papers — thesis, chronological evidence, thematic synthesis. It combines plot knowledge (c11_hin_ar_cbse_05_002), character insight (c11_hin_ar_cbse_05_004/005), and theme analysis (this node).
ANSWER: Shivpujan Sahay's narrative arc — from Eksgu's denied childhood schooling to his adult professional degrees to his continued subordination — demonstrates that education alone cannot dismantle caste oppression because caste operates through social ritual, not merit. As a child, Eksgu's desire to study is crushed by Thakur Phalgun Singh's refusal; his labor sustains the haveli but he cannot enter the classroom. Thakurain's charity (food, clothes) substitutes for justice, while his father accepts servitude as destiny, showing internalized oppression. Decades later, Eksgu returns as a BA, LLB graduate, yet Thakur still addresses him by first name without honorifics while demanding "Thakur Saheb" in return. The degree remains invisible to caste eyes. The arc is circular, not linear: the ending mirrors the beginning, confirming the primary theme that caste is a self-reproducing hierarchy that nullifies individual achievement. Liberation requires structural rupture, not individual escape.

## COMPETENCY_QUESTION_1
QUESTION: A Class 11 student writes this thematic statement for "जूही की कली": "The story teaches us that we should not discriminate based on caste and everyone deserves education." Identify TWO specific weaknesses in this statement from a board-exam perspective, and rewrite it to meet senior secondary analytical standards.

COMPETENCY: Critical evaluation of thematic statements / Metacognitive awareness of exam expectations

STEPS:
- Step 1: Identify weakness 1 — The statement is prescriptive ("teaches us that we should not") rather than descriptive-analytical ("shows how caste operates"). Board exams ask what the TEXT does, not what moral lesson the reader should learn.
- Step 2: Identify weakness 2 — It reduces a complex systemic critique to a simple moral platitude, ignoring the story's central insight that education FAILS to overcome caste (Eksgu gets educated but remains subordinated).
- Step 3: Apply the Theme Formula — Topic: Caste discrimination's persistence despite merit. Author's Insight: It operates through ritualized power that renders achievement invisible. Universal Implication: Dignity requires collective structural change, not individual mobility.
- Step 4: Rewrite — "The primary theme is that caste discrimination functions as a self-reproducing system of ritualized subordination that persists even when the marginalized achieve educational and professional distinction, revealing that individual merit cannot secure dignity within an unchanged hierarchical order."
ANSWER: Weakness 1: Prescriptive/moralistic language ("teaches us," "should not") instead of analytical description of textual operation. Weakness 2: Contradicts the story's own evidence — Eksgu GETS education but caste oppression continues. Rewritten statement meets board standards: analytical, evidence-aligned, propositionally complete.
DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: The story ends with Eksgu reflecting: "एकसगु को अपनी दीनता का बोध न था... वह अपनी हीनता के अहसास से मुक्त न हो सका" (Eksgu had no awareness of his wretchedness... he could not free himself from the sense of inferiority). Using this closing insight, explain how the story's PRIMARY THEME shifts from "external oppression" to "internalized oppression" — and why this shift is the author's deepest message.

COMPETENCY: Thematic evolution analysis / Psychological dimension of social critique

STEPS:
- Step 1: Define the shift — Early theme: Caste oppresses FROM OUTSIDE (laws, customs, Thakur's power). Late theme: Caste oppresses FROM INSIDE (internalized inferiority, unconscious servility).
- Step 2: Trace textual evidence for external phase — Child Eksgu: barred from school, beaten, fed leftovers, summoned by bell. The oppression is visible, enacted by others.
- Step 3: Trace textual evidence for internal phase — Adult Eksgu: despite degrees, he waits for Thakur's permission to sit, anticipates commands, feels "हीनता" (inferiority) without external trigger. The oppression has become self-policing.
- Step 4: Explain author's message — Shivpujan Sahay shows caste's true victory: it colonizes the mind. The deepest horror isn't the haveli's cruelty but that Eksgu carries the haveli inside him even after escaping it.
- Step 5: Connect to "जूही की कली" metaphor — The jasmine bud (जूही की कली) blooms in hostile soil but its fragrance is claimed by the gardener; similarly, Eksgu's merit blooms but his dignity is still owned by the caste order.
ANSWER: The theme evolves from external oppression (caste as laws/customs enforced by Thakur) to internalized oppression (caste as self-policing inferiority). Evidence: Child Eksgu faces visible barriers (denied school, beaten, fed leftovers). Adult Eksgu, despite BA/LLB, unconsciously waits for permission to sit, anticipates commands, feels "हीनता" without external trigger. The author's deepest message: caste's true victory is colonizing the mind — Eksgu carries the haveli inside him after escaping it. The "जूही की कली" metaphor completes this: the bud blooms in hostile soil but its fragrance is claimed by the gardener; Eksgu's merit blooms but his dignity remains owned by the caste order.
DIFFICULTY: hard