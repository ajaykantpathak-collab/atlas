## DEFINITION
Grammar: Language Usage in the Text refers to the study of how words, phrases, and grammatical structures function within the specific context of the chapter "Hkkjr ekrk" to convey meaning, tone, and thematic depth. It includes analyzing vocabulary in context, deriving abstract noun forms (fo'ks"k.k :i) from concrete nouns, and understanding how grammatical choices reflect the author's style and intent.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student must be able to (1) explain the contextual meaning of at least five key words from the text with textual evidence, and (2) correctly derive and use the characteristic abstract noun forms (fo'ks"k.k :i) of given nouns in new sentences, justifying the morphological transformation.

## SCOPE_BOUNDARY
This node covers vocabulary in context (meanings of specific words as used in the chapter) and noun morphology (deriving fo'ks"k.k :i forms). It does not cover broader grammar topics like verb conjugation, sentence synthesis, or literary devices (covered in sibling nodes).

## WALKTHROUGH
When you read a powerful speech like Nehru's 'Bharat Mata', have you noticed how certain words carry more weight than their dictionary definitions? Start by picking a sentence from the text (e.g., "Hkkjr ekrk vdlj tc eSa ,d tyls ls nwljs tyls esa tkrk gksrk...") and identify words that seem charged with emotion. Look at the surrounding sentences to infer meaning (context clues). Next, take a concrete noun like 'ped' (tree) and derive its abstract quality 'pedpan' or 'pedtva' (treeness), explaining the suffix patterns. Connect this to the text's nouns like 'fganqLrku' (unity) which is already abstract, and contrast with 'ped' (concrete). The key insight: grammatical forms are not just rules but tools the author uses to build the theme of unity in diversity.

## DIAGNOSTIC_QUESTION_1
What is the meaning of 'fo'ks"k.k :i' in Hindi grammar, and give one example from the textbook exercise list (vk”kknh, ped, fganqLrku, fons'k, ljdkj, ;k=kk, iqjk.k, Hkkjr) with its derived form.

## DIAGNOSTIC_ANSWER_1
fo'ks"k.k :i is the characteristic abstract noun form derived from a concrete or base noun, typically formed by adding suffixes like -ta, -pan, -ai, -av to denote the quality or state. For example, from 'ped' (tree) we get 'pedpan' (treeness) or 'pedtva'. A wrong answer (e.g., giving the plural form or synonym) reveals the student confuses fo'ks"k.k :i with vचन or paryayvachi, indicating a lack of understanding of morphological derivation.

## DIAGNOSTIC_QUESTION_2
In the sentence "eSa mÙkj&ifPNe esa [kScj osQ njsZ ls ysdj èkqj nfD[ku esa dU;koqQekjh rd dh viuh ;k=kk dk gky crkrk", the word 'nfD[ku' is used. Explain why the author chooses 'nfD[ku' (valley) instead of a more common word like 'uhps' (down) or 'xq.nk' (low), considering the thematic context of the chapter.

## DIAGNOSTIC_ANSWER_2
The author uses 'nfD[ku' to evoke a geographical and metaphorical depth, symbolizing the low points in India's struggle and the vast expanse of the land, aligning with the theme of unity across diverse terrains. A student who only gives the dictionary meaning ("valley") misses the connotative layer, showing they treat vocabulary as isolated words rather than thematic choices.

## DIAGNOSTIC_QUESTION_3
Given the noun 'iqjk.k' (tradition) from the exercise list, derive its fo'ks"k.k :i and use it in a sentence that reflects the chapter's idea of living traditions. Show the morphological steps.

## DIAGNOSTIC_ANSWER_3
Step 1: Identify base noun 'iqjk.k' (tradition). Step 2: Recognize it ends in a consonant, so common abstract suffixes are -ta or -pan. Step 3: Derive 'iqjk.kta' (traditionality) or 'iqjk.kpan' (state of being traditional). Step 4: Form sentence: 'Hkkjr dh iqjk.kta osQ vk/kkj ij fganqLrku tkrh gS' (India's unity rests on its traditionality). A wrong derivation like 'iqjk.kta' misspelled or using 'iqjk.k' as is shows the student cannot apply morphological rules to new nouns.

## DIAGNOSTIC_QUESTION_4
Compare the fo'ks"k.k :i of 'vk”kknh' (freedom) and 'fons'k' (government). Both are abstract nouns already. How does the textbook exercise expect you to treat them? Analyze the grammatical nature of the list: why are some words concrete (ped, Hkkjr) and others abstract (vk”kknh, fganqLrku) mixed together?

## DIAGNOSTIC_ANSWER_4
The exercise tests the student's ability to recognize that fo'ks"k.k :i for already abstract nouns is often the same word or a further derived quality (e.g., vk”kknh -> vk”kknhpan? but usually the form remains). The mix of concrete and abstract nouns checks if the student can distinguish between primary abstraction (ped -> pedpan) and secondary abstraction (vk”kknh -> vk”kknh). A student who gives the same word for all shows they don't analyze the noun's existing abstractness.

## DIAGNOSTIC_QUESTION_5
The word '<Is' (chest/heart) appears in the phrase "ml <Is osQ lkFk" (with that chest/heart). Critique the translation of '<Is' as 'chest' versus 'heart' in the context of "Hkkjr ekrk njvly ;gh djksM+ksa yksx gSa] vkSj ¶Hkkjr ekrk dh t;!¸ ls eryc gqvk bu yksxksa dh t; dkA". Which translation better serves the author's rhetorical purpose? Justify.

## DIAGNOSTIC_ANSWER_5
'Heart' is better because the passage speaks of emotional identification ("t; dk eryc") and the metaphorical heart of the motherland, not the physical chest. Choosing 'chest' indicates a literalist reading that fails to evaluate connotation in rhetorical context.

## DIAGNOSTIC_QUESTION_6
Write a short paragraph (4-5 lines) continuing the author's journey metaphor ("eSa viuh ckrphr esa phu] Lisu] vchflfu;k...") using at least three words from the 'kCn&Nfo' list (l;kus, fx”kk, u”kfj;k, egnwn, elyk, ;d&lk¡, <Is, rCnhfy;ksa, tq”k, d'ked'k, gokys, oqQrwgy, rkTtqc, g^s&d^s, v”kh”k, njvly, tylk, èkkok) and two derived fo'ks"k.k :i forms from the noun list. Ensure the grammatical forms fit naturally.

## DIAGNOSTIC_ANSWER_6
A good answer will integrate words like 'elyk' (lap), 'tq”k' (part), 'd'ked'k' (suffering) and derived forms like 'pedpan' (from ped) and 'fganqLrkuta' (from fganqLrku) in a coherent narrative that mirrors the text's tone. A poor answer will force words without syntactic fit or misuse the derived forms (e.g., using 'pedpan' as a verb), revealing weak morphological control.

## COMMON_MISCONCEPTION
Students often think 'fo'ks"k.k :i' means simply writing the plural (vचन) or a synonym (parayvachi) of the noun. They confuse the term 'fo'ks"k.k' (characteristic) with 'fo'ks"k' (special) and assume it asks for a 'special form' like honorific or plural. This happens because in earlier classes they practiced 'vचन badlo' and 'parayvachi' more than abstract noun derivation. For example, for 'ped' they write 'ped' (plural) or 'vrks' (synonym) instead of 'pedpan/pedtva'.

## ON_FAILURE
1. Re-teach the definition of fo'ks"k.k :i using a simple concrete noun like 'lq[k' (boy) -> 'lq[kpan' (boyhood) or 'lq[kta' (boyishness). 2. Show the suffix chart: -pan, -ta, -ai, -av, -hat. 3. Have the student practice with 5 concrete nouns from daily life (ghar -> gharpan, pani -> paniyat). 4. Then return to the textbook list and classify each noun as concrete or abstract before deriving. 5. Emphasize that for already abstract nouns (vk”kknh), the fo'ks"k.k :i may be the same or a further derived form (vk”kknhpan), but the exercise likely expects recognition of the base quality.

## BUILDS_ON
Vocabulary in Context: Key Words (c11_hin_ar_cbse_08_010) where students learned the meanings of key terms.

## LEADS_TO
Comprehension: Literal and Inferential Questions (c11_hin_ar_cbse_08_012) where language usage aids deeper comprehension.

## PREREQUISITE_NODE_IDS
c11_hin_ar_cbse_08_010, c11_hin_ar_cbse_08_009

## PREREQUISITE_REASONS
c11_hin_ar_cbse_08_010: Students need the vocabulary meanings from the previous node to understand the words before analyzing their grammatical forms and contextual usage.
c11_hin_ar_cbse_08_009: Grammar usage (passive voice in "ykn j[kk Fkk") reinforces the irony of colonial agency.  

## FORWARD_NODE_IDS
c11_hin_ar_cbse_08_012, c11_hin_ar_cbse_08_014, c12_hin_a_cbse_04_011, c12_hin_a_cbse_09_011, c12_hin_a_cbse_11_011, c12_hin_a_cbse_12_011, c12_hin_a_cbse_17_011, c12_hin_ar_cbse_01_011, c12_hin_ar_cbse_02_011, c12_hin_ar_cbse_07_011, c12_hin_ar_cbse_08_011, c12_hin_ar_cbse_09_011, c12_hin_ar_cbse_10_011, c12_hin_ar_cbse_11_011

## FORWARD_REASONS
c11_hin_ar_cbse_08_012: Understanding language usage (vocabulary in context and noun forms) is essential for answering literal and inferential comprehension questions that test nuanced meaning.
c11_hin_ar_cbse_08_014: Grammar/usage knowledge ensures syntactically correct Hindi answers.  
c12_hin_a_cbse_04_011: अगला तार्किक चरण: This node analyzes the grammatical structures, syntactic patterns, and language usage specific to th... इस नोड की अवधारणाओं को सीधे उपयोग/विस्तारित करता है।  
c12_hin_a_cbse_09_011: Covered *vakya rachna* (sentence structure) — Braj SOV with postpositions mirrors but differs in case markers.  
c12_hin_a_cbse_11_011: Explains absolutive/perfective participle usage in narrative sequencing — used in all three stories.  
c12_hin_a_cbse_12_011: Practice with PEEL paragraph structure for language analysis  
c12_hin_a_cbse_17_011: Identified grammatical parallelism as rhetorical device — directly used in Q3/Q6.  
c12_hin_ar_cbse_01_011: Practice with rhetorical questions and inverted syntax.  
c12_hin_ar_cbse_02_011: Application to longer poems.  
c12_hin_ar_cbse_07_011: Alankar recognition aids syntax analysis.  
c12_hin_ar_cbse_08_011: Class 11 grammar node for same chapter provides foundation in grammatical analysis.  
c12_hin_ar_cbse_09_011: Refines skill in detecting syntactic inversion for emphasis.  
c12_hin_ar_cbse_10_011: Register variation in dialogue (Chapter 8).  
c12_hin_ar_cbse_11_011: Deepens compound verb aspect analysis  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
none

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_08_010 -> c11_hin_ar_cbse_08_011 -> c11_hin_ar_cbse_08_012

## THIS_FORMULA
fo'ks"k.k :i derivation pattern: For concrete nouns ending in consonant: add -pan, -ta, -ai, -av, -hat (e.g., ped -> pedpan). For nouns ending in vowel: add -pan, -ta (e.g., lq[k -> lq[kpan). For abstract nouns: often the same word or further derivation with -pan/-ta.

## FORMULA_VARIABLES
N/A - conceptual

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
linguistic

## CROSS_SUBJECT
c11_history_indian_nationalism | The chapter "Hkkjr ekrk" is a historical speech by Nehru; understanding language usage helps analyze rhetorical strategies in historical texts.
c11_civics_constitutional_values | The themes of unity, diversity, and freedom in the text connect to constitutional values; grammatical analysis reveals how language frames civic ideals.

## PREREQ_CONCEPT
Knowledge of basic Hindi noun classification (concrete vs abstract) and common abstract noun suffixes (-pan, -ta, -ai, -av, -hat).

## PREREQ_BEFORE
Student must be able to identify nouns in a sentence and distinguish between concrete (physical) and abstract (quality/state) nouns.

## PREREQ_STUCK
Review Class 9-10 Hindi grammar on 'laKk' (noun) types and 'fo'ks"k.k :i' derivation rules from the grammar textbook (Vyakaran).

## WORKED_EXAMPLE_1
PROBLEM: Analyze the contextual meaning and grammatical form of the word 'rCnhfy;ksa' (upheavals/events) in the sentence: "eSa mUgsa lksfo;r ;wfu;u esa gksus okyh vpjt&Hkjh rCnhfy;ksa dk gky Hkh crkrk vkSj dgrk fd vejhdk us oSQlh rjDdh dh gSA" and derive its fo'ks"k.k :i if applicable.
STEPS:
- Step 1: Locate the word in the text and read the surrounding clause: "vpjt&Hkjh rCnhfy;ksa" (heart-shaking upheavals). Note it is plural, used as a noun.
- Step 2: Determine the base singular form: 'rCnhfy;k' (upheaval/event). Check if it is concrete or abstract: abstract (denotes an event).
- Step 3: For fo'ks"k.k :i, since it is already abstract, the characteristic form may be 'rCnhfy;kpan' (state of being eventful) or simply 'rCnhfy;k'. But the exercise list does not include this word; we practice derivation anyway.
- Step 4: Contextual meaning: Here it refers to the traumatic events of partition and economic crisis (vpjt&Hkjh = heart-rending). The author uses it to convey emotional intensity.
- Step 5: Connect to theme: The word choice shows Nehru's empathy; the grammatical plural indicates multiple crises, reinforcing the narrative of resilience.
REASONING: This demonstrates how to move from word-level grammar to thematic analysis, a key Class 11 skill.
ANSWER: Contextual meaning: traumatic historical events (partition, famine). Base noun: rCnhfy;k (abstract). fo'ks"k.k :i: rCnhfy;kpan (or rCnhfy;k). The plural form 'rCnhfy;ksa' emphasizes multiplicity of crises.

## WORKED_EXAMPLE_2
PROBLEM: The textbook exercise asks for fo'ks"k.k :i of 'fons'k' (government). Derive it and explain why this noun is problematic for the standard derivation rule.
STEPS:
- Step 1: Identify 'fons'k' as an abstract noun (collective entity). It ends in a vowel (ं).
- Step 2: Recall suffixes for vowel-ending nouns: -pan, -ta (e.g., 'vidya' -> 'vidyapan' rare, usually 'vidya' itself). 'fons'k' is a tatsam word from Sanskrit 'saṃsthā'.
- Step 3: Attempt derivation: 'fons'kpan' (state of being a government) or 'fons'kta' (government-ness). Both are rare/awkward.
- Step 4: Analyze why: Some abstract nouns, especially administrative terms, resist further abstraction. The exercise may expect 'fons'k' itself as its own fo'ks"k.k :i (i.e., the characteristic form is the word itself).
- Step 5: Verify with dictionary/grammar: In Hindi grammar, for nouns that are already abstract qualities, the fo'ks"k.k :i is often the word itself. So answer: fons'k.
REASONING: This teaches students to recognize exceptions and not mechanically apply suffixes.
ANSWER: fo'ks"k.k :i of 'fons'k' is 'fons'k' (since it is already an abstract noun denoting the concept of government). Derivation of 'fons'kpan' is not standard usage.

## WORKED_EXAMPLE_3
PROBLEM: Combine vocabulary context and noun derivation: In the phrase "Hkkjr ekrk njvly ;gh djksM+ksa yksx gSa" (India mother is simply millions of people), the word 'njvly' (merely/only) modifies the noun phrase. Rewrite the sentence by replacing 'djksM+ksa yksx' with its fo'ks"k.k :i form derived from 'yksx' (person) and adjust grammar accordingly. Then explain the shift in meaning.
STEPS:
- Step 1: Identify 'yksx' (person) - concrete noun. Derive fo'ks"k.k :i: 'yksxpan' (personhood) or 'yksxta' (humanity). Choose 'yksxta' as more common.
- Step 2: 'djksM+ksa yksx' means 'millions of people'. The abstract collective would be 'djksM+ksa yksxta' (millions of humanities? awkward) or better 'yksxta' as a mass noun: 'Hkkjr ekrk njvly yksxta gS' (India mother is merely humanity).
- Step 3: Rewrite: "Hkkjr ekrk njvly yksxta gS" (India mother is merely humanity/personhood).
- Step 4: Compare: Original emphasizes discrete individuals ('djksM+ksa yksx' - millions of persons). New version emphasizes the collective quality ('yksxta' - humanity). The grammatical shift from countable plural to abstract singular changes the focus from number to essence.
- Step 5: Relate to author's intent: Nehru actually uses 'djksM+ksa yksx' to stress that the motherland is not an abstract goddess but real people. So the concrete plural is rhetorically deliberate.
- Step 6: Conclusion: Grammatical form (concrete plural vs abstract singular) carries ideological weight.
REASONING: This integrates morphology, syntax, and rhetorical analysis - exactly the multi-concept competency needed.
ANSWER: Rewritten: "Hkkjr ekrk njvly yksxta gS". Shift: from counting individuals to defining essence. Nehru's choice of concrete plural underscores his democratic, humanistic nationalism.

## COMPETENCY_QUESTION_1
QUESTION: In the textbook exercise, you are asked to write the fo'ks"k.k :i of 'Hkkjr' (India). 'Hkkjr' is a proper noun (name of a country). Derive its characteristic form and argue whether it should be 'Hkkjrta', 'Hkkjrpan', 'Bharatiyata', or something else. Support with examples from Hindi usage.
COMPETENCY: Morphological analysis and linguistic reasoning
STEPS:
- Step 1: Recognize 'Hkkjr' is a proper noun, typically not derived for abstract quality.
- Step 2: Note that the abstract quality associated with India is 'Hkkjrta' (Indianness) or 'Bharatiyata' (from 'Bharat').
- Step 3: Check if 'Hkkjrpan' exists in usage (rare). 'Hkkjrta' is common in phrases like 'Hkkjrta dh ljk;'.
- Step 4: Conclude that fo'ks"k.k :i for proper nouns often uses a related adjective + suffix (Bharat -> Bharatiyata) rather than the proper noun itself.
- Step 5: Write the answer: The most accepted fo'ks"k.k :i is 'Hkkjrta' or 'Bharatiyata', not a direct derivation from 'Hkkjr'.
ANSWER: fo'ks"k.k :i of 'Hkkjr' is 'Hkkjrta' (Indianness) or 'Bharatiyata' (from Bharat). Direct derivation 'Hkkjrpan' is not standard. This shows fo'ks"k.k :i follows usage patterns, not just mechanical rules.
DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: The author uses the phrase "g^s&d^s" (firm/steadfast) to describe a voice: "vkf[kj ,d g^s&d^s tkV us... tokc fn;k". Analyze the grammatical structure of 'g^s&d^s' (reduplicative/adverbial) and its function in the sentence. Then, create a new sentence using a similar reduplicative pattern (like 'dhIr-dhIr', 'dhire-dhire') to convey a tone of resilience, and explain the grammatical category of such words in Hindi.
COMPETENCY: Grammatical analysis and creative application
STEPS:
- Step 1: Identify 'g^s&d^s' as a reduplicative compound (dvitva/avayavik) functioning as an adverb (kriya visheshan) modifying 'tkV' (voice) or the manner of speaking.
- Step 2: Note the meaning: 'firm, unwavering, steady' (from the gloss: â"V&iq"V] LoLFk] e”kcwr dn&dkBh okyk).
- Step 3: Explain that such words are 'avayavik shabd' or 'dvitva shabd' used adverbially.
- Step 4: Create sentence: "Wo dhIr-dhIr bolti rahi, bina dhere." (She kept speaking steadily, without pausing.)
- Step 5: Explain that 'dhIr-dhIr' is also a reduplicative adverb denoting manner.
- Step 6: Connect to text: The author uses 'g^s&d^s' to characterize the peasant's voice as unshakeable, mirroring the steadfastness of the people.
ANSWER: 'g^s&d^s' is a reduplicative adverb (kriya visheshan) meaning firm/steadfast. New sentence: "Sena veer-veer ladti rahi." (The army fought bravely.) Such words belong to the category of 'avayavik kriya visheshan' (reduplicative adverbs).
DIFFICULTY: hard