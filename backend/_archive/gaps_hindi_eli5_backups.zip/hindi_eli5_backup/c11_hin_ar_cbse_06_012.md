## DEFINITION
Literal comprehension refers to understanding information explicitly stated in the text (facts, details, sequence of events), while inferential comprehension requires deriving meaning not directly stated by using textual evidence, context clues, and logical reasoning to draw conclusions about characters' motives, themes, or implied outcomes.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student can independently distinguish between literal and inferential questions in a board-style exam, locate explicit textual evidence for literal answers, and construct a 4-step PEEL response (Point, Evidence, Explanation, Link) for inferential answers using at least two pieces of textual evidence.

## SCOPE_BOUNDARY
This node covers the classification and answering strategy for literal (fact-based, directly stated) and inferential (implied, reasoning-based) comprehension questions specific to the play "जतन" (Jatuh) from Aroh Class 11. It does NOT cover critical appreciation, creative writing based on the text, or speaking/listening activities (those are separate nodes 013-015).

## WALKTHROUGH
Imagine you are sitting in the exam hall and see a question: "Why does Jatuh refuse to sign the complaint against the headmaster?" You panic because the text never says "Jatuh refuses because..." directly. This is where most students freeze — they hunt for a sentence that doesn't exist. The key insight: board exams test inferential comprehension precisely because the answer isn't written word-for-word. Start by asking: "What does the text explicitly show Jatuh doing/saying?" (literal evidence). Then ask: "What do these actions imply about her values?" (inference). The bridge is textual evidence — every inference must be anchored in something the character said, did, or what another character reported. Practice this two-step scan: highlight explicit facts first, then connect them to the question's "why" or "how."

## DIAGNOSTIC_QUESTION_1
What is the fundamental difference between a literal comprehension question and an inferential comprehension question in the context of board exam pattern?

## DIAGNOSTIC_ANSWER_1
A literal question asks for information directly stated in the text (e.g., "What subject does Jatuh teach?"), while an inferential question requires drawing a conclusion using textual clues (e.g., "Why does Jatuh risk her job to protect Vipin?"). A wrong answer that defines both as "questions based on the text" reveals the student cannot distinguish explicit vs. implicit meaning — a critical gap because board marking schemes allocate different weightage and expect different answer structures for each type.

## DIAGNOSTIC_QUESTION_2
In the play "जतन", Jatuh says: "मैंने पहली बार देखा कि वे बच्चे जो मार खाते हैं, वे मार खाने के आदी हो जाते हैं।" If a question asks: "What does this statement reveal about Jatuh's perspective on corporal punishment?", is this literal or inferential? Justify your classification in two sentences.

## DIAGNOSTIC_ANSWER_2
This is an inferential question. The statement is a direct quote (literal fact), but the question asks what it "reveals about her perspective" — an interpretation of her attitude, not a restatement of the quote. A student who labels this "literal because it's a direct quote" confuses the *source* (explicit text) with the *task* (interpretation). Board exams frequently use direct quotes as springboards for inferential questions; recognizing this pattern prevents misclassification.

## DIAGNOSTIC_QUESTION_3
Given the exchange where the Headmaster says: "नियम! जानती हो तुम्हारा विद्यालय कितने नियमों से चलता है?" and Jatuh replies: "नियम तोड़ने के लिए नहीं, निभाने के लिए होते हैं।" Answer this inferential question using the PEEL structure: "How does this exchange establish the central conflict between institutional authority and individual conscience?" Provide Point, Evidence (paraphrased), Explanation, Link.

## DIAGNOSTIC_ANSWER_3
**Point:** The exchange frames the conflict as rules-as-control vs. rules-as-moral-duty. **Evidence:** Headmaster uses "नियम" to justify administrative power ("कितने नियमों से चलता है"), while Jatuh redefines "नियम" as ethical obligation ("निभाने के लिए"). **Explanation:** Headmaster's tone implies rules are tools for compliance; Jatuh's rebuttal claims rules serve justice. This clash mirrors the larger Vipin case where the system demands procedural conformity (signing false complaint) but conscience demands truth. **Link:** Thus, the dialogue microcosms the play's core tension — bureaucracy vs. humanity. A wrong answer quoting only Jatuh's line without contrasting the Headmaster's framing shows inability to analyze dialogue as dramatic conflict, not just character speech.

## DIAGNOSTIC_QUESTION_4
Compare the literal information about Vipin's academic performance (marks: Physics 86, Chemistry 80, Biology 88, Hindi 82, Maths 90) with Jatuh's inference: "वह लड़का पढ़ने में बहुत तेज है।" Analyze how the playwright uses specific numerical data to build an inferential portrait of Vipin that contrasts with the Headmaster's reduction of him to "कॉपी जाँचने वाला".

## DIAGNOSTIC_ANSWER_4
The literal marks (all above 80, Maths 90) objectively establish Vipin's academic excellence across subjects. Jatuh's inference "बहुत तेज" synthesizes this data into a character trait. The Headmaster's reduction to "कॉपी जाँचने वाला" strips away the human achiever, keeping only bureaucratic utility. The playwright's technique: concrete numbers (literal) → teacher's professional judgment (inferential) → administrator's dehumanizing label (critical irony). A student who merely lists the marks misses the structural contrast — the numbers exist precisely to make the Headmaster's dismissal palpable. Wrong answers treat the marks as "extra information" rather than evidentiary foundation for inference.

## DIAGNOSTIC_QUESTION_5
Evaluate this student's answer to an inferential question: "Why does Jatuh visit the Headmaster's house at night?" — Student writes: "Because she wants to complain about Vipin's punishment." The text shows Jatuh visiting *after* the Headmaster refuses to act at school. Is this answer acceptable for full marks in CBSE Class 11? Defend your evaluation.

## DIAGNOSTIC_ANSWER_5
Unacceptable for full marks. The answer states a literal plot point (visit occurs) but misattributes the *motive* (complaining about punishment) when the text implies she goes to *persuade* the Headmaster to retract the false complaint against Vipin — a nuanced inferential distinction. CBSE marking scheme requires: (1) accurate inference of intent, (2) textual anchor (e.g., "after Headmaster refuses at school"), (3) connection to her ethical stance. The student's answer scores 1/3 (knows visit happens) but loses 2 marks for wrong motive and no evidence. This reveals the common error: confusing *sequence of events* (literal) with *character motivation* (inferential).

## DIAGNOSTIC_QUESTION_6
Create an inferential question based on the final scene where the Headmaster signs the retraction paper, and write a model PEEL answer using evidence from Jatuh's earlier dialogue: "मैंने पहली बार देखा कि वे बच्चे जो मार खाते हैं, वे मार खाने के आदी हो जाते हैं।"

## DIAGNOSTIC_ANSWER_6
**Question:** "How does the Headmaster's final signing of the retraction paper reflect a subtle shift in the power dynamic established through Jatuh's earlier insight about corporal punishment?" **Model Answer:** **Point:** The signing marks institutional power yielding to moral authority. **Evidence:** Jatuh's earlier insight — "मार खाने के आदी हो जाते हैं" — exposes punishment as creating compliance, not change. **Explanation:** The Headmaster, who wielded punishment (Vipin's 72 marks cut, false complaint), finally submits to Jatuh's paper — a non-violent, procedural act. He becomes the one "adapted" to her method. **Link:** Thus, the play ends not with systemic revolution but with one administrator internalizing the teacher's lesson: true authority comes from conscience, not cane. A poor answer describes the signing as "Headmaster agrees" without linking to the punishment-insight motif, showing inability to trace thematic threads across scenes.

## COMMON_MISCONCEPTION
Students believe "inferential" means "guessing" or "giving your opinion." They write answers like "I think Jatuh is brave because she fights the system" without textual evidence. The error stems from Class 10 comprehension where personal response questions were common. In Class 11 board pattern, *every* inference must be grounded in specific textual evidence (dialogue, stage direction, narrative detail). The misconception is: "Inference = my idea" vs. reality: "Inference = text-supported conclusion." For example, in the Vipin case, a student writes "Jatuh helps Vipin because she likes him" (opinion) instead of "Jatuh helps Vipin because she sees his marks (86,80,88,82,90) and knows the complaint is false" (evidence-based inference).

## ON_FAILURE
Step 1: Give the student a 3-column table: Column A = Literal Fact from text (quote/paraphrase), Column B = Inference Question, Column C = Evidence-based Inference. Step 2: Model 2 examples from "जतन" (e.g., Fact: "Vipin gets 72 marks cut" → Question: "Why does Jatuh call it injustice?" → Inference: "Because his actual marks prove excellence, making punishment disproportionate"). Step 3: Student practices 3 more rows independently. Step 4: Immediate feedback — highlight any Column C entry lacking Column A reference. Reinforce: "No evidence = no marks, even if the idea is right."

## BUILDS_ON
c11_hin_ar_cbse_06_002 (Text: Plot and Narrative Structure) — because students must know the sequence of events before distinguishing what is explicitly stated vs. implied.

## LEADS_TO
c11_hin_ar_cbse_06_013 (Critical Thinking: Analysis and Interpretation) — because inferential comprehension is the foundation for higher-order analysis of themes, character psychology, and authorial intent.

## PREREQUISITE_NODE_IDS
c11_hin_ar_cbse_06_001, c11_hin_ar_cbse_06_002, c11_hin_ar_cbse_06_003, c11_hin_ar_cbse_06_004, c11_hin_ar_cbse_06_005, c11_hin_ar_cbse_06_006, c11_hin_ar_cbse_06_007, c11_hin_ar_cbse_06_008, c11_hin_ar_cbse_06_009, c11_hin_ar_cbse_06_010, c11_hin_ar_cbse_06_011
## PREREQUISITE_REASONS
c11_hin_ar_cbse_06_001: Context/background knowledge needed to understand institutional setting of the play
c11_hin_ar_cbse_06_002: Plot structure knowledge required to locate literal events in sequence
c11_hin_ar_cbse_06_003: Setting/atmosphere awareness helps infer mood and tension in scenes
c11_hin_ar_cbse_06_004: Protagonist analysis provides character motivation baseline for inferences
c11_hin_ar_cbse_06_005: Supporting character dynamics (Headmaster, Vipin, Yashoda) are key to inferential questions
c11_hin_ar_cbse_06_006: Primary theme (education vs. bureaucracy) frames many inferential "why" questions
c11_hin_ar_cbse_06_007: Secondary themes (gender, power, conscience) deepen inferential layers
c11_hin_ar_cbse_06_008: Imagery/metaphor recognition aids inferring symbolic meaning
c11_hin_ar_cbse_06_009: Irony/symbolism detection is essential for advanced inferential questions
c11_hin_ar_cbse_06_010: Vocabulary in context prevents misreading key terms (e.g., "विवेक", "नियम")
c11_hin_ar_cbse_06_011: Grammar/usage knowledge ensures accurate parsing of dialogue nuances

## FORWARD_NODE_IDS
c11_hin_ar_cbse_06_013, c11_hin_ar_cbse_06_014, c11_hin_ar_cbse_06_015, c12_hin_ar_cbse_04_012, c12_hin_ar_cbse_06_012

## FORWARD_REASONS
c11_hin_ar_cbse_06_013: Critical thinking requires inferential comprehension as its evidence base
c11_hin_ar_cbse_06_014: Writing skills (analytical paragraphs, character sketches) apply PEEL structure taught here
c11_hin_ar_cbse_06_015: Speaking/listening discussions need students to distinguish fact from interpretation
c12_hin_ar_cbse_04_012: अगला तार्किक चरण: Literal comprehension is the ability to extract explicitly stated facts, details, and sequences dire... इस नोड की अवधारणाओं को सीधे उपयोग/विस्तारित करता है।  
c12_hin_ar_cbse_06_012: Class 11 literal/inferential foundation — this node assumes you already know the definitions.  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
none

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_06_002 -> c11_hin_ar_cbse_06_012 -> c11_hin_ar_cbse_06_013

## THIS_FORMULA
PEEL Structure for Inferential Answers: Point (direct answer to 'why/how') + Evidence (explicit textual detail: quote, action, stage direction, number) + Explanation (logical bridge: how evidence proves point) + Link (connection to theme/character arc/central conflict)

## FORMULA_VARIABLES
Point = 1-sentence claim answering the inferential question; Evidence = specific textual reference (not whole paragraph); Explanation = 2-3 sentences reasoning from evidence to point; Link = 1 sentence connecting to broader theme/play's message

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
linguistic

## CROSS_SUBJECT
c11_history_ncert_03 | Historical source analysis requires distinguishing explicit statements in primary sources (literal) from historian's inferences about motives/causes (inferential) — same evidence-based reasoning
c11_economics_ncert_02 | Interpreting data tables (literal numbers) to infer economic trends (e.g., rising literacy → workforce quality) mirrors marks-to-character inference in the play
c11_civics_ncert_01 | Constitutional provisions (literal text) vs. judicial interpretation (inferential application) parallels rules-as-written vs. rules-as-ethical-duty conflict in Jatuh

## PREREQ_CONCEPT
Ability to locate explicit textual details (quotes, stage directions, numerical data) in the play "जतन" without prompting.

## PREREQ_BEFORE
Student must have read the full play and completed plot/character/theme nodes (001-011) to have the textual reservoir from which to draw evidence.

## PREREQ_STUCK
If stuck, re-read c11_hin_ar_cbse_06_002 (Plot) and c11_hin_ar_cbse_06_004 (Protagonist) to rebuild the event-sequence and character-motivation mental map before attempting inference.

## WORKED_EXAMPLE_1
PROBLEM: Answer this inferential question from "जतन" using PEEL: "Why does Yashoda initially resist Jatuh's intervention but later support her?" (Context: Yashoda is Vipin's mother; early scenes show her fear, later she brings food for Jatuh's protest.)
STEPS:
- Step 1: Identify the question type — "why" about character change = inferential; need evidence from multiple scenes.
- Step 2: Scan text for Yashoda's explicit actions/dialogue: Scene 1 — "नहीं-नहीं, मैं तो बहुत डरती हूँ" (fear); Scene 2 — brings food, says "आजकल के बच्चे..." (shift); Scene 3 — stands with Jatuh at protest.
- Step 3: Select two contrasting pieces of evidence: Early fear dialogue + later supportive action.
- Step 4: Construct Point: Yashoda transforms from fear-driven compliance to conscience-driven solidarity.
- Step 5: Write Explanation: Early fear reflects systemic powerlessness ("मार खाने के आदी"); later support shows Jatuh's moral courage awakening her agency.
- Step 6: Link: This mirrors the play's arc — individual conscience can inspire collective resistance against bureaucratic apathy.
REASONING: The steps enforce evidence-first thinking: locate explicit facts (Step 2) before forming inference (Step 4). Using two temporal evidence points (early vs. late) captures character development, which board exams reward.
ANSWER: **Point:** Yashoda evolves from fearful compliance to active solidarity. **Evidence:** Initially she says "नहीं-नहीं, मैं तो बहुत डरती हूँ" when Jatuh proposes action; later she brings food to the protest site and says "आजकल के बच्चे..." acknowledging the injustice. **Explanation:** Her initial fear reflects internalized helplessness under a system where "मार खाने के आदी हो जाते हैं"; Jatuh's persistent ethical stand models resistance, enabling Yashoda to reclaim agency. **Link:** This mother's transformation embodies the play's message — moral courage is contagious and can dismantle bureaucratic indifference one person at a time.

## WORKED_EXAMPLE_2
PROBLEM: A literal question asks: "What specific academic marks does Vipin score in his five subjects?" An inferential question asks: "How do Vipin's marks function as dramatic evidence in the play?" Answer both, showing the difference in answer structure.
STEPS:
- Step 1: Classify Q1 as literal (direct fact retrieval) and Q2 as inferential (function/meaning of facts).
- Step 2: For Q1, retrieve exact numbers from text: Physics 86, Chemistry 80, Biology 88, Hindi 82, Maths 90. Format as list — no analysis needed.
- Step 3: For Q2, identify the marks' dramatic role: they contradict the Headmaster's claim that Vipin is "कॉपी जाँचने वाला" (clerical material).
- Step 4: Select evidence: Jatuh reads marks aloud ("बैक्सी 86... गणित 90") and says "वह लड़का पढ़ने में बहुत तेज है" — her inference from the data.
- Step 5: Explain the contrast: Numbers (objective truth) vs. Headmaster's label (subjective dismissal) = dramatic irony.
- Step 6: Link to theme: Marks symbolize meritocracy crushed by bureaucratic arbitrariness.
REASONING: This worked example explicitly contrasts the two question types using the same textual data (marks), teaching students that literal answers = data retrieval, inferential answers = data interpretation. The step "identify dramatic role" (Step 3) is the pivot from literal to inferential thinking.
ANSWER: **Literal Answer:** Vipin's marks: Physics 86, Chemistry 80, Biology 88, Hindi 82, Mathematics 90. **Inferential Answer (PEEL):** **Point:** Vipin's marks serve as objective evidence exposing the Headmaster's bureaucratic dehumanization. **Evidence:** Jatuh reads the marks sequentially and concludes "वह लड़का पढ़ने में बहुत तेज है"; Headmaster reduces him to "कॉपी जाँचने वाला". **Explanation:** The specific high scores (all >80) make the Headmaster's dismissal palpable — he ignores merit to enforce procedural conformity (false complaint). The marks become dramatic proof that the system punishes excellence when it threatens administrative convenience. **Link:** Thus, numerical data transforms into thematic symbol: quantifiable truth vs. arbitrary power.

## WORKED_EXAMPLE_3
PROBLEM: Combined application — The play's stage direction reads: "(जतन के पीछे के भाग में विद्यालय का दृश्य... बच्चे पिट रहे हैं)". Question: "Analyze how this stage direction functions as both literal setting and inferential commentary on the education system." (Requires integrating setting analysis from node 003 and literary devices from node 008/009.)
STEPS:
- Step 1: Separate literal vs. inferential layers in the stage direction. Literal: physical setting (school, background), action (children being beaten). Inferential: what this imagery implies about systemic normalization of violence.
- Step 2: Recall node 003 (Setting) — the school is not a sanctuary but a site of fear. Recall node 009 (Irony/Symbolism) — "पिट रहे हैं" (present continuous) suggests ongoing, routine violence.
- Step 3: Identify the dramatic function: placed at the opening, it frames the entire play's conflict before any dialogue.
- Step 4: Connect to Jatuh's later insight: "मार खाने के आदी हो जाते हैं" — the stage direction visually enacts what she later verbalizes.
- Step 5: Construct Point: The opening stage direction establishes corporal punishment as the invisible curriculum of the institution.
- Step 6: Evidence: "बच्चे पिट रहे हैं" (visual literal) + present continuous tense (linguistic literal) + background placement (spatial literal).
- Step 7: Explanation: "पीछे के भाग में" (in the background) implies punishment is foundational, not incidental; "विद्यालय का दृश्य" equates school with beating — setting = synecdoche for system.
- Step 8: Link: This visual thesis statement makes Jatuh's later fight inevitable — she combats what the opening image normalizes.
REASONING: This example synthesizes three prior nodes (setting, irony, plot) to show how board-level inferential questions often require cross-referencing textual elements. The 8 steps model the multi-layered analysis expected in 6-mark questions.
ANSWER: **Point:** The opening stage direction literally depicts a school scene but inferentially establishes corporal punishment as the institution's hidden curriculum. **Evidence:** Literal details — "विद्यालय का दृश्य" (setting), "बच्चे पिट रहे हैं" (action), "पीछे के भाग में" (spatial framing), present continuous "पिट रहे हैं" (tense). **Explanation:** "पीछे के भाग में" positions violence as the backdrop supporting the foreground narrative — punishment is the system's foundation. Present continuous denotes habitual action, not isolated incident. "विद्यालय का दृश्य" = synecdoche where part (beating) stands for whole (education). This visual thesis is verbalized later by Jatuh: "मार खाने के आदी हो जाते हैं." **Link:** The play's structure enacts its argument: the opening image normalizes what the protagonist must denormalize. Jatuh's journey is making the background visible — turning "दृश्य" into "विवेक."

## COMPETENCY_QUESTION_1
QUESTION: In the CBSE Class 11 Hindi Core sample paper, a 3-mark question reads: "जतन की अंतिम पंक्ति 'आजकल के बच्चे...' में यशोदा का कथन किस सामाजिक यथार्थ की ओर संकेत करता है? पाठ के आधार पर स्पष्ट कीजिए।" Identify the question type, then write a model answer using PEEL with evidence from two different scenes.
COMPETENCY: Textual evidence integration across scenes for inferential interpretation
STEPS:
- Step 1: Classify — "किस सामाजिक यथार्थ की ओर संकेत करता है" = inferential (social reality implication).
- Step 2: Locate the quoted line context: Yashoda says this at the protest site (final scene), observing students.
- Step 3: Find earlier scene evidence of the same social reality: Scene where she fears system ("मैं बहुत डरती हूँ") and Scene where Jatuh explains punishment's effect ("मार खाने के आदी").
- Step 4: Synthesize: The line signals intergenerational internalization of oppression — parents teach children compliance because they've learned "resistance is futile."
- Step 5: Write PEEL answer linking final line to earlier evidence.
ANSWER: **Question Type:** Inferential (asks for implied social reality, not literal meaning of the line). **Model Answer:** **Point:** Yashoda's final remark "आजकल के बच्चे..." signals the cyclical internalization of systemic oppression across generations. **Evidence 1:** Earlier she admits "नहीं-नहीं, मैं तो बहुत डरती हूँ" — her fear teaches Vipin compliance. **Evidence 2:** Jatuh's analysis "मार खाने के आदी हो जाते हैं" explains the mechanism: punishment conditions acceptance. **Explanation:** Yashoda's shift from fearful mother to protest participant mirrors the social reality — when adults model resistance (Jatuh), children ("आजकल के बच्चे") learn courage instead of compliance. Her remark is both observation and hope. **Link:** Thus, the play ends not with systemic victory but with generational possibility — the "social reality" is changeable through moral example.
DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: A 6-mark board question: "जतन नाटक में 'नियम' शब्द की व्यंजना कैसे बदलती है? प्रधानाचार्य, जतन और यशोदा के संवादों के प्रमाण सहित व्याख्या कीजिए।" (How does the connotation of 'नियम' (rule) shift in the play? Explain with evidence from Headmaster, Jatuh, and Yashoda's dialogues.) This requires tracking a lexical motif across three characters — a high-order inferential task.
COMPETENCY: Lexical motif tracking and multi-character comparative inference
STEPS:
- Step 1: Identify the core task — trace semantic shift of one word ("नियम") across three speakers = inferential + comparative.
- Step 2: Extract each character's "नियम" usage: Headmaster: "नियम! जानती हो तुम्हारा विद्यालय कितने नियमों से चलता है?" (instrument of control); Jatuh: "नियम तोड़ने के लिए नहीं, निभाने के लिए होते हैं" (moral covenant); Yashoda: (implied) — her silence/compliance initially, later participation in protest = "नियम" as lived justice.
- Step 3: Analyze the shift trajectory: Administrative → Ethical → Communal.
- Step 4: Structure answer: Introduction (thesis: word evolves from bureaucratic tool to moral compass), three body paragraphs (one per character with quote + inference), synthesis paragraph (trajectory significance), conclusion (link to theme).
- Step 5: Ensure each paragraph follows Point-Evidence-Explanation for that character.
ANSWER: **Thesis:** "नियम" undergoes a semantic migration from administrative coercion to ethical commitment to collective conscience. **Headmaster:** "नियम! जानती हो तुम्हारा विद्यालय कितने नियमों से चलता है?" — **Inference:** Rules as hierarchical control mechanisms; "चलता है" (runs) implies mechanical compliance, not justice. **Jatuh:** "नियम तोड़ने के लिए नहीं, निभाने के लिए होते हैं" — **Inference:** "निभाने" (upholding/fulfilling) redefines rule as moral duty; contrast "तोड़ने" (breaking) vs. "निभाने" frames ethics as active practice. **Yashoda:** No direct "नियम" quote, but her arc — from "डरती हूँ" (rule-fear) to protest participation (rule-embodiment) — **Inference:** She internalizes Jatuh's definition; her body at the protest *becomes* the rule upheld. **Synthesis:** The word travels top-down (Headmaster's imposition) → horizontal (Jatuh's redefinition) → bottom-up (Yashoda's enactment). **Link:** This lexical journey dramatizes the play's central argument: true "नियम" is not written in circulars but lived in conscience.
DIFFICULTY: hard