## DEFINITION
Grammar in the context of literary analysis refers to the study of how grammatical structures — tense, aspect, mood, sentence type, repetition, word order, negation, and clause structure — function not merely as rules of correct usage but as *meaning-making resources* that a poet deploys to achieve specific emotional and thematic effects. In Hindi Aroh Chapter 11, the poem "Ghar ki Yaad" (Memory of Home), grammatical choices are inseparable from the poem's emotional purpose: the tenses the poet selects encode the relationship between past and present; the repetitions enact the obsessive return of memory; the sentence structures — whether complete or fragmented, flowing or broken — mirror the speaker's psychological state of nostalgic longing. Grammar in this poem is not a neutral vehicle carrying meaning; it *is* the meaning, shaping the reader's experience of nostalgia at the level of syntax itself.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student must independently identify at least three distinct grammatical features in the poem (e.g., tense shifts, repetition patterns, sentence fragmentation, negation structures), explain how each feature serves the poem's emotional purpose of evoking nostalgia and longing, and demonstrate how altering a grammatical feature (e.g., changing past tense to present, removing a repetition, completing a fragmented sentence) would change the poem's emotional effect. The student must also explain how the grammatical structure of at least one stanza works as an *integrated system* where multiple features (tense + repetition + sentence type) combine to produce a single emotional outcome.

## SCOPE_BOUNDARY
This node covers the analysis of grammatical structures and language usage patterns specifically within the poem "Ghar ki Yaad" in Hindi Aroh Chapter 11, including tense, aspect, repetition, sentence structure, negation, and word order as meaning-making resources. It does NOT cover vocabulary analysis (addressed in node 010), literary devices such as metaphor or imagery (addressed in sibling device nodes), rhyme scheme or meter (addressed in node 003), or the poem's themes (addressed in node 006). It does not extend to teaching Hindi grammar rules as such — the node assumes grammatical knowledge and applies it analytically.

## WALKTHROUGH
Imagine a friend telling you about a childhood home: "I *lived* there. I *played* in that courtyard. I *was* happy." Now imagine the same friend saying: "I *live* there. I *play* in that courtyard. I *am* happy." The first version is memory — past tense places the experience in a time that is gone, creating distance and loss. The second version is hallucination — present tense makes the past feel alive, as if the speaker has not left, creating a haunting immediacy. That is the power of grammatical tense in a poem about memory. Now open "Ghar ki Yaad" and scan for tense: which lines use past tense (memory, distance, loss)? Which lines shift to present tense (immediacy, haunting presence, the past refusing to stay past)? Does the poet use future tense anywhere, and if so, what does it mean to speak of the future in a poem about the past? Next, look for repetition — not just repeated words but repeated *structures* (anaphora, parallel constructions). Repetition in a poem about memory is not redundancy; it is *enactment* — the speaker returns to the same image, the same phrase, the same grammatical pattern, just as the mind returns obsessively to the memory of home. Then examine sentence structure: are the sentences complete and flowing, or fragmented and broken? Complete sentences suggest a mind in control, narrating memory from a distance; fragments suggest a mind overwhelmed, the memory breaking through in pieces rather than as coherent narrative. The key insight: in a poem about nostalgia, grammar is not the container of emotion — it *is* the emotion, experienced at the level of syntax.

## DIAGNOSTIC_QUESTION_1
Explain in your own words how a poet's choice of tense (past, present, future) shapes the reader's experience of a poem about memory. Give an example from everyday speech where changing the tense of a sentence about a past event changes its emotional effect.

## DIAGNOSTIC_ANSWER_1
Past tense creates distance — the event is over, the speaker is separated from it by time, and the emotional register is typically nostalgic or melancholic. Present tense creates immediacy — the event feels ongoing, as if the speaker is reliving it, and the emotional register is typically haunting or vivid. Future tense about a past event creates longing or projection — the speaker imagines returning, recreating, or re-experiencing what is gone. Example: "I *lived* in that house" (past: memory, distance, acceptance of loss) vs. "I *live* in that house" (present: the memory is so vivid it feels current, the speaker has not psychologically left). A wrong answer that treats tense as merely "when the action happens" (a grammatical definition without emotional analysis) reveals the student can identify tense but cannot perform *functional tense analysis* — the senior-secondary skill of reading tense as an *emotional resource*, not just a temporal marker.

## DIAGNOSTIC_QUESTION_2
In "Ghar ki Yaad," identify a passage where the poet shifts from one tense to another. Explain what each tense contributes to the emotional landscape of the passage and why the *shift* — not just each tense individually — is the key to the poem's effect.

## DIAGNOSTIC_ANSWER_2
A strong answer identifies a passage where the poet moves between tenses (e.g., from past to present, or from present to past). The past tense contributes distance, memory, and the recognition of loss — the home is remembered, not inhabited. The present tense contributes immediacy, haunting presence, and the refusal of distance — the home is felt, not just remembered. The *shift* is the key because it enacts the psychological experience of nostalgia: the speaker oscillates between remembering (past, the home is gone) and reliving (present, the home is here), and this oscillation *is* nostalgia — the inability to settle in either tense. A wrong answer that analyzes each tense separately without explaining the *shift* reveals the student can identify tense but cannot read tense *transition* as a structural device that enacts psychological movement.

## DIAGNOSTIC_QUESTION_3
Identify a pattern of repetition in the poem — a repeated word, phrase, or grammatical structure. Explain how the repetition serves the poem's emotional purpose. Is the repetition *reinforcing* (deepening the same feeling) or *accumulating* (building toward a new feeling)? Justify your answer.

## DIAGNOSTIC_ANSWER_3
A strong answer identifies a specific repetition pattern and analyzes its function. If the poet repeats a word or phrase associated with home (e.g., a repeated invocation of a room, a sound, a person), the repetition *enacts* the obsessive return of memory — the mind cannot leave the image, returns to it again and again. If the repetition is *reinforcing*, each repetition deepens the same emotion (the longing intensifies but does not change). If the repetition is *accumulating*, each repetition adds a new layer (the longing shifts, deepens, or transforms — the second repetition is not the same as the first because the first has already changed the reader's emotional state). A wrong answer that calls repetition "for emphasis" or "for poetic effect" without specifying *which* effect reveals the student sees repetition as a decorative device rather than a *structural enactment* of the psychological process of remembering.

## DIAGNOSTIC_QUESTION_4
Examine the sentence structure in a key stanza of the poem. Are the sentences complete and flowing, or fragmented and broken? How does the sentence structure mirror the speaker's psychological state? What would change if the fragments were completed into full sentences?

## DIAGNOSTIC_ANSWER_4
A strong answer identifies whether the sentences are complete or fragmented and connects this to the speaker's state of mind. If the sentences are fragmented (incomplete clauses, broken phrases, dashes or ellipses), the fragmentation mirrors a mind overwhelmed by memory — the emotion breaks through in pieces, not as coherent narrative. Completing the fragments into full sentences would impose order and distance: a complete sentence says "this is what happened," while a fragment says "this is what I cannot fully articulate." The completion would reduce the rawness of the emotion by giving it grammatical containment. A wrong answer that treats sentence structure as merely "the poet's style" without connecting it to psychological state reveals the student cannot read grammar as a *mirror of consciousness* — the senior-secondary skill of seeing syntactic form as psychological content.

## DIAGNOSTIC_QUESTION_5
Analyze the use of negation in the poem — instances where the poet uses negative constructions ("not," "no," "never," "without"). How does negation contribute to the poem's emotional effect? Is the negation *absence* (something is missing) or *refusal* (something is denied)? Explain the difference and its emotional consequence.

## DIAGNOSTIC_ANSWER_5
A strong answer distinguishes between negation as *absence* (something that was there is now gone — "there is no longer the sound of...") and negation as *refusal* (something is denied or rejected — "I will not forget..."). Absence-negation creates emptiness and loss — the negative construction highlights what is missing, making the reader *feel* the gap. Refusal-negation creates defiance and persistence — the negative construction asserts the speaker's will against forgetting, making the negative a form of *commitment*. The emotional consequence: absence-negation produces melancholy (the home is gone); refusal-negation produces determination (the memory will not be lost). A poem about nostalgia typically uses both: absence to create the ache of loss, refusal to create the insistence of memory. A wrong answer that treats all negation as "saying something is not there" reveals the student misses the *modal* dimension of negation — negation can be descriptive (absence) or volitional (refusal), and the difference shapes the poem's emotional register.

## DIAGNOSTIC_QUESTION_6
Rewrite one stanza of the poem changing three grammatical features (e.g., tense, repetition, sentence structure). Write both the original and your rewritten version. Then explain in 4-5 sentences how each grammatical change alters the emotional effect, demonstrating that the poet's original grammatical choices were not arbitrary but *motivated* by the poem's emotional purpose.

## DIAGNOSTIC_ANSWER_6
A strong answer selects a stanza, identifies three grammatical features in it, changes each one (e.g., past tense → present, removes a repetition, completes a fragment), and explains the cumulative effect of the changes. For example, changing past to present would shift the stanza from memory to hallucination; removing repetition would flatten the obsessive return of memory into a single, linear statement; completing a fragment would impose grammatical order on emotional overflow. The cumulative effect: the rewritten stanza would feel *calmer, more distant, more controlled* — and therefore *less nostalgic*. The original's grammatical "irregularities" (tense shifts, repetitions, fragments) are not errors but *techniques* — each one serves the poem's purpose of making the reader *feel* nostalgia rather than merely understand it. A poor answer that changes words but not grammatical structures, or that cannot articulate the emotional consequence of each change, reveals the student cannot perform *grammatical functional analysis* — the skill of reading grammar as emotional architecture.

## COMMON_MISCONCEPTION
Students treat grammar as a *separate layer* from meaning — they analyze "what the poem says" (content) and "what devices it uses" (metaphor, imagery) but treat grammar as the *invisible scaffolding* that holds the poem up without contributing to its effect. The specific error in "Ghar ki Yaad" is reading the tense shifts, repetitions, and sentence fragments as *accidents of expression* rather than as *deliberate techniques*. Students may notice that the poet repeats a phrase but explain it as "for emphasis" (a middle-school answer) rather than analyzing *what kind* of emphasis — obsessive return, emotional accumulation, structural echo. A deeper error is assuming that grammatical correctness equals grammatical effectiveness: students may "correct" a fragment into a complete sentence and feel they have improved it, not realizing they have destroyed the fragment's psychological function. The root cause is that grammar is taught as *rules* (what is correct) rather than as *resources* (what is possible) — students learn to identify tense and sentence type but never learn to ask: *what does this tense do to the reader? What does this sentence structure make the reader feel?*

## ON_FAILURE
Step 1: Select a key stanza from the poem. Have the student identify every verb and label its tense (past, present, future). Then ask: "Which tense dominates? Where does the tense shift? What does the shift feel like when you read it aloud?" Step 2: Have the student mark every repeated word or phrase in the stanza. Ask: "Is the repetition exact or varied? Does the repeated word mean the same thing each time, or does its meaning shift? What would be lost if the repetition were removed?" Step 3: Have the student identify the sentence boundaries — where does each sentence start and end? Are there fragments? Incomplete clauses? Dashes or ellipses? Ask: "If you completed this fragment into a full sentence, would the emotion be stronger or weaker? Why?" Step 4: Have the student rewrite the stanza in a single tense, without repetition, in complete sentences. Read both versions aloud. Ask: "Which version feels more like nostalgia? Why? What did the grammar contribute that the words alone could not?" This exercise forces the student to *experience* grammar as emotional architecture by removing it and observing the consequence.

## PREREQUISITE_NODE_IDS
c11_hin_ar_cbse_11_001, c11_hin_ar_cbse_11_002, c11_hin_ar_cbse_11_006, c11_hin_ar_cbse_11_008, c11_hin_ar_cbse_11_010

## PREREQUISITE_REASONS
c11_hin_ar_cbse_11_001: The "Before You Read" context establishes the poet's biographical background and the historical/cultural setting of the poem, which is essential because grammatical choices (register, dialect, formality) are shaped by the poet's background and the poem's context.
c11_hin_ar_cbse_11_002: Plot and narrative structure analysis (or in the case of a poem, the structural arc — opening, development, climax, resolution) establishes where grammatical features appear in the poem's movement, which is essential because tense shifts and repetition patterns are *structurally positioned* — they occur at specific points in the poem's arc for specific reasons.
c11_hin_ar_cbse_11_006: Theme analysis identifies the poem's central themes (nostalgia, loss, the persistence of memory, home as identity), which are the *meaning* that grammatical structures serve. Without thematic clarity, grammar analysis becomes identification of features without explanation of function — the student needs to know what emotion or theme the grammar is constructing.
c11_hin_ar_cbse_11_008: Grammar analysis (e.g., verb forms in metaphors) builds on identifying figurative constructions.  
c11_hin_ar_cbse_11_010: Grammar analysis (e.g., 'csVs' as causative verb vs noun) requires prior semantic clarity on what the word *means* in context.  

## FORWARD_NODE_IDS
c11_hin_ar_cbse_11_012, c11_hin_ar_cbse_11_013, c11_hin_ar_cbse_11_014, c12_hin_a_cbse_04_011, c12_hin_a_cbse_08_011, c12_hin_a_cbse_09_011, c12_hin_a_cbse_11_011, c12_hin_a_cbse_12_011, c12_hin_a_cbse_17_011, c12_hin_ar_cbse_01_011, c12_hin_ar_cbse_02_011, c12_hin_ar_cbse_07_011, c12_hin_ar_cbse_09_011, c12_hin_ar_cbse_10_011, c12_hin_ar_cbse_11_011

## FORWARD_REASONS
c11_hin_ar_cbse_11_012: Character and voice analysis builds on grammar analysis — the speaker's psychological state (which character/voice analysis examines) is encoded *in* the grammar (tense, repetition, fragmentation). Understanding how grammar functions (this node) is prerequisite to analyzing how the speaker's voice is grammatically constructed.
c11_hin_ar_cbse_11_013: Critical thinking and interpretation questions in board exams demand evidence-based analysis of how grammatical structures construct meaning — this node provides the analytical framework (tense as emotional resource, repetition as enactment, fragmentation as psychological mirror) that the critical thinking node will require students to apply independently.
c11_hin_ar_cbse_11_014: Grammar usage helps write error-free analytical sentences.  
c12_hin_a_cbse_04_011: अगला तार्किक चरण: This node analyzes the grammatical structures, syntactic patterns, and language usage specific to th... इस नोड की अवधारणाओं को सीधे उपयोग/विस्तारित करता है।  
c12_hin_a_cbse_08_011: Class 11 Grammar node covers Braj Bhasha verb morphology, sandhi-samas rules, and historical sound changes — essential foundation for analyzing Phoolchand's language. c12_hin_a_cbse_08_010: Vocabulary in Context provides the archaic-to-modern word mappings (kCnkFkZ) that this node uses as data for grammatical analysis.  
c12_hin_a_cbse_09_011: Covered *bhasha aur boli* concept — theoretical basis for treating Braj as literary dialect, not "wrong Hindi".  
c12_hin_a_cbse_11_011: Practices integrated grammatical analysis of a full story — model for this chapter's three stories.  
c12_hin_a_cbse_12_011: Comparison of urban vs rural registers in Class 11 texts  
c12_hin_a_cbse_17_011: Practiced writing grammar-focused answers — board exam skill.  
c12_hin_ar_cbse_01_011: Comparative analysis of grammatical deviation across texts.  
c12_hin_ar_cbse_02_011: Advanced grammatical analysis.  
c12_hin_ar_cbse_07_011: Metrical scanning drills.  
c12_hin_ar_cbse_09_011: Exposure to symbolism through lexical choice.  
c12_hin_ar_cbse_10_011: Dialect in autobiographical writing (Chapter 11).  
c12_hin_ar_cbse_11_011: Prepares for philosophical register analysis  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
none

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_11_006 -> c11_hin_ar_cbse_11_011 -> c11_hin_ar_cbse_11_013

## THIS_FORMULA
N/A - conceptual

## FORMULA_VARIABLES
N/A

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
analytical

## CROSS_SUBJECT
N/A

## PREREQ_CONCEPT
Understanding that grammatical structures (tense, repetition, sentence type, negation) are not neutral rules but *meaning-making resources* that a poet deploys to achieve specific emotional and thematic effects. Grammar in a poem is not the invisible scaffolding but the *visible architecture* — the reader experiences the poem's emotion *through* its grammar, not despite it.

## PREREQ_BEFORE
The student must be able to: (1) identify Hindi verb tenses (past, present, future) and sentence types (declarative, interrogative, fragment); (2) identify the poem's central themes (from node 006); (3) recognize repetition when it occurs in a text; (4) distinguish literal from figurative language — all skills developed in earlier nodes and in standard Hindi grammar instruction.

## PREREQ_STUCK
If the student cannot connect grammar to emotion, return to node 006 (Theme) and re-establish the poem's emotional core (nostalgia, longing, the ache of distance). Then ask: "When you feel nostalgic, do you speak in complete, calm sentences, or do you repeat yourself, trail off, and mix past and present? The poet's grammar does the same thing — it *behaves* like a nostalgic mind." This re-anchors grammar in lived emotional experience.

## WORKED_EXAMPLE_1
PROBLEM: Analyze the tense usage in a key stanza of "Ghar ki Yaad." Identify the dominant tense, locate any tense shifts within the stanza, and explain how the tense pattern contributes to the poem's emotional effect of nostalgia.

STEPS:
- Step 1: Identify all verbs in the stanza and label each by tense (past, present, future, habitual). Note which tense is dominant — the dominant tense establishes the stanza's *temporal home base*.
- Step 2: Locate tense shifts — identify any point where the tense changes. Mark the exact word where the shift occurs. The shift is not random; it occurs at a specific moment for a specific reason.
- Step 3: Analyze the dominant tense — if past tense dominates, the stanza is positioned in memory: the speaker is looking back, the home is gone, the emotional register is loss. If present tense dominates, the stanza is positioned in immediacy: the home is felt now, the memory is not distant but present, the emotional register is haunting.
- Step 4: Analyze the shift — when the tense shifts, what changes emotionally? A shift from past to present means the memory *erupts* into the present — the speaker is no longer remembering but *reliving*. A shift from present to past means the immediacy *recedes* — the speaker pulls back from the hallucination of presence into the reality of distance. The shift enacts the *oscillation* that defines nostalgia: the inability to stay in either past or present.
- Step 5: Connect to the poem's emotional purpose — the tense pattern (dominant tense + shifts) is not a grammatical accident but an *emotional strategy*. The poet uses tense to make the reader *experience* the oscillation of nostalgia — the reader is pulled between past and present just as the speaker is, feeling the ache of distance and the shock of immediacy in alternation.

REASONING: This worked example models *tense analysis as emotional architecture* — the skill of reading tense not as a temporal marker but as a psychological resource. The critical move is Step 4: analyzing the *shift* rather than each tense individually, because nostalgia lives in the *transition* between tenses, not in any single tense. This skill is directly tested in board exam questions asking "How does the poet's use of tense contribute to the poem's mood?"

ANSWER: The stanza's tense pattern contributes to nostalgia through the *oscillation* between past and present. The dominant tense establishes the temporal base (memory or immediacy), and the shifts enact the psychological movement of nostalgia — the speaker's inability to settle in either past (the home is gone) or present (the home is here). The tense pattern is an emotional strategy: it makes the reader *experience* the oscillation rather than merely understand it, pulling the reader into the same temporal instability that the speaker feels.

## WORKED_EXAMPLE_2
PROBLEM: Identify a repetition pattern in the poem — a word, phrase, or grammatical structure that recurs. Analyze whether the repetition is *reinforcing* (deepening the same emotion) or *accumulating* (building toward a new emotion). Explain how the repetition serves the poem's purpose of enacting the obsessive return of memory.

STEPS:
- Step 1: Identify the repetition — locate a word, phrase, or grammatical structure that appears more than once. Note whether the repetition is *exact* (identical each time) or *varied* (the same element with modifications).
- Step 2: Map the occurrences — list each occurrence with its surrounding context. Where in the poem does each appear? What surrounds each occurrence? The context determines whether the repetition means the same thing each time or something different.
- Step 3: Determine reinforcing vs. accumulating — if each repetition deepens the *same* emotion (the longing intensifies but does not change), it is *reinforcing*. If each repetition adds a *new layer* (the longing shifts, deepens, or transforms — the second occurrence means something different because the first has already changed the reader's state), it is *accumulating*.
- Step 4: Analyze the psychological function — repetition in a poem about memory *enacts* the mind's obsessive return. The speaker cannot leave the image, the phrase, the memory — the mind circles back, and the repetition makes the reader circle back too. This is not redundancy but *simulation*: the reader experiences the obsessive return that defines nostalgia.
- Step 5: Test by removal — imagine the poem without the repetition (each element appearing only once). What is lost? If the loss is *intensity* (the emotion is weaker), the repetition was reinforcing. If the loss is *development* (the emotion does not evolve), the repetition was accumulating. Either way, the removal confirms that the repetition is *functional*, not decorative.

REASONING: This worked example models *repetition analysis as psychological enactment* — the skill of reading repetition not as "emphasis" but as a *simulation of mental process*. The critical move is Step 3: distinguishing *reinforcing* from *accumulating* repetition, which is a senior-secondary analytical distinction that transforms "the poet repeats for emphasis" (middle-school) into "the poet's repetition enacts the mind's obsessive return, and each return either deepens or transforms the emotion" (senior-secondary).

ANSWER: The repetition pattern in the poem is [reinforcing/accumulating] — each recurrence of the repeated element [deepens the same emotion / adds a new emotional layer], enacting the mind's obsessive return to the memory of home. The repetition is not decorative but *psychological*: it simulates the process of remembering, making the reader experience the circular, inescapable movement of nostalgia. Removing the repetition would weaken the poem not by reducing emphasis but by destroying the *enactment* of mental process that gives the poem its emotional authenticity.

## WORKED_EXAMPLE_3
PROBLEM: Examine the sentence structure across the poem. Identify whether the sentences are predominantly complete and flowing or fragmented and broken. Explain how the sentence structure mirrors the speaker's psychological state. Then, rewrite one passage converting fragments to complete sentences (or complete sentences to fragments) and analyze what is gained and lost in each version.

STEPS:
- Step 1: Survey sentence structure — read the poem and mark sentence boundaries (periods, dashes, line breaks that function as syntactic breaks). Count complete sentences vs. fragments. Identify the dominant pattern.
- Step 2: Connect to psychological state — if fragments dominate, the speaker's mind is *overwhelmed*: memory breaks through in pieces, not as coherent narrative. If complete sentences dominate, the speaker's mind is *controlled*: memory is narrated from a distance, with composure. The sentence structure mirrors the speaker's relationship to the memory — fragments suggest the memory is *too close* to narrate calmly; complete sentences suggest the memory has been *processed* enough to articulate.
- Step 3: Identify structural variation — does the poem shift from fragments to complete sentences (or vice versa) at any point? This shift marks a psychological transition: the speaker moves from overwhelmed to composed (or from composed to overwhelmed), and the sentence structure *tracks* this movement.
- Step 4: Rewrite experiment — take a passage with fragments and complete them into full sentences. Then take a passage with complete sentences and fragment them. Compare each rewritten version with the original.
- Step 5: Analyze gains and losses — completing fragments imposes order and distance: the emotion is contained, articulated, but *tamed*. Fragmenting complete sentences breaks composure: the emotion overflows, but *coherence* is lost. The original poem's choice of sentence structure represents a *balance* between emotional rawness and narrative control — and that balance is the poem's specific emotional signature. Changing it in either direction produces a *different* poem with a *different* emotional effect.

REASONING: This worked example models *sentence structure as psychological mirror* — the skill of reading syntax as a reflection of consciousness. The critical move is Step 5: analyzing *both directions* of rewriting (completing fragments AND fragmenting complete sentences) to demonstrate that the poet's original choice is not a default but a *deliberate balance* between two emotional possibilities. This bidirectional analysis is a senior-secondary skill that distinguishes "the poet uses fragments" (observation) from "the poet's choice of fragments over complete sentences represents a specific emotional calibration that alternatives cannot achieve" (analysis).

ANSWER: The poem's sentence structure mirrors the speaker's psychological state: [fragments/complete sentences] dominate, suggesting a mind [overwhelmed by memory that breaks through in pieces / composed enough to narrate memory from a distance]. Completing fragments would impose order but tame the emotion; fragmenting complete sentences would intensify the emotion but lose coherence. The poet's original choice represents a deliberate balance between rawness and control — a specific emotional calibration that changing the sentence structure in either direction would destroy.

## COMPETENCY_QUESTION_1
QUESTION: A critic argues: "The grammatical irregularities in 'Ghar ki Yaad' — tense shifts, repetitions, and sentence fragments — are not flaws but the poem's most sophisticated techniques. They prove that the poet has mastered grammar well enough to *break* it purposefully." (a) Identify one grammatical "irregularity" from the poem and explain how it serves the poem's emotional purpose. (b) Defend or challenge the critic's claim that purposeful grammatical breaking requires *mastery* of grammar. (c) What is the difference between a grammatical *error* and a grammatical *technique*? How can a reader tell the difference?

COMPETENCY: Evaluating claims about grammatical purposefulness — distinguishing error from technique, a key analytical skill for board exam "evaluate" questions requiring judgment about authorial intention.

STEPS:
- Step 1: Identify a grammatical irregularity — select a tense shift, repetition, or sentence fragment from the poem. Describe it precisely (where it occurs, what it looks like grammatically).
- Step 2: Explain its emotional purpose — connect the irregularity to the poem's emotional effect. The tense shift enacts temporal oscillation (nostalgia); the repetition enacts obsessive return (memory's circularity); the fragment enacts psychological overwhelm (memory breaking through in pieces). The irregularity is not an error but a *technique* because it serves a specific, identifiable emotional function.
- Step 3: Evaluate the "mastery" claim — purposeful breaking requires knowing the rule being broken and *why*. A poet who shifts tense without understanding tense cannot control the effect; the shift would be random, not motivated. Mastery means the poet can choose *which* rule to break, *when*, and *what effect* the breaking produces. This is different from ignorance, where breaking is accidental and the effect is uncontrolled.
- Step 4: Distinguish error from technique — an error is *unmotivated*: it serves no function, and removing it would improve the text. A technique is *motivated*: it serves a function, and removing it would *diminish* the text. The reader tells the difference by *removal test*: if you "correct" the irregularity (complete the fragment, regularize the tense, remove the repetition), does the poem improve or deteriorate? If it deteriorates, the irregularity was a technique; if it improves, it was an error.
- Step 5: Formulate judgment — the critic's claim is [defensible/challengable] because [the poem's irregularities pass the removal test / do not pass the removal test], demonstrating [purposeful technique / accidental error].

ANSWER: (a) [Specific irregularity] serves the poem's emotional purpose by [enacting temporal oscillation / obsessive return / psychological overwhelm]. (b) The critic's claim is defensible: purposeful grammatical breaking requires mastery because the poet must know *which* rule to break, *when*, and *what effect* the breaking produces — random breaking produces random effects, not the controlled emotional architecture the poem displays. (c) An error is unmotivated (serves no function; correction improves the text); a technique is motivated (serves a function; correction diminishes the text). The reader distinguishes them by the *removal test*: "correct" the irregularity and observe whether the poem gains or loses emotional power.

DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: Construct an analytical paragraph (PEEL structure) arguing that the poem's grammatical structure operates as an *integrated system* — that tense, repetition, and sentence structure do not work independently but *combine* to produce the poem's emotional effect of nostalgia. Identify a single stanza where all three features operate simultaneously, analyze how they interact, and explain why analyzing any one feature *without* the others would produce an incomplete reading.

COMPETENCY: Synthesizing multiple grammatical features into an integrated analysis — demonstrating that grammatical structures work as a *system*, not as isolated features, a senior-secondary analytical skill.

STEPS:
- Step 1: Point — The poem's grammatical structure operates as an integrated system: tense, repetition, and sentence structure combine in a single stanza to produce nostalgia, and analyzing any one feature without the others produces an incomplete reading.
- Step 2: Evidence — Select a stanza where all three features are present. Identify the tense pattern (dominant tense + shifts), the repetition pattern (repeated element + function), and the sentence structure (complete vs. fragment). Quote key examples of each.
- Step 3: Explanation — Analyze how the three features *interact*: the tense shift creates temporal instability (the speaker oscillates between past and present); the repetition enacts the obsessive return that *drives* the oscillation (the mind returns to the same image, pulling it between tenses); the sentence fragmentation *results from* the instability (the mind cannot form complete sentences because it is caught between tenses and trapped in repetition). The features are not parallel but *causal*: repetition drives tense shifts, tense shifts produce fragmentation. They form a *cascade*, not a list.
- Step 4: Link — Analyzing any one feature alone produces an incomplete reading: tense alone shows oscillation but not *why* the speaker cannot stabilize (repetition explains this); repetition alone shows obsessive return but not *what* it produces (fragmentation shows this); fragmentation alone shows overwhelm but not *what causes* it (tense shifts and repetition explain this). Only the *integrated* analysis reveals the full emotional mechanism: repetition → tense instability → syntactic fragmentation → the reader's experience of nostalgia as a *system*, not a single feeling.
- Step 5: Concluding synthesis — The poem's grammar is not a collection of independent features but a *cascade* where each feature drives the next, producing nostalgia as a *systemic* emotional effect. The poet's mastery lies not in deploying each feature well but in *linking* them so that the reader experiences nostalgia not as a single emotion but as a *process* — the mind returning, oscillating, and breaking apart, all at once.

ANSWER: The poem's grammatical structure operates as an integrated system in which tense, repetition, and sentence structure combine in a single stanza to produce nostalgia as a *process*, not a single feeling. Repetition drives tense instability (the mind's return pulls it between past and present); tense instability produces syntactic fragmentation (the mind cannot form complete sentences while oscillating temporally). The features form a *cascade*, not a list: each one causes the next. Analyzing any one feature alone is incomplete because each feature's function is *defined* by its interaction with the others. Only integrated analysis reveals the full emotional mechanism: the reader experiences nostalgia as a systemic process — the mind returning, oscillating, and breaking apart simultaneously.

DIFFICULTY: hard
