## DEFINITION
Critical thinking in literary analysis is the disciplined process of examining a text's components—such as imagery, tone, structure, and language—to interpret its deeper meanings, evaluate the author's craft, and construct an evidence-based argument about the work's significance.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student can independently deconstruct the poem "lk;s esa /wi" by identifying specific literary devices (irony, symbolism, repetition), explaining how they shape the poem's critique of power, and writing a structured analytical response using the PEEL (Point, Evidence, Explanation, Link) format with direct textual references.

## SCOPE_BOUNDARY
This node covers the critical analysis and interpretation of Nagarjun's poem "lk;s esa /wi" (Chapter 13), focusing on thematic depth, poetic devices, structural choices, and socio-political context. It does NOT cover creative writing based on the chapter (node 014) or speaking/listening activities (node 015).

## WALKTHROUGH
Imagine you are sitting in a dimly lit room during a power cut—the darkness feels heavy, but you know it's temporary. Now, read the poem's opening lines: the poet describes a darkness that isn't just absence of light, but a deliberate political condition. To begin analysis, don't ask "What does this mean?" Ask instead: "What is the poet *doing* with language here?" First, circle every word related to light/darkness and power/helplessness. Second, note the shift in tone from the first stanza's descriptive irony to the final stanza's direct address. Third, connect the repeated phrase "fpjkx" (which appears in contradictory contexts) to the poem's central paradox. The key insight: Nagarjun uses the *form* of the poem (repetition, irony, direct address) to mirror the *content* (the cyclical, inescapable nature of state oppression).

## DIAGNOSTIC_QUESTION_1
What is the primary function of the repetition of the word "fpjkx" (curfew/section 144) in the first stanza of "lk;s esa /wi"?

## DIAGNOSTIC_ANSWER_1
The repetition of "fpjkx" first in a general sense ("for homes") and then in a specific, ironic negation ("not for the city") establishes the poem's central irony: state power protects the powerful, not the common citizen. A wrong answer (e.g., "it shows the poet likes the word") reveals the student is treating repetition as mere decoration rather than a structural device that encodes meaning.

## DIAGNOSTIC_QUESTION_2
Explain in your own words why the poet describes the night as "lk;s esa /wi" (darkness in the lanes) rather than using a more standard phrase like "rat ka andhera" (darkness of the night).

## DIAGNOSTIC_ANSWER_2
"lk;s esa /wi" localizes the darkness to the narrow lanes where ordinary people live, making it intimate and inescapable, whereas "rat ka andhera" is a universal, natural phenomenon. The phrase implies the darkness is man-made (political) and confined to the marginalized. A wrong answer focusing only on "poetic beauty" misses the deliberate spatial politics of the imagery.

## DIAGNOSTIC_QUESTION_3
Apply the concept of "dramatic irony" to the second stanza ("u gks deh”k rks ik¡oksa ls isV <¡d ysaxs..."). Identify the gap between what the powerful believe and what the poem reveals.

## DIAGNOSTIC_ANSWER_3
The powerful ("fu”kke") believe their rule ("fly ns ”kqcku 'kk;j") is permanent and legitimate ("bl cgj osQ fy,A"). The poem reveals their legitimacy is a fragile performance ("gfr;kr") maintained by fear ("eqrebu") and the suppression of dissent ("iRFkj fi?ky ugha ldrk"). The irony: the more they assert permanence, the more they expose their insecurity. A wrong answer that only summarizes the stanza without naming the *gap* between appearance and reality shows inability to apply the term "dramatic irony" analytically.

## DIAGNOSTIC_QUESTION_4
Analyze how the poem's structure—moving from third-person observation (stanzas 1-2) to first-person declaration (stanza 3)—serves its political purpose.

## DIAGNOSTIC_ANSWER_4
The shift from "dgk¡ rks..." (impersonal) to "eSa csdjkj gw¡..." (personal) transforms the poem from a report on injustice to an act of resistance. The speaker refuses the role of passive observer ("vkil esa xw¡Fkdj") and claims agency ("vlj osQ fy,A"). This structural turn mirrors the poem's call for the marginalized to reject imposed silence. A wrong answer that only notes "the pronoun changes" without linking it to the theme of voice/agency fails to analyze structure as meaning.

## DIAGNOSTIC_QUESTION_5
Evaluate the claim: "Nagarjun's poem is merely a historical document about the 1975 Emergency; it has no relevance today." Defend your position using textual evidence.

## DIAGNOSTIC_ANSWER_5
The claim is false. While rooted in the Emergency (curfew, censorship, fear), the poem's core critique—state power using "security" to silence dissent, the complicity of those who "keep the lamp of the city burning" while lanes remain dark—is universal. The final stanza's "vlj osQ fy,A" (for effect/impact) addresses any era where performance replaces justice. A wrong answer agreeing with the claim reveals a "historical fallacy": confusing *setting* with *theme*, and ignoring the poem's deliberate timelessness (no specific dates in the text).

## DIAGNOSTIC_QUESTION_6
Write a four-line stanza in Hindi (or English) that uses *irony* and *repetition* to critique a modern form of "curfew" (e.g., digital shutdown, surveillance, algorithmic control), mimicking Nagarjun's technique in the first stanza.

## DIAGNOSTIC_ANSWER_6
Example: "dgk¡ rks r; Fkk dYiuk dk;Z dk fy, / dgk¡ dYiuk ugha 'kkjh osQ fy, / ;gk¡ dk;ZØe ds lk;s esa /wi yxrh gS / pyks ;gk¡ ls pysa vkSj 'kklu Hkj osQ fy," A strong answer adapts the *structure* (contrasting purpose vs. reality, spatial confinement, call to action) not just the vocabulary. A weak answer copies words without transferring the ironic logic to a new context.

## COMMON_MISCONCEPTION
Students often believe "critical analysis" means finding *one* hidden symbolic meaning (e.g., "the dark night = Emergency") and then stopping. They treat the poem as a riddle with a single answer. In reality, Nagarjun's poem operates through *layered tensions*: the tension between "fpjkx" as protection vs. oppression, between the "city's lamp" and the "lanes' darkness," between the ruler's "permanent rule" and the poet's "temporary voice." The error arises because school-level "comprehension" questions often reward single-answer retrieval, not multi-perspective analysis.

## ON_FAILURE
1. **Re-anchor to the text**: Ask the student to physically mark *three* specific words/phrases that create a tension (e.g., "fpjkx" vs "e;Llj ugha"; "fly" vs "gfr;kr"; "eqrebu" vs "vlj").
2. **Name the tension**: For each pair, have them complete the sentence: "On the surface X suggests ___, but the context reveals ___."
3. **Map to structure**: Draw a 3-box flow: Stanza 1 (Irony of Law) → Stanza 2 (Anatomy of Power) → Stanza 3 (Act of Resistance). Ask: "What changes in the *speaker's position* across these boxes?"
4. **Write one PEEL paragraph**: Using *one* tension, write a 4-sentence analysis: Point (the tension), Evidence (the two phrases), Explanation (how the tension works), Link (what this says about power).

## BUILDS_ON
This node builds on the literal comprehension (node 012) and identification of literary devices (nodes 008, 009) to synthesize an interpretive argument.

## LEADS_TO
This node enables the writing skills node (014) where students must produce a full analytical essay, and the speaking/listening node (015) where they defend interpretations in discussion.

## PREREQUISITE_NODE_IDS
c11_hin_ar_cbse_13_012, c11_hin_ar_cbse_13_008, c11_hin_ar_cbse_13_009, c11_hin_ar_cbse_13_006, c11_hin_ar_cbse_13_007, c11_hin_ar_cbse_13_001, c11_hin_ar_cbse_13_002, c11_hin_ar_cbse_13_004, c11_hin_ar_cbse_13_005, c11_hin_ar_cbse_13_010, c11_hin_ar_cbse_13_011

## PREREQUISITE_REASONS
c11_hin_ar_cbse_13_012: Literal and inferential comprehension provides the factual baseline (who, what, where) without which analysis has no evidence.
c11_hin_ar_cbse_13_008: Understanding imagery and metaphor is required to decode the "darkness/light" and "lane/city" central conceits.
c11_hin_ar_cbse_13_009: Irony and symbolism are the poem's primary operative devices; analysis is impossible without recognizing them.
c11_hin_ar_cbse_13_006: The primary theme (misuse of state power) is the anchor for all interpretive claims.
c11_hin_ar_cbse_13_007: Secondary themes (fear, complicity, resistance) provide the nuance needed for higher-order analysis.
c11_hin_ar_cbse_13_001: The historical context (Emergency, Nagarjun's activism) prevents ahistorical or purely aesthetic readings.
c11_hin_ar_cbse_13_002: In poetry, narrative structure refers to the organization of a poem's events, images, and... की समझ आवश्यक है, क्योंकि यह नोड (Critical thinking in literary analysis is the disciplined process of examining a text's co...) इसी आधार पर आगे बढ़ता है।  
c11_hin_ar_cbse_13_004: Critical interpretation requires a solid protagonist analysis as foundation for evaluating the poem's ideological stance.  
c11_hin_ar_cbse_13_005: Critical thinking requires synthesizing character analysis with structural analysis—e.g., how the three-stanza structure mirrors the three groups' distancing from the body.  
c11_hin_ar_cbse_13_010: Critical interpretation of themes like 'false consciousness' is built on precise understanding of words like 'eqrebu' and 'vlj'.  
c11_hin_ar_cbse_13_011: Critical interpretation requires citing syntactic choices (e.g., ellipsis as trauma marker) as textual proof.  

## FORWARD_NODE_IDS
c11_hin_ar_cbse_13_014, c11_hin_ar_cbse_13_015, c12_hin_al_cbse_02_013, c12_hin_ar_cbse_03_013, c12_hin_ar_cbse_13_013

## FORWARD_REASONS
c11_hin_ar_cbse_13_014: Writing an analytical essay requires the PEEL structure and evidence-selection skills practiced here.
c11_hin_ar_cbse_13_015: Discussion points demand the ability to articulate and defend an interpretation with textual support, not just opinion.
c12_hin_al_cbse_02_013: Practiced creative response from a non-human perspective.  
c12_hin_ar_cbse_03_013: अगला तार्किक चरण: Critical Thinking: इस नोड की अवधारणाओं को सीधे उपयोग/विस्तारित करता है।  
c12_hin_ar_cbse_13_013: Class 11 critical thinking foundation (same skill, lower complexity texts)  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS


## CHAIN_DESCRIPTION
c11_hin_ar_cbse_13_012 -> c11_hin_ar_cbse_13_013 -> c11_hin_ar_cbse_13_014

## THIS_FORMULA
PEEL Analysis Structure: **P**oint (Interpretive claim about device/theme) → **E**vidence (Specific line/word from poem) → **E**xplanation (How evidence proves point via literary mechanism) → **L**ink (Connect to poem's central argument about power/resistance).

## FORMULA_VARIABLES
P = Analytical claim (e.g., "The poet uses spatial contrast to expose class bias in state power")
E = Textual detail (e.g., "fpjkxk¡ gjsoQ ?kj osQ fy," vs "fpjkx e;Llj ugha 'kgj osQ fy,")
E = Literary reasoning (e.g., "The repetition with negation creates dramatic irony: the law's stated purpose (homes) is inverted by its actual target (city/power)")
L = Thematic synthesis (e.g., "This establishes the poem's thesis: legal structures serve the powerful, not the marginalized")

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
analytical

## CROSS_SUBJECT
c11_history_emergency_1975 | The poem functions as a literary primary source for the Emergency; analyzing its irony/symbolism deepens historical empathy beyond textbook facts.
c11_civics_authoritarianism | The poem illustrates the mechanism of "legal authoritarianism"—using constitutional provisions (curfew) to suspend rights—central to understanding democratic backsliding.

## PREREQ_CONCEPT
The student must understand that literary analysis is not "finding the right answer" but "building a case" using textual evidence and literary terminology.

## PREREQ_BEFORE
The student must be able to independently identify at least three instances of irony, symbolism, or imagery in the poem (from nodes 008, 009) and state the primary theme in their own words (from node 006).

## PREREQ_STUCK
If stuck, review the "Irony and Symbolism" node (c11_hin_ar_cbse_13_009) and re-read the poem marking every word that has a *double meaning* in context (e.g., "fpjkx", "fly", "gfr;kr", "vlj").

## WORKED_EXAMPLE_1
PROBLEM: Analyze how Nagarjun uses the contrast between "?kj" (home) and "'kgj" (city) in the first stanza to establish the poem's political critique.
STEPS:
- Step 1: Identify the two key spatial terms and their modifiers: "fpjkxk¡ gjsoQ ?kj osQ fy," (curfew for the sake of homes) vs "fpjkx e;Llj ugha 'kgj osQ fy," (curfew not for the sake of the city).
- Step 2: Define the connotations: "?kj" suggests private, domestic, vulnerable space of ordinary citizens; "'kgj" suggests public, political, institutional space of power.
- Step 3: Analyze the grammatical irony: The same word "fpjkx" (curfew/Section 144) is used in both lines, but the prepositional phrases "gjsoQ ?kj osQ fy," and "e;Llj ugha 'kgj osQ fy," flip the *purpose* clause. The law claims to protect homes but actually serves the city (power).
- Step 4: Connect to the stanza's next image: "nj[rksa osQ lk;s esa /wi yxrh gS" (darkness of curfew lies in the lanes). The "lanes" (lk;s) belong to the "?kj" world, not the "'kgj". The darkness falls where the law *claims* to protect.
- Step 5: Synthesize: The contrast exposes the hypocrisy of state rhetoric. The "curfew" is not a shield for the weak but a weapon for the strong. This sets up the poem's central argument: legal language masks political violence.
REASONING: This analysis moves from lexical choice (words) to syntactic structure (purpose clauses) to spatial politics (lanes vs city) to thematic thesis. Each step deepens the interpretive claim using textual evidence.
ANSWER: Nagarjun contrasts "?kj" (home) and "'kgj" (city) to reveal that the Emergency's legal apparatus (fpjkx) instrumentally claims to protect the private sphere while actually securing the public seat of power. The irony of the repeated "fpjkx" with opposing purpose clauses, combined with the image of darkness falling specifically in the "lk;s" (lanes/homes), proves the law's true function is the protection of the regime, not the citizen.

## WORKED_EXAMPLE_2
PROBLEM: Interpret the metaphor "rsjk fu”kke gS fly ns ”kqcku 'kk;j dh" (The ruler's command is to fly the kite of falsehood) in the final stanza. How does the kite metaphor encapsulate the nature of authoritarian propaganda?
STEPS:
- Step 1: Unpack the metaphor's components: "fu”kke" (ruler/state), "fly" (falsehood/lie), "ns”kqku 'kk;j" (kite string/manjha), "fu”kke" (command/order).
- Step 2: Analyze the action: "fly ns ”kqcku 'kk;j dh" – the ruler *orders* the flying of a kite made of lies. The kite is not spontaneous; it is a state-directed operation.
- Step 3: Analyze the object: A kite ("”kqcku") flies high, is visible to all, appears graceful/free, but is entirely controlled by a string held by the flyer. The "manjha" (glass-coated string) cuts other kites—it is aggressive.
- Step 4: Connect to "gfr;kr" (performance/drama): The next line calls this "gfr;kr”k:jh gS bl cgj osQ fy," (this is a grand performance for the world). The kite is a spectacle—propaganda as public theater.
- Step 5: Evaluate the metaphor's limits: A kite *must* come down; it depends on wind. The metaphor implicitly predicts the regime's fragility despite its high-flying appearance.
- Step 6: Link to speaker's response: "eSa csdjkj gw¡ vkok”k esa vlj osQ fy," (I shout in the gathering for effect). The speaker's "shout" is the counter-force—the wind that can cut the string or ground the kite.
REASONING: The metaphor works because it captures the *visibility*, *control*, *aggression*, and *inherent instability* of state propaganda in a single image. The analysis must show how each element of the metaphor maps to a political reality.
ANSWER: The kite metaphor encapsulates authoritarian propaganda as a state-orchestrated spectacle ("fu”kke gS... fu”kke") that appears elevated and free ("fly") but is wholly controlled by power ("ns”kqku 'kk;j"), designed to dominate the public sky ("cgj") and sever dissent (manjha), yet remains fundamentally fragile—dependent on favorable winds and a tether that can be cut. The poet's "shout" (vlj) represents the disruptive truth that grounds the performance.

## WORKED_EXAMPLE_3
PROBLEM: The poem's final line "vlj osQ fy," (for effect/impact) is ambiguous. Does it mean the poet speaks *to create an effect* or *because it is effective*? Analyze both readings and argue which is stronger based on the poem's trajectory.
STEPS:
- Step 1: Establish the grammatical ambiguity: "vlj" = effect/impact/result; "osQ fy," = for the sake of / because of. Reading A: "I shout *for the sake of creating an effect*" (purpose). Reading B: "I shout *because it has effect*" (causal confidence).
- Step 2: Test Reading A against stanza 3's opening: "gedks ekywe gS tUur dh gdhdr ysfdu" (We are accustomed to the depth of darkness, *but*). The "but" signals a break from passivity. "fny osQ [kq'k j[kus dks xkfyc ;s [k;ky vPNk gS" (to keep the lamp of the mind burning, this struggle is very difficult). The struggle is hard *because* the darkness is deep. Speaking is an act of defiance *against* the odds, not a guaranteed success.
- Step 3: Test Reading B against the poem's tone: The poem is pervaded by fear ("eqrebu"), suppression ("iRFkj fi?ky ugha ldrk"), and the ruler's apparent permanence ("fly ns ”kqcku 'kk;j"). If the poet *knew* it was effective, the tone would be triumphant, not desperate.
- Step 4: Examine the word "csdjkj" (shouting loudly/desperately). One shouts "csdjkj" when one is *not* being heard, when the "vlj" is uncertain. It is an attempt to *produce* an effect, not a celebration of one achieved.
- Step 5: Consider the "pkSFkk 'ksj" (last stanza) context from the textbook exercise: "tUur dh gdhdr" (depth of darkness) vs "[k;ky" (struggle). The struggle *is* the attempt to create "vlj" where none is visible.
- Step 6: Conclude: Reading A (purposive: shouting *to make* an impact) is stronger. It aligns with the poem's existential stance: action in the face of futility. "vlj osQ fy," = "in the hope of an effect," making the poem itself the "vlj"—the poem *is* the shout.
REASONING: This analysis demonstrates how to resolve ambiguity by testing readings against the whole textual environment (lexical, tonal, structural). It models the "evidence-based interpretation" required for board exams.
ANSWER: The reading "I shout *to create an effect* (purposive)" is stronger. The poem's trajectory moves from observed oppression (stanzas 1-2) to a difficult, desperate act of speech (stanza 3). The words "csdjkj" (desperate shout), "vPNk [k;ky" (very difficult struggle), and the contrast with "tUur dh gdhdr" (accustomed to darkness) all indicate the outcome is uncertain. The poet speaks *because* silence is complicity, not because victory is assured. The poem *enacts* the "vlj" it hopes for.

## COMPETENCY_QUESTION_1
QUESTION: A student writes: "Nagarjun uses the word 'fpjkx' twice in the first stanza to show that curfew was imposed everywhere." Explain why this answer would receive low marks in a Class 11 board exam, and rewrite it as a high-mark analytical statement using the PEEL structure.
COMPETENCY: Analytical writing / Exam answer formulation
STEPS:
- Step 1: Identify the flaw: The student's answer is a *literal observation* (repetition exists) + a *vague generalization* ("everywhere"). It misses the *contrast* (homes vs city), the *irony* (protection vs oppression), and the *function* (exposing state hypocrisy).
- Step 2: Draft the Point: "Nagarjun deploys the repetition of 'fpjkx' with opposing purpose clauses to enact a structural irony that exposes the class bias of Emergency rule."
- Step 3: Draft the Evidence: "The shift from 'fpjkxk¡ gjsoQ ?kj osQ fy,' to 'fpjkx e;Llj ugha 'kgj osQ fy,' in consecutive lines."
- Step 4: Draft the Explanation: "The identical legal term is grammatically bound to two contradictory beneficiaries—the vulnerable home and the powerful city—revealing that the law's stated intent is a mask for its actual function."
- Step 5: Draft the Link: "This opening irony establishes the poem's central thesis: state power uses the language of protection to engineer the darkness ('/wi') in the lanes of the poor."
ANSWER: The original answer fails because it treats repetition as a counting exercise rather than a meaning-making device. It ignores the *difference* between the two occurrences. High-mark rewrite: "Nagarjun deploys the repetition of 'fpjkx' with opposing purpose clauses to enact a structural irony that exposes the class bias of Emergency rule. The shift from 'fpjkxk¡ gjsoQ ?kj osQ fy,' to 'fpjkx e;Llj ugha 'kgj osQ fy,' in consecutive lines binds the identical legal term to two contradictory beneficiaries—the vulnerable home and the powerful city—revealing that the law's stated intent is a mask for its actual function. This opening irony establishes the poem's central thesis: state power uses the language of protection to engineer the darkness ('/wi') in the lanes of the poor."
DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: "The poem 'lk;s esa /wi' is not about the Emergency; it is about the *language* of the Emergency." Evaluate this statement. In your answer, analyze at least two specific linguistic strategies (e.g., irony, metaphor, pronoun shift, repetition, imperative mood) and explain how they transform a historical event into a universal critique of power.
COMPETENCY: Critical evaluation / Synthesis of form and content
STEPS:
- Step 1: Take a clear position: The statement is largely accurate. The poem uses the Emergency as *occasion*, not *subject*. Its target is the *rhetorical machinery* of authoritarianism.
- Step 2: Analyze Strategy 1 - Irony/Repetition (Stanza 1): The "fpjkx" repetition shows how legal language is hollowed out—words mean their opposite. This is a universal mechanism: "security" becomes "repression" in any era.
- Step 3: Analyze Strategy 2 - Metaphor of the Kite (Stanza 3): "fly ns ”kqcku 'kk;j" transforms propaganda into a controlled spectacle. The metaphor *is* the analysis: it shows *how* lies fly (state support, glass string, public sky). This works for any regime's media manipulation.
- Step 4: Analyze Strategy 3 - Pronoun Shift (Stanza 1-2 vs 3): The move from impersonal "dgk¡ rks" to "eSa csdjkj gw¡" enacts the birth of the resisting subject. This is the poem's argument: resistance begins when language is reclaimed from the state.
- Step 5: Synthesize: These strategies make the poem *about* language because they *perform* the critique through form. The poem doesn't just describe the Emergency's lies; it shows *how lies work linguistically* (irony, metaphor, pronoun politics).
- Step 6: Conclude: The historical reference grounds the poem, but the linguistic architecture makes it a permanent tool for diagnosing power.
ANSWER: The statement is compelling. Nagarjun uses the Emergency not as a topic to describe, but as a laboratory to dissect the *linguistic architecture of authoritarianism*. Three strategies universalize the critique: (1) **Semantic Inversion via Repetition**: The double use of "fpjkx" with contradictory purpose clauses ("?kj osQ fy," / "e;Llj ugha 'kgj osQ fy,") exposes how state discourse weaponizes legal terminology—making "protection" mean "suppression." This mechanism operates in any security state. (2) **The Kite Metaphor as Propaganda Theory**: "fu”kke gS fly ns ”kqcku 'kk;j dh" doesn't just describe lies; it models them—state-sponsored (fu”kke), spectacular (fly), aggressive (manjha), fragile (wind-dependent). This is a structural analysis of disinformation applicable to modern media. (3) **Pronoun Shift as Political Subjectivation**: The shift from third-person observation ("dgk¡ rks") to first-person intervention ("eSa csdjkj gw¡") enacts the poem's core argument: resistance is a *speech act*. The poem becomes the very "vlj" (impact) it seeks. Thus, the poem *is* an analysis of the Emergency's language, making it a permanent diagnostic tool for any "darkness in the lanes."
DIFFICULTY: hard