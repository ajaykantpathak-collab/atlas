## DEFINITION
Critical thinking in literary analysis refers to the disciplined process of examining a text beyond its surface meaning — identifying underlying themes, evaluating the effectiveness of literary devices, interpreting symbolic language, and forming evidence-based judgments about the poet's intent and the work's broader significance. For फकीर's poems, this involves analyzing how Braj Bhasha vocabulary, Bhakti-era philosophical concepts, and poetic structures like *doha* and *chappay* convey Nirguna Bhakti ideals.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student can independently analyze any of फकीर's three poems in Chapter 8 by: (1) identifying at least two literary devices with textual evidence, (2) explaining how the poet's language choices reflect Nirguna Bhakti philosophy, and (3) constructing a coherent interpretation that connects the poem's imagery to its spiritual message, all while writing in structured Hindi with appropriate terminology.

## SCOPE_BOUNDARY
This node covers deep analysis and interpretation of the three poems by फकीर in Chapter 8 (Antra). It assumes prior completion of literal comprehension (node 012), literary devices (nodes 008, 009), and theme identification (nodes 006, 007). It does NOT cover basic vocabulary meanings, grammar rules, or writing formal answers — those are addressed in nodes 010, 011, and 014 respectively.

## WALKTHROUGH
Imagine you're reading फकीर's second poem (*lf[k gs] fd iqNfl vuqHko eks,A...*) and feel the words describe a storm, yet something tells you it's not really about weather. Start by reading the poem aloud — notice the rhythm of *fry fry uwru gks* mimicking thunder. Next, mark every word that could have a double meaning: *eèkqj cksy* (dark clouds / worldly illusions), *vuqjkx* (lightning / divine revelation). Then, recall the Bhakti context from node 001: फकीर was a Nirguna saint who rejected rituals. Ask: *How does the storm imagery critique ritualistic worship?* Finally, connect the last line (*fo|kifr dg izku tqM+kbrs yk[ks u ehyy ,dA*) — the poet says only one who endures this inner storm attains truth. The key insight: the poem maps an external natural phenomenon to an internal spiritual journey.

## DIAGNOSTIC_QUESTION_1
फकीर की पहली कविता (*osQ ifrvk y, tk,r js eksjk fivre iklA*) में 'लकवसु एकल' का शाब्दिक अर्थ क्या है? यह शब्द किस छंद शैली में प्रयुक्त हुआ है?

## DIAGNOSTIC_ANSWER_1
शाब्दिक अर्थ: 'लकवसु' = लोक (संसार) का, 'एकल' = एकमात्र/अकेला। अर्थात् 'संसार का एकमात्र आधार'। यह शब्द दोहा छंद में प्रयुक्त हुआ है (मात्रिक छंद: 13+11 मात्राएँ)। गलत उत्तर (जैसे 'लकवसु' को 'लकड़ी का' समझना) दर्शाता है कि छात्र ब्रजभाषा के शब्द-भंडार और दोहा छंद की पहचान नहीं कर पाया।

## DIAGNOSTIC_QUESTION_2
दूसरी कविता में 'फ्रजफर' (frjfir) शब्द का प्रयोग कवि ने क्यों किया है? अपने शब्दों में समझाएँ कि यह शब्द निर्गुण भक्ति की किस अवधारणा को व्यक्त करता है।

## DIAGNOSTIC_ANSWER_2
'फ्रजफर' का अर्थ है 'स्थिर/पूर्ण/साकार रूप में प्रकट'। निर्गुण भक्ति में ईश्वर निराकार है, पर भक्त की अंतर्दृष्टि से वह 'फ्रजफर' (स्पष्टतः अनुभव करने योग्य) हो जाता है। कवि कहता है: 'ट्यू वीफक गे :ि फुगक्जय उ;ु उ फ्रजफर ह्सय' — अर्थात् तूफान (माया/संसार) में भी जो ईश्वर को निराकार रूप में नहीं, बल्कि फ्रजफर (साक्षात्) अनुभव करता है, वही सच्चा भक्त है। गलत उत्तर (जैसे 'फ्रजफर' का अर्थ 'प्रसन्न' बताना) दर्शाता है कि छात्र शब्दार्थ तो जानता है पर निर्गुण भक्ति के 'साक्षात्कार' दर्शन को नहीं समझा।

## DIAGNOSTIC_QUESTION_3
तीसरी कविता (*oqQlqfer dkuu gsfj deyeqf[k]*) में 'देयक' (deyeq[k]) शब्द का प्रयोग करते हुए कवि ने किस सामाजिक विषमता पर प्रहार किया है? पाठ से साक्ष्य देकर समझाएँ।

## DIAGNOSTIC_ANSWER_3
'देयक' = 'देने योग्य/दान लेने वाला' (भिखारी/निम्न जाति)। कवि लिखता है: 'दकसफदी&द्यजो] एकक्दज&ेकफु लकफु' — अर्थात् दान देने वाला (ऊँची जाति) और दान लेने वाला (नीची जाति) दोनों बराबर हैं। फकीर जाति-आधारित दान-प्रथा को नकारते हुए कहता है कि ईश्वर के सामने सब 'देयक' (लेने-देने वाले) मात्र हैं। छात्र यदि केवल 'देयक' का अर्थ 'दाता' लिखे, तो वह कवि के सामाजिक क्रांतिकारी तेवर को चूक जाता है।

## DIAGNOSTIC_QUESTION_4
तीनों कविताओं में 'ईककक्ज' (eèkqiqj) शब्द की पुनरावृत्ति का तुलनात्मक विश्लेषण करें। प्रत्येक कविता में यह शब्द किस भिन्न भाव को व्यक्त करता है?

## DIAGNOSTIC_ANSWER_4
पहली कविता: 'एककक्ज क्ल जस दु वितल यस्य' — यहाँ 'ईककक्ज' = 'परम आनंद/मोक्ष का धाम' (लक्ष्य)। दूसरी कविता: 'लसगकस एककक्ज क्सय लज़ोफग लुयु लज़कफर इफक इजल उ क्सय' — यहाँ 'ईककक्ज' = 'सांसारिक माया/कष्टों का स्रोत' (बाधा)। तीसरी कविता: 'एककदक] लककु&लककु क्पुफु वफकफु एककुज&एककुज इजसे रकसगकजक' — यहाँ 'ईककक्ज' = 'ईश्वरीय कृपा/दिव्य प्रकाश' (साधन)। गलत विश्लेषण (सभी जगह एक ही अर्थ) दर्शाता है कि छात्र संदर्भ-आधारित व्याख्या नहीं कर पाता।

## DIAGNOSTIC_QUESTION_5
क्या फकीर की कविताओं को केवल 'धार्मिक उपदेश' मानना उचित है? उनके काव्य में निहित सामाजिक-राजनीतिक चेतना के प्रमाण देते हुए अपना मत स्पष्ट करें।

## DIAGNOSTIC_ANSWER_5
नहीं, केवल धार्मिक उपदेश मानना अपूर्ण होगा। प्रमाण: (1) पहली कविता में 'हकौन फ्लच¯लग उज&इफर' — तत्कालीन सुल्तान/शासक की आलोचना। (2) दूसरी कविता में 'दर एककक्-त्कफेफु जेकल एकवकसफी उ क्व>य दब्लु उसकफी' — शासकीय अत्याचार (कर वसूली) का चित्रण। (3) तीसरी कविता में जाति-व्यवस्था पर सीधा प्रहार ('दकसफदी&द्यजो')। फकीर भक्ति को सामाजिक मुक्ति का साधन बनाते हैं। जो छात्र इसे केवल 'भक्ति काव्य' कहे, वह कवि के 'संत परंपरा के विद्रोही स्वर' को नजरअंदाज करता है।

## DIAGNOSTIC_QUESTION_6
फकीर की शैली में एक नया दोहा (13+11 मात्राएँ) रचें जो 'निर्गुण भक्ति में गुरु की भूमिका' पर केंद्रित हो। ब्रजभाषा के कम से कम दो विशिष्ट शब्द प्रयोग करें।

## DIAGNOSTIC_ANSWER_6
उदाहरण:  
'गुरु बिनु ज्ञान न होइ, भटके जीव संसार।  
एककक्ज पंथ देखावे, तारै भव पार॥'  
मात्रा गणना: गुरु(2) बि(1) नु(1) जा(2) न(1) हो(1) इ(1) = 9? (असंगत) — छात्र को मात्रिक छंद की समझ नहीं।  
सही प्रयास:  
'गुरु बिनु ज्ञान न उपजै, भटकत फिरै संसार।  
एककक्ज पंथ देखावत, तारै भव पार॥'  
(मात्राएँ जाँचना आवश्यक)। ब्रज शब्द: 'उपजै', 'भटकत', 'पंथ'। खराब उत्तर: खड़ीबोली में लिखना या मात्रा दोष — दर्शाता है कि छात्र फकीर की छंद-शैली और ब्रजभाषा के सौंदर्य को नहीं समझा।

## COMMON_MISCONCEPTION
Students treat critical analysis as **line-by-line translation** or **summary**. They write: "पहली कविता में कवि कहता है कि संसार एक झूठा खेल है..." and stop there. They miss that फकीर uses *storm* (second poem) as an extended metaphor for *Maya*, that *eèkqiqj* shifts meaning across poems, and that the poet's Nirguna stance is a **social revolt** against caste and ritual. This error occurs because they rely on Hindi paraphrase (भावार्थ) instead of analyzing *how* language creates meaning — a habit from earlier classes where 'explanation' meant translation.

## ON_FAILURE
1. **Revisit node 012 (Comprehension):** Re-read each poem with the *word-meaning list* (node 010) open. Write literal translation of **every line** in your notebook.  
2. **Revisit nodes 008 & 009 (Literary Devices):** For each poem, make a 3-column table: *Device | Line/Word | Effect*. Example: *Metaphor | "eèkqj cksy" (dark clouds) | Represents worldly illusions that block divine vision.*  
3. **Re-diagnostic:** Attempt Diagnostic Question 4 again. If you cannot explain the three distinct meanings of *eèkqiqj* with evidence, repeat step 2 for that specific word across all three poems.

## BUILDS_ON
Comprehension: Literal and Inferential Questions (c12_hin_a_cbse_08_012) — because analysis requires a solid base of what the text *says* before exploring what it *means*.

## LEADS_TO
Writing Skills: Based on the Chapter (c12_hin_a_cbse_08_014) — because structured analytical answers (PEEL format) are the written expression of critical thinking.

## PREREQUISITE_NODE_IDS
c12_hin_a_cbse_08_012, c12_hin_a_cbse_08_008, c12_hin_a_cbse_08_009, c12_hin_a_cbse_08_006, c12_hin_a_cbse_08_007, c11_hin_ar_cbse_08_013, c11_hin_ar_cbse_01_013, c12_hin_a_cbse_08_001, c12_hin_a_cbse_08_004, c12_hin_a_cbse_08_005, c12_hin_a_cbse_08_010, c12_hin_a_cbse_08_011

## PREREQUISITE_REASONS
c12_hin_a_cbse_08_012: Provides literal/inferential understanding of all three poems — essential raw material for analysis.  
c12_hin_a_cbse_08_008: Supplies imagery/metaphor identification skills (e.g., storm as Maya).  
c12_hin_a_cbse_08_009: Supplies irony/symbolism identification (e.g., *eèkqiqj* as both goal and obstacle).  
c12_hin_a_cbse_08_006: Establishes primary theme (Nirguna Bhakti) as interpretive lens.  
c12_hin_a_cbse_08_007: Provides secondary themes (social equality, anti-ritualism) for multi-layered reading.  
c11_hin_ar_cbse_08_013: Class 11 critical thinking foundation — same skill applied to simpler texts.  
c11_hin_ar_cbse_01_013: Earliest exposure to analysis framework (context, device, theme, interpretation).
c12_hin_a_cbse_08_001: Critical thinking demands linking text to context.  
c12_hin_a_cbse_08_004: Critical interpretation (e.g., "Is this protagonist feminist? feudal? modern?") needs a rigorously established baseline character.  
c12_hin_a_cbse_08_005: Critical interpretation requires evaluating how supporting figures shape meaning.  
c12_hin_a_cbse_08_010: Critical thinking needs nuanced vocabulary to support interpretations.  
c12_hin_a_cbse_08_011: Language Usage in the Text refers to the systematic analysis of grammatical structures, li... की समझ आवश्यक है, क्योंकि यह नोड (Critical thinking in literary analysis refers to the disciplined process of examining a te...) इसी आधार पर आगे बढ़ता है।  

## FORWARD_NODE_IDS
c12_hin_a_cbse_08_014, c12_hin_a_cbse_08_015
## FORWARD_REASONS
c12_hin_a_cbse_08_014: Analytical insights become the *content* of structured answers (PEEL paragraphs) in writing tasks.  
c12_hin_a_cbse_08_015: Interpretive judgments fuel discussion points (e.g., "Is फकीर more a poet or a social reformer?").

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
No cross-subject prior nodes available in the provided list.

## CHAIN_DESCRIPTION
c12_hin_a_cbse_08_012 -> c12_hin_a_cbse_08_013 -> c12_hin_a_cbse_08_014

## THIS_FORMULA
N/A - conceptual (Analysis Framework: Context → Language → Device → Theme → Interpretation)

## FORMULA_VARIABLES
N/A

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
analytical

## CROSS_SUBJECT
N/A | फकीर की रचनाएँ भक्ति आंदोलन की निर्गुण शाखा (कबीर, रैदास, दादू) की प्रतिनिधि हैं; इतिहास में मध्यकालीन भारत के सामाजिक-धार्मिक सुधार आंदोलनों को समझने के लिए इनका विश्लेषण आवश्यक है।  
 N/A | कविताओं में ग्रामीण परिवेश (बादल, बिजली, खेत, जाति-आधारित व्यवसाय) का चित्रण सांस्कृतिक भूगोल की 'मानव-पर्यावरण अंतःक्रिया' और 'लोक सांस्कृतिक क्षेत्र' अवधारणाओं से जुड़ता है।
## PREREQ_CONCEPT
Ability to move from *what the poem says* (literal) to *how it says it* (devices) to *why it matters* (theme/philosophy).

## PREREQ_BEFORE
Student must have read all three poems, understood the word-meanings (node 010), identified at least two devices per poem (nodes 008, 009), and stated the primary theme in one sentence (node 006).

## PREREQ_STUCK
If stuck, review **node 012 (Comprehension)** for poem-level understanding and **nodes 008/009 (Literary Devices)** for device identification — these are the building blocks of analysis.

## WORKED_EXAMPLE_1
PROBLEM: Analyze how फकीर uses the *storm* imagery in the second poem (*lf[k gs] fd iqNfl vuqHko eks,A...*) to depict the spiritual seeker's inner struggle. Write a structured analytical paragraph (PEEL format).

STEPS:
- Step 1: Identify the central image — the violent storm (*vuqHko*, *fry fry uwru gks*) — and note it occupies the first 6 lines.
- Step 2: List the storm's components with double meanings: *eèkqj cksy* (dark clouds = ignorance/maya), *vuqjkx* (lightning = momentary divine glimpse), *lzqfr* (downpour = grace/knowledge), *fcnxèk* (thunder = guru's voice/shabda).
- Step 3: Connect each to Nirguna Bhakti philosophy using node 006: The seeker (*ge :i*) must not seek shelter (*u;u u frjfir Hksy*) in rituals but endure the storm to attain *frjfir* (firm realization).
- Step 4: Explain the progression: fear (*fugkjy*) → endurance (*lsgks eèkqj cksy... u xsy*) → breakthrough (*fo|kifr dg izku tqM+kbrs yk[ks u ehyy ,d*).
- Step 5: Conclude: The storm is not an obstacle but the *necessary path* — a classic Nirguna metaphor where suffering purifies.

REASONING: This follows the Analysis Framework: the image (Language) is decoded via devices (Metaphor, Symbolism) to reveal the theme (Nirguna path) and yield an interpretation (storm as grace).

ANSWER:  
**Point:** फकीर दूसरी कविता में तूफान को केवल प्राकृतिक घटना नहीं, बल्कि साधक की आंतरिक साधना का प्रतीक बनाते हैं।  
**Evidence:** 'लसग फिफजर वुक्जेक्स ककफफुव फ्रय फ्रय उव्रु गक्स' — बिजली की चमक (दिव्य झलक) और मूसलाधार वर्षा (कृपा/ज्ञान) दोनों तूफान के अंग हैं।  
**Explanation:** कवि कहता है 'ट्यू वीफक गे :ि फुगक्जय उ;ु उ फ्रजफर ह्सय' — जो तूफान से नहीं डरता, वही ईश्वर को साक्षात् (फ्रजफर) पाता है। 'फ्रजफर' निर्गुण का साकार अनुभव है।  
**Link:** इस प्रकार तूफान बाधा नहीं, मोक्ष का मार्ग है — फकीर की निर्गुण भक्ति का केंद्रीय संदेश।

## WORKED_EXAMPLE_2
PROBLEM: Compare the portrayal of *social hierarchy* in the first poem (*osQ ifrvk y, tk,r js eksjk fivre iklA*) and the third poem (*oqQlqfer dkuu gsfj deyeqf[k]*). How does फकीर subvert the traditional varna order in both?

STEPS:
- Step 1: Locate hierarchy markers in Poem 1: *xksoqQy* (king/ruler), *eèkqiqj* (capital/centre of power), *fiz;re* (minister) — all fleeing. The poet (a low-caste saint) remains (*eu Hkkou*).
- Step 2: Locate hierarchy markers in Poem 3: *dksfdy&dyjo* (donor = high caste), *eèkqdj&èkqfu* (receiver = low caste), *deyeq[k* (beggar/outcaste) — explicitly equated: *lqfu* (equal).
- Step 3: Identify the subversion technique: In Poem 1, political power collapses before spiritual truth (*fiz;re* flees, poet stays). In Poem 3, ritual hierarchy (dana-pratigraha) is declared false (*u;u xj, ty&èkkjk* — caste distinctions are illusions).
- Step 4: Link to फकीर's biography (node 001): He was a weaver (जुलाहा) challenging both Sultanate authority and Brahminical ritualism.
- Step 5: Synthesize: Both poems use *inversion* — the lowly becomes the true knower, the powerful becomes the fugitive.

REASONING: Comparison requires extracting parallel structures (political vs. ritual hierarchy) and showing how the same philosophical stance (Nirguna equality) operates in different domains.

ANSWER:  
पहली कविता में राजनीतिक सत्ता (*xksoqQy*, *eèkqiqj*) भय से भागती है, जबकि संत (*fiz;re*) स्थिर रहता है — सत्ता की आध्यात्मिक हीनता दर्शाता है। तीसरी कविता में धार्मिक सत्ता (*dksfdy&dyjo*, दान-प्रथा) को झूठा घोषित कर *deyeq[k* (नीची जाति) को *lqfu* (बराबर) बताया जाता है। दोनों में फकीर 'उलटबाँसी' शैली में वर्चस्व को उलट देते हैं: जो नीचे है (संत, अछूत) वही सत्य का अधिकारी है। यह निर्गुण भक्ति का सामाजिक क्रांतिकारी स्वरूप है।

## WORKED_EXAMPLE_3
PROBLEM: A board exam question asks: "फकीर की कविताओं में 'ईककक्ज' (eèkqiqj) शब्द की बहुआयामी व्यंजना स्पष्ट कीजिए।" Write a 100-word answer integrating all three poems.

STEPS:
- Step 1: Define *eèkqiqj* literally: 'capital city' (Poem 1), 'dark cloud region' (Poem 2), 'divine abode/grace' (Poem 3).
- Step 2: For Poem 1, explain: *xksoqQy rsft eèkqiqj cl js du vitl ysy* — political centre abandoned by king; *eèkqiqj* = worldly power centre, ultimately empty.
- Step 3: For Poem 2, explain: *lsgks eèkqj cksy lzoufg lwuy lzqfr iFk ijl u xsy* — *eèkqj cksy* (dark clouds) block the path; *eèkqiqj* here = Maya's dense region, the obstacle.
- Step 4: For Poem 3, explain: *rqv xqu lqanfj vfr Hksy nwcfjµ xqfu&xqfu izse rksgkjk* — *eèkqiqj* implied in *rksgkjk* (divine play/light); *eèkqiqj* = God's luminous realm, the goal.
- Step 5: Synthesize: The word travels from *political* → *psychological* → *spiritual* plane, mirroring the seeker's journey from external to internal.
- Step 6: Draft answer in Hindi using terms: *बहुआयामी व्यंजना*, *राजनैतिक*, *मानसिक*, *आध्यात्मिक*, *निर्गुण साधना*।

REASONING: Board exams demand precise, multi-textual evidence. This example trains the student to track a single motif across poems — a high-order skill for 5-mark questions.

ANSWER:  
फकीर 'ईककक्ज' को तीन धरातलों पर प्रयुक्त करते हैं: (1) प्रथम पद में 'एककक्ज' = राजधानी/सत्ता केंद्र (*एककक्ज क्ल जस दु वितल यस्य*), जो क्षणभंगुर है। (2) द्वितीय पद में 'एककक्ज क्सय' = माया का घन अंधकार (*लसगकस एककक्ज क्सय लज़ोफग...*), जो साधक को भ्रमित करता है। (3) तृतीय पद में निहित 'रकसगकजक' (ईश्वरीय लीला/प्रकाश) में 'एककक्ज' = परम धाम/कृपा का स्रोत। यह शब्द-यात्रा साधक की बाह्य सत्ता से आंतरिक ज्योति तक की यात्रा को प्रतिबिंबित करती है — निर्गुण भक्ति की केंद्रीय प्रक्रिया।

## COMPETENCY_QUESTION_1
QUESTION: फकीर की पहली कविता में 'हकौन फ्लच¯लग उज&इफर' (हकूमत फकीर उजागर) पंक्ति के आधार पर बताएँ कि कवि सुल्तान/शासक की तुलना में अपनी स्थिति को कैसे श्रेष्ठ सिद्ध करता है? अपने उत्तर में 'विडंबना' (irony) और 'प्रतीक' (symbol) का प्रयोग अवश्य करें।

COMPETENCY: Literary Analysis with Terminology Application

STEPS:
- Step 1: Identify the irony — the Sultan (symbol of worldly power) flees in fear, while the fakir (symbol of spiritual power) remains unmoved.
- Step 2: Explain the symbol: *xksoqQy* (king) = temporal authority; *fiz;re* (minister/poet) = spiritual authority.
- Step 3: Connect to Nirguna theme: True power lies in *eu Hkkou* (winning the heart/self-mastery), not *jkT;dky* (kingdom).
- Step 4: Write a 4-sentence answer using the terms 'विडंबना' and 'प्रतीक' correctly.

ANSWER:  
इस पंक्ति में **विडंबना** यह है कि सुल्तान (*xksoqQy*), जो **प्रतीक** है सांसारिक शक्ति का, भय से भाग जाता है (*rsft eèkqiqj cl js*), जबकि फकीर (*fiz;re*), जो **प्रतीक** है आध्यात्मिक शक्ति का, अडिग रहता है (*eu Hkkou*)। कवि व्यंग्यपूर्वक दिखाता है कि राजसत्ता (*jkT;dky*) मृत्यु/भय के सामने असहाय है, पर संत की सत्ता (*dhfrZyrk*) अमर है। यह निर्गुण भक्ति का कथन है: असली 'हकूमत' आत्मा पर विजय पाने में है, प्रदेश पर नहीं।

DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: फकीर की तीनों कविताओं को पढ़कर यह कथन मूल्यांकन करें: "फकीर का काव्य केवल ईश्वर-भक्ति नहीं, अपितु मध्यकालीन भारतीय समाज की विसंगतियों पर एक तीखा सामाजिक दस्तावेज़ भी है।" अपने उत्तर में तीनों कविताओं से कम से कम एक-एक प्रमाण दें।

COMPETENCY: Critical Evaluation with Multi-Textual Evidence

STEPS:
- Step 1: Deconstruct the statement into two claims: (A) God-devotion, (B) Social document of medieval anomalies.
- Step 2: For Poem 1, find evidence of political anomaly: *xksoqQy* fleeing shows Sultanate instability; poet's fearlessness shows alternative authority.
- Step 3: For Poem 2, find evidence of religious anomaly: *dr eèkq&tkfefu jHkl xekvksfy u cw>y dblu osQfy* — rulers extracting taxes (jizya?) while claiming piety; poet rejects ritual shelter (*u;u u frjfir Hksy*).
- Step 4: For Poem 3, find evidence of caste anomaly: *dksfdy&dyjo] eèkqdj&èkqfu lqfu* — explicit rejection of varna-based dana system.
- Step 5: Synthesize: The poems collectively document political tyranny, religious hypocrisy, and caste oppression — all challenged by Nirguna equality.
- Step 6: Write a structured evaluation (120 words) with clear stance and evidence.

ANSWER:  
कथन पूर्णतः सत्य है। फकीर भक्ति को सामाजिक मुक्ति का साधन बनाते हैं।  
**प्रमाण 1 (राजनीतिक):** प्रथम पद में *xksoqQy rsft eèkqiqj cl js* — सुल्तान राजधानी छोड़ भागता है, पर संत (*fiz;re*) कहता है *eu Hkkou* — सत्ता का नैतिक पतन उजागर।  
**प्रमाण 2 (धार्मिक):** द्वितीय पद में *dr eèkq&tkfefu jHkl xekvksfy u cw>y dblu osQfy* — शासक कर वसूलते हैं (जजिया?), पर संत रीतिगत शरण (*u;u u frjfir Hksy*) ठुकराता है — धार्मिक पाखंड पर प्रहार।  
**प्रमाण 3 (सामाजिक):** तृतीय पद में *dksfdy&dyjo] eèkqdj&èkqfu lqfu* — दाता (ब्राह्मण) और भोक्ता (शूद्र) को बराबर घोषित कर वर्ण-व्यवस्था को चुनौती।  
अतः फकीर का काव्य मध्यकालीन विसंगतियों (निरंकुश सत्ता, पाखंड, जातिभेद) का जीवंत दस्तावेज़ है, जहाँ भक्ति = प्रतिरोध है।

DIFFICULTY: hard