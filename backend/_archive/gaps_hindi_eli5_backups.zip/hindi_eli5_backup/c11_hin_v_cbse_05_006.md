## DEFINITION
The primary theme is the central, unifying idea or insight about life and human experience that the author conveys through the narrative elements (plot, character, setting, conflict). The message is the author's specific perspective or commentary on that theme, often implicit, which the reader infers by synthesizing how the protagonist's journey resolves.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student must independently identify the primary theme of "jktLFkku dh jtr cw¡nas", trace its development across at least three key plot points with textual evidence, and articulate the author's message about power and vulnerability in a structured PEEL paragraph suitable for a 5-mark board answer.

## SCOPE_BOUNDARY
This node covers ONLY the identification and analysis of the single, overarching primary theme (the dehumanizing nature of systemic power and the resilience of the marginalized) and its core message. It does NOT cover secondary themes (poverty, migration, family duty) which are addressed in node c11_hin_v_cbse_05_007, nor does it cover literary devices used to convey the theme (nodes 008, 009).

## WALKTHROUGH
Imagine you are watching a news report about a street vendor's cart being overturned by municipal officers — you instantly sense the injustice of raw power crushing the helpless. That visceral reaction is your entry point to this story's theme. Begin by asking: "Whose story is this, and what is the *one* universal truth about power the author forces us to witness through Gopal's eyes?" First, list the three most devastating moments where authority (the landlord, the contractor, the city system) crushes Gopal's dignity. Second, note Gopal's internal response each time — does he break, or does he endure? Third, examine the ending: does the system change, or does Gopal's survival *become* the resistance? The key insight: the primary theme is not "poverty is hard" (that's a topic); the theme is "institutional power systematically dehumanizes the poor, yet their silent endurance constitutes a profound, unacknowledged victory."

## DIAGNOSTIC_QUESTION_1
Define 'primary theme' in prose fiction and distinguish it from 'subject' or 'topic' using a one-sentence example from any Class 10 text.

## DIAGNOSTIC_ANSWER_1
**Correct Answer:** The primary theme is the central insight about the human condition (e.g., "Unchecked authority corrupts absolutely"), whereas the subject is the surface topic (e.g., "British colonialism in India"). In "The Letter" (Class 10), the subject is an old man waiting for a letter; the theme is "the agony of separation transcends time and logic."  
**Wrong Answer Reveals:** If a student writes "The theme is the struggle of a watchman," they confuse plot summary with thematic abstraction. They cannot generalize from specific events to universal human truth — a critical Board exam failure.

## DIAGNOSTIC_QUESTION_2
The title "jktLFkku dh jtr cw¡nas" (The Prickly Bushes of Power) is a metaphor. Explain what the 'prickly bushes' and 'power' represent *specifically* in Gopal's life, and why the metaphor is more effective than a literal title like "Gopal's Hard Life."

## DIAGNOSTIC_ANSWER_2
**Correct Answer:** The 'prickly bushes' represent the invisible, thorny barriers of systemic exploitation — the landlord's debt trap, the contractor's wage theft, the city's indifference — that tear at Gopal's dignity daily. 'Power' is not just the government; it is the *network* of local authorities who wield control over his survival. The metaphor works because bushes entangle you the more you struggle; Gopal's honest labor only deepens his entrapment. A literal title states the *effect*; the metaphor reveals the *mechanism*.  
**Wrong Answer Reveals:** If a student says "Bushes mean difficulties, power means government," they miss the *systemic, entangling* nature of the oppression. They treat the metaphor as decoration, not structural analysis.

## DIAGNOSTIC_QUESTION_3
Apply the 'Theme Tracking' method: Select THREE sequential plot points from the story (e.g., Village debt → Migration to Delhi → Watchman job) and write ONE analytical sentence for each showing how *that specific event* advances the primary theme of "systemic dehumanization."

## DIAGNOSTIC_ANSWER_3
**Correct Answer (Sample Steps):**
1. Village: "The landlord's manipulation of Gopal's illiteracy to seize his land establishes that power operates through *legalized fraud*, stripping agency before he even reaches the city."
2. Migration: "The contractor's theft of wages during the journey proves that *mobility offers no escape* — the predatory structure follows the migrant."
3. Delhi: "As a watchman guarding a building he can never enter, Gopal embodies the *ultimate irony*: his labor protects the very power that excludes him."  
**Wrong Answer Reveals:** If a student writes "He lost land, then money, then got a job," they narrate plot. They fail to connect each event to the *theme's mechanism* (fraud, portability of oppression, structural irony).

## DIAGNOSTIC_QUESTION_4
Analyze the ending: Gopal continues as a watchman, silent and enduring. Does this ending reinforce a message of *hopeless resignation* or *quiet resistance*? Defend your interpretation using Gopal's internal monologue and the symbolism of the 'prickly bushes' in the final paragraphs.

## DIAGNOSTIC_ANSWER_4
**Correct Answer:** It is **quiet resistance**. The text shows Gopal's internal monologue: he calculates his children's future, not his past losses. He *chooses* to stay, to work, to educate his children — refusing to become the 'thorn' that hurts others. The 'prickly bushes' remain, but he learns to navigate them without bleeding. The message: *Dignity is preserved not by destroying the system (impossible), but by refusing to let the system define your humanity.*  
**Wrong Answer Reveals:** If a student says "He gives up / nothing changes," they read passively. They miss the *agency* in endurance — a senior-secondary analytical skill. Board examiners reward the distinction between *passive suffering* and *active survival*.

## DIAGNOSTIC_QUESTION_5
Evaluate this student claim: "The primary theme is 'Poverty destroys families.' The message is 'Education is the only way out.'" Judge the validity of this claim against the text's treatment of Gopal's children and the structural causes of his poverty.

## DIAGNOSTIC_ANSWER_5
**Correct Answer:** **Invalid.** The claim reduces a *systemic critique* to an *individual moral lesson*. The text shows Gopal's poverty stems from *landlord fraud* and *contractor exploitation* — structural violence, not personal failure. His children's education is his *hope*, but the text offers no guarantee it will "free" them from the same bushes. The author's message targets the *system*, not the victim's lack of education.  
**Wrong Answer Reveals:** If a student agrees, they impose a middle-class meritocracy bias on a text about structural inequality. They cannot separate *author's intent* from *reader's prejudice* — fatal for "Critical Thinking" questions (node 013).

## DIAGNOSTIC_QUESTION_6
Create a 4-line poetic stanza or a 50-word micro-fiction piece from the perspective of the 'prickly bushes' themselves, voicing the primary theme: the perspective of Power watching the powerless endure.

## DIAGNOSTIC_ANSWER_6
**Criteria for Good Answer:**
- Voice: Arrogant, patient, systemic ("I am the law / the debt / the locked gate").
- Theme: Power *expects* breakage; is unsettled by endurance.
- Imagery: Thorns, blood, roots, silence.
- **Sample:** "I drink the sweat of a thousand Gopals / My thorns are laws written in ink they cannot read / Yet each dawn he rises, unbroken / My roots tremble — *he has learned to walk between my thorns*."  
**Poor Answer Reveals:** If the piece sympathizes with Gopal ("Oh, poor man, I hurt you"), the student fails to *inhabit the theme's antagonist*. They cannot separate authorial stance from character perspective — essential for "Irony and Symbolism" (node 009).

## COMMON_MISCONCEPTION
**Students equate 'Theme' with 'Moral of the Story' (e.g., "Hard work pays off" or "Be honest").** They search for a prescriptive lesson *for the character* rather than a descriptive truth *about the world*. In this story, they see Gopal's endurance and conclude "Message: Never give up." This is wrong because: (1) The author critiques the *system that forces endurance*, not praises endurance itself. (2) Gopal has *no choice* but to endure — calling it a 'moral' blames victims who *do* break. (3) Board exams ask "What does the author *reveal* about power?" not "What should Gopal do?" This misconception stems from middle-school fable-based teaching where themes are explicit morals.

## ON_FAILURE
1. **Confront the Moral Trap:** Give the student two statements: A) "Never give up." B) "Systems of power survive by grinding down the poor." Ask: "Which one *explains the story's existence*? Which one could be a poster on a wall?" The story *is* the evidence for B.
2. **Re-read the Ending with a Lens:** Provide the final 3 paragraphs. Ask: "Highlight every word showing Gopal's *choice* vs. every word showing the *system's pressure*." Count them. Discuss: "If the theme was 'never give up', why does the author spend 80% of the text describing the bushes, not Gopal's will?"
3. **Connect to Node 004 (Protagonist):** Review Gopal's characterization — is he *heroic* or *trapped*? The text emphasizes his *helplessness* (illiteracy, debt, migration). A 'moral' requires agency; the theme exposes the *absence* of agency.
4. **Practice Abstraction Ladder:** Topic → "Watchman's life" → Theme → "Institutional power dehumanizes" → Message → "Endurance is the only dignity left." Drill this ladder until automatic.

## BUILDS_ON
Node c11_hin_v_cbse_05_002 (Plot and Narrative Structure) — you cannot analyze theme without mapping the causal chain of events that constitute the 'argument' of the story.

## LEADS_TO
Node c11_hin_v_cbse_05_007 (Theme: Secondary Themes) — once the primary thematic spine is fixed, secondary themes (migration, fatherhood, literacy) can be mapped as branches.

## PREREQUISITE_NODE_IDS
c11_hin_v_cbse_05_002, c11_hin_v_cbse_05_004, c11_hin_v_cbse_05_005, c11_hin_v_cbse_05_001

## PREREQUISITE_REASONS
c11_hin_v_cbse_05_002: Plot provides the sequence of systemic oppressions (landlord → contractor → city) that *build* the theme cumulatively.
c11_hin_v_cbse_05_004: Gopal's characterization (illiterate, dignified, father) is the *lens* through which the theme is experienced; his internal monologue *is* the thematic evidence.
c11_hin_v_cbse_05_005: Supporting characters (landlord, contractor, wife, children) function as *embodiments* of Power and Vulnerability; analyzing them reveals the theme's dramatization.
c11_hin_v_cbse_05_001: Themes like 'swabhiman' and 'lok-maryada' are contextual constructs; this node provides the semantic field for thematic interpretation.  

## FORWARD_NODE_IDS
c11_hin_v_cbse_05_007, c11_hin_v_cbse_05_008, c11_hin_v_cbse_05_009, c11_hin_v_cbse_05_013, c11_hin_v_cbse_05_010, c11_hin_v_cbse_05_012, c11_hin_v_cbse_05_014, c11_hin_v_cbse_05_015, c12_hin_a_cbse_05_006

## FORWARD_REASONS
c11_hin_v_cbse_05_007: Secondary themes (poverty, migration) are *subsets* of the primary theme; they cannot be analyzed independently without the primary framework.
c11_hin_v_cbse_05_008: Imagery (thorns, dust, locked gates) and metaphor *encode* the primary theme; analysis requires the theme as decoder.
c11_hin_v_cbse_05_009: Irony (watchman guarding power) and symbolism (bushes) *enact* the theme; identifying them depends on knowing *what* they symbolize.
c11_hin_v_cbse_05_013: Critical interpretation *is* thematic argumentation; this node provides the central claim for all analytical essays.
c11_hin_v_cbse_05_010: Theme: Primary Theme and Message establishes the central conflict (power vs. powerless, development vs. destruction) that dictates the semantic direction of key terms.  
c11_hin_v_cbse_05_012: Primary theme awareness guides thematic inferences — the 'big picture' that connects scattered details.  
c11_hin_v_cbse_05_014: Primary theme (exploitation vs dignity) is the central thesis for most long-answer questions.  
c11_hin_v_cbse_05_015: Primary theme (heritage erosion) is the central argument scaffold  
c12_hin_a_cbse_05_006: Class 11 Vitan Theme node — reinforces the skill across textbooks, ensuring transfer.  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
none

## CHAIN_DESCRIPTION
c11_hin_v_cbse_05_002 -> c11_hin_v_cbse_05_006 -> c11_hin_v_cbse_05_007 (Plot establishes the events; Primary Theme abstracts their meaning; Secondary Themes branch from the core).

## THIS_FORMULA
N/A - conceptual

## FORMULA_VARIABLES
N/A

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
analytical

## CROSS_SUBJECT
c11_civics_democracy_rights | The story illustrates how *absence of legal literacy and bureaucratic accountability* (Civics: Rule of Law, Rights of Marginalized) enables the 'prickly bushes' of power to operate unchecked — Gopal's illiteracy makes him invisible to the Constitution's protections.
c11_economics_poverty_inequality | The narrative maps *structural poverty* (Economics: Vicious cycle of debt, informal labor exploitation, rural-urban wage gap) not as individual failure but as systemic extraction — the landlord and contractor are economic agents of the 'bushes'.

## PREREQ_CONCEPT
Understanding that 'Theme = Author's Argument about the World' (not character's lesson) — derived from Class 10 prose analysis (e.g., "The Letter", "A Shady Plot") but deepened for systemic critique.

## PREREQ_BEFORE
Student must be able to distinguish *Plot Event* (what happens) from *Thematic Significance* (what it proves about the world) — practiced in Node 002.

## PREREQ_STUCK
Review "Plot-to-Theme Ladder" exercise from Node 002: Take 3 plot points, write "This shows that..." sentences, then generalize to a universal statement.

## WORKED_EXAMPLE_1
PROBLEM: A student writes this theme statement for a 3-mark question: "The theme of the story is the difficult life of a watchman named Gopal who moves from village to city." Diagnose the error and rewrite it into a Board-standard primary theme statement using the Abstraction Ladder.

STEPS:
- Step 1: Identify the error — the student has written a *plot summary* (specific character + specific events) not a *theme* (universal insight). It fails the "So what?" test.
- Step 2: Apply Abstraction Ladder Level 1 (Topic): "Struggle of a migrant worker in the city."
- Step 3: Apply Level 2 (Pattern): "The system exploits the migrant's vulnerability at every stage — village, journey, city."
- Step 4: Apply Level 3 (Universal Insight/Theme): "Institutional power structures systematically dehumanize the marginalized, rendering their labor invisible and their dignity conditional."
- Step 5: Formulate the Message (Author's Stance): "Yet, the marginalized reclaim agency through silent endurance and intergenerational hope, exposing the system's moral bankruptcy."
- Step 6: Combine into Board Answer: "The primary theme is the systemic dehumanization of the poor by entrenched power structures. The message: true resistance lies not in overthrowing the system (impossible for the powerless) but in preserving human dignity through quiet perseverance and securing the next generation's future."

REASONING: The Abstraction Ladder forces movement from *particular* (Gopal) → *pattern* (migrant experience) → *universal* (power vs. vulnerability). Board examiners award full marks only for Level 3+ statements. The message *must* include the author's perspective on the theme, not just the theme itself.

ANSWER: **Corrected Theme Statement:** "The story exposes how institutional power (landlord, contractor, urban system) operates as 'prickly bushes' that entangle and dehumanize the marginalized. The author's message: dignity survives not through rebellion but through the quiet, generational endurance of those the system discards."

## WORKED_EXAMPLE_2
PROBLEM: Using the 'Theme Tracking Table' method, trace the primary theme across THREE key scenes: (1) Landlord seizing land, (2) Contractor stealing wages en route, (3) Gopal as watchman guarding a luxury building. Fill the table with: Scene | Power's Action | Gopal's Response | Thematic Revelation.

STEPS:
- Step 1: Recall/Re-read the three scenes (from Nodes 002, 004). Focus on *agency*: who acts, who suffers, who witnesses.
- Step 2: Scene 1 (Village): Power's Action = Legal fraud using illiteracy. Gopal's Response = Helpless acceptance (no courts, no voice). Thematic Revelation = Power *writes the rules* to legitimize theft.
- Step 3: Scene 2 (Migration): Power's Action = Contractor's brute force + wage theft. Gopal's Response = Protects family first, swallows injustice. Thematic Revelation = Power is *portable* — follows the victim; family is the only shield.
- Step 4: Scene 3 (Delhi): Power's Action = Employment as watchman — guarding wealth he cannot touch. Gopal's Response = Silent dedication, plans children's education. Thematic Revelation = Power *needs* the poor to sustain itself; the poor's endurance *sustains* the poor.
- Step 5: Synthesize: The progression shows Power evolving from *active predator* (landlord) → *parasitic intermediary* (contractor) → *structural architecture* (city). Gopal evolves from *victim* → *protector* → *strategist*. The theme deepens from "exploitation exists" to "exploitation is the system's operating logic."

REASONING: A table forces separation of *plot mechanics* (column 2,3) from *thematic meaning* (column 4). This mirrors the Board's "Analyze how the author develops the theme" question pattern. The progression (predator → parasite → structure) is the analytical gold standard.

ANSWER: **Completed Table:**
| Scene | Power's Action | Gopal's Response | Thematic Revelation |
|-------|----------------|------------------|---------------------|
| 1. Landlord seizes land | Manipulates records, uses law as weapon | Silent surrender; no recourse | Power *legitimizes* theft through institutional fraud |
| 2. Contractor steals wages | Physical threats, withholds earned money | Shields family, absorbs loss | Power is *mobile* and *inescapable*; family = only agency |
| 3. Watchman at luxury building | Employs him to guard exclusion | Works honestly, educates children | Power *depends* on the poor; endurance = generational investment |

## WORKED_EXAMPLE_3
PROBLEM: A Board-style 6-mark question: "The title 'jktLFkku dh jtr cw¡nas' is not just a metaphor but the *thesis statement* of the story. Analyze how the narrative structure (plot, character, ending) proves this thesis." Write a structured response using PEEL (Point, Evidence, Explanation, Link) for three body paragraphs.

STEPS:
- Step 1: Deconstruct the prompt — Thesis = "Power = Prickly Bushes (entangling, invisible, painful, unavoidable)." Need 3 proof points: Plot structure, Character arc, Ending.
- Step 2: Para 1 (Plot Structure): Point = The *circular* plot (village → city → same trap) mimics bushes' entanglement. Evidence = Landlord's debt trap → Contractor's trap → Watchman's trap. Explanation = Each move *promises* escape but *delivers* deeper entanglement; the structure *enacts* the metaphor. Link = The plot *is* the bushes closing in.
- Step 3: Para 2 (Character - Gopal): Point = Gopal's body bears the 'thorns' — illiteracy, calloused hands, silence. Evidence = He cannot read land papers; he carries loads; he speaks only to his children. Explanation = The bushes don't just surround him; they *constitute* his identity. His silence is not weakness — it's the sound of thorns tearing flesh. Link = Character *embodies* the thesis.
- Step 4: Para 3 (Ending): Point = The open ending (he stays a watchman) proves the bushes are *perennial*, not seasonal. Evidence = Final image: he watches the city sleep, children's books in bag. Explanation = No magical rescue; the bushes remain. But his *navigation* (educating children) is the *only* way through. The thesis holds: bushes exist, but the *path* is human. Link = Ending confirms the metaphor's permanence and the only possible resistance.
- Step 5: Conclusion: Synthesize — Title = Thesis because every structural choice (circular plot, silent protagonist, unresolved ending) *proves* power is an entangling, inescapable, yet navigable thicket.
- Step 6: Check PEEL compliance — each para has Point (theme claim), Evidence (textual detail), Explanation (analytical link), Link (back to thesis).

REASONING: This models the *exact* structure expected for 6-mark "Analyze/Evaluate" questions in Board exams. The thesis-driven approach (Title = Thesis) is a high-order heuristic: it forces the student to read *every element* as evidence for the central metaphor. The circular plot analysis is the specific "senior secondary" insight — middle school sees "beginning-middle-end"; Class 11 sees "structure as argument."

ANSWER: **Model Response Outline:**
**Intro:** The title operates as the story's thesis: power is not a hammer (blunt, visible) but a thicket (entangling, invisible, drawing blood the more you struggle). The narrative architecture — plot, character, ending — systematically proves this.
**Body 1 (Plot):** The circular trajectory (village debt → migration trap → urban servitude) mirrors the bushes' logic: every struggle to escape tightens the hold. The landlord's legal trap, the contractor's physical trap, the city's economic trap — each 'clearing' reveals deeper thorns.
**Body 2 (Character):** Gopal's illiteracy, migratory body, and watchman's uniform are the thorns *internalized*. His silence is the rustle of leaves — the only sound the bushes allow. Yet his fatherhood (children's education) is the *machete* he forges *inside* the thicket.
**Body 3 (Ending):** No exit. The final frame — watchman, night, books — confirms the bushes are the *permanent ecology*. But the books signify: the next generation may *map* the thicket. The thesis stands: Power = Prickly Bushes. Resistance = Learning to walk between thorns.
**Conclusion:** The story doesn't just *use* the metaphor; it *becomes* the metaphor.

## COMPETENCY_QUESTION_1
QUESTION: "The primary theme of 'jktLFkku dh jtr cw¡nas' is often misidentified as 'The hardships of migrant labor.' Using the distinction between *Topic* and *Theme*, and referencing the *title's metaphor*, explain why this misidentification fails to capture the author's central argument about the *nature of power*."

COMPETENCY: Conceptual Understanding & Critical Differentiation (Topic vs. Theme; Metaphor as Thesis)

STEPS:
- Step 1: Define the misidentification: "Hardships of migrant labor" is a *topic* (subject matter), observable and descriptive.
- Step 2: Define the actual theme: An *abstract insight* into the *mechanism* of power — it is systemic, entangling, and dehumanizing by design (the 'prickly bushes').
- Step 3: Use the title metaphor: "Hardships" = the *scratches*; "Prickly bushes" = the *structure that inflicts scratches inevitably*. The topic describes the *victim's experience*; the theme exposes the *perpetrator's architecture*.
- Step 4: Cite structural proof: The story spends equal time on the *landlord* (rural power), *contractor* (transit power), *city system* (urban power) — not just Gopal's suffering. The theme is *Power's anatomy*; the topic is *Gopal's biography*.
- Step 5: Conclude: Misidentifying topic as theme reduces a systemic critique to an individual tragedy, letting the 'bushes' (the system) off the hook.

ANSWER: The statement "hardships of migrant labor" is a **topic** — the *what* of the story. The **primary theme** is the *why* and *how*: "Institutional power operates as an entangling, inescapable thicket ('prickly bushes') that systematically dehumanizes the marginalized by design, not accident." The metaphor proves this: bushes are not 'hardships' (effects); they are the *active, structural cause* — thorny, interconnected, regrowing. The narrative structure (three distinct power centers: landlord, contractor, city) confirms the theme is about *Power's systemic nature*, not the migrant's suffering. Confusing topic for theme obscures the author's indictment of the *system*.

DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: "Critically evaluate the claim: 'Gopal's acceptance of his watchman job proves the story's message is that the poor must compromise with corruption to survive.' In your evaluation, contrast *compromise* (active negotiation of values) with *endurance* (structural navigation without moral surrender), using Gopal's internal monologue and the 'prickly bushes' symbolism."

COMPETENCY: Analytical Evaluation & Nuanced Interpretation (Resistance vs. Resignation; Symbolism as Evidence)

STEPS:
- Step 1: Unpack the claim's binary: It assumes only two options — *rebel* (impossible) or *compromise* (moral corruption). It ignores a third: *endurance with integrity*.
- Step 2: Define 'Compromise' in this context: Actively participating in corruption (e.g., Gopal becoming a corrupt contractor, bribing officials, stealing from the building he guards). The text shows he does *none* of these.
- Step 3: Define 'Endurance' using text: Gopal works *honestly* as a watchman (protects the property), refuses to let the system make him a predator (he doesn't exploit others), and channels his agency into *children's education* — a generational attack on the bushes' root (illiteracy).
- Step 4: Use 'Prickly Bushes' symbolism: Compromise = becoming a thorn yourself. Endurance = learning to walk *between* thorns without becoming one. The bushes remain; the *path* is the victory.
- Step 5: Internal monologue evidence: His thoughts focus on *children's future*, not *his comfort* or *revenge*. This is strategic endurance, not moral compromise.
- Step 6: Verdict: The claim is **reductive and false**. It projects middle-class anxiety onto a structural narrative. The message: *Dignity is the refusal to let the bushes turn you into a bush.*

ANSWER: The claim is **invalid**. It conflates **structural endurance** (navigating an inescapable system while preserving core values) with **moral compromise** (actively adopting the system's corrupt logic). Evidence against compromise: (1) Gopal performs his watchman duties *honestly* — he does not pilfer, collude, or exploit. (2) His internal monologue reveals *zero* rationalization of the system; he sees it clearly as "jtr cw¡nas." (3) His agency is directed *outward* — educating children to *read the land papers* he couldn't — a direct strike at the bushes' root (illiteracy). The 'prickly bushes' metaphor settles this: Compromise = growing thorns. Endurance = bleeding but still walking, clearing a path for the next feet. The author's message: **The system forces you into the bushes; your humanity is measured by whether you become a thorn or a path.**

DIFFICULTY: hard