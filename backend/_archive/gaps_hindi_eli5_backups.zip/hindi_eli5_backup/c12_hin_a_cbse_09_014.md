## DEFINITION
Writing Skills based on Chapter 9 (कुकुआन) refers to the ability to compose structured, evidence-based answers for poetry analysis questions — including theme interpretation, literary device identification, character/persona analysis, and comparative evaluation — using the PEEL (Point, Evidence, Explanation, Link) framework aligned with CBSE marking schemes.

## COGNITIVE_LEVEL
apply

## MASTERY_CRITERIA
The student can independently write a 150-200 word analytical answer for any poem-based question from this chapter using the PEEL structure: stating a clear point, quoting/paraphrasing specific lines as evidence, explaining the poetic effect, and linking back to the central theme of separation (वियोग) and devotion (भक्ति).

## SCOPE_BOUNDARY
This node covers writing analytical answers for the two dohas of कुकुआन in Chapter 9 — focusing on theme (virah/bhakti), imagery (nature as metaphor), tone, and vocabulary. It does NOT cover creative writing, letter writing, or essay writing formats from the broader writing skills syllabus.

## WALKTHROUGH
Imagine you're sitting in the board exam and see this question: "कुकुआन के दोहों में विरह-वेदना को प्रकृति के माध्यम से कैसे व्यक्त किया गया है? उदाहरण सहित समझाइए।" Your mind goes blank — you know the poem but don't know how to START the answer. First, read the question twice and underline keywords: "विरह-वेदना" (theme), "प्रकृति के माध्यम से" (method), "उदाहरण सहित" (evidence required). Next, recall the two dohas: the first uses monsoon imagery (clouds, rain, peacocks) to contrast nature's joy with the separated soul's pain; the second uses the night/dawn cycle to show endless waiting. Now structure: Point 1 — Nature mirrors inner turmoil (quote line 1-2). Evidence — "कजरि कजरि बरसत..." Explanation — Rain brings joy to peacocks but intensifies separation. Link — This contrast heightens virah. Point 2 — Time stretches in separation (quote line 5-6). Evidence — "बहु बेरि बिताई..." Explanation — Night feels endless without beloved. Link — Shows bhakti as patient endurance. Key insight: Every answer must OPEN with the theme, USE textual evidence, and CLOSE by connecting device to meaning.

## DIAGNOSTIC_QUESTION_1
What is the PEEL structure for writing literature answers, and what does each letter stand for in the context of poetry analysis?

## DIAGNOSTIC_ANSWER_1
PEEL stands for Point (main argument about the poem), Evidence (specific line/word from the text), Explanation (how the evidence creates meaning/effect), Link (connect back to theme/question). A wrong answer like "Point, Example, Explain, Conclusion" reveals the student memorizes acronyms without understanding the literary analysis purpose — "Link" specifically demands thematic connection, not just summary.

## DIAGNOSTIC_QUESTION_2
A student writes: "कुकुआन के पहले दोहे में बादल बरसते हैं और मोर नाचते हैं जिससे विरहिणी को दुःख होता है।" Identify TWO specific weaknesses in this answer relative to CBSE marking expectations.

## DIAGNOSTIC_ANSWER_2
Weakness 1: No direct textual evidence — the answer paraphrases generally instead of quoting "कजरि कजरि बरसत..." or "मोर नाचत...". Weakness 2: No analysis of POETIC DEVICE — it states WHAT happens but not HOW the imagery works (contrast, personification, sensory detail). A correct answer would name the device (विरोधाभास/contrast) and explain its emotional effect.

## DIAGNOSTIC_QUESTION_3
Apply the PEEL structure to answer: "दूसरे दोहे में 'रात' और 'सुबह' के चक्र का क्या महत्व है?" Write a complete 4-sentence PEEL paragraph.

## DIAGNOSTIC_ANSWER_3
Point: The night-dawn cycle symbolizes the endless waiting in virah. Evidence: "बहु बेरि बिताई रैन..." and "प्रभात भई..." show repeated nights passing. Explanation: Each "बहु बेरि" (many times) emphasizes duration; dawn brings no relief ("दुख न भागा"), making time itself an antagonist. Link: This temporal imagery reinforces bhakti as patient endurance — the devotee's wait mirrors the eternal night of separation. A wrong answer would merely translate lines without analyzing "बहु बेरि" as repetition device.

## DIAGNOSTIC_QUESTION_4
Compare how the FIRST doha uses AUDITORY imagery (sound) versus the SECOND doha using VISUAL imagery (sight). Which creates a stronger sense of virah? Analyze with evidence.

## DIAGNOSTIC_ANSWER_4
First doha: Auditory — "कजरि कजरि" (onomatopoeic rain sound), "मोर नाचत" implies peacock calls — sound amplifies the world's celebration, making silence of separation louder. Second doha: Visual — "रैन" (darkness), "प्रभात" (light), "नैन" (eyes) — sight emphasizes watching/waiting. Stronger: Auditory in first doha — sound is inescapable (rain falls everywhere), creating involuntary contrast; visual in second is voluntary (she watches), showing agency in devotion. Wrong answer: "Both are equal" — misses that auditory imagery creates IMMEDIATE sensory clash, while visual shows CHOSEN endurance.

## DIAGNOSTIC_QUESTION_5
Evaluate this student claim: "कुकुआन की भाषा सरल ब्रजभाषा है इसलिए उनके दोहे समझने में आसान हैं।" Defend or refute using specific vocabulary from the text.

## DIAGNOSTIC_ANSWER_5
Refute. The claim confuses "सरल" (simple) with "लोकप्रचलित" (colloquial). Text shows: "कजरि" (onomatopoeia), "विरह" (technical bhakti term), "बहु बेरि" (archaic multiplier), "नैन" (poetic eye), "प्रभात" (Sanskritized dawn). These require glossary support (as NCERT provides). The language is ACCESSIBLE but not SIMPLE — it uses precise poetic vocabulary (तत्सम/तद्भव mix) for emotional density. Wrong answer: "Yes it's simple" — reveals student equates familiar words with simple meaning, missing how कुकुआन compresses complex virah philosophy into deceptively plain words.

## DIAGNOSTIC_QUESTION_6
Create a new 2-line doha in Braj Bhasha style that uses NATURE IMAGERY to express VIRAH, following कुकुआन's pattern of contrast. Explain your device choices.

## DIAGNOSTIC_ANSWER_6
Example: "बसंत आयो वन फूले, कोयल बोले मधुर स्वर / विरहिन के अंग लगै शीत, जलत तन अंतर भीतर" — Device 1: Seasonal contrast (spring joy vs inner cold) like कुकुआन's monsoon. Device 2: Sound imagery (koel's sweet song) intensifying silence. Device 3: Internal/external body contrast ("अंग" vs "अंतर"). Good answer shows deliberate imitation of कुकुआन's structure: nature observation → personal application → philosophical link. Poor answer: generic sad lines without contrast or device awareness.

## COMMON_MISCONCEPTION
Students believe "writing skills for poetry" means memorizing model answers for each question. They write: "कुकुआन भक्ति कवि हैं। उनके दोहे विरह पर हैं।" — This is CONTENT recall, not WRITING SKILL. The real error: They don't treat the answer as an ARGUMENT that must be built line-by-line. They quote lines but don't EXPLAIN the poetic effect (e.g., writing "कजरि कजरि बरसत" without saying "onomatopoeia mimics relentless rain"). CBSE marks the EXPLANATION, not the quotation. This misconception persists because Class 10-11 accepted descriptive answers; Class 12 demands analytical writing.

## ON_FAILURE
Step 1: Have the student pick ONE 3-mark question from the chapter's exercise (e.g., Q4 on poetic features). Step 2: Together, highlight the 3 key words in the question (e.g., "काव्यगत विशेषताएँ" = imagery, language, emotion). Step 3: For each key word, find ONE line from the dohas — write it verbatim. Step 4: For each line, complete this sentence starter: "This line uses [device] to show [effect] which connects to [theme] because..." Step 5: Assemble into PEEL paragraphs. Re-diagnostic: Give a new unseen 3-mark question; student must produce PEEL outline in 5 minutes.

## BUILDS_ON
Class 11 Writing Skills (c11_hin_ar_cbse_01_014) where students learned basic answer structuring for prose; this node advances to poetry-specific analytical writing with device-to-meaning explanation.

## LEADS_TO
c12_hin_a_cbse_09_015 (Speaking and Listening) where students orally defend their written interpretations using the same evidence-analysis framework.

## PREREQUISITE_NODE_IDS
c12_hin_a_cbse_09_002, c12_hin_a_cbse_09_006, c12_hin_a_cbse_09_008, c12_hin_a_cbse_09_009, c12_hin_a_cbse_09_010, c12_hin_a_cbse_09_011, c12_hin_a_cbse_09_012, c12_hin_a_cbse_09_013, c11_hin_ar_cbse_01_014
## PREREQUISITE_REASONS
c12_hin_a_cbse_09_002: Plot/narrative structure of the dohas provides the sequence for evidence selection
c12_hin_a_cbse_09_006: Primary theme (virah-bhakti) is the mandatory Link in every PEEL paragraph
c12_hin_a_cbse_09_008: Imagery/metaphor analysis supplies the Explanation step content
c12_hin_a_cbse_09_009: Irony/symbolism knowledge enables deeper device identification
c12_hin_a_cbse_09_010: Vocabulary meanings ensure accurate Evidence quotation and interpretation
c12_hin_a_cbse_09_011: Grammar/usage helps parse archaic Braj forms for correct Evidence
c12_hin_a_cbse_09_012: Literal/inferential comprehension separates surface meaning from analytical Point
c12_hin_a_cbse_09_013: Critical thinking provides the evaluative lens for Link statements
c11_hin_ar_cbse_01_014: Class 11 writing skills foundation — basic answer structure upgraded to poetry analysis

## FORWARD_NODE_IDS
c12_hin_a_cbse_09_015
## FORWARD_REASONS
c12_hin_a_cbse_09_015: Speaking/Listening requires students to orally present and defend the same written analyses — this node provides the written scaffold for oral articulation

## CROSS_SUBJECT_PREREQS
c11_hin_ar_cbse_01_014, c11_hin_ar_cbse_02_014
## CROSS_SUBJECT_REASONS
c11_hin_ar_cbse_01_014: Writing skills from Class 11 Antra Chapter 1 (कबीर) established PEEL for bhakti poetry — कुकुआन extends this tradition
c11_hin_ar_cbse_02_014: Class 11 Chapter 2 (मीरा) writing skills modeled virah-bhakti answer structure — direct thematic predecessor

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_01_014 -> c12_hin_a_cbse_09_014 -> c12_hin_a_cbse_09_015

## THIS_FORMULA
PEEL Paragraph = Point (theme-linked claim) + Evidence (verbatim line/phrase) + Explanation (device → effect analysis) + Link (back to question's core theme)

## FORMULA_VARIABLES
Point: One-sentence analytical claim answering the specific question | Evidence: Exact textual reference (line number or quoted phrase) | Explanation: 2-3 sentences naming poetic device and explaining its emotional/intellectual effect | Link: Closing sentence connecting this paragraph's analysis to the poem's central theme (virah/bhakti)

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
linguistic

## CROSS_SUBJECT
N/A | The virah-bhakti theme in कुकुआन mirrors the historical Bhakti movement's emphasis on personal devotion over ritual — answer writing must reflect this socio-religious context
 N/A | The first doha's monsoon imagery (कजरि, मोर) draws on North Indian monsoon geography — understanding seasonal patterns deepens imagery analysis
## PREREQ_CONCEPT
PEEL answer structure for literature analysis, specifically adapted for poetry where Evidence = quoted lines and Explanation = poetic device analysis.

## PREREQ_BEFORE
Student must have completed all chapter nodes 001-013 (content mastery) and Class 11 writing skills (structural foundation).

## PREREQ_STUCK
If stuck on Explanation step: Revisit c12_hin_a_cbse_09_008 (Imagery/Metaphor) and 009 (Irony/Symbolism) — list every device in both dohas with effect notes before attempting PEEL.

## WORKED_EXAMPLE_1
PROBLEM: Write a PEEL paragraph answering: "कुकुआन के पहले दोहे में 'कजरि कजरि' पद की आवृत्ति का काव्यात्मक प्रभाव क्या है?" (3 marks)

STEPS:
- Step 1: Identify question demand — "काव्यात्मक प्रभाव" (poetic effect) means analyze device + emotion, not just meaning. Key word: "आवृत्ति" (repetition).
- Step 2: Locate evidence — First doha, opening: "कजरि कजरि बरसत..." The word "कजरि" repeats twice consecutively.
- Step 3: Name the device — अनुप्रास (alliteration) + आवृत्ति (repetition) + ध्वन्यात्मक अनुकरण (onomatopoeia). "कजरि" mimics heavy raindrop sound.
- Step 4: Explain effect — Repetition creates rhythmic insistence: rain won't stop. Onomatopoeia makes reader HEAR the downpour. This auditory immersion contrasts with the विरहिणी's silent inner drought.
- Step 5: Link to theme — The relentless sound externalizes her internal restlessness; nature's abundance (rain) mocks her emptiness (virah). This contrast IS the virah experience.

REASONING: The PEEL structure forces the student to move from identification (what device) to analysis (how it works) to synthesis (why it matters for theme). Each step builds the previous — without device naming, explanation is vague; without theme link, analysis is isolated.

ANSWER:
Point: "कजरि कजरि" की आवृत्ति अनुप्रास और ध्वन्यात्मक अनुकरण द्वारा वर्षा की अनवरत ध्वनि का सजीव चित्रण करती है।
Evidence: पहले दोहे का आरंभिक पद — "कजरि कजरि बरसत..."।
Explanation: "कजरि" की द्विवार आवृत्ति (आवृत्ति अलंकार) और 'ज-र' ध्वनियों की अनुप्रास वर्षा की झड़ी की लय और तीव्रता को श्रव्य बनाती है। यह श्रव्य बिम्ब (auditory imagery) विरहिणी की आंतरिक नीरवता और सूनेपन से तीव्र विरोधाभास (contrast) उत्पन्न करता है — प्रकृति उल्लास से भरी है, अंतःकरण विरह से रीता।
Link: इस प्रकार ध्वनि-चित्रण विरह-वेदना को केवल बताता नहीं, पाठक को अनुभव कराता है — कुकुआन की काव्यगत विशेषता।

## WORKED_EXAMPLE_2
PROBLEM: Improve this weak 4-mark answer: "दोनों दोहों में विरह का वर्णन है। पहले में बादल और मोर हैं, दूसरे में रात और सुबह। कुकुआन सरल भाषा में गहरी बात कहते हैं।" Make it CBSE-standard using PEEL.

STEPS:
- Step 1: Diagnose weaknesses — No PEEL structure, no textual evidence, no device analysis, generic "सरल भाषा" claim, no comparative framework.
- Step 2: Create comparative Points — Point 1: Nature as mirror (Doha 1). Point 2: Time as antagonist (Doha 2). Point 3: Language precision (both).
- Step 3: Assign Evidence per Point — P1: "कजरि कजरि बरसत..." / "मोर नाचत...". P2: "बहु बेरि बिताई रैन..." / "प्रभात भई...". P3: "विरह", "नैन", "प्रभात" (तत्सम density).
- Step 4: Draft Explanations — P1: Contrast device (विरोधाभास) — nature's joy vs human sorrow. P2: Repetition (आवृत्ति) — "बहु बेरि" stretches time; dawn brings no relief. P3: Vocabulary analysis — not "simple" but "संकेतात्मक" (suggestive).
- Step 5: Write Links — Each paragraph closes with "इस प्रकार कुकुआन विरह को [specific dimension] के रूप में प्रस्तुत करते हैं।"

REASONING: Board marking scheme for 4-mark questions expects 3-4 distinct analytical points with evidence. The improved version transforms a descriptive summary into an analytical essay by enforcing PEEL per point. Comparative structure (Doha 1 vs Doha 2) is explicitly required by "दोनों दोहों में".

ANSWER:
[Point 1] कुकुआन पहले दोहे में प्रकृति के उल्लास और विरहिणी की वेदना का विरोधाभास (contrast) रचते हैं। [Evidence] "कजरि कजरि बरसत..." और "मोर नाचत..."। [Explanation] वर्षा और मोर का नृत्य श्रव्य-दृश्य बिम्बों (audio-visual imagery) द्वारा प्रकृति के उत्सव को साकार करते हैं, किन्तु "विरहिन के अंग लगै शीत" (अंतर्निहित) — यह विरोधाभास विरह की असहनीयता को तीव्र करता है। [Link] इस प्रकार प्रकृति दर्पण बनती है जो आंतरिक रिक्तता को प्रतिबिंबित करती है।

[Point 2] दूसरे दोहे में काल (समय) स्वयं विरह का साधन बनता है। [Evidence] "बहु बेरि बिताई रैन..." और "प्रभात भई..."। [Explanation] "बहु बेरि" की आवृत्ति समय के खिंचाव को मूर्त करती है; प्रभात का आगमन ("प्रभात भई") आशा नहीं, निराशा लाता है — "दुख न भागा"। यह काल-चक्र विरह को क्षणिक नहीं, शाश्वत बनाता है। [Link] समय की यह निर्ममता भक्ति की धैर्यवान प्रतीक्षा (patient endurance) को रेखांकित करती है।

[Point 3] भाषा की "सरलता" वास्तव में संकेतात्मक सघनता (suggestive density) है। [Evidence] "विरह", "नैन", "प्रभात", "बहु बेरि"। [Explanation] तत्सम शब्द (विरह, प्रभात) दार्शनिक भार वहन करते हैं; तद्भव (नैन, कजरि) लोक-स्पर्श देते हैं। यह मिश्रण भाव को सुलभ yet गंभीर बनाता है। [Link] कुकुआन की भाषा इसीलिए "लोकप्रचलित किंतु लक्षणापूर्ण" है — भक्ति काव्य की परंपरा का निर्वाह।

## WORKED_EXAMPLE_3
PROBLEM: A 6-mark board question: "कुकुआन के दोहों में 'वियोग' और 'संयोग' की द्वंद्वात्मकता (dialectic) को उदाहरण सहित विश्लेषित कीजिए।" Write a complete structured answer.

STEPS:
- Step 1: Decode question — "द्वंद्वात्मकता" = dialectic = tension/interplay between two opposing forces (virah = separation, sanyog = union). Must show how they interact, not just list both.
- Step 2: Map dialectic across both dohas — Doha 1: External sanyog (rain+earth, peacock+cloud) vs internal virah. Doha 2: Temporal sanyog (night→dawn cycle) vs eternal virah. The BELOVED is absent in both — only proxies exist.
- Step 3: Structure 3 PEEL paragraphs — P1: Doha 1's sensory dialectic. P2: Doha 2's temporal dialectic. P3: Synthesis — virah TRANSFORMS sanyog into spiritual longing.
- Step 4: Select precise Evidence — P1: "कजरि कजरि बरसत" (cloud-earth union) vs "विरहिन...". P2: "रैन... प्रभात" (night-day union) vs "दुख न भागा". P3: "नैन" (eyes seeking union) as the site of dialectic.
- Step 5: Write Explanations with device names — P1: उपमा (simile) implied: rain:earth :: beloved:devotee. P2: रूपक (metaphor): night = virah duration. P3: प्रतीक (symbol): eyes = desire for union.
- Step 6: Concluding Link — The dialectic RESOLVES in bhakti: virah IS the highest sanyog (separation as intense presence).

REASONING: 6-mark questions require multi-paragraph synthesis. The dialectic concept (from c12_hin_a_cbse_09_013 Critical Thinking) elevates answer from description to philosophical analysis. Each paragraph handles one dimension (sensory, temporal, metaphysical) — showing hierarchical thinking examiners reward.

ANSWER:
कुकुआन के दोहों में वियोग-संयोग की द्वंद्वात्मकता तीन स्तरों पर संचालित होती है:

स्तर 1 — इंद्रियगत द्वंद्व (पहला दोहा): प्रकृति में संयोग का उत्सव (मेघ-धरा मिलन, मोर-मेघ संगति) विरहिणी के वियोग को तीक्ष्ण बनाता है। "कजरि कजरि बरसत" — मेधा की वर्षा धरा से संयोग है; "मोर नाचत" — मोर का मेघ से संयोग। किन्तु विरहिणी के लिए यही संयोग-विम्ब उसकी वियोग-वेदना को "शीत" (शीतलता/रिक्तता) में बदल देते हैं। उपमा-विधान द्वारा कवि संयोग को वियोग का दर्पण बनाते हैं।

स्तर 2 — कालगत द्वंद्व (दूसरा दोहा): रात्रि-प्रभात का चक्रीय संयोग ("बहु बेरि बिताई रैन... प्रभात भई") समय की नियमितता दर्शाता है, पर "दुख न भागा" — वियोग कालातीत है। यहाँ रूपक में रात्रि = वियोग की अवधि, प्रभात = आशा का छलावा। समय का संयोग (चक्र) वियोग को मिटा नहीं पाता — यह द्वंद्व भक्ति की "धीरता" (patience) को परिभाषित करता है।

स्तर 3 — आध्यात्मिक संश्लेषण: "नैन" (आँखें) द्वंद्व का स्थल हैं — वे संयोग खोजती हैं ("पिया मिलन की आस") पर वियोग ही पाती हैं। कुकुआन इस द्वंद्व को विघटित नहीं, साधते हैं: वियोग ही परम संयोग बन जाता है (वियोगे संयोगः)। यही भक्ति-दर्शन की पराकाष्ठा है।

## COMPETENCY_QUESTION_1
QUESTION: A Class 12 student writes this answer for a 3-mark question on कुकुआन: "कुकुआन के दोहों में प्रकृति का वर्णन सुंदर है। पहले दोहे में वर्षा और मोर हैं, दूसरे में रात और सुबह। इससे विरह का दुःख पता चलता है।" As an examiner, evaluate this answer against CBSE marking criteria. Identify exactly which marking points it misses and rewrite ONE paragraph to demonstrate the required standard.

COMPETENCY: Critical evaluation of answer quality against board marking scheme

STEPS:
- Step 1: Recall CBSE 3-mark poetry marking scheme — typically: 1 mark for correct Point/interpretation, 1 mark for textual Evidence, 1 mark for Explanation of device/effect.
- Step 2: Audit the student answer — Point: vague ("सुंदर वर्णन", "दुःख पता चलता है"); Evidence: paraphrased not quoted; Explanation: absent (no device named, no effect analyzed).
- Step 3: Identify missing marks — Loses Evidence mark (no verbatim line), loses Explanation mark (no device→effect), Point mark partial (theme identified but not analytically framed).
- Step 4: Rewrite first doha analysis as model PEEL paragraph with all three marks secured.

ANSWER:
Evaluation: This answer would score 1/3 marks. It identifies the theme (virah) — earning partial Point mark. It provides ZERO verbatim textual evidence (paraphrase "वर्षा और मोर" ≠ quoting "कजरि कजरि बरसत" or "मोर नाचत") — loses Evidence mark. It offers NO poetic device analysis (no mention of contrast, onomatopoeia, imagery) — loses Explanation mark. CBSE requires: "उदाहरण सहित व्याख्या" = quote + device + effect.

Model rewrite (securing 3/3):
Point: पहले दोहे में प्रकृति का उल्लासमय वर्णन विरहिणी की वेदना को विरोधाभास (contrast) द्वारा तीव्र करता है।
Evidence: "कजरि कजरि बरसत..." तथा "मोर नाचत..."।
Explanation: "कजरि कजरि" की ध्वन्यात्मक आवृत्ति (onomatopoeia + repetition) वर्षा की अनवरत ध्वनि रचती है; मोर का नृत्य दृश्य बिम्ब (visual imagery) उत्सव का साक्ष्य देता है। यह बाह्य उल्लास विरहिणी के आंतरिक "शीत" (रिक्तता) से टकराकर वियोग की असहनीयता को मूर्त करता है — संयोग-वियोग का द्वंद्व।
Link: इस प्रकार प्रकृति-चित्रण मात्र अलंकार नहीं, विरह की अंतःसंरचना का प्रकटीकरण है।

DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: Design a 4-step "Answer Writing Protocol" card that a struggling Class 12 student can use DURING the board exam for any कुकुआन-based poetry question. The protocol must be specific to this chapter's demands (Braj vocabulary, virah-bhakti theme, two-doha structure) and fit on an index card. Test your protocol by applying it to this question: "दूसरे दोहे में 'नैन' पद का क्या महत्व है?"

COMPETENCY: Metacognitive strategy design for exam performance

STEPS:
- Step 1: Determine the 4 essential exam-time actions — must be sequential, memory-light, and chapter-specific.
- Step 2: Draft protocol steps with chapter-specific anchors (e.g., "Check: which doha? Doha 1 = sensory contrast, Doha 2 = temporal contrast").
- Step 3: Include a vocabulary trigger list (key Braj words → standard meanings).
- Step 4: Apply protocol to the test question live — show each step's output.
- Step 5: Verify protocol produces PEEL-compliant answer.

ANSWER:
**कुकुआन उत्तर-लेखन प्रोटोकॉल (Index Card Version)**

**STEP 1: पहचानो (5 सेकंड)**
प्रश्न में कीवर्ड अंडरलाइन करो: विषय (विरह/भक्ति/प्रकृति/काल), दोहा संख्या (1 या 2), मांग (बिम्ब/भाषा/दर्शन)।
→ Test Q: विषय = "नैन" (प्रतीक), दोहा = 2, मांग = "महत्व" (प्रतीकात्मक अर्थ)।

**STEP 2: उद्धृत करो (10 सेकंड)**
संबंधित दोहे से सटीक पद/पंक्ति लिखो। ब्रज शब्दों का अर्थ ब्रैकेट में।
→ "नैन" (आँखें/दृष्टि) — "नैन लगाए बैठी..." / "नैन बिछाए..." (संदर्भानुसार)।

**STEP 3: विश्लेषण करो (30 सेकंड)**
यंत्र पहचानो → प्रभाव बताओ → विषय से जोड़ो।
यंत्र: प्रतीक (symbol) + रूपक (metaphor: नैन = प्रतीक्षा/आसक्ति)।
प्रभाव: "नैन" शारीरिक अंग नहीं, भक्ति की एकाग्र दृष्टि (focused gaze) — "नैन बिछाना" = पलकें बिछाना = पूर्ण समर्पण।
विषय लिंक: वियोग में भी नैन संयोग की प्रतीक्षा करते हैं — यही भक्ति।

**STEP 4: संयोजित करो (PEEL में लिखो, 45 सेकंड)**
Point + Evidence + Explanation + Link = 3-4 वाक्य।

**ब्रज-ट्रिगर सूची:** कजरि=वर्षा ध्वनि, बहु बेरि=अनेक बार, प्रभात=सुबह, विरह=वियोग, नैन=आँख/दृष्टि/आसक्ति।

---
Test Application Output:
Point: "नैन" पद भक्ति में दृष्टि को प्रतीक्षा और आसक्ति का प्रतीक बनाता है।
Evidence: दूसरे दोहे में "नैन लगाए/बिछाए" (प्रसंगानुसार)।
Explanation: "नैन" रूपक द्वारा शारीरिक दृष्टि को आध्यात्मिक एकाग्रता में रूपांतरित करता है — "नैन बिछाना" लोकमुहावरा पूर्ण समर्पण दर्शाता है। वियोग की रात्रि में भी नैन संयोग की प्रतीक्षा नहीं छोड़ते।
Link: इस प्रकार "नैन" विरह को निष्क्रिय दुःख नहीं, सक्रिय भक्ति-प्रतीक्षा सिद्ध करता है — कुकुआन का दार्शनिक योगदान।

DIFFICULTY: hard