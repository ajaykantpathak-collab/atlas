## DEFINITION
Literal comprehension questions require answers directly stated in the text, while inferential comprehension questions demand logical conclusions drawn by connecting textual evidence with contextual knowledge. Both require precise textual referencing.

## COGNITIVE_LEVEL
apply

## MASTERY_CRITERIA
Student can independently classify any question from the chapter as literal or inferential, locate exact textual evidence for literal answers, and construct inferential answers using a minimum of two textual clues with logical justification.

## SCOPE_BOUNDARY
Covers only comprehension question types (literal and inferential) for the poem "lcls [krjukd". Does NOT cover critical analysis, creative writing, or speaking skills which are addressed in subsequent nodes (013-015).

## WALKTHROUGH
Imagine you're in the exam hall staring at a question: "dfo us fdl vk'k; ls esgur dh ywV dks lcls [krjukd ugha ekuk?" Your heart races because the answer isn't written word-for-word in the poem. This is where most students freeze. The secret? First, ask: "Is the answer explicitly written (literal) or must I connect clues (inferential)?" For this poem, start by marking the three negative definitions in Stanza 1 (what it is NOT) and the seven positive images in Stanzas 2-4 (what it IS). Literal questions live in Stanza 1; inferential questions live in the gaps between Stanzas 2-4 and the historical context of 1984 riots. The key insight: every inferential answer in this poem must anchor itself in the concrete imagery of the "pakshi" (bird), "kavya" (poem), or "mritak" (dead body) – never in vague feelings.

## DIAGNOSTIC_QUESTION_1
What is the definition of a literal comprehension question in the context of Hindi poetry analysis?

## DIAGNOSTIC_ANSWER_1
A literal comprehension question asks for information explicitly stated in the poem's text, requiring no interpretation beyond the written words (e.g., "List the three things the poet says are NOT the smallest"). A wrong answer like "It's about understanding the deep meaning" reveals the student confuses literal with inferential comprehension, leading to over-interpretation of direct factual questions.

## DIAGNOSTIC_QUESTION_2
In the poem, the line "lcls [krjukd gksrk gS eqnkZ 'kkafr ls Hkj tkuk" appears. Is the question "Why does the poet compare the smallest thing to a bird that doesn't fly away?" literal or inferential? Explain your reasoning.

## DIAGNOSTIC_ANSWER_2
This is an inferential question because the poem never explicitly states the *reason* for the comparison; the student must infer the symbolic connection between the bird's helplessness and the common man's trapped existence using the imagery of "ohjku gq, vk¡xuksa" and "ejfl;k". A wrong classification as "literal" reveals the student believes any question about the poem's content is literal, missing that "why" demands reasoning beyond textual retrieval.

## DIAGNOSTIC_QUESTION_3
Given the question: "Stanza 3 mentions 'vkiosQ ftLe osQ iwjc esa pqHk tk,'. Identify the literal subject being described and the inferential meaning of 'pqHk tk,' in the context of the 1984 riots."

## DIAGNOSTIC_ANSWER_3
Step 1: Literal subject = "vkRek" (the individual/person) from line "vkRek dk lwjt Mwc tk,". Step 2: Literal action = "pqHk tk," (falls/goes into). Step 3: Inferential meaning = The crushing of human dignity/voice into the "fwjc" (darkness/abyss) of communal violence, where justice ("ftLe") is buried. A wrong answer describing only the physical falling reveals inability to connect the verb "pqHk" to the historical metaphor of systemic erasure.

## DIAGNOSTIC_QUESTION_4
Compare the literal imagery of "cSBs&fcBk, idM+s tkuk" (Stanza 1) with the inferential imagery of "lcls [krjukd og pk¡n gksrk gS tks gj gR;kdkaM osQ ckn... vkidh vk¡[kksa dks fepks± dh rjg ugha xM+rk gS" (Stanza 3). How does the shift from abstract negation to concrete sensory detail change the reader's comprehension of "smallest"?

## DIAGNOSTIC_ANSWER_4
The literal negation ("cSBs&fcBk, idM+s tkuk") defines "smallest" by exclusion (intellectual understanding), while the inferential sensory detail ("vk¡[kksa dks fepks± dh rjg ugha xM+rk") forces visceral embodiment (experiential understanding). The shift moves comprehension from cognitive agreement to empathetic horror – the reader *feels* the weight on their own eyes. A wrong answer listing only the images without analyzing the *shift in reader position* misses the pedagogical purpose of the poem's structure.

## DIAGNOSTIC_QUESTION_5
Evaluate this student's answer to "Why is the dead body's silence the smallest thing?": "Because the poet says 'vkRek dk lwjt Mwc tk,' so the dead person has no voice left." Is this a sufficient inferential answer for Class 11 board standards? Justify.

## DIAGNOSTIC_ANSWER_5
No, it is insufficient. The answer only paraphrases the literal line ("lwjt Mwc tk") without inferring the *socio-political implication*: that the silence represents the state's erasure of minority voices during the 1984 riots, where "ftLe osQ iwjc" (justice's darkness) swallows testimony. Board-level inferential answers require: (1) Textual anchor, (2) Historical context linkage, (3) Thematic generalization. This answer stops at step 1.

## DIAGNOSTIC_QUESTION_6
Create a new inferential question for this poem that requires connecting the "pakshi" (bird) imagery in Stanza 4 with the "nqgjko" (helpless person) in Stanza 3, and explain what a model answer must include.

## DIAGNOSTIC_ANSWER_6
Question: "The bird that 'does not fly away like a petal' (Stanza 4) and the 'helpless person in the jaws of death' (Stanza 3) – what shared condition of the common citizen do they jointly reveal?" Model answer must include: (1) Both images depict *forced passivity* – neither chooses to stay; (2) The bird's "p<+rk gS" (trembles) mirrors the person's "Hkwy tkrh" (shaking voice); (3) Both symbolize the citizen stripped of agency by state violence ("xaqMs dh rjg vdM+rk" / "ph"kksa ls mBrh vaèksiu"). A poor answer would describe the bird and person separately without synthesizing the shared political metaphor.

## COMMON_MISCONCEPTION
Students believe "inferential" means "guessing based on personal opinion." They write answers like "I think the smallest thing is sadness because the poem feels sad," ignoring that in this poem, every inference MUST be grounded in the specific historical trauma of the 1984 anti-Sikh riots (referenced in the poet's bio) and the concrete imagery of "kavya" (poem as testimony), "ejfl;" (elegy), and "xaqMs" (executioner). They miss that the poem's inferential layer is *historically coded*, not emotionally open-ended.

## ON_FAILURE
1. Have the student re-read the poet's bio note: "1988 esa [kkfyLrfu;ksa osQ gkFkksa ekjs x, vkSj ns'k dh vkoke osQ fy, 'kghn gks x,A" 
2. Ask them to circle every word in the poem related to death/violence (ejfl;, xaqMs, ph"kk, mritak, nqgjko). 
3. Model one inference aloud: "The word 'xaqMs' (executioner) in Stanza 4 is not metaphorical – it literally names the rioters. Therefore, the bird 'trembling in alleys' infers the targeted community hiding in Delhi's gullies." 
4. Assign: Write 3 inferences using the formula: [Image] + [Historical Fact from Bio] = [Inferred Meaning].

## BUILDS_ON
c11_hin_ar_cbse_15_010 (Vocabulary in Context) – precise word meanings (e.g., "xaqMs", "ejfl;") are the building blocks for valid inferences.

## LEADS_TO
c11_hin_ar_cbse_15_013 (Critical Thinking: Analysis and Interpretation) – inferential comprehension provides the evidence base for higher-order thematic analysis.

## PREREQUISITE_NODE_IDS
c11_hin_ar_cbse_15_010, c11_hin_ar_cbse_15_011, c11_hin_ar_cbse_15_006, c11_hin_ar_cbse_15_008, c11_hin_ar_cbse_15_009

## PREREQUISITE_REASONS
c11_hin_ar_cbse_15_010: Vocabulary mastery (e.g., "xaqMs", "ejfl;", "ftLe") is essential to decode both literal and inferential layers.
c11_hin_ar_cbse_15_011: Grammar node teaches identification of verb forms (e.g., "pqHk tk," vs "gksrk gS") which signal temporal shifts crucial for inference.
c11_hin_ar_cbse_15_006: Primary theme (state violence vs. common man) provides the thematic framework that guides valid inferences.
c11_hin_ar_cbse_15_008: Imagery analysis (bird, dead body, poem) supplies the concrete textual evidence required for inferential answers.
c11_hin_ar_cbse_15_009: Comprehension questions (literal and inferential) directly test the ability to track ironic structure and symbolic progression.  

## FORWARD_NODE_IDS
c11_hin_ar_cbse_15_013, c11_hin_ar_cbse_15_014, c11_hin_ar_cbse_15_015, c12_hin_a_cbse_15_012, c12_hin_ar_cbse_04_012, c12_hin_ar_cbse_15_012

## FORWARD_REASONS
c11_hin_ar_cbse_15_013: Critical thinking requires the evidence-gathering skill (literal) and interpretation skill (inferential) mastered here.
c11_hin_ar_cbse_15_014: Writing skills (analytical paragraphs) directly use the PEEL structure practiced in inferential answer writing.
c11_hin_ar_cbse_15_015: Comprehension skills ensure accurate textual reference.  
c12_hin_a_cbse_15_012: Class 11 comprehension foundation — literal/inferential distinction, evidence citation, answer structure  
c12_hin_ar_cbse_04_012: अगला तार्किक चरण: Literal comprehension is the ability to extract explicitly stated facts, details, and sequences dire... इस नोड की अवधारणाओं को सीधे उपयोग/विस्तारित करता है।  
c12_hin_ar_cbse_15_012: Prior exposure to the same comprehension taxonomy at Class 11 level; this node deepens it with board-exam rigor.  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
No prior class cross-subject nodes available for Hindi Aroh.

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_15_010 -> c11_hin_ar_cbse_15_012 -> c11_hin_ar_cbse_15_013

## THIS_FORMULA
Inferential Answer = [Literal Textual Evidence] + [Historical/Contextual Knowledge] + [Thematic Generalization]

## FORMULA_VARIABLES
- Literal Textual Evidence: Direct quote or precise paraphrase from poem (e.g., "xaqMs dh rjg vdM+rk")
- Historical/Contextual Knowledge: External fact linking text to context (e.g., 1984 riots, poet's activism)
- Thematic Generalization: Abstract concept connecting evidence to theme (e.g., "state terror erases citizen agency")

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
analytical

## CROSS_SUBJECT
c11_history_india_1984_sikh_riots | The poem's inferential layer is historically coded; understanding the 1984 anti-Sikh riots context is mandatory for valid inferences about "xaqMs", "ejfl;", and "ftLe".
c11_civics_constitutional_rights_minorities | The poem's central inference – the "smallest thing" as the erasure of minority voice – connects directly to Article 29-30 (cultural/educational rights) and state failure to protect minorities.

## PREREQ_CONCEPT
Ability to distinguish explicit textual statements from implicit suggestions using vocabulary and grammar cues.

## PREREQ_BEFORE
Student must know the meanings of key terms: "xaqMs" (executioner), "ejfl;" (elegy), "ftLe" (justice/law), "nqgjko" (helpless person), "ohjku" (trembling/fearful).

## PREREQ_STUCK
If stuck, review c11_hin_ar_cbse_15_010 (Vocabulary) for "xaqMs, ejfl;, ftLe, nqgjko" and c11_hin_ar_cbse_15_011 (Grammar) for verb aspect differences between "gksrk gS" (habitual) and "tk," (completive).

## WORKED_EXAMPLE_1
PROBLEM: Answer the literal question: "According to the first stanza, what three things does the poet explicitly state are NOT the smallest?" (Board exam 2-marker)

STEPS:
- Step 1: Identify the question type – "explicitly state" and "first stanza" signal a literal retrieval task.
- Step 2: Locate Stanza 1 in the poem (lines 1-3): "esgur dh ywV lcls [krjukd ugha gksrh / iqfyl dh ekj lcls [krjukd ugha gksrh / xíkjh&yksHk dh eq_h lcls [krjukd ugha gksrh".
- Step 3: Extract the three noun phrases exactly: (1) esgur dh ywV, (2) iqfyl dh ekj, (3) xíkjh&yksHk dh eq_h.
- Step 4: Format answer as a numbered list using the poet's exact wording – no paraphrasing, no explanation needed for literal questions.
- Step 5: Verify against the negative marker "ugha gksrh" in all three lines to ensure no positive definition slipped in.

REASONING: Literal questions test reading accuracy, not interpretation. The board awards full marks only for verbatim textual matches. Adding "because..." or "this means..." wastes time and risks introducing inference errors.

ANSWER:
1. esgur dh ywV (tear of the eye)
2. iqfyl dh ekj (love of the heart)
3. xíkjh&yksHk dh eq_h (pain of separation/longing)

## WORKED_EXAMPLE_2
PROBLEM: Answer the inferential question: "Why does the poet say the smallest thing is 'the bird that trembles in the alleys after the massacre'? Support with two textual clues." (Board exam 3-marker)

STEPS:
- Step 1: Classify as inferential – "why does the poet say" demands reason not stated in text.
- Step 2: Locate the image: Stanza 4, lines 3-4: "lcls [krjukd og pk¡n gksrk gS tks gj gR;kdkaM osQ ckn / ohjku gq, vk¡xuksa esa p<+rk gS".
- Step 3: Identify Clue 1 (Historical): "gj gR;kdkaM" (after the massacre) links to poet's bio: "1988 esa [kkfyLrfu;ksa osQ gkFkksa ekjs x," – the 1984 Delhi riots.
- Step 4: Identify Clue 2 (Imagery): "ohjku gq, vk¡xuksa esa p<+rk" (trembling in fearful alleys) – the bird doesn't flee ("fepks± dh rjg ugha xM+rk") but stays trembling, mirroring trapped minorities.
- Step 5: Synthesize inference: The bird symbolizes the targeted community forced into hiding, too terrorized to flee, making their trapped existence the "smallest" (most reduced) human condition.
- Step 6: Structure answer: Point (symbol of trapped minorities) + Evidence 1 ("gj gR;kdkaM" + 1984 context) + Evidence 2 ("ohjku...p<+rk" + "ugha xM+rk") + Link to "smallest" = erasure of agency.

REASONING: Inferential answers in this poem are historically anchored. The formula [Image + History = Meaning] is non-negotiable. Missing the 1984 reference makes the inference "generic" and loses 1-2 marks.

ANSWER:
The poet calls the trembling bird the "smallest" because it represents the Sikh community trapped in Delhi's alleys after the 1984 massacre (Clue 1: "gj gR;kdkaM" references the riots). Unlike a petal that flies away, the bird "does not fly away" (Clue 2: "vkidh vk¡[kksa dks fepks± dh rjg ugha xM+rk") – it stays trembling ("ohjku...p<+rk"), symbolizing a people stripped of the agency to escape, reduced to bare survival. This forced passivity is the "smallest" human state.

## WORKED_EXAMPLE_3
PROBLEM: A student writes this answer to "Explain the significance of the repetition 'lcls [krjukd ugha gksrh' in Stanza 1": "The poet repeats it to emphasize that these things are not small. It shows they are big emotions." Critique and rewrite to board standard.

STEPS:
- Step 1: Diagnose errors: (a) "big emotions" is vague – the poem negates *specific* things, not a category; (b) misses the structural function: the repetition builds a *negative definition* to clear ground for the positive definition in Stanzas 2-4; (c) ignores the escalating intimacy: eye-tear (physical) -> heart-love (emotional) -> separation-pain (existential).
- Step 2: Retrieve literal structure: Three parallel negatives with increasing metaphysical weight.
- Step 3: Infer rhetorical purpose: By negating the conventionally "small" (tear) to "large" (separation pain), the poet creates a vacuum that the true "smallest" (political erasure) must fill.
- Step 4: Connect to theme: The negation of personal grief prepares the reader for the *public* grief of Stanza 2-4 – the shift from "iqfyl" (private) to "lekt" (public).
- Step 5: Draft board-level answer using PEEL: Point (structural negation as rhetorical clearing), Evidence (three specific negations with escalating scope), Explanation (creates contrast for the political "smallest"), Link (enables the poem's shift from personal to communal trauma).

REASONING: This worked example teaches *how to upgrade* a weak answer – a critical exam skill. The repetition isn't just emphasis; it's a structural device that enables the poem's central inferential leap from private to political.

ANSWER:
**Weak Answer Critique:** "Big emotions" is reductive; the repetition is structural, not merely emphatic.
**Board-Standard Rewrite:**
The thrice-repeated "lcls [krjukd ugha gksrh" performs a *definitional clearance*. It systematically negates three progressively expansive human experiences: (1) physical reflex (esgur dh ywV), (2) emotional core (iqfyl dh ekj), (3) existential rupture (xíkjh&yksHk dh eq_h). By rejecting even the "largest" private grief as "not the smallest," the poet creates a semantic vacuum. This vacuum is filled in Stanzas 2-4 by a *public/political* "smallest" – the erasure of the citizen's voice ("vkRek dk lwjt Mwc tk,"). The repetition thus engineers the poem's central movement: from the intimate to the historic, from "iqfyl" to "lekt".

## COMPETENCY_QUESTION_1
QUESTION: A Class 11 student answers the inferential question "What does 'cSBs&fcBk, idM+s tkuk' imply about the nature of the 'smallest' thing?" with: "It means the smallest thing is not about refusing or accepting, so it's about being neutral." Identify the precise comprehension error and rewrite the answer correctly using the poem's logic.

COMPETENCY: Analyzing flawed inferential reasoning and correcting it with textual-historical synthesis.

STEPS:
- Step 1: Identify error – student treats "cSBs&fcBk," (refusal/acceptance) as abstract philosophy, ignoring the poem's concrete political context where "refusal/acceptance" refers to the *state's denial of justice* and *victim's forced acceptance of erasure*.
- Step 2: Retrieve correct context – "cSBs&fcBk," appears in the negative definition stanza; the positive definition shows the "smallest" as *active suffering* (bird trembling, dead body silenced), not neutrality.
- Step 3: Apply historical lens – 1984 riots: victims had no power to "refuse" (cSBs) the violence nor "accept" (fcBk) it as justice; they were reduced to "nqgjko" (helpless).
- Step 4: Rewrite: "The line negates voluntary choice (refusal/acceptance). The 'smallest' thing is the *absence of agency* – the citizen reduced to a 'nqgjko' in 'xaqMs dh rjg' (executioner's jaws) who cannot even choose to flee ('fepks± dh rjg ugha xM+rk'). Neutrality is a privilege; the poem describes its total loss."

ANSWER:
**Error:** Misreading political helplessness as philosophical neutrality. The poem's "smallest" is the *violent removal of choice*, not a state of equilibrium.
**Corrected Answer:** "cSBs&fcBk, idM+s tkuk" signifies that the "smallest" condition lies *beyond* the binary of resistance or submission. In the 1984 context (poet's bio), the targeted community could neither refuse the mob ("cSBs") nor accept the violence as legitimate ("fcBk") – they were rendered "nqgjko" (helpless) in "xaqMs dh rjg" (executioner's jaws). The "smallest" is this radical disempowerment where even the capacity to say yes/no is extinguished, as seen in the bird that "trembles" but "does not fly away" – trapped, not neutral.

DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: The poem ends with the image of the bird that "does not fly away like a petal" but "trembles in the alleys." A student claims this is a metaphor for "hope" because the bird is still alive. Using the poem's full textual and historical architecture, evaluate this interpretation and provide the board-exam standard inference.

COMPETENCY: Evaluating competing interpretations using textual evidence and historical context to defend the authorially intended meaning.

STEPS:
- Step 1: Test "hope" hypothesis against Stanza 4 details: "ohjku gq, vk¡xuksa esa p<+rk" (trembles in fearful alleys), "vkidh vk¡[kksa dks fepks± dh rjg ugha xM+rk" (doesn't fly away like a petal), "ejfl, i<+rk" (reads elegy), "vdM+rk" (crushes/smashes).
- Step 2: Cross-reference with Stanza 3: "vkRek dk lwjt Mwc tk," (person's voice silenced), "ftLe osQ iwjc esa pqHk tk," (falls into justice's darkness).
- Step 3: Apply historical anchor (poet's bio): "1988 esa [kkfyLrfu;ksa osQ gkFkksa ekjs x," – written *after* the riots, as testimony ("ejfl;k" = elegy for the dead), not anticipation.
- Step 4: Synthesize – the bird's non-flight is not hope; it's *entrapment*. "fepks± dh rjg" (like a petal) implies lightness/freedom denied. "ohjku" (fearful) and "vdM+rk" (crushed) confirm trauma, not resilience.
- Step 5: Formulate board answer: Acknowledge the student's surface reading (alive = hope), then dismantle with 3 textual-historical counters: (1) "ejfl;k" genre = mourning, not hope; (2) "xaqMs" (executioner) presence = ongoing threat; (3) "ftLe osQ iwjc" = justice extinguished. The bird is a *witness*, not a survivor.

ANSWER:
**Evaluation:** The "hope" reading is a Category Error – it imports an external optimism alien to the poem's elegiac ("ejfl;k"), testimonial purpose.
**Board-Standard Inference:** The bird embodies *testimonial entrapment*. Three textual-historical proofs: (1) Genre marker: The poem is an "ejfl;k" (elegy) – the bird "i<+rk ejfl," (reads elegy), performing mourning, not hoping. (2) Threat persistence: "xaqMs dh rjg vdM+rk" (crushes like an executioner) – the killer is still present, making survival precarious, not hopeful. (3) Justice vacuum: "ftLe osQ iwjc esa pqHk tk," – the bird/person falls into the *darkness of justice*, meaning the system has failed. The bird's refusal to fly "fepks± dh rjg" (like a petal) signifies the *impossibility of escape* for the targeted minority, not the choice to stay. It is the "smallest" thing: a life reduced to witnessing its own erasure.

DIFFICULTY: hard