## DEFINITION
Character analysis of the protagonist involves examining the central character's traits, motivations, conflicts, and development through their actions, speech, thoughts, and interactions with others to understand their role in conveying the text's central theme. In "Paik Dark Dark...", the protagonist is the illiterate messenger (paik) whose struggle with literacy and dignity drives the poem's social commentary.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student can independently identify the protagonist's key traits, trace their development across the poem using textual evidence, and explain how the character embodies the theme of education versus ignorance in a structured PEEL (Point, Evidence, Explanation, Link) paragraph suitable for board exams.

## SCOPE_BOUNDARY
This node covers the protagonist (paik) only: his physical description, socio-economic status, dialogue, internal conflict, and transformation. It does NOT cover supporting characters (the poet/narrator), themes in isolation, or literary devices unless directly illustrating character.

## WALKTHROUGH
Imagine you receive a letter but cannot read it — you must trust a stranger to tell you its contents, not knowing if they speak truth. This is the paik's daily reality. Begin by listing every detail the poem gives about him: his appearance ("dark dark"), his job (running in heat), his words (refusing then accepting learning), and his final resolve. Notice how each detail reveals his dignity despite oppression. The key insight: the paik is not a passive victim; his journey from "I will not learn" to "I will learn" makes him the agent of the poem's message.

## DIAGNOSTIC_QUESTION_1
What is the literal meaning of the phrase "paik dark dark" (पाइक डार्क डार्क) used in the poem's opening, and what does it suggest about the protagonist's social identity?

## DIAGNOSTIC_ANSWER_1
The phrase literally describes the messenger as "dark, dark" — referring to his sun-burnt complexion from running outdoors and metaphorically to his illiteracy (darkness of ignorance). A wrong answer (e.g., "it means he is evil" or "it describes his clothes") reveals the student confuses physical description with moral judgment or misses the metaphor linking skin colour to educational deprivation.

## DIAGNOSTIC_QUESTION_2
Why does the paik initially refuse the poet's offer to teach him, saying "I will not learn"? Explain using his socio-economic context.

## DIAGNOSTIC_ANSWER_2
He refuses because he is old, exhausted from physical labour, and believes literacy cannot change his material reality — his survival depends on running, not reading. A wrong answer (e.g., "he is lazy" or "he hates the poet") shows the student misses the structural barriers: the poem explicitly states he has never had leisure ("I never got time") and fears losing his only livelihood.

## DIAGNOSTIC_QUESTION_3
Apply the PEEL structure to write one paragraph answering: "How does the poet use the paik's dialogue to reveal his self-awareness?" Use two pieces of evidence from the poem.

## DIAGNOSTIC_ANSWER_3
**Point:** The paik's dialogue shows acute awareness of his exploitation. **Evidence 1:** When he says "You say the scribe is good / but he writes lies," he knows the literate manipulate him. **Evidence 2:** His final decision "I will learn" proves he understands literacy as power. **Explanation:** Both quotes show he is not ignorant of his oppression — he analyses it. **Link:** This makes his transformation an act of resistance, not charity. A weak answer would only quote without explaining *how* the quotes prove self-awareness.

## DIAGNOSTIC_QUESTION_4
Compare the paik's attitude toward learning at the beginning and end of the poem. What specific event triggers the shift, and what does this reveal about his character?

## DIAGNOSTIC_ANSWER_4
Initially he rejects learning as useless ("What will I do with reading?"); finally he accepts it as survival ("I will learn... I will not let my daughter go"). The trigger is the poet revealing the scribe's deceit — the paik realises literacy protects his family. This reveals his pragmatism: he learns not for abstract knowledge but to shield the next generation. A wrong answer missing the "daughter" reference fails to see his motivation is intergenerational, not personal.

## DIAGNOSTIC_QUESTION_5
Evaluate the poet's role in the paik's transformation. Is the poet a saviour or a catalyst? Justify with textual reasoning.

## DIAGNOSTIC_ANSWER_5
The poet is a catalyst, not a saviour. He exposes the scribe's fraud ("he writes lies") but the paik *chooses* to act ("I will learn"). The poem centres the paik's agency: the poet offers the tool, but the paik decides to use it. Calling the poet a "saviour" erases the protagonist's autonomy — a common error when students project middle-class reformist narratives onto marginalised characters.

## DIAGNOSTIC_QUESTION_6
Write a 4-line internal monologue for the paik the night after he decides to learn, capturing his fear, resolve, and hope for his daughter. Use imagery from the poem (heat, letters, running).

## DIAGNOSTIC_ANSWER_6
*Example:* "These legs that burn on noon's harsh tar / Will now trace letters, near and far. / No scribe's false pen shall seal her fate / My daughter reads — I make it straight."  
A poor answer would be generic ("I want to study") without tying to the poem's concrete symbols (heat, running, letters, daughter). The task tests if the student can *inhabit* the character using textual building blocks.

## COMMON_MISCONCEPTION
Students often treat the paik as a passive symbol of "illiterate India" rather than an active character with agency. They write: "The poet teaches the paik" — but the poem never shows a lesson occurring. The paik *decides* to learn; the poet only exposes the injustice. This error stems from reading the poem as a moral fable (teacher saves student) instead of a dialogue between equals where the marginalised character claims power.

## ON_FAILURE
1. Re-read the poem marking *only* the paik's spoken lines in one colour, the poet's in another. 2. Count how many lines the paik speaks versus the poet — notice the paik dominates the second half. 3. Ask: "Who makes the final decision?" The answer is in the paik's last speech. 4. Rewrite one paragraph replacing "the poet teaches him" with "the paik chooses to learn" and see how the meaning shifts.

## BUILDS_ON
c11_hin_ar_cbse_12_002 (Plot and Narrative Structure) — understanding the sequence of dialogue is essential to trace the character's turning point.

## LEADS_TO
c11_hin_ar_cbse_12_005 (Character Analysis: Supporting Characters) — the poet's character is defined *through* his interaction with the paik; you cannot analyse the foil without the protagonist.

## PREREQUISITE_NODE_IDS
c11_hin_ar_cbse_12_001, c11_hin_ar_cbse_12_002, c11_hin_ar_cbse_12_003
## PREREQUISITE_REASONS
c11_hin_ar_cbse_12_001: Context on Nagarjun's Marxist lens explains why the paik is portrayed as a conscious labourer, not a pitiable victim.
c11_hin_ar_cbse_12_002: The narrative structure (dialogue poem with a clear turning point) maps the protagonist's psychological shift.
c11_hin_ar_cbse_12_003: The setting (scorching roads, scribe's office) creates the material conditions shaping the paik's choices.

## FORWARD_NODE_IDS
c11_hin_ar_cbse_12_005, c11_hin_ar_cbse_12_006, c11_hin_ar_cbse_12_013, c11_hin_ar_cbse_12_012, c11_hin_ar_cbse_12_014, c12_hin_ar_cbse_12_004

## FORWARD_REASONS
c11_hin_ar_cbse_12_005: The supporting character (poet/narrator) is defined by his relationship to the protagonist — his role as catalyst only exists because the paik changes.
c11_hin_ar_cbse_12_006: The primary theme (education as liberation) is *embodied* in the protagonist's arc; theme analysis requires character evidence.
c11_hin_ar_cbse_12_013: Critical interpretation (e.g., "Is the ending optimistic?") depends on how we read the paik's agency — established here.
c11_hin_ar_cbse_12_012: Protagonist analysis (the mother) provides character traits essential for inferring her motives.  
c11_hin_ar_cbse_12_014: Protagonist analysis gives the character details required for a character sketch.  
c12_hin_ar_cbse_12_004: Prior practice in protagonist analysis (first-person narrator, trait identification, evidence citation) is the direct skill foundation.  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
none

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_12_002 -> c11_hin_ar_cbse_12_004 -> c11_hin_ar_cbse_12_005

## THIS_FORMULA
PEEL Paragraph Structure for Character Analysis: **P**oint (trait/change) → **E**vidence (dialogue/action/description) → **E**xplanation (what it reveals about character) → **L**ink (connect to theme/author's purpose)

## FORMULA_VARIABLES
P = Character trait or turning point (e.g., "The paik transforms from resignation to resistance")  
E = Specific textual detail (e.g., "In the final stanza he says 'I will learn'")  
E = Inference linking detail to trait (e.g., "This shift from 'I will not' to 'I will' shows agency")  
L = Connection to broader idea (e.g., "Thus Nagarjun presents literacy as a tool of self-empowerment, not charity")

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
analytical

## CROSS_SUBJECT
c11_history_social_reform_movements | The paik's struggle mirrors 19th/20th century Indian social reformers' focus on literacy for marginalised castes — but the poem centres the learner's agency, not the reformer's charity.
c11_sociology_social_stratification | The poem illustrates how literacy functions as cultural capital (Bourdieu): the scribe monopolises it to exploit the paik, who must acquire it to break the cycle.

## PREREQ_CONCEPT
Understanding dialogue poems as dramatic encounters where character is revealed through speech, not narration.

## PREREQ_BEFORE
Student must be able to distinguish between the poet (Nagarjun) and the speaker (the "I" in the poem who dialogues with the paik).

## PREREQ_STUCK
Review "Dialogue Poem Structure" from c11_hin_ar_cbse_12_002 — identify who speaks each stanza.

## WORKED_EXAMPLE_1
PROBLEM: Using the PEEL structure, analyse how the poet uses the paik's physical description ("dark dark", "running in heat", "feet blistered") to establish his socio-economic reality in the first three stanzas.

STEPS:
- Step 1: Identify the question's demand — "how physical description establishes socio-economic reality" → we need to connect bodily details to class/labour.
- Step 2: Locate evidence — Stanza 1: "dark dark" (complexion + ignorance metaphor); Stanza 2: "runs in heat", "blistered feet"; Stanza 3: "carries letters he cannot read".
- Step 3: Apply PEEL for each detail. First PEEL: Point = colour signifies dual oppression. Evidence = "dark dark". Explanation = sun exposure + illiteracy. Link = introduces intersection of body and mind.
- Step 4: Second PEEL: Point = labour is embodied. Evidence = "blistered feet". Explanation = physical cost of being a messenger. Link = shows why he has no time/energy for learning.
- Step 5: Synthesize — the description is not decorative; it builds the materialist foundation for his later resistance.

REASONING: The poem is Marxist in orientation — the body is the site of exploitation. Physical details are evidence of material conditions, not mere imagery. PEEL forces the student to move from quote to analysis to thematic significance.

ANSWER: The paik's "dark dark" skin functions as a palimpsest: literally burnt by the sun during endless runs, metaphorically darkened by enforced illiteracy. His "blistered feet" are the corporeal receipt of a labour that leaves no leisure for education. When he carries letters "he cannot read", the irony crystallises — his body transports the very tool of power (literacy) that excludes him. Nagarjun thus establishes the protagonist's reality through somatic evidence, preparing the reader to understand his initial refusal to learn not as stubbornness but as rational calculation: survival demands running, not reading.

## WORKED_EXAMPLE_2
PROBLEM: The paik says: "You say the scribe is good / but he writes lies." Analyse how this single accusation reshapes the poem's power dynamic and the protagonist's self-perception.

STEPS:
- Step 1: Identify the speaker, addressee, and context — paik speaks to poet after poet praises the scribe.
- Step 2: Unpack "writes lies" — not errors, but deliberate falsification. The scribe controls information flow.
- Step 3: Analyse power shift — earlier, poet holds knowledge (offers teaching). Now paik reveals *he already knows* the system is rigged. He is not ignorant; he is strategically silent.
- Step 4: Connect to self-perception — he sees himself as a target of fraud, not a passive recipient. This awareness fuels his later decision.
- Step 5: Link to theme — literacy is exposed as a weapon of the powerful; acquiring it becomes self-defence.

REASONING: This moment is the epistemological turning point. The protagonist moves from object (illiterate body) to subject (critical analyst). Students often miss this because the line is brief and the poet doesn't react dramatically.

ANSWER: The accusation "he writes lies" instantly reframes the paik from a man who *lacks* knowledge to a man who *sees through* the manipulation of knowledge. He understands the scribe's literacy is not neutral — it is instrumentalised to exploit him (e.g., fake letters, withheld money orders). This revelation does two things: (1) it justifies his earlier refusal — why learn a skill used to cheat you? (2) it makes his final decision to learn a tactical reversal: he will master the weapon turned against him. The power dynamic tilts — the poet realises the paik needs not charity but justice. The protagonist's self-perception shifts from "I am dark/illiterate" to "I am cheated, and I will stop it."

## WORKED_EXAMPLE_3
PROBLEM: Trace the protagonist's character arc across the entire poem using the framework: **Initial State → Catalyst → Internal Conflict → Decision → New State**. Cite one evidence per stage.

STEPS:
- Step 1: Initial State — resignation. Evidence: "What will I do with reading? / I have never had time." Shows he has internalised his exclusion.
- Step 2: Catalyst — poet exposes scribe's fraud. Evidence: "He writes lies." External event shatters his assumption that literacy = honesty.
- Step 3: Internal Conflict — weighs cost of learning (age, time) against cost of ignorance (daughter's future). Evidence: "If I learn... I will not let my daughter go." The conflict is intergenerational.
- Step 4: Decision — active choice. Evidence: "I will learn." Short, declarative, future tense. No hesitation.
- Step 5: New State — empowered agent. Evidence: "I will not let my daughter go [to the scribe]." He becomes protector, not victim.
- Step 6: Thematic Link — arc mirrors Nagarjun's vision: education as praxis (action + reflection), not mere skill acquisition.

REASONING: Board exams often ask "Trace the character's development" — this 6-stage framework ensures no phase is missed. Each stage requires *specific* textual evidence, not generalisation. The intergenerational motive (daughter) is the poem's unique twist — missing it loses the gender/caste dimension.

ANSWER: The paik begins in resigned acceptance of his illiteracy ("What will I do with reading?"). The catalyst is the poet's revelation of the scribe's deceit ("he writes lies"), which transforms literacy from an abstract good into a necessary shield. His internal conflict surfaces when he weighs his age against his daughter's vulnerability ("If I learn... I will not let my daughter go"). The decision ("I will learn") is abrupt and absolute, marking his transition from passive sufferer to active resister. In the new state, he claims the role of guardian — "I will not let my daughter go" to the scribe — embodying the poem's central argument: literacy enables the marginalised to protect their own. Nagarjun thus crafts a protagonist whose arc is not linear improvement but political awakening.

## COMPETENCY_QUESTION_1
QUESTION: A Class 11 student writes: "The paik is illiterate and poor. The poet feels sorry for him and teaches him to read. In the end, the paik becomes literate and happy." Identify **three** specific inaccuracies in this summary based on the poem's text, and rewrite it correctly in 4 sentences using the PEEL structure.

COMPETENCY: Critical evaluation of peer response / textual fidelity

STEPS:
- Step 1: Identify inaccuracy 1 — the poet never "teaches" him; the paik decides to learn.
- Step 2: Identify inaccuracy 2 — "becomes literate" is not shown; the poem ends at the *decision*, not the outcome.
- Step 3: Identify inaccuracy 3 — "happy" imposes a middle-class resolution; the poem ends on resolve, not emotion.
- Step 4: Rewrite using PEEL: Point = Paik's agency drives change. Evidence = "I will learn" (his words). Explanation = He chooses literacy as resistance. Link = Nagarjun centres the marginalised voice.

ANSWER: Three inaccuracies: (1) The poet does not teach the paik — the paik *decides* to learn after the poet exposes the scribe's fraud. (2) The poem does not show the paik becoming literate; it ends at his resolve ("I will learn"). (3) "Happy" is a projected emotion; the text shows determination, not happiness.  
**Corrected PEEL paragraph:** The paik's transformation is self-driven, not bestowed. When he declares "I will learn," he rejects the role of passive beneficiary and claims literacy as a tool of autonomy. This choice reframes education as an act of resistance against a system that uses literacy to exploit him. Nagarjun thus positions the marginalised protagonist as the architect of his own liberation.

DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: "The paik's final decision to learn is motivated entirely by his love for his daughter." Evaluate this statement. To what extent do you agree? Support your answer with **three** distinct textual reasons, acknowledging any counter-evidence.

COMPETENCY: Nuanced argumentation with textual evidence / evaluating character motivation

STEPS:
- Step 1: Agree partially — daughter is the *stated* motive in final stanza ("I will not let my daughter go").
- Step 2: Reason 1 — Intergenerational justice: he links his learning to her protection (direct quote).
- Step 3: Reason 2 — But his *awareness* of exploitation (scribe's lies) precedes the daughter mention; self-respect is also a motive.
- Step 4: Reason 3 — Counter-evidence: earlier he says "What will I do with reading?" showing he initially sees no *personal* use. The daughter makes it *useful*.
- Step 5: Synthesize — motivation is layered: immediate trigger = daughter; deeper cause = realisation of systemic fraud. "Entirely" is reductionist.

ANSWER: The statement is partially true but reductive. **Agree:** The final stanza explicitly ties his resolve to his daughter — "I will not let my daughter go [to the scribe]" — making intergenerational protection the proximate motive. **Reason 1:** He learns *for* her, not himself, transforming literacy into a hereditary shield. **Reason 2:** However, the *catalyst* is the scribe's fraud ("he writes lies"), which wounds his dignity *as a man*, not just as a father. His earlier refusal ("What will I do with reading?") shows he saw no personal utility — the daughter provides that utility. **Reason 3:** Counter-evidence: if love alone motivated him, he would have accepted the poet's first offer. He only agrees *after* understanding the mechanism of exploitation. Thus, motivation = **love + political consciousness**. The word "entirely" erases the latter.

DIFFICULTY: hard