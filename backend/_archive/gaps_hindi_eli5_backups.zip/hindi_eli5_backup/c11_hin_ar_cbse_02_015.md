## DEFINITION
Speaking and Listening: Discussion Points refers to the structured oral competency where students collaboratively explore, debate, and synthesize interpretations of a literary text through evidence-based dialogue, requiring active listening, turn-taking, and the ability to build upon peers' ideas while grounding arguments in textual specifics.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student can independently initiate and sustain a 5-minute literary discussion on "fe;k¡ ulh#íhu" by: (1) posing at least two open-ended interpretive questions rooted in textual evidence, (2) responding to a peer's claim with a relevant quote or scene reference, and (3) synthesizing two contrasting viewpoints into a nuanced conclusion about the story's critique of societal hypocrisy.

## SCOPE_BOUNDARY
This node covers only the oral discussion framework for Chapter 2 ("vejdkar") — specifically, generating discussion questions, practicing active listening protocols, and structuring spoken responses using textual evidence. It does NOT cover formal debate rules, presentation skills, or written answer composition (those are in nodes 013 and 014).

## WALKTHROUGH
Imagine you're in a college seminar where the professor asks, "What does the author really think about education — does he value degrees or wisdom?" You freeze because you've only memorized plot points. To begin, reread the climactic confrontation between fe;k¡ ulh#íhu and the professor (pages 24-26) and underline every line where education is mentioned. Next, convert each underline into a "Why" or "How" question — e.g., "Why does fe;k¡ mock the professor's degrees while teaching a child 'vfyI+kQ'?" Then, practice the "Listen-Quote-Build" cycle with a partner: one states a claim with a line reference, the other repeats the claim in their own words, adds a new quote, and extends the interpretation. The key insight: discussion isn't sharing opinions — it's collaborative evidence-mining where every assertion must be traceable to a specific dialogue or narrative detail.

## DIAGNOSTIC_QUESTION_1
What is the primary purpose of a "textual evidence anchor" in a literary discussion, and how does it differ from a personal opinion?

## DIAGNOSTIC_ANSWER_1
A textual evidence anchor is a specific quote, scene, or narrative detail from the story used to ground an interpretive claim, making it verifiable by all participants. Unlike personal opinion ("I feel the professor is arrogant"), an anchor ("On page 25, the professor says 'vkius [kkunkuh ukuckbZ gksus dk f"kØ fd;k]'") allows the group to collectively examine the same words. A wrong answer — e.g., "Evidence is just a quote you like" — reveals the student confuses decoration with argumentation and cannot distinguish between subjective reaction and analytical support.

## DIAGNOSTIC_QUESTION_2
In the story, fe;k¡ ulh#íhu asks the professor: "D;k vki nwljh i<+kbZ dh ckcr oqQN dg jgs Fks u!" — why is this question a stronger discussion opener than "Is fe;k¡ rude to the professor?"

## DIAGNOSTIC_ANSWER_2
The first question invites analysis of power dynamics, irony, and the story's critique of institutional education by focusing on a specific textual moment where fe;k¡ exposes the professor's performative intellect. The second question reduces a complex character interaction to a binary moral judgment ("rude" vs "not rude"), shutting down exploration of themes like "rkyhe dh rkyhe gh cM+h ph”k gksrh gS" (the smallest lie is a big sin). A student who prefers the second question likely equates discussion with opinion-sharing and misses how textual specifics generate interpretive depth.

## DIAGNOSTIC_QUESTION_3
During a discussion, a peer claims: "fe;k¡ ulh#íhu is just an uneducated fool who gets lucky." Using the "Listen-Quote-Build" protocol, formulate a spoken response that acknowledges their view, introduces a countering textual detail, and reframes the interpretation.

## DIAGNOSTIC_ANSWER_3
Step 1 (Listen): "You're saying fe;k¡'s success comes from luck, not wisdom — I hear that in his lack of formal degrees." Step 2 (Quote): "But on page 26, when he teaches the child 'vfyI+kQ → cs → the', the narrative calls it 'lekI+kQ' (profound) learning — not luck." Step 3 (Build): "This suggests the story values oral, experiential pedagogy over certificated knowledge, making fe;k¡ a deliberate foil to the professor's hollow credentials." A response that skips Step 1 or 2 shows the student cannot separate listening from rebuttal or cannot locate textual support under pressure.

## DIAGNOSTIC_QUESTION_4
Compare the discussion potential of these two questions about the ending: (A) "Did fe;k¡ win in the end?" (B) "How does the final image of fe;k¡ teaching 'vfyI+kQ' under the streetlight redefine 'v[kckj' (literature) for the novel?" Which enables deeper analysis and why?

## DIAGNOSTIC_ANSWER_4
Question B is superior because it directs attention to a specific symbolic scene (streetlight teaching), a key term ("v[kckj"), and the novel's meta-commentary on what counts as literature — all requiring multi-layered textual synthesis. Question A reduces the ending to a binary win/lose, ignoring the story's ambiguity (the professor's grudging "gS lkfgc] ekuk!"). Choosing A indicates the student conflates plot resolution with thematic closure and cannot frame questions that open interpretive space rather than close it.

## DIAGNOSTIC_QUESTION_5
A classmate argues: "The story is just a comedy about a funny illiterate man — no serious theme." Evaluate this claim using the story's treatment of "uxhuklk”k" (exploitation) and "ehuklk”k" (deception) as discussed in the vocabulary node (010). Is the claim defensible?

## DIAGNOSTIC_ANSWER_5
The claim is indefensible. The vocabulary node explicitly defines "uxhuklk”k" as exploitation by the powerful (the professor leveraging fe;k¡'s illiteracy) and "ehuklk”k" as systemic deception (the professor's performative scholarship). The comedy is a vehicle — fe;k¡'s humor ("ge crZu èkksuk u lh[krs / ge Hkêòh cukuk u lh[krs") masks a scathing critique of how institutional education enables both. A student defending the claim likely reads tone literally and misses how irony (node 009) and vocabulary (node 010) encode thematic gravity beneath surface humor.

## DIAGNOSTIC_QUESTION_6
Create an original discussion prompt for a 4-person group that: (1) references the "three stages of life" poem fe;k¡ recites (page 25), (2) connects to the story's critique of "izca/k" (formal education), and (3) requires each speaker to cite a different character's perspective.

## DIAGNOSTIC_ANSWER_6
Strong prompt: "fe;k¡'s poem — 'u dPph esa cSBk / u cSBk og iDdh esa / u nwljh esa → vkSj tk cSBk rhljh esa' — maps childhood, youth, old age to spaces of learning. Taking the roles of fe;k¡, the professor, the child, and the narrator, each person argue: Which space does your character believe is the TRUE site of education? Cite one line each." A weak prompt would ask "What does the poem mean?" — too vague, no role structure, no citation requirement. The strong version forces polyvocal analysis and textual precision.

## COMMON_MISCONCEPTION
Students believe "discussion points" are just a list of topics to talk about (e.g., "theme of education," "character of fe;k¡"). They prepare by memorizing themes from node 006/007 and then recite them in a circle. This fails because: (1) it treats discussion as serial monologue, not interactive inquiry; (2) it ignores the listening dimension — no one builds on others' ideas; (3) it lacks textual anchoring — themes float unmoored from specific dialogues like the "ckn'kkg lyker" revelation (page 27) or the streetlight pedagogy scene. The misconception stems from confusing "content coverage" (what the story is about) with "discourse moves" (how to collaboratively construct meaning).

## ON_FAILURE
If a student falls into the "topic list" trap: (1) Hand them a transcript of a model 3-minute discussion on a different chapter — have them highlight every "Listen-Quote-Build" cycle in three colors. (2) Assign a 5-minute "silent listening" exercise: they must paraphrase a peer's claim before speaking, using the stem "So you're saying [paraphrase] — and I see that in [specific line]." (3) Give them a "Discussion Move Menu" card with only 4 moves: Probe ("What line shows that?"), Extend ("That connects to page 24 where..."), Complicate ("But the narrator says..."), Synthesize ("So we have two views: X says..., Y says..."). Practice with low-stakes topics (e.g., "best street food") before returning to the text.

## BUILDS_ON
This node synthesizes all prior chapter nodes (001-014) — plot, character, theme, devices, vocabulary, grammar, comprehension, critical thinking, writing — into a live oral practice where each concept becomes a discussion tool rather than a test item.

## LEADS_TO
This node enables the internal assessment (ASL) and board exam speaking tasks where students must demonstrate spontaneous, evidence-based literary conversation — a skill transferable to university seminars and professional collaborative problem-solving.

## PREREQUISITE_NODE_IDS
c11_hin_ar_cbse_02_001, c11_hin_ar_cbse_02_002, c11_hin_ar_cbse_02_003, c11_hin_ar_cbse_02_004, c11_hin_ar_cbse_02_005, c11_hin_ar_cbse_02_006, c11_hin_ar_cbse_02_007, c11_hin_ar_cbse_02_008, c11_hin_ar_cbse_02_009, c11_hin_ar_cbse_02_010, c11_hin_ar_cbse_02_011, c11_hin_ar_cbse_02_012, c11_hin_ar_cbse_02_013, c11_hin_ar_cbse_02_014
## PREREQUISITE_REASONS
c11_hin_ar_cbse_02_001: Context/background provides the socio-historical frame (colonial education, Hindi literary renaissance) essential for interpreting fe;k¡'s resistance.
c11_hin_ar_cbse_02_002: Plot structure identifies the confrontation beats (arrival, interrogation, teaching scene, departure) that anchor discussion turning points.
c11_hin_ar_cbse_02_003: Setting/atmosphere (the professor's study vs. streetlight) supplies the spatial symbolism that fuels "where does real learning happen?" debates.
c11_hin_ar_cbse_02_004: Protagonist analysis gives fe;k¡'s motivation, voice, and irony — the engine of every discussion he dominates.
c11_hin_ar_cbse_02_005: Supporting characters (professor, child, narrator) provide the polyvocal perspectives required for Diagnostic Q6's role-play.
c11_hin_ar_cbse_02_006: Primary theme (education vs. wisdom) is the central debate axis; without it, discussion has no gravitational center.
c11_hin_ar_cbse_02_007: Secondary themes (exploitation, deception, oral vs. written tradition) enrich counter-arguments and complication moves.
c11_hin_ar_cbse_02_008: Imagery/metaphor (streetlight, three stages poem) supplies the symbolic evidence for interpretive claims.
c11_hin_ar_cbse_02_009: Irony/symbolism (fe;k¡'s "illiterate" wisdom vs. professor's "learned" folly) is the primary engine of textual tension.
c11_hin_ar_cbse_02_010: Vocabulary (uxhuklk”k, ehuklk”k, v[kckjuohl) equips students with precise analytical terminology for spoken arguments.
c11_hin_ar_cbse_02_011: Grammar/usage (dialect, register shifts) helps students notice how fe;k¡'s language performs his resistance.
c11_hin_ar_cbse_02_012: Literal/inferential comprehension ensures baseline textual accuracy — no discussion survives factual errors.
c11_hin_ar_cbse_02_013: Critical thinking/analysis provides the interpretive frameworks (feminist, postcolonial, pedagogical) that deepen discussion beyond plot.
c11_hin_ar_cbse_02_014: Writing skills (structured answers) transfer directly to spoken PEEL (Point-Evidence-Explanation-Link) response architecture.

## FORWARD_NODE_IDS
c12_hin_a_cbse_12_015, c12_hin_al_cbse_02_015, c12_hin_al_cbse_03_015, c12_hin_ar_cbse_02_015, c12_hin_ar_cbse_12_015

## FORWARD_REASONS
none
c12_hin_a_cbse_12_015: अगला तार्किक चरण: Speaking and Listening: इस नोड की अवधारणाओं को सीधे उपयोग/विस्तारित करता है।  
c12_hin_al_cbse_02_015: Reinforces discussion protocols across multiple texts.  
c12_hin_al_cbse_03_015: Class 11 Antra discussion experience transfers to Class 12 complexity  
c12_hin_ar_cbse_02_015: Class 11 speaking/listening practice establishes baseline fluency in turn-taking, paraphrasing, and evidence citation.  
c12_hin_ar_cbse_12_015: अगला तार्किक चरण: Speaking and Listening: इस नोड की अवधारणाओं को सीधे उपयोग/विस्तारित करता है।  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
none

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_02_014 -> c11_hin_ar_cbse_02_015 -> none: Writing skills (structured textual analysis) enable spoken evidence-based discussion, which culminates the chapter's learning trajectory.

## THIS_FORMULA
Listen-Quote-Build (LQB) Protocol: 1. PARAPHRASE peer's claim → 2. CITE specific textual evidence (line/scene) → 3. EXTEND interpretation with new insight → 4. INVITE next speaker with open question.

## FORMULA_VARIABLES
PARAPHRASE = restate peer's argument in own words to confirm listening; CITE = quote or reference exact textual location (page, speaker, context); EXTEND = add analytical layer (theme, device, contradiction, implication); INVITE = pose a follow-up question that opens the floor.

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
linguistic

## CROSS_SUBJECT
c11_history_nationalism | The story's critique of colonial-era formal education (professor's degrees vs. fe;k¡'s indigenous pedagogy) parallels History's examination of Macaulay's Minute and the "downward filtration" theory — both question whose knowledge counts as legitimate.
c11_political_science_democracy | The power dynamic between professor (institutional authority) and fe;k¡ (subaltern voice) mirrors PolSci's study of epistemic injustice and participatory democracy — discussion itself models inclusive deliberation where marginalized knowledge (oral teaching) challenges certified expertise.
c11_sociology_social_change | The "three stages of life" poem (childhood/youth/old age mapped to learning spaces) reflects Sociology's life-course perspective on education as social reproduction vs. transformation — fe;k¡'s streetlight teaching disrupts institutional isomorphism.

## PREREQ_CONCEPT
The student must understand that literary discussion is a collaborative evidence-game, not an opinion-exchange — every claim must be traceable to a textual anchor, and every response must visibly build on the previous speaker's point.

## PREREQ_BEFORE
Before starting, the student should have completed nodes 001-014 and be able to: locate any scene in the text within 30 seconds, define all vocabulary terms from node 010, and state the primary theme in one sentence with two supporting quotes.

## PREREQ_STUCK
If stuck, return to node 013 (Critical Thinking) and redo the "evidence-to-interpretation" ladder exercise: take one quote, write three increasingly abstract inferences, then practice saying them aloud as LQB moves.

## WORKED_EXAMPLE_1
PROBLEM: A student freezes when asked to discuss "the role of the child in fe;k¡'s pedagogy." They know the child appears on page 25 but cannot generate a discussion-worthy point.

STEPS:
- Step 1: Identify the textual anchor — reread page 25 where fe;k¡ teaches the child "vfyI+kQ → cs → the" under the streetlight. Note the narrator's description: "lekI+kQ" (profound) and the child's perfect repetition.
- Step 2: Connect to prior nodes — Node 004 (protagonist) shows fe;k¡ values oral transmission; Node 008 (imagery) identifies streetlight as "knowledge in darkness"; Node 010 (vocabulary) defines "v[kckjuohl" as one who makes/reads literature — fe;k¡ is redefining it.
- Step 3: Formulate an interpretive claim using LQB structure: "The child isn't just a plot device — fe;k¡ uses the child to prove that literature (v[kckj) begins in embodied, communal speech, not textbooks."
- Step 4: Anticipate a peer counter: "But the child is illiterate too — so it's just ignorance passing to ignorance." Prepare a rebuttal quote: "fe;k¡ says 'ge crZu èkksuk u lh[krs / ge Hkêòh cukuk u lh[krs' — he's rejecting the professor's literacy, not literacy itself."
- Step 5: Synthesize into a discussion move: "So the child represents the next generation learning on fe;k¡'s terms — oral, rhythmic, contextual. Who wants to challenge that reading?"

REASONING: This models how to transform a passive "I know this scene" into an active discussion intervention by layering textual precision (Step 1), conceptual scaffolding from prior nodes (Step 2), claim formulation (Step 3), counter-anticipation (Step 4), and collaborative invitation (Step 5).

ANSWER: The student can now enter the discussion with a 45-second opening move that cites text, invokes themes, and invites response — exactly what the ASL rubric rewards.

## WORKED_EXAMPLE_2
PROBLEM: During a group discussion, two students argue: Student A says "The professor is the villain." Student B says "No, fe;k¡ is a fraud." The discussion stalls in binary moralizing.

STEPS:
- Step 1: Diagnose the stall — both claims are character judgments without textual warrants or thematic stakes. Neither uses LQB.
- Step 2: Intervene with a process question: "Can each of you give one line that makes you say that?" (Forces CITE move).
- Step 3: Student A cites: "Professor says 'vkius [kkunkuh ukuckbZ gksus dk f"kØ fd;k' — mocking fe;k¡'s identity." Student B cites: "fe;k¡ lies about knowing the clerk's name — 'gks rks pqdh lkfgc] ij tkuuk ;g Fkk'."
- Step 4: Reframe using Node 009 (irony): "Notice — the professor's 'education' enables arrogance; fe;k¡'s 'deception' exposes the professor's ignorance. The story isn't judging characters — it's judging systems."
- Step 5: Synthesize: "So the real discussion isn't 'who's good' but 'how does the text use irony to show that institutional literacy produces ethical illiteracy?' Now — who has a quote about the clerk (ckn'kkg lyker)?"

REASONING: This demonstrates the teacher/facilitator role in modeling LQB to elevate stalled peer talk. Steps 1-2 enforce evidence; Steps 3-4 apply literary concepts (irony, system vs. individual); Step 5 redirects to a higher-order question requiring synthesis.

ANSWER: The discussion shifts from moral debate to literary analysis, with students now competing to find the best "ckn'kkg lyker" quote — e.g., "ckn'kkg lyker us [kwc [kkbZ vkSj [kwc ljkgh" (the clerk ate and laughed heartily) — to explore complicity.

## WORKED_EXAMPLE_3
PROBLEM: Design a 10-minute whole-class discussion plan for the question: "Does the story ultimately validate or subvert the guru-shishya tradition?" Must include: opening hook, 3 structured rounds, and a synthesis close — all using LQB.

STEPS:
- Step 1 (Hook): Play a 30-second audio of a traditional guru-shishya chant vs. fe;k¡'s streetlight teaching (page 25). Ask: "Which is the real guru-shishya?" — surfaces preconceptions.
- Step 2 (Round 1 - Textual Mapping): In pairs, students find 3 scenes where guru-shishya dynamics appear (e.g., professor→fe;k¡, fe;k¡→child, clerk→professor). Each pair shares one scene + quote. Teacher maps on board: "Who teaches whom? What is transmitted?"
- Step 3 (Round 2 - Thematic Tension): Using Node 007 (secondary themes), groups debate: "Is fe;k¡ a guru? He has no degrees, no institution, but the child learns. The professor has degrees but teaches nothing." Groups must use "uxhuklk”k" and "ehuklk”k" in arguments.
- Step 4 (Round 3 - Polyphonic Synthesis): Assign roles: fe;k¡, professor, child, narrator, clerk. Each role speaks once: "My character would say the tradition is [validated/subverted] because [quote]." No repetition allowed.
- Step 5 (Close): Teacher models synthesis: "We heard five voices. The tradition is neither validated nor subverted — it's relocated. The streetlight replaces the study. Oral rhythm replaces written exam. The guru is the one who makes the learner say 'vfyI+kQ' — wherever that happens."
- Step 6 (Exit Ticket): Each student writes one new question the discussion raised for them — e.g., "Can streetlight pedagogy scale?" — linking to Node 014 (writing) and future inquiry.

REASONING: This plan operationalizes all prior nodes: Round 1 uses plot (002) and character (004/005); Round 2 uses themes (006/007) and vocabulary (010); Round 3 uses irony (009) and polyvocality (013); Close models the synthesis expected in board exam speaking tasks. The 6-step structure ensures cognitive progression from recall to creation.

ANSWER: A discussion plan that is time-bound, role-structured, evidence-mandatory, and conceptually layered — directly usable for ASL practice and teacher observation.

## COMPETENCY_QUESTION_1
QUESTION: In a 3-minute discussion on "fe;k¡ ulh#íhu's critique of certificated knowledge," a student says: "The author hates degrees — fe;k¡ wins because he's real." Using the LQB protocol, respond by: (1) paraphrasing the claim, (2) citing a textual detail that complicates it, (3) extending the interpretation to include the narrator's role, and (4) inviting a peer to examine the ending's ambiguity.

COMPETENCY: Collaborative Literary Argumentation — the ability to engage a peer's claim with textual precision, conceptual nuance, and discursive generosity.

STEPS:
- Step 1: Paraphrase — "You're arguing the story privileges lived wisdom over paper credentials, and fe;k¡ embodies that victory."
- Step 2: Cite complication — "But on page 28, the narrator calls fe;k¡ 'dgkor' (storyteller) and says 'dgkor tc Hkh x<+h xbZ gks] gekjs cq"qxks± osQ djrc ij gh iwjh mrjrh gS' — the storyteller returns to the margins. Victory isn't simple."
- Step 3: Extend to narrator — "The narrator is complicit — they record fe;k¡'s brilliance but also his erasure. The text preserves what the system discards."
- Step 4: Invite — "So is the ending a win, a preservation, or a warning? Who has a line about the 'streetlight' that decides?"

ANSWER: A complete LQB response that validates the peer, introduces irony (fe;k¡'s marginalization persists), shifts from character to narrative structure, and opens the floor with a focused textual question. This demonstrates all four LQB moves fluently.

DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: You are facilitating a discussion where three students have spoken: Student 1: "fe;k¡ is a trickster." Student 2: "He's a truth-teller." Student 3: "He's both — that's the point." The discussion is circling. Design the next 2 minutes of facilitation moves (using only LQB-aligned interventions) to push the group toward a synthesized, textually grounded conclusion about the story's genre-blending (comedy/satire/tragedy).

COMPETENCY: Discussion Facilitation & Synthesis — the ability to diagnose a stalled peer discussion and intervene with structured moves that elevate analytical depth without dominating.

STEPS:
- Step 1: Diagnose aloud — "We have three claims: trickster, truth-teller, both. All plausible. But none yet anchored in the story's generic signals. Let's test each against the text's tone shifts."
- Step 2: Assign a targeted evidence hunt — "Student 1, find a 'trickster' moment in the clerk scene (page 27). Student 2, find a 'truth-teller' moment in the professor confrontation (page 24). Student 3, find where the tone shifts from comedy to something darker (page 25-26). One minute."
- Step 3: Structure the share-out as LQB — Each reports: "My claim: [trickster/truth-teller/shift]. My quote: [exact line]. This suggests the genre is [satire/tragicomedy/...] because..."
- Step 4: Synthesize live — "So: the clerk scene (trickster) uses comedy to expose corruption; the professor scene (truth-teller) uses satire to puncture authority; the streetlight scene (shift) uses pathos to mourn lost pedagogies. The story blends genres to show that fe;k¡'s wisdom survives only in the margins — a tragicomic resistance."
- Step 5: Close with a transfer question — "If this story were written today, what 'streetlight' would fe;k¡ teach under? What 'professor' would he mock?"

ANSWER: A facilitation sequence that redirects stalled character debate to genre analysis via targeted evidence retrieval, enforces LQB sharing, models synthesis using textual mapping, and ends with a contemporary transfer question — all in ~2 minutes. This mirrors the "critical thinking to speaking" bridge the board exam assesses.

DIFFICULTY: hard