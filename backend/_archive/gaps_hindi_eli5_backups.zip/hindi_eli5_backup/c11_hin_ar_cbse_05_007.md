## DEFINITION
Secondary themes are the underlying ideas or messages in a literary work that support, contrast, or complement the primary theme, often exploring specific social, psychological, or moral dimensions through subplots, character interactions, or symbolic elements.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student must be able to identify at least three secondary themes in "xyrk yksgk," provide textual evidence for each, and explain how each secondary theme interacts with the primary theme of caste-based oppression.

## SCOPE_BOUNDARY
This node covers identification and analysis of secondary themes in the story "xyrk yksgk" (Chapter 5 of Aroh). It does not cover primary theme analysis (covered in node 006) or literary devices (covered in nodes 008-009).

## WALKTHROUGH
Have you ever noticed how a movie might be mainly about a hero's journey, but also shows side stories about friendship, corruption, or gender roles? Those are secondary themes. In 'xyrk yksgk,' the primary theme is caste oppression, but the story also reveals other themes. To find them, look for recurring patterns: How is Eksgu treated in school vs at home? What does Thakur Phakir Singh say vs do? How does the narrator Iqbal react? Jot down these observations, then group them into broader ideas like 'hypocrisy of the privileged' or 'denial of education.' The key insight is that secondary themes deepen the primary theme by showing its many facets.

## DIAGNOSTIC_QUESTION_1
What is the definition of a secondary theme in literature?

## DIAGNOSTIC_ANSWER_1
A secondary theme is a subordinate idea that runs parallel to the primary theme, enriching the narrative by exploring additional social, moral, or psychological dimensions. A wrong answer (e.g., confusing it with the main message or a plot summary) reveals the student cannot distinguish between central and supporting thematic layers.

## DIAGNOSTIC_QUESTION_2
In "xyrk yksgk," the primary theme is caste-based oppression. Explain in your own words how the theme of 'hypocrisy of the upper caste' functions as a secondary theme. Give one example from the text.

## DIAGNOSTIC_ANSWER_2
The hypocrisy of the upper caste is shown through Thakur Phakir Singh who pretends to be benevolent but actually exploits Eksgu and denies him dignity. For instance, he makes Eksgu work like a servant while claiming to help him. A wrong answer that only describes plot events without linking to the theme of hypocrisy shows the student cannot abstract a thematic idea from concrete incidents.

## DIAGNOSTIC_QUESTION_3
Apply the concept of secondary themes to a new context: In a story about a girl fighting for education in a village, the primary theme is gender equality. List two possible secondary themes and briefly justify each with a hypothetical plot point.

## DIAGNOSTIC_ANSWER_3
Possible secondary themes: (1) Poverty as a barrier to education – shown when the girl's family cannot afford books. (2) Generational conflict – shown when her grandmother opposes her schooling. A wrong answer that lists themes without connecting to hypothetical plot points indicates the student cannot apply the concept of thematic support through narrative details.

## DIAGNOSTIC_QUESTION_4
Analyze how the secondary theme of 'denial of education to lower castes' interacts with the primary theme of caste oppression in "xyrk yksgk." Use two specific textual references.

## DIAGNOSTIC_ANSWER_4
The denial of education reinforces caste oppression by ensuring Eksgu remains trapped in servitude. When Iqbal discovers Eksgu's name is on the school register but he never attended, it shows systemic exclusion. When Thakur Phakir Singh threatens to send Eksgu to the city for education but actually uses him as labor, it reveals education as a tool of manipulation. A wrong answer that treats the two themes as separate shows the student cannot analyze thematic interplay.

## DIAGNOSTIC_QUESTION_5
Evaluate the effectiveness of the secondary theme 'resilience of the marginalized' in "xyrk yksgk." Does it strengthen or weaken the story's critique of caste? Justify your judgment.

## DIAGNOSTIC_ANSWER_5
It strengthens the critique because Eksgu's quiet dignity (e.g., continuing to work despite abuse, not complaining) highlights the inhumanity of his oppressors by contrast. If the theme were portrayed as passive acceptance, it might weaken the critique, but the text shows his resilience as a form of silent resistance. A wrong answer that merely praises the character without evaluating thematic function shows the student cannot critically assess literary choices.

## DIAGNOSTIC_QUESTION_6
Create a short paragraph (4-5 sentences) that introduces a new secondary theme for "xyrk yksgk" not discussed in class, supported by an imaginary but plausible scene from the story.

## DIAGNOSTIC_ANSWER_6
A plausible new secondary theme: 'The complicity of silent bystanders.' Scene: The village schoolteacher sees Eksgu working in Thakur's fields during school hours but says nothing, fearing the Thakur's power. This would extend the critique beyond active oppressors to those who enable oppression through silence. A poor answer that invents a theme contradicting the story's tone (e.g., a sudden magical rescue) reveals the student cannot maintain textual consistency while creating thematic extensions.

## COMMON_MISCONCEPTION
Students often think secondary themes are just 'subplots' or 'minor topics' and list plot events (e.g., 'Eksgu goes to the city') instead of abstract ideas (e.g., 'the false promise of urban escape'). They also confuse secondary themes with literary devices (e.g., 'irony is a secondary theme'). This happens because they focus on what happens rather than what the events signify about human experience or society.

## ON_FAILURE
If a student lists plot events, ask: "What larger idea about society or human nature does this event represent?" Guide them to complete the sentence: "This event shows that ______." Then help them generalize: "So the secondary theme is ______." If they confuse with literary devices, clarify: "Irony is a technique the author uses to reveal the theme of hypocrisy. The theme is the idea; irony is the tool."

## BUILDS_ON
This node builds on the ability to identify the primary theme (node 006) and character analysis (nodes 004-005) because secondary themes emerge from character actions and relationships.

## LEADS_TO
This node enables critical analysis of how multiple themes structure the narrative (node 013) and writing analytical essays on thematic complexity (node 014).

## PREREQUISITE_NODE_IDS
c11_hin_ar_cbse_05_004, c11_hin_ar_cbse_05_005, c11_hin_ar_cbse_05_006
## PREREQUISITE_REASONS
c11_hin_ar_cbse_05_004: Understanding the protagonist Eksgu's characterization is essential to see how his experiences embody secondary themes like resilience and denial of education.
c11_hin_ar_cbse_05_005: Supporting characters like Thakur Phakir Singh and Iqbal enact the secondary themes of hypocrisy and complicity.
c11_hin_ar_cbse_05_006: The primary theme of caste oppression provides the anchor; secondary themes must be analyzed in relation to it.

## FORWARD_NODE_IDS
c11_hin_ar_cbse_05_013, c11_hin_ar_cbse_05_014, c11_hin_ar_cbse_05_008, c11_hin_ar_cbse_05_015, c12_hin_a_cbse_01_007, c12_hin_a_cbse_05_007, c12_hin_a_cbse_08_007, c12_hin_a_cbse_10_007, c12_hin_ar_cbse_05_007, c12_hin_ar_cbse_07_007

## FORWARD_REASONS
c11_hin_ar_cbse_05_013: Critical thinking requires analyzing how multiple themes interact, which is built on identifying secondary themes.
c11_hin_ar_cbse_05_014: Writing skills tasks often ask for thematic essays; knowing secondary themes provides content for structured arguments.
c11_hin_ar_cbse_05_008: Secondary themes (childhood, gender, education) are illuminated by specific sensory details.  
c11_hin_ar_cbse_05_015: Secondary themes (education, modernity, hypocrisy) allow nuanced arguments beyond the main theme.  
c12_hin_a_cbse_01_007: Chapter 5 added historical context as thematic layer.  
c12_hin_a_cbse_05_007: Class 11 Antra Chapter 5 covered secondary themes in a different text, building the conceptual skill.  
c12_hin_a_cbse_08_007: अगला तार्किक चरण: Secondary themes are the underlying, complementary ideas in a literary work that support, contrast w... इस नोड की अवधारणाओं को सीधे उपयोग/विस्तारित करता है।  
c12_hin_a_cbse_10_007: Develops skill of distinguishing theme from plot/event.  
c12_hin_ar_cbse_05_007: Class 11 foundation on secondary themes provides the analytical vocabulary (motif, recurrence, thematic function) needed for Class 12 depth.  
c12_hin_ar_cbse_07_007: Chapter 5 application  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
none

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_05_006 -> c11_hin_ar_cbse_05_007 -> c11_hin_ar_cbse_05_013

## THIS_FORMULA
N/A - conceptual

## FORMULA_VARIABLES
N/A

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
conceptual

## CROSS_SUBJECT
c11_sociology_social_stratification | The story illustrates caste-based stratification and its impact on education and labor, core concepts in sociology.
c11_political_science_social_justice | The themes of hypocrisy, complicity, and denial of rights connect to political science discussions on social justice and marginalized communities.

## PREREQ_CONCEPT
The student must understand the difference between a primary theme (the central message) and secondary themes (supporting ideas that add depth).

## PREREQ_BEFORE
The student should have completed the analysis of the primary theme and character sketches for Eksgu, Thakur Phakir Singh, and Iqbal.

## PREREQ_STUCK
If stuck, review the character analysis of Thakur Phakir Singh (node 005) and the primary theme of caste oppression (node 006).

## WORKED_EXAMPLE_1
PROBLEM: Identify the secondary theme of 'hypocrisy of the privileged' in "xyrk yksgk" and provide two pieces of textual evidence with explanation.

STEPS:
- Step 1: Recall the primary theme (caste oppression) and define the secondary theme 'hypocrisy of the privileged' as the gap between professed values and actual behavior of upper-caste characters.
- Step 2: Scan the text for scenes where Thakur Phakir Singh or other upper-caste characters speak kindly but act exploitatively.
- Step 3: Select Evidence 1: Thakur Phakir Singh tells Eksgu he will send him to the city for education but instead makes him do household labor. This shows false benevolence.
- Step 4: Select Evidence 2: Thakur Phakir Singh claims to treat Eksgu like a son but denies him basic dignity (e.g., making him sit on the floor, not letting him eat with them). This reveals the performance of kindness.
- Step 5: Explain how each evidence supports the theme: The contrast between words and actions exposes hypocrisy as a mechanism to maintain caste hierarchy while appearing moral.
- Step 6: Connect to primary theme: Hypocrisy masks oppression, making it harder to challenge because it wears a mask of generosity.

REASONING: This step-by-step moves from definition to evidence selection to thematic explanation, modeling how to ground abstract themes in concrete textual moments.

ANSWER: The secondary theme 'hypocrisy of the privileged' is demonstrated by Thakur Phakir Singh's false promises of education and his performative kindness that conceals exploitation. This theme deepens the primary theme by showing how caste oppression operates through deception as well as force.

## WORKED_EXAMPLE_2
PROBLEM: Trace the secondary theme 'denial of education as a tool of caste control' across three key moments in the story.

STEPS:
- Step 1: Define the theme: Education is deliberately withheld or manipulated to keep lower-caste children in servitude.
- Step 2: Locate Moment 1: Eksgu's name is on the school register but he never attends; Iqbal discovers this. This shows systemic erasure.
- Step 3: Locate Moment 2: Thakur Phakir Singh threatens to send Eksgu to the city for education but actually uses him as free labor. This shows education as a bait.
- Step 4: Locate Moment 3: When Eksgu finally gets a chance to learn (Iqbal tries to teach him), the Thakur's household disrupts it, and Eksgu's exhaustion prevents learning. This shows structural barriers.
- Step 5: Analyze the pattern: Each moment shows a different mechanism—bureaucratic neglect, deceptive promises, physical exhaustion—all serving caste control.
- Step 6: Synthesize: The theme is not just 'Eksgu is uneducated' but 'the system ensures he stays uneducated.'

REASONING: This example teaches tracing a theme across the narrative arc, showing how recurring motifs build a thematic argument.

ANSWER: The theme 'denial of education as a tool of caste control' appears in (1) the fake school enrollment, (2) the broken promise of city education, and (3) the sabotage of informal learning. Together they reveal education denial as an intentional strategy of oppression.

## WORKED_EXAMPLE_3
PROBLEM: Compare the secondary themes 'resilience of the marginalized' and 'complicity of the educated bystander' in "xyrk yksgk." How do they create tension in the narrative?

STEPS:
- Step 1: Define both themes: Resilience = Eksgu's quiet endurance and dignity; Complicity = Iqbal's awareness but inaction.
- Step 2: Find evidence for resilience: Eksgu works tirelessly, bears insults, never rebels openly, yet maintains self-respect (e.g., when he refuses to eat leftovers secretly).
- Step 3: Find evidence for complicity: Iqbal observes everything, feels pity, but does not confront Thakur Phakir Singh effectively; he rationalizes his inaction.
- Step 4: Analyze interaction: Eksgu's resilience makes Iqbal's complicity more glaring— the victim's strength highlights the bystander's weakness.
- Step 5: Explain narrative tension: The reader hopes Iqbal will act because Eksgu deserves better; the gap creates moral tension.
- Step 6: Conclude: This tension forces the reader to question their own potential complicity in real-life injustices.

REASONING: This advanced example requires comparing two themes and evaluating their combined effect, a higher-order skill for board exams.

ANSWER: The themes create tension by juxtaposing Eksgu's silent strength with Iqbal's passive observation. Eksgu's resilience makes Iqbal's inaction morally uncomfortable, turning the story into a critique not just of the oppressor but of the silent witness.

## COMPETENCY_QUESTION_1
QUESTION: In "xyrk yksgk," the secondary theme of 'urban vs. rural values' appears through Eksgu's brief stay in the city. Explain how this theme contrasts with the primary theme of caste oppression. Provide two textual details to support your answer.

COMPETENCY: Thematic analysis and textual evidence integration

STEPS:
- Step 1: Identify the secondary theme: The city represents anonymity, mobility, and relative equality compared to the village's rigid caste hierarchy.
- Step 2: Recall textual details: Eksgu experiences freedom in the city (e.g., he can walk on the road, no one asks his caste). In the village, he is confined to servitude.
- Step 3: Explain the contrast: The urban space temporarily suspends caste oppression, highlighting how caste is a social construct enforced in the village.
- Step 4: Conclude: This contrast underscores that caste oppression is not natural but locally enforced, strengthening the critique.

ANSWER: The urban-rural contrast shows that caste oppression is spatially contingent. In the city, Eksgu experiences dignity (e.g., walking freely, not being questioned about caste), while in the village he is reduced to a servant. This contrast reveals caste as a socially enforced hierarchy, not an inherent truth, thereby deepening the primary theme's critique.

DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: The story ends with Eksgu returning to the village and resuming his servitude. Some readers argue this ending reinforces the secondary theme 'inevitability of caste fate,' while others say it highlights 'the failure of individual resistance without structural change.' Evaluate both interpretations and state which is better supported by the text. Justify with three textual references.

COMPETENCY: Critical evaluation of thematic interpretation with evidence

STEPS:
- Step 1: Outline Interpretation A: The ending shows caste fate is inescapable; Eksgu's return proves the system always wins.
- Step 2: Outline Interpretation B: The ending shows individual kindness (Iqbal's) cannot dismantle caste; structural change is needed.
- Step 3: Textual Reference 1: Thakur Phakir Singh's power remains unchallenged; he summons Eksgu back effortlessly.
- Step 4: Textual Reference 2: Iqbal's attempts (teaching, offering help) are piecemeal and fail to alter Eksgu's condition.
- Step 5: Textual Reference 3: The village social order (schoolteacher's silence, neighbors' acceptance) shows collective complicity.
- Step 6: Judge: Interpretation B is better supported because the text emphasizes systemic forces (Thakur's authority, institutional neglect, social silence) over fatalism. Eksgu's return is due to structural power, not destiny.
- Step 7: Formulate answer with clear stance and evidence.

ANSWER: Interpretation B is stronger. The text shows Eksgu's return results from Thakur Phakir Singh's unchecked power (he sends a cart to fetch Eksgu), Iqbal's ineffective individual efforts (teaching him briefly but not challenging the Thakur), and the village's collective silence (schoolteacher, neighbors). The story critiques the structure, not destiny.

DIFFICULTY: hard