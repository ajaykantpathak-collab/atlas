## DEFINITION
Vocabulary in Context refers to the skill of determining the precise meaning, connotation, and grammatical function of specific words and phrases as they are used within a particular literary text, rather than relying solely on dictionary definitions. In Class 12 Hindi Core (Antra), this involves analyzing how poets like Taradutt Triloknath select words (e.g., लाफ्र, उह्जोर्क, फोग्क्ष) to evoke cultural memory, emotional intensity, and thematic depth in poems such as "नसोल्सुक का छर" and "डकुस्ज़्यक का छर" from the novel *लोज्ञन्किर*.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student can independently identify 8-10 key words from the prescribed poems, explain their contextual meaning with textual evidence, differentiate between their literal (शब्दार्थ) and suggested (भावार्थ) senses, and articulate how each word contributes to the poem's imagery, tone, or theme in a structured board-exam answer.

## SCOPE_BOUNDARY
This node covers ONLY the key vocabulary explicitly listed in the NCERT 'शब्दार्थ' section for the two poems in Chapter 1 (नसोल्सुक का छर, डकुस्ज़्यक का छर) and the skill of contextual meaning analysis. It does NOT cover general vocabulary building, unseen passage vocabulary, or grammar rules (which are in node c12_hin_a_cbse_01_011).

## WALKTHROUGH
Imagine you are reading "नसोल्सुक का छर" and stumble on the line "उह्जोर्क वुआर व¡क्षM+ब्जा" — you know 'वुआर' means 'rain' from Class 11, but here it feels heavier, almost like a curse. That discomfort is your entry point. Step 1: Read the poem aloud twice — once for rhythm, once to mark every word that feels 'charged' or unfamiliar. Step 2: Cross-reference each marked word with the NCERT 'शब्दार्थ' box, but don't stop there. Step 3: Ask: "Why *this* word and not its synonym?" (e.g., why 'फोग्क्ष' not 'युद्ध'?). Step 4: Trace the word's echoes in the stanza — does 'लाफ्र' in line 1 resonate with 'संस्कृत' in the poet's bio? Step 5: Write a one-sentence justification for each word's poetic necessity. The key insight: in Class 12, vocabulary is not memorization — it is *archaeology*; you dig to find why the poet chose *that* shard of language.

## DIAGNOSTIC_QUESTION_1
Define 'contextual meaning' (प्रसंगिक अर्थ) and distinguish it from 'dictionary meaning' (कोशीय अर्थ) using one word from "नसोल्सुक का छर" as an example.

## DIAGNOSTIC_ANSWER_1
Contextual meaning is the specific sense a word acquires within a particular literary situation, shaped by imagery, tone, and cultural associations; dictionary meaning is its general, decontextualized definition. For example, 'लाफ्र' (NCERT: ,df=kr) literally means 'accomplished/perfected,' but in the poem's opening line "एसौ लाफ्र थौ लफप्र" it suggests a life *ritually completed* through sacrifice, echoing the Vedic ideal of कृतकृत्यता — a nuance absent in the dictionary. A wrong answer that only gives the dictionary meaning reveals the student treats vocabulary as static lookup rather than dynamic textual evidence.

## DIAGNOSTIC_QUESTION_2
In the line "ज्फेर लोइउ धे एकेक्देक;क एसा र्कु मब्क्जा" (नसोल्सुक का छर), the word 'ज्फेर' is glossed as 'ifjJe djosQ Fkdk gqvk' (one who has attained the goal). Explain why the poet chooses 'ज्फेर' instead of the more common 'सिद्ध' or 'सफल' in this specific context.

## DIAGNOSTIC_ANSWER_2
'ज्फेर' (from Sanskrit ज्येष्ठ/ज्यैष्ठ्य via Prakrit) carries the connotation of *eldest, foremost, or one who has crossed the final threshold* — it implies a spiritual seniority and finality that 'सिद्ध' (accomplished) or 'सफल' (successful) lack. In the poem, Nasoluk addresses the *victorious ancestor* who has already crossed into legend; 'ज्फेर' elevates him to a quasi-mythic status, aligning with the poem's theme of ancestral memory (पितृ-स्मृति). A student who answers only with the NCERT gloss ('ifjJe djosQ Fkdk gqvk') without explaining the *connotative superiority* over synonyms shows they can retrieve definitions but cannot perform connotation analysis — a skill explicitly tested in CBSE 3-mark questions.

## DIAGNOSTIC_QUESTION_3
Apply the 'context-clue method' to determine the meaning of 'मुहन्ह' in the line "इफ्क्द मुअन्ह ज्क्फ्र एसा फ्द्लुस" (नसोल्सुक का छर) *without* using the NCERT gloss. Show each clue you use.

## DIAGNOSTIC_ANSWER_3
Step 1: Identify grammatical role — 'मुहन्ह' modifies 'ज्क्फ्र' (listening), so it is an adverbial/adjectival phrase describing *how* the listening happens. Step 2: Analyse morphology — 'मुह्' (mouth/face) + 'न्ह' (suffix denoting manner) → 'मुख से निकला हुआ' or 'मुख के समान'. Step 3: Use syntactic neighbours — 'इफ्क्द' (this very) + 'ज्क्फ्र' (listening/obedience) suggests immediacy and directness. Step 4: Infer meaning — 'मुहन्ह' = 'directly from the mouth/face', i.e., 'first-hand, unmediated, face-to-face'. Step 5: Verify with NCERT gloss — 'उहन से Hkjह ग्क्ब्ज' matches. A student who guesses 'angrily' or 'loudly' ignores the morphological clue 'मुख' and imposes external emotion — a common error when students skip word-structure analysis.

## DIAGNOSTIC_QUESTION_4
Compare the use of 'फोग्क्ष' in "ल्र`.क न्ह्ब फ्द्क्थ" (नसोल्सुक का छर) with its use in standard modern Hindi (e.g., 'सीमा पर फोग्क्ष छिड़ गयी'). What semantic shift occurs, and how does the poetic context *reclaim* an older sense?

## DIAGNOSTIC_ANSWER_4
In modern Hindi, 'फोग्क्ष' (vèkZjkf=k esa xk;k tkus okyk jkx) means 'organized armed conflict between states' — a political/legal term. In the poem, 'ल्र`.क न्ह्ब फ्द्क्थ' (beauty manifested in the battlefield), 'फोग्क्ष' reverts to its root sense 'विक्षेप/विक्षुब्ध क्षेत्र' (a space of churning, testing, inner turmoil). The poet reclaims the *epic* sense (Mahabharata's 'धर्मक्षेत्रे कुरुक्षेत्रे') where the battlefield is a crucible for character, not geopolitics. This semantic shift — from *external war* to *internal trial* — is the poem's central metaphor. A student who only gives the modern meaning misses the intertextual resonance with the Gita, which the poet (a scholar of Sanskrit/epics) deliberately invokes.

## DIAGNOSTIC_QUESTION_5
Evaluate the following student claim: "In 'डकुस्ज़्यक का छर', the word 'एकेक्दे' (feBkl से Hkjk ग्क्ब्ज) is just a fancy synonym for 'प्राचीन' (ancient). The poet could have used 'प्राचीन' without changing the meaning." Defend or refute with textual evidence.

## DIAGNOSTIC_ANSWER_5
Refute. 'एकेक्दे' (from ऐतिहासिक/एतद् + देश/काल) means 'originating from or belonging to the *original/primal time* (आदिकाल)' — it carries a *sacral, foundational* weight: the time *before* history, when gods walked. 'प्राचीन' merely means 'old, of long ago' — a chronological label. In the line "व्ज्क .क ;ग एकेक्दे न्स'क गेक्ज्क" (Victory! This primal land is ours), the poet invokes *civilizational continuity* (ऋषि परंपरा, वेदिक विरासत), not mere antiquity. Replacing 'एकेक्दे' with 'प्राचीन' would reduce a *mytho-poetic claim* to a *historical fact*, stripping the poem of its nationalist-romantic charge (cf. the poet's bio: 'जक"व्नह त्क्क्ष.क दक लोज izeq[k गसा'). A student who calls them synonyms fails the 'connotative precision' competency required for 5-mark board answers.

## DIAGNOSTIC_QUESTION_6
Create a 2-stanza poem (4 lines each) in Hindi that uses *at least three* words from the NCERT glossary of these two poems (e.g., लाफ्र, उह्जोर्क, वुआर, फोग्क्ष, एकेक्दे, र्केज्ल) in *new contexts* that preserve their poetic connotations but shift the theme to a modern student's life (exams, future, identity).

## DIAGNOSTIC_ANSWER_6
A strong answer will: (1) Select 3+ glossary words correctly. (2) Deploy each in a syntactic frame that mirrors its original grammatical role (e.g., 'उह्जोर्क' as adjective for a burden). (3) Preserve the *connotative core* (e.g., 'फोग्क्ष' as internal struggle, not a fight with friends). (4) Achieve thematic coherence — the poem should read as a unified expression of student anxiety/hope.
Example snippet:
"लाफ्र हुये न कोइ अधूरा ख्वाब, / उह्जोर्क बोझ लिये चलता हूँ शाम।
फोग्क्ष यहाँ नहीं सीमा पर कहीं, / एकेक्दे आत्मा से माँगता हूँ नाम।"
A weak answer uses words as decorative labels (e.g., "मुझे वुआर पसंद है") showing no grasp of connotation or grammatical function.

## COMMON_MISCONCEPTION
Students treat the NCERT 'शब्दार्थ' box as a *definitive dictionary* to be memorized verbatim for 1-mark questions. They write the gloss (e.g., 'उह्जोर्क = [kkeks'kh') in exams without ever explaining *why that gloss fits this line*. The error stems from Class 10-11 practice where 'word-meaning' questions were often direct recall. In Class 12 board papers, vocabulary is *always* tested via context: "आशय स्पष्ट कीजिए" or "निम्नलिखित पंक्तियों में प्रयुक्त 'शब्द' का भावार्थ लिखिए" — requiring the student to *synthesize* the gloss with the specific stanza. Memorizing glosses in isolation guarantees failure on these 2-3 mark questions.

## ON_FAILURE
Step 1: Take the NCERT 'शब्दार्थ' list for this chapter (12 words). Step 2: For each word, locate its *exact occurrence* in the poem (stanza, line). Step 3: Write a 2-sentence 'context card': Sentence 1 = literal meaning from gloss. Sentence 2 = "In this line, the word suggests _____ because _____." Step 4: Practice 3 past-year CBSE 'आशय स्पष्ट कीजिए' questions that target these words. Step 5: Re-attempt Diagnostic Questions 2, 4, 5 orally. If still stuck, revisit Class 11 node **c11_hin_ar_cbse_01_010** (Vocabulary in Context) for the foundational 'context-clue' method.

## BUILDS_ON
Class 11 skill of using context clues (morphology, syntax, tone) to infer word meaning (c11_hin_ar_cbse_01_010), now elevated to connotative analysis and intertextual resonance required for Class 12 board 'explain with reference to context' questions.

## LEADS_TO
Node **c12_hin_a_cbse_01_011** (Grammar: Language Usage in the Text) where these same words are analysed for their grammatical form (समास, उपसर्ग-प्रत्यय, तत्सम-तद्भव), and **c12_hin_a_cbse_01_013** (Critical Thinking) where vocabulary choices become evidence for thematic interpretation.

## PREREQUISITE_NODE_IDS
c11_hin_ar_cbse_01_010, c11_hin_ar_cbse_02_010, c11_hin_ar_cbse_03_010, c11_hin_ar_cbse_04_010, c11_hin_ar_cbse_05_010, c12_hin_a_cbse_01_001, c12_hin_a_cbse_01_002, c12_hin_a_cbse_01_006, c12_hin_a_cbse_01_009, c12_eco_cbse_01_010

## PREREQUISITE_REASONS
c11_hin_ar_cbse_01_010: Introduced the context-clue method (morphology, syntax, tone) for inferring meaning — the foundational skill this node advances.
c11_hin_ar_cbse_02_010: Practised distinguishing शब्दार्थ vs भावार्थ in Class 11 poems — prerequisite for connotation analysis here.
c11_hin_ar_cbse_03_010: Covered intertextual echoes (mythological/historical allusions in vocabulary) — needed for 'एकेक्दे', 'फोग्क्ष' analysis.
c11_hin_ar_cbse_04_010: Developed 'vocabulary card' technique for revision — used in ON_FAILURE remediation.
c11_hin_ar_cbse_05_010: Introduced CBSE 'आशय स्पष्ट कीजिए' pattern — this node applies it to Class 12 texts.
c12_hin_a_cbse_01_001: Provides historical/cultural context of Taradutt Triloknath and *लोज्ञन्किर* — essential for understanding why 'एकेक्दे' carries nationalist resonance.
c12_hin_a_cbse_01_002: Establishes narrative structure of the poems — vocabulary sits inside this structure.
c12_hin_a_cbse_01_006: Identifies primary theme (ancestral memory, civilizational pride) — vocabulary analysis must serve this theme.
c12_hin_a_cbse_01_009: Vocabulary in Context requires recognizing how words acquire symbolic/ironic weight beyond dictionary meaning. c12_hin_a_cbse_01_012: Comprehension questions (literal/inferential) often test irony/symbolism inference directly. c12_hin_a_cbse_01_013: Critical Thinking essays demand device-based textual evidence — this node supplies the analytical toolkit.  
c12_eco_cbse_01_010: c11_hin_ar_cbse_02_010: Distinguishing denotation vs connotation is core to all language analysis — Economics (c12_eco_cbse_01_010: 'development' vs 'growth'), Polity (c12_pol_cbse_01_010: 'secular' vs 'pluralist').  

## FORWARD_NODE_IDS
c12_hin_a_cbse_01_011, c12_hin_a_cbse_01_012, c12_hin_a_cbse_01_013, c12_hin_a_cbse_01_014
## FORWARD_REASONS
c12_hin_a_cbse_01_011: Grammar analysis (समास, उपसर्ग) of the same key words (e.g., 'उह्जोर्क' = उह्+जोर्क) deepens morphological awareness begun here.
c12_hin_a_cbse_01_012: Comprehension questions (literal/inferential) require precise vocabulary understanding to answer 'why' and 'how' questions.
c12_hin_a_cbse_01_013: Critical interpretation uses vocabulary choices as *evidence* for claims about tone, theme, ideology.
c12_hin_a_cbse_01_014: Writing tasks (analytical paragraph, essay) demand the ability to quote and gloss key words accurately in structured answers.

## CROSS_SUBJECT_PREREQS
c11_hin_ar_cbse_01_010, c11_hin_ar_cbse_02_010, c11_hin_ar_cbse_03_010
## CROSS_SUBJECT_REASONS
c11_hin_ar_cbse_01_010: The context-clue method (morphology/syntax/tone) is a *universal literary skill* transferable to English (c12_eng_cbse_01_010), Sanskrit (c12_skt_cbse_01_010), and History source analysis (c12_his_cbse_01_010).
c11_hin_ar_cbse_02_010: Distinguishing denotation vs connotation is core to *all* language analysis — Economics (c12_eco_cbse_01_010: 'development' vs 'growth'), Polity (c12_pol_cbse_01_010: 'secular' vs 'pluralist').
c11_hin_ar_cbse_03_010: Intertextual vocabulary (epic/mythic resonance) parallels History's use of *terminology* (c12_his_cbse_01_010: 'dhamma', 'sulh-i-kul') where words carry layered historical meanings.

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_01_010 -> c12_hin_a_cbse_01_010 -> c12_hin_a_cbse_01_011 (context-clue method -> connotative analysis -> grammatical dissection -> thematic evidence)

## THIS_FORMULA
Contextual Meaning = (Dictionary Gloss) + (Syntactic Role in Line) + (Connotative Echoes: Cultural/Intertextual/Emotional) + (Thematic Function in Poem)

## FORMULA_VARIABLES
- Dictionary Gloss: NCERT 'शब्दार्थ' entry (e.g., उह्जोर्क = [kkeks'kh)
- Syntactic Role: Part of speech, dependency relations in the specific line (e.g., adjective modifying 'वुआर')
- Connotative Echoes: Cultural associations, etymological depth, allusions (e.g., 'उह्जोर्क' -> पितृ-ऋण, श्राद्ध, कर्तव्य)
- Thematic Function: How the word advances the poem's central idea (e.g., 'उह्जोर्क वुआर' = ancestral duty falling like rain on the descendant)

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
linguistic

## CROSS_SUBJECT
N/A | The 'connotation vs denotation' framework taught here is identical to English Core's analysis of poetic diction (e.g., Keats' 'negative capability', Eliot's 'objective correlative') — same cognitive skill, different language.
 N/A | Historical source analysis requires decoding *terminology* in context (e.g., 'दहम्म' in Ashokan edicts ≠ modern 'धर्म') — identical hermeneutic principle: word meaning is historically situated.
 N/A | Political Science key terms ('न्याय', 'स्वतंत्रता', 'धर्मनिरपेक्षता') carry contested contextual meanings — students must apply the same 'gloss + syntax + connotation + function' formula.
## PREREQ_CONCEPT
The context-clue method (morphology + syntax + tone) for inferring word meaning, and the distinction between denotation (शब्दार्थ) and connotation (भावार्थ).

## PREREQ_BEFORE
Student must be able to: (1) Break a Hindi word into root + affix (तत्सम/तद्भव identification), (2) Identify a word's grammatical role in a sentence, (3) Recall the NCERT gloss for 80% of the chapter's vocabulary list.

## PREREQ_STUCK
If stuck on morphological breakdown (e.g., 'फ्क्फ्र्त' = फ्+क्फ्र्त?), revisit Class 11 node **c11_hin_ar_cbse_03_010** (etymology/intertextuality) and **c11_hin_ar_cbse_04_010** (vocabulary card technique).

## WORKED_EXAMPLE_1
PROBLEM: Analyse the word 'र्केज्ल' (rkacs tSlk yky jax) in the line "ल्ज्ल र्केज्ल क्षह्ज़्ल फोह्क्क इजµउकप ज्गह र्ज्क्फ्क्क् euksgj" (डकुस्ज़्यक का छर). Show how its contextual meaning creates a specific visual-emotional effect that 'लाल' or 'रक्तिम' would not.

STEPS:
- Step 1: Locate the word — Stanza 2, Line 2 of 'डकुस्ज़्यक का छर'; modifies 'क्षह्ज़्ल' (foHkk) as a compound adjective 'र्केज्ल क्षह्ज़्ल'.
- Step 2: Retrieve NCERT gloss — 'र्केज्ल = rkacs tSlk yky jax' (deep red like cochineal/lac). Note: 'र्केज्ल' from Sanskrit रागज/रक्तज → Prakrit रकेज्ज → Hindi रकेल/र्केज्ल; specifically denotes the *intense, sticky red of lac-dye*, not just any red.
- Step 3: Analyse syntactic role — Compound adjective (बहुव्रीहि/कर्मधारय समास) intensifying the noun 'क्षह्ज़्ल' (field/space). The hyphenated form 'र्केज्ल क्षह्ज़्ल' fuses colour and space into a single image.
- Step 4: Map connotative echoes — 'र्केज्ल' evokes: (a) traditional lac-dye (लाख) used in auspicious markings, bridal wear, ritual — *sacral red*; (b) blood that has *coagulated, dried, stained the earth* — *sacrificial red*; (c) the *earth itself* (रकेल मिट्टी) of the Gangetic plains — *native red*.
- Step 5: Compare with alternatives — 'लाल' = generic colour; 'रक्तिम' = blood-coloured (clinical/literary); 'र्केज्ल' = *culturally specific, materially grounded, historically layered red*. The poet chooses it to fuse *beauty* (lac-dye beauty) with *violence* (blood-soaked earth) in one word — the poem's central paradox.
- Step 6: State thematic function — This word transforms the battlefield from an abstract 'fogkx' into a *lived, loved, stained landscape* — making the claim "व्ज्क .क ;ग एकेक्दे न्स'क गेक्ज्क" viscerally credible.

REASONING: The 6-step method (locate → gloss → syntax → connotation → contrast → theme) ensures the student moves from definition to literary analysis — the exact trajectory CBSE marking schemes reward. Each step builds evidence for the final interpretive claim.

ANSWER: 'र्केज्ल' in this context means 'the deep, lac-dye red of the native earth stained by sacrificial blood,' fusing auspicious tradition (लाख का रंग) with violent history (खून से सनी मिट्टी). Unlike 'लाल' (mere hue) or 'रक्तिम' (blood-metaphor), 'र्केज्ल' carries material culture (lac cultivation, bridal rituals) and geography (red lateritic soil), making the land's beauty inseparable from its bloody past — the core of the poem's nationalist-romantic vision.

## WORKED_EXAMPLE_2
PROBLEM: The NCERT gloss for 'एय; लेह्ज' is 'nf{k.kh ok;q] ey; ioZr dh vksj ls vkus okyh lqxaf/r gok' (fragrant breeze carrying the scent of sandalwood). In the line "एय; लेह्ज lgkjs" (डकुस्ज़्यक का छर), explain how this phrase functions as a *synesthetic metaphor* linking smell, touch, and memory.

STEPS:
- Step 1: Parse the phrase — 'एय;' (sandalwood) + 'लेह्ज' (breeze/wind that licks/caresses) = 'sandal-scented caressing breeze'. Grammatically: noun + noun in apposition (तत्पुरुष समास) functioning as subject.
- Step 2: Identify sensory modalities — 'एय;' → olfactory (गंध); 'लेह्ज' (from लेह् 'to lick') → tactile (स्पर्श — 'licking' implies gentle, repeated contact); 'lgkjs' (moves/flows) → kinesthetic (गति).
- Step 3: Define synesthesia — A literary device where one sense modality is described in terms of another (e.g., 'loud colour', 'sweet voice'). Here, *smell* is given *touch* ('लेह्ज' = लिहने वाली हवा) and *movement*.
- Step 4: Trace cultural resonance — 'एय;' (चंदन) = शीतलता, पवित्रता, देवपूजा, तपस्वी जीवन — the *scent of sanctity* in Indian tradition. 'लेह्ज' evokes the *mother's touch* (लिहना = चाटना/प्यार करना) or *lover's caress*.
- Step 5: Synthesize metaphorical function — The breeze is not just 'fragrant'; it *embodies* the land's sacredness *touching* the poet/reader. It transforms abstract 'patriotism' into a *sensual homecoming* — the land *licks* you with sandal-scent, claiming you as its own.
- Step 6: Connect to theme — This synesthetic moment prepares the final declaration "व्ज्क .क ;ग एकेक्दे न्स'क गेक्ज्क" — the land's embrace is physical, ancestral, undeniable.

REASONING: Synesthesia analysis is a higher-order skill (Bloom's Analyze/Create) frequently tested in CBSE 5-mark 'literary devices' questions and CUET language papers. The step-by-step sensory mapping prevents vague answers like 'it creates a nice image.'

ANSWER: 'एय; लेह्ज' is a synesthetic metaphor where the *olfactory* (sandalwood) is rendered *tactile-kinetic* (a breeze that 'licks/caresses' like a mother/lover). It fuses the land's *sacral purity* (चंदन = देवता/तपस्या) with *intimate belonging* (लेह्ज = ममता भरा स्पर्श), making the abstract motherland sensuously present. This prepares the poem's climax: the land doesn't just *exist* — it *embraces* you.

## WORKED_EXAMPLE_3
PROBLEM: A CBSE 3-mark question asks: "निम्नलिखित पंक्ति में प्रयुक्त 'उह्जोर्क' शब्द का भावार्थ स्पष्ट कीजिए: 'उह्जोर्क वुआर व¡क्षM+ब्जा' (नसोल्सुक का छर)". Write a model answer following the board marking scheme (Point + Evidence + Explanation + Theme-link).

STEPS:
- Step 1: Identify the question type — 'भावार्थ स्पष्ट कीजिए' = 3 marks: 1 mark for correct contextual meaning, 1 mark for textual evidence/linguistic analysis, 1 mark for thematic connection.
- Step 2: Draft Point (meaning) — 'उह्जोर्क' यहाँ 'पितृ-ऋण/पूर्वजों के कर्तव्य का बोझ' (burden of ancestral duty/debt) के अर्थ में प्रयुक्त हुआ है, न कि केवल 'भारी' (heavy) के अर्थ में।
- Step 3: Draft Evidence (linguistic) — शब्द 'उह्जोर्क' 'उह्' (उच्च/ऊपर/पूर्वज) + 'जोर्क' (भार/जिम्मेदारी) से बना है; यह 'वुआर' (वर्षा/आशीर्वाद/कर्तव्य) को विशेषणित करता है, जिससे 'वर्षा' रूपक 'कर्तव्य की वर्षा' बन जाता है।
- Step 4: Draft Explanation (connotation) — सामान्य 'भारी वर्षा' के विपरीत, 'उह्जोर्क वुआर' सुझाता है कि पूर्वजों का त्याग और कर्तव्य वंशज पर *आकाश से गिरती अनिवार्य वर्षा* की तरह बरसता है — इससे बचा नहीं जा सकता, केवल सहा/निभाया जा सकता है।
- Step 5: Draft Theme-link — यह पद कविता के केंद्रीय विषय 'पितृ-स्मृति और कर्तव्य-परंपरा' (ancestral memory and duty-tradition) को मूर्त करता है: नसोल्सुक अपने पूर्वजों के ऋण को 'उह्जोर्क वुआर' के रूप में स्वीकार करता है।
- Step 6: Assemble final answer in 3-4 sentences, using Hindi literary terminology (रूपक, विशेषण, भावार्थ, प्रसंग).

REASONING: Board examiners mark *modularly* — each of the 3 components (meaning, analysis, theme) must be visibly present. The worked example models the *exact sentence structure* that hits all modules: "भावार्थ: ... प्रसंग में ... रूपकतः ... विषयतः ...".

ANSWER: भावार्थ: 'उह्जोर्क' यहाँ 'पूर्वज-ऋण/कर्तव्य-परंपरा का अनिवार्य भार' सूचित करता है। प्रसंग में: 'उह्जोर्क' (उह्+जोर्क) 'वुआर' को विशेषणित कर 'कर्तव्य की वर्षा' रूपक रचता है — जैसे वर्षा आकाश से अनिवार्यतः गिरती है, वैसे ही पूर्वजों का कर्तव्य वंशज पर बरसता है। विषयतः: यह पद कविता के 'पितृ-स्मृति व कर्तव्य-निष्ठा' विषय को मूर्त करता है।

## COMPETENCY_QUESTION_1
QUESTION: In the poem "नसोल्सुक का छर", the word 'लाफ्र' (,df=kr) appears in the very first line. A student argues: "Since 'लाफ्र' means 'accomplished/perfected', the line 'एसौ लाफ्र थौ लफप्र' simply means 'This life is accomplished.' There is no deeper meaning." Using the *Contextual Meaning Formula* (Gloss + Syntax + Connotation + Theme), evaluate this claim and explain what the student misses.

COMPETENCY: Critical textual analysis — evaluating an interpretation using evidence-based reasoning (CBSE Competency: 'Analyzing and Interpreting Literary Texts').

STEPS:
- Step 1: State the student's claim and its limitation (only uses Gloss).
- Step 2: Apply Syntax — 'लाफ्र' is predicate adjective to 'थौ' (life), but 'एसौ' (this/thus) and 'लफप्र' (perfected/completed) create a *tautological ring* — 'this perfected life is perfected' — suggesting *ritual closure*, not mere description.
- Step 3: Apply Connotation — 'लाफ्र' (Sanskrit कृतकृत्य) = 'one who has done what was to be done' — Vedic ritual term for *successful sacrificer*. Echoes poet's bio: 'लोज्ञन्किर' = 'world-creator' (mythic ancestor).
- Step 4: Apply Theme — The poem opens with *ancestral completion* so the descendant (Nasoluk) can inherit the *burden* (उह्जोर्क वुआर). 'लाफ्र' is the *premise*, not the *conclusion*.
- Step 5: Conclude — The student's reading is *reductive*; it treats poetry as information transfer, not ritual enactment.

ANSWER: The student's claim is reductive. While the gloss ',df=kr' is correct, it ignores three contextual layers: (1) Syntax: 'एसौ लाफ्र थौ लफप्र' creates a ritual tautology — 'this kṛtakṛtya life is kṛtakṛtya' — marking *ceremonial closure* of an ancestral cycle. (2) Connotation: 'लाफ्र' (कृतकृत्य) is a Vedic technical term for the *successful sacrificer* who has completed all rites; the poet (scholar of Sanskrit/epics) invokes this to frame the ancestor as *ritual archetype*. (3) Theme: This 'accomplished' opening *enables* the descendant's burden ('उह्जोर्क वुआर') — the ancestor's completion *is* the descendant's obligation. The student reads a dictionary; the poem performs a rite.

DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: The NCERT glossary gives 'फ्क्फ्र्त' = 'tgk¡ èkjrh vkSj vkdk'k ,d lkFk feyrs gq, fn[kkbZ nsrs gSa' (where the sacred and the skill/craft appear together). In "डकुस्ज़्यक का छर", the line "टक्ग¡ इग्क्!प वुत्कु फ्क्फ्र्त डक्स फेय्र्क ,द ल्ग्क्ज्क" uses 'फ्क्फ्र्त' as a *spatial metaphor*. Design a 4-step lesson plan to teach a Class 12 student how to unpack this metaphor for a 5-mark board answer, including: (a) the exact question stem they might face, (b) the morphological clue, (c) the intertextual echo, (d) the thematic payoff.

COMPETENCY: Pedagogical content knowledge — designing instruction for a specific exam competency (CBSE 'Literary Devices and Interpretation' + CUET 'Critical Thinking').

STEPS:
- Step 1: Predict the question stem — "‘टक्ग¡ इग्क्!प वुत्कु फ्क्फ्र्त डक्स फेय्र्क ,द ल्ग्क्ज्क’ पंक्ति में ‘फ्क्फ्र्त’ शब्द के माध्यम से कवि ने कौन-सा रूपक रचा है? भावार्थ सहित स्पष्ट कीजिए।" (5 marks)
- Step 2: Teach morphological clue — 'फ्क्फ्र्त' = फ् (वि/पृथक्) + क्फ्र्त (कृ → करना/सृजन) → 'विशिष्ट सृजन/कौशल'। 'èkjrh' (पवित्र/वेदिक) + 'vkdk'k' (कौशल/शिल्प) = 'जहाँ वेद-मंत्र और शिल्प-कौशल एक साथ घटित हों' — गुरुकुल, यज्ञशाला, मंदिर-निर्माण स्थल।
- Step 3: Teach intertextual echo — 'फ्क्फ्र्त' resonates with विश्वकर्मा tradition (देवताओं के शिल्पी), शिल्पशास्त्र (मानसार, मयमतम), and the *Bhakti* ideal of 'काम ही पूजा' (कबीर: 'काम काज करि देखो रे')। कवि (इतिहास/पुराण विद) इस परंपरा को सक्रिय करता है।
- Step 4: Teach thematic payoff — The metaphor relocates 'nation' (न्स'क) from *political territory* to *sacred workshop* — 'वुत्कु' (ancestral wisdom) and 'फ्क्फ्र्त' (living craft) together *build* the nation daily. This transforms nationalism from 'territorial claim' to 'civilizational practice' — the poem's core argument.

ANSWER: Lesson Plan: (1) Question Stem: "‘फ्क्फ्र्त’ के माध्यम से प्रयुक्त रूपक की व्याख्या कीजिए।" (2) Morphology: फ्+क्फ्र्त = विशिष्ट कौशल; प्रसंग में 'èkjrh वkdk'k' का संयोग = गुरुकुल/यज्ञशाला/मंदिर-निर्माण। (3) Intertextuality: विश्वकर्मा परंपरा, शिल्पशास्त्र, कबीर का 'काम ही पूजा' — पवित्र श्रम की भारतीय अवधारणा। (4) Theme: राष्ट्र = भूखंड नहीं, 'वुत्कु फ्क्फ्र्त' = पूर्वज-ज्ञान व जीवंत कौशल की दैनिक साधना। छात्र को चारों चरण उत्तर में समाहित करने होंगे।

DIFFICULTY: hard