## DEFINITION
Character analysis of the protagonist involves systematically examining the central character's traits, motivations, conflicts, and development through their actions, speech, thoughts, relationships, and the author's narrative descriptions to understand their role in advancing the story's themes.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student must be able to write a structured character sketch of the protagonist using textual evidence (actions, dialogues, internal monologue, others' reactions) organized under traits like resilience, vulnerability, and agency, and explain how the character's arc reflects the chapter's core themes of displacement and survival.

## SCOPE_BOUNDARY
This node covers the protagonist (the first-person narrator/author-figure) in "जक्तLFकku dh jtr cw¡nas" only. It does NOT cover supporting characters (node 005), thematic analysis (nodes 006-007), or literary devices (nodes 008-009), though it references plot (node 002) and setting (node 003) as context for character decisions.

## WALKTHROUGH
Imagine you meet someone who survived losing both parents by age 13, migrated from a conflict zone (Naxalbari) to Delhi with three children, then moved to Mumbai to become a journalist — what questions would you ask to understand *who they are*, not just *what they did*? Start by listing every explicit detail the text gives: age at each crisis, decisions made, emotional language used ("विचलित", "छोड़ आए"). Next, group these into patterns: moments of agency vs. helplessness, public vs. private self. Then, connect each pattern to a specific setting shift (village → Naxalbari → Delhi → Mumbai) using node 003. Finally, ask: which trait *drives* the arc? That becomes your thesis for the character sketch.

## DIAGNOSTIC_QUESTION_1
What is the primary difference between a character *sketch* and a character *analysis* in senior secondary literary study?

## DIAGNOSTIC_ANSWER_1
A sketch lists traits and events; an analysis interprets *why* those traits matter by linking them to the character's choices, conflicts, and the work's themes using textual evidence. A wrong answer (e.g., "sketch is shorter") reveals the student sees analysis as mere summary, not as argument-driven interpretation required in board exams.

## DIAGNOSTIC_QUESTION_2
In the protagonist's move from Naxalbari to Delhi with three children, the text says he was "विचलित" (disturbed) by his sister's circumstances. Explain what this word choice reveals about his internal state *beyond* the plot fact of migration.

## DIAGNOSTIC_ANSWER_2
"विचलित" implies moral/emotional agitation, not just physical displacement — it shows he acts from empathy and responsibility, not mere survival instinct, marking him as relational and principled. A wrong answer focusing only on "he was sad" misses the ethical dimension that defines his agency, a key Class 11 analytical leap.

## DIAGNOSTIC_QUESTION_3
Using the PEEL structure (Point, Evidence, Explanation, Link), write *one* analytical paragraph proving the protagonist's "resilience" is *active* (choice-driven) not *passive* (endurance-only). Use two distinct textual moments.

## DIAGNOSTIC_ANSWER_3
Point: The protagonist exercises agency in every crisis. Evidence 1: At 13, he continues schooling after mother's death (not dropping out). Evidence 2: He *chooses* to leave Naxalbari for Delhi to protect his sister's children, risking the unknown. Explanation: Both show deliberate decisions to uphold duty/education over despair. Link: This active resilience shapes his later journalism — witnessing truth as duty. A weak answer lists hardships without showing *choice*, confusing suffering with character.

## DIAGNOSTIC_QUESTION_4
Compare the protagonist's relationship with *place* (village, Naxalbari, Delhi, Mumbai) across the narrative. How does each setting test or reveal a different facet of his identity?

## DIAGNOSTIC_ANSWER_4
Village: roots/innocence (farmer's son). Naxalbari: political awakening/caregiver role (protector). Delhi: anonymous struggle/survivor (laborer). Mumbai: professional voice/witness (journalist). Each shift strips a layer (son → brother → father-figure → citizen) and adds agency. A wrong answer treats settings as backdrop, not as character-revealing crucibles — a common Class 11 error.

## DIAGNOSTIC_QUESTION_5
The protagonist becomes a journalist in Mumbai. Evaluate whether this career choice is a *natural culmination* of his character arc or an *external opportunity*. Defend using his language ("लिखा", "प्रकाशित") and earlier traits.

## DIAGNOSTIC_ANSWER_5
Natural culmination: his lifelong pattern is *documenting* (schooling, observing sister's pain, writing in newspapers) — journalism formalizes his instinct to bear witness. "एक पुस्तक प्रकाशित" shows deliberate craft, not luck. A wrong answer calling it "good fortune" ignores the textual through-line of literacy-as-survival, missing the author's thematic intent.

## DIAGNOSTIC_QUESTION_6
Write a 50-word "internal monologue" the protagonist might have *the night before leaving Naxalbari*, synthesizing his fear, duty, and hope. Use only traits proven in the text.

## DIAGNOSTIC_ANSWER_6
"Three small hands clutch mine. Sister's hollow eyes haunt me. This land burns with promises broken — but Delhi? Unknown. I cannot stay. I cannot fail them. My pen will feed us; my will must lead. Tomorrow, we walk into noise, carrying silence." A poor answer invents traits (e.g., anger at government) not in text, showing failure to ground creativity in evidence.

## COMMON_MISCONCEPTION
Students confuse "protagonist analysis" with "narrating the protagonist's life events in order." They write: "He was born in a village, mother died, father died, he went to Naxalbari, then Delhi, then Mumbai, became a journalist." This is a *plot summary*, not analysis. The error stems from Class 10 habit of "character sketch = biography." In Class 11, analysis requires *thematic grouping* (e.g., "Three moments where he chooses responsibility over safety") and *interpretive claims* ("His migration is an act of moral courage, not desperation"), each backed by textual evidence.

## ON_FAILURE
1. Ask the student to highlight every *verb* attached to the protagonist in the text (e.g., "छोड़ आए", "लिखा", "निकल पड़े"). 2. Group verbs into: *survival actions* (eating, moving) vs. *agency actions* (protecting, writing, publishing). 3. Have them write one sentence per group starting with "The protagonist *chooses* to..." 4. Show how each choice connects to a theme (duty, truth, resilience). This shifts focus from *what happened* to *what he did and why it matters*.

## BUILDS_ON
Plot and Narrative Structure (node 002) — provides the sequence of events that the character analysis will reinterpret as choices.

## LEADS_TO
Character Analysis: Supporting Characters (node 005) — the protagonist's traits are clarified by contrast with others (sister, children, Mumbai colleagues).

## PREREQUISITE_NODE_IDS
c11_hin_v_cbse_05_001, c11_hin_v_cbse_05_002, c11_hin_v_cbse_05_003
## PREREQUISITE_REASONS
c11_hin_v_cbse_05_001: Context (author's life, Naxalbari background) frames the protagonist's real-world parallels.
c11_hin_v_cbse_05_002: Plot structure gives the event sequence to analyze as character-driven choices.
c11_hin_v_cbse_05_003: Setting shifts (village→Naxalbari→Delhi→Mumbai) are the external pressures that reveal internal traits.

## FORWARD_NODE_IDS
c11_hin_v_cbse_05_005, c11_hin_v_cbse_05_006, c11_hin_v_cbse_05_013, c11_hin_v_cbse_05_007, c11_hin_v_cbse_05_008, c11_hin_v_cbse_05_012, c11_hin_v_cbse_05_014, c11_hin_v_cbse_05_015, c12_hin_a_cbse_05_004

## FORWARD_REASONS
c11_hin_v_cbse_05_005: Supporting characters (sister, children) are defined by their impact on/reflection of the protagonist.
c11_hin_v_cbse_05_006: The protagonist's arc *embodies* the primary theme (displacement/resilience).
c11_hin_v_cbse_05_013: Critical thinking requires a solid character analysis as foundation for interpretation.
c11_hin_v_cbse_05_007: Protagonist's (clerk's) arc embodies "administrative nomadism" — a key secondary theme.  
c11_hin_v_cbse_05_008: Protagonist's character traits determine which metaphors attach to them (e.g., "hammer" suits a resilient character).  
c11_hin_v_cbse_05_012: Protagonist analysis provides character motivation framework needed for "why" inferential questions.  
c11_hin_v_cbse_05_014: Character analysis of protagonist provides the core material for character-sketch answers.  
c11_hin_v_cbse_05_015: Protagonist analysis gives character-based evidence for displacement theme  
c12_hin_a_cbse_05_004: Prior practice in protagonist analysis (Class 11 Vitan Ch5) reinforces the skill across different text types.  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
No prior class nodes available for Hindi Vitan.

## CHAIN_DESCRIPTION
c11_hin_v_cbse_05_002 -> c11_hin_v_cbse_05_004 -> c11_hin_v_cbse_05_005

## THIS_FORMULA
N/A - conceptual

## FORMULA_VARIABLES
N/A

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
conceptual

## CROSS_SUBJECT
c11_history_nationalism | The protagonist's migration from Naxalbari mirrors post-independence tribal displacement — history provides the macro-context for his micro-choices.
c11_economics_livelihood | His shift from agrarian roots to urban journalism illustrates structural economic transition (primary→tertiary sector) experienced by individuals.
c11_geography_migration | The village→Naxalbari→Delhi→Mumbai trajectory maps push-pull factors (conflict, kinship, labor markets) central to migration geography.

## PREREQ_CONCEPT
Understanding that *character is revealed through choice under pressure*, not just description — the core analytical move from Class 10 to 11.

## PREREQ_BEFORE
Student must be able to locate 5-6 key decisions the protagonist makes across the narrative (e.g., continuing school, leaving Naxalbari, moving to Mumbai, writing for publication).

## PREREQ_STUCK
If stuck, review "Plot and Narrative Structure" (node 002) and make a timeline of *only the protagonist's active decisions* (omit passive events like "mother died").

## WORKED_EXAMPLE_1
PROBLEM: Write a structured character analysis paragraph on the protagonist's "sense of responsibility" using the PEEL method, with evidence from two distinct phases of his life (pre-Delhi and post-Delhi).

STEPS:
- Step 1: Identify the trait to analyze — "responsibility" — and recall the PEEL structure: Point (claim), Evidence (textual detail), Explanation (interpretation), Link (to theme/arc).
- Step 2: Select two textual moments showing responsibility: (a) Continuing education after mother's death at age 13 (pre-Delhi), (b) Uprooting three children from Naxalbari to Delhi for their safety (Delhi phase).
- Step 3: Draft the Point sentence: "The protagonist's defining trait is an active, sacrificial responsibility that precedes his adult roles."
- Step 4: Insert Evidence with context: "At 13, despite losing his mother, he 'पढ़ाई जारी रखी' (continued schooling); decades later, 'बहन की परिस्थितियों से विचलित होकर' (disturbed by sister's circumstances) he moves to Delhi with her three children."
- Step 5: Write Explanation: "The first shows self-responsibility (refusing victimhood); the second shows relational responsibility (choosing uncertain duty over safe inertia). Both are *choices*, not reactions."
- Step 6: Write Link: "This dual responsibility — to self and kin — becomes the lens through which he later practices journalism as public duty."
REASONING: PEEL forces analytical depth: Point makes a claim, Evidence grounds it, Explanation unpacks *why* it proves the claim, Link connects to larger meaning — exactly what board examiners reward.
ANSWER: The protagonist's defining trait is an active, sacrificial responsibility that precedes his adult roles. At 13, despite losing his mother, he "पढ़ाई जारी रखी" (continued schooling); decades later, "बहन की परिस्थितियों से विचलित होकर" (disturbed by sister's circumstances) he moves to Delhi with her three children. The first shows self-responsibility (refusing victimhood); the second shows relational responsibility (choosing uncertain duty over safe inertia). Both are *choices*, not reactions. This dual responsibility — to self and kin — becomes the lens through which he later practices journalism as public duty.

## WORKED_EXAMPLE_2
PROBLEM: The protagonist describes his Mumbai phase as "समाचार-पत्रों में लिखा, एक पुस्तक प्रकाशित" (wrote in newspapers, published a book). Analyze how the *language* of this description (passive/understated) characterizes him differently than a boastful account would.

STEPS:
- Step 1: Note the grammatical construction — past tense, simple verbs ("लिखा", "प्रकाशित"), no adjectives of success ("प्रसिद्ध", "सफल").
- Step 2: Contrast with a hypothetical boastful version: "मैंने बड़े अखबारों में लेख लिखे और एक बेस्टसेलर पुस्तक प्रकाशित की."
- Step 3: Infer character from restraint: The minimalism mirrors his life — survival, not spectacle. He reports facts like a journalist: objective, unselfpitying.
- Step 4: Connect to earlier trait: At 13, he didn't dramatize grief; he "पढ़ाई जारी रखी." Consistency: he *does*, doesn't *perform*.
- Step 5: Link to theme: This quiet professionalism makes his witnessing credible — the "burning fires of the capital" (chapter title) are observed, not exploited.
REASONING: Senior secondary analysis examines *how* something is said, not just *what*. The protagonist's linguistic restraint is characterization — it reveals humility, professionalism, and alignment with the text's documentary tone.
ANSWER: The bare verbs "लिखा", "प्रकाशित" — no modifiers of fame or struggle — mirror his lifelong pattern: action without self-dramatization. Like his silent schooling at 13 or wordless migration to Delhi, he *acts* and *records*, never *performs*. This linguistic restraint characterizes him as a witness, not a protagonist of his own drama, lending authenticity to his journalism and reinforcing the chapter's theme of quiet endurance amid "ज्वलंत चिनगारियाँ" (burning sparks).

## WORKED_EXAMPLE_3
PROBLEM: Synthesize a full character sketch (150 words) of the protagonist integrating: (a) three core traits with evidence, (b) his evolution across four settings, (c) how he embodies the chapter's central conflict (individual vs. circumstance).

STEPS:
- Step 1: List three core traits from textual patterns: (1) Resilient agency (choices in crisis), (2) Relational duty (to sister's children, to truth), (3) Quiet professionalism (restrained narration, journalist identity).
- Step 2: Map each trait to a setting-phase: Village → self-responsibility (schooling); Naxalbari → relational duty (protecting niece/nephews); Delhi → survival agency (labor, adaptation); Mumbai → professional duty (journalism).
- Step 3: Identify the central conflict: Individual will vs. structural forces (poverty, conflict, displacement).
- Step 4: Draft thesis: "The protagonist transforms circumstance into testimony through deliberate, duty-bound choices."
- Step 5: Write sketch using PEEL clusters: Trait 1 + Village/Naxalbari evidence → Trait 2 + Delhi evidence → Trait 3 + Mumbai evidence → Synthesis: his life *is* the "ज्वलंत चिनगारियाँ" — not destroyed by fire, but forged into light.
- Step 6: Verify word count (~150) and board-exam readiness: thesis-driven, evidence-dense, theme-linked.
REASONING: Board questions (e.g., "चरित्र-चित्रण कीजिए") demand synthesis, not isolated points. This example models the *integration* of trait, setting, conflict, and theme — the highest-order skill for this node.
ANSWER: The protagonist transforms circumstance into testimony through deliberate, duty-bound choices. At 13, orphaned, he chooses schooling over despair — resilient agency rooted in self-respect. In Naxalbari, "विचलित" by his sister's plight, he uproots her three children for Delhi — relational duty overriding fear. In Delhi's anonymity, he survives labor without losing voice. In Mumbai, "समाचार-पत्रों में लिखा, एक पुस्तक प्रकाशित" — quiet professionalism makes his journalism witness, not performance. Across village→Naxalbari→Delhi→Mumbai, each setting strips support systems; each time, he *chooses* responsibility. He embodies the chapter's "ज्वलंत चिनगारियाँ": not consumed by structural fires (poverty, conflict, displacement), but forged into a chronicler who carries others' stories. His character arc *is* the argument: dignity is not inherited — it is decided, daily.

## COMPETENCY_QUESTION_1
QUESTION: A Class 11 student writes: "The protagonist is brave because he faced many difficulties like mother's death, father's death, migration, and still became a journalist." Identify the analytical flaw in this statement and rewrite it as a board-level analytical claim with one piece of evidence.

COMPETENCY: Critical analysis of student work / Argument construction
STEPS:
- Step 1: Identify the flaw — "brave because he faced difficulties" confuses *passive suffering* with *active courage*; it lists events, not choices.
- Step 2: Recall that board-level claims require: (a) an interpretive adjective (not just "brave"), (b) a specific choice as evidence, (c) a link to character logic.
- Step 3: Select a choice-moment: leaving Naxalbari for Delhi with three children ("विचलित होकर... निकल पड़े").
- Step 4: Rewrite: "The protagonist demonstrates *moral courage* — not mere endurance — when he voluntarily leaves Naxalbari for Delhi solely to protect his sister's children, risking the unknown despite having no safety net."
ANSWER: Flaw: Equates experiencing trauma with possessing virtue. Bravery is shown in *response* to trauma, not trauma itself. Board-level rewrite: "The protagonist demonstrates *moral courage* — not mere endurance — when he voluntarily leaves Naxalbari for Delhi solely to protect his sister's children, risking the unknown despite having no safety net." This uses an interpretive trait ("moral courage"), a specific choice (leaving Naxalbari), and a risk-context ("no safety net") — meeting board criteria for analytical depth.
DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: The chapter title "जक्तLFकku dh jtr cw¡nas" (Burning Sparks/Fires of the Capital) is metaphorical. Construct an argument that the protagonist *himself* becomes a "ज्वलंत चिनगारी" (burning spark) in the capital, using his character arc across three settings. Your answer must: (a) define the metaphor in this context, (b) trace the protagonist's transformation from *victim of fire* to *bearer of fire*, (c) cite one textual detail per setting.

COMPETENCY: Thematic-character synthesis / Metaphorical interpretation
STEPS:
- Step 1: Define the metaphor: "ज्वलंत चिनगारी" = a consciousness that survives structural violence and illuminates truth for others (journalist as witness).
- Step 2: Trace transformation: Village/Naxalbari — *victim* of fire (poverty, conflict, loss); Delhi — *passing through* fire (anonymous labor, displacement); Mumbai — *becomes* fire (journalist publishing truth).
- Step 3: Select textual details: (a) Naxalbari: "बहन की परिस्थितियों से विचलित" — fire as empathy-igniter; (b) Delhi: "निकल पड़े... तीन बच्चों के साथ" — fire as protective will; (c) Mumbai: "एक पुस्तक प्रकाशित" — fire as documented testimony.
- Step 4: Synthesize: He doesn't escape the capital's fires; he *channels* them into language. His character arc *is* the metaphor's fulfillment.
- Step 5: Write final argument in 4-5 sentences with thesis, evidence clusters, and thematic closure.
ANSWER: "ज्वलंत चिनगारी" signifies a consciousness forged in structural violence that chooses to illuminate rather than burn. In Naxalbari, the protagonist is *victim* of fire — "बहन की परिस्थितियों से विचलित" by conflict's cruelty. In Delhi, he *passes through* fire — "तीन बच्चों के साथ निकल पड़े" — his protective will a spark against darkness. In Mumbai, he *becomes* fire — "एक पुस्तक प्रकाशित" — transforming survival into public testimony. He does not flee the capital's flames; he feeds them with documented truth. His character arc *embodies* the title: from ash to spark, from silence to witness.
DIFFICULTY: hard