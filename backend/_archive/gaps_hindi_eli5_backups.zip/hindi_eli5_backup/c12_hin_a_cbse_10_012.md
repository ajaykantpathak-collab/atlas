## DEFINITION
Literal comprehension questions require retrieving explicitly stated information from the text (facts, details, sequences). Inferential comprehension questions require drawing conclusions not directly stated by combining textual evidence with reasoning, context, and prior knowledge.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
Student can independently distinguish literal from inferential questions, locate exact textual evidence for literal answers, and construct logical inferences supported by multiple textual clues for inferential answers — writing responses that follow the Point-Evidence-Explanation-Link (PEEL) structure expected in CBSE board exams.

## SCOPE_BOUNDARY
This node covers only the skill of answering literal and inferential questions based on the Chapter 10 prose memoir "jkepanz 'kqDy". It does NOT cover critical analysis, creative writing, or speaking/listening tasks (those are separate nodes). It focuses on the 10 comprehension questions in the NCERT "iz'u&vH;kl" section and similar unseen-passage patterns.

## WALKTHROUGH
Imagine you're in the exam hall facing an unseen passage or the Chapter 10 memoir. The first question asks: "What was the author's age when his family moved to Prayagraj?" — that's literal, the answer sits in one sentence. The next asks: "Why did the author feel 'okfdI+kQ' (awkward/embarrassed) when his father praised Hindi?" — that's inferential; the text never says "he felt embarrassed because...", you must connect his youthful pride in English, his father's traditional values, and the social context. Start every question by labeling it L (literal) or I (inferential). For L: scan for keywords, quote the line. For I: collect 2-3 textual clues, state the hidden meaning, explain the logical bridge. This labeling habit alone raises board marks by 15-20%.

## DIAGNOSTIC_QUESTION_1
What is the defining difference between a literal comprehension question and an inferential comprehension question?

## DIAGNOSTIC_ANSWER_1
A literal question's answer is directly stated in the text (e.g., "Where was the author born?" → "cLrh f'kys osQ vxksuk xk¡o"). An inferential question's answer is NOT directly stated; it requires combining textual clues to reach a logical conclusion (e.g., "Why did the author call himself 'fuLlansg'?" requires inferring his self-perception from multiple incidents). A wrong answer that treats an inferential question as literal (copying a sentence that doesn't actually answer "why") reveals the student cannot distinguish explicit vs. implicit information.

## DIAGNOSTIC_QUESTION_2
In the memoir, the author writes: "esjh lwjr esa ,slh D;k ckr Fkh] ;g bl le; ugha dg ldrkA" (I don't know what was in my mind then). Is the question "What was in the author's mind at that moment?" literal or inferential? Justify in one sentence.

## DIAGNOSTIC_ANSWER_2
It is an inferential question because the text explicitly states the author *cannot* recall his past thoughts; the answer must be reconstructed from surrounding context (his age, his English-medium schooling, his father's Hindi advocacy) — not retrieved. A student who labels it "literal" and quotes the same sentence as the answer reveals the misconception that any question about the text's content is literal, ignoring whether the information is actually *available*.

## DIAGNOSTIC_QUESTION_3
Apply the PEEL structure to answer this inferential question from the chapter: "Why did the author's father stop him from reading English novels?" (Textual clues: father's traditional Hindi scholarship, his burning of English books, his statement "¯gnh dk cM+k 'kkSd gSA".)

## DIAGNOSTIC_ANSWER_3
**Point:** The father wanted to protect his son's Hindi linguistic roots. **Evidence:** He burned English books, called Hindi "cM+k 'kkSd", and curated a Hindi library. **Explanation:** As a traditional scholar (vaxzs"kh, laLÑr teacher), he saw English education as a threat to cultural identity; his extreme act of burning books shows fear of anglicization. **Link:** This reflects the wider colonial-era tension between English modernity and Indian tradition — the chapter's central theme. A wrong answer that only quotes "¯gnh dk cM+k 'kkSd gSA" without explaining the *motive* behind the book-burning shows the student stops at evidence and skips explanation/link.

## DIAGNOSTIC_QUESTION_4
Compare the cognitive demand of Question 1 ("ys[kd us vius firk th dh fdu&fdu fo'ks"krkvksa dk mYys[k fd;k gS\") and Question 7 (";g dFku fdlosQ lanHkZ esa dgk x;k gS vkSj D;ksa\ Li"V dhft,A") from the NCERT exercise. Which Bloom level does each target?

## DIAGNOSTIC_ANSWER_4
Question 1 targets **Remember/Understand** (list explicitly described traits: scholar of Sanskrit/Hindi/English, strict, burned English books, curated Hindi library). Question 7 targets **Analyze/Evaluate** (interpret the *significance* of the "ân;&ifjp;" — the basement meeting with Premchand — within the narrative arc: it marks the author's literary awakening and validates his father's Hindi world). A student who writes a paragraph for Q1 but one line for Q7 reveals inability to match answer depth to cognitive demand — a major board-exam mark-loser.

## DIAGNOSTIC_QUESTION_5
Evaluate this student's answer to the inferential question: "How did the 'fuLlansg' group get its name?"  
Student writes: "The author and his friends used the word 'fuLlansg' often, so people started calling them 'fuLlansg' people."  
Is this answer sufficient for 2 marks? Why/why not?

## DIAGNOSTIC_ANSWER_5
**No, 0/2 marks.** The answer is circular — it restates the *effect* (people called them that) without the *cause* (the word was a playful distortion of "philosophy" used during their pseudo-intellectual discussions). The text says: "ftlesa ^fuLlansg* bR;kfn 'kCn vk;k djrs FksA ... mUgksaus ge yksxksa dk uke ^fuLlansg* yksx j[k NksM+k FksA". The student misses the ironic self-mockery and the peer-group dynamic. This reveals the misconception that inferential answers can be guessed from the question's keywords without close textual reading.

## DIAGNOSTIC_QUESTION_6
Create your own inferential question based on this textual segment: "pkSèkjh lkgc osQ ikl gh ,d ySEi ty jgk FkkA ySEi dh cÙkh ,d ckj HkHkdus yxhA pkSèkjh lkgc ukSdjksa dks vkok"k nsus yxsA eSaus pkgk fd c<+dj cÙkh uhps fxjk nw¡] ij y{ehukjk;.k us rek'kk ns[kus osQ fopkj ls eq>s èkhjs ls jksd fy;kA" (Premchand had a clay oil-lamp; its chimney cracked; he ordered servants; I rushed to fix it but Yashpal stopped me saying 'let it be'.)  
Your question must require connecting this incident to Premchand's character as revealed elsewhere in the chapter.

## DIAGNOSTIC_ANSWER_6
**Sample question:** "What does the cracked chimney incident reveal about Premchand's attitude toward material comfort versus intellectual pursuit?"  
**Criteria for a good answer:** Must cite (a) Premchand ignoring the broken lamp to continue talking, (b) his simplicity ("oaQèkksa rd cky yVd jgs gSa"), (c) contrast with the author's urban anxiety. A poor answer that only describes the event ("the lamp broke and he didn't fix it") shows the student cannot move from *narration* to *character interpretation* — the core skill this node builds.

## COMMON_MISCONCEPTION
Students believe "inferential" means "guessing" or "giving your opinion". They write answers like "I think the father was strict because he loved Hindi" without anchoring *any* claim in textual evidence. The exact error: they treat the text as a springboard for personal views instead of a constrained evidence base. In board exams, such answers get 0 marks because the marking scheme requires **textual proof for every inferential step**. The misconception persists because school-level comprehension often accepts "reasonable" guesses; Class 12 board and CUET demand evidence-chained reasoning.

## ON_FAILURE
1. Have the student take any 5 questions from the chapter's "iz'u&vH;kl" and label each L or I.  
2. For each I-question, force them to write **three separate textual quotes** that collectively support the inference — no quote, no mark.  
3. Then rewrite the answer using PEEL: Point (inference), Evidence (3 quotes), Explanation (logical bridge), Link (theme).  
4. Re-diagnose: give a fresh inferential question from an unseen passage; if they still skip Evidence step, repeat with a simpler text (Class 10 level) until the habit forms.

## BUILDS_ON
Class 11 literal/inferential comprehension (c11_hin_ar_cbse_10_012) where students learned to distinguish explicit vs. implicit information in shorter texts.

## LEADS_TO
Critical Thinking: Analysis and Interpretation (c12_hin_a_cbse_10_013) where inferences become building blocks for thematic arguments and authorial intent evaluation.

## PREREQUISITE_NODE_IDS
c12_hin_a_cbse_10_001, c12_hin_a_cbse_10_002, c12_hin_a_cbse_10_003, c12_hin_a_cbse_10_004, c12_hin_a_cbse_10_005, c12_hin_a_cbse_10_006, c12_hin_a_cbse_10_007, c12_hin_a_cbse_10_008, c12_hin_a_cbse_10_009, c12_hin_a_cbse_10_010, c12_hin_a_cbse_10_011, c11_hin_ar_cbse_10_012
## PREREQUISITE_REASONS
c12_hin_a_cbse_10_001: Context/background knowledge needed to interpret cultural references (e.g., "vaxzs"kh", "laLÑr") in inferential answers.  
c12_hin_a_cbse_10_002: Plot structure tells you *where* to scan for literal answers (early vs. late paragraphs).  
c12_hin_a_cbse_10_003: Setting/atmosphere clues (e.g., "fpÙkkd"kZd <ax", "veyk") are key evidence for mood-based inferences.  
c12_hin_a_cbse_10_004: Protagonist's traits (author's evolving identity) are the subject of most inferential questions.  
c12_hin_a_cbse_10_005: Supporting characters (father, Premchand, Yashpal) provide the foil for inferences about the protagonist.  
c12_hin_a_cbse_10_006: Primary theme (Hindi vs. English, tradition vs. modernity) is the ultimate "Link" in PEEL for inferential answers.  
c12_hin_a_cbse_10_007: Secondary themes (mentorship, literary community) appear in multi-part inferential questions.  
c12_hin_a_cbse_10_008: Imagery/metaphor (e.g., "ân;&ifjp;" as womb of literary birth) are evidence for deeper inferences.  
c12_hin_a_cbse_10_009: Irony/symbolism (father burning books while son later becomes Hindi professor) drive evaluative inferences.  
c12_hin_a_cbse_10_010: Vocabulary (e.g., "fuLlansg", "okfdI+kQ", "viHkza'k") must be understood to avoid literal misreading.  
c12_hin_a_cbse_10_011: Grammar usage (e.g., passive voice in "fy[kh x;k" vs. active "fy[kk") affects agency inferences.  
c11_hin_ar_cbse_10_012: Direct predecessor — same skill at lower text complexity; student must have mastered L/I labeling there.

## FORWARD_NODE_IDS
c12_hin_a_cbse_10_013, c12_hin_a_cbse_10_014, c12_hin_a_cbse_10_015
## FORWARD_REASONS
c12_hin_a_cbse_10_013: Critical thinking requires chaining multiple inferences into an interpretive argument — this node supplies the atomic inference skill.  
c12_hin_a_cbse_10_014: Writing skills (analytical paragraphs, essays) use PEEL structure mastered here as the paragraph skeleton.  
c12_hin_a_cbse_10_015: Speaking/listening discussions need participants to distinguish factual recall from reasoned opinion — this node trains that distinction.

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
N/A

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_10_012 -> c12_hin_a_cbse_10_012 -> c12_hin_a_cbse_10_013

## THIS_FORMULA
PEEL Structure for Inferential Answers:  
**P**oint = Your inference (one sentence).  
**E**vidence = 2-3 direct textual quotes/paraphrases with paragraph/line reference.  
**E**xplanation = Logical reasoning connecting evidence to point (why does this evidence imply the point?).  
**L**ink = Connect point to chapter's central theme / author's purpose / broader context.

## FORMULA_VARIABLES
P = Inference statement (answer to the "why/how/what does this reveal" question)  
E = Textual citations (exact words or close paraphrase with location)  
R = Reasoning bridge (explicit logic: "Because the text shows X and Y, it implies Z")  
L = Thematic connection (e.g., "This reflects the chapter's theme of linguistic identity crisis")

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
linguistic

## CROSS_SUBJECT
N/A | The memoir's tension between English education and Hindi revival mirrors the History chapter "Nationalism in India" — both show individuals negotiating colonial modernity and indigenous identity; inferential skill transfers: using textual/historical evidence to explain motives.  
 N/A | The author's physical movements (village → Prayagraj → literary circles) parallel Geography's "migration and cultural diffusion"; literal questions map to "describe settlement pattern", inferential to "explain cultural impact of migration".  
 N/A | Father's investment in son's Hindi education vs. English market value reflects Economics' "human capital formation" — inferential question: "Was the father's choice economically rational?" requires evidence from text + economic reasoning.
## PREREQ_CONCEPT
Ability to distinguish explicitly stated information from implied meaning in a Hindi literary prose text.

## PREREQ_BEFORE
Student must have completed Chapter 10's plot, character, theme, and vocabulary nodes (c12_hin_a_cbse_10_001 through 10_011) and Class 11 literal/inferential comprehension (c11_hin_ar_cbse_10_012).

## PREREQ_STUCK
If stuck on labeling a question L/I, re-read the specific paragraph referenced in the question — if the answer sentence exists verbatim, it's literal; if you need to combine sentences, it's inferential.

## WORKED_EXAMPLE_1
PROBLEM: Answer the NCERT Exercise Question 3 (literal): "मिक्की;क; क्ज्हुक्ज;.क प्क्सेक्ज्ह ^इज़से?कु* ध् इग्य्ह >य्द य्स्कद उस फ्दल इज़्दकज न्स्खा\" (How did the first author of 'Izse?ku' see Premchand?)  
STEPS:
- Step 1: Identify question type — asks for a specific description from the text → LITERAL.
- Step 2: Scan the text for keywords "मिक्की;क;", "इज़से?कु", "इग्य्ह >य्द". Locate paragraph: "मिक्की;क; क्ज्हुक्ज;.क प्क्सेक्ज्ह ^इज़से?कु* ध् इग्य्ह >य्द य्स्कद उस फ्दल इज़्दकज न्स्खा" — actually the text says: "मिक्की;क; थ उक्ज्ह दक्स ह्क्क"क्क एकुर्स फे व् च्ज्क्च्ज उक्ज्ह ह्क्क"क्क फ्य[क्क द्ज्र्स फे... ब्लह इज़्दकज उस फे दगुक फे...". Wait, the question is about the *first author* of 'Izse?ku' seeing Premchand. The text: "मिक्की;क; क्ज्हुक्ज;.क प्क्सेक्ज्ह ^इज़से?कु* ध् इग्य्ह >य्द य्स्कद उस फ्दल इज़्दकज न्स्खा" — this is the question itself. The answer is in the preceding narrative: the author (as a boy) saw Premchand at his house. But the question asks how the *first author of Izse?ku* saw Premchand. That is the author himself (Micky;k;). So the answer is the description of that meeting.
- Step 3: Extract exact textual evidence: "एहय म्स<+ द्क लिज र्स ग्क्वा... उह्प्स द्क च्म+s एद्कु उस के ल्केउस गे य्क्स ट्क [क्म्स+ ग्,।" and "च्कर घ च्कर एसा एक्य्वे ग्क्वा फ्दतल एद्कु उस के ल्स उस फ्दुद्य फ्दु-फ्दु ह्क्कौक्वा उस म् य्कुस फ्दु&फ्दु ह्क्कौक्वा उस न्स[क्र ज्गा".
- Step 4: Synthesize into a direct answer: The author (as a 16-year-old boy) saw Premchand sitting on the upper floor of his house, accessed by steep narrow stairs, in a simple room with a clay lamp, looking very ordinary yet dignified.
- Step 5: Verify — answer uses only textual facts, no interpretation. Matches literal question demand.
REASONING: Literal questions are retrieval tasks; the PEEL structure collapses to Point + Evidence only. The key is precise location of the answer segment and accurate paraphrase without adding inference.
ANSWER: मिक्की;क; क्ज्हुक्ज;.क प्क्सेक्ज्ह (लेखक स्वयम्) ने ^इज़से?कु* के प्रथम लेखक प्रेमचंद को उनके घर की ऊपरी मंजिल के एक साधारण कमरे में, मिट्टी के दीये की रोशनी में, सीढ़ियाँ चढ़कर देखा था। वे बहुत साधारण वेश में थे पर उनका व्यक्तित्व प्रभावशाली था।

## WORKED_EXAMPLE_2
PROBLEM: Answer NCERT Exercise Question 7 (inferential): "\"ब्ल इज़्क्ररो द्ह न`फ"व एसा इज़से व् ओक्करव्ग्य द्क वन~H्क्वर फेज.क ज्गरक फ्का\" ;ग द्कु फ्द्लोस्Q लन्ह्क्ज़ एसा द्गक ज्;क गा व् द्कुसा\\? लिज"व द्हफ्ट,।" (The text says 'in this situation there was a wonderful mixture of enthusiasm and anxiety.' In whose context is this said and why? Explain.)  
STEPS:
- Step 1: Label question — asks for context (who) and reason (why) for a quoted phrase → INFERENTIAL (phrase is quoted, but its *significance* is not explained in that sentence).
- Step 2: Locate the quote in text: "ब्लह इज़्क्ररो द्ह न`फ"व एसा इज़से व् ओक्करव्ग्य द्क वन~H्क्वर फेज.क ज्गरक फ्का" appears when the author describes the literary circle at Prayagraj (Jh;qr~ द्क'खिज्ल्क्न थ त्क;लोक्य, च्क- ह्क्कोकुनक्ल थ ग्क्युक, इआ- च्ज्हुक्फ्क क्सा म्+, इआ- मेख'कद्ज फ्}ोस्न्ह एच्; फेक्).
- Step 3: Identify "who" — the author himself (य्स्कद) as a young aspiring writer entering that circle.
- Step 4: Gather evidence for "why": (a) "व्फ्क्द्र्ज ओध्य, एकर््ज्क्सा व् द्प्ग्ज्ह उस वी+क्ज्ल्ज्क्सा व् वेख्सा द्क च्ल्र्ह फ्का" — intimidating senior figures. (b) "स्ल्स य्क्सक्सा द्क म्न्ज़ द्कुस् एसा गे य्क्सक्सा द्क च्क्स्य्ह ओक्क्क़न य्क्सुर्ह फ्का" — awe mixed with desire to belong. (c) "इज़से व् ओक्करव्ग्य" — enthusiasm to write vs. anxiety about measuring up.
- Step 5: Construct PEEL:  
  **P:** The phrase describes the author's own state of mind as a novice in the Prayagraj literary circle.  
  **E:** "व्फ्क्द्र्ज ओध्य... म्न्ज़ द्कुस् एसा गे य्क्सक्सा द्क च्क्स्य्ह ओक्क्क़न य्क्सुर्ह फ्का" (para on literary circle).  
  **R:** The presence of giants like Jh;qr~ द्क'खिज्ल्क्न created awe (anxiety) while the welcoming atmosphere ("फुअन्स्ग" group's playful distortion of "philosophy") gave courage (enthusiasm).  
  **L:** This duality captures the chapter's theme of literary apprenticeship — the tension between reverence for tradition and the urge to create anew.
- Step 6: Final answer in Hindi, 3-4 sentences, board-exam style.
REASONING: Inferential questions require the full PEEL chain. The "why" is never in one sentence; it emerges from synthesizing atmosphere, character dynamics, and author's self-description.
ANSWER: यह पंक्ति लेखक (जयशंकर प्रसाद) के स्वयं के मनोभावों के संदर्भ में कही गई है जब वे 16 वर्ष की अवस्था में प्रयागराज की साहित्यिक मंडली (जिसमें ज्वाला प्रसाद मिश्र, पं. हनुमान प्रसाद गुप्त, चंद्रबली पांडेय, महावीर प्रसाद द्विवेदी आदि थे) में शामिल हुए। वहां वरिष्ठ साहित्यकारों की विद्वत्ता और गरिमा देखकर उनके मन में भय (आकांक्षा) उत्पन्न हुआ, किंतु साथ ही 'फुल्लांसग' मंडली की अनौपचारिकता और प्रोत्साहन ने उत्साह (इच्छा) भी भरा। यह द्वंद्व गुरु-शिष्य परंपरा और नवीन सृजन की आकांक्षा के बीच के संक्रमण को दर्शाता है।

## WORKED_EXAMPLE_3
PROBLEM: A CUET-style unseen passage question (inferential):  
"In the memoir, the author's father burns English novels but later the author becomes a Hindi professor. What does this irony reveal about the *nature of linguistic identity formation* in colonial India?" (Requires combining Chapter 10 with historical context.)  
STEPS:
- Step 1: Recognize this goes beyond the chapter — it's an *extrapolative inference* (CUET/Competitive exam pattern). Still uses PEEL but "Link" connects to external historical concept.
- Step 2: Evidence from text: Father burns books ("फिर थ उन इक्ल्र्द्क्सा को फ्निक्द्ज ज्क[उस य्क्सा"), calls Hindi "च्म+क 'क्क्स्द". Author's outcome: "व्क्य्क्स्पुक रेड य्स[कु... ह्क्कन्ह ल्क्फ्गर; ध् फोर्ह्क्ल द्क्स ओ;ऑफल्क्र द्ज्स ग्,".
- Step 3: Historical knowledge (Class 12 History): Colonial education policy (Macaulay's Minute) created English-knowing elite; Hindi revival movements (Nagari Pracharini Sabha, Premchand's role) countered it.
- Step 4: Formulate inference (Point): Linguistic identity was not a fixed inheritance but a *contested, negotiated process* — even within one family, the rejection of English could produce its most effective Hindi practitioner.
- Step 5: Explanation: Father's radical purge (burning books) was a defensive nativism; son's mastery of Hindi *through* that purge (access to curated library, mentorship of Premchand) turned defense into creative offense. The irony: the very books burned were the ones the son later translated/edited (implied by his scholarly work).
- Step 6: Link: This mirrors the national trajectory — Hindi's modernization (Premchand, Prasad, Dwivedi) used Western forms (novel, essay, criticism) to express Indian content. Identity formation = selective appropriation, not pure rejection.
- Step 7: Write answer in 150 words (CUET limit), using formal Hindi academic register.
REASONING: Competitive exams test transfer of comprehension skill to new contexts. The PEEL structure holds, but "Evidence" now includes cross-textual references, and "Link" demands disciplinary knowledge.
ANSWER: यह विडंबना दर्शाती है कि औपनिवेशिक भारत में भाषाई पहचान एक रैखिक विरासत नहीं, बल्कि द्वंद्वात्मक संवाद थी। पिता का अंग्रेजी उपन्यास जलाना (रक्षात्मक स्वदेशीवाद) और पुत्र का उन्हीं परिस्थितियों में हिंदी आचार्य बनना (सृजनात्मक स्वदेशीकरण) — दोनों एक ही सातत्य के दो ध्रुव हैं। प्रेमचंद आदि के सान्निध्य में लेखक ने अंग्रेजी के 'नकार' को हिंदी के 'सकार' में रूपांतरित किया। यह राष्ट्रीय स्तर पर हिंदी के आधुनिकीकरण (उपन्यास, निबंध, आलोचना जैसे पाश्चात्य रूपों का भारतीय अंतर्वस्तु हेतु प्रयोग) का सूक्ष्म रूपक है। पहचान निर्माण = चयनात्मक विनियोग, शुद्ध अस्वीकार नहीं।

## COMPETENCY_QUESTION_1
QUESTION: A Class 12 student answers the inferential question "Why did the author feel 'okfdI+kQ' (embarrassed) when his father praised Hindi?" with: "Because he liked English more than Hindi at that time."  
Critique this answer using the PEEL framework. What is missing? Rewrite it to earn full marks (3 marks).
COMPETENCY: Critical evaluation of peer response / Application of answer-structure rubric
STEPS:
- Step 1: Identify the student's answer as a bare "Point" without Evidence, Explanation, or Link.
- Step 2: Note the textual evidence available: "एसा र्क्स वुद्ह ल्स[र्स घ ब्ल च्कर ल्स ^ओक्फ्दी+कक्* ग्क्स ज्;क" (immediate reaction), "इसा र्क्स बुध ल्स[र्स घ ब्ल च्कर ल्स ^ह्क्कन्ह द्क च्म+क 'क्क्स्द ग्सा*" (father's statement), "व्क्ट ल्स र्ह्ल औ"ख्ज इग्य्स द्क च्कर फ्का" (16 years earlier context).
- Step 3: Explain that "liked English more" is an unsupported claim — the text shows he was *immersed* in English (English-medium school, English novels) but doesn't state preference.
- Step 4: Rewrite using PEEL: Point (embarrassment from clash of identities), Evidence (three quotes), Explanation (father's public praise highlighted the son's private Anglicized world), Link (theme: generational/cultural transition).
ANSWER: **Critique:** The answer states a plausible inference but provides **zero textual evidence** — it's an opinion, not an evidence-based inference. Board marking scheme: 0/3 marks.  
**Rewritten full-mark answer:** लेखक को पिता द्वारा हिंदी की प्रशंसा (\"हिंदी का बड़ा स्कद\") पर 'ओकफी+कक्' (असहज/शर्मिंदगी) इसलिए महसूस हुई क्योंकि उस समय (16 वर्ष की अवस्था में) वह अंग्रेजी माध्यम के स्कूल में पढ़ता था, अंग्रेजी उपन्यास पढ़ता था, और उसके मन में अंग्रेजी के प्रति आकर्षण था। पाठ साक्ष्य: (1) \"उसके पहले से ही हिंदी के संबंध में एक विचित्र उत्कंठा...\" (2) \"मैं तो उसकी लज्जा देखते ही 'ओकफी+कक्' हो गया\" (3) \"पिता उन दिनों अंग्रेजी नहीं, उर्दू लिखते थे...\" व्याख्या: पिता का सार्वजनिक हिंदी-गौरव लेखक के निजी अंग्रेजी-अभ्यस्त संसार से टकराया, जिससे सांस्कृतिक द्वैध उजागर हुआ। संबंध: यह पीढ़ीगत संक्रमण (पिता: परंपरावादी विद्वान, पुत्र: औपनिवेशिक आधुनिकता का उत्पाद) अध्याय का केंद्रीय विषय है।
DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: Design a 4-mark inferential question for this chapter that requires synthesizing evidence from **three different paragraphs** to explain a character's motivation. Provide the question, the three paragraph references (by content, not page), and the ideal PEEL answer outline.
COMPETENCY: Question design / Backward engineering of assessment / Synthesis across text segments
STEPS:
- Step 1: Choose a character with distributed characterization — Premchand (pkSèkjh lkgc) appears in: (a) basement meeting (ân;&ifjp;), (b) cracked lamp incident (ySEi ty), (c) literary circle description (fpÙkkd"kZd eaMyh).
- Step 2: Frame question targeting motivation: "Premchand's interactions with the young author reveal a deliberate mentorship strategy. Explain with evidence from three separate incidents."
- Step 3: Map evidence:  
  Para A (basement): "व्क्स! तक इक्व्व त्क्ब्ज़ र्क्सा पायर व्कोगा" — playful encouragement, lowering hierarchy.  
  Para B (lamp): "व्ज्स! तक इक्व्ब्ज़ र्क्स्ब पायर व्कोगा" — refusing help, modeling self-reliance/simplicity.  
  Para C (circle): "प्क्सेक्ज्ह ल्क्गक उस के इकल घ, च्म+ य्सेई त्य ज्गक फ्का... ओक्कुथ उस उह्प्स ल्स ओग द्फोक् य्य्द्ज्क]" — inclusive leadership, letting junior voices speak.
- Step 4: Ideal PEEL outline:  
  P: Premchand consciously nurtured the author's literary confidence through egalitarian gestures.  
  E1: Basement — informal command \"work before talk\" treats boy as peer.  
  E2: Lamp — refuses servant-like help, teaches dignity of labor.  
  E3: Circle — creates space for juniors (\"फुल्लांसग\" group) to experiment.  
  R: Each incident removes a barrier (formality, dependence, silence) that silences young writers.  
  L: This mentorship model — democratic, practice-oriented — is the chapter's alternative to colonial pedagogy.
- Step 5: Ensure question phrasing matches CBSE "Analyze/Evaluate" command words.
ANSWER: **Question:** \"प्रेमचंद की युवा लेखक (जयशंकर प्रसाद) के प्रति मार्गदर्शन-शैली में समानतावादी सशक्तिकरण की रणनीति निहित है। पाठ के तीन भिन्न प्रसंगों से प्रमाण देकर विश्लेषण कीजिए।\" (4 अंक)  
**Paragraph References:** (1) तहखाने की मुलाकात (\"चलो! जब तक लिख न लो, बात न करो\"), (2) टूटे चिमनी वाले दीये का प्रसंग (\"चलो! जब तक बुझ न जाए, हाथ न लगाओ\"), (3) साहित्यिक मंडली में कनिष्ठों को स्थान (\"फुल्लांसग\" समूह का निर्माण)।  
**Ideal PEEL Outline:** See Step 4 above.  
DIFFICULTY: hard