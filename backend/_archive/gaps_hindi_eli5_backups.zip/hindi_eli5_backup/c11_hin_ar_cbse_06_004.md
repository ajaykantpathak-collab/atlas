## DEFINITION
Character analysis of the protagonist involves systematically examining the central character's personality traits, motivations, conflicts, development arc, and relationships to understand their role in advancing the narrative's themes. For Class 11 board exams, this requires citing textual evidence (dialogue, actions, internal monologue, others' perceptions) and explaining how each element reveals the protagonist's psychological depth and thematic significance.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student can write a structured 150-word board-style answer analyzing Jatuh's character using at least three distinct textual evidence categories (speech, action, internal conflict, relationships) and explicitly linking each to the story's central themes of educational integrity and systemic resistance.

## SCOPE_BOUNDARY
This node covers ONLY the protagonist Jatuh (जतुः/जतूह) from Chapter 6 "jtuh". It does NOT cover supporting characters (Vfer, Yhyk, Principal, etc.) which are addressed in node c11_hin_ar_cbse_06_005, nor does it cover thematic analysis (node c11_hin_ar_cbse_06_006) or plot structure (node c11_hin_ar_cbse_06_002).

## WALKTHROUGH
Imagine you're watching a teacher in your own school who refuses to punish a student despite the principal demanding it - what would that teacher be thinking? That's exactly where we begin with Jatuh. First, locate every scene where Jatuh speaks or acts decisively (the staffroom confrontation, the home conversation with her sister, the final public hearing). Next, categorize each moment: Is she defending a principle? Revealing vulnerability? Challenging authority? Then ask: "What does this specific action/reaction tell us about her core values?" Finally, connect each trait to the larger battle between child-centric education and bureaucratic cruelty - this thematic linking is what fetches full marks in board answers.

## DIAGNOSTIC_QUESTION_1
Identify the protagonist of "jtuh" and state her profession as established in the opening scenes of the chapter.

## DIAGNOSTIC_ANSWER_1
The protagonist is Jatuh (जतुः), a school teacher (कॉलेज/स्कूल शिक्षिका) - evident from her interactions with student Vfer, colleague Yhyk, and Principal GsmekLvj in the staffroom and classroom scenes. A wrong answer (naming Vfer or the Principal) reveals confusion between protagonist and antagonist/supporting roles, suggesting the student hasn't tracked narrative perspective - the story follows Jatuh's consciousness, not the student's.

## DIAGNOSTIC_QUESTION_2
Explain in your own words why Jatuh refuses to accept the Principal's directive to not give tuition references to Vfer, despite the administrative pressure.

## DIAGNOSTIC_ANSWER_2
Jatuh refuses because she believes Vfer genuinely deserves academic support (he scored 72% despite systemic neglect) and withholding help would punish the victim of a broken system. A wrong answer focusing only on "she likes the student" or "she is rebellious" misses the ethical reasoning - Jatuh's stance is principle-based (educational justice), not personal favoritism. This confusion between personal bias and professional ethics is the key misconception.

## DIAGNOSTIC_QUESTION_3
In the scene where Jatuh confronts the Principal about corporal punishment (V~;w'ku), she says: "V~;w'ku rks de'kksj cPps ysrs gSa" (Only frightened children accept corporal punishment). Apply the PEEL method to analyze what this single line reveals about her pedagogical philosophy.

## DIAGNOSTIC_ANSWER_3
**Point**: Jatuh views corporal punishment as psychologically damaging, not corrective. **Evidence**: The line "V~;w'ku rks de'kksj cPps ysrs gSa" (p. 80). **Explanation**: She equates compliance through fear with trauma ("de'kksj" = frightened), implying true learning requires safety. **Link**: This establishes her as the moral center opposing institutional violence - a direct thematic anchor for board answers. A weak answer would merely translate the line without analyzing "de'kksj" as a deliberate lexical choice contrasting with "shiksha" (education).

## DIAGNOSTIC_QUESTION_4
Compare Jatuh's private conversation with her sister (Ifr) about the tuition reference issue (pp. 77-78) with her public confrontation with the Director (Funs'kd) at the inquiry (pp. 81-82). What does the shift in tone and strategy reveal about her character development?

## DIAGNOSTIC_ANSWER_4
Privately, Jatuh is vulnerable, seeking emotional validation ("rqEgsa oSQls ekywe?"), and admits exhaustion ("lkspk pijklh dks Hkstdj..."). Publicly, she is strategic, evidence-based ("cksMZ dk dke gh ;g gS..."), and weaponizes institutional rules against the institution. This duality reveals a protagonist who feels fear but chooses moral courage - a nuanced "reluctant hero" arc. Missing this private/public split leads to a flat "brave teacher" characterization that ignores her humanity.

## DIAGNOSTIC_QUESTION_5
Evaluate the criticism that Jatuh's final decision to organize a public hearing (ehfVax) is reckless idealism rather than effective activism. Use textual evidence to defend your judgment.

## DIAGNOSTIC_ANSWER_5
It is effective activism, not recklessness. Evidence: She secures lawyer Laiknd's support ("vkidh lkjh ckr eSaus uksV dj yh gSA"), mobilizes media ("25 rkjh[k... ehfVax"), and forces policy change ("dksbZ Hkh Vhpj vius gh LowQy osQ Nk=kksa dk V~;w'ku ugha djsxk"). The Director's surrender ("funs'kd ns[krk jgrk gS... daèks mpdk nsrk gS") confirms tactical success. Calling it "reckless" ignores her calculated use of democratic tools (press, law, public opinion) - a confusion between emotional outburst and strategic resistance.

## DIAGNOSTIC_QUESTION_6
Write a 50-word internal monologue for Jatuh the night before the public hearing, capturing her fear, resolve, and the specific memory of Vfer's injured hand that fuels her. Use first-person Hindi.

## DIAGNOSTIC_ANSWER_6
A strong response: "कल Vfer का सूजा हाथ देखा - वही हाथ जो 72% लाया था। आज नींद नहीं आती। Director की धमकी, Principal की चालाकी... पर अगर मैं चुप रही तो हर कमज़ोर बच्चे की उम्मीद टूटेगी। कल बोलूँगी - नहीं, लड़ूँगी।" A weak answer uses generic fear ("I am scared") without the specific trigger (Vfer's hand, the 72% detail) showing the student hasn't anchored emotion in textual evidence.

## COMMON_MISCONCEPTION
Students consistently confuse Jatuh's *professional ethics* with *personal affection* for Vfer. They cite her giving him tuition references or defending him as "she cares for him" rather than "she upholds every student's right to fair assessment." This error stems from reading the teacher-student dynamic through a familiar sentimental lens (like a favorite teacher) instead of analyzing the text's systemic critique. The text explicitly shows her applying the same standard to all ("ge blh rjg dkWfi;k¡ fn[kkus yx tk,¡ rks ;gk¡ rks isjsaV~l dh HkhM+ yxh jgs lkjs le;") - proving it's principle, not preference.

## ON_FAILURE
Step 1: Have the student list every interaction between Jatuh and Vfer in a two-column table: Column A = Action/Dialogue, Column B = Is this special treatment or standard policy? Step 2: Show the Principal scene where Jatuh says "eSFl esa ges'kk lsaV&ijlsaV uacj ysrk jgk gSA bl lky Hkh mlus iwjk isij Bhd fd;k gSA" - highlighting "bl lky Hkh" (even then/despite that) proving consistency. Step 3: Ask: "If she favored him personally, would she demand the same rights for *all* students in the public hearing?" Step 4: Rewrite one board answer paragraph replacing "Vfer" with "any student" to test if the argument holds.

## BUILDS_ON
c11_hin_ar_cbse_06_002 (Plot and Narrative Structure) - requires understanding the story's conflict arc to map Jatuh's character beats to turning points.

## LEADS_TO
c11_hin_ar_cbse_06_005 (Character Analysis: Supporting Characters) - Jatuh's traits are defined relationally; analyzing foils (Principal, Vfer, Sister) deepens protagonist understanding.

## PREREQUISITE_NODE_IDS
c11_hin_ar_cbse_06_001, c11_hin_ar_cbse_06_002, c11_hin_ar_cbse_06_003
## PREREQUISITE_REASONS
c11_hin_ar_cbse_06_001: Context on Usha Priyamvada's New Story Movement and educational themes frames Jatuh as a representative figure, not just an individual.
c11_hin_ar_cbse_06_002: Plot structure identifies the three confrontations (staffroom, home, inquiry) as the character's testing points.
c11_hin_ar_cbse_06_003: Setting (staffroom, home, public hearing) shapes Jatuh's code-switching between private vulnerability and public authority.

## FORWARD_NODE_IDS
c11_hin_ar_cbse_06_005, c11_hin_ar_cbse_06_006, c11_hin_ar_cbse_06_013, c11_hin_ar_cbse_06_007, c11_hin_ar_cbse_06_008, c11_hin_ar_cbse_06_009, c11_hin_ar_cbse_06_010, c11_hin_ar_cbse_06_011, c11_hin_ar_cbse_06_012, c11_hin_ar_cbse_06_014, c11_hin_ar_cbse_06_015, c12_hin_ar_cbse_06_004

## FORWARD_REASONS
c11_hin_ar_cbse_06_005: Supporting characters (Vfer as conscience, Principal as antagonist, Sister as confidante) function as mirrors to Jatuh's traits.
c11_hin_ar_cbse_06_006: Primary theme (educational integrity vs systemic cruelty) is embodied in Jatuh's choices - theme analysis requires protagonist analysis first.
c11_hin_ar_cbse_06_013: Critical interpretation (e.g., "Is Jatuh a tragic or triumphant figure?") synthesizes character and theme.
c11_hin_ar_cbse_06_007: Protagonist analysis (जतüh) reveals how the central character embodies thematic tensions.  
c11_hin_ar_cbse_06_008: Protagonist's psychology is revealed through metaphors he uses/attracts.  
c11_hin_ar_cbse_06_009: Understanding the protagonist's experiences is needed to see how irony affects him personally.  
c11_hin_ar_cbse_06_010: Understanding वफ़र's character reveals why he uses words like "ट्यूशन" with desperation.  
c11_hin_ar_cbse_06_011: Protagonist analysis gives character background needed to link register to personality.  
c11_hin_ar_cbse_06_012: Protagonist analysis provides character motivation baseline for inferences  
c11_hin_ar_cbse_06_014: Protagonist analysis supplies evidence for character sketches.  
c11_hin_ar_cbse_06_015: Character Analysis: Protagonist (Jtuh) gives the moral center around which discussion tensions organize  
c12_hin_ar_cbse_06_004: अगला तार्किक चरण: Character analysis of the protagonist in poetry involves identifying the central personified figure,... इस नोड की अवधारणाओं को सीधे उपयोग/विस्तारित करता है।  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
none

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_06_002 -> c11_hin_ar_cbse_06_004 -> c11_hin_ar_cbse_06_005

## THIS_FORMULA
N/A - conceptual

## FORMULA_VARIABLES
N/A

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
conceptual

## CROSS_SUBJECT
c11_civics_democratic_rights | Jatuh's use of public hearing (ehfVax), media mobilization, and legal recourse (Lawyer Laiknd) mirrors civic education on constitutional remedies (Article 32, PIL) - her activism is a literary case study of democratic participation.
c11_psychology_moral_development | Jatuh's progression from private doubt to public principled action illustrates Kohlberg's post-conventional morality (Stage 5: social contract, Stage 6: universal ethical principles) - she prioritizes justice over institutional loyalty.

## PREREQ_CONCEPT
Narrative perspective identification: recognizing that the story filters events through Jatuh's consciousness (free indirect discourse, access to her thoughts) making her the protagonist.

## PREREQ_BEFORE
Student must be able to distinguish narrative focalization (whose eyes we see through) from character prominence (who speaks most).

## PREREQ_STUCK
Review "narrative point of view" in c11_hin_ar_cbse_06_002 - specifically the difference between first-person narration and third-person limited focalization through Jatuh.

## WORKED_EXAMPLE_1
PROBLEM: Write a board-style answer (120 words) analyzing how Jatuh's dialogue with Yhyk in the staffroom (pp. 70-71) establishes her as a teacher who prioritizes student dignity over institutional compliance.

STEPS:
- Step 1: Locate the exact exchange - Jatuh learns Vfer's tuition was denied because he didn't bring 72 marks; she reacts "xqLls vkSj nq[k ls" (with anger and disappointment).
- Step 2: Identify the key dialogue: "V~;w'ku ugha ysus ls feyrs gSa dgha vPNs uacj?" and "lj rks ckj&ckj dgrs gh Fks fd V~;w'ku dj yks..."
- Step 3: Categorize evidence type - this is SPEECH revealing VALUES (rhetorical question challenging normalized violence).
- Step 4: Analyze specific words: "feyrs" (fail/fall apart) implies systemic collapse without punishment; "lj" (habit) exposes unexamined tradition.
- Step 5: Connect to theme - this moment plants the seed for her later public rebellion; the staffroom is where private conscience meets professional duty.
REASONING: Board answers require moving from textual micro-detail (word choice) to macro-theme. The staffroom scene is the inciting incident for her moral arc - skipping it makes the later public hearing seem unmotivated.
ANSWER: जतुः का स्टाफरूम संवाद (पृ. 70-71) उसकी शैक्षिक नैतिकता का पहला प्रमाण है। जब यशिका बताती है कि वीफर को ट्यूशन इसलिए नहीं मिली क्योंकि उसने "मार नहीं खाई", जतुः का प्रश्न - "क्या पिटाई न खाने से अंक गिर जाते हैं?" - शारीरिक दंड की निरर्थकता को उजागर करता है। "लज" (आदत) शब्द का प्रयोग दिखाता है कि वह परंपरा को अंधानुकरण मानती है। उसका क्रोध ("क्षुब्ध और निराश") व्यक्तिगत नहीं, सैद्धांतिक है - यही बीज बाद में जनसुनवाई में फूटता है।

## WORKED_EXAMPLE_2
PROBLEM: Analyze how the home scene with her sister (Ifr, pp. 77-78) complicates Jatuh's characterization by revealing vulnerability without undermining her resolve.

STEPS:
- Step 1: Identify the setting shift - from public institution to private domestic space (kitchen, tea, sister's concern).
- Step 2: Extract Jatuh's admissions: "rqEgsa oSQls ekywe?" (seeking validation), "lkspk pijklh dks Hkstdj..." (exhaustion from parental pressure), "vjs tc cPps us lkjk isij Bhd fd;k gS..." (frustration with systemic inertia).
- Step 3: Contrast with her public persona - no grand speeches, only raw questions ("D;k dg jgh gSa vki...").
- Step 4: Analyze the sister's role as foil - Ifr represents conventional compliance ("vPNk ekLVj yksx V~;w'ku djrs gSa"), making Jatuh's dissent sharper.
- Step 5: Synthesize - vulnerability humanizes; it doesn't weaken. The scene proves her resistance costs her personally ("csVk rks vHkh i<+us ugha tk jgk gS"), raising stakes for board answers on "moral courage."
REASONING: Students often skip domestic scenes as "irrelevant." This scene is crucial for the "reluctant hero" reading - it shows courage as action despite fear, not absence of fear.
ANSWER: बहन के साथ घरेलू दृश्य जतुः को 'निडर योद्धा' नहीं, 'डरी हुई पर अडिग शिक्षिका' बनाता है। वह स्वीकारती है: "मेरा चश्मा अभी तक नहीं चढ़ा" (मानसिक थकान), माता-पिता के दबाव से थकी है, फिर भी पूछती है: "क्या पिटाई ही एकमात्र भाषा है?" बहन की पारंपरिक सोच ("अच्छे लोग पिटाई करते हैं") के बरक्स जतुः का मौन प्रतिरोध अधिक शक्तिशाली है। यह दृश्य बोर्ड उत्तर में 'नैतिक साहस' की परिभाषा देता है: भय के बावजूद सही करना।

## WORKED_EXAMPLE_3
PROBLEM: Trace Jatuh's character arc across three institutional confrontations (Staffroom → Director's Office → Public Hearing) showing how each escalates her strategy from protest to systemic intervention.

STEPS:
- Step 1: Staffroom (pp. 70-71) - TACTIC: Verbal challenge within hierarchy. She questions Principal's logic ("isij vPNk djks rc HKh uacj de gks tkrs gSa"), uses data (Vfer's 72%), appeals to pedagogy. RESULT: Dismissed ("fu;e!"; "OgkWV Mw ;w ehu").
- Step 2: Director's Office (pp. 80-81) - TACTIC: Formal complaint with evidence. She cites rules ("cksMZ dk dke gh ;g gS"), exposes policy violation ("V~;w'ku osQ uke ij pyus okyh bl nqdkunkjh"), demands accountability. RESULT: Bureaucratic deflection ("gekjs ikl rks vkt rd fdlh isjsaV ls bl rjg dh dksbZ f'kdk;r ugha vkbZ").
- Step 3: Public Hearing (pp. 83-84) - TACTIC: Democratic mobilization. She bypasses hierarchy entirely - engages lawyer (Laiknd), media (25 reporters), parents, public opinion. RESULT: Policy change ("dksbZ HKh Vhpj vius gh LowQy osQ Nk=kksa dk V~;w'ku ugha djsxk").
- Step 4: Map the trajectory - Internal appeal → Formal grievance → Extra-institutional pressure. Each failure of the previous level necessitates the next.
- Step 5: Character insight - Jatuh learns the system won't reform itself; she must become the external force. This is the "teacher as activist" arc.
- Step 6: Thematic lock - The arc embodies the chapter's central argument: individual conscience must invoke collective democratic power to dismantle institutional violence.
REASONING: This worked example models the "trace the arc" question type frequent in Class 11 boards (5-6 marks). It requires synthesizing plot nodes (c11_hin_ar_cbse_06_002) with character analysis - exactly the cross-node thinking the curriculum demands.
ANSWER: जतुः का तीन चरणों में संस्थागत संघर्ष उसकी रणनीतिक परिपक्वता दर्शाता है: 1) स्टाफरूम - तर्क और आंकड़ों से प्रधानाचार्य को चुनौती (वीफर के 72%), खारिज। 2) निदेशक कक्ष - नियमों का हवाला देकर औपचारिक शिकायत, नौकरशाही टालमटोल। 3) जनसुनवाई - वकील, मीडिया, जनमत का उपयोग कर व्यवस्था को बाध्य करना, नीति परिवर्तन। प्रत्येक विफलता अगले स्तर की रणनीति जन्म देती है। यह 'शिक्षक से कार्यकर्ता' की यात्रा अध्याय का केंद्रीय तर्क है: व्यक्तिगत विवेक को सामूहिक लोकतांत्रिक शक्ति में बदलना ही संस्थागत हिंसा का प्रतिकार है।

## COMPETENCY_QUESTION_1
QUESTION: "Jatuh's refusal to punish Vfer is often read as professional ethics. However, her sister Ifr argues: 'Good people do corporal punishment; you're making it complicated.' Using this counter-perspective, evaluate whether Jatuh's rigidity is ethical clarity or moral arrogance. Support with two textual instances."

COMPETENCY: Critical evaluation of character motivation using counter-argument

STEPS:
- Step 1: Acknowledge Ifr's voice as the societal norm (majority view) - not a villain, but the status quo.
- Step 2: Instance 1 - Staffroom: Jatuh could have compromised ("just sign the reference") but chooses principle. Is this arrogance? No - she risks her career for a student's right, not ego.
- Step 3: Instance 2 - Public Hearing: She accepts personal cost ("csVk rks vHKh i<+us ugha tk jgk gS") and public scrutiny. Arrogance seeks validation; she seeks policy change.
- Step 4: Synthesize - Rigidity in service of vulnerable others is ethics; rigidity for self-righteousness is arrogance. Jatuh's beneficiaries are students (present/future), not herself.
ANSWER: जतुः की 'हठ' नैतिक स्पष्टता है, अहंकार नहीं। बहन की बात ('अच्छे लोग पिटाई करते हैं') बहुसंख्यक सोच है - जतुः इसका प्रतिरोध करती है। प्रमाण 1: स्टाफरूम में वह समझौता कर सकती थी (संदर्भ दे देती), पर वीफर के अधिकार के लिए प्रधानाचार्य से भिड़ी - कैरियर जोखिम में डाला। प्रमाण 2: जनसुनवाई में वह निजी कीमत (मानसिक तनाव, पारिवारिक दबाव) चुकाती है, पर नीति बदलवाती है। अहंकार स्वयं को सही साबित करना चाहता है; जतुः का लक्ष्य व्यवस्था सुधारना है। उसका प्रतिरोध कमज़ोर के लिए है, स्वयं के लिए नहीं।
DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: The story uses 'free indirect discourse' (मुक्त अप्रत्यक्ष वाचन) to blend Jatuh's thoughts with narration. Identify one passage where this technique reveals her internal conflict about Vfer's tuition reference, and explain how the linguistic merging of narrator and character voice deepens our understanding of her dilemma compared to direct dialogue alone.

COMPETENCY: Literary device analysis applied to character psychology

STEPS:
- Step 1: Define free indirect discourse for this context - third-person narration adopting character's vocabulary, syntax, and emotional tone without quotation marks.
- Step 2: Locate passage: pp. 73-74, after sister leaves - "jtuh osQ psgjs ij ruko... ?kwjdj pijklh dks ns[krh gSA" and her unspoken calculation about Vfer's marks vs. Principal's rule.
- Step 3: Analyze linguistic markers: "rqe tSls yksxksa osQ dkj.k gh rks bl ns'k esa oqQN ugha gksrk" - the narrator uses Jatuh's bitter idiom ("rqe tSls log"), not neutral description.
- Step 4: Contrast with direct dialogue - if she said this aloud to Principal, it's confrontation; as internal narration, it's suppressed rage revealing powerlessness within hierarchy.
- Step 5: Effect on character reading - we see the *cost* of silence. The technique makes her public outburst later earned, not sudden.
ANSWER: पृ. 73-74 पर बहन के जाने के बाद का वर्णन: "jtuh osQ psgjs ij ruko... rqe tSls yksxksa osQ dkj.k gh rks bl ns'k esa oqQN ugha gksrk" - यहाँ वर्णनकर्ता जतुः की कड़वी मुहावरेदार भाषा ("तुम जैसे लोगों") का प्रयोग करता है, न कि तटस्थ स्वर। यदि वह ये शब्द प्रधानाचार्य से कहती, यह टकराव होता; आंतरिक एकालाप में यह दबी हुई असहायता है। मुक्त अप्रत्यक्ष वाचन हमें उसकी चुप्पी की कीमत दिखाता है - वह बोलना चाहती है, पर व्यवस्था रोकती है। यही दबा आक्रोश बाद में जनसुनवाई में फूटता है। सीधा संवाद केवल बाहरी संघर्ष दिखाता; यह तकनीक आंतरिक नैतिक संघर्ष उजागर करती है।
DIFFICULTY: hard