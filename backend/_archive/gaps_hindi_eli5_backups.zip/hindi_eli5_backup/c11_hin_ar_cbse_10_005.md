## DEFINITION
Character analysis of supporting characters involves examining how secondary figures in a literary work—through their actions, dialogue, relationships, and contrasts—illuminate the protagonist's traits, advance the plot, and embody thematic ideas. In Kabir's poetry and life sketch, supporting characters like Guru Ramanand, Sultan Sikandar Lodi, and his disciples serve as mirrors and foils that sharpen our understanding of Kabir's Nirguna Bhakti and social rebellion.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student can identify at least three supporting characters from the chapter, cite specific textual evidence (lines or biographical details) for each, explain how each character contrasts with or complements Kabir, and articulate what this reveals about the central themes of Nirguna Bhakti and social equality.

## SCOPE_BOUNDARY
This node covers analysis of supporting characters explicitly mentioned in the NCERT chapter "Kabir" (Aroh Chapter 10): biographical figures (Guru Ramanand, Sultan Sikandar Lodi, Namdev, disciples) and the addressee in the poem ("ifr"). It does not cover characters from other Kabir poems not in the syllabus, nor does it repeat the protagonist analysis of Kabir himself (covered in node c11_hin_ar_cbse_10_004).

## WALKTHROUGH
Imagine you are watching a play where the main actor (Kabir) stands alone on stage—but every time a friend, enemy, or student enters, the spotlight shifts and you see a new side of Kabir: his humility with his guru, his defiance before the Sultan, his tenderness with a disciple. That is exactly what supporting characters do in this chapter. Begin by listing every named person in the biographical note and the poem (Guru Ramanand, Sultan Sikandar Lodi, Namdev, the "ifr" addressed in the poem). Next, for each, ask: "What does this person's interaction with Kabir reveal about Kabir's beliefs?" Then, find one line or incident from the text that proves it. Finally, connect that revelation to the chapter's big ideas: formless God, rejection of ritual, equality. The key insight: supporting characters are not just "extra people"—they are literary tools the author uses to define the hero by contrast and connection.

## DIAGNOSTIC_QUESTION_1
Name three supporting characters mentioned in the biographical introduction of the Kabir chapter and state one factual detail about each from the text.

## DIAGNOSTIC_ANSWER_1
Correct answer: (1) Guru Ramanand – Kabir's guru who initiated him into Bhakti; (2) Sultan Sikandar Lodi – the ruler who persecuted Kabir and forced him to flee Kashi; (3) Namdev (referred to as 'nkl th' in the text) – a fellow saint whose influence is noted in Kabir's tradition. A wrong answer that lists only Kabir's family (Loi, Kamal) or characters from other chapters shows the student cannot distinguish the chapter's specific supporting cast from general knowledge.

## DIAGNOSTIC_QUESTION_2
In the poem, Kabir addresses an "ifr" (sister). Explain in your own words what this address suggests about Kabir's view of spiritual kinship versus biological kinship.

## DIAGNOSTIC_ANSWER_2
Correct answer: By calling a fellow seeker "ifr" (sister), Kabir elevates spiritual companionship above blood relations, showing that in Nirguna Bhakti the bond of shared devotion ("eksj&eqoqQV") defines true family. A wrong answer that treats "ifr" as Kabir's biological sister reveals a literal reading that misses the poem's symbolic use of relationships to express egalitarian spirituality.

## DIAGNOSTIC_QUESTION_3
Using the biographical note, write a 4-sentence PEEL paragraph explaining how Sultan Sikandar Lodi functions as a foil to Kabir. Include one paraphrased textual detail.

## DIAGNOSTIC_ANSWER_3
Correct answer: Point: Sultan Sikandar Lodi represents orthodox state power that enforces religious conformity. Evidence: The text states that after many attempts to arrest him, Kabir had to leave Kashi and wander in old age. Explanation: The Sultan's persecution highlights Kabir's fearless commitment to truth—where the Sultan uses force, Kabir uses the "flag of love." Link: This contrast underscores the theme that true spirituality cannot be controlled by political authority. A weak answer that only narrates the event without the "Explanation" and "Link" steps shows the student cannot structure analytical writing.

## DIAGNOSTIC_QUESTION_4
Compare the roles of Guru Ramanand and the "ifr" in the poem. How does each represent a different dimension of Kabir's spiritual journey?

## DIAGNOSTIC_ANSWER_4
Correct answer: Guru Ramanand (biographical) represents the formal initiation and lineage of the Bhakti tradition—Kabir's connection to a guru-parampara. The "ifr" (poetic) represents the horizontal, egalitarian community of seekers where hierarchy dissolves. Together they show Kabir navigating both vertical (guru-disciple) and horizontal (devotee-devotee) spiritual relationships. A wrong answer that conflates them or sees only one dimension shows inability to analyze multiple textual layers.

## DIAGNOSTIC_QUESTION_5
Critique the view that supporting characters in this chapter are merely background figures with no thematic significance. Defend your position with two specific examples.

## DIAGNOSTIC_ANSWER_5
Correct answer: Supporting characters are thematic engines. Example 1: Sultan Sikandar Lodi's persecution dramatizes the conflict between institutional religion and Kabir's direct, personal Bhakti. Example 2: The "ifr" in the poem transforms the abstract idea of "prem" (love) into a living relationship, making the concept of "nirguna prem" tangible. A wrong answer that agrees they are "just background" reveals a surface-level reading that misses how every named figure in a compact NCERT chapter is deliberately chosen.

## DIAGNOSTIC_QUESTION_6
Create a 4-line dialogue (in Hindi or English) between Kabir and one supporting character from the chapter that reveals a core theme. Label the theme.

## DIAGNOSTIC_ANSWER_6
Expected answer: A dialogue where Kabir tells Sultan Sikandar Lodi: "Your sword cuts bodies, my word cuts ignorance." Theme: Power of truth over force. Or Kabir to "ifr": "Sister, the temple is not in Kashi, it beats in this chest." Theme: Internalization of worship. A poor answer that writes a generic moral conversation without anchoring in the chapter's specific characters/themes shows the student cannot synthesize character and theme creatively.

## COMMON_MISCONCEPTION
Students often think "supporting character analysis" means writing a mini-biography of each person (birth, death, achievements). In this chapter, the biographical note is only 100 words—the exam never asks for life histories. The real task is to explain *function*: how does this person's presence sharpen Kabir's portrait? For example, writing three sentences about Sultan Sikandar Lodi's reign is irrelevant; writing one sentence about how his persecution proves Kabir's courage is full marks.

## ON_FAILURE
If a student writes biographical summaries, stop them and say: "Close the book. Look at the question: 'How does this character reveal Kabir?' Now, find ONE interaction between them in the text. Write that interaction down. Now complete this sentence: 'This shows that Kabir is _____ because _____.' Repeat for two more characters. Do not write any fact that does not fit that sentence frame."

## BUILDS_ON
c11_hin_ar_cbse_10_004 (Character Analysis: Protagonist) – students must first know Kabir's core traits (fearless, egalitarian, Nirguna devotee) before they can see how others reflect or contrast them.

## LEADS_TO
c11_hin_ar_cbse_10_006 (Theme: Primary Theme and Message) – understanding how supporting characters embody themes prepares students to extract and articulate the chapter's central ideas.

## PREREQUISITE_NODE_IDS
c11_hin_ar_cbse_10_001, c11_hin_ar_cbse_10_002, c11_hin_ar_cbse_10_003, c11_hin_ar_cbse_10_004
## PREREQUISITE_REASONS
c11_hin_ar_cbse_10_001: Provides historical-religious context (Bhakti movement, Nirguna vs Saguna) needed to understand why figures like Ramanand and Sikandar Lodi matter.
c11_hin_ar_cbse_10_002: Establishes the narrative structure of the biographical note and poem so students can locate where each supporting character appears.
c11_hin_ar_cbse_10_003: Sets the atmosphere of persecution and wandering that frames Kabir's interactions with the Sultan and disciples.
c11_hin_ar_cbse_10_004: Defines Kabir's protagonist traits (courage, simplicity, devotion to formless God) which are the benchmark for all foil/complement analysis.

## FORWARD_NODE_IDS
c11_hin_ar_cbse_10_006, c11_hin_ar_cbse_10_007, c11_hin_ar_cbse_10_013, c11_hin_ar_cbse_10_014, c11_hin_ar_cbse_10_015, c12_hin_ar_cbse_06_005, c12_hin_ar_cbse_10_005

## FORWARD_REASONS
c11_hin_ar_cbse_10_006: Supporting characters concretize the primary theme (Nirguna Bhakti and social equality) enabling theme articulation.
c11_hin_ar_cbse_10_007: Secondary themes (guru-shishya parampara, religious persecution, spiritual kinship) are carried by specific supporting figures.
c11_hin_ar_cbse_10_013: Critical interpretation of the text requires evaluating how character dynamics shape meaning—this node provides the evidence base.
c11_hin_ar_cbse_10_014: Supporting characters (Rana, in-laws, society) appear as foils in thematic answers on patriarchy/orthodoxy.  
c11_hin_ar_cbse_10_015: Supporting characters (implied Pandit/Qazi/Society) are the foils against which the speaker defines himself.  
c12_hin_ar_cbse_06_005: Class 11 foundation on supporting character analysis in Aroh.  
c12_hin_ar_cbse_10_005: Class 11 supporting character analysis (Chapter 10 Aroh) builds the methodological foundation for functional character analysis.  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
none

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_10_004 -> c11_hin_ar_cbse_10_005 -> c11_hin_ar_cbse_10_006

## THIS_FORMULA
PEEL + Foil/Complement Framework: For each supporting character → Point (role), Evidence (textual detail), Explanation (contrast/complement to Kabir), Link (theme).

## FORMULA_VARIABLES
N/A

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
analytical

## CROSS_SUBJECT
c11_history_bhakti_movement | The Bhakti movement's social history (caste challenge, state persecution) provides the real-world backdrop for Kabir's interactions with Sultan Sikandar Lodi and Guru Ramanand.
c11_civics_constitutional_values | Kabir's egalitarian spiritual community ("ifr", disciples across castes) prefigures constitutional ideals of fraternity and equality before law.

## PREREQ_CONCEPT
Protagonist analysis (Kabir's core traits: Nirguna devotion, social rebellion, poetic simplicity) from node c11_hin_ar_cbse_10_004.

## PREREQ_BEFORE
Student must be able to list Kabir's three defining characteristics with one textual evidence each.

## PREREQ_STUCK
Review the "Character Analysis: Protagonist" node (c11_hin_ar_cbse_10_004) and re-read the biographical note highlighting every verb associated with Kabir (e.g., "fojksèk fd;k", "Hkwfe dh", "pyh xb±").

## WORKED_EXAMPLE_1
PROBLEM: Analyze how the figure of Guru Ramanand functions as a supporting character to reveal Kabir's attitude toward tradition and innovation in spirituality. Use the PEEL structure.

STEPS:
- Step 1: Identify the character and his textual reference – Guru Ramanand is mentioned in the biographical note as the guru from whom Kabir received initiation ("cpiu ls gh muosQ eu esa Ñ".k HkfDr dh Hkkouk tUe ys pqdh Fkh").
- Step 2: Determine the protagonist trait to be illuminated – Kabir's simultaneous respect for tradition (accepting a guru) and innovation (transcending ritual).
- Step 3: Select evidence – The text says Kabir "Reprint 2026-27 ehjk us yksdykt vkSj oqQy dh e;kZnk osQ uke ij yxk, x, lkekftd vkSj oSpkfjd caèkuksa dk ges'kk fojksèk fd;k" (broke social/religious stereotypes in the name of yoga and devotion).
- Step 4: Explain the foil/complement dynamic – Ramanand represents the orthodox guru-parampara; Kabir accepts the lineage but rejects its ritualistic boundaries (caste, idol-worship).
- Step 5: Link to theme – This duality embodies the Nirguna Bhakti theme: formless devotion that uses tradition's door but walks beyond its walls.

REASONING: The PEEL structure forces the student to move from textual fact to thematic insight. The foil framework (tradition vs innovation) is the analytical lens prescribed by the chapter's central tension.

ANSWER: Guru Ramanand serves as the traditional anchor that makes Kabir's radical departure visible. By accepting initiation from Ramanand, Kabir honors the guru-shishya parampara (Point). The text notes he "broke social and religious stereotypes in the name of yoga and devotion" (Evidence). This shows Kabir did not reject tradition wholesale—he used its authority to dismantle its exclusivity (Explanation). Thus, Ramanand's presence illuminates the theme that true Bhakti transcends external forms while acknowledging its roots (Link).

## WORKED_EXAMPLE_2
PROBLEM: The poem addresses an "ifr" (sister). Analyze how this poetic addressee functions as a supporting character to convey the theme of spiritual equality.

STEPS:
- Step 1: Locate the addressee in the poem – First stanza: "esjks ifr lksbZ" (O my sister, listen).
- Step 2: Identify the protagonist's message to her – "fxjèkj xksiky] nwljks u dksbZ tk osQ flj eksj&eqoqQV" (No one goes to the city of love with the flag of love and affection).
- Step 3: Determine the relationship dynamic – Horizontal, non-hierarchical; both are seekers on the same path.
- Step 4: Contrast with vertical relationships (guru, Sultan) – Unlike the guru (authority) or Sultan (power), the "ifr" shares equal status in devotion.
- Step 5: Connect to theme – The address "ifr" dissolves caste/gender hierarchy, making spiritual kinship the only kinship that matters in Nirguna Bhakti.

REASONING: The poem's direct address is a dramatic device. Analyzing the pronoun "ifr" instead of "guru" or "bhakta" reveals Kabir's intentional leveling of spiritual relationships.

ANSWER: The "ifr" in the poem is not a biological sister but a fellow traveler on the path of love. By addressing her as "ifr," Kabir establishes a horizontal bond of shared seeking (Point). He tells her that the "city of love" cannot be reached by external flags but only by internal "eksj&eqoqQV" (Evidence). Unlike his vertical relationship with Guru Ramanand (authority) or Sultan Sikandar Lodi (opposition), this relationship is one of mutuality—both are equal before the formless Divine (Explanation). This embodies the chapter's core theme: Nirguna Bhakti creates a community where caste, gender, and ritual status vanish, replaced by "prem" as the sole criterion (Link).

## WORKED_EXAMPLE_3
PROBLEM: Compare the thematic functions of Sultan Sikandar Lodi (biographical) and the "ifr" (poetic) as supporting characters. How do they together define the boundaries of Kabir's spiritual world?

STEPS:
- Step 1: List the two characters and their domains – Sultan Sikandar Lodi: historical/political domain (biographical note). "ifr": poetic/spiritual domain (poem).
- Step 2: Identify Kabir's stance toward each – Toward Sultan: defiance, flight, unwavering truth. Toward "ifr": invitation, shared journey, tenderness.
- Step 3: Extract textual evidence for each – Sultan: "fpÙkkSM+ jkt?kjkus esa vusd d"V mBkus osQ ckn ehjk okil esM+rk vk xb±A" (after many arrests, Kabir left Kashi). "ifr": "esjks ifr lksbZ… eksj&eqoqQV" (O sister… love and affection).
- Step 4: Analyze the contrast – Sultan represents external coercion that Kabir resists; "ifr" represents internal communion that Kabir nurtures.
- Step 5: Synthesize the dual boundary – The Sultan marks the outer limit: where state power ends, Kabir's spiritual freedom begins. The "ifr" marks the inner core: where ritual ends, love begins.
- Step 6: Link to chapter's thematic architecture – Together they frame Kabir's world: politically persecuted but spiritually expansive; socially isolated but communally connected through "prem."

REASONING: This worked example combines biographical and poetic texts, requiring the student to synthesize across the chapter's two genres—a key board exam skill.

ANSWER: Sultan Sikandar Lodi and the "ifr" function as the outer and inner boundaries of Kabir's spiritual universe. The Sultan, through persecution ("many attempts to arrest"), defines the political limit—Kabir's body can be exiled but not his truth (Point 1, Evidence 1). The "ifr," through the invitation to the "city of love," defines the spiritual center—Kabir's soul invites all to a space beyond ritual (Point 2, Evidence 2). The Sultan elicits defiance; the "ifr" elicits communion (Explanation). This duality structures the chapter's message: Nirguna Bhakti is both a refuge from state oppression and a radical equality that redefines human relations (Link).

## COMPETENCY_QUESTION_1
QUESTION: The biographical note mentions that Kabir "broke social and religious stereotypes in the name of yoga and devotion." Choose ONE supporting character (other than Kabir) and explain how that character's presence in the text makes this claim visible. Write your answer in PEEL format.

COMPETENCY: Textual evidence-based analytical writing

STEPS:
- Step 1: Select a supporting character (e.g., Sultan Sikandar Lodi, Guru Ramanand, "ifr", Namdev).
- Step 2: State the Point – how this character relates to "breaking stereotypes."
- Step 3: Provide Evidence – a specific line or detail from the biographical note or poem.
- Step 4: Explain – connect the evidence to the stereotype being broken (caste, ritual, gender, political obedience).
- Step 5: Link – tie back to the claim about "yoga and devotion" as the motive.

ANSWER: (Sample for Sultan Sikandar Lodi) Point: Sultan Sikandar Lodi embodies the orthodox power structure that enforces religious stereotypes. Evidence: The text states the Sultan made "many attempts to arrest" Kabir, forcing him to leave Kashi in old age. Explanation: The Sultan's persecution was triggered by Kabir's refusal to conform to state-sanctioned Islam or ritual Hinduism—his "yoga and devotion" to a formless God broke the stereotype that spirituality requires institutional mediation. Link: Thus, the Sultan's hostility proves that Kabir's Nirguna Bhakti was a lived rebellion, not just poetry.

DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: "Supporting characters in Kabir's chapter are not people but arguments." Evaluate this statement by analyzing two supporting characters. In your answer, define what "argument" means in a literary sense, then apply it to each character with textual support.

COMPETENCY: Literary evaluation and conceptual application

STEPS:
- Step 1: Define "argument" in literary terms – a character who embodies a perspective or value that the text debates.
- Step 2: Choose two supporting characters (e.g., Sultan Sikandar Lodi and "ifr").
- Step 3: For each, state the argument they embody (Sultan: state control over religion; "ifr": love as the only religious qualification).
- Step 4: Show how Kabir's interaction with them stages the debate.
- Step 5: Conclude whether the statement holds, with nuance.

ANSWER: In literary terms, an "argument" is a dramatized perspective that the protagonist engages with. Sultan Sikandar Lodi embodies the argument that religious truth is enforced by political authority—his arrests "argue" that dissent is punishable. Kabir's refusal to recant "argues" back that truth is internal. The "ifr" embodies the argument that spiritual community is built on "prem" alone, not caste or ritual—her address as "sister" "argues" for radical equality. Kabir's invitation to the "city of love" extends that argument. The statement is largely true: these characters are thinly sketched as individuals but thickly drawn as ideological positions. However, calling them "not people" overstates it—the biographical note gives Sultan historical weight, and the poem gives "ifr" emotional warmth. They are people *as* arguments.

DIFFICULTY: hard