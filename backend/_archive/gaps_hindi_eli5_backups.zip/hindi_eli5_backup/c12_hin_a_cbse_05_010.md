## DEFINITION
Vocabulary in Context refers to the skill of determining the precise meaning, connotation, and emotional weight of a word as it is used within a specific literary text, rather than relying solely on its dictionary definition. In poetry, this includes understanding how a word’s sound, imagery, and cultural associations contribute to the poem’s tone, theme, and aesthetic effect.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student can independently identify key vocabulary from the poems "olar vk;k" and "rksM+ks", explain each word’s contextual meaning with textual evidence, and articulate how the poet’s lexical choices shape the central imagery and emotional resonance of the poems.

## SCOPE_BOUNDARY
This node covers the key vocabulary listed in the NCERT 'kCnkFkZ vkSj fVIi.kh' section for Chapter 5 (Jagjit Singh’s poems "olar vk;k" and "rksM+ks"). It focuses on contextual interpretation, connotation, and poetic function. It does not cover grammatical analysis (handled in node c12_hin_a_cbse_05_011) or comprehensive thematic essay writing (handled in node c12_hin_a_cbse_05_013).

## WALKTHROUGH
Imagine you are reading "olar vk;k" and you encounter the word "oqQÅduk" in the very first line. You might know its dictionary meaning — "morning" — but the poem uses it to evoke a specific sensory experience: the crisp, fragrant air of dawn that carries the promise of a new day, yet the poet says "olar vk;k" (the morning came) as if it arrived uninvited. To master vocabulary in context, start by reading the poem aloud, circling every word that feels charged or unfamiliar. Then, for each word, ask: (1) What is the literal meaning? (2) What images, sounds, or memories does it trigger in this specific line? (3) How does it connect to the poem’s broader theme of inevitable change and the futility of resisting time? The key insight is that in poetry, words are not labels; they are packed with cultural memory and sensory detail that the poet deliberately chooses to compress layers of meaning.

## DIAGNOSTIC_QUESTION_1
List any four key words from the poem "olar vk;k" that are explained in the NCERT vocabulary section ('kCnkFkZ vkSj fVIi.kh').

## DIAGNOSTIC_ANSWER_1
Correct answer: Any four from: oqQÅduk, pqjeqjk,, r#oj, fiQjdh, enueghuk, ngj&ngj, ngduk, <kd, uanu ou, eèkqeLr, fid, ux.;.  
A wrong answer (e.g., listing words not in the vocabulary list like "olar" or "vk;k") reveals the student cannot distinguish between the poet’s general vocabulary and the specific terms the textbook highlights for contextual study. This suggests they are not using the NCERT apparatus as a study tool.

## DIAGNOSTIC_QUESTION_2
Explain the difference between the literal meaning of "fiQjdh" and its contextual meaning in the line "f[kyh gqbZ gok vkbZ] fiQjdh&lh vkbZ] pyh xbZ" from "olar vk;k".

## DIAGNOSTIC_ANSWER_2
Correct answer: Literally, "fiQjdh" means "evening" or "twilight". Contextually, paired with "fiQjdh&lh" (lingering evening), it conveys a reluctant, heavy dusk that drags its feet — the "gok" (cow) has returned, the "lh" (dust) has settled, yet the evening refuses to end, mirroring the poet’s sense of time stretching painfully.  
A wrong answer that only gives the dictionary meaning shows the student treats vocabulary as static definitions. They miss how the compound "fiQjdh&lh" and the verb "pyh xbZ" (slipped away) personify time as a weary entity, which is central to the poem’s mood of helplessness.

## DIAGNOSTIC_QUESTION_3
In the poem "rksM+ks", the word "O;kih" appears in the line "vius eu osQ eSnkuksa ij O;kih oSQlh Åc gS". Use "O;kih" in an original sentence that captures its poetic connotation of being deeply, almost painfully, rooted.

## DIAGNOSTIC_ANSWER_3
Correct answer: "The old banyan tree stood O;kih in the courtyard, its roots embracing the earth so tightly that no storm could dislodge it — a silent witness to generations."  
A wrong answer like "The plant is O;kih in the pot" treats it as a simple botanical term ("firmly fixed"). The student fails to grasp that in the poem, "O;kih" describes the heart’s memories (eSnkuksa) as immovable, almost burdensome, fixtures — the connotation is emotional weight, not physical stability.

## DIAGNOSTIC_QUESTION_4
Compare how the words "ngj&ngj" (in "olar vk;k") and "ux.;" (in the same poem) contribute to the portrayal of time’s passage. Use specific lines as evidence.

## DIAGNOSTIC_ANSWER_4
Correct answer: "ngj&ngj" (slowly, gradually) appears in "ngj&ngj ngosaQxs dgha <kd osQ taxy vke ckSj vkosaxs" — it depicts time as a creeping, almost imperceptible thief that steals youth drop by drop. "ux.;" (sudden, unexpected) appears in "vkt osQ ux.; fnu tkuw¡xk" — it marks the shocking moment when the inevitable (old age/death) finally announces itself. Together, they frame time as a dual process: a long, quiet erosion followed by a sudden, irreversible arrival.  
A wrong answer that defines them only as "slowly" and "suddenly" misses the structural contrast: the poem moves from the prolonged agony of waiting (ngj&ngj) to the blunt finality of the end (ux.;). This contrast is the poem’s temporal architecture.

## DIAGNOSTIC_QUESTION_5
Which single word from the combined vocabulary list of both poems do you think most powerfully conveys the central theme of "the inevitability of aging and the futility of resistance"? Justify your choice with reference to at least two lines.

## DIAGNOSTIC_ANSWER_5
Correct answer (example): "rksM+ks" (from the poem "rksM+ks"). The repeated refrain "rksM+ks rksM+ks rksM+ks" is a command to pile up — wood, fire, memories, even the heart’s ashes. It appears in "lc [ksr cukdj NksM+ks" (make a pyre and pile it up) and "xksM+ks xksM+ks xksM+ks" (burn, burn, burn). The word embodies the frantic, repetitive human attempt to build meaning against entropy, yet the imperative tone reveals desperation, not control.  
A wrong answer choosing a descriptive word like "fiQjdh" or "enueghuk" shows the student picks imagery over thematic function. They haven’t learned to ask: "Which word *performs* the theme?" The refrain "rksM+ks" is a verb of action that becomes a ritual of surrender.

## DIAGNOSTIC_QUESTION_6
Write a two-line poem (in Hindi or English) using at least three words from the NCERT vocabulary list, preserving the melancholic, reflective mood of Jagjit Singh’s poems.

## DIAGNOSTIC_ANSWER_6
Expected criteria: The poem must use three vocabulary words (e.g., ngj&ngj, ux.;, O;kih) naturally, not forced. The mood should be contemplative, dealing with time/memory. Example: "ngj&ngj beet gayi raat, ux.; aayi subah ki khabar / O;kih yaadein ab bhi hain, jaise koi purana shajar."  
A poor answer that merely strings words together ("ngj&ngj ux.; O;kih hain") reveals the student sees vocabulary as isolated tokens. They haven’t internalized that these words carry emotional atmospheres that must be woven into a coherent voice.

## COMMON_MISCONCEPTION
Students memorize the NCERT glossary meanings as fixed definitions and reproduce them in exams without linking the word to its specific line, stanza, or the poem’s emotional arc. For instance, they write "enueghuk = dkenso dk eghuk" but never explain why the poet chooses this pastoral, rustic term instead of a more urban "subah" — missing how it grounds the poem in a timeless, rural rhythm that contrasts with modern anxiety. This error costs marks in both board exams (where "contextual meaning" is explicitly asked) and competitive exams (where inference questions test connotative depth).

## ON_FAILURE
1. Have the student re-read both poems aloud, circling every glossed word in the text.  
2. For each circled word, write a two-sentence "Context Card": Sentence 1 = literal meaning; Sentence 2 = what the word *does* in that line (image, sound, emotion).  
3. Practice one 3-mark board-style question daily: "Explain the contextual significance of [word] in the given line." Use the marking scheme: 1 mark for meaning, 1 for textual link, 1 for thematic connection.  
4. After one week, re-attempt Diagnostic Questions 2, 4, and 5. If errors persist, revisit node c12_hin_a_cbse_05_008 (Imagery and Metaphor) to see how vocabulary builds imagery.

## BUILDS_ON
The ability to identify and interpret poetic imagery and metaphor (node c12_hin_a_cbse_05_008), because vocabulary in context is the raw material from which imagery is constructed.

## LEADS_TO
Grammar: Language Usage in the Text (node c12_hin_a_cbse_05_011), where contextual vocabulary informs syntactic and stylistic analysis, and Comprehension (node c12_hin_a_cbse_05_012), where precise word knowledge enables accurate inference.

## PREREQUISITE_NODE_IDS
c12_hin_a_cbse_05_001, c12_hin_a_cbse_05_008, c12_hin_a_cbse_05_009, c11_hin_ar_cbse_05_010
## PREREQUISITE_REASONS
c12_hin_a_cbse_05_001: Provides the biographical and historical context of Jagjit Singh, without which words like "oqQÅduk" (rural dawn) lose their cultural specificity.  
c12_hin_a_cbse_05_008: Teaches how imagery works; vocabulary nodes supply the lexical building blocks of that imagery.  
c12_hin_a_cbse_05_009: Irony and symbolism often operate through lexical ambiguity; understanding connotation is prerequisite.  
c11_hin_ar_cbse_05_010: Class 11 vocabulary node establishes the method of contextual analysis; Class 12 deepens it with more complex poems.

## FORWARD_NODE_IDS
c12_hin_a_cbse_05_011, c12_hin_a_cbse_05_012, c12_hin_a_cbse_05_013, c12_hin_a_cbse_05_014

## FORWARD_REASONS
c12_hin_a_cbse_05_011: Grammatical analysis (e.g., compound formation in "fiQjdh&lh") requires knowing the base vocabulary first.  
c12_hin_a_cbse_05_012: Literal and inferential comprehension questions directly test vocabulary in context.  
c12_hin_a_cbse_05_013: Critical interpretation of theme and tone is impossible without precise lexical understanding.
c12_hin_a_cbse_05_014: Key vocabulary (e.g., oqQÅduk, pqjeqjk, r#oj) — ensures accurate quoting in Hindi.  

## CROSS_SUBJECT_PREREQS
c11_hin_ar_cbse_05_010, c11_hin_v_cbse_05_010
## CROSS_SUBJECT_REASONS
c11_hin_ar_cbse_05_010: The Antra (Core) vocabulary node from Class 11 Chapter 5 introduces the same pedagogical method for a different poet; the skill transfers directly.  
c11_hin_v_cbse_05_010: The Vitan (Supplementary) vocabulary node offers additional practice with non-fiction prose vocabulary, reinforcing the "context over dictionary" principle across genres.

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_05_010 -> c12_hin_a_cbse_05_010 -> c12_hin_a_cbse_05_011

## THIS_FORMULA
N/A - conceptual

## FORMULA_VARIABLES
N/A

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
linguistic

## CROSS_SUBJECT
N/A | Analyzing key terminology in historical sources (e.g., "swaraj", "satyagraha") requires the same contextual vocabulary skill: words carry political connotations beyond dictionary definitions.  
 N/A | Interpreting geographical terms like "anthropocene" or "biodiversity hotspot" in case studies demands understanding how discipline-specific vocabulary shapes the argument, just as poetic vocabulary shapes the poem.
## PREREQ_CONCEPT
Words in poetry are not transparent labels; they are compressed cultural and sensory units whose meaning is activated by their specific placement in the text.

## PREREQ_BEFORE
The student must have read both poems at least twice and marked every word listed in the NCERT 'kCnkFkZ vkSj fVIi.kh' section.

## PREREQ_STUCK
If stuck, review the NCERT vocabulary list alongside the poem text, and for each word, locate its exact line and stanza — this physical mapping is the first step to contextual thinking.

## WORKED_EXAMPLE_1
PROBLEM: Analyze the word "pqjeqjk," in the line "pqjeqjk, ik¡o rys m¡Qps rjQoj ls fxjs" from "olar vk;k". Explain its literal meaning, contextual image, and thematic contribution.

STEPS:
- Step 1: Locate the word in the poem. It appears in stanza 1, describing the morning’s arrival: "pqjeqjk, ik¡o rys m¡Qps rjQoj ls fxjs".
- Step 2: Consult the NCERT glossary: "pqjeqjk, = pjejkus dh vkok”k" (desire to cook/prepare food). Note the root "pqj" (to cook/ripen).
- Step 3: Examine the context: The morning is personified as a woman (ik¡o) coming with a "pqjeqjk," — a desire to cook. But she comes "m¡Qps rjQoj ls" (from the back door), quietly, almost sneakily.
- Step 4: Analyze the imagery: "Cooking" suggests nurturing, warmth, daily ritual. The "back door" suggests informality, intimacy, perhaps the domestic sphere traditionally associated with women. The morning doesn't announce itself grandly; it slips in with a humble, life-sustaining intention.
- Step 5: Connect to theme: The poem contrasts the grand, indifferent passage of time ("ngj&ngj ngosaQxs...") with this tiny, tender human moment. "pqjeqjk," anchors the cosmic in the domestic — the universe may be eroding youth, but the morning still brings the simple urge to feed, to nurture. This tension is the poem’s emotional core.

REASONING: The steps move from textual location to dictionary support, then to literary context (personification, gender, spatial metaphor), and finally to thematic synthesis. This mirrors the board exam expectation: meaning + evidence + significance.

ANSWER: "pqjeqjk," literally means "desire to cook". Contextually, it personifies the morning as a nurturing woman entering quietly through the back door with the intention to prepare a meal. Thematically, it juxtaposes the vast, cruel erosion of time (depicted elsewhere in the poem) with the persistent, humble act of care — suggesting that even in inevitable decay, the instinct to nurture survives.

## WORKED_EXAMPLE_2
PROBLEM: The word "Ålj&catj" appears in "rksM+ks" as ";s Ålj catj rksM+ks". Explain how this compound word functions differently from its two separate components.

STEPS:
- Step 1: Break the compound: "Ålj" (fire) + "catj" (wood/fuel). The glossary says "vuqitkÅ ”kehu" (unwilling/reluctant) — but that seems contradictory; actually "Ålj&catj" here means "firewood" as a combined entity ready for burning.
- Step 2: Check the line: ";s Ålj catj rksM+ks" — "Pile up this firewood." The imperative "rksM+ks" (pile up) acts on the compound object.
- Step 3: Consider the separate words: "Ålj" alone is the element fire, often symbolic of purification, destruction, energy. "catj" alone is inert wood, potential fuel. Together, "Ålj&catj" denotes the prepared material for a pyre — wood that *will become* fire.
- Step 4: Analyze the poetic effect: The compound fuses the agent (fire) and the patient (wood) into a single noun. This linguistic fusion mirrors the poem’s theme: the boundary between the burner and the burnt, the self and the memory, is collapsing. The command "rksM+ks" applies to both: pile up the firewood *and* the fire itself.
- Step 5: Thematic link: In the next refrain "xksM+ks xksM+ks xksM+ks" (burn, burn, burn), the piled "Ålj&catj" is consumed. The compound word thus encapsulates the entire cycle: preparation -> ignition -> ashes. It is the poem’s material metaphor for a life readied for its own ending.

REASONING: Morphological analysis of compounds is a standard CBSE competency. The step-by-step shows how form (compounding) enacts meaning (fusion of opposites), a key analytical move for Class 12.

ANSWER: "Ålj&catj" is a compound meaning "firewood", but its internal structure fuses "fire" (Ålj) and "wood" (catj) into a single entity that already contains its own combustion. Unlike the separate words which denote distinct elements, the compound represents the *readiness* for burning — the wood that has accepted its fate as fuel. This linguistic fusion mirrors the poem’s insistence that the heart’s memories (eSnkuksa) are already "O;kih" (fixed) on the pyre, awaiting the final "xksM+ks".

## WORKED_EXAMPLE_3
PROBLEM: Compare the use of "ngj&ngj" in "olar vk;k" and "ux.;" in the same poem to show how the poet structures the reader’s experience of time. Write a paragraph suitable for a 5-mark board answer.

STEPS:
- Step 1: Identify both words in the text. "ngj&ngj" in stanza 2: "ngj&ngj ngosaQxs dgha <kd osQ taxy vke ckSj vkosaxs". "ux.;" in stanza 3: "vkt osQ ux.; fnu tkuw¡xk".
- Step 2: Define each contextually. "ngj&ngj" = slowly, imperceptibly, drop by drop. It modifies how "ngosaQxs" (youth/beauty) leaves — "dgha <kd osQ taxy" (from the body’s heat/sweat). "ux.;" = sudden, unexpected, without warning. It modifies "fnu" (day) — the day of reckoning.
- Step 3: Analyze the temporal sequence. The poem moves from a prolonged process (stanza 2) to a sudden event (stanza 3). "ngj&ngj" governs the *duration* of aging; "ux.;" marks the *terminus* of aging.
- Step 4: Analyze the emotional effect on the reader. "ngj&ngj" creates a sense of dreadful slowness — we feel each drop leaving. "ux.;" delivers a shock — the end arrives before we are ready. The reader experiences both the dragged-out suffering and the brutal finality.
- Step 5: Synthesize for the answer. The poet uses this lexical pair to structure the poem’s temporal architecture: first the long, quiet theft (ngj&ngj), then the abrupt foreclosure (ux.;). This dual tempo is the poem’s central formal strategy for conveying the tragedy of aging.

REASONING: This example combines two vocabulary items into a comparative analysis, requiring the student to see words as structural elements, not isolated definitions. The 5-step paragraph structure (locate, define, sequence, effect, synthesize) matches the CBSE 5-mark answer format.

ANSWER: In "olar vk;k", Jagjit Singh deploys "ngj&ngj" and "ux.;" as the two poles of temporal experience. "ngj&ngj" (slowly, gradually) describes the stealthy, daily erosion of youth — "ngj&ngj ngosaQxs dgha <kd osQ taxy vke ckSj vkosaxs" — where life drains drop by drop from the body’s warmth. This creates a prolonged, almost unbearable tension. In stark contrast, "ux.;" (sudden, unforeseen) announces the final day: "vkt osQ ux.; fnu tkuw¡xk" — the day of death arrives without warning. The poem’s temporal architecture moves from the interminable slowness of decay (ngj&ngj) to the instantaneous finality of the end (ux.;). Together, they force the reader to inhabit both the chronic anxiety of aging and the acute shock of mortality, making the poem’s meditation on time viscerally structural.

## COMPETENCY_QUESTION_1
QUESTION: The NCERT glossary defines "enueghuk" as "dkenso dk eghuk (olar)". In the poem "olar vk;k", the line reads "veqd fnu veqd ckj enueghus dh gksosxh iapeh". Explain why the poet chooses this specific rustic, pastoral compound ("enueghuk") instead of a more common word like "subah" or "prabhaat". What does this choice reveal about the poem’s relationship to time and tradition?

COMPETENCY: Literary Analysis – Lexical Choice and Cultural Connotation

STEPS:
- Step 1: Identify the literal meaning and register of "enueghuk" (rural, agricultural, cowherd’s morning) vs. "subah" (neutral, urban, Persianate) and "prabhaat" (Sanskritized, literary, formal).
- Step 2: Locate the line: "veqd fnu veqd ckj enueghus dh gksosxh iapeh" — "the hope that used to arise every day, many times, from the cowherd’s morning."
- Step 3: Analyze the imagery: "enueghuk" evokes a cyclic, nature-governed rhythm — cows waking, milking, the village stirring. It is repetitive ("veqd fnu veqd ckj") and rooted in a pre-modern temporality.
- Step 4: Connect to theme: The poem laments the loss of youth and the approach of death. By anchoring memory in "enueghuk", the poet suggests that the speaker’s past belongs to a timeless, almost mythic rural order — one where hope was as regular as dawn. The word choice resists modern, linear clock-time.
- Step 5: Conclude: The lexical choice enacts the poem’s longing for a time when life was measured in natural cycles, not in the "ngj&ngj" erosion of the body.

ANSWER: The poet chooses "enueghuk" (cowherd’s morning) over "subah" or "prabhaat" to embed the speaker’s memory in a specific cultural and temporal world: the rural, agrarian cycle where dawn is announced by cattle, not clocks. This compound carries connotations of repetition, simplicity, and harmony with nature — "veqd fnu veqd ckj" (every day, many times) hope arose from this rhythm. In a poem about the cruel linearity of aging ("ngj&ngj ngosaQxs..."), "enueghuk" evokes a lost cyclical time where renewal was guaranteed. The word itself becomes a vessel of nostalgia, contrasting the poem’s present inevitability with a past where morning was a promise, not a threat.

DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: In "rksM+ks", the refrain shifts from "rksM+ks rksM+ks rksM+ks" (pile up) to "xksM+ks xksM+ks xksM+ks" (burn). Using the vocabulary entries for "rksM+ks" (implied: to pile, to heap) and "xksM+ks" (implied: to burn, to reduce to ashes), analyze how this single phonetic shift (r -> x) enacts the poem’s philosophical movement from accumulation to dissolution. Support your answer with at least two specific lines.

COMPETENCY: Critical Thinking – Phonetic-Semantic Patterning and Thematic Structure

STEPS:
- Step 1: Note the phonetic similarity: both are onomatopoeic, repetitive imperatives; the only change is the initial consonant cluster (rk -> xk). This creates a sonic echo that binds the two acts.
- Step 2: Locate the lines: First refrain: "rksM+ks rksM+ks rksM+ks ;s iRFkj ;s p^kuas ;s >wBs caèku VwVsa". Second refrain: "xksM+ks xksM+ks xksM+ks iz'u&vH;kl".
- Step 3: Analyze the semantic shift: "rksM+ks" is constructive (gathering, building a pyre, stacking memories). "xksM+ks" is destructive (burning, consuming, releasing). The pyre must be built before it can burn.
- Step 4: Interpret the philosophical movement: The poem begins with the human impulse to accumulate — experiences ("iRFkj"), fuel ("p^kuas"), even the "caèku" (shadows/shades) of the past. But accumulation is futile; the only resolution is "xksM+ks" — letting go through fire. The phonetic shift mirrors the inevitability of this transition: the sound itself "burns" from a harder 'r' to a breathier 'x'.
- Step 5: Synthesize: The vocabulary shift is not decorative; it is the poem’s argument in miniature. We spend life "rksM+ks"-ing; death forces "xksM+ks". The refrain structure makes this audible.

ANSWER: The shift from "rksM+ks" to "xksM+ks" is the poem’s sonic and semantic engine. "rksM+ks" (pile up) governs the first half: "rksM+ks rksM+ks rksM+ks ;s iRFkj ;s p^kuas ;s >wBs caèku VwVsa" — the speaker frantically gathers the first firewood, the logs, the very shadows of the past. This is the human project of building meaning through accumulation. But the structure demands its counterpart: "xksM+ks xksM+ks xksM+ks" (burn, burn, burn) — the pyre is lit, the accumulated self is consumed. The phonetic shift from the rolled, effortful 'rk' to the fricative, exhaling 'xk' enacts the release of breath, the surrender of the constructed ego. The vocabulary does not merely describe the ritual; the refrain *performs* the philosophy: all piling is prelude to burning. The words are the ritual.

DIFFICULTY: hard