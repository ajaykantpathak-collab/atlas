## DEFINITION
Irony is a literary device where the intended meaning of words or events is opposite to their literal or expected meaning, often highlighting a contradiction. Symbolism is the use of objects, characters, or actions to represent abstract ideas or qualities beyond their literal sense. In Mahadevi Varma's poems, irony exposes the injustice faced by the weak, while the 'lamp' (bZ'oj) symbolizes hope, resilience, and the human spirit.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student can identify at least two instances of irony and two symbols in the poems, explain how each device deepens the theme, and write a structured analysis using textual evidence.

## SCOPE_BOUNDARY
This node covers irony (situational, dramatic, verbal) and symbolism as used in the two poems of Chapter 14. It does not cover other literary devices like alliteration, personification, or rhyme scheme, which are addressed in other nodes.

## WALKTHROUGH
Imagine you are reading a poem where a powerful king punishes a weak woman for seeking justice, but the poem calls it "justice" – that contradiction is irony. Now think of a small lamp that a woman wants to keep burning despite storms; that lamp is not just a light but a symbol of her undying hope. To analyze these devices, first read the poems aloud to hear the tone. Then mark lines where the literal meaning clashes with the implied meaning (irony) or where an object carries extra meaning (symbol). Ask: What is the poet really saying? How does the device make the theme stronger? The key insight is that irony and symbolism work together to reveal the poet's critique of power and celebration of resilience.

## DIAGNOSTIC_QUESTION_1
Define irony and symbolism in your own words, giving one example from everyday life for each.

## DIAGNOSTIC_ANSWER_1
Irony occurs when the opposite of what is expected happens, e.g., a fire station burning down. Symbolism is when an object represents a deeper idea, e.g., a dove representing peace. A wrong answer (e.g., confusing irony with coincidence or symbolism with metaphor) shows the student cannot distinguish the devices or grasp their functional difference.

## DIAGNOSTIC_QUESTION_2
In the first poem, the king calls his punishment of Mahadevi Varma 'justice'. Explain why this is an example of situational irony.

## DIAGNOSTIC_ANSWER_2
Situational irony arises because the king's action (punishing a woman for demanding justice) is the opposite of what justice means. The label 'justice' applied to an unjust act creates the irony. A wrong answer that only defines irony without linking to the specific situation shows the student cannot apply the concept to the text.

## DIAGNOSTIC_QUESTION_3
Identify the symbol of the 'lamp' (bZ'oj) in the second poem and explain what it represents in the context of the woman's struggle.

## DIAGNOSTIC_ANSWER_3
The lamp symbolizes the woman's inner strength, hope, and desire to protect her dignity (her 'home') against external oppression. The steps: 1) locate the lamp imagery, 2) note the woman's plea to keep it lit, 3) connect to her resistance. A wrong answer that treats the lamp only as a literal object misses the symbolic layer.

## DIAGNOSTIC_QUESTION_4
Compare the use of irony in the first poem with the use of symbolism in the second poem. How do both devices serve the common theme of resistance against injustice?

## DIAGNOSTIC_ANSWER_4
Irony in the first poem exposes the hypocrisy of power by showing the gap between the king's claim of justice and his tyrannical act. Symbolism in the second poem embodies the quiet, persistent resistance of the marginalized through the lamp that refuses to go out. Together, they highlight the theme: injustice is loud but fragile, while resistance is quiet but enduring. A wrong answer that treats the devices in isolation fails to see the thematic unity.

## DIAGNOSTIC_QUESTION_5
Critique the effectiveness of Mahadevi Varma's use of irony versus symbolism in conveying the poems' message. Which device do you find more powerful and why?

## DIAGNOSTIC_ANSWER_5
Both are effective but in different ways: irony shocks the reader into recognizing systemic injustice, while symbolism invites empathy and lingers as a lasting image of hope. A justified critique might argue symbolism is more powerful because it transcends the specific historical context and becomes universal. A wrong answer that merely prefers one without textual justification shows lack of evaluative skill.

## DIAGNOSTIC_QUESTION_6
Write a short stanza (4-6 lines) that uses both irony and a symbol to express a personal experience of facing an unfair situation but keeping hope alive.

## DIAGNOSTIC_ANSWER_6
A good answer will include a clear ironic contrast (e.g., "They called it fairness when they took my voice") and a sustained symbol (e.g., "A seed beneath the snow, I wait for spring"). A poor answer may use only one device or confuse irony with sarcasm, indicating incomplete mastery.

## COMMON_MISCONCEPTION
Students often confuse irony with mere coincidence or bad luck, and they treat symbols as just 'metaphors'. For example, they may say the king's punishment is 'ironic' because it's sad, not because it contradicts the concept of justice. They may say the lamp is a metaphor for hope, missing that a symbol operates throughout the poem and carries cultural weight. This error arises because both devices involve 'meaning beyond literal', but irony relies on contradiction while symbolism relies on representation.

## ON_FAILURE
Step 1: Re-read the two poems focusing only on lines where the speaker's tone suggests a gap between words and reality (irony) and where an object is repeatedly emphasized (symbol). Step 2: Create a two-column table: Column A – Literal meaning; Column B – Implied meaning. Fill for 3-4 key lines. Step 3: For symbolism, list the object, its literal function, and its abstract association in the poem. Step 4: Write one paragraph explaining how the contradiction (irony) or the object (symbol) deepens the theme. Practice with a new short poem.

## BUILDS_ON
This node builds on the understanding of imagery and metaphor (c11_hin_ar_cbse_14_008) because both irony and symbolism often operate through imagery and metaphorical language.

## LEADS_TO
This node enables critical thinking and interpretation (c11_hin_ar_cbse_14_013) where students synthesize devices to form an overall analysis of the chapter.

## PREREQUISITE_NODE_IDS
c11_hin_ar_cbse_14_001, c11_hin_ar_cbse_14_002, c11_hin_ar_cbse_14_003, c11_hin_ar_cbse_14_004, c11_hin_ar_cbse_14_005, c11_hin_ar_cbse_14_006, c11_hin_ar_cbse_14_007, c11_hin_ar_cbse_14_008
## PREREQUISITE_REASONS
c11_hin_ar_cbse_14_001: Provides historical context of Mahadevi Varma and the Chhayavad movement, essential for understanding the poems' background.
c11_hin_ar_cbse_14_002: Understanding plot and narrative structure helps locate where irony and symbolism appear in the poems.
c11_hin_ar_cbse_14_003: Setting and atmosphere influence the tone, which is crucial for detecting irony.
c11_hin_ar_cbse_14_004: Protagonist analysis reveals the speaker's perspective, necessary for interpreting ironic statements.
c11_hin_ar_cbse_14_005: Supporting characters (like the king) are central to the situational irony in the first poem.
c11_hin_ar_cbse_14_006: Primary theme (resistance against injustice) is the message that irony and symbolism serve.
c11_hin_ar_cbse_14_007: Secondary themes (gender, power) are illuminated by these devices.
c11_hin_ar_cbse_14_008: Imagery and metaphor are foundational; irony and symbolism often build upon them.

## FORWARD_NODE_IDS
c11_hin_ar_cbse_14_010, c11_hin_ar_cbse_14_011, c11_hin_ar_cbse_14_012, c11_hin_ar_cbse_14_013, c11_hin_ar_cbse_14_014, c11_hin_ar_cbse_14_015, c12_hin_a_cbse_05_009, c12_hin_a_cbse_10_009, c12_hin_a_cbse_14_009, c12_hin_al_cbse_01_009, c12_hin_ar_cbse_09_009, c12_hin_ar_cbse_12_009, c12_hin_ar_cbse_14_009

## FORWARD_REASONS
c11_hin_ar_cbse_14_010: Vocabulary in context requires understanding of words used ironically or symbolically.
c11_hin_ar_cbse_14_011: Grammar and language usage includes analyzing how syntactic choices create irony.
c11_hin_ar_cbse_14_012: Comprehension questions often ask to explain the effect of irony and symbolism.
c11_hin_ar_cbse_14_013: Critical thinking and interpretation directly depend on mastering these devices.
c11_hin_ar_cbse_14_014: Writing skills tasks may require using irony or symbolism in creative writing.
c11_hin_ar_cbse_14_015: Speaking and listening discussions will explore interpretations based on these devices.
c12_hin_a_cbse_05_009: अगला तार्किक चरण: Irony is a literary device where the intended meaning of words or a situation is opposite to their l... इस नोड की अवधारणाओं को सीधे उपयोग/विस्तारित करता है।  
c12_hin_a_cbse_10_009: Chapter 14 traced symbol evolution across a novel — models longitudinal symbolic reading.  
c12_hin_a_cbse_14_009: Class 11 coverage of the same devices ensures students have prior exposure to definitions and simple examples.  
c12_hin_al_cbse_01_009: Class 11 Antra Chapter 14 Irony and Symbolism node refines evaluation skills.  
c12_hin_ar_cbse_09_009: Prepares for creative application (writing own examples).  
c12_hin_ar_cbse_12_009: अगला तार्किक चरण: Irony in this story is the contrast between appearance and reality — where the wealthy waste water c... इस नोड की अवधारणाओं को सीधे उपयोग/विस्तारित करता है।  
c12_hin_ar_cbse_14_009: Class 11 coverage of irony and symbolism in the same chapter establishes baseline definitions and simple identification; Class 12 deepens to functional analysis and thematic integration.  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
none

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_14_008 -> c11_hin_ar_cbse_14_009 -> c11_hin_ar_cbse_14_013

## THIS_FORMULA
N/A - conceptual

## FORMULA_VARIABLES
N/A

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
analytical

## CROSS_SUBJECT
c11_history_colonialism | The poems reflect resistance against oppressive power structures, paralleling historical anti-colonial struggles where irony and symbolism were used in literature and speeches.
c11_civics_democracy_rights | The theme of justice denied to the weak connects to civic concepts of rights, equality, and the rule of law, where irony highlights the gap between law and practice.

## PREREQ_CONCEPT
Understanding of basic literary devices (imagery, metaphor) and the ability to distinguish literal from figurative meaning.

## PREREQ_BEFORE
Student must be able to identify the speaker, tone, and central idea of each poem.

## PREREQ_STUCK
Review the distinction between metaphor (direct comparison) and symbol (object representing an idea throughout a work) from node c11_hin_ar_cbse_14_008.

## WORKED_EXAMPLE_1
PROBLEM: Analyze the irony in the lines where the king punishes Mahadevi Varma after she demands justice for the weak. Explain how this irony strengthens the poem's critique of authority.
STEPS:
- Step 1: Identify the literal event – the king punishes the poet for asking him to uphold justice.
- Step 2: Identify the expected norm – a just ruler rewards those who seek justice, not punishes them.
- Step 3: Note the contradiction – the king's action is the opposite of justice, yet he calls it justice (or the situation is presented as justice).
- Step 4: Determine the type of irony – situational irony (outcome opposite to expectation) and possibly dramatic irony (reader knows the injustice while the king claims righteousness).
- Step 5: Explain the effect – the irony exposes the hypocrisy of power, making the critique sharper than direct statement.
- Step 6: Connect to theme – reinforces the theme that institutional power often perpetuates injustice.
REASONING: By breaking down the situation into expectation vs reality, we isolate the ironic gap. Linking to theme shows why the poet chose irony over direct condemnation.
ANSWER: The king's punishment of Mahadevi Varma for demanding justice is situational irony because the outcome (punishment) contradicts the expected result (reward/justice). This irony underscores the poem's central critique: those in power often subvert the very ideals they claim to uphold, making the injustice more glaring.

## WORKED_EXAMPLE_2
PROBLEM: In the second poem, the speaker asks the lamp to keep burning despite storms. Identify the symbol, its literal and symbolic meanings, and explain how the symbol develops the theme of resilience.
STEPS:
- Step 1: Locate the symbol – the lamp (bZ'oj) is the central image in the second poem.
- Step 2: State literal meaning – a small oil lamp that provides light in a house.
- Step 3: Identify symbolic associations – light = hope, knowledge, dignity; storm = oppression, adversity; keeping it lit = perseverance.
- Step 4: Trace the symbol's development – the speaker protects the lamp, asks it not to go out, even imagines carrying it through darkness.
- Step 5: Link to the speaker's situation – the woman (Mahadevi Varma) faces societal storms but refuses to let her inner light (voice, dignity) be extinguished.
- Step 6: Conclude thematic significance – the lamp transforms personal resilience into a universal symbol of marginalized resistance.
REASONING: Symbolism works through sustained association; tracking the lamp across the poem shows how the poet builds meaning. Connecting to the speaker's biography grounds the symbol in lived experience.
ANSWER: The lamp symbolizes the poet's indomitable spirit and hope. Literally a source of light, it becomes a metaphor for her refusal to surrender her dignity despite patriarchal oppression. The repeated plea 'vks pjkpj! er pwd volj' (O lamp, keep burning) turns the object into an emblem of quiet, persistent resistance.

## WORKED_EXAMPLE_3
PROBLEM: Compare how irony and symbolism function together across both poems to portray the dual reality of oppression and resistance. Use specific textual references.
STEPS:
- Step 1: Recall the core irony of Poem 1 – power masquerading as justice.
- Step 2: Recall the core symbol of Poem 2 – the lamp as resilient hope.
- Step 3: Identify the common antagonist – systemic injustice (king/patriarchy/storms).
- Step 4: Analyze the relationship – irony exposes the oppressor's falsehood; symbolism embodies the oppressed's truth.
- Step 5: Note the structural placement – first poem shows the external reality (irony of power), second poem reveals internal response (symbol of resistance).
- Step 6: Synthesize – the two devices are complementary: irony diagnoses the disease, symbolism prescribes the cure.
REASONING: This multi-step comparison requires holding both poems in mind and seeing how the poet uses different devices for different but connected purposes. It mirrors board exam questions that ask for 'inter-poem analysis'.
ANSWER: In the first poem, situational irony lays bare the king's tyranny disguised as justice, diagnosing the corruption of power. In the second, the lamp symbolizes the woman's unquenchable dignity, prescribing resilience. Together, they present a complete picture: irony reveals the external injustice, while symbolism affirms the internal strength that resists it.

## COMPETENCY_QUESTION_1
QUESTION: The first poem uses the phrase 'fu;a=k.k' (justice) to describe the king's punishment of the poet. Explain how this word choice creates verbal irony and what it reveals about the poet's attitude toward authority.
COMPETENCY: Literary analysis – identifying verbal irony and interpreting authorial stance.
STEPS:
- Step 1: Define verbal irony – saying one thing but meaning the opposite.
- Step 2: Locate the word 'fu;a=k.k' in context – the king calls his act justice.
- Step 3: Explain the gap – the act is unjust, so the label is ironic.
- Step 4: Infer the poet's attitude – she rejects the king's definition, exposing his misuse of language to legitimize tyranny.
- Step 5: Write a concise answer quoting the word and explaining its ironic force.
ANSWER: The word 'fu;a=k.k' (justice) is verbally ironic because the king uses it to label an act that is fundamentally unjust – punishing a woman for demanding fairness. The poet employs this irony to strip away the legitimacy of authority, showing that those in power manipulate language to disguise oppression. Her attitude is one of defiant exposure: she refuses to accept the king's version of reality.
DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: In the second poem, the speaker says: 'viuk ?kj ls D;k rkRi;Z gS' (What is the connection with your house?) and later insists on keeping the lamp lit. Analyze how the 'house' and the 'lamp' function as interlinked symbols of identity and resistance. Support with textual evidence.
COMPETENCY: Symbolic analysis – interpreting interlinked symbols and their thematic contribution.
STEPS:
- Step 1: Identify the two symbols – house (?kj) and lamp (bZ'oj).
- Step 2: Explain the house as symbol – represents the self, dignity, personal space, identity.
- Step 3: Explain the lamp as symbol – represents the inner light, hope, consciousness that inhabits the house.
- Step 4: Show their linkage – the lamp is inside the house; protecting the lamp is protecting the self.
- Step 5: Connect to the speaker's challenge – external forces (storm, power) threaten both; the speaker's refusal to let the lamp go out is an assertion of identity.
- Step 6: Conclude with thematic significance – the symbols together portray resistance as an act of self-preservation.
ANSWER: The 'house' symbolizes the poet's identity and autonomous space, while the 'lamp' symbolizes the living spirit within that space. The rhetorical question 'viuk ?kj ls D;k rkRi;Z gS' challenges the intruder's claim over her selfhood. The plea 'vks pjkpj! er pwd volj' (O lamp, keep burning) transforms the lamp into an emblem of her refusal to let her inner truth be extinguished. Together, they form a unified symbolic architecture: the house is the fortress of self, the lamp its undying sentinel. This interlinking elevates personal resistance to a universal metaphor for marginalized dignity.
DIFFICULTY: hard