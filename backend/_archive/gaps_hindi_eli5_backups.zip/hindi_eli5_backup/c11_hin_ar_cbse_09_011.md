## DEFINITION
Language usage in the text refers to the systematic analysis of grammatical forms, syntactic structures, lexical choices, and stylistic features employed in a literary work—here, Dhabji's Braj Bhasha poem and the modern Hindi prose introduction—to reveal how linguistic patterns encode meaning, tone, and historical context.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student can independently identify three distinct Braj Bhasha grammatical features (verb morphology, case markers, particles) in the poem, map each to its modern Hindi equivalent using the gloss, and explain how these features create the poem's gnomic, oral quality versus the prose's expository clarity.

## SCOPE_BOUNDARY
This node covers grammatical and stylistic analysis of the specific poem by Dhabji (Braj Bhasha) and the accompanying Hindi prose in NCERT Class 11 Aroh Chapter 9. It does not cover a comprehensive history of Braj Bhasha, general Hindi grammar rules unrelated to the text, or other chapters' language usage.

## WALKTHROUGH
Imagine you hear an old folk song in a dialect you partly understand—some words feel familiar, but the verb endings and sentence connectors sound different. That is exactly the experience of reading Dhabji's poem. Begin by reading the Braj lines aloud alongside the Hindi gloss; notice which words shift predictably (like *nkstx* → *nirdesh*) and which change completely (like *tkauka* → *hote hain*). Next, hunt for patterns: circle every verb ending, underline every postposition, and highlight particles like *gh* and *vfxfu*. Finally, ask: "Why did the poet choose *this* form instead of the modern one?"—the answer unlocks the poem's timeless, proverbial force.

## DIAGNOSTIC_QUESTION_1
What is the modern Hindi equivalent of the Braj Bhasha word **'nkstx'** as given in the *kCn&Nfo* (gloss) at the end of the poem?

## DIAGNOSTIC_ANSWER_1
The gloss explicitly states: **nkstx (iQk- nks”k[k) → ujd** (निर्देश). A wrong answer such as *nishchay* (निश्चय) reveals the student either did not consult the provided gloss or confused the phonetic shape with a similar-sounding tatsama word, showing a reliance on guesswork over textual evidence.

## DIAGNOSTIC_QUESTION_2
In the line **'ge rkS ,d ,d dfj tkaukaA'**, the verb **'tkauka'** ends in **'-auka'**. Explain what grammatical category this suffix marks in Braj Bhasha and how it differs from the modern Hindi equivalent.

## DIAGNOSTIC_ANSWER_2
The suffix **'-auka'** marks the **habitual present / general truth** (equivalent to modern Hindi **'-te hain'** or **'-ta hai'**). A response calling it "past tense" or "future tense" shows the student is imposing Hindi verb paradigms (*-tha*, *-ega*) onto Braj morphology instead of recognising the distinct *-auka* habitual paradigm that gives the poem its universal, proverbial tone.

## DIAGNOSTIC_QUESTION_3
Rewrite the Braj phrase **'lc ?kfV varfj rw¡gh O;kid /jS l:iS lksbZAA'** in modern standard Hindi, correctly mapping each case marker (*karak chinha*) and the verb.

## DIAGNOSTIC_ANSWER_3
**Step-by-step mapping:**  
1. *lc* → **लेकिन** (conjunction, not a case marker).  
2. *rw¡gh* (genitive) → **का** (*O;kid rw¡gh* → *किसी का*).  
3. */jS* (locative) → **में** (*l:iS /jS* → *स्थिर में* → *स्थिर रहती है* contextually).  
4. *lksbZ* (verb *rahnā* habitual) → **रहती है**।  
**Modern Hindi:** "लेकिन क्षण भर किसी के हाथ में स्थिर नहीं रहती।"  
An answer that translates *rw¡gh* as *से* or */jS* as *को* reveals confusion between Braj and Hindi postposition systems.

## DIAGNOSTIC_QUESTION_4
Compare the density and function of **alliteration (anupraas)** in the first two lines of the poem (*ge rkS ,d ,d dfj tkaukaA / nksb dgSa frugha dkSa nkstx ftu ukfgau ifgpkauka*) with its occurrence in the prose sentence **'lk[kh] lcn ,oa jeSuh ladfyr gSa'**. Why does the poet pack more alliteration into the verse?

## DIAGNOSTIC_ANSWER_4
The poem uses **dense, consecutive alliteration** (*ge rkS*, *dgSa frugha*, *nkstx ftu*, *ukfgau ifgpkauka*) to create **musicality, memorability, and oral rhythm**—essential for a folk poem meant to be sung. The prose uses **sparse, isolated alliteration** (*lk[kh] lcn jeSuh*) only for **rhetorical polish** in a written, explanatory context. Missing this contrast indicates the student cannot distinguish poetic vs. prosaic linguistic registers.

## DIAGNOSTIC_QUESTION_5
The gloss translates **'ck<+h dk"V gh dkVS vfxfu u dkVS dksbZA'** as **'टेढ़ी टांग ही टेढ़ी नहीं तो टेढ़ी किसी की नहीं।'** Critique whether this translation fully captures the grammatical force of the particles **'gh'** and **'vfxfu'**.

## DIAGNOSTIC_ANSWER_5
The translation correctly renders *gh* as **'ही'** (exclusive focus) and *vfxfu* as **'नहीं'** (negation), but it **loses the elliptical parallelism** of the original where the copula *hai* is omitted in both clauses. A poor critique would say "it's accurate" without noting that Braj's zero-copula gnomic structure makes the statement more aphoristic and absolute than the Hindi translation, which feels slightly more discursive.

## DIAGNOSTIC_QUESTION_6
Compose **two original lines in Braj Bhasha style** that express a philosophical idea about impermanence. You must use: (a) the habitual suffix **'-auka'**, (b) the genitive marker **'rw¡gh'** (or *osQ*), and (c) at least one tadbhava word from the poem's gloss (e.g., *lekauka*, *dksagjk*).

## DIAGNOSTIC_ANSWER_6
**Sample answer:**  
*jg mY~ sab nashvar ghatauka, kaun rahai sada thirauka |*  
*karam kI gat nyari nirakhai, sabhI ko apano karauka ||*  
**Criteria for a good answer:**  
- Uses *-auka* correctly on verbs (*ghatauka*, *thirauka*, *karauka*).  
- Uses *rw¡gh* or *osQ* for genitive (*karam kI gat* → *karam rw¡gh gat* acceptable).  
- Includes tadbhava vocabulary (*ghatauka* from *ghaṭnā*, *thirauka* from *sthira*).  
A poor answer uses modern Hindi forms (*hote hain*, *ka*, *nirdesh*) showing failure to internalise Braj patterns.

## COMMON_MISCONCEPTION
Students treat Braj Bhasha as merely "old Hindi" and mechanically replace every unfamiliar ending with a modern Hindi one (e.g., reading *-auka* as *-aya* past tense). They miss that Braj has **systematic, rule-governed differences**: a distinct habitual paradigm (*-auka*), conserved Apabhramsa postpositions (*rw¡gh* for *kā*, */jS* for *mẽ*), and frequent **zero copula** in gnomic statements. This leads to mistranslating timeless truths as past narratives.

## ON_FAILURE
1. **Build a 5-row comparison table** with columns: *Braj Form | Gloss | Modern Hindi | Grammatical Category | Function in Poem*. Fill it together for *tkauka, dgSa, rw¡gh, gh, vfxfu*.  
2. **Guided translation:** Have the student translate stanza 1 line-by-line, labeling every verb, case marker, and particle using the table.  
3. **Mini-lecture (2 min):** Explain that *-auka* = *-tā hai* (habitual), *rw¡gh* = *kā*, zero copula = proverbial force.  
4. **Exit ticket:** Student writes one Braj-style sentence using *-auka* and *rw¡gh* to prove internalisation.

## BUILDS_ON
c11_hin_ar_cbse_09_010 (Vocabulary in Context: Key Words) – the gloss decoded there is the essential key for every grammatical analysis here.

## LEADS_TO
c11_hin_ar_cbse_09_012 (Comprehension: Literal and Inferential Questions) – precise grammatical decoding enables accurate literal comprehension, which is the foundation for inference.

## PREREQUISITE_NODE_IDS
c11_hin_ar_cbse_09_010
## PREREQUISITE_REASONS
c11_hin_ar_cbse_09_010: The *kCn&Nfo* (word-meaning) section provides the lexical bridge without which Braj grammatical forms cannot be reliably identified or mapped to Hindi.

## FORWARD_NODE_IDS
c11_hin_ar_cbse_09_012, c11_hin_ar_cbse_09_013, c12_hin_a_cbse_04_011, c12_hin_a_cbse_09_011, c12_hin_a_cbse_11_011, c12_hin_a_cbse_12_011, c12_hin_a_cbse_17_011, c12_hin_ar_cbse_01_011, c12_hin_ar_cbse_02_011, c12_hin_ar_cbse_07_011, c12_hin_ar_cbse_09_011, c12_hin_ar_cbse_10_011, c12_hin_ar_cbse_11_011

## FORWARD_REASONS
c11_hin_ar_cbse_09_012: Grammatical accuracy in decoding verb tense, case, and particles is prerequisite for correct literal comprehension of the poem.  
c11_hin_ar_cbse_09_013: Language-usage evidence (e.g., habitual aspect, zero copula) directly supports critical claims about tone, theme, and oral tradition.
c12_hin_a_cbse_04_011: अगला तार्किक चरण: This node analyzes the grammatical structures, syntactic patterns, and language usage specific to th... इस नोड की अवधारणाओं को सीधे उपयोग/विस्तारित करता है।  
c12_hin_a_cbse_09_011: Introduced *alankar* identification — *vyajokti* here is grammar-rhetoric interface needing both skills.  
c12_hin_a_cbse_11_011: Covers dialectal features in literary Hindi (Braj, Awadhi) — identifies "mYykl", "dy", "mYN".  
c12_hin_a_cbse_12_011: Vocabulary inference strategies using context clues  
c12_hin_a_cbse_17_011: Distinguished synonyms via morphological analysis — key for आँगन variants.  
c12_hin_ar_cbse_01_011: Develops glossing/annotation skills for poetic grammar.  
c12_hin_ar_cbse_02_011: Preparation for board-level analysis.  
c12_hin_ar_cbse_07_011: Further Braj pronoun case studies.  
c12_hin_ar_cbse_09_011: Direct precursor — same skill set applied to Class 11 Chapter 9 poems.  
c12_hin_ar_cbse_10_011: Archaic forms in poetry/prose (Chapter 9).  
c12_hin_ar_cbse_11_011: Enhances locative phrase semantic role understanding  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
none

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_09_010 -> c11_hin_ar_cbse_09_011 -> c11_hin_ar_cbse_09_012

## THIS_FORMULA
N/A - conceptual

## FORMULA_VARIABLES
N/A

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
linguistic

## CROSS_SUBJECT
c11_history_medieval_india | The poem's Braj Bhasha reflects the Bhakti movement's deliberate choice of vernacular over Sanskrit, linking linguistic form to religious democratisation in medieval North India.  
c11_sociology_indian_society | The diglossia between Braj (folk/poetic) and Khari Boli (modern standard) in the same textbook illustrates language standardisation, prestige hierarchies, and the marginalisation of regional dialects.

## PREREQ_CONCEPT
Ability to use a bilingual glossary to map archaic lexical items to modern equivalents and recognise basic Hindi grammatical terminology (*kriya, karak, visheshan, avyaya*).

## PREREQ_BEFORE
Student must have completed the vocabulary node (c11_hin_ar_cbse_09_010) and be comfortable with terms like *kriya-rup*, *karak-chinha*, and *tadbhava/tatsama*.

## PREREQ_STUCK
Review the *kCn&Nfo* box at the end of the NCERT poem text and the basic Hindi grammar chapter on *kriya* and *karak* from Class 9-10.

## WORKED_EXAMPLE_1
PROBLEM: Analyse the verb forms in the first stanza: **'ge rkS ,d ,d dfj tkaukaA / nksb dgSa frugha dkSa nkstx ftu ukfgau ifgpkauka AA'**

STEPS:
- Step 1: List every verb form: *tkauka, dgSa, ukfgau, ifgpkauka*.
- Step 2: Use the gloss to identify roots: *tkauka* → *tuknā* (होना), *dgSa* → *kahnā* (कहना), *ukfgau* → *uṛnā* (उड़ना), *ifgpkauka* → *phailnā* (फैलना).
- Step 3: Isolate suffixes: *-auka* (on *tk-* and *ifgp-*), *-a* (on *dgS-*), *-au* (on *ukfg-*).
- Step 4: Map to Braj grammar: *-auka* = habitual present/future (general truth); *-a* = 3rd person plural present; *-au* = subjunctive/optative (here 'may fly/spread').
- Step 5: Contrast with modern Hindi: *hote hain, kehte hain, uḍeṁ, phailẽ*. Note the poem's gnomic timelessness vs. Hindi's explicit person/number marking.
REASONING: Moving from form → root → suffix → category → modern equivalent → stylistic effect trains the student to see grammar as a meaning-making system, not a labelling exercise.
ANSWER: The stanza uses three distinct Braj verb endings: habitual *-auka* (universal truths), plural present *-a* (reporting speech), and subjunctive *-au* (wish/possibility). Together they create a layered statement: "We *are* beads on one string (eternal fact); people *say* the thread is invisible (reported belief); may the thread *not snap* and *spread* (prayer)."

## WORKED_EXAMPLE_2
PROBLEM: Identify all case markers (*karak chinha*) in **'lc ?kfV varfj rw¡gh O;kid /jS l:iS lksbZAA'** and explain their syntactic roles.

STEPS:
- Step 1: Segment the string: *lc | ?kfV | varfj | rw¡gh | O;kid | /jS | l:iS | lksbZ*.
- Step 2: Tag each word using gloss & context: *lc* (conjunction 'but'), *?kfV* (noun 'moment'), *varfj* (adjective 'heavy/dense' → here 'brief'), *rw¡gh* (postposition), *O;kid* (pronoun 'anyone'), */jS* (postposition), *l:iS* (adverb 'steady'), *lksbZ* (verb 'stays').
- Step 3: Confirm case markers: *rw¡gh* = genitive (*kā*), */jS* = locative (*mẽ*). *lc* is not a case marker.
- Step 4: Map to Hindi: *O;kid rw¡gh* → *किसी का*; *l:iS /jS* → *स्थिर में* (idiomatically *स्थिर रहती है* → *remains steady in* → *हाथ में स्थिर रहती है*).
- Step 5: Note phonological shift: Apabhraṃśa *kera* → Braj *rw¡gh* → Khari Boli *kā*; Apabhraṃśa *majjha* → Braj */jS* → Khari Boli *mẽ*.
REASONING: This demonstrates that case markers are the most conservative layer—phonology changes, but syntactic slots remain stable, allowing reliable cross-mapping.
ANSWER: Two true case markers: **rw¡gh** (genitive, 'का') marking possessor *O;kid*, and **/jS** (locative, 'में') marking location *l:iS*. The verb *lksbZ* (habitual 'रहती है') agrees with the implied feminine subject *tang* from previous line.

## WORKED_EXAMPLE_3
PROBLEM: The line **'ck<+h dk"V gh dkVS vfxfu u dkVS dksbZA'** uses particles *gh* and *vfxfu* in a correlative structure. Analyse the syntax and rewrite in modern Hindi preserving the logical emphasis.

STEPS:
- Step 1: Parse words via gloss: *ck<+h* (टेढ़ी), *dk"V* (टांग), *gh* (ही), *dkVS* (टेढ़ी), *vfxfu* (नहीं), *u* (तो), *dkVS* (टेढ़ी), *dksbZ* (किसी की).
- Step 2: Identify structure: [Subject *ck<+h dk"V*] [Focus *gh*] [Predicate *dkVS*] [Neg *vfxfu*] [Correlative *u*] [Predicate *dkVS*] [Genitive *dksbZ*].
- Step 3: Determine ellipsis: Zero copula in both clauses (gnomic present).
- Step 4: Modern Hindi reconstruction with explicit copula and focus marking: **'टेढ़ी टांग *ही* टेढ़ी नहीं है, तो *किसी की* टेढ़ी नहीं है।'**
- Step 5: Explain pragmatic force: *gh* restricts the negation to *this* leg; *u…dksbZ* generalises—if even the obvious case fails, no case holds. Braj's compactness sharpens the logic.
REASONING: Combining syntax (correlative), morphology (zero copula), and pragmatics (focus particle) shows how grammar encodes the poem's philosophical argument.
ANSWER: The line is a correlative conditional with double ellipsis of *hai*. *gh* = exclusive focus ('only this leg'), *vfxfu* = predicate negation, *u* = 'then'. Modern Hindi requires *hai* and often repeats *tedi* for clarity, diluting the aphoristic punch.

## COMPETENCY_QUESTION_1
QUESTION: A student translates *tkauka* in the first line as **'थे'** (past tense). Identify the exact morphological misunderstanding and correct it using internal textual evidence.

COMPETENCY: Morphological analysis and error diagnosis
STEPS:
- Step 1: Isolate the form *tkauka* and its suffix *-auka*.
- Step 2: Recall that Braj *-auka* is a habitual present/future marker (cf. *ifgpkauka* same suffix two lines later).
- Step 3: Check context: *ge rkS* (we are) + *tkauka* describes a permanent metaphysical state, not a past event.
- Step 4: Conclude the student confused *-auka* with Hindi *-the* due to vague phonetic similarity.
ANSWER: The error is misidentifying the Braj habitual suffix *-auka* (≈ *होते हैं*) as past tense. Internal evidence: *ifgpkauka* (same suffix) clearly cannot be past in a blessing/prayer. Correct translation: 'होते हैं' (are/become).
DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: Compare the poem (Braj) and the prose introduction (modern Hindi) on **three linguistic parameters**: (a) verb morphology, (b) case markers, (c) lexical register. Give one concrete example from each text for each parameter and explain how the differences serve the distinct communicative purposes.

COMPETENCY: Comparative register analysis
STEPS:
- Step 1: Poem verb: *tkauka* (-*auka* synthetic habitual). Prose verb: *dgykrh gS* (analytic *raha hai* progressive/habitual).
- Step 2: Poem case: *rw¡gh* (Braj genitive). Prose case: *osQ* (Khari Boli genitive).
- Step 3: Poem lexis: *nkstx* (tadbhava/desya 'निर्देश'). Prose lexis: *eqDrkoLFkk* (tatsama 'प्रतिष्ठा').
- Step 4: Functional explanation: Poem's synthetic verbs, conserved postpositions, and tadbhava lexicon create **oral, mnemonic, accessible folk discourse**. Prose's analytic verbs, standardised postpositions, and tatsama lexicon create **precise, authoritative, academic exposition**.
- Step 5: Synthesise: Language variation mirrors genre variation—oral poetry vs. written literary history.
ANSWER: (a) Verb: poem *tkauka* (synthetic habitual) vs prose *dgykrh gS* (analytic). (b) Case: poem *rw¡gh* vs prose *osQ*. (c) Lexis: poem *nkstx* (desya) vs prose *eqDrkoLFkk* (tatsama). The poem's forms aid memorability and emotional resonance; the prose's forms ensure clarity and scholarly credibility.
DIFFICULTY: hard