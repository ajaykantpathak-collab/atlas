## DEFINITION
Secondary themes are the underlying, supporting ideas in a literary work that complement and enrich the primary theme by exploring specific dimensions of human experience, social reality, or emotional truth through recurring motifs, imagery, and narrative details.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student must be able to identify at least three distinct secondary themes in "lcls [krjukd" with textual evidence, explain how each secondary theme connects to the primary theme of existential insignificance, and articulate how the poet uses negation and concrete imagery to develop these themes.

## SCOPE_BOUNDARY
This node covers identification and analysis of secondary themes in Viren Dangwal's poem "lcls [krjukd" including alienation, mechanization of life, mortality, and loss of human connection. It does NOT cover primary theme analysis (node 006), literary devices (nodes 008-009), or vocabulary (node 010).

## WALKTHROUGH
Imagine you're watching a crowded metro station at 8 PM - thousands of people moving like clockwork, but each carrying a private sorrow no one else sees. That's exactly what this poem captures. Start by re-reading the poem and marking every concrete image the poet calls "smallest" - the door, window, staircase, road, evening, night, darkness. Notice the pattern: each is a transitional space where human feeling enters but doesn't stay. The key insight is that the poet uses negation (what is NOT smallest) to define what IS smallest - a technique called definition by exclusion that reveals how modern life reduces profound human experiences to mere functional passages.

## DIAGNOSTIC_QUESTION_1
What is the definition of a secondary theme in literature, and how does it differ from the primary theme in terms of scope and function within a text?

## DIAGNOSTIC_ANSWER_1
A secondary theme is a supporting idea that explores specific aspects of the primary theme through particular motifs, characters, or situations, while the primary theme is the central, unifying idea that encompasses the entire work. A wrong answer that equates secondary themes with subplots or minor topics reveals the student confuses structural elements with thematic layers - secondary themes are interpretive lenses, not narrative components.

## DIAGNOSTIC_QUESTION_2
In "lcls [krjukd", the poet repeatedly uses the phrase "lcls [krjukd ugha gksrh" (is not the smallest) for grand concepts like love's memory and national borders. Explain why this strategy of negation is essential for establishing the poem's secondary theme of alienation in modern urban life.

## DIAGNOSTIC_ANSWER_2
The negation strategy works by first invoking what society considers profound (love, motherhood, nationhood) and then dismissing them as "not smallest," forcing the reader to confront the gap between cultural ideals and lived reality where these grand emotions fail to sustain daily existence. A wrong answer that sees this as mere contrast misses how negation performs the poem's central argument: that alienation isn't the absence of big emotions but the failure of those emotions to translate into daily sustenance.

## DIAGNOSTIC_QUESTION_3
Apply the concept of "definition by exclusion" to analyze how the image "eqnkZ 'kkafr ls Hkj tkuk / u gksuk rM+i dk lc lgu dj tkuk" (returning home empty-hearted / not getting the taste of dry bread) functions as a concrete instantiation of the secondary theme of emotional starvation amidst material routine.

## DIAGNOSTIC_ANSWER_3
The image works through exclusion by presenting the barest material act (eating dry bread after work) stripped of its emotional nourishment (empty-hearted), making the absence palpable through what should accompany it but doesn't. A wrong answer that only paraphrases the literal meaning misses how the poem uses sensory deprivation (taste, fullness) as evidence for the secondary theme - the worker's body performs the routine but the self has already checked out.

## DIAGNOSTIC_QUESTION_4
Compare the secondary theme of mechanization in "lcls [krjukd" with the portrayal of industrial labor in Munshi Premchand's "Kafan" (from Class 10). How do both texts use the body as a site where systemic dehumanization becomes visible?

## DIAGNOSTIC_ANSWER_4
Both texts make the body the archive of exploitation: Premchand shows Budhia's body consumed by hunger and cold while Ghisu and Madhav calculate shroud costs, while Dangwal shows the worker's body performing "dke ls ykSVdj ?kj vkuk" (returning home after work) as a mechanical loop where "gekjs liuksa dk ej tkuk" (our shadows' sleep leaving) suggests the soul has already departed. A wrong answer that treats these as merely "both about poverty" misses the specific literary strategy: both use bodily routines (eating, sleeping, working) as evidence that the system has hollowed out the human from inside.

## DIAGNOSTIC_QUESTION_5
Evaluate the claim: "The secondary theme of mortality in 'lcls [krjukd' is not about death as an event but about death as a daily condition." Support your evaluation with at least two specific images from the poem.

## DIAGNOSTIC_ANSWER_5
The claim is accurate. The poem presents mortality as embedded in routine: "og pk¡n gksrk gS / tks gj gR;kdkaM osQ ckn / ohjku gq, vk¡xuksa esa p<+rk gS" (the smallest is the leaf / that after the festival / gets trapped in withered branches) shows death as post-celebration residue, and "tks xaqMs dh rjg vdM+rk gS" (that freezes like glass) captures the suspended animation of the sleepless. A wrong answer that cites only the crematorium road ("lcls [krjukd og xhr gksrk gS / vkiosQ dkuksa rd igq¡pus osQ fy,") treats mortality as destination rather than condition, missing how the poem distributes death across everyday objects.

## DIAGNOSTIC_QUESTION_6
Create a four-line free verse poem that uses the "definition by exclusion" technique (listing what something is NOT before revealing what it IS) to explore a secondary theme from your own urban experience - for example, the smallest loneliness, the smallest freedom, or the smallest home.

## DIAGNOSTIC_ANSWER_6
A strong response will mirror the poem's structure: 2-3 negations of grand concepts followed by 2-3 concrete, sensory images of the mundane reality, maintaining the rhythm of "X is not smallest / Y is not smallest / Z is smallest because [specific bodily/emotional detail]." A weak response that merely lists sad things without the exclusion structure or without grounding in sensory detail reveals the student hasn't internalized the poem's central rhetorical strategy as a thematic tool.

## COMMON_MISCONCEPTION
Students commonly believe secondary themes are simply "less important themes" or "sub-themes" that can be listed like topics (loneliness, death, city life). The senior secondary error is treating themes as static labels rather than dynamic arguments the text makes through specific formal choices. For example, a student writes "alienation is a secondary theme" but cannot explain how the poem's negation structure, its progression from public to private spaces, and its use of domestic objects as witnesses collectively construct that argument. This misconception arises because Class 10 taught theme identification as labeling; Class 11 requires theme analysis as tracing an argument through textual evidence.

## ON_FAILURE
If a student cannot move beyond labeling, guide them through this sequence: (1) Pick ONE image from the poem (e.g., the window "tks ph'kksa ls mBrh vaèksiu dh Hkki ij <qyd tkrh gS"). (2) Ask: "What does this window SEE? What does it HEAR? What does it FAIL to hold?" (3) Connect each answer to a specific line. (4) Ask: "So what argument about urban life is the window making?" (5) Generalize: "This is how the theme of alienation is BUILT, not just stated." Repeat with two more images until the student sees themes as architectural, not decorative.

## BUILDS_ON
This node builds on the primary theme analysis (node 006) which established the central argument about existential insignificance, and character analysis nodes (004-005) which examined how the poetic persona embodies this insignificance.

## LEADS_TO
This node enables literary devices analysis (nodes 008-009) where students will examine how imagery, irony, and symbolism formally enact the secondary themes, and critical thinking (node 013) where they synthesize themes and devices into interpretive arguments.

## PREREQUISITE_NODE_IDS
c11_hin_ar_cbse_15_001, c11_hin_ar_cbse_15_002, c11_hin_ar_cbse_15_003, c11_hin_ar_cbse_15_004, c11_hin_ar_cbse_15_005, c11_hin_ar_cbse_15_006
## PREREQUISITE_REASONS
c11_hin_ar_cbse_15_001: Context about Viren Dangwal's political poetry and the 1988 background is essential for reading secondary themes as social commentary.
c11_hin_ar_cbse_15_002: Narrative structure shows the poem's movement from public negation to private affirmation, which structures thematic development.
c11_hin_ar_cbse_15_003: Setting analysis of urban transitional spaces (door, window, staircase, road) provides the physical loci where secondary themes manifest.
c11_hin_ar_cbse_15_004: The poetic persona as the exhausted worker is the lens through which all secondary themes are filtered.
c11_hin_ar_cbse_15_005: Supporting characters (the sleeping city, the festival crowd, the crematorium-bound) represent the collective dimensions of secondary themes.
c11_hin_ar_cbse_15_006: Primary theme of "smallest as most crushing" is the umbrella under which all secondary themes operate.

## FORWARD_NODE_IDS
c11_hin_ar_cbse_15_008, c11_hin_ar_cbse_15_009, c11_hin_ar_cbse_15_013, c11_hin_ar_cbse_15_014, c11_hin_ar_cbse_15_015, c12_hin_a_cbse_01_007, c12_hin_a_cbse_08_007, c12_hin_a_cbse_10_007, c12_hin_a_cbse_15_007, c12_hin_ar_cbse_15_007

## FORWARD_REASONS
c11_hin_ar_cbse_15_008: Imagery and metaphor analysis requires identified themes to explain what the devices are DOING thematically.
c11_hin_ar_cbse_15_009: Irony and symbolism analysis depends on understanding the gap between negated ideals and affirmed realities that secondary themes expose.
c11_hin_ar_cbse_15_013: Critical thinking synthesis needs thematic inventory as raw material for interpretive arguments.
c11_hin_ar_cbse_15_014: Writing skills tasks (analytical paragraphs, theme essays) require thematic evidence banks built in this node.
c11_hin_ar_cbse_15_015: Secondary themes offer multiple angles for discussion.  
c12_hin_a_cbse_01_007: Chapter 15 discussed themes in oral presentations.  
c12_hin_a_cbse_08_007: अगला तार्किक चरण: Secondary themes are the underlying, complementary ideas in a literary work that support, contrast w... इस नोड की अवधारणाओं को सीधे उपयोग/विस्तारित करता है।  
c12_hin_a_cbse_10_007: Practice with competency-based thematic questions.  
c12_hin_a_cbse_15_007: Class 11 practice with secondary themes in "अपू के साथ ढाई साल" builds the analytical vocabulary.  
c12_hin_ar_cbse_15_007: Class 11 introduced secondary theme identification in simpler texts; this builds to argumentative prose complexity.  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
No prior class nodes available for cross-subject connections.

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_15_006 -> c11_hin_ar_cbse_15_007 -> c11_hin_ar_cbse_15_008: Primary theme establishes the central argument, secondary themes unpack its dimensions through concrete imagery, literary devices analyze how form enacts these thematic arguments.

## THIS_FORMULA
N/A - conceptual

## FORMULA_VARIABLES
N/A

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
conceptual

## CROSS_SUBJECT
c11_sociology_social_change | The poem's depiction of alienation, mechanized routine, and erosion of kinship bonds directly illustrates sociological concepts of anomie, alienation in industrial society, and the transformation of primary groups into secondary associations.
c11_psychology_human_development | The imagery of emotional starvation ("eqnkZ 'kkafr ls Hkj tkuk"), sleep disturbance ("vkrafdr yksxksa osQ njok"kksa ij / tks xaqMs dh rjg vdM+rk gS"), and identity loss connects to psychological concepts of burnout, existential anxiety, and the impact of chronic stress on self-concept.

## PREREQ_CONCEPT
Understanding of primary theme as the central unifying argument of a text, and ability to distinguish between thematic topics (labels) and thematic statements (arguments the text makes).

## PREREQ_BEFORE
Student must have completed analysis of the poem's primary theme (node 006) and understand the negation structure ("lcls [krjukd ugha gksrh" repeated for grand concepts vs. "lcls [krjukd gksrk gS" for mundane realities).

## PREREQ_STUCK
Review the primary theme analysis (node 006) focusing on how the poet defines "smallest" through exclusion, and re-read the poem marking every concrete noun that follows "lcls [krjukd gksrk gS".

## WORKED_EXAMPLE_1
PROBLEM: Analyze how the secondary theme of "the commodification of human relationships" is developed through the progression of domestic spaces in the poem (door → window → staircase → road).

STEPS:
- Step 1: Identify the four domestic spaces in sequence: door ("diV osQ 'kksj esa / lgh gksrs gq, Hkh nc tkuk"), window ("fdlh tqxuw dh ykS esa i<+uk"), staircase ("eqf_;k¡ Hkhapdj cl oDr fudky ysuk"), road ("lcls [krjukd og xhr gksrk gS / vkiosQ dkuksa rd igq¡pus osQ fy,").
- Step 2: Note the progression from intimate threshold (door) to public thoroughfare (road) - each space mediates between private self and public world.
- Step 3: Analyze what each space FAILS to do: door doesn't hold the shadow ("vkidh vk¡[kksa dks fepks± dh rjg ugha xM+rk gS"), window's voice is stolen by wind ("tks ph'kksa ls mBrh vaèksiu dh Hkki ij <qyd tkrh gS"), staircase melts cries ("tks jks"kejkZ osQ Øe dks ihrh gqbZ"), road leads only to crematorium.
- Step 4: Connect each failure to commodification: the door should welcome but only measures exit/entry; the window should communicate but transmits only noise; the staircase should support ascent but absorbs grief; the road should connect but terminates in disposal.
- Step 5: Synthesize: The progression shows how urban architecture converts relational spaces into functional conduits - each domestic threshold becomes a transaction point where human feeling is processed and discarded.
- Step 6: Link to primary theme: This commodification IS what makes these spaces "smallest" - they are the minimal units where the system's reduction of humans to functions becomes visible.

REASONING: The poem uses spatial progression as a thematic argument: by moving from the most intimate threshold (door) to the most public (road), it shows commodification operating at every scale of domestic life. Each space's failure is not accidental but structural - the architecture itself enacts the secondary theme.

ANSWER: The secondary theme of commodification of relationships is developed through a spatial argument: four domestic thresholds (door, window, staircase, road) each fail their relational function (holding, communicating, supporting, connecting) and instead perform systemic functions (measuring transit, transmitting noise, absorbing grief, disposing bodies). This progression from intimate to public demonstrates that commodification is totalizing - no domestic space escapes conversion into a functional conduit. The poem thus argues that alienation isn't an external force but built into the very architecture of daily life.

## WORKED_EXAMPLE_2
PROBLEM: Explain how the secondary theme of "festival as ideological masking" operates through the contrast between "gj gR;kdkaM" (the festival) and "ohjku gq, vk¡xuksa" (withered branches) in the lines "og pk¡n gksrk gS / tks gj gR;kdkaM osQ ckn / ohjku gq, vk¡xuksa esa p<+rk gS".

STEPS:
- Step 1: Identify the two key terms in opposition: "gj gR;kdkaM" (festival/celebration) and "ohjku gq, vk¡xuksa" (withered branches).
- Step 2: Analyze the temporal marker "ckn" (after) - the festival is positioned as BEFORE, the withered branches as AFTER, making the festival a temporary suspension.
- Step 3: Examine the verb "p<+rk gS" (gets trapped/entangled) - the leaf doesn't fall naturally but is caught, suggesting the festival creates conditions for entrapment.
- Step 4: Connect to ideological masking: festivals in Indian context represent collective joy, cultural continuity, and social cohesion. The poem argues this collective performance masks the underlying reality of "withered branches" - exhausted, depleted human lives.
- Step 5: Link to the "smallest" definition: the leaf trapped AFTER the festival is "smallest" because it reveals what the festival hides - the individual residue of collective performance.
- Step 6: Generalize: The secondary theme exposes how ritualized joy functions as anesthesia - the festival doesn't heal the withering; it only postpones the leaf's confrontation with the branch.

REASONING: The poem uses a single compressed image (leaf/branch/festival) to make a sophisticated sociological argument about the function of collective ritual in masking individual suffering. The temporal structure (after) and the passive verb (trapped) do the critical work.

ANSWER: The secondary theme of festival as ideological masking operates through a three-part structure: (1) The festival ("gj gR;kdkaM") represents collective performance of joy and unity; (2) The temporal marker "ckn" (after) positions the festival as a temporary interruption of the default state; (3) The image "ohjku gq, vk¡xuksa esa p<+rk gS" (trapped in withered branches) reveals the festival's aftermath - not renewal but entrapment of the already-depleted. The leaf is "smallest" because it is the minimal unit that exposes the festival's failure to address the structural withering. The poem thus critiques how public ritual masks private decay.

## WORKED_EXAMPLE_3
PROBLEM: Synthesize the secondary themes of alienation, mechanization, mortality, and ideological masking to construct a coherent reading of the poem's final stanza ("lcls [krjukd og jkr gksrh gS / tks f"kank :g osQ vklekuksa ij <yrh gS / ftlesa flI+kQZ mYyw cksyrs vkSj gqvk¡ gqvk¡ djrs xhnM+ / ges'kk osQ v¡èksjs can njok"kksa&pkSxkBksa ij fpid tkrs gS").

STEPS:
- Step 1: Parse the final stanza's syntax - "lcls [krjukd og jkr gksrh gS" (the smallest is that tree) introduces a culminating image that gathers previous themes.
- Step 2: Identify "f"kank :g osQ vklekuksa" (hollow roots of false unity) - connects to ideological masking (festival as false unity) and alienation (unity that is hollow).
- Step 3: Analyze "flI+kQZ mYyw cksyrs vkSj gqvk¡ gqvk¡ djrs xhnM+" (dry peacocks scream and scream and fade) - peacocks = beauty/joy; dry = depleted; screaming = protest; fading = mortality. Mechanization reduces even beauty to repetitive, fading noise.
- Step 4: Examine "ges'kk osQ v¡èksjs can njok"kksa&pkSxkBksa ij fpid tkrs gS" (fall on the nails and claws of vultures of greed) - vultures = systemic exploitation; nails/claws = instruments of extraction; falling = inevitable capture.
- Step 5: Synthesize all four themes: The tree represents the social organism. Its roots are hollow unity (ideological masking). Its flowers are dry peacocks - beauty mechanized into repetitive scream (mechanization). Its fate is vultures of greed (alienation from the fruits of one's life). The entire life-cycle ends in predatory capture (mortality as condition).
- Step 6: Connect to the poem's opening negation: The grand concepts (love, motherhood, nation) were "not smallest" because they are the "hollow roots" - the tree grows from them but they don't sustain it. The "smallest" things (door, window, staircase, road, leaf, night, darkness, this tree) are the actual living tissue.

REASONING: The final stanza functions as a thematic synthesis where the tree becomes an allegorical summary. Each element maps to a secondary theme developed earlier, and the "hollow roots" directly answer the opening negation - the grand concepts are precisely the hollow roots that cannot sustain the tree.

ANSWER: The final stanza synthesizes all secondary themes into a single arboreal allegory: the tree = the worker's life/social body; hollow roots of false unity = ideological masking (festivals, national borders, love's memory as empty foundations); dry peacocks screaming and fading = mechanization of beauty/joy into repetitive, exhausted performance; vultures of greed catching the falling = alienation where systemic exploitation harvests the life's residue; the entire cycle from hollow roots to vulture claws = mortality as daily condition rather than event. The stanza confirms the poem's central argument: what society calls "great" (roots of unity) are hollow, while what it ignores (the falling, the screaming, the caught) are the "smallest" - the actual substance of lived experience.

## COMPETENCY_QUESTION_1
QUESTION: A Class 11 student writes in their exam: "The secondary themes of the poem are loneliness, death, and city life." Using the distinction between thematic topics and thematic arguments, explain why this answer would receive partial marks at best, and rewrite it as a full-mark response that demonstrates analytical depth.

COMPETENCY: Thematic analysis - distinguishing topics from arguments and constructing evidence-based thematic statements.

STEPS:
- Step 1: Identify the error - the student lists topics (loneliness, death, city life) not thematic statements (what the poem ARGUES about these topics).
- Step 2: Explain the marking criterion - senior secondary assessment rewards "what the text says about X" not "X is in the text."
- Step 3: Convert each topic into a thematic argument using textual evidence: loneliness → "the poem argues that urban alienation is structural, not emotional, evidenced by domestic thresholds that fail to hold human presence"; death → "mortality is presented as daily condition embedded in routine, evidenced by the leaf trapped post-festival and the vultures at the tree's base"; city life → "mechanization converts relational spaces into functional conduits, evidenced by the door/window/staircase/road progression."
- Step 4: Show how to integrate these into a coherent paragraph with the primary theme.

ANSWER: The student's answer lists thematic topics, not thematic arguments. At senior secondary level, themes are arguments the text makes, not labels for content. A full-mark response: "The poem develops three interconnected secondary themes: (1) Structural alienation - evidenced by the sequence of domestic thresholds (door, window, staircase, road) that perform systemic functions (measuring transit, transmitting noise, absorbing grief, disposing bodies) instead of relational ones; (2) Mortality as daily condition - evidenced by the leaf trapped in withered branches after the festival and the vultures waiting at the tree of hollow unity, showing death not as event but as the default state masked by collective ritual; (3) Mechanization of the human - evidenced by the worker's body performing 'dke ls ykSVdj ?kj vkuk' while 'gekjs liuksa dk ej tkuk,' making the self a ghost in its own routine. These themes collectively substantiate the primary theme: the 'smallest' things are the minimal units where the system's reduction of human to function becomes visible."

DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: The poem uses "definition by exclusion" (negating grand concepts to define the smallest) as its central rhetorical strategy. Design a board-exam style analytical question (5 marks) that tests a student's ability to explain how this strategy operates across the poem's structure, and provide the model answer with marking scheme.

COMPETENCY: Assessment design - creating and evaluating competency-based questions that test analytical synthesis.

STEPS:
- Step 1: Design a question that requires tracing the strategy across structural sections (opening negation → middle affirmation → final synthesis), not just identifying it.
- Step 2: Ensure the question demands textual evidence from at least three distinct sections.
- Step 3: Create a marking scheme that allocates marks for: identification of strategy (1 mark), structural tracing (2 marks), thematic function (2 marks).
- Step 4: Write a model answer demonstrating the expected analytical depth.

ANSWER: **Question (5 marks):** "The poem 'lcls [krjukd' opens with three negations ('esgur dh ywV lcls [krjukd ugha gksrh / iqfyl dh ekj lcls [krjukd ugha gksrh / xíkjh&yksHk dh eq_h lcls [krjukd ugha gksrh') followed by seven affirmations ('lcls [krjukd gksrk gS...'). Analyze how this structure of definition by exclusion functions as a thematic argument. Support your answer with evidence from the opening, middle, and concluding sections."

**Marking Scheme:**
- 1 mark: Identifies definition by exclusion as the central rhetorical strategy
- 2 marks: Traces the strategy across three structural moments (opening negation of ideals, middle affirmation of mundane realities, concluding synthesis in the tree allegory)
- 2 marks: Explains thematic function - how exclusion reveals the gap between ideological constructs and lived experience, making the "smallest" the site of truth

**Model Answer:** The poem's definition by exclusion operates as a three-stage argument: (1) Opening negation dismisses three cultural pillars - romantic love ('esgur dh ywV'), maternal love ('iqfyl dh ekj'), national identity ('xíkjh&yksHk dh eq_h') - as "not smallest," establishing that society's highest values fail as measures of human significance. (2) Middle affirmation defines the "smallest" through seven concrete images (empty-hearted return, door that doesn't hold shadow, window whose voice wind steals, staircase that melts cries, crematorium road, post-festival leaf, sleepless night) - each a domestic threshold where relational function is replaced by systemic function. (3) Concluding synthesis (the tree of hollow roots, dry peacocks, vultures of greed) reveals WHY the opening ideals were hollow roots - they are the ideological masking that enables the mechanized exploitation depicted in the middle section. The strategy thus moves from ideological critique (what's false) to phenomenological evidence (what's real) to structural explanation (why the false sustains the real). The "smallest" emerges not as a size but as the minimal unit where the system's violence becomes visible.

DIFFICULTY: hard