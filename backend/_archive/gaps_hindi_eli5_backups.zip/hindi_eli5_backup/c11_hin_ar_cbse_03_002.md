## DEFINITION
Plot and Narrative Structure refers to the sequence of events in a story (plot) and the way the author organizes and presents those events (narrative structure), including elements like exposition, rising action, climax, falling action, resolution, and techniques such as flashback, foreshadowing, and point of view.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student can identify the five stages of plot in the given text, explain how the narrative structure (first-person retrospective narration, flashbacks) shapes the reader's understanding, and write a structured analysis using textual evidence.

## SCOPE_BOUNDARY
This node covers the plot and narrative structure of the specific chapter "viw osQ lkFk <kbZ lky" from the Class 11 Hindi Aroh textbook. It does not cover character analysis, themes, or literary devices in depth (those are separate nodes).

## WALKTHROUGH
Have you ever helped organize a school function or a play? Remember the chaos, the last-minute problems, and the final performance? Connect this to the author's experience in "viw osQ lkFk <kbZ lky". Guide the student to read the text and mark key events: what happens first, what builds tension, what is the turning point, and how it ends. Then discuss how the author tells the story as an adult looking back, which adds reflection and dramatic irony. The key insight: the narrative structure mirrors the play's structure—both have a beginning, middle, and end, but the adult perspective adds depth and meaning.

## DIAGNOSTIC_QUESTION_1
What are the five standard stages of a plot in a narrative? List them in order.

## DIAGNOSTIC_ANSWER_1
The five stages are: 1) Exposition (introduction of setting, characters, situation), 2) Rising Action (events that build tension), 3) Climax (turning point, highest tension), 4) Falling Action (events after climax leading to resolution), 5) Resolution (outcome). A wrong answer (e.g., missing stages or wrong order) reveals the student lacks the basic vocabulary to analyze plot structure.

## DIAGNOSTIC_QUESTION_2
In "viw osQ lkFk <kbZ lky", the author narrates the story as an adult recalling childhood events. How does this first-person retrospective point of view affect the narrative structure? Explain in your own words.

## DIAGNOSTIC_ANSWER_2
The retrospective narration allows the author to interject adult reflections, create dramatic irony (the child doesn't know what the adult knows), and structure the story thematically rather than strictly chronologically. A wrong answer (e.g., "it makes it more interesting") shows the student cannot analyze how point of view shapes structure.

## DIAGNOSTIC_QUESTION_3
Identify the climax of the story and explain why it is the turning point. Use one specific detail from the text.

## DIAGNOSTIC_ANSWER_3
The climax is the performance night when two actors appear as "Hkwyks" (the same character), causing confusion and comedy. This is the turning point because the play's success hangs on this moment, and the author's childhood dream is both realized and subverted. A wrong answer (e.g., identifying the stage-building as climax) shows the student cannot distinguish between rising action and climax.

## DIAGNOSTIC_QUESTION_4
Compare the structure of the play within the story (the play being staged) with the structure of the story itself. How do they mirror each other?

## DIAGNOSTIC_ANSWER_4
Both have a preparation phase (rehearsals/exposition), a performance (climax), and an aftermath (resolution). The story's narrative structure mimics the play's three-act structure, and the author's adult narration acts like a narrator in a play, commenting on the action. A weak answer fails to see the meta-theatrical parallel.

## DIAGNOSTIC_QUESTION_5
Evaluate the author's decision to include the episode of the "Hkwyks" mix-up. Does it strengthen or weaken the narrative? Justify your opinion.

## DIAGNOSTIC_ANSWER_5
It strengthens the narrative because it adds humor, highlights the theme of imperfection in art, and provides a memorable climax that underscores the community's collaborative spirit. A wrong evaluation (e.g., "it's just a funny incident") shows the student cannot link a plot event to thematic significance.

## DIAGNOSTIC_QUESTION_6
Write a brief alternative ending (3-4 sentences) for the story where the play is a complete disaster, and explain how this would change the story's message.

## DIAGNOSTIC_ANSWER_6
Alternative ending: The stage collapses, actors forget lines, and the audience leaves angry. The author feels shame and gives up theatre. This would change the message from "art brings community together despite flaws" to "failure destroys dreams." A poor answer would not connect the ending to the theme.

## COMMON_MISCONCEPTION
Students often confuse the sequence of events (plot) with the narrative structure (how the story is told). They think identifying what happens is the same as analyzing structure. For example, they list events but miss the flashback when the adult author reflects on the child's perspective, or they don't notice that the story starts in media res with the author already wanting to stage a play. This error occurs because they focus on content over form.

## ON_FAILURE
If the student confuses plot and structure, do this: 1) Have them draw a timeline of events in chronological order (plot). 2) Have them draw a second timeline of the order in which the author presents them (narrative order). 3) Compare the two and mark where they differ (e.g., the opening reflection, the digressions). 4) Ask: "Why did the author choose this order?" This makes the distinction concrete.

## BUILDS_ON
This builds on the basic understanding of story elements (beginning, middle, end) from earlier classes.

## LEADS_TO
This enables deeper analysis of character development and theme, which depend on understanding how plot events reveal character and convey theme.

## PREREQUISITE_NODE_IDS
c11_hin_ar_cbse_03_001
## PREREQUISITE_REASONS
c11_hin_ar_cbse_03_001: The "Before You Read" node provides context about the author and the setting, which is necessary to understand the exposition of the plot.

## FORWARD_NODE_IDS
c11_hin_ar_cbse_03_003, c11_hin_ar_cbse_03_004, c11_hin_ar_cbse_03_006, c11_hin_ar_cbse_03_005, c11_hin_ar_cbse_03_007, c11_hin_ar_cbse_03_008, c11_hin_ar_cbse_03_009, c11_hin_ar_cbse_03_010, c11_hin_ar_cbse_03_011, c11_hin_ar_cbse_03_012, c11_hin_ar_cbse_03_013, c11_hin_ar_cbse_03_014, c12_hin_a_cbse_06_002, c12_hin_a_cbse_08_002, c12_hin_a_cbse_09_002, c12_hin_a_cbse_17_002, c12_hin_ar_cbse_14_002

## FORWARD_REASONS
c11_hin_ar_cbse_03_003: Setting and atmosphere are established in the exposition and affect the plot's development. c11_hin_ar_cbse_03_004: Character analysis of the protagonist requires understanding how plot events shape the protagonist's journey. c11_hin_ar_cbse_03_006: Primary theme emerges through the plot's resolution and narrative structure.
c11_hin_ar_cbse_03_005: Plot knowledge locates where each supporting character enters/exits and how their actions drive narrative turning points.  
c11_hin_ar_cbse_03_007: Plot and narrative structure knowledge allows students to map secondary themes onto specific narrative beats (exposition, complication, climax, resolution).  
c11_hin_ar_cbse_03_008: Plot/Narrative Structure tells *where* in the story key images appear (e.g., flood climax vs. peaceful well scenes) — device function changes with narrative position.  
c11_hin_ar_cbse_03_009: Plot and Narrative Structure provides the event-sequence knowledge needed to spot where expectation-reality gaps (irony) occur in the story timeline.  
c11_hin_ar_cbse_03_010: Understanding plot structure and narrative sequence is essential to locate each vocabulary word in its precise dramatic moment - the 'when' and 'why' of its usage.  
c11_hin_ar_cbse_03_011: Plot and Narrative Structure supplies the narrative segments (childhood, rehearsal, performance) where language usage shifts — e.g., rehearsal scenes use more imperatives.  
c11_hin_ar_cbse_03_012: Plot sequence knowledge required to locate where events happen for literal retrieval.  
c11_hin_ar_cbse_03_013: Plot structure knowledge needed to trace how rehearsal chaos mirrors narrative arc  
c11_hin_ar_cbse_03_014: कथानक और कथात्मक संरचना की समझ साक्ष्य (Evidence) चुनने के लिए अनिवार्य है।  
c12_hin_a_cbse_06_002: Teaches "stanzaic progression" in narrative poems — directly applicable to "हजारी-जइके".  
c12_hin_a_cbse_08_002: Shows how emotional arcs replace event-based plots in Bhakti/Riti poetry.  
c12_hin_a_cbse_09_002: Practiced identifying turning points in Class 11 stories.  
c12_hin_a_cbse_17_002: Deepens understanding of how narrative structure serves theme, a skill directly applied here.  
c12_hin_ar_cbse_14_002: Practices first-person narrative limitations in "काफ़ी कश्मीर" — directly applicable to this story's narrator.  
c11_hin_ar_cbse_03_004: Plot structure identifies the three major crises (stage, casting, performance) that test the narrator's character.  
c11_hin_ar_cbse_03_006: Plot knowledge is essential to trace thematic development across the narrative arc.  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
none

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_03_001 -> c11_hin_ar_cbse_03_002 -> c11_hin_ar_cbse_03_003

## THIS_FORMULA
N/A - conceptual

## FORMULA_VARIABLES
N/A

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
analytical

## CROSS_SUBJECT
c11_history_social_change | The story reflects the social and cultural life of a village in pre-independence India, connecting to historical context of rural education and theatre.
c11_civics_community_participation | The collective effort to stage the play illustrates community participation and local governance, relevant to civics concepts of civic engagement.

## PREREQ_CONCEPT
Understanding of basic story elements: character, setting, problem, solution.

## PREREQ_BEFORE
The student should be able to summarize the story in their own words.

## PREREQ_STUCK
If stuck, review the summary of the story from the "Before You Read" node and re-read the text focusing on the sequence of events.

## WORKED_EXAMPLE_1
PROBLEM: Analyze the exposition of "viw osQ lkFk <kbZ lky". Identify the setting, the protagonist's goal, and the initial conflict.
STEPS:
- Step 1: Read the first few paragraphs of the story. Note the time (author's childhood), place (village school), and the narrator's voice (adult recalling).
- Step 2: Identify the protagonist (the author as a child) and his goal: to stage a play.
- Step 3: Identify the initial conflict: lack of a stage, resources, and experienced actors.
- Step 4: Explain how the exposition sets up the rest of the plot by establishing the stakes (the author's passion vs. reality).
- Step 5: Connect to the narrative structure: the adult narrator frames the childhood dream with hindsight.
REASONING: The exposition introduces the central desire and obstacles, and the retrospective narration adds a layer of reflection that colors the entire story.
ANSWER: The exposition establishes the village school setting, the child-author's intense desire to stage a play, and the obstacles of no stage, no funds, and no experienced actors. The adult narrator's voice frames this as a formative memory.

## WORKED_EXAMPLE_2
PROBLEM: Trace the rising action in the story. List at least four events that build tension toward the climax.
STEPS:
- Step 1: Define rising action as events that complicate the conflict and increase stakes.
- Step 2: Scan the text for events after the exposition and before the performance night.
- Step 3: Select events: (a) building the stage with villagers' help, (b) rehearsals with untrained actors, (c) the challenge of finding a "Hkwyks" actor, (d) the weather threat and last-minute preparations.
- Step 4: Explain how each event raises tension: the stage building shows community involvement but also difficulty; rehearsals show the gap between dream and reality; the "Hkwyks" casting creates a specific problem; weather adds external pressure.
- Step 5: Note how the narrative structure interweaves these with the author's reflections.
REASONING: Rising action is not just a list but a chain of cause-and-effect that tightens the plot toward the climax.
ANSWER: The rising action includes: 1) The community effort to build the stage, 2) Chaotic rehearsals with children and villagers, 3) The casting crisis for the role of "Hkwyks" leading to two actors being prepared, 4) The stormy weather on the performance day threatening cancellation. Each event escalates the stakes.

## WORKED_EXAMPLE_3
PROBLEM: Explain how the narrative structure uses a frame story (the adult author looking back) to enhance the theme of memory and art. Combine plot analysis with narrative technique.
STEPS:
- Step 1: Identify the frame: the story begins and ends with the adult author reflecting on the past.
- Step 2: Identify the inner story: the chronological events of the play production.
- Step 3: Analyze how the frame comments on the inner story: the adult voice provides insight the child lacked, e.g., the significance of the "Hkwyks" mix-up.
- Step 4: Show how the frame creates dramatic irony: we know the play's impact on the author's life, the child does not.
- Step 5: Connect to theme: the frame emphasizes that art's value lies in the experience and memory, not perfection.
- Step 6: Conclude how this structure deepens the reader's emotional response.
REASONING: The frame story is a narrative structure device that allows the author to interpret the plot events thematically, turning a simple anecdote into a meditation on art and community.
ANSWER: The narrative uses a frame structure where the adult author introduces and concludes the childhood memory. This frame allows reflective commentary on the events, creating dramatic irony and highlighting the theme that imperfect art can have lasting personal and communal significance. The child's perspective lives the events; the adult's perspective gives them meaning.

## COMPETENCY_QUESTION_1
QUESTION: The story "viw osQ lkFk <kbZ lky" is often described as a "play within a story." Analyze how the structure of the play (rehearsal, performance, aftermath) parallels the structure of the narrative itself. Provide two specific parallels.
COMPETENCY: Analyzing narrative structure and meta-fictional elements
STEPS:
- Step 1: Outline the three-act structure of the play being staged.
- Step 2: Outline the plot structure of the overall story.
- Step 3: Identify parallel stages: preparation (rehearsals = rising action), performance (climax), aftermath (resolution).
- Step 4: Explain how the author uses this parallel to blur the line between art and life.
ANSWER: The play's rehearsals mirror the story's rising action (both involve preparation and obstacles). The play's performance night is the story's climax (both are the moment of truth). The play's aftermath (audience reaction, author's reflection) mirrors the story's resolution (author's adult understanding). This parallel structure reinforces the theme that life imitates art.
DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: "The narrative structure of 'viw osQ lkFk <kbZ lky' is non-linear because the adult narrator frequently interrupts the chronological flow with reflections." Evaluate this statement. Do you agree? Support your answer with two examples from the text.
COMPETENCY: Evaluating narrative technique and its effect
STEPS:
- Step 1: Define non-linear narrative.
- Step 2: Examine the text for interruptions: e.g., the opening paragraph where the adult author reflects on the origin of the play idea; the digression about the village people and their characters.
- Step 3: Determine if these interruptions break chronological order or are woven into the narration.
- Step 4: Argue that while the main plot is chronological, the reflective passages create a layered temporal structure, making it non-linear in a subtle way.
- Step 5: Provide two examples: (a) the opening reflection on the first play idea, (b) the author's commentary during the performance about the "Hkwyks" mix-up.
ANSWER: I agree. The narrative is primarily chronological but layered with the adult narrator's reflective intrusions that disrupt linear time. Example 1: The story opens with the adult author explaining how the idea of the play came to him years earlier, before jumping to the childhood events. Example 2: During the climax, the narrator steps out of the scene to comment on the irony of two "Hkwyks" actors, a perspective only possible in retrospect. These make the structure non-linear in a thematic sense.
DIFFICULTY: hard