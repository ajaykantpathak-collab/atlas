## DEFINITION
Critical Thinking: Analysis and Interpretation is the ability to examine a literary text beyond its surface meaning, evaluate the author's choices (structure, language, perspective), and construct an evidence-based argument about the text's deeper significance, cultural context, and ideological underpinnings.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student can independently select relevant textual evidence from any of the three stories, connect it to a specific interpretive claim (e.g., about power, education, or tradition), and explain how the author's narrative techniques (irony, symbolism, narrative voice) shape that meaning, writing a structured analytical paragraph using the Point-Evidence-Explanation-Link (PEEL) method.

## SCOPE_BOUNDARY
This node covers critical analysis of the three stories in Chapter 11 ("ckyd cp x;k", "?kM+h osQ iq”ksZ", "<sys pqu yks") focusing on interpretive arguments supported by textual evidence. It does NOT cover creative writing based on the stories (node 014) or speaking/listening activities (node 015), nor does it re-teach plot summary, character sketches, or device identification done in nodes 001–012.

## WALKTHROUGH
Imagine you are asked in a board exam: "How does the author use the child's perspective in 'ckyd cp x;k' to critique the colonial education system?" A struggling student might retell the plot. Instead, start by identifying the *lens* — here, the naive child narrator. Next, hunt for *specific moments* where the child's observations clash with adult reality (e.g., the teacher's brutal punishment vs. the child's confusion). Then, ask: "What does this gap *reveal* about the system?" Finally, structure your answer: Point (the child's lens exposes brutality), Evidence (quote the child's description of the teacher's stick), Explanation (the contrast highlights normalized violence), Link (this supports the story's critique of education as oppression). Practice this 4-step move on each story.

## DIAGNOSTIC_QUESTION_1
What is the primary difference between a literal comprehension answer and a critical analysis answer for a question about "?kM+h osQ iq”ksZ"?

## DIAGNOSTIC_ANSWER_1
A literal comprehension answer retells what the narrator says about clocks (e.g., "The narrator explains how clocks measure time"). A critical analysis answer interprets *why* the author chooses that voice (e.g., "The narrator's pedantic lecture on clocks satirizes institutional control over indigenous timekeeping"). Wrong answers usually confuse summary with argument; they miss that critical analysis requires evaluating the author's *purpose* and *effect*, not just content.

## DIAGNOSTIC_QUESTION_2
In "ckyd cp x;k", the child says, "eSa ;koTtUe yksdlsok d:¡ xk". Explain what this statement reveals about the gap between the child's understanding and the author's intention.

## DIAGNOSTIC_ANSWER_2
The child literally means he was born to serve the nation (innocent patriotism), but the author uses dramatic irony: the "service" imposed is colonial schooling that erases his culture. The gap shows how education colonizes the mind. A wrong answer treats the statement at face value, missing the irony that the child's "service" is actually his subjugation.

## DIAGNOSTIC_QUESTION_3
Apply the concept of "narrative perspective" to compare how "ckyd cp x;k" and "<sys pqu yks" use a limited point of view to critique authority. Write one analytical paragraph for each story.

## DIAGNOSTIC_ANSWER_3
For "ckyd cp x;k": The child's limited view makes the teacher's cruelty visible through innocent description (e.g., the stick "dk'kh ¯gnw" becoming a tool of terror), forcing the reader to judge what the child cannot. For "<sys pqu yks": The folk-tale frame (the three sisters) and the king's limited choice expose how authority reduces complex lives to a gamble. A weak answer describes the perspectives without linking them to *critique of authority*.

## DIAGNOSTIC_QUESTION_4
Analyze the symbol of the "fe^h" (clock/watch) in "<sys pqu yks". How does its meaning shift from a practical object to a metaphor for colonial modernity? Support with two textual details.

## DIAGNOSTIC_ANSWER_4
Initially, the clock is a foreign curiosity ("osfn dh e^h", "xksfHky] Hkkj}ktµlHkh esa gSA"). It becomes a metaphor when the narrator equates "tUeHkj osQ lkFkh dh pquko fe^h osQ <syksa ij NksM+uk" — colonial rule synchronizes indigenous life to an external, mechanical rhythm, disrupting organic time ("cdkSy dchj osQµ iRFkj iwts gfj feysa rks rw iwt igkj"). Wrong answers list clock references without tracing the *semantic shift* from object to symbol of imposed order.

## DIAGNOSTIC_QUESTION_5
Evaluate the claim: "The three stories in this chapter collectively argue that *education* and *time* are the twin instruments of colonial domination." Defend or refute using evidence from at least two stories.

## DIAGNOSTIC_ANSWER_5
Defend: In "ckyd cp x;k", education is the instrument (school as "okf"kZdksRlo" that breaks the child). In "?kM+h osQ iq”ksZ", time is the instrument (clocks as "osn'kkL=kK èkekZpk;ks± dk gh dke" to discipline natives). In "<sys pqu yks", both merge: the clock (*fe^h*) regulates life, and the folk-tale's loss of oral tradition ("vk'oyk;u] xksfHky] Hkkj}ktµlHkh") shows epistemic colonization. Refute: The stories also show resistance (child's escape, narrator's satire, folk-tale's survival). A weak evaluation picks one side without acknowledging textual complexity.

## DIAGNOSTIC_QUESTION_6
Create a new interpretive question for "?kM+h osQ iq”ksZ" that requires analyzing the author's use of *addressing the reader directly* ("rqEgsa", "vkidh"). Write the question and a model answer outline (Point, Evidence, Explanation, Link).

## DIAGNOSTIC_ANSWER_6
Question: "How does the second-person address in '?kM+h osQ iq”ksZ' implicate the reader in the politics of timekeeping?" Outline: Point — The direct address collapses distance between narrator and reader. Evidence — "rqEgsa blls D;k\ D;k bl miek ls ftKklk can gks tkrh gS" and "vkidh ?kM+h esa vkèkh jkr gS". Explanation — It forces the reader to confront their own complicity in regulated time. Link — This technique turns a philosophical essay into a personal indictment of modern discipline. A poor answer describes the pronoun usage without analyzing its *rhetorical effect*.

## COMMON_MISCONCEPTION
Students think "critical analysis" means *finding faults* in the story or *expressing personal opinions* ("I feel the author is wrong about clocks"). In Class 12 Hindi board exams, critical analysis means *interpreting the author's craft*: how literary choices (irony, symbol, narrative voice) construct meaning. They confuse "analysis" (breaking down how the text works) with "criticism" (judging the text's value). This leads to answers like "The story is good because it teaches us to value time" instead of "The author uses the clock as a symbol to critique colonial modernity."

## ON_FAILURE
If a student cannot move beyond summary/opinion:
1. Give them a one-paragraph summary of "ckyd cp x;k" and a model analytical paragraph on the same paragraph. Ask them to highlight every sentence in the model that *does not appear in the summary* (these are the analytical moves).
2. Practice the "So what?" drill: After every evidence quote, write "This shows that..." and "This matters because..." until they reach a thematic claim.
3. Revisit node c12_hin_a_cbse_11_009 (Irony and Symbolism) and c12_hin_a_cbse_11_012 (Comprehension) to re-learn device identification and inferential reading.
4. Re-diagnostic: Ask them to analyze the *title* "?kM+h osQ iq”ksZ" as an ironic signifier (3-sentence written response).

## BUILDS_ON
This node builds on the ability to identify literary devices (nodes 008, 009) and inferential comprehension (node 012) by requiring students to *use* those devices as evidence for interpretive claims.

## LEADS_TO
This node enables Writing Skills (node 014) where students must produce full analytical essays, and Speaking/Listening (node 015) where they defend interpretations in discussion.

## PREREQUISITE_NODE_IDS
c12_hin_a_cbse_11_002, c12_hin_a_cbse_11_004, c12_hin_a_cbse_11_006, c12_hin_a_cbse_11_008, c12_hin_a_cbse_11_009, c12_hin_a_cbse_11_012, c11_hin_ar_cbse_11_013, c12_hin_a_cbse_11_005, c12_hin_a_cbse_11_007, c12_hin_a_cbse_11_010, c12_hin_a_cbse_11_011

## PREREQUISITE_REASONS
c12_hin_a_cbse_11_002: Plot knowledge needed to select relevant scenes for evidence.
c12_hin_a_cbse_11_004: Protagonist analysis provides the character lens for interpretation.
c12_hin_a_cbse_11_006: Primary theme identification gives the interpretive framework.
c12_hin_a_cbse_11_008: Imagery/Metaphor identification supplies symbolic evidence.
c12_hin_a_cbse_11_009: Irony/Symbolism identification supplies rhetorical evidence.
c12_hin_a_cbse_11_012: Inferential comprehension is the baseline for reading between lines.
c11_hin_ar_cbse_11_013: Class 11 critical thinking foundation (analysis of "Namak ka Daroga" etc.) provides the methodological template.
c12_hin_a_cbse_11_005: Critical thinking questions often ask "compare the role of X in story A with Y in story B" — this node builds that comparative skill.  
c12_hin_a_cbse_11_007: Critical thinking requires synthesizing primary and secondary themes into a coherent interpretation.  
c12_hin_a_cbse_11_010: Vocabulary in Context: की समझ आवश्यक है, क्योंकि यह नोड (Critical Thinking:) इसी आधार पर आगे बढ़ता है।  
c12_hin_a_cbse_11_011: Register and dialect analysis enables critical interpretation of author's sociolinguistic stance.  

## FORWARD_NODE_IDS
c12_hin_a_cbse_11_014, c12_hin_a_cbse_11_015
## FORWARD_REASONS
c12_hin_a_cbse_11_014: Writing skills require the analytical paragraphs practiced here as building blocks for essays.
c12_hin_a_cbse_11_015: Speaking/listening discussions require the evidence-based claims and counter-claims developed here.

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
c12_history_colonialism: The stories' critique of colonial education and time-discipline connects to historical processes of colonial modernity (Macaulay's Minute, factory acts).
c12_sociology_social_change: The tension between indigenous/oral time ("?kM+h", "fe^h") and mechanical/colonial time illustrates theories of social change (tradition vs. modernity).
c12_politicalscience_power_authority: The school and clock as disciplinary institutions illustrate Foucault's "disciplinary power" — relevant for understanding power structures.

## CHAIN_DESCRIPTION
c12_hin_a_cbse_11_009 -> c12_hin_a_cbse_11_013 -> c12_hin_a_cbse_11_014

## THIS_FORMULA
N/A - conceptual

## FORMULA_VARIABLES
N/A

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
conceptual

## CROSS_SUBJECT
N/A | The story "ckyd cp x;k" dramatizes the colonial classroom as a site of cultural erasure, directly illustrating historical policies like Macaulay's Minute on Education (1835) which aimed to create "a class of persons Indian in blood and colour, but English in taste."
 N/A | The conflict in "?kM+h osQ iq”ksZ" between organic, event-based time ("?kM+h le; crykrh gSA") and abstract, clock-time ("osn'kkL=kK èkekZpk;ks±") exemplifies the sociological shift from "traditional" to "modern" temporal consciousness described by theorists like E.P. Thompson.
 N/A | The teacher's stick in "ckyd cp x;k" and the clock's regulation in "<sys pqu yks" function as what Foucault calls "disciplinary technologies" — instruments that produce docile bodies through surveillance and normalization.
## PREREQ_CONCEPT
The student must understand that literary texts are *constructed artifacts* — every detail (word choice, narrator, symbol) is a deliberate choice by the author to shape meaning.

## PREREQ_BEFORE
The student must be able to: (1) distinguish narrator from author, (2) identify at least two literary devices per story, (3) write a PEEL paragraph for a simple inferential question (from node 012).

## PREREQ_STUCK
If stuck, return to node c12_hin_a_cbse_11_009 (Irony and Symbolism) and practice identifying *one* ironic moment in "ckyd cp x;k" and explaining its effect in two sentences.

## WORKED_EXAMPLE_1
PROBLEM: Analyze how the author uses the child's misunderstanding of "yaw" (yawn) in "ckyd cp x;k" to expose the brutality of the colonial classroom. Write a PEEL paragraph.

STEPS:
- Step 1: Identify the moment — the child says "yaw" (meaning "yes" in his dialect) but the teacher hears "yawn" and beats him.
- Step 2: Identify the device — dramatic irony (child's innocence vs. teacher's cruelty) and linguistic alienation (dialect vs. standard Hindi).
- Step 3: Select evidence — "ckyd oqQN lkspus yxk... ^yaw*... firk vkSj vè;kid fujk'k gks x,A" and the description of the stick "dk'kh ¯gnw".
- Step 4: Explain the effect — The child's harmless word becomes a pretext for violence; the teacher's misreading mirrors the colonial system's misreading of the child's culture.
- Step 5: Link to theme — This moment crystallizes the story's argument: education here is not liberation but a violent imposition of linguistic and cultural hegemony.

REASONING: The steps move from concrete textual moment to device identification to evidence selection to interpretive explanation to thematic linking — the exact chain required for board exam analytical answers.

ANSWER: The child's innocent utterance "yaw" (dialect for "yes") is misheard as a yawn, triggering brutal punishment. This dramatic irony exposes the colonial classroom's foundational violence: the teacher, representing state authority, literally beats the child's mother-tongue out of him. The stick ("dk'kh ¯gnw") becomes a metonym for the entire system that mistakes cultural difference for insolence. Thus, a single misunderstood word encapsulates the story's critique of education as cultural erasure.

## WORKED_EXAMPLE_2
PROBLEM: In "?kM+h osQ iq”ksZ", the narrator argues "èkeZ dk jgL; tkuuk osn'kkL=kK èkekZpk;ks± dk gh dke gSA". Critically evaluate this claim by analyzing the narrator's own relationship with clocks.

STEPS:
- Step 1: Locate the claim — it appears in the middle of the essay as a provocative generalization.
- Step 2: Examine the narrator's practice — he owns a watch ("vukM+h osQ gkFk esa pkgs ?kM+h er nks"), checks it constantly, and structures his day by it.
- Step 3: Identify the contradiction — the narrator *simultaneously* critiques clock-time as a tool of specialists ("osn'kkL=kK èkekZpk;ks±") and lives by it ("gesa rks èkks[kk gksrk gS fd ijnknk dh ?kM+h tsc esa Mkys fiQjrs gks").
- Step 4: Interpret the contradiction — This is not hypocrisy but *complicity*: the narrator shows how even the critic is colonized by clock-time. The essay performs the trap it describes.
- Step 5: Formulate evaluation — The claim is deliberately hyperbolic; its truth lies in exposing how *inescapable* clock-discipline is, even for those who see through it.

REASONING: Critical evaluation requires noticing the text's self-reflexivity — the narrator includes himself in the critique. This moves beyond "agree/disagree" to analyzing *how the text constructs its own argument*.

ANSWER: The narrator's claim that only specialists need clock-time is intentionally undermined by his own confession of watch-dependence. This performative contradiction reveals that clock-time is not merely a tool used by elites but a totalizing regime that captures even its critics. The essay thus demonstrates the *hegemony* of mechanical time: resistance is possible only from within the system.

## WORKED_EXAMPLE_3
PROBLEM: Compare the representation of "authority" in all three stories. How does each story use a different narrative strategy to make authority visible as *constructed* rather than natural? Write a comparative analytical response (4-5 sentences per story).

STEPS:
- Step 1: Define "authority" in each story — School/Teacher in "ckyd", Clock/Specialists in "?kM+h", King/Fate in "<sys pqu yks".
- Step 2: Identify narrative strategy for "ckyd" — Child's limited POV makes authority appear arbitrary and terrifying (the stick appears suddenly, reasons unexplained).
- Step 3: Identify narrative strategy for "?kM+h" — Direct address and satirical essay form make authority discursive: the narrator *argues* against clock-time, exposing its ideological basis.
- Step 4: Identify narrative strategy for "<sys pqu yks" — Folk-tale frame (three sisters, king's gamble) makes authority mythic and arbitrary; the clock ("fe^h") enters as a foreign object that disrupts the tale's logic.
- Step 5: Synthesize — All three denaturalize authority: "ckyd" through innocent perception, "?kM+h" through intellectual critique, "<sys pqu yks" through folk-tale defamiliarization.
- Step 6: Conclude — Together they show authority operates at bodily (school), temporal (clock), and existential (fate) levels, all vulnerable to narrative exposure.

REASONING: Comparative analysis requires a common analytical framework (here: "narrative strategy to denaturalize authority") applied consistently across texts. This is a higher-order skill tested in competency-based board questions.

ANSWER: In "ckyd cp x;k", the child's-eye view renders the teacher's authority bewildering and brutal — the stick falls without logic, making power visible as raw force. In "?kM+h osQ iq”ksZ", the essayist's direct address and irony dissect clock-time as a specialist discourse masquerading as universal truth, revealing authority as linguistic construction. In "<sys pqu yks", the folk-tale's arbitrary choice of a sister by the king, later mirrored by the clock's intrusion ("fe^h"), frames authority as a game of chance colonized by mechanical order. Each story uses its distinct form — autobiographical vignette, satirical essay, folk-tale — to strip authority of its "natural" aura.

## COMPETENCY_QUESTION_1
QUESTION: A student writes: "In 'ckyd cp x;k', the author shows that British education was bad because the teacher beat the child." Identify two specific weaknesses in this analytical claim and rewrite it as a board-exam quality analytical statement (2-3 sentences).

COMPETENCY: Critical Evaluation of Peer Response / Argument Refinement

STEPS:
- Step 1: Identify weakness 1 — "British education was bad" is a vague moral judgment, not a literary analysis of *how* the text constructs its critique.
- Step 2: Identify weakness 2 — "because the teacher beat the child" reduces a complex scene to a single causal claim, ignoring narrative technique (irony, perspective, symbolism).
- Step 3: Apply the PEEL structure — Point: The story critiques colonial education through the child's limited perspective. Evidence: The child's dialect word "yaw" is misread as insolence. Explanation: This dramatic irony exposes the system's cultural violence. Link: The beating is not just cruelty but a symbol of epistemic erasure.
- Step 4: Write the refined statement.

ANSWER: Weaknesses: (1) Replaces literary analysis with moral summary. (2) Ignores how narrative form (child's POV, irony) produces the critique. Refined: "Through the child's naive perspective, the story exposes colonial education as cultural violence: the teacher's brutal punishment of the dialect word 'yaw' (misheard as a yawn) uses dramatic irony to show how the system criminalizes the child's native language, making the stick a metonym for epistemic erasure."

DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: "The clock in '<sys pqu yks' is not just a symbol of colonial modernity but a *character* in the folk-tale." Defend this interpretation by analyzing three specific moments where the clock acts with agency, and explain how this personification serves the story's critique.

COMPETENCY: Advanced Literary Analysis (Personification as Critical Device)

STEPS:
- Step 1: Identify three moments of clock-agency — (a) The clock is chosen by the king as a "gift" that structures the tale's timeline. (b) The clock's "Mxyksa" (hands) are described as having "Hkjkslk" (entanglement) with life's threads. (c) The clock's rhythm dictates the folk-tale's ending: "cdkSy dchj osQ iRFkj iwts gfj feysa rks rw iwt igkj".
- Step 2: Analyze personification — The clock "chooses", "entangles", "dictates" — verbs of agency usually reserved for humans.
- Step 3: Explain critical function — Personifying the clock makes colonial modernity an *active antagonist* in the folk world, not a passive tool. It invades the narrative logic of the tale itself.
- Step 4: Connect to critique — The folk-tale's oral, cyclical time ("tl"; "dhfrZ") is disrupted by the clock's linear, mechanical agency. The story *performs* the colonization of indigenous temporality.
- Step 5: Synthesize into a coherent argument.

ANSWER: The clock acts as a character when (1) the king selects it as the prize that determines the sisters' fates, (2) its hands ("fe^h osQ Mxyksa") actively "Hkjkslk" (entangle) with the threads of life — "eaxy", "'kfu'pj", "c`gLifr" — and (3) its mechanical rhythm ultimately overwrites the tale's oral logic ("cdkSy dchj osQ iRFkj iwts gfj feysa rks rw iwt igkj"). This personification transforms the clock from object to agent of colonial modernity, enacting the violent synchronization of indigenous life-worlds to an alien temporal order. The folk-tale form, which relies on cyclical, event-based time, is itself colonized by the clock's linear agency — a meta-critique of how colonial epistemology rewrites native narrative structures.

DIFFICULTY: hard