## DEFINITION
The primary theme is the central, unifying idea that the author explores throughout the text, revealed through the protagonist's journey, key conflicts, and resolution; the message is the author's specific perspective or insight on that theme intended for the reader to internalize. In Kabir's poetry (Chapter 10), the primary theme is *Nirguna Bhakti* (formless devotion) transcending social hierarchies, and the message is that true spirituality lies in internal love (*prem*) and surrender to the Divine (*Ram*) rather than external rituals, caste identity, or scriptural scholarship.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student can independently identify the primary theme of Kabir's poetry in this chapter, trace its development across at least three distinct textual evidences (prose introduction and poem), and articulate the social reform message in a structured PEEL paragraph using precise terminology (e.g., *Nirguna*, *Saguna*, *varna-vyavastha*, *prem-marg*).

## SCOPE_BOUNDARY
This node covers identifying and analyzing the *primary* theme and core message of the Kabir chapter (prose introduction + Poem 1) only. It does NOT cover secondary themes (node 10_007), literary devices (nodes 10_008, 10_009), or comprehension questions (node 10_012). It focuses on the thematic core: rejection of ritualism/caste via internal devotion.

## WALKTHROUGH
Imagine you are listening to a street musician in Varanasi singing a Kabir *doha* – the words are simple, but they challenge everything you've been taught about religion and status. To find the theme, start by reading the prose introduction (page 113-114) not for facts, but for *conflicts*: Kabir vs. Pandits, Kabir vs. Mullahs, Kabir vs. Caste System. Next, read Poem 1 aloud, marking every word related to 'identity' (julaha, neech, kasbi) and every word related to 'divine connection' (Ram, prem, bhagat). The theme lives in the *tension* between these two columns. The key insight: Kabir uses his own 'low' identity as proof that God is accessible to all without mediators.

## DIAGNOSTIC_QUESTION_1
What is the precise literary definition of 'primary theme' as distinct from 'subject' or 'plot' in a senior secondary context?

## DIAGNOSTIC_ANSWER_1
The primary theme is the universal, abstract idea explored through the text (e.g., 'the accessibility of the divine beyond social barriers'), whereas the subject is the concrete topic (e.g., 'Kabir's life as a weaver') and plot is the sequence of events. A wrong answer (e.g., 'the theme is Kabir's weaving') reveals the student confuses concrete subject matter with abstract thematic concept, a Class 10-level error that prevents analytical writing in Class 11.

## DIAGNOSTIC_QUESTION_2
Explain in your own words why Kabir's self-identification as a 'julaha' (weaver) and 'neech' (low caste) in the poem is *essential* to the primary theme, not just biographical detail.

## DIAGNOSTIC_ANSWER_2
Kabir's declared low-caste identity *is* the thematic argument: it serves as living evidence that *Nirguna Bhakti* requires no ritual purity or high birth, directly enacting the theme 'God belongs to the lover, not the scholar.' A wrong answer treating this as mere autobiography ('he mentions it because he was a weaver') misses the rhetorical function of the poet's persona in constructing the theme – a critical Class 11 analytical gap.

## DIAGNOSTIC_QUESTION_3
Apply the 'Theme Tracing' method: List three distinct textual anchors (one from prose intro, two from Poem 1) that collectively prove the primary theme is 'Internal devotion transcends external ritual/caste.' Use line/stanza references.

## DIAGNOSTIC_ANSWER_3
1. Prose: "ehjk us Ñ".k ls viuh vuU;rk O;Dr dh gS" (Kabir expresses independence from ritual). 2. Poem 1, Opening: "esjs rks fxjèkj xksiky] nwljks u dksbZ" (My capital is Ram alone, nothing else) – rejects material/ritual capital. 3. Poem 1, Middle: "valqou ty lhafp&lhafp] izse&csfy cks;h" (Pure love-wave rises, separation-endurance is the test) – defines devotion as internal emotional state. A wrong answer quoting only the prose or only the poem shows inability to synthesize across text sections – a board exam requirement.

## DIAGNOSTIC_QUESTION_4
Analyze the structural relationship between the prose introduction (third-person biography) and Poem 1 (first-person declaration). How does this shift in narrative voice *reinforce* the primary theme?

## DIAGNOSTIC_ANSWER_4
The prose establishes Kabir's *social* marginalization (historical fact: attacked by orthodoxy, lived in Kashi/Maghar), while the poem establishes his *spiritual* authority (first-person claim: "My capital is Ram"). The shift from objectified victim to empowered speaker structurally enacts the theme: the socially 'low' becomes the spiritually 'high.' A wrong answer discussing only content ('both talk about Kabir') ignores form-function analysis required for 'Analyze' level.

## DIAGNOSTIC_QUESTION_5
Evaluate this student claim: "Kabir's message is simply 'caste is bad'." Defend or refute using textual evidence from the chapter.

## DIAGNOSTIC_ANSWER_5
Refute. The text shows Kabir's message is *positive* (what *is* the path: *prem*, *bhagat*, *Ram*) not merely *negative* (what is not). Prose: "ehjk dh dfork dk iz/ku xq.k lknxh vkSj ljyrk gS" (essence is simplicity and directness). Poem: "nfèk efFk ?k`r dkf<+ fy;ks] Mkfj n;h Nks;h" (Heart's true love is the only offering). Reducing to 'anti-caste' ignores the constructive *Nirguna* theology central to Class 11 syllabus. A wrong agreement reveals reductive reading missing the philosophical depth.

## DIAGNOSTIC_QUESTION_6
Create a two-line *doha* in Kabir's style (simple Hindi, rhyming couplet) that encapsulates the primary theme of this chapter for a modern Class 11 student struggling with peer pressure.

## DIAGNOSTIC_ANSWER_6
Example: "Logon ki baat na maniyo, apna mann hi jaan / Andar Ram base hai, pehchano apni shaan." (Don't mind people's talk, know your own mind / Ram resides within, recognize your own dignity). A poor answer uses complex Sanskritized vocabulary or focuses only on caste, failing to adapt Kabir's *simple, direct, internal-focus* style to a contemporary context – showing lack of thematic internalization.

## COMMON_MISCONCEPTION
Students conflate 'theme' with 'moral lesson' or 'social issue.' They write: "The theme is caste discrimination" or "The message is we should not discriminate." This error arises because Class 10 Social Science trains them to spot 'social evils,' but Class 11 Hindi requires identifying the *philosophical framework* (Nirguna Bhakti) that *generates* the social critique. They miss that Kabir's attack on caste is a *consequence* of his theology (God is inside everyone), not the core theme itself.

## ON_FAILURE
1. **Re-anchor**: Ask student to complete this sentence frame: "Kabir argues that because ______ (theological claim: God is formless/inside all), therefore ______ (social claim: caste/rituals are irrelevant)." 2. **Color-code**: Give the prose intro and poem; use two highlighters: Yellow for 'Social Reality words' (julaha, pandit, mazhab), Green for 'Spiritual Reality words' (Ram, prem, bhagat, gyan). 3. **Synthesize**: Student writes one paragraph: "The Green words *resolve* the tension created by the Yellow words by..." 4. **Terminology Drill**: Practice writing "Nirguna Bhakti" and "Prem-marg" in three sentences until fluent.

## BUILDS_ON
Character Analysis: Protagonist (c11_hin_ar_cbse_10_004) where Kabir's persona as a marginalized yet spiritually authoritative figure was established.

## LEADS_TO
Theme: Secondary Themes (c11_hin_ar_cbse_10_007) where students will explore subordinate threads like Guru-Shishya parampara, Hindu-Muslim unity, and the body-as-temple metaphor.

## PREREQUISITE_NODE_IDS
c11_hin_ar_cbse_10_001, c11_hin_ar_cbse_10_004, c11_hin_ar_cbse_10_005, c11_hin_ar_cbse_10_002

## PREREQUISITE_REASONS
c11_hin_ar_cbse_10_001: Provides essential historical context (Bhakti movement, Kabir's persecution) without which the theme's urgency is invisible.
c11_hin_ar_cbse_10_004: Establishes Kabir's character as the vehicle of the theme – his 'low' birth and 'high' realization are the theme's dialectic.
c11_hin_ar_cbse_10_005: Supporting characters (Pandits, Mullahs, disciples) represent the orthodox forces the theme opposes; their analysis sets up the conflict.
c11_hin_ar_cbse_10_002: Plot and narrative structure in poetry refers to the organized sequence of events, thought... की समझ आवश्यक है, क्योंकि यह नोड (The primary theme is the central, unifying idea that the author explores throughout the te...) इसी आधार पर आगे बढ़ता है।  

## FORWARD_NODE_IDS
c11_hin_ar_cbse_10_007, c11_hin_ar_cbse_10_008, c11_hin_ar_cbse_10_013, c11_hin_ar_cbse_10_009, c11_hin_ar_cbse_10_014, c11_hin_ar_cbse_10_015, c12_hin_a_cbse_10_006, c12_hin_ar_cbse_10_006, c12_hin_ar_cbse_12_006

## FORWARD_REASONS
c11_hin_ar_cbse_10_007: Primary theme mastery is prerequisite to distinguishing secondary themes (e.g., Guru importance) as supportive rather than central.
c11_hin_ar_cbse_10_008: Imagery/metaphor analysis (e.g., 'weaving', 'market') requires knowing the theme they serve (e.g., weaving = life's karma).
c11_hin_ar_cbse_10_013: Critical interpretation demands a firm thematic anchor to evaluate alternate readings (e.g., Marxist vs. Bhakti readings).
c11_hin_ar_cbse_10_009: Establishes the central theme (inner love vs outer show) that all irony and symbolism in this chapter serve — without this, devices become ornamental, not functional.  
c11_hin_ar_cbse_10_014: Primary theme (nirgun-sagun bhakti synthesis) is the "Link" target for every PEEL paragraph.  
c11_hin_ar_cbse_10_015: Primary theme (Nirguna Bhakti/social equality) is the central axis of any discussion.  
c12_hin_a_cbse_10_006: Class 11 theme-analysis practice (same node type) gives the methodological foundation — identifying theme from textual evidence.  
c12_hin_ar_cbse_10_006: Prior exposure to theme identification in Hindi prose gives the terminological and analytical foundation.  
c12_hin_ar_cbse_12_006: Vocabulary for thematic discussion.  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
none

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_10_004 -> c11_hin_ar_cbse_10_006 -> c11_hin_ar_cbse_10_007

## THIS_FORMULA
N/A - conceptual

## FORMULA_VARIABLES
N/A

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
analytical

## CROSS_SUBJECT
c11_history_bhakti_movement | The primary theme (Nirguna Bhakti transcending caste/ritual) is the literary manifestation of the 15th-century Nirguna Bhakti movement studied in History; Kabir is a key figure in both.
c11_sociology_caste_system | The theme's social message directly critiques the *varna-vyavastha* and *jati* hierarchy analyzed in Sociology; Kabir's 'julaha' identity makes the sociological abstract concrete.

## PREREQ_CONCEPT
Character Analysis of Kabir as a figure embodying the tension between social marginalization and spiritual authority (c11_hin_ar_cbse_10_004).

## PREREQ_BEFORE
Student must be able to state: "Kabir was a low-caste weaver who challenged high-caste religious authorities through poems asserting direct access to God."

## PREREQ_STUCK
Review the 'Character Analysis: Protagonist' node (c11_hin_ar_cbse_10_004) focusing on the 'Kabir's Social Position vs. Spiritual Stature' comparison table.

## WORKED_EXAMPLE_1
PROBLEM: Using the PEEL structure, write a board-exam style answer (80-100 words) to: "How does the prose introduction prepare the reader for the primary theme expressed in Poem 1?"
STEPS:
- Step 1: Identify the core demand – 'prose prepares for poem's theme' requires linking biography to theology.
- Step 2: Select Point: The prose establishes Kabir's *social exclusion* as the necessary backdrop for his *spiritual inclusion* message.
- Step 3: Select Evidence (Prose): "fpÙkkSM+ jkt?kjkus esa vusd d\"V mBkus osQ ckn ehjk okil esM+rk vk xb±A" (After many attacks in royal court, Kabir fled) AND "os Ñ".k dks gh viuk vkjkè; vkSj ifr ekurh jghaA" (Made devotion his occupation/family).
- Step 4: Select Evidence (Poem): "esjs rks fxjèkj xksiky] nwljks u dksbZ" (My capital is Ram alone) – connects 'fleeing court' to 'rejecting worldly capital'.
- Step 5: Explain Link: The prose shows *why* Kabir rejects external power (he was victimized by it); the poem shows *what* he replaces it with (internal Ram). This cause-effect is the theme.
- Step 6: Concluding Link sentence: Thus, the biography is not context but the *proof* of the theme's lived truth.
REASONING: This models the 'Text-to-Text Synthesis' skill (prose + poem) mandated in Class 11 board questions. Steps 3-4 enforce evidence pairing; Step 5 demands analytical 'Explain' not narrative 'Describe'.
ANSWER: The prose introduction frames Kabir's persecution by orthodox authorities (Pandits/Mullahs) and royal courts as the crucible that forged his theology. Forced to flee Kashi after debates, he made "devotion his occupation and family" (prose). This biographical trauma directly prepares the poem's defiant declaration: "My capital is Ram alone, I have no other" (Poem 1). The prose shows the *failure* of external power/ritual to protect him; the poem offers the *alternative* – internal love (prem) as invincible capital. The theme 'Nirguna Bhakti transcends social hierarchy' is thus not abstract philosophy but survival strategy validated by life.

## WORKED_EXAMPLE_2
PROBLEM: A student writes: "The theme is Kabir's love for God." Diagnose the error and guide them to a Class 11 level thematic statement using the 'Abstraction Ladder' technique.
STEPS:
- Step 1: Diagnose – "Love for God" is Level 1 (Subject/Topic), not Theme. It's true but trivial; applies to Mira, Surdas, Tulsidas too.
- Step 2: Apply Abstraction Ladder Rung 1 (Add Conflict): "Kabir's love for God *despite* being low caste." Better, but still plot-summary.
- Step 3: Apply Rung 2 (Add Structural Opposition): "Kabir's love for God *rejects* the caste/ritual system that excludes him." Now we have tension.
- Step 4: Apply Rung 3 (Extract Universal Principle): "Authentic divine connection (Nirguna Bhakti) is internally generated through love (prem) and requires/validates no external mediator (caste, ritual, scripture)." This is the theme.
- Step 5: Verify against text: Does prose support "no external mediator"? Yes ("O;FkZ osQ dk;ks± esa O;Lr yksxksa osQ izfr nq[k izdV fd;k"). Does poem support "internally generated"? Yes ("nfèk efFk ?k`r dkf<+ fy;ks").
REASONING: The Abstraction Ladder (Topic -> Conflict -> Opposition -> Universal Principle) is a reproducible cognitive tool for moving from Class 10 'moral of story' to Class 11 'thematic statement'. Each rung adds analytical depth required by board marking schemes.
ANSWER: Corrected Thematic Statement: "The primary theme is the supremacy of *Nirguna Bhakti* – an internal, egalitarian path of love (*prem*) and surrender to the Formless Divine (*Ram*) that inherently dismantles external hierarchies of caste (*varna*), ritual (*karmakand*), and scriptural authority (*pandit/mullah*) by locating the Divine within the marginalized self."

## WORKED_EXAMPLE_3
PROBLEM: Compare the 'Primary Theme' of this Kabir chapter with the 'Primary Theme' of the previous chapter (Meera Bai, Chapter 9) in a comparative analysis paragraph (100 words). Focus on the *difference in theological strategy* despite shared 'Bhakti' label.
STEPS:
- Step 1: Recall Chapter 9 (Meera) primary theme: *Saguna Bhakti* – intense personal devotion to a *form* (Krishna) defying social norms (royal family, widowhood) through *virah* (separation) and *prem*.
- Step 2: Recall Chapter 10 (Kabir) primary theme (from Worked Example 2): *Nirguna Bhakti* – devotion to *formless* Ram, defying caste/ritual through *gyan-prem* synthesis and social equality.
- Step 3: Identify Comparative Axis: 'Form vs. Formless' (Saguna vs. Nirguna) and 'Social Base' (Royal woman vs. Low-caste man).
- Step 4: Draft Point: Both use *prem* to challenge patriarchy/orthodoxy, but Meera *embraces* divine form (Krishna's image/flute) while Kabir *rejects* all forms (idols, temples, scriptures).
- Step 5: Draft Evidence: Meera: "Giridhar Gopal" (personal deity); Kabir: "Nirgun Ram" (attribute-less).
- Step 6: Synthesize: Meera's theme = 'Exclusive love for Personal God transcends social duty'; Kabir's theme = 'Inclusive knowledge-love for Formless God transcends social identity.'
REASONING: This builds the 'Inter-textual Analysis' competency (c11_hin_ar_cbse_10_013) by forcing precise theological differentiation (Saguna/Nirguna) – a favorite board exam comparative question. Steps 1-2 ensure factual base; Steps 3-6 build analytical structure.
ANSWER: While both Meera (Ch.9) and Kabir (Ch.10) wield *prem* (love) as a subversive force against orthodoxy, their theological strategies diverge fundamentally. Meera's *Saguna Bhakti* centers on exclusive, eroticized devotion to a personal form (Krishna/Giridhar), using *virah* to dissolve her royal identity. Kabir's *Nirguna Bhakti* rejects all forms, idols, and scriptures ("Pothi padh padh jag mua"), locating the formless *Ram* within the low-caste self ("Julaha"). Meera's theme asserts the *individual's right to choose her divine lover* against patriarchal duty; Kabir's theme asserts the *universal accessibility of the Divine* against caste hierarchy. The former personalizes God; the latter universalizes the self.

## COMPETENCY_QUESTION_1
QUESTION: "Kabir's poetry is often called 'Upside-down language' (Ulta Bani) because it inverts social hierarchies. Using the primary theme of this chapter, explain how the *very structure* of Poem 1 (opening declaration -> rejection of rituals -> definition of true devotion) performs this inversion. Write a structured response (Point, Evidence, Explanation, Link)."
COMPETENCY: Textual Structure Analysis / Thematic Argumentation
STEPS:
- Step 1: State Point: The poem's tripartite structure enacts the thematic inversion: Social Low (Stanza 1) -> Spiritual High (Stanza 2) -> New Hierarchy (Stanza 3).
- Step 2: Evidence Stanza 1: "esjs rks fxjèkj xksiky" – claims highest spiritual capital (Ram) from lowest social position (implied julaha).
- Step 3: Evidence Stanza 2: "valqou ty lhafp&lhafp" – redefines purity (valqou) as love-wave, not ritual bath.
- Step 4: Evidence Stanza 3: "nfèk efFk ?k`r dkf<+ fy;ks" – establishes heart's truth as only valid currency, bankrupting priestly authority.
- Step 5: Link: This structural movement *is* the 'Ulta Bani' – the poem doesn't just describe inversion, it performs it linguistically.
ANSWER: The poem's three-stanza architecture *performs* the 'Ulta Bani' inversion. Stanza 1 opens with the socially marginalized speaker ("julaha" implied) declaring the ultimate spiritual asset: "My capital is Ram alone" – placing the 'low' at the 'high' summit. Stanza 2 inverts ritual purity: "Pure love-wave rises" replaces Ganga-snan; "separation-endurance" replaces sacrificial fire. Stanza 3 establishes the new economy: "Heart's true love is the offering" – the 'neech' heart outranks the Brahmin's mantra. The structure moves from *Declaration* (I have Ram) to *Redefinition* (Love is purity) to *Legislation* (Heart-truth is law), structurally mirroring the theme: the excluded become the legislators of true spirituality.
DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: "A Class 11 student argues: 'Kabir's message in this chapter is irrelevant today because caste is legally abolished and we don't believe in rituals.' Critique this argument using the primary theme's *universal philosophical core* (beyond historical caste/ritual). Your answer must define the core, identify the modern equivalent of 'external mediators,' and explain why the theme remains urgent."
COMPETENCY: Critical Evaluation / Contemporary Relevance / Philosophical Abstraction
STEPS:
- Step 1: Define Core: The theme is not 'anti-caste' per se, but 'Anti-Mediation' – the insistence that Ultimate Reality/Truth is directly accessible *without* any external authority, institution, or performance.
- Step 2: Modern Mediators: Identify today's 'Pandits/Mullahs' – algorithmic feeds defining identity, credentialism defining worth, performative activism replacing inner work, consumerist spirituality (buying 'wellness').
- Step 3: Modern 'Caste': Internalized hierarchies – imposter syndrome, status anxiety, outsourcing self-worth to LinkedIn/Instagram metrics.
- Step 4: Kabir's Relevance: "nfèk efFk ?k`r dkf<+ fy;ks" (Heart's true love/offering) is the antidote to external validation seeking. The theme asks: "Where is your capital invested?" – in followers/likes/degrees (external) or in self-knowledge/integrity (internal Ram)?
- Step 5: Conclusion: The theme is urgent *because* mediation has intensified digitally; Kabir's 'direct access' is radical digital minimalism for the soul.
ANSWER: The student confuses the theme's *historical garment* (15th-century caste/ritual) with its *philosophical skeleton* (Anti-Mediation). The primary theme is: **Truth/God/Self is immediately accessible; any structure claiming to gatekeep it is false.** Today's 'Pandits' are algorithms curating our reality; 'rituals' are performative productivity/wellness routines; 'caste' is the hierarchy of digital influence. Kabir's "My capital is Ram alone" translates to: "My worth is my intrinsic integrity, not my LinkedIn badge." The poem's "Heart's true love is the offering" challenges the outsourcing of meaning to influencers/gurus/apps. The theme is not 'caste is bad' but 'Mediation is bondage' – making it *more* relevant in an algorithmically mediated age where direct experience is rarest.
DIFFICULTY: hard