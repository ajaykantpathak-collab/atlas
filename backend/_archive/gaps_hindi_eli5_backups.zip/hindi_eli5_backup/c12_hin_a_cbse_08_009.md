## DEFINITION
Irony is a literary device where the intended meaning of words or events is opposite to their literal or expected meaning, creating a contrast between appearance and reality. Symbolism is the use of concrete objects, images, or actions to represent abstract ideas, qualities, or states of mind, allowing the poet to convey deeper spiritual or philosophical meanings beyond the surface narrative.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student can independently identify specific instances of verbal, situational, and dramatic irony in Kabir's poems, explain how symbols like 'weaver's loom', 'dead village', or 'water bubble' function as extended metaphors for spiritual truths, and write a structured board-style answer linking these devices to the poet's critique of ritualism and advocacy for inner realization.

## SCOPE_BOUNDARY
This node covers the identification, classification, and thematic analysis of irony and symbolism specifically in the three Kabir poems prescribed in Class 12 Antra Chapter 8. It does not cover other literary devices (imagery, metaphor, alliteration) which are addressed in node c12_hin_a_cbse_08_008, nor does it cover the biography of Kabir or the historical Bhakti movement context (covered in node c12_hin_a_cbse_08_001).

## WALKTHROUGH
Imagine you are reading a WhatsApp forward that says "Great job breaking the vase, now we have modern art!" — you instantly recognize the speaker means the opposite: that is verbal irony. Now, open your textbook to the first poem (stanza 1). Ask yourself: "Does the poet really mean the weaver is weaving cloth, or is the loom a symbol for something else?" Start by underlining every concrete noun (loom, thread, shuttle, village, water, bubble). For each, ask: "What abstract idea does this represent in Kabir's philosophy?" Then look for statements where the surface meaning contradicts the poet's known teachings (e.g., praising the 'dead village' in poem 2). That contrast is irony. The key insight: Kabir uses irony to expose hypocrisy and symbolism to map the invisible spiritual journey onto visible, everyday objects — making the abstract tangible for the common person.

## DIAGNOSTIC_QUESTION_1
Define verbal irony and give one example from Poem 1 (stanza 1) where the literal meaning of a line contradicts the poet's intended spiritual message.

## DIAGNOSTIC_ANSWER_1
Verbal irony occurs when a speaker says one thing but means the opposite, often to criticize or mock. In Poem 1, the line "एकलफज हउ फिवक फ्चक जस एसफग ज्गयकस उ न टक" (The weaver weaves cloth, but the cloth does not cover the body) literally describes a failed weaver, but ironically means the ritualistic person performs rites (weaving) that fail to cover the soul's nakedness. A wrong answer that only identifies the literal weaving without the spiritual contradiction shows the student cannot move from textual detail to authorial intent — a critical board exam skill.

## DIAGNOSTIC_QUESTION_2
Explain in your own words why the 'dead village' (मुरदों का गांव) in Poem 2 is a symbol and not just a setting. What abstract concept does it represent?

## DIAGNOSTIC_ANSWER_2
The 'dead village' symbolizes a society spiritually dead due to empty rituals, caste pride, and absence of true devotion — it is not merely a physical backdrop. The symbol works because the villagers 'walk' and 'talk' but lack inner life (लगन), making them 'living dead'. A wrong answer describing it only as a creepy atmosphere or a literal ghost village reveals the student confuses setting with symbolism and misses Kabir's satirical target: orthodox communities that mimic religion without love.

## DIAGNOSTIC_QUESTION_3
Apply the concept of situational irony to Poem 3: The poem describes a water bubble (बुदबुदा) forming and bursting. What is the situation, what is the expected outcome for a bubble, and how does Kabir invert this expectation to deliver a spiritual truth?

## DIAGNOSTIC_ANSWER_3
Situation: A bubble forms on water. Expected outcome: It bursts and vanishes — a momentary, insignificant event. Kabir's inversion: He treats the bubble's brief life as a profound metaphor for human existence — the burst is not an end but a merger with the infinite (water). The irony: What looks like destruction is actually liberation. A wrong answer that only describes the bubble's physics without the spiritual reversal shows inability to apply the device to the poem's central theme.

## DIAGNOSTIC_QUESTION_4
Analyze how the symbol of the 'weaver's shuttle' (सारथी/धुरी) in Poem 1 functions differently from the 'water bubble' in Poem 3. Compare their roles in conveying Kabir's philosophy of effort vs. surrender.

## DIAGNOSTIC_ANSWER_4
The shuttle symbolizes *active, disciplined effort* (साधना) — the weaver must skillfully throw the shuttle to create the fabric of devotion; it represents the path of *karma-yoga* guided by the Guru. The bubble symbolizes *effortless impermanence and surrender* — it forms and bursts by nature, representing *sahaja-yoga* where realization happens when ego dissolves. The shuttle demands "विटल" (alertness); the bubble teaches "फ्नु" (merger). A weak answer listing both as 'symbols of life' without contrasting agency vs. passivity misses the nuanced dialectic in Kabir's teachings.

## DIAGNOSTIC_QUESTION_5
Evaluate the effectiveness of Kabir's use of dramatic irony in Poem 2, where the poet-narrator knows the village is spiritually dead but the villagers themselves do not. Does this device strengthen or weaken the poem's reformist message? Justify.

## DIAGNOSTIC_ANSWER_5
It strengthens the message profoundly. Dramatic irony positions the reader alongside the enlightened poet, creating moral urgency: we see the villagers' delusion (they think they are alive/religious) while they cannot. This mirrors Kabir's real-life role as a social critic awakening the masses. It does not weaken because the tone is compassionate (लगन लगी है), not mocking — the irony invites self-recognition, not ridicule. A wrong answer claiming it 'confuses the reader' or 'is just a trick' fails to evaluate the device's rhetorical purpose in a Bhakti context.

## DIAGNOSTIC_QUESTION_6
Create a new 4-line stanza in Hindi (or Hinglish) that uses *both* a central symbol (like a lamp, seed, or mirror) and verbal irony to convey a Kabir-like message about inner truth vs. outer show. Write the stanza and then explain your symbol and the ironic twist.

## DIAGNOSTIC_ANSWER_6
Stanza:  
"दीपक जलता मंदिर में, अंधेरा मन के अंदर  
बाहर पूजा थाल सजाए, भीतर बैठा बंदर"  
Symbol: The lamp (दीपक) = outer ritual; Darkness (अंधेरा) = inner ignorance; Monkey (बंदर) = restless, imitative mind.  
Irony: The verbal irony lies in "बाहर पूजा थाल सजाए" (adorned the worship plate outside) — the speaker *appears* to describe piety, but the next line reveals the reality: the worshipper's mind is a monkey. The contrast exposes hypocrisy. A poor answer would use a symbol without irony (e.g., just describing a lamp lighting darkness) or irony without a sustained symbol (e.g., a sarcastic one-liner), showing inability to integrate the two devices as Kabir does.

## COMMON_MISCONCEPTION
Students often confuse *symbolism* with *imagery*: they identify a concrete object (e.g., 'loom') and call it a symbol simply because it is described vividly. They miss that a symbol *must* carry a consistent, abstract meaning *beyond* its physical properties throughout the poem (the loom = the Guru-guided spiritual practice, not just a machine). Similarly, they label any unexpected event as 'irony' without distinguishing verbal (words), situational (events), or dramatic (knowledge gap) — leading to vague answers like "there is irony in the poem" without textual evidence. This happens because Class 11 teaching often treats devices as labels to spot, not as structural choices with thematic consequences.

## ON_FAILURE
If a student cannot distinguish symbol from image, give them two columns: Column A = "Physical details in Poem 1 (loom, thread, shuttle, cloth)" ; Column B = "Abstract meanings (Guru's guidance, devotee's effort, divine grace, liberated soul)". Ask them to draw arrows mapping each physical detail to its abstract counterpart — if a detail has no abstract partner, it's imagery, not symbol. For irony confusion, give three index cards labeled "Verbal", "Situational", "Dramatic" and three quote cards from the poems; have them match and justify each match aloud. Re-diagnose with Diagnostic Question 3 and 4.

## BUILDS_ON
Builds on the ability to distinguish literal vs. figurative language (Class 11 Literary Devices: Imagery and Metaphor) and the thematic understanding of Kabir's critique of ritualism (Theme nodes 006, 007).

## LEADS_TO
Enables critical interpretation of the poet's voice and philosophy (Critical Thinking: Analysis and Interpretation, node 013) and structured analytical writing (Writing Skills, node 014).

## PREREQUISITE_NODE_IDS
c12_hin_a_cbse_08_001, c12_hin_a_cbse_08_002, c12_hin_a_cbse_08_006, c12_hin_a_cbse_08_007, c12_hin_a_cbse_08_008, c11_hin_ar_cbse_08_009, c11_hin_ar_cbse_08_008, c12_hin_a_cbse_08_003, c12_hin_a_cbse_08_005

## PREREQUISITE_REASONS
c12_hin_a_cbse_08_001: Provides historical context of Kabir and Bhakti movement essential for understanding why he uses irony against orthodoxy.
c12_hin_a_cbse_08_002: Narrative structure of each poem (stanza progression) helps locate where symbols are introduced and developed.
c12_hin_a_cbse_08_006: Primary theme (inner realization over outer ritual) is the semantic target of every symbol and ironic statement.
c12_hin_a_cbse_08_007: Secondary themes (Guru's role, impermanence, sahaja) clarify which abstract ideas specific symbols represent.
c12_hin_a_cbse_08_008: Imagery and Metaphor node establishes the foundation of figurative language; symbolism is a specialized, sustained metaphor.
c11_hin_ar_cbse_08_009: Class 11 introduction to irony and symbolism in a different text provides the definitional baseline.
c11_hin_ar_cbse_08_008: Class 11 imagery/metaphor work builds the habit of moving from concrete to abstract.
c12_hin_a_cbse_08_003: Atmosphere of viraha enables recognition of irony (rain brings union but here brings separation) and symbolism (clouds as failed messengers)  
c12_hin_a_cbse_08_005: Irony/symbolism (e.g., thorn as grace, door as barrier) is carried by supporting characters.  

## FORWARD_NODE_IDS
c12_hin_a_cbse_08_010, c12_hin_a_cbse_08_011, c12_hin_a_cbse_08_012, c12_hin_a_cbse_08_013, c12_hin_a_cbse_08_014, c12_hin_a_cbse_08_015
## FORWARD_REASONS
c12_hin_a_cbse_08_010: Vocabulary work requires understanding symbolic words (e.g., 'लगन', 'सारथी', 'बुदबुदा') in their figurative sense.
c12_hin_a_cbse_08_011: Grammar analysis of verb forms in ironic statements (e.g., subjunctive vs. indicative) deepens device appreciation.
c12_hin_a_cbse_08_012: Inferential comprehension questions directly test ability to decode symbols and irony.
c12_hin_a_cbse_08_013: Critical thinking tasks demand synthesis of devices into thematic arguments.
c12_hin_a_cbse_08_014: Writing skills require using device analysis as evidence in structured answers.
c12_hin_a_cbse_08_015: Speaking/listening discussions on "Is Kabir relevant today?" need device-based textual support.

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
N/A

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_08_009 -> c12_hin_a_cbse_08_009 -> c12_hin_a_cbse_08_013

## THIS_FORMULA
N/A - conceptual

## FORMULA_VARIABLES
N/A

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
analytical

## CROSS_SUBJECT
N/A | Kabir's irony and symbolism reflect the Nirguna Bhakti tradition's challenge to ritualistic orthodoxy and caste hierarchy — a core theme in Medieval Indian History.
 N/A | Kabir's symbolic language of unity (weaver's cloth = all threads one fabric) and irony against religious hypocrisy prefigure constitutional ideals of fraternity and equality.
## PREREQ_CONCEPT
The student must understand that in Bhakti poetry, everyday objects are deliberately elevated to spiritual signifiers — a convention distinct from decorative metaphor.

## PREREQ_BEFORE
Student must be able to paraphrase each poem's literal narrative in simple Hindi before attempting device analysis.

## PREREQ_STUCK
If stuck, revisit the 'Symbol Mapping' exercise in ON_FAILURE and re-read the Theme nodes (006, 007) to anchor each symbol to a specific Kabirian idea.

## WORKED_EXAMPLE_1
PROBLEM: Analyze the symbol of 'लगन' (deep longing/absorption) in Poem 2. Show how it transforms from a noun denoting an emotion into a symbol of the *only* valid spiritual path in Kabir's system.

STEPS:
- Step 1: Locate every occurrence of 'लगन' and related words (लगी, लगन) in Poem 2. Note: It appears in the opening line "लगन लगी है" and implicitly in "उ;ु न फ्रिजफिर ग्सी" (no realization/arrival).
- Step 2: Identify the literal meaning in each context: 'लगन लगी है' = a deep attachment has taken hold; 'उ;ु न फ्रिजफिर' = the destination (God) has not been reached/realized.
- Step 3: Contrast with what the villagers *have*: they have rituals, chants, caste pride, but the poem says "लगन लगी है" is absent — "उ;ु न फ्रिजफिर ग्सी" (they haven't reached). This contrast makes 'लगन' the *differentiating symbol* between true and false religiosity.
- Step 4: Trace the symbol's extension: The poet says "मैं तो जन्म-जन्म से अपने सतगुरु का रूप ही देखती रही हूँ" (I have seen only my Satguru's form birth after birth) — here 'लगन' symbolizes *exclusive, unwavering focus on the Guru*, not just any emotion.
- Step 5: Connect to theme: The symbol 'लगन' encapsulates the chapter's primary theme (node 006) — inner realization via Guru's grace — and exposes the secondary theme of ritual futility (node 007). The symbol is not decorative; it is the *criterion of authenticity*.

REASONING: This step-by-step moves from textual evidence (step 1) to literal meaning (2), to contrastive function (3), to thematic expansion (4), to thesis-level synthesis (5) — mirroring the 4-mark board answer structure: Point, Evidence, Explanation, Link.

ANSWER: In Poem 2, 'लगन' is the central symbol representing *exclusive, Guru-centric devotion* that alone leads to realization. Its absence in the 'dead village' (despite their rituals) creates the poem's tragic irony: the villagers are spiritually dead because they lack this one symbol. The symbol works by being both the *means* (the longing) and the *proof* (of true path) — a sophisticated symbolic density typical of Kabir.

## WORKED_EXAMPLE_2
PROBLEM: Identify and classify the irony in the line from Poem 1: "एक्सज युक्सु एउ ड्ब्लु ओसकफी" (The weaver weaves, but the cloth does not cover the body). Explain how this verbal irony serves the poet's satirical purpose.

STEPS:
- Step 1: Parse the literal sentence: Subject = weaver (जुलाहा/साधक), Action = weaves (बुनता है), Object = cloth (कपड़ा), Outcome = cloth does not cover body (तन नहीं ढकता). This is a paradox: weaving's purpose is covering.
- Step 2: Identify the speaker's stance: The poet *knows* weaving *should* cover; the failure is intentional in the description. This is verbal irony — saying "he weaves" (positive action) but negating its *telos* (purpose).
- Step 3: Map to spiritual allegory using Theme nodes: Weaver = ritualistic practitioner; Weaving = performing rites (puja, fasts, pilgrimages); Cloth = merit/karma accumulated; Body = soul/self. The irony: Rituals are performed but the soul remains 'naked' (unprotected, unrealized).
- Step 4: Determine satirical target: Not the weaver's skill, but the *misplaced faith in ritual efficacy*. The irony mocks the *expectation* that mechanical rites yield spiritual fruit.
- Step 5: Evaluate effect on reader: The reader (likely familiar with weaving) feels the absurdity — why weave if it doesn't cover? This cognitive dissonance forces the question: "What *does* cover the soul?" Answer in next lines: "फिवर फिउक फ्कुक जस एसफग ज्गयकस उ न टक" — only the Guru's word/guidance.

REASONING: Verbal irony here is not mere wordplay; it is a *theological argument* compressed into a paradox. The steps ensure the student moves from linguistic form to doctrinal content — essential for 6-mark 'analyze the device' questions.

ANSWER: The line employs **verbal irony**: the literal statement "weaver weaves" affirms ritual action, while "cloth does not cover body" denies its soteriological efficacy. This exposes the futility of *kriya-kanda* (ritual action) without *jnana/bhakti* (inner realization). The irony is sustained: the poem's next stanza resolves it by introducing the true 'weaver' (Guru) whose 'cloth' (teaching) *does* cover.

## WORKED_EXAMPLE_3
PROBLEM: Compare the symbolic systems of Poem 1 (weaving) and Poem 3 (water bubble). Write a 150-word analytical paragraph showing how Kabir uses two distinct symbolic frameworks to address the same core tension: human effort vs. divine grace.

STEPS:
- Step 1: Define the core tension from Theme nodes: *Purushartha* (effort) vs. *Prasada* (grace). Kabir navigates this via *Guru-kripa* (Guru's grace enabling effort).
- Step 2: Analyze Poem 1's symbolic system: Weaving = *effortful sadhana* guided by Guru (शuttle = Guru's word, thread = devotion, cloth = realized state). Key verb: "बुनता" (active, continuous). Symbol implies *path* (मर्ग).
- Step 3: Analyze Poem 3's symbolic system: Bubble = *effortless arising and merging* in the Absolute. Key verb: "बनता-बिगड़ता" (automatic, natural). Symbol implies *fruit* (फल) / *sahaja* state.
- Step 4: Identify the irony linking them: In Poem 1, the *false* weaver's effort fails (irony of wasted labor); in Poem 3, the bubble's *non-effort* succeeds (irony of effortless success). Both ironies point to the *same* truth: human agency is real but insufficient without divine alignment.
- Step 5: Synthesize: The two symbols are not contradictory but *dialectical* — weaving is the *discipline* for the seeker; bubble is the *vision* of the realized. Kabir holds both: "साधो, सहज समाधि भली" (Sahaja samadhi is good) but also "गुरु बिन ज्ञान न उपजै" (No knowledge without Guru).
- Step 6: Draft paragraph using PEEL structure: Point (dual symbols resolve effort/grace), Evidence (specific symbols + irony), Explanation (dialectical relation), Link (Kabir's integrated path).

REASONING: This multi-step comparison requires holding two symbolic systems simultaneously, mapping each to a philosophical pole, and revealing their synthesis — a high-order analytical skill tested in 6-mark board questions and CUET critical thinking items.

ANSWER: Kabir deploys the **weaver's loom** (Poem 1) and the **water bubble** (Poem 3) as complementary symbolic frameworks resolving the effort-grace dialectic. The loom symbolizes *disciplined sadhana*: the shuttle (Guru's word) must be thrown with "विटल" (alertness) to weave the cloth of realization — effort is indispensable but *directed* effort. Its verbal irony (weaving that doesn't cover) satirizes *undirected* ritual labor. Conversely, the bubble symbolizes *sahaja*: it forms and bursts without volition, merging into water — grace is effortless, *prasada*. Its situational irony (bursting = liberation) inverts worldly logic. Together, they articulate Kabir's non-dual pedagogy: the seeker *weaves* (effort) until the fabric dissolves into the *bubble's* merger (grace). The symbols are sequential stages on one path, not rival doctrines — a nuanced reading essential for full marks.

## COMPETENCY_QUESTION_1
QUESTION: A Class 12 student writes in a board exam answer: "Kabir uses the symbol of the loom to show that life is like weaving cloth." The examiner awards 1 out of 3 marks. Using your knowledge of symbolism vs. imagery and Kabir's specific theology, explain *why* this answer is insufficient and rewrite it to earn full marks.

COMPETENCY: Critical evaluation of peer response / Exam answer improvement

STEPS:
- Step 1: Identify the flaw: The student treats the loom as a *simile* ("life is *like* weaving") — a fleeting comparison — rather than a *sustained symbol* where each part (shuttle, thread, weaver, cloth) maps to a specific spiritual reality (Guru's word, devotion, seeker, realization).
- Step 2: Note the missing theological precision: Kabir's loom is not about 'life' generally; it is about *the specific path of Guru-mukh sadhana* versus *manmukh ritualism*. The symbol encodes a sectarian doctrinal claim.
- Step 3: Note the missing device interaction: The answer ignores the *verbal irony* that the false weaver's cloth *fails* — the symbol's power lies in its *failure* for the ritualist and *success* for the devotee.
- Step 4: Rewrite using PEEL: Point (Loom = symbol of Guru-guided sadhana), Evidence (Stanza 1: "एकलफज हउ फिवक..."), Explanation (Each component maps to a spiritual element; irony exposes fake weaving), Link (Thus the symbol structures the poem's central argument).

ANSWER: The original answer reduces a complex, multi-mapped symbol to a simple simile, losing Kabir's doctrinal specificity and the irony that drives his critique. Improved answer: "Kabir employs the **loom as an extended symbol** of the *Guru-mukh sadhana*: the weaver is the seeker, the shuttle is the Guru's *shabda*, the thread is *prem-bhakti*, and the cloth is *atma-jnana*. Crucially, the poem's **verbal irony** — 'the weaver weaves but the cloth does not cover the body' — reveals that *ritualistic* weaving (manmukh) fails this mapping. Only when the Guru weaves does the cloth cover the soul. Thus the symbol is not a decorative comparison but the poem's structural argument for initiated devotion over mechanical rites." (148 words)

DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: In a CUET-style case-based question, you are given a new 4-line Kabir couplet (not in textbook):  
"चलती चक्की देख के, दिया कबीरा रोय  
दो पाटन के बीच में, साबुत बचा न कोय"  
(Seeing the moving millstone, Kabir weeps / Between the two stones, nothing remains whole.)  
Identify **one symbol** and **one irony** in this couplet. Explain how they work *together* to convey the poet's view of *samsara* (worldly existence). Your answer must reference the symbolic logic established in the textbook poems (Poems 1-3).

STEPS:
- Step 1: Identify the central symbol: The **millstone (चक्की/दो पाटन)**. Map it using textbook logic: In Poem 1, the loom's two beams hold the warp — here, the two stones are *time (kaal)* and *karma* (or *maya* and *death*), the inescapable dualities that crush the individual.
- Step 2: Identify the irony: **Situational irony** — the millstone's *function* is to grind grain into flour (nourishment), but here it grinds *beings* into dust (destruction). The expectation (food production) is inverted into reality (annihilation).
- Step 3: Connect to textbook Poem 3: The water bubble also depicts *impermanence under dual forces* (air/water). The bubble's 'bursting' = millstone's 'grinding'. Both symbolize *samsara* as a process of inevitable dissolution.
- Step 4: Connect to textbook Poem 2: The 'dead village' lacks 'लगन' — here, the 'whole grain' (साबुत) = the ego/self that *could* survive if it had 'लगन' (single-pointed devotion). The irony: only the *unsplit* (साबुत) escapes — but the millstone ensures N/A escape *unless* they transcend the duality (like the bubble merging).
- Step 5: Synthesize: Symbol (millstone = samsara's crushing mechanism) + Irony (nourisher becomes destroyer) = Kabir's vision of world as a *transformative trap* where only *surrender* (becoming flour/dust willingly) or *transcendence* (bubble merging) saves.

ANSWER: The **millstone (दो पाटन)** functions as a **symbol of samsara's dual crushing forces (time/karma, maya/death)** — directly extending the textbook's symbolic logic where concrete mechanisms (loom, bubble) represent spiritual processes. The **situational irony** lies in the millstone's perversion: designed to *produce flour* (sustain life), it *destroys wholeness* (साबुत बचा न कोय). This irony mirrors Poem 3's bubble: what seems destructive (bursting/grinding) is actually the *necessary dissolution* of the false self. In Poem 2, the 'dead villagers' lack 'लगन' — here, the 'साबुत' (whole/unsplit) grain represents the *ego-intact self* that *cannot* survive the millstone. The symbol and irony together declare: *Samsara is a mill that spares no ego; liberation lies in voluntary surrender (becoming flour) or Guru-guided transcendence (like the bubble merging)*. This reading applies the textbook's device-to-theme mapping to an unseen text — a key CUET competency.

DIFFICULTY: hard