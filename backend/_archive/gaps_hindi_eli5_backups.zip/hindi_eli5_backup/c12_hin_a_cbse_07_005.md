## DEFINITION
Character analysis of supporting characters involves identifying characters other than the protagonist, examining their traits, actions, and dialogue, and explaining how they illuminate the protagonist's personality, advance the plot, or reinforce the central theme of the literary work.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student can independently identify at least three supporting characters in the poem "ckjgeklk", cite specific textual evidence (stanza/line references) for each, and write a structured PEEL paragraph explaining how each character deepens the portrayal of the protagonist (ukf;dk) or develops the theme of viraha (separation).

## SCOPE_BOUNDARY
This node covers only the supporting characters in the poem "ckjgeklk" (Chapter 7, Antra Part 2). It does not cover the protagonist analysis (done in c12_hin_a_cbse_07_004), thematic analysis (later nodes), or characters from other chapters.

## WALKTHROUGH
Imagine you are a detective trying to understand a person who never speaks directly about her feelings — you would interview her friends, watch how others react to her, and note what messengers bring her. In "ckjgeklk", the woman (ukf;dk) barely speaks; her agony is revealed through the friend (sakhi) who describes her state, the bird (iou) that carries hope, and the night (ekl) that witnesses her vigil. Start by listing every named or implied character besides the woman. Then, for each, ask: What does this character do? What does it say? How does the woman respond? Finally, connect each observation to the central idea of longing. The key insight: supporting characters in lyric poetry are not "people" but dramatic voices that externalize the protagonist's inner world.

## DIAGNOSTIC_QUESTION_1
Name three supporting characters that appear in the poem "ckjgeklk" and give one line reference (stanza number) for each.

## DIAGNOSTIC_ANSWER_1
Correct answer: 1) Sakhi (friend) — speaks in Stanza 1 ("fi; lkSa dgsgq l¡nslM+k..."); 2) Iou (bird) — appears in Stanza 4 ("iQkxqu iou >¡dksjS cgkA"); 3) Ekl (night) — addressed as a presence in Stanza 3 ("ykxsm ek¡g ijS vc ikykA"). A wrong answer that lists only "the beloved" or "the poet" reveals the student cannot distinguish between the protagonist, the addressee, and true supporting voices that actively intervene in the poem.

## DIAGNOSTIC_QUESTION_2
Explain in your own words how the sakhi's speech in the first stanza functions differently from the protagonist's own voice (which is almost absent).

## DIAGNOSTIC_ANSWER_2
The sakhi acts as an external narrator who observes and reports the woman's physical and mental state ("ty jgh gS vkSj Hk¡ojs rFkk dkx osQ le{k viuh fLFkfr;ksa dk o.kZu djrs gq, uk;d dks lans'k Hkst jgh gSA"), creating dramatic irony because the audience knows more than the absent beloved. A wrong answer that says "the sakhi is the protagonist" shows confusion between the speaking voice and the suffering subject; the student has not grasped that the poem uses a witness-figure to objectify the protagonist's pain.

## DIAGNOSTIC_QUESTION_3
Using the PEEL structure, write a short paragraph (4-5 sentences) analyzing the role of the bird (iou) in Stanza 4. Your Point must be a clear claim about its function.

## DIAGNOSTIC_ANSWER_3
Model answer: Point — The bird serves as a fragile messenger of hope that intensifies the woman's anticipation. Evidence — In Stanza 4, the bird flies "cgkA" (swiftly) and the woman watches it "pk¡pfj tksjh" (waiting for its return). Explanation — Its speed contrasts with her stillness, and its uncertain return mirrors the uncertainty of her beloved's arrival. Link — Thus the bird externalizes the oscillation between hope and despair that defines viraha. A wrong answer that merely translates the stanza without a claim reveals the student cannot move from summary to analysis.

## DIAGNOSTIC_QUESTION_4
Compare the function of the night (ekl) in Stanza 3 with the function of the sakhi in Stanza 1. How does each "character" expand the spatial and emotional scope of the poem?

## DIAGNOSTIC_ANSWER_4
The sakhi provides a human, intimate witness at close range (inside the house), while the night expands the scene to the cosmic scale — "ykxsm ek¡g ijS vc ikykA" (the night has spread over the sky) — making the woman's solitude universal. A wrong answer that treats both as "just background" misses the structural movement from domestic interior to infinite exterior, which mirrors the protagonist's expanding grief.

## DIAGNOSTIC_QUESTION_5
Critique the following student statement: "The supporting characters in this poem are unimportant because the poem is really about the woman's feelings." Provide two textual reasons why this view is incorrect.

## DIAGNOSTIC_ANSWER_5
The statement is incorrect because: 1) Without the sakhi's report ("lks èkfu fcjgsa tfj eqbZ] rsfgd èkqvk¡ ge ykxA"), we would have no concrete image of the woman's condition; 2) The bird's flight ("iQkxqu iou >¡dksjS cgkA") creates the central tension of waiting — remove it, and the poem loses its dynamic of hope/deferral. A wrong answer that agrees with the student reveals a fundamental misunderstanding of lyric technique: in viraha poetry, the protagonist's interiority is ONLY accessible through external mirrors.

## DIAGNOSTIC_QUESTION_6
Create a two-stanza extension (in Hindi, using simple Braj/Avadhi flavor) where a new supporting character — the river (nadī) — speaks to the woman, reflecting her tears. Keep the rhyme scheme similar to the original (AA BB CC...).

## DIAGNOSTIC_ANSWER_6
A good response will: a) maintain the couplet-based rhyme; b) give the river a distinct voice (e.g., "maīṁ bahatī hūṁ, tū bahatī hai"); c) mirror the woman's sorrow without resolving it. A poor response that makes the river offer comfort or solve the separation violates the genre convention of viraha — the supporting character must deepen, not relieve, the longing.

## COMMON_MISCONCEPTION
Students believe "supporting character analysis" means writing a biography of each character (where they live, their family, etc.). In lyric poetry like "ckjgeklk", supporting figures (sakhi, iou, ekl) are not fleshed-out individuals but functional voices — the sakhi exists only to speak the woman's condition, the bird only to embody hope's flight. Students waste marks describing imaginary backstories instead of analyzing textual function. This error stems from importing novelistic character expectations into a 14-stanza poem where every word serves the rasa of viraha.

## ON_FAILURE
1. Re-read Stanza 1 and 4 aloud, underlining every verb attributed to the sakhi and the iou. 2. Complete this table: Character | Action Verb | Effect on Protagonist | Effect on Reader. 3. Revisit c11_hin_ar_cbse_07_005 (Class 11 Supporting Character Analysis) and redo its Worked Example 2. 4. Write one PEEL paragraph for the sakhi using the table. 5. Self-check: Does my paragraph quote a specific phrase? Does it explain the effect? If not, repeat step 4.

## BUILDS_ON
c12_hin_a_cbse_07_004 (Character Analysis: Protagonist) — you must first know the protagonist's core conflict before seeing how others reflect it.

## LEADS_TO
c12_hin_a_cbse_07_006 (Theme: Primary Theme and Message) — the supporting characters' collective function reveals the theme of viraha as cosmic and inescapable.

## PREREQUISITE_NODE_IDS
c12_hin_a_cbse_07_004, c12_hin_a_cbse_07_002, c11_hin_ar_cbse_07_005, c11_hin_ar_cbse_07_004, c12_hin_a_cbse_07_001

## PREREQUISITE_REASONS
c12_hin_a_cbse_07_004: Provides the protagonist's profile (ukf;dk's viraha) which is the reference point for all supporting character analysis.
c12_hin_a_cbse_07_002: Establishes the narrative structure (stanza progression) so you can locate where each supporting character enters.
c11_hin_ar_cbse_07_005: Class 11 foundation for the skill of distinguishing protagonist vs. supporting roles in Hindi poetry.
c11_hin_ar_cbse_07_004: Class 11 protagonist analysis practice — needed to avoid conflating the two.
c12_hin_a_cbse_07_001: If stuck, review the definition of "viraha" in c12_hin_a_cbse_07_001 (Context) and the protagonist's profile in c12_hin_a_cbse_07_004.  

## FORWARD_NODE_IDS
c12_hin_a_cbse_07_006, c12_hin_a_cbse_07_013, c12_hin_a_cbse_07_014, c12_hin_a_cbse_07_015

## FORWARD_REASONS
c12_hin_a_cbse_07_006: The supporting characters' roles (witness, messenger, cosmic backdrop) directly construct the primary theme of separation as universal.
c12_hin_a_cbse_07_013: Critical thinking requires synthesizing character functions into an interpretive argument — this node supplies the evidence base.
c12_hin_a_cbse_07_014: Writing tasks (e.g., "analyze the role of the sakhi") demand the analytical paragraphs practiced here.
c12_hin_a_cbse_07_015: Absent husband as silent counterpoint shapes dialogue  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
c12_history_bhakti_movement: The poem belongs to the Nirguna/Saguna bhakti tradition where the devotee (woman) and divine (beloved) separation is mediated by intermediaries (guru/sakhi) — historical context clarifies the sakhi's symbolic weight.
c12_sociology_gender_roles_in_literature: The portrayal of the woman's interiority through a female friend reflects gendered communication patterns in medieval North Indian society — sociological lens deepens character reading.

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_07_005 -> c12_hin_a_cbse_07_005 -> c12_hin_a_cbse_07_006

## THIS_FORMULA
PEEL for Supporting Character Analysis: Point (claim about function) → Evidence (stanza/line + Hindi phrase) → Explanation (how it works) → Link (connect to protagonist/theme).

## FORMULA_VARIABLES
Point = One-sentence analytical claim (e.g., "The sakhi externalizes the protagonist's invisible suffering."); Evidence = Specific textual reference (stanza number + key words in original); Explanation = 2-3 sentences unpacking the evidence's effect; Link = Sentence tying back to viraha theme or protagonist's arc.

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
linguistic

## CROSS_SUBJECT
N/A | The sakhi mirrors the guru-mediated devotee-divine relationship central to bhakti historiography.
 N/A | The female confidante as the only witness to a woman's grief reflects purdah-era social constraints on expression.
## PREREQ_CONCEPT
Understanding that in pre-modern Hindi poetry, "character" often means "voice-function" rather than "psychological individual".

## PREREQ_BEFORE
Student must be able to identify the protagonist (ukf;dk) and state her central emotion (viraha) without prompting.

## PREREQ_STUCK
If stuck, review the definition of "viraha" in c12_hin_a_cbse_07_001 (Context) and the protagonist's profile in c12_hin_a_cbse_07_004.

## WORKED_EXAMPLE_1
PROBLEM: Analyze the function of the sakhi (friend) in Stanza 1 of "ckjgeklk" using the PEEL structure.
STEPS:
- Step 1: Identify the supporting character — the sakhi speaks the opening lines ("fi; lkSa dgsgq l¡nslM+k...").
- Step 2: Formulate a Point — The sakhi acts as an external observer who makes the protagonist's internal agony visible to the audience.
- Step 3: Select Evidence — She describes the woman sitting by the water ("ty jgh gS"), detailing her physical markers: "Hk¡ojs rFkk dkx osQ le{k viuh fLFkfr;ksa dk o.kZu djrs gq, uk;d dks lans'k Hkst jgh gSA".
- Step 4: Explain — The verbs "jgh gS" (sits), "o.kZu djrs gq," (describing), "lans'k Hkst jgh gSA" (sending message) show the woman is passive; the sakhi does the speaking, the moving, the communicating. This creates dramatic irony: we see the woman through another's eyes, heightening her isolation.
- Step 5: Link — This externalization is essential to viraha poetry — the beloved is absent, the woman is silent, so a witness must voice her pain. The sakhi thus structuralizes the theme of communication across separation.
REASONING: The steps move from identification to claim to textual proof to effect-analysis to thematic synthesis — exactly the analytical ladder board exams reward.
ANSWER: The sakhi in Stanza 1 functions as the poem's first witness. By reporting the woman's static posture ("ty jgh gS") and her silent signaling ("lans'k Hkst jgh gSA"), the sakhi transforms private grief into a public scene. This device allows the poet to show, not tell, the depth of viraha — the woman's body becomes a text the sakhi reads aloud. Consequently, the audience experiences the separation as both intimate (domestic detail) and performed (relayed), a hallmark of the genre.

## WORKED_EXAMPLE_2
PROBLEM: Compare the bird (iou) in Stanza 4 and the night (ekl) in Stanza 3 as supporting "characters". Write two PEEL paragraphs showing how each expands the poem's emotional geography.
STEPS:
- Step 1: List the two characters and their stanzas — iou (Stanza 4), ekl (Stanza 3).
- Step 2: Determine each one's spatial domain — iou: sky/flight path; ekl: entire firmament ("ykxsm ek¡g").
- Step 3: Draft Point for iou — The bird embodies fragile, mobile hope that connects the woman to the absent beloved.
- Step 4: Evidence for iou — "iQkxqu iou >¡dksjS cgkA" (swift bird flies) and woman watches "pk¡pfj tksjh" (waiting for return).
- Step 5: Explanation for iou — Its speed ("cgkA") contrasts with her stillness; its round trip ("pk¡pfj") mirrors the desired return of the beloved. The bird's uncertainty ("dfjUg cukiQfr dhUg gqyklwA" — fate's writing unknown) duplicates her anxiety.
- Step 6: Link for iou — Thus the bird externalizes the oscillation between hope and despair.
- Step 7: Draft Point for ekl — The night expands the domestic scene to a cosmic scale, universalizing the woman's vigil.
- Step 8: Evidence for ekl — "ykxsm ek¡g ijS vc ikykA" (night spreads over sky), "ggfy ggfy vfèkdkS fg; dk¡iSAA" (darkness deepens).
- Step 9: Explanation for ekl — The night is not a messenger but a container; it holds her without response, making her solitude absolute. The repetition "ggfy ggfy" mimics the endless hours.
- Step 10: Link for ekl — Together, bird (vertical hope) and night (horizontal envelope) map the two axes of viraha: yearning upward, waiting outward.
REASONING: This worked example models comparative analysis — a frequent board competency question — by applying the same PEEL template to two figures and then synthesizing their spatial symbolism.
ANSWER: Paragraph 1 (iou): The bird serves as a fragile messenger of hope... [as in Diagnostic Answer 3]. Paragraph 2 (ekl): The night functions as an all-encompassing witness... [as above]. Synthesis: The poem's emotional geography moves from the room (sakhi) to the sky (bird) to the cosmos (night), paralleling the protagonist's grief expanding from personal to universal.

## WORKED_EXAMPLE_3
PROBLEM: A board exam question asks: "How do the supporting characters in 'ckjgeklk' collectively construct the experience of viraha? Answer in 150 words with textual references." Write a model answer.
STEPS:
- Step 1: Deconstruct the prompt — "collectively construct" means synthesis, not isolated descriptions; "viraha experience" = the theme; "150 words" = concise, 4-5 paragraphs.
- Step 2: Map each supporting character to a dimension of viraha — sakhi: physical manifestation; iou: temporal hope/deferral; ekl: spatial/cosmic solitude; priyatam (absent beloved): the void that generates all.
- Step 3: Draft thesis sentence — The supporting voices in "ckjgeklk" form a concentric structure that externalizes the protagonist's viraha from body to universe.
- Step 4: Write Paragraph 1 (sakhi) — Use PEEL: Point = domestic witness; Evidence = "Hk¡ojs rFkk dkx osQ le{k"; Explanation = makes invisible pain visible; Link = grounds viraha in the body.
- Step 5: Write Paragraph 2 (iou) — Point = mobile hope; Evidence = "iQkxqu iou >¡dksjS cgkA"; Explanation = bird's flight = desired reunion; Link = introduces time/anticipation.
- Step 6: Write Paragraph 3 (ekl) — Point = cosmic container; Evidence = "ykxsm ek¡g ijS vc ikykA"; Explanation = night universalizes solitude; Link = elevates personal grief to existential condition.
- Step 7: Concluding sentence — Together, they prove viraha is not an emotion but a world the woman inhabits.
- Step 8: Word count check — trim redundancies, ensure each paragraph has a Hindi phrase.
REASONING: This example demonstrates exam-ready synthesis: it uses the same evidence from Worked Examples 1-2 but reorganizes them into a cohesive argument, modeling the "competency: critical thinking" pattern.
ANSWER: The supporting characters in "ckjgeklk" build a concentric architecture of viraha. The sakhi (Stanza 1) anchors the woman's grief in the domestic body — "Hk¡ojs rFkk dkx osQ le{k viuh fLFkfr;ksa dk o.kZu" — making invisible pain tangible. The bird (Stanza 4) introduces vertical yearning: "iQkxqu iou >¡dksjS cgkA" flies where she cannot, its uncertain return ("pk¡pfj tksjh") mirroring her deferred hope. The night (Stanza 3) expands the scene horizontally: "ykxsm ek¡g ijS vc ikykA" spreads over the sky, its deepening darkness ("ggfy ggfy") timing her endless vigil. Even the absent beloved functions as a supporting absence — the "fcjg" (beloved) who never appears. Collectively, these voices transform the woman's room into a microcosm of separation: body, sky, cosmos. Viraha, thus, is not felt — it is staged.

## COMPETENCY_QUESTION_1
QUESTION: In the poem "ckjgeklk", the sakhi says: "lks èkfu fcjgsa tfj eqbZ] rsfgd èkqvk¡ ge ykxA". Explain how this single line simultaneously characterizes the sakhi, the protagonist, and the absent beloved. Use the PEEL structure.
COMPETENCY: Textual Analysis and Inference
STEPS:
- Step 1: Translate the line — "If the beloved were here, the night would pass in joy."
- Step 2: Identify the speaker (sakhi) and her stance — she speaks a conditional truth, imagining an alternative reality.
- Step 3: Analyze effect on protagonist — the line reveals the woman's current reality is the opposite: beloved absent, night painful.
- Step 4: Analyze effect on beloved — he is defined solely by his absence; his presence would transform time ("ykx" = night/time).
- Step 5: Synthesize — the sakhi's hypothetical constructs all three characters relationally.
ANSWER: The sakhi's conditional statement ("lks èkfu fcjgsa tfj eqbZ] rsfgd èkqvk¡ ge ykxA") operates as a relational triangle. For the sakhi, it establishes her role as the voice that articulates the unspoken — she says what the woman cannot. For the protagonist (ukf;dk), it acts as a mirror: the imagined joy ("rsfgd èkqvk¡ ge ykxA") throws her actual sorrow ("ykxsm ek¡g ijS vc ikykA") into sharp relief. For the absent beloved, it reduces him to a functional absence — he is not a person but the condition that would "make the night pass." Thus, one line from a supporting character simultaneously defines the speaker's empathy, the sufferer's lack, and the cause's power. This economy is characteristic of bhakti viraha poetry.
DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: A student claims: "The bird (iou) in Stanza 4 is just a decorative nature image; removing it would not change the poem's meaning." Evaluate this claim using at least three textual arguments. Then, propose a one-stanza rewrite of Stanza 4 without the bird that preserves the core emotion — and explain why your rewrite still fails to capture the original's effect.
COMPETENCY: Critical Evaluation and Creative Reconstruction
STEPS:
- Step 1: List three textual arguments against the claim — (a) the bird introduces motion/agency in a static poem; (b) its round trip ("pk¡pfj") structures the temporal rhythm of hope; (c) the woman's active watching ("tkSa iS fi;fg tjr vl HkkokA") centers her gaze on the bird, making it the focal point of her consciousness.
- Step 2: Write a bird-less stanza — e.g., "Night deepens, I wait, no wing in sight / My eyes scan the dark for a sign of light."
- Step 3: Explain the loss — the rewrite replaces dynamic anticipation (bird's flight/return) with static waiting; it removes the metaphor of the messenger, the parallel between bird's journey and beloved's journey, and the visual focus that organizes the stanza's imagery.
- Step 4: Conclude — the bird is structural, not decorative.
ANSWER: The claim is false. Three textual arguments: 1) The bird provides the poem's only kinetic action ("iQkxqu iou >¡dksjS cgkA") against the woman's stillness ("ty jgh gS"). 2) Its cyclic flight ("pk¡pfj tksjh" — waiting for its return) creates the stanza's temporal architecture: departure → vigil → hoped return. 3) The woman's gaze is explicitly fixed on it ("tkSa iS fi;fg tjr vl HkkokA" — eyes fixed on the path), making the bird the optical center of her consciousness. Bird-less rewrite: "rqEg fcuq oaQrk èkfu g#bZ] ru fruqoj Hkk MksyA / rsfg ij fcjg tjkbZ oSQ] pgS mM+kok >ksyAA" (The night is long, hope burns low / I call the beloved, he does not come). This preserves the longing but loses the mediating metaphor — the bird's flight *is* the hope made visible. Without it, the poem tells the emotion; with it, the poem enacts the emotion through a surrogate journey. The supporting character is the engine of the stanza's affective logic.
DIFFICULTY: hard