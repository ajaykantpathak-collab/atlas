## DEFINITION
Writing skills based on the chapter refer to the ability to construct structured, evidence-based analytical responses to questions on the poems "vDd osQ opu" by vDdegknsoh, using the PEEL (Point, Evidence, Explanation, Link) framework to demonstrate comprehension of themes, literary devices, and character perspectives.

## COGNITIVE_LEVEL
apply

## MASTERY_CRITERIA
The student can independently write a 150-200 word board-style answer that states a clear analytical point, embeds relevant textual evidence (paraphrased or quoted), explains the evidence's significance, and links back to the central theme of women's oppression and resistance.

## SCOPE_BOUNDARY
This node covers writing analytical answers for exam questions on the two poems in Chapter 14 (theme of patriarchy, symbolism of bird/cage, use of irony, character of the protagonist). It does NOT cover creative writing (e.g., writing a new poem), formal letter writing, or unrelated grammar exercises.

## WALKTHROUGH
Imagine you get a board exam question: "How does the poet use the bird-cage imagery to critique patriarchy?" A struggling student writes a summary of the poem. That is not analysis. To begin, read the question and underline keywords: "bird-cage imagery," "critique," "patriarchy." Next, recall the specific stanzas where the bird (bZ'oj) and cage (?kj) appear in both poems. Then, structure your answer using PEEL: make a Point about the symbolism, give Evidence from the lines (e.g., the bird's clipped wings in poem 1, the prayer to open the house in poem 2), Explain how the evidence shows patriarchal control, and Link to the broader theme of women's silenced agency. The key insight: every sentence must earn marks by advancing an argument, not just retelling the story.

## DIAGNOSTIC_QUESTION_1
What does the acronym PEEL stand for in the context of writing analytical answers for literature?

## DIAGNOSTIC_ANSWER_1
PEEL stands for Point, Evidence, Explanation, Link. A wrong answer (e.g., "Paragraph, Essay, Explain, List") reveals the student has not internalized the standard answer-writing structure taught in senior secondary English, leading to disorganized responses that lack analytical depth.

## DIAGNOSTIC_QUESTION_2
A student writes: "In the first poem, the bird is in a cage. This shows women are trapped. In the second poem, she prays to God to open the cage." Why is this answer insufficient for a 6-mark question at Class 11 level?

## DIAGNOSTIC_ANSWER_2
The answer only narrates plot points (summary) without analytical vocabulary (e.g., "symbolism," "patriarchal metaphor"), lacks specific textual references (stanza/line indicators), and omits the "Explanation" and "Link" steps of PEEL. A wrong diagnosis (e.g., "it's too short") misses the structural deficiency: the student doesn't know how to move from observation to interpretation.

## DIAGNOSTIC_QUESTION_3
Apply the PEEL structure to answer: "Explain the significance of the word 'pjkpj' (flutter/wings) in the first poem." Write only the Point and Evidence steps.

## DIAGNOSTIC_ANSWER_3
Point: The onomatopoeic word 'pjkpj' (vks pjkpj! er pwd volj) vividly captures the bird's desperate physical struggle against confinement. Evidence: In the final stanza of the first poem, the sound 'pjkpj' is juxtaposed with 'pwd volj' (falling down), showing the futility of the struggle. A wrong application would quote the line without naming the device (onomatopoeia) or connecting it to the theme of resistance.

## DIAGNOSTIC_QUESTION_4
Compare the tone of the two poems. The first poem ends with the bird falling ('pwd volj'); the second is a prayer ('gs esjs twgh...'). Analyze how this tonal shift changes the reader's understanding of the protagonist's agency.

## DIAGNOSTIC_ANSWER_4
The first poem's tone is tragic realism (objective depiction of crushing oppression), while the second shifts to desperate supplication (subjective plea for divine intervention). This shift reveals that the protagonist (vDdegknsoh) moves from being a silent victim to an active spiritual resistor, refusing to accept the cage as final. A wrong analysis treats both poems as having the same "sad tone," missing the evolution from passive suffering to active resistance.

## DIAGNOSTIC_QUESTION_5
Evaluate this claim: "The second poem weakens the feminist message because the woman prays to a male God (pUuefYydktqZu) for freedom instead of breaking the cage herself." Defend or refute using textual evidence.

## DIAGNOSTIC_ANSWER_5
Refute. The prayer is a strategic necessity in a context where physical rebellion is impossible (she is physically confined: 'viuh >ksyh [kkyh j[kuk pkgrh gSa'). Addressing 'pUuefYydktqZu' (the Supreme Creator) bypasses the earthly patriarch (the king/husband) and claims a higher justice. The poem shows agency through spiritual defiance, not passivity. A wrong evaluation imposes modern Western feminism on a medieval Bhakti-context text, ignoring the historical constraints of the protagonist.

## DIAGNOSTIC_QUESTION_6
Create a new 4-line stanza in the style of the second poem where the bird (bZ'oj) speaks directly to the cage (?kj), using at least one literary device from the chapter (irony, metaphor, or personification).

## DIAGNOSTIC_ANSWER_6
Example: "O cage, you boast of walls so strong, / But my song seeps through where bars belong. / You are not my home, but my metaphor, / I'll break you open with a breath, no more." (Uses metaphor and personification). A poor answer writes a generic rhyme without the specific voice (bird addressing cage) or the chapter's devices, showing inability to transfer learning to creative application.

## COMMON_MISCONCEPTION
Students believe "writing a good answer" means writing a detailed summary of the poem in chronological order. They think including more plot points = more marks. This error stems from Class 10 focus on "comprehension" (retelling) rather than Class 11 "critical appreciation" (arguing). For example, a student spends 80 words describing the king's anger in the background story but zero words analyzing how the 'bZ'oj' metaphor functions in stanza 2 of poem 1.

## ON_FAILURE
1. Give the student a 3-mark question and a model PEEL answer. 2. Color-code the model: Point (Blue), Evidence (Green), Explanation (Yellow), Link (Red). 3. Ask them to highlight the same colors in their own answer. 4. If a color is missing, they rewrite only that component. 5. Practice with one stanza at a time until the structure becomes automatic.

## BUILDS_ON
Critical Thinking: Analysis and Interpretation (c11_hin_ar_cbse_14_013) where students learned to identify themes and devices; now they learn to communicate that analysis in writing.

## LEADS_TO
Speaking and Listening: Discussion Points (c11_hin_ar_cbse_14_015) where written arguments are adapted for oral presentation and debate.

## PREREQUISITE_NODE_IDS
c11_hin_ar_cbse_14_001, c11_hin_ar_cbse_14_002, c11_hin_ar_cbse_14_003, c11_hin_ar_cbse_14_004, c11_hin_ar_cbse_14_005, c11_hin_ar_cbse_14_006, c11_hin_ar_cbse_14_007, c11_hin_ar_cbse_14_008, c11_hin_ar_cbse_14_009, c11_hin_ar_cbse_14_010, c11_hin_ar_cbse_14_011, c11_hin_ar_cbse_14_012, c11_hin_ar_cbse_14_013

## PREREQUISITE_REASONS
c11_hin_ar_cbse_14_001: Context knowledge (Bhakti movement, vDdegknsoh's biography) provides the "Link" to historical patriarchy.
c11_hin_ar_cbse_14_002: Narrative structure helps sequence evidence logically in the answer.
c11_hin_ar_cbse_14_003: Setting/atmosphere (the cage, the palace) provides concrete Evidence for confinement imagery.
c11_hin_ar_cbse_14_004: Protagonist analysis (vDdegknsoh as historical figure and poetic persona) informs the "Point" about agency.
c11_hin_ar_cbse_14_005: Supporting characters (the king, the bird) function as foils; essential for comparative Points.
c11_hin_ar_cbse_14_006: Primary theme (oppression/resistance) is the ultimate "Link" destination for every paragraph.
c11_hin_ar_cbse_14_007: Secondary themes (spiritual autonomy, body vs soul) allow nuanced Points in higher-mark questions.
c11_hin_ar_cbse_14_008: Imagery/metaphor identification (bird, cage, wings) supplies the specific textual Evidence.
c11_hin_ar_cbse_14_009: Irony/symbolism analysis enables sophisticated Explanation steps (e.g., the cage as 'protection' vs prison).
c11_hin_ar_cbse_14_010: Key vocabulary (pjkpj, ik'k, <hy, pUuefYydktqZu) ensures precise terminology in Evidence/Explanation.
c11_hin_ar_cbse_14_011: Grammar usage (imperative mood in poem 2: 'Hkwy tkÅ¡', 'oqQN nsus') supports Explanation of tone.
c11_hin_ar_cbse_14_012: Literal/inferential comprehension ensures Evidence is accurately paraphrased, not misquoted.
c11_hin_ar_cbse_14_013: Critical interpretation provides the analytical "Points" that drive the essay argument.

## FORWARD_NODE_IDS
c12_hin_a_cbse_05_014, c12_hin_a_cbse_14_014, c12_hin_ar_cbse_14_014

## FORWARD_REASONS
c12_hin_a_cbse_05_014: अगला तार्किक चरण: Writing Skills based on the chapter refers to the ability to compose structured, evidence-based resp... इस नोड की अवधारणाओं को सीधे उपयोग/विस्तारित करता है।  
c12_hin_a_cbse_14_014: Class 11 Antra writing skills established PEEL basics and literature answer structure — this node advances it to competency level.  
c12_hin_ar_cbse_14_014: Class 11 foundation in text-based writing (PEEL introduction, evidence embedding) — this node advances it to board-exam rigor.  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
none

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_14_013 -> c11_hin_ar_cbse_14_014 -> c11_hin_ar_cbse_14_015

## THIS_FORMULA
PEEL Structure: Point (Analytical Claim) + Evidence (Textual Reference) + Explanation (Device/Effect Analysis) + Link (Theme/Question Connection)

## FORMULA_VARIABLES
Point: A single, arguable claim answering the question (e.g., "The poet uses the bird as a metaphor for the woman's silenced voice."); Evidence: Specific textual detail (stanza number, key phrase, literary device) supporting the Point; Explanation: Analysis of HOW the evidence works (device, connotation, context) to prove the Point; Link: Sentence connecting the paragraph back to the essay's thesis or the exam question's key terms.

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
linguistic

## CROSS_SUBJECT
c11_history_medieval_india | The chapter's historical context (vDdegknsoh in Rajputana, conflict with king) connects to History themes of Bhakti movement challenging feudal patriarchy and gender norms in medieval Rajasthan.
c11_sociology_gender_studies | The bird-cage symbolism is a classic sociological metaphor for patriarchal control of women's mobility and sexuality; the poems serve as primary texts for analyzing resistance strategies in pre-modern India.

## PREREQ_CONCEPT
Student must understand the difference between *summary* (what happens) and *analysis* (why it matters/how it works) — introduced in Critical Thinking node (c11_hin_ar_cbse_14_013).

## PREREQ_BEFORE
Student must have read both poems in the NCERT textbook, identified the central metaphor (bird=caged woman), and listed at least 3 literary devices used.

## PREREQ_STUCK
If stuck, review "Theme: Primary Theme and Message" (c11_hin_ar_cbse_14_006) and "Literary Devices: Imagery and Metaphor" (c11_hin_ar_cbse_14_008) to rebuild the content bank needed for Evidence and Explanation steps.

## WORKED_EXAMPLE_1
PROBLEM: Improve this weak answer to a 3-mark question: "Question: What does the 'cage' symbolize in the first poem? Weak Answer: The cage is where the bird lives. The king put the bird there. It is made of gold. The bird dies in it."
STEPS:
- Step 1: Identify the question's demand: "symbolize" requires interpretation, not physical description. The weak answer only gives literal details (gold, king, death).
- Step 2: Recall the PEEL structure. The weak answer has no Point (analytical claim), Evidence is plot narration not textual quote, Explanation is missing, Link is absent.
- Step 3: Draft Point: The golden cage symbolizes the deceptive luxury of patriarchal confinement that masks oppression as privilege.
- Step 4: Select Evidence: Reference the description of the cage in the poem (implied by 'viuh >ksyh [kkyh j[kuk pkgrh gSa' - keeping wings clipped) and the king's 'protection' that is actually imprisonment.
- Step 5: Write Explanation: Gold represents material comfort provided by the patriarch (king/husband) to silence dissent; clipping wings (ik'k <hy) shows the systematic destruction of agency.
- Step 6: Write Link: Thus, the cage is not a physical space but a metaphor for the socio-cultural structure that traps women like vDdegknsoh.
REASONING: The weak answer stays at the literal level (remember/understand). The improved answer moves to analyze/evaluate by decoding the symbol's socio-political meaning, which is the Class 11 expectation.
ANSWER: The golden cage symbolizes the deceptive luxury of patriarchal confinement that masks oppression as privilege. In the poem, the protagonist's wings are clipped ('ik'k <hy') while she is kept in comfort ('viuh >ksyh [kkyh j[kuk pkgrh gSa'), illustrating how patriarchal systems provide material security only to destroy autonomy. The gold represents the bribe of privilege that buys silence. Therefore, the cage functions as an extended metaphor for the socio-cultural structure that entraps women like vDdegknsoh, making their oppression invisible even to themselves.

## WORKED_EXAMPLE_2
PROBLEM: Write a 6-mark answer for: "Contrast the portrayal of the bird's desire for freedom in the two poems." (Student tends to write two separate summaries.)
STEPS:
- Step 1: Deconstruct the question: "Contrast" requires side-by-side comparison, not sequential summary. "Desire for freedom" is the analytical lens.
- Step 2: Create a comparative thesis (Point for whole answer): Poem 1 depicts freedom as a crushed biological instinct; Poem 2 reimagines it as a spiritual right claimed through prayer.
- Step 3: Structure two body paragraphs using PEEL, each comparing one dimension (Physical vs Spiritual; Passive vs Active).
- Step 4: Paragraph 1 (Physical/Passive): Point: In Poem 1, freedom is a physical flutter ('pjkpj') ending in defeat. Evidence: 'vks pjkpj! er pwd volj' (flutter then fall). Explanation: Onomatopoeia 'pjkpj' emphasizes visceral struggle; 'pwd volj' shows patriarchal power crushing the body. Link: Freedom here is a biological right denied by force.
- Step 5: Paragraph 2 (Spiritual/Active): Point: In Poem 2, freedom becomes a divine entitlement demanded via prayer. Evidence: 'gs esjs twgh... Hkwy tkÅ¡ viuk ?kj' (O my Lord... make my house open). Explanation: Imperative mood ('Hkwy tkÅ¡') shifts agency to the supplicant; addressing 'twgh' (Lord) bypasses the earthly jailer. Link: Freedom evolves from bodily escape to spiritual liberation.
- Step 6: Concluding Link: The contrast traces the protagonist's journey from silenced victim to conscious resistor, showing that when the body is caged, the soul litigates in a higher court.
REASONING: This models the "compare and contrast" essay structure required in board exams: thesis-driven, integrated paragraphs (not two summaries), and thematic synthesis in conclusion.
ANSWER: The two poems present a stark evolution in the portrayal of the desire for freedom. In the first poem, freedom is a crushed biological instinct: the bird's desperate flutter ('vks pjkpj!') meets immediate defeat ('er pwd volj'). The onomatopoeic 'pjkpj' visceralizes the physical struggle, while 'pwd volj' signifies the patriarchal power that clips wings ('ik'k <hy') to enforce confinement. Here, freedom is a bodily right denied by force. In contrast, the second poem reimagines freedom as a spiritual entitlement claimed through active supplication. The imperative prayer 'gs esjs twgh... Hkwy tkÅ¡ viuk ?kj' (O my Lord, make my house open) shifts agency to the woman; she addresses the Supreme Creator ('pUuefYydktqZu'), bypassing the earthly king who caged her. The 'house' (cage) is demanded to be opened not by her captor but by divine justice. This contrast traces vDdegknsoh's journey from silenced victim to conscious resistor: when the body is imprisoned, the soul litigates in a higher court, transforming passive suffering into spiritual defiance.

## WORKED_EXAMPLE_3
PROBLEM: A 10-mark question: "vDdegknsoh's poetry is a historical document of women's resistance in medieval India." Evaluate this statement with reference to both poems. (Combines historical context, theme, device, and personal response.)
STEPS:
- Step 1: Unpack the claim: "historical document" = primary source value; "women's resistance" = agency against patriarchy; "medieval India" = specific socio-historical context.
- Step 2: Formulate thesis: The poems function as both personal testimony and collective resistance archive, using Bhakti discourse to legitimize female dissent.
- Step 3: Argument 1 (Historical Persona): Point: vDdegknsoh's biography (node 001) as a princess who renounced kingdom validates the poems as lived history. Evidence: Text notes she left palace after king broke promise. Explanation: The poems are not fiction but autobiography; the 'bird' is the poet herself. Link: This biographical grounding makes them historical documents.
- Step 4: Argument 2 (Resistance through Bhakti): Point: Poem 2 uses Bhakti vocabulary ('pUuefYydktqZu', 'twgh') to frame resistance as divine right. Evidence: Prayer format mirrors Meerabai's strategy. Explanation: In medieval Rajasthan, appealing to God was the only legitimate dissent for women; it reframes rebellion as devotion. Link: Resistance is encoded in spiritual language to survive censorship.
- Step 5: Argument 3 (Symbolic Universality): Point: The bird-cage metaphor transcends individual experience to represent all aristocratic women. Evidence: 'bZ'oj' (bird) has no name; '?kj' (house) is generic. Explanation: Allegory protects the poet while generalizing the condition. Link: The symbol transforms personal pain into collective testimony.
- Step 6: Counter-perspective/Nuance: The poems end in prayer, not revolution; resistance is spiritual, not structural. This limits their "document" value for material history.
- Step 7: Synthesis: They are historical documents of *ideological* resistance, recording how women negotiated agency within impossible constraints.
REASONING: This models the highest-level board answer: multi-paragraph, thesis-driven, integrating context (node 001), theme (node 006/007), device (node 008/009), and critical evaluation (node 013) — exactly what "competency" questions demand.
ANSWER: vDdegknsoh's poems operate as layered historical documents recording women's negotiated resistance in medieval Rajputana. First, their autobiographical anchor — the poet-princess who abandoned her kingdom when the king violated his promise — transforms the 'bird' from metaphor into lived testimony. The cage ('?kj') is not imaginary; it is the zenana where wings are clipped ('ik'k <hy') to enforce conformity. Second, the resistance strategy is historically specific: Poem 2's prayer to 'pUuefYydktqZu' employs Bhakti discourse (like Meerabai) to legitimize dissent. By addressing the Supreme Creator instead of the earthly king, she claims a jurisdiction beyond patriarchal law, encoding rebellion as devotion — the only safe language for a medieval woman. Third, the allegorical universality of 'bZ'oj' (unnamed bird) and '?kj' (generic house) generalizes her aristocratic trauma into a collective archive of upper-caste women's confinement. However, as historical documents, they reveal the limits of their era: resistance remains spiritual ('Hkwy tkÅ¡ viuk ?kj'), not material; the cage opens only by divine grace, not human revolution. Thus, they document not the overthrow of patriarchy, but the ingenious survival of female subjectivity within it — a testament to resistance as endurance.

## COMPETENCY_QUESTION_1
QUESTION: A Class 11 student writes this answer to "Explain the irony in the king's 'protection' of the bird in Poem 1": "The king says he will protect the bird but he actually puts it in a cage. This is ironic because a cage is not protection." The teacher gives 1 out of 3 marks. Using the PEEL framework, diagnose exactly which components are missing or weak, and rewrite the answer to earn full marks.
COMPETENCY: Critical evaluation of answer quality / Application of PEEL criteria
STEPS:
- Step 1: Identify the student's Point: "The king's protection is actually imprisonment." (Present but vague).
- Step 2: Check Evidence: "puts it in a cage" — plot summary, not textual evidence (no line/stanza reference, no device named).
- Step 3: Check Explanation: "cage is not protection" — states the irony but doesn't analyze HOW the text creates it (e.g., contrast between 'lkSan;Z' (care) and 'NksM+ fn;k' (abandoned)).
- Step 4: Check Link: Missing — no connection to theme of patriarchal betrayal or the poem's central argument.
- Step 5: Rewrite adding: specific Evidence (king's 'vn~Hkqr&vykSfdd lkSan;Z' vs outcome 'jkt&ifjokj dks NksM+ fn;k'), Explanation of dramatic irony (reader knows cage=prison; king calls it care), Link to vDdegknsoh's real-life betrayal.
ANSWER: Diagnosis: The answer has a basic Point but lacks textual Evidence (no quote/device), has superficial Explanation (labels irony without analyzing mechanism), and no thematic Link. Rewritten PEEL answer: The central irony lies in the king's perversion of 'lkSan;Z' (protection) into imprisonment. Evidence: The text states the king saw her 'vn~Hkqr&vykSfdd lkSan;Z' (worldly-spiritual welfare) but ultimately 'jkt&ifjokj dks NksM+ fn;k' (abandoned kingdom and palace). Explanation: This is dramatic irony — the king frames the cage as welfare ('fookg osQ fy,') while the reader sees the clipped wings ('ik'k <hy') and clipped life. The word 'lkSan;Z' becomes a euphemism for control. Link: This mirrors vDdegknsoh's historical experience where royal 'protection' demanded surrender of autonomy, making the bird's cage a precise allegory for the Rajput princess's gilded trap.
DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: "The second poem is merely a religious prayer; it has no feminist relevance." Write a 150-word counter-argument using evidence from both poems, the poet's biography, and the literary device of 'address' (apostrophe), structured in two PEEL paragraphs.
COMPETENCY: Argumentative writing synthesizing biography, literary device, and gender theory
STEPS:
- Step 1: Formulate thesis: The prayer form is a strategic feminist weapon in a theocratic patriarchy, not surrender.
- Step 2: Paragraph 1 (Biographical/Historical): Point: vDdegknsoh's life (leaving kingdom) proves the prayer is political act. Evidence: She abandoned palace when king broke promise (node 001). Explanation: In medieval Rajasthan, a woman's only legal recourse against a king was divine appeal; the prayer documents this strategy. Link: The poem is a legal affidavit addressed to the Highest Court.
- Step 3: Paragraph 2 (Literary Device - Apostrophe): Point: The apostrophe to 'pUuefYydktqZu' subverts the king's authority. Evidence: Imperatives 'Hkwy tkÅ¡', 'oqQN nsus' directed at God, not king. Explanation: Apostrophe bypasses the human oppressor; the cage ('?kj') is commanded to open by a Power the king cannot defy. Link: This reclaims agency — she judges her jailer by invoking a higher Judge.
- Step 4: Synthesis: The prayer is the resistance of the powerless made powerful through spiritual jurisdiction.
ANSWER: The claim that Poem 2 is "merely a religious prayer" ignores the theocratic reality of medieval Rajputana where the divine was the only court above the king. First, vDdegknsoh's biography confirms the prayer as political strategy: historically, she fled the palace only after the king violated his sworn promise ('fookg osQ fy, jktk osQ lkeus rhu 'krs± j[kha'), proving the poem documents a real woman exhausting earthly justice before appealing to the divine. In a system where women had no legal standing, addressing 'pUuefYydktqZu' was not piety but jurisprudence — a affidavit filed in the Supreme Court of the universe. Second, the poem's apostrophe (direct address to an absent entity) structurally enacts this bypass. The imperatives 'Hkwy tkÅ¡ viuk ?kj' (make my house open) and 'oqQN nsus' (give such order) are commanded not to the king who holds the keys, but to the Creator who owns the house. This rhetorical move strips the patriarch of legitimacy; the cage ('?kj') must open because a higher Authority orders it. Thus, the prayer is the resistance of the materially powerless made operationally powerful through spiritual jurisdiction — a feminist act encoded in Bhakti language to survive the censor.
DIFFICULTY: hard