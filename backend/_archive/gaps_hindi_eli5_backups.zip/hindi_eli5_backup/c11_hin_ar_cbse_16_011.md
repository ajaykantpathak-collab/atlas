## DEFINITION
Language usage in poetry refers to the deliberate grammatical, lexical, and syntactic choices a poet makes to create imagery, rhythm, and emotional impact. In this poem, the poet uses metaphorical compounds, inverted word order, and vivid adjective-noun pairings to contrast societal decay with moral awakening.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student can identify and explain at least three distinct grammatical or lexical features in the poem (such as samas, vibhakti, poetic inversion, or compound imagery) and analyze how each contributes to the poem's central theme of conscience awakening.

## SCOPE_BOUNDARY
This node covers grammatical analysis of the poem "vkvks] feydj cpk,¡" including samas (compound words), vibhakti (case endings), poetic word order, and imagery-building vocabulary. It does NOT cover general Hindi grammar rules unrelated to this text, nor does it repeat the thematic analysis from nodes 16_006-16_009.

## WALKTHROUGH
Imagine you're reading a poem where words don't follow normal sentence order — "Hkhrj dh vkx" (the poison of hatred) instead of "vkx Hkhrj dh". Ask yourself: why did the poet place "dh vkx" after "Hkhrj"? This inversion forces you to pause at "Hkhrj" first, making hatred the subject before revealing its poisonous nature. Start by reading the poem aloud, noticing where the natural Hindi SOV order breaks. Mark every compound word (like vkcks&gok, vD[kM+iu) and ask what two ideas are fused. Then trace how case endings (ne, ko, se, par) show who acts upon whom in each image. The key insight: grammatical choices are not decorative — they enact the poem's argument that conscience must be actively "awakened" (cpk,¡) against passive suffering.

## DIAGNOSTIC_QUESTION_1
Identify the samas (compound type) in "vkcks&gok" and "vD[kM+iu" from the poem's vocabulary list, and state the meaning of each compound as given in the 'kCn&Nfo section.

## DIAGNOSTIC_ANSWER_1
vkcks&gok is a Tatpurusha samas (tyok;q + gok = tyok;q dk gok) meaning "deep darkness of the riverbank/shore". vD[kM+iu is a Karmadharaya samas (vD[k + M+iu = fdlh ckr dks ysdj #[kkbZ ls ru tkus dk Hkko) meaning "obsessive clinging to something". A wrong answer reveals the student cannot distinguish between compound types or relies on literal word-for-word translation instead of the idiomatic meanings provided in the textbook.

## DIAGNOSTIC_QUESTION_2
In the line "Hkhrj dh vkx / èkuq"k dh Mksjh", explain why the poet uses the genitive case (dh) for both "Hkhrj" and "èkuq"k" instead of the instrumental case (se). What relationship does "dh" establish that "se" would not?

## DIAGNOSTIC_ANSWER_2
The genitive "dh" establishes possession/origin — hatred *possesses* poison, selfishness *possesses* a mosquito-like sting — making these qualities intrinsic to the abstract nouns. Instrumental "se" would imply the poison comes *from* hatred as an external agent, weakening the metaphor of inherent corruption. A wrong answer shows the student treats case endings as interchangeable markers rather than semantic choices that shape metaphorical meaning.

## DIAGNOSTIC_QUESTION_3
The poem lists negative images in the first half (Hkhrj, èkuq"k, rhj, oqQYgkM+h, taxy) and positive images in the second half (ufn;ksa, igkM+ksa, xhrksa, fe^h, iQlyksa). Identify the grammatical pattern that structures both lists and explain how this parallel syntax serves the poem's argument.

## DIAGNOSTIC_ANSWER_3
Both lists use the pattern [Abstract Noun] + [Genitive 'dh/ki/ki'] + [Concrete Noun] — e.g., "Hkhrj dh vkx", "ufn;ksa dh fueZyrk". This parallelism creates structural equivalence between societal evils and virtues, suggesting they occupy the same grammatical (and moral) space — the choice between them is a matter of conscious selection. A wrong answer misses the syntactic parallelism or treats the lists as mere vocabulary catalogues rather than a grammatical enactment of moral choice.

## DIAGNOSTIC_QUESTION_4
Analyze the imperative construction "vkvks] feydj cpk,¡" (Come, let's awaken). Why does the poet use the conjunctive participle "feydj" (having awakened) + imperative "cpk,¡" instead of a simple imperative "cpk,¡" alone? What temporal and agency implications does this structure carry?

## DIAGNOSTIC_ANSWER_4
"feydj cpk,¡" creates a sequential imperative: first *awaken yourselves* (feydj), *then* awaken others (cpk,¡). The conjunctive participle makes self-awakening a prerequisite for collective action, encoding the poem's philosophy that social change begins with individual conscience. A simple "cpk,¡" would imply simultaneous or undifferentiated action. A wrong answer treats "feydj" as mere emphasis or ignores the sequential logic of conjunctive participles in Hindi imperatives.

## DIAGNOSTIC_QUESTION_5
Evaluate the poet's choice to use Tatsama-heavy vocabulary (vkcks&gok, vD[kM+iu, tq>k:iu, lksaèkkiu, mEehn) alongside Tadbhava words (Hkhrj, èkuq"k, rhj, oqQYgkM+h, taxy). Does this register mixing strengthen or weaken the poem's accessibility and authority? Justify with two specific examples.

## DIAGNOSTIC_ANSWER_5
The mixing strengthens both: Tatsama compounds (vD[kM+iu, tq>k:iu) lend philosophical precision to abstract psychological states, while Tadbhava words (Hkhrj, rhj) ground visceral evils in everyday speech. Example 1: "vD[kM+iu" (Sanskrit-rooted) names a complex psychological attachment that "lalach" cannot capture. Example 2: "Hkhrj" (Tadbhava) evokes raw, bodily hatred more viscerally than "dvesha". A wrong answer either privilees one register as "better" or fails to link register choice to specific semantic gaps in the other register.

## DIAGNOSTIC_QUESTION_6
Write four lines of poetry in Hindi that use the same [Abstract Noun + Genitive + Concrete Noun] pattern as the poem, but on the theme of "digital addiction among youth". Use at least one Tatsama compound and one Tadbhava word.

## DIAGNOSTIC_ANSWER_6
Example answer:
"scLs dh gVk / iSj dh nqfu;k
fMftVy dh vkx / lqUnj dh Mksjh"
A strong answer maintains the exact grammatical template, contrasts a Tatsama compound (scLs, fMftVy) with Tadbhava words (iSj, lqUnj), and maps the poem's moral anatomy onto a contemporary issue. A weak answer breaks the pattern, uses only one register, or treats the exercise as free verse without grammatical constraint.

## COMMON_MISCONCEPTION
Students assume "poetic language" means only figures of speech (alankar) like metaphor or alliteration, ignoring how core grammar — case endings, compound formation, word order, verb forms — constructs poetic meaning. For example, they will identify "Hkhrj dh vkx" as a metaphor but miss that "dh" makes hatred the *owner* of poison, not just its source. This error persists because school grammar teaches cases as mechanical labeling exercises, not as semantic tools poets exploit.

## ON_FAILURE
1. Have the student rewrite three poem lines in standard prose order (SOV) and compare: "vkx Hkhrj dh gS" vs "Hkhrj dh vkx" — discuss what is lost/gained. 2. Give a table of 5 poem compounds; have them split each into component words, identify samas type using the 'kCn&Nfo meanings, and explain why the compound is more powerful than the paraphrase. 3. Ask them to replace all genitives (dh/ki/ki) with instrumental (se) in one stanza and read aloud — discuss how agency shifts. 4. Finally, have them compose two lines using the [Noun+dh+Noun] pattern on a personal struggle, forcing grammatical imitation.

## BUILDS_ON
Vocabulary in Context (node 16_010) where students learned the meanings of key terms like vkcks&gok, vD[kM+iu, tq>k:iu.

## LEADS_TO
Comprehension: Literal and Inferential Questions (node 16_012) where grammatical analysis supports evidence-based interpretation.

## PREREQUISITE_NODE_IDS
c11_hin_ar_cbse_16_010, c11_hin_ar_cbse_16_007

## PREREQUISITE_REASONS
c11_hin_ar_cbse_16_010: Students must know the precise meanings of key vocabulary (vkcks&gok, vD[kM+iu, tq>k:iu, lksaèkkiu, mEehn) from the 'kCn&Nfo section before analyzing how these compounds function grammatically and semantically in the poem.
c11_hin_ar_cbse_16_007: Language usage reflects the theme of linguistic rootedness.  

## FORWARD_NODE_IDS
c11_hin_ar_cbse_16_012, c11_hin_ar_cbse_16_013, c12_hin_a_cbse_04_011, c12_hin_a_cbse_09_011, c12_hin_a_cbse_11_011, c12_hin_a_cbse_12_011, c12_hin_a_cbse_17_011, c12_hin_ar_cbse_01_011, c12_hin_ar_cbse_02_011, c12_hin_ar_cbse_07_011, c12_hin_ar_cbse_09_011, c12_hin_ar_cbse_10_011, c12_hin_ar_cbse_11_011, c12_hin_ar_cbse_12_011

## FORWARD_REASONS
c11_hin_ar_cbse_16_012: Grammatical analysis of case endings, compounds, and word order provides the textual evidence needed for literal and inferential comprehension answers. c11_hin_ar_cbse_16_013: Understanding how language choices enact theme (e.g., sequential imperative encoding self-then-social awakening) is prerequisite for critical interpretation.
c12_hin_a_cbse_04_011: अगला तार्किक चरण: This node analyzes the grammatical structures, syntactic patterns, and language usage specific to th... इस नोड की अवधारणाओं को सीधे उपयोग/विस्तारित करता है।  
c12_hin_a_cbse_09_011: *Avyay* (indeclinables) — Braj uses distinct avyays (e.g., *rsa* for *hi*) for recognition.  
c12_hin_a_cbse_11_011: Reviews all Class 11 grammar concepts — comprehensive foundation.  
c12_hin_a_cbse_12_011: Board-style short answer writing for grammar questions  
c12_hin_a_cbse_17_011: Final Class 11 grammar node — ensures readiness for Class 12 depth.  
c12_hin_ar_cbse_01_011: Culminating Class 11 grammar analysis — direct precursor to Class 12 depth.  
c12_hin_ar_cbse_02_011: Final consolidation before Class 12.  
c12_hin_ar_cbse_07_011: Synthesis of grammar, meter, and meaning.  
c12_hin_ar_cbse_09_011: Final Class 11 synthesis before Class 12 deepening.  
c12_hin_ar_cbse_10_011: Language and memory in narrative (Chapter 16).  
c12_hin_ar_cbse_11_011: Synthesizes year-long grammatical literacy  
c12_hin_ar_cbse_12_011: Establishes the analytical framework — "grammar as rhetorical choice" — through worked examples from Class 11 texts (e.g., tense shifts in "नमक का दरोगा", honorifics in "ग़लता लोहा").  
c11_hin_ar_cbse_16_013: अगला तार्किक चरण: Critical thinking in literary analysis involves examining a text beyond its literal meaning to uncov... इस नोड की अवधारणाओं को सीधे उपयोग/विस्तारित करता है।  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
none

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_16_010 -> c11_hin_ar_cbse_16_011 -> c11_hin_ar_cbse_16_012

## THIS_FORMULA
Poetic Grammar Analysis Template: [Identify Feature] -> [Quote Exact Form] -> [State Grammatical Rule] -> [Explain Semantic Effect] -> [Link to Theme]

## FORMULA_VARIABLES
Feature: The specific grammatical element (samas type, vibhakti, word order, verb form, register). Exact Form: The precise word/phrase from the poem. Rule: The Hindi grammatical principle governing this form. Effect: How this form shapes meaning beyond literal paraphrase. Theme Link: How the effect serves the poem's central idea of conscience awakening.

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
linguistic

## CROSS_SUBJECT
c11_psychology_cognitive_processes | The poem's sequential imperative "feydj cpk,¡" (awaken self, then awaken others) mirrors the psychological concept of metacognition — monitoring one's own thinking before influencing others — a core topic in Class 11 Psychology's "Thinking and Reasoning" chapter.
c11_sociology_social_change | The poem's contrast between traditional evils (Hkhrj, oqQYgkM+h) and modern evils (tax, vf'k{kk, 'kjkc) using parallel grammatical structures reflects sociology's "continuity and change" framework — same structural positions, different content — taught in Class 11 Sociology's "Social Change and Social Order" unit.

## PREREQ_CONCEPT
Understanding of Hindi samas (compound words) and vibhakti (case endings) from Class 9-10 grammar, specifically Tatpurusha, Karmadharaya, and genitive case functions.

## PREREQ_BEFORE
Student can identify samas types in isolation and label case endings in simple sentences.

## PREREQ_STUCK
Review Class 10 Hindi Grammar: Samas Vigrah and Vibhakti Pratyaya exercises, focusing on Tatpurusha vs Karmadharaya distinction and genitive vs instrumental semantic difference.

## WORKED_EXAMPLE_1
PROBLEM: Analyze the grammatical structure and thematic function of the line "BaMh gksrh fnup;kZ esa / thou dh xekZgV" from the poem.

STEPS:
- Step 1: Identify the core grammatical pattern — "BaMh gksrh fnup;kZ esa" is a locative phrase (fnup;kZ = fnup;k + sa = in the morning, esa = in) with a present participle "gksrh" (happening/becoming) agreeing with "BaMh" (dawn/daybreak). "thou dh xekZgV" follows the [Abstract Noun + Genitive + Concrete Noun] pattern: "thou" (existence/life) + "dh" (genitive) + "xekZgV" (blood/sweat).
- Step 2: Recognize the poetic inversion — standard prose would be "fnup;kZ esa BaMh gksrh" (dawn happening in the morning). The poet fronts "BaMh gksrh" to emphasize the *process of dawning* as the temporal frame.
- Step 3: Analyze the metaphor "thou dh xekZgV" — "xekZgV" literally means blood/sweat of labor; "thou dh" makes existence the *possessor* of this blood. This fuses biological life with laborious struggle, suggesting living *is* bleeding effort.
- Step 4: Connect to the preceding imperative "vkvks, feydj cpk,¡" — the dawning morning (BaMh gksrh) is the time *for* awakening conscience; the "blood of existence" is what's at stake if we don't awaken. The locative "esa" pins this urgency to a specific, recurring moment (every morning).
- Step 5: Synthesize — the grammar enacts the poem's call: the participle "gksrh" (ongoing process) mirrors the continuous effort "cpk,¡" (keep awakening); the genitive "dh" makes the cost (xekZgV) intrinsic to life (thou), not optional.

REASONING: This analysis moves from grammatical identification to semantic effect to thematic integration, showing how each grammatical choice (participle, inversion, genitive, locative) serves the poem's argument that conscience awakening is a daily, laborious, intrinsic necessity.

ANSWER: The line uses a fronted participial phrase ("BaMh gksrh fnup;kZ esa") to frame the awakening as a daily recurring process, and a genitive metaphor ("thou dh xekZgV") to fuse existence with bloody struggle, making the cost of unconscious living intrinsic to life itself. The grammar performs the poem's urgency: ongoing action (gksrh) demands ongoing awakening (cpk,¡); possessed cost (dh) demands owned responsibility.

## WORKED_EXAMPLE_2
PROBLEM: The poem uses two distinct verb forms for "awakening": "feydj" (conjunctive participle from fey+) and "cpk,¡" (imperative from cpk+). Explain the grammatical difference and why both are necessary for the poem's meaning.

STEPS:
- Step 1: Identify the verb forms — "feydj" is the conjunctive participle (fey + dj) indicating completed prior action; "cpk,¡" is the plural imperative (cpk + ,¡) indicating command/request for future action.
- Step 2: State the grammatical rule — In Hindi, conjunctive participle + imperative creates a sequential command: "Having done X, do Y." The first action is prerequisite for the second.
- Step 3: Apply to the poem — "vkvks] feydj cpk,¡" = "Come, having awakened [yourselves], awaken [others]." Self-awakening (feydj) must precede social awakening (cpk,¡).
- Step 4: Contrast with alternative — If the poet wrote "vkvks] feyks] cpk,¡" (two imperatives), it would imply simultaneous or unordered actions. If "feyks" (subjunctive) were used, it would be hypothetical. The participle "feydj" makes the sequence factual and mandatory.
- Step 5: Link to theme — The poem argues social evils (Hkhrj, oqQYgkM+h, tax) persist because individuals lack conscience. Grammar encodes the solution: individual conscience (feydj) is the *condition* for collective action (cpk,¡). The form *is* the argument.

REASONING: This example demonstrates how verb morphology (participle vs imperative) creates temporal logic that embodies the poem's philosophy. Students often miss that "feydj" is not just "awakening" but "having awakened" — a completed state enabling the next action.

ANSWER: "feydj" (conjunctive participle) marks self-awakening as a completed prerequisite; "cpk,¡" (imperative) commands the subsequent social awakening. The sequential grammar enacts the poem's core thesis: personal conscience must be established before collective moral action can occur. Using two imperatives would flatten this dependency; the participle makes it structural.

## WORKED_EXAMPLE_3
PROBLEM: Compare the compound structures in the negative list (Stanza 2: "Hkhrj dh vkx", "èkuq"k dh Mksjh", "rhj dk uqdhykiu", "oqQYgkM+h dh èkkj", "taxy dh rk"kk gok") and the positive list (Stanza 3: "ufn;ksa dh fueZyrk", "igkM+ksa dk ekSu", "xhrksa dh èkqu", "fe^h dk lksaèkkiu", "iQlyksa dh ygygkgV"). Identify three grammatical differences and explain how they reflect a shift in the poem's vision.

STEPS:
- Step 1: Map the grammatical structure of each item — Negative list: [Tadbhava Abstract Noun] + [Genitive: dh/dk/ki] + [Tadbhava Concrete Noun]. Positive list: [Tatsama/Tadbhava Abstract Noun] + [Genitive: dh/dk/ki] + [Tatsama-heavy Concrete Noun].
- Step 2: Identify Difference 1: Register shift — Negative list uses predominantly Tadbhava words (Hkhrj, èkuq"k, rhj, oqQYgkM+h, taxy, vkx, Mksjh, uqdhykiu, èkkj, rk"kk, gok) rooted in everyday experience of suffering. Positive list introduces Tatsama compounds (fueZyrk, ekSu, èkqu, lksaèkkiu, ygygkgV) suggesting cultivated, refined virtues.
- Step 3: Identify Difference 2: Gender/number agreement in genitive — Negative list mixes "dh" (masc), "dk" (masc), "ki" (fem) based on the *concrete* noun's gender (vkx-masc, Mksjh-fem, uqdhykiu-masc, èkkj-fem, gok-masc). Positive list consistently uses "dh/dk" for masculine abstract nouns (ufn;ksa, fe^h, iQlyksa) and "dk" for masculine concrete nouns (ekSu, èkqu, lksaèkkiu) — but "igkM+ksa dk ekSu" uses "dk" agreeing with "ekSu" (masc). The pattern is less regular, reflecting organic diversity vs rigid corruption.
- Step 4: Identify Difference 3: Semantic density — Negative compounds are mostly transparent (vkx, Mksjh, gok are simple nouns). Positive compounds include complex Tatsama formations: "fueZyrk" (fu+eZyrk = created/produced), "lksaèkkiu" (lksa+èkkiu = beauty-worship), "ygygkgV" (ygy+gkgV = deep-gamboling/joy). These require morphological unpacking, mirroring how virtues require conscious cultivation.
- Step 5: Synthesize thematic shift — The grammar moves from *naming* evils (simple, familiar, Tadbhava) to *constructing* virtues (complex, learned, Tatsama). This mirrors the poem's arc: evils are our default inheritance; virtues are achievements of language and conscience.

REASONING: This worked example combines morphological analysis (Tadbhava vs Tatsama), syntactic analysis (genitive agreement patterns), and semantic analysis (transparency vs density) to show how grammatical contrast enacts thematic transformation — a key skill for Board exam "language usage" questions.

ANSWER: Three grammatical differences: (1) Register: Negative list = Tadbhava (everyday suffering); Positive list = Tatsama-heavy (cultivated virtues). (2) Genitive agreement: Negative list follows concrete noun gender regularly; Positive list shows variation reflecting organic diversity. (3) Morphological density: Negative items are lexically simple; Positive items are morphologically complex compounds (fueZyrk, lksaèkkiu, ygygkgV). Together, these shifts grammatically enact the poem's argument: evils are given, virtues are made — through language, conscience, and effort.

## COMPETENCY_QUESTION_1
QUESTION: In the poem, the line "ukpus osQ fy, [kqyk vk¡xu / xkus osQ fy, xhr" uses the infinitive "fy," (for) twice with different case governances: "ukpus osQ" (genitive) vs "xkus osQ" (genitive). However, the objects "[kqyk vk¡xu" (a little laughter) and "xhr" (sweat/labor) are in different cases — direct vs oblique? Analyze the case governance of "fy," here and explain why the poet might choose this parallel structure despite the objects having different semantic roles (beneficiary vs cost).

COMPETENCY: Grammatical analysis of case governance and parallelism in poetic syntax

STEPS:
- Step 1: Identify that "fy," is an indeclinable (avyaya) meaning "for the sake of", governing the genitive case (osQ) for the beneficiary (ukpus, xkus).
- Step 2: Note that both "ukpus osQ" and "xkus osQ" are genitive phrases — "for children" and "for ploughing/agriculture". The parallelism is at the beneficiary level.
- Step 3: Analyze the objects: "[kqyk vk¡xu" (direct case, masculine singular) is what is *given* to children; "xhr" (direct case, masculine singular) is what is *given* to agriculture. Both are direct objects of an implied verb "give/do".
- Step 4: Explain the poetic effect — The parallel "X osQ fy, Y" structure equates two vastly different acts: giving laughter to children (joy, ease) and giving sweat to fields (toil, necessity). The grammar forces equivalence: both are "for the sake of" their respective beneficiaries.
- Step 5: Conclude — This syntactic parallelism enacts the poem's vision of a just society where nurturing the young and working the land are equally valued, grammatically symmetrical offerings.

ANSWER: "fy," governs genitive "osQ" for both beneficiaries (ukpus, xkus), creating parallel prepositional phrases. The objects "[kqyk vk¡xu" and "xhr" are both direct-case nouns functioning as implied direct objects of "give". The parallel structure "X osQ fy, Y" grammatically equates giving laughter to children with giving sweat to fields — enacting the poem's ideal of a society where care and labor are symmetrically valued offerings.

DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: The poem ends with three lines using the compound structure "FkksM+k&lk fo'okl / FkksM+h&lh mEehn / FkksM+s&ls lius". Analyze the samas type, the morphological pattern of the first member (FkksM+k&lk, FkksM+h&lh, FkksM+s&ls), and explain how this grammatical repetition with variation performs the poem's final vision of society.

COMPETENCY: Morphological analysis of compound variation and thematic performance

STEPS:
- Step 1: Identify the samas — Each is a Bahuvrihi (exocentric) compound describing a society/household: "FkksM+k&lk fo'okl" = "a household/world having happy boys", "FkksM+h&lh mEehn" = "a household having happy girls", "FkksM+s&ls lius" = "a household having happy children".
- Step 2: Analyze the first member variation — "FkksM+k&lk" (masc sg: happy boy), "FkksM+h&lh" (fem sg: happy girl), "FkksM+s&ls" (masc pl: happy children). The stem "FkksM+" (happy) takes gender/number agreement suffixes (-lk, -lh, -ls) matching the implied head noun (boy, girl, children).
- Step 3: Note the second member variation — "fo'okl" (masc: household/world), "mEehn" (fem: household/family), "lius" (masc pl: children/people). Each compound's gender is determined by its second member.
- Step 4: Explain the morphological performance — The repetition of "FkksM+" with systematic agreement variation (lk/lh/ls) enacts *inclusive completeness*: no gender/number is left out. The shift from singular (boy, girl) to plural (children) enacts *collective integration*.
- Step 5: Link to the poem's arc — The opening imperative "vkvks, feydj cpk,¡" (plural, collective) finds its grammatical fulfillment here: a society where happiness is morphologically distributed across all genders and ages. The Bahuvrihi compounds describe the *result* of the awakening: a world *characterized by* happy boys, happy girls, happy children.

ANSWER: The three compounds are Bahuvrihi samas describing a society by its happiest members. The first member "FkksM+" takes systematic agreement suffixes (-lk masc sg, -lh fem sg, -ls masc pl) matching each implied head (boy, girl, children). The second members (fo'okl, mEehn, lius) shift from singular household to plural people. This morphological repetition-with-variation performs the poem's utopian vision: happiness grammatically distributed across all genders and generations, the structural realization of the opening call to collective awakening.

DIFFICULTY: hard