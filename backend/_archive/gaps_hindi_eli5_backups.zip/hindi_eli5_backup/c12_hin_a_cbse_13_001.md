## DEFINITION
"Before You Read: Context and Background" provides essential historical, biographical, and literary context for Chapter 13 "Hkh'e lkguh" — a memoir by Hkh'e lkguh (1915–2003) recounting personal encounters with freedom fighters like Sakharam, Usha, and Kailash Vajpayee during the pre-independence era (c. 1938). It equips students to situate the narrative within the Quit India Movement, understand the author's literary style (colloquial Hindi, short sentences, dialogue-driven narration), and recognize themes of nationalism, personal sacrifice, and human relationships under colonial oppression.

## COGNITIVE_LEVEL
understand

## MASTERY_CRITERIA
The student can independently: (1) explain how the historical context (1938, pre-Quite India) shapes the characters' motivations, (2) identify three stylistic features of Hkh'e lkguh's prose from the introductory note, and (3) predict two major themes the chapter will explore based on the background information.

## SCOPE_BOUNDARY
This node covers ONLY the introductory/contextual material before the main text: author biography, historical setting (1938, freedom struggle), key figures introduced (Sakharam, Usha, Kailash Vajpayee), and literary style markers. It does NOT cover plot analysis, character deep-dives, theme analysis, or textual comprehension — those are addressed in subsequent nodes (c12_hin_a_cbse_13_002 onward).

## WALKTHROUGH
Imagine you're about to watch a film set in 1938 India — you'd want to know: Who's ruling? What's the mood on the streets? Who are the freedom fighters? This node is your "pre-show briefing." Start by reading the author's bio (born 1915, educated at home, MA from Nagpur, worked in journalism) — notice how his life mirrors the nation's transition. Next, mark the historical anchor: "1938, pre-Quit India, Sakharam editing 'Nai Raah'." Then identify the three central figures: Sakharam (revolutionary editor), Usha (his partner), Kailash Vajpayee (young activist). Finally, spot the style clues: "colloquial Hindi," "short sentences," "dialogue-heavy," "imagery-rich." The key insight: this isn't just history — it's personal memory woven into national history.

## DIAGNOSTIC_QUESTION_1
What is the specific historical year anchored in the introductory note of "Hkh'e lkguh," and which nationalist publication was Sakharam associated with at that time?

## DIAGNOSTIC_ANSWER_1
The introductory note explicitly states "lu~ 1938 osQ vklikl dh ckr gS" (this is about 1938) and mentions Sakharam was editing "u;h rkyhe" (Nai Raah) as its "lg&laiknd" (associate editor). A wrong answer (e.g., "1942" or "Quite India Movement") reveals the student is conflating the broader movement with the specific temporal setting of this memoir — a common error where students substitute general knowledge for textual evidence.

## DIAGNOSTIC_QUESTION_2
The author's bio mentions he "mnwZ vkSj vaxzs'kh dk vè;;u LowQy esa fd;k" (studied Marathi and English deeply). How does this bilingual foundation likely influence the narrative style of "Hkh'e lkguh"?

## DIAGNOSTIC_ANSWER_2
The bilingual foundation explains the prose's distinctive blend: "mnwZ 'kCnksa dk iz;ksx fo"k; dks vkReh;rk iznku djrk gS" (Marathi words lend authenticity to the subject) while "iatkch Hkk"kk dh lksaèkh egd Hkh eglwl dh tk ldrh gS" (Sanskritised Hindi's simplicity is also evident). A wrong answer like "it makes the language difficult" misses the nuanced stylistic effect — the text uses Marathi terms (e.g., "xkaèkh," "usg:") for cultural rootedness, not obstruction.

## DIAGNOSTIC_QUESTION_3
Based on the background note, the author describes Kailash Vajpayee as ";kLlsj vjkI+kQkr osQ usr`Ro esa vLFkk;h ljdkj dke dj jgh Fkh" (working in the provisional government in Kailash Vajpayee's capacity). If a student claims Kailash Vajpayee was a British government official, what textual evidence directly contradicts this?

## DIAGNOSTIC_ANSWER_3
The note states: "fI+kQfyLrhu osQ izfr Hkkjr dk joS;k cgqr lgkuqHkwfriw.kZ ,oa leFkZu Hkjk" (India's resentment against the British was intense and widespread) and Kailash Vajpayee is explicitly linked to the "vLFkk;h ljdkj" (provisional government) formed by freedom fighters — not the British administration. The student's error stems from misreading "vLFkk;h" (provisional/revolutionary) as "official" and ignoring the anti-colonial context established in the same paragraph.

## DIAGNOSTIC_QUESTION_4
The introductory note says: "bl ikB osQ ekè;e ls jpukdkj osQ O;fDrRo osQ vfrfjDr jk"Vªh;rk] ns'kizse vkSj varjjk"Vªh; eS=kh tSls eqís Hkh ikBd osQ lkeus mtkxj gks tkrs gSa." Identify two specific textual details from the background that would support the theme of "varjjk"Vªh; eS=kh" (international solidarity).

## DIAGNOSTIC_ANSWER_4
Two supporting details: (1) The author's own international exposure — "V~;wful esa gh mu fnukda ys[kd la?k dh if=kdk ^yksVl* dk laikndh; dk;kZy; gqvk djrk Fkk" (in Berlin, the writers' association journal 'Yuvak' had its editorial office) and (2) The reference to Indian revolutionaries abroad — "Hkkjr ls tkusokys izfrfufèk eaMy esa loZJh deys'oj] tks¯xnjiky] ckyw jko] vCnqy fcfLeYykg vkfn Fks" (Indians going abroad for revolutionary work included Subhas Chandra Bose, Rash Behari Bose, etc.). A weak answer cites only "international names" without linking them to the text's explicit mentions.

## DIAGNOSTIC_QUESTION_5
Evaluate this claim: "The background note portrays Sakharam as a one-dimensional revolutionary icon." Use two specific phrases from the note to defend or refute.

## DIAGNOSTIC_ANSWER_5
The claim is false. The note humanizes Sakharam: "xkaèkh th dk jks"k dk fu;e Fkk" (Sakharam had a rule of humor) and "xkaèkh th dh ns[kjs[k esa mldk bykt py jgk Fkk" (a smile played in Sakharam's gaze) — showing warmth and humor alongside his revolutionary role. A student agreeing with the claim misses these "telling details" that the note deliberately includes to prevent hagiography. The note balances "jk"Vªh;rk" with "eS=kh" (humanity).

## DIAGNOSTIC_QUESTION_6
Create a 3-sentence "pre-reading journal entry" from the perspective of a 1938 college student in Nagpur who has just heard Sakharam speak at Morris College. Incorporate: (a) the colloquial tone of the era, (b) the tension between studies and nationalism, and (c) one Marathi-inflected Hindi word from the text.

## DIAGNOSTIC_ANSWER_6
Sample entry: "Aj Sakharam ji Morris College me bole — unki boli me wo 'xkaèkh' si sadgi thi, jaise koi dost baat kare. Man me sochta hoon: MA karke naukri karun ya 'Nai Raah' ke saath chalun? Babuji kehte hain padhai chhodo, desh bachao." A poor answer uses formal Hindi ("Sakharam ji ne bhashan diya"), omits the Marathi word, or treats nationalism as abstract — missing the lived, colloquial tension the background note establishes.

## COMMON_MISCONCEPTION
Students treat the "Before You Read" section as skimmable trivia — memorizing the author's birth year (1915) but missing the *functional* details: that he worked in journalism ("i=kdkfjrk"), translated Russian stories ("vuqokn"), and lived in Berlin ("V~;wful"). They then struggle later to explain *why* the prose uses journalistic brevity, Russian-literature-like irony, or European references. The error: confusing *biographical facts* with *literary-shaping experiences*. The note isn't a CV — it's a decoder for the text's voice.

## ON_FAILURE
If a student cannot name three style markers from the note (e.g., "mnwZ 'kCnksa dk iz;ksx," "NksVs&NksVs okD;," "laoknksa dk iz;ksx"), have them: (1) Re-read *only* the second paragraph of the author bio with a highlighter, marking every phrase describing language/style. (2) Convert each marked phrase into a "style card" (e.g., "Short sentences → urgency, realism"). (3) Predict how each style card will appear in the main text (e.g., "Short sentences → dialogue scenes with Sakharam"). (4) Verify predictions in c12_hin_a_cbse_13_002 (Plot and Narrative Structure).

## BUILDS_ON
Class 11 "Before You Read" nodes (e.g., c11_hin_ar_cbse_13_001) established the habit of using contextual notes to decode historical setting, authorial voice, and thematic seeds — this node deepens that by adding colonial-era political nuance and multilingual stylistic analysis.

## LEADS_TO
c12_hin_a_cbse_13_002 (Plot and Narrative Structure) — the historical anchors (1938, Sakharam's arrest, Usha's role) and style markers (dialogue-heavy, colloquial) identified here become the scaffolding for analyzing the narrative's non-linear structure and temporal shifts.

## PREREQUISITE_NODE_IDS
c11_hin_ar_cbse_13_001
## PREREQUISITE_REASONS
c11_hin_ar_cbse_13_001: Class 11 Chapter 13's "Before You Read" introduced the protocol of extracting historical context, author biography, and stylistic clues from introductory notes — this node applies that protocol to a more politically complex, multilingual text.

## FORWARD_NODE_IDS
c12_hin_a_cbse_13_002, c12_hin_a_cbse_13_003, c12_hin_a_cbse_13_004, c12_hin_a_cbse_13_005, c12_hin_a_cbse_13_006, c12_hin_a_cbse_13_010, c12_hin_a_cbse_13_012

## FORWARD_REASONS
c12_hin_a_cbse_13_002: The 1938 timeline and Sakharam's editorial role anchor the plot's starting point and inciting incident. c12_hin_a_cbse_13_003: The "lsokxzke" (ward/office) setting and "jsyxkM+h oèkkZ" (Morris College) atmosphere derive from background details. c12_hin_a_cbse_13_004: Sakharam's characterization as humorous ("jks"k dk fu;e"), humane ("bykt"), and revolutionary builds directly on the note's portrayal. c12_hin_a_cbse_13_005: Usha and Kailash Vajpayee's roles are seeded in the background — their dynamics await analysis. c12_hin_a_cbse_13_006: Themes of "jk"Vªh;rk," "ns'kizse," and "varjjk"Vªh; eS=kh" are explicitly named in the note as emerging from the narrative.
c12_hin_a_cbse_13_010: Provides background context essential for understanding historical terms like "lnjeqdke".  
c12_hin_a_cbse_13_012: Context/background knowledge (Partition, Delhi college, literary circles) essential for historical inferences.  
c12_hin_a_cbse_13_003: Provides historical-literary context (Progressive Writers, Emergency) essential for decoding atmosphere.  
c12_hin_a_cbse_13_004: Provides biographical context (Hkh'e lkguh's life, Partition, literary circles) essential to decode the protagonist's historical situatedness.  
c12_hin_a_cbse_13_005: अगला तार्किक चरण: Character analysis of supporting characters involves examining how secondary figures in a narrative... इस नोड की अवधारणाओं को सीधे उपयोग/विस्तारित करता है।  
c12_hin_a_cbse_13_006: Provides historical context (Partition, 1938 setting) essential to interpret the theme's historical dimension.  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
c11_his_cbse_08_001: Class 11 History Chapter 8 ("Nationalism in India") covers the 1930s political landscape — Civil Disobedience, rise of socialist groups, revolutionary press — directly illuminating the "1938, Nai Raah, Sakharam" context. c11_his_cbse_08_002: The same chapter's section on "Revolutionaries and International Links" (Bose, Berlin, provisional government) explains the Kailash Vajpayee / Berlin references in the Hindi note.

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_13_001 -> c12_hin_a_cbse_13_001 -> c12_hin_a_cbse_13_002

## THIS_FORMULA
N/A - conceptual

## FORMULA_VARIABLES
N/A

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
conceptual

## CROSS_SUBJECT
N/A | The 1938 setting, revolutionary press (Nai Raah), and provisional government references in the Hindi text directly mirror History's coverage of late-1930s nationalist strategies, socialist press, and Bose's international networks.
 N/A | The portrayal of Sakharam as editor-activist, Usha as partner-in-struggle, and Kailash Vajpayee in provisional government illustrates Political Science's framework of "civil society resistance," "women in nationalism," and "alternative governance models" during colonial rule.
## PREREQ_CONCEPT
Ability to extract functional literary clues (style, theme seeds, historical anchors) from a textbook's introductory note — not just memorize biographical facts.

## PREREQ_BEFORE
Student must have practiced "Before You Read" analysis in Class 11 (e.g., c11_hin_ar_cbse_13_001) and studied the 1930s nationalist movement in Class 11 History (c11_his_cbse_08_001).

## PREREQ_STUCK
If stuck, revisit c11_hin_ar_cbse_13_001's worked example on "how to mine an introductory note for theme seeds" and c11_his_cbse_08_001's timeline of 1935–1939 nationalist events.

## WORKED_EXAMPLE_1
PROBLEM: A student reads the introductory note and writes: "Author born 1915, MA 1938, worked in Berlin. Themes: patriotism." Diagnose why this response fails Board marking criteria and rewrite it to meet "Context and Background" competency.

STEPS:
- Step 1: Identify what the student included (birth year, education, job) and what they missed (style markers, specific historical anchors, named themes from the note).
- Step 2: Recall Board marking scheme for "Before You Read" questions: 1 mark for historical context, 1 mark for author's literary background, 1 mark for thematic prediction — all must be text-grounded.
- Step 3: Map each required mark to specific phrases in the note: Historical context → "lu~ 1938 osQ vklikl," "u;h rkyhe if=kdk," "fI+kQfyLrhu vLFkk;h ljdkj"; Literary background → "mnwZ vkSj vaxzs'kh dk vè;;u," "vuqoknd osQ in ij," "rel miU;kl"; Thematic prediction → "jk"Vªh;rk," "ns'kizse," "varjjk"Vªh; eS=kh."
- Step 4: Rewrite the response integrating these text-anchored points, using the note's own terminology (e.g., "mnwZ 'kCnksa dk iz;ksx" not just "Marathi influence").
- Step 5: Verify the rewrite covers all three marking points without adding external knowledge.

REASONING: Board exams reward *textual fidelity* — using the note's exact phrases as evidence. Competitive exams (CUET/Humanities) test the same skill: "Based on the passage, which theme is *explicitly signaled*?" The rewrite trains students to treat the note as evidence, not trivia.

ANSWER: Improved response: "The note anchors the narrative in 1938 (pre-Quit India), when Sakharam edited 'Nai Raah' under a provisional government (vLFkk;h ljdkj) linked to revolutionaries like Subhas Bose. Author Hkh'e lkguh's Marathi-English bilingualism (mnwZ vkSj vaxzs'kh dk vè;;u) and translation work (rel miU;kl, vuqoknd) shape a prose style using Marathi words for authenticity (mnwZ 'kCnksa dk iz;ksx), short sentences (NksVs&NksVs okD;), and dialogue (laoknksa dk iz;ksx). The note explicitly signals three themes: vfrfjDr jk"Vªh;rk (embodied nationalism), ns'kizse (patriotism), and varjjk"Vªh; eS=kh (international solidarity via Berlin links)."

## WORKED_EXAMPLE_2
PROBLEM: The note mentions "xkaèkh th dk jks"k dk fu;e Fkk" (Sakharam had a rule of humor) and "xkaèkh th dh ns[kjs[k esa mldk bykt py jgk Fkk" (a smile played in Sakharam's gaze). A student asks: "How can a revolutionary have a 'rule of humor'? Isn't that trivializing?" Use the background note to construct a literary defense of this characterization.

STEPS:
- Step 1: Locate the two phrases in the note and note their placement — they appear *after* the revolutionary credentials (editor of Nai Raah, provisional government associate) and *before* the international solidarity theme.
- Step 2: Identify the literary function: the note uses "jks"k" (humor) and "bykt" (smile) as *humanizing counterweights* to "jk"Vªh;rk" (nationalism) — preventing the "icon trap."
- Step 3: Connect to the author's stated style: "mudh Hkk"kk&'kSyh esa iatkch Hkk"kk dh lksaèkh egd Hkh eglwl dh tk ldrh gS" (simplicity of Sanskritised Hindi) — humor and simplicity are twin markers of accessibility, not grandiosity.
- Step 4: Anticipate the main text: the dialogue-heavy scenes (c12_hin_a_cbse_13_002) will show Sakharam joking with the narrator ("vPNk pyw¡xkA"), laughing at himself ("rw rks ikxy gS!"), using humor to defuse tension.
- Step 5: Formulate the defense: "Humor is not trivialization — it's the text's way of showing revolutionaries as *people*, not posters. The note signals this by placing 'jks"k dk fu;e' right after 'jk"Vªh;rk' — they coexist."

REASONING: This mirrors Board "Critical Thinking" questions (c12_hin_a_cbse_13_013) that ask: "How does the author avoid stereotyping the freedom fighter?" The defense must cite the note's *structure* (juxtaposition) and *style markers* (simplicity, dialogue), not just opinion.

ANSWER: The "rule of humor" is a deliberate literary strategy signaled in the background note. By placing "xkaèkh th dk jks"k dk fu;e Fkk" immediately after establishing his revolutionary gravitas (editor, provisional government, international links), the note structures Sakharam as a *whole human* — nationalism (jk"Vªh;rk) and humanity (eS=kh) together. This aligns with the author's style: colloquial Hindi (mnwZ 'kCn), short sentences (NksVs okD;), and dialogue (laoknksa) all serve accessibility over monumentality. In the main text, this predicts scenes where Sakharam jokes while fleeing ("vPNk pyw¡xk"), laughs at his own disguise ("rw rks ikxy gS"), and uses warmth ("bykt") to recruit the narrator — making his patriotism lived, not performed.

## WORKED_EXAMPLE_3
PROBLEM: Synthesize the background note's three explicit theme signals — "vfrfjDr jk"Vªh;rk" (embodied nationalism), "ns'kizse" (patriotism), "varjjk"Vªh; eS=kh" (international solidarity) — with the author's biographical details (journalism, translation, Berlin stay) to predict *how* each theme will manifest in the narrative's *form* (structure, language, perspective).

STEPS:
- Step 1: List the three themes from the note's second-last paragraph.
- Step 2: List the author's form-shaping experiences: journalism (i=kdkfjrk) → brevity, factual grounding; translation (vuqoknd, rel miU;kl) → irony, layered meaning, cross-cultural lens; Berlin (V~;wful, yksVl) → international perspective, comparative framing.
- Step 3: Map each theme to a formal manifestation:
  - "vfrfjDr jk"Vªh;rk" + journalism → narrative grounded in specific dates/places (1938, Morris College, Nai Raah office), not abstract speeches.
  - "ns'kizse" + translation (Russian lit influence) → patriotism shown through *personal sacrifice* (Usha's risk, Sakharam's humor under pressure), not slogans — Chekhovian irony.
  - "varjjk"Vªh; eS=kh" + Berlin stay → narrative includes foreign characters (German doctor, international students), multilingual dialogue, and a protagonist who *compares* Indian and European realities.
- Step 4: Predict a structural consequence: non-linear chronology (journalism's "inverted pyramid" + memoir's fragmentation) — the note's own structure jumps from 1938 to Berlin to 1938.
- Step 5: Predict a language consequence: code-switching (Marathi/Hindi/English) mirroring the author's "mnwZ vkSj vaxzs'kh" duality and Berlin multilingualism.

REASONING: This synthesis moves beyond "what are the themes" to "how does the author's life shape the *telling* of the themes" — a Board "Literary Devices" (c12_hin_a_cbse_13_008/009) and CUET "Author's Craft" competency. The mapping of biography → form → theme is the analytical core.

ANSWER: 
- Embodied nationalism (vfrfjDr jk"Vªh;rk) → Journalistic precision: narrative opens with "lu~ 1938," "jsyxkM+h oèkkZ," "u;h rkyhe" — specific, verifiable anchors. Structure follows reportage: who, where, when, what.
- Patriotism (ns'kizse) → Translated irony (Russian lit influence): Sakharam's "jks"k dk fu;e," Usha's quiet courage ("v[kckj okyh ?kVuk") — patriotism as *lived detail*, not rhetoric. The note's "chp&chp esa tksM+ fn;k gS" (woven subtly) confirms this.
- International solidarity (varjjk"Vªh; eS=kh) → Berlin lens: narrative includes German doctor ("fno~Q"), international students ("loZJh deys'oj"), code-switched dialogue. The author's "V~;wful esa" experience makes the local global.
- Form synthesis: Fragmented chronology (1938 → Berlin → 1938), multilingual texture (Marathi "xkaèkh," Hindi "usg:," English "professor"), dialogue-driven scenes — all traced to the bio in the note.

## COMPETENCY_QUESTION_1
QUESTION: The introductory note states: "mudh Hkk"kk esa mnwZ 'kCnksa dk iz;ksx fo"k; dks vkReh;rk iznku djrk gS" (Marathi words lend authenticity to the subject). In the main text, you encounter the word "xkaèkh" (Sakharam) — a Marathi name used in Hindi prose. Explain *why* the author retains the Marathi form instead of Hindi "Sakharam" or Sanskritized "Shankaram," and what literary effect this creates for the theme of "vfrfjDr jk"Vªh;rk" (embodied nationalism).

COMPETENCY: Textual Evidence-Based Interpretation
STEPS:
- Step 1: Identify the note's claim about Marathi words → "vkReh;rk" (authenticity/groundedness).
- Step 2: Define "vfrfjDr jk"Vªh;rk" from the note → nationalism rooted in lived, local, bodily experience, not abstract ideology.
- Step 3: Analyze "xkaèkh" vs. "Sakharam/Shankaram": Marathi form preserves regional identity, oral texture, the *sound* of 1938 Maharashtra.
- Step 4: Connect: The name *is* the embodiment — a Maharashtrian revolutionary in a Maharashtrian context, speaking his own name. Hindi/Sanskrit forms would erase that specificity, making nationalism "disembodied."
- Step 5: Conclude: The Marathi name performs the theme linguistically — form enacts content.

ANSWER: The author retains "xkaèkh" (Marathi) because "vfrfjDr jk"Vªh;rk" means nationalism *lived in a specific body, place, and language*. A Hindi "Sakharam" or Sanskritized "Shankaram" would impose a pan-Indian label on a Maharashtrian revolutionary, diluting the "vkReh;rk" (authenticity) the note explicitly values. The Marathi phonetics — the retroflex "èkh," the vowel "xka" — carry the oral history of the region. When the narrator (a Hindi speaker) writes "xkaèkh," he performs cross-linguistic respect: he *keeps* the other's name intact. This mirrors the note's "varjjk"Vªh; eS=kh" — solidarity without erasure. The name itself becomes a micro-manifesto: nationalism that honors linguistic diversity.

DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: The background note describes the author's Berlin phase: "V~;wful esa gh mu fnukda ys[kd la?k dh if=kdk ^yksVl* dk laikndh; dk;kZy; gqvk djrk Fkk" and "Hkkjr ls tkusokys izfrfufèk eaMy esa loZJh deys'oj] tks¯xnjiky] ckyw jko] vCnqy fcfLeYykg vkfn Fks." In the main text, the narrator meets a German doctor ("fno~Q") who treats Sakharam. Using *only* the background note, predict two specific narrative techniques the author will use in this doctor scene to convey "varjjk"Vªh; eS=kh" (international solidarity) — and explain how each technique derives from the author's Berlin experience.

COMPETENCY: Intertextual Prediction from Biographical Context
STEPS:
- Step 1: Extract the two Berlin-experience details: (a) Editorial work on 'Yuvak' (writers' journal) → exposure to *writerly craft*, multilingual literary discourse. (b) Contact with Indian revolutionaries abroad (Bose, Rash Behari, etc.) → *lived* international solidarity, not theoretical.
- Step 2: Predict Technique 1 from (a): The doctor's dialogue will use *literary/medical precision* — not caricature. The author knows how writers observe; the doctor will speak like a professional, not a "foreigner prop." Evidence: "okrkZyki xqtjkrh Hkk"kk" (polished language) in the note.
- Step 3: Predict Technique 2 from (b): The scene will frame the doctor *through Indian eyes* — the narrator noticing what Indians notice (compassion, competence, shared anti-colonialism). Not the doctor's POV. Evidence: "xkaèkh th dh ns[kjs[k esa mldk bykt" — perspective is Indian revolutionary's gaze.
- Step 4: Link both to "varjjk"Vªh; eS=kh": Technique 1 shows solidarity as *professional equality* (doctor = colleague). Technique 2 shows solidarity as *mutual recognition* (Sakharam's smile = "I see you").
- Step 5: Verify against note's explicit theme list: both predictions serve "varjjk"Vªh; eS=kh" without adding external assumptions.

ANSWER: 
1. **Multilingual, professional dialogue for the doctor** — Derived from the author's editorial role at 'Yuvak' in Berlin, where he engaged with writers across languages. The note says the doctor speaks "okrkZyki xqtjkrh Hkk"kk" (polished, articulate language). This avoids "foreign accent" stereotypes; the doctor is a peer, not a prop. Solidarity = linguistic respect.
2. **Focalization through Sakharam's gaze** — Derived from the author's proximity to revolutionaries like Bose in Berlin: he learned to *see international allies as Indians saw them*. The note states "xkaèkh th dh ns[kjs[k esa mldk bykt py jgk Fkk" (a smile played in Sakharam's gaze). The scene will show the doctor *through Sakharam's eyes* — his smile acknowledging shared humanity. Solidarity = mutual recognition, not patronage.
Both techniques are seeded in the note's biography-to-theme pipeline: journalism → craft precision; Berlin revolutionaries → Indian-centered internationalism.

DIFFICULTY: hard