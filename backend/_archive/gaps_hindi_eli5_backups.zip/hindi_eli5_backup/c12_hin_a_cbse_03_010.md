## DEFINITION
Vocabulary in Context refers to the skill of determining the precise meaning of words as they are used in a specific literary text, considering poetic nuance, cultural connotation, and syntactic placement, rather than relying solely on isolated dictionary definitions.

## COGNITIVE_LEVEL
understand

## MASTERY_CRITERIA
The student can accurately explain the contextual meaning of at least 10 key words from the two poems in Chapter 3, differentiate between literal and figurative usage, and demonstrate correct usage in original sentences that reflect the poem's tone.

## SCOPE_BOUNDARY
This node covers the key vocabulary listed in the NCERT 'kCnkFkZ vkSj fVIi.kh' sections for the poems 'nhi vosQyk' and 'eSaus ns[kk] ,d cw¡n' in Chapter 3. It does not cover grammatical analysis (node 011), comprehension questions (node 012), or literary device identification (nodes 008, 009).

## WALKTHROUGH
Imagine you are reading 'nhi vosQyk' and stumble on the word 'lfeèkk' — the dictionary says 'wave' but the poem says ';K dh lkexzh' (play of waves). Why does the poet choose this word to describe a river's movement? Start by reading the stanza aloud, noting the rhythm. Next, locate the word in the NCERT glossary. Then, examine the surrounding imagery: what is the river doing? How does 'play' (lkexzh) change the picture from a mere 'wave'? Finally, connect this to the poem's central idea of joyful, living nature. This process — sound, glossary, imagery, theme — is the repeatable method for every key word.

## DIAGNOSTIC_QUESTION_1
What is the contextual meaning of 'fcjyk' in the line ';g lfeèkkµ,slh vkx gBhyk fcjyk lqyxk,xk' from 'nhi vosQyk'?

## DIAGNOSTIC_ANSWER_1
Correct answer: 'fcjyk' means 'unique' or 'one among many' (cgqrksa esa ,d), describing the river's smile as rare and special. A wrong answer like 'many' or 'common' reveals the student looked only at the root 'fcj' (many) and missed the idiomatic glossary meaning 'cgqrksa esa ,d', ignoring the poetic context of uniqueness.

## DIAGNOSTIC_QUESTION_2
Explain why the glossary defines 've`r&iwr&i;' as 've`r :ih ifo=k nw/' (deep, serious, new) rather than just 'deep' or 'serious' separately.

## DIAGNOSTIC_ANSWER_2
Correct answer: The compound 've`r&iwr&i;' fuses three qualities — depth (ve`r), gravity/seriousness (iwr), and novelty/freshness (i;) — to describe the river's eternal yet ever-renewing flow. A wrong answer listing only 'deep' shows the student treats compound words as additive lists instead of fused poetic images where each component modifies the others.

## DIAGNOSTIC_QUESTION_3
Use the word 'mYyac&ckgq' in a sentence that captures its poetic sense from the line 'mYyac&ckgq] ;g fpj&v[kaM viukikA'.

## DIAGNOSTIC_ANSWER_3
Correct answer: 'The old banyan tree stood mYyac&ckgq, its twisted branches like folded hands in silent prayer.' (Shows 'bent/hunched with age' and dignified endurance). A wrong answer like 'The tired worker sat mYyac&ckgq' misses the poetic dignity and natural imagery (fpj&v[kaM) attached to the word in the poem.

## DIAGNOSTIC_QUESTION_4
Compare the usage of 'lkxj' (in 'lkxj osQ >kx ls') and 'cw¡n' (in ',d cw¡n lglk mNyh') across the two poems. How does the shift in scale alter the emotional tone?

## DIAGNOSTIC_ANSWER_4
Correct answer: 'lkxj' (river) in the first poem suggests vast, flowing life; 'cw¡n' (small stream/rivulet) in the second poem miniaturizes the image to something fragile, personal, and easily lost ('jax xbZ {k.kHkj'). The shift from river to stream mirrors the shift from collective celebration of nature to intimate, personal grief. A wrong answer treating them as synonyms misses the deliberate scaling-down that structures the second poem's elegiac tone.

## DIAGNOSTIC_QUESTION_5
Evaluate the claim: 'The glossary meaning of 'izÑr' as 'LokHkkfod' (worldly/secular) contradicts the spiritual tone of the line ';g izÑr] Lo;aHkw] czã] v;qr% bldks Hkh 'kfDr dks ns nks'.'

## DIAGNOSTIC_ANSWER_5
Correct answer: The claim is false. 'izÑr' here means 'born of this world' (izÑfr ls mRiUu) — the river is a worldly manifestation that still deserves reverence ('kfDr). The poet elevates the secular to the sacred. A wrong answer agreeing with the claim reveals a binary mindset that separates 'worldly' from 'worthy of worship', missing the poem's core philosophy of finding divinity in nature.

## DIAGNOSTIC_QUESTION_6
Create a two-line couplet (doha/chaupai style) using 'fojkV~' and 'mUekspu' that reflects the imagery of 'eSaus ns[kk] ,d cw¡n'.

## DIAGNOSTIC_ANSWER_6
Expected criteria: Couplet must use 'fojkV~' as 'vast/expanse' (cgqr cM+k) and 'mUekspu' as 'absorbing/engulfing' (eqDr djuk), and evoke the sudden loss of color/light. Example: 'fojkV~ akaas mein jab andhera chhaaya, / mUekspu kar liya usne saara ujaala.' A poor answer using 'fojkV~' as 'sky' only (literal) and 'mUekspu' as 'eating' shows failure to transfer poetic connotations to new creative use.

## COMMON_MISCONCEPTION
Students memorize the NCERT glossary meanings as fixed definitions and apply them mechanically in all contexts. For example, they write 'v;qr% = 10' in every answer, missing that in the poem 'v;qr%' means 'complete/perfect' (vlac¼) as a metaphor for the river's fullness. They fail to see that poetic words carry 'surplus meaning' — the glossary gives the anchor, but the context stretches it.

## ON_FAILURE
1. Have the student pick 3 words they got wrong. 2. For each, re-read the specific stanza aloud. 3. Ask: 'What is happening in the image right before and after this word?' 4. Have them write the glossary meaning, then write a second 'poetic meaning' sentence starting with 'In this line, the word suggests...' 5. Re-attempt Diagnostic Questions 3 and 6 for those words only.

## BUILDS_ON
Class 11 Vocabulary in Context (c11_hin_ar_cbse_01_010) where students learned to use glossaries and identify context clues in simpler prose and poetry.

## LEADS_TO
Comprehension: Literal and Inferential Questions (c12_hin_a_cbse_03_012) where precise vocabulary understanding is required to answer 'meaning in context' board questions.

## PREREQUISITE_NODE_IDS
c12_hin_a_cbse_03_001, c12_hin_a_cbse_03_002, c11_hin_ar_cbse_01_010, c12_hin_a_cbse_03_008, c12_hin_a_cbse_03_009

## PREREQUISITE_REASONS
c12_hin_a_cbse_03_001: Provides background on poet vKs; and his linguistic style, essential to anticipate his vocabulary innovations.
c12_hin_a_cbse_03_002: Establishes narrative structure of the poems so students can locate where key words appear.
c11_hin_ar_cbse_01_010: Builds the foundational skill of using NCERT glossary and context clues for Hindi literary texts.
c12_hin_a_cbse_03_008: Vocabulary in context (e.g., "क्षेप", "रुद्रक", "जाक्स कब्बा") requires understanding metaphorical usage to gloss correctly.  
c12_hin_a_cbse_03_009: Vocabulary items like "वोस्यक", "उन्मुक्तता", "जैतून" carry symbolic weight understood only after this node.  

## FORWARD_NODE_IDS
c12_hin_a_cbse_03_011, c12_hin_a_cbse_03_012, c12_hin_a_cbse_03_013, c12_hin_a_cbse_03_014

## FORWARD_REASONS
c12_hin_a_cbse_03_011: Grammar analysis requires knowing the exact lexical category and nuance of key words (e.g., 've`r&iwr&i;' as compound adjective).
c12_hin_a_cbse_03_012: Comprehension questions frequently test 'meaning in context' for these exact glossary words.
c12_hin_a_cbse_03_013: Critical interpretation of themes like 'nature as divine' depends on precise understanding of words like 'izÑr', 'Lo;aHkw', 'fojkV~'.
c12_hin_a_cbse_03_014: Key vocabulary (e.g., "lwjt", "u'ojrk") enables precise quoting.  

## CROSS_SUBJECT_PREREQS
c11_hin_ar_cbse_01_010, c11_hin_v_cbse_01_010
## CROSS_SUBJECT_REASONS
c11_hin_ar_cbse_01_010: Reinforces vocabulary acquisition strategies from Class 11 Antra (prose/poetry) that transfer directly to Class 12 Antra.
c11_hin_v_cbse_01_010: Provides parallel vocabulary practice from Class 11 Vitan (non-fiction), showing how context shifts meaning across genres.

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_01_010 -> c12_hin_a_cbse_03_010 -> c12_hin_a_cbse_03_012

## THIS_FORMULA
Contextual Meaning = Glossary Definition + Syntactic Role + Imagery Cluster + Thematic Resonance

## FORMULA_VARIABLES
Glossary Definition: NCERT provided meaning; Syntactic Role: Part of speech and grammatical function in the line; Imagery Cluster: Associated sensory images in the stanza; Thematic Resonance: Connection to poem's central idea.

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
linguistic

## CROSS_SUBJECT
N/A | Analyzing connotation vs denotation in English poetry (e.g., Keats, Wordsworth) uses the same four-step method: dictionary meaning, syntax, imagery, theme.
 N/A | Understanding sant kavya vocabulary (e.g., 'prem', 'gyan', 'bhakti') requires identical context-sensitive reading where words carry layered spiritual meanings beyond dictionary definitions.
## PREREQ_CONCEPT
Ability to navigate NCERT glossary and distinguish literal vs figurative language in Hindi poetry.

## PREREQ_BEFORE
Student must have read both poems in Chapter 3 at least once and attempted the NCERT 'kCnkFkZ' exercise.

## PREREQ_STUCK
If stuck, revisit Class 11 Antra Chapter 1 Vocabulary node (c11_hin_ar_cbse_01_010) and practice the 'Glossary + Context' two-column note method on 5 words from that chapter.

## WORKED_EXAMPLE_1
PROBLEM: Analyze the word 'Lo;aHkw' in the line ';g izÑr] Lo;aHkw] czã] v;qr% bldks Hkh 'kfDr dks ns nks' from 'nhi vosQyk'.
STEPS:
- Step 1: Locate the word in the NCERT glossary: 'Lo;aHkw' -> 'czãk] Lo;a iSnk gqvk' (pure, self-contained).
- Step 2: Identify syntactic role: It is a predicate adjective in a list of four adjectives ('izÑr] Lo;aHkw] czã] v;qr%') all modifying the implied subject 'nhi' (river).
- Step 3: Examine imagery cluster: The preceding word 'izÑr' (worldly) and following 'czã' (pure/clean) and 'v;qr%' (complete/perfect) create a progression from worldly existence to spiritual perfection.
- Step 4: Determine thematic resonance: The river is 'self-contained' (Lo;a iSnk) — it does not depend on external validation; its purity is intrinsic. This supports the poem's argument that nature deserves reverence for its own sake.
- Step 5: Synthesize: In this context, 'Lo;aHkw' means 'autonomously complete, needing nothing outside itself' — a spiritual quality attributed to a physical river.
REASONING: The four-step method (Glossary -> Syntax -> Imagery -> Theme) prevents the common error of stopping at 'pure' and missing the philosophical weight of 'self-contained' in the poem's argument for nature's intrinsic value.
ANSWER: 'Lo;aHkw' contextually means 'self-contained/autonomously complete', elevating the river from a mere physical entity ('izÑr') to a being of intrinsic spiritual worth ('kfDr').

## WORKED_EXAMPLE_2
PROBLEM: Explain the difference in connotation between 'xksjl' (in ';g xksjlµthou&dkeèksuq dk ve`r&iwr i;') and its common meaning 'new/modern'.
STEPS:
- Step 1: Check glossary: 'xksjl' -> 'nwèk] ngh' (new, fresh).
- Step 2: Note the compound: 'xksjl' modifies 'thou&dkeèksuq' (life-struggle) and connects to 've`r&iwr i;' (deep, serious, new moment).
- Step 3: Analyze imagery: The river's flow is described as 'thou&dkeèksuq' (struggle of life) — a serious, continuous effort. 'xksjl' here does not mean 'modern' but 'ever-renewing', 'fresh at every moment'.
- Step 4: Connect to theme: The poem celebrates the river's eternal newness — it is ancient yet every wave is 'xksjl'. This contrasts with human life where 'new' implies replacement; here 'new' means 'unceasing renewal'.
- Step 5: Formulate answer: In the poem, 'xksjl' = 'perpetually fresh/renewing', not 'recent/modern'.
REASONING: Students often import the contemporary Hindi usage 'xksjl = modern' into poetic contexts. The compound 've`r&iwr&i;' and the noun 'thou&dkeèksuq' force the reading 'ever-fresh' — a nuance only visible through syntactic and thematic analysis.
ANSWER: 'xksjl' in this context means 'ever-renewing, perpetually fresh', describing the river's eternal vitality, not temporal newness.

## WORKED_EXAMPLE_3
PROBLEM: A board exam question asks: 'Explain the significance of the word 'u'ojrk' in the line 'lwus fojkV~ osQ lEeq[k gj vkyksd&Nqvk viukiu gS mUekspu u'ojrk osQ nkx ls!' from 'eSaus ns[kk] ,d cw¡n'.' Write a 3-mark answer.
STEPS:
- Step 1: Quote glossary: 'u'ojrk' -> 'uk'k'khyrk] feVuk' (strangeness, wonder/astonishment).
- Step 2: Identify syntactic context: 'u'ojrk osQ nkx ls' (from the axe/blow of strangeness) — instrumental case showing cause. The 'fojkV~' (vast expanse/sky) 'mUekspu' (absorbs/engulfs) the 'gj vkyksd&Nqvk' (roaring thunder-clouds).
- Step 3: Unpack imagery: The vast sky swallows the terrifying storm; the speaker feels 'u'ojrk' — a mix of alienation ('uk'k'khyrk') and awe ('feVuk') at nature's violent beauty.
- Step 4: Link to poem's core: The poem is about a small stream ('cw¡n') dying ('jax xbZ {k.kHkj'). The 'u'ojrk' is the speaker's realization of nature's indifferent power — the same sky that held the stream now swallows the storm.
- Step 5: Structure 3-mark answer: (1) Meaning: 'u'ojrk' = awe-stricken alienation. (2) Context: Caused by sky engulfing storm. (3) Significance: Marks the moment of confronting nature's sublime indifference, foreshadowing the stream's loss.
REASONING: Board marking scheme awards 1 mark for meaning, 1 for contextual placement, 1 for thematic significance. The worked example models the exact three-move structure examiners expect.
ANSWER: 'u'ojrk' signifies the speaker's awe-stricken alienation ('uk'k'khyrk] feVuk') when the vast sky ('fojkV~') engulfs the roaring storm clouds. This moment of sublime terror reveals nature's indifferent power — the same cosmos that cradled the tiny stream ('cw¡n') now displays its capacity to swallow even thunder. The word marks the poem's turn from intimate grief to cosmic perspective.

## COMPETENCY_QUESTION_1
QUESTION: The word 'v;qr%' appears in the line ';g izÑr] Lo;aHkw] czã] v;qr% bldks Hkh 'kfDr dks ns nks'. The glossary gives three meanings: '10 g”kkj dh la[;k] vlac¼] i`Fkd'. A student writes in the exam: 'v;qr% means ten, so the poet is counting ten qualities of the river.' Identify the error and explain the correct contextual meaning with evidence from the poem's structure.
COMPETENCY: Critical Thinking - Contextual Vocabulary Analysis
STEPS:
- Step 1: Identify the student's error: Applying the primary mathematical meaning ('ten') in a poetic adjectival slot where it functions as a qualitative descriptor.
- Step 2: Note syntactic position: 'v;qr%' is the fourth adjective in a series modifying 'nhi' (river), parallel to 'izÑr', 'Lo;aHkw', 'czã' — all qualitative.
- Step 3: Select appropriate glossary sense: 'vlac¼' (complete) or 'i`Fkd' (perfect) fits the semantic field of 'pure, self-contained, worldly'.
- Step 4: Provide evidence: The poem's refrain 'ij bldks Hkh iafDr dks ns nks' (give it respect too) argues for the river's *complete* worthiness, not a numerical count.
ANSWER: The student commits a 'dictionary-first' error, ignoring syntactic context. 'v;qr%' here means 'complete/perfect' (vlac¼/i`Fkd), describing the river's fullness of being. The list of four adjectives builds a case for the river's total ('v;qr%') worthiness of reverence ('kfDr'), not a count of ten attributes.
DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: Compare the use of 'ekSuk' in ';g eèkq gSµLo;a dky dh ekSuk dk ;qx&lap;]' (nhi vosQyk) with its standard meaning 'Vksdjk] fiVkjk' (shadow/reflection). How does the compound ';qx&lap;' (touch-dialogue) transform the word's connotation to support the poem's philosophy of 'O;fDrxr lÙkk' (individual freedom)?
COMPETENCY: Literary Analysis - Lexical Semantics in Philosophical Context
STEPS:
- Step 1: State standard meaning: 'ekSuk' = shadow/reflection (passive, derivative, insubstantial).
- Step 2: Analyze the compound modifier: ';qx&lap;' = 'touch and dialogue' — implies active, reciprocal, tactile engagement.
- Step 3: Synthesize transformed meaning: 'ekSuk' here becomes 'a presence that engages in dialogue through touch' — not a passive shadow but an interactive manifestation. The mountain's 'shadow' on the river is not a mere reflection; it is a relationship.
- Step 4: Connect to philosophy: 'O;fDrxr lÙkk' (individual freedom) in the poem means freedom *within* relationship, not isolation. The mountain and river are distinct ('O;fDr') but in ';qx&lap;' — the shadow is the medium of their free communion.
- Step 5: Conclude: The poet reclaims 'ekSuk' from 'insubstantial copy' to 'intimate interface', mirroring the poem's redefinition of freedom as 'connection without loss of self'.
ANSWER: Standard 'ekSuk' = passive shadow. Modified by ';qx&lap;', it becomes 'active, dialogic presence' — the mountain's shadow on the river is a tactile conversation between two free entities. This lexical innovation embodies the poem's core philosophy: individual freedom (O;fDrxr lÙkk) is realized not in separation but in mutual, respectful engagement (lekt e”kcwr gksxk).
DIFFICULTY: hard