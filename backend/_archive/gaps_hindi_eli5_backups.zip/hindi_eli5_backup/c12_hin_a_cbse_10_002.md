## DEFINITION
Plot and Narrative Structure refers to the sequence of events (plot) and the technique used to arrange and present those events (narrative structure) in a literary work. In this chapter, the narrative is a first-person autobiographical account that moves non-chronologically, using flashbacks, anecdotes, and thematic associations to depict the author's formative years and the Hindi literary milieu of the early 20th century.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student can map the narrative timeline of the chapter, identify at least three structural devices (e.g., flashback, frame narrative, thematic juxtaposition), and explain how each device shapes the reader's understanding of the author's relationship with Hindi literature.

## SCOPE_BOUNDARY
This node covers only the plot and narrative structure of the prescribed text "izse?ku dh Nk;k&Le`fr" by Kaka Kalelkar (jkepanz 'kqDy) from NCERT Class 12 Hindi Antra Chapter 10. It does not cover general theory of plot types, other chapters, or character/theme analysis in depth (those are separate nodes).

## WALKTHROUGH
Imagine you are asked to summarize this chapter in five sentences but find yourself jumping between the author's childhood, his father's library, meetings with Hazari Prasad Dwivedi, and the atmosphere of Hindi literary circles — all mixed together. That confusion is exactly why we study narrative structure. Begin by reading the text once just to get the "story" — who, what, where. Then, on a second read, mark every time the narrator shifts time (e.g., "16 o"kZ dh voLFkk", "vc", "rhl o"kZ ifgys"). Draw a rough timeline on paper: plot the events in the order they happened in real life, then number them in the order they appear in the text. The gap between the two orders reveals the narrative structure. The key insight: the author uses a thematic, not chronological, architecture to show how literature shaped his identity.

## DIAGNOSTIC_QUESTION_1
What is the primary narrative perspective used in "izse?ku dh Nk;k&Le`fr"?

## DIAGNOSTIC_ANSWER_1
The primary narrative perspective is first-person autobiographical ("esjs", "eSa", "esjh"). A wrong answer (e.g., "third-person omniscient") reveals the student has not recognized the narrator as the author himself recounting his own memories, which is essential for understanding the subjective, selective nature of the narrative.

## DIAGNOSTIC_QUESTION_2
The narrative does not follow a straight chronological order. Give one specific example from the text where the narrator jumps forward or backward in time, and name the structural device used.

## DIAGNOSTIC_ANSWER_2
Example: The narrator begins with his birth (1884) and early education, then jumps to 1905 when he joins the Hindi Word Committee, then flashes back to his childhood memory of hearing about Hazari Prasad Dwivedi ("Hkkjrsanq gfj'panz") — a jump of about 20 years. The device is **analepsis (flashback)**. A wrong answer that simply says "the story moves back and forth" without a concrete textual marker shows the student cannot anchor structural analysis in specific textual evidence.

## DIAGNOSTIC_QUESTION_3
Apply the concept of "frame narrative" to this chapter: Identify the outer frame and the inner story/ies it encloses.

## DIAGNOSTIC_ANSWER_3
Outer frame: The adult narrator reflecting on his literary journey while writing/speaking in the present (implied by phrases like "vc", "rhl o"kZ ifgys"). Inner stories: (1) Childhood memory of father reading Hindi poets, (2) The episode of visiting Hazari Prasad Dwivedi's house unknowingly, (3) Anecdotes about the Hindi literary circle ("fuLlansg" group). A wrong answer that lists only events without distinguishing frame from embedded narratives indicates the student sees a flat list rather than a hierarchical structure.

## DIAGNOSTIC_QUESTION_4
Analyze how the author uses **thematic juxtaposition** (placing contrasting ideas side by side) in the narrative. Provide one pair of juxtaposed elements and explain its effect.

## DIAGNOSTIC_ANSWER_4
Juxtaposition: The rigid, traditional Sanskrit-oriented education of the father ("laLÑr] vaxzs”kh] ck¡Xyk vkSj ¯gnh osQ izkphu rFkk uohu lkfgR;") vs. the vibrant, living Hindi literary world of Hazari Prasad Dwivedi and the "fuLlansg" circle. Effect: Highlights the transition from classical scholarship to modern Hindi literary consciousness, mirroring the author's own intellectual evolution. A wrong answer that merely lists two topics without explaining the contrast or its narrative purpose shows surface-level reading.

## DIAGNOSTIC_QUESTION_5
Evaluate the effectiveness of the non-linear structure in conveying the central theme: "the making of a Hindi writer." Is the fragmentation a strength or a weakness? Justify with two textual reasons.

## DIAGNOSTIC_ANSWER_5
Strength. Reason 1: The fragmentation mimics how memory actually works — associative, not chronological — making the portrayal of literary influence feel organic. Reason 2: By placing the meeting with Dwivedi (the culmination) before the childhood anecdotes (the roots), the narrative creates dramatic irony: the reader knows the significance of "Hkkjrsanq th dk ?kj" before the young narrator does. A wrong answer that calls it "confusing" without linking structure to theme misses the author's artistic intention.

## DIAGNOSTIC_QUESTION_6
Create a one-paragraph "narrative map" of the chapter that a Class 12 student could use for quick revision. It must show the real-life chronological order of 5 key events AND the order they appear in the text.

## DIAGNOSTIC_ANSWER_6
Chronological order: (1) Birth & early education in village (1884–), (2) Father's library & exposure to Hindi poets (childhood), (3) Move to Varanasi, join Hindi Word Committee (1905), (4) Encounter with Hazari Prasad Dwivedi (c. 1920s), (5) Participation in "fuLlansg" literary circle (1930s). Textual order: (3) → (1) → (2) → (4) → (5) with reflective commentary interspersed. A poor answer that lists events only in textual order or only chronologically fails to demonstrate the structural analysis skill.

## COMMON_MISCONCEPTION
Students often assume "plot" means "what happens in order" and therefore try to force this text into a straight timeline. They miss that the *narrative structure* is deliberately thematic: the author groups memories by *literary influence* (father's poets → Dwivedi → peer circle) rather than by date. This error stems from treating autobiographical prose like a novel with a single plotline, ignoring that reflective essays use **associative logic**. For example, a student might write "First he was born, then he met Dwivedi, then he joined the committee" — missing that the text *opens* with the committee, *then* recalls birth, *then* the Dwivedi meeting appears as a flashback within a flashback.

## ON_FAILURE
1. Re-read the text **only for time markers** (underline every phrase indicating time: "lu~ 1884", "lu~ 1905", "16 o"kZ", "rhl o"kZ ifgys", "vc", "igys"). 2. Make a two-column table: Column A = Event, Column B = Time marker in text. 3. Sort Column B by actual historical date; compare with the order in the text. 4. Write one sentence explaining *why* the author placed the committee episode first (hint: it establishes his public identity as a Hindi worker before showing private roots). 5. Re-attempt Diagnostic Question 4 with this table.

## BUILDS_ON
Class 11 understanding of basic narrative elements (chronology, flashback, first-person point of view) from nodes like c11_hin_ar_cbse_01_002 and c11_hin_v_cbse_01_002.

## LEADS_TO
Character Analysis (c12_hin_a_cbse_10_004, c12_hin_a_cbse_10_005) because narrative structure determines how character is revealed; Theme nodes (c12_hin_a_cbse_10_006, c12_hin_a_cbse_10_007) because structure embodies theme.

## PREREQUISITE_NODE_IDS
c12_hin_a_cbse_10_001, c11_hin_ar_cbse_01_002, c11_hin_v_cbse_01_002
## PREREQUISITE_REASONS
c12_hin_a_cbse_10_001: Provides historical/literary context (Hindi renaissance, Kaka Kalelkar's role) essential to grasp why the narrative emphasizes certain events.
c11_hin_ar_cbse_01_002: Introduced basic narrative structure terms (plot, flashback, perspective) in Class 11 Antra prose.
c11_hin_v_cbse_01_002: Reinforced narrative analysis in Class 11 Vitan (different texts, same skills).

## FORWARD_NODE_IDS
c12_hin_a_cbse_10_003, c12_hin_a_cbse_10_004, c12_hin_a_cbse_10_006, c12_hin_a_cbse_10_005, c12_hin_a_cbse_10_007, c12_hin_a_cbse_10_008, c12_hin_a_cbse_10_010, c12_hin_a_cbse_10_012, c12_hin_a_cbse_10_013, c12_hin_a_cbse_10_014

## FORWARD_REASONS
c12_hin_a_cbse_10_003: Setting/atmosphere is conveyed through the same narrative frames (e.g., the "fuLlansg" circle scenes).
c12_hin_a_cbse_10_004: Protagonist (author) is constructed via the narrative's selective memory — structure *is* characterization here.
c12_hin_a_cbse_10_006: Primary theme (formation of a Hindi writer) is enacted by the narrative structure itself.
c12_hin_a_cbse_10_005: Plot knowledge identifies which scenes feature supporting characters.  
c12_hin_a_cbse_10_007: Narrative structure knowledge lets student locate where secondary themes appear, recur, and evolve across the memoir's timeline.  
c12_hin_a_cbse_10_008: Plot/Narrative Structure tells us *where* in the narrative the devices appear (childhood vs. youth vs. maturity) — crucial for tracking extended metaphors across time.  
c12_hin_a_cbse_10_010: Familiarity with the plot ensures the student knows the narrative situation where each word appears.  
c12_hin_a_cbse_10_012: Plot structure tells you *where* to scan for literal answers (early vs. late paragraphs).  
c12_hin_a_cbse_10_013: Understanding narrative structure helps identify how Shukla arranges memories non-chronologically for thematic effect.  
c12_hin_a_cbse_10_014: Plot/Narrative Structure provides the chronological framework to select temporally relevant evidence for biographical writing  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
c12_history_modern_india_literature: The chapter's backdrop — Hindi language movement, Nagari Pracharini Sabha, Dwivedi era — is modern Indian cultural history; structural references to 1905, 1920s align with historical periodization.
c12_english_narrative_techniques: Concepts like frame narrative, analepsis, thematic juxtaposition are universal narratology tools taught in English Core; applying them here reinforces cross-linguistic analytical vocabulary.

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_01_002 -> c12_hin_a_cbse_10_002 -> c12_hin_a_cbse_10_004

## THIS_FORMULA
N/A - conceptual

## FORMULA_VARIABLES
N/A

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
conceptual

## CROSS_SUBJECT
N/A | The narrative's time markers (1905 Hindi Word Committee, 1920s Dwivedi era) correspond to historical phases of the Hindi language movement; analyzing structure requires placing literary anecdotes in their historical moment.
 N/A | Narratological terms (frame story, flashback, thematic juxtaposition, unreliable/self-reflective narrator) are identical in English literary analysis; using them here builds transferable critical vocabulary.
## PREREQ_CONCEPT
Ability to distinguish *story* (fabula: chronological events) from *discourse* (syuzhet: presented order) — introduced in Class 11 narrative analysis.

## PREREQ_BEFORE
Student must be able to identify first-person pronouns and time-sequence words in Hindi prose.

## PREREQ_STUCK
If stuck, review Class 11 node c11_hin_ar_cbse_01_002 "Text: Plot and Narrative Structure" for the story vs. discourse distinction and practice on a simpler text.

## WORKED_EXAMPLE_1
PROBLEM: The chapter opens with the author's birth (1884) and quickly jumps to 1905 (joining Hindi Word Committee). Then, in the middle of describing the committee, he suddenly recalls a childhood memory of hearing about "Hkkjrsanq gfj'panz". Map this sequence and name the structural device.

STEPS:
- Step 1: Identify the opening event — birth and early education (1884–1900s). This is the *earliest* chronological event.
- Step 2: Identify the next event in textual order — 1905, joining the committee in Kashi. This is a *later* chronological event.
- Step 3: Notice the phrase "vc" (then) and "rhl o"kZ ifgys" (three years ago) — but the memory of Hazari Prasad Dwivedi is from *before* 1905 (when the author was a child). The text says: "Hkkjrsanq gfj'panz osQ ukVd osQ lacaèk esa ,d viwoZ eèkqj Hkkouk esjs eu esa txh jgrh Fkh" — this memory is triggered *during* the 1905 narration.
- Step 4: Recognize the device: **Analepsis (flashback) embedded within a chronological narration**. The narrative present is 1905; the flashback goes to childhood (pre-1905).
- Step 5: Interpret: The author uses the committee (his public literary debut) as a trigger to recall the *origin* of his literary passion (Dwivedi's name). Structure mirrors psychological association.

REASONING: The author does not follow a birth-to-death timeline. He starts at a pivotal public moment (1905) and lets memory radiate outward. This is typical of reflective autobiography where *theme* (literary awakening) organizes *time*.

ANSWER: The textual sequence is: (1) Birth/early life → (2) 1905 Committee → (3) Childhood memory of Dwivedi (flashback). Device: Analepsis. The flashback is motivated by thematic association (the committee reminds him of the poet who inspired him).

## WORKED_EXAMPLE_2
PROBLEM: The "fuLlansg" (लुल्लान्सग्) group is introduced in the middle of the chapter (para starting "esjs eqgYys esa dksbZ eqlyeku lc&tt vk x, Fks"). Explain how this episode functions structurally as a **thematic cluster** rather than a chronological next step.

STEPS:
- Step 1: Locate the episode: After the Dwivedi house visit anecdote, the narrator describes a gathering at his father's house where young writers meet — they call themselves "fuLlansg" (from English "fluent"? No, from "fulsome"? Actually a playful coinage).
- Step 2: Check chronology: The "fuLlansg" meetings happened in the 1920s–30s, *after* the Dwivedi meeting (c. 1920) and *after* the author was established. But in the text, it appears *before* the later anecdote about Dwivedi's poetry reading (the "okeuth" episode).
- Step 3: Identify the grouping principle: Both the "fuLlansg" circle and the later Dwivedi poetry reading are **scenes of literary sociability** — the author groups them to show the *community* that shaped him, not their dates.
- Step 4: Name the structural principle: **Thematic juxtaposition / associative clustering**. The narrative moves by *affinity* (literary circles), not *time*.
- Step 5: Effect: The reader experiences the *density* of the literary milieu — multiple generations (father's friends, peers, juniors) interacting — which a strict timeline would fragment.

REASONING: Autobiographical prose often uses "thick description" of a milieu. By clustering scenes of literary conversation, the author builds a composite portrait of the Hindi literary field.

ANSWER: The "fuLlansg" episode is a thematic cluster representing the peer literary community. It is placed next to the Dwivedi anecdote (mentor) to create a structural triad: father's classical circle → mentor Dwivedi → peer group "fuLlansg". Chronology is sacrificed for thematic completeness.

## WORKED_EXAMPLE_3
PROBLEM: The chapter ends with a reflective comment on language: "mikè;k; th ukxjh dks Hkk"kk ekurs Fks vkSj cjkcj ukxjh Hkk"kk fy[kk djrs Fks..." (Michealji knew languages...). How does this ending resolve the narrative structure? Connect to the opening.

STEPS:
- Step 1: Re-read the opening: The author presents his lineage — father a scholar of Sanskrit, Persian, Braj, modern Hindi; author himself educated traditionally then self-taught in modern Hindi literature.
- Step 2: Re-read the closing: The anecdote about Michealji (a Christian scholar?) who wrote Urdu in Devanagari and Hindi in Urdu script, believing "the language developed by cultured people is the true language." This mirrors the author's own hybrid linguistic identity.
- Step 3: Trace the arc: Opening = inheritance (father's classical languages). Middle = discovery (modern Hindi literary world). Closing = synthesis (language as living, script-fluid practice).
- Step 4: Identify the structural closure: **Circular/Reflective closure**. The narrative returns to the *language question* raised implicitly at the start (what is "true" Hindi?), answering it through a final anecdote that embodies the author's philosophy.
- Step 5: Evaluate: The plot (life events) is unresolved — we don't know his later career — but the *narrative structure* achieves thematic closure: the making of a Hindi writer is complete when he embraces linguistic inclusivity.

REASONING: In reflective autobiography, the "plot" is the development of consciousness. The structure is designed to enact that development: from received tradition → contested modernity → integrated vision. The final anecdote is not just another story; it is the *thesis statement* performed as narrative.

ANSWER: The ending resolves the narrative by mirroring the opening's language theme. Opening: father's multilingual scholarship. Closing: Michealji's script-fluid practice. Structure: Circular — the author's journey comes full circle to a mature definition of Hindi. The plot remains open-ended (life continues), but the narrative structure closes the thematic argument.

## COMPETENCY_QUESTION_1
QUESTION: A Class 12 student writes: "The chapter is confusing because it jumps around in time. The author should have written it in order." Using your knowledge of narrative structure, write a 100-word response defending the author's non-linear choice. Use the terms *analepsis*, *thematic clustering*, and *reflective autobiography*.

COMPETENCY: Critical interpretation & metalanguage use
STEPS:
- Step 1: Acknowledge the student's frustration (validate).
- Step 2: Define the genre: reflective autobiography ≠ chronological biography.
- Step 3: Explain analepsis: flashbacks are not errors; they show how memory works.
- Step 4: Explain thematic clustering: grouping by literary influence (father → mentor → peers) reveals intellectual genealogy better than dates.
- Step 5: Conclude: The structure *is* the argument — becoming a writer is associative, not linear.

ANSWER: The confusion arises from expecting a biography, but this is a *reflective autobiography*. The author uses *analepsis* (flashbacks) not randomly, but to mimic how memory links the present (1905 committee) to its psychological roots (childhood hearing of Dwivedi). *Thematic clustering* groups the father's classical circle, Dwivedi's mentorship, and the "fuLlansg" peers into a triad of literary inheritance — a map of *influence*, not a calendar. In this genre, structure *enacts* the theme: becoming a writer is an associative, recursive process. The non-linear form is the content.

DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: The chapter contains a story-within-a-story: the anecdote of the poetry reading at Dwivedi's house where Okeuth reads a poem and Dwivedi jokes "It sounds like [kaHkk Vsfd [kM+h tSls ukfj eqxykus dh". Analyze how this *embedded narrative* functions at three levels: (1) character revelation (Dwivedi), (2) thematic reinforcement (literary criticism), (3) structural mirroring (performance of the very literary culture the chapter describes).

COMPETENCY: Multi-level textual analysis
STEPS:
- Step 1: Summarize the embedded anecdote (Dwivedi's house, poetry reading, humorous critique).
- Step 2: Level 1 — Character: Shows Dwivedi as approachable, witty, rigorous but not pedantic — a living critic, not a statue.
- Step 3: Level 2 — Theme: The joke ("like a crow pecking a wound") enacts *sahridaya* criticism — honest, vivid, rooted in shared literary culture. Reinforces theme: literature as lived conversation.
- Step 4: Level 3 — Structure: The chapter *is* a literary gathering in text form. This anecdote mirrors the chapter's own method: anecdotes, jokes, serious talk mixed. The narrative performs what it describes.
- Step 5: Synthesize: Embedded narrative = microcosm of the whole chapter.

ANSWER: (1) Character: Dwivedi emerges as a critic who blends humour and insight — "okeuth us uhps ls og dfoÙk yydkjk" shows he listens attentively; his joke reveals a mind that sees through pretension. (2) Theme: The metaphor "crow pecking a wound" captures *sahridaya* (empathetic yet sharp) criticism — the ideal reader the chapter itself addresses. (3) Structure: The chapter is a textual *baithak* (gathering); this scene is a *mise en abyme* — a miniature version of the whole. The narrative structure recursively enacts the literary culture it narrates.

DIFFICULTY: hard