## DEFINITION
Vocabulary in Context is the skill of determining the meaning of unfamiliar words by analyzing the surrounding text, including synonyms, antonyms, examples, explanations, and the overall tone of the passage, rather than relying solely on a dictionary.

## COGNITIVE_LEVEL
apply

## MASTERY_CRITERIA
The student can independently identify at least 5 key words from the chapter, explain their contextual meaning using specific textual evidence, and use each word correctly in a new sentence that reflects the story's tone.

## SCOPE_BOUNDARY
This node covers only the key vocabulary listed in the NCERT 'Hkk"kk&f'kYi' section of Chapter 12 (iQ.kh'ojukFk ^js.kq*) and the strategy of using context clues. It does NOT cover grammar rules, literary device analysis, or full comprehension questions — those are addressed in sibling nodes.

## WALKTHROUGH
Imagine you are reading a WhatsApp message from a friend who uses a word you've never seen — you don't run to a dictionary; you look at the emojis, the previous messages, and the situation to guess the meaning. That's exactly what we do with literary vocabulary. First, locate the word in the story (e.g., 'dkcqyh&dk;nk' on page 78). Read the two sentences before and after it. Ask: Is the speaker angry, sad, or sarcastic? Does the word describe a person, action, or feeling? Then match the clues to the meaning. The key insight: context is a puzzle — the surrounding words are the pieces that reveal the picture.

## DIAGNOSTIC_QUESTION_1
What is the meaning of the phrase 'dkcqyh&dk;nk' as used in the story when Gjxksfcu says it to the midwife?

## DIAGNOSTIC_ANSWER_1
The phrase means 'a pointless, futile activity' or 'waste of effort' — Gjxksfcu uses it to dismiss the midwife's traditional practice of massaging the newborn as outdated and useless. A wrong answer like 'a type of massage' shows the student ignored the speaker's dismissive tone and the contrast with modern medicine.

## DIAGNOSTIC_QUESTION_2
Explain in your own words why the author chooses the compound word 'jkse&jkse dyius yxk' instead of simply writing 'dyius yxk' (heart sank).

## DIAGNOSTIC_ANSWER_2
The reduplication 'jkse&jkse' intensifies the emotion, showing a repeated, heavy sinking feeling — not a momentary disappointment but a deep, growing dread as Gjxksfcu realizes the village's ignorance. A wrong answer like 'it means very sad' misses the rhythmic, cumulative effect that mirrors the character's spiraling anxiety.

## DIAGNOSTIC_QUESTION_3
In the sentence 'cM+h cgqfj;k [kkst [kcj u ysuk' (the midwife did not take any news of the child), identify the context clue that reveals the meaning of '[kkst [kcj' and explain how it works.

## DIAGNOSTIC_ANSWER_3
The clue is the following phrase 'tkudkjh izkIr u djuk' (did not make information known) — the parallel structure shows '[kkst [kcj' means 'to ignore completely / not acknowledge'. A student who answers 'she didn't bring news' fails to see the grammatical parallelism that defines the idiom.

## DIAGNOSTIC_QUESTION_4
Compare the use of 'vxguh èkku' (adverse time) and 'eksfnvkbu' (midwife) in the story. How does the context shift the connotation of 'vxguh èkku' from a neutral time reference to a thematic symbol?

## DIAGNOSTIC_ANSWER_4
Initially 'vxguh èkku' refers to the difficult hour of childbirth, but through repetition in the midwife's lament ('vxguh èkku osQ le; cky&cPpksa dks ysdj...'), it becomes a symbol of systemic neglect of rural women. A weak answer treats both as literal time references, missing the thematic elevation through contextual repetition.

## DIAGNOSTIC_QUESTION_5
Evaluate whether the glossary definition 'lans'kokgd = lans'k igq¡pkus okyk' (one who brings message) is sufficient for understanding the word's role in the climax where the midwife is called 'laofn;k MVdj [kkrk gS vkSj viQj dj lksrk gS'.

## DIAGNOSTIC_ANSWER_5
The definition is necessary but insufficient — the context adds irony: the midwife 'brings the message' of death (viQj) not life, subverting the traditional role. A student who accepts the dictionary meaning alone misses the tragic irony central to the story's critique of superstition.

## DIAGNOSTIC_QUESTION_6
Create a new sentence using 'cgqfj;k' (midwife) that reflects the dignity and exhaustion the character embodies in the final scene, not just the dictionary meaning.

## DIAGNOSTIC_ANSWER_6
Example: 'The cgqfj;k sat motionless on the cot, her hands still stained with the birth she couldn't save, waiting for a thank-you that would never come.' A poor answer like 'The cgqfj;k delivered the baby' reduces a complex character to a functional label, ignoring the contextual weight of 'Hkw[kh&I;klh' (exhausted) and 'flldrh' (trembling) from the text.

## COMMON_MISCONCEPTION
Students treat vocabulary learning as memorizing glossary definitions. In this chapter, they write 'dkcqyh&dk;nk = futile' without realizing the word carries the *speaker's contempt for tradition* — the meaning lives in the *attitude*, not the dictionary. They miss that 'viQjuk' means 'to swallow life' (metaphor for causing death) not just 'to eat', because they don't connect it to the midwife's role reversal from life-giver to death-bringer.

## ON_FAILURE
1. Return to the text and highlight every occurrence of the target word (use c12_hin_a_cbse_12_002 for plot location). 2. For each occurrence, write: speaker, listener, emotion, and immediate context. 3. Build a 'context map' showing how meaning shifts across scenes. 4. Re-attempt Diagnostic Questions 3 and 5 using this map. 5. If still stuck, review c11_hin_ar_cbse_01_010 (Class 11 Vocabulary in Context) for the basic 4-clue strategy (synonym, antonym, example, explanation).

## BUILDS_ON
The skill of identifying context clues (synonym, antonym, example, general sense) introduced in Class 11 Vocabulary nodes.

## LEADS_TO
Grammar: Language Usage in the Text (c12_hin_a_cbse_12_011) where these words are analyzed for morphological structure and syntactic function.

## PREREQUISITE_NODE_IDS
c12_hin_a_cbse_12_001, c12_hin_a_cbse_12_002, c12_hin_a_cbse_12_003, c12_hin_a_cbse_12_004, c12_hin_a_cbse_12_005, c12_hin_a_cbse_12_006, c12_hin_a_cbse_12_007, c12_hin_a_cbse_12_008, c12_hin_a_cbse_12_009, c11_hin_ar_cbse_01_010, c11_hin_ar_cbse_02_010, c11_hin_ar_cbse_03_010
## PREREQUISITE_REASONS
c12_hin_a_cbse_12_001: Provides background on rural midwifery customs essential for understanding 'cgqfj;k' and 'eksfnvkbu'.
c12_hin_a_cbse_12_002: Plot structure locates where each key word appears (e.g., 'dkcqyh&dk;nk' in the confrontation scene).
c12_hin_a_cbse_12_003: Setting (village vs. city) explains the clash in 'vxguh èkku' usage.
c12_hin_a_cbse_12_004: Protagonist Gjxksfcu's modern education shapes his dismissive vocabulary.
c12_hin_a_cbse_12_005: Midwife's characterization gives emotional weight to 'Hkw[kh&I;klh' and 'flldrh'.
c12_hin_a_cbse_12_006: Primary theme (tradition vs. modernity) frames the irony in 'laofn;k'.
c12_hin_a_cbse_12_007: Secondary theme (gender neglect) deepens 'cgqfj;k' beyond 'midwife'.
c12_hin_a_cbse_12_008: Imagery of 'phj&gj.k yhyk' (trembling hands) contextualizes 'viQjuk'.
c12_hin_a_cbse_12_009: Irony in 'laofn;k MVdj [kkrk gS vkSj viQj dj lksrk gS' requires vocabulary precision.
c11_hin_ar_cbse_01_010: Introduced the 4 context-clue types used here.
c11_hin_ar_cbse_02_010: Practiced context-clue strategy on shorter texts.
c11_hin_ar_cbse_03_010: Applied strategy to character-specific vocabulary.

## FORWARD_NODE_IDS
c12_hin_a_cbse_12_011, c12_hin_a_cbse_12_012, c12_hin_a_cbse_12_013, c12_hin_a_cbse_12_014, c12_hin_a_cbse_12_015
## FORWARD_REASONS
c12_hin_a_cbse_12_011: Vocabulary mastery enables analysis of compound formation (dkcqyh&dk;nk) and idiomatic syntax ([kkst [kcj).
c12_hin_a_cbse_12_012: Comprehension answers require precise word meanings (e.g., 'eksfnvkbu' vs 'cgqfj;k' distinction).
c12_hin_a_cbse_12_013: Critical interpretation of 'laofn;k' as ironic symbol depends on vocabulary depth.
c12_hin_a_cbse_12_014: Writing tasks (character sketch, thematic essay) demand accurate, contextual word use.
c12_hin_a_cbse_12_015: Discussion points on rural healthcare use this vocabulary for authentic expression.

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
c12_history_primary_sources_analysis: Understanding archaic or region-specific terms (like 'eksfnvkbu') in historical documents uses the same context-clue strategy.
c12_english_literary_vocabulary: Analyzing connotation shifts in literary texts (e.g., 'vxguh èkku' from literal to symbolic) transfers directly to English poetry/prose analysis.

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_01_010 -> c12_hin_a_cbse_12_010 -> c12_hin_a_cbse_12_011

## THIS_FORMULA
Context-Clue Strategy: (1) Locate word in text → (2) Read 2 sentences before/after → (3) Identify clue type (synonym/antonym/example/explanation/tone) → (4) Infer meaning → (5) Verify with glossary/dictionary → (6) Use in new contextual sentence.

## FORMULA_VARIABLES
N/A

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
linguistic

## CROSS_SUBJECT
N/A | Both require inferring meaning of obsolete/region-specific terms from surrounding textual evidence without external references.
 N/A | Both analyze how repeated contextual usage transforms a word's connotation (e.g., 'vxguh èkku' → symbol of systemic failure).
## PREREQ_CONCEPT
The 4 basic context-clue types: synonym, antonym, example, general sense (taught in Class 11).

## PREREQ_BEFORE
Student must be able to locate a word in the text and read the surrounding paragraph fluently.

## PREREQ_STUCK
If stuck, review the 'Context Clue Flowchart' from c11_hin_ar_cbse_01_010 — specifically the decision tree for compound words like 'dkcqyh&dk;nk'.

## WORKED_EXAMPLE_1
PROBLEM: Determine the contextual meaning of 'dkcqyh&dk;nk' (page 78) and explain how the author uses it to reveal Gjxksfcu's attitude toward tradition.
STEPS:
- Step 1: Locate the word — Gjxksfcu says it to the midwife when she massages the newborn: 'dkcqyh&dk;nk rks rqeus [kwc lh[kk gS'.
- Step 2: Read surrounding context — He calls it 'pqi ugha jg ldk' (no longer works) and contrasts with 'fuekSfN;s' (medicine). The midwife is 'eksfnvkbu reddj [kM+h gks xbZ' (midwife got angry).
- Step 3: Identify clue type — Antonym clue: 'fuekSfN;s' (medicine) is presented as the effective alternative; tone clue: 'pqi ugha jg ldk' shows dismissal.
- Step 4: Infer meaning — 'dkcqyh&dk;nk' = outdated, futile practice with no real effect.
- Step 5: Verify with glossary — 'dkcqyh&dk;nk' is not in the given glossary, but 'dkcqyh' implies 'futile' (from 'dkcqyh' = useless), consistent with inference.
- Step 6: Connect to attitude — The word choice shows Gjxksfcu's modern, rationalist contempt for traditional knowledge.
REASONING: This 6-step process moves from textual evidence to inferential meaning to thematic significance — exactly what board exams require in 'Hkk"kk&f'kYi' questions.
ANSWER: 'dkcqyh&dk;nk' contextually means 'a futile, outdated ritual'; it characterizes Gjxksfcu as dismissive of tradition and confident in scientific modernity.

## WORKED_EXAMPLE_2
PROBLEM: The glossary defines 'viQjuk' as 'isV Hkjdj [kkuk' (swallowing life). Using the climax scene (page 84), explain how the context transforms this into a metaphor for the midwife's tragic role reversal.
STEPS:
- Step 1: Locate 'viQjuk' — 'laofn;k MVdj [kkrk gS vkSj viQj dj lksrk gS' (the messenger eats and destroys life).
- Step 2: Analyze immediate context — The midwife sits 'Hkw[kh&I;klh' (exhausted), 'flldrh' (trembling), having 'fny dks dM+k fd;k' (given the final blow). She brought the message of death, not life.
- Step 3: Identify clue type — Irony clue: 'laofn;k' traditionally brings news of birth (life); here she brings death. The verb 'viQjuk' (swallow/destroy) contrasts with her life-giving role.
- Step 4: Infer metaphorical meaning — 'viQjuk' = to extinguish life, to be the agent of death despite being a birth attendant.
- Step 5: Trace thematic arc — Earlier she 'eksfnvkbu reddj [kM+h gks xbZ' (midwife got angry at being called useless); now she embodies the very uselessness Gjxksfcu accused her of.
- Step 6: State thematic function — The word encapsulates the story's critique: superstition and neglect turn life-givers into death-bringers.
REASONING: This example shows how vocabulary analysis feeds directly into thematic interpretation (c12_hin_a_cbse_12_006/007) and irony analysis (c12_hin_a_cbse_12_009).
ANSWER: Context transforms 'viQjuk' from a literal 'swallowing' into a metaphor for the midwife's tragic complicity in infant mortality due to systemic neglect.

## WORKED_EXAMPLE_3
PROBLEM: Compare the contextual meanings of 'cgqfj;k' and 'eksfnvkbu' — both mean 'midwife' but are used differently. Explain the distinction using textual evidence from pages 78-84.
STEPS:
- Step 1: List occurrences — 'eksfnvkbu' used by narrator (page 78: 'eksfnvkbu cM+cM+krh'), by Gjxksfcu (page 79: 'eksfnvkbu dkdh'), by villagers (page 80: 'eksfnvkbu osQ vkslkjs'). 'cgqfj;k' used by Gjxksfcu (page 80: 'cM+h cgqfj;k'), by narrator (page 81: 'cM+h cgqfj;k osQ cM+s HkkbZ'), by midwife herself (page 83: 'cM+h cgqfj;k dk lgh laokn').
- Step 2: Analyze speaker perspective — 'eksfnvkbu' is the traditional, respectful term used by community; 'cgqfj;k' is the formal, slightly distant term used by the educated protagonist and narrator.
- Step 3: Identify contextual shift — When Gjxksfcu speaks *to* her, he uses 'cM+h cgqfj;k' (formal, respectful address); when speaking *about* her dismissively, he says 'eksfnvkbu dkdh' (that midwife's futile act).
- Step 4: Note midwife's self-reference — She says 'cM+h cgqfj;k dk lgh laokn' — adopting the formal term to assert professional identity.
- Step 5: Synthesize distinction — 'eksfnvkbu' = social role in tradition; 'cgqfj;k' = professional identity in transition. The shift marks the conflict between tradition and modernity.
- Step 6: Apply to exam answer — In a board question 'Distinguish between eksfnvkbu and cgqfj;k', use this speaker-based analysis with 3 textual citations.
REASONING: This multi-step comparative analysis mirrors the 'compare and contrast' competency questions in CBSE Hindi Core (5-mark questions).
ANSWER: 'eksfnvkbu' reflects the community's traditional view; 'cgqfj;k' reflects the modern, professional self-image. The code-switching reveals the central tension of the story.

## COMPETENCY_QUESTION_1
QUESTION: In the sentence 'gjxksfcu us ns[kh viuh vk¡[kksa ls nzkSinh dh phj&gj.k yhyk' (Gjxksfcu saw the trembling of the midwife's old hands), the phrase 'phj&gj.k yhyk' is not in the glossary. Using context clues from the entire story, deduce its meaning and explain why the author chose this compound phrase instead of a simple word like 'kpjuk' (trembling).
COMPETENCY: Contextual Inference and Author's Craft
STEPS:
- Step 1: Break down 'phj&gj.k' — 'phj' (tremor) + 'gj.k' (vibration) = intense, visible shaking.
- Step 2: Locate in context — Page 79, when Gjxksfcu confronts her about the massage. She is 'cM+cM+krh' (old), 'xkyh nsrh' (drying up), and just been insulted.
- Step 3: Identify clue type — Physical description clue ('cM+cM+krh', 'xkyh nsrh') + emotional cause (insult, fear of obsolescence).
- Step 4: Infer meaning — 'phj&gj.k yhyk' = uncontrollable, age-and-emotion-fueled trembling that reveals vulnerability.
- Step 5: Explain author's choice — 'kpjuk' is neutral; 'phj&gj.k yhyk' uses onomatopoeic reduplication to make the reader *feel* the frailty and the injustice of a life's work being dismissed.
ANSWER: 'phj&gj.k yhyk' means 'violent, pitiable trembling of aged hands'; the compound phrase embodies the midwife's physical decay and emotional devastation, making the reader witness her dignity crumble — a simple verb could not carry this thematic weight.
DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: The story uses 'vxguh èkku' (adverse time) three times in the final pages (83-84). Trace each occurrence, analyze how the context shifts its meaning from literal to symbolic, and argue whether this lexical repetition is a device of emphasis or irony.
COMPETENCY: Lexical Tracking and Literary Device Analysis
STEPS:
- Step 1: Find all three occurrences — (a) 'vxguh èkku osQ le; cky&cPpksa dks ysdj' (page 83, midwife's lament), (b) 'vxguh èkku dk pwM+k gS' (page 84, narrator describing Gjxksfcu's departure), (c) 'vxguh èkku... xk¡o dk rkM+ flj m¡Qpk djosQ' (page 84, village atmosphere).
- Step 2: Analyze context of each — (a) Midwife blames 'vxguh èkku' for children being taken away — externalizes guilt. (b) Narrator calls Gjxksfcu's entrapment 'vxguh èkku ka pwM+k' — ironic, he brought it on himself. (c) Village's collective 'vxguh èkku' — systemic, not individual.
- Step 3: Identify shift — Literal (difficult hour) → Psychological (excuse) → Ironic (self-inflicted) → Systemic (village fate).
- Step 4: Evaluate device — It is *both*: emphasis through repetition creates a leitmotif; irony emerges from the gap between who suffers (women/children) and who speaks the phrase (midwife as excuse, narrator as critique).
- Step 5: Formulate argument — The repetition is primarily ironic because the 'adverse time' is not fate but the result of patriarchal neglect — the word becomes an indictment.
ANSWER: 'vxguh èkku' evolves from a temporal marker to a symbol of systemic failure; the repetition is ironic because the characters attribute to fate what is actually human-made neglect.
DIFFICULTY: hard