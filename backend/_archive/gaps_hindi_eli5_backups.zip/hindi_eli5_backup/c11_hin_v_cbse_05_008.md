## DEFINITION
Imagery refers to the use of descriptive language that appeals to the five senses (sight, sound, smell, taste, touch) to create vivid mental pictures. Metaphor is a figure of speech that directly compares two unrelated things by stating one *is* the other, without using "like" or "as", to transfer qualities and deepen meaning.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student can independently identify specific instances of imagery and metaphor in the chapter, explain their sensory appeal and comparative logic, and write a structured analytical paragraph (Point-Evidence-Explanation-Link) showing how these devices reinforce the chapter's central themes.

## SCOPE_BOUNDARY
This node covers the identification, classification (visual, auditory, olfactory, tactile, gustatory), and thematic analysis of imagery and metaphor *only* within the chapter "jktLFkku dh jtr cw¡nas". It does not cover simile, personification, irony, symbolism, or grammatical structures, which are addressed in sibling nodes.

## WALKTHROUGH
Imagine you are reading a thriller novel late at night; the author writes "the silence screamed in his ears" and suddenly you *feel* the tension in your own chest. That is the power of metaphor and imagery. To begin analysing them in this chapter, first re-read the key descriptive passages (the opening village scene, the protagonist's inner monologue, the climax) with a pencil in hand. Mark every phrase that makes you see, hear, smell, or feel something — these are your imagery candidates. Next, circle any direct comparison where object A is called object B (e.g., "his hope was a flickering diya"). Ask: what quality of B is being given to A? Finally, connect each device to the chapter's themes of resilience, darkness vs. light, or societal pressure. The key insight: these devices are not decoration; they are the engine that makes the theme *felt*, not just understood.

## DIAGNOSTIC_QUESTION_1
Define "metaphor" and give one example from everyday Hindi usage (not from the textbook).

## DIAGNOSTIC_ANSWER_1
A metaphor is a direct comparison between two unlike things stating one *is* the other (e.g., "समय पैसा है" — Time is money). A wrong answer (e.g., defining it as using "like/as" or giving a simile example like "बहादुर जैसे शेर") reveals the student confuses metaphor with simile and lacks the core concept of implicit identity transfer.

## DIAGNOSTIC_QUESTION_2
In the chapter, the author describes the night as "अंधेरे की चादर" (a blanket of darkness). Is this imagery, metaphor, or both? Explain your reasoning in two sentences.

## DIAGNOSTIC_ANSWER_2
It is both: "चादर" (blanket) creates a tactile imagery of weight and coverage, while the direct equation "night *is* a blanket" is a metaphor transferring qualities of comfort/smothering. A wrong answer identifying only one device shows the student cannot see how a single phrase can function on multiple literary levels simultaneously.

## DIAGNOSTIC_QUESTION_3
Find a passage in the chapter where auditory imagery (sound) is used to build tension. Quote the phrase (or describe it closely) and explain *how* the sound description creates tension.

## DIAGNOSTIC_ANSWER_3
Example: "सन्नाटे में घड़ी की टिक-टिक धड़कन जैसी लगी" (the clock's tick-tock in the silence felt like a heartbeat). The onomatopoeic "टिक-टिक" mimics the sound, and the comparison to a heartbeat (simile supporting imagery) accelerates the reader's pulse. A wrong answer quoting visual description ("अंधेरा घना था") shows inability to distinguish sensory modes or link technique to effect.

## DIAGNOSTIC_QUESTION_4
Compare the metaphor "जिंदगी एक बोझ है" (life is a burden) with "जिंदगी एक नदी है" (life is a river). How does each metaphor shape a *different* understanding of the protagonist's struggle in the chapter?

## DIAGNOSTIC_ANSWER_4
"Burden" implies weight, exhaustion, and a desire to drop it — aligning with despair. "River" implies flow, inevitability, and a destination — aligning with endurance. The chapter uses the latter. A wrong answer treating them as synonymous reveals failure to analyze the *specific* conceptual mapping (entailments) each vehicle brings to the tenor.

## DIAGNOSTIC_QUESTION_5
Critique this student claim: "The metaphor 'आशा की किरण' (ray of hope) is clichéd and therefore ineffective in the chapter's climax." Defend or refute using textual reasoning.

## DIAGNOSTIC_ANSWER_5
Refute: While common, its effectiveness here depends on *contextual preparation* — the chapter builds prolonged darkness imagery (visual/tactile) making the "ray" a sharp sensory contrast. The metaphor works because it *resolves* the established imagery pattern. A wrong answer agreeing without textual evidence shows inability to evaluate device-function-in-context versus isolated label.

## DIAGNOSTIC_QUESTION_6
Write a 3-line original metaphor poem (in Hindi or English) capturing the central conflict of the chapter, using *only* metaphors (no similes, no direct statements of theme).

## DIAGNOSTIC_ANSWER_6
Example:  
"सपने टूटे शीशे हैं, पैर काटते हर कदम पर।  
समाज दीवार है, ऊँची, चिकनी, बिन दरवाज़े।  
फिर भी, हौसला हथौड़ा है — दीवार में दरार डालता।"  
A poor answer using similes ("जैसे") or abstract statements ("वह संघर्ष करता है") reveals the student cannot *generate* the device they are supposed to analyze, indicating surface-level understanding.

## COMMON_MISCONCEPTION
Students believe imagery is *only* visual description (e.g., "the sky was blue") and miss auditory, olfactory, tactile, and gustatory imagery. They also think a metaphor is "just a fancy word for comparison" and fail to see that the *vehicle* (the image used) carries specific cultural/emotional baggage (e.g., "दीया" implies fragility, temporariness, sacredness — unlike "bulb"). This error stems from middle-school definition-memorization without analyzing *how* the comparison reshapes meaning in a specific text.

## ON_FAILURE
1. Take the student to a well-known Hindi poem (e.g., Nirala's "सरोज स्मृति") and explicitly label *five* sensory images in the first stanza. 2. Give two sentences: "वह शेर है" vs "वह शेर जैसा है". Ask: "Which one makes 'he' *become* the lion? What qualities of lion now belong to 'he'?" 3. Return to the chapter: pick one metaphor, list 3 qualities of the vehicle, and match each to the protagonist's situation. 4. Assign a 5-sentence PEEL paragraph writing task on *one* metaphor.

## BUILDS_ON
Thorough understanding of the chapter's primary theme (resilience against oppression) and the protagonist's psychological landscape (from Theme and Character nodes).

## LEADS_TO
Analysis of irony and symbolism (node 009), where metaphorical objects (like the lamp) become symbols with fixed cultural meanings, and irony arises from the gap between the metaphor's promise and reality.

## PREREQUISITE_NODE_IDS
c11_hin_v_cbse_05_001, c11_hin_v_cbse_05_002, c11_hin_v_cbse_05_003, c11_hin_v_cbse_05_004, c11_hin_v_cbse_05_006, c11_hin_v_cbse_05_007

## PREREQUISITE_REASONS
c11_hin_v_cbse_05_001: Context/background knowledge is needed to understand the socio-cultural weight of metaphors (e.g., "diya" in Indian tradition).  
c11_hin_v_cbse_05_002: Plot structure tells *where* key descriptive passages occur (climax, resolution).  
c11_hin_v_cbse_05_003: Setting/atmosphere analysis provides the sensory baseline (darkness, silence) that imagery builds upon.  
c11_hin_v_cbse_05_004: Protagonist's character traits determine which metaphors attach to them (e.g., "hammer" suits a resilient character).  
c11_hin_v_cbse_05_006: Primary theme (hope/resilience) is the *target* that all imagery and metaphor serve; without it, analysis is aimless.
c11_hin_v_cbse_05_007: Imagery/metaphor (e.g., well as "breathing body") are the vehicles of secondary themes.  

## FORWARD_NODE_IDS
c11_hin_v_cbse_05_009, c11_hin_v_cbse_05_013, c11_hin_v_cbse_05_014, c11_hin_v_cbse_05_012, c11_hin_v_cbse_05_015, c12_hin_a_cbse_02_008, c12_hin_a_cbse_04_008, c12_hin_a_cbse_05_008

## FORWARD_REASONS
c11_hin_v_cbse_05_009: Irony and symbolism extend metaphor analysis — a metaphor repeated structurally becomes a symbol; irony often subverts a metaphor's expectation.  
c11_hin_v_cbse_05_013: Critical thinking requires synthesizing device analysis into interpretive arguments about authorial intent.  
c11_hin_v_cbse_05_014: Writing skills (analytical paragraph, essay) directly apply the PEEL structure practiced here.
c11_hin_v_cbse_05_012: Imagery/metaphor recognition enables inference of symbolic meaning beyond literal description.  
c11_hin_v_cbse_05_015: Imagery/metaphor identification enables literary device-based points  
c12_hin_a_cbse_02_008: Advanced practice in Vitan final chapter.  
c12_hin_a_cbse_04_008: Synthesis of devices in long poem — holistic analysis.  
c12_hin_a_cbse_05_008: Practices device identification in unseen passages.  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
none

## CHAIN_DESCRIPTION
c11_hin_v_cbse_05_006 -> c11_hin_v_cbse_05_008 -> c11_hin_v_cbse_05_009

## THIS_FORMULA
N/A - conceptual

## FORMULA_VARIABLES
N/A

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
analytical

## CROSS_SUBJECT
c11_history_indian_national_movement | The chapter's metaphors of "darkness" (colonial oppression) and "light" (freedom struggle) mirror historical narratives; analyzing literary devices here builds skill for interpreting political speeches and nationalist poetry.  
c11_geography_human_geography | Imagery of landscape (river, barren land) in the chapter reflects human-environment interaction concepts; geographical terms like "arid", "fertile" become metaphorical vehicles for social conditions.

## PREREQ_CONCEPT
Ability to distinguish literal from figurative language and to articulate the *tenor* (subject) and *vehicle* (image) of a metaphor.

## PREREQ_BEFORE
Student must have read the full chapter at least once and completed the plot, setting, character, and theme nodes (001-007).

## PREREQ_STUCK
Re-read the chapter summary and theme analysis (node 006) to anchor device-hunting in the central idea of "struggle and hope".

## WORKED_EXAMPLE_1
PROBLEM: Analyze the visual and tactile imagery in the opening description of the village lane (first two paragraphs) and explain how it establishes the chapter's mood.

STEPS:
- Step 1: Locate the opening paragraphs describing the village lane at night. Identify all sensory words: "घुप्प अंधेरा" (pitch darkness), "ठंडी हवा" (cold wind), "कीचड़ भरी गलियाँ" (muddy lanes), "टिमटिमाते दिये" (flickering lamps).
- Step 2: Classify each: "घुप्प अंधेरा" = visual (absence of light); "ठंडी हवा" = tactile (temperature); "कीचड़ भरी गलियाँ" = tactile+olfactory (mud, damp smell); "टिमटिमाते दिये" = visual (movement of light).
- Step 3: Note the *pattern*: overwhelming darkness/cold/mud vs. tiny, fragile lights. This contrast is the core imagery structure.
- Step 4: Connect to mood: The sensory details create a mood of oppression, isolation, and vulnerability — the physical environment mirrors the social oppression the protagonist faces.
- Step 5: Link to theme: This mood sets up the central conflict (individual vs. hostile environment) and foreshadows the "light" metaphor for resistance.

REASONING: This step-by-step moves from concrete identification -> classification -> pattern recognition -> effect analysis -> thematic linking, which is the exact analytical ladder required for board-level answers.

ANSWER: The opening uses dense visual (darkness, flickering lamps), tactile (cold wind, mud), and olfactory (damp mud) imagery to create a suffocating atmosphere. The contrast between the pervasive "घुप्प अंधेरा" and the fragile "टिमटिमाते दिये" establishes a mood of fragile hope amid overwhelming despair, directly foreshadowing the protagonist's struggle.

## WORKED_EXAMPLE_2
PROBLEM: The protagonist thinks: "मेरी जिंदगी एक बुझता हुआ दीया है" (My life is a dying lamp). Identify tenor, vehicle, ground (shared qualities), and explain how this metaphor deepens our understanding of her psychological state at this point in the plot.

STEPS:
- Step 1: Identify tenor (subject): "मेरी जिंदगी" (my life). Identify vehicle (image): "बुझता हुआ दीया" (dying lamp).
- Step 2: List 4-5 qualities of a dying lamp: flickering, fragile, temporary, sacred/ritualistic, gives light until last moment, easily extinguished by wind.
- Step 3: Map each quality to the protagonist's state: flickering = fluctuating hope; fragile = vulnerability to societal pressure; temporary = sense of limited time/agency; sacred = her duty/resilience has moral weight; extinguished by wind = external forces (patriarchy, poverty) threaten her.
- Step 4: Note the *cultural specificity*: "दीया" carries connotations of prayer, home, woman's domain — making the metaphor gendered and culturally rooted, not universal.
- Step 5: Connect to plot moment: This thought occurs after a specific setback (e.g., rejection of her proposal). The metaphor shows internalized despair but also latent dignity (the lamp still burns).

REASONING: Explicitly separating tenor/vehicle/ground prevents vague "it means she is sad" answers. Cultural grounding is essential for Hindi literature analysis at Class 11 level.

ANSWER: Tenor = protagonist's life; Vehicle = dying lamp. Ground: fragility, temporariness, sacred duty, vulnerability to external winds, persistent light until end. The metaphor reveals she feels her agency is flickering and threatened by patriarchal "winds", yet her resilience retains a sacred, ritualistic dignity — she has not gone out yet.

## WORKED_EXAMPLE_3
PROBLEM: The chapter uses the extended metaphor of "journey through a dark forest" across three key scenes (leaving home, the confrontation, the resolution). Trace this metaphor's evolution and evaluate how its *transformation* mirrors the protagonist's arc.

STEPS:
- Step 1: Locate Scene 1 (leaving home): "मैं अंधेरे वन में अकेली प्रवेश कर रही हूँ" — forest = unknown future; darkness = fear/ignorance; alone = isolation.
- Step 2: Locate Scene 2 (confrontation): "वन के जानवर गुर्रा रहे हैं, पर मेरे हाथ में मशाल है" — animals = antagonists/societal voices; torch = her education/voice; active "हाथ में" shows agency.
- Step 3: Locate Scene 3 (resolution): "वन अब डरावना नहीं, जाना-पहचाना लगता है; मैं पथ-प्रदर्शक हूँ" — forest transformed from threat to familiar terrain; she becomes guide for others.
- Step 4: Analyze the *shift* in metaphor's function: Scene 1 = metaphor for victimhood; Scene 2 = metaphor for armed resistance; Scene 3 = metaphor for leadership/mastery.
- Step 5: Evaluate effectiveness: The extended metaphor provides structural coherence (three-part journey) and shows *internal* change (fear -> courage -> mastery) more powerfully than abstract narration.
- Step 6: Link to board answer requirement: A high-scoring answer would quote key phrases from each scene, use the terms "tenor/vehicle/ground", and conclude with the metaphor's role in character arc.

REASONING: This example demands synthesis across the whole text (plot structure + character arc + device evolution) — the highest-order skill for this node.

ANSWER: The "dark forest" metaphor evolves from a symbol of passive victimhood (Scene 1) to an arena of active resistance where the protagonist wields a "torch" of knowledge (Scene 2), finally becoming a mastered landscape where she guides others (Scene 3). This trajectory — unknown threat -> challenged space -> owned territory — maps precisely onto her psychological arc from fear to empowerment, making the extended metaphor the chapter's structural backbone.

## COMPETENCY_QUESTION_1
QUESTION: "In 'jktLFkku dh jtr cw¡nas', the author uses the metaphor of 'burning lamps' (जलते हुए दीये) repeatedly. A student argues: 'This is just a cultural symbol of hope, not a literary metaphor.' Using your knowledge of the difference between *symbol* and *metaphor*, and evidence from at least two distinct scenes, evaluate this claim."

COMPETENCY: Literary analysis — distinguishing metaphor from symbol and evaluating device function in context.

STEPS:
- Step 1: Define metaphor (context-specific, implicit comparison) vs. symbol (culturally fixed, recurring, multi-layered).
- Step 2: Identify Scene A (e.g., opening): lamps are *described* as physical objects flickering in wind — here they function as visual imagery + metaphor for fragile lives.
- Step 3: Identify Scene B (e.g., climax): the protagonist *lights a new lamp* deliberately — here the act transforms the object into a symbol of agency/ritual.
- Step 4: Argue: The *same object* operates as metaphor in Scene A (implicit comparison: life = lamp) and becomes a symbol in Scene B (cultural code: lighting lamp = invoking divine witness/resolve). The student's claim is partially true but reductive — it ignores the *development* from metaphor to symbol across the narrative.
- Step 5: Conclude: Effective analysis tracks this fluidity; board answers must specify *which scene* and *which function*.

ANSWER: The claim is partially correct but incomplete. In the opening, "जलते हुए दीये" function as metaphor: the fragile flame is implicitly compared to the villagers' precarious existence (tenor=life, vehicle=lamp). In the climax, when the protagonist lights a lamp before confronting the authority, the act invokes the cultural symbol of "deepa" (sacred witness, dispelling ignorance). The object *shifts* from metaphor (author-created comparison) to symbol (culturally pre-loaded meaning) — a sophisticated technique the student's claim overlooks. A full answer must cite both scenes and name the shift.

DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: "The chapter blends olfactory imagery (smell of damp earth, smoke, incense) with the central metaphor of 'suffocation' (घुटन). Write an analytical paragraph (150 words) explaining how this *multisensory imagery* makes the abstract metaphor of suffocation physically palpable for the reader, and why this matters for the theme of gendered oppression."

COMPETENCY: Multisensory imagery analysis + thematic synthesis + structured academic writing (PEEL).

STEPS:
- Step 1: Open with a clear topic sentence: "Olfactory and tactile imagery concretize the metaphor of suffocation, embodying gendered oppression as a physical atmosphere."
- Step 2: Evidence 1 (Olfactory): Quote/describe "सीलन भरी मिट्टी की गंध" (smell of damp earth) in the courtyard — links to confinement, roots, tradition.
- Step 3: Evidence 2 (Olfactory+Tactile): "धुएँ से भरी रसोई" (smoke-filled kitchen) — smoke = invisible barrier, stinging eyes = tactile pain, women's workspace as trap.
- Step 4: Evidence 3 (Contrast): "इत्र और अगरबत्ती" (perfume/incense) in the oppressor's space — sensory privilege vs. deprivation.
- Step 5: Explanation: These smells are not decorative; they *are* the "घुटन" metaphor made sensory. The reader *breathes* the oppression.
- Step 6: Link to theme: Gendered oppression here is not just laws but the very air women inhabit — the imagery proves the metaphor's material reality.

ANSWER: Olfactory and tactile imagery concretize the metaphor of suffocation, embodying gendered oppression as a physical atmosphere. The pervasive "सीलन भरी मिट्टी की गंध" in the courtyard traps the protagonist in ancestral confinement, while the "धुएँ से भरी रसोई" — smoke stinging eyes, coating lungs — transforms the kitchen from a nurturing space into a chamber of slow asphyxiation. Contrastingly, the oppressor's chambers carry "इत्र और अगरबत्ती", marking sensory privilege. These smells are not decorative; they *are* the "घुटन" metaphor made visceral: the reader inhales the same dampness, chokes on the same smoke. This multisensory strategy proves that patriarchal oppression in the chapter is not merely legal or economic but *environmental* — it occupies the air women breathe, making resistance a fight for breath itself. The imagery thus elevates the metaphor from rhetorical flourish to material evidence of systemic violence.

DIFFICULTY: hard