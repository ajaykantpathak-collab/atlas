## DEFINITION
Plot and Narrative Structure refers to the sequence of events (plot) and the framework (structure) that organizes those events in a literary work. In a one-act play like "जटुह", the plot unfolds through dialogue and stage directions in a single continuous act, typically following a linear progression: exposition (introduction of characters and conflict), rising action (development of conflict), climax (turning point), and resolution (outcome). The narrative structure here is dialogue-driven, with minimal subplots, focusing on the central conflict of parental pressure and the coaching industry.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student must be able to identify the five stages of plot (exposition, rising action, climax, falling action, resolution) in the play "जटुह", cite specific dialogues or stage directions as evidence for each stage, and explain how the single-act structure intensifies the theme of educational pressure.

## SCOPE_BOUNDARY
This node covers the plot progression and narrative structure of the one-act play "जटुह" only. It does not cover character analysis, themes, or literary devices in depth (those are separate nodes). It focuses on structural elements: division of the act into scenes (French scenes), use of dialogue to advance plot, and the role of stage directions.

## WALKTHROUGH
Imagine you are watching a play where a tuition teacher and a student argue about homework, and suddenly the student's mother enters, shifting the focus to parental anxiety. How does the playwright arrange these scenes to build tension? Begin by reading the play once to get the overall story. Then, re-read and mark every entrance and exit of characters (French scenes). Notice how each new character changes the conflict. The key insight: the play's single-act structure forces all confrontations into one continuous space, mirroring the inescapable pressure the student feels.

## DIAGNOSTIC_QUESTION_1
What is the definition of 'exposition' in the context of a one-act play? Provide an example from the opening of "जटुह".

## DIAGNOSTIC_ANSWER_1
Exposition is the part of the plot that introduces the setting, characters, and initial conflict. In "जटुह", the exposition occurs in the opening dialogue between जटुह and वफर् where we learn about वफर्'s tuition, his father's absence, and the pressure of exams. A wrong answer would confuse exposition with the inciting incident (e.g., saying the mother's entry is the exposition), showing the student cannot distinguish the initial setup from the event that complicates the plot.

## DIAGNOSTIC_QUESTION_2
Explain in your own words how the playwright uses 'French scenes' (character entrances/exits) to structure the rising action in "जटुह".

## DIAGNOSTIC_ANSWER_2
The playwright structures rising action through a series of French scenes: each time a new character enters (यथक, ग्स्मेकल्वज, इफर, लैक्नद, etc.), the conflict escalates from a private tuition dispute to a systemic critique of education. A wrong answer might list entrances but not explain how each escalates the conflict, indicating the student sees structure as a list rather than a causal chain.

## DIAGNOSTIC_QUESTION_3
Apply the concept of 'climax' to the play: Identify the climax of "जटुह" and justify your choice using a specific dialogue or stage direction.

## DIAGNOSTIC_ANSWER_3
The climax occurs when जटुह confronts the principal (ग्स्मेकल्वज) and refuses to back down, declaring she will file a complaint against the coaching mafia (around page 81-82). This is the turning point because the conflict shifts from personal to institutional. A wrong answer might pick the emotional reunion of वफर् and his mother, which is part of the falling action, showing the student cannot distinguish the peak of tension from its release.

## DIAGNOSTIC_QUESTION_4
Analyze how the single-act structure (no interval, continuous time) contributes to the play's theme of relentless academic pressure.

## DIAGNOSTIC_ANSWER_4
The continuous single-act structure traps the audience in the same unbroken timeline as the characters, mirroring the student's inability to escape the cycle of tuition, exams, and parental expectations. There is no intermission to 'breathe', just as वफर् gets no respite. A wrong answer would focus only on convenience of staging, missing the thematic resonance of structural choice.

## DIAGNOSTIC_QUESTION_5
Evaluate the effectiveness of the play's resolution: Does the ending (जटुह deciding to launch a movement) provide a satisfying closure to the central conflict? Argue with evidence.

## DIAGNOSTIC_ANSWER_5
The resolution is intentionally open-ended: जटुह's decision to start a movement (page 83) suggests the systemic issue persists, which is realistic but not a neat closure. This effectiveness lies in its refusal to offer a false solution, aligning with the play's critical tone. A wrong answer might demand a happy ending (e.g., वफर् gets relief), revealing an expectation of conventional resolution over thematic integrity.

## DIAGNOSTIC_QUESTION_6
Create an alternative ending for "जटुह" that changes the narrative structure from linear to circular (ending where it began). Write a brief scenario (3-4 sentences) showing how this would alter the play's message.

## DIAGNOSTIC_ANSWER_6
A circular ending could show जटुह back in her tuition room with a new student, repeating the same dialogue about homework, implying the system is unchangeable. This would shift the message from potential activism to hopeless cyclical traps. A poor answer would simply rewrite the ending without explaining the structural change's thematic impact, showing the student doesn't grasp how structure shapes meaning.

## COMMON_MISCONCEPTION
Students often think the 'plot' is just a summary of events, and they list scenes in order without identifying the structural function (exposition, rising action, etc.). They also confuse the one-act play's French scenes with formal 'acts' and 'scenes', leading them to say the play has multiple scenes when it is technically one continuous act with character-based divisions. This error arises because they apply the structure of multi-act plays (like Shakespeare) to a modern one-act play.

## ON_FAILURE
If a student cannot distinguish plot events from structural stages, have them create a two-column table: Column A: Event (e.g., "Mother enters"), Column B: Structural Role (e.g., "Rising action - introduces parental pressure"). Use color-coding: highlight each French scene entrance in the text. Then ask: "What changes after this entrance?" This forces them to see causality, not just sequence.

## BUILDS_ON
c11_hin_ar_cbse_06_001 (Before You Read: Context and Background) provides the socio-historical context of the coaching industry, which is essential to understand the conflict driving the plot.

## LEADS_TO
c11_hin_ar_cbse_06_003 (Text: Setting and Atmosphere) because the single setting (tuition room) and its atmosphere are integral to the narrative structure's unity of place and time.

## PREREQUISITE_NODE_IDS
c11_hin_ar_cbse_06_001
## PREREQUISITE_REASONS
c11_hin_ar_cbse_06_001: Provides background on the coaching culture and the playwright's context, which frames the central conflict of the plot.

## FORWARD_NODE_IDS
c11_hin_ar_cbse_06_003, c11_hin_ar_cbse_06_004, c11_hin_ar_cbse_06_005, c11_hin_ar_cbse_06_006, c11_hin_ar_cbse_06_007, c11_hin_ar_cbse_06_008, c11_hin_ar_cbse_06_009, c11_hin_ar_cbse_06_010, c11_hin_ar_cbse_06_012, c11_hin_ar_cbse_06_013, c11_hin_ar_cbse_06_014, c11_hin_ar_cbse_06_015, c12_hin_a_cbse_09_002, c12_hin_ar_cbse_06_002

## FORWARD_REASONS
c11_hin_ar_cbse_06_003: The setting (tuition room) is the physical space where the entire plot unfolds; understanding structure helps analyze how setting constrains action.
c11_hin_ar_cbse_06_004: The protagonist जटुह's actions drive the plot; plot structure reveals her character arc.
c11_hin_ar_cbse_06_005: Supporting characters enter/exit to advance plot; their structural roles clarify their functions.
c11_hin_ar_cbse_06_006: The primary theme (educational pressure) is developed through the plot's progression; structure organizes thematic revelation.
c11_hin_ar_cbse_06_007: Plot structure understanding ensures students can locate thematic moments in the correct dramatic sequence.  
c11_hin_ar_cbse_06_008: Plot structure knowledge helps locate where devices appear in narrative arc.  
c11_hin_ar_cbse_06_009: Plot knowledge lets the student locate specific scenes where irony and symbols operate.  
c11_hin_ar_cbse_06_010: Knowledge of plot sequence helps locate where key words appear and their dramatic function.  
c11_hin_ar_cbse_06_012: Plot structure knowledge required to locate literal events in sequence  
c11_hin_ar_cbse_06_013: Plot structure knowledge allows identification of turning points (e.g., tuition scene, Director's office, final meeting) for analysis.  
c11_hin_ar_cbse_06_014: Understanding plot structure is essential for writing summaries and scene conversions.  
c11_hin_ar_cbse_06_015: Plot and Narrative Structure provides the scene-sequence map needed to locate discussion evidence chronologically  
c12_hin_a_cbse_09_002: Connected structure to theme development.  
c12_hin_ar_cbse_06_002: Class 11 foundation on identifying narrative structure in poetry.  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
none

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_06_001 -> c11_hin_ar_cbse_06_002 -> c11_hin_ar_cbse_06_003

## THIS_FORMULA
N/A - conceptual

## FORMULA_VARIABLES
N/A

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
analytical

## CROSS_SUBJECT
c11_psychology_academic_stress | The play depicts a student's mental breakdown due to academic pressure, a core topic in psychology (stress, coping mechanisms, parental influence).
c11_sociology_education_system | The critique of coaching mafia and institutional failure reflects sociological perspectives on education as a social institution and inequality.

## PREREQ_CONCEPT
Understanding of basic dramatic structure (exposition, rising action, climax, falling action, resolution) from earlier classes.

## PREREQ_BEFORE
The student must know the five elements of a plot diagram and be able to define each.

## PREREQ_STUCK
If stuck, review the plot diagram (Freytag's Pyramid) and practice mapping a simple story (e.g., a fairy tale) to its five stages.

## WORKED_EXAMPLE_1
PROBLEM: Map the first 10 pages of "जटुह" (up to the mother's entry) onto Freytag's Pyramid. Identify exposition, inciting incident, and rising action with textual evidence.
STEPS:
- Step 1: Read the opening segment (pages 69-71) and list all events in order: जटुह and वफर् discuss homework, वफर्'s father is away, वफर् is tired, जटुह insists on tuition.
- Step 2: Identify the exposition: The opening dialogue establishes the setting (tuition room), characters (ट्यूशन टीचर and छात्र), and the routine pressure (homework, exams).
- Step 3: Identify the inciting incident: वफर्'s emotional outburst ("मेरा फर्जीवाड़ा...") reveals his breakdown, shifting from routine to crisis.
- Step 4: Identify rising action: The mother's entrance (page 71) introduces parental anxiety and the financial burden of tuition, escalating the conflict.
- Step 5: Verify by checking if each event increases tension: The mother's threat to withdraw वफर् from tuition raises stakes for जटुह.
REASONING: This step-by-step mapping teaches students to distinguish between mere events and structural turning points by asking "Does this event change the direction or intensity of the conflict?"
ANSWER: Exposition: Pages 69-70 (setting, characters, routine). Inciting Incident: वफर्'s outburst about fake marks (page 70). Rising Action: Mother's entry and confrontation (page 71).

## WORKED_EXAMPLE_2
PROBLEM: The play uses 'French scenes' (character entrances/exits) to structure the narrative. Identify all French scenes in the segment where the principal (ग्स्मेकल्वज) visits (pages 74-76) and explain how each new character alters the conflict.
STEPS:
- Step 1: Define French scene: A unit of action marked by a character's entrance or exit, not a formal scene break.
- Step 2: Scan pages 74-76 for entrances/exits: Start with जटुह and वफर्; then ग्स्मेकल्वज enters (first French scene); then पिजखल enters (second); then फनस'कद enters (third); then जटुह exits (fourth).
- Step 3: Analyze the conflict shift with each entrance: ग्स्मेकल्वज brings institutional authority; पिजखल brings parental perspective; फनस'कद brings administrative power.
- Step 4: Note how the conflict expands from individual (वफर्'s tuition) to systemic (coaching mafia, school rules).
- Step 5: Conclude that the French scene structure allows the playwright to layer multiple perspectives without changing setting.
REASONING: French scenes are the structural backbone of one-act plays; analyzing them reveals how the playwright manages pacing and thematic expansion in a confined space.
ANSWER: Four French scenes in this segment: (1) ग्स्मेकल्वज enters -> conflict becomes institutional; (2) पिजखल enters -> adds parental voice; (3) फनस'कद enters -> introduces administrative threat; (4) जटुह exits -> leaves the conflict unresolved, leading to public protest.

## WORKED_EXAMPLE_3
PROBLEM: Compare the narrative structure of "जटुह" (one-act play) with a traditional five-act play. How does the compression into one act affect the portrayal of the theme 'education system'?
STEPS:
- Step 1: Recall the five-act structure: Act 1 (Exposition), Act 2 (Rising Action), Act 3 (Climax), Act 4 (Falling Action), Act 5 (Resolution).
- Step 2: Map "जटुह" onto these five acts within a single continuous act: Identify where each act would begin/end if divided.
- Step 3: Note the compression: Exposition and inciting incident happen in first 10 pages; rising action spans multiple French scenes; climax is the confrontation with principal; falling action is the public meeting; resolution is जटुह's decision to start movement.
- Step 4: Analyze the effect of compression: The audience experiences the pressure as relentless and simultaneous, mirroring the student's experience of overlapping demands (tuition, school, parents).
- Step 5: Contrast with a five-act play where time gaps between acts allow reflection; here, no reflection time, emphasizing systemic entrapment.
- Step 6: Conclude that the one-act structure is a deliberate formal choice to embody the theme of inescapable pressure.
REASONING: Comparing structures across genres deepens understanding of how form serves theme. The student must move beyond identifying stages to evaluating structural choices.
ANSWER: The one-act structure compresses the five acts into a continuous flow, eliminating breathing spaces. This formal choice mirrors the theme: just as the student cannot escape the cycle of exams and tuition, the audience cannot escape the play's intensity. A five-act structure would allow subplots and reflection, diluting the critique of systemic pressure.

## COMPETENCY_QUESTION_1
QUESTION: The play "जटुह" begins and ends in the same physical space (the tuition room). How does this circular spatial structure reinforce the play's central conflict? Support your answer with two specific references to the text.
COMPETENCY: Analyzing structural choices and their thematic significance.
STEPS:
- Step 1: Identify the opening and closing settings (both the tuition room).
- Step 2: Note what happens in the opening: routine tuition, pressure normalized.
- Step 3: Note what happens in the closing: जटुह decides to launch a movement, but the room remains the same.
- Step 4: Explain the irony: The space that symbolized oppression becomes the launchpad for resistance, yet the system (the room) persists.
ANSWER: The circular spatial structure highlights that while individual resistance (जटुह's movement) begins, the structural conditions (the tuition room as a site of exploitation) remain unchanged. This reinforces the theme that systemic change requires more than individual action. References: Opening stage direction (page 69) describes the room; closing stage direction (page 83) shows जटुह in the same room planning a movement.
DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: In "जटुह", the playwright uses off-stage characters (like वफर्'s father, the coaching mafia) who are frequently mentioned but never appear. How does this narrative device of 'absent presence' shape the plot structure and the audience's perception of the conflict?
COMPETENCY: Evaluating narrative techniques and their effect on plot and theme.
STEPS:
- Step 1: List off-stage characters: वफर्'s father (mentioned as absent), coaching mafia (referred to by ग्स्मेकल्वज), the education minister (implied).
- Step 2: Explain how their absence creates a power dynamic: The unseen forces control the on-stage characters' lives.
- Step 3: Analyze plot structure: The conflict is driven by forces that cannot be directly confronted, making the on-stage confrontations (with principal, parents) feel inadequate.
- Step 4: Connect to theme: The 'absent presence' mirrors how the education system is controlled by distant policymakers and commercial interests, leaving teachers and students powerless.
- Step 5: Conclude that this device expands the conflict beyond the stage, suggesting the problem is structural, not personal.
ANSWER: The absent presence of the father, coaching mafia, and policymakers structures the plot around a central void: the real decision-makers are never on stage. This forces the on-stage characters (जटुह, वफर्, mother, principal) into proxy battles, emphasizing that the conflict is systemic. The audience perceives the tuition room as a microcosm of a larger invisible machinery.
DIFFICULTY: hard