## DEFINITION
Imagery is the use of vivid, sensory language that appeals to the five senses (sight, sound, smell, touch, taste) to create mental pictures and evoke physical sensations in the reader. Metaphor is a figure of speech that directly compares two unrelated things by stating one *is* the other, transferring qualities from the vehicle (the image used) to the tenor (the subject described) without using "like" or "as".

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student can independently identify specific instances of imagery and metaphor in the story, classify the sensory mode of each image, explain the tenor-vehicle relationship in each metaphor, and analyze how these devices jointly construct the protagonist's inner world and the story's central themes of isolation and resilience.

## SCOPE_BOUNDARY
This node covers only imagery (all five sensory types) and metaphor (explicit and implicit) as they appear in the prescribed story "Bari Bajari" (बड़ी बाजारी) by Usha Priyamvada. It does not cover simile, personification, irony, symbolism, or other rhetorical devices — those are addressed in sibling nodes.

## WALKTHROUGH
Imagine you are walking through a crowded Indian bazaar at dusk: the smell of frying pakoras, the clang of bicycle bells, the rough texture of a jute bag against your arm. Good writers make you *feel* that scene without you being there. In this story, Usha Priyamvada uses exactly such sensory details (imagery) and striking comparisons (metaphor) to put you inside the mind of an aging market woman. To begin, re-read the first three paragraphs slowly with a pencil in hand. Circle every word that triggers a sensation — a colour, a sound, a smell, a texture, a taste. Then underline any statement where one thing is directly called another (e.g., "the market was a beast"). That is your raw data. Next, group the circled words by sense organ. For each underlined metaphor, name the two things being equated and ask: what quality of the second thing is being forced onto the first? Finally, connect each cluster to the woman's loneliness or her stubborn dignity. The key insight: imagery builds the physical world she inhabits; metaphor builds the emotional world she *is*.

## DIAGNOSTIC_QUESTION_1
Define imagery and metaphor in your own words, giving one original example of each (not from the textbook).

## DIAGNOSTIC_ANSWER_1
Imagery: Language that appeals to the senses (e.g., "The wet earth smelled of rain and crushed mint"). Metaphor: A direct comparison saying X *is* Y (e.g., "Her grief was a locked room with no key"). A wrong answer that only lists "visual descriptions" for imagery reveals the misconception that imagery is only visual. A wrong answer that uses "like" or "as" for metaphor reveals confusion with simile.

## DIAGNOSTIC_QUESTION_2
In the opening scene of "Bari Bajari", the author writes about "the smell of frying oil and sweat" and "the market's heartbeat". Explain how these two phrases function differently as literary devices and what each achieves for the reader.

## DIAGNOSTIC_ANSWER_2
"The smell of frying oil and sweat" is olfactory + tactile imagery — it places the reader physically in the bazaar. "The market's heartbeat" is a metaphor (market = living organism) — it suggests the market has a life of its own, mirroring the protagonist's own pulse. A student who calls both "imagery" misses the metaphor; a student who calls both "metaphor" misses the sensory grounding. Both errors show inability to distinguish device from effect.

## DIAGNOSTIC_QUESTION_3
Read this new sentence: "The neon sign flickered like a dying firefly, and the street became a river of broken glass." Identify the simile, the metaphor, and one instance of visual imagery. Then rewrite the sentence using *only* metaphor and visual imagery (no simile).

## DIAGNOSTIC_ANSWER_3
Simile: "like a dying firefly". Metaphor: "the street became a river of broken glass". Visual imagery: "neon sign flickered", "broken glass". Rewrite: "The neon sign was a dying firefly; the street, a river of broken glass." A wrong answer that keeps "like" fails the transformation task; a wrong answer that adds new comparisons not in the original shows inability to isolate existing devices.

## DIAGNOSTIC_QUESTION_4
The story contains two extended metaphors: (a) the market as a living creature, and (b) the protagonist's body as a worn-out tool. Compare how each metaphor develops the theme of "endurance versus decay". Use specific textual evidence (paraphrased) in your answer.

## DIAGNOSTIC_ANSWER_4
The market-as-creature metaphor (heartbeat, breathing, digesting crowds) shows endurance — it persists regardless of individual humans. The body-as-tool metaphor (joints rusting, hands blunt, back a bent nail) shows decay — the woman's physical self is deteriorating. Together they create tension: the world outlives the body, yet she refuses to break. A student who only lists the metaphors without contrasting their thematic direction fails analysis. A student who invents a third metaphor not in the text fails textual fidelity.

## DIAGNOSTIC_QUESTION_5
Critique this student claim: "The metaphor 'her eyes were two dry wells' is more powerful than the imagery 'dust settled on her eyelashes' because metaphors are always deeper than imagery." Defend or refute with reasoning grounded in literary theory.

## DIAGNOSTIC_ANSWER_5
Refute. Metaphor and imagery operate differently: imagery provides concrete sensory evidence ("dust on eyelashes" proves the environment and her stillness); metaphor condenses abstract emotion ("dry wells" conveys exhausted tears and depth of sorrow). Neither is inherently "deeper"; they are complementary layers. The claim reveals a hierarchical misconception that figurative language > literal sensory detail. A strong answer acknowledges both devices serve the same thematic moment — her suppressed grief.

## DIAGNOSTIC_QUESTION_6
Write a 4-sentence paragraph describing a railway platform at midnight using at least two types of imagery and one original metaphor. Do not use any simile.

## DIAGNOSTIC_ANSWER_6
Example: "The platform exhaled cold steam (tactile/olfactory). A lone bulb swung, casting shadows that stretched like tired travellers (visual — but note: 'stretched like' is a simile, so this would be penalised). Correct version: 'The platform exhaled cold steam. A lone bulb swung, its light a thin gruel on the concrete. The silence had the weight of an unspoken goodbye (metaphor). A discarded newspaper skittered, dry as bone (tactile/auditory — but 'dry as bone' is simile). Better: 'The silence was an unspoken goodbye; a newspaper skittered, brittle and bone-dry.'" A poor answer uses similes, misses a sense mode, or offers a clichéd metaphor ("heart of stone").

## COMMON_MISCONCEPTION
Students consistently treat metaphor as a decorative "extra" rather than a structural component of meaning. They identify "the market was a beast" but then write "this shows the market was dangerous" — a paraphrase, not an analysis of *which* qualities of "beast" (unpredictability, hunger, mindless force) are mapped onto the market and *why* that matters for the protagonist who must negotiate it daily. They also restrict imagery to visual descriptions, ignoring how Usha Priyamvada uses olfactory (frying oil, sweat), auditory (clanging bells, vendor cries), and tactile (rough jute, cold steam) imagery to immerse the reader in the woman's bodily experience. This happens because school-level teaching often equates "image" with "picture".

## ON_FAILURE
1. Have the student close the book and describe their own kitchen at dinner time using all five senses — this re-activates the sensory vocabulary. 2. Give them three simple sentences ("The room was messy. She was sad. The night was dark.") and ask them to convert each into a metaphor + two imagery types. 3. Return to the story's first page; together, colour-code: yellow for visual, green for olfactory, blue for auditory, pink for tactile, orange for gustatory. 4. For every metaphor found, fill a two-column table: Vehicle | Tenor | Transferred Quality. 5. Re-attempt Diagnostic Questions 3 and 4. Mastery is shown when the student can explain *why* the author chose "beast" over "machine" for the market.

## BUILDS_ON
Class 11 foundation in identifying basic figures of speech (simile, metaphor, personification) and distinguishing literal from figurative language.

## LEADS_TO
Irony and Symbolism (c12_hin_a_cbse_12_009) where students will see how metaphor sets up ironic reversals and how recurring images become symbols.

## PREREQUISITE_NODE_IDS
c11_hin_ar_cbse_01_008, c11_hin_ar_cbse_02_008, c11_hin_v_cbse_01_008, c12_hin_a_cbse_12_001, c12_hin_a_cbse_12_002, c12_hin_a_cbse_12_006, c12_hin_a_cbse_12_003, c12_hin_a_cbse_12_007

## PREREQUISITE_REASONS
c11_hin_ar_cbse_01_008: Introduced imagery and metaphor definitions and basic identification in Class 11 Antra Chapter 1. c11_hin_ar_cbse_02_008: Reinforced the same devices in a different text, showing variety. c11_hin_v_cbse_01_008: Covered literary devices in Vitan, providing cross-text practice. c12_hin_a_cbse_12_001: Context node gives author background and socio-cultural setting essential for interpreting metaphors rooted in market life. c12_hin_a_cbse_12_002: Plot node ensures student knows narrative sequence to place each device in correct scene. c12_hin_a_cbse_12_006: Primary theme node establishes the central ideas (isolation, dignity) that imagery and metaphor serve.
c12_hin_a_cbse_12_003: Imagery and metaphor node will analyze how setting details become symbolic (cot, railway, lanes)  
c12_hin_a_cbse_12_007: Imagery and Metaphor node will analyze how sensory details (rough hands, ash, dust) concretize secondary themes.  
c11_hin_ar_cbse_02_008: Imagery is the use of vivid, sensory language that appeals to the five senses (sight, soun... की समझ आवश्यक है, क्योंकि यह नोड (Imagery is the use of vivid, sensory language that appeals to the five senses (sight, soun...) इसी आधार पर आगे बढ़ता है।  
c11_hin_v_cbse_01_008: Imagery (fp=kiV laxhr) in this chapter refers to the author's technique of using vivid, se... की समझ आवश्यक है, क्योंकि यह नोड (Imagery is the use of vivid, sensory language that appeals to the five senses (sight, soun...) इसी आधार पर आगे बढ़ता है।  
c12_hin_a_cbse_12_001: Imagery and metaphor choices stem from the colloquial, descriptive language noted.  
c12_hin_a_cbse_12_002: Plot and narrative structure refer to the sequence of events in a story and the technique... की समझ आवश्यक है, क्योंकि यह नोड (Imagery is the use of vivid, sensory language that appeals to the five senses (sight, soun...) इसी आधार पर आगे बढ़ता है।  
c12_hin_a_cbse_12_006: The primary theme of a literary work is its central, unifying idea or insight about human... की समझ आवश्यक है, क्योंकि यह नोड (Imagery is the use of vivid, sensory language that appeals to the five senses (sight, soun...) इसी आधार पर आगे बढ़ता है।  

## FORWARD_NODE_IDS
c12_hin_a_cbse_12_009, c12_hin_a_cbse_12_010, c12_hin_a_cbse_12_013, c12_hin_a_cbse_12_014, c12_hin_a_cbse_12_015

## FORWARD_REASONS
c12_hin_a_cbse_12_009: Irony and Symbolism builds directly on metaphor understanding — many symbols originate as extended metaphors. c12_hin_a_cbse_12_010: Vocabulary in Context requires recognizing metaphorical usage of words (e.g., "digest" for crowd absorption). c12_hin_a_cbse_12_013: Critical Thinking questions demand device-based textual evidence, which this node equips the student to provide.
c12_hin_a_cbse_12_014: बिंब-रूपक (imagery-metaphor) पहचानने से Explanation में गहराई आती है।  
c12_hin_a_cbse_12_015: Gives imagery/metaphor tools to analyze storytelling as "mapping" (xkM+h ij lokj)  
c12_hin_a_cbse_12_010: Imagery of 'phj&gj.k yhyk' (trembling hands) contextualizes 'viQjuk'.  
c12_hin_a_cbse_12_013: Imagery and metaphor are the primary tools the author uses to encode meaning; analysis requires decoding them.  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
N/A

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_01_008 -> c12_hin_a_cbse_12_008 -> c12_hin_a_cbse_12_009

## THIS_FORMULA
N/A - conceptual

## FORMULA_VARIABLES
N/A

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
analytical

## CROSS_SUBJECT
N/A | The story's market setting reflects the transformation of traditional bazaars under colonial and post-colonial economic shifts; imagery of "neon signs" vs "oil lamps" mirrors historical transition. c12_economics_rural_economy | The protagonist's barter-like exchanges and the metaphor of market-as-organism illustrate informal sector dynamics and vendor resilience studied in rural economics.
## PREREQ_CONCEPT
Ability to distinguish literal from figurative language and to name the five sensory modalities.

## PREREQ_BEFORE
Student must recall the definitions of imagery (sensory language) and metaphor (direct comparison) from Class 11.

## PREREQ_STUCK
If stuck, revisit Class 11 Antra Chapter 1 Literary Devices node (c11_hin_ar_cbse_01_008) and re-do the identification exercises there.

## WORKED_EXAMPLE_1
PROBLEM: Analyze the olfactory and tactile imagery in the paragraph where the protagonist prepares her evening meal (paraphrased: "She lit the stove; the smell of mustard oil rose sharp; the dough resisted her fingers; the rolled chapati hit the tawa with a wet slap"). Identify each sensory detail, classify it, and explain how the cluster characterises her relationship with labour.

STEPS:
- Step 1: Locate the paragraph in the text (after she returns from the market, before the customer arrives).
- Step 2: Extract every sensory phrase: "smell of mustard oil rose sharp" (olfactory), "dough resisted her fingers" (tactile - resistance/pressure), "rolled chapati hit the tawa with a wet slap" (auditory + tactile - wetness, impact).
- Step 3: Classify each by sense modality: olfactory (1), tactile (2), auditory (1). Note the absence of visual/gustatory here — deliberate focus on process, not product.
- Step 4: Interpret the cluster: The sharp oil smell signals frugality (mustard oil is cheap); the resisting dough shows physical effort; the wet slap is the sound of repetitive, skilled labour. Together they portray work as intimate, bodily, and unglamorous.
- Step 5: Connect to character: She does not romanticise her labour; the imagery makes the reader feel the weight of each motion, building respect for her endurance. The lack of gustatory imagery (taste of food) underscores she cooks for survival, not pleasure.

REASONING: This step-by-step moves from textual evidence to classification to thematic synthesis — the exact chain board examiners reward. It avoids the common error of listing images without explaining their collective purpose.

ANSWER: The paragraph uses olfactory (mustard oil), tactile (resisting dough, wet slap), and auditory (slap) imagery to immerse the reader in the physicality of the woman's daily labour. The cluster characterises her relationship with work as tactile, repetitive, and stripped of sensory reward — she knows the dough's resistance better than the chapati's taste.

## WORKED_EXAMPLE_2
PROBLEM: The narrator describes the market at noon as "a throat that swallowed noise and spat out silence". Identify the metaphor, name its tenor and vehicle, list three qualities of the vehicle transferred to the tenor, and explain how this metaphor reframes the market's power over the vendors.

STEPS:
- Step 1: Identify the metaphor: "the market [tenor] was a throat [vehicle] that swallowed noise and spat out silence".
- Step 2: Name tenor = the market (specifically its noon-time atmosphere); vehicle = a throat (biological organ).
- Step 3: List transferred qualities: (a) involuntary reflex — swallowing/spitting happens without conscious control; (b) cyclical rhythm — swallow then spit, like breathing; (c) transformation — input (noise) becomes output (silence), the organ changes the substance.
- Step 4: Map to market: (a) The market absorbs vendors' cries and customer haggling (noise) and returns emptiness (silence) — vendors have no control over this cycle. (b) The rhythm is relentless, daily, biological — not a human-made schedule but an organic imperative. (c) The market transforms human energy (voices) into indifference (silence), highlighting vendor powerlessness.
- Step 5: Contrast with earlier "heartbeat" metaphor: heartbeat suggests life; throat suggests consumption and waste. This shift signals the narrative move from market-as-living-community to market-as-devouring-machine.

REASONING: Metaphor analysis requires unpacking the vehicle's connotations, not just stating the comparison. The step "list transferred qualities" forces the student to move beyond "market = throat" to "what does a throat *do* that a market *does*?" — the core of metaphor theory.

ANSWER: Tenor = market at noon; Vehicle = throat. Transferred qualities: involuntary reflex, cyclical rhythm, transformative consumption. The metaphor reframes the market as a biological entity that ingests human sound and excretes silence, rendering vendors' efforts invisible and inevitable — a shift from the earlier "heartbeat" metaphor that suggested vitality.

## WORKED_EXAMPLE_3
PROBLEM: In the climax, the protagonist thinks: "My hands are two old rags; the coins are cold beetles." Combine imagery and metaphor analysis to show how this internal monologue encapsulates her self-perception at that moment.

STEPS:
- Step 1: Identify the two metaphors: (1) hands = old rags; (2) coins = cold beetles.
- Step 2: For each, name tenor and vehicle. Metaphor 1: tenor = her hands; vehicle = old rags. Metaphor 2: tenor = coins (her earnings); vehicle = cold beetles.
- Step 3: Analyse imagery inside the metaphors: "old rags" carries tactile (worn, thin, frayed), visual (faded, shapeless), olfactory (dusty, musty) imagery. "cold beetles" carries tactile (cold, hard, segmented), visual (small, dark, many-legged), thermal (cold) imagery.
- Step 4: Determine transferred qualities: Rags -> uselessness, disposability, loss of form, absorption of dirt. Beetles -> mindless multiplicity, cold indifference, scuttling away, insect-like insignificance.
- Step 5: Synthesise self-perception: She sees her labouring hands as discarded objects (rags) and her hard-won money as alien, lifeless things that don't warm her (cold beetles). The metaphors collapse the subject-object boundary: she *is* the rags; the coins *are* beetles. This is not sadness — it is existential erasure.
- Step 6: Link to story's arc: Earlier she called her hands "tools"; now "rags" shows the tool has broken beyond repair. The shift from tool (instrument) to rag (waste) marks the narrative's emotional climax.

REASONING: This example demands simultaneous handling of two metaphors and their embedded imagery — a higher-order skill required for board "analyze" questions and competitive exam passage analysis. The step "analyse imagery inside the metaphors" is crucial: metaphors are not abstract; they work *through* sensory imagery.

ANSWER: The twin metaphors — hands as old rags, coins as cold beetles — use layered tactile/visual/thermal imagery to convey utter depletion. "Rags" transfers disposability and formlessness to her hands; "cold beetles" transfers alienation and lifelessness to her earnings. Together they enact her self-erasure: the labourer becomes waste, the reward becomes vermin. The shift from earlier "hands as tools" to "hands as rags" marks the irreversible crossing from dignity to despair.

## COMPETENCY_QUESTION_1
QUESTION: (Case-based) A student writes: "The author uses the metaphor 'the market was a beast' to show the market is dangerous." The teacher remarks: "Incomplete — you named the vehicle but not the specific transferred qualities." Rewrite the student's answer to meet board-level analysis standards, using the PEEL structure (Point, Evidence, Explanation, Link).

COMPETENCY: Analytical Writing / Structured Literary Response

STEPS:
- Step 1: Point — The metaphor "market as beast" transfers specific qualities: mindless appetite, territorial aggression, and indifference to individual suffering.
- Step 2: Evidence — The text shows the market "swallowing" vendors' cries and "spitting out" silence (swallow/spit imagery), and the protagonist's fear of being "crushed under its hooves" (hooves imagery).
- Step 3: Explanation — "Beast" is not just "dangerous"; a beast operates on instinct, not malice. The market destroys not because it hates the vendors but because its nature is consumption. The hooves image adds weight and inevitability — the vendor cannot negotiate with a hoof.
- Step 4: Link — This metaphor establishes the structural inequality: the vendor is prey, the market is predator, and no amount of individual effort (her "rags" hands) changes the food chain. It sets up the story's central conflict: dignity within a devouring system.

ANSWER: The metaphor "the market was a beast" transfers the qualities of mindless appetite (swallowing noise, spitting silence), territorial aggression (hooves that crush), and instinctual indifference (it does not hate, it consumes). Evidence: the market "swallowed noise and spat out silence"; the protagonist fears being "crushed under its hooves". Explanation: A beast's danger is not personal but biological — the market destroys vendors as a function of its nature, not by choice. Link: This frames the protagonist's struggle as existential — she seeks dignity inside a system that structurally positions her as prey.

DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: (Assertion-Reason) Assertion (A): The recurring olfactory imagery of "mustard oil", "frying oil", and "sweat" functions as a leitmotif that binds the protagonist's body to the market space. Reason (R): Olfactory imagery is the most primitive sense and directly accesses memory, making it the optimal device for a story about aging and endurance. Determine if both A and R are true, and if R correctly explains A.

COMPETENCY: Critical Evaluation of Literary Reasoning

STEPS:
- Step 1: Evaluate Assertion (A) — True. The three smells appear at key structural points: mustard oil (her kitchen, private labour), frying oil (market, public labour), sweat (her body, the bridge). They recur cyclically, binding her bodily existence to the market's rhythm.
- Step 2: Evaluate Reason (R) — Partially true but overstated. Olfaction *is* strongly linked to memory (Proust effect), but calling it "most primitive" is a pop-science simplification; touch and taste are equally ancient. More importantly, the story uses olfactory imagery not primarily for memory triggers but for *material presence* — the smells are immediate, current, inescapable.
- Step 3: Test if R explains A — No. A claims a structural/leitmotif function (binding body to space through recurrence). R claims a psychological/neurological function (memory access via primitive sense). The recurrence creates the binding, not the "primitiveness" of smell. The story could use recurring auditory imagery (bell clangs) for the same structural effect.
- Step 4: Identify the flaw — R confuses *why the device works psychologically* with *why the author chose it structurally*. The leitmotif works because of repetition and cross-scene placement, not because smell is "primitive".
- Step 5: Formulate verdict — Both A and R are true (with R's "primitive" caveat), but R does not correctly explain A.

ANSWER: Assertion (A) is true — the olfactory triplet acts as a structural leitmotif binding body to market. Reason (R) is partially true but contains a scientific oversimplification ("most primitive sense"). Crucially, R does not correctly explain A: the leitmotif's binding power comes from its strategic recurrence across private/public scenes, not from olfaction's supposed neurological primacy. The same structural work could be done by recurring auditory or tactile motifs.

DIFFICULTY: hard