## DEFINITION
Language Usage Analysis in prose texts refers to the systematic examination of grammatical structures, syntactic patterns, lexical choices, and stylistic devices employed by an author to convey meaning, establish voice, and create specific effects. It involves identifying how morphology (word formation), syntax (sentence structure), semantics (meaning), and pragmatics (contextual use) work together to shape the narrative texture and thematic depth of a literary work.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student must be able to independently identify and explain at least four distinct grammatical or stylistic features in the text (e.g., compound verbs, honorific systems, dialectal variations, narrative tense shifts) with textual evidence, and articulate how each feature contributes to character portrayal, thematic development, or narrative perspective in a structured analytical paragraph.

## SCOPE_BOUNDARY
This node covers grammatical and stylistic analysis of Krishna Sobti's "वख्खे विèक्कफज" specifically: verb morphology (aspect, mood, compound verbs), pronoun/honorific system, sentence types and patterns, dialectal/colloquial features, direct/indirect speech representation, and lexical register shifts. It does NOT cover literary devices like metaphor/imagery (node 03_008, 03_009), plot structure (03_002), or thematic analysis (03_006, 03_007) as primary focus, though connections may be referenced.

## WALKTHROUGH
Imagine you're listening to your grandmother tell a story — you notice she uses certain words like "बिटिया" instead of "बेटी", or says "कर दियो" instead of "कर दिया", and her sentences often trail off with "तो" or "ना". That's exactly what we do in language usage analysis: we become linguistic detectives examining HOW the author constructs the narrator's voice. Start by selecting a 2-3 page segment and circling every verb form — notice the endings (-ती, -ता, -के, -कर, -करके). Then track who speaks to whom using which honorifics (तू, तुम, आप, जी, बाबूजी). Next, identify sentences that mix Sanskritized vocabulary (तत्सम) with rustic expressions (देशज). Finally, ask: what does this linguistic layering reveal about the narrator's identity, her relationship with power, and her journey from silence to written expression? The key insight: language isn't just a vehicle for the story — it IS the story of a marginalized woman claiming her voice.

## DIAGNOSTIC_QUESTION_1
Identify the grammatical term for verb formations like "खाती-पीती", "आती-जाती", "कहती-सुनती" that appear repeatedly in the text, and explain their aspectual function in two sentences.

## DIAGNOSTIC_ANSWER_1
These are **compound verbs (संयुक्त क्रिया)** formed by combining two verbal stems (V1+V2) where the first verb (V1) carries the main lexical meaning and the second (V2) adds aspectual nuance — here, the V2 forms (खाती, पीती, आती, जाती, कहती, सुनती) are actually conjunctive participles (अन्य क्रिया रूप) indicating **simultaneous/habitual continuity** (समकालिक/नित्य निरंतरता). A wrong answer calling them "simple verbs" or "conjunctions" reveals the student cannot distinguish morphological composition from syntactic coordination, missing how Sobti uses this structure to convey the relentless, cyclical nature of domestic labor.

## DIAGNOSTIC_QUESTION_2
The narrator shifts between "मैं" (main), "हम" (ham), and "अपना" (apna) as first-person references. Explain the pragmatic difference between these forms in the context of her interactions with रक्रक, लखन नक, and her children, giving one textual instance for each.

## DIAGNOSTIC_ANSWER_2
"मैं" asserts individual agency and subjective experience (e.g., "मैं लो;ा घ डकेरा फि;क चली" — claiming ownership of her labor). "हम" signals collective identity with her children or solidarity with marginalized women (e.g., "हमारे बच्चे" — positioning herself as representative mother). "अपना" marks reflexive possession and emotional intimacy (e.g., "अपने बच्चों के लिए" — emphasizing personal stake). A student who treats these as interchangeable synonyms misses how Sobti encodes the narrator's shifting subjectivity — from isolated worker to collective representative to protective mother — through pronominal choice alone.

## DIAGNOSTIC_QUESTION_3
In the passage where रक्रक says "देखो, तुमसे कहा था न कि यहाँ पहले से ही कोई काम कर रहा है", analyze the sentence structure: identify the clause types, the function of "न", and explain how this single utterance establishes power dynamics through syntax.

## DIAGNOSTIC_ANSWER_3
The utterance contains: (1) Main clause "देखो" (imperative, verb-initial, no subject — direct command), (2) Complement clause "तुमसे कहा था" (past perfect, dative subject "तुमसे" marking indirect object as logical subject), (3) Embedded clause "कि यहाँ पहले से ही कोई काम कर रहा है" (finite clause with existential "कोई", habitual aspect "कर रहा है"). The particle "न" after "था" functions as a **confirmation-seeking tag** (पुष्टिकारक कण), presupposing shared knowledge and placing burden of agreement on listener. Syntactically, रक्रक controls all clause types — imperative, reported speech, and embedded assertion — while the narrator receives only the dative role ("तुमसे"), grammatically encoding his epistemic authority and her subordination. A student identifying only "imperative sentence" misses the layered clause embedding that performs power.

## DIAGNOSTIC_QUESTION_4
Compare the narrator's internal monologue (e.g., "मैं सोचती कि ये लोग मुझे क्यों नहीं समझते") with her spoken dialogue (e.g., "नहीं, अभी तक कोई काम नहीं आया"). Identify three systematic grammatical differences and explain how they reflect the gap between her inner consciousness and social performance.

## DIAGNOSTIC_ANSWER_4
Three differences: (1) **Tense-aspect**: Internal monologue uses imperfective/habitual ("सोचती", "रहती") reflecting ongoing mental state; spoken dialogue uses perfective/present ("नहीं आया", "है") for factual assertion. (2) **Clause complexity**: Internal monologue embeds multiple subordinate clauses ("कि ये लोग... क्यों नहीं समझते"); spoken dialogue uses paratactic, fragmented structures ("नहीं, अभी तक कोई काम नहीं आया"). (3) **Honorific avoidance**: Internal monologue uses zero honorifics for others ("ये लोग"); spoken dialogue would require honorifics if addressing superiors. This gap shows her rich interiority (complex syntax, subjective time) versus constrained exteriority (simple syntax, objective time, power-conscious register). A student listing only "different words" fails to see grammar as the site where oppression and resistance are negotiated.

## DIAGNOSTIC_QUESTION_5
Evaluate the claim: "Sobti's use of Braj/Western Hindi dialect forms (e.g., 'करियो', 'दियो', 'हौ', 'भयो') is merely decorative local color." Defend or refute using three specific grammatical arguments from the text.

## DIAGNOSTIC_ANSWER_5
**Refute.** Three arguments: (1) **Morphological systemicity**: Forms like "करियो" (optative/precative), "दियो" (perfective participle), "हौ" (1st person plural present), "भयो" (3rd person masculine perfective) follow consistent Braj paradigms — not random insertions but a coherent alternative grammar. (2) **Sociolinguistic indexing**: These forms cluster in scenes of domestic intimacy, childhood memory, and female solidarity (e.g., with लखन नक, children), marking a **vernacular feminine register** distinct from the Khari Boli of patriarchal authority (रक्रक, लखन नक के पिता). (3) **Narrative agency**: The narrator's written Hindi (the text we read) is Khari Boli, but her *remembered* speech is dialect — the dialect forms appear precisely when she reclaims her past on her own terms. Calling this "decorative" ignores how Sobti uses diglossia to stage the narrator's bilingual consciousness. A student accepting the claim reveals inability to see dialect as grammatical system with political valence.

## DIAGNOSTIC_QUESTION_6
Write a 150-word diary entry from the narrator's perspective *after* she begins writing her autobiography, using at least four grammatical features analyzed above (compound verbs, honorific shifts, dialect forms, clause embedding) to show her evolving linguistic consciousness. Annotate each feature in brackets.

## DIAGNOSTIC_ANSWER_6
**Sample response:** "आज फिर [dialect: 'फिर' as discourse marker] रक्रक बाबू ने [honorific: 'बाबू' + ergative 'ने'] कहा — 'लिखती रहो' [compound verb: V1+V2 habitual]. मैं [1st person assertion] सोचती हूँ [embedded clause: 'कि' complementizer] कि मेरी भाषा अब मेरी है [possessive 'मेरी' + equative 'है']. पहले [temporal adverb] जब मैं [subject] बोलती थी [habitual aspect], तब [subordinate clause] शब्द [object] दूसरों के [genitive] होते थे। अब [contrastive discourse marker] कलम [instrumental subject] मेरे हाथ में [locative] है और [coordination] वाक्य [subject] मेरे [genitive] बनते हैं [passive/resultative]। लखन नक [vocative] सुनो [imperative] — तुम्हारी [2nd person possessive] माँ [noun] अब [temporal] 'मैं' [quoted pronoun] से 'लेखिका' [noun] बनी [perfective]।"

**Features annotated:** [dialect], [honorific+ergative], [compound verb], [1st person], [embedding], [possessive+equative], [habitual], [subordination], [contrastive marker], [instrumental/locative], [coordination], [passive/resultative], [vocative], [2nd person possessive], [perfective]. A poor answer using only standard Khari Boli with no annotations shows the student cannot *produce* the grammatical repertoire they were asked to *analyze* — the ultimate test of analytical internalization.

## COMMON_MISCONCEPTION
Students believe "language usage analysis" means listing difficult vocabulary words (शब्दार्थ) or identifying figures of speech (अलंकार). They treat grammar as a labeling exercise — circling "verb", "noun", "adjective" — rather than analyzing **how grammatical choices construct meaning**. For example, when seeing "करती रहती", they label it "verb" and stop, missing that the V1+V2 compound encodes *gendered labor temporalities* (the "रहती" marks unending duration specifically for women's work). They also confuse **dialect** (systematic grammatical variation) with **errors** or "incorrect Hindi", failing to recognize Braj forms as a rule-governed system indexing the narrator's class, gender, and regional identity. This misconception stems from school grammar pedagogy that treats standard Khari Boli as the only "correct" grammar and literary analysis as content-only.

## ON_FAILURE
If a student reduces analysis to vocabulary listing or part-of-speech labeling: (1) Give them two parallel sentences — "वह काम करती है" vs "वह काम करती रहती है" — and ask them to act out the difference physically (one finite action, one endless cycle). (2) Show a 3-sentence excerpt with all honorifics removed; have them restore "तुम/आप/जी/बाबूजी" based on speaker-addressee relationships, proving grammar encodes social hierarchy. (3) Assign a "dialect hunt": find 5 Braj forms, identify their paradigm (e.g., "भयो" = 3rd masc. sg. perfective), and explain why Sobti chooses it *there* instead of Khari Boli "हुआ". (4) Require them to rewrite one paragraph in "standard Hindi" and compare — what is lost? (The narrator's voice, her resistance, her motherhood). This moves them from labeling to *functional* analysis.

## BUILDS_ON
c11_hin_v_cbse_03_010 (Vocabulary in Context: Key Words) — students must first recognize key lexical items before analyzing their grammatical behavior.

## LEADS_TO
c11_hin_v_cbse_03_012 (Comprehension: Literal and Inferential Questions) — grammatical awareness enables precise inference of unstated meanings, power dynamics, and narrative reliability.

## PREREQUISITE_NODE_IDS
c11_hin_v_cbse_03_010, c11_hin_v_cbse_03_002, c11_hin_v_cbse_03_004
## PREREQUISITE_REASONS
c11_hin_v_cbse_03_010: Vocabulary knowledge provides the lexical inventory needed to analyze morphological variants (e.g., recognizing "करियो" as variant of "करना").
c11_hin_v_cbse_03_002: Plot/narrative structure knowledge situates grammatical shifts at specific narrative moments (e.g., tense shift when narrator begins writing).
c11_hin_v_cbse_03_004: Protagonist analysis establishes the narrator's social position, which grammatical choices (honorifics, dialect) index and negotiate.

## FORWARD_NODE_IDS
c11_hin_v_cbse_03_012, c11_hin_v_cbse_03_013, c11_hin_v_cbse_03_014, c12_hin_a_cbse_04_011, c12_hin_a_cbse_09_011, c12_hin_a_cbse_12_011, c12_hin_ar_cbse_10_011, c12_hin_v_cbse_03_011

## FORWARD_REASONS
c11_hin_v_cbse_03_012: Grammatical analysis provides tools for literal/inferential comprehension (e.g., aspect distinguishes completed vs. ongoing actions critical for plot inference).
c11_hin_v_cbse_03_013: Critical interpretation requires linguistic evidence (e.g., honorific shifts prove changing power dynamics; dialect use proves resistance).
c11_hin_v_cbse_03_014: Writing skills (autobiographical piece) directly apply the grammatical repertoire analyzed here (compound verbs, dialect, honorifics, embedding).
c12_hin_a_cbse_04_011: अगला तार्किक चरण: This node analyzes the grammatical structures, syntactic patterns, and language usage specific to th... इस नोड की अवधारणाओं को सीधे उपयोग/विस्तारित करता है।  
c12_hin_a_cbse_09_011: Additional *sarvanam* practice — reinforces pronoun analysis skill.  
c12_hin_a_cbse_12_011: Study of verb valency and case marking in Hindi  
c12_hin_ar_cbse_10_011: Vitan Chapter 3 — honorifics in epistolary text.  
c12_hin_v_cbse_03_011: Advanced Class 11 work on linking grammar to authorial purpose.  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
none

## CHAIN_DESCRIPTION
c11_hin_v_cbse_03_010 -> c11_hin_v_cbse_03_011 -> c11_hin_v_cbse_03_012 (Vocabulary provides lexical base; Grammar analyzes structural patterning; Comprehension applies both for meaning extraction)

## THIS_FORMULA
N/A - conceptual (Language usage analysis follows a descriptive framework, not a computational formula)

## FORMULA_VARIABLES
N/A

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
linguistic

## CROSS_SUBJECT
c11_history_colonialism_language | The narrator's shift from Braj dialect (vernacular) to written Khari Boli (standard) mirrors the historical imposition of standardized Hindi/Urdu during colonial modernity, where language standardization served administrative control — her autobiography reverses this by using the standard to preserve the vernacular.
c11_sociology_gender_labor | The compound verb "खाती-पीती रहती" grammatically encodes the sociological concept of "time poverty" — women's unpaid domestic labor has no temporal boundaries (habitual aspect), unlike men's wage labor (perfective "काम करके आया").

## PREREQ_CONCEPT
Students must understand basic Hindi verb morphology (tense, aspect, mood) and pronoun/honorific system from Class 9-10.

## PREREQ_BEFORE
Ability to identify verb forms (क्रिया रूप), case markers (कारक चिह्न), and sentence types (वाक्य भेद) in simple sentences.

## PREREQ_STUCK
If stuck, review Class 10 Hindi grammar: "क्रिया के रूप और काल", "सर्वनाम और कारक", "वाक्य के भेद" — focus on aspect (साधारण/पूर्ण/अपूर्ण) and honorific distinctions (तू/तुम/आप).

## WORKED_EXAMPLE_1
PROBLEM: Analyze the grammatical construction and pragmatic force of the narrator's internal question: "मैं सोचती कि ये लोग मुझे क्यों नहीं समझते" (Page 22). Identify all grammatical features and explain how they construct her subjectivity.

STEPS:
- Step 1: Segment the sentence into clauses — Main clause: "मैं सोचती" (Subject "मैं" + Verb "सोचती", imperfective/habitual aspect, 1st person feminine singular). Subordinate clause: "कि ये लोग मुझे क्यों नहीं समझते" (Complementizer "कि" + Subject "ये लोग" + Object "मुझे" + Adverb "क्यों" + Negation "नहीं" + Verb "समझते", habitual present, 3rd person plural).
- Step 2: Identify the verb morphology — "सोचती" (root सोच् + ता/ती habitual participle + auxiliary implied) marks ongoing mental process; "समझते" (root समझ् + ता/ते habitual) marks general truth/generic statement about "these people".
- Step 3: Analyze pronoun system — "मैं" (nominative, unmarked, asserts individual agency); "ये लोग" (demonstrative plural, distal/deictic, creates us/them boundary); "मुझे" (dative/accusative, marks narrator as affected experiencer).
- Step 4: Examine negation and interrogation — "नहीं" (pre-verbal negation, scope over "समझते"); "क्यों" (wh-adverb, seeks causal explanation, embeds epistemic gap).
- Step 5: Synthesize — The habitual aspect in both verbs ("सोचती", "समझते") frames this as recurring cognitive pattern, not one-time event. The complement clause structure ("कि...") makes the thought an object of cognition, showing meta-awareness. The distal demonstrative "ये लोग" + generic habitual "समझते" constructs a structural opacity — the narrator positions herself as perennial interpreter of an opaque social world.

REASONING: This analysis moves from form (morphology, syntax) to function (aspectual framing, pronominal positioning, epistemic stance) to meaning (subjectivity construction). Each step builds evidence for the claim that grammar *is* the narrator's resistance.

ANSWER: The sentence uses a matrix clause with habitual aspect ("सोचती") embedding a complement clause ("कि...") with generic habitual ("समझते"), distal demonstrative subject ("ये लोग"), dative object ("मुझे"), and causal wh-interrogative ("क्यों") under negation. This grammar constructs the narrator as a habitual thinker perpetually confronting a structurally uncomprehending "they" — her subjectivity is forged in the gap between her continuous cognition and their persistent failure to understand.

## WORKED_EXAMPLE_2
PROBLEM: Compare the honorific address system in two exchanges: (A) रक्रक to narrator: "देखो, तुमसे कहा था न..." (Page 22) and (B) Narrator to रक्रक: "बाबूजी, मुझे काम चाहिए" (Page 21). Map the grammatical differences to power relations.

STEPS:
- Step 1: Extract address terms and pronominal forms — Exchange A: Address "देखो" (imperative, no honorific), Pronoun "तुमसे" (2nd person familiar, dative case). Exchange B: Address "बाबूजी" (honorific noun, vocative), Pronoun "मुझे" (1st person, dative — no 2nd person pronoun used).
- Step 2: Analyze case marking — "तुमसे" (dative postposition "से" on familiar pronoun) marks narrator as indirect object of speech act; "मुझे" (dative) marks narrator as experiencer of need. No 2nd person pronoun appears in B — avoidance strategy.
- Step 3: Identify verb forms — A: "कहा था" (perfective, past, 3rd person masculine singular agreeing with null subject "मैं" — रक्रक speaks of himself in 3rd person? No, "कहा था" agrees with "मैं" implied subject, but "तुमसे" is dative subject of "कहना" in dative-subject construction). B: "चाहिए" (modal predicate, impersonal, dative subject "मुझे" — need is experienced, not asserted).
- Step 4: Map to power — A: रक्रक uses imperative ("देखो"), familiar pronoun ("तुम"), dative-subject construction controlling the speech act ("तुमसे कहा था" = "I told you"), confirmation tag ("न") demanding assent. B: Narrator uses honorific address ("बाबूजी"), avoids 2nd person pronoun entirely, uses dative-experiencer construction ("मुझे चाहिए") framing need as involuntary state, not demand.
- Step 5: Conclude — Grammatically, रक्रक occupies the **agentive center** (imperative subject, familiar pronoun, active perfective verb, tag questioner); narrator occupies the **dative periphery** (dative case only, honorific address upward, modal predicate of need). The grammar *performs* the hierarchy.

REASONING: Honorifics are not just "polite words" — they are grammaticalized power indices. The dative-subject construction ("तुमसे कहा था", "मुझे चाहिए") is a syntactic resource that Sobti deploys asymmetrically: the powerful man uses it to assert past authority ("I told YOU"), the powerless woman uses it to suppress agency ("TO ME is needed").

ANSWER: Exchange A (रक्रक→नैरेटर): Imperative "देखो", familiar pronoun "तुमसे" (dative), active perfective "कहा था" with dative-subject construction, confirmation tag "न" — encodes epistemic authority and hierarchical command. Exchange B (नैरेटर→रक्रक): Honorific vocative "बाबूजी", zero 2nd person pronoun (avoidance), dative-experiencer "मुझे" with modal predicate "चाहिए" — encodes supplication and agency suppression. The grammatical asymmetry (imperative vs. vocative, familiar vs. honorific, active vs. dative-modal) *is* the power relation.

## WORKED_EXAMPLE_3
PROBLEM: The text shifts from oral/narrative mode (Pages 21-35) to written/autobiographical mode (Pages 36-57). Trace three grammatical markers of this shift and argue how they represent the narrator's transition from "spoken subject" to "writing subject".

STEPS:
- Step 1: Identify the transition point — Page 36: "रक्रक ने एक दिन कहा... 'तुम अपनी आत्मकथा लिखो'" (रक्रक commands writing). Page 37: "मैंने कलम उठाई" (narrator begins writing). Page 38: "आज से मैं रोज़ लिखूँगी" (commitment).
- Step 2: Marker 1 — **Tense-aspect density**: Oral mode: high frequency of habitual imperfective ("रहती", "करती", "जाती", "आती") reflecting cyclical oral time. Written mode: increase in perfective ("लिखा", "पढ़ा", "समझा", "हुआ") and future ("लिखूँगी", "पढ़ूँगी") — linear, teleological time of autobiography.
- Step 3: Marker 2 — **Clause embedding depth**: Oral mode: parataxis, coordination ("और", "फिर", "तो"), shallow embedding. Written mode: hypotaxis, multiple subordinate clauses ("जब मैंने लिखा कि...", "जिससे कि...", "इसलिए क्योंकि...") — syntactic complexity of literate discourse.
- Step 4: Marker 3 — **Dialect-to-standard shift**: Oral mode: Braj forms dense ("करियो", "दियो", "हौ", "भयो", "ह्वै", "किहो"). Written mode: Khari Boli standard forms dominate ("करना", "दिया", "हैं", "हुआ", "होगा", "कहा") — dialect appears only in quoted speech/memory, not narration.
- Step 5: Marker 4 — **Self-reference stabilization**: Oral mode: fluid "मैं/हम/अपना" shifting with context. Written mode: consistent "मैं" as authorial "I" — the grammatical subject of writing ("मैं लिखती हूँ", "मेरी किताब", "मेरा नाम").
- Step 6: Synthesize — The grammatical shift from habitual/paratactic/dialectal/fluid to perfective/hypotactic/standardized/stable mirrors the narrator's institutionalization as a "writer" — but note: she retains dialect in dialogue, preserving her oral self *within* the written text. Grammar enacts the dual consciousness.

REASONING: This example requires tracking grammatical distributions across a large text span (diachronic analysis within the narrative), connecting micro-features (aspect, embedding, dialect, pronominals) to macro-transition (oral→written subjectivity). It combines morphological, syntactic, sociolinguistic, and discourse-level analysis — the full toolkit of language usage analysis.

ANSWER: Three grammatical markers of the oral-to-written shift: (1) Aspectual shift from habitual imperfective (cyclical domestic time) to perfective/future (linear autobiographical time); (2) Syntactic shift from paratactic coordination to hypotactic subordination (literate complexity); (3) Register shift from Braj dialect density to Khari Boli standardization (institutional language), with dialect preserved only in quoted memory. Together, these construct the narrator's emergence as a writing subject who commands standard grammar but archives her vernacular self — grammar as both assimilation and resistance.

## COMPETENCY_QUESTION_1
QUESTION: In the episode where the narrator's son asks "माँ, तुम पढ़ी-लिखी नहीं हो न?" (Page 42), the narrator replies "नहीं बेटा, पर मैं अपनी कहानी लिख सकती हूँ". Analyze the grammatical contrast between the son's question and the mother's reply. How does the grammar encode the intergenerational shift from *oral literacy* to *written literacy*? Use at least three specific grammatical terms in your answer.

COMPETENCY: Linguistic analysis of intergenerational literacy transition

STEPS:
- Step 1: Analyze son's question — "पढ़ी-लिखी नहीं हो न": Compound adjective "पढ़ी-लिखी" (perfective participles, feminine agreement with "तुम"), copula "हो" (2nd person familiar present), negation "नहीं", tag "न" (confirmation-seeking). Frames literacy as *completed credential* (perfective) possessed/not possessed.
- Step 2: Analyze mother's reply — "लिख सकती हूँ": Modal compound "सकती हूँ" (V1 root लिख् + V2 सक् potential mood + auxiliary हूँ 1st sg.), future-oriented capacity. "अपनी कहानी" (reflexive possessive + noun) — authorship claim.
- Step 3: Contrast grammatical frameworks — Son: Static credentialism (perfective participle + copula = state). Mother: Dynamic potentiality (modal compound + future orientation = agency). Son: Familiar pronoun "तुम" + tag "न" (peer-like interrogation). Mother: Honorific avoidance (no 2nd person pronoun), "बेटा" (kinship address), 1st person "मैं" (authorial assertion).
- Step 4: Connect to literacy transition — Oral literacy (son's frame): Knowledge as *possession* (perfective "पढ़ी-लिखी"), certified by institution. Written literacy (mother's frame): Knowledge as *production* (modal "लिख सकती हूँ"), authorized by self. The grammar shifts from **stative perfective** to **dynamic modal**, from **familiar interrogation** to **authorial declaration**.

ANSWER: The son's question uses a stative perfective construction ("पढ़ी-लिखी नहीं हो") framing literacy as an achieved credential — a binary state certified by formal education. The mother's reply deploys a dynamic modal compound ("लिख सकती हूँ") framing literacy as an ongoing capacity for narrative production. Grammatically: (1) Perfective participle + copula (static state) vs. Potential modal + auxiliary (dynamic capacity); (2) Familiar pronoun + confirmation tag (peer interrogation) vs. Kinship address + 1st person authorial subject (intergenerational authority); (3) Negation of past achievement vs. Affirmation of future agency. This encodes the shift from institutional oral literacy (what you *have*) to autobiographical written literacy (what you *do*).

DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: The text ends with the narrator reflecting: "मेरी कहानी अब मेरी है। पहले जब मैं बोलती थी, तब शब्द दूसरों के होते थे। अब कलम मेरे हाथ में है और वाक्य मेरे बनते हैं।" (Page 57) This passage contains a deliberate grammatical progression. Identify the progression across the four sentences and explain how it enacts the narrator's syntactic liberation. Your answer must reference: (a) case marking shifts, (b) voice/agency alternations, (c) temporal deixis, and (d) clause complexity.

COMPETENCY: Syntactic analysis of narrative agency construction

STEPS:
- Step 1: Sentence 1 — "मेरी कहानी अब मेरी है": Genitive subject "मेरी" (possessor), nominative predicate "मेरी" (possessed), equative copula "है", temporal deictic "अब" (present anchor). Simple equative clause — assertion of ownership.
- Step 2: Sentence 2 — "पहले जब मैं बोलती थी, तब शब्द दूसरों के होते थे": Temporal deictic "पहले" (past anchor), subordinate temporal clause "जब मैं बोलती थी" (habitual aspect, 1st person subject), main clause "तब शब्द दूसरों के होते थे" (habitual past, subject "शब्द" nominative, genitive possessor "दूसरों के"). Complex hypotaxis — past subordination.
- Step 3: Sentence 3 — "अब कलम मेरे हाथ में है": Temporal deictic "अब" (present), locative construction "मेरे हाथ में" (instrumental/locative), subject "कलम" nominative, copula "है". Simple locative predication — material condition of agency.
- Step 4: Sentence 4 — "और वाक्य मेरे बनते हैं": Coordinating "और", subject "वाक्य" nominative, genitive agent "मेरे" (ergative-like agency in passive/resultative "बनते हैं"), habitual present. Passive/resultative construction with genitive agent — syntactic reclamation of production.
- Step 5: Map the progression — (a) Case: Genitive possessor (S1) → Nominative subject + Genitive possessor (S2) → Locative instrumental (S3) → Nominative subject + Genitive agent (S4) — trajectory from *possession* to *instrumental control* to *productive agency*. (b) Voice: Equative (S1) → Active habitual (S2 "बोलती थी") → Locative stative (S3) → Passive/resultative with agent (S4 "मेरे बनते हैं") — trajectory from *being* to *speaking* to *holding* to *making*. (c) Deixis: "अब" (S1) → "पहले...तब" (S2) → "अब" (S3) → implicit present (S4) — oscillation anchoring liberation in present. (d) Complexity: Simple (S1) → Complex hypotactic (S2) → Simple (S3) → Coordinated (S4) — mastering complexity then simplifying with authority.

ANSWER: The four-sentence passage enacts syntactic liberation through a calibrated grammatical progression: (a) Case marking shifts from genitive possession ("मेरी कहानी") to locative instrumental control ("मेरे हाथ में") to genitive agency in passive ("मेरे बनते हैं") — the narrator moves from owning to wielding to *generating* language. (b) Voice alternates from equative stative ("है") to active habitual ("बोलती थी") to locative stative ("है") to resultative passive with explicit agent ("मेरे बनते हैं") — the final passive-with-agent is the grammatical signature of *authorial* production (the sentences *get made by me*). (c) Temporal deixis oscillates "अब → पहले/तब → अब → [present]" — the past is subordinated ("जब...तब"), the present is claimed twice. (d) Clause complexity peaks at S2 (hypotactic temporal subordination — the grammar of memory) then resolves to simple/coordinated structures (S3-S4) — the grammar of mastery. The narrator doesn't just *say* she owns her story; the syntax *performs* the takeover.

DIFFICULTY: hard