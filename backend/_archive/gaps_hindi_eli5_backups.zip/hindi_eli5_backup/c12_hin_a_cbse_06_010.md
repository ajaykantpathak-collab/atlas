## DEFINITION
Vocabulary in Context: Key Words refers to the systematic study of significant words from the chapter "Raskhan" (रसखान), focusing on their contextual meanings, connotations, grammatical forms, and poetic usage in Braj Bhasha and Khari Boli, enabling students to decode the poet's devotional intensity and linguistic artistry.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student can independently identify, define, and explain the contextual significance of at least 15 key words from the chapter, differentiate between their literal (वाच्यार्थ) and suggested (व्यंग्यार्थ/लाक्षणिक) meanings in the poems, and use them correctly in original sentences demonstrating devotional or literary register.

## SCOPE_BOUNDARY
This node covers the key vocabulary listed in the NCERT 'शब्दार्थ' section for both poems (हरि झर झर and जतन! एक कज फिर वखो) and the introductory prose, including Braj Bhasha forms, tatsama/tadbhava distinctions, and poetic compounds. It does NOT cover general grammar rules (node 011), comprehension questions (node 012), or literary device analysis (nodes 008, 009).

## WALKTHROUGH
Imagine you are reading Raskhan's poem "हरि झर झर" and stumble on "लुसग़" — is it a verb, noun, or adjective? Does it mean "shining" or "trembling"? You cannot guess from Hindi alone because it's Braj Bhasha. Start by listing every unfamiliar word from both poems and the prose intro. Group them: (1) Braj-specific forms (लुसग़, फुल्कि, चकित), (2) Tatsama words with shifted meaning (मृदु, अहर्निश), (3) Poetic compounds (रसिक, रसखान). For each, find the NCERT gloss, then trace its root (Sanskrit/Prakrit), note the grammatical form (participle, absolutive, etc.), and finally explain why Raskhan chose THIS word over a common synonym — that is the analytical leap from meaning to artistry.

## DIAGNOSTIC_QUESTION_1
What is the literal meaning (वाच्यार्थ) of the Braj Bhasha word "लुसग़" as used in the line "लुसग़ लुसग़ लुसग़ लुसग़" from Raskhan's poem, and what is its grammatical form?

## DIAGNOSTIC_ANSWER_1
The word "लुसग़" (लुसग) is a present participle (वर्तमान कृदंत) from the root लुस् (to shine/gleam), meaning "shining, gleaming, glittering" — used here as an adverbial modifier describing the continuous shimmering of Krishna's form. A wrong answer like "trembling" or "dancing" reveals the student is guessing from sound similarity to "लहर" or "ललच" rather than consulting the NCERT gloss or recognizing the root लुस्. This error shows lack of dictionary discipline and unfamiliarity with Braj phonology where स़ represents a retroflex flap.

## DIAGNOSTIC_QUESTION_2
In the phrase "मृदु मृदु मृदु मृदु" from the same poem, the word "मृदु" is a Tatsama adjective. Explain why Raskhan repeats it four times instead of using a degree modifier like "अत्यन्त मृदु", and what poetic effect this repetition (अनुप्रास/पुनरुक्ति) creates in the context of Krishna's flute music.

## DIAGNOSTIC_ANSWER_2
The quadruple repetition "मृदु मृदु मृदु मृदु" mimics the continuous, unbroken, gentle flow of the flute melody — each utterance is a separate note, creating an auditory iconicity (ध्वन्यानुकरण) that "अत्यन्त मृदु" (a single intellectual assessment) cannot. A student who says "for emphasis" or "to show intensity" misses the mimetic function: the form *enacts* the content. This error reveals a tendency to treat poetic devices as decorative rather than structural, a gap carried from Class 11 where repetition was taught only as "अनुप्रास अलंकार" without linking to sensory enactment.

## DIAGNOSTIC_QUESTION_3
The NCERT gloss gives "चकित" = "आश्चर्यचकित" (astonished). In the line "चकित चकित चकित चकित", the word appears four times. Rewrite this line in standard Khari Boli Hindi preserving the poetic effect, and explain what is lost in translation.

## DIAGNOSTIC_ANSWER_3
Khari Boli rendering: "आश्चर्य से भरा हुआ, आश्चर्य से भरा हुआ, आश्चर्य से भरा हुआ, आश्चर्य से भरा हुआ" or "हतप्रभ, हतप्रभ, हतप्रभ, हतप्रभ". What is lost: (1) the monosyllabic brevity of "चकित" (2 syllables) vs. the polysyllabic expansion (6+ syllables), destroying the staccato rhythm mirroring a startled heartbeat; (2) the Braj phonetic flavour — the retroflex ट् in चकित adds a percussive click absent in "हतप्रभ"; (3) the participial force (कृदंत) implying a *state entered suddenly*, whereas "हतप्रभ" is a static adjective. A student who only substitutes synonyms misses the prosodic and morphological dimensions — evidence of treating vocabulary as interchangeable labels rather than sound-sense units.

## DIAGNOSTIC_QUESTION_4
Compare the compounds "रसिक" (रस + इक) and "रसखान" (रस + खान). Both contain "रस" (aesthetic sentiment/devotional nectar). Analyse how the suffixes "-इक" (tatsama, denoting 'possessor of') and "-खान" (Persian, denoting 'mine/treasure house') reflect Raskhan's dual cultural identity and his theological synthesis in the poems.

## DIAGNOSTIC_ANSWER_4
"रसिक" (Sanskrit suffix -इक) frames Raskhan within the classical Sanskrit aesthetic tradition: a connoisseur of rasa, aligned with Bharata's Natyashastra. "रसखान" (Persian खान = mine/treasure) frames him in the Indo-Islamic tradition: a *repository* of rasa, suggesting abundance and generosity. Together they encode his synthesis — he *masters* the tradition (रसिक) and *embodies* it as a gift (रसखान). A student who defines both merely as "lover of Krishna" or "poet of rasa" flattens the etymological tension that is the poem's subtext. This error stems from memorising glosses without analysing morphological ancestry — a skill explicitly built in Class 11 node c11_hin_ar_cbse_01_010 but rarely applied to proper nouns.

## DIAGNOSTIC_QUESTION_5
Evaluate the claim: "The word 'खान' in 'रसखान' is merely an honorific title like 'Khan' in Mughal court names, and has no semantic connection to the poem's imagery of Krishna's form as a treasure-house." Defend or refute using evidence from the poem "हरि झर झर".

## DIAGNOSTIC_ANSWER_5
Refute. In "हरि झर झर", Krishna's form is described as "रतन की खान" (mine of jewels) implicitly through words like "रतन", "ज्योति", "कान्ति" — the poet *sees* the divine body as a treasure-mine. "रसखान" thus means "one who *is* a mine of rasa" — not just a title but a metaphysical claim: the poet's identity *is* the reservoir of the very rasa Krishna embodies. A student accepting the claim reveals a compartmentalised reading: treating vocabulary as isolated dictionary entries rather than nodes in the poem's semantic network. This is the "label fallacy" — assuming a word's meaning is exhausted by its gloss.

## DIAGNOSTIC_QUESTION_6
Create a four-line verse (चौपाई/दोहा) in Khari Boli or Braj using at least THREE key words from the NCERT glossary (e.g., लुसग़, मृदु, चकित, रसिक, रसखान, अहर्निश, फुल्कि) such that each word retains its contextual poetic force from Raskhan's poems. Explain your choices in 2 sentences.

## DIAGNOSTIC_ANSWER_6
Example verse:
"मृदु मृदु बाजत बंसी धुनि, लुसग़ लुसग़ अंग कान्ति।
चकित चकित मन रसिक भयो, रसखान बने अनन्त॥"
Choices: "मृदु" repeated for mimetic softness; "लुसग़" for visual shimmer; "चकित" for sudden awe; "रसिक" and "रसखान" as identity progression. A poor answer uses the words as decorative insertions (e.g., "रसखान कवि मृदु बोलत लुसग़") without phonetic or semantic enactment — showing the student cannot transfer *usage* from analysis to creation.

## COMMON_MISCONCEPTION
Students treat the NCERT 'शब्दार्थ' list as a static glossary to memorise for 1-mark questions, ignoring that Raskhan's vocabulary is a *curated register* where every word carries: (a) Braj vs. Khari Boli phonology, (b) Tatsama/Tadbhava/Persian etymology signalling cultural synthesis, (c) grammatical form (participle, absolutive, compound) enacting aspectual nuance, and (d) mimetic sound patterning. For example, they learn "फुल्कि = फूल की तरह" but miss that the absolutive (कृदंत) form implies "having blossomed *into*..." — a completed action becoming a state — which mirrors the theological moment of grace. This reductionist approach costs marks in 3-mark "व्याख्या" questions where examiners expect "शब्द-चयन का सौंदर्य" analysis.

## ON_FAILURE
If a student cannot move beyond gloss-memorisation: (1) Assign a "Word Autopsy" for 5 key words: root > suffix > grammatical form > literal meaning > contextual connotation > mimetic effect — using the NCERT gloss as *starting point*, not endpoint. (2) Have them read aloud the Braj lines focusing *only* on the target word's sound (e.g., the retroflex flap in लुसग़, the dental cluster in चकित) and describe the physical sensation of pronouncing it. (3) Map each word to its Sanskrit/Persian ancestor using Monier-Williams or Platts (online) to make etymology visible. (4) Re-attempt Diagnostic Q3 and Q6 after 48 hours — if they still substitute synonyms without prosodic justification, loop to Class 11 node c11_hin_ar_cbse_01_010 for morphological analysis drill.

## BUILDS_ON
Class 11 Vocabulary in Context (c11_hin_ar_cbse_01_010) where students learned to distinguish वाच्यार्थ/लाक्षणिकार्थ and identify tatsama/tadbhava — now applied to Braj Bhasha poetic register with morphological and prosodic analysis.

## LEADS_TO
Grammar: Language Usage in the Text (c12_hin_a_cbse_06_011) where these same words become data for analysing Braj verb forms, case endings, and syntactic archaisms.

## PREREQUISITE_NODE_IDS
c11_hin_ar_cbse_01_010, c11_hin_v_cbse_01_010, c12_hin_a_cbse_06_001, c12_hin_a_cbse_06_008, c12_hin_a_cbse_06_009
## PREREQUISITE_REASONS
c11_hin_ar_cbse_01_010: Class 11 Antra Vocabulary node establishes the method of contextual meaning analysis (वाच्यार्थ/लाक्षणिकार्थ) and etymological categorisation (तत्सम/तद्भव/देशज/विदेशज) used here.
c11_hin_v_cbse_01_010: Class 11 Vitan Vocabulary node reinforces the same skillset with different texts, ensuring transferability.
c12_hin_a_cbse_06_001: Before You Read provides the historical-cultural context (Raskhan's Muslim identity, Braj Bhasha tradition) essential for interpreting Persian-Sanskrit lexical fusion.
c12_hin_a_cbse_06_008: Literary Devices: Imagery and Metaphor supplies the analytical vocabulary (मिमेटिक, ध्वन्यानुकरण, अनुप्रास) needed to explain *why* specific words create poetic effects.
c12_hin_a_cbse_06_009: Literary Devices: Irony and Symbolism provides the framework for reading "रसखान" as symbolic identity — prerequisite for Diagnostic Q4/Q5.

## FORWARD_NODE_IDS
c12_hin_a_cbse_06_011, c12_hin_a_cbse_06_012, c12_hin_a_cbse_06_013, c12_hin_a_cbse_06_015

## FORWARD_REASONS
c12_hin_a_cbse_06_011: Grammar node uses the same key words as primary data for analysing Braj morphology (verb forms, case endings, absolutives) — vocabulary mastery enables grammatical segmentation.
c12_hin_a_cbse_06_012: Comprehension questions require precise word-level understanding to answer inferential items (e.g., "चकित चकित चकित चकित से कवि की कौन-सी मन:स्थिति व्यक्त होती है?").
c12_hin_a_cbse_06_013: Critical Thinking demands evaluation of lexical choices (e.g., "रसखान ने 'खान' उपनाम क्यों चुना?") — impossible without the etymological-semantic work done here.
c12_hin_a_cbse_06_015: यदि अटकें तो c12_hin_a_cbse_06_013 (Critical Thinking) के 'दावा-प्रमाण' अभ्यास और c12_hin_a_cbse_06_010 (Vocabulary) के ब्रज शब्दों को दोहराएँ।  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
c12_history_03_001: Bhakti-Sufi traditions (Theme 3, Class 12 History) cover the same syncretic culture — Raskhan's Persian-Sanskrit vocabulary is linguistic evidence of the historical synthesis taught there.
c12_sociology_02_001: Cultural diversity and syncretism (Chapter 2, Class 12 Sociology) provides the sociological framework for analysing how language (रसिक/रसखान) encodes identity negotiation — vocabulary as social fact.

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_01_010 -> c12_hin_a_cbse_06_010 -> c12_hin_a_cbse_06_011

## THIS_FORMULA
N/A - conceptual

## FORMULA_VARIABLES
N/A

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
linguistic

## CROSS_SUBJECT
N/A | Raskhan's Braj-Persian vocabulary (रसिक/रसखान, लुसग़/चकित) is primary linguistic evidence for the Bhakti-Sufi syncretism analysed in History Theme 3 — word forms encode historical synthesis.
 N/A | The semantic shift of "खान" from honorific to "treasure-house of rasa" illustrates sociology's concept of cultural appropriation and re-signification — vocabulary as site of identity construction.
## PREREQ_CONCEPT
Morphological segmentation (root + suffix) and contextual meaning layers (literal > suggested > mimetic) from Class 11 Vocabulary nodes.

## PREREQ_BEFORE
Student must be able to: (1) segment a word into root + suffix, (2) distinguish वाच्यार्थ from लाक्षणिकार्थ, (3) identify tatsama/tadbhava/foreign origin, (4) read Braj Bhasha script with basic phonetic accuracy.

## PREREQ_STUCK
If stuck on Braj forms (लुसग़, फुल्कि), revisit Class 11 node c11_hin_v_cbse_01_010 where Braj phonology (retroflex flap, vowel length) was introduced with comparative examples.

## WORKED_EXAMPLE_1
PROBLEM: Analyse the word "अहर्निश" (अहः + निशा) from the prose introduction. Explain its formation, literal meaning, contextual connotation in Raskhan's biography, and why the poet-biographer chooses this Tatsama compound over the common Tadbhava "दिन-रात".

STEPS:
- Step 1: Segment the compound — "अहः" (day, from अहन्) + "निशा" (night) = अहर्निश (day and night, continuously). Identify as द्वन्द्व समास (copulative compound) with both members retaining independence.
- Step 2: Note the register — fully Tatsama (Sanskrit), zero phonological adaptation to Braj/Hindi. This signals formal, elevated, biographical narration distinct from the poems' Braj register.
- Step 3: Literal meaning: "day and night, incessantly, continuously". Contextual connotation in the prose: Raskhan's *unbroken* devotion — "अहर्निश हरि-चिन्तन" implies a yogic constancy, not mere habit.
- Step 4: Contrast with "दिन-रात" (Tadbhava). "दिन-रात" is colloquial, temporal; "अहर्निश" is literary, eternalising — it frames Raskhan's devotion as *tapasya* (austerity), aligning him with Sanskrit bhakti tradition (e.g., Narada Bhakti Sutra).
- Step 5: Verify against the text — the prose says "अहर्निश हरि-चिन्तन में लगे रहते थे". The compound compresses "every moment of every day and night" into one prosodically heavy word (गुरु-लघु-गुरु), slowing the reader's pace to mirror the constancy described.

REASONING: This 5-step method (segment > register > literal > contrast > prosodic verification) moves from form to function to aesthetic choice — the exact trajectory examiners reward in "शब्द-चयन का सौंदर्य" questions.

ANSWER: "अहर्निश" is a Tatsama द्वन्द्व समास meaning "incessantly", chosen over "दिन-रात" to elevate Raskhan's devotion to the status of classical साधना, with its heavy meter (गुरु-लघु-गुरु) enacting temporal expansiveness.

## WORKED_EXAMPLE_2
PROBLEM: The NCERT gloss gives "फुल्कि" = "फूल की तरह" (like a flower). In the line "फुल्कि फुल्कि फुल्कि फुल्कि", analyse why the absolutive (कृदंत/ल्यप्) form is used instead of the adjective "फुल्ल" (blossomed) or the noun "फूल", and what the quadruple repetition achieves.

STEPS:
- Step 1: Identify grammatical form — "फुल्कि" is an absolutive (ल्यप् कृदंत) from the root फुल् (to blossom), meaning "having blossomed" or "in a blossomed manner". It denotes *manner of action*, not state.
- Step 2: Contrast with alternatives — "फुल्ल" (past participle) = "blossomed" (resultant state); "फूल" (noun) = "flower" (object). The absolutive "फुल्कि" = "blossoming-ly, in the mode of blossoming" — it modifies the *verb* (implied: शोभते/विहरते), describing *how* Krishna's form appears.
- Step 3: Contextualise — the line describes Krishna's limbs/form: each limb "blossoming-ly" radiates beauty. The absolutive captures the *dynamic process* of beauty unfolding, not a static attribute.
- Step 4: Repetition effect — four absolutives in sequence create a "cascading manner adverbial": each limb, each gesture, each glance, each smile — all blossoming-ly. The phonetic lightness (लघु-लघु) of "फुल्कि" mimics petals opening.
- Step 5: Theological link — in Braj bhakti, the divine form is *ever-fresh* (नित्यनूतन), never static. "फुल्कि" as process-word encodes this theology; "फुल्ल" would freeze it.

REASONING: Grammatical form (absolutive vs participle vs noun) is not a technical detail — it *is* the theological statement. The worked example models how to derive meaning from morphology, a skill tested in 4-mark "भाषिक सौंदर्य" questions.

ANSWER: "फुल्कि" (absolutive) denotes dynamic manner ("blossoming-ly"), chosen over static "फुल्ल" to enact the theology of Krishna's ever-fresh form; quadruple repetition distributes this manner across four dimensions of his beauty with petal-light phonetics.

## WORKED_EXAMPLE_3
PROBLEM: Synthesise vocabulary, imagery, and cultural context: Explain how the cluster {रसिक, रसखान, रस, रसना, रसाल} in the chapter constructs a "lexical field of rasa" that bridges Sanskrit poetics (Bharata), Braj bhakti (Vallabha), and Persianate culture (Khan), and why this matters for a Class 12 board answer on "Raskhan's synthesis".

STEPS:
- Step 1: List all "रस-" words in the chapter — रसिक (prose), रसखान (title/pen-name), रस (poems: "रस की खान", "रसना"), रसना (tongue/taste-organ, poem 2), रसाल (juicy, poem 2). Note: रसना and रसाल are in the second poem per NCERT gloss.
- Step 2: Tag each with origin and register — रसिक (Tatsama, Sanskrit poetics), रसखान (Tatsama + Persian, hybrid), रस (Tatsama, core concept), रसना (Tatsama, physiological), रसाल (Tatsama, adjective).
- Step 3: Map to traditions — रसिक invokes Bharata's रस-सूत्र (रसिक = rasajña); रसखान invokes Persianate naming (खान = mine/lord) *and* Sanskrit रस; रसना invokes both Ayurvedic physiology (taste-organ) and poetic "tasting" of rasa; रसाल invokes Vallabha's "रसाल श्रीकृष्ण" (Krishna as embodiment of rasa).
- Step 4: Show the synthesis arc — The prose *introduces* रसिक (Sanskrit connoisseur); the pen-name रसखान *declares* hybrid identity; the poems *enact* it through रस (core), रसना (instrument of tasting), रसाल (Krishna's nature). The lexical field *is* the argument.
- Step 5: Board-answer structure — Open: "Raskhan's vocabulary constructs a lexical field of rasa..." Body: 3 paragraphs (Sanskrit register, Persian register, Braj enactment). Close: "Thus every word performs the synthesis it describes." This is the 5-mark "विश्लेषणात्मक उत्तर" pattern.

REASONING: Competitive exams (CUET, JEE Hindi) and Board 5-markers demand *interconnected* analysis — not isolated word meanings but lexical networks mapped to cultural history. This example models that synthesis.

ANSWER: The रस-lexical field (रसिक→रसखान→रस→रसना→रसाल) moves from Sanskrit poetics (रसिक) through hybrid identity (रसखान) to Braj enactment (रस, रसना, रसाल), each word a node in the synthesis — the vocabulary *performs* the theology.

## COMPETENCY_QUESTION_1
QUESTION: A student writes in a board exam: "रसखान ने 'लुसग़', 'मृदु', 'चकित', 'फुल्कि' शब्दों का प्रयोग कृष्ण के सौंदर्य को दिखाने के लिए किया है।" Award marks out of 3 using CBSE marking scheme logic, and rewrite the answer to earn full marks.

COMPETENCY: Critical evaluation of peer response / Marking scheme application

STEPS:
- Step 1: Identify the deficit — the answer lists words and states a generic purpose ("show beauty") without: (a) distinguishing Braj vs Tatsama register, (b) analysing grammatical form (participle, absolutive, repetition), (c) linking to mimetic effect, (d) connecting to synthesis theme.
- Step 2: Apply CBSE 3-mark rubric for "शब्द-चयन का सौंदर्य" — 1 mark for identification, 1 for analysis of form/meaning, 1 for thematic link. The given answer gets 1/3 (only identification).
- Step 3: Rewrite with 3 components: (i) "लुसग़" (Braj participle) enacts shimmering motion; "मृदु" (Tatsama) quadrupled mimics flute's soft continuity; "चकित" quadrupled enacts startled awe; "फुल्कि" (absolutive) quadrupled distributes dynamic blossoming. (ii) Register shift: Braj words for sensory immediacy, Tatsama for theological weight. (iii) Together they construct Krishna's form as *simultaneously* accessible (Braj) and transcendent (Sanskrit).
- Step 4: Verify word count ~60 words, uses terms "कृदंत", "अनुप्रास", "ध्वन्यानुकरण", "तत्सम/ब्रज" — examiner triggers.

ANSWER: Original: 1/3 (generic). Rewritten: "रसखान ब्रज के कृदंत रूपों (लुसग़, फुल्कि) द्वारा कृष्ण के रूप की गतिशील छवि रचते हैं — लुसग़ की झरझर ज्योति, फुल्कि का खिलता सौंदर्य। तत्सम 'मृदु' व 'चकित' की चतुर्थी आवृत्ति बंसी की मृदुता व भक्त के विस्मय का ध्वन्यानुकरण करती है। ब्रज की संवेदनशीलता व संस्कृत की गरिमा का यह संश्लेषण ही रसखान की भक्ति का भाषिक रूप है।" (3/3)

DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: In the poem "जतन! एक कज फिर वखो", the word "वखो" (imperative) appears. The NCERT gloss: "वखो = कहो, सुनाओ". A student translates the line "जतन! एक कज फिर वखो" as "Try! Tell one more story." Critique this translation using linguistic, poetic, and theological criteria. Provide a superior translation with justification.

COMPETENCY: Translation criticism / Register sensitivity / Theological literacy

STEPS:
- Step 1: Linguistic — "वखो" is Braj imperative of वखन (to speak/narrate), cognate with Sanskrit व्यख्यान (exposition). "Tell a story" reduces व्याख्यान/वखन to casual narration; the register is *expository*, *authoritative*, *revelatory*.
- Step 2: Poetic — "कज" (काज = कार्य/लीला) + "वखो" = "expound the divine play". The line is addressed to the *self* or the *heart* (मन) — an internal command to re-enter the narrative, not to entertain an audience.
- Step 3: Theological — In Vallabha sampradaya (Raskhan's tradition), "कथन" (speaking Krishna's lila) *is* seva (service). "वखो" is a ritual act, not communication. "Story" implies fiction; "लीला" implies divine truth.
- Step 4: Superior translation — "यत्न करो! एक लीला का पुन: व्याख्यान करो।" or "जतन! एक काज (लीला) फिर से उद्घाटित करो।" Justification: "यत्न/जतन" (effort/vow), "काज/लीला" (divine act), "व्याख्यान/उद्घाटन" (exposition/revelation) preserve the ritual-exegetical force.
- Step 5: Board relevance — This level of translation critique appears in CUET Hindi "अनुवाद समीक्षा" and Board "भावार्थ/व्याख्या" where "कहानी" for "काज/लीला" loses 2 marks.

ANSWER: The translation "Tell one more story" fails on three counts: (1) Linguistic — "वखो" = व्याख्यान (exposition), not casual telling; (2) Poetic — address is to self/heart for re-immersion, not audience; (3) Theological — Krishna's lila is not "story" but revelatory truth. Better: "यत्न करो! एक लीला का पुनर्व्याख्यान करो।" — preserves ritual-exegetical register.

DIFFICULTY: hard