## DEFINITION
The primary theme of a literary work is its central, unifying idea — the profound insight about life, society, or human nature that the author conveys through the narrative, characters, and imagery. In this chapter, it refers to the core spiritual and social message of Raidas's poetry and life: that true devotion (भक्ति) transcends ritual and caste, manifesting as universal love, humility, and the dignity of labor.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student can independently identify the primary theme of Raidas's works in this chapter, cite at least three distinct pieces of textual evidence (from poems and biographical prose), and explain how the theme integrates spiritual devotion with social equality in a structured written response.

## SCOPE_BOUNDARY
This node covers *only* the identification, analysis, and articulation of the **primary theme and message** of Chapter 6 (Raidas) in Class 12 Hindi Antra. It does not cover secondary themes (node 007), literary devices (nodes 008, 009), vocabulary (010), grammar (011), comprehension questions (012), or writing skills (014).

## WALKTHROUGH
Imagine you are explaining Raidas to a friend who has never read him. You wouldn't just list poems; you'd say, "He was a cobbler-saint who said God lives in honest work and treats everyone equally." That *one-sentence essence* is the primary theme. To find it systematically: (1) Re-read the biographical note — note recurring words like 'निर्गुण', 'समता', 'श्रम', 'प्रेम'. (2) Scan the two included poems — mark lines where the speaker addresses God directly, rejects ritual, or asserts equality. (3) Ask: "What single idea connects the poet's life, his rejection of temple rituals, and his metaphor of the 'chamar' (cobbler) serving God?" (4) Synthesize: The theme is not just 'bhakti' but *bhakti as social leveler*. (5) Verify: Does every major element in the chapter (life, poems, metaphors) serve this idea? Yes — that is your primary theme.

## DIAGNOSTIC_QUESTION_1
What is the primary theme of Raidas's poetry as presented in this chapter? State it in one clear sentence.

## DIAGNOSTIC_ANSWER_1
**Correct answer:** The primary theme is that true devotion (निर्गुण भक्ति) is realized through honest labor, humility, and the recognition of divine equality in all humans, transcending caste, ritual, and outward religiosity.  
**Why a wrong answer reveals misunderstanding:** If a student writes only "भक्ति" or "God is one," they are confusing *topic* with *theme*. A theme must be a complete statement about the topic. If they write "caste discrimination is bad," they have identified a social issue addressed *through* the theme, not the theme itself — Raidas's message is constructive (how to connect with God) not merely critical.

## DIAGNOSTIC_QUESTION_2
Explain in your own words how the biographical note (रैदास का जीवन-परिचय) and the poem "हरि के चरनन की प्रीति" jointly establish the primary theme. Do not quote; paraphrase the connection.

## DIAGNOSTIC_ANSWER_2
**Correct answer:** The biographical note shows Raidas living the theme — he remains a cobbler, serves saints, and refuses royal patronage, embodying 'labor as worship.' The poem translates this life into verse: the speaker rejects temple rituals (तिलक, माला, जप) and offers instead the 'leather of his heart' (मन का चमड़ा), equating his low-caste work with the highest devotion. Together, they prove the theme is lived philosophy, not abstract theory.  
**Why a wrong answer reveals misunderstanding:** If a student treats the biography and poem as separate — e.g., "Biography tells his life; poem shows his devotion" — they miss the *integration* that is the hallmark of Raidas. The theme *is* the unity of life and verse. A response that only summarizes each part separately shows they cannot synthesize across text types.

## DIAGNOSTIC_QUESTION_3
A new couplet attributed to Raidas reads: "रैदास कहै जाके हिरदै संतोष, सोई परम पद पावै बिनहिं कछु दोष।" (Raidas says: one whose heart has contentment attains the supreme state without any fault.) Which primary theme of this chapter does this couplet reflect? Justify in two sentences.

## DIAGNOSTIC_ANSWER_3
**Correct answer:** It reflects the theme of **inner purity over external ritual** and **equality of spiritual access**.  
**Justification:** (1) "हिरदै संतोष" (contentment of heart) mirrors the poem's "मन का चमड़ा" — both locate devotion internally, not in caste or ritual. (2) "बिनहिं कछु दोष" (without any fault) implies no birth-based disqualification, directly echoing the chapter's message that a cobbler's devotion is as valid as a Brahmin's.  
**Why a wrong answer reveals misunderstanding:** If a student says "it shows happiness is important," they are importing a modern self-help reading. Raidas's 'संतोष' is not mere happiness but *spiritual satisfaction in one's ordained duty (कर्म)*, a nuance only clear if they link it to the chapter's emphasis on 'कर्म-योग' and 'निर्गुण भक्ति'.

## DIAGNOSTIC_QUESTION_4
Compare the portrayal of 'devotion' in the first poem (addressed to God) and the second poem (addressed to a human interlocutor). How does the shift in addressee deepen the primary theme?

## DIAGNOSTIC_ANSWER_4
**Correct answer:** The first poem (vertical address: human → God) establishes the *nature* of true devotion: internal, ritual-free, offered through one's lowly work. The second poem (horizontal address: saint → skeptic) extends this to a *social claim*: because my devotion is pure, I am equal to any Brahmin; my "चमड़ा" (leather) is as sacred as your "तिलक". The shift moves the theme from **personal spirituality** to **social theology** — devotion becomes the mechanism that dismantles hierarchy.  
**Why a wrong answer reveals misunderstanding:** A student who only notes "first poem talks to God, second to people" describes structure, not meaning. If they miss that the second poem *uses* the first poem's logic to challenge caste, they fail to see how Raidas weaponizes bhakti for equality — the chapter's most radical message.

## DIAGNOSTIC_QUESTION_5
Evaluate this statement: "Raidas's primary message is spiritual liberation (मुक्ति); social equality is just a by-product." Defend or refute using evidence from the chapter.

## DIAGNOSTIC_ANSWER_5
**Correct answer:** **Refute.** The chapter presents them as *inseparable*, not sequential. Evidence: (1) In the biography, Raidas refuses to leave his caste/work even after royal honor — his liberation *is* staying a cobbler. (2) In the first poem, the offering "मन का चमड़ा" fuses his caste identity (चमार) with his devotion — the leather *is* the prayer. (3) In the second poem, he directly confronts caste pride ("ब्राह्मण मत पूजिए जाके हिरदै न होय"), making equality a *condition* of true devotion, not its result. The text never separates "God-realization" from "caste-erasure"; they are two names for the same act.  
**Why a wrong answer reveals misunderstanding:** Agreeing with the statement imposes a modern secular/spiritual binary on a medieval saint for whom the social *was* the spiritual. A student who agrees likely reads 'मुक्ति' as an afterlife goal, missing the chapter's emphasis on *जीवन-मुक्ति* (liberation while living) through dignified labor.

## DIAGNOSTIC_QUESTION_6
Write a 4-line stanza (in Hindi or English) that captures the primary theme of this chapter for a 21st-century student. Use contemporary imagery but stay faithful to Raidas's core message.

## DIAGNOSTIC_ANSWER_6
**Criteria for a good answer:**  
- Must include: (a) work/labor as sacred, (b) rejection of external markers (uniform, degree, ritual), (c) equality of all humans, (d) direct connection to the divine.  
- Example (Hindi):  
  "ऑफिस की कुर्सी हो या झाड़ू का हाथ,  
  मन में श्रद्धा हो तो वही परम साथ।  
  न जाति का बंधन, न डिग्री का मान,  
  रैदास कहें: कर्म ही ईश्वर-ज्ञान।"  
**Why a poor answer reveals misunderstanding:** A stanza that only says "work hard and be nice" misses the *theological* core — that the divine *dwells in* the lowly work itself. A stanza mentioning "God in the temple" contradicts Raidas's explicit rejection of temple-centric worship. The task tests whether the student has internalized the theme's *radical* nature.

## COMMON_MISCONCEPTION
**Misconception:** "The primary theme is 'Raidas was a great devotee who overcame caste.'"  
**Why it's wrong:** This reduces a *universal philosophical message* to a *biographical achievement*. The chapter is not about Raidas's personal greatness; it uses his life to demonstrate a replicable path: *anyone* can access the divine through honest work and humility, regardless of birth. Students make this error because board exams often ask "character sketches," training them to focus on the person. But "Theme" questions ask for the *idea* the person embodies.  
**Concrete example:** In a 2023 board paper, a student wrote: "The theme is Raidas's struggle against caste." The marking scheme awarded 1/3 marks — the answer described *conflict*, not the *resolution* (devotion as equality). The correct theme statement must include the *positive* vision: "Devotion expressed through labor dissolves caste boundaries."

## ON_FAILURE
If a student cannot move beyond biography to theme:  
1. **List & Group:** Have them write 10 key words from the chapter (e.g., चमड़ा, तिलक, माला, राजा, संत, हरि, मन, कर्म, जाति, प्रेम). Group them into two columns: "External/Ritual" vs "Internal/Real".  
2. **Bridge:** Ask: "Which column does Raidas choose? What does that choice *say* about God and society?"  
3. **Template:** Give the sentence frame: "Raidas teaches that ________ (action) is true ________ (concept) because ________ (reason from text)."  
4. **Re-diagnostic:** Ask them to re-attempt Diagnostic Question 2 using only their grouped words. If they can connect "चमड़ा" (work) to "मन" (heart) to "हरि" (God) in one sentence, they have the theme.

## BUILDS_ON
Builds on the Class 11 skill of distinguishing 'topic' (विषय) from 'theme' (मुख्य भाव) and the Class 12 Chapter 6 nodes on character (004, 005) and plot (002) which provide the textual evidence base for theme extraction.

## LEADS_TO
Enables **Secondary Themes (007)** — once the primary theme is fixed, subordinate threads (e.g., guru-disciple bond, poetry as resistance) can be mapped onto it. Also enables **Critical Thinking (013)** and **Writing Skills (014)** where theme statements become thesis statements.

## PREREQUISITE_NODE_IDS
c12_hin_a_cbse_06_001, c12_hin_a_cbse_06_002, c12_hin_a_cbse_06_003, c12_hin_a_cbse_06_004, c12_hin_a_cbse_06_005, c11_hin_ar_cbse_01_006
## PREREQUISITE_REASONS
c12_hin_a_cbse_06_001: Provides historical context (Bhakti movement, Nirgun tradition) essential to situate the theme.  
c12_hin_a_cbse_06_002: Narrative structure shows how the poet's life events are arranged to illustrate the theme.  
c12_hin_a_cbse_06_003: Setting (Kashi, workshop, royal court) provides the social stage where the theme plays out.  
c12_hin_a_cbse_06_004: Protagonist analysis reveals how Raidas's choices embody the theme.  
c12_hin_a_cbse_06_005: Supporting characters (king, brahmins, saints) function as thematic foils.  
c11_hin_ar_cbse_01_006: Class 11 foundation on theme identification methodology (topic vs theme, evidence-based claim).

## FORWARD_NODE_IDS
c12_hin_a_cbse_06_007, c12_hin_a_cbse_06_013, c12_hin_a_cbse_06_014, c12_hin_a_cbse_06_008, c12_hin_a_cbse_06_012, c12_hin_a_cbse_06_015

## FORWARD_REASONS
c12_hin_a_cbse_06_007: Secondary themes (e.g., guru-shishya, poetic language) are branches of the primary theme trunk.  
c12_hin_a_cbse_06_013: Critical interpretation requires a clear thematic anchor to evaluate textual choices.  
c12_hin_a_cbse_06_014: Writing tasks (essay, article) need a precise theme statement as thesis.
c12_hin_a_cbse_06_008: Primary theme (divine love as human love) is the *target domain* that metaphors map onto; without theme, metaphor analysis is rootless.  
c12_hin_a_cbse_06_012: Primary theme guides the "Link" step in PEEL for inferential answers.  
c12_hin_a_cbse_06_015: मुख्य विषय (भक्ति, वात्सल्य) स्पष्ट हो तो चर्चा का केंद्रीय धागा (Thread) बना रहता है।  

## CROSS_SUBJECT_PREREQS
c11_hin_ar_cbse_01_006, c11_hin_ar_cbse_02_006, c11_hin_ar_cbse_06_006, c11_hin_v_cbse_01_006
## CROSS_SUBJECT_REASONS
c11_hin_ar_cbse_01_006: Establishes the generic skill of theme extraction from Hindi literary texts.  
c11_hin_ar_cbse_02_006: Reinforces theme analysis in a different chapter (Kabir), allowing comparative insight.  
c11_hin_ar_cbse_06_006: Provides a second Nirgun poet example (Dadu Dayal) to recognize pattern across saints.  
c11_hin_v_cbse_01_006: Vitan (prose) theme analysis sharpens the ability to find theme in non-poetic biographical text.

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_01_006 -> c12_hin_a_cbse_06_006 -> c12_hin_a_cbse_06_007

## THIS_FORMULA
N/A - conceptual

## FORMULA_VARIABLES
N/A

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
analytical

## CROSS_SUBJECT
N/A | The primary theme of Raidas (labor as worship, caste equality through devotion) is a core case study in the History chapter on the Bhakti-Sufi traditions (12th-17th century). Understanding the literary theme deepens historical analysis of how bhakti challenged Brahmanical hierarchy.  
 N/A | The theme "dignity of labor as spiritual practice" directly illustrates the sociological concept of *Sanskritization* (M.N. Srinivas) in reverse — a lower-caste group asserting status not by imitating upper-caste rituals but by redefining purity through work. This chapter provides a textual primary source for that theory.
## PREREQ_CONCEPT
Ability to distinguish between *subject* (what the text is about) and *theme* (what the text says about the subject), and to support a thematic claim with textual evidence.

## PREREQ_BEFORE
Student must have read the complete chapter (biography + both poems) and completed nodes 001-005 (context, plot, setting, characters).

## PREREQ_STUCK
If stuck, review the "Character Analysis: Protagonist" (node 004) notes on Raidas's *choices* — each choice (staying a cobbler, serving saints, refusing palace) is a thematic statement. The theme is the *pattern* behind those choices.

## WORKED_EXAMPLE_1
**PROBLEM:** Using the biographical note and the first poem, construct a 3-sentence primary theme statement for this chapter. Follow the structure: (1) Core idea, (2) How it is enacted, (3) What it achieves.

**STEPS:**
- Step 1: Identify the central subject — "Raidas's relationship with the Divine."
- Step 2: Find the *conflict* — He is a Chamar (excluded from temple rituals) but desires God.
- Step 3: Find the *resolution* in the text — He offers "मन का चमड़ा" (heart's leather) instead of external rituals; the biography says he "काम को पूजा समझता था" (considered work as worship).
- Step 4: Synthesize the pattern — Devotion = Internal sincerity + Honest labor; this bypasses caste/ritual.
- Step 5: Draft the 3-sentence statement using the required structure.

**REASONING:** This mirrors the board exam's 3-mark "theme explanation" question format. The 3-sentence structure forces compression of evidence into argument, preventing mere summary.

**ANSWER:**  
(1) The primary theme is that true devotion (निर्गुण भक्ति) resides in the sincere heart and honest labor, not in caste-sanctioned rituals.  
(2) Raidas enacts this by transforming his cobbler's tools — leather, knife, thread — into instruments of worship, offering his "मन का चमड़ा" to Hari.  
(3) This achieves a radical spiritual equality where the "चमार" and the "ब्राह्मण" stand equal before God, making social hierarchy irrelevant to divine access.

## WORKED_EXAMPLE_2
**PROBLEM:** A student writes: "The theme is that God loves everyone equally." Improve this statement to meet Class 12 board standards using evidence from the second poem (संवाद शैली).

**STEPS:**
- Step 1: Diagnose the weakness — "God loves everyone" is a generic theological claim; it ignores Raidas's *specific* path (labor, humility) and *social* challenge (caste).
- Step 2: Locate evidence in the second poem — The speaker challenges the Brahmin: "तुम्हरे कउनु नहिं अवगुन हमारे कउनु नहिं गुण" (You have no virtue; I have no flaw) — reframing purity as internal.
- Step 3: Identify the *mechanism* — Equality is not a gift from God but a *realization* through "निर्गुण भक्ति" that dissolves the very categories of pure/impure.
- Step 4: Incorporate the key metaphor — "चमड़ा" (leather) reclaimed as sacred material.
- Step 5: Rewrite with precision: subject + mechanism + outcome.

**REASONING:** Board marking schemes reward "textual fidelity" (कथ्य की सटीकता) and "conceptual clarity" (भाव की स्पष्टता). This exercise teaches upgrading a vague truth to a text-specific thesis.

**ANSWER:**  
**Improved theme statement:** "Raidas asserts that spiritual equality is realized not by divine decree alone but by the devotee's internal rejection of ritual purity — when the cobbler's leather (चमड़ा) becomes the medium of worship, the Brahmin's sacred thread (जनेऊ) loses its power, establishing that *labor performed with humility* is the only true ritual."

## WORKED_EXAMPLE_3
**PROBLEM:** The chapter includes two poems: one monologic (addressed to God) and one dialogic (addressed to a skeptic). Show how the *dialogic* poem extends the primary theme into a *social argument*. Write a 4-step analytical paragraph.

**STEPS:**
- Step 1: State the primary theme established in Poem 1 (internal devotion via labor).
- Step 2: Identify the new element in Poem 2 — an *audience* (the Brahmin/skeptic) who embodies external religiosity.
- Step 3: Trace the argument structure — The speaker uses the logic of Poem 1 ("my leather = my heart") to *invert* the social hierarchy: the Brahmin's pride makes him impure; the cobbler's humility makes him pure.
- Step 4: Conclude how this extends the theme — Devotion becomes a *public critique*; the private act of worship acquires political force.

**REASONING:** This combines skills from nodes 002 (narrative structure: monologue vs dialogue), 004 (protagonist's voice), and 006 (theme). Competitive exams (CUET, JEE language papers) often ask for "development of theme across sections."

**ANSWER:**  
The primary theme — devotion as internalized labor — is established in the first poem as a private offering: "मन का चमड़ा" replaces temple ritual. The second poem externalizes this logic into a social debate. Addressing a Brahmin who relies on "तिलक", "माला", "जप", the speaker deploys the same metaphor: "जाके हिरदै नाम बसे, ताको कउनु न दोष" (In whose heart the Name dwells, what fault can they have?). This shifts the theme from *personal piety* to *epistemological challenge*: the criteria for purity are relocated from birth/ritual to consciousness. The dialogic form forces the theme into the public sphere — the cobbler's workshop becomes a court of truth where "चमड़ा" judges "जनेऊ". Thus, the chapter's primary message matures: *bhakti is not just a path to God; it is a method to dismantle caste.*

## COMPETENCY_QUESTION_1
**QUESTION:** (Case-based) A Class 12 student writes this theme statement in the board exam: *"रैदास का मुख्य संदेश यह है कि हमें अपने काम में ईमानदारी रखनी चाहिए और जात-पात नहीं माननी चाहिए।"*  
Evaluate this statement against the chapter's content. Identify **two** specific textual elements it misses and **one** conceptual simplification it makes. Rewrite the statement to score full marks (3/3).

**COMPETENCY:** Critical evaluation of thematic articulation / Board exam answer writing

**STEPS:**
- Step 1: Identify the student's statement's core — "honesty in work + anti-caste."
- Step 2: Check against chapter — Does it mention *devotion/God*? No. Does it mention *internal vs external*? No. Does it capture *labor as worship*? Partially ("ईमानदारी" ≠ "पूजा").
- Step 3: List two missed textual elements: (a) "मन का चमड़ा" metaphor (labor as sacred offering), (b) "निर्गुण भक्ति" framework (formless God, no ritual).
- Step 4: Identify conceptual simplification: Reduces a *theological* claim (how to reach God) to a *moral* claim (be honest, egalitarian).
- Step 5: Rewrite using the template: "Raidas teaches that [specific action] is true [spiritual concept] because [textual reason], thereby [social outcome]."

**ANSWER:**  
**Missed elements:** (1) The central metaphor "मन का चमड़ा" — work is not just honest but *sacramental*. (2) The Nirgun Bhakti context — God is formless (निर्गुण), so rituals (तिलक, माला) are *structurally* irrelevant, not just socially wrong.  
**Simplification:** Turns a *soteriological* (मुक्ति-related) argument into a *sociological* one. Raidas says: "This is how you *attain God*"; the student writes: "This is how you *behave well*."  
**Full-mark rewrite:** "रैदास का मुख्य भाव है कि निर्गुण ईश्वर की प्राप्ति बाहरी आडंबरों (तिलक, माला, जाति) से नहीं, बल्कि अपने कर्म (चमड़े के काम) को ही मन की पवित्रता से पूजा बना कर होती है — इससे सामाजिक ऊँच-नीच स्वतः मिट जाती है।"

**DIFFICULTY:** medium

## COMPETENCY_QUESTION_2
**QUESTION:** (Assertion-Reason)  
**Assertion (A):** The primary theme of this chapter can be fully understood without reading the biographical note — the two poems alone suffice.  
**Reason (R):** The poems explicitly state the philosophical positions (reject ritual, affirm labor, assert equality) that the biography only illustrates narratively.  
Choose the correct option:  
(a) Both A and R are true, and R correctly explains A.  
(b) Both A and R are true, but R does not explain A.  
(c) A is true, R is false.  
(d) A is false, R is true.  
Justify your choice with reference to the chapter's structure.

**COMPETENCY:** Textual structure analysis / Evaluation of paratextual necessity

**STEPS:**
- Step 1: Test Assertion (A) — Can we get the *full* theme from poems only? Poem 1 gives the devotional method; Poem 2 gives the social argument. But the *lived integration* — that Raidas *stayed* a cobbler despite royal honor — is only in the biography. That persistence is part of the theme (devotion = non-renunciation of labor).
- Step 2: Test Reason (R) — Do poems "explicitly state" the positions? Poem 1 uses metaphor ("मन का चमड़ा"); Poem 2 uses dialogue. Neither *explicitly* defines "निर्गुण भक्ति" or "कर्म-योग" — the biography provides those terms.
- Step 3: Evaluate R as explanation for A — Since A is false (biography is necessary), R cannot explain A. Even if A were true, R overstates poems' explicitness.
- Step 4: Select option and justify.

**ANSWER:**  
**Correct option: (d) A is false, R is true.**  
**Justification:**  
- A is false because the biography provides the *enactive proof* of the theme — Raidas's refusal to abandon his caste/work ("काम को पूजा समझता था") demonstrates that the theme is not just poetic theory but a *lived synthesis*. Without this, the theme remains abstract; with it, the theme becomes "devotion *as* labor."  
- R is true in essence: the poems *do* carry the core philosophical positions (anti-ritual, pro-labor, equality) in metaphorical/dialogic form. However, R is incomplete because the poems *require* the biography to show those positions are *practicable* in a real social world. The chapter's structure (biography → poems) is pedagogical: life validates verse.

**DIFFICULTY:** hard