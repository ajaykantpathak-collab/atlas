## DEFINITION
Writing Skills based on the chapter refers to the ability to construct structured, evidence-based answers for poetry analysis questions in board exams, using the PEEL (Point, Evidence, Explanation, Link) method to analyze themes, literary devices, tone, and central idea of the poem "vkvks] feydj cpk,¡" by Fuezyk iqrqy.

## COGNITIVE_LEVEL
apply

## MASTERY_CRITERIA
The student can independently write a 150-200 word long answer for a poetry analysis question that includes a clear thesis point, at least two textual evidences with line/stanza references, analytical explanation of how each evidence supports the point, and a concluding link to the poem's central idea or broader context.

## SCOPE_BOUNDARY
This node covers writing analytical answers for poetry-specific questions (theme, imagery, symbolism, irony, central idea, critical appreciation) based on Chapter 16; it does NOT cover creative writing (poem composition), grammar exercises, or prose answer writing from other chapters.

## WALKTHROUGH
Imagine you are in the exam hall facing a 6-mark question: "How does the poet contrast the beauty of nature with the cruelty of feudal society in 'vkvks] feydj cpk,¡'?" A weak answer would merely summarize the poem or list images without analysis. To begin, read the question carefully and underline keywords: "contrast," "beauty of nature," "cruelty of feudal society." Next, recall the two distinct sections of the poem – the inviting, sensuous imagery of the first part and the harsh, ironic depiction of feudal oppression in the second. Then, select two strong pieces of evidence: one from the nature imagery (e.g., the description of the peacock's dance or the fragrance of earth) and one from the feudal cruelty (e.g., the reference to the whip of the landlord or the hanging of the innocent). Apply the PEEL structure for each evidence. Finally, link both paragraphs to the central idea of the poem as a call to awaken consciousness against injustice.

## DIAGNOSTIC_QUESTION_1
What does the acronym PEEL stand for in the context of writing structured answers for literature questions?

## DIAGNOSTIC_ANSWER_1
PEEL stands for Point, Evidence, Explanation, Link. A wrong answer (e.g., "Paragraph, Example, Explain, Conclusion") reveals the student confuses the mnemonic with generic paragraph structure and does not know the specific analytical function of each component: Point makes a claim, Evidence provides textual proof, Explanation analyzes the evidence, Link connects back to the question or central idea.

## DIAGNOSTIC_QUESTION_2
A student writes: "The poem shows nature is beautiful and feudal society is bad. The poet uses many images like peacock, fragrance, whip, hanging." Why is this answer insufficient for a 6-mark board question even though it mentions correct content?

## DIAGNOSTIC_ANSWER_2
The answer lacks analytical depth: it states observations without explaining HOW the images create contrast or WHAT effect they produce. It provides no specific line/stanza references, no analysis of literary devices (metaphor, irony), and no linking to the central idea of awakening consciousness. A wrong answer here reveals the student treats literature as information recall rather than as craft analysis.

## DIAGNOSTIC_QUESTION_3
Apply the PEEL structure to answer this 3-mark question: "Identify and explain the significance of the metaphor 'uxkM+s dh rjg ctrs gSa 'kCn' (words flutter like butterflies) in the poem."

## DIAGNOSTIC_ANSWER_3
Point: The metaphor compares words to butterflies to highlight their fragile, fleeting beauty. Evidence: In the opening stanza, the poet writes "uxkM+s dh rjg ctrs gSa 'kCn". Explanation: Butterflies are delicate, colorful, and short-lived; this suggests the poet's words are aesthetically pleasing but vulnerable in a harsh feudal world that crushes free expression. Link: This metaphor sets up the central tension between artistic sensitivity and societal brutality that drives the poem. A wrong answer would only identify the metaphor without explaining the connotations of "butterfly" or connecting to the poem's theme.

## DIAGNOSTIC_QUESTION_4
Compare the use of sensory imagery in the first section (nature) and the second section (feudal cruelty) of the poem. How does the shift in imagery serve the poet's purpose?

## DIAGNOSTIC_ANSWER_4
The first section uses olfactory (fragrance of earth), visual (peacock dance, colors), and tactile (cool breeze) imagery to create a sensuous, inviting world. The second section shifts to violent, auditory (crack of whip), and grotesque visual (hanging bodies, blood) imagery. This sharp contrast juxtaposes the natural harmony the poet cherishes with the systemic violence of feudalism, making the injustice viscerally felt. The shift serves the purpose of awakening the reader's conscience by shattering the aesthetic comfort. A wrong answer would list images from both sections without analyzing the functional contrast or the emotional trajectory from beauty to horror.

## DIAGNOSTIC_QUESTION_5
Evaluate this student's thesis statement for a critical appreciation essay: "The poem 'vkvks] feydj cpk,¡' is a beautiful description of nature that suddenly turns into a political protest." Is this an effective thesis? Why or why not?

## DIAGNOSTIC_ANSWER_5
The thesis is ineffective because it frames the two sections as disconnected ("suddenly turns") rather than integrally linked. A strong thesis would argue: "The poem uses the seductive beauty of nature as a strategic foil to expose the brutality of feudal society, making the political protest emerge organically from the aesthetic experience." The weak thesis reveals the student sees the poem as two separate parts rather than a unified artistic strategy where form serves theme.

## DIAGNOSTIC_QUESTION_6
Write a 4-sentence paragraph using PEEL that answers: "How does the title 'vkvks] feydj cpk,¡' reflect the poem's central message?" Invent your own evidence from the poem's content.

## DIAGNOSTIC_ANSWER_6
Point: The imperative title "Come, let us sow" functions as a metaphorical call to collective action rather than a literal agricultural invitation. Evidence: The poem moves from "sowing" words like butterfly-seeds in the first section to the urgency of "sowing" resistance in the feudal wasteland of the second. Explanation: The verb "cpk,¡" (let us sow) carries dual agency – the poet invites the reader to participate in cultivating both beauty and justice, implying that aesthetic awakening and social revolution are the same gesture. Link: Thus the title encapsulates the poem's core message that art must be a seed for social transformation. A poor answer would explain the literal meaning of "sowing" without the metaphorical leap to resistance.

## COMMON_MISCONCEPTION
Students believe that writing a good literature answer means paraphrasing the poem/story in their own words and adding a moral lesson at the end. They treat "analysis" as "summary with a message." For this poem, they write: "The poet describes nature beautifully, then shows feudal cruelty, and tells us to fight injustice." This misses the mark because board examiners reward analysis of HOW the poet achieves effects (device, structure, tone, contrast) not WHAT happens. The misconception arises from school-level "summary writing" practice where retelling is rewarded, whereas Class 11 demands critical appreciation.

## ON_FAILURE
If a student produces summary instead of analysis: 1) Give them a 3-mark question and ask them to highlight every sentence that makes a claim (Point) in yellow, every textual reference (Evidence) in green, every analytical sentence (Explanation) in blue, and every linking sentence (Link) in pink. 2) They will see mostly yellow (summary) with little green/blue/pink. 3) Have them rewrite ONLY the blue and pink sentences first, forcing analytical thinking. 4) Then insert green evidence from the text to support each blue sentence. This color-coding makes the missing components visible and teaches the PEEL rhythm.

## BUILDS_ON
Critical thinking analysis of the poem's themes and devices (nodes 012, 013) provides the raw analytical material that writing skills structure into exam answers.

## LEADS_TO
Speaking and listening discussion (node 015) where students must articulate the same analytical points orally, and board exam answer writing for all poetry chapters.

## PREREQUISITE_NODE_IDS
c11_hin_ar_cbse_16_012, c11_hin_ar_cbse_16_013, c11_hin_ar_cbse_16_008, c11_hin_ar_cbse_16_009, c11_hin_ar_cbse_16_007

## PREREQUISITE_REASONS
c11_hin_ar_cbse_16_012: Literal and inferential comprehension provides the textual facts and inferences needed as Evidence in PEEL.
c11_hin_ar_cbse_16_013: Critical thinking analysis supplies the interpretive insights (themes, irony, symbolism) that become the Point and Explanation in answers.
c11_hin_ar_cbse_16_008: Knowledge of imagery and metaphor enables identification of specific devices to discuss as Evidence.
c11_hin_ar_cbse_16_009: Understanding of irony and symbolism allows analysis of how the poet's techniques create meaning (Explanation step).
c11_hin_ar_cbse_16_007: Writing tasks often ask for thematic analysis essays.  

## FORWARD_NODE_IDS
c11_hin_ar_cbse_16_015, c12_hin_a_cbse_05_014

## FORWARD_REASONS
c11_hin_ar_cbse_16_015: Speaking and listening requires students to orally present the same structured arguments (Point, Evidence, Explanation) they practice in writing, adapting PEEL for discussion format.
c12_hin_a_cbse_05_014: अगला तार्किक चरण: Writing Skills based on the chapter refers to the ability to compose structured, evidence-based resp... इस नोड की अवधारणाओं को सीधे उपयोग/विस्तारित करता है।  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
none

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_16_012 -> c11_hin_ar_cbse_16_014 -> c11_hin_ar_cbse_16_015 : Comprehension provides textual evidence, writing skills structure it into PEEL answers, speaking/listening adapts the structure for oral presentation.

## THIS_FORMULA
PEEL = Point (claim) + Evidence (textual quote/reference) + Explanation (analysis of device/effect) + Link (connection to question/central idea)

## FORMULA_VARIABLES
Point: A clear, arguable claim that directly answers the question. Evidence: Specific line/stanza reference or paraphrased textual detail. Explanation: Analysis of how the evidence supports the point, naming literary devices and their effects. Link: Sentence connecting the paragraph back to the question's key terms or the poem's central idea.

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
linguistic

## CROSS_SUBJECT
c11_history_feudalism | The poem's depiction of feudal cruelty (landlord's whip, hanging of innocents) connects to History Chapter on "Feudal Society in Medieval India" where students analyze similar power structures and peasant resistance.
c11_sociology_social_change | The poem's call for awakening consciousness ("vkvks] feydj cpk,¡") mirrors Sociology concepts of "social movements" and "collective action" where cultural symbols mobilize change.

## PREREQ_CONCEPT
Student must understand that poetry analysis answers require arguing an interpretation with textual proof, not retelling the poem.

## PREREQ_BEFORE
Student must have completed nodes 008, 009, 012, 013 to have the analytical content (devices, themes, inferences) ready to structure.

## PREREQ_STUCK
If stuck, review the "Literary Devices: Imagery and Metaphor" (008) and "Critical Thinking: Analysis and Interpretation" (013) nodes to refresh the analytical observations needed for Evidence and Explanation steps.

## WORKED_EXAMPLE_1
PROBLEM: Improve this weak 6-mark answer: "The poet shows nature is very beautiful in the first part. He describes peacock, fragrance, colors. In the second part he shows feudal society is cruel. There is whip, hanging, blood. The poem tells us to wake up and fight. The title says come let us sow."
STEPS:
- Step 1: Identify the question implied: "How does the poet contrast nature's beauty with feudal cruelty to convey a message of resistance?"
- Step 2: Note the weak answer has only summary (yellow) – no device analysis, no specific references, no PEEL structure.
- Step 3: Extract two strong Points from the content: (1) Sensuous imagery creates an idealized natural world. (2) Violent imagery exposes feudal brutality. (3) The contrast serves as a call to action.
- Step 4: For each Point, find Evidence from the poem: e.g., "BaMh gksrh fnup;kZ esa thou dh xekZgV" (nature) and "FkksM+k&lk fo'okl / FkksM+h&lh mEehn" (feudal cruelty).
- Step 5: Write Explanation for each: analyze how olfactory/visual imagery in first section creates immersion, how metallic/violent imagery in second creates shock, how the juxtaposition produces irony.
- Step 6: Write Link sentences connecting each paragraph to the central idea of "awakening consciousness through aesthetic shock."
REASONING: The PEEL structure forces the writer to move from observation to analysis. By requiring Evidence and Explanation for each Point, it ensures the answer demonstrates HOW the poet achieves effects, not just WHAT is described. The Link step ensures the answer stays focused on the question's demand.
ANSWER: Improved answer (structured in three PEEL paragraphs):
Paragraph 1 (Nature's beauty): Point: The poet constructs a sensuous, immersive natural world through dense sensory imagery. Evidence: The opening stanza employs olfactory ("eu dk gjkiu"), visual ("Hkksykiu fny dk vD[kM+iu"), and tactile ("tq>k:iu") images. Explanation: This synesthetic layering invites the reader into a harmonious ecosystem where "fe^h dk lksaèkkiu" (lightning's playfulness) suggests nature's innocent vitality, establishing a benchmark of beauty. Link: This aesthetic baseline makes the subsequent violation by feudalism more jarring.
Paragraph 2 (Feudal cruelty): Point: The second section shatters this harmony with grotesque, metallic imagery of systemic violence. Evidence: The poem shifts to "Hkhrj dh vkx" (whip's lash), "oqQYgkM+h dh èkkj" (oppression's scream), and the chilling catalog "FkksM+k&lk fo'okl / FkksM+h&lh mEehn / FkksM+s&ls lius" (big farms, big harvests, big profits). Explanation: The repetition of "FkksM+" (big) with ironic modifiers exposes how feudal prosperity is built on "rhj dk uqdhykiu" (uprooting of life), turning agricultural metaphors into indictments. Link: The contrast between "sowing" in nature and "reaping blood" in feudalism creates the poem's central irony.
Paragraph 3 (Call to action): Point: The title's imperative "vkvks] feydj cpk,¡" transforms the reader from spectator to participant in resistance. Evidence: The verb "cpk,¡" (let us sow) recurs metaphorically in "cfLr;ksa dks 'kgj dh vkcks&gok ls cpk,¡" (sow consciousness from the heart's depth). Explanation: This agricultural metaphor reframes poetic utterance as revolutionary praxis – words become seeds of awareness in the "nkSj" (time/field) of history. Link: Thus the poem enacts its own message: the aesthetic experience IS the political awakening.

## WORKED_EXAMPLE_2
PROBLEM: Write a 3-mark answer for: "Explain the significance of the line 'izÑfr osQ fouk'k vkSj foLFkkiu osQ dkj.k vkt vkfnoklh lekt ladV esa gS' (Nature's generosity and establishment's cruelty are why feudal society is burning today)."
STEPS:
- Step 1: Identify the question asks for explanation of a specific critical comment (from the poet's note) linking nature, establishment, and feudal crisis.
- Step 2: Formulate Point: The line encapsulates the poem's dialectic – nature's abundance is perverted by feudal exploitation, creating inevitable rebellion.
- Step 3: Select Evidence: From poem – nature's generosity: "vkvks] feydj cpk,¡" (invitation to sow/share), "eu dk gjkiu" (heart's music); establishment's cruelty: "FkksM+k&lk fo'okl" (big farms of the powerful), "rhj dk uqdhykiu" (uprooting of life).
- Step 4: Write Explanation: "fouk'k" (generosity) refers to nature's free gifts (fragrance, color, breeze) which the feudal "foLFkkiu" (establishment) monopolizes through "FkksM+k&lk fo'okl" (large landholdings). The "ladV" (burning) is the peasant uprising sparked by this theft – seen in the poem's urgent tone "vc Hkh gekjs ikl !" (still with us!).
- Step 5: Write Link: This interpretation shows the poem is not merely descriptive but diagnoses the historical contradiction driving feudalism's crisis.
REASONING: This question tests the ability to integrate the poet's own critical note (paratext) with textual evidence. The PEEL structure ensures the answer explains the comment rather than just agreeing with it.
ANSWER: The line diagnoses feudalism's crisis as a conflict between nature's innate generosity and the establishment's monopolistic cruelty. Nature offers "eu dk gjkiu" (heart's music) and open invitation "vkvks] feydj cpk,¡" to share its abundance freely. However, the feudal "foLFkkiu" (establishment) converts this commons into "FkksM+k&lk fo'okl" (big farms) for "FkksM+s&ls lius" (big profits), enacting "rhj dk uqdhykiu" (uprooting of life). This theft of nature's "fouk'k" (generosity) by the powerful makes the "ladV" (burning/unrest) inevitable – the poem's closing urgency "vc Hkh gekjs ikl !" signals that the historical contradiction remains unresolved. The poem thus functions as both diagnosis and call to reclaim nature's generosity for humanity.

## WORKED_EXAMPLE_3
PROBLEM: A 6-mark question asks: "The poem uses irony as a major device. Analyze with examples." Write a full answer using PEEL for two distinct ironic instances.
STEPS:
- Step 1: Recall from node 009 the two main ironies: (1) Agricultural metaphors used for exploitation ("FkksM+k&lk fo'okl" – big farms should mean prosperity but mean oppression). (2) The title's "sowing" – the establishment sows cruelty but reaps rebellion.
- Step 2: Structure two main body paragraphs, each a full PEEL on one irony.
- Step 3: Paragraph 1 (Agricultural irony): Point: The poem subverts agricultural vocabulary to expose feudal perversion of nature's cycles. Evidence: "FkksM+k&lk fo'okl / FkksM+h&lh mEehn / FkksM+s&ls lius" – the repetition of "FkksM+" (big/great) with "fo'okl" (farms), "mEehn" (harvest), "lius" (profit). Explanation: In a natural cycle, big farms yield big harvests for the community; here the "mEehn" (harvest) is "vk'kk" (sorrow) and "lius" (profit) is for the landlord alone. The irony lies in using growth metaphors for systemic depletion – "rhj dk uqdhykiu" (uprooting of life) replaces cultivation. Link: This linguistic irony mirrors the material irony of a system that starves the producers.
- Step 4: Paragraph 2 (Title/Action irony): Point: The imperative title "vkvks] feydj cpk,¡" (Come, let us sow) carries dramatic irony – the poet invites sowing of consciousness, but the feudal lords have already sown the seeds of their own destruction. Evidence: The closing lines "vc Hkh gekjs ikl !" (still with us!) and the catalog of feudal atrocities "Hkhrj dh vkx / oqQYgkM+h dh èkkj". Explanation: The establishment "sows" whip-lashes and screams ("cpk,¡" in the sense of inflicting), but the harvest is "ladV" (burning rebellion). The poet's "cpk,¡" (let us sow words/consciousness) is the counter-sowing that will outlast the feudal crop. Link: The double meaning of "sowing" – as agricultural act, as poetic creation, as revolutionary praxis – makes the title the poem's controlling irony.
- Step 5: Add introductory thesis and concluding synthesis paragraph.
- Step 6: Verify each paragraph has all four PEEL components and uses terminology from node 009 (situational irony, verbal irony).
REASONING: This worked example demonstrates how to handle a device-specific question that requires multiple instances. The two-paragraph PEEL structure ensures each irony is fully analyzed with its own evidence and explanation, while the thesis and conclusion provide cohesion. This mirrors the board expectation for "analyze with examples" questions.
ANSWER: The poem employs sustained irony to expose the gap between feudalism's claims and its reality. First, agricultural vocabulary is inverted: "FkksM+k&lk fo'okl / FkksM+h&lh mEehn / FkksM+s&ls lius" uses the language of abundance ("FkksM+" = big/great) to describe a system where "mEehn" (harvest) means "vk'kk" (sorrow) for the peasant and "lius" (profit) means exploitation for the landlord. The natural cycle of sowing-reaping is perverted into "rhj dk uqdhykiu" (uprooting of life) – a verbal irony where growth metaphors describe systemic depletion. Second, the title "vkvks] feydj cpk,¡" (Come, let us sow) operates as dramatic irony: the feudal establishment has long been "sowing" "Hkhrj dh vkx" (whip's lash) and "oqQYgkM+h dh èkkj" (oppression's scream), but their harvest is "ladV" (burning unrest). The poet's counter-invitation to "sow" consciousness ("cfLr;ksa dks 'kgj dh vkcks&gok ls cpk,¡") reframes poetic utterance as the true cultivation that will survive the feudal blaze. Thus irony functions not as mere contrast but as structural revelation of a society sowing its own demise.

## COMPETENCY_QUESTION_1
QUESTION: A student writes this answer for a 4-mark question "How does the poet use contrast in the poem?": "The poem has two parts. First part is about nature: peacock, fragrance, colors. Second part is about feudalism: whip, hanging, blood. This contrast shows nature is good and feudalism is bad. The poet wants us to choose nature." Identify THREE specific weaknesses in this answer relative to board exam criteria, and rewrite ONE paragraph using PEEL to model the expected standard.
COMPETENCY: Critical evaluation of answer quality and application of PEEL structure
STEPS:
- Step 1: Identify weaknesses: (1) No literary terminology (imagery, irony, tone). (2) No specific textual references (line/stanza). (3) No analysis of HOW contrast works (juxtaposition, shift in register, structural placement). (4) Oversimplified moral ("choose nature") instead of thematic interpretation.
- Step 2: Select one contrast aspect to model: the shift from sensuous to violent imagery.
- Step 3: Write Point: The poet structures the poem as a violent rupture of sensuous immersion to enact the violation of nature by feudalism.
- Step 4: Write Evidence: First section's "BaMh gksrh fnup;kZ esa / thou dh xekZgV / eu dk gjkiu" vs second section's "Hkhrj dh vkx / èkuq"k dh Mksjh / rhj dk uqdhykiu".
- Step 5: Write Explanation: The initial stanza uses soft consonants, liquid vowels, and synesthetic blending to create a hypnotic aesthetic trance; the second section introduces plosives, harsh consonants, and monosyllabic brutality that phonetically enact the whip's crack.
- Step 6: Write Link: This sonic contrast makes the reader physically experience the intrusion of feudal violence into natural harmony, fulfilling the poem's aim of "cpkus" (awakening) through aesthetic shock.
ANSWER: Three weaknesses: (1) Lacks literary vocabulary – uses "parts" instead of "sections/stanzas," "shows" instead of "juxtaposes/contrasts through imagery/tonal shift." (2) Provides no specific textual evidence – "peacock, fragrance" are generalizations without line references or quoted phrases. (3) Offers no analysis of technique – does not explain HOW the contrast is constructed (imagery shift, sound patterns, structural placement) or WHAT effect it produces (irony, shock, awakening). Modeled PEEL paragraph: The poem's central contrast is engineered through a deliberate rupture of sensory register. The opening stanza immerses the reader in a synesthetic natural world – "BaMh gksrh fnup;kZ esa / thou dh xekZgV / eu dk gjkiu" – where liquid vowels (eu, gjkiu, xekZgV) and soft consonants create a hypnotic aesthetic trance. This sensuous baseline is violently shattered by the second section's plosive brutality: "Hkhrj dh vkx / èkuq"k dh Mksjh / rhj dk uqdhykiu" – the harsh aspirates (Hkhrj, vkx, èkuq"k) and staccato rhythm phonetically enact the whip's crack and the body's rupture. This sonic violence does not merely describe feudal cruelty; it makes the reader viscerally feel the intrusion of systemic oppression into natural harmony. Thus the structural contrast performs the poem's awakening function: the aesthetic shock compels the consciousness to "vkvks] feydj cpk,¡" – to sow resistance in the very field where beauty was violated.
DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: "The poem 'vkvks] feydj cpk,¡' is not just a critique of feudalism but a manifesto for the role of poetry in social change." Write a 150-word critical appreciation that analyzes how the poem's FORM (structure, imagery, tone, address) embodies this manifesto. Use at least three PEEL-structured paragraphs.
COMPETENCY: Synthesis of form and theme in sustained analytical writing
STEPS:
- Step 1: Formulate thesis: The poem's tripartite structure (invitation, violation, counter-invitation) enacts the poet's theory of revolutionary aesthetics.
- Step 2: Paragraph 1 (Structure as manifesto): Point: The three-section structure mirrors the dialectic of revolutionary consciousness – aesthetic seduction, political revelation, activist commitment. Evidence: Section 1 (stanzas 1-3) uses hortatory "vkvks" (come) + sensuous imagery; Section 2 (stanzas 4-6) shifts to declarative catalog of atrocities; Section 3 (stanza 7) returns to imperative "vc Hkh gekjs ikl" (still with us). Explanation: This movement from "come see" to "see this horror" to "still here, act now" mimics the pedagogic arc of conscientization (Freire) – the poem performs the awakening it preaches. Link: Form thus becomes praxis: the reader's journey through the poem IS the awakening.
- Step 3: Paragraph 2 (Imagery as manifesto): Point: The central metaphor of "sowing" (cpk,¡) transforms poetry from ornament to agricultural intervention. Evidence: "uxkM+s dh rjg ctrs gSa 'kCn" (words flutter like butterflies) → "cfLr;ksa dks 'kgj dh vkcks&gok ls cpk,¡" (sow consciousness from heart's depth). Explanation: The butterfly metaphor acknowledges poetry's fragility; the redefinition of "cpk,¡" as sowing consciousness in the "nkSj" (time/field) of history claims durability for the word-seed. The irony: feudalism sows "vkx" (lashes) but the poet's "cpk,¡" yields "ladV" (burning change). Link: Imagery enacts the manifesto's claim: poetry is not reflection but cultivation.
- Step 4: Paragraph 3 (Address as manifesto): Point: The direct second-person address "vkvks" (come) and inclusive "gekjs" (our) positions the reader as co-agent, not spectator. Evidence: Opening "vkvks] feydj cpk,¡ viuh cfLr;ksa dks" and closing "vc Hkh gekjs ikl !". Explanation: The shift from imperative invitation to collective possession ("gekjs ikl" – still with us) collapses the distance between poet and reader, making the poem a site of collective subjectivity formation. Link: This rhetorical strategy fulfills the manifesto's demand: poetry creates the "we" that can act.
- Step 5: Concluding synthesis: The poem's form – its structural dialectic, metaphorical coherence, and rhetorical address – does not merely describe the manifesto; it IS the manifesto in action.
ANSWER: The poem's tripartite structure enacts its revolutionary manifesto. Section 1's hortatory "vkvks" (come) and synesthetic immersion ("BaMh gksrh fnup;kZ esa / thou dh xekZgV") seduce the reader into aesthetic complicity. Section 2's declarative catalog ("Hkhrj dh vkx / oqQYgkM+h dh èkkj") shatters this complicity with visceral horror. Section 3's return to imperative ("vc Hkh gekjs ikl !") converts shock into collective resolve. This dialectic – seduction, violation, mobilization – mirrors Freirean conscientization: the poem performs the awakening it preaches. The central metaphor of "cpk,¡" (sowing) transforms poetry from ornament to intervention. "uxkM+s dh rjg ctrs gSa 'kCn" admits the word's fragility, but "cfLr;ksa dks 'kgj dh vkcks&gok ls cpk,¡" redefines sowing as planting consciousness in history's field ("nkSj"). The irony is precise: feudalism sows "vkx" (lashes) and reaps "ladV" (burning); the poet's counter-sowing yields enduring resistance. Finally, the shifting address – from "vkvks" (you come) to "gekjs ikl" (still with us) – collapses poet-reader distance, forging the collective subjectivity essential for change. The poem's form does not merely illustrate its manifesto; the structural dialectic, metaphorical coherence, and rhetorical address collectively constitute the manifesto in action.
DIFFICULTY: hard