## DEFINITION
Character analysis of supporting characters involves examining the traits, motivations, dialogues, and actions of characters other than the protagonist to understand their function in advancing the plot, developing themes, and revealing the protagonist's personality through contrast or parallel. In "जतुथ", supporting characters like यथ्यक (wife), वफर (son), गणेशकुमार (colleague), and पितृ (father) serve as mirrors to the societal pressures and educational conflicts central to the narrative.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student can identify at least three supporting characters, cite specific dialogues/actions as evidence for their traits, explain how each character influences the protagonist's decisions, and articulate their collective role in highlighting the story's critique of the education system.

## SCOPE_BOUNDARY
This node covers only the supporting characters in the short story "जतुथ" (Chapter 6 of Aroh). It does not cover the protagonist's analysis (done in node 004), thematic analysis (nodes 006, 007), or literary devices (nodes 008, 009). It focuses on character portrayal through dialogue, stage directions, and relationships.

## WALKTHROUGH
Imagine you are a director casting a play: the lead actor is important, but the supporting actors make the story believable. In "जतुथ", जतुथ's wife यथ्यक, his son वफर, and colleague गणेशकुमार are not just background—they voice the very societal pressures that trap जतुथ. Begin by listing every character who speaks or is described. Then, for each, ask: What do they want? What do they fear? How does their interaction with जतुथ change him? Finally, connect their individual struggles to the larger theme of "education as a burden vs. liberation". The key insight: supporting characters in this story are not subplots; they are the living evidence of the system जतुथ fights.

## DIAGNOSTIC_QUESTION_1
Name the four main supporting characters in "जतुथ" and state one defining trait for each based on the text.

## DIAGNOSTIC_ANSWER_1
The four main supporting characters are: यथ्यक (जतुथ's wife) – pragmatic and anxious about financial survival; वफर (their son) – sensitive and crushed by academic pressure; गणेशकुमार (colleague) – cynical and resigned to systemic corruption; पितृ (जतुथ's father) – traditional and obsessed with status through marks. A wrong answer (e.g., listing only two characters or giving generic traits like "kind") shows the student has not tracked character-specific dialogues and stage directions.

## DIAGNOSTIC_QUESTION_2
Explain in your own words how यथ्यक's dialogue in the kitchen scene (where she discusses tuition fees and वफर's marks) reveals the economic pressure on the family, without summarizing the plot.

## DIAGNOSTIC_ANSWER_2
यथ्यक's repeated references to "फीस", "ट्यूशन", and "नंबर" show she views education as a transactional necessity for survival, not intellectual growth. Her tone shifts from pleading to sarcastic ("वाह! वाह!") exposing how financial insecurity forces her to prioritize marks over learning. A wrong answer that merely retells the scene ("she asks for money") misses the analytical step of linking her words to the story's socioeconomic critique.

## DIAGNOSTIC_QUESTION_3
Apply the concept of "foil" to analyze how वफर's breakdown during the result scene contrasts with जतुथ's outward composure. What does this contrast reveal about जतुथ's internal conflict?

## DIAGNOSTIC_ANSWER_3
वफर's visible collapse (crying, refusing food) acts as a foil to जतुथ's controlled exterior (he continues marking papers). This contrast reveals जतुथ's suppressed guilt and helplessness—he cannot protect his son from the system he serves. The student must identify the foil structure, cite वफर's actions (e.g., "रोते-रोते खाना नहीं खाया") and जतुथ's actions (e.g., "कॉपियाँ जाँचते रहे"), and infer the internal conflict. A wrong answer that only describes both characters separately fails to establish the analytical relationship.

## DIAGNOSTIC_QUESTION_4
Analyze how गणेशकुमार's cynicism ("नकल कराके पास करा दो") functions as a thematic device to expose the moral decay of the education system. Support with two specific utterances.

## DIAGNOSTIC_ANSWER_4
गणेशकुमार normalizes corruption through casual suggestions: "नकल कराके पास करा दो" and "सब चलता है". His pragmatism contrasts with जतुथ's idealism, making the system's rot tangible. The analysis must connect his dialogues to the theme of institutional compromise, not just label him "corrupt". A wrong answer that calls him a "villain" oversimplifies—he represents systemic complicity, not individual malice.

## DIAGNOSTIC_QUESTION_5
Evaluate the statement: "पितृ's obsession with वफर's marks is the primary cause of जतुथ's ethical dilemma." Defend or refute using textual evidence.

## DIAGNOSTIC_ANSWER_5
Refute. पितृ's pressure ("नंबर नहीं आए तो मुँह मत दिखाना") is a catalyst, but जतुथ's dilemma stems from the confluence of यथ्यक's financial anxiety, वफर's fragility, गणेशकुमार's normalization of cheating, and his own conscience. The text shows जतुथ weighing all voices (e.g., he listens to each before deciding). A wrong answer that agrees ignores the multi-voiced pressure the playwright constructs.

## DIAGNOSTIC_QUESTION_6
Create a 50-word monologue for यथ्यक that she might deliver after जतुथ refuses to help वफर cheat, capturing her fear, love, and resentment. Use the story's linguistic register.

## DIAGNOSTIC_ANSWER_6
A strong monologue blends colloquial Hindi with emotional specificity: "तुम्हारे सिद्धांतों का क्या करूँ? वफर रो-रोकर सोया है, फीस के नोटिस आ रहे हैं, और तुम कहते हो 'ईमानदारी'? तुम्हारी ईमानदारी हमारे पेट नहीं भरेगी।" Criteria: uses यथ्यक's voice (direct address, concrete worries), reflects her dual role as caregiver and realist. A poor answer writes generic complaints without the story's specific pressures.

## COMMON_MISCONCEPTION
Students treat supporting characters as "minor" and only list their traits (e.g., "यथ्यक is caring") without analyzing their structural function. In senior secondary exams, a character sketch that does not link the character to the protagonist's conflict or the story's theme receives partial marks. For example, describing वफर as "sensitive" without connecting his sensitivity to the critique of rote-learning misses the analytical demand.

## ON_FAILURE
1. Have the student re-read only the dialogues of one supporting character (e.g., यथ्यक) and highlight every word related to money, marks, or fear. 2. Ask: "If this character were removed, what would जतुथ lose?" 3. Guide them to write one paragraph connecting that character's pressure to जतुथ's final decision. 4. Repeat for two more characters, then compare their pressures in a table.

## BUILDS_ON
Protagonist analysis (node 004) where students learned to extract traits from जतुथ's actions and soliloquies; now they apply the same method to secondary figures.

## LEADS_TO
Theme analysis (node 006) where the collective pressures from supporting characters crystallize into the primary theme: "Education as a tool of social stratification vs. human development."

## PREREQUISITE_NODE_IDS
c11_hin_ar_cbse_06_001, c11_hin_ar_cbse_06_002, c11_hin_ar_cbse_06_003, c11_hin_ar_cbse_06_004
## PREREQUISITE_REASONS
c11_hin_ar_cbse_06_001: Context/background knowledge of the author and era is needed to understand the societal pressures shaping supporting characters.
c11_hin_ar_cbse_06_002: Plot structure knowledge helps locate where each supporting character enters and exits the narrative.
c11_hin_ar_cbse_06_003: Setting/atmosphere (the cramped house, the staff room) explains the physical constraints influencing character interactions.
c11_hin_ar_cbse_06_004: Protagonist analysis provides the baseline; supporting characters are defined in relation to जतुथ's journey.

## FORWARD_NODE_IDS
c11_hin_ar_cbse_06_006, c11_hin_ar_cbse_06_007, c11_hin_ar_cbse_06_013, c11_hin_ar_cbse_06_014, c11_hin_ar_cbse_06_008, c11_hin_ar_cbse_06_011, c11_hin_ar_cbse_06_012, c12_hin_ar_cbse_06_005

## FORWARD_REASONS
c11_hin_ar_cbse_06_006: Primary theme emerges from the chorus of supporting characters' voices.
c11_hin_ar_cbse_06_007: Secondary themes (parental pressure, corruption, gender roles) are carried by specific supporting characters.
c11_hin_ar_cbse_06_013: Critical thinking requires evaluating character motivations as evidence for interpretations.
c11_hin_ar_cbse_06_014: Writing skills (character sketch, analytical paragraph) directly apply this analysis.
c11_hin_ar_cbse_06_008: Supporting characters' contrasting worlds are built through imagery.  
c11_hin_ar_cbse_06_011: Supporting character analysis supplies social roles (director, mother, student) that determine language choices.  
c11_hin_ar_cbse_06_012: Supporting character dynamics (Headmaster, Vipin, Yashoda) are key to inferential questions  
c12_hin_ar_cbse_06_005: Class 11 foundation on supporting character analysis in Aroh.  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
none

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_06_004 -> c11_hin_ar_cbse_06_005 -> c11_hin_ar_cbse_06_006

## THIS_FORMULA
N/A - conceptual

## FORMULA_VARIABLES
N/A

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
analytical

## CROSS_SUBJECT
c11_sociology_family_dynamics | The family interactions in "जतुथ" (पितृ's expectations, यथ्यक's economic anxiety, वफर's stress) mirror sociological concepts of family as a site of status reproduction and intergenerational pressure.
c11_economics_human_capital | The story treats education as human capital investment; supporting characters embody the cost-benefit calculations (tuition fees, expected returns via marks) that drive household decisions in development economics.

## PREREQ_CONCEPT
Ability to distinguish between direct characterization (author's description) and indirect characterization (dialogue, action, reaction of others) as taught in protagonist analysis.

## PREREQ_BEFORE
Student must have read the full text of "जतुथ" and marked every speaking character's name in the margin.

## PREREQ_STUCK
Review the "Character List and Key Dialogues" table created during protagonist analysis (node 004) and add rows for यथ्यक, वफर, गणेशकुमार, पितृ.

## WORKED_EXAMPLE_1
PROBLEM: Write a structured character analysis of यथ्यक (जतुथ's wife) using the PEEL method (Point, Evidence, Explanation, Link) showing how she embodies the economic anxiety of lower-middle-class families.

STEPS:
- Step 1: Identify the point – यथ्यक represents the pragmatic survival instinct that clashes with जतुथ's idealism.
- Step 2: Locate evidence – Her dialogues in the kitchen scene: "फीस भरनी है", "ट्यूशन का पैसा कहाँ से आएगा?", and her sarcastic "वाह! वाह!" when जतुथ quotes principles.
- Step 3: Analyze evidence – The repetition of financial terms shows her reality is material, not moral; the sarcasm reveals resentment at bearing the burden alone.
- Step 4: Explain function – She forces जतुथ (and the audience) to confront the material cost of honesty, making his dilemma concrete.
- Step 5: Link to theme – Her character grounds the abstract theme "education vs. livelihood" in daily survival, showing why the system traps even well-meaning people.
- Step 6: Conclude – यथ्यक is not merely a "nagging wife"; she is the voice of structural compulsion.

REASONING: The PEEL structure ensures each claim is textually grounded and thematically connected, meeting board exam expectations for analytical writing.

ANSWER: यथ्यक embodies the economic anxiety that makes ethical choices a luxury. In the kitchen scene, her litany — "फीस भरनी है, ट्यूशन का पैसा कहाँ से आएगा?" — reduces education to a series of payments. Her sarcastic "वाह! वाह!" at जतुथ's principles exposes the gap between idealism and survival. This contrast sharpens जतुथ's conflict: his conscience vs. his family's needs. Thus, यथ्यक personifies the systemic pressure that turns education into a transaction, reinforcing the story's critique of a society where marks determine survival.

## WORKED_EXAMPLE_2
PROBLEM: Analyze how वफर's silence and physical reactions (stage directions) in the result scene function as a more powerful indictment of the education system than any dialogue could.

STEPS:
- Step 1: Note the stage directions – "वफर रोते-रोते खाना नहीं खाया", "चुपचाप कॉपी लेकर बैठ गया", "आँखें लाल" – these are non-verbal characterization.
- Step 2: Compare with his earlier dialogue – Earlier he pleads "पापा, कुछ करो ना"; now silence replaces speech, showing total defeat.
- Step 3: Interpret the shift – Silence signifies internalized trauma; the child who asked for help now accepts helplessness.
- Step 4: Connect to जतुथ – जतुथ watches but cannot act; the son's body becomes the site where the father's failure is inscribed.
- Step 5: Relate to system critique – The system breaks the child's spirit before he enters adulthood; वफर's broken body is the system's receipt.
- Step 6: Synthesize – The playwright uses stage directions to show what dialogues cannot: the visceral, pre-verbal impact of institutional violence on the innocent.

REASONING: Senior secondary analysis requires reading stage directions as textual evidence equal to dialogue, especially in a play-script story.

ANSWER: वफर's silence is the loudest condemnation. Stage directions — "रोते-रोते खाना नहीं खाया", "चुपचाप कॉपी लेकर बैठ गया" — trace his journey from pleading ("पापा, कुछ करो ना") to numb acceptance. This physical collapse mirrors the system's success: it produces not scholars but shattered children. जतुथ's helpless witnessing makes the tragedy intergenerational. The playwright thus uses the son's body as evidence that the examination system consumes childhood itself.

## WORKED_EXAMPLE_3
PROBLEM: Compare गणेशकुमार and पितृ as two faces of systemic complicity: one institutional (teacher), one familial (grandfather). How do their differing motivations converge to trap जतुथ?

STEPS:
- Step 1: Characterize गणेशकुमार – Colleague, cynic, suggests "नकल कराके पास करा दो"; motivation: self-preservation, ease.
- Step 2: Characterize पितृ – Grandfather, traditionalist, demands "नंबर नहीं आए तो मुँह मत दिखाना"; motivation: social status, family honor.
- Step 3: Identify convergence – Both reduce education to a certificate: गणेशकुमार via corruption, पितृ via marks. Both dismiss learning.
- Step 4: Show how they trap जतुथ – गणेशकुमार offers the "easy way"; पितृ threatens shame. जतुथ is squeezed between professional compromise and familial disgrace.
- Step 5: Analyze dramatic function – They represent the two pillars of the system: institutional corruption and social validation of that corruption.
- Step 6: Evaluate author's intent – By making both "ordinary" (not villains), the playwright shows complicity is normalized, not exceptional.

REASONING: This comparison requires synthesizing characterization across two spheres (workplace and home) to reveal the systemic web — a classic board exam "compare and contrast" task.

ANSWER: गणेशकुमार and पितृ are mirror images of complicity. The teacher normalizes corruption ("सब चलता है, नकल करा दो"); the grandfather sanctifies the outcome ("नंबर लाओ, मुँह दिखाने लायक रहो"). One sells the means, the other buys the end. Together, they leave जतुथ no ethical space: if he cheats, he betrays his conscience; if he doesn't, he fails his son and father. Their ordinariness — no malice, just "pragmatism" and "tradition" — proves the system survives because ordinary people uphold it.

## COMPETENCY_QUESTION_1
QUESTION: "In 'जतुथ', the supporting characters are not individuals but personifications of social forces." Evaluate this statement with reference to any three supporting characters, using the PEEL structure for each.

COMPETENCY: Critical analysis and structured argumentation (combining character analysis, thematic interpretation, and evidence-based writing).

STEPS:
- Step 1: Choose three supporting characters (e.g., यथ्यक, गणेशकुमार, पितृ).
- Step 2: For each, write a PEEL paragraph: Point (which social force they embody), Evidence (specific line/action), Explanation (how the evidence proves the point), Link (connection to the story's central conflict).
- Step 3: Synthesize in a concluding sentence: the playwright uses typification to show systemic entrapment.
- Step 4: Ensure each paragraph uses textual detail, not generalization.

ANSWER: यथ्यक embodies economic compulsion: her refrain "फीस कहाँ से आएगी?" (Evidence) turns abstract poverty into daily arithmetic (Explanation), forcing जतुथ to choose between principle and survival (Link). गणेशकुमार embodies institutional cynicism: "नकल करा दो, सब चलता है" (Evidence) reveals corruption as routine, not aberration (Explanation), making जतुथ's resistance seem futile (Link). पितृ embodies status anxiety: "नंबर नहीं तो मुँह मत दिखाना" (Evidence) ties family honor to a marksheet (Explanation), adding moral weight to जतुथ's dilemma (Link). Together, they are not "characters" but the three jaws of the trap: poverty, corruption, prestige.

DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: The playwright uses stage directions for वफर more than dialogues. Analyze how this technical choice shapes the audience's perception of the education system's impact on children. Support with at least four specific stage directions from the text.

COMPETENCY: Close reading of dramatic techniques and their thematic function (combining literary device analysis, character analysis, and thematic interpretation).

STEPS:
- Step 1: List four stage directions for वफर (e.g., "रोते-रोते खाना नहीं खाया", "चुपचाप कॉपी लेकर बैठ गया", "आँखें लाल", "सहमा हुआ कोने में").
- Step 2: For each, explain what it communicates that dialogue cannot (pre-verbal trauma, helplessness, internalization).
- Step 3: Argue why the playwright silences the child — to show the system steals voice before it steals future.
- Step 4: Connect to the larger theme: the child's body becomes the text on which the system writes its verdict.
- Step 5: Conclude with the effect on audience: visceral empathy vs. intellectual debate.

ANSWER: The playwright denies वफर speech to make his suffering undeniable. "रोते-रोते खाना नहीं खाया" shows hunger struck by grief; "चुपचाप कॉपी लेकर बैठ गया" turns the answer-sheet into a tombstone; "आँखें लाल" maps sleepless nights onto a child's face; "सहमा हुआ कोने में" spatializes his marginalization. These directions bypass rhetoric — we see the system's victim, not hear its critique. The silence is the system's success: a child who cannot articulate his pain. This technique forces the audience from judgment to witness, making the theme visceral.

DIFFICULTY: hard