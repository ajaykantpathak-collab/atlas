## DEFINITION
Literal comprehension questions require students to locate and restate information explicitly stated in the text, while inferential comprehension questions demand students to derive meaning by combining textual evidence with logical reasoning, context clues, and prior knowledge to reach conclusions not directly written.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student can independently distinguish between literal and inferential questions, locate exact textual evidence for literal answers, and construct inferential answers using a 3-step chain: (1) quote relevant lines, (2) explain the implied meaning, (3) justify the inference with textual support and contextual logic.

## SCOPE_BOUNDARY
This node covers strategies for answering literal and inferential comprehension questions based on the two poems in Chapter 5 ("ओलर वक" and "रक्सक्स"). It does NOT cover critical analysis, literary device identification, or creative writing — those are addressed in sibling nodes c12_hin_a_cbse_05_013 and c12_hin_a_cbse_05_014.

## WALKTHROUGH
Imagine you're sitting in the CBSE board exam and see Question 3: "कवि ने 'ओलर वक' में प्रकृति के किस रूप का चित्रण किया है?" — your heart races because the answer isn't written word-for-word in the poem. This is where most students lose marks: they either copy lines randomly (literal approach for an inferential question) or write vague feelings without textual proof. Start by reading the question twice and circling the command word — "क्या" (literal) vs "क्यों/कैसे/क्या प्रभाव" (inferential). For literal questions, scan the poem for keywords from the question and copy the exact phrase. For inferential questions, use the "Evidence → Inference → Justification" ladder: first underline 2-3 relevant lines, then state what they imply about the theme/character/emotion, then explain why that implication holds given the poem's context (e.g., the poet's background, the imagery pattern). The key insight: inferential answers are not guesses — they are logical bridges built from textual bricks.

## DIAGNOSTIC_QUESTION_1
"ओलर वक" कविता में 'पफमफ;क' शब्द का शाब्दिक अर्थ क्या है? (पाठ्यपुस्तक के 'शब्दार्थ' खंड के आधार पर उत्तर दें।)

## DIAGNOSTIC_ANSWER_1
Correct answer: "पफमफ;क" का अर्थ है "पफमफ;क की लोकप्रिय वोक्क्स" (पफमफ;क का रणहकोर रूप)। A wrong answer like "पफमफ;क का अर्थ है बादल" reveals the student is guessing from context instead of consulting the textbook glossary — a literal comprehension error where they fail to retrieve explicitly provided information.

## DIAGNOSTIC_QUESTION_2
कविता "रक्सक्स" में "स iRFkj s p^kuksa" पंक्ति का शाब्दिक अर्थ समझाते हुए बताएँ कि यह पंक्ति कवि के किस मनोभाव को प्रत्यक्ष रूप से प्रकट करती है?

## DIAGNOSTIC_ANSWER_2
Correct answer: शाब्दिक अर्थ है "यह पहला कदम है, ये पाँव हैं" — कवि सीधे-सीधे कह रहा है कि यात्रा का आरंभ हो चुका है। A wrong answer like "यह पंक्ति बताती है कि कवि थक गया है" reveals the student is imposing an external interpretation (fatigue) not supported by the literal text — confusing inferential reading with literal retrieval.

## DIAGNOSTIC_QUESTION_3
"ओलर वक" की इन पंक्तियों के आधार पर एक नैतिक निष्कर्ष निकालें: "फ[कीह गकब गोक वब्ज] फिजध&lह वब्ज] पिि िबि" — कवि यहाँ प्रकृति के किस चक्र को दर्शा रहा है और इसका मानव जीवन पर क्या निहितार्थ है?

## DIAGNOSTIC_ANSWER_3
Correct answer: कवि ऋतु-चक्र (पतझड़ के बाद बसंत) दर्शा रहा है; निहितार्थ: दुःख के बाद सुख अवश्य आता है, परिवर्तन शाश्वत है। Steps: (1) Identify imagery: सूखे पत्ते गिरना (पतझड़) → नई कोपलें फूटना (बसंत)। (2) Infer cycle: प्रकृति में अंत के बाद नई शुरुआत। (3) Map to human life: निराशा के बाद आशा। A wrong answer like "कवि कह रहा है कि पत्ते गिरते हैं" stays at literal description and misses the inferential leap to universal truth — the classic "description passed off as analysis" error.

## DIAGNOSTIC_QUESTION_4
"रक्सक्स" कविता में "एल्ज-कत्ज" (वुजितकेहु) पद का प्रयोग कवि ने क्यों किया है? पाठ के प्रमाण सहित समझाएँ कि यह पद कविता के केंद्रीय भाव को कैसे गहराता है?

## DIAGNOSTIC_ANSWER_4
Correct answer: "एल्ज-कत्ज" का अर्थ है 'विपरीत/उल्टा' — कवि कहता है कि जीवन-मृत्यु, सुख-दुःख, मिलन-विछोह सब विपरीतताएँ एक साथ चलती हैं। प्रमाण: "रक्सक्स रक्सक्स रक्सक्स / स अल्ज कत्ज रक्सक्स" की पुनरावृत्ति। यह केंद्रीय भाव (जीवन की द्वंद्वात्मकता) को गहराता है क्योंकि पुनरावृत्ति से द्वंद्व की निरंतरता झलकती है। A wrong answer like "कवि ने सुंदर शब्द प्रयोग किया है" ignores the semantic weight and structural function — a surface-level reading missing the inferential link between word-choice and theme.

## DIAGNOSTIC_QUESTION_5
पाठ्यपुस्तक में दिए गए प्रश्न 5 ("इजफ्र इक्व;क ध ल्गपजह ग स" — इस कथन पर चर्चा करते हुए वकत के संदर्भ में इस दृश्य की यथार्थपरकता पर प्रकाश डालिए) का मूल्यांकन करें: क्या यह प्रश्न शाब्दिक बोध जांचता है या नैतिक बोध? अपने निर्णय का औचित्य सिद्ध करें।

## DIAGNOSTIC_ANSWER_5
Correct answer: यह नैतिक/नैतिक बोध (evaluative-inferential) प्रश्न है क्योंकि: (1) "ल्गपजह" शब्द पाठ में स्पष्ट नहीं — इसकी व्याख्या करनी पड़ती है; (2) "यथार्थपरकता" का निर्णय पाठ + बाहरी ज्ञान (ग्रामीण जीवन की समझ) दोनों मांगता है; (3) उत्तर में व्यक्तिगत मत + पाठ्य साक्ष्य दोनों चाहिए। A wrong answer like "यह शाब्दिक प्रश्न है क्योंकि पाठ में लिखा है" reveals inability to distinguish question taxonomy — the student sees words from the text and assumes literal, missing the evaluative demand.

## DIAGNOSTIC_QUESTION_6
"ओलर वक" की अंतिम दो पंक्तियों ("फन्र उघा टकुक फ्ककु] फ्लस इक्व;क फ्ककु ब्जि फ्ककु") से प्रेरित होकर एक नई 4-पंक्ति की कविता लिखें जो 'अनिश्चितता में आशा' का भाव व्यक्त करे। शाब्दिक अर्थ से आगे जाकर रूपक का प्रयोग करें।

## DIAGNOSTIC_ANSWER_6
Expected criteria: (1) 4 lines in Hindi; (2) uses metaphor (not literal description); (3) conveys hope amid uncertainty; (4) echoes the original's rhythm. Good answer example: "अंधेरे में एक दीप जलता है / न जाने कब बुझ जाए / पर उसकी लौ में / नया सवेरा छिपा है।" A poor answer like "कल का पता नहीं पर हम खुश हैं" is literal, lacks metaphor, and shows no inferential transfer from source text to new creation.

## COMMON_MISCONCEPTION
Students believe "inferential question" means "write your personal opinion/feelings about the poem." They write answers like "मुझे यह कविता अच्छी लगी क्योंकि यह सुंदर है" or "कवि बहुत दुखी लगता है" without anchoring a single claim in textual evidence. This happens because Class 10-11 comprehension often accepted "personal response" answers, but Class 12 board marking scheme (and CUET/JEE language sections) requires EVIDENCE-BASED INFERENCE: every claim must trace back to specific words/lines/patterns in the text. The error costs 2-3 marks per question in board exams and leads to rejection in competitive exam comprehension passages.

## ON_FAILURE
If a student cannot distinguish literal vs inferential or writes evidence-free inferences: (1) Give them a 4-line unseen poem and 3 questions — one literal ("किस मौसम का वर्णन है?"), one inferential ("कवि का मनोदशा क्या है?"), one evaluative ("क्या आप सहमत हैं?") — ask them to label each question type first. (2) For the inferential one, force the "Quote → Infer → Justify" template on paper: Column A (exact line), Column B (what it implies), Column C (why). (3) Re-diagnose using c11_hin_ar_cbse_01_012 (Class 11 Comprehension node) literal/inferential exercises — have them redo 5 questions with the template. (4) Only advance when they produce 3 consecutive inferential answers with correct textual citations.

## BUILDS_ON
Class 11 literal/inferential comprehension (c11_hin_ar_cbse_01_012) where students learned basic question-type identification but not the structured evidence-inference-justification chain required for Class 12 board marking scheme.

## LEADS_TO
Critical Thinking: Analysis and Interpretation (c12_hin_a_cbse_05_013) where inferential skills are extended to multi-layered thematic analysis, intertextual connections, and authorial intent evaluation.

## PREREQUISITE_NODE_IDS
c12_hin_a_cbse_05_001, c12_hin_a_cbse_05_002, c12_hin_a_cbse_05_008, c12_hin_a_cbse_05_009, c12_hin_a_cbse_05_010, c11_hin_ar_cbse_01_012, c11_hin_ar_cbse_05_012, c12_hin_a_cbse_05_011

## PREREQUISITE_REASONS
c12_hin_a_cbse_05_001: Context/background knowledge needed to make valid inferences about poet's intent
c12_hin_a_cbse_05_002: Narrative structure understanding helps locate where in the poem evidence resides
c12_hin_a_cbse_05_008: Imagery/metaphor knowledge essential for inferring meaning from figurative language
c12_hin_a_cbse_05_009: Irony/symbolism recognition prevents literal reading of non-literal devices
c12_hin_a_cbse_05_010: Vocabulary mastery ensures accurate literal retrieval of word meanings
c11_hin_ar_cbse_01_012: Class 11 foundation in literal/inferential distinction
c11_hin_ar_cbse_05_012: Class 11 Chapter 5 specific comprehension practice with similar poetic style
c12_hin_a_cbse_05_011: Grammatical features become textual evidence for literal/inferential comprehension answers  

## FORWARD_NODE_IDS
c12_hin_a_cbse_05_013, c12_hin_a_cbse_05_014, c12_hin_a_cbse_05_015

## FORWARD_REASONS
c12_hin_a_cbse_05_013: Critical thinking requires the evidence-based inference skill mastered here as its foundation
c12_hin_a_cbse_05_014: Writing skills answers (especially analytical paragraphs) use the same Quote→Infer→Justify structure
c12_hin_a_cbse_05_015: Ensures literal and inferential understanding before oral expression.  

## CROSS_SUBJECT_PREREQS
c11_hin_ar_cbse_01_012, c11_hin_ar_cbse_05_012
## CROSS_SUBJECT_REASONS
c11_hin_ar_cbse_01_012: Class 11 Hindi Aroh Comprehension node — builds the foundational question-type taxonomy
c11_hin_ar_cbse_05_012: Class 11 Hindi Aroh Chapter 5 Comprehension — same poet/theme continuity for deeper inference practice

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_01_012 -> c12_hin_a_cbse_05_012 -> c12_hin_a_cbse_05_013

## THIS_FORMULA
Literal Question = Direct Text Retrieval (Keyword Scan → Exact Phrase Copy) | Inferential Question = Evidence Chain (Quote Text → State Implication → Justify with Context/Pattern)

## FORMULA_VARIABLES
N/A - conceptual

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
linguistic

## CROSS_SUBJECT
N/A | English Core Unseen Passage Comprehension uses identical literal/inferential taxonomy and evidence-based answer structure for CBSE Board and CUET
 N/A | History Source-Based Questions require distinguishing explicitly stated facts (literal) from historian's interpretation (inferential) using textual evidence from primary sources
## PREREQ_CONCEPT
Ability to distinguish explicitly stated information from implied meaning in a text, and to cite exact textual evidence for any claim.

## PREREQ_BEFORE
Student must be able to: (1) identify keywords in a question, (2) scan a poem for those keywords, (3) understand the textbook glossary meanings of key words, (4) recognize basic poetic devices (metaphor, repetition, imagery).

## PREREQ_STUCK
If stuck, review "Keyword Scanning & Glossary Use" from c12_hin_a_cbse_05_010 and "Poetic Device Identification" from c12_hin_a_cbse_05_008/c12_hin_a_cbse_05_009.

## WORKED_EXAMPLE_1
PROBLEM: "ओलर वक" कविता के आधार पर उत्तर दें: "कवि ने 'ओलर वक' (ओलावृष्टि) को किस रूप में प्रस्तुत किया है और इसका क्या प्रभाव पड़ा है?" — यह एक नैतिक प्रश्न है। 4+ चरणों में उत्तर लिखें।

STEPS:
- Step 1: प्रश्न का प्रकार पहचानें — "किस रूप में" + "क्या प्रभाव" = नैतिक (inferential), शाब्दिक नहीं। आदेश शब्द "किस रूप" और "प्रभाव" निहित अर्थ मांगते हैं।
- Step 2: कविता में 'ओलर वक' से संबंधित पंक्तियाँ खोजें — "पफमफ;क ध लोकहकोद वोक्क्स" (शब्दार्थ), "िक्वइह इज रिि इक्वइह इज रिि" (ध्वनि अनुकरण), "िक्वकव क्वकव त्रिन त्रिन" (गति)।
- Step 3: प्रमाण से निष्कर्ष निकालें — ओलावृष्टि को कवि ने 'लोकप्रिय रणहकोर' (वोक्क्स) कहा है, न कि विनाशक। ध्वनि "त्रिन त्रिन" संगीतमय है, भयावह नहीं।
- Step 4: प्रभाव बताएं — "वेकद फनु वेकद कज इउेघुस ध गक्सोस इअपह" (बार-बार आने वाला आनंद), "एनआरज इजा एनकुह एफख" (निश्चिंतता का प्रमाण) — ओलावृष्टि ग्रामीण जीवन में उत्सव और राहत लाती है।
- Step 5: उत्तर संरचना करें — बिंदु: कवि ओलावृष्टि को विनाश नहीं, प्रकृति का उत्सव मानते हैं। प्रमाण: "पफमफ;क ध लोकहकोद वोक्क्स" और "त्रिन त्रिन" ध्वनि। व्याख्या: ग्रामीण जनमानस इसे फसल के लिए शुभ मानता है, भय नहीं। केंद्रीय भाव से जोड़ें: प्रकृति और मानव का सहअस्तित्व।

REASONING: This 5-step chain forces the student to move from question analysis → evidence location → inference → contextual justification → structured answer — exactly what the CBSE marking scheme rewards (1 mark for point, 1 for evidence, 1 for explanation).

ANSWER: कवि ने 'ओलर वक' को प्रकृति का लोकप्रिय उत्सव (रणहकोर वोक्क्स) माना है, विनाशक नहीं। प्रमाण: "पफमफ;क ध लोकहकोद वोक्क्स" और ध्वन्यात्मक "त्रिन त्रिन"। प्रभाव: ग्रामीण जनमानस में प्रसन्नता और निश्चिंतता ("वेकद फनु वेकद कज...") — यह फसल के लिए शुभ संकेत है। केंद्रीय भाव: प्रकृति का मानवीयकरण और सहअस्तित्व।

## WORKED_EXAMPLE_2
PROBLEM: "रक्सक्स" कविता में "रक्सक्स रक्सक्स रक्सक्स" की पुनरावृत्ति का क्या अभिप्राय है? पाठ्य साक्ष्य सहित समझाएँ। (बोर्ड परीक्षा 3 अंक प्रश्न)

STEPS:
- Step 1: प्रश्न विश्लेषण — "क्या अभिप्राय" + "पाठ्य साक्ष्य सहित" = नैतिक प्रश्न जिसमें प्रमाण अनिवार्य है।
- Step 2: पुनरावृत्ति के तीनों उदाहरण चिह्नित करें — (क) प्रथम छंद: "रक्सक्स रक्सक्स रक्सक्स / स इरफकज दकस गे तुसा", (ख) द्वितीय छंद: "रक्सक्स रक्सक्स रक्सक्स / स अल्ज कत्ज रक्सक्स", (ग) तृतीय छंद: "इक्सकक्स इक्सकक्स इक्सकक्स"।
- Step 3: प्रत्येक प्रसंग में अर्थ निकालें — (क) श्रम/प्रयत्न की निरंतरता (पैर चलाना), (ख) जीवन की द्वंद्वात्मकता (विपरीतताओं का सहअस्तित्व), (ग) तीव्रता/आवेग (हृदय की धड़कन/उत्कंठा)।
- Step 4: पैटर्न पहचानें — पुनरावृत्ति क्रमिक गहराती है: शारीरिक क्रिया → दार्शनिक सत्य → भावनात्मक चरम।
- Step 5: संश्लिष्ट उत्तर लिखें — पुनरावृत्ति जीवन की अनवरत गति, द्वंद्व, और उत्कंठा को ध्वन्यात्मक रूप से मूर्त करती है।

REASONING: The step-by-step pattern recognition (physical → philosophical → emotional) is the inferential leap examiners look for. Most students only cite one occurrence and miss the progression.

ANSWER: "रक्सक्स" की त्रिवार पुनरावृत्ति जीवन की त्रिविध गति दर्शाती है: (1) प्रथम छंद में "इरफकज दकस गे तुसा" — श्रमशील पैरों की अनवरत गति; (2) द्वितीय छंद में "अल्ज कत्ज रक्सक्स" — जीवन की विपरीतताओं (सुख-दुःख, मिलन-विछोह) का सहअस्तित्व; (3) तृतीय छंद में "इक्सकक्स इक्सकक्स" — हृदय की तीव्र धड़कन/उत्कंठा। क्रमिक गहराव: शारीरिक → दार्शनिक → भावनात्मक। प्रमाण: तीनों छंदों की प्रारंभिक पंक्तियाँ।

## WORKED_EXAMPLE_3
PROBLEM: CUET-शैली प्रश्न: "निम्नलिखित कथनों पर विचार करें: कथन 1: 'ओलर वक' में कवि प्रकृति का मानवीयकरण करता है। कथन 2: 'रक्सक्स' में कवि जीवन की निस्सारता व्यक्त करता है। सही विकल्प चुनें: (अ) केवल कथन 1 सही (ब) केवल कथन 2 सही (स) दोनों सही (द) दोनों गलत। अपने उत्तर का औचित्य पाठ्य साक्ष्य से सिद्ध करें।"

STEPS:
- Step 1: दोनों कथनों को अलग-अलग जांचें — यह दावा-सत्यापन (assertion-verification) प्रकार का नैतिक प्रश्न है।
- Step 2: कथन 1 की जांच — "ओलर वक" में: "पफमफ;क ध लोकहकोद वोक्क्स" (ओलावृष्टि को रणहकोर मानना), "इउेघुस ध गक्सोस इअपह" (आनंद देना) — मानवीय गुण (लोकप्रियता, आनंद देना) आरोपित → कथन 1 सही।
- Step 3: कथन 2 की जांच — "रक्सक्स" में: "फेह इजा जल गक्सक घ ति इकसलसख क्ट दकस" (आशा), "विउस इउ ध [क्त दकस नक्सु दुस ध" (हृदय की धड़कन भी रक्सक्स) — जीवन में गति, आशा, उत्कंठा है, निस्सारता नहीं → कथन 2 गलत।
- Step 4: विकल्प मिलान — केवल कथन 1 सही → विकल्प (अ)।
- Step 5: औचित्य लेखन — कथन 1 के लिए "वोक्क्स" और "गक्सोस" शब्द; कथन 2 के विरुद्ध "जल गक्सक" (आशा) और "इक्सकक्स" (जीवन-ऊर्जा) शब्द उद्धृत करें।
- Step 6: अंतिम उत्तर संरचना — विकल्प + दोनों कथनों का साक्ष्य-आधारित खंडन/समर्थन।

REASONING: Competitive exams (CUET, JEE language) test the ability to evaluate competing claims using textual evidence — not just answer direct questions. This worked example bridges board-style inference to competitive-exam assertion-reasoning format.

ANSWER: सही विकल्प: (अ) केवल कथन 1 सही। औचित्य: कथन 1 सही — "पफमफ;क ध लोकहकोद वोक्क्स" (ओलावृष्टि को रणहकोर मानना) और "इउेघुस ध गक्सोस इअपह" (आनंद प्रदाता) से प्रकृति का मानवीयकरण सिद्ध। कथन 2 गलत — "फेह इजा जल गक्सक घ ति इकसलसख क्ट दकस" (आशा की उपस्थिति) और "विउस इउ ध [क्त दकस नक्सु दुस ध" (हृदय की जीवंत धड़कन) जीवन की सार्थकता दर्शाते हैं, निस्सारता नहीं।

## COMPETENCY_QUESTION_1
QUESTION: "ओलर वक" कविता की इन पंक्तियों पर विचार करें: "िक्वकव क्वकव त्रिन त्रिन / िक्वकव क्वकव त्रिन त्रिन / िक्वकव क्वकव त्रिन त्रिन"। एक छात्र लिखता है: "कवि ने 'त्रिन त्रिन' शब्द तीन बार दोहराया है ताकि कविता लंबी लगे।" इस उत्तर में क्या कमी है? सही नैतिक उत्तर लिखें जिसमें प्रमाण, निष्कर्ष, और औचित्य तीनों हों।

COMPETENCY: Textual Evidence-Based Reasoning (CBSE Competency: Critical Thinking & Analysis)

STEPS:
- Step 1: छात्र के उत्तर की त्रुटि पहचानें — यह शाब्दिक अवलोकन (पुनरावृत्ति गिनती) है, नैतिक व्याख्या नहीं; "कविता लंबी लगे" लेखकीय उद्देश्य का निराधार अनुमान है।
- Step 2: ध्वनि अनुकरण (ऑनोमेटोपिया) पहचानें — "त्रिन त्रिन" ओलों की ध्वनि का अनुकरण है।
- Step 3: प्रसंग से जोड़ें — पूर्ववर्ती पंक्तियों में "पफमफ;क ध लोकहकोद वोक्क्स" — ध्वनि भय नहीं, उत्सव की है।
- Step 4: संश्लिष्ट उत्तर बनाएं — पुनरावृत्ति ध्वनि की लयबद्धता, निरंतरता, और उत्सवी स्वर को मूर्त करती है।

ANSWER: छात्र का उत्तर शाब्दिक अवलोकन मात्र है, नैतिक व्याख्या नहीं। सही उत्तर: "त्रिन त्रिन" की त्रिवार पुनरावृत्ति ओलों की ध्वनि का अनुकरण (ऑनोमेटोपिया) है जो तीन कार्य करती है: (1) ध्वनि की लयबद्ध निरंतरता दर्शाती है — "िक्वकव क्वकव त्रिन त्रिन" की गति; (2) उत्सवी स्वर स्थापित करती है — पूर्ववर्ती "पफमफ;क ध लोकहकोद वोक्क्स" से मेल खाता है; (3) ग्रामीण जनमानस की प्रसन्नता ("वेकद फनु वेकद कज...") को ध्वनि-चित्रण से जोड़ती है। प्रमाण: शब्दार्थ खंड में "त्रिन त्रिन" को "ध्वनि अनुकरण" बताया गया है।

DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: CUET/Board Hybrid: "रक्सक्स" कविता के द्वितीय छंद ("स अल्ज कत्ज रक्सक्स / स प्जरह इजरह रक्सक्स / लक [कसर कुकद्ज एनक्म्स...") में 'अल्ज-कत्ज' (विपरीतता) और 'प्जरह-इजरह' (पैर की जूती/बिछिया) के युग्म क्या दर्शाते हैं? एक तुलनात्मक सारणी बनाएं जिसमें कॉलम हों: (क) युग्म, (ख) शाब्दिक अर्थ, (ग) नैतिक अर्थ, (घ) केंद्रीय भाव से संबंध। फिर 50 शब्दों में केंद्रीय भाव सारांशित करें।

COMPETENCY: Synthesis & Structured Analysis (CBSE Competency: Organizing Information + CUET Competency: Comparative Analysis)

STEPS:
- Step 1: दोनों युग्मों को अलग करें — 'अल्ज-कत्ज' (विपरीत/उल्टा) और 'प्जरह-इजरह' (पैर के आभूषण/बिछिया)।
- Step 2: शाब्दिक अर्थ लिखें — शब्दार्थ खंड से: अल्ज-कत्ज = वुजितकेहु; प्जरह-इजरह = इक्वक्सा ध फेि, प्क्ज्क्क्ग वगइ ध फेि एनकहु एनकहु।
- Step 3: नैतिक अर्थ निकालें — अल्ज-कत्ज: जीवन की द्वंद्वात्मकता (सुख-दुःख, जीवन-मृत्यु); प्जरह-इजरह: जीवन-यात्रा के साधन/संगी जो अंत तक साथ देते हैं।
- Step 4: केंद्रीय भाव से जोड़ें — दोनों युग्म मिलकर "जीवन की अनवरत गति में द्वंद्व और साथ" दर्शाते हैं।
- Step 5: सारणी बनाएं + 50-शब्द सारांश लिखें।

ANSWER: 
सारणी:
| युग्म | शाब्दिक अर्थ | नैतिक अर्थ | केंद्रीय भाव से संबंध |
|------|--------------|-------------|-------------------|
| अल्ज-कत्ज | विपरीत/उल्टा | जीवन की द्वंद्वात्मकता (सुख-दुःख, मिलन-विछोह) | जीवन में विरोधाभास सहअस्तित्व में हैं |
| प्जरह-इजरह | पैर की जूती/बिछिया | जीवन-यात्रा के निरंतर साथी/साधन | गति के लिए आधारभूत सहारा |

सारांश (50 शब्द): "रक्सक्स" में 'अल्ज-कत्ज' जीवन की अंतर्निहित द्वंद्वात्मकता को और 'प्जरह-इजरह' यात्रा के अविचल साथ को मूर्त करते हैं। दोनों मिलकर केंद्रीय भाव व्यक्त करते हैं: जीवन विरोधाभासों भरी अनवरत यात्रा है जहाँ प्रत्येक कदम (रक्सक्स) द्वंद्व और साहचर्य दोनों लिए होता है — थमना नहीं, चलते रहना ही नियति है।

DIFFICULTY: hard