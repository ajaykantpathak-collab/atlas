## DEFINITION
"Before You Read: Context and Background" is the preparatory step where students systematically gather information about the poet, the literary movement, the historical era, and the significance of the title *before* engaging with the poem's text, creating a mental framework that guides interpretation and prevents misreading.

## COGNITIVE_LEVEL
understand

## MASTERY_CRITERIA
The student can independently extract the poet's literary identity (style, major themes, period), explain the socio-historical forces shaping the poem, and articulate how the title functions as a thematic key — all without reading the poem itself — and use this framework to make specific, evidence-based predictions about the poem's imagery and concerns.

## SCOPE_BOUNDARY
This node covers: (1) reading and synthesizing the NCERT poet introduction, (2) identifying the literary movement (आधुनिक/समकालीन कविता) and its characteristics, (3) situating the poem in post-Independence Hindi poetry's shift from *Chhayavaad* to *Prayogvaad*/*Nayi Kavita*, (4) decoding the title "cukjl" as a metaphor for urban marginality. It does NOT cover line-by-line analysis, poetic devices, or thematic development — those belong to subsequent nodes (c12_hin_a_cbse_04_002 onward).

## WALKTHROUGH
Imagine you open your Hindi textbook to Chapter 4 and see the poem "cukjl" by osQnkjukFk ¯lg. You feel a vague anxiety: the title is unfamiliar, the poet's name doesn't ring a bell, and the lines look dense. Most students skip the grey box above the poem — that's the trap. Start *there*. Read the poet's bio slowly: note "1934–2018", "आधुनिक हिंदी कविता में प्रयोग", "चित्रात्मकता", "अस्तित्ववादी सरोकार". Ask: *What does 'experiment in modern Hindi poetry' mean?* It signals broken metre, free verse, concrete imagery over abstract emotion. Next, place the dates: 1934 birth means he wrote post-1947, amid urbanization, Partition trauma, Nehruvian optimism turning to disillusionment. Now the title: "cukjl" — a narrow lane, a ghetto, a cul-de-sac. Not a highway, not a plaza. *Predict*: this poem will speak from the margins, using tight, claustrophobic images. That prediction is your reading compass. The key insight: **context is not trivia — it is the lens that brings the poem into focus.**

## DIAGNOSTIC_QUESTION_1
Who is the poet of "cukjl" and which literary tendency in modern Hindi poetry is he most associated with?

## DIAGNOSTIC_ANSWER_1
The poet is Ashok Vajpeyi (अशोक वाजपेयी), a central figure of *Prayogvaad* (Experimentalism) and *Nayi Kavita* (New Poetry) in post-Independence Hindi literature, known for privileging image over statement, fragmentation over narrative, and existential questioning over ideological certainty. A wrong answer (e.g., naming a *Chhayavaad* poet like Nirala or a *Pragativad* poet like Nagarjun) reveals the student cannot distinguish literary generations — a fatal error because each movement reads the world through radically different optics.

## DIAGNOSTIC_QUESTION_2
Explain in your own words why knowing the poet's birth year (1934) and the phrase "आधुनिक हिंदी कविता में प्रयोग" matters for reading "cukjl".

## DIAGNOSTIC_ANSWER_2
1934 places the poet's formative years in the 1950s–60s — the era of *Nayi Kavita* (Muktibodh, Agyeya, Shamsher) when Hindi poetry broke from *Chhayavaad*'s lyrical romanticism to confront urban alienation, bureaucratic absurdity, and the self's fragmentation. "प्रयोग" signals formal rupture: no fixed metre, no rhyme scheme, syntax stretched to breaking point. A student who says "it helps understand the poet's life" misses the point: context tells you *what formal and thematic contracts the poem has already broken* before you read line one.

## DIAGNOSTIC_QUESTION_3
You are given an unseen poem titled "फ्लाईओवर के नीचे" by a poet born in 1965, described in the textbook as "समकालीन कविता के प्रमुख हस्ताक्षर, नगरीय यथार्थ के चितेरे". Apply the context-gathering steps to write three specific predictions about this poem's imagery, tone, and structure.

## DIAGNOSTIC_ANSWER_3
Step 1: Identify period — 1965 birth = post-1990s liberalization poet (globalization, flyovers, displacement). Step 2: Decode label — "नगरीय यथार्थ" = concrete, gritty, anti-romantic urban detail (exhaust fumes, migrant labour, neon lights). Step 3: Title analysis — "फ्लाईओवर के नीचे" = liminal space, marginalized lives beneath infrastructure of power. Predictions: (1) Imagery: concrete, steel, dust, marginalized bodies (not flowers, rivers). (2) Tone: clinical, ironic, or rage-quiet, not sentimental. (3) Structure: free verse, enjambment mimicking fragmented urban perception. A wrong answer predicting "beautiful description of nature" or "rhyming couplets" shows failure to transfer context-to-text mapping.

## DIAGNOSTIC_QUESTION_4
Compare the contextual framework of "cukjl" (Ashok Vajpeyi, 1934, *Nayi Kavita*) with a *Bhakti* poem like Kabir's "साँईं इतना दीजिए". How does the shift from *Bhakti* context to *Nayi Kavita* context alter the very definition of what a "poem" does?

## DIAGNOSTIC_ANSWER_4
*Bhakti* context: poem as *upadesha* (moral instruction), communal voice, simple metaphor (flour, guest), divine addressee, certainty of meaning. *Nayi Kavita* context: poem as *anubhuti* (phenomenological exploration), individual consciousness, fractured metaphor (cul-de-sac, dead rat, evening), no guaranteed addressee, ambiguity as value. The shift moves poetry from *transmitting truth* to *enacting the search for truth in a disenchanted world*. A student who says "both are poems so they're similar" commits category error — they confuse form with function.

## DIAGNOSTIC_QUESTION_5
Evaluate the claim: "Reading the 'Before You Read' box is optional; the poem should stand on its own. If you need biography to understand it, the poem has failed."

## DIAGNOSTIC_ANSWER_5
This claim confuses *autonomy* with *hermeticism*. Modernist poetry (Eliot, Celan, Vajpeyi) deliberately *requires* context — its allusions, intertextuality, and formal innovations are dialogues with tradition and history. The "Before You Read" box is not a crutch; it is the *minimal shared knowledge* the poet assumes. Without knowing Vajpeyi's *Prayogvaad* stance, a student reads "लड़कों के डैने" as biological nonsense rather than surreal metamorphosis. The poem *does* stand on its own — but only for a reader who brings the context the poem itself presupposes. Rejecting context is not purity; it is illiteracy.

## DIAGNOSTIC_QUESTION_6
Create a "Before You Read" note for a hypothetical poem "मेट्रो का आखिरी डिब्बा" by a fictional poet born in 1992, described as "डिजिटल युग की कविता के प्रतिनिधि, भाषा और माध्यम की सीमाएं तोड़ने वाले". Include: literary movement, two likely themes, one formal prediction, and the title's metaphorical charge.

## DIAGNOSTIC_ANSWER_6
**Literary Movement:** Digital-age / Post-globalization Hindi poetry (post-2010), characterized by code-switching, multimodality, attention economy critique. **Themes:** (1) Algorithmic alienation / performative selfhood, (2) Compression of space-time in gig economy. **Formal Prediction:** Fragmented lines mimicking notification bursts; possible QR code / emoji / English-Hindi hybridity; non-linear reading paths. **Title Metaphor:** "आखिरी डिब्बा" = marginal space in a system designed for flow; the poet speaks from the last coach — precarious, observant, disconnected from the driver's cabin. A poor answer lists generic themes ("love, sadness") and ignores the digital-age descriptor, showing inability to infer from literary-historical labels.

## COMMON_MISCONCEPTION
Students treat the "Before You Read" box as a *biographical fact file* to memorize for 1-mark questions ("कवि का जन्म कब हुआ?"). They miss that every detail — "चित्रात्मकता", "अस्तित्ववादी सरोकार", "प्रयोग" — is a *hermeneutic instruction*: it tells you *how to read*. For example, seeing "चित्रात्मकता" should trigger: *I will hunt for concrete, visual, non-abstract images.* Seeing "अस्तित्ववादी सरोकार" should trigger: *I will track the speaker's isolation, absurdity, freedom.* Memorizing dates without converting them into reading protocols is the error that costs marks in both Board (long answers demand contextual anchoring) and CUET (unseen passages test context-to-text transfer).

## ON_FAILURE
If a student cannot convert the poet's intro into reading predictions: (1) Have them re-read *only* the NCERT intro for "cukjl" and underline every adjective describing the poetry (चित्रात्मक, प्रयोगशील, अस्तित्ववादी). (2) For each adjective, write one question they will ask the poem (e.g., "चित्रात्मक" → "Which three images are most vivid?"). (3) Read the poem *only* to answer those questions. (4) Debrief: "Which prediction held? Which failed? Why?" This trains context-as-tool, not context-as-trivia.

## BUILDS_ON
Class 11 skill of reading poet introductions and identifying literary movements (e.g., *Chhayavaad*, *Pragativad*) from nodes like c11_hin_ar_cbse_01_001.

## LEADS_TO
Directly enables "Text: Plot and Narrative Structure" (c12_hin_a_cbse_04_002) where the poem's structural choices are analyzed through the lens of *Prayogvaad* formalism.

## PREREQUISITE_NODE_IDS
c11_hin_ar_cbse_01_001, c11_hin_ar_cbse_02_001, c11_hin_ar_cbse_03_001, c11_hin_v_cbse_01_001
## PREREQUISITE_REASONS
c11_hin_ar_cbse_01_001: Establishes the routine of reading "Before You Read" for context — this node deepens it for Class 12's more complex modernist texts. c11_hin_ar_cbse_02_001: Builds familiarity with *Nayi Kavita* features (free verse, imagery) via earlier poems. c11_hin_ar_cbse_03_001: Reinforces title-decoding as predictive skill. c11_hin_v_cbse_01_001: Provides parallel practice in Vitan textbook with different poets/movements.
c11_hin_ar_cbse_02_001: "Before You Read: की समझ आवश्यक है, क्योंकि यह नोड ("Before You Read:) इसी आधार पर आगे बढ़ता है।  
c11_hin_ar_cbse_03_001: "Before You Read: की समझ आवश्यक है, क्योंकि यह नोड ("Before You Read:) इसी आधार पर आगे बढ़ता है।  
c11_hin_v_cbse_01_001: "Before You Read: की समझ आवश्यक है, क्योंकि यह नोड ("Before You Read:) इसी आधार पर आगे बढ़ता है।  

## FORWARD_NODE_IDS
c12_hin_a_cbse_04_002, c12_hin_a_cbse_04_003, c12_hin_a_cbse_04_004, c12_hin_a_cbse_04_005, c12_hin_a_cbse_04_006, c12_hin_a_cbse_04_008

## FORWARD_REASONS
c12_hin_a_cbse_04_002: Context predicts *Prayogvaad* structure (fragmented, non-narrative) — student now knows *why* the poem lacks plot. c12_hin_a_cbse_04_003: "cukjl" as urban margin predicts setting — student expects claustrophobic, sensory, nocturnal atmosphere. c12_hin_a_cbse_04_004: Existential concern predicts protagonist — student looks for isolated, questioning consciousness, not heroic figure. c12_hin_a_cbse_04_005: Marginal setting predicts supporting characters — student expects fleeting, spectral presences (beggar, rat, evening). c12_hin_a_cbse_04_006: *Prayogvaad* + post-Independence disillusionment predicts primary theme — alienation in modern city.
c12_hin_a_cbse_04_008: Context of OsnkjukFk lg — biographical lens on imagery choices.  
c12_hin_a_cbse_04_003: Supplies historical/cultural context of the poet and the village milieu essential for social setting.  
c12_hin_a_cbse_04_004: Provides poet background and context of urban Hindi poetry essential to read the street as a conscious entity.  
c12_hin_a_cbse_04_005: अगला तार्किक चरण: Character analysis of supporting characters in a poem involves identifying the secondary figures — w... इस नोड की अवधारणाओं को सीधे उपयोग/विस्तारित करता है।  
c12_hin_a_cbse_04_006: Context/background establishes the poet's philosophical leanings (existential imagery).  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
No prior-class nodes from other subjects were provided in the input; cross-subject links are established at Class 12 level in CROSS_SUBJECT below.

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_01_001 -> c12_hin_a_cbse_04_001 -> c12_hin_a_cbse_04_002

## THIS_FORMULA
Context Framework = Poet's Literary Identity (Movement + Style) + Historical Era (Socio-Political Coordinates) + Title Decoding (Metaphorical Charge) → Reading Predictions (Imagery, Tone, Structure, Themes)

## FORMULA_VARIABLES
- Poet's Literary Identity: Movement label (e.g., *Prayovad*), style markers (e.g., चित्रात्मकता, प्रयोग)
- Historical Era: Birth/death dates → formative decades → dominant discourses (e.g., 1934 → 1950s–60s *Nayi Kavita*)
- Title Decoding: Literal meaning + connotative field + syntactic role (e.g., "cukjl" = noun, marginal space, cul-de-sac)
- Reading Predictions: Testable hypotheses about the poem's formal and semantic choices

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
conceptual

## CROSS_SUBJECT
N/A | Post-Independence India (1947–1970s) — urbanization, planning, displacement — provides the material history that *Nayi Kavita* poets like Vajpeyi render into imagery (cul-de-sacs, bureaucratic colonies, migrant labour).  
 N/A | Social Change and Modernity in India — concepts of *anomie*, *marginality*, *public/private sphere* — give sociological vocabulary to articulate the poem's existential themes (alienation, anonymity in the city).
## PREREQ_CONCEPT
Ability to convert a textbook's biographical note into a set of *reading questions* (not just facts).

## PREREQ_BEFORE
Student must know how to locate the grey "Before You Read" box, distinguish poet's bio from poem's text, and recognize major Hindi literary movements (*Chhayavaad*, *Pragativad*, *Nayi Kavita*, *Samkaleen Kavita*).

## PREREQ_STUCK
If stuck, review Class 11 "Before You Read" nodes (e.g., c11_hin_ar_cbse_01_001) and practice: take any poet intro, list 3 style adjectives, turn each into a "I will look for..." question.

## WORKED_EXAMPLE_1
PROBLEM: Using only the NCERT "Before You Read" box for "cukjl", generate a structured context note that a student can carry into the first reading.

STEPS:
- Step 1: Extract poet data — Name: Ashok Vajpeyi. Lifespan: 1934–2018. Key labels: "आधुनिक हिंदी कविता में प्रयोग", "चित्रात्मकता", "अस्तित्ववादी सरोकार", "लय और छंद के नये प्रतिमान".
- Step 2: Map labels to literary movement — "प्रयोग" + "लय और छंद के नये प्रतिमान" = *Prayovad* / *Nayi Kavita* (1950s–70s). Hallmarks: free verse, image-centric, anti-rhetorical, existential.
- Step 3: Historical coordinates — Born 1934 → adolescent in 1947, young poet in 1950s–60s. Context: post-Partition trauma, Nehruvian modernization, rise of Hindi literary institutions, crisis of faith in progress.
- Step 4: Decode title "cukjl" — Literal: narrow lane, dead-end. Connotative: marginality, entrapment, lack of exit, intimate scale vs. grand narrative. Grammatical: masculine noun, singular, locative potential ("cukjl में").
- Step 5: Synthesize predictions — (a) Imagery: concrete, visual, urban, nocturnal, small-scale (rats, lamps, boys). (b) Structure: free verse, enjambment, no rhyme, stanza breaks as breath pauses. (c) Voice: solitary observer, detached yet implicated. (d) Themes: alienation, time's erosion, meaning in meaninglessness.

REASONING: Each step transforms a static textbook fact into an active reading tool. The movement label predicts form; the era predicts thematic pressure; the title predicts spatial logic. This mirrors how expert readers unconsciously frame texts.

ANSWER: **Context Note for "cukjl"**  
Poet: Ashok Vajpeyi (1934–2018), *Nayi Kavita* / *Prayovad*  
Movement Markers: Free verse, image > idea, existential questioning, formal innovation  
Historical Lens: Post-1947 urban Hindi modernity — planned colonies, bureaucratic life, fading ideals  
Title Key: "Cul-de-sac" → marginal space, no through-road, intimate entrapment  
Reading Compass: Expect tight visual frames, nocturnal palette, solitary consciousness, absence of resolution.

## WORKED_EXAMPLE_2
PROBLEM: A Class 12 student writes in the Board exam: "कवि अशोक वाजपेयी जी का जन्म 1934 में हुआ था। वे आधुनिक कविता के बड़े कवि हैं। उनकी कविता 'cukjl' गली के बारे में है।" Explain why this answer scores 0/2 for a "context and significance" question, and rewrite it to score full marks.

STEPS:
- Step 1: Diagnose the error — The answer lists facts (birth year, fame) but shows *zero* understanding of how those facts shape the poem. It treats context as decoration, not interpretation.
- Step 2: Identify what the marking scheme demands — CBSE expects: (a) Literary movement + its significance, (b) Title's thematic function, (c) One link between context and textual expectation.
- Step 3: Retrieve the context framework from Worked Example 1 — *Prayovad*, existential, urban marginality, "cukjl" as metaphor.
- Step 4: Draft the improved answer using the PEEL structure (Point, Evidence, Explanation, Link).
- Step 5: Verify against marking scheme — contains movement, title decoding, predictive link.

REASONING: Board examiners reward *analytical use* of context, not recall. The rewrite must show the student *thinking with* the context.

ANSWER: **Weak Answer (0/2):** "कवि अशोक वाजपेयी जी का जन्म 1934 में हुआ था। वे आधुनिक कविता के बड़े कवि हैं। उनकी कविता 'cukjl' गली के बारे में है।"  
**Strong Answer (2/2):** "अशोक वाजपेयी 'नयी कविता/प्रयोगवाद' के प्रमुख हस्ताक्षर हैं जिनकी कविता में चित्रात्मकता, छंद-मुक्ति और अस्तित्ववादी सरोकार प्रमुख हैं। 1934 में जन्मे वाजपेयी ने उत्तर-स्वातंत्र्योत्तर शहरी मोहभंग को भोगा है। शीर्षक 'cukjl' (कुचला/संकरी गली) इस कविता के लिए रूपक है: यह हाशिए की उस जगह को चिह्नित करता है जहाँ मुख्यधारा की विकास-गाथा नहीं पहुँचती। अतः कविता में हमें नगरीय विपन्नता, अकेलापन और अर्थहीनता के ठोस दृश्य मिलेंगे — कोई भावुक उपदेश नहीं।"

## WORKED_EXAMPLE_3
PROBLEM: A CUET-style unseen passage gives a 4-line poem fragment: "फ्लाईओवर के पायों तले / सोता है शहर का कचरा / और सपने देखता है / एक टूटा हुआ स्ट्रीटलाइट". The headnote: "Poet: Ananya (b. 1995), digital-age Hindi poet, works with Instagram poetry, code-switching, urban precarity." Using the context framework, analyze how the fragment confirms or complicates the headnote's claims.

STEPS:
- Step 1: Parse headnote — Movement: Digital-age / Instagram poetry (post-2015). Style: code-switching, brevity, visual-verbal hybridity, platform-shaped form. Themes: urban precarity, gig life, algorithmic mediation.
- Step 2: Analyze fragment for formal markers — 4 lines, no punctuation, enjambment ("पायों तले / सोता है"), free verse. *Confirms*: brevity, free verse. *Complicates*: no English/Hindi code-switching, no hashtag/emoji, no visual layout play — looks like print poetry.
- Step 3: Analyze imagery for thematic markers — "फ्लाईओवर के पायों तले" = infrastructure underbelly (precarity). "शहर का कचरा" = waste/marginalized bodies (precarity). "टूटा हुआ स्ट्रीटलाइट" = failed public infrastructure, dead hope (precarity). *Confirms*: urban precarity as core concern.
- Step 4: Analyze tone/voice — Third-person observational ("सोता है", "सपने देखता है"), personification of object (streetlight dreams). *Confirms*: detached witness stance. *Complicates*: Instagram poetry often uses first-person confessional; this is impersonal, almost documentary.
- Step 5: Synthesize — Fragment *partially* fits headnote: themes align perfectly, form aligns minimally (brevity only). Suggests poet may write differently for print vs. platform, or headnote oversimplifies.

REASONING: This mirrors CUET's "assertion-reason" or "case-based" questions where students must test a contextual claim against textual evidence. The framework forces systematic checking: form, imagery, tone, voice — each against the context label.

ANSWER: The fragment **confirms** the thematic claim (urban precarity via flyover underbelly, waste, broken infrastructure) but **complicates** the formal claim (digital-age/Instagram poetry). It lacks code-switching, visual experimentation, first-person immediacy, and platform-specific markers. Instead, it uses classic *Nayi Kavita* techniques: free verse, impersonal observation, personification, concrete imagery. This suggests either (a) the poet's "digital-age" label refers only to distribution, not form, or (b) the fragment is from a print-specific poem. A full answer would note this tension and refuse to reduce the poem to its headnote.

## COMPETENCY_QUESTION_1
QUESTION: The NCERT introduction to "cukjl" states: "कविता भाषा की लय और छंद के नये प्रतिमान गढ़ती है।" Based on this *alone*, predict **two** specific formal features you will find in the poem and **one** feature you will *not* find. Justify each prediction using the term "प्रतिमान" (paradigm/standard).

COMPETENCY: Inferring formal properties from a literary-historical claim (Context → Form prediction)

STEPS:
- Step 1: Unpack "नये प्रतिमान" — it means the poem deliberately breaks *old* standards (fixed metre, rhyme, stanzaic regularity) and establishes *new* ones (visual rhythm, syntactic cadence, imagistic pacing).
- Step 2: Predict Feature 1 (will find): **Enjambment overriding line breaks** — because new paradigm replaces metrical closure with syntactic flow across lines.
- Step 3: Predict Feature 2 (will find): **Variable line lengths / visual spacing as rhythm** — because rhythm is now spatial, not temporal-syllabic.
- Step 4: Predict Feature 3 (will NOT find): **End-rhyme scheme (aa, bb or abab)** — because rhyme is an *old* paradigm; new paradigm treats sound patterning as internal, not structural.
- Step 5: Justify each using "प्रतिमान" — old paradigm = Chhayavad's dulcet metres; new paradigm = speech-rhythm, image-sequence, silence as punctuation.

ANSWER:  
**Will find:** (1) Enjambment as primary rhythmic device — the line break does not coincide with syntactic pause, creating a new paradigm of "visual speech-rhythm". (2) Stanzas of unequal length, possibly single-line stanzas — the new paradigm treats white space as a rhythmic unit.  
**Will not find:** A consistent end-rhyme scheme — the old paradigm of "rhyming couplets/quatrains" is explicitly rejected by "नये प्रतिमान"; sound echoes, if any, will be internal/alliterative, not structural.  
DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: A student argues: "The title 'cukjl' is just a setting. The poem could be set in a 'महल' (palace) and the themes would remain the same because universal human emotions don't change with location." Using Ashok Vajpeyi's *Prayovad* context and the metaphorical charge of "cukjl", evaluate this argument. Your answer must reference: (a) the *Prayovad* principle of "भाषा ही अनुभव है" (language *is* experience), (b) the title's semantic field, and (c) one specific image from the poem (describe it without quoting) that *only* works in a cul-de-sac.

COMPETENCY: Defending context-dependent meaning against universalist reduction (Critical Evaluation)

STEPS:
- Step 1: State the core disagreement — In *Prayovad*, setting is not backdrop; it is constitutive of experience. "भाषा ही अनुभव है" means the *words* (including the title) *create* the reality, not label a pre-existing one.
- Step 2: Analyze "cukjl" semantic field — Narrowness, dead-end, accumulation (dust, waste, bodies), no through-traffic, intimate surveillance. A "महल" implies grandeur, openness, display, hierarchy — opposite semantic field.
- Step 3: Identify a cul-de-sac-specific image from the poem — The "dead rat" (मरा हुआ चूहा) lying undisturbed for days, or the "evening" (साँझ) that "sits like a beggar on the steps" — these require *stasis, neglect, containment* impossible in a palace's swept corridors.
- Step 4: Synthesize — Changing setting to "महल" would require changing the poem's entire imagery, syntax, and existential premise. The argument confuses *theme* (alienation) with *embodiment* (how alienation *looks/feels* in a specific material space).
- Step 5: Conclude — The student's view is *New Critical* (text autonomous), but *Prayovad* is *materialist*: the cul-de-sac *is* the poem's grammar.

ANSWER: The argument fails because it treats setting as decorative container rather than generative constraint. (a) *Prayovad*'s axiom "भाषा ही अनुभव है" means the title "cukjl" does not *name* a place; it *enacts* a spatial logic — enclosure, stasis, marginal visibility. (b) The semantic field of "cukjl" (कुचला, संकरी, निकासहीन) produces images of accumulation (कचरा, मरा चूहा, बैठी साँझ) that a "महल" (openness, display, hierarchy) cannot host. (c) The image of the evening sitting "like a beggar on the steps" (सीढ़ियों पर भिखारिन-सी बैठी साँझ) *requires* the cul-de-sac's steps — liminal, domestic, unmonitored. In a palace, evening arrives via chandeliers and courtiers; it does not beg. Therefore, the poem's themes are *inseparable* from its setting; universalism erases the poem's materialist precision.  
DIFFICULTY: hard