## DEFINITION
Literal comprehension questions require answers directly stated in the text, while inferential comprehension questions require drawing conclusions by combining textual evidence with reasoning and background knowledge.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
Student can independently classify any question as literal or inferential, locate exact textual evidence for literal answers, and construct a logical inference chain (claim + evidence + reasoning) for inferential answers that aligns with the author's intent.

## SCOPE_BOUNDARY
Covers distinguishing literal vs. inferential questions, answer-writing structure (PEEL), and applying both to the chapter "Hkkjrh; dyk,¡" (Indian Arts). Does NOT cover critical evaluation of the author's perspective (node 013) or creative writing based on the chapter (node 014).

## WALKTHROUGH
Imagine you're reading a WhatsApp forward claiming "Madhubani paintings only use red and black colours." You instantly know it's false because you remember the text says they use "çkÑfrd jax" (natural colours) including yellow, blue, etc. That's literal comprehension - the answer is right there. Now, if someone asks "Why did folk art survive while classical art needed royal patronage?" - the text never says this directly. You must infer from clues: folk art is linked to "çÑfr vkSj thou" (rituals and life), done by "le`¼" (common people) on walls/floors, while classical art was confined to "jktkvksa vkSj fofHkUu 'kkldksa osQ laj{k.k" (kings and courts). This walkthrough teaches you to spot the difference and write board-level answers using the PEEL method.

## DIAGNOSTIC_QUESTION_1
Identify the question type: "According to the text, what is the 'ukV~;'kkL=k' (Natyashastra) considered for classical dance?" Is this literal or inferential?

## DIAGNOSTIC_ANSWER_1
Literal. The text explicitly states: "ukV~;'kkL=k esa budk 'kkL=kh; Lo:i cuk] tks dyk osQ fy, vc rd dk çkIr lcls egRoiw.kZ 'kkL=k gSA" A wrong answer (inferential) reveals the student confuses "explicitly stated fact" with "needs interpretation" - they may think any question about importance requires inference.

## DIAGNOSTIC_QUESTION_2
Explain in your own words why the author says folk art forms are "yksd ls tqM+h" (connected to folk) even today, using the phrase "thou ls tqM+h" (connected to life) from the text.

## DIAGNOSTIC_ANSWER_2
This is an UNDERSTAND question. Correct answer: Folk arts originate from daily rituals (çÑfr), agricultural cycles (R;ksgkj), and life events (tUeksRlo ls 'kknh&C;kg), so they remain embedded in community life unlike court arts which depended on patronage. A wrong answer that just quotes "thou ls tqM+h" without explaining the *connection* reveals the student cannot paraphrase or see the cause-effect link between origin and survival.

## DIAGNOSTIC_QUESTION_3
APPLY: A board exam asks: "How does the text suggest that the distinction between 'classical' and 'folk' art is blurred in practice?" Write a 2-sentence PEEL answer using textual evidence.

## DIAGNOSTIC_ANSWER_3
Step 1: Identify claim - The boundary is fluid. Step 2: Find evidence - Text says: "'kkL=kh; vkSj yksddykvksa osQ chp dHkh u •Re gksus okyk laokn gh budh rkdr gSA" and "vkt osQ eapksa ;k f-iQYeksa esa tks laxhr ;k u`R; feyrk gS muesa nksuksa dk feyk&tqyk :i vf/d fn•kbZ iM+rk gSA". Step 3: Explain - Continuous interaction (laokn) and mixed presentation in modern media prove the categories aren't rigid. Step 4: Link - Thus, the text portrays them as a spectrum, not binaries. A wrong answer listing separate features of each reveals inability to synthesize evidence for a comparative inference.

## DIAGNOSTIC_QUESTION_4
ANALYZE: Compare the survival mechanisms of folk painting (fp=kdyk) and classical dance (laxhr) as described in the text. What structural difference in their transmission does the author highlight?

## DIAGNOSTIC_ANSWER_4
Folk painting survives through community participation ("le`¼ esa gh xk;k tkrk Fkk", "yksd #fp osQ vuqlkj") and ritual necessity (walls/floors for festivals), making it decentralized. Classical dance survived through codified texts ("ukV~;'kkL=k", "fy•k x;k vkSj ckn esa pydj ,d 'kkL=kh; ijaijk 'kq: gqbZ") and guru-shishya parampara under royal patronage ("jktkvksa osQ laj{k.k"), making it institutionalized. A wrong answer that only describes themes or costumes misses the *transmission structure* (community vs. institution) which is the analytical core.

## DIAGNOSTIC_QUESTION_5
EVALUATE: "The author claims Indian arts give 'mRlkg vkSj fo'okl' (joy and peace) because they are rooted in 'euq"; osQ thou' (inner life)." Do you agree this is the *primary* reason for their global appeal today? Justify using text and outside knowledge.

## DIAGNOSTIC_ANSWER_5
Partially agree. Text supports: "euq"; osQ thou ls tqM+h gksus osQ dkj.k gh ... fojklr osQ çfr gesa mRlkg vkSj fo'okl ls Hkj nsrh gSaA" But global appeal today also stems from aesthetic uniqueness (e.g., Madhubani's geometric patterns, Bharatanatyam's precision) and cultural exoticism - factors the text doesn't claim as primary. A wrong answer that just says "Yes, because text says so" reveals uncritical acceptance; a wrong answer saying "No, it's marketing" ignores textual evidence. Good evaluation balances textual claim with contextual limits.

## DIAGNOSTIC_QUESTION_6
CREATE: Frame one literal and one inferential question *from the perspective of a 10th-century temple sculptor* reading the section on "laxhr dyk" (dance), based only on information in the text.

## DIAGNOSTIC_ANSWER_6
Literal: "What were the two types of dance mentioned in the ancient tradition?" (Text: "ekxhZ rFkk nslh"). Inferential: "If dance moved from temples to courts, did the 'devotional essence' (ekxhZ) get diluted or adapted?" (Requires inferring from "lkeosn es xkus osQ tks funZs'k fn, x, gSa mlls ;g irk pyrk gS fd ... iwtk vkSj ea=kksPpkj osQ rjhosQ dks gh lke dgrs Fks" vs later "orZeku le; esa ... euq"; osQ thou dk T+k:jh vax Fkk"). A poor question pair would be factual recall only or unanswerable from text.

## COMMON_MISCONCEPTION
Students think "inferential" means "guessing" or "giving your opinion." They write answers like "I feel the author thinks folk art is better" without textual evidence. In Class 11 Hindi board exams, inferential answers *must* be grounded in textual clues (words like "vc rd", "bl rjg", "dkj.k", "è;ku nsus dh ckr") and logical connectors (therefore, because, since). The error stems from confusing "inference" (evidence-based conclusion) with "personal response" (subjective feeling).

## ON_FAILURE
1. Give the student a 3-column table: Column A (Text Quote), Column B (What it literally says), Column C (What it implies). 2. Practice with 5 sentences from the chapter (e.g., "dykvksa dk ;g vn~Hkqr lalkj gekjh laLÑfr dh igpku gS" -> Literal: Art is heritage identity. Implied: Losing art = losing cultural identity). 3. Drill the phrase "The text suggests X because it states Y, which implies Z" until they use it automatically.

## BUILDS_ON
Vocabulary in Context (node 010) and Grammar: Language Usage (node 011) - students need word-level precision to distinguish stated vs. implied meaning.

## LEADS_TO
Critical Thinking: Analysis and Interpretation (node 013) - inferential comprehension is the foundation for higher-order critique.

## PREREQUISITE_NODE_IDS
c11_hin_v_cbse_04_001, c11_hin_v_cbse_04_010, c11_hin_v_cbse_04_011, c11_hin_v_cbse_04_005, c11_hin_v_cbse_04_008, c11_hin_v_cbse_04_009

## PREREQUISITE_REASONS
c11_hin_v_cbse_04_001: Context and Background provides the historical/cultural framework needed to make valid inferences about art forms.
c11_hin_v_cbse_04_010: Vocabulary in Context ensures students understand key terms (e.g., 'ukV~;'kkL=k', 'laokn', 'fganqLrkuh') to avoid misreading literal statements.
c11_hin_v_cbse_04_011: Grammar: Language Usage helps identify markers of inference in Hindi (e.g., 'è;ku nsus dh ckr', 'bl rjg', 'dkj.k') vs. markers of fact.
c11_hin_v_cbse_04_005: Comprehension questions frequently ask about specific supporting figures' contributions.  
c11_hin_v_cbse_04_008: Comprehension questions (literal/inferential) require quoting imagery as evidence and interpreting metaphorical meaning.  
c11_hin_v_cbse_04_009: Comprehension questions (literal/inferential) require device-awareness to answer "why did the author phrase it this way?" items.  

## FORWARD_NODE_IDS
c11_hin_v_cbse_04_013, c11_hin_v_cbse_04_014
## FORWARD_REASONS
c11_hin_v_cbse_04_013: Critical Thinking requires the ability to make evidence-based inferences before evaluating the author's perspective.
c11_hin_v_cbse_04_014: Writing Skills answers (analytical paragraphs, essays) depend on the PEEL structure mastered here for inferential questions.

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
none

## CHAIN_DESCRIPTION
c11_hin_v_cbse_04_010 -> c11_hin_v_cbse_04_012 -> c11_hin_v_cbse_04_013

## THIS_FORMULA
PEEL Structure for Inferential Answers: Point (Inference) + Evidence (Text Quote/Paraphrase) + Explanation (Reasoning linking evidence to point) + Link (Connect to broader theme/question)

## FORMULA_VARIABLES
Point = The inferred answer/claim; Evidence = Specific textual reference (line/para concept); Explanation = Logical reasoning showing *how* evidence supports point; Link = Connection to chapter's central idea or question's demand

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
linguistic

## CROSS_SUBJECT
c11_history_indian_culture | Both analyze how art forms reflect social structures (folk vs. elite patronage) and change over time - comprehension skills transfer directly to historical source analysis.
c11_geography_human_geography | Regional art forms (Madhubani, Warli, Kathakali) are tied to specific geographies/climates/agricultural cycles; inferential reading connects cultural practices to environmental determinants.

## PREREQ_CONCEPT
Ability to identify explicit information in a Hindi expository text and recognize cohesive devices (connectors, reference words) that signal author's reasoning.

## PREREQ_BEFORE
Student must be able to summarize each section of the chapter (painting, music, dance) in 2-3 sentences using key terms from the text.

## PREREQ_STUCK
If stuck, review "Vocabulary in Context: Key Words" (node 010) for terms like 'laokn', 'fganqLrkuh', 'ukV~;'kkL=k' and "Grammar: Language Usage" (node 011) for inference markers like 'è;ku nsus dh ckr'.

## WORKED_EXAMPLE_1
PROBLEM: Answer this inferential question in 60 words using PEEL: "The text states classical arts were 'c¡/k' (bound by rules) while folk arts were 'yksd #fp osQ vuqlkj' (according to folk sentiment). What does this imply about the *creative agency* of artists in each tradition?"

STEPS:
- Step 1: Identify the core comparison - creative freedom/constraint in classical vs. folk.
- Step 2: Locate evidence: Classical - "fu;e vkSj vuq'kklu ls c¡/k Fkk", "dykvksa dks lqO;ofLFkr vkSj ifj"Ñr djus osQ fy, çksRlkfgr Hkh djrs jgrs Fks". Folk - "yksd #fp osQ vuqlkj ;g lewg esa gh xk;k tkrk Fkk", "dyk l`tu dks ns•dj vk'p;Z gksrk gSA".
- Step 3: Formulate Point: Classical artists had limited agency within rigid frameworks; folk artists had collective agency within flexible community norms.
- Step 4: Write Explanation: Classical rules (ukV~;'kkL=k) standardized form, requiring mastery of prescribed grammar; folk art's "vk'p;Z" (spontaneous) nature allowed improvisation for ritual function.
- Step 5: Link to theme: This reflects the chapter's central contrast - institutional preservation vs. living tradition.
- Step 6: Check word count and PEEL flow.

REASONING: The inference "creative agency differs" is not stated; it's derived by contrasting "c¡/k" (bound) with "vk'p;Z" (spontaneous/energized) and "çksRlkfgr" (regulated) with "yksd #fp" (collective sentiment). PEEL ensures the answer is analytical, not descriptive.

ANSWER: Classical artists operated within codified rules (ukV~;'kkL=k) and royal regulation ("çksRlkfgr"), limiting individual innovation to mastery of set forms. Folk artists, guided by collective sentiment ("yksd #fp") and ritual need, exercised spontaneous creativity ("vk'p;Z") - adapting forms freely for community function. Thus, classical tradition prioritized preservation through discipline; folk tradition prioritized relevance through flexibility - a core tension in Indian arts' evolution.

## WORKED_EXAMPLE_2
PROBLEM: Literal question: "List the three occasions mentioned in the text when folk paintings are traditionally created." (Answer directly from text, no inference.)

STEPS:
- Step 1: Scan text for "fp=kdyk" section and keywords like "cu", "bUgsa", "ekaxfyd volj".
- Step 2: Extract explicit list: 1) "tUeksRlo" (birth), 2) "'kknh&C;kg" (marriage), 3) "iwtk rFkk •srh&ckM+h" (festivals and harvest).
- Step 3: Verify no other occasions are listed as *traditional* for folk painting (classical painting had court occasions).
- Step 4: Format as bulleted list for board exam clarity.
- Step 5: Ensure Hindi terminology matches text exactly.

REASONING: Literal questions test retrieval accuracy. The text explicitly clusters these three: "tUeksRlo ls ysdj] 'kknh&C;kg] iwtk rFkk •srh&ckM+h ls Hkh tqM+h gSA". No inference needed - just precise extraction.

ANSWER: 1. tUeksRlo (Birth ceremonies) 2. 'kknh&C;kg (Marriage rituals) 3. iwtk rFkk •srh&ckM+h (Festivals and harvest occasions)

## WORKED_EXAMPLE_3
PROBLEM: Combined literal+inferential: "The text says 'Hkkjrh; dykvksa dk foLrkj fo'o osQ vU; Hkw&Hkkxksa esa Hkh gqvk' (Indian arts spread worldwide). Using textual evidence, infer *why* the author believes they retain 'regional specificity' ({ks=kh; fo'ks"krk) despite global spread."

STEPS:
- Step 1: Identify the paradox - global spread vs. local roots.
- Step 2: Find global spread evidence: "Hkkjrh; dykvksa dk foLrkj fo'o osQ vU; Hkw&Hkkxksa esa Hkh gqvk".
- Step 3: Find regional specificity evidence: "mu dykÑfr;ksa osQ l`tu es {ks=kh; fo'ks"krk,¡ gSa", "xka/kj 'kSyh esa cuh cq¼ dh çfrek vkSj frCcr dh 'kSyh esa cuh cq¼ çfrek esa viuh&viuh {ks=kh; igpku Li"V fn•kbZ nsrh gSA".
- Step 4: Find *causal* link in text: "Hkkjrh; dykvksa dks R;ksgkjksa] mRloksa ls vyx ugha fd;k tk ldrkA ;s dyk,¡ tUeksRlo ls ysdj] 'kknh&C;kg] iwtk rFkk •srh&ckM+h ls Hkh tqM+h gSaA".
- Step 5: Synthesize inference: Arts remain region-specific because their *origin and function* are tied to local rituals/agriculture/geography (R;ksgkj, mRlo) - global spread is secondary to this root system.
- Step 6: Write PEEL answer with "è;ku nsus dh ckr" structure.

REASONING: This combines literal retrieval (spread fact, regional fact, ritual link) with inference (ritual link *explains* regional persistence despite spread). The key connector is "dkj.k" (reason) implied by the text's structure.

ANSWER: The author implies regional specificity persists because Indian arts are organically rooted in local "R;ksgkj" (seasons/agriculture) and "mRlo" (customs) - from birth to harvest. Text evidence: "xka/kj 'kSyh ... viuh&viuh {ks=kh; igpku Li"V fn•kbZ nsrh gSa" and "dykvksa dks R;ksgkjksa] mRloksa ls vyx ugha fd;k tk ldrk". Global dissemination ("fo'o osQ vU; Hkw&Hkkxksa") doesn't sever this umbilical cord; the art's *meaning* remains local even if its *form* travels.

## COMPETENCY_QUESTION_1
QUESTION: A Class 11 student writes this answer to an inferential question: "The author thinks folk art is more authentic because it's done by common people." Identify two flaws in this answer relative to board exam expectations, and rewrite it correctly using PEEL with textual evidence.

COMPETENCY: Critical evaluation of answer quality / Application of PEEL structure

STEPS:
- Step 1: Identify Flaw 1 - "Author thinks" is an assumption; answers must use "The text suggests/shows" + evidence.
- Step 2: Identify Flaw 2 - "More authentic" is a value judgment not in text; text contrasts transmission modes, not authenticity hierarchy.
- Step 3: Locate correct evidence: "yksd dykvksa dk laca/ O;olk; ls tqM+k rks O;fDr osaQfær gksrh pyh xb±A" and "'kkL=kh; vkSj yksddykvksa osQ chp ... laokn gh budh rkdr gSA".
- Step 4: Rewrite using PEEL: Point (Text portrays folk art as community-embedded, not individually owned), Evidence (quote above), Explanation (shift from individual to collective creation), Link (shows symbiotic relationship, not superiority).

ANSWER: Flaws: 1) Attributes opinion to author without textual support ("author thinks"). 2) Imposes value hierarchy ("more authentic") absent in text which describes complementary roles. Corrected PEEL: The text suggests folk art's defining feature is its inseparability from community life ("O;olk; ls tqM+k rks O;fDr osaQfær gksrh pyh xb±A"), unlike classical art's individual mastery within codified rules. This is evidenced by folk art's creation "lewg esa" (in collective) per "yksd #fp" rather than for patrons. Thus, the distinction is structural (collective vs. individual agency), not qualitative - both traditions interact continuously ("laokn gh budh rkdr").

DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: Read this unseen excerpt inspired by the chapter: "The Warli painter does not sign her canvas; the wall is her gallery, the harvest festival her deadline. The Kathak dancer signs her lineage (gharana) with every chakkars; the proscenium stage is her court, the grant application her patron." Frame one literal and one inferential question *on this excerpt* that test the *exact same concepts* as the chapter's folk vs. classical contrast. Provide model answers.

COMPETENCY: Transfer of comprehension skills to unseen text / Question design

STEPS:
- Step 1: Map excerpt elements to chapter concepts: Warli = folk painting (community, ritual, unsigned), Kathak = classical dance (gharana/lineage, court/stage, institutional patronage).
- Step 2: Draft literal question targeting explicit fact: "What replaces royal patronage for the modern Kathak dancer according to the excerpt?" (Answer: grant application).
- Step 3: Draft inferential question targeting structural contrast: "How does the excerpt contrast the *accountability* of the folk artist vs. the classical artist?" (Inference: Folk artist accountable to community ritual cycle; classical artist accountable to institutional lineage and funding bodies).
- Step 4: Write model literal answer (direct quote).
- Step 5: Write model inferential PEEL answer linking "harvest festival deadline" (community time) vs "grant application" (bureaucratic time).

ANSWER: Literal Q: "What serves as the deadline for the Warli painter and the patron for the Kathak dancer?" A: Harvest festival (deadline); grant application (patron). Inferential Q: "The excerpt contrasts two types of artistic accountability. Explain." A: The Warli painter is accountable to the community's ritual calendar ("harvest festival her deadline") - her art serves a collective function. The Kathak dancer is accountable to institutional structures ("gharana" lineage, "grant application" funding) - her art sustains a professional lineage. This mirrors the chapter's contrast: folk art's "yksd #fp" vs. classical art's "ukV~;'kkL=k" and "jktkvksa osQ laj{k.k".

DIFFICULTY: hard