## DEFINITION
Plot and narrative structure in an expository text refers to the logical organization of ideas — how the author sequences information (introduction, development, conclusion), uses transitions, and employs structural devices like classification, comparison, or cause-effect to guide the reader's understanding of the central theme.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student can independently identify the macro-structure (introduction-body-conclusion) and micro-structure (paragraph-level organization patterns) of the chapter, explain why the author chose this sequence, and map how each section contributes to the central argument about Indian arts being inseparable from life and culture.

## SCOPE_BOUNDARY
This node covers analyzing the organizational structure of the NCERT expository text "Hkkjrh; dyk,¡" (Chapter 4, Vitan). It does NOT cover fictional plot elements (climax, rising action) or poetic structure. It focuses on expository patterns: classification, chronological development, thematic grouping, and illustrative exemplification.

## WALKTHROUGH
Imagine you're given a jigsaw puzzle without the picture on the box — that's what reading a long expository text feels like without noticing its structure. Start by asking: "What is the author's big claim in the first paragraph?" (Indian arts express life through various mediums). Then scan the subheadings: painting, music, dance, folk arts — each is a category. Notice how within painting, the author moves from prehistoric (Bhimbetka) to folk (Madhubani, Warli) to classical (Mughal, Rajput) — that's chronological within classification. The key insight: structure serves the thesis — the author proves "arts are rooted in life" by showing how every art form emerges from rituals, seasons, and community.

## DIAGNOSTIC_QUESTION_1
What is the primary organizational pattern used in the first section of the chapter (pages 59-60) before the discussion of specific art forms begins?

## DIAGNOSTIC_ANSWER_1
The primary pattern is **general-to-specific (deductive)**. The author opens with a universal claim — all humans express inner experiences through language, painting, music, dance — then narrows to the Indian context: diversity of arts across regions, their connection to rituals/seasons, and their evolution from collective to individual expression. A wrong answer (e.g., "chronological") reveals the student confuses historical timeline with logical exposition; they haven't distinguished between *time order* and *idea hierarchy*.

## DIAGNOSTIC_QUESTION_2
In the painting section (pages 60-63), the author discusses Bhimbetka cave paintings, then Madhubani, Warli, and Mughal/Rajput styles. What structural principle governs this sequence?

## DIAGNOSTIC_ANSWER_2
The sequence follows **chronological development within a classification framework**. The author classifies painting into "prehistoric/folk" and "classical/courtly", then within each, arranges examples chronologically (Bhimbetka → later folk → medieval court styles). A wrong answer ("thematic" or "geographical") shows the student sees isolated examples but misses the meta-pattern: the text demonstrates *evolution* of form while maintaining *cultural continuity* — a key argument for "arts rooted in life".

## DIAGNOSTIC_QUESTION_3
Apply the concept of "transitional signaling" to explain how the author moves from the painting section (ending on page 63) to the music section (starting page 64).

## DIAGNOSTIC_ANSWER_3
The transition uses **parallel structure and thematic echo**: Page 63 ends with "fp=kdyk Hkh yksd ls tqM+h Fkh" (painting was also connected to folk). Page 64 opens "laxhr dyk / Hkkjr osQ çkphure laxhr dk o.kZu..." — mirroring the opening of the painting section ("fp=kdyk / fp=kdkjh çkphu dky ls gh..."). Both start with "ancient origins → folk roots → classical codification". A student who cannot identify this parallelism misses the author's deliberate architectural symmetry across art forms.

## DIAGNOSTIC_QUESTION_4
Analyze why the author places the detailed discussion of *rasa* and *raga* theory (pages 64-65) *after* describing folk music examples (page 64) but *before* discussing dance (page 65).

## DIAGNOSTIC_ANSWER_4
The placement follows **conceptual scaffolding**: folk music (accessible, concrete) → theoretical framework (rasa/raga, abstract) → dance (which *applies* that theory through movement). The author builds the reader's conceptual toolkit before introducing the next art form that depends on it. A wrong analysis (e.g., "random order") reveals inability to see hierarchical dependency between concepts — a critical skill for reading academic texts.

## DIAGNOSTIC_QUESTION_5
Evaluate the effectiveness of the conclusion (page 69) in resolving the structural tension set up in the introduction (page 59).

## DIAGNOSTIC_ANSWER_5
Highly effective. The introduction poses a tension: "Arts express inner life → but are they separate from daily life?" The conclusion resolves it by synthesizing: "All arts emerged from collective life → evolved into classical forms → yet retain folk roots → and remain interconnected (music+dance+painting in festivals)." The circular return to "collective creation" (page 59: "yksd ls gh Fkk") closes the argument. A student calling it "repetitive" fails to recognize *synthesis* as a structural resolution device, not mere repetition.

## DIAGNOSTIC_QUESTION_6
Create a one-paragraph structural outline of the chapter using only these labels: [Thesis], [Category 1: Painting], [Category 2: Music], [Category 3: Dance], [Category 4: Folk Arts], [Synthesis/Conclusion]. Add one transitional phrase between each.

## DIAGNOSTIC_ANSWER_6
[Thesis] **Indian arts are diverse expressions of collective life rooted in rituals and seasons.** → **For instance**, [Category 1: Painting] **traces evolution from Bhimbetka caves through folk (Madhubani, Warli) to court styles (Mughal, Rajput), showing continuity of purpose.** → **Similarly**, [Category 2: Music] **moves from folk instruments to classical raga-rasa theory, illustrating codification without severing folk ties.** → **Likewise**, [Category 3: Dance] **shows classical forms (Bharatanatyam, Kathak) emerging from temple/folk traditions, governed by Natyashastra.** → **Moreover**, [Category 4: Folk Arts] **lists regional forms (Bihu, Garba, Bhangra) as living proof of art-life inseparability.** → **Ultimately**, [Synthesis/Conclusion] **reaffirms that classical and folk are not opposites but a continuum — each art form a thread in India's cultural fabric.**  
A poor outline uses "then, then, then" — revealing additive rather than argumentative structure.

## COMMON_MISCONCEPTION
Students treat "structure" as a list of topics ("first painting, then music, then dance") rather than an *argumentative architecture*. They miss that the author *chooses* this sequence to prove a thesis: each art form follows the same trajectory (folk → classical → modern continuity) to demonstrate unity in diversity. This error stems from middle-school habit of summarizing content instead of analyzing rhetorical design.

## ON_FAILURE
1. Give the student a blank "structure map" template: Thesis → Category 1 (sub-points) → Category 2 (sub-points) → Category 3 (sub-points) → Category 4 (sub-points) → Synthesis.  
2. Ask them to fill *only* the thesis and the *first sub-point* of each category from memory.  
3. Then have them read *only the first and last sentence of each section* to see the parallel trajectory.  
4. Finally, ask: "What single sentence could replace all four category sections?" — forcing abstraction from content to pattern.

## BUILDS_ON
c11_hin_v_cbse_04_001 (Before You Read: Context and Background) — students need the cultural/historical context provided there to recognize why the author structures the argument around rituals, seasons, and collective life.

## LEADS_TO
c11_hin_v_cbse_04_003 (Text: Setting and Atmosphere) — understanding the macro-structure prepares students to analyze how *setting* (ritual space, seasonal time, regional geography) functions as a structural element within each art-form section.

## PREREQUISITE_NODE_IDS
c11_hin_v_cbse_04_001
## PREREQUISITE_REASONS
c11_hin_v_cbse_04_001: Provides essential background on Indian cultural diversity, ritual-art connections, and the folk-classical continuum — without this, students cannot recognize the thesis that the structure proves.

## FORWARD_NODE_IDS
c11_hin_v_cbse_04_003, c11_hin_v_cbse_04_006, c11_hin_v_cbse_04_004, c11_hin_v_cbse_04_005, c11_hin_v_cbse_04_007, c11_hin_v_cbse_04_008, c11_hin_v_cbse_04_009, c11_hin_v_cbse_04_010, c11_hin_v_cbse_04_011, c11_hin_v_cbse_04_013, c11_hin_v_cbse_04_014, c12_hin_a_cbse_09_002

## FORWARD_REASONS
c11_hin_v_cbse_04_003: Setting/atmosphere analysis requires seeing how geographic/seasonal/ritual settings are *structured into* each art-form section (e.g., Warli paintings on harvest walls, Bihu in spring fields).  
c11_hin_v_cbse_04_006: Primary theme ("arts as life-expression") is *constructed* by the narrative structure; you cannot analyze theme without seeing how structure builds it.
c11_hin_v_cbse_04_004: Establishes the chapter's narrative arc (continuity despite change) which is the protagonist's central conflict.  
c11_hin_v_cbse_04_005: Narrative structure awareness helps locate where supporting figures are introduced (e.g., folk arts section vs. classical arts section).  
c11_hin_v_cbse_04_007: Plot/narrative structure knowledge helps trace how themes unfold across the chapter's organization  
c11_hin_v_cbse_04_008: Narrative structure awareness helps locate where devices cluster (e.g., metaphor density in theme articulation sections).  
c11_hin_v_cbse_04_009: Plot and Narrative Structure gives the chronological/historical framework (folk → classical → modern) within which situational irony operates across time.  
c11_hin_v_cbse_04_010: Plot and narrative structure analysis establishes where key words appear in the narrative arc, which is essential because a word's connotation is contextually determined — the same word can carry different connotations at different points in the narrative.  
c11_hin_v_cbse_04_011: Understanding the plot/narrative structure (expository, not narrative) sets expectations for the grammatical register — students must know this is *informational prose* to analyze its syntax appropriately.  
c11_hin_v_cbse_04_013: Narrative structure understanding helps trace the chapter's argumentative architecture  
c11_hin_v_cbse_04_014: Narrative structure awareness helps students organize answers chronologically or thematically.  
c12_hin_a_cbse_09_002: Vitan chapter 4 narrative structure practice.  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
none

## CHAIN_DESCRIPTION
c11_hin_v_cbse_04_001 -> c11_hin_v_cbse_04_002 -> c11_hin_v_cbse_04_003

## THIS_FORMULA
Expository Structure = Thesis Statement + [Parallel Category Development (Classification → Chronology → Theory → Example)] + Synthesis Conclusion

## FORMULA_VARIABLES
Thesis Statement: Central claim (Indian arts express collective life).  
Parallel Category Development: Each art form (painting, music, dance, folk) follows identical sub-sequence: ancient origins → folk diversity → classical codification → modern continuity.  
Classification → Chronology → Theory → Example: Micro-pattern within each category.  
Synthesis Conclusion: Re-integrates categories to prove thesis.

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
analytical

## CROSS_SUBJECT
c11_history_ancient_india | The chapter's chronological layering (Bhimbetka → medieval courts → modern folk) mirrors historical periodization; structure analysis reinforces history skill of identifying continuity/change.  
c11_geography_human_geography | Regional art forms (Madhubani=Bihar, Warli=Maharashtra, Bihu=Assam) are spatially organized; structure reflects geographic distribution — a geographic lens on cultural diffusion.

## PREREQ_CONCEPT
Ability to distinguish *content* (what is said) from *structure* (how it is organized) in non-fiction texts.

## PREREQ_BEFORE
Student must know the chapter's basic subject matter (Indian art forms) and the author's main claim (arts are rooted in collective life/rituals).

## PREREQ_STUCK
If stuck, review the "Before You Read" node (c11_hin_v_cbse_04_001) for the cultural context that makes the structural choices meaningful.

## WORKED_EXAMPLE_1
PROBLEM: Identify the macro-structure of the chapter and explain how the painting section (pages 60-63) exemplifies the parallel category development pattern.  
STEPS:
- Step 1: Read the first paragraph (page 59) and last paragraph (page 69) to isolate the thesis and synthesis. Thesis: "All arts express inner life; Indian arts are diverse but rooted in rituals/seasons." Synthesis: "Arts evolved from collective to classical but remain interconnected and folk-rooted."
- Step 2: List the four major sections between them: Painting (60-63), Music (64-65), Dance (65-66), Folk Arts (66-68). Note each has a bold heading.
- Step 3: Analyze Painting section internally: Opens with "fp=kdyk / fp=kdkjh çkphu dky ls gh..." (ancient origins) → Describes Bhimbetka (prehistoric) → Folk styles: Madhubani, Warli, Mughal/Rajput (historical progression) → Ends with "fp=kdyk Hkh yksd ls tqM+h Fkh" (folk connection).
- Step 4: Map this to the parallel pattern: Ancient origins → Folk diversity → Classical/courtly development → Folk-rooted conclusion. Confirm Music/Dance/Folk sections follow same arc.
- Step 5: Articulate the structural argument: The repetition of this trajectory across four art forms *is* the proof of "unity in diversity" — structure *enacts* the thesis.  
REASONING: This 5-step process moves from global (whole chapter) to local (one section) to comparative (across sections) to meta (why this structure serves the argument) — the core of structural analysis.  
ANSWER: Macro-structure = Thesis → 4 Parallel Categories → Synthesis. Painting section exemplifies parallel development via: (1) Ancient origin claim, (2) Prehistoric example (Bhimbetka), (3) Folk examples (Madhubani, Warli), (4) Classical examples (Mughal, Rajput), (5) Explicit folk-link conclusion. The parallelism across categories constructs the argument that *every* Indian art follows the folk-to-classical continuum.

## WORKED_EXAMPLE_2
PROBLEM: The music section (pages 64-65) inserts a theoretical discussion of *rasa* and *raga* (shlokas from Natyashastra) between folk examples and classical forms. Analyze why this placement is structurally strategic.  
STEPS:
- Step 1: Locate the theoretical passage: Page 64 ends with folk instruments (Bansuri, Shehnai, folk songs). Page 65 begins with "lkfgR;laxhrdykfoghu%..." — a Sanskrit shloka defining music as path to liberation.
- Step 2: Identify the structural function: The theory *bridges* folk practice (experiential, oral) and classical codification (textual, rule-bound). Without it, the jump from "villagers singing Bihu" to "Bharatanatyam's margam" would feel abrupt.
- Step 3: Check the dance section (page 65): It *immediately* references "Natyashastra" and "rasa" — showing the theory introduced in music *applies* to dance. Cross-category scaffolding.
- Step 4: Evaluate alternative placements: If theory came *after* dance, dance would lack foundation. If before folk, it would be too abstract too early. Current placement = "conceptual bridge at point of need."
- Step 5: Generalize: Expository texts often insert theoretical frameworks *between* concrete examples and their formalized extensions — a transferable structural pattern.  
REASONING: This analyzes *micro-structure* (placement of one passage) in service of *macro-coherence* (preparing reader for next category). It teaches students to ask "Why here?" not just "What is here?"  
ANSWER: The rasa/raga theory is placed as a conceptual bridge: it codifies the folk musical experiences just described (giving them terminology) and provides the shared theoretical foundation (Natyashastra) that the subsequent dance section will rely on. This "theory-at-the-hinge" structure ensures conceptual continuity across art-form categories.

## WORKED_EXAMPLE_3
PROBLEM: Compare the structural role of "examples" in the painting section (Madhubani, Warli, Mughal, Rajput) vs. the folk arts section (Bihu, Garba, Bhangra, Chhau). How does the *difference* in exemplification strategy serve the chapter's evolving argument?  
STEPS:
- Step 1: Catalog painting examples: 4 distinct styles, each with historical period, region, technique, and patronage context (e.g., "Mughal: court patronage, Persian influence"). High specificity, art-historical framing.
- Step 2: Catalog folk arts examples: 10+ forms listed rapidly (Bihu, Garba, Bhangra, Chhau, Lavani, etc.) with minimal detail — mostly region + occasion (festival, harvest). Breadth over depth.
- Step 3: Identify the structural shift: Painting section = *depth* (showing evolution within one medium). Folk arts section = *breadth* (showing ubiquity across regions/occasions).
- Step 4: Link to argument arc: Early categories (painting, music, dance) prove *historical depth* of folk-classical continuum. Final category (folk arts) proves *contemporary pervasiveness* — arts are alive *everywhere* now.
- Step 5: Synthesize: The exemplification strategy *changes* to match the argument's phase: from "arts have deep roots" (painting/music/dance) to "arts are everywhere today" (folk arts). Structure adapts to rhetorical need.  
REASONING: This advanced analysis requires comparing exemplification *across* categories and linking form to rhetorical function — a board-level competency (evaluating author's craft).  
ANSWER: Painting uses *deep, historicized examples* to demonstrate evolution over centuries; folk arts uses *broad, enumerative examples* to demonstrate pan-Indian vitality today. The shift from depth to breadth mirrors the chapter's argumentative movement: first establishing historical legitimacy of the folk-classical continuum, then proving its living presence across the subcontinent. The structure *performs* the argument.

## COMPETENCY_QUESTION_1
QUESTION: The chapter uses a "parallel category" structure where painting, music, dance, and folk arts each follow a similar internal sequence. Explain how this structural choice supports the author's central thesis about Indian culture. Provide two specific textual evidences from different categories.  
COMPETENCY: Analyzing author's structural choices in service of theme (CBSE Competency: Literary Analysis / Critical Thinking)  
STEPS:
- Step 1: State the thesis: Indian arts are diverse expressions of a shared cultural root (collective life, rituals, seasons).
- Step 2: Identify the parallel sequence: Each category moves from ancient/folk origins → historical development → classical codification → explicit folk-continuity statement.
- Step 3: Evidence 1 (Painting): "lcls çkphu fp=kksa osQ uewus 'kSy fp=kksa dks gh ekuk tkrk gS" (earliest paintings are folk) → ends "fp=kdyk Hkh yksd ls tqM+h Fkh" (painting also connected to folk).
- Step 4: Evidence 2 (Music): Folk instruments (Bansuri, Shehnai) → Raga/Rasa theory (Natyashastra) → Classical forms (Hindustani/Carnatic) → "laxhr Hkh yksd ls tqM+h Fkh" (music also connected to folk).
- Step 5: Conclude: The repetition of this arc across four domains *enacts* "unity in diversity" — structure *is* the argument.  
ANSWER: The parallel structure proves the thesis by demonstration: every art form, regardless of medium, follows the same folk-to-classical trajectory while retaining folk roots. Painting shows it via Bhimbetka→Madhubani→Mughal→folk-link; Music shows it via folk instruments→Natyashastra theory→classical gharanas→folk-link. The structure doesn't just *describe* unity — it *performs* it.  
DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: A student claims: "The folk arts section (pages 66-68) breaks the parallel structure because it lacks historical depth and theoretical framework — it's just a list." Critique this claim using structural analysis. Is the student correct? Why or why not?  
COMPETENCY: Evaluating structural coherence and rhetorical strategy (CBSE Competency: Critical Evaluation / Argument Analysis)  
STEPS:
- Step 1: Acknowledge surface validity: Folk arts section *does* lack historical timeline and shloka-based theory — it's enumerative.
- Step 2: Analyze its structural *position*: It is the *final* category before synthesis. Its role is not to show evolution (already done 3x) but to show *saturation* — arts are everywhere, now.
- Step 3: Identify its internal logic: Grouped by *occasion/function* (harvest: Bihu, Pongal; worship: Garba, Chhau; martial: Gatka; seasonal: Lohri) — a *thematic* classification replacing *chronological* one.
- Step 4: Link to synthesis (page 69): The list enables the conclusion's claim: "lHkh yksd u`R;ksa esa ,d xksykbZ esa urZd gkFk..." (all folk arts share a rhythm of collective creation). The list *is* the evidence for that claim.
- Step 5: Verdict: The student confuses *uniformity* with *parallelism*. Parallelism means *functional equivalence* in the argument, not identical sub-components. The folk section's difference *is* its structural purpose.  
ANSWER: The student is incorrect. The folk arts section *fulfills* the parallel structure by shifting exemplification strategy from "historical depth" (proven in prior sections) to "contemporary breadth." Its thematic classification (by occasion/season) and enumerative density serve the argument's final phase: proving the *ubiquity* of art-life connection today. The synthesis paragraph (page 69) explicitly draws on this list ("lHkh yksd u`R;ksa esa..."). Structural analysis asks "What work does this part do?" not "Does it look the same?"  
DIFFICULTY: hard