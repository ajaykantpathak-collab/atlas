## DEFINITION
Critical thinking in literary analysis involves examining a text beyond its literal meaning to evaluate the author's choices, underlying themes, character motivations, social commentary, and the effectiveness of literary techniques in conveying meaning.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
Student can independently analyze a passage from "Ud ka Nankshik" to identify underlying themes, evaluate character decisions, interpret Premchand's social commentary, and support interpretations with specific textual evidence.

## SCOPE_BOUNDARY
Covers analysis of themes, character motivations, author's craft, and social commentary in "Ud ka Nankshik" (The Construction of a Hospital). Does not cover basic comprehension (node c11_hin_ar_cbse_01_012) or creative writing based on the chapter (node c11_hin_ar_cbse_01_014).

## WALKTHROUGH
Imagine you're reading a news report about a government hospital project where funds were misused. You don't just note what happened—you ask: Why did the system fail? Who benefited? What does this reveal about our institutions? That's critical thinking. In Premchand's story, we do the same: we don't just follow the plot, we examine why Dr. Vyaksihnhu fails, what the hospital construction symbolizes, and what Premchand is saying about society. First, identify the central conflict between idealism and bureaucracy. Then trace how characters represent larger social forces. Finally, connect the author's choices to his message about integrity in a corrupt system.

## DIAGNOSTIC_QUESTION_1
What is the central conflict in "Ud ka Nankshik" between Dr. Vyaksihnhu and the bureaucratic system represented by Aakhaji?

## DIAGNOSTIC_ANSWER_1
The central conflict is between Dr. Vyaksihnhu's idealistic commitment to genuine service and the corrupt bureaucratic system represented by Aakhaji that prioritizes formal procedures and personal gain over actual human welfare. A wrong answer (e.g., "it's about building a hospital" or "they dislike each other") reveals the student only grasps plot events, not the ideological clash driving the narrative. The conflict is structural: one character embodies service as moral duty, the other embodies office as opportunity for extraction.

## DIAGNOSTIC_QUESTION_2
Explain in your own words why Dr. Vyaksihnhu ultimately resigns and leaves, despite his dedication to the hospital project.

## DIAGNOSTIC_ANSWER_2
Dr. Vyaksihnhu resigns because he realizes the system is structurally incapable of genuine service—his idealism cannot survive in a framework where corruption is normalized and human dignity is secondary to procedure. His departure is not defeat but a refusal to compromise his integrity. A wrong answer focusing only on "he was insulted" or "he lost authority" shows the student misses the philosophical dimension of his choice. The resignation is a deliberate moral act: he denies the system his complicity, exposing its hollowness by withdrawing the only thing of value he had to offer—his honest labor.

## DIAGNOSTIC_QUESTION_3
Apply the concept of dramatic irony to analyze the scene where Aakhaji claims "the government is you and me" while actually protecting his own interests. How does this irony reveal the story's theme?

## DIAGNOSTIC_ANSWER_3
Step 1: Identify the ironic statement—Aakhaji says "government is you and me" implying shared responsibility and partnership. Step 2: Identify the reality—Aakhaji uses state resources for personal comfort (government bungalow, servants, influence for his son). Step 3: Explain the gap—his words mask self-interest as public duty; the collective "we" excludes the actual public. Step 4: Connect to theme—this irony exposes how bureaucratic language disguises exploitation, a core theme of the story. A wrong answer that only defines irony without applying it to this specific scene shows inability to transfer the concept to textual analysis.

## DIAGNOSTIC_QUESTION_4
Compare the two father figures in the story—Dr. Vyaksihnhu's father (mentioned briefly) and Aakhaji as a father to his son. How do their parenting approaches reflect the story's larger value conflict?

## DIAGNOSTIC_ANSWER_4
Dr. Vyaksihnhu's father valued education and principle over comfort (letting his son struggle rather than compromise), shaping his son's integrity. Aakhaji uses his position to secure his son's future through corruption (getting him a job through influence), teaching him that connections matter more than competence. This contrast mirrors the central conflict: principle vs. pragmatism, service vs. self-interest. A wrong answer that treats them as merely "different parenting styles" misses how they embody the story's ideological battle. The fathers represent two competing models of inheritance: one passes moral capital, the other passes corrupt privilege.

## DIAGNOSTIC_QUESTION_5
Critique the story's ending: Is Dr. Vyaksihnhu's resignation a moral victory or a practical failure? Defend your position with textual evidence.

## DIAGNOSTIC_ANSWER_5
It is a moral victory because he preserves his integrity and exposes the system's hollowness—his final letter naming corrupt officials is an act of resistance. However, it's a practical failure as the hospital remains in corrupt hands. The story suggests moral victories matter more in a corrupt world—his departure inspires the narrator (and readers) to value conscience over compromise. A one-sided answer ("it's a failure because he left" or "it's a victory because he stood tall") shows inability to hold nuanced evaluation. Premchand's realism demands recognizing both: the system survives, but its moral legitimacy is shattered.

## DIAGNOSTIC_QUESTION_6
Write a diary entry from Aakhaji's perspective the night Dr. Vyaksihnhu resigns, revealing his true thoughts about "duty," "service," and the young doctor's idealism.

## DIAGNOSTIC_ANSWER_6
A strong entry would show Aakhaji's self-justification ("I'm practical, he's naive"), perhaps a flicker of unease about his son's future in this system, and bureaucratic language masking greed. It should capture his voice—formal, self-serving, dismissive of idealism as "impractical." A weak entry makes him a cartoon villain or suddenly guilt-ridden, missing Premchand's nuanced portrayal of corruption as banal and self-rationalizing. The best answers reveal how Aakhaji truly believes he is the sensible one—corruption, to him, is just "how things work."

## COMMON_MISCONCEPTION
Students often think "critical analysis" means finding faults with the story or criticizing characters' decisions. They write "Dr. Vyaksihnhu was wrong to resign because he abandoned the patients" instead of analyzing WHY the author wrote it that way and WHAT it reveals about society. This error comes from confusing "critical" (as in negative judgment) with "critical thinking" (as in deep examination). For example, a student might say "The story is unrealistic because no doctor would just leave" missing that Premchand uses this to make a point about systemic corruption forcing out honesty. The task is not to judge the character but to interpret the author's design.

## ON_FAILURE
1. Clarify the meaning of "critical" in academic context—it means analytical, not negative.
2. Model the difference: Show a "criticism" ("I didn't like the ending") vs. "critical analysis" ("The ending serves to highlight the impossibility of integrity in a corrupt system").
3. Practice with a familiar text (e.g., a well-known movie scene)—ask "What is the filmmaker trying to say?" not "Was this a good decision?"
4. Return to the story with the frame: "What is Premchand revealing about society through this character's choice?" Use the PEEL structure: Point, Evidence, Explanation, Link to theme.

## BUILDS_ON
Literal and inferential comprehension (node c11_hin_ar_cbse_01_012)—students must first understand what happens before analyzing why and what it means.

## LEADS_TO
Writing skills based on the chapter (node c11_hin_ar_cbse_01_014)—critical analysis provides the content and depth for analytical writing tasks.

## PREREQUISITE_NODE_IDS
c11_hin_ar_cbse_01_001, c11_hin_ar_cbse_01_002, c11_hin_ar_cbse_01_004, c11_hin_ar_cbse_01_006, c11_hin_ar_cbse_01_008, c11_hin_ar_cbse_01_009, c11_hin_ar_cbse_01_012, c11_hin_ar_cbse_01_005, c11_hin_ar_cbse_01_007, c11_hin_ar_cbse_01_010, c11_hin_ar_cbse_01_011

## PREREQUISITE_REASONS
c11_hin_ar_cbse_01_001: Context/background knowledge essential for interpreting social commentary
c11_hin_ar_cbse_01_002: Plot understanding needed before analyzing structure and meaning
c11_hin_ar_cbse_01_004: Protagonist analysis provides foundation for evaluating his choices
c11_hin_ar_cbse_01_006: Primary theme identification needed for deeper thematic analysis
c11_hin_ar_cbse_01_008: Imagery/metaphor recognition enables analysis of author's craft
c11_hin_ar_cbse_01_009: Irony/symbolism understanding required for interpreting key scenes
c11_hin_ar_cbse_01_012: Literal/inferential comprehension is the base for critical analysis
c11_hin_ar_cbse_01_005: Critical thinking questions require multi-character comparative analysis.  
c11_hin_ar_cbse_01_007: Critical thinking requires synthesizing multiple thematic threads into an interpretive argument — this node provides the thematic inventory and tracing method.  
c11_hin_ar_cbse_01_010: Critical interpretation of authorial stance (e.g., Premchand's use of *veys* vs. *mazdur*) depends on connotative precision.  
c11_hin_ar_cbse_01_011: Grammar: की समझ आवश्यक है, क्योंकि यह नोड (Critical thinking in literary analysis involves examining a text beyond its literal meanin...) इसी आधार पर आगे बढ़ता है।  

## FORWARD_NODE_IDS
c11_hin_ar_cbse_01_014, c11_hin_ar_cbse_01_015, c12_hin_a_cbse_01_013, c12_hin_a_cbse_04_013, c12_hin_a_cbse_06_013, c12_hin_a_cbse_07_013, c12_hin_a_cbse_08_013, c12_hin_a_cbse_09_013, c12_hin_a_cbse_10_013, c12_hin_a_cbse_12_013, c12_hin_a_cbse_17_001, c12_hin_a_cbse_17_013, c12_hin_al_cbse_01_013, c12_hin_al_cbse_02_013, c12_hin_al_cbse_03_013, c12_hin_ar_cbse_02_013, c12_hin_ar_cbse_03_013, c12_hin_ar_cbse_10_013

## FORWARD_REASONS
c11_hin_ar_cbse_01_014: Critical analysis provides evidence and arguments for analytical writing tasks
c11_hin_ar_cbse_01_015: Interpretive insights fuel meaningful discussion and debate
c12_hin_a_cbse_01_013: Class 11 critical thinking skills transfer to Class 12 complexity  
c12_hin_a_cbse_04_013: Class 11 critical thinking foundation — ensures the student has practiced the analysis→interpretation→evaluation pipeline on simpler texts.  
c12_hin_a_cbse_06_013: Class 11 critical thinking foundation — introduces evidence–claim–warrant model.  
c12_hin_a_cbse_07_013: Class 11 critical thinking foundation for poem analysis methodology  
c12_hin_a_cbse_08_013: Earliest exposure to analysis framework (context, device, theme, interpretation).  
c12_hin_a_cbse_09_013: Class 11 Critical Thinking introduced the 5-step method; this node deepens it for Board-level rigor.  
c12_hin_a_cbse_10_013: Class 11 critical thinking foundation — analyzing autobiographical voice in 'Namak Ka Daroga'.  
c12_hin_a_cbse_12_013: Class 11 Critical Thinking established the basic framework (claim-evidence-reasoning) which this node deepens for a more complex text.  
c12_hin_a_cbse_17_001: Class 11 Critical Thinking for Namak ka Daroga — trains the analytical skill of linking textual evidence to philosophical argument, required for Mishra's essay.  
c12_hin_a_cbse_17_013: Class 11 critical thinking practice on similar essays builds analytical habits.  
c12_hin_al_cbse_01_013: Class 11 critical thinking practice establishes the analytical mindset.  
c12_hin_al_cbse_02_013: Introduced basic critical thinking terminology (theme, perspective, irony) in Class 11 Antra Chapter 1.  
c12_hin_al_cbse_03_013: Class 11 critical thinking practice establishes the analytical framework (evidence -> reasoning -> claim).  
c12_hin_ar_cbse_02_013: Class 11 critical thinking foundation (PEEL structure, device-to-theme linking) is the direct pedagogical precursor.  
c12_hin_ar_cbse_03_013: अगला तार्किक चरण: Critical Thinking: इस नोड की अवधारणाओं को सीधे उपयोग/विस्तारित करता है।  
c12_hin_ar_cbse_10_013: Established the PEEL structure and summary-vs-analysis distinction; this node assumes that foundation.  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
none

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_01_012 -> c11_hin_ar_cbse_01_013 -> c11_hin_ar_cbse_01_014

## THIS_FORMULA
N/A - conceptual

## FORMULA_VARIABLES
N/A

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
analytical

## CROSS_SUBJECT
c11_history_colonialism | The story reflects colonial-era bureaucracy and its continuation in post-colonial India—connects to history of administrative systems
c11_civics_public_administration | Aakhaji represents bureaucratic corruption and the gap between policy and implementation—connects to civics concepts of accountability and governance
c11_economics_corruption | The hospital construction scandal illustrates resource misallocation and rent-seeking behavior—connects to economics of corruption

## PREREQ_CONCEPT
Students must understand the difference between literal comprehension (what happens) and critical analysis (why it matters and what it reveals).

## PREREQ_BEFORE
Students should have completed basic comprehension of the story including plot, characters, and explicit themes.

## PREREQ_STUCK
Review the distinction between "what the text says" vs "what the text means" using a simple fable or news article before returning to the story.

## WORKED_EXAMPLE_1
PROBLEM: Analyze how Premchand uses the hospital building itself as a symbol throughout the story. What does its changing state represent?

STEPS:
- Step 1: Identify all references to the hospital building in the story—its planned grandeur, the construction process, the corruption in materials, the final incomplete state.
- Step 2: Note the contrast between the intended purpose (healing, service) and the reality (corruption, neglect, personal gain).
- Step 3: Connect the building's physical state to the moral state of the system—foundation compromised by corruption, structure weakened by greed, completion delayed by self-interest.
- Step 4: Analyze the ending—the building stands but is hollow, mirroring a system that maintains appearance while losing its soul.
- Step 5: Synthesize—the hospital symbolizes the nation's public institutions: meant for service, captured by corruption, structurally compromised.

REASONING: This analysis moves from concrete textual details to abstract symbolic meaning, showing how physical objects carry thematic weight in Premchand's realism.

ANSWER: The hospital building symbolizes public institutions in a corrupt system. Its planned grandeur represents idealistic goals; the substandard materials and delayed construction represent systemic corruption; its incomplete yet standing state at the end represents institutions that maintain facade while losing purpose. Dr. Vyaksihnhu's departure leaves the building physically present but morally empty—just like the system.

## WORKED_EXAMPLE_2
PROBLEM: Examine the role of education in the story. How do different characters' attitudes toward education reveal the story's critique of the colonial education system?

STEPS:
- Step 1: Identify all references to education—Dr. Vyaksihnhu's Western education, his father's sacrifices for it, Aakhaji's view of education as job qualification, the clerk's limited literacy, the villagers' reverence for "padhe-likhe" (educated) people.
- Step 2: Contrast Dr. Vyaksihnhu's education (liberal arts, critical thinking, moral formation) with the utilitarian view (degree as ticket to government job).
- Step 3: Analyze the irony—Dr. Vyaksihnhu's "useless" humanities education gives him conscience; the "practical" administrative education produces corrupt officials.
- Step 4: Connect to the father's statement about "padhai-likhai" being a burden—education without values creates clever criminals, not good citizens.
- Step 5: Evaluate Premchand's position—he critiques colonial education that produces clerks for empire, not citizens for society; true education must build character.

REASONING: This traces a motif across multiple characters and connects it to the author's broader social critique, demonstrating how thematic analysis works across the whole text.

ANSWER: Education in the story operates on two levels: as moral formation (Dr. Vyaksihnhu's father's vision) and as career credential (Aakhaji's view). The tragedy is that the system rewards the latter. Premchand critiques colonial education that severed learning from values—producing officials who can administer but not serve. Dr. Vyaksihnhu's "impractical" idealism comes from the very humanities education the system dismisses.

## WORKED_EXAMPLE_3
PROBLEM: Compare and contrast the two confrontations between Dr. Vyaksihnhu and Aakhaji (the first meeting in the office, and the final confrontation before resignation). How does the power dynamic shift, and what does this reveal about the nature of resistance in a corrupt system?

STEPS:
- Step 1: Analyze the first confrontation—Aakhaji holds institutional power, Dr. Vyaksihnhu appeals to rules and ideals, Aakhaji dismisses him with bureaucratic language and veiled threats.
- Step 2: Analyze the final confrontation—Dr. Vyaksihnhu now holds moral authority, speaks plain truth, names corruption directly, Aakhaji is reduced to threats and pleas.
- Step 3: Identify the shift—from institutional power vs. idealistic appeal to moral authority vs. defensive corruption.
- Step 4: Note the language change—Aakhaji uses formal bureaucratic Hindi initially; Dr. Vyaksihnhu uses direct, simple language finally.
- Step 5: Connect to the story's view on resistance—direct moral confrontation exposes corruption but cannot defeat it structurally; the system survives but loses legitimacy.
- Step 6: Evaluate the cost—Dr. Vyaksihnhu wins the argument but loses his position; the system wins the battle but loses moral claim.

REASONING: This comparative analysis shows how character dynamics enact thematic arguments, and how the author structures confrontations to reveal systemic truths.

ANSWER: The first confrontation shows institutional power crushing idealism through procedure. The final confrontation shows moral truth exposing institutional hollowness. The shift reveals Premchand's insight: in a corrupt system, integrity cannot win on the system's terms—it can only refuse to play, thereby exposing the game. Dr. Vyaksihnhu's resignation is not defeat but a different kind of victory—he denies the system his complicity.

## COMPETENCY_QUESTION_1
QUESTION: In the story, the narrator says about Dr. Vyaksihnhu: "He was a big man, but his bigness was not of the kind that the world recognizes." Analyze this statement in light of the story's ending. What definition of "greatness" does Premchand propose through this character?

COMPETENCY: Literary analysis—interpreting author's thematic statement through character arc

STEPS:
- Step 1: Identify the two definitions of "bigness" in the story—worldly success (position, money, influence) vs. moral stature (integrity, courage, service).
- Step 2: Trace how Dr. Vyaksihnhu embodies the second throughout—refusing bribes, treating poor patients, confronting corruption.
- Step 3: Analyze the ending—he loses worldly position but gains moral completeness; the narrator (and reader) recognizes his true stature.
- Step 4: Connect to Premchand's humanist philosophy—true greatness lies in moral courage, not social status.

ANSWER: Premchand redefines greatness as moral integrity that refuses compromise. Dr. Vyaksihnhu's "bigness" is his unwavering conscience—he treats the poor equally, rejects corruption, and ultimately chooses unemployment over complicity. The world (Aakhaji, the system) sees him as a failure; the narrator (Premchand's voice) sees him as the only true success. The story proposes that in a corrupt society, the "great" are those who refuse to be corrupted.

DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: The story presents multiple "fathers"—Dr. Vyaksihnhu's biological father, Aakhaji as father to his son, and Dr. Vyaksihnhu as a father-figure to the narrator. Analyze how these three father-son relationships form a thematic argument about inheritance—what is passed down, and what is the cost of each inheritance?

COMPETENCY: Comparative thematic analysis—tracing a motif across character relationships

STEPS:
- Step 1: Map the three relationships—(1) Dr. Vyaksihnhu's father: sacrifices for son's education, passes values of integrity and service. (2) Aakhaji: uses corruption to secure son's job, passes privilege without merit. (3) Dr. Vyaksihnhu and narrator: intellectual/moral mentorship, passes critical consciousness.
- Step 2: Identify what each inherits—Dr. Vyaksihnhu inherits conscience (cost: material struggle); Aakhaji's son inherits position (cost: moral bankruptcy); narrator inherits critical vision (cost: disillusionment with system).
- Step 3: Analyze the pattern—biological inheritance (Aakhaji) perpetuates corruption; value-based inheritance (Dr. Vyaksihnhu's father) perpetuates resistance; chosen inheritance (narrator) perpetuates witness.
- Step 4: Evaluate Premchand's argument—the story suggests true inheritance is not biological or institutional but moral; the narrator becomes the true "son" of Dr. Vyaksihnhu by carrying his witness forward.
- Step 5: Connect to the title "Ud ka Nankshik"—the hospital is a failed institutional inheritance; the real construction is of character.

ANSWER: The three father-son pairs represent three types of inheritance: Aakhaji passes corrupt privilege (systemic continuity); Dr. Vyaksihnhu's father passes principled struggle (moral continuity); Dr. Vyaksihnhu passes critical witness to the narrator (intellectual continuity). The story argues that in a corrupt system, the only meaningful inheritance is moral—the narrator's transformation into a witness is the true "construction" the title ironically references. Each inheritance has a cost: corruption costs the soul; principle costs comfort; witness costs innocence.

DIFFICULTY: hard