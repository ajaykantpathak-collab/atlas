## DEFINITION
Imagery (चित्रात्मकता) is the use of vivid, sensory language that appeals to the five senses (sight, sound, touch, taste, smell) to create mental pictures and evoke physical sensations in the reader. Metaphor (रूपक/उपमा) is a figure of speech that directly equates two unlike things by stating one *is* the other (without using 'like' or 'as'), transferring qualities from the vehicle (source) to the tenor (target) to reveal a hidden similarity. In this chapter, both devices transform factual descriptions of art forms into immersive aesthetic experiences.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student can independently identify at least three distinct sensory images and two metaphors in the chapter, explain the specific sensory appeal of each image, and articulate how the metaphor reshapes the reader's understanding of the art form by transferring specific qualities from vehicle to tenor.

## SCOPE_BOUNDARY
This node covers identification, classification (visual, auditory, tactile, olfactory, gustatory, kinesthetic), and functional analysis of imagery and metaphor *specifically within the NCERT text "Hkkjrh; dyk,¡"* (pages 59-70). It does not cover simile (explicit comparison using 'like/as'), personification, or other tropes addressed in node c11_hin_v_cbse_04_009, nor does it require analysis of devices in external poems or prose.

## WALKTHROUGH
Imagine you are scrolling through a travel blog about the Ajanta caves. The blogger doesn't just say "the paintings are old"; they write "the walls breathe with the breath of centuries, their colors whispering stories of monks and merchants." You instantly *feel* the cool dampness, *hear* the silence, *see* the faded ochre. That is imagery and metaphor at work. In this chapter, the author uses similar language to make Indian arts tangible. Begin by reading the section on "fp=kdyk" (painting) on page 60-62. Underline every phrase that makes you see a color, hear a sound, feel a texture, or sense movement. Then ask: "Is the author describing the art literally, or saying the art *is* something else?" For instance, when the text says cave paintings are "thou dh jkstekZ dh xfrfof/;k¡" (expressions of life's vitality), it equates static pigment on rock with dynamic living energy. That is a metaphor. The key insight: imagery builds the sensory world; metaphor builds the conceptual bridge between the art object and its cultural soul.

## DIAGNOSTIC_QUESTION_1
Define 'imagery' (चित्रात्मकता) and 'metaphor' (रूपक) precisely as used in literary analysis. Give one example of each from the "fp=kdyk" (painting) section of the chapter (pages 60-62) without quoting the text verbatim; describe the passage location instead.

## DIAGNOSTIC_ANSWER_1
**Correct Answer:** Imagery is language appealing to the senses (e.g., the description of "xq-iQkvksa esa thou dh jkstekZ dh xfrfof/;k¡" on page 61 creates visual and kinesthetic images of dynamic life force). Metaphor is an implicit equation (e.g., calling cave paintings "dyk l`tu dh vfr çkphu ijaijk" on page 61 equates paintings with primordial artistic instinct).  
**Wrong Answer Reveals:** If the student gives only a visual example for imagery, they hold the misconception that imagery = only visual description. If they confuse metaphor with simile (looking for 'like/as'), they haven't grasped the direct equation nature of metaphor.

## DIAGNOSTIC_QUESTION_2
The text states: "fp=kdkjh çkphu dky ls gh gekjs thou dk vfHkUu vax jgk gSA" (Painting has been an integral expression of our life since primitive times). Is this a metaphor? Explain why or why not by identifying the tenor and vehicle. If it is not a metaphor, what device is it?

## DIAGNOSTIC_ANSWER_2
**Correct Answer:** This is **not a metaphor**; it is a **literal statement** (or metonymy at most). Tenor = painting; Vehicle = "integral expression of life". The verb "is" (implicit in "gh gSA") links them as a factual claim about history/function, not an imaginative transfer of qualities. A metaphor would be "Painting *is* the heartbeat of civilization."  
**Wrong Answer Reveals:** If the student calls it a metaphor because "painting" and "life" are different domains, they confuse *association* with *equation*. They miss that metaphor requires the vehicle to *become* the tenor imaginatively, not just be related to it.

## DIAGNOSTIC_QUESTION_3
Apply the concept of 'kinesthetic imagery' (गति/स्पर्श सम्बन्धी चित्रात्मकता) to the description of "vtark dh xq-iQk,¡" (Bhimbetka cave paintings) on page 62. Identify two specific phrases (describe location) that evoke bodily movement or physical sensation, and explain the sensation each evokes.

## DIAGNOSTIC_ANSWER_3
**Correct Answer:**  
1. "bu fp=kksa esa thou dh jkstekZ dh xfrfof/;k¡" (p.61) → evokes sensation of pulsing, expanding energy in the viewer's own muscles.  
2. "fp=k osQ ekè;e ls lkaLÑfrd vkSj ,sfrgkfld dFkkvksa dks vfHkO;Dr fd;k tkrk gSA" (p.63) → evokes tactile sensation of tracing narrative lines with fingertips, feeling the flow of story.  
**Steps:** Locate Bhimbetka section → scan for verbs/adjectives of motion/touch/pressure → map to bodily sensation.  
**Wrong Answer Reveals:** If the student picks only color words ("xk;d", "dkys", "uhys"), they conflate kinesthetic with visual imagery. They need to distinguish *seeing* motion from *feeling* motion.

## DIAGNOSTIC_QUESTION_4
Analyze the extended metaphor in the "laxhr dyk" (music) section (pages 64-66) where Indian classical music is linked to "lkfgR;laxhrdykfoghu% lk{kkRi'kq% iqPNfo"kk.kghu%" (Sanskrit verse: music leads to liberation, the performer becomes one with the listener). How does this metaphor transform the technical description of "oh.kk" (swara), "lqj/rky" (rhythm/tempo), and "jkx" (raga) into a spiritual experience?

## DIAGNOSTIC_ANSWER_4
**Correct Answer:** The metaphor equates musical performance (tenor) with yogic union/moksha (vehicle). Technical terms become spiritual stages: "oh.kk" (note) → breath/prana; "lqj/rky" (rhythm) → heartbeat/cosmic cycle; "jkx" (raga) → emotional landscape mapped to time. The metaphor transfers qualities of *transcendence, discipline, unity* onto mere acoustics, forcing the reader to perceive a raga not as a scale but as a path to "foghu" (liberation).  
**Wrong Answer Reveals:** If the student only explains the Sanskrit verse meaning without linking each technical term to a transferred quality, they treat the metaphor as decoration, not a structural mapping that reorganizes the reader's perception.

## DIAGNOSTIC_QUESTION_5
Evaluate the effectiveness of the olfactory/gustatory imagery in the "u`R; dyk" (dance) section (pages 66-68). The text describes folk dances linked to seasons, harvest, and rituals (e.g., "ck¡l u`R;", "Øk-ÝV dyk"). Does the *absence* of explicit smell/taste words weaken the sensory immersion, or does the metaphorical language compensate? Justify with two textual references.

## DIAGNOSTIC_ANSWER_5
**Correct Answer:** The absence is compensated by **synesthetic metaphor**.  
1. "gkFkksa dh fofHkUu eqæk,¡ ... euq"; osQ Hkkoksa ls ysdj tkuojksa osQ Hkkoksa rd" (p.68) maps dance movements (visual/kinesthetic) directly to emotions (internal sensation) and spiritual states (transcendent), bypassing smell/taste.  
2. "bUgha Hkko&Hkafxekvksa osQ tfj;s egkHkkjr vkSj jkek;.k tSlh dFkkvksa rd dks dg nsus dh ijaijk u`R; dyk esa feyrh gSA" (p.68) equates dance gestures with epic narratives, making the *taste* of heroism and *scent* of devotion metaphorically present.  
The metaphor "dance = embodied prayer" fills the sensory gap more powerfully than literal description could.  
**Wrong Answer Reveals:** If the student says "it weakens immersion because we can't smell the harvest," they treat imagery as a checklist of five senses rather than a holistic evocation. They miss that metaphor *creates* sensory experience cross-modally.

## DIAGNOSTIC_QUESTION_6
Create a 4-line free-verse poem (in Hindi or English) that uses **both** a metaphor equating an Indian art form from the chapter to a natural force (river, fire, wind, mountain) **and** at least two distinct sensory images (not both visual) to convey the metaphor. Do not name the art form; let the images and metaphor reveal it.

## DIAGNOSTIC_ANSWER_6
**Expected Criteria:**  
- Clear metaphor: Art form *is* natural force (e.g., "Kathak is a river...").  
- Two+ sensory images: e.g., auditory ("ghungroo's silver rain"), tactile ("soles burning on centuries"), kinesthetic ("spinning into vortex").  
- Art form identifiable implicitly (e.g., ghungroo, chakkars, taal → Kathak).  
**Poor Answer Reveals:** If the poem uses simile ("dance *like* a river"), the student hasn't internalized metaphor's direct equation. If all images are visual ("colors swirl"), they haven't grasped multisensory imagery. If the art form is unidentifiable, the metaphor lacks concrete grounding in the chapter's specifics.

## COMMON_MISCONCEPTION
Students believe **imagery is only "visual description" (chitra varnan)** and **metaphor is just "fancy comparison" (sundar tulna)**. They underline adjectives like "sundar" (beautiful), "praachin" (ancient), "vishal" (huge) as imagery, and label any sentence with "is" linking two nouns as metaphor (e.g., "Bharatanatyam is a dance form"). This stems from middle-school worksheets that treat imagery = adjectives and metaphor = "X is Y" pattern matching, ignoring sensory modality and the *transfer of qualities* that defines metaphor. In this chapter, the author writes "vtark dh xq-iQkvksa osQ fp=k brus vkd"kZd gSa fd os vkt rd osQ dykdkjksa ij xgjk vlj Mkyrs gSa" (Bhimbetka paintings are so powerful they influence artists today). A student may call "vkd"kZd" (powerful) imagery and "influence artists" a metaphor, missing that the *real* imagery is in the preceding description of pigments ("xk;d, dkys, uhys jax") and the *real* metaphor is "paintings = living ancestors guiding present hands."

## ON_FAILURE
1. **Sensory Sort Drill:** Give the student 10 phrases from the chapter (e.g., "oh.kk ki madhur taan", "ghungroo ki jhankar", "mitti ki sondhi gandh", "chakkars ka bhavar", "raga ka samay"). Have them sort into 6 sensory columns (Visual, Auditory, Tactile, Olfactory, Gustatory, Kinesthetic). Discuss why "praachin" fits none.  
2. **Metaphor Surgery:** Take a literal sentence: "Madhubani painting uses natural colors." Convert to metaphor step-by-step: (a) Identify target quality (organic connection to earth). (b) Choose vehicle (tree roots). (c) Write equation: "Madhubani *is* the tree's roots painting the sky." (d) Verify: does "roots" transfer *nourishment, hidden depth, inevitable growth*? If yes, metaphor works.  
3. **Transfer Map:** For the chapter's central metaphor "Art = Life's Pulse" (p.61), draw a two-column map: Left column = qualities of "pulse" (rhythmic, vital, invisible but felt, connects whole body). Right column = qualities of "art" mapped from left. Student must fill right column using text evidence. This makes the *mechanism* of metaphor visible.

## BUILDS_ON
c11_hin_v_cbse_04_003 (Text: Setting and Atmosphere) — because atmosphere is built through imagery, and setting details often become metaphorical vehicles.

## LEADS_TO
c11_hin_v_cbse_04_009 (Literary Devices: Irony and Symbolism) — because symbolism extends metaphor (a symbol *is* a sustained metaphor), and irony often subverts the expectations set by imagery.

## PREREQUISITE_NODE_IDS
c11_hin_v_cbse_04_001, c11_hin_v_cbse_04_002, c11_hin_v_cbse_04_003, c11_hin_v_cbse_04_004, c11_hin_v_cbse_04_005, c11_hin_v_cbse_04_006, c11_hin_v_cbse_04_007
## PREREQUISITE_REASONS
c11_hin_v_cbse_04_001: Context/background knowledge needed to understand cultural references that become metaphorical vehicles (e.g., "ukV~;'kkL=k", "yksd dyk").
c11_hin_v_cbse_04_002: Narrative structure awareness helps locate where devices cluster (e.g., metaphor density in theme articulation sections).
c11_hin_v_cbse_04_003: Setting/atmosphere analysis directly trains sensory detection — the prerequisite skill for imagery identification.
c11_hin_v_cbse_04_004: Protagonist's perspective (if any) often filters imagery; understanding character voice prevents misattribution.
c11_hin_v_cbse_04_005: Supporting characters/voices may introduce distinct metaphorical frameworks (folk vs classical).
c11_hin_v_cbse_04_006: Primary theme ("unity in diversity of arts") is the *target domain* for the chapter's major metaphors.
c11_hin_v_cbse_04_007: Secondary themes (ritual, seasonality, transmission) provide the *source domains* for metaphors (e.g., harvest → dance).

## FORWARD_NODE_IDS
c11_hin_v_cbse_04_009, c11_hin_v_cbse_04_012, c11_hin_v_cbse_04_013, c11_hin_v_cbse_04_014, c12_hin_a_cbse_04_008, c12_hin_a_cbse_05_008

## FORWARD_REASONS
c11_hin_v_cbse_04_009: Irony and symbolism are higher-order tropes that build on mastery of imagery (symbol = image with sustained reference) and metaphor (irony often inverts a metaphor).
c11_hin_v_cbse_04_012: Comprehension questions (literal/inferential) require quoting imagery as evidence and interpreting metaphorical meaning.
c11_hin_v_cbse_04_013: Critical analysis demands evaluating *how* imagery/metaphor construct the chapter's argument about Indian arts.
c11_hin_v_cbse_04_014: Writing skills (analytical paragraph, essay) require embedding device analysis using PEEL structure taught here.
c12_hin_a_cbse_04_008: Metaphor of cage — structural metaphor like "vkèkk".  
c12_hin_a_cbse_05_008: Links metaphor to argumentative structure.  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
none

## CHAIN_DESCRIPTION
c11_hin_v_cbse_04_003 -> c11_hin_v_cbse_04_008 -> c11_hin_v_cbse_04_009

## THIS_FORMULA
N/A - conceptual

## FORMULA_VARIABLES
N/A

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
conceptual

## CROSS_SUBJECT
c11_history_ancient_india | The chapter's metaphors (e.g., cave paintings as "primordial instinct", dance as "embodied epic") mirror historians' interpretive frameworks: material culture as window into cognitive world. Analyzing these metaphors trains the same skill as evaluating historical narratives.
c11_geography_cultural_landscape | Regional art forms (Madhubani, Warli, Bhimbetka) are geographically situated. Imagery of "mitti ki gandh", "monsoon rhythms", "mountain echoes" reflects human-environment interaction — core geography concept. Device analysis reveals how landscape shapes aesthetic expression.
c11_civics_cultural_diversity | The chapter's central metaphor "unity in diversity" (fofo/rk gekjh igpku) is a constitutional value (Art. 29, 51A(f)). Dissecting how imagery of distinct arts (painting, music, dance) are woven into a single narrative teaches civic interpretation of cultural policy texts.

## PREREQ_CONCEPT
Sensory literacy: the ability to distinguish seeing, hearing, touching, smelling, tasting, and moving sensations in language — developed in Class 9-10 poetry analysis (e.g., "Meghdoot" imagery).

## PREREQ_BEFORE
Student must be able to read a Hindi descriptive passage and highlight at least five phrases that evoke a physical sensation (not just an idea), labeling each with its sense modality.

## PREREQ_STUCK
Review Class 10 Hindi (Kshitij/Kritika) poetry imagery exercises — specifically the "chitratmakta" (imagery) questions in NCERT solutions for poems like "Utsaah" or "Atmaparichay".

## WORKED_EXAMPLE_1
PROBLEM: Analyze the imagery in the paragraph describing "mM+hlk osQ iVfp=k" (Mughal miniature painting) on page 63. The text mentions "dkxT+k ;k iÙkksa ij xgjs yky] dkys] uhys jaxksa ls mosQjrs gSaA" and "xhrxksfoan osQ inksa dks urZd vksfM+'kh u`R; osQ ekè;e ls Hkh vfHkO;Dr djrs gSaA". Identify three distinct sensory images, classify each by modality, and explain how together they construct the *atmosphere* of the miniature workshop.
STEPS:
- Step 1: Locate the Mughal miniature paragraph (page 63, lines 3-6). Isolate descriptive phrases: "yky] dkys] uhys jax" (colors), "xgjs" (verb: painted/rendered), "urZd vksfM+'kh u`R; osQ ekè;e" (through classical dance gestures).
- Step 2: Classify each by sensory modality: "yky] dkys] uhys jax" → Visual (hue, saturation); "xgjs" → Kinesthetic/Tactile (brush movement, pressure on surface); "urZd vksfM+'kh u`R;" → Kinesthetic + Visual (body posture, gesture frozen in pigment).
- Step 3: Analyze interaction: Visual colors provide the *palette*; kinesthetic brushwork provides the *process*; dance-gesture imagery provides the *grammar* of form. The workshop atmosphere becomes a hybrid space where painting *dances*.
- Step 4: Connect to chapter theme: This multisensory fusion exemplifies "lHkh dyk,¡ ,d nwljs ls tqM+h gqbZ gaSA" (all arts are interconnected) — the central thesis. The imagery *enacts* the theme rather than just stating it.
- Step 5: Verify: Does the analysis cover at least three modalities? Yes (Visual, Kinesthetic, Tactile implied). Does it link to atmosphere? Yes — the workshop feels alive, rhythmic, choreographed.
REASONING: This example moves beyond listing images to showing how their *modality mix* creates a specific atmospheric effect (synesthetic workshop) that advances the chapter's argument about inter-arts unity.
ANSWER: The three images are: (1) Visual — "yky, dkys, uhys jax" (red, black, white pigments) establishing the material palette; (2) Kinesthetic/Tactile — "xgjs" (rendered/applied) evoking the brush's drag, pressure, and rhythm on wasli paper; (3) Kinesthetic/Visual — "urZd vksfM+'kh u`R;" (classical dance gestures) mapping bodily movement onto painted figures. Together they construct an atmosphere where the painter's hand *dances*, the colors *breathe*, and the miniature becomes a frozen performance — embodying the chapter's claim that Indian arts share a common "ukV~;'kkL=k" (grammar).

## WORKED_EXAMPLE_2
PROBLEM: The text states: "laxhr Hkkjr osQ çkphure laxhr dk o.kZu oSfnd dky esa feyrk gSA" (Indian music's description found in Vedic period). Later: "laxhr Hkh yksd ls tqM+k FkkA blesa laLdkjxhr vkSj Írqxhr Hkh •wc feyrs gSaA" (Music was also connected to folk; included classical and folk). Identify the **metaphor** that structures the entire "laxhr dyk" section (pages 64-66). Map the source domain (vehicle) and target domain (tenor), list three specific mappings (e.g., source: "time of day" → target: "raga"), and explain how this metaphor organizes the reader's understanding of Indian music's evolution.
STEPS:
- Step 1: Read the full music section (pp.64-66) looking for a sustained comparison. The key is the Sanskrit verse: "lkfgR;laxhrdykfoghu% lk{kkRi'kq% iqPNfo"kk.kghu%" — music as path to liberation (moksha) where performer and listener become one.
- Step 2: Identify Tenor (Target) = Indian Classical Music (system, practice, experience). Vehicle (Source) = Yogic Spiritual Discipline / Moksha Marga (path to liberation).
- Step 3: Extract three mappings from text: (a) "oh.kk" (swara/note) → "prana" (breath/life force) — implied by "oh.kk ij igq¡p xb±" (music reaches the swara). (b) "lqj/rky" (laya/tala) → "cosmic rhythm/heartbeat" — implied by "jkx vkSj dky ls lac¼" (raga connected to time/season). (c) "jkx" (raga) → "emotional-spiritual state mapped to time" — explicit in "czãeqgqrZ eas HkSjo] es?k jkx dk laca/ lqcg ls".
- Step 4: Analyze organizational function: This metaphor transforms a technical history (Vedic → Prabandha → Dhrupad → Khayal) into a *spiritual genealogy*. The "rules" (fu;e, vuq'kklu) become "disciplines" (sadhana); "folk connection" becomes "accessibility of the path"; "instrument-body unity" ("phT+ksa gekjs vkl&ikl osQ jksT+kejkZ") becomes "embodied practice".
- Step 5: Evaluate effect: The reader doesn't just learn music history; they *experience* music as sadhana. The metaphor makes the foreign (ancient technical system) familiar (universal spiritual quest).
- Step 6: Check against text: Does the text support "performer = listener = one"? Yes: "lk{kkr fcuk iw¡N osQ i'kq osQ leku gksrk gS" (performer becomes equal to listener without effort).
REASONING: This worked example demonstrates *extended metaphor analysis* — a board-level skill. It requires tracing a single vehicle across multiple textual segments, mapping specific technical terms to abstract qualities, and evaluating the metaphor's rhetorical work.
ANSWER: The governing metaphor is **INDIAN CLASSICAL MUSIC IS A YOGIC PATH TO LIBERATION (MOKSHA MARGA)**. Tenor = Music system/practice; Vehicle = Spiritual discipline (Sadhana). Three mappings: 1. Swara (note) → Prana (breath/essential vibration) — "oh.kk ij igq¡p". 2. Tala/Laya (rhythm) → Cosmic cycle/Heartbeat — "jkx vkSj dky ls lac¼". 3. Raga (melodic framework) → Time-bound emotional-spiritual state — "czãeqgqrZ eas HkSjo". This metaphor organizes the section by reframing historical evolution (Vedic → Khayal) as progressive revelation of the path, technical rules as yogic disciplines, and folk-classical continuum as exoteric-esoteric unity. The reader grasps music not as entertainment but as *spiritual technology*.

## WORKED_EXAMPLE_3
PROBLEM: Compare the **metaphorical logic** in two passages: (A) "fp=kdkjh çkphu dky ls gh gekjs thou dk vfHkUu vax jgk gSA" (Painting = integral expression of life, p.60) and (B) "u`R; dks ns•dj dqN yksx ,slk lksprs gSa fd ;g fl-iZQ gkFk vkSj iSj dh xfr ls tqM+k gSA" (Some think dance = mere limb movement, p.68). The author *rejects* (B) and *affirms* a corrected metaphor for dance. Identify the author's positive metaphor for dance (find it on p.68), contrast its vehicle with (B)'s vehicle, and explain how the shift in vehicle changes the *epistemological status* of dance (i.e., what kind of knowledge dance becomes).
STEPS:
- Step 1: Locate the author's positive metaphor for dance on page 68. Text: "Hkkjrh; u`R; dk lcls vkd"kZd :i gS&& gkFkksa dh fofHkUu eqæk,¡ ... euq"; osQ Hkkoksa ls ysdj tkuojksa osQ Hkkoksa rd" (The most powerful form of Indian dance = diverse body movements... conveying emotions to spiritual states). Also: "bu 'kkL=kh; u`R;ksa es eq[;:i ls osQjy dk dFkdfy] eksfguhvêðe] mÙkj çns'k dk dRFkd..." (classical dances: Odissi = devotional poetry, Kathakali = epic enactment, etc.).
- Step 2: Formulate the positive metaphor: **INDIAN CLASSICAL DANCE IS AN EMBODIED LANGUAGE OF THE SOUL (SHARIRIK BHAVA-BHASHA)**. Vehicle = Language/Communication system (with vocabulary = gestures, grammar = natyashastra, semantics = bhava/rasa). Tenor = Dance.
- Step 3: Contrast vehicles: (B) Vehicle = "fl-iZQ gkFk vkSj iSj dh xfr" (mere physical movement/mechanics). Author's Vehicle = "Hkko&Hkafxek" (emotion-expression) → "tkuoj" (spiritual states) → "dFkdfy/dRFkd" (poetic/epic narrative).
- Step 4: Analyze epistemological shift: (B) makes dance **procedural knowledge** (knowing *how* to move limbs — kinesthetic skill). Author's metaphor makes dance **interpretive/embodied knowledge** (knowing *what* the gesture means, *how* it carries narrative, *why* it elevates). Dance becomes a *text* to be read, a *scripture* to be embodied.
- Step 5: Link to imagery: The author supports this metaphor with kinesthetic imagery ("gkFkksa dh fofHkUu eqæk" — diverse limb movements) and auditory imagery ("osQjy dk dFkdfy" — Odissi's poetic rhythm) showing dance *as* language in action.
- Step 6: Board-exam application: A question "How does the author redefine dance?" requires this exact contrast: from physical exercise to semantic-spiritual practice, evidenced by the shift from "gkFk/iSj" imagery to "Hkko/tkuoj" metaphor.
REASONING: This example combines metaphor identification, vehicle analysis, and epistemological evaluation — the highest-order skill for Class 12 board "analysis and interpretation" questions. It uses the chapter's explicit rebuttal structure to teach critical reading of metaphorical argumentation.
ANSWER: The author's positive metaphor: **DANCE = EMBODIED SEMANTIC SYSTEM (LANGUAGE OF BHAAVA/RASA)**. Vehicle: Language/Narrative/Scripture (gestures = words, sequences = sentences, performance = recitation). Contrast: Misconception (B) uses Vehicle = **Biomechanics** (limbs/joints = levers/hinges). Epistemological shift: Biomechanics → Dance as *craft/skill* (procedural knowledge, observable, measurable). Language/Scripture → Dance as *knowledge tradition* (interpretive, intergenerational, truth-bearing). The shift elevates dance from "physical education" to "liberal art" — exactly the chapter's project of establishing "ukV~;'kkL=k" (grammar) for all arts. The imagery of "gkFkksa dh eqæk" (limb movements) serves the *new* metaphor by showing the *vocabulary* of this language, not the mechanics of a machine.

## COMPETENCY_QUESTION_1
QUESTION: The chapter describes "vtark dh xq-iQk,¡" (Bhimbetka cave paintings) as having "thou dh jkstekZ dh xfrfof/;k¡" (expressions of life's vitality) and "dyk l`tu dh vfr çkphu ijaijk" (primordial instinct of art creation). A student writes: "The author uses imagery to show the paintings are old and metaphor to say they are like instinct." Critique this student's answer using the concepts of sensory modality and metaphorical mapping. What two specific corrections would you give?
COMPETENCY: Critical evaluation of peer analysis / Metacognitive correction
STEPS:
- Step 1: Identify the student's two claims: (a) "imagery shows paintings are old" (b) "metaphor says they are like instinct".
- Step 2: Evaluate claim (a): "thou dh jkstekZ dh xfrfof/;k¡" evokes *vitality, energy, pulsation* (kinesthetic/visual), not "oldness" (temporal). "Old" is a fact; "vitality" is a sensory experience. Correction 1: Imagery here creates *living presence*, not antiquity.
- Step 3: Evaluate claim (b): "dyk l`tu dh vfr çkphu ijaijk" is a **metaphor** (Painting *is* primordial instinct), not a simile ("like instinct"). The vehicle "primordial instinct" transfers qualities: *innate, universal, pre-linguistic, survival-driven*. "Like instinct" weakens the equation to comparison. Correction 2: Metaphor = direct equation ("is"), not comparison ("like"); it makes painting the *embodiment* of instinct.
- Step 4: Synthesize feedback: The student reduces imagery to information-conveying and metaphor to decoration. Both devices here *constitute* the author's argument: art is not old object but living force.
ANSWER: The student's answer contains two fundamental errors. First, they misread the imagery: "thou dh jkstekZ dh xfrfof/;k¡" (expressions of life's vitality) deploys **kinesthetic and visual imagery** (pulsing energy, dynamic forms) to make the paintings feel *alive now*, not merely *old then*. Imagery here creates sensory immediacy, not historical distance. **Correction 1:** "The imagery evokes living vitality (kinesthetic pulse), not antiquity." Second, they misidentify the metaphor: "dyk l`tu dh vfr çkphu ijaijk" (primordial instinct of art creation) is a **direct metaphor** (Painting *is* primordial instinct), not a simile ("like instinct"). The vehicle "primordial instinct" transfers qualities of *innateness, universality, pre-conscious drive* onto painting, making art a biological-cosmic imperative. **Correction 2:** "Metaphor equates painting with instinct ('is'), transferring innate/universal qualities; it does not merely compare ('like')." Together, these devices argue that Indian art is a living, instinctual force — not a museum artifact.
DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: The chapter's final paragraph (p.69) states: "lHkh yksd u`R;ksa esa ,d xksykbZ esa urZd gkFk es gkFk feyk, rjg&rjg osQ djrc fn•krs gSaA ... ;gh dkj.k gS fd ;gk¡ dh dykvksa dk eqjhn vkt iwjk fo'o gSA" (In all folk dances, primal rhythm resonates in every limb... that is why these arts resonate globally today). Using the concepts of **kinesthetic imagery** and **extended metaphor**, explain how the author transforms "folk dance" from a *regional cultural practice* into a *universal human language*. Your answer must: (i) identify the extended metaphor's vehicle, (ii) quote/describe two kinesthetic images that enact this metaphor, (iii) explain the "primal rhythm" (urZd gkFk) as a metaphorical bridge, and (iv) conclude why this matters for the chapter's global claim.
COMPETENCY: Synthetic analysis / Argument construction / Evidence-based interpretation
STEPS:
- Step 1: Identify the extended metaphor vehicle: **FOLK DANCE = PRIMAL RHYTHM / UNIVERSAL HEARTBEAT**. The text: "urZd gkFk" (primal rhythm), "gkFkksa dh fofHkUu eqæk" (diverse limb movements), "viuh vki esa Hkkjr dh vn~Hkqr lkgp;Z vkSj çseHkkouk" (India's unity and harmony in their own body).
- Step 2: Select two kinesthetic images: (a) "gkFkksa dh fofHkUu eqæk,¡ ... euq"; osQ Hkkoksa ls ysdj tkuojksa osQ Hkkoksa rd" (diverse limb movements conveying emotions to spiritual states) — evokes *muscle tension, flow, weight shift* as semantic units. (b) "iatkc dh efgyk,¡ fxík djrh gSaA jktLFkkuh efgyk,¡ viuh vks<+uh ls psgjs dks <ad dj ?kwej djrh gSa" (Assam women sway; Rajasthan women spin veils) — evokes *swaying torque, centrifugal force, fabric resistance* — distinct regional kinetics unified by "gkFk".
- Step 3: Explain "urZd gkFk" as bridge: It is the **metaphorical invariant** — the constant (rhythm) across variables (regional forms). Just as DNA is the invariant across bodies, "primal rhythm" is the invariant across dances. It maps *biological rhythm* (heartbeat, breath, circadian) → *cultural rhythm* (taal, laya, cyclical time). This makes every folk dance a "dialect" of a single "language" (the metaphor from Worked Example 3).
- Step 4: Connect to global claim: If dance = universal rhythm, then *any* human body can "read" it. The global resonance ("eqjhn vkt iwjk fo'o") is not exotic appeal but *kinesthetic recognition* — the viewer's own "urZd gkFk" resonates. The chapter thus argues Indian folk arts are not "local heritage" but "human birthright".
ANSWER: The author employs the extended metaphor **FOLK DANCE = PRIMAL RHYTHM (UNIVERSAL HEARTBEAT)**. Vehicle = "urZd gkFk" (primal rhythm) — the biological-metaphysical pulse underlying all movement. Two kinesthetic images enact this: (1) "gkFkksa dh fofHkUu eqæk,¡ ... euq"; osQ Hkkoksa ls ysdj tkuojksa osQ Hkkoksa rd" — the dancer's limbs become syntax, their tension/release carrying meaning from emotion to transcendence; the viewer *feels* the grammar in their own muscles. (2) "iatkc dh efgyk,¡ fxík djrh gSa... jktLFkkuh efgyk,¡ viuh vks<+uh ls psgjs dks <ad dj ?kwej djrh gSa" — the sway of Bihu and spin of Ghoomar evoke distinct regional kinetics (torque, centrifugal pull, fabric drag) yet both manifest the same "gkFk". "UrZd gkFk" functions as the metaphorical bridge: it is the **invariant deep structure** (like DNA) across the **surface variations** (regional styles). It maps biological rhythm (heartbeat, breath) onto cultural rhythm (taal, cyclical time), making every folk dance a dialect of a single embodied language. This matters because the global claim ("eqjhn vkt iwjk fo'o") rests not on exoticism but on **kinesthetic universality** — the viewer's own primal rhythm recognizes its kin. The chapter thus repositions Indian folk arts from "cultural property" to "human inheritance."
DIFFICULTY: hard