## DEFINITION
Character analysis of the protagonist involves systematically examining the central figure's personality traits, motivations, internal conflicts, relationships, and development across the narrative, using direct textual evidence (actions, speech, thoughts, authorial description) to support inferences about their role in advancing the theme.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student can write a structured 150-200 word character sketch of Jaishankar Prasad (the protagonist) that identifies at least four distinct personality traits, supports each with specific textual evidence from the essay, explains how the narrator's perspective shapes the portrayal, and connects the character to the chapter's central theme of literary dedication.

## SCOPE_BOUNDARY
This node covers ONLY the protagonist Jaishankar Prasad as portrayed in Dr. Nagendra's memoir "Izse?ku dh Nk;k Le`fr". It does NOT cover supporting characters (narrator, Mrs. Prasad, narrator's father), plot structure, themes, or literary devices — those are addressed in sibling nodes.

## WALKTHROUGH
Imagine you are writing a reference letter for a literary giant like Jaishankar Prasad — what specific incidents would you cite to prove his greatness? Start by listing every direct description of Prasad in the text: his physical appearance (rare), his daily habits (writing at night, morning walks), his interactions (with the narrator, his wife, other writers), and his values (simplicity, generosity, linguistic purity). Notice how the narrator's childhood admiration colors the portrayal. The key insight: Prasad emerges not through grand declarations but through quiet, consistent actions — like refusing to move his dying wife's bed or writing in "ehjtkiqj" script to make Hindi accessible — revealing a character defined by humility and mission-driven purpose.

## DIAGNOSTIC_QUESTION_1
Identify the narrator of the essay "Izse?ku dh Nk;k Le`fr" and state his relationship to the protagonist Jaishankar Prasad.

## DIAGNOSTIC_ANSWER_1
The narrator is Dr. Nagendra (the essayist), who recounts his childhood and youthful encounters with Jaishankar Prasad. He is an admiring observer and junior contemporary, not a peer. A wrong answer (e.g., "Prasad is the narrator") reveals confusion between the subject of a memoir and its author — a critical error because the entire portrayal is filtered through the narrator's selective memory and reverence.

## DIAGNOSTIC_QUESTION_2
Explain in your own words why the narrator describes Prasad's house as having a "kh?kz xgjh eS=kh" (extremely simple atmosphere) despite Prasad's literary fame.

## DIAGNOSTIC_ANSWER_2
The simplicity reflects Prasad's values: he prioritized literary creation over material display. The narrator contrasts the modest downstairs room (where Prasad worked) with the grandeur expected of a "mahakavi," showing Prasad's humility. A wrong answer focusing only on poverty ("he was poor") misses the deliberate choice — Prasad could have earned more but chose austerity, which the narrator admires as integral to his literary integrity.

## DIAGNOSTIC_QUESTION_3
The text states Prasad wrote in "ehjtkiqj" (Devanagari) instead of the prevalent "ukxjh" (Kaithi) script. Apply the concept of "character through choice" to explain what this decision reveals about Prasad's personality and mission.

## DIAGNOSTIC_ANSWER_3
Step 1: Identify the choice — Prasad deliberately used Devanagari for Hindi when Kaithi was the official script. Step 2: Note the narrator's explanation: Prasad believed "the script developed by educated people becomes the script of the language." Step 3: Infer traits — visionary (saw Devanagari as Hindi's future), principled (rejected convenience for principle), nation-building mindset (linked script to identity). Step 4: Connect to broader characterization — this aligns with his simple lifestyle and dedication to Hindi's elevation. A wrong answer treating this as mere personal preference misses its symbolic weight in the narrator's portrayal of Prasad as a language architect.

## DIAGNOSTIC_QUESTION_4
Analyze how the narrator uses the episode of Prasad's dying wife (Mrs. Prasad) and the unmoved bed to reveal Prasad's character. Compare this with the narrator's description of Prasad's generosity toward struggling writers.

## DIAGNOSTIC_ANSWER_4
Both episodes reveal Prasad's emotional depth and selflessness but in different registers. The bed episode shows private grief transformed into respect: he refuses to disturb her final resting place, revealing tenderness and ritualistic devotion. The generosity episode (giving money to writers secretly) shows public compassion without ego. Together, they create a consistent portrait: Prasad's actions — whether in intimate sorrow or public duty — stem from an inner moral compass, not social performance. A wrong answer treating them as separate anecdotes fails to synthesize them into a unified character trait: "quiet, principle-driven humanity."

## DIAGNOSTIC_QUESTION_5
Evaluate the narrator's claim that Prasad's "fpÙkkd"kZd fp=k.k" (heart-stirring portrayal) emerges from the "vn~Hkqr feJ.k" (intense tension) between "izse" (literature) and "oqQrwgy" (domesticity). Is this tension the core of Prasad's characterization in the essay? Defend your view with evidence.

## DIAGNOSTIC_ANSWER_5
Yes, the tension is central. Evidence: Prasad writes masterpieces at night while managing household chaos by day; he hosts literary giants in a cramped home; his wife's illness and death occur alongside his creative peak. The narrator explicitly states this tension created the "intense atmosphere" from which great literature emerged. However, a nuanced evaluation notes the narrator *romanticizes* this tension — he doesn't fully explore the cost to Mrs. Prasad (a supporting character). A wrong answer accepting the narrator's view uncritically misses the essay's subtle gender dynamics; a strong answer acknowledges the narrator's bias while affirming the tension as the essay's structural device for character revelation.

## DIAGNOSTIC_QUESTION_6
Create a 50-word "literary resume" for Jaishankar Prasad based solely on the narrator's direct descriptions in the essay. Include: one physical detail, two personality traits with evidence, one literary principle, and one legacy.

## DIAGNOSTIC_ANSWER_6
*Physical:* "lM+d ij dbZ pDdj" (beard on face) — only direct physical marker. *Traits:* (1) Simplicity — worked in a modest downstairs room despite fame; (2) Generosity — secretly funded struggling writers. *Principle:* "ukxj viHkza'k ls tks f'k"V yksxksa dh Hkk"kk fodflr gqbZ] ogh ukxjh dgykbZ" — championed Devanagari as the people's script. *Legacy:* Established Hindi's modern literary standard; inspired the narrator's lifelong devotion. A poor answer invents details not in the text (e.g., "tall, wore khadi") or omits evidence citations.

## COMMON_MISCONCEPTION
Students conflate the *narrator's admiration* with *objective character traits*, writing "Prasad was great because the narrator says so" instead of extracting evidence of *what Prasad did* that earned that admiration. They also ignore the narrator's selective memory — e.g., describing Prasad's "simple room" but not his professional networks — treating the portrayal as transparent reality rather than a constructed literary image. This leads to vague, hagiographic answers that lose board marks for lack of textual anchoring.

## ON_FAILURE
1. Re-read the essay marking every sentence where Prasad *acts* or *speaks* (not where the narrator praises him). 2. Categorize these into: habits, decisions, interactions, crises. 3. For each category, write one trait + one quote. 4. Re-attempt Diagnostic Question 4 using only this evidence table. 5. If still stuck, revisit c11_hin_ar_cbse_01_004 (Class 11 Protagonist Analysis) for the evidence→trait→theme scaffold.

## BUILDS_ON
Class 11 character analysis (c11_hin_ar_cbse_01_004) which introduced the trait-evidence-explanation structure; this node deepens it by adding narrator-perspective critique and thematic linking.

## LEADS_TO
Supporting character analysis (c12_hin_a_cbse_10_005) where the same evidence-based method is applied to Mrs. Prasad and the narrator's father, then to theme nodes where character insights feed thematic arguments.

## PREREQUISITE_NODE_IDS
c12_hin_a_cbse_10_001, c12_hin_a_cbse_10_002, c12_hin_a_cbse_10_003, c11_hin_ar_cbse_01_004
## PREREQUISITE_REASONS
c12_hin_a_cbse_10_001: Provides biographical context of Prasad's era and the narrator's background essential for interpreting character motivations.
c12_hin_a_cbse_10_002: Establishes the memoir's narrative structure (chronological vs. thematic) which determines how character is revealed across episodes.
c12_hin_a_cbse_10_003: Sets the physical/cultural atmosphere (Kashi, literary circles, domestic space) that shapes Prasad's characterization.
c11_hin_ar_cbse_01_004: Introduces the foundational character analysis framework (traits, evidence, development) this node extends with narrator-perspective complexity.

## FORWARD_NODE_IDS
c12_hin_a_cbse_10_005, c12_hin_a_cbse_10_006, c12_hin_a_cbse_10_013, c12_hin_a_cbse_10_007, c12_hin_a_cbse_10_012, c12_hin_a_cbse_10_014

## FORWARD_REASONS
c12_hin_a_cbse_10_005: Supporting characters (Mrs. Prasad, narrator's father) are analyzed using the same evidence-based method established here.
c12_hin_a_cbse_10_006: Primary theme (literary dedication vs. domestic life) is argued through protagonist's character traits proven in this node.
c12_hin_a_cbse_10_013: Critical interpretation questions (e.g., "Is the narrator reliable?") require the protagonist analysis as evidentiary base.
c12_hin_a_cbse_10_007: Protagonist analysis shows how Shukla ji's consciousness is the lens through which secondary themes are experienced.  
c12_hin_a_cbse_10_012: Protagonist's traits (author's evolving identity) are the subject of most inferential questions.  
c12_hin_a_cbse_10_014: Character Analysis: Protagonist (Prasad) supplies the core personality traits and defining incidents needed for character-sketch answers  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
N/A

## CHAIN_DESCRIPTION
c12_hin_a_cbse_10_003 -> c12_hin_a_cbse_10_004 -> c12_hin_a_cbse_10_005

## THIS_FORMULA
N/A - conceptual

## FORMULA_VARIABLES
N/A

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
analytical

## CROSS_SUBJECT
N/A | Biographical writing uses similar evidence-based character reconstruction: the historian, like the literary analyst, must distinguish subject's actions from biographer's interpretation.
 N/A | Trait inference from behavioral evidence (Prasad's script choice → principled visionary) mirrors psychological assessment: observing consistent patterns across contexts to infer enduring dispositions.
## PREREQ_CONCEPT
Ability to distinguish direct characterization (author tells) from indirect characterization (actions/speech reveal) and to cite textual evidence for inferences.

## PREREQ_BEFORE
Student must have completed the Plot and Setting nodes for this chapter to know the narrative sequence and physical context of Prasad's portrayal.

## PREREQ_STUCK
If unable to separate narrator's voice from Prasad's actions, review the "Indirect Characterization" section in c11_hin_ar_cbse_01_004 and re-read the essay marking only Prasad's verbs.

## WORKED_EXAMPLE_1
PROBLEM: Using the PEEL structure (Point, Evidence, Explanation, Link), write a paragraph analyzing Prasad's "simplicity" as a deliberate intellectual choice, not mere poverty.
STEPS:
- Step 1 (Point): Prasad's simplicity was a conscious alignment with his literary mission to elevate Hindi as a people's language.
- Step 2 (Evidence): The narrator describes his downstairs workspace: "lM+d ij dbZ pDdj yxsA oqQN nsj ihNs, d yM+osQ us m¡xyh ls Åij dh vksj b'kkjk fd;k" (beard on face, a woman fanning from above) — a modest room, not a study. Later, Prasad explains his script choice: "ukxj viHkza'k ls tks f'k"V yksxksa dh Hkk"kk fodflr gqbZ] ogh ukxjh dgykbZ."
- Step 3 (Explanation): The physical austerity mirrors the linguistic austerity — both reject elitism. The beard and fan suggest traditional Indian simplicity; the script choice shows intellectual consistency. He could have used Kaithi (official, easier for administration) but chose Devanagari to make Hindi accessible to the "educated people" (f'k"V yksx).
- Step 4 (Link): This consistency — lifestyle matching linguistic principle — makes him a credible leader of the Hindi renaissance, which is the chapter's central theme.
- Step 5 (Verification): Cross-check: Does the text support "deliberate choice"? Yes — the narrator explicitly contrasts Prasad's choice with the prevailing Kaithi usage and explains Prasad's reasoning.
REASONING: The PEEL structure forces evidence before interpretation, preventing the common error of asserting traits without proof. Linking to theme ensures the analysis serves the board exam's "central idea" requirement.
ANSWER: Prasad's simplicity was a deliberate intellectual choice aligning his life with his mission to democratize Hindi. His modest downstairs workspace — "lM+d ij dbZ pDdj yxsA oqQN nsj ihNs" — mirrors his rejection of the elite Kaithi script in favor of Devanagari: "ukxj viHkza'k ls tks f'k"V yksxksa dh Hkk"kk fodflr gqbZ] ogh ukxjh dgykbZ." This consistency between domestic austerity and linguistic principle establishes him as an authentic leader of the Hindi renaissance, the chapter's core theme.

## WORKED_EXAMPLE_2
PROBLEM: The narrator calls Prasad "ek viwoZ ekèkq;Z" (a strange attraction) in childhood. Analyze how the essay transforms this childhood fascination into a mature literary judgment through three specific encounters.
STEPS:
- Step 1: Identify the three encounters: (a) Childhood: hearing father recite Prasad's poetry; (b) Youth: visiting Prasad's house, seeing the "kh?kz xgjh eS=kh"; (c) Adulthood: witnessing Prasad's generosity to writers and his wife's deathbed scene.
- Step 2: Trace the shift in narrator's lens: (a) Awe at poetic greatness; (b) Surprise at human simplicity; (c) Reverence for moral consistency.
- Step 3: For each, extract Prasad's action that triggers the shift: (a) Father's recitation → Prasad's poetic power; (b) Working in a simple room → Prasad's humility; (c) Unmoved bed + secret charity → Prasad's integrated humanity.
- Step 4: Synthesize: The "strange attraction" evolves from hero-worship to recognition of a life where literary greatness and domestic duty are not separate but fused.
- Step 5: Connect to characterization: This narrative arc *is* the characterization method — Prasad is revealed through the narrator's deepening understanding, making the reader undergo the same journey.
REASONING: This example teaches the "character through narrator's evolution" technique essential for memoir analysis. Board exams often ask "How does the narrator's view change?" — this structure answers it directly.
ANSWER: The essay structures Prasad's characterization through the narrator's three-stage evolving perception: (1) Childhood awe — father's recitation of "gfj'panz" poetry establishes Prasad as a literary giant. (2) Youthful surprise — visiting the "kh?kz xgjh eS=kh" reveals a giant living simply, working in a modest room. (3) Mature reverence — witnessing the unmoved deathbed and anonymous charity shows greatness rooted in daily moral choices. The "viwoZ ekèkq;Z" thus matures into recognition that Prasad's literature and life are one integrated whole.

## WORKED_EXAMPLE_3
PROBLEM: A board exam question asks: "Prasad's character is revealed more through what he *doesn't* say than what he does." Evaluate this claim with two pieces of evidence from the text.
STEPS:
- Step 1: Deconstruct the claim — it suggests silence/omission as characterization technique.
- Step 2: Find silences: (a) Prasad never boasts of his literary status; when the narrator visits, he doesn't mention his fame. (b) During his wife's illness, he doesn't complain or seek sympathy; the narrator discovers the severity only through observation.
- Step 3: Contrast with speech: Prasad speaks mainly about Hindi's future (script, vocabulary) — public mission, not private self.
- Step 4: Analyze effect: The silences create dignity; the speeches reveal vision. Together they build a character defined by *service* (to language, to family) not *self-presentation*.
- Step 5: Evaluate the claim: Partially true — silences reveal private virtues (humility, endurance); speeches reveal public mission. The narrator *interprets* both. The claim oversimplifies by ignoring the speeches' role.
- Step 6: Formulate exam answer: Acknowledge the claim's insight (silences show private greatness) but add nuance (speeches show public greatness); conclude that the narrator's *selection* of both creates the portrait.
REASONING: This models the "evaluate a critical statement" question type common in CBSE 5-mark questions. It requires balancing a given perspective with textual counter-evidence — a high-order skill.
ANSWER: The claim is insightful but incomplete. Prasad's silences — never mentioning his fame to the young narrator, enduring his wife's death without public grief — powerfully reveal private humility and endurance. However, his *spoken* words — advocating Devanagari as "the script developed by educated people," guiding young writers — equally reveal his public vision. The narrator constructs Prasad's character by juxtaposing these: the man who speaks for a language's future but stays silent about his own greatness. Thus, characterization emerges from the *tension* between strategic speech and deliberate silence.

## COMPETENCY_QUESTION_1
QUESTION: The narrator describes Prasad's daily routine: writing at night, meeting visitors by day, managing household crises. Using the concept of "character as habit," explain how this routine reflects Prasad's prioritization of literature over self-comfort. Support with two specific textual details.
COMPETENCY: Textual Evidence Integration
STEPS:
- Step 1: Identify the routine details: "rhl o"kZ ifgys... pkSèkjh lkgc ls rks vc vPNh rjg ifjp; gks x;k Fkk" (writing at night while wife ill), "mikè;k; th ukxjh dks Hkk"kk ekurs Fks" (teaching Hindi language).
- Step 2: Define "character as habit" — repeated actions reveal deep values.
- Step 3: Connect night writing to literary priority: he sacrifices sleep/health for creation.
- Step 4: Connect daytime teaching to mission: he invests in Hindi's future over personal leisure.
- Step 5: Synthesize: The routine *is* the character — no grand gestures, just daily choice of literature over comfort.
ANSWER: Prasad's routine embodies "character as habit": his nightly writing during his wife's terminal illness ("rhl o"kZ ifgys... pkSèkjh lkgc ls rks vc vPNh rjg ifjp; gks x;k Fkk") shows literature as non-negotiable duty; his daytime teaching of Hindi ("mikè;k; th ukxjh dks Hkk"kk ekurs Fks") shows language-building as daily practice. These aren't sacrifices he announces — they are the fabric of his days, revealing a character for whom literary mission supersedes self-comfort without performative martyrdom.
DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: A critic argues: "The narrator's Prasad is a construct — a saintly figure created by selective memory to serve a nationalist Hindi narrative." Using the text, give one piece of evidence supporting this view and one complicating it. Conclude with your assessment.
COMPETENCY: Critical Perspective Evaluation
STEPS:
- Step 1: Evidence supporting "construct": The narrator omits Prasad's controversies (e.g., his conflicts with other literary factions, his commercial publishing decisions) — only reverent moments appear.
- Step 2: Evidence complicating: The narrator includes un-saintly details — Prasad's irritation at the poet's bad verse ("dfoÙk yydkjk"), his blunt correction of the scholar ("okg! ;g D;k eqf'dy ckr gSA"), his human grief at wife's death.
- Step 3: Analyze narrator's intent: He explicitly states his purpose — to show how "izse vkSj oqQrwgy dk vn~Hkqr feJ.k" produced greatness. This is interpretation, not hagiography.
- Step 4: Assess: The portrait is *curated* (all memoirs are) but not *fabricated* — the included flaws serve the theme of tension, not perfection.
- Step 5: Formulate balanced conclusion.
ANSWER: The critic's view is partially valid but reductive. Supporting evidence: The narrator excludes Prasad's known literary rivalries and financial negotiations, presenting a seamless devotion. Complicating evidence: The narrator *includes* Prasad's sharp rebuke to a bad poet ("dfoÙk yydkjk") and his raw grief at his wife's death — details that humanize, not sanctify. The narrator's stated aim — to reveal how "izse vkSj oqQrwgy dk vn~Hkqr feJ.k" forged the writer — frames these as thematic selections, not omissions. Thus, Prasad emerges as a *thematic construct* (the writer as synthesis of art and life) rather than a *saintly fiction*.
DIFFICULTY: hard