## DEFINITION
Setting refers to the time, place, and social environment in which a literary work unfolds, while atmosphere is the emotional mood or feeling evoked in the reader through descriptive language, imagery, and sensory details; together they create the immersive world that shapes characters' actions and reinforces themes.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student can independently identify specific textual evidence (words, phrases, images) that establish setting and atmosphere in Raskhan's poetry and the prose excerpt, explain how they interact to deepen the bhakti theme, and write a structured PEEL paragraph analyzing this relationship for a 5-mark board question.

## SCOPE_BOUNDARY
This node covers analysis of setting (historical Braj region, Vrindavan, 16th-century socio-religious context) and atmosphere (devotional ecstasy, longing, contrast between worldly and spiritual realms) in Raskhan's "Jhānkī" poem and the "Hajar-Jak" prose excerpt; it does NOT cover character analysis, theme development beyond setting-atmosphere link, or other literary devices like irony/symbolism (covered in sibling nodes).

## WALKTHROUGH
Imagine you are standing in a crowded Vrindavan temple courtyard in 1580 CE — the air thick with incense, the sound of dholak and cymbals, devotees swaying to Krishna's name. Now open your textbook to Raskhan's "Jhānkī": the poem does not just describe this scene, it *makes you feel* it through words like "कुंज" (grove), "यमुना" (Yamuna), "रास" (divine dance). Start by circling every place-name, time-marker, and sensory word (smell, sound, touch) in the poem and prose. Next, label each as "setting" (external facts) or "atmosphere" (internal feeling). Then ask: how does the setting *produce* the atmosphere? For example, the Yamuna's flowing water (setting) mirrors the devotee's flowing tears (atmosphere). The key insight: in bhakti poetry, setting is never neutral — it is charged with divine presence, and atmosphere is the reader's participatory experience of that charge.

## DIAGNOSTIC_QUESTION_1
Define "setting" and "atmosphere" in your own words, and give one example of each from Raskhan's "Jhānkī" poem (reference stanza number or line description).

## DIAGNOSTIC_ANSWER_1
Setting = the concrete spatiotemporal and social coordinates of the narrative (e.g., "Vrindavan's kunj/groves" in stanza 1 establishes the sacred geography of Braj). Atmosphere = the emotional mood evoked in the reader through sensory language (e.g., the repeated "आँसू" / tears and "विरह" / separation imagery creates an atmosphere of intense longing). A wrong answer that swaps the two (e.g., calling "tears" a setting detail) reveals confusion between external facts and internal emotional effect — a fundamental category error that leads to vague, mark-losing board answers.

## DIAGNOSTIC_QUESTION_2
In the prose excerpt "Hajar-Jak," the narrator describes Hajar's mother's reaction to Krishna's idol: "वे रोने लगीं... उनके आँसू नहीं रुकते थे." Explain how this moment uses *setting details* (physical surroundings) to amplify the *atmosphere* of divine love. Do not merely summarize the scene.

## DIAGNOSTIC_ANSWER_2
The setting detail "मंदिर का अँधेरा कोना" (dark corner of the temple) contrasts with the "मूर्ति की चमक" (glow of the idol), physically framing the mother's tears as illumination in darkness — the setting *becomes* a metaphor for spiritual awakening. The cold stone floor (setting) against her warm tears (atmosphere) creates tactile tension that mirrors the soul's contact with the divine. A wrong answer that only narrates "she cried because she loved Krishna" misses the *craft*: how the writer uses physical space to make the emotion tangible. This confusion between *plot summary* and *literary analysis* is the #1 reason students lose 2-3 marks on 5-mark questions.

## DIAGNOSTIC_QUESTION_3
APPLY: Below are two sentences describing the same scene. Identify which creates a stronger *atmosphere of devotion* and explain why, using the terms "sensory imagery" and "show-don't-tell."
A. "The devotee felt great love for Krishna and prayed sincerely."
B. "Her fingers traced the cold flute on the idol's lips; the sandalwood scent clung to her palms long after she left the sanctum."

## DIAGNOSTIC_ANSWER_3
Sentence B is stronger. It uses sensory imagery (tactile: "cold flute," "traced"; olfactory: "sandalwood scent clung") to *show* devotion through physical interaction with the setting, rather than *telling* the abstract emotion "love." The setting (idol, sanctum, sandalwood) becomes the medium through which atmosphere is conveyed. A student choosing A reveals a "telling" habit — stating emotions directly instead of grounding them in setting-evoked sensory experience. This is exactly what CBSE marking schemes penalize: "general statements without textual evidence."

## DIAGNOSTIC_QUESTION_4
ANALYZE: Compare how the poem "Jhānkī" and the prose "Hajar-Jak" use the *Yamuna river* as a setting element. In the poem it appears as "यमुना तट" (Yamuna's bank); in the prose, Hajar's mother "यमुना में स्नान करने जाती थी" (went to bathe in Yamuna). How does each text transform this shared geographical feature into a *different* atmospheric effect?

## DIAGNOSTIC_ANSWER_4
In the poem, "यमुना तट" is a *static, eternal backdrop* for Krishna's lila — the atmosphere is timeless, mythic, inviting the reader into a perpetual divine present. In the prose, the mother's *daily ritual* of bathing makes Yamuna a *lived, habitual space* — the atmosphere is intimate, domestic, showing how the sacred permeates ordinary routine. The poem uses setting to *elevate*; the prose uses setting to *indwell*. A wrong answer that says "both show Yamuna is holy" flattens the distinction between *mythic atmosphere* (poem) and *embodied devotion* (prose) — a failure to analyze how genre (verse vs. prose) shapes setting-atmosphere interaction.

## DIAGNOSTIC_QUESTION_5
EVALUATE: A student writes: "Raskhan's setting is just Vrindavan; the atmosphere is just bhakti. There's nothing complex about it." Critique this statement using two specific textual proofs that demonstrate layered complexity in the setting-atmosphere relationship.

## DIAGNOSTIC_ANSWER_5
The statement is reductive and incorrect. Proof 1: The poem juxtaposes "राजमहल" (royal palace — Raskhan's Muslim noble birth setting) with "कुंज" (grove — chosen bhakti setting), creating an atmosphere of *radical renunciation* — the setting contrast *is* the spiritual journey. Proof 2: In "Hajar-Jak," the setting shifts from "जंगल" (forest/wilderness) to "मंदिर" (temple), mirroring Hajar's inner shift from fear to faith — the atmosphere evolves *through* setting change. A student making this oversimplification cannot score above 2/5 on a board analysis question because they miss the *dynamic interplay* that CBSE competency questions explicitly test ("analyze how setting shapes mood").

## DIAGNOSTIC_QUESTION_6
CREATE: Write a 4-line stanza (in Hindi or English) that establishes a *new setting* for a Krishna devotee (e.g., a modern city apartment, a hospital room, a railway station) and evokes an *atmosphere of viraha (separation longing)* using only sensory details — no abstract emotion words like "sad," "love," "devotion."

## DIAGNOSTIC_ANSWER_6
Example (English): "Fluorescent light hums above the plastic idol / Metro rumble shakes the incense ash / Cold tea steams beside the unread Gita / Her fingers find the flute's carved curve in darkness." 
Criteria for a good answer: (1) Specific, unconventional setting named, (2) At least 3 sensory details (auditory, tactile, olfactory, visual), (3) Zero abstract emotion labels, (4) The object (flute/idol/Gita) bridges setting and atmosphere. A poor answer uses "she misses Krishna" or "she feels sad" — revealing inability to *embody* atmosphere in setting, a skill essential for creative writing tasks in CUET/board exams.

## COMMON_MISCONCEPTION
Students treat setting as a passive "background" (time/place labels) and atmosphere as a simple adjective ("sad," "holy," "peaceful"). They write: "The setting is Vrindavan. The atmosphere is devotional." This is wrong because: (1) In Raskhan, setting is *active* — the kunj, Yamuna, flute *participate* in the devotee's experience (e.g., "यमुना तट पर रास रचायो" — Yamuna's bank *hosts* the divine dance). (2) Atmosphere is not a label but a *layered effect* created by conflicting sensory inputs: the poem mixes "मधुर बांसुरी" (sweet flute) with "विरह की आग" (fire of separation) — the atmosphere is *bittersweet ecstasy*, not just "devotional." (3) Students miss the *historical setting layer*: Raskhan's Muslim identity (setting: Mughal court culture) vs. Hindu bhakti (setting: Braj) creates an atmosphere of *syncretic surrender* — a nuance that appears in CUET "assertion-reason" questions. The error stems from Class 10-style "fill-in-the-blank" learning where setting = one-word answer.

## ON_FAILURE
Step 1: Re-read the poem aloud, circling every noun that names a place, object, or time (कुंज, यमुना, बांसुरी, रात, प्रातः). Step 2: For each circled word, write *one* sensory detail the text attaches to it (e.g., कुंज → "गहन" dense/dark; बांसुरी → "मधुर" sweet). Step 3: Draw a two-column table: left column = setting detail, right column = feeling it evokes in *you* as reader. Step 4: Re-attempt Diagnostic Question 2 using this table as evidence. Step 5: If still stuck, revisit Class 11 node **c11_hin_ar_cbse_01_003** (Setting and Atmosphere in Chapter 1) and re-do its Worked Example 1 — the same analytical scaffold applies.

## BUILDS_ON
Class 11 skill of identifying setting and atmosphere as separate elements.

## LEADS_TO
Character analysis (c12_hin_a_cbse_06_004/005) where setting-atmosphere shapes protagonist's choices, and Theme analysis (c12_hin_a_cbse_06_006/007) where setting-atmosphere *embodies* the primary theme of bhakti.

## PREREQUISITE_NODE_IDS
c11_hin_ar_cbse_01_003, c11_hin_ar_cbse_02_003, c11_hin_ar_cbse_03_003, c11_hin_ar_cbse_04_003, c11_hin_ar_cbse_05_003, c11_hin_ar_cbse_06_003, c11_hin_ar_cbse_07_003, c11_hin_ar_cbse_08_003, c11_hin_ar_cbse_09_003, c11_hin_ar_cbse_10_003, c11_hin_ar_cbse_11_003, c11_hin_ar_cbse_12_003, c11_hin_ar_cbse_13_003, c11_hin_ar_cbse_14_003, c11_hin_ar_cbse_15_003, c11_hin_ar_cbse_16_003, c11_hin_v_cbse_01_003, c11_hin_v_cbse_02_003, c11_hin_v_cbse_03_003, c11_hin_v_cbse_04_003, c11_hin_v_cbse_05_003, c12_hin_a_cbse_06_001, c12_hin_a_cbse_06_002
## PREREQUISITE_REASONS
c11_hin_ar_cbse_01_003: Class 11 foundation for identifying setting/atmosphere in prose/poetry across multiple chapters
c11_hin_ar_cbse_02_003: Reinforced practice with different texts builds pattern recognition
c11_hin_ar_cbse_03_003: Additional genre variety (poetry vs prose) in setting-atmosphere analysis
c11_hin_ar_cbse_04_003: Cumulative exposure to Braj/Avadhi dialect settings
c11_hin_ar_cbse_05_003: Practice with historical-social setting layers
c11_hin_ar_cbse_06_003: Bhakti poetry specific setting-atmosphere conventions
c11_hin_ar_cbse_07_003: Mythic vs. domestic setting contrast
c11_hin_ar_cbse_08_003: Sensory imagery mapping exercises
c11_hin_ar_cbse_09_003: Atmosphere as multi-tonal (not single adjective)
c11_hin_ar_cbse_10_003: Setting as active participant in narrative
c11_hin_ar_cbse_11_003: Temporal setting (time of day/season) effects
c11_hin_ar_cbse_12_003: Social setting (caste/court/village) dimensions
c11_hin_ar_cbse_13_003: Intertextual setting references
c11_hin_ar_cbse_14_003: Setting-atmosphere in autobiographical prose
c11_hin_ar_cbse_15_003: Comparative setting analysis across texts
c11_hin_ar_cbse_16_003: Advanced synthesis for board-level answers
c11_hin_v_cbse_01_003: Vitan textbook complementary practice
c11_hin_v_cbse_02_003: Non-fiction setting analysis
c11_hin_v_cbse_03_003: Essay/memoir atmosphere techniques
c11_hin_v_cbse_04_003: Travelogue setting as character
c11_hin_v_cbse_05_003: Reflective atmosphere in personal narrative
c12_hin_a_cbse_06_001: Context/background knowledge of Raskhan's life (Mughal court to Vrindavan)
c12_hin_a_cbse_06_002: Narrative structure understanding (where setting shifts occur in the chapter)

## FORWARD_NODE_IDS
c12_hin_a_cbse_06_004, c12_hin_a_cbse_06_005, c12_hin_a_cbse_06_006, c12_hin_a_cbse_06_007, c12_hin_a_cbse_06_008, c12_hin_a_cbse_06_009, c12_hin_a_cbse_06_012, c12_hin_a_cbse_06_013

## FORWARD_REASONS
c12_hin_a_cbse_06_004: Protagonist's spiritual journey is mapped through setting shifts (court → Vrindavan)
c12_hin_a_cbse_06_005: Supporting characters (Hajar, mother) defined by their relationship to sacred spaces
c12_hin_a_cbse_06_006: Primary theme (bhakti as surrender) is *enacted* through setting-atmosphere fusion
c12_hin_a_cbse_06_007: Secondary themes (syncretism, renunciation) emerge from setting contrasts
c12_hin_a_cbse_06_008: Imagery/metaphor analysis requires setting-atmosphere foundation (e.g., Yamuna as metaphor)
c12_hin_a_cbse_06_009: Irony/symbolism (e.g., Muslim poet in Hindu sacred space) rooted in setting tension
c12_hin_a_cbse_06_012: Setting/atmosphere clues support inferential reasoning about mood.  
c12_hin_a_cbse_06_013: Supplies setting/atmosphere details (Braj, pastoral) that inform imagistic analysis.  

## CROSS_SUBJECT_PREREQS
c11_hin_ar_cbse_06_003, c11_hin_ar_cbse_07_003, c11_hin_ar_cbse_08_003
## CROSS_SUBJECT_REASONS
c11_hin_ar_cbse_06_003: Bhakti poetry setting conventions (Braj topography as sacred geography) directly transfer to Raskhan analysis
c11_hin_ar_cbse_07_003: Mythic vs. domestic setting contrast in earlier bhakti poems builds comparative lens
c11_hin_ar_cbse_08_003: Sensory imagery mapping practice from Class 11 is the core analytical tool for this node

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_06_003 -> c12_hin_a_cbse_06_003 -> c12_hin_a_cbse_06_006 (Setting-atmosphere analysis enables theme articulation for board competency questions)

## THIS_FORMULA
PEEL Analysis Framework for Setting-Atmosphere: Point (specific setting element) → Evidence (quoted phrase + sensory detail) → Explanation (how sensory detail creates feeling) → Link (connect to bhakti theme / character state / structural function)

## FORMULA_VARIABLES
P = Precise setting detail from text (noun phrase with modifier); E = Direct quote or close paraphrase with sensory word highlighted; Ex = Cause-effect: "The [sensory detail] makes the reader feel [specific emotion] because [cultural/psychological reason]"; L = "This reinforces the theme of [bhakti/syncretism/viraha] by showing [how setting participates in spiritual experience]."

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
analytical

## CROSS_SUBJECT
N/A | The historical setting of 16th-century Braj (Mughal-Rajput syncretism, Vrindavan as theological center) is the *actual history* behind Raskhan's poetic setting — students who know the history read the poem's atmosphere as culturally grounded, not just decorative
 N/A | The Yamuna river, Braj parikrama route, and kunj/grove ecology are *geographical realities* that shape the poem's sensory atmosphere — understanding the physical landscape explains why "यमुना तट" evokes specific devotional feelings
 N/A | Temple-centered economy of Vrindavan (pilgrimage, offerings, patronage) is the *material setting* enabling the devotional atmosphere — Raskhan's own patronage history reflects this
 N/A | The poem's atmosphere of Hindu-Muslim spiritual synthesis (Raskhan's identity) mirrors the *civic ideal* of pluralism — setting as a site of negotiated belonging
## PREREQ_CONCEPT
Ability to distinguish between denotative setting details (facts) and connotative atmospheric effects (feelings), practiced across Class 11 Hindi chapters.

## PREREQ_BEFORE
Student must be able to: (1) locate setting markers in a Hindi text, (2) identify sensory language (श्रव्य, स्पर्श, दृश्य, घ्राण, स्वाद), (3) articulate a specific mood in one precise word (not "happy/sad" but "yearning," "reverence," "ecstatic surrender").

## PREREQ_STUCK
If unable to separate setting from atmosphere, return to Class 11 node **c11_hin_ar_cbse_08_003** (Literary Devices: Imagery and Metaphor) and redo its Worked Example 2 — the imagery-to-mood mapping exercise is the prerequisite skill.

## WORKED_EXAMPLE_1
PROBLEM: Analyze how the opening stanza of "Jhānkī" establishes the setting of Braj and simultaneously creates an atmosphere of divine accessibility. Write a PEEL paragraph.

STEPS:
- Step 1: Identify the setting markers in stanza 1 — "कुंज" (grove), "यमुना" (Yamuna), "ब्रज" (Braj), "गोकुल" (Gokul) — these are proper nouns anchoring the poem in sacred geography.
- Step 2: Identify the sensory/modifier words attached to each — "गहन कुंज" (dense/dark grove), "कलकल यमुना" (murmuring Yamuna), "मनोहर ब्रज" (charming Braj), "गोपाल गोकुल" (cowherd Gokul). Note: each modifier adds sensory texture (visual: dense; auditory: murmuring; aesthetic: charming; vocational: cowherd).
- Step 3: Apply PEEL — Point: The stanza constructs Braj as an intimate, sensory-rich dwelling place of Krishna, not a distant heaven. Evidence: "गहन कुंज" (dense grove) + "कलकल यमुना" (murmuring Yamuna). Explanation: "गहन" suggests closeness, enclosure — the divine is *within reach*, not remote; "कलकल" (onomatopoeic water sound) makes the river audible, pulling the reader into the soundscape. Link: This accessibility mirrors bhakti's core claim — God is available to all senses, here and now, without priestly mediation.
- Step 4: Verify against theme — Does this support "bhakti as direct access"? Yes. The setting *is* the argument.
- Step 5: Polish for board answer — Add transition: "Thus, the very first stanza uses Braj's physical topography to enact the poem's theological proposition."

REASONING: This example models the exact 4-step PEEL structure CBSE expects for 5-mark "analyze" questions. It forces the student to move from *identification* (Step 1-2) to *interpretation* (Step 3) to *thematic synthesis* (Step 4-5) — the full analytical arc.

ANSWER: The opening stanza of "Jhānkī" transforms Braj from a geographical location into an atmosphere of divine immediacy. By modifying each place-name with sensory adjectives — "गहन कुंज" (dense grove), "कलकल यमुना" (murmuring Yamuna) — Raskhan makes the sacred space tangible: the grove's density suggests the divine is *enclosed, near, findable*; the river's onomatopoeic murmur invites auditory participation. This setting-atmosphere fusion enacts the bhakti principle that Krishna is accessible to every devotee's senses, without ritual barrier. The physical landscape *becomes* the spiritual argument.

## WORKED_EXAMPLE_2
PROBLEM: In the prose excerpt "Hajar-Jak," Hajar's mother visits the temple daily. Analyze how the *routine setting* (temple courtyard, stone steps, idol) builds an atmosphere of *habitual devotion* rather than dramatic epiphany. Use PEEL.

STEPS:
- Step 1: Locate the routine setting details — "प्रतिदिन मंदिर जाती थी" (went to temple daily), "सीढ़ियों पर बैठती" (sat on steps), "मूर्ति के सामने" (before the idol), "चंदन का टीका" (sandalwood tilak).
- Step 2: Note the *repetition markers* — "प्रतिदिन" (daily), "नियम से" (regularly), "आदत सी पड़ गई" (became a habit). These convert setting into ritual.
- Step 3: Apply PEEL — Point: The prose uses mundane, repetitive setting details to show devotion as *lived practice*, not sudden miracle. Evidence: "सीढ़ियों की ठंडक" (coolness of steps) + "नियम से चंदन लगाती" (applies sandalwood regularly). Explanation: The tactile "cold steps" felt daily grounds devotion in the body; the olfactory "sandalwood" repeated daily makes piety a sensory habit. Link: This reflects the bhakti ideal of *nitya-seva* (daily service) — atmosphere emerges from accumulation, not intensity.
- Step 4: Contrast with poem — Poem's atmosphere is *ecstatic/peak* (रास, बांसुरी, विरह); prose's is *quotidian/sustained*. Both are valid bhakti modes.
- Step 5: Write board-ready answer — Include the contrast for extra depth (shows "analyze" level).

REASONING: This example teaches students to recognize *genre difference* (poem vs. prose) in setting-atmosphere creation — a specific Class 12 competency (comparative analysis across forms within same chapter). The "routine vs. peak" distinction is a sophisticated analytical move that scores high on "evaluate" questions.

ANSWER: In "Hajar-Jak," the temple setting is stripped of spectacle: "सीढ़ियों की ठंडक" (cool stone steps), "नियम से चंदन का टीका" (daily sandalwood tilak), "प्रतिदिन की आदत" (daily habit). These repeated, tactile-olfactory details construct an atmosphere of *quiet constancy* — devotion as muscle memory, not emotional surge. The cold steps under the mother's body each morning make surrender physical; the sandalwood scent on her fingers each evening makes it lingering. Unlike the poem's "कलकल यमुना" (peak auditory ecstasy), here the atmosphere accumulates through *returning* to the same setting. The prose thus embodies *nitya-bhakti* (daily devotion) where setting is not a stage for miracle but a workshop for habituation.

## WORKED_EXAMPLE_3
PROBLEM: Synthesis task — Compare how *time of day* functions as a setting element in the poem (references to "प्रातः" morning, "संध्या" evening, "रात" night) vs. the prose (mother's "सुबह-सुबह" early morning bath, "सांझ" evening lamp-lighting). Explain how each text uses temporal setting to structure a *different devotional rhythm*. Write a comparative PEEL paragraph.

STEPS:
- Step 1: Extract all time markers — Poem: "प्रातःकाल" (dawn), "संध्या" (dusk), "निशि" (night), "बिहान" (morning). Prose: "ब्रह्ममुहूर्त" (pre-dawn), "सूर्योदय से पहले" (before sunrise), "सांझ ढले" (after dusk).
- Step 2: Map each to associated activity — Poem: dawn = "दर्शन" (vision), dusk = "आरती" (worship), night = "विरह" (separation longing). Prose: pre-dawn = "स्नान" (bath), post-dusk = "दीप जलाना" (lighting lamp).
- Step 3: Identify the *rhythm* each creates — Poem: *cosmic cycle* — time mirrors Krishna's eternal lila (morning cow-grazing, evening return, night dance). Prose: *human cycle* — time mirrors householder routine (bath, chores, lamp).
- Step 4: Comparative PEEL — Point: Both texts use diurnal time to structure devotion, but the poem aligns human time with *divine time*, while the prose aligns it with *domestic time*. Evidence: Poem — "निशि रास रचायो" (night: divine dance); Prose — "सांझ ढले दीप जला के" (dusk: household lamp). Explanation: The poem's night is metaphysical (Krishna's rasa-lila); the prose's dusk is practical (light for cooking/prayer). Link: This reveals Raskhan's dual vision — the mystic sees Krishna's time; the devotee-mother keeps human time *for* Krishna.
- Step 5: Check for "analyze" depth — Yes: compares, contrasts, explains function, links to author's perspective.
- Step 6: Final polish — Use comparative connectives: "whereas," "conversely," "both... but."

REASONING: This is the hardest worked example because it requires *cross-textual synthesis* within the same chapter — a skill explicitly tested in CBSE "case-based" and CUET "comparative analysis" questions. It also connects to Class 11 learning (c11_hin_ar_cbse_11_003: temporal setting) but raises it to comparative level.

ANSWER: Both texts anchor devotion in the day's cycle, but they synchronize different clocks. The poem's temporal markers — "प्रातःकाल दर्शन," "संध्या आरती," "निशि रास" — follow *Krishna's pastoral schedule*: cows out at dawn, home at dusk, dance at night. The atmosphere is *mythic participation*: the devotee enters God's time. The prose's markers — "ब्रह्ममुहूर्त स्नान," "सांझ ढले दीप" — follow a *widow's domestic schedule*: ritual bath before sunrise, lamp after dusk. The atmosphere is *offering*: human time given to God. Raskhan thus presents a spectrum: the poet-mystic *dissolves* into divine time; the mother *sanctifies* human time. The shared setting (Braj, temple, Yamuna) hosts both rhythms — proving setting is not a container but a *meeting ground* of eternal and temporal.

## COMPETENCY_QUESTION_1
QUESTION: A CUET-style assertion-reason question:  
**Assertion (A):** In Raskhan's "Jhānkī," the setting of Vrindavan is not merely a backdrop but an active participant in the devotional experience.  
**Reason (R):** The poem uses sensory-rich modifiers (e.g., "गहन," "कलकल," "मनोहर") attached to place-names to convert geography into felt presence.  
Choose the correct option:  
(a) Both A and R are true, and R correctly explains A.  
(b) Both A and R are true, but R does not explain A.  
(c) A is true, R is false.  
(d) A is false, R is true.

COMPETENCY: Critical evaluation of assertion-reason logic with textual evidence

STEPS:
- Step 1: Verify Assertion (A) — Is Vrindavan an active participant? Yes: "यमुना तट पर रास रचायो" (Yamuna's bank *hosts* the dance), "कुंज में बुलायो" (grove *calls* the devotee). Setting acts.
- Step 2: Verify Reason (R) — Are there sensory modifiers on place-names? Yes: "गहन कुंज," "कलकल यमुना," "मनोहर ब्रज," "गोपाल गोकुल." Each adds sensory dimension.
- Step 3: Test explanatory link — Does R explain *how* setting becomes active? Yes: the modifiers *are the mechanism* — they transform nouns from static labels into sensory experiences that the reader *feels*, making the setting participatory.
- Step 4: Select option — Both true, R explains A → (a).

ANSWER: (a) Both A and R are true, and R correctly explains A. The sensory modifiers ("गहन," "कलकल," "मनोहर") are the precise literary device that animates the setting, turning Vrindavan from a map location into a living, feeling presence that envelops the devotee. This is the core setting-atmosphere dynamic the chapter teaches.

DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: Case-based question: Read the following student answer to a 5-mark board question *"Analyze how setting creates atmosphere in the 'Hajar-Jak' prose excerpt"* and identify **two specific weaknesses** using CBSE marking criteria. Then rewrite the answer to score full marks.

**Student Answer:**  
"The setting of the story is a temple in Vrindavan. Hajar's mother goes there every day. She sits on the steps and puts tilak on the idol. The atmosphere is very religious and peaceful. She loves Krishna very much. The setting shows she is a true devotee. The Yamuna river is also there. It is holy. This creates a holy atmosphere."

COMPETENCY: Evaluating and improving analytical writing (meta-cognitive skill for board exam success)

STEPS:
- Step 1: Identify Weakness 1 — **No textual evidence**: Zero quotes, no specific sensory words from the text ("सीढ़ियों की ठंडक," "चंदन का टीका," "प्रतिदिन"). CBSE requires "close reference to text."
- Step 2: Identify Weakness 2 — **Conflation of setting and atmosphere**: "setting shows she is a true devotee" confuses character inference with atmospheric effect. Atmosphere = reader's feeling, not character's trait.
- Step 3: Rewrite using PEEL × 2 (two distinct setting-atmosphere pairs) — Pair 1: Steps' coldness → tactile atmosphere of embodied routine. Pair 2: Sandalwood scent → olfactory atmosphere of lingering sacredness.
- Step 4: Add thematic link — Connect to *nitya-bhakti* (daily devotion) as the chapter's structural idea.
- Step 5: Ensure 120-150 words, formal Hindi/English, no vague adjectives.

ANSWER: **Weaknesses:** (1) Zero textual quotes/sensory details — violates "close reference to text" criterion. (2) Treats atmosphere as character trait ("she is a true devotee") rather than reader's evoked mood.  
**Rewritten Answer (full marks):**  
The prose constructs an atmosphere of *habitual devotion* through two sensory-anchored setting details. First, "सीढ़ियों की ठंडक" (coolness of stone steps) felt "प्रतिदिन" (daily) by the mother converts the temple courtyard into a tactile routine — the cold stone against skin makes surrender physical and cumulative, not occasional. This evokes in the reader a mood of *quiet constancy*, mirroring *nitya-seva*. Second, "नियम से चंदन का टीका" (regular sandalwood tilak) leaves "हथेलियों पर सुगंध" (fragrance on palms) long after prayer — the olfactory trace extends the sacred space beyond the temple, creating an atmosphere of *permeating grace*. Together, these setting-atmosphere pairs show bhakti not as emotional peak but as sensory habituation — the core theme of "Hajar-Jak."

DIFFICULTY: hard