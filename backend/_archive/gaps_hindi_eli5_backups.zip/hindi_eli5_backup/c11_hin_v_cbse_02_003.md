## DEFINITION
Setting refers to the physical, temporal, and social environment in which a narrative unfolds, including geographical location, climate, historical period, and cultural context. Atmosphere is the emotional mood or tone evoked by the setting through sensory details, imagery, and narrative perspective, shaping the reader's psychological response to the story world.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student must be able to identify specific textual evidence of physical setting (geography, climate, architecture) and emotional atmosphere (mood, tone, sensory imagery) in the chapter, and explain how the author uses setting to create atmosphere that reinforces the central themes of water scarcity, community resilience, and traditional ecological knowledge.

## SCOPE_BOUNDARY
This node covers analysis of setting and atmosphere in "jktLFkku dh jtr cw¡nas" (Chapter 2 of Vitan), focusing on the desert landscape, johad construction, water typologies (ikyjikuh, ikrkyikuh, jstk.khikuh), and the socio-cultural atmosphere of collective labor. It does NOT cover character analysis, plot structure, thematic development beyond setting-atmosphere interplay, or grammatical devices—those are addressed in sibling nodes.

## WALKTHROUGH
Imagine you are standing barefoot on burning sand at noon in a Rajasthan village—your soles blister, the air shimmers, and the only relief is the memory of cool water in a johad. Now ask: how does the author make you *feel* that heat, that desperation, that collective hope? Begin by marking every phrase describing the physical environment—sand dunes, temperature, water sources, soil types. Next, highlight words conveying emotion: "ladjk" (intensity), "tek" (cold/relief), "fpukbZ" (construction/creation), "lkoèkkuh" (cooperation). Then trace how physical details (e.g., "xgjkbZ esa tek ne?kksaVw xje gok") transform into emotional atmosphere (relief, anticipation). Finally, connect this interplay to the chapter's core message: setting is not backdrop but active character—the desert *demands* the johad, and the johad *creates* community.

## DIAGNOSTIC_QUESTION_1
What are the three types of water sources (ikuh) classified in the text based on their relationship to ground level, and what Hindi terms does the author use for each?

## DIAGNOSTIC_ANSWER_1
The three types are: (1) ikyjikuh (surface water) — water flowing from rain, collected in ponds, tanks, etc.; (2) ikrkyikuh (groundwater) — water existing below ground level, accessed via wells; (3) jstk.khikuh (sub-surface water) — water between surface and deep groundwater, neither fully surface nor deep well water. A wrong answer (e.g., confusing ikrkyikuh with jstk.khikuh or omitting one type) reveals the student has not grasped the text's precise hydro-geological classification, which is foundational to understanding the setting's water logic.

## DIAGNOSTIC_QUESTION_2
Explain in your own words how the description of the johad construction process (pages 14-16) creates an atmosphere of collective resilience rather than mere physical labor.

## DIAGNOSTIC_ANSWER_2
The text transforms labor into ritual: the first day's "kh[h" ceremony with three offerings, the synchronized rhythm of "eq_h Hkj&Hkj" (filling soil together), the shared "fonkbZ" (refreshments) and "HksaV" (wages) as communal celebration, and the "xk¡o" (village) identity forged through "lkoèkkuh" (cooperation). A wrong answer focusing only on technical steps (digging, filling, compacting) misses the atmospheric layer—the author uses sensory details (sound of "Hkj&Hkj," taste of "fe^h," sight of "ckYVh") to elevate labor into a social covenant, revealing the student cannot distinguish physical description from atmospheric construction.

## DIAGNOSTIC_QUESTION_3
Apply the concept of "setting as active character" to this passage: "jsr osQ uhps lc txg [kfM+;k dh i^h ugha gS] blfy, oqaQbZ Hkh iwjs jktLFkku esa ugha feysxh" (Johads don't exist where the impermeable layer isn't underground). How does the geological setting dictate human settlement patterns?

## DIAGNOSTIC_ANSWER_3
Step 1: Identify the geological constraint — impermeable layer ([kfM+;k i^h) must exist underground to hold water. Step 2: Note the textual evidence — johads only exist where this layer exists (pq:], chdkusj, tSlyesj, ckM+esj). Step 3: Connect to settlement — villages (xk¡o) and their names (ikj-based names like tkujs vkyks ikj) emerge *around* johads. Step 4: Conclude — the setting (geology) determines where water can be stored, which determines where humans can live, making the land the primary agent of human geography. A wrong answer treating geology as passive background shows inability to apply the setting-atmosphere interplay analytically.

## DIAGNOSTIC_QUESTION_4
Analyze how the author uses contrasting sensory imagery (heat vs. coolness, scarcity vs. abundance) to build atmospheric tension in the opening paragraphs (pages 9-10).

## DIAGNOSTIC_ANSWER_4
The opening juxtaposes: "xjeh c<+rh" (increasing heat) vs. "tek ne?kksaVw xje gok" (cool breeze carrying moisture); "ladjk txg" (intense heat) vs. "fe^h dh nwjh ij fe^h" (workers resting on cool sand); "oqaQbZ dh xgjkbZ" (pond's breadth) vs. "py jgs esgurh dke" (difficult work). This tension mirrors the central conflict—water scarcity versus human ingenuity. A weak answer listing images without explaining their *contrastive function* reveals the student sees imagery as decoration, not as atmospheric architecture.

## DIAGNOSTIC_QUESTION_5
Evaluate the author's choice to embed technical hydro-geological knowledge (ikyjikuh/ikrkyikuh/jstk.khikuh) within a narrative of communal labor. Does this enhance or dilute the atmospheric immersion? Justify.

## DIAGNOSTIC_ANSWER_5
It enhances immersion by grounding atmosphere in empirical reality—the community's resilience is not romanticized but *engineered*. The classification appears mid-narrative (page 13) precisely when the johad's function is explained, making the reader *feel* the villagers' expertise. Dilution would occur if terms were abstract; here, "jstk.khikuh [kfM+;k i^h osQ dkj.k ikrkyhikuh ls vyx cuk jgrk gSA" ties knowledge to survival. A wrong judgment (e.g., "it breaks narrative flow") reveals the student expects atmosphere to be purely emotive, not epistemological.

## DIAGNOSTIC_QUESTION_6
Create a 4-line atmospheric vignette (in Hindi or English) depicting a johad at twilight, using at least two sensory details from the text and one hydro-geological term (ikyjikuh/ikrkyikuh/jstk.khikuh) to show how setting shapes mood.

## DIAGNOSTIC_ANSWER_6
Example: "jstk.khikuh ki sheetal parchhaiyan johad ke paani par ghir aayi, / mitti ki saunf gandh hawa mein tairti, / thake hue haathon ki 'Hkj-Hkj' ab sapno mein badli, / raat ka pehla tara paani mein doob gaya." A poor vignette using generic sunset imagery without textual anchoring (no "mitti ki gandh," no "Hkj-Hkj," no water-term) shows the student cannot synthesize setting elements into original atmospheric writing.

## COMMON_MISCONCEPTION
Students often treat "setting" as static backdrop (desert = hot, dry) and "atmosphere" as mere adjective-labeling (mood = sad/hopeful). In this text, the desert is *dynamic*—its geology ([kfM+;k i^h) *creates* the johad, the johad *creates* the village, the village *creates* the ritual. The atmosphere is not a label but a process: "xjeh de djus osQ fy, mQij 'kehu ij [kM+s yksx chp&chp esa eq_h Hkj jsr" — the collective action *is* the atmosphere. Students miss that setting and atmosphere are co-constitutive here: the physical necessity of water storage generates the emotional texture of communal labor.

## ON_FAILURE
If the student conflates setting with atmosphere or treats them as static: (1) Have them draw a two-column map: left column = physical details from text (e.g., "nl&ianzg gkFk uhps i^h"), right column = emotional effect (e.g., "ejQHkwfe esa jsr osQ d.k leku :i ls fc[kjs jgrs gSa"). (2) Ask: "If the impermeable layer were absent, how would the *feeling* of the village change?" forcing causal linking. (3) Assign a micro-write: "Describe the same johad site in two seasons—pre-monsoon desperation vs. post-monsoon abundance—using only details from the text." This makes the dynamic interplay visible.

## BUILDS_ON
c11_hin_v_cbse_02_001 (Context and Background) — provides the geographical/historical frame (Rajasthan's water crisis, traditional systems) necessary to situate the setting.

## LEADS_TO
c11_hin_v_cbse_02_004 (Character Analysis: Protagonist) — the protagonist's actions are shaped by the setting-atmosphere nexus; understanding the land's demands explains his choices.

## PREREQUISITE_NODE_IDS
c11_hin_v_cbse_02_001, c11_hin_v_cbse_02_002
## PREREQUISITE_REASONS
c11_hin_v_cbse_02_001: Provides essential background on Rajasthan's water geography, traditional johad systems, and the author's context—without this, the setting's cultural specificity is lost.
c11_hin_v_cbse_02_002: Establishes the narrative structure (exposition of the johad construction) which frames where and how setting details appear in the text sequence.

## FORWARD_NODE_IDS
c11_hin_v_cbse_02_004, c11_hin_v_cbse_02_006, c11_hin_v_cbse_02_008, c11_hin_v_cbse_02_007, c11_hin_v_cbse_02_013, c11_hin_v_cbse_02_015, c12_hin_a_cbse_06_003, c12_hin_v_cbse_02_003

## FORWARD_REASONS
c11_hin_v_cbse_02_004: The protagonist's characterization emerges from his interaction with the setting (e.g., his knowledge of jstk.khikuh guides the johad site selection).
c11_hin_v_cbse_02_006: The primary theme (community resilience through traditional ecological knowledge) is instantiated in the setting-atmosphere interplay analyzed here.
c11_hin_v_cbse_02_008: Imagery and metaphor (e.g., "ve`r tSlk ehBk ikuh" for sub-surface water) are the linguistic vehicles of atmosphere—this node identifies *what* they evoke, the next analyzes *how*.
c11_hin_v_cbse_02_007: Setting and atmosphere details (arid landscape, seasonal rhythms) are the backdrop against which secondary themes like gendered water labor become visible.  
c11_hin_v_cbse_02_013: Setting analysis (water-scarce landscape) is the ecological substrate of the chapter's argument.  
c11_hin_v_cbse_02_015: Setting and atmosphere knowledge grounds the discussion in the desert's physical and cultural context.  
c12_hin_a_cbse_06_003: Non-fiction setting analysis  
c12_hin_v_cbse_02_003: Class 11 foundation for setting-atmosphere analysis framework (sensory mapping, emotional valence).  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
none

## CHAIN_DESCRIPTION
c11_hin_v_cbse_02_001 -> c11_hin_v_cbse_02_003 -> c11_hin_v_cbse_02_004 (Context establishes geographical reality; Setting/Atmosphere analyzes its literary rendering; Protagonist's actions are interpreted through this rendered environment.)

## THIS_FORMULA
N/A - conceptual

## FORMULA_VARIABLES
N/A

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
conceptual

## CROSS_SUBJECT
c11_geography_water_resources | The text's classification of water sources (ikyjikuh, ikrkyikuh, jstk.khikuh) directly mirrors geography's classification of surface water, groundwater, and soil moisture—students can map literary terms to hydrological concepts.
c11_history_cultural_heritage | The johad construction rituals (kh[h ceremony, collective labor, community governance) reflect historical traditions of participatory resource management in pre-colonial Rajasthan, linking literary atmosphere to historical social structures.

## PREREQ_CONCEPT
Understanding that literary setting includes physical geography (landforms, climate, water systems) as active narrative elements, not passive background.

## PREREQ_BEFORE
Student must be able to locate Rajasthan on a map, describe its arid climate, and define "johad" as a traditional rainwater harvesting structure.

## PREREQ_STUCK
Review c11_hin_v_cbse_02_001 (Context and Background) for the geographical and cultural framework of the chapter.

## WORKED_EXAMPLE_1
PROBLEM: Analyze how the author establishes the oppressive heat of the desert setting in the first two paragraphs (pages 9-10) and converts it into an atmosphere of urgent collective action.
STEPS:
- Step 1: Identify all heat-related phrases — "xjeh c<+rh," "ladjk txg," "oqaQbZ dh xgjkbZ esa py jgs esgurh dke," "mQij 'kehu ij [kM+s yksx chp&chp esa eq_h Hkj jsr."
- Step 2: Categorize them — direct temperature description (xjeh c<+rh), physical sensation (ladjk txg), impact on labor (esgurh dke), human response (eq_h Hkj).
- Step 3: Trace the shift — heat (setting) → difficulty (atmosphere of struggle) → collective response (atmosphere of cooperation via "chp&chp esa eq_h Hkj").
- Step 4: Note the sensory bridge — "tek ne?kksaVw xje gok" (cool breeze) appears *only after* the collective labor begins, symbolically linking human action to environmental relief.
- Step 5: Synthesize — The setting (heat) is not merely described; it *provokes* the atmosphere (collective urgency), making the johad construction a direct atmospheric response to environmental pressure.
REASONING: This step-by-step tracing shows how setting details are selectively deployed to generate a specific emotional atmosphere, demonstrating the analytical skill of connecting physical description to narrative mood.
ANSWER: The author uses a cause-effect chain: extreme heat (setting) → laborious conditions (atmosphere of hardship) → synchronized collective effort (atmosphere of resilience) → cooling breeze (atmosphere of hope). The setting *drives* the atmospheric arc.

## WORKED_EXAMPLE_2
PROBLEM: Explain how the description of soil types and water-holding capacity (pages 12-13) functions as both scientific exposition and atmospheric device.
STEPS:
- Step 1: Locate the technical passage — "jsr osQ d.k cgqr gh ckjhd gksrs gSa... tgk¡ yxko gS] ogk¡ vyxko Hkh gksrk gSA" and the three water types (ikyjikuh, ikrkyikuh, jstk.khikuh).
- Step 2: Identify the scientific function — classifies hydro-geological conditions determining johad viability.
- Step 3: Identify atmospheric function — the variability ("tgk¡ yxko gS] ogk¡ vyxko") creates tension: not all land can hold water; survival depends on *knowing* the land.
- Step 4: Connect to narrative stakes — "ftl fe^h osQ d.k ijLij fpidrs gSa] os viuh txg Hkh NksM+rs gSa" — those who read the land's signs survive; the atmosphere becomes one of epistemic respect.
- Step 5: Show the blend — terms like "jstk.khikuh" are not footnotes; they are the villagers' vocabulary of survival, making the atmosphere *knowledge-saturated*.
REASONING: This demonstrates how the text refuses to separate "fact" from "feeling"—the hydro-geology *is* the emotional terrain, a key insight for senior secondary analysis.
ANSWER: The soil/water classification serves dual purpose: scientifically, it explains *where* johads work; atmospherically, it establishes a world where survival depends on reading the land's hidden signs, generating an atmosphere of reverence for traditional ecological knowledge.

## WORKED_EXAMPLE_3
PROBLEM: Compare the atmosphere of the johad construction phase (pages 14-16) with the post-construction phase (pages 18-19). How does the shift in setting (from building to maintaining) alter the emotional tone?
STEPS:
- Step 1: List construction-phase atmosphere markers — ritual (kh[h ceremony), rhythm (eq_h Hkj), celebration (fonkbZ, HksaV), collective identity (xk¡o lekt), anticipation (fe^h HklosQ).
- Step 2: List post-construction markers — "futh vkSj lkoZtfud laifÙk" (tradition and governance), "eqxhZ dh fpjifjfpr dgkuh" (mythologized history), seasonal cycle (iwjk xk¡o xks/wfy csyk), permanence ("jkr&Hkj vkSj vxys fnu&Hkj oqaQb;k¡ vkjke djsaxh").
- Step 3: Identify the setting shift — from *active transformation* of land (digging, compacting) to *cyclical stewardship* (desilting, governing, remembering).
- Step 4: Analyze atmospheric shift — construction = high-energy, ritualized, future-oriented ("fe^h HklosQ"); maintenance = cyclical, institutionalized, memory-anchored ("eqxhZ dh dgkuh").
- Step 5: Link to theme — the atmosphere evolves from *creating* resilience to *sustaining* it, mirroring the johad's own shift from project to infrastructure.
- Step 6: Conclude — the setting's temporal dimension (event vs. cycle) structures the atmosphere's emotional register (urgency vs. continuity).
REASONING: This comparison requires synthesizing setting details across the text's timeline, showing how atmosphere is not static but evolves with the physical environment's stage of human interaction.
ANSWER: Construction atmosphere is acute, communal, and forward-looking (ritualized labor building hope); maintenance atmosphere is chronic, institutional, and backward-looking (governance preserving memory). The setting shifts from "land being shaped" to "land shaping society," and the atmosphere follows.

## COMPETENCY_QUESTION_1
QUESTION: The author writes: "gj fnu lksus dk ,d vaMk nsus okyh eqxhZ dh fpjifjfpr dgkuh dks 'kehu ij mrkjrh gS oqaQbZA" (The johad rests on the foundation of a mythologized history that gives a daily salute to tradition). Using specific textual evidence, explain how the *physical setting* of the johad (its location, structure, water) makes this "mythologized history" atmospherically palpable rather than abstract.
COMPETENCY: Textual Evidence Integration and Atmospheric Analysis
STEPS:
- Step 1: Identify the physical setting details of the johad — "jsr osQ uhps lc txg [kfM+;k dh i^h," "NksVs O;kl dh oqaQbZ esa èkhjs&èkhjs fjl dj vk jgk ikuh," "ueh dh ek=kk rks ogk¡ gks pqdh o"kkZ ls r; gks xbZ gSA".
- Step 2: Identify the "mythologized history" markers — "eqxhZ dh fpjifjfpr dgkuh," "xk¡o lekt dh lkoZtfud 'kehu," "lky&Hkj oqaQb;ksa esa ikuh Hkjsxk".
- Step 3: Show the connection — the impermeable layer ([kfM+;k i^h) is a *geological fact* that becomes a *cultural foundation* because it enables the johad, which enables the village, which generates the history.
- Step 4: Explain atmospheric effect — the water you touch (ikuh), the soil you compact (mQij), the shade you sit in (jtr cw¡nas) are all *physical proofs* of the history, making the atmosphere one of tangible continuity.
ANSWER: The johad's physical reality — its water held by a specific geological layer, its embankments built by generations, its shade cooling the present — transforms "mythologized history" from story into sensory experience. The atmosphere becomes one of *embodied tradition*: you don't just hear the history; you drink it, sit in it, maintain it.
DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: A board exam question asks: "How does the author use the contrast between 'ikyjikuh' (surface water) and 'jstk.khikuh' (sub-surface water) to develop the atmosphere of *precarious abundance* in the desert setting?" Write a structured response (150 words) using the PEEL method (Point, Evidence, Explanation, Link).
COMPETENCY: Structured Analytical Writing for Board Examination
STEPS:
- Step 1 (Point): State the thesis — the contrast between visible, fleeting surface water and hidden, sustained sub-surface water creates an atmosphere where abundance is felt as both gift and responsibility.
- Step 2 (Evidence): Cite "ikyjikuh... èkjkry ij cgrk gS... ikrkyikuh... dq vksa esa fudkyk tkrk gS... jstk.khikuh [kfM+;k i^h osQ dkj.k ikrkyhikuh ls vyx cuk jgrk gSA" and "fnu Hkj esa ,d oqaQbZ eqf'dy ls bruk gh ikuh tek dj ikrh gS".
- Step 3 (Explanation): Surface water (ikyjikuh) is theatrical but unreliable — "unh, rkykc vkfn esa jksdk tkrk gSA" — creating anxiety. Sub-surface water (jstk.khikuh) is invisible but dependable — "ikuh bruk fxjs fd ik¡p vaxqy Hkhrj lek tk, rks ml fnu dh o"kkZ dks ik¡p vaxqy jstks dgsaxs" — creating trust. The atmosphere lives in the tension between seeing-and-losing vs. knowing-and-keeping.
- Step 4 (Link): This tension mirrors the community's existential condition — they must constantly translate visible scarcity into managed abundance through collective knowledge, making the atmosphere one of *vigilant stewardship*.
ANSWER: The author juxtaposes ikyjikuh (surface water: visible, seasonal, lost to evaporation — "unh, rkykc vkfn esa jksdk tkrk gSA") with jstk.khikuh (sub-surface water: hidden, sustained by impermeable layers — "[kfM+;k i^h osQ dkj.k... feydj viuk fof'k"V :i [kks nsrk gSA") to craft an atmosphere of precarious abundance. Surface water teases with presence then vanishes, generating anxiety; sub-surface water rewards knowledge with reliability, generating trust. The community's survival depends on reading the land to access the latter — "ftl fe^h osQ d.k ijLij fpidrs gSa, os viuh txg Hkh NksM+rs gSa". Thus, abundance is not a given but a covenant between geology and human attention. The atmosphere becomes one of vigilant stewardship: every johad is a promise kept between the impermeable layer and the collective hand that maintains it.
DIFFICULTY: hard