## DEFINITION
The primary theme of a literary work is its central, unifying idea — a universal insight about human experience, society, or life that the author conveys through plot, characters, and setting. The message is the author's specific stance or lesson derived from that theme, often reflecting a critique or affirmation of social values.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student can independently identify the primary theme across all three stories in the chapter, articulate a coherent thematic statement supported by textual evidence from each story, and explain how the author's narrative choices (characterization, conflict, symbolism) reinforce that theme.

## SCOPE_BOUNDARY
This node covers identifying and analyzing the primary theme and message of the three stories ("ckyd cp x;k", "?kM+h osQ iq”ksZ", "<sys pqu yks") in Chapter 11 of Class 12 Hindi Antra. It does NOT cover secondary themes, detailed literary device analysis, or grammar/vocabulary — those are addressed in subsequent nodes.

## WALKTHROUGH
Imagine you are asked: "What is Premchand really trying to tell us through these three very different stories?" Start by recalling the core conflict in each story: a boy fleeing an oppressive school, a poor man's time being stolen by the rich, a ghost choosing a beggar's skull over a king's. Notice the pattern — each story exposes a system (education, time/labor, mortality) that dehumanizes the vulnerable. The primary theme emerges when you connect these patterns: **Institutional and social structures often crush individual dignity, and true humanity lies in resisting that dehumanization.** The message is a call to recognize this injustice and value human worth over systemic efficiency. To begin, list the protagonist's struggle in each story, then ask: "What does the author want me to feel about this struggle?" That emotional-intellectual response is your gateway to theme.

## DIAGNOSTIC_QUESTION_1
Define "primary theme" in your own words and give one example from any story you have read previously.

## DIAGNOSTIC_ANSWER_1
A primary theme is the central, overarching idea that runs through an entire work, expressed as a complete thought (e.g., "Education that ignores a child's individuality destroys creativity"). A wrong answer would be a single word like "education" or a plot summary like "a boy runs away from school" — this reveals the student confuses theme with topic or plot.

## DIAGNOSTIC_QUESTION_2
In "ckyd cp x;k", the boy runs away because he cannot bear the teacher's mechanical questioning. Explain what this incident reveals about the story's theme regarding education.

## DIAGNOSTIC_ANSWER_2
The incident shows that the education system prioritizes rote compliance over the child's inner growth; the theme is that **true education must nurture the individual's spirit, not suppress it**. A wrong answer might focus only on the boy's fear or the teacher's cruelty without linking it to a broader statement about education's purpose — this reveals the student cannot move from specific event to universal insight.

## DIAGNOSTIC_QUESTION_3
Read this short passage: "The factory owner timed every bathroom break; workers who exceeded two minutes lost half a day's wages." Identify the theme this passage illustrates and connect it to the theme of "?kM+h osQ iq”ksZ".

## DIAGNOSTIC_ANSWER_3
The passage illustrates **the exploitation of the poor's time/labor by the powerful** — the same theme as "?kM+h osQ iq”ksZ" where the rich measure the poor's time to extract maximum work. A wrong answer would say "it's about factory rules" or "time management" — missing the power dynamic and the thematic link to Premchand's story.

## DIAGNOSTIC_QUESTION_4
Compare how "ckyd cp x;k" and "<sys pqu yks" use different narrative strategies (realistic vs. folk-tale) to convey a similar message about human dignity. Which strategy do you find more effective and why?

## DIAGNOSTIC_ANSWER_4
"ckyd cp x;k" uses realistic detail (the teacher's questions, the boy's physical fear) to make the oppression tangible; "<sys pqu yks" uses allegory (ghost choosing a skull) to show dignity's universality beyond social rank. Both argue that **human worth is not determined by external systems**. A weak answer would only list differences without synthesizing the shared message, revealing inability to compare thematic techniques.

## DIAGNOSTIC_QUESTION_5
A student claims: "The message of all three stories is simply 'life is unfair.'" Evaluate this interpretation. Is it adequate? Why or why not?

## DIAGNOSTIC_ANSWER_5
The interpretation is **inadequate** because it reduces a critical social critique to a passive observation. Premchand doesn't just say "life is unfair" — he shows *how* specific systems (school, labor, mortality) are structured to dehumanize, implying they *can* be changed. A student who accepts this oversimplification misses the author's activist intent and the stories' call for empathy and reform.

## DIAGNOSTIC_QUESTION_6
Write a 4-line micro-story (in Hindi or English) that conveys the primary theme of this chapter: "Systems that ignore individual dignity ultimately diminish us all." Use a setting and characters of your choice.

## DIAGNOSTIC_ANSWER_6
A good answer creates a miniature narrative showing a system (e.g., a hospital triage algorithm, a corporate appraisal) overriding human need, and a moment where the system's rigidity harms both the victim and the enforcer. A poor answer would write a generic sad event without systemic critique, revealing the student hasn't internalized the theme's structural dimension.

## COMMON_MISCONCEPTION
Students often think "theme = moral" and write "The theme is: we should respect children" or "The theme is: don't waste time." This is wrong because **a theme is an observation about reality, not a command**. Premchand shows *how* systems disrespect children; he doesn't merely say "respect them." Another error: treating each story's theme as separate. The chapter's primary theme is the *common thread* across all three — students must synthesize, not list.

## ON_FAILURE
If a student cannot synthesize the primary theme, guide them through this 3-step remediation: (1) Re-read the "Before You Read" section (c12_hin_a_cbse_11_001) to recall the author's stated intent. (2) Use the character analysis nodes (c12_hin_a_cbse_11_004, 005) to list each protagonist's core conflict. (3) Complete a "Theme Triangle" worksheet: vertex A = conflict in story 1, vertex B = conflict in story 2, vertex C = conflict in story 3; the center = what all three share. Then re-attempt Diagnostic Question 4.

## BUILDS_ON
This node builds on the ability to identify a single story's theme (Class 11 skill) and extends it to synthesizing a unifying theme across multiple texts by the same author.

## LEADS_TO
This node enables the analysis of secondary themes (c12_hin_a_cbse_11_007) and the critical thinking node (c12_hin_a_cbse_11_013) where students evaluate competing interpretations.

## PREREQUISITE_NODE_IDS
c12_hin_a_cbse_11_001, c12_hin_a_cbse_11_002, c12_hin_a_cbse_11_003, c12_hin_a_cbse_11_004, c12_hin_a_cbse_11_005, c11_hin_ar_cbse_11_006
## PREREQUISITE_REASONS
c12_hin_a_cbse_11_001: Provides author background and context essential for understanding his thematic concerns.
c12_hin_a_cbse_11_002: Plot knowledge is needed to trace how events develop the theme.
c12_hin_a_cbse_11_003: Setting details (colonial school, feudal village, folk world) ground the theme in specific socio-historical realities.
c12_hin_a_cbse_11_004: Protagonist's internal struggle embodies the theme; without character analysis, theme remains abstract.
c12_hin_a_cbse_11_005: Supporting characters (teacher, rich men, ghost) represent the systemic forces the theme critiques.
c11_hin_ar_cbse_11_006: Class 11 theme-analysis practice provides the methodological foundation for multi-text synthesis.

## FORWARD_NODE_IDS
c12_hin_a_cbse_11_007, c12_hin_a_cbse_11_008, c12_hin_a_cbse_11_009, c12_hin_a_cbse_11_013, c12_hin_a_cbse_11_012, c12_hin_a_cbse_11_014, c12_hin_a_cbse_11_015

## FORWARD_REASONS
c12_hin_a_cbse_11_007: Secondary themes (e.g., gender, tradition) branch out from the primary theme established here.
c12_hin_a_cbse_11_008: Imagery and metaphor are the linguistic vehicles of the theme; analysis requires knowing the theme first.
c12_hin_a_cbse_11_009: Irony and symbolism deepen the theme; their interpretation depends on a clear thematic anchor.
c12_hin_a_cbse_11_013: Critical thinking tasks (e.g., "Compare Premchand's view of education with Tagore's") require a solid primary theme as reference point.
c12_hin_a_cbse_11_012: Primary theme guides thematic inferences.  
c12_hin_a_cbse_11_014: Supplies the primary theme (education vs. ritual) that forms the Link in most answers.  
c12_hin_a_cbse_11_015: Primary theme is the backbone of any thematic discussion.  

## CROSS_SUBJECT_PREREQS
c11_hin_ar_cbse_11_006, c11_hin_v_cbse_01_006
## CROSS_SUBJECT_REASONS
c11_hin_ar_cbse_11_006: Theme analysis in Class 11 Antra (Chapter 11) likely covered a Premchand story, giving direct practice in identifying his recurring concerns.
c11_hin_v_cbse_01_006: Vitan's theme node may have addressed social realism, providing a complementary perspective on how literature reflects societal structures.

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_11_006 -> c12_hin_a_cbse_11_006 -> c12_hin_a_cbse_11_007

## THIS_FORMULA
Thematic Statement = (Recurring Conflict across Texts) + (Author's Implicit Judgment) + (Universal Human Implication)

## FORMULA_VARIABLES
- Recurring Conflict: The core struggle repeated in each story (e.g., individual vs. dehumanizing system)
- Author's Implicit Judgment: The textual evidence showing the author's sympathy/critique (e.g., narrative tone, character fate)
- Universal Human Implication: What the pattern reveals about human nature/society beyond the specific stories

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
analytical

## CROSS_SUBJECT
N/A | Premchand's stories reflect colonial-era education policies and feudal labor exploitation — history provides the factual backdrop for the theme's social critique.
 N/A | The theme of systemic dehumanization connects to sociological concepts of power, class, and institutional violence — sociology offers theoretical frameworks to analyze the stories' social dynamics.
 N/A | "?kM+h osQ iq”ksZ" directly illustrates surplus labor extraction — economics explains the material basis of the time-theft theme.
## PREREQ_CONCEPT
Ability to move from "what happens" (plot) to "what it means" (theme) using textual evidence.

## PREREQ_BEFORE
Student must have completed plot summary, character sketches, and setting analysis for all three stories in this chapter.

## PREREQ_STUCK
If stuck, revisit the "Character Analysis: Protagonist" node (c12_hin_a_cbse_11_004) and re-identify each protagonist's moment of greatest crisis — the theme lives in that crisis.

## WORKED_EXAMPLE_1
PROBLEM: Using the "Theme Triangle" method, derive the primary theme of the chapter from the three stories' central conflicts.
STEPS:
- Step 1: Identify the protagonist's core conflict in each story. For "ckyd cp x;k": the boy's spirit vs. the school's mechanical demands. For "?kM+h osQ iq”ksZ": the poor man's time/life vs. the rich's measurement/exploitation. For "<sys pqu yks": the ghost's choice — a beggar's skull (dignity in poverty) vs. a king's skull (power in death).
- Step 2: Abstract each conflict to a structural level. Story 1: Institution vs. Individuality. Story 2: Powerful vs. Powerless (time as resource). Story 3: Social status vs. Essential humanity (death as equalizer).
- Step 3: Find the common denominator. All three show a system (school, economy, mortality/hierarchy) that reduces humans to functions/objects, and a moment where the victim's humanity asserts itself (running away, questioning, ghost's choice).
- Step 4: Formulate the thematic statement. "Premchand reveals how institutional and social structures systematically strip individuals of dignity, and suggests that true humanity emerges when the marginalized resist or transcend these structures."
- Step 5: Verify against the author's stated intent in the chapter introduction ("f'k{kk gesa cPps ij yknuh ugha pkfg..."). The statement aligns: education shouldn't crush, time shouldn't be stolen, death shouldn't be hierarchized.
REASONING: The Theme Triangle forces synthesis by making the student compare conflicts at a structural level, not just plot level. Step 5 anchors the interpretation in authorial intent, avoiding over-reading.
ANSWER: Primary Theme: **Systemic dehumanization vs. irreducible human dignity.** Message: **Societies must restructure institutions (education, labor, social hierarchy) to serve human growth, not the other way around.**

## WORKED_EXAMPLE_2
PROBLEM: A board exam question asks: "How does Premchand use the contrast between the teacher's questions and the boy's silence in 'ckyd cp x;k' to develop the theme of education?" Write a structured answer using the PEEL method (Point, Evidence, Explanation, Link).
STEPS:
- Step 1 (Point): The contrast exposes the fundamental mismatch between the education system's mechanical goals and the child's organic need for understanding.
- Step 2 (Evidence): The teacher asks factual questions (history dates, geometry, rulers' names) while the boy experiences physical fear (sweating, trembling) and mental blankness. The boy's final answer — "I will become a wanderer" — rejects the system entirely.
- Step 3 (Explanation): The questions represent "knowledge as commodity" — measurable, hierarchical, detached from life. The boy's silence and flight represent "knowledge as lived experience" — intuitive, embodied, inseparable from self. The teacher's persistence despite the boy's distress shows the system's indifference to the learner.
- Step 4 (Link): This microcosm mirrors the chapter's primary theme: an institution (school) designed to serve society ends up crushing the very individuals it should nurture. The boy's escape is both tragedy (lost schooling) and triumph (preserved self).
- Step 5 (Polish): Combine into a 4-5 sentence board answer with key terms: "mechanical rote learning", "child's psyche", "alienation", "Premchand's humanism".
REASONING: PEEL ensures each claim is textually grounded and analytically developed — exactly what CBSE marking schemes reward. The link step explicitly connects the scene to the chapter's primary theme.
ANSWER: Premchand juxtaposes the teacher's factual, hierarchical questioning with the boy's visceral fear and ultimate rejection to critique colonial education as a dehumanizing machine. The questions — dates, rulers, geometry — symbolize knowledge stripped of meaning, imposed on a child whose body and mind rebel. The boy's answer, "I will become a wanderer," is not mere truancy but a radical refusal to be molded into a cog. This scene encapsulates the chapter's primary theme: systems that ignore individual dignity destroy the very humanity they claim to develop.

## WORKED_EXAMPLE_3
PROBLEM: Synthesize a comparative thematic statement that includes all three stories and references at least two literary devices (from upcoming nodes) that reinforce the theme.
STEPS:
- Step 1: Re-state the primary theme from Worked Example 1: Systemic dehumanization vs. irreducible human dignity.
- Step 2: Identify a literary device in each story that amplifies this theme. Story 1: Irony — the teacher thinks he is educating, but he is actually driving the child away from learning. Story 2: Symbolism — the "watch" and "measuring time" symbolize capitalist/feudal quantification of human life. Story 3: Allegory — the ghost's skull choice allegorizes the ultimate equality of death, mocking social hierarchy.
- Step 3: Explain how each device serves the theme. Irony exposes the system's self-defeat. Symbolism makes abstract exploitation concrete. Allegory universalizes the critique beyond history.
- Step 4: Draft the integrated statement. "Through irony in 'ckyd cp x;k', symbolism in '?kM+h osQ iq”ksZ', and allegory in '<sys pqu yks', Premchand constructs a layered indictment of structures that quantify and categorize human beings, asserting that dignity survives only when individuals or their representations refuse systemic categorization."
- Step 5: Check against CBSE competency requirements: multi-text, multi-device, analytical, uses NCERT terminology (irony, symbolism, allegory).
- Step 6: Anticipate follow-up: This statement prepares the student for c12_hin_a_cbse_11_008/009 where these devices are analyzed in depth.
REASONING: This example models the higher-order synthesis expected in CBSE competency questions and JEE/NEET-style humanities passages (e.g., CUET). It bridges theme analysis with literary device analysis — a key cross-node skill.
ANSWER: Premchand employs irony (the educator destroying education), symbolism (time as a tool of oppression), and allegory (death as the great leveler) across the three stories to argue that any system — pedagogical, economic, or social — which reduces humans to measurable units inevitably fails, because human dignity resides in the unquantifiable essence that such systems cannot capture.

## COMPETENCY_QUESTION_1
QUESTION: The chapter's introduction states: "फ'क{kk gesa cPps ij yknuh ugha pkfg, cfYd mlosQ ekul esa f'k{kk dh #fp iSnk djus okys cht Mkys tk,¡" (Education should not be imposed on children, but should develop the quality inherent in them). Using evidence from "ckyd cp x;k" AND one other story, explain how Premchand dramatizes the violation of this principle in different social domains.
COMPETENCY: Textual evidence integration + cross-story thematic synthesis
STEPS:
- Step 1: Identify the principle: education/development must be internal, not external imposition.
- Step 2: In "ckyd cp x;k", show how the school imposes external knowledge (dates, names) ignoring the boy's inner world (fear, imagination, desire for freedom).
- Step 3: In "?kM+h osQ iq”ksZ", show how the rich impose their time-measurement on the poor, treating the poor's life as raw material for the rich's schedule — a violation of the poor's right to their own time/life.
- Step 4: In "<sys pqu yks", show how social hierarchy imposes identity (king vs. beggar) even in death, but the ghost's choice subverts this imposition by valuing the beggar's skull (simplicity, truth) over the king's (power, deceit).
- Step 5: Conclude: All three domains (education, economy, social ritual) impose external structures that erase individual essence; Premchand's dramatization makes this violence visible.
ANSWER: In "ckyd cp x;k", the teacher's rote questioning imposes dead facts on a living child, causing flight — the system rejects the child's innate curiosity. In "?kM+h osQ iq”ksZ", the rich measure the poor's time like a commodity, imposing their schedule on the poor's biological and emotional rhythms — the poor's life is not their own. In "<sys pqu yks", the ghost rejects the king's skull (symbol of imposed grandeur) and chooses the beggar's (symbol of authentic existence), showing that true worth lies in what is internally cultivated, not externally imposed. Premchand thus dramatizes the same violation across pedagogical, economic, and metaphysical domains.
DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: A critic argues: "Premchand's primary theme in this chapter is not social critique but spiritual resignation — the ghost's choice of the beggar's skull shows that only in death do we escape hierarchy." Evaluate this interpretation using textual evidence from all three stories. Does the text support resignation or resistance?
COMPETENCY: Critical evaluation of competing interpretations + multi-textual evidence
STEPS:
- Step 1: Acknowledge the critic's point: the ghost story does suggest death equalizes.
- Step 2: Counter with "ckyd cp x;k": the boy's running away is active resistance, not resignation. He rejects the system physically.
- Step 3: Counter with "?kM+h osQ iq”ksZ": the narrator's angry exposition ("osn'kkL=kK èkekZpk;ks± dk gh dke gS...") is a call to awareness, not acceptance. The text urges readers to recognize the theft of time.
- Step 4: Re-read the ghost story: the ghost's choice is an active subversion — it *chooses* the beggar, mocking the king. That's resistance in the metaphysical realm.
- Step 5: Synthesize: The chapter's trajectory moves from resistance (boy), to exposé (time theft), to subversion (ghost). Resignation is never the final note; the author's voice is polemical.
- Step 6: Final judgment: The critic cherry-picks one story's ending and ignores the chapter's overall thrust. The primary theme is resistance to dehumanization, not resignation to it.
ANSWER: The interpretation is flawed. While the ghost story acknowledges death's equality, the ghost's *active choice* of the beggar's skull is a final act of defiance against hierarchy. In "ckyd cp x;k", the boy's escape is physical resistance. In "?kM+h osQ iq”ksZ", the narrator's passionate rhetoric ("rqEgsa blls D;k\") demands readerly resistance. The chapter's primary theme is **resistance to systemic dehumanization**, evidenced by the protagonists' refusal to be fully captured by the systems that oppress them. Resignation would silence the narrator; instead, the text amplifies the voices of the marginalized.
DIFFICULTY: hard