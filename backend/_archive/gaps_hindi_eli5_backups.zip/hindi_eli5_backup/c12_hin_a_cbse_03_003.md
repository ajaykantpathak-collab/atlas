## DEFINITION
Setting in poetry refers to the time, place, and physical environment where the poem's action or reflection occurs, while atmosphere is the emotional mood or feeling evoked in the reader through the poet's choice of imagery, sound devices, and diction. In Class 12, we analyze how setting and atmosphere work together to reveal the poem's deeper thematic concerns.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student can identify the specific spatial and temporal markers in both poems of this chapter, explain how the poet constructs atmosphere through sensory imagery and sound patterns, and evaluate how setting-atmosphere interplay conveys the central theme of human resilience or nature's indifference.

## SCOPE_BOUNDARY
This node covers setting and atmosphere analysis exclusively for the two poems in Chapter 3 ("nhi vosQyk" and "eSaus ns[kk] ,d cw¡n"). It does not cover character analysis, thematic synthesis across chapters, or grammatical structures — those are addressed in sibling nodes.

## WALKTHROUGH
Imagine you walk into a dark room and hear a single flute playing — the darkness is the setting, the eerie calm is the atmosphere. Now open "nhi vosQyk": the poem opens with a village night ("nhi") that is "Lusg" (dark), "xoZ" (fearful), yet "enekrk" (beloved). Ask yourself: why does the poet call a terrifying night beloved? In "eSaus ns[kk] ,d cw¡n", the setting shifts to a garden where a flower changes colour before your eyes. The atmosphere moves from wonder ("u'ojrk") to melancholy. To begin, read each poem aloud twice — first for the physical scene (where/when), second for the emotional tone (how it feels). Mark every word that appeals to sight, sound, touch. The key insight: in this poet's work, setting is never passive backdrop; it actively shapes the speaker's philosophical stance.

## DIAGNOSTIC_QUESTION_1
What is the primary setting of the poem "nhi vosQyk" in terms of time and place?

## DIAGNOSTIC_ANSWER_1
The primary setting is a village night ("nhi") in rural India, suggested by images like "lkxj" (village), "fojkV~" (darkness), and the collective voice addressing the night. A wrong answer like "a city street" or "daytime" reveals the student cannot locate basic spatial-temporal markers — they are reading for plot rather than setting.

## DIAGNOSTIC_QUESTION_2
In "nhi vosQyk", the speaker says "ij bldks Hkh iafDr dks ns nks". Explain in your own words why the speaker asks the night to be given to "iafDr" (consciousness/awareness) despite calling it "Lusg" and "xoZ".

## DIAGNOSTIC_ANSWER_2
The speaker embraces the night's darkness and fear because confronting them directly ("iafDr esa 'kkfey dj yksA") transforms terror into empowerment — awareness integrates the night's harsh reality into human consciousness, making it "beloved" through acceptance. A wrong answer like "the speaker is suicidal" or "it's a metaphor for death" shows the student confuses atmosphere (fear) with theme (resilience) and misses the transformative logic.

## DIAGNOSTIC_QUESTION_3
Identify three sensory images in the first stanza of "eSaus ns[kk] ,d cw¡n" and state whether each appeals to sight, touch, or sound. Then explain how together they establish the poem's initial atmosphere.

## DIAGNOSTIC_ANSWER_3
Images: "lkxj osQ >kx ls" (sight — visual spread), "jax xbZ {k.kHkj" (sight — colour change), "<yrs lwjt dh vkx ls" (touch/sight — delicate motion of wind). Together they create an atmosphere of quiet wonder at nature's subtle, almost magical transformation. A wrong answer listing "sound of wind" or "smell of flower" reveals the student imposes senses not in the text — a common error of projecting rather than observing.

## DIAGNOSTIC_QUESTION_4
Compare the role of darkness in "nhi vosQyk" and "eSaus ns[kk] ,d cw¡n". How does the same physical condition (absence of light) generate opposite atmospheres in the two poems?

## DIAGNOSTIC_ANSWER_4
In "nhi vosQyk", darkness ("fojkV~", "Lusg") is an external, collective challenge that the community faces together — atmosphere is communal defiance. In "eSaus ns[kk] ,d cw¡n", darkness ("fojkV~ osQ lEeq[k") is a backdrop that makes the flower's colour-change visible — atmosphere is solitary awe. A wrong answer saying "both are scary" misses the shift from social to individual, external to internal — the core analytical move for this chapter.

## DIAGNOSTIC_QUESTION_5
Evaluate the claim: "The atmosphere in 'nhi vosQyk' is created primarily through sound devices (repetition, rhythm) rather than visual imagery." Defend or refute with evidence.

## DIAGNOSTIC_ANSWER_5
Refute. While the refrain "nhi vosQyk Lusg Hkjk gS xoZ Hkjk enekrk" uses repetition and rhythm to build hypnotic intensity, the atmosphere of "xoZ" (fear) and "enekrk" (beloved) is grounded in concrete visual/tactile images: "xhr" (thorn), "eksrh" (straw), "vf}rh;" (lightning), "eèkq" (lamp), "xksjl" (wet), "vaoqQj" (storm). Sound amplifies but does not replace imagery. A wrong answer agreeing reveals over-reliance on "poetic devices" checklists without textual evidence.

## DIAGNOSTIC_QUESTION_6
Write a four-line stanza in Hindi that establishes a setting of a railway platform at midnight and an atmosphere of quiet loneliness, using at least two sensory images and one sound device.

## DIAGNOSTIC_ANSWER_6
Example:
"plVfj;k dk ;g vkjkxl] rkfRod dk lkj ugh
tkudkjh dh dhwoni ugh] gh lqus x;h
,d rkfRod pk¡n dk Hkko] tkx:d dk vkjs[k
vusd'kq dj x;k gS] lcls vyx gS mldk ns[k"
A poor answer uses abstract words ("loneliness", "sadness") without sensory anchors — showing the student cannot translate analysis into creation.

## COMMON_MISCONCEPTION
Students treat "setting" as merely the background label (e.g., "village night") and "atmosphere" as a single adjective (e.g., "scary"). In this chapter, the misconception is fatal because both poems use the *same* setting element (night/darkness) to generate *diametrically opposite* atmospheres (communal resilience vs solitary wonder). Students write "darkness creates fear in both" and lose marks for missing the poet's philosophical contrast. They also confuse the *speaker's* attitude with the *reader's* atmosphere — the speaker in "nhi vosQyk" claims the night is "enekrk", but the reader feels awe at human courage, not comfort.

## ON_FAILURE
1. Re-read both poems aloud, physically underlining every noun/adjective that names a place, time, light condition, or weather element — this forces setting identification.
2. For each underlined word, write one sentence: "This word makes me feel ____ because ____" — this separates reader's atmosphere from speaker's statement.
3. Create a two-column table: Column A = Setting Element (e.g., "lightning"), Column B = Atmosphere Effect (e.g., "sudden terror, then clarity"). Do this for 5 elements per poem.
4. Re-attempt Diagnostic Question 4. If still stuck, revisit Class 11 node c11_hin_ar_cbse_01_003 for the basic setting/atmosphere distinction.

## BUILDS_ON
Class 11 skill of distinguishing physical setting from emotional atmosphere in a single poem (c11_hin_ar_cbse_01_003).

## LEADS_TO
Character Analysis (c12_hin_a_cbse_03_004) — the speaker's relationship with setting reveals character; and Theme analysis (c12_hin_a_cbse_03_006) — setting-atmosphere interplay is the primary vehicle for theme in these poems.

## PREREQUISITE_NODE_IDS
c12_hin_a_cbse_03_001, c12_hin_a_cbse_03_002, c11_hin_ar_cbse_01_003
## PREREQUISITE_REASONS
c12_hin_a_cbse_03_001: Provides biographical/historical context of the poet (vKs;/Nagarjun) essential to understand why rural night and flower are chosen settings.
c12_hin_a_cbse_03_002: Establishes narrative structure — the poems' stanzaic progression *is* the temporal setting; you cannot analyze atmosphere without knowing where the poem turns.
c11_hin_ar_cbse_01_003: The foundational Class 11 node where students first learned to separate setting (where/when) from atmosphere (mood) — without this, Class 12 comparative analysis is impossible.

## FORWARD_NODE_IDS
c12_hin_a_cbse_03_004, c12_hin_a_cbse_03_006, c12_hin_a_cbse_03_008, c12_hin_a_cbse_03_012

## FORWARD_REASONS
c12_hin_a_cbse_03_004: The speaker in both poems is defined by their response to setting — the collective "we" in "nhi vosQyk" and the solitary "I" in "eSaus ns[kk]" — character analysis requires this setting-attitude link.
c12_hin_a_cbse_03_006: The primary theme (human dignity against nature's indifference) is conveyed *through* the setting-atmosphere dialectic; theme node cannot be taught without this analysis.
c12_hin_a_cbse_03_008: Setting/atmosphere (hilltop at dusk, abstract "soul-space") provides the physical ground for imagery.  
c12_hin_a_cbse_03_012: Setting/atmosphere provides inferential clues  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
No cross-subject prerequisite nodes exist in the provided Class 11 Hindi-only list.

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_01_003 -> c12_hin_a_cbse_03_003 -> c12_hin_a_cbse_03_004

## THIS_FORMULA
N/A - conceptual

## FORMULA_VARIABLES
N/A

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
conceptual

## CROSS_SUBJECT
N/A | The poet vKs; (Nagarjun) belongs to the Progressive Writers' Movement; his use of rural night setting reflects the movement's focus on peasant consciousness — a direct link to History Chapter 3 "Nationalism in India" cultural dimensions.
 N/A | The poem "nhi vosQyk" depicts a nucleated village settlement ("lkxj") with collective night watch ("iafDr") — connects to Geography Chapter 4 "Human Settlements" patterns of rural community cohesion.
 N/A | The imagery "xhr" (thorn), "eksrh" (straw), "lwjt" (wind) reflects agrarian ecology; the poem's atmosphere of resilience mirrors Economics Chapter 2 "Indian Economy 1950-1990" discussion of village self-reliance.
## PREREQ_CONCEPT
Distinguishing physical setting (time/place) from emotional atmosphere (mood) in a literary text.

## PREREQ_BEFORE
Student must be able to list 3+ concrete setting details from a poem and name the dominant atmosphere in one word.

## PREREQ_STUCK
Review "Setting vs Atmosphere" table in c11_hin_ar_cbse_01_003 and practice on a new unseen poem.

## WORKED_EXAMPLE_1
PROBLEM: Analyze how the setting of "village night" in "nhi vosQyk" is constructed through specific lexical choices in the first two stanzas, and how this setting generates the atmosphere of "collective defiance".

STEPS:
- Step 1: Identify all spatial-temporal markers in Stanza 1: "nhi" (night), "Lusg" (dark), "xoZ" (fearful), "enekrk" (beloved), "iafDr" (consciousness). Note: "nhi" names time, "Lusg/xoZ" describe light/emotion, "iafDr" introduces human agency.
- Step 2: Identify Stanza 2 markers: "xhr" (thorn), "eksrh" (straw), "vf}rh;" (lightning), "eèkq" (lamp), "xksjl" (wet), "vaoqQj" (storm). These are concrete rural night images — thorny paths, straw huts, lightning, oil lamps, wet mud, storm.
- Step 3: Classify each marker as setting (physical) or atmosphere (emotional). "xhr", "eksrh", "eèkq", "xksjl", "vaoqQj" are setting. "vf}rh;" is both (physical lightning, emotional shock). The refrain "nhi vosQyk Lusg Hkjk gS xoZ Hkjk enekrk" is atmosphere statement.
- Step 4: Trace the logic: The poem lists harsh physical realities (thorns, storm, darkness) but the refrain *revalues* them as "enekrk" because "iafDr" (awareness) transforms suffering into strength. The atmosphere is not "fear" but "defiance through acceptance".
- Step 5: Verify with the poem's structure: The refrain repeats 4 times — each repetition adds a new setting image but the same atmosphere conclusion. This incremental building proves atmosphere is *constructed*, not given.

REASONING: This step-by-step forces the student to move from word-level evidence to structural pattern — the exact skill Board exams reward in 5-mark "explain with reference to context" questions.

ANSWER: The village night setting is built through a catalogue of rural hardships (thorns, straw huts, storm, darkness) which the refrain repeatedly reinterprets as "beloved" because conscious acceptance ("iafDr") converts passive suffering into active resilience. The atmosphere of collective defiance emerges from the tension between the harsh setting details and the speaker's deliberate revaluation.

## WORKED_EXAMPLE_2
PROBLEM: In "eSaus ns[kk] ,d cw¡n", the setting shifts from a garden path ("lkxj osQ >kx ls") to the flower itself ("cw¡n"). Explain how this zoom-in shifts the atmosphere from "wonder" to "melancholy".

STEPS:
- Step 1: Locate the two settings: Stanza 1 — "lkxj osQ >kx ls" (from behind the village/garden hedge), a wide view. Stanza 2 — "lwus fojkV~ osQ lEeq[k" (from the very lap of darkness), an intimate view inside the flower's space.
- Step 2: Identify the atmosphere words for each: Stanza 1 — "u'ojrk osQ nkx ls" (from the edge of wonder), "mUekspu" (astonishment). Stanza 2 — "jax xbZ {k.kHkj" (colour changed), "<yrs lwjt dh vkx ls" (from the touch of gentle wind) — fragility, transience.
- Step 3: Analyze the verb shift: "ns[kk" (saw — past, completed) vs "xbZ" (changed — process, ongoing). The first setting allows a moment of capture; the second setting reveals inevitable change.
- Step 4: Connect to the central image: The flower's colour change ("jax xbZ") is caused by "lwjt" (wind) — an external force. In the wide setting, the wind is gentle ("<yrs"); in the close setting, it alters the flower's identity. Atmosphere shifts from "wonder at beauty" to "melancholy at impermanence".
- Step 5: Synthesize: The zoom-in is a metaphor for deepening knowledge — the more closely you observe nature, the more you see its fragility. The atmosphere evolves because the setting narrows.

REASONING: This example teaches the "setting zoom" technique — a classic poetic strategy where spatial narrowing mirrors thematic deepening. Board exams often ask "How does the poet's focus change?" — this is the model answer structure.

ANSWER: The poem begins with a distanced setting ("from behind the hedge") where the flower's colour-change appears as wondrous spectacle ("u'ojrk", "mUekspu"). As the setting zooms into "the lap of darkness" surrounding the flower, the same colour-change is revealed as fragile response to wind ("<yrs lwjt dh vkx ls"), shifting atmosphere to melancholy at beauty's impermanence. The spatial narrowing enacts the thematic realization.

## WORKED_EXAMPLE_3
PROBLEM: Compare how both poems use "darkness" (fojkV~/Lusg/nhi) as a setting element but generate opposite atmospheres. Write a structured comparative paragraph using the PEEL method (Point, Evidence, Explanation, Link).

STEPS:
- Step 1 (Point): In "nhi vosQyk", darkness is a communal challenge that strengthens human bonds; in "eSaus ns[kk] ,d cw¡n", darkness is a solitary backdrop that heightens individual perception of transience.
- Step 2 (Evidence - Poem 1): "nhi vosQyk Lusg Hkjk gS xoZ Hkjk enekrk / ij bldks Hkh iafDr dks ns nks" — darkness is addressed collectively ("bldks"), fear is acknowledged ("xoZ") but transformed by awareness ("iafDr").
- Step 3 (Evidence - Poem 2): "lwus fojkV~ osQ lEeq[k / gj vkyksd&Nqvk viukiu gS mUekspu / u'ojrk osQ nkx ls!" — darkness ("fojkV~") is the "lap" holding the flower; the speaker stands alone ("eSaus ns[kk]") at wonder's edge.
- Step 4 (Explanation): Poem 1 uses second-person plural imperative ("ns nks") — darkness demands collective action. Poem 2 uses first-person singular ("eSaus ns[kk]") — darkness enables solitary epiphany. The grammatical subject (we vs I) mirrors the atmospheric difference (social resilience vs individual awe).
- Step 5 (Link): Both poems refuse to treat darkness as mere absence; they make it an active presence — but one presence unites, the other isolates. This duality is the poet's signature: nature as both adversary and revelation.
- Step 6 (Board Exam Polish): Use connectors "vipreeta" (conversely), "ek rRo" (on one hand), "dusre rRo" (on the other). Quote line numbers/references if possible. End with thematic significance.

REASONING: This worked example models the exact comparative paragraph structure required for 6-mark Board questions and JEE-style "analyze the following poems" tasks. It integrates grammar (imperative vs indicative), perspective (we vs I), and philosophy (collective vs individual).

ANSWER: (Sample PEEL paragraph)
Point: Darkness functions as a crucible in both poems but forges opposite atmospheres — collective defiance in "nhi vosQyk", solitary wonder in "eSaus ns[kk] ,d cw¡n".
Evidence: The first poem addresses darkness collectively: "nhi vosQyk Lusg Hkjk gS xoZ Hkjk enekrk / ij bldks Hkh iafDr dks ns nks" (imperative plural "ns nks"). The second poem observes darkness individually: "eSaus ns[kk] ,d cw¡n lglk mNyh / lwus fojkV~ osQ lEeq[k gj vkyksd&Nqvk viukiu gS mUekspu".
Explanation: The grammatical shift from "we/you" to "I" mirrors the atmospheric shift. In Poem 1, darkness is a shared enemy that demands "iafDr" (conscious resistance) — the atmosphere is forged in communal speech. In Poem 2, darkness ("fojkV~") is the "lap" that cradles the flower, allowing the solitary speaker to witness "jax xbZ {k.kHkj" — the atmosphere blooms in private perception.
Link: Thus the poet uses the same setting element to reveal two faces of human-nature dialogue: we survive together, we marvel alone.

## COMPETENCY_QUESTION_1
QUESTION: A student writes: "Both poems are about night, so both have a scary atmosphere." Using specific evidence from "nhi vosQyk" and "eSaus ns[kk] ,d cw¡n", explain why this statement is an oversimplification and what the student misses about the poet's technique.

COMPETENCY: Critical Thinking — identifying oversimplification and articulating nuanced textual evidence.

STEPS:
- Step 1: Acknowledge the surface similarity — both poems use night/darkness as setting.
- Step 2: Quote the atmosphere words from each poem: "enekrk" (beloved) and "u'ojrk" (wonder) — neither means "scary".
- Step 3: Explain the speaker's agency: Poem 1 speaker *chooses* to love the night via "iafDr"; Poem 2 speaker *witnesses* beauty in darkness.
- Step 4: Name the technique: "revaluation of setting through consciousness" — the poet's signature move.
- Step 5: Conclude: The student misses that atmosphere is *constructed* by the speaker's stance, not dictated by setting.

ANSWER: The statement reduces two distinct philosophical engagements with darkness to a single emotional label. "nhi vosQyk" explicitly calls the dark night "enekrk" (beloved) because "iafDr" (awareness) transforms fear into strength — atmosphere is *earned*. "eSaus ns[kk] ,d cw¡n" finds "u'ojrk" (wonder) in darkness because it reveals the flower's colour-change — atmosphere is *discovered*. The student misses the poet's core technique: setting is raw material; atmosphere is the product of human consciousness interacting with it.

DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: The poem "nhi vosQyk" uses a refrain that repeats with incremental additions of setting details. Design a 3-column table showing: (Column A) Refrain repetition number, (Column B) New setting image introduced in that stanza, (Column C) How that image intensifies or modifies the atmosphere of "enekrk". Then write a 2-sentence synthesis of what this structural pattern reveals about the poem's theme.

COMPETENCY: Analytical Structuring — mapping structural pattern to thematic meaning.

STEPS:
- Step 1: Identify the 4 refrain occurrences (after each stanza).
- Step 2: For each, extract the new setting image from the preceding stanza: Stanza 1 -> "xhr" (thorn), "eksrh" (straw); Stanza 2 -> "vf}rh;" (lightning), "eèkq" (lamp); Stanza 3 -> "xksjl" (wet), "vaoqQj" (storm); Stanza 4 -> "lnk&nzfor" (calm-steady), "fpj&tkx:d" (flower-smiling), "vuqjDr&us=k" (submissive-restrained), "mYyac&ckgq" (bent-bowed), "fpj&v[kaM" (flower-garland).
- Step 3: Fill Column C: Thorn/straw -> atmosphere of humble endurance; Lightning/lamp -> atmosphere of sudden clarity; Wet/storm -> atmosphere of soaked resilience; Calm/flower/submissive/bowed/garland -> atmosphere of dignified surrender.
- Step 4: Observe the progression: physical hardship -> elemental violence -> spiritual acceptance.
- Step 5: Synthesis: The incremental catalogue structure enacts the poem's theme — "enekrk" is not a feeling but a *practice* built by accumulating and accepting each harsh reality.

ANSWER:
Table:
1. "xhr, eksrh" -> Atmosphere: humble endurance of daily rural hardship.
2. "vf}rh;, eèkq" -> Atmosphere: sudden illumination amid danger.
3. "xksjl, vaoqQj" -> Atmosphere: soaked but unbroken resilience.
4. "lnk&nzfor, fpj&tkx:d, vuqjDr&us=k, mYyac&ckgq, fpj&v[kaM" -> Atmosphere: dignified, graceful acceptance.
Synthesis: The refrain's incremental accumulation mirrors how "enekrk" (belovedness) is constructed — not by denying darkness, but by cataloguing its specific pains and integrating them into consciousness. The structure *is* the theme: love for life is built detail by detail.

DIFFICULTY: hard