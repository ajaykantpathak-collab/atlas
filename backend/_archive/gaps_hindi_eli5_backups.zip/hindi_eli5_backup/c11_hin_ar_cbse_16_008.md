## DEFINITION
Imagery (प्रतिबिंब/चित्रण) is the use of vivid, sensory language that appeals to the five senses (sight, sound, smell, touch, taste) to create mental pictures. Metaphor (रूपक/उपमा) is a figure of speech that directly equates two unlike things by stating one *is* the other, transferring qualities from the vehicle (image) to the tenor (subject) without using comparative words like "like" or "as".

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student can independently identify at least three distinct sensory images and two metaphors in the poem, explain the specific sensory appeal of each image, and articulate how the metaphor's vehicle reshapes the reader's understanding of the tenor in the context of the joint vs. nuclear family theme.

## SCOPE_BOUNDARY
This node covers identification, classification (visual, auditory, tactile, etc.), and analytical interpretation of imagery and metaphor *only* in the NCERT poem "आओ, फिर दीये जलाएँ" (Chapter 16). It does not cover simile, personification, symbolism, or irony (covered in node 009), nor does it address devices in other chapters.

## WALKTHROUGH
Imagine you are scrolling through Instagram and see a reel of a Diwali evening: the *visual* of flickering diyas, the *auditory* crackle of sparklers, the *olfactory* scent of ghee and sweets, the *tactile* warmth on your palms. That reel uses sensory details to make you *feel* the moment. The poet Fuezyk Iqrqy does exactly this with words. Start by reading the poem aloud slowly. In the first stanza, underline every word that triggers a sense (e.g., "इव्वल", "रंग", "बांसुरी"). Ask: "Which sense does this word hit?" Then, look for direct equations: "हँसी की मुस्कान" – is laughter literally a smile? No, the poet says laughter *is* a smile to show its infectious visibility. That is a metaphor. The key insight: imagery builds the *world* of the poem; metaphor builds the *meaning* by forcing a new perspective on familiar objects.

## DIAGNOSTIC_QUESTION_1
Define "imagery" (चित्रण) and "metaphor" (रूपक) in your own words, giving one original example for each that is NOT from the textbook.

## DIAGNOSTIC_ANSWER_1
**Correct Answer:** Imagery is descriptive language appealing to the five senses (e.g., "The scorching June wind slapped my face like a dry towel" – tactile/visual). Metaphor is a direct comparison stating A is B (e.g., "Time is a thief" – time steals moments).  
**What a wrong answer reveals:** If the student defines imagery as "description" without specifying sensory appeal, they confuse it with general narration. If they use "like/as" in the metaphor example, they confuse metaphor with simile. Both indicate a lack of precise terminological boundaries required for board exam definitions.

## DIAGNOSTIC_QUESTION_2
In the line "बाँसुरी की बाँक में / जीवन की गूँज" (Stanza 2), identify the metaphor. What is the tenor and what is the vehicle? Why does the poet *not* write "जीवन बाँसुरी की बाँक *जैसा* है"?

## DIAGNOSTIC_ANSWER_2
**Correct Answer:** Metaphor: "बाँसुरी की बाँक" (flute's curve/tune) = vehicle; "जीवन की गूँज" (life's resonance) = tenor. The poet avoids "जैसा" (like) to assert an *identity*, not a resemblance. The flute's curve *is* life's resonance – suggesting life's continuity, breath-dependence, and music are inherent, not merely similar.  
**What a wrong answer reveals:** If the student swaps tenor/vehicle, they misunderstand which concept is being illuminated. If they say "it's just poetic style," they miss the semantic force of metaphor: it compels the reader to *see* life *as* music, not just compare them. This is a Class 11-level analytical distinction.

## DIAGNOSTIC_QUESTION_3
APPLY: The poem uses "इव्वल की इव्वल चमक" (Stanza 1). Classify the *primary* sensory appeal (visual, auditory, etc.). Then, rewrite this phrase as a simile. Explain how the shift from metaphor (implied) to simile changes the reader's focus.

## DIAGNOSTIC_ANSWER_3
**Correct Answer:** Primary appeal: Visual (bright, steady light). Simile rewrite: "चमक *जैसी* इव्वल की इव्वल" or "इव्वल *की तरह* चमकती". Shift: The original (implied metaphor: the glow *is* the diya's essence) fuses object and quality. The simile separates them – the glow becomes a *property* the subject *has*, distancing the reader from the immediate sensory fusion.  
**What a wrong answer reveals:** If the student says "auditory" or "tactile," they cannot map sensory words to modalities. If they claim the simile "means the same," they miss the grammatical-semantic nuance: metaphor = identity/essence; simile = comparison/property. Board exams test this distinction in "effect of device" questions.

## DIAGNOSTIC_QUESTION_4
ANALYZE: Compare the imagery in "हँसी की मुस्कान" (Stanza 2) and "फुसफुसाहट की फुहार" (Stanza 3). How do the *sound patterns* (alliteration, vowel quality) in each phrase reinforce their respective sensory imagery?

## DIAGNOSTIC_ANSWER_4
**Correct Answer:** "हँसी की मुस्कान" – repeated nasal 'ं' (anunasik) and open 'आ' (aa) vowels create a broad, resonant, open-mouthed *visual-auditory* blend (laughter seen/heard). "फुसफुसाहट की फुहार" – repeated 'फ' (ph) and 'स' (s) fricatives produce a soft, airy, dispersed *tactile-auditory* texture (whisper felt as mist). The phonetics *enact* the imagery.  
**What a wrong answer reveals:** If the student only identifies "alliteration" without linking sound to sense, they treat sound devices as decoration. Senior secondary analysis requires showing *how* phonic texture *constructs* the sensory experience (phonesthetics). This connects to node 011 (Grammar: Language Usage).

## DIAGNOSTIC_QUESTION_5
EVALUATE: A student claims: "The metaphor 'हाथों की मेंहदी' (Stanza 3) for 'tradition' is weak because mehndi fades quickly, but traditions are long-lasting." Defend or refute this interpretation using textual evidence from the poem's theme of joint vs. nuclear family.

## DIAGNOSTIC_ANSWER_5
**Correct Answer:** Refute. The poem contrasts *fragility* of joint family bonds ("फुसफुसाहट", "फुहार") with modernity's "भयावह सन्नाटा". Mehndi's *fading* is precisely the point: traditions *are* fading in nuclear setups. The metaphor captures the *transience* the poet laments, not permanence. The "रचती" (applying) implies active effort to sustain what is inherently temporary.  
**What a wrong answer reveals:** If the student agrees, they read metaphor literally/isolated from theme. They miss that metaphors in this poem often highlight *vulnerability* (diya flame, mehndi, whisper) to critique nuclear family isolation. This thematic integration is essential for 6-mark board answers.

## DIAGNOSTIC_QUESTION_6
CREATE: Write a 4-line Hindi poem stanza (छंद) about "exam stress" using: (a) at least two distinct sensory images (label them), (b) one metaphor equating stress to a tangible object. Do not use "जैसे/वैसे".

## DIAGNOSTIC_ANSWER_6
**Expected Answer Criteria:**  
1. Two labeled sensory images (e.g., "Visual: काली स्याही सा अँधेरा", "Tactile: माथे पर पसीने की नोकदार सुई").  
2. One metaphor without comparative words (e.g., "तनाव लोहे का वह बक्सा है / जो सीने पर रखा गया हो").  
3. Coherent thematic unity.  
**Poor answer reveals:** Using "जैसा" = simile confusion. Only visual images = narrow sensory range. Metaphor abstract ("तनाव एक बोझ है") = fails "tangible object" requirement. Shows inability to *generate* devices, only recognize them.

## COMMON_MISCONCEPTION
Students believe **any comparison is a metaphor** and **any descriptive word is imagery**. Specifically, they label "दीये की लौ" as imagery (it's a concrete noun, not sensory description) and "जीवन दीये *जैसा* है" as metaphor (it's a simile due to "जैसा"). They also think imagery is only visual ("mental picture"), ignoring auditory, olfactory, tactile, gustatory. This stems from middle-school definitions that oversimplify: "imagery = pictures in mind", "metaphor = comparison". In Class 11, imagery = *sensory evocation*; metaphor = *identity assertion*.

## ON_FAILURE
1. **Sensory Sort Drill:** Give the student 15 words from the poem (इव्वल, बाँसुरी, फुसफुसाहट, मेंहदी, सन्नाटा, etc.). Ask them to sort into 5 sense columns (दृश्य, श्रव्य, घ्राण, स्पर्श, स्वाद). Discuss misplaced words.  
2. **Metaphor Surgery:** Take 3 similes from Class 10 texts (e.g., "वीर तुम बढ़े चलो... तुम अनंत हो *जैसे* सागर"). Have student delete "जैसे" and rewrite as metaphor ("तुम अनंत सागर हो"). Analyze meaning shift.  
3. **Phonic Mapping:** Read aloud "फुसफुसाहट की फुहार" 5 times. Student marks where lips/teeth/tongue create friction. Connect friction to "whisper" sensation.  
4. **Theme Anchor:** For each device found, student writes one sentence: "This [device] supports the theme of [joint family warmth/nuclear isolation] by..."

## BUILDS_ON
Node c11_hin_ar_cbse_16_003 (Setting and Atmosphere) – sensory details in setting description are the raw material for imagery analysis.

## LEADS_TO
Node c11_hin_ar_cbse_16_009 (Literary Devices: Irony and Symbolism) – metaphor often *becomes* symbol when repeated; irony often *subverts* metaphorical expectations.

## PREREQUISITE_NODE_IDS
c11_hin_ar_cbse_16_001, c11_hin_ar_cbse_16_002, c11_hin_ar_cbse_16_003, c11_hin_ar_cbse_16_006, c11_hin_ar_cbse_16_004, c11_hin_ar_cbse_16_005, c11_hin_ar_cbse_16_007, c11_hin_ar_cbse_16_010

## PREREQUISITE_REASONS
c11_hin_ar_cbse_16_001: Context of joint vs. nuclear family is essential to interpret *why* specific metaphors (diya, mehndi) are chosen.  
c11_hin_ar_cbse_16_002: Narrative structure (stanza progression) shows how imagery accumulates to build the poem's argument.  
c11_hin_ar_cbse_16_003: Atmosphere analysis (warmth vs. silence) directly relies on sensory imagery identification.  
c11_hin_ar_cbse_16_006: Primary theme (value of joint family) is the lens through which all metaphors must be evaluated.
c11_hin_ar_cbse_16_004: Imagery/metaphor node examines how "ekVh," "vkcks&gok," "Hkhrj dh vkx" construct the speaker's vision—direct extension of character analysis.  
c11_hin_ar_cbse_16_005: Imagery and metaphor (e.g., "मिट्टी का रंग" as identity, "उफ्न" as warmth) are the linguistic clothing of the supporting characters.  
c11_hin_ar_cbse_16_007: Imagery and metaphor are the primary vehicles for secondary themes.  
c11_hin_ar_cbse_16_010: Imagery analysis requires precise understanding of each word's sensory and connotative value established here.  

## FORWARD_NODE_IDS
c11_hin_ar_cbse_16_009, c11_hin_ar_cbse_16_012, c11_hin_ar_cbse_16_013, c11_hin_ar_cbse_16_014, c12_hin_a_cbse_02_008, c12_hin_a_cbse_04_008, c12_hin_a_cbse_05_008, c12_hin_a_cbse_16_008, c11_hin_ar_cbse_16_015

## FORWARD_REASONS
c11_hin_ar_cbse_16_009: Symbolism extends metaphor (repeated vehicle becomes symbol); irony often contradicts metaphorical promise.  
c11_hin_ar_cbse_16_012: Inferential comprehension questions require explaining *how* imagery/metaphor constructs meaning beyond literal sense.  
c11_hin_ar_cbse_16_013: Critical interpretation (e.g., "Is the poet romanticizing the past?") demands evaluating device effectiveness.
c11_hin_ar_cbse_16_014: Knowledge of imagery and metaphor enables identification of specific devices to discuss as Evidence.  
c12_hin_a_cbse_02_008: Mastery-level practice in Class 11 Antra final chapter.  
c12_hin_a_cbse_04_008: Unseen poem practice — builds exam-speed identification.  
c12_hin_a_cbse_05_008: Synthesizes all Class 11 device skills.  
c12_hin_a_cbse_16_008: Direct predecessor — same devices, simpler text, same authorial concerns.  
c11_hin_ar_cbse_16_015: Review the imagery and metaphor analysis (c11_hin_ar_cbse_16_008) and the critical thinking questions (c11_hin_ar_cbse_16_013) to gather discussion points.  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
No prior class nodes available for cross-subject linking in this Hindi Aroh chapter.

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_16_003 -> c11_hin_ar_cbse_16_008 -> c11_hin_ar_cbse_16_009: Setting analysis provides sensory inventory; this node teaches device classification/analysis; next node extends to higher-order tropes (symbol/irony) built on metaphorical foundations.

## THIS_FORMULA
N/A - conceptual

## FORMULA_VARIABLES
N/A

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
linguistic

## CROSS_SUBJECT
c11_psychology_cognitive_processes | Mental imagery research (Kosslyn) shows sensory simulation in reading mirrors perception – explains *why* imagery evokes embodied responses in the poem.  
c11_sociology_social_change | Joint vs. nuclear family transition (Chapter 3: Social Institutions) is the sociological reality the poem's metaphors (diya, mehndi, bansuri) critique – metaphor as social commentary.

## PREREQ_CONCEPT
Precise distinction between *sensory language* (imagery) and *figurative identity* (metaphor), and ability to map words to sensory modalities.

## PREREQ_BEFORE
Student must be able to list the five sensory modalities in Hindi (दृश्य, श्रव्य, घ्राण, स्पर्श, स्वाद) and define simile (उपमा) using "जैसे/वैसे" structure.

## PREREQ_STUCK
Review Class 9/10 Hindi grammar chapter "अलंकार" (Figures of Speech) – specifically उपमा (simile) and रूपक (metaphor) definitions and examples.

## WORKED_EXAMPLE_1
PROBLEM: Analyze the imagery and metaphor in the phrase "बाँसुरी की बाँक में / जीवन की गूँज" (Stanza 2). Explain how the vehicle transforms the tenor.

STEPS:
- Step 1: Identify the two nouns in the equation. "बाँसुरी की बाँक" (flute's curve/tune) and "जीवन की गूँज" (life's resonance). The preposition "में" (in) suggests containment/identity.
- Step 2: Classify the vehicle's sensory properties. Bansuri: auditory (melody), tactile (breath/wind), visual (curved bamboo), kinesthetic (finger movement). It is handmade, organic, requires living breath.
- Step 3: Map vehicle properties to tenor (life). Life as melody = non-linear, aesthetic, temporal. Life as breath-dependent = fragile, rhythmic, stops when breath stops. Life as handmade = crafted by choices, not factory-made.
- Step 4: Contrast with a simile alternative ("जीवन बाँसुरी *जैसा* है"). Simile keeps life and flute separate; metaphor fuses them – the poem *enacts* life-as-music through its own rhythmic lines.
- Step 5: Connect to theme. Joint family life = collective melody (interdependence, shared breath). Nuclear family = solo, amplified, recorded music (isolated, mechanical). The metaphor *is* the thematic argument.

REASONING: This 5-step method (Identify -> Sense-map -> Property-transfer -> Form-contrast -> Theme-anchor) forces the student to move beyond "identification" to "interpretation", which is the board exam requirement for 4-6 mark questions.

ANSWER: The metaphor equates life's essence to a flute's curve/tune. The vehicle (bansuri) transfers qualities of breath-dependence, organic craftsmanship, melodic continuity, and collective resonance (in an ensemble) to the tenor (life). This directly supports the poem's theme: joint family life is a shared, living music; nuclear modernity breaks the flute into isolated, silent pieces.

## WORKED_EXAMPLE_2
PROBLEM: The poem opens with "आओ, फिर दीये जलाएँ" and uses "इव्वल की इव्वल चमक". Analyze the *visual* and *tactile* imagery cluster in Stanza 1 and explain how it sets up the central metaphor of the diya.

STEPS:
- Step 1: List all sensory words in Stanza 1. Visual: "इव्वल", "चमक", "रंग", "उजाला". Tactile: "गरमाहट" (implied by flame), "हाथों" (holding). Kinesthetic: "जलाएँ" (action of lighting).
- Step 2: Group into clusters. Cluster A: Light words (इव्वल, चमक, उजाला) – intensity, steadiness, color. Cluster B: Body words (हाथों, गरमाहट) – proximity, contact, care.
- Step 3: Analyze the metaphor "दीया" = "परंपरा/संस्कार/संबंध". The diya is small, fragile, requires constant oil (effort), gives light/warmth, fights darkness (isolation).
- Step 4: Show how imagery *builds* the metaphor. "इव्वल की इव्वल चमक" – the repetition "इव्वल... इव्वल" mimics the steady, unwavering flame. Visual steadiness = cultural continuity. Tactile "गरमाहट" = emotional warmth of relationships.
- Step 5: Evaluate function. The stanza doesn't just *describe* a diya; the sensory cluster *constructs* the diya as a metaphor for high-maintenance, high-value traditions. Lighting it ("जलाएँ") is a deliberate, communal act (imperative plural "आओ").

REASONING: Board questions often ask "How does the poet use imagery to develop a metaphor?" This step-by-step (Inventory -> Cluster -> Metaphor Identification -> Imagery->Metaphor Link -> Functional Evaluation) mirrors the PEEL structure required in long answers.

ANSWER: Stanza 1 constructs a dense visual-tactile-kinesthetic cluster around the diya. The repetition in "इव्वल की इव्वल चमक" enacts the flame's steadiness; "हाथों" and implied "गरमाहट" ground the light in human touch. This imagery cluster transforms the diya from object to metaphor: tradition as a fragile, hand-sustained flame that provides both visibility (guidance) and warmth (affection) against the "भयावह सन्नाटा" of nuclear isolation.

## WORKED_EXAMPLE_3
PROBLEM: Compare the metaphors "हँसी की मुस्कान" (Stanza 2) and "फुसफुसाहट की फुहार" (Stanza 3). How do their *grammatical structures* (noun + postposition + noun) and *phonetics* create contrasting emotional tones (joy vs. fragility) relevant to the joint family theme?

STEPS:
- Step 1: Parse grammatical structure. Both: [Abstract Noun 1] + का/की + [Concrete Noun 2]. "हँसी की मुस्कान" (Laughter's smile), "फुसफुसाहट की फुहार" (Whisper's spray/mist). Structure: Abstract quality *possesses/manifests as* concrete form.
- Step 2: Analyze phonetics of Noun 1. "हँसी" – open vowel 'आ' (aa), nasal 'ं', aspirated 'ह' – expansive, resonant, open throat. "फुसफुसाहट" – repeated fricatives 'फ', 'स', 'ह' – breathy, turbulent, low energy, dispersed.
- Step 3: Analyze phonetics of Noun 2. "मुस्कान" – nasal 'ं', open 'आ', velar 'क' – rounded, sustained, visible curve. "फुहार" – fricative 'फ', vowel 'उ' (rounded but short), 'ह' – fine, dispersed, evaporative.
- Step 4: Map to tone. "हँसी की मुस्कान": Phonetics enact *expansion, visibility, sustainability* – joy that is seen, shared, lasts. "फुसफुसाहट की फुहार": Phonetics enact *contraction, invisibility, transience* – intimacy that is felt, private, vanishes.
- Step 5: Synthesize with theme. Joint family = collective laughter (public, resonant, structural "मुस्कान" of society). Nuclear family = whispered secrets (private, fine, "फुहार" that evaporates in "सन्नाटा"). The grammatical parallelism highlights the structural replacement of robust joy by fragile intimacy.

REASONING: This 6-step analysis (Grammar -> Phonetics N1 -> Phonetics N2 -> Tone Mapping -> Thematic Synthesis) integrates linguistic form (morphology, phonetics) with literary meaning – a senior secondary competency. It prepares students for "How does the poet use language to convey...?" questions.

ANSWER: Both metaphors use the [Abstract का Concrete] structure, but their phonetics create opposing affective tones. "हँसी की मुस्कान" uses open, resonant sounds (आ, ं) to produce a tone of expansive, visible, sustainable joy – the "smile" of a thriving joint family. "फुसफुसाहट की फुहार" uses breathy fricatives (फ, स, ह) to produce a tone of contracted, invisible, evaporative fragility – the "mist" of isolated nuclear whispers. The parallel structure invites comparison; the phonic contrast executes the thematic argument.

## COMPETENCY_QUESTION_1
QUESTION: The poem uses the imperative "आओ, फिर दीये जलाएँ" (Come, let's light diyas again). Explain how the *imagery* in the first stanza transforms this imperative from a ritual instruction into a metaphorical call for social action. Support with two specific sensory details.

COMPETENCY: Literary Analysis – Connecting Device to Theme (CBSE 6-mark pattern)

STEPS:
- Step 1: Identify the literal level: lighting oil lamps (ritual).
- Step 2: Identify two sensory details: (a) Visual: "इव्वल की इव्वल चमक" (steady, intrinsic brightness). (b) Tactile/Kinesthetic: "हाथों" (hands) + implied warmth of flame.
- Step 3: Explain metaphorical transfer: Diya = Tradition/Relationship. Lighting = Active maintenance.
- Step 4: Argue transformation: "इव्वल की इव्वल चमक" suggests traditions have *inherent* value (not borrowed). "हाथों" implies *personal, collective effort* (not automated/electric). The imperative "आओ" (plural) + sensory cluster = communal reconstruction of fragmented bonds.

ANSWER: The visual imagery "इव्वल की इव्वल चमक" (the diya's own steady glow) establishes tradition as self-luminous, not dependent on external validation – countering modern "electric" convenience. The tactile/kinesthetic "हाथों" (in hands) and the act of lighting ("जलाएँ") ground the metaphor in deliberate, embodied labor – relationships require hands-on care. Together, they shift "आओ, फिर दीये जलाएँ" from "perform a ritual" to "communally rebuild the fragile, hand-sustained warmth of joint family bonds against nuclear isolation."

DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: A critic argues: "The metaphors in 'आओ, फिर दीये जलाएँ' are nostalgic clichés (diya, bansuri, mehndi) that romanticize a patriarchal joint family, ignoring its oppression of women." Using *at least two metaphors* and their *imagery*, evaluate this claim. Does the poem's device usage support or complicate the critic's view?

COMPETENCY: Critical Evaluation – Assessing Ideological Implications of Literary Devices (CBSE HOTS/Competency)

STEPS:
- Step 1: Acknowledge the surface validity: Diya/bansuri/mehndi are traditional symbols often used uncritically.
- Step 2: Analyze "हाथों की मेंहदी" metaphor + imagery. Mehndi: applied *by women*, on *women's hands*, temporary, decorative, fades. Imagery: visual (red/green), olfactory (henna smell), tactile (cooling paste). This *could* symbolize women's labor as ornamental/ephemeral.
- Step 3: Analyze "बाँसुरी की बाँक में / जीवन की गूँज". Bansuri: traditionally male (Krishna), breath-controlled, musical skill. Imagery: auditory, kinesthetic. Life = male artistry?
- Step 4: Counter-evidence from *device usage*. "फुसफुसाहट की फुहार" (whisper's mist) – gender-neutral, fragile, intimate. "हँसी की मुस्कान" – collective, visible, structural. The poem *juxtaposes* gendered metaphors (mehndi/bansuri) with universal human ones (laughter, whisper, diya).
- Step 5: Judgment. The poem *complicates* the critic's view. It uses gendered metaphors *alongside* universal sensory metaphors of fragility (diya, whisper, mist) to argue that *all* relationships in nuclear modernity are endangered, not just women's roles. The devices enforce a *shared vulnerability* reading.

ANSWER: The critic's view is partially valid but incomplete. "हाथों की मेंहदी" (women's decorative, fading labor) and "बाँसुरी की बाँक" (male breath/artistry) *do* carry patriarchal coding. However, the poem's *system* of metaphors – especially the universal, fragile imagery of "इव्वल की इव्वल चमक" (diya's steady flame), "फुसफुसाहट की फुहार" (whisper's mist), and "हँसी की मुस्कान" (laughter's smile) – constructs a *shared precarity*. The sensory cluster (visual, tactile, auditory) applies to *everyone* in the nuclear void. The devices thus complicate a purely patriarchal reading: they mourn the loss of *interdependent vulnerability* (diya needs hands, whisper needs air, mehndi needs skin) that characterized the joint family, regardless of gender. The poem critiques modernity's "भयावह सन्नाटा" through metaphors of *universal* fragility.

DIFFICULTY: hard