## DEFINITION
The primary theme of a literary work is its central, unifying idea or insight about human experience that the author conveys through the narrative elements; the message is the specific moral, social, or philosophical conclusion the author intends the reader to derive from that theme.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student must be able to identify the primary theme of "लकड़ियों में आग" by tracing the fire metaphor across all three stanzas, and articulate the poem's revolutionary message with textual evidence showing how the poet transforms a natural phenomenon into a socio-political statement.

## SCOPE_BOUNDARY
This node covers identifying and analyzing the primary theme (revolutionary awakening of the oppressed) and message (inevitable uprising against exploitation) in Nagarjun's poem "लकड़ियों में आग" using the fire-in-wood metaphor; it does not cover secondary themes like nature imagery or literary devices such as irony and symbolism, which are addressed in subsequent nodes.

## WALKTHROUGH
Imagine you are sitting around a winter bonfire in your village and notice how the seemingly dead, cold logs suddenly crackle with hidden flames — this is exactly how Nagarjun wants you to read his poem. Begin by reading the poem aloud twice: first for the sound and rhythm, then marking every occurrence of fire-related words (आग, जलना, धधकना) and wood-related words (लकड़ियाँ, चिरई, ठूँठ). Notice how the first stanza establishes the metaphor, the second stanza applies it to the powerful versus the powerless, and the third stanza declares the inevitable outcome. The key insight is that the poem does not merely describe a natural phenomenon; it uses the physics of latent heat in wood as a precise analogue for revolutionary potential in the oppressed, making the theme both inevitable and urgent.

## DIAGNOSTIC_QUESTION_1
What is the central metaphor in Nagarjun's poem "लकड़ियों में आग" and what two entities does it connect?

## DIAGNOSTIC_ANSWER_1
The central metaphor is "fire hidden in wood" (लकड़ियों में आग), connecting the latent revolutionary consciousness in the oppressed masses (wood) to the inevitable uprising (fire) that will consume the exploitative system. A wrong answer that identifies only "fire" or "wood" separately, or connects fire to "nature" instead of "social revolution," reveals the student has not grasped the metaphor's socio-political function and is reading literally rather than allegorically.

## DIAGNOSTIC_QUESTION_2
Explain in your own words why the poet says "एल्लज निजर" (foolish, broken) in the first stanza and how this description sets up the poem's central argument.

## DIAGNOSTIC_ANSWER_2
The phrase describes the wood as seemingly useless and discarded, mirroring how the ruling class views the poor as worthless and powerless; this sets up the poem's argument by establishing the deceptive appearance that the exploiters believe, which the poet will overturn by revealing the hidden fire. A wrong answer that treats "एल्लज निजर" as mere physical description of dry wood misses the irony: the poet adopts the oppressor's vocabulary only to subvert it, showing the student has not understood the poem's rhetorical strategy of ironic reversal.

## DIAGNOSTIC_QUESTION_3
Apply the fire-in-wood metaphor to a contemporary Indian context: identify a specific marginalized community and describe what the "wood," "fire," and "spark" would represent in their struggle, using the poem's logic.

## DIAGNOSTIC_ANSWER_3
For landless agricultural laborers in Bihar: the "wood" is their suppressed labor and dignity, the "fire" is their collective consciousness of rights (e.g., minimum wage awareness), and the "spark" is a triggering event like a landlord's atrocity or a union organizer's speech. Steps: (1) Identify the dormant group (wood), (2) Identify the latent energy (fire), (3) Identify the catalyst (spark), (4) Map each to the poem's three-stanza progression. A wrong answer that chooses a middle-class protest or separates the spark from the community's own agency reveals the student cannot transfer the metaphor's structural logic — specifically that the fire arises from within the wood, not from outside.

## DIAGNOSTIC_QUESTION_4
Analyze how the shift from third-person observation in stanza 1 ("लकड़ियों में आग") to first-person declaration in stanza 2 ("मैं चसदज ग्वाँ...") to prophetic future tense in stanza 3 ("रहजक फौजक...") structures the poem's thematic argument.

## DIAGNOSTIC_ANSWER_4
The progression enacts the theme: stanza 1 presents the objective reality (fire exists in wood regardless of perception), stanza 2 inserts the poet as witness-participant aligning with the oppressed ("I am with the insignificant"), and stanza 3 projects the inevitable historical outcome (the "careless world" will be consumed). This three-stage structure — diagnosis, solidarity, prophecy — mirrors the revolutionary process itself. A wrong answer that treats the stanzas as merely descriptive, or misses the shift from "is" to "will be," reveals the student cannot analyze how poetic structure encodes thematic argument.

## DIAGNOSTIC_QUESTION_5
Evaluate the claim: "Nagarjun's poem is pessimistic because it predicts destruction." Defend your judgment using specific lines and the distinction between destruction of the oppressive order versus destruction of the oppressed.

## DIAGNOSTIC_ANSWER_5
The claim is false; the poem is revolutionary-optimistic. The "destruction" targets the "ग़फ़लत" (complacent world) of the exploiters ("रहजक फौजक" — the careless army/rulers), while the "चसदज" (insignificant ones) are the agents of renewal. The fire purifies; it does not annihilate the wood but releases its energy. A wrong answer that agrees with the claim reveals the student conflates revolutionary violence with nihilism and cannot distinguish between the poem's targets (the oppressive structure) and its heroes (the oppressed), missing the poem's clear moral framework.

## DIAGNOSTIC_QUESTION_6
Write a four-line stanza in Hindi that extends the poem's metaphor to a modern context (e.g., digital activism, climate justice, student movements), maintaining the original's rhythm and the fire-in-wood logic.

## DIAGNOSTIC_ANSWER_6
Example: "स्मार्टफोन की ठूँठ में धधकता सवाल / उँगलियों की चिंगारी से जलेगा जाल / ग़फ़लत की दीवारें ढहेंगी आज / युवा लकड़ियों की आग बनेगी काज।" A good answer maps wood→suppressed questions, spark→digital action, fire→collective uprising, and targets the complacent system. A poor answer that writes a generic motivational verse without the metaphor's causal logic (spark-from-within, inevitable consumption of the old order) reveals the student has not internalized the poem's structural metaphor as a generative template.

## COMMON_MISCONCEPTION
Students often read "लकड़ियों में आग" as a nature poem about literal fire in wood, or as a generic "never give up" inspirational poem, missing that the fire is specifically a class-war metaphor where the wood = the proletariat/oppressed, the fire = revolutionary consciousness, and the "careless world" = the feudal-capitalist order. This error occurs because the poem's vocabulary (लकड़ियाँ, चिरई, ठूँठ) is deceptively pastoral, and the NCERT textbook places it without explicit Marxist framing, so students lack the interpretive lens to decode the allegory. A concrete example: a student writes "the poem teaches us that hidden talent exists in everyone" — this individualistic reading erases the collective, structural, and political dimension that is the poem's actual core.

## ON_FAILURE
Step 1: Ask the student to list every noun in the poem that refers to people or groups (e.g., "चसदज", "रहजक फौजक", "ग़फ़लत", "इक़रेबू") and identify which side of a power struggle each represents. Step 2: Have them re-read stanza 2 aloud, replacing "मैं चसदज ग्वाँ" with "मैं मजदूर/दलित/आदिवासी हूँ" to force the allegorical mapping. Step 3: Give them a two-column table: Column A = words from the poem (लकड़ियाँ, आग, चिंगारी, धुआँ, राख), Column B = social equivalents (दबा हुआ वर्ग, क्रांतिकारी चेतना, उत्प्रेरक घटना, आंदोलन, नई व्यवस्था); ask them to match and justify each pairing. Step 4: Show a 2-minute clip of a peasant movement speech (e.g., from the 1970s Bihar Kisan Sabha) and ask: "Which lines from the poem could be this speaker's slogan?" This grounds the metaphor in historical reality.

## BUILDS_ON
The node builds on the student's ability to identify and explain extended metaphors (c11_hin_ar_cbse_13_008) and to trace character perspectives across a text (c11_hin_ar_cbse_13_004, c11_hin_ar_cbse_13_005).

## LEADS_TO
This node enables the analysis of secondary themes like "nature as witness" and "the poet's role" (c11_hin_ar_cbse_13_007) and the study of irony and symbolism as devices that sustain the primary metaphor (c11_hin_ar_cbse_13_009).

## PREREQUISITE_NODE_IDS
c11_hin_ar_cbse_13_001, c11_hin_ar_cbse_13_002, c11_hin_ar_cbse_13_003, c11_hin_ar_cbse_13_004, c11_hin_ar_cbse_13_005

## PREREQUISITE_REASONS
c11_hin_ar_cbse_13_001: Provides the historical context of Nagarjun's Marxist leanings and the Naxalite-era Bihar background essential for decoding the poem's political allegory.
c11_hin_ar_cbse_13_002: Establishes the three-stanza narrative arc (observation → solidarity → prophecy) that structures the thematic argument.
c11_hin_ar_cbse_13_003: The primary theme (critique of authoritarian power) is instantiated in the setting-atmosphere dynamic; the court *is* the theme in physical form.  
c11_hin_ar_cbse_13_004: The primary theme (resistance to exploitation) emerges directly from the protagonist's character arc.  
c11_hin_ar_cbse_13_005: The supporting characters' mechanical rituals (pallbearers' labor, relatives' performed grief) constitute the primary textual evidence for the theme "death as social ritual vs. personal loss."  

## FORWARD_NODE_IDS
c11_hin_ar_cbse_13_007, c11_hin_ar_cbse_13_009, c11_hin_ar_cbse_13_013, c11_hin_ar_cbse_13_008, c11_hin_ar_cbse_13_015, c12_hin_ar_cbse_12_006, c12_hin_ar_cbse_13_006

## FORWARD_REASONS
c11_hin_ar_cbse_13_007: The primary theme (revolutionary awakening) is the trunk from which secondary themes (nature's complicity, the intellectual's duty) branch out.
c11_hin_ar_cbse_13_009: Irony (the oppressor's blindness) and symbolism (wood/fire/ash) are the devices that encode the primary theme; they cannot be analyzed without first establishing what they serve.
c11_hin_ar_cbse_13_013: Critical interpretation requires a settled understanding of the primary theme as the anchor for evaluating competing readings.
c11_hin_ar_cbse_13_008: Primary Theme provides the central idea that imagery and metaphor serve.  
c11_hin_ar_cbse_13_015: मुख्य विषय (सत्ता बनाम व्यक्ति) चर्चा का केंद्रीय तनाव (central tension) देता है।  
c12_hin_ar_cbse_12_006: Critical thinking template for thematic interpretation.  
c12_hin_ar_cbse_13_006: Class 11 theme analysis skill (identifying central idea, distinguishing theme from plot/moral) is the direct methodological prerequisite.  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
none

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_13_001 -> c11_hin_ar_cbse_13_006 -> c11_hin_ar_cbse_13_007: Context enables theme identification, which enables secondary theme exploration.

## THIS_FORMULA
N/A - conceptual

## FORMULA_VARIABLES
N/A

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
conceptual

## CROSS_SUBJECT
c11_history_peasant_movements | The poem allegorizes the same agrarian class conflict (landlords vs. landless laborers) that History Chapter "Peasant Movements in Colonial and Post-Colonial India" analyzes structurally; the "fire in wood" metaphor maps onto the historical concept of "latent class consciousness" ignited by specific grievances.
c11_civics_social_justice | The poem's message — that the marginalized possess inherent revolutionary agency — operationalizes the Civics concept of "empowerment from below" versus "state-led welfare," illustrating Article 38/39 Directive Principles through literary form.
c11_economics_inequality | The "careless world" (ग़फ़लत) of the exploiters mirrors the Economics concept of "elite capture" where ruling classes ignore structural inequality until systemic rupture; the poem predicts the Kuznets-curve reversal via revolution rather than policy.

## PREREQ_CONCEPT
Extended metaphor analysis: the ability to map a concrete source domain (fire in wood) onto an abstract target domain (revolution in society) across multiple textual touchpoints.

## PREREQ_BEFORE
The student must be able to distinguish between a simple simile ("like fire in wood") and an extended metaphor that structures an entire poem's argument, and must know the historical context of Nagarjun as a poet-activist in 1970s Bihar.

## PREREQ_STUCK
If stuck, review "extended metaphor" in c11_hin_ar_cbse_13_008 and "Nagarjun's political biography" in c11_hin_ar_cbse_13_001; the metaphor cannot be decoded without both the technical tool and the historical key.

## WORKED_EXAMPLE_1
PROBLEM: Using only the first stanza of "लकड़ियों में आग," prove that the poem's primary theme is revolutionary inevitability, not natural description.
STEPS:
- Step 1: Isolate the key nouns and verbs in stanza 1: "लकड़ियाँ" (wood), "आग" (fire), "एल्लज निजर" (foolish/broken), "चिरई" (bird/spark), "धधकना" (to blaze). Note that "एल्लज निजर" is an external judgment (how the wood looks to an observer), while "आग" is an internal reality.
- Step 2: Identify the metaphor's tenor and vehicle: Vehicle = fire hidden in wood (natural phenomenon); Tenor = revolutionary potential hidden in the oppressed (social phenomenon). The poem asserts the tenor exists regardless of the vehicle's appearance.
- Step 3: Analyze the causal logic: The wood does not "decide" to burn; the fire is immanent in its material condition. Similarly, the poem argues revolution is immanent in the material condition of exploitation, not a voluntary choice.
- Step 4: Connect to the phrase "प्यक्स उन क जकक उघा लदकक" (but fire wants to burn) — the agency is attributed to the fire, not the wood. This grammatical shift (wood as passive substrate, fire as active agent) encodes the theme: the oppressed are the substrate; revolutionary consciousness is the agent.
- Step 5: Conclude: The stanza's physics (latent heat → combustion) is a deterministic model, not a pastoral scene. The theme is therefore structural inevitability, not aesthetic observation.
REASONING: This step-by-step moves from lexical evidence to grammatical agency to philosophical implication, demonstrating how a single stanza establishes the poem's core thesis through the metaphor's internal logic.
ANSWER: The first stanza establishes revolutionary inevitability by presenting fire as an immanent property of wood (not an accidental attribute), using the wood's deceptive appearance ("एल्लज निजर") as the oppressor's misreading, and attributing agency to the fire ("प्यक्स उन क जकक उघा लदकक") — making the wood the passive historical substrate and the fire the active historical force.

## WORKED_EXAMPLE_2
PROBLEM: A student writes: "The poem's message is that poor people should not lose hope because they have inner strength." Identify the three specific ways this answer dilutes the poem's actual revolutionary message, and rewrite it as a board-level answer.
STEPS:
- Step 1: Identify the dilution: (a) "inner strength" individualizes what the poem presents as collective structural force (fire is a property of the wood-pile, not each stick); (b) "should not lose hope" moralizes what the poem presents as material inevitability (fire burns regardless of hope); (c) "poor people" depoliticizes the specific class antagonism (the poem names the antagonist: "रहजक फौजक" / "ग़फ़लत").
- Step 2: Retrieve the poem's own vocabulary for the rewrite: replace "poor people" with "शोषित जनसमूह" (exploited masses), "inner strength" with "सन्निहित क्रांतिकारी चेतना" (immanent revolutionary consciousness), "hope" with "ऐतिहासिक अनिवार्यता" (historical necessity).
- Step 3: Structure the board answer using the PEEL format: Point (primary theme), Evidence (stanza 2 first-person alignment + stanza 3 future tense), Explanation (how the metaphor encodes class struggle), Link (message = systemic overthrow, not personal resilience).
- Step 4: Draft the answer: "नागार्जुन की कविता 'लकड़ियों में आग' का प्राथमिक विषय शोषित वर्ग की सन्निहित क्रांतिकारी चेतना की अनिवार्य विजय है। प्रथम छंद में लकड़ियों की 'एल्लज निजर' बाहरी छवि के विरुद्ध 'आग' की आंतरिक सत्ता द्वंद्वात्मक भौतिकवाद का रूपक है। द्वितीय छंद में कवि का 'मैं चसदज ग्वाँ' कहना बौद्धिक की शोषितों के साथ पक्षधरता दर्शाता है। तृतीय छंद 'रहजक फौजक' के विनाश की भविष्यवाणी करता है — संदेश व्यक्तिगत धैर्य नहीं, व्यवस्था-परिवर्तन है।"
- Step 5: Verify against marking scheme: contains theme statement, textual evidence from all three stanzas, conceptual vocabulary (द्वंद्वात्मक भौतिकवाद, पक्षधरता), and clear message articulation.
REASONING: This example teaches the student to diagnose a "soft" reading, replace it with the poem's own political vocabulary, and structure the answer for board-exam expectations (PEEL + conceptual terminology).
ANSWER: The rewritten board-level answer (in Step 4) demonstrates the correct thematic articulation: collective, structural, revolutionary — not individual, psychological, inspirational.

## WORKED_EXAMPLE_3
PROBLEM: Compare the fire metaphor in "लकड़ियों में आग" with the "seed beneath the snow" metaphor in Shelley's "Ode to the West Wind" (Class 11 English elective). Analyze how both poets use dormant natural energy to figure political revolution, but differ in the agency they attribute to the oppressed.
STEPS:
- Step 1: Map the shared structure: Both poems use a natural latent energy (fire in wood / seed under snow) as vehicle for revolutionary potential in the oppressed (tenor). Both have three movements: latency → catalyst → eruption.
- Step 2: Identify the catalyst in each: Nagarjun — "चिरई" (bird/spark) as external trigger landing on the wood; Shelley — "West Wind" as divine/natural force scattering the seeds. Note: Nagarjun's catalyst is small, accidental, proximate (a bird); Shelley's is cosmic, intentional, distant.
- Step 3: Analyze agency of the oppressed: In Nagarjun, the wood *is* the fuel; the fire arises from its own materiality ("प्यक्स उन क जकक उघा लदकक" — fire *wants* to burn). The oppressed contain the energy. In Shelley, the seeds are passive ("winged seeds... lie cold and low"); the Wind must "drive" them. The oppressed await external liberation.
- Step 4: Connect to poet's political stance: Nagarjun (Marxist) = revolution from below, immanent in class structure. Shelley (Romantic revolutionary) = revolution as spiritual/natural renewal, requiring a prophetic intermediary (the poet as "trumpet").
- Step 5: Synthesize the difference in message: Nagarjun's message = "The oppressed will inevitably rise because exploitation creates its own negation." Shelley's message = "The prophet-poet must awaken the dormant masses through visionary art."
- Step 6: Write a comparative thesis: "While both metaphors figure revolution as dormant natural force, Nagarjun locates agency in the material condition of the oppressed (immanent fire), whereas Shelley locates it in the external inspiration of the visionary (transcendent wind), reflecting Marxist vs. Romantic theories of historical change."
REASONING: This cross-textual analysis deepens the student's grasp of Nagarjun's specific thematic choice by contrasting it with a canonical parallel, revealing that the "fire in wood" metaphor is a deliberate theoretical commitment, not just a poetic image.
ANSWER: The comparative thesis (Step 6) with its six-step derivation shows how the same metaphorical structure yields opposite political theologies based on where agency is placed — inside the wood or outside in the wind.

## COMPETENCY_QUESTION_1
QUESTION: The poem's second stanza begins with "डगकक रक्स र; फपजकककक ग्जससो कक फयक कक लए" (Somewhere the wood was for a home, somewhere the wood was not foolish for the palace). Explain how this apparent non-sequitur — a description of wood's domestic uses — functions as a political statement within the poem's thematic architecture. Your answer must reference the contrast between "फयक" (home) and "ककगज" (palace) and the irony of "एल्लज" (foolish).
COMPETENCY: Thematic analysis with attention to irony and class contrast
STEPS:
- Step 1: Identify the two social spaces invoked: "फयक" (the poor's hut) and "ककगज" (the rich's palace) — establishing the class divide.
- Step 2: Analyze the word "एल्लज" (foolish/useless): The wood is "not foolish" for the palace (it serves the rich) but becomes "foolish" when the poem's speaker claims it — revealing that "usefulness" is defined by the ruling class.
- Step 3: Connect to the metaphor: The same wood that builds the palace (exploited labor) contains the fire that will burn it. The domestic utility is the mask; the revolutionary potential is the truth.
- Step 4: Articulate the thematic function: This stanza exposes the material basis of exploitation (wood = labor of the poor) before declaring its dialectical negation (fire = revolution).
ANSWER: The stanza uses the wood's dual destiny — serving the palace while being dismissed as foolish — to allegorize how the ruling class consumes the labor of the poor while denying their humanity. The irony of "एल्लज" (the wood is foolish *only* when it ceases to serve the palace) mirrors the ideological operation of class society: the oppressed are valued only as instruments. This sets up the poem's central reversal: the "foolish" wood will become the "fire" that consumes the palace.
DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: A critic argues: "Nagarjun's 'लकड़ियों में आग' fails as a revolutionary poem because it naturalizes violence — fire burning wood is a mindless chemical reaction, not a conscious political act." Refute this critique by analyzing how the poem's third stanza ("रहजक फौजक... ग़फ़लककक") transforms the natural metaphor into a historical subject. Your answer must use the terms "immanence," "agency," and "historical necessity" correctly.
COMPETENCY: Critical evaluation of a literary interpretation using Marxist literary theory concepts
STEPS:
- Step 1: Define the critic's error: Conflating the *vehicle* (natural fire) with the *tenor* (revolutionary consciousness). The metaphor's point is precisely that the fire *appears* natural/mindless to the observer ("ग़फ़लककक" — the careless world) but is in fact the expression of the wood's immanent contradiction.
- Step 2: Analyze "immanence": The fire is not imported; it arises from the wood's material condition (dryness, compression, time). Similarly, revolutionary consciousness arises from the material condition of exploitation — it is immanent, not external.
- Step 3: Analyze "agency": The poem attributes desire to the fire ("प्यक्स उन क जकक उघा लदकक" — fire *wants* to burn). This personification lifts the metaphor from chemistry to history: the oppressed *will* their liberation. The third stanza's "चसदज" (insignificant ones) become the grammatical subject of history.
- Step 4: Analyze "historical necessity": The future tense "रहजक फौजक... ग़फ़लककक" (the careless army/world will burn) presents the outcome as structurally determined, not morally wished. The "ग़फ़लककक" (complacency) of the rulers guarantees the fire's victory.
- Step 5: Conclude: The poem does not naturalize violence; it historicizes nature. It uses the *inevitability* of combustion to figure the *inevitability* of revolution, making the natural metaphor a scientific analogy for historical materialism.
ANSWER: The critique commits the category error of reading the vehicle literally. The poem's third stanza — with its prophetic future tense, its naming of the antagonist ("रहजक फौजक"), and its diagnosis of the ruler's "ग़फ़लककक" — converts the chemical fact of combustion into the historical law of class struggle. Fire's "mindlessness" is exactly how revolution *appears* to the complacent elite; the poem reveals it as the immanent agency of the exploited, making historical necessity visible through natural metaphor.
DIFFICULTY: hard