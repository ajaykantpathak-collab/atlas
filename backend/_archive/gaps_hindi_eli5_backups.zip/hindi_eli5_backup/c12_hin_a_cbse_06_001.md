## DEFINITION
The "Before You Read: Context and Background" section provides essential historical, cultural, and literary information about the poet Raskhan (रसखान), his life, the Bhakti movement context, and the specific works included in this chapter, enabling students to approach the texts with informed awareness.

## COGNITIVE_LEVEL
understand

## MASTERY_CRITERIA
The student can explain Raskhan's historical period, his unique position as a Muslim poet devoted to Krishna, the significance of his works *Jake Panjrekul* and the poems in the chapter, and how the Bhakti movement's syncretic culture shaped his writing.

## SCOPE_BOUNDARY
This node covers only the introductory context: Raskhan's biography, his major works, the Bhakti movement background, and the themes of the specific poems/prose in Chapter 6. It does NOT cover detailed textual analysis, literary devices, character analysis, or comprehension questions — those are addressed in subsequent nodes (c12_hin_a_cbse_06_002 onward).

## WALKTHROUGH
Imagine opening your Hindi textbook to Chapter 6 and seeing unfamiliar names like "रसखान", "जके पंजरेकुल", and verses in Braj Bhasha that feel distant. You might wonder: *Who is this poet? Why is a Muslim writing about Krishna? What is the historical setting?* Start by reading the "Before You Read" box carefully — it is your map. First, note the poet's lifespan (1532–1623) and birthplace uncertainty. Then, identify his shift from worldly pursuits to devotion after hearing a verse from *Jake Panjrekul*. Next, observe the three genres he wrote in: *dohas*, *pads*, and *savaiyas*. Finally, connect his life to the chapter's two texts: the poem "हजरी-जके का इजसे" (expressing Radha's longing) and the prose excerpt from *Jake Panjrekul* (describing Yashoda's love). The key insight: Raskhan's poetry emerges from a lived synthesis of Islamic upbringing and deep Krishna-bhakti, making him a unique voice in the Bhakti tradition.

## DIAGNOSTIC_QUESTION_1
Who was Raskhan, and during which period did he live?

## DIAGNOSTIC_ANSWER_1
Raskhan (रसखान) was a 16th–17th century Hindi poet (c. 1532–1623) born in a Muslim family, possibly in Jhansi or nearby, who became a devoted Krishna-bhakta and composed poetry in Braj Bhasha. A wrong answer (e.g., "He was a Mughal emperor" or "He wrote in Sanskrit") reveals the student has not read the biographical note and lacks basic factual grounding, which will hinder all subsequent analysis.

## DIAGNOSTIC_QUESTION_2
Explain in your own words why Raskhan is considered a significant figure in the Bhakti movement.

## DIAGNOSTIC_ANSWER_2
Raskhan represents the syncretic spirit of the Bhakti movement: born Muslim, he embraced Krishna-bhakti wholeheartedly, wrote in the vernacular (Braj), and expressed profound devotion through Hindu mythological imagery, showing that spiritual love transcends religious boundaries. A wrong answer that merely says "He wrote good poems" or "He was a Muslim poet" misses the *cultural synthesis* and *devotional intensity* that define his significance.

## DIAGNOSTIC_QUESTION_3
The "Before You Read" section mentions Raskhan's works include *dohas*, *pads*, and *savaiyas*. If you were given a new two-line verse by Raskhan with a rhyming couplet structure, which genre would it most likely belong to, and why?

## DIAGNOSTIC_ANSWER_3
It would be a *doha* because *dohas* are rhyming couplets (two lines) in Matra metre, commonly used by Bhakti poets for concise philosophical or devotional statements. A wrong answer (e.g., "pada" or "savaiya") shows confusion about the structural definitions of these genres, which is essential for identifying form in later nodes.

## DIAGNOSTIC_QUESTION_4
Compare the thematic focus of the poem "हजरी-जके का इजसे" (Radha's longing) with the prose excerpt from *Jake Panjrekul* (Yashoda's maternal love). What common emotional core do they share, and how does the perspective differ?

## DIAGNOSTIC_ANSWER_4
Both texts center on *prem* (love) as the path to the divine, but the poem explores *virah* (separation-longing) from Radha's perspective, while the prose depicts *vatsalya* (parental affection) from Yashoda's viewpoint. A wrong answer that only lists "love" without distinguishing *virah* vs. *vatsalya* or the shift from *gopi* to *mother* fails to analyze the nuanced emotional landscape Raskhan portrays.

## DIAGNOSTIC_QUESTION_5
Critique the statement: "Raskhan's poetry is merely an imitation of Surdas or other Hindu Bhakti poets." Defend your judgment with evidence from the context provided.

## DIAGNOSTIC_ANSWER_5
The statement is false. Raskhan's poetry is not imitation but a *personal, lived synthesis*: his Muslim upbringing, sudden spiritual turning point, and choice to live in Vrindavan/Gokul show authentic internalization. His language (*voḍkh* and *sahaj* Braj) and imagery (e.g., describing Krishna's flute as "आनंद की बाँसुरी") reflect original expression, not copying. A wrong answer that agrees with the statement reveals a misconception that cross-religious devotion must be derivative, ignoring the Bhakti movement's core principle of direct, personal access to the divine.

## DIAGNOSTIC_QUESTION_6
Write a short paragraph (4–5 lines) in Hindi or English imagining Raskhan's inner monologue at the moment he decided to leave his earlier life and settle in Vrindavan, using at least two details from the "Before You Read" section.

## DIAGNOSTIC_ANSWER_6
A strong response might be: "The verse from Jake Panjrekul echoed in my heart — 'हजरी-जके का इजसे' — and I could no longer stay in the world of hunting and painting. I left the court, the comforts, and walked to Braj, where every dust particle sings of Shyam. Now I will sing only of Him, in the language of the soil." A poor answer that invents unrelated details (e.g., "he met a guru in the forest") shows failure to anchor creativity in the given biographical facts.

## COMMON_MISCONCEPTION
Students often think Raskhan's Muslim background makes his Krishna-bhakti "unusual" or "syncretic" in a superficial way, leading them to write answers like "He was a Muslim who wrote Hindu poems." This misses the deeper point: in the Bhakti tradition, *devotion (bhakti) is not bound by birth-religion*; Raskhan's life *exemplifies* the movement's core teaching that God is accessible to all through love. The error stems from viewing religion through modern communal lenses rather than the medieval Bhakti framework where *bhakti* itself was the identity.

## ON_FAILURE
1. Re-read the "Before You Read" box *aloud* slowly, underlining every proper noun (Raskhan, Jake Panjrekul, Vrindavan, Gokul, Braj Bhasha). 2. Create a two-column table: left column = facts from the text (birth, turning point, works, death), right column = significance of each fact. 3. Watch a 5-minute video on "Bhakti Movement and Syncretism" (e.g., NCERT Class 12 History Chapter 6 summary). 4. Re-attempt Diagnostic Question 2 and 5, checking if your answers now reflect the *internal logic of bhakti* rather than external religious labels.

## BUILDS_ON
Class 11 "Before You Read" nodes that introduced medieval poets (Kabir, Surdas, Mirabai) and the Bhakti movement's key features.

## LEADS_TO
Textual analysis of the poem "हजरी-जके का इजसे" and prose from *Jake Panjrekul* in nodes c12_hin_a_cbse_06_002 through c12_hin_a_cbse_06_015.

## PREREQUISITE_NODE_IDS
c11_hin_ar_cbse_01_001, c11_hin_v_cbse_01_001, c11_hin_ar_cbse_06_001
## PREREQUISITE_REASONS
c11_hin_ar_cbse_01_001: Introduced the "Before You Read" skill for a medieval poet chapter, modeling how to extract biographical and historical context.
c11_hin_v_cbse_01_001: Provided practice in identifying Bhakti movement themes and poet backgrounds in the *Vitan* textbook.
c11_hin_ar_cbse_06_001: Likely covered a Bhakti poet (e.g., Surdas/Kabir) in Class 11 *Antra*, giving direct precedent for Raskhan's context.

## FORWARD_NODE_IDS
c12_hin_a_cbse_06_002, c12_hin_a_cbse_06_003, c12_hin_a_cbse_06_004, c12_hin_a_cbse_06_005, c12_hin_a_cbse_06_006, c12_hin_a_cbse_06_007, c12_hin_a_cbse_06_008, c12_hin_a_cbse_06_009, c12_hin_a_cbse_06_010, c12_hin_a_cbse_06_011, c12_hin_a_cbse_06_012, c12_hin_a_cbse_06_013, c12_hin_a_cbse_06_014, c12_hin_a_cbse_06_015
## FORWARD_REASONS
c12_hin_a_cbse_06_002: Plot/narrative structure analysis requires knowing the poet's life events that shape the narrative.
c12_hin_a_cbse_06_003: Setting/atmosphere (Vrindavan, Gokul) is established in the background.
c12_hin_a_cbse_06_004: Protagonist analysis (Radha/Krishna/Yashoda) needs the devotional context.
c12_hin_a_cbse_06_005: Supporting characters (gopis, cowherds) derive from the Bhakti milieu.
c12_hin_a_cbse_06_006: Primary theme (prem-bhakti) is rooted in the poet's own journey.
c12_hin_a_cbse_06_007: Secondary themes (virah, vatsalya) are introduced in the background.
c12_hin_a_cbse_06_008: Imagery/metaphor (flute, dust of Braj) draws from Raskhan's lived experience.
c12_hin_a_cbse_06_009: Irony/symbolism (Muslim poet singing Hindu bhakti) is contextual.
c12_hin_a_cbse_06_010: Key vocabulary (Braj words) is previewed in the background note.
c12_hin_a_cbse_06_011: Grammar/usage (Braj Bhasha forms) is framed by the poet's linguistic choice.
c12_hin_a_cbse_06_012: Comprehension questions assume knowledge of the poet's intent.
c12_hin_a_cbse_06_013: Critical interpretation builds on the historical-personal synthesis.
c12_hin_a_cbse_06_014: Writing tasks (e.g., article on Raskhan) need this background.
c12_hin_a_cbse_06_015: Discussion points (syncretism, language) originate here.

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
c12_history_bhakti_movement_001: Understanding the Bhakti movement's timeline, key figures, and syncretic ideology in medieval India provides the historical framework for Raskhan's life and work.
c12_geography_medieval_india_001: Knowledge of the Braj region (Vrindavan, Mathura, Gokul) — its geography, pilgrimage significance, and cultural landscape — helps visualize the setting of Raskhan's poetry.

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_01_001 -> c12_hin_a_cbse_06_001 -> c12_hin_a_cbse_06_002

## THIS_FORMULA
N/A - conceptual

## FORMULA_VARIABLES
N/A

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
conceptual

## CROSS_SUBJECT
N/A | The Bhakti movement's emphasis on personal devotion over ritual and its transcendence of caste/religious boundaries is the direct historical context for Raskhan's life and poetry.
 N/A | The Braj region's physical and cultural geography (Yamuna, forests, temples) is the living landscape in which Raskhan's poems are set and which he himself inhabited.
## PREREQ_CONCEPT
The Bhakti movement's core idea: direct, personal devotion (bhakti) to a chosen deity (here, Krishna) accessible to all regardless of birth, expressed in vernacular language.

## PREREQ_BEFORE
Student should recall the definition of Bhakti movement, names of major poet-saints (Kabir, Surdas, Mira, Tulsidas), and the shift from Sanskrit to regional languages.

## PREREQ_STUCK
If stuck, review Class 11 Hindi *Antra* Chapter 1 "Before You Read" (c11_hin_ar_cbse_01_001) and Class 12 History Chapter 6 "Bhakti-Sufi Traditions" (c12_history_bhakti_movement_001).

## WORKED_EXAMPLE_1
PROBLEM: A student reads the "Before You Read" section and must extract the three most significant turning points in Raskhan's life for a 2-mark board question.
STEPS:
- Step 1: Read the paragraph slowly and highlight all chronological markers (birth, early life, turning point, later life, death).
- Step 2: Identify the explicit turning point: "hearing a verse from Jake Panjrekul" leading to renunciation.
- Step 3: Infer the second turning point: his decision to settle in Vrindavan/Gokul and adopt the life of a bhakta.
- Step 4: Note the third key phase: his composition of major works (*Jake Panjrekul*, dohas, pads, savaiyas) in Braj Bhasha.
- Step 5: Verify that each point is directly supported by the text and not assumed.
REASONING: Board questions on biography require text-based evidence, not general knowledge. The "Before You Read" box is the only prescribed source for this chapter.
ANSWER: The three turning points are: (1) Birth in a Muslim family and early engagement in hunting/painting; (2) Spiritual transformation upon hearing a verse from *Jake Panjrekul*, leading to renunciation; (3) Settlement in Braj (Vrindavan/Gokul) and prolific devotional writing in Braj Bhasha.

## WORKED_EXAMPLE_2
PROBLEM: Explain how the "Before You Read" section prepares you to understand the poem "हजरी-जके का इजसे" (Radha's longing) before you read a single line of the poem.
STEPS:
- Step 1: Note the background says Raskhan wrote "pads" (lyrical poems) in Braj Bhasha — so expect a lyrical, musical verse.
- Step 2: See that he lived in Vrindavan/Gokul — so the poem's setting will be the Braj landscape (Yamuna, forests, cowsheds).
- Step 3: Recognize his core emotion is *prem-bhakti* (love-devotion) — so the poem will express intense personal longing for Krishna.
- Step 4: Connect the specific mention of "Radha's longing" in the chapter description to the poem's title "हजरी-जके का इजसे" (Hajri-Jake's longing).
- Step 5: Anticipate the tone: intimate, yearning, using *virah* (separation) imagery typical of Radha-Krishna poetry.
REASONING: Pre-reading context activates schema — the brain's framework for organizing new information. Knowing the poet's life, language, and thematic preoccupations lets you predict genre, setting, emotion, and even vocabulary.
ANSWER: The background tells us the poet is a Krishna-bhakta writing in Braj from Vrindavan, so the poem will be a Braj-lyric (pad) set in Braj, voiced by Radha in *virah*, expressing intense personal love for Krishna — exactly what we encounter.

## WORKED_EXAMPLE_3
PROBLEM: A CUET-style question asks: "Raskhan's poetry illustrates the syncretic culture of medieval India. Support this statement with two specific details from his life and works as given in the 'Before You Read' section."
STEPS:
- Step 1: Define "syncretic culture" in this context: blending of Hindu and Muslim traditions in spiritual practice and artistic expression.
- Step 2: Extract Detail 1 from text: Raskhan was born Muslim (Muslim family, early life in hunting/painting) but became a Krishna-bhakta, living in Hindu holy sites (Vrindavan/Gokul).
- Step 3: Extract Detail 2 from text: He composed in Braj Bhasha (a Hindu-associated vernacular) using Hindu mythological imagery (Radha, Krishna, Yashoda, gopis) and poetic forms (doha, pada, savaiya) rooted in Hindu Bhakti tradition.
- Step 4: Synthesize: These two details show *both* personal religious crossing *and* artistic-linguistic adoption, embodying syncretism.
- Step 5: Format as a concise answer with clear "Detail 1" and "Detail 2" for the examiner.
REASONING: Competitive exams like CUET test ability to use textual evidence for a conceptual claim. The "Before You Read" box is the evidence bank; the student must select and frame details precisely.
ANSWER: (1) Raskhan, born in a Muslim family, renounced his earlier life to live as a Krishna devotee in Vrindavan/Gokul, crossing religious boundaries in personal practice. (2) He wrote devotional poetry in Braj Bhasha — the language of Hindu Bhakti — employing Hindu deities (Radha, Krishna), themes (virah, vatsalya), and forms (doha, pada), thus merging Islamic origin with Hindu literary-spiritual tradition.

## COMPETENCY_QUESTION_1
QUESTION: The "Before You Read" section states that Raskhan's language is "वोडख" (voḍkh) and "सहज" (sahaj). A student claims this means his language is "simple and unpolished." Evaluate this claim and correct it using the context.
COMPETENCY: Critical interpretation of literary terminology in context
STEPS:
- Step 1: Recognize that "वोडख" and "सहज" are technical terms in Hindi literary criticism, not casual descriptions.
- Step 2: Recall/from context infer: "सहज" means natural, spontaneous, flowing — not artificial or overly Sanskritized.
- Step 3: "वोडख" (from Braj *voḍkh*) means forceful, powerful, impactful — carrying emotional weight.
- Step 4: Combine: The language is *both* accessible (sahaj) *and* emotionally potent (voḍkh) — a hallmark of great Bhakti poetry.
- Step 5: Conclude the student's claim is partially right (sahaj = simple) but dangerously incomplete (misses voḍkh = power).
ANSWER: The claim is inaccurate. "सहज" does mean natural/unpretentious, but "वोडख" means forceful, vigorous, emotionally resonant. Together they describe a language that is *both* easy on the ear *and* deep in impact — typical of Raskhan's Braj poetry which moves the listener while using everyday speech. Calling it merely "simple and unpolished" ignores its aesthetic power.
DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: Design a 3-question interview for Raskhan (if he were alive today) that would reveal the *inner conflict* and *resolution* in his spiritual journey, using only facts from the "Before You Read" section. Write the questions in Hindi or English.
COMPETENCY: Creative synthesis of biographical facts into interpretive questioning
STEPS:
- Step 1: Identify the conflict: Muslim upbringing + worldly pursuits (hunting, painting) vs. sudden Krishna-bhakti.
- Step 2: Identify the resolution: Renunciation, settlement in Braj, lifelong devotional writing.
- Step 3: Craft Question 1 targeting the moment of change: "What was the exact verse from Jake Panjrekul that stopped you in your tracks, and why did it shake your world?"
- Step 4: Craft Question 2 targeting the cost: "You left the court, the hunt, the brush — what did your family and peers say, and how did you answer them?"
- Step 5: Craft Question 3 targeting the new identity: "After 30 years in Vrindavan, when you write 'हजरी-जके का इजसे', are you Radha, or are you Raskhan speaking through her?"
ANSWER: 1. "वह कौन-सा पद था जके पंजरेकुल का जिसने आपका जीवन बदल दिया, और उसने ऐसा क्या कहा जो शिकार और चित्रकला से बड़ा लगा?" 2. "दरबार, शिकार, कूची छोड़कर ब्रज आने पर आपके अपनों ने क्या कहा? आपने उन्हें कैसे समझाया?" 3. "तीस साल ब्रज में रहकर जब आप 'हजरी-जके का इजसे' लिखते हैं, तो उसमें राधा बोल रही हैं या रसखान खुद राधा बनकर बोल रहे हैं?"
DIFFICULTY: hard