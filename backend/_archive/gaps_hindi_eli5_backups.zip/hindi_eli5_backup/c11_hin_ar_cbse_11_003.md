## DEFINITION
Setting refers to the physical, temporal, and social backdrop against which the poem's events unfold — in "?kj dh ;kn" this is the aging ancestral house with its cracked walls, leaky roof, and generations of family memories. Atmosphere is the emotional mood or feeling evoked by that setting — here a blend of melancholy decay, warm nostalgia, and resilient affection that makes the house feel alive with the poet's past.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student can independently identify at least three specific setting details from the poem, explain how each detail contributes to the overall atmosphere using textual evidence, and articulate the relationship between the physical decay of the house and the emotional warmth of the poet's memories.

## SCOPE_BOUNDARY
This node covers only the analysis of setting (time, place, physical description) and atmosphere (mood, tone, emotional resonance) in the poem "?kj dh ;kn". It does not include character analysis, thematic development, or literary devices beyond those directly creating setting and atmosphere.

## WALKTHROUGH
Imagine walking into your grandmother's old house after ten years — the smell of damp walls, the creak of the floorboards, the way sunlight falls on the same cracked tiles. That immediate sensory rush is exactly what the poet captures. Begin by reading the poem aloud twice: first for the overall feeling, then with a pencil to mark every word that describes the house physically (walls, roof, doors, rooms) and every word that conveys emotion (memories, longing, warmth). Notice how the poet never separates the two — the broken window isn't just broken, it's "the window where father used to sit". That fusion is the key insight: in this poem, setting and atmosphere are inseparable because the house IS the poet's memory.

## DIAGNOSTIC_QUESTION_1
What is the primary physical setting of the poem "?kj dh ;kn" and what time period does it suggest?

## DIAGNOSTIC_ANSWER_1
The primary setting is an old ancestral house (described through cracked walls, leaky roof, broken windows, and multiple generations living together) suggesting a timeless, possibly pre-modern Indian joint family home. A wrong answer that only says "a house" or "village" reveals the student hasn't noticed the specific sensory details (e.g., "izk.k eu f?kjrk", "pkj HkkbZ pkj cfgusa") that establish both the physical decay and the historical depth of the setting.

## DIAGNOSTIC_QUESTION_2
Explain in your own words how the poet creates a sense of nostalgia through the description of the house's deterioration.

## DIAGNOSTIC_ANSWER_2
The poet juxtaposes physical decay (cracked walls, leaking roof) with intimate family moments (father's chair, mother's kitchen, children playing) so that each flaw in the house becomes a vessel for memory — the broken window isn't just damage, it's where father sat; the leaking roof isn't just a problem, it's where monsoon memories live. A wrong answer that treats decay and nostalgia as separate ideas shows the student misses the poem's central technique: the setting's flaws are precisely what make it emotionally rich.

## DIAGNOSTIC_QUESTION_3
In stanza 3 (beginning "vkt xhrk ikB djosQ"), the poet describes future visitors reacting to the house. Apply the concept of atmosphere to explain what mood this imagined future scene creates for the present reader.

## DIAGNOSTIC_ANSWER_3
The imagined future visitors ("[ksyrs ;k [kM+s gksaxs") who will find the house strange and ask its name creates a poignant atmosphere of impermanence and loss — it makes the reader feel the fragility of the poet's world, knowing this living memory will become a ruin. Steps: 1) Identify the future scene described. 2) Note the contrast between current intimate knowledge ("ik¡posa dk uke") and future ignorance. 3) Recognize this projection forward deepens the present atmosphere of bittersweet attachment. A wrong answer focusing only on the visitors' actions misses the emotional effect on the reader.

## DIAGNOSTIC_QUESTION_4
Analyze how the repetition of "?kj u”kj esa frj jgk gS" (the house stands in the courtyard) at the end of multiple stanzas functions structurally to reinforce both setting and atmosphere.

## DIAGNOSTIC_ANSWER_4
The refrain acts as an anchor — each time it returns, it pulls the reader back to the physical reality of the house (setting) while accumulating emotional weight (atmosphere) because the preceding stanzas have added new memories to that same location. The house becomes a fixed point around which time, memory, and decay swirl. A wrong answer that calls it "just a chorus" or "repetition for rhythm" fails to see how the refrain structurally binds the poem's physical and emotional dimensions.

## DIAGNOSTIC_QUESTION_5
Evaluate whether the poem's atmosphere is ultimately one of despair or resilience. Support your judgment with two specific textual evidences.

## DIAGNOSTIC_ANSWER_5
The atmosphere is resilience — despite overwhelming physical decay ("jkr Hkj fxjrk", "izk.k eu f?kjrk"), the poem ends with the speaker claiming ownership of the house's story ("dke djrk gw¡ fd dguk / uke djrk gw¡ fd dguk") and asserting "eSa e”ks esa gw¡ lgh gS". Evidence 1: The father's voice persists in memory ("firk th dgrs jgs gSa") showing continuity. Evidence 2: The final stanza transforms the house from a decaying object into a living narrative the poet controls. A wrong answer choosing "despair" ignores the poet's agency in the closing lines and the warmth that permeates the decay.

## DIAGNOSTIC_QUESTION_6
Write a four-line stanza in Hindi that uses a specific setting detail (like a broken swing, a faded photograph, a silent courtyard) to create an atmosphere of bittersweet memory, modeling the technique used in "?kj dh ;kn".

## DIAGNOSTIC_ANSWER_6
A strong answer will: 1) Choose one concrete setting detail. 2) Attach a specific memory to it. 3) Use sensory language (smell, sound, touch). 4) End with an emotional resonance that lingers. Example: "tutte jhule ki vo jhankaar / ab bhi sunti hai raat bhar / nanhi ungliyon ki woh mehak / khamosh aangan mein bas rahi". A poor answer uses abstract nouns ("sadness", "memory") without a physical anchor, showing the student hasn't grasped how the poem makes atmosphere through concrete setting.

## COMMON_MISCONCEPTION
Students often treat setting as a static backdrop — just listing physical details like "old house, cracked walls, leaky roof" — and atmosphere as a separate label like "sad" or "nostalgic". They miss that in this poem, every physical detail is simultaneously an emotional trigger: the "pkj HkkbZ" (four walls) aren't just architecture, they're the boundaries that held the family; the "cfgu vkbZ" (dampness) isn't just moisture, it's the monsoon that soaked childhood games. The misconception arises because textbooks often teach setting and atmosphere as separate bullet points, but here they are fused — the house's decay IS the poetry's warmth.

## ON_FAILURE
1. Have the student pick ONE physical detail from the poem (e.g., "izk.k eu f?kjrk" — the leaking roof). 2. Ask: "What specific memory does the poet attach to this leak?" (Answer: monsoon nights, father's worry, family huddling). 3. Ask: "If the roof weren't leaking, would that memory exist?" Guide them to see the leak CREATES the memory. 4. Repeat with two more details until they can articulate: "The setting detail and the emotion are the same thing in this poem." 5. Then have them re-read the poem marking each physical detail with its attached memory in the margin.

## BUILDS_ON
Understanding the poem's narrative structure (node c11_hin_ar_cbse_11_002) is essential because the setting is revealed progressively through the poem's temporal shifts — past, present, imagined future — not all at once.

## LEADS_TO
Character analysis (nodes c11_hin_ar_cbse_11_004 and c11_hin_ar_cbse_11_005) because the characters (father, mother, children) are inseparable from the house — their identities are shaped by its rooms, and the house's atmosphere is built from their presence.

## PREREQUISITE_NODE_IDS
c11_hin_ar_cbse_11_001, c11_hin_ar_cbse_11_002
## PREREQUISITE_REASONS
c11_hin_ar_cbse_11_001: Provides the historical and biographical context (poet's life, joint family system) necessary to understand why this specific house carries such cultural weight.
c11_hin_ar_cbse_11_002: Establishes the poem's narrative movement (past memories → present decay → imagined future) which structures how setting details are introduced and layered with atmosphere.

## FORWARD_NODE_IDS
c11_hin_ar_cbse_11_004, c11_hin_ar_cbse_11_005, c11_hin_ar_cbse_11_006, c11_hin_ar_cbse_11_008, c11_hin_ar_cbse_11_007, c11_hin_ar_cbse_11_012, c11_hin_ar_cbse_11_014, c12_hin_a_cbse_06_003, c12_hin_a_cbse_11_003, c12_hin_ar_cbse_11_003

## FORWARD_REASONS
c11_hin_ar_cbse_11_004: The protagonist (the poet-speaker) is defined by his relationship to the house — his voice emerges from its walls.
c11_hin_ar_cbse_11_005: Supporting characters (father, mother, children) exist only through their interactions with the house's spaces.
c11_hin_ar_cbse_11_006: The primary theme (roots, memory, impermanence) is embodied in the house's setting and atmosphere.
c11_hin_ar_cbse_11_008: Imagery and metaphor (e.g., house as living body, walls as memory-keepers) are the devices that fuse setting and atmosphere.
c11_hin_ar_cbse_11_007: Understanding setting and atmosphere is crucial because secondary themes in this poem are deeply embedded in the physical and emotional landscape of the home.  
c11_hin_ar_cbse_11_012: Setting/atmosphere details are the primary textual evidence for inferential questions on mood.  
c11_hin_ar_cbse_11_014: Setting/atmosphere analysis provides evidence for mood-based questions.  
c12_hin_a_cbse_06_003: Temporal setting (time of day/season) effects  
c12_hin_a_cbse_11_003: Class 11 foundation on setting/atmosphere basics (pathetic fallacy, sensory imagery) — this node deepens, not repeats  
c12_hin_ar_cbse_11_003: Class 11 foundation for identifying setting components (time, place, social context) and basic atmosphere vocabulary.  

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_11_002 -> c11_hin_ar_cbse_11_003 -> c11_hin_ar_cbse_11_004

## THIS_FORMULA
N/A - conceptual

## FORMULA_VARIABLES
N/A

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
analytical

## CROSS_SUBJECT
c11_history_indian_nationalism | The poem's ancestral house mirrors the decay of traditional joint families during colonial modernity — a microcosm of social history.
c11_geography_human_settlements | The house as a settlement unit reflects how physical space shapes human relationships and cultural memory in rural India.

## PREREQ_CONCEPT
The student must understand that in poetry, setting is not merely background but an active participant in meaning-making, revealed through sensory imagery and temporal shifts.

## PREREQ_BEFORE
The student must have read the poem at least twice and be able to summarize its basic narrative arc (memories of father/mother → current decay → imagined future).

## PREREQ_STUCK
If stuck, review the poem's summary and context from node c11_hin_ar_cbse_11_001, focusing on the poet's life in a joint family and the symbolism of the ancestral home.

## WORKED_EXAMPLE_1
PROBLEM: Analyze how the first stanza establishes both the physical setting and the emotional atmosphere of the poem.
STEPS:
- Step 1: Identify the physical details in the first stanza — "vkt ikuh fxj jgk gS" (very old), "cgqr ikuh fxj jgk gS" (very very old), "jkr Hkj fxjrk jgk gS" (walls crumbling), "izk.k eu f?kjrk jgk gS" (roof leaking with dampness). These establish a house in advanced decay.
- Step 2: Identify the emotional cues — "cgqr ikuh fxj jgk gS" repeated with emphasis, "?kj u”kj esa frj jgk gS" (house stands in courtyard) suggesting endurance despite decay.
- Step 3: Notice the fusion — the age and decay are not presented as tragic but as factual, even familiar. The repetition of "cgqr ikuh fxj jgk gS" creates a rhythm of acceptance.
- Step 4: Determine the atmosphere — not horror at decay, but a quiet, weathered dignity. The house "stands" (frj jgk gS) — agency in persistence.
- Step 5: Connect to the poem's trajectory — this opening sets the baseline: a setting that is physically failing but atmospherically resilient, preparing us for the memories that explain WHY it still stands.
REASONING: The first stanza works like an establishing shot in film — it gives us the physical coordinates and the emotional weather simultaneously. The key is seeing that "ikuh" (old) and "frj" (stands) are not contradictory; the atmosphere emerges from their coexistence.
ANSWER: The first stanza establishes a setting of extreme physical decay (crumbling walls, leaking roof) while simultaneously creating an atmosphere of quiet endurance through the repetition of "cgqr ikuh fxj jgk gS" and the verb "frj" (stands). The house's age is not mourned but witnessed, setting up the poem's central tension: decay as the vessel of memory.

## WORKED_EXAMPLE_2
PROBLEM: Explain how the description of "pkj HkkbZ pkj cfgusa" (four walls, four doors) in stanza 2 functions as both a setting detail and an atmosphere builder.
STEPS:
- Step 1: Locate the detail — "?kj fd ?kj esa pkj HkkbZ / pkj HkkbZ I;kj cfgusa" (in the house, four walls / four walls, four doors). This is a precise architectural description.
- Step 2: Analyze the numerical precision — "pkj" (four) repeated four times. This suggests order, completeness, a structured space.
- Step 3: Contrast with the decay from stanza 1 — the house is falling apart (jkr Hkj fxjrk) yet still has four walls and four doors. The structure persists.
- Step 4: Connect to family — "ek;osQ esa cfgu vkbZ / cfgu vkbZ cki osQ ?kj" (in the courtyard, dampness spreads / dampness spreads, the house of dampness). The walls and doors contain the dampness, the family, the life.
- Step 5: Determine atmospheric effect — the four walls/doors become a metaphor for the family unit: defined boundaries that hold both decay ("cfgu") and life. The atmosphere is one of containment — the house holds it all.
REASONING: The poet uses a simple architectural fact (four walls, four doors) and through repetition and placement next to "cfgu" (dampness/decay), transforms it into a symbol of resilient containment. The setting detail becomes atmospheric because it represents what endures.
ANSWER: The "four walls, four doors" detail precisely maps the house's layout (setting) while the repetition and juxtaposition with spreading dampness create an atmosphere of structured endurance — the house's skeleton remains intact to hold both decay and family life, making the boundaries themselves feel protective and alive.

## WORKED_EXAMPLE_3
PROBLEM: The poem shifts between past, present, and imagined future. Analyze how this temporal layering deepens the atmosphere of the house as a living entity.
STEPS:
- Step 1: Map the temporal layers — Present: "vkt ikuh fxj jgk gS" (now it is very old). Past: "firk th ftudks cq<+kik" (father who was young), "ek¡ us dgk gksxk" (mother would say). Future: "tc fd uhps vk, gksaxs" (when they come down), "[ksyrs ;k [kM+s gksaxs" (they will see or be amazed).
- Step 2: Identify the constant — In all three times, the house is the anchor: "?kj u”kj esa frj jgk gS" repeats across stanzas.
- Step 3: Analyze the past layer — Father's voice ("I;kj esa cgrs jgs gSa"), mother's predictions ("nq%[k fdruk cgk gksxk") — the house witnessed their lives.
- Step 4: Analyze the future layer — Strangers will not know its name ("ik¡posa dk uke ysdj"), but the poet claims "eSa e”ks esa gw¡ lgh gS" (I am right here).
- Step 5: Synthesize — The house exists in all three tenses simultaneously. It is not a ruin of the past nor a future ruin; it is a present consciousness that holds time.
- Step 6: Conclude atmosphere — This temporal depth makes the house feel alive, almost sentient. The atmosphere transcends nostalgia (which is only past-oriented) and becomes a form of immortality: the house IS the poet's ongoing act of remembering.
REASONING: The temporal shifts are not decorative — they prove the house's atmosphere is not static. By showing the house in past, present, and future, the poet demonstrates that setting can be a living consciousness. The atmosphere is the feeling of being inside that consciousness.
ANSWER: The temporal layering transforms the house from a decaying building into a living entity that exists simultaneously in past (father's voice, mother's words), present (poet's ownership), and future (imagined strangers). The refrain "?kj u”kj esa frj jgk gS" anchors all three times, creating an atmosphere of timeless presence — the house doesn't just hold memories, it actively remembers through the poet.

## COMPETENCY_QUESTION_1
QUESTION: The poem describes the house as "cfgu vkbZ cki osQ ?kj" (house of dampness/dampness's house). Using this phrase, explain how the poet reverses the usual relationship between a house and its flaws to create a unique atmosphere.
COMPETENCY: Interpretative analysis of metaphorical reversal in setting description
STEPS:
- Step 1: Identify the usual relationship — a house HAS dampness; dampness is a flaw in the house.
- Step 2: Identify the reversal — "cfgu vkbZ cki osQ ?kj" makes dampness the possessor and the house the possession. The house belongs to the dampness.
- Step 3: Explain the atmospheric effect — this suggests the decay is not an intruder but the true owner; the house has surrendered to time, yet this surrender is described without despair.
- Step 4: Connect to the larger pattern — the poet consistently gives agency to the house's flaws (walls crumble actively, roof leaks actively), making the decay feel alive and almost affectionate.
ANSWER: By phrasing it as "dampness's house" rather than "house with dampness", the poet makes decay the central identity of the setting. This reversal creates an atmosphere where deterioration is not a failure but a form of authenticity — the house has become what time made it, and that honesty is its dignity. The flaw IS the character.
DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: In the final stanza, the speaker says "dke djrk gw¡ fd dguk / uke djrk gw¡ fd dguk" (I do the work of speaking / I do the work of naming). How does this declaration transform the house from a physical setting into an atmosphere of resistance? Provide a structured answer with textual evidence.
COMPETENCY: Synthesis of setting, atmosphere, and speaker agency in poetic closure
STEPS:
- Step 1: Establish the house as physical setting — throughout the poem, it is described through sensory decay (cracks, leaks, dampness).
- Step 2: Identify the shift in the final stanza — the speaker stops describing the house and starts claiming authorship of its story ("dke djrk gw¡ fd dguk").
- Step 3: Analyze "uke djrk gw¡ fd dguk" — naming is an act of power; to name something is to define its reality. The poet refuses to let future strangers name it ("ik¡posa dk uke ysdj").
- Step 4: Connect to atmosphere — the physical decay remains, but the emotional atmosphere shifts from passive endurance to active preservation. The house survives BECAUSE the poet speaks it.
- Step 5: Conclude with evidence — the final lines "gs lthys gjs lkou / gs fd esjs iq.; ikou" (like this only, like my own home) affirm that the poet's voice IS the house's continued existence.
ANSWER: The declaration transforms the house from a decaying object (setting) into a living narrative (atmosphere of resistance). By claiming the "work of speaking/naming", the poet makes the house's survival dependent on his voice — not its walls. The atmosphere becomes one of defiant continuity: the house stands not because of its "pkj HkkbZ" but because "eSa e”ks esa gw¡ lgh gS". The physical ruin is transcended by the act of poetic witness.
DIFFICULTY: hard