## DEFINITION
Speaking and Listening: Discussion Points refers to the structured oral activity where students collaboratively explore the themes, characters, and social issues of the chapter "इजसेपन" (specifically the story "उद्देश्य") by expressing reasoned viewpoints, actively listening to peers, and building on each other's ideas using textual evidence.

## COGNITIVE_LEVEL
apply

## MASTERY_CRITERIA
The student can prepare 2-3 discussion points supported by specific textual references, speak clearly for 1-2 minutes, listen actively to at least two peers, and respond by agreeing, disagreeing, or extending their ideas with evidence from the story.

## SCOPE_BOUNDARY
This node covers the process of preparing for and participating in a formal group discussion based on the chapter "इजसेपन". It does not cover writing analytical essays, detailed literary device identification, or grammar rules, which are addressed in sibling nodes.

## WALKTHROUGH
Imagine your teacher announces a class discussion on whether the protagonist Vyaksihnhu's rebellion against the colonial education system was justified. You feel nervous because you're not sure how to start or what to say. First, recall the key conflicts from the story: Vyaksihnhu's resignation, his confrontation with the inspector, and the villagers' reaction. Next, pick one clear stance (e.g., "His rebellion was justified because it exposed systemic injustice"). Then, find two short passages that support your stance (e.g., his speech about self-respect, the description of the school's conditions). Practice stating your point in one sentence, then quoting the evidence, then explaining the link. During the discussion, listen for keywords in others' speeches, note down their arguments, and respond directly to them using phrases like "Building on what X said..." or "I see it differently because...". The key insight is that a good discussion is not a speech contest but a collaborative investigation where evidence from the text is the shared currency.

## DIAGNOSTIC_QUESTION_1
What is the primary purpose of a 'discussion point' in a Class 11 speaking and listening activity based on a literary text?

## DIAGNOSTIC_ANSWER_1
A discussion point is a focused, arguable claim about the text that a student prepares in advance, supported by specific textual evidence, to initiate or deepen a collaborative conversation. A wrong answer (e.g., "It's just my opinion on the story") reveals the misconception that discussion is about sharing unsupported personal feelings rather than evidence-based literary analysis.

## DIAGNOSTIC_QUESTION_2
In the story "उद्देश्य", Vyaksihnhu says, "नौकरी में वक़्त की पाबंदी... यह तो हज का तकाज़ा है।" Explain in your own words what this statement reveals about his attitude towards the colonial education system.

## DIAGNOSTIC_ANSWER_2
The statement reveals Vyaksihnhu's view that the colonial system reduces education to a mechanical, soul-crushing routine where punctuality and obedience are valued over genuine learning and human dignity. A wrong answer (e.g., "He hates his job") shows the student cannot connect the specific quote to the broader thematic critique of institutional dehumanization.

## DIAGNOSTIC_QUESTION_3
You are preparing a discussion point on the theme of 'self-respect vs. survival' in the story. Select ONE specific incident from the text (not the resignation scene) and explain how you would use it to argue that Vyaksihnhu prioritizes self-respect.

## DIAGNOSTIC_ANSWER_3
A strong answer would cite the scene where Vyaksihnhu refuses to accept the inspector's bribe-like offer of a transfer ("डाक्टर साहब ने... तबादला करा देने का वादा किया") and instead chooses to resign. Steps: 1) Identify the incident (refusal of transfer). 2) Quote the key dialogue ("मैं आपकी कृपा का भूखा नहीं हूँ"). 3) Explain how this action sacrifices his livelihood (survival) for dignity (self-respect). 4) Connect to the theme. A wrong answer using a vague reference ("he was brave") shows inability to anchor arguments in textual specifics.

## DIAGNOSTIC_QUESTION_4
Compare the listening stance required in a literary discussion versus a casual conversation with friends. How does the demand for 'textual evidence' change the way you listen?

## DIAGNOSTIC_ANSWER_4
In a literary discussion, you listen for textual references (quotes, incidents, character actions) to evaluate the validity of a peer's claim, whereas in casual conversation you listen for emotional resonance or shared experience. The evidence requirement forces you to track specific page numbers or dialogues mentally, making listening an analytical act of verification. A wrong answer ("It's the same, just more formal") misses the cognitive shift from passive reception to active critical auditing.

## DIAGNOSTIC_QUESTION_5
Evaluate this student's discussion contribution: "Vyaksihnhu was foolish to resign because he had a family to feed. The author should have made him compromise." Is this a valid literary discussion point? Why or why not?

## DIAGNOSTIC_ANSWER_5
No, it is not a valid discussion point because it judges the character's morality from an external, real-world perspective rather than analyzing the author's thematic intent. A valid point would be: "Premchand constructs Vyaksihnhu's resignation as a tragic necessity to expose the impossibility of dignity under colonialism, as shown by the villagers' helplessness." The wrong answer reveals the misconception that discussion is about agreeing/disagreeing with characters' life choices rather than interpreting authorial craft.

## DIAGNOSTIC_QUESTION_6
Create a new discussion question for the story "उद्देश्य" that would require participants to synthesize the theme of education with the theme of colonial power. Write the question and a model opening statement (2-3 sentences) with one piece of evidence.

## DIAGNOSTIC_ANSWER_6
Question: "How does the school building itself function as a symbol of colonial control in the story?" Model opening: "The dilapidated school building, described as 'टूटी-फूटी दीवारें' and 'कमरों में अंधेरा', symbolizes how colonial education neglects the intellectual and physical growth of Indian children while demanding their obedience. For instance, the inspector's tour focuses on punctuality registers, not learning outcomes." A poor question (e.g., "Did you like the story?") shows inability to design analytical, evidence-driven prompts.

## COMMON_MISCONCEPTION
Students believe a discussion is a series of isolated speeches where each person states their opinion. They prepare a monologue, ignore others' points, and treat textual evidence as optional decoration. This stems from confusing 'speaking' with 'discussing' and from school experiences where 'participation' is often rewarded for volume rather than analytical engagement.

## ON_FAILURE
1. Model a 3-turn mini-discussion with a volunteer: You make a claim with evidence → Student responds by referencing your evidence → You extend. 2. Give the student a 'Discussion Tracker' sheet with columns: 'Peer's Point', 'Evidence They Used', 'My Response (Agree/Disagree/Extend)', 'My Evidence'. 3. Practice with a low-stakes topic (e.g., "Should the village have supported Vyaksihnhu?") using the tracker. 4. Debrief: "Notice how your response changed when you had to write down their evidence first."

## BUILDS_ON
This node builds on the student's ability to identify themes, character motivations, and key incidents from the story (covered in nodes c11_hin_ar_cbse_01_002 to c11_hin_ar_cbse_01_007).

## LEADS_TO
This node enables the student to transfer oral analytical skills to the writing skills node (c11_hin_ar_cbse_01_014) where they must structure written arguments with evidence.

## PREREQUISITE_NODE_IDS
c11_hin_ar_cbse_01_002, c11_hin_ar_cbse_01_004, c11_hin_ar_cbse_01_006, c11_hin_ar_cbse_01_012, c11_hin_ar_cbse_01_013, c11_hin_ar_cbse_01_001, c11_hin_ar_cbse_01_008, c11_hin_ar_cbse_01_014

## PREREQUISITE_REASONS
c11_hin_ar_cbse_01_002: Provides plot and narrative structure knowledge needed to reference specific incidents in discussion.
c11_hin_ar_cbse_01_004: Supplies protagonist analysis essential for discussing Vyaksihnhu's motives and actions.
c11_hin_ar_cbse_01_006: Gives primary theme understanding required to formulate thematic discussion points.
c11_hin_ar_cbse_01_012: Develops literal and inferential comprehension skills to accurately cite textual evidence.
c11_hin_ar_cbse_01_013: Builds critical interpretation skills to move beyond summary to analysis in discussion.
c11_hin_ar_cbse_01_001: "Context and Background" refers to the historical, social, biographical, and literary circ... की समझ आवश्यक है, क्योंकि यह नोड (Speaking and Listening:) इसी आधार पर आगे बढ़ता है।  
c11_hin_ar_cbse_01_008: Speaking/listening discussions need device-vocabulary to articulate responses.  
c11_hin_ar_cbse_01_014: Written PEEL arguments become speaking points; students convert each paragraph into a 1-minute oral presentation with the same structure.  

## FORWARD_NODE_IDS
c12_hin_a_cbse_01_015, c12_hin_a_cbse_04_015, c12_hin_a_cbse_05_015, c12_hin_a_cbse_06_015, c12_hin_a_cbse_09_015, c12_hin_a_cbse_12_015, c12_hin_a_cbse_17_015, c12_hin_al_cbse_01_015, c12_hin_al_cbse_02_015, c12_hin_al_cbse_03_015, c12_hin_ar_cbse_01_015, c12_hin_ar_cbse_03_015, c12_hin_ar_cbse_06_015, c12_hin_ar_cbse_12_015, c12_hin_ar_cbse_01_006

## FORWARD_REASONS
none: This is the final node in the chapter sequence; no subsequent nodes depend on it.
c12_hin_a_cbse_01_015: Class 11 ASL foundation establishes baseline speaking/listening protocols (turn-taking, formal register).  
c12_hin_a_cbse_04_015: Establishes baseline speaking-listening protocols (turn-taking, respectful disagreement) that this node refines for literary texts.  
c12_hin_a_cbse_05_015: Builds on prior year's speaking/listening foundation.  
c12_hin_a_cbse_06_015: कक्षा 11 में मौखिक चर्चा का प्रारंभिक अभ्यास (बुनियादी PEEL) यहाँ विस्तार पाता है।  
c12_hin_a_cbse_09_015: First chapter ASL exposure — recalls basic turn-taking and respectful disagreement protocols.  
c12_hin_a_cbse_12_015: अगला तार्किक चरण: Speaking and Listening: इस नोड की अवधारणाओं को सीधे उपयोग/विस्तारित करता है।  
c12_hin_a_cbse_17_015: Class 11 speaking/listening foundation establishes baseline protocol familiarity  
c12_hin_al_cbse_01_015: अगला तार्किक चरण: Speaking and Listening Discussion Points for "lwjnkl dh >ksaiM+h" are structured oral activities whe... इस नोड की अवधारणाओं को सीधे उपयोग/विस्तारित करता है।  
c12_hin_al_cbse_02_015: Prior year speaking/listening practice builds baseline discussion fluency.  
c12_hin_al_cbse_03_015: Prior ASL practice builds baseline speaking/listening confidence  
c12_hin_ar_cbse_01_015: अगला तार्किक चरण: Speaking and Listening: इस नोड की अवधारणाओं को सीधे उपयोग/विस्तारित करता है।  
c12_hin_ar_cbse_03_015: Prior speaking/listening baseline — this node assumes familiarity with turn-taking, active listening basics  
c12_hin_ar_cbse_06_015: Class 11 foundation for discussion protocols (turn-taking, building on peers).  
c12_hin_ar_cbse_12_015: अगला तार्किक चरण: Speaking and Listening: इस नोड की अवधारणाओं को सीधे उपयोग/विस्तारित करता है।  
c12_hin_ar_cbse_01_006: c12_hin_ar_cbse_01_014: Writing skills (PEEL structure) transfer directly to spoken argumentation. c11_hin_ar_cbse_01_015: Class 11 speaking/listening foundation — basic turn-taking, active listening protocols.  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
none: No prior class nodes available for cross-subject linking.

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_01_002 -> c11_hin_ar_cbse_01_015 -> none

## THIS_FORMULA
N/A - conceptual

## FORMULA_VARIABLES
N/A

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
linguistic

## CROSS_SUBJECT
c11_history_colonial_education | The story critiques the colonial education system; history provides context on Macaulay's Minutes and Wood's Despatch which shaped the system Vyaksihnhu rebels against.
c11_civics_rights_dignity | Vyaksihnhu's resignation is an assertion of human dignity against institutional oppression; civics explores fundamental rights and the concept of dignity in the Indian Constitution.
c11_economics_labour_exploitation | The inspector's offer of transfer in exchange for compliance mirrors economic coercion; economics examines labour rights and power imbalances in employer-employee relationships.

## PREREQ_CONCEPT
The student must be able to locate and cite specific textual evidence (dialogues, descriptions, narrative comments) to support an interpretive claim about the story.

## PREREQ_BEFORE
Before starting this node, the student should have completed the comprehension and critical thinking nodes (c11_hin_ar_cbse_01_012, c11_hin_ar_cbse_01_013) to ensure they can move beyond plot summary to analysis.

## PREREQ_STUCK
If stuck, review the 'Critical Thinking: Analysis and Interpretation' node (c11_hin_ar_cbse_01_013) to practice forming evidence-based claims about the story's themes.

## WORKED_EXAMPLE_1
PROBLEM: Prepare a 2-minute discussion opening on the topic: "The story 'उद्देश्य' shows that individual rebellion is futile against systemic oppression." You must take a clear stance (agree/disagree) and use two pieces of textual evidence.

STEPS:
- Step 1: Decide your stance. Choose "Disagree" because the story ends with Vyaksihnhu's dignity intact and the villagers' awakening, suggesting rebellion has moral value even if it doesn't change the system immediately.
- Step 2: Select Evidence 1. Vyaksihnhu's final speech to the inspector: "मैंने अपनी आत्मा बेच दी होती... वह मैंने नहीं किया." This shows his rebellion preserves his self-respect.
- Step 3: Select Evidence 2. The villagers' reaction: "लोगों ने देखा... एक आदमी ने नौकरी छोड़ दी." This shows his act inspires collective consciousness, a seed for future resistance.
- Step 4: Structure the opening: Stance sentence → Evidence 1 with quote → Explanation of how it supports stance → Evidence 2 with quote → Explanation → Concluding sentence linking to the topic.
- Step 5: Rehearse aloud, timing yourself. Ensure the tone is conversational but analytical, not memorized.

REASONING: This process moves the student from opinion to argument by forcing evidence selection first, then building the speech around the evidence. The two-evidence requirement ensures depth, and the stance-first approach prevents rambling.

ANSWER: "I disagree that rebellion is futile. First, Vyaksihnhu tells the inspector, 'मैंने अपनी आत्मा बेच दी होती... वह मैंने नहीं किया,' proving his rebellion succeeded in preserving his integrity — a victory the system couldn't take. Second, the narrator notes the villagers watched 'एक आदमी ने नौकरी छोड़ दी,' implying his act planted a seed of resistance in the collective mind. Futility would mean no change at all; here, both the individual and the community are transformed."

## WORKED_EXAMPLE_2
PROBLEM: During a discussion, a peer says: "The inspector is just doing his job; he's not the villain." You want to respond by complicating this view using the concept of 'complicity in systemic evil'. Use one textual detail.

STEPS:
- Step 1: Acknowledge the peer's point to show active listening: "That's a fair reading — the inspector does follow procedures."
- Step 2: Pivot to your complication: "But the story shows how 'just doing the job' upholds an unjust system."
- Step 3: Identify textual detail: The inspector's offer to Vyaksihnhu: "डाक्टर साहब ने... तबादला करा देने का वादा किया" — a bribe to buy silence.
- Step 4: Explain the detail: This offer reveals the inspector knows the system is corrupt but chooses to manage dissent rather than address injustice.
- Step 5: Synthesize: "So he's not a cartoon villain, but a functionary who enables oppression by prioritizing order over justice."

REASONING: This models the 'Agree-But-Pivot' discussion move, which validates the peer while advancing analysis. Using a specific textual detail (the bribe offer) grounds the abstract concept of complicity in the story's reality.

ANSWER: "I agree he's not a villain in a personal sense, but the story critiques his role as a functionary. When he offers Vyaksihnhu a transfer — 'तबादला करा देने का वादा किया' — to withdraw his resignation, he's essentially bribing him to keep quiet. That shows he knows the system is unjust but prefers managing dissent to fixing it. That's complicity."

## WORKED_EXAMPLE_3
PROBLEM: Design a discussion activity for a group of 5 students on the theme: "Education as a tool of liberation vs. education as a tool of control in 'उद्देश्य'." Specify the preparation task, the discussion structure (time, roles), and the assessment criteria for the teacher.

STEPS:
- Step 1: Preparation Task (Homework): Each student finds 2 quotes — one showing education as control (e.g., inspector's emphasis on punctuality registers), one showing education as liberation (e.g., Vyaksihnhu's teaching of self-respect). Write a 3-sentence explanation for each.
- Step 2: Discussion Structure (20 mins): 2 mins - Silent review of notes. 10 mins - Round-robin sharing: each student presents one 'control' quote and one 'liberation' quote with explanation. 5 mins - Open debate: "Which view does the story ultimately endorse?" 3 mins - Group synthesis: one student summarizes the emerging consensus.
- Step 3: Roles: Facilitator (keeps time, ensures equal turns), Evidence Tracker (notes quotes used), Devil's Advocate (challenges consensus), Summarizer, Observer (gives feedback on listening).
- Step 4: Assessment Criteria (Teacher): 1) Preparation quality (quotes + explanations submitted). 2) Speaking: Uses textual evidence, clear stance, responds to peers. 3) Listening: Notes peers' points, builds on them (tracker sheet). 4) Collaboration: Stays on topic, respectful disagreement.
- Step 5: Differentiation: Struggling students get a quote bank; advanced students must connect to Premchand's other stories (e.g., 'पूस की रात').

REASONING: This worked example models how to translate the abstract skill 'discussion' into a concrete, assessable classroom activity with scaffolding (quote bank), structure (roles, time), and clear criteria aligned to the mastery statement.

ANSWER: Activity Plan: "Theme: Education as Liberation vs. Control. Prep: 2 quotes + explanations per student. Structure: 20-min guided discussion with 5 roles. Assessment: 4-criteria rubric (Prep, Speaking, Listening, Collaboration). Differentiation: Quote bank for support; intertextual links for extension."

## COMPETENCY_QUESTION_1
QUESTION: You are the facilitator in a group discussion on "उद्देश्य". A quiet student finally speaks: "I think Vyaksihnhu was wrong to leave his students." The group falls silent. What specific facilitation move would you make to deepen the discussion, and what textual evidence would you prompt the group to examine?

COMPETENCY: Facilitation and evidence-based probing
STEPS:
- Step 1: Validate the contribution: "That's a crucial perspective — the students' welfare is the silent casualty."
- Step 2: Reframe as an analytical question: "Let's examine the text: Does the story give us any evidence about what happens to the students after he leaves?"
- Step 3: Direct to specific passage: "Look at the last two paragraphs — the narrator describes the village atmosphere. What does it say about the children?"
- Step 4: Synthesize: "So the text suggests... [students answer]. How does that complicate the idea that he was 'wrong'?"

ANSWER: Facilitation move: "Validate → Reframe as text-based inquiry → Direct to specific passage (ending paragraphs) → Synthesize." Evidence to prompt: The final description of the village — "लोगों ने देखा... एक आदमी ने नौकरी छोड़ दी" and the silence of the school — to analyze whether the students are abandoned or inspired.
DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: Write a 150-word reflective paragraph evaluating your own participation in a discussion on "उद्देश्य". Use the following framework: (1) One discussion point you made with evidence, (2) One peer's point that changed your thinking, (3) One listening behavior you need to improve, (4) A goal for the next discussion.

COMPETENCY: Metacognitive self-assessment of speaking and listening
STEPS:
- Step 1: Recall your own contribution. Example: "I argued that Vyaksihnhu's resignation was an act of teaching, using his final speech: 'मैंने अपनी आत्मा बेच दी होती...'"
- Step 2: Recall a peer's point that shifted you. Example: "Riya noted the villagers' passivity — they watched but didn't act — which made me see his rebellion as isolated, not catalytic."
- Step 3: Identify a listening gap. Example: "I interrupted Arjun before he finished his evidence because I wanted to counter him."
- Step 4: Set a SMART goal. Example: "Next time, I will write down the peer's full argument and evidence before formulating my response."
- Step 5: Write the paragraph integrating all four elements coherently.

ANSWER: "In yesterday's discussion, I argued that Vyaksihnhu's resignation was itself a pedagogical act, citing his declaration 'मैंने अपनी आत्मा बेच दी होती... वह मैंने नहीं किया' as proof that he taught dignity by example. However, Riya's observation that the villagers remained passive spectators — 'लोगों ने देखा... एक आदमी ने नौकरी छोड़ दी' — without collective action, forced me to reconsider whether his act sparked change or merely highlighted inertia. I noticed I interrupted Arjun mid-sentence to rebut him, missing his nuance about the inspector's dilemma. My goal for the next discussion: I will use a two-column note sheet — 'Peer's Point/Evidence' and 'My Response' — to enforce a 5-second pause before speaking, ensuring I listen to understand, not just to reply."
DIFFICULTY: hard