## DEFINITION
Secondary themes are the underlying ideas, motifs, or messages that support, contrast, or enrich the primary theme of a literary work. In Chapter 1 of *Antra*, the two poems — *nsolsuk dk xhr* and *dkusZfy;k dk xhr* — carry a primary theme of patriotism and national awakening, while secondary themes include **individual desire vs. social constraints**, **the pain of unfulfilled love**, **gender inequality in traditional society**, **nature as a mirror of human emotion**, **sacrifice for the motherland**, and **cultural pride rooted in heritage**. Identifying secondary themes requires tracing recurring images, emotional tones, and character perspectives across stanzas.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student can independently identify at least three secondary themes in both poems, cite specific lines/imagery as evidence, explain how each secondary theme interacts with the primary theme of patriotism, and write a structured 150-word analysis using the Point-Evidence-Explanation-Link (PEEL) method.

## SCOPE_BOUNDARY
This node covers **only** the identification, analysis, and written articulation of secondary themes in the two poems of Chapter 1 (*nsolsuk dk xhr* and *dkusZfy;k dk xhr*). It does **not** cover literary devices (imagery, irony, symbolism), vocabulary, grammar, comprehension questions, or writing skills based on the chapter — those are handled in sibling nodes 008–015.

## WALKTHROUGH
Imagine you are asked in the board exam: *"How does the poem *nsolsuk dk xhr* reflect the condition of women in early 20th-century India while also contributing to the novel's nationalist tone?"* You recall the primary theme (patriotism) from the previous node, but this question demands **more** — it asks for the *other* layers. Start by **re-reading both poems aloud**, noting shifts in tone: the first poem moves from personal grief to quiet rebellion; the second from descriptive beauty to a call for action. **Mark three recurring patterns** in each poem (e.g., references to *chudiyaan*, *jhanjhar*, *purdah* in Poem 1; *Himalaya*, *Ganga*, *kisan* in Poem 2). **Ask:** "What human experiences do these patterns represent beyond love for the country?" That question leads you to secondary themes. The key insight: **secondary themes are not separate — they deepen the primary theme by showing *who* suffers, *what* is lost, and *why* freedom matters at the human level.**

## DIAGNOSTIC_QUESTION_1
What is the definition of a secondary theme in literature, and how does it differ from the primary theme?

## DIAGNOSTIC_ANSWER_1
A secondary theme is a subordinate idea that runs alongside the primary theme, enriching it by exploring specific human experiences, social issues, or emotional conflicts. Unlike the primary theme — which is the central, unifying message (e.g., patriotism in these poems) — secondary themes are multiple, more localized, and often revealed through character voice, imagery, or subplots.  
**Wrong answer reveals:** If a student says "secondary theme is just a smaller theme" or "it's the same as the main idea but less important," they confuse *hierarchy* with *function*. The difference is structural: the primary theme organizes the whole work; secondary themes provide texture, contrast, and universality.

## DIAGNOSTIC_QUESTION_2
In *nsolsuk dk xhr*, the speaker says: *"eSaus Hkzeo'k thou lafpr] eèkqdfj;ksa dh Hkh[k yqVkbZ"* (I have spent my life in bonds, breaking the dreams of women). Explain in your own words what secondary theme this line reveals and how it connects to the primary theme of the chapter.

## DIAGNOSTIC_ANSWER_2
This line reveals the secondary theme of **gendered oppression within traditional society** — the systematic crushing of women's aspirations. It connects to the primary theme (patriotism/national awakening) by implying that true national freedom cannot exist while half the population remains enslaved by custom. The speaker's personal bondage becomes a metaphor for the nation's subjugation.  
**Wrong answer reveals:** If a student only says "it shows women are sad" or "it's about love," they miss the **systemic critique** and the **thematic bridge** to nationalism. They treat the line as personal emotion only, not as a deliberate thematic layer.

## DIAGNOSTIC_QUESTION_3
Apply the PEEL method to analyze how the image of *"ykSVk yks ;g viuh Fkkrh / esjh djQ.kk gk&gk [kkrh"* (This vermilion is your right, it eats my flesh like fire) in *nsolsuk dk xhr* supports a secondary theme. Write the full PEEL paragraph.

## DIAGNOSTIC_ANSWER_3
**Point:** The vermilion (sindoor) symbolizes the oppressive weight of forced marriage and widowhood rituals imposed on women.  
**Evidence:** The line *"ykSVk yks ;g viuh Fkkrh / esjh djQ.kk gk&gk [kkrh"* directly equates a symbol of marital auspiciousness with physical torture.  
**Explanation:** The metaphor transforms a cultural marker into an instrument of violence, exposing how tradition weaponizes symbols to control women's bodies.  
**Link:** This reinforces the secondary theme of **ritualized gender violence**, which parallels the primary theme: just as the nation is shackled by colonial rule, women are shackled by patriarchal custom — both demand liberation.  
**Wrong answer reveals:** If a student writes only "it shows she hates sindoor" or "it's a metaphor for pain," they fail to **name the theme**, **explain the cultural mechanism**, or **link to the primary theme** — treating PEEL as a labeling exercise, not an analytical scaffold.

## DIAGNOSTIC_QUESTION_4
Compare the role of **nature imagery** in both poems as a vehicle for secondary themes. How does *dkusZfy;k dk xhr* use nature differently from *nsolsuk dk xhr*?

## DIAGNOSTIC_ANSWER_4
In *nsolsuk dk xhr*, nature (*jhanjhar*, *chudiyaan*, *raat*, *chandni*) reflects the speaker's **inner turmoil and confinement** — the moon witnesses her sleeplessness, the bangles mock her silence. Nature is a **mirror of private grief**.  
In *dkusZfy;k dk xhr*, nature (*Himalaya, Ganga, khet-khalihan, kisan*) embodies **collective strength, fertility, and enduring identity** — the land *is* the nation. Nature here is a **symbol of public pride and resistance**.  
**Wrong answer reveals:** If a student says "both poems use nature beautifully" or lists images without contrasting their **thematic function**, they miss the analytical shift from *subjective* to *objective*, *personal* to *collective* — a core distinction in thematic analysis.

## DIAGNOSTIC_QUESTION_5
Evaluate this student claim: *"The secondary theme of 'sacrifice' in dkusZfy;k dk xhr is identical to the primary theme of patriotism — so it's not really a separate theme."* Defend or refute with textual reasoning.

## DIAGNOSTIC_ANSWER_5
**Refute.** While sacrifice *serves* patriotism, it operates as a distinct secondary theme because it **particularizes** the abstract ideal. The lines *"gse oqaQHk ys m"kk losjs / Hkjrh <qydkrh lq[k esjs"* (The green fields wave their heads, the golden harvest smiles at me) and *"efnj m¡Q?krs jgrs tc / txdj jtuh Hkj rkjk"* (When the plough turns the soil, the sweat becomes gold) show sacrifice as **daily labor of peasants**, not just heroic martyrdom. This grounds patriotism in **economic reality and agrarian identity**, making it a separable thematic layer.  
**Wrong answer reveals:** If a student agrees, they conflate *theme* with *topic*. They don't see that a secondary theme **modulates** the primary theme by adding dimension — here, shifting from *political* patriotism to *cultural-economic* patriotism.

## DIAGNOSTIC_QUESTION_6
Create a 4-line stanza in Hindi (or Hindi-English mix) that introduces a **new secondary theme** relevant to *nsolsuk dk xhr* but not explicitly stated in the poem — e.g., intergenerational trauma, resistance through silence, or the commodification of tradition. Explain your choice in 2 sentences.

## DIAGNOSTIC_ANSWER_6
**Stanza (example):**  
*maañ ki maañ ne bhi sahi thi ye aag*  
*chudiyaan tooti, par awaaz nahi lagi*  
*aj bhi wo raat hai, bas chehra badla hai*  
*parampara ka bojh, ab bhi wahi lagi*  

**Explanation:** This introduces the secondary theme of **intergenerational transmission of patriarchal trauma** — the idea that nsolsuk's silence is not isolated but inherited. It deepens the poem by suggesting the system survives *because* each generation absorbs the weight silently.  
**Poor answer reveals:** If a student writes a generic "sad poem about women" without **thematic intentionality** (naming the theme, linking to the original), they treat creative writing as emotional venting, not as **thematic extension** — a key skill for competitive exams like CUET.

## COMMON_MISCONCEPTION
**Misconception:** *"Secondary themes are just 'other topics' mentioned in the poem — like love, nature, or sadness — and I can list them without connecting to the primary theme."*  
**Why it's wrong:** This reduces thematic analysis to **topic-spotting**. In CBSE and competitive exams, a secondary theme **must** be shown as a *lens* that refracts the primary theme. For example, "love" in *nsolsuk dk xhr* is not a theme by itself; **"love thwarted by social hierarchy"** is a secondary theme because it **mirrors** the nation's love for freedom thwarted by colonial hierarchy. Students lose 2–3 marks per question when they list topics without **analytical linkage**. The error stems from Class 11 habit of "theme = subject" rather than "theme = argument about the subject."

## ON_FAILURE
1. **Revisit Node c12_hin_a_cbse_01_006 (Primary Theme)** — re-read the PEEL examples there; notice how every paragraph ends with a link to nationalism.  
2. **Do a "Theme Mapping" exercise:** Draw two columns — *Primary Theme* (center) and *Secondary Themes* (branches). For each branch, write **one line from the poem** and **one sentence explaining the link**.  
3. **Re-diagnose:** Attempt Diagnostic Question 4 again, but this time **force a comparative link** in every sentence (e.g., "Unlike Poem 1 where nature..., Poem 2 uses nature to...").  
4. **If still stuck:** Watch a 10-min video on "Thematic Layering in Hindi Poetry" (NCERT official channel) and redo the mapping with a peer.

## BUILDS_ON
Primary theme identification (Node c12_hin_a_cbse_01_006) — you cannot analyze secondary themes without a clear anchor.

## LEADS_TO
Literary Devices: Imagery and Metaphor (Node c12_hin_a_cbse_01_008) — secondary themes are often *carried* by imagery; the next node teaches how to decode that vehicle.

## PREREQUISITE_NODE_IDS
c12_hin_a_cbse_01_006, c11_hin_ar_cbse_01_007, c11_hin_ar_cbse_02_007, c11_hin_ar_cbse_03_007, c11_hin_ar_cbse_04_007, c11_hin_ar_cbse_05_007, c11_hin_ar_cbse_06_007, c11_hin_ar_cbse_07_007, c11_hin_ar_cbse_08_007, c11_hin_ar_cbse_09_007, c11_hin_ar_cbse_10_007, c11_hin_ar_cbse_11_007, c11_hin_ar_cbse_12_007, c11_hin_ar_cbse_13_007, c11_hin_ar_cbse_14_007, c11_hin_ar_cbse_15_007, c11_hin_ar_cbse_16_007, c11_hin_v_cbse_01_007, c11_hin_v_cbse_02_007, c11_hin_v_cbse_03_007, c11_hin_v_cbse_04_007, c11_hin_v_cbse_05_007, c12_hin_a_cbse_01_001, c12_hin_a_cbse_01_005

## PREREQUISITE_REASONS
c12_hin_a_cbse_01_006: Primary theme must be established first — secondary themes only make sense in relation to it.  
c11_hin_ar_cbse_01_007: Class 11 Antra Chapter 1 introduced secondary theme analysis; this node deepens it with more complex texts.  
c11_hin_ar_cbse_02_007: Chapter 2 (Class 11) practiced tracking multiple themes across a longer narrative.  
c11_hin_ar_cbse_03_007: Chapter 3 reinforced theme vs. topic distinction.  
c11_hin_ar_cbse_04_007: Chapter 4 linked themes to character arcs.  
c11_hin_ar_cbse_05_007: Chapter 5 added historical context as thematic layer.  
c11_hin_ar_cbse_06_007: Chapter 6 introduced comparative thematics across poems.  
c11_hin_ar_cbse_07_007: Chapter 7 practiced writing theme-based answers.  
c11_hin_ar_cbse_08_007: Chapter 8 connected themes to author's biography.  
c11_hin_ar_cbse_09_007: Chapter 9 explored irony as thematic tool.  
c11_hin_ar_cbse_10_007: Chapter 10 used symbolism to reveal secondary themes.  
c11_hin_ar_cbse_11_007: Chapter 11 integrated vocabulary with thematic nuance.  
c11_hin_ar_cbse_12_007: Chapter 12 applied thematic analysis to comprehension questions.  
c11_hin_ar_cbse_13_007: Chapter 13 developed critical interpretation of themes.  
c11_hin_ar_cbse_14_007: Chapter 14 wrote essays on themes.  
c11_hin_ar_cbse_15_007: Chapter 15 discussed themes in oral presentations.  
c11_hin_ar_cbse_16_007: Chapter 16 synthesized all thematic skills.  
c11_hin_v_cbse_01_007: Vitan Chapter 1 (Class 11) introduced secondary themes in prose.  
c11_hin_v_cbse_02_007: Vitan Chapter 2 contrasted poetic and prosaic thematic treatment.  
c11_hin_v_cbse_03_007: Vitan Chapter 3 added socio-political dimension to themes.  
c11_hin_v_cbse_04_007: Vitan Chapter 4 linked themes to narrative structure.  
c11_hin_v_cbse_05_007: Vitan Chapter 5 consolidated thematic analysis across genres.
c12_hin_a_cbse_01_001: Secondary themes reflect the period's social issues.  
c12_hin_a_cbse_01_005: Secondary themes (gendered suffering, intellectual tradition, oral culture) are carried *specifically* by these two supporting characters — their analysis feeds directly into sub-theme identification.  

## FORWARD_NODE_IDS
c12_hin_a_cbse_01_008, c12_hin_a_cbse_01_009, c12_hin_a_cbse_01_013, c12_hin_a_cbse_01_014
## FORWARD_REASONS
c12_hin_a_cbse_01_008: Imagery and metaphor are the primary vehicles of secondary themes — this node provides the *what*, next node teaches the *how*.  
c12_hin_a_cbse_01_009: Irony and symbolism often *encode* secondary themes (e.g., sindoor as ironic symbol).  
c12_hin_a_cbse_01_013: Critical thinking requires evaluating how secondary themes shift interpretation.  
c12_hin_a_cbse_01_014: Writing skills need thematic depth to produce high-scoring answers.

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
c11_his_cbse_08_001: History Chapter 8 (Nationalism in India) provides the **historical backdrop** for the patriotic primary theme and the social-reform secondary themes.  
c11_his_cbse_08_002: History Chapter 8 also covers **women's participation in nationalist movements**, directly illuminating the gender-oppression theme in *nsolsuk dk xhr*.  
c11_civ_cbse_05_001: Civics Chapter 5 (Gender, Religion, Caste) gives the **conceptual framework** for analyzing patriarchy as a secondary theme.  
c11_civ_cbse_05_002: Same chapter explains **intersectionality** — how colonial and patriarchal power structures overlap, which is the core thematic tension in both poems.

## CHAIN_DESCRIPTION
c12_hin_a_cbse_01_006 -> c12_hin_a_cbse_01_007 -> c12_hin_a_cbse_01_008

## THIS_FORMULA
N/A - conceptual

## FORMULA_VARIABLES
N/A

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
analytical

## CROSS_SUBJECT
N/A | The secondary theme of sacrifice in *dkusZfy;k dk xhr* mirrors the historical reality of peasant and worker participation in the freedom struggle — connecting literary representation to historical agency.  
 N/A | The secondary theme of ritualized gender violence in *nsolsuk dk xhr* aligns with Civics concepts of patriarchal structures and legal reform — enabling interdisciplinary analysis of literature as social document.
## PREREQ_CONCEPT
Primary theme as organizing center — secondary themes only function when anchored to a clear primary theme.

## PREREQ_BEFORE
Student must be able to state the primary theme of Chapter 1 in one sentence and give two textual evidences for it.

## PREREQ_STUCK
If stuck, review the PEEL paragraphs in Node c12_hin_a_cbse_01_006 and practice writing one PEEL for a secondary theme using the same structure.

## WORKED_EXAMPLE_1
PROBLEM: Analyze how the secondary theme of **"nature as witness to injustice"** operates in *nsolsuk dk xhr* and write a PEEL paragraph for it.  
STEPS:
- Step 1: Identify the primary theme (patriotism/national awakening) from Node 006 — this is the anchor.
- Step 2: Scan the poem for nature images: *raat* (night), *chandni* (moonlight), *jhanjhar* (anklet sound in wind), *chudiyaan* (bangles), *hawa* (wind). Note they appear in moments of the speaker's isolation.
- Step 3: Determine the pattern — nature does not comfort; it **observes silently** (e.g., *"izy; py jgk vius iFk ij"* — love walks on its own path, implying nature's indifference). This creates a secondary theme: **nature as silent witness to human suffering**.
- Step 4: Explain the thematic function — this mirrors the nation's suffering under colonialism: the land watches, endures, records. The personal and political share the same witness.
- Step 5: Write PEEL: Point → Evidence (*"izy; py jgk vius iFk ij"*) → Explanation (nature's detachment = society's complicity) → Link (just as the nation's pain is witnessed by history, her pain is witnessed by nature — both demand voice).  
REASONING: This 5-step process moves from **anchor → evidence → pattern → interpretation → structured articulation** — the exact cognitive chain exam questions test.  
ANSWER: **PEEL Paragraph:** The poem positions nature as a silent witness to the speaker's injustice, deepening the primary theme of national awakening. In the line *"izy; py jgk vius iFk ij"* (love walks gently on its own path), the night and wind observe her anguish without intervention, just as the Indian landscape witnessed colonial exploitation without immediate redress. This personification of nature as a passive observer critiques societal complicity — both the family that forces marriage and the empire that denies freedom rely on silence. Thus, the secondary theme of **nature as witness** transforms the personal lament into a metaphor for collective historical testimony, reinforcing that awakening begins when the witnessed finds a voice.

## WORKED_EXAMPLE_2
PROBLEM: Compare the secondary theme of **"cultural pride"** in *dkusZfy;k dk xhr* with the secondary theme of **"cultural entrapment"** in *nsolsuk dk xhr*. Write a 100-word comparative analysis.  
STEPS:
- Step 1: Define each theme in one phrase: Poem 1 = cultural entrapment (tradition as cage); Poem 2 = cultural pride (tradition as strength).
- Step 2: Locate evidence in Poem 1: *"ykSVk yks ;g viuh Fkkrh / esjh djQ.kk gk&gk [kkrh"* (vermilion as burning flesh) — tradition harms.
- Step 3: Locate evidence in Poem 2: *"gse oqaQHk ys m"kk losjs / Hkjrh <qydkrh lq[k esjs"* (green fields, golden harvest) — tradition nurtures.
- Step 4: Analyze the contrast — same culture (Hindu symbols: sindoor, fields, harvest) but **different relationship to the speaker**: imposed vs. inherited, violent vs. life-giving.
- Step 5: Synthesize — the chapter uses this dichotomy to argue that **culture must be reclaimed, not rejected**: nsolsuk's pain shows what happens when culture is weaponized by patriarchy; dkusZfy;k shows what happens when culture is owned by the people.  
REASONING: Comparative thematic analysis is a favorite in CBSE 5-mark questions and CUET case-based passages. The 5 steps enforce **balanced treatment**, **textual grounding**, and **synthesis** — not just listing.  
ANSWER: While *nsolsuk dk xhr* portrays culture as entrapment — the sindoor that *"gk&gk [kkrh"* (eats like fire) symbolizes patriarchal tradition weaponized against women — *dkusZfy;k dk xhr* reclaims culture as pride: the *"gse oqaQHk"* (green fields) and *"Hkjrh <qydkrh"* (smiling harvest) represent a living heritage that sustains the nation. The same symbols (vermilion/fields, ritual/land) serve opposite thematic functions because the **agency differs**: in Poem 1, culture is imposed from outside; in Poem 2, it arises from the people's labor. This contrast is the chapter's core argument: true nationalism requires liberating culture from oppressive structures so it becomes a source of collective strength — making "cultural redefinition" the bridge between the two secondary themes.

## WORKED_EXAMPLE_3
PROBLEM: A board exam question asks: *"The two poems in Chapter 1 present two faces of Indian tradition. Discuss with reference to secondary themes."* Write a 150-word structured answer integrating at least three secondary themes.  
STEPS:
- Step 1: Deconstruct the prompt — "two faces" = contrast; "secondary themes" = need 3+ named themes with evidence.
- Step 2: Select three secondary themes that appear in **both** poems but differently: (a) Tradition, (b) Womanhood/Motherhood, (c) Land/Soil.
- Step 3: For each theme, create a mini PEEL (Point + Evidence from each poem + Link).
- Step 4: Draft the answer in 4 paragraphs: Intro (thesis: tradition is dual), Theme 1, Theme 2, Theme 3, Conclusion (synthesis).
- Step 5: Check word count, ensure each paragraph has **explicit comparative language** (whereas, conversely, in contrast).
- Step 6: Verify all 3 themes are **named**, **evidenced**, and **linked to primary theme**.  
REASONING: This 6-step process mirrors the **exam writing protocol**: unpack → select → structure → draft → refine → verify. It prevents the common error of writing a summary instead of an argument.  
ANSWER: The two poems reveal tradition's dual face: as **cage** and as **cradle**. First, **tradition as gendered cage** (*nsolsuk*: *"ykSVk... gk&gk [kkrh"*) vs. **tradition as agrarian cradle** (*dkusZfy;k*: *"gse oqaQHk... Hkjrh <qydkrh"*) — the same cultural symbols (vermilion, harvest) become tools of oppression or sources of dignity depending on who controls them. Second, **womanhood as silenced victim** (*nsolsuk*: *"eSaus Hkzeo'k thou lafpr"*) vs. **motherland as empowered Shakti** (*dkusZfy;k*: *"vjQ.k ;g eèkqe; ns'k gekjk"*) — the female body shifts from site of suffering to symbol of sovereignty. Third, **soil as witness to private grief** (*nsolsuk*: night wind) vs. **soil as generator of collective wealth** (*dkusZfy;k*: *"txdj jtuh Hkj rkjk"*) — the land absorbs tears in one, yields gold in the other. Together, these secondary themes argue that nationalism must **transform tradition from the first face to the second** — making the personal political, and the political personal.

## COMPETENCY_QUESTION_1
QUESTION: In *nsolsuk dk xhr*, the speaker addresses the *fo'o* (world) in the line *"fo'o! u l¡Hkysxh ;g eq>ls / bls eu dh ykt x¡okbZA"*. Identify the secondary theme this apostrophe reveals, and explain how it **complicates** the primary theme of patriotism. Use one additional line from the poem as evidence.  
COMPETENCY: Textual Analysis & Thematic Synthesis  
STEPS:
- Step 1: Identify the figure of speech (apostrophe — addressing an absent entity).
- Step 2: Name the secondary theme: **appeal to universal justice / moral witness**.
- Step 3: Explain the complication — the speaker bypasses national leaders, gods, or husband to address *the world*, implying her injustice is a **human rights violation**, not just a domestic or national issue.
- Step 4: Cite second line: *"eSaus fut nqcZy in&cy ij / mlls gkjh&gksM+ yxkbZ"* — she frames her pain as a **global testimony**, not a private grief.
- Step 5: Conclude: This secondary theme expands patriotism from *political independence* to *human dignity* — the nation cannot be free if its women appeal to the world for justice.  
ANSWER: The apostrophe to *fo'o* (world) reveals the secondary theme of **universal moral accountability**. By demanding the world not laugh but *feel* her pain (*"eu dh ykt x¡okbZA"*), nsolsuk positions her suffering as a **crime against humanity**, not merely a family tragedy. This complicates patriotism: if the nation's daughters must appeal to the *world* for justice, the nation has already failed its own. The line *"eSaus fut nqcZy in&cy ij / mlls gkjh&gksM+ yxkbZ"* (I have placed burning coals on my tender heart) transforms her body into evidence in a global court. Thus, the secondary theme **raises the stakes** of nationalism — freedom must include gender justice, or it is incomplete.  
DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: A CUET-style case-based question provides a 4-line excerpt from *dkusZfy;k dk xhr* (not the full poem) and asks: *"The poet uses agrarian imagery to construct a secondary theme of 'productive patriotism.' Analyze this claim with reference to the given lines and your knowledge of the poem."* The excerpt:  
*"gse oqaQHk ys m"kk losjs / Hkjrh <qydkrh lq[k esjs / efnj m¡Q?krs jgrs tc / txdj jtuh Hkj rkjk"*  
Write a 120-word response that: (a) defines 'productive patriotism' in this context, (b) analyzes two images from the excerpt, (c) links to the primary theme, and (d) contrasts with *nsolsuk dk xhr*.  
COMPETENCY: Case-Based Reasoning & Intertextual Comparison  
STEPS:
- Step 1: Define 'productive patriotism' — patriotism expressed through **labor, fertility, and sustenance**, not just sacrifice or rhetoric.
- Step 2: Analyze image 1: *"gse oqaQHk ys m"kk losjs"* — green fields waving heads = **living, growing nationhood**, not static symbolism.
- Step 3: Analyze image 2: *"txdj jtuh Hkj rkjk"* — plough turning soil, sweat becoming gold = **labor as alchemy**, transforming earth into value.
- Step 4: Link to primary theme: this makes patriotism **daily practice**, not occasional heroism — the farmer *is* the freedom fighter.
- Step 5: Contrast with *nsolsuk*: there, the body is *consumed* by tradition (*"djQ.kk gk&gk [kkrh"*); here, the body *produces* through tradition. One is **extraction**, the other **generation**.
- Step 6: Synthesize in 120 words with clear structure.  
ANSWER: 'Productive patriotism' redefines love for the nation as **creative labor on the land** rather than abstract sentiment or martial sacrifice. The image *"gse oqaQHk ys m"kk losjs"* (green fields waving heads) portrays the nation as a **living organism** — patriotism is cultivation, not conquest. *"txdj jtuh Hkj rkjk"* (plough turns soil, sweat becomes gold) elevates the peasant's toil to **alchemy**: the body's expenditure *produces* the nation's wealth. This grounds the primary theme (national awakening) in **material practice** — the farmer *is* the patriot. In stark contrast, *nsolsuk dk xhr* shows a female body **consumed** by ritual: *"ykSVk... djQ.kk gk&gk [kkrh"* (vermilion eats flesh like fire). There, tradition extracts; here, tradition generates. The chapter thus argues: true nationalism must shift society from **extraction of the vulnerable** to **production by the empowered** — making 'productive patriotism' the thematic bridge between the two poems.  
DIFFICULTY: hard