## DEFINITION
Speaking and Listening: Discussion Points refers to the structured oral communication skill where students articulate evidence-based interpretations of a literary text, actively listen to peer perspectives, and collaboratively build analytical insights through disciplined dialogue grounded in textual evidence.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student must independently initiate a literary discussion by posing an interpretive question anchored in a specific stanza, sustain the dialogue by integrating at least two peer contributions with textual evidence, and conclude by synthesizing a nuanced thematic insight that acknowledges complexity or ambiguity in the poem.

## SCOPE_BOUNDARY
This node covers structured discussion techniques for the poem "Ghar ki Yaad" — including formulating interpretive questions, using textual evidence from specific stanzas, analyzing literary devices in conversation, and synthesizing thematic insights. It does NOT cover formal debate formats, presentation skills, or creative writing based on the poem.

## WALKTHROUGH
Imagine you are sitting in a circle with classmates after reading "Ghar ki Yaad" — the poem where the poet remembers his childhood home, his father's strictness, and the smell of his mother's cooking. You want to say something meaningful but don't know where to begin. Start by picking ONE striking image — perhaps the repeated line "bahut ikuh phij jag gaya" — and ask: "Why does the poet repeat this refrain exactly twelve times?" Then listen as a peer connects it to the twelve stanzas, another links it to the cyclical nature of memory. You build on that: "The repetition mimics how memory loops — not linear but circular." That is the key insight: discussion is not sharing opinions; it is collaborative close reading where each voice adds a layer of textual evidence.

## DIAGNOSTIC_QUESTION_1
What is the primary purpose of a literary discussion based on a poem like "Ghar ki Yaad" in a Class 11 assessment context?

## DIAGNOSTIC_ANSWER_1
The primary purpose is to demonstrate analytical thinking by collaboratively exploring the poem's themes, devices, and ambiguities through evidence-based reasoning — not to express personal feelings or summarize the plot. A wrong answer such as "to share what we liked about the poem" reveals the student confuses literary discussion with personal response; they have not grasped that assessment focuses on textual analysis, not preference.

## DIAGNOSTIC_QUESTION_2
A student says: "The poem is about missing home. Everyone misses home, so it's relatable." Why is this an inadequate contribution to a senior secondary literary discussion?

## DIAGNOSTIC_ANSWER_2
This contribution stays at the level of universal theme without textual anchoring — it offers no stanza reference, no analysis of how the poet constructs nostalgia through specific devices (refrain, imagery, dialogue), and no engagement with complexity (e.g., the father's harshness vs. the mother's warmth). A student giving this answer misunderstands that "relatability" is not analysis; they need to learn that every claim must be tethered to a specific textual moment.

## DIAGNOSTIC_QUESTION_3
During a discussion on stanza 7 ("ikpok¡ eSa gw¡ vHkkxk..."), one student claims the speaker is arrogant. Another cites "firk th us dgk gksxk / gk;] fdruk lgk gksxk" to argue the father's voice dominates. How should a third student synthesize these views using textual evidence?

## DIAGNOSTIC_ANSWER_3
The synthesis: "The speaker's assertion 'eSa e"ks esa gw¡ lgh gS' (stanza 10) appears arrogant, but stanza 7 shows he anticipates his father's voice ('firk th dgrs jgs gSa / I;kj esa cgrs jgs gSa') — the poem structures their voices in dialogue, not monologue. The arrogance is performative; the father's lingering presence undermines it." A student who cannot trace this interplay across stanzas fails to see the poem as a dramatic conversation, not a solo confession.

## DIAGNOSTIC_QUESTION_4
Compare the function of the refrain "bahut ikuh phij jag gaya" in stanzas 1, 6, and 12. What does its shifting context reveal about the speaker's emotional arc?

## DIAGNOSTIC_ANSWER_4
In stanza 1, the refrain establishes physical distance ("vkt ikuh phij jag gS"). In stanza 6, it frames the father's anticipated return ("tc fd uhps vk, gksaxs"). In stanza 12, it becomes an internal state ("dg u nsuk tkxrk gw¡ / vkneh ls Hkkxrk gw¡") — the external journey has become psychological entrapment. A student who treats the refrain as mere repetition misses its structural role in mapping the speaker's movement from spatial separation to existential imprisonment.

## DIAGNOSTIC_QUESTION_5
Evaluate this interpretive claim: "The mother in 'Ghar ki Yaad' is a passive symbol of nurture; the father represents authority. The poem reinforces gender stereotypes." Defend or challenge using at least two textual details.

## DIAGNOSTIC_ANSWER_5
Challenge: The mother's presence ("ek¡ us dgk gksxk / nq[k fdruk cgk gksxk") carries prophetic weight — she measures the son's suffering, not just comforts. The father's authority is undercut by his predicted frailty ("jks iM+s gksaxs cjkcj / ik¡posa dk uke ysdj") — he will need care, reversing roles. The poem complicates stereotypes by showing both parents as mortal, voiced, and mutually dependent. A student who accepts the stereotype reading has not examined how the poem subverts its own archetypes through temporal reversal.

## DIAGNOSTIC_QUESTION_6
Design a discussion prompt for peers that would generate a 10-minute evidence-based conversation on the poem's treatment of time. The prompt must reference a specific stanza and avoid yes/no phrasing.

## DIAGNOSTIC_ANSWER_6
Strong prompt: "In stanza 11, the speaker says 'gs lthys gjs lkou / gs fd esjs iq.; ikou' — how does this collapse of past, present, and future tense reshape our reading of the earlier stanzas where memory feels like a fixed place? Use at least two other stanzas to trace how the poem's time sense shifts." A weak prompt ("Did you like the ending?") reveals the student cannot distinguish discussion triggers from opinion polls; they need practice crafting analytical entry points.

## COMMON_MISCONCEPTION
Students believe a good literary discussion means "everyone shares their interpretation and we respect all views." In senior secondary assessment, this leads to superficial pooling of unsubstantiated opinions. The actual requirement is argumentative rigor: each claim must be challenged, qualified, or extended using specific textual evidence (stanza, line, device). Students default to "relatability" because it feels safe; they avoid close reading because it demands technical vocabulary (refrain, enjambment, dramatic monologue) they haven't practiced deploying in speech.

## ON_FAILURE
1. Give the student a single stanza (e.g., stanza 4) and ask them to write three discussion questions that cannot be answered without quoting the text. 2. Model a 2-minute "think-aloud" where you take a peer's vague comment ("It's sad") and transform it into an analytical move: "You say it's sad — which image creates that sadness? The 'cfgu vkbZ cki osQ ?kj' in stanza 3? Why a 'blind well'?" 3. Have them practice the "Evidence → Inference → Question" loop in pairs for 10 minutes daily until they spontaneously cite stanzas.

## BUILDS_ON
c11_hin_ar_cbse_11_013: Critical Thinking: Analysis and Interpretation — students must already be able to identify themes, devices, and textual evidence in writing before transferring those skills to real-time oral discourse.

## LEADS_TO
c11_hin_ar_cbse_11_014: Writing Skills: Based on the Chapter — discussion insights become the raw material for structured analytical writing; the oral-to-written pipeline is the core pedagogical sequence.

## PREREQUISITE_NODE_IDS
c11_hin_ar_cbse_11_001, c11_hin_ar_cbse_11_002, c11_hin_ar_cbse_11_006, c11_hin_ar_cbse_11_008, c11_hin_ar_cbse_11_009, c11_hin_ar_cbse_11_013, c11_hin_ar_cbse_11_012

## PREREQUISITE_REASONS
c11_hin_ar_cbse_11_001: Context and background knowledge (Bachchan's life, Chhayavaad movement) frames why "home" carries nationalist and personal resonance.
c11_hin_ar_cbse_11_002: Plot and narrative structure — the poem's 12-stanza architecture mirrors the cyclic refrain; students must grasp this macro-structure to discuss micro-shifts.
c11_hin_ar_cbse_11_006: Primary theme (nostalgia as psychological imprisonment) gives the discussion its conceptual anchor.
c11_hin_ar_cbse_11_008: Imagery and metaphor analysis — students need the vocabulary to name "blind well," "father's voice as shadow" in conversation.
c11_hin_ar_cbse_11_009: Irony and symbolism — the father's predicted role-reversal is ironic; the house as living entity is symbolic; discussion demands these labels.
c11_hin_ar_cbse_11_013: Critical thinking skills (inference, synthesis, evaluation) are the cognitive engine of evidence-based dialogue.
c11_hin_ar_cbse_11_012: Speaking/listening discussions use literal facts as shared ground and inferences as debate points.  

## FORWARD_NODE_IDS
c12_hin_a_cbse_11_015, c12_hin_a_cbse_12_015, c12_hin_al_cbse_02_015, c12_hin_al_cbse_03_015, c12_hin_ar_cbse_11_015, c12_hin_ar_cbse_12_015

## FORWARD_REASONS
c12_hin_a_cbse_11_015: Class 11 speaking/listening experience establishes baseline oral fluency.  
c12_hin_a_cbse_12_015: अगला तार्किक चरण: Speaking and Listening: इस नोड की अवधारणाओं को सीधे उपयोग/विस्तारित करता है।  
c12_hin_al_cbse_02_015: Reinforces academic language for literary discussion.  
c12_hin_al_cbse_03_015: Time management in spoken tasks  
c12_hin_ar_cbse_11_015: Class 11 established baseline speaking/listening protocols (turn-taking, eye contact, Hindi fluency) this node advances.  
c12_hin_ar_cbse_12_015: अगला तार्किक चरण: Speaking and Listening: इस नोड की अवधारणाओं को सीधे उपयोग/विस्तारित करता है।  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
none

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_11_013 -> c11_hin_ar_cbse_11_015 -> c11_hin_ar_cbse_11_014

## THIS_FORMULA
Discussion Move = Textual Anchor (stanza/line) + Analytical Label (device/theme/structure) + Interpretive Claim + Invitation for Peer Extension

## FORMULA_VARIABLES
Textual Anchor: Specific stanza number and quoted phrase; Analytical Label: Technical term (refrain, enjambment, dramatic irony, etc.); Interpretive Claim: Argutable insight about meaning/effect; Invitation for Peer Extension: Open-ended follow-up question

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
linguistic

## CROSS_SUBJECT
c11_history_nationalism | The poem's "home" operates as a metonym for the colonized self reclaiming cultural memory — discussion can link Bachchan's Chhayavaad lyricism to anti-colonial cultural nationalism.
c11_psychology_memory | The refrain's repetition mirrors involuntary autobiographical memory loops (Proustian "madeleine" effect); students can discuss how poetic form enacts cognitive science of nostalgia.

## PREREQ_CONCEPT
Students must be able to independently identify and name at least three literary devices in "Ghar ki Yaad" (refrain, imagery, dramatic dialogue) and explain their thematic function in writing.

## PREREQ_BEFORE
The student can write a 150-word analysis of any stanza using the PEEL structure (Point, Evidence, Explanation, Link) without teacher scaffolding.

## PREREQ_STUCK
Return to c11_hin_ar_cbse_11_008 and c11_hin_ar_cbse_11_009 — practice device identification and thematic linking in written paragraphs before attempting oral deployment.

## WORKED_EXAMPLE_1
PROBLEM: A discussion group falls silent after one student says "The poem is about missing home." Restart the dialogue using the Discussion Move formula.

STEPS:
- Step 1: Identify the gap — the claim has no textual anchor, no analytical label, and closes conversation instead of opening it.
- Step 2: Apply the formula — choose Stanza 3 ("?kj fd ?kj esa pkj HkkbZ / pkj HkkbZ I;kj cfgusa") as Textual Anchor.
- Step 3: Attach Analytical Label — "This stanza uses domestic enumeration (listing four brothers, four sisters) as a structural metaphor for wholeness."
- Step 4: Formulate Interpretive Claim — "The precision of numbers (four/four) contrasts with the later fragmentation — the 'whole' home exists only in memory's grid."
- Step 5: Craft Invitation for Peer Extension — "How does this numerical completeness in stanza 3 set up the breakdown we see in stanza 8 where the father cannot recognize his own children?"
REASONING: The formula forces every contribution to be evidentiarily grounded, technically precise, interpretively bold, and dialogically open — the four pillars of assessed literary discussion.
ANSWER: "Look at stanza 3 — the poet counts 'pkj HkkbZ pkj cfgusa' like a census. That numerical completeness is a metaphor for the intact family unit. But by stanza 8, the father asks 'ik¡posa dk uke ysdj' — he needs his children to name themselves. The grid collapses. Who wants to trace where else numbers or naming appear?"

## WORKED_EXAMPLE_2
PROBLEM: Two students debate whether the speaker is unreliable. Student A: "He says 'eSa e"ks esa gw¡ lgh gS' — he admits self-deception." Student B: "But the father's voice confirms his guilt." Mediate using evidence.

STEPS:
- Step 1: Map the conflict — Student A reads stanza 10 as confession; Student B reads stanza 7 as corroboration.
- Step 2: Demand textual precision — ask each to quote the exact lines supporting their stance.
- Step 3: Introduce Analytical Label — "This is dramatic irony: the speaker's self-justification ('?kj ugha gw¡ cl ;gh gS') is framed by the father's predicted judgment ('firk th us dgk gksxk / gk;] fdruk lgk gksxk')."
- Step 4: Synthesize — "The poem doesn't resolve reliability; it stages a trial where both voices are partial. The refrain 'bahut ikuh phij jag gaya' becomes the courtroom gavel — recurring, final, unanswerable."
- Step 5: Extend — "Where else does the poem use legal/trial language? 'dkSu gw¡ eSa' (stanza 12), 'dg u nsuk ekSu gw¡ eSa' — the speaker puts himself on the stand."
REASONING: Mediation models how discussion moves from binary disagreement to structural analysis by naming the device (dramatic irony) that contains both perspectives.
ANSWER: "You're both right because the poem is a trial, not a testimony. Stanza 10: 'eSa e"ks esa gw¡ lgh gS / ?kj ugha gw¡ cl ;gh gS' — the defendant's plea. Stanza 7: 'firk th dgrs jgs gSa / I;kj esa cgrs jgs gSa' — the prosecution's witness. The refrain is the gavel. The poem never delivers a verdict. That's why it haunts us. Who can find another 'courtroom' metaphor?"

## WORKED_EXAMPLE_3
PROBLEM: Design a 15-minute whole-class discussion plan on "Time and Memory in 'Ghar ki Yaad'" that ensures every student speaks at least once and uses the Discussion Move formula.

STEPS:
- Step 1: Pre-discussion prep (2 min) — distribute a one-page stanza map with device labels (refrain, enjambment, apostrophe, etc.) for reference.
- Step 2: Opening prompt (1 min) — "Stanza 11 collapses tenses: 'gs lthys gjs lkou / gs fd esjs iq.; ikou'. How does this temporal collapse rewrite the 'fixed past' of stanzas 1-5? Use the Discussion Move formula."
- Step 3: First round — cold-call three students to each make one Discussion Move (anchor + label + claim + invitation).
- Step 4: Peer extension round (5 min) — each initial speaker chooses a peer to extend their move; teacher tracks participation on roster.
- Step 5: Synthesis round (3 min) — two volunteers summarize the emerging insight using at least two peers' contributions by name.
- Step 6: Metacognitive close (2 min) — "What discussion habit did we practice today that you'll use in the board exam oral?" (Answer: Evidence → Label → Claim → Invite).
REASONING: The plan structures discussion as a teachable, assessable skill — not free talk. The stanza map scaffolds vocabulary; the formula ensures rigor; cold-calling + peer extension guarantees equity; metacognitive close transfers skill to exam context.
ANSWER: A timed, scaffolded, formula-driven discussion plan with participation accountability and explicit skill-transfer reflection — ready for classroom implementation.

## COMPETENCY_QUESTION_1
QUESTION: In a discussion on "Ghar ki Yaad," a peer argues: "The poem is sentimental — it just romanticizes the past." Using the Discussion Move formula, construct a response that acknowledges their reading, complicates it with textual evidence from two stanzas, and invites further analysis.

COMPETENCY: Evidence-based argumentation in literary dialogue

STEPS:
- Step 1: Acknowledge the peer's reading as a valid entry point ("Sentimentality is one lens — the poem does invite nostalgia").
- Step 2: Introduce a complicating device from Stanza 8 ("But stanza 8 undercuts romance with grotesquerie: 'jks iM+s gksaxs cjkcj / ik¡posa dk uke ysdj' — the father's body fails, he needs his children to name themselves").
- Step 3: Add a second stanza — Stanza 12 ("And stanza 12 refuses closure: 'dg u nsuk tkxrk gw¡ / vkneh ls Hkkxrk gw¡' — memory becomes torture, not comfort").
- Step 4: Label the shift — "The poem moves from sentiment to trauma through ironic reversal and psychological entrapment."
- Step 5: Invite extension — "Where else does the poem punish the speaker for his nostalgia? Who can trace the 'punishment' motif?"
ANSWER: "Sentimentality is one lens — the poem does invite nostalgia. But stanza 8 undercuts romance with grotesquerie: 'jks iM+s gksaxs cjkcj / ik¡posa dk uke ysdj' — the father's body fails, he needs his children to name themselves. And stanza 12 refuses closure: 'dg u nsuk tkxrk gw¡ / vkneh ls Hkkxrk gw¡' — memory becomes torture, not comfort. The poem moves from sentiment to trauma through ironic reversal and psychological entrapment. Where else does the poem punish the speaker for his nostalgia? Who can trace the 'punishment' motif?"
DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: You are leading a discussion on the poem's structure. A student claims: "The 12 stanzas are just repetition — nothing changes." Design a 4-move discussion sequence that guides the group to discover the poem's structural progression from spatial memory to existential crisis, using only textual evidence.

COMPETENCY: Facilitating analytical discovery through structured questioning

STEPS:
- Step 1: Validate then pivot — "Repetition is the surface pattern. Let's test if the *content* of repetition shifts. Compare the refrain's context in Stanza 1 vs Stanza 12."
- Step 2: Evidence hunt — "Stanza 1: 'vkt ikuh phij jag gS' — physical distance. Stanza 12: 'dg u nsuk tkxrk gw¡ / vkneh ls Hkkxrk gw¡' — psychological imprisonment. What changed?"
- Step 3: Map the arc — "Trace the middle stanzas: 3 (domestic census), 6 (father's return), 8 (role reversal), 10 (self-justification). Each stanza adds a layer to the 'journey.'"
- Step 4: Synthesis challenge — "So the 12 stanzas aren't circular — they're a descent. The refrain is the heartbeat of a man sinking deeper. Who can argue the opposite — that it *is* circular — using Stanza 11's 'gs lthys gjs lkou'?"
ANSWER: A facilitation sequence that: (1) accepts the student's observation as a hypothesis, (2) designs a comparative evidence task, (3) guides structural mapping, (4) invites counter-argument — modeling how teachers scaffold discovery without lecturing.
DIFFICULTY: hard