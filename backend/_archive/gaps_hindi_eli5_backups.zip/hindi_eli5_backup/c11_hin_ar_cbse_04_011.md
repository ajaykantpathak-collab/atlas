## DEFINITION
Grammar: Language Usage in the Text refers to the analysis of specific grammatical structures, vocabulary choices, sentence patterns, and stylistic features employed in the chapter to convey tone, theme, and character perspectives, including the interplay between Sanskritized Hindi, Perso-Arabic vocabulary, and colonial English influences.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student can identify and explain at least three distinct grammatical or lexical features in the text (e.g., use of passive voice for irony, honorifics for power dynamics, code-mixing for satire) and demonstrate how each contributes to the author's critique of colonial education.

## SCOPE_BOUNDARY
This node covers grammatical and lexical analysis of the chapter "फोनिब्ज-लाHkk"k.k" (from the textbook), including sentence structure, vocabulary registers, and stylistic devices. It does not cover general Hindi grammar rules unrelated to the text, nor does it include comprehensive literary analysis of themes or characters (covered in sibling nodes).

## WALKTHROUGH
Imagine you are reading a text where an Indian narrator sarcastically addresses an Englishman as "एब यकडबल्यूएमज़ेड" (Mr. Englishman) and uses phrases like "फोनिब्ज-लाHkk"k.k" – you might wonder why the author mixes English sounds into Hindi words. Start by reading a short passage aloud, noticing which words feel formal, which sound like English transliterations, and where the sentence structure feels unusually complex. Mark sentences that use passive voice (e.g., "यह कार्य किया गया") and ask: who is hiding the doer? Then compare the Hindi used by the narrator (high Sanskritized) with the Englishman's supposed speech. The key insight: the author manipulates grammar and vocabulary to expose colonial arrogance and Indian complicity.

## DIAGNOSTIC_QUESTION_1
What is the meaning of the word "इक्ज़िट" (exit) as used in the context of the chapter's language exercise, and from which language is it borrowed?

## DIAGNOSTIC_ANSWER_1
The word "इक्ज़िट" means "निकास" or "बाहर जाने का रास्ता" and is borrowed from English. A wrong answer (e.g., saying it's a Sanskrit word) reveals the student cannot identify loanwords and their source languages, a key skill for analyzing the text's linguistic hybridity.

## DIAGNOSTIC_QUESTION_2
In the sentence "वकीलों ने न्यायालय में बहस की" (Lawyers argued in court), the textbook asks to convert it to "सामान्य हिंदी". What does this conversion typically involve, and why is it asked in this chapter?

## DIAGNOSTIC_ANSWER_2
Conversion to "सामान्य हिंदी" involves replacing Perso-Arabic vocabulary (e.g., वकील, न्यायालय, बहस) with Sanskrit-derived equivalents (e.g., वकील -> अधिवक्ता, न्यायालय -> अदालत, बहस -> वाद-विवाद). The chapter asks this to highlight the linguistic hierarchy imposed by colonial education that privileged certain registers. A wrong answer (e.g., just simplifying grammar) shows the student misses the sociolinguistic critique embedded in the exercise.

## DIAGNOSTIC_QUESTION_3
Apply the concept of "passive voice as evasion of agency" to the sentence "ब्लैक बोर्ड पर लिखवाया गया" (Was made to write on the blackboard). Who is the hidden agent, and what does this reveal about the classroom power dynamic?

## DIAGNOSTIC_ANSWER_3
The hidden agent is the teacher (or colonial authority) who forces the student to write. The passive construction hides the coercive power, making the action appear automatic. A student who only identifies the grammatical form without linking to power dynamics fails to apply the concept to the text's critique of colonial pedagogy.

## DIAGNOSTIC_QUESTION_4
Compare the use of honorifics in the narrator's address to the Englishman ("एब यकडबल्यूएमज़ेड", "महोदय") with the Englishman's imagined address to Indians. What does this asymmetry reveal about the colonial relationship?

## DIAGNOSTIC_ANSWER_4
The narrator uses exaggerated honorifics (महोदय, श्रीमान) while the Englishman is portrayed as using demeaning terms (निगर, काले). This asymmetry satirizes the Indian's internalized inferiority and the Englishman's blatant racism. A wrong answer that treats both as equal politeness misses the irony and the author's intent.

## DIAGNOSTIC_QUESTION_5
Evaluate the effectiveness of the author's use of code-mixing (e.g., "फोनिब्ज-लाHkk"k.k", "एब यकडबल्यूएमज़ेड") as a satirical device. Does it enhance or obscure the critique?

## DIAGNOSTIC_ANSWER_5
It enhances the critique by mimicking the absurdity of Anglicized pronunciation forced upon Indians, making the reader hear the colonial distortion. However, overuse could alienate readers unfamiliar with English phonetics. A student who says it's merely decorative fails to evaluate the device's rhetorical function.

## DIAGNOSTIC_QUESTION_6
Create a short satirical paragraph (4-5 sentences) in Hindi that uses at least two English loanwords transliterated in Devanagari, one passive construction hiding agency, and exaggerated honorifics to mock a contemporary authority figure (e.g., a bureaucrat, a tech CEO).

## DIAGNOSTIC_ANSWER_6
A good answer will demonstrate conscious use of the three features for satire. Example: "श्रीमान सीईओ महोदय, आपके 'ऐप' ने हमारी 'प्राइवेसी' चुरा ली है, ऐसा कहा जाता है। डेटा बेचा गया, मुनाफा कमाया गया, पर हमसे पूछा तक नहीं गया।" A poor answer uses the features mechanically without satirical intent, showing lack of creative synthesis.

## COMMON_MISCONCEPTION
Students often think "language usage" only means identifying parts of speech (noun, verb) or correcting grammar errors. In this chapter, it actually means analyzing how the author deliberately chooses specific registers (Sanskritized vs. Perso-Arabic vs. English), sentence structures (passive vs. active), and address forms to build a political argument. They miss that grammar here is a tool of satire, not just rules.

## ON_FAILURE
If a student cannot move beyond parts-of-speech identification, guide them through a single sentence from the text: "वकीलों ने न्यायालय में बहस की". Step 1: List each word's language origin (वकील - Arabic, न्यायालय - Sanskrit, बहस - Persian). Step 2: Ask why the author might choose this mix in a colonial court scene. Step 3: Convert to Sanskritized Hindi and discuss the shift in tone. Step 4: Connect to the chapter's theme of linguistic imposition. Repeat with two more sentences until they see grammar as a carrier of ideology.

## BUILDS_ON
Vocabulary in Context: Key Words (c11_hin_ar_cbse_04_010) where students learned to identify word meanings and origins.

## LEADS_TO
Comprehension: Literal and Inferential Questions (c11_hin_ar_cbse_04_012) where grammatical insights support deeper textual inference.

## PREREQUISITE_NODE_IDS
c11_hin_ar_cbse_04_010, c11_hin_ar_cbse_04_008, c11_hin_ar_cbse_04_009, c11_hin_ar_cbse_04_001, c11_hin_ar_cbse_04_007

## PREREQUISITE_REASONS
c11_hin_ar_cbse_04_010: Provides vocabulary foundation (word origins, meanings) needed to analyze register mixing.
c11_hin_ar_cbse_04_008: Imagery and metaphor analysis prepares students to see language as a stylistic tool.
c11_hin_ar_cbse_04_009: Irony and symbolism recognition is essential for detecting satirical grammar.
c11_hin_ar_cbse_04_001: Context/background knowledge of colonial education sets the historical frame for language politics.
c11_hin_ar_cbse_04_007: Grammar/usage analysis reveals how language choices encode thematic positions.  

## FORWARD_NODE_IDS
c11_hin_ar_cbse_04_012, c11_hin_ar_cbse_04_013, c11_hin_ar_cbse_04_014, c12_hin_a_cbse_04_011, c12_hin_a_cbse_05_011, c12_hin_a_cbse_09_011, c12_hin_a_cbse_11_011, c12_hin_a_cbse_12_011, c12_hin_a_cbse_17_011, c12_hin_ar_cbse_01_011, c12_hin_ar_cbse_02_011, c12_hin_ar_cbse_04_010, c12_hin_ar_cbse_04_011, c12_hin_ar_cbse_07_011, c12_hin_ar_cbse_09_011, c12_hin_ar_cbse_10_011, c12_hin_ar_cbse_11_011

## FORWARD_REASONS
c11_hin_ar_cbse_04_012: Grammatical analysis enables accurate literal comprehension and inference of tone.
c11_hin_ar_cbse_04_013: Critical interpretation of the author's argument relies on understanding linguistic choices.
c11_hin_ar_cbse_04_014: Writing skills tasks (e.g., analytical paragraphs) require citing grammatical evidence.
c12_hin_a_cbse_04_011: अगला तार्किक चरण: This node analyzes the grammatical structures, syntactic patterns, and language usage specific to th... इस नोड की अवधारणाओं को सीधे उपयोग/विस्तारित करता है।  
c12_hin_a_cbse_05_011: Class 11 work on syntactic deviation for poetic effect  
c12_hin_a_cbse_09_011: Introduced *samas* identification — prevents over-application to tadbhava words (Diagnostic 5).  
c12_hin_a_cbse_11_011: Explains perfective participle (-kar/-dj) forms — critical for "<ydkdj", "fl[kkdj".  
c12_hin_a_cbse_12_011: Analysis of dialect markers in Class 11 prose selections  
c12_hin_a_cbse_17_011: Covered समास (compound) types — required to analyze व्यक्ति-लिंग/समाज-लिंग as तत्पुरुष समास.  
c12_hin_ar_cbse_01_011: Develops ability to link grammatical choice to thematic meaning.  
c12_hin_ar_cbse_02_011: Exposure to different poets' grammatical styles.  
c12_hin_ar_cbse_04_010: Class 11 grammar node — provides metalanguage (collocation, register, aspect) needed for connotation analysis.  
c12_hin_ar_cbse_04_011: Class 11 grammar node provides the foundational terminology (voice, tense, clause types) used here.  
c12_hin_ar_cbse_07_011: Practice with syntactic inversion in medieval poetry.  
c12_hin_ar_cbse_09_011: Develops ability to link grammatical form to poetic effect.  
c12_hin_ar_cbse_10_011: Worked examples of idiom interpretation (Chapter 4).  
c12_hin_ar_cbse_11_011: Develops register variation awareness  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS


## CHAIN_DESCRIPTION
c11_hin_ar_cbse_04_010 -> c11_hin_ar_cbse_04_011 -> c11_hin_ar_cbse_04_012

## THIS_FORMULA
N/A - conceptual

## FORMULA_VARIABLES
N/A

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
linguistic

## CROSS_SUBJECT
c11_history_colonialism | The chapter satirizes Macaulay's English Education Act 1835; history node provides the policy background that the text's language usage critiques.
c11_english_language_contact | The text's transliterated English words (e.g., एब यकडबल्यूएमज़ेड) illustrate phonological adaptation and code-mixing phenomena studied in language contact.

## PREREQ_CONCEPT
Ability to identify the language origin (Sanskrit, Persian, Arabic, English) of Hindi vocabulary.

## PREREQ_BEFORE
Student must know how to distinguish between तत्सम, तद्भव, विदेशज, and देशज words in Hindi.

## PREREQ_STUCK
Review the "शब्द-निर्माण" and "भाषा-परिवार" concepts from Class 9-10 Hindi grammar (तत्सम/तद्भव/विदेशज classification).

## WORKED_EXAMPLE_1
PROBLEM: Analyze the grammatical satire in the sentence: "एब यकडबल्यूएमज़ेड! वर डक्स व्किओस् 'क्क्लु-द्य द्क ब्ल न्स् एस् वर ग्क्स क्स;क" (Mr. Englishman! Now your rule in this country has ended). Identify how the transliteration, sentence structure, and address form work together to mock colonial authority.

STEPS:
- Step 1: Identify the transliterated words: "एब यकडबल्यूएमज़ेड" = "Mr. Englishman" written in Devanagari as pronounced by an Indian. Note the deliberate distortion of English phonetics.
- Step 2: Analyze the sentence structure: "वर डक्स व्किओस् 'क्क्लु-द्य द्क ब्ल न्स् एस् वर ग्क्स क्स;क" uses Hindi syntax but with English words forced into Hindi grammar (e.g., 'क्क्लु-द्य' for 'rule ended'). The verb "ग्क्स क्स;क" (गया है) is in passive/perfective, suggesting the rule ended on its own, not by Indian agency.
- Step 3: Examine the address form: "एब यकडबल्यूएमज़ेड" is used as a vocative with no honorific, yet the narrator later uses "महोदय". This inconsistency mocks the Englishman's demand for titles.
- Step 4: Synthesize: The author creates a linguistic hybrid that sounds absurd, highlighting the absurdity of colonial rule. The grammar mimics the colonizer's language but subverts it.
- Step 5: Connect to theme: This linguistic strategy enacts the chapter's central argument – colonial education imposed a foreign language that Indians now turn against the colonizer.

REASONING: The steps move from surface features (transliteration) to structural choices (syntax, voice) to pragmatic function (address), revealing how grammar serves satire. Each step builds evidence for the interpretive claim.

ANSWER: The sentence satirizes colonial authority by transliterating English into Devanagari to expose its foreignness, using passive-like construction to deny the colonizer agency in their own departure, and employing inconsistent honorifics to mock their obsession with status. Together, these grammatical choices perform the text's anti-colonial critique.

## WORKED_EXAMPLE_2
PROBLEM: The textbook exercise asks: "इक्ज़िट, ब्लैक बोर्ड, टिकट, स्टेशन" – classify these words by language origin and explain why the author includes them in a Hindi text about colonial education.

STEPS:
- Step 1: Classify each word: इक्ज़िट (English), ब्लैक बोर्ड (English), टिकट (English via Persian/Arabic? Actually टिकट from English 'ticket'), स्टेशन (English). All are loanwords from English.
- Step 2: Note the context: These are objects/institutions introduced by the British (exit signs, blackboards, tickets, railway stations). The author uses the English terms even in Hindi to show how colonial modernity imposed its vocabulary.
- Step 3: Analyze the effect: Using the English words (in Devanagari) instead of Hindi equivalents (निकास, काला तख्ता, टिकट -> प्रवेशपत्र, स्टेशन -> रेलवे स्टेशन) forces the reader to confront the pervasiveness of colonial language.
- Step 4: Link to the chapter's argument: The narrator's use of these words, while criticizing the Englishman, shows the Indian's complicity – we use their words even to resist them.
- Step 5: Evaluate: This is not mere vocabulary listing; it's a meta-commentary on linguistic imperialism.

REASONING: The exercise appears simple (classify words) but the chapter demands analysis of why those specific words are used. The steps guide from classification to contextual interpretation to thematic synthesis.

ANSWER: All four words are English loanwords transliterated into Hindi. The author includes them to demonstrate how colonial institutions (railways, schools, courts) imposed English vocabulary on Indian life. Their presence in a Hindi critique underscores the inescapability of linguistic colonization – the narrator cannot fully escape the colonizer's language even while attacking him.

## WORKED_EXAMPLE_3
PROBLEM: Compare the two conversion tasks in the textbook: (1) "वकीलों ने न्यायालय में बहस की" -> "सामान्य हिंदी" and (2) "मुद्दई सुस्त गवाह चुस्त" (a proverb) -> explain in simple Hindi. How do these tasks together reveal the chapter's view on language hierarchy?

STEPS:
- Step 1: Perform conversion 1: Replace वकील (Arabic) with अधिवक्ता (Sanskrit), न्यायालय (Sanskrit) with अदालत (Persian/Arabic? Actually अदालत is Arabic, but often used), बहस (Persian) with वाद-विवाद (Sanskrit). Note the direction: towards Sanskritized Hindi.
- Step 2: Perform conversion 2: The proverb "मुद्दई सुस्त गवाह चुस्त" uses Persian-origin words (मुद्दई, गवाह). Explain in simple Hindi: "मुकदमा करने वाला आलसी होता है और गवाह तेज़।" Here simplification retains Persian words but clarifies meaning.
- Step 3: Analyze the pattern: Task 1 pushes for Sanskritization (associated with "pure" Hindi), Task 2 accepts Perso-Arabic vocabulary as part of common speech. The textbook itself mixes registers.
- Step 4: Connect to author's stance: Chandradhar Sharma Guleri (a Sanskrit scholar) advocates for Sanskritized Hindi, yet the chapter's narrator uses a highly Persianized, English-mixed register to satirize the Englishman. This tension shows the complexity of language politics.
- Step 5: Synthesize: The exercises are not neutral; they reflect the early 20th-century debate on Hindi's identity. The chapter uses this debate as a weapon against colonial education.
- Step 6: Relate to board exam: A question might ask "How does the language exercise reflect the theme?" Answer must link grammatical choices to ideological positions.

REASONING: This example combines vocabulary classification (from prerequisite node) with thematic analysis (from literary devices nodes) to show how grammar exercises in the textbook are themselves part of the text's argument.

ANSWER: The first conversion promotes Sanskritization as linguistic purity, aligning with the nationalist Hindi project. The second accepts Perso-Arabic vocabulary as the living language of the people. The chapter exploits this tension: the narrator's high Sanskritized rhetoric contrasts with the Englishman's Anglicized vocabulary, while the exercises reveal the author's own ideological position. Together, they show that "language usage" in the text is a battlefield of colonial and nationalist identities.

## COMPETENCY_QUESTION_1
QUESTION: In the chapter, the narrator says: "वकीलों ने न्यायालय में बहस की". The textbook asks to rewrite it in "सामान्य हिंदी". A student rewrites it as "वकीलों ने कोर्ट में बहस की". Is this correct? Justify your answer by explaining what "सामान्य हिंदी" means in the context of this chapter's language politics.

COMPETENCY: Critical analysis of sociolinguistic concepts in literary context

STEPS:
- Step 1: Identify the student's error: "कोर्ट" is an English loanword, not "सामान्य हिंदी".
- Step 2: Define "सामान्य हिंदी" in this context: It refers to the Sanskritized register promoted as standard Hindi in the early 20th century (तत्सम शब्दावली).
- Step 3: Provide the expected conversion: "अधिवक्ताओं ने अदालत में वाद-विवाद किया" (using तत्सम words).
- Step 4: Explain why the distinction matters: The chapter critiques colonial education that displaced indigenous legal vocabulary; using "कोर्ट" perpetuates the very Anglicization the author opposes.

ANSWER: No, the student's rewrite is incorrect. "सामान्य हिंदी" in this chapter means the Sanskritized literary standard (तत्सम प्रधान), not the colloquial mixed register. The correct conversion replaces Perso-Arabic/English words with Sanskrit equivalents: वकील -> अधिवक्ता, न्यायालय -> अदालत (or न्यायालय itself is Sanskrit), बहस -> वाद-विवाद. Using "कोर्ट" (from English court) contradicts the chapter's nationalist linguistic agenda.

DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: The narrator addresses the Englishman as "एब यकडबल्यूएमज़ेड" (transliterated Mr. Englishman) and later as "महोदय". Analyze how the shift in address forms across the text maps onto the shifting power dynamic between colonizer and colonized. Support your answer with at least two other grammatical features (e.g., verb forms, sentence types) that reinforce this mapping.

COMPETENCY: Synthesis of grammatical analysis with thematic interpretation

STEPS:
- Step 1: Map the address forms: Initial "एब यकडबल्यूएमज़ेड" (mocking, no respect) -> later "महोदय" (formal honorific) -> final direct challenge without address. This mirrors the Indian's journey from subservience to resistance.
- Step 2: Identify verb forms: Early passages use passive/impersonal constructions ("लिखवाया गया", "समझाया गया") showing Indian passivity. Later, active voice ("मैंने कहा", "तुमने किया") asserts agency.
- Step 3: Identify sentence types: Early rhetorical questions ("क्या यही न्याय है?") seeking validation. Later, declarative imperatives ("जाओ", "सुनो") commanding the Englishman.
- Step 4: Synthesize: The grammatical trajectory from passive/polite to active/confrontational enacts the political awakening that is the chapter's core narrative.
- Step 5: Conclude: Language usage is not decorative; it is the vehicle of the protagonist's empowerment.

ANSWER: The shift from transliterated mockery ("एब यकडबल्यूएमज़ेड") to formal honorific ("महोदय") to direct addresslessness parallels the Indian narrator's internal shift from colonized subject to resistant voice. This is reinforced by a grammatical shift from passive/impersonal constructions (denying Indian agency) to active voice and imperative sentences (claiming agency). For example, early "ब्लैक बोर्ड पर लिखवाया गया" (passive) becomes later "मैंने तुम्हारा शासन समाप्त किया" (active). The grammar performs the political transformation.

DIFFICULTY: hard