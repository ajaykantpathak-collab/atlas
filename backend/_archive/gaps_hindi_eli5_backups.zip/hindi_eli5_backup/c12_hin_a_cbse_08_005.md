## DEFINITION
Supporting characters in poetry are the secondary voices, personified entities, or symbolic figures (e.g., the *sakhi* friend, the divine beloved, the door/thorn) that interact with the protagonist to reveal their inner state, advance the thematic conflict (virah/milan), and embody abstract concepts like longing, obstruction, or grace. Unlike prose, they are often archetypal rather than individualized.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
Student can identify all supporting figures in the three poems, explain each one's symbolic function in a 4-step PEEL paragraph (Point, Evidence from line/stanza, Explanation of symbolic role, Link to virah/milan theme), and distinguish between a literal character and a personified abstraction.

## SCOPE_BOUNDARY
Covers only the three poems by Phokir (fo|kifr) in NCERT Class 12 Antra Chapter 8. Does NOT cover character analysis of other chapters, novels, or plays. Focuses on Braj Bhasha poetic conventions: sakhi, priya, personified nature/objects.

## WALKTHROUGH
Imagine you are listening to a friend describe a dream where a door refuses to open and a thorn pricks their foot — you instantly know the door and thorn aren't "characters" in a novel sense but symbols of their anxiety. Similarly, in Phokir's poems, the *sakhi* (xksoqQy), the beloved (eèkqiqj/fifjr/laqnfj), the door (dkuu), and the thorn (>k¡ib) are not people with backstories; they are dramatic devices externalizing the devotee's separation (virah). Start by listing every noun that speaks, is addressed, or acts in each stanza. Ask: "Does this entity have agency? Does it represent a feeling or obstacle?" That distinction is your entry point.

## DIAGNOSTIC_QUESTION_1
Identify the supporting character addressed as "xksoqQy" in the first poem and state their single dramatic function in that stanza.

## DIAGNOSTIC_ANSWER_1
The *xksoqQy* (sakhi/friend) is addressed in stanza 1 ("xksoqQy rsft eèkqiqj cl js du vitl ysy"). Their function is to witness the protagonist's despair and receive the information that the beloved has gone far away, thereby externalizing the protagonist's isolation. A wrong answer (e.g., "the sakhi is the protagonist's wife") reveals confusion between the poetic convention of *sakhi* as a confidante in Braj poetry and a literal marital relationship.

## DIAGNOSTIC_QUESTION_2
Explain in your own words why the "dkuu" (door) and "deyeqf[k]" (threshold) in the third poem are considered supporting characters rather than mere setting details.

## DIAGNOSTIC_ANSWER_2
The door and threshold are personified: they "watch" (gsfj) and possess agency ("ewfn jg, nq u;ku" — stay awake, don't sleep). They act as gatekeepers controlling access to the beloved, symbolizing the barrier between the devotee and the divine. A wrong answer describing them as "background scenery" misses the *kriyā* (action) verbs assigned to them, a hallmark of *āropa* (superimposition) in Bhakti poetry where inanimate objects become conscious participants.

## DIAGNOSTIC_QUESTION_3
In poem 2, the line "lsgks eèkqj cksy lzoufg lwuy lzqfr iFk ijl u xsy" attributes a specific action to the beloved's hair. Apply the concept of *alaṅkāra* (figure of speech) to analyze how this hair functions as a supporting "character" that traps the protagonist.

## DIAGNOSTIC_ANSWER_3
The hair (eèkqj cksy) is a *sādhāraṇīkaraṇa* (generalized symbol) of *māyā*/attachment: it "does not sleep in the house" (lzoufg lwuy lzqfr iFk ijl u xsy), meaning the beloved's tresses keep the protagonist awake/entangled. It acts as an autonomous antagonist — a supporting character representing worldly bondage. A wrong answer treating the hair as literal decoration ignores the verb "lzqfr" (awake/alert) giving it sentient hostility.

## DIAGNOSTIC_QUESTION_4
Compare the role of the *sakhi* (xksoqQy/lf[k) in poem 1 and poem 2. How does the shift in the *sakhi*'s stance (from listener to questioner) reflect the protagonist's deepening crisis?

## DIAGNOSTIC_ANSWER_4
In poem 1, the *sakhi* is a passive confidante ("xksoqQy rsft...") receiving the protagonist's declaration. In poem 2, the *sakhi* initiates ("lf[k gs] fd iqNfl vuqHko eks" — "O friend, there is some call"), probing the protagonist's unrest. This shift mirrors the protagonist's move from *stated separation* to *unbearable, inexplicable longing* (vuqHko). A wrong answer saying "the sakhi is the same in both" misses the structural evolution of the *virah* narrative across the three poems.

## DIAGNOSTIC_QUESTION_5
Evaluate the claim: "The thorn (>k¡ib) in poem 3 is a more effective supporting character than the beloved (jeku/laqnfj) because it has clearer agency." Defend or refute with textual evidence.

## DIAGNOSTIC_ANSWER_5
Refute. The thorn (>k¡ib) has physical agency ("can dj ns" — pierce/prick) but exists only as an instrument of the beloved's play (līlā). The beloved (jeku/laqnfj) is the *ultimate* agent: "pkSnfl&pk¡n&leku" (watching carefully), "xj, tyèkkjk" (creating fire/obstacles), "Nu&Nu ruq fNu" (dancing in various forms). The thorn is a *nimitta* (instrument); the beloved is the *kartā* (doer). A wrong answer privileging the thorn confuses *visible action* with *causal primacy* in Bhakti poetics where the divine hides behind obstacles.

## DIAGNOSTIC_QUESTION_6
Create a two-stanza Braj-style couplet (dohā/chaupāi) introducing a *new* supporting character (e.g., a flute, a peacock, a cloud) that symbolizes the protagonist's hope. Use at least two archaic Braj words from the glossary (e.g., *vitl, fugkjy, frjfir*).

## DIAGNOSTIC_ANSWER_6
Example: "bnsfg;k pkj fgr] vitl u gksrkoyh / fugkjy frjfir Hksy] eu dks lqjkoyh" (The peacock cries in the forest, hope does not die / Seeing union, the heart finds peace). A poor answer uses modern Hindi words (ashā, dekhkar) or lacks a clear symbolic link between the new character and the emotional state, showing failure to internalize the *bhāva*-language mapping.

## COMMON_MISCONCEPTION
Students treat every noun in the poem as a "character" with equal weight (e.g., analyzing "cksy" hair, "dkuu" door, "xksoqQy" sakhi, "jeku" beloved all as parallel dramatis personae). They miss the hierarchy: the *priya* (beloved) is the *adhikārī* (primary agent), the *sakhi* is the *madhyastha* (mediator), and objects (door, thorn, hair) are *upādāna* (material instruments). This leads to board answers that list "characters" without analyzing their *functional tier* in the *virah* narrative, costing 2-3 marks in 5-mark questions.

## ON_FAILURE
1. Re-read node c12_hin_a_cbse_08_004 (Protagonist) to re-establish the protagonist's *bhāva* trajectory. 2. Make a 3-column table: Entity | Verbs/Actions Assigned | Symbolic Tier (Primary/Mediator/Instrument). 3. Re-attempt Diagnostic Q4 using this table. 4. If still stuck, revisit c11_hin_ar_cbse_08_005 (Class 11 Supporting Characters) for the *sakhi* convention basics.

## BUILDS_ON
c12_hin_a_cbse_08_004 (Character Analysis: Protagonist) — you must know the protagonist's *virah* stages before mapping how supporting figures reflect them.

## LEADS_TO
c12_hin_a_cbse_08_006 (Theme: Primary Theme and Message) — the collective function of supporting characters *constructs* the theme of *prem-mārga* (path of love).

## PREREQUISITE_NODE_IDS
c12_hin_a_cbse_08_004, c12_hin_a_cbse_08_001, c11_hin_ar_cbse_08_005, c11_hin_ar_cbse_01_005
## PREREQUISITE_REASONS
c12_hin_a_cbse_08_004: Protagonist's emotional arc is the reference frame for every supporting character's function.
c12_hin_a_cbse_08_001: Context (Bhakti/Sufi milieu, Braj Bhasha conventions) explains why *sakhi* and *priya* are archetypes.
c11_hin_ar_cbse_08_005: Direct Class 11 precedent for supporting character analysis in the same textbook series.
c11_hin_ar_cbse_01_005: Foundational Class 11 introduction to character roles (flat/round, symbolic) in Hindi poetry.

## FORWARD_NODE_IDS
c12_hin_a_cbse_08_006, c12_hin_a_cbse_08_009, c12_hin_a_cbse_08_013, c12_hin_a_cbse_08_007

## FORWARD_REASONS
c12_hin_a_cbse_08_006: Theme emerges from the interplay of protagonist and supporting characters (e.g., separation/union).
c12_hin_a_cbse_08_009: Irony/symbolism (e.g., thorn as grace, door as barrier) is carried by supporting characters.
c12_hin_a_cbse_08_013: Critical interpretation requires evaluating how supporting figures shape meaning.
c12_hin_a_cbse_08_007: Supporting characters (guru, pandit, mullah, Yama) personify thematic conflicts.  

## CROSS_SUBJECT_PREREQS
c11_hin_ar_cbse_08_005, c11_hin_v_cbse_01_005
## CROSS_SUBJECT_REASONS
c11_hin_ar_cbse_08_005: Same chapter index in Antra Class 11 — likely covers parallel Bhakti poem analysis (e.g., Kabir/Mira) where *sakhi* convention is identical.
c11_hin_v_cbse_01_005: Vitan (supplementary reader) Class 11 Chapter 1 — may contain prose character analysis that contrasts with poetic symbolization.

## CHAIN_DESCRIPTION
c12_hin_a_cbse_08_004 -> c12_hin_a_cbse_08_005 -> c12_hin_a_cbse_08_006

## THIS_FORMULA
Character Function = (Agency Verbs + Addressee Status + Symbolic Tier) mapped onto Virah/Milan continuum

## FORMULA_VARIABLES
Agency Verbs: Kriyā-padas assigned to entity (e.g., gsfj=watches, can dj ns=pierces). Addressee Status: Directly spoken to (xksoqQy) vs spoken about (dkuu). Symbolic Tier: 1=Priya (causal), 2=Sakhi (mediator), 3=Upādāna (instrument). Virah/Milan Continuum: Poem 1 (stated separation) -> Poem 2 (restless longing) -> Poem 3 (obstacle-laden approach).

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
analytical

## CROSS_SUBJECT
N/A | The *sakhi* and *priya* conventions mirror historical Bhakti/Sufi social structures where female devotees adopted *gopī-bhāva*; the door/thorn symbolism reflects temple ritual barriers.
 N/A | Jungian *anima/animus* projection onto the beloved and *shadow* onto obstacles (thorn) explains the poems' universal psychological resonance beyond sectarian theology.
## PREREQ_CONCEPT
Braj Bhasha *virah* poetry convention: the protagonist (nāyak/nāyikā) never speaks directly to the divine; mediation via *sakhi* and personified nature is mandatory.

## PREREQ_BEFORE
Student can define *nāyak-nāyikā-bheda* (hero-heroine types) and *sakhī* role from Class 11 Hindi (c11_hin_ar_cbse_01_005) and identify the protagonist's *bhāva* in each poem (c12_hin_a_cbse_08_004).

## PREREQ_STUCK
If the distinction between *sakhi* as character vs *sakhi* as narrative device is unclear, review the *Barahmasa* or *Biraha* poems in Class 11 Antra Chapter 1 (c11_hin_ar_cbse_01_002/005).

## WORKED_EXAMPLE_1
PROBLEM: Analyze the supporting character "eèkqj cksy" (beloved's hair) in poem 2, stanza 2. Show how it functions as an antagonist using the 4-step PEEL method.

STEPS:
- Step 1: Locate the entity — "eèkqj cksy" appears in line 2 of poem 2, described with the verb phrase "lzoufg lwuy lzqfr iFk ijl u xsy" (does not sleep in the houses, remains alert).
- Step 2: Identify grammatical agency — "lzqfr" (awake/alert) is a stative verb giving sentience to hair; "lzoufg lwuy" (in the houses) gives it spatial dominance.
- Step 3: Determine symbolic tier — Hair is *upādāna* (instrument) of the beloved's control; it binds the protagonist ("fry&fry uwru gks" — trembles again and again).
- Step 4: Link to theme — The hair's wakefulness mirrors the protagonist's insomnia, externalizing *virah* as a physical trap. The beloved need not be present; her hair enforces separation.
- Step 5: Verify with glossary — "lzqfr" = Jqfr (alert), "fry&fry" = trembling. Confirms physical manifestation of anxiety.

REASONING: The PEEL structure forces textual evidence (step 1-2) before interpretation (step 3-4), preventing the common error of asserting symbolism without linguistic proof. Step 5 uses the NCERT glossary to ground analysis in the text's own lexicon.

ANSWER: The beloved's hair is a supporting character at the Instrumental tier. It acts autonomously (stays awake, pervades houses) to enforce the protagonist's sleepless trembling, symbolizing how *māyā* (attachment) operates without the divine's direct presence. This advances the *virah* theme by making separation tactile.

## WORKED_EXAMPLE_2
PROBLEM: Compare the door (dkuu) and threshold (deyeqf[k]) in poem 3 as a paired supporting character unit. Explain their combined symbolic function using the "Agency Verbs + Addressee Status" formula.

STEPS:
- Step 1: List entities and verbs — "dkuu gsfj" (door watches), "deyeqf[k] ewfn jg, nq u;ku" (threshold stays awake, doesn't sleep). Both have *kriyā* (action).
- Step 2: Check addressee status — Neither is directly addressed; they are described in third person ("gsfj" = watches). They are *observed* obstacles, not interlocutors like the *sakhi*.
- Step 3: Assign symbolic tier — Both are *upādāna* (instruments) but elevated to *pratiṣṭhā* (established guardians) by personification. They guard the *gṛha* (house = divine abode).
- Step 4: Analyze pairing — Door = vertical barrier (entry/exit); Threshold = horizontal boundary (inside/outside). Together they seal the space completely.
- Step 5: Connect to protagonist's action — Protagonist says ">k¡ib can dj ns" (remove the thorn) — the thorn is *outside* the door/threshold. The door/threshold are the final inner sanctum barrier.
- Step 6: Theme link — They represent *dharmic* or *karmic* thresholds: the devotee must transcend institutional/ritual boundaries (door) and liminal states (threshold) to reach the beloved.

REASONING: The formula variables (Agency Verbs, Addressee Status, Symbolic Tier) create a rubric that prevents over-interpretation. The pairing analysis (step 4) reveals structural symbolism missed when analyzing each noun in isolation.

ANSWER: The door-threshold pair forms a compound Guardian character at the Instrumental tier. Their personified wakefulness (gsfj, ewfn jg) seals the divine abode, representing the final ritual/psychological barriers before *milan*. Unlike the *sakhi* (mediator), they cannot be persuaded — only transcended.

## WORKED_EXAMPLE_3
PROBLEM: Trace the evolution of the *sakhi* (xksoqQy / lf[k) across all three poems as a single supporting character arc. Use the Virah/Milan continuum variable.

STEPS:
- Step 1: Poem 1 — "xksoqQy rsft eèkqiqj cl js du vitl ysy" (Friend, beloved gone far, hope lost). *Sakhi* = passive witness to *stated virah*. Addressee status: direct address ("xksoqQy").
- Step 2: Poem 2 — "lf[k gs] fd iqNfl vuqHko eks" (O friend, some call arises). *Sakhi* = active interrogator probing *unexplained longing* (vuqHko). Addressee status: direct address ("lf[k").
- Step 3: Poem 3 — *Sakhi* absent as addressee. Protagonist speaks to door/thorn/beloved directly. *Sakhi*'s mediation function is exhausted; protagonist now confronts barriers alone.
- Step 4: Map to continuum — Poem 1: *Viśaya-virah* (separation from object). Poem 2: *Bhāva-virah* (separation as internal state). Poem 3: *Sādhana-virah* (separation as obstacle course). *Sakhi* relevance decreases as protagonist internalizes the journey.
- Step 5: Thematic implication — The *sakhi*'s disappearance signals the devotee's maturity: from needing a confidante to facing the divine's tests directly.
- Step 6: Board answer structure — Write as a 3-stage trajectory: Confidante → Interrogator → Absent (internalized), each stage marked by shift in address mode and verb agency.

REASONING: This multi-poem synthesis is exactly what CBSE 5-mark questions demand ("Trace the development of..."). The continuum variable (Viśaya/Bhāva/Sādhana virah) provides the analytical framework that lifts the answer from description to literary criticism.

ANSWER: The *sakhi* evolves from passive listener (Poem 1) to active questioner (Poem 2) to complete absence (Poem 3), mirroring the protagonist's shift from externalized grief to internalized restlessness to autonomous spiritual striving. Her fading presence marks the devotee's transition from *dvaita* (duality, needing a mediator) to *advaita*-like direct confrontation with the divine's obstacles.

## COMPETENCY_QUESTION_1
QUESTION: A student writes: "In Phokir's poems, the sakhi, the door, the thorn, and the hair are all supporting characters because they are not the main speaker." Using the concept of Symbolic Tier, explain why this statement is an oversimplification and rewrite it as a board-exam quality sentence.

COMPETENCY: Critical Analysis / Literary Terminology Precision
STEPS:
- Step 1: Identify the error — the student conflates "non-protagonist" with "supporting character" without differentiating functional hierarchy.
- Step 2: Apply Symbolic Tier — Priya (beloved) = Tier 1 (Causal Agent); Sakhi = Tier 2 (Mediator); Hair/Door/Thorn = Tier 3 (Instruments).
- Step 3: Note agency gradient — Priya has ultimate agency (creates obstacles); Sakhi has speech agency; Objects have personified but limited agency.
- Step 4: Draft corrected sentence — "Phokir deploys a three-tier supporting cast: the Priya (jeku/laqnfj) as the causal agent, the Sakhi (xksoqQy/lf[k) as the human mediator, and personified instruments (hair, door, thorn) as material extensions of divine will."

ANSWER: The original statement flattens the poem's theological architecture. The corrected version uses "three-tier supporting cast," "causal agent," "mediator," and "material extensions" — terminology that demonstrates *analytical* (not just identificatory) competence. This earns full content marks in CBSE 3-5 mark questions.

DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: In Poem 3, the protagonist commands the thorn: ">k¡ib can dj ns" (remove the thorn). Yet the thorn is described as "tyèkkjk" (obstacle) created by the beloved's play ("xj, tyèkkjk" — fire/obstacle created). Construct an Assertion-Reason argument evaluating whether the protagonist's command to the thorn represents *bhakti* (devotion) or *ahaṅkāra* (ego). Use at least two glossary words.

STEPS:
- Step 1: Assertion — The command is *bhakti*, not *ahaṅkāra*, because it addresses the *instrument* (thorn) while acknowledging the *agent* (beloved's "xj, tyèkkjk").
- Step 2: Reason 1 — "can dj ns" (remove/pierce through) is a plea for *kṛpā* (grace) to clear the path; the protagonist does not claim power to remove it themselves.
- Step 3: Reason 2 — Glossary: "tyèkkjk = vJqèkkjk" (trembling/obstacle) and "xj, = fxjuk" (to create/fire). The beloved *creates* the obstacle; the devotee asks for its removal — classic *prapatti* (surrender) dynamic.
- Step 4: Counter-argument check — If protagonist said "I will crush the thorn," that would be *ahaṅkāra*. The imperative "ns" (give/do) directed at the thorn is actually a prayer to the beloved via the obstacle.
- Step 5: Board-style conclusion — The command is a *vyāj-stuti* (indirect prayer): addressing the obstacle to invoke the obstacle-maker's mercy.

ANSWER: Assertion: The command represents *bhakti*. Reason: The protagonist targets the *nimitta* (thorn, tyèkkjk) while implicitly invoking the *kartā* (beloved who "xj," creates fire/obstacles). The verb "ns" (give/do) is a petition, not a command of power. This mirrors the *gopī-bhāva* where obstacles are embraced as the beloved's play. A student writing "the protagonist orders the thorn" confuses grammatical imperative with theological agency.

DIFFICULTY: hard