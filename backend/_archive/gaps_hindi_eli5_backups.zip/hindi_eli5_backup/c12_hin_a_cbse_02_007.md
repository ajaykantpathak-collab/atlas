## DEFINITION
Secondary themes are the underlying ideas, motifs, or concerns in a literary work that support, contrast with, or enrich the primary theme without being the central message; they emerge through recurring images, character interactions, and narrative details that reveal additional layers of meaning about human experience, society, or emotion.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student can independently identify at least three distinct secondary themes in "Lajja ka Lekh" (or the prescribed poem), cite specific textual evidence (lines, images, character moments) for each, and explain how each secondary theme interacts with the primary theme of a father's grief at his daughter's vidai to deepen the poem's emotional and social resonance.

## SCOPE_BOUNDARY
This node covers identification, textual evidence gathering, and analytical explanation of secondary themes in the Class 12 Antra Chapter 2 poem "Lajja ka Lekh" by Nirala (referred to as फुजक्यक in the text). It does NOT cover primary theme analysis (done in node 006), literary devices (nodes 008-009), or writing skills (node 014).

## WALKTHROUGH
Imagine you are at a friend's sister's wedding — the bride is crying, the father is silent, the mother is busy arranging things, and relatives are discussing customs. You sense many emotions at once: not just the father's sadness, but also the mother's quiet strength, the weight of tradition, the fleeting nature of childhood. A poem works the same way. Start by re-reading the poem silently, then aloud, noticing which lines pull at you beyond the father's grief. Mark stanzas where the mother appears, where customs are described, where time passes. Ask: "What else is the poet showing us about life, relationships, or society?" Each marked cluster is a potential secondary theme. The key insight: secondary themes are not hidden; they are woven into the same lines that carry the primary theme — you just shift your lens.

## DIAGNOSTIC_QUESTION_1
What is the definition of a secondary theme in literature, and how does it differ from the primary theme?

## DIAGNOSTIC_ANSWER_1
A secondary theme is a supporting idea that runs alongside the primary theme, adding depth or contrast; the primary theme is the central, unifying message. A wrong answer that equates secondary themes with "subplots" or "minor topics" reveals the student confuses narrative structure with thematic layering — themes are ideas, not events.

## DIAGNOSTIC_QUESTION_2
In "Lajja ka Lekh," the primary theme is the father's grief at his daughter's vidai. Identify one secondary theme suggested by the lines describing the mother's appearance and actions (e.g., "csVh osQ :i jax esa iRuh dk :i jax fn[kkbZ iM+rk gS"), and explain how it differs from the father's grief.

## DIAGNOSTIC_ANSWER_2
A valid secondary theme is the mother's quiet endurance and symbolic role as the keeper of continuity — she embodies the household's stability amid rupture. A wrong answer that says "the mother is also sad" misses the contrast: the father's grief is vocal and central; the mother's presence is visual, ritualistic, and sustaining — a different emotional register altogether.

## DIAGNOSTIC_QUESTION_3
Apply the concept of secondary theme to a new context: In a story about a farmer losing his land to a highway project, the primary theme is displacement. List two plausible secondary themes and the specific textual details (not plot events) that would evidence each.

## DIAGNOSTIC_ANSWER_3
Secondary theme 1: The erosion of intergenerational knowledge — evidenced by descriptions of the farmer's hands remembering seed rhythms the soil no longer needs. Secondary theme 2: The redefinition of masculinity in economic collapse — evidenced by the farmer's silence at the dinner table where he once led prayers. A wrong answer listing "loss of income" or "moving to the city" confuses plot consequences with thematic ideas.

## DIAGNOSTIC_QUESTION_4
Analyze how the secondary theme of "social custom as both shelter and cage" operates in "Lajja ka Lekh." Use the lines referencing "csVh cpkvks] csVh i<+kvks" (daughters to marry, daughters to educate) and the father's internal conflict to show how custom simultaneously structures meaning and inflicts pain.

## DIAGNOSTIC_ANSWER_4
The phrase "csVh cpkvks, csVh i<+kvks" encapsulates the duality: custom prescribes the daughter's marriage (vidai) as sacred duty, giving the father's grief ritual legitimacy, yet the same custom forces the separation that causes the pain. The father's conflict — "nq[k gh thou dh dFkk jgh, D;k dgw¡ vkt tks ugha dgh" — shows him trapped in a narrative he cannot rewrite. A wrong answer that only lists customs without analyzing their contradictory function misses the analytical demand.

## DIAGNOSTIC_QUESTION_5
Evaluate this student claim: "The poem's secondary themes are less important than the primary theme because they get fewer lines." Defend or refute using evidence from the poem's structure.

## DIAGNOSTIC_ANSWER_5
Refute. In "Lajja ka Lekh," the mother appears in fewer lines but her image — "csVh osQ :i jax esa iRuh dk :i jax" — anchors the poem's emotional architecture; without her, the father's grief floats unmoored. Similarly, the custom theme appears in a single proverb but governs the entire situation. Thematic weight ≠ line count. A wrong answer agreeing with the claim reveals a quantitative rather than structural understanding of theme.

## DIAGNOSTIC_QUESTION_6
Create a four-line stanza in Hindi that introduces a secondary theme of "silent sibling witness" to the vidai scene in "Lajja ka Lekh," using imagery consistent with the poem's tone.

## DIAGNOSTIC_ANSWER_6
A strong response might be:
"कोने में खड़ा छोटा भाई, / आँखों में मेला, होंठ सिले, / गुड़िया छिनी, आँगन सूना, / बाबा के दुःख में खुद पिघले।"
This works because it adds a new perspective (brother), uses concrete imagery (doll, courtyard), and links to the primary theme (father's grief) without overshadowing it. A poor answer that writes a generic sad poem about weddings shows inability to extend a specific textual world.

## COMMON_MISCONCEPTION
Students often think secondary themes are just "other topics mentioned in the poem" — e.g., listing "marriage," "mother," "time" as themes without articulating the *idea* each embodies. They write: "A secondary theme is marriage" instead of "A secondary theme is the tension between social duty and personal attachment in marriage." This happens because they confuse subject (what the poem talks about) with theme (what the poem says about that subject). The NCERT questions (e.g., Q3: "vkdk'k cny dj cuk egh" — what do 'vkdk'k' and 'egh' signify?) demand interpretation, not listing.

## ON_FAILURE
If a student cannot move from subject to theme, do this 3-step remediation: (1) Take one subject from the poem (e.g., "mother"). Ask: "What does the poem *say* about mothers through this specific mother?" (2) Co-construct a theme statement: "Mothers are the silent architects of continuity." (3) Have the student find two lines that *show* this, not just mention her. Repeat for two more subjects. Only then return to the diagnostic questions.

## BUILDS_ON
This node builds on the ability to distinguish subject from theme and to cite textual evidence, developed in c12_hin_a_cbse_02_006 (Primary Theme) and c12_hin_a_cbse_02_004/005 (Character Analysis).

## LEADS_TO
This node enables literary devices analysis (c12_hin_a_cbse_02_008, 009) because devices like metaphor and irony are the vehicles through which secondary themes are conveyed; it also enables critical interpretation (c12_hin_a_cbse_02_013) and writing skills (c12_hin_a_cbse_02_014).

## PREREQUISITE_NODE_IDS
c12_hin_a_cbse_02_001, c12_hin_a_cbse_02_002, c12_hin_a_cbse_02_003, c12_hin_a_cbse_02_004, c12_hin_a_cbse_02_005, c12_hin_a_cbse_02_006
## PREREQUISITE_REASONS
c12_hin_a_cbse_02_001: Provides biographical and historical context (Nirala's life, Chhayavad) essential for grasping why certain secondary themes (e.g., tradition vs. modernity) appear.
c12_hin_a_cbse_02_002: Narrative structure knowledge helps locate where secondary themes surface in the poem's progression.
c12_hin_a_cbse_02_003: Setting/atmosphere (the vidai scene, the household) is the physical ground of secondary themes like custom and gender roles.
c12_hin_a_cbse_02_004: Protagonist (father) analysis reveals how secondary themes reflect/refract through his consciousness.
c12_hin_a_cbse_02_005: Supporting characters (mother, daughter, relatives) are the primary carriers of secondary themes.
c12_hin_a_cbse_02_006: Primary theme identification is the anchor; secondary themes are defined in relation to it.

## FORWARD_NODE_IDS
c12_hin_a_cbse_02_008, c12_hin_a_cbse_02_009, c12_hin_a_cbse_02_013, c12_hin_a_cbse_02_014, c12_hin_a_cbse_02_012, c12_hin_a_cbse_02_015

## FORWARD_REASONS
c12_hin_a_cbse_02_008: Imagery and metaphor are the main vehicles for secondary themes (e.g., mother's form as continuity).
c12_hin_a_cbse_02_009: Irony and symbolism deepen secondary themes (e.g., the proverb as ironic cage).
c12_hin_a_cbse_02_013: Critical interpretation requires synthesizing primary and secondary themes into a coherent reading.
c12_hin_a_cbse_02_014: Writing skills tasks (analytical essays, theme-based answers) directly apply this analysis.
c12_hin_a_cbse_02_012: Secondary themes (tradition, silence) offer additional inference lenses.  
c12_hin_a_cbse_02_015: Secondary themes offer multiple entry points for diverse discussion angles.  

## CROSS_SUBJECT_PREREQS
c11_hin_ar_cbse_01_007, c11_hin_ar_cbse_02_007, c11_hin_ar_cbse_03_007, c11_hin_ar_cbse_04_007, c11_hin_ar_cbse_05_007, c11_hin_ar_cbse_06_007, c11_hin_ar_cbse_07_007, c11_hin_ar_cbse_08_007, c11_hin_ar_cbse_09_007, c11_hin_ar_cbse_10_007, c11_hin_ar_cbse_11_007, c11_hin_ar_cbse_12_007, c11_hin_ar_cbse_13_007, c11_hin_ar_cbse_14_007, c11_hin_ar_cbse_15_007, c11_hin_ar_cbse_16_007, c11_hin_v_cbse_01_007, c11_hin_v_cbse_02_007, c11_hin_v_cbse_03_007, c11_hin_v_cbse_04_007, c11_hin_v_cbse_05_007
## CROSS_SUBJECT_REASONS
c11_hin_ar_cbse_01_007: Class 11 Antra Chapter 1 secondary themes practice establishes the skill of distinguishing primary/secondary themes in Chhayavad poetry.
c11_hin_ar_cbse_02_007: Chapter 2 reinforces the method with a different poem, building transferable analytical muscle.
c11_hin_ar_cbse_03_007: Chapter 3 adds complexity with multiple speakers, preparing for the layered voices in "Lajja ka Lekh."
c11_hin_ar_cbse_04_007: Chapter 4 introduces social themes (caste, reform) that resonate with the custom theme here.
c11_hin_ar_cbse_05_007: Chapter 5's focus on nature-human parallels trains the eye for symbolic secondary themes.
c11_hin_ar_cbse_06_007: Chapter 6's historical poems model how secondary themes encode collective memory.
c11_hin_ar_cbse_07_007: Chapter 7's feminist undertones prefigure the gender-role secondary theme in vidai.
c11_hin_ar_cbse_08_007: Chapter 8's philosophical poems teach abstract theme articulation.
c11_hin_ar_cbse_09_007: Chapter 9's urban alienation themes contrast with this poem's rural rootedness.
c11_hin_ar_cbse_10_007: Chapter 10's satirical secondary themes show thematic range.
c11_hin_ar_cbse_11_007: Chapter 11's children's perspectives link to the sibling witness idea.
c11_hin_ar_cbse_12_007: Chapter 12's folk motifs connect to the proverb "csVh cpkvks, csVh i<+kvks."
c11_hin_ar_cbse_13_007: Chapter 13's modernist fragmentation contrasts with this poem's structural unity.
c11_hin_ar_cbse_14_007: Chapter 14's Dalit literature themes expand the social critique lens.
c11_hin_ar_cbse_15_007: Chapter 15's environmental themes broaden the thematic vocabulary.
c11_hin_ar_cbse_16_007: Chapter 16's meta-poetic themes teach self-reflexive reading.
c11_hin_v_cbse_01_007 to c11_hin_v_cbse_05_007: Vitan chapters reinforce theme identification across genres (memoir, reportage, essay).
c11_hin_v_cbse_01_007: अन्य विषय की सहायता: Secondary themes are the supporting ideas, motifs, and concerns that run alongside the pri... के तत्व इस नोड में प्रयुक्त होते हैं।  
c11_hin_v_cbse_02_007: अन्य विषय की सहायता: Secondary themes are the underlying, often interconnected ideas in a literary text that su... के तत्व इस नोड में प्रयुक्त होते हैं।  
c11_hin_v_cbse_03_007: अन्य विषय की सहायता: Secondary themes are the subordinate yet significant ideas that run parallel to the primar... के तत्व इस नोड में प्रयुक्त होते हैं।  
c11_hin_v_cbse_04_007: अन्य विषय की सहायता: Secondary themes are the supporting ideas that run alongside the primary theme, enriching... के तत्व इस नोड में प्रयुक्त होते हैं।  
c11_hin_v_cbse_05_007: अन्य विषय की सहायता: Secondary themes are the underlying ideas, concerns, or messages in a literary work that s... के तत्व इस नोड में प्रयुक्त होते हैं।  

## CHAIN_DESCRIPTION
c12_hin_a_cbse_02_006 -> c12_hin_a_cbse_02_007 -> c12_hin_a_cbse_02_008

## THIS_FORMULA
Secondary Theme = (Recurring Subject) + (Implied Idea/Attitude) + (Textual Evidence Cluster) + (Relationship to Primary Theme: support/contrast/complicate)

## FORMULA_VARIABLES
Recurring Subject: A person, object, custom, or concept that appears multiple times (e.g., mother, proverb, time).
Implied Idea/Attitude: The poet's stance toward that subject (e.g., "mother as anchor," "custom as double-edged").
Textual Evidence Cluster: 2+ specific lines/images that collectively convey the idea.
Relationship to Primary Theme: How the secondary theme deepens, questions, or expands the central message.

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
analytical

## CROSS_SUBJECT
N/A | The poem's tension between "csVh cpkvks, csVh i<+kvks" mirrors early 20th-century debates on women's education vs. traditional marriage duties — a direct historical parallel.
 N/A | The vidai ritual, gendered grief expression (father vs. mother), and sibling roles map onto sociological concepts of patrilocal kinship, emotional labor, and ritual transition.
## PREREQ_CONCEPT
Distinguishing subject (what the text is about) from theme (what the text says about that subject) — e.g., "marriage" is a subject; "marriage as a social contract that both binds and severs" is a theme.

## PREREQ_BEFORE
Student must be able to answer: "What is the difference between a topic and a theme?" with a literary example.

## PREREQ_STUCK
Review the "Subject vs. Theme" mini-lesson in c12_hin_a_cbse_02_006 (Primary Theme) using the worked example there.

## WORKED_EXAMPLE_1
PROBLEM: Identify and analyze the secondary theme of "time as irreversible yet cyclical" in "Lajja ka Lekh," using the poem's opening and closing stanzas.
STEPS:
- Step 1: Locate time markers in the poem — opening: "ns[kk fookg vkevi uoy" (morning scene, wedding day); closing: "gks x;k C;kg, vkReh; Lotu" (done, departed, only own people remain). Note the progression from ritual beginning to finality.
- Step 2: Identify the recurring subject — time/transition — appearing in "fiz; dh v'kCn" (moment's words), "vkdk'k cny dj cuk egh" (change direction, make it right), "nq[k gh thou dh dFkk jgh" (only life's tale remains).
- Step 3: Articulate the implied idea — time moves forward irrevocably (vidai cannot be undone) yet the cycle repeats (every father faces this; "csVh cpkvks" is generational). The father's plea "vkdk'k cny dj cuk egh" is a futile wish to reverse time.
- Step 4: Gather evidence cluster — Stanza 1: morning preparations (time beginning); Stanza 3: "fiz; ekSu, laxhr Hkjk" (time as a fleeting art); Final stanza: "gks x;k C;kg" (time completed). The proverb "csVh cpkvks, csVh i<+kvks" encodes the cycle.
- Step 5: Relate to primary theme — The father's grief is acute because time is irreversible; its universality (cyclical nature) makes it bearable only through ritual. The secondary theme frames the primary theme as both personal tragedy and shared human condition.
REASONING: This 5-step method moves from textual markers to abstract idea to structural function, ensuring the theme is grounded in evidence and connected to the poem's core.
ANSWER: Secondary theme: Time as irreversible yet cyclical. Evidence: Opening wedding morning vs. closing departure; "vkdk'k cny dj cuk egh" (wish to reverse) vs. "nq[k gh thou dh dFkk jgh" (acceptance of narrative). Relationship: Makes father's grief both unique (his moment) and universal (every father's moment).

## WORKED_EXAMPLE_2
PROBLEM: The poem references the mother through visual imagery ("csVh osQ :i jax esa iRuh dk :i jax fn[kkbZ iM+rk gS") but gives her no dialogue. Analyze how this silence functions as a secondary theme of "gendered emotional labor."
STEPS:
- Step 1: Note the mother's sole appearance — visual, not verbal. She is seen in the daughter's form ("iRuh dk :i jax"), suggesting she lives on through the daughter.
- Step 2: Contrast with the father — he speaks, remembers, pleads ("vkdk'k cny dj cuk egh"), his grief is articulate and central. The mother's grief is implied, not expressed.
- Step 3: Identify the recurring subject — silence/performance of gender roles. The mother "jgs U;Lr" (stays composed) while the father breaks down.
- Step 4: Articulate the implied idea — Women's grief is domesticated, channeled into continuity (she becomes the daughter's reflection); men's grief is permitted public articulation. The custom "csVh cpkvks" demands this division.
- Step 5: Connect to primary theme — The father's primary grief is visible because the mother's invisible labor (emotional, ritual) holds the space for it. Her silence is not absence; it is structural support.
- Step 6: Verify with text — "Hkj tyn ekjk dks T;ksa vikj" (apply oil to hair, make her ready) — mother prepares the bride; "os gh lq[k-nq[k esa jgs U;Lr" (they stay composed in joy/sorrow) — explicit gendered expectation.
REASONING: This analysis uses character contrast (from node 004/005), textual silence as evidence, and social context (from node 001) to elevate a textual gap into a thematic statement.
ANSWER: Secondary theme: Gendered emotional labor — the mother's performed composure and visual continuity enable the father's articulated grief. Her silence is the poem's structural counterweight.

## WORKED_EXAMPLE_3
PROBLEM: Synthesize three secondary themes (custom as double-edged, gendered emotional labor, time as irreversible/cyclical) to explain how they collectively transform the vidai from a personal family moment into a cultural commentary.
STEPS:
- Step 1: Map each secondary theme to a structural element — Custom: the proverb "csVh cpkvks, csVh i<+kvks" (frame); Gendered labor: mother's silence vs. father's speech (character dynamic); Time: morning-to-evening arc (temporal structure).
- Step 2: Show how each theme critiques/extends the primary theme — Custom: makes grief obligatory, not just personal; Gendered labor: reveals grief's unequal distribution; Time: situates grief in an endless chain.
- Step 3: Identify the convergence point — The father's final couplet: "nq[k gh thou dh dFkk jgh, D;k dgw¡ vkt tks ugha dgh" — he recognizes his story is the old story.
- Step 4: Analyze the commentary — The poem does not reject custom (the father performs it: "bl iFk ij, esjs dk;Z ldy gksa") but exposes its human cost. The cultural commentary is implicit: rituals sustain society by channeling individual pain into collective forms.
- Step 5: Check against NCERT Q6 — "eq> HkkX;ghu dh rw lacy fujkyk dh ;g iafDr D;k ^csVh cpkvks] csVh i<+kvks* tSls dk;ZØe dh ek¡x djrh gS" — yes, the poem enacts the very process it describes.
- Step 6: Formulate the synthesized insight — Secondary themes are not decorative; they are the poem's argument about how culture manages emotion. The personal becomes political through thematic layering.
REASONING: Synthesis requires holding multiple thematic threads simultaneously and showing their structural interdependence — the highest analytical skill for board and competitive exams.
ANSWER: The three secondary themes interlock: custom provides the script, gendered labor divides the performance, time ensures the replay. Together, they reveal vidai as a cultural technology for processing separation — the poem's commentary on tradition's emotional economy.

## COMPETENCY_QUESTION_1
QUESTION: A Class 12 student writes in a board exam answer: "The secondary themes of the poem are mother, time, and custom." The examiner awards 1 out of 3 marks. Using the subject vs. theme distinction, rewrite the answer to earn full marks, citing one line per theme.
COMPETENCY: Conceptual clarity and exam answer structuring (CBSE marking scheme alignment)
STEPS:
- Step 1: Identify the error — the student listed subjects, not themes.
- Step 2: Convert each subject to a theme statement with implied idea.
- Step 3: Select one precise textual reference per theme (not whole stanzas).
- Step 4: Structure each point as: Theme statement → Evidence → Link to primary theme.
ANSWER: 
1. Secondary theme: Gendered emotional labor — the mother's silent composure ("os gh lq[k-nq[k esa jgs U;Lr") contrasts with the father's vocal grief, revealing how ritual allocates emotional expression by gender. This deepens the primary theme by showing the father's grief is enabled by the mother's invisible labor.
2. Secondary theme: Time as irreversible yet cyclical — the arc from "ns[kk fookg" to "gks x;k C;kg" and the plea "vkdk'k cny dj cuk egh" frame the vidai as both unique rupture and generational recurrence ("nq[k gh thou dh dFkk jgh"). This universalizes the primary theme.
3. Secondary theme: Custom as both shelter and cage — the proverb "csVh cpkvks, csVh i<+kvks" encodes society's dual demand: marry daughters (shelter) and educate them (cage of expectation). The father's compliance ("bl iFk ij, esjs dk;Z ldy gksa") shows custom's coercive comfort. This contextualizes the primary theme socially.
DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: In a JEE-style assertion-reason question:
Assertion (A): In "Lajja ka Lekh," the secondary theme of time's cyclical nature is conveyed more through the poem's structural arc than through explicit statements.
Reason (R): The poem opens with a wedding morning and closes with the departure's finality, while the only direct time reference ("fiz; ekSu, laxhr Hkjk") appears mid-poem as a metaphor.
Choose the correct option and justify using textual evidence.
A) Both A and R are true, and R correctly explains A.
B) Both A and R are true, but R does not explain A.
C) A is true, R is false.
D) A is false, R is true.
COMPETENCY: Critical evaluation of thematic technique (competitive exam pattern)
STEPS:
- Step 1: Verify A — Is cyclical time conveyed structurally? Yes: morning→evening arc + generational proverb = structural cyclicality.
- Step 2: Verify R — Is the only direct time reference mid-poem as metaphor? Check text: "fiz; dh v'kCn" (stanza 2), "fiz; ekSu, laxhr Hkjk" (stanza 3), "nq[k gh thou dh dFkk jgh" (final stanza) — multiple time references, not just one. R is false.
- Step 3: Select option — A is true, R is false → Option C.
- Step 4: Justify — The poem uses multiple time markers (not just one), and structural arc is primary but not exclusive conveyor.
ANSWER: Option C. A is true: the morning-to-departure arc and the generational proverb structurally encode cyclical time. R is false: time references appear in at least three stanzas (e.g., "fiz; dh v'kCn", "fiz; ekSu, laxhr Hkjk", "nq[k gh thou dh dFkk jgh"), not just one mid-poem metaphor.
DIFFICULTY: hard