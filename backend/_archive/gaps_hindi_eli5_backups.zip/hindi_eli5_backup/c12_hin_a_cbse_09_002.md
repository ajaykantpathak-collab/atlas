## DEFINITION
Plot and narrative structure in poetry refers to the organized sequence of events, conflicts, and resolutions that give a narrative poem its story-like progression, including exposition, rising action, climax, falling action, and denouement, often conveyed through stanzas, speaker shifts, and temporal markers.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student can independently map the narrative arc of a poem by identifying its structural components (exposition, conflict, climax, resolution), explain how stanza organization and speaker perspective advance the plot, and justify their analysis with textual evidence.

## SCOPE_BOUNDARY
This node covers narrative structure analysis of the two poems by Kukuan in Chapter 9 (Antra). It does not cover lyrical poems without a story, nor does it address poetic devices like rhyme or meter in isolation — those are handled in Literary Devices nodes.

## WALKTHROUGH
Imagine you are listening to a friend recount a dramatic incident — they don't just blurt the ending; they set the scene, build tension, reach a turning point, and then resolve it. Narrative poems work the same way. Start by reading the first poem aloud and asking: "What situation is introduced in the opening lines? What desire or problem does the speaker express? How does the middle section intensify that longing? Where does the emotional peak occur? How does the final stanza resolve or leave the tension?" Then do the same for the second poem, noting its dialogue form. The key insight: even in verse, a story has a skeleton — find it, and the poem's meaning becomes structural, not just emotional.

## DIAGNOSTIC_QUESTION_1
What are the five standard stages of a narrative arc, and which stage typically contains the poem's turning point?

## DIAGNOSTIC_ANSWER_1
The five stages are exposition, rising action, climax, falling action, and denouement. The climax is the turning point where tension peaks. A wrong answer (e.g., listing "beginning, middle, end" or placing the turning point in the exposition) reveals the student is recalling a vague three-part model instead of the precise five-stage framework needed for board-level analysis.

## DIAGNOSTIC_QUESTION_2
In the first poem of Chapter 9, the speaker describes waiting for a beloved over many days. Explain how the progression from "vofèk vklikl ijs" (long nights passing) to "pkgr pyu ;s lanslks ys lqtku dks" (asking the beloved to wear the necklace) shows rising action rather than exposition.

## DIAGNOSTIC_ANSWER_2
The opening lines establish the duration and pain of waiting (exposition). The shift to a direct plea for the beloved to adorn herself signals an escalation — the speaker moves from passive endurance to active urging, marking rising action. If a student calls this the climax, they confuse emotional intensity with structural peak; the climax would be the moment of union or final rejection, which this poem withholds.

## DIAGNOSTIC_QUESTION_3
The second poem is structured as a dialogue between two voices. Identify which voice speaks the lines "vkukdkuh vkjlh fugkfjcks djkSxs dkSykSa" and which responds with "ekSu gw lkSa nsf[kgkSa fdrsd iu ikfygkS tw". Then explain how this alternating structure creates narrative tension.

## DIAGNOSTIC_ANSWER_3
The first line is a challenge spoken by a skeptical observer (voice A); the response is the defender's reply (voice B). The alternation creates tension by juxtaposing doubt and faith without a narrator's mediation. A student who assigns both to the same speaker misses the dramatic conflict essential to the poem's narrative structure.

## DIAGNOSTIC_QUESTION_4
Compare the narrative structures of the two poems: one uses a single speaker's monologue across time, the other uses immediate dialogue. Which structural choice better conveys unresolved longing, and why?

## DIAGNOSTIC_ANSWER_4
The monologue structure (first poem) better conveys unresolved longing because its linear, unbroken flow mirrors the endless passage of time ("cgqr fnuku") and the speaker's solitary fixation. The dialogue poem resolves tension through exchange. A student who prefers the dialogue for longing confuses dramatic conflict with sustained interiority.

## DIAGNOSTIC_QUESTION_5
A classmate argues that the first poem has no climax because the beloved never appears. Evaluate this claim using the concept of structural climax in open-ended narratives.

## DIAGNOSTIC_ANSWER_5
The claim is incorrect. The climax in an open-ended narrative can be the moment of maximum emotional intensity — here, the speaker's desperate plea "pkgr pyu ;s lanslks ys lqtku dks" — even without external resolution. The structural climax is internal. A student who agrees with the classmate equates climax only with plot resolution, ignoring psychological peaks.

## DIAGNOSTIC_QUESTION_6
Write a four-line stanza that could serve as a falling action for the first poem, assuming the beloved finally arrives but remains silent. Use the same meter and vocabulary register as the poem.

## DIAGNOSTIC_ANSWER_6
Example: "aue ys vkxs cgqr fnuksa ds ckn / euHkkou dk uke ugha lquk tkrs / lq[k ys vkxs vkdkj ds nq?kZVksa esa / lanslks yxh jgrh gS nq[khA" A good answer maintains the Braj-inflected register, references prior motifs (necklace, waiting), and shows the speaker's continued yearning despite presence. A poor answer introduces modern Hindi or resolves the tension completely, violating the poem's sustained ambiguity.

## COMMON_MISCONCEPTION
Students often treat "plot" in poetry as a simple summary of what happens, ignoring how stanza breaks, line enjambment, and speaker shifts *structure* the narrative. For example, they write "The poet waits for his lover" as the plot of the first poem, missing that the *structural choice* to stretch the waiting across multiple stanzas with incremental imagery (nights → days → necklace) *is* the plot's architecture. This error costs marks in board questions asking "How does the poet build narrative tension?" because the answer requires analyzing form, not just content.

## ON_FAILURE
1. Have the student re-read the first poem and physically mark each stanza with a label: E (exposition), R (rising), C (climax), F (falling), D (denouement). 2. Ask them to justify each label with one line reference. 3. If they cannot distinguish rising from climax, give a mini-lesson using a familiar Hindi film song with clear narrative stages (e.g., "Tujhse Naraz Nahi Zindagi") and map its structure together. 4. Re-assess by having them analyze the second poem's dialogue turns as structural beats.

## BUILDS_ON
Class 11 skill of identifying narrative sequence in prose stories (c11_hin_ar_cbse_01_002) extended to verse form.

## LEADS_TO
Character Analysis: Protagonist (c12_hin_a_cbse_09_004) where the speaker's structural choices reveal personality.

## PREREQUISITE_NODE_IDS
c11_hin_ar_cbse_01_002, c11_hin_ar_cbse_02_002, c11_hin_ar_cbse_03_002, c11_hin_ar_cbse_04_002, c11_hin_ar_cbse_05_002, c11_hin_ar_cbse_06_002, c11_hin_ar_cbse_07_002, c11_hin_ar_cbse_08_002, c11_hin_ar_cbse_09_002, c11_hin_ar_cbse_10_002, c11_hin_ar_cbse_11_002, c11_hin_ar_cbse_12_002, c11_hin_ar_cbse_13_002, c11_hin_ar_cbse_14_002, c11_hin_ar_cbse_15_002, c11_hin_ar_cbse_16_002, c11_hin_v_cbse_01_002, c11_hin_v_cbse_02_002, c11_hin_v_cbse_03_002, c11_hin_v_cbse_04_002, c11_hin_v_cbse_05_002, c12_hin_a_cbse_09_001
## PREREQUISITE_REASONS
c11_hin_ar_cbse_01_002: Class 11 introduced narrative arc terminology (exposition, climax, etc.) in prose; this node transfers that to poetry.
c11_hin_ar_cbse_02_002: Reinforced structural analysis across multiple texts.
c11_hin_ar_cbse_03_002: Practiced identifying turning points in Class 11 stories.
c11_hin_ar_cbse_04_002: Linked narrative structure to character motivation.
c11_hin_ar_cbse_05_002: Showed how supporting characters create subplots.
c11_hin_ar_cbse_06_002: Connected structure to theme development.
c11_hin_ar_cbse_07_002: Explored secondary themes through structural parallels.
c11_hin_ar_cbse_08_002: Introduced imagery as structural markers.
c11_hin_ar_cbse_09_002: Taught irony/symbolism as structural devices.
c11_hin_ar_cbse_10_002: Built vocabulary for discussing narrative techniques.
c11_hin_ar_cbse_11_002: Covered grammar of narrative tense/aspect.
c11_hin_ar_cbse_12_002: Practiced literal/inferential questions on structure.
c11_hin_ar_cbse_13_002: Developed critical interpretation of structural choices.
c11_hin_ar_cbse_14_002: Wrote structured analyses of narrative.
c11_hin_ar_cbse_15_002: Discussed narrative structure orally.
c11_hin_ar_cbse_16_002: Consolidated narrative analysis across genres.
c11_hin_v_cbse_01_002: Vitan chapter 1 narrative structure practice.
c11_hin_v_cbse_02_002: Vitan chapter 2 narrative structure practice.
c11_hin_v_cbse_03_002: Vitan chapter 3 narrative structure practice.
c11_hin_v_cbse_04_002: Vitan chapter 4 narrative structure practice.
c11_hin_v_cbse_05_002: Vitan chapter 5 narrative structure practice.
c12_hin_a_cbse_09_001: Provides historical/biographical context for Kukuan's narrative voice.

## FORWARD_NODE_IDS
c12_hin_a_cbse_09_003, c12_hin_a_cbse_09_004, c12_hin_a_cbse_09_005, c12_hin_a_cbse_09_006, c12_hin_a_cbse_09_007, c12_hin_a_cbse_09_008, c12_hin_a_cbse_09_009, c12_hin_a_cbse_09_012, c12_hin_a_cbse_09_013, c12_hin_a_cbse_09_010, c12_hin_a_cbse_09_014, c12_hin_a_cbse_09_015

## FORWARD_REASONS
c12_hin_a_cbse_09_003: Setting details (time/place markers) are structural elements identified here.
c12_hin_a_cbse_09_004: The protagonist (speaker) is revealed through narrative choices mapped in this node.
c12_hin_a_cbse_09_005: Supporting voices (e.g., the second poem's interlocutor) are structural functions.
c12_hin_a_cbse_09_006: Primary theme (longing/devotion) unfolds through the narrative arc analyzed here.
c12_hin_a_cbse_09_007: Secondary themes (faith vs doubt) are structured by the dialogue form.
c12_hin_a_cbse_09_008: Imagery clusters (necklace, night, fire) serve as structural signposts.
c12_hin_a_cbse_09_009: Irony (unanswered plea) and symbolism (necklace) operate at structural turning points.
c12_hin_a_cbse_09_012: Comprehension questions require structural awareness to infer unstated events.
c12_hin_a_cbse_09_013: Critical interpretation depends on evaluating structural effectiveness.
c12_hin_a_cbse_09_010: अगला तार्किक चरण: Vocabulary in Context: इस नोड की अवधारणाओं को सीधे उपयोग/विस्तारित करता है।  
c12_hin_a_cbse_09_014: Plot/narrative structure of the dohas provides the sequence for evidence selection  
c12_hin_a_cbse_09_015: Narrative structure of the doha pair (progression from metaphor 1 to metaphor 2) is the backbone of comparative discussion.  

## CROSS_SUBJECT_PREREQS
c11_hin_ar_cbse_01_002, c11_hin_ar_cbse_02_002, c11_hin_ar_cbse_03_002, c11_hin_ar_cbse_04_002, c11_hin_ar_cbse_05_002, c11_hin_ar_cbse_06_002, c11_hin_ar_cbse_07_002, c11_hin_ar_cbse_08_002, c11_hin_ar_cbse_09_002, c11_hin_ar_cbse_10_002, c11_hin_ar_cbse_11_002, c11_hin_ar_cbse_12_002, c11_hin_ar_cbse_13_002, c11_hin_ar_cbse_14_002, c11_hin_ar_cbse_15_002, c11_hin_ar_cbse_16_002, c11_hin_v_cbse_01_002, c11_hin_v_cbse_02_002, c11_hin_v_cbse_03_002, c11_hin_v_cbse_04_002, c11_hin_v_cbse_05_002
## CROSS_SUBJECT_REASONS
c11_hin_ar_cbse_01_002: Narrative structure concepts learned in Class 11 Hindi Aroh are directly applied here.
c11_hin_ar_cbse_02_002: Reinforcement of structural analysis across multiple Class 11 texts.
c11_hin_ar_cbse_03_002: Practice in identifying turning points transfers to poetry.
c11_hin_ar_cbse_04_002: Character motivation revealed through structure.
c11_hin_ar_cbse_05_002: Subplot and supporting character structural roles.
c11_hin_ar_cbse_06_002: Theme development through narrative progression.
c11_hin_ar_cbse_07_002: Secondary themes via structural parallels.
c11_hin_ar_cbse_08_002: Imagery as structural markers.
c11_hin_ar_cbse_09_002: Irony/symbolism at structural junctures.
c11_hin_ar_cbse_10_002: Vocabulary for narrative techniques.
c11_hin_ar_cbse_11_002: Grammar of narrative tense/aspect.
c11_hin_ar_cbse_12_002: Literal/inferential questions on structure.
c11_hin_ar_cbse_13_002: Critical interpretation of structural choices.
c11_hin_ar_cbse_14_002: Writing structured analyses.
c11_hin_ar_cbse_15_002: Oral discussion of narrative structure.
c11_hin_ar_cbse_16_002: Consolidation across genres.
c11_hin_v_cbse_01_002: Vitan narrative structure practice.
c11_hin_v_cbse_02_002: Vitan narrative structure practice.
c11_hin_v_cbse_03_002: Vitan narrative structure practice.
c11_hin_v_cbse_04_002: Vitan narrative structure practice.
c11_hin_v_cbse_05_002: Vitan narrative structure practice.

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_01_002 -> c12_hin_a_cbse_09_002 -> c12_hin_a_cbse_09_004

## THIS_FORMULA
Narrative Arc = Exposition (Stanza 1) + Rising Action (Stanzas 2–n-1) + Climax (Peak Emotional/Action Stanza) + Falling Action (Post-Climax Shift) + Denouement (Final Stanza/Closure)

## FORMULA_VARIABLES
Exposition: Opening situation, speaker, desire/problem; Rising Action: Escalation through repetition, imagery intensification, time progression; Climax: Structural peak — direct address, imperative, or revelation; Falling Action: Shift in tone, acceptance, or unresolved tension; Denouement: Final image/line leaving resonance.

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
analytical

## CROSS_SUBJECT
N/A | The narrative structure of Kukuan's poems reflects the Bhakti tradition's use of viraha (separation) as a spiritual narrative arc, where the devotee's longing for God mirrors the structural progression from yearning to surrender.
 N/A | The speaker's construction of self through narrative waiting in the first poem illustrates how individuals use story structure to organize emotional experience, a concept studied in narrative psychology.
## PREREQ_CONCEPT
Ability to segment a text into narrative stages (exposition, rising action, climax, falling action, denouement) learned in Class 11 prose analysis.

## PREREQ_BEFORE
Student must recall the five-stage narrative arc and have practiced mapping it onto at least two Class 11 stories.

## PREREQ_STUCK
Review the narrative arc mapping exercise from Class 11 Chapter 1 (c11_hin_ar_cbse_01_002) where you labeled each paragraph of a story with its structural stage.

## WORKED_EXAMPLE_1
PROBLEM: Analyze the narrative structure of the first poem in Chapter 9 by mapping each stanza to the five-stage arc and justifying the climax placement.
STEPS:
- Step 1: Read the poem silently, then aloud, noting the number of stanzas and the progression of time markers (e.g., "cgqr fnuku" → "vofèk vklikl ijs" → "dfg dfg vkou" → "xfg xfg jk[kfr").
- Step 2: Identify the exposition: Stanza 1 establishes the speaker's prolonged waiting ("cgqr fnuku dks vofèk vklikl ijs") and the beloved's absence.
- Step 3: Trace rising action: Stanza 2 intensifies the sensory pain ("dfg dfg vkou Nchys euHkkou dks") and introduces the necklace as a symbol of desired union ("pkgr pyu ;s lanslks ys lqtku dks").
- Step 4: Locate the climax: The direct imperative "pkgr pyu ;s lanslks ys lqtku dks" is the emotional peak where passive waiting becomes active demand — the turning point of the speaker's agency.
- Step 5: Check for falling action/denouement: The poem ends on the imperative without resolution; the lack of a response stanza serves as an open denouement, sustaining longing.
REASONING: This step-by-step mapping forces the student to move beyond summary ("he waits for her") to structural analysis ("the poet uses imperative mood in the penultimate stanza to mark the climax"). The absence of a resolution stanza is itself a structural choice meaningful for board answers.
ANSWER: The poem follows a compressed arc: Stanza 1 = Exposition (waiting introduced), Stanza 2 = Rising Action (sensory details, time compression), Stanza 3 (implied by the imperative line) = Climax (speaker demands action), No explicit Falling Action/Denouement = Open ending that structurally enacts endless viraha.

## WORKED_EXAMPLE_2
PROBLEM: The second poem uses a dialogue structure. Identify the narrative function of each speech turn and explain how the alternation creates a mini-plot within a single stanza.
STEPS:
- Step 1: Separate the two voices: Voice A (skeptic) speaks lines 1–2 ("vkukdkuh vkjlh fugkfjcks djkSxs dkSykSa / dgk eks pfdr nlk R;ksa u nhfB MksfygS"), Voice B (believer) replies lines 3–4 ("ekSu gw lkSa nsf[kgkSa fdrsd iu ikfygkS tw / owQdHkjh ewdrk cqyk; vki cksfygSA").
- Step 2: Label Voice A's turn as Exposition + Conflict: the skeptic questions the possibility of divine vision ("Who has seen the invisible?").
- Step 3: Label Voice B's turn as Rising Action + Climax: the believer counters with personal experience ("I have seen...") and redefines the terms ("owQdHkjh ewdrk" — the difficulty is the test).
- Step 4: Note the final couplet (lines 5–6) as a shared Denouement: both voices converge on the inevitability of the outcome ("#bZ fn, jgkSxs dgk¡ ykS cgjk;cs dh / dcgw¡ rkS esfj;S iqdkj dku [kksfy gSA").
- Step 5: Explain the effect: The dialogue compresses a full debate (doubt → faith → acceptance) into six lines, making the narrative structure itself an argument for faith's immediacy.
REASONING: Students often miss that dialogue poems have a plot. By assigning structural roles to each speech turn, they see how Kukuan uses dramatic form to narrate a spiritual conflict resolution.
ANSWER: The dialogue enacts a micro-narrative: Skeptic's challenge (exposition/conflict) → Believer's testimony (rising action/climax) → Joint acknowledgment of inevitable grace (denouement). The structure *is* the argument.

## WORKED_EXAMPLE_3
PROBLEM: Compare the narrative pacing of the two poems. The first stretches waiting across indeterminate time; the second resolves a theological debate in six lines. How does each poem's structural pacing serve its thematic purpose?
STEPS:
- Step 1: Define pacing in narrative poetry: the speed at which structural stages unfold, controlled by stanza length, line density, and temporal markers.
- Step 2: Analyze Poem 1's pacing: Slow, expansive. "cgqr fnuku" (many days), "vofèk vklikl ijs" (long nights passed) — the syntax drags, mirroring the drag of viraha. The climax arrives only after this temporal accumulation.
- Step 3: Analyze Poem 2's pacing: Rapid, dialectical. Each couplet is a complete exchange; the conflict-climax-resolution cycle occurs in three speech pairs. No temporal markers — it's an eternal present of debate.
- Step 4: Link to theme: Poem 1's slow pacing *embodies* the theme of painful separation (viraha). Poem 2's swift pacing *enacts* the theme of instant recognition (anubhuti) — faith doesn't wait.
- Step 5: Synthesize for a board-style answer: "Kukuan manipulates narrative pacing as a thematic device: the first poem's elongated rising action mimics the devotee's prolonged separation, while the second poem's compressed dialogue structure enacts the suddenness of divine revelation."
- Step 6: Check against marking scheme: This answer names the device (pacing), quotes evidence ("cgqr fnuku" vs six-line dialogue), explains mechanism (syntax drag vs dialectical speed), and connects to theme (viraha vs anubhuti) — hitting all four PEEL criteria.
REASONING: This multi-step comparison demonstrates the Class 12 expectation of inter-textual structural analysis within a single chapter, a frequent board competency question pattern.
ANSWER: Poem 1 uses dilated pacing (expanded rising action, delayed climax) to structurally enact viraha's duration. Poem 2 uses accelerated pacing (immediate conflict, rapid climax, shared denouement) to structurally enact anubhuti's immediacy. Both are deliberate narrative choices, not mere stylistic differences.

## COMPETENCY_QUESTION_1
QUESTION: A board exam asks: "How does the narrative structure of the first poem reflect the Bhakti concept of viraha (separation)?" Write a structured response using the PEEL method (Point, Evidence, Explanation, Link).
COMPETENCY: Literary analysis with textual evidence and thematic linking
STEPS:
- Step 1: State the Point: The poem's open-ended narrative structure — specifically its missing denouement — mirrors the Bhakti idea that viraha is a perpetual, purifying state, not a problem to be solved.
- Step 2: Provide Evidence: Quote the final imperative "pkgr pyu ;s lanslks ys lqtku dks" and note the absence of a response stanza.
- Step 3: Explain: The structural refusal to grant resolution forces the reader into the speaker's endless waiting, making the form itself a devotional practice.
- Step 4: Link: This aligns with Kukuan's described philosophy where "izse dk vR;ar xaHkhj" (intense love for the beloved) is the goal, not union.
ANSWER: The poem's narrative structure enacts viraha by withholding denouement. The climax (speaker's plea) is not followed by union or rejection, leaving the narrative suspended in longing. This structural choice reflects the Bhakti tenet that separation intensifies devotion — the poem *performs* what it describes.
DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: In a JEE-style assertion-reason question: Assertion (A): The dialogue form of the second poem creates a more dynamic narrative structure than the monologue of the first poem. Reason (R): Dialogue inherently contains conflict, while monologue only expresses emotion. Choose the correct option: (a) Both A and R are true and R correctly explains A. (b) Both A and R are true but R does not explain A. (c) A is true but R is false. (d) A is false but R is true.
COMPETENCY: Critical evaluation of literary form and reasoning
STEPS:
- Step 1: Evaluate Assertion: Is the dialogue "more dynamic"? Dynamism depends on structural movement. The dialogue compresses conflict-climax-resolution rapidly; the monologue elongates rising action. Both are dynamic in different ways — A is an oversimplification.
- Step 2: Evaluate Reason: Does monologue "only express emotion"? No — the first poem's monologue has a clear narrative arc (exposition to climax). R is false.
- Step 3: Determine option: A is debatable (subjective), R is false → Option (c) if A is considered true in a limited sense, but best answer is (d) A is false (dialogue isn't inherently more dynamic) and R is false. However, typical exam keys treat such comparative claims as false when they ignore nuance.
- Step 4: Select (d) with justification: Both poems have dynamic structures suited to their themes; monologue can be highly dynamic through internal conflict.
ANSWER: (d) A is false but R is true? Wait — R is also false. Actually, the correct choice is (c) if the exam considers dialogue more dynamic, but R is false because monologue does more than express emotion. The most defensible answer is (c) A is true (dialogue has external conflict = more dynamic) but R is false (monologue also has narrative structure). We'll go with (c) as per typical CBSE competitive pattern where "dynamic" = external conflict.
DIFFICULTY: hard