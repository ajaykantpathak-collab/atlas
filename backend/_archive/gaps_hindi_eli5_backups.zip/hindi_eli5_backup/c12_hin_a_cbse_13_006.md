## DEFINITION
The primary theme of a literary work is its central, unifying idea or insight about human experience that the author conveys through the narrative; the message is the specific perspective or lesson the author intends the reader to derive from that theme.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student can articulate the primary theme of "Hkh'e lkguh" in a precise thematic statement (not a plot summary), support it with at least three distinct pieces of textual evidence spanning plot, character, and setting, and explain how the author's narrative choices convey the intended message about human resilience amid historical upheaval.

## SCOPE_BOUNDARY
This node covers identifying and analyzing the **primary theme and message** of the specific story "Hkh'e lkguh" (Chapter 13, Antra). It does NOT cover secondary themes (node 007), literary devices (nodes 008-009), or grammar/vocabulary (nodes 010-011). It assumes familiarity with plot, setting, and character analyses (nodes 002-005).

## WALKTHROUGH
Imagine you are asked in the board exam: "What is the central message of 'Hkh'e lkguh'?" Don't start by retelling the story. Instead, ask yourself: "What big idea about life does this story keep returning to?" First, list the major conflicts: the narrator's nostalgic return, xkaèkh's quiet endurance, the farmer's sacrifice, the partition refugee's shared pain. Next, look for the **pattern** connecting them — each character faces loss but responds with dignity and connection. Then, check the ending: the narrator's unresolved departure and xkaèkh's continuing journey suggest the message is not "everything gets fixed" but "human bonds endure despite history's ruptures." Finally, phrase your theme as a complete sentence: "The story shows that ordinary human empathy and shared memory sustain people when historical forces like Partition shatter their world."

## DIAGNOSTIC_QUESTION_1
Define "theme" in literature and explain how it differs from "plot" in one sentence each.

## DIAGNOSTIC_ANSWER_1
Theme is the underlying universal idea or insight about human experience (e.g., "love endures beyond death"); plot is the sequence of events that happen in the story (e.g., "a man visits his village and meets an old friend"). A wrong answer that describes plot events as theme reveals the student cannot distinguish between *what happens* and *what it means* — a critical error that loses 2+ marks in board exams where "theme" questions require analytical statements, not narration.

## DIAGNOSTIC_QUESTION_2
A student writes: "The theme of 'Hkh'e lkguh' is Partition." Why is this answer incomplete? Rewrite it as a correct thematic statement.

## DIAGNOSTIC_ANSWER_2
"Partition" is a historical backdrop, not a theme. A theme must express an *insight* about that backdrop. Correct version: "The story explores how Partition's violence fractures communities yet cannot erase the fundamental human need for connection and empathy." A student who only names the historical event shows they confuse **subject** with **theme** — a common Class 12 error that leads to superficial answers in both board and CUET questions.

## DIAGNOSTIC_QUESTION_3
In the scene where xkaèkh tends to the sick old man (the #X.k O;fDr) daily, which primary theme does this illustrate? Quote one specific action from the text that supports your choice.

## DIAGNOSTIC_ANSWER_3
This illustrates the theme: **"Quiet, consistent caregiving sustains dignity in the face of abandonment."** Evidence: xkaèkh visits daily, inquires about his health, and speaks to him in gentle Hkk"kk (xkaèkh th mlosQ ikl tkrs vkSj mlosQ LokLF; osQ ckjs esa iwNrkN djrsA mudk okrkZyki xqtjkrh Hkk"kk esa gqvk djrkA). A wrong answer citing "xkaèkh is kind" stays at character trait level; the theme requires linking the action to a universal human pattern shown by the author.

## DIAGNOSTIC_QUESTION_4
Compare the narrator's relationship with xkaèkh (childhood friend) and with ;kLlsj vjkI+kQkr (Partition refugee). How do **both** relationships develop the same primary theme? Use one similarity and one difference in your analysis.

## DIAGNOSTIC_ANSWER_4
**Similarity:** Both relationships are built on **shared past and empathetic listening** — the narrator walks with xkaèkh recalling village memories; with vjkI+kQkr, he listens to Partition trauma (vjkI+kQkr gesa iQy Nhy&Nhydj f[kyk jgs FksA). **Difference:** The first is rooted in **nostalgic continuity** (same village, same language), the second in **rupture and displacement** (new city, broken past). Together they show the theme: **"Human connection persists across both continuity and catastrophic change."** A student who only describes the friendships separately misses the comparative synthesis that board "analyze" questions demand.

## DIAGNOSTIC_QUESTION_5
Evaluate this claim: "The farmer's (ck”khxj) subplot is a distraction from the main story; the author should have focused only on xkaèkh and the narrator." Defend or refute using the primary theme.

## DIAGNOSTIC_ANSWER_5
**Refute.** The farmer's sacrifice — carrying his mother, risking his life, finally giving his own flesh — is a **thematic parallel** to xkaèkh's quiet endurance and vjkI+kQkr's resilience. All three embody the message: **"Love expresses itself through self-giving action when words fail."** Removing the subplot would narrow the theme to "friendship survives Partition" instead of the broader "humanity survives inhumanity." A student who calls it a distraction fails to see **structural thematics** — a skill tested in JEE-style comprehension passages where every element serves the central idea.

## DIAGNOSTIC_QUESTION_6
Write a 50-word thematic statement for "Hkh'e lkguh" that a Class 12 topper would use in a board exam answer. It must include: (a) the core theme, (b) one historical context, (c) one literary technique the author uses.

## DIAGNOSTIC_ANSWER_6
**Model answer:** "Through the lens of a nostalgic homecoming shattered by Partition's memory, Hkh'e lkguh reveals that **ordinary acts of caregiving — xkaèkh tending a dying stranger, a farmer feeding his mother his own flesh — become radical resistance against historical dehumanization**; the author uses **parallel narratives** to universalize this quiet heroism." A poor answer omits the technique or stays vague ("it's about Partition and kindness"), showing inability to integrate form and content — a key differentiator for 90+ scores.

## COMMON_MISCONCEPTION
**Misconception:** "The theme is just the moral of the story, like 'be kind' or 'Partition was bad.'"  
**Why it's wrong:** This reduces a complex literary theme to a slogan. The story does not *preach* kindness; it *portrays* kindness as a survival strategy in a world where state violence (Partition) and social neglect (the dying old man ignored by others) have stripped away institutional care. Students write slogans because they're taught "theme = moral" in middle school. In Class 12, theme = **author's insight into a human condition**, proved by textual patterns. The board marking scheme explicitly penalizes "moralizing" answers that ignore textual evidence.

## ON_FAILURE
If a student cannot move beyond plot summary or slogan themes:  
1. **Revisit plot node (c12_hin_a_cbse_13_002)** and list 5 key events. For each, ask: "What does this event *show* about how humans respond to loss?"  
2. **Re-read character nodes (004, 005)** focusing on xkaèkh's actions — not his traits. Write one sentence per action: "When xkaèkh does X, the author shows Y about human nature."  
3. **Do a 10-minute timed write:** "Complete this sentence: 'Hkh'e lkguh is a story about ______, and it suggests that ______.'" Share with peer/teacher for feedback on whether the blanks contain a universal insight + textual proof.

## BUILDS_ON
Builds on the ability to distinguish plot events from thematic patterns, developed in Class 11 theme nodes (e.g., c11_hin_ar_cbse_01_006).

## LEADS_TO
Enables analysis of secondary themes (node 007) and how literary devices (nodes 008-009) reinforce the primary theme.

## PREREQUISITE_NODE_IDS
c12_hin_a_cbse_13_001, c12_hin_a_cbse_13_002, c12_hin_a_cbse_13_003, c12_hin_a_cbse_13_004, c12_hin_a_cbse_13_005, c11_hin_ar_cbse_01_006
## PREREQUISITE_REASONS
c12_hin_a_cbse_13_001: Provides historical context (Partition, 1938 setting) essential to interpret the theme's historical dimension.  
c12_hin_a_cbse_13_002: Supplies the plot sequence; theme analysis requires tracing patterns across events.  
c12_hin_a_cbse_13_003: Setting (village vs. city, pre/post-Partition) shapes the theme of displacement vs. rootedness.  
c12_hin_a_cbse_13_004: Protagonist xkaèkh's characterization is the primary vehicle for the theme of quiet endurance.  
c12_hin_a_cbse_13_005: Supporting characters (vjkI+kQkr, ck”khxj) provide parallel thematic threads.  
c11_hin_ar_cbse_01_006: Class 11 foundation on theme identification/analysis; assumes prior practice.

## FORWARD_NODE_IDS
c12_hin_a_cbse_13_007, c12_hin_a_cbse_13_008, c12_hin_a_cbse_13_009, c12_hin_a_cbse_13_013, c12_hin_a_cbse_13_010, c12_hin_a_cbse_13_012, c12_hin_a_cbse_13_014, c12_hin_a_cbse_13_015

## FORWARD_REASONS
c12_hin_a_cbse_13_007: Secondary themes (nostalgia, language, memory) branch from the primary theme established here.  
c12_hin_a_cbse_13_008: Imagery/metaphor analysis requires knowing the theme they serve (e.g., "fI+kQfyLrhu" as metaphor for fractured self).  
c12_hin_a_cbse_13_009: Irony/symbolism (e.g., the farmer's flesh as symbol of sacrificial love) only make sense relative to the primary theme.  
c12_hin_a_cbse_13_013: Critical thinking questions (case-based, assertion-reason) directly test thematic interpretation skills built here.
c12_hin_a_cbse_13_010: Primary theme (patriotism) informs words like "joS;k".  
c12_hin_a_cbse_13_012: Primary theme (displacement, memory) frames the "why" behind character actions.  
c12_hin_a_cbse_13_014: Provides primary theme (patriotism/humanism) for the "Link" step in PEEL  
c12_hin_a_cbse_13_015: Theme identification (memory, partition, resistance) provides discussion foundation  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
No cross-subject prerequisite nodes provided in the prior class list; thematic analysis of Partition literature is primarily developed within Hindi curriculum.

## CHAIN_DESCRIPTION
c12_hin_a_cbse_13_002 -> c12_hin_a_cbse_13_006 -> c12_hin_a_cbse_13_007 (Plot understanding enables primary theme analysis, which enables secondary theme exploration).

## THIS_FORMULA
N/A - conceptual

## FORMULA_VARIABLES
N/A

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
conceptual

## CROSS_SUBJECT
N/A | The story's backdrop of the 1947 Partition and its human toll connects directly to Class 12 History's "Partition: The Making of the Indian Subcontinent" — both examine how macro-history shapes micro-lives.  
 N/A | The depiction of village community disintegration and refugee resettlement mirrors Sociology's "Social Change and Social Problems in India" (migration, dislocation, community resilience).
## PREREQ_CONCEPT
Ability to synthesize multiple textual details (plot points, character actions, setting details) into a single abstract statement about human experience.

## PREREQ_BEFORE
Student must have completed plot, setting, and character analyses for this chapter (nodes 002-005) and understand the historical fact of Partition.

## PREREQ_STUCK
If stuck, re-read the "v[kckj okyh ?kVuk" scene (farmer feeding mother his flesh) and xkaèkh's daily visits to the old man — these are the thematic anchors; ask: "What do these two scenes have in common about love and survival?"

## WORKED_EXAMPLE_1
PROBLEM: A board exam question asks: "Identify the primary theme of 'Hkh'e lkguh' and support it with two examples from the text." Write a structured answer following the PEEL method (Point, Evidence, Explanation, Link).

STEPS:
- Step 1: **Point** — State the theme as a complete insight sentence: "The primary theme is the enduring power of quiet, selfless caregiving to preserve human dignity amid historical catastrophe."
- Step 2: **Evidence 1** — Select xkaèkh's actions: "xkaèkh visits the dying #X.k O;fDr daily, speaks to him in gentle language, and stays until the end, despite having no obligation."
- Step 3: **Explanation 1** — Connect to theme: "This shows caregiving as a chosen moral act, not duty, highlighting agency in a world where Partition stripped away choices."
- Step 4: **Evidence 2** — Select the farmer's sacrifice: "The farmer (ck”khxj) carries his mother, then cuts his own flesh to feed her when lost in the forest."
- Step 5: **Explanation 2** — Connect to theme: "This extreme parallel elevates caregiving to sacrificial love, suggesting that when systems fail, individual bodies become sites of resistance."
- Step 6: **Link** — Conclude: "Together, these parallel narratives transform personal kindness into a collective survival strategy, which is the author's message."

REASONING: The PEEL structure ensures each claim is anchored in text (board requirement) and interpreted (analysis requirement). Using two distinct characters (xkaèkh and ck”khxj) proves the theme is structural, not incidental.

ANSWER: The primary theme of "Hkh'e lkguh" is the enduring power of quiet, selfless caregiving to preserve human dignity amid historical catastrophe. This is evident when xkaèkh voluntarily tends to a dying stranger daily, using gentle speech to offer dignity in abandonment — showing caregiving as moral agency in a choice-less world. Parallelly, the farmer ck”khxj's act of cutting his own flesh to feed his lost mother elevates care to sacrificial resistance. These parallel narratives suggest that when Partition destroys institutional and communal safety nets, individual acts of embodied love become the last defense of humanity.

## WORKED_EXAMPLE_2
PROBLEM: A CUET-style question: "How does the author use the **narrator's perspective** to reveal the primary theme? Answer in 60 words."

STEPS:
- Step 1: Identify narrator's role — he is the **frame narrator**, returning after years, observing xkaèkh and vjkI+kQkr.
- Step 2: Note his initial stance — nostalgic, detached observer ("eSa nsj jkr lsokxzke igq¡pkA").
- Step 3: Track his shift — he becomes emotionally implicated: "eSaus v[kckj ns[k gh jgk Fkk fd lhf<+;ksa ij fdlh osQ mrjus dh vkok”k vkbZA" (he witnesses the farmer's sacrifice viscerally).
- Step 4: Connect to theme — the narrator's journey from **observer to witness** mirrors the reader's journey from historical distance to empathetic engagement.
- Step 5: Draft answer — "The narrator begins as a nostalgic tourist but becomes a shaken witness to xkaèkh's quiet heroism and the farmer's bloody sacrifice. This shift forces the reader to move beyond 'Partition facts' to feel the theme: caregiving as radical resistance. The frame structure thus enacts the theme — empathy requires proximity."

REASONING: Competitive exams test **narrative technique's thematic function**, not just content. The 60-word limit demands conciseness: every word must carry analytical weight. The frame-narrator insight is a high-yield observation.

ANSWER: The narrator's arc from detached nostalgic visitor to visceral witness (of xkaèkh's daily vigil and the farmer's self-cannibalistic care) mirrors the reader's required shift from historical abstraction to empathetic proximity. This frame structure enacts the theme: caregiving becomes radical resistance only when witnessed intimately, not recalled distantly. The author thus uses narrative perspective to make the theme experiential, not merely intellectual.

## WORKED_EXAMPLE_3
PROBLEM: Synthesis task: "Compare the primary theme of 'Hkh'e lkguh' with that of the Class 11 story 'Usne Kaha Tha' (Chandradhar Sharma Guleri). Both deal with Partition-era trauma. Write a 100-word comparative thematic analysis."

STEPS:
- Step 1: Recall "Usne Kaha Tha" theme — **"Unspoken love and sacrifice transcend death and war; a promise kept beyond the grave."** (Lahna Singh dies fulfilling his vow to protect his beloved's husband).
- Step 2: Recall "Hkh'e lkguh" theme — **"Quiet, embodied caregiving sustains dignity when history destroys all structures."**
- Step 3: Find common ground — Both center **sacrificial love as response to violence** (war/Partition). Both use **bodily sacrifice** (Lahna Singh's death; farmer's flesh).
- Step 4: Find divergence — "Usne Kaha Tha" is **romantic-mythic** (promise to a woman, Sikh soldier ethos); "Hkh'e lkguh" is **domestic-realist** (mother-son, neighbor-stranger, no grand oaths).
- Step 5: Synthesize — "Guleri mythologizes sacrifice as eternal vow; lkguh democratizes it as daily, anonymous act. Both insist love outlives the politics that kills bodies."
- Step 6: Polish to 100 words — focus on thematic vocabulary: "mythic vs. quotidian," "vow vs. instinct," "transcendence vs. immanence."

REASONING: Comparative thematic analysis is a **high-order skill** appearing in CUET/IPMAT and board long-answer questions. It requires holding two texts' thematic cores simultaneously and evaluating authorial choices — not just listing similarities.

ANSWER: Both stories position sacrificial love as the sole bulwark against historical violence (WWI/Partition). Guleri's "Usne Kaha Tha" mythologizes this through Lahna Singh's death-bound vow — a romantic, transcendent promise that defies mortality. Lkguh's "Hkh'e lkguh" democratizes sacrifice into the farmer's instinctive self-cannibalism and xkaèkh's neighborly vigil — immanent, anonymous, bodily acts with no audience. Where Guleri elevates sacrifice to sacred oath, lkguh grounds it in the quotidian: a mother's hunger, a stranger's fever. Together they argue that **love's endurance is not in grand gestures but in the flesh-and-blood refusal to let dignity die** — whether on a battlefield or a village path.

## COMPETENCY_QUESTION_1
QUESTION: **Case-Based:** A student writes in the board exam: "The theme of 'Hkh'e lkguh' is that we should help others in need." The examiner awards 1/3 marks. Using the marking scheme logic, explain **why** this answer lost marks and rewrite it to earn full marks.

COMPETENCY: Critical evaluation of answer quality (metacognition) + thematic precision.

STEPS:
- Step 1: Identify the error — the answer states a **moral injunction** ("we should help"), not an **authorial insight** ("the story shows that...").
- Step 2: Note missing textual evidence — no reference to xkaèkh, farmer, or Partition context.
- Step 3: Note missing complexity — reduces a nuanced theme (caregiving as resistance to dehumanization) to a platitude.
- Step 4: Rewrite using PEEL — Point (theme statement), Evidence (two textual moments), Explanation (how they deepen theme), Link (author's message).

ANSWER: The answer lost marks because: (1) It confuses **theme** (what the story reveals) with **moral** (what we should do). Board rubrics require "author's insight into human condition," not preaching. (2) It provides **zero textual evidence** — 3-mark questions demand at least two specific references. (3) It ignores the **historical dimension** (Partition) which is central to the story's thematic weight.  
**Full-mark rewrite:** "The story reveals that in a world shattered by Partition, **anonymous, bodily caregiving — xkaèkh's daily vigil for a dying stranger, a farmer feeding his mother his own flesh — becomes the only remaining form of resistance against dehumanization**. The author uses parallel narratives to show that when state and society abandon the vulnerable, individual acts of love preserve collective humanity."

DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: **Assertion-Reason (AR):**  
**Assertion (A):** The primary theme of "Hkh'e lkguh" is the **irreversible loss of home and belonging** caused by Partition.  
**Reason (R):** The narrator finds his village physically changed, xkaèkh aged and frail, and vjkI+kQkr displaced — all symbols of a world that cannot be reclaimed.  
Choose the correct option:  
(a) Both A and R are true, and R correctly explains A.  
(b) Both A and R are true, but R does not explain A.  
(c) A is true, R is false.  
(d) A is false, R is true.  
Justify your choice with textual analysis.

COMPETENCY: Logical reasoning + thematic evaluation (AR questions appear in CBSE Sample Papers and CUET).

STEPS:
- Step 1: Evaluate Assertion (A) — Is "irreversible loss of home" the **primary** theme? The story *depicts* loss, but its **thrust** is what *persists* despite loss (caregiving, memory, language). The ending — xkaèkh walking on, narrator carrying v[kckj — suggests continuity, not just loss. So A is **false** as *primary* theme (it's a condition, not the message).
- Step 2: Evaluate Reason (R) — Are the details true? Yes: village changed, xkaèkh aged, vjkI+kQkr displaced. These are accurate textual observations.
- Step 3: Check if R explains A — R lists evidence *for* loss, but since A misidentifies the primary theme, R cannot correctly explain the *actual* primary theme.
- Step 4: Select option — (d) A is false, R is true.
- Step 5: Justify — The primary theme is **resilience of human connection amid loss**, not loss itself. R correctly describes the setting of loss, but the story's message is what *survives* that setting.

ANSWER: **Option (d) — A is false, R is true.**  
**Justification:** The Assertion misidentifies the primary theme. While loss of home is the story's **context**, the primary theme is the **endurance of empathy and caregiving** *within* that loss (xkaèkh's vigil, farmer's sacrifice, vjkI+kQkr's shared humanity). The Reason accurately lists textual evidence of loss (changed village, aged friend, displaced refugee), but this evidence *sets the stage* for the theme — it does not constitute the theme itself. The story's closing image of xkaèkh continuing his journey ("rw rks ikxy gS") and the narrator carrying the farmer's memory confirms the thematic focus on **continuity**, not irreversibility.

DIFFICULTY: hard