## DEFINITION
Irony (वाक्यवैपरीत्य/व्यंग्य) is a literary device where the intended meaning of words or situations is opposite to their literal or apparent meaning, creating a contrast between expectation and reality. Symbolism (प्रतीकवाद) is the use of concrete objects, characters, or actions to represent abstract ideas, qualities, or concepts beyond their literal significance.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student must be able to identify at least two distinct instances of irony and two symbols in the chapter's three stories, explain how each operates at both literal and figurative levels, and write a structured analysis connecting these devices to the stories' themes using textual evidence.

## SCOPE_BOUNDARY
This node covers irony (situational, verbal, dramatic) and symbolism (objects, characters, actions as symbols) specifically in the three stories: "काका साहब", "आंखों की झूठी गवाही", and "पिंजरे की उड़ान" from the chapter "पं. केशवचंद्र शुक्ल". It does NOT cover imagery, metaphor, or other figures of speech addressed in node c12_hin_a_cbse_11_008.

## WALKTHROUGH
Imagine you're watching a movie where a character says "What a beautiful day!" during a terrible storm — you instantly recognize the gap between words and reality. That's irony. Now think of a wedding ring — it's just a metal band, but it represents eternal commitment. That's symbolism. In Premchand's stories, look for moments where characters say one thing but mean another, or where objects like spectacles, birds, or a child's running away carry deeper meanings about education, perception, and freedom. Start by re-reading each story asking: "What is the surface meaning? What is the hidden meaning? What object keeps reappearing?" The key insight: irony exposes societal hypocrisies while symbols condense complex themes into tangible forms.

## DIAGNOSTIC_QUESTION_1
Define situational irony and give one example from "काका साहब" where the outcome contradicts the characters' expectations.

## DIAGNOSTIC_ANSWER_1
Situational irony occurs when actions produce an outcome opposite to what was intended or expected. In "काका साहब", the teacher expects the boy to name a conventional profession, but the boy says "I'll become a wanderer" — ironically, his wandering leads to real education while formal schooling failed him. A wrong answer (e.g., "irony is just sarcasm") reveals confusion between verbal irony (tone-based) and situational irony (outcome-based), and inability to locate textual evidence.

## DIAGNOSTIC_QUESTION_2
Explain in your own words why the spectacles (ऐनक) in "आंखों की झूठी गवाही" function as a symbol, not just a plot device.

## DIAGNOSTIC_ANSWER_2
The spectacles symbolize specialized knowledge that gatekeeps truth — the eye specialist claims only experts can examine eyes, but the narrator argues everyone has the right to self-knowledge. They represent how institutions (medical, educational) monopolize understanding. A wrong answer (e.g., "spectacles help the old man see") treats them only as literal objects, missing the symbolic layer about epistemic authority and democratic access to knowledge.

## DIAGNOSTIC_QUESTION_3
Apply the concept of dramatic irony to "पिंजरे की उड़ान": identify what the reader knows that the characters (the old man, the birds) do not, and how this creates tension.

## DIAGNOSTIC_ANSWER_3
The reader knows the old man's "test" is a metaphor for life choices, while the birds (and initially the narrator) perceive it literally as a game. This creates dramatic irony — we understand the philosophical weight (freedom vs security, tradition vs modernity) before the characters do. A wrong answer (e.g., "the birds don't know they're in a cage") misses that dramatic irony requires reader's superior knowledge, not just character ignorance.

## DIAGNOSTIC_QUESTION_4
Analyze how verbal irony operates in the narrator's tone when describing the education system in "काका साहब". Quote one phrase and explain its double meaning.

## DIAGNOSTIC_ANSWER_4
The phrase "शिक्षा के नाम पर बच्चों पर लादी जाने वाली बोझ" (the burden imposed on children in the name of education) uses verbal irony — "शिक्षा के नाम पर" (in the name of education) superficially honors the system, while "लादी जाने वाली बोझ" (imposed burden) exposes its oppressive reality. The double meaning critiques hollow formalities. A wrong answer (e.g., "the narrator is angry") identifies emotion but not the linguistic mechanism of saying one thing to mean its opposite.

## DIAGNOSTIC_QUESTION_5
Evaluate: Which story uses symbolism more effectively to convey its central theme — "आंखों की झूठी गवाही" (spectacles) or "पिंजरे की उड़ान" (birds)? Justify with two comparative points.

## DIAGNOSTIC_ANSWER_5
"पिंजरे की उड़ान" uses birds more effectively because: (1) the three birds map directly onto three life philosophies (materialism, tradition, spirituality) making the symbol structurally integral, not decorative; (2) the final poem ("जन्म-मृत्यु के चक्र में...") explicitly links bird-flight to human existential cycles, creating a closed symbolic system. Spectacles in the other story are powerful but remain a single metaphor. A wrong answer (e.g., "both are equal") fails to evaluate comparative structural integration of symbol into theme.

## DIAGNOSTIC_QUESTION_6
Create a new symbolic object for a modern retelling of "काका साहब" that represents the gap between institutional education and real learning. Describe the object and explain its symbolic layers.

## DIAGNOSTIC_ANSWER_6
A cracked smartphone screen: literally a damaged device, symbolically representing how digital education (online classes, apps) promises access but delivers fragmented, superficial knowledge. The cracks = systemic flaws; the glowing screen = illusion of enlightenment; the touch interface = passive consumption mistaken for interaction. A poor answer (e.g., "a broken book") merely transplants the old symbol without adapting to contemporary context, showing inability to transfer symbolic thinking.

## COMMON_MISCONCEPTION
Students conflate irony with mere coincidence or bad luck (e.g., "it's ironic that the boy ran away and got lost" — no, that's just unfortunate). They also treat every recurring object as a symbol (e.g., "the teacher's cane is a symbol" — it's just a prop unless it represents authority/oppression consistently). The root error: confusing literal recurrence with figurative representation, and confusing unexpected outcomes with ironic reversal of expectation.

## ON_FAILURE
Step 1: Re-read "काका साहब" marking every moment where a character's statement contradicts their action or the outcome — label each as verbal/situational/dramatic irony. Step 2: List all objects appearing in all three stories; for each, ask "Does this represent an abstract idea beyond its function?" — only keep those with consistent thematic resonance. Step 3: Write one paragraph per device using the template: "In [story], [device] appears when [context]. Literally it means [X]. Figuratively it suggests [Y]. This supports the theme of [Z]." Step 4: Compare your analysis with the model answers in node c12_hin_a_cbse_11_013 (Critical Thinking).

## BUILDS_ON
Node c12_hin_a_cbse_11_008 (Imagery and Metaphor) establishes foundational figurative language analysis; this node deepens into structural devices that organize entire narratives.

## LEADS_TO
Node c12_hin_a_cbse_11_013 (Critical Thinking: Analysis and Interpretation) where irony and symbolism become tools for synthesizing multi-layered thematic arguments.

## PREREQUISITE_NODE_IDS
c12_hin_a_cbse_11_001, c12_hin_a_cbse_11_002, c12_hin_a_cbse_11_008, c11_hin_ar_cbse_11_009, c12_hin_a_cbse_11_006, c12_hin_a_cbse_11_007

## PREREQUISITE_REASONS
c12_hin_a_cbse_11_001: Provides author context (Premchand's reformist agenda) essential for decoding ironic critique of institutions.
c12_hin_a_cbse_11_002: Plot knowledge required to track where irony/symbolism occur in narrative sequence.
c12_hin_a_cbse_11_008: Builds on metaphor/imagery identification skills; symbolism extends metaphor into sustained representation.
c11_hin_ar_cbse_11_009: Class 11 coverage of irony/symbolism in other texts provides the definitional baseline.
c12_hin_a_cbse_11_006: Irony and symbolism deepen the theme; their interpretation depends on a clear thematic anchor.  
c12_hin_a_cbse_11_007: Irony and symbolism often highlight the gap between primary and secondary themes (e.g., the "Holistic Development" banner).  

## FORWARD_NODE_IDS
c12_hin_a_cbse_11_010, c12_hin_a_cbse_11_012, c12_hin_a_cbse_11_013, c12_hin_a_cbse_11_014, c12_hin_a_cbse_11_015

## FORWARD_REASONS
c12_hin_a_cbse_11_010: Vocabulary like "व्यंग्य", "प्रतीक", "वाक्यवैपरीत्य" must be mastered for precise literary terminology in answers.
c12_hin_a_cbse_11_012: Comprehension questions directly test device identification and effect (e.g., "What does the spectacle symbolize?").
c12_hin_a_cbse_11_013: Critical thinking requires synthesizing irony/symbolism into thematic arguments with evidence.
c12_hin_a_cbse_11_014: Writing skills tasks (analytical paragraph, essay) demand structured device-analysis using these concepts.
c12_hin_a_cbse_11_015: Irony/symbolism detection enables deeper interpretive claims.  

## CROSS_SUBJECT_PREREQS
c11_hin_ar_cbse_01_009, c11_hin_ar_cbse_02_009, c11_hin_ar_cbse_03_009
## CROSS_SUBJECT_REASONS
c11_hin_ar_cbse_01_009: Irony/symbolism in "नमक का दरोगा" (corruption vs duty) parallels Premchand's institutional critique.
c11_hin_ar_cbse_02_009: Symbolism in "मियाँ नसीरुद्दीन" (the kite as freedom) trains the same object→abstraction mapping.
c11_hin_ar_cbse_03_009: Dramatic irony in "अपू के साथ ढाई साल" (reader knows Apoo's fate) builds the reader-superiority concept.

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_11_009 -> c12_hin_a_cbse_11_009 -> c12_hin_a_cbse_11_013

## THIS_FORMULA
Irony Analysis = (Surface Meaning) ≠ (Deep Meaning) + Textual Evidence + Thematic Function | Symbolism Analysis = (Concrete Object) → (Abstract Idea) + Recurrence Pattern + Thematic Integration

## FORMULA_VARIABLES
Surface Meaning: Literal words/actions in text | Deep Meaning: Implied critique/reality | Textual Evidence: Exact phrase/scene reference | Thematic Function: How device serves central idea | Concrete Object: Physical element (spectacles, birds, cane) | Abstract Idea: Concept represented (knowledge, freedom, authority) | Recurrence Pattern: Frequency and variation of symbol's appearance | Thematic Integration: Whether symbol structures the narrative or merely decorates

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
analytical

## CROSS_SUBJECT
N/A | Premchand's irony exposes colonial education's failure — connects to History's critique of Macaulay's minutes and indigenous knowledge systems.
 N/A | Symbols like spectacles/birds represent tradition-modernity conflict — mirrors Sociology's analysis of structural change agents and cultural lag.
## PREREQ_CONCEPT
Ability to distinguish literal vs figurative meaning (from Class 11 Literary Devices node c11_hin_ar_cbse_11_009).

## PREREQ_BEFORE
Student must have read all three stories completely and identified at least 5 recurring objects/phrases per story.

## PREREQ_STUCK
If stuck on "is this irony or just contrast?", return to Class 11 node c11_hin_ar_cbse_11_009 and re-do the irony-type classification exercise with "नमक का दरोगा".

## WORKED_EXAMPLE_1
PROBLEM: Analyze the situational irony in the ending of "काका साहब" where the boy's "wandering" becomes his true education.
STEPS:
- Step 1: Identify the expectation set up early — the teacher asks "What will you become?" implying a professional identity (doctor, clerk) validates education.
- Step 2: Identify the outcome — the boy says "I'll become a wanderer" (आवारा), which the teacher/father dismisses as failure.
- Step 3: Trace the narrative result — the boy's wandering exposes him to real people, practical skills, and self-knowledge that formal schooling denied.
- Step 4: Articulate the irony — the rejected path (wandering) produces the claimed goal of education (enlightened, capable individual) while the approved path (school) produced only rote compliance.
- Step 5: Connect to theme — this irony structures Premchand's critique: true education liberates, institutional education domesticates.
REASONING: Situational irony requires a clear expectation-outcome reversal that serves thematic purpose. Steps 1-2 establish the expectation, Step 3 the outcome, Step 4 the reversal, Step 5 the significance.
ANSWER: The situational irony lies in the boy's "failure" (wandering) achieving education's true aim (critical thinking, empathy, autonomy) while "success" (passing exams) would have produced only conformity. Premchand inverts societal values: the wanderer becomes the true scholar.

## WORKED_EXAMPLE_2
PROBLEM: Explain how the three birds in "पिंजरे की उड़ान" function as an extended symbolic system representing three responses to tradition.
STEPS:
- Step 1: Map each bird to its choice — Bird 1 chooses the cage (security), Bird 2 chooses the open sky (freedom), Bird 3 chooses the old man's hand (guided tradition).
- Step 2: Identify the abstract ideas — Cage = materialism/conformity; Sky = radical individualism; Hand = reformed tradition with agency.
- Step 3: Note recurrence and variation — each bird's choice is narrated with distinct imagery (golden cage, stormy sky, warm palm) reinforcing the symbolic differentiation.
- Step 4: Analyze the old man's role — he is not a neutral observer but the embodiment of tradition offering/withholding freedom; his test makes the symbol interactive.
- Step 5: Link to the concluding poem — "जन्म-मृत्यु के चक्र में..." explicitly equates bird-flight with soul's journey, confirming the allegorical design.
REASONING: Extended symbolism requires consistent mapping (Step 1-2), textual reinforcement (Step 3), narrative integration (Step 4), and thematic closure (Step 5).
ANSWER: The three birds form a symbolic triad: the first bird (cage) symbolizes passive acceptance of tradition; the second (sky) symbolizes rootless rebellion; the third (hand) symbolizes conscious continuity — Premchand's ideal where tradition is chosen, not imposed.

## WORKED_EXAMPLE_3
PROBLEM: Compare the use of verbal irony in the narrator's voice across "काका साहब" and "आंखों की झूठी गवाही" — how does tone shift from playful to polemical?
STEPS:
- Step 1: In "काका साहब", locate the narrator's description of the teacher's questioning — "मास्टर साहब ने बड़े प्रेम से पूछा" (teacher asked affectionately) but the questions are rigid ("What will you be?"). The irony: affectionate tone masks authoritarian intent.
- Step 2: In "आंखों की झूठी गवाही", locate the narrator's direct address to the specialist — "आप ही बताइए, आँखें किसकी हैं?" (You tell me, whose eyes are they?). The irony: polite form ("आप") frames a radical challenge to professional monopoly.
- Step 3: Identify the tonal shift — Story 1 uses gentle mockery (playful irony) to invite sympathy for the boy; Story 2 uses confrontational irony to provoke reader's indignation at institutional arrogance.
- Step 4: Explain the rhetorical purpose — playful irony disarms, making critique palatable; polemical irony mobilizes, demanding systemic change.
- Step 5: Synthesize — both serve Premchand's reformism but calibrate irony to the target: family/school (micro) vs medical/state (macro) authority.
REASONING: Verbal irony's effect depends on tone-audience alignment. Step 1-2 extract textual instances, Step 3 classifies tone, Step 4 links tone to rhetorical goal, Step 5 reveals authorial strategy.
ANSWER: "काका साहब" employs Horatian irony (gentle, corrective) — "मास्टर साहब ने बड़े प्रेम से पूछा" masks the violence of labeling a child. "आंखों की झूठी गवाही" employs Juvenalian irony (bitter, accusatory) — "आँखों के डॉक्टर ही आँखों के मालिक नहीं" directly attacks epistemic hierarchy. The shift reflects escalating stakes: from pedagogical to existential freedom.

## COMPETENCY_QUESTION_1
QUESTION: A Class 12 student writes: "The spectacles in the story are a symbol of old age because the old man wears them." Using the concept of symbolism, explain why this analysis is insufficient and rewrite it to meet board exam standards.
COMPETENCY: Critical analysis of literary interpretation / Application of symbolism criteria
STEPS:
- Step 1: Identify the error — the student confuses association (old man wears spectacles) with symbolic representation (spectacles = specialized knowledge gatekeeping).
- Step 2: State the criteria for valid symbolism — recurrence, thematic resonance, abstraction from literal function.
- Step 3: Provide textual evidence — the specialist says "only experts can examine eyes", the narrator counters "eyes belong to the person", spectacles become the physical token of this dispute.
- Step 4: Rewrite the analysis using the template: "The spectacles symbolize [abstract idea] because [evidence 1], [evidence 2], and they [thematic function]."
ANSWER: The student's analysis fails because it describes a literal attribute (old age) not a symbolic meaning. Board-standard rewrite: "The spectacles symbolize institutional monopoly over knowledge. Evidence: (1) The specialist claims exclusive right to examine eyes, making spectacles a tool of authority; (2) The narrator's challenge — 'whose eyes are they?' — turns spectacles into contested territory; (3) This supports the theme of democratic access to self-knowledge versus professional gatekeeping."
DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: In a CUET-style assertion-reason question:
Assertion (A): Premchand uses dramatic irony in "पिंजरे की उड़ान" to make the reader complicit in judging the birds' choices.
Reason (R): The reader knows the philosophical allegory before the birds do, creating a position of moral superiority.
Choose the correct option and justify your choice with reference to the text.
COMPETENCY: Evaluation of literary device function / Competitive exam pattern reasoning
STEPS:
- Step 1: Verify Assertion — does dramatic irony make reader complicit? Yes, we "judge" Bird 1 as cowardly, Bird 2 as reckless, Bird 3 as wise because we grasp the allegory.
- Step 2: Verify Reason — does reader know allegory before birds? Yes, the old man's framing ("this is a test of life") and the poem's explicit mapping give reader the key.
- Step 3: Check A-R linkage — does R correctly explain A? Yes, reader's prior knowledge (R) creates the judging stance (A).
- Step 4: Select option — Both A and R true, R explains A.
- Step 5: Add textual anchor — cite the moment the old man says "this is not a game, this is life" and the final poem's "birth-death cycle" lines.
ANSWER: Option: Both A and R are true, and R is the correct explanation of A. Justification: The old man's declaration "यह खेल नहीं, जीवन है" (this is not a game, this is life) and the concluding poem's explicit equation of bird-flight with human existential choices give the reader the allegorical key before the birds "understand" their choices. This dramatic irony positions the reader as evaluator of life-philosophies — complicit in Premchand's moral framework.
DIFFICULTY: hard