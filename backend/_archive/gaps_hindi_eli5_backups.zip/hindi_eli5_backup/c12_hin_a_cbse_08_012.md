## DEFINITION
Literal comprehension questions require students to retrieve information explicitly stated in the text, such as facts, details, or direct statements. Inferential comprehension questions require students to draw conclusions, make interpretations, or understand implied meanings by combining textual evidence with prior knowledge and context.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student can independently distinguish between literal and inferential questions, locate explicit textual evidence for literal answers, and construct logical inferences supported by textual clues for inferential answers, using the PEEL (Point, Evidence, Explanation, Link) structure in written responses.

## SCOPE_BOUNDARY
This node covers strategies for answering literal and inferential questions based on the Kabir poems in Chapter 8 (Antra). It does not cover critical analysis, creative writing, or speaking/listening activities, which are addressed in subsequent nodes.

## WALKTHROUGH
Imagine you are sitting in the exam hall and see a question: "कबीर ने संसार को 'नकली' क्यों कहा है?" You might panic because the word 'नकली' isn't directly in the poem. Start by reading the question carefully: underline keywords (कबीर, संसार, नकली). Then scan the poem for related words — 'माया', 'भ्रम', 'झूठ', 'असार'. In the first pada, Kabir says "जगत मिथ्या" (the world is illusory). That's your evidence. For literal questions like "कबीर का जन्म कहाँ हुआ था?", you simply locate the factual detail from the introductory text. The key insight: literal answers are *found*; inferential answers are *built* from clues.

## DIAGNOSTIC_QUESTION_1
What is the primary difference between a literal comprehension question and an inferential comprehension question?

## DIAGNOSTIC_ANSWER_1
A literal question asks for information directly stated in the text (e.g., "कबीर के गुरु का नाम क्या था?"), while an inferential question requires the reader to deduce meaning not explicitly written (e.g., "कबीर की वाणी में सामाजिक समरसता का भाव कैसे व्यक्त होता है?"). A wrong answer that says "both need reading the text" misses the crucial distinction: literal = retrieval, inferential = reasoning with evidence.

## DIAGNOSTIC_QUESTION_2
In the first pada of Kabir in this chapter, the line "जगत मिथ्या, ब्रह्म सत्य" appears. A student answers the inferential question "कबीर संसार को क्षणभंगुर क्यों मानते हैं?" by quoting this line. Is this a complete inferential answer? Why or why not?

## DIAGNOSTIC_ANSWER_2
No, quoting the line is only the *evidence* step. An inferential answer must also *explain* how that evidence supports the inference: the line states the world is illusory (मिथ्या) and only Brahman is eternal, implying the world's transient nature. The student must connect "मिथ्या" to "क्षणभंगुर" and link it to Kabir's philosophy. A wrong answer that stops at the quote shows confusion between evidence and explanation.

## DIAGNOSTIC_QUESTION_3
Given the second pada: "मन न रंगाए, रंगाए जोगी कपड़ा" (The mind is not dyed, only the yogi's robe is dyed). Answer the literal question: "जोगी क्या रंगाता है?" and the inferential question: "कबीर बाह्य आडंबर पर क्यों प्रहार करते हैं?" Show your PEEL structure for the inferential answer.

## DIAGNOSTIC_ANSWER_3
Literal: जोगी अपना कपड़ा रंगाता है। Inferential PEEL: Point — कबीर बाह्य आडंबर को निरर्थक मानते हैं। Evidence — "मन न रंगाए, रंगाए जोगी कपड़ा"। Explanation — केवल वस्त्र रंगने से मन शुद्ध नहीं होता; वास्तविक साधना आंतरिक है। Link — यह कबीर के निर्गुण भक्ति और आंतरिक पवित्रता के सिद्धांत को दर्शाता है। A wrong answer that gives only the point without evidence shows inability to structure inferential responses.

## DIAGNOSTIC_QUESTION_4
Compare the two questions: (A) "कबीर की भाषा में कौन-कौन सी बोलियों का मिश्रण है?" (B) "कबीर की भाषा जनमानस की भाषा क्यों कही जाती है?" Identify which is literal and which is inferential, and explain the different cognitive demands.

## DIAGNOSTIC_ANSWER_4
(A) is literal — it asks for a list of dialects (खड़ी बोली, ब्रज, अवधी, आदि) directly mentioned in the introductory text. (B) is inferential — it requires analyzing *why* the mixture makes it accessible: simple vocabulary, everyday metaphors, oral rhythm. The cognitive demand shifts from retrieval (A) to synthesis of textual features with sociolinguistic context (B). A wrong answer that treats both as factual recall fails to recognize the analytical leap in (B).

## DIAGNOSTIC_QUESTION_5
A student writes this answer to "कबीर की 'उलटबांसी' शैली का उद्देश्य क्या है?": "कबीर उलटबांसी इसलिए लिखते हैं ताकि लोग चकरा जाएँ और सोचने पर मजबूर हों।" Evaluate this answer. Is it sufficient for a 3-mark board question? What would you add?

## DIAGNOSTIC_ANSWER_5
The answer is partially correct but incomplete for 3 marks. It identifies the effect (confusion → thought) but misses the *purpose*: to shatter conventional thinking, reveal paradoxical truths (e.g., "मछली जल में प्यासी"), and awaken spiritual insight. A full answer needs: (1) definition of उलटबांसी, (2) example from the poem, (3) explanation of how it disrupts assumptions, (4) link to Kabir's non-dual philosophy. The student's answer shows surface-level understanding — a common board-exam trap where students confuse *effect* with *purpose*.

## DIAGNOSTIC_QUESTION_6
Create your own inferential question based on the third pada ("कबीर दास की वाणी में...") that requires connecting imagery to theme. Provide the question and a model PEEL answer.

## DIAGNOSTIC_ANSWER_6
Question: "तीसरे पद में 'आगि लगाई जल में' बिंब के माध्यम से कबीर कौन-सा आध्यात्मिक सत्य व्यक्त करते हैं?" Model PEEL: Point — आत्मा की परमात्मा में विलीनता की तीव्र आकांक्षा। Evidence — "आगि लगाई जल में, जल बुझाई आगि"। Explanation — जल (आत्मा) में आग (प्रेम/विरह) लगना असंभव लगता है, पर भक्ति में यह संभव है; यह विरोधाभास उलटबांसी है। Link — यह निर्गुण भक्ति के 'असंभव को संभव बनाने' वाले रहस्य को दर्शाता है। A poor question would be literal ("तीसरे पद में कौन-सा बिंब है?") showing inability to design inferential tasks.

## COMMON_MISCONCEPTION
Students think inferential questions are "guessing" or "opinion" questions, so they write vague answers like "कबीर अच्छा संदेश देते हैं" without textual evidence. They confuse *inference* (logical deduction from evidence) with *assumption* (personal feeling). This stems from treating literature as subjective rather than evidence-based. In board exams, such answers get 0/3 because the marking scheme requires explicit textual reference + logical connection.

## ON_FAILURE
If a student cannot distinguish literal vs. inferential, do this 3-step remediation: (1) Give them a short unseen paragraph (5 lines) and ask them to write 2 literal and 2 inferential questions *with answers*. (2) Have them highlight the exact words in the text that answer the literal questions. (3) For inferential, have them write the evidence sentence, then the inference, then the explanation linking them. Repeat with a Kabir pada from the chapter. Re-diagnose using Diagnostic Question 2.

## BUILDS_ON
Builds on Class 11 comprehension skills (c11_hin_ar_cbse_01_012) where students learned basic question types, now deepening into evidence-based inferential reasoning with poetic texts.

## LEADS_TO
Enables critical thinking and analysis (c12_hin_a_cbse_08_013) where students evaluate interpretations and compare multiple readings of the same text.

## PREREQUISITE_NODE_IDS
c11_hin_ar_cbse_01_012, c12_hin_a_cbse_08_001, c12_hin_a_cbse_08_002, c12_hin_a_cbse_08_008, c12_hin_a_cbse_08_010, c12_hin_a_cbse_08_011, c12_hin_a_cbse_08_007, c12_hin_a_cbse_08_009

## PREREQUISITE_REASONS
c11_hin_ar_cbse_01_012: Provides foundational comprehension question types from Class 11.
c12_hin_a_cbse_08_001: Context/background knowledge of Kabir's life and times is essential for inferential answers.
c12_hin_a_cbse_08_002: Understanding narrative/poetic structure helps locate evidence in specific stanzas.
c12_hin_a_cbse_08_008: Knowledge of imagery/metaphor is required to interpret figurative language in inferential questions.
c12_hin_a_cbse_08_010: Vocabulary mastery ensures accurate understanding of key terms in questions and text.
c12_hin_a_cbse_08_011: Grammar awareness helps parse complex sentences in both questions and poetic lines.
c12_hin_a_cbse_08_007: Comprehension questions often ask "How does the poet criticize rituals?" — requires thematic analysis.  
c12_hin_a_cbse_08_009: Inferential comprehension questions directly test ability to decode symbols and irony.  

## FORWARD_NODE_IDS
c12_hin_a_cbse_08_013, c12_hin_a_cbse_08_014, c12_hin_a_cbse_08_015

## FORWARD_REASONS
c12_hin_a_cbse_08_013: Critical thinking requires the inferential skills honed here to analyze themes, compare interpretations, and evaluate literary merit.
c12_hin_a_cbse_08_014: Writing skills (analytical paragraphs, essays) directly apply the PEEL structure practiced in this node.
c12_hin_a_cbse_08_015: Provides literal and inferential comprehension base needed to cite accurate lines.  

## CROSS_SUBJECT_PREREQS
c11_hin_ar_cbse_01_012, c11_hin_ar_cbse_02_012, c11_hin_ar_cbse_03_012
## CROSS_SUBJECT_REASONS
c11_hin_ar_cbse_01_012: Class 11 Antra comprehension foundation — same skill set applied to different texts.
c11_hin_ar_cbse_02_012: Reinforces literal/inferential distinction across multiple chapters in Class 11.
c11_hin_ar_cbse_03_012: Provides varied poetic/prose texts for practice, building transferable comprehension strategies.

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_01_012 -> c12_hin_a_cbse_08_012 -> c12_hin_a_cbse_08_013

## THIS_FORMULA
PEEL Structure for Inferential Answers: Point (inference) → Evidence (quote/paraphrase) → Explanation (how evidence supports point) → Link (connect to theme/author's purpose)

## FORMULA_VARIABLES
Point = The inferred answer to the question; Evidence = Exact textual reference (line/stanza); Explanation = Logical reasoning connecting evidence to point; Link = Connection to broader theme, context, or author's intent

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
linguistic

## CROSS_SUBJECT
N/A | Understanding historical context of Bhakti movement (Kabir's era) aids inferential answers about social critique in poems.
 N/A | Constitutional values (equality, fraternity) resonate with Kabir's themes; inferential questions often link literature to civic ideals.
## PREREQ_CONCEPT
Ability to distinguish explicit textual information from implicit meaning, and to use textual evidence to support a claim.

## PREREQ_BEFORE
Student must be able to locate specific details in a Hindi text and understand basic poetic devices (metaphor, symbolism) from Class 11 and earlier nodes in this chapter.

## PREREQ_STUCK
If stuck, review Class 11 comprehension node c11_hin_ar_cbse_01_012 and practice identifying literal vs. inferential questions in any Hindi textbook passage.

## WORKED_EXAMPLE_1
PROBLEM: Answer the inferential question: "कबीर के अनुसार 'गुरु' की क्या महत्ता है? पाठ के आधार पर समझाइए।" (Based on the introductory text and poems in Chapter 8)
STEPS:
- Step 1: Identify question type — inferential (asks for "महत्ता" meaning significance/role, not just name).
- Step 2: Scan introductory text and poems for references to guru. Find: "गुरु गोविंद दोऊ खड़े..." (not in this chapter but in intro), and in pada 1 "सतगुरु मिल्या...".
- Step 3: Extract evidence: Intro says Kabir considered guru essential for knowledge; Pada 1 implies guru reveals truth ("सतगुरु मिल्या तब जान्या")।
- Step 4: Formulate Point: कबीर गुरु को ज्ञान-प्राप्ति का अनिवार्य माध्यम मानते हैं।
- Step 5: Write PEEL answer: Point (गुरु अनिवार्य हैं), Evidence ("सतगुरु मिल्या तब जान्या"), Explanation (गुरु के बिना आत्मज्ञान असंभव), Link (यह निर्गुण भक्ति में गुरु-परंपरा की प्रधानता दर्शाता है)।
REASONING: The question asks for "महत्ता" (significance), which is not a single fact but a synthesized understanding of the guru's role across the text. PEEL ensures each part of the answer is anchored in evidence.
ANSWER: कबीर के अनुसार गुरु (सतगुरु) आत्मज्ञान प्राप्ति का एकमात्र माध्यम हैं। पाठ में आता है "सतगुरु मिल्या तब जान्या" — गुरु के मिलने पर ही वास्तविक ज्ञान होता है। गुरु अज्ञानरूपी अंधकार को दूर कर ब्रह्मज्ञान कराते हैं। यह कबीर की गुरु-केन्द्रित भक्ति-धारा को दर्शाता है।

## WORKED_EXAMPLE_2
PROBLEM: A literal question from the chapter: "कबीर की प्रमुख रचनाएँ कौन-कौन सी हैं?" Answer using the introductory text only.
STEPS:
- Step 1: Recognize as literal — asks for a list explicitly given in the "Before You Read" section.
- Step 2: Locate the relevant paragraph in the introductory text (fo|kifr@47).
- Step 3: Extract the list: "बीजक", "साखी", "सबद", "रमैनी"।
- Step 4: Format answer clearly: कबीर की प्रमुख रचनाएँ हैं — बीजक, साखी, सबद, रमैनी।
- Step 5: Verify no extra interpretation is added; it's pure retrieval.
REASONING: Literal questions test reading accuracy, not analysis. The answer must match the text exactly without inference.
ANSWER: कबीर की प्रमुख रचनाएँ हैं — बीजक, साखी, सबद, रमैनी।

## WORKED_EXAMPLE_3
PROBLEM: Combined literal + inferential question: "पहले पद में 'माया' शब्द का प्रयोग किन अर्थों में हुआ है? कबीर माया को त्याज्य क्यों मानते हैं?" (Two sub-questions: literal meaning + inferential reason)
STEPS:
- Step 1: Break into two parts: (a) literal — meanings of 'माया' in pada 1; (b) inferential — why reject it.
- Step 2: For (a), read pada 1 lines: "माया महा ठगनी हम जानी", "माया तेरे त्रिगुण झूठे". Identify meanings: illusion (भ्रम), deceit (छल), material wealth (धन-संपत्ति), triguna (three gunas).
- Step 3: For (b), gather evidence: "माया महा ठगनी", "सब जग माया के फेर", "माया छूटे न मन से". Infer: माया बांधती है, भटकाती है, ईश्वर से विमुख करती है।
- Step 4: Write combined answer: (a) पहले पद में 'माया' का अर्थ है — भ्रम, छल, त्रिगुणात्मक प्रकृति, और सांसारिक आसक्ति। (b) कबीर माया को त्याज्य मानते हैं क्योंकि यह जीव को ठगती है ("महा ठगनी"), संसार में उलझाए रखती है ("सब जग माया के फेर"), और ईश्वर-प्राप्ति में बाधा है।
- Step 5: Check PEEL for inferential part: Point (त्याज्य), Evidence (पद की पंक्तियाँ), Explanation (बांधने वाली शक्ति), Link (मोक्ष मार्ग में बाधा)।
REASONING: This models how board questions often combine literal and inferential parts. Students must switch modes: retrieve for (a), reason for (b).
ANSWER: (a) पहले पद में 'माया' के अर्थ: भ्रम/मोह, छल/ठगनी, त्रिगुण (सत-रज-तम), सांसारिक आसक्ति। (b) कबीर माया को त्याज्य मानते हैं क्योंकि वह जीव को ठगकर संसार में फंसाए रखती है ("माया महा ठगनी हम जानी"), त्रिगुणों के झूठे जाल में उलझाती है ("माया तेरे त्रिगुण झूठे"), और परमात्मा की ओर जाने से रोकती है। यह कबीर के वैराग्य और निर्गुण उपासना का आधार है।

## COMPETENCY_QUESTION_1
QUESTION: Read the following student answer to an inferential question and identify two specific weaknesses based on the PEEL criteria. Then rewrite the answer correctly.

Question: "कबीर की वाणी में 'प्रेम' की क्या विशेषता है?"  
Student's answer: "कबीर प्रेम को बहुत बड़ा मानते हैं। वे कहते हैं प्रेम से ही ईश्वर मिलता है। प्रेम सब कुछ है।"

COMPETENCY: Critical evaluation of peer response / Application of answer-structuring criteria
STEPS:
- Step 1: Identify missing PEEL components — no specific Evidence (quotes), no Explanation of *how* love leads to God, no Link to Kabir's philosophy (e.g., non-duality, inner experience).
- Step 2: Note vagueness — "बहुत बड़ा", "सब कुछ" are assertions without textual support.
- Step 3: Recall relevant lines from chapter: "प्रेम गली अति सांकरी", "प्रेम न बाड़ी उपजे", "पोथी पढ़ि पढ़ि जग मुआ"।
- Step 4: Rewrite using PEEL: Point — कबीर प्रेम को संकीर्ण नहीं, बल्कि अहंकार-रहित समर्पण मानते हैं। Evidence — "प्रेम गली अति सांकरी ता में दो न समाइ"। Explanation — प्रेम में 'दो' (द्वैत/अहंकार) नहीं चलता; यह गुरु-शिष्य या भक्त-भगवान के अभेद का मार्ग है। Link — यह कबीर के निर्गुण भक्ति में प्रेम को साधन नहीं, साध्य (अनुभूति) बनाता है।
ANSWER: Weaknesses: (1) No textual evidence — answer is opinion, not inference. (2) No explanation of Kabir's unique concept of love (non-dual, ego-less). Rewritten answer: कबीर प्रेम को अहंकार-रहित अभेद-भाव मानते हैं। पद में "प्रेम गली अति सांकरी ता में दो न समाइ" — प्रेम की गली इतनी संकरी है कि उसमें द्वैत (भक्त और भगवान) नहीं समाते। इसका अर्थ है प्रेम में अहंकार का पूर्ण विलय आवश्यक है। यह कबीर के निर्गुण ब्रह्म की अनुभूति को प्रेम के माध्यम से व्यक्त करता है।
DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: Design a 3-mark inferential question for the second pada ("मन न रंगाए...") that tests the student's ability to connect metaphor to social critique. Provide the question, a model answer with PEEL, and the marking scheme breakdown (1 mark each for Point, Evidence, Explanation+Link).

COMPETENCY: Question design / Metacognitive awareness of assessment criteria
STEPS:
- Step 1: Analyze pada 2 for metaphors: "रंगाए जोगी कपड़ा", "मन न रंगाए", "कबीर कबीरा"।
- Step 2: Identify social critique: external rituals vs. inner purity; caste/sectarian markers (robe) vs. universal humanity.
- Step 3: Frame question requiring metaphor-social link: "दूसरे पद में 'रंगाए जोगी कपड़ा' रूपक के माध्यम से कबीर किस सामाजिक कुरीति पर प्रहार करते हैं? स्पष्ट कीजिए।"
- Step 4: Model PEEL: Point — कबीर बाह्य आडंबर और वेश-भूषा आधारित धार्मिक पहचान की आलोचना करते हैं। Evidence — "मन न रंगाए, रंगाए जोगी कपड़ा"। Explanation — केवल वस्त्र बदलने (जोगी का कपड़ा रंगाने) से मन शुद्ध नहीं होता; वास्तविक धर्म आंतरिक शुद्धि में है। Link — यह तत्कालीन समाज में प्रचलित पाखंड (योगी/संन्यासी वेश धारण कर ढोंग करना) और जाति-आधारित धार्मिक श्रेष्ठता को खारिज करता है।
- Step 5: Marking scheme: Point (1), Evidence (1), Explanation+Link (1).
ANSWER: Question: "दूसरे पद में 'रंगाए जोगी कपड़ा' रूपक के माध्यम से कबीर किस सामाजिक कुरीति पर प्रहार करते हैं? स्पष्ट कीजिए।" Model Answer: कबीर बाह्य आडंबर और वेश-भूषा आधारित धार्मिक पहचान की आलोचना करते हैं। पद में "मन न रंगाए, रंगाए जोगी कपड़ा" — केवल जोगी का कपड़ा रंगाने (बाह्य वेश बदलने) से मन शुद्ध नहीं होता। वास्तविक साधना आंतरिक शुद्धि में है, न कि बाहरी प्रतीकों में। यह तत्कालीन समाज में प्रचलित पाखंड (वेश धारण कर ढोंग करना) और जाति-आधारित धार्मिक श्रेष्ठता को खारिज करता है। Marking: Point=1, Evidence=1, Explanation+Link=1.
DIFFICULTY: hard