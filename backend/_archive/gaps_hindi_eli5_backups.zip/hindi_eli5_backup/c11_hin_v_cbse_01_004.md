## DEFINITION
Character analysis of the protagonist involves systematically examining the central character's traits, motivations, conflicts, and development through textual evidence such as actions, dialogue, thoughts, and relationships to understand their role in conveying the theme.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student can write a structured 150-word character sketch of Yashodhara using at least three distinct textual evidences (actions, speech, author's commentary) and explain how each evidence reveals a specific trait that connects to the chapter's central theme of artistic integrity.

## SCOPE_BOUNDARY
This node covers analysis of Yashodhara as the sole protagonist — her personality, artistic philosophy, and narrative function. It does NOT cover supporting characters (node 005), thematic analysis (nodes 006-007), or literary devices (nodes 008-009).

## WALKTHROUGH
Imagine you are introducing your friend to a remarkable artist you met — you wouldn't just say "she paints well"; you'd describe the moment she mixed colours with closed eyes, the way she spoke about tradition, and how she reacted when criticised. Similarly, to analyse Yashodhara, start by listing every direct description the author gives (e.g., "she became impatient," "she spoke with conviction"), then group these into trait categories like 'passionate', 'rooted in tradition', 'innovative'. Next, find two concrete incidents for each trait — one from her speech, one from her action. Finally, connect each trait to the author's larger argument about the value of indigenous art forms. The key insight: a protagonist in non-fiction is revealed through the author's selective lens, so always ask "Why did the author choose to show this specific moment?"

## DIAGNOSTIC_QUESTION_1
What is the primary textual evidence used to establish Yashodhara's impatience with superficial art appreciation in the opening paragraph?

## DIAGNOSTIC_ANSWER_1
The author describes Yashodhara becoming restless ("व्याकुल") and speaking sharply ("तीक्ष्ण स्वर") when visitors treat her paintings as mere decoration. A wrong answer like "she smiled politely" reveals the student cannot distinguish between the author's narration and the character's actual reaction, indicating a failure to identify direct characterization.

## DIAGNOSTIC_QUESTION_2
Explain in your own words why the author considers Yashodhara's blending of traditional techniques with modern sensibility as her defining artistic trait.

## DIAGNOSTIC_ANSWER_2
The author values this blend because it represents a living tradition — Yashodhara uses ancient mineral pigments and folk motifs but composes them with contemporary spatial awareness, making heritage relevant without fossilizing it. A wrong answer focusing only on "she uses old colours" shows the student misses the synthesis aspect, treating tradition and modernity as separate rather than integrated.

## DIAGNOSTIC_QUESTION_3
The author writes: "उसकी कला में लोक का सौन्दर्य और शास्त्र की गहराई दोनों हैं।" Identify two specific moments in the text where Yashodhara demonstrates folk aesthetics (लोक सौन्दर्य) and two where she demonstrates classical discipline (शास्त्र की गहराई).

## DIAGNOSTIC_ANSWER_3
Folk aesthetics: (1) using village women's tattoo patterns as border motifs, (2) depicting festivals with communal spontaneity. Classical discipline: (1) preparing canvas with 14-layer traditional ground, (2) adhering to iconometric rules for deity proportions. A wrong answer listing only themes (e.g., "she paints villages") without technical specifics shows the student cannot distinguish subject matter from artistic method.

## DIAGNOSTIC_QUESTION_4
Compare how the author's portrayal of Yashodhara's authority differs when she teaches students versus when she negotiates with gallery owners. What does this contrast reveal about her character?

## DIAGNOSTIC_ANSWER_4
With students she is nurturing but exacting ("हाथ पकड़कर सिखाती, पर गलती पर डाँटती"), while with gallery owners she is firm yet diplomatic ("मूल्य नहीं घटाती, पर प्रदर्शनी की शर्तें मान लेती"). This contrast reveals her core integrity — she compromises on presentation but never on artistic standards. A wrong answer saying "she is strict with both" misses the nuanced power dynamics, showing inability to analyze contextual behaviour.

## DIAGNOSTIC_QUESTION_5
The author claims Yashodhara "revitalised a dying tradition." Evaluate this claim using three pieces of evidence from the text, considering both artistic innovation and social impact.

## DIAGNOSTIC_ANSWER_5
Evidence: (1) Artistic — she introduced natural binder recipes that prevented cracking in humid climates, (2) Social — trained 12 women from her village as professional artists, (3) Institutional — her works entered the National Museum's permanent collection. The claim is valid because innovation addressed material decay while training ensured generational continuity. A wrong answer citing only "she became famous" reveals evaluative superficiality — confusing recognition with substantive revitalisation.

## DIAGNOSTIC_QUESTION_6
Write a 50-word diary entry from Yashodhara's perspective on the day the author visited her studio, reflecting her inner conflict between preserving purity and reaching wider audiences.

## DIAGNOSTIC_ANSWER_6
A strong entry: "Today a city writer watched me grind lapis lazuli. He asked why I don't use synthetic blue. I wanted to shout — this stone carries centuries of prayers! But then he smiled at my Ganesha's curved trunk... maybe sharing the soul matters more than guarding the pigment." A weak entry describing only external events ("He came, saw paintings, left") shows inability to infer interiority from textual gaps.

## COMMON_MISCONCEPTION
Students often treat Yashodhara as a fictional character with a plotted arc, expecting a clear 'beginning-middle-end' transformation. They miss that in this memoir, her 'character' is constructed through the author's thematic purpose — each anecdote is selected to illustrate a specific argument about art, not to tell her life story. For example, they might search for a 'climax' where she overcomes self-doubt, but the text shows consistent conviction; the tension is external (market vs tradition), not internal.

## ON_FAILURE
1. Have the student list all author-narrated incidents chronologically on index cards. 2. Colour-code each card by the author's apparent purpose: 'shows technique', 'shows philosophy', 'shows social role', 'shows personality'. 3. Ask: "Which pile has the most cards? Why did the author need so many examples of that trait?" 4. Guide them to see the pattern: the author builds a case for indigenous art's viability through Yashodhara as evidence, not protagonist.

## BUILDS_ON
c11_hin_v_cbse_01_002 (Plot and Narrative Structure) — understanding the non-fiction memoir structure is essential to distinguish author's voice from subject's portrayal.

## LEADS_TO
c11_hin_v_cbse_01_005 (Character Analysis: Supporting Characters) — the same analytical framework applies to secondary figures like the gallery owner or student artists.

## PREREQUISITE_NODE_IDS
c11_hin_v_cbse_01_001, c11_hin_v_cbse_01_002, c11_hin_v_cbse_01_003
## PREREQUISITE_REASONS
c11_hin_v_cbse_01_001: Provides cultural context of Indian painting traditions necessary to evaluate Yashodhara's innovations.
c11_hin_v_cbse_01_002: Establishes the memoir's non-linear structure so students don't expect a conventional character arc.
c11_hin_v_cbse_01_003: The studio atmosphere descriptions are primary evidence of Yashodhara's working methods and values.

## FORWARD_NODE_IDS
c11_hin_v_cbse_01_005, c11_hin_v_cbse_01_006, c11_hin_v_cbse_01_013, c11_hin_v_cbse_01_007, c11_hin_v_cbse_01_012, c12_hin_a_cbse_03_004, c12_hin_a_cbse_06_004, c12_hin_al_cbse_01_004, c12_hin_v_cbse_01_004, c12_hin_v_cbse_02_004

## FORWARD_REASONS
c11_hin_v_cbse_01_005: Protagonist analysis model transfers directly to supporting characters using same evidence categories.
c11_hin_v_cbse_01_006: Yashodhara's traits embody the primary theme (tradition-modernity synthesis), so character analysis feeds thematic analysis.
c11_hin_v_cbse_01_013: Critical interpretation requires evaluating author's portrayal choices, building on character evidence skills.
c11_hin_v_cbse_01_007: Protagonist analysis (author as narrator) shows how personal experience becomes thematic lens.  
c11_hin_v_cbse_01_012: Protagonist analysis supplies character-based evidence for inference.  
c12_hin_a_cbse_03_004: Prior practice with poetic persona in Class 11 Vitan poems (e.g., "Bharat Mata") bridges to this more complex dual-poem analysis.  
c12_hin_a_cbse_06_004: Reinforces protagonist analysis in non-fiction prose (Vitan textbook), bridging to this chapter's biographical mode.  
c12_hin_al_cbse_01_004: Vitan's character analysis practice adds exposure to different narrative voices.  
c12_hin_v_cbse_01_004: Class 11 Vitan protagonist analysis builds the foundational skill of tracking character through textual evidence.  
c12_hin_v_cbse_02_004: Introduced the trait‑evidence‑explanation framework used here.  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
none

## CHAIN_DESCRIPTION
c11_hin_v_cbse_01_002 -> c11_hin_v_cbse_01_004 -> c11_hin_v_cbse_01_005

## THIS_FORMULA
N/A - conceptual

## FORMULA_VARIABLES
N/A

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
analytical

## CROSS_SUBJECT
c11_history_01 | Understanding how individual artists reflect broader cultural revival movements in colonial/post-colonial India connects to History's study of cultural nationalism.
c11_geography_01 | The use of locally sourced mineral pigments (lapis from Afghanistan, indigo from Bengal) maps onto Geography's resource distribution and trade routes concepts.

## PREREQ_CONCEPT
Non-fiction narrative perspective — recognizing the author as a filter between the real person and the textual representation.

## PREREQ_BEFORE
Student must distinguish between "what Yashodhara did" and "what the author chose to show about Yashodhara."

## PREREQ_STUCK
Review the difference between biography and character portrayal in memoir — re-read node 002's section on authorial selection.

## WORKED_EXAMPLE_1
PROBLEM: Write a character sketch paragraph (80 words) on Yashodhara's 'rooted innovativeness' using the PEEL structure (Point, Evidence, Explanation, Link).

STEPS:
- Step 1: Identify the trait — 'rooted innovativeness' means honouring tradition while adapting it. Locate two textual proofs: (a) her use of 14-layer traditional canvas preparation, (b) her incorporation of contemporary abstract backgrounds.
- Step 2: Select the strongest evidence combination — pair the technical detail (canvas layers) with the visual outcome (modern composition) to show both roots and innovation.
- Step 3: Draft Point sentence: "Yashodhara embodies rooted innovativeness by mastering ancient techniques to serve contemporary expression."
- Step 4: Insert Evidence: "She insists on the 14-layer 'gesso' ground described in Shilpashastras, yet juxtaposes traditional deity figures against abstract colour fields."
- Step 5: Write Explanation: "The laborious ground honours material heritage, while abstract backgrounds liberate icons from narrative rigidity, proving tradition can evolve without erosion."
- Step 6: Craft Link: "This duality makes her the living argument for the author's thesis — indigenous art thrives through creative fidelity, not fossilisation."

REASONING: PEEL forces explicit connection between evidence and interpretation. Step 2's pairing ensures the evidence demonstrates both sides of the trait. Step 6 links to theme, satisfying board exam requirement for thematic integration.

ANSWER: Yashodhara embodies rooted innovativeness by mastering ancient techniques to serve contemporary expression. She insists on the 14-layer 'gesso' ground described in Shilpashastras, yet juxtaposes traditional deity figures against abstract colour fields. The laborious ground honours material heritage, while abstract backgrounds liberate icons from narrative rigidity, proving tradition can evolve without erosion. This duality makes her the living argument for the author's thesis — indigenous art thrives through creative fidelity, not fossilisation.

## WORKED_EXAMPLE_2
PROBLEM: The author describes Yashodhara's reaction to a critic calling her work 'derivative'. Analyse how this single incident reveals three character traits using the 'Action-Speech-Thought' framework.

STEPS:
- Step 1: Locate the incident — after a Delhi exhibition, a reviewer writes "merely copies folk styles." Author notes Yashodhara read it, smiled, then returned to grinding pigments.
- Step 2: Map to framework: Action = resumed grinding (routine continues unchanged); Speech = told author "पत्थर बोलते हैं, आलोचक नहीं" (stones speak, critics don't); Thought = inferred from author's observation "her eyes held no defensiveness, only the kiln's patience."
- Step 3: Derive Trait 1 (Equanimity) from Action — no disruption of creative process shows emotional stability.
- Step 4: Derive Trait 2 (Epistemic Humility) from Speech — attributing authority to materials/tradition rather than ego.
- Step 5: Derive Trait 3 (Long-term Perspective) from Thought — 'kiln's patience' metaphor implies she measures success in centuries, not reviews.
- Step 6: Synthesize: The incident compresses her philosophy — art as dialogue with tradition, not conversation with critics.

REASONING: The framework prevents superficial reading. Step 3-5 show how one moment yields multiple traits when analysed through different behavioural lenses. Step 6 connects to chapter's core argument about artistic integrity.

ANSWER: The critic incident reveals: (1) Equanimity — she continued grinding pigments, showing her process is internally driven; (2) Epistemic Humility — "Stones speak, not critics" shifts authority to tradition; (3) Long-term Perspective — the author's 'kiln's patience' observation frames her work in geological time. Together, they illustrate her core belief: authentic art answers to its materials and lineage, not contemporary judgement.

## WORKED_EXAMPLE_3
PROBLEM: Compare the author's portrayal of Yashodhara in the studio (Sections 1-3) versus the exhibition hall (Sections 4-5). How does the shift in setting alter which character traits are foregrounded? Use a Venn diagram approach in your analysis.

STEPS:
- Step 1: List studio-section traits with evidence: (a) Technical mastery — "mixes colours by finger-tip viscosity test", (b) Ritualistic discipline — "chants while preparing canvas", (c) Communal generosity — "teaches village girls for free".
- Step 2: List exhibition-section traits with evidence: (a) Strategic communication — "explains symbolism in English for collectors", (b) Boundary-setting — "refuses to sign works not meeting her standard", (c) Cultural translation — "frames folk motifs in contemporary artist statements".
- Step 3: Identify overlap (intersection): Integrity — both settings show uncompromising standards (studio: redoes flawed layer; exhibition: withdraws subpar piece).
- Step 4: Identify studio-unique: Intimacy with tradition (chants, finger-tests). Exhibition-unique: Public negotiation (language-switching, framing).
- Step 5: Analyse author's purpose: Studio reveals her 'being' (artist-as-practitioner); exhibition reveals her 'becoming' (artist-as-cultural-bridge). The author uses setting to show tradition is not static — it requires active translation.
- Step 6: Formulate thesis: "The author constructs Yashodhara's character dialectically — private ritual grounds public innovation, proving the chapter's argument that living tradition requires both sanctuary and marketplace."

REASONING: Venn diagram forces structural comparison. Steps 1-4 ensure textual coverage. Step 5 interprets authorial design. Step 6 produces exam-ready analytical statement linking character to theme.

ANSWER: Studio Yashodhara: technical mastery (finger-tip viscosity), ritual discipline (chants), communal generosity (free teaching). Exhibition Yashodhara: strategic communication (English explanations), boundary-setting (refuses signatures), cultural translation (artist statements). Intersection: uncompromising integrity (redoes layers/withdraws works). The author uses setting dialectically — studio shows tradition's depth, exhibition shows its necessary evolution. This character construction proves the thesis: living tradition needs both rooted practice and adaptive outreach.

## COMPETENCY_QUESTION_1
QUESTION: The author writes, "Yashodhara's art is not a window to the past, but a door to the future." Using three specific textual references, explain how the author's portrayal of her character supports this metaphor. Structure your answer in four paragraphs: Claim, Evidence 1+Analysis, Evidence 2+Analysis, Evidence 3+Synthesis.

COMPETENCY: Literary analysis with structured argumentation

STEPS:
- Step 1: Identify the metaphor's implication — 'door to future' means her character embodies forward-looking agency, not nostalgia.
- Step 2: Select Evidence 1: Her training village girls as professionals (future livelihoods). Analysis: Character trait = social visionary.
- Step 3: Select Evidence 2: Her material innovations (crack-resistant binders). Analysis: Character trait = problem-solving practitioner.
- Step 4: Select Evidence 3: Her refusal to freeze iconography ("deities evolve with devotees"). Analysis: Character trait = dynamic traditionalist.
- Step 5: Synthesize: These three traits — visionary, practitioner, dynamic — collectively make her a 'door' because each actively shapes what comes next.

ANSWER: The author portrays Yashodhara as a door to the future through three character dimensions. First, her social vision appears in training twelve village women as professional artists — she transforms tradition from inheritance into livelihood, creating future custodians. Second, her practitioner's problem-solving emerges in developing humidity-resistant binders — she solves material decay that would otherwise end the practice, ensuring physical continuity. Third, her dynamic traditionalism shows when she insists "deities evolve with devotees," refusing to fossilize iconography. Together, visionary custodianship, material innovation, and adaptive theology make her character an active threshold — not a passive frame — through which tradition walks forward.

DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: A board exam question asks: "The protagonist in this memoir is less a person than an argument." Evaluate this statement by analysing how the author's selective portrayal of Yashodhara serves the chapter's thesis on indigenous art's relevance. Write a 120-word critical response acknowledging both sides.

COMPETENCY: Critical evaluation of authorial construction

STEPS:
- Step 1: Unpack the statement — "less a person" suggests flattening of complexity; "an argument" suggests instrumentalization for thesis.
- Step 2: Support side — author omits personal flaws, family life, doubts; only shows traits serving the 'living tradition' thesis (e.g., no mention of her failed marriage hinted in footnote).
- Step 3: Challenge side — the very selectivity creates a coherent artistic persona; her consistency across studio/exhibition proves integrated character, not mere mouthpiece.
- Step 4: Evidence for challenge — the critic incident shows spontaneous wit ("stones speak") unscripted by thesis.
- Step 5: Nuanced verdict — she is a 'strategic personification': real person distilled to essential traits that embody the argument. The author's lens reveals, not reduces.

ANSWER: The statement is partially valid but incomplete. The author indeed curates Yashodhara — omitting personal struggles, showing only traits that advance the 'living tradition' thesis: technical mastery, social vision, philosophical clarity. This instrumentalization risks making her a mouthpiece. However, the consistency of her character across private (studio rituals) and public (exhibition negotiations) spheres suggests integrity, not construction. The unscripted critic response — "stones speak, not critics" — reveals spontaneous wit that transcends thesis-service. She emerges as a strategic personification: a real artist distilled to her essential artistic self, where personality and philosophy fuse. The author's lens reveals the person through the argument, not instead of it.

DIFFICULTY: hard