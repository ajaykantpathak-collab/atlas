## DEFINITION
Character analysis of supporting characters involves examining the roles, traits, motivations, and development of characters who are not the main protagonist but contribute significantly to the narrative, themes, and the protagonist's journey in a literary text.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student can identify at least three supporting characters from the chapter, describe their key traits with specific textual evidence, explain their narrative function (foil, catalyst, thematic embodiment), and analyze their relationship with the protagonist and the chapter's central themes.

## SCOPE_BOUNDARY
This node covers only the supporting characters in the Class 12 Hindi Antra Chapter 10 ("Izse?ku" by Jai Shankar Prasad). It does not cover the protagonist's analysis (addressed in node c12_hin_a_cbse_10_004) or thematic analysis (addressed in subsequent nodes).

## WALKTHROUGH
Imagine you are writing a character reference letter for a friend's college application — you would select specific incidents that reveal their personality, not just list adjectives. Similarly, analyzing supporting characters begins with listing every character who interacts meaningfully with the protagonist. Next, re-read their scenes, noting their dialogue, actions, and the protagonist's reactions. Then, group these observations into 2-3 dominant traits per character. Ask: "How does this character push the protagonist toward change or reveal a thematic idea?" Finally, write a structured response using the PEEL method (Point, Evidence, Explanation, Link) for each character. The key insight: supporting characters are not background decoration; they are deliberate constructs that shape the protagonist's arc and embody the author's thematic concerns.

## DIAGNOSTIC_QUESTION_1
Name any three supporting characters from the chapter "Izse?ku" and state one dominant trait for each.

## DIAGNOSTIC_ANSWER_1
Correct answer: (1) The narrator's father (firk th) — authoritative and tradition-bound; (2) The poet Mikè;k; cnjhukjk;.k pkSèkjh — eccentric and free-spirited; (3) The teacher ia- osQnkjukFk th — observant and encouraging. A wrong answer that merely lists names without traits, or assigns traits like "kind" or "strict" without textual basis, reveals the student cannot distinguish between a character's role and their characterized personality.

## DIAGNOSTIC_QUESTION_2
In your own words, explain how the poet Mikè;k; cnjhukjk;.k pkSèkjh functions as a foil to the narrator's father in the chapter.

## DIAGNOSTIC_ANSWER_2
Correct answer: The father represents orthodox tradition, discipline, and practical worldly success, while the poet embodies artistic freedom, spontaneity, and unworldly passion. Their contrasting values create a tension that pulls the young narrator between two worlds, highlighting the theme of tradition versus modernity. A wrong answer that only describes their surface differences (e.g., "one is a father, one is a poet") without linking to the narrator's internal conflict shows the student misunderstands the literary concept of a foil.

## DIAGNOSTIC_QUESTION_3
Using the PEEL structure, write a short paragraph analyzing how the teacher ia- osQnkjukFk th's invitation to the narrator to visit his home reveals the teacher's character.

## DIAGNOSTIC_ANSWER_3
Correct answer: Point — The teacher is perceptive and nurturing. Evidence — He notices the narrator's hesitation and personally invites him, saying "vjs! tc iwQV tkbZ rcS pyr vkogA" (Come! When you are free, come walking). Explanation — This shows he reads the narrator's shyness and removes barriers by making the visit informal. Link — His action contrasts with the father's rigid expectations, offering the narrator a safe space for literary growth. A wrong answer that quotes the line but does not explain its significance or link to broader characterization indicates the student cannot move from evidence to analysis.

## DIAGNOSTIC_QUESTION_4
Compare the narrative functions of the father and the poet Mikè;k; cnjhukjk;.k pkSèkjh. How does each advance the protagonist's development differently?

## DIAGNOSTIC_ANSWER_4
Correct answer: The father acts as a restraining force — his disapproval of "fuLlansg" (frivolous) literary pursuits forces the narrator to defend his passion, strengthening his resolve. The poet acts as an enabling force — his chaotic, joyful literary circle validates the narrator's identity as a writer. Together, they create a dialectic that shapes the narrator's artistic identity. A wrong answer that treats both as simply "influential" without distinguishing the nature of their influence (restriction vs. liberation) shows the student cannot analyze functional differences between characters.

## DIAGNOSTIC_QUESTION_5
Evaluate the statement: "The supporting characters in 'Izse?ku' are mere stereotypes — the strict father, the mad poet, the kind teacher — and lack psychological depth." Defend or refute with evidence.

## DIAGNOSTIC_ANSWER_5
Correct answer: Refute. While they occupy archetypal roles, the author gives them idiosyncratic details that transcend stereotype: the father's secret pride when the narrator's work is recognized, the poet's precise linguistic theories ("ukxj viHkza'k ls..."), the teacher's spontaneous poetry recitation on a rooftop. These moments reveal inner lives that serve the memoir's authenticity. A wrong answer that agrees with the statement reveals the student confuses archetype with stereotype and misses the author's subtle humanization of these figures.

## DIAGNOSTIC_QUESTION_6
Create a diary entry from the perspective of the poet Mikè;k; cnjhukjk;.k pkSèkjh on the day he first meets the young narrator. Include at least two specific references to his characterization in the chapter.

## DIAGNOSTIC_ANSWER_6
A strong answer will adopt the poet's distinctive voice (playful, linguistically inventive), reference his habit of composing spontaneously ("dfoÙk iwjk gks x;k"), and show his immediate recognition of the narrator's potential ("esjk >qdko c<+rk x;k"). A weak answer that writes in generic diary style without capturing his eccentric speech patterns or his philosophy of language ("ehj¾ leqnz$tk¾iq=kh$iqj") indicates the student has not internalized the character's unique textual fingerprint.

## COMMON_MISCONCEPTION
Students often treat supporting characters as static plot devices — listing their actions but not analyzing why the author crafted them that way. For example, they write "The father scolds the narrator for reading poetry" but miss that this scolding *establishes the central conflict of tradition vs. artistic vocation*. They also confuse "trait" with "role": calling the poet "a mentor" describes his function, not his personality (which is erratic, generous, linguistically obsessed). This error costs marks in board exams because CBSE rubrics reward "analysis of character's contribution to theme" over mere description.

## ON_FAILURE
If the student exhibits this misconception: (1) Have them re-read only the scenes where the father, poet, and teacher appear, highlighting every verb and adjective attached to them. (2) Create a three-column chart: Character | Textual Evidence (quote/paraphrase) | Inferred Trait | Thematic Link. (3) Practice writing one PEEL paragraph for each character using the chart. (4) Re-attempt Diagnostic Question 4 as a check — the answer must distinguish *how* each character's influence operates differently.

## BUILDS_ON
Character Analysis: Protagonist (c12_hin_a_cbse_10_004) — understanding the protagonist's arc is necessary to see how supporting characters shape it.

## LEADS_TO
Theme: Primary Theme and Message (c12_hin_a_cbse_10_006) — supporting characters embody thematic tensions that the theme node will synthesize.

## PREREQUISITE_NODE_IDS
c12_hin_a_cbse_10_001, c12_hin_a_cbse_10_002, c12_hin_a_cbse_10_003, c12_hin_a_cbse_10_004, c11_hin_ar_cbse_01_005
## PREREQUISITE_REASONS
c12_hin_a_cbse_10_001: Provides biographical context of Jai Shankar Prasad essential for understanding the memoir's perspective.
c12_hin_a_cbse_10_002: Plot knowledge identifies which scenes feature supporting characters.
c12_hin_a_cbse_10_003: Setting details (e.g., the poet's chaotic household) reveal character through environment.
c12_hin_a_cbse_10_004: Protagonist analysis establishes the baseline against which supporting characters act as foils.
c11_hin_ar_cbse_01_005: Class 11 foundation in supporting character analysis techniques (trait identification, textual evidence, functional role).

## FORWARD_NODE_IDS
c12_hin_a_cbse_10_006, c12_hin_a_cbse_10_007, c12_hin_a_cbse_10_013, c12_hin_a_cbse_10_012

## FORWARD_REASONS
c12_hin_a_cbse_10_006: Primary theme (tradition vs. modernity) emerges directly from father-poet opposition analyzed here.
c12_hin_a_cbse_10_007: Secondary themes (guru-shishya parampara, artistic vocation) are carried by specific supporting characters.
c12_hin_a_cbse_10_013: Critical thinking questions require synthesized character insights to evaluate author's craft.
c12_hin_a_cbse_10_012: Supporting characters (father, Premchand, Yashpal) provide the foil for inferences about the protagonist.  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
N/A

## CHAIN_DESCRIPTION
c12_hin_a_cbse_10_004 -> c12_hin_a_cbse_10_005 -> c12_hin_a_cbse_10_006

## THIS_FORMULA
N/A - conceptual

## FORMULA_VARIABLES
N/A

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
analytical

## CROSS_SUBJECT
N/A | Understanding how personal memoirs reflect historical transition (colonial modernity vs. tradition) through character dynamics.
 N/A | Analyzing interpersonal influence (parental authority, mentorship) on identity formation in adolescence.
## PREREQ_CONCEPT
Ability to extract character traits from textual evidence and distinguish between a character's narrative role and their individualized personality.

## PREREQ_BEFORE
Student must have completed reading the chapter and the protagonist analysis node (c12_hin_a_cbse_10_004).

## PREREQ_STUCK
If stuck, revisit the protagonist analysis node (c12_hin_a_cbse_10_004) and the plot/structure node (c12_hin_a_cbse_10_002) to map character-scene connections.

## WORKED_EXAMPLE_1
PROBLEM: Analyze the father (firk th) as a supporting character in "Izse?ku" using the PEEL method.
STEPS:
- Step 1: Identify all scenes where the father appears — the opening memory of him reading poets aloud, the scolding over "fuLlansg" friends, the moment he hides books, the final acknowledgment of the narrator's publication.
- Step 2: Extract textual evidence for each scene — e.g., "os dHkh&dHkh lquk;k djrs Fks" (he would sometimes listen), "okfdI+kQ gks x;k" (became angry), "mUgha fnuksa ia- osQnkjukFk th ikBd us... dk'kh Hkstk" (teacher gave a job).
- Step 3: Infer dominant traits — authoritative (controls household reading), tradition-bound (values practical employment over art), secretly proud (final scene).
- Step 4: Determine narrative function — he is the primary antagonist to the narrator's artistic desire, creating the central conflict; his eventual acceptance resolves the arc.
- Step 5: Link to theme — his trajectory from opposition to quiet acceptance mirrors the society's shifting attitude toward Hindi literature, embodying the theme of tradition negotiating modernity.
REASONING: This step-by-step moves from concrete textual moments to abstract thematic function, ensuring every claim is evidence-based. The PEEL structure forces the student to explain *how* the evidence supports the trait, not just state it.
ANSWER: The father is a complex antagonist whose authority stems from genuine concern for his son's livelihood in a colonial economy. His opposition to "fuLlansg" literary circles is not mere conservatism but pragmatic protection. The author humanizes him through the final scene where he "ns[k cM+s izlUu gq, vkSj cgqr nwj esjs lkFk ckrphr djrs gq, x,A" — a moment of unspoken validation that elevates him from a stereotype to a symbol of a generation in transition.

## WORKED_EXAMPLE_2
PROBLEM: Analyze the poet Mikè;k; cnjhukjk;.k pkSèkjh as a catalyst for the narrator's literary identity.
STEPS:
- Step 1: Locate the poet's two major appearances — the rooftop poetry recitation ("pkSèkjh lkgc us iwNkA ¶dfg, D;k gky gS\¸") and the literary gathering at his house ("blh ls mUgksaus ge yksxksa dk uke ^fuLlansg* yksx j[k NksM+k Fks").
- Step 2: Note his distinctive speech and behavior — he composes instantly ("vafre pj.k jg x;k Fkk"), values linguistic purity ("ukxj viHkza'k ls..."), lives chaotically ("veyk... deZpkjh eaMy").
- Step 3: Infer traits — spontaneous creativity, intellectual rigor beneath bohemian exterior, generosity (feeds young writers).
- Step 4: Explain catalytic function — he provides the narrator's first literary community, validates the narrator's passion, and models a life devoted to art.
- Step 5: Connect to theme — he represents the "modern" Hindi writer forging a new literary language, contrasting with the father's world; his circle names themselves "fuLlansg" (carefree), reclaiming the insult as identity.
REASONING: The poet appears briefly but his impact is disproportionate — a classic catalytic character. The steps ensure the student links his eccentricities to his thematic role as the embodiment of the new literary movement.
ANSWER: Mikè;k; cnjhukjk;.k pkSèkjh is the catalyst who transforms the narrator's private scribbling into a public vocation. His rooftop recitation — where he turns a mundane conversation about tea into a poem ("[kaHkk Vsfd [kM+h tSls ukfj eqxykus dh") — demonstrates poetry as a way of being, not just writing. By welcoming the narrator into the "fuLlansg" circle, he provides the affirmation the father withholds. His linguistic theory ("ehj¾ leqnz$tk¾iq=kh$iqj") shows the intellectual depth behind the madness, making him the architect of the narrator's artistic philosophy.

## WORKED_EXAMPLE_3
PROBLEM: Compare the father and the poet as thematic foils. How does their opposition structure the narrator's coming-of-age?
STEPS:
- Step 1: List father's values — stability, service, Sanskritized Hindi, paternal authority, practicality.
- Step 2: List poet's values — artistic freedom, linguistic innovation (Khari Boli), communal creativity, anti-authoritarianism, spiritual pursuit through art.
- Step 3: Identify the narrator's position — caught between, initially secretive ("eSa cM+h pkg vkSj oqQrwgy dh n`f"V ls... u tkus fdu&fdu Hkkoukvksa esa yhu gksdj ns[krk jgk"), later integrating both.
- Step 4: Trace the narrative arc — childhood fear of father → adolescent rebellion via poet's circle → adult synthesis (becomes a writer *and* a responsible householder).
- Step 5: Analyze structural role — the father represents the *thesis* (tradition), the poet the *antithesis* (modernity), the narrator the *synthesis* (modern Hindi writer rooted in tradition).
- Step 6: Evaluate author's craft — Prasad uses his own life to dramatize the birth of modern Hindi literature; the characters are not just people but historical forces personified.
REASONING: This worked example combines character analysis with thematic synthesis, a skill required for board competency questions and competitive exam essays. The dialectical framework (thesis-antithesis-synthesis) provides a rigorous analytical lens beyond simple compare-contrast.
ANSWER: The father and poet are not merely contrasting personalities; they are the dialectical poles of the narrator's historical moment. The father's insistence on "mnwZ&vaxzs"kh" education and service mirrors the colonial bureaucratic ideal. The poet's "ukxj viHkza'k" theory and "fuLlansg" circle enact the nationalist linguistic project. The narrator's journey from hiding in "Hkkoukvksa" (alleys) to sitting "ia- osQnkjukFk th ikBd" (teacher's chair) resolves the dialectic: he becomes a writer who honors tradition (dedicating work to father's memory) while innovating form (Prasad's poetic experiments). This structural reading is what distinguishes a board-level answer from a summary.

## COMPETENCY_QUESTION_1
QUESTION: (Case-based) Read the following excerpt from the chapter: "pkSèkjh lkgc dgrs tk jgs gSa] ¶vjs! tc iwQV tkbZ rcS pyr vkogA¸ var esa fpeuh Xyksc osQ lfgr pdukpwj gks xbZ] ij pkSèkjh lkgc dk gkFk ySEi dh rjI+kQ u c<+kA" Analyze how this moment reveals the poet's character and his relationship with the narrator. Use the PEEL structure.
COMPETENCY: Textual analysis and inference
STEPS:
- Step 1: Identify the context — the poet is unwell, yet continues hosting the literary gathering.
- Step 2: Point — The poet prioritizes his literary community over personal comfort.
- Step 3: Evidence — "pdukpwj gks xbZ" (was unwell) but "gkFk ySEi dh rjI+kQ u c<+k" (did not reduce the tea's quantity).
- Step 4: Explanation — The tea ritual symbolizes the nurturing of the "fuLlansg" circle; his refusal to diminish it shows his commitment to the collective over the self.
- Step 5: Link — This generosity mirrors his earlier welcome of the narrator; it establishes him as the benevolent center of a literary ecosystem that sustains the narrator's growth.
ANSWER: The poet's insistence on maintaining the tea ritual despite illness reveals his character as a nurturing patriarch of the literary community. The "ySEi" (tea) is not merely a beverage but a ritual of inclusion — the same hospitality that first drew the narrator in. By refusing to "c<+k" (reduce) it, he signals that the circle's continuity matters more than his bodily needs. This moment deepens our understanding of his relationship with the narrator: he is not a distant mentor but a host who sustains the very space where the narrator finds his voice. The narrator's observation of this detail ("esaus pkgk fd...") marks his transition from passive recipient to conscious chronicler of the poet's legacy.
DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: (Assertion-Reason) Assertion (A): The supporting characters in "Izse?ku" function primarily as thematic symbols rather than psychologically realistic individuals. Reason (R): Their dialogues are highly stylized and they appear only at key thematic junctures in the narrative. Evaluate the assertion and reason. Is R the correct explanation of A?
COMPETENCY: Critical evaluation of literary characterization
STEPS:
- Step 1: Assess Assertion — Partially true: characters *do* carry thematic weight (father = tradition, poet = modernity), but the text also gives them idiosyncratic, non-symbolic details (father's secret pride, poet's linguistic theory, teacher's rooftop recitation).
- Step 2: Assess Reason — Partially true: dialogues are stylized (poet's linguistic formula), but they also appear in mundane moments (father listening to poets, teacher's casual invitation).
- Step 3: Determine relationship — R does not fully explain A because the "stylized" moments coexist with realistic details that undermine a purely symbolic reading.
- Step 4: Synthesize — The author uses *selective stylization* to heighten thematic resonance while grounding characters in memoiristic realism.
- Step 5: Conclude — Both A and R are partially correct but overstated; R is not the correct explanation of A because the characters exceed their symbolic functions.
ANSWER: Assertion (A) is an overgeneralization. While the father and poet clearly embody thematic poles, Jai Shankar Prasad invests them with specific, non-symbolic humanity: the father's hidden joy at the narrator's job, the poet's precise linguistic philosophy ("ehj¾ leqnz$tk¾iq=kh$iqj"), the teacher's spontaneous rooftop poetry. Reason (R) is also overstated — dialogues are not *only* stylized (the teacher's "vjs! tc iwQV tkbZ rcS pyr vkog" is colloquial), and characters appear in transitional scenes, not just thematic climaxes. Therefore, R does not correctly explain A. The author's achievement is precisely the fusion of symbolic function and individual texture — a hallmark of modernist Hindi memoir.
DIFFICULTY: hard