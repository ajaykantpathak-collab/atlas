## DEFINITION
Literal comprehension questions require students to retrieve information explicitly stated in the text, while inferential comprehension questions demand logical deductions by combining textual clues with background knowledge to uncover implied meanings not directly written.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student must independently distinguish between literal and inferential question types, locate precise textual evidence for literal answers, and construct inferential answers using a minimum of two textual clues linked by logical reasoning, presented in a structured PEEL (Point, Evidence, Explanation, Link) paragraph.

## SCOPE_BOUNDARY
This node covers strategies for answering literal and inferential questions based solely on the prose narrative "vkyks&vk¡èkkfj" (Chapter 3, Vitan). It does not cover critical evaluation of author's craft, creative writing extensions, or grammatical analysis of the text.

## WALKTHROUGH
Imagine you are asked: "Why did the narrator's employer (rkrq'k) give her a diary and pen?" A struggling student might guess "because he was kind." Instead, start by reading the question carefully and underlining keywords: *employer, diary, pen, why*. Scan the text for these nouns. You find the episode where rkrq'k hands her a diary saying, "Write your life story." Now ask: what events led to this? The text shows he noticed her interest in reading, her struggle with literacy, and her desire to record her experiences. Connect these clues: his gift was not random kindness but a deliberate act to empower her voice. The key insight: inferential answers are built by stitching together explicit details like a puzzle, not by importing outside opinions.

## DIAGNOSTIC_QUESTION_1
What is the primary difference between a literal comprehension question and an inferential comprehension question?

## DIAGNOSTIC_ANSWER_1
A literal question asks for information directly stated in the text (e.g., "What did the narrator cook?"), while an inferential question requires deriving meaning from clues (e.g., "Why did the narrator feel empowered?"). A wrong answer that says "literal questions are easy and inferential are hard" reveals the student confuses difficulty level with cognitive process, missing the core distinction: explicit vs. implicit information.

## DIAGNOSTIC_QUESTION_2
In the chapter, the narrator says, "eq>s lcsjs tYnh mBdj] fcuk oqQN [kk,&fi,] dke ij vkuk iM+rk Fkk." (I used to go to work for long hours without eating or drinking.) Is this statement a literal fact or an inferential conclusion? Justify your answer in one sentence.

## DIAGNOSTIC_ANSWER_2
It is a literal fact because the narrator explicitly states her routine of working long hours without food in the text. A wrong answer labeling it "inferential" shows the student mistakes first-person narration for interpretation, failing to recognize that a character's direct description of their own actions is explicit textual evidence.

## DIAGNOSTIC_QUESTION_3
A question asks: "How did rkrq'k's attitude toward the narrator change after she started writing?" List two explicit textual clues you would use to answer this inferential question.

## DIAGNOSTIC_ANSWER_3
Clue 1: rkrq'k initially dismissed her writing ("rqe ugha le>ksxh") but later read her diary and praised her expression ("rqEgkjh ys[ku mRÑ"V gSA"). Clue 2: He shifted from discouraging her ("rqEgsa bu lc ckrksa dks ysdj vHkh ekFkk&iPph djus dh ”k:jr ugha gSA") to actively supporting her ("fy[kks vkSj i<+ks"). A student who quotes only his final praise misses the necessary contrast to infer *change*.

## DIAGNOSTIC_QUESTION_4
Compare the narrator's relationship with her first employer (lquhy) and her later employer (rkrq'k) using the textual evidence of how each reacted to her literacy efforts. What does this comparison reveal about the theme of empowerment?

## DIAGNOSTIC_ANSWER_4
Lquhy mocked her literacy ("ckrsa djrs&djrs og eq>ls cksys] yks] ckr djksA") and questioned her presence, while rkrq'k provided tools (diary, pen) and validated her writing ("rqEgkjh fp_h dbZ fnu igys feyh Fkh..."). This contrast reveals empowerment flourishes where agency is nurtured, not suppressed. A weak answer merely lists behaviors without linking them to the thematic idea of empowerment through education.

## DIAGNOSTIC_QUESTION_5
Evaluate the claim: "The narrator's ability to write her autobiography was solely due to rkrq'k's support." Use textual evidence to defend or refute this.

## DIAGNOSTIC_ANSWER_5
The claim is partially true but incomplete. Evidence: rkrq'k gave diary/pen, encouraged writing, and connected her to publishers. Counter-evidence: The narrator's intrinsic drive ("eSa viuk dke fd, tkvksA cl] fy[kks vkSj i<+ks"), her prior secret reading ("lquhy us muls dgk] lj] vkius dgk Fkk u\ eSa bls ys vk;k gw¡A"), and support from others (tsBw, 'kfeZyk nh) were equally crucial. A student agreeing wholly ignores the text's emphasis on her self-motivation ("esjh bPNk gksrh gSA").

## DIAGNOSTIC_QUESTION_6
Create an inferential question about the narrator's children (cPps) that requires connecting their educational progress to the narrator's own journey, and provide a model answer using two textual clues.

## DIAGNOSTIC_ANSWER_6
Question: "How does the narrator's literacy journey influence her children's attitude toward education?" Model Answer: The narrator's learning inspires her children to value education; Clue 1: "cPps vc u rks igys dh rjg ”kjk&”kjk lh ckr ij jksus&fpYykus yxrs] u gh cseryc bèkj&mèkj HkVdrsA" (children no longer quarrel over trivialities but discuss serious matters). Clue 2: "mudh i<+kbZ&fy[kkbZ Bhd py jgh gSA" (their reading/writing improves). A poor answer would state "they became educated" without citing the behavioral shift as evidence.

## COMMON_MISCONCEPTION
Students often treat inferential questions as "opinion questions" and answer with personal feelings ("I think she felt sad") instead of textual inference ("The text shows she felt sad because she describes her heart sinking when..."). This error stems from confusing *inference* (logic + text) with *subjective reaction* (personal emotion). For example, when asked "Why did the narrator leave the first house?", a student might write "Because she didn't like it" instead of citing the text: "lquhy us eq>s Hkhrj ys x, vkSj lc le>k&cq>k fn;k" (lquhy scolded her and gave strict orders).

## ON_FAILURE
1. Ask the student to highlight every verb of speaking/thinking/feeling attributed to the narrator in a selected paragraph. 2. Have them label each as "Explicit" (direct quote) or "Implicit" (implied by action). 3. Practice converting an implicit label into an inferential answer stem: "The text shows X when it says Y, therefore Z." 4. Reinforce with a mini-exercise: give three literal facts from the chapter and ask the student to generate one valid inference that combines them.

## BUILDS_ON
Understanding the plot sequence (c11_hin_v_cbse_03_002) and character motivations (c11_hin_v_cbse_03_004, c11_hin_v_cbse_03_005) is essential because literal retrieval relies on narrative order and inferential reasoning depends on consistent character traits.

## LEADS_TO
This node enables Critical Thinking: Analysis and Interpretation (c11_hin_v_cbse_03_013) where students evaluate themes and authorial intent, and Writing Skills (c11_hin_v_cbse_03_014) where they compose structured analytical paragraphs using the same evidence-based reasoning.

## PREREQUISITE_NODE_IDS
c11_hin_v_cbse_03_002, c11_hin_v_cbse_03_004, c11_hin_v_cbse_03_005, c11_hin_v_cbse_03_010, c11_hin_v_cbse_03_011, c11_hin_v_cbse_03_008, c11_hin_v_cbse_03_009

## PREREQUISITE_REASONS
c11_hin_v_cbse_03_002: Plot knowledge provides the chronological framework to locate literal answers.
c11_hin_v_cbse_03_004: Protagonist analysis supplies the personality traits needed to justify inferences about her choices.
c11_hin_v_cbse_03_005: Supporting character dynamics offer the relational context for inferring motives of employers/family.
c11_hin_v_cbse_03_010: Vocabulary in context ensures accurate interpretation of key Hindi terms that carry thematic weight.
c11_hin_v_cbse_03_011: Grammar usage awareness helps distinguish narrator's voice from reported speech in textual evidence.
c11_hin_v_cbse_03_008: Comprehension questions (literal/inferential) require quoting imagery as evidence and explaining metaphorical meaning for inferential answers.  
c11_hin_v_cbse_03_009: Comprehension questions require identifying and explaining irony/symbolism as textual evidence for inferential answers.  

## FORWARD_NODE_IDS
c11_hin_v_cbse_03_013, c11_hin_v_cbse_03_014, c11_hin_v_cbse_03_015, c12_hin_v_cbse_03_012

## FORWARD_REASONS
c11_hin_v_cbse_03_013: Critical thinking requires the evidence-combining skill honed here to analyze broader themes.
c11_hin_v_cbse_03_014: Writing analytical answers uses the PEEL structure practiced in inferential responses.
c11_hin_v_cbse_03_015: Discussion points demand the same textual grounding to support oral arguments.
c12_hin_v_cbse_03_012: Prior practice with same skill at lower complexity.  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
none

## CHAIN_DESCRIPTION
c11_hin_v_cbse_03_002 -> c11_hin_v_cbse_03_012 -> c11_hin_v_cbse_03_013

## THIS_FORMULA
Inferential Answer = (Textual Clue 1 + Textual Clue 2 + Logical Connector) → Thematic Insight

## FORMULA_VARIABLES
Textual Clue 1: First explicit detail from the text supporting the inference.
Textual Clue 2: Second explicit detail from the text that reinforces or contrasts with the first.
Logical Connector: Reasoning phrase (e.g., "this suggests," "therefore," "consequently") linking clues to conclusion.
Thematic Insight: The inferred meaning tied to a larger idea in the chapter (e.g., empowerment, gender, education).

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
linguistic

## CROSS_SUBJECT
c11_history_nationalism | Both require synthesizing multiple primary sources (textual clues) to construct a historical argument (inference), moving beyond surface facts to interpret motives.
c11_geography_human_development | Inferring quality of life from indicators (literacy, income) mirrors deriving character growth from textual behaviors (reading, writing, employment changes).
c11_economics_consumer_behaviour | Analyzing a character's choices (narrator's employment decisions) parallels evaluating consumer decisions based on stated preferences vs. revealed preferences.

## PREREQ_CONCEPT
Ability to distinguish between directly stated information and implied meaning in a narrative text.

## PREREQ_BEFORE
Student must have read the full chapter "vkyks&vk¡èkkfj" and be familiar with the narrator's major life events: early employment, literacy struggle, relationship with rkrq'k, and eventual authorship.

## PREREQ_STUCK
If stuck, review the chapter summary and character sketches from nodes c11_hin_v_cbse_03_002 and c11_hin_v_cbse_03_004 to rebuild event sequence and trait inventory.

## WORKED_EXAMPLE_1
PROBLEM: Answer the inferential question: "Why did the narrator feel 'cgqr [kjkc' (very pained) when she saw the women carrying loads on their heads while going to fetch water?" (Reference: middle of chapter, water-fetching scene).

STEPS:
- Step 1: Identify question type – "Why did she feel..." signals inferential; need to explain emotion using textual clues.
- Step 2: Locate the scene – Scan for keywords "water," "fetch," "head," "women," "pain." Find the passage where narrator describes V^h&is'kkc (water scarcity) and women carrying loads.
- Step 3: Extract Clue 1 – Narrator explicitly states: "yM+osQ&yM+fd;ksa] cM+s&cw<+s] lHkh gkFk esa ikuh dh cksry ys V^h osQ fy, ckgj tkrsA" (women, old and young, all carry water pots on heads).
- Step 4: Extract Clue 2 – Narrator contrasts her current relatively better condition: "vc os ogka¡ cksry l¡Hkkysa ;k lqvj Hkxk,¡! eq>s rks ;g ns[k&lqudj cgqr [kjkc yxrk" (now they have taps/pipes? but this sight pains me).
- Step 5: Apply logical connector – The pain arises from empathy rooted in her own past suffering; she recognizes the unchanging drudgery of women's lives despite her personal progress.
- Step 6: Formulate thematic insight – This reflects the chapter's theme of collective female suffering vs. individual escape; her pain is solidarity, not self-pity.

REASONING: The steps move from question decoding to evidence gathering, then synthesis. Using two contrasting clues (others' current hardship vs. narrator's retrospective empathy) creates a robust inference grounded in the text's gender-and-labor theme.

ANSWER: The narrator feels deep pain because the sight of women carrying water pots on their heads (Clue 1) mirrors the inescapable drudgery she once endured, and despite her own improved circumstances (Clue 2), she feels solidarity with their unchanging suffering, highlighting the theme that individual mobility does not erase collective gendered labor.

## WORKED_EXAMPLE_2
PROBLEM: A literal question asks: "What specific gift did rkrq'k give the narrator to encourage her writing, and on what occasion?" Answer using direct textual evidence.

STEPS:
- Step 1: Identify question type – "What specific gift" and "on what occasion" demand explicit facts.
- Step 2: Scan for nouns – "gift," "rkrq'k," "writing," "diary," "pen," "occasion."
- Step 3: Locate exact sentences – Find: "rkrq'k us ,d fnu eq>ls cksys] csch] rqEgkjh fp_h vkbZ gSA... mUgksaus crk;k fd fp_h dksydkrk ls muosQ ,d caèkq us Hksth gSA" and later "rkrq'k us eq>ls cSB tkus dks dgk vkSj fiQj fp_h i<+dj lqukus yxs] fiz; csch] eSa crk ugha ldrk rqEgkjh Mk;jh i<+dj eq>s fdruk vPNk yxk!"
- Step 4: Extract precise details – Gift: "fp_h" (diary) and "dkWih" (pen) – actually earlier: "rkrq'k us viuh fy[kus dh Vsfcy osQ Mªkj ls ,d isu vkSj dkWih fudkyh" (rkrq'k took out a pencil and a notebook from his writing kit). Occasion: After narrator expressed desire to write, during a conversation where rkrq'k read her earlier attempts.
- Step 5: Verify no inference needed – The text explicitly states the items and the immediate context (he handed them after she hesitated to share her writing).
- Step 6: Construct concise answer – Gift: a pencil and a notebook (later a diary). Occasion: When rkrq'k discovered her writing attempts and urged her to continue.

REASONING: Literal questions require precision; the steps enforce direct textual lookup without interpretation. Noting the sequence (pencil/notebook first, diary later) prevents conflation of two separate gifting moments.

ANSWER: rkrq'k first gave her a pencil and a notebook from his own writing kit when he learned she wanted to write but hesitated; later, he gifted her a diary (fp_h) after a publisher (caèkq) suggested she write her life story.

## WORKED_EXAMPLE_3
PROBLEM: Combine literal and inferential skills: "Trace the narrator's transition from illiteracy to authorship using three key turning points from the text. For each turning point, provide one literal detail and one inference about its impact on her agency."

STEPS:
- Step 1: Define scope – Need three turning points spanning the narrative arc.
- Step 2: Select Turning Point 1 (Early literacy spark) – Literal: "lquhy us muls dgk] lj] vkius dgk Fkk u\ eSa bls ys vk;k gw¡A" (lquhy shows her a book she once gave). Inference: This re-encounter awakens her dormant desire to read, planting the seed of agency.
- Step 3: Select Turning Point 2 (Active learning) – Literal: "rkrq'k us eq>ls cSB tkus dks dgk vkSj fiQj fp_h i<+dj lqukus yxs" (rkrq'k makes her sit and read diary aloud). Inference: Structured mentorship transforms passive wish into active skill, shifting power dynamic.
- Step 4: Select Turning Point 3 (Public authorship) – Literal: "Hkxoku us le>us dh {kerk gh ugha nh eq>s] ysfdu eS le>uk pkgrh gw¡!... fp_h fy[kus dk flj&iSj eSa tkurh ugha Fkh fiQj Hkh tSls cu iM+k fy[kkA" (Publisher didn't teach her, but she learned; didn't know craft but wrote anyway). Inference: She claims professional identity independently, achieving full agency beyond patronage.
- Step 5: Synthesize pattern – Each point shows expanding circle: accidental re-exposure → guided practice → autonomous creation.
- Step 6: Write integrated response using PEEL for each point.

REASONING: This multi-step task demands both retrieval (literal) and synthesis (inferential) across the whole chapter, mirroring board exam long-answer questions. The three-point structure ensures comprehensive coverage.

ANSWER: 
1. Re-exposure (Literal: lquhy shows her old book; Inference: reignites latent literacy desire). 
2. Mentored practice (Literal: rkrq'k makes her read diary aloud; Inference: converts desire into skill via structured support). 
3. Autonomous publication (Literal: publisher accepts manuscript without formal training; Inference: she seizes professional identity independently). 
Together, they map her journey from object of others' actions to subject of her own narrative.

## COMPETENCY_QUESTION_1
QUESTION: "The narrator says, 'eq>s ;g ckr cM+h e”ksnkj yxrh fd 'k£eyk nh us esjs ltus&èktus osQ ckjs esa iwNk D;ksafd ltuk&èktuk eq>s dHkh vPNk ugha yxkA' (I found it very strange that the elder daughter-in-law asked about my reading/writing because it never seemed important to me). Using this quote, explain how the narrator's self-perception of her literacy differs from how others perceive it. Support with two textual evidences."

COMPETENCY: Textual Evidence Integration and Perspective Analysis

STEPS:
- Step 1: Deconstruct the quote – narrator's view: literacy unimportant ("ltuk&èktuk eq>s dHkh vPNk ugha yxk"); other's view: important enough to inquire ("'k£eyk nh us ... iwNk").
- Step 2: Find Evidence 1 for narrator's view – Early chapter: "esjk i<+uk&fy[kuk Hkh ugha gks ldkA" (could not read/write) and she accepts it as normal for her class.
- Step 3: Find Evidence 2 for others' view – rkrq'k's persistent encouragement: "rkrq'k us dgk] ns[kks csch] rqe viuk dke fd, tkvksA cl] fy[kks vkSj i<+ksA" (tells her to write/read).
- Step 4: Analyze the gap – Narrator internalizes societal marginalization (literacy not for her), while outsiders (rkrq'k, 'k£eyk nh) see her potential.
- Step 5: Write structured answer linking quote, evidences, and insight about internalized oppression vs. external recognition.

ANSWER: The quote reveals the narrator's internalized belief that literacy is irrelevant to her identity as a domestic worker (Evidence 1: she states she never learned to read/write and accepted it). In contrast, rkrq'k and 'k£eyk nh actively probe and promote her literacy (Evidence 2: rkrq'k commands "fy[kks vkSj i<+ks"), seeing it as a tool for empowerment. This disconnect underscores the theme that marginalized individuals often cannot envision their own agency until others mirror it back to them.

DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: "Design a 4-row comparison table contrasting the narrator's three major employers (lquhy, rkrq'k, Hkksyk nk) on these parameters: (a) Attitude toward her literacy, (b) Treatment of her domestic labor, (c) Impact on her agency. Fill each cell with a specific textual clue (phrase/sentence reference) and a one-sentence inference."

COMPETENCY: Comparative Analysis and Structured Data Synthesis

STEPS:
- Step 1: Identify the three employers and their narrative segments – lquhy (first house), rkrq'k (long-term employer), Hkksyk nk (final house owner).
- Step 2: For each employer, locate textual clues for parameter (a) literacy attitude – e.g., lquhy: "lquhy us muls dgk] lj] vkius dgk Fkk u\ eSa bls ys vk;k gw¡A" (mocking); rkrq'k: "rkrq'k us eq>ls cSB tkus dks dgk vkSj fiQj fp_h i<+dj lqukus yxs" (supportive); Hkksyk nk: "Hkksyk nk cksyk] rks fiQj pyksA" (indifferent/dismissive).
- Step 3: Locate clues for (b) labor treatment – lquhy: "lquhy us eq>s Hkhrj ys x, vkSj lc le>k&cq>k fn;k" (harsh); rkrq'k: "rkrq'k eq>s dke djrs ns[krs rks dHkh&dHkh dgrs] csch] rqe bruk dke oSQls dj ikrh gks!" (acknowledges workload); Hkksyk nk: "Hkksyk nk us dgk] bl rjg cPps osQ lkFk jkr esa rqe vosQyh oSQls jgksxh" (exploitative).
- Step 4: Derive inference for (c) agency impact – lquhy: reinforces subservience; rkrq'k: enables voice; Hkksyk nk: triggers escape.
- Step 5: Present as a clean table with columns: Employer | Literacy Clue + Inference | Labor Clue + Inference | Agency Impact Clue + Inference.

ANSWER: 
| Employer | Literacy Attitude (Clue → Inference) | Labor Treatment (Clue → Inference) | Agency Impact (Clue → Inference) |
|---|---|---|---|
| lquhy | "vkius dgk Fkk u\ eSa bls ys vk;k gw¡A" → Mocks her past attempt, denies legitimacy | "Hkhrj ys x, vkSj lc le>k&cq>k fn;k" → Authoritarian control, no autonomy | "eq>s cdrs&cdrs pyh xbZA" → Forces exit, agency = escape |
| rkrq'k | "fp_h i<+dj lqukus yxs... fy[kks vkSj i<+ks" → Active mentorship, validates voice | "rqe bruk dke oSQls dj ikrh gks!" → Recognizes labor, negotiates rest | "rqEgkjh ys[ku mRÑ"V gSA" → Affirms professional identity |
| Hkksyk nk | No direct literacy interaction → Indifference maintains invisibility | "vosQyh oSQls jgksxh" → Treats as disposable labor | "eSa dy gh dgha vkSj ?kj <w¡<+ yw¡xh" → Catalyzes final self-determination |

DIFFICULTY: hard