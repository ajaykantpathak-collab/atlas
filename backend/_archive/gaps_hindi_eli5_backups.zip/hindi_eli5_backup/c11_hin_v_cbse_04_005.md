## DEFINITION
Character analysis of supporting characters involves examining the roles, traits, and contributions of secondary figures in a text who interact with the protagonist and help develop the theme, plot, or central idea. In non-fiction essays like "Hkkjrh; dyk,¡", supporting characters are real-life individuals, communities, or personified art forms that illustrate and reinforce the main argument about Indian arts' cultural rootedness and diversity.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student can identify at least three supporting figures/groups in the chapter, describe their characteristics using specific textual evidence, and explain how each contributes to the central theme of Indian arts' organic connection to life, region, and tradition.

## SCOPE_BOUNDARY
This node covers analysis of supporting figures such as folk artists (Mithila painters, Rajasthani miniaturists), classical practitioners (Tansen, temple sculptors), patrons (kings, temples), and communities in "Hkkjrh; dyk,¡". It does not cover protagonist analysis (the narrator/collective Indian consciousness), thematic synthesis, or literary device identification, which are addressed in sibling nodes.

## WALKTHROUGH
Imagine you are curating an exhibition on Indian arts. The main theme is "Art as Life" – that's your protagonist. Now, which specific artists, communities, or patrons would you display to prove this theme? The chapter mentions Mithila women painting on walls, Rajasthani miniaturists illustrating manuscripts, temple sculptors carving deities, and classical musicians like Tansen. These are your supporting characters. To analyze them, first locate every specific group or individual named in the text. Next, note what the author says about their methods, materials, and relationship to society. Then, ask: how does this group's practice prove that art arises from daily life and ritual? Finally, write a structured response linking each figure to the central argument using the PEEL method (Point, Evidence, Explanation, Link).

## DIAGNOSTIC_QUESTION_1
Identify any three groups or individuals explicitly named in the chapter who serve as supporting figures for the central idea of Indian arts.

## DIAGNOSTIC_ANSWER_1
Correct answer: Mithila folk painters (women painting kohbar/arikpan), Rajasthani miniature painters (kings' court artists), and classical musician Tansen (or temple sculptors of Khajuraho/Konark). A wrong answer listing only generic categories like "painters" or "musicians" without specific textual references reveals the student cannot distinguish between the chapter's concrete examples and abstract categories, indicating a surface-level reading.

## DIAGNOSTIC_QUESTION_2
Explain in your own words why the author includes the example of Mithila women painting kohbar and aripana designs. What does this example contribute to the essay's argument?

## DIAGNOSTIC_ANSWER_2
Correct answer: The Mithila example shows art emerging from domestic rituals (weddings, festivals) using natural materials, proving that art is not separate from life but embedded in auspicious occasions and women's daily practice. A wrong answer focusing only on "beauty" or "tradition" misses the author's specific argument about art's functional role in social rituals and its creation by non-professional community members, revealing a misunderstanding of the essay's thesis on art-life integration.

## DIAGNOSTIC_QUESTION_3
The chapter states: "fp=kdkjh çkphu dky ls gh gekjs thou dk vfHkUu vax jgk gSA" (The painter has been an integral part of our life since ancient times). Apply this statement to analyze the role of the Rajasthani miniature painter as a supporting character. What specific evidence from the text shows their integration with royal courts and manuscript illustration?

## DIAGNOSTIC_ANSWER_3
Correct answer: The text describes miniature painters working on palace walls, manuscripts, and royal portraits under patronage of kings (e.g., "jktLFkku osQ fpÙkkS<+x<+ esa dykdkj ydM+h osQ eafnjksa ij fp=kdkjh djrs Fks"). This supports the statement by showing painters as documented court professionals whose livelihood and social status were tied to ruling elites, contrasting with folk artists' communal roots. A wrong answer that merely repeats the quote without linking to the miniature painter's specific courtly context shows inability to apply a general claim to a specific supporting figure.

## DIAGNOSTIC_QUESTION_4
Compare the social context of the folk artist (e.g., Mithila painter) and the classical artist (e.g., Tansen or temple sculptor) as supporting characters. How do their differing relationships to patronage and community reveal the essay's nuanced view of "yksd" (folk) vs. "'kkL=kh;" (classical) art?

## DIAGNOSTIC_ANSWER_4
Correct answer: Folk artists create collectively for community rituals (women painting together for kohbar), using local materials, with no individual signatures. Classical artists like Tansen or temple sculptors often receive royal/religious patronage, work within codified rules (shastras), and gain individual recognition. The essay uses both to show that Indian art spans a continuum from anonymous communal expression to celebrated individual mastery, yet both remain rooted in "ukV~;'kkL=k" (traditional knowledge). A wrong answer treating them as identical or completely separate misses the essay's dialectic of continuity and distinction.

## DIAGNOSTIC_QUESTION_5
Evaluate the author's choice to include the temple sculptor (xhrxksfoan) as a supporting figure. Does this example strengthen or weaken the argument that Indian art is inseparable from spiritual practice? Justify with textual evidence.

## DIAGNOSTIC_ANSWER_5
Correct answer: It strengthens the argument. The text explicitly states sculptors expressed devotion through stone ("xhrxksfoan osQ inksa dks urZd vksfM+'kh u`R; osQ ekè;e ls Hkh vfHkO;Dr djrs gSa"), linking tactile craft to metaphysical intent. The Khajuraho/Konark examples show art as temple architecture's soul. A wrong answer claiming it weakens the argument by showing "religious art only" ignores the author's broader definition of spirituality as encompassing all life rituals, revealing a narrow interpretation of the essay's spiritual-secular synthesis.

## DIAGNOSTIC_QUESTION_6
Create a brief character sketch of the "folk artist community" as a collective supporting character in this chapter. Include their motivation, method, material, and social function based solely on textual clues.

## DIAGNOSTIC_ANSWER_6
Correct answer: The folk artist community (e.g., Mithila women, Rajasthani phad painters, Bastar metalworkers) is motivated by ritual necessity and communal celebration. Their method is intergenerational oral transmission and collective creation. Materials are locally sourced: clay, vegetable dyes, stone, metal. Social function: marking life passages (birth, marriage, harvest), preserving myths, and maintaining cosmic order through auspicious symbols. A poor answer inventing individual biographies or modern market motivations shows failure to extract collective character traits from the text's anthropological descriptions.

## COMMON_MISCONCEPTION
Students often believe "supporting characters" only exist in fiction and therefore skip this analysis for essays. In "Hkkjrh; dyk,¡", the author deliberately populates the text with specific artist communities (Mithila women, Rajasthani miniaturists, Tanjore bronze casters, Tansen, temple sculptors) as evidentiary characters. Another error is treating each art form as a mere example rather than a character with agency – e.g., saying "the chapter mentions Madhubani painting" instead of "Mithila women painters use walls as canvas to invoke marital blessings." This reduces living practitioners to static labels, missing the essay's humanistic core.

## ON_FAILURE
1. Have the student re-read the chapter with a highlighter, marking every proper noun referring to a person, community, or specific artist group (e.g., "Mithila ki mahilayen", "Tansen", "Khajuraho ke shilpkar"). 2. Create a three-column table: Figure/Group | Textual Description (quote/paraphrase) | Function in Argument. 3. Model one row together: "Mithila women | 'bhitti chitra', 'kohbar', 'arikpan' using rice paste | Proves art as women's domestic ritual." 4. Assign the student to complete two more rows independently, then discuss how each row supports the thesis.

## BUILDS_ON
Character Analysis: Protagonist (c11_hin_v_cbse_04_004) – understanding the narrator/collective consciousness as the central perspective.

## LEADS_TO
Theme: Primary Theme and Message (c11_hin_v_cbse_04_006) – supporting characters' collective evidence builds the thematic argument.

## PREREQUISITE_NODE_IDS
c11_hin_v_cbse_04_001, c11_hin_v_cbse_04_002, c11_hin_v_cbse_04_003, c11_hin_v_cbse_04_004
## PREREQUISITE_REASONS
c11_hin_v_cbse_04_001: Provides cultural/historical context needed to understand why certain artist communities appear in the text.
c11_hin_v_cbse_04_002: Narrative structure awareness helps locate where supporting figures are introduced (e.g., folk arts section vs. classical arts section).
c11_hin_v_cbse_04_003: Setting/atmosphere knowledge (regional geography, temple vs. court vs. home) informs the supporting characters' environments.
c11_hin_v_cbse_04_004: Protagonist analysis establishes the central perspective (Indian art tradition) against which supporting characters are defined.

## FORWARD_NODE_IDS
c11_hin_v_cbse_04_006, c11_hin_v_cbse_04_007, c11_hin_v_cbse_04_008, c11_hin_v_cbse_04_009, c11_hin_v_cbse_04_010, c11_hin_v_cbse_04_011, c11_hin_v_cbse_04_012, c11_hin_v_cbse_04_013, c11_hin_v_cbse_04_014, c11_hin_v_cbse_04_015, c12_hin_ar_cbse_06_005

## FORWARD_REASONS
c11_hin_v_cbse_04_006: Primary theme emerges from synthesizing what supporting characters collectively demonstrate.
c11_hin_v_cbse_04_007: Secondary themes (regional diversity, tradition-modernity) are carried by specific supporting figures.
c11_hin_v_cbse_04_008: Imagery/metaphor analysis often focuses on descriptions of supporting characters' creations.
c11_hin_v_cbse_04_009: Irony/symbolism may arise from contrasts between folk and classical supporting characters.
c11_hin_v_cbse_04_010: Key vocabulary is often embedded in descriptions of supporting characters' tools/techniques.
c11_hin_v_cbse_04_011: Language usage varies when describing different supporting communities (Sanskritized vs. dialect terms).
c11_hin_v_cbse_04_012: Comprehension questions frequently ask about specific supporting figures' contributions.
c11_hin_v_cbse_04_013: Critical thinking requires evaluating the author's selection of supporting characters.
c11_hin_v_cbse_04_014: Writing tasks may ask to profile a supporting character or compare two.
c11_hin_v_cbse_04_015: Discussion points often center on the relevance of these supporting figures today.
c12_hin_ar_cbse_06_005: Class 11 Vitan foundation on supporting character analysis.  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
No prior class nodes available for cross-subject linking in Hindi Vitan.

## CHAIN_DESCRIPTION
c11_hin_v_cbse_04_004 -> c11_hin_v_cbse_04_005 -> c11_hin_v_cbse_04_006

## THIS_FORMULA
N/A - conceptual

## FORMULA_VARIABLES
N/A

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
conceptual

## CROSS_SUBJECT
c11_history_medieval_india | The chapter's references to court painters (Rajasthani miniatures), temple sculptors (Khajuraho/Konark), and musician Tansen directly connect to medieval Indian history themes of patronage, Bhakti/Sufi movements, and regional kingdoms.
c11_geography_cultural_geography | The mapping of art forms to specific regions (Mithila/Bihar, Rajasthan, Bastar/Chhattisgarh, Tanjore/Tamil Nadu) illustrates cultural geography concepts of region-specific material culture and human-environment interaction.

## PREREQ_CONCEPT
Ability to distinguish between a text's central perspective (protagonist) and its illustrative figures (supporting characters) using textual evidence.

## PREREQ_BEFORE
Student must have completed the Protagonist Analysis node (c11_hin_v_cbse_04_004) and be able to articulate the chapter's central idea: "Indian arts are diverse expressions of a shared civilizational ethos rooted in daily life and tradition."

## PREREQ_STUCK
Review the Protagonist Analysis (node 004) notes on the narrator's voice and thesis, then re-read the chapter's folk arts and classical arts sections to list all named communities/individuals.

## WORKED_EXAMPLE_1
PROBLEM: Analyze the Rajasthani miniature painter as a supporting character in "Hkkjrh; dyk,¡". Use the PEEL structure to show how this figure supports the theme of art-patronage interdependence.

STEPS:
- Step 1: Identify the supporting character. Locate the text segment on Rajasthani miniature painting (pages 61-62). The character is not a single named individual but the professional painter community attached to royal courts.
- Step 2: Extract textual evidence. Note phrases: "jktLFkku osQ fpÙkkS<+x<+ esa dykdkj ydM+h osQ eafnjksa ij fp=kdkjh djrs Fks", "ydM+h osQ eafnjksa ij fp=kdkjh", "mM+hlk osQ iVfp=k dFkk esa dfo t;nso osQ xhrxksfoan dks Hkh mosQjk x;k gSA".
- Step 3: Determine character traits from evidence. Traits: court-dependent, technically skilled in manuscript illustration, narrative-oriented (depicting literary texts), collaborates with poets/scribes, uses mineral pigments on prepared surfaces.
- Step 4: Connect traits to theme. The painter's courtly existence demonstrates the essay's claim that classical art ("'kkL=kh; dyk") thrives on institutional patronage ("ukV~;'kkL=k") and serves elite aesthetic and documentary needs, contrasting with folk art's communal autonomy.
- Step 5: Draft PEEL response. Point: The Rajasthani miniature painter exemplifies the classical artist-patron symbiosis. Evidence: Text states they worked on palace walls and manuscripts for kings. Explanation: This shows art production embedded in feudal power structures, where artists recorded royal glory and religious narratives under directive. Link: Thus, this supporting character validates the essay's argument that Indian art's classical stream evolved within structured patronage systems, distinct from folk art's organic community roots.

REASONING: This worked example models the full analytical arc: from textual location to evidence extraction, trait inference, thematic connection, and structured academic writing. It teaches students to treat a community as a character with agency and historical specificity.

ANSWER: The Rajasthani miniature painter functions as a supporting character representing the classical-artist-under-patronage archetype. Textual evidence shows them creating illustrated manuscripts (like the Ramayana series for Raja Jagat Singh) and wall paintings in palaces, using sophisticated mineral pigments and following iconographic conventions. Their dependence on royal courts for livelihood and status illustrates the essay's argument that 'kkL=kh; dyk (classical art) requires institutional support (ukV~;'kkL=k) and serves codified aesthetic purposes. This contrasts with the Mithila folk painter (another supporting character) who creates autonomously for community rituals. Together, these two supporting characters establish the essay's central dialectic between folk and classical streams.

## WORKED_EXAMPLE_2
PROBLEM: The chapter mentions Tansen as a supporting figure in the music section. Analyze how his inclusion serves the author's argument about the guru-shishya parampara and the transition from court to modern institutional patronage.

STEPS:
- Step 1: Locate the reference. Find Tansen's mention in the music section (page 65): "nf{k.k Hkkjr osQ egkcfyiqje dh fo'kky ewfrZ dyk vkSj ratkSj dh fp=kdyk] dyk dkS'ky osQ vn~Hkqr mnkgj.k gaSA" – actually Tansen is referenced indirectly via "egkcfyiqje" (Tansen's title). The text discusses Hindustani music's courtly origins.
- Step 2: Identify the character's described role. Tansen represents the pinnacle of court musician (darbari gayak) under Akbar, trained in the guru-shishya tradition, later symbolizing national musical heritage.
- Step 3: Analyze the author's framing. The essay traces music from folk roots to classical codification: "laxhr Hkh yksd ls tqM+k Fkk... vkt osQ 'kkL=kh; laxhr ls cgqr vyx ugha Fkk". Tansen embodies this historical transition.
- Step 4: Evaluate thematic function. As a supporting character, Tansen bridges the past (courtly parampara) and present (national classical music). His legacy shows how individual genius operates within tradition ("ukV~;'kkL=k").
- Step 5: Contrast with folk musician supporting character. The folk musician (e.g., Langa/Manganiyar) learns hereditarily within community, performs for life-cycle events, not courts. Tansen represents institutionalization.
- Step 6: Synthesize. The author uses Tansen to illustrate the classical stream's historical depth and its vulnerability to patronage shifts – from Mughal courts to modern academies.

REASONING: This example requires students to work with an indirect textual reference (Tansen as "egkcfyiqje") and infer his character role from the essay's historical narrative. It builds the skill of reading supporting characters as historical symbols, not just textual mentions.

ANSWER: Tansen functions as a supporting character symbolizing the classical musician's journey from court servant to cultural icon. The text positions him within the guru-shishya parampara ("ukV~;'kkL=k") and the Mughal court system ("nf{k.k Hkkjr osQ egkcfyiqje"). His inclusion supports the theme of continuity: the same musical knowledge (ragas, talas) that once served royal darbars now defines national classical music. Unlike the anonymous folk singer tied to seasonal festivals, Tansen's named legacy shows how classical art acquires individual authorship within tradition. This contrast enriches the essay's folk-classical dialectic.

## WORKED_EXAMPLE_3
PROBLEM: Compare the temple sculptor (xhrxksfoan) and the folk metalworker (Bastar dhokra artist) as supporting characters. How do their differing materials (stone vs. metal), patrons (temple/community vs. tribal collective), and spiritual frameworks (Puranic iconography vs. animistic symbols) reflect the essay's view of unity in diversity?

STEPS:
- Step 1: Identify both supporting characters in text. Temple sculptor: page 62 ("xhrxksfoan", "Khajuraho/Konark"). Bastar metalworker: page 63 ("Bastar dhokra", "tribal metal casting").
- Step 2: Create comparison matrix from textual clues. Material: stone (permanent, architectural) vs. metal (lost-wax, portable). Patron: temple-building kings/guilds vs. tribal community for ritual use. Spiritual framework: Hindu deity forms (Vishnu, Shiva) vs. nature spirits/ancestors (Danteshwari, local deities).
- Step 3: Analyze shared characteristics. Both use "ukV~;'kkL=k" (traditional knowledge) passed orally/visually. Both integrate art with ritual necessity – temple sculpture for darshan, dhokra for votive offerings. Both show "vfHku;" (skill) as spiritual practice.
- Step 4: Connect to essay's unity argument. The author states: "lHkh dyk,¡ ,d nwljs ls tqM+h gqbZ gaSA" (all arts are interconnected). These two characters, though culturally distant, share the principle of art-as-sacred-action.
- Step 5: Note the diversity argument. The essay celebrates regional specificity: "fofo/rk gekjh igpku gSA". The sculptor's Nagara/Dravida styles and the metalworker's tribal motifs represent this diversity.
- Step 6: Formulate analytical conclusion. The pairing demonstrates the essay's core thesis: Indian art is a single civilization's expression through infinitely varied local forms. The supporting characters are not just examples; they are proof instances of the unity-diversity dialectic.

REASONING: This multi-step comparison teaches students to synthesize across textual sections, identify structural parallels, and evaluate how the author deploys supporting characters to build a macro-argument. It mirrors board exam questions asking for "compare and contrast" with textual evidence.

ANSWER: The temple sculptor and Bastar metalworker are paired supporting characters illustrating the essay's "unity in diversity" thesis. The sculptor (Khajuraho/Konark) works in stone for grand temples under royal/guild patronage, depicting Puranic narratives through codified iconometry. The Bastar dhokra artist uses lost-wax brass casting for tribal votive figures, serving community rituals around nature deities. Textually, both are described as channels of "ukV~;'kkL=k" – the sculptor expresses "urZd vksfM+'kh u`R;" through stone, the metalworker inherits "vfHku;" through clan practice. Their shared trait: art as ritual necessity, not aesthetic luxury. Their difference: one serves a pan-Indian textual tradition, the other a localized oral cosmology. Together, they prove the author's claim that "Hkkjrh; dyk,¡ yksd ls 'kkL=kh; :i rd vpkud ugha igq¡ph" – Indian arts flow seamlessly from folk to classical, united by their embeddedness in life and tradition.

## COMPETENCY_QUESTION_1
QUESTION: The chapter describes the Mithila painter and the Rajasthani miniature painter as two distinct supporting characters. Using specific textual evidence, explain how the author uses their contrasting workspaces (home wall vs. palace studio) and audiences (family/community vs. king/connoisseur) to develop the theme of art's social embeddedness.

COMPETENCY: Textual Evidence-Based Comparative Analysis

STEPS:
- Step 1: Locate the Mithila painter description (walls, floors, women, rituals) and Rajasthani miniature painter description (palace, manuscripts, kings, pigments).
- Step 2: Identify workspace and audience for each from the text.
- Step 3: Explain how workspace/audience shapes the art's purpose in each case.
- Step 4: Synthesize how the contrast demonstrates the theme: art is never autonomous but always serves a specific social context.

ANSWER: The Mithila painter works on home walls/floors (bhitti/arikpan) for family rituals (kohbar at weddings), using rice paste and vegetable dyes. Her audience is the household and community; her art invokes auspiciousness. The Rajasthani miniature painter works in palace studios (fpÙkkS<+x<+) on prepared paper/cloth for royal patrons, using mineral colors; his audience is the king and court; his art illustrates manuscripts and records glory. The author juxtaposes these to show that Indian art's form, technique, and meaning are determined by its social location – domestic/communal vs. courtly/elite. Both are equally "embedded," proving art's inseparability from the patronizing structure, whether kinship or monarchy.

DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: Critique the author's selection of supporting characters in the folk arts section. Are the chosen communities (Mithila painters, Bastar metalworkers, Rajasthani phad painters, Tanjore bronze casters) representative of India's folk art diversity? What region or community is notably absent, and how might its inclusion change the essay's portrayal of folk art?

COMPETENCY: Critical Evaluation of Authorial Choices

STEPS:
- Step 1: List the folk art communities explicitly named in the chapter.
- Step 2: Map them to geographical regions (North, Central, West, South).
- Step 3: Identify a major region/community not mentioned (e.g., Bengal patua scroll painters, Odisha pattachitra, Kerala muralists, Warli painters of Maharashtra).
- Step 4: Analyze how the absent community's characteristics (e.g., narrative scroll performance, itinerant tradition) would add a dimension missing from the current selection (which emphasizes settled, ritualistic, non-performative arts).
- Step 5: Formulate a balanced critique acknowledging the essay's space constraints while noting the gap.

ANSWER: The chapter's folk art supporting characters – Mithila (Bihar), Bastar (Chhattisgarh), Rajasthani phad (Rajasthan), Tanjore bronze (Tamil Nadu) – cover four zones but omit Eastern India's performative scroll traditions (Bengal patua, Odisha pattachitra) and Western India's Warli wall art. The selected communities are largely settled, ritual-bound, and non-narrative-performative. Including patuas would introduce the itinerant bard-painter who sings while unscrolling – a character blending visual and oral art, challenging the essay's somewhat static view of folk art as domestic decoration. This absence slightly narrows the "folk" portrait toward the sedentary and ritualistic, missing the dynamic, storytelling dimension of many Indian folk arts. However, given the essay's survey nature, the selection effectively illustrates regional rootedness and material diversity.

DIFFICULTY: hard