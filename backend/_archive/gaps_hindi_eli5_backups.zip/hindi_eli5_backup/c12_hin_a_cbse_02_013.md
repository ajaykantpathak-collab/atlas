## DEFINITION
Critical thinking in literary analysis is the disciplined process of examining a text beyond its surface meaning to uncover underlying themes, evaluate the author's choices (language, structure, devices), and form an independent, evidence-based interpretation of the work's significance and artistic merit.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student can independently deconstruct a poem's stanza structure, imagery, and tone to construct a coherent argument about its central theme, supporting every claim with specific textual evidence and explaining how that evidence proves the interpretation.

## SCOPE_BOUNDARY
This node covers the analytical framework for interpreting Nirala's poem "ljkst Le`fr" (Chapter 2, Antra) — focusing on synthesizing plot, character, theme, and literary devices studied in previous nodes into a critical evaluation. It does NOT cover basic comprehension, vocabulary, or grammar rules, which are addressed in sibling nodes 001–012.

## WALKTHROUGH
Imagine you are a detective arriving at a crime scene — the poem is the scene, and the clues are the words, images, and structure left by the poet. First, you don't just read; you *re-read aloud* to hear the rhythm and spot repetitions (like the refrain "nq[k gh thou dh dFkk jgh"). Next, you map the emotional journey: the poem moves from a tender memory of the mother (stanzas 1–3) to the father's harsh reality (stanza 4) to a philosophical resignation (final stanza). Then, you ask: *Why does Nirala contrast the mother's "xhfr" (affection) with the father's "HkkX;ghu" (stern) demeanor?* You connect this to the poet's life (orphaned early, raised by a strict father) — which you learned in the Context node (c12_hin_a_cbse_02_001). Finally, you judge: *Does the poem resolve the conflict, or leave it open?* The key insight: critical thinking means you don't just list devices; you argue *why* the poet chose them to shape the reader's experience.

## DIAGNOSTIC_QUESTION_1
What is the primary difference between *literal comprehension* (node 012) and *critical interpretation* (this node) when analyzing a poem?

## DIAGNOSTIC_ANSWER_1
Literal comprehension retrieves facts explicitly stated in the text (e.g., "The poet remembers his mother's face"). Critical interpretation infers unstated meanings, evaluates artistic choices, and synthesizes evidence to argue a theme (e.g., "The poet uses the mother's fading memory to symbolize the irretrievable loss of childhood innocence"). A wrong answer that merely lists plot points reveals the student is still operating at the comprehension level and hasn't grasped that interpretation requires an argument backed by analysis of *how* the text works.

## DIAGNOSTIC_QUESTION_2
In "ljkst Le`fr," the line "vkdk'k cny dj cuk egh" appears. A student writes: "This means the poet wants to change his fate." Explain why this interpretation is incomplete and what critical element is missing.

## DIAGNOSTIC_ANSWER_2
The interpretation misses the *irony* and *agency*: "vkdk'k" (fate/time) is commanded to change, but "egh" (mother) is the object — the poet is pleading with fate to *become* the mother, i.e., to restore her presence. The critical element missing is the grammatical role of "egh" as the desired state, not the agent of change. A student who only sees "change fate" ignores the syntactic structure and the emotional desperation encoded in the imperative mood, revealing a surface-level reading that doesn't engage with the poem's linguistic craft.

## DIAGNOSTIC_QUESTION_3
Apply the concept of *juxtaposition* to compare the imagery of the mother in stanza 2 ("ns[krh eq>s rw g¡lh ean / gksBksa esa fctyh i¡Qlh Lian") with the imagery of the father in stanza 4 ("eq> HkkX;ghu dh rw lacy"). What thematic tension does this contrast create?

## DIAGNOSTIC_ANSWER_3
Step 1: Identify mother's imagery — gentle, sensory ("g¡lh ean" = moist eyes, "fctyh i¡Qlh Lian" = trembling lips holding a smile), conveying warmth and fragility. Step 2: Identify father's imagery — "HkkX;ghu" (stern/formidable), "lacy" (attached/bound), suggesting duty, rigidity, emotional distance. Step 3: Analyze the juxtaposition — the mother embodies unconditional love ("xhfr"), the father embodies societal expectation and harsh reality. Step 4: Thematic tension — the poem pits nurturing intimacy against the crushing weight of patriarchal responsibility, mirroring the poet's own life (orphaned, raised by a strict father). A wrong answer that merely describes the two images without linking them to the poem's central conflict (memory vs. reality, tenderness vs. survival) shows the student can spot devices but cannot synthesize them into thematic analysis.

## DIAGNOSTIC_QUESTION_4
Analyze how the refrain "nq[k gh thou dh dFkk jgh / D;k dgw¡ vkt tks ugha dgh" functions structurally and philosophically across the poem's three appearances (end of stanza 3, stanza 5, and the final couplet).

## DIAGNOSTIC_ANSWER_4
Structurally, the refrain acts as an anchor — each recurrence marks a shift: first, after the mother's memory (personal grief); second, after the father's departure (existential isolation); third, as a final philosophical statement (universal futility). Philosophically, it evolves from a factual observation ("life's story remains incomplete") to a rhetorical challenge ("what else is there that isn't said?") to a resigned acceptance ("if you stay, my work is done"). A student who treats the refrain as mere repetition misses its *progressive modulation* — the meaning deepens with context. This error reveals a failure to track how a device accumulates significance across the whole text, a core skill of critical analysis.

## DIAGNOSTIC_QUESTION_5
Evaluate the claim: "Nirala's use of Braj-inflected Khari Boli in 'ljkst Le`fr' is merely a stylistic flourish; the poem would have the same emotional impact in standard modern Hindi." Defend your judgment with evidence from the poem's diction.

## DIAGNOSTIC_ANSWER_5
The claim is false. The Braj forms ("rw" for "raha", "mj" for "man", "Lian" for "laal", "fujkdkj" for "nirankar") carry cultural and emotional resonance: they evoke the *folk* and *devotional* traditions (Braj is the language of Krishna bhakti), framing the mother as a divine, almost sacred figure. Standard Hindi ("raha", "man", "laal", "nirankar") would strip the poem of its ritualistic intimacy and its connection to the *bhakti* sensibility that elevates personal grief to spiritual longing. A student who agrees with the claim ignores the *semantic density* of dialect — they treat words as interchangeable labels rather than carriers of cultural memory, a critical oversight in interpreting Nirala, who deliberately fused classical and folk registers.

## DIAGNOSTIC_QUESTION_6
Create a four-line stanza in Nirala's voice that extends the poem's central metaphor of "thou dh dFkk" (life's story) using the *same rhyme scheme and refrain structure* as the final couplet. Your stanza must reflect the poet's mature philosophical stance (not just personal grief).

## DIAGNOSTIC_ANSWER_6
A strong answer will: (1) Use AABB or ABAB rhyme matching the poem's loose rhyme (e.g., "jgh / dgh", "egh / egh"), (2) Incorporate the refrain's key words ("dFkk", "jgh", "vkt"), (3) Shift from personal loss to universal insight (e.g., "sabhi ki dFkk adhi jgh / koi na poora kar sake vkt"). A poor answer that merely rhymes without thematic depth or mimics the refrain mechanically shows the student cannot internalize the poet's *voice* and *vision* — they imitate form without grasping the intellectual core, which is the ultimate test of critical engagement.

## COMMON_MISCONCEPTION
Students believe "critical analysis" means *finding faults* or *criticizing* the poem. They write answers like "The poem is good but the language is difficult" or "Nirala should have used simpler words." This error stems from confusing the everyday meaning of "critical" (negative judgment) with the academic meaning (disciplined, evidence-based evaluation). In Class 12 board exams, such answers score zero because they demonstrate *no analytical skill* — they offer opinion without textual evidence, and they ignore the poem's artistic intent entirely. The correct approach is to *interrogate* the text: *How* does the difficulty of language serve the theme? *Why* did Nirala choose Braj forms? The answer must always be grounded in the text, not the reader's preference.

## ON_FAILURE
If a student exhibits the "criticism vs. analysis" misconception: Step 1 — Show a model board answer (from CBSE marking scheme) that analyzes a device without praising/blaming. Step 2 — Give them a 2-line excerpt from the poem (e.g., "ur u;uksa ls vkyksd mrj") and ask: "What *work* does the word 'vkyksd' do here?" Force them to answer only with textual function (e.g., "It personifies the eyebrows as mourners, externalizing inner grief"). Step 3 — Have them rewrite their previous "critical" answer replacing every opinion ("I feel", "It should be") with an analytical claim ("The poet uses X to achieve Y"). Step 4 — Re-diagnose with Diagnostic Question 4 (refrain analysis) to verify they now track device function across the text.

## BUILDS_ON
This node synthesizes all prior analytical nodes (plot, character, theme, devices, comprehension) into the higher-order skill of independent critical interpretation.

## LEADS_TO
This node enables the writing node (c12_hin_a_cbse_02_014) where students must produce structured critical essays, and the speaking node (c12_hin_a_cbse_02_015) where they defend interpretations orally.

## PREREQUISITE_NODE_IDS
c12_hin_a_cbse_02_001, c12_hin_a_cbse_02_002, c12_hin_a_cbse_02_003, c12_hin_a_cbse_02_004, c12_hin_a_cbse_02_005, c12_hin_a_cbse_02_006, c12_hin_a_cbse_02_007, c12_hin_a_cbse_02_008, c12_hin_a_cbse_02_009, c12_hin_a_cbse_02_010, c12_hin_a_cbse_02_011, c12_hin_a_cbse_02_012, c11_hin_ar_cbse_02_013, c11_hin_ar_cbse_04_013, c11_hin_ar_cbse_06_013
## PREREQUISITE_REASONS
c12_hin_a_cbse_02_001: Provides biographical/historical context essential for interpreting autobiographical elements.
c12_hin_a_cbse_02_002: Supplies narrative structure knowledge to analyze how the poem's "story" is organized.
c12_hin_a_cbse_02_003: Gives atmosphere/setting analysis skills to interpret the domestic vs. cosmic spaces in the poem.
c12_hin_a_cbse_02_004: Enables protagonist (poet-persona) analysis for voice and perspective.
c12_hin_a_cbse_02_005: Supports analysis of mother/father as supporting characters with symbolic weight.
c12_hin_a_cbse_02_006: Primary theme (loss, memory) is the foundation for any critical argument.
c12_hin_a_cbse_02_007: Secondary themes (time, fate, filial duty) enrich multi-layered interpretation.
c12_hin_a_cbse_02_008: Imagery/metaphor analysis is the core evidence for critical claims.
c12_hin_a_cbse_02_009: Irony/symbolism analysis reveals deeper tensions (e.g., "vkdk'k cny dj cuk egh").
c12_hin_a_cbse_02_010: Vocabulary precision (e.g., "fujkdkj", "Lian") is needed for diction analysis.
c12_hin_a_cbse_02_011: Grammar awareness (imperative mood, case endings) supports syntactic interpretation.
c12_hin_a_cbse_02_012: Literal/inferential comprehension is the baseline — interpretation builds on it.
c11_hin_ar_cbse_02_013: Class 11 critical thinking practice on similar lyrical poems builds the analytical habit.
c11_hin_ar_cbse_04_013: Class 11 analysis of Nirala's "Juhi Ki Kali" transfers device-recognition skills.
c11_hin_ar_cbse_06_013: Class 11 analysis of "Ram Ki Shakti Puja" trains epic-to-lyric comparative thinking.

## FORWARD_NODE_IDS
c12_hin_a_cbse_02_014, c12_hin_a_cbse_02_015
## FORWARD_REASONS
c12_hin_a_cbse_02_014: Writing skills require the analytical arguments and evidence-gathering techniques mastered here to construct board-standard essays.
c12_hin_a_cbse_02_015: Speaking/listening discussions demand the ability to articulate and defend interpretations developed in this node.

## CROSS_SUBJECT_PREREQS
c11_hin_ar_cbse_02_013, c11_hin_ar_cbse_04_013
## CROSS_SUBJECT_REASONS
c11_hin_ar_cbse_02_013: Class 11 Antra Chapter 2 critical thinking node establishes the analytical framework (evidence → claim → warrant) used here at higher complexity.
c11_hin_ar_cbse_04_013: Class 11 Antra Chapter 4 critical thinking on Nirala's "Juhi Ki Kali" provides direct poet-specific analytical precedent (imagery, refrain, autobiographical reading).

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_02_013 -> c12_hin_a_cbse_02_013 -> c12_hin_a_cbse_02_014

## THIS_FORMULA
Critical Interpretation = (Textual Evidence × Literary Device Analysis) + (Contextual Knowledge × Thematic Synthesis) → Coherent Argument

## FORMULA_VARIABLES
Textual Evidence: Specific lines, words, images quoted/paraphrased from the poem. Literary Device Analysis: Explanation of how a device (metaphor, refrain, juxtaposition) functions. Contextual Knowledge: Poet's life, historical period, literary movement (Chhayavad), cultural references. Thematic Synthesis: Integration of primary/secondary themes into a unified reading. Coherent Argument: A logical, evidence-backed interpretive claim.

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
analytical

## CROSS_SUBJECT
N/A | The poem's depiction of early 20th-century rural family dynamics (patriarchal authority, maternal nurture, orphanhood) connects to History's study of social structures in colonial India (Chapter 3: Social Change). Analyzing the father as "HkkX;ghu" reflects historical realities of feudal household heads.
 N/A | The poem's exploration of grief, memory reconstruction, and the "refrain" as a cognitive anchor links to Psychology's Chapter 4: Memory and Forgetting — specifically how repetitive recall (the refrain) serves emotional regulation and identity formation.
## PREREQ_CONCEPT
The student must understand that a literary text is a *constructed artifact* — every word, image, and structural choice is a deliberate decision by the author that can be analyzed for its effect.

## PREREQ_BEFORE
The student must have completed all sibling nodes 001–012 for this chapter, ensuring they possess the raw analytical materials (theme, device, character, comprehension) before attempting synthesis.

## PREREQ_STUCK
If stuck, return to c12_hin_a_cbse_02_008 (Imagery and Metaphor) and c12_hin_a_cbse_02_009 (Irony and Symbolism) — these provide the most critical evidence for interpretive arguments in this poem.

## WORKED_EXAMPLE_1
PROBLEM: Analyze how the metaphor "fiz; dh v'kCn Ük`axkj&eq[kj" (stanza 2) encapsulates the poem's central conflict between memory and mortality.
STEPS:
- Step 1: Identify the metaphor's components — "fiz;" (breath/life), "v'kCn" (speech/word), "Ük`axkj" (formless/limitless), "eq[kj" (ruler/lord). The phrase means "the formless lord of the word that is breath."
- Step 2: Locate the context — spoken by the poet addressing the mother's memory ("esjs olar dh izFke xhfr"), framing her as the origin of his poetic voice.
- Step 3: Analyze the tension — "Ük`axkj" suggests the infinite, deathless nature of the creative spirit, while "fiz; dh v'kCn" ties it to mortal breath. The mother ("xhfr") bridges them: she gave the breath *and* the word.
- Step 4: Connect to central conflict — The poem struggles with the mother's physical absence (mortality) vs. her enduring presence in his poetry (immortality). This metaphor compresses that struggle: the "formless lord" is both the mother and the poetic impulse she birthed.
- Step 5: Verify with the poem's trajectory — The final stanza's "viZ.k / riZ.k" (giving back) completes the cycle: the poet returns the gift (poetry) to the source (mother/fate), resolving the conflict through artistic offering.
REASONING: This 5-step method (identify → contextualize → analyze tension → link to theme → verify with whole text) ensures the interpretation is grounded in textual detail and not imposed from outside. It models the "evidence → claim" logic required in board exams.
ANSWER: The metaphor fuses the mother's biological gift (breath) with her spiritual gift (poetic voice), making her the "formless ruler" of the poet's art. It captures the central conflict by showing that mortality (breath) and immortality (word) are unified in the maternal figure — her death cannot erase her because she *is* the poet's language.

## WORKED_EXAMPLE_2
PROBLEM: The poem shifts from past tense (stanzas 1–3) to present imperative (stanza 4: "vkdk'k cny dj cuk egh") to future conditional (final stanza: ";fn èkeZ] jgs ur lnk ekFk"). Explain how this tense progression structures the poem's philosophical argument.
STEPS:
- Step 1: Map the tenses — Stanza 1–3: past ("ns[kk", "gksBksa", "Hkj", "xk;k") = remembered experience. Stanza 4: imperative ("cny", "cuk") = desperate demand on the present. Final stanza: conditional ("jgs", "gksa") = hypothetical resolution.
- Step 2: Determine the psychological arc — Memory (past) → Protest (present) → Acceptance (future conditional). The poet moves from passive recollection to active rebellion against fate, then to a negotiated peace.
- Step 3: Link to the refrain — The refrain "nq[k gh thou dh dFkk jgh" appears at the end of the past section (stanza 3) and the protest section (stanza 5), framing both as "incomplete." The final couplet *becomes* the completion condition.
- Step 4: Analyze the philosophical claim — Life's story ("thou dh dFkk") is incomplete *until* the poet's work ("dk;Z") is done. The conditional "if you stay... my work be finished" makes artistic creation the *condition* for narrative closure.
- Step 5: Evaluate the argument's coherence — The tense shift proves the poem is not a static elegy but a dynamic enactment of the poet's struggle to *make* meaning from loss. The grammar *is* the philosophy.
REASONING: Tense analysis is a high-yield critical tool because it reveals the poem's temporal architecture — how the poet manipulates time to shape meaning. Board examiners reward this level of structural awareness.
ANSWER: The progression from past → imperative → conditional enacts the poet's journey from grief to agency to conditional transcendence. The poem argues that narrative closure is not given by fate but earned through creative work — a distinctly Chhayavadi assertion of the artist's power.

## WORKED_EXAMPLE_3
PROBLEM: Compare Nirala's treatment of the mother in "ljkst Le`fr" with his treatment of the mother figure in "Juhi Ki Kali" (Class 11, Antra Ch. 4). Identify one shared device and one divergent thematic outcome.
STEPS:
- Step 1: Recall "Juhi Ki Kali" — the mother is associated with the *juhi* flower (fragrant, nocturnal, offered to Shiva), symbolizing self-effacing devotion and spiritual purity.
- Step 2: Identify shared device — Both poems use *synesthetic imagery* blending sensory domains: "g¡lh ean / fctyh i¡Qlh Lian" (visual+tactile) here; "juhi ki kali / mahakti raat" (olfactory+visual) there. Both fuse the mother's presence with a sensory trace that outlives her.
- Step 3: Analyze divergent outcomes — In "Juhi Ki Kali," the mother merges with the divine (Shiva offering), achieving *spiritual transcendence*. In "ljkst Le`fr," the mother remains *humanly inaccessible* — the poet commands fate to "become" her, but the conditional ending ("if you stay") admits she cannot return. The first poem resolves loss through bhakti; the second through artistic labor ("dk;Z ldy gksa").
- Step 4: Connect to Nirala's evolution — Early poem (1920s): mother as goddess, solace in tradition. Later poem (1930s): mother as irreplaceable human, solace only in poetry. This mirrors Nirala's shift from romantic-devotional to modernist-existential Chhayavad.
- Step 5: Formulate the comparative thesis — Nirala uses the same sensory-imagery device to explore two different resolutions of maternal loss: one religious, one aesthetic. The divergence marks his intellectual maturation.
REASONING: Comparative analysis across texts by the same author is a sophisticated critical skill (tested in CUET and higher-order board questions). It requires mastery of both texts and the ability to trace an author's thematic development.
ANSWER: Shared device: synesthetic sensory imagery encoding maternal presence. Divergent outcome: "Juhi Ki Kali" sublimates the mother into divine ritual (bhakti resolution); "ljkst Le`fr" confronts her absence as an existential void filled only by the poet's creative work (aesthetic resolution). The shift reflects Nirala's move from tradition to modernity.

## COMPETENCY_QUESTION_1
QUESTION: A Class 12 student writes in the board exam: "The refrain 'nq[k gh thou dh dFkk jgh' repeats three times, showing the poet is sad." Using the marking scheme criteria for 'Critical Analysis' (2 marks), explain why this answer would receive 0 marks and rewrite it to earn full marks.
COMPETENCY: Evaluating analytical writing against board exam rubric
STEPS:
- Step 1: Identify the rubric requirement — "Analysis of literary device with textual evidence and thematic connection" (not mere identification or emotion-labeling).
- Step 2: Diagnose the flaws — (a) "repeats three times" = identification, not analysis; (b) "showing the poet is sad" = vague emotional label, not interpretive claim; (c) no evidence from the poem's *changing context* of the refrain.
- Step 3: Construct the improved answer — Must include: (i) structural function (anchor at three turning points), (ii) semantic modulation (observation → challenge → acceptance), (iii) thematic link (incompleteness of life vs. completion through art), (iv) one specific textual reference (e.g., the shift from "jgh" to "gks" in the final couplet).
- Step 4: Write the model answer — "The refrain acts as a structural anchor at three critical junctures: after the mother's memory (personal grief), after the father's departure (existential isolation), and as the poem's philosophical conclusion. Its meaning modulates from factual observation ('jgh') to rhetorical defiance ('dgh') to conditional resolution ('gksa'), embodying the poem's argument that life's narrative remains incomplete until the poet's creative work ('dk;Z') achieves closure."
ANSWER: The original answer scores 0 because it only *identifies* repetition and *labels* emotion without analyzing *how* the device constructs meaning. The rewritten answer earns 2 marks by analyzing structural function, semantic progression, and thematic synthesis with textual precision.
DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: "Nirala's 'ljkst Le`fr' is not an elegy for a dead mother; it is a manifesto for the poet's artistic immortality." Critically evaluate this statement. In your answer, you must: (a) define 'elegy' and 'manifesto' in literary terms, (b) analyze two poetic devices that support *each* reading, (c) synthesize a final judgment with evidence.
COMPETENCY: Synthesizing opposing critical perspectives into a nuanced argument
STEPS:
- Step 1: Define terms — Elegy: a poem of mourning for the dead, typically moving from grief to consolation. Manifesto: a public declaration of principles/intentions, often programmatic.
- Step 2: Devices supporting elegy — (i) Apostrophe: addressing the dead mother ("eSaus nh", "rw fiQj leksn") enacts mourning ritual. (ii) Pastoral imagery: "xhfr", "uoy", "Lian" evoke lost innocence, classic elegiac tropes.
- Step 3: Devices supporting manifesto — (i) Imperative address to fate ("vkdk'k cny dj cuk egh") — the poet *commands* reality, asserting artistic agency. (ii) Meta-poetic closure ("esjs dk;Z ldy gksa") — the poem declares its own purpose: poetry as the vehicle for immortality.
- Step 4: Synthesize — The poem *begins* as elegy (stanzas 1–3) but *transforms* into manifesto (stanzas 4–5). The pivot is the father's departure: the loss of the second parent forces the poet to become his own authority. The final conditional ("if you stay") is not consolation (elegiac) but a contract (manifesto): *I will complete my work if you witness it.*
- Step 5: Final judgment — The statement is *partially true but reductive*. The poem is a *hybrid*: an elegy that refuses elegiac consolation, replacing it with a manifesto of artistic self-fashioning. This refusal is its modernist core.
ANSWER: The poem hybridizes elegy and manifesto. It uses elegiac devices (apostrophe, pastoral memory) to establish loss, then deploys manifesto devices (imperative agency, meta-poetic declaration) to reject passive mourning. The synthesis: Nirala mourns the mother *by* declaring his art as her only surviving form — making the elegy the *ground* for the manifesto.
DIFFICULTY: hard