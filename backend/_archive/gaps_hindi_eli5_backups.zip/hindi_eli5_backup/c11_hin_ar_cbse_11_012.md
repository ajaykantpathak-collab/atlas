## DEFINITION
Literal comprehension questions require retrieving information explicitly stated in the text, while inferential comprehension questions require drawing logical conclusions by combining textual evidence with background knowledge and contextual clues. In senior secondary Hindi, this distinction is critical because board exams allocate specific marks for each type and demand precise textual referencing for inferential answers.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student can independently classify any comprehension question as literal or inferential, locate exact textual evidence for literal answers, and construct inferential answers using a minimum of two textual clues with explicit reasoning linking evidence to conclusion.

## SCOPE_BOUNDARY
This node covers only the identification and answering of literal and inferential questions based on the poem "Ghar ki Yaad" by Harivansh Rai Bachchan. It does not cover critical evaluation, creative extrapolation, or comparative analysis with other texts (addressed in nodes 013-015).

## WALKTHROUGH
Imagine you receive a text from a friend: "Reached station. Train late." Literal: friend is at station, train is delayed. Inferential: friend is bored/annoyed, will be late for your plan, might need a pickup later. You did this automatically. Now apply the same split to the poem. First, read the poem aloud once to hear the rhythm of memory. Then, for every question, ask: "Is the answer written verbatim in the lines?" If yes -> literal. If no -> inferential: gather 2-3 specific lines, note the emotional context (nostalgia, father's absence), and deduce the implied meaning. The key insight: inferential answers are not guesses; they are evidence-based deductions.

## DIAGNOSTIC_QUESTION_1
Identify the type of question: "कविता में 'पिता' शब्द कितनी बार आया है?" (How many times does the word 'father' appear in the poem?)

## DIAGNOSTIC_ANSWER_1
This is a **literal** question because the answer can be found by directly counting the occurrences of the word 'पिता' in the text without any interpretation. A wrong answer (e.g., calling it inferential) reveals the student confuses "counting/retrieving" with "interpreting" and does not grasp that literal questions have a single, verifiable answer located explicitly in the text.

## DIAGNOSTIC_QUESTION_2
Explain in your own words why the poet describes the house as "यादों का घर" (house of memories) rather than just "मेरा घर" (my house).

## DIAGNOSTIC_ANSWER_2
This is an **inferential** question. The phrase "यादों का घर" is not explicitly defined in the poem; the student must infer that the physical house is gone/empty and only memories remain, using clues like "अब नहीं रहा वह घर" and the repeated refrain "घर की याद". A wrong answer (e.g., "because the poet likes memories") reveals the student treats inference as personal opinion rather than a conclusion forced by textual evidence like the contrast between past warmth and present absence.

## DIAGNOSTIC_QUESTION_3
Given the lines: "पिता ने कहा था / 'घर में चार दीवारें / चार खिड़कियाँ'" and later "पिता को कोई एक चीज़ भी नहीं मिली", write a 2-sentence inferential answer to: "पिता की स्थिति क्या दर्शाती है?" (What does the father's condition show?)

## DIAGNOSTIC_ANSWER_3
**Steps:** 1) Identify literal facts: father described a house with 4 walls/4 windows; later he got "not even one thing". 2) Note the contrast: promise vs reality. 3) Infer: the father's life was stripped of the stability he promised. 4) Formulate: The father's condition shows the tragic gap between his aspirations for a secure home and the harsh reality of displacement/loss. A wrong answer (e.g., "father was poor") reveals the student misses the symbolic contrast and states a generic fact not grounded in the specific textual juxtaposition.

## DIAGNOSTIC_QUESTION_4
Compare the literal meaning of "नक्शा" (map) in the line "नक्शा बना लिया था" with its inferred symbolic meaning in the context of the poem's theme of displacement.

## DIAGNOSTIC_ANSWER_4
**Literal:** A physical architectural plan drawn by the father. **Inferred:** The map symbolizes the father's attempt to impose order/permanence on a life defined by impermanence; its failure to materialize represents the fragility of rootedness. A wrong answer (e.g., "map means plan") reveals the student cannot separate denotation from connotation and fails to link the symbol to the broader theme of loss analyzed in node 009 (Symbolism).

## DIAGNOSTIC_QUESTION_5
Evaluate this student answer to an inferential question: "कवि को घर की याद क्यों आती है? क्योंकि वह बूढ़ा हो गया है।" (Why does the poet remember home? Because he has grown old.) Is this a valid inference? Justify.

## DIAGNOSTIC_ANSWER_5
**Invalid inference.** The poem never states the poet's age; "old age" is an external assumption. Valid inferences must be anchored in the text: the poet remembers home because of *sensory triggers* (smell of rain, sound of train) and *emotional void* (father's absence, "अब नहीं रहा वह घर"). A wrong evaluation (e.g., "yes, it's valid") reveals the student cannot distinguish text-supported inference from personal projection, a critical error in board exams where marks are awarded only for text-grounded reasoning.

## DIAGNOSTIC_QUESTION_6
Create one literal and one inferential question based on the final stanza (beginning "और कहना...") that a Class 11 exam might ask. Provide the expected answer for each.

## DIAGNOSTIC_ANSWER_6
**Literal Q:** "कवि अंत में किससे कहता है कि 'घर नहीं रहा'?" **Answer:** "अपने आप से" or "पाठक से" (explicit in "अपने आप से कहना"). **Inferential Q:** "अंतिम पंक्ति 'घर नहीं रहा, यह याद ही याद है' कवि की किस मनःस्थिति को दर्शाती है?" **Answer:** It shows *acceptance of irreversible loss* – the physical home is gone, only the mental construct 'memory' remains; the repetition 'याद ही याद' emphasizes the total replacement of reality by recollection. A poor created question (e.g., literal: "What is the poet's name?") reveals the student cannot distinguish question *types* or identify which stanza details are examinable.

## COMMON_MISCONCEPTION
Students believe "inferential" means "write your feelings about the poem." They write: "I feel sad because the house is gone" instead of "The poet conveys loss through the contrast between 'चार दीवारें' (stanza 2) and 'अब नहीं रहा वह घर' (stanza 5)." This error stems from middle-school "personal response" tasks. In Class 11 board exams, inferential answers *must* cite line/stanza references and explain the logical bridge from evidence to conclusion. Without textual anchors, the answer scores zero regardless of emotional sincerity.

## ON_FAILURE
1. **Re-anchor:** Give the student 3 explicit lines from the poem. Ask: "What does this line *say*?" (Literal). Write it down. 2. **Bridge:** Ask: "What does this line *suggest* about the father/poet/time?" Force them to use the stem: "The line 'X' suggests Y because..." 3. **Categorize:** Present 5 mixed questions. Student sorts into Literal/Inferential columns *before* answering. 4. **Model:** Show a board-marking-scheme answer for an inferential question: (Point) + (Quote) + (Explain link) + (Mini-conclusion). Student replicates structure with a new question.

## BUILDS_ON
The ability to distinguish explicit statement from implied meaning, developed through prior nodes' coverage of the poem's narrative (002), imagery (008), and vocabulary (010).

## LEADS_TO
Critical thinking (node 013) where inferential reasoning is extended to thematic interpretation, and writing skills (node 014) where structured evidence-based answers are formalized into exam responses.

## PREREQUISITE_NODE_IDS
c11_hin_ar_cbse_11_001, c11_hin_ar_cbse_11_002, c11_hin_ar_cbse_11_003, c11_hin_ar_cbse_11_004, c11_hin_ar_cbse_11_005, c11_hin_ar_cbse_11_006, c11_hin_ar_cbse_11_007, c11_hin_ar_cbse_11_008, c11_hin_ar_cbse_11_009, c11_hin_ar_cbse_11_010, c11_hin_ar_cbse_11_011
## PREREQUISITE_REASONS
c11_hin_ar_cbse_11_001: Context/background knowledge needed to understand displacement theme for inferences.
c11_hin_ar_cbse_11_002: Plot/narrative structure provides the sequence of events for literal retrieval.
c11_hin_ar_cbse_11_003: Setting/atmosphere details are the primary textual evidence for inferential questions on mood.
c11_hin_ar_cbse_11_004: Protagonist (poet persona) analysis supplies the 'speaker' context for inferring tone.
c11_hin_ar_cbse_11_005: Supporting characters (father) are central to key inferential questions about loss.
c11_hin_ar_cbse_11_006: Primary theme (memory/loss) is the overarching framework for valid inferences.
c11_hin_ar_cbse_11_007: Secondary themes (displacement, time) provide additional lenses for inference.
c11_hin_ar_cbse_11_008: Imagery/metaphor identification yields the concrete textual clues required for inference.
c11_hin_ar_cbse_11_009: Irony/symbolism knowledge enables deeper inferential leaps (e.g., map symbolism).
c11_hin_ar_cbse_11_010: Vocabulary in context ensures accurate literal comprehension of key terms like 'याद', 'नक्शा'.
c11_hin_ar_cbse_11_011: Grammar/usage awareness prevents misreading syntactic nuances that change literal meaning.

## FORWARD_NODE_IDS
c11_hin_ar_cbse_11_013, c11_hin_ar_cbse_11_014, c11_hin_ar_cbse_11_015, c12_hin_a_cbse_11_012, c12_hin_ar_cbse_04_012, c12_hin_ar_cbse_09_012, c12_hin_ar_cbse_11_002, c12_hin_ar_cbse_11_012

## FORWARD_REASONS
c11_hin_ar_cbse_11_013: Critical thinking requires the inferential skill built here as its foundation for analysis/interpretation.
c11_hin_ar_cbse_11_014: Writing skills (answers, essays) directly apply the literal/inferential answer structure taught here.
c11_hin_ar_cbse_11_015: Speaking/listening discussions use literal facts as shared ground and inferences as debate points.
c12_hin_a_cbse_11_012: Class 11 Antra comprehension skills are direct foundation.  
c12_hin_ar_cbse_04_012: अगला तार्किक चरण: Literal comprehension is the ability to extract explicitly stated facts, details, and sequences dire... इस नोड की अवधारणाओं को सीधे उपयोग/विस्तारित करता है।  
c12_hin_ar_cbse_09_012: Builds stamina for longer poems.  
c12_hin_ar_cbse_11_002: Develops literal and inferential comprehension skills needed to accurately identify plot events before analyzing their structural role.  
c12_hin_ar_cbse_11_012: Provides the foundational distinction between literal and inferential comprehension from Class 11.  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
none

## CHAIN_DESCRIPTION
c11_hin_ar_cbse_11_002 -> c11_hin_ar_cbse_11_012 -> c11_hin_ar_cbse_11_013

## THIS_FORMULA
N/A - conceptual

## FORMULA_VARIABLES
N/A

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
linguistic

## CROSS_SUBJECT
c11_history_nationalism | The poem's theme of displacement and memory of home parallels the Partition-era refugee experience studied in History; inferential skills transfer to analyzing primary sources (letters, testimonies) where literal content masks trauma.
c11_psychology_memory | The poem illustrates constructive memory (rebuilding home in mind); inferential comprehension mirrors psychological reasoning: using cues (smell, sound) to reconstruct past states, a core concept in cognitive psychology.

## PREREQ_CONCEPT
Distinction between denotation (literal meaning) and connotation (implied meaning) in poetic language.

## PREREQ_BEFORE
Student must have completed a full reading of "Ghar ki Yaad" with annotations for sensory images, emotional shifts, and father-figure references (covered in nodes 001-011).

## PREREQ_STUCK
If stuck, review the annotated summary of stanzas 2, 5, and 8 from node 002 (Plot) and the imagery chart from node 008 (Imagery and Metaphor).

## WORKED_EXAMPLE_1
PROBLEM: Answer the inferential question: "कविता में 'ट्रेन की आवाज़' और 'बारिश की गंध' केवल संवेदनात्मक विवरण नहीं हैं; ये कवि की किस आंतरिक स्थिति को प्रकट करते हैं?" (Train sound and rain smell are not just sensory details; what internal state of the poet do they reveal?) Use the PEEL structure (Point, Evidence, Explanation, Link).

STEPS:
- Step 1: Identify the question type – inferential (asks for "internal state" not explicitly stated).
- Step 2: Locate the literal evidence: Stanza 3 mentions "गाड़ी की आवाज़" triggering memory; Stanza 6 mentions "बारिश की गंध" bringing the house alive.
- Step 3: Analyze the pattern: Both are *involuntary triggers* (Proustian memory) that bypass conscious control, pulling the poet into the past.
- Step 4: Synthesize the internal state: They reveal the poet's *helpless immersion in nostalgia* – memory attacks him through senses, showing he cannot "choose" to forget; the past is physically alive in him.
- Step 5: Draft PEEL answer: Point: Triggers reveal involuntary nostalgia. Evidence: "गाड़ी की आवाज़ सुनकर / याद आ जाता है घर" and "बारिश की गंध / घर को जिला देती है". Explanation: Sensory cues act as portals; the poet is a passive recipient. Link: This powerlessness underscores the poem's theme of memory as an inescapable force.

REASONING: The steps move from classification to evidence gathering to pattern recognition to thematic synthesis – the exact cognitive chain board examiners expect for 3-4 mark inferential questions.

ANSWER: The train sound and rain smell act as involuntary sensory triggers that reveal the poet's helpless immersion in nostalgia. In stanza 3, "गाड़ी की आवाज़ सुनकर / याद आ जाता है घर" and in stanza 6, "बारिश की गंध / घर को जिला देती है" show that memory ambushes him through the senses, not by will. This powerlessness proves memory is an inescapable force, not a chosen recollection, deepening the theme of loss.

## WORKED_EXAMPLE_2
PROBLEM: A literal question asks: "पिता ने घर के नक्शे में क्या-क्या बनाया था?" (What did the father include in the house map?) Convert this into an inferential question and answer it.

STEPS:
- Step 1: Answer the literal question first (prerequisite for inference): Father drew "चार दीवारें, चार खिड़कियाँ, एक दरवाज़ा, एक आँगन" (4 walls, 4 windows, 1 door, 1 courtyard).
- Step 2: Formulate an inferential question: "पिता के नक्शे की सरलता और उसके अधूरे रह जाने से कवि क्या संकेत करता है?" (What does the simplicity and incompleteness of the father's map suggest?)
- Step 3: Gather evidence for inference: Literal simplicity (basic elements only) + later line "पिता को कोई एक चीज़ भी नहीं मिली" (father got not even one thing).
- Step 4: Reason the inference: The map's minimalism reflects the father's modest, achievable dream; its total failure symbolizes how even basic security was denied by circumstance/displacement.
- Step 5: Write structured answer: The map's simplicity (only 4 walls, 4 windows) shows the father's humble aspiration for basic shelter. Its total non-fulfilment ("कोई एक चीज़ भी नहीं मिली") suggests the cruel irony that displacement strips away even the most fundamental human need for a roof.

REASONING: This example demonstrates the senior-secondary skill of *generating* inferential questions from literal facts – a meta-cognitive ability tested in "frame your own question" board tasks.

ANSWER: Inferential Question: "पिता के नक्शे की सरलता और उसके अधूरे रह जाने से कवि क्या संकेत करता है?" Answer: The map's bare-bones design (4 walls, 4 windows, 1 door, 1 courtyard) reflects the father's modest dream of basic security. Its complete failure – "पिता को कोई एक चीज़ भी नहीं मिली" – signifies the brutal irony that forces of displacement deny even the most minimal human shelter, turning a simple plan into a symbol of utter loss.

## WORKED_EXAMPLE_3
PROBLEM: The poem ends with: "घर नहीं रहा, यह याद ही याद है।" A board question: "इस पंक्ति में 'याद' शब्द की पुनरावृत्ति ('याद ही याद') कवि के किस मनोविज्ञान को उजागर करती है? दो साक्ष्यों के साथ समझाइए।" (What psychology of the poet does the repetition 'yaad hi yaad' reveal? Explain with two evidences.)

STEPS:
- Step 1: Classify: Inferential (asks for "psychology" + demands two evidences).
- Step 2: Identify the device: Repetition (अनुप्रास/पुनरावृत्ति) for emphasis – covered in node 008/009.
- Step 3: Locate Evidence 1 (textual): The line itself + preceding context "अब नहीं रहा वह घर" (that house exists no more).
- Step 4: Locate Evidence 2 (structural): The poem's circular structure – opens with "घर की याद", closes with "याद ही याद"; memory has *replaced* reality.
- Step 5: Infer psychology 1: *Obsessive fixation* – the mind cannot hold the physical object, so it loops the word to keep the lost object present.
- Step 6: Infer psychology 2: *Acceptance through substitution* – by saying "याद ही याद", he acknowledges the physical is gone and the mental construct is now the only 'home' left.
- Step 7: Synthesize into board-format answer: Point -> Evidence 1 -> Explanation -> Evidence 2 -> Explanation -> Concluding Link.

REASONING: This 7-step worked example mirrors the 4-5 mark "explain with reference to context" questions where students must integrate literary device knowledge (node 008/009) with inferential reasoning and textual citation.

ANSWER: The repetition "याद ही याद" reveals two psychological states: (1) **Obsessive fixation** – Evidence: "अब नहीं रहा वह घर" immediately precedes it; the mind, unable to grasp the lost physical home, compulsively repeats the word 'memory' to maintain a grip on the vanishing object. (2) **Acceptance through substitution** – Evidence: The poem's circular arc from opening "घर की याद" to closing "याद ही याद" shows memory has *become* the home. The poet psychologically replaces the irretrievable physical structure with its mental echo, achieving a fragile closure where "याद" is the only remaining reality.

## COMPETENCY_QUESTION_1
QUESTION: Read the following extract from a *different* poem (unseen): "पुराने घर की चाबी / अब भी मेरी जेब में पड़ी है / मगर ताला कब का बदल चुका है।" Frame ONE literal and ONE inferential question on this extract. Answer your inferential question using the PEEL method.

COMPETENCY: Transfer of literal/inferential distinction to unseen text; question framing; structured answer writing.

STEPS:
- Step 1: Literal Question: "कवि के पास पुराने घर की क्या चीज़ अभी भी है?" (Answer: चाबी / key)
- Step 2: Inferential Question: "चाबी का होना और ताले का बदल जाना – यह विरोधाभास कवि के किस अनुभव को दर्शाता है?" (What experience does the paradox of having the key but the lock changed convey?)
- Step 3: Evidence 1: "चाबी ... जेब में पड़ी है" (possession of access tool).
- Step 4: Evidence 2: "ताला कब का बदल चुका है" (access denied by changed reality).
- Step 5: PEEL Answer: Point: The paradox illustrates the futility of holding onto past access when the present has structurally changed. Evidence: Key in pocket vs lock changed long ago. Explanation: The key (memory/claim) is useless because the lock (reality/ownership) has been replaced; the past cannot unlock the present. Link: This mirrors "Ghar ki Yaad" where the map (plan) exists but the house (reality) is gone.

ANSWER: Literal Q: "कवि के पास पुराने घर की क्या चीज़ अभी भी है?" Ans: चाबी। Inferential Q: "चाबी का होना और ताले का बदल जाना – यह विरोधाभास कवि के किस अनुभव को दर्शाता है?" Ans: The paradox illustrates the futility of holding onto past access when the present has structurally changed. The key (memory/claim) remains in the pocket, but the lock (reality/ownership) "कब का बदल चुका है" – the past cannot unlock the present. This mirrors "Ghar ki Yaad" where the father's map exists but the house is gone.

DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: A Class 11 student writes this answer to an inferential question on "Ghar ki Yaad": "कवि अपने घर को बहुत याद करता है क्योंकि वह उससे प्यार करता था।" (The poet misses his home a lot because he loved it.) Critique this answer using board exam marking criteria. Then rewrite it to score full marks (3 marks), incorporating two specific textual references.

COMPETENCY: Evaluation of answer quality against marking scheme; rewriting to meet competency standards (evidence, reasoning, terminology).

STEPS:
- Step 1: Identify flaws: (a) No textual evidence. (b) "प्यार करता था" is a vague emotional claim, not an inference from the text. (c) No analysis of *how* the poem conveys longing. (d) Uses 1st person "कवि ... करता है" instead of analytical tone.
- Step 2: Determine marking criteria for 3 marks: 1 mark for valid inference, 1 mark for two textual references, 1 mark for logical explanation linking evidence to inference.
- Step 3: Select Evidence 1: Stanza 1 refrain "घर की याद" + sensory triggers (stanza 3, 6).
- Step 4: Select Evidence 2: Final stanza "घर नहीं रहा, यह याद ही याद है" – memory replacing reality.
- Step 5: Draft inference: The poet's longing manifests as an *involuntary, sensory-haunted obsession* where memory physically substitutes the lost home.
- Step 6: Write full-mark answer: "कवि की घर के प्रति लालसा स्वैच्छिक नहीं, बल्कि इंद्रिय-जनित बाध्यता है। साक्ष्य 1: 'गाड़ी की आवाज़ सुनकर / याद आ जाता है घर' (अनुच्छेद 3) और 'बारिश की गंध / घर को जिला देती है' (अनुच्छेद 6) दर्शाते हैं कि साधारण संवेदनाएँ अतीत को जबरन वर्तमान में खींच लाती हैं। साक्ष्य 2: अंतिम पंक्ति 'घर नहीं रहा, यह याद ही याद है' में 'याद' की पुनरावृत्ति सिद्ध करती है कि भौतिक घर के अभाव में स्मृति ही उसका प्रतिस्थापन बन गई है।"

ANSWER: Critique: The original answer scores 0/3 – it states a generic emotion without textual proof, uses no poetic terminology, and offers no analytical reasoning. Rewritten full-mark answer: "कवि की घर के प्रति लालसा स्वैच्छिक नहीं, बल्कि इंद्रिय-जनित बाध्यता है। साक्ष्य 1: 'गाड़ी की आवाज़ सुनकर / याद आ जाता है घर' (अनुच्छेद 3) और 'बारिश की गंध / घर को जिला देती है' (अनुच्छेद 6) दर्शाते हैं कि साधारण संवेदनाएँ अतीत को जबरन वर्तमान में खींच लाती हैं। साक्ष्य 2: अंतिम पंक्ति 'घर नहीं रहा, यह याद ही याद है' में 'याद' की पुनरावृत्ति सिद्ध करती है कि भौतिक घर के अभाव में स्मृति ही उसका प्रतिस्थापन बन गई है।"

DIFFICULTY: hard