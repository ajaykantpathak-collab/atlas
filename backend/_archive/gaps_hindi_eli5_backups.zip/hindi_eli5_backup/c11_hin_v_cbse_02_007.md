## DEFINITION
Secondary themes are the underlying, often interconnected ideas in a literary text that support, complicate, or contrast with the primary theme; they emerge through recurring motifs, character interactions, setting details, and narrative patterns rather than being explicitly stated.

## COGNITIVE_LEVEL
analyze

## MASTERY_CRITERIA
The student can identify at least three distinct secondary themes in the chapter, trace each theme across two or more textual evidence points, and explain how each secondary theme enriches or complicates the primary theme of water conservation and community resilience.

## SCOPE_BOUNDARY
This node covers identification and analysis of secondary themes in "जलतल की झिर झिर" (Chapter 2, Vitan) including social hierarchy in labor, traditional knowledge systems, gendered water access, dignity of manual work, and community interdependence; it does NOT cover primary theme analysis (node 006), literary devices (nodes 008-009), or writing skills (node 014).

## WALKTHROUGH
Imagine you're watching a documentary about a village in Rajasthan where people build johads (earthen check dams) by hand — you notice the main story is about water, but you also see women walking miles for water, elders guiding young workers, caste groups sitting separately during meals, and rituals before digging begins. These aren't the "main message" but they're everywhere in the background, shaping how the main story unfolds. To find secondary themes, start by asking: "What patterns keep appearing in the background of this water story?" Look for repeated details about who does what work, how decisions are made, what rituals exist, and what tensions appear between groups. The key insight: secondary themes are the texture of the primary theme — they show the human, social, and cultural fabric that makes the main theme lived and real.

## DIAGNOSTIC_QUESTION_1
What is the definition of a secondary theme in literature, and how does it differ from the primary theme?

## DIAGNOSTIC_ANSWER_1
A secondary theme is a supporting or parallel idea that runs through a text alongside the primary theme, emerging through motifs, character interactions, and setting details rather than direct statement; it differs from the primary theme in that it is not the central message but enriches, complicates, or contextualizes it. A wrong answer that equates secondary themes with "less important themes" reveals a misunderstanding — secondary themes are not hierarchically lesser but structurally distinct: they operate through accumulation and implication, not authorial declaration.

## DIAGNOSTIC_QUESTION_2
In the chapter, the author describes how pond-builders (पस्तकिज्या) receive annual wages (वार्षिक-हज) and special festival allowances (त्यौहारों पर विशेष भत्ता), yet their names are changed to generic labels (उनके नाम के बजाय, उन्हें संख्या दी जाती है). What secondary theme does this contrast reveal?

## DIAGNOSTIC_ANSWER_2
This contrast reveals the secondary theme of **dignity of labor versus institutional erasure of worker identity** — the system acknowledges labor's economic value (wages, allowances) but systematically strips workers of individual identity (numeric labels, renamed identities), exposing a tension between material recognition and social invisibility. A wrong answer focusing only on "exploitation" or "fair wages" misses the nuanced duality: the text shows both recognition (special allowances, skill respect) AND erasure (renaming, generic categorization), which together form the secondary theme.

## DIAGNOSTIC_QUESTION_3
Trace the secondary theme of "traditional knowledge versus bureaucratic categorization" across two specific passages in the text where the author contrasts indigenous water classification (इक्यजिकुह, इकरकीकुह, यष्टिक्रियकुह) with official drought-relief categories.

## DIAGNOSTIC_ANSWER_3
Passage 1 (pages 13-14): The author details the threefold indigenous classification — इक्यजिकुह (surface runoff), इकरकीकुह (groundwater), यष्टिक्रियकुह (subsurface flow between the two) — based on hydrological behavior and seasonal patterns. Passage 2 (page 17): Official drought relief uses rigid categories like "scarcity," "near-scarcity," "moderate" based on rainfall deficits alone, ignoring soil moisture, subsurface flow, and local microclimates. The contrast shows traditional knowledge as dynamic, location-specific, and process-oriented versus bureaucratic knowledge as static, universal, and metric-driven. A wrong answer listing only the terms without contrasting their epistemological basis misses the analytical depth required.

## DIAGNOSTIC_QUESTION_4
Analyze how the secondary theme of "gendered water labor" operates in the text through the description of women's water-fetching routines (पनिहारिनें, सिर पर घड़े) versus men's pond-digging work (पस्तकिज्या, फावड़ा-तगाड़ी). What does this spatial division reveal about social structure?

## DIAGNOSTIC_ANSWER_4
The spatial division reveals a secondary theme of **gendered spatial politics of water access**: women's labor is domestic, repetitive, invisible (daily head-loads from distant sources), while men's labor is communal, project-based, publicly recognized (pond-building with tools, wages, festivals). This mirrors the public/private divide where women's water work sustains daily survival but carries no social honor, while men's water work builds infrastructure and earns communal status. A wrong answer that merely notes "women fetch water, men dig ponds" without analyzing the symbolic valuation of each labor type fails to engage the theme's critical dimension.

## DIAGNOSTIC_QUESTION_5
Evaluate the author's stance on the secondary theme of "community interdependence versus caste hierarchy" by examining the tension between collective pond-building (सामूहिक श्रम, साझा भोज) and persistent caste-based seating (जाति-आधारित बैठक, अलग-अलग पंगत).

## DIAGNOSTIC_ANSWER_5
The author presents a **dialectical tension, not a resolution**: collective labor (shared digging, communal meals, joint rituals) creates moments of interdependence where caste boundaries blur (water touches all hands equally), yet ritual seating (separate rows, hierarchical serving) reinstates hierarchy immediately after. The author neither romanticizes unity nor condemns caste — instead, the text shows interdependence as *functional necessity* (ponds need all hands) while caste remains *social default* (meals need order). A wrong answer claiming "the text shows caste is broken by collective work" or "caste dominates everything" imposes a binary the text deliberately avoids.

## DIAGNOSTIC_QUESTION_6
Create a 4-line poetic stanza or a 3-sentence micro-narrative that embodies the secondary theme of "water as social memory" — how ponds store not just water but histories of labor, conflict, and cooperation.

## DIAGNOSTIC_ANSWER_6
**Micro-narrative:** "The old johad holds more than rain — its banks remember the blisters of 1987, the fight between Thakur and Meghwal over the first bucket, the lullaby a mother sang while waiting her turn. When the water rises, it doesn't just fill the pit; it lifts those stories back into the village air." A poor answer that writes only about water's physical properties ("water remembers minerals, temperature") misses the metaphorical dimension: the theme is about *social* memory encoded in infrastructure, not hydrological memory.

## COMMON_MISCONCEPTION
Students often confuse **secondary themes with "sub-plots" or "minor topics"** — they list elements like "pond construction process," "drought description," or "villager dialogues" as secondary themes. This error occurs because they look for *what happens* (plot points) rather than *what recurs as an idea* (thematic patterns). For example, "pond construction" is a plot sequence; "dignity of manual labor in a caste-stratified society" is the secondary theme enacted through that sequence. The misconception stems from middle-school training to identify "topics" rather than "themes" — topics are nouns (water, ponds, labor), themes are complete ideas with tension (labor is honored yet workers are erased).

## ON_FAILURE
If a student lists plot points as themes: (1) Ask them to convert each noun into a complete sentence with a verb expressing a relationship or tension (e.g., "pond construction" → "collective labor builds infrastructure but cannot dismantle social hierarchy"). (2) Have them find three textual moments where this tension appears — not just where ponds are built, but where labor's dignity is affirmed AND where workers are anonymized. (3) Use a two-column table: Column A = "What the text shows happening" (plot), Column B = "What this pattern suggests about society/human nature" (theme). Practice with 2-3 clear examples from the text before independent work.

## BUILDS_ON
Primary theme identification (node 006) — students must first grasp the central message (water conservation through community resilience) before analyzing how secondary themes complicate it.

## LEADS_TO
Critical thinking and interpretation (node 013) — secondary theme analysis provides the evidentiary foundation for higher-order analytical writing and discussion.

## PREREQUISITE_NODE_IDS
c11_hin_v_cbse_02_001, c11_hin_v_cbse_02_002, c11_hin_v_cbse_02_003, c11_hin_v_cbse_02_004, c11_hin_v_cbse_02_005, c11_hin_v_cbse_02_006
## PREREQUISITE_REASONS
c11_hin_v_cbse_02_001: Context/background knowledge of Rajasthan's water geography is essential to recognize how secondary themes emerge from specific ecological conditions.
c11_hin_v_cbse_02_002: Plot and narrative structure knowledge allows students to locate where secondary themes appear in the narrative arc (e.g., during collective digging vs. during meals).
c11_hin_v_cbse_02_003: Setting and atmosphere details (arid landscape, seasonal rhythms) are the backdrop against which secondary themes like gendered water labor become visible.
c11_hin_v_cbse_02_004: Protagonist analysis (the narrator/observer) reveals the lens through which secondary themes are filtered — his positionality shapes what is noticed.
c11_hin_v_cbse_02_005: Supporting characters (pond-builders, women fetchers, officials) embody different secondary themes; their roles must be understood first.
c11_hin_v_cbse_02_006: Primary theme (water conservation/community resilience) is the anchor — secondary themes only make sense in relation to it.

## FORWARD_NODE_IDS
c11_hin_v_cbse_02_008, c11_hin_v_cbse_02_009, c11_hin_v_cbse_02_012, c11_hin_v_cbse_02_013, c11_hin_v_cbse_02_014, c12_hin_a_cbse_01_007, c12_hin_a_cbse_08_007, c12_hin_a_cbse_10_007, c12_hin_v_cbse_02_007

## FORWARD_REASONS
c11_hin_v_cbse_02_008: Imagery and metaphor (e.g., "pond as memory vessel") are the literary vehicles through which secondary themes are conveyed.
c11_hin_v_cbse_02_009: Irony and symbolism (e.g., water giving life but reflecting caste divisions) deepen secondary theme analysis.
c11_hin_v_cbse_02_012: Comprehension questions (literal and inferential) test whether students can locate textual evidence for secondary themes.
c11_hin_v_cbse_02_013: Critical thinking requires synthesizing multiple secondary themes into an interpretive argument about the text's worldview.
c11_hin_v_cbse_02_014: Writing skills (analytical paragraphs, essays) apply secondary theme analysis in structured academic responses.
c12_hin_a_cbse_01_007: Vitan Chapter 2 contrasted poetic and prosaic thematic treatment.  
c12_hin_a_cbse_08_007: अगला तार्किक चरण: Secondary themes are the underlying, complementary ideas in a literary work that support, contrast w... इस नोड की अवधारणाओं को सीधे उपयोग/विस्तारित करता है।  
c12_hin_a_cbse_10_007: Reinforces theme identification in non-fiction prose.  
c12_hin_v_cbse_02_007: Class 11 secondary theme analysis provides the methodological foundation (identify-trace-explain) used here at higher depth.  

## CROSS_SUBJECT_PREREQS


## CROSS_SUBJECT_REASONS
none

## CHAIN_DESCRIPTION
c11_hin_v_cbse_02_006 -> c11_hin_v_cbse_02_007 -> c11_hin_v_cbse_02_013: Primary theme anchors secondary theme analysis, which feeds into critical interpretation.

## THIS_FORMULA
N/A - conceptual

## FORMULA_VARIABLES
N/A

## FORMULA_UNITS
N/A

## COMPUTATION_TYPE
analytical

## CROSS_SUBJECT
c11_sociology_social_stratification | The secondary theme of caste hierarchy in labor organization (separate seating, renamed workers) directly illustrates sociological concepts of structural inequality and ritual pollution/purity in rural India.
c11_geography_water_resources | The indigenous water classification (इक्यजिकुह, इकरकीकुह, यष्टिक्रियकुह) reflects traditional hydrological knowledge systems that geography examines as community-based resource management.
c11_economics_informal_sector | The pond-builders' wage structure (annual retainer, festival bonuses, piece-rate for extra work) exemplifies informal labor economics — precarious yet culturally embedded.
c11_history_environmental_history | The text's portrayal of johads as historical infrastructure shaped by climatic adaptation aligns with environmental history's focus on human-water relationships over time.

## PREREQ_CONCEPT
Primary theme identification: the ability to state the text's central message in one sentence and locate its main textual supports.

## PREREQ_BEFORE
Student must be able to write: "The primary theme of this chapter is community-driven water conservation through traditional johad-building in arid Rajasthan" and cite 2-3 key passages.

## PREREQ_STUCK
If stuck, review node 006 (Primary Theme) and practice writing the primary theme statement with evidence — secondary themes cannot be analyzed without this anchor.

## WORKED_EXAMPLE_1
PROBLEM: Identify and analyze the secondary theme of "ritual as social contract" in the pond-building process described in the text (pages 14-16), using the PEEL structure (Point, Evidence, Explanation, Link).

STEPS:
- Step 1: Identify the recurring pattern — before digging begins, rituals occur: first day क्खाई (worship), offering three cloves/cardamoms, later चककक (completion ceremony) with feasting. These are not optional; they structure the work timeline.
- Step 2: Formulate the Point: Rituals in pond-building function as social contracts that legitimize collective labor, distribute risk, and reinforce community bonds beyond mere superstition.
- Step 3: Gather Evidence: (a) Page 14: "पहले दिन क्खाई की पूजा... तीन लौंग-इलायची" — low-cost, accessible ritual marking labor's sacred start. (b) Page 15: "चककक... साझा भोज" — completion feast where all workers eat together, temporarily suspending hierarchy. (c) Page 16: Officials (पटवारी, तहसीलदार) attend, linking ritual to bureaucratic recognition.
- Step 4: Explanation: The क्खाई ritual transforms digging from wage-labor into communal duty (धर्म), making withdrawal socially costly. The चककक feast redistributes honor — the pond belongs to all who ate. Official presence converts ritual into administrative record. Together, rituals bind individuals to the collective project across caste, class, and state boundaries.
- Step 5: Link to primary theme: These rituals sustain the primary theme (community resilience) by making cooperation emotionally and socially durable, not just economically rational. Without ritual, the collective might fracture under drought stress.

REASONING: The PEEL structure forces movement from observation (rituals exist) to analysis (rituals function as social contracts) to synthesis (rituals enable the primary theme). Each step builds evidentiary rigor required for board-level answers.

ANSWER: The secondary theme "ritual as social contract" emerges through three key rituals: क्खाई (initiation), ongoing offerings during digging, and चककक (completion feast). These rituals legitimize collective labor as sacred duty (not mere work), create moments of caste-transcending commensality, and bridge community practice with state recognition. They reveal that water infrastructure in this society is not just technical but covenantal — built on shared belief as much as shared labor.

## WORKED_EXAMPLE_2
PROBLEM: Compare how the secondary theme of "knowledge authority" plays out in two scenes: (a) the elder pond-builder teaching apprentices (pages 10-11) and (b) the government official classifying drought severity (page 17). Use a Venn diagram approach in writing.

STEPS:
- Step 1: Define the two knowledge authorities — Scene A: Embodied, apprenticeship-based, location-specific (elder पस्तकिज्या reading soil, slope, vegetation). Scene B: Codified, metric-based, universalizable (official measuring rainfall deficit, categorizing villages).
- Step 2: Create comparison criteria: Source of authority, transmission method, adaptability, accountability, relationship to power.
- Step 3: Analyze Scene A (elder teaching): Authority from decades of successful ponds (track record). Transmission: oral, hands-on, context-dependent ("यहाँ की मिट्टी ऐसी है"). Adaptability: adjusts to each site's micro-topography. Accountability: visible in pond's performance. Power: moral, not coercive.
- Step 4: Analyze Scene B (official classification): Authority from state mandate. Transmission: written circulars, standardized forms. Adaptability: low — same categories applied across diverse ecologies. Accountability: to superiors, not villagers. Power: coercive (relief funds depend on category).
- Step 5: Synthesize the Venn overlap: Both claim to "know water," both determine resource allocation, both affect survival. But Scene A's knowledge lives in bodies and landscapes; Scene B's lives in files and formulas. The text privileges Scene A by showing its predictive success (ponds hold water) versus Scene B's reactive failure (relief arrives late).
- Step 6: Connect to secondary theme: The tension reveals "epistemic justice" as a secondary theme — whose knowledge counts when water is scarce? The text argues for pluralism: official categories for coordination, indigenous categories for precision.

REASONING: This worked example models comparative analysis — a key board exam skill — by structuring comparison around analytical criteria rather than description. The 6-step process moves from definition to criteria to evidence to synthesis to thematic connection.

ANSWER: The elder's authority is epistemic (grounded in ecological intimacy and proven outcomes); the official's is institutional (grounded in state power and standardization). The elder reads the land; the official reads the rain gauge. The text shows the elder's knowledge producing living ponds; the official's knowledge producing delayed relief. This contrast establishes "knowledge justice" as a secondary theme: sustainable water management requires recognizing and integrating both epistemic systems, not replacing one with the other.

## WORKED_EXAMPLE_3
PROBLEM: Write a board-exam style analytical paragraph (150 words) on the secondary theme "water scarcity as a revelator of social fault lines" using evidence from at least three different sections of the chapter. Integrate primary theme connection.

STEPS:
- Step 1: Deconstruct the prompt — "revelator of social fault lines" means water scarcity exposes pre-existing cracks (caste, gender, class, state-society). Need 3+ textual sections. Target: 150 words, analytical tone, PEEL structure.
- Step 2: Select evidence clusters: Cluster 1 (Caste): Pages 10-11 — pond-builders include "वंचित समूह" (marginalized groups), yet seating remains segregated. Cluster 2 (Gender): Pages 18-19 — women as पनिहारिनें (water-bearers) walk kilometers daily; men build infrastructure. Cluster 3 (State-society): Page 17 — drought categories determine relief, but categories ignore local reality; villagers manipulate records to qualify.
- Step 3: Draft Point sentence: "Water scarcity in the chapter acts less as a creator than a revelator of entrenched social fault lines — caste, gender, and bureaucratic alienation — that persist even during collective survival efforts."
- Step 4: Draft Evidence-Explanation cycles: (a) Caste: Collective digging (सामूहिक श्रम) coexists with जाति-आधारित पंगत — the pond's water touches all hands, but the meal's seating replicates hierarchy. (b) Gender: Pond-building earns wages, festivals, recognition; water-fetching earns invisibility. The same water crisis assigns men public builder-identity, women private carrier-burden. (c) State-society: Official drought codes (अभाव, निकट-अभाव) reduce lived thirst to administrative checkboxes; villagers perform "scarcity" to access relief, revealing a performative gap between state categories and ground truth.
- Step 5: Draft Link to primary theme: These fault lines do not negate the primary theme (community resilience) — they complicate it. Resilience is not unity but negotiation across these fractures. The johad holds water *and* these tensions.
- Step 6: Edit for concision, academic vocabulary (revelator, commensality, epistemic, performative), and flow. Verify word count ~150.

REASONING: This example models the exact board exam competency: writing a tight, evidence-rich analytical paragraph that synthesizes multiple textual locations into a coherent thematic argument. The 6-step process mirrors exam conditions: prompt analysis → evidence selection → thesis → evidence cycles → thematic synthesis → polishing.

ANSWER: Water scarcity in the chapter acts less as a creator than a revelator of entrenched social fault lines — caste, gender, and bureaucratic alienation — that persist even during collective survival efforts. Collective pond-digging (सामूहिक श्रम) coexists with caste-segregated seating (जाति-आधारित पंगत): the pond's water touches all hands equally, but the meal's architecture replicates hierarchy. Gender divides labor symbolically: men's pond-building earns wages, festivals, and public identity as पस्तकिज्या; women's daily water-fetching (पनिहारिनें) earns invisibility and physical burden. State drought categories (अभाव, निकट-अभाव) reduce lived thirst to administrative checkboxes, forcing villagers to perform "scarcity" for relief — exposing a performative gap between bureaucratic epistemology and embodied reality. These fault lines do not negate the primary theme of community resilience; they complicate it. The johad holds not just water but these negotiated tensions — resilience as ongoing negotiation, not achieved unity.

## COMPETENCY_QUESTION_1
QUESTION: The author describes how pond-builders (पस्तकिज्या) develop specialized vocabulary for water types (इक्यजिकुह, इकरकीकुह, यष्टिक्रियकुह) that differs from both scientific hydrology and official drought terminology. Using this example, explain how the secondary theme of "language as epistemic sovereignty" operates in the text. What does the community's insistence on its own water-lexicon reveal about power and knowledge?

COMPETENCY: Analytical interpretation — connecting linguistic evidence to thematic argument about knowledge power.

STEPS:
- Step 1: Identify the three water-terms and their meanings from the text (indigenous classification based on flow behavior and seasonal timing).
- Step 2: Contrast with scientific terms (surface runoff, groundwater, interflow) and official terms (scarcity categories based on rainfall deficit).
- Step 3: Analyze why the community retains its terms despite exposure to others — the terms encode *actionable* knowledge (where to dig, when to expect recharge) that external terms don't provide.
- Step 4: Argue that linguistic retention = epistemic sovereignty — the community refuses to let its hydrological reality be translated into categories that serve state administration over local survival.
- Step 5: Conclude: Language here is not just description but resistance — naming water on their own terms preserves their capacity to act on it.

ANSWER: The three terms — इक्यजिकुह (surface runoff from first rains), इकरकीकुह (groundwater recharge), यष्टिक्रियकुह (subsurface flow between strata) — form a practical typology guiding *where* and *when* to dig johads. Scientific hydrology uses similar categories but lacks the temporal granularity (e.g., "first rain runoff vs. later runoff") crucial for timing labor. Official categories ignore subsurface flow entirely. The community's insistence on its lexicon reveals that **knowledge power lies in operational utility**: their terms enable effective action; external terms enable administrative control. By retaining their vocabulary, pond-builders maintain epistemic sovereignty — the right to define their hydrological reality in ways that serve their survival, not state legibility. This makes "language as epistemic sovereignty" a secondary theme: the struggle over water is also a struggle over what counts as valid knowledge about water.

DIFFICULTY: medium

## COMPETENCY_QUESTION_2
QUESTION: The chapter ends with the image of the pond (जोहड़) holding water *and* reflecting the village — "जोहड़ का पानी आकाश को नहीं, गांव को दिखाता है" (The pond's water reflects not the sky but the village). Using this metaphor as your anchor, write a 200-word critical analysis of how the secondary theme "infrastructure as social mirror" unifies at least three other secondary themes in the text. Your analysis must reference specific textual moments without quoting extensively.

COMPETENCY: Synthetic critical writing — integrating multiple secondary themes through a central metaphor with textual evidence.

STEPS:
- Step 1: Unpack the metaphor — the pond as mirror means its physical structure (depth, banks, inlets) and social process (who dug, who fetches, who decides) both *hold* and *reflect* the village's social reality.
- Step 2: Select three secondary themes to unify: (a) Caste hierarchy in collective labor, (b) Gendered water access, (c) Epistemic tension between indigenous and official knowledge.
- Step 3: For each theme, identify the "reflection" moment: (a) Caste: The pond's embankment built by all castes, but the inauguration feast's seating mirrors village hierarchy. (b) Gender: The pond stores water men's labor extracted, but women's bodies transport it — the mirror shows male credit, female labor. (c) Knowledge: The pond's design follows इक्यजिकुह logic (indigenous), but its existence in revenue records follows official categories — the mirror shows dual epistemologies.
- Step 4: Synthesize: The pond doesn't just *reveal* these themes passively; its *construction* actively *produces* the social relations it reflects. Digging together creates momentary equality; feasting reinstates hierarchy. The infrastructure is the site where social reality is both enacted and observed.
- Step 5: Write the analysis with thesis, three evidence paragraphs, synthesis, and closing — 200 words, board-exam tone.

ANSWER: The closing metaphor — "the pond reflects not the sky but the village" — crystallizes the secondary theme of infrastructure as social mirror. The johad does not merely store water; its physical and ritual architecture reflects, enacts, and sometimes contests the village's fault lines. First, caste: the embankment rises through collective labor where all hands touch the same soil, yet the completion feast (चककक) reinstates hierarchy through segregated seating (जाति-आधारित पंगत). The pond mirrors this duality — unity in making, division in celebrating. Second, gender: the pond exists because men's labor (पस्तकिज्या, wages, public recognition) dug it, but its water reaches homes through women's invisible daily labor (पनिहारिनें, head-loads, no ceremony). The mirror shows male credit superimposed on female sustenance. Third, knowledge: the pond's siting follows indigenous hydrology (इक्यजिकुह, यष्टिक्रियकुह — reading slope, soil, subsurface flow), yet its legitimacy in state eyes depends on official drought codes that ignore these very logics. The pond thus reflects an epistemic standoff. Crucially, the infrastructure does not passively reflect; its construction *produces* these social relations. The act of digging together creates fleeting equality; the act of categorizing it for relief produces performative scarcity. The johad is where the village sees itself — fractured, negotiating, enduring. Water conservation here is not technical triumph but social covenant, renewed each monsoon in the mud and the mirror.

DIFFICULTY: hard