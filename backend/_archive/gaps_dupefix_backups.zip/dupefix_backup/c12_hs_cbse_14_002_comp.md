## PARENT_NODE_ID
c12_hs_cbse_14_002

## EXAM_TARGETS
CUET (Arts), CLAT, UPSC Foundation, NDA, BA entrances, BBA entrances

## STREAM
humanities

## SCOPE_BOUNDARY
Covers classification of stains by origin and chemical nature, general principles of stain removal, and fabric‑specific laundering considerations for natural and synthetic fibres.  
Does not cover advanced textile engineering, nanocoating technologies, industrial dye synthesis, or non‑textile material conservation.

## NODES_INVOLVED
### PRIMARY_SUBJECT_NODES:
c12_hs_cbse_14_002, c12_hs_cbse_14_003, c12_hs_cbse_14_004, c12_hs_cbse_14_006, c12_hs_cbse_14_011
### CROSS_SUBJECT_NODES:
c12_hist_cbse_03_007 (Cultural Heritage Conservation), c12_polsc_cbse_02_012 (Heritage Legislation and International Treaties), c12_geo_cbse_04_009 (Coastal Water Salinity and Hardness), c12_psy_cbse_05_015 (Consumer Trust and Brand Perception), c12_soc_cbse_03_010 (Social Impact of Eco‑friendly Practices)
### PREREQUISITE_NODES:
c10_hs_cbse_09_001 (Fabric Fibre Basics), c11_hs_cbse_02_004 (Protein and Tannin Chemistry), c11_chem_cbse_08_003 (Acid‑Base Concepts), c10_geo_cbse_01_005 (Water Cycle), c11_psy_cbse_04_002 (Learning and Motivation)

## SEED_QUESTION_1
### TITLE: Museum Textile Conservation – Mixed Stain on a Silk Brocade
### SCENARIO:
A 19th‑century silk brocade banner, part of a museum’s textile collection, is being digitised. During handling, a conservator accidentally spills a mixture of freshly brewed coffee (≈5 mL) and a ball‑point pen oil‑based ink (≈2 mL) on the lower right corner. The banner is displayed in a climate‑controlled hall (22 °C, 55 % RH). The museum’s conservation policy (aligned with UNESCO guidelines) mandates that any treatment must be reversible, use the mildest effective agent first, and avoid altering the fibre’s natural sheen. The conservator must decide: (i) how to classify each stain component, (ii) which general principle(s) of stain removal apply, (iii) whether to use a water‑based tannin remover, a solvent‑based ink remover, or a sequential approach, and (iv) how to test the chosen method without risking further damage. The ambient coastal humidity occasionally spikes to 70 % RH, affecting drying times. Consider the silk’s protein nature, the coffee’s tannin‑rich acidic profile (pH≈5), and the ink’s non‑polar solvent base.
### CONCEPTS_COMBINED:
PRIMARY: c12_hs_cbse_14_002 (Stain classification & principles), c12_hs_cbse_14_003 (Specific removal methods), c12_hs_cbse_14_004 (Laundry process – testing), c12_hs_cbse_14_006 (Detergents/action), c12_hs_cbse_14_011 (Fibre‑specific laundering – silk)  
CROSS: c12_hist_cbse_03_007 (Heritage value), c12_polsc_cbse_02_012 (Legal/ethical constraints), c12_geo_cbse_04_009 (Humidity effect on drying), c12_psy_cbse_05_015 (Decision stress), c12_soc_cbse_03_010 (Public perception of conservation)
### DIFFICULTY_TIER: Advanced
### EXAM_LEVELS: UPSC Prelims, CLAT, CUET (Arts)

#### SUB_PART_A
**Q:** Identify the chemical class of each spill component (coffee and ink) and justify why each belongs to that class based on its molecular composition.  
**Nodes:** c12_hs_cbse_14_002, c11_hs_cbse_02_004 | **Level:** Main | **Time:** 70 sec  
**Guideline:**  
Step 1 (Identify+Recall): Recall stain classification by chemical nature – protein, tannin, oil, dye. Coffee contains chlorogenic acids (tannin); ink contains lipid‑soluble pigments dissolved in aliphatic solvents (oil).  
Step 2 (Setup): List observed properties – colour, solubility in water vs. organic solvent, pH.  
Step 3 (Execute): Match coffee to tannin class (water‑soluble, acidic); ink to oil class (solvent‑soluble, non‑polar).  
Step 4 (Verify+Answer): Coffee → tannin stain; Ink → oil stain. No unit needed.  
Step 5 (Generalize): If the ink were water‑based, it would shift to dye class.  
**Shortcut:** Spot‑test with water vs. alcohol | Saves 20 sec | Valid for fresh stains.  
**Traps:**  
1) Calling coffee a protein stain (confuses with milk) – misidentifies tannin‑protein similarity.  
2) Labelling ink as a dye stain (overlooks solvent base) – ignores solubility test.  
3) Assuming both are mineral stains (ignores organic origin) – misapplies classification criteria.  
**Variants:** V1: Change coffee to tea (same class) V2: Change ink to permanent marker (dye‑oil mix) V3: Add constraint: stain is 24 h old (oxidation) V4: Conceptual: Explain why tannins bind silk via H‑bonding V5: Assertion‑Reason: A: Coffee is tannin; R: It contains phenolic groups that chelate metals.

#### SUB_PART_B
**Q:** According to the general principles of stain removal, which step should the conservator perform first and why?  
**Nodes:** c12_hs_cbse_14_002, c12_hs_cbse_14_004 | **Level:** Advanced | **Time:** 80 sec  
**Guideline:**  
Step 1 (Identify+Recall): Principles: mildest agent first, test hidden area, work from outside inward.  
Step 2 (Setup): Identify available agents – mild aqueous tannin remover (e.g., dilute glycerin‑water) vs. strong solvent (e.g., acetone).  
Step 3 (Execute): Choose mildest effective agent → start with water‑based tannin lift for coffee, then treat ink with minimal solvent.  
Step 4 (Verify+Answer): First step: apply a dilute aqueous solution (glycerin‑water) to a hidden seam to test for colour bleed or fibre distortion.  
Step 5 (Generalize): If the fabric were cotton, a stronger alkaline pre‑soak could be used first.  
**Shortcut:** “Mildest first” rule | Saves 15 sec | Valid when fibre sensitivity unknown.  
**Traps:**  
1) Starting with solvent (violates mildest‑first) – risks silk degradation.  
2) Skipping hidden‑area test (ignores principle) – may cause visible damage.  
3) Working from centre outward (reverse) – spreads stain.  
**Variants:** V1: Fabric is polyester (more solvent‑tolerant) V2: Stain is dried (requires re‑wetting) V3: Add constraint: no solvents allowed (forces aqueous only) V4: Conceptual: Why work from outside inward? V5: Assertion‑Reason: A: Test hidden area first; R: Prevents irreversible damage to visible portion.

#### SUB_PART_C
**Q:** Calculate the approximate pH of the coffee spill assuming it contributes 0.02 mol of acetic‑acid‑equivalent titratable acidity to 5 mL of spill, and the silk’s isoelectric point is pH 4.5. Will the silk be positively, negatively, or neutrally charged during treatment?  
**Nodes:** c12_hs_cbse_14_002, c11_hs_cbse_02_004, c11_chem_cbse_08_003 | **Level:** Advanced | **Time:** 100 sec  
**Guideline:**  
Step 1 (Identify+Recall): pH = –log[H⁺]; H⁺ from acid ≈ moles/volume (L). Silk charge: pH < pI → positive; pH > pI → negative.  
Step 2 (Setup): Moles acid = 0.02 mol; Volume = 5 mL = 0.005 L → [H⁺] = 0.02/0.005 = 4 M.  
Step 3 (Execute): pH = –log(4) ≈ –0.60 (unrealistic; indicates assumption too high). Realistically, coffee titratable acidity ≈0.002 mol → [H⁺]=0.002/0.005=0.4 M → pH≈0.40. Still acidic (<4.5).  
Step 4 (Verify+Answer): pH ≈ 0.4–2.0 (acidic) → silk (pI 4.5) carries net **positive** charge.  
Step 5 (Generalize): If spill were neutral (pH 7), silk would be negative.  
**Shortcut:** Use pH ≈ –log(moles/volume) | Saves 25 sec | Valid for monoprotic acids.  
**Traps:**  
1) Forgetting to convert mL to L → overestimates [H⁺] by 1000×.  
2) Using pKa of acetic acid incorrectly (needs Henderson‑Hasselbalch).  
3) Assuming silk charge follows fabric pH directly without considering buffering.  
**Variants:** V1: Volume 10 mL (pH higher) V2: Acid amount 0.001 mol (pH≈1.0) V3: Add constraint: silk treated with buffer pH 6.0 (charge negative) V4: Conceptual: Explain effect of charge on tannin binding V5: Assertion‑Reason: A: Silk positive in acid; R: Protonated amino groups exceed deprotonated carboxyls.

#### SUB_PART_D
**Q:** The conservator plans to use a 2 % v/v ethanol‑water blend to lift the oil‑based ink after tannin removal. If the spill area is 2 cm² and the fabric thickness is 0.02 cm, estimate the volume of blend needed to fully penetrate the stained zone assuming 80 % absorption efficiency.  
**Nodes:** c12_hs_cbse_14_004, c12_hs_cbse_14_006, c10_geo_cbse_01_005 | **Level:** Main | **Time:** 90 sec  
**Guideline:**  
Step 1 (Identify+Recall): Volume needed = area × thickness ÷ efficiency.  
Step 2 (Setup): Area = 2 cm²; thickness = 0.02 cm → raw volume = 0.04 cm³ = 0.04 mL. Efficiency = 0.80 → required = raw/0.8.  
Step 3 (Execute): 0.04 mL / 0.8 = 0.05 mL.  
Step 4 (Verify+Answer): ≈0.05 mL (50 µL) of 2 % ethanol‑water blend.  
Step 5 (Generalize): If thickness doubled, volume doubles.  
**Shortcut:** V = (A×t)/η | Saves 15 sec | Valid for uniform thin layers.  
**Traps:**  
1) Forgetting to divide by efficiency → underestimates needed volume.  
2) Using area in mm² without conversion → error factor 100.  
3) Assuming 100 % penetration (ignores fabric porosity).  
**Variants:** V1: Area 5 cm² (volume 0.125 mL) V2: Efficiency 50 % (volume 0.10 mL) V3: Add constraint: use pure ethanol (changes solubility) V4: Conceptual: Why ethanol‑water blend reduces surface tension? V5: Assertion‑Reason: A: 0.05 mL needed; R: Ethanol lowers interfacial tension, aiding oil removal.

#### SUB_PART_E
**Q:** Discuss how the museum’s public relations team should communicate the conservation intervention to visitors, referencing principles of corporate communication and public relations from the communication chapter, and predict one possible visitor perception outcome if the message emphasizes reversibility versus emphasizing traditional craftsmanship.  
**Nodes:** c12_hs_cbse_14_002 (link via stain removal), c12_psy_cbse_05_015, c12_soc_cbse_03_010, (implied communication nodes – we treat as cross‑subject) | **Level:** Advanced | **Time:** 110 sec  
**Guideline:**  
Step 1 (Identify+Recall): PR principles – transparency, stakeholder engagement, message framing.  
Step 2 (Setup): Two frames: (a) “Scientific, reversible treatment preserves authenticity”; (b) “Honoring traditional hand‑weaving techniques”.  
Step 3 (Execute): Frame (a) builds trust in expertise, reduces fear of alteration; Frame (b) appeals to heritage pride but may raise concerns about modernity.  
Step 4 (Verify+Answer): Emphasizing reversibility → likely outcome: increased visitor confidence in museum’s care, higher perceived credibility. Emphasizing craftsmanship → outcome: heightened emotional connection, but possible skepticism if modern tools visible.  
Step 5 (Generalize): If audience skewed toward tourists, reversibility frame works better; if audience skewed toward scholars, craftsmanship frame resonates.  
**Shortcut:** Message‑audience matrix | Saves 20 sec | Valid for stakeholder‑specific PR.  
**Traps:**  
1) Assuming all visitors interpret technical details equally (ignores literacy).  
2) Overemphasizing reversibility may seem evasive about intervention extent.  
3) Neglecting social media amplification (risk of viral misinformation).  
**Variants:** V1: Audience = school children (frame simplifies to “safe cleaning”) V2: Medium = Instagram visual story (needs before/after) V3: Add constraint: limited budget (forces organic social media) V4: Conceptual: Explain two‑way symmetric model of PR V5: Assertion‑Reason: A: Reversibility frame boosts trust; R: Transparency reduces uncertainty aversion.

## SEED_QUESTION_2
### TITLE: Eco‑Laundry Startup – AI‑Guided Stain Protocol for Activewear in a Humid Coastal City
### SCENARIO:
“PureWash”, an eco‑friendly laundry subscription service, uses an AI app to recommend stain‑removal protocols for customers’ activewear (polyester‑cotton 65/35 blend). A user in Mumbai uploads a photo of a gym shirt showing three simultaneous stains: a sweat patch (protein‑rich, slightly acidic), a sunscreen spot (oil‑soluble avobenzone, octocrylene), and a mud splatter (mineral‑silicate, alkaline). The city’s monsoon season has raised groundwater hardness to 300 ppm CaCO₃, and the local tap water shows elevated chloride due to seawater intrusion. The AI must consider: (i) stain classification, (ii) water hardness impact on detergent efficacy, (iii) choice of biodegradable surfactant vs. conventional detergent, (iv) fabric‑specific temperature limits (polyester melts >80 °C, cotton tolerates 90 °C), and (v) the user’s eco‑concern score (measured via a Likert scale) influencing willingness to accept a longer, cooler wash. The app also logs the user’s past preference for “plant‑based” labels, a factor shown to increase trust by 22 % in prior surveys.  
### CONCEPTS_COMBINED:
PRIMARY: c12_hs_cbse_14_002, c12_hs_cbse_14_003, c12_hs_cbse_14_004, c12_hs_cbse_14_006, c12_hs_cbse_14_011  
CROSS: c12_geo_cbse_04_009 (Water hardness & salinity), c12_psy_cbse_05_015 (Consumer trust & eco‑label effect), c12_soc_cbse_03_010 (Adoption of green services), (implied tech node – AI recommendation) | **DIFFICULTY_TIER:** Advanced  
### EXAM_LEVELS: CUET (Arts), CLAT, UPSC Prelims

#### SUB_PART_A
**Q:** Classify each of the three stains (sweat, sunscreen, mud) by chemical nature and indicate their solubility tendency.  
**Nodes:** c12_hs_cbse_14_002, c11_hs_cbse_02_004 | **Level:** Main | **Time:** 75 sec  
**Guideline:**  
Step 1 (Identify+Recall): Recall classes – protein, tannin, oil, dye, mineral. Sweat = protein/urea; sunscreen = oil‑soluble avobenzone (lipid); mud = mineral silicate.  
Step 2 (Setup): Test solubility – sweat water‑soluble; sunscreen soluble in ethanol/hexane; mud insoluble in water, disperses with agitation.  
Step 3 (Execute): Assign: Sweat → protein (water‑soluble); Sunscreen → oil (solvent‑soluble); Mud → mineral (insoluble).  
Step 4 (Verify+Answer): Sweat – protein, WS; Sunscreen – oil, SS; Mud – mineral, INS.  
Step 5 (Generalize): If sunscreen were zinc‑oxide inorganic, it’d shift to mineral.  
**Shortcut:** Solubility spot‑test (water vs. alcohol) | Saves 18 sec | Valid for fresh stains.  
**Traps:**  
1) Labeling sweat as tannin (confuses with lactic acid).  
2) Calling sunscreen a dye stain (ignores lipid carrier).  
3) Treating mud as protein (organic matter misidentification).  
**Variants:** V1: Sweat aged → adds urea crystals (still protein) V2: Sunscreen replaced by zinc‑oxide (mineral) V3: Add constraint: water temperature limited to 30 °C (affects solubility) V4: Conceptual: Why protein stains bind cotton via H‑bonding? V5: Assertion‑Reason: A: Mud is insoluble; R: Silicate lattice lacks polar groups for H‑bonding.

#### SUB_PART_B
**Q:** Estimate the effective hardness (in ppm CaCO₃) of the wash water if the groundwater contributes 300 ppm and seawater intrusion adds 50 ppm NaCl (assuming NaCl contributes 0 % to CaCO₃ equivalence but increases ionic strength, reducing surfactant activity by 15 %).  
**Nodes:** c12_hs_cbse_14_004, c12_geo_cbse_04_009, c10_geo_cbse_01_005 | **Level:** Main | **Time:** 85 sec  
**Guideline:**  
Step 1 (Identify+Recall): Hardness expressed as CaCO₃ equivalent; NaCl does not add hardness but affects activity.  
Step 2 (Setup): Base hardness = 300 ppm. Activity reduction = 15 % → effective hardness = base / (1‑0.15) ? Actually, to achieve same surfactant performance, need to compensate: required hardness equivalence = base × (1+0.15) = 300 × 1.15 = 345 ppm.  
Step 3 (Execute): 300 × 1.15 = 345 ppm CaCO₃‑equivalent.  
Step 4 (Verify+Answer): Effective hardness ≈ 345 ppm.  
Step 5 (Generalize): If NaCl rose to 100 ppm with 20 % activity loss, effective hardness = 300 × 1.20 = 360 ppm.  
**Shortcut:** Effective hardness = nominal × (1 + activity‑loss fraction) | Saves 12 sec | Valid for monovalent salt interference.  
**Traps:**  
1) Adding NaCl ppm directly to hardness (unit mismatch).  
2) Assuming linear activity loss without considering micelle formation.  
3) Ignoring temperature effect on hardness precipitation.  
**Variants:** V1: Groundwater 250 ppm, NaCl 30 ppm, loss 10 % → 275 ppm V2: Add constraint: use built‑in water softener (exchange Na⁺) → hardness drops to 60 ppm V3: Conceptual: Explain why Ca²⁺ binds surfactant anions V4: Assertion‑Reason: A: Higher ionic strength reduces surfactant efficacy; R: Shields electrostatic heads, increasing CMC.  
**V5:** Change to soft water (30 ppm) → effective hardness ≈ 35 ppm (if loss 15 %).

#### SUB_PART_C
**Q:** The AI recommends a two‑step wash: (1) 30 °C, 15 min with a plant‑based anionic surfactant (critical micelle concentration 0.02 % w/v) for protein stain, followed by (2) 40 °C, 10 min with the same surfactant plus 5 % v/v ethanol for oil stain. If the surfactant’s solubility limit in water at 30 °C is 0.05 % w/v, calculate the maximum surfactant concentration (in % w/v) that can be used in step 1 without precipitation, and state whether the chosen 0.02 % is safe.  
**Nodes:** c12_hs_cbse_14_006, c12_hs_cbse_14_004, c11_chem_cbse_08_003 | **Level:** Advanced | **Time:** 100 sec  
**Guideline:**  
Step 1 (Identify+Recall): Solubility limit = max concentration before precipitation.  
Step 2 (Setup): Given limit = 0.05 % w/v. Desired = 0.02 % w/v.  
Step 3 (Execute): 0.02 % < 0.05 % → safe.  
Step 4 (Verify+Answer): Maximum usable = 0.05 % w/v; chosen 0.02 % is **safe** (well below limit).  
Step 5 (Generalize): If temperature raised to 50 °C, solubility may increase to 0.07 %, allowing higher surfactant load.  
**Shortcut:** Compare % w/v to solubility limit | Saves 15 sec | Valid when temperature‑dependent solubility known.  
**Traps:**  
1) Mistaking % w/v for molarity without density conversion.  
2) Assuming solubility limit is temperature‑independent.  
3) Overlooking surfactant micelle formation affecting apparent solubility.  
**Variants:** V1: Limit 0.03 % → 0.02 % still safe V2: Limit 0.015 % → 0.02 % precipitates (unsafe) V3: Add constraint: use surfactant blend (non‑ionic + anionic) altering limit V4: Conceptual: Why does ethanol improve oil removal? V5: Assertion‑Reason: A: 0.02 % safe; R: Below critical precipitation threshold.

#### SUB_PART_D
**Q:** Considering the polyester‑cotton blend, determine the maximum wash temperature that avoids polyester deformation while ensuring cotton cleaning efficiency, given that polyester’s glass transition temperature (Tg) is ~78 °C and cotton’s optimal cleaning temperature for protein stains is 60 °C.  
**Nodes:** c12_hs_cbse_14_011, c12_hs_cbse_14_004 | **Level:** Main | **Time:** 80 sec  
**Guideline:**  
Step 1 (Identify+Recall): Polyester deforms above Tg; cotton cleaning improves up to ~60‑70 °C for proteins.  
Step 2 (Setup): Safe limit = min(Tg‑5 °C, cotton optimal) to provide safety margin.  
Step 3 (Execute): Tg‑5 °C = 73 °C; cotton optimal = 60 °C → limiting factor = 60 °C.  
Step 4 (Verify+Answer): Maximum safe wash temperature = **60 °C**.  
Step 5 (Generalize): If using polyester‑elastane blend (Tg lower), temperature must drop further.  
**Shortcut:** T_max = min(Tg‑margin, T_opt,cotton) | Saves 12 sec | Valid for blends where one component limits.  
**Traps:**  
1) Using Tg directly without safety margin → risk of creep.  
2) Assuming cotton needs >70 °C for proteins (overestimates).  
3) Ignoring that detergents can lower effective cleaning temperature.  
**Variants:** V1: Blend 80/20 polyester/cotton → same limit (cotton still) V2: Add constraint: stain is oil‑only → cotton optimal 50 °C → T_max = 50 °C V3: Conceptual: Explain why Tg marks onset of chain mobility. V4: Assertion‑Reason: A: 60 °C safe; R: Below Tg, polymer chains remain glass‑locked.  
**V5:** Change to 100 % polyester → T_max = 73 °C (with 5 °C margin).

#### SUB_PART_E
**Q:** The startup’s marketing highlights that 78 % of users trust the “plant‑based” label, increasing likelihood of subscription renewal by 1.34×. If baseline renewal probability is 45 %, calculate the renewed probability for users who see the label, and discuss one ethical consideration related to conveying this statistic in corporate communication.  
**Nodes:** c12_psy_cbse_05_015, c12_soc_cbse_03_010, (implied communication node) | **Level:** Advanced | **Time:** 95 sec  
**Guideline:**  
Step 1 (Identify+Recall): Renewal probability with label = baseline × factor.  
Step 2 (Setup): Baseline = 0.45; factor = 1.34.  
Step 3 (Execute): 0.45 × 1.34 = 0.603 → 60.3 %.  
Step 4 (Verify+Answer): Renewed probability ≈ **60 %**.  
Step 5 (Generalize): If factor were 1.10, renewal = 0.495 (49.5 %).  
**Shortcut:** P_label = P₀ × F | Saves 10 sec | Valid for multiplicative effect models.  
**Traps:**  
1) Adding probabilities instead of multiplying (0.45+0.34=0.79).  
2) Misinterpreting factor as percentage increase (1.34 → 34 % increase, correct).  
3) Assuming effect applies to all users regardless of prior attitude.  
**Variants:** V1: Baseline 30 % → renewal 40.2 % V2: Factor 1.60 → renewal 72 % V3: Add constraint: label only shown to eco‑neutral segment (effect halved) → renewal ≈ 52.5 % V4: Conceptual: Explain why eco‑labels trigger heuristic trust (affect‑based processing). V5: Assertion‑Reason: A: Label boosts renewal; R: Heuristic reduces cognitive load, favoring positive attitude.

## SEED_QUESTION_3
### TITLE: Smart‑Fabric Manufacturing – Multi‑Stain Challenge in Conductive Yarn Production
### SCENARIO:
A multinational electronics‑textile joint venture produces a prototype smart jacket with silver‑coated nylon yarns (conductive) intertwined with polyurethane‑based stretch fibers. During the lamination step, three contaminants appear: (1) electrolyte gel used for sensor testing (water‑based, contains NaCl and polyacrylamide, slightly basic pH 8.5), (2) a metallic dye bath residue (silver nitrate precipitate, pH ≈ 7, forms Ag₂O‑like particles), and (3) a biofilm from Pseudomonas spp. colonizing the yarn surface in a humid storage chamber (extracellular polymeric substances, polysaccharides, pH ≈ 6.5). The jacket must meet IEC 60601‑1 medical‑device safety standards, which prohibit any residual metal ions >10 ppm and require biocompatibility (ISO 10993). The production facility is located in a semi‑arid region where recycled water used for rinsing has elevated sulfate (150 ppm) and low calcium (20 ppm). The process engineering team must decide: (i) how to classify each contaminant by stain chemistry, (ii) which general principle(s) of stain removal apply given the conductive coating’s susceptibility to abrasion and chemical etching, (iii) whether to use a chelating agent (EDTA), a mild enzymatic cleaner, or a plasma‑based surface treatment, and (iv) how to validate that post‑treatment silver ion leaching stays below regulatory limits. The team also needs to draft a press release explaining the safety measures to investors and healthcare regulators, integrating principles of corporate communication and public relations.  
### CONCEPTS_COMBINED:
PRIMARY: c12_hs_cbse_14_002, c12_hs_cbse_14_003, c12_hs_cbse_14_004, c12_hs_cbse_14_006, c12_hs_cbse_14_011  
CROSS: c12_hist_cbse_03_007 (Heritage‑like value of IP), c12_polsc_cbse_02_012 (Regulatory standards – IEC/ISO), c12_geo_cbse_04_009 (Water sulfate/calcium effect), c12_psy_cbse_05_015 (Risk perception in medical tech), c12_soc_cbse_03_010 (Societal acceptance of wearables) | **DIFFICULTY_TIER:** Advanced+  
### EXAM_LEVELS: UPSC Prelims, CLAT, CUET (Arts), JEE Advanced (for interdisciplinary reasoning)

#### SUB_PART_A
**Q:** Classify each contaminant (electrolyte gel, metallic dye residue, biofilm) by chemical nature and indicate its predominant solubility class.  
**Nodes:** c12_hs_cbse_14_002, c11_hs_cbse_02_004 | **Level:** Main | **Time:** 80 sec  
**Guideline:**  
Step 1 (Identify+Recall): Recall classes – protein, tannin, oil, dye, mineral, polysaccharide. Electrolyte gel = water‑based polymer/salt (mineral‑like, but polymer). Metallic dye residue = inorganic silver salt (mineral). Biofilm = polysaccharide extracellular slime (carbohydrate).  
Step 2 (Setup): Test solubility – gel water‑soluble; silver nitrate residue water‑soluble (Ag⁺) but precipitate Ag₂O insoluble; biofilm water‑swellable, not truly soluble.  
Step 3 (Execute): Assign: Gel → mineral (ionic, WS); Dye residue → mineral (ionic, partially SS due to precipitate); Biofilm → polysaccharide (swellable, WS‑like).  
Step 4 (Verify+Answer): Gel – mineral, WS; Dye residue – mineral, partially SS; Biofilm – polysaccharide, WS‑like.  
Step 5 (Generalize): If the gel were purely organic (e.g., agar), it would shift to polysaccharide class.  
**Shortcut:** Spot‑test with water vs. alcohol | Saves 20 sec | Valid for fresh contaminants.  
**Traps:**  
1) Labeling electrolyte gel as protein (confuses with polyacrylamide).  
2) Calling metallic residue a dye stain (ignores inorganic silver).  
3) Treating biofilm as oil (overlooks polysaccharide nature).  
**Variants:** V1: Gel aged → adds calcium carbonate (still mineral) V2: Metallic residue replaced by gold nanoparticle colloid (still mineral) V3: Add constraint: pH = 4 (acidic) → gel may precipitate V4: Conceptual: Why polysaccharides swell in water? V5: Assertion‑Reason: A: Biofilm is polysaccharide; R: Contains repeating sugar units that hydrogen‑bond water.

#### SUB_PART_B
**Q:** According to the general principles of stain removal, which step should the team perform first and why?  
**Nodes:** c12_hs_cbse_14_002, c12_hs_cbse_14_004 | **Level:** Advanced | **Time:** 90 sec  
**Guideline:**  
Step 1 (Identify+Recall): Principles: mildest agent first, test hidden area, work from outside inward, avoid abrasion/etching of conductive coating.  
Step 2 (Setup): Available agents: mild enzymatic cleaner (e.g., protease), chelating agent (EDTA), plasma‑based surface treatment.  
Step 3 (Execute): Choose mildest effective agent that does not etch silver → start with enzymatic cleaner on a concealed seam to check for coating integrity.  
Step 4 (Verify+Answer): First step: apply a dilute protease solution (0.5 % w/v) to an inner hem, rinse, and inspect for silver loss or surface roughening.  
Step 5 (Generalize): If the coating were gold (more inert), a chelating agent could be tried first.  
**Shortcut:** “Mildest first, avoid etching” rule | Saves 18 sec | Valid when coating sensitivity unknown.  
**Traps:**  
1) Starting with plasma (aggressive) – risks etching silver nanocoating.  
2) Skipping hidden‑area test – may cause irreversible loss of conductivity.  
3) Using EDTA directly (strong chelator) – can complex Ag⁺ and leach silver.  
**Variants:** V1: Coating is titanium nitride (more resistant) → plasma may be used first V2: Add constraint: no liquids allowed (dry‑only) → forces plasma or UV‑ozone V3: Conceptual: Why work from outside inward on a flexible substrate? V4: Assertion‑Reason: A: Test hidden area first; R: Prevents visible damage to conductive pattern.  
**V5:** Change contaminant to organic grease → start with mild solvent wipe.

#### SUB_PART_C
**Q:** The team plans to use 0.1 % w/v EDTA solution to chelate any residual Ag⁺ after enzymatic cleaning. If the rinse water volume is 200 mL and the EDTA solution is added at 5 mL, calculate the final EDTA concentration (in % w/v) and state whether it remains below the 0.5 % w/v safety threshold for the polyurethane stretch fibers.  
**Nodes:** c12_hs_cbse_14_006, c12_hs_cbse_14_004, c11_chem_cbse_08_003 | **Level:** Advanced | **Time:** 100 sec  
**Guideline:**  
Step 1 (Identify+Recall): Final % w/v = (mass of EDTA / total volume) × 100. Assume EDTA density ≈ 1 g/mL for dilute solutions.  
Step 2 (Setup): Mass EDTA ≈ 5 mL × 1 g/mL = 5 g. Total volume = 200 mL + 5 mL = 205 mL.  
Step 3 (Execute): (5 g / 205 mL) × 100 ≈ 2.44 % w/v.  
Step 4 (Verify+Answer): Final concentration ≈ **2.4 % w/v**, which **exceeds** the 0.5 % safety limit → not safe for polyurethane.  
Step 5 (Generalize): To stay safe, limit EDTA addition to ≤ 1 mL in 200 mL rinse (≈0.5 % w/v).  
**Shortcut:** C_final = (V_add × ρ) / (V_total) × 100 | Saves 15 sec | Valid for dilute aqueous additives.  
**Traps:**  
1) Forgetting to add the volumes → underestimates denominator.  
2) Assuming EDTA density is exactly 1 g/mL (introduces small error).  
3) Overlooking that EDTA may hydrolyze, changing effective concentration.  
**Variants:** V1: Rinse volume 100 mL, EDTA 2 mL → ≈1.96 % w/v (still unsafe) V2: Add constraint: use 0.2 % w/v EDTA stock → need 50 mL stock to reach 0.5 % final V3: Conceptual: Why does EDTA chelate Ag⁺? V4: Assertion‑Reason: A: 2.4 % exceeds safety limit; R: High EDTA can swell and weaken polyurethane.  
**V5:** Change to 0.05 % w/v EDTA stock → 0.5 mL needed for safe final concentration.

#### SUB_PART_D
**Q:** After treatment, the team measures silver ion leaching at 8 ppm in the rinse effluent. The IEC 60601‑1 limit is 10 ppm. Calculate the margin of safety (as a percentage) and comment on whether the result passes the regulatory test.  
**Nodes:** c12_hs_cbse_14_002, c12_polsc_cbse_02_012, c11_chem_cbse_08_003 | **Level:** Main | **Time:** 85 sec  
**Guideline:**  
Step 1 (Identify+Recall): Margin of safety = (Limit – Measured) / Limit × 100 %.  
Step 2 (Setup): Limit = 10 ppm; Measured = 8 ppm.  
Step 3 (Execute): (10 − 8) / 10 × 100 = 20 %.  
Step 4 (Verify+Answer): Margin of safety = **20 %**; the result **passes** (measured < limit).  
Step 5 (Generalize): If measured were 12 ppm, margin would be −20 % (fail).  
**Shortcut:** Margin % = (L − M)/L × 100 | Saves 10 sec | Valid for any limit‑vs‑measure scenario.  
**Traps:**  
1) Reversing numerator (Measured−Limit) → negative margin misinterpreted as pass.  
2) Using absolute difference without dividing by limit → gives 2 ppm, not a percentage.  
3) Assuming any detectable silver is a fail (ignores limit).  
**Variants:** V1: Measured 5 ppm → margin 50 % V2: Limit tightened to 5 ppm, measured 4 ppm → margin 20 % V3: Add constraint: report in ppb (8 ppm = 8000 ppb) V4: Conceptual: Why is Ag⁺ toxic to cells? V5: Assertion‑Reason: A: 8 ppm passes; R: Below the IEC‑specified threshold.  
**V5:** Change limit to 15 ppm → margin ≈ 47 %.

#### SUB_PART_E
**Q:** Draft a short press release (≈120 words) explaining the safety measures taken to ensure the smart jacket meets IEC 60601‑1 and ISO 10993 standards, integrating principles of corporate communication and public relations (clarity, transparency, stakeholder focus).  
**Nodes:** c12_hs_cbse_14_002 (link via stain removal), c12_psy_cbse_05_015, c12_soc_cbse_03_010, (implied communication node) | **Level:** Advanced | **Time:** 115 sec  
**Guideline:**  
Step 1 (Identify+Recall): PR principles – clarity, transparency, stakeholder engagement, message framing.  
Step 2 (Setup): Identify key messages: (a) rigorous cleaning protocol, (b) verification of silver leaching <10 ppm, (c) biocompatibility testing per ISO 10993.  
Step 3 (Execute): Combine into a concise release, avoid jargon, highlight patient safety and regulatory compliance.  
Step 4 (Verify+Answer): Example release:  
*“[Company] announces that its prototype smart jacket has successfully cleared IEC 60601‑1 and ISO 10993 safety evaluations. A multi‑stage cleaning protocol—enzymatic depolymerization followed by controlled EDTA chelation—reduces residual silver ions to 8 ppm, well below the 10 ppm limit. Independent biocompatibility testing confirms non‑toxicity and non‑irritancy. Transparent reporting and ongoing monitoring ensure patient safety and regulatory trust.”*  
Step 5 (Generalize): If audience were investors, emphasize IP protection and market readiness; if audience were clinicians, stress clinical safety data.  
**Shortcut:** PR‑triangle (message‑audience‑medium) | Saves 20 sec | Valid for stakeholder‑specific communication.  
**Traps:**  
1) Overloading with technical details (loses clarity).  
2) Omitting stakeholder benefits (appears self‑serving).  
3) Using hyperbolic claims (“completely risk‑free”) → undermines credibility.  
**Variants:** V1: Audience = investors (add sentence about IP protection and expected ROI) V2: Medium = TikTok video (needs visual demo of leaching test) V3: Add constraint: word limit 80 words (forces tighter phrasing) V4: Conceptual: Explain the two‑way symmetric model of PR V5: Assertion‑Reason: A: Press release boosts trust; R: Transparent communication reduces uncertainty perception.

## DECOMPOSITION_MAP
## DECOMPOSITION_MAP
- SEED_QUESTION_1:
    - SUB_PART_A: c12_hs_cbse_14_002, c11_hs_cbse_02_004
    - SUB_PART_B: c12_hs_cbse_14_002, c12_hs_cbse_14_004
    - SUB_PART_C: c12_hs_cbse_14_002, c11_hs_cbse_02_004, c11_chem_cbse_08_003
    - SUB_PART_D: c12_hs_cbse_14_004, c12_hs_cbse_14_006, c10_geo_cbse_01_005
    - SUB_PART_E: c12_hs_cbse_14_002, c12_psy_cbse_05_015, c12_soc_cbse_03_010
- SEED_QUESTION_2:
    - SUB_PART_A: c12_hs_cbse_14_002, c11_hs_cbse_02_004
    - SUB_PART_B: c12_hs_cbse_14_004, c12_geo_cbse_04_009, c10_geo_cbse_01_005
    - SUB_PART_C: c12_hs_cbse_14_006, c12_hs_cbse_14_004, c11_chem_cbse_08_003
    - SUB_PART_D: c12_hs_cbse_14_011, c12_hs_cbse_14_004
    - SUB_PART_E: c12_psy_cbse_05_015, c12_soc_cbse_03_010
- SEED_QUESTION_3:
    - SUB_PART_A: c12_hs_cbse_14_002, c11_hs_cbse_02_004
    - SUB_PART_B: c12_hs_cbse_14_002, c12_hs_cbse_14_004
    - SUB_PART_C: c12_hs_cbse_14_006, c12_hs_cbse_14_004, c11_chem_cbse_08_003
    - SUB_PART_D: c12_hs_cbse_14_002, c12_polsc_cbse_02_012, c11_chem_cbse_08_003
    - SUB_PART_E: c12_hs_cbse_14_002, c12_psy_cbse_05_015, c12_soc_cbse_03_010

## ON_FAILURE_ROUTING
## ON_FAILURE_ROUTING
- If a student struggles with **SUB_PART_A** of any seed question → Review prerequisite node **c11_hs_cbse_02_004** (Protein and Tannin Chemistry) and re‑do the solubility spot‑test guideline.
- If a student struggles with **SUB_PART_B** → Re‑study **c12_hs_cbse_14_002** (Stain classification & principles) focusing on the “mildest agent first” and hidden‑area testing rules.
- If a student struggles with **SUB_PART_C** → Revisit **c11_chem_cbse_08_003** (Acid‑Base Concepts) for pH calculations and **c10_geo_cbse_01_005** (Water Cycle) for dilution effects.
- If a student struggles with **SUB_PART_D** → Review **c12_hs_cbse_14_004** (Laundry process – testing) and **c12_hs_cbse_14_006** (Detergents/action) for volume/efficiency calculations.
- If a student struggles with **SUB_PART_E** → Refer to **c12_psy_cbse_05_015** (Consumer Trust and Brand Perception) and **c12_soc_cbse_03_010** (Social Impact of Eco‑friendly Practices) for communication and perception frameworks.
- For **SEED_QUESTION_3** specific failures:
    - SUB_PART_A failure → Re‑read **c11_hs_cbse_02_004** (polymer vs. mineral classification).
    - SUB_PART_B failure → Review **c12_hs_cbse_14_002** (gentle cleaning principles) and **c12_polsc_cbse_02_012** (IEC/ISO standards).
    - SUB_PART_C failure → Re‑do **c11_chem_cbse_08_003** (EDTA dilution math) and safety thresholds.
    - SUB_PART_D failure → Practice limit‑vs‑measure calculations using **c11_chem_cbse_08_003**.
    - SUB_PART_E failure → Study **c12_psy_cbse_05_015** (risk perception) and **c12_soc_cbse_03_010** (stakeholder messaging).

## EXAM_STRATEGY
## EXAM_STRATEGY
1. **Time Allocation**  
   - Reserve ~2 min for reading the scenario and identifying the combined concepts.  
   - Allocate ~1 min per sub‑part (A–E) – adjust upward for calculation‑heavy parts (C, D).  
   - Keep a 30‑second buffer at the end for review.

2. **Answering Order**  
   - Start with the sub‑part you feel most confident about (often A or B) to secure quick marks.  
   - Move to the calculation‑based parts (C, D) next while the scenario details are fresh.  
   - Finish with the discussion/communication part (E) which benefits from a broader view.

3. **Elimination Technique**  
   - For multiple‑choice‑style sub‑parts, eliminate options that violate the “mildest agent first” principle or mismatch solubility class.  
   - In calculation questions, first estimate the order of magnitude (e.g., pH < 1 for strong acid) to catch unit‑conversion slips.

4. **Use of Shortcuts**  
   - Memorise the provided shortcuts (e.g., V = (A×t)/η, Margin % = (L‑M)/L×100).  
   - Apply them directly; they save 10‑25 seconds each and reduce arithmetic errors.

5. **Avoiding Common Traps**  
   - Always convert mL → L before using in pH or molarity formulas.  
   - Never add NaCl ppm directly to hardness; remember it only affects activity.  
   - Do not assume 100 % absorption or penetration; apply the given efficiency factor.  
   - In communication questions, explicitly mention transparency, stakeholder focus, and message framing.

6. **Checking Consistency**  
   - After answering, quickly verify that your answer respects the scenario constraints (e.g., temperature limits for polyester, reversibility requirement for museum textiles).  
   - Ensure units are present where required and omitted where the guideline says “No unit needed”.

7. **If Stuck**  
   - Mark the question, move on, and return if time permits.  
   - Use the ON_FAILURE_ROUTING notes to identify which prerequisite node to skim mentally (e.g., recall the acid‑base table from c11_chem_cbse_08_003).

Following this strategy will help you navigate the multi‑concept, multi‑step questions efficiently while minimizing avoidable errors. Good luck!